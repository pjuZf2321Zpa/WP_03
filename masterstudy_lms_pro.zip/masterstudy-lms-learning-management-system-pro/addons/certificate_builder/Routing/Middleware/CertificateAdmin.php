<?php

namespace MasterStudy\Lms\Pro\addons\certificate_builder\Routing\Middleware;

use MasterStudy\Lms\Plugin\Addons;
use MasterStudy\Lms\Routing\MiddlewareInterface;
use WP_REST_Response;

final class CertificateAdmin implements MiddlewareInterface {
	public function process( $request, callable $next ) {
		if ( current_user_can( 'administrator' ) ) {
			return $next( $request );
		}

		if ( $this->can_instructor_access() ) {
			return $next( $request );
		}

		return new WP_REST_Response(
			array(
				'error_code' => 'forbidden_access',
				'message'    => esc_html__( 'Only admins and instructors with certificate access can access this route!', 'masterstudy-lms-learning-management-system-pro' ),
			),
			403
		);
	}

	private function can_instructor_access(): bool {
		return function_exists( 'is_ms_lms_addon_enabled' )
			&& is_ms_lms_addon_enabled( Addons::CERTIFICATE_BUILDER )
			&& class_exists( '\STM_LMS_Options' )
			&& (bool) \STM_LMS_Options::get_option( 'instructors_certificates', false )
			&& class_exists( '\STM_LMS_Instructor' )
			&& \STM_LMS_Instructor::is_instructor();
	}
}
