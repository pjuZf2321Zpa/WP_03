<?php

/*
Plugin Name: MemberPress Scale
Plugin URI: https://memberpress.com/
Description: The membership plugin that makes it easy to accept payments for access to your content and digital products.
Version: 1.14.2
Requires at least: 6.5
Tested up to: 7.1
Requires PHP: 7.4
License: GPL v2+
License URI: https://www.gnu.org/licenses/gpl-2.0.html
Author: Caseproof, LLC
Author URI: https://caseproof.com/
Text Domain: memberpress
Update URI: memberpress
*/

/**
 * * * * * * * * * * * * * * * * * * * * * * *
 *                                           *
 * Reporting a Security Vulnerability        *
 *                                           *
 * Please disclose any security issues or    *
 * vulnerabilities to security@caseproof.com *
 *                                           *
 * * * * * * * * * * * * * * * * * * * * * * *
 */

defined('ABSPATH') || exit;

use MemberPress\GroundLevel\Package\PluginConfig;

require_once __DIR__ . '/vendor-prefixed/autoload.php';
require_once __DIR__ . '/app/MeprBootstrap.php';

/**
 * Bootstraps the plugin and returns the plugin's instance.
 */
function memberpress(): MeprBootstrap
{
    return MeprBootstrap::instance() ?? new MeprBootstrap(new PluginConfig(__FILE__));
}

memberpress();


define('MEPR_MOTHERSHIP_API_BASE_URL', 'https://mpress2.gpltimes.com/api/v1/');

$mepr_lic_key = 'b5e0b5f8-dd86-89e6-aca4-9dd6e6e1a930';

update_option('mepr_activation_override', true);
update_option('mepr_activated', true);

add_filter('pre_update_option_mepr_activated', '__return_true');

add_action('admin_init', function () {
    $option  = MEPR_PLUGIN_NAME . '_admin_notices';
    $notices = get_option($option, []);

    if (!is_array($notices) || !isset($notices['license_revoked'])) {
        return;
    }

    unset($notices['license_revoked']);

    if (empty($notices)) {
        delete_option($option);
    } else {
        update_option($option, $notices, false);
    }
}, 1);

add_filter('memberpress_allowed_download_hosts', function ($hosts) {
    return array_merge((array) $hosts, ['f004.backblazeb2.com', 'mpress2.gpltimes.com']);
});

add_action('init', function () use ($mepr_lic_key) {
    if (!class_exists('MeprOptions', false)) return;
    $opts = MeprOptions::fetch();
    if ($opts->mothership_license !== $mepr_lic_key) {
        $opts->mothership_license = $mepr_lic_key;
        $opts->store(false);
    }
}, 1);

add_action('switch_blog', function () use ($mepr_lic_key) {
    if (!class_exists('MeprOptions', false)) return;
    $opts = MeprOptions::fetch();
    if ($opts->mothership_license !== $mepr_lic_key) {
        $opts->mothership_license = $mepr_lic_key;
        $opts->store(false);
    }
}, 10);

add_filter('pre_http_request', function ($pre, $args, $url) use ($mepr_lic_key) {
    if (strpos($url, 'memberpress-mastermind') !== false || strpos($url, 'mp-mastermind') !== false) {
        if (strpos($url, '/credits/balance') !== false) {
            return [
                'headers'  => [],
                'body'     => json_encode([
                    'balance'         => 0,
                    'credits'         => 0,
                    'current_balance' => 0,
                    'purchase_url'    => '',
                    'dashboard_url'   => '',
                ]),
                'response' => ['code' => 200, 'message' => 'OK'],
                'cookies'  => [],
                'filename' => '',
            ];
        }
        if (strpos($url, '/credits/packages') !== false) {
            return [
                'headers'  => [],
                'body'     => json_encode([
                    'packages'        => [],
                    'default_package' => null,
                ]),
                'response' => ['code' => 200, 'message' => 'OK'],
                'cookies'  => [],
                'filename' => '',
            ];
        }
        if (strpos($url, '/credits/checkout') !== false) {
            return [
                'headers'  => [],
                'body'     => json_encode([
                    'error'   => true,
                    'message' => 'Credit purchase is not available.',
                ]),
                'response' => ['code' => 200, 'message' => 'OK'],
                'cookies'  => [],
                'filename' => '',
            ];
        }
    }

    $mepr_api_url = str_replace('licenses.caseproof.com', 'mpress2.gpltimes.com', $url);

    if (strpos($mepr_api_url, '/api/v1/licenses/') !== false) {
        return mepr_gpl_license_api_response($mepr_api_url);
    }

    if ($mepr_api_url !== $url) {
        return wp_remote_request($mepr_api_url, array_merge($args, ['timeout' => 30]));
    }

    if (strpos($url, 'mothership.caseproof.com') === false) return $pre;

    if (
        strpos($url, '/license_keys/check/') !== false ||
        strpos($url, '/license_keys/activate/') !== false ||
        strpos($url, '/license_keys/deactivate/') !== false
    ) {
        return [
            'headers'  => [],
            'body'     => json_encode([
                'status'     => 'enabled',
                'expires_at' => null,
                'license'    => $mepr_lic_key,
                'message'    => 'License activated successfully',
            ]),
            'response' => ['code' => 200, 'message' => 'OK'],
            'cookies'  => [],
            'filename' => '',
        ];
    }

    return wp_remote_request(
        str_replace('mothership.caseproof.com', 'mpress2.gpltimes.com', $url),
        array_merge($args, ['timeout' => 30])
    );
}, 10, 3);

add_filter('pre_set_site_transient_mepr_license_info', function ($value) use ($mepr_lic_key) {
    if (!is_array($value)) return $value;
    if (empty($value['product_slug'])) $value['product_slug'] = 'memberpress-scale';
    if (empty($value['product_name'])) $value['product_name'] = 'MemberPress Scale';
    if (isset($value['license_key']) && !is_array($value['license_key'])) {
        $value['license_key'] = ['status' => 'enabled', 'expires_at' => null, 'license' => is_string($value['license_key']) ? $value['license_key'] : $mepr_lic_key];
    }
    return $value;
}, 10, 1);

function mepr_gpl_license_http_response($data, $code = 200)
{
    return [
        'headers'  => [],
        'body'     => wp_json_encode($data),
        'response' => ['code' => $code, 'message' => get_status_header_desc($code)],
        'cookies'  => [],
        'filename' => '',
    ];
}

function mepr_gpl_license_object($license_key)
{
    return [
        'key'              => $license_key,
        'status'           => 'enabled',
        'expires_at'       => '2036-08-02T23:59:59.000Z',
        'max_activations'  => 100,
        'activation_count' => 1,
        '_embedded'        => [
            'product' => [
                'slug' => defined('MEPR_EDITION') ? MEPR_EDITION : 'memberpress-growth',
                'name' => defined('MEPR_DISPLAY_NAME') ? MEPR_DISPLAY_NAME : 'MemberPress',
                'type' => 'plugin',
            ],
            'user'    => [
                'email'      => 'noreply@gmail.com',
                'first_name' => 'GPL',
                'last_name'  => 'Times',
                'status'     => 'enabled',
            ],
        ],
    ];
}

function mepr_gpl_activation_object($license_key, $domain)
{
    $now = gmdate('c');

    return [
        'id'          => $license_key . ':' . $domain,
        'domain'      => $domain,
        'license_key' => $license_key,
        'status'      => 'active',
        'is_test'     => false,
        'created_at'  => $now,
        'updated_at'  => $now,
        '_embedded'   => ['license' => mepr_gpl_license_object($license_key)],
    ];
}

function mepr_gpl_license_api_response($url)
{
    $path   = (string) wp_parse_url($url, PHP_URL_PATH);
    $path   = trim((string) preg_replace('#^.*?/api/v1/#', '', $path), '/');
    $domain = class_exists('MeprUtils') ? MeprUtils::site_domain() : (string) wp_parse_url(home_url(), PHP_URL_HOST);

    if (preg_match('#^licenses/([^/]+)/activations/meta$#', $path, $m)) {
        return mepr_gpl_license_http_response([
            'prod'      => ['allowed' => 100, 'used' => 1, 'free' => 99],
            'test'      => ['allowed' => 100, 'used' => 0, 'free' => 100],
            '_embedded' => ['license' => mepr_gpl_license_object(rawurldecode($m[1]))],
        ]);
    }

    if (preg_match('#^licenses/([^/]+)/activations/(.+)/deactivate$#', $path, $m)) {
        return mepr_gpl_license_http_response(
            mepr_gpl_activation_object(rawurldecode($m[1]), rawurldecode($m[2]))
        );
    }

    if (preg_match('#^licenses/([^/]+)/activate$#', $path, $m)) {
        return mepr_gpl_license_http_response(
            mepr_gpl_activation_object(rawurldecode($m[1]), $domain),
            201
        );
    }

    if (preg_match('#^licenses/([^/]+)/activations/(.+)$#', $path, $m)) {
        return mepr_gpl_license_http_response(
            mepr_gpl_activation_object(rawurldecode($m[1]), rawurldecode($m[2]))
        );
    }

    if (preg_match('#^licenses/([^/]+)/activations$#', $path, $m)) {
        return mepr_gpl_license_http_response([
            'activations' => [mepr_gpl_activation_object(rawurldecode($m[1]), $domain)],
        ]);
    }

    if (preg_match('#^licenses/([^/]+)#', $path, $m)) {
        return mepr_gpl_license_http_response(mepr_gpl_license_object(rawurldecode($m[1])));
    }

    return mepr_gpl_license_http_response(mepr_gpl_license_object(''));
}
