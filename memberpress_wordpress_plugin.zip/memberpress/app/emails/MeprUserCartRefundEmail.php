<?php

if (!defined('ABSPATH')) {
    die('You are not allowed to call this page directly.');
}

/**
 * Cart order refund email sent to the customer.
 *
 * Sends one consolidated refund notice per refund action (full, per-line-item,
 * or order-level partial) rather than one per transaction.
 */
class MeprUserCartRefundEmail extends MeprBaseOptionsUserEmail
{
    /**
     * Per-refund context (amount, tax, mode, refunded txns) set before send().
     *
     * @var array
     */
    protected $context = [];

    /**
     * Set the default enabled, title, subject & body.
     *
     * @param  array $args The args.
     * @return void
     */
    public function set_defaults($args = [])
    {
        $this->title       = __('<b>Cart Order Refund</b> Notice', 'memberpress');
        $this->description = __('Sent to a customer when a cart order is refunded (full, per item, or partial).', 'memberpress');
        $this->ui_order    = 3;

        $enabled = $use_template = $this->show_form = true;
        $subject = __('Your Refund — Order #{$order_id}', 'memberpress');
        $body    = $this->body_partial();

        $this->defaults  = compact('enabled', 'subject', 'body', 'use_template');
        $this->variables = self::get_cart_refund_email_vars();
    }

    /**
     * Get the body partial for the email.
     *
     * @param  array $vars Optional variables to pass to the view.
     * @return string The body partial HTML.
     */
    public function body_partial($vars = [])
    {
        return MeprView::get_string('/emails/user-cart-refund', $vars);
    }

    /**
     * Set the per-refund context before send().
     *
     * @param  array $context Context {refunded_amount, refunded_tax, mode, refunded_txns}.
     * @return void
     */
    public function set_context(array $context)
    {
        $this->context = $context;
    }

    /**
     * Send the cart refund email for the given order.
     *
     * @param  MeprOrder    $order        The refunded cart order.
     * @param  string|false $subject      Subject override, or false for the stored default.
     * @param  string|false $body         Body override, or false for the stored default.
     * @param  boolean|null $use_template Whether to wrap in the email template, or null for the default.
     * @param  string       $content_type The content type of the email.
     * @return void
     */
    public function send($order = [], $subject = false, $body = false, $use_template = null, $content_type = 'html')
    {
        if (!($order instanceof MeprOrder)) {
            parent::send($order, $subject, $body, $use_template, $content_type);
            return;
        }

        if (!$this->enabled()) {
            return;
        }

        $user     = new MeprUser($order->user_id);
        $this->to = $user->user_email;

        $vars = self::build_cart_refund_vars($order, $user, $this->context);

        $formatted_subject = MeprUtils::replace_vals($this->get_stored_field('subject'), $vars);
        $formatted_body    = MeprUtils::replace_vals($this->get_stored_field('body'), $vars);

        // Let add-ons inject send params (e.g. pdf-invoice). Core stays agnostic.
        $send_params = MeprHooks::apply_filters('mepr_cart_refund_email_params', [], $order, $this);

        parent::send($send_params, $formatted_subject, $formatted_body, $use_template, $content_type);
    }

    /**
     * Get the available email template variables.
     *
     * @return array Variable name => description map.
     */
    public static function get_cart_refund_email_vars()
    {
        return [
            '{$user_first_name}' => __('User First Name', 'memberpress'),
            '{$user_last_name}'  => __('User Last Name', 'memberpress'),
            '{$user_email}'      => __('User Email', 'memberpress'),
            '{$order_id}'        => __('Order ID', 'memberpress'),
            '{$order_total}'     => __('Order Total', 'memberpress'),
            '{$refunded_amount}' => __('Refunded Amount', 'memberpress'),
            '{$refunded_tax}'    => __('Refunded Tax', 'memberpress'),
            '{$refunded_items}'  => __('Refunded Items (HTML table)', 'memberpress'),
            '{$refund_date}'     => __('Refund Date', 'memberpress'),
        ];
    }

    /**
     * Build the template variable replacement map for a refund.
     *
     * @param  MeprOrder $order   The cart order.
     * @param  MeprUser  $user    The purchasing user.
     * @param  array     $context The per-refund context.
     * @return array
     */
    public static function build_cart_refund_vars($order, $user, array $context)
    {
        $currency        = $order->currency;
        $refunded_amount = (float) ($context['refunded_amount'] ?? 0);
        $refunded_tax    = (float) ($context['refunded_tax'] ?? 0);
        $refunded_txns   = $context['refunded_txns'] ?? [];

        $items_html = self::build_refund_items_table($refunded_txns, $order, $context);

        $vars = [
            'user_first_name' => $user->first_name ?: '',
            'user_last_name'  => $user->last_name ?: '',
            'user_email'      => $user->user_email,
            'order_id'        => $order->id,
            'order_total'     => MeprAppHelper::format_currency($order->total, true, false, false, $currency),
            'refunded_amount' => MeprAppHelper::format_currency($refunded_amount, true, false, false, $currency),
            'refunded_tax'    => MeprAppHelper::format_currency($refunded_tax, true, false, false, $currency),
            'refunded_items'  => $items_html,
            'refund_date'     => MeprAppHelper::format_date(MeprUtils::db_now(), ''),
        ];

        return MeprUserCartReceiptEmail::escape_vars($vars);
    }

    /**
     * Build an HTML table of refunded line items (empty string for an order-level partial).
     *
     * @param  MeprTransaction[] $refunded_txns The refunded transactions (full/per-line modes).
     * @param  MeprOrder         $order         The parent cart order.
     * @param  array             $context       The per-refund context.
     * @return string HTML table string.
     */
    public static function build_refund_items_table($refunded_txns, $order, array $context)
    {
        $currency = $order->currency;
        $fmt      = fn($n) => esc_html(MeprAppHelper::format_currency($n, true, false, false, $currency));
        $mode     = $context['mode'] ?? 'full';

        // A partial refund (per-line or order-level) doesn't refund a whole line, so listing line
        // rows with their full amounts would be misleading — show only the refunded total + tax.
        $rows = $mode === 'partial' ? [] : array_map(function ($txn) use ($fmt) {
            $product = new MeprProduct($txn->product_id);
            $qty     = (int) $txn->get_meta('_mepr_quantity', true) ?: 1;

            return [
                'name'  => esc_html($product->post_title),
                'qty'   => (int) $qty,
                'total' => $fmt($txn->amount),
            ];
        }, $refunded_txns);

        $refunded_amount = $fmt((float) ($context['refunded_amount'] ?? 0));
        $refunded_tax    = (float) ($context['refunded_tax'] ?? 0) > 0 ? $fmt($context['refunded_tax']) : null;

        return MeprView::get_string('/emails/partials/cart-refund-items-table', get_defined_vars());
    }
}
