<?php

namespace WPAICG\Lib\VectorStores\FileUpload;

use WPAICG\Vector\AIPKit_Vector_Embedding_Batch_Policy;
use WP_Error;

if (!defined('ABSPATH')) {
    exit;
}

require_once WPAICG_PLUGIN_DIR . 'classes/knowledge-base/embedding-batches.php';

/**
 * Paid chunking and embedding batch settings for Knowledge Base ingestion.
 */
class AIPKit_Vector_File_Ingestion_Batch_Settings extends AIPKit_Vector_Embedding_Batch_Policy
{
    public static function apply_chunking_defaults(array $defaults): array
    {
        $settings = get_option(self::option_name(), []);
        foreach (array_keys($defaults) as $key) {
            if (isset($settings['chunk_' . $key])) {
                $defaults[$key] = (int) $settings['chunk_' . $key];
            }
        }
        return $defaults;
    }

    public static function saved_batch_size(array $config): int
    {
        $settings = get_option(self::option_name(), []);
        $settings = is_array($settings) ? $settings : [];
        return isset($settings[$config['key']]) ? (int) $settings[$config['key']] : (int) $config['default'];
    }

    /** @return bool|WP_Error */
    public static function apply_payload_to_general_settings(array &$general_settings, array $settings, bool $is_pro)
    {
        if (!self::has_payload_keys($settings) || !$is_pro) {
            return false;
        }

        $dirty = false;
        foreach (self::provider_configs() as $provider => $config) {
            $key = $config['key'];
            if (!array_key_exists($key, $settings)) {
                continue;
            }

            $value = (int) $settings[$key];
            if ($value < self::min_batch_size() || $value > (int) $config['max']) {
                return new \WP_Error(
                    'invalid_embedding_batch_size_' . $provider,
                    sprintf(
                        /* translators: 1: Provider name, 2: Minimum batch size, 3: Maximum batch size. */
                        __('%1$s embedding batch size must be between %2$d and %3$d.', 'gpt3-ai-content-generator'),
                        $config['label'],
                        self::min_batch_size(),
                        (int) $config['max']
                    )
                );
            }

            $general_settings[$key] = $value;
            $dirty = true;
        }

        return $dirty;
    }

    /** @return bool|WP_Error */
    public static function apply_chunking_settings(array &$general_settings, array $settings)
    {
        $general_dirty = false;
        $avg = isset($settings['chunk_avg_chars_per_token']) ? (int)$settings['chunk_avg_chars_per_token'] : null;
        $max = isset($settings['chunk_max_tokens_per_chunk']) ? (int)$settings['chunk_max_tokens_per_chunk'] : null;
        $ovl = isset($settings['chunk_overlap_tokens']) ? (int)$settings['chunk_overlap_tokens'] : null;
        $effective_max = $max !== null ? $max : (int)($general_settings['chunk_max_tokens_per_chunk'] ?? 3000);
        $effective_overlap = $ovl !== null ? $ovl : (int)($general_settings['chunk_overlap_tokens'] ?? 150);

        // Validate ranges
        if ($avg !== null) {
            if ($avg < 2 || $avg > 4) {
                return new \WP_Error('invalid_chunk_avg', __('Average chars per token must be between 2 and 4.', 'gpt3-ai-content-generator'));
            }
            $general_settings['chunk_avg_chars_per_token'] = $avg;
            $general_dirty = true;
        }
        if ($max !== null) {
            if ($max < 256 || $max > 6000) {
                return new \WP_Error('invalid_chunk_max', __('Max tokens per chunk must be between 256 and 6000.', 'gpt3-ai-content-generator'));
            }
            $general_settings['chunk_max_tokens_per_chunk'] = $max;
            $general_dirty = true;
        }
        if ($ovl !== null) {
            if ($ovl < 0 || $ovl > 1000) {
                return new \WP_Error('invalid_chunk_overlap', __('Overlap tokens must be between 0 and 1000.', 'gpt3-ai-content-generator'));
            }
            $general_settings['chunk_overlap_tokens'] = $ovl;
            $general_dirty = true;
        }
        if ($effective_overlap >= $effective_max) {
            return new \WP_Error('invalid_chunk_overlap_ratio', __('Overlap tokens must be lower than max tokens per chunk.', 'gpt3-ai-content-generator'));
        }

        return $general_dirty;
    }

    /** @return bool|WP_Error */
    public static function apply_openai_chunking_settings(array &$general_settings, array $settings)
    {
        $general_dirty = false;
        $mode = isset($settings['openai_file_search_chunking_mode']) ? sanitize_key((string) $settings['openai_file_search_chunking_mode']) : null;
        $max = isset($settings['openai_file_search_max_chunk_size_tokens']) ? (int) $settings['openai_file_search_max_chunk_size_tokens'] : null;
        $ovl = isset($settings['openai_file_search_chunk_overlap_tokens']) ? (int) $settings['openai_file_search_chunk_overlap_tokens'] : null;
        $effective_max = $max !== null ? $max : (int) ($general_settings['openai_file_search_max_chunk_size_tokens'] ?? 800);
        $effective_overlap = $ovl !== null ? $ovl : (int) ($general_settings['openai_file_search_chunk_overlap_tokens'] ?? 400);

        if ($mode !== null) {
            if (!in_array($mode, ['auto', 'custom'], true)) {
                return new \WP_Error('invalid_openai_file_search_chunking_mode', __('OpenAI File Search chunking must be Auto or Custom.', 'gpt3-ai-content-generator'));
            }
            $general_settings['openai_file_search_chunking_mode'] = $mode;
            $general_dirty = true;
        }
        if ($max !== null) {
            if ($max < 100 || $max > 4096) {
                return new \WP_Error('invalid_openai_file_search_chunk_max', __('OpenAI File Search max tokens must be between 100 and 4096.', 'gpt3-ai-content-generator'));
            }
            $general_settings['openai_file_search_max_chunk_size_tokens'] = $max;
            $general_dirty = true;
        }
        if ($ovl !== null) {
            if ($ovl < 0) {
                return new \WP_Error('invalid_openai_file_search_chunk_overlap', __('OpenAI File Search overlap tokens must be 0 or higher.', 'gpt3-ai-content-generator'));
            }
            $general_settings['openai_file_search_chunk_overlap_tokens'] = $ovl;
            $general_dirty = true;
        }
        if ($effective_overlap > (int) floor($effective_max / 2)) {
            return new \WP_Error('invalid_openai_file_search_chunk_overlap_ratio', __('OpenAI File Search overlap cannot exceed half of max tokens per chunk.', 'gpt3-ai-content-generator'));
        }

        return $general_dirty;
    }
}
