<?php

namespace BitApps\IntegrationsPro\Actions\FollowUpBoss;

use BitApps\IntegrationsPro\Actions\FollowUpBoss\Services\ActionPlanService;
use BitApps\IntegrationsPro\Actions\FollowUpBoss\Services\AppointmentOutcomeService;
use BitApps\IntegrationsPro\Actions\FollowUpBoss\Services\AppointmentService;
use BitApps\IntegrationsPro\Actions\FollowUpBoss\Services\AppointmentTypeService;
use BitApps\IntegrationsPro\Actions\FollowUpBoss\Services\CallService;
use BitApps\IntegrationsPro\Actions\FollowUpBoss\Services\CustomFieldService;
use BitApps\IntegrationsPro\Actions\FollowUpBoss\Services\DealCustomFieldService;
use BitApps\IntegrationsPro\Actions\FollowUpBoss\Services\DealService;
use BitApps\IntegrationsPro\Actions\FollowUpBoss\Services\EmailMarketingService;
use BitApps\IntegrationsPro\Actions\FollowUpBoss\Services\EmailTemplateService;
use BitApps\IntegrationsPro\Actions\FollowUpBoss\Services\EventService;
use BitApps\IntegrationsPro\Actions\FollowUpBoss\Services\GroupService;
use BitApps\IntegrationsPro\Actions\FollowUpBoss\Services\NoteService;
use BitApps\IntegrationsPro\Actions\FollowUpBoss\Services\PersonService;
use BitApps\IntegrationsPro\Actions\FollowUpBoss\Services\PipelineService;
use BitApps\IntegrationsPro\Actions\FollowUpBoss\Services\PondService;
use BitApps\IntegrationsPro\Actions\FollowUpBoss\Services\ReactionService;
use BitApps\IntegrationsPro\Actions\FollowUpBoss\Services\RelationshipService;
use BitApps\IntegrationsPro\Actions\FollowUpBoss\Services\StageService;
use BitApps\IntegrationsPro\Actions\FollowUpBoss\Services\TaskService;
use BitApps\IntegrationsPro\Actions\FollowUpBoss\Services\TeamService;
use BitApps\IntegrationsPro\Actions\FollowUpBoss\Services\TextMessageTemplateService;
use BitApps\IntegrationsPro\Actions\FollowUpBoss\Services\UserService;

final class FollowUpBossService
{
    public static function createPerson($response, $fieldData, $apiClient, $settings)
    {
        return (new PersonService($apiClient, $fieldData, $settings))->createPerson();
    }

    public static function updatePerson($response, $fieldData, $apiClient, $settings)
    {
        return (new PersonService($apiClient, $fieldData, $settings))->updatePerson();
    }

    public static function deletePerson($response, $fieldData, $apiClient)
    {
        return (new PersonService($apiClient, $fieldData))->deletePerson();
    }

    public static function createEvent($response, $fieldData, $apiClient, $settings)
    {
        return (new EventService($apiClient, $fieldData, $settings))->createEvent();
    }

    public static function createRelationship($response, $fieldData, $apiClient)
    {
        return (new RelationshipService($apiClient, $fieldData))->createRelationship();
    }

    public static function updateRelationship($response, $fieldData, $apiClient)
    {
        return (new RelationshipService($apiClient, $fieldData))->updateRelationship();
    }

    public static function deleteRelationship($response, $fieldData, $apiClient)
    {
        return (new RelationshipService($apiClient, $fieldData))->deleteRelationship();
    }

    public static function createNote($response, $fieldData, $apiClient, $settings)
    {
        return (new NoteService($apiClient, $fieldData, $settings))->createNote();
    }

    public static function updateNote($response, $fieldData, $apiClient, $settings)
    {
        return (new NoteService($apiClient, $fieldData, $settings))->updateNote();
    }

    public static function deleteNote($response, $fieldData, $apiClient)
    {
        return (new NoteService($apiClient, $fieldData))->deleteNote();
    }

    public static function logCall($response, $fieldData, $apiClient, $settings)
    {
        return (new CallService($apiClient, $fieldData, $settings))->logCall();
    }

    public static function updateCall($response, $fieldData, $apiClient, $settings)
    {
        return (new CallService($apiClient, $fieldData, $settings))->updateCall();
    }

    public static function deleteUser($response, $fieldData, $apiClient, $settings)
    {
        return (new UserService($apiClient, $fieldData, $settings))->deleteUser();
    }

    public static function applyActionPlan($response, $fieldData, $apiClient, $settings)
    {
        return (new ActionPlanService($apiClient, $fieldData, $settings))->applyActionPlan();
    }

    public static function updateActionPlanStatus($response, $fieldData, $apiClient, $settings)
    {
        return (new ActionPlanService($apiClient, $fieldData, $settings))->updateActionPlanStatus();
    }

    public static function createEmailTemplate($response, $fieldData, $apiClient, $settings)
    {
        return (new EmailTemplateService($apiClient, $fieldData, $settings))->createEmailTemplate();
    }

    public static function updateEmailTemplate($response, $fieldData, $apiClient, $settings)
    {
        return (new EmailTemplateService($apiClient, $fieldData, $settings))->updateEmailTemplate();
    }

    public static function deleteEmailTemplate($response, $fieldData, $apiClient)
    {
        return (new EmailTemplateService($apiClient, $fieldData))->deleteEmailTemplate();
    }

    public static function createTextMessageTemplate($response, $fieldData, $apiClient, $settings)
    {
        return (new TextMessageTemplateService($apiClient, $fieldData, $settings))->createTextMessageTemplate();
    }

    public static function updateTextMessageTemplate($response, $fieldData, $apiClient, $settings)
    {
        return (new TextMessageTemplateService($apiClient, $fieldData, $settings))->updateTextMessageTemplate();
    }

    public static function deleteTextMessageTemplate($response, $fieldData, $apiClient)
    {
        return (new TextMessageTemplateService($apiClient, $fieldData))->deleteTextMessageTemplate();
    }

    public static function logEmailMarketingEvent($response, $fieldData, $apiClient, $settings)
    {
        return (new EmailMarketingService($apiClient, $fieldData, $settings))->logEmailMarketingEvent();
    }

    public static function createEmailCampaign($response, $fieldData, $apiClient)
    {
        return (new EmailMarketingService($apiClient, $fieldData))->createEmailCampaign();
    }

    public static function updateEmailCampaign($response, $fieldData, $apiClient)
    {
        return (new EmailMarketingService($apiClient, $fieldData))->updateEmailCampaign();
    }

    public static function createCustomField($response, $fieldData, $apiClient, $settings)
    {
        return (new CustomFieldService($apiClient, $fieldData, $settings))->createCustomField();
    }

    public static function updateCustomField($response, $fieldData, $apiClient, $settings)
    {
        return (new CustomFieldService($apiClient, $fieldData, $settings))->updateCustomField();
    }

    public static function deleteCustomField($response, $fieldData, $apiClient)
    {
        return (new CustomFieldService($apiClient, $fieldData))->deleteCustomField();
    }

    public static function createStage($response, $fieldData, $apiClient)
    {
        return (new StageService($apiClient, $fieldData))->createStage();
    }

    public static function updateStage($response, $fieldData, $apiClient)
    {
        return (new StageService($apiClient, $fieldData))->updateStage();
    }

    public static function deleteStage($response, $fieldData, $apiClient, $settings)
    {
        return (new StageService($apiClient, $fieldData, $settings))->deleteStage();
    }

    public static function createTask($response, $fieldData, $apiClient, $settings)
    {
        return (new TaskService($apiClient, $fieldData, $settings))->createTask();
    }

    public static function updateTask($response, $fieldData, $apiClient, $settings)
    {
        return (new TaskService($apiClient, $fieldData, $settings))->updateTask();
    }

    public static function deleteTask($response, $fieldData, $apiClient)
    {
        return (new TaskService($apiClient, $fieldData))->deleteTask();
    }

    public static function createAppointment($response, $fieldData, $apiClient, $settings)
    {
        return (new AppointmentService($apiClient, $fieldData, $settings))->createAppointment();
    }

    public static function updateAppointment($response, $fieldData, $apiClient, $settings)
    {
        return (new AppointmentService($apiClient, $fieldData, $settings))->updateAppointment();
    }

    public static function deleteAppointment($response, $fieldData, $apiClient)
    {
        return (new AppointmentService($apiClient, $fieldData))->deleteAppointment();
    }

    public static function createAppointmentType($response, $fieldData, $apiClient)
    {
        return (new AppointmentTypeService($apiClient, $fieldData))->createAppointmentType();
    }

    public static function updateAppointmentType($response, $fieldData, $apiClient)
    {
        return (new AppointmentTypeService($apiClient, $fieldData))->updateAppointmentType();
    }

    public static function deleteAppointmentType($response, $fieldData, $apiClient, $settings)
    {
        return (new AppointmentTypeService($apiClient, $fieldData, $settings))->deleteAppointmentType();
    }

    public static function createAppointmentOutcome($response, $fieldData, $apiClient)
    {
        return (new AppointmentOutcomeService($apiClient, $fieldData))->createAppointmentOutcome();
    }

    public static function updateAppointmentOutcome($response, $fieldData, $apiClient)
    {
        return (new AppointmentOutcomeService($apiClient, $fieldData))->updateAppointmentOutcome();
    }

    public static function deleteAppointmentOutcome($response, $fieldData, $apiClient, $settings)
    {
        return (new AppointmentOutcomeService($apiClient, $fieldData, $settings))->deleteAppointmentOutcome();
    }

    public static function createPipeline($response, $fieldData, $apiClient)
    {
        return (new PipelineService($apiClient, $fieldData))->createPipeline();
    }

    public static function updatePipeline($response, $fieldData, $apiClient)
    {
        return (new PipelineService($apiClient, $fieldData))->updatePipeline();
    }

    public static function deletePipeline($response, $fieldData, $apiClient)
    {
        return (new PipelineService($apiClient, $fieldData))->deletePipeline();
    }

    public static function createDeal($response, $fieldData, $apiClient, $settings)
    {
        return (new DealService($apiClient, $fieldData, $settings))->createDeal();
    }

    public static function updateDeal($response, $fieldData, $apiClient, $settings)
    {
        return (new DealService($apiClient, $fieldData, $settings))->updateDeal();
    }

    public static function deleteDeal($response, $fieldData, $apiClient)
    {
        return (new DealService($apiClient, $fieldData))->deleteDeal();
    }

    public static function createDealCustomField($response, $fieldData, $apiClient, $settings)
    {
        return (new DealCustomFieldService($apiClient, $fieldData, $settings))->createDealCustomField();
    }

    public static function updateDealCustomField($response, $fieldData, $apiClient, $settings)
    {
        return (new DealCustomFieldService($apiClient, $fieldData, $settings))->updateDealCustomField();
    }

    public static function deleteDealCustomField($response, $fieldData, $apiClient)
    {
        return (new DealCustomFieldService($apiClient, $fieldData))->deleteDealCustomField();
    }

    public static function createGroup($response, $fieldData, $apiClient, $settings)
    {
        return (new GroupService($apiClient, $fieldData, $settings))->createGroup();
    }

    public static function updateGroup($response, $fieldData, $apiClient, $settings)
    {
        return (new GroupService($apiClient, $fieldData, $settings))->updateGroup();
    }

    public static function deleteGroup($response, $fieldData, $apiClient)
    {
        return (new GroupService($apiClient, $fieldData))->deleteGroup();
    }

    public static function createTeam($response, $fieldData, $apiClient, $settings)
    {
        return (new TeamService($apiClient, $fieldData, $settings))->createTeam();
    }

    public static function updateTeam($response, $fieldData, $apiClient, $settings)
    {
        return (new TeamService($apiClient, $fieldData, $settings))->updateTeam();
    }

    public static function deleteTeam($response, $fieldData, $apiClient, $settings)
    {
        return (new TeamService($apiClient, $fieldData, $settings))->deleteTeam();
    }

    public static function createPond($response, $fieldData, $apiClient, $settings)
    {
        return (new PondService($apiClient, $fieldData, $settings))->createPond();
    }

    public static function updatePond($response, $fieldData, $apiClient, $settings)
    {
        return (new PondService($apiClient, $fieldData, $settings))->updatePond();
    }

    public static function deletePond($response, $fieldData, $apiClient, $settings)
    {
        return (new PondService($apiClient, $fieldData, $settings))->deletePond();
    }

    public static function addReaction($response, $fieldData, $apiClient, $settings)
    {
        return (new ReactionService($apiClient, $fieldData, $settings))->addReaction();
    }

    public static function removeReaction($response, $fieldData, $apiClient, $settings)
    {
        return (new ReactionService($apiClient, $fieldData, $settings))->removeReaction();
    }
}
