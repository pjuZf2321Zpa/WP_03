<?php

namespace FluentCartPro\App\Modules\Promotional\OrderBump;

/**
 * Thrown when a change cannot get its lock, so the caller can ask the admin to try again.
 */
class RegistryBusyException extends \RuntimeException
{
}
