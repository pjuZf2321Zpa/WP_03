<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Actions\Booknetic\BookneticService;
use BitApps\IntegrationsPro\Config;
use BitApps\IntegrationsPro\Core\Util\Hooks;

Hooks::filter(Config::withFreePrefix('booknetic_create_appointment'), [BookneticService::class, 'createAppointment'], 10, 4);
Hooks::filter(Config::withFreePrefix('booknetic_update_appointment'), [BookneticService::class, 'updateAppointment'], 10, 3);
Hooks::filter(Config::withFreePrefix('booknetic_delete_appointment'), [BookneticService::class, 'deleteAppointment'], 10, 2);
Hooks::filter(Config::withFreePrefix('booknetic_reschedule_appointment'), [BookneticService::class, 'rescheduleAppointment'], 10, 3);
Hooks::filter(Config::withFreePrefix('booknetic_change_appointment_status'), [BookneticService::class, 'changeAppointmentStatus'], 10, 3);
Hooks::filter(Config::withFreePrefix('booknetic_update_payment'), [BookneticService::class, 'updatePayment'], 10, 3);
Hooks::filter(Config::withFreePrefix('booknetic_complete_payment'), [BookneticService::class, 'completePayment'], 10, 2);
Hooks::filter(Config::withFreePrefix('booknetic_create_customer'), [BookneticService::class, 'createCustomer'], 10, 3);
Hooks::filter(Config::withFreePrefix('booknetic_update_customer'), [BookneticService::class, 'updateCustomer'], 10, 3);
Hooks::filter(Config::withFreePrefix('booknetic_delete_customer'), [BookneticService::class, 'deleteCustomer'], 10, 2);
Hooks::filter(Config::withFreePrefix('booknetic_assign_customer_category'), [BookneticService::class, 'assignCustomerCategory'], 10, 3);
Hooks::filter(Config::withFreePrefix('booknetic_create_staff'), [BookneticService::class, 'createStaff'], 10, 4);
Hooks::filter(Config::withFreePrefix('booknetic_update_staff'), [BookneticService::class, 'updateStaff'], 10, 3);
Hooks::filter(Config::withFreePrefix('booknetic_delete_staff'), [BookneticService::class, 'deleteStaff'], 10, 2);
Hooks::filter(Config::withFreePrefix('booknetic_duplicate_staff'), [BookneticService::class, 'duplicateStaff'], 10, 2);
Hooks::filter(Config::withFreePrefix('booknetic_set_staff_status'), [BookneticService::class, 'setStaffStatus'], 10, 3);
Hooks::filter(Config::withFreePrefix('booknetic_create_location'), [BookneticService::class, 'createLocation'], 10, 3);
Hooks::filter(Config::withFreePrefix('booknetic_update_location'), [BookneticService::class, 'updateLocation'], 10, 3);
Hooks::filter(Config::withFreePrefix('booknetic_delete_location'), [BookneticService::class, 'deleteLocation'], 10, 2);
Hooks::filter(Config::withFreePrefix('booknetic_duplicate_location'), [BookneticService::class, 'duplicateLocation'], 10, 2);
Hooks::filter(Config::withFreePrefix('booknetic_set_location_status'), [BookneticService::class, 'setLocationStatus'], 10, 3);
Hooks::filter(Config::withFreePrefix('booknetic_create_service'), [BookneticService::class, 'createService'], 10, 4);
Hooks::filter(Config::withFreePrefix('booknetic_update_service'), [BookneticService::class, 'updateService'], 10, 3);
Hooks::filter(Config::withFreePrefix('booknetic_delete_service'), [BookneticService::class, 'deleteService'], 10, 2);
Hooks::filter(Config::withFreePrefix('booknetic_duplicate_service'), [BookneticService::class, 'duplicateService'], 10, 2);
Hooks::filter(Config::withFreePrefix('booknetic_set_service_status'), [BookneticService::class, 'setServiceStatus'], 10, 3);
Hooks::filter(Config::withFreePrefix('booknetic_create_service_extra'), [BookneticService::class, 'createServiceExtra'], 10, 3);
Hooks::filter(Config::withFreePrefix('booknetic_update_service_extra'), [BookneticService::class, 'updateServiceExtra'], 10, 3);
Hooks::filter(Config::withFreePrefix('booknetic_delete_service_extra'), [BookneticService::class, 'deleteServiceExtra'], 10, 2);
Hooks::filter(Config::withFreePrefix('booknetic_duplicate_service_extra'), [BookneticService::class, 'duplicateServiceExtra'], 10, 3);
Hooks::filter(Config::withFreePrefix('booknetic_create_customer_category'), [BookneticService::class, 'createCustomerCategory'], 10, 3);
Hooks::filter(Config::withFreePrefix('booknetic_update_customer_category'), [BookneticService::class, 'updateCustomerCategory'], 10, 3);
Hooks::filter(Config::withFreePrefix('booknetic_delete_customer_category'), [BookneticService::class, 'deleteCustomerCategory'], 10, 2);
Hooks::filter(Config::withFreePrefix('booknetic_create_location_category'), [BookneticService::class, 'createLocationCategory'], 10, 2);
Hooks::filter(Config::withFreePrefix('booknetic_update_location_category'), [BookneticService::class, 'updateLocationCategory'], 10, 2);
Hooks::filter(Config::withFreePrefix('booknetic_delete_location_category'), [BookneticService::class, 'deleteLocationCategory'], 10, 2);
Hooks::filter(Config::withFreePrefix('booknetic_create_service_category'), [BookneticService::class, 'createServiceCategory'], 10, 3);
Hooks::filter(Config::withFreePrefix('booknetic_update_service_category'), [BookneticService::class, 'updateServiceCategory'], 10, 3);
Hooks::filter(Config::withFreePrefix('booknetic_delete_service_category'), [BookneticService::class, 'deleteServiceCategory'], 10, 2);
Hooks::filter(Config::withFreePrefix('booknetic_create_in_app_notification'), [BookneticService::class, 'createInAppNotification'], 10, 3);
