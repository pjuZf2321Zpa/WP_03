<?php

namespace WPAICG\Lib\VectorStores\FileUpload;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Sends queued-upload results after provider-specific validation and processing.
 * Pinecone also strips non-array log data; Qdrant and Chroma retain it.
 *
 * @param object $handler_instance Provider AJAX handler.
 * @param array|\WP_Error $result Ingestion result.
 */
function send_upload_result($handler_instance, $result, bool $strip_non_array_log_data = false): void
{
    if (is_wp_error($result)) {
        $data = $result->get_error_data();
        if (is_array($data) && isset($data['log_data'])) {
            $handler_instance->_log_vector_data_source_entry($data['log_data']);
        }
        $handler_instance->send_wp_error($result);
        return;
    }

    if (isset($result['log_data']) && is_array($result['log_data'])) {
        $handler_instance->_log_vector_data_source_entry($result['log_data']);
        unset($result['log_data']);
    }
    if ($strip_non_array_log_data) {
        unset($result['log_data']);
    }
    wp_send_json_success($result);
}

namespace WPAICG\Lib\VectorStores\FileUpload\Pinecone;

use WP_Error;
use WPAICG\Vector\AIPKit_Vector_Store_Manager;
use WPAICG\Core\AIPKit_AI_Caller;
use WPAICG\Dashboard\Ajax\AIPKit_Vector_Store_Pinecone_Ajax_Handler;
use WPAICG\Lib\VectorStores\FileUpload\AIPKit_Vector_File_Ingestion_Job;



/**
 * Handles the logic for ajax_upload_file_and_upsert_to_pinecone.
 * This file is intended to be conditionally included by the AJAX handler if Pro.
 *
 * @param AIPKit_Vector_Store_Manager $vector_store_manager
 * @param AIPKit_AI_Caller $ai_caller
 * @param array $pinecone_config
 * @param AIPKit_Vector_Store_Pinecone_Ajax_Handler $handler_instance The AJAX handler instance for logging.
 * @return array|WP_Error An array including data for logging by the caller, or WP_Error.
 */
function _aipkit_pinecone_ajax_upload_file_and_upsert_logic(
    AIPKit_Vector_Store_Manager $vector_store_manager,
    AIPKit_AI_Caller $ai_caller,
    array $pinecone_config,
    AIPKit_Vector_Store_Pinecone_Ajax_Handler $handler_instance
) {
    $job_class_path = WPAICG_LIB_DIR . 'knowledge-base/file-ingestion.php';
    if (!class_exists(AIPKit_Vector_File_Ingestion_Job::class) && file_exists($job_class_path)) {
        require_once $job_class_path;
    }
    if (!class_exists(AIPKit_Vector_File_Ingestion_Job::class)) {
        return new WP_Error('vector_file_ingestion_job_missing_pinecone', __('File ingestion job component is missing.', 'gpt3-ai-content-generator'), ['status' => 500]);
    }

    $log_callback = [$handler_instance, '_log_vector_data_source_entry'];

    // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce is checked by the calling handler method.
    if (!empty($_POST['job_id'])) {
        // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce is checked by the calling handler method.
        $job_id = sanitize_text_field(wp_unslash($_POST['job_id']));
        return AIPKit_Vector_File_Ingestion_Job::process_job(
            $job_id,
            $vector_store_manager,
            $ai_caller,
            $pinecone_config,
            $log_callback
        );
    }

    // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce is checked by the calling handler method.
    $target_index_name = isset($_POST['index_name']) ? sanitize_text_field(wp_unslash($_POST['index_name'])) : '';
    // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce is checked by the calling handler method.
    $embedding_provider_key = isset($_POST['embedding_provider']) ? sanitize_key($_POST['embedding_provider']) : '';
    // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce is checked by the calling handler method.
    $embedding_model = isset($_POST['embedding_model']) ? sanitize_text_field(wp_unslash($_POST['embedding_model'])) : '';

    if (empty($target_index_name)) {
        return new WP_Error('missing_target_store_pinecone_upload_lib', __('Target Pinecone index is required.', 'gpt3-ai-content-generator'), ['status' => 400]);
    }
    // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce is checked by the calling handler method.
    if (!isset($_FILES['file_to_upload'])) {
        return new WP_Error('no_file_pinecone_upload_lib', __('No file provided for Pinecone upload.', 'gpt3-ai-content-generator'), ['status' => 400]);
    }
    if (empty($embedding_provider_key) || empty($embedding_model)) {
        return new WP_Error('missing_embedding_config_pinecone_lib', __('Embedding provider and model are required.', 'gpt3-ai-content-generator'), ['status' => 400]);
    }

    // phpcs:ignore WordPress.Security.NonceVerification.Missing, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Nonce checked in handler; file data is validated by AIPKit_Upload_Utils::validate_upload_file().
    $file_data = $_FILES['file_to_upload'];
    // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce is checked by the calling handler method.
    $source_context = isset($_POST['source_context']) ? sanitize_key(wp_unslash($_POST['source_context'])) : 'sources_module_file_upload';

    return AIPKit_Vector_File_Ingestion_Job::create_from_uploaded_file([
        'provider' => 'pinecone',
        'target_id' => $target_index_name,
        'embedding_provider_key' => $embedding_provider_key,
        'embedding_model' => $embedding_model,
        'file_data' => $file_data,
        'context' => $source_context === 'chatbot_settings_file_upload' ? 'chatbot_settings' : 'admin',
        'user_id' => get_current_user_id(),
        'log_callback' => $log_callback,
    ]);
}

/**
 * Runs the paid upload action after the shared entry point checks access and plan.
 */
function dispatch_upload_action(AIPKit_Vector_Store_Pinecone_Ajax_Handler $handler_instance): void
{
    $pinecone_config = $handler_instance->_get_pinecone_config();
    if (is_wp_error($pinecone_config)) {
        $handler_instance->send_wp_error($pinecone_config);
        return;
    }

    $result = _aipkit_pinecone_ajax_upload_file_and_upsert_logic(
        $handler_instance->get_vector_store_manager(),
        $handler_instance->get_ai_caller(),
        $pinecone_config,
        $handler_instance
    );
    \WPAICG\Lib\VectorStores\FileUpload\send_upload_result($handler_instance, $result, true);
}

namespace WPAICG\Lib\VectorStores\FileUpload\Qdrant;

use WP_Error;
use WPAICG\Vector\AIPKit_Vector_Store_Manager;
use WPAICG\Core\AIPKit_AI_Caller;
use WPAICG\Dashboard\Ajax\AIPKit_Vector_Store_Qdrant_Ajax_Handler;
use WPAICG\Lib\VectorStores\FileUpload\AIPKit_Vector_File_Ingestion_Job;



/**
 * Handles the logic for ajax_upload_file_and_upsert_to_qdrant.
 * This file is intended to be conditionally included by the AJAX handler if Pro.
 *
 * @param AIPKit_Vector_Store_Manager $vector_store_manager
 * @param AIPKit_AI_Caller $ai_caller
 * @param array $qdrant_config
 * @param AIPKit_Vector_Store_Qdrant_Ajax_Handler $handler_instance The AJAX handler instance for logging.
 * @return array|WP_Error An array including data for logging by the caller, or WP_Error.
 */
function _aipkit_qdrant_ajax_upload_file_and_upsert_logic(
    AIPKit_Vector_Store_Manager $vector_store_manager,
    AIPKit_AI_Caller $ai_caller,
    array $qdrant_config,
    AIPKit_Vector_Store_Qdrant_Ajax_Handler $handler_instance
) {
    $job_class_path = WPAICG_LIB_DIR . 'knowledge-base/file-ingestion.php';
    if (!class_exists(AIPKit_Vector_File_Ingestion_Job::class) && file_exists($job_class_path)) {
        require_once $job_class_path;
    }
    if (!class_exists(AIPKit_Vector_File_Ingestion_Job::class)) {
        return new WP_Error('vector_file_ingestion_job_missing_qdrant', __('File ingestion job component is missing.', 'gpt3-ai-content-generator'), ['status' => 500]);
    }

    $log_callback = [$handler_instance, '_log_vector_data_source_entry'];

    // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce is checked by the calling handler method.
    if (!empty($_POST['job_id'])) {
        // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce is checked by the calling handler method.
        $job_id = sanitize_text_field(wp_unslash($_POST['job_id']));
        return AIPKit_Vector_File_Ingestion_Job::process_job(
            $job_id,
            $vector_store_manager,
            $ai_caller,
            $qdrant_config,
            $log_callback
        );
    }

    // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce is checked by the calling handler method.
    $target_collection_name = isset($_POST['target_store_id']) ? sanitize_text_field(wp_unslash($_POST['target_store_id'])) : '';
    // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce is checked by the calling handler method.
    $embedding_provider_key = isset($_POST['embedding_provider']) ? sanitize_key($_POST['embedding_provider']) : '';
    // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce is checked by the calling handler method.
    $embedding_model = isset($_POST['embedding_model']) ? sanitize_text_field(wp_unslash($_POST['embedding_model'])) : '';

    if (empty($target_collection_name)) {
        return new WP_Error('missing_target_collection_qdrant_lib', __('Target Qdrant collection name is required.', 'gpt3-ai-content-generator'), ['status' => 400]);
    }
    // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce is checked by the calling handler method.
    if (!isset($_FILES['file_to_upload'])) {
        return new WP_Error('no_file_qdrant_upload_lib', __('No file provided for Qdrant upload.', 'gpt3-ai-content-generator'), ['status' => 400]);
    }
    if (empty($embedding_provider_key) || empty($embedding_model)) {
        return new WP_Error('missing_embedding_config_qdrant_lib', __('Embedding provider and model are required for Qdrant.', 'gpt3-ai-content-generator'), ['status' => 400]);
    }

    // phpcs:ignore WordPress.Security.NonceVerification.Missing, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Nonce checked in handler; file data is validated by AIPKit_Upload_Utils::validate_upload_file().
    $file_data = $_FILES['file_to_upload'];
    // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce is checked by the calling handler method.
    $source_context = isset($_POST['source_context']) ? sanitize_key(wp_unslash($_POST['source_context'])) : 'sources_module_file_upload';

    return AIPKit_Vector_File_Ingestion_Job::create_from_uploaded_file([
        'provider' => 'qdrant',
        'target_id' => $target_collection_name,
        'embedding_provider_key' => $embedding_provider_key,
        'embedding_model' => $embedding_model,
        'file_data' => $file_data,
        'context' => $source_context === 'chatbot_settings_file_upload' ? 'chatbot_settings' : 'admin',
        'user_id' => get_current_user_id(),
        'log_callback' => $log_callback,
    ]);
}

/**
 * Runs the paid upload action after the shared entry point checks access and plan.
 */
function dispatch_upload_action(AIPKit_Vector_Store_Qdrant_Ajax_Handler $handler_instance): void
{
    $qdrant_config = $handler_instance->_get_qdrant_config();
    if (is_wp_error($qdrant_config)) {
        $handler_instance->send_wp_error($qdrant_config);
        return;
    }

    $result = _aipkit_qdrant_ajax_upload_file_and_upsert_logic(
        $handler_instance->get_vector_store_manager(),
        $handler_instance->get_ai_caller(),
        $qdrant_config,
        $handler_instance
    );

    \WPAICG\Lib\VectorStores\FileUpload\send_upload_result($handler_instance, $result);
}

namespace WPAICG\Lib\VectorStores\FileUpload\Chroma;

use WP_Error;
use WPAICG\Core\AIPKit_AI_Caller;
use WPAICG\Dashboard\Ajax\AIPKit_Vector_Store_Chroma_Ajax_Handler;
use WPAICG\Lib\VectorStores\FileUpload\AIPKit_Vector_File_Ingestion_Job;
use WPAICG\Vector\AIPKit_Vector_Store_Manager;



/**
 * Handles the logic for ajax_upload_file_and_upsert_to_chroma.
 *
 * @param AIPKit_Vector_Store_Manager $vector_store_manager
 * @param AIPKit_AI_Caller $ai_caller
 * @param array<string,mixed> $chroma_config
 * @param AIPKit_Vector_Store_Chroma_Ajax_Handler $handler_instance
 * @return array<string,mixed>|WP_Error
 */
function _aipkit_chroma_ajax_upload_file_and_upsert_logic(
    AIPKit_Vector_Store_Manager $vector_store_manager,
    AIPKit_AI_Caller $ai_caller,
    array $chroma_config,
    AIPKit_Vector_Store_Chroma_Ajax_Handler $handler_instance
) {
    $job_class_path = WPAICG_LIB_DIR . 'knowledge-base/file-ingestion.php';
    if (!class_exists(AIPKit_Vector_File_Ingestion_Job::class) && file_exists($job_class_path)) {
        require_once $job_class_path;
    }
    if (!class_exists(AIPKit_Vector_File_Ingestion_Job::class)) {
        return new WP_Error('vector_file_ingestion_job_missing_chroma', __('File ingestion job component is missing.', 'gpt3-ai-content-generator'), ['status' => 500]);
    }

    $log_callback = [$handler_instance, '_log_vector_data_source_entry'];

    // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce is checked by the calling handler method.
    if (!empty($_POST['job_id'])) {
        // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce is checked by the calling handler method.
        $job_id = sanitize_text_field(wp_unslash($_POST['job_id']));
        return AIPKit_Vector_File_Ingestion_Job::process_job(
            $job_id,
            $vector_store_manager,
            $ai_caller,
            $chroma_config,
            $log_callback
        );
    }

    // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce is checked by the calling handler method.
    $target_collection_name = isset($_POST['target_store_id']) ? sanitize_text_field(wp_unslash($_POST['target_store_id'])) : '';
    if ($target_collection_name === '') {
        // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce is checked by the calling handler method.
        $target_collection_name = isset($_POST['collection_name']) ? sanitize_text_field(wp_unslash($_POST['collection_name'])) : '';
    }
    // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce is checked by the calling handler method.
    $embedding_provider_key = isset($_POST['embedding_provider']) ? sanitize_key($_POST['embedding_provider']) : '';
    // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce is checked by the calling handler method.
    $embedding_model = isset($_POST['embedding_model']) ? sanitize_text_field(wp_unslash($_POST['embedding_model'])) : '';

    if ($target_collection_name === '') {
        return new WP_Error('missing_target_collection_chroma_lib', __('Target Chroma collection name is required.', 'gpt3-ai-content-generator'), ['status' => 400]);
    }
    // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce is checked by the calling handler method.
    if (!isset($_FILES['file_to_upload'])) {
        return new WP_Error('no_file_chroma_upload_lib', __('No file provided for Chroma upload.', 'gpt3-ai-content-generator'), ['status' => 400]);
    }
    if ($embedding_provider_key === '' || $embedding_model === '') {
        return new WP_Error('missing_embedding_config_chroma_lib', __('Embedding provider and model are required for Chroma.', 'gpt3-ai-content-generator'), ['status' => 400]);
    }

    // phpcs:ignore WordPress.Security.NonceVerification.Missing, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Nonce checked in handler; file data is validated by AIPKit_Upload_Utils::validate_upload_file().
    $file_data = $_FILES['file_to_upload'];
    // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce is checked by the calling handler method.
    $source_context = isset($_POST['source_context']) ? sanitize_key(wp_unslash($_POST['source_context'])) : 'sources_module_file_upload';

    return AIPKit_Vector_File_Ingestion_Job::create_from_uploaded_file([
        'provider' => 'chroma',
        'target_id' => $target_collection_name,
        'embedding_provider_key' => $embedding_provider_key,
        'embedding_model' => $embedding_model,
        'file_data' => $file_data,
        'context' => $source_context === 'chatbot_settings_file_upload' ? 'chatbot_settings' : 'admin',
        'user_id' => get_current_user_id(),
        'log_callback' => $log_callback,
    ]);
}

/**
 * Runs the paid upload action after the shared entry point checks access and plan.
 */
function dispatch_upload_action(AIPKit_Vector_Store_Chroma_Ajax_Handler $handler_instance): void
{
    $chroma_config = $handler_instance->_get_chroma_config();
    if (is_wp_error($chroma_config)) {
        $handler_instance->send_wp_error($chroma_config);
        return;
    }

    $result = _aipkit_chroma_ajax_upload_file_and_upsert_logic(
        $handler_instance->get_vector_store_manager(),
        $handler_instance->get_ai_caller(),
        $chroma_config,
        $handler_instance
    );

    \WPAICG\Lib\VectorStores\FileUpload\send_upload_result($handler_instance, $result);
}
