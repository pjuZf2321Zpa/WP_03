<?php

defined('ABSPATH') || exit;

class MeprCoursesCtrl extends MeprFeatureAddonCtrl
{
    /**
     * Configure the add-on.
     */
    protected function configure(): void
    {
        $this->slug                = 'memberpress-courses';
        $this->main_file           = 'memberpress-courses/main.php';
        $this->page_title          = __('MemberPress Courses', 'memberpress');
        $this->menu_title          = __('Courses', 'memberpress');
        $this->menu_position       = 11;
        $this->view_path           = '/admin/courses/ui';
        $this->post_activation_url = add_query_arg('post_type', 'mpcs-course', admin_url('edit.php'));
        $this->show_options_tab    = true;
    }
}
