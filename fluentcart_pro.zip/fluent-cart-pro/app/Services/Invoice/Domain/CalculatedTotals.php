<?php

declare(strict_types=1);

namespace FluentCartPro\App\Services\Invoice\Domain;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Engine output DTO. Contains totals and tax breakdown (taxSummaries).
 * BR-CO-16: duePayable = grandTotal - totalPrepaid + rounding.
 */
final class CalculatedTotals
{
    public Money $totalNet;

    public Money $totalVat;

    public Money $grandTotal;

    public Money $totalPrepaid;

    public Money $rounding;

    public Money $duePayable;

    /** @var TaxSummary[] */
    public array $taxSummaries;

    /**
     * @param TaxSummary[] $taxSummaries
     */
    public function __construct(
        Money $totalNet,
        Money $totalVat,
        Money $grandTotal,
        Money $totalPrepaid,
        Money $rounding,
        Money $duePayable,
        array $taxSummaries = []
    ) {
        $this->totalNet     = $totalNet;
        $this->totalVat     = $totalVat;
        $this->grandTotal   = $grandTotal;
        $this->totalPrepaid = $totalPrepaid;
        $this->rounding     = $rounding;
        $this->duePayable   = $duePayable;
        $this->taxSummaries = $taxSummaries;
    }
}
