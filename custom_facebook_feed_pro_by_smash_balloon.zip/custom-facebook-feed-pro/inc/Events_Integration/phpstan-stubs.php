<?php
// phpcs:ignoreFile -- PHPStan stub artifact only; never loaded or executed at runtime (see notes below).

/*
 * Static-analysis stubs for optional third-party event-calendar plugins.
 *
 * These functions belong to The Events Calendar and Sugar Calendar. The Events
 * integration's Target adapters call them only behind is_available() /
 * class_exists() guards, so they are never invoked unless the host plugin is
 * active. They are declared here — guarded by function_exists() and never
 * required at runtime — purely so PHPStan can resolve the symbols when those
 * plugins are absent from the CI environment. This file is not autoloaded and
 * is never included by the plugin.
 *
 * @package CustomFacebookFeed\Events_Integration
 */

if (! function_exists('tribe_create_event')) {
	/**
	 * Stub for The Events Calendar's tribe_create_event().
	 *
	 * @param array $args Event arguments.
	 * @return int Created event post ID (0 on failure).
	 */
	function tribe_create_event($args)
	{
		return 0;
	}
}

if (! function_exists('tribe_update_event')) {
	/**
	 * Stub for The Events Calendar's tribe_update_event().
	 *
	 * @param int   $post_id Event post ID.
	 * @param array $args    Event arguments.
	 * @return int|bool Updated event post ID, or false on failure.
	 */
	function tribe_update_event($post_id, $args)
	{
		return false;
	}
}

if (! function_exists('tribe_delete_event')) {
	/**
	 * Stub for The Events Calendar's tribe_delete_event().
	 *
	 * @param int  $post_id      Event post ID.
	 * @param bool $force_delete Whether to bypass the trash.
	 * @return bool Whether the event was deleted.
	 */
	function tribe_delete_event($post_id, $force_delete = false)
	{
		return false;
	}
}

if (! function_exists('tribe_get_option')) {
	/**
	 * Stub for The Events Calendar's tribe_get_option().
	 *
	 * @param string $option_name   Option key.
	 * @param mixed  $default_value Value returned when the option is unset.
	 * @return mixed Option value.
	 */
	function tribe_get_option($option_name, $default_value = false)
	{
		return $default_value;
	}
}

if (! function_exists('tribe_create_venue')) {
	/**
	 * Stub for The Events Calendar's tribe_create_venue().
	 *
	 * @param array $args Venue arguments.
	 * @return int Created venue post ID (0 on failure).
	 */
	function tribe_create_venue($args)
	{
		return 0;
	}
}

if (! function_exists('sugar_calendar_get_event_post_type_id')) {
	/**
	 * Stub for Sugar Calendar's sugar_calendar_get_event_post_type_id().
	 *
	 * @return string Event post type slug.
	 */
	function sugar_calendar_get_event_post_type_id()
	{
		return '';
	}
}

if (! function_exists('sugar_calendar_get_calendar_taxonomy_id')) {
	/**
	 * Stub for Sugar Calendar's sugar_calendar_get_calendar_taxonomy_id().
	 *
	 * @return string Calendar taxonomy slug.
	 */
	function sugar_calendar_get_calendar_taxonomy_id()
	{
		return '';
	}
}

if (! function_exists('sugar_calendar_add_event')) {
	/**
	 * Stub for Sugar Calendar's sugar_calendar_add_event().
	 *
	 * @param array $data Event data.
	 * @return int Created event ID (0 on failure).
	 */
	function sugar_calendar_add_event($data)
	{
		return 0;
	}
}

if (! function_exists('sugar_calendar_update_event')) {
	/**
	 * Stub for Sugar Calendar's sugar_calendar_update_event().
	 *
	 * @param int   $event_id Event ID.
	 * @param array $data     Event data.
	 * @return bool Whether the event was updated.
	 */
	function sugar_calendar_update_event($event_id, $data)
	{
		return false;
	}
}

if (! function_exists('sugar_calendar_delete_event')) {
	/**
	 * Stub for Sugar Calendar's sugar_calendar_delete_event().
	 *
	 * @param int $event_id Event ID.
	 * @return bool Whether the event was deleted.
	 */
	function sugar_calendar_delete_event($event_id)
	{
		return false;
	}
}

if (! function_exists('sugar_calendar_get_event')) {
	/**
	 * Stub for Sugar Calendar's sugar_calendar_get_event().
	 *
	 * @param int $event_id Event ID.
	 * @return object|null Event object, or null when not found.
	 */
	function sugar_calendar_get_event($event_id)
	{
		return null;
	}
}

if (! function_exists('sugar_calendar_get_event_by_object')) {
	/**
	 * Stub for Sugar Calendar's sugar_calendar_get_event_by_object().
	 *
	 * @param int    $object_id   Related object ID (e.g. a post ID).
	 * @param string $object_type Related object type.
	 * @return object|null Event object, or null when not found.
	 */
	function sugar_calendar_get_event_by_object($object_id, $object_type = 'post')
	{
		return null;
	}
}
