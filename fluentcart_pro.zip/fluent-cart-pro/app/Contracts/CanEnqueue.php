<?php

namespace FluentCartPro\App\Contracts;

use FluentCartPro\App\Utils\Enqueuer\Vite as ProVite;
use FluentCart\Framework\Support\Arr;

/**
 * Pro override for CanEnqueue — uses ProVite instead of free's Vite.
 *
 * Pro email block classes use this trait to enqueue their assets
 * through the pro plugin's Vite pipeline. The base CanEnqueue trait
 * (in the free plugin) handles free/storefront blocks via free's Vite.
 */
trait CanEnqueue
{
    public function enqueue_scripts($localizeData = []): void
    {
        $scripts = $this->getScripts();
        $handlePrefix = $this->getScriptName();
        $isLocalized = false;

        foreach ($scripts as $i => $script) {
            $source = is_array($script) ? Arr::get($script, 'source') : $script;
            $deps = is_array($script) ? Arr::get($script, 'dependencies', []) : [];
            $handle = ($i === 0) ? $handlePrefix : $handlePrefix . '_' . $i;

            $vite = ProVite::enqueueScript($handle, $source, $deps);

            if (!$isLocalized && !empty($localizeData)) {
                $vite->with($localizeData);
                $isLocalized = true;
            }
        }
    }

    public function enqueue_styles(): void
    {
        $styles = $this->getStyles();
        $handlePrefix = $this->getStyleName();

        foreach ($styles as $i => $style) {
            $source = is_array($style) ? Arr::get($style, 'source') : $style;
            $handle = ($i === 0) ? $handlePrefix : $handlePrefix . '_' . $i;

            ProVite::enqueueStyle($handle, $source);
        }
    }
}
