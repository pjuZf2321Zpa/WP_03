<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Core\Util\Route;
use BitApps\IntegrationsPro\Triggers\BookingCalendar\BookingCalendarController;

Route::get('booking-calendar/get', [BookingCalendarController::class, 'getAllTasks']);
