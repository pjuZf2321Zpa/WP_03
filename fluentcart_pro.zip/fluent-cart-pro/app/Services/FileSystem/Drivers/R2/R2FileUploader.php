<?php

namespace FluentCartPro\App\Services\FileSystem\Drivers\R2;

class R2FileUploader
{
    public static function upload(string $accountId, string $secret, string $accessKey, string $bucket, string $localFilePath, string $uploadToFilePath)
    {
        if (!file_exists($localFilePath)) {
            return new \WP_Error('r2_file_not_found', __('File not found for upload.', 'fluent-cart-pro'));
        }

        $region = 'auto';
        $service = 's3';
        $host = $accountId . '.r2.cloudflarestorage.com';
        $content = file_get_contents($localFilePath);
        $payloadHash = hash('sha256', $content);
        $timestamp = gmdate('Ymd\THis\Z');
        $date = gmdate('Ymd');
        $encodedPath = '/' . $bucket . '/' . implode('/', array_map('rawurlencode', explode('/', $uploadToFilePath)));
        $canonicalHeaders = 'host:' . $host . "\n"
            . 'x-amz-content-sha256:' . $payloadHash . "\n"
            . 'x-amz-date:' . $timestamp . "\n";
        $signedHeaders = 'host;x-amz-content-sha256;x-amz-date';
        $canonicalRequest = 'PUT' . "\n" . $encodedPath . "\n\n" . $canonicalHeaders . "\n" . $signedHeaders . "\n" . $payloadHash;
        $credentialScope = $date . '/' . $region . '/' . $service . '/aws4_request';
        $stringToSign = 'AWS4-HMAC-SHA256' . "\n" . $timestamp . "\n" . $credentialScope . "\n" . hash('sha256', $canonicalRequest);
        $kDate = hash_hmac('sha256', $date, 'AWS4' . $secret, true);
        $kRegion = hash_hmac('sha256', $region, $kDate, true);
        $kService = hash_hmac('sha256', $service, $kRegion, true);
        $kSigning = hash_hmac('sha256', 'aws4_request', $kService, true);
        $signature = hash_hmac('sha256', $stringToSign, $kSigning);

        $response = wp_remote_request('https://' . $host . $encodedPath, [
            'method'  => 'PUT',
            'headers' => [
                'Authorization'        => 'AWS4-HMAC-SHA256 Credential=' . $accessKey . '/' . $credentialScope . ', SignedHeaders=' . $signedHeaders . ', Signature=' . $signature,
                'x-amz-date'           => $timestamp,
                'x-amz-content-sha256' => $payloadHash,
                'Content-Type'         => mime_content_type($localFilePath),
            ],
            'body'    => $content,
            'timeout' => 60,
        ]);

        if (is_wp_error($response)) {
            return $response;
        }

        $code = (int) wp_remote_retrieve_response_code($response);
        if ($code >= 200 && $code < 300) {
            return [
                'success' => true,
                'path'    => $uploadToFilePath,
            ];
        }

        return new \WP_Error(
            'r2_upload_failed',
            sprintf(__('Upload failed with code: %s', 'fluent-cart-pro'), $code)
        );
    }
}
