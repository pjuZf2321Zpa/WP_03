<?php

namespace MasterStudy\Lms\Pro\AddonsPlus\Calendar\Routing\Swagger\Routes;

use MasterStudy\Lms\Routing\Swagger\RequestInterface;
use MasterStudy\Lms\Routing\Swagger\ResponseInterface;
use MasterStudy\Lms\Routing\Swagger\Route;

final class Events extends Route implements RequestInterface, ResponseInterface {
	public function request(): array {
		return array_merge(
			( new Summary() )->request(),
			array(
				'page'     => array(
					'type'        => 'integer',
					'description' => 'Page number.',
					'required'    => false,
					'default'     => 1,
				),
				'per_page' => array(
					'type'        => 'integer',
					'description' => 'Events per page.',
					'required'    => false,
					'default'     => 20,
				),
				'search'   => array(
					'type'        => 'string',
					'description' => 'Search query scoped to the selected month.',
					'required'    => false,
				),
				'status'   => array(
					'type'        => 'string',
					'description' => 'Optional event status filter.',
					'required'    => false,
					'enum'        => array( 'upcoming', 'past' ),
				),
			)
		);
	}

	public function response(): array {
		return array(
			'events'     => array(
				'type'        => 'array',
				'description' => 'Calendar events.',
				'items'       => array(
					'type'       => 'object',
					'properties' => EventSchema::properties(),
				),
			),
			'pagination' => array(
				'type'        => 'object',
				'description' => 'Pagination metadata.',
				'properties'  => EventSchema::pagination(),
			),
			'counts'     => array(
				'type'        => 'object',
				'description' => 'Event counts for the current month and search scope.',
				'properties'  => EventSchema::counts(),
			),
		);
	}

	public function get_summary(): string {
		return 'Get Calendar Events';
	}

	public function get_description(): string {
		return 'Returns paginated events for the selected month with optional backend search.';
	}
}
