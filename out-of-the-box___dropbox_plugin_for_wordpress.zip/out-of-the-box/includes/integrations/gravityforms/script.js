(function ($) {
    'use strict';
    var unsubscribeBridge = null;

    /* binding to the load field settings event to initialize */
    $(document).on('gform_load_field_settings', function (event, field, form) {
        jQuery('#field_wpcp_outofthebox').val(field.defaultValue);
        if (field['OutoftheBoxShortcode'] !== undefined && field['OutoftheBoxShortcode'] !== '') {
            jQuery('#field_wpcp_outofthebox').val(field['OutoftheBoxShortcode']);
        }
    });

    /* Shortcode Generator Popup */
    $('.wpcp-shortcodegenerator.outofthebox').on('click', function (e) {
        var raw_content = jQuery('#field_wpcp_outofthebox').val();
        var shortcode = raw_content.replace('</p>', '').replace('<p>', '');
        var query = 'shortcode=' + WPCP_shortcodeEncode(shortcode);
        var instanceId = window.WPCP_Bridge.createInstanceId();
        unsubscribeBridge = window.WPCP_Bridge.subscribe(
            'out-of-the-box',
            'wpcp-shortcode',
            instanceId,
            function (data) {
                if (!data || typeof data.shortcode !== 'string') {
                    return;
                }

                $('#field_wpcp_outofthebox').val(data.shortcode);
                SetFieldProperty('OutoftheBoxShortcode', data.shortcode);
                unsubscribeBridge();
                unsubscribeBridge = null;
                tb_remove();
            }
        );
        tb_show(
            'Upload Configuration',
            ajaxurl +
                '?action=outofthebox-getpopup&' +
                query +
                '&type=modules&foruploadfield=1&callback=uses_listener&wpcp_instance_id=' + encodeURIComponent(instanceId) + '&TB_iframe=true&height=768&width=1024'
        );
    });
})(jQuery);
