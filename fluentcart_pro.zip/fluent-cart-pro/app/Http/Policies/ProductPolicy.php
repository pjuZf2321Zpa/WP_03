<?php

namespace FluentCartPro\App\Http\Policies;

use FluentCart\App\Http\Policies\Policy;
use FluentCart\Framework\Http\Request\Request;

class ProductPolicy extends Policy
{
    public function verifyRequest(Request $request): bool
    {
        return $this->hasRoutePermissions();
    }
}
