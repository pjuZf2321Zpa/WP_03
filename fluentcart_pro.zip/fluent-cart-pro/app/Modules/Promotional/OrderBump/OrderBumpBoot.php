<?php

namespace FluentCartPro\App\Modules\Promotional\OrderBump;

use FluentCart\App\Helpers\Helper;
use FluentCart\App\Services\OrderService;
use FluentCart\App\Vite;
use FluentCart\Framework\Support\Arr;
use FluentCartPro\App\Modules\Promotional\Models\OrderPromotion;


class OrderBumpBoot
{
    const POSITION_HOOKS = [
        'above_customer' => 'fluent_cart/before_customer_details',
        'below_customer' => 'fluent_cart/after_customer_details',
        'above_summary' => 'fluent_cart/before_order_summary',
        'below_summary' => 'fluent_cart/after_order_summary',
        'above_payment' => 'fluent_cart/before_payment_methods',
        'below_payment' => 'fluent_cart/after_payment_methods',
    ];

    // Customer-details and summary hooks only exist in newer core; older core never fires them.
    const FALLBACK_POSITIONS = ['above_customer', 'below_customer', 'above_summary', 'below_summary'];

    protected static $stylePrinted = false;

    // Autoloaded flag: does any active bump opt in to the cart drawer? Cleared on bump save.
    const CART_FLAG_OPTION = 'fluent_cart_pro_bump_in_cart';

    protected static $firedPositions = [];

    protected static $fallbackRendered = [];

    // Active bumps loaded once per cart object, shared by every position renderer.
    protected static $bumpsCart;

    protected static $bumpsCache;

    // Bump lines removed by this request, so checkout can refuse after any earlier step removed one.
    protected $removedBumpCount = 0;

    public function register()
    {
        add_action('fluent_cart/after_order_notes', [$this, 'renderAfterOrderNotes']);

        foreach (self::POSITION_HOOKS as $position => $hook) {
            add_action($hook, function ($data) use ($position) {
                $this->renderPosition($position, $data);
            });
        }

        add_action('fluent_cart/cart_drawer/after_items', [$this, 'renderCartDrawerBumps']);
        add_action('fluent_cart/cart_page/after_items', [$this, 'renderCartPageBumps']);
        add_action('wp_enqueue_scripts', [$this, 'enqueueDrawerScript']);

        add_filter('fluent_cart/apply_order_bump', [$this, 'applyOrderBump'], 10, 2);

        // Before TaxModule (10) and ShippingModule (9) price the cart a bump is about to leave.
        add_action('fluent_cart/cart/cart_data_items_updated', [$this, 'removeUnqualifiedBumps'], 6);
        add_filter('fluent_cart/checkout/revalidate_cart', [$this, 'revalidateAtCheckout'], 10, 2);

        add_action('fluent_cart/loading_app', function () {
            Vite::enqueueScript('fluent_cart_order_bump_scripts', 'order-bump/order-bump.js');
        });
    }

    public function renderAfterOrderNotes($data)
    {
        $this->maybeShowBumps($data);

        // Old core: summary hooks never fire, so show those bumps here instead.
        foreach (self::FALLBACK_POSITIONS as $position) {
            if (empty(self::$firedPositions[$position]) && empty(self::$fallbackRendered[$position])) {
                self::$fallbackRendered[$position] = true;
                $this->maybeShowBumps(array_merge((array)$data, ['position' => $position]));
            }
        }
    }

    public function renderPosition($position, $data)
    {
        if (Arr::get($data, 'context') === 'modal' || empty($data['cart'])) {
            return;
        }

        self::$firedPositions[$position] = true;

        if (!empty(self::$fallbackRendered[$position])) {
            return; // already shown by the after_order_notes fallback
        }

        $this->maybeShowBumps(['cart' => $data['cart'], 'position' => $position]);
    }

    public function renderCartDrawerBumps($data)
    {
        $cart = Arr::get((array)$data, 'cart');
        if (!is_object($cart)) {
            return;
        }

        // An emptied cart shows the empty state only; a bump alone must not start a cart.
        $cartItems = $cart->cart_data;
        if (empty($cartItems) || !self::hasCartBumps()) {
            return;
        }

        $this->maybeShowBumps(['cart' => $cart, 'context' => 'cart_drawer']);
    }

    public function renderCartPageBumps($data)
    {
        $cart = Arr::get((array)$data, 'cart');
        if (!is_object($cart) || empty($cart->cart_data) || !self::hasCartBumps()) {
            return;
        }

        $this->maybeShowBumps(['cart' => $cart, 'context' => 'cart_page']);
    }

    public static function hasCartBumps()
    {
        $flag = get_option(self::CART_FLAG_OPTION, '');

        if ($flag !== 'yes' && $flag !== 'no') {
            $flag = 'no';
            $bumps = OrderPromotion::query()->where('type', 'order_bump')->where('status', 'active')->get();
            foreach ($bumps as $bump) {
                if (Arr::get($bump->config, 'show_in_cart') === 'yes') {
                    $flag = 'yes';
                    break;
                }
            }
            update_option(self::CART_FLAG_OPTION, $flag, true);
        }

        return $flag === 'yes';
    }

    public static function flushCartFlag()
    {
        delete_option(self::CART_FLAG_OPTION);
    }

    // Pages that render the drawer, and the checkout when the active card has an Add button.
    public function enqueueDrawerScript()
    {
        if (!class_exists(\FluentCart\App\Hooks\Cart\CartLoader::class)
            || !method_exists(\FluentCart\App\Hooks\Cart\CartLoader::class, 'shouldHideCartDrawer')
            || !\FluentCart\App\Modules\Templating\AssetLoader::shouldLoadGlobalFrontendAssets()
        ) {
            return;
        }

        if (\FluentCart\App\Hooks\Cart\CartLoader::shouldHideCartDrawer()) {
            if ((int)get_the_ID() === (int)(new \FluentCart\Api\StoreSettings())->getReceiptPageId()
                || strpos($this->activeCard()['content'], 'fluent-cart/order-bump-add-button') === false) {
                return;
            }
        } elseif (!self::hasCartBumps()) {
            return;
        }

        // Pro's own build, so Pro's Vite helper, not core's (core's dev server and manifest lack this file).
        \FluentCartPro\App\Utils\Enqueuer\Vite::enqueueScript('fluent_cart_order_bump_drawer', 'public/order-bump/cart-drawer-bump.js', [], null, true);
    }

    protected function getActiveBumps($cart)
    {
        if (self::$bumpsCart !== $cart) {
            self::$bumpsCart = $cart;

            // Versioned by the group's last change, see OrderPromotion::clearActiveCache().
            $cacheKey = OrderPromotion::ACTIVE_BUMPS_CACHE_KEY . ':' . wp_cache_get_last_changed(OrderPromotion::CACHE_GROUP);
            $rows = wp_cache_get($cacheKey, OrderPromotion::CACHE_GROUP);

            if (!is_array($rows)) {
                // Plain rows, so the cache holds data rather than model objects.
                $rows = OrderPromotion::query()->where('type', 'order_bump')
                    ->where('status', 'active')
                    ->orderBy('priority', 'DESC')
                    ->get()
                    ->map(function (OrderPromotion $bump) {
                        return $bump->getAttributes();
                    })
                    ->all();

                wp_cache_set($cacheKey, $rows, OrderPromotion::CACHE_GROUP, HOUR_IN_SECONDS);
            }

            self::$bumpsCache = OrderPromotion::query()->hydrate($rows);
        }

        return self::$bumpsCache;
    }

    public function maybeShowBumps($data)
    {
        $cart = $data['cart'];
        $context = Arr::get($data, 'context');
        $isPage = $context === 'cart_page';
        $isDrawer = $isPage || $context === 'cart_drawer'; // drawer and page share the card selection
        $position = Arr::get($data, 'position', '');
        if (!isset(self::POSITION_HOOKS[$position])) {
            $position = '';
        }

        // Carts bound to an existing payment (custom payment link, renewal invoice, early
        // installment) or already carrying an upgrade reject new items, so never offer a
        // bump on them. Same predicate the apply_order_bump handler uses.
        if (!$cart->acceptsAdditionalItems()) {
            return;
        }

        $cartData = $cart->cart_data;

        $addedPromotionIds = [];
        $objectIds = [];

        foreach ($cartData as $cartItem) {
            $objectIds[] = $cartItem['object_id'];
            if (isset($cartItem['other_info']['promotion_id'])) {
                $addedPromotionIds[] = $cartItem['other_info']['promotion_id'];
            }
        }

        $bumps = $this->getActiveBumps($cart);

        if ($bumps->isEmpty()) {
            return;
        }

        $formattedBumps = [];

        // Drawer: bumps already in the cart always keep their card (they hold the Remove
        // control); the remaining slots go to the highest-priority unadded ones.
        $idleSlots = PHP_INT_MAX;
        if ($isDrawer) {
            $limit = $isPage
                ? max(1, (int)apply_filters('fluent_cart/order_bump/cart_page_limit', 2))
                : max(1, (int)apply_filters('fluent_cart/order_bump/cart_drawer_limit', 2));
            $addedCount = 0;
            foreach ($bumps as $candidate) {
                if (Arr::get($candidate->config, 'show_in_cart') === 'yes' && in_array($candidate->id, $addedPromotionIds)) {
                    $addedCount++;
                }
            }
            $idleSlots = max(0, $limit - $addedCount);

            // One batch per relation for every opted-in bump, instead of a lazy load per card.
            $optedIn = $bumps->filter(function ($candidate) {
                return Arr::get($candidate->config, 'show_in_cart') === 'yes';
            });
            if ($optedIn->isNotEmpty()) {
                $optedIn->loadMissing(['product_variant.product', 'product_variant.media', 'product_variant.simpleProductGallery']);
            }
        }

        $hasSubscription = $cart->hasSubscription();

        foreach ($bumps as $bump) {
            if ($isDrawer) {
                // Checked before product_variant loads, so opted-out bumps cost nothing.
                if (Arr::get($bump->config, 'show_in_cart') !== 'yes') {
                    continue;
                }
            } else {
                $bumpPosition = Arr::get($bump->config, 'position', '');
                if ($bumpPosition === 'disabled') {
                    continue; // Not offered at checkout; the cart drawer and page still can
                }
                if (!isset(self::POSITION_HOOKS[$bumpPosition])) {
                    $bumpPosition = '';
                }
                if ($bumpPosition !== $position) {
                    continue;
                }
            }

            $isAdded = in_array($bump->id, $addedPromotionIds);
            if (!$isAdded) {
                if (in_array($bump->src_object_id, $objectIds)) {
                    continue; // Skip if the bump item is already in the cart
                }

                if ($idleSlots <= 0) {
                    continue; // Drawer is full; checked before product_variant loads
                }
            }

            // An added subscription bump is the cart's subscription; hiding it would drop its own card.
            if (!$isAdded && $hasSubscription && $bump->product_variant && $bump->product_variant->payment_type === 'subscription') {
                continue; // Skip subscription bumps if the cart has a subscription
            }

            if (count($formattedBumps) >= 5 || !$bump->product_variant) {
                break; // Limit to 5 bumps
            }

            // Conditions gate new offers; an added bump keeps its card so it can still be removed.
            if (!$isAdded && !$this->isConditonsMatched($bump, [
                'cart'       => $cart,
                'object_ids' => $objectIds
            ])) {
                continue;
            }

            $formattedBumps[] = [
                'id'              => $bump->id,
                'title'           => $bump->title,
                'description'     => $bump->description,
                'product_variant' => $bump->product_variant,
                'discount'        => $this->getDiscountAmount($bump),
                'variant_id'      => $bump->src_object_id,
                'is_added'        => $isAdded,
                'image_id'        => (int)Arr::get($bump->config, 'image.id', 0),
            ];

            if (!$isAdded) {
                $idleSlots--;
            }
        }

        if (!$formattedBumps) {
            return;
        }

        $card = $this->activeCard();

        if ($isDrawer) {
            $this->renderDrawerCards($formattedBumps, $isPage ? 'page' : 'drawer', $card);
            return;
        }
        ?>

        <div data-fct_order_bump_wrap class="fct_order_bump_wrap">
            <?php if (!self::$stylePrinted) : self::$stylePrinted = true; ?>
            <style><?php echo $this->activeCardCss(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></style>
            <?php endif; ?>
            <div class="fct_order_promotions_wrap fct_checkout_form_section">
                <div class="fct_form_section_body">
                    <div class="fct_order_promotions">
                        <?php
                        foreach ($formattedBumps as $formattedBump) {
                            echo $this->renderCard($card, $formattedBump); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
                        }
                        ?>

                    </div>
                </div>
            </div>
        </div>

        <?php
    }

    // The active card, as block markup. A card that cannot add and remove the offer falls back to the default.
    protected function activeCard(): array
    {
        $key = OrderBumpSettings::activeTemplate();
        $service = new OrderBumpTemplateService();
        $template = $service->getTemplate($key);
        $content = $template ? $template['content'] : '';

        // A checkbox adds and removes. A button card needs both buttons, or the shopper cannot take the offer out again.
        $hasBothButtons = strpos($content, 'fluent-cart/order-bump-add-button') !== false
            && strpos($content, 'fluent-cart/order-bump-remove-button') !== false;
        if (strpos($content, 'fluent-cart/order-bump-checkbox') === false && !$hasBothButtons) {
            $content = $service->defaultContent($key);
        }

        return ['key' => $key, 'content' => $content];
    }

    // The cart drawer is narrow, so it leaves the description out.
    protected function renderCard(array $card, array $formattedBump, bool $withDescription = true): string
    {
        $postTitle = (string)Arr::get($formattedBump, 'product_variant.product.post_title', '');
        $variationTitle = (string)Arr::get($formattedBump, 'product_variant.variation_title', '');

        $values = $this->getPriceParts($formattedBump) + [
            'title'           => $formattedBump['title'],
            'product_title'   => $postTitle,
            'variation_title' => ($variationTitle !== '' && $variationTitle !== $postTitle) ? wp_strip_all_tags($variationTitle) : '',
            'image'           => $this->getBumpImageUrl($formattedBump),
            'description'     => $withDescription ? (string)$formattedBump['description'] : '',
        ];

        return OrderBumpTemplateRenderer::render($card['content'], $values, [
            'id'            => (int)$formattedBump['id'],
            'is_added'      => !empty($formattedBump['is_added']),
            'product_title' => $postTitle,
        ]);
    }

    // The editor's own font-size and spacing choices (Small, Medium, ...) exist only in the editor,
    // so the shop needs their variables and classes to show what was picked.
    protected function presetCss(): string
    {
        $presets = \FluentCart\App\Services\Email\BlockEditorHelper::getStyleDefaults();
        $variables = '';
        $classes = '';

        foreach ($presets['font-size'] as $preset) {
            $variables .= '--wp--preset--font-size--' . $preset['slug'] . ':' . $preset['size'] . ';';
            $classes .= '.has-' . $preset['slug'] . '-font-size{font-size:' . $preset['size'] . ' !important;}';
        }
        foreach ($presets['spacing'] as $preset) {
            $variables .= '--wp--preset--spacing--' . $preset['slug'] . ':' . $preset['size'] . ';';
        }

        return ':root{' . $variables . '}' . $classes . "\n";
    }

    // Rules the active card needs in every place: the compact card outside the cart, the classic card inside it,
    // and the block markup (paragraphs, figures) looking like the old built-in cards.
    protected function activeCardCss(): string
    {
        return $this->cardCss(':is(.fct_order_bump_wrap, [data-fluent-cart-cart-drawer], [data-fluent-cart-page-after-items])');
    }

    // The same rules for the card editor, where the card has no wrapper around it.
    public function editorCss(): string
    {
        // The editor lays blocks out with a gap between them; the card spaces its own parts.
        return $this->cardCss('') . <<<'CSS'

.fct_order_promotion .wp-block,
.fct_cart_bump .wp-block {
    margin-block-start: 0;
    margin-block-end: 0;
}
.fct_order_promotion .fct_order_promotion_description {
    margin-block-start: 4px;
}
.fct_order_promotion .fct_order_promotion_footer {
    margin-block-start: 16px;
}
CSS;
    }

    protected function cardCss(string $scope): string
    {
        $css = str_replace('[data-fluent-cart-cart-drawer]', $scope, $this->cartCardCss());

        $cardsCss = '';
        foreach (OrderBumpTemplateService::cardClasses() as $card) {
            $cardsCss .= $card::css() . "\n";
        }

        return $this->presetCss() . $this->classicCardCss() . $css . $cardsCss . <<<CSS

.fct_order_promotion p,
.fct_cart_bump p,
.fct_order_promotion figure,
.fct_cart_bump figure {
    margin: 0;
}
.fct_order_promotion p.fct_order_promotion_title {
    margin-bottom: 6px;
}
.fct_order_promotion p.fct_order_promotion_description {
    margin-top: 4px;
}
.fct_cart_bump p.fct_cart_bump_badge {
    margin-bottom: 2px;
}
.fct_order_promotion_variation_title:empty,
.fct_order_promotion_description:empty,
.fct_cart_bump_variation:empty {
    display: none;
}
.fct_order_promotion_variation_title:not(:empty)::before {
    content: "- ";
}
{$scope} input.fct_order_promotion_input {
    flex: none;
    width: 16px;
    height: 16px;
}

.fct_order_promotion_prices,
.fct_cart_bump_price {
    display: flex;
    flex-wrap: wrap;
    align-items: baseline;
    column-gap: 8px;
}
.fct_cart_bump_price {
    column-gap: 6px;
}
.fct_order_promotion_original_price:empty,
.fct_order_promotion_discount:empty {
    display: none;
}
.fct_order_promotion .fct_order_promotion_discount:not(:empty)::before {
    content: "(";
}
.fct_order_promotion .fct_order_promotion_discount:not(:empty)::after {
    content: ")";
}
/* The checkout styles its checkboxes itself; the drawer and the cart page get the same look. */
:is([data-fluent-cart-cart-drawer], [data-fluent-cart-page-after-items]) input.fct_order_promotion_input {
    appearance: none;
    -webkit-appearance: none;
    position: relative;
    display: flex;
    align-items: center;
    justify-content: center;
    box-sizing: border-box;
    margin: 0;
    padding: 0;
    background: #fff;
    border: 1px solid var(--fct-border-color, #D6DAE1);
    border-radius: 4px;
}
:is([data-fluent-cart-cart-drawer], [data-fluent-cart-page-after-items]) input.fct_order_promotion_input::before {
    content: "";
    position: absolute;
    top: 1px;
    left: 4.5px;
    box-sizing: border-box;
    width: 5px;
    height: 9px;
    margin: 0;
    border: solid #fff;
    border-width: 0 1.5px 1.5px 0;
    transform: rotate(45deg);
    opacity: 0;
}
:is([data-fluent-cart-cart-drawer], [data-fluent-cart-page-after-items]) input.fct_order_promotion_input:checked {
    background: var(--fct-primary-bg-color, #253241);
    border-color: var(--fct-primary-bg-color, #253241);
}
:is([data-fluent-cart-cart-drawer], [data-fluent-cart-page-after-items]) input.fct_order_promotion_input:checked::before {
    opacity: 1;
}
{$scope} label.fct_order_promotion_toggle {
    border-radius: inherit;
    display: flex;
    align-items: center;
    column-gap: 8px;
    cursor: pointer;
    font-size: inherit;
    font-weight: 600;
    padding: 12px 0;
    margin: 0 0 -12px;
}
.fct_cart_bump_added[hidden],
.fct_cart_bump_btn[hidden] {
    display: none;
}
.fct_cart_bump_item[data-state="added"] .fct_cart_bump {
    border-color: #cdbdf9;
    border-color: color-mix(in srgb, #7d52f4 30%, var(--fct-card-bg-color, #fff));
    background: #f8f5ff;
    background: color-mix(in srgb, #7d52f4 6%, var(--fct-card-bg-color, #fff));
}

CSS;
    }

    protected function classicCardCss(): string
    {
        return <<<'CSS'
                .fct_order_promotions_wrap {
                    margin-bottom: 20px;
                    margin-top: 20px;
                }

                .fct_order_promotions {
                    display: flex;
                    flex-direction: column;
                    gap: 12px;
                }

                .fct_order_promotion {
                    border: 1px solid var(--fct-border-color, #e1e1e1);
                    border-radius: 8px;
                    background: var(--fct-card-bg-color, #fff);
                    padding: 16px;
                }

                .fct_order_promotion_body {
                    display: flex;
                    column-gap: 16px;
                    align-items: start;
                }

                .fct_order_promotion_icon {
                    flex: 0 0 auto;
                    width: 64px;
                    height: 64px;
                    border-radius: 8px;
                    overflow: hidden;
                    background: rgba(79, 70, 229, 0.1);
                }

                .fct_order_promotion_icon img {
                    display: block;
                    width: 100%;
                    height: 100%;
                    object-fit: cover;
                }

                .fct_bump_details {
                    flex: 1;
                    min-width: 0;
                }

                .fct_order_promotion_title {
                    display: inline-block;
                    margin-bottom: 6px;
                    padding: 2px 8px;
                    border-radius: 999px;
                    background: rgba(125, 82, 244, 0.15);
                    color: #6a3fe0;
                    font-size: 12px;
                    font-weight: 500;
                    line-height: 1.5;
                }

                .fct_order_promotion_product_title {
                    font-size: 15px;
                    font-weight: 600;
                    line-height: 1.3;
                }

                .fct_order_promotion_variation_title {
                    font-size: 13px;
                    color: var(--fct-secondary-text-color, #6b7280);
                }

                .fct_order_promotion_original_price {
                    text-decoration: line-through;
                    color: var(--fct-secondary-text-color, #6b7280);
                }

                .fct_order_promotion_discounted_price,
                span.fct_order_promotion_price {
                    font-weight: 600;
                    color: var(--fct-primary-text-color, #000);
                }

                .fct_order_promotion_discount {
                    color: #c0392b;
                }

                .fct_order_promotion_description {
                    font-size: 14px;
                    margin-top: 4px;
                    color: var(--fct-secondary-text-color, #6b7280);
                }

                .fct_order_promotion_footer {
                    margin-top: 16px;
                    padding-top: 4px;
                    border-top: 1px solid var(--fct-border-color, #e1e1e1);
                }

                .fct_checkout label.fct_order_promotion_toggle {
                    display: flex;
                    align-items: center;
                    column-gap: 8px;
                    cursor: pointer;
                    font-size: inherit;
                    font-weight: 600;
                    margin: 0;
                }
CSS;
    }

    protected function cartCardCss(): string
    {
        return <<<'CSS'
            [data-fluent-cart-cart-drawer] .fct_cart_bumps {
                display: flex;
                flex-direction: column;
                gap: 12px;
                padding: 12px 16px;
                min-height: 0;
                overflow-y: auto;
            }

            [data-fluent-cart-cart-drawer] .fct_cart_bumps_label {
                font-size: 12px;
                font-weight: 600;
                letter-spacing: 0.04em;
                text-transform: uppercase;
                color: var(--fct-secondary-text-color, #6b7280);
            }

            [data-fluent-cart-cart-drawer] .fct_cart_bump {
                display: flex;
                align-items: center;
                gap: 14px;
                padding: 12px;
                border: 1px solid var(--fct-border-color, #e1e1e1);
                border-radius: 8px;
                background: var(--fct-card-bg-color, #fff);
            }

            [data-fluent-cart-cart-drawer] .fct_cart_bump_icon {
                flex: 0 0 auto;
                width: 56px;
                height: 56px;
                border-radius: 10px;
                overflow: hidden;
                background: #e8edf6;
            }

            [data-fluent-cart-cart-drawer] .fct_cart_bump_icon img {
                display: block;
                width: 100%;
                height: 100%;
                object-fit: cover;
            }

            [data-fluent-cart-cart-drawer] .fct_cart_bump_details {
                flex: 1;
                min-width: 0;
                font-size: 12px;
                line-height: 1.4;
            }

            [data-fluent-cart-cart-drawer] .fct_cart_bump_badge {
                display: inline-block;
                margin-bottom: 2px;
                padding: 1px 8px;
                border-radius: 999px;
                background: rgba(125, 82, 244, 0.15);
                color: #6a3fe0;
                font-size: 11px;
                font-weight: 500;
            }

            [data-fluent-cart-cart-drawer] .fct_cart_bump_product {
                font-size: 15px;
                font-weight: 400;
                line-height: 1.3;
                overflow-wrap: anywhere;
                color: var(--fct-primary-text-color, #000);
            }

            [data-fluent-cart-cart-drawer] .fct_cart_bump_variation {
                color: var(--fct-secondary-text-color, #6b7280);
            }

            [data-fluent-cart-cart-drawer] .fct_cart_bump .fct_order_promotion_original_price {
                text-decoration: line-through;
                color: var(--fct-secondary-text-color, #6b7280);
            }

            [data-fluent-cart-cart-drawer] .fct_cart_bump .fct_order_promotion_discounted_price,
            [data-fluent-cart-cart-drawer] .fct_cart_bump span.fct_order_promotion_price {
                font-weight: 600;
                color: var(--fct-primary-text-color, #000);
            }

            [data-fluent-cart-cart-drawer] .fct_cart_bump .fct_order_promotion_discount {
                color: #c0392b;
            }

            [data-fluent-cart-cart-drawer] .fct_cart_bump_actions {
                flex: 0 0 auto;
                display: flex;
                flex-direction: column;
                align-items: flex-end;
                gap: 4px;
            }

            [data-fluent-cart-cart-drawer] .fct_cart_bump_added {
                font-size: 14px;
                font-weight: 600;
                color: #6a3fe0;
            }

            [data-fluent-cart-cart-drawer] .fct_cart_bump_btn {
                cursor: pointer;
                margin: 0;
                font-family: inherit;
                text-transform: none;
                box-shadow: none;
                padding: 9px 20px;
                border: 0;
                border-radius: 8px;
                background: #334155;
                color: #fff;
                font-size: 14px;
                font-weight: 600;
                line-height: 1.2;
            }

            [data-fluent-cart-cart-drawer] .fct_cart_bump_btn[data-fct_bump_action="remove"] {
                padding: 4px 0;
                min-height: 24px;
                background: transparent;
                color: #c0392b;
                font-size: 13px;
                font-weight: 400;
                text-decoration: underline;
            }

            [data-fluent-cart-cart-drawer] .fct_cart_bump_btn[data-fct_bump_action="remove"]:hover,
            [data-fluent-cart-cart-drawer] .fct_cart_bump_btn[data-fct_bump_action="remove"]:focus {
                background: transparent;
                color: #c0392b;
            }

            [data-fluent-cart-cart-drawer] .fct_cart_bump_btn:focus-visible {
                outline: 2px solid #6a3fe0;
                outline-offset: 2px;
            }

            [data-fluent-cart-cart-drawer] .fct_cart_bump_btn:disabled {
                opacity: 0.6;
                cursor: not-allowed;
            }
CSS;
    }

    // Custom image, then variant image, product featured image, store placeholder.
    protected function getBumpImageUrl($formattedBump)
    {
        $bumpVariant = $formattedBump['product_variant'];
        $imageUrl = $formattedBump['image_id']
            ? wp_get_attachment_image_url($formattedBump['image_id'], 'thumbnail')
            : false;
        if (!$imageUrl) {
            $imageUrl = $bumpVariant->thumbnail;
        }
        if (!$imageUrl && $bumpVariant->product) {
            $imageUrl = $bumpVariant->product->getMediaUrl();
        }
        if (!$imageUrl) {
            $imageUrl = Helper::getProductPlaceholderUrl();
        }

        return $imageUrl;
    }

    // The three price texts of a card: the old price and the saving only when there is a discount.
    protected function getPriceParts($formattedBump): array
    {
        $price = $formattedBump['product_variant']->item_price;
        $discount = $formattedBump['discount'];

        $discountedPrice = max(0, $price - $discount);

        // Base-currency amounts; shown in the shopper's currency when
        // core multi-currency presents another one. The cart prices the
        // bump at the discounted base price, so convert that price — the
        // currency's rounding then matches what is charged — and show the
        // saving as the difference.
        if (class_exists(\FluentCart\App\Modules\MultiCurrency\Services\StorefrontPrice::class)) {
            $price = \FluentCart\App\Modules\MultiCurrency\Services\StorefrontPrice::amount($price);
            $discountedPrice = $discount
                ? \FluentCart\App\Modules\MultiCurrency\Services\StorefrontPrice::amount($discountedPrice)
                : $price;
            $discount = max(0, $price - $discountedPrice);
        }

        $hasDiscount = !empty($discount) && $price;

        // toDecimal() returns the currency symbol as an HTML entity; the renderer escapes plain text.
        $format = function ($amount) {
            return html_entity_decode(Helper::toDecimal($amount), ENT_QUOTES, 'UTF-8');
        };

        return [
            'original_price' => $hasDiscount ? $format($price) : '',
            'price'          => $format($hasDiscount ? $discountedPrice : $price),
            'savings'        => $hasDiscount ? __('Save', 'fluent-cart-pro') . ' ' . $format($discount) : '',
        ];
    }

    protected function renderDrawerCards($formattedBumps, $variant = 'drawer', array $card = [])
    {
        $isPage = $variant === 'page';
        $labelId = $isPage ? 'fct_cart_bumps_label_page' : 'fct_cart_bumps_label';

        // Printed on every render: it sits inside the wrapper that a fragment replaces whole.
        ?>
        <style><?php echo $this->activeCardCss(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></style>
        <?php
        if ($isPage) {
            // The page container pads and does not scroll.
            ?>
            <style>
                [data-fluent-cart-page-after-items] .fct_cart_bumps {
                    padding: 12px 0;
                    overflow: visible;
                }
            </style>
            <?php
        }
        ?>
        <div class="fct_cart_bumps<?php echo $isPage ? ' fct_cart_bumps--page' : ''; ?>" data-fct_cart_bumps data-fluent-cart-hide-when-empty
             role="group" aria-labelledby="<?php echo esc_attr($labelId); ?>"
             data-fct_error="<?php echo esc_attr__('Something went wrong', 'fluent-cart-pro'); ?>">
            <div class="fct_cart_bumps_label" id="<?php echo esc_attr($labelId); ?>"><?php esc_html_e('Add to your order', 'fluent-cart-pro'); ?></div>
            <?php foreach ($formattedBumps as $formattedBump) : ?>
                <div class="fct_cart_bump_item" data-fct_cart_bump_card
                     data-state="<?php echo $formattedBump['is_added'] ? 'added' : 'idle'; ?>"><?php echo $this->renderCard($card, $formattedBump, $isPage); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></div>
            <?php endforeach; ?>
        </div>
        <?php
    }

    public function applyOrderBump($responseData, $data)
    {
        $cart = $data['cart'];
        $bumpId = isset($data['bump_id']) ? intval($data['bump_id']) : 0;

        if (!$bumpId) {
            return new \WP_Error('no_bump_id', 'No bump id provided');
        }

        $bump = OrderPromotion::query()->where('id', $bumpId)
            ->where('type', 'order_bump')
            ->where('status', 'active')
            ->first();

        if (!$bump) {
            return new \WP_Error('invalid_bump', 'Invalid bump');
        }

        $prevShippingRequired = $cart->requireShipping();

        $cartData = $cart->cart_data;
        $willAdd = Arr::get($data, 'request_data.is_upgraded', '') === 'yes';

        if (!$willAdd) {
            // Only remove the line this bump added, never a same-variant item
            // the cart already carried.
            $cart->removeItem($bump->src_object_id, [
                'other_info.promotion_id' => $bump->id
            ]);

            return [
                'message'          => __('Item has been removed from your cart', 'fluent-cart-pro'),
                'shipping_changed' => $prevShippingRequired != $cart->requireShipping()
            ];
        }

        $hasSubscription = $cart->hasSubscription();
        if ($hasSubscription && $bump->product_variant && $bump->product_variant->payment_type === 'subscription') {
            return new \WP_Error('subscription_bump_not_allowed', 'You can not add a subscription bump when your cart has a subscription product.');
        }

        $exitingOrderObjectIds = [];
        foreach ($cartData as $cartItem) {
            $exitingOrderObjectIds[] = $cartItem['object_id'];
        }

        if ($willAdd && in_array($bump->src_object_id, $exitingOrderObjectIds)) {
            return new \WP_Error('bump_already_in_cart', 'Item already in cart');
        }

        $variant = $bump->product_variant;
        if (!$variant) {
            return new \WP_Error('invalid_variant', 'Invalid variant');
        }

        $isValid = $this->isConditonsMatched($bump, [
            'cart'       => $cart,
            'object_ids' => $exitingOrderObjectIds
        ]);

        if (!$isValid) {
            return new \WP_Error('conditions_not_met', 'Sorry, you can not buy this item now.');
        }

        // Not will_validate: its subscription-mix rule refuses carts this bump accepts on purpose.
        $canPurchase = apply_filters('fluent_cart/cart/can_purchase', $variant->canPurchase(1), [
            'cart'      => $cart,
            'variation' => $variant,
            'quantity'  => 1
        ]);
        if (is_wp_error($canPurchase)) {
            return $canPurchase;
        }

        $discountAmount = $this->getDiscountAmount($bump);
        $originalPrice = $variant->item_price;

        if ($discountAmount) {
            $variant->item_price = max(0, ($variant->item_price - $discountAmount));
        }

        $otherInfo = [
            'promotion_id'         => $bump->id,
            'promotion_type'       => 'order_bump',
            'promo_price_original' => $originalPrice,
        ];

        if (Arr::get($bump->config, 'allow_coupon', 'no') !== 'yes') {
            $otherInfo['is_locked'] = 'yes';
        }

        if (Arr::get($bump->config, 'free_shipping', 'no') === 'yes') {
            $otherInfo['free_shipping'] = 'yes';
        }

        $cart = $cart->addByVariation($variant, [
            'other_info' => $otherInfo,
            'quantity'   => 1
        ]);

        if (is_wp_error($cart)) {
            return $cart;
        }

        return [
            'message'          => __('Item has been added to your cart', 'fluent-cart-pro'),
            'shipping_changed' => $prevShippingRequired != $cart->requireShipping()
        ];
    }

    /**
     * Drop every bump line whose conditions no longer hold for the cart without that line.
     *
     * Each removal fires this hook again, so one call settles bumps that depended on
     * the one just removed.
     *
     * @param array $data ['cart' => Cart]
     * @return void
     */
    public function removeUnqualifiedBumps($data)
    {
        $cart = Arr::get($data, 'cart');
        if (!$cart instanceof \FluentCart\App\Models\Cart || $cart->isLocked() || !$this->countBumpLines($cart)) {
            return;
        }

        while ($this->removeFirstUnqualifiedBump($cart)) {
        }
    }

    /**
     * Place-order check, so a page loaded before the cart changed cannot buy a bump
     * that no longer qualifies.
     *
     * @param \WP_Error|null $result
     * @param array $data ['cart' => Cart]
     * @return \WP_Error|null WP_Error when this request removed a bump line, at any step.
     */
    public function revalidateAtCheckout($result, $data)
    {
        $cart = Arr::get($data, 'cart');
        if (!$cart instanceof \FluentCart\App\Models\Cart) {
            return $result;
        }

        $this->removeUnqualifiedBumps(['cart' => $cart]);

        if (!$this->removedBumpCount) {
            return $result;
        }

        return new \WP_Error(
            'order_bump_removed',
            __('An offer in your cart no longer applies. Please review your order and place it again.', 'fluent-cart-pro')
        );
    }

    protected function countBumpLines($cart)
    {
        $count = 0;
        foreach ((array)$cart->cart_data as $item) {
            if (Arr::get($item, 'other_info.promotion_type') === 'order_bump') {
                $count++;
            }
        }

        return $count;
    }

    protected function removeFirstUnqualifiedBump($cart)
    {
        $cartData = array_values((array)$cart->cart_data);

        foreach ($cartData as $index => $item) {
            $promotionId = (int)Arr::get($item, 'other_info.promotion_id', 0);
            if (!$promotionId || Arr::get($item, 'other_info.promotion_type') !== 'order_bump') {
                continue;
            }

            $bump = OrderPromotion::query()->where('id', $promotionId)
                ->where('type', 'order_bump')
                ->where('status', 'active')
                ->first();
            if (!$bump) {
                continue;
            }

            // Judge the bump as it was when added: the lines before it, never itself or a bump added after it.
            $otherIds = [];
            $excludedItems = [];
            foreach ($cartData as $otherIndex => $other) {
                if ($otherIndex >= $index && Arr::get($other, 'other_info.promotion_type') === 'order_bump') {
                    $excludedItems[] = $other;
                } else {
                    $otherIds[] = $other['object_id'];
                }
            }

            $isValid = $this->isConditonsMatched($bump, [
                'cart'          => $cart,
                'object_ids'    => $otherIds,
                'exclude_items' => $excludedItems,
            ]);
            if ($isValid) {
                continue;
            }

            $cart->removeItem(Arr::get($item, 'object_id'), ['other_info.promotion_id' => $promotionId]);

            $removed = count((array)$cart->cart_data) < count($cartData);
            if ($removed) {
                $this->removedBumpCount++;
            }

            return $removed;
        }

        return false;
    }

    protected function isConditonsMatched(OrderPromotion $bump, $args = [])
    {
        if (Arr::get($bump->conditions, 'is_enabled') !== 'yes') {
            return true;
        }

        $cart = Arr::get($args, 'cart', null);

        $conditionGroups = Arr::get($bump->conditions, 'groups', []);

        if (!$conditionGroups) {
            return true;
        }

        $objectIds = Arr::get($args, 'object_ids', []);

        foreach ($conditionGroups as $conditionGroup) {
            if (!$conditionGroup) {
                continue;
            }


            $isAllMatched = true;
            foreach ($conditionGroup as $condition) {
                if (!$isAllMatched) {
                    break;
                }

                $key = Arr::get($condition, 'key');
                $operator = Arr::get($condition, 'operator');
                $value = Arr::get($condition, 'value');

                if ($key === 'order_items') {
                    if (!is_array($value) || !$value) {
                        continue;
                    }
                    $hasCommon = !!array_intersect($value, $objectIds);

                    if ($operator === 'exist') {
                        $isAllMatched = $hasCommon;
                    } else {
                        $isAllMatched = !$hasCommon;
                    }
                } else if ($key === 'order_subtotal') {
                    $subtotal = $cart->getItemsSubtotal();
                    $excludedItems = Arr::get($args, 'exclude_items', []);
                    if ($excludedItems) {
                        $subtotal -= OrderService::getItemsAmountWithoutDiscount($excludedItems);
                    }
                    if ($operator === 'greater_than') {
                        $isAllMatched = $subtotal > Helper::toCent($value);
                    } else if ($operator === 'less_than') {
                        $isAllMatched = $subtotal <= Helper::toCent($value);
                    } else if ($operator === 'equals') {
                        $isAllMatched = $subtotal == Helper::toCent($value);
                    } else if ($operator === 'not_equals') {
                        $isAllMatched = $subtotal != Helper::toCent($value);
                    } else {
                        $isAllMatched = false;
                    }
                }
            }

            if ($isAllMatched) {
                return true;
            }
        }

        return false;
    }

    protected function getDiscountAmount(OrderPromotion $bump)
    {
        $discountAmount = Helper::toCent(Arr::get($bump->config, 'discount.discount_amount', 0));
        if (Arr::get($bump->config, 'discount.discount_type') === 'percentage') {
            $discountAmount = (int)round(($bump->product_variant->item_price * $discountAmount / 100) / 100);
        }

        return $discountAmount;
    }
}
