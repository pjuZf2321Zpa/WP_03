<?php
/**
 * Bottom-right promo card suggesting the events sync when a calendar plugin
 * is active and an events source is connected. Dismissal is permanent.
 *
 * @package CustomFacebookFeed\Events_Integration
 * @since 4.11
 */

namespace CustomFacebookFeed\Events_Integration\Admin;

use CustomFacebookFeed\Events_Integration\Config;
use CustomFacebookFeed\Events_Integration\EventsIntegration;
use CustomFacebookFeed\Events_Integration\Provider\EventsProvider;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class EventsSyncPromo {

	/**
	 * Option: promo permanently dismissed (site-wide).
	 */
	const OPTION_DISMISSED = 'cff_events_sync_promo_dismissed';

	/**
	 * The plugin's own admin page slugs the card may appear on.
	 * cff-settings is intentionally absent: the card links there.
	 */
	const PAGES = array(
		'cff-top',
		'cff-feed-builder',
		'cff-oembeds-manager',
		'cff-extensions-manager',
		'cff-support',
		'cff-about-us',
	);

	/**
	 * Register admin hooks.
	 */
	public function register_hooks() {
		if ( ! is_admin() ) {
			return;
		}
		add_action( 'admin_footer', array( $this, 'maybe_render' ) );
		add_action( 'wp_ajax_cff_events_sync_dismiss_promo', array( $this, 'ajax_dismiss' ) );
	}

	/**
	 * Whether the card should appear on the current screen.
	 *
	 * @return bool
	 */
	public function should_show() {
		if ( get_option( self::OPTION_DISMISSED ) ) {
			return false;
		}
		// Only on this plugin's own admin pages.
		$page = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only display routing.
		if ( ! in_array( $page, self::PAGES, true ) ) {
			return false;
		}
		if ( ! Config::license_allows() || Config::is_enabled() ) {
			return false;
		}
		if ( empty( $this->available_calendars() ) ) {
			return false;
		}

		return $this->has_events_source();
	}

	/**
	 * Labels of the active, supported calendar plugins.
	 *
	 * @return string[]
	 */
	public function available_calendars() {
		$labels = array();
		foreach ( EventsIntegration::adapters() as $adapter ) {
			if ( $adapter->is_available() ) {
				$labels[] = $adapter->label();
			}
		}

		return $labels;
	}

	/**
	 * Whether at least one events source is connected.
	 *
	 * @return bool
	 */
	private function has_events_source() {
		$provider = new EventsProvider();

		return count( $provider->get_sources() ) > 0;
	}

	/**
	 * Render the card in the admin footer when the conditions are met.
	 */
	public function maybe_render() {
		if ( ! $this->should_show() ) {
			return;
		}

		$calendars    = $this->available_calendars();
		$settings_url = admin_url( 'admin.php?page=cff-settings&view=events' );
		/* translators: %s: comma-separated calendar plugin name(s), e.g. "Sugar Calendar". */
		$description = sprintf(
			__( 'We noticed %s is active and you have a Facebook events source connected. Sync your Facebook events into your calendar automatically.', 'custom-facebook-feed' ),
			implode( ', ', $calendars )
		);
		?>
		<div class="cff-events-sync-promo" id="cff-events-sync-promo">
			<button type="button" class="cff-events-sync-promo-dismiss" aria-label="<?php esc_attr_e( 'Dismiss', 'custom-facebook-feed' ); ?>">&times;</button>
			<h4><?php esc_html_e( 'Sync Facebook Events to your calendar', 'custom-facebook-feed' ); ?></h4>
			<p><?php echo esc_html( $description ); ?></p>
			<a class="cff-btn sb-btn-orange" href="<?php echo esc_url( $settings_url ); ?>">
				<?php esc_html_e( 'Set up Events Sync', 'custom-facebook-feed' ); ?>
			</a>
		</div>
		<style>
			.cff-events-sync-promo {
				position: fixed;
				right: 20px;
				bottom: 20px;
				z-index: 99999;
				width: 320px;
				background: #fff;
				border: 1px solid #d8dde3;
				border-radius: 6px;
				box-shadow: 0 4px 18px rgba(0, 0, 0, 0.12);
				padding: 18px 20px;
			}
			.cff-events-sync-promo h4 {
				margin: 0 24px 8px 0;
				font-size: 14px;
			}
			.cff-events-sync-promo p {
				margin: 0 0 12px;
				font-size: 12px;
				color: #55595d;
			}
			.cff-events-sync-promo .cff-btn {
				display: inline-block;
				text-decoration: none;
				padding: 7px 14px;
				border-radius: 4px;
				background: #fe544f;
				color: #fff;
				font-size: 12px;
				border: none;
				cursor: pointer;
			}
			.cff-events-sync-promo-dismiss {
				position: absolute;
				top: 8px;
				right: 10px;
				border: none;
				background: transparent;
				font-size: 18px;
				line-height: 1;
				color: #8c8f94;
				cursor: pointer;
			}
		</style>
		<script>
			( function() {
				var card = document.getElementById( 'cff-events-sync-promo' );
				if ( ! card ) {
					return;
				}
				card.querySelector( '.cff-events-sync-promo-dismiss' ).addEventListener( 'click', function() {
					card.style.display = 'none';
					var data = new FormData();
					data.append( 'action', 'cff_events_sync_dismiss_promo' );
					data.append( 'nonce', '<?php echo esc_js( wp_create_nonce( 'cff-admin' ) ); ?>' );
					fetch( ajaxurl, { method: 'POST', credentials: 'same-origin', body: data } );
				} );
			} )();
		</script>
		<?php
	}

	/**
	 * AJAX: persist the dismissal.
	 */
	public function ajax_dismiss() {
		check_ajax_referer( 'cff-admin', 'nonce' );

		$cap = current_user_can( 'manage_custom_facebook_feed_options' ) ? 'manage_custom_facebook_feed_options' : 'manage_options';
		$cap = apply_filters( 'cff_settings_pages_capability', $cap );
		if ( ! current_user_can( $cap ) ) {
			wp_send_json_error();
		}

		update_option( self::OPTION_DISMISSED, 1, false );
		wp_send_json_success();
	}
}
