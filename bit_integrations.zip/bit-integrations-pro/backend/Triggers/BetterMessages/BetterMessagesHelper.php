<?php

namespace BitApps\IntegrationsPro\Triggers\BetterMessages;

class BetterMessagesHelper
{
    public static function NewMessageReceivedFormatFields($message)
    {
        $userClass = bit_integrations_get_class('Core\\Util\\User');
        $helperClass = bit_integrations_get_class('Core\\Util\\Helper');

        if (! \function_exists('Better_Messages')) {
            return;
        }

        $senderData = $userClass::get($message->sender_id);
        $message = Better_Messages()->functions->get_message($message->id);

        $data = \is_object($message) ? get_object_vars($message) : $message;
        $data['sender'] = $senderData;

        return $helperClass::prepareFetchFormatFields($data);
    }

    public static function isPluginInstalled()
    {
        return class_exists('Better_Messages_Functions');
    }
}
