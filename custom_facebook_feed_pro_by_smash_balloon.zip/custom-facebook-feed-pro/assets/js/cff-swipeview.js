/**
 * Reels swipe viewer for Facebook (SMASH-2049 prototype).
 *
 * Slice 1 proved the ROUTING SPLIT -- that this viewer and the plugin's
 * existing hand-rolled lightbox can share one mixed feed without either
 * swallowing the other's input. Slice 2 replaces that slice's open() stub with
 * the real shell: a three-slot window, the three-tier playback chain, the
 * follow-the-finger gesture layer, Instagram's chrome grammar, and the a11y
 * layer. The routing split below is UNCHANGED from slice 1 -- its 48-assertion
 * coexistence suite is the feature's kill-criterion evidence and nothing here
 * may move it.
 *
 * ==========================================================================
 * THE CONTRACT, which is Instagram's OUTCOME contract (spec S2.2) verbatim
 * ==========================================================================
 *
 *   Reel click     -> preventDefault + mark it CLAIMED -> open()
 *   non-Reel click -> BARE RETURN. Nothing else. The lightbox's own delegated
 *                     bubble handler on `body` then runs completely untouched.
 *
 * The bare return is the whole mechanism, and it is why there is no "close the
 * lightbox first" logic anywhere in this file. Instagram gets mixed-feed
 * coexistence for free from exactly that fall-through, and copying the shape
 * matters more than copying its code (Instagram's viewer is unmerged, with no
 * PR, so none of its implementation choices are normative).
 *
 * ==========================================================================
 * INSTAGRAM IS THE REFERENCE, NOT YOUTUBE -- and the difference is not cosmetic
 * ==========================================================================
 *
 * The shell's skeleton (slots, tier chain, track motion, gestures, a11y) ports
 * from the YouTube prototype, which is the newest and most complete
 * implementation in the fleet. But YouTube's TRANSPORT is an iframe player, and
 * three of its behaviours exist only because of that. Facebook's tier 1 is a
 * native `<video>`, the same lineage as Instagram's, so where the two siblings
 * disagree this file follows Instagram:
 *
 *   sound on open      Spec S4.1 (revised 2026-08-14) is attempt-UNMUTED, with
 *                      a muted retry on rejection plus a pill. That is a
 *                      PROMISE-driven chain on a real `<video>`
 *                      (attemptPlay(), below) -- not YouTube's inferred-refusal
 *                      watchdog, which had to guess because playVideo()
 *                      returns undefined, and which demonstrably fired ~380ms
 *                      before a cold player reached PLAYING and popped a pill
 *                      over audio the browser was about to allow. Not ported.
 *   mute state         A real `volumechange` listener, which fires for both a
 *                      user change and a direct property assignment. YouTube's
 *                      250ms poll is load-bearing there because its API emits
 *                      no such event; here the poll is belt-and-braces behind
 *                      a real signal.
 *   idle-fade chrome   YouTube's chrome fades after a few seconds of playback.
 *                      That was specific maintainer direction for the YouTube
 *                      lane (its embed paints its own title bar over the first
 *                      seconds, so two titles competed). Facebook has no such
 *                      furniture on tier 1, and NEITHER reference viewer
 *                      idle-fades anything but its unmute pill. Not ported.
 *
 * Everything else here that looks like a choice is a RATIFIED one from the
 * Instagram and TikTok reviews, pre-applied so the Facebook design review only
 * has to look at what is genuinely Facebook-novel. Each is marked `RATIFIED`
 * with its source at the point it is implemented.
 *
 * ==========================================================================
 * WHY CAPTURE PHASE, AND WHY NO JQUERY
 * ==========================================================================
 *
 * The lightbox binds `$('body').on('click', 'a[data-cff-lightbox], ...')` --
 * a delegated BUBBLE-phase handler (assets/js/cff-scripts.js:4682). To decide
 * a Reel's fate before that handler sees the event, this listener must run in
 * the CAPTURE phase on `document`, which is strictly earlier in the
 * propagation path.
 *
 * jQuery has no capture-phase API at all. So the one load-bearing line of this
 * feature could not use jQuery even if the handle depended on it, which is why
 * the registration in CFF_Swipe_View::register_assets() declares no deps.
 *
 * A claimed click is MARKED, never stopped (SMASH-2232). It used to be
 * stopImmediatePropagation'd, which kept the lightbox shut but also silenced
 * every listener below document -- including Feed Analytics, which counts
 * clicks with a listener on each `.cff-item a` / `.cff-album-item a`, so no Reel
 * opened here was ever counted. Now the click travels the same path it does
 * with the viewer off, carrying CLAIM_FLAG. The lightbox's delegated handler on
 * `body` sees the flag and stands down (cff-scripts.js, Lightbox.enable()),
 * but still returns false, so the plugin's document-level play-button handler
 * never sees a claimed click -- exactly as it never sees one with the viewer
 * off, where the lightbox's `return false` ends the click at `body`.
 *
 * ==========================================================================
 * WHY THE INPUT COLLISION DOES NOT HAPPEN -- verified, not assumed
 * ==========================================================================
 *
 * The lightbox looked like it would collide, because `keyboardAction`
 * (cff-scripts.js:6140) is extremely greedy: Escape, the arrow keys, and ANY
 * key whose character matches /x|o|c/ or equals p/n all act on it.
 *
 * It does not collide, and the reason is a lifecycle fact rather than luck:
 * those handlers are bound in `enableKeyboardNav()` (`:6117`) which is called
 * ONLY from `Lightbox.prototype.start()` (`:5252`), and removed in
 * `disableKeyboardNav()` -> `$(document).off('.keyboard')` from
 * `Lightbox.prototype.end()` (`:6186`). Nothing binds a document-level key
 * handler at init -- verified by grep across the whole file.
 *
 * So on a Reel click, `start()` never runs, and the lightbox has ZERO document
 * key handlers bound while this viewer is open. The two directions are:
 *
 *   viewer open   -> lightbox bound no keys at all, so nothing to collide with
 *   lightbox open -> this viewer is closed and its key handler is not attached,
 *                    because it attaches on open and detaches on close
 *
 * Both halves are asserted behaviourally against the real lightbox in
 * tests/behavioural/coexistence.js. Note the second half is a property of THIS
 * file: a viewer that bound its keys once at init would break it. That is why
 * the handler here is attached in open() and removed in close(), and why it is
 * never bound at module scope.
 *
 * Also, jQuery's `.keyboard` event namespace is the lightbox's teardown
 * instrument -- `off('.keyboard')` removes every handler in that namespace,
 * whoever registered it. This file uses native addEventListener, so it cannot
 * be in that namespace and cannot be torn down by the lightbox closing.
 *
 * AND A THIRD SEPARATION, found by mutation rather than by reading: the
 * lightbox's greedy handler listens on `keyup` (`:6118`), while this file
 * listens on `keydown`. A mutation that bound a module-scope keydown Escape
 * swallower SURVIVED the entire behavioural suite for exactly that reason --
 * it could not reach the lightbox at all. Only the keyup version of the same
 * mutation killed the tests. So the two components are separated on THREE
 * independent axes: propagation phase (capture vs bubble), jQuery namespace
 * (none vs `.keyboard`), and event type (keydown vs keyup). None of the three
 * is load-bearing alone, which is why the behavioural tier asserts the
 * OUTCOME rather than any one of these mechanisms.
 *
 * ==========================================================================
 * OWN NAMESPACE, OWN MOUNT POINT -- a booby trap, not a style preference
 * ==========================================================================
 *
 * Twelve sites in cff-scripts.js call
 * `$('#cff-lightbox-wrapper video.cff-lightbox-video')[0].pause()` (`:4755`,
 * `:4768`, `:4780`, `:4788`, `:4800`, `:4812`, `:4824`, `:4867`, `:5533`,
 * `:6149`, `:6164`, `:6178`). All twelve are inert TODAY, because nothing ever
 * creates that element -- the lightbox shell has no <video> and loads the mp4
 * as an iframe src. They all come alive the instant anything inserts a
 * `<video class="cff-lightbox-video">` inside `#cff-lightbox-wrapper`. Worse,
 * `:5063` runs `$container.find('video').remove()` on EVERY image change.
 *
 * SLICE 2 IS WHERE THAT TRAP GOES LIVE, because slice 2 is the slice that
 * creates a `<video>`. So it matters more here than it did in slice 1: this
 * viewer mounts at #cff-swipeview-root, appended to <body> and never inside the
 * lightbox wrapper, and every class it owns is prefixed `cff-swipeview-`. The
 * tier-1 element is `video.cff-swipeview-video`, which matches neither
 * `.cff-lightbox-video` nor any descendant selector rooted at
 * `#cff-lightbox-wrapper`. A test asserts that negative against the real
 * lightbox with a real <video> on the page.
 *
 * @since 4.13.0 (SMASH-2049 prototype)
 */
(function (window, document) {
	'use strict';

	/**
	 * The per-post seam attribute, emitted server-side by CFF_Swipe_View on the
	 * media wrapper of every eligible Reel, on both edges. This is the ONLY
	 * routing signal; nothing here re-derives Reel-ness in the browser.
	 */
	var REEL_SELECTOR = '[data-cff-reel]';

	/**
	 * The feed container, and the feed-level enablement flag on the existing
	 * data-cff-flags channel.
	 */
	var FEED_SELECTOR = '.cff';
	var FEED_FLAG     = 'swipeView';

	/**
	 * The media anchors a click has to land on for the viewer to claim it.
	 *
	 * Scoped rather than "any anchor inside the reel host" on purpose: the
	 * wrapper also contains the video-title link (cff-scripts' `<h4><a>`), and
	 * a customer clicking a title expects to go to Facebook, not to open a
	 * viewer. Instagram scopes to its own media anchor for the same reason.
	 *
	 *   a.cff-album-cover -- videos-edge media cover link
	 *   a.cff-vidLink     -- timeline-edge media link
	 *   [data-cff-lightbox] -- the lightbox-bound shapes, which cff-scripts.js
	 *                          attaches at runtime (`:2279`) rather than in PHP
	 */
	var MEDIA_ANCHOR = 'a.cff-album-cover, a.cff-vidLink, a[data-cff-lightbox], area[data-cff-lightbox]';

	/**
	 * The flag a claimed Reel click carries, as an expando on the native event
	 * (SMASH-2232). cff-scripts.js reads the same name in the lightbox's click
	 * handler, so rename both or neither.
	 */
	var CLAIM_FLAG = 'cffSwipeViewClaimed';

	var MOUNT_ID = 'cff-swipeview-root';

	/* ───────────────────────── Tunables (spec S3.1 / S3.2 / S5.2) ─────────────
	 *
	 * Every value here is the spec's, and the two that are NOT are named as
	 * such. Provisional in the spec means provisional here; changing one is a
	 * spec conversation, not a local tuning pass.
	 */
	var WINDOW_RADIUS           = 1;    // S4.4: three slots, active plus one either side.
	var TRANSITION_MS           = 320;  // S3.2.
	var NAV_COOLDOWN_MS         = 420;  // S3.1.
	var WHEEL_THRESHOLD         = 25;   // S3.1.
	var WHEEL_COOLDOWN_MS       = 550;  // S3.1.
	var SWIPE_THRESHOLD_PX      = 60;   // S3.1 flick distance.
	var SWIPE_MAX_DURATION_MS   = 600;  // The flick's duration bound -- see decideSnap().
	var START_TIMEOUT_MS        = 4000; // S5.2 trigger 2, the start watchdog.
	/*
	 * AC 25's MID-SESSION stall bound, and it is a DIFFERENT number from the
	 * start watchdog for a reason.
	 *
	 * START_TIMEOUT_MS covers "this never began" -- nothing has played, so a
	 * generous 4s is right: a cold player on a slow connection deserves it.
	 * This covers "this was playing and stopped", where the visitor is already
	 * watching and a frozen frame is immediately obvious. 2.5s is long enough
	 * to ride out an ordinary rebuffer and short enough that the escalation
	 * feels like recovery rather than a second failure.
	 */
	var STALL_TIMEOUT_MS        = 2500; // AC 25: a previously-good source dying.
	var CHROME_POLL_MS          = 250;  // S6.1: play state refreshed at least this often.
	var ANALYTICS_THROTTLE_MS   = 250;  // S8.
	var ANALYTICS_SCHEMA_VERSION = 1;   // S8.

	/*
	 * THE §8 SCHEMA (AC 32). Every event carries every one of these keys, with
	 * `null` where it has nothing to say -- see emitAnalytics().
	 *
	 * This list IS the schema, and it is declared in one place so that adding a
	 * field is a visible decision rather than a side effect of writing an
	 * emit call. A key not in this list is dropped with a console warning, so a
	 * field that exists on one event type only cannot quietly enter the stream.
	 *
	 * `schema_version`, `event`, `ts` and `post_id` are NOT here: they are set
	 * unconditionally on every envelope and are not optional.
	 */
	var ANALYTICS_FIELDS = [
		// Position in the track.
		'index',
		'total',
		'slides_viewed',
		// Which tier / adapter the event is about.
		'adapter',
		'from',
		'to',
		'tier',
		'terminal',
		// Why it happened.
		'reason',
		'trigger',
		'phase',
		'intended',
		/*
		 * HOW a share completed -- 'web-share' or 'clipboard'. The two are not
		 * interchangeable analytically: one hands the link to another app, the
		 * other leaves it on the clipboard and relies on the visitor. Declared
		 * here rather than passed ad hoc, because the envelope is fixed-shape
		 * (AC 32) -- the suite's schema guard is what caught this field being
		 * emitted before it was declared.
		 */
		'method',
		// AC 25's attribution: the browser never gives us an HTTP status for
		// media, so the MediaError code is the closest observable signal.
		'mediaErrorCode',
		'mediaErrorMessage',
		'afterStart'
	];

	/**
	 * How far the finger has to travel before a touch becomes a DRAG rather
	 * than a tap. Not a spec value -- it is hardware jitter tolerance, and its
	 * only job is to stop a stationary tap from being read as a 1px drag and
	 * suppressing the play/pause it was meant to trigger.
	 */
	var DRAG_START_PX = 8;

	/**
	 * The release boundary, as a fraction of the viewport. Not a spec value
	 * either: S3.1 specifies the 60px flick, and the AREA rule is the
	 * 2026-08-24 team feedback ("based on which reel occupies the most area, it
	 * scrolls up or down" -- Aman), which is a majority, i.e. one half.
	 * Expressed as a fraction so the boundary is DERIVED from the viewport
	 * rather than being a second tuned constant.
	 */
	var DRAG_SNAP_AREA_FRACTION = 0.5;

	/**
	 * How long the centre play/pause glyph stays on screen after a tap. Must
	 * match the cffSwipeViewTapFlash keyframe duration in the stylesheet -- the
	 * animation paints the fade and this timer removes the node, so a mismatch
	 * either clips the fade or parks a transparent glyph over the stage. A test
	 * reads both values and asserts they agree.
	 */
	/*
	 * AC 27's label timings. TAP_FLASH_MS used to live here; its subject --
	 * the 600ms transient tap echo -- stopped existing when rule 1.10 replaced
	 * it with the persistent pause glyph, and the cross-file assertion that
	 * pinned the constant against the keyframe's duration went with it. That is
	 * a BEHAVIOURAL retarget rather than a rename, and the suite records it as
	 * one.
	 */
	/*
	 * ONE definition of "desktop", and it is the stylesheet's.
	 *
	 * `cff-swipeview.css` gates the desktop layout on exactly this condition,
	 * so anything in JS meaning "the desktop layout is showing" must ask the
	 * same question. A geometry-tier assertion pins the two strings equal:
	 * two notions of desktop in one feature is how a control ends up behaving
	 * as though it were on the other layout.
	 *
	 * The width half matters as much as the capability half -- at 500px with a
	 * mouse we render the TOUCH layout, so a fine pointer alone is not desktop.
	 */
	var DESKTOP_QUERY = '(hover: hover) and (pointer: fine) and (min-width: 769px)';

	var MUTE_HINT_DELAY_MS = 350;  // Rule 1.7 / AC 27: +350ms in.
	var MUTE_HINT_HOLD_MS  = 4500; // Rule 1.7 / AC 27: retract at 4500ms.
	// Rule 1.10 / AC 11: the dissolve. Must equal the cffSwipeViewPauseOut
	// keyframe's duration, and the suite asserts the pair from both files --
	// the same cross-file discipline TAP_FLASH_MS used to carry.
	var PAUSE_GLYPH_OUT_MS = 100;
	// IG-3's share-chain toast. Long enough to read a URL, which is what the
	// last rung of the chain puts in it.
	var TOAST_MS = 3200;
	/*
	 * Rule 1.14's letterbox boundary: media WIDER than 9:16 x 1.04 is
	 * contained over a blurred backdrop; anything taller is cropped.
	 *
	 * The 4% tolerance is the whole reason this is a constant rather than a
	 * bare `9/16` comparison. A nominally-9:16 encode whose dimensions round a
	 * pixel out -- 406x720 is 0.5639, not 0.5625 -- would otherwise flip into
	 * letterbox mode and paint two backdrop bands around a video that fills
	 * the frame. The harness's own test clip is exactly that shape.
	 */
	var FIT_CONTAIN_RATIO = (9 / 16) * 1.04;

	/*
	 * Rule 1.16's wheel tuning, adopted from the reference. FOUR numbers, and
	 * each one exists because a trackpad is not a mouse wheel: a single
	 * two-finger flick produces dozens of events over hundreds of
	 * milliseconds, with a long decaying inertia tail after the fingers lift.
	 *
	 *   ACCUM    fire once the accumulated delta passes 40px, rather than on
	 *            any single event's delta. A trackpad's individual deltas are
	 *            often 1-3px, so a per-event threshold either never fires or
	 *            fires on a mouse wheel's first notch and nothing else.
	 *   IDLE     a gap longer than 160ms ends the gesture and zeroes the
	 *            accumulator. Without it, three separate small scrolls minutes
	 *            apart add up to one navigation.
	 *   COOLDOWN at least 450ms between slides, so one flick moves one slide.
	 *   TAIL     the accumulator is NOT re-armed until the gesture ends, which
	 *            is what discards the inertia tail rather than letting it walk
	 *            the visitor through the feed.
	 */
	var WHEEL_ACCUM_PX = 40;
	var WHEEL_IDLE_MS = 160;
	var WHEEL_SLIDE_COOLDOWN_MS = 450;

	/*
	 * Rule 1.16 / AC 12's pull-to-close. Touch only, slide 0 only, at rest
	 * only, and on RELEASE only.
	 *
	 * The damping and the cap are what keep the strict-clamp feel the 1978
	 * gesture rules ratified: at slide 0 a downward drag has nowhere to go, so
	 * the track follows at 35% of the finger and stops at 160px. The visitor
	 * gets a physical acknowledgement that the gesture registered, without the
	 * track ever appearing to scroll somewhere it cannot.
	 *
	 * 140px on release is the commit threshold, and it is deliberately ABOVE
	 * the cap's halfway point: a 130px pull returns, a 145px pull closes, and
	 * the suite pins both sides plus the non-zero-slide refusal.
	 */
	var PULL_CLOSE_DAMP = 0.35;
	var PULL_CLOSE_MAX_PX = 160;
	var PULL_CLOSE_COMMIT_PX = 140;

	/*
	 * Rule 1.9's first-run coach. TOUCH ONLY and ONCE EVER.
	 *
	 * The 350ms arm delay is not cosmetic: the tap that OPENED the viewer is
	 * still settling, and dismiss listeners armed immediately would catch it
	 * and dismiss the overlay before it could be read. 3200ms is the
	 * auto-dismiss, so it leaves on its own if the visitor does nothing.
	 */
	var COACH_ARM_MS = 350;
	var COACH_AUTO_MS = 3200;
	var COACH_STORAGE_KEY = 'cffSwipeViewCoachSeen';

	/**
	 * Whether §4.4's pre-warm is suppressed for this visitor.
	 *
	 * `navigator.connection.saveData` is the visitor asking, at the OS or
	 * browser level, not to have bytes spent speculatively -- and pre-warm is
	 * exactly that: metadata for two videos they may never watch.
	 *
	 * Read at each decision rather than cached once, because Data Saver can be
	 * toggled mid-session and a cached answer would keep warming for the rest
	 * of it.
	 *
	 * @return {boolean}
	 */
	function prewarmSuppressed() {
		var conn = navigator.connection || navigator.mozConnection || navigator.webkitConnection;

		return !! (conn && conn.saveData);
	}

	/**
	 * Capability sets (spec S6.2), and they are FROZEN.
	 *
	 * Freezing is not ceremony. Adapters return these BY REFERENCE, so every
	 * slot on a caps-less tier shares one object -- and a single stray
	 * `slot.caps.mute = true` anywhere would silently grant mute to every
	 * caps-less slot in the session, including ones already torn down. This is
	 * the (d) half of the four YouTube shell defects: there, five sites defend
	 * `slot.caps` with `|| NO_CAPS` while five trust it bare, and the whole
	 * ambiguity exists because the invariant was never stated. It is stated
	 * here: `slot.caps` is ALWAYS a non-null caps object, normalised at the one
	 * assignment seam (see setSlotCaps), so no read site needs a fallback.
	 *
	 * Facebook is the plugin where this stops being latent: tier 2 is genuinely
	 * caps-less, so the invariant is load-bearing on day one rather than on the
	 * day someone adds a zero-capability tier.
	 */
	var NO_CAPS   = Object.freeze({ mute: false, playPause: false, progress: false });
	var FULL_CAPS = Object.freeze({ mute: true,  playPause: true,  progress: true  });

	/* ───────────────────────── Open-session state ─────────────────────────
	 *
	 * `session` is null when closed. Everything below it is scoped to one
	 * viewing and reset by open(), which is what makes "a fresh open is a fresh
	 * session" true rather than remembered.
	 */
	var session = null;

	/**
	 * The visitor's last EXPLICIT mute choice, in either direction (spec S4.2).
	 * `false` -- attempt unmuted -- until an explicit mute.
	 *
	 * MODULE-LEVEL AND IN MEMORY ONLY, matching both reference viewers: there
	 * is no localStorage, sessionStorage, cookie or server round-trip in either
	 * of them, and S4.2 puts cross-session persistence out of scope. It is
	 * reset by open(), so "persists across slides for the session" means
	 * exactly that.
	 *
	 * The ONLY writer of `true` is toggleMute(). A muted RETRY after a refusal
	 * never writes here, because S4.1 says plainly that a muted retry MUST NOT
	 * be recorded as the visitor's explicit choice.
	 */
	var userMuted = false;

	/**
	 * Set once per session by a PROVEN unmute -- a resolved unmuted play()
	 * whose element still reports unmuted at resolve time. Not "the pill was
	 * tapped": a tap that ends in another refusal must leave the affordance in
	 * place.
	 *
	 * RATIFIED (2026-08-24 feedback item F, Instagram): the pill auto-hides
	 * after the first SUCCESSFUL unmute, not after any tap. Suppressing on a
	 * mere tap means a later slide that is genuinely refused audio gives the
	 * visitor silence with no affordance and no explanation.
	 */
	var unmuteSucceeded = false;

	var lastAnalyticsAt = {};

	/* ───────────────────────── Small helpers ───────────────────────── */

	/**
	 * closest() with a fallback, because this bundle targets the same browser
	 * floor as the rest of the plugin's ES5 assets.
	 *
	 * @param {Element|null} start    Node to start from.
	 * @param {string}       selector CSS selector.
	 *
	 * @return {Element|null}
	 */
	function closest(start, selector) {
		var node = start;

		while (node && node.nodeType === 1) {
			if (node.matches ? node.matches(selector) : matchesFallback(node, selector)) {
				return node;
			}
			node = node.parentNode;
		}

		return null;
	}

	/**
	 * @param {Element} node     Element to test.
	 * @param {string}  selector CSS selector.
	 *
	 * @return {boolean}
	 */
	function matchesFallback(node, selector) {
		var fn = node.msMatchesSelector || node.webkitMatchesSelector;

		return fn ? fn.call(node, selector) : false;
	}

	/**
	 * @param {string}  tag       Tag name.
	 * @param {string}  className Class attribute.
	 * @param {Object}  attrs     Attributes to set.
	 *
	 * @return {Element}
	 */
	function el(tag, className, attrs) {
		var node = document.createElement(tag);

		if (className) {
			node.className = className;
		}

		if (attrs) {
			Object.keys(attrs).forEach(function (key) {
				node.setAttribute(key, attrs[ key ]);
			});
		}

		return node;
	}

	/**
	 * @return {boolean} Whether the visitor asked for reduced motion.
	 */
	function prefersReducedMotion() {
		return !! (window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches);
	}

	/**
	 * Spec S12 -- only http(s) may become an href or a media src.
	 *
	 * Every url this viewer touches came out of an encrypted cache of
	 * third-party data. CFF_Swipe_View already validates scheme and host
	 * server-side and drops anything else, so this is the second of two
	 * independent checks rather than the only one -- deliberately, because the
	 * seam is a data channel and a future emitter on it should not be able to
	 * hand this file a `javascript:` url just because it forgot.
	 *
	 * @param {string} url Candidate.
	 *
	 * @return {boolean}
	 */
	function isHttpUrl(url) {
		return /^https?:\/\//i.test(String(url || ''));
	}

	/**
	 * Whether a url is on facebook.com, for the values that become a NAVIGATION
	 * target or an embed document rather than a media reference.
	 *
	 * Parsed with the URL constructor where available rather than matched with
	 * a regex: `https://www.facebook.com.evil.test/` and
	 * `https://evil.test/?x=www.facebook.com` both satisfy a naive
	 * `indexOf('facebook.com')`, and the host is the whole question here. The
	 * regex fallback anchors the host segment for the same reason.
	 *
	 * @param {string} url Candidate.
	 *
	 * @return {boolean}
	 */
	function isFacebookUrl(url) {
		if (! isHttpUrl(url)) {
			return false;
		}

		if (typeof window.URL === 'function') {
			try {
				var host = new window.URL(url).hostname.toLowerCase();

				return host === 'facebook.com' || host.slice(-13) === '.facebook.com';
			} catch (e) {
				return false;
			}
		}

		return /^https?:\/\/([a-z0-9-]+\.)*facebook\.com(\/|$|\?|#)/i.test(String(url));
	}

	/**
	 * Spec S12 -- a media src may also be a same-origin relative path (the
	 * behavioural harness serves local mp4s that way), but any other scheme is
	 * rejected.
	 *
	 * @param {string} url Candidate.
	 *
	 * @return {string} The url, or '' when it is not usable as a media src.
	 */
	/**
	 * Escape a URL for use inside a CSS `url()` token.
	 *
	 * A DIFFERENT job from safeMediaSrc(), which decides whether a URL may be
	 * loaded at all. This one decides whether it can be safely INTERPOLATED
	 * into a stylesheet value, and the answer for anything doubtful is no.
	 *
	 * The threat is CSS injection through a cached poster URL: a `)` closes the
	 * `url()` token early and everything after it is parsed as further
	 * declarations. Quotes and backslashes let an attacker escape a quoted
	 * form; whitespace and control characters can split the token; and a
	 * newline can begin a whole new declaration.
	 *
	 * REFUSAL, NOT ESCAPING, and that is deliberate. Percent-encoding the
	 * dangerous characters would keep more URLs working, but it means reasoning
	 * about the interaction of CSS tokenisation and URL decoding to be sure the
	 * escape holds -- and a poster is decoration. Losing the blurred backdrop on
	 * a pathological URL costs nothing; getting the escape subtly wrong costs a
	 * stylesheet injection on every visitor's page.
	 *
	 * @param {string} url An already host-checked URL.
	 *
	 * @return {string} The URL, or '' when it must not be interpolated.
	 */
	function safeCssUrl(url) {
		var value = String(url || '');

		if (! value) {
			return '';
		}

		// Refuse anything that could terminate or extend the token: parens,
		// either quote, a backslash, any whitespace, and any C0/C1 control
		// character.
		/* eslint-disable-next-line no-control-regex */
		if (/[()'"\\\s]|[\x00-\x1f\x7f-\x9f]/.test(value)) {
			return '';
		}

		return value;
	}

	/**
	 * Apply rule 1.14's fit decision to a slot, from the media's INTRINSIC
	 * dimensions.
	 *
	 * Called on `loadedmetadata` (and on a poster's `load`), because that is
	 * the first moment the intrinsic size is known. Calling it earlier reads
	 * zeroes and would letterbox nothing, or everything, depending on which way
	 * the comparison falls.
	 *
	 * The backdrop's `display` is toggled rather than left permanently on: it
	 * carries a 28px blur over an over-scaled background image, which is a real
	 * compositor cost, and it is only ever VISIBLE behind contained media.
	 *
	 * @param {Object} slot The slot record.
	 *
	 * @return {void}
	 */
	function applyFit(slot) {
		if (! slot || ! slot.stage) {
			return;
		}

		var node = slot.stage.querySelector('.cff-swipeview-video, .cff-swipeview-terminal-poster');
		var w = 0;
		var h = 0;

		if (node) {
			// videoWidth for a <video>, naturalWidth for an <img>. Both are 0
			// until metadata arrives, which is what the guard below is for.
			w = node.videoWidth || node.naturalWidth || 0;
			h = node.videoHeight || node.naturalHeight || 0;
		}

		if (! w || ! h) {
			slot.stage.removeAttribute('data-fit');

			if (slot.backdrop) {
				slot.backdrop.style.display = 'none';
			}

			return;
		}

		var wider = (w / h) > FIT_CONTAIN_RATIO;

		if (wider) {
			slot.stage.setAttribute('data-fit', 'contain');
		} else {
			slot.stage.removeAttribute('data-fit');
		}

		if (! slot.backdrop) {
			return;
		}

		/*
		 * The backdrop needs a poster to blur. With none -- and poster data is
		 * THIN on Facebook, present on only a couple of the fixture's
		 * videos-edge items and never on a timeline DASH reel -- the frame's
		 * own black is the answer, which is the design's stated fallback rather
		 * than a failure.
		 */
		var slide = session ? session.slides[ slot.index ] : null;
		var poster = slide ? safeCssUrl(slide.poster) : '';

		if (wider && poster) {
			slot.backdrop.style.backgroundImage = 'url(' + poster + ')';
			/*
			 * `'block'`, NOT `''`.
			 *
			 * Instagram's equivalent writes `style.display = wider ? '' : 'none'`,
			 * which works there because its backdrop's BASE rule is visible and
			 * the JS only ever hides it. Ours is `display: none` in the
			 * stylesheet -- deliberately, so the 28px blur over an over-scaled
			 * background image earns no compositor pass until it is actually
			 * needed -- and clearing the inline style therefore falls straight
			 * back to that `none`.
			 *
			 * So the port of that one line shipped a backdrop that was
			 * configured, positioned, given its image, and never displayed:
			 * the same INVISIBLE-BACKDROP outcome Instagram fixed in
			 * `49d18a6b`, arrived at through a completely different mechanism.
			 * Caught by asserting the computed `display` rather than the
			 * assignment.
			 */
			slot.backdrop.style.display = 'block';
		} else {
			slot.backdrop.style.display = 'none';
		}
	}

	function safeMediaSrc(url) {
		var value = String(url || '');

		if (! value) {
			return '';
		}

		if (/^https?:\/\//i.test(value)) {
			return value;
		}

		if (value.charAt(0) === '/') {
			return value;
		}

		return /^[a-z][a-z0-9+.\-]*:/i.test(value) ? '' : value;
	}

	/**
	 * Parse a cached count the way CFF_Swipe_View::count_or_null() does, so the
	 * two halves of the absence-is-not-zero contract cannot disagree.
	 *
	 * RATIFIED (Instagram, SMASH-1851): "no data" and "zero" are DIFFERENT. The
	 * server omits the attribute entirely when it has no count, so an ABSENT
	 * attribute reads as null here and the readout is dropped; a present "0" is
	 * a real zero and renders. A truthiness test at either end collapses the
	 * two and is the exact defect this pair of functions exists to prevent.
	 *
	 * @param {string|null} raw The attribute value, or null when absent.
	 *
	 * @return {number|null}
	 */
	function parseCount(raw) {
		if (raw === undefined || raw === null || raw === '') {
			return null;
		}

		var value = parseInt(raw, 10);

		return (isNaN(value) || value < 0) ? null : value;
	}

	/**
	 * Platform-convention abbreviation for DISPLAY only; the accessible name
	 * uses the exact figure, because a screen reader gains nothing from "1.2K".
	 *
	 * The 999500 boundary is Instagram's, and it is a fixed Rex finding rather
	 * than a round number: the K branch rounds for k >= 100, so 999500 is the
	 * SMALLEST n whose K form would round up to 1000 and print the nonsense
	 * "1000K". Both sides of that boundary are pinned by a test.
	 *
	 * @param {number} n A non-negative count.
	 *
	 * @return {string}
	 */
	function formatCount(n) {
		if (n < 1000) {
			return String(n);
		}

		if (n < 999500) {
			var k = n / 1000;

			return (k >= 100 ? Math.round(k) : Math.round(k * 10) / 10) + 'K';
		}

		var m = n / 1000000;

		return (m >= 100 ? Math.round(m) : Math.round(m * 10) / 10) + 'M';
	}

	/**
	 * Singular/plural for the SPOKEN label only -- "1 likes" read aloud is
	 * sloppy in a way "1" under a heart glyph is not, because the glyph carries
	 * the noun visually and nothing carries it aurally.
	 *
	 * @param {string} kind  `likes` or `comments`.
	 * @param {number} value The count.
	 *
	 * @return {string}
	 */
	function countNoun(kind, value) {
		if (kind === 'likes') {
			return value === 1 ? 'like' : 'likes';
		}

		return value === 1 ? 'comment' : 'comments';
	}

	/**
	 * The exact figure, grouped with the visitor's locale -- what assistive
	 * technology is given in place of the abbreviation.
	 *
	 * @param {number} n A non-negative count.
	 *
	 * @return {string}
	 */
	function exactCount(n) {
		try {
			return n.toLocaleString();
		} catch (e) {
			return String(n);
		}
	}

	/* ───────────────────────── Analytics (spec S8) ─────────────────────────
	 *
	 * SMASH-1852 owns the transport; this is the seam only. Two things are
	 * wired from day one deliberately, because Instagram's port shipped without
	 * them and that is a recorded open defect:
	 *
	 *   - `schema_version` on every event
	 *   - post identity (`post_id`) on every event, resolved from the index
	 *
	 * `bubbles: true` is load-bearing rather than habit. The epic's recorded
	 * test-shape traps include a `bubbles: false` dispatch that made an
	 * assertion pass while the event was unobservable from a document-level
	 * listener. A non-bubbling event dispatched ON document is technically
	 * still observable there -- the SHAPE is the trap, because anything that
	 * later moves the dispatch target breaks every consumer silently.
	 */

	/**
	 * @param {string} name    Event name.
	 * @param {Object} payload Event detail.
	 *
	 * @return {void}
	 */
	function emitAnalytics(name, payload) {
		var now = Date.now();

		if (lastAnalyticsAt[ name ] && (now - lastAnalyticsAt[ name ]) < ANALYTICS_THROTTLE_MS) {
			return;
		}

		lastAnalyticsAt[ name ] = now;

		/*
		 * ── THE FIXED ENVELOPE: ABSENT FIELDS ARE `null`, NEVER DROPPED ──────
		 *
		 * AC 32's explicit requirement, and it is the half of the AC that is
		 * actually deliverable today (see the transport note below).
		 *
		 * Every §8 event carries EVERY key in ANALYTICS_FIELDS, with `null`
		 * where this event has nothing to say. That is not tidiness: a
		 * consumer distinguishing "this event had no `reason`" from "this
		 * event's `reason` was dropped in transit" cannot do it if absent keys
		 * are simply missing, and a schema that varies its key set per event
		 * forces every reader to special-case every event name. An explicit
		 * `null` is a statement; a missing key is an ambiguity.
		 *
		 * `schema_version` and post identity are UNCONDITIONAL. `post_id` used
		 * to be set only when a slide could be resolved, which meant the one
		 * field a consumer joins on was the field most likely to be absent --
		 * and absent for the reason (an unresolvable index) that most needs
		 * reporting.
		 */
		var detail = {
			schema_version: ANALYTICS_SCHEMA_VERSION,
			event: name,
			ts: now
		};
		var i;

		for (i = 0; i < ANALYTICS_FIELDS.length; i++) {
			detail[ ANALYTICS_FIELDS[ i ] ] = null;
		}

		if (payload) {
			Object.keys(payload).forEach(function (key) {
				/*
				 * An UNDECLARED field is dropped, loudly in development rather
				 * than silently forever. The field list is the schema, and a
				 * payload key that is not in it would otherwise appear in the
				 * stream for one event type only -- which is exactly the
				 * per-event special-casing the fixed envelope exists to
				 * prevent. Adding a field means adding it to ANALYTICS_FIELDS,
				 * which is one line and a schema decision.
				 */
				if (ANALYTICS_FIELDS.indexOf(key) === -1) {
					if (window.console && window.console.warn) {
						window.console.warn('cff-swipeview: undeclared analytics field "'
							+ key + '" on event "' + name + '" -- add it to ANALYTICS_FIELDS');
					}

					return;
				}

				// `undefined` is normalised to `null`. They mean the same
				// thing here and only one of them survives JSON.
				detail[ key ] = payload[ key ] === undefined ? null : payload[ key ];
			});
		}

		// Post identity, derived from the event's OWN index when it carries
		// one, so an event about a neighbour slot is attributed to that
		// neighbour rather than to whatever happens to be current.
		var index = (payload && typeof payload.index === 'number') ? payload.index : (session ? session.index : -1);
		var slide = slideAt(index);

		detail.post_id = slide ? slide.id : null;

		reportAnalytics(detail);
	}

	/**
	 * THE ONE TRANSPORT SEAM for §8 events (AC 32).
	 *
	 * ── TRANSPORT PENDING SMASH-1852, AND THAT IS A FINDING, NOT A SHORTCUT ──
	 *
	 * AC 32 asks for these events to leave the stub and ride the plugin's real
	 * transport. **Custom Facebook Feed has no front-end event transport that
	 * can carry this payload**, and that was checked rather than assumed:
	 *
	 *   inc/UsageTracking/EventRecorder.php  is a NAME-ONLY COUNTER. `record()`
	 *       takes a single string, increments a count in the
	 *       `cff_smash_usage_events` option and stamps a date. It has no
	 *       payload parameter at all -- so `schema_version`, post identity and
	 *       every nullable field would be discarded at the door. It is also
	 *       called exclusively from admin/server paths (`plugin_installed`,
	 *       `setting_changed`, `notification_clicked`), and routing per-slide
	 *       front-end events through it would mean an `update_option()` write
	 *       on every slide change -- a real performance cost for a payload it
	 *       cannot keep.
	 *   the `wp_ajax_nopriv_*` actions  are feature endpoints (`cff_get_new_posts`,
	 *       `cff_do_locator`, `cff_resized_images_submit`), not telemetry.
	 *       None accepts an event.
	 *
	 * SMASH-1852's shared endpoint is the intended destination and is unbuilt.
	 * So this stays a `CustomEvent`, and the deliverable part of AC 32 is that
	 * it is now ONE named seam carrying the FULL, FIXED payload shape: when the
	 * endpoint exists, the change is the body of this function and nothing
	 * else. Inventing an endpoint here would have been worse than waiting --
	 * a POST to a URL nobody serves is a silent failure plus a per-slide
	 * request.
	 *
	 * The event is dispatched on `document` so a host page or a future
	 * transport can subscribe without this file knowing about it, which is
	 * also what the behavioural suite listens to.
	 *
	 * @param {Object} detail The complete envelope.
	 *
	 * @return {void}
	 */
	function reportAnalytics(detail) {
		try {
			document.dispatchEvent(new window.CustomEvent('cffSwipeViewEvent', {
				detail: detail,
				bubbles: true
			}));
		} catch (e) {
			// Engines without the CustomEvent constructor: drop silently (S8).
			// An analytics failure must never break playback.
		}
	}

	/**
	 * The flags on a feed container, off the existing data-cff-flags channel.
	 *
	 * Riding that channel rather than wp_localize_script is what sidesteps the
	 * boolean string-casting trap (false -> ""), which the YouTube lane paid
	 * for once already.
	 *
	 * @param {Element} feed Feed container.
	 *
	 * @return {Array<string>}
	 */
	function feedFlags(feed) {
		var raw = feed ? feed.getAttribute('data-cff-flags') : null;

		return raw ? raw.split(',') : [];
	}

	/**
	 * @param {Element} feed Feed container.
	 * @param {string}  flag Flag name.
	 *
	 * @return {boolean}
	 */
	function hasFlag(feed, flag) {
		return feedFlags(feed).indexOf(flag) > -1;
	}

	/**
	 * Whether this feed has the visitor's consent for the viewer to BIND AT ALL.
	 *
	 * This implements spec S2.4's binding refusal properly, which is one of the
	 * four conscious divergences from Instagram's implementation. Instagram only
	 * suppresses its EMBED TIER when GDPR-gated -- a proxy its own code comment
	 * admits to, taken because it had "no cheap read access to live
	 * consentGiven", and which leaves its viewer opening to a poster-plus-link
	 * on a feed that has no consent. Facebook has the real server-side plumbing
	 * Instagram lacked, so it should not clone the proxy.
	 *
	 * Two reads, in order of authority:
	 *
	 *   1. The live per-feed `settings.consentGiven` that cff-scripts.js
	 *      computes via `feed.checkConsent()` (`:1032`), which is what actually
	 *      integrates with the consent plugins.
	 *   2. Failing that -- the feed script may not have initialised yet, since
	 *      this listener is registered at capture on document and does not wait
	 *      for it -- the flags: GDPR active and the CDN still blocked means no
	 *      consent yet.
	 *
	 * THE FEED INDEX IS RESOLVED PER FEED, NOT HARDCODED TO 0. cff-scripts.js
	 * reads `window.cff.feeds[0].settings.consentGiven` at `:1107` and `:4945`,
	 * which is a latent multi-feed bug: on a page with two feeds, the second
	 * feed's consent state is read off the first. `data-cff-index` is stamped
	 * per feed at `:975` (1-based), so the correct entry is reachable and this
	 * file reaches it. Do not replicate the hardcoded index.
	 *
	 * @param {Element} feed Feed container.
	 *
	 * @return {boolean}
	 */
	function hasConsent(feed) {
		var index = parseInt(feed.getAttribute('data-cff-index'), 10);

		if (
			window.cff
			&& window.cff.feeds
			&& !isNaN(index)
			&& window.cff.feeds[ index - 1 ]
			&& window.cff.feeds[ index - 1 ].settings
			&& typeof window.cff.feeds[ index - 1 ].settings.consentGiven !== 'undefined'
		) {
			return !! window.cff.feeds[ index - 1 ].settings.consentGiven;
		}

		if (! hasFlag(feed, 'gdpr')) {
			return true;
		}

		return hasFlag(feed, 'overrideBlockCDN');
	}

	/**
	 * Whether dispatch is suppressed for this particular anchor.
	 *
	 * Mirrors Instagram's suppression matrix, applied at BOTH dispatch and
	 * track build so a suppressed post is absent from the track rather than
	 * merely unclickable.
	 *
	 * The customizer-preview case is the one worth naming: the front-end script
	 * genuinely does run inside the builder's preview iframe on this fleet, so
	 * "the script is structurally absent from admin" -- true for Instagram --
	 * is NOT true here and cannot be relied on.
	 *
	 * @param {Element} anchor The media anchor.
	 * @param {Element} feed   Its feed container.
	 *
	 * @return {boolean}
	 */
	function isSuppressed(anchor, feed) {
		if (closest(anchor, '.cff-no-consent-hide')) {
			return true;
		}

		// The builder / customizer preview: never hijack a click an admin is
		// making to inspect their own feed.
		if (closest(anchor, '.cff-customizer-preview, .cff_builder_preview, #cff-builder')) {
			return true;
		}

		if (feed && feed.classList && feed.classList.contains('cff-moderation-mode')) {
			return true;
		}

		return false;
	}

	/**
	 * The eligible track for a feed: that feed's Reels, IN FEED ORDER, and
	 * nothing else.
	 *
	 * Non-eligible posts are ABSENT rather than skipped-over, which is what
	 * makes "swipe to the next Reel" mean the same thing on a mixed feed as on
	 * a Reels-only one. A Reels-only feed is the degenerate case of exactly
	 * this contract, with the non-eligible set empty -- there is no whole-feed
	 * special case and no read of the per-feed post-type filters.
	 *
	 * @param {Element} feed Feed container.
	 *
	 * @return {Array<Element>} Reel hosts in document order.
	 */
	function collectTrack(feed) {
		var hosts = feed.querySelectorAll(REEL_SELECTOR);
		var track = [];
		var i;

		for (i = 0; i < hosts.length; i++) {
			var anchor = hosts[ i ].querySelector(MEDIA_ANCHOR) || hosts[ i ];

			if (! isSuppressed(anchor, feed)) {
				track.push(hosts[ i ]);
			}
		}

		return track;
	}

	/**
	 * The capture-phase router. The whole feature's decision, in one function.
	 *
	 * Every early `return` here is a BARE return by design: it means "not ours",
	 * and it leaves the event untouched so the lightbox behaves exactly as it
	 * does on a stock install.
	 *
	 * @param {MouseEvent} event The click.
	 *
	 * @return {void}
	 */
	function onClickCapture(event) {
		// A modified click is the visitor asking the browser for a new tab or a
		// download, not asking us for a viewer. Left button only.
		if (event.button !== 0 || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) {
			return;
		}

		var anchor = closest(event.target, MEDIA_ANCHOR);
		if (! anchor) {
			return;
		}

		var host = closest(anchor, REEL_SELECTOR);
		if (! host) {
			// The non-Reel path. This is the line that gives us coexistence.
			return;
		}

		var feed = closest(host, FEED_SELECTOR);
		if (! feed || ! hasFlag(feed, FEED_FLAG)) {
			return;
		}

		// Consent is a BINDING refusal, not a tier suppression: without it the
		// viewer does not act at all and the click falls through to the
		// plugin's existing, already-consent-aware behaviour.
		if (! hasConsent(feed)) {
			return;
		}

		if (isSuppressed(anchor, feed)) {
			return;
		}

		var track = collectTrack(feed);
		var index = indexOfHost(track, host);

		// Zero eligible, or a host that suppression removed from its own track:
		// fall through rather than open an empty viewer.
		if (! track.length || index < 0) {
			return;
		}

		// Claimed, not stopped (SMASH-2232): preventDefault keeps the anchor
		// from navigating, and the flag tells the lightbox to stand down. The
		// click still reaches every other listener on its path, so Feed
		// Analytics counts it exactly as it does with the viewer off.
		event.preventDefault();
		event[ CLAIM_FLAG ] = true;

		// The clicked anchor is passed EXPLICITLY as the opener (S7.1):
		// a click on a non-focusable tile leaves document.activeElement
		// on <body>, so a viewer that inferred it would restore focus
		// nowhere on close.
		open(track, index, anchor);
	}

	/**
	 * @param {Array<Element>} track Track hosts.
	 * @param {Element}        host  Host to find.
	 *
	 * @return {number} Index, or -1.
	 */
	function indexOfHost(track, host) {
		var i;

		for (i = 0; i < track.length; i++) {
			if (track[ i ] === host) {
				return i;
			}
		}

		return -1;
	}

	/* ───────────────────────── Post metadata (spec S9.2) ─────────────────────
	 *
	 * The normalised per-slide view, read once at open() off the seam
	 * attributes and never re-read. Everything here is already
	 * scheme-validated and host-validated server-side by CFF_Swipe_View; the
	 * second validation on the way out (safeMediaSrc / isHttpUrl /
	 * isFacebookUrl) is defence in depth on a data channel, not a duplicate.
	 */

	/**
	 * @param {Element} host A reel host.
	 * @param {number}  index Its position in the track.
	 *
	 * @return {Object} The S9.2 shape, plus the two Facebook-specific fields.
	 */
	function readSlide(host, index) {
		return {
			// `id` is the analytics identity (S9.2). data-post-id is what the
			// render path already stamps; the host's own id is the fallback.
			id:         host.getAttribute('data-post-id') || host.getAttribute('id') || String(index),
			videoSrc:   safeMediaSrc(host.getAttribute('data-cff-swipe-src')),
			embed:      host.getAttribute('data-cff-swipe-embed') || '',
			permalink:  host.getAttribute('data-cff-swipe-permalink') || '',
			poster:     safeMediaSrc(host.getAttribute('data-cff-swipe-poster')),
			caption:    host.getAttribute('data-cff-swipe-caption') || '',
			author:     host.getAttribute('data-cff-swipe-author') || '',
			// S5.4's up-front decline, resolved server-side from 1909's
			// is_known_unplayable_source(): a .mpd manifest or an absent
			// source. Declining before rendering is the point -- a slide must
			// not pay a visible failed-load round-trip to discover what the
			// cache already knows.
			unplayable: host.getAttribute('data-cff-swipe-unplayable') === '1',
			// Absence is null, never 0. See parseCount().
			likes:      parseCount(host.getAttribute('data-cff-swipe-likes')),
			comments:   parseCount(host.getAttribute('data-cff-swipe-comments')),
			// AC 15's third metric. The plugin's own tile meta box prints
			// shares alongside reactions and comments, so the parity floor
			// requires it here -- see the change log's audit.
			shares:     parseCount(host.getAttribute('data-cff-swipe-shares')),
			authorImg:  safeMediaSrc(host.getAttribute('data-cff-swipe-author-img')),
			// Gated by the same host check the permalink uses. With no safe
			// link the author row degrades to a plain <div> and Follow is
			// omitted entirely, rather than rendering a dead promise.
			authorLink: isFacebookUrl(host.getAttribute('data-cff-swipe-author-link'))
				? host.getAttribute('data-cff-swipe-author-link')
				: '',
			/*
			 * AC 13. Always false on Facebook today, and read from an attribute
			 * the seam does not emit rather than hard-coded to `false`: the
			 * branch is then reachable the day a Page-level `is_verified`
			 * request is added, and until then it is honestly absent rather
			 * than silently impossible. NEVER inferred from anything else.
			 */
			verified:   host.getAttribute('data-cff-swipe-verified') === '1'
		};
	}

	/**
	 * @param {number} index Track index.
	 *
	 * @return {Object|null} The normalised slide, or null when out of range.
	 */
	function slideAt(index) {
		if (! session || index < 0 || index >= session.slides.length) {
			return null;
		}

		return session.slides[ index ];
	}

	/* ───────────────────────── Poster preload ─────────────────────────
	 *
	 * A poster SHOULD paint before playback begins (S4.4), so a slide is never
	 * blank. This memo keeps one Image per url so a back-swipe does not refetch.
	 *
	 * IT NULLS ITS MEMO ON REJECTION, and that is the (b) half of the four
	 * YouTube shell defects carried across rather than inherited. There,
	 * `apiPromise` is module-level, short-circuits on `if (apiPromise) return
	 * apiPromise`, and is NEVER nulled on rejection -- so one transient script
	 * failure (an ad-blocker warming up, a CSP hiccup, a consent tool
	 * intercepting) sent every subsequent slide, in every subsequent open(), to
	 * the terminal tier for the page's whole lifetime. Facebook has no script
	 * API to load, so that subsystem is deleted rather than fixed; what carries
	 * over is the SHAPE, and this is the only memoised promise in the file.
	 *
	 * Facebook makes the rejection case ordinary rather than exotic: fbcdn
	 * poster urls are signed and expire, so a 403 here is the aged-cache common
	 * case. A permanently-memoised rejection would mean one expired poster
	 * suppressed the poster for that url for the rest of the page.
	 */
	var posterMemo = {};

	/**
	 * @param {string} url A poster url.
	 *
	 * @return {Promise|null} Resolves when decodable; null when there is no url.
	 */
	function preloadPoster(url) {
		if (! url) {
			return null;
		}

		if (posterMemo[ url ]) {
			return posterMemo[ url ];
		}

		posterMemo[ url ] = new Promise(function (resolve, reject) {
			var img = new window.Image();

			img.onload  = function () { resolve(url); };
			img.onerror = function () {
				// THE FIX: drop the memo before rejecting, so a retry exists.
				// Deleting it first means even a synchronous re-entrant call
				// from the rejection handler gets a fresh attempt.
				delete posterMemo[ url ];
				reject(new Error('poster load failed'));
			};
			img.src = url;
		});

		// A rejection nobody awaits is an unhandled rejection; the memo's
		// consumers are all optional paint niceties, so absorb it here.
		posterMemo[ url ].catch(function () {});

		return posterMemo[ url ];
	}

	/* ═══════════════════════ Tier 1 -- native <video> ═══════════════════════
	 *
	 * The mp4 is already cached, requested on both edges and normalised to one
	 * flat path server-side. So Facebook's tier 1 is the same transport as
	 * Instagram's and TikTok's -- a real HTMLMediaElement with a real
	 * play() promise, real error events and a real `volumechange`.
	 *
	 * What is NET-NEW versus the plugin's own existing player: there is no
	 * `muted`, no `playsinline` and no `autoplay` anywhere in this plugin
	 * today, and NO onerror handling for video at all -- a 403'd mp4 fails
	 * silently on a stock install. Muted-fallback autoplay, playsinline and
	 * error-driven escalation are all written from scratch here.
	 */

	/**
	 * THE one place the sound rule lives (spec S4.1, revised 2026-08-14).
	 *
	 * `muted` is a plain boolean INTENT asserted directly on `video.muted` --
	 * never a negation of some other flag. `play({muted: !userMuted})` is the
	 * exact bug that shipped in a sibling port of this viewer, and it is why
	 * this is one function rather than one expression per call site. play(),
	 * restart() and setMuted(false) all route through here, so the fallback
	 * cannot stay correct in one caller while silently regressing in another.
	 *
	 * THE RESOLVE ARM IS THE ONLY HONEST PROOF OF AUDIO. A resolved unmuted
	 * play() re-reads `v.muted` AT RESOLVE TIME rather than trusting the intent
	 * that was passed in, because the rejection fallback below -- or an
	 * explicit mute racing us -- may have flipped it in the meantime. That
	 * re-read is the sole writer of `unmuteSucceeded`, which is what the pill's
	 * auto-hide keys off.
	 *
	 * THE REJECTION ARM MUST NOT STALL. S4.1 is explicit: on a rejected promise
	 * the viewer retries muted, continues playing, surfaces the pill and emits
	 * `swipeview_autoplay_blocked`. A bare `v.play().catch(() => {})` -- which
	 * is what a naive loop-at-end path looks like -- swallows a rejected replay
	 * with no mute, no emit and no pill, leaving the shell believing playback
	 * is fine while the element has in fact stopped (a rejected play() leaves
	 * the video paused). That regression shipped in a sibling port; it is why
	 * restart() below routes here too.
	 *
	 * @param {HTMLVideoElement} video The element.
	 * @param {Object}           ctx   The adapter context (emit + identity).
	 * @param {boolean}          muted The INTENDED mute state.
	 *
	 * @return {void}
	 */
	function attemptPlay(video, ctx, muted) {
		video.muted = muted;

		var promise;

		try {
			promise = video.play();
		} catch (e) {
			// Older engines throw synchronously rather than rejecting.
			ctx.emit('autoplay_blocked', { intended: muted ? 'muted' : 'unmuted' });
			return;
		}

		if (! promise || typeof promise.catch !== 'function') {
			// A browser with no promise-returning play(). Nothing to chain; the
			// start watchdog (S5.2) is what covers a silent failure here.
			return;
		}

		if (! muted && typeof promise.then === 'function') {
			promise.then(function () {
				if (! video.muted) {
					unmuteSucceeded = true;
					updateMuteChrome();
				}
			}, function () { /* The catch below owns the rejection path. */ });
		}

		promise.catch(function () {
			if (! muted) {
				video.muted = true;
				ctx.emit('autoplay_blocked', { intended: 'unmuted' });
				video.play().catch(function () {
					// Refused MUTED too: autoplay is blocked outright, which
					// the pill has nothing to offer for.
					ctx.emit('autoplay_blocked', { intended: 'muted' });
				});
				return;
			}

			ctx.emit('autoplay_blocked', { intended: 'muted' });
		});
	}

	/**
	 * Create the tier-1 adapter.
	 *
	 * @param {Object} slide The normalised slide.
	 * @param {Object} ctx   { stage, emit }.
	 *
	 * @return {Object} An S9.1 instance.
	 */
	function createNativeVideo(slide, ctx) {
		var video = el('video', 'cff-swipeview-video');
		var destroyed = false;

		video.src = slide.videoSrc;

		if (slide.poster) {
			video.poster = slide.poster;
		}

		// A pre-gesture safe default ONLY. attemptPlay() sets the real intended
		// value synchronously when play() is actually invoked, which happens
		// before this element ever paints a frame.
		video.muted = true;
		video.playsInline = true;
		// iOS Safari reads the ATTRIBUTE, not just the property; without it
		// playback takes over the whole screen (S4.1).
		video.setAttribute('playsinline', '');
		// Looping is driven explicitly on `ended` so the loop event always
		// fires and S4.3's loop goes through attemptPlay's fallback chain.
		video.loop = false;
		// S4.4: metadata is the ceiling until the slide is actually activated.
		video.preload = 'metadata';

		/*
		 * AC 25: the media error, WITH its code.
		 *
		 * The viewer never sees an HTTP status for this fetch -- the request is
		 * the browser's, not ours. A 403 on a signed fbcdn URL (measured: 403
		 * `text/plain` "URL signature expired", never 410, no redirect --
		 * `smash2044-evidence/m3-check-death-shape.md`) surfaces here as a
		 * `MediaError` and nothing more. Cross-origin, even `message` is
		 * usually empty.
		 *
		 * So the CODE is what gets carried, for attribution rather than for
		 * routing:
		 *   2 MEDIA_ERR_NETWORK          the fetch died mid-stream
		 *   3 MEDIA_ERR_DECODE           bytes arrived and were not playable
		 *   4 MEDIA_ERR_SRC_NOT_SUPPORTED the src was rejected outright, which
		 *                                 is how a 403 on the initial request
		 *                                 usually presents
		 *
		 * Routing on a status code we cannot read is the trap AC 25 describes
		 * as "stalling": the escalation must fire on the signal that exists.
		 */
		video.addEventListener('error', function () {
			var code = (video.error && video.error.code) || 0;

			ctx.emit('error', {
				reason: 'media-load-failed',
				mediaErrorCode: code,
				// Only ever populated same-origin; recorded when present
				// rather than assumed absent.
				mediaErrorMessage: (video.error && video.error.message) || null,
				// Distinguishes "never started" from AC 25's case: a source
				// that WAS playing and then died.
				afterStart: ctx.slot.playingSeen === true
			});
		});
		video.addEventListener('loadedmetadata', function () {
			/*
			 * Rule 1.14's fit decision, taken HERE and not earlier: this is
			 * the first moment the intrinsic dimensions are known. Read before
			 * metadata arrives they are both 0, and the ratio comparison then
			 * letterboxes either nothing or everything depending on which way
			 * a divide-by-zero falls.
			 */
			applyFit(ctx.slot);
			ctx.emit('ready');
		});
		video.addEventListener('playing', function () {
			ctx.emit('playing', { muted: video.muted });
		});
		/*
		 * `stalled` AND `waiting`, and the pair is AC 25's substance.
		 *
		 * A mid-playback range request that 403s frequently fires NEITHER
		 * `error` NOR `stalled` -- it fires `waiting`, because from the
		 * element's point of view it is simply short of data. That is the
		 * shape a signed URL expiring mid-session takes when the first range
		 * succeeded and a later one did not, and listening only for `stalled`
		 * is why such a slide freezes on its last decoded frame with a
		 * spinner and no escalation, forever.
		 *
		 * Both still route through the same event: S9.1's rule that a stall
		 * shows the loading affordance and does NOT escalate is unchanged.
		 * What escalates is the WATCHDOG the router arms, and that watchdog is
		 * now armed for a mid-session stall as well as a failure to start.
		 */
		video.addEventListener('stalled', function () {
			ctx.emit('stalled');
		});
		video.addEventListener('waiting', function () {
			ctx.emit('stalled');
		});
		/*
		 * Progress is what proves recovery. An ordinary rebuffer fires
		 * `waiting` and then resumes; a dead source fires `waiting` and never
		 * does. `timeupdate` only fires while the playback position is
		 * actually moving, so it is the honest "still alive" signal -- more so
		 * than `playing`, which fires once on resume and would leave a source
		 * that resumed for one frame looking healthy.
		 */
		video.addEventListener('timeupdate', function () {
			ctx.emit('progressing');
		});
		video.addEventListener('ended', function () {
			ctx.emit('ended');
		});

		// A REAL volumechange listener -- the Instagram half YouTube
		// structurally could not have. It fires for BOTH a user-driven change
		// and a direct property assignment (attemptPlay's fallback sets
		// `video.muted` exactly that way), so this is the one listener that
		// keeps the mute button and the pill in sync with reality regardless of
		// which code path changed it. Never the `userMuted` intent, which can
		// legitimately diverge from the real property for as long as a rejected
		// retry's fallback is in effect.
		video.addEventListener('volumechange', function () {
			if (ctx.isCurrent()) {
				updateMuteChrome();
			}
		});

		ctx.stage.appendChild(video);

		return {
			name: 'native-video',
			caps: FULL_CAPS,
			el: video,
			play: function (opts) {
				var wantMuted = ! opts || opts.muted !== false;

				// Only now does the payload get fetched in full.
				video.preload = 'auto';
				attemptPlay(video, ctx, wantMuted);
			},
			pause: function () {
				video.pause();
			},
			setMuted: function (mute) {
				// Muting never needs a play() call; UNMUTING does, and routes
				// through the same fallback as every other activation so a
				// refused retry still degrades to muted and re-arms the pill
				// instead of leaving the element silently paused.
				if (mute) {
					video.muted = true;
					return;
				}

				attemptPlay(video, ctx, false);
			},
			// S9.1: MUST NOT report optimistically -- real paused/ended state
			// only. An over-eager answer here is what defeats a stall watchdog.
			isPlaying: function () {
				return ! video.paused && ! video.ended;
			},
			// The REAL property, never the intent. A rejected retry can leave
			// the element muted while intent never flipped, and the chrome must
			// render what is true.
			isMuted: function () {
				return video.muted;
			},
			progress: function () {
				return { current: video.currentTime || 0, duration: video.duration || 0 };
			},
			/**
			 * S4.3's loop-at-end. Routed through attemptPlay rather than a bare
			 * play().catch() -- see attemptPlay's own note. Preserves whatever
			 * mute state is currently in effect rather than forcing either.
			 */
			restart: function () {
				try {
					video.currentTime = 0;
				} catch (e) { /* Not seekable yet; play() from wherever it is. */ }

				attemptPlay(video, ctx, video.muted);
			},
			/**
			 * Reuse this element for a different post by swapping its src.
			 *
			 * VALIDATE BEFORE MUTATING -- the (c) half of the four YouTube
			 * shell defects, fixed here rather than carried. There, `recycle()`
			 * writes `id` / `wantPlaying` / `everPlayed` BEFORE the capability
			 * guard runs, so on failure the adapter's identity points at the
			 * new post while the frame still holds the old video: the `false`
			 * return correctly drives the fallback, but the instance it leaves
			 * behind is already lying about what it contains.
			 *
			 * So every reason to refuse is checked first, and nothing is
			 * written until the answer is yes. The `false` return is kept --
			 * it is what drives the caller's rebuild.
			 *
			 * @param {Object} next The incoming slide.
			 *
			 * @return {boolean} Whether the element was reused.
			 */
			recycle: function (next) {
				if (destroyed) {
					return false;
				}

				if (! next || next.unplayable || ! next.videoSrc) {
					return false;
				}

				// Only NOW does anything change.
				video.pause();
				video.removeAttribute('poster');

				if (next.poster) {
					video.poster = next.poster;
				}

				video.src = next.videoSrc;
				video.preload = 'metadata';
				video.muted = true;
				video.load();

				return true;
			},
			destroy: function () {
				destroyed = true;

				try {
					video.pause();
					// Dropping the node alone leaves the browser holding an
					// open connection for the media; removing the src and
					// re-loading is what actually releases it.
					video.removeAttribute('src');
					video.load();
				} catch (e) { /* Best effort -- teardown must not throw. */ }

				if (video.parentNode) {
					video.parentNode.removeChild(video);
				}
			}
		};
	}

	/* ═══════════════ Tier 2 -- the FB embed, as a click-to-play card ═════════
	 *
	 * THIS IS THE MOST FACEBOOK-NOVEL SURFACE IN THE FILE, and the one the
	 * design review should spend its time on. Four facts shape it, all of them
	 * measured or verified rather than assumed:
	 *
	 * 1. THE FRAME HAS ZERO CONTROL SURFACE. The Facebook JS SDK is never
	 *    loaded on the front end -- verified by absence across `inc/`,
	 *    `templates/` and `assets/js/cff-scripts.js`: no connect.facebook.net,
	 *    no sdk.js, no FB.init, no FB.Event, no fb-root, no subscribe(). The
	 *    `class="fb-video"` wrappers the render path emits are inert
	 *    decoration; one of them even stamps `fb-xfbml-state="rendered"`, the
	 *    marker that tells an SDK NOT to parse the node. So `caps` is NO_CAPS
	 *    and that is a structural fact, not a conservative guess.
	 *
	 * 2. SO IT IS RENDERED HONESTLY AS CLICK-TO-PLAY, WITH NO FAKE CONTROLS.
	 *    A mute button, a progress bar or a play/pause glyph over this tier
	 *    would be a control that silently does nothing -- exactly what S6.2
	 *    forbids ("users MUST NOT be able to press a control that silently does
	 *    nothing"). The card shows the poster and ONE affordance that does
	 *    something real: load Facebook's own player. Everything the session
	 *    chrome cannot support goes disabled, not inert (see updateChrome).
	 *
	 *    The click-to-play shape earns a second thing for free: the frame is a
	 *    third-party request, and not making it until the visitor asks keeps
	 *    S5.3's consent posture intact on a tier the plugin's CDN gate does not
	 *    inspect. A speculative iframe on activation would be a third-party
	 *    load preceding the visitor's intent.
	 *
	 * 3. `&height=` MUST BE SIZED TO THE STAGE. The seam's cached embed src is
	 *    Facebook's own generated wrapper and carries `&width=540` with no
	 *    height. `plugins/video.php` sizes its DOCUMENT from those params, not
	 *    from the iframe box -- so a 390x693 stage with the cached width paints
	 *    the player at its own aspect inside the frame and leaves the remainder
	 *    TRANSPARENT: measured as a 151px band on a 390-wide stage, through
	 *    which the black slide behind shows. It reads as a rendering bug. So
	 *    both params are rewritten to the measured stage box at construction.
	 *
	 * 4. THE FRAME'S OWN TOP BAR NAVIGATES AWAY, so it is MASKED. The embed
	 *    document paints a Facebook title/attribution bar across its top, and
	 *    that bar is a link: a tap there leaves the site for facebook.com in
	 *    the middle of a swipe session, with no warning and no way back into
	 *    the viewer. `show_text=false` suppresses the caption block below the
	 *    video but NOT that bar, and there is no parameter that does. Since the
	 *    frame is cross-origin we cannot style it, so the only available fix is
	 *    geometric: an opaque, pointer-eating strip of our own over that band.
	 *
	 * ACCEPTED LIMITATION, STATED RATHER THAN HIDDEN: while the frame is
	 * playing it owns pointer input over its own box, so a vertical swipe
	 * STARTED on the frame body does not navigate the track. That is what a
	 * zero-capability cross-origin transport costs. Navigation stays available
	 * from the arrow keys, the desktop chevrons, the masked band and the
	 * gutters either side of the frame. Naming it is more useful to the design
	 * review than papering over it, and the alternative -- covering the frame
	 * with our gesture layer -- would make Facebook's own controls unreachable
	 * and leave the tier with no way to play at all.
	 */

	/**
	 * Rewrite or add query parameters on a url, safely.
	 *
	 * WRITTEN OUT RATHER THAN CONCATENATED, because the plugin's own attempt at
	 * this is a recorded landmine: `assets/js/cff-scripts.js:5611-5614` appends
	 * `'?autoplay=1' + "&mute=0"` to a url that ALREADY contains `?` (the
	 * cached wrapper is `plugins/video.php?href=...&width=540`), producing a
	 * double-`?` that Facebook cannot parse; and `:2290` / `:2294` emit a stray
	 * space after `href=`. Do not infer from that code that FB embed autoplay
	 * works today -- whether these params take effect at all is a must-measure
	 * (plan S5 item M2), and this function's job is only to make the url
	 * well-formed so the measurement is of Facebook's behaviour rather than of
	 * our own malformed string.
	 *
	 * Params are decoded and re-encoded, so the cached `href` -- itself a
	 * url-encoded permalink -- round-trips rather than being double-encoded.
	 *
	 * @param {string} url    The base url.
	 * @param {Object} params Params to set. A null value REMOVES the key.
	 *
	 * @return {string}
	 */
	function withParams(url, params) {
		var parts = String(url).split('#');
		var hash  = parts.length > 1 ? '#' + parts.slice(1).join('#') : '';
		var head  = parts[0].split('?');
		var base  = head[0];
		var query = head.slice(1).join('?');

		var pairs = [];
		var seen  = {};

		(query ? query.split('&') : []).forEach(function (pair) {
			if (! pair) {
				return;
			}

			var eq    = pair.indexOf('=');
			var key   = eq === -1 ? pair : pair.slice(0, eq);
			var value = eq === -1 ? '' : pair.slice(eq + 1);

			if (Object.prototype.hasOwnProperty.call(params, key)) {
				seen[ key ] = true;

				if (params[ key ] === null) {
					return;
				}

				value = window.encodeURIComponent(String(params[ key ]));
			}

			pairs.push(key + '=' + value);
		});

		Object.keys(params).forEach(function (key) {
			if (seen[ key ] || params[ key ] === null) {
				return;
			}

			pairs.push(key + '=' + window.encodeURIComponent(String(params[ key ])));
		});

		return base + (pairs.length ? '?' + pairs.join('&') : '') + hash;
	}

	/**
	 * Create the tier-2 adapter: a poster card that loads Facebook's own player
	 * on an explicit tap.
	 *
	 * @param {Object} slide The normalised slide.
	 * @param {Object} ctx   { stage, emit }.
	 *
	 * @return {Object} An S9.1 instance.
	 */
	function createEmbedCard(slide, ctx) {
		var wrap = el('div', 'cff-swipeview-embedcard');
		var destroyed = false;
		var frame = null;
		var startTimer = null;

		if (slide.poster) {
			var poster = el('img', 'cff-swipeview-embedcard-poster', { alt: '', 'aria-hidden': 'true' });
			poster.src = slide.poster;
			poster.loading = 'lazy';
			wrap.appendChild(poster);
			preloadPoster(slide.poster);
		}

		// The ONE real affordance. A <button> rather than a styled div so it
		// arrives focusable, Enter- and Space-activated, and named -- and so
		// S6.3's centre hit-test has a genuine control to probe.
		var trigger = el('button', 'cff-swipeview-embedcard-play', {
			type: 'button',
			'aria-label': 'Play this Reel in Facebook’s player'
		});
		trigger.appendChild(buildControlIcon('play', 34));

		var label = el('span', 'cff-swipeview-embedcard-label');
		// textContent, never markup (S12). The copy says what will happen
		// rather than implying our own player: the visitor is about to get
		// Facebook's frame, with Facebook's controls.
		label.textContent = 'Play in Facebook’s player';

		wrap.appendChild(trigger);
		wrap.appendChild(label);

		/**
		 * Build the frame, sized to the measured stage.
		 *
		 * @return {void}
		 */
		function mountFrame() {
			if (destroyed || frame) {
				return;
			}

			// S12 -- an identifier interpolated into an embed url MUST be
			// validated against an expected shape before use. The seam already
			// host-validated this value; re-checking here means a future
			// emitter on the same attribute cannot hand this file a frame src
			// pointing anywhere else.
			if (! isFacebookUrl(slide.embed)) {
				ctx.emit('error', { reason: 'embed-src-rejected' });
				return;
			}

			// Fact 3: size the DOCUMENT to the stage, not just the box. The
			// rect is read at mount time rather than at create time because
			// the stage is only laid out once the slot is positioned, and a
			// rotation between the two would otherwise bake a stale height.
			var rect = ctx.stage.getBoundingClientRect();
			var width  = Math.max(1, Math.round(rect.width));
			var height = Math.max(1, Math.round(rect.height));

			frame = el('iframe', 'cff-swipeview-embedcard-frame', {
				title: 'Facebook Reel',
				scrolling: 'no',
				frameborder: '0',
				allowfullscreen: 'true',
				allow: 'autoplay; encrypted-media; picture-in-picture; clipboard-write',
				referrerpolicy: 'strict-origin-when-cross-origin',
				// A11y: the frame's own document is a separate tab-order that
				// the viewer's focus trap cannot see into or cycle out of, so
				// it is sealed OUT of the trap rather than fought with. The
				// tier's real action -- the permalink CTA -- stays in the trap.
				tabindex: '-1'
			});

			frame.src = withParams(slide.embed, {
				width: width,
				height: height,
				// The visitor just tapped, so this activation genuinely carries
				// gesture credit. The frame's initial state is settable at
				// construction even though nothing is controllable afterwards,
				// which is how S4.2's "explicit choice persists across slides"
				// is honoured on a tier whose mute control is correctly
				// disabled.
				autoplay: '1',
				mute: userMuted ? '1' : '0',
				show_text: 'false'
			});

			// S9.1 + S5.2's accepted limitation: a cross-origin frame fires
			// `load` even for an error document, so `playing` here is
			// optimistic BY NECESSITY -- there is no other observable. Emitting
			// it is what lets a genuinely-working embed disarm its own watchdog
			// instead of being escalated away every time.
			frame.addEventListener('load', function () {
				if (destroyed) {
					return;
				}

				ctx.emit('playing', { muted: userMuted });
			});

			wrap.appendChild(frame);

			// Fact 4: the mask goes in AFTER the frame so it stacks above it
			// without needing a z-index that the track's transform would trap.
			// aria-hidden and no tabindex: it is a geometric guard, not a
			// control, and there is nothing here for assistive tech to do.
			wrap.appendChild(el('div', 'cff-swipeview-embedcard-mask', { 'aria-hidden': 'true' }));

			wrap.classList.add('cff-swipeview-embedcard-playing');
		}

		trigger.addEventListener('click', function (event) {
			event.preventDefault();
			// The tap belongs to this control, not to the stage's play/pause.
			event.stopPropagation();
			mountFrame();
		});

		ctx.stage.appendChild(wrap);

		/*
		 * THE CARD IS A VALID PRESENTATION, so it reports started -- otherwise
		 * the S5.2 start watchdog would escalate a perfectly good click-to-play
		 * offer away after 4 seconds and the tier could never be reached.
		 *
		 * DEFERRED BY A TICK, AND GUARDED -- this is the (a) half of the four
		 * YouTube shell defects, fixed rather than carried. The deferral itself
		 * is necessary: create() is called as `slot.inst = factory.create(...)`,
		 * so a synchronous emit runs BEFORE the assignment completes and the
		 * handler reads a slot whose `inst` is still the previous, already
		 * destroyed instance.
		 *
		 * But YouTube's version defers with NO destroyed flag and NO stored
		 * timer handle, and its `destroy()` only removes the node. The emit
		 * closure then reads the shared, mutable slot record LIVE, so a dead
		 * adapter writes to whatever now occupies that slot and attributes to
		 * the new index. The consequence is worse than a mis-attribution: the
		 * landing branch sets `playingSeen = true` and the start watchdog
		 * early-returns on `if (slot.playingSeen) return`, so THE NEXT
		 * OCCUPANT'S WATCHDOG IS NEVER ARMED and a genuinely stalled slide sits
		 * behind a hidden spinner forever.
		 *
		 * Facebook makes it far more likely, which is why it is fixed here: a
		 * three-tier chain tears adapters down on every .mpd, every absent
		 * source and every expired mp4 -- the aged-cache common case.
		 *
		 * The fix is both halves plus an identity check: the handle is stored
		 * so destroy() can clear it, the flag is checked at fire time in case
		 * the clear raced, and ctx.emit itself refuses to deliver from an
		 * instance the slot no longer holds (see makeEmitter).
		 */
		startTimer = window.setTimeout(function () {
			startTimer = null;

			if (destroyed) {
				return;
			}

			ctx.emit('playing', { muted: true });
		}, 0);

		return {
			name: 'fb-embed-card',
			caps: NO_CAPS,
			// Callable no-ops. Capabilities are optional; the METHOD SURFACE is
			// not -- the shell calls play(), pause() and destroy()
			// unconditionally, and only setMuted / isMuted / isPlaying /
			// progress / restart are presence-checked. A zero-cap adapter that
			// omitted play() would throw on activation.
			play: function () {},
			pause: function () {
				// Nothing to pause before the tap; after it, the frame owns
				// playback and we have no handle on it. Dropping the frame on
				// pause would restart it on return, which S4.4's
				// never-reparent rule exists to prevent -- so a neighbour that
				// was tapped genuinely keeps playing until it is recycled or
				// the viewer closes. Recorded for the design review: this is
				// the one place a neighbour can still be audible, and it is a
				// property of the transport, not a choice.
			},
			isPlaying: function () {
				return !! frame;
			},
			isMuted: function () {
				// The frame's real state is unobservable. Reporting `true`
				// keeps the chrome from claiming sound is on when it cannot
				// know -- and the mute control is disabled on this tier
				// anyway, so nothing acts on the answer.
				return true;
			},
			progress: function () {
				return null;
			},
			destroy: function () {
				destroyed = true;

				if (startTimer !== null) {
					window.clearTimeout(startTimer);
					startTimer = null;
				}

				if (wrap.parentNode) {
					wrap.parentNode.removeChild(wrap);
				}
			}
		};
	}

	/* ═══════════════ Tier 3 -- poster plus permalink (terminal) ══════════════
	 *
	 * Also the shape a consent-blocked presentation takes, which is why it is
	 * terminal (S5.3).
	 *
	 * MORE DURABLE THAN IT LOOKS, and less durable than YouTube's. CFF_Resizer
	 * localises feed images into the uploads directory, so a poster can outlive
	 * the CDN url it came from -- while video bytes are never localised. That
	 * asymmetry is the most important operational fact about this viewer: your
	 * poster will probably outlive your mp4. But unlike YouTube's i.ytimg.com
	 * stills, Facebook's posters are NOT categorically non-expiring, so this
	 * tier can still rot on an install where resizing never ran.
	 *
	 * WHICH IS WHY THE POSTER-LESS STATE IS RENDERED DELIBERATELY. A slide with
	 * neither mp4 nor poster is a black rectangle with a link, and the seam
	 * reports that honestly (poster is thin in the data -- present on only 2 of
	 * 7 videos-edge fixture items, and absent entirely from the timeline DASH
	 * reel). A viewer that discovered this state at runtime would show an
	 * unexplained black slide; this one says what happened.
	 */

	/**
	 * @param {Object} slide The normalised slide.
	 * @param {Object} ctx   { stage, emit }.
	 *
	 * @return {Object} An S9.1 instance.
	 */
	function createPosterTerminal(slide, ctx) {
		var wrap = el('div', 'cff-swipeview-terminal');
		var destroyed = false;
		var startTimer = null;

		if (slide.poster) {
			var poster = el('img', 'cff-swipeview-terminal-poster', { alt: '', 'aria-hidden': 'true' });

			// The terminal tier paints a REAL poster with object-fit, so it has
			// a genuine letterbox case -- and it is the tier whose own opaque
			// background used to sit over the backdrop (see the CSS audit).
			poster.addEventListener('load', function () {
				applyFit(ctx.slot);
			});
			poster.src = slide.poster;
			poster.loading = 'lazy';
			wrap.appendChild(poster);
		} else {
			// The deliberate black slide. It carries a class of its own so the
			// geometry suite can assert the state exists and is laid out,
			// rather than the absence being indistinguishable from a bug.
			wrap.classList.add('cff-swipeview-terminal-noposter');
		}

		/*
		 * The scrim, as its own element rather than a background on the wrap.
		 * The wrap's own background had to go for the letterbox paint order
		 * (see the CSS audit), and this tier still needs something behind its
		 * text to make 13px legible over an arbitrary video frame -- so the
		 * two jobs are separated: the frame provides black, this provides
		 * contrast, and neither hides the backdrop.
		 *
		 * Appended AFTER the poster so it sits over it, and BEFORE the message
		 * and the pill so they sit over it in turn.
		 */
		wrap.appendChild(el('div', 'cff-swipeview-terminal-scrim', { 'aria-hidden': 'true' }));

		var message = el('p', 'cff-swipeview-terminal-msg');
		message.textContent = slide.poster
			? 'This Reel can’t be played here.'
			: 'This Reel can’t be played here, and its preview image is no longer available.';
		wrap.appendChild(message);

		/*
		 * The terminal tier's required "View on Facebook" action (S7.1: it is
		 * this tier's ONLY action, so it must be inside the focus trap). It
		 * uses the SAME normalised permalink the caption CTA uses -- an adapter
		 * MUST NOT derive its own platform url (S9.1).
		 *
		 * A permalink can legitimately be absent: CFF_Swipe_View refuses the
		 * `plugins/video.php` wrapper that 1909's accessor returns as a
		 * graceful degrade, because a wrapper is an embed frame rather than a
		 * permalink and sending a visitor there from a "View on Facebook"
		 * affordance is not what the affordance promises. So the link keeps an
		 * aria-disabled fallback: there is nothing else on this tier for the
		 * space to close up around.
		 */
		var href = isFacebookUrl(slide.permalink) ? slide.permalink : '';
		var link = el('a', 'cff-swipeview-terminal-link', { target: '_blank', rel: 'noopener noreferrer' });
		link.href = href || '#';

		if (! href) {
			link.setAttribute('aria-disabled', 'true');
		}

		/*
		 * "Open on Facebook", styled exactly like the top-row CTA (rule 1.19)
		 * but on its OWN class -- and the glyph makes it read as the same
		 * affordance rather than as a bare text link.
		 *
		 * The wording differs from the top row's "View on Facebook"
		 * deliberately: on this tier the visitor cannot watch the Reel here at
		 * all, so "Open" states that leaving is the point rather than offering
		 * a second way to see the same thing.
		 */
		link.appendChild(buildControlIcon('facebook', 16));

		var linkLabel = el('span', 'cff-swipeview-terminal-link-label');

		linkLabel.textContent = 'Open on Facebook';
		link.appendChild(linkLabel);
		wrap.appendChild(link);

		ctx.stage.appendChild(wrap);

		// Same deferral, same two guards, same reason as the embed card's.
		startTimer = window.setTimeout(function () {
			startTimer = null;

			if (destroyed) {
				return;
			}

			ctx.emit('playing', { muted: true });
		}, 0);

		return {
			name: 'poster-terminal',
			caps: NO_CAPS,
			play: function () {},
			pause: function () {},
			isPlaying: function () { return true; },
			isMuted: function () { return true; },
			progress: function () { return null; },
			destroy: function () {
				destroyed = true;

				if (startTimer !== null) {
					window.clearTimeout(startTimer);
					startTimer = null;
				}

				if (wrap.parentNode) {
					wrap.parentNode.removeChild(wrap);
				}
			}
		};
	}

	/**
	 * The chain (spec S5.1). Three tiers, per the published Facebook adapter
	 * sketch in Instagram's swipe-view reference.
	 *
	 * `canPlay` is the up-front decline (S5.4): tier 1 refuses a source the
	 * cache already knows is unplayable -- a .mpd manifest or an absent
	 * source, resolved server-side by 1909's is_known_unplayable_source() --
	 * rather than paying a visible failed-load round-trip per slide. Declining
	 * is NOT a failure and MUST NOT emit a fallback event.
	 *
	 * Tier 2 is available on the VIDEOS EDGE ONLY, and by absence rather than
	 * by a check: `embed_html` is never requested and never cached on the
	 * timeline edge, so the seam simply emits no embed attribute there and
	 * `canPlay` reads false. A timeline tier 2 would have to be
	 * PERMALINK-BUILT, which puts it inside S5.3's rule -- a permalink-built
	 * embed is not a CDN asset, `blocking_cdn()` never inspects it, and the
	 * plugin's own GDPR gate does not discharge it. This prototype does not
	 * build one.
	 */
	var CHAIN = [
		{
			name: 'native-video',
			canPlay: function (slide) { return ! slide.unplayable && !! slide.videoSrc; },
			create: createNativeVideo
		},
		{
			name: 'fb-embed-card',
			canPlay: function (slide) { return isFacebookUrl(slide.embed); },
			create: createEmbedCard
		},
		{
			name: 'poster-terminal',
			canPlay: function () { return true; },
			create: createPosterTerminal
		}
	];

	/* ═══════════════════ Three-slot window (spec S4.4) ═══════════════════
	 *
	 * Exactly three slots (or fewer, for a short track): the active slide and
	 * one either side. Slots are FIXED DOM NODES reused by index, positioned
	 * with `top: index * 100%`, so a slot's DOM position never changes and
	 * "never reparented" is structurally true rather than a rule someone has to
	 * remember.
	 *
	 * ARCHITECTURE DECISION, RECORDED: three slots per the plan's S3.1
	 * recommendation, consistent with YouTube. The staged Maintainer call on
	 * three-slots-vs-render-all (spec S4.4's open conflict, smash-ops PR 34)
	 * REMAINS OPEN -- production adopts its outcome. S4.4's adjacent pre-warm
	 * is deliberately NOT built: it is prototype-optional / production-required,
	 * and Facebook is the first plugin in the fleet where it genuinely binds
	 * (pre-warm applies only to a direct HTMLMediaElement transport, which
	 * YouTube's tier 1 is not). Neighbours here are RENDERED but never playing,
	 * with no media pre-warm.
	 *
	 * One consequence of not pre-warming, and it is the reason the neighbour
	 * isolation rule below is YouTube's rather than Instagram's: the two
	 * siblings chose opposite rules, and Instagram's blanket discard is
	 * mandatory precisely BECAUSE it pre-warms. With nothing warmed
	 * speculatively here, a neighbour's error is a real fact about a slide the
	 * visitor is about to reach, and having its terminal tier ready before they
	 * arrive is worth more than the attribution purity. The moment this
	 * prototype grows pre-warm, that trade inverts and S4.4's discard rule
	 * applies unchanged -- so the escalation path below is written to make that
	 * a one-line change (see onAdapterEvent).
	 */

	/**
	 * @return {void}
	 */
	function buildSlots() {
		var track = session.dom.track;
		var count = Math.min(session.slides.length, WINDOW_RADIUS * 2 + 1);
		var i;

		while (track.firstChild) {
			track.removeChild(track.firstChild);
		}

		session.slots = [];

		for (i = 0; i < count; i++) {
			/*
			 * `role="group"` is REQUIRED here, not decoration -- and the
			 * behavioural suite is what proved it.
			 *
			 * A slot carries both `aria-roledescription` and, from
			 * assignSlot(), an `aria-label` ("Reel 2 of 5"). BOTH attributes
			 * are PROHIBITED on an element with no role: a role-less div maps
			 * to ARIA `generic`, where neither is allowed and both are
			 * unreliably exposed. The first run of tests/behavioural/viewer.js
			 * caught exactly that -- its "no role-less div carries an
			 * aria-label" sweep named these two slots.
			 *
			 * `group` is also the correct answer rather than merely a legal
			 * one: it is the ARIA carousel pattern (each slide is a `group`
			 * with an `aria-roledescription` and an accessible name), so the
			 * label describes a container the visitor is moving between.
			 *
			 * Note this is the OPPOSITE call from the counts cluster, which
			 * deliberately stays role-less and drops its aria-label in favour
			 * of an sr-only summary. The difference is what the label is FOR: a
			 * slot's label names a container, where a group is right; the
			 * counts cluster's would name a value already spelled out by its
			 * children, and `group` there makes AT read the digits twice.
			 */
			var slotEl = el('div', 'cff-swipeview-slot', {
				role: 'group',
				'aria-roledescription': 'Reel'
			});
			/*
			 * Rule 1.1's stage row -- the per-slot half. The frame and the
			 * per-post rail column are FLEX SIBLINGS inside it, which is what
			 * makes them centre together (rule 1.1) and puts the rail outside
			 * the frame (rule 1.3) with no `right:` arithmetic anywhere.
			 *
			 * The session-level twin of this row is built in buildOverlay().
			 * Both rows are `position: absolute; inset: 0` over their own
			 * container and both hold a 44px rail column on desktop, so the
			 * frame resolves to the SAME box in each -- which is the property
			 * the geometry suite asserts rather than assumes.
			 */
			var stageRow = el('div', 'cff-swipeview-stagerow');
			var stage    = el('div', 'cff-swipeview-stage');
			var railCol  = el('div', 'cff-swipeview-railcol');

			/*
			 * S6.1's loading affordance: a slide that has been activated but
			 * has not reported `playing` shows this rather than a blank frame.
			 *
			 * Mounted INSIDE the frame, not as a sibling of the row. It is
			 * chrome, and rule 1.2/AC 2's anchoring model is frame-anchored --
			 * left on the slot it would centre on the WINDOW, which on a
			 * letterboxed desktop puts the spinner on the backdrop pillars
			 * instead of on the video it describes. The frame is
			 * `position: relative`, so it is already the containing block.
			 */
			var loader = el('div', 'cff-swipeview-loader', { 'aria-hidden': 'true' });
			loader.appendChild(el('i', 'cff-swipeview-spinner'));

			/*
			 * IG-1's bottom scrim: 42% of the frame's height, inside the frame,
			 * under the bottom row. Appended BEFORE the loader and before the
			 * per-slide chrome so document order puts it beneath both, and it
			 * carries `z-index: 1` so it also sits under the media's own
			 * stacking level rather than over it.
			 *
			 * There is deliberately NO TOP scrim -- the top row carries its own
			 * text-shadow instead, because a second gradient up there fights
			 * the clean top edge that removing the wordmark created.
			 */
			/*
			 * The letterbox backdrop, FIRST in the stage so every tier's media
			 * paints over it. It is deliberately a stage child rather than a
			 * child of any tier's own wrapper: the fit question is the FRAME's,
			 * and tier 1 and tier 3 both have a genuine letterbox case.
			 */
			var backdrop = el('div', 'cff-swipeview-backdrop', { 'aria-hidden': 'true' });
			var scrim = el('div', 'cff-swipeview-scrim', { 'aria-hidden': 'true' });

			stage.appendChild(backdrop);
			stage.appendChild(scrim);
			stage.appendChild(loader);
			stageRow.appendChild(stage);
			stageRow.appendChild(railCol);
			slotEl.appendChild(stageRow);
			track.appendChild(slotEl);

			session.slots.push({
				el: slotEl,
				stageRow: stageRow,
				stage: stage,
				railCol: railCol,
				backdrop: backdrop,
				scrim: scrim,
				loader: loader,
				index: null,
				inst: null,
				tier: -1,
				// THE INVARIANT: always a non-null caps object. Never assigned
				// anywhere but setSlotCaps().
				caps: NO_CAPS,
				// §4.4 / AC 28: set per assignment; see assignSlot().
				warm: false,
				watchdog: null,
				stallWatchdog: null,
				playingSeen: false,
				chromeEl: null,
				lastEscalationTrigger: null
			});
		}
	}

	/**
	 * THE ONE ASSIGNMENT SEAM for `slot.caps` -- the (d) fix.
	 *
	 * YouTube's shell has ten `slot.caps` consumers: five defend with
	 * `|| NO_CAPS` and five trust it bare. The ambiguity exists because the
	 * invariant was never stated, and the five defenders are in fact DEAD CODE
	 * -- every write site there assigns a non-null object, so `slot.caps` is
	 * never nullish. The genuinely reachable null is `slot` ITSELF, which
	 * `slotForIndex()` returns whenever no slot holds the current index, and
	 * the two bare sites were missing exactly that guard.
	 *
	 * So the convention here is: normalise in one place, state the invariant,
	 * drop every `|| NO_CAPS` fallback, and put the `!slot` guard where the
	 * real null is. Every read site below therefore reads `slot.caps.mute`
	 * bare, after checking `slot`.
	 *
	 * @param {Object}      slot The slot record.
	 * @param {Object|null} caps The adapter's reported caps, if any.
	 *
	 * @return {void}
	 */
	function setSlotCaps(slot, caps) {
		slot.caps = (caps && typeof caps === 'object') ? caps : NO_CAPS;
	}

	/**
	 * @return {Array<number>} The indices the window should hold.
	 */
	function desiredIndices() {
		var out = [];
		var i;

		for (i = session.index - WINDOW_RADIUS; i <= session.index + WINDOW_RADIUS; i++) {
			if (i >= 0 && i < session.slides.length) {
				out.push(i);
			}
		}

		return out;
	}

	/**
	 * Assign the window's indices to slots, KEEPING any slot that already holds
	 * a wanted index. That keep is what makes a one-step back-swipe instant,
	 * and it is also what makes recycling possible at all.
	 *
	 * @return {void}
	 */
	function syncWindow() {
		var desired = desiredIndices();
		var keep = {};
		var free = [];

		session.slots.forEach(function (slot) {
			if (slot.index !== null && desired.indexOf(slot.index) !== -1 && ! keep[ slot.index ]) {
				keep[ slot.index ] = slot;
				return;
			}

			free.push(slot);
		});

		desired.forEach(function (index) {
			if (keep[ index ]) {
				return;
			}

			var slot = free.shift();

			if (! slot) {
				return;
			}

			assignSlot(slot, index);
			keep[ index ] = slot;
		});

		/*
		 * THE RAIL'S CONTENT FOLLOWS THE WINDOW, and this is the only place it
		 * is refreshed.
		 *
		 * syncWindow() is the right owner for the same reason activateCurrent()
		 * owns `warm`: it is the function that runs whenever the window moves,
		 * on EVERY navigation path (wheel, keyboard, both chevrons, a drag
		 * commit) and on open(). Hanging the refresh off assignSlot() instead
		 * would miss the case syncWindow() exists to handle -- a slot whose
		 * index is still in the window is KEPT, never re-assigned, so
		 * navigating onto an already-warm neighbour would leave the rail
		 * showing the slide the visitor just left.
		 *
		 * LAST in this function, after the assignment loop, so the slide it
		 * reads is the one the window has settled on. And synchronous here, in
		 * navigate()'s own call stack alongside moveTrack(true) -- which is
		 * what puts the content swap in the same paint as the transform's
		 * start. See updateRail().
		 */
		updateRail();
	}

	/**
	 * @param {number} index Track index.
	 *
	 * @return {Object|null} The slot holding it, or null.
	 */
	function slotForIndex(index) {
		var i;

		if (! session) {
			return null;
		}

		for (i = 0; i < session.slots.length; i++) {
			if (session.slots[ i ].index === index) {
				return session.slots[ i ];
			}
		}

		return null;
	}

	/**
	 * @return {Object|null} The slot holding the active slide.
	 */
	function activeSlot() {
		return session ? slotForIndex(session.index) : null;
	}

	/**
	 * Point a slot at a track index.
	 *
	 * @param {Object} slot  The slot record.
	 * @param {number} index Track index.
	 *
	 * @return {void}
	 */
	function assignSlot(slot, index) {
		var slide = session.slides[ index ];

		/*
		 * §4.4 / AC 28's PRE-WARM, and what it actually consists of here.
		 *
		 * `warm` means "this slot is an adjacent neighbour, not the slide the
		 * visitor is looking at". The warming itself is not a separate
		 * mechanism: a neighbour's tier-1 adapter is instantiated by the
		 * normal path with `preload = 'metadata'`, muted, and never played --
		 * which IS §4.4's pre-warm (metadata ceiling, created muted and
		 * paused). Facebook is the first plugin in the fleet where this binds
		 * at all, because pre-warm only means anything for a direct
		 * HTMLMediaElement transport and YouTube's tier 1 is an iframe.
		 *
		 * ±1 ADJACENCY ONLY, and RELEASE IS STRUCTURAL. The window is three
		 * fixed slots reused by index, so a slide leaving ±1 has its slot
		 * REASSIGNED -- which destroys the old adapter through
		 * instantiateTier()'s teardown, closing the media connection. AC 28's
		 * "warmed elements MUST NOT accumulate" is therefore true by
		 * construction rather than by a cleanup pass that could be forgotten;
		 * there is no code path that can hold a fourth <video>.
		 */
		slot.warm = index !== session.index;

		slot.index = index;
		// Positioned BY INDEX, not by DOM order -- the track translates by
		// whole slide heights and a slot's DOM position never changes.
		slot.el.style.top = (index * 100) + '%';
		slot.el.setAttribute('data-index', String(index));
		slot.el.setAttribute('aria-label', 'Reel ' + (index + 1) + ' of ' + session.slides.length);

		slot.playingSeen = false;
		clearWatchdogs(slot);

		/*
		 * Reset the letterbox before the new slide's media loads. Without this
		 * a contained slide leaves `data-fit` and its blurred poster behind,
		 * so the next slide -- which may be a perfectly 9:16 video -- paints
		 * inside two bands of the PREVIOUS slide's backdrop until its own
		 * metadata arrives. applyFit() then sets it correctly, so the artefact
		 * is transient, which is exactly the kind that survives review.
		 */
		slot.stage.removeAttribute('data-fit');

		if (slot.backdrop) {
			slot.backdrop.style.display = 'none';
			slot.backdrop.style.backgroundImage = '';
		}

		// Per-slide chrome is rebuilt (cheap, text-only DOM); the PLAYER is
		// what must survive.
		if (slot.chromeEl && slot.chromeEl.parentNode) {
			slot.chromeEl.parentNode.removeChild(slot.chromeEl);
		}

		/*
		 * MOUNTED INSIDE THE FRAME, not on the slot. AC 2's anchoring model:
		 * on a letterboxed desktop a slot-mounted row puts the byline and
		 * caption on the backdrop pillars rather than on the video they
		 * describe. The frame is `position: relative`, so it is already the
		 * containing block, and its `overflow: hidden` is what keeps a long
		 * expanded caption inside the rounded frame.
		 */
		slot.chromeEl = buildSlideChrome(slide);
		slot.stage.appendChild(slot.chromeEl);

		/*
		 * NO RAIL IS BUILT HERE ANY MORE, and `slot.railCol` stays EMPTY on
		 * purpose — see buildOverlay() for why the rail became one
		 * session-level element on 2026-09-10.
		 *
		 * THE COLUMN ITSELF IS NOT DELETED, and that is load-bearing rather
		 * than laziness. On desktop it is a 44px flex ITEM in this slot's
		 * stage row, and its width is the only reason this row's frame lands
		 * on exactly the same box as the session chrome row's. Remove it and
		 * every slot's video shifts 60px (44 + the 16px stage gap) away from
		 * the mute chip, the CTA and the progress bar that are supposed to sit
		 * on it — the same 30px-class drift the session column's own comment
		 * records, and what the geometry suite's "both rows resolve
		 * identically" assertion exists to catch. It is a SPACER now.
		 *
		 * The old comment here explained that the rail had to be built ABOVE
		 * the recycle early-return, because the recycle path skips everything
		 * after it and a rail mounted below would show the PREVIOUS slide's
		 * counts against the new video. That hazard has not gone away — it has
		 * MOVED, and it is worth saying where: the rail is now refreshed by
		 * updateRail() from syncWindow(), which runs on every window move
		 * regardless of which tier path assignSlot() takes. So the recycle
		 * return can no longer strand it, because the refresh is not inside
		 * this function at all.
		 */

		// The recycle path: this slot already holds a tier-1 element and the
		// incoming slide is playable on tier 1, so swap its src in place rather
		// than rebuilding the element and re-binding six listeners.
		//
		// The guard order matters and is the (c) fix's caller side: recycle()
		// validates before it mutates and returns false when it refuses, and
		// this call site treats false as "rebuild from tier 0" rather than as
		// an error. So a refusal costs one wasted call and never leaves a
		// half-updated adapter behind.
		if (slot.inst && slot.tier === 0 && slot.inst.recycle && CHAIN[0].canPlay(slide)) {
			if (slot.inst.recycle(slide) !== false) {
				setSlotCaps(slot, slot.inst.caps);
				showLoader(slot, true);
				emitAnalytics('adapter_recycled', { index: index, adapter: slot.inst.name });
				return;
			}
		}

		/*
		 * Data Saver: a WARM slot gets no media at all. The slide is still
		 * assigned, its chrome and rail are built, and its poster shows -- what
		 * is skipped is the speculative metadata fetch, which is the only part
		 * `saveData` is about. Instantiating happens for real when the visitor
		 * navigates to it and it stops being warm.
		 */
		if (slot.warm && prewarmSuppressed()) {
			slot.tier = -1;
			setSlotCaps(slot, NO_CAPS);
			showLoader(slot, false);

			return;
		}

		instantiateTier(slot, 0);
	}

	/**
	 * @param {number} tier Chain position.
	 *
	 * @return {string}
	 */
	function tierName(tier) {
		return (CHAIN[ tier ] && CHAIN[ tier ].name) || 'none';
	}

	/**
	 * @param {number} from  First tier to consider.
	 * @param {Object} slide The slide.
	 *
	 * @return {number} The tier index, or -1 when none can play it.
	 */
	function nextPlayableTier(from, slide) {
		var i;

		for (i = from; i < CHAIN.length; i++) {
			if (CHAIN[ i ].canPlay(slide)) {
				return i;
			}
		}

		return -1;
	}

	/**
	 * Build the adapter context for one instance.
	 *
	 * THE IDENTITY GUARD LIVES HERE -- the third half of the (a) fix.
	 *
	 * The two other halves (a `destroyed` flag and a stored timer handle) live
	 * inside each adapter, and they are enough for an adapter that tears itself
	 * down cleanly. This one covers the case they cannot: an emit already in
	 * flight, or a listener the browser fires during teardown, from an instance
	 * the slot no longer holds. `slot.inst !== instance` is a cheap, total
	 * answer -- it does not depend on the adapter having remembered to guard
	 * itself, which is exactly the assumption YouTube's version makes and loses
	 * on.
	 *
	 * The index is read LIVE off the slot rather than captured, and that is a
	 * measured YouTube fix worth keeping: a tier-1 element outlives its post
	 * when recycled, so one create() serves every slide that slot ever holds. A
	 * captured index goes stale on the first recycle and stays stale -- there,
	 * the symptom was `time_to_playing_ms` silently STOPPING (its
	 * `index === currentIndex` guard never matched again) rather than going
	 * wrong, which is the harder failure to notice. `boundIndex` survives only
	 * as the fallback for the window between create() and the slot's first
	 * assignment settling.
	 *
	 * @param {Object} slot       The slot record.
	 * @param {number} boundIndex The index at create time.
	 * @param {string} fromName   The adapter's name, for attribution.
	 *
	 * @return {Object} The ctx handed to create().
	 */
	function makeContext(slot, boundIndex, fromName) {
		var ctx = {
			stage: slot.stage,
			/*
			 * The slot record itself, so an adapter can ask for the letterbox
			 * fit to be re-evaluated when its media reports intrinsic
			 * dimensions. `stage` alone is not enough: applyFit() also needs
			 * the slot's backdrop element and its index, and passing three
			 * fields separately is three chances for one to go stale.
			 */
			slot: slot,
			/**
			 * @param {string} kind   The S9.1 event kind.
			 * @param {Object} detail Event detail.
			 *
			 * @return {void}
			 */
			emit: function (kind, detail) {
				if (! session) {
					return;
				}

				// The identity guard. `ctx.instance` is written by
				// instantiateTier immediately after create() returns.
				if (ctx.instance && slot.inst !== ctx.instance) {
					return;
				}

				var live = (slot.index === null) ? boundIndex : slot.index;

				onAdapterEvent(slot, live, kind, detail, fromName);
			},
			/**
			 * @return {boolean} Whether this instance's slide is the active one.
			 */
			isCurrent: function () {
				if (! session) {
					return false;
				}

				if (ctx.instance && slot.inst !== ctx.instance) {
					return false;
				}

				return slot.index === session.index;
			},
			instance: null
		};

		return ctx;
	}

	/**
	 * Tear down whatever a slot holds and instantiate the first tier from
	 * `fromTier` that can play its slide.
	 *
	 * @param {Object} slot               The slot record.
	 * @param {number} fromTier           First tier to consider.
	 * @param {string} escalationTrigger  Which S5.2 trigger caused this, if any.
	 *
	 * @return {void}
	 */
	function instantiateTier(slot, fromTier, escalationTrigger) {
		var slide = session.slides[ slot.index ];

		clearWatchdogs(slot);
		slot.playingSeen = false;

		// Destroy BEFORE clearing the stage. Dropping the node alone leaves a
		// <video> holding an open media connection and an <iframe> loaded,
		// which leaks across a long session.
		if (slot.inst) {
			slot.inst.destroy();
			slot.inst = null;
		}

		/*
		 * Clear the TIER's nodes, and ONLY those.
		 *
		 * This was a bare `while (stage.firstChild) removeChild` until chrome
		 * started living inside the frame, and it has now had to grow twice --
		 * which is the useful part of the history rather than an embarrassment.
		 *
		 *   step (a)  the loader moved into the frame (chrome is frame-anchored
		 *             per AC 2; on the slot it centred on the WINDOW, i.e. on
		 *             the backdrop pillars). The bare loop deleted it on the
		 *             first escalation, and showLoader() then toggled a class
		 *             on a detached node for the rest of the session.
		 *   step (e)  the bottom row and the scrim moved in too. Both are
		 *             rebuilt by assignSlot() BEFORE it calls this function, so
		 *             a per-node exemption for the loader alone would have
		 *             deleted the byline, the caption and the scrim on every
		 *             single slide assignment -- not just on an escalation.
		 *
		 * So the exemption is a LIST the slot owns rather than one hard-coded
		 * identity, and membership is by IDENTITY rather than by class name: a
		 * class check is a second place for the two to drift apart, and the
		 * failure mode when they do is a silently missing element rather than
		 * an error.
		 *
		 * A third instance of this shape (setControlIcon() and the mute chip's
		 * label) is fixed the same way, in that function.
		 */
		var keep = [slot.loader, slot.chromeEl, slot.scrim, slot.backdrop];
		var child = slot.stage.firstChild;

		while (child) {
			var nextChild = child.nextSibling;

			if (keep.indexOf(child) === -1) {
				slot.stage.removeChild(child);
			}

			child = nextChild;
		}

		var tier = nextPlayableTier(fromTier, slide);

		if (tier === -1) {
			// Unreachable while tier 3's canPlay returns true unconditionally,
			// but stated rather than assumed: a chain with no playable tier
			// leaves the slot empty and its loader off, not spinning forever.
			slot.tier = -1;
			setSlotCaps(slot, NO_CAPS);
			showLoader(slot, false);
			return;
		}

		slot.tier = tier;

		var factory = CHAIN[ tier ];
		// Captured so an escalation is attributed to the adapter that FAILED,
		// not to whatever replaced it. Safe to capture: the adapter identity
		// really is fixed for the life of the instance.
		var boundIndex = slot.index;
		var ctx = makeContext(slot, boundIndex, factory.name);

		slot.inst = factory.create(slide, ctx);
		ctx.instance = slot.inst;
		setSlotCaps(slot, slot.inst && slot.inst.caps);
		showLoader(slot, true);

		if (tier === CHAIN.length - 1) {
			// S11 names swipeview_terminal_tier as THE instrument for the
			// disjunctive reliability row, so the branch has to survive onto
			// this event. The trigger is passed as an ARGUMENT rather than read
			// back off the slot: YouTube read it from
			// `slot.lastEscalationTrigger`, which onAdapterEvent clears
			// immediately BEFORE calling this function, so the watchdog branch
			// always arrived as the fallback string 'error' -- one staged
			// silent stall emitted `...fallback{trigger:'watchdog'}` and, one
			// line later, `...terminal_tier{trigger:'error'}` for the SAME
			// escalation. An argument cannot be cleared out from under a read.
			emitAnalytics('swipeview_terminal_tier', {
				index: boundIndex,
				adapter: factory.name,
				trigger: fromTier === 0 ? 'initial' : (escalationTrigger || 'explicit-error')
			});
		}
	}

	/**
	 * @param {Object}  slot    The slot record.
	 * @param {boolean} visible Whether the loading affordance shows.
	 *
	 * @return {void}
	 */
	function showLoader(slot, visible) {
		if (! slot.loader) {
			return;
		}

		if (visible) {
			slot.loader.classList.add('cff-swipeview-loader-visible');
			return;
		}

		slot.loader.classList.remove('cff-swipeview-loader-visible');
	}

	/**
	 * @param {Object} slot The slot record.
	 *
	 * @return {void}
	 */
	function clearWatchdogs(slot) {
		if (slot.watchdog !== null) {
			window.clearTimeout(slot.watchdog);
			slot.watchdog = null;
		}

		// AC 25's stall watchdog is a SEPARATE slot, not a reuse of the one
		// above. They can be in flight at different times for the same slide
		// and one must not silently cancel the other -- a start watchdog armed
		// on a re-activation would otherwise clear a live stall watchdog and
		// the stall would then never escalate.
		if (slot.stallWatchdog !== null) {
			window.clearTimeout(slot.stallWatchdog);
			slot.stallWatchdog = null;
		}
	}

	/**
	 * Cancel only the STALL watchdog, leaving the start watchdog alone.
	 *
	 * Called on every sign of progress. Separate from clearWatchdogs() because
	 * progress must not disarm a start watchdog that is legitimately still
	 * counting -- `timeupdate` can fire before `playing` on some engines.
	 *
	 * @param {Object} slot The slot record.
	 *
	 * @return {void}
	 */
	function clearStallWatchdog(slot) {
		if (slot.stallWatchdog !== null) {
			window.clearTimeout(slot.stallWatchdog);
			slot.stallWatchdog = null;
		}
	}

	/**
	 * AC 25: escalate a source that WAS playing and has stopped delivering.
	 *
	 * The gap this closes. The start watchdog only arms while
	 * `!slot.playingSeen`, and S9.1's rule is that a stall shows the loading
	 * affordance and does not escalate. Together those two correct rules left a
	 * hole exactly the size of AC 25: a slide that played, then lost its
	 * source, had NO watchdog and NO escalation path. It froze on its last
	 * decoded frame with a spinner over it, indefinitely.
	 *
	 * And this is the ORDINARY case rather than an edge one, which is why the
	 * AC calls it out. Signed fbcdn URLs live ~106 hours (measured), so any
	 * cache older than ~4 days serves dead mp4s -- the terminal-tier rate is
	 * cache-age driven. A URL can also expire while a session is open, and a
	 * mid-playback range request against an expired URL 403s
	 * (`URL signature expired` -- see the evidence file) without firing
	 * `error` at all: the element just runs short of data.
	 *
	 * Armed on a stall, disarmed by progress. Only for the ACTIVE slide: a
	 * neighbour is not playing, so it cannot stall, and warmed neighbours are
	 * discarded upstream anyway (AC 28).
	 *
	 * @param {Object} slot  The slot record.
	 * @param {number} index The slot's live index.
	 *
	 * @return {void}
	 */
	function armStallWatchdog(slot, index) {
		// Never displace a live one -- a burst of `waiting` events must not
		// keep pushing the deadline out, or a genuinely dead source is never
		// declared dead.
		if (slot.stallWatchdog !== null) {
			return;
		}

		slot.stallWatchdog = window.setTimeout(function () {
			slot.stallWatchdog = null;

			if (! session || slot.index !== index || ! slot.inst) {
				return;
			}

			// Recovered while the timer ran.
			if (slot.inst.isPlaying && slot.inst.isPlaying()) {
				return;
			}

			var terminal = slot.tier >= CHAIN.length - 1;

			emitAnalytics('swipeview_playback_stalled', {
				index: index,
				adapter: slot.inst.name,
				terminal: terminal,
				phase: 'mid-session'
			});

			if (terminal) {
				// Nowhere left to go. Drop the spinner rather than leaving it
				// turning over a tier that has already reported itself as a
				// valid presentation.
				showLoader(slot, false);

				return;
			}

			slot.lastEscalationTrigger = 'mid-session-stall';
			onAdapterEvent(slot, index, 'error', { reason: 'mid-session-stall' }, slot.inst.name);
		}, STALL_TIMEOUT_MS);
	}

	/**
	 * S5.2 trigger 2 -- the start watchdog.
	 *
	 * Keys off an OBSERVED `playing` event, never off an isPlaying()-style
	 * flag: `HTMLMediaElement.paused` becomes false the instant play() is
	 * called, long before any data arrives, so a flag-based watchdog can never
	 * fire on the case it exists for. This covers the silent stall -- a media
	 * request that hangs forever emits neither an error nor playback, and
	 * nothing else would ever rescue it.
	 *
	 * On Facebook that is the aged-cache case rather than an exotic one:
	 * fbcdn media urls are signed with a window of roughly 106 hours, and the
	 * backup cache lives for a YEAR, so dead signed urls are normal and the
	 * escalation chain is mandatory rather than defensive.
	 *
	 * @param {Object} slot  The slot record.
	 * @param {number} index The index it held when armed.
	 *
	 * @return {void}
	 */
	function armStartWatchdog(slot, index) {
		clearWatchdogs(slot);

		if (slot.playingSeen) {
			return;
		}

		slot.watchdog = window.setTimeout(function () {
			slot.watchdog = null;

			if (! session || slot.index !== index || ! slot.inst) {
				return;
			}

			if (slot.playingSeen) {
				return;
			}

			var terminal = slot.tier >= CHAIN.length - 1;

			emitAnalytics('swipeview_playback_stalled', {
				index: index,
				adapter: slot.inst.name,
				terminal: terminal
			});

			if (terminal) {
				// Nowhere left to escalate. Drop the spinner rather than
				// leaving it spinning forever on a tier that has already
				// reported itself as a valid presentation.
				showLoader(slot, false);
				return;
			}

			slot.lastEscalationTrigger = 'watchdog';
			onAdapterEvent(slot, index, 'error', { reason: 'no-start' }, slot.inst.name);
		}, START_TIMEOUT_MS);
	}

	/* ═══════════════════ Adapter event routing (spec S9.1) ═══════════════════ */

	/**
	 * @param {Object} slot     The slot record.
	 * @param {number} index    The slot's live index.
	 * @param {string} kind     The S9.1 event kind.
	 * @param {Object} detail   Event detail.
	 * @param {string} fromName The reporting adapter's name.
	 *
	 * @return {void}
	 */
	function onAdapterEvent(slot, index, kind, detail, fromName) {
		if (! session) {
			return;
		}

		if (kind === 'error') {
			/*
			 * NEIGHBOUR ISOLATION -- the one port decision that depends on
			 * pre-warm, and the reason it is worth a comment rather than a
			 * line.
			 *
			 * Instagram discards ALL emissions from a warm slide as the first
			 * statement of its handler. That is mandatory THERE because it
			 * pre-warms: S4.4 is explicit that a pre-warm error MUST NOT
			 * escalate the chain and MUST NOT emit any S8 event, because
			 * letting them through counts failures no visitor ever saw and
			 * corrupts the two numbers S11 leans on hardest.
			 *
			 * This prototype pre-warms nothing (see the slot-window note), so
			 * every adapter here belongs to a slide that is rendered and, for
			 * the neighbours, one swipe away. A neighbour's dead mp4 is a real
			 * fact about a slide the visitor is about to reach, and having its
			 * terminal tier ready before they arrive is the better trade --
			 * while the S8 attribution stays on the neighbour's OWN index, so a
			 * consumer can filter it.
			 *
			 * PRE-WARM HAS NOW LANDED (AC 28), SO THAT TRADE HAS INVERTED --
			 * and the prototype's note above is left standing precisely
			 * because it predicted this and named the change.
			 *
			 * With neighbours warmed, a neighbour's error is no longer "a real
			 * fact about a slide the visitor is about to reach": it is the
			 * result of a fetch WE started speculatively, for a slide they may
			 * never open. Letting it escalate the chain and emit an S8 event
			 * counts a failure nobody saw, and corrupts the two numbers S11
			 * leans on hardest. So Instagram's blanket discard replaces
			 * YouTube's routing, exactly as S4.4 requires, and it is the early
			 * return below.
			 *
			 * What is NOT lost: the slide still escalates when the visitor
			 * actually reaches it, because activateCurrent() re-activates a
			 * slot whose media failed and the error then arrives on a slot
			 * that is no longer warm.
			 */
			if (slot.warm) {
				return;
			}

			var toTier = nextPlayableTier(slot.tier + 1, session.slides[ index ]);
			// Captured FIRST, before anything reads it: an earlier arrangement
			// of these lines in the YouTube shell shipped `trigger: undefined`
			// on every fallback event while the terminal-tier event a line
			// later read it correctly. Two events disagreeing about one
			// escalation is exactly what passing the value explicitly prevents.
			var escalationTrigger = slot.lastEscalationTrigger || 'explicit-error';

			slot.lastEscalationTrigger = null;

			emitAnalytics('swipeview_playback_fallback', {
				index: index,
				from: fromName || tierName(slot.tier),
				to: toTier > slot.tier ? tierName(toTier) : null,
				reason: (detail && detail.reason) || 'load-error',
				trigger: escalationTrigger
			});

			instantiateTier(slot, slot.tier + 1, escalationTrigger);

			if (index === session.index) {
				activateCurrent(true);
			}

			return;
		}

		if (kind === 'ready') {
			emitAnalytics('adapter_ready', { index: index, adapter: fromName || tierName(slot.tier) });
			return;
		}

		if (kind === 'playing') {
			slot.playingSeen = true;
			clearWatchdogs(slot);
			showLoader(slot, false);

			if (index === session.index) {
				updateChrome();
			}

			return;
		}

		if (kind === 'stalled') {
			// S9.1: shows the loading affordance, does NOT escalate. Only for
			// the active slide -- a neighbour buffering is not something the
			// visitor is looking at.
			if (index === session.index) {
				showLoader(slot, true);

				/*
				 * AC 25. The stall itself still does not escalate -- S9.1's
				 * rule is intact -- but a stall on a slide that HAS PLAYED now
				 * arms a bounded watchdog, and that is what escalates if the
				 * source never comes back.
				 *
				 * Gated on `playingSeen` because a stall BEFORE first play is
				 * already the start watchdog's business, and arming both would
				 * race two timers to escalate the same slide.
				 */
				if (slot.playingSeen) {
					armStallWatchdog(slot, index);
				}
			}

			return;
		}

		if (kind === 'progressing') {
			// The playback position moved, so whatever we were worried about
			// resolved itself. Only the STALL watchdog is disarmed -- a start
			// watchdog that is legitimately still counting is left alone.
			clearStallWatchdog(slot);

			if (index === session.index && slot.playingSeen) {
				showLoader(slot, false);
			}

			return;
		}

		if (kind === 'ended') {
			// S4.3 -- the active slide LOOPS. Auto-advance is not v1 behaviour.
			if (index === session.index && slot.inst && slot.inst.restart) {
				slot.inst.restart();
			}

			return;
		}

		if (kind === 'autoplay_blocked') {
			emitAnalytics('swipeview_autoplay_blocked', { index: index, intended: detail && detail.intended });

			// Arm the pill only for the slide the visitor is actually looking
			// at, and only for a refused UNMUTED attempt -- a refused MUTED
			// retry means autoplay is blocked outright, which the pill has
			// nothing to offer for.
			if (index === session.index && detail && detail.intended === 'unmuted') {
				session.unmutePillArmed = true;
				updateChrome();
			}

			return;
		}

		emitAnalytics('adapter_' + kind, { index: index, adapter: fromName || tierName(slot.tier) });
	}

	/* ═══════════════════ Playback intent (spec S4.1 / S4.2) ═══════════════════ */

	/**
	 * Ask one slot to play, and arm its watchdog.
	 *
	 * `muted` is asserted directly, never negated. The capability guard is
	 * S4.1's: where the tier reports no mute control, no unmute attempt is
	 * synthesised against it -- it keeps whatever the frame does on its own.
	 *
	 * @param {Object}  slot  The slot record.
	 * @param {number}  index Its index.
	 * @param {boolean} muted The intended mute state.
	 *
	 * @return {void}
	 */
	function attemptSlotPlay(slot, index, muted) {
		if (! slot.inst) {
			return;
		}

		var wantMuted = slot.caps.mute ? !! muted : true;

		slot.inst.play({ muted: wantMuted });
		armStartWatchdog(slot, index);
	}

	/**
	 * Activate the current slide and put every other slot into the neighbour
	 * state: rendered and paused, never playing, never audible.
	 *
	 * @param {boolean} reactivateOnly Skip the neighbour bookkeeping (used when
	 *                                 a tier escalated under the active slide).
	 *
	 * @return {void}
	 */
	function activateCurrent(reactivateOnly) {
		var active = activeSlot();

		session.slots.forEach(function (slot) {
			var isActive = slot.index === session.index;

			/*
			 * S7 -- inert AND aria-hidden the non-active slots. Both, not one:
			 * `inert` is not universally supported, and aria-hidden alone
			 * leaves an off-screen slide's controls focusable. Three live
			 * presentations in the accessibility tree at once is the failure
			 * this prevents.
			 *
			 * `inert` is the right tool HERE -- unlike on the gesture layer,
			 * where it would delete the feature -- because an off-screen slot
			 * needs neither pointer interaction nor AT exposure.
			 *
			 * RATIFIED, and it closes a recorded Instagram MISS: non-active IG
			 * slides are neither aria-hidden nor inert (open item 3 in the
			 * swipe-view handoff). Not inherited.
			 */
			/*
			 * §4.4 / AC 28: `warm` is maintained HERE, not only where a slot is
			 * assigned -- and getting that wrong is a real bug I wrote and
			 * caught by checking the claim rather than the code.
			 *
			 * assignSlot() sets it for a NEWLY assigned slot, but syncWindow()
			 * KEEPS a slot whose index is still in the window, so navigating
			 * onto a neighbour never re-assigns it. Set only there, `warm`
			 * would stay true for the slide the visitor is now watching -- and
			 * because the neighbour-error rule discards emissions from a warm
			 * slot, that slide's dead media would be discarded again on every
			 * retry and IT WOULD NEVER ESCALATE. A permanently black slide,
			 * with the terminal tier one step away and unreachable.
			 *
			 * activateCurrent() is the only function that knows which slot is
			 * active at any given moment, so the flag belongs here and
			 * assignSlot()'s write is just the initial value.
			 */
			slot.warm = ! isActive;

			slot.el.classList.toggle('cff-swipeview-slot-active', isActive);

			if ('inert' in window.HTMLElement.prototype) {
				slot.el.inert = ! isActive;
			}

			if (isActive) {
				slot.el.removeAttribute('aria-hidden');
			} else {
				slot.el.setAttribute('aria-hidden', 'true');
			}

			if (! slot.inst || isActive || reactivateOnly) {
				return;
			}

			clearWatchdogs(slot);
			slot.inst.pause();

			// A neighbour is never audible, whatever the session's mute state
			// is -- S4.4 is explicit that both sound rules are scoped to
			// ACTIVATION. The 2026-08-14 sound-on-open reversal makes this MORE
			// load-bearing, not less: now that a session routinely carries an
			// unmuted state, applying it to a slide that is not active is
			// exactly how an off-screen slide ends up audible.
			if (slot.inst.setMuted) {
				slot.inst.setMuted(true);
			}

			showLoader(slot, false);
		});

		if (active && active.inst) {
			// The active slide's own request goes out FIRST, and it is
			// gesture-backed: open() is a click and every navigate() is a
			// gesture, so S4.1 says attempt UNMUTED unless the visitor's last
			// explicit choice was mute.
			attemptSlotPlay(active, session.index, userMuted);
			showLoader(active, ! active.playingSeen);
		}

		updateChrome();
	}

	/* ═══════════════════ Track motion (spec S3.2) ═══════════════════ */

	/**
	 * THE one place the track's transform is written.
	 *
	 * Single-writer discipline is the reason rather than the mechanism: before
	 * the drag existed there was exactly one transform write, and adding a
	 * second one on the follow path is how a track ends up with two sources of
	 * truth that disagree at the boundary between them.
	 *
	 * `pct` is the RESTING position as a positive slide count (index * 100) and
	 * the minus sign lives in the format string. `pxDelta` is the drag's px
	 * travel composed over that percentage base -- the two units cannot be
	 * added in JS, one being relative to the track's own height and the other
	 * absolute, so they are added by the browser inside calc(), and only when
	 * there is a delta to add. The sign is normalised into the OPERATOR
	 * (`- 40px`, never `+ -40px`): calc() does accept a signed operand, but the
	 * negative-plus form is the shape engines have historically been picky
	 * about and emitting the unambiguous one costs nothing.
	 *
	 * @param {number} pct     Resting position, as a positive slide count.
	 * @param {number} pxDelta Drag travel in px, down-positive.
	 *
	 * @return {void}
	 */
	function setTrackOffset(pct, pxDelta) {
		var delta = pxDelta || 0;
		var y = delta === 0
			? '-' + pct + '%'
			: 'calc(-' + pct + '% ' + (delta < 0 ? '- ' + Math.abs(delta) : '+ ' + delta) + 'px)';

		session.dom.track.style.transform = 'translate3d(0, ' + y + ', 0)';
	}

	/**
	 * Mirror the track's live drag delta onto the SESSION RAIL.
	 *
	 * ── WHY THIS EXISTS (SMASH-2064, Asmita's call 2026-09-10) ───────────────
	 *
	 * "Match TikTok on Facebook." The rail follows the thumb during a finger
	 * drag, as TikTok's and Instagram's do, and still does not move on a
	 * committed navigation.
	 *
	 * That closes a divergence this file previously carried DELIBERATELY. The
	 * comment in buildOverlay() used to argue that a fully pinned rail was the
	 * correct reading of the 2026-09-10 rule, on the grounds that "in place"
	 * and "without it going up and down" speak to this element directly. The
	 * reading was defensible and it is now overruled at source: the rule
	 * governs the NAVIGATION, and only commit travel was ever meant to go. A
	 * rail pinned during a DRAG is what put reel N's stats over reel N+1's
	 * incoming video for the whole gesture -- the same defect Instagram
	 * recorded under SMASH-1978 on 2026-08-27, which this does NOT reverse.
	 *
	 * ── THE MECHANISM, AND WHY IT IS ON THIS ELEMENT ─────────────────────────
	 *
	 * `pxDelta` is `session.dragDeltaPx` VERBATIM -- the same already-clamped
	 * value setTrackOffset() composes, deliberately shared rather than
	 * recomputed, because a second derivation is how the two would eventually
	 * disagree about a clamp and drift apart by a few pixels at the ends of the
	 * track. It carries pull-to-close's damped follow for free, for the same
	 * reason: the rail mirrors whatever the track actually did.
	 *
	 * The delta ALONE is the correct mirror, not the track's whole transform.
	 * The track sits at `-index * 100% + delta`; its active slide therefore
	 * sits at `delta` relative to the frame, and that is what this rail --
	 * which describes exactly that one slide -- has to match.
	 *
	 * THE HOST IS `.cff-swipeview-rail`, NOT `.cff-swipeview-railcol`, and that
	 * is where this viewer's shape genuinely differs from Instagram's rather
	 * than merely looking different. IG transforms its COLUMN (`setRailTravel`
	 * writes `.sbi-qs-railcol`) and can, because that column holds nothing but
	 * the rail. This column also hosts the CHEVRONS -- `nav` is appended to
	 * `chromeRailCol` as the rail's sibling -- and the chevrons are viewport
	 * navigation, not reel chrome: native TikTok's sit outside the column and
	 * do not move with the video, and this viewer's have never travelled with a
	 * drag. Transforming the column would take them along. So the transform
	 * goes on the inner rail, which is precisely the element choice TikTok
	 * makes and states its own reason for: "that is also why the transform
	 * below goes on `.sbtt-swipeview-rail-reel` and NOT on
	 * `.sbtt-swipeview-rail` itself: the nav cluster is a sibling of that
	 * wrapper". `nav` also carries its own `transform: translateY(-50%)` on
	 * desktop, which a column transform would compose with rather than replace.
	 *
	 * THE CONSEQUENCE THAT NEEDED CODE ELSEWHERE: a transform on a CHILD does
	 * not move the parent's border box, so `railCol.getBoundingClientRect()` --
	 * the box both carve-outs hit-test against -- stays put while the glyphs
	 * travel. IG never had to think about this because the node it transforms
	 * IS the node its carve-out measures. Here they are different nodes, so
	 * pointIsInControlDeadSpace() and clickIsOnBackdrop() now read the RAIL's
	 * live rect as well as the column's. See those two functions.
	 *
	 * `animate` is true for exactly ONE caller: settleBack(), the animated
	 * return after a drag that did not commit. It is false during the drag (any
	 * transition would make the rail lag the finger) and false on a commit (the
	 * rail lands at rest in the same paint updateRail() swaps its content in).
	 * Under reduced motion the FOLLOW stays and only the return goes instant --
	 * S3.2 is about motion the visitor did not ask for, and a drag is direct
	 * manipulation they are performing themselves.
	 *
	 * Cleared to `''` rather than to `translateY(0px)`, which is IG's shape and
	 * not TikTok's -- TikTok's is a React style object that is always present,
	 * so it has no way to express absence. The two are behaviourally identical
	 * and `''` is strictly better here: a rail at rest carries no transform at
	 * all and therefore establishes no containing block and no stacking context
	 * it does not need. It also means the AT-REST DOM is byte-identical to the
	 * pinned build's, which is what lets S6.3's at-rest hit-tests and the
	 * geometry tier's stylesheet-derived boxes stand unchanged.
	 *
	 * @param {number}  pxDelta Drag travel in px, down-positive.
	 * @param {boolean} animate Whether the return to rest transitions.
	 *
	 * @return {void}
	 */
	function setRailTravel(pxDelta, animate) {
		if (! session || ! session.dom || ! session.dom.rail) {
			return;
		}

		var px      = pxDelta || 0;
		var instant = ! animate || prefersReducedMotion();

		// Only the DURATION is written here; the property list and the easing
		// stay in the stylesheet, in one place -- see `.cff-swipeview-rail`.
		session.dom.rail.style.transitionDuration = instant ? '0ms' : (TRANSITION_MS + 'ms');
		session.dom.rail.style.transform = px ? ('translateY(' + px + 'px)') : '';
	}

	/**
	 * @param {boolean} animate Whether to transition.
	 *
	 * @return {void}
	 */
	function moveTrack(animate) {
		// S3.2: under reduced motion the transition is REMOVED ENTIRELY -- the
		// slide changes instantly -- not merely shortened.
		var duration = (animate === false || prefersReducedMotion()) ? 0 : TRANSITION_MS;

		session.dom.track.style.transition = duration ? ('transform ' + duration + 'ms ease-out') : 'none';
		setTrackOffset(session.index * 100, 0);
		/*
		 * ── THE COMMIT: the rail lands at rest, INSTANTLY, and stays there ──
		 *
		 * This is the half of Asmita's 2026-09-10 rule that does NOT change.
		 * The track animates the remaining distance; the rail does not move at
		 * all, and updateRail() swaps its counts in the same paint. V24 pins
		 * exactly this, by sampling the rail's anchor mid-transition.
		 *
		 * Unconditionally instant -- a commit is never the animated case, so
		 * this is not gated on reduced motion (setRailTravel is instant for
		 * `animate: false` either way).
		 *
		 * It runs on EVERY navigation path by construction, because moveTrack()
		 * is the one place any committed move is written: wheel, keys, both
		 * chevrons, the drag-commit, and the session's opening move. The
		 * drag-commit is the one that NEEDS it -- `dragDeltaPx` is non-zero
		 * when that gesture ends, so without this line the rail would stay
		 * parked mid-drag while the track snapped to the new slide.
		 */
		setRailTravel(0, false);
		session.transitioning = duration > 0;

		if (duration > 0) {
			window.setTimeout(function () {
				if (session) {
					session.transitioning = false;
				}
			}, duration);
		}
	}

	/**
	 * Return the track to the slide it is actually on, animated -- the release
	 * path for a drag that did not earn a commit, and for any gesture that
	 * aborted.
	 *
	 * DELIBERATELY DOES NOT SET `transitioning`. A return is not a navigation,
	 * and arming the flag would lock the viewer out of input for the
	 * transition's duration after a gesture that changed nothing. So a visitor
	 * who half-drags and lets go can immediately catch the returning track and
	 * drag again -- which is the RE-GRABBABLE SETTLE the 2026-08-24 feedback
	 * asked for, and it falls out of not arming a flag rather than needing
	 * machinery of its own.
	 *
	 * `session.index` rather than the drag's base index: in the ordinary case
	 * they are the same slide, and where they differ (a navigation arrived from
	 * elsewhere mid-gesture) the live index is the one actually on screen and
	 * therefore the only correct target.
	 *
	 * @return {void}
	 */
	function settleBack() {
		var duration = prefersReducedMotion() ? 0 : TRANSITION_MS;

		session.dom.track.style.transition = duration ? ('transform ' + duration + 'ms ease-out') : 'none';
		setTrackOffset(session.index * 100, 0);
		/*
		 * The ONE caller that ANIMATES the rail. A drag that did not earn a
		 * commit leaves the same slide on screen, so the rail returns to rest
		 * with the track -- same duration, same easing, because a divergence
		 * there is visible as the rail sliding at a different speed than the
		 * video it is captioning.
		 *
		 * `duration > 0` rather than a second prefersReducedMotion() call, so
		 * the rail cannot disagree with the track about whether this return
		 * animates: both read the one decision made on the line above. The
		 * release snap is exactly where S3.2 applies -- unlike the follow.
		 */
		setRailTravel(0, duration > 0);
	}

	/**
	 * One slide's height in px -- the unit both the clamp and the area rule are
	 * expressed in.
	 *
	 * Measured off the LIVE slot rather than derived from window.innerHeight.
	 * The slot IS the thing being translated, its height is whatever the
	 * stylesheet's `position: fixed; inset: 0` actually resolved to, and
	 * `offsetHeight` is unaffected by the track's own transform. innerHeight is
	 * the fallback only for a slot not yet laid out.
	 *
	 * RATIFIED (2026-08-24 feedback item C): the siblings' rail clipped on
	 * mobile because they sized on `100vh`, which excludes the dynamic
	 * toolbars. The fix there was dvh; the fix here is not needing a viewport
	 * unit at all -- a fixed, inset-0 root IS the visual viewport box, so there
	 * is no `vh` or `dvh` anywhere in this file or its stylesheet to be wrong.
	 * A test asserts that absence.
	 *
	 * @return {number}
	 */
	function slideHeightPx() {
		var slot = activeSlot();
		var height = (slot && slot.el) ? slot.el.offsetHeight : 0;

		return height > 0 ? height : (window.innerHeight || 0);
	}

	/**
	 * THE one choke point every navigation path funnels through: wheel, touch
	 * flick, drag commit, arrows, PageUp/Down and both chevrons.
	 *
	 * Enforcing the clamp, the cooldown and the stale-state clears here rather
	 * than per handler is what makes them identical BY CONSTRUCTION rather than
	 * by several code paths kept in step -- and a per-handler guard is the shape
	 * that let a sibling viewer's pinch-abort defect in.
	 *
	 * @param {number} delta +1 next, -1 previous.
	 *
	 * @return {void}
	 */
	function navigate(delta) {
		if (! session) {
			return;
		}

		// RATIFIED (spec S6.1's caption expander): swipe navigation is
		// suppressed while the caption is expanded. A vertical drag there
		// scrolls the caption's own surface; navigating out from under an
		// expanded caption loses the text the visitor deliberately opened.
		if (session.captionExpanded) {
			return;
		}

		var target = session.index + delta;

		// S2.3's STRICT end clamp, with no rubber-band. RATIFIED: Instagram
		// shipped a "gentle bounce" past the end (a spec MAY, not a
		// requirement) and REMOVED it on maintainer feedback, because the
		// transform re-fired on every key-repeat and juddered the track ~30
		// times a second. Not re-introduced here, on any input path.
		if (session.navLocked || target < 0 || target >= session.slides.length) {
			return;
		}

		session.navLocked = true;
		window.setTimeout(function () {
			if (session) {
				session.navLocked = false;
			}
		}, NAV_COOLDOWN_MS);

		session.index = target;
		session.viewed[ target ] = true;

		/*
		 * A stale hint belongs to the slide being swiped away. Disarming here
		 * is also what makes AC 27's per-slide replay work: the new slide's
		 * own refused attempt re-arms, so the label follows real refusals
		 * rather than a remembered one.
		 */
		session.unmutePillArmed = false;
		clearMuteHint();
		session.dom.mute.classList.remove('cff-swipeview-mute-hinting');

		moveTrack(true);
		syncWindow();
		activateCurrent(false);

		/*
		 * RE-BANK on the navigation gesture. The window has just moved, so the
		 * slot that is now a neighbour may be an element that has never been
		 * played under an activation. Synchronous in this handler's stack for
		 * the same reason as in open(): a rAF or a timer loses the activation.
		 */
		primeMediaActivation();
		emitAnalytics(delta > 0 ? 'swipeview_next' : 'swipeview_prev', { index: session.index });
	}

	/* ═══════════════════ Icons ═══════════════════
	 *
	 * RATIFIED, AND COPIED RATHER THAN REDRAWN. These are the glyphs Instagram
	 * and TikTok finally shipped after the 2026-08-24 feedback round ("replace
	 * the icons for muting and pausing the video" -- Alex; "try to match icons
	 * as close as possible... get as close as the native players" -- Aman), and
	 * they arrive here as path data transcribed from `js/sbi-quickscroll.js` on
	 * the SMASH-1851 branch. Not re-authored from memory: the whole point of
	 * the sibling round was that the first attempt used TEXT GLYPHS
	 * ('|| ' '>' '(x' '((') at font-size 18, where the OS picks the artwork, so
	 * the same button was a flat outline on one platform and a colour emoji on
	 * another at a size and baseline nobody controlled.
	 *
	 * NO DEPENDENCY IS ADDED. Team convention, binding since the 2026-08-24
	 * round: copy icon path data, do NOT add react-icons or any icon package.
	 * The path strings are the whole payload -- no icon font, no sprite, no
	 * fetch. Aman pointed at react-icons as a BROWSING reference for choosing
	 * shapes, not as a package to install, and the Instagram round recorded
	 * that distinction explicitly.
	 *
	 * PROVENANCE, per glyph:
	 *   play / pause          Material Symbols geometry (Apache-2.0), with the
	 *                         pause bars trimmed 4 -> 3.6 so the pair sits
	 *                         better inside a 44px disc. Instagram's exact
	 *                         entries.
	 *   volumeOn / volumeOff  Hand-authored in the sibling to match the Reels
	 *                         player's filled speaker, which is narrower and
	 *                         softer than Material's cone. No third-party path
	 *                         data, so nothing to attribute.
	 *   chevronUp / Down      Hand-authored on the 24-unit grid, with the ink
	 *                         box centred on (12,12) exactly. The centring is
	 *                         load-bearing rather than tidy: a round-capped
	 *                         stroke paints every point within strokeWidth/2 of
	 *                         the polyline, so fitting a viewBox to the path's
	 *                         COORDINATES lands the ink off-centre -- and
	 *                         because a chevron pair leans opposite ways the
	 *                         error is MIRRORED, one glyph painting low and the
	 *                         other high, so the pair sits visibly closer
	 *                         together than their discs. SMASH-1853 shipped
	 *                         exactly that defect with a 16x10 box.
	 *   close                 The Reels bare cross, rendered at 16 in the
	 *                         24 viewBox (maintainer feedback 2026-08-28 --
	 *                         scaled by the RENDER BOX, so the ink geometry
	 *                         stays exact where re-authoring at a smaller
	 *                         scale would have re-cut the shape).
	 *
	 * THE TABLE IS THE REVIEW SURFACE. A glyph swap has to be a one-line edit
	 * here, so nothing outside this object may hard-code a path and no call
	 * site may special-case an icon. Each entry is an ARRAY because a glyph can
	 * be several paths with independent paint -- the speaker is a filled cone
	 * plus stroked waves -- which is why these cannot collapse into the flat
	 * string map RAIL_ICON_PATHS uses.
	 */
	/*
	 * Glyphs whose source grid is NOT 24x24. One entry, and it is the coach
	 * hand -- see buildControlIcon() for why the exception exists rather than
	 * re-cutting the shape.
	 */
	var CONTROL_ICON_BOX = {
		coachHand: { w: 44, h: 64 },

		/*
		 * The plugin's own Facebook mark is Font Awesome's `facebook-square`,
		 * drawn on a 448x512 canvas: the glyph itself is 448x448 and the extra
		 * 64 units are FA's vertical padding. Both dimensions are declared
		 * VERBATIM rather than cropped to the ink, because the ink is what must
		 * be reproduced and the canvas is part of how the plugin ships it.
		 *
		 * A non-square viewBox inside the square CSS box every icon gets is
		 * safe: SVG's default `preserveAspectRatio` is `xMidYMid meet`, so the
		 * canvas is FITTED and CENTRED, never stretched. At the CTA pill's 16px
		 * that puts 14px of ink in the box, which sits right alongside the
		 * 24-grid glyphs' ~13px. Measured, not assumed -- see the geometry tier.
		 */
		facebook: { w: 448, h: 512 }
	};

	var CONTROL_ICON_PATHS = {
		play: [
			{ d: 'M8 5v14l11-7z' }
		],
		pause: [
			{ d: 'M6 5h3.6v14H6zM14.4 5H18v14h-3.6z' }
		],
		/*
		 * Appendix A.1's pause/play glyph, verbatim: the triangle shown in the
		 * 84px disc while a slide is paused (rule 1.10 / AC 11). Filled AND
		 * stroked with a round join, which is what gives it the softened
		 * corners at 40px -- a plain fill reads noticeably sharper at that
		 * size.
		 *
		 * Distinct from `play` above, which is the tier-2 card's own 68px
		 * disc. Two glyphs, two jobs, and step (h) hit-tests them against each
		 * other because on a tier-2 slide both want the frame's centre.
		 */
		pauseGlyph: [
			{ d: 'M8.5 5.5v13l10.5-6.5z', fill: 'currentColor', stroke: 'currentColor', 'stroke-width': '2.5', 'stroke-linejoin': 'round' }
		],
		/*
		 * ── THE ONE GLYPH WITH NO DESIGN SOURCE -- FOR AMAN ──────────────────
		 *
		 * The reference has no Facebook set. Appendix A.1 is the shared engine,
		 * A.2 is Instagram and A.3 is TikTok; Aman never built a Facebook skin
		 * and never mentioned Facebook at all. So "reproduce the path data, do
		 * not redraw" cannot be satisfied here -- there is nothing to
		 * reproduce, and this is the only element in the whole port in that
		 * position.
		 *
		 * Rather than resolve that silently, this is drawn in the design's OWN
		 * IDIOM and flagged: the enclosing rounded square is Appendix A.2's
		 * Instagram-mark geometry character-for-character (`rect x=3 y=3 w=18
		 * h=18 rx=5`, stroke-width 2), with an "f" stroked at the same weight
		 * inside it. So it sits with the set rather than beside it, and
		 * swapping in whatever Aman draws is one string.
		 *
		 * The alternative considered and NOT taken: the plugin already ships a
		 * Facebook mark at `admin/assets/img/fb-icon.svg`. It is a SOLID brand
		 * "f" in Facebook blue on a 52x52 viewBox with a drop-shadow filter --
		 * a different idiom, a different colour and a different grid from every
		 * other glyph in this viewer, which are all `currentColor` outlines on
		 * 24x24. Using it would have been visibly wrong next to the mute chip.
		 *
		 * RECORDED AS AN OPEN ITEM. See the change log.
		 */
		/*
		 * ── THE VERIFIED BADGE: WIRED DARK, NEVER FAKED (AC 13) ──────────────
		 *
		 * Present so the branch EXISTS rather than having to be invented later,
		 * and unreachable today because Facebook does not expose the fact.
		 * Checked rather than assumed: `is_verified` and `verification_status`
		 * appear nowhere in the plugin; the header call requests exactly
		 * `id,picture.height(150).width(150),cover,name,link` plus
		 * `fan_count,about`; and no post-level edge on either the timeline or
		 * the videos side carries one.
		 *
		 * Sourcing it would mean adding a PAGE-LEVEL `is_verified` request with
		 * an unverified permission scope, and the value would be per-Page
		 * rather than per-post. That is a decision for Asmita and Aman, not an
		 * implementation detail, so it is omitted and recorded as a stated
		 * limitation. `slide.verified` is never set from any other signal --
		 * inferring it from a follower count or a name match would be faking a
		 * platform trust marker, which is the one thing this must not do.
		 *
		 * Appendix A.2's polygon is procedurally generated there (24 points
		 * alternating r=10 and r=8.4); the resolved output is reproduced
		 * verbatim rather than re-deriving the loop.
		 */
		verified: [
			{ tag: 'polygon', points: '22.00,12.00 20.11,14.17 20.66,17.00 17.94,17.94 17.00,20.66 14.17,20.11 12.00,22.00 9.83,20.11 7.00,20.66 6.06,17.94 3.34,17.00 3.89,14.17 2.00,12.00 3.89,9.83 3.34,7.00 6.06,6.06 7.00,3.34 9.83,3.89 12.00,2.00 14.17,3.89 17.00,3.34 17.94,6.06 20.66,7.00 20.11,9.83', fill: '#0095f6', stroke: 'none' },
			{ d: 'M7.8 12.4l2.7 2.6 5.7-5.8', fill: 'none', stroke: '#fff', 'stroke-width': '2.2', 'stroke-linecap': 'round', 'stroke-linejoin': 'round' }
		],
		/*
		 * Appendix A.1's first-run swipe hand, verbatim -- and note the
		 * viewBox: 0 0 44 64, NOT the 24-unit grid every other glyph here
		 * uses. Reproducing it on a 24 grid would mean re-cutting the shape,
		 * which the rule forbids, so buildControlIcon() takes an optional
		 * viewBox for this one case.
		 */
		coachHand: [
			{ d: 'M22 6v30', fill: 'none', stroke: '#fff', 'stroke-width': '2.4', 'stroke-linecap': 'round', 'stroke-linejoin': 'round' },
			{ d: 'M12 16l10-10 10 10', fill: 'none', stroke: '#fff', 'stroke-width': '2.4', 'stroke-linecap': 'round', 'stroke-linejoin': 'round' },
			{ tag: 'circle', cx: '22', cy: '52', r: '6', fill: '#fff', stroke: 'none' }
		],
		/*
		 * ── THE PLUGIN'S OWN FACEBOOK MARK ───────────────────────────────────
		 *
		 * Path data copied VERBATIM from `templates/header.php`'s `$square_logo`
		 * -- the mark the FRONT-END FEED HEADER draws (Font Awesome's
		 * `facebook-square`, `viewBox="0 0 448 512"`, `fill="currentColor"`).
		 * Not a transcription and not a re-cut: the same bytes the header ships.
		 *
		 * This replaced a mark drawn in Facebook's idiom because the reference
		 * carried no Facebook glyph. Drawing one was the wrong call twice over:
		 * it put a THIRD Facebook mark in a plugin that already had two, and it
		 * was an outlined rounded square where the plugin's is solid, so the
		 * viewer's CTA did not look like the feed it opened from.
		 *
		 * The plugin ships two marks and they are NOT interchangeable:
		 *
		 *   templates/header.php:75   FA `facebook-square`, 448x512, solid.
		 *                             The FRONT-END feed header -- also in
		 *                             `inc/CFF_Display_Elements_Pro.php`,
		 *                             `assets/js/cff-scripts.js` and
		 *                             `assets/svgs/facebookShare.svg`. THIS ONE.
		 *   assets/svgs/facebook.svg  a circle-f on a 12x13 canvas, reachable
		 *                             only through the builder's `svgs.js` icon
		 *                             table. ADMIN-ONLY -- using it here would
		 *                             have made the viewer match the settings
		 *                             screen instead of the feed.
		 *
		 * Chosen by asking which file the FRONT END renders, not by which name
		 * read more like a logo: the mark's job here is to make the CTA read as
		 * continuous with the feed the visitor opened the viewer from.
		 */
		facebook: [
			{ d: 'M400 32H48A48 48 0 0 0 0 80v352a48 48 0 0 0 48 48h137.25V327.69h-63V256h63v-54.64c0-62.15 37-96.48 93.67-96.48 27.14 0 55.52 4.84 55.52 4.84v61h-31.27c-30.81 0-40.42 19.12-40.42 38.73V256h68.78l-11 71.69h-57.78V480H400a48 48 0 0 0 48-48V80a48 48 0 0 0-48-48z' }
		],
		volumeOn: [
			{ d: 'M3.6 9.4h2.9l4.7-3.8a.85.85 0 0 1 1.4.66v11.5a.85.85 0 0 1-1.4.66L6.5 14.6H3.6a.85.85 0 0 1-.85-.85v-3.5a.85.85 0 0 1 .85-.85z' },
			{ d: 'M15.9 9a4.2 4.2 0 0 1 0 6', fill: 'none', stroke: 'currentColor', 'stroke-width': '1.8', 'stroke-linecap': 'round' },
			{ d: 'M18.5 6.4a7.8 7.8 0 0 1 0 11.2', fill: 'none', stroke: 'currentColor', 'stroke-width': '1.8', 'stroke-linecap': 'round' }
		],
		volumeOff: [
			{ d: 'M3.6 9.4h2.9l4.7-3.8a.85.85 0 0 1 1.4.66v11.5a.85.85 0 0 1-1.4.66L6.5 14.6H3.6a.85.85 0 0 1-.85-.85v-3.5a.85.85 0 0 1 .85-.85z' },
			{ d: 'M16.2 9.8l5 4.4M21.2 9.8l-5 4.4', fill: 'none', stroke: 'currentColor', 'stroke-width': '1.8', 'stroke-linecap': 'round' }
		],
		chevronUp: [
			{ d: 'M5 16L12 8L19 16', fill: 'none', stroke: 'currentColor', 'stroke-width': '2', 'stroke-linecap': 'round', 'stroke-linejoin': 'round' }
		],
		chevronDown: [
			{ d: 'M5 8L12 16L19 8', fill: 'none', stroke: 'currentColor', 'stroke-width': '2', 'stroke-linecap': 'round', 'stroke-linejoin': 'round' }
		],
		/*
		 * Appendix A.1's close glyph, copied as PATH DATA -- a two-segment
		 * STROKED cross at stroke-width 2.4 with round caps, not the filled
		 * outline-of-an-X this viewer shipped before. The spec says
		 * "reproduce as path data -- do not redraw", and the difference is
		 * visible: a filled X carries its own corner geometry, where a
		 * stroked one takes its weight from the stroke and matches the
		 * chevrons' and rail glyphs' line quality.
		 *
		 * Cross-checked character-for-character against the Instagram build
		 * at `a6d0ca03`, not against the live reference site. That is the
		 * ticket's top risk: the reference is a moving target, and the four
		 * viewers diverge again the moment one of them ports from it directly.
		 */
		close: [
			{ d: 'M6 6l12 12M18 6L6 18', fill: 'none', stroke: 'currentColor', 'stroke-width': '2.4', 'stroke-linecap': 'round' }
		]
	};

	/**
	 * The counts glyphs. OUTLINE, matching Instagram's own visual language --
	 * TikTok's sibling viewer uses filled glyphs, and S6.1's platform-native
	 * rule (decided 2026-08-18) is what makes that difference correct rather
	 * than an inconsistency. Facebook Reels reads as the Instagram Reels
	 * grammar, so the outline set is the one to copy.
	 */
	/*
	 * ── RAIL GLYPHS: APPENDIX A.2, VERBATIM ─────────────────────────────────
	 *
	 * The design's hand-drawn 1.8-stroke outline set REPLACES the shapes this
	 * viewer copied before. That is an overturn rather than a refinement: the
	 * old `likes` and `comments` paths were approximations at stroke-width
	 * 1.75, and the directive is to reproduce the reference's path data rather
	 * than redraw anything near it.
	 *
	 * Cross-checked character-for-character against the Instagram build at
	 * `a6d0ca03`, NOT against the live reference site -- the ticket's top risk
	 * is the four viewers diverging again because one of them ported from a
	 * moving target.
	 *
	 * Flat strings with ONE shared paint object, because every glyph here is a
	 * stroked outline on the same 24-unit grid. The Facebook mark is the
	 * exception and lives in CONTROL_ICON_PATHS instead -- it is SOLID, and it
	 * arrives on the plugin's own 448x512 canvas, so it shares neither this
	 * table's paint nor its grid. `buildRailItem` routes by which table the
	 * glyph is in.
	 */
	var RAIL_ICON_PATHS = {
		// heart (outline)
		likes: ['M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.7l-1-1.1a5.5 5.5 0 0 0-7.8 7.8l1 1L12 21l7.8-7.6 1-1a5.5 5.5 0 0 0 0-7.8z'],
		// speech bubble
		comments: ['M12 3a9 9 0 0 0-7.6 13.8L3 21l4.4-1.3A9 9 0 1 0 12 3z'],
		// paper plane -- TWO paths, and both are needed: the first is the
		// stroke from the corner to the fold, the second the plane's outline.
		share: ['M22 2L11 13', 'M22 2l-7 20-4-9-9-4z']
	};

	var RAIL_ICON_PAINT = {
		fill: 'none',
		stroke: 'currentColor',
		'stroke-width': '1.8',
		'stroke-linecap': 'round',
		'stroke-linejoin': 'round'
	};

	/**
	 * Build one control glyph.
	 *
	 * @param {string} name The glyph name.
	 * @param {number} size The RENDER box in px; the 24-unit viewBox never
	 *                      changes, which is what makes 16px in the CTA pill
	 *                      and 22px on the close disc the same ink at two
	 *                      scales rather than two re-cut shapes.
	 *
	 * @return {SVGElement}
	 */
	function buildControlIcon(name, size) {
		var specs = CONTROL_ICON_PATHS[ name ] || [];
		var px = String(size || 22);
		var svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');

		/*
		 * The 24-unit viewBox is the default and almost never changes -- that
		 * invariance is what makes 16px in the CTA pill and 22px on the close
		 * disc the SAME ink at two scales rather than two re-cut shapes.
		 *
		 * Two glyphs are exceptions, both for the same reason -- re-cutting
		 * either onto a 24 grid is exactly the redraw the rule forbids:
		 * Appendix A.1 draws the coach hand on a 44x64 grid, and the plugin
		 * ships its Facebook mark on Font Awesome's 448x512 one. So the box is
		 * overridable, and a non-square glyph takes its height from the ratio
		 * rather than from `size`.
		 */
		var box = CONTROL_ICON_BOX[ name ] || { w: 24, h: 24 };
		var height = box.w === box.h
			? px
			: String(Math.round((Number(px) * box.h) / box.w));

		svg.setAttribute('viewBox', '0 0 ' + box.w + ' ' + box.h);
		svg.setAttribute('width', px);
		svg.setAttribute('height', height);
		svg.setAttribute('aria-hidden', 'true');
		svg.setAttribute('focusable', 'false');

		specs.forEach(function (spec) {
			/*
			 * `tag` selects the SVG element and is not itself an attribute.
			 * Most glyphs are path data, but a rounded square is a
			 * `<rect rx>` -- and an `rx` on a `<path>` is silently inert, so a
			 * mark transcribed the lazy way ships with square corners rather
			 * than failing. Declaring the shape is what keeps the design's own
			 * geometry rather than a re-cut approximation of it.
			 */
			var tag  = spec.tag || 'path';
			var node = document.createElementNS('http://www.w3.org/2000/svg', tag);

			// Filled by default -- the majority case. A spec that wants
			// stroking says so explicitly, and its keys are written straight
			// through so a new paint attribute needs no change here.
			node.setAttribute('fill', 'currentColor');
			Object.keys(spec).forEach(function (key) {
				if (key !== 'tag') {
					node.setAttribute(key, spec[ key ]);
				}
			});
			svg.appendChild(node);
		});

		return svg;
	}

	/**
	 * Swap a control's glyph in place, leaving its other children alone.
	 *
	 * @param {HTMLElement} button The control.
	 * @param {string}      name   The glyph name.
	 * @param {number}      size   The render box in px.
	 *
	 * @return {void}
	 */
	function setControlIcon(button, name, size) {
		if (! button) {
			return;
		}

		/*
		 * Replace the SVG only, and leave every other child alone.
		 *
		 * This was a bare `while (button.firstChild) removeChild` until the
		 * mute chip gained its expanding label as a CHILD of the button (rule
		 * 1.6 / AC 7). The bare form then deleted the label on the first
		 * updateMuteChrome() call -- which runs on every 250ms chrome poll --
		 * so the label was destroyed within a quarter-second of the viewer
		 * opening and the whole refusal affordance was silently dead.
		 *
		 * Nothing in the product would have complained: the JS would have kept
		 * toggling a class on a button whose label no longer existed, the chip
		 * would simply never have expanded, and "the browser refused sound and
		 * said nothing" is indistinguishable from "this video has no audio".
		 *
		 * This is one of TWO instances of the same defect shape in this build
		 * -- the other was the loader inside `instantiateTier()`'s stage clear.
		 * Both were a wholesale child wipe meeting a newly long-lived child, so
		 * both are fixed the same way: remove what this function OWNS, by tag,
		 * and never everything it happens to find.
		 */
		var existing = button.querySelector('svg');

		if (existing) {
			button.removeChild(existing);
		}

		// Prepended, not appended: the glyph precedes the label in the chip,
		// and appending would put a re-rendered icon AFTER the label text.
		button.insertBefore(buildControlIcon(name, size), button.firstChild);
	}

	/**
	 * Build one rail glyph from Appendix A.2's path data.
	 *
	 * @param {string} kind `likes`, `comments` or `share`.
	 * @param {number} size The render box (28 touch / 26 desktop, set in CSS;
	 *                      this is the attribute default).
	 *
	 * @return {SVGElement}
	 */
	function buildRailIcon(kind, size) {
		var svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
		var px  = String(size || 28);

		/*
		 * The 24-unit viewBox is the default and almost never changes -- that
		 * invariance is what makes 16px in the CTA pill and 22px on the close
		 * disc the SAME ink at two scales rather than two re-cut shapes.
		 *
		 * Two glyphs are exceptions, both for the same reason -- re-cutting
		 * either onto a 24 grid is exactly the redraw the rule forbids:
		 * Appendix A.1 draws the coach hand on a 44x64 grid, and the plugin
		 * ships its Facebook mark on Font Awesome's 448x512 one. So the box is
		 * overridable, and a non-square glyph takes its height from the ratio
		 * rather than from `size`.
		 */
		/*
		 * `kind`, NOT `name`. This read `CONTROL_ICON_BOX[ name ]` -- and
		 * `name` is not a parameter of this function, so it resolved up the
		 * scope chain to `window.name`, the browsing context's name. That is
		 * `''` on a normal page, so the lookup missed and every rail glyph
		 * silently took the 24-unit fallback.
		 *
		 * Harmless right up until it wasn't: every glyph in RAIL_ICON_PATHS is
		 * on a 24 grid, so the correct box and the accidental one agreed, and
		 * nothing could look wrong. It would have started mis-rendering the
		 * moment a non-24 glyph entered the rail -- which is exactly what the
		 * Facebook mark below does. Worse, `window.name` is WRITABLE by the
		 * page: a host that set it to `coachHand` would have rendered the rail
		 * on a 44x64 canvas, a bug no amount of reading this file would explain.
		 */
		var box = CONTROL_ICON_BOX[ kind ] || { w: 24, h: 24 };
		var height = box.w === box.h
			? px
			: String(Math.round((Number(px) * box.h) / box.w));

		svg.setAttribute('viewBox', '0 0 ' + box.w + ' ' + box.h);
		svg.setAttribute('width', px);
		svg.setAttribute('height', height);
		// Presentation only. Every rail item carries its own accessible name,
		// so the glyph stays out of the a11y tree entirely -- otherwise the
		// item is named twice, once by the label and once by the SVG.
		svg.setAttribute('aria-hidden', 'true');
		svg.setAttribute('focusable', 'false');

		(RAIL_ICON_PATHS[ kind ] || []).forEach(function (d) {
			var path = document.createElementNS('http://www.w3.org/2000/svg', 'path');

			Object.keys(RAIL_ICON_PAINT).forEach(function (key) {
				path.setAttribute(key, RAIL_ICON_PAINT[ key ]);
			});
			path.setAttribute('d', d);
			svg.appendChild(path);
		});

		return svg;
	}

	/**
	 * Build one rail item.
	 *
	 * @param {Object} spec `{tag, modifier, icon, count, label, href, attrs}`.
	 *
	 * @return {HTMLElement}
	 */
	function buildRailItem(spec) {
		var node = el(spec.tag, 'cff-swipeview-act ' + spec.modifier, spec.attrs || {});

		if (spec.tag === 'button') {
			node.type = 'button';
		}

		if (spec.href) {
			node.href = spec.href;
			node.target = '_blank';
			node.rel = 'noopener noreferrer';
		}

		/*
		 * Two glyph tables, and the item picks by WHERE THE GLYPH LIVES.
		 *
		 * RAIL_ICON_PATHS holds the three stroked outlines on a 24 grid, and
		 * `buildRailIcon` paints them `fill: none; stroke: currentColor`.
		 * CONTROL_ICON_PATHS holds filled shapes with their own per-shape paint.
		 * The Facebook mark is in the second table -- RAIL_ICON_PATHS' own
		 * comment has said so since the rail was built -- and it is SOLID, so
		 * routing it through the rail builder would stroke its outline and fill
		 * nothing: a hollow double-edged f-square, not the plugin's mark.
		 *
		 * Data-driven rather than a name test, so a glyph moving tables needs
		 * no change here.
		 */
		node.appendChild(
			! RAIL_ICON_PATHS[ spec.icon ] && CONTROL_ICON_PATHS[ spec.icon ]
				? buildControlIcon(spec.icon, 28)
				: buildRailIcon(spec.icon, 28)
		);

		/*
		 * ── THE COUNT ROW IS ALWAYS RENDERED, EVEN WHEN EMPTY ────────────────
		 *
		 * Measured against the reference: its like, comment and share items are
		 * all 43px tall on desktop despite share carrying no figure. So the
		 * count row's 12px is RESERVED rather than collapsed, and the three
		 * glyphs stay evenly pitched.
		 *
		 * IG-3's "a glyph without a count" is about the FIGURE, not about the
		 * space. Collapsing the row pulls the next glyph 17px up toward its
		 * neighbour and breaks the rail's rhythm -- which is exactly the
		 * uneven-pitch defect Instagram fixed in `897e6ea8`.
		 *
		 * The element keeps its height through a `min-height` in CSS, because
		 * an empty INLINE element generates no line box of its own.
		 */
		if (spec.label) {
			var label = el('span', 'cff-swipeview-act-label', { 'aria-hidden': 'true' });

			// A text node, never markup (§12).
			label.textContent = spec.label;
			node.appendChild(label);
		} else {
			var count = el('b', 'cff-swipeview-act-count', { 'aria-hidden': 'true' });

			if (spec.count !== null && spec.count !== undefined) {
				count.textContent = formatCount(spec.count);
			}

			node.appendChild(count);
		}

		return node;
	}

	/**
	 * The ACTIVE slide's shareable permalink, or '' when there is none.
	 *
	 * Same guard as the rail builder's -- isFacebookUrl() -- so a slide whose
	 * permalink the seam could not distinguish from an embed wrapper reports
	 * absence here too, rather than handing a wrapper URL to the share sheet.
	 *
	 * @return {string}
	 */
	function activeShareUrl() {
		var slide = (session && session.slides) ? session.slides[ session.index ] : null;

		return (slide && isFacebookUrl(slide.permalink)) ? slide.permalink : '';
	}

	/**
	 * Build the ACTIVE slide's rail items (rules IG-2 / IG-3 / AC 8 / AC 15).
	 *
	 * "Per-post" until 2026-09-10, when the rail became one session-level
	 * element that stays put and swaps its content -- see buildOverlay(). The
	 * items are still per-post; the element holding them is not.
	 *
	 * REPLACES buildStatsCluster(), which wrapped every metric in ONE <a> to
	 * the post. That was wrong in a way worth stating, because it looked tidy:
	 * a single link around a heart, a speech bubble and their figures claims
	 * all three are the same kind of thing and all three go to the same place.
	 * IG-3 says they are not interchangeable, and each item now carries the
	 * semantics its action actually has:
	 *
	 *   likes    a READOUT. `<div role="img">` with an exact-figure label and
	 *            `cursor: default`. There is no logged-in visitor inside an
	 *            embedded feed, so a tappable-looking heart would promise
	 *            something this UI cannot deliver.
	 *   comments a LINK to the post, where commenting genuinely works.
	 *   share    a real <button> -- the rail's only in-page action.
	 *   view     touch only, the desktop CTA pill's counterpart.
	 *
	 * ABSENCE IS NOT ZERO (AC 15), and it resolves differently per item:
	 *   - a missing LIKES figure hides the readout ENTIRELY, because a heart
	 *     with no number is a readout that reads nothing.
	 *   - comments and share SURVIVE UNLABELLED, because each is also a
	 *     link-out and an action respectively -- they still do something
	 *     useful with no figure attached.
	 *
	 * RETURNS AN ARRAY, NOT A RAIL ELEMENT, and the change of contract is the
	 * session-rail fix's other half. The rail element itself is built ONCE in
	 * buildOverlay() and never replaced; this function produces the items that
	 * go INSIDE it for one slide, and updateRail() swaps them. A builder that
	 * returned a fresh `.cff-swipeview-rail` would have to be re-mounted, and
	 * re-mounting is exactly what "one session-level element" forbids -- the
	 * identity a test now pins with isSameNode() would change on every
	 * navigation while every rect assertion still passed.
	 *
	 * @param {Object} slide The slide record.
	 *
	 * @return {Array<HTMLElement>} The rail's items, in paint order.
	 */
	function buildRailItems(slide) {
		var items = [];
		var href = isFacebookUrl(slide.permalink) ? slide.permalink : '';

		// LIKES -- a readout, and omitted outright when there is no figure.
		if (slide.likes !== null) {
			items.push(buildRailItem({
				tag: 'div',
				modifier: 'cff-swipeview-act-like',
				icon: 'likes',
				count: slide.likes,
				attrs: {
					role: 'img',
					'aria-label': exactCount(slide.likes) + ' ' + countNoun('likes', slide.likes)
				}
			}));
		}

		/*
		 * COMMENTS -- a link when there is a permalink, and NOTHING when there
		 * is not. A comment glyph that goes nowhere is worse than no glyph: it
		 * offers the one action the viewer genuinely cannot perform in-page.
		 *
		 * The permalink is DERIVED rather than requested from Graph, and the
		 * seam reports absence rather than handing back the embed-wrapper URL
		 * it cannot distinguish from a real permalink -- so this branch is
		 * reachable in production, not defensive.
		 */
		if (href) {
			items.push(buildRailItem({
				tag: 'a',
				modifier: 'cff-swipeview-act-comment',
				icon: 'comments',
				count: slide.comments,
				href: href,
				attrs: {
					'aria-label': slide.comments === null
						? 'View comments on Facebook'
						: exactCount(slide.comments) + ' ' + countNoun('comments', slide.comments)
							+ ' — view on Facebook'
				}
			}));
		}

		/*
		 * SHARE -- a real button, and the only item here that DOES something
		 * rather than reporting or linking. Present whenever there is a URL to
		 * share, with or without a figure.
		 */
		if (href) {
			var share = buildRailItem({
				tag: 'button',
				modifier: 'cff-swipeview-act-share',
				icon: 'share',
				count: slide.shares,
				attrs: { 'aria-label': 'Share this Reel' }
			});

			/*
			 * THE URL IS RESOLVED AT CLICK TIME, from the slide that is active
			 * THEN -- not from the `href` this closure captured when the item
			 * was built.
			 *
			 * Both readings give the same answer today, because updateRail()
			 * rebuilds every item on every navigation and a rebuilt button
			 * carries a fresh closure. That is precisely why the captured form
			 * is the wrong thing to rely on: it is correct only as a
			 * consequence of the rebuild, so the day anything reuses an item
			 * instead of replacing it, this button silently shares the slide
			 * the visitor was on two swipes ago -- and `swipeview_shared`
			 * reports that stale index as a real share.
			 *
			 * Reading live makes the guarantee independent of the rebuild.
			 * Falling back to the captured `href` keeps a share working if the
			 * live lookup ever misses, which is the fail-safe direction.
			 */
			share.addEventListener('click', function (event) {
				event.preventDefault();
				event.stopPropagation();
				shareSlide(activeShareUrl() || href);
			});
			items.push(share);
		}

		/*
		 * VIEW -- touch only (CSS hides it on desktop, where the top-row CTA
		 * pill does this job). A VIEWPORT-driven migration, which is what
		 * keeps §6.1's "a control MUST NOT relocate as the chain escalates"
		 * true: the tier chain never moves it.
		 */
		if (href) {
			items.push(buildRailItem({
				tag: 'a',
				modifier: 'cff-swipeview-act-view',
				icon: 'facebook',
				label: 'View',
				href: href,
				attrs: { 'aria-label': 'View this Reel on Facebook' }
			}));
		}

		return items;
	}

	/**
	 * Swap the session rail's CONTENT to the active slide.
	 *
	 * THE ELEMENT IS NEVER REPLACED -- only its children are. That is the
	 * invariant the whole fix rests on, and it is why this clears in place
	 * rather than rebuilding a rail and re-mounting it.
	 *
	 * ── WHEN, RELATIVE TO THE TRANSITION ────────────────────────────────────
	 *
	 * Called from syncWindow(), which navigate() runs in the SAME TASK as
	 * moveTrack(true) -- so the counts change in the same paint that the
	 * track's 320ms transform starts, and the rail is already at rest showing
	 * the new figures while the video slides in behind it. This is TikTok's
	 * timing, in its own words: "on a commit it lands at rest in the same
	 * paint that swaps its content, while the track animates the remaining
	 * distance."
	 *
	 * The alternative -- deferring the swap to the transition's end -- was not
	 * taken. It leaves the OUTGOING slide's like and comment counts painted
	 * over the INCOMING video for 320ms, which is the same class of defect
	 * the per-slot rail's own comment warned about ("the PREVIOUS slide's like
	 * and comment counts against the new video. Silent, plausible, and
	 * wrong"), just with a shorter window.
	 *
	 * NO TRANSITION IS INTRODUCED, so there is nothing for reduced motion to
	 * suppress: the swap is a DOM replacement, not an animation, and it is
	 * identical under `prefers-reduced-motion`. The rail's only animated
	 * property remains the per-item hover/active `transform` it already had.
	 *
	 * A MISSING SLIDE IS A NO-OP rather than an empty rail. The window can be
	 * mid-assignment when this runs, and blanking the rail on a transient miss
	 * would flicker the counts off and back on.
	 *
	 * @return {void}
	 */
	function updateRail() {
		if (! session || ! session.dom || ! session.dom.rail) {
			return;
		}

		var slide = session.slides[ session.index ];

		if (! slide) {
			return;
		}

		var rail = session.dom.rail;

		while (rail.firstChild) {
			rail.removeChild(rail.firstChild);
		}

		buildRailItems(slide).forEach(function (item) {
			rail.appendChild(item);
		});
	}

	/**
	 * IG-3's share chain: Web Share, then clipboard + toast, then a toast
	 * carrying the URL itself.
	 *
	 * Three rungs, and each exists because the one above it is unavailable
	 * somewhere real. `navigator.share` is mobile-and-Safari; the async
	 * clipboard needs a secure context AND a permission that can be refused;
	 * and when both are gone the only honest thing left is to show the visitor
	 * the URL so they can copy it themselves. The toast is a POLITE LIVE
	 * REGION rather than a painted box alone -- a silent successful copy is
	 * indistinguishable from a dead button.
	 *
	 * Every rung is wrapped, because each of the first two can REJECT rather
	 * than throw: an unhandled rejection here would leave the visitor with no
	 * feedback at all, which is the failure mode the chain exists to prevent.
	 *
	 * @param {string} url The permalink.
	 *
	 * @return {void}
	 */
	function shareSlide(url) {
		/*
		 * TWO BRANCHES, CHOSEN BY VIEWPORT AT CLICK TIME -- Asmita's call.
		 *
		 * Desktop copies the permalink and says so. Touch opens the native
		 * share sheet. The distinction is deliberate: on a desktop browser
		 * `navigator.share` exists but opens an OS dialog most people neither
		 * want nor expect, whereas a clipboard copy is what "share" means with
		 * a keyboard and a mouse.
		 *
		 * GATED ON THE VIEWPORT, NOT ON `navigator.share` PRESENCE, and that is
		 * the load-bearing part -- presence-gating is exactly what produced the
		 * reported behaviour, since desktop Chrome has the API and so got the
		 * sheet. The question being asked is "which layout is the visitor
		 * using", which is DESKTOP_QUERY: the stylesheet's own condition.
		 *
		 * Read at CLICK time rather than cached at open, so a window resized
		 * across the breakpoint mid-session behaves the way it looks.
		 */
		var slide = session ? session.slides[session.index] : null;

		/*
		 * S8 FIRES ON COMPLETION, not on intent. This used to be the function's
		 * first statement, so a visitor who opened the sheet and dismissed it
		 * counted as a share -- and on desktop every click counted, whatever
		 * happened next.
		 */
		var completed = function (method) {
			emitAnalytics('swipeview_share', {
				index: session ? session.index : null,
				method: method
			});
		};

		var copyLink = function () {
			var failed = function () {
				/*
				 * The last rung. Not an error state -- the visitor can still
				 * act, they just have to copy it themselves. No event: nothing
				 * has been shared.
				 */
				showToast('Copy this link: ' + url);
			};

			if (! navigator.clipboard || ! navigator.clipboard.writeText) {
				failed();

				return;
			}

			try {
				navigator.clipboard.writeText(url).then(function () {
					showToast('Link copied');
					completed('clipboard');
				}, failed);
			} catch (e) {
				failed();
			}
		};

		if (isDesktopViewport()) {
			copyLink();

			return;
		}

		if (navigator.share) {
			try {
				/*
				 * `title` and `text` alongside the url: a bare url leaves the
				 * sheet's preview a naked link, and several targets show
				 * nothing useful without them.
				 */
				var payload = { url: url };

				if (slide && slide.author) {
					payload.title = slide.author;
				}

				if (slide && slide.caption) {
					payload.text = slide.caption;
				}

				var shared = navigator.share(payload);

				if (shared && shared.then) {
					shared.then(function () {
						completed('web-share');
					}, function (err) {
						/*
						 * AbortError is the visitor dismissing the sheet. That
						 * is a decision, not a failure: no toast, no event, and
						 * NO clipboard fallback -- copying a link they just
						 * declined to share would be its own surprise.
						 */
						if (err && err.name === 'AbortError') {
							return;
						}

						copyLink();
					});

					return;
				}

				// A legacy synchronous implementation: nothing to await.
				completed('web-share');

				return;
			} catch (e) {
				// Fall through to the clipboard rung.
			}
		}

		copyLink();
	}

	function showToast(text) {
		if (! session) {
			return;
		}

		var toast = session.dom.toast;

		// A text node, never markup (§12) -- and the URL rung puts a
		// server-derived string in here.
		toast.textContent = text;
		toast.classList.add('cff-swipeview-toast-on');

		if (session.toastTimer) {
			window.clearTimeout(session.toastTimer);
		}

		session.toastTimer = window.setTimeout(function () {
			if (! session) {
				return;
			}

			session.toastTimer = null;
			session.dom.toast.classList.remove('cff-swipeview-toast-on');
		}, TOAST_MS);
	}

	/**
	 * Derive a stable hue from a string, for the fallback avatar disc.
	 *
	 * Stable is the whole requirement: the same Page must always get the same
	 * disc. A random or per-slide hue reads as a DIFFERENT account between
	 * slides of the same Page, which is worse than a neutral grey circle.
	 *
	 * @param {string} text The Page name.
	 *
	 * @return {number} A hue in [0, 360).
	 */
	function hueFor(text) {
		var hash = 0;
		var i;

		for (i = 0; i < text.length; i++) {
			// A plain rolling hash. Not cryptographic and does not need to be
			// -- it only has to be deterministic and reasonably spread.
			hash = ((hash << 5) - hash + text.charCodeAt(i)) | 0;
		}

		return Math.abs(hash) % 360;
	}

	/**
	 * Build the avatar (AC 10), through the per-edge fallback chain.
	 *
	 * THE CHAIN, AND IT IS NEVER FAKED:
	 *   1. the per-post picture, which the TIMELINE edge carries
	 *      unconditionally (`from{picture,id,name,link}` is requested outright)
	 *      and the VIDEOS edge carries only under `include_extras`.
	 *   2. the header-details cache, which is per-PAGE rather than per-post and
	 *      exists only if header data was fetched at all. Passed in by the
	 *      caller rather than resolved here.
	 *   3. the design's initial-letter gradient disc.
	 *
	 * Rung 3 is a real answer rather than an error state, and on the videos
	 * edge without `include_extras` it is the ORDINARY case, not an edge one.
	 *
	 * THE `error` HANDLER IS RUNG 1.5 AND IS NOT OPTIONAL. fbcdn signs every
	 * avatar URL with roughly a 106-hour life, so a cache older than ~4 days
	 * serves URLs that 403. Trusting the URL's presence means a broken-image
	 * glyph where the design has a disc -- which is why the handler swaps in
	 * the fallback rather than leaving the <img> to fail visibly.
	 *
	 * @param {Object} slide The slide record.
	 *
	 * @return {HTMLElement}
	 */
	function buildAvatar(slide) {
		var name = slide.author || '';
		var initial = name ? name.charAt(0) : '?';

		var fallback = function () {
			var disc = el('span', 'cff-swipeview-avatar cff-swipeview-avatar-fallback', {
				'aria-hidden': 'true'
			});

			disc.style.setProperty('--cff-sv-avatar-hue', String(hueFor(name || 'facebook')));
			// A text node, never markup (§12).
			disc.textContent = initial;

			return disc;
		};

		if (! slide.authorImg) {
			return fallback();
		}

		var img = el('img', 'cff-swipeview-avatar', {
			src: slide.authorImg,
			alt: '',
			width: '32',
			height: '32',
			loading: 'lazy',
			decoding: 'async'
		});

		/*
		 * Rung 1.5. A signed fbcdn URL that has expired 403s, and an <img> that
		 * fails paints the UA's broken-image glyph where the design has a disc.
		 * Swapping the node keeps the row's geometry identical -- both are
		 * 32px and share the `-avatar` class -- so nothing below shifts.
		 */
		img.addEventListener('error', function () {
			if (img.parentNode) {
				img.parentNode.replaceChild(fallback(), img);
			}
		});

		return img;
	}

	/**
	 * Append caption text to a node, colouring hashtags as INERT spans.
	 *
	 * Built by tokenising the text and appending real text nodes and spans --
	 * NEVER by parsing markup (§12). A caption is third-party content and the
	 * only safe way to put it on the page is as text.
	 *
	 * The hashtags are colour-only, which is AC 18's resolution of a conflict
	 * the design contains: it asks for both "caption text never tappable" and
	 * "hashtags with a hover underline", and those cannot both hold. A hover
	 * underline is an interactivity claim and a hashtag link is tappable
	 * caption text. Behaviour wins on the authority split.
	 *
	 * @param {HTMLElement} node The target.
	 * @param {string}      text The caption.
	 *
	 * @return {void}
	 */
	function appendCaptionText(node, text) {
		/*
		 * A caption's literal `<br>` markers become real newlines, and the
		 * expanded rule's `white-space: pre-line` renders them as breaks. This
		 * is how line breaks survive without ever parsing the text as markup.
		 */
		var normalised = String(text).replace(/<br\s*\/?>/gi, '\n');
		// Split on the hashtag itself, keeping the delimiter, so the pieces
		// reassemble to exactly the original string.
		var parts = normalised.split(/(#[^\s#]+)/g);

		parts.forEach(function (part) {
			if (! part) {
				return;
			}

			if (part.charAt(0) === '#' && part.length > 1) {
				var tag = el('span', 'cff-swipeview-tag');

				tag.textContent = part;
				node.appendChild(tag);

				return;
			}

			node.appendChild(document.createTextNode(part));
		});
	}

	/**
	 * Build the frame's bottom row (rules IG-4 / IG-5 / AC 9 / AC 17 / AC 18).
	 *
	 * @param {Object} slide The slide record.
	 *
	 * @return {HTMLElement}
	 */
	function buildSlideChrome(slide) {
		var bottom = el('div', 'cff-swipeview-bottom');

		/* ── The author row ───────────────────────────────────────────────── */
		if (slide.author) {
			var row = el('div', 'cff-swipeview-authorrow');

			/*
			 * A LINK when there is a safe Page URL, a plain <div> when there is
			 * not -- and the degraded shape is deliberate rather than
			 * defensive. `from{link}` can legitimately be absent, and the
			 * videos edge carries it only under `include_extras`, so this
			 * branch is reachable in production. The avatar and name still
			 * render; they simply do not link.
			 *
			 * Building the URL from the Page NAME is not an option: Facebook
			 * Page names are free text with spaces and punctuation, so there is
			 * no allowlist analogue and any construction would resolve to
			 * somebody else's Page.
			 */
			var author = el(slide.authorLink ? 'a' : 'div', 'cff-swipeview-author');

			if (slide.authorLink) {
				author.href = slide.authorLink;
				author.target = '_blank';
				author.rel = 'noopener noreferrer';
				author.setAttribute('aria-label', slide.author + ' on Facebook');
			} else {
				// A role-less div must carry NO aria-label -- it maps to ARIA
				// `generic`, where the attribute is prohibited. The sr-only
				// slide label at the end of this function carries the name.
				author.setAttribute('aria-hidden', 'true');
			}

			author.appendChild(buildAvatar(slide));

			var handle = el('span', 'cff-swipeview-handle');
			var handleText = el('span', 'cff-swipeview-handle-text');

			// A text node, never markup (§12).
			handleText.textContent = slide.author;
			handle.appendChild(handleText);

			/*
			 * AC 13: the verified badge is NOT SOURCEABLE on Facebook, so it is
			 * omitted -- checked, not assumed. `is_verified` and
			 * `verification_status` appear nowhere in the plugin, and no
			 * post-level edge carries one. The branch is wired dark so the
			 * shape exists if a Page-level request is ever added, and it is
			 * NEVER faked from any other signal.
			 */
			if (slide.verified) {
				handle.appendChild(buildControlIcon('verified', 14));
			}

			author.appendChild(handle);
			row.appendChild(author);

			/*
			 * Follow is OMITTED, not disabled, when there is no safe link. A
			 * pill that links nowhere is a promise the UI cannot keep -- and
			 * this is the one place §6.2's "disable, never omit" does NOT
			 * apply, because there is no capability being refused: the target
			 * simply does not exist.
			 */
			if (slide.authorLink) {
				var follow = el('a', 'cff-swipeview-follow', {
					href: slide.authorLink,
					target: '_blank',
					rel: 'noopener noreferrer',
					'aria-label': 'Follow ' + slide.author + ' on Facebook'
				});

				// "Follow", not "Like Page": the design's pill says Follow and
				// so does Facebook's own Reels UI.
				follow.textContent = 'Follow';
				row.appendChild(follow);
			}

			bottom.appendChild(row);
		}

		/* ── The caption ──────────────────────────────────────────────────── */
		if (slide.caption) {
			var caption = el('p', 'cff-swipeview-caption');
			var text = el('span', 'cff-swipeview-caption-text', { 'aria-hidden': 'true' });

			appendCaptionText(text, slide.caption);
			caption.appendChild(text);

			/*
			 * Built ALWAYS, hidden until overflow is MEASURED -- so the reveal
			 * is a class toggle rather than a DOM insertion, and the geometry
			 * suite can assert the collapsed layout without the button
			 * appearing and disappearing underneath it.
			 */
			var more = el('button', 'cff-swipeview-caption-more', {
				type: 'button',
				'aria-expanded': 'false'
			});

			more.textContent = 'more';
			more.addEventListener('click', function (event) {
				event.preventDefault();
				event.stopPropagation();
				toggleCaption();
			});
			caption.appendChild(more);
			bottom.appendChild(caption);
		}

		/*
		 * The accessible name for the slide, in ONE place, outside the visual
		 * row. It exists because every visible piece above is either
		 * aria-hidden or a link with its own label: the handle text to avoid a
		 * double read, the caption because its visible form is one clamped
		 * line. Without this the slide would announce as its bare aria-label
		 * ("Reel 2 of 5") and the visitor would lose the author and caption
		 * entirely.
		 */
		var label = el('p', 'cff-swipeview-sr cff-swipeview-slidelabel');
		var parts = [];

		if (slide.author) {
			parts.push('By ' + slide.author);
		}

		if (slide.caption) {
			parts.push(slide.caption);
		}

		label.textContent = parts.join('. ');
		bottom.appendChild(label);

		return bottom;
	}

	/**
	 * @return {boolean} The ACTIVE element's real muted state.
	 */
	function realMuted() {
		var slot = activeSlot();

		if (! slot || ! slot.inst || ! slot.inst.isMuted) {
			return true;
		}

		return slot.inst.isMuted();
	}

	/**
	 * S6.2 is PER CONTROL, not one boolean, and a control the tier cannot
	 * support is DISABLED -- never left inert. Users MUST NOT be able to press
	 * a control that silently does nothing.
	 *
	 * The button and the pill read the element's ACTUAL muted property, never
	 * the `userMuted` intent: a refused unmuted attempt leaves the element
	 * muted while intent never flipped (that per-attempt fallback is
	 * deliberate), so rendering off intent would let the button claim sound is
	 * on when it is not. This was a Rex-class finding on both siblings.
	 *
	 * @return {void}
	 */
	function updateMuteChrome() {
		if (! session) {
			return;
		}

		var slot  = activeSlot();
		// `slot.caps` is always a non-null caps object (see setSlotCaps), so
		// the only guard needed is on `slot` itself -- which is the guard
		// YouTube's two bare sites were missing.
		var caps  = slot ? slot.caps : NO_CAPS;
		var muted = realMuted();

		session.dom.mute.disabled = ! caps.mute;
		// 20px, per rule 1.6 -- passed explicitly rather than relying on
		// buildControlIcon()'s 22px default, which is the close disc's size.
		setControlIcon(session.dom.mute, muted ? 'volumeOff' : 'volumeOn', 20);
		// The glyph reports the CURRENT state (a crossed-out speaker means
		// audio is off) while aria-label names the ACTION -- the platform
		// convention on both siblings.
		session.dom.mute.setAttribute('aria-label', muted ? 'Unmute' : 'Mute');
		session.dom.root.setAttribute('data-muted', muted ? 'true' : 'false');

		/*
		 * Rule 1.6 / AC 7's inverted state paint, driven by an ATTRIBUTE
		 * rather than a class so it cannot disagree with the `muted` value
		 * computed one line above. MUTED is loud (solid white chip, dark
		 * glyph); UNMUTED is quiet (dark translucent, white glyph).
		 *
		 * `data-state` names the SOUND, not the button: "on" means audio is
		 * on. The inversion between what the chip paints and what it is
		 * called is exactly why this is an attribute the CSS reads rather than
		 * two classes the JS has to keep opposite.
		 */
		session.dom.mute.setAttribute('data-state', muted ? 'off' : 'on');

		/*
		 * The pill's visibility, gated on FOUR terms rather than the armed flag
		 * alone:
		 *
		 *   armed            a genuinely refused UNMUTED attempt happened
		 *   muted            the element really is silent right now, so the
		 *                    offer is still true
		 *   caps.mute        the tier can be driven at all (keeps it off the
		 *                    embed and terminal tiers, which have no sound
		 *                    control)
		 *   !unmuteSucceeded RATIFIED (2026-08-24 item F): once audio is PROVEN
		 *                    for this session, stop asking. Keyed on a proven
		 *                    unmute, not on a tap -- a tap that ends in another
		 *                    refusal must leave the affordance in place, or a
		 *                    later refused slide gives the visitor silence with
		 *                    no explanation.
		 */
		var wantHint = session.unmutePillArmed && muted && caps.mute && ! unmuteSucceeded;

		setMuteHint(wantHint);
	}

	/**
	 * Drive the mute chip's expanding "Tap to unmute" label (AC 27's timings).
	 *
	 * The label is the REFUSAL ARM of §4.1, not an unconditional affordance.
	 * Aman's build opens muted every time and shows this label as the way in;
	 * we keep §4.1's unmuted attempt, so the label only appears when the
	 * BROWSER refused -- which is why the gate above has four terms and not
	 * one. The paint always reflects real state; only the LABEL is gated.
	 *
	 * THE TIMINGS, and why each exists:
	 *
	 *   +350ms in   the chip is already expanding from 34px as the slide
	 *               settles; opening the label in the same frame as the slide
	 *               change reads as a layout jump rather than an invitation.
	 *   4500ms out  it retracts on its own. A permanent label is chrome, not a
	 *               hint, and it would sit over the video for the whole
	 *               session on a browser that always refuses.
	 *
	 * IT REPLAYS PER SLIDE while still in the refused-muted state, and that
	 * falls out of the existing structure rather than needing a replay timer:
	 * navigate() disarms, then the new slide's own unmuted attempt is refused
	 * and re-arms. So the label follows the actual refusals rather than a
	 * remembered one -- and a slide that DOES get audio simply never arms.
	 *
	 * AND IT STOPS FOREVER once the visitor has real audio, keyed on
	 * `unmuteSucceeded`, which only attemptPlay()'s resolve handler writes,
	 * and only after re-reading the element as genuinely unmuted. A TAP IS NOT
	 * A SUCCESS: keying this on the tap instead is the defect Instagram fixed
	 * in `0be01f4f`, and it matters because a tap that ends in another refusal
	 * must leave the affordance in place. Otherwise the visitor taps once,
	 * gets nothing, and every later slide is silent with no explanation.
	 *
	 * An explicit mute by the visitor also suppresses it -- toggleMute()
	 * clears the armed flag, so rule 1.7(c) is honoured by disarming rather
	 * than by a fifth term here.
	 *
	 * @param {boolean} want Whether the label should be offered.
	 *
	 * @return {void}
	 */
	function setMuteHint(want) {
		if (! session) {
			return;
		}

		if (! want) {
			clearMuteHint();
			session.dom.mute.classList.remove('cff-swipeview-mute-hinting');

			return;
		}

		// Already showing, or already scheduled: leave it alone. Re-entering
		// on every 250ms chrome poll would otherwise restart the retract timer
		// forever and the label would never leave.
		if (session.hintTimer || session.hintRetract
			|| session.dom.mute.classList.contains('cff-swipeview-mute-hinting')) {
			return;
		}

		session.hintTimer = window.setTimeout(function () {
			if (! session) {
				return;
			}

			session.hintTimer = null;
			session.dom.mute.classList.add('cff-swipeview-mute-hinting');

			session.hintRetract = window.setTimeout(function () {
				if (! session) {
					return;
				}

				session.hintRetract = null;
				session.dom.mute.classList.remove('cff-swipeview-mute-hinting');
			}, MUTE_HINT_HOLD_MS);
		}, MUTE_HINT_DELAY_MS);
	}

	/**
	 * Drop any pending label timers.
	 *
	 * Called on a slide change and on close. Without it a timer armed for the
	 * slide being swiped away fires against the next one -- opening a label on
	 * a slide whose sound was never refused.
	 *
	 * @return {void}
	 */
	function clearMuteHint() {
		if (! session) {
			return;
		}

		if (session.hintTimer) {
			window.clearTimeout(session.hintTimer);
			session.hintTimer = null;
		}

		if (session.hintRetract) {
			window.clearTimeout(session.hintRetract);
			session.hintRetract = null;
		}
	}

	/**
	 * @return {void}
	 */
	function updateChrome() {
		if (! session) {
			return;
		}

		var total = session.slides.length;

		/*
		 * "3 of 8", not "3 / 8" -- AC 5's wording, and the change matters now
		 * that this string is ONLY ever spoken. A slash is unambiguous read
		 * with the eye and is not read consistently aloud: screen readers
		 * variously announce it as "slash", as "of", or skip it entirely, so
		 * "3 / 8" reaches the listener as "three slash eight" or "three
		 * eight". The word is the announcement now, so it is spelled out.
		 */
		session.dom.counter.textContent = (session.index + 1) + ' of ' + total;

		var slot = activeSlot();
		var caps = slot ? slot.caps : NO_CAPS;

		// S6.1 -- progress is HIDDEN when the tier cannot report it. Hidden
		// rather than disabled because it is a readout, not a control: there is
		// no action to refuse, and a permanently-empty bar is a claim that
		// playback has not started.
		session.dom.progress.hidden = ! caps.progress;

		// S2.3's end clamp, made visible. Disabling rather than removing keeps
		// the geometry stable -- a control that vanishes moves its sibling --
		// and drops the button out of the Tab cycle via the :not([disabled])
		// filter, so a keyboard visitor never lands on a dead stop at either
		// end.
		session.dom.navPrev.disabled = session.index <= 0;
		session.dom.navNext.disabled = session.index >= total - 1;

		/*
		 * The CTA pill is a SESSION-level element carrying PER-SLIDE data, so
		 * both its href and its `hidden` are refreshed here on every slide
		 * change -- and `hidden` genuinely varies rather than being belt and
		 * braces. Graph is never asked for `permalink_url` on either edge, so
		 * a Reel's permalink is DERIVED, and the seam reports absence (an empty
		 * string) rather than handing back the embed-wrapper URL it cannot
		 * distinguish from a real permalink. An empty href is not rendered.
		 *
		 * The top row is `justify-content: flex-end`, so when the pill hides
		 * the mute chip slides right into the space. That is correct -- nothing
		 * else occupies it -- but it is asserted rather than assumed, because
		 * it means the chip's own position is a function of a per-slide value.
		 */
		var slide = slot ? session.slides[ slot.index ] : null;
		var permalink = (slide && isFacebookUrl(slide.permalink)) ? slide.permalink : '';

		if (permalink) {
			session.dom.cta.setAttribute('href', permalink);
			session.dom.cta.hidden = false;
		} else {
			session.dom.cta.removeAttribute('href');
			session.dom.cta.hidden = true;
		}

		setProgress(slot);

		// The pause glyph follows the tier's ACTUAL play state, never a
		// caller's intent -- see setPausedGlyph().
		var playing = !! (slot && slot.inst && slot.inst.isPlaying && slot.inst.isPlaying());

		setPausedGlyph(!! caps.playPause && !! slot && slot.playingSeen && ! playing);

		updateMuteChrome();
		syncPlayState();
		syncCaptionOverflow();
	}

	/**
	 * S6.1's play-state readout for assistive technology.
	 *
	 * There is deliberately no persistent play/pause BUTTON -- neither
	 * platform's Reels UI has one, and S6.1's platform-native rule makes that
	 * the target. But "play/pause reflects actual player state" is BEHAVIOUR
	 * and stays normative however the control is rendered, so the state is paid
	 * for with an sr-only live region fed from the same 250ms real-state sample
	 * the centre glyph echoes visually. Sighted and AT visitors learn the same
	 * fact through different channels.
	 *
	 * Announces only on CHANGE -- a live region rewritten with an unchanged
	 * value four times a second is noise, not access.
	 *
	 * Silent where the tier has no playPause capability (S6.2) rather than
	 * announcing a state that is not real.
	 *
	 * @return {void}
	 */
	function syncPlayState() {
		var slot = activeSlot();
		var caps = slot ? slot.caps : NO_CAPS;
		var text;

		if (! slot || ! slot.inst || ! caps.playPause) {
			text = '';
		} else if (! slot.playingSeen) {
			text = 'Loading';
		} else {
			text = (slot.inst.isPlaying && slot.inst.isPlaying()) ? 'Playing' : 'Paused';
		}

		if (text === session.lastPlayStateText) {
			return;
		}

		session.lastPlayStateText = text;
		session.dom.playState.textContent = text;
	}

	/**
	 * Reveal the caption's expander only when the text ACTUALLY overflows its
	 * clamp -- S6.1's "revealed only on measured overflow".
	 *
	 * `scrollHeight > clientHeight + 1` rather than a character count or a
	 * guess about line length: the clamp is a CSS property and the overflow is
	 * a layout fact, so only layout can answer it. The 1px tolerance absorbs
	 * sub-pixel line-height rounding, which otherwise reveals the button on
	 * captions that fit exactly.
	 *
	 * Runs on every chrome update, so a rotation or a font swap that changes
	 * the answer is picked up without its own listener.
	 *
	 * @return {void}
	 */
	function syncCaptionOverflow() {
		var slot = activeSlot();

		if (! slot || ! slot.chromeEl) {
			return;
		}

		var caption = slot.chromeEl.querySelector('.cff-swipeview-caption');
		var text    = slot.chromeEl.querySelector('.cff-swipeview-caption-text');

		if (! caption || ! text) {
			return;
		}

		if (session.captionExpanded) {
			/*
			 * While expanded the clamp is off, so the measurement below would
			 * hide the very button the visitor needs to collapse with. The
			 * expanded state always shows it.
			 */
			caption.classList.add('cff-swipeview-caption-has-more');

			return;
		}

		/*
		 * MEASURED ON WIDTH, not height -- and this is the retarget AC 17
		 * forces rather than a refactor.
		 *
		 * The caption was a three-line `-webkit-line-clamp` block, so overflow
		 * was `scrollHeight > clientHeight`. It is now ONE line with `nowrap` +
		 * ellipsis, and a nowrap line has no height overflow at all: its
		 * scrollHeight equals its clientHeight however long the text is. The
		 * height test would therefore report "no overflow" for every caption
		 * ever written, hiding the "more" button permanently and silently
		 * truncating every caption at one line with no way to read the rest.
		 *
		 * So the axis moves with the clamp: `scrollWidth > clientWidth`.
		 *
		 * The 1px tolerance is for sub-pixel text metrics -- a line that fits
		 * exactly can measure 0.4px over and would otherwise offer a "more"
		 * that reveals nothing.
		 */
		var overflowing = text.scrollWidth > text.clientWidth + 1;

		caption.classList.toggle('cff-swipeview-caption-has-more', overflowing);
	}

	/**
	 * @return {void}
	 */
	function toggleCaption() {
		if (! session) {
			return;
		}

		setCaptionExpanded(! session.captionExpanded);
	}

	/**
	 * @param {boolean} expanded Target state.
	 *
	 * @return {void}
	 */
	function setCaptionExpanded(expanded) {
		if (! session || session.captionExpanded === expanded) {
			return;
		}

		session.captionExpanded = expanded;
		// An ATTRIBUTE rather than a class, so the stylesheet's state selector
		// reads `[data-caption="expanded"]` and cannot be confused with the
		// many `cff-swipeview-*` classes this root already carries. It is also
		// greppable as one string.
		session.dom.root.setAttribute('data-caption', expanded ? 'expanded' : 'collapsed');

		var slot = activeSlot();

		if (slot && slot.chromeEl) {
			var caption = slot.chromeEl.querySelector('.cff-swipeview-caption');
			var more    = slot.chromeEl.querySelector('.cff-swipeview-caption-more');

			if (more) {
				more.setAttribute('aria-expanded', expanded ? 'true' : 'false');
				more.textContent = expanded ? 'less' : 'more';
			}

			/*
			 * The expanded state is a class on the CAPTION, not only an
			 * attribute on the root. Both exist and they do different jobs:
			 * the root attribute is the session's state (one caption is
			 * expandable at a time), while this class is what the scroll
			 * surface's rules hang off -- and those rules have to target the
			 * element that scrolls, which is per-slide.
			 */
			if (caption) {
				caption.classList.toggle('cff-swipeview-caption-expanded', expanded);
			}
		}

		syncCaptionOverflow();
	}

	/* ═══════════════════ Controls ═══════════════════ */

	/**
	 * @return {void}
	 */
	function toggleMute() {
		var slot = activeSlot();

		if (! slot || ! slot.caps.mute) {
			return;
		}

		var shouldUnmute = realMuted();

		// Record the new EXPLICIT choice, in EITHER direction (S4.2): an
		// explicit mute suppresses S4.1's unmuted attempt on later slides just
		// as an explicit unmute restores it.
		userMuted = ! shouldUnmute;

		if (slot.inst && slot.inst.setMuted) {
			slot.inst.setMuted(! shouldUnmute);
		}

		session.unmutePillArmed = false;
		updateChrome();
		emitAnalytics(shouldUnmute ? 'swipeview_unmuted' : 'swipeview_muted', { index: session.index });
	}

	/**
	 * @return {void}
	 */
	function togglePlay() {
		var slot = activeSlot();

		if (! slot || ! slot.inst) {
			return;
		}

		// Disabled, never silently inert (S6.2). On the embed and terminal
		// tiers there is nothing to toggle, so the tap does nothing AND paints
		// no glyph -- a flash with no effect is the "control that silently does
		// nothing" in visual form.
		if (! slot.caps.playPause) {
			return;
		}

		// Resolved ONCE and reused for both the glyph and the branch. Sampling
		// isPlaying() twice -- once for the picture, once for the action -- is
		// how the two come to disagree.
		var willPlay = ! (slot.inst.isPlaying && slot.inst.isPlaying());

		/*
		 * No glyph call here any more. The pause glyph is a state readout, so
		 * it is written by updateChrome() below from the tier's ACTUAL play
		 * state rather than from this branch's intent. That matters: a paint
		 * driven from intent shows "paused" the moment the visitor taps, even
		 * when the pause never took -- which is the same
		 * optimistic-paint-versus-reality gap rule 1.7(a) rules out for the
		 * mute chip.
		 */
		if (! willPlay) {
			clearWatchdogs(slot);
			slot.inst.pause();
		} else {
			// A tap IS a gesture, so this attempt gets the session's intent
			// unnegated -- the same rule activation follows.
			attemptSlotPlay(slot, session.index, userMuted);
		}

		updateChrome();
	}

	/**
	 * THE ONE WRITER of the progress bar (rule 1.12 / AC 29).
	 *
	 * It is one function because it used to be two: `tick()` wrote the fill on
	 * its 250ms interval and nothing else did, so a slide change did not move
	 * the bar until the next tick. Both callers now go through here, which is
	 * what makes the synchronous-write-on-slide-change half of AC 29 true at
	 * all.
	 *
	 * `transform: scaleX()` rather than `width`, and a TRANSITION whose
	 * duration equals CHROME_POLL_MS. Three things follow:
	 *
	 * 1. The bar interpolates between the 250ms samples §6.1 requires instead
	 *    of stepping. Facebook declared no transition at all, so it stepped.
	 * 2. A transform animates on the compositor; a width relayouts every frame.
	 * 3. Matching the transition to the sample interval means each sample's
	 *    animation finishes exactly as the next arrives. YouTube's sibling
	 *    defect -- which AC 29 names -- is a 250ms sample swept by a 200ms
	 *    transition, leaving a ~450ms window where the bar shows a wrong value
	 *    AND slides toward another one.
	 *
	 * THE BACKWARD GUARD. A slide change or a loop wrap moves the value DOWN,
	 * and an animated decrease reads as the bar rewinding -- rule 1.12's "jump
	 * on nav". The guard class is added, the value written, and the class
	 * removed on the NEXT FRAME, so exactly that one write is unanimated.
	 *
	 * The add-and-write must happen in ONE TASK, and that is the part worth
	 * stating: a write deferred past the class removal is animated after all,
	 * so the guard would be present in the source and suppress nothing. Only
	 * the REMOVAL is deferred.
	 *
	 * @param {Object|null} slot The active slot, if any.
	 *
	 * @return {void}
	 */
	function setProgress(slot) {
		if (! session) {
			return;
		}

		var fraction = 0;

		if (slot && slot.inst && slot.inst.progress) {
			var reading = slot.inst.progress();

			// `progress()` reports {current, duration}, not a fraction -- and
			// a zero or absent duration is "not known yet", not "at the
			// start", so it must not divide.
			if (reading && reading.duration > 0) {
				fraction = reading.current / reading.duration;
			}
		}

		fraction = Math.max(0, Math.min(1, fraction));

		var fill = session.dom.progressFill;
		var backward = fraction < session.lastProgress;

		if (backward) {
			fill.classList.add('cff-swipeview-progress-fill-jump');
		}

		fill.style.transform = 'scaleX(' + fraction + ')';
		session.dom.progress.setAttribute('aria-valuenow', String(Math.round(fraction * 100)));
		session.lastProgress = fraction;

		if (backward) {
			window.requestAnimationFrame(function () {
				if (session) {
					session.dom.progressFill.classList.remove('cff-swipeview-progress-fill-jump');
				}
			});
		}
	}

	/**
	 * Paint the paused state (rule 1.10 / AC 11).
	 *
	 * This replaced flashPlayGlyph(), and the change is one of KIND rather
	 * than of styling. The old function built a glyph, added a class, and set
	 * a 600ms timer to take it away again -- a transient echo answering "you
	 * tapped". The new one writes a single attribute on the root and lets CSS
	 * decide what to show, so the glyph is a READOUT of whether the slide is
	 * paused and answers the question §6.1 actually puts on the visual channel.
	 *
	 * There is no timer, and that removes a whole defect class: a timer-owned
	 * paint can outlive the state it describes (pause, resume within 600ms,
	 * and the old flash was still fading in over a playing video) or lag it
	 * (two taps inside one window left the wrong glyph on screen). An
	 * attribute cannot disagree with the value that wrote it.
	 *
	 * The `-was` class is the one piece of bookkeeping left: it is left behind
	 * for a single 100ms window after unpausing so the glyph can animate OUT
	 * rather than vanishing. It is removed by a timer, but it is DECORATION
	 * ONLY -- if that timer never fires, the CSS still hides the glyph via the
	 * `[data-paused="false"]` selector on everything but this class, so the
	 * worst case is a dissolve that does not play, never a glyph stuck on
	 * screen.
	 *
	 * @param {boolean} paused Whether the active slide is paused.
	 *
	 * @return {void}
	 */
	function setPausedGlyph(paused) {
		if (! session) {
			return;
		}

		var root  = session.dom.root;
		var glyph = session.dom.pauseGlyph;
		var was   = root.getAttribute('data-paused') === 'true';

		root.setAttribute('data-paused', paused ? 'true' : 'false');

		if (paused) {
			glyph.classList.remove('cff-swipeview-pauseglyph-was');

			if (session.glyphTimer) {
				window.clearTimeout(session.glyphTimer);
				session.glyphTimer = null;
			}

			return;
		}

		// Only arm the dissolve if there was something to dissolve FROM.
		// Without this check every 250ms chrome poll on a playing slide
		// re-arms a 100ms animation on a hidden element.
		if (! was) {
			return;
		}

		glyph.classList.add('cff-swipeview-pauseglyph-was');

		if (session.glyphTimer) {
			window.clearTimeout(session.glyphTimer);
		}

		session.glyphTimer = window.setTimeout(function () {
			if (! session) {
				return;
			}

			session.glyphTimer = null;
			session.dom.pauseGlyph.classList.remove('cff-swipeview-pauseglyph-was');
		}, PAUSE_GLYPH_OUT_MS);
	}

	/**
	 * @param {Event} event The click.
	 *
	 * @return {void}
	 */
	function onNavClick(event) {
		var button = event.currentTarget || event.target;
		var dir = (button && button.getAttribute) ? button.getAttribute('data-nav') : null;

		// Anything other than the two known values is ignored rather than
		// guessed at -- a mistyped attribute must not silently navigate the
		// wrong way.
		if (dir !== 'prev' && dir !== 'next') {
			return;
		}

		navigate(dir === 'next' ? 1 : -1);
	}

	/**
	 * The 250ms sample (spec S6.1: play state refreshed at least this often).
	 *
	 * BELT-AND-BRACES HERE, NOT LOAD-BEARING -- and that is the Instagram
	 * difference. On YouTube this poll is the ONLY thing that notices the
	 * player muting itself, because the YT API fires no `volumechange`. Tier 1
	 * here is a real `<video>` with a real `volumechange` listener, so the mute
	 * chrome is already correct within a frame of any change and this poll only
	 * covers progress and the play-state announcement.
	 *
	 * @return {void}
	 */
	function tick() {
		if (! session) {
			return;
		}

		var slot = activeSlot();

		setProgress(slot);
		updateMuteChrome();
		syncPlayState();

		// The active slide's loader tracks OBSERVED playback, not intent.
		if (slot) {
			showLoader(slot, ! slot.playingSeen);
		}
	}

	/* ═══════════════════ Gestures (spec S3) ═══════════════════
	 *
	 * RATIFIED (2026-08-24 team feedback, items B and the area rule):
	 * "the scroll should follow the thumb as to feel responsive and when the
	 * thumb lifts up, based on which reel occupies the most area, it scrolls up
	 * or down" (Aman); "it would be more smooth to start the scroll when the
	 * finger touches the device, not after the finger finishes the swipe"
	 * (Alex). Both siblings implemented it; this is a port of the shape, not a
	 * re-derivation.
	 *
	 * The two functions below are PURE -- no DOM, no session, no framework --
	 * and that is deliberate. The properties that actually matter here (the
	 * track can never travel further than there is a populated slot to reveal;
	 * the release decision is a majority-of-viewport rule with a DERIVED
	 * boundary) are worth unit- and mutation-testing without a browser around
	 * them, and the node tier calls them directly through the test seam.
	 *
	 * SIGN CONVENTION, chosen once so it cannot drift between the geometry and
	 * the handlers: a positive offset means the track has been pulled DOWN,
	 * which is `touch.clientY - startY`. Pulling down reveals the PREVIOUS
	 * slide above; pulling up (negative) reveals the NEXT slide below. The
	 * follow path never negates anything, because the track moves WITH the
	 * finger.
	 */

	/**
	 * Clamp a raw finger delta to what the track can honestly show.
	 *
	 * Two separate limits that happen to coincide, so one expression serves
	 * both:
	 *
	 * 1. S2.3, normative: a STRICT clamp at the ends of the track with NO
	 *    rubber-band. On the first slide the track cannot be pulled down at
	 *    all; on the last it cannot be pulled up. Both siblings hard-clamp, and
	 *    Instagram's own history is the argument -- it shipped a gentle bounce
	 *    past the end and removed it on maintainer feedback because the
	 *    transform re-fired on every key-repeat and juddered the track. Letting
	 *    the DRAG path reveal empty space would reintroduce that overshoot by
	 *    the back door.
	 * 2. The slot window (S4.4) holds the active slide and one neighbour either
	 *    side, and recycles on COMMIT rather than mid-gesture -- so past one
	 *    viewport in either direction there is no populated slot to reveal, and
	 *    dragging further would expose an empty slot.
	 *
	 * One viewport is therefore the travel limit in both directions, and it is
	 * also exactly what "one slide per gesture" allows. This is the one place
	 * the follow stops being strictly 1:1 with the finger, and it is
	 * deliberate: 1:1 holds throughout the range a gesture can actually commit
	 * to.
	 *
	 * @param {number} rawOffset Finger travel, down-positive.
	 * @param {Object} opts      { index, total, viewportHeight }.
	 *
	 * @return {number} The clamped offset.
	 */
	/**
	 * Whether this device gets the desktop layout.
	 *
	 * The SAME capability probe the stylesheet's one media query uses, so the
	 * JS and the CSS cannot disagree about which layout is on screen -- which
	 * matters for the coach, because a coach shown on desktop is teaching a
	 * gesture the visitor has no way to perform.
	 *
	 * @return {boolean}
	 */
	function isDesktopViewport() {
		if (! window.matchMedia) {
			// No matchMedia means a very old engine, which gets the touch
			// layout as the base -- so it is consistent to treat it as touch
			// here too.
			return false;
		}

		return window.matchMedia(DESKTOP_QUERY).matches;
	}

	/**
	 * Whether the first-run coach has already been shown (rule 1.9).
	 *
	 * Wrapped, because localStorage THROWS rather than returning null in
	 * Safari's private mode and under a blocked-cookies policy. An exception
	 * here would abort open() -- so the failure direction is deliberate: if
	 * the store cannot be read, treat the coach as already seen. A visitor
	 * who never sees a hint has lost a hint; a visitor whose viewer fails to
	 * open has lost the feature.
	 *
	 * @return {boolean}
	 */
	function coachAlreadySeen() {
		try {
			return window.localStorage.getItem(COACH_STORAGE_KEY) === '1';
		} catch (e) {
			return true;
		}
	}

	/**
	 * @return {void}
	 */
	function markCoachSeen() {
		try {
			window.localStorage.setItem(COACH_STORAGE_KEY, '1');
		} catch (e) {
			// Nothing to do. The coach then shows again next session, which is
			// a far better failure than an exception in the open path.
		}
	}

	/**
	 * Show the first-run coach, if it is owed (rule 1.9 / AC 12).
	 *
	 * FOUR gates, and each removes a way for this to be an annoyance rather
	 * than a hint: touch only (desktop has chevrons and a cursor), once ever
	 * (localStorage, plugin-namespaced), reduced motion drops the animation
	 * but keeps the text, and the dismiss listeners are armed 350ms LATE.
	 *
	 * THE ARM DELAY IS THE SUBTLE ONE. The tap that opened the viewer is still
	 * settling when this runs, so listeners armed immediately catch it and
	 * dismiss the overlay before it can be read -- the visitor sees a flash of
	 * something and never learns what it said.
	 *
	 * @return {void}
	 */
	function showCoach() {
		if (! session || isDesktopViewport() || coachAlreadySeen()) {
			return;
		}

		var coach = session.dom.coach;

		coach.classList.add('cff-swipeview-coach-on');
		markCoachSeen();

		var dismiss = function () {
			if (! session) {
				return;
			}

			session.dom.coach.classList.remove('cff-swipeview-coach-on');

			if (session.coachAuto) {
				window.clearTimeout(session.coachAuto);
				session.coachAuto = null;
			}

			if (session.coachDismiss) {
				session.dom.gestures.removeEventListener('touchstart', session.coachDismiss);
				session.dom.gestures.removeEventListener('wheel', session.coachDismiss);
				session.coachDismiss = null;
			}
		};

		session.coachAuto = window.setTimeout(dismiss, COACH_AUTO_MS);

		window.setTimeout(function () {
			if (! session || ! session.dom.coach.classList.contains('cff-swipeview-coach-on')) {
				return;
			}

			session.coachDismiss = dismiss;
			// Passive: these only ever read that an interaction happened.
			session.dom.gestures.addEventListener('touchstart', dismiss, { passive: true });
			session.dom.gestures.addEventListener('wheel', dismiss, { passive: true });
		}, COACH_ARM_MS);
	}

	/**
	 * Rule 1.16 / AC 12's pull-to-close follow distance.
	 *
	 * Kept as its own pure function rather than folded into
	 * clampDragOffset(), and that separation is deliberate. The clamp
	 * implements the RATIFIED strict-clamp feel (SMASH-1978) and carries its
	 * own pins; a downward drag at slide 0 returns a hard zero there, which is
	 * correct for navigation because there is no previous slide to reveal.
	 * Pull-to-close is a DIFFERENT gesture that happens to share an input, so
	 * it gets its own term and its own tests, and the clamp's contract does not
	 * move.
	 *
	 * THE DAMPING IS WHAT PRESERVES THE CLAMP'S FEEL. An undamped follow at
	 * slide 0 is indistinguishable from the track scrolling somewhere it cannot
	 * go, which is exactly what the strict clamp exists to prevent. At 35% of
	 * the finger, capped at 160px, the visitor gets a physical acknowledgement
	 * that the gesture registered without the track ever appearing to navigate.
	 *
	 * Every condition is the CALLER's to establish -- touch, slide 0, at rest,
	 * downward -- because this function cannot know them and guessing would
	 * make it wrong somewhere. It only shapes a distance.
	 *
	 * @param {number} rawOffset The finger's downward travel in px.
	 *
	 * @return {number} The damped, capped follow distance.
	 */
	function pullFollow(rawOffset) {
		if (! (rawOffset > 0)) {
			return 0;
		}

		return Math.min(rawOffset * PULL_CLOSE_DAMP, PULL_CLOSE_MAX_PX);
	}

	/**
	 * Whether a released pull commits to closing (rule 1.16 / AC 12).
	 *
	 * Measured on the FINGER's travel, not on the damped follow distance. That
	 * is the distinction worth stating: the follow is capped at 160px, so a
	 * threshold applied to it would be reachable by a 400px pull and a 460px
	 * pull alike but never distinguish them -- and at 35% damping a 140px
	 * follow needs a 400px finger travel, which is most of a phone screen.
	 * The threshold belongs on the gesture the visitor performed.
	 *
	 * @param {Object} opts `{ rawOffset, index, atRest, touch }`.
	 *
	 * @return {boolean}
	 */
	function decidePullClose(opts) {
		var o = opts || {};

		// SLIDE 0 ONLY. Anywhere else a downward drag is a navigation to the
		// previous slide, and closing instead would throw away the visitor's
		// place in the feed on a gesture they use constantly.
		if (o.index !== 0) {
			return false;
		}

		// TOUCH ONLY -- there is no pull gesture with a mouse, and a trackpad
		// two-finger scroll must never close the viewer.
		if (! o.touch) {
			return false;
		}

		// AT REST ONLY. Mid-transition the index is already changing, and
		// committing a close against a moving track races the navigation.
		if (! o.atRest) {
			return false;
		}

		return (o.rawOffset || 0) > PULL_CLOSE_COMMIT_PX;
	}

	function clampDragOffset(rawOffset, opts) {
		var o = opts || {};
		var index = o.index || 0;
		var total = o.total || 0;
		var reach = o.viewportHeight > 0 ? o.viewportHeight : 0;
		// Down reveals the previous slide; up reveals the next. At either end
		// of the track the corresponding limit collapses to zero.
		var maxDown = index > 0 ? reach : 0;
		var maxUp   = index < total - 1 ? reach : 0;
		var clamped = rawOffset;

		if (rawOffset > maxDown) {
			clamped = maxDown;
		} else if (rawOffset < -maxUp) {
			clamped = -maxUp;
		}

		// Negating a zero limit yields `-0`, a distinct value under Object.is
		// that would leak into every downstream comparison and assertion for
		// no benefit. Normalised once, here, rather than tolerated by every
		// caller.
		return clamped === 0 ? 0 : clamped;
	}

	/**
	 * Where to land when the finger lifts: 1 for the next slide, -1 for the
	 * previous, 0 to return to the one already showing.
	 *
	 * THE PRIMARY RULE IS AREA -- the release snaps to whichever slide occupies
	 * most of the viewport. Because the track is a contiguous strip of
	 * viewport-height slides, that reduces to one comparison: the adjacent
	 * slide covers exactly `|dragOffset|` of the viewport and the current one
	 * covers the remaining `viewportHeight - |dragOffset|`, so the adjacent
	 * slide holds the majority precisely when
	 * `|dragOffset| > viewportHeight * 0.5`.
	 *
	 * The boundary is DERIVED from the viewport, never a tuned constant, and a
	 * majority is a STRICT inequality -- so an exact half-and-half split
	 * RETURNS rather than advancing. That matters: a gesture ending precisely
	 * on the midpoint has expressed no preference, and returning is the
	 * recoverable choice.
	 *
	 * THE FLICK ACCELERATOR IS LAYERED ON TOP as a deliberate composition, not
	 * a fallback: a short fast flick advances even though it never uncovered
	 * half the viewport, because that is what a flick means to a thumb and
	 * because every native player commits on one. This is the one part of the
	 * rule that is a product judgement rather than geometry.
	 *
	 * THE ONE NARROWING, STATED PLAINLY: a SLOW drag past 60px that never
	 * crosses half the viewport RETURNS, where a threshold-only implementation
	 * would advance. That is not a side effect; it is the point of an area
	 * rule, and both siblings made the same narrowing. Without the duration
	 * bound the 60px rule would subsume the area rule entirely -- every drag
	 * past 60px would commit, so the majority test could never decide anything
	 * and the area rule would be cosmetic.
	 *
	 * OPERATORS: `>=` on distance and `<=` on duration, which is the pair both
	 * siblings shipped. A strict pair disagrees only at exactly 60px and
	 * exactly 600ms; the inclusive one is kept so the flick behaves identically
	 * to what was measured on the siblings.
	 *
	 * @param {Object} opts { dragOffset, viewportHeight, durationMs }.
	 *
	 * @return {number} -1, 0 or 1.
	 */
	function decideSnap(opts) {
		var o = opts || {};
		var distance = Math.abs(o.dragOffset || 0);

		if (distance === 0) {
			return 0;
		}

		// Down (positive) reveals the previous slide, so it navigates backwards.
		var direction = o.dragOffset < 0 ? 1 : -1;

		// The area rule. Guarded on a real height so the function stays total:
		// a zero-height viewport cannot be reasoned about by area, and
		// answering "majority" from a zero denominator would commit on the
		// tiniest movement.
		if (o.viewportHeight > 0 && distance > o.viewportHeight * DRAG_SNAP_AREA_FRACTION) {
			return direction;
		}

		if (distance >= SWIPE_THRESHOLD_PX && o.durationMs <= SWIPE_MAX_DURATION_MS) {
			return direction;
		}

		return 0;
	}

	/**
	 * THE one place tap suppression is captured, and the one place drag state
	 * is cleared.
	 *
	 * Every path that ends a gesture routes through here -- a release, a
	 * cancel, a second finger aborting a pinch, and close() disarming a gesture
	 * still in flight -- which is what makes "a drag never toggles playback" a
	 * property of ENDING a drag rather than something four call sites have to
	 * remember. A sibling viewer shipped exactly that defect by capturing the
	 * flag at the call sites and missing the pinch-abort path.
	 *
	 * `dragDeltaPx` is zeroed here for the same reason: this is the one
	 * function every gesture-end path reaches, so a delta left armed here is a
	 * delta the NEXT gesture's first touchmove would compose against. Note this
	 * clears the drag's STATE, not the track's transform -- returning the track
	 * is a separate, animated act (settleBack) that only the paths which did
	 * not commit should perform.
	 *
	 * @return {void}
	 */
	function resetDrag() {
		if (! session) {
			return;
		}

		session.suppressTap = session.dragging;
		session.touchStartY = null;
		session.dragging = false;
		session.dragDeltaPx = 0;
	}

	/**
	 * @param {WheelEvent} event The wheel.
	 *
	 * @return {void}
	 */
	function onWheel(event) {
		// Return BEFORE preventDefault while the caption is expanded, so a
		// wheel that lands on it scrolls it natively. Calling preventDefault
		// first and bailing after would suppress the scroll and leave a long
		// caption unreadable on a trackpad -- S6.1's "the expanded caption owns
		// its own scroll surface".
		if (session.captionExpanded) {
			return;
		}

		/*
		 * A ctrl-modified wheel is a PINCH-ZOOM, not a scroll -- that is how
		 * every trackpad reports one, and how a browser's own zoom gesture
		 * arrives. Passing it through navigated the feed while the visitor was
		 * trying to zoom, and preventDefault-ing it would suppress the zoom
		 * entirely. So it is returned on before either happens, which leaves
		 * the browser to do its own thing (rule 1.16).
		 */
		if (event.ctrlKey) {
			return;
		}

		event.preventDefault();

		var now = Date.now();

		/*
		 * ── THE ACCUMULATOR (rule 1.16) ──────────────────────────────────────
		 *
		 * This replaced a per-event threshold (`Math.abs(deltaY) < 25`), which
		 * is the wrong shape for a trackpad: individual deltas there are often
		 * 1-3px, so the threshold either never fires or -- on a mouse wheel,
		 * whose single notch is ~100px -- fires on every notch with no
		 * accumulation at all. Two devices, two failure modes, one constant.
		 *
		 * A gap longer than WHEEL_IDLE_MS ends the gesture and zeroes the
		 * accumulator, so three small scrolls minutes apart never add up to a
		 * navigation.
		 */
		if (now - session.wheelLastAt > WHEEL_IDLE_MS) {
			session.wheelAccum = 0;
			session.wheelSpent = false;
		}

		session.wheelLastAt = now;

		/*
		 * THE INERTIA TAIL. After a trackpad flick the browser keeps sending
		 * events for hundreds of milliseconds while the fingers are already
		 * off the surface. Once this gesture has navigated, `wheelSpent` stays
		 * true until the gesture actually ENDS (the idle gap above), so the
		 * tail is discarded rather than walking the visitor through the feed.
		 */
		if (session.wheelSpent) {
			return;
		}

		// Direction changes mid-gesture restart the accumulation, so a
		// wobble cannot cancel itself into a phantom navigation.
		if ((session.wheelAccum > 0) !== (event.deltaY > 0) && session.wheelAccum !== 0) {
			session.wheelAccum = 0;
		}

		session.wheelAccum += event.deltaY;

		if (Math.abs(session.wheelAccum) < WHEEL_ACCUM_PX) {
			return;
		}

		// At least WHEEL_SLIDE_COOLDOWN_MS between slides, so one flick is one
		// slide however much delta it carried.
		if (now - session.wheelNavAt < WHEEL_SLIDE_COOLDOWN_MS) {
			return;
		}

		var direction = session.wheelAccum > 0 ? 1 : -1;

		session.wheelNavAt = now;
		session.wheelAccum = 0;
		session.wheelSpent = true;

		navigate(direction);
	}

	/**
	 * @param {TouchEvent} event The touchstart.
	 *
	 * @return {void}
	 */
	function onTouchStart(event) {
		/*
		 * SINGLE FINGER ONLY. A second touch is a pinch or a stray palm;
		 * reading touches[0] unconditionally re-bases the gesture on the new
		 * finger and the track lurches by the distance between the two
		 * contacts.
		 *
		 * An abort expresses no destination, so a follow already in progress
		 * RETURNS -- the same treatment onTouchCancel gives an interrupted
		 * gesture. Reading `dragging` before resetDrag() clears it is what
		 * makes that distinguishable from a two-finger tap, which has nothing
		 * to return.
		 */
		if (! event.touches || event.touches.length !== 1) {
			if (session.touchStartY !== null) {
				var wasDragging = session.dragging;

				resetDrag();

				if (wasDragging) {
					settleBack();
				}
			}

			return;
		}

		/*
		 * THE CAPTION'S GESTURE IS NOT THE TRACK'S.
		 *
		 * navigate() already refuses while the caption is expanded, which was
		 * sufficient when a touch could only ever RESULT in a navigation. A
		 * follow-drag is different in kind: it moves the track on every
		 * touchmove, before any navigation is decided. Relying on navigate()
		 * alone would let the visitor drag the whole feed around underneath an
		 * expanded caption and then watch it snap back -- the track would
		 * visibly budge even though nothing navigated, which reads as the
		 * viewer fighting the caption.
		 *
		 * Refused at the START of the gesture rather than clamped to zero in
		 * the follow. Both would hold the track still, but a refusal also
		 * leaves `touchStartY` null, so onTouchMove returns at its first guard
		 * and never calls preventDefault() -- which is what lets the caption's
		 * own scroll surface keep the gesture natively. A zero-clamp would
		 * swallow the scroll and leave a long caption unreadable, the same
		 * defect onWheel's bail exists to avoid one input source over.
		 */
		if (session.captionExpanded) {
			session.touchStartY = null;
			return;
		}

		// A drag that cannot commit must not be allowed to follow the finger:
		// mid-transition it would fight the running snap, and inside the nav
		// cooldown it could only ever rubber-band back, which reads as a broken
		// control rather than as a rate limit.
		if (session.transitioning || session.navLocked) {
			session.touchStartY = null;
			return;
		}

		session.touchStartY   = event.touches[0].clientY;
		session.touchStartAt  = Date.now();
		session.dragging      = false;
		session.dragDeltaPx   = 0;
		session.dragBaseIndex = session.index;
		/*
		 * Sampled ONCE at touchstart rather than read per move, and that is
		 * deliberate: it is both the denominator of the area rule and the reach
		 * of the clamp, so re-reading it mid-gesture would move the boundary the
		 * visitor is aiming at WHILE they aim at it. A mobile address bar
		 * collapsing under the finger is the realistic way that happens -- and
		 * it is the same class of problem as the 100vh clipping the 2026-08-24
		 * feedback reported, arriving through a different door.
		 */
		session.dragViewportH = slideHeightPx();
	}

	/**
	 * @param {TouchEvent} event The touchmove.
	 *
	 * @return {void}
	 */
	function onTouchMove(event) {
		if (session.touchStartY === null) {
			return;
		}

		if (! event.touches || event.touches.length !== 1) {
			return;
		}

		// Finger delta, DOWN-POSITIVE. The track moves WITH the finger, so this
		// is also the track's delta and nothing on the follow path negates
		// anything.
		var dy = event.touches[0].clientY - session.touchStartY;

		if (! session.dragging) {
			if (Math.abs(dy) < DRAG_START_PX) {
				// A tap's hardware jitter, not a drag.
				return;
			}

			session.dragging = true;
			// The follow must be IMMEDIATE; an inherited transition from the
			// last snap would make the track visibly lag the finger for its
			// duration.
			session.dom.track.style.transition = 'none';
		}

		// Only ever reached for a real drag, never for a tap -- which is what
		// keeps tap-to-play/pause working on this same layer. The listener is
		// registered NON-PASSIVE for exactly this call; a passive listener's
		// preventDefault is ignored (with a console warning) and the page
		// scrolls underneath the viewer.
		event.preventDefault();

		session.dragDeltaPx = clampDragOffset(dy, {
			index: session.dragBaseIndex,
			total: session.slides.length,
			viewportHeight: session.dragViewportH
		});

		/*
		 * PULL-TO-CLOSE's damped follow (rule 1.16 / AC 12). At slide 0 the
		 * clamp above returns a hard zero for a downward drag -- correct for
		 * navigation, since there is no previous slide -- so without this the
		 * track does not move at all and the gesture has no feedback.
		 *
		 * The pull is composed here rather than inside the clamp so the
		 * ratified strict-clamp contract is untouched: this only ever ADDS
		 * movement where the clamp had decided on none.
		 */
		if (session.dragBaseIndex === 0 && dy > 0 && session.dragDeltaPx === 0) {
			session.dragDeltaPx = pullFollow(dy);
			session.pullRawPx = dy;
		} else {
			session.pullRawPx = 0;
		}

		// Composed against the DRAG'S BASE index rather than the live one, so a
		// navigation arriving from elsewhere mid-gesture cannot leave the track
		// drawing a stale drag over a new index.
		setTrackOffset(session.dragBaseIndex * 100, session.dragDeltaPx);
		// THE FOLLOW (SMASH-2064). The rail is outside the track, so its travel
		// is explicit rather than inherited -- but it is the SAME value, never a
		// second derivation, which is what keeps the two from drifting apart at
		// the clamp. Never animated here: a transition would make the rail lag
		// the finger. See setRailTravel().
		setRailTravel(session.dragDeltaPx, false);
	}

	/**
	 * @param {TouchEvent} event The touchend.
	 *
	 * @return {void}
	 */
	function onTouchEnd(event) {
		if (session.touchStartY === null) {
			return;
		}

		var endY = (event.changedTouches && event.changedTouches[0])
			? event.changedTouches[0].clientY
			: session.touchStartY;

		// Read from the touch that LEFT rather than from `dragDeltaPx`: the
		// final touchmove and this touchend can arrive in the same frame, and
		// the stored delta would then be one move behind the finger.
		var downDy      = endY - session.touchStartY;
		var duration    = Date.now() - session.touchStartAt;
		var wasDragging = session.dragging;
		var baseIndex   = session.dragBaseIndex;
		var viewportH   = session.dragViewportH;

		resetDrag();

		/*
		 * PULL-TO-CLOSE is decided BEFORE the snap, because it is a different
		 * outcome rather than a competing direction: a committed pull closes
		 * the viewer, so there is no slide to snap to.
		 *
		 * `atRest` is `! transitioning`, read here rather than trusted from the
		 * gesture's start -- a navigation arriving from elsewhere mid-gesture
		 * is exactly the race this guards.
		 */
		if (decidePullClose({
			rawOffset: downDy,
			index: baseIndex,
			atRest: ! session.transitioning,
			touch: true
		})) {
			emitAnalytics('swipeview_close', { index: session.index, reason: 'pull' });
			closeViewer();

			return;
		}

		/*
		 * A pull that did NOT commit has to return the track by hand. The snap
		 * below cannot do it: at slide 0 a downward drag clamps to zero, so
		 * `decideSnap` sees no movement and reports no direction, and
		 * `wasDragging` then routes to settleBack() -- which is right, but only
		 * because the pull left the track transformed. Stated because the two
		 * paths look interchangeable and are not.
		 */
		var offset = clampDragOffset(downDy, {
			index: baseIndex,
			total: session.slides.length,
			viewportHeight: viewportH
		});
		var direction = decideSnap({
			dragOffset: offset,
			viewportHeight: viewportH,
			durationMs: duration
		});

		// Routed through navigate() rather than moving the track directly, and
		// this is the whole reason the commit is one line: a drag-commit IS a
		// navigation, so it inherits the end clamp, the cooldown, the caption
		// suppression, the stale-pill and tap-flash clears, the slot recycling
		// and the analytics from the same place wheel, keyboard and chevron
		// input get them.
		if (direction !== 0) {
			navigate(direction);
			return;
		}

		// No commit. Only a gesture that actually MOVED the track has anything
		// to return -- a tap must not trigger a settle animation on a
		// stationary track.
		if (wasDragging) {
			settleBack();
		}
	}

	/**
	 * An interrupted gesture (a system gesture taking over, an incoming call)
	 * is not a release: it expresses no destination, so the track returns and
	 * nothing commits.
	 *
	 * @return {void}
	 */
	function onTouchCancel() {
		if (session.touchStartY === null) {
			return;
		}

		var wasDragging = session.dragging;

		resetDrag();

		if (wasDragging) {
			settleBack();
		}
	}

	/**
	 * Swallows exactly one synthesised click -- the one belonging to a drag.
	 * The suppression check stays FIRST so a swipe can never be read as a tap.
	 *
	 * @return {void}
	 */
	/**
	 * Whether a point is inside a rect.
	 *
	 * @param {number} x    Client x.
	 * @param {number} y    Client y.
	 * @param {Object} rect A DOMRect-like.
	 *
	 * @return {boolean}
	 */
	function pointInRect(x, y, rect) {
		return !! rect && x >= rect.left && x <= rect.right
			&& y >= rect.top && y <= rect.bottom;
	}

	/**
	 * Whether a click landed on the BACKDROP rather than on the viewer
	 * (rule 1.16 / AC 12).
	 *
	 * The boundary is the STAGE COLUMN -- the frame itself -- and everything
	 * outside it is backdrop. Two clusters then need carving back out, and
	 * BOTH of them sit outside the frame on desktop, so by the boundary test
	 * alone every pixel of them is "backdrop" and only the controls themselves
	 * are protected. That is not good enough for either.
	 *
	 * THE RAIL NEEDS THE CARVE-OUT MORE THAN THE CHEVRONS DO, and this is the
	 * shape of the defect it prevents: rule IG-2 makes the rail bare glyphs
	 * with no disc, stacked with 18px gaps and 18px of bottom padding. A real
	 * click in the gap between two glyphs, or in the column's bottom padding,
	 * is a near-miss on a control -- and without the carve-out it CLOSES THE
	 * VIEWER, losing the visitor's place in the feed. The per-item hit rings do
	 * not save it: they extend 8px sideways but only 1px vertically, which is
	 * the axis the stack is arranged along.
	 *
	 * Instagram measured exactly that on a live build before fixing it in
	 * `a6d0ca03` -- verified in that file rather than taken from its change
	 * log, because the log for an earlier round claimed a carve-out that a
	 * failed patch had not actually applied.
	 *
	 * CARVED BY THE COLUMN'S BOX, not per item, deliberately: the column is the
	 * region a visitor reads as "the controls", and per-item boxes leave
	 * precisely the gaps that were failing.
	 *
	 * Unknown geometry NEVER closes. The fail-safe direction is the viewer
	 * staying open, which is the behaviour without this feature at all.
	 *
	 * @param {number} x Client x.
	 * @param {number} y Client y.
	 *
	 * @return {boolean}
	 */
	/**
	 * Is this point in the rail column's dead space -- its inter-glyph gaps,
	 * its bottom padding, or the chevron gap?
	 *
	 * WHY THIS EXISTS. Asmita reported "the like icon acts as a play/pause
	 * button". The readout itself is innocent: measured at both viewports, a
	 * click on its centre AND on its count text hit-tests to the readout and
	 * leaves `paused` untouched. What actually happens is a near-miss -- the
	 * gaps are 20px on touch, so a fingertip 4px off the heart lands on the
	 * gesture layer, and the gesture layer's click handler is the pause toggle.
	 * The pause glyph then blooms in the middle of the frame, so the visitor
	 * attributes it to the icon they aimed at.
	 *
	 * `clickIsOnBackdrop()` below has carved this exact region out since the
	 * rail was built -- "gaps and padding included" -- so a near-miss could not
	 * CLOSE the viewer. That reasoning was never extended to the pause toggle,
	 * which is the same near-miss with a different consequence. It is one
	 * region and one intent: a tap in the space BETWEEN controls is a miss, and
	 * a miss should do nothing.
	 *
	 * Swipes are unaffected -- a drag sets `suppressTap`, which `onGestureClick`
	 * checks first, so the gaps still start a swipe (which is why the column is
	 * pointer-transparent in the first place).
	 *
	 * @param {number} x Client x.
	 * @param {number} y Client y.
	 *
	 * @return {boolean}
	 */
	function pointIsInControlDeadSpace(x, y) {
		/*
		 * THE SESSION column, not a slot's. The rail moved out of the track on
		 * 2026-09-10 and the carve-out has to follow it, or the region a
		 * visitor reads as "the controls" and the region this function
		 * protects stop being the same region.
		 *
		 * The BOX is unchanged by that move, which is why no offset is
		 * recomputed here: on desktop both columns are the same 44px
		 * full-height flex item, and on touch both shrink-wrap their own rail
		 * at `right: 10px; bottom: 0`. Measured identical on the live demo at
		 * both viewports before and after.
		 *
		 * `slot.railCol` is now an empty spacer and would still return a
		 * plausible 44px rect on desktop -- so reading it would have LOOKED
		 * right there and silently protected nothing on touch, where the empty
		 * column shrink-wraps to zero. A zero-size rect is skipped by the
		 * guard below rather than matched, which is the fail-safe direction
		 * but also exactly how that bug would have hidden.
		 */
		if (session.dom && session.dom.railCol) {
			var col = session.dom.railCol.getBoundingClientRect();

			if (col.width && col.height && pointInRect(x, y, col)) {
				return true;
			}
		}

		/*
		 * AND THE RAIL'S OWN LIVE BOX (SMASH-2064). Two boxes now, not one,
		 * because the drag-follow transform goes on the RAIL while the column
		 * above is the node this carve-out was written against -- and a
		 * transform on a child does not move its parent's border box. So during
		 * a drag, and during settleBack()'s 320ms animated return, the glyphs
		 * are somewhere the column's rect no longer covers.
		 *
		 * `getBoundingClientRect()` is read LIVE on every call rather than
		 * cached at gesture start, and that is the load-bearing detail: it
		 * already reflects the transform, including mid-transition, so the
		 * carve-out cannot drift from where the glyphs actually are the way a
		 * stored number would. The re-grabbable settle makes that reachable --
		 * settleBack() deliberately does not arm `transitioning`, so a visitor
		 * can tap a rail still animating home.
		 *
		 * The UNION of the two boxes, not a swap. On desktop the column is a
		 * 44px full-height flex item and a rail dragged UPWARD is still inside
		 * it; on touch the column shrink-wraps the rail, so either direction
		 * leaves it. Keeping both means the region the visitor last saw
		 * controls in stays inert as well, which is the fail-safe direction
		 * this function already commits to -- a tap here does nothing, and
		 * doing nothing is never the harmful outcome.
		 */
		if (session.dom && session.dom.rail) {
			var railBox = session.dom.rail.getBoundingClientRect();

			if (railBox.width && railBox.height && pointInRect(x, y, railBox)) {
				return true;
			}
		}

		if (session.dom && session.dom.nav) {
			var nav = session.dom.nav.getBoundingClientRect();

			if (nav.width && nav.height && pointInRect(x, y, nav)) {
				return true;
			}
		}

		return false;
	}

	function clickIsOnBackdrop(x, y) {
		var slot = activeSlot();

		if (! slot || ! slot.stage) {
			return false;
		}

		var frame = slot.stage.getBoundingClientRect();

		if (! frame || ! frame.width || ! frame.height) {
			return false;
		}

		// Inside the frame is never backdrop.
		if (pointInRect(x, y, frame)) {
			return false;
		}

		// Carve-out 1: the session chevrons.
		if (session.dom.nav && pointInRect(x, y, session.dom.nav.getBoundingClientRect())) {
			return false;
		}

		// Carve-out 2: the SESSION rail COLUMN, gaps and padding included. Was
		// the per-post column until the rail became session-level
		// (2026-09-10); same box, different owner. Carved by the COLUMN rather
		// than per item because the 18px desktop / 20px touch gaps between
		// bare glyphs are precisely where a near-miss lands, and closing the
		// viewer there loses the visitor's place in the feed.
		if (session.dom.railCol
			&& pointInRect(x, y, session.dom.railCol.getBoundingClientRect())) {
			return false;
		}

		// Carve-out 3: the RAIL's own live box (SMASH-2064). The same second
		// region pointIsInControlDeadSpace() explains at length -- the
		// drag-follow transform is on the rail, so the column's rect stops
		// describing where the glyphs are for the duration of a drag and its
		// animated return. Read live, never cached, for the same reason.
		//
		// Unguarded on width/height here, exactly like the column line above
		// it: this function's stated doctrine is that unknown geometry NEVER
		// closes, so a degenerate box carving a pixel out of the backdrop is
		// the harmless direction and losing the visitor's place in the feed is
		// not. The sibling function guards because its own outcome (do nothing
		// vs toggle playback) is symmetric.
		if (session.dom.rail
			&& pointInRect(x, y, session.dom.rail.getBoundingClientRect())) {
			return false;
		}

		return true;
	}

	/**
	 * @param {Event} event The click on the gesture layer.
	 *
	 * @return {void}
	 */
	function onGestureClick(event) {
		/*
		 * SUPPRESSION IS CHECKED FIRST, before the backdrop branch, and the
		 * order is load-bearing. `suppressTap` is set when a drag has just
		 * ended, and the click that follows a drag release can land anywhere --
		 * including outside the frame, if the finger travelled. Testing the
		 * backdrop first would close the viewer at the end of an ordinary
		 * swipe.
		 */
		if (session.suppressTap) {
			session.suppressTap = false;

			return;
		}

		if (event && clickIsOnBackdrop(event.clientX, event.clientY)) {
			emitAnalytics('swipeview_close', { index: session.index, reason: 'backdrop' });
			closeViewer();

			return;
		}

		/*
		 * A near-miss on a rail glyph or a chevron is a MISS, not a request to
		 * pause -- see pointIsInControlDeadSpace(). Checked after the backdrop
		 * branch because on DESKTOP the rail column sits outside the frame, so
		 * the two regions can overlap and "do not close" has to win there too;
		 * and after `suppressTap`, so a swipe that ends in the column is still
		 * a swipe.
		 */
		if (event && pointIsInControlDeadSpace(event.clientX, event.clientY)) {
			return;
		}

		togglePlay();
	}

	/* ═══════════════════ DOM construction ═══════════════════ */

	/**
	 * Build the overlay.
	 *
	 * @return {Object} The dom handle map stored on the session.
	 */
	function buildOverlay() {
		/*
		 * S7.1 dialog semantics, hand-rolled. The plugin's own lightbox is the
		 * in-house precedent for doing this without a library: save the opener,
		 * move focus in, trap Tab, restore.
		 *
		 * `aria-keyshortcuts` advertises the actions AT users cannot otherwise
		 * find, and the SCOPE RULE is deliberately narrower than the full key
		 * binding set below -- a list AT reads out on every open has a cost of
		 * its own, so a shortcut is announced only where the action has NO
		 * reliably AT-reachable control:
		 *
		 *   Space   togglePlay() has no focusable control AT ALL, by design
		 *           (neither platform's Reels UI has a persistent play button).
		 *           This is the gap being closed.
		 *   Arrows  the chevrons are the only AT-reachable navigation, and they
		 *           are display:none outside `(hover: hover) and
		 *           (pointer: fine)`, so focusables()' offsetParent filter
		 *           drops them wholesale on touch viewports.
		 *
		 * Excluded, because each is already reachable or is not a command:
		 *   PageUp/Down  exact aliases of the arrows; doubles what AT reads for
		 *                no added capability.
		 *   m            updateMuteChrome() disables the mute button exactly
		 *                when !caps.mute, so a labelled, enabled control is
		 *                present whenever the action is meaningful at all.
		 *   Escape       the close button is unconditionally focusable, and
		 *                Escape-dismisses is a dialog convention AT already
		 *                conveys.
		 *   Tab          the focus trap, not a command.
		 *
		 * "Space" is the ARIA spelling of the `case ' '` below -- the attribute
		 * is itself a space-delimited list, so the literal key value cannot be
		 * used (WAI-ARIA 1.2). Every other token is its `event.key` verbatim.
		 */
		var root = el('div', 'cff-swipeview-root', {
			id: MOUNT_ID,
			role: 'dialog',
			'aria-modal': 'true',
			'aria-label': 'Reels viewer',
			'aria-keyshortcuts': 'Space ArrowUp ArrowDown',
			tabindex: '-1',
			'data-muted': 'true',
			'data-caption': 'collapsed'
		});

		var viewport = el('div', 'cff-swipeview-viewport');
		var track    = el('div', 'cff-swipeview-track');
		viewport.appendChild(track);

		/*
		 * S7.1's "input layer" -- a distinct element so it can be hidden from
		 * AT, rather than binding wheel/touch/click to the dialog root (which
		 * must stay in the accessibility tree).
		 *
		 * A SIBLING of the viewport, not a descendant of the track, and that is
		 * the S6.3 fix rather than a layout preference. The track carries a
		 * live `transform`, which establishes a stacking context and TRAPS
		 * every descendant z-index inside it -- so a z-index on slide content
		 * is never compared against this element at all. The comparison that
		 * decides who wins a click is viewport-vs-gesture, because those two
		 * really are siblings.
		 *
		 * NO tabindex, deliberately. A div is not focusable to begin with, so
		 * `tabindex="-1"` would not remove sequential focusability (there is
		 * none) -- it would ADD click focusability, and Chrome then refuses the
		 * aria-hidden outright while the element holds focus, un-hiding from AT
		 * the one layer AT must never see. Instagram hit exactly that and
		 * removed the attribute; this is the landmine the brief names by hand.
		 *
		 * `inert` is also the wrong tool HERE -- it removes pointer interaction
		 * along with AT exposure, and pointer interaction is the element's
		 * entire purpose. It would silence the warning by deleting the feature.
		 */
		var gestures = el('div', 'cff-swipeview-gesture', { 'aria-hidden': 'true' });

		/*
		 * Rule 1.1's stage row -- the SESSION-LEVEL half, and the second
		 * consumer of the frame geometry.
		 *
		 * Why a second copy of the frame exists at all: the chrome inside the
		 * frame splits by scope. The rail counts and the bottom row are
		 * PER-POST (they change per slide, and the ratified thumb-follow rule
		 * has them travelling with the drag), so they live inside the track.
		 * The mute button, the progress bar and the pause glyph are
		 * SESSION-scoped -- one mute button means one accessible name, one
		 * focus stop in the trap, and one disabled state driven by the ACTIVE
		 * tier's capability, where N per-slide buttons would mean N of each to
		 * keep in sync. Those cannot live inside the track, so they get a box
		 * that reproduces the frame's geometry at overlay level.
		 *
		 * The consequence to know, because it is visible: this chrome does NOT
		 * travel with a drag, while the rail and the bottom row DO. That is the
		 * ratified rule -- the RAIL is the element named as mirroring the drag
		 * transform (SMASH-2064, "match TikTok on Facebook", 2026-09-10).
		 *
		 * The bottom row travels by INHERITANCE, being inside the track. The
		 * rail no longer can, having moved out of it, so its travel is written
		 * explicitly by setRailTravel() -- same value, one paint, no second
		 * derivation. Aman's static reference build has no JS drag at all, so
		 * it cannot show the difference either way.
		 *
		 * The rail column here is the CHEVRONS' host -- session-level, since
		 * navigation is not per-post. It is present and 44px wide on desktop
		 * even before the chevrons move into it (step d), because its width is
		 * what makes this row's frame land on exactly the same box as each
		 * slot's. A missing column here would offset the session chrome from
		 * the video it sits on by 30px, which is the kind of drift the suite's
		 * "both rows resolve identically" assertion exists to catch.
		 */
		/*
		 * NO `aria-hidden` on this layer, deliberately. From step (c) it holds
		 * the mute button and the CTA pill -- both focusable -- and
		 * `aria-hidden` on an ancestor of a focusable element is the exact
		 * violation the gesture-layer note above records: Chrome refuses the
		 * attribute outright while a descendant holds focus, and AT would
		 * otherwise lose two of the viewer's four session controls. The layer
		 * is a plain positioned container; it needs no role and no name.
		 */
		var chromeLayer   = el('div', 'cff-swipeview-chromelayer');
		var chromeRow     = el('div', 'cff-swipeview-stagerow');
		var frameChrome   = el('div', 'cff-swipeview-framechrome');
		var chromeRailCol = el('div', 'cff-swipeview-railcol');

		chromeRow.appendChild(frameChrome);
		chromeRow.appendChild(chromeRailCol);
		chromeLayer.appendChild(chromeRow);

		/*
		 * AC 5: the VISIBLE counter is gone; §7.1's position announcement
		 * survives AT-only.
		 *
		 * It kept a painted "3 / 8" at the window's top-left in 13px
		 * semibold, and Facebook was the only one of the four viewers still
		 * showing one -- pill-less, in the exact corner the close disc now
		 * occupies. The design has no counter anywhere and the frame's
		 * top-left is deliberately blank.
		 *
		 * What is NOT dropped is the announcement. The element keeps
		 * `role="status"` and `aria-live="polite"` and gains the `-sr` class,
		 * so a screen-reader user still hears the position on every slide
		 * change while nothing is painted. Deleting the node with the paint
		 * would have been a real regression for exactly the visitor who most
		 * needs it: a feed with no visible position indicator at all.
		 *
		 * This is a §6.4 escalation -- §6.1 guarantees a visible counter, so
		 * the viewer is knowingly non-conformant on that clause until spec
		 * amendment A1 lands. Recorded, not reinterpreted.
		 */
		var counter = el('div', 'cff-swipeview-sr cff-swipeview-counter', {
			role: 'status', 'aria-live': 'polite', 'aria-atomic': 'true'
		});

		var playState = el('div', 'cff-swipeview-sr cff-swipeview-playstate', {
			role: 'status', 'aria-live': 'polite', 'aria-atomic': 'true'
		});

		/*
		 * Desktop chevrons. Built unconditionally and DISABLED at the ends of
		 * the track rather than added and removed -- a control that vanishes
		 * moves its sibling, and a disabled button keeps the geometry stable
		 * while staying honest about what it can do (S6.2).
		 *
		 * RATIFIED (2026-08-24 item E, Aman's explicit call on Instagram):
		 * visibility is gated on INPUT CAPABILITY -- `(hover: hover) and
		 * (pointer: fine)` -- and NEVER on viewport width. A narrow desktop
		 * window still has a mouse and a keyboard; a large tablet still has
		 * neither. The same gate governs the keyboard-hint copy, which is why
		 * that feedback item is about a media query rather than about a string.
		 */
		/*
		 * TOOLTIPS (rule 1.9 / AC 12). The tip copy names the arrow AND the
		 * `j`/`k` alias, so the superset onKeydown actually binds is
		 * discoverable to the visitors who can use it, without putting a
		 * second token in `aria-keyshortcuts` for AT to read out twice.
		 *
		 * The tip is NOT the accessible name -- `aria-label` still carries it,
		 * because a tooltip is a desktop-only hover affordance gated behind
		 * `(hover: hover) and (pointer: fine)` and AT must not depend on it.
		 *
		 * The DOUBLE SPACE is the design's separator between an action and its
		 * shortcut, the same shape the close disc uses ("Close  Esc"). It
		 * survives because the CSS renders it via `content: attr(...)` in a
		 * `white-space: nowrap` box.
		 */
		var nav = el('div', 'cff-swipeview-nav');
		var navPrev = el('button', 'cff-swipeview-nav-prev', {
			type: 'button', 'data-nav': 'prev', 'aria-label': 'Previous Reel',
			'data-cff-swipe-tip': 'Previous  ↑ / K'
		});
		navPrev.appendChild(buildControlIcon('chevronUp'));
		var navNext = el('button', 'cff-swipeview-nav-next', {
			type: 'button', 'data-nav': 'next', 'aria-label': 'Next Reel',
			'data-cff-swipe-tip': 'Next  ↓ / J'
		});
		navNext.appendChild(buildControlIcon('chevronDown'));
		nav.appendChild(navPrev);
		nav.appendChild(navNext);

		/*
		 * MOUNTED INTO THE SESSION RAIL COLUMN, not onto the root.
		 *
		 * Rule 1.11 makes the chevrons the rail column's middle row, and the
		 * CSS positions them `top: 50%; right: 0; left: 0` -- which resolves
		 * against their CONTAINING BLOCK. Left as a root child, that block is
		 * the window: the pair centred on the WINDOW's midpoint and spanned its
		 * full width, so on a letterboxed desktop they sat in the middle of the
		 * backdrop rather than in the 44px column beside the frame.
		 *
		 * The CSS alone looked right and the elements were in the wrong parent.
		 * The behavioural tier caught it by measuring the nav's centre against
		 * the frame's -- a static read of the same rules would have agreed with
		 * itself and passed.
		 */
		chromeRailCol.appendChild(nav);

		/*
		 * ── THE RAIL IS SESSION-LEVEL, AND IT DOES NOT MOVE ──────────────────
		 *
		 * Asmita's fleet rule, 2026-09-10: "keep the like/comment/share stats
		 * rail in place and update it without it going up and down with the
		 * video (we do this with TikTok); otherwise it looks too jarring having
		 * these icons moving so much."
		 *
		 * WHAT IT REPLACES, measured on the live demo at 4.12.0.9 before the
		 * change. The rail was built PER SLOT and mounted in the slot's own rail
		 * column -- inside the track -- so the track's navigation transform
		 * carried it a full viewport height and back on every slide change:
		 *
		 *   desktop 1440x900   at rest y=709   mid-transition y=1133.9  (+424.9)
		 *   touch    390x844   at rest y=586   mid-transition y=984.47  (+398.5)
		 *
		 * Both mid-transition positions are BELOW the viewport's bottom edge, so
		 * the three glyphs swept out of frame and back in over 320ms while the
		 * top row (y=0) and the chevrons (y=400) held still. That is the
		 * jarring the rule names, and it is the Instagram behaviour her recording
		 * shows -- this viewer was ported from that chrome and inherited it.
		 *
		 * SO THE RAIL MOVES OUT OF THE TRACK AND INTO THE SESSION COLUMN, which
		 * is the one host where it lands on the same box it already occupied.
		 * `chromeRow` is a `.cff-swipeview-stagerow` exactly like each slot's,
		 * and this column is a `.cff-swipeview-railcol` exactly like each slot's
		 * -- the geometry suite's "both rows resolve identically" assertion is
		 * what makes that a measured property rather than a hope. No CSS moves,
		 * no offset is recomputed, and the at-rest rect is unchanged to the
		 * hundredth of a pixel on both viewports.
		 *
		 * THE CHEVRONS ARE ITS SIBLING, not its parent, and the order is
		 * deliberate: `nav` is `position: absolute; top: 50%` on desktop and
		 * `display: none` on touch, so it is out of flow in both. The rail is
		 * therefore the column's ONLY in-flow child and the column's own
		 * `justify-content: flex-end` still bottom-aligns it -- which is AC 8's
		 * "grows upward from the frame's bottom edge", preserved by construction.
		 *
		 * THE DRAG-FOLLOW IS PORTED FROM TIKTOK AFTER ALL (SMASH-2064). An
		 * earlier round of this work argued the opposite here, and the argument
		 * is worth keeping rather than deleting, because the reasoning was
		 * sound and the CONCLUSION was still wrong. It ran: FB's rail travelled
		 * only because it sat in the track; the 2026-09-10 rule speaks to this
		 * element directly ("in place", "without it going up and down"); a
		 * pinned rail is already this viewer's grammar, since the top row, the
		 * mute chip, the CTA and the chevrons have never travelled. So the rail
		 * was made session-level AND pinned outright, and the divergence from
		 * TikTok was flagged rather than hidden.
		 *
		 * Asmita settled it on 2026-09-10: "match TikTok on Facebook." The rule
		 * governs the NAVIGATION -- only commit travel was ever meant to go --
		 * and a drag is direct manipulation, where the rail must stay with the
		 * reel it is describing. Instagram reached the same split under
		 * SMASH-1978 on 2026-08-27 and this does not reverse it.
		 *
		 * So the delta IS mirrored onto this element, which is the local
		 * equivalent of TikTok's `.sbtt-swipeview-rail-reel` wrapper -- the
		 * INNER rail, chosen over the column for TikTok's own stated reason:
		 * the chevrons are the column's other child and must not travel. The
		 * mechanism, the element choice and the carve-out consequence are all
		 * in setRailTravel().
		 *
		 * ONE ELEMENT, so its CONTENT is what changes per slide -- see
		 * updateRail(), called from syncWindow() in the same task as
		 * moveTrack(). TikTok's note on the same seam is the timing this
		 * matches: "on a commit it lands at rest in the same paint that swaps its
		 * content, while the track animates the remaining distance."
		 */
		var rail = el('div', 'cff-swipeview-rail');

		chromeRailCol.appendChild(rail);

		/*
		 * ── The frame's top row (rule 1.5 / AC 6) ────────────────────────────
		 *
		 * `[blank left] … [mute][View on Facebook]`, right-aligned, INSIDE the
		 * frame. Both controls were window-anchored before -- mute in the
		 * bottom-right gutter, the CTA not existing at all -- and AC 2 replaces
		 * that model wholesale: on a letterboxed desktop, window-anchored
		 * chrome sits on the backdrop pillars rather than on the video.
		 */
		var top = el('div', 'cff-swipeview-top');

		/*
		 * Mute: ONE expanding chip replacing TWO old controls (AC 7) -- the
		 * discless gutter glyph and the separate bottom-centre unmute pill. One
		 * accessible name, one focus stop, one disabled state.
		 *
		 * The label is a CHILD of the button, not a sibling, which is what
		 * makes 34 -> 136 a single expanding box. It carries no aria of its
		 * own: the button's `aria-label` is the accessible name and the label's
		 * text would otherwise be announced as a second, competing one.
		 */
		var mute = el('button', 'cff-swipeview-mute', {
			type: 'button', 'data-act': 'mute', 'aria-label': 'Unmute', 'data-state': 'off'
		});
		mute.appendChild(buildControlIcon('volumeOff', 20));
		var muteLabel = el('span', 'cff-swipeview-mute-label', { 'aria-hidden': 'true' });
		muteLabel.textContent = 'Tap to unmute';
		mute.appendChild(muteLabel);

		/*
		 * The CTA pill. Desktop-only by CSS; on touch it becomes a rail item
		 * (step d), and that migration is VIEWPORT-driven so §6.1's "a control
		 * MUST NOT relocate as the chain escalates" is untouched.
		 *
		 * It is a session-level element carrying PER-SLIDE data, so
		 * updateChrome() refreshes both its href and its `hidden` on every
		 * slide change -- and `hidden` genuinely varies: a Reel's permalink is
		 * DERIVED rather than requested from Graph, and the seam reports
		 * absence rather than handing back the embed-wrapper URL it could not
		 * distinguish from a real one. An empty href is not rendered.
		 */
		var cta = el('a', 'cff-swipeview-cta', {
			target: '_blank', rel: 'noopener noreferrer', hidden: 'hidden'
		});
		cta.appendChild(buildControlIcon('facebook', 16));
		var ctaLabel = el('span', 'cff-swipeview-cta-label');
		ctaLabel.textContent = 'View on Facebook';
		cta.appendChild(ctaLabel);

		top.appendChild(mute);
		top.appendChild(cta);

		var progress = el('div', 'cff-swipeview-progress', {
			role: 'progressbar',
			'aria-label': 'Playback progress',
			'aria-valuemin': '0',
			'aria-valuemax': '100',
			'aria-valuenow': '0'
		});
		var progressFill = el('i', 'cff-swipeview-progress-fill');
		progress.appendChild(progressFill);

		/*
		 * The pause glyph (rule 1.10 / AC 11) -- a persistent readout of the
		 * paused state, replacing the 600ms tap-flash.
		 *
		 * The difference is not cosmetic. A flash answers "you tapped"; this
		 * answers "the video is paused", which is the question §6.1 puts on the
		 * visual channel. It is shown by a `data-paused` attribute on the root
		 * rather than by a timer, so the paint cannot outlive or lag the state
		 * it describes -- the class of bug the flash's 600ms timer had by
		 * construction.
		 *
		 * Shrink-wrapped and centre-anchored, NOT full-bleed. The tap-flash
		 * already had that shape and it is kept for the same reason: a
		 * pointer-events regression on this layer exposes an 84px disc rather
		 * than the whole frame, and a full-frame element above the gesture layer
		 * is this file's founding §6.3 defect.
		 */
		var pauseGlyph = el('div', 'cff-swipeview-pauseglyph', { 'aria-hidden': 'true' });
		pauseGlyph.appendChild(buildControlIcon('pauseGlyph', 84));

		/*
		 * The share chain's toast. SESSION-level, not per-slide: there is one
		 * outcome to report at a time, and a per-slide toast would be rebuilt
		 * out from under an in-flight clipboard promise on a slide change.
		 *
		 * A POLITE LIVE REGION rather than a painted box alone. The whole
		 * point of the fallback chain is that the visitor learns which rung
		 * ran, and a silent successful copy is indistinguishable from a dead
		 * button. `aria-atomic` so the whole message is re-read rather than
		 * just the changed words -- the last rung's message is a URL.
		 */
		var toast = el('div', 'cff-swipeview-toast', {
			role: 'status', 'aria-live': 'polite', 'aria-atomic': 'true'
		});

		/*
		 * Rule 1.4 / AC 2: window-anchored, top-LEFT, a 40px disc with a 22px
		 * glyph. The ONLY window-anchored control left in the viewer.
		 *
		 * The tooltip's copy is "Close  Esc" with a DOUBLE SPACE, which is the
		 * design's own separator between an action and its shortcut (the
		 * chevrons use the same shape: "Previous  ↑ / K"). It is rendered by
		 * `content: attr(...)` in a `white-space: nowrap` box, so both spaces
		 * survive -- an `&nbsp;` would be the wrong tool and would show up in
		 * the accessible name.
		 *
		 * The tooltip is NOT the accessible name. `aria-label` carries the
		 * full "Close Reels viewer", because a tooltip is a desktop-only
		 * hover affordance gated behind a capability query and AT must not
		 * depend on it.
		 */
		var close = el('button', 'cff-swipeview-close', {
			type: 'button',
			'aria-label': 'Close Reels viewer',
			'data-cff-swipe-tip': 'Close  Esc'
		});
		close.appendChild(buildControlIcon('close', 22));

		// DOM order IS the Tab order (focusables() collects in document order),
		// so this sequence decides the cycle: chevrons -> mute -> pill -> close,
		// then the active slide's own controls.
		/*
		 * The session frame chrome's own contents, mounted INSIDE the frame's
		 * session-level twin so they inherit its geometry and are clipped by
		 * its radius -- which is what lets the full-frame-width progress bar
		 * sit flush on a rounded bottom edge without its square ends poking
		 * past the corner curve.
		 */
		/*
		 * The coach, mounted in the frame chrome so it covers the FRAME rather
		 * than the window -- a full-window overlay would dim the backdrop and
		 * the rail along with the video it is pointing at.
		 */
		var coach = el('div', 'cff-swipeview-coach', { 'aria-hidden': 'true' });
		var coachHand = buildControlIcon('coachHand', 44);
		var coachText = el('p', 'cff-swipeview-coach-text');

		coachText.textContent = 'Swipe up for next';
		coach.appendChild(coachHand);
		coach.appendChild(coachText);
		coachHand.setAttribute('class', 'cff-swipeview-coach-hand');

		frameChrome.appendChild(top);
		frameChrome.appendChild(progress);
		frameChrome.appendChild(pauseGlyph);
		frameChrome.appendChild(toast);
		frameChrome.appendChild(coach);

		/*
		 * DOM order IS the Tab order (focusables() collects in document order),
		 * so this sequence decides the cycle. The chrome layer comes before
		 * `nav` and `close`, which puts the frame's own controls -- mute, then
		 * the CTA -- ahead of the chevrons and the close disc, and the active
		 * slide's per-slide controls after those.
		 *
		 * `close` is appended LAST deliberately. It shares level 3 with the
		 * chrome layer, so document order is what puts it on top -- which
		 * matters on touch, where the full-bleed frame's top row runs
		 * underneath the window-anchored close disc.
		 */
		root.appendChild(viewport);
		root.appendChild(gestures);
		root.appendChild(chromeLayer);
		root.appendChild(counter);
		root.appendChild(playState);
		root.appendChild(close);

		close.addEventListener('click', function (event) {
			event.preventDefault();
			closeViewer();
		});
		mute.addEventListener('click', function (event) {
			event.preventDefault();
			toggleMute();
		});
		// ONE handler for both chevrons, reading the direction off `data-nav`
		// and routed through navigate() -- the same function the arrow keys
		// call -- so the cooldown, the end clamp and the analytics are
		// identical by construction rather than by two code paths kept in step.
		navPrev.addEventListener('click', onNavClick);
		navNext.addEventListener('click', onNavClick);

		// wheel and touchmove are NON-PASSIVE: a passive listener's
		// preventDefault() is ignored (with a console warning) and the page
		// would scroll underneath the viewer.
		gestures.addEventListener('wheel', onWheel, { passive: false });
		gestures.addEventListener('touchstart', onTouchStart, { passive: true });
		gestures.addEventListener('touchmove', onTouchMove, { passive: false });
		gestures.addEventListener('touchend', onTouchEnd, { passive: true });
		gestures.addEventListener('touchcancel', onTouchCancel, { passive: true });
		gestures.addEventListener('click', onGestureClick);

		return {
			root: root,
			viewport: viewport,
			track: track,
			gestures: gestures,
			chromeLayer: chromeLayer,
			chromeRow: chromeRow,
			frameChrome: frameChrome,
			chromeRailCol: chromeRailCol,
			/*
			 * The session rail, and the column it lives in. BOTH are handles
			 * because they answer different questions: `rail` is the element
			 * whose CONTENT updateRail() swaps, and `railCol` is the BOX the
			 * dead-space and backdrop carve-outs hit-test against -- gaps and
			 * bottom padding included, which is the whole point of carving by
			 * the column rather than per item.
			 */
			rail: rail,
			railCol: chromeRailCol,
			counter: counter,
			playState: playState,
			nav: nav,
			navPrev: navPrev,
			navNext: navNext,
			mute: mute,
			top: top,
			cta: cta,
			ctaLabel: ctaLabel,
			muteLabel: muteLabel,
			pauseGlyph: pauseGlyph,
			toast: toast,
			coach: coach,
			progress: progress,
			progressFill: progressFill,
			close: close
		};
	}

	/* ═══════════════════ Keyboard and focus (spec S7.1) ═══════════════════ */

	/**
	 * Whether Space belongs to what is focused rather than to play/pause.
	 *
	 * S3.3 gives the viewer every key, and Space is its play/pause. That is
	 * consistent and invisible while every control is reached by Enter. It
	 * stops being invisible the moment a focusable BUTTON is in the cycle: a
	 * native button fires its click on Space's keyUP, and a preventDefault on
	 * keydown suppresses it -- so the caption expander would be Enter-only
	 * while Space paused the video instead. That is a real gap rather than a
	 * stylistic one: overriding a native button's own activation key is the
	 * author taking back something the platform provides.
	 *
	 * ONE EXCEPTION, and it is why this is a function rather than a condition:
	 * THE CLOSE BUTTON KEEPS PLAY/PAUSE. Focus starts on it when the viewer
	 * opens, so yielding Space there would mean the first Space press of every
	 * session DISMISSES THE VIEWER -- for a visitor whose intent, on a playing
	 * video, is almost certainly to pause. Losing your place in the feed is not
	 * a recoverable mis-key. Close is still Enter-activated, and Escape closes
	 * from anywhere, so nothing becomes unreachable.
	 *
	 * Links are deliberately not covered: Space does not activate an <a>
	 * anywhere on the web, so the CTA yields Space to play/pause like any
	 * non-control focus.
	 *
	 * @param {EventTarget} target The focused node.
	 *
	 * @return {boolean}
	 */
	function spaceBelongsToTarget(target) {
		if (! target || ! target.tagName) {
			return false;
		}

		var isButton = target.tagName === 'BUTTON'
			|| (target.getAttribute && target.getAttribute('role') === 'button');

		if (! isButton) {
			return false;
		}

		return ! (target.classList && target.classList.contains('cff-swipeview-close'));
	}

	/**
	 * The viewer's own key handling, live only while open.
	 *
	 * Registered in the CAPTURE phase and calling stopPropagation, so a key
	 * pressed while the viewer is open cannot reach anything underneath it.
	 * There is nothing to reach in practice -- the lightbox unbinds its
	 * document handlers when it closes and never bound them if it never opened
	 * -- but a viewer that relied on that would be relying on another
	 * component's internals. Owning the event is cheaper than trusting them.
	 *
	 * Bound on DOCUMENT rather than on the overlay so S3.3's "the viewer owns
	 * every key" holds no matter where focus sits: focus lands outside easily
	 * enough (a click on the page behind before the overlay took focus, an
	 * extension stealing it, a host script calling blur()).
	 *
	 * @param {KeyboardEvent} event The key event.
	 *
	 * @return {void}
	 */
	function onKeyDown(event) {
		if (! session) {
			return;
		}

		var key = event.key;

		// Before every other branch: the caption expander is a button too, and
		// the expanded branch below preventDefaults Space as well.
		if (key === ' ' && spaceBelongsToTarget(event.target)) {
			return;
		}

		/*
		 * ESCAPE IS LAYERED. It collapses the expanded caption FIRST and does
		 * not close the viewer. Two nested dismissible things share one key and
		 * the inner one wins -- the platform convention, and the alternative
		 * (one Escape closing both) would throw away the visitor's place in the
		 * feed for pressing Escape once.
		 */
		if (session.captionExpanded && (key === 'Escape' || key === 'Esc')) {
			event.preventDefault();
			event.stopPropagation();
			setCaptionExpanded(false);
			return;
		}

		/*
		 * While the caption is expanded the arrows and PageUp/PageDown are left
		 * ALONE -- no preventDefault -- so the browser scrolls the focused
		 * caption surface with them. navigate() is suppressed anyway, so
		 * swallowing them here would give a keyboard visitor a caption they can
		 * see and cannot scroll.
		 */
		if (session.captionExpanded
			&& (key === 'ArrowDown' || key === 'ArrowUp' || key === 'PageDown' || key === 'PageUp' || key === ' ')
		) {
			if (key === ' ') {
				event.preventDefault();
				event.stopPropagation();
				togglePlay();
			}

			return;
		}

		switch (key) {
			case 'Escape':
			case 'Esc':
				event.preventDefault();
				event.stopPropagation();
				closeViewer();
				break;
			/*
			 * `j` / `k` are rule 1.17's superset, and they are aliases rather
			 * than a second binding: both route through the same navigate()
			 * call the arrows use, so the cooldown, the end clamp, the caption
			 * suppression and the analytics are identical by construction.
			 *
			 * Deliberately NOT added to `aria-keyshortcuts`. That attribute is
			 * read out on every open, and its scope rule here is "announce a
			 * shortcut only where the action has no reliably AT-reachable
			 * control". The arrows are already announced for exactly that
			 * reason; announcing two more spellings of the same action doubles
			 * what AT reads for no added capability.
			 */
			case 'j':
			case 'J':
			case 'ArrowDown':
			case 'PageDown':
				event.preventDefault();
				event.stopPropagation();
				navigate(1);
				break;
			case 'k':
			case 'K':
			case 'ArrowUp':
			case 'PageUp':
				event.preventDefault();
				event.stopPropagation();
				navigate(-1);
				break;
			// The arrow keys are UP/DOWN because the track is vertical. Left and
			// right are accepted as aliases rather than ignored: slice 1 bound
			// them, the coexistence suite drives them, and a visitor who
			// reaches for them on a horizontal-looking carousel should not find
			// the viewer inert.
			case 'ArrowRight':
				event.preventDefault();
				event.stopPropagation();
				navigate(1);
				break;
			case 'ArrowLeft':
				event.preventDefault();
				event.stopPropagation();
				navigate(-1);
				break;
			case ' ':
				event.preventDefault();
				event.stopPropagation();
				togglePlay();
				break;
			case 'm':
			case 'M':
				event.stopPropagation();
				toggleMute();
				break;
			case 'Tab':
				trapFocus(event);
				break;
			default:
				break;
		}
	}

	/**
	 * The chrome PLUS the active slide's own focusable content.
	 *
	 * The slide's content matters: on the terminal tier the platform link is
	 * that tier's ONLY action, so trapping to the chrome alone would make it
	 * keyboard-unreachable (S7.1). On tier 2 the play trigger is the same case.
	 *
	 * Each control is named INDIVIDUALLY rather than collected by a group
	 * selector. A group selector silently stops reaching a control that gets
	 * re-parented, which is how a sibling viewer's mute button became
	 * keyboard-unreachable for one commit -- invisible under a mouse.
	 *
	 * IFRAMES ARE DELIBERATELY ABSENT. A cross-origin frame's document is a
	 * separate tab order this trap can neither see into nor cycle out of, so
	 * the frame carries tabindex="-1" (set at construction) and is sealed OUT
	 * rather than fought with. The tier's real actions -- the play trigger
	 * before the tap, the counts CTA after -- stay in the trap.
	 *
	 * The offsetParent filter drops anything not actually rendered (the
	 * chevrons on a touch viewport, the pill when it is not armed), so a
	 * control rejoins the cycle the moment it becomes visible without needing
	 * its own check.
	 *
	 * @return {Array<Element>}
	 */
	function focusables() {
		var root = session.dom.root;

		/*
		 * ── THE RAIL IS ENUMERATED HERE NOW, AND IT HAS TO BE ────────────────
		 *
		 * Until 2026-09-10 the rail lived inside the active slot, so its
		 * comment link, its share button and its touch-only "View" link were
		 * picked up FOR FREE by the active-slot sweep below. Moving the rail to
		 * the session chrome layer took it out of that sweep, and nothing else
		 * would have noticed: the trap would simply have stopped visiting three
		 * controls.
		 *
		 * That failure is invisible to every assertion this suite already had.
		 * The Tab-cycle tests size their walk from `_focusables()` itself, so a
		 * shorter list makes a shorter walk and the cycle still "closes"; and
		 * V18's ring audit only checks that whatever it REACHES has a ring, so
		 * three unreachable controls with perfectly good rings pass it. A
		 * keyboard visitor would have been unable to reach the comments link or
		 * share at all, and the suite would have stayed green — which is why
		 * there is now an explicit assertion that these three are IN this list,
		 * rather than trusting the shape of the DOM to keep them here.
		 *
		 * `:not([disabled])` on the button and `[href]` on the links mirror the
		 * active-slot sweep's own filters, so an item the rail omits for a
		 * slide with no permalink is absent rather than present-and-dead.
		 *
		 * DOCUMENT ORDER, NOT SELECTOR ORDER. querySelectorAll returns matches
		 * in document order however the selector list is written, so adding the
		 * rail here does not let this list reorder the tab cycle behind the
		 * CSS's back -- the cycle follows the DOM, which is what a keyboard
		 * visitor expects and what the rail's new position in the chrome layer
		 * already decides.
		 */
		var items = [].slice.call(root.querySelectorAll(
			'.cff-swipeview-nav-prev:not([disabled]), .cff-swipeview-nav-next:not([disabled]), '
			+ '.cff-swipeview-mute:not([disabled]), .cff-swipeview-cta:not([hidden]), .cff-swipeview-close, '
			+ '.cff-swipeview-rail a[href], .cff-swipeview-rail button:not([disabled])'
		));

		var active = root.querySelector('.cff-swipeview-slot-active');

		if (active) {
			items = items.concat([].slice.call(
				active.querySelectorAll('a[href], button:not([disabled])')
			));
		}

		return items.filter(function (node) {
			return node.offsetParent !== null || node === document.activeElement;
		});
	}

	/**
	 * @param {KeyboardEvent} event The Tab press.
	 *
	 * @return {void}
	 */
	function trapFocus(event) {
		var items = focusables();

		if (! items.length) {
			return;
		}

		var current = items.indexOf(document.activeElement);

		event.preventDefault();
		event.stopPropagation();

		var next = event.shiftKey
			? (current <= 0 ? items.length - 1 : current - 1)
			: (current === items.length - 1 || current === -1 ? 0 : current + 1);

		items[ next ].focus();
	}

	/* ═══════════════════ Open / close ═══════════════════ */

	/**
	 * Open the viewer.
	 *
	 * @param {Array<Element>} track  Reel hosts, in feed order.
	 * @param {number}         index  Start index.
	 * @param {Element|null}   opener The element that was clicked.
	 *
	 * @return {void}
	 */
	/**
	 * Bank WebKit's per-element media activation grant on all three pooled
	 * `<video>` elements, inside the opening gesture's own call stack.
	 *
	 * WHY. iOS grants "you may play with sound" PER ELEMENT, on user
	 * activation. The active slide gets its grant for free -- `attemptPlay()`
	 * calls `play()` synchronously inside the opening click, which is exactly
	 * what banks it. The NEIGHBOURS do not: the pool reuses three elements
	 * (`recycle()` swaps `src` and re-`load()`s), so when a swipe later makes a
	 * neighbour active, its element has never been played under an activation
	 * and iOS refuses the unmuted attempt. The first slide has sound and every
	 * subsequent one is silent -- which is the reported symptom, and it is
	 * about element identity rather than about the play call being async.
	 *
	 * So each neighbour gets a MUTED `play()` here, in the click's stack, and
	 * is paused again as soon as it starts. The grant survives; nothing is
	 * heard.
	 *
	 * THE ACTIVE SLOT IS DELIBERATELY SKIPPED. `attemptPlay()` owns it and may
	 * be mid-flight with an UNMUTED attempt; a muted `play()` from here would
	 * race it and could flip the very first slide to silent -- turning a
	 * neighbour fix into a regression on the one slide that already worked.
	 *
	 * S4.4 IS RESPECTED, and this is what the "neighbours are never played"
	 * pin is renegotiated to: never played AUDIBLY, and never left playing.
	 * `muted` is re-asserted rather than assumed, `preload` is not touched (the
	 * metadata ceiling stands), and the pause returns each element to a paused,
	 * silent, metadata-only state.
	 *
	 * @return {number} How many elements were primed (for the test seam).
	 */
	function primeMediaActivation() {
		var primed = 0;

		if (! session || ! session.slots) {
			return 0;
		}

		session.slots.forEach(function (slot) {
			// Only a real HTMLMediaElement transport can hold a grant. Tier 1
			// is a cross-origin iframe and tier 2 a still -- neither applies.
			if (! slot || slot.tier !== 0 || ! slot.inst || ! slot.inst.el) {
				return;
			}

			// The active element is attemptPlay()'s, not ours. See above.
			if (slot.index === session.index) {
				return;
			}

			var media = slot.inst.el;

			if (! media.src) {
				return;
			}

			try {
				// Re-asserted, not assumed: a neighbour must never be audible.
				media.muted = true;

				var settle = function () {
					try {
						media.pause();
						media.currentTime = 0;
					} catch (err) { /* a detached element is not a failure */ }
				};
				var attempt = media.play();

				if (attempt && typeof attempt.then === 'function') {
					attempt.then(settle, function () { /* refused: nothing banked, nothing broken */ });
				} else {
					settle();
				}

				primed++;
			} catch (err) {
				/*
				 * A refused prime is the pre-existing behaviour, not a new
				 * failure -- swallow it. Throwing here would abort open().
				 */
			}
		});

		return primed;
	}

	function open(track, index, opener) {
		if (session || ! track.length) {
			return;
		}

		var slides = track.map(function (host, position) {
			return readSlide(host, position);
		});

		var start = Math.max(0, Math.min(index || 0, slides.length - 1));

		session = {
			slides: slides,
			index: start,
			slots: [],
			dom: null,
			// S7.1: the opener is passed in EXPLICITLY rather than inferred --
			// a click on a non-focusable tile leaves document.activeElement on
			// <body>, so inferring it would restore focus nowhere.
			opener: opener || null,
			viewed: {},
			navLocked: false,
			wheelLock: false,
			wheelAccum: 0,
			wheelLastAt: 0,
			wheelNavAt: 0,
			wheelSpent: false,
			transitioning: false,
			captionExpanded: false,
			unmutePillArmed: false,
			lastPlayStateText: null,
			pollTimer: null,
			lastProgress: 0,
			hintTimer: null,
			hintRetract: null,
			glyphTimer: null,
			toastTimer: null,
			coachAuto: null,
			coachDismiss: null,
			onKeyDown: null,
			touchStartY: null,
			touchStartAt: 0,
			dragging: false,
			suppressTap: false,
			dragDeltaPx: 0,
			dragBaseIndex: start,
			dragViewportH: 0,
			pullRawPx: 0
		};

		session.viewed[ start ] = true;

		// Per-session sound state. S4.1: open() is itself a click -- a
		// qualifying gesture -- so attempt UNMUTED by default, and the only
		// writer of `true` from here on is an explicit mute action. A fresh
		// open is a fresh session because the browser's audio decision may
		// genuinely have changed.
		userMuted = false;
		unmuteSucceeded = false;
		lastAnalyticsAt = {};

		session.dom = buildOverlay();

		// Mounted on body, NEVER inside #cff-lightbox-wrapper.
		document.body.appendChild(session.dom.root);
		document.documentElement.classList.add('cff-swipeview-open');

		buildSlots();
		syncWindow();
		moveTrack(false);
		activateCurrent(false);

		/*
		 * STILL INSIDE THE OPENING CLICK'S CALL STACK, and that is the whole
		 * point -- deferring this behind a rAF or a timer loses the user
		 * activation and the grant with it. Must stay ABOVE the
		 * requestAnimationFrame block below.
		 */
		primeMediaActivation();

		/*
		 * Rule 1.13's fade-in, raised on the NEXT frame so the browser has a
		 * paint at `opacity: 0` to transition FROM. Setting it in the same
		 * task as the append gives no starting frame and the transition is
		 * skipped -- the element is styled and mounted in one go, so there is
		 * no "before".
		 *
		 * IN ONLY. There is no matching fade-out, and closeViewer() stays
		 * synchronous: a fade-out has to defer the teardown behind a timer or
		 * a `transitionend`, and a deferred teardown owns the scroll lock for
		 * the length of the deferral. If the transition never fires -- reduced
		 * motion, a backgrounded tab throttling timers, the node detached
		 * first -- the lock is never released and the visitor is left on a
		 * page they cannot scroll with no viewer on screen to explain it.
		 * A missing 180ms of polish on close is the cheaper failure.
		 */
		window.requestAnimationFrame(function () {
			if (! session) {
				return;
			}

			session.dom.root.classList.add('cff-swipeview-root-in');
			// Rule 1.9's first-run coach. After the fade begins, so it does not
			// appear over a still-transparent root.
			showCoach();
		});

		session.pollTimer = window.setInterval(tick, CHROME_POLL_MS);

		// Key handling is attached HERE, on open, and removed on close. Binding
		// it once at init would leak viewer keys into an open lightbox and break
		// the second half of the coexistence contract.
		session.onKeyDown = function (event) {
			onKeyDown(event);
		};
		document.addEventListener('keydown', session.onKeyDown, true);

		// Focus the close button so a keyboard visitor lands on something real
		// (S7.1). Deferred a frame so the overlay has been laid out and
		// offsetParent is meaningful for focusables().
		window.requestAnimationFrame(function () {
			if (! session) {
				return;
			}

			try {
				session.dom.close.focus();
			} catch (e) { /* Focus is best-effort; the trap still works. */ }
		});

		emitAnalytics('swipeview_opened', { index: start, total: slides.length });
	}

	/**
	 * Close the viewer and put every listener it added back.
	 *
	 * @return {void}
	 */
	function closeViewer() {
		if (! session) {
			return;
		}

		var opener  = session.opener;
		var index   = session.index;
		var viewed  = Object.keys(session.viewed).length;

		document.removeEventListener('keydown', session.onKeyDown, true);

		if (session.pollTimer !== null) {
			window.clearInterval(session.pollTimer);
			session.pollTimer = null;
		}

		clearMuteHint();

		// The gesture layer's listeners go with the node, but drag state is
		// cleared first: a finger still on the screen can deliver a trailing
		// touchend, and leaving state armed means onTouchEnd's bail does not
		// fire and the release runs its commit path against a closed viewer.
		resetDrag();

		session.slots.forEach(function (slot) {
			clearWatchdogs(slot);

			if (slot.inst && slot.inst.destroy) {
				slot.inst.destroy();
			}

			slot.inst = null;
			slot.tier = -1;
			slot.index = null;
			setSlotCaps(slot, NO_CAPS);
			slot.playingSeen = false;
		});

		if (session.dom.root.parentNode) {
			session.dom.root.parentNode.removeChild(session.dom.root);
		}

		document.documentElement.classList.remove('cff-swipeview-open');

		// Emitted BEFORE the session is dropped, because emitAnalytics resolves
		// post identity off it.
		emitAnalytics('swipeview_closed', { index: index, slides_viewed: viewed });

		session = null;

		// S7.1 focus restoration.
		if (opener && document.body.contains(opener) && typeof opener.focus === 'function') {
			try {
				opener.focus();
			} catch (e) { /* Best effort. */ }
		}
	}

	// ONE capture-phase listener on document, for the life of the page. The
	// router itself is cheap -- two closest() walks before it can decide the
	// click is not ours -- and registering once avoids any dependency on when
	// the feed script initialises.
	document.addEventListener('click', onClickCapture, true);

	/*
	 * Test seam. Exposes the predicates and pure functions the verification
	 * tiers assert on, plus read-only views of live state.
	 *
	 * Deliberately GETTERS rather than the variables themselves: exposing a
	 * variable would let a test (or anything else) write it and desync the DOM
	 * from the state, and a harness that can force state cannot then measure
	 * behaviour -- "never force state to test behaviour" is one of the plan's
	 * recorded verification rules.
	 */
	window.cffSwipeView = {
		isOpen: function () {
			return !! session;
		},
		trackLength: function () {
			return session ? session.slides.length : 0;
		},
		index: function () {
			return session ? session.index : -1;
		},
		close: closeViewer,
		_collectTrack: collectTrack,
		_hasConsent: hasConsent,
		// Pure geometry (SMASH-1978's shape). The node tier has no DOM and
		// cannot dispatch a touch sequence, so the clamp and the snap decision
		// are only directly testable if they can be called without a gesture
		// around them.
		_clampDragOffset: clampDragOffset,
		_pullFollow: pullFollow,
		_decidePullClose: decidePullClose,
		_decideSnap: decideSnap,
		_formatCount: formatCount,
		_parseCount: parseCount,
		_countNoun: countNoun,
		_withParams: withParams,
		_isFacebookUrl: isFacebookUrl,
		_isDesktopViewport: isDesktopViewport,
		_DESKTOP_QUERY: DESKTOP_QUERY,
		_prewarmSuppressed: prewarmSuppressed,
		_safeCssUrl: safeCssUrl,
		_buildSlideChrome: buildSlideChrome,
		// Read-only views for the behavioural tier.
		/**
		 * The focus cycle, exposed for the behavioural tier.
		 *
		 * It exists because a test that walks the Tab ring has to know how big
		 * the ring is: "the cycle closes" is only observable if you press Tab
		 * MORE times than there are stops. That count was a literal 7 and
		 * quietly stopped being enough the moment the rail added two controls
		 * — the walk went round exactly once, saw no repeat, and reported a
		 * broken trap. Reading the real list means the assertion cannot go
		 * stale again as controls are added in later steps.
		 *
		 * @return {Array<HTMLElement>}
		 */
		_focusables: function () {
			return session ? focusables() : [];
		},
		/**
		 * The dead-space predicate, exposed for the behavioural tier
		 * (SMASH-2064).
		 *
		 * It exists because the carve-out now UNIONS two live boxes -- the
		 * column and the drag-transformed rail -- and the union is only
		 * observable at a point that lies in one and not the other. Reaching
		 * such a point through a real tap alone is possible but proves less
		 * than it appears: `suppressTap` swallows the click that follows a
		 * drag, so a tap-only test can report "nothing happened" for the wrong
		 * reason and be vacuously green. Asking the predicate directly
		 * separates "the region moved with the glyphs" from "the click was
		 * suppressed", and the tier asserts BOTH.
		 *
		 * Read-only, and it takes the same client coordinates the click
		 * handler passes, so it cannot answer a question the real path would
		 * not have asked.
		 *
		 * @param {number} x Client x.
		 * @param {number} y Client y.
		 *
		 * @return {boolean}
		 */
		_pointIsInControlDeadSpace: function (x, y) {
			return session ? pointIsInControlDeadSpace(x, y) : false;
		},
		_state: function () {
			if (! session) {
				return null;
			}

			var slot = activeSlot();

			return {
				index: session.index,
				total: session.slides.length,
				slots: session.slots.length,
				tier: slot ? slot.tier : -1,
				adapter: (slot && slot.inst) ? slot.inst.name : null,
				caps: slot ? slot.caps : null,
				playingSeen: slot ? slot.playingSeen : false,
				muted: session.dom.root.getAttribute('data-muted'),
				captionExpanded: session.captionExpanded,
				// Renamed with its subject: the bottom-centre pill is gone and
				// the offer is now the mute chip's expanding label (AC 7).
				hintVisible: session.dom.mute.classList.contains('cff-swipeview-mute-hinting'),
				ctaVisible: ! session.dom.cta.hidden,
				paused: session.dom.root.getAttribute('data-paused') === 'true',
				dragging: session.dragging,
				dragDeltaPx: session.dragDeltaPx,
				userMuted: userMuted,
				unmuteSucceeded: unmuteSucceeded
			};
		},
		_constants: {
			WINDOW_RADIUS: WINDOW_RADIUS,
			TRANSITION_MS: TRANSITION_MS,
			NAV_COOLDOWN_MS: NAV_COOLDOWN_MS,
			WHEEL_THRESHOLD: WHEEL_THRESHOLD,
			WHEEL_COOLDOWN_MS: WHEEL_COOLDOWN_MS,
			SWIPE_THRESHOLD_PX: SWIPE_THRESHOLD_PX,
			SWIPE_MAX_DURATION_MS: SWIPE_MAX_DURATION_MS,
			DRAG_START_PX: DRAG_START_PX,
			DRAG_SNAP_AREA_FRACTION: DRAG_SNAP_AREA_FRACTION,
			START_TIMEOUT_MS: START_TIMEOUT_MS,
			STALL_TIMEOUT_MS: STALL_TIMEOUT_MS,
			CHROME_POLL_MS: CHROME_POLL_MS,
			MUTE_HINT_DELAY_MS: MUTE_HINT_DELAY_MS,
			MUTE_HINT_HOLD_MS: MUTE_HINT_HOLD_MS,
			PAUSE_GLYPH_OUT_MS: PAUSE_GLYPH_OUT_MS,
			TOAST_MS: TOAST_MS,
			FIT_CONTAIN_RATIO: FIT_CONTAIN_RATIO,
			WHEEL_ACCUM_PX: WHEEL_ACCUM_PX,
			WHEEL_IDLE_MS: WHEEL_IDLE_MS,
			WHEEL_SLIDE_COOLDOWN_MS: WHEEL_SLIDE_COOLDOWN_MS,
			PULL_CLOSE_DAMP: PULL_CLOSE_DAMP,
			PULL_CLOSE_MAX_PX: PULL_CLOSE_MAX_PX,
			PULL_CLOSE_COMMIT_PX: PULL_CLOSE_COMMIT_PX,
			COACH_ARM_MS: COACH_ARM_MS,
			COACH_AUTO_MS: COACH_AUTO_MS,
			ANALYTICS_SCHEMA_VERSION: ANALYTICS_SCHEMA_VERSION,
			ANALYTICS_FIELDS: ANALYTICS_FIELDS,
			CHAIN: CHAIN.map(function (tier) { return tier.name; })
		}
	};
}(window, document));
