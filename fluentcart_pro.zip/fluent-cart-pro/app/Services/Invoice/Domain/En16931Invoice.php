<?php

declare(strict_types=1);

namespace FluentCartPro\App\Services\Invoice\Domain;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Root invoice DTO for EN 16931. Immutable. No taxBreakdowns (engine produces them in CalculatedTotals).
 */
final class En16931Invoice
{
    public string $invoiceNumber;

    /** BT-3: TypeCode — 380 = commercial invoice, 381 = credit note */
    public string $typeCode;

    public ?string $issueDate;

    public ?string $dueDate;

    public string $currency;

    public Seller $seller;

    public Customer $buyer;

    /** @var InvoiceLine[] */
    public array $lines;

    /** @var array */
    public array $allowances;

    /** @var array */
    public array $charges;

    public Money $prepaidAmount;

    public Money $roundingAmount;

    /** Amount the invoice must settle to; when set, the engine derives BT-114 from it. */
    public ?Money $payableAmount;

    public string $paymentMeans;

    public string $notes;

    public string $buyer_reference;

    public string $purchase_order_ref;

    public string $payment_term;

    /**
     * @param array<string, mixed> $data
     */
    public function __construct(array $data = [])
    {
        $this->invoiceNumber   = (string) ($data['invoiceNumber'] ?? '');
        $this->typeCode        = (string) ($data['typeCode'] ?? '380');
        $this->issueDate       = isset($data['issueDate']) ? (string) $data['issueDate'] : null;
        $this->dueDate         = isset($data['dueDate']) ? (string) $data['dueDate'] : null;
        $this->currency        = (string) ($data['currency'] ?? 'EUR');
        $this->seller          = ($data['seller'] ?? null) instanceof Seller ? $data['seller'] : new Seller($data['seller'] ?? []);
        $this->buyer           = ($data['buyer'] ?? null) instanceof Customer ? $data['buyer'] : new Customer($data['buyer'] ?? []);
        $this->lines           = $data['lines'] ?? [];
        $this->allowances      = $data['allowances'] ?? [];
        $this->charges         = $data['charges'] ?? [];
        $currency              = $this->currency;
        $this->prepaidAmount   = ($data['prepaidAmount'] ?? null) instanceof Money ? $data['prepaidAmount'] : new Money($currency, (int) ($data['prepaidAmountCents'] ?? 0));
        $this->roundingAmount  = ($data['roundingAmount'] ?? null) instanceof Money ? $data['roundingAmount'] : new Money($currency, (int) ($data['roundingAmountCents'] ?? 0));
        $this->payableAmount   = isset($data['payableAmountCents']) ? new Money($currency, (int) $data['payableAmountCents']) : null;
        $this->paymentMeans    = (string) ($data['paymentMeans'] ?? '1');
        $this->notes           = (string) ($data['notes'] ?? '');
        $this->buyer_reference = (string) ($data['buyer_reference'] ?? '');
        $this->purchase_order_ref = (string) ($data['purchase_order_ref'] ?? '');
        $this->payment_term    = (string) ($data['payment_term'] ?? '');
    }

    /**
     * Whether any line has a standard-rated VAT category ('S').
     * Used by profiles for BR-S-02 (seller VAT ID required for standard-rated invoices).
     */
    public function hasStandardRateVat(): bool
    {
        foreach ($this->lines as $line) {
            if ($line->taxCategory === 'S') {
                return true;
            }
        }
        return false;
    }
}
