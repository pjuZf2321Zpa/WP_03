<?php

namespace TheLion\UseyourDrive\Integrations;

defined('ABSPATH') || exit;

/**
 * Manages temporary upload state in the WooCommerce session.
 *
 * Each cart-line (product_id + variation_id) gets its own session entry so
 * different variations of the same product keep separate upload contexts.
 * Variation-less uploads (e.g. on the product page before the customer picks
 * a variation) live under variation_id = 0 and are promoted to the
 * variation-specific key on first cart/checkout render.
 *
 * Persisted state per cart-line:
 *   - folder_key      Stable identifier used in the `userfoldernametemplate`
 *                     so the cloud folder does not rotate per day.
 *   - listtoken       Last rendered shortcode listtoken (used for prefill).
 *   - account_id      Cloud account that owns the temp folder.
 *   - folder_id       Configured temp upload root folder.
 *   - folder_template Sub-path under folder_id where files were stored.
 *   - uploads         Map of entry_id => file metadata.
 *   - last_activity   Unix timestamp of the last write (TTL bookkeeping).
 *
 * Uses WC()->session for persistence (cookie + DB) with the default 48h TTL.
 */
class WC_Temp_Upload_Store
{
    /** Session key prefix for temp upload entries. */
    public const SESSION_PREFIX = 'wpcp_useyourdrive_uploads_';

    /** State key for the stable folder identifier. */
    public const FOLDER_KEY = 'folder_key';

    /**
     * Get the state for a product/variation combination.
     *
     * When `$promote_parent` is true and no state exists for the variation,
     * state stored under variation_id = 0 (e.g. uploads done on the product
     * page before a variation was selected) is promoted to the variation
     * key and the parent entry is removed.
     *
     * @param int  $product_id
     * @param int  $variation_id
     * @param bool $promote_parent
     *
     * @return null|array
     */
    public static function get($product_id, $variation_id = 0, $promote_parent = true)
    {
        $session = self::session();
        if (null === $session) {
            return null;
        }

        $data = $session->get(self::full_key($product_id, $variation_id));
        if (!empty($data) && is_array($data)) {
            return $data;
        }

        if ($promote_parent && $variation_id > 0) {
            $parent = $session->get(self::full_key($product_id, 0));
            if (!empty($parent) && is_array($parent)) {
                self::set($product_id, $variation_id, $parent);
                self::remove($product_id, 0);

                return $parent;
            }
        }

        return null;
    }

    /**
     * Write the full state for a product/variation combination.
     *
     * Automatically refreshes the `last_activity` timestamp.
     *
     * @param int $product_id
     * @param int $variation_id
     */
    public static function set($product_id, $variation_id, array $data)
    {
        $session = self::session();
        if (null === $session) {
            return;
        }

        $data['last_activity'] = time();
        $session->set(self::full_key($product_id, $variation_id), $data);
    }

    /**
     * Initialise state for a product/variation if it does not yet exist.
     *
     * Always returns the resulting state (existing or newly created).
     * A `folder_key` is generated on first init so the cloud folder stays
     * stable across requests and days.
     *
     * @param int   $product_id
     * @param int   $variation_id
     * @param array $initial      Initial state (account_id, folder_id, listtoken, ...).
     *
     * @return array
     */
    public static function init($product_id, $variation_id, array $initial)
    {
        $existing = self::get($product_id, $variation_id);
        if (!empty($existing)) {
            return $existing;
        }

        if (!isset($initial[self::FOLDER_KEY]) || '' === $initial[self::FOLDER_KEY]) {
            $initial[self::FOLDER_KEY] = self::generate_folder_key($product_id, $variation_id);
        }

        if (!isset($initial['uploads']) || !is_array($initial['uploads'])) {
            $initial['uploads'] = [];
        }

        self::set($product_id, $variation_id, $initial);

        return $initial;
    }

    /**
     * Update the listtoken on an existing state without touching uploads.
     *
     * Called on every render so `prefill_temporarily_uploads()` always
     * targets the freshest input field name.
     *
     * @param int    $product_id
     * @param int    $variation_id
     * @param string $listtoken
     */
    public static function set_listtoken($product_id, $variation_id, $listtoken)
    {
        $data = self::get($product_id, $variation_id);
        if (empty($data)) {
            return;
        }

        if (($data['listtoken'] ?? null) === $listtoken) {
            return;
        }

        $data['listtoken'] = $listtoken;
        self::set($product_id, $variation_id, $data);
    }

    /**
     * Return the stable folder identifier for a cart-line.
     *
     * @param int $product_id
     * @param int $variation_id
     *
     * @return string empty string when no state exists yet
     */
    public static function get_folder_key($product_id, $variation_id = 0)
    {
        $data = self::get($product_id, $variation_id);

        return (!empty($data) && isset($data[self::FOLDER_KEY])) ? (string) $data[self::FOLDER_KEY] : '';
    }

    /**
     * Merge new uploads into an existing state.
     *
     * Does nothing when no state exists yet (no auto-init: the render path
     * is responsible for creating the state with the right account/folder
     * context).
     *
     * @param int         $product_id
     * @param int         $variation_id
     * @param array       $files        map of entry_id => file metadata
     * @param null|string $listtoken    optional listtoken to sync at the same time
     */
    public static function add_uploads($product_id, $variation_id, array $files, $listtoken = null)
    {
        $data = self::get($product_id, $variation_id);
        if (empty($data)) {
            return;
        }

        $current = isset($data['uploads']) && is_array($data['uploads']) ? $data['uploads'] : [];
        $data['uploads'] = array_merge($current, $files);

        if (null !== $listtoken) {
            $data['listtoken'] = $listtoken;
        }

        self::set($product_id, $variation_id, $data);
    }

    /**
     * Remove uploaded entries from an existing state.
     *
     * @param int      $product_id
     * @param int      $variation_id
     * @param string[] $entry_ids
     *
     * @return bool true when at least one entry was removed
     */
    public static function remove_uploads($product_id, $variation_id, array $entry_ids)
    {
        $data = self::get($product_id, $variation_id);
        if (empty($data) || empty($data['uploads'])) {
            return false;
        }

        $changed = false;
        foreach ($entry_ids as $entry_id) {
            if (isset($data['uploads'][$entry_id])) {
                unset($data['uploads'][$entry_id]);
                $changed = true;
            }
        }

        if ($changed) {
            self::set($product_id, $variation_id, $data);
        }

        return $changed;
    }

    /**
     * Return the uploads map for a product/variation.
     *
     * @param int $product_id
     * @param int $variation_id
     *
     * @return array
     */
    public static function get_uploads($product_id, $variation_id = 0)
    {
        $data = self::get($product_id, $variation_id);

        return (!empty($data) && !empty($data['uploads'])) ? $data['uploads'] : [];
    }

    /**
     * Delete the state for a cart-line.
     *
     * @param int $product_id
     * @param int $variation_id
     */
    public static function remove($product_id, $variation_id = 0)
    {
        $session = self::session();
        if (null === $session) {
            return;
        }

        $session->__unset(self::full_key($product_id, $variation_id));
    }

    /**
     * Return all active cart-line keys in the current session.
     *
     * @return array<int, array{product_id:int, variation_id:int}>
     */
    public static function get_all_keys()
    {
        $session = self::session();
        if (null === $session) {
            return [];
        }

        $session_data = method_exists($session, 'get_session_data') ? $session->get_session_data() : [];
        if (!is_array($session_data)) {
            return [];
        }

        $prefix_len = strlen(self::SESSION_PREFIX);
        $keys = [];

        foreach ($session_data as $key => $_value) {
            if (0 !== strpos($key, self::SESSION_PREFIX)) {
                continue;
            }

            $suffix = substr($key, $prefix_len);
            $parts = explode('_', $suffix, 2);

            $product_id = (int) ($parts[0] ?? 0);
            $variation_id = (int) ($parts[1] ?? 0);

            if ($product_id > 0) {
                $keys[] = ['product_id' => $product_id, 'variation_id' => $variation_id];
            }
        }

        return $keys;
    }

    /**
     * Remove every temp upload entry from the session.
     */
    public static function clear_all()
    {
        foreach (self::get_all_keys() as $entry) {
            self::remove($entry['product_id'], $entry['variation_id']);
        }
    }

    /**
     * Build the session key suffix for a product/variation combination.
     *
     * Simple products use `<product_id>_0`, variations use
     * `<product_id>_<variation_id>`.
     *
     * @param int $product_id
     * @param int $variation_id
     *
     * @return string
     */
    private static function build_key($product_id, $variation_id = 0)
    {
        return ((int) $product_id).'_'.((int) $variation_id);
    }

    /**
     * Return the full WC session key for a cart-line.
     *
     * @param int $product_id
     * @param int $variation_id
     *
     * @return string
     */
    private static function full_key($product_id, $variation_id = 0)
    {
        return self::SESSION_PREFIX.self::build_key($product_id, $variation_id);
    }

    /**
     * Resolve the active WC session, initialising it for guests when needed.
     *
     * @return null|\WC_Session
     */
    private static function session()
    {
        if (!function_exists('WC') || null === WC()->session) {
            return null;
        }

        if (!WC()->session->has_session()) {
            WC()->session->set_customer_session_cookie(true);
        }

        return WC()->session;
    }

    /**
     * Generate a unique folder key for the current upload cycle.
     *
     * Logged-in users get a user-prefixed key for traceability; guests get a
     * session-entropy hash.
     *
     * @param int $product_id
     * @param int $variation_id
     *
     * @return string
     */
    private static function generate_folder_key($product_id, $variation_id)
    {
        $session = self::session();
        $customer_id = (null !== $session) ? (string) $session->get_customer_id() : '';

        $entropy = function_exists('wp_generate_uuid4') ? wp_generate_uuid4() : bin2hex(\random_bytes(16));
        $hash = substr(md5($customer_id.'|'.$product_id.'|'.$variation_id.'|'.$entropy), 0, 16);
        $user_id = get_current_user_id();

        if ($user_id > 0) {
            return 'user_'.$user_id.'_'.$hash;
        }

        return 'guest_'.$hash;
    }
}
