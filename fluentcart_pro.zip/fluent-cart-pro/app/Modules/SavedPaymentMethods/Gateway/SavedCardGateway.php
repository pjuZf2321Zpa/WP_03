<?php

namespace FluentCartPro\App\Modules\SavedPaymentMethods\Gateway;

use FluentCart\App\Helpers\CurrenciesHelper;
use FluentCart\App\Modules\PaymentMethods\Core\AbstractPaymentGateway;
use FluentCart\App\Modules\PaymentMethods\Core\BaseGatewaySettings;
use FluentCart\App\Modules\PaymentMethods\Core\GatewayManager;
use FluentCart\App\Modules\MultiCurrency\Services\BaseCurrency;
use FluentCart\App\Modules\MultiCurrency\Services\CurrencyContext;
use FluentCart\App\Modules\PaymentMethods\StripeGateway\API\API;
use FluentCart\App\Modules\PaymentMethods\StripeGateway\Confirmations;
use FluentCart\App\Modules\PaymentMethods\PayPalGateway\PayPalHelper;
use FluentCart\App\Modules\PaymentMethods\StripeGateway\StripeHelper;
use FluentCart\App\Services\Payments\PaymentInstance;
use FluentCart\Framework\Support\Arr;
use FluentCartPro\App\Modules\SavedPaymentMethods\PayPal\PayPalTokenCharger;
use FluentCartPro\App\Modules\SavedPaymentMethods\SavedPaymentMethodRepository;
use FluentCartPro\App\Utils\Enqueuer\Vite;

/**
 * "Saved Card" pay-now gateway (SPM-06).
 *
 * Registered as a pro custom gateway so the existing place-order flow
 * (CheckoutApi::finalizeOrder -> App::gateway($order->payment_method)) routes an
 * order whose payment_method is `fct_saved_card` here. It charges a card the
 * customer already vaulted at Stripe, OFF-SESSION, server-side.
 *
 * Money-safety (see coding-rules/payment-idempotency.md):
 *  - any failure / decline / requires_action returns WP_Error, so core flips the
 *    PENDING transaction to FAILED (retry-clean) and returns 422;
 *  - a succeeded charge is recorded through core's idempotent
 *    Confirmations::confirmPaymentSuccessByCharge(), which drives the atomic
 *    PAID claim + single order_paid (a later webhook re-report is a no-op);
 *  - the PaymentIntent create carries an Idempotency-Key derived from
 *    PaymentInstance::getIdempotencySeed() so duplicate submits dedupe.
 *
 * The chosen saved card arrives as an opaque id persisted on the order at
 * checkout (Checkout\SavedCardSelector); it is resolved against THIS order's
 * customer, which is the ownership boundary — a foreign id never resolves.
 */
class SavedCardGateway extends AbstractPaymentGateway
{
    const SLUG = 'fct_saved_card';
    const ORDER_TOKEN_META = '_fct_saved_pm';

    public array $supportedFeatures = ['payment', 'refund', 'multi_currency'];

    public BaseGatewaySettings $settings;

    public function __construct()
    {
        parent::__construct(new SavedCardGatewaySettings(), null);
    }

    public static function register(): void
    {
        fluent_cart_api()->registerCustomPaymentMethod(self::SLUG, new self());
    }

    public function meta(): array
    {
        return [
            'title'       => __('Saved card', 'fluent-cart-pro'),
            'route'       => self::SLUG,
            'slug'        => self::SLUG,
            'description' => __('Pay instantly with a saved card', 'fluent-cart-pro'),
            'logo'        => Vite::getAssetUrl('images/payment-methods/saved-card.svg'),
            'logo_light'  => '',
            'icon'        => Vite::getAssetUrl('images/payment-methods/saved-card.svg'),
            'brand_color' => '#253241',
            'upcoming'    => false,
            'status'      => $this->settings->get('is_active') === 'yes',
        ];
    }

    public function makePaymentFromPaymentInstance(PaymentInstance $paymentInstance)
    {
        $order = $paymentInstance->order;
        $transaction = $paymentInstance->transaction;

        if (!$order || !$transaction) {
            return new \WP_Error('fct_saved_no_txn', __('Could not start the payment.', 'fluent-cart-pro'));
        }

        $customer = $order->customer;
        if (!$customer) {
            return new \WP_Error('fct_saved_no_customer', __('No customer for this order.', 'fluent-cart-pro'));
        }

        $opaqueId = $order->getMeta(self::ORDER_TOKEN_META);
        if (!$opaqueId) {
            return new \WP_Error('fct_saved_no_selection', __('No saved card was selected.', 'fluent-cart-pro'));
        }

        // Resolve against THIS order's customer — the ownership boundary.
        $resolved = (new SavedPaymentMethodRepository())->resolve($customer, $opaqueId);
        if (!$resolved) {
            return new \WP_Error('fct_saved_not_found', __('The selected payment method is no longer available.', 'fluent-cart-pro'));
        }

        // One slug serves every provider: the picker already posts this gateway,
        // so routing on the resolved entry keeps the checkout and place-order flow
        // untouched. Ownership was enforced above, before the branch.
        $resolvedGateway = Arr::get($resolved, 'gateway');

        if (!in_array($resolvedGateway, ['stripe', 'paypal'], true)) {
            return new \WP_Error('fct_saved_not_found', __('The selected payment method is no longer available.', 'fluent-cart-pro'));
        }

        if (!self::providerChargesIn($resolvedGateway, (string) $transaction->currency)) {
            return new \WP_Error('fct_saved_currency_unsupported', __('The selected payment method cannot pay in this currency.', 'fluent-cart-pro'));
        }

        if ($resolvedGateway === 'paypal') {
            return $this->chargeSavedPayPal($paymentInstance, $resolved);
        }

        $vendorCustomerId = Arr::get($resolved, 'customer_id') ?: $customer->getMeta('stripe_customer_id');
        $paymentMethodId = Arr::get($resolved, 'pm.id');
        if (!$vendorCustomerId || !$paymentMethodId) {
            return new \WP_Error('fct_saved_not_found', __('The selected card is no longer available.', 'fluent-cart-pro'));
        }

        $currency = $transaction->currency;
        $amount = (int) $transaction->total;
        if ($currency && CurrenciesHelper::isZeroDecimal($currency)) {
            $amount = (int) round($amount / 100);
        }

        $intentData = [
            'amount'         => $amount,
            'currency'       => strtolower($currency),
            'customer'       => $vendorCustomerId,
            'payment_method' => $paymentMethodId,
            'confirm'        => 'true',
            'off_session'    => 'true',
            'description'    => '#' . $order->invoice_no,
            'metadata'       => [
                'fct_order_id'   => $order->id,
                'fct_order_uuid' => $order->uuid,
            ],
        ];

        // Idempotency-Key from the approved seed (empty seed => no key).
        $seed = $paymentInstance->getIdempotencySeed();
        $idempotencyKey = $seed
            ? 'fct_saved_pi_' . md5($seed . '|' . wp_json_encode([
                'amount'         => $amount,
                'currency'       => strtolower((string) $currency),
                'customer'       => $vendorCustomerId,
                'payment_method' => $paymentMethodId,
            ]))
            : null;

        // Must be a headers ARRAY: API::remoteRequest merges $extraHeaders only
        // when is_array() passes, so a bare string is dropped silently — no
        // warning, no error, and no duplicate-charge protection at all.
        $headers = $idempotencyKey ? ['Idempotency-Key' => $idempotencyKey] : [];

        $intent = (new API())->createStripeObject('payment_intents', $intentData, 'current', $headers);
        if (is_wp_error($intent)) {
            return $intent; // core marks the transaction FAILED
        }

        $status = Arr::get($intent, 'status');

        if ($status === 'requires_action') {
            // Off-session cannot interactively authenticate at the place-order
            // step — fail cleanly and steer the buyer to pay with the card on-session.
            return new \WP_Error(
                'fct_saved_requires_action',
                __('This card needs authentication. Please pay by entering the card details instead.', 'fluent-cart-pro')
            );
        }

        if ($status !== 'succeeded') {
            return new \WP_Error('fct_saved_declined', __('The saved card could not be charged. Please try another card.', 'fluent-cart-pro'));
        }

        $charge = $this->fetchCharge(Arr::get($intent, 'id'));
        if (!$charge) {
            // Money was captured but we cannot read the charge. A WP_Error here
            // would flip the transaction to FAILED, and a resubmit bumps
            // payment_attempt -> new Idempotency-Key -> a SECOND PaymentIntent.
            // Report success with the order left unpaid; stamp the intent id so
            // the Stripe webhook can reconcile the transaction to paid.
            if (!$transaction->vendor_charge_id) {
                $transaction->vendor_charge_id = Arr::get($intent, 'id');
                $transaction->save();
            }

            return [
                'status'      => 'success',
                'message'     => __('Payment received and is being confirmed.', 'fluent-cart-pro'),
                'redirect_to' => $transaction->getReceiptPageUrl(),
            ];
        }

        // Record paid through core's idempotent path (atomic PAID claim + single order_paid).
        (new Confirmations())->confirmPaymentSuccessByCharge($transaction, [
            'charge'    => $charge,
            'intent_id' => Arr::get($intent, 'id'),
        ]);

        return [
            'status'      => 'success',
            'message'     => __('Payment successful', 'fluent-cart-pro'),
            'redirect_to' => $transaction->getReceiptPageUrl(),
        ];
    }

    /**
     * Whether the provider that saved a method can charge it in $currency: a
     * currency other than the store's needs the provider's multi_currency feature.
     */
    public static function providerChargesIn(string $provider, string $currency): bool
    {
        $gateway = GatewayManager::gateway($provider);
        if (!$gateway instanceof AbstractPaymentGateway) {
            return false;
        }

        if (!class_exists(CurrencyContext::class)) {
            return $gateway->isCurrencySupported();
        }

        if (!BaseCurrency::is($currency) && !$gateway->has('multi_currency')) {
            return false;
        }

        // isCurrencySupported() reads the rendering currency
        return (bool) CurrencyContext::withCurrency($currency, [$gateway, 'isCurrencySupported']);
    }

    /**
     * Charge a saved PayPal account off-session.
     *
     * The PENDING result is why this does not simply map non-true to WP_Error:
     * an eCheck that is still settling is neither paid nor failed, and returning
     * WP_Error would make core flip the transaction to FAILED while PayPal may
     * still capture the money. Report it as a success whose order stays unpaid
     * until the webhook settles it.
     *
     * @param PaymentInstance $paymentInstance
     * @param array $resolved ['gateway'=>'paypal', 'pm'=>[...]]
     * @return array|\WP_Error
     */
    private function chargeSavedPayPal(PaymentInstance $paymentInstance, array $resolved)
    {
        $transaction = $paymentInstance->transaction;
        $token = Arr::get($resolved, 'pm.id');

        $result = (new PayPalTokenCharger())->charge($paymentInstance, $token);

        if (is_wp_error($result)) {
            return $result; // core marks the transaction FAILED — retry-clean
        }

        if ($result === 'processing') {
            return [
                'status'      => 'success',
                'message'     => __('Payment received and is being confirmed by PayPal.', 'fluent-cart-pro'),
                'redirect_to' => $transaction->getReceiptPageUrl(),
            ];
        }

        return [
            'status'      => 'success',
            'message'     => __('Payment successful', 'fluent-cart-pro'),
            'redirect_to' => $transaction->getReceiptPageUrl(),
        ];
    }

    /**
     * Retrieve the expanded latest charge for a succeeded PaymentIntent.
     */
    private function fetchCharge($intentId)
    {
        if (!$intentId) {
            return null;
        }

        $full = (new API())->getStripeObject('payment_intents/' . $intentId . '?expand[]=latest_charge');
        if (is_wp_error($full)) {
            return null;
        }

        $charge = Arr::get($full, 'latest_charge');

        return is_array($charge) ? $charge : null;
    }

    /**
     * The charge is an ordinary Stripe PaymentIntent, so refunds go through the
     * same helper core's Stripe gateway uses (Stripe.php:399-409).
     *
     * This MUST be named processRefund() — that is what Services\Payments\Refund
     * calls. A method named refund() is never invoked, which leaves the
     * abstract's not_implemented WP_Error to be swallowed while the refund
     * transaction and the OrderRefund event have already been dispatched: the
     * order reads as refunded and no money is returned.
     *
     * @param OrderTransaction $transaction
     * @param int $amount
     * @param array $args
     * @return string|\WP_Error vendor refund id, or the gateway error
     */
    public function processRefund($transaction, $amount, $args)
    {
        if (!$amount) {
            return new \WP_Error(
                'fct_saved_refund_amount_required',
                __('Refund amount is required.', 'fluent-cart-pro')
            );
        }

        // This slug now creates BOTH Stripe and PayPal charges, so the refund has
        // to reach the provider that actually took the money. Sending a PayPal
        // capture id through Stripe's refund API fails at best; at worst the
        // gateway advertises refund support it cannot honour, which is how a
        // refund ends up recorded locally with nothing returned to the buyer.
        if ($this->chargedProvider($transaction) === 'paypal') {
            return PayPalHelper::processRemoteRefund($transaction, $amount, $args);
        }

        return StripeHelper::processRemoteRefund($transaction, $amount, $args);
    }

    /**
     * Which provider actually captured this transaction.
     *
     * Derived from `paypal_vault_order_id`, which core's
     * PayPalGateway\Processor::settleVaultChargeResponse() persists BEFORE it
     * branches on capture status — so it is present for every transaction this
     * gateway charged through PayPal, including one still settling as an eCheck.
     * Deriving beats stamping our own marker here: there is no window between the
     * charge and the stamp in which a refund could resolve the wrong way.
     *
     * @param \FluentCart\App\Models\OrderTransaction $transaction
     * @return string 'paypal'|'stripe'
     */
    private function chargedProvider($transaction): string
    {
        $meta = $transaction->meta ?? [];

        if (is_array($meta) && Arr::get($meta, 'paypal_vault_order_id')) {
            return 'paypal';
        }

        return 'stripe';
    }

    public function webHookPaymentMethodName()
    {
        return self::SLUG;
    }

    public function handleIPN()
    {
        // No dedicated IPN — Stripe webhooks are handled by the core Stripe gateway.
    }

    public function getOrderInfo(array $data)
    {
        // No client-side element: the standard Place Order button drives the
        // server-side off-session charge (mirrors the offline gateway).
        return null;
    }

    public function fields()
    {
        return [];
    }
}
