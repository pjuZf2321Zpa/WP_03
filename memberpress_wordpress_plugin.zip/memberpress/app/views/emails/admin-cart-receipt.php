<?php if (!defined('ABSPATH')) {
    die('You are not allowed to call this page directly.');
} ?>
<div id="header" style="width: 680px; padding: 0px; margin: 0 auto; text-align: left;">
  <h1 style="font-size: 30px; margin-bottom: 0;"><?php echo esc_html_x('New Cart Order', 'email', 'memberpress'); ?></h1>
  <h2 style="margin-top: 0; color: #999; font-weight: normal;"><?php echo esc_html_x('Order #{$order_id} from {$user_email}', 'email', 'memberpress'); ?></h2>
</div>
<div id="body" style="width: 600px; background: white; padding: 40px; margin: 0 auto; text-align: left;">

  <p><?php echo esc_html_x('A new cart order has been placed on your site.', 'email', 'memberpress'); ?></p>

  {$order_items}

  <table style="clear: both; width: 100%;" class="transaction">
    <tr><th style="text-align: left;"><?php echo esc_html_x('Customer:', 'email', 'memberpress'); ?></th><td>{$user_first_name} {$user_last_name} &lt;{$user_email}&gt;</td></tr>
    <tr><th style="text-align: left;"><?php echo esc_html_x('Order Date:', 'email', 'memberpress'); ?></th><td>{$order_date}</td></tr>
    <tr><th style="text-align: left;"><?php echo esc_html_x('Payment Method:', 'email', 'memberpress'); ?></th><td>{$payment_method}</td></tr>
    <tr><th style="text-align: left;"><?php echo esc_html_x('Order Total:', 'email', 'memberpress'); ?></th><td><strong>{$order_total}</strong></td></tr>
  </table>

</div>
