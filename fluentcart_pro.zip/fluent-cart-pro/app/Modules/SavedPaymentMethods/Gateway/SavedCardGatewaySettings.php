<?php

namespace FluentCartPro\App\Modules\SavedPaymentMethods\Gateway;

use FluentCart\App\Modules\PaymentMethods\Core\BaseGatewaySettings;
use FluentCartPro\App\Modules\SavedPaymentMethods\SavedPaymentMethods;

/**
 * Settings shim for the Saved Card gateway. It has no configurable UI of its
 * own — it is "active" exactly when the Saved Payment Methods feature is
 * enabled. Stripe keys/mode come from the real Stripe gateway (this gateway
 * only charges tokens already vaulted there).
 */
class SavedCardGatewaySettings extends BaseGatewaySettings
{
    public $settings;
    public $methodHandler = 'fluent_cart_payment_settings_fct_saved_card';

    public static function getDefaults(): array
    {
        return [
            'is_active'    => 'no',
            'payment_mode' => 'live',
        ];
    }

    public function isActive(): bool
    {
        return SavedPaymentMethods::isEnabled();
    }

    public function getMode()
    {
        return (new \FluentCart\Api\StoreSettings())->get('order_mode');
    }

    public function getPublicKey()
    {
        return null;
    }

    public function getApiKey()
    {
        return null;
    }

    /**
     * is_active tracks the feature flag so the gateway only surfaces when the
     * merchant has enabled saved payment methods.
     */
    public function get($key = '')
    {
        if ($key === 'is_active') {
            return SavedPaymentMethods::isEnabled() ? 'yes' : 'no';
        }

        if ($key && is_array($this->settings) && isset($this->settings[$key])) {
            return $this->settings[$key];
        }

        return $this->settings;
    }
}
