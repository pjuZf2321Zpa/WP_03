<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Actions\WebbaBooking\WebbaBookingProActions;
use BitApps\IntegrationsPro\Config;
use BitApps\IntegrationsPro\Core\Util\Hooks;

Hooks::filter(Config::withFreePrefix('webba_booking_create_booking'), [WebbaBookingProActions::class, 'createBooking'], 10, 3);
Hooks::filter(Config::withFreePrefix('webba_booking_update_status'), [WebbaBookingProActions::class, 'updateBookingStatus'], 10, 3);
Hooks::filter(Config::withFreePrefix('webba_booking_approve'), [WebbaBookingProActions::class, 'approveBooking'], 10, 3);
Hooks::filter(Config::withFreePrefix('webba_booking_cancel'), [WebbaBookingProActions::class, 'cancelBooking'], 10, 3);
Hooks::filter(Config::withFreePrefix('webba_booking_delete'), [WebbaBookingProActions::class, 'deleteBooking'], 10, 3);
Hooks::filter(Config::withFreePrefix('webba_booking_set_paid'), [WebbaBookingProActions::class, 'setBookingAsPaid'], 10, 3);
Hooks::filter(Config::withFreePrefix('webba_booking_create_coupon'), [WebbaBookingProActions::class, 'createCoupon'], 10, 2);
Hooks::filter(Config::withFreePrefix('webba_booking_update_coupon'), [WebbaBookingProActions::class, 'updateCoupon'], 10, 3);
Hooks::filter(Config::withFreePrefix('webba_booking_create_service'), [WebbaBookingProActions::class, 'createService'], 10, 3);
Hooks::filter(Config::withFreePrefix('webba_booking_update_service'), [WebbaBookingProActions::class, 'updateService'], 10, 3);
Hooks::filter(Config::withFreePrefix('webba_booking_create_category'), [WebbaBookingProActions::class, 'createServiceCategory'], 10, 2);
Hooks::filter(Config::withFreePrefix('webba_booking_create_staff'), [WebbaBookingProActions::class, 'createStaffMember'], 10, 2);
Hooks::filter(Config::withFreePrefix('webba_booking_create_location'), [WebbaBookingProActions::class, 'createLocation'], 10, 2);
