<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Actions\WCAffiliate\WCAffiliateProHelper;
use BitApps\IntegrationsPro\Config;
use BitApps\IntegrationsPro\Core\Util\Hooks;

Hooks::filter(Config::withFreePrefix('wcaffiliate_create_affiliate'), [WCAffiliateProHelper::class, 'createAffiliate'], 10, 2);
Hooks::filter(Config::withFreePrefix('wcaffiliate_update_affiliate_status'), [WCAffiliateProHelper::class, 'updateAffiliateStatus'], 10, 2);
Hooks::filter(Config::withFreePrefix('wcaffiliate_create_referral'), [WCAffiliateProHelper::class, 'createReferral'], 10, 2);
Hooks::filter(Config::withFreePrefix('wcaffiliate_update_referral_status'), [WCAffiliateProHelper::class, 'updateReferralStatus'], 10, 2);
Hooks::filter(Config::withFreePrefix('wcaffiliate_create_transaction'), [WCAffiliateProHelper::class, 'createTransaction'], 10, 2);
Hooks::filter(Config::withFreePrefix('wcaffiliate_update_transaction_status'), [WCAffiliateProHelper::class, 'updateTransactionStatus'], 10, 2);
