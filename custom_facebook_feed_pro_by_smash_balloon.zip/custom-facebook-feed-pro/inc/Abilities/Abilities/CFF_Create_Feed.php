<?php

namespace CustomFacebookFeed\Abilities\Abilities;

use CustomFacebookFeed\Abilities\Services\CFF_Feed_Settings_Service;
use CustomFacebookFeed\Abilities\Services\CFF_Settings_Schema;

if (!defined('ABSPATH')) {
	exit;
}

/**
 * facebook-feed/create-feed
 *
 * @since 4.13
 */
class CFF_Create_Feed extends CFF_Ability
{
	public function slug()
	{
		return 'create-feed';
	}

	public function args()
	{
		$writable = CFF_Settings_Schema::writable(CFF_Settings_Schema::feed_settings());
		// feed_name has a dedicated top-level property; a nested copy would be
		// silently written into the settings blob instead of the feeds row.
		unset($writable['feed_name']);

		return array(
			'label'               => __('Create a Custom Facebook Feed', 'custom-facebook-feed'),
			'description'         => __('Creates a new feed like the Feed Builder does: an optional feed template, optional quick settings, and optional already-connected accounts as sources. A feed can be created with NO sources and connected later. Returns the new feed id and its shortcode. Requires AI write access.', 'custom-facebook-feed'), // phpcs:ignore Generic.Files.LineLength.TooLong -- single literal for make-pot
			'input_schema'        => array(
				'type'                 => 'object',
				'properties'           => array(
					'feed_name'    => array(
						'type'        => 'string',
						'maxLength'   => 200,
						'description' => 'Optional name; defaults to the first source username.',
					),
					'feedtemplate' => array(
						'type'        => 'string',
						'enum'        => CFF_Feed_Settings_Service::FEED_TEMPLATES,
						'description' => 'Optional feed template preset.',
					),
					'sources'      => array(
						'type'        => 'array',
						'items'       => array('type' => 'string', 'maxLength' => 100),
						'maxItems'    => 10,
						'description' => 'Usernames or account ids of ALREADY-CONNECTED accounts (see list-sources). Omit to create a sourceless feed.', // phpcs:ignore Generic.Files.LineLength.TooLong -- single literal for make-pot
					),
					'settings'     => array(
						'type'                 => 'object',
						'properties'           => CFF_Settings_Schema::to_json_properties($writable),
						'additionalProperties' => false,
						'description'          => 'Quick settings applied on top of the template.',
					),
				),
				'additionalProperties' => false,
			),
			'output_schema'       => array(
				'type'       => 'object',
				'properties' => array(
					'feed_id'   => array('type' => 'integer'),
					'feed_name' => array('type' => 'string'),
					'shortcode' => array('type' => 'string'),
					'updated'   => array('type' => 'array', 'items' => array('type' => 'string')),
					'ignored'   => array('type' => 'object'),
					'warnings'  => array(
						'type'        => 'array',
						'items'       => array('type' => 'string'),
						'description' => 'Non-fatal notes about the write: a requested change was accepted '
							. 'but overridden by a plugin rule, or a coupled precondition fell back to a default.',
					),
				),
			),
			'execute_callback'    => array($this, 'execute'),
			'permission_callback' => array($this, 'can_write'),
			'meta'                => $this->write_meta(false, false),
		);
	}

	public function execute($input = null)
	{
		return (new CFF_Feed_Settings_Service())->create_feed(
			$this->normalize_input($input),
			array(CFF_Update_Feed_Settings::class, 'tier_check')
		);
	}
}
