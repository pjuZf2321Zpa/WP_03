<?php

namespace MasterStudy\Lms\Pro\AddonsPlus\Notifications\Repositories;

final class PushQueueRepository {
	public const STATUS_PENDING    = 'pending';
	public const STATUS_PROCESSING = 'processing';
	public const STATUS_SENT       = 'sent';
	public const STATUS_RETRY      = 'retry';
	public const STATUS_FAILED     = 'failed';
	public const STATUS_SKIPPED    = 'skipped';
	private const MAX_ATTEMPTS     = 5;
	private const STALE_SECONDS    = 900;

	public function enqueue( int $notification_id, array $recipient_user_ids ): void {
		global $wpdb;

		$recipient_user_ids = array_values( array_unique( array_filter( array_map( 'absint', $recipient_user_ids ) ) ) );

		if ( $notification_id <= 0 || empty( $recipient_user_ids ) ) {
			return;
		}

		$now   = gmdate( 'Y-m-d H:i:s' );
		$table = masterstudy_lms_notification_push_queue_table_name( $wpdb );
		$rows  = array();
		$args  = array();

		foreach ( $recipient_user_ids as $user_id ) {
			$rows[] = '(%d,%d,%s,%s,%s,%s)';
			$args[] = $notification_id;
			$args[] = $user_id;
			$args[] = self::STATUS_PENDING;
			$args[] = $now;
			$args[] = $now;
			$args[] = $now;
		}

		// phpcs:disable WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare -- Table name and value placeholders are generated internally.
		$wpdb->query(
			$wpdb->prepare(
				"INSERT IGNORE INTO {$table} (notification_id,recipient_user_id,status,available_at_gmt,created_at_gmt,updated_at_gmt) VALUES " . implode( ',', $rows ),
				$args
			)
		);
		// phpcs:enable WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare
	}

	public function claim_available( int $limit = 25 ): array {
		global $wpdb;

		$limit    = min( 100, max( 1, $limit ) );
		$now      = gmdate( 'Y-m-d H:i:s' );
		$claim_id = wp_generate_uuid4();
		$queue    = masterstudy_lms_notification_push_queue_table_name( $wpdb );

		$wpdb->query(
			$wpdb->prepare(
				// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				"UPDATE {$queue}
					SET status = %s, claim_id = %s, updated_at_gmt = %s
					WHERE status IN (%s,%s) AND available_at_gmt <= %s
					ORDER BY available_at_gmt ASC, id ASC
					LIMIT %d",
				self::STATUS_PROCESSING,
				$claim_id,
				$now,
				self::STATUS_PENDING,
				self::STATUS_RETRY,
				$now,
				$limit
			)
		);

		if ( $wpdb->rows_affected <= 0 ) {
			return array();
		}

		return $wpdb->get_results(
			$wpdb->prepare(
				// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				"SELECT * FROM {$queue} WHERE claim_id = %s ORDER BY available_at_gmt ASC, id ASC",
				$claim_id
			),
			ARRAY_A
		);
	}

	public function mark_sent( int $queue_id ): void {
		$this->update_status( $queue_id, self::STATUS_SENT );
	}

	public function mark_skipped( int $queue_id, string $reason = '' ): void {
		$this->update_status( $queue_id, self::STATUS_SKIPPED, $reason );
	}

	public function mark_failed( int $queue_id, int $attempts, string $error, bool $retry = true ): void {
		global $wpdb;

		$attempts = max( 1, $attempts );
		$status   = $retry && $attempts < self::MAX_ATTEMPTS ? self::STATUS_RETRY : self::STATUS_FAILED;
		$delay    = min( HOUR_IN_SECONDS, (int) pow( 2, $attempts ) * MINUTE_IN_SECONDS );
		$now      = gmdate( 'Y-m-d H:i:s' );

		$wpdb->update(
			masterstudy_lms_notification_push_queue_table_name( $wpdb ),
			array(
				'status'           => $status,
				'claim_id'         => '',
				'attempts'         => $attempts,
				'available_at_gmt' => gmdate( 'Y-m-d H:i:s', time() + $delay ),
				'last_error'       => sanitize_textarea_field( $error ),
				'updated_at_gmt'   => $now,
				'processed_at_gmt' => self::STATUS_FAILED === $status ? $now : null,
			),
			array( 'id' => $queue_id ),
			array( '%s', '%s', '%d', '%s', '%s', '%s', '%s' ),
			array( '%d' )
		);
	}

	public function recover_stale_processing( int $stale_seconds = self::STALE_SECONDS ): int {
		global $wpdb;

		$now     = gmdate( 'Y-m-d H:i:s' );
		$cutoff  = gmdate( 'Y-m-d H:i:s', time() - max( MINUTE_IN_SECONDS, $stale_seconds ) );
		$message = 'Queue claim expired before processing completed.';
		$table   = masterstudy_lms_notification_push_queue_table_name( $wpdb );
		$retried = (int) $wpdb->query(
			$wpdb->prepare(
				// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				"UPDATE {$table}
					SET status = %s,
						claim_id = '',
						available_at_gmt = %s,
						processed_at_gmt = NULL,
						last_error = %s,
						updated_at_gmt = %s,
						attempts = LEAST(attempts + 1, %d)
					WHERE status = %s AND updated_at_gmt <= %s AND attempts + 1 < %d",
				self::STATUS_RETRY,
				$now,
				$message,
				$now,
				self::MAX_ATTEMPTS,
				self::STATUS_PROCESSING,
				$cutoff,
				self::MAX_ATTEMPTS
			)
		);
		$failed = (int) $wpdb->query(
			$wpdb->prepare(
				// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				"UPDATE {$table}
					SET status = %s,
						claim_id = '',
						available_at_gmt = %s,
						processed_at_gmt = %s,
						last_error = %s,
						updated_at_gmt = %s,
						attempts = LEAST(attempts + 1, %d)
					WHERE status = %s AND updated_at_gmt <= %s AND attempts + 1 >= %d",
				self::STATUS_FAILED,
				$now,
				$now,
				$message,
				$now,
				self::MAX_ATTEMPTS,
				self::STATUS_PROCESSING,
				$cutoff,
				self::MAX_ATTEMPTS
			)
		);

		return $retried + $failed;
	}

	public function has_pending(): bool {
		global $wpdb;

		return (bool) $wpdb->get_var(
			$wpdb->prepare(
				// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- Table name is generated from $wpdb->prefix.
				'SELECT 1 FROM ' . masterstudy_lms_notification_push_queue_table_name( $wpdb ) . ' WHERE status IN (%s,%s) LIMIT 1',
				self::STATUS_PENDING,
				self::STATUS_RETRY
			)
		);
	}

	private function update_status( int $queue_id, string $status, string $message = '' ): void {
		global $wpdb;

		$now = gmdate( 'Y-m-d H:i:s' );

		$wpdb->update(
			masterstudy_lms_notification_push_queue_table_name( $wpdb ),
			array(
				'status'           => $status,
				'claim_id'         => '',
				'processed_at_gmt' => $now,
				'updated_at_gmt'   => $now,
				'last_error'       => sanitize_textarea_field( $message ),
			),
			array( 'id' => $queue_id ),
			array( '%s', '%s', '%s', '%s', '%s' ),
			array( '%d' )
		);
	}
}
