<?php

namespace WPAICG\Addons\Ollama;

use WP_Error;

if (!defined('ABSPATH')) {
    exit;
}

// Pro initialization may load this provider before the shared dependency loader.
if (!class_exists(\WPAICG\Core\Providers\BaseProviderStrategy::class)) {
    require_once dirname(__DIR__, 2) . '/classes/ai/providers/contracts.php';
}
require_once dirname(__DIR__, 2) . '/classes/ai/providers/chat-completions.php';

/**
 * Shared Ollama model helpers for ID extraction and name-based capability hints.
 */
class AIPKit_Ollama_Model_Utils
{
    /**
     * Name-pattern hints for Ollama vision-capable models.
     *
     * @var array<int, string>
     */
    private const VISION_HINTS = [
        'llava',
        'bakllava',
        'minicpm-v',
        'moondream',
        'qwen-vl',
        'qwen2-vl',
        'qwen2.5-vl',
        'qwen3-vl',
        'gemma3',
        'vision',
        '-vl',
        '_vl',
    ];

    /**
     * Name-pattern hints for Ollama embedding-capable models.
     *
     * @var array<int, string>
     */
    private const EMBEDDING_HINTS = [
        'embed',
        'embedding',
        'nomic-embed',
        'mxbai-embed',
        'bge-',
        'e5-',
        'all-minilm',
        'snowflake-arctic-embed',
        'jina-embeddings',
    ];

    /**
     * Extract normalized model id from mixed row payload.
     *
     * @param mixed $row
     * @return string
     */
    public static function extract_model_id($row): string
    {
        if (is_string($row)) {
            return self::normalize_model_id($row);
        }

        if (!is_array($row)) {
            return '';
        }

        $id = isset($row['id']) ? (string) $row['id'] : '';
        if ($id === '' && isset($row['name'])) {
            $id = (string) $row['name'];
        }

        return self::normalize_model_id($id);
    }

    /**
     * Normalize a model id string.
     *
     * @param mixed $value
     * @return string
     */
    public static function normalize_model_id($value): string
    {
        return sanitize_text_field((string) $value);
    }

    /**
     * Determine whether a capability map declares vision support.
     *
     * @param array<string, mixed> $capabilities
     * @return bool
     */
    public static function is_vision_capable(array $capabilities): bool
    {
        return !empty($capabilities['vision']) || !empty($capabilities['image_input']);
    }

    /**
     * Determine whether model id/name contains vision hints.
     *
     * @param string $value
     * @return bool
     */
    public static function has_vision_hint(string $value): bool
    {
        return self::contains_any_hint($value, self::VISION_HINTS);
    }

    /**
     * Determine whether model id/name contains embedding hints.
     *
     * @param string $value
     * @return bool
     */
    public static function has_embedding_hint(string $value): bool
    {
        return self::contains_any_hint($value, self::EMBEDDING_HINTS);
    }

    /**
     * Utility to check if normalized haystack contains any configured hint token.
     *
     * @param string $value
     * @param array<int, string> $hints
     * @return bool
     */
    private static function contains_any_hint(string $value, array $hints): bool
    {
        $haystack = strtolower(trim($value));
        if ($haystack === '') {
            return false;
        }

        foreach ($hints as $hint) {
            if ($hint !== '' && strpos($haystack, $hint) !== false) {
                return true;
            }
        }

        return false;
    }
}

/**
 * Resolves normalized Ollama model capabilities from /api/show metadata.
 */
class AIPKit_Ollama_Capability_Resolver
{
    /**
     * Provider-level capability defaults.
     *
     * @return array<string, bool>
     */
    public static function get_capability_map(): array
    {
        return [
            'chat' => true,
            'stream' => true,
            'completion' => true,
            'text_generation' => true,
            'tools' => false,
            'web_search_tool' => false,
            'vision' => false,
            'image_input' => false,
            'image_output' => false,
            'image_generation' => false,
            'embeddings' => false,
        ];
    }

    /**
     * Normalize mixed capability list values.
     *
     * @param mixed $value Raw list.
     * @return array<int, string>
     */
    private static function normalize_list($value): array
    {
        if (!is_array($value)) {
            return [];
        }

        $normalized = [];
        foreach ($value as $entry) {
            if (!is_string($entry)) {
                continue;
            }
            $entry = strtolower(trim($entry));
            if ($entry !== '') {
                $normalized[] = $entry;
            }
        }

        return array_values(array_unique($normalized));
    }

    /**
     * Utility to check if haystack contains any item from needles.
     *
     * @param string $haystack
     * @param array<int, string> $needles
     * @return bool
     */
    private static function contains_any(string $haystack, array $needles): bool
    {
        foreach ($needles as $needle) {
            if ($needle !== '' && strpos($haystack, $needle) !== false) {
                return true;
            }
        }

        return false;
    }

    /**
     * Resolve model-level capabilities from /api/show payload.
     *
     * @param array<string, mixed> $show_response Decoded /api/show response.
     * @param string $model_id Optional explicit model id.
     * @return array<string, bool>
     */
    public static function resolve_from_show_response(array $show_response, string $model_id = ''): array
    {
        $resolved = self::get_capability_map();

        $raw_capabilities = self::normalize_list($show_response['capabilities'] ?? []);
        $has_explicit_capability_list = !empty($raw_capabilities);

        if ($has_explicit_capability_list) {
            $supports_completion = in_array('completion', $raw_capabilities, true)
                || in_array('chat', $raw_capabilities, true)
                || in_array('generate', $raw_capabilities, true);
            $supports_vision = in_array('vision', $raw_capabilities, true)
                || in_array('image_input', $raw_capabilities, true)
                || in_array('image', $raw_capabilities, true)
                || in_array('multimodal', $raw_capabilities, true);
            $supports_embeddings = in_array('embeddings', $raw_capabilities, true)
                || in_array('embedding', $raw_capabilities, true)
                || in_array('embed', $raw_capabilities, true);

            $resolved['completion'] = $supports_completion;
            $resolved['text_generation'] = $supports_completion;
            $resolved['chat'] = $supports_completion;
            $resolved['stream'] = $supports_completion;
            $resolved['vision'] = $supports_vision;
            $resolved['image_input'] = $supports_vision;
            $resolved['embeddings'] = $supports_embeddings;
        }

        $effective_model_id = $model_id !== ''
            ? $model_id
            : (string) ($show_response['model'] ?? ($show_response['name'] ?? ''));
        $model_id_l = strtolower(trim($effective_model_id));

        $details = is_array($show_response['details'] ?? null) ? $show_response['details'] : [];
        $detail_family = isset($details['family']) && is_string($details['family'])
            ? strtolower(trim($details['family']))
            : '';
        $detail_families = self::normalize_list($details['families'] ?? []);

        $family_haystack = trim(implode(' ', array_merge([$detail_family], $detail_families, [$model_id_l])));

        $model_info = is_array($show_response['model_info'] ?? null) ? $show_response['model_info'] : [];
        $model_info_keys = [];
        foreach (array_keys($model_info) as $key) {
            if (is_string($key)) {
                $model_info_keys[] = strtolower(trim($key));
            }
        }
        $model_info_haystack = implode(' ', $model_info_keys);

        // Vision inference fallbacks when capabilities array is absent or incomplete.
        $vision_from_model_info = self::contains_any(
            $model_info_haystack,
            ['.vision.', '.mm.', 'tokens_per_image', 'image_size', 'vision']
        );
        $vision_from_family = AIPKit_Ollama_Model_Utils::has_vision_hint($family_haystack);

        if ($vision_from_model_info || $vision_from_family) {
            $resolved['vision'] = true;
            $resolved['image_input'] = true;
        }

        // Embedding inference fallback from model naming/family hints.
        $embedding_hint = AIPKit_Ollama_Model_Utils::has_embedding_hint($family_haystack);
        if ($embedding_hint) {
            $resolved['embeddings'] = true;
        }

        // If explicit capabilities only indicate embedding and no completion, treat as embedding-only model.
        $explicitly_embedding_only = $has_explicit_capability_list
            && $resolved['embeddings']
            && !$resolved['completion'];
        if ($explicitly_embedding_only) {
            $resolved['chat'] = false;
            $resolved['stream'] = false;
            $resolved['text_generation'] = false;
        }

        return $resolved;
    }
}

class AIPKit_Ollama_API
{
    private const DEFAULT_BASE_URL = 'http://localhost:11434';
    private const DEFAULT_TIMEOUT_SECONDS = 120;

    /**
     * Resolve configured Ollama base URL from request params or saved option.
     *
     * @param array $params API params that may contain `base_url`.
     * @return string
     */
    private function resolve_base_url(array $params = []): string
    {
        $raw_base_url = $params['base_url'] ?? get_option('aipkit_ollama_base_url', self::DEFAULT_BASE_URL);
        $base_url = is_string($raw_base_url) ? trim($raw_base_url) : '';
        if ($base_url === '') {
            $base_url = self::DEFAULT_BASE_URL;
        }

        return rtrim($base_url, '/');
    }

    /**
     * Decode and validate an Ollama HTTP response.
     *
     * @param mixed  $response HTTP response from wp_remote_*.
     * @param string $context  Context label for error messages.
     * @return array|\WP_Error
     */
    private function decode_response($response, string $context)
    {
        if (is_wp_error($response)) {
            return $response;
        }

        $status_code = (int) wp_remote_retrieve_response_code($response);
        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);

        if (json_last_error() !== JSON_ERROR_NONE) {
            return new \WP_Error(
                'json_decode_error',
                sprintf(
                    /* translators: %s: Request context label. */
                    __('Failed to decode JSON response from Ollama %s.', 'gpt3-ai-content-generator'),
                    esc_html($context)
                ),
                ['status' => $status_code, 'response_body' => $body]
            );
        }

        if ($status_code >= 400) {
            $error_message = (is_array($data) && isset($data['error']) && is_string($data['error']) && $data['error'] !== '')
                ? $data['error']
                : sprintf(
                    /* translators: %d: HTTP status code returned by API. */
                    __('Ollama API request failed with HTTP %d.', 'gpt3-ai-content-generator'),
                    $status_code
                );

            return new \WP_Error(
                'ollama_api_error',
                $error_message,
                ['status' => $status_code, 'response_body' => $data]
            );
        }

        return is_array($data) ? $data : [];
    }

    /**
     * Execute GET request and decode JSON response.
     *
     * @param string $endpoint Endpoint path beginning with /.
     * @param array  $api_params API connection parameters.
     * @param int    $timeout Timeout in seconds.
     * @param string $context Context label for errors.
     * @return array|\WP_Error
     */
    private function get_json(string $endpoint, array $api_params = [], int $timeout = self::DEFAULT_TIMEOUT_SECONDS, string $context = '')
    {
        $response = wp_remote_get(
            $this->resolve_base_url($api_params) . $endpoint,
            [
                'headers' => [
                    'Content-Type' => 'application/json',
                    'Accept' => 'application/json',
                ],
                'timeout' => $timeout,
            ]
        );

        return $this->decode_response($response, $context !== '' ? $context : $endpoint);
    }

    /**
     * Execute POST request and decode JSON response.
     *
     * @param string $endpoint Endpoint path beginning with /.
     * @param array  $payload Request payload.
     * @param array  $api_params API connection parameters.
     * @param int    $timeout Timeout in seconds.
     * @param string $context Context label for errors.
     * @return array|\WP_Error
     */
    private function post_json(string $endpoint, array $payload, array $api_params = [], int $timeout = self::DEFAULT_TIMEOUT_SECONDS, string $context = '')
    {
        $response = wp_remote_post(
            $this->resolve_base_url($api_params) . $endpoint,
            [
                'body' => wp_json_encode($payload),
                'headers' => [
                    'Content-Type' => 'application/json',
                    'Accept' => 'application/json',
                ],
                'timeout' => $timeout,
            ]
        );

        return $this->decode_response($response, $context !== '' ? $context : $endpoint);
    }

    /**
     * Normalize embedding vector values to float entries.
     *
     * @param mixed $vector
     * @return array<int, float>|null
     */
    public static function normalize_embedding_vector($vector): ?array
    {
        if (!is_array($vector)) {
            return null;
        }

        $normalized = [];
        foreach ($vector as $value) {
            if (is_int($value) || is_float($value) || (is_string($value) && is_numeric($value))) {
                $normalized[] = (float) $value;
            }
        }

        return empty($normalized) ? null : $normalized;
    }

    /**
     * Extract a single embedding vector from mixed endpoint response shapes.
     *
     * @param array<string, mixed> $response
     * @return array<int, float>|null
     */
    private static function extract_embedding_vector_from_response(array $response): ?array
    {
        if (isset($response['embedding']) && is_array($response['embedding'])) {
            return self::normalize_embedding_vector($response['embedding']);
        }

        if (isset($response['embeddings']) && is_array($response['embeddings']) && isset($response['embeddings'][0])) {
            $first = $response['embeddings'][0];
            if (is_array($first) && isset($first['embedding'])) {
                return self::normalize_embedding_vector($first['embedding']);
            }
            return self::normalize_embedding_vector($first);
        }

        if (isset($response['data']) && is_array($response['data']) && isset($response['data'][0]) && is_array($response['data'][0])) {
            $first_data = $response['data'][0];
            if (isset($first_data['embedding']) && is_array($first_data['embedding'])) {
                return self::normalize_embedding_vector($first_data['embedding']);
            }
        }

        return null;
    }

    /**
     * Fallback for legacy `/api/embeddings` endpoint with multi-input batching.
     *
     * Legacy endpoint commonly accepts a single `prompt`, so this method
     * executes one request per input and aggregates vectors.
     *
     * @param array<int, string> $inputs
     * @param string             $model
     * @param array<string, mixed> $api_params
     * @return array|\WP_Error
     */
    private function request_embeddings_legacy_batch(array $inputs, string $model, array $api_params = [])
    {
        $embeddings = [];
        $prompt_eval_count = 0;
        $eval_count = 0;
        $total_duration = 0;
        $load_duration = 0;

        foreach ($inputs as $input_text) {
            if (!is_string($input_text) || trim($input_text) === '') {
                continue;
            }

            $single_payload = [
                'model' => $model,
                'prompt' => trim($input_text),
            ];
            $single_result = $this->post_json('/api/embeddings', $single_payload, $api_params, self::DEFAULT_TIMEOUT_SECONDS, 'embeddings');
            if (is_wp_error($single_result)) {
                return $single_result;
            }

            $single_vector = self::extract_embedding_vector_from_response($single_result);
            if (!is_array($single_vector)) {
                return new \WP_Error(
                    'ollama_embedding_no_data',
                    __('No embedding data found in Ollama legacy embeddings response.', 'gpt3-ai-content-generator')
                );
            }

            $embeddings[] = $single_vector;
            $prompt_eval_count += isset($single_result['prompt_eval_count']) ? absint($single_result['prompt_eval_count']) : 0;
            $eval_count += isset($single_result['eval_count']) ? absint($single_result['eval_count']) : 0;
            $total_duration += isset($single_result['total_duration']) ? absint($single_result['total_duration']) : 0;
            $load_duration += isset($single_result['load_duration']) ? absint($single_result['load_duration']) : 0;
        }

        if (empty($embeddings)) {
            return new \WP_Error(
                'ollama_embedding_no_data',
                __('No embedding data found in Ollama legacy embeddings response.', 'gpt3-ai-content-generator')
            );
        }

        return [
            'embeddings' => $embeddings,
            'prompt_eval_count' => $prompt_eval_count,
            'eval_count' => $eval_count,
            'total_duration' => $total_duration > 0 ? $total_duration : null,
            'load_duration' => $load_duration > 0 ? $load_duration : null,
        ];
    }

    public function get_models($api_params)
    {
        return $this->get_json('/api/tags', is_array($api_params) ? $api_params : [], self::DEFAULT_TIMEOUT_SECONDS, 'model list');
    }

    /**
     * Fetch detailed metadata for a specific model using /api/show.
     *
     * Supports both `model` and `name` payload keys for broader Ollama version compatibility.
     *
     * @param string $model Model id/name.
     * @param array  $api_params Optional API params (base_url).
     * @param bool   $verbose Include verbose metadata when supported.
     * @return array|\WP_Error
     */
    public function show_model(string $model, array $api_params = [], bool $verbose = true)
    {
        $model = sanitize_text_field($model);
        if ($model === '') {
            return new \WP_Error(
                'missing_ollama_model',
                __('Ollama model name is required for model details lookup.', 'gpt3-ai-content-generator')
            );
        }

        $payload = ['model' => $model];
        if ($verbose) {
            $payload['verbose'] = true;
        }
        $result = $this->post_json('/api/show', $payload, $api_params, self::DEFAULT_TIMEOUT_SECONDS, 'model details');
        if (!is_wp_error($result)) {
            return $result;
        }

        // Compatibility fallback for Ollama variants expecting `name`.
        $fallback_payload = ['name' => $model];
        if ($verbose) {
            $fallback_payload['verbose'] = true;
        }

        $fallback = $this->post_json('/api/show', $fallback_payload, $api_params, self::DEFAULT_TIMEOUT_SECONDS, 'model details');
        return is_wp_error($fallback) ? $result : $fallback;
    }

    /**
     * Request embeddings from Ollama.
     *
     * Tries `/api/embed` first (newer API), then falls back to `/api/embeddings` (legacy).
     *
     * @param string|array $input Embedding input text or list of texts.
     * @param array        $api_params Optional API params (base_url).
     * @param array        $options Required: model. Optional: truncate, keep_alive, options.
     * @return array|\WP_Error
     */
    public function request_embeddings($input, array $api_params = [], array $options = [])
    {
        $model = isset($options['model']) ? sanitize_text_field((string) $options['model']) : '';
        if ($model === '') {
            return new \WP_Error(
                'missing_ollama_embedding_model',
                __('Ollama embedding model is required.', 'gpt3-ai-content-generator')
            );
        }

        $payload = ['model' => $model];
        if (isset($options['truncate'])) {
            $payload['truncate'] = (bool) $options['truncate'];
        }
        if (isset($options['keep_alive'])) {
            $payload['keep_alive'] = $options['keep_alive'];
        }
        if (isset($options['options']) && is_array($options['options'])) {
            $payload['options'] = $options['options'];
        }

        if (is_array($input)) {
            $normalized_inputs = [];
            foreach ($input as $entry) {
                if (!is_string($entry)) {
                    continue;
                }
                $entry = trim($entry);
                if ($entry !== '') {
                    $normalized_inputs[] = $entry;
                }
            }
            if (empty($normalized_inputs)) {
                return new \WP_Error(
                    'invalid_ollama_embedding_input',
                    __('Embedding input array for Ollama is empty.', 'gpt3-ai-content-generator')
                );
            }
            $payload['input'] = $normalized_inputs;
        } elseif (is_string($input) && trim($input) !== '') {
            $payload['input'] = trim($input);
        } else {
            return new \WP_Error(
                'invalid_ollama_embedding_input',
                __('Embedding input for Ollama must be a non-empty string or array of strings.', 'gpt3-ai-content-generator')
            );
        }

        $result = $this->post_json('/api/embed', $payload, $api_params, self::DEFAULT_TIMEOUT_SECONDS, 'embeddings');
        if (!is_wp_error($result)) {
            return $result;
        }

        // Fallback to legacy endpoint.
        $legacy_payload = ['model' => $model];
        if (is_array($payload['input'])) {
            if (count($payload['input']) > 1) {
                // Legacy endpoint commonly supports a single prompt per request.
                return $this->request_embeddings_legacy_batch($payload['input'], $model, $api_params);
            }
            $legacy_payload['prompt'] = (string) $payload['input'][0];
        } else {
            $legacy_payload['prompt'] = (string) $payload['input'];
        }

        $fallback = $this->post_json('/api/embeddings', $legacy_payload, $api_params, self::DEFAULT_TIMEOUT_SECONDS, 'embeddings');
        return is_wp_error($fallback) ? $result : $fallback;
    }

    /**
     * Resolve normalized capability map for a model via /api/show metadata.
     *
     * @param string $model Model id/name.
     * @param array  $api_params Optional API params.
     * @param bool   $verbose Whether to request verbose metadata.
     * @return array|\WP_Error
     */
    public function resolve_model_capabilities(string $model, array $api_params = [], bool $verbose = true)
    {

        $show_response = $this->show_model($model, $api_params, $verbose);
        if (is_wp_error($show_response)) {
            return $show_response;
        }

        return AIPKit_Ollama_Capability_Resolver::resolve_from_show_response($show_response, $model);
    }

    public function chat($payload)
    {
        $api_params = [];
        $request_payload = is_array($payload) ? $payload : [];
        if (isset($request_payload['base_url'])) {
            $api_params['base_url'] = (string) $request_payload['base_url'];
            unset($request_payload['base_url']);
        }

        return $this->post_json('/api/chat', $request_payload, $api_params, self::DEFAULT_TIMEOUT_SECONDS, 'chat');
    }
}

/**
 * Capability-driven classification for Ollama model sync.
 */
class AIPKit_Ollama_Model_Sync_Classifier
{
    private const DEFAULT_OLLAMA_BASE_URL = 'http://localhost:11434';
    private const CAPABILITY_CACHE_INDEX_OPTION = 'aipkit_ollama_capability_cache_index';
    private const CAPABILITY_CACHE_TRANSIENT_PREFIX = 'aipkit_ollama_cap_';

    /**
     * Register classifier hooks.
     *
     * @return void
     */
    public static function register_hooks(): void
    {
        add_filter(
            'aipkit_ollama_sync_models_classification',
            [self::class, 'classify_models'],
            10,
            3
        );
    }

    /**
     * Build a capability map fallback from model id/name when /api/show is unavailable.
     *
     * @param array<string, mixed> $model_row Synced model row.
     * @return array<string, bool>
     */
    private static function build_fallback_capabilities(array $model_row): array
    {

        $capabilities = class_exists(AIPKit_Ollama_Capability_Resolver::class)
            ? AIPKit_Ollama_Capability_Resolver::get_capability_map()
            : [
                'chat' => true,
                'stream' => true,
                'completion' => true,
                'text_generation' => true,
                'vision' => false,
                'image_input' => false,
                'embeddings' => false,
            ];

        $model_id = AIPKit_Ollama_Model_Utils::extract_model_id($model_row);
        $model_name = isset($model_row['name']) ? sanitize_text_field((string) $model_row['name']) : '';
        $haystack = trim($model_id . ' ' . $model_name);

        if (AIPKit_Ollama_Model_Utils::has_embedding_hint($haystack)) {
            $capabilities['embeddings'] = true;
            $capabilities['chat'] = false;
            $capabilities['stream'] = false;
            $capabilities['completion'] = false;
            $capabilities['text_generation'] = false;
        }

        if (AIPKit_Ollama_Model_Utils::has_vision_hint($haystack)) {
            $capabilities['vision'] = true;
            $capabilities['image_input'] = true;
        }

        return $capabilities;
    }

    /**
     * Resolve normalized base URL scope used for capability cache partitioning.
     *
     * @param array<string, mixed> $api_params
     * @return string
     */
    private static function resolve_base_url_scope(array $api_params): string
    {
        $raw_base_url = $api_params['base_url'] ?? get_option('aipkit_ollama_base_url', self::DEFAULT_OLLAMA_BASE_URL);
        $base_url = is_string($raw_base_url) ? trim($raw_base_url) : '';
        if ($base_url === '') {
            $base_url = self::DEFAULT_OLLAMA_BASE_URL;
        }

        $normalized = strtolower(rtrim($base_url, '/'));
        if ($normalized === '') {
            $normalized = self::DEFAULT_OLLAMA_BASE_URL;
        }

        $filtered = apply_filters('aipkit_ollama_capabilities_cache_scope', $normalized, $api_params);
        if (!is_string($filtered) || trim($filtered) === '') {
            return $normalized;
        }

        return strtolower(trim($filtered));
    }

    /**
     * Resolve capability cache TTL in seconds.
     *
     * @return int
     */
    private static function get_capability_cache_ttl(): int
    {
        $default_ttl = defined('HOUR_IN_SECONDS')
            ? 12 * HOUR_IN_SECONDS
            : 43200;

        $ttl = (int) apply_filters('aipkit_ollama_capabilities_cache_ttl', $default_ttl);
        return max(0, $ttl);
    }

    /**
     * Build scoped transient key for model capability cache.
     *
     * @param string $base_url_scope
     * @param string $model_id
     * @return string
     */
    private static function build_capability_cache_key(string $base_url_scope, string $model_id): string
    {
        $hash = md5(strtolower(trim($base_url_scope)) . '|' . strtolower(trim($model_id)));
        return self::CAPABILITY_CACHE_TRANSIENT_PREFIX . $hash;
    }

    /**
     * Build scope id for index option.
     *
     * @param string $base_url_scope
     * @return string
     */
    private static function build_scope_id(string $base_url_scope): string
    {
        return md5(strtolower(trim($base_url_scope)));
    }

    /**
     * Normalize capability cache key list.
     *
     * @param mixed $keys
     * @return array<int, string>
     */
    private static function normalize_cache_keys($keys): array
    {
        if (!is_array($keys)) {
            return [];
        }

        $normalized = [];
        foreach ($keys as $key) {
            if (!is_string($key)) {
                continue;
            }
            $key = sanitize_key($key);
            if ($key !== '' && strpos($key, self::CAPABILITY_CACHE_TRANSIENT_PREFIX) === 0) {
                $normalized[] = $key;
            }
        }

        return array_values(array_unique($normalized));
    }

    /**
     * Read capability cache index option.
     *
     * @return array<string, mixed>
     */
    private static function get_capability_cache_index(): array
    {
        $index = get_option(self::CAPABILITY_CACHE_INDEX_OPTION, []);
        return is_array($index) ? $index : [];
    }

    /**
     * Return cached capability map for a key.
     *
     * @param string $cache_key
     * @return array<string, bool>|null
     */
    private static function get_cached_capabilities(string $cache_key): ?array
    {
        $cached = get_transient($cache_key);
        if (!is_array($cached)) {
            return null;
        }

        $normalized = [];
        foreach ($cached as $capability => $supported) {
            if (!is_string($capability)) {
                continue;
            }
            $normalized[sanitize_key($capability)] = (bool) $supported;
        }

        return empty($normalized) ? null : $normalized;
    }

    /**
     * Persist capability map into cache.
     *
     * @param string $cache_key
     * @param array<string, bool> $capabilities
     * @param int $ttl_seconds
     * @return void
     */
    private static function set_cached_capabilities(string $cache_key, array $capabilities, int $ttl_seconds): void
    {
        if ($ttl_seconds <= 0) {
            return;
        }

        set_transient($cache_key, $capabilities, $ttl_seconds);
    }

    /**
     * Sync capability cache index for a base-url scope and clear stale transients.
     *
     * @param string $base_url_scope
     * @param array<int, string> $active_cache_keys
     * @return int Number of invalidated stale transient keys.
     */
    private static function sync_scope_cache_index(string $base_url_scope, array $active_cache_keys): int
    {
        $scope_id = self::build_scope_id($base_url_scope);
        $active_cache_keys = self::normalize_cache_keys($active_cache_keys);

        $index = self::get_capability_cache_index();
        $scope_row = isset($index[$scope_id]) && is_array($index[$scope_id])
            ? $index[$scope_id]
            : [];
        $existing_cache_keys = self::normalize_cache_keys($scope_row['keys'] ?? []);

        $stale_cache_keys = array_values(array_diff($existing_cache_keys, $active_cache_keys));
        foreach ($stale_cache_keys as $stale_cache_key) {
            delete_transient($stale_cache_key);
        }

        $next_scope_row = [
            'base_url' => $base_url_scope,
            'keys' => $active_cache_keys,
        ];

        $index_changed = false;
        if (empty($active_cache_keys)) {
            if (isset($index[$scope_id])) {
                unset($index[$scope_id]);
                $index_changed = true;
            }
        } elseif (!isset($index[$scope_id]) || $index[$scope_id] !== $next_scope_row) {
            $index[$scope_id] = $next_scope_row;
            $index_changed = true;
        }

        if (!empty($stale_cache_keys) || $index_changed) {
            update_option(self::CAPABILITY_CACHE_INDEX_OPTION, $index, 'no');
        }

        return count($stale_cache_keys);
    }

    /**
     * Remove all capability cache keys for a base-url scope.
     *
     * @param string $base_url_scope
     * @return int Number of invalidated keys.
     */
    private static function clear_scope_cache(string $base_url_scope): int
    {
        $scope_id = self::build_scope_id($base_url_scope);
        $index = self::get_capability_cache_index();
        if (!isset($index[$scope_id]) || !is_array($index[$scope_id])) {
            return 0;
        }

        $existing_cache_keys = self::normalize_cache_keys($index[$scope_id]['keys'] ?? []);
        foreach ($existing_cache_keys as $cache_key) {
            delete_transient($cache_key);
        }

        unset($index[$scope_id]);
        update_option(self::CAPABILITY_CACHE_INDEX_OPTION, $index, 'no');

        return count($existing_cache_keys);
    }

    /**
     * Classify synced Ollama models with capability metadata from /api/show.
     *
     * @param mixed $current_value Existing filter value.
     * @param mixed $models Raw synced model rows from /api/tags mapping.
     * @param mixed $api_params API params (base_url).
     * @return array<string, mixed>|mixed
     */
    public static function classify_models($current_value, $models, $api_params)
    {
        if (!is_array($models)) {
            return $current_value;
        }

        $api = new AIPKit_Ollama_API();
        $resolved_api_params = is_array($api_params) ? $api_params : [];

        $all_models = [];
        $chat_models = [];
        $embedding_models = [];
        $vision_models = [];
        $model_details_failures = [];

        $capability_cache_ttl = self::get_capability_cache_ttl();
        $capability_cache_enabled = $capability_cache_ttl > 0;
        $cache_scope = self::resolve_base_url_scope($resolved_api_params);
        $seen_cache_keys = [];
        $cache_stats = [
            'enabled' => $capability_cache_enabled,
            'ttl_seconds' => $capability_cache_ttl,
            'hits' => 0,
            'misses' => 0,
            'writes' => 0,
            'invalidated' => 0,
        ];

        foreach ($models as $model_row_raw) {
            if (!is_array($model_row_raw)) {
                continue;
            }

            $model_row = $model_row_raw;
            $model_id = sanitize_text_field((string) ($model_row['id'] ?? ($model_row['name'] ?? '')));
            if ($model_id === '') {
                continue;
            }

            $model_row['id'] = $model_id;
            if (empty($model_row['name'])) {
                $model_row['name'] = $model_id;
            }

            $cache_key = self::build_capability_cache_key($cache_scope, $model_id);
            $seen_cache_keys[] = $cache_key;

            $capabilities = null;
            if ($capability_cache_enabled) {
                $cached_capabilities = self::get_cached_capabilities($cache_key);
                if (is_array($cached_capabilities)) {
                    $capabilities = $cached_capabilities;
                    $cache_stats['hits']++;
                }
            }

            if (!is_array($capabilities)) {
                $cache_stats['misses']++;
                $capabilities_result = $api->resolve_model_capabilities($model_id, $resolved_api_params, true);
                if (is_wp_error($capabilities_result)) {
                    $model_details_failures[] = [
                        'id' => $model_id,
                        'message' => $capabilities_result->get_error_message(),
                    ];
                    $capabilities = self::build_fallback_capabilities($model_row);
                } else {
                    $capabilities = $capabilities_result;
                    if ($capability_cache_enabled) {
                        self::set_cached_capabilities($cache_key, $capabilities, $capability_cache_ttl);
                        $cache_stats['writes']++;
                    }
                }
            }

            $model_row['capabilities'] = $capabilities;
            $all_models[] = $model_row;

            if (!empty($capabilities['embeddings'])) {
                $embedding_models[] = $model_row;
            }
            if (!empty($capabilities['vision']) || !empty($capabilities['image_input'])) {
                $vision_models[] = $model_row;
            }
            if (!empty($capabilities['chat']) || !empty($capabilities['text_generation']) || !empty($capabilities['completion'])) {
                $chat_models[] = $model_row;
            }
        }

        // Safety fallback: if capability parsing yielded no chat set, preserve all non-embedding-only models.
        if (empty($chat_models) && !empty($all_models)) {
            foreach ($all_models as $model_row) {
                $caps = is_array($model_row['capabilities'] ?? null) ? $model_row['capabilities'] : [];
                $is_embedding_only = !empty($caps['embeddings'])
                    && empty($caps['chat'])
                    && empty($caps['text_generation'])
                    && empty($caps['completion']);
                if (!$is_embedding_only) {
                    $chat_models[] = $model_row;
                }
            }
        }

        $sort_by_name = static function (array &$rows): void {
            usort(
                $rows,
                static fn(array $left, array $right): int => strcasecmp(
                    (string) ($left['name'] ?? $left['id'] ?? ''),
                    (string) ($right['name'] ?? $right['id'] ?? '')
                )
            );
        };

        $sort_by_name($all_models);
        $sort_by_name($chat_models);
        $sort_by_name($embedding_models);
        $sort_by_name($vision_models);

        if ($capability_cache_enabled) {
            $cache_stats['invalidated'] = self::sync_scope_cache_index($cache_scope, $seen_cache_keys);
        } else {
            $cache_stats['invalidated'] = self::clear_scope_cache($cache_scope);
        }

        $option_updates = [
            'aipkit_ollama_embedding_model_list' => array_values($embedding_models),
            'aipkit_ollama_vision_model_list' => array_values($vision_models),
            'aipkit_ollama_model_capability_list' => array_values($all_models),
        ];

        return [
            'all_models' => array_values($all_models),
            'chat_models' => array_values($chat_models),
            'embedding_models' => array_values($embedding_models),
            'vision_models' => array_values($vision_models),
            'model_details_failures' => array_values($model_details_failures),
            'cache_stats' => $cache_stats,
            'option_updates' => $option_updates,
        ];
    }
}

/**
 * Paid-only Ollama integration for provider allowlist bridges.
 */
class AIPKit_Ollama_Provider_Gating_Integration
{
    /**
     * Register provider allowlist hooks.
     *
     * @return void
     */
    public static function register_hooks(): void
    {
        add_filter('aipkit_main_provider_allowlist', [self::class, 'filter_main_provider_allowlist']);
        add_filter('aipkit_sync_provider_allowlist', [self::class, 'filter_sync_provider_allowlist']);
        add_filter('aipkit_recommended_model_supported_providers', [self::class, 'filter_recommended_model_supported_providers']);
        add_filter('aipkit_recommended_model_fallback_providers', [self::class, 'filter_recommended_model_fallback_providers']);
    }

    /**
     * Ensure Ollama is available in main provider allowlist on Pro.
     *
     * @param mixed $providers Current allowlist.
     * @return array<int, string>
     */
    public static function filter_main_provider_allowlist($providers): array
    {
        return self::append_ollama($providers);
    }

    /**
     * Ensure Ollama sync endpoint is available on Pro.
     *
     * @param mixed $providers Current sync allowlist.
     * @return array<int, string>
     */
    public static function filter_sync_provider_allowlist($providers): array
    {
        return self::append_ollama($providers);
    }

    /**
     * Ensure Ollama supports recommended-model payload generation on Pro.
     *
     * @param mixed $providers Current provider list.
     * @return array<int, string>
     */
    public static function filter_recommended_model_supported_providers($providers): array
    {
        return self::append_ollama($providers);
    }

    /**
     * Ensure Ollama can use recommended fallback rows when recommended map is empty.
     *
     * @param mixed $providers Current provider list.
     * @return array<int, string>
     */
    public static function filter_recommended_model_fallback_providers($providers): array
    {
        return self::append_ollama($providers);
    }

    /**
     * Append Ollama to a provider list if not already present.
     *
     * @param mixed $providers
     * @return array<int, string>
     */
    private static function append_ollama($providers): array
    {
        $normalized = is_array($providers) ? $providers : [];
        $normalized = array_values(array_filter(array_map(
            static function ($provider) {
                return sanitize_text_field((string) $provider);
            },
            $normalized
        )));

        if (!in_array('Ollama', $normalized, true)) {
            $normalized[] = 'Ollama';
        }

        return $normalized;
    }
}

/**
 * Paid-only Ollama integration hooks for embedding provider paths.
 */
class AIPKit_Ollama_Embedding_Integration
{
    /**
     * Register embedding integration hooks.
     *
     * @return void
     */
    public static function register_hooks(): void
    {
        add_filter('aipkit_embedding_provider_map', [self::class, 'filter_embedding_provider_map'], 10, 2);
        add_filter('aipkit_embedding_models_by_provider', [self::class, 'filter_embedding_models_by_provider'], 10, 2);
        add_filter('aipkit_embedding_requires_api_key', [self::class, 'filter_embedding_requires_api_key'], 10, 6);
        add_filter('aipkit_embedding_options', [self::class, 'filter_embedding_options'], 10, 5);
    }

    /**
     * Add Ollama to normalized embedding provider map.
     *
     * @param mixed $provider_map
     * @param mixed $context
     * @return array<string, string>
     */
    public static function filter_embedding_provider_map($provider_map, $context = ''): array
    {
        $normalized = [];
        if (is_array($provider_map)) {
            foreach ($provider_map as $key => $value) {
                if (!is_string($key) || !is_string($value)) {
                    continue;
                }
                $normalized[sanitize_key($key)] = sanitize_text_field($value);
            }
        }

        if (empty($normalized)) {
            $normalized = [
                'openai' => 'OpenAI',
                'google' => 'Google',
                'azure' => 'Azure',
                'openrouter' => 'OpenRouter',
            ];
        }

        $normalized['ollama'] = 'Ollama';
        return $normalized;
    }

    /**
     * Inject Ollama embedding-capable models into UI/provider model maps.
     *
     * @param mixed $models_by_provider
     * @param mixed $context
     * @return array<string, array<int, array{id:string,name:string}>>
     */
    public static function filter_embedding_models_by_provider($models_by_provider, $context = ''): array
    {
        $normalized = [];
        if (is_array($models_by_provider)) {
            foreach ($models_by_provider as $provider_key => $models) {
                if (!is_string($provider_key)) {
                    continue;
                }
                $provider_key = sanitize_key($provider_key);
                if ($provider_key === '') {
                    continue;
                }
                $normalized[$provider_key] = self::normalize_model_rows($models);
            }
        }

        $normalized['ollama'] = self::get_embedding_model_rows();
        return $normalized;
    }

    /**
     * Ollama embedding calls do not require API key.
     *
     * @param mixed $requires_api_key
     * @param mixed $provider
     * @return bool
     */
    public static function filter_embedding_requires_api_key(
        $requires_api_key,
        $provider,
        $api_params = [],
        $embedding_options = [],
        $input = null,
        $provider_data = []
    ): bool {
        return self::is_ollama_provider((string) $provider) ? false : (bool) $requires_api_key;
    }

    /**
     * Resolve fallback Ollama embedding model when missing/invalid.
     *
     * @param mixed $embedding_options
     * @param mixed $provider
     * @return array<string, mixed>
     */
    public static function filter_embedding_options(
        $embedding_options,
        $provider,
        $api_params = [],
        $input = null,
        $provider_data = []
    ): array {
        if (!self::is_ollama_provider((string) $provider)) {
            return is_array($embedding_options) ? $embedding_options : [];
        }

        $options = is_array($embedding_options) ? $embedding_options : [];
        $requested_model = isset($options['model']) ? sanitize_text_field((string) $options['model']) : '';
        $resolved_model = self::resolve_embedding_model($requested_model);
        if ($resolved_model !== '') {
            $options['model'] = $resolved_model;
        }

        return $options;
    }

    /**
     * Determine if provider value matches Ollama.
     *
     * @param string $provider
     * @return bool
     */
    private static function is_ollama_provider(string $provider): bool
    {
        return strtolower(trim($provider)) === 'ollama';
    }

    /**
     * Resolve best embedding model for Ollama from stored metadata.
     *
     * @param string $requested_model
     * @return string
     */
    private static function resolve_embedding_model(string $requested_model): string
    {
        $requested_model = sanitize_text_field($requested_model);
        $embedding_candidates = self::get_embedding_capable_model_ids();

        if ($requested_model !== '') {
            foreach ($embedding_candidates as $candidate) {
                if (strcasecmp($candidate, $requested_model) === 0) {
                    return $candidate;
                }
            }

            // If there are known candidates and selected model is not embedding-capable, fallback.
            if (!empty($embedding_candidates)) {
                return $embedding_candidates[0];
            }

            // No capability metadata available yet; preserve requested model as a best effort.
            return $requested_model;
        }

        if (!empty($embedding_candidates)) {
            return $embedding_candidates[0];
        }

        $fallback = '';
        $all_model_rows = class_exists('\WPAICG\AIPKit_Providers')
            ? \WPAICG\AIPKit_Providers::get_ollama_models()
            : [];
        if (is_array($all_model_rows)) {
            foreach ($all_model_rows as $model_row) {
                $model_id = AIPKit_Ollama_Model_Utils::extract_model_id($model_row);
                if ($model_id !== '' && AIPKit_Ollama_Model_Utils::has_embedding_hint($model_id)) {
                    $fallback = $model_id;
                    break;
                }
            }
        }

        /**
         * Last-mile override for resolved Ollama embedding model.
         *
         * @param string $fallback
         * @param string $requested_model
         * @param array<int, string> $embedding_candidates
         */
        $resolved = apply_filters(
            'aipkit_ollama_embedding_model_fallback',
            $fallback,
            $requested_model,
            $embedding_candidates
        );

        return is_string($resolved) ? sanitize_text_field($resolved) : $fallback;
    }

    /**
     * Collect deduplicated embedding-capable model ids from stored options.
     *
     * @return array<int, string>
     */
    private static function get_embedding_capable_model_ids(): array
    {
        $model_ids = [];
        $seen = [];
        $append = static function (string $model_id) use (&$model_ids, &$seen): void {
            $model_id = sanitize_text_field($model_id);
            if ($model_id === '') {
                return;
            }
            $lookup = strtolower($model_id);
            if (isset($seen[$lookup])) {
                return;
            }
            $seen[$lookup] = true;
            $model_ids[] = $model_id;
        };

        $embedding_rows = class_exists('\WPAICG\AIPKit_Providers')
            ? \WPAICG\AIPKit_Providers::get_ollama_embedding_models()
            : [];
        if (is_array($embedding_rows)) {
            foreach ($embedding_rows as $row) {
                $id = AIPKit_Ollama_Model_Utils::extract_model_id($row);
                if ($id !== '') {
                    $append($id);
                }
            }
        }

        $capability_rows = class_exists('\WPAICG\AIPKit_Providers')
            ? \WPAICG\AIPKit_Providers::get_ollama_capability_models()
            : [];
        if (is_array($capability_rows)) {
            foreach ($capability_rows as $row) {
                if (!is_array($row)) {
                    continue;
                }
                $id = AIPKit_Ollama_Model_Utils::extract_model_id($row);
                if ($id === '') {
                    continue;
                }
                $caps = isset($row['capabilities']) && is_array($row['capabilities']) ? $row['capabilities'] : [];
                if (!empty($caps['embeddings']) || AIPKit_Ollama_Model_Utils::has_embedding_hint($id)) {
                    $append($id);
                }
            }
        }

        return $model_ids;
    }

    /**
     * Normalize mixed model rows to `[id, name]` entries.
     *
     * @param mixed $models
     * @return array<int, array{id:string,name:string}>
     */
    private static function normalize_model_rows($models): array
    {
        if (
            class_exists('\WPAICG\AIPKit_Providers')
            && method_exists('\WPAICG\AIPKit_Providers', 'normalize_embedding_model_rows')
        ) {
            return \WPAICG\AIPKit_Providers::normalize_embedding_model_rows($models);
        }

        return [];
    }

    /**
     * Return Ollama embedding-capable model rows for UI/provider model maps.
     *
     * @return array<int, array{id:string,name:string}>
     */
    private static function get_embedding_model_rows(): array
    {
        $stored_rows = class_exists('\WPAICG\AIPKit_Providers')
            ? \WPAICG\AIPKit_Providers::get_ollama_embedding_models()
            : [];
        $normalized_rows = self::normalize_model_rows($stored_rows);
        if (!empty($normalized_rows)) {
            return $normalized_rows;
        }

        $fallback_rows = [];
        foreach (self::get_embedding_capable_model_ids() as $model_id) {
            $model_id = sanitize_text_field($model_id);
            if ($model_id === '') {
                continue;
            }
            $fallback_rows[] = [
                'id' => $model_id,
                'name' => $model_id,
            ];
        }

        return $fallback_rows;
    }
}

/**
 * Paid-only Ollama integration for frontend image-upload gating.
 */
class AIPKit_Ollama_Upload_Gate_Integration
{
    /**
     * Register upload gate hooks.
     *
     * @return void
     */
    public static function register_hooks(): void
    {
        add_filter(
            'aipkit_chat_image_upload_model_supported',
            [self::class, 'filter_image_upload_model_supported'],
            10,
            2
        );
    }

    /**
     * Enable image upload for Ollama only when selected model is vision-capable.
     *
     * @param mixed $is_supported Current gate decision.
     * @param mixed $context Gate context payload from frontend feature manager.
     * @return bool
     */
    public static function filter_image_upload_model_supported($is_supported, $context): bool
    {
        $current_decision = (bool) $is_supported;
        if (!is_array($context)) {
            return $current_decision;
        }

        $provider = isset($context['provider']) ? sanitize_text_field((string) $context['provider']) : '';
        if (strtolower($provider) !== 'ollama') {
            return $current_decision;
        }

        $model_id = isset($context['model']) ? sanitize_text_field((string) $context['model']) : '';
        if ($model_id === '') {
            return false;
        }

        return self::is_vision_capable_model($model_id);
    }

    /**
     * Resolve whether a model is vision-capable from persisted Ollama sync metadata.
     *
     * @param string $model_id
     * @return bool
     */
    private static function is_vision_capable_model(string $model_id): bool
    {
        $lookup = strtolower(trim($model_id));
        if ($lookup === '') {
            return false;
        }

        $capability_rows = class_exists('\WPAICG\AIPKit_Providers')
            ? \WPAICG\AIPKit_Providers::get_ollama_capability_models()
            : [];
        if (is_array($capability_rows)) {
            foreach ($capability_rows as $row) {
                if (!is_array($row)) {
                    continue;
                }

                $row_model_id = AIPKit_Ollama_Model_Utils::extract_model_id($row);
                if ($row_model_id === '' || strtolower($row_model_id) !== $lookup) {
                    continue;
                }

                $capabilities = isset($row['capabilities']) && is_array($row['capabilities'])
                    ? $row['capabilities']
                    : [];

                return AIPKit_Ollama_Model_Utils::is_vision_capable($capabilities);
            }
        }

        $vision_rows = class_exists('\WPAICG\AIPKit_Providers')
            ? \WPAICG\AIPKit_Providers::get_ollama_vision_models()
            : [];
        if (is_array($vision_rows)) {
            foreach ($vision_rows as $row) {
                $row_model_id = AIPKit_Ollama_Model_Utils::extract_model_id($row);
                if ($row_model_id !== '' && strtolower($row_model_id) === $lookup) {
                    return true;
                }
            }
        }

        return false;
    }
}

/**
 * Paid-only Ollama integration hooks for chat image-input capability checks.
 */
class AIPKit_Ollama_Vision_Integration
{
    /**
     * Register vision integration hooks.
     *
     * @return void
     */
    public static function register_hooks(): void
    {
        add_filter(
            'aipkit_chat_image_input_validation_error',
            [self::class, 'validate_chat_image_input_support'],
            10,
            6
        );
    }

    /**
     * Validate Ollama image input compatibility based on synced capability metadata.
     *
     * @param mixed $validation_error Existing validation error from earlier filters.
     * @param mixed $image_inputs Normalized image inputs payload.
     * @param mixed $provider Selected provider.
     * @param mixed $model Selected model id.
     * @param mixed $bot_settings Bot settings.
     * @param mixed $flow Request flow identifier (stream/non_stream).
     * @return mixed WP_Error on validation failure, otherwise original value.
     */
    public static function validate_chat_image_input_support(
        $validation_error,
        $image_inputs,
        $provider,
        $model,
        $bot_settings = [],
        $flow = 'non_stream'
    ) {
        if (is_wp_error($validation_error)) {
            return $validation_error;
        }

        if (!self::is_ollama_provider((string) $provider)) {
            return $validation_error;
        }

        if (!is_array($image_inputs) || empty($image_inputs)) {
            return $validation_error;
        }

        $model_id = AIPKit_Ollama_Model_Utils::normalize_model_id($model);
        $flow_key = sanitize_key((string) $flow);
        if ($model_id === '') {
            return new WP_Error(
                'ollama_model_missing_for_image_input',
                __('Ollama image analysis requires a selected model.', 'gpt3-ai-content-generator'),
                [
                    'status' => 400,
                    'provider' => 'Ollama',
                    'flow' => $flow_key,
                ]
            );
        }

        $capability_row = self::find_capability_row($model_id);
        if (is_array($capability_row)) {
            $capabilities = isset($capability_row['capabilities']) && is_array($capability_row['capabilities'])
                ? $capability_row['capabilities']
                : [];

            if (AIPKit_Ollama_Model_Utils::is_vision_capable($capabilities)) {
                return $validation_error;
            }

            return new WP_Error(
                'ollama_model_not_vision_capable',
                __(
                    'Selected Ollama model does not support image analysis. Choose a vision-capable Ollama model and sync models if needed.',
                    'gpt3-ai-content-generator'
                ),
                [
                    'status' => 400,
                    'provider' => 'Ollama',
                    'model' => $model_id,
                    'flow' => $flow_key,
                ]
            );
        }

        $vision_models = class_exists('\WPAICG\AIPKit_Providers')
            ? \WPAICG\AIPKit_Providers::get_ollama_vision_models()
            : [];
        if (self::is_model_in_list($model_id, $vision_models)) {
            return $validation_error;
        }

        if (self::infer_vision_capability_from_model_name($model_id)) {
            return $validation_error;
        }

        return new WP_Error(
            'ollama_model_capabilities_unknown',
            __(
                'Unable to confirm image support for the selected Ollama model. Please sync Ollama models and try again.',
                'gpt3-ai-content-generator'
            ),
            [
                'status' => 400,
                'provider' => 'Ollama',
                'model' => $model_id,
                'flow' => $flow_key,
            ]
        );
    }

    /**
     * Determine whether provider is Ollama.
     *
     * @param string $provider
     * @return bool
     */
    private static function is_ollama_provider(string $provider): bool
    {
        return strtolower(trim($provider)) === 'ollama';
    }

    /**
     * Find capability row for a model from persisted metadata option.
     *
     * @param string $model_id
     * @return array<string, mixed>|null
     */
    private static function find_capability_row(string $model_id): ?array
    {
        $capability_rows = class_exists('\WPAICG\AIPKit_Providers')
            ? \WPAICG\AIPKit_Providers::get_ollama_capability_models()
            : [];
        if (!is_array($capability_rows) || empty($capability_rows)) {
            return null;
        }

        $lookup = strtolower($model_id);
        foreach ($capability_rows as $row) {
            if (!is_array($row)) {
                continue;
            }

            $row_id = AIPKit_Ollama_Model_Utils::extract_model_id($row);
            if ($row_id === '') {
                continue;
            }

            if (strtolower($row_id) === $lookup) {
                return $row;
            }
        }

        return null;
    }

    /**
     * Check if model exists in an option list row set.
     *
     * @param string $model_id
     * @param mixed $rows
     * @return bool
     */
    private static function is_model_in_list(string $model_id, $rows): bool
    {
        if (!is_array($rows) || $model_id === '') {
            return false;
        }

        $lookup = strtolower($model_id);
        foreach ($rows as $row) {
            $row_id = AIPKit_Ollama_Model_Utils::extract_model_id($row);
            if ($row_id !== '' && strtolower($row_id) === $lookup) {
                return true;
            }
        }

        return false;
    }

    /**
     * Fallback capability inference from model id naming patterns.
     *
     * @param string $model_id
     * @return bool
     */
    private static function infer_vision_capability_from_model_name(string $model_id): bool
    {
        if ($model_id === '') {
            return false;
        }


        $inferred = AIPKit_Ollama_Capability_Resolver::resolve_from_show_response([], $model_id);
        return AIPKit_Ollama_Model_Utils::is_vision_capable(is_array($inferred) ? $inferred : []);
    }
}

namespace WPAICG\Core\Providers;

use WPAICG\Addons\Ollama\AIPKit_Ollama_API;
use WPAICG\Core\Providers\Traits\ChatCompletionsPayloadTrait;
use WP_Error;

/**
 * Ollama provider strategy (Pro)
 * - No API key required
 * - Chat payload standardized using ChatCompletionsPayloadTrait
 */
class AIPKit_Ollama_Strategy extends BaseProviderStrategy
{
    use ChatCompletionsPayloadTrait; // Standardize messages/instructions mapping

    /** @var AIPKit_Ollama_API */
    private $api;

    public function __construct()
    {
        $this->api = new AIPKit_Ollama_API();
    }

    /**
     * Extract plain text content from a message content payload.
     *
     * @param mixed $content
     * @return string
     */
    private static function normalize_user_text_content($content): string
    {
        if (is_string($content)) {
            return $content;
        }

        if (!is_array($content)) {
            return '';
        }

        foreach ($content as $part) {
            if (!is_array($part)) {
                continue;
            }
            $part_type = isset($part['type']) ? strtolower((string) $part['type']) : '';
            if (
                ($part_type === 'text' || $part_type === 'input_text')
                && isset($part['text'])
                && is_string($part['text'])
            ) {
                return $part['text'];
            }
        }

        return '';
    }

    /**
     * Normalize image inputs into Ollama-compatible base64 image array.
     *
     * @param mixed $image_inputs
     * @return array<int, string>
     */
    private static function normalize_ollama_images($image_inputs): array
    {
        if (!is_array($image_inputs)) {
            return [];
        }

        $images = [];
        foreach ($image_inputs as $image_input) {
            if (!is_array($image_input)) {
                continue;
            }

            $base64_data = isset($image_input['base64']) ? trim((string) $image_input['base64']) : '';
            if ($base64_data === '') {
                continue;
            }

            if (strncmp($base64_data, 'data:', strlen('data:')) === 0) {
                $parts = explode('base64,', $base64_data, 2);
                if (count($parts) === 2) {
                    $base64_data = $parts[1];
                }
            }

            $base64_data = preg_replace('/\s+/', '', $base64_data);
            if (!is_string($base64_data) || $base64_data === '') {
                continue;
            }

            $images[] = $base64_data;
        }

        return $images;
    }

    /**
     * Normalize Ollama token metadata into the shared plugin usage shape.
     *
     * @param array<string, mixed> $response
     * @return array<string, mixed>|null
     */
    private static function normalize_ollama_usage(array $response): ?array
    {
        if (
            !isset($response['prompt_eval_count'])
            && !isset($response['eval_count'])
            && !isset($response['total_duration'])
            && !isset($response['load_duration'])
        ) {
            return null;
        }

        $input_tokens = (int) ($response['prompt_eval_count'] ?? 0);
        $output_tokens = (int) ($response['eval_count'] ?? 0);

        return [
            'input_tokens' => $input_tokens,
            'output_tokens' => $output_tokens,
            'total_tokens' => $input_tokens + $output_tokens,
            'prompt_tokens' => $input_tokens,
            'completion_tokens' => $output_tokens,
            'provider_raw' => [
                'prompt_eval_count' => $input_tokens,
                'eval_count' => $output_tokens,
                'total_duration' => isset($response['total_duration']) ? (int) $response['total_duration'] : null,
                'load_duration' => isset($response['load_duration']) ? (int) $response['load_duration'] : null,
                'prompt_eval_duration' => isset($response['prompt_eval_duration']) ? (int) $response['prompt_eval_duration'] : null,
                'eval_duration' => isset($response['eval_duration']) ? (int) $response['eval_duration'] : null,
            ],
        ];
    }

    /**
     * Sanitize generic reasoning effort values for Ollama's `think` parameter.
     *
     * @param mixed $value
     * @return string
     */
    private static function sanitize_ollama_think_effort($value): string
    {
        if (!is_string($value)) {
            return '';
        }

        $normalized = strtolower(trim($value));
        if ($normalized === 'xhigh') {
            return 'high';
        }

        return in_array($normalized, ['none', 'low', 'medium', 'high'], true)
            ? $normalized
            : '';
    }

    /**
     * GPT-OSS models require string think levels instead of boolean flags.
     *
     * @param string $model
     * @return bool
     */
    private static function model_requires_think_levels(string $model): bool
    {
        return strpos(strtolower($model), 'gpt-oss') !== false;
    }

    /**
     * Resolve the outgoing Ollama `think` payload value.
     *
     * Accepts either an explicit `think` value in ai_params or the plugin's
     * normalized `reasoning.effort` payload.
     *
     * @param array<string, mixed> $ai_params
     * @param string $model
     * @return bool|string|null
     */
    private static function resolve_ollama_think_value(array $ai_params, string $model)
    {
        if (array_key_exists('think', $ai_params)) {
            $explicit = $ai_params['think'];
            if (is_bool($explicit)) {
                return $explicit;
            }
            if (is_string($explicit)) {
                $normalized = self::sanitize_ollama_think_effort($explicit);
                if ($normalized !== '') {
                    return self::model_requires_think_levels($model)
                        ? ($normalized === 'none' ? false : $normalized)
                        : ($normalized !== 'none');
                }
            }
        }

        $reasoning = isset($ai_params['reasoning']) && is_array($ai_params['reasoning'])
            ? $ai_params['reasoning']
            : [];
        $effort = self::sanitize_ollama_think_effort($reasoning['effort'] ?? '');
        if ($effort === '' || $effort === 'none') {
            return null;
        }

        return self::model_requires_think_levels($model) ? $effort : true;
    }

    /**
     * Attach image_inputs to the latest user message as Ollama `images`.
     *
     * If the latest message is not from the user (e.g. image-only turn), append
     * a new user message with empty text content and the image payload.
     *
     * @param mixed $messages
     * @param mixed $image_inputs
     * @return array<int, array<string, mixed>>
     */
    private static function attach_image_inputs_to_messages($messages, $image_inputs): array
    {
        $normalized_images = self::normalize_ollama_images($image_inputs);
        if (empty($normalized_images)) {
            return is_array($messages) ? $messages : [];
        }

        $normalized_messages = is_array($messages) ? array_values($messages) : [];
        $target_index = array_key_last($normalized_messages);

        if (
            $target_index === null
            || !isset($normalized_messages[$target_index])
            || !is_array($normalized_messages[$target_index])
            || (($normalized_messages[$target_index]['role'] ?? '') !== 'user')
        ) {
            $normalized_messages[] = [
                'role' => 'user',
                'content' => '',
            ];
            $target_index = array_key_last($normalized_messages);
        }

        if ($target_index === null || !isset($normalized_messages[$target_index]) || !is_array($normalized_messages[$target_index])) {
            return $normalized_messages;
        }

        $existing_content = $normalized_messages[$target_index]['content'] ?? '';
        $normalized_messages[$target_index]['role'] = 'user';
        $normalized_messages[$target_index]['content'] = self::normalize_user_text_content($existing_content);
        $normalized_messages[$target_index]['images'] = $normalized_images;

        return $normalized_messages;
    }

    /**
     * @return string|\WP_Error
     */
    public function build_api_url(string $operation, array $params)
    {
        $base_url = !empty($params['base_url']) ? rtrim($params['base_url'], '/') : rtrim(get_option('aipkit_ollama_base_url', 'http://localhost:11434'), '/');

        switch ($operation) {
            case 'chat':
            case 'stream':
                return $base_url . '/api/chat'; // Same endpoint for streaming
            case 'models':
                return $base_url . '/api/tags';
            case 'embeddings':
                return $base_url . '/api/embeddings';
            default:
                return new WP_Error('unsupported_operation', 'This operation is not supported by the Ollama provider.');
        }
    }

    public function get_api_headers(string $api_key, string $operation): array
    {
        $headers = [
            'Content-Type' => 'application/json',
        ];
        // Ollama streams JSON lines; Accept can stay JSON
        $headers['Accept'] = ($operation === 'stream') ? 'application/json' : 'application/json';
        return $headers;
    }

    public function format_chat_payload(string $user_message, string $instructions, array $history, array $ai_params, string $model): array
    {
        // Start from standardized Chat Completions-style payload
        $payload = $this->format_chat_completions_payload($instructions, $history, $user_message, $ai_params, $model, true);
        $payload['messages'] = self::attach_image_inputs_to_messages(
            $payload['messages'] ?? [],
            $ai_params['image_inputs'] ?? null
        );

        // Move OpenAI-style params into Ollama options and rename as needed
        $options = [];
        if (isset($payload['temperature'])) {
            $options['temperature'] = (float) $payload['temperature'];
            unset($payload['temperature']);
        }
        if (isset($payload['top_p'])) {
            $options['top_p'] = (float) $payload['top_p'];
            unset($payload['top_p']);
        }
        if (isset($payload['max_tokens'])) {
            $options['num_predict'] = (int) $payload['max_tokens'];
            unset($payload['max_tokens']);
        }
        // Optional: top_k if provided via ai_params
        if (isset($ai_params['top_k'])) {
            $options['top_k'] = (int) $ai_params['top_k'];
        }
        if (!empty($options)) {
            $payload['options'] = $options;
        }

        $think = self::resolve_ollama_think_value($ai_params, $model);
        if ($think !== null) {
            $payload['think'] = $think;
        }

        // Ollama uses stream=false for standard calls
        $payload['stream'] = false;
        return $payload;
    }

    /**
     * @return mixed[]|\WP_Error
     */
    public function parse_chat_response(array $decoded_response, array $request_data)
    {
        if (isset($decoded_response['error'])) {
            return new WP_Error('ollama_api_error', $decoded_response['error']);
        }

        if (!isset($decoded_response['message']['content'])) {
            return new WP_Error('ollama_response_format_error', 'Unexpected response format from Ollama API.');
        }

        $usage = self::normalize_ollama_usage($decoded_response);

        return [
            'content' => (string) ($decoded_response['message']['content'] ?? ''),
            'usage'   => $usage,
        ];
    }

    public function parse_error_response($response_body, int $status_code): string
    {
        if (is_array($response_body) && isset($response_body['error'])) {
            return (string) $response_body['error'];
        }
        if (is_string($response_body)) {
            $decoded = json_decode($response_body, true);
            if (json_last_error() === JSON_ERROR_NONE && isset($decoded['error'])) {
                return (string) $decoded['error'];
            }
        }
        return 'Ollama API error: Unexpected response format.';
    }

    /**
     * @return mixed[]|\WP_Error
     */
    public function get_models(array $api_params = [])
    {
        $models = $this->api->get_models($api_params);

        if (is_wp_error($models)) {
            return $models;
        }

        if (isset($models['models']) && is_array($models['models'])) {
            return $this->format_model_list($models['models'], 'name', 'name');
        }

        return new WP_Error('ollama_model_format_error', 'Unexpected model format from Ollama API.');
    }

    /**
     * Extract embedding vectors from mixed Ollama response shapes.
     *
     * @param array<string, mixed> $response
     * @return array<int, array<int, float>>
     */
    private static function extract_embedding_vectors(array $response): array
    {
        $vectors = [];

        if (isset($response['embeddings']) && is_array($response['embeddings'])) {
            foreach ($response['embeddings'] as $entry) {
                $candidate = null;
                if (is_array($entry) && isset($entry['embedding'])) {
                    $candidate = AIPKit_Ollama_API::normalize_embedding_vector($entry['embedding']);
                } else {
                    $candidate = AIPKit_Ollama_API::normalize_embedding_vector($entry);
                }
                if (is_array($candidate)) {
                    $vectors[] = $candidate;
                }
            }
        }

        if (empty($vectors) && isset($response['embedding']) && is_array($response['embedding'])) {
            $candidate = AIPKit_Ollama_API::normalize_embedding_vector($response['embedding']);
            if (is_array($candidate)) {
                $vectors[] = $candidate;
            }
        }

        if (empty($vectors) && isset($response['data']) && is_array($response['data'])) {
            foreach ($response['data'] as $entry) {
                if (!is_array($entry) || !isset($entry['embedding'])) {
                    continue;
                }
                $candidate = AIPKit_Ollama_API::normalize_embedding_vector($entry['embedding']);
                if (is_array($candidate)) {
                    $vectors[] = $candidate;
                }
            }
        }

        return $vectors;
    }

    /**
     * Extract usage metadata from Ollama embedding response when available.
     *
     * @param array<string, mixed> $response
     * @return array<string, mixed>|null
     */
    private static function extract_embedding_usage(array $response): ?array
    {
        $input_tokens = isset($response['prompt_eval_count']) ? absint($response['prompt_eval_count']) : null;
        $completion_tokens = isset($response['eval_count']) ? absint($response['eval_count']) : null;

        if ($input_tokens === null && $completion_tokens === null) {
            return null;
        }

        $total_tokens = ($input_tokens ?? 0) + ($completion_tokens ?? 0);
        return [
            'input_tokens' => (int) ($input_tokens ?? 0),
            'total_tokens' => (int) $total_tokens,
            'provider_raw' => [
                'prompt_eval_count' => (int) ($input_tokens ?? 0),
                'eval_count' => (int) ($completion_tokens ?? 0),
                'total_duration' => isset($response['total_duration']) ? (int) $response['total_duration'] : null,
                'load_duration' => isset($response['load_duration']) ? (int) $response['load_duration'] : null,
            ],
        ];
    }

    /**
     * @return mixed[]|\WP_Error
     */
    public function generate_embeddings($input, array $api_params, array $options = [])
    {
        $model = isset($options['model']) ? sanitize_text_field((string) $options['model']) : '';
        if ($model === '') {
            return new WP_Error(
                'missing_ollama_embedding_model',
                __('Ollama embedding model ID is required.', 'gpt3-ai-content-generator')
            );
        }

        if (is_string($input)) {
            $input = trim($input);
            if ($input === '') {
                return new WP_Error(
                    'invalid_ollama_embedding_input',
                    __('Embedding input for Ollama cannot be empty.', 'gpt3-ai-content-generator')
                );
            }
        } elseif (is_array($input)) {
            $normalized_inputs = [];
            foreach ($input as $entry) {
                if (!is_string($entry)) {
                    continue;
                }
                $entry = trim($entry);
                if ($entry !== '') {
                    $normalized_inputs[] = $entry;
                }
            }
            if (empty($normalized_inputs)) {
                return new WP_Error(
                    'invalid_ollama_embedding_input',
                    __('Embedding input array for Ollama is empty.', 'gpt3-ai-content-generator')
                );
            }
            $input = $normalized_inputs;
        } else {
            return new WP_Error(
                'invalid_ollama_embedding_input',
                __('Embedding input for Ollama must be a string or array of strings.', 'gpt3-ai-content-generator')
            );
        }

        $expected_count = is_array($input) ? count($input) : 1;

        $request_options = ['model' => $model];
        if (array_key_exists('truncate', $options)) {
            $request_options['truncate'] = (bool) $options['truncate'];
        }
        if (array_key_exists('keep_alive', $options)) {
            $request_options['keep_alive'] = $options['keep_alive'];
        }
        if (isset($options['options']) && is_array($options['options'])) {
            $request_options['options'] = $options['options'];
        }

        $result = $this->api->request_embeddings($input, $api_params, $request_options);
        if (is_wp_error($result)) {
            return $result;
        }

        if (isset($result['error']) && is_string($result['error']) && trim($result['error']) !== '') {
            return new WP_Error(
                'ollama_embedding_api_error',
                sanitize_text_field($result['error'])
            );
        }

        $embeddings = self::extract_embedding_vectors($result);
        if (empty($embeddings)) {
            return new WP_Error(
                'ollama_embedding_no_data',
                __('No embedding data found in Ollama response.', 'gpt3-ai-content-generator')
            );
        }
        if (count($embeddings) !== $expected_count) {
            return new WP_Error(
                'ollama_embedding_count_mismatch',
                sprintf(
                    /* translators: 1: expected embedding count, 2: received embedding count */
                    __('Ollama returned %2$d embedding vectors for %1$d inputs.', 'gpt3-ai-content-generator'),
                    $expected_count,
                    count($embeddings)
                )
            );
        }

        return [
            'embeddings' => $embeddings,
            'usage' => self::extract_embedding_usage($result),
        ];
    }

    public function build_sse_payload(array $messages, $system_instruction, array $ai_params, string $model): array
    {
        // Use standardized formatter to normalize message structure, then enable stream
        $payload = $this->format_sse_chat_completions_payload($messages, (string)$system_instruction, $ai_params, $model, true, false);
        $payload['messages'] = self::attach_image_inputs_to_messages(
            $payload['messages'] ?? [],
            $ai_params['image_inputs'] ?? null
        );

        // Map OpenAI-style params into Ollama options
        $options = [];
        if (isset($payload['temperature'])) {
            $options['temperature'] = (float) $payload['temperature'];
            unset($payload['temperature']);
        }
        if (isset($payload['top_p'])) {
            $options['top_p'] = (float) $payload['top_p'];
            unset($payload['top_p']);
        }
        if (isset($payload['max_tokens'])) {
            $options['num_predict'] = (int) $payload['max_tokens'];
            unset($payload['max_tokens']);
        }
        if (isset($ai_params['top_k'])) {
            $options['top_k'] = (int) $ai_params['top_k'];
        }
        if (!empty($options)) {
            $payload['options'] = $options;
        }

        $think = self::resolve_ollama_think_value($ai_params, $model);
        if ($think !== null) {
            $payload['think'] = $think;
        }

        $payload['stream'] = true; // Explicit
        return $payload;
    }

    public function parse_sse_chunk(string $sse_chunk, string &$current_buffer): array
    {
        // Ollama sends JSON lines (NDJSON), not classic SSE events
        $current_buffer .= $sse_chunk;
        $lines = explode("\n", $current_buffer);
        $current_buffer = array_pop($lines); // keep last partial in buffer

        $result = [
            'delta'      => null,
            'usage'      => null,
            'is_error'   => false,
            'is_warning' => false,
            'is_done'    => false,
        ];

        foreach ($lines as $line) {
            $line = trim($line);
            if ($line === '') { continue; }

            $data = json_decode($line, true);
            if (json_last_error() !== JSON_ERROR_NONE) { continue; }

            if (isset($data['error'])) {
                $result['is_error'] = true;
                $result['delta'] = (string) $data['error'];
                continue;
            }

            if (isset($data['message']['content']) && $data['message']['content'] !== '') {
                if ($result['delta'] === null) {
                    $result['delta'] = '';
                }
                $result['delta'] .= (string) $data['message']['content'];
            }

            if (!empty($data['done'])) {
                $result['is_done'] = true;
                $result['usage'] = self::normalize_ollama_usage($data);
            }
        }

        return $result;
    }
}
