<?php
namespace Indeed\Ihc;

if ( ! defined( 'ABSPATH' ) ) { exit; }
class Ihc_GDPR {
    private $pluginName = 'Ultimate Membership Pro';
    private $uid = 0;
    private $group_id = 'ump_plugin_data';

    public function __construct()
    {
        add_action('admin_init', array($this, 'privacyPolicy'));
        add_filter('wp_privacy_personal_data_exporters', array($this, 'registerExport') );
        add_filter('wp_privacy_personal_data_erasers', array($this, 'registerErase') );
    }

    public function privacyPolicy()
    {
        if (!function_exists('wp_add_privacy_policy_content')){
           return;
        }
        $policyText = '';
        wp_add_privacy_policy_content($this->pluginName, $policyText);
    }

    public function registerExport($exporters=array())
    {
        $exporters['ump-exporter'] = array(
            'exporter_friendly_name'	=> $this->pluginName,
            'callback'		          	=> array($this, 'doExport'),
        );
        return $exporters;
    }

    public function registerErase($erasers=array())
    {
        $erasers['ump-eraser'] = array(
        		'eraser_friendly_name'    => $this->pluginName,
        		'callback'                => array($this, 'doErase'),
      	);
      	return $erasers;
    }

    public function doExport($emailAddress='', $page=1)
    {
        $user = get_user_by( 'email', $emailAddress );

        if (!$user) {
            return array(
                'data' => array(),
                'done' => true
            );
        }

        $this->uid = $user->ID;
        $exportData = array();

        // User Metas
        $userMetas = $this->getUserMetas();
        if ($userMetas){
            $exportData[] = array(
                'group_id'    => $this->group_id . '-user-metas',
                'group_label' => 'Ultimate Membership Pro - User Metas',
                'item_id'     => 'ump-user-metas',
                'data'        => $userMetas
            );
        }

        // User Levels
        $userLevels = $this->getUserLevels();
        if ($userLevels){
            $exportData[] = array(
                'group_id'    => $this->group_id . '-user-levels',
                'group_label' => 'Ultimate Membership Pro - User Memberships',
                'item_id'     => 'ump-user-levels',
                'data'        => $userLevels
            );
        }

        // User Logs
        $userLogs = $this->getUserLogs();
        if ($userLogs){
            $exportData[] = array(
                'group_id'    => $this->group_id . '-user-logs',
                'group_label' => 'Ultimate Membership Pro - User Logs',
                'item_id'     => 'ump-user-logs',
                'data'        => $userLogs
            );
        }

        // Security Login
        $securityLogin = $this->getSecurityLogin();
        if ($securityLogin){
            $exportData[] = array(
                'group_id'    => $this->group_id . '-security-login',
                'group_label' => 'Ultimate Membership Pro - Security Login',
                'item_id'     => 'ump-security-login',
                'data'        => $securityLogin
            );
        }

        // Download Monitor Limit
        $downloadMonitorLimit = $this->getDownloadMonitorLimit();
        if ($downloadMonitorLimit){
            $exportData[] = array(
                'group_id'    => $this->group_id . '-download-monitor',
                'group_label' => 'Ultimate Membership Pro - Download Monitor Limit',
                'item_id'     => 'ump-download-monitor',
                'data'        => $downloadMonitorLimit
            );
        }

        // Cheat Off
        $cheatOff = $this->getCheatOff();
        if ($cheatOff){
            $exportData[] = array(
                'group_id'    => $this->group_id . '-cheat-off',
                'group_label' => 'Ultimate Membership Pro - Cheat Off',
                'item_id'     => 'ump-cheat-off',
                'data'        => $cheatOff
            );
        }

        // Payments
        $payments = $this->getPayments();
        if ($payments){
            $exportData[] = array(
                'group_id'    => $this->group_id,
                'group_label' => 'Ultimate Membership Pro - Payments',
                'item_id'     => 'ump-payments',
                'data'        => $payments
            );
        }

        // User Sites
        $userSites = $this->getUserSites();
        if ($userSites){
            $exportData[] = array(
                'group_id'    => $this->group_id . '-user-sites',
                'group_label' => 'Ultimate Membership Pro - User Sites',
                'item_id'     => 'ump-user-sites',
                'data'        => $userSites
            );
        }

        // Orders
        $orders = $this->getOrders();
        if ($orders){
            $exportData[] = array(
                'group_id'    => $this->group_id . '-orders',
                'group_label' => 'Ultimate Membership - Orders',
                'item_id'     => 'ump-orders',
                'data'        => $orders
            );
        }

        // Order Metas
        $ordersMeta = $this->getOrderMetas();
        if ($ordersMeta){
            $exportData[] = array(
                'group_id'    => $this->group_id . '-order-metas',
                'group_label' => 'Ultimate Membership - Order Meta',
                'item_id'     => 'ump-order-metas',
                'data'        => $ordersMeta
            );
        }

        return array(
            'data' => $exportData,
            'done' => true
        );
    }

    public function doErase($emailAddress='', $page=1)
    {
        $user = get_user_by('email', $emailAddress );
        $this->uid = $user->ID;
        global $wpdb;
        /// usermeta
        $query = $wpdb->prepare( "DELETE FROM {$wpdb->usermeta}
                                      WHERE
                                      user_id=%d
                                      ", $this->uid );
        $query .= " AND (meta_key LIKE '%ihc_%' OR meta_key LIKE '%user_levels%')";
        $wpdb->query( $query );
        /// ihc_user_levels
        $query = $wpdb->prepare( "DELETE FROM {$wpdb->prefix}ihc_user_levels
                                      WHERE user_id=%d;", $this->uid );
        $wpdb->query( $query );
        /// ihc_user_logs
        $query = $wpdb->prepare( "DELETE FROM {$wpdb->prefix}ihc_user_logs
                                    WHERE uid=%d", $this->uid );
        $wpdb->query( $query );
        /// ihc_security_login
        $username = \Ihc_Db::get_username_by_wpuid($this->uid);
        $query = $wpdb->prepare("DELETE FROM {$wpdb->prefix}ihc_security_login
                          WHERE username=%s ;", $username );
        $wpdb->query( $query );
        /// ihc_download_monitor_limit
        $query = $wpdb->prepare( "DELETE FROM {$wpdb->prefix}ihc_download_monitor_limit
                          WHERE uid=%d ;", $this->uid );
        $wpdb->query( $query );
        /// ihc_cheat_off
        $query = $wpdb->prepare( "DELETE FROM {$wpdb->prefix}ihc_cheat_off
                          WHERE uid=%d;", $this->uid );
        $wpdb->query( $query );
        /// ihc_user_sites
        $query = $wpdb->prepare( "DELETE FROM {$wpdb->prefix}ihc_user_sites
                          WHERE uid=%d;", $this->uid );
        $wpdb->query( $query );
        return array(
            'items_removed'  => true,
            'items_retained' => false,
            'messages'       => array( '' ),
            'done'           => true,
  		);
    }

    private function getUserMetas(){
        global $wpdb;
        $query = $wpdb->prepare( "SELECT meta_key, meta_value
                        FROM {$wpdb->usermeta}
                        WHERE
                        (
                          meta_key LIKE '%%ihc_%%'
                          OR
                          meta_key LIKE '%%user_levels%%'
                        )
                        AND
                        user_id=%d ", $this->uid );
        $dataDb = $wpdb->get_results($query);
        if (!$dataDb){
            return false;
        }
        $data = array();
        foreach ($dataDb as $object){
            $data[] = array(
                'name'  => $object->meta_key,
                'value' => $object->meta_value,
            );
        }
        return $data;
    }

    private function getUserLevels(){
        global $wpdb;
        $query = $wpdb->prepare("SELECT level_id, start_time, update_time, expire_time, notification, status
                                    FROM {$wpdb->prefix}ihc_user_levels
                                    WHERE user_id=%d
        ", $this->uid);
        $dataDb = $wpdb->get_results($query);
        if (!$dataDb){
            return false;
        }
        $data = array();
        foreach ($dataDb as $object){
            $data[] = array(
                'name'  => 'Entry',
                'value' => 'Level: ' . $object->level_id . ' (' . \Ihc_Db::get_level_name_by_lid($object->level_id) . ')'
                            . ', Start time: ' . $object->start_time
                            . ', Update time: ' . $object->update_time
                            . ', Expire time: ' . $object->expire_time
                            . ', Notification: ' . $object->notification
                            . ', Status: ' . $object->status,
            );
        }
        return $data;
    }

    private function getUserLogs(){
        global $wpdb;
        $query = $wpdb->prepare("SELECT lid, log_type, log_content, create_date FROM {$wpdb->prefix}ihc_user_logs
                                    WHERE uid=%d ;
        ", $this->uid);
        $dataDb = $wpdb->get_results($query);
        if (!$dataDb){
            return false;
        }
        $data = array();
        foreach ($dataDb as $object){
            $data[] = array(
                'name'  => 'Entry',
                'value' => 'Level: ' . $object->lid . ' (' . \Ihc_Db::get_level_name_by_lid($object->lid) . ')'
                            . ', Log type: ' . $object->log_type
                            . ', Log content: ' . $object->log_content
                            . ', Create date: ' . date('Y-m-d H:i:s', $object->create_date)
            );
        }
        return $data;
    }

    private function getSecurityLogin(){
        global $wpdb;
        $username = \Ihc_Db::get_username_by_wpuid($this->uid);
        $query = $wpdb->prepare( "SELECT ip, log_time, attempts_count, locked
                                      FROM {$wpdb->prefix}ihc_security_login
                                      WHERE username=%s;
                                ", $username );
        $dataDb = $wpdb->get_results($query);
        if (!$dataDb){
            return false;
        }
        $data = array();
        foreach ($dataDb as $object){
            $data[] = array(
                'name'  => 'Entry',
                'value' => 'IP: ' . $object->ip
                            . ', Log time: ' . date('Y-m-d H:i:s', $object->log_time)
                            . ', Attempts count: ' . $object->attempts_count
                            . ', Locked: ' . $object->locked
            );
        }
        return $data;
    }

    private function getDownloadMonitorLimit(){
        global $wpdb;
        $query = $wpdb->prepare("SELECT lid, download_limit
                                    FROM {$wpdb->prefix}ihc_download_monitor_limit
                                    WHERE uid=%d ;
        ", $this->uid );
        $dataDb = $wpdb->get_results($query);
        if (!$dataDb){
            return false;
        }
        $data = array();
        foreach ($dataDb as $object){
            $data[] = array(
                'name'  => 'Entry',
                'value' => 'Level: ' . $object->lid . ' (' . \Ihc_Db::get_level_name_by_lid($object->lid) . ')'
                            . ', Download limit: ' . $object->download_limit
            );
        }
        return $data;
    }

    private function getCheatOff(){
        global $wpdb;
        $query = $wpdb->prepare("SELECT hash
                                    FROM {$wpdb->prefix}ihc_cheat_off
                                    WHERE uid=%d;
        ", $this->uid );
        $dataDb = $wpdb->get_results($query);
        if (!$dataDb){
            return false;
        }
        $data = array();
        foreach ($dataDb as $object){
            $data[] = array(
                'name'  => 'Entry',
                'value' => 'Hash: ' . $object->hash
            );
        }
        return $data;
    }

    private function getPayments(){
        global $wpdb;
        $query = $wpdb->prepare( "SELECT txn_id, payment_data, history, paydate
                                    FROM {$wpdb->prefix}indeed_members_payments
                                    WHERE u_id=%d;
        ", $this->uid );
        $dataDb = $wpdb->get_results($query);
        if (!$dataDb){
            return false;
        }
        $data = array();
        foreach ($dataDb as $object){
            $data[] = array(
                'name'  => 'Entry',
                'value' => 'Transaction ID: ' . $object->txn_id
                            . ', Pay date: ' . $object->paydate
                            . ', Payment data: ' . $object->payment_data
                            . ', Payment history: ' . json_encode(unserialize($object->history))
            );
        }
        return $data;
    }

    private function getUserSites(){
        global $wpdb;
        $query = $wpdb->prepare("SELECT lid, site_id
                                    FROM {$wpdb->prefix}ihc_user_sites
                                    WHERE uid=%d;
        ", $this->uid );
        $dataDb = $wpdb->get_results($query);
        if (!$dataDb){
            return false;
        }
        $data = array();
        foreach ($dataDb as $object){
            $data[] = array(
                'name'  => 'Entry',
                'value' => 'Level: ' . $object->lid . ' (' . \Ihc_Db::get_level_name_by_lid($object->lid) . ')'
                            . ', Site: ' . $object->site_id . ' (' . get_site_url($object->site_id) . ')'
            );
        }
        return $data;
    }

    private function getOrders(){
        global $wpdb;
        $query = $wpdb->prepare( "SELECT lid, amount_type, amount_value, automated_payment, status, create_date
                                    FROM {$wpdb->prefix}ihc_orders
                                    WHERE uid=%d;
        ", $this->uid );
        $dataDb = $wpdb->get_results($query);
        if (!$dataDb){
            return false;
        }
        $data = array();
        foreach ($dataDb as $object){
            $data[] = array(
                'name'  => 'Entry',
                'value' => 'Level: ' . $object->lid . ' (' . \Ihc_Db::get_level_name_by_lid($object->lid) . ')'
                            . ', Amount type: ' . $object->amount_type
                            . ', Amount value: ' . $object->amount_value
                            . ', Automated payment: ' . $object->automated_payment
                            . ', Status: ' . $object->status
                            . ', Create date: ' . $object->create_date
            );
        }
        return $data;
    }

    private function getOrderMetas(){
        global $wpdb;
        $query = $wpdb->prepare( "SELECT a.order_id, a.meta_key, a.meta_value
                                    FROM {$wpdb->prefix}ihc_orders_meta a
                                    INNER JOIN {$wpdb->prefix}ihc_orders b
                                    ON a.order_id=b.id
                                    WHERE b.uid=%d;
        ", $this->uid );
        $dataDb = $wpdb->get_results( $query );
        if (!$dataDb){
            return false;
        }
        $data = array();
        foreach ($dataDb as $object){
            $data[] = array(
                'name'  => 'Entry',
                'value' => 'Order ID: ' . $object->order_id
                            . ', ' . $object->meta_key
                            . ': ' . $object->meta_value
            );
        }
        return $data;
    }
}
