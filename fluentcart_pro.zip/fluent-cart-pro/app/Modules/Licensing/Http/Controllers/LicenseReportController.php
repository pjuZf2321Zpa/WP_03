<?php

namespace FluentCartPro\App\Modules\Licensing\Http\Controllers;

use FluentCart\App\Http\Controllers\Controller;
use FluentCart\App\Services\Report\ReportHelper;
use FluentCart\Framework\Http\Request\Request;
use FluentCartPro\App\Modules\Licensing\Services\LicenseReportService;

class LicenseReportController extends Controller
{
    public function overview(Request $request)
    {
        return LicenseReportService::make()->getOverview($this->params($request));
    }

    public function status(Request $request)
    {
        return LicenseReportService::make()->getStatus($this->params($request));
    }

    public function trend(Request $request)
    {
        return LicenseReportService::make()->getTrend($this->params($request));
    }

    public function products(Request $request)
    {
        return LicenseReportService::make()->getProducts($this->params($request));
    }

    public function versions(Request $request)
    {
        return LicenseReportService::make()->getVersions(absint($request->get('product_id')));
    }

    public function environment(Request $request)
    {
        return LicenseReportService::make()->getEnvironment(absint($request->get('product_id')));
    }

    protected function params(Request $request): array
    {
        return ReportHelper::processParams($request->get('params'));
    }
}
