<?php

namespace MasterStudy\Lms\Pro\addons\google_classrooms\Admin\Http\Controllers;

use MasterStudy\Lms\Http\WpResponseFactory;
use MasterStudy\Lms\Pro\addons\google_classrooms\Admin\Http\Serializers\ClassroomSerializer;
use MasterStudy\Lms\Pro\addons\google_classrooms\Admin\Repositories\ClassroomsRepository;
use MasterStudy\Lms\Validation\Validator;
use WP_REST_Request;
use WP_REST_Response;

final class GetClassroomsController {
	public function __invoke( WP_REST_Request $request ): WP_REST_Response {
		$validator = new Validator(
			$request->get_params(),
			array(
				'per_page'   => 'nullable|integer',
				'page'       => 'nullable|integer',
				'search'     => 'nullable|string',
				'date_range' => 'nullable|string',
				'sort'       => 'nullable|string',
			)
		);

		if ( $validator->fails() ) {
			return WpResponseFactory::validation_failed( $validator->get_errors_array() );
		}

		$repository = new ClassroomsRepository();
		$serializer = new ClassroomSerializer();
		$data       = $repository->get_list( $validator->get_validated() );

		return WpResponseFactory::ok_with_data(
			array(
				'items' => $serializer->collectionToArray( $data['posts'] ),
				'total' => $data['total'],
				'pages' => $data['pages'],
			)
		);
	}
}
