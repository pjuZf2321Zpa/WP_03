<?php if (!defined('ABSPATH')) {
    die('You are not allowed to call this page directly.');
} ?>
<div class="notice notice-info is-dismissible mepr-notice-dismiss-permanently" data-notice="cart_release">
  <p>
    <?php
    printf(
        // Translators: %1$s: open b tag, %2$s: close b tag, %3$s: open docs link, %4$s: close docs link, %5$s: open settings link, %6$s: close settings link.
        esc_html__('%1$sNew: Shopping Cart (Beta).%2$s Stable and ready to use, though we\'re still refining it based on feedback. We haven\'t changed anything on your site — your registration pages work exactly as they do today. %3$sRead the overview%4$s, or turn it on in %5$sSettings → Cart%6$s whenever you\'re ready.', 'memberpress'),
        '<b>',
        '</b>',
        '<a href="' . esc_url(MeprUtils::get_link_url('docs_cart_overview')) . '" target="_blank" rel="noopener noreferrer">',
        '</a>',
        '<a href="' . esc_url(admin_url('admin.php?page=memberpress-options#cart')) . '">',
        '</a>'
    );
    ?>
  </p>
</div>
