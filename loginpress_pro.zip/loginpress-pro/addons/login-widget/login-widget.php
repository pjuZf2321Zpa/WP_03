<?php // phpcs:ignore WordPress.Files.FileName.InvalidClassFileName
/**
 * LoginPress - Login Widget Addon.
 *
 * LoginPress - Login widget is the best Login plugin by <a href="https://wpbrigade.com/">WPBrigade</a> which allows you to login from front end.
 *
 * @package   LoginPress
 * @subpackage Widget
 * @category  Core
 * @author    WPBrigade
 * @since     1.0.0
 * @version   6.2.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Include utility functions.
require_once plugin_dir_path( __FILE__ ) . 'classes/class-loginpress-widget-utilities.php';

// Include LoginPress Login Widget Trait.
require_once plugin_dir_path( __FILE__ ) . 'traits/utils.php';

if ( ! class_exists( 'LoginPress_Login_Widget' ) ) :

	/**
	 * LoginPress Login Widget class.
	 *
	 * @package   LoginPress
	 * @subpackage Widget
	 * @category  Core
	 * @since     1.0.0
	 * @version   6.1.0
	 */
	final class LoginPress_Login_Widget {

		use LoginPress_Login_Widget_Trait;

		/**
		 * Social login settings array.
		 *
		 * @since 1.0.0
		 * @var array Social login settings.
		 */
		public $settings;

		/**
		 * General settings array.
		 *
		 * @since 1.0.0
		 * @var array General plugin settings.
		 */
		public $general_settings;

		/**
		 * Captcha settings array.
		 *
		 * @since 1.0.0
		 * @var array Captcha configuration settings.
		 */
		public $captcha_settings;

		/**
		 * Class constructor.
		 *
		 * @since 1.0.0
		 * @version 6.1.0
		 * @return void
		 */
		public function __construct() {

			if ( LoginPress_Pro::addon_wrapper( 'login-widget' ) ) {
				$this->hooks();
				$this->define_constants();
			}
		}

		/**
		 * Hook into actions and filters.
		 *
		 * @since 3.0.0
		 * @version 6.2.0
		 * @return void
		 */
		public function hooks() {

			add_action( 'init', array( $this, 'social_login' ) );
			add_action( 'wp_enqueue_scripts', array( $this, 'loginpress_widget_script' ) );
			add_action( 'widgets_init', array( $this, 'register_widget' ) );
			add_action( 'admin_enqueue_scripts', array( $this, 'admin_scripts' ) );
			add_action( 'wp_ajax_loginpress_widget_login_process', array( $this, 'loginpress_widget_ajax' ) );
			add_action( 'wp_ajax_nopriv_loginpress_widget_login_process', array( $this, 'loginpress_widget_ajax' ) );
			add_action( 'wp_ajax_nopriv_loginpress_widget_register_process', array( $this, 'loginpress_widget_register_process' ) );
			add_action( 'wp_ajax_nopriv_loginpress_widget_lost_password_process', array( $this, 'loginpress_widget_lost_password_process' ) );
			add_action( 'wp_ajax_loginpress_widget_refresh_math_captcha', array( $this, 'loginpress_widget_refresh_math_captcha' ) );
			add_action( 'wp_ajax_nopriv_loginpress_widget_refresh_math_captcha', array( $this, 'loginpress_widget_refresh_math_captcha' ) );
			$this->settings         = get_option( 'loginpress_social_logins' );
			$this->general_settings = get_option( 'loginpress_setting' );
			$this->captcha_settings = get_option( 'loginpress_captcha_settings' );
		}

		/**
		 * Compatibility of LoginPress - Social Login with Widget Login.
		 *
		 * @since 4.0.0
		 * @version 6.2.0
		 * @return string Social login buttons HTML.
		 */
		public function loginpress_social_login() {

			$redirect_to = site_url() . sanitize_text_field( wp_unslash( $_SERVER['REQUEST_URI'] ) ); // @codingStandardsIgnoreLine.
			$encoded_url        = rawurlencode( $redirect_to );
			$social_login_class = LoginPress_Social::instance();
			if ( ( ! isset( $this->settings['enable_social_login_links']['login'] ) ) && ( ! isset( $this->settings['enable_social_login_links']['register'] ) ) ) {
				return null;
			}

			$button_style   = isset( $this->settings['social_button_styles'] ) ? $this->settings['social_button_styles'] : '';
			$button_text    = $this->settings['social_login_button_label'] ?? 'Login with %provider%';
			$provider_order = isset( $this->settings['provider_order'] ) && ! empty( $this->settings['provider_order'] )
				? ( is_array( $this->settings['provider_order'] )
					? $this->settings['provider_order']
					: json_decode( $this->settings['provider_order'], true ) )
				: array( 'facebook', 'twitter', 'gplus', 'linkedin', 'microsoft', 'apple', 'discord', 'wordpress', 'github', 'amazon', 'pinterest', 'disqus', 'reddit', 'spotify', 'twitch' );

			$html = "<div class='social-networks block " . esc_attr( "loginpress-$button_style" ) . "'>";

				$separator_text = apply_filters( 'loginpress_social_login_separator', __( 'or', 'loginpress-pro' ) );
				$html          .= "<span class='social-sep'><span>" . esc_html( $separator_text ) . '</span></span>';

			foreach ( $provider_order as $provider ) {
				if ( isset( $this->settings[ $provider ] ) && 'on' === $this->settings[ $provider ] && ! empty( $this->settings[ "{$provider}_status" ] ) && 'not verified' !== strtolower( $this->settings[ "{$provider}_status" ] ) ) {
					$client_id_key     = "{$provider}_client_id";
					$client_secret_key = "{$provider}_client_secret";
					$app_id_key        = "{$provider}_app_id";
					$app_secret_key    = "{$provider}_app_secret";

					if ( ( ! empty( $this->settings[ $client_id_key ] ) && ! empty( $this->settings[ $client_secret_key ] ) ) ||
						( ! empty( $this->settings[ $app_id_key ] ) && ! empty( $this->settings[ $app_secret_key ] ) ) ||
						( ! empty( $this->settings[ "{$provider}_oauth_token" ] ) && ! empty( $this->settings[ "{$provider}_token_secret" ] ) ) ||
						( ! empty( $this->settings[ "{$provider}_service_id" ] ) && ! empty( $this->settings[ "{$provider}_key_id" ] ) && ! empty( $this->settings[ "{$provider}_team_id" ] ) && ! empty( $this->settings[ "{$provider}_p_key" ] ) ) ) {

						$button_label_key = "{$provider}_button_label";
						if ( 'gplus' === $provider ) {
							$button_label_key = 'google_button_label';
						}
						// Replace 'gplus' with 'Google'.
						$provider_display_name = ( 'gplus' === $provider ) ? 'Google' : ucfirst( $provider );

						$provider_button_text = ! empty( $this->settings[ $button_label_key ] )
						? $this->settings[ $button_label_key ]
						: ( ! empty( $button_text )
							? str_replace( '%provider%', $provider_display_name, $button_text )
							: esc_html__( 'Login with ', 'loginpress-pro' ) . esc_html( $provider_display_name ) );

						$login_id   = "{$provider}_login";
						$icon_class = ( 'gplus' === $provider ) ? 'icon-google-plus' : "icon-$provider";

						$html .= "<a href='" . esc_url_raw( wp_login_url() . "?lpsl_login_id=$login_id&state=" . base64_encode( "redirect_to=$encoded_url" ) . "&redirect_to=$redirect_to" ) . "' title='" . esc_html( $provider_button_text ) . "' rel='nofollow'>"; // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode
						$html .= "<div class='lpsl-icon-block $icon_class clearfix'>";
						$html .= "<span class='lpsl-login-text'>" . esc_html( $provider_button_text ) . '</span>';
						$html .= $social_login_class->get_provider_icon( $provider ); // Dynamically fetch the provider's icon.
						$html .= '</div></a>';
					}
				}
			}

			$html .= '</div>';
			return $html;
		}

		/**
		 * LoginPress Addon updater.
		 *
		 * @since 1.0.0
		 * @version 6.1.0
		 * @return void
		 */
		public function init_addon_updater() {

			if ( class_exists( 'LoginPress_AddOn_Updater' ) ) {
				$updater = new LoginPress_AddOn_Updater( 2333, __FILE__, $this->version );
			}
		}

		/**
		 * Add social logins.
		 *
		 * @since 3.0.0
		 * @version 6.0.2
		 */
		public function social_login() {

			if ( class_exists( 'LoginPress_Social' ) && true === apply_filters( 'loginpress_social_widget', true ) ) {

				if ( method_exists( 'LoginPress_Social', 'check_social_api_status' ) && true === LoginPress_Social::check_social_api_status() && $this->loginpress_is_widget_present() ) {
					add_filter( 'login_form_bottom', array( $this, 'loginpress_social_login' ), 1 );
				}
			}
		}


		/**
		 * Enqueue widget scripts and styles.
		 *
		 * @since 3.0.0
		 * @version 6.0.2
		 * @return void
		 */
		public function loginpress_widget_script() {

			// Only enqueue if the widget is present on the page.
			if ( ! $this->loginpress_is_widget_present() ) {
				return;
			}

			$attributes = get_option( 'loginpress_block_attributes' );

			// Enqueue LoginPress Widget JS.
			wp_enqueue_script( 'loginpress-login-widget-script', plugins_url( 'assets/js/script.js', __FILE__ ), array( 'jquery' ), LOGINPRESS_PRO_VERSION, false );
			wp_enqueue_script( 'loginpress-pasword-strength-meter', plugins_url( 'js/password-strength-meter.js', LOGINPRESS_ROOT_FILE ), array( 'jquery', 'password-strength-meter' ), LOGINPRESS_VERSION, true );
			wp_enqueue_script( 'password-strength-meter' );
			// Enqueue Styles.
			wp_enqueue_style( 'loginpress-login-widget-style', plugins_url( 'assets/css/style.css', __FILE__ ), '', LOGINPRESS_PRO_VERSION );

			if ( class_exists( 'LoginPress_Social' ) ) {
				wp_enqueue_style( 'font-awesome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css' ); // phpcs:ignore
				if ( ! is_user_logged_in() ) {
					wp_enqueue_style( 'loginpress-social-login', plugins_url( 'social-login/assets/css/login.css', __DIR__ ), array(), LOGINPRESS_PRO_VERSION );
					include LOGINPRESS_SOCIAL_DIR_PATH . 'assets/js/script-login.php';
				}
			}

			$loginpress_widget_option  = get_option( 'widget_loginpress-login-widget' );
			$_loginpress_widget_option = isset( $loginpress_widget_option ) ? $loginpress_widget_option : false;
			if ( $attributes ) {

				// Use block attributes.
				$error_bg_color   = isset( $attributes['errorBgColor'] ) ? $attributes['errorBgColor'] : '#fbb1b7';
				$error_text_color = isset( $attributes['errorTextColor'] ) ? $attributes['errorTextColor'] : '#ae121e';

			} elseif ( $_loginpress_widget_option ) {
				$error_bg_color = isset( $loginpress_widget_option[2]['error_bg_color'] ) ? $loginpress_widget_option[2]['error_bg_color'] : '#fbb1b7';

				$error_text_color = isset( $loginpress_widget_option[2]['error_text_color'] ) ? $loginpress_widget_option[2]['error_text_color'] : '#ae121e';
			}

				$_loginpress_widget_error_bg_clr = "
                .loginpress-login-widget .loginpress_widget_error{
                  background-color: {$error_bg_color};
                  color: {$error_text_color};
                }";
				wp_add_inline_style( 'loginpress-login-widget-style', $_loginpress_widget_error_bg_clr );

			// Get widget parameters from trait utility method.
			$loginpress_widget_params = $this->loginpress_get_widget_params();

			wp_localize_script( 'loginpress-login-widget-script', 'loginpress_widget_params', $loginpress_widget_params );
		}

		/**
		 * Register LoginPress Widget.
		 *
		 * @since 3.0.0
		 * @version 6.1.0
		 * @return void
		 */
		public function register_widget() {
			include_once LOGINPRESS_WIDGET_DIR_PATH . 'classes/class-loginpress-widget.php';
			include_once LOGINPRESS_WIDGET_DIR_PATH . 'classes/class-loginpress-render-block.php';
			register_widget( 'LoginPress_Widget' );
		}

		/**
		 * Define LoginPress Widget Constants.
		 *
		 * @since 3.0.0
		 * @version 6.1.0
		 * @return void
		 */
		private function define_constants() {
			LoginPress_Pro_Init::define( 'LOGINPRESS_WIDGET_DIR_PATH', plugin_dir_path( __FILE__ ) );
		}

		/**
		 * Load JS or CSS files at admin side and enqueue them.
		 *
		 * @param string $hook The current admin page hook.
		 * @since 3.0.0
		 * @version 6.1.0
		 * @return void
		 */
		public function admin_scripts( $hook ) { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter.Found
			if ( ! is_admin() ) {
				wp_enqueue_style( 'loginpress_widget_style', plugins_url( 'assets/css/style.css', __FILE__ ), array(), LOGINPRESS_PRO_VERSION );
				wp_enqueue_script( 'loginpress_widget_js', plugins_url( 'assets/js/script.js', __FILE__ ), array( 'jquery' ), LOGINPRESS_PRO_VERSION, false );
			}
		}

		/**
		 * Retrieve the redirect URL w.r.t Login Redirect Add-On.
		 *
		 * @param int    $user_id User ID.
		 * @param string $option meta key name.
		 * @since 3.0.0
		 *
		 * @return string $redirect_url meta value of the user w.r.t key name.
		 */
		private function loginpress_redirect_url( $user_id, $option ) {
			return LoginPress_Widget_Utilities::get_user_redirect_url( $user_id, $option );
		}

		/**
		 * AJAX: new math captcha HTML for LoginPress widget/block after submit.
		 *
		 * @return void
		 * @since 6.2.0
		 */
		public function loginpress_widget_refresh_math_captcha() {
			check_ajax_referer( 'loginpress_login_widget_security', 'nonce' );

			if ( ! class_exists( 'LoginPress_Math_Captcha' ) ) {
				wp_send_json_error( array( 'message' => '' ) );
			}

			$context  = isset( $_POST['context'] ) ? sanitize_key( wp_unslash( $_POST['context'] ) ) : '';
			$settings = get_option( 'loginpress_captcha_settings' );

			if ( ! isset( $settings['enable_captchas'] ) || 'on' !== $settings['enable_captchas'] ) {
				wp_send_json_error( array( 'message' => '' ) );
			}
			if ( ! isset( $settings['captchas_type'] ) || 'type_math' !== $settings['captchas_type'] ) {
				wp_send_json_error( array( 'message' => '' ) );
			}

			$math_key = 'off';
			switch ( $context ) {
				case 'login':
					$math_key = isset( $settings['math_captcha_enable']['login_form'] ) ? $settings['math_captcha_enable']['login_form'] : 'off';
					break;
				case 'register':
					$math_key = isset( $settings['math_captcha_enable']['register_form'] ) ? $settings['math_captcha_enable']['register_form'] : 'off';
					break;
				case 'lost':
					$math_key = isset( $settings['math_captcha_enable']['lostpassword_form'] ) ? $settings['math_captcha_enable']['lostpassword_form'] : 'off';
					break;
				default:
					wp_send_json_error( array( 'message' => '' ) );
			}

			if ( 'off' === $math_key ) {
				wp_send_json_error( array( 'message' => '' ) );
			}

			$html = LoginPress_Math_Captcha::loginpress_math_widget_refresh_fragment( $context );
			if ( '' === $html ) {
				wp_send_json_error( array( 'message' => '' ) );
			}

			wp_send_json_success( array( 'html' => $html ) );
		}

		/**
		 * LoginPress_widget_ajax function.
		 *
		 * @access public
		 * @since 3.0.0
		 * @version 6.1.0
		 * @return void
		 */
		public function loginpress_widget_ajax() {

			check_ajax_referer( 'loginpress_login_widget_security', 'nonce' );

			$data                        = array();
			$data['user_login']          = isset( $_POST['user_login'] ) ? sanitize_text_field( wp_unslash( $_POST['user_login'] ) ) : '';
			$data['user_password']       = isset( $_POST['user_password'] ) ? sanitize_text_field( wp_unslash( $_POST['user_password'] ) ) : '';
			$data['remember']            = isset( $_POST['remember'] ) ? sanitize_text_field( wp_unslash( $_POST['remember'] ) ) : '';
			$redirect_to                 = isset( $_POST['redirect_to'] ) ? esc_url_raw( wp_unslash( $_POST['redirect_to'] ) ) : '';
			$secure_cookie               = null;
			$captcha_response            = isset( $_POST['captcha_response'] ) ? sanitize_text_field( wp_unslash( $_POST['captcha_response'] ) ) : '';
			$math_captcha_raw            = isset( $_POST['math_captcha'] ) ? sanitize_text_field( wp_unslash( $_POST['math_captcha'] ) ) : '';
			$math_captcha_answer         = ! empty( $math_captcha_raw ) ? intval( $math_captcha_raw ) : null;
			$math_captcha_hash           = isset( $_POST['loginpress_math_captcha_hash'] ) ? sanitize_text_field( wp_unslash( $_POST['loginpress_math_captcha_hash'] ) ) : '';
			$loginpress_captcha_settings = $this->captcha_settings;
			$cap_login                   = isset( $loginpress_captcha_settings['captcha_enable']['login_form'] ) ? $loginpress_captcha_settings['captcha_enable']['login_form'] : false;
			$cap_login_cf                = isset( $loginpress_captcha_settings['captcha_enable_cf']['login_form'] ) ? $loginpress_captcha_settings['captcha_enable_cf']['login_form'] : false;
			$captchas_type               = isset( $loginpress_captcha_settings['captchas_type'] ) ? $loginpress_captcha_settings['captchas_type'] : 'type_recaptcha';
			$hcaptcha_login              = isset( $loginpress_captcha_settings['hcaptcha_enable']['login_form'] ) ? $loginpress_captcha_settings['hcaptcha_enable']['login_form'] : 'off';
			$math_login                  = isset( $loginpress_captcha_settings['math_captcha_enable']['login_form'] ) ? $loginpress_captcha_settings['math_captcha_enable']['login_form'] : 'off';
			if ( isset( $loginpress_captcha_settings['enable_captchas'] ) && 'on' === $loginpress_captcha_settings['enable_captchas'] ) {
				if ( ( 'off' !== $hcaptcha_login && 'type_hcaptcha' === $captchas_type ) ||
					( 'off' !== $cap_login && 'type_recaptcha' === $captchas_type ) ||
					( $cap_login_cf && 'type_cloudflare' === $captchas_type ) ||
					( 'off' !== $math_login && 'type_math' === $captchas_type ) ) {
					if ( 'type_math' === $captchas_type && 'off' !== $math_login ) {
						// Validate math captcha - check if field is empty.
						if ( empty( $math_captcha_raw ) && empty( $math_captcha_hash ) ) {
							$response['error'] = __( 'Please verify captcha.', 'loginpress-pro' );
							echo wp_json_encode( $response );
							wp_die();
						}
						// Start session if needed.
						$this->loginpress_start_session();

						$correct_answer = isset( $_SESSION['loginpress_math_widget_login_captcha'] ) ? $_SESSION['loginpress_math_widget_login_captcha'] : null; // @codingStandardsIgnoreLine.
						if ( $math_captcha_hash ) {
							$salt = wp_salt();
							if ( md5( $math_captcha_answer . $salt ) !== $math_captcha_hash ) {
								$response['error'] = __( 'Please provide correct Captcha answer', 'loginpress-pro' );
								echo wp_json_encode( $response );
								wp_die();
							}
						} elseif ( null !== $math_captcha_answer && $math_captcha_answer !== $correct_answer ) {
							$response['error'] = __( 'Please provide correct Captcha answer', 'loginpress-pro' );
							echo wp_json_encode( $response );
							wp_die();
						}
						unset( $_SESSION['loginpress_math_widget_login_captcha'] ); // @codingStandardsIgnoreLine.
					} elseif ( $captcha_response ) {
						if ( $cap_login || $cap_login_cf ) {
							if ( 'type_recaptcha' === $loginpress_captcha_settings['captchas_type'] ) {
								$captcha = new LoginPress_Recaptcha( $this->general_settings, $loginpress_captcha_settings );
								add_filter( 'authenticate', array( $captcha, 'loginpress_recaptcha_auth' ), 99, 3 );
							} elseif ( 'type_hcaptcha' === $loginpress_captcha_settings['captchas_type'] ) {
								$hcaptcha = new LoginPress_Hcaptcha( $loginpress_captcha_settings );
								add_filter( 'authenticate', array( $hcaptcha, 'loginpress_hcaptcha_auth' ), 99, 3 );
							} elseif ( 'type_cloudflare' === $loginpress_captcha_settings['captchas_type'] ) {
								$cf = new LoginPress_Turnstile( $loginpress_captcha_settings );
								add_filter( 'authenticate', array( $cf, 'loginpress_turnstile_auth_widget' ), 99, 4 );
							}
						}
					} else {
						$response['error'] = __( 'Please verify captcha.', 'loginpress-pro' );
						echo wp_json_encode( $response );
						wp_die();
					}
				}
			}
			// If the user wants ssl but the session is not ssl, force a secure cookie.
			if ( ! force_ssl_admin() ) {
				$user = is_email( $data['user_login'] ) ? get_user_by( 'email', $data['user_login'] ) : get_user_by( 'login', sanitize_user( $data['user_login'] ) );

				if ( $user && get_user_option( 'use_ssl', $user->ID ) ) {
					$secure_cookie = true;
					force_ssl_admin( true );
				}
			}

			if ( force_ssl_admin() ) {
				$secure_cookie = true;
			}

			if ( is_null( $secure_cookie ) && force_ssl_admin() ) {
				$secure_cookie = false;
			}

			// Login.
			$user = wp_signon( $data, $secure_cookie );

			// Redirect filter.
			if ( $secure_cookie && strstr( $redirect_to, 'wp-admin' ) ) {
				$redirect_to = str_replace( 'http:', 'https:', $redirect_to );
			}

			/**
			 * Filter login url if Login Redirect addon used. Add separate Login Widget Redirect compatibility.
			 *
			 * @since 1.0.5
			 */
			if ( class_exists( 'LoginPress_Login_Redirect_Main' ) && apply_filters( 'prevent_loginpress_login_widget_redirect', true ) ) {
				$logged_user_id     = $user->data->ID;
				$redirect_to        = $this->loginpress_redirect_url( $logged_user_id, 'loginpress_login_redirects_url' );
				$role_redirects_url = get_option( 'loginpress_redirects_role' );

				if ( empty( $redirect_to ) && ! empty( $role_redirects_url ) ) {
					foreach ( $role_redirects_url as $key => $value ) {
						if ( ! empty( $key ) && ! empty( $user ) ) {
							if ( in_array( $key, $user->roles, true ) ) {
								$redirect_to = $value['login'];
							}
						}
					}
				}
			}

			/**
			 * Add Force password reset compatibility for Login Widget/Block.
			 *
			 * @since 6.0.0
			 * @version 6.1.0
			 */
			if ( class_exists( 'LoginPress_Force_Password_Reset' ) ) {
				if ( defined( 'LOGINPRESS_VERSION' ) && version_compare( LOGINPRESS_VERSION, '6.1.0', '>=' ) ) {
					$redirect_to = LoginPress_Force_Password_Reset::loginpress_user_login_check( $data['user_login'], $user );
				} else {
					// Deprecated way for backward compatibility.
					$force_password_reset = new LoginPress_Force_Password_Reset();
					$redirect_to          = $force_password_reset->loginpress_user_login_check( $data['user_login'], $user );
					if ( empty( $redirect_to ) ) {
						$redirect_to = $_REQUEST['redirect_to'] ?? ''; // phpcs:ignore
					}
				}
			}

			$response = array();

			if ( ! is_wp_error( $user ) ) {

				$response['success']  = 1;
				$response['redirect'] = $redirect_to;
			} else {

				$response['success'] = 0;
				if ( $user->errors ) {

					foreach ( $user->errors as $key => $error ) {

						$response[ $key ] = $error[0];
						break;
					}
				} else {

					$response['error'] = __( 'Please enter your username and password to login.', 'loginpress-pro' );
				}
			}

			echo wp_json_encode( $response );
			wp_die();
		}
	}
endif;

new LoginPress_Login_Widget();
