<?php

namespace MasterStudy\Lms\Pro\addons\assignments\Routing\Swagger;

use MasterStudy\Lms\Routing\Swagger\RequestInterface;
use MasterStudy\Lms\Routing\Swagger\ResponseInterface;
use MasterStudy\Lms\Routing\Swagger\Route;

class GetAdminStudentAssignment extends Route implements RequestInterface, ResponseInterface {
	public function request(): array {
		return array();
	}

	public function response(): array {
		return array(
			'id'         => array(
				'type' => 'integer',
			),
			'title'      => array(
				'type' => 'string',
			),
			'submission' => array(
				'type' => 'object',
			),
			'review'     => array(
				'type' => 'object',
			),
		);
	}

	public function get_summary(): string {
		return 'Get Admin Student Assignment';
	}

	public function get_description(): string {
		return 'Returns one student assignment attempt with review drawer data.';
	}
}
