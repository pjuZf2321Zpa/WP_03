<?php

namespace MasterStudy\Lms\Pro\addons\google_classrooms\Admin\Http\Controllers;

use MasterStudy\Lms\Http\WpResponseFactory;
use MasterStudy\Lms\Pro\addons\google_classrooms\Admin\Repositories\GoogleClassroomsImportRepository;
use MasterStudy\Lms\Validation\Validator;
use RuntimeException;
use WP_REST_Request;
use WP_REST_Response;

final class UploadGoogleClassroomsCredentialsController {
	public function __invoke( WP_REST_Request $request ): WP_REST_Response {
		$validator = new Validator(
			$request->get_file_params(),
			array(
				'file' => 'required',
			)
		);

		if ( $validator->fails() ) {
			return WpResponseFactory::validation_failed( $validator->get_errors_array() );
		}

		try {
			$data = ( new GoogleClassroomsImportRepository() )->upload_credentials( $request->get_file_params()['file'] );

			return WpResponseFactory::ok_with_data( $data );
		} catch ( RuntimeException $e ) {
			return WpResponseFactory::bad_request( $e->getMessage() );
		}
	}
}
