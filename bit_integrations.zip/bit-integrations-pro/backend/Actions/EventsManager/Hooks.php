<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Actions\EventsManager\EventsManagerProHelper;
use BitApps\IntegrationsPro\Config;
use BitApps\IntegrationsPro\Core\Util\Hooks;

Hooks::filter(Config::withFreePrefix('eventsmanager_unregister_user_from_event'), [EventsManagerProHelper::class, 'unregisterUserFromEvent'], 10, 2);
