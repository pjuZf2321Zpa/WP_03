<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Actions\QuizAndSurveyMaster\QuizAndSurveyMasterProHelper;
use BitApps\IntegrationsPro\Config;
use BitApps\IntegrationsPro\Core\Util\Hooks;

Hooks::filter(Config::withFreePrefix('quiz_and_survey_master_create_quiz'), [QuizAndSurveyMasterProHelper::class, 'createQuiz'], 10, 3);
Hooks::filter(Config::withFreePrefix('quiz_and_survey_master_update_quiz_name'), [QuizAndSurveyMasterProHelper::class, 'updateQuizName'], 10, 2);
Hooks::filter(Config::withFreePrefix('quiz_and_survey_master_duplicate_quiz'), [QuizAndSurveyMasterProHelper::class, 'duplicateQuiz'], 10, 3);
Hooks::filter(Config::withFreePrefix('quiz_and_survey_master_delete_quiz'), [QuizAndSurveyMasterProHelper::class, 'deleteQuiz'], 10, 3);
Hooks::filter(Config::withFreePrefix('quiz_and_survey_master_create_question'), [QuizAndSurveyMasterProHelper::class, 'createQuestion'], 10, 4);
Hooks::filter(Config::withFreePrefix('quiz_and_survey_master_update_question'), [QuizAndSurveyMasterProHelper::class, 'updateQuestion'], 10, 4);
Hooks::filter(Config::withFreePrefix('quiz_and_survey_master_delete_question'), [QuizAndSurveyMasterProHelper::class, 'deleteQuestion'], 10, 2);
Hooks::filter(Config::withFreePrefix('quiz_and_survey_master_delete_result'), [QuizAndSurveyMasterProHelper::class, 'deleteResult'], 10, 3);
