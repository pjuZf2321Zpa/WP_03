<?php
/**
 * Template_Builder Class file.
 *
 * Builds the Pro features a SureForms form template declares.
 *
 * @package sureforms-pro.
 * @since 2.13.0
 */

namespace SRFM_Pro\Inc\Extensions;

use SRFM\Inc\Form_Templates;
use SRFM\Inc\Helper;
use SRFM_Pro\Inc\Global_Settings\Advanced_Restriction_Defaults;
use SRFM_Pro\Inc\Traits\Get_Instance;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Turns the Pro feature keys of a free form template into Pro block attributes
 * and form metas, through the free `srfm_form_template_content` and
 * `srfm_form_template_metas` filters.
 *
 * Templates name fields by slug (the `slug` of each template field). Fields get
 * fresh random block_ids on every build, so this class reads the built content,
 * maps each slug to its block_id and writes the metas in the format the Pro
 * feature reads. A declaration that names an unknown field or operator raises
 * `_doing_it_wrong()` and is skipped: nothing broken is ever written.
 *
 * Each feature is built only when the class that owns it is loaded, so a Starter
 * build skips the Pro-tier keys silently (see FEATURE_OWNERS).
 *
 * Declaration reference (all keys optional):
 *
 * `conditions` (Starter) - show or hide fields, written to `_srfm_conditional_logic`:
 *     'conditions' => [
 *         '<target-slug>' => [
 *             'action' => 'show' | 'hide',            // Default 'show'.
 *             'logic'  => [                           // OR groups...
 *                 [                                   // ...of AND conditions.
 *                     [ '<source-slug>', '<operator>', <value> ],
 *                 ],
 *             ],
 *         ],
 *     ]
 *   Operators: Conditional_Logic::get_allowed_operators(), and only those the
 *   editor offers for the source block (e.g. `>` needs a number/nps/slider, `in`
 *   a dropdown/multi-choice). `<value>` is a string, except `in`/`!in` (a list of
 *   option labels) and `between` (`[ min, max ]` or 'min,max'). `null`, `!null`,
 *   `isChecked`, `!isChecked`, `isSelected`, `!isSelected` take no value.
 *   Sources and targets must be fields outside a repeater (top-level, address or register); repeater
 *   children and non-input blocks (upload, password, html, page-break...) can't be
 *   sources. If any condition of a target is invalid, the whole target is skipped.
 *
 * `confirmations` (Starter) - conditional thank-you messages, `_srfm_conditional_confirmation`:
 *     'confirmations' => [
 *         [
 *             'name'    => 'Label shown in the editor',            // Optional.
 *             'message' => '<p>Thanks {form:full-name}</p>',      // Required for success_message.
 *             'type'    => 'success_message' | 'redirect',        // Default success_message.
 *             'url'     => 'https://...',                         // Required for redirect.
 *             'after'   => 'hide_form' | 'reset_form',            // Default hide_form.
 *             'logic'   => '_AND_' | '_OR_',                      // Default _AND_.
 *             'rules'   => [ [ '<slug>', '<operator>', '<value>' ], ... ], // At least one.
 *         ],
 *     ]
 *   Rule operators: _EQUAL_ _NOT_EQUAL_ _GREATER_ _GREATER_OR_EQUAL_ _LESSER_
 *   _LESSER_OR_EQUAL_ _STARTS_WITH_ _ENDS_WITH_ _CONTAINS_ _NOT_CONTAINS_ _REGEX_
 *   _IN_ _NOT_IN_ (`_IN_` values are comma separated). The first matching
 *   confirmation replaces the template's thank-you message.
 *
 * `email_conditions` (Starter) - send a notification only when rules match, `_srfm_email_conditional_meta`:
 *     'email_conditions' => [
 *         'admin' | 'autoresponder' | <notification id> => [
 *             'logic' => '_AND_' | '_OR_',
 *             'rules' => [ [ '<slug>', '<operator>', '<value>' ], ... ],
 *         ],
 *     ]
 *   `admin` is notification 1 and `autoresponder` notification 2 (free builds the
 *   autoresponder only when the template has one and a required email field).
 *   Same rule operators as `confirmations`.
 *
 * `attach_uploads` (Starter) - attach files to the admin notification, `_srfm_email_attach_uploads_meta`:
 *     'attach_uploads' => [ '<upload-slug>', ... ]
 *
 * `restrictions` (Starter) - only the login gate, `_srfm_additional_form_restriction`:
 *     'restrictions' => [ 'login' => true ]
 *     'restrictions' => [ 'login' => [ 'message' => 'Please sign in first.' ] ]
 *   Any other key (password, ip, country, keyword) is refused. Only built on
 *   create: a swap keeps the form's own restrictions.
 *
 * `save_resume` (Pro) - `'save_resume' => true`, `_srfm_save_resume` with Pro's default texts.
 *
 * `survey` (Pro) - `_srfm_survey_meta`:
 *     'survey' => true
 *     'survey' => [ 'show_live_results' => false ]   // Default false: live results replace the thank-you message.
 *
 * `conversational` (Pro) - `_srfm_conversational_form` and the welcome screen in `_srfm_premium_common`:
 *     'conversational' => true
 *     'conversational' => [
 *         'welcome_heading' => '...',   // Optional; Pro's default otherwise.
 *         'welcome_message' => '...',
 *         'start_button'    => '...',
 *         'welcome_screen'  => true,    // Default true.
 *         'progress_bar'    => true,    // Default true.
 *     ]
 *   Skipped when the template has page breaks (the conversational layout drops
 *   page-break blocks, so the steps would silently disappear). On create and
 *   preview it also turns the form's Instant Form page on, the only page the
 *   conversational layout renders on.
 *
 * `quiz` (Business) - `_srfm_quiz_meta`, one question per dropdown / multi-choice field:
 *     'quiz' => true
 *     'quiz' => [
 *         'scoreType'            => 'correct_incorrect' | 'advanced',  // Default correct_incorrect.
 *         'gradingSystem'        => 'default' | 'pass_fail' | 'letter', // Default default.
 *         'passPercent'          => 50,       // Int 0-100.
 *         'resultOutput'         => 'default_confirmation' | 'show_score' | 'full_result', // Default default_confirmation;
 *                                             // the other two replace the thank-you message.
 *         'correctAnswerScore'   => 5,        // Int >= 0 (correct_incorrect).
 *         'inCorrectAnswerScore' => 0,        // Int, may be negative.
 *         'defaultScore'         => 5,        // Int >= 0 (advanced).
 *         'randomizeQuestions'   => false,
 *         'randomizeOptions'     => false,
 *         'letterGrades'         => [ [ 'grade' => 'A', 'percentage' => 90 ], ... ],
 *     ]
 *   Answers come from the fields' options: `isCorrect` (bool) and, for advanced
 *   scoring, `individualScore` (int). In correct_incorrect mode a question without
 *   an `isCorrect` option is left out. Confirmation and email rules can test
 *   `{quiz_score}`, `{quiz_percentage}`, `{quiz_letter_grade}` and `{quiz_pass_fail}`
 *   (`Pass` / `Fail`) in place of a field slug.
 *
 * `partial_entries` (Business) - `_srfm_partial_entries`, capture on with the disclosure shown:
 *     'partial_entries' => true
 *     'partial_entries' => [
 *         'capture_mode' => 'meaningful' | 'contact', // Default meaningful.
 *         'resume'       => false,                    // Resume link.
 *         'reminder'     => false,                    // Reminder email to the visitor.
 *         'email'        => '<email-slug>',           // Default: the first email field outside a repeater.
 *     ]
 *
 * `cpt` (Business) - `_srfm_raw_cpt_meta`, one feed creating a post per submission:
 *     'cpt' => [
 *         'title'          => '<slug>' | 'Text with {form:slug} tags', // Required.
 *         'content'        => '<slug>' | '<p>{form:slug}</p>',
 *         'excerpt'        => '<slug>' | '...',
 *         'featured_image' => '<upload-slug>',
 *         'post_type'      => 'post',     // A public post type of the site, else post.
 *         'status'         => 'pending' | 'draft', // Default pending; never published.
 *         'category'       => '<term-slug>',       // Only an existing category.
 *         'name'           => 'Feed name',
 *     ]
 *   The author is the logged-in submitter (none for guests).
 *
 * `registration` (Business) - `_srfm_user_registration_settings`, creates a subscriber:
 *     'registration' => true
 *     'registration' => [
 *         'email'           => '<email-slug>',    // Default: the first email field outside a repeater (required).
 *         'username'        => '<input-or-email-slug>', // Default: the email field.
 *         'password'        => '<password-slug>', // Default: the first password field.
 *         'first_name'      => '<slug>',
 *         'last_name'       => '<slug>',
 *         'website'         => '<slug>',
 *         'auto_login'      => false,
 *         'send_user_email' => true,
 *     ]
 *   The role is always subscriber. Only built on create: a swap keeps the form's
 *   own registration settings.
 *
 * `entry_limit` (Business) - free's `_srfm_form_restriction` cap and `_srfm_recurring_entry_limit`:
 *     'entry_limit' => [
 *         'max'     => 1,                          // Required int >= 1.
 *         'period'  => 'total' | 'day' | 'week' | 'month' | 'year', // Required.
 *         'enabled' => false,                      // Default false: set up but off.
 *         'message' => 'Limit reached text',
 *     ]
 *   Only built on create: a swap keeps the form's own limit and scheduling.
 *
 * Swap: in the `swap` context every meta in OWNED_METAS that the new template
 * does not build goes back to its empty value. The access settings in
 * KEPT_ON_SWAP (login gate, entry limits and scheduling) are never touched on a
 * swap: they are only built when a form is created. User registration is reset
 * and rebuilt like the other features: it maps the form's fields by slug, so
 * keeping it after the fields change would reject every sign-up.
 *
 * Message metas: the Pro metas that hold a form's messages (conditional
 * thank-you messages, conditional emails, email attachments) are added to free's
 * `srfm_form_template_message_meta_keys`, so they follow the user's choice to
 * also replace the form's emails and messages on a swap.
 *
 * @since 2.13.0
 */
class Template_Builder {
	use Get_Instance;

	/**
	 * Class whose presence means this build includes each feature.
	 *
	 * @since 2.13.0
	 */
	public const FEATURE_OWNERS = [
		'conditions'       => Conditional_Logic::class,
		'confirmations'    => Conditional_Confirmations::class,
		'email_conditions' => Conditional_Emails::class,
		'attach_uploads'   => Attach_Uploads::class,
		'restrictions'     => Additional_Form_Restrictions::class,
		'save_resume'      => 'SRFM_Pro\Inc\Save_Resume\Init',
		'survey'           => 'SRFM_Pro\Inc\Survey\Editor',
		'conversational'   => 'SRFM_Pro\Inc\Conversational_Form',
		'quiz'             => 'SRFM_Pro\Inc\Quiz\Editor',
		'partial_entries'  => 'SRFM_Pro\Inc\Partial_Entries\Init',
		'cpt'              => 'SRFM_Pro\Inc\Custom_Post_Type\Init',
		'registration'     => 'SRFM_Pro\Inc\User_Registration\Init',
		'entry_limit'      => 'SRFM_Pro\Inc\Recurring_Entry_Limit\Init',
	];

	/**
	 * Pro's per-form styling meta. Its `form_theme` picks the active theme;
	 * 'custom' styles the form from this meta's own values.
	 *
	 * @since 2.13.0
	 */
	public const STYLING_META = '_srfm_forms_styling_starter';

	/**
	 * Operators of the rule-based features (confirmations, email conditions).
	 * Mirrors Pro Helper::process_condition().
	 *
	 * @since 2.13.0
	 */
	public const RULE_OPERATORS = [ '_EQUAL_', '_NOT_EQUAL_', '_GREATER_', '_GREATER_OR_EQUAL_', '_LESSER_', '_LESSER_OR_EQUAL_', '_STARTS_WITH_', '_ENDS_WITH_', '_CONTAINS_', '_NOT_CONTAINS_', '_REGEX_', '_IN_', '_NOT_IN_' ];

	/**
	 * Quiz results a confirmation or email rule can test, besides fields.
	 * Resolved by Score_Calculator::resolve_quiz_condition_field().
	 *
	 * @since 2.13.0
	 */
	public const QUIZ_RULE_FIELDS = [ '{quiz_score}', '{quiz_percentage}', '{quiz_letter_grade}', '{quiz_pass_fail}' ];

	/**
	 * Keys of free's `_srfm_forms_styling` that Pro's styling meta carries too
	 * (MIRRORED_FIELDS in the editor), copied over as they are so the editor
	 * opens with the two in sync.
	 *
	 * @since 2.13.0
	 */
	private const MIRRORED_STYLING_KEYS = [
		'bg_color',
		'bg_type',
		'bg_gradient',
		'bg_gradient_type',
		'bg_gradient_color_1',
		'bg_gradient_color_2',
		'bg_gradient_location_1',
		'bg_gradient_location_2',
		'bg_gradient_angle',
		'bg_gradient_overlay_type',
		'bg_image_overlay_color',
		'bg_image',
		'bg_image_attachment',
		'bg_image_repeat',
		'bg_image_size',
		'bg_image_size_custom',
		'bg_image_size_custom_unit',
		'primary_color',
		'text_color',
		'text_color_on_primary',
		'submit_button_alignment',
	];

	/**
	 * Gaps between rows and below labels, in px, on the conversational layout
	 * for each of free's field spacing sizes
	 * (Conversational_Form::cf_spacing_variables(), which applies only while
	 * that page renders).
	 *
	 * @since 2.13.0
	 */
	private const CONVERSATIONAL_GAPS = [
		'small'  => [
			'form_row_gap'    => 20,
			'field_label_gap' => 20,
		],
		'medium' => [
			'form_row_gap'    => 24,
			'field_label_gap' => 24,
		],
		'large'  => [
			'form_row_gap'    => 28,
			'field_label_gap' => 28,
		],
	];

	/**
	 * Pro styling keys set, in px, from free's size variables for the form's
	 * field spacing (Helper::get_css_vars()), so text and the button keep
	 * free's sizes.
	 *
	 * @since 2.13.0
	 */
	private const SIZE_KEYS = [
		'form_row_gap'                => '--srfm-row-gap-between-blocks',
		'field_label_gap'             => '--srfm-input-field-margin-top',
		'field_label_size'            => '--srfm-label-font-size',
		'field_label_line_height'     => '--srfm-label-line-height',
		'field_help_text_size'        => '--srfm-description-font-size',
		'field_help_text_line_height' => '--srfm-description-line-height',
		'button_text_size'            => '--srfm-btn-font-size',
		'button_line_height'          => '--srfm-btn-line-height',
	];

	/**
	 * Method building each feature's metas. Each receives
	 * ( $declaration, $slug_map, $metas, $context, $content ) and returns the metas;
	 * a builder may leave off the trailing arguments it doesn't use.
	 *
	 * @since 2.13.0
	 */
	private const META_BUILDERS = [
		'conditions'       => 'add_conditional_logic',
		'confirmations'    => 'add_confirmations',
		'email_conditions' => 'add_email_conditions',
		'attach_uploads'   => 'add_attach_uploads',
		'restrictions'     => 'add_restrictions',
		'save_resume'      => 'add_save_resume',
		'survey'           => 'add_survey',
		'conversational'   => 'add_conversational',
		'quiz'             => 'add_quiz',
		'partial_entries'  => 'add_partial_entries',
		'cpt'              => 'add_cpt',
		'registration'     => 'add_registration',
		'entry_limit'      => 'add_entry_limit',
	];

	/**
	 * Features whose settings control who can submit the form and when (login
	 * gate, entry limits and scheduling). Restyling a form with "Change
	 * template" must not open a members-only form, so on a swap these are
	 * neither reset nor built: the form keeps its own settings. They are only
	 * built when a form is created.
	 *
	 * User registration is not one of them: its settings point at the form's
	 * fields by slug (`{form:username}`), so after a swap they are reset and
	 * built from the new template's fields, as for any other feature.
	 *
	 * @since 2.13.0
	 */
	private const KEPT_ON_SWAP = [ 'restrictions', 'entry_limit' ];

	/**
	 * Pro metas that hold a form's messages, by the feature that owns them. A
	 * swap only replaces them when the user chooses to also replace the form's
	 * emails and messages (free's `srfm_form_template_message_meta_keys`).
	 *
	 * @since 2.13.0
	 */
	private const MESSAGE_METAS = [
		'confirmations'    => [ '_srfm_conditional_confirmation' ],
		'email_conditions' => [ '_srfm_email_conditional_meta' ],
		'attach_uploads'   => [ '_srfm_email_attach_uploads_meta' ],
	];

	/**
	 * Form metas each feature owns. On a swap, the ones the new template does
	 * not declare go back to their empty value, so no rule of the old template
	 * (pointing at blocks that are gone) survives. `entry_limit` is left out: its
	 * period works on free's `_srfm_form_restriction`, which a swap keeps.
	 *
	 * @since 2.13.0
	 */
	private const OWNED_METAS = [
		'conditions'       => [ '_srfm_conditional_logic' ],
		'confirmations'    => [ '_srfm_conditional_confirmation' ],
		'email_conditions' => [ '_srfm_email_conditional_meta' ],
		'attach_uploads'   => [ '_srfm_email_attach_uploads_meta' ],
		'restrictions'     => [ '_srfm_additional_form_restriction' ],
		'save_resume'      => [ '_srfm_save_resume' ],
		'survey'           => [ '_srfm_survey_meta' ],
		'conversational'   => [ '_srfm_conversational_form' ],
		'quiz'             => [ '_srfm_quiz_meta' ],
		'partial_entries'  => [ '_srfm_partial_entries' ],
		'cpt'              => [ '_srfm_raw_cpt_meta' ],
		'registration'     => [ '_srfm_user_registration_settings' ],
	];

	/**
	 * Quiz settings a template can declare, with the editor's defaults
	 * (QUIZ_DATA in the quiz editor script).
	 *
	 * @since 2.13.0
	 */
	private const QUIZ_DEFAULTS = [
		'scoreType'            => 'correct_incorrect',
		'correctAnswerScore'   => 5,
		'inCorrectAnswerScore' => 0,
		'defaultScore'         => 5,
		'gradingSystem'        => 'default',
		'resultOutput'         => 'default_confirmation',
		'randomizeQuestions'   => false,
		'randomizeOptions'     => false,
		'passPercent'          => 50,
	];

	/**
	 * Blocks the editor never offers as a condition source.
	 * Mirrors `srfm.conditionalLogic.excludeBlocks` in src/conditional-logic/single-condition.js.
	 *
	 * @since 2.13.0
	 */
	private const EXCLUDED_SOURCES = [ 'upload', 'password', 'page-break', 'advanced-heading', 'icon', 'image', 'separator', 'signature', 'register', 'login', 'html' ];

	/**
	 * Operators per editor block type.
	 * Mirrors src/conditional-logic/conditional-logic-options.json.
	 *
	 * @since 2.13.0
	 */
	private const OPERATORS_BY_TYPE = [
		'default'    => [ '==', '!=', 'null', '!null', 'includes', '!includes', 'startWith', 'endWith', 'matchesPattern', 'doesNotMatchPattern' ],
		'text'       => [ '==', '!=', 'null', '!null', 'includes', '!includes', 'startWith', 'endWith', 'matchesPattern', 'doesNotMatchPattern' ],
		'number'     => [ '==', '!=', '>', '>=', '<', '<=', 'between', 'matchesPattern', 'doesNotMatchPattern' ],
		'list'       => [ '==', '!=', 'in', '!in', 'isSelected', '!isSelected', 'matchesPattern', 'doesNotMatchPattern' ],
		'checkbox'   => [ 'isChecked', '!isChecked', 'matchesPattern', 'doesNotMatchPattern' ],
		'datepicker' => [ 'datePickerIs', 'isBefore', 'isOnOrBefore', 'isAfter', 'isOnOrAfter' ],
		'timepicker' => [ 'timePickerIs', 'isBefore', 'isOnOrBefore', 'isAfter', 'isOnOrAfter' ],
		// A slider is a number, or a list when its type is text; the slug map keeps no attributes.
		'slider'     => [ '==', '!=', '>', '>=', '<', '<=', 'between', 'in', '!in', 'isSelected', '!isSelected', 'matchesPattern', 'doesNotMatchPattern' ],
	];

	/**
	 * Operators that take no value.
	 *
	 * @since 2.13.0
	 */
	private const VALUELESS_OPERATORS = [ 'null', '!null', 'isChecked', '!isChecked', 'isSelected', '!isSelected' ];

	/**
	 * Notification ids free's template builder writes.
	 *
	 * @since 2.13.0
	 */
	private const NOTIFICATION_IDS = [
		'admin'         => 1,
		'autoresponder' => 2,
	];

	/**
	 * Style chosen in the preview for the template being applied in the
	 * editor. The swap metas don't carry free's styling, so it is rebuilt
	 * from the template and this style.
	 *
	 * @since 2.13.0
	 * @var array<string, mixed>
	 */
	private static $swap_style = [];

	/**
	 * Constructor.
	 *
	 * @since 2.13.0
	 * @return void
	 */
	public function __construct() {
		add_filter( 'srfm_form_template_content', [ self::class, 'filter_content' ], 10, 2 );
		add_filter( 'srfm_form_template_metas', [ self::class, 'filter_metas' ], 10, 5 );
		add_filter( 'rest_request_before_callbacks', [ self::class, 'remember_swap_style' ], 10, 3 );
		add_filter( 'srfm_form_template_message_meta_keys', [ self::class, 'add_message_meta_keys' ] );
	}

	/**
	 * Add the Pro metas that hold a form's messages to the ones a template swap
	 * only replaces when the user chooses to also replace emails and messages.
	 *
	 * @hooked srfm_form_template_message_meta_keys
	 * @param mixed $keys Meta keys.
	 * @since 2.13.0
	 * @return mixed
	 */
	public static function add_message_meta_keys( $keys ) {
		if ( ! is_array( $keys ) ) {
			return $keys;
		}
		foreach ( self::MESSAGE_METAS as $feature => $meta_keys ) {
			if ( self::is_feature_available( $feature ) ) {
				$keys = array_merge( $keys, $meta_keys );
			}
		}
		return array_values( array_unique( $keys ) );
	}

	/**
	 * Remember the style sent with a request for a template's content (the
	 * editor's "Change template"), for add_styling().
	 *
	 * @hooked rest_request_before_callbacks
	 * @param mixed            $response Response so far, returned unchanged.
	 * @param mixed            $handler  Route handler.
	 * @param \WP_REST_Request $request  Request.
	 * @since 2.13.0
	 * @return mixed
	 */
	public static function remember_swap_style( $response, $handler, $request ) {
		unset( $handler );
		if ( $request instanceof \WP_REST_Request && 1 === preg_match( '#^/sureforms/v1/form-templates/(?!create$|request$|swap$)[a-z0-9-]+$#', $request->get_route() ) ) {
			self::$swap_style = class_exists( Form_Templates::class ) ? Form_Templates::sanitize_style( $request->get_param( 'style' ) ) : [];
		}
		return $response;
	}

	/**
	 * Whether this build includes a template feature.
	 *
	 * @param string $key Template key, such as `conditions`.
	 * @since 2.13.0
	 * @return bool
	 */
	public static function is_feature_available( $key ) {
		$owner     = self::FEATURE_OWNERS[ $key ] ?? '';
		$available = '' !== $owner && class_exists( $owner );

		/**
		 * Filters whether the template builder builds a feature.
		 *
		 * @since 2.13.0
		 * @param bool   $available Whether the class owning the feature is loaded.
		 * @param string $key       Template key, such as `conditions`.
		 */
		return (bool) apply_filters( 'srfm_pro_template_feature_available', $available, $key );
	}

	/**
	 * Map each field slug in block markup to its block.
	 *
	 * @param string $content Block markup.
	 * @since 2.13.0
	 * @return array<string, array{block_id: string, blockName: string, parent: string}> Slug => block. The first block wins a duplicate slug.
	 */
	public static function get_slug_map( $content ) {
		$map = [];
		self::collect_slugs( parse_blocks( $content ), '', $map );
		return $map;
	}

	/**
	 * Set `isConditionalLogic` on the blocks a template's conditions target.
	 *
	 * @hooked srfm_form_template_content
	 * @param string               $content  Block markup.
	 * @param array<string, mixed> $template Template.
	 * @since 2.13.0
	 * @return string
	 */
	public static function filter_content( $content, $template ) {
		if ( ! is_string( $content ) || ! is_array( $template ) || empty( $template['conditions'] ) || ! self::is_feature_available( 'conditions' ) ) {
			return $content;
		}

		$logic = self::build_conditional_logic( $template['conditions'], self::get_slug_map( $content ), false );
		if ( empty( $logic ) ) {
			return $content;
		}

		$targets = [];
		foreach ( $logic as $entry ) {
			$targets[ (string) array_key_first( $entry ) ] = true;
		}

		return self::mark_conditional_targets( $content, $targets );
	}

	/**
	 * Add `"isConditionalLogic":true` to the attributes of the given blocks,
	 * leaving the rest of the markup byte for byte as it was.
	 *
	 * @param string              $content   Block markup.
	 * @param array<string, bool> $block_ids Block ids to mark, as keys.
	 * @since 2.13.0
	 * @return string
	 */
	public static function mark_conditional_targets( $content, $block_ids ) {
		// Block comment opener, as matched by WP_Block_Parser.
		$pattern = '/<!--\s+wp:(?:[a-z][a-z0-9_-]*\/)?[a-z][a-z0-9_-]*\s+(?P<attrs>{(?:(?:[^}]+|}+(?=})|(?!}\s+\/?-->).)*+)?})\s+\/?-->/s';

		$marked = preg_replace_callback(
			$pattern,
			static function ( $match ) use ( $block_ids ) {
				$attrs   = $match['attrs'];
				$decoded = json_decode( $attrs, true );
				if ( ! is_array( $decoded ) || ! is_string( $decoded['block_id'] ?? null ) || ! isset( $block_ids[ $decoded['block_id'] ] ) ) {
					return $match[0];
				}

				if ( ! array_key_exists( 'isConditionalLogic', $decoded ) ) {
					$new_attrs = '{}' === $attrs ? '{"isConditionalLogic":true}' : '{"isConditionalLogic":true,' . substr( $attrs, 1 );
				} elseif ( true === $decoded['isConditionalLogic'] ) {
					return $match[0];
				} else {
					$new_attrs = (string) preg_replace( '/"isConditionalLogic":\s*[^,}]*/', '"isConditionalLogic":true', $attrs, 1 );
				}

				return str_replace( $attrs, $new_attrs, $match[0] );
			},
			$content
		);

		return is_string( $marked ) ? $marked : $content;
	}

	/**
	 * Write the metas of the Pro features a template declares.
	 *
	 * @hooked srfm_form_template_metas
	 * @param array<string, mixed>             $metas    Metas.
	 * @param array<string, mixed>             $template Template.
	 * @param string                           $content  The form's block markup.
	 * @param array<int, array<string, mixed>> $fields   Resolved fields (unused; slugs are read from `$content`).
	 * @param string                           $context  `create`, `swap` or `preview`.
	 * @since 2.13.0
	 * @return array<string, mixed>
	 */
	public static function filter_metas( $metas, $template, $content = '', $fields = [], $context = 'create' ) {
		unset( $fields );
		if ( ! is_array( $metas ) || ! is_array( $template ) ) {
			return $metas;
		}

		$context = in_array( $context, [ 'create', 'swap', 'preview' ], true ) ? $context : 'create';
		if ( 'swap' === $context ) {
			$metas = self::reset_owned_metas( $metas );
		}

		$declared = array_intersect_key( $template, self::META_BUILDERS );
		if ( ! empty( $declared ) ) {
			$content = is_string( $content ) ? $content : '';
			$map     = self::get_slug_map( $content );

			foreach ( self::META_BUILDERS as $key => $method ) {
				if ( empty( $template[ $key ] ) || ! self::is_feature_available( $key ) || ( 'swap' === $context && in_array( $key, self::KEPT_ON_SWAP, true ) ) ) {
					continue;
				}
				$metas = self::$method( $template[ $key ], $map, $metas, $context, $content );
			}
		}

		// Last: the row gap depends on whether the form is conversational.
		return self::add_styling( $metas, $template, $context );
	}

	/**
	 * Pro's styling meta for a form styled with free's `_srfm_forms_styling`:
	 * the Custom theme, with free's colours and background, and the sizes free
	 * renders the form's field spacing with.
	 *
	 * @param array<string, mixed> $styling        Free's styling.
	 * @param array<string, mixed> $default        Registered default of Pro's styling meta.
	 * @param bool                 $conversational Whether the form uses the conversational layout.
	 * @since 2.13.0
	 * @return array<string, mixed>
	 */
	public static function map_styling( $styling, $default, $conversational = false ) {
		$starter = array_merge( $default, array_intersect_key( $styling, array_flip( self::MIRRORED_STYLING_KEYS ) ) );

		$starter['form_theme'] = 'custom';

		$spacing = Helper::get_string_value( $styling['field_spacing'] ?? 'small' );
		$sizes   = Helper::get_css_vars( $spacing );
		foreach ( self::SIZE_KEYS as $key => $variable ) {
			$px = self::px( $sizes[ $variable ] ?? '' );
			if ( null !== $px ) {
				$starter[ $key ] = $px;
				$starter[ 'form_row_gap' === $key ? 'form_row_gap_type' : $key . '_unit' ] = 'px';
			}
		}
		if ( $conversational ) {
			$starter = array_merge( $starter, self::CONVERSATIONAL_GAPS[ $spacing ] ?? self::CONVERSATIONAL_GAPS['small'] );
		}

		// `--srfm-btn-padding` is "<vertical> <horizontal>".
		$padding = array_map( [ self::class, 'px' ], explode( ' ', Helper::get_string_value( $sizes['--srfm-btn-padding'] ?? '' ) ) );
		if ( 2 === count( $padding ) && null !== $padding[0] && null !== $padding[1] ) {
			$starter['button_padding_top']    = $padding[0];
			$starter['button_padding_bottom'] = $padding[0];
			$starter['button_padding_right']  = $padding[1];
			$starter['button_padding_left']   = $padding[1];
			$starter['button_padding_unit']   = 'px';
		}

		return self::map_page_break_colors( $starter );
	}

	/**
	 * Encode a JSON-string meta. Values are returned raw in every context:
	 * free slashes the whole post array before wp_insert_post() on create.
	 *
	 * @param array<mixed> $data Data.
	 * @since 2.13.0
	 * @return string
	 */
	public static function json_meta( $data ) {
		return (string) wp_json_encode( $data, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
	}

	/**
	 * `_srfm_conditional_logic` from a `conditions` declaration.
	 *
	 * @param mixed                                                                     $conditions Declaration.
	 * @param array<string, array{block_id: string, blockName: string, parent: string}> $map        Slug map.
	 * @param bool                                                                      $warn       Whether to report invalid declarations.
	 * @since 2.13.0
	 * @return array<int, array<string, array{action: string, logic: array<int, array<int, array<string, mixed>>>}>>
	 */
	public static function build_conditional_logic( $conditions, $map, $warn = true ) {
		if ( ! is_array( $conditions ) ) {
			self::warn( $warn, 'conditions', __( 'Template "conditions" must be an array keyed by target field slug.', 'sureforms-pro' ) );
			return [];
		}

		$entries = [];
		foreach ( $conditions as $target_slug => $rule ) {
			$target_slug = (string) $target_slug;
			$target      = $map[ $target_slug ] ?? null;
			if ( null === $target || 'srfm/repeater' === $target['parent'] ) {
				/* translators: %s: field slug */
				self::warn( $warn, 'conditions', sprintf( __( 'Condition target "%s" is not a field of the template outside a repeater.', 'sureforms-pro' ), $target_slug ) );
				continue;
			}

			$action = is_array( $rule ) && isset( $rule['action'] ) ? $rule['action'] : 'show';
			if ( ! is_array( $rule ) || ! in_array( $action, [ 'show', 'hide' ], true ) || empty( $rule['logic'] ) || ! is_array( $rule['logic'] ) ) {
				/* translators: %s: field slug */
				self::warn( $warn, 'conditions', sprintf( __( 'Condition for "%s" needs an action of show or hide and a logic list.', 'sureforms-pro' ), $target_slug ) );
				continue;
			}

			$logic = [];
			foreach ( $rule['logic'] as $group ) {
				$conditions_in_group = [];
				foreach ( is_array( $group ) ? $group : [] as $condition ) {
					$built = self::build_condition( $condition, $map, $target_slug, $warn );
					if ( null === $built ) {
						continue 3; // One invalid condition skips the whole target.
					}
					$conditions_in_group[] = $built;
				}
				if ( empty( $conditions_in_group ) ) {
					/* translators: %s: field slug */
					self::warn( $warn, 'conditions', sprintf( __( 'Condition for "%s" has an empty group.', 'sureforms-pro' ), $target_slug ) );
					continue 2;
				}
				$logic[] = $conditions_in_group;
			}

			$entries[] = [
				$target['block_id'] => [
					'action' => $action,
					'logic'  => $logic,
				],
			];
		}

		return $entries;
	}

	/**
	 * Style the form with Pro's Custom theme, set to the template's look.
	 *
	 * Without this the form keeps Pro's default styling meta (`form_theme`
	 * 'default', navy button, white background): the front end uses free's
	 * template styling, but the editor shows and edits Pro's defaults. Pro's
	 * meta starts from its registered default, takes the keys it shares with
	 * free's `_srfm_forms_styling`, and the field and button sizes free's
	 * styling renders with, so the published form looks the same.
	 *
	 * @param array<string, mixed> $metas    Metas.
	 * @param array<string, mixed> $template Template.
	 * @param string               $context  `create`, `swap` or `preview`.
	 * @since 2.13.0
	 * @return array<string, mixed>
	 */
	private static function add_styling( $metas, $template, $context ) {
		$default = self::registered_default( self::STYLING_META );
		if ( ! is_array( $default ) || empty( $default ) ) {
			return $metas; // Pro's styling isn't registered.
		}

		$styling = $metas['_srfm_forms_styling'] ?? null;
		if ( 'swap' === $context && ! is_array( $styling ) && class_exists( Form_Templates::class ) ) {
			$styling = Form_Templates::build_style_metas( $template, self::$swap_style )['_srfm_forms_styling'];
		}
		if ( ! is_array( $styling ) || empty( $styling ) ) {
			return $metas;
		}

		$conversational              = Helper::get_array_value( $metas['_srfm_conversational_form'] ?? [] );
		$metas[ self::STYLING_META ] = self::map_styling( $styling, $default, ! empty( $conversational['is_cf_enabled'] ) );
		return $metas;
	}

	/**
	 * Page-break button colours that keep the look the buttons have without
	 * Pro's styling: Next in the primary colour, Back tinted with the text
	 * colour, neither changing on hover. Empty colours fall back to the
	 * form's own colours.
	 *
	 * @param array<string, mixed> $starter Pro styling.
	 * @since 2.13.0
	 * @return array<string, mixed>
	 */
	private static function map_page_break_colors( $starter ) {
		foreach ( array_keys( $starter ) as $key ) {
			if ( 0 === strpos( (string) $key, 'page_break_' ) && false !== strpos( (string) $key, '_color_' ) ) {
				$starter[ $key ] = '';
			}
		}

		$primary    = Helper::get_string_value( $starter['primary_color'] ?? '' );
		$on_primary = Helper::get_string_value( $starter['text_color_on_primary'] ?? '' );
		$text       = Helper::get_string_value( $starter['text_color'] ?? '' );
		if ( 1 === preg_match( '/^#[0-9a-fA-F]{6}$/', $primary ) ) {
			$starter['page_break_next_button_border_color_normal']    = $primary;
			$starter['page_break_next_button_background_color_hover'] = $primary;
			$starter['page_break_next_button_border_color_hover']     = $primary;
			$starter['page_break_next_button_text_color_hover']       = $on_primary;
		}
		if ( 1 === preg_match( '/^#[0-9a-fA-F]{6}$/', $text ) ) {
			// Text colour at 5% and 80%, as free's `--srfm-page-break-back-btn-*`.
			$starter['page_break_back_button_border_color_normal']    = $text . '0D';
			$starter['page_break_back_button_background_color_hover'] = $text . '0D';
			$starter['page_break_back_button_border_color_hover']     = $text . '0D';
			$starter['page_break_back_button_text_color_hover']       = $text . 'CC';
		}

		return $starter;
	}

	/**
	 * A whole number of pixels from a CSS length such as `18px`.
	 *
	 * @param mixed $value CSS length.
	 * @since 2.13.0
	 * @return int|null Null when the value isn't in whole pixels.
	 */
	private static function px( $value ) {
		return is_string( $value ) && 1 === preg_match( '/^(\d+)px$/', trim( $value ), $match ) ? (int) $match[1] : null;
	}

	/**
	 * Recursive part of get_slug_map().
	 *
	 * @param array<int, array<string, mixed>>                                          $blocks Parsed blocks.
	 * @param string                                                                    $parent Parent block name, '' at the top level.
	 * @param array<string, array{block_id: string, blockName: string, parent: string}> $map    Map being built.
	 * @since 2.13.0
	 * @return void
	 */
	private static function collect_slugs( $blocks, $parent, &$map ) {
		foreach ( $blocks as $block ) {
			$name  = is_string( $block['blockName'] ?? null ) ? $block['blockName'] : '';
			$attrs = is_array( $block['attrs'] ?? null ) ? $block['attrs'] : [];
			$slug  = is_string( $attrs['slug'] ?? null ) ? $attrs['slug'] : '';
			$id    = is_string( $attrs['block_id'] ?? null ) ? $attrs['block_id'] : '';

			if ( '' !== $name && '' !== $slug && '' !== $id && ! isset( $map[ $slug ] ) ) {
				$map[ $slug ] = [
					'block_id'  => $id,
					'blockName' => $name,
					'parent'    => $parent,
				];
			}

			if ( ! empty( $block['innerBlocks'] ) && is_array( $block['innerBlocks'] ) ) {
				self::collect_slugs( $block['innerBlocks'], $name, $map );
			}
		}
	}

	/**
	 * One condition of a `conditions` declaration in the stored format.
	 *
	 * @param mixed                                                                     $condition   `[ source-slug, operator, value ]`.
	 * @param array<string, array{block_id: string, blockName: string, parent: string}> $map         Slug map.
	 * @param string                                                                    $target_slug Target slug, for messages.
	 * @param bool                                                                      $warn        Whether to report invalid declarations.
	 * @since 2.13.0
	 * @return array{field: string, operator: string, value: string|array<int, string>, type: string}|null Null when invalid.
	 */
	private static function build_condition( $condition, $map, $target_slug, $warn ) {
		if ( ! is_array( $condition ) || ! isset( $condition[0], $condition[1] ) || ! is_string( $condition[0] ) || ! is_string( $condition[1] ) ) {
			/* translators: %s: field slug */
			self::warn( $warn, 'conditions', sprintf( __( 'A condition for "%s" is not [ source-slug, operator, value ].', 'sureforms-pro' ), $target_slug ) );
			return null;
		}

		[ $source_slug, $operator ] = $condition;
		$source                     = $map[ $source_slug ] ?? null;
		$type                       = null === $source ? '' : str_replace( 'srfm/', '', $source['blockName'] );
		if ( null === $source || $source_slug === $target_slug || 'srfm/repeater' === $source['parent'] || in_array( $type, self::EXCLUDED_SOURCES, true ) ) {
			/* translators: 1: source field slug, 2: target field slug */
			self::warn( $warn, 'conditions', sprintf( __( 'Condition source "%1$s" (for "%2$s") is not a field conditions can read.', 'sureforms-pro' ), $source_slug, $target_slug ) );
			return null;
		}

		$allowed = Conditional_Logic::get_allowed_operators();
		$by_type = self::OPERATORS_BY_TYPE[ self::editor_block_type( $source ) ];
		if ( ! in_array( $operator, $allowed, true ) || ! in_array( $operator, $by_type, true ) ) {
			/* translators: 1: operator, 2: source field slug */
			self::warn( $warn, 'conditions', sprintf( __( 'Operator "%1$s" is not available for field "%2$s".', 'sureforms-pro' ), $operator, $source_slug ) );
			return null;
		}

		$raw = $condition[2] ?? '';
		if ( in_array( $operator, self::VALUELESS_OPERATORS, true ) ) {
			$value = '';
		} elseif ( in_array( $operator, [ 'in', '!in' ], true ) ) {
			$value = array_values( array_map( 'strval', array_filter( is_array( $raw ) ? $raw : [ $raw ], 'is_scalar' ) ) );
		} elseif ( 'between' === $operator && is_array( $raw ) && 2 === count( $raw ) ) {
			$value = implode( ',', array_map( 'strval', array_values( $raw ) ) );
		} elseif ( is_scalar( $raw ) ) {
			$value = is_bool( $raw ) ? ( $raw ? 'true' : 'false' ) : (string) $raw;
		} else {
			/* translators: %s: source field slug */
			self::warn( $warn, 'conditions', sprintf( __( 'The value of a condition on "%s" must be a string.', 'sureforms-pro' ), $source_slug ) );
			return null;
		}

		return [
			'field'    => $source['block_id'],
			'operator' => $operator,
			'value'    => $value,
			'type'     => $type,
		];
	}

	/**
	 * The block type the conditional-logic editor uses for a source field.
	 * Mirrors helperProcessBlocks() in src/conditional-logic/single-condition.js.
	 *
	 * @param array{block_id: string, blockName: string, parent: string} $source Source block.
	 * @since 2.13.0
	 * @return string Key of OPERATORS_BY_TYPE.
	 */
	private static function editor_block_type( $source ) {
		switch ( str_replace( 'srfm/', '', $source['blockName'] ) ) {
			case 'dropdown':
			case 'multi-choice':
				return 'list';
			case 'slider':
				return 'slider';
			case 'date-picker':
				return 'datepicker';
			case 'time-picker':
				return 'timepicker';
			case 'checkbox':
			case 'gdpr':
				return 'checkbox';
			case 'number':
			case 'nps':
				return 'number';
			case 'inline-button':
			case 'input':
			case 'email':
			case 'textarea':
			case 'phone':
				return 'text';
			default:
				return 'default';
		}
	}

	/**
	 * Builder for `conditions`.
	 *
	 * @param mixed                                                                     $declaration Declaration.
	 * @param array<string, array{block_id: string, blockName: string, parent: string}> $map         Slug map.
	 * @param array<string, mixed>                                                      $metas       Metas.
	 * @since 2.13.0
	 * @return array<string, mixed>
	 */
	private static function add_conditional_logic( $declaration, $map, $metas ) {
		$logic = self::build_conditional_logic( $declaration, $map );
		if ( ! empty( $logic ) ) {
			$metas['_srfm_conditional_logic'] = $logic;
		}
		return $metas;
	}

	/**
	 * Rules of a confirmation or email condition in the stored format.
	 *
	 * @param mixed                                                                     $rules Declared `[ [ slug, operator, value ], ... ]`.
	 * @param array<string, array{block_id: string, blockName: string, parent: string}> $map   Slug map.
	 * @param string                                                                    $key   Template key, for messages.
	 * @since 2.13.0
	 * @return array<int, array{field: string, operator: string, value: string}>|null Null when any rule is invalid.
	 */
	private static function build_rules( $rules, $map, $key ) {
		if ( ! is_array( $rules ) || empty( $rules ) ) {
			self::warn( true, $key, __( 'Rules must be a non-empty list of [ field-slug, operator, value ].', 'sureforms-pro' ) );
			return null;
		}

		$built = [];
		foreach ( $rules as $rule ) {
			$is_quiz = is_array( $rule ) && isset( $rule[0] ) && in_array( $rule[0], self::QUIZ_RULE_FIELDS, true ) && self::is_feature_available( 'quiz' );
			if ( ! is_array( $rule ) || ! isset( $rule[0], $rule[1] ) || ! is_string( $rule[0] ) || ( ! $is_quiz && ! isset( $map[ $rule[0] ] ) ) ) {
				self::warn( true, $key, __( 'A rule names a field the template does not have.', 'sureforms-pro' ) );
				return null;
			}
			if ( ! in_array( $rule[1], self::RULE_OPERATORS, true ) ) {
				/* translators: %s: operator */
				self::warn( true, $key, sprintf( __( 'Unknown rule operator "%s".', 'sureforms-pro' ), is_string( $rule[1] ) ? $rule[1] : '' ) );
				return null;
			}
			$value = $rule[2] ?? '';
			if ( is_array( $value ) ) {
				$value = implode( ',', array_map( 'strval', array_filter( $value, 'is_scalar' ) ) );
			}
			$built[] = [
				'field'    => $is_quiz ? $rule[0] : '{form:' . $rule[0] . '}',
				'operator' => $rule[1],
				'value'    => is_scalar( $value ) ? (string) $value : '',
			];
		}

		return $built;
	}

	/**
	 * Validated `_AND_` / `_OR_` logic.
	 *
	 * @param mixed  $logic Declared logic.
	 * @param string $key   Template key, for messages.
	 * @since 2.13.0
	 * @return string|null Null when invalid.
	 */
	private static function rule_logic( $logic, $key ) {
		$logic = $logic ?? '_AND_';
		if ( ! in_array( $logic, [ '_AND_', '_OR_' ], true ) ) {
			self::warn( true, $key, __( 'Rule logic must be _AND_ or _OR_.', 'sureforms-pro' ) );
			return null;
		}
		return $logic;
	}

	/**
	 * Builder for `confirmations`.
	 *
	 * @param mixed                                                                     $declaration Declaration.
	 * @param array<string, array{block_id: string, blockName: string, parent: string}> $map         Slug map.
	 * @param array<string, mixed>                                                      $metas       Metas.
	 * @since 2.13.0
	 * @return array<string, mixed>
	 */
	private static function add_confirmations( $declaration, $map, $metas ) {
		$confirmations = [];
		foreach ( is_array( $declaration ) ? $declaration : [] as $index => $item ) {
			if ( ! is_array( $item ) ) {
				continue;
			}
			$type  = $item['type'] ?? 'success_message';
			$after = $item['after'] ?? 'hide_form';
			$url   = is_string( $item['url'] ?? null ) ? esc_url_raw( $item['url'] ) : '';
			if ( ! in_array( $type, [ 'success_message', 'redirect' ], true ) || ! in_array( $after, [ 'hide_form', 'reset_form' ], true )
				|| ( 'redirect' === $type && '' === $url ) || ( 'success_message' === $type && empty( $item['message'] ) ) ) {
				self::warn( true, 'confirmations', __( 'A confirmation needs a message (or type redirect with a url) and after of hide_form or reset_form.', 'sureforms-pro' ) );
				continue;
			}
			$logic = self::rule_logic( $item['logic'] ?? null, 'confirmations' );
			$rules = self::build_rules( $item['rules'] ?? null, $map, 'confirmations' );
			if ( null === $logic || null === $rules ) {
				continue;
			}

			$confirmations[] = [
				'status'              => true,
				/* translators: %d: confirmation number */
				'name'                => is_string( $item['name'] ?? null ) ? $item['name'] : sprintf( __( 'Confirmation %d', 'sureforms-pro' ), (int) $index + 1 ),
				'confirmationType'    => $type,
				'confirmationMessage' => is_string( $item['message'] ?? null ) ? $item['message'] : '',
				'afterSubmission'     => $after,
				'redirectTo'          => 'url',
				'redirectUrl'         => [
					'label' => $url,
					'value' => $url,
				],
				'enableQueryParams'   => false,
				'queryParams'         => [],
				'conditionalLogic'    => [
					'status' => true,
					'logic'  => $logic,
					'rules'  => $rules,
				],
			];
		}

		if ( ! empty( $confirmations ) ) {
			$metas['_srfm_conditional_confirmation'] = self::json_meta( $confirmations );
		}
		return $metas;
	}

	/**
	 * Ids of the notifications in the metas being built.
	 *
	 * @param array<string, mixed> $metas Metas.
	 * @since 2.13.0
	 * @return array<int, int>
	 */
	private static function notification_ids( $metas ) {
		$ids = [];
		foreach ( Helper::get_array_value( $metas['_srfm_email_notification'] ?? [] ) as $notification ) {
			if ( is_array( $notification ) && isset( $notification['id'] ) ) {
				$ids[] = (int) $notification['id'];
			}
		}
		return $ids;
	}

	/**
	 * Builder for `email_conditions`.
	 *
	 * @param mixed                                                                     $declaration Declaration.
	 * @param array<string, array{block_id: string, blockName: string, parent: string}> $map         Slug map.
	 * @param array<string, mixed>                                                      $metas       Metas.
	 * @since 2.13.0
	 * @return array<string, mixed>
	 */
	private static function add_email_conditions( $declaration, $map, $metas ) {
		$existing = self::notification_ids( $metas );
		$feeds    = [];
		foreach ( is_array( $declaration ) ? $declaration : [] as $notification => $item ) {
			$id = is_int( $notification ) ? $notification : ( self::NOTIFICATION_IDS[ $notification ] ?? 0 );
			if ( ! in_array( $id, $existing, true ) || ! is_array( $item ) ) {
				/* translators: %s: notification key */
				self::warn( true, 'email_conditions', sprintf( __( 'Email condition for "%s" names a notification the template does not send.', 'sureforms-pro' ), (string) $notification ) );
				continue;
			}
			$logic = self::rule_logic( $item['logic'] ?? null, 'email_conditions' );
			$rules = self::build_rules( $item['rules'] ?? null, $map, 'email_conditions' );
			if ( null === $logic || null === $rules ) {
				continue;
			}
			$feeds[] = [
				'conditionalLogic' => [
					'id'     => $id,
					'status' => true,
					'logic'  => $logic,
					'rules'  => $rules,
				],
			];
		}

		if ( ! empty( $feeds ) ) {
			$metas['_srfm_email_conditional_meta'] = self::json_meta( $feeds );
		}
		return $metas;
	}

	/**
	 * Builder for `attach_uploads`.
	 *
	 * @param mixed                                                                     $declaration Declaration.
	 * @param array<string, array{block_id: string, blockName: string, parent: string}> $map         Slug map.
	 * @param array<string, mixed>                                                      $metas       Metas.
	 * @since 2.13.0
	 * @return array<string, mixed>
	 */
	private static function add_attach_uploads( $declaration, $map, $metas ) {
		if ( ! in_array( self::NOTIFICATION_IDS['admin'], self::notification_ids( $metas ), true ) ) {
			return $metas;
		}

		$block_ids = [];
		foreach ( is_array( $declaration ) ? $declaration : [] as $slug ) {
			$block = is_string( $slug ) ? ( $map[ $slug ] ?? null ) : null;
			if ( null === $block || 'srfm/upload' !== $block['blockName'] || 1 !== preg_match( '/^[a-f0-9]{8}$/', $block['block_id'] ) ) {
				/* translators: %s: field slug */
				self::warn( true, 'attach_uploads', sprintf( __( '"%s" is not an upload field of the template.', 'sureforms-pro' ), is_string( $slug ) ? $slug : '' ) );
				continue;
			}
			$block_ids[] = $block['block_id'];
		}

		if ( ! empty( $block_ids ) ) {
			$metas['_srfm_email_attach_uploads_meta'] = self::json_meta(
				[
					[
						'id'                   => self::NOTIFICATION_IDS['admin'],
						'attach_uploads'       => true,
						'attach_upload_fields' => array_values( array_unique( $block_ids ) ),
					],
				]
			);
		}
		return $metas;
	}

	/**
	 * Builder for `restrictions`: the login gate only.
	 *
	 * The other restrictions keep what a new form would get: Pro's registered
	 * defaults with the site-wide IP / country / keyword settings over them.
	 *
	 * @param mixed                                                                     $declaration Declaration.
	 * @param array<string, array{block_id: string, blockName: string, parent: string}> $map         Slug map.
	 * @param array<string, mixed>                                                      $metas       Metas.
	 * @since 2.13.0
	 * @return array<string, mixed>
	 */
	private static function add_restrictions( $declaration, $map, $metas ) {
		unset( $map );
		if ( ! is_array( $declaration ) || empty( $declaration['login'] ) || array_diff( array_keys( $declaration ), [ 'login' ] ) ) {
			self::warn( true, 'restrictions', __( 'Templates can only set the login restriction: [ "login" => true ].', 'sureforms-pro' ) );
			if ( ! is_array( $declaration ) || empty( $declaration['login'] ) ) {
				return $metas;
			}
		}

		$data = self::new_form_restrictions();

		$login         = Helper::get_array_value( $data['login'] ?? [] );
		$message       = is_array( $declaration['login'] ) && is_string( $declaration['login']['message'] ?? null ) ? $declaration['login']['message'] : '';
		$data['login'] = [
			'status'  => true,
			'message' => '' !== $message ? $message : Helper::get_string_value( $login['message'] ?? '' ),
		];

		$metas['_srfm_additional_form_restriction'] = self::json_meta( $data );
		return $metas;
	}

	/**
	 * Builder for `save_resume`. Pro's registered default carries the default
	 * texts; the meta sanitizer would blank them if they were left out.
	 *
	 * @param mixed                                                                     $declaration Declaration.
	 * @param array<string, array{block_id: string, blockName: string, parent: string}> $map         Slug map.
	 * @param array<string, mixed>                                                      $metas       Metas.
	 * @since 2.13.0
	 * @return array<string, mixed>
	 */
	private static function add_save_resume( $declaration, $map, $metas ) {
		unset( $declaration, $map );
		$default = json_decode( Helper::get_string_value( self::registered_default( '_srfm_save_resume' ) ), true );
		$data    = array_merge( is_array( $default ) ? $default : [], [ 'status' => true ] );

		$metas['_srfm_save_resume'] = self::json_meta( $data );
		return $metas;
	}

	/**
	 * Builder for `survey`.
	 *
	 * @param mixed                                                                     $declaration Declaration.
	 * @param array<string, array{block_id: string, blockName: string, parent: string}> $map         Slug map.
	 * @param array<string, mixed>                                                      $metas       Metas.
	 * @since 2.13.0
	 * @return array<string, mixed>
	 */
	private static function add_survey( $declaration, $map, $metas ) {
		unset( $map );
		$metas['_srfm_survey_meta'] = self::json_meta(
			[
				'status'            => true,
				'show_live_results' => is_array( $declaration ) && ! empty( $declaration['show_live_results'] ),
			]
		);
		return $metas;
	}

	/**
	 * Builder for `conversational`.
	 *
	 * @param mixed                                                                     $declaration Declaration.
	 * @param array<string, array{block_id: string, blockName: string, parent: string}> $map         Slug map.
	 * @param array<string, mixed>                                                      $metas       Metas.
	 * @param string                                                                    $context     Context.
	 * @param string                                                                    $content     Block markup.
	 * @since 2.13.0
	 * @return array<string, mixed>
	 */
	private static function add_conversational( $declaration, $map, $metas, $context, $content ) {
		unset( $map );
		if ( has_block( 'srfm/page-break', $content ) ) {
			self::warn( true, 'conversational', __( 'A conversational template cannot have page breaks.', 'sureforms-pro' ) );
			return $metas;
		}

		$options = is_array( $declaration ) ? $declaration : [];
		$text    = static function ( $key, $fallback ) use ( $options ) {
			return is_string( $options[ $key ] ?? null ) && '' !== $options[ $key ] ? $options[ $key ] : $fallback;
		};

		$form = array_merge(
			Helper::get_array_value( self::registered_default( '_srfm_conversational_form' ) ),
			[
				'is_cf_enabled'      => true,
				'cf_layout'          => 'no-image',
				'cf_is_progress_bar' => ! isset( $options['progress_bar'] ) || (bool) $options['progress_bar'],
			]
		);

		// Same defaults as the AI form builder (Conversational_Form::create_metas_for_ai()).
		$welcome = [
			'is_welcome_screen'      => ! isset( $options['welcome_screen'] ) || (bool) $options['welcome_screen'],
			'welcome_screen_heading' => $text( 'welcome_heading', __( 'Help Us Gather Valuable Insights!', 'sureforms-pro' ) ),
			'welcome_screen_message' => $text( 'welcome_message', __( 'Answer a few quick questions to share your thoughts and make your voice heard.', 'sureforms-pro' ) ),
			'welcome_screen_image'   => '',
			'start_btn_text'         => $text( 'start_button', __( 'Get Started', 'sureforms-pro' ) ),
		];

		$metas['_srfm_conversational_form'] = $form;
		$metas['_srfm_premium_common']      = array_merge( Helper::get_array_value( $metas['_srfm_premium_common'] ?? [] ), $welcome );

		// The conversational layout only renders on the form's own page. In the
		// swap context the editor keeps the form's page settings as they are.
		if ( 'swap' !== $context && isset( $metas['_srfm_instant_form_settings'] ) && is_array( $metas['_srfm_instant_form_settings'] ) ) {
			$metas['_srfm_instant_form_settings']['enable_instant_form'] = true;
		}

		return $metas;
	}

	/**
	 * Restrictions a new form gets: Pro's registered defaults with the site-wide
	 * IP / country / keyword settings over them.
	 *
	 * @since 2.13.0
	 * @return array<string, mixed>
	 */
	private static function new_form_restrictions() {
		$data   = json_decode( Helper::get_string_value( self::registered_default( '_srfm_additional_form_restriction' ) ), true );
		$data   = is_array( $data ) ? $data : [];
		$global = class_exists( Advanced_Restriction_Defaults::class ) ? Advanced_Restriction_Defaults::get_instance() : null;
		if ( $global instanceof Advanced_Restriction_Defaults ) {
			$data = array_merge( $data, $global->get_settings() );
		}
		return $data;
	}

	/**
	 * Swap context: every meta a feature of this build owns, at its empty value.
	 * The builders then write the ones the new template declares. The access
	 * settings in KEPT_ON_SWAP are left out, so the form keeps its own.
	 *
	 * @param array<string, mixed> $metas Metas.
	 * @since 2.13.0
	 * @return array<string, mixed>
	 */
	private static function reset_owned_metas( $metas ) {
		$registered = get_registered_meta_keys( 'post', defined( 'SRFM_FORMS_POST_TYPE' ) ? SRFM_FORMS_POST_TYPE : 'sureforms_form' );
		foreach ( self::OWNED_METAS as $feature => $keys ) {
			if ( in_array( $feature, self::KEPT_ON_SWAP, true ) || ! self::is_feature_available( $feature ) ) {
				continue;
			}
			foreach ( $keys as $key ) {
				if ( ! isset( $registered[ $key ] ) ) {
					continue; // The editor ignores keys it doesn't know.
				}
				if ( array_key_exists( 'default', $registered[ $key ] ) ) {
					$metas[ $key ] = $registered[ $key ]['default'];
				} else {
					$metas[ $key ] = in_array( $registered[ $key ]['type'] ?? 'string', [ 'array', 'object' ], true ) ? [] : '';
				}
			}
		}
		return $metas;
	}

	/**
	 * Builder for `quiz`: the settings declared over the editor's defaults, and a
	 * question for each dropdown / multi-choice block, from its options'
	 * `isCorrect` and `individualScore`.
	 *
	 * @param mixed                                                                     $declaration Declaration.
	 * @param array<string, array{block_id: string, blockName: string, parent: string}> $map         Slug map.
	 * @param array<string, mixed>                                                      $metas       Metas.
	 * @param string                                                                    $context     Context.
	 * @param string                                                                    $content     Block markup.
	 * @since 2.13.0
	 * @return array<string, mixed>
	 */
	private static function add_quiz( $declaration, $map, $metas, $context, $content ) {
		unset( $context );
		$options = is_array( $declaration ) ? $declaration : [];
		$data    = array_merge( [ 'status' => true ], self::QUIZ_DEFAULTS, [ 'letterGrades' => \SRFM_Pro\Inc\Quiz\Utils::get_default_letter_grades() ] );
		$choices = [
			'scoreType'     => [ 'correct_incorrect', 'advanced' ],
			'gradingSystem' => [ 'default', 'pass_fail', 'letter' ],
			'resultOutput'  => [ 'default_confirmation', 'show_score', 'full_result' ],
		];

		foreach ( $options as $key => $value ) {
			$key   = (string) $key;
			$valid = true;
			if ( isset( $choices[ $key ] ) ) {
				$valid = in_array( $value, $choices[ $key ], true );
			} elseif ( in_array( $key, [ 'randomizeQuestions', 'randomizeOptions' ], true ) ) {
				$valid = is_bool( $value );
			} elseif ( 'passPercent' === $key ) {
				$valid = is_int( $value ) && $value >= 0 && $value <= 100;
			} elseif ( in_array( $key, [ 'correctAnswerScore', 'defaultScore' ], true ) ) {
				$valid = is_int( $value ) && $value >= 0;
			} elseif ( 'inCorrectAnswerScore' === $key ) {
				$valid = is_int( $value );
			} elseif ( 'letterGrades' === $key ) {
				$value = self::quiz_letter_grades( $value );
				$valid = ! empty( $value );
			} else {
				/* translators: %s: setting name */
				self::warn( true, 'quiz', sprintf( __( 'Unknown quiz setting "%s".', 'sureforms-pro' ), $key ) );
				continue;
			}

			if ( ! $valid ) {
				/* translators: %s: setting name */
				self::warn( true, 'quiz', sprintf( __( 'Invalid value for the quiz setting "%s"; the default is used.', 'sureforms-pro' ), $key ) );
				continue;
			}
			$data[ $key ] = $value;
		}

		$slugs = [];
		foreach ( $map as $slug => $block ) {
			$slugs[ $block['block_id'] ] = $slug;
		}

		$questions = [];
		foreach ( \SRFM_Pro\Inc\Quiz\Editor::extract_quiz_questions_from_content( $content ) as $question ) {
			$answers = is_array( $question['correctAnswers'] ?? null ) ? $question['correctAnswers'] : [];
			if ( 'correct_incorrect' === $data['scoreType'] && empty( array_filter( array_column( $answers, 'isCorrect' ) ) ) ) {
				$block_id = Helper::get_string_value( $question['blockId'] ?? '' );
				/* translators: %s: field slug */
				self::warn( true, 'quiz', sprintf( __( 'Quiz question "%s" has no option with isCorrect, so it is not scored.', 'sureforms-pro' ), $slugs[ $block_id ] ?? $block_id ) );
				continue;
			}
			$questions[] = $question;
		}

		if ( empty( $questions ) ) {
			self::warn( true, 'quiz', __( 'A quiz template needs at least one dropdown or multiple-choice question with a correct option.', 'sureforms-pro' ) );
			return $metas;
		}

		$data['questions']        = $questions;
		$metas['_srfm_quiz_meta'] = self::json_meta( $data );
		return $metas;
	}

	/**
	 * Valid declared letter grades.
	 *
	 * @param mixed $grades `[ [ 'grade' => 'A', 'percentage' => 90 ], ... ]`.
	 * @since 2.13.0
	 * @return array<int, array{grade: string, percentage: int}> Empty when any grade is invalid.
	 */
	private static function quiz_letter_grades( $grades ) {
		$built = [];
		foreach ( is_array( $grades ) ? $grades : [] as $grade ) {
			if ( ! is_array( $grade ) || ! is_string( $grade['grade'] ?? null ) || '' === $grade['grade'] || ! is_int( $grade['percentage'] ?? null ) || $grade['percentage'] < 0 || $grade['percentage'] > 100 ) {
				return [];
			}
			$built[] = [
				'grade'      => $grade['grade'],
				'percentage' => $grade['percentage'],
			];
		}
		return $built;
	}

	/**
	 * The first field of a block type in the slug map that is not inside a repeater.
	 *
	 * @param array<string, array{block_id: string, blockName: string, parent: string}> $map        Slug map.
	 * @param string                                                                    $block_name Block name, such as `srfm/email`.
	 * @since 2.13.0
	 * @return string Slug, or ''.
	 */
	private static function first_field_of_type( $map, $block_name ) {
		foreach ( $map as $slug => $block ) {
			if ( $block_name === $block['blockName'] && 'srfm/repeater' !== $block['parent'] ) {
				return (string) $slug;
			}
		}
		return '';
	}

	/**
	 * A declared field slug, checked against the block types it may be.
	 *
	 * @param mixed                                                                     $slug   Declared slug.
	 * @param array<string, array{block_id: string, blockName: string, parent: string}> $map    Slug map.
	 * @param array<int, string>                                                        $types  Allowed block names; empty for any.
	 * @param string                                                                    $key    Template key, for messages.
	 * @param string                                                                    $option Declaration option, for messages.
	 * @since 2.13.0
	 * @return string|null The slug, or null (after a warning) when it is not such a field outside a repeater.
	 */
	private static function declared_field( $slug, $map, $types, $key, $option ) {
		$slug  = is_string( $slug ) ? $slug : '';
		$block = $map[ $slug ] ?? null;
		if ( null === $block || 'srfm/repeater' === $block['parent'] || ( ! empty( $types ) && ! in_array( $block['blockName'], $types, true ) ) ) {
			/* translators: 1: option name, 2: allowed block types */
			self::warn( true, $key, sprintf( __( '"%1$s" must be the slug of a field of the template outside a repeater (%2$s).', 'sureforms-pro' ), $option, empty( $types ) ? __( 'any type', 'sureforms-pro' ) : implode( ', ', $types ) ) );
			return null;
		}
		return $slug;
	}

	/**
	 * Builder for `partial_entries`: capture on, with the safe defaults.
	 *
	 * @param mixed                                                                     $declaration Declaration.
	 * @param array<string, array{block_id: string, blockName: string, parent: string}> $map         Slug map.
	 * @param array<string, mixed>                                                      $metas       Metas.
	 * @since 2.13.0
	 * @return array<string, mixed>
	 */
	private static function add_partial_entries( $declaration, $map, $metas ) {
		$options = is_array( $declaration ) ? $declaration : [];

		$mode = $options['capture_mode'] ?? 'meaningful';
		if ( ! in_array( $mode, [ 'meaningful', 'contact' ], true ) ) {
			self::warn( true, 'partial_entries', __( 'capture_mode must be meaningful or contact.', 'sureforms-pro' ) );
			$mode = 'meaningful';
		}

		$email = isset( $options['email'] )
			? self::declared_field( $options['email'], $map, [ 'srfm/email' ], 'partial_entries', 'email' )
			: self::first_field_of_type( $map, 'srfm/email' );
		$email = null === $email || '' === $email ? '' : $map[ $email ]['block_id'];

		$reminder = ! empty( $options['reminder'] );
		if ( $reminder && '' === $email ) {
			self::warn( true, 'partial_entries', __( 'Reminders need an email field; they stay off.', 'sureforms-pro' ) );
			$reminder = false;
		}

		$default = json_decode( Helper::get_string_value( self::registered_default( '_srfm_partial_entries' ) ), true );
		$data    = array_merge(
			is_array( $default ) ? $default : [],
			[
				'status'               => true,
				'disclosure'           => true,
				'capture_mode'         => $mode,
				'resume'               => ! empty( $options['resume'] ),
				'reminder'             => $reminder,
				'reminder_email_field' => $email,
			]
		);

		$metas['_srfm_partial_entries'] = self::json_meta( $data );
		return $metas;
	}

	/**
	 * A post field of a `cpt` declaration as a smart tag string: a field slug,
	 * or text whose `{form:slug}` tags all name fields of the template.
	 *
	 * @param mixed                                                                     $value Declared value.
	 * @param array<string, array{block_id: string, blockName: string, parent: string}> $map   Slug map.
	 * @since 2.13.0
	 * @return string|null Null when it names an unknown field.
	 */
	private static function cpt_value( $value, $map ) {
		if ( ! is_string( $value ) || '' === $value ) {
			return null;
		}
		if ( isset( $map[ $value ] ) ) {
			return '{form:' . $value . '}';
		}
		if ( ! preg_match_all( '/\{form:([^}]+)\}/', $value, $tags ) ) {
			return null;
		}
		foreach ( $tags[1] as $slug ) {
			if ( ! isset( $map[ $slug ] ) ) {
				return null;
			}
		}
		return $value;
	}

	/**
	 * Builder for `cpt`: one post feed creating a pending (or draft) post.
	 *
	 * @param mixed                                                                     $declaration Declaration.
	 * @param array<string, array{block_id: string, blockName: string, parent: string}> $map         Slug map.
	 * @param array<string, mixed>                                                      $metas       Metas.
	 * @since 2.13.0
	 * @return array<string, mixed>
	 */
	private static function add_cpt( $declaration, $map, $metas ) {
		$options = is_array( $declaration ) ? $declaration : [];
		$general = [];
		foreach ( [ 'title', 'content', 'excerpt' ] as $part ) {
			if ( ! isset( $options[ $part ] ) ) {
				$general[ $part ] = '';
				continue;
			}
			$value = self::cpt_value( $options[ $part ], $map );
			if ( null === $value ) {
				/* translators: %s: post field */
				self::warn( true, 'cpt', sprintf( __( 'The post %s names a field the template does not have.', 'sureforms-pro' ), $part ) );
				return $metas;
			}
			$general[ $part ] = $value;
		}
		if ( '' === $general['title'] ) {
			self::warn( true, 'cpt', __( 'A cpt template needs a title field.', 'sureforms-pro' ) );
			return $metas;
		}

		$image = '';
		if ( isset( $options['featured_image'] ) ) {
			$slug  = self::declared_field( $options['featured_image'], $map, [ 'srfm/upload' ], 'cpt', 'featured_image' );
			$image = null === $slug ? '' : '{form:' . $slug . '}';
		}

		$post_type = $options['post_type'] ?? 'post';
		$object    = is_string( $post_type ) ? get_post_type_object( $post_type ) : null;
		if ( null === $object || ! $object->public || in_array( $post_type, [ 'attachment', SRFM_FORMS_POST_TYPE ], true ) ) {
			/* translators: %s: post type */
			self::warn( true, 'cpt', sprintf( __( 'Post type "%s" is not a public post type of this site; posts are created as post.', 'sureforms-pro' ), is_string( $post_type ) ? $post_type : '' ) );
			$post_type = 'post';
		}

		$status = $options['status'] ?? 'pending';
		if ( ! in_array( $status, [ 'pending', 'draft' ], true ) ) {
			self::warn( true, 'cpt', __( 'Template posts are created as pending or draft, never published; pending is used.', 'sureforms-pro' ) );
			$status = 'pending';
		}

		$taxonomies = [];
		if ( isset( $options['category'] ) ) {
			$term = is_string( $options['category'] ) && is_object_in_taxonomy( $post_type, 'category' ) ? get_term_by( 'slug', $options['category'], 'category' ) : false;
			if ( $term instanceof \WP_Term ) {
				$taxonomies[] = [
					'id'       => 1,
					'term'     => 'category',
					'value'    => [
						'id'   => $term->slug,
						'text' => $term->name,
					],
					'type'     => 'assign',
					'isCustom' => false,
				];
			} else {
				self::warn( true, 'cpt', __( 'The category is not an existing category of the post type; none is assigned.', 'sureforms-pro' ) );
			}
		}

		$feed = [
			'status'           => true,
			'feedName'         => is_string( $options['name'] ?? null ) && '' !== $options['name'] ? $options['name'] : __( 'Post from submission', 'sureforms-pro' ),
			'postSettings'     => [
				'visibility' => 'public',
				'password'   => '',
				'postType'   => $post_type,
				'status'     => $status,
				'date'       => 'entry_date',
				'customDate' => '',
				'hours'      => '12',
				'minutes'    => '00',
				'meridiem'   => 'AM',
				'author'     => 'logged_in_user',
			],
			'postGeneral'      => $general,
			'featuredImage'    => [
				'image'   => $image,
				'altText' => '',
				'caption' => '',
			],
			'userMeta'         => [],
			'taxonomies'       => $taxonomies,
			'conditionalLogic' => [
				'status' => false,
				'logic'  => 'AND',
				'rules'  => [],
			],
		];

		$metas['_srfm_raw_cpt_meta'] = self::json_meta( [ $feed ] );
		return $metas;
	}

	/**
	 * Builder for `registration`: creates a subscriber from the mapped fields.
	 *
	 * @param mixed                                                                     $declaration Declaration.
	 * @param array<string, array{block_id: string, blockName: string, parent: string}> $map         Slug map.
	 * @param array<string, mixed>                                                      $metas       Metas.
	 * @since 2.13.0
	 * @return array<string, mixed>
	 */
	private static function add_registration( $declaration, $map, $metas ) {
		$options = is_array( $declaration ) ? $declaration : [];

		$email = isset( $options['email'] )
			? self::declared_field( $options['email'], $map, [ 'srfm/email' ], 'registration', 'email' )
			: self::first_field_of_type( $map, 'srfm/email' );
		if ( null === $email || '' === $email ) {
			self::warn( true, 'registration', __( 'A registration template needs an email field.', 'sureforms-pro' ) );
			return $metas;
		}

		$username = isset( $options['username'] ) ? self::declared_field( $options['username'], $map, [ 'srfm/input', 'srfm/email' ], 'registration', 'username' ) : $email;
		$password = isset( $options['password'] )
			? self::declared_field( $options['password'], $map, [ 'srfm/password' ], 'registration', 'password' )
			: self::first_field_of_type( $map, 'srfm/password' );
		if ( null === $username || null === $password ) {
			return $metas;
		}

		$tags = [];
		foreach ( [ 'first_name', 'last_name', 'website' ] as $option ) {
			$slug = isset( $options[ $option ] ) ? self::declared_field( $options[ $option ], $map, [], 'registration', $option ) : '';
			if ( null === $slug ) {
				return $metas;
			}
			$tags[ $option ] = '' === $slug ? '' : '{form:' . $slug . '}';
		}

		if ( isset( $options['role'] ) && 'subscriber' !== $options['role'] ) {
			self::warn( true, 'registration', __( 'Template registrations always create subscribers.', 'sureforms-pro' ) );
		}

		$feed = [
			'name'                  => __( 'User Registration', 'sureforms-pro' ),
			'status'                => true,
			'registrationType'      => 'create',
			'username'              => '{form:' . $username . '}',
			'firstname'             => $tags['first_name'],
			'lastname'              => $tags['last_name'],
			'email'                 => '{form:' . $email . '}',
			'website'               => $tags['website'],
			'password'              => '' === $password ? '' : '{form:' . $password . '}',
			'userRole'              => 'subscriber',
			'customUserMeta'        => [
				[
					'key'   => '',
					'value' => '',
				],
			],
			'sendUserEmail'         => ! isset( $options['send_user_email'] ) || (bool) $options['send_user_email'],
			'emailNotificationType' => 'email',
			'autoLogin'             => ! empty( $options['auto_login'] ),
		];

		$metas['_srfm_user_registration_settings'] = self::json_meta( [ $feed ] );
		return $metas;
	}

	/**
	 * Builder for `entry_limit`: a recurring cap on free's entry limit. The cap
	 * is written off unless the declaration sets `enabled`. Never built on a
	 * swap (KEPT_ON_SWAP): the form keeps its own limit and scheduling.
	 *
	 * @param mixed                                                                     $declaration Declaration.
	 * @param array<string, array{block_id: string, blockName: string, parent: string}> $map         Slug map.
	 * @param array<string, mixed>                                                      $metas       Metas.
	 * @since 2.13.0
	 * @return array<string, mixed>
	 */
	private static function add_entry_limit( $declaration, $map, $metas ) {
		unset( $map );
		$options = is_array( $declaration ) ? $declaration : [];
		$max     = $options['max'] ?? null;
		$period  = $options['period'] ?? null;
		if ( ! is_int( $max ) || $max < 1 || ! in_array( $period, [ 'total', 'day', 'week', 'month', 'year' ], true ) ) {
			self::warn( true, 'entry_limit', __( 'An entry limit needs a max of at least 1 and a period of total, day, week, month or year.', 'sureforms-pro' ) );
			return $metas;
		}

		$enabled = true === ( $options['enabled'] ?? false );

		$current     = $metas['_srfm_form_restriction'] ?? self::registered_default( '_srfm_form_restriction' );
		$restriction = is_string( $current ) ? json_decode( $current, true ) : $current;
		$restriction = array_merge(
			is_array( $restriction ) ? $restriction : [],
			[
				'status'     => $enabled,
				'maxEntries' => $max,
			]
		);
		if ( is_string( $options['message'] ?? null ) && '' !== $options['message'] ) {
			$restriction['message'] = $options['message'];
		}

		$metas['_srfm_form_restriction']      = self::json_meta( $restriction );
		$metas['_srfm_recurring_entry_limit'] = self::json_meta( [ 'period' => $period ] );
		return $metas;
	}

	/**
	 * Registered default of a form meta.
	 *
	 * @param string $key Meta key.
	 * @since 2.13.0
	 * @return mixed
	 */
	private static function registered_default( $key ) {
		$registered = get_registered_meta_keys( 'post', defined( 'SRFM_FORMS_POST_TYPE' ) ? SRFM_FORMS_POST_TYPE : 'sureforms_form' );
		return $registered[ $key ]['default'] ?? '';
	}

	/**
	 * Report an invalid template declaration.
	 *
	 * @param bool   $warn    Whether to report.
	 * @param string $key     Template key.
	 * @param string $message Message.
	 * @since 2.13.0
	 * @return void
	 */
	private static function warn( $warn, $key, $message ) {
		if ( $warn ) {
			_doing_it_wrong( esc_html( self::class . '::' . $key ), esc_html( $message ), '2.13.0' );
		}
	}
}
