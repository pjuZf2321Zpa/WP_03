<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Core\Util\Hooks;
use BitApps\IntegrationsPro\Actions\SeoPress\SeoPressProHelper;
use BitApps\IntegrationsPro\Config;

// Deprecated since v2.7.8 - use bit_integrations_seopress_* hooks instead
if (class_exists('BitApps\\IntegrationsPro\\Config') && version_compare(BitApps\IntegrationsPro\Config::VERSION, '2.7.8', '<')) {
    Hooks::filter('btcbi_seopress_update_post_meta', [SeoPressProHelper::class, 'updatePostMeta'], 10, 3);
}

// New hooks since v2.7.8
Hooks::filter(Config::withFreePrefix('seopress_update_post_meta'), [SeoPressProHelper::class, 'updatePostMeta'], 10, 3);
