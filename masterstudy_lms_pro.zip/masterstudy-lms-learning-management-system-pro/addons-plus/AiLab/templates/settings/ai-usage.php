<?php

use MasterStudy\Lms\Pro\AddonsPlus\AiLab\Services\OpenAi\Model;
use MasterStudy\Lms\Pro\AddonsPlus\AiLab\Services\UsageLogger;

$usage_setting = get_option( UsageLogger::$option_name, array() );

if ( ! is_array( $usage_setting ) ) {
	$usage_setting = array();
}

$usage_date   = array_key_last( $usage_setting );
$model_labels = array();

foreach ( array_keys( Model::get_text_providers() ) as $provider ) {
	$model_labels += Model::get_text_models_by_provider( $provider );
}

foreach ( array_keys( Model::get_image_providers() ) as $provider ) {
	$model_labels += Model::get_image_models_by_provider( $provider );
}
?>

<div class="wpcfto_generic_field wpcfto_generic_field__select">
	<div class="ai-usage-section">
		<div class="section-title"><span><?php echo esc_html__( 'Usage', 'masterstudy-lms-learning-management-system-pro' ); ?></span></div>
		<div class="usage-section">
			<?php if ( ! empty( $usage_setting ) && is_array( $usage_setting ) ) : ?>
				<div class="usage-section-data"><?php echo esc_html( $usage_date ); ?></div>
				<div class="usage-section-content">
					<?php
					$usage_tokens = $usage_setting[ $usage_date ];
					foreach ( $usage_tokens as $token => $token_value ) :
						$model_label = $model_labels[ $token ] ?? $token;
						?>
						<div class="tokens-data">
							<div class="tokens-data-key">
								<?php echo esc_html( $model_label ); ?>:
							</div>
							<div class="tokens-data-tokens">
								<?php
								if ( isset( $token_value['total'] ) ) {
									echo esc_html( $token_value['total'] ) . ' images';
								}

								if ( isset( $token_value['total_tokens'] ) ) {
									echo esc_html( $token_value['total_tokens'] ) . ' tokens';
								}
								?>
							</div>
						</div>
						<?php
					endforeach;
					?>
				</div>
				<?php
			else :
				echo esc_html__( 'You have not generated any content yet.', 'masterstudy-lms-learning-management-system-pro' );
			endif;
			?>
		</div>

		<div class="wpcfto-field-description wpcfto-field-description__before description">
			<?php
			echo esc_html__( 'For exact usage and billing, please check your selected provider dashboards.', 'masterstudy-lms-learning-management-system-pro' );
			?>
		</div>
	</div>
</div>
