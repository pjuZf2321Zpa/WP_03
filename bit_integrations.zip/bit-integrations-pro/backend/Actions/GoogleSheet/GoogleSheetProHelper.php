<?php

namespace BitApps\IntegrationsPro\Actions\GoogleSheet;

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Core\Util\HttpHelper;

final class GoogleSheetProHelper
{
    public const BASE_URL = 'https://sheets.googleapis.com/v4';

    public const DRIVE_URL = 'https://www.googleapis.com/drive/v3';

    public static function createSpreadsheet($response, $fieldData, $integrationDetails = null)
    {
        $headers = self::authHeader($integrationDetails);
        if (\is_array($headers) && isset($headers['success'])) {
            return $headers;
        }

        $title = $fieldData['title'] ?? '';
        if (empty($title)) {
            return self::failure(__('Spreadsheet title is required', 'bit-integrations-pro'));
        }

        $payload = ['properties' => ['title' => $title]];
        if (!empty($fieldData['sheetTitle'])) {
            $payload['sheets'] = [['properties' => ['title' => $fieldData['sheetTitle']]]];
        }

        $apiResponse = HttpHelper::post(self::BASE_URL . '/spreadsheets', wp_json_encode($payload), $headers);

        return self::formatResponse($apiResponse, __('Spreadsheet created successfully', 'bit-integrations-pro'));
    }

    public static function deleteSpreadsheet($response, $fieldData, $integrationDetails = null)
    {
        $headers = self::authHeader($integrationDetails);
        if (\is_array($headers) && isset($headers['success'])) {
            return $headers;
        }

        $spreadsheetId = $fieldData['spreadsheetId'] ?? '';
        if (empty($spreadsheetId)) {
            return self::failure(__('Spreadsheet is required', 'bit-integrations-pro'));
        }

        $apiResponse = HttpHelper::request(self::DRIVE_URL . "/files/{$spreadsheetId}", 'DELETE', null, $headers);

        return self::formatResponse($apiResponse, __('Spreadsheet deleted successfully', 'bit-integrations-pro'));
    }

    public static function createSheet($response, $fieldData, $integrationDetails = null)
    {
        $headers = self::authHeader($integrationDetails);
        if (\is_array($headers) && isset($headers['success'])) {
            return $headers;
        }

        $spreadsheetId = $integrationDetails->spreadsheetId ?? '';
        $title = $fieldData['title'] ?? '';
        if (empty($spreadsheetId) || empty($title)) {
            return self::failure(__('Spreadsheet and worksheet title are required', 'bit-integrations-pro'));
        }

        $payload = ['requests' => [['addSheet' => ['properties' => ['title' => $title]]]]];
        $apiResponse = HttpHelper::post(self::BASE_URL . "/spreadsheets/{$spreadsheetId}:batchUpdate", wp_json_encode($payload), $headers);

        return self::formatResponse($apiResponse, __('Worksheet created successfully', 'bit-integrations-pro'));
    }

    public static function copySheet($response, $fieldData, $integrationDetails = null)
    {
        $headers = self::authHeader($integrationDetails);
        if (\is_array($headers) && isset($headers['success'])) {
            return $headers;
        }

        $spreadsheetId = $integrationDetails->spreadsheetId ?? '';
        $worksheetName = $integrationDetails->worksheetName ?? '';
        $destinationId = $fieldData['destinationSpreadsheetId'] ?? '';
        if (empty($spreadsheetId) || empty($worksheetName) || empty($destinationId)) {
            return self::failure(__('Source worksheet and destination spreadsheet are required', 'bit-integrations-pro'));
        }

        $sheetId = self::sheetIdByTitle($spreadsheetId, $worksheetName, $headers);
        if (\is_null($sheetId)) {
            return self::failure(__('Worksheet not found', 'bit-integrations-pro'));
        }

        $payload = ['destinationSpreadsheetId' => $destinationId];
        $apiResponse = HttpHelper::post(self::BASE_URL . "/spreadsheets/{$spreadsheetId}/sheets/{$sheetId}:copyTo", wp_json_encode($payload), $headers);

        return self::formatResponse($apiResponse, __('Worksheet copied successfully', 'bit-integrations-pro'));
    }

    public static function deleteSheet($response, $fieldData, $integrationDetails = null)
    {
        $headers = self::authHeader($integrationDetails);
        if (\is_array($headers) && isset($headers['success'])) {
            return $headers;
        }

        $spreadsheetId = $fieldData['spreadsheetId'] ?? '';
        $worksheetName = $fieldData['worksheetName'] ?? '';
        if (empty($spreadsheetId) || empty($worksheetName)) {
            return self::failure(__('Spreadsheet and worksheet are required', 'bit-integrations-pro'));
        }

        $sheetId = self::sheetIdByTitle($spreadsheetId, $worksheetName, $headers);
        if (\is_null($sheetId)) {
            return self::failure(__('Worksheet not found', 'bit-integrations-pro'));
        }

        $payload = ['requests' => [['deleteSheet' => ['sheetId' => $sheetId]]]];
        $apiResponse = HttpHelper::post(self::BASE_URL . "/spreadsheets/{$spreadsheetId}:batchUpdate", wp_json_encode($payload), $headers);

        return self::formatResponse($apiResponse, __('Worksheet deleted successfully', 'bit-integrations-pro'));
    }

    public static function appendOrUpdateRow($response, $fieldData, $integrationDetails = null)
    {
        $headers = self::authHeader($integrationDetails);
        if (\is_array($headers) && isset($headers['success'])) {
            return $headers;
        }

        $spreadsheetId = $integrationDetails->spreadsheetId ?? '';
        $worksheetName = $integrationDetails->worksheetName ?? '';
        $mappedColumnValue = self::mappedColumns($fieldData, $integrationDetails);

        if (empty($spreadsheetId) || empty($worksheetName)) {
            return self::failure(__('Spreadsheet and worksheet are required', 'bit-integrations-pro'));
        }

        if (empty($mappedColumnValue)) {
            return self::failure(__('No column is mapped', 'bit-integrations-pro'));
        }

        $columnToMatch = isset($fieldData['columnToMatch']) ? (int) $fieldData['columnToMatch'] : -1;
        if ($columnToMatch >= 0) {
            $columnToMatch += self::baseColumnIndex($integrationDetails);
        }

        $matched = ['matchedRow' => -1, 'values' => []];

        if ($columnToMatch >= 0 && \array_key_exists($columnToMatch, $mappedColumnValue)) {
            $sheetValues = self::fetchSheetValues($spreadsheetId, $worksheetName, $headers);
            $matched = self::findRowToUpdate($sheetValues, $columnToMatch, (string) $mappedColumnValue[$columnToMatch]);
        }

        if ($matched['matchedRow'] < 0) {
            return self::appendRow($spreadsheetId, $worksheetName, $mappedColumnValue, $headers);
        }

        $data = [];
        $rowLength = max(\count($matched['values']), max(array_keys($mappedColumnValue)) + 1);
        for ($col = 0; $col < $rowLength; ++$col) {
            $oldValue = $matched['values'][$col] ?? '';
            $newValue = $mappedColumnValue[$col] ?? $oldValue;
            if ($oldValue !== $newValue) {
                $data[] = [
                    'range'  => self::a1Sheet($worksheetName) . '!' . self::columnIndexToLetter($col) . ($matched['matchedRow'] + 1),
                    'values' => [[$newValue]],
                ];
            }
        }

        if (empty($data)) {
            return ['success' => true, 'message' => __('Row is already up to date', 'bit-integrations-pro'), 'data' => ['row_number' => $matched['matchedRow'] + 1]];
        }

        $payload = ['data' => $data, 'valueInputOption' => 'USER_ENTERED'];
        $apiResponse = HttpHelper::post(self::BASE_URL . "/spreadsheets/{$spreadsheetId}/values:batchUpdate", wp_json_encode($payload), $headers);

        return self::formatResponse($apiResponse, __('Row updated successfully', 'bit-integrations-pro'));
    }

    public static function updateRow($response, $fieldData, $integrationDetails = null)
    {
        $headers = self::authHeader($integrationDetails);
        if (\is_array($headers) && isset($headers['success'])) {
            return $headers;
        }

        $spreadsheetId = $integrationDetails->spreadsheetId ?? '';
        $worksheetName = $integrationDetails->worksheetName ?? '';
        $rowId = (int) ($fieldData['rowId'] ?? 0);
        $mappedColumnValue = self::mappedColumns($fieldData, $integrationDetails);

        if (empty($spreadsheetId) || empty($worksheetName) || $rowId < 1) {
            return self::failure(__('Spreadsheet, worksheet and row number are required', 'bit-integrations-pro'));
        }

        if (empty($mappedColumnValue)) {
            return self::failure(__('No column is mapped', 'bit-integrations-pro'));
        }

        $data = [];
        foreach ($mappedColumnValue as $columnIndex => $value) {
            $data[] = [
                'range'  => self::a1Sheet($worksheetName) . '!' . self::columnIndexToLetter($columnIndex) . $rowId,
                'values' => [[$value]],
            ];
        }

        $payload = ['data' => $data, 'valueInputOption' => 'USER_ENTERED'];
        $apiResponse = HttpHelper::post(self::BASE_URL . "/spreadsheets/{$spreadsheetId}/values:batchUpdate", wp_json_encode($payload), $headers);

        return self::formatResponse($apiResponse, __('Row updated successfully', 'bit-integrations-pro'));
    }

    public static function deleteRow($response, $fieldData, $integrationDetails = null)
    {
        $headers = self::authHeader($integrationDetails);
        if (\is_array($headers) && isset($headers['success'])) {
            return $headers;
        }

        $spreadsheetId = $integrationDetails->spreadsheetId ?? '';
        $worksheetName = $integrationDetails->worksheetName ?? '';
        $rowId = (int) ($fieldData['rowId'] ?? 0);

        if (empty($spreadsheetId) || empty($worksheetName) || $rowId < 1) {
            return self::failure(__('Spreadsheet, worksheet and row number are required', 'bit-integrations-pro'));
        }

        $sheetId = self::sheetIdByTitle($spreadsheetId, $worksheetName, $headers);
        if (\is_null($sheetId)) {
            return self::failure(__('Worksheet not found', 'bit-integrations-pro'));
        }

        $payload = [
            'requests' => [
                [
                    'deleteDimension' => [
                        'range' => [
                            'sheetId'    => $sheetId,
                            'dimension'  => 'ROWS',
                            'startIndex' => $rowId - 1,
                            'endIndex'   => $rowId,
                        ],
                    ],
                ],
            ],
        ];

        $apiResponse = HttpHelper::post(self::BASE_URL . "/spreadsheets/{$spreadsheetId}:batchUpdate", wp_json_encode($payload), $headers);

        return self::formatResponse($apiResponse, __('Row deleted successfully', 'bit-integrations-pro'));
    }

    public static function createColumn($response, $fieldData, $integrationDetails = null)
    {
        $headers = self::authHeader($integrationDetails);
        if (\is_array($headers) && isset($headers['success'])) {
            return $headers;
        }

        $spreadsheetId = $integrationDetails->spreadsheetId ?? '';
        $worksheetName = $integrationDetails->worksheetName ?? '';
        $columnName = $fieldData['columnName'] ?? '';

        if (empty($spreadsheetId) || empty($worksheetName) || empty($columnName)) {
            return self::failure(__('Spreadsheet, worksheet and column name are required', 'bit-integrations-pro'));
        }

        $sheetId = self::sheetIdByTitle($spreadsheetId, $worksheetName, $headers);
        if (\is_null($sheetId)) {
            return self::failure(__('Worksheet not found', 'bit-integrations-pro'));
        }

        $columnIndex = (int) ($fieldData['columnIndex'] ?? 0);
        if ($columnIndex < 1) {
            $sheetValues = self::fetchSheetValues($spreadsheetId, $worksheetName, $headers);
            $columnIndex = \count($sheetValues[0] ?? []) + 1;
        }

        $payload = [
            'requests' => [
                [
                    'insertDimension' => [
                        'range' => [
                            'sheetId'    => $sheetId,
                            'dimension'  => 'COLUMNS',
                            'startIndex' => $columnIndex - 1,
                            'endIndex'   => $columnIndex,
                        ],
                    ],
                ],
            ],
        ];

        HttpHelper::post(self::BASE_URL . "/spreadsheets/{$spreadsheetId}:batchUpdate", wp_json_encode($payload), $headers);

        $headerRange = self::a1Sheet($worksheetName) . '!' . self::columnIndexToLetter($columnIndex - 1) . '1';
        $apiResponse = HttpHelper::request(
            self::BASE_URL . "/spreadsheets/{$spreadsheetId}/values/" . rawurlencode($headerRange) . '?valueInputOption=USER_ENTERED',
            'PUT',
            wp_json_encode(['values' => [[$columnName]]]),
            $headers
        );

        return self::formatResponse($apiResponse, __('Column created successfully', 'bit-integrations-pro'));
    }

    private static function appendRow($spreadsheetId, $worksheetName, $mappedColumnValue, $headers)
    {
        $minIndex = min(array_keys($mappedColumnValue));
        $maxIndex = max(array_keys($mappedColumnValue));
        $range = self::a1Sheet($worksheetName) . '!' . self::columnIndexToLetter($minIndex) . ':' . self::columnIndexToLetter($maxIndex);

        $values = [];
        for ($i = $minIndex; $i <= $maxIndex; ++$i) {
            $values[] = $mappedColumnValue[$i] ?? '';
        }

        $payload = ['majorDimension' => 'ROWS', 'values' => [$values]];
        $apiResponse = HttpHelper::post(
            self::BASE_URL . "/spreadsheets/{$spreadsheetId}/values/" . rawurlencode($range) . ':append?valueInputOption=USER_ENTERED&insertDataOption=INSERT_ROWS',
            wp_json_encode($payload),
            $headers
        );

        return self::formatResponse($apiResponse, __('Row appended successfully', 'bit-integrations-pro'));
    }

    private static function mappedColumns($fieldData, $integrationDetails)
    {
        $columns = $fieldData['values'] ?? [];
        if (empty($columns) || !\is_array($columns)) {
            return [];
        }

        $baseIndex = self::baseColumnIndex($integrationDetails);

        $shifted = [];
        foreach ($columns as $offset => $value) {
            $shifted[$baseIndex + (int) $offset] = $value;
        }

        return $shifted;
    }

    private static function baseColumnIndex($integrationDetails)
    {
        $baseColumn = preg_replace('/[^A-Za-z]/', '', $integrationDetails->headerRow ?? 'A1');

        return empty($baseColumn) ? 0 : self::excelColumnToIndex($baseColumn);
    }

    private static function a1Sheet($worksheetName)
    {
        return "'" . str_replace("'", "''", $worksheetName) . "'";
    }

    private static function findRowToUpdate($sheetValues, $columnToMatch, $valueToMatch)
    {
        foreach ($sheetValues as $rowIndex => $rowValues) {
            if (isset($rowValues[$columnToMatch]) && (string) $rowValues[$columnToMatch] === $valueToMatch) {
                return ['matchedRow' => $rowIndex, 'values' => (array) $rowValues];
            }
        }

        return ['matchedRow' => -1, 'values' => []];
    }

    private static function fetchSheetValues($spreadsheetId, $worksheetName, $headers)
    {
        $apiResponse = HttpHelper::get(self::BASE_URL . "/spreadsheets/{$spreadsheetId}/values/" . rawurlencode(self::a1Sheet($worksheetName)), null, $headers);

        if (!\is_object($apiResponse) || empty($apiResponse->values)) {
            return [];
        }

        return array_map(function ($row) {
            return (array) $row;
        }, (array) $apiResponse->values);
    }

    private static function sheetIdByTitle($spreadsheetId, $worksheetName, $headers)
    {
        $apiResponse = HttpHelper::get(self::BASE_URL . "/spreadsheets/{$spreadsheetId}?fields=sheets.properties", null, $headers);

        if (!\is_object($apiResponse) || empty($apiResponse->sheets)) {
            return null;
        }

        foreach ($apiResponse->sheets as $sheet) {
            if (($sheet->properties->title ?? '') === $worksheetName) {
                return $sheet->properties->sheetId ?? null;
            }
        }

        return null;
    }

    private static function columnIndexToLetter($columnIndex)
    {
        ++$columnIndex;
        $letter = '';
        while ($columnIndex > 0) {
            --$columnIndex;
            $letter = \chr($columnIndex % 26 + 65) . $letter;
            $columnIndex = (int) ($columnIndex / 26);
        }

        return $letter;
    }

    private static function excelColumnToIndex($column)
    {
        $column = strtoupper($column);
        $index = 0;
        for ($i = 0; $i < \strlen($column); ++$i) {
            $index = $index * 26 + (\ord($column[$i]) - \ord('A') + 1);
        }

        return $index - 1;
    }

    private static function authHeader($integrationDetails)
    {
        $accessToken = $integrationDetails->tokenDetails->access_token ?? '';

        if (empty($accessToken)) {
            return self::failure(__('Google Sheet authorization token is missing', 'bit-integrations-pro'));
        }

        return [
            'Authorization' => "Bearer {$accessToken}",
            'Content-Type'  => 'application/json',
        ];
    }

    private static function formatResponse($apiResponse, $successMessage)
    {
        if (is_wp_error($apiResponse)) {
            return self::failure($apiResponse->get_error_message());
        }

        if (\is_object($apiResponse) && !empty($apiResponse->error)) {
            return self::failure($apiResponse->error->message ?? __('Unknown error', 'bit-integrations-pro'));
        }

        return ['success' => true, 'message' => $successMessage, 'data' => $apiResponse];
    }

    private static function failure($message)
    {
        return ['success' => false, 'message' => $message];
    }
}
