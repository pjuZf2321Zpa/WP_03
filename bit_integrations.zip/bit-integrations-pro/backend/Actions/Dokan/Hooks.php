<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Actions\Dokan\DokanRecordHelper;
use BitApps\IntegrationsPro\Config;
use BitApps\IntegrationsPro\Core\Util\Hooks;

// Deprecated since v2.7.8 - use bit_integrations_dokan_* hooks instead
if (bit_integrations_version_below('2.7.8')) {
    Hooks::filter('btcbi_dokan_vendor_crud_actions', [DokanRecordHelper::class, 'vendorCreateActions'], 10, 2);
}

// New hooks since v2.7.8
Hooks::filter(Config::withFreePrefix('dokan_vendor_crud_actions'), [DokanRecordHelper::class, 'vendorCreateActions'], 10, 2);
