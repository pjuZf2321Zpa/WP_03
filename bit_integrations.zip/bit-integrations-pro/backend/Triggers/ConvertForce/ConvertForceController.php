<?php

namespace BitApps\IntegrationsPro\Triggers\ConvertForce;

use BitApps\IntegrationsPro\Config;

final class ConvertForceController
{
    private const POST_TYPE = 'convertforce-popup';

    private const META_KEY = '_convertforce_conversion';

    public static function info()
    {
        return [
            'name'              => 'ConvertForce Popup Builder',
            'type'              => 'custom_form_submission',
            'is_active'         => self::isPluginInstalled(),
            'documentation_url' => '#',
            'tutorial_url'      => '#',
            'tasks'             => [
                'action' => 'convert-force/get',
                'method' => 'get',
            ],
            'fetch' => [
                'action' => 'trigger/test',
                'method' => 'post',
            ],
            'fetch_remove' => [
                'action' => 'trigger/test/remove',
                'method' => 'post',
            ],
            'isPro' => true
        ];
    }

    public function getAllTasks()
    {
        if (!self::isPluginInstalled()) {
            wp_send_json_error(\sprintf(__('%s is not installed or activated', 'bit-integrations-pro'), 'ConvertForce Popup Builder'));
        }

        wp_send_json_success(StaticData::tasks());
    }

    public static function campaignCreated($postId, $post, $update): void
    {
        if ($update || !self::isConvertForceCampaign($post)) {
            return;
        }

        self::flowExecute('convert_force_campaign_created', self::getCampaignData((int) $postId, $post));
    }

    public static function campaignUpdated($postId, $post, $update): void
    {
        if (!$update || !self::isConvertForceCampaign($post)) {
            return;
        }

        self::flowExecute('convert_force_campaign_updated', self::getCampaignData((int) $postId, $post));
    }

    public static function campaignStatusChanged($newStatus, $oldStatus, $post): void
    {
        if ($newStatus === $oldStatus || !self::isConvertForceCampaign($post)) {
            return;
        }

        $data = array_merge(
            self::getCampaignData((int) $post->ID, $post),
            [
                'old_status' => $oldStatus,
                'new_status' => $newStatus,
            ]
        );

        self::flowExecute('convert_force_campaign_status_changed', $data);
    }

    public static function campaignDeleted($postId, $post = null): void
    {
        $post = $post instanceof \WP_Post ? $post : get_post($postId);

        if (!self::isConvertForceCampaign($post)) {
            return;
        }

        self::flowExecute('convert_force_campaign_deleted', self::getCampaignData((int) $postId, $post));
    }

    private static function flowExecute($entityId, $data)
    {
        $helperClass = bit_integrations_get_class('Core\\Util\\Helper');
        $flowClass = bit_integrations_get_class('Flow\\Flow');

        $formData = $helperClass::prepareFetchFormatFields($data);

        if (empty($formData) || !\is_array($formData)) {
            return;
        }

        $helperClass::setTestData(Config::withFreePrefix("{$entityId}_test"), array_values($formData));

        $flows = $flowClass::exists('ConvertForce', $entityId);

        if (!$flows) {
            return;
        }

        $data = array_column($formData, 'value', 'name');

        $flowClass::execute('ConvertForce', $entityId, $data, $flows);

        return ['type' => 'success'];
    }

    private static function isPluginInstalled(): bool
    {
        return \defined('CONVERTFORCE_VERSION');
    }

    private static function isConvertForceCampaign($post): bool
    {
        return $post instanceof \WP_Post && $post->post_type === self::POST_TYPE;
    }

    private static function getCampaignData(int $postId, $post = null): array
    {
        $post = $post instanceof \WP_Post ? $post : get_post($postId);

        if (!$post) {
            return [];
        }

        $meta = get_post_meta($postId, self::META_KEY, true);

        return [
            'campaign_id'        => $post->ID,
            'title'              => get_the_title($post),
            'content'            => $post->post_content,
            'status'             => $post->post_status,
            'author_id'          => (int) $post->post_author,
            'created_at'         => $post->post_date,
            'updated_at'         => $post->post_modified,
            'meta'               => \is_array($meta) ? $meta : [],
            'display_options'    => \is_array($meta) ? ($meta['displayOptions'] ?? []) : [],
            'display_conditions' => \is_array($meta) ? ($meta['displayConditions'] ?? []) : [],
            'post'               => json_decode(wp_json_encode($post), true),
        ];
    }
}
