<?php

if (!defined('ABSPATH')) {
    exit;
}
    
use BitApps\IntegrationsPro\Core\Util\Hooks;
use BitApps\IntegrationsPro\Triggers\BetterMessages\BetterMessagesController;

Hooks::add('better_messages_message_sent', [BetterMessagesController::class, 'handleNewMessageReceived'], 10, 1);
