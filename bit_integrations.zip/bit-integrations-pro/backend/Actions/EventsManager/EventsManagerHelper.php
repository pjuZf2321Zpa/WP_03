<?php

namespace BitApps\IntegrationsPro\Actions\EventsManager;

/**
 * Shared helpers for the Events Manager action handlers.
 *
 * Ported from bit-pi's EventsManagerHelper/EventsManagerServices, with the bit-pi
 * status_code envelope replaced by the success/message envelope Bit Integrations logs.
 */
final class EventsManagerHelper
{
    /**
     * Booking statuses, as Events Manager defines them in EM_Booking::$status_array.
     */
    public const STATUS_REJECTED = 2;

    public const STATUS_CANCELLED = 3;

    /**
     * Events Manager marks a live event with event_status = 1.
     */
    public const EVENT_STATUS_ACTIVE = 1;

    /**
     * Sentinel meaning "every active event the user is booked into".
     */
    public const ALL_EVENTS = '-1';

    public static function isPluginActive()
    {
        return class_exists('EM_Events');
    }

    /**
     * Verify every required key is present and non-empty.
     *
     * @param array $fieldData
     * @param array $required
     *
     * @return null|array Error envelope listing the missing keys, null when satisfied
     */
    public static function requireFields($fieldData, array $required)
    {
        $missing = [];

        foreach ($required as $key) {
            if (!isset($fieldData[$key]) || $fieldData[$key] === '' || $fieldData[$key] === null) {
                $missing[] = $key;
            }
        }

        if (!empty($missing)) {
            return self::errorResponse(
                // translators: %s: comma separated field names
                wp_sprintf(__('Missing required field(s): %s', 'bit-integrations-pro'), implode(', ', $missing))
            );
        }
    }

    public static function errorResponse($message)
    {
        return [
            'success' => false,
            'message' => $message
        ];
    }

    public static function successResponse($message, $data = [])
    {
        return [
            'success' => true,
            'message' => $message,
            'data'    => $data
        ];
    }
}
