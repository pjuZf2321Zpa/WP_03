<?php

namespace WPAICG\Lib\AutoGPT\Actions;

use WP_Error;
use WPAICG\Core\AIPKit_OpenAI_Reasoning;
use WPAICG\Utils\AIPKit_Prompt_Sanitizer;
use WPAICG\AutoGPT\Cron\EventProcessor\Trigger;

if (!defined('ABSPATH')) {
    exit;
}

/** Builds and validates Rewrite Content automation settings. */
function build_task_config_enhancement_logic(array $post_data)
{
    $task_config = [];
    $task_config['post_content_format'] = ($post_data['post_content_format'] ?? '') === 'gutenberg' ? 'gutenberg' : 'html';
    $task_config['post_types'] = isset($post_data['post_types']) && is_array($post_data['post_types']) ? array_map('sanitize_key', $post_data['post_types']) : [];
    $task_config['post_categories'] = isset($post_data['post_categories']) && is_array($post_data['post_categories']) ? array_map('absint', $post_data['post_categories']) : [];
    $task_config['post_authors'] = isset($post_data['post_authors']) && is_array($post_data['post_authors']) ? array_map('absint', $post_data['post_authors']) : [];
    $task_config['post_statuses'] = isset($post_data['post_statuses']) && is_array($post_data['post_statuses']) ? array_map('sanitize_key', $post_data['post_statuses']) : ['publish'];

    // Fields to enhance (respect explicit '1'/'0' values from frontend)
    $task_config['update_title'] = (isset($post_data['update_title']) && $post_data['update_title'] === '1') ? '1' : '0';
    $task_config['update_excerpt'] = (isset($post_data['update_excerpt']) && $post_data['update_excerpt'] === '1') ? '1' : '0';
    $task_config['update_meta'] = (isset($post_data['update_meta']) && $post_data['update_meta'] === '1') ? '1' : '0';
    $task_config['update_content'] = (isset($post_data['update_content']) && $post_data['update_content'] === '1') ? '1' : '0';

    // Prompts
    $task_config['title_prompt'] = isset($post_data['title_prompt']) ? AIPKit_Prompt_Sanitizer::sanitize(wp_unslash($post_data['title_prompt'])) : '';
    $task_config['excerpt_prompt'] = isset($post_data['excerpt_prompt']) ? AIPKit_Prompt_Sanitizer::sanitize(wp_unslash($post_data['excerpt_prompt'])) : '';
    $task_config['meta_prompt'] = isset($post_data['meta_prompt']) ? AIPKit_Prompt_Sanitizer::sanitize(wp_unslash($post_data['meta_prompt'])) : '';
    $task_config['content_prompt'] = isset($post_data['content_prompt']) ? AIPKit_Prompt_Sanitizer::sanitize(wp_unslash($post_data['content_prompt'])) : '';

    // AI Settings
    $provider_raw = $post_data['ai_provider'] ?? 'openai';
    switch (strtolower($provider_raw)) {
        case 'openai':
            $task_config['ai_provider'] = 'OpenAI';
            break;
        case 'openrouter':
            $task_config['ai_provider'] = 'OpenRouter';
            break;
        case 'google':
            $task_config['ai_provider'] = 'Google';
            break;
        case 'azure':
            $task_config['ai_provider'] = 'Azure';
            break;
        case 'claude':
            $task_config['ai_provider'] = 'Claude';
            break;
        case 'deepseek':
            $task_config['ai_provider'] = 'DeepSeek';
            break;
        case 'xai':
            $task_config['ai_provider'] = 'xAI';
            break;
        case 'ollama':
            $task_config['ai_provider'] = 'Ollama';
            break;
        default:
            $task_config['ai_provider'] = \WPAICG\AIPKit_Providers::normalize_provider_label((string) $provider_raw);
            break;
    }
    $task_config['ai_model'] = $post_data['ai_model'] ?? '';
    $task_config['ai_temperature'] = isset($post_data['ai_temperature']) ? floatval($post_data['ai_temperature']) : 1.0;
    $task_config['content_max_tokens'] = isset($post_data['content_max_tokens']) ? absint($post_data['content_max_tokens']) : 4000;
    $reasoning_effort = AIPKit_OpenAI_Reasoning::sanitize_effort($post_data['reasoning_effort'] ?? '');
    $task_config['reasoning_effort'] = $reasoning_effort !== '' ? $reasoning_effort : 'none';

    // Task Frequency
    $task_config['task_frequency'] = isset($post_data['task_frequency']) ? sanitize_key($post_data['task_frequency']) : 'daily';

    // One-time run flag (explicit value)
    $task_config['enhance_existing_now_flag'] = (isset($post_data['enhance_existing_now_flag']) && $post_data['enhance_existing_now_flag'] === '1') ? '1' : '0';

    $task_config['enable_vector_store'] = isset($post_data['enable_vector_store']) && $post_data['enable_vector_store'] === '1' ? '1' : '0';
    if ($task_config['enable_vector_store'] === '1') {
        $task_config['vector_store_provider'] = isset($post_data['vector_store_provider']) ? sanitize_key($post_data['vector_store_provider']) : 'openai';
        $task_config['vector_store_top_k'] = isset($post_data['vector_store_top_k']) ? absint($post_data['vector_store_top_k']) : 3;

        if ($task_config['vector_store_provider'] === 'openai') {
            $task_config['openai_vector_store_ids'] = isset($post_data['openai_vector_store_ids']) && is_array($post_data['openai_vector_store_ids']) ? array_map('sanitize_text_field', $post_data['openai_vector_store_ids']) : [];
        } elseif ($task_config['vector_store_provider'] === 'google') {
            $task_config['google_file_search_store_names'] = isset($post_data['google_file_search_store_names']) && is_array($post_data['google_file_search_store_names'])
                ? array_values(array_unique(array_filter(array_map(
                    static function ($store_name): string {
                        $store_name = sanitize_text_field((string) $store_name);
                        return strpos($store_name, 'fileSearchStores/') === 0 ? $store_name : '';
                    },
                    $post_data['google_file_search_store_names']
                ))))
                : [];
        } elseif ($task_config['vector_store_provider'] === 'pinecone') {
            $task_config['pinecone_index_name'] = isset($post_data['pinecone_index_name']) ? sanitize_text_field($post_data['pinecone_index_name']) : '';
        } elseif ($task_config['vector_store_provider'] === 'qdrant') {
            $task_config['qdrant_collection_name'] = isset($post_data['qdrant_collection_name']) ? sanitize_text_field($post_data['qdrant_collection_name']) : '';
        } elseif ($task_config['vector_store_provider'] === 'chroma') {
            $task_config['chroma_collection_name'] = isset($post_data['chroma_collection_name']) ? sanitize_text_field($post_data['chroma_collection_name']) : '';
        } elseif ($task_config['vector_store_provider'] === 'local') {
            $task_config['local_store_id'] = isset($post_data['local_store_id']) ? sanitize_text_field($post_data['local_store_id']) : '';
        }

        if (
            $task_config['vector_store_provider'] === 'local' ||
            $task_config['vector_store_provider'] === 'pinecone' ||
            $task_config['vector_store_provider'] === 'qdrant' ||
            $task_config['vector_store_provider'] === 'chroma'
        ) {
            $task_config['vector_embedding_provider'] = isset($post_data['vector_embedding_provider']) ? sanitize_key($post_data['vector_embedding_provider']) : 'openai';
            $task_config['vector_embedding_model'] = isset($post_data['vector_embedding_model']) ? sanitize_text_field($post_data['vector_embedding_model']) : '';
        }

        $has_vector_source = false;
        if ($task_config['vector_store_provider'] === 'openai') {
            $has_vector_source = !empty($task_config['openai_vector_store_ids']);
        } elseif ($task_config['vector_store_provider'] === 'google') {
            $has_vector_source = !empty($task_config['google_file_search_store_names']);
        } elseif ($task_config['vector_store_provider'] === 'pinecone') {
            $has_vector_source = !empty($task_config['pinecone_index_name']);
        } elseif ($task_config['vector_store_provider'] === 'qdrant') {
            $has_vector_source = !empty($task_config['qdrant_collection_name']);
        } elseif ($task_config['vector_store_provider'] === 'chroma') {
            $has_vector_source = !empty($task_config['chroma_collection_name']);
        } elseif ($task_config['vector_store_provider'] === 'local') {
            $has_vector_source = !empty($task_config['local_store_id']);
        }
        if (!$has_vector_source) {
            return new WP_Error('missing_vector_source_enhance', __('Please select a knowledge source before enabling context.', 'gpt3-ai-content-generator'), ['status' => 400]);
        }
        if ($task_config['vector_store_provider'] === 'google' && ($task_config['ai_provider'] ?? '') !== 'Google') {
            return new WP_Error('google_file_search_provider_mismatch', __('Google File Search requires Google as the AI provider.', 'gpt3-ai-content-generator'), ['status' => 400]);
        }
    }

    // Validation
    if (empty($task_config['post_types'])) {
        return new WP_Error('missing_post_types_enhance', __('Please select at least one post type to update.', 'gpt3-ai-content-generator'));
    }
    if ($task_config['update_title'] !== '1' && $task_config['update_excerpt'] !== '1' && $task_config['update_meta'] !== '1' && $task_config['update_content'] !== '1') {
        return new WP_Error('no_enhancement_selected', __('Please select at least one field to update (Title, Excerpt, Content, or Meta Description).', 'gpt3-ai-content-generator'));
    }

    return $task_config;
}

/** Queues all matching content for a manual Rewrite Content run. */
function run_now_content_enhancement_logic(int $task_id, array $task_config): void
{
    // The logic to queue posts for enhancement is the same whether it's a scheduled run or a "Run Now" trigger.
    if (function_exists('\WPAICG\AutoGPT\Cron\EventProcessor\Trigger\trigger_content_enhancement_task_logic')) {
        // For "Run Now", we always pass null for last_run_time to get all posts matching criteria.
        Trigger\trigger_content_enhancement_task_logic($task_id, $task_config, null);
    }
}

/** Queues an initial rewrite and consumes its one-time flag. */
function finalize_enhancement_save_logic(int $task_id, array $task_config): void
{
    // Queue all existing content immediately. The last_run_time is null.
    Trigger\trigger_content_enhancement_task_logic($task_id, $task_config, null);

    // Disable the flag so it doesn't run again on the next cron trigger.
    global $wpdb;
    $tasks_table_name = $wpdb->prefix . 'aipkit_automated_tasks';
    $task_config['enhance_existing_now_flag'] = '0';
    // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Reason: Direct update to a custom table is necessary to update task state.
    $wpdb->update(
        $tasks_table_name,
        ['task_config' => wp_json_encode($task_config)],
        ['id' => $task_id],
        ['%s'],
        ['%d']
    );
}
