<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Actions\QuizMaker\QuizMakerProHelper;
use BitApps\IntegrationsPro\Config;
use BitApps\IntegrationsPro\Core\Util\Hooks;

Hooks::filter(Config::withFreePrefix('quiz_maker_create_quiz'), [QuizMakerProHelper::class, 'createQuiz'], 10, 4);
Hooks::filter(Config::withFreePrefix('quiz_maker_update_quiz'), [QuizMakerProHelper::class, 'updateQuiz'], 10, 4);
Hooks::filter(Config::withFreePrefix('quiz_maker_change_quiz_status'), [QuizMakerProHelper::class, 'changeQuizStatus'], 10, 3);
Hooks::filter(Config::withFreePrefix('quiz_maker_delete_quiz'), [QuizMakerProHelper::class, 'deleteQuiz'], 10, 2);
Hooks::filter(Config::withFreePrefix('quiz_maker_create_question'), [QuizMakerProHelper::class, 'createQuestion'], 10, 4);
Hooks::filter(Config::withFreePrefix('quiz_maker_update_question'), [QuizMakerProHelper::class, 'updateQuestion'], 10, 4);
Hooks::filter(Config::withFreePrefix('quiz_maker_change_question_status'), [QuizMakerProHelper::class, 'changeQuestionStatus'], 10, 3);
Hooks::filter(Config::withFreePrefix('quiz_maker_delete_question'), [QuizMakerProHelper::class, 'deleteQuestion'], 10, 2);
Hooks::filter(Config::withFreePrefix('quiz_maker_create_quiz_category'), [QuizMakerProHelper::class, 'createQuizCategory'], 10, 3);
Hooks::filter(Config::withFreePrefix('quiz_maker_update_quiz_category'), [QuizMakerProHelper::class, 'updateQuizCategory'], 10, 3);
Hooks::filter(Config::withFreePrefix('quiz_maker_delete_quiz_category'), [QuizMakerProHelper::class, 'deleteQuizCategory'], 10, 2);
Hooks::filter(Config::withFreePrefix('quiz_maker_create_question_category'), [QuizMakerProHelper::class, 'createQuestionCategory'], 10, 3);
Hooks::filter(Config::withFreePrefix('quiz_maker_update_question_category'), [QuizMakerProHelper::class, 'updateQuestionCategory'], 10, 3);
Hooks::filter(Config::withFreePrefix('quiz_maker_delete_question_category'), [QuizMakerProHelper::class, 'deleteQuestionCategory'], 10, 2);
Hooks::filter(Config::withFreePrefix('quiz_maker_create_result'), [QuizMakerProHelper::class, 'createResult'], 10, 3);
Hooks::filter(Config::withFreePrefix('quiz_maker_mark_result_as_read'), [QuizMakerProHelper::class, 'markResultAsRead'], 10, 2);
Hooks::filter(Config::withFreePrefix('quiz_maker_delete_result'), [QuizMakerProHelper::class, 'deleteResult'], 10, 2);
Hooks::filter(Config::withFreePrefix('quiz_maker_create_review'), [QuizMakerProHelper::class, 'createReview'], 10, 3);
Hooks::filter(Config::withFreePrefix('quiz_maker_delete_review'), [QuizMakerProHelper::class, 'deleteReview'], 10, 2);
Hooks::filter(Config::withFreePrefix('quiz_maker_create_question_report'), [QuizMakerProHelper::class, 'createQuestionReport'], 10, 3);
Hooks::filter(Config::withFreePrefix('quiz_maker_resolve_question_report'), [QuizMakerProHelper::class, 'resolveQuestionReport'], 10, 2);
Hooks::filter(Config::withFreePrefix('quiz_maker_delete_question_report'), [QuizMakerProHelper::class, 'deleteQuestionReport'], 10, 2);
