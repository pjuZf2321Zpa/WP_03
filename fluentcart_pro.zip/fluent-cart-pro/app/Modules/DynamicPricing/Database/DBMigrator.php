<?php

namespace FluentCartPro\App\Modules\DynamicPricing\Database;

use FluentCartPro\App\Database\DBMigrator as BaseDBMigrator;
use FluentCartPro\App\Modules\DynamicPricing\Database\Migrations\AppliedPricingRulesMigrator;
use FluentCartPro\App\Modules\DynamicPricing\Database\Migrations\PricingRulesMigrator;

class DBMigrator extends BaseDBMigrator
{
    public function migrate()
    {
        PricingRulesMigrator::migrate();
        AppliedPricingRulesMigrator::migrate();
    }

    public function dropTable()
    {
        PricingRulesMigrator::dropTable();
        AppliedPricingRulesMigrator::dropTable();
    }
}
