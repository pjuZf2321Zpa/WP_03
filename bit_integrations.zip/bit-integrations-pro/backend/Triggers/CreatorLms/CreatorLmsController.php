<?php

namespace BitApps\IntegrationsPro\Triggers\CreatorLms;

use BitApps\IntegrationsPro\Config;
use Throwable;

final class CreatorLmsController
{
    public static function info()
    {
        return [
            'name'              => 'Creator LMS',
            'type'              => 'custom_form_submission',
            'is_active'         => self::isPluginInstalled(),
            'tutorial_url'      => '#',
            'tasks'             => [
                'action' => 'creator-lms/get',
                'method' => 'get',
            ],
            'fetch' => [
                'action' => 'trigger/test',
                'method' => 'post',
            ],
            'fetch_remove' => [
                'action' => 'trigger/test/remove',
                'method' => 'post',
            ],
            'isPro' => true,
        ];
    }

    public function getAllEvents()
    {
        if (!self::isPluginInstalled()) {
            wp_send_json_error(\sprintf(__('%s is not installed or activated', 'bit-integrations-pro'), 'Creator LMS'));
        }

        wp_send_json_success(StaticData::events());
    }

    /**
     * Handle student enrolled in course trigger.
     * Supports two hooks:
     * - creator_lms_after_enrolled_student($order_id)
     * - creator_lms_manual_student_enrollment($student_id, $course_id)
     *
     * @param mixed $arg1
     * @param mixed $arg2
     * @param mixed $arg3
     */
    public static function studentEnrolledInCourse($arg1, $arg2 = null, $arg3 = null)
    {
        [$studentId, $courseId, $orderId] = self::resolveEnrollmentIds($arg1, $arg2, $arg3);

        if (!$studentId || !$courseId) {
            return;
        }

        self::flowExecute('creator_lms_after_enrolled_student', self::buildBaseEventData($studentId, $courseId, $orderId));
    }

    public static function studentCompletedCourse($studentId, $courseId, $orderId = 0)
    {
        $studentId = (int) $studentId;
        $courseId = (int) $courseId;

        if (!$studentId || !$courseId) {
            return;
        }

        self::flowExecute('creator_lms_course_completed', self::buildBaseEventData($studentId, $courseId, (int) $orderId));
    }

    public static function studentCompletedLesson($lessonId, $courseId, $studentId)
    {
        $lessonId = (int) $lessonId;
        $courseId = (int) $courseId;
        $studentId = (int) $studentId;

        if (!$lessonId || !$courseId || !$studentId) {
            return;
        }

        $data = array_merge(
            [
                'student_id'      => $studentId,
                'course_id'       => $courseId,
                'completion_date' => current_time('mysql'),
            ],
            self::getUserInfo($studentId),
            self::getCourseData($courseId),
            self::getLessonData($lessonId)
        );

        self::flowExecute('creator_lms_lesson_completed', $data);
    }

    public static function courseCreated($courseId)
    {
        $courseId = (int) $courseId;

        if (!$courseId) {
            return;
        }

        $data = array_merge(
            ['course_id' => $courseId, 'created_at' => current_time('mysql')],
            self::getCourseData($courseId),
            self::getUserInfo(get_current_user_id())
        );

        self::flowExecute('creatorlms_new_course', $data);
    }

    public static function courseUpdated($courseId)
    {
        $courseId = (int) $courseId;

        if (!$courseId) {
            return;
        }

        $data = array_merge(
            ['course_id' => $courseId, 'updated_at' => current_time('mysql')],
            self::getCourseData($courseId),
            self::getUserInfo(get_current_user_id())
        );

        self::flowExecute('creatorlms_update_course', $data);
    }

    /**
     * Resolve student ID, course ID, and order ID from the two possible hook signatures.
     *
     * @param mixed $arg1
     * @param mixed $arg2
     * @param mixed $arg3
     *
     * @return array{0: int, 1: int, 2: int} [$studentId, $courseId, $orderId]
     */
    private static function resolveEnrollmentIds($arg1, $arg2, $arg3)
    {
        if (is_numeric($arg1) && is_numeric($arg2)) {
            return [(int) $arg1, (int) $arg2, is_numeric($arg3) ? (int) $arg3 : 0];
        }

        $orderId = (int) $arg1;
        $enrollment = self::getEnrollmentByOrderId($orderId);

        return [
            $enrollment ? (int) $enrollment['user_id'] : 0,
            $enrollment ? (int) $enrollment['course_id'] : 0,
            $orderId,
        ];
    }

    /**
     * Fetch the most recent enrollment row for a given order ID.
     *
     * @param int $orderId
     *
     * @return array<string, mixed>|null
     */
    private static function getEnrollmentByOrderId($orderId)
    {
        global $wpdb;

        $table = $wpdb->prefix . 'crlms_user_enrollment';

        return $wpdb->get_row(
            $wpdb->prepare(
                "SELECT * FROM {$table} WHERE order_id = %d ORDER BY id DESC LIMIT 1",
                $orderId
            ),
            ARRAY_A
        ) ?: null;
    }

    private static function buildBaseEventData($studentId, $courseId, $orderId = 0)
    {
        return array_merge(
            [
                'student_id' => $studentId,
                'course_id'  => $courseId,
                'order_id'   => $orderId,
                'timestamp'  => current_time('mysql'),
            ],
            self::getUserInfo($studentId),
            self::getCourseData($courseId)
        );
    }

    private static function getLessonData($lessonId)
    {
        $post = get_post($lessonId);

        return [
            'lesson_id'        => $post ? $post->ID : $lessonId,
            'lesson_title'     => $post ? $post->post_title : '',
            'lesson_permalink' => $post ? get_permalink($post->ID) : '',
            'lesson_status'    => $post ? $post->post_status : '',
        ];
    }

    private static function getUserInfo($userId)
    {
        return bit_integrations_get_class('Core\\Util\\User')::get($userId);
    }

    private static function getCourseData($courseId)
    {
        if (!$courseId) {
            return [];
        }

        if (\function_exists('crlms_get_course')) {
            try {
                $course = crlms_get_course($courseId);

                if ($course) {
                    return [
                        'course_id'          => $course->get_id(),
                        'course_title'       => $course->get_name(),
                        'course_description' => $course->get_description(),
                        'course_permalink'   => $course->get_permalink(),
                        'course_status'      => $course->get_status(),
                    ];
                }
            } catch (Throwable $e) {
            // Fall through to WP post fallback.
            }
        }

        $post = get_post($courseId);

        if (!$post) {
            return [];
        }

        return [
            'course_id'          => $post->ID,
            'course_title'       => $post->post_title,
            'course_description' => $post->post_content,
            'course_permalink'   => get_permalink($post->ID),
            'course_status'      => $post->post_status,
        ];
    }

    private static function flowExecute($entityId, $data)
    {
        $helperClass = bit_integrations_get_class('Core\\Util\\Helper');
        $flowClass = bit_integrations_get_class('Flow\\Flow');

        $formData = $helperClass::prepareFetchFormatFields($data);

        if (empty($formData) || !\is_array($formData)) {
            return;
        }

        $helperClass::setTestData(Config::withFreePrefix("{$entityId}_test"), array_values($formData));

        $flows = $flowClass::exists('CreatorLms', $entityId);

        if (!$flows) {
            return;
        }

        $flowClass::execute('CreatorLms', $entityId, array_column($formData, 'value', 'name'), $flows);
    }

    private static function isPluginInstalled()
    {
        return class_exists('CreatorLms') && \function_exists('crlms_get_course');
    }
}
