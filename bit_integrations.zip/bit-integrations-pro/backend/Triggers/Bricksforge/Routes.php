<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Core\Util\Route;
use BitApps\IntegrationsPro\Triggers\Bricksforge\BricksforgeController;

Route::get('bricksforge/get', [BricksforgeController::class, 'getAllTasks']);
