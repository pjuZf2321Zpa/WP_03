<?php

namespace MasterStudy\Lms\Pro\addons\certificate_builder\Http\Controllers\Admin;

use MasterStudy\Lms\Http\WpResponseFactory;
use MasterStudy\Lms\Pro\addons\certificate_builder\Http\Serializers\CertificateAdminSerializer;
use MasterStudy\Lms\Pro\addons\certificate_builder\Repositories\CertificateAdminAccess;
use MasterStudy\Lms\Pro\addons\certificate_builder\Repositories\CertificateAdminRepository;
use MasterStudy\Lms\Validation\Validator;
use WP_REST_Request;
use WP_REST_Response;

final class GetCertificatesController {
	public function __invoke( WP_REST_Request $request ): WP_REST_Response {
		if ( ! CertificateAdminAccess::can_access() ) {
			return WpResponseFactory::forbidden();
		}

		$validator = new Validator(
			$request->get_params(),
			array(
				'per_page'   => 'nullable|integer',
				'page'       => 'nullable|integer',
				'search'     => 'nullable|string',
				'instructor' => 'nullable|integer',
				'sort'       => 'nullable|string',
			)
		);

		if ( $validator->fails() ) {
			return WpResponseFactory::validation_failed( $validator->get_errors_array() );
		}

		$data                 = ( new CertificateAdminRepository() )->get_list( $validator->get_validated() );
		$data['certificates'] = ( new CertificateAdminSerializer() )->collectionToArray( $data['posts'] );
		unset( $data['posts'] );

		return WpResponseFactory::ok_with_data( $data );
	}
}
