<?php

namespace BitApps\IntegrationsPro\Core\Util;

use BitApps\IntegrationsPro\Config;
use ReflectionMethod;

final class Route
{
    private static $_prefix = 'bit_integrations_';

    private static $_invokeable;

    public static function get($hook, $invokeable)
    {
        return static::request('GET', $hook, $invokeable);
    }

    public static function post($hook, $invokeable)
    {
        return static::request('POST', $hook, $invokeable);
    }

    public static function request($method, $hook, $invokeable)
    {
        $action = $_REQUEST['action'] ?? $_POST['action'] ?? $_GET['action'] ?? null;
        $action = sanitize_text_field($action);

        if (
            (isset($_SERVER['REQUEST_METHOD']) && sanitize_text_field($_SERVER['REQUEST_METHOD']) != $method)
            || empty($action)
            || (!empty($action) && strpos($action, $hook) === false)
        ) {
            return;
        }

        static::$_invokeable[static::$_prefix . $hook][$method] = $invokeable;

        Hooks::add('wp_ajax_' . static::$_prefix . $hook, [__CLASS__, 'action']);
    }

    public static function action()
    {
        $action = $_REQUEST['action'] ?? $_POST['action'] ?? $_GET['action'] ?? null;
        $action = sanitize_text_field($action);

        $sanitizedMethod = sanitize_text_field($_SERVER['REQUEST_METHOD']);
        $requestMethod = \in_array($sanitizedMethod, ['GET', 'POST']) ? $sanitizedMethod : 'POST';

        if (isset($_REQUEST['_ajax_nonce']) && wp_verify_nonce(sanitize_text_field($_REQUEST['_ajax_nonce']), Config::withFreePrefix('nonce'))) {
            $invokeable = static::$_invokeable[$action][$requestMethod];
            unset($_POST['_ajax_nonce'], $_POST['action'], $_GET['_ajax_nonce'], $_GET['action']);

            // A nonce proves origin, not authority: Pro routes carry no capability check of their own.
            if (!static::hasWriteAccess()) {
                wp_send_json_error(
                    __('You do not have permission to perform this action.', 'bit-integrations-pro'),
                    403
                );
            }

            if (method_exists($invokeable[0], $invokeable[1])) {
                if ($requestMethod == 'POST') {
                    if (isset($_SERVER['CONTENT_TYPE']) && strpos(sanitize_text_field($_SERVER['CONTENT_TYPE']), 'form-data') === false && strpos(sanitize_text_field($_SERVER['CONTENT_TYPE']), 'x-www-form-urlencoded') === false) {
                        $inputJSON = file_get_contents('php://input');
                        $data = \is_string($inputJSON) ? json_decode($inputJSON) : $inputJSON;
                    } elseif ($_POST['data']) {
                        $data = \is_string($_POST['data']) ? json_decode(wp_unslash($_POST['data'])) : $_POST['data'];
                    } else {
                        $data = (object) $_POST;
                    }
                } else {
                    $data = (object) $_GET;
                }

                $reflectionMethod = new ReflectionMethod($invokeable[0], $invokeable[1]);
                $response = $reflectionMethod->invoke($reflectionMethod->isStatic() ? null : new $invokeable[0](), $data);

                if (is_wp_error($response)) {
                    wp_send_json_error($response);
                } else {
                    wp_send_json_success($response);
                }
            } else {
                wp_send_json_error('Method doesn\'t exists');
            }
        } else {
            wp_send_json_error(
                __(
                    'Token expired or invalid. Please refresh the page and try again.',
                    'bit-integrations-pro'
                ),
                401
            );
        }
    }

    private static function hasWriteAccess()
    {
        $capabilities = bit_integrations_get_class('Core\\Util\\Capabilities');

        if ($capabilities && method_exists($capabilities, 'hasIntegrationWriteAccess')) {
            return $capabilities::hasIntegrationWriteAccess();
        }

        return current_user_can('manage_options');
    }
}
