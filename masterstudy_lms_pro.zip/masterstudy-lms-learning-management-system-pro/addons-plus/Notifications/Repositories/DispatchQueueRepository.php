<?php

namespace MasterStudy\Lms\Pro\AddonsPlus\Notifications\Repositories;

final class DispatchQueueRepository {
	public const STATUS_PENDING    = 'pending';
	public const STATUS_PROCESSING = 'processing';
	public const STATUS_DONE       = 'done';
	public const STATUS_RETRY      = 'retry';
	public const STATUS_FAILED     = 'failed';
	private const MAX_ATTEMPTS     = 5;
	private const STALE_SECONDS    = 900;

	public function enqueue_recipients( int $notification_id, array $recipient_ids, array $channels, array $context = array(), int $batch_size = 100 ): void {
		$recipient_ids = $this->sanitize_ids( $recipient_ids );
		$batch_size    = min( 500, max( 1, $batch_size ) );

		if ( $notification_id <= 0 || empty( $recipient_ids ) ) {
			return;
		}

		foreach ( array_chunk( $recipient_ids, $batch_size ) as $chunk ) {
			$this->insert(
				$notification_id,
				'explicit',
				0,
				$chunk,
				$channels,
				$context,
				$batch_size,
				hash( 'sha256', 'explicit:' . implode( ',', $chunk ) )
			);
		}
	}

	public function enqueue_target( int $notification_id, string $target_type, int $target_value, array $channels, array $context = array(), int $batch_size = 100 ): void {
		if ( $notification_id <= 0 || $target_value <= 0 ) {
			return;
		}

		$target_type = sanitize_key( $target_type );

		if ( '' === $target_type ) {
			return;
		}

		$this->insert(
			$notification_id,
			$target_type,
			$target_value,
			array(),
			$channels,
			$context,
			min( 500, max( 1, $batch_size ) ),
			hash( 'sha256', "{$target_type}:{$target_value}" )
		);
	}

	public function claim_available( int $limit = 5 ): array {
		global $wpdb;

		$limit    = min( 50, max( 1, $limit ) );
		$now      = gmdate( 'Y-m-d H:i:s' );
		$claim_id = wp_generate_uuid4();
		$queue    = masterstudy_lms_notification_dispatch_queue_table_name( $wpdb );

		$wpdb->query(
			$wpdb->prepare(
				// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				"UPDATE {$queue}
					SET status = %s, claim_id = %s, updated_at_gmt = %s
					WHERE status IN (%s,%s) AND available_at_gmt <= %s
					ORDER BY available_at_gmt ASC, id ASC
					LIMIT %d",
				self::STATUS_PROCESSING,
				$claim_id,
				$now,
				self::STATUS_PENDING,
				self::STATUS_RETRY,
				$now,
				$limit
			)
		);

		if ( $wpdb->rows_affected <= 0 ) {
			return array();
		}

		return $wpdb->get_results(
			$wpdb->prepare(
				// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				"SELECT * FROM {$queue} WHERE claim_id = %s ORDER BY available_at_gmt ASC, id ASC",
				$claim_id
			),
			ARRAY_A
		);
	}

	public function continue_target( int $queue_id, int $next_cursor ): void {
		global $wpdb;

		if ( $queue_id <= 0 ) {
			return;
		}

		$now = gmdate( 'Y-m-d H:i:s' );

		$wpdb->update(
			masterstudy_lms_notification_dispatch_queue_table_name( $wpdb ),
			array(
				'status'           => self::STATUS_PENDING,
				'claim_id'         => '',
				'cursor_value'     => max( 0, $next_cursor ),
				'available_at_gmt' => $now,
				'updated_at_gmt'   => $now,
				'last_error'       => null,
			),
			array( 'id' => $queue_id ),
			array( '%s', '%s', '%d', '%s', '%s', '%s' ),
			array( '%d' )
		);
	}

	public function mark_done( int $queue_id ): void {
		$this->update_status( $queue_id, self::STATUS_DONE );
	}

	public function mark_failed( int $queue_id, int $attempts, string $error, bool $retry = true ): void {
		global $wpdb;

		if ( $queue_id <= 0 ) {
			return;
		}

		$attempts = max( 1, $attempts );
		$status   = $retry && $attempts < self::MAX_ATTEMPTS ? self::STATUS_RETRY : self::STATUS_FAILED;
		$delay    = min( HOUR_IN_SECONDS, (int) pow( 2, $attempts ) * MINUTE_IN_SECONDS );
		$now      = gmdate( 'Y-m-d H:i:s' );

		$wpdb->update(
			masterstudy_lms_notification_dispatch_queue_table_name( $wpdb ),
			array(
				'status'           => $status,
				'claim_id'         => '',
				'attempts'         => $attempts,
				'available_at_gmt' => gmdate( 'Y-m-d H:i:s', time() + $delay ),
				'last_error'       => sanitize_textarea_field( $error ),
				'updated_at_gmt'   => $now,
				'processed_at_gmt' => self::STATUS_FAILED === $status ? $now : null,
			),
			array( 'id' => $queue_id ),
			array( '%s', '%s', '%d', '%s', '%s', '%s', '%s' ),
			array( '%d' )
		);
	}

	public function recover_stale_processing( int $stale_seconds = self::STALE_SECONDS ): int {
		global $wpdb;

		$now     = gmdate( 'Y-m-d H:i:s' );
		$cutoff  = gmdate( 'Y-m-d H:i:s', time() - max( MINUTE_IN_SECONDS, $stale_seconds ) );
		$message = 'Queue claim expired before processing completed.';
		$table   = masterstudy_lms_notification_dispatch_queue_table_name( $wpdb );
		$retried = (int) $wpdb->query(
			$wpdb->prepare(
				// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				"UPDATE {$table}
					SET status = %s,
						claim_id = '',
						available_at_gmt = %s,
						processed_at_gmt = NULL,
						last_error = %s,
						updated_at_gmt = %s,
						attempts = LEAST(attempts + 1, %d)
					WHERE status = %s AND updated_at_gmt <= %s AND attempts + 1 < %d",
				self::STATUS_RETRY,
				$now,
				$message,
				$now,
				self::MAX_ATTEMPTS,
				self::STATUS_PROCESSING,
				$cutoff,
				self::MAX_ATTEMPTS
			)
		);
		$failed = (int) $wpdb->query(
			$wpdb->prepare(
				// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				"UPDATE {$table}
					SET status = %s,
						claim_id = '',
						available_at_gmt = %s,
						processed_at_gmt = %s,
						last_error = %s,
						updated_at_gmt = %s,
						attempts = LEAST(attempts + 1, %d)
					WHERE status = %s AND updated_at_gmt <= %s AND attempts + 1 >= %d",
				self::STATUS_FAILED,
				$now,
				$now,
				$message,
				$now,
				self::MAX_ATTEMPTS,
				self::STATUS_PROCESSING,
				$cutoff,
				self::MAX_ATTEMPTS
			)
		);

		return $retried + $failed;
	}

	public function has_pending(): bool {
		global $wpdb;

		return (bool) $wpdb->get_var(
			$wpdb->prepare(
				// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- Table name is generated from $wpdb->prefix.
				'SELECT 1 FROM ' . masterstudy_lms_notification_dispatch_queue_table_name( $wpdb ) . ' WHERE status IN (%s,%s) LIMIT 1',
				self::STATUS_PENDING,
				self::STATUS_RETRY
			)
		);
	}

	private function insert( int $notification_id, string $target_type, int $target_value, array $recipient_ids, array $channels, array $context, int $batch_size, string $target_hash ): void {
		global $wpdb;

		$now = gmdate( 'Y-m-d H:i:s' );

		$wpdb->query(
			$wpdb->prepare(
				// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- Table name is generated from $wpdb->prefix.
				'INSERT IGNORE INTO ' . masterstudy_lms_notification_dispatch_queue_table_name( $wpdb ) . ' (notification_id,target_type,target_value,target_hash,recipient_ids,channels,context,batch_size,status,available_at_gmt,created_at_gmt,updated_at_gmt)
				VALUES (%d,%s,%d,%s,%s,%s,%s,%d,%s,%s,%s,%s)',
				$notification_id,
				$target_type,
				$target_value,
				$target_hash,
				! empty( $recipient_ids ) ? wp_json_encode( $recipient_ids ) : null,
				implode( ',', $this->normalize_channels( $channels ) ),
				wp_json_encode( $context ),
				$batch_size,
				self::STATUS_PENDING,
				$now,
				$now,
				$now
			)
		);
	}

	private function update_status( int $queue_id, string $status ): void {
		global $wpdb;

		if ( $queue_id <= 0 ) {
			return;
		}

		$now = gmdate( 'Y-m-d H:i:s' );

		$wpdb->update(
			masterstudy_lms_notification_dispatch_queue_table_name( $wpdb ),
			array(
				'status'           => $status,
				'claim_id'         => '',
				'processed_at_gmt' => $now,
				'updated_at_gmt'   => $now,
			),
			array( 'id' => $queue_id ),
			array( '%s', '%s', '%s', '%s' ),
			array( '%d' )
		);
	}

	private function normalize_channels( array $channels ): array {
		$channels = array_filter( array_map( 'sanitize_key', $channels ) );

		return array_values( array_unique( $channels ) );
	}

	private function sanitize_ids( array $ids ): array {
		return array_values( array_unique( array_filter( array_map( 'absint', $ids ) ) ) );
	}
}
