<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Core\Util\Route;
use BitApps\IntegrationsPro\Triggers\Brizy\BrizyController;

Route::get('brizy/get', [BrizyController::class, 'getAllTasks']);
