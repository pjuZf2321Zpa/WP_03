<?php

namespace BitApps\IntegrationsPro\Actions\QuizMaker;

final class QuizMakerProHelper
{
    private const QUESTION_TYPES = [
        'radio', 'checkbox', 'select', 'text', 'short_text', 'number', 'date',
        'true_or_false', 'custom', 'fill_in_blank', 'dropdown_fill_in_blank',
        'matching', 'ranking', 'upload_file',
    ];

    public static function createQuiz($defaultResponse, $fieldData, $utilities = null, $integrationDetails = null)
    {
        if (!self::isQuizMakerActive()) {
            return self::errorResponse(__('Quiz Maker is not installed or activated', 'bit-integrations-pro'));
        }

        if (empty($fieldData['title'])) {
            return self::errorResponse(__('Quiz title is required', 'bit-integrations-pro'));
        }

        $authorId = get_current_user_id();
        $columns = self::pick($fieldData, ['title', 'description', 'quiz_image', 'quiz_url']);
        $columns['description'] = $columns['description'] ?? '';
        $columns['ordering'] = isset($fieldData['ordering']) ? (int) $fieldData['ordering'] : 0;
        $columns['quiz_category_id'] = isset($integrationDetails->selectedQuizCategory) ? (int) $integrationDetails->selectedQuizCategory : 0;
        $columns['question_ids'] = implode(',', self::toIdList($integrationDetails->selectedQuestions ?? ''));
        $columns['published'] = self::publishedFromUtilities($utilities, 1);
        $columns['author_id'] = $authorId;
        $columns['create_date'] = current_time('mysql');
        $columns['options'] = self::defaultQuizOptions();

        $quizId = self::insert('quizes', $columns);

        if (!$quizId) {
            return self::errorResponse(__('Failed to create the quiz', 'bit-integrations-pro'));
        }

        self::addQuizCustomPost($quizId, $columns['title'], $authorId);

        return self::successResponse(__('Quiz created successfully', 'bit-integrations-pro'), ['quiz_id' => $quizId]);
    }

    public static function updateQuiz($defaultResponse, $fieldData, $utilities = null, $integrationDetails = null)
    {
        if (!self::isQuizMakerActive()) {
            return self::errorResponse(__('Quiz Maker is not installed or activated', 'bit-integrations-pro'));
        }

        $quizId = isset($fieldData['quiz_id']) ? (int) $fieldData['quiz_id'] : 0;

        if (empty($quizId)) {
            return self::errorResponse(__('Quiz ID is required', 'bit-integrations-pro'));
        }

        if (!self::rowExists('quizes', $quizId)) {
            // translators: %d is the record id.
            return self::errorResponse(\sprintf(__('Quiz not found with Quiz Id: %d', 'bit-integrations-pro'), $quizId));
        }

        $columns = self::pick($fieldData, ['title', 'description', 'quiz_image', 'quiz_url']);

        if (isset($fieldData['ordering'])) {
            $columns['ordering'] = (int) $fieldData['ordering'];
        }

        if (!empty($integrationDetails->selectedQuizCategory)) {
            $columns['quiz_category_id'] = (int) $integrationDetails->selectedQuizCategory;
        }

        if (!empty($integrationDetails->selectedQuestions)) {
            $columns['question_ids'] = implode(',', self::toIdList($integrationDetails->selectedQuestions));
        }

        $published = self::publishedFromUtilities($utilities, null);

        if ($published !== null) {
            $columns['published'] = $published;
        }

        if (empty($columns)) {
            return self::errorResponse(__('No fields provided to update', 'bit-integrations-pro'));
        }

        if (!self::update('quizes', $quizId, $columns)) {
            return self::errorResponse(__('Failed to update the quiz', 'bit-integrations-pro'));
        }

        return self::successResponse(__('Quiz updated successfully', 'bit-integrations-pro'), ['quiz_id' => $quizId]);
    }

    public static function changeQuizStatus($defaultResponse, $fieldData, $integrationDetails = null)
    {
        if (!self::isQuizMakerActive()) {
            return self::errorResponse(__('Quiz Maker is not installed or activated', 'bit-integrations-pro'));
        }

        $quizId = isset($fieldData['quiz_id']) ? (int) $fieldData['quiz_id'] : 0;

        if (empty($quizId)) {
            return self::errorResponse(__('Quiz ID is required', 'bit-integrations-pro'));
        }

        if (!isset($integrationDetails->quizStatus) || $integrationDetails->quizStatus === '') {
            return self::errorResponse(__('Status is required', 'bit-integrations-pro'));
        }

        if (!self::rowExists('quizes', $quizId)) {
            // translators: %d is the record id.
            return self::errorResponse(\sprintf(__('Quiz not found with Quiz Id: %d', 'bit-integrations-pro'), $quizId));
        }

        if (!self::update('quizes', $quizId, ['published' => (int) $integrationDetails->quizStatus])) {
            return self::errorResponse(__('Failed to change the quiz status', 'bit-integrations-pro'));
        }

        return self::successResponse(__('Quiz status changed successfully', 'bit-integrations-pro'), ['quiz_id' => $quizId]);
    }

    public static function deleteQuiz($defaultResponse, $fieldData)
    {
        if (!self::isQuizMakerActive()) {
            return self::errorResponse(__('Quiz Maker is not installed or activated', 'bit-integrations-pro'));
        }

        $quizId = isset($fieldData['quiz_id']) ? (int) $fieldData['quiz_id'] : 0;

        if (empty($quizId)) {
            return self::errorResponse(__('Quiz ID is required', 'bit-integrations-pro'));
        }

        if (!self::rowExists('quizes', $quizId)) {
            // translators: %d is the record id.
            return self::errorResponse(\sprintf(__('Quiz not found with Quiz Id: %d', 'bit-integrations-pro'), $quizId));
        }

        global $wpdb;

        self::delete('quizes', ['id' => $quizId]);

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.DirectDatabaseQuery.DirectQuery -- Quiz Maker exposes no API for its custom tables
        $wpdb->delete(self::table('reports'), ['quiz_id' => $quizId], ['%d']);

        return self::successResponse(__('Quiz deleted successfully', 'bit-integrations-pro'), ['quiz_id' => $quizId]);
    }

    public static function createQuestion($defaultResponse, $fieldData, $utilities = null, $integrationDetails = null)
    {
        if (!self::isQuizMakerActive()) {
            return self::errorResponse(__('Quiz Maker is not installed or activated', 'bit-integrations-pro'));
        }

        if (empty($fieldData['question'])) {
            return self::errorResponse(__('Question is required', 'bit-integrations-pro'));
        }

        $categoryId = isset($integrationDetails->selectedQuestionCategory) ? (int) $integrationDetails->selectedQuestionCategory : 0;

        if (empty($categoryId)) {
            return self::errorResponse(__('Question category is required', 'bit-integrations-pro'));
        }

        $type = $integrationDetails->questionType ?? '';

        if (!\in_array($type, self::QUESTION_TYPES, true)) {
            // translators: %s is the comma-separated list of supported question types.
            return self::errorResponse(\sprintf(__('Unsupported question type. Use one of: %s', 'bit-integrations-pro'), implode(', ', self::QUESTION_TYPES)));
        }

        $columns = self::questionColumns($fieldData);
        $columns['question'] = $fieldData['question'];
        $columns['question_title'] = $columns['question_title'] ?? wp_strip_all_tags($fieldData['question']);
        $columns['category_id'] = $categoryId;
        $columns['type'] = $type;
        $columns['published'] = self::publishedFromUtilities($utilities, 1);
        $columns['author_id'] = get_current_user_id();
        $columns['create_date'] = current_time('mysql');

        $questionId = self::insert('questions', $columns);

        if (!$questionId) {
            return self::errorResponse(__('Failed to create the question', 'bit-integrations-pro'));
        }

        self::replaceAnswers($questionId, $fieldData['answers'] ?? []);

        return self::successResponse(__('Question created successfully', 'bit-integrations-pro'), ['question_id' => $questionId]);
    }

    public static function updateQuestion($defaultResponse, $fieldData, $utilities = null, $integrationDetails = null)
    {
        if (!self::isQuizMakerActive()) {
            return self::errorResponse(__('Quiz Maker is not installed or activated', 'bit-integrations-pro'));
        }

        $questionId = isset($fieldData['question_id']) ? (int) $fieldData['question_id'] : 0;

        if (empty($questionId)) {
            return self::errorResponse(__('Question ID is required', 'bit-integrations-pro'));
        }

        if (!self::rowExists('questions', $questionId)) {
            // translators: %d is the record id.
            return self::errorResponse(\sprintf(__('Question not found with Question Id: %d', 'bit-integrations-pro'), $questionId));
        }

        $columns = self::questionColumns($fieldData);

        if (isset($fieldData['question'])) {
            $columns['question'] = $fieldData['question'];
        }

        if (!empty($integrationDetails->selectedQuestionCategory)) {
            $columns['category_id'] = (int) $integrationDetails->selectedQuestionCategory;
        }

        if (!empty($utilities->selected_question_type)) {
            if (!\in_array($utilities->selected_question_type, self::QUESTION_TYPES, true)) {
                // translators: %s is the comma-separated list of supported question types.
            return self::errorResponse(\sprintf(__('Unsupported question type. Use one of: %s', 'bit-integrations-pro'), implode(', ', self::QUESTION_TYPES)));
            }

            $columns['type'] = $utilities->selected_question_type;
        }

        $published = self::publishedFromUtilities($utilities, null);

        if ($published !== null) {
            $columns['published'] = $published;
        }

        $answers = $fieldData['answers'] ?? [];

        if (empty($columns) && empty($answers)) {
            return self::errorResponse(__('No fields provided to update', 'bit-integrations-pro'));
        }

        if (!empty($columns) && !self::update('questions', $questionId, $columns)) {
            return self::errorResponse(__('Failed to update the question', 'bit-integrations-pro'));
        }

        self::replaceAnswers($questionId, $answers);

        return self::successResponse(__('Question updated successfully', 'bit-integrations-pro'), ['question_id' => $questionId]);
    }

    public static function changeQuestionStatus($defaultResponse, $fieldData, $integrationDetails = null)
    {
        if (!self::isQuizMakerActive()) {
            return self::errorResponse(__('Quiz Maker is not installed or activated', 'bit-integrations-pro'));
        }

        $questionId = isset($fieldData['question_id']) ? (int) $fieldData['question_id'] : 0;

        if (empty($questionId)) {
            return self::errorResponse(__('Question ID is required', 'bit-integrations-pro'));
        }

        if (!isset($integrationDetails->questionStatus) || $integrationDetails->questionStatus === '') {
            return self::errorResponse(__('Status is required', 'bit-integrations-pro'));
        }

        if (!self::rowExists('questions', $questionId)) {
            // translators: %d is the record id.
            return self::errorResponse(\sprintf(__('Question not found with Question Id: %d', 'bit-integrations-pro'), $questionId));
        }

        if (!self::update('questions', $questionId, ['published' => (int) $integrationDetails->questionStatus])) {
            return self::errorResponse(__('Failed to change the question status', 'bit-integrations-pro'));
        }

        return self::successResponse(__('Question status changed successfully', 'bit-integrations-pro'), ['question_id' => $questionId]);
    }

    public static function deleteQuestion($defaultResponse, $fieldData)
    {
        if (!self::isQuizMakerActive()) {
            return self::errorResponse(__('Quiz Maker is not installed or activated', 'bit-integrations-pro'));
        }

        $questionId = isset($fieldData['question_id']) ? (int) $fieldData['question_id'] : 0;

        if (empty($questionId)) {
            return self::errorResponse(__('Question ID is required', 'bit-integrations-pro'));
        }

        if (!self::rowExists('questions', $questionId)) {
            // translators: %d is the record id.
            return self::errorResponse(\sprintf(__('Question not found with Question Id: %d', 'bit-integrations-pro'), $questionId));
        }

        self::delete('questions', ['id' => $questionId]);
        self::delete('answers', ['question_id' => $questionId]);
        self::detachQuestionFromQuizzes($questionId);

        return self::successResponse(__('Question deleted successfully', 'bit-integrations-pro'), ['question_id' => $questionId]);
    }

    public static function createQuizCategory($defaultResponse, $fieldData, $utilities = null)
    {
        return self::createCategory('quizcategories', $fieldData, $utilities, [
            'title_required' => __('Quiz category title is required', 'bit-integrations-pro'),
            'failed'         => __('Failed to create the quiz category', 'bit-integrations-pro'),
            'success'        => __('Quiz category created successfully', 'bit-integrations-pro'),
        ]);
    }

    public static function updateQuizCategory($defaultResponse, $fieldData, $utilities = null)
    {
        return self::updateCategory('quizcategories', 'quiz_category_id', $fieldData, $utilities, [
            'id_required' => __('Quiz category ID is required', 'bit-integrations-pro'),
            // translators: %d is the quiz category id.
            'not_found'   => __('Quiz category not found with Id: %d', 'bit-integrations-pro'),
            'failed'      => __('Failed to update the quiz category', 'bit-integrations-pro'),
            'success'     => __('Quiz category updated successfully', 'bit-integrations-pro'),
        ]);
    }

    public static function deleteQuizCategory($defaultResponse, $fieldData)
    {
        return self::deleteRecord('quizcategories', 'quiz_category_id', $fieldData, [
            'id_required' => __('Quiz category ID is required', 'bit-integrations-pro'),
            // translators: %d is the quiz category id.
            'not_found'   => __('Quiz category not found with Id: %d', 'bit-integrations-pro'),
            'failed'      => __('Failed to delete the quiz category', 'bit-integrations-pro'),
            'success'     => __('Quiz category deleted successfully', 'bit-integrations-pro'),
        ]);
    }

    public static function createQuestionCategory($defaultResponse, $fieldData, $utilities = null)
    {
        return self::createCategory('categories', $fieldData, $utilities, [
            'title_required' => __('Question category title is required', 'bit-integrations-pro'),
            'failed'         => __('Failed to create the question category', 'bit-integrations-pro'),
            'success'        => __('Question category created successfully', 'bit-integrations-pro'),
        ]);
    }

    public static function updateQuestionCategory($defaultResponse, $fieldData, $utilities = null)
    {
        return self::updateCategory('categories', 'question_category_id', $fieldData, $utilities, [
            'id_required' => __('Question category ID is required', 'bit-integrations-pro'),
            // translators: %d is the question category id.
            'not_found'   => __('Question category not found with Id: %d', 'bit-integrations-pro'),
            'failed'      => __('Failed to update the question category', 'bit-integrations-pro'),
            'success'     => __('Question category updated successfully', 'bit-integrations-pro'),
        ]);
    }

    public static function deleteQuestionCategory($defaultResponse, $fieldData)
    {
        return self::deleteRecord('categories', 'question_category_id', $fieldData, [
            'id_required' => __('Question category ID is required', 'bit-integrations-pro'),
            // translators: %d is the question category id.
            'not_found'   => __('Question category not found with Id: %d', 'bit-integrations-pro'),
            'failed'      => __('Failed to delete the question category', 'bit-integrations-pro'),
            'success'     => __('Question category deleted successfully', 'bit-integrations-pro'),
        ]);
    }

    public static function createResult($defaultResponse, $fieldData, $integrationDetails = null)
    {
        if (!self::isQuizMakerActive()) {
            return self::errorResponse(__('Quiz Maker is not installed or activated', 'bit-integrations-pro'));
        }

        $quizId = isset($fieldData['quiz_id']) ? (int) $fieldData['quiz_id'] : 0;

        if (empty($quizId)) {
            return self::errorResponse(__('Quiz ID is required', 'bit-integrations-pro'));
        }

        if (!isset($fieldData['score']) || $fieldData['score'] === '') {
            return self::errorResponse(__('Score is required', 'bit-integrations-pro'));
        }

        if (!self::rowExists('quizes', $quizId)) {
            // translators: %d is the record id.
            return self::errorResponse(\sprintf(__('Quiz not found with Quiz Id: %d', 'bit-integrations-pro'), $quizId));
        }

        $now = current_time('mysql');
        $columns = self::pick($fieldData, ['user_name', 'user_email', 'user_phone', 'duration', 'user_explanation']);
        $columns['quiz_id'] = $quizId;
        $columns['score'] = (string) $fieldData['score'];
        $columns['user_id'] = self::selectedUserId($integrationDetails);
        $columns['user_ip'] = $fieldData['user_ip'] ?? '';
        $columns['start_date'] = $fieldData['start_date'] ?? $now;
        $columns['end_date'] = $fieldData['end_date'] ?? $now;
        $columns['corrects_count'] = (string) ($fieldData['corrects_count'] ?? '0');
        $columns['questions_count'] = (string) ($fieldData['questions_count'] ?? '0');
        $columns['options'] = '';
        $columns['read'] = 0;

        $resultId = self::insert('reports', $columns);

        if (!$resultId) {
            return self::errorResponse(__('Failed to create the quiz result', 'bit-integrations-pro'));
        }

        return self::successResponse(__('Quiz result created successfully', 'bit-integrations-pro'), ['result_id' => $resultId]);
    }

    public static function markResultAsRead($defaultResponse, $fieldData)
    {
        if (!self::isQuizMakerActive()) {
            return self::errorResponse(__('Quiz Maker is not installed or activated', 'bit-integrations-pro'));
        }

        $resultId = isset($fieldData['result_id']) ? (int) $fieldData['result_id'] : 0;

        if (empty($resultId)) {
            return self::errorResponse(__('Result ID is required', 'bit-integrations-pro'));
        }

        if (!self::rowExists('reports', $resultId)) {
            // translators: %d is the record id.
            return self::errorResponse(\sprintf(__('Quiz result not found with Result Id: %d', 'bit-integrations-pro'), $resultId));
        }

        if (!self::update('reports', $resultId, ['read' => 1])) {
            return self::errorResponse(__('Failed to mark the quiz result as read', 'bit-integrations-pro'));
        }

        return self::successResponse(__('Quiz result marked as read', 'bit-integrations-pro'), ['result_id' => $resultId]);
    }

    public static function deleteResult($defaultResponse, $fieldData)
    {
        return self::deleteRecord('reports', 'result_id', $fieldData, [
            'id_required' => __('Result ID is required', 'bit-integrations-pro'),
            // translators: %d is the quiz result id.
            'not_found'   => __('Quiz result not found with Result Id: %d', 'bit-integrations-pro'),
            'failed'      => __('Failed to delete the quiz result', 'bit-integrations-pro'),
            'success'     => __('Quiz result deleted successfully', 'bit-integrations-pro'),
        ]);
    }

    public static function createReview($defaultResponse, $fieldData, $integrationDetails = null)
    {
        if (!self::isQuizMakerActive()) {
            return self::errorResponse(__('Quiz Maker is not installed or activated', 'bit-integrations-pro'));
        }

        $quizId = isset($fieldData['quiz_id']) ? (int) $fieldData['quiz_id'] : 0;

        if (empty($quizId)) {
            return self::errorResponse(__('Quiz ID is required', 'bit-integrations-pro'));
        }

        if (empty($integrationDetails->reviewScore)) {
            return self::errorResponse(__('Rating is required', 'bit-integrations-pro'));
        }

        $score = (int) $integrationDetails->reviewScore;

        if ($score < 1 || $score > 5) {
            return self::errorResponse(__('Rating must be between 1 and 5', 'bit-integrations-pro'));
        }

        if (!self::rowExists('quizes', $quizId)) {
            // translators: %d is the record id.
            return self::errorResponse(\sprintf(__('Quiz not found with Quiz Id: %d', 'bit-integrations-pro'), $quizId));
        }

        $columns = self::pick($fieldData, ['user_name', 'user_email', 'user_phone']);
        $columns['quiz_id'] = $quizId;
        $columns['score'] = (string) $score;
        $columns['review'] = $fieldData['review'] ?? '';
        $columns['user_id'] = self::selectedUserId($integrationDetails);
        $columns['user_ip'] = $fieldData['user_ip'] ?? '';
        $columns['options'] = '';
        $columns['rate_date'] = current_time('mysql');

        $reviewId = self::insert('rates', $columns);

        if (!$reviewId) {
            return self::errorResponse(__('Failed to create the review', 'bit-integrations-pro'));
        }

        return self::successResponse(__('Review created successfully', 'bit-integrations-pro'), ['review_id' => $reviewId]);
    }

    public static function deleteReview($defaultResponse, $fieldData)
    {
        return self::deleteRecord('rates', 'review_id', $fieldData, [
            'id_required' => __('Review ID is required', 'bit-integrations-pro'),
            // translators: %d is the review id.
            'not_found'   => __('Review not found with Review Id: %d', 'bit-integrations-pro'),
            'failed'      => __('Failed to delete the review', 'bit-integrations-pro'),
            'success'     => __('Review deleted successfully', 'bit-integrations-pro'),
        ]);
    }

    public static function createQuestionReport($defaultResponse, $fieldData, $integrationDetails = null)
    {
        if (!self::isQuizMakerActive()) {
            return self::errorResponse(__('Quiz Maker is not installed or activated', 'bit-integrations-pro'));
        }

        $questionId = isset($fieldData['question_id']) ? (int) $fieldData['question_id'] : 0;

        if (empty($questionId)) {
            return self::errorResponse(__('Question ID is required', 'bit-integrations-pro'));
        }

        if (empty($fieldData['report_text'])) {
            return self::errorResponse(__('Report text is required', 'bit-integrations-pro'));
        }

        if (!self::rowExists('questions', $questionId)) {
            // translators: %d is the record id.
            return self::errorResponse(\sprintf(__('Question not found with Question Id: %d', 'bit-integrations-pro'), $questionId));
        }

        $columns = self::pick($fieldData, ['user_name', 'user_email']);
        $columns['question_id'] = $questionId;
        $columns['report_text'] = $fieldData['report_text'];
        $columns['user_id'] = self::selectedUserId($integrationDetails);
        $columns['user_ip'] = $fieldData['user_ip'] ?? '';
        $columns['resolved'] = 0;
        $columns['create_date'] = current_time('mysql');

        $reportId = self::insert('question_reports', $columns);

        if (!$reportId) {
            return self::errorResponse(__('Failed to create the question report', 'bit-integrations-pro'));
        }

        return self::successResponse(__('Question report created successfully', 'bit-integrations-pro'), ['question_report_id' => $reportId]);
    }

    public static function resolveQuestionReport($defaultResponse, $fieldData)
    {
        if (!self::isQuizMakerActive()) {
            return self::errorResponse(__('Quiz Maker is not installed or activated', 'bit-integrations-pro'));
        }

        $reportId = isset($fieldData['question_report_id']) ? (int) $fieldData['question_report_id'] : 0;

        if (empty($reportId)) {
            return self::errorResponse(__('Question report ID is required', 'bit-integrations-pro'));
        }

        if (!self::rowExists('question_reports', $reportId)) {
            // translators: %d is the record id.
            return self::errorResponse(\sprintf(__('Question report not found with Report Id: %d', 'bit-integrations-pro'), $reportId));
        }

        $updated = self::update('question_reports', $reportId, [
            'resolved'     => 1,
            'resolve_date' => current_time('mysql'),
        ]);

        if (!$updated) {
            return self::errorResponse(__('Failed to resolve the question report', 'bit-integrations-pro'));
        }

        return self::successResponse(__('Question report resolved successfully', 'bit-integrations-pro'), ['question_report_id' => $reportId]);
    }

    public static function deleteQuestionReport($defaultResponse, $fieldData)
    {
        return self::deleteRecord('question_reports', 'question_report_id', $fieldData, [
            'id_required' => __('Question report ID is required', 'bit-integrations-pro'),
            // translators: %d is the question report id.
            'not_found'   => __('Question report not found with Report Id: %d', 'bit-integrations-pro'),
            'failed'      => __('Failed to delete the question report', 'bit-integrations-pro'),
            'success'     => __('Question report deleted successfully', 'bit-integrations-pro'),
        ]);
    }

    private static function createCategory($suffix, $fieldData, $utilities, array $messages)
    {
        if (!self::isQuizMakerActive()) {
            return self::errorResponse(__('Quiz Maker is not installed or activated', 'bit-integrations-pro'));
        }

        if (empty($fieldData['title'])) {
            return self::errorResponse($messages['title_required']);
        }

        $categoryId = self::insert($suffix, [
            'title'       => $fieldData['title'],
            'description' => $fieldData['description'] ?? '',
            'published'   => self::publishedFromUtilities($utilities, 1),
            'author_id'   => get_current_user_id(),
        ]);

        if (!$categoryId) {
            return self::errorResponse($messages['failed']);
        }

        return self::successResponse($messages['success'], ['category_id' => $categoryId]);
    }

    private static function updateCategory($suffix, $idKey, $fieldData, $utilities, array $messages)
    {
        if (!self::isQuizMakerActive()) {
            return self::errorResponse(__('Quiz Maker is not installed or activated', 'bit-integrations-pro'));
        }

        $categoryId = isset($fieldData[$idKey]) ? (int) $fieldData[$idKey] : 0;

        if (empty($categoryId)) {
            return self::errorResponse($messages['id_required']);
        }

        if (!self::rowExists($suffix, $categoryId)) {
            return self::errorResponse(\sprintf($messages['not_found'], $categoryId));
        }

        $columns = self::pick($fieldData, ['title', 'description']);
        $published = self::publishedFromUtilities($utilities, null);

        if ($published !== null) {
            $columns['published'] = $published;
        }

        if (empty($columns)) {
            return self::errorResponse(__('No fields provided to update', 'bit-integrations-pro'));
        }

        if (!self::update($suffix, $categoryId, $columns)) {
            return self::errorResponse($messages['failed']);
        }

        return self::successResponse($messages['success'], ['category_id' => $categoryId]);
    }

    private static function deleteRecord($suffix, $idKey, $fieldData, array $messages)
    {
        if (!self::isQuizMakerActive()) {
            return self::errorResponse(__('Quiz Maker is not installed or activated', 'bit-integrations-pro'));
        }

        $id = isset($fieldData[$idKey]) ? (int) $fieldData[$idKey] : 0;

        if (empty($id)) {
            return self::errorResponse($messages['id_required']);
        }

        if (!self::rowExists($suffix, $id)) {
            return self::errorResponse(\sprintf($messages['not_found'], $id));
        }

        if (!self::delete($suffix, ['id' => $id])) {
            return self::errorResponse($messages['failed']);
        }

        return self::successResponse($messages['success'], [$idKey => $id]);
    }

    private static function questionColumns($fieldData)
    {
        return self::pick($fieldData, [
            'question_title', 'question_image', 'question_hint', 'explanation',
            'right_answer_text', 'wrong_answer_text',
        ]);
    }

    private static function replaceAnswers($questionId, $answers)
    {
        if (empty($answers) || !\is_array($answers)) {
            return;
        }

        $rows = array_values(
            array_filter(
                $answers,
                function ($row) {
                    return \is_array($row) && isset($row['answer']) && $row['answer'] !== '';
                }
            )
        );

        if (empty($rows)) {
            return;
        }

        self::delete('answers', ['question_id' => $questionId]);

        $ordering = 1;

        foreach ($rows as $row) {
            self::insert('answers', [
                'question_id' => $questionId,
                'answer'      => $row['answer'],
                'image'       => $row['image'] ?? '',
                'correct'     => isset($row['correct']) ? (int) $row['correct'] : 0,
                'ordering'    => isset($row['ordering']) ? (int) $row['ordering'] : $ordering,
                'placeholder' => $row['placeholder'] ?? '',
            ]);

            ++$ordering;
        }
    }

    private static function defaultQuizOptions()
    {
        return wp_json_encode([
            'quiz_version' => AYS_QUIZ_VERSION,
            'core_version' => get_bloginfo('version'),
            'php_version'  => phpversion(),
            'form_name'    => '',
            'form_email'   => '',
            'form_phone'   => '',
            'custom_css'   => '',
        ]);
    }

    private static function addQuizCustomPost($quizId, $title, $authorId)
    {
        if (!class_exists('\Quiz_Maker_Custom_Post_Type')) {
            return;
        }

        \Quiz_Maker_Custom_Post_Type::ays_quiz_add_custom_post([
            'quiz_id'    => $quizId,
            'quiz_title' => $title,
            'author_id'  => $authorId,
        ]);
    }

    private static function detachQuestionFromQuizzes($questionId)
    {
        global $wpdb;

        $table = self::table('quizes');

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.DirectDatabaseQuery.DirectQuery -- Quiz Maker exposes no API for its custom tables
        $quizzes = $wpdb->get_results("SELECT id, question_ids FROM `{$table}`");

        foreach ($quizzes as $quiz) {
            $questionIds = self::toIdList($quiz->question_ids);

            if (!\in_array($questionId, $questionIds, true)) {
                continue;
            }

            $remaining = array_values(array_diff($questionIds, [$questionId]));

            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.DirectDatabaseQuery.DirectQuery -- Quiz Maker exposes no API for its custom tables
            $wpdb->update($table, ['question_ids' => implode(',', $remaining)], ['id' => (int) $quiz->id]);
        }
    }

    private static function selectedUserId($integrationDetails)
    {
        return isset($integrationDetails->selectedUser) && $integrationDetails->selectedUser !== ''
            ? (int) $integrationDetails->selectedUser
            : get_current_user_id();
    }

    private static function publishedFromUtilities($utilities, $fallback)
    {
        if (isset($utilities->selected_published) && $utilities->selected_published !== '') {
            return (int) $utilities->selected_published;
        }

        return $fallback;
    }

    private static function pick($fieldData, array $keys)
    {
        $columns = [];

        foreach ($keys as $key) {
            if (isset($fieldData[$key]) && $fieldData[$key] !== '') {
                $columns[$key] = $fieldData[$key];
            }
        }

        return $columns;
    }

    private static function toIdList($ids)
    {
        if (\is_array($ids)) {
            return array_values(array_filter(array_map('intval', $ids)));
        }

        if (!\is_string($ids) || $ids === '') {
            return [];
        }

        return array_values(array_filter(array_map('intval', explode(',', $ids))));
    }

    private static function table($suffix)
    {
        global $wpdb;

        return $wpdb->prefix . 'aysquiz_' . $suffix;
    }

    private static function rowExists($suffix, $id)
    {
        global $wpdb;

        $table = self::table($suffix);

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.DirectDatabaseQuery.DirectQuery -- Quiz Maker exposes no API for its custom tables
        return (bool) $wpdb->get_var($wpdb->prepare("SELECT id FROM `{$table}` WHERE id = %d", (int) $id));
    }

    private static function insert($suffix, array $columns)
    {
        global $wpdb;

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.DirectDatabaseQuery.DirectQuery -- Quiz Maker exposes no API for its custom tables
        $inserted = $wpdb->insert(self::table($suffix), $columns);

        return $inserted ? (int) $wpdb->insert_id : 0;
    }

    private static function update($suffix, $id, array $columns)
    {
        global $wpdb;

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.DirectDatabaseQuery.DirectQuery -- Quiz Maker exposes no API for its custom tables
        return $wpdb->update(self::table($suffix), $columns, ['id' => (int) $id]) !== false;
    }

    private static function delete($suffix, array $where)
    {
        global $wpdb;

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.DirectDatabaseQuery.DirectQuery -- Quiz Maker exposes no API for its custom tables
        return (bool) $wpdb->delete(self::table($suffix), $where);
    }

    private static function isQuizMakerActive()
    {
        return \defined('AYS_QUIZ_VERSION');
    }

    private static function successResponse($message, $data = [])
    {
        return [
            'success' => true,
            'message' => $message,
            'data'    => $data
        ];
    }

    private static function errorResponse($message)
    {
        return [
            'success' => false,
            'message' => $message
        ];
    }
}
