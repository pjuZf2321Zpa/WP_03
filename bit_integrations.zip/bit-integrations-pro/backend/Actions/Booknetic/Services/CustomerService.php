<?php

namespace BitApps\IntegrationsPro\Actions\Booknetic\Services;

use BitApps\IntegrationsPro\Core\Util\Hooks;
use BookneticApp\Backend\Customers\Services\CustomerService as BookneticCustomerService;
use BookneticApp\Models\Appointment;
use BookneticApp\Models\Customer;
use BookneticApp\Models\CustomerCategory;
use BookneticApp\Providers\IoC\Container;

final class CustomerService extends BaseService
{
    private const GENDERS = ['male', 'female'];

    public function createCustomer(): array
    {
        $error = $this->validate([
            'first_name' => [__('First Name', 'bit-integrations-pro')],
            'last_name'  => [__('Last Name', 'bit-integrations-pro')],
            'email'      => [__('Email', 'bit-integrations-pro'), 'email'],
        ]);

        if ($error !== null) {
            return $error;
        }

        $email = $this->string('email');

        if (Customer::query()->where('email', $email)->count() > 0) {
            return $this->error(__('A customer with this email exists. Use a different email.', 'bit-integrations-pro'));
        }

        $profileError = $this->profileError();

        if ($profileError !== null) {
            return $this->error($profileError);
        }

        $categoryId = $this->int('category_id');

        if ($categoryId > 0 && empty(CustomerCategory::query()->get($categoryId))) {
            return $this->error(__('The customer category does not exist. Select a different category.', 'bit-integrations-pro'));
        }

        if ($categoryId === 0) {
            $defaultCategory = CustomerCategory::query()->where('is_default', 1)->fetch();
            $categoryId = $defaultCategory ? (int) $defaultCategory->id : 0;
        }

        $data = [
            'user_id'       => $this->int('user_id'),
            'first_name'    => $this->string('first_name'),
            'last_name'     => $this->string('last_name'),
            'email'         => $email,
            'phone_number'  => $this->string('phone_number'),
            'birthdate'     => $this->has('birthdate') ? $this->parseDate($this->string('birthdate')) : null,
            'notes'         => $this->string('notes'),
            'profile_image' => '',
            'gender'        => strtolower($this->string('gender')),
            'category_id'   => $categoryId > 0 ? $categoryId : null,
            'created_at'    => current_time('mysql', true),
            'created_by'    => get_current_user_id(),
        ];

        if (!Customer::query()->insert($data)) {
            return $this->error(__('Booknetic did not create the customer. Try again.', 'bit-integrations-pro'));
        }

        $customerId = Customer::lastId();
        $this->linkWpUser($data['user_id'], 'booknetic_customer');
        Hooks::run('bkntc_customer_created', $customerId, null);
        Hooks::run('bkntc_customer_saved', $customerId);

        return $this->success(Customer::query()->get($customerId));
    }

    public function updateCustomer(): array
    {
        $error = $this->validate(['customer_id' => [__('Customer ID', 'bit-integrations-pro'), 'integer']]);

        if ($error !== null) {
            return $error;
        }

        $customerId = $this->int('customer_id');
        $customer = Customer::query()->get($customerId);

        if (empty($customer)) {
            return $this->error(__('The customer does not exist. Select a different customer.', 'bit-integrations-pro'));
        }

        $profileError = $this->profileError();

        if ($profileError !== null) {
            return $this->error($profileError);
        }

        $data = $this->optionalTextFields([
            'first_name'   => 'first_name',
            'last_name'    => 'last_name',
            'phone_number' => 'phone_number',
            'notes'        => 'notes',
        ]) + $this->optionalIntFields(['user_id', 'category_id']);

        if ($this->has('birthdate')) {
            $data['birthdate'] = $this->parseDate($this->string('birthdate'));
        }

        if ($this->has('gender')) {
            $data['gender'] = strtolower($this->string('gender'));
        }

        if ($this->has('email')) {
            $email = $this->string('email');

            if (!is_email($email)) {
                return $this->error(__('The customer email is not valid. Enter a correct email.', 'bit-integrations-pro'));
            }

            if (Customer::query()->where('email', $email)->where('id', '<>', $customerId)->count() > 0) {
                return $this->error(__('A customer with this email exists. Use a different email.', 'bit-integrations-pro'));
            }

            $data['email'] = $email;
        }

        if (!empty($data['category_id']) && empty(CustomerCategory::query()->get($data['category_id']))) {
            return $this->error(__('The customer category does not exist. Select a different category.', 'bit-integrations-pro'));
        }

        if (empty($data)) {
            return $this->error(__('No customer field is set. Map one or more fields to update.', 'bit-integrations-pro'));
        }

        Hooks::run('bkntc_customer_before_edit', $customerId);
        Customer::query()->where('id', $customerId)->update($data);

        if (isset($data['user_id'])) {
            $this->linkWpUser($data['user_id'], 'booknetic_customer', $customer->user_id);
        }

        Hooks::run('bkntc_customer_saved', $customerId);

        return $this->success(Customer::query()->get($customerId));
    }

    public function deleteCustomer(): array
    {
        $error = $this->validate(['customer_id' => [__('Customer ID', 'bit-integrations-pro'), 'integer']]);

        if ($error !== null) {
            return $error;
        }

        $customerId = $this->int('customer_id');

        if (empty(Customer::query()->get($customerId))) {
            return $this->error(__('The customer does not exist. Select a different customer.', 'bit-integrations-pro'));
        }

        if (Appointment::query()->where('customer_id', $customerId)->count() > 0) {
            return $this->error(__('The customer has appointments. Delete the appointments first.', 'bit-integrations-pro'));
        }

        Container::get(BookneticCustomerService::class)->delete($customerId, 0);

        return $this->success(['customer_id' => $customerId], __('The customer is deleted.', 'bit-integrations-pro'));
    }

    public function assignCustomerCategory(): array
    {
        $error = $this->validate([
            'customer_id' => [__('Customer ID', 'bit-integrations-pro'), 'integer'],
            'category_id' => [__('Customer Category', 'bit-integrations-pro'), 'integer'],
        ]);

        if ($error !== null) {
            return $error;
        }

        $customerId = $this->int('customer_id');
        $categoryId = $this->int('category_id');

        if (empty(Customer::query()->get($customerId))) {
            return $this->error(__('The customer does not exist. Select a different customer.', 'bit-integrations-pro'));
        }

        if (empty(CustomerCategory::query()->get($categoryId))) {
            return $this->error(__('The customer category does not exist. Select a different category.', 'bit-integrations-pro'));
        }

        Hooks::run('bkntc_customer_before_edit', $customerId);
        $result = $this->updateRecord(Customer::class, $customerId, ['category_id' => $categoryId]);

        if ($result['success']) {
            Hooks::run('bkntc_customer_saved', $customerId);
        }

        return $result;
    }

    private function profileError(): ?string
    {
        if ($this->has('birthdate') && $this->parseDate($this->string('birthdate')) === null) {
            return __('The birth date is not valid. Enter a date such as 1990-01-31.', 'bit-integrations-pro');
        }

        if ($this->missingWpUser($this->int('user_id'))) {
            return __('The WordPress user does not exist. Select a different user.', 'bit-integrations-pro');
        }

        $gender = strtolower($this->string('gender'));

        if ($gender !== '' && !\in_array($gender, self::GENDERS, true)) {
            return __('The gender is not valid. Use male or female.', 'bit-integrations-pro');
        }

        return null;
    }
}
