<?php

namespace FluentCartPro\App\Modules\SavedPaymentMethods\Http\Controllers;

use FluentCart\Api\Resource\CustomerResource;
use FluentCart\App\Http\Controllers\FrontendControllers\BaseFrontendController;
use FluentCart\Framework\Http\Request\Request;
use FluentCartPro\App\Modules\SavedPaymentMethods\AddCardService;
use FluentCartPro\App\Modules\SavedPaymentMethods\ManageCardService;
use FluentCartPro\App\Modules\SavedPaymentMethods\SavedPaymentMethodRepository;

/**
 * Customer-facing REST controller for saved payment methods.
 *
 * Guarded by core CustomerFrontendPolicy (logged-in only), so every action
 * MUST resolve and scope to the current customer — the policy does not
 * guarantee ownership.
 */
class CustomerPaymentMethodController extends BaseFrontendController
{
    /**
     * GET /wp-json/fluent-cart/v2/saved-payment-methods
     * List the current customer's saved cards (browser-safe, opaque ids).
     */
    public function index(Request $request): \WP_REST_Response
    {
        $customer = $this->currentCustomer();
        if ($customer instanceof \WP_REST_Response) {
            return $customer;
        }

        return $this->sendSuccess([
            'data'    => (new SavedPaymentMethodRepository())->list($customer),
            'message' => __('Saved payment methods retrieved', 'fluent-cart-pro'),
        ]);
    }

    /**
     * POST /wp-json/fluent-cart/v2/saved-payment-methods
     * Add + verify a new card (SetupIntent, SCA-aware, rate-limited). On the
     * first call may return {status:requires_action, client_secret,
     * setup_intent_id} for inline 3DS; the client confirms and re-POSTs with
     * setup_intent_id to finalize.
     */
    public function store(Request $request): \WP_REST_Response
    {
        $customer = $this->currentCustomer();
        if ($customer instanceof \WP_REST_Response) {
            return $customer;
        }

        $paymentMethodId = sanitize_text_field((string) $request->get('payment_method_id', ''));
        $setupIntentId = sanitize_text_field((string) $request->get('setup_intent_id', ''));
        $setDefault = $request->get('set_default') === 'yes' ? 'yes' : 'no';

        // These ids are concatenated into Stripe API paths downstream, so
        // enforce the Stripe id grammar here (sanitize_text_field does not).
        // Reject anything that isn't a well-formed pm_/seti_ token.
        if ($paymentMethodId !== '' && !preg_match('/^pm_[A-Za-z0-9]+$/', $paymentMethodId)) {
            return $this->sendError([
                'status'  => 'failed',
                'message' => __('Invalid payment method.', 'fluent-cart-pro'),
            ], 422);
        }
        if ($setupIntentId !== '' && !preg_match('/^seti_[A-Za-z0-9]+$/', $setupIntentId)) {
            return $this->sendError([
                'status'  => 'failed',
                'message' => __('Invalid verification reference.', 'fluent-cart-pro'),
            ], 422);
        }

        if ($paymentMethodId === '' && $setupIntentId === '') {
            return $this->sendError([
                'status'  => 'failed',
                'message' => __('Missing payment method.', 'fluent-cart-pro'),
            ], 422);
        }

        $result = (new AddCardService())->addCard($customer, $paymentMethodId, $setupIntentId, $setDefault);
        $body = $result['body'];

        if (($body['status'] ?? '') === 'failed') {
            return $this->sendError($body, $result['code']);
        }

        return $this->sendSuccess($body);
    }

    /**
     * GET /wp-json/fluent-cart/v2/saved-payment-methods/setup-intent-attempts
     * Remaining card-verification attempts today (for the add-card UI).
     */
    public function remainingAttempts(Request $request): \WP_REST_Response
    {
        $customer = $this->currentCustomer();
        if ($customer instanceof \WP_REST_Response) {
            return $customer;
        }

        $vendorCustomerId = $customer->getMeta('stripe_customer_id');
        $remaining = $vendorCustomerId
            ? (new AddCardService())->remainingAttempts($vendorCustomerId)
            : (int) apply_filters(AddCardService::RATE_LIMIT_FILTER, AddCardService::DEFAULT_RATE_LIMIT, '');

        return $this->sendSuccess(['remaining' => $remaining]);
    }

    /**
     * POST /wp-json/fluent-cart/v2/saved-payment-methods/{id}/default
     * Set a saved card as the account-wide default.
     */
    public function setDefault(Request $request, $id): \WP_REST_Response
    {
        $customer = $this->currentCustomer();
        if ($customer instanceof \WP_REST_Response) {
            return $customer;
        }

        $id = $this->validCardId($id);
        if ($id === null) {
            return $this->sendError(['status' => 'failed', 'message' => __('Invalid card reference.', 'fluent-cart-pro')], 422);
        }

        return $this->respond((new ManageCardService())->setDefault($customer, $id));
    }

    /**
     * DELETE /wp-json/fluent-cart/v2/saved-payment-methods/{id}
     * Remove a saved card (blocked when it backs a live subscription).
     */
    public function destroy(Request $request, $id): \WP_REST_Response
    {
        $customer = $this->currentCustomer();
        if ($customer instanceof \WP_REST_Response) {
            return $customer;
        }

        $id = $this->validCardId($id);
        if ($id === null) {
            return $this->sendError(['status' => 'failed', 'message' => __('Invalid card reference.', 'fluent-cart-pro')], 422);
        }

        return $this->respond((new ManageCardService())->delete($customer, $id));
    }

    /**
     * The opaque card id is a 20-char hex token (see repository). Reject
     * anything else before it is used to look up / mutate a stored card.
     */
    private function validCardId($id)
    {
        $id = sanitize_text_field((string) $id);

        return preg_match('/^[a-f0-9]{20}$/', $id) ? $id : null;
    }

    private function respond(array $result): \WP_REST_Response
    {
        $body = $result['body'];

        if (($body['status'] ?? '') === 'failed') {
            return $this->sendError($body, $result['code']);
        }

        return $this->sendSuccess($body);
    }

    /**
     * Resolve the logged-in customer or a ready-to-return error response.
     *
     * @return \FluentCart\App\Models\Customer|\WP_REST_Response
     */
    private function currentCustomer()
    {
        $error = $this->checkUserLoggedIn();
        if ($error !== null) {
            return $error;
        }

        $customer = CustomerResource::getCurrentCustomer();
        if (!$customer) {
            return $this->sendError([
                'message' => __('Customer not found', 'fluent-cart-pro'),
            ]);
        }

        return $customer;
    }
}
