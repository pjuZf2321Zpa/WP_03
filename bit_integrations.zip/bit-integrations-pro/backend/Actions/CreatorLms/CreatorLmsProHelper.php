<?php

/**
 * Creator LMS Pro Action Helper
 */

namespace BitApps\IntegrationsPro\Actions\CreatorLms;

use CreatorLms\Data\Student;
use Throwable;

class CreatorLmsProHelper
{
    public static function createStudent($defaultResponse, $fieldData)
    {
        if (!self::isCreatorLmsActive()) {
            return $defaultResponse;
        }

        $userEmail = self::extractEmail($fieldData);

        if (!$userEmail) {
            return self::errorResponse(__('A valid student email is required.', 'bit-integrations-pro'));
        }

        if (email_exists($userEmail)) {
            return self::errorResponse(__('A student account already exists with this email.', 'bit-integrations-pro'));
        }

        if (!\function_exists('creator_lms_create_new_student')) {
            return self::errorResponse(__('Creator LMS student creation function is not available.', 'bit-integrations-pro'));
        }

        $username = isset($fieldData['username']) ? sanitize_user($fieldData['username']) : '';
        $password = $fieldData['password'] ?? '';
        $args = self::extractOptionalTextFields($fieldData, ['first_name', 'last_name']);

        $studentId = creator_lms_create_new_student($userEmail, $username, $password, $args);

        if (is_wp_error($studentId)) {
            return self::errorResponse($studentId->get_error_message());
        }

        self::tagStudentMeta((int) $studentId);

        return self::successResponse(
            __('Student created successfully.', 'bit-integrations-pro'),
            self::getUserData((int) $studentId)
        );
    }

    public static function updateStudentData($defaultResponse, $fieldData)
    {
        if (!self::isCreatorLmsActive()) {
            return $defaultResponse;
        }

        $userEmail = self::extractEmail($fieldData);

        if (!$userEmail) {
            return self::errorResponse(__('A valid student email is required.', 'bit-integrations-pro'));
        }

        $student = get_user_by('email', $userEmail);

        if (!$student) {
            return self::errorResponse(__('Student not found with the provided email.', 'bit-integrations-pro'));
        }

        $studentId = (int) $student->ID;
        $updateData = array_merge(
            ['ID' => $studentId],
            self::extractOptionalTextFields($fieldData, ['first_name', 'last_name', 'display_name'])
        );

        if (!empty($fieldData['new_email'])) {
            $newEmail = sanitize_email($fieldData['new_email']);

            if (!is_email($newEmail)) {
                return self::errorResponse(__('Invalid new email address.', 'bit-integrations-pro'));
            }

            $existingUser = get_user_by('email', $newEmail);
            if ($existingUser && (int) $existingUser->ID !== $studentId) {
                return self::errorResponse(__('The new email is already in use by another user.', 'bit-integrations-pro'));
            }

            $updateData['user_email'] = $newEmail;
        }

        if (\count($updateData) === 1) {
            return self::errorResponse(__('No fields provided to update.', 'bit-integrations-pro'));
        }

        $updated = wp_update_user($updateData);

        if (is_wp_error($updated)) {
            return self::errorResponse($updated->get_error_message());
        }

        return self::successResponse(
            __('Student updated successfully.', 'bit-integrations-pro'),
            self::getUserData($studentId)
        );
    }

    public static function enrollUserInCourse($defaultResponse, $fieldData)
    {
        if (!self::isCreatorLmsActive()) {
            return $defaultResponse;
        }

        $userEmail = self::extractEmail($fieldData);
        $courseId = self::extractIntField($fieldData, 'course_id');

        if (!$userEmail) {
            return self::errorResponse(__('A valid student email is required.', 'bit-integrations-pro'));
        }

        if (!$courseId) {
            return self::errorResponse(__('A valid course ID is required.', 'bit-integrations-pro'));
        }

        $student = get_user_by('email', $userEmail);

        if (!$student) {
            return self::errorResponse(__('Student not found with the provided email.', 'bit-integrations-pro'));
        }

        if (!self::validateCoursePost($courseId)) {
            return self::errorResponse(__('Course not found.', 'bit-integrations-pro'));
        }

        $studentId = (int) $student->ID;

        self::tagStudentMeta($studentId);

        if (self::isAlreadyEnrolled($studentId, $courseId)) {
            return self::errorResponse(__('Student is already enrolled in this course.', 'bit-integrations-pro'));
        }

        $enrolled = self::insertEnrollmentRecord($studentId, $courseId);

        if (!$enrolled) {
            return self::errorResponse(__('Failed to enroll student in course.', 'bit-integrations-pro'));
        }

        [$enrollmentId, $startDate] = $enrolled;

        do_action('creator_lms_manual_student_enrollment', $studentId, $courseId);

        return self::successResponse(
            __('Student enrolled successfully.', 'bit-integrations-pro'),
            [
                'enrollment_id' => $enrollmentId,
                'student_id'    => $studentId,
                'course_id'     => $courseId,
                'status'        => 'enrolled',
                'start_date'    => $startDate,
            ]
        );
    }

    public static function createCourse($defaultResponse, $fieldData, $integrationDetails = null)
    {
        if (!self::isCreatorLmsActive()) {
            return $defaultResponse;
        }

        $courseTitle = isset($fieldData['course_title']) ? sanitize_text_field($fieldData['course_title']) : '';
        $courseDescription = isset($fieldData['course_description']) ? wp_kses_post($fieldData['course_description']) : '';

        if (empty($courseTitle)) {
            return self::errorResponse(__('Course title is required.', 'bit-integrations-pro'));
        }

        if (empty($courseDescription)) {
            return self::errorResponse(__('Course description is required.', 'bit-integrations-pro'));
        }

        $courseClass = self::resolveCourseClass();

        if (!class_exists($courseClass)) {
            return self::errorResponse(__('Course model class is not available.', 'bit-integrations-pro'));
        }

        $courseStatus = self::resolveCourseStatus($integrationDetails);

        try {
            $course = new $courseClass();
            $course->set_name($courseTitle);
            $course->set_description($courseDescription);
            $course->set_status($courseStatus);
            $course->save();

            $courseId = (int) $course->get_id();
        } catch (Throwable $e) {
            return self::errorResponse($e->getMessage());
        }

        return self::successResponse(
            __('Course created successfully.', 'bit-integrations-pro'),
            self::getCourseData($courseId)
        );
    }

    public static function markLessonCompleted($defaultResponse, $fieldData)
    {
        if (!self::isCreatorLmsActive()) {
            return $defaultResponse;
        }

        $userEmail = self::extractEmail($fieldData);
        $courseId = self::extractIntField($fieldData, 'course_id');
        $lessonId = self::extractIntField($fieldData, 'lesson_id');

        if (!$userEmail) {
            return self::errorResponse(__('A valid student email is required.', 'bit-integrations-pro'));
        }

        if (!$courseId) {
            return self::errorResponse(__('A valid course ID is required.', 'bit-integrations-pro'));
        }

        if (!$lessonId) {
            return self::errorResponse(__('A valid lesson ID is required.', 'bit-integrations-pro'));
        }

        $student = get_user_by('email', $userEmail);

        if (!$student) {
            return self::errorResponse(__('Student not found with the provided email.', 'bit-integrations-pro'));
        }

        if (!self::validateCoursePost($courseId)) {
            return self::errorResponse(__('Course not found.', 'bit-integrations-pro'));
        }

        if (!self::validateLessonPost($lessonId)) {
            return self::errorResponse(__('Lesson not found.', 'bit-integrations-pro'));
        }

        $studentId = (int) $student->ID;

        if (!class_exists('\CreatorLms\Data\Student')) {
            return self::errorResponse(__('Creator LMS Student class is not available.', 'bit-integrations-pro'));
        }

        try {
            $studentObj = new Student($studentId);
            $studentObj->complete_lesson($lessonId);

            do_action('creator_lms_after_lesson_completed', $lessonId, $courseId, $studentId);
            do_action('creator_lms_lesson_completed', $lessonId, $courseId, $studentId);
        } catch (Throwable $e) {
            return self::errorResponse($e->getMessage());
        }

        return self::successResponse(
            __('Lesson marked as completed.', 'bit-integrations-pro'),
            ['student_id' => $studentId, 'course_id' => $courseId, 'lesson_id' => $lessonId]
        );
    }

    private static function extractEmail($fieldData)
    {
        $email = isset($fieldData['user_email']) ? sanitize_email($fieldData['user_email']) : '';

        return (empty($email) || !is_email($email)) ? '' : $email;
    }

    private static function extractIntField($fieldData, $key)
    {
        return isset($fieldData[$key]) ? (int) $fieldData[$key] : 0;
    }

    private static function extractOptionalTextFields($fieldData, $keys)
    {
        $result = [];

        foreach ($keys as $key) {
            if (!empty($fieldData[$key])) {
                $result[$key] = sanitize_text_field($fieldData[$key]);
            }
        }

        return $result;
    }

    /**
     * Tag a user as a Creator LMS student via user meta.
     *
     * @param mixed $studentId
     */
    private static function tagStudentMeta($studentId)
    {
        update_user_meta($studentId, '_is_creator_lms_student', 'yes');
        update_user_meta($studentId, '_is_creator_lms_user', 'yes');
    }

    private static function getUserData($userId)
    {
        return bit_integrations_get_class('Core\\Util\\User')::get($userId);
    }

    private static function isAlreadyEnrolled($studentId, $courseId)
    {
        global $wpdb;

        $table = $wpdb->prefix . 'crlms_user_enrollment';
        $row = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT status FROM {$table} WHERE user_id = %d AND course_id = %d ORDER BY id DESC LIMIT 1",
                $studentId,
                $courseId
            ),
            ARRAY_A
        );

        return !empty($row) && 'enrolled' === ($row['status'] ?? '');
    }

    private static function insertEnrollmentRecord($studentId, $courseId)
    {
        global $wpdb;

        $table = $wpdb->prefix . 'crlms_user_enrollment';
        $startDate = current_time('mysql');

        $inserted = $wpdb->insert(
            $table,
            [
                'user_id'    => $studentId,
                'course_id'  => $courseId,
                'status'     => 'enrolled',
                'progress'   => 'running',
                'start_date' => $startDate,
            ],
            ['%d', '%d', '%s', '%s', '%s']
        );

        return $inserted ? [(int) $wpdb->insert_id, $startDate] : null;
    }

    private static function validateCoursePost($courseId)
    {
        $postType = \defined('CREATOR_LMS_COURSE_CPT') ? CREATOR_LMS_COURSE_CPT : 'crlms-course';
        $post = get_post($courseId);

        return $post && $post->post_type === $postType;
    }

    private static function validateLessonPost($lessonId)
    {
        $postType = \defined('CREATOR_LMS_LESSON_CPT') ? CREATOR_LMS_LESSON_CPT : 'crlms-lesson';
        $post = get_post($lessonId);

        return $post && $post->post_type === $postType;
    }

    /**
     * Resolve the fully-qualified Course class name based on whether Pro is active.
     */
    private static function resolveCourseClass()
    {
        return \function_exists('creator_lms_is_pro') && creator_lms_is_pro()
            ? '\CreatorLmsPro\Data\Course'
            : '\CreatorLms\Data\Course';
    }

    private static function resolveCourseStatus($integrationDetails)
    {
        $allowed = ['draft', 'publish', 'pending'];
        $selected = isset($integrationDetails->courseStatus)
            ? sanitize_text_field($integrationDetails->courseStatus)
            : 'draft';

        return \in_array($selected, $allowed, true) ? $selected : 'draft';
    }

    private static function getCourseData($courseId)
    {
        if (!$courseId) {
            return [];
        }

        if (\function_exists('crlms_get_course')) {
            try {
                $course = crlms_get_course($courseId);

                if ($course) {
                    return [
                        'id'          => $course->get_id(),
                        'title'       => $course->get_name(),
                        'description' => $course->get_description(),
                        'permalink'   => $course->get_permalink(),
                        'status'      => $course->get_status(),
                    ];
                }
            } catch (Throwable $e) {
            // Fall through to WP post fallback.
            }
        }

        $post = get_post($courseId);

        if (!$post) {
            return [];
        }

        return [
            'id'          => $post->ID,
            'title'       => $post->post_title,
            'description' => $post->post_content,
            'permalink'   => get_permalink($post->ID),
            'status'      => $post->post_status,
        ];
    }

    private static function successResponse($message, $data)
    {
        return ['success' => true, 'message' => $message, 'data' => $data];
    }

    private static function errorResponse($message)
    {
        return ['success' => false, 'message' => $message];
    }

    private static function isCreatorLmsActive()
    {
        return class_exists('CreatorLms') && \function_exists('crlms_get_course');
    }
}
