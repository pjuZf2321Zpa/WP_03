<?php
/**
 * Partial: Chatbot rules, in the Rules side panel.
 *
 * A list of rules (one row each, with an on/off switch), or an empty card with examples to start from. The
 * rules script draws the rows and edits one rule at a time in the same panel; these labels give it plain words
 * for the saved events, checks and actions.
 */
if (!defined('ABSPATH')) {
    exit;
}

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- This file only uses local helper/template variables and does not define public globals.

// $bot_id and $triggers_json come from the Rules side panel (admin/views/chatbot/behavior-settings.php).
if (empty($bot_id)) {
    echo '<p class="aipkit_rules_tip">' . esc_html__('Create or select a chatbot to configure rules.', 'gpt3-ai-content-generator') . '</p>';
    return;
}

// Ensure schema for JS is available
$trigger_schemas_path = WPAICG_LIB_DIR . 'chatbot/trigger-schemas.php';
$trigger_schemas = file_exists($trigger_schemas_path) ? require $trigger_schemas_path : [];

$rule_examples = [
    'price' => [
        'icon' => 'format-chat',
        'title' => __('Answer price questions the same way every time', 'gpt3-ai-content-generator'),
        'summary' => __('A visitor sends a message · if it mentions price or cost → reply', 'gpt3-ai-content-generator'),
        'rule' => [
            'name' => __('Price questions', 'gpt3-ai-content-generator'),
            'event_name' => 'user_message_received',
            // A pattern, so Price and PRICE match too.
            'conditions' => [['type' => 'text_content', 'field' => 'user_message_text', 'operator' => 'matches_regex', 'value' => '/price|pricing|cost/i']],
            'action' => ['type' => 'bot_reply', 'payload' => ['message' => __('You can find all our prices on our pricing page.', 'gpt3-ai-content-generator'), 'stop_processing_ai' => true]],
            'priority' => 10,
            'is_active' => true,
        ],
    ],
    'contact' => [
        'icon' => 'feedback',
        'title' => __('Ask for contact details on the pricing page', 'gpt3-ai-content-generator'),
        'summary' => __('A chat starts · if the page title contains “Pricing” → show a form', 'gpt3-ai-content-generator'),
        'rule' => [
            'name' => __('Contact form on Pricing', 'gpt3-ai-content-generator'),
            'event_name' => 'session_started',
            'conditions' => [['type' => 'post_context', 'field' => 'post_title', 'operator' => 'contains', 'value' => __('Pricing', 'gpt3-ai-content-generator')]],
            'action' => ['type' => 'display_form', 'payload' => [
                'title' => __('Can we get back to you?', 'gpt3-ai-content-generator'),
                'submit_button_text' => __('Send', 'gpt3-ai-content-generator'),
                'elements' => [
                    ['id' => 'name', 'type' => 'text_input', 'label' => __('Name', 'gpt3-ai-content-generator'), 'placeholder' => '', 'required' => true, 'default_value' => '', 'help_text' => ''],
                    ['id' => 'email', 'type' => 'text_input', 'label' => __('Email', 'gpt3-ai-content-generator'), 'placeholder' => '', 'required' => true, 'default_value' => '', 'help_text' => ''],
                ],
            ]],
            'priority' => 10,
            'is_active' => true,
        ],
    ],
    'phone' => [
        'icon' => 'shield',
        'title' => __('Stop messages that share phone numbers', 'gpt3-ai-content-generator'),
        'summary' => __('A visitor sends message · if it looks like a phone number → block it', 'gpt3-ai-content-generator'),
        'rule' => [
            'name' => __('No phone numbers', 'gpt3-ai-content-generator'),
            'event_name' => 'user_message_received',
            'conditions' => [['type' => 'text_content', 'field' => 'user_message_text', 'operator' => 'matches_regex', 'value' => '/\+?\d[\d\s().-]{7,}\d/']],
            'action' => ['type' => 'block_message', 'payload' => ['reason' => __('For your privacy, please don’t share phone numbers here.', 'gpt3-ai-content-generator')]],
            'priority' => 10,
            'is_active' => true,
        ],
    ],
    'errors' => [
        'icon' => 'admin-links',
        'title' => __('Tell your team when something breaks', 'gpt3-ai-content-generator'),
        'summary' => __('Something goes wrong → send to a webhook', 'gpt3-ai-content-generator'),
        'rule' => [
            'name' => __('Errors to a webhook', 'gpt3-ai-content-generator'),
            'event_name' => 'system_error_occurred',
            'conditions' => [],
            'action' => ['type' => 'call_webhook', 'payload' => ['endpoint_url' => '', 'http_method' => 'POST', 'headers' => (object) [], 'body_template' => '', 'timeout_seconds' => 10]],
            'priority' => 10,
            // Off until it has somewhere to send to.
            'is_active' => false,
        ],
    ],
];

$saved_rules = json_decode(trim((string) $triggers_json) ?: '[]', true);
$has_rules = is_array($saved_rules) && !empty($saved_rules);

$rule_labels = [
    'events' => [
        'user_message_received' => __('A visitor sends a message', 'gpt3-ai-content-generator'),
        'session_started' => __('A chat starts', 'gpt3-ai-content-generator'),
        'form_submitted' => __('A visitor sends a form', 'gpt3-ai-content-generator'),
        'system_error_occurred' => __('Something goes wrong', 'gpt3-ai-content-generator'),
    ],
    'actions' => [
        'bot_reply' => __('Reply with a message', 'gpt3-ai-content-generator'),
        'display_form' => __('Show a form', 'gpt3-ai-content-generator'),
        'inject_context' => __('Add instructions for the AI', 'gpt3-ai-content-generator'),
        'block_message' => __('Block the message', 'gpt3-ai-content-generator'),
        'call_webhook' => __('Send to a webhook', 'gpt3-ai-content-generator'),
        'set_variable' => __('Remember a value', 'gpt3-ai-content-generator'),
        'store_form_submission' => __('Save the form answers', 'gpt3-ai-content-generator'),
    ],
    'actions_short' => [
        'bot_reply' => __('reply', 'gpt3-ai-content-generator'),
        'display_form' => __('show a form', 'gpt3-ai-content-generator'),
        'inject_context' => __('add instructions', 'gpt3-ai-content-generator'),
        'block_message' => __('block it', 'gpt3-ai-content-generator'),
        'call_webhook' => __('send to a webhook', 'gpt3-ai-content-generator'),
        'set_variable' => __('remember a value', 'gpt3-ai-content-generator'),
        'store_form_submission' => __('save the answers', 'gpt3-ai-content-generator'),
    ],
    'action_icons' => [
        'bot_reply' => 'format-chat',
        'display_form' => 'feedback',
        'inject_context' => 'editor-paste-text',
        'block_message' => 'shield',
        'call_webhook' => 'admin-links',
        'set_variable' => 'tag',
        'store_form_submission' => 'database',
    ],
    'groups' => [
        'user_context' => __('The visitor', 'gpt3-ai-content-generator'),
        'text_content' => __('Their message', 'gpt3-ai-content-generator'),
        'conversation_state' => __('The chat', 'gpt3-ai-content-generator'),
        'ai_model_context' => __('The AI model', 'gpt3-ai-content-generator'),
        'http_context' => __('Where they came from', 'gpt3-ai-content-generator'),
        'post_context' => __('The page', 'gpt3-ai-content-generator'),
        'error_context' => __('The error', 'gpt3-ai-content-generator'),
    ],
    'fields' => [
        'is_logged_in' => __('Logged in', 'gpt3-ai-content-generator'),
        'user_role' => __('Their role', 'gpt3-ai-content-generator'),
        'user_message_text' => __('Their message', 'gpt3-ai-content-generator'),
        'message_count' => __('Messages so far', 'gpt3-ai-content-generator'),
        'current_provider' => __('AI provider', 'gpt3-ai-content-generator'),
        'current_model_id' => __('AI model', 'gpt3-ai-content-generator'),
        'http_referer' => __('The link they came from', 'gpt3-ai-content-generator'),
        'user_agent' => __('Their browser', 'gpt3-ai-content-generator'),
        'post_id' => __('Page ID', 'gpt3-ai-content-generator'),
        'post_title' => __('Page title', 'gpt3-ai-content-generator'),
        'post_tags_contain' => __('Page tags', 'gpt3-ai-content-generator'),
        'error_code' => __('Error code', 'gpt3-ai-content-generator'),
        'error_message' => __('Error message', 'gpt3-ai-content-generator'),
        'failed_provider' => __('Provider that failed', 'gpt3-ai-content-generator'),
        'failed_model' => __('Model that failed', 'gpt3-ai-content-generator'),
        'status_code' => __('Status code', 'gpt3-ai-content-generator'),
        'operation' => __('What it was doing', 'gpt3-ai-content-generator'),
        'module' => __('Part of the plugin', 'gpt3-ai-content-generator'),
    ],
    'operators' => [
        'is_true' => __('is yes', 'gpt3-ai-content-generator'),
        'is_false' => __('is no', 'gpt3-ai-content-generator'),
        'equals' => __('is', 'gpt3-ai-content-generator'),
        'not_equals' => __('is not', 'gpt3-ai-content-generator'),
        'equals_ignore_case' => __('is (any case)', 'gpt3-ai-content-generator'),
        'contains' => __('contains', 'gpt3-ai-content-generator'),
        'not_contains' => __('doesn’t contain', 'gpt3-ai-content-generator'),
        'starts_with' => __('starts with', 'gpt3-ai-content-generator'),
        'ends_with' => __('ends with', 'gpt3-ai-content-generator'),
        'matches_regex' => __('matches the pattern', 'gpt3-ai-content-generator'),
        'is_empty' => __('is empty', 'gpt3-ai-content-generator'),
        'is_not_empty' => __('isn’t empty', 'gpt3-ai-content-generator'),
        'is_one_of' => __('is one of', 'gpt3-ai-content-generator'),
        'is_not_one_of' => __('isn’t one of', 'gpt3-ai-content-generator'),
        'greater_than' => __('is more than', 'gpt3-ai-content-generator'),
        'less_than' => __('is less than', 'gpt3-ai-content-generator'),
        'equals_numeric' => __('equals', 'gpt3-ai-content-generator'),
        'not_equals_numeric' => __('doesn’t equal', 'gpt3-ai-content-generator'),
        'greater_than_or_equals' => __('is at least', 'gpt3-ai-content-generator'),
        'less_than_or_equals' => __('is at most', 'gpt3-ai-content-generator'),
    ],
    // Each action's own settings: a name, a hint, and how it is shown.
    'payload' => [
        'message' => [__('Reply', 'gpt3-ai-content-generator'), __('Sent to the visitor. You can use {{placeholders}}.', 'gpt3-ai-content-generator'), 'area'],
        'stop_processing_ai' => [__('Skip the AI answer', 'gpt3-ai-content-generator'), __('Only this reply is sent.', 'gpt3-ai-content-generator'), 'switch'],
        'placement' => [__('Where', 'gpt3-ai-content-generator'), __('Where the instructions go.', 'gpt3-ai-content-generator'), 'select'],
        'content' => [__('Instructions', 'gpt3-ai-content-generator'), __('Added for this answer only. You can use {{placeholders}}.', 'gpt3-ai-content-generator'), 'area'],
        'reason' => [__('Message to the visitor', 'gpt3-ai-content-generator'), __('Optional. Says why the message was blocked.', 'gpt3-ai-content-generator'), 'area'],
        'endpoint_url' => [__('Webhook URL', 'gpt3-ai-content-generator'), __('Where to send it.', 'gpt3-ai-content-generator'), 'url'],
        'http_method' => [__('Method', 'gpt3-ai-content-generator'), __('POST suits most webhooks.', 'gpt3-ai-content-generator'), 'select'],
        'headers' => [__('Headers', 'gpt3-ai-content-generator'), __('One per line, such as Authorization: Bearer abc123.', 'gpt3-ai-content-generator'), 'headers'],
        'body_template' => [__('Body', 'gpt3-ai-content-generator'), __('Placeholders: {{submitted_data_json}}, {{submitted_data_display_json}}, {{submitted_data_labels_json}}, {{submitted.field_id}}, {{submitted_display.field_id}}, {{submitted_label.field_id}}.', 'gpt3-ai-content-generator'), 'area'],
        'timeout_seconds' => [__('Wait up to', 'gpt3-ai-content-generator'), __('Seconds before it gives up.', 'gpt3-ai-content-generator'), 'number'],
        'scope' => [__('Keep it', 'gpt3-ai-content-generator'), __('On the visitor’s account, or for this chat only.', 'gpt3-ai-content-generator'), 'select'],
        'key' => [__('Name', 'gpt3-ai-content-generator'), __('What to call the value.', 'gpt3-ai-content-generator'), 'text'],
        'value' => [__('Value', 'gpt3-ai-content-generator'), __('You can use {{placeholders}}.', 'gpt3-ai-content-generator'), 'text'],
        'title' => [__('Form title', 'gpt3-ai-content-generator'), __('Optional. Shown above the form.', 'gpt3-ai-content-generator'), 'text'],
        'submit_button_text' => [__('Button text', 'gpt3-ai-content-generator'), __('On the form’s send button.', 'gpt3-ai-content-generator'), 'text'],
        'log_message_format' => [__('Log message', 'gpt3-ai-content-generator'), __('Placeholders: {{form_id}}, {{user_name}}, {{form_submission_summary}}.', 'gpt3-ai-content-generator'), 'area'],
    ],
    'choices' => [
        'system_instruction_prepend' => __('Before your instructions', 'gpt3-ai-content-generator'),
        'system_instruction_append' => __('After your instructions', 'gpt3-ai-content-generator'),
        'history_prepend' => __('Before the chat history', 'gpt3-ai-content-generator'),
        'user_meta' => __('On the visitor’s account', 'gpt3-ai-content-generator'),
        'bot_context' => __('For this chat', 'gpt3-ai-content-generator'),
    ],
    'element_types' => [
        'text_input' => __('Short answer', 'gpt3-ai-content-generator'),
        'textarea' => __('Long answer', 'gpt3-ai-content-generator'),
        'dropdown' => __('Dropdown', 'gpt3-ai-content-generator'),
        'checkbox_group' => __('Checkboxes', 'gpt3-ai-content-generator'),
        'radio_group' => __('Choices', 'gpt3-ai-content-generator'),
        'label' => __('Text', 'gpt3-ai-content-generator'),
        'heading' => __('Heading', 'gpt3-ai-content-generator'),
    ],
    'ui' => [
        'new_rule' => __('New rule', 'gpt3-ai-content-generator'),
        'unnamed' => __('Unnamed rule', 'gpt3-ai-content-generator'),
        /* translators: %d: number of rules. */
        'count_one' => __('%d rule', 'gpt3-ai-content-generator'),
        /* translators: %d: number of rules. */
        'count_many' => __('%d rules', 'gpt3-ai-content-generator'),
        /* translators: %d: number of rules that are on. */
        'count_on' => __('%d on', 'gpt3-ai-content-generator'),
        /* translators: %s: one check of a rule, such as their message contains “price”. */
        'if' => __('if %s', 'gpt3-ai-content-generator'),
        /* translators: %d: number of further checks. */
        'and_more' => __(' and %d more', 'gpt3-ai-content-generator'),
        /* translators: %s: a value a check compares with, such as price. */
        'quoted' => __('“%s”', 'gpt3-ai-content-generator'),
        'all_rules' => __('All rules', 'gpt3-ai-content-generator'),
        'on' => __('On', 'gpt3-ai-content-generator'),
        /* translators: %s: name of a rule. */
        'switch' => __('Turn %s on or off', 'gpt3-ai-content-generator'),
        'group_rule' => __('Rule', 'gpt3-ai-content-generator'),
        'group_if' => __('Only if', 'gpt3-ai-content-generator'),
        'group_then' => __('Then', 'gpt3-ai-content-generator'),
        'group_more' => __('More', 'gpt3-ai-content-generator'),
        'name' => __('Name', 'gpt3-ai-content-generator'),
        'name_hint' => __('Only you see it.', 'gpt3-ai-content-generator'),
        'when' => __('When', 'gpt3-ai-content-generator'),
        'when_hint' => __('What starts this rule.', 'gpt3-ai-content-generator'),
        'checks' => __('Checks', 'gpt3-ai-content-generator'),
        'checks_hint' => __('All must match. With none, the rule runs every time.', 'gpt3-ai-content-generator'),
        'add_check' => __('Add a check', 'gpt3-ai-content-generator'),
        'check_what' => __('What to check', 'gpt3-ai-content-generator'),
        'check_operator' => __('How it compares', 'gpt3-ai-content-generator'),
        'remove_check' => __('Remove this check', 'gpt3-ai-content-generator'),
        'value' => __('Value', 'gpt3-ai-content-generator'),
        'values' => __('Values, separated by commas', 'gpt3-ai-content-generator'),
        'action' => __('Action', 'gpt3-ai-content-generator'),
        'action_hint' => __('What the rule does.', 'gpt3-ai-content-generator'),
        'order' => __('Order', 'gpt3-ai-content-generator'),
        'order_hint' => __('Lower numbers run first when several rules match.', 'gpt3-ai-content-generator'),
        'fields' => __('Form fields', 'gpt3-ai-content-generator'),
        'fields_hint' => __('What the form asks.', 'gpt3-ai-content-generator'),
        'add_field' => __('Add a field', 'gpt3-ai-content-generator'),
        'remove_field' => __('Remove this field', 'gpt3-ai-content-generator'),
        'new_field' => __('New field', 'gpt3-ai-content-generator'),
        'field_type' => __('Type', 'gpt3-ai-content-generator'),
        'field_label' => __('Label', 'gpt3-ai-content-generator'),
        'field_text' => __('Text', 'gpt3-ai-content-generator'),
        'field_id' => __('Field ID', 'gpt3-ai-content-generator'),
        'field_id_hint' => __('Used in placeholders, such as {{submitted.email}}.', 'gpt3-ai-content-generator'),
        'placeholder' => __('Placeholder', 'gpt3-ai-content-generator'),
        'required' => __('Required', 'gpt3-ai-content-generator'),
        'default_value' => __('Default value', 'gpt3-ai-content-generator'),
        'default_hint' => __('For checkboxes, separate several values with commas.', 'gpt3-ai-content-generator'),
        'help_text' => __('Help text', 'gpt3-ai-content-generator'),
        'options' => __('Options', 'gpt3-ai-content-generator'),
        'option_value' => __('Saved value', 'gpt3-ai-content-generator'),
        'option_text' => __('Shown as', 'gpt3-ai-content-generator'),
        'add_option' => __('Add an option', 'gpt3-ai-content-generator'),
        'remove_option' => __('Remove this option', 'gpt3-ai-content-generator'),
        'needs_message' => __('Write the reply to turn this rule on.', 'gpt3-ai-content-generator'),
        'needs_content' => __('Write the instructions to turn this rule on.', 'gpt3-ai-content-generator'),
        'needs_url' => __('Add the webhook URL to turn this rule on.', 'gpt3-ai-content-generator'),
        'needs_key' => __('Name the value to turn this rule on.', 'gpt3-ai-content-generator'),
        'needs_field' => __('Add a form field to turn this rule on.', 'gpt3-ai-content-generator'),
        'delete' => __('Delete rule', 'gpt3-ai-content-generator'),
        'delete_title' => __('Delete this rule?', 'gpt3-ai-content-generator'),
        'delete_text' => __('It stops right away. You can’t undo this.', 'gpt3-ai-content-generator'),
        'keep' => __('Keep it', 'gpt3-ai-content-generator'),
    ],
    'templates' => array_map(static fn($example) => $example['rule'], $rule_examples),
];
?>
<?php // The rules autosave reports here and saves this field. ?>
<span class="aipkit_popover_status_inline aipkit_triggers_status" aria-live="polite"></span>
<textarea
    id="aipkit_bot_<?php echo esc_attr($bot_id); ?>_triggers_json"
    name="triggers_json"
    class="aipkit_trigger_hidden_textarea"
    aria-hidden="true"
    tabindex="-1"
    hidden
><?php echo esc_textarea((string) $triggers_json); ?></textarea>
<div class="aipkit_trigger_builder_container" id="aipkit_trigger_builder_<?php echo esc_attr($bot_id); ?>" data-bot-id="<?php echo esc_attr($bot_id); ?>">
    <?php // This hidden input stores the raw JSON data that JS will load initially ?>
    <input type="hidden" class="aipkit_trigger_raw_data_source" value="<?php echo esc_attr($triggers_json); ?>">
    <?php // This hidden input makes the schemas available to JS ?>
    <input type="hidden" class="aipkit_trigger_schemas_source" data-schemas="<?php echo esc_attr(wp_json_encode($trigger_schemas)); ?>">
    <input type="hidden" class="aipkit_rules_labels_source" data-labels="<?php echo esc_attr(wp_json_encode($rule_labels)); ?>">

    <div class="aipkit_panel_stack" data-aipkit-rules-list>
        <div class="aipkit_panel_stack aipkit_panel_stack--tight" data-aipkit-rules-filled<?php echo $has_rules ? '' : ' hidden'; ?>>
            <div class="aipkit_panel_top">
                <span class="aipkit_panel_count" data-aipkit-rules-count></span>
                <button type="button" class="aipkit_btn aipkit_btn-secondary aipkit_rules_add aipkit_trigger_add_new_btn">
                    <span class="dashicons dashicons-plus-alt2" aria-hidden="true"></span>
                    <?php esc_html_e('Add a rule', 'gpt3-ai-content-generator'); ?>
                </button>
            </div>
            <div class="aipkit_panel_list aipkit_trigger_list_container" id="aipkit_trigger_list_for_<?php echo esc_attr($bot_id); ?>"></div>
            <p class="aipkit_rules_tip"><?php esc_html_e('When several rules match, the one with the lowest order number runs first.', 'gpt3-ai-content-generator'); ?></p>
        </div>
        <div class="aipkit_panel_stack" data-aipkit-rules-empty<?php echo $has_rules ? ' hidden' : ''; ?>>
            <div class="aipkit_panel_empty">
                <span class="aipkit_panel_empty_icon dashicons dashicons-randomize" aria-hidden="true"></span>
                <span class="aipkit_panel_empty_title"><?php esc_html_e('No rules yet', 'gpt3-ai-content-generator'); ?></span>
                <span class="aipkit_panel_empty_text"><?php esc_html_e('A rule does one thing when something happens, such as replying to a keyword or showing a form when a chat starts.', 'gpt3-ai-content-generator'); ?></span>
                <button type="button" class="aipkit_btn aipkit_btn-primary aipkit_panel_empty_action aipkit_trigger_add_new_btn">
                    <span class="dashicons dashicons-plus-alt2" aria-hidden="true"></span>
                    <?php esc_html_e('Add a rule', 'gpt3-ai-content-generator'); ?>
                </button>
            </div>
            <section class="aipkit_panel_section" aria-labelledby="aipkit_rules_examples_title">
                <h4 class="aipkit_panel_section_title" id="aipkit_rules_examples_title"><?php esc_html_e('Or start from an example', 'gpt3-ai-content-generator'); ?></h4>
                <div class="aipkit_panel_list">
                    <?php foreach ($rule_examples as $example_key => $example) : ?>
                        <div class="aipkit_panel_row">
                            <div class="aipkit_panel_row_main">
                                <span class="aipkit_rule_icon dashicons dashicons-<?php echo esc_attr($example['icon']); ?>" aria-hidden="true"></span>
                                <span class="aipkit_panel_row_copy">
                                    <span class="aipkit_panel_row_title"><?php echo esc_html($example['title']); ?></span>
                                    <span class="aipkit_panel_row_meta"><?php echo esc_html($example['summary']); ?></span>
                                </span>
                                <button type="button" class="aipkit_panel_link aipkit_rules_use" data-aipkit-rule-template="<?php echo esc_attr($example_key); ?>" aria-label="<?php echo esc_attr(sprintf(/* translators: %s: an example rule, such as Answer price questions. */ __('Use: %s', 'gpt3-ai-content-generator'), $example['title'])); ?>">
                                    <span class="aipkit_panel_link_label"><?php esc_html_e('Use', 'gpt3-ai-content-generator'); ?></span>
                                </button>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </section>
        </div>
    </div>

    <?php // One rule's settings; the rules script draws them when a rule is opened. ?>
    <div class="aipkit_rule_editor" data-aipkit-rule-editor hidden></div>
</div>
