<?php

namespace FluentCartPro\App\Modules\InlineCheckout\Checkout;

use FluentCart\Framework\Support\Arr;
use FluentCartPro\App\Modules\InlineCheckout\Cart\InlineCartService;
use FluentCartPro\App\Modules\InlineCheckout\Config\InlineCheckoutConfig;
use FluentCartPro\App\Modules\InlineCheckout\Renderer\InlineCheckoutItemsRenderer;

/**
 * Draws the selectable option list wherever core would draw a flat summary.
 *
 * One listener covers every summary surface there is, because core funnels them
 * all through CartSummaryRender: first paint on the block and the shortcode,
 * and the AJAX round trips behind applying a coupon, removing one, changing an
 * address, patching checkout data and refreshing the summary. Before core
 * published this filter each of those was a separate call site that had to be
 * taught about the selector — and any one of them missed meant a shopper
 * watched their radio list turn into a plain list mid-checkout.
 */
class ItemsFragment
{
    /**
     * Guards against re-entry.
     *
     * InlineCheckoutItemsRenderer composes a CartSummaryRender of its own for
     * the heading and the footer. That render fires this same filter, so
     * without the flag the two would call each other until the stack ran out.
     * Core deliberately does not hold this flag for us: it cannot know which
     * listener is re-entering.
     *
     * @var bool
     */
    protected static $rendering = false;

    /**
     * @return void
     */
    public function register(): void
    {
        add_filter('fluent_cart/checkout/cart_summary_html', [$this, 'render'], 10, 2);
    }

    /**
     * @param string|null $html
     * @param array $args ['cart' => Cart, 'with_wrapper' => bool, 'context' => 'summary'|'items']
     * @return string|null
     */
    public function render($html, $args)
    {
        if ($html !== null || self::$rendering) {
            return $html;
        }

        $cart = Arr::get($args, 'cart');

        if (!InlineCartService::isSelectorCart($cart)) {
            return $html;
        }

        $config = InlineCartService::configFromCart($cart);
        $variations = InlineCheckoutConfig::resolveVariations($config);

        $renderer = new InlineCheckoutItemsRenderer($cart, $config, $variations);

        self::$rendering = true;
        try {
            // `items` is the caller asking for the line-item list alone; it
            // draws its own heading and footer, so only the options come back.
            // `summary` is the whole box, and the wrapper is drawn only there.
            if (Arr::get($args, 'context') === 'items') {
                return $renderer->getItemsHtml();
            }

            $withWrapper = Arr::get($args, 'context') === 'summary'
                && (bool)Arr::get($args, 'with_wrapper', true);

            return $renderer->getHtml($withWrapper);
        } finally {
            self::$rendering = false;
        }
    }
}
