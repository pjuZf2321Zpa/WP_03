<?php

namespace FluentCartPro\App\Modules\Licensing\Hooks\Handlers;

use FluentCart\App\Helpers\Helper;
use FluentCart\App\Models\Product;
use FluentCart\Framework\Support\Arr;
use FluentCartPro\App\Modules\Licensing\Models\License;
use FluentCartPro\App\Modules\Licensing\Models\LicenseActivation;
use FluentCartPro\App\Modules\Licensing\Models\LicenseSite;
use FluentCartPro\App\Modules\Licensing\Services\LicenseHelper;
use FluentCartPro\App\Modules\Licensing\Services\ReleaseSignature;

class LicenseApiHandler
{

    public function register()
    {
        add_action('fluent_cart_action_check_license', [$this, 'checkLicense']);
        add_action('fluent_cart_action_activate_license', [$this, 'activateLicense']);
        add_action('fluent_cart_action_deactivate_license', [$this, 'deActivateLicense']);
        add_action('fluent_cart_action_get_license_version', [$this, 'getVersion']);
        add_action('fluent_cart_action_download_license_package', [$this, 'downloadLicensePackage']);
    }

    public function checkLicense($data = [])
    {
        $formattedData = [
            'license_key'     => sanitize_text_field(Arr::get($data, 'license_key', '')),
            'activation_hash' => sanitize_text_field(Arr::get($data, 'activation_hash', '')),
            'item_id'         => sanitize_text_field(Arr::get($data, 'item_id', '')),
            'site_url'        => LicenseHelper::sanitizeSiteUrl(Arr::get($data, 'site_url', '')),
        ];

        if (!$formattedData['site_url'] || (!$formattedData['license_key'] && !$formattedData['activation_hash']) || !$formattedData['item_id']) {
            return $this->sendSuccessResponse([
                'status'     => 'invalid',
                'error_type' => 'validation_error',
                'message'    => __('license_key, site_url and item_id is required', 'fluent-cart-pro'),
            ]);
        }

        [$license, $activation] = LicenseHelper::getLicenseByKeyHashData($formattedData);

        if (is_wp_error($license)) {
            $errorResponse = apply_filters('fluent_cart/license/checking_error', [
                'status'     => 'invalid',
                'error_type' => $license->get_error_code(),
                'message'    => $license->get_error_message()
            ], $formattedData);

            return $this->sendSuccessResponse($errorResponse);
        }

        if (($formattedData['item_id'] != $license->product_id) && apply_filters('fluent_cart/license/check_item_id', true, $license, $activation, $formattedData)) {
            $errorResponse = apply_filters('fluent_cart/license/checking_error', [
                'status'     => 'invalid',
                'error_type' => 'key_mismatch',
                'message'    => 'This license key is not valid for this product. Did you provide the valid license key?'
            ], $formattedData);

            return $this->sendSuccessResponse($errorResponse);
        }

        $status = $license->getPublicStatus();
        $product = $license->product;

        $returnData = [
            'status'            => $status,
            'activation_limit'  => $license->limit,
            'activation_hash'   => $activation ? $activation->activation_hash : '',
            'activations_count' => $license->activation_count,
            'license_key'       => $license->license_key,
            'expiration_date'   => $license->expiration_date ?: 'lifetime',
            'product_id'        => $license->product_id,
            'variation_id'      => $license->variation_id,
            'variation_title'   => $license->variation->variation_title ?? '',
            'product_title'     => $product ? $product->post_title : 'unknown product',
            'created_at'        => $license->created_at,
            'updated_at'        => $license->updated_at
        ];

        $returnData = LicenseHelper::attachLicenseMetaDataToResponse($returnData, $license);

        $returnData = apply_filters('fluent_cart/license/check_license_response', $returnData, $license, $activation, $data);

        if (is_wp_error($returnData)) {
            return $this->sendSuccessResponse([
                'status'     => 'invalid',
                'error_type' => 'license_error',
                'message'    => $returnData->get_error_message()
            ]);
        }

        return $this->sendSuccessResponse($returnData);
    }

    public function activateLicense($data = [])
    {
        $formattedData = [
            'license_key' => sanitize_text_field(Arr::get($data, 'license_key', '')),
            'item_id'     => sanitize_text_field(Arr::get($data, 'item_id', '')),
            'site_url'    => LicenseHelper::sanitizeSiteUrl(Arr::get($data, 'site_url', '')),
        ];

        if (!$formattedData['site_url'] || !$formattedData['license_key'] || !$formattedData['item_id']) {
            return $this->sendErrorResponse([
                'message'    => __('license_key, site_url and item_id is required', 'fluent-cart-pro'),
                'error_type' => 'validation_error'
            ], 422);
        }

        $license = License::query()
            ->where('license_key', $formattedData['license_key'])
            ->first();

        if (!$license) {
            return $this->sendErrorResponse([
                'message'    => __('License not found', 'fluent-cart-pro'),
                'error_type' => 'license_not_found'
            ], 422);
        }

        if ($license->product_id != $formattedData['item_id']) {
            return $this->sendErrorResponse([
                'message'    => __('This license key is not valid for this product. Did you provide the valid license key?', 'fluent-cart-pro'),
                'error_type' => 'key_mismatch'
            ], 422);
        }

        $lock = $this->acquireActivationLock($license->id);
        if (!$lock) {
            return $this->sendErrorResponse([
                'message'    => __('Another activation for this license is in progress. Please try again.', 'fluent-cart-pro'),
                'error_type' => 'activation_busy'
            ], 429);
        }

        // Release before wp_send_json() exits, including when activation throws.
        try {
            $result = $this->activateSiteForLicense($license, $formattedData, $data);
        } finally {
            $this->releaseActivationLock($lock);
        }

        if (is_wp_error($result)) {
            return $this->sendErrorResponse([
                'message'    => $result->get_error_message(),
                'error_type' => $result->get_error_code()
            ], 422);
        }

        $site = $result['site'];
        $activation = $result['activation'];

        if ($result['created']) {
            do_action('fluent_cart/license/site_activated', $site, $activation, $license, $data);
        }

        $product = $license->product;

        $returnData = [
            'status'            => 'valid',
            'activation_limit'  => $license->limit,
            'activation_hash'   => $activation->activation_hash ?? '',
            'activations_count' => $license->activation_count,
            'license_key'       => $license->license_key,
            'expiration_date'   => $license->expiration_date ?: 'lifetime',
            'product_id'        => $license->product_id,
            'variation_id'      => $license->variation_id,
            'variation_title'   => $license->variation->variation_title ?? '',
            'product_title'     => $product ? $product->post_title : 'unknown product',
            'created_at'        => $license->created_at,
            'updated_at'        => $license->updated_at
        ];

        $returnData = LicenseHelper::attachLicenseMetaDataToResponse($returnData, $license);

        $returnData = apply_filters('fluent_cart/license/activate_license_response', $returnData, $license, $activation, $data);

        if (is_wp_error($returnData)) {
            return $this->sendErrorResponse([
                'message'    => $returnData->get_error_message(),
                'error_type' => 'activation_error'
            ], 422);
        }

        return $this->sendSuccessResponse($returnData);
    }

    /** @return array|\WP_Error */
    private function activateSiteForLicense(License $license, array $formattedData, array $data)
    {
        $license->refresh();

        if ($license->isExpired()) {
            return new \WP_Error('license_expired', __('The license key is expired. Please renew or purchase a new license', 'fluent-cart-pro'));
        }

        if (!$license->isActive()) {
            return new \WP_Error('license_not_active', __('The license is not Active. Please contact the support.', 'fluent-cart-pro'));
        }

        $siteUrl = $formattedData['site_url'];
        $site = LicenseSite::query()
            ->where('site_url', $siteUrl)
            ->orWhere('site_url', 'www.' . $siteUrl)
            ->first();

        if ($site && strpos($site->site_url, 'www.') === 0) {
            $site->site_url = $siteUrl;
            $site->save();
        }

        if ($site) {
            $activation = LicenseActivation::query()
                ->where('license_id', $license->id)
                ->where('site_id', $site->id)
                ->first();

            if ($activation) {
                return [
                    'site'       => $site,
                    'activation' => $activation,
                    'created'    => false,
                ];
            }
        }

        // The stored count can lag a parallel activation, so the rows are counted
        // under the lock. The higher number wins: imported licenses may carry a
        // stored count with no activation rows.
        $activeRows = LicenseActivation::query()
            ->where('license_id', $license->id)
            ->where('status', 'active')
            ->where('is_local', '!=', 1)
            ->count();
        $license->activation_count = max((int) $license->activation_count, $activeRows);

        $activationLimit = $license->getActivationLimit();
        $isLocalSite = LicenseHelper::isLocalSite($formattedData['site_url']);

        if (!$isLocalSite && !$activationLimit) {
            return new \WP_Error('activation_limit_exceeded', __('This license key has no activation limit. Please upgrade or purchase a new license.', 'fluent-cart-pro'));
        }

        $isNewSite = false;

        if (!$site) {
            $site = LicenseSite::query()->create(array_filter([
                'site_url'         => $formattedData['site_url'],
                'server_version'   => sanitize_text_field(Arr::get($data, 'server_version', '')),
                'platform_version' => sanitize_text_field(Arr::get($data, 'platform_version', ''))
            ]));
            $isNewSite = true;
        } else {
            $serverVersion = sanitize_text_field(Arr::get($data, 'server_version', ''));
            $platformVersion = sanitize_text_field(Arr::get($data, 'platform_version', ''));

            $willUpdate = false;
            if ($serverVersion && $serverVersion != $site->server_version) {
                $site->server_version = $serverVersion;
                $willUpdate = true;
            }
            if ($platformVersion && $platformVersion != $site->platform_version) {
                $site->platform_version = $platformVersion;
                $willUpdate = true;
            }

            if ($willUpdate) {
                $site->save();
            }
        }


        $activation = null;

        if (!$isNewSite) {
            $activation = LicenseActivation::query()
                ->where('license_id', $license->id)
                ->where('site_id', $site->id)
                ->first();
        }

        if (!$activation) {
            $activation = LicenseActivation::query()->create(array_filter([
                'site_id'          => $site->id,
                'license_id'       => $license->id,
                'status'           => 'active',
                'is_local'         => $isLocalSite ? 1 : 0,
                'product_id'       => $license->product_id,
                'variation_id'     => $license->variation_id,
                'variation_title'  => $license->variation->variation_title ?? '',
                'activation_hash'  => md5(wp_generate_uuid4() . $license->license_key . $site->id),
                'last_update_date' => gmdate('Y-m-d H:i:s')
            ]));
        } else {
            $activation->status = 'active';
            $activation->is_local = $isLocalSite ? 1 : 0;
            $activation->last_update_date = gmdate('Y-m-d H:i:s');
            $activation->product_id = $license->product_id;
            $activation->variation_id = $license->variation_id;
            $activation->variation_title = $license->variation->variation_title ?? '';
            $activation->save();
        }

        // Let's recount the activations count
        $license->recountActivations();

        return [
            'site'       => $site,
            'activation' => $activation,
            'created'    => true,
        ];
    }

    public function deActivateLicense($data = [])
    {
        $formattedData = [
            'license_key' => sanitize_text_field(Arr::get($data, 'license_key', '')),
            'item_id'     => sanitize_text_field(Arr::get($data, 'item_id', '')),
            'site_url'    => LicenseHelper::sanitizeSiteUrl(Arr::get($data, 'site_url', '')),
        ];

        if (!$formattedData['site_url'] || !$formattedData['license_key'] || !$formattedData['item_id']) {
            do_action('fluent_cart/license/site_deactivated_failed', $formattedData);

            return $this->sendErrorResponse([
                'message'    => __('license_key, site_url and item_id is required', 'fluent-cart-pro'),
                'error_type' => 'validation_error'
            ], 422);
        }


        $license = License::query()
            ->where('license_key', $formattedData['license_key'])
            ->first();

        if (!$license || $license->product_id != $formattedData['item_id']) {
            do_action('fluent_cart/license/site_deactivated_failed', $formattedData);
            return $this->sendErrorResponse([
                'message'    => __('License not found or does not match with the item_id', 'fluent-cart-pro'),
                'error_type' => 'license_not_found'
            ], 422);
        }

        $siteUrl = $formattedData['site_url'];
        $site = LicenseSite::query()
            ->where('site_url', $siteUrl)
            ->orWhere('site_url', 'www.' . $siteUrl)
            ->first();

        if (!$site) {
            do_action('fluent_cart/license/site_deactivated_failed', $formattedData);
            return $this->sendErrorResponse([
                'message'    => __('Site not found', 'fluent-cart-pro'),
                'error_type' => 'site_not_found'
            ], 422);
        }

        $activation = LicenseActivation::query()
            ->where('license_id', $license->id)
            ->where('site_id', $site->id)
            ->first();

        if ($activation) {
            $activation->delete();
        }

        $license->recountActivations();

        if ($site) {
            do_action('fluent_cart/license/site_deactivated', $site, $activation, $license, $data);
        }

        $returnData = [
            'status'            => 'deactivated',
            'activation_limit'  => $license->limit,
            'activations_count' => $license->activation_count,
            'expiration_date'   => $license->expiration_date,
            'product_id'        => $license->product_id,
            'variation_id'      => $license->variation_id,
            'product_title'     => $license->product ? $license->product->post_title : 'unknown product',
            'variation_title'   => $license->variation->variation_title ?? '',
            'created_at'        => $license->created_at,
            'updated_at'        => $license->updated_at
        ];

        $returnData = apply_filters('fluent_cart/license/deactivate_license_response', $returnData, $license, $activation, $data);

        if (is_wp_error($returnData)) {
            return $this->sendErrorResponse([
                'message'    => $returnData->get_error_message(),
                'error_type' => 'deactivation_error'
            ], 422);
        }

        return $this->sendSuccessResponse($returnData);
    }

    public function getVersion($data = [])
    {
        $itemId = sanitize_text_field(Arr::get($data, 'item_id', ''));
        // Let's find the license version details by this itemId
        $product = Product::query()->find($itemId);

        if (!$product) {
            return $this->sendErrorResponse([
                'message'    => __('Product not found', 'fluent-cart-pro'),
                'error_type' => 'product_not_found'
            ], 422);
        }

        $licenseSettings = $product->getProductMeta('license_settings');
        if (empty($licenseSettings) || !is_array($licenseSettings)) {
            return $this->sendErrorResponse([
                'message'    => __('License settings not found for this product', 'fluent-cart-pro'),
                'error_type' => 'license_settings_not_found'
            ], 422);
        }

        $enabled = Arr::get($licenseSettings, 'enabled', '') === 'yes';
        if (!$enabled) {
            return $this->sendErrorResponse([
                'message'    => __('License is not enabled for this product', 'fluent-cart-pro'),
                'error_type' => 'license_not_enabled'
            ], 422);
        }

        $changelog = (string)$product->getProductMeta('_fluent_sl_changelog');

        $changeLogUrl = Arr::get($licenseSettings, 'wp.readme_url', '');

        if (!$changeLogUrl) {
            $changeLogUrl = get_permalink($product->ID);
        }

        $icon = Arr::get($licenseSettings, 'wp.icon_url', '');
        $bannerURL = Arr::get($licenseSettings, 'wp.banner_url', '');

        $changeLogData = [
            'new_version'    => Arr::get($licenseSettings, 'version', ''),
            'stable_version' => Arr::get($licenseSettings, 'version', ''),
            'name'           => $product->post_title,
            'slug'           => $product->post_name,
            'url'            => $changeLogUrl,
            'last_updated'   => $product->post_modified,
            'homepage'       => get_permalink($product->ID),
            'package'        => '',
            'download_link'  => '',
            'sections'       => [
                'description' => (string)$product->post_excerpt,
                'changelog'   => $changelog
            ],
            'banners'        => [
                'low'  => $bannerURL,
                'high' => $bannerURL
            ],
            'icons'          => [
                '2x' => $icon,
                '1x' => $icon
            ]
        ];

        // A signed release, for stores that publish one. Echoed exactly as
        // stored: the signature covers the manifest's decoded bytes, so any
        // re-encoding here would leave the site with a well-formed pair that
        // verifies against nothing and an update it refuses to install.
        //
        // Present whenever the values are, with no filter in front of them —
        // gating both the storage and the response would let a store fill the
        // fields in and never ship them. Stores that don't sign have nothing
        // stored, so their response is unchanged.
        $changeLogData += ReleaseSignature::fromSettings($licenseSettings);

        $formattedData = array_filter([
            'license_key'     => sanitize_text_field(Arr::get($data, 'license_key', '')),
            'activation_hash' => sanitize_text_field(Arr::get($data, 'activation_hash', '')),
            'item_id'         => sanitize_text_field(Arr::get($data, 'item_id', '')),
            'site_url'        => LicenseHelper::sanitizeSiteUrl(Arr::get($data, 'site_url', '')),
        ]);

        [$license, $activation] = LicenseHelper::getLicenseByKeyHashData($formattedData, false);

        // A license for another product must not produce an update offer for
        // this one: the package it resolves to would be the *licensed*
        // product's file, so answering with this product's version would offer
        // a site an update that installs something else.
        //
        // Integer comparison for the same reason as the download path: $itemId
        // is whatever the site was configured with, so "042" must match 42.
        $licenseCoversProduct = !is_wp_error($license) && (int) $license->product_id === (int) $itemId;

        if (is_wp_error($license) || !$license->isValid() || !$licenseCoversProduct) {
            $changeLogData['license_message'] = 'Invalid License Key';
            $changeLogData['license_status'] = 'invalid';
        } else {
            $changeLogData['license_status'] = $license->getPublicStatus();
            if (Arr::get($formattedData, 'activation_hash', '')) {
                $formattedData['license_key'] = '';
            }

            $hash = $this->encodePackageToken([
                'license_key'     => Arr::get($formattedData, 'license_key'),
                'activation_hash' => Arr::get($formattedData, 'activation_hash', ''),
                'site_url'        => Arr::get($formattedData, 'site_url'),
                // From the license, not the request — the two are equal here by
                // the check above, and deriving keeps it that way if it moves.
                'item_id'         => (string) $license->product_id
            ]);

            $packageUrl = add_query_arg([
                'fct_package' => $hash
            ], home_url('?fluent-cart=download_license_package'));

            $changeLogData['download_link'] = $packageUrl;
            $changeLogData['package'] = $packageUrl;
            $changeLogData['trunk'] = $packageUrl;
        }

        if ($activation && $activation->site) {
            $serverVersion = sanitize_text_field(Arr::get($data, 'server_version', ''));
            $platformVersion = sanitize_text_field(Arr::get($data, 'platform_version', ''));
            $site = $activation->site;

            $willUpdate = false;

            if ($serverVersion && $site->server_version !== $serverVersion) {
                $site->server_version = $serverVersion;
                $willUpdate = true;
            }

            if ($platformVersion && $site->platform_version !== $platformVersion) {
                $site->platform_version = $platformVersion;
                $willUpdate = true;
            }

            if ($willUpdate) {
                $site->save();
            }

            $userSiteVersion = sanitize_text_field(Arr::get($data, 'current_version', ''));

            if ($userSiteVersion && $userSiteVersion != $activation->last_update_version) {
                $activation->last_update_version = $userSiteVersion;
                $activation->save();
            }
        }

        $returnData = apply_filters('fluent_cart/license/get_version_response', $changeLogData, $product, $data);

        if (is_wp_error($returnData)) {
            return $this->sendErrorResponse([
                'message'    => $returnData->get_error_message(),
                'error_type' => $returnData->get_error_code()
            ], 422);
        }

        return $this->sendSuccessResponse($returnData);
    }

    public function downloadLicensePackage($data = [])
    {
        $packageData = $this->decodePackageToken(Arr::get($data, 'fct_package', ''));

        if (is_wp_error($packageData)) {
            return $this->sendErrorResponse([
                'message'    => $packageData->get_error_message(),
                'error_type' => $packageData->get_error_code()
            ], 422);
        }

        $resolved = $this->resolvePackageDownload($packageData);

        if (is_wp_error($resolved)) {
            return $this->sendErrorResponse([
                'message'    => $resolved->get_error_message(),
                'error_type' => $resolved->get_error_code()
            ], 422);
        }

        $activation = $resolved['activation'];

        if ($activation) {
            // we should add last_update_version
            // get the current version of the software
            $currentSoftwareVersion = sanitize_text_field(Arr::get($resolved['license_settings'], 'version', ''));
            if ($currentSoftwareVersion) {
                $activation->last_update_version = $currentSoftwareVersion;
                $activation->last_update_date = gmdate('Y-m-d H:i:s');
                $activation->save();
            }
        }

        $signedDownlloadUrl = Helper::generateDownloadFileLink($resolved['downloadable_file']);

        if ($signedDownlloadUrl) {
            header('Location: ' . $signedDownlloadUrl);
            exit();
        }

        die('Download link is not available for this product.');
    }

    /**
     * Resolve what a decoded package token is actually entitled to download.
     *
     * SECURITY — the two rules here are not interchangeable, and the order
     * matters:
     *
     *   1. The product is *derived* from `$license->product_id`. A License
     *      carries exactly one product_id, so this derivation is what confines
     *      a token to the single product its license was issued for. It is the
     *      entitlement model on its own: even if every other field in the token
     *      were attacker-chosen, the download could not leave that product.
     *   2. A token-supplied `item_id`, when present, is *verified* against the
     *      same value and a mismatch is refused. This catches a caller asking
     *      for the wrong thing and says so, instead of silently serving
     *      something else — but it is a consistency check, not the boundary.
     *
     * Never invert these by resolving the product from `item_id` and treating
     * rule 2 as the guard. That is the shape this code had before, and it let
     * anyone holding any valid license key download any other product's package
     * by editing one field.
     *
     * @param array $packageData Decoded token payload
     * @return array|\WP_Error
     */
    private function resolvePackageDownload($packageData)
    {
        $data = [
            'license_key'     => sanitize_text_field(Arr::get($packageData, 'license_key', '')),
            'activation_hash' => sanitize_text_field(Arr::get($packageData, 'activation_hash', '')),
            'site_url'        => LicenseHelper::sanitizeSiteUrl(Arr::get($packageData, 'site_url', '')),
            'item_id'         => sanitize_text_field(Arr::get($packageData, 'item_id', ''))
        ];

        [$license, $activation] = LicenseHelper::getLicenseByKeyHashData($data, false);

        if (is_wp_error($license)) {
            return $license;
        }

        if (!$license->isValid()) {
            return new \WP_Error('expired_license', __('This license key is not valid', 'fluent-cart-pro'));
        }

        // Rule 2. Absent on legacy positional tokens, where the field sat at a
        // position that a site_url with a scheme could shift — so it is checked
        // when supplied rather than required, and its absence is never fatal.
        //
        // Compared as integers on purpose. The stored product_id is canonical
        // but the token's copy came from whatever the site was configured with,
        // so "042" must match product 42. Leniency is safe here precisely
        // because this is not the boundary: a value that squeaks past still
        // downloads the licensed product, whereas a false refusal would strand
        // an honest site with an update it can never install.
        if ($data['item_id'] && (int) $data['item_id'] !== (int) $license->product_id) {
            return new \WP_Error('key_mismatch', __('This license key is not valid for this product', 'fluent-cart-pro'));
        }

        // Rule 1. The product comes from the license, never from the token.
        // See the docblock above before changing this line.
        $product = Product::query()->find($license->product_id);

        if (!$product) {
            return new \WP_Error('product_not_found', __('Product not found', 'fluent-cart-pro'));
        }

        $licenseSettings = $product->getProductMeta('license_settings');
        $enabled = Arr::get($licenseSettings, 'enabled', '') === 'yes';

        if (!$enabled) {
            return new \WP_Error('license_not_enabled', __('License is not enabled for this product', 'fluent-cart-pro'));
        }

        $downloadableFiles = $product->downloadable_files;
        $downloadableFile = null;

        $updateFileId = Arr::get($licenseSettings, 'global_update_file', '');
        if ($updateFileId) {
            $downloadableFile = $downloadableFiles->firstWhere('id', $updateFileId);
        }

        if (!$downloadableFile && $downloadableFiles->count() == 1) {
            $downloadableFile = $downloadableFiles->first();
        }

        if (!$downloadableFile) {
            return new \WP_Error('downloadable_file_not_found', __('No downloadable file found for this product', 'fluent-cart-pro'));
        }

        return [
            'license'           => $license,
            'activation'        => $activation,
            'product'           => $product,
            'license_settings'  => $licenseSettings,
            'downloadable_file' => $downloadableFile
        ];
    }

    /**
     * Wrap package payload fields for transport in an update transient.
     *
     * This is an envelope, not a credential: it is deliberately unsigned, and
     * it carries only what resolvePackageDownload() actually reads — the
     * license key (or activation hash), the site to stamp, and the product id
     * it expects to be served. That last one is minted from the license and
     * re-checked against the license on the way back in, so it is a consistency
     * field rather than an instruction. There is no expiry: an unsigned expiry
     * is attacker-editable, so carrying one would only invite a later change to
     * enforce it against honest updates.
     *
     * The token is therefore deterministic for a given license and site, which
     * lets the CDN in front of this API construct it at the edge and cache
     * version responses per product instead of per license.
     *
     * That edge-side construction is why the encoding is pinned rather than
     * incidental. The field order below is part of the wire format, and
     * JSON_UNESCAPED_SLASHES is required because PHP escapes forward slashes by
     * default and JSON.stringify does not — without it every token containing a
     * URL would differ from the byte-identical one the edge builds. Do not add
     * JSON_UNESCAPED_UNICODE: PHP and JS both escape non-ASCII to \uXXXX, so
     * leaving it off is what keeps IDN site urls matching.
     *
     * The same goes for `site_url`, which is LicenseHelper::sanitizeSiteUrl()
     * output — the edge mirrors that transform to reach the same bytes. Hooking
     * `fluent_cart/license/sanitized_url` changes it here and not there, so
     * edge-built tokens would quietly stop matching origin-built ones. Nothing
     * subscribes to that filter today.
     * The same caution applies to `fluent_cart/license/get_version_response`,
     * which runs after this and could rewrite the package URL wholesale, and
     * to WordPress's own `home_url` filter, which supplies the host the package
     * URL is built on. That last one is the likeliest to move without anyone
     * touching this file: it is core, third-party plugins do hook it (some
     * append query args, some rewrite the scheme), and a snippets plugin can
     * introduce one with no deploy at all.
     */
    private function encodePackageToken($payload)
    {
        // URL-safe base64: '+' in standard base64 decodes as a space when the
        // URL is fetched over GET, which would corrupt the token.
        return rtrim(strtr(base64_encode(wp_json_encode($payload, JSON_UNESCAPED_SLASHES)), '+/', '-_'), '=');
    }

    /**
     * Decode a package token into its payload fields.
     *
     * Three shapes are accepted, permanently, all by plain parsing:
     *   1. bare JSON — what encodePackageToken() now emits and what the CDN
     *      edge constructs.
     *   2. "v2:{json}:{hmac}" — minted by 1.6.1 only. No longer produced, but
     *      still sitting in customer update transients. The signature is
     *      unwrapped and discarded rather than verified: the secret it was
     *      signed with is gone, and nothing about it was load-bearing.
     *   3. positional "license_key:activation_hash:site_url:..." — pre-1.6.1.
     *
     * Accepting unsigned tokens is safe because the token does not decide what
     * is served: resolvePackageDownload() resolves the product from the license
     * and only compares `item_id` against it, so forging that field turns a
     * download into a refusal, never into someone else's package.
     *
     * `item_id` is deliberately not recovered from shape 3. It sat at a fixed
     * position there, which a site_url carrying a scheme could shift, so a
     * legacy token's fourth segment is not reliably a product id — and since a
     * mismatch is now refused, reading a shifted value would break exactly the
     * cached URLs this shape exists to keep working. An `expires` field may
     * appear in older payloads; it is likewise not read.
     *
     * @return array|\WP_Error
     */
    private function decodePackageToken($packageHash)
    {
        $raw = base64_decode(strtr((string) $packageHash, '-_', '+/'));

        if (!$raw) {
            return new \WP_Error('invalid_package_data', __('Invalid package data', 'fluent-cart-pro'));
        }

        if (strpos($raw, 'v2:') === 0) {
            $body = substr($raw, 3);
            $signaturePos = strrpos($body, ':');

            if ($signaturePos === false) {
                return new \WP_Error('invalid_package_data', __('Invalid package data', 'fluent-cart-pro'));
            }

            $raw = substr($body, 0, $signaturePos);
        }

        $decoded = json_decode($raw, true);

        if (is_array($decoded)) {
            return $decoded;
        }

        // Pre-1.6.1 positional token. Read at fixed positions exactly as the
        // original parser did, quirks included: a site_url carrying a scheme
        // shifts the trailing fields the way it always did. Nothing past
        // site_url is read anymore, so those quirks no longer decide anything.
        $parts = explode(':', $raw);

        return [
            'license_key'     => Arr::get($parts, 0, ''),
            'activation_hash' => Arr::get($parts, 1, ''),
            'site_url'        => Arr::get($parts, 2, '')
        ];
    }

    /** @return string|false the lock name, or false when it could not be taken */
    private function acquireActivationLock($licenseId)
    {
        global $wpdb;

        // GET_LOCK names are shared by every site on the MySQL server.
        $lock = 'fct_license_activate_' . md5(constant('DB_NAME') . ':' . $wpdb->options . ':' . $licenseId);

        return (string) $wpdb->get_var($wpdb->prepare('SELECT GET_LOCK(%s, %d)', $lock, 5)) === '1' ? $lock : false;
    }

    private function releaseActivationLock($lock)
    {
        global $wpdb;

        $wpdb->get_var($wpdb->prepare('SELECT RELEASE_LOCK(%s)', $lock));
    }

    private function sendSuccessResponse(array $data, int $code = 200)
    {
        $data['success'] = true;
        wp_send_json($data, $code);
    }

    private function sendErrorResponse(array $data, int $code = 400)
    {
        if (empty($data['success'])) {
            $data['success'] = false;
        }

        wp_send_json($data, $code);
    }

}
