<?php
/**
 * The sales window of a ticket preset: the ticket form's options, but no specific date, and the rule they make in the
 * field the preset form and the *Save as preset* modal post.
 *
 * @since 6.12.0
 *
 * @version 6.12.0
 *
 * @var string                                                                                                                                          $field_prefix           The prefix of the ids of the window's options.
 * @var array{start: array{mode: string, value?: int, unit?: int, anchor?: string}, end: array{mode: string, value?: int, unit?: int, anchor?: string}} $form_rule              The rule the window starts from.
 * @var Tribe__Tickets__Admin__Views                                                                                                                    $sales_window_template  The Event Tickets template that renders the window's options.
 * @var array<string,mixed>                                                                                                                             $sales_window_context   The context of Event Tickets' `relative-sale-dates/sales-window` view, as `Editor::get_preset_sales_window_context()` builds it.
 * @var bool                                                                                                                                            $has_unsupported_option Whether the preset stores an option the form no longer offers.
 * @var string                                                                                                                                          $rule_field_name        The name of the field the rule is posted in.
 */

defined( 'ABSPATH' ) || exit;
?>
<div class="tec-tickets-plus-preset__field tec-tickets-plus-preset__sales-window" data-field-prefix="<?php echo esc_attr( $field_prefix ); ?>">
	<?php $sales_window_template->template( 'relative-sale-dates/sales-window', $sales_window_context ); ?>
	<?php if ( $has_unsupported_option ) : ?>
		<p class="tec-tickets-plus-preset__sales-window-notice">
			<?php esc_html_e( 'This preset was saved with a sales date option the form no longer offers. Saving the preset replaces it with the option shown.', 'event-tickets-plus' ); ?>
		</p>
	<?php endif; ?>
	<input
		type="hidden"
		class="tec-tickets-plus-preset__sales-window-rule"
		name="<?php echo esc_attr( $rule_field_name ); ?>"
		value="<?php echo esc_attr( wp_json_encode( $form_rule ) ); ?>"
	/>
</div>
