<?php

namespace MasterStudy\Lms\Pro\AddonsPlus\Notifications\Repositories;

final class PushSubscriptionRepository {
	public const BROWSER_KEY_MAX_LENGTH       = 64;
	public const ENDPOINT_MAX_LENGTH          = 500;
	public const PUBLIC_KEY_MAX_LENGTH        = 255;
	public const AUTH_TOKEN_MAX_LENGTH        = 128;
	public const CONTENT_ENCODING_MAX_LENGTH  = 20;
	public const SUBSCRIPTION_JSON_MAX_LENGTH = 2048;
	public const USER_AGENT_MAX_LENGTH        = 255;
	public const ALLOWED_ENCODINGS            = array( 'aes128gcm', 'aesgcm' );
	private const ACTIVE_LIMIT                = 10;
	private const ALLOWED_ENDPOINT_HOSTS      = array(
		'fcm.googleapis.com',
		'android.googleapis.com',
		'updates.push.services.mozilla.com',
		'push.services.mozilla.com',
		'*.push.apple.com',
	);

	public function upsert( int $user_id, string $browser_key, array $subscription, string $user_agent = '' ): bool {
		global $wpdb;

		$browser_key       = sanitize_text_field( $browser_key );
		$endpoint          = isset( $subscription['endpoint'] ) ? esc_url_raw( $subscription['endpoint'] ) : '';
		$keys              = isset( $subscription['keys'] ) && is_array( $subscription['keys'] ) ? $subscription['keys'] : array();
		$content_encoding  = sanitize_text_field( $subscription['contentEncoding'] ?? 'aes128gcm' );
		$public_key        = sanitize_text_field( $keys['p256dh'] ?? '' );
		$auth_token        = sanitize_text_field( $keys['auth'] ?? '' );
		$subscription_json = wp_json_encode( $subscription );

		if (
			$user_id <= 0
			|| '' === $browser_key
			|| strlen( $browser_key ) > self::BROWSER_KEY_MAX_LENGTH
			|| '' === $endpoint
			|| strlen( $endpoint ) > self::ENDPOINT_MAX_LENGTH
			|| '' === $public_key
			|| strlen( $public_key ) > self::PUBLIC_KEY_MAX_LENGTH
			|| '' === $auth_token
			|| strlen( $auth_token ) > self::AUTH_TOKEN_MAX_LENGTH
			|| strlen( $content_encoding ) > self::CONTENT_ENCODING_MAX_LENGTH
			|| false === $subscription_json
			|| strlen( $subscription_json ) > self::SUBSCRIPTION_JSON_MAX_LENGTH
			|| ! $this->is_valid_endpoint( $endpoint )
			|| ! in_array( $content_encoding, self::ALLOWED_ENCODINGS, true )
		) {
			return false;
		}

		$now           = gmdate( 'Y-m-d H:i:s' );
		$endpoint_hash = hash( 'sha256', $endpoint );
		$data          = array(
			'user_id'          => $user_id,
			'browser_key'      => sanitize_text_field( $browser_key ),
			'endpoint_hash'    => $endpoint_hash,
			'endpoint'         => $endpoint,
			'public_key'       => $public_key,
			'auth_token'       => $auth_token,
			'content_encoding' => $content_encoding,
			'subscription'     => $subscription_json,
			'status'           => 'active',
			'user_agent'       => $this->limit_string( sanitize_text_field( $user_agent ), self::USER_AGENT_MAX_LENGTH ),
			'created_at_gmt'   => $now,
			'updated_at_gmt'   => $now,
		);

		$this->deactivate_other_browser_keys_for_endpoint( $endpoint_hash, $browser_key );

		$existing_id = $this->find_id_by_browser_key( $browser_key );

		if ( $existing_id > 0 ) {
			unset( $data['created_at_gmt'] );

			$updated = false !== $wpdb->update(
				masterstudy_lms_notification_push_subscriptions_table_name( $wpdb ),
				$data,
				array( 'id' => $existing_id ),
				array( '%d', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s' ),
				array( '%d' )
			);

			if ( $updated ) {
				$this->enforce_active_limit( $user_id );
			}

			return $updated;
		}

		$inserted = false !== $wpdb->insert(
			masterstudy_lms_notification_push_subscriptions_table_name( $wpdb ),
			$data,
			array( '%d', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s' )
		);

		if ( $inserted ) {
			$this->enforce_active_limit( $user_id );
		}

		return $inserted;
	}

	public function find_id_by_browser_key( string $browser_key ): int {
		global $wpdb;

		if ( '' === $browser_key ) {
			return 0;
		}

		return (int) $wpdb->get_var(
			$wpdb->prepare(
				// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- Table name is generated from $wpdb->prefix.
				'SELECT id FROM ' . masterstudy_lms_notification_push_subscriptions_table_name( $wpdb ) . ' WHERE browser_key = %s LIMIT 1',
				$browser_key
			)
		);
	}

	public function active_for_user( int $user_id ): array {
		if ( $user_id <= 0 ) {
			return array();
		}

		$subscriptions = $this->active_for_users( array( $user_id ) );

		return $subscriptions[ $user_id ] ?? array();
	}

	public function active_for_users( array $user_ids ): array {
		global $wpdb;

		$user_ids = $this->sanitize_ids( $user_ids );

		if ( empty( $user_ids ) ) {
			return array();
		}

		$table        = masterstudy_lms_notification_push_subscriptions_table_name( $wpdb );
		$placeholders = implode( ',', array_fill( 0, count( $user_ids ), '%d' ) );
		$params       = array_merge( $user_ids, array( 'active' ) );
		// phpcs:disable WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Table name and IN placeholders are generated internally.
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT *
				FROM {$table}
				WHERE user_id IN ({$placeholders}) AND status = %s
				ORDER BY user_id ASC, updated_at_gmt DESC, id DESC",
				$params
			),
			ARRAY_A
		);
		// phpcs:enable WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$grouped = array();

		foreach ( $rows as $row ) {
			$user_id = (int) $row['user_id'];

			if ( ! isset( $grouped[ $user_id ] ) ) {
				$grouped[ $user_id ] = array();
			}

			$grouped[ $user_id ][] = $row;
		}

		return $grouped;
	}

	public function deactivate_by_browser_key( int $user_id, string $browser_key ): bool {
		global $wpdb;

		if ( $user_id <= 0 || '' === $browser_key ) {
			return false;
		}

		return false !== $wpdb->update(
			masterstudy_lms_notification_push_subscriptions_table_name( $wpdb ),
			array(
				'status'         => 'inactive',
				'updated_at_gmt' => gmdate( 'Y-m-d H:i:s' ),
			),
			array(
				'user_id'     => $user_id,
				'browser_key' => sanitize_text_field( $browser_key ),
			),
			array( '%s', '%s' ),
			array( '%d', '%s' )
		);
	}

	public function deactivate_by_endpoint( string $endpoint ): bool {
		global $wpdb;

		if ( '' === $endpoint ) {
			return false;
		}

		return false !== $wpdb->update(
			masterstudy_lms_notification_push_subscriptions_table_name( $wpdb ),
			array(
				'status'         => 'inactive',
				'updated_at_gmt' => gmdate( 'Y-m-d H:i:s' ),
			),
			array( 'endpoint_hash' => hash( 'sha256', $endpoint ) ),
			array( '%s', '%s' ),
			array( '%s' )
		);
	}

	private function deactivate_other_browser_keys_for_endpoint( string $endpoint_hash, string $browser_key ): void {
		global $wpdb;

		$wpdb->query(
			$wpdb->prepare(
				// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- Table name is generated from $wpdb->prefix.
				'UPDATE ' . masterstudy_lms_notification_push_subscriptions_table_name( $wpdb ) . ' SET status = %s, updated_at_gmt = %s WHERE endpoint_hash = %s AND browser_key != %s',
				'inactive',
				gmdate( 'Y-m-d H:i:s' ),
				$endpoint_hash,
				sanitize_text_field( $browser_key )
			)
		);
	}

	private function enforce_active_limit( int $user_id ): void {
		global $wpdb;

		if ( $user_id <= 0 ) {
			return;
		}

		$ids = $wpdb->get_col(
			$wpdb->prepare(
				// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- Table name is generated from $wpdb->prefix.
				'SELECT id FROM ' . masterstudy_lms_notification_push_subscriptions_table_name( $wpdb ) . ' WHERE user_id = %d AND status = %s ORDER BY updated_at_gmt DESC, id DESC',
				$user_id,
				'active'
			)
		);

		if ( count( $ids ) <= self::ACTIVE_LIMIT ) {
			return;
		}

		$ids          = array_map( 'absint', array_slice( $ids, self::ACTIVE_LIMIT ) );
		$placeholders = implode( ',', array_fill( 0, count( $ids ), '%d' ) );
		$params       = array_merge( array( 'inactive', gmdate( 'Y-m-d H:i:s' ) ), $ids );

		// phpcs:disable WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare -- Table name and IN placeholders are generated internally.
		$wpdb->query(
			$wpdb->prepare(
				'UPDATE ' . masterstudy_lms_notification_push_subscriptions_table_name( $wpdb ) . " SET status = %s, updated_at_gmt = %s WHERE id IN ({$placeholders})",
				$params
			)
		);
		// phpcs:enable WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare
	}

	private function is_valid_endpoint( string $endpoint ): bool {
		$parts = wp_parse_url( $endpoint );

		if ( ! is_array( $parts ) || empty( $parts['scheme'] ) || empty( $parts['host'] ) ) {
			return false;
		}

		$scheme = strtolower( (string) $parts['scheme'] );
		$host   = strtolower( trim( (string) $parts['host'], '[]' ) );

		if ( $this->is_loopback_host( $host ) ) {
			if ( $this->is_local_environment() && in_array( $scheme, array( 'http', 'https' ), true ) ) {
				return true;
			}

			return false;
		}

		if ( 'https' !== $scheme ) {
			return false;
		}

		if ( filter_var( $host, FILTER_VALIDATE_IP ) ) {
			return false;
		}

		if ( ! filter_var( $host, FILTER_VALIDATE_DOMAIN, FILTER_FLAG_HOSTNAME ) ) {
			return false;
		}

		if ( $this->is_allowed_endpoint_host( $host ) ) {
			return true;
		}

		return false;
	}

	private function is_loopback_host( string $host ): bool {
		return in_array( $host, array( 'localhost', '127.0.0.1', '::1' ), true );
	}

	private function is_allowed_endpoint_host( string $host ): bool {
		foreach ( $this->allowed_endpoint_hosts() as $allowed_host ) {
			if ( $host === $allowed_host ) {
				return true;
			}

			if ( 0 === strpos( $allowed_host, '*.' ) ) {
				$suffix = substr( $allowed_host, 1 );

				if ( ltrim( $suffix, '.' ) !== $host && substr( $host, -strlen( $suffix ) ) === $suffix ) {
					return true;
				}
			}
		}

		return false;
	}

	private function limit_string( string $value, int $length ): string {
		if ( function_exists( 'mb_substr' ) ) {
			return mb_substr( $value, 0, $length );
		}

		return substr( $value, 0, $length );
	}

	private function allowed_endpoint_hosts(): array {
		/**
		 * Filters allowed browser push service endpoint hosts.
		 *
		 * Wildcards may be expressed as suffix values like "*.push.apple.com".
		 *
		 * @param array $hosts Allowed endpoint hosts.
		 */
		$hosts = apply_filters( 'masterstudy_notifications_allowed_push_endpoint_hosts', self::ALLOWED_ENDPOINT_HOSTS );

		if ( ! is_array( $hosts ) ) {
			$hosts = self::ALLOWED_ENDPOINT_HOSTS;
		}

		return array_values(
			array_unique(
				array_filter(
					array_map(
						static function ( $host ): string {
							return strtolower( trim( sanitize_text_field( (string) $host ) ) );
						},
						$hosts
					)
				)
			)
		);
	}

	private function is_local_environment(): bool {
		$is_local = function_exists( 'wp_get_environment_type' ) && 'local' === wp_get_environment_type();

		return $is_local || ( defined( 'WP_DEBUG' ) && WP_DEBUG );
	}

	private function sanitize_ids( array $ids ): array {
		return array_values( array_unique( array_filter( array_map( 'absint', $ids ) ) ) );
	}
}
