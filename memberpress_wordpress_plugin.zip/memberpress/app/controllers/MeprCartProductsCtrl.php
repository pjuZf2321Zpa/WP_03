<?php

if (!defined('ABSPATH')) {
    die('You are not allowed to call this page directly.');
}

class MeprCartProductsCtrl extends MeprBaseCartCtrl
{
    /**
     * Load hooks for cart product administration.
     *
     * @return void
     */
    public function load_hooks()
    {
        add_action('mepr_product_terms_before', [$this, 'add_product_type_sidebar']);
        add_action('mepr_membership_meta_boxes', [$this, 'register_cart_shop_metabox']);
        add_action('mepr_membership_save_meta', [$this, 'save_cart_shop_meta']);
        add_action('admin_enqueue_scripts', [$this, 'enqueue_admin_scripts']);
        add_filter('get_user_option_meta-box-order_' . MeprProduct::$cpt, [$this, 'ensure_cart_shop_metabox_order']);
    }

    /**
     * Add the product type dropdown to the top of the sidebar Product Terms meta box.
     *
     * @param  MeprProduct $product The current product.
     * @return void
     */
    public function add_product_type_sidebar(MeprProduct $product)
    {
        $type = get_post_meta($product->ID, MeprProduct::$type_str, true);
        if ('' === $type) {
            $type = 'membership';
        }
        ?>
        <p>
            <strong><?php esc_html_e('Product Type:', 'memberpress'); ?></strong>
        </p>
        <p>
            <?php // Options derive from the available types; labels from the canonical type_labels(). ?>
            <select name="<?php echo esc_attr(MeprProduct::$type_str); ?>" id="<?php echo esc_attr(MeprProduct::$type_str); ?>">
                <?php foreach (MeprProduct::available_types() as $mepr_type) : ?>
                    <option value="<?php echo esc_attr($mepr_type); ?>"<?php selected($type, $mepr_type); ?>><?php echo esc_html(MeprProduct::type_labels()[$mepr_type] ?? $mepr_type); ?></option>
                <?php endforeach; ?>
            </select>
        </p>
        <?php
    }

    /**
     * Register the Cart & Shop meta box, rendered above the Publish box ('side'/'high').
     *
     * @param  MeprProduct $product The current product.
     * @return void
     */
    public function register_cart_shop_metabox(MeprProduct $product)
    {
        add_meta_box(
            'memberpress-cart-shop',
            __('Cart &amp; Shop', 'memberpress'),
            [$this, 'render_cart_shop_metabox'],
            MeprProduct::$cpt,
            'side',
            'high',
            ['product' => $product]
        );
    }

    /**
     * Default the Cart & Shop meta box to sit right after Product Terms in the sidebar.
     *
     * A user's saved meta-box order (from dragging boxes) otherwise appends any box that
     * didn't exist when the order was saved to the bottom of the column. We inject it after
     * Product Terms only when it's absent, so an explicit user placement is still respected.
     *
     * @param  array|false $order The saved meta-box order keyed by context, or false when none.
     * @return array|false
     */
    public function ensure_cart_shop_metabox_order($order)
    {
        // No saved order → WordPress falls back to registration order (already after Product Terms).
        if (!is_array($order)) {
            return $order;
        }

        // Respect an explicit user placement: if the box already appears in ANY context
        // (the user dragged it — even to a different column), leave the saved order untouched.
        foreach ($order as $context_ids) {
            if (in_array('memberpress-cart-shop', array_map('trim', explode(',', (string) $context_ids)), true)) {
                return $order;
            }
        }

        // Not placed yet → default it right after Product Terms in the side column.
        if (empty($order['side'])) {
            return $order;
        }

        $ids = array_filter(array_map('trim', explode(',', $order['side'])));
        $pos = array_search('memberpress-product-meta', $ids, true);
        if (false === $pos) {
            array_unshift($ids, 'memberpress-cart-shop');
        } else {
            array_splice($ids, $pos + 1, 0, 'memberpress-cart-shop');
        }

        $order['side'] = implode(',', $ids);

        return $order;
    }

    /**
     * Render the Cart & Shop meta box content.
     *
     * @param  WP_Post $post    The current post.
     * @param  array   $metabox Meta box registration args (carries the product).
     * @return void
     */
    public function render_cart_shop_metabox($post, $metabox)
    {
        $product = $metabox['args']['product'];
        ?>
        <div class="cart-shop">
            <?php MeprView::render('/admin/products/cart_shop', get_defined_vars()); ?>
        </div>
        <?php
    }

    /**
     * Save cart and shop meta fields when a product is saved.
     *
     * @param  MeprProduct $product The current product.
     * @return void
     */
    public function save_cart_shop_meta(MeprProduct $product)
    {
        $id = $product->ID;

        // Product type (membership, digital, physical).
        $type = isset($_POST[MeprProduct::$type_str]) ? sanitize_text_field(wp_unslash($_POST[MeprProduct::$type_str])) : 'membership';
        if (!in_array($type, ['membership', 'digital', 'physical'], true)) {
            $type = 'membership';
        }
        update_post_meta($id, MeprProduct::$type_str, $type);

        // Registration page toggle (checkbox — store as '1'/'0' string so that
        // get_post_meta returning '' can be distinguished as "never set" for backward compat).
        // Membership-only: force off for digital/physical regardless of the posted value.
        $enable_registration_page = isset($_POST[MeprProduct::$enable_registration_page_str]) ? '1' : '0';
        if ($type !== MeprProduct::TYPE_MEMBERSHIP) {
            $enable_registration_page = '0';
        }
        update_post_meta($id, MeprProduct::$enable_registration_page_str, $enable_registration_page);

        // Customize Payment Methods / User Information Fields are standalone-registration-only
        // (UI hides them for other types and when Standalone registration page is off). Force them
        // off so a cart-only product can never carry them. Runs after the legacy save (store_meta)
        // on mepr_membership_save_meta, so these overrides win.
        if ($type !== MeprProduct::TYPE_MEMBERSHIP || $enable_registration_page !== '1') {
            update_post_meta($id, MeprProduct::$customize_payment_methods_str, false);
            update_post_meta($id, MeprProduct::$customize_profile_fields_str, false);
        }

        // Custom thank-you *page* redirects apply only with a standalone registration page.
        // Cart checkout uses the thank-you *message* path — fall back if page was selected.
        if ($enable_registration_page !== '1') {
            $thank_you_type = get_post_meta($id, MeprProduct::$thank_you_page_type_str, true);
            if ($thank_you_type === 'page') {
                update_post_meta($id, MeprProduct::$thank_you_page_type_str, 'message');
            }
        }

        // SKU.
        $sku = isset($_POST[MeprProduct::$sku_str]) ? sanitize_text_field(wp_unslash($_POST[MeprProduct::$sku_str])) : '';
        update_post_meta($id, MeprProduct::$sku_str, $sku);

        // Shop page visibility.
        $shop_visibility = isset($_POST[MeprProduct::$shop_visibility_str]) ? sanitize_text_field(wp_unslash($_POST[MeprProduct::$shop_visibility_str])) : 'visible';
        if (!in_array($shop_visibility, ['visible', 'hidden'], true)) {
            $shop_visibility = 'visible';
        }
        update_post_meta($id, MeprProduct::$shop_visibility_str, $shop_visibility);

        if ($type === MeprProduct::TYPE_MEMBERSHIP) {
            update_post_meta($id, MeprProduct::$max_quantity_str, 1);
        } else {
            $max_quantity_raw = isset($_POST[MeprProduct::$max_quantity_str]) ? sanitize_text_field(wp_unslash($_POST[MeprProduct::$max_quantity_str])) : '';
            $max_quantity     = ('' !== $max_quantity_raw && is_numeric($max_quantity_raw))
                ? min(MeprCartSessionService::MAX_ITEM_QTY, absint($max_quantity_raw))
                : MeprCartSessionService::MAX_ITEM_QTY;
            update_post_meta($id, MeprProduct::$max_quantity_str, $max_quantity);
        }

        // Requires shipping (checkbox — boolean).
        $requires_shipping = isset($_POST[MeprProduct::$requires_shipping_str]);
        update_post_meta($id, MeprProduct::$requires_shipping_str, $requires_shipping);

        // Flat-rate shipping cost.
        $shipping_cost_raw = isset($_POST[MeprProduct::$shipping_cost_str]) ? sanitize_text_field(wp_unslash($_POST[MeprProduct::$shipping_cost_str])) : '0.00';
        $shipping_cost     = MeprUtils::format_currency_us_float($shipping_cost_raw);
        update_post_meta($id, MeprProduct::$shipping_cost_str, $shipping_cost);

        // Weight (physical products only — save for all types, JS hides the field for non-physical).
        $weight_raw = isset($_POST[MeprProduct::$weight_str]) ? sanitize_text_field(wp_unslash($_POST[MeprProduct::$weight_str])) : '';
        $weight     = ('' !== $weight_raw && is_numeric($weight_raw)) ? (float) $weight_raw : '';
        update_post_meta($id, MeprProduct::$weight_str, $weight);

        $weight_unit = isset($_POST[MeprProduct::$weight_unit_str]) ? sanitize_text_field(wp_unslash($_POST[MeprProduct::$weight_unit_str])) : 'lbs';
        if (!in_array($weight_unit, ['lbs', 'kg', 'oz', 'g'], true)) {
            $weight_unit = 'lbs';
        }
        update_post_meta($id, MeprProduct::$weight_unit_str, $weight_unit);

        // Period type: digital and physical are always lifetime (one-time purchase).
        // Membership products save the submitted value unchanged.
        if (in_array($type, ['digital', 'physical'], true)) {
            update_post_meta($id, MeprProduct::$period_type_str, 'lifetime');
        } else {
            // Membership — pass the submitted period_type through after sanitising.
            $period_type = isset($_POST[MeprProduct::$period_type_str]) ? sanitize_text_field(wp_unslash($_POST[MeprProduct::$period_type_str])) : 'lifetime';
            if (!in_array($period_type, ['weeks', 'months', 'years', 'lifetime', 'week', 'month', 'year'], true)) {
                $period_type = 'lifetime';
            }
            update_post_meta($id, MeprProduct::$period_type_str, $period_type);
        }
    }

    /**
     * Enqueue admin JavaScript for the product type conditional field visibility.
     * Only loads on product edit screens.
     *
     * @param  string $hook The current admin page hook.
     * @return void
     */
    public function enqueue_admin_scripts($hook)
    {
        if (!in_array($hook, ['post.php', 'post-new.php'], true)) {
            return;
        }

        $screen = get_current_screen();
        if (!$screen || $screen->post_type !== MeprProduct::$cpt) {
            return;
        }

        wp_enqueue_style(
            'mepr-admin-cart-product',
            MEPR_CSS_URL . '/admin-cart-product.css',
            ['mepr-cart-tokens'],
            MEPR_VERSION
        );

        wp_enqueue_script(
            'mepr-cart-product-type',
            MEPR_JS_URL . '/admin/cart-product-type.js',
            ['jquery', 'mepr-products-js'],
            MEPR_VERSION,
            true
        );

        // Expose the product-type constants so the JS never hard-codes the type strings.
        wp_localize_script('mepr-cart-product-type', 'MeprProductTypes', [
            'membership' => MeprProduct::TYPE_MEMBERSHIP,
            'digital'    => MeprProduct::TYPE_DIGITAL,
            'physical'   => MeprProduct::TYPE_PHYSICAL,
        ]);
    }
}
