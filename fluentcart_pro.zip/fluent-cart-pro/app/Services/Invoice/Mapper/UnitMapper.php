<?php

declare(strict_types=1);

namespace FluentCartPro\App\Services\Invoice\Mapper;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Maps unit labels to UN/ECE codes for EN 16931 compliance.
 */
final class UnitMapper
{
    private const UNIT_CODE_PIECE = 'H87';

    private const MAP = [
        'piece'    => 'H87',
        'each'     => 'H87',
        'pcs'      => 'H87',
        'hour'     => 'HUR',
        'hours'    => 'HUR',
        'hrs'      => 'HUR',
        'service'  => 'C62',
        'services' => 'C62',
        'day'      => 'DAY',
        'days'     => 'DAY',
    ];

    public function toCode(string $unit): string
    {
        $key = strtolower(trim($unit));
        return self::MAP[$key] ?? '';
    }

    /**
     * Resolve unit code from order item. Returns UN/ECE code or default H87 (pieces).
     *
     * @param object $item OrderItem with optional payment_type or object_type
     */
    public function resolveFromItem(object $item): string
    {
        // FluentCart items use payment_type (one_time, subscription) and object_type
        $paymentType = $item->payment_type ?? '';
        if ($paymentType === 'subscription') {
            return 'C62'; // service
        }

        return self::UNIT_CODE_PIECE;
    }
}
