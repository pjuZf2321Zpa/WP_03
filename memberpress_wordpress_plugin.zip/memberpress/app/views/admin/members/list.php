<?php if (!defined('ABSPATH')) {
    die('You are not allowed to call this page directly.');
} ?>
<div class="wrap">
  <h1 class="wp-heading-inline">
    <?php esc_html_e('Members', 'memberpress'); ?>
    <?php
    /*
     * Fires inside the heading. Consumers must echo inline phrasing content only
     * (e.g. an escaped title suffix), never block-level HTML, to keep valid <h1> nesting.
     */
    MeprHooks::do_action('mepr_after_admin_members_heading'); ?>
  </h1>
  <a href="<?php echo esc_url(admin_url('admin.php?page=memberpress-members&action=new')); ?>" class="page-title-action"><?php esc_html_e('Add New', 'memberpress'); ?></a>
  <hr class="wp-header-end">

  <?php if (!isset($errors)) {
      // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited
        $errors = '';
  } ?>
  <?php MeprView::render('/admin/errors', compact('errors', 'message')); ?>

  <?php $list_table->display(); ?>
</div>
