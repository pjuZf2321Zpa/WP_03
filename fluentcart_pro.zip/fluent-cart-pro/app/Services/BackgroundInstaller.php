<?php

namespace FluentCartPro\App\Services;

use FluentCart\Framework\Support\Arr;

class BackgroundInstaller
{
    const DEFAULT_ALLOWED_LICENSE_HOST = 'fluentcart.com';
    const DEFAULT_PRO_LICENSE_SETTINGS_KEY = '__fluent-cart-pro_sl_info';

    public function downloadFromGithub($args)
    {
        $githubUrl = Arr::get($args, 'url');
        $pluginSlug = Arr::get($args, 'plugin_slug');
        $path = Arr::get($args, 'path');
        require_once ABSPATH . 'wp-admin/includes/file.php';
        require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
        require_once ABSPATH . 'wp-admin/includes/plugin.php';

        WP_Filesystem();


        $skin = new \Automatic_Upgrader_Skin();
        $upgrader = new \WP_Upgrader($skin);

        ob_start();

        try {

            if (strpos($githubUrl, '/releases/latest') !== false) {
                $downloadUrl = $this->getLatestReleaseDownloadUrl($githubUrl, $path);
                if (is_wp_error($downloadUrl)) {
                    throw new \Exception($downloadUrl->get_error_message());
                }
                $githubUrl = $downloadUrl;
            }

            $download = $upgrader->download_package($githubUrl);


            if (is_wp_error($download)) {
                throw new \Exception(wp_kses_post($download->get_error_message()));
            }

            $working_dir = $upgrader->unpack_package($download, true);

            if (is_wp_error($working_dir)) {
                throw new \Exception(wp_kses_post($working_dir->get_error_message()));
            }

            // Strip macOS "__MACOSX" artifacts so WP's single-folder detection
            // descends into the real plugin folder instead of nesting it too deep.
            $this->removeArchiveArtifacts($working_dir);

            $result = $upgrader->install_package(
                array(
                    'source'                      => $working_dir,
                    'destination'                 => WP_PLUGIN_DIR . '/' . $pluginSlug,
                    'clear_destination'           => false,
                    'abort_if_destination_exists' => false,
                    'clear_working'               => true,
                    'hook_extra'                  => array(
                        'type'   => 'plugin',
                        'action' => 'install',
                    ),
                )
            );

            if (is_wp_error($result)) {
                throw new \Exception(wp_kses_post($result->get_error_message()));
            }

            ob_end_clean();

            wp_clean_plugins_cache();

            $plugin_file = $pluginSlug . '/' . $pluginSlug . '.php';
            $activate_result = activate_plugin($plugin_file);

            if (is_wp_error($activate_result)) {
                throw new \Exception(esc_html($activate_result->get_error_message()));
            };

            return [
                'action' => 'reload'
            ];
        } catch (\Exception $e) {

            ob_end_clean();

            return new \WP_Error('installation_failed', $e->getMessage());
        }
    }

    private function getLatestReleaseDownloadUrl($releasesUrl, $path = 'zipball_url')
    {
        preg_match('#github\.com/([^/]+)/([^/]+)/releases#', $releasesUrl, $matches);

        if (empty($matches[1]) || empty($matches[2])) {
            return new \WP_Error('invalid_url', __('Invalid GitHub releases URL', 'fluent-cart-pro'));
        }

        $owner = $matches[1];
        $repo = $matches[2];

        $api_url = "https://api.github.com/repos/{$owner}/{$repo}/releases/latest";

        $response = wp_remote_get($api_url, [
            'timeout' => 30,
            'headers' => [
                'Accept'     => 'application/vnd.github.v3+json',
                'User-Agent' => 'FluentCart/' . FLUENTCART_VERSION
            ]
        ]);


        if (is_wp_error($response)) {
            return new \WP_Error('api_error', $response->get_error_message());
        }


        $code = wp_remote_retrieve_response_code($response);

        if ($code !== 200) {
            return new \WP_Error('api_error', 'Github API error with status code: ' . $code);
        }

        $body = wp_remote_retrieve_body($response);

        $data = json_decode($body, true);


        $url = Arr::get($data, $path);
        if (empty($url)) {
            return new \WP_Error('no_release', 'No release found. Please ensure the repository has published releases.');
        }

        return $url;
    }


    public function downloadFromUrl($args)
    {
        $url = Arr::get($args, 'url');
        $pluginSlug = Arr::get($args, 'plugin_slug');

        if ($this->isLicensedAddon($pluginSlug)) {
            $url = $this->getLicensedAddonDownloadUrl($pluginSlug);
            if (is_wp_error($url)) {
                return $url;
            }
        }

        if (empty($url) || !filter_var($url, FILTER_VALIDATE_URL)) {
            return new \WP_Error('invalid_url', __('A valid URL is required.', 'fluent-cart-pro'));
        }

        $pluginSlug = sanitize_key($pluginSlug);
        if (empty($pluginSlug)) {
            return new \WP_Error('invalid_slug', __('A valid plugin slug is required.', 'fluent-cart-pro'));
        }

        require_once ABSPATH . 'wp-admin/includes/file.php';
        require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
        require_once ABSPATH . 'wp-admin/includes/plugin.php';

        WP_Filesystem();

        $skin = new \Automatic_Upgrader_Skin();
        $upgrader = new \WP_Upgrader($skin);

        ob_start();

        try {
            $download = $upgrader->download_package($url);

            if (is_wp_error($download)) {
                throw new \Exception(wp_kses_post($download->get_error_message()));
            }

            $working_dir = $upgrader->unpack_package($download, true);

            if (is_wp_error($working_dir)) {
                throw new \Exception(wp_kses_post($working_dir->get_error_message()));
            }

            // Zips built on macOS carry a top-level "__MACOSX" resource-fork folder
            // alongside the real plugin folder. That extra root entry breaks
            // WP_Upgrader::install_package() single-folder detection, which then
            // installs the plugin one directory too deep and activation fails.
            $this->removeArchiveArtifacts($working_dir);

            $result = $upgrader->install_package(
                array(
                    'source'                      => $working_dir,
                    'destination'                 => WP_PLUGIN_DIR . '/' . $pluginSlug,
                    'clear_destination'           => false,
                    'abort_if_destination_exists' => false,
                    'clear_working'               => true,
                    'hook_extra'                  => array(
                        'type'   => 'plugin',
                        'action' => 'install',
                    ),
                )
            );

            if (is_wp_error($result)) {
                throw new \Exception(wp_kses_post($result->get_error_message()));
            }

            ob_end_clean();

            wp_clean_plugins_cache();

            $plugin_file = $pluginSlug . '/' . $pluginSlug . '.php';
            $activate_result = activate_plugin($plugin_file);

            if (is_wp_error($activate_result)) {
                throw new \Exception(esc_html($activate_result->get_error_message()));
            }

            return [
                'action' => 'reload'
            ];
        } catch (\Exception $e) {
            ob_end_clean();

            return new \WP_Error('installation_failed', $e->getMessage());
        }
    }

    /**
     * Strip macOS-specific artifacts ("__MACOSX") from an unpacked archive so a
     * single real plugin folder remains. Without this, WP_Upgrader's single-folder
     * detection sees multiple root entries and installs the plugin nested too deep.
     *
     * @param string $workingDir
     * @return void
     */
    private function removeArchiveArtifacts($workingDir)
    {
        global $wp_filesystem;

        if (empty($wp_filesystem) || empty($workingDir)) {
            return;
        }

        $macArtifact = trailingslashit($workingDir) . '__MACOSX';
        if ($wp_filesystem->exists($macArtifact)) {
            $wp_filesystem->delete($macArtifact, true);
        }
    }

    private function getLicensedAddonDownloadUrl($addonSlug)
    {
        $addon = $this->getRegisteredAddonBySlug($addonSlug);
        $licenseConfig = Arr::get($addon, 'license_required', []);
        $sourceLink = esc_url_raw((string)Arr::get($addon, 'source_link', ''));

        if (empty($licenseConfig['parent_product_id']) || empty($sourceLink) || !wp_http_validate_url($sourceLink)) {
            return new \WP_Error(
                'addon_config_missing',
                __('Licensed add-on configuration is missing.', 'fluent-cart-pro')
            );
        }

        $requestUrl = add_query_arg(['fluent-cart' => 'get_license_version'], $sourceLink);
        $apiScheme = wp_parse_url($requestUrl, PHP_URL_SCHEME);
        $apiHost = strtolower((string)wp_parse_url($requestUrl, PHP_URL_HOST));
        $allowedHosts = apply_filters('fluent_cart_pro/licensed_addons/allowed_hosts', [self::DEFAULT_ALLOWED_LICENSE_HOST]);
        $allowedHosts = array_filter(array_map(function ($host) {
            return strtolower(trim((string)$host));
        }, (array)$allowedHosts));

        if (!$requestUrl || !wp_http_validate_url($requestUrl) || strtolower((string)$apiScheme) !== 'https') {
            return new \WP_Error(
                'addon_config_invalid',
                __('Licensed add-on API URL is invalid.', 'fluent-cart-pro')
            );
        }

        if (!$apiHost || !in_array($apiHost, $allowedHosts, true)) {
            return new \WP_Error(
                'addon_config_invalid_host',
                __('Licensed add-on API host is not trusted.', 'fluent-cart-pro')
            );
        }

        $licenseInfo = get_option($this->getProLicenseSettingsKey(), []);
        $licenseKey = sanitize_text_field(Arr::get($licenseInfo, 'license_key', ''));
        $activationHash = sanitize_text_field(Arr::get($licenseInfo, 'activation_hash', ''));

        if (!$licenseKey && !$activationHash) {
            return new \WP_Error(
                'license_not_active',
                __('Please activate FluentCart Pro license before installing this add-on.', 'fluent-cart-pro')
            );
        }

        $response = wp_remote_post($requestUrl, [
            'timeout'   => 30,
            'sslverify' => true,
            'body'      => [
                'item_id'         => absint($licenseConfig['parent_product_id']),
                'addon_slug'      => sanitize_text_field($addonSlug),
                'license_key'     => $licenseKey,
                'activation_hash' => $activationHash,
                'site_url'        => home_url(),
            ],
        ]);

        if (is_wp_error($response)) {
            return new \WP_Error('license_server_error', $response->get_error_message());
        }

        if (200 !== wp_remote_retrieve_response_code($response)) {
            return new \WP_Error(
                'license_server_error',
                __('License server returned an unexpected response.', 'fluent-cart-pro')
            );
        }

        $body = wp_remote_retrieve_body($response);
        $payload = json_decode($body, true);

        if (!is_array($payload)) {
            return new \WP_Error(
                'invalid_license_response',
                __('Could not parse add-on version response from the license server.', 'fluent-cart-pro')
            );
        }

        $downloadUrl = Arr::get($payload, 'package', Arr::get($payload, 'download_link', ''));
        $licenseStatus = Arr::get($payload, 'license_status', 'invalid');
        $errorMessage = sanitize_text_field(Arr::get($payload, 'license_message', ''));

        if ($licenseStatus !== 'valid') {
            return new \WP_Error(
                'license_invalid',
                $errorMessage ?: __('FluentCart Pro license is invalid for this add-on.', 'fluent-cart-pro')
            );
        }

        $downloadScheme = strtolower((string)wp_parse_url($downloadUrl, PHP_URL_SCHEME));
        if (empty($downloadUrl) || !wp_http_validate_url($downloadUrl) || $downloadScheme !== 'https') {
            return new \WP_Error(
                'missing_download_url',
                __('No valid secure download URL returned by the license server.', 'fluent-cart-pro')
            );
        }

        $downloadHost = strtolower((string)wp_parse_url($downloadUrl, PHP_URL_HOST));
        if (!$downloadHost || !in_array($downloadHost, $allowedHosts, true)) {
            return new \WP_Error(
                'invalid_download_host',
                __('Download URL host is not trusted.', 'fluent-cart-pro')
            );
        }

        return $downloadUrl;
    }

    private function isLicensedAddon($addonSlug)
    {
        $addon = $this->getRegisteredAddonBySlug($addonSlug);
        return (bool) Arr::get($addon, 'license_required.enabled', false);
    }

    private function getRegisteredAddonBySlug($addonSlug)
    {
        $addons = apply_filters('fluent_cart/module_settings/plugin_addons', []);
        $paymentAddons = apply_filters('fluent_cart/payment_addons', []);

        if (!is_array($addons)) {
            $addons = [];
        }
        if (!is_array($paymentAddons)) {
            $paymentAddons = [];
        }

        $allAddons = array_merge($addons, $paymentAddons);

        foreach ($allAddons as $addon) {
            if (Arr::get($addon, 'plugin_slug') === $addonSlug) {
                return $addon;
            }
        }

        return [];
    }

    private function getProLicenseSettingsKey()
    {
        if (defined('FLUENTCART_PRO_PLUGIN_FILE_PATH')) {
            $slug = dirname(plugin_basename(FLUENTCART_PRO_PLUGIN_FILE_PATH));
            if ($slug && $slug !== '.') {
                return '__' . sanitize_key($slug) . '_sl_info';
            }
        }

        return self::DEFAULT_PRO_LICENSE_SETTINGS_KEY;
    }

}
