<?php if (!defined('ABSPATH')) {
    die('You are not allowed to call this page directly.');
}
// phpcs:disable WordPress.Security.EscapeOutput.OutputNotEscaped -- all row and total values are escaped when built in the email classes.
?>
<table style="width:100%;border-collapse:collapse;margin:16px 0;" class="mepr-cart-receipt-items">
    <thead>
        <tr style="background:#f5f5f5;">
            <th style="text-align:left;padding:8px 12px;border-bottom:2px solid #ddd;"><?php echo esc_html_x('Product', 'email', 'memberpress'); ?></th>
            <th style="text-align:center;padding:8px 12px;border-bottom:2px solid #ddd;"><?php echo esc_html_x('Qty', 'email', 'memberpress'); ?></th>
            <th style="text-align:right;padding:8px 12px;border-bottom:2px solid #ddd;"><?php echo esc_html_x('Price', 'email', 'memberpress'); ?></th>
            <th style="text-align:right;padding:8px 12px;border-bottom:2px solid #ddd;"><?php echo esc_html_x('Total', 'email', 'memberpress'); ?></th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($rows as $row) : ?>
        <tr>
            <td style="padding:8px 12px;border-bottom:1px solid #eee;">
                <?php echo $row['name']; ?>
                <?php if (!empty($row['byline'])) : ?>
                    <br><small style="color:#6b7280;"><?php echo $row['byline']; ?></small>
                <?php endif; ?>
            </td>
            <td style="text-align:center;padding:8px 12px;border-bottom:1px solid #eee;"><?php echo $row['qty']; ?></td>
            <td style="text-align:right;padding:8px 12px;border-bottom:1px solid #eee;"><?php echo $row['unit_price']; ?></td>
            <td style="text-align:right;padding:8px 12px;border-bottom:1px solid #eee;"><?php echo $row['total']; ?></td>
        </tr>
        <?php endforeach; ?>
    </tbody>
    <tfoot>
        <?php if ($subtotal !== null) : ?>
        <tr>
            <td colspan="3" style="text-align:right;padding:6px 12px;"><?php echo esc_html_x('Subtotal', 'email', 'memberpress'); ?></td>
            <td style="text-align:right;padding:6px 12px;"><?php echo $subtotal; ?></td>
        </tr>
        <?php endif; ?>
        <?php if ($discount !== null) : ?>
        <tr>
            <td colspan="3" style="text-align:right;padding:6px 12px;color:#c0392b;"><?php echo esc_html($discount_label ?? _x('Discount', 'email', 'memberpress')); ?></td>
            <td style="text-align:right;padding:6px 12px;color:#c0392b;">-<?php echo $discount; ?></td>
        </tr>
        <?php endif; ?>
        <?php if (!empty($tax_rows)) : ?>
            <?php foreach ($tax_rows as $tax_row) : ?>
        <tr>
            <td colspan="3" style="text-align:right;padding:6px 12px;"><?php echo $tax_row['label']; ?></td>
            <td style="text-align:right;padding:6px 12px;"><?php echo $tax_row['amount']; ?></td>
        </tr>
            <?php endforeach; ?>
        <?php elseif (!empty($tax_fallback)) : ?>
        <tr>
            <td colspan="3" style="text-align:right;padding:6px 12px;"><?php echo esc_html_x('Tax', 'email', 'memberpress'); ?></td>
            <td style="text-align:right;padding:6px 12px;"><?php echo $tax_fallback; ?></td>
        </tr>
        <?php endif; ?>
        <?php if ($shipping !== null) : ?>
        <tr>
            <td colspan="3" style="text-align:right;padding:6px 12px;"><?php echo esc_html_x('Shipping', 'email', 'memberpress'); ?></td>
            <td style="text-align:right;padding:6px 12px;"><?php echo $shipping; ?></td>
        </tr>
        <?php endif; ?>
        <tr style="font-weight:bold;border-top:2px solid #ddd;">
            <td colspan="3" style="text-align:right;padding:8px 12px;"><?php echo esc_html_x('Total', 'email', 'memberpress'); ?></td>
            <td style="text-align:right;padding:8px 12px;"><?php echo $total; ?></td>
        </tr>
    </tfoot>
</table>
