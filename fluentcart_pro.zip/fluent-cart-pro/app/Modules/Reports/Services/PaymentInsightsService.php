<?php

namespace FluentCartPro\App\Modules\Reports\Services;

use FluentCart\App\Services\Report\PaymentMethodReportService;

/**
 * The Pro parts of Reports → Payment Methods: disputes by gateway and how customers paid (card brands and methods).
 */
class PaymentInsightsService extends PaymentMethodReportService
{
    private const DISPUTE_KEYS = ['gateway', 'label', 'orders', 'disputed_orders', 'dispute_rate', 'disputes_lost', 'dispute_amount'];

    public function getDisputes(array $params): array
    {
        $pick = function (array $row) {
            return array_intersect_key($row, array_flip(self::DISPUTE_KEYS));
        };
        $current = $this->gateways($params, false);
        $previous = !empty($params['comparePeriod'])
            ? $this->gateways(array_merge($params, ['startDate' => $params['comparePeriod'][0], 'endDate' => $params['comparePeriod'][1]]), false)['totals']
            : null;

        return [
            'rows'     => array_map($pick, $current['rows']),
            'totals'   => $pick($current['totals']),
            'previous' => $previous ? $pick($previous) : null,
        ];
    }

    public function getMethods(array $params): array
    {
        return $this->methods($params);
    }
}
