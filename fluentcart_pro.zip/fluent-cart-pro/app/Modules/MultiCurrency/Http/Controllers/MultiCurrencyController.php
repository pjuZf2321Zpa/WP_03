<?php

namespace FluentCartPro\App\Modules\MultiCurrency\Http\Controllers;

use FluentCart\App\Helpers\CurrenciesHelper;
use FluentCart\App\Http\Controllers\Controller;
use FluentCart\App\Models\Order;
use FluentCart\App\Modules\MultiCurrency\Services\BaseCurrency;
use FluentCart\App\Modules\MultiCurrency\Services\CurrencySnapshot;
use FluentCart\App\Modules\MultiCurrency\Services\MultiCurrencySettings;
use FluentCart\App\Modules\MultiCurrency\Services\RoundingRules;
use FluentCart\App\Services\Money;
use FluentCart\Framework\Http\Request\Request;
use FluentCartPro\App\Modules\MultiCurrency\Http\Requests\CurrencyRateRequest;
use FluentCartPro\App\Modules\MultiCurrency\Http\Requests\MultiCurrencySettingsRequest;
use FluentCartPro\App\Modules\MultiCurrency\RateStore;

/**
 * Admin endpoints for multi-currency settings and manual exchange rates.
 * fluent-cart dev-docs/multi-currency/08-exchange-rates.md.
 */
class MultiCurrencyController extends Controller
{
    public function getSettings(Request $request)
    {
        return $this->sendSuccess($this->settingsPayload());
    }

    public function saveSettings(MultiCurrencySettingsRequest $request)
    {
        $data = $request->getSafe($request->sanitize());
        $raw = $request->all();

        // Only overwrite what the request actually sent
        $input = MultiCurrencySettings::get();
        foreach (['enabled', 'currencies', 'rate_lock_minutes', 'rate_provider', 'rate_margin'] as $key) {
            if (array_key_exists($key, $raw)) {
                $input[$key] = $data[$key] ?? null;
            }
        }

        $saved = MultiCurrencySettings::save($input);

        if (is_wp_error($saved)) {
            return $this->sendError(['message' => $saved->get_error_message()], 422);
        }

        return $this->sendSuccess(array_merge($this->settingsPayload(), [
            'message' => __('Multi-currency settings saved.', 'fluent-cart-pro'),
        ]));
    }

    public function addRate(CurrencyRateRequest $request)
    {
        $data = $request->getSafe($request->sanitize());

        $row = RateStore::record($data['currency'], $data['rate']);

        if (is_wp_error($row)) {
            return $this->sendError(['message' => $row->get_error_message()], 422);
        }

        return $this->sendSuccess([
            'message' => __('Exchange rate saved.', 'fluent-cart-pro'),
            'rate'    => $this->formatRate($row),
        ]);
    }

    public function rateHistory(Request $request)
    {
        $currency = strtoupper(sanitize_text_field((string) $request->get('currency', '')));

        $rows = RateStore::history($currency, 20);
        $this->primeAuthors($rows);

        return $this->sendSuccess([
            'currency' => $currency,
            'rates'    => array_map([$this, 'formatRate'], $rows),
        ]);
    }

    private function settingsPayload(): array
    {
        $settings = MultiCurrencySettings::get();
        $base = BaseCurrency::get();

        $activeRows = RateStore::activeRows(array_column($settings['currencies'], 'code'));
        $this->primeAuthors(array_filter($activeRows));
        $rates = [];
        foreach ($settings['currencies'] as $row) {
            $active = $activeRows[strtoupper($row['code'])] ?? null;
            $rates[$row['code']] = $active ? $this->formatRate($active) : null;
        }

        $available = [];
        foreach (CurrenciesHelper::getCurrencies() as $code => $label) {
            if ($code === $base || Money::isThreeDecimal($code)) {
                continue;
            }
            $available[] = [
                'code'     => $code,
                'label'    => $label,
                'sign'     => CurrenciesHelper::getCurrencySign($code),
                'decimals' => Money::getDecimals($code),
            ];
        }

        return [
            'settings'             => $settings,
            'base_currency'        => $base,
            'base_currency_locked' => MultiCurrencySettings::isEnabled() && Order::query()->exists(),
            'available_currencies' => $available,
            'rounding_options'     => RoundingRules::options(),
            'charm_options'        => RoundingRules::charmOptions(),
            'rate_providers'       => MultiCurrencySettings::rateProviders(),
            'rate_provider_notes'  => MultiCurrencySettings::rateProviderNotes(),
            'rates'                => $rates,
        ];
    }

    /**
     * Load every rate author in one query so formatRate()'s get_userdata() reads the cache.
     *
     * @param \FluentCartPro\App\Modules\MultiCurrency\Models\CurrencyRate[] $rows
     */
    private function primeAuthors(array $rows): void
    {
        $userIds = array_values(array_unique(array_filter(array_map(function ($row) {
            return (int) $row->created_by;
        }, $rows))));

        if ($userIds) {
            cache_users($userIds);
        }
    }

    /**
     * @param \FluentCartPro\App\Modules\MultiCurrency\Models\CurrencyRate $row
     */
    private function formatRate($row): array
    {
        $user = $row->created_by ? get_userdata($row->created_by) : null;

        return [
            'id'           => (int) $row->id,
            'base'         => $row->base,
            'quote'        => $row->quote,
            'rate'         => (string) $row->rate,
            'source'       => $row->source,
            'effective_at' => (string) $row->effective_at,
            'created_by'   => $user ? $user->display_name : '',
            // Manual rates are the merchant's choice; only a feed can go stale
            'is_stale'     => $row->source !== CurrencySnapshot::SOURCE_MANUAL && RateStore::isStale($row, 72),
        ];
    }
}
