<?php

use FluentCart\Framework\Http\Router;
use FluentCartPro\App\Modules\MultiCurrency\Http\Controllers\MultiCurrencyController;

/**
 * @var Router $router
 */
$router->prefix('settings/multi-currency')
    ->withPolicy('FluentCart\App\Http\Policies\AdminPolicy')
    ->group(function (Router $router) {
        $router->get('/', [MultiCurrencyController::class, 'getSettings'])->meta(['permissions' => 'is_super_admin']);
        $router->post('/', [MultiCurrencyController::class, 'saveSettings'])->meta(['permissions' => 'is_super_admin']);
        $router->get('/rates', [MultiCurrencyController::class, 'rateHistory'])->meta(['permissions' => 'is_super_admin']);
        $router->post('/rates', [MultiCurrencyController::class, 'addRate'])->meta(['permissions' => 'is_super_admin']);
    });
