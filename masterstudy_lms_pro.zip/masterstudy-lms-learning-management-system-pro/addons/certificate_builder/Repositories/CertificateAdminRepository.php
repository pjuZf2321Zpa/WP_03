<?php

namespace MasterStudy\Lms\Pro\addons\certificate_builder\Repositories;

use MasterStudy\Lms\Plugin\PostType;
use RuntimeException;
use WP_Query;

final class CertificateAdminRepository {
	private const ERROR_BAD_REQUEST = 400;
	private const ERROR_FORBIDDEN   = 403;
	private const MAX_PER_PAGE      = 100;
	private const ALLOWED_STATUSES  = array( 'publish', 'pending', 'draft', 'private' );

	public function get_list( array $params ): array {
		$per_page = min( self::MAX_PER_PAGE, max( 1, (int) ( $params['per_page'] ?? 10 ) ) );
		$page     = max( 1, (int) ( $params['page'] ?? 1 ) );
		$search   = isset( $params['search'] ) ? trim( (string) $params['search'] ) : '';

		$query_args = array(
			'post_type'              => PostType::CERTIFICATE,
			'post_status'            => self::ALLOWED_STATUSES,
			'ignore_sticky_posts'    => true,
			'posts_per_page'         => $per_page,
			'paged'                  => $page,
			'no_found_rows'          => false,
			'update_post_meta_cache' => true,
			'update_post_term_cache' => false,
		);

		if ( '' !== $search ) {
			$query_args['s'] = $search;
		}

		if ( CertificateAdminAccess::can_manage_all() ) {
			$instructor = isset( $params['instructor'] ) ? absint( $params['instructor'] ) : 0;

			if ( $instructor > 0 ) {
				$query_args['author'] = $instructor;
			}
		} else {
			$query_args['author'] = get_current_user_id();
		}

		$sort = isset( $params['sort'] ) ? trim( (string) $params['sort'] ) : '';
		if ( '' !== $sort && class_exists( '\STM_LMS_Helpers' ) ) {
			$sort_params = \STM_LMS_Helpers::get_sort_params_by_string( $sort );
			$key         = $sort_params['key'] ?? '';
			$direction   = strtoupper( (string) ( $sort_params['direction'] ?? 'ASC' ) );
			$direction   = in_array( $direction, array( 'ASC', 'DESC' ), true ) ? $direction : 'ASC';

			switch ( $key ) {
				case 'instructor':
					$query_args['orderby'] = 'author';
					$query_args['order']   = $direction;
					break;
				case 'title':
				default:
					$query_args['orderby'] = 'title';
					$query_args['order']   = $direction;
					break;
			}
		} else {
			$query_args['orderby'] = 'title';
			$query_args['order']   = 'ASC';
		}

		$query = new WP_Query( $query_args );

		if ( function_exists( 'update_post_author_caches' ) ) {
			update_post_author_caches( $query->posts );
		}

		return array(
			'posts'              => $query->posts,
			'pages'              => (int) $query->max_num_pages,
			'current_page'       => $page,
			'total_certificates' => (int) $query->found_posts,
		);
	}

	public function bulk_delete( array $certificates ): void {
		foreach ( $certificates as $certificate ) {
			$certificate_id = $this->resolve_certificate_id( $certificate );

			if ( ! $certificate_id || PostType::CERTIFICATE !== get_post_type( $certificate_id ) ) {
				throw new RuntimeException(
					esc_html__( 'Invalid certificate provided for bulk delete.', 'masterstudy-lms-learning-management-system' ),
					self::ERROR_BAD_REQUEST
				);
			}

			if ( ! current_user_can( 'delete_post', $certificate_id ) ) {
				throw new RuntimeException(
					esc_html__( 'You do not have permission to delete this certificate.', 'masterstudy-lms-learning-management-system' ),
					self::ERROR_FORBIDDEN
				);
			}

			$result = wp_delete_post( $certificate_id, true );
			if ( false === $result || null === $result ) {
				throw new RuntimeException(
					sprintf(
						/* translators: %d: certificate ID. */
						esc_html__( 'Unable to delete certificate %d.', 'masterstudy-lms-learning-management-system' ),
						$certificate_id
					)
				);
			}
		}
	}

	/**
	 * @param mixed $certificate
	 */
	private function resolve_certificate_id( $certificate ): int {
		if ( is_numeric( $certificate ) ) {
			return (int) $certificate;
		}

		if ( is_array( $certificate ) && isset( $certificate['id'] ) ) {
			return (int) $certificate['id'];
		}

		return 0;
	}
}
