<?php
/**
 * Divi 5 module for the UseyourDrive plugin.
 */

namespace TheLion\Integrations\Divi\D5\Modules;

defined('ABSPATH') || exit;

final class UseyourDrive extends AbstractShortcodeModule
{
    protected const SLUG = 'useyourdrive';
    protected const D4_SHORTCODE = 'wpcp_useyourdrive';
}
