<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Core\Util\Route;
use BitApps\IntegrationsPro\Triggers\AvadaForms\AvadaFormsController;

Route::get('avada-forms/get', [AvadaFormsController::class, 'getAllTasks']);
