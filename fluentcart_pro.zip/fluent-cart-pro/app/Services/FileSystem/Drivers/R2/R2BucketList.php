<?php

namespace FluentCartPro\App\Services\FileSystem\Drivers\R2;

use FluentCart\Framework\Support\Arr;

class R2BucketList
{
    protected string $accessKey;

    protected string $secretKey;

    protected string $accountId;

    protected string $region = 'auto';

    protected string $hashAlgorithm = 'sha256';

    protected string $httpMethod = 'GET';

    protected string $signature;

    protected string $timeStamp;

    protected string $date;

    protected string $requestUrl;

    public static function get(string $accountId, string $secret, string $accessKey)
    {
        return (new static($accountId, $secret, $accessKey))->getList();
    }

    public function __construct(string $accountId, string $secret, string $accessKey)
    {
        $this->accountId = $accountId;
        $this->secretKey = $secret;
        $this->accessKey = $accessKey;
        $this->timeStamp = gmdate('Ymd\THis\Z');
        $this->date = substr($this->timeStamp, 0, 8);
        $this->requestUrl = 'https://' . $this->accountId . '.r2.cloudflarestorage.com';

        $this->generateSignature();
    }

    public function getList()
    {
        add_filter('http_request_timeout', [$this, 'extendHttpTimeout']);

        $response = wp_remote_request($this->requestUrl, [
            'method'  => $this->httpMethod,
            'headers' => $this->getHeaders(),
        ]);

        remove_filter('http_request_timeout', [$this, 'extendHttpTimeout']);

        if (is_wp_error($response)) {
            return $response;
        }

        if ((int) wp_remote_retrieve_response_code($response) !== 200) {
            return new \WP_Error(
                'invalid_r2_credentials',
                __('Invalid Cloudflare R2 credentials or account id.', 'fluent-cart-pro')
            );
        }

        return $this->parseResponseXml($response);
    }

    public function extendHttpTimeout(): int
    {
        return 30;
    }

    protected function parseResponseXml($response): array
    {
        $xml = simplexml_load_string(wp_remote_retrieve_body($response));
        $array = json_decode(json_encode($xml), true);

        $responseBucket = Arr::get($array, 'Buckets.Bucket', []);

        if (Arr::has($responseBucket, 'Name')) {
            return [Arr::get($responseBucket, 'Name')];
        }

        $buckets = [];
        foreach ($responseBucket as $bucket) {
            $name = Arr::get($bucket, 'Name');
            if ($name) {
                $buckets[] = $name;
            }
        }

        return $buckets;
    }

    protected function generateSignature(): void
    {
        $this->signature = $this->generateSignatureKey();
    }

    protected function createScope(): string
    {
        return $this->date . '/' . $this->region . '/s3/aws4_request';
    }

    protected function getContentHash(): string
    {
        return hash($this->hashAlgorithm, '');
    }

    protected function createCanonicalUrl(): string
    {
        return $this->httpMethod . "\n/\n\n"
            . 'host:' . $this->getHost() . "\n"
            . 'x-amz-content-sha256:' . $this->getContentHash() . "\n"
            . 'x-amz-date:' . $this->timeStamp . "\n\n"
            . "host;x-amz-content-sha256;x-amz-date\n"
            . $this->getContentHash();
    }

    protected function getHost(): string
    {
        return (string) parse_url($this->requestUrl, PHP_URL_HOST);
    }

    protected function createStringToSign(): string
    {
        $hash = hash($this->hashAlgorithm, $this->createCanonicalUrl());

        return 'AWS4-HMAC-SHA256' . "\n" . $this->timeStamp . "\n" . $this->createScope() . "\n" . $hash;
    }

    protected function getSigningKey()
    {
        $dateKey = hash_hmac($this->hashAlgorithm, $this->date, 'AWS4' . $this->secretKey, true);
        $regionKey = hash_hmac($this->hashAlgorithm, $this->region, $dateKey, true);
        $serviceKey = hash_hmac($this->hashAlgorithm, 's3', $regionKey, true);

        return hash_hmac($this->hashAlgorithm, 'aws4_request', $serviceKey, true);
    }

    protected function generateSignatureKey(): string
    {
        return hash_hmac($this->hashAlgorithm, $this->createStringToSign(), $this->getSigningKey());
    }

    protected function getHeaders(): array
    {
        $signedHeaders = 'host;x-amz-content-sha256;x-amz-date';

        return [
            'x-amz-content-sha256' => $this->getContentHash(),
            'x-amz-date'           => $this->timeStamp,
            'Authorization'        => 'AWS4-HMAC-SHA256 Credential=' . $this->accessKey . '/' . $this->date . '/' . $this->region . '/s3/aws4_request, SignedHeaders=' . $signedHeaders . ', Signature=' . $this->signature,
        ];
    }
}
