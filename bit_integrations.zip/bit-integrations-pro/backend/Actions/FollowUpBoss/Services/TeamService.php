<?php

namespace BitApps\IntegrationsPro\Actions\FollowUpBoss\Services;

final class TeamService extends BaseService
{
    public function createTeam(): array
    {
        $validationRules = [
            'name'     => ['required'],
            'user_ids' => ['required'],
        ];
        $error = $this->validateFields(
            $validationRules,
            [
                'name'     => __('Team Name', 'bit-integrations-pro'),
                'user_ids' => __('Members', 'bit-integrations-pro'),
            ],
            ['user_ids']
        );

        if ($error !== null) {
            return $error;
        }

        $payload = $this->removeEmptyValues(
            [
                'name'      => $this->getString('name'),
                'userIds'   => $this->getIntegerList('user_ids'),
                'leaderIds' => $this->getIntegerList('leader_ids'),
            ]
        );

        return $this->dispatch('POST', '/teams', $payload);
    }

    public function updateTeam(): array
    {
        $validationRules = ['team_id' => ['required', 'integer']];
        $error = $this->validateFields(
            $validationRules,
            [
                'team_id' => __('Team ID', 'bit-integrations-pro'),
            ]
        );

        if ($error !== null) {
            return $error;
        }

        $payload = $this->removeEmptyValues(
            [
                'name'      => $this->getString('name'),
                'userIds'   => $this->getIntegerList('user_ids'),
                'leaderIds' => $this->getIntegerList('leader_ids'),
            ]
        );

        return $this->dispatch('PUT', '/teams/' . rawurlencode($this->getString('team_id')), $payload);
    }

    public function deleteTeam(): array
    {
        $validationRules = ['team_id' => ['required', 'integer']];
        $error = $this->validateFields(
            $validationRules,
            [
                'team_id' => __('Team ID', 'bit-integrations-pro'),
            ]
        );

        if ($error !== null) {
            return $error;
        }

        $query = $this->removeEmptyValues(
            [
                'moveToTeamId' => $this->getInteger('move_to_team_id'),
            ]
        );

        return $this->dispatch('DELETE', '/teams/' . rawurlencode($this->getString('team_id')), null, $query);
    }
}
