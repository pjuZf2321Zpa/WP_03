<?php

namespace WPAICG\Lib\Integrations\Recipes\Contracts;

use WP_Error;

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

interface AIPKit_Recipe_Registry_Interface
{
    /**
     * Registers a recipe template definition.
     *
     * @param array<string, mixed> $template
     * @return bool|WP_Error
     */
    public function register_template(array $template);

    /**
     * Returns one template by slug or null if missing.
     *
     * @param string $template_slug
     * @return array<string, mixed>|null
     */
    public function get_template(string $template_slug): ?array;

    /**
     * Returns whether a template exists.
     *
     * @param string $template_slug
     * @return bool
     */
    public function has_template(string $template_slug): bool;

    /**
     * Returns templates, optionally filtered by properties like event_name or app_slug.
     *
     * @param array<string, mixed> $filters
     * @return array<int, array<string, mixed>>
     */
    public function get_templates(array $filters = []): array;
}

interface AIPKit_Recipe_Executor_Interface
{
    /**
     * Returns whether this executor can attempt the given recipe for the emitted event.
     *
     * @param array<string, mixed> $recipe
     * @param array<string, mixed> $event_envelope
     * @return bool|WP_Error
     */
    public function can_execute(array $recipe, array $event_envelope);

    /**
     * Executes one premium app recipe.
     *
     * @param array<string, mixed> $recipe
     * @param array<string, mixed> $event_envelope
     * @param array<string, mixed> $context
     * @return array<string, mixed>|WP_Error
     */
    public function execute(array $recipe, array $event_envelope, array $context = []);
}
