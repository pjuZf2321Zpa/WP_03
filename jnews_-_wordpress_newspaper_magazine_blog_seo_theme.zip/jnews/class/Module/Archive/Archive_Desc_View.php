<?php
/**
 * @author : Jegtheme
 */

namespace JNews\Module\Archive;

Class Archive_Desc_View extends ArchiveViewAbstract {
	public function render_module_back( $attr, $column_class ) {
		$style = $this->generate_style( $attr );
		$tag   = $this->get_html_tag( $attr );

		return
			"<div {$this->element_id($attr)} class='jeg_archive_description_wrapper {$this->unique_id} {$this->get_vc_class_name()} {$attr['scheme']} {$attr['el_class']}'>
				{$style}
                <{$tag} class=\"jeg_archive_description\">Archive description goes here, it will change into related archive description on frontend website.</{$tag}>
            </div>";
	}

	public function render_module_front( $attr, $column_class ) {
		$term  = $this->get_term();
		$desc  = isset( $term->description ) ? $term->description : '';
		$style = $this->generate_style( $attr );
		$tag   = $this->get_html_tag( $attr );

		return
			"<div {$this->element_id($attr)} class='jeg_archive_description_wrapper {$this->unique_id} {$this->get_vc_class_name()} {$attr['scheme']} {$attr['el_class']}'>
				{$style}
                <{$tag} class=\"jeg_archive_description\">{$desc}</{$tag}>
            </div>";
	}

	public function get_html_tag( $attr ) {
		$tag          = isset( $attr['html_tag'] ) ? $attr['html_tag'] : 'h2';
		$allowed_tags = array( 'h2', 'h3', 'h4', 'h5', 'h6', 'p', 'div' );

		return in_array( $tag, $allowed_tags, true ) ? $tag : 'h2';
	}

	public function generate_style( $attr ) {

		$result = '';

		if ( isset( $attr['text_color'] ) && $attr['text_color'] ) {
			$result .= 'color: ' . $attr['text_color'] . ';';
		}

		if ( isset( $attr['font_size'] ) && $attr['font_size'] ) {
			$result .= 'font-size: ' . $attr['font_size'] . ';';
		}

		if ( $result ) {
			$result = '<style>' . $this->element_id( $attr ) . ' .jeg_archive_description {' . $result . '}' . '</style>';
		}

		return $result;
	}
}
