<?php

namespace BitApps\IntegrationsPro\Actions\SenseiLMS;

use Sensei_Course_Manual_Enrolment_Provider;
use Sensei_Utils;
use Woothemes_Sensei_Certificate_Data_Store;

final class SenseiLMSProHelper
{
    private const LESSON_STATUSES = ['in-progress', 'ungraded', 'graded', 'passed', 'failed'];

    private const POST_STATUSES = ['publish', 'draft', 'pending', 'private'];

    public static function enrollUserInCourse($defaultResponse, $fieldData, $integrationDetails)
    {
        return self::handleEnrolment('enrol_learner', __('User enrolled in course successfully', 'bit-integrations-pro'), $fieldData, $integrationDetails);
    }

    public static function withdrawUserFromCourse($defaultResponse, $fieldData, $integrationDetails)
    {
        return self::handleEnrolment('withdraw_learner', __('User withdrawn from course successfully', 'bit-integrations-pro'), $fieldData, $integrationDetails);
    }

    public static function startCourseForUser($defaultResponse, $fieldData, $integrationDetails)
    {
        $error = self::ensureActive('Sensei_Utils');
        if ($error) {
            return $error;
        }

        $courseId = self::selectedId($integrationDetails, 'selectedCourse');
        $user = self::findUser($fieldData);

        if (!$courseId) {
            return self::error(__('Please select a course', 'bit-integrations-pro'));
        }

        if (!$user) {
            return self::error(__('User not found with the provided email', 'bit-integrations-pro'));
        }

        Sensei_Utils::user_start_course($user->ID, $courseId);

        return self::success(__('Course started for user successfully', 'bit-integrations-pro'));
    }

    public static function completeCourseForUser($defaultResponse, $fieldData, $integrationDetails)
    {
        $error = self::ensureActive('Sensei_Utils');
        if ($error) {
            return $error;
        }

        $courseId = self::selectedId($integrationDetails, 'selectedCourse');
        $user = self::findUser($fieldData);

        if (!$courseId) {
            return self::error(__('Please select a course', 'bit-integrations-pro'));
        }

        if (!$user) {
            return self::error(__('User not found with the provided email', 'bit-integrations-pro'));
        }

        Sensei_Utils::user_start_course($user->ID, $courseId);
        Sensei_Utils::user_complete_course($courseId, $user->ID, true);

        // user_complete_course() returns the progress comment id (always truthy), and only
        // marks the course complete once every lesson is done — so verify the real status.
        if (!Sensei_Utils::user_completed_course($courseId, $user->ID)) {
            return self::error(__('Course could not be marked complete. The learner still has lessons to finish.', 'bit-integrations-pro'));
        }

        return self::success(__('Course marked as complete successfully', 'bit-integrations-pro'));
    }

    public static function resetCourseForUser($defaultResponse, $fieldData, $integrationDetails)
    {
        $error = self::ensureActive('Sensei_Utils');
        if ($error) {
            return $error;
        }

        $courseId = self::selectedId($integrationDetails, 'selectedCourse');
        $user = self::findUser($fieldData);

        if (!$courseId) {
            return self::error(__('Please select a course', 'bit-integrations-pro'));
        }

        if (!$user) {
            return self::error(__('User not found with the provided email', 'bit-integrations-pro'));
        }

        Sensei_Utils::sensei_remove_user_from_course($courseId, $user->ID);

        return self::success(__('Course progress reset successfully', 'bit-integrations-pro'));
    }

    public static function startLessonForUser($defaultResponse, $fieldData, $integrationDetails)
    {
        $error = self::ensureActive('Sensei_Utils');
        if ($error) {
            return $error;
        }

        $lessonId = self::selectedId($integrationDetails, 'selectedLesson');
        $user = self::findUser($fieldData);

        if (!$lessonId) {
            return self::error(__('Please select a lesson', 'bit-integrations-pro'));
        }

        if (!$user) {
            return self::error(__('User not found with the provided email', 'bit-integrations-pro'));
        }

        $markComplete = (isset($integrationDetails->selectedMarkComplete) && $integrationDetails->selectedMarkComplete === 'yes');

        Sensei_Utils::user_start_lesson($user->ID, $lessonId, $markComplete);

        return self::success(__('Lesson started for user successfully', 'bit-integrations-pro'));
    }

    public static function updateLessonStatus($defaultResponse, $fieldData, $integrationDetails)
    {
        $error = self::ensureActive('Sensei_Utils');
        if ($error) {
            return $error;
        }

        $lessonId = self::selectedId($integrationDetails, 'selectedLesson');
        $user = self::findUser($fieldData);
        $status = $integrationDetails->selectedLessonStatus ?? '';

        if (!$lessonId) {
            return self::error(__('Please select a lesson', 'bit-integrations-pro'));
        }

        if (!$user) {
            return self::error(__('User not found with the provided email', 'bit-integrations-pro'));
        }

        if (!\in_array($status, self::LESSON_STATUSES, true)) {
            return self::error(__('Invalid lesson status provided', 'bit-integrations-pro'));
        }

        $updated = Sensei_Utils::update_lesson_status($user->ID, $lessonId, $status, []);

        if (!$updated) {
            return self::error(__('Failed to update the lesson status', 'bit-integrations-pro'));
        }

        return self::success(__('Lesson status updated successfully', 'bit-integrations-pro'));
    }

    public static function resetLessonForUser($defaultResponse, $fieldData, $integrationDetails)
    {
        $error = self::ensureActive('Sensei_Utils');
        if ($error) {
            return $error;
        }

        $lessonId = self::selectedId($integrationDetails, 'selectedLesson');
        $user = self::findUser($fieldData);

        if (!$lessonId) {
            return self::error(__('Please select a lesson', 'bit-integrations-pro'));
        }

        if (!$user) {
            return self::error(__('User not found with the provided email', 'bit-integrations-pro'));
        }

        Sensei_Utils::sensei_remove_user_from_lesson($lessonId, $user->ID);

        return self::success(__('Lesson progress reset successfully', 'bit-integrations-pro'));
    }

    public static function gradeQuiz($defaultResponse, $fieldData, $integrationDetails)
    {
        $error = self::ensureActive('Sensei_Utils');
        if ($error) {
            return $error;
        }

        $quizId = self::selectedId($integrationDetails, 'selectedQuiz');
        $user = self::findUser($fieldData);

        if (!$quizId) {
            return self::error(__('Please select a quiz', 'bit-integrations-pro'));
        }

        if (!$user) {
            return self::error(__('User not found with the provided email', 'bit-integrations-pro'));
        }

        if (!isset($fieldData['grade']) || !is_numeric($fieldData['grade'])) {
            return self::error(__('A numeric grade is required', 'bit-integrations-pro'));
        }

        $grade = (float) $fieldData['grade'];
        $gradeType = !empty($integrationDetails->selectedGradeType) ? $integrationDetails->selectedGradeType : 'auto';

        $graded = Sensei_Utils::sensei_grade_quiz($quizId, $grade, $user->ID, $gradeType);

        if (!$graded) {
            return self::error(__('Failed to grade the quiz. The learner may not have submitted this quiz yet.', 'bit-integrations-pro'));
        }

        return self::success(__('Quiz graded successfully', 'bit-integrations-pro'));
    }

    public static function createCourse($defaultResponse, $fieldData, $integrationDetails)
    {
        $error = self::ensureActive();
        if ($error) {
            return $error;
        }

        if (empty($fieldData['post_title'])) {
            return self::error(__('Course title is required', 'bit-integrations-pro'));
        }

        $postId = wp_insert_post(self::buildPostArgs('course', $fieldData, $integrationDetails), true);

        if (is_wp_error($postId)) {
            return self::error($postId->get_error_message());
        }

        return self::success(__('Course created successfully', 'bit-integrations-pro'), ['course_id' => $postId]);
    }

    public static function createLesson($defaultResponse, $fieldData, $integrationDetails)
    {
        $error = self::ensureActive();
        if ($error) {
            return $error;
        }

        if (empty($fieldData['post_title'])) {
            return self::error(__('Lesson title is required', 'bit-integrations-pro'));
        }

        $courseId = self::selectedId($integrationDetails, 'selectedCourse');

        if (!$courseId) {
            return self::error(__('Please select a course for the lesson', 'bit-integrations-pro'));
        }

        $postId = wp_insert_post(self::buildPostArgs('lesson', $fieldData, $integrationDetails), true);

        if (is_wp_error($postId)) {
            return self::error($postId->get_error_message());
        }

        update_post_meta($postId, '_lesson_course', $courseId);

        return self::success(__('Lesson created successfully', 'bit-integrations-pro'), ['lesson_id' => $postId, 'course_id' => $courseId]);
    }

    public static function createCertificate($defaultResponse, $fieldData, $integrationDetails)
    {
        $error = self::ensureActive();
        if ($error) {
            return $error;
        }

        if (!class_exists('Woothemes_Sensei_Certificate_Data_Store')) {
            return self::error(__('Sensei LMS Certificates addon is not active', 'bit-integrations-pro'));
        }

        $courseId = self::selectedId($integrationDetails, 'selectedCourse');
        $user = self::findUser($fieldData);

        if (!$courseId) {
            return self::error(__('Please select a course', 'bit-integrations-pro'));
        }

        if (!$user) {
            return self::error(__('User not found with the provided email', 'bit-integrations-pro'));
        }

        $store = new Woothemes_Sensei_Certificate_Data_Store();
        $certificateId = $store->insert($user->ID, $courseId);

        if (is_wp_error($certificateId)) {
            $message = $certificateId->get_error_message();

            return self::error($message !== '' ? $message : __('A certificate already exists for this user and course', 'bit-integrations-pro'));
        }

        // insert() calls wp_insert_post(..., $wp_error = false), so a non-duplicate failure returns 0 (not a WP_Error).
        if (empty($certificateId)) {
            return self::error(__('Failed to create the certificate', 'bit-integrations-pro'));
        }

        return self::success(__('Certificate created successfully', 'bit-integrations-pro'), ['certificate_id' => $certificateId]);
    }

    private static function handleEnrolment($method, $successMessage, $fieldData, $integrationDetails)
    {
        $error = self::ensureActive('Sensei_Course_Manual_Enrolment_Provider');
        if ($error) {
            return $error;
        }

        $courseId = self::selectedId($integrationDetails, 'selectedCourse');
        $user = self::findUser($fieldData);

        if (!$courseId) {
            return self::error(__('Please select a course', 'bit-integrations-pro'));
        }

        if (!$user) {
            return self::error(__('User not found with the provided email', 'bit-integrations-pro'));
        }

        $result = Sensei_Course_Manual_Enrolment_Provider::instance()->{$method}($user->ID, $courseId);

        if (!$result) {
            return self::error(__('Failed to update the course enrolment', 'bit-integrations-pro'));
        }

        return self::success($successMessage);
    }

    private static function buildPostArgs($postType, $fieldData, $integrationDetails)
    {
        $postStatus = !empty($integrationDetails->selectedStatus) ? $integrationDetails->selectedStatus : 'publish';

        if (!\in_array($postStatus, self::POST_STATUSES, true)) {
            $postStatus = 'publish';
        }

        $args = [
            'post_type'    => $postType,
            'post_status'  => $postStatus,
            'post_title'   => sanitize_text_field($fieldData['post_title']),
            'post_content' => isset($fieldData['post_content']) ? wp_kses_post($fieldData['post_content']) : '',
            'post_excerpt' => isset($fieldData['post_excerpt']) ? sanitize_textarea_field($fieldData['post_excerpt']) : '',
        ];

        if (!empty($fieldData['author_email'])) {
            $author = get_user_by('email', $fieldData['author_email']);

            if ($author) {
                $args['post_author'] = $author->ID;
            }
        }

        return $args;
    }

    private static function selectedId($integrationDetails, $key)
    {
        $value = isset($integrationDetails->{$key}) ? $integrationDetails->{$key} : '';

        if (empty($value) || $value === 'any') {
            return 0;
        }

        return (int) $value;
    }

    private static function findUser($fieldData)
    {
        if (empty($fieldData['user_email'])) {
            return false;
        }

        return get_user_by('email', $fieldData['user_email']);
    }

    private static function isActive()
    {
        return class_exists('Sensei_Main');
    }

    /**
     * Verify Sensei LMS is active and that every required class exists.
     *
     * @param string ...$classes Sensei class names the caller depends on
     *
     * @return null|array error envelope when something is missing, null otherwise
     */
    private static function ensureActive(...$classes)
    {
        if (!self::isActive()) {
            return self::error(__('Sensei LMS is not installed or activated', 'bit-integrations-pro'));
        }

        foreach ($classes as $class) {
            if (!class_exists($class)) {
                // translators: %s is the missing class name.
                return self::error(\sprintf(__('Required Sensei class %s is missing.', 'bit-integrations-pro'), $class));
            }
        }

        return null;
    }

    private static function success($message, $data = [])
    {
        return ['success' => true, 'message' => $message, 'data' => $data];
    }

    private static function error($message)
    {
        return ['success' => false, 'message' => $message];
    }
}
