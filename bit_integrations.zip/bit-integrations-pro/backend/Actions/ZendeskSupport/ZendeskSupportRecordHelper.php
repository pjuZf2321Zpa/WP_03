<?php

/**
 * Zendesk Support Record Api (Pro)
 */

namespace BitApps\IntegrationsPro\Actions\ZendeskSupport;

use BitApps\IntegrationsPro\Core\Util\HttpHelper;

/**
 * Handles all Zendesk Support write actions on the Pro side.
 *
 * Each action is registered on its own hook (see Hooks.php) and receives
 * ($response, $fieldData, $utilities, $integrationDetails).
 */
final class ZendeskSupportRecordHelper
{
    public static function createTicket($response, $data, $utilities, $integrationDetails)
    {
        [$baseUrl, $headers, $data, $error] = self::boot($integrationDetails, $data, $utilities, ['subject', 'description']);
        if ($error) {
            return $error;
        }

        $payload = wp_json_encode(['ticket' => self::buildTicketPayload($data)]);

        return self::dispatch($baseUrl . '/tickets.json', 'POST', $payload, $headers, 'ticket');
    }

    public static function updateTicket($response, $data, $utilities, $integrationDetails)
    {
        [$baseUrl, $headers, $data, $error] = self::boot($integrationDetails, $data, $utilities, ['ticketId']);
        if ($error) {
            return $error;
        }

        $ticket = self::buildTicketPayload($data, true);

        if (!empty($data['commentBody'])) {
            $ticket['comment'] = ['body' => $data['commentBody']];
        }

        if (empty($ticket)) {
            return self::nothingToUpdate();
        }

        $payload = wp_json_encode(['ticket' => $ticket]);

        return self::dispatch($baseUrl . '/tickets/' . rawurlencode($data['ticketId']) . '.json', 'PUT', $payload, $headers, 'ticket');
    }

    public static function deleteTicket($response, $data, $utilities, $integrationDetails)
    {
        [$baseUrl, $headers, $data, $error] = self::boot($integrationDetails, $data, $utilities, ['ticketId']);
        if ($error) {
            return $error;
        }

        return self::dispatch($baseUrl . '/tickets/' . rawurlencode($data['ticketId']) . '.json', 'DELETE', '', $headers);
    }

    public static function addTicketComment($response, $data, $utilities, $integrationDetails)
    {
        [$baseUrl, $headers, $data, $error] = self::boot($integrationDetails, $data, $utilities, ['ticketId', 'commentBody']);
        if ($error) {
            return $error;
        }

        $comment = [
            'body'   => $data['commentBody'],
            'public' => ($data['visibility'] ?? 'public') === 'public',
        ];

        if (!empty($data['authorId'])) {
            $comment['author_id'] = $data['authorId'];
        }

        $payload = wp_json_encode(['ticket' => ['comment' => $comment]]);

        return self::dispatch($baseUrl . '/tickets/' . rawurlencode($data['ticketId']) . '.json', 'PUT', $payload, $headers, 'ticket');
    }

    public static function addTagsToTicket($response, $data, $utilities, $integrationDetails)
    {
        return self::ticketTags('POST', $integrationDetails, $data, $utilities);
    }

    public static function removeTagsFromTicket($response, $data, $utilities, $integrationDetails)
    {
        return self::ticketTags('DELETE', $integrationDetails, $data, $utilities);
    }

    public static function createUser($response, $data, $utilities, $integrationDetails)
    {
        [$baseUrl, $headers, $data, $error] = self::boot($integrationDetails, $data, $utilities, ['name', 'email']);
        if ($error) {
            return $error;
        }

        $payload = wp_json_encode(['user' => self::buildUserPayload($data)]);

        return self::dispatch($baseUrl . '/users.json', 'POST', $payload, $headers, 'user');
    }

    public static function updateUser($response, $data, $utilities, $integrationDetails)
    {
        [$baseUrl, $headers, $data, $error] = self::boot($integrationDetails, $data, $utilities, ['userId']);
        if ($error) {
            return $error;
        }

        $user = self::buildUserPayload($data);

        if (empty($user)) {
            return self::nothingToUpdate();
        }

        $payload = wp_json_encode(['user' => $user]);

        return self::dispatch($baseUrl . '/users/' . rawurlencode($data['userId']) . '.json', 'PUT', $payload, $headers, 'user');
    }

    public static function createOrUpdateUser($response, $data, $utilities, $integrationDetails)
    {
        [$baseUrl, $headers, $data, $error] = self::boot($integrationDetails, $data, $utilities, ['name', 'email']);
        if ($error) {
            return $error;
        }

        $payload = wp_json_encode(['user' => self::buildUserPayload($data)]);

        return self::dispatch($baseUrl . '/users/create_or_update.json', 'POST', $payload, $headers, 'user');
    }

    public static function deleteUser($response, $data, $utilities, $integrationDetails)
    {
        [$baseUrl, $headers, $data, $error] = self::boot($integrationDetails, $data, $utilities, ['userId']);
        if ($error) {
            return $error;
        }

        return self::dispatch($baseUrl . '/users/' . rawurlencode($data['userId']) . '.json', 'DELETE', '', $headers);
    }

    public static function suspendUser($response, $data, $utilities, $integrationDetails)
    {
        [$baseUrl, $headers, $data, $error] = self::boot($integrationDetails, $data, $utilities, ['userId']);
        if ($error) {
            return $error;
        }

        $payload = wp_json_encode(['user' => ['suspended' => true]]);

        return self::dispatch($baseUrl . '/users/' . rawurlencode($data['userId']) . '.json', 'PUT', $payload, $headers, 'user');
    }

    public static function createOrganization($response, $data, $utilities, $integrationDetails)
    {
        [$baseUrl, $headers, $data, $error] = self::boot($integrationDetails, $data, $utilities, ['name']);
        if ($error) {
            return $error;
        }

        $payload = wp_json_encode(['organization' => self::buildOrganizationPayload($data)]);

        return self::dispatch($baseUrl . '/organizations.json', 'POST', $payload, $headers, 'organization');
    }

    public static function updateOrganization($response, $data, $utilities, $integrationDetails)
    {
        [$baseUrl, $headers, $data, $error] = self::boot($integrationDetails, $data, $utilities, ['organizationId']);
        if ($error) {
            return $error;
        }

        $organization = self::buildOrganizationPayload($data);

        if (empty($organization)) {
            return self::nothingToUpdate();
        }

        $payload = wp_json_encode(['organization' => $organization]);

        return self::dispatch($baseUrl . '/organizations/' . rawurlencode($data['organizationId']) . '.json', 'PUT', $payload, $headers, 'organization');
    }

    public static function deleteOrganization($response, $data, $utilities, $integrationDetails)
    {
        [$baseUrl, $headers, $data, $error] = self::boot($integrationDetails, $data, $utilities, ['organizationId']);
        if ($error) {
            return $error;
        }

        return self::dispatch($baseUrl . '/organizations/' . rawurlencode($data['organizationId']) . '.json', 'DELETE', '', $headers);
    }

    public static function createGroup($response, $data, $utilities, $integrationDetails)
    {
        [$baseUrl, $headers, $data, $error] = self::boot($integrationDetails, $data, $utilities, ['name']);
        if ($error) {
            return $error;
        }

        $group = self::filterEmpty([
            'name'        => $data['name'] ?? null,
            'description' => $data['description'] ?? null,
            'default'     => isset($data['isDefault']) ? ($data['isDefault'] === 'true' || $data['isDefault'] === true) : null,
        ]);

        $payload = wp_json_encode(['group' => $group]);

        return self::dispatch($baseUrl . '/groups.json', 'POST', $payload, $headers, 'group');
    }

    public static function updateGroup($response, $data, $utilities, $integrationDetails)
    {
        [$baseUrl, $headers, $data, $error] = self::boot($integrationDetails, $data, $utilities, ['groupId']);
        if ($error) {
            return $error;
        }

        $group = self::filterEmpty([
            'name'        => $data['name'] ?? null,
            'description' => $data['description'] ?? null,
        ]);

        if (empty($group)) {
            return self::nothingToUpdate();
        }

        $payload = wp_json_encode(['group' => $group]);

        return self::dispatch($baseUrl . '/groups/' . rawurlencode($data['groupId']) . '.json', 'PUT', $payload, $headers, 'group');
    }

    public static function deleteGroup($response, $data, $utilities, $integrationDetails)
    {
        [$baseUrl, $headers, $data, $error] = self::boot($integrationDetails, $data, $utilities, ['groupId']);
        if ($error) {
            return $error;
        }

        return self::dispatch($baseUrl . '/groups/' . rawurlencode($data['groupId']) . '.json', 'DELETE', '', $headers);
    }

    /**
     * Shared bootstrap for every action: builds the auth client, merges utility
     * values into the field data, and validates required fields.
     *
     * @param mixed    $integrationDetails
     * @param mixed    $utilities
     * @param string[] $required
     * @param mixed    $data
     *
     * @return array{0:?string,1:?array,2:?array,3:?array} [baseUrl, headers, data, error]
     */
    private static function boot($integrationDetails, $data, $utilities, array $required = []): array
    {
        [$baseUrl, $headers, $error] = self::client($integrationDetails);
        if ($error) {
            return [null, null, null, $error];
        }

        $data = self::withUtilities($data, $utilities);

        $missing = [];
        foreach ($required as $field) {
            if (empty($data[$field])) {
                $missing[] = $field;
            }
        }

        if (!empty($missing)) {
            return [null, null, null, self::requiredError($missing)];
        }

        return [$baseUrl, $headers, $data, null];
    }

    /**
     * Adds or removes tags on a ticket (POST = add, DELETE = remove).
     *
     * @param mixed $integrationDetails
     * @param mixed $utilities
     * @param mixed $data
     */
    private static function ticketTags(string $method, $integrationDetails, $data, $utilities)
    {
        [$baseUrl, $headers, $data, $error] = self::boot($integrationDetails, $data, $utilities, ['ticketId', 'tags']);
        if ($error) {
            return $error;
        }

        $payload = wp_json_encode(['tags' => self::stringToArray($data['tags'])]);

        return self::dispatch($baseUrl . '/tickets/' . rawurlencode($data['ticketId']) . '/tags.json', $method, $payload, $headers, 'tags');
    }

    /**
     * Merges the selected utility dropdown values (priority, status, group_id,
     * etc.) into the mapped field data. Field-map values take precedence.
     *
     * @param mixed $utilities
     */
    private static function withUtilities(array $data, $utilities): array
    {
        $utilities = array_filter((array) $utilities, static function ($value) {
            return $value !== '' && $value !== null && $value !== [];
        });

        return array_merge($utilities, $data);
    }

    private static function client($integrationDetails): array
    {
        $subdomain = $integrationDetails->subdomain ?? '';
        $email = $integrationDetails->email ?? '';
        $apiToken = $integrationDetails->apiToken ?? '';

        if (empty($subdomain) || empty($email) || empty($apiToken)) {
            return [null, null, ['success' => false, 'message' => __('Missing Zendesk subdomain, email, or API token', 'bit-integrations-pro'), 'code' => 401]];
        }

        $baseUrl = 'https://' . $subdomain . '.zendesk.com/api/v2';
        $headers = [
            'Content-Type'  => 'application/json',
            'Accept'        => 'application/json',
            'Authorization' => 'Basic ' . base64_encode($email . '/token:' . $apiToken),
        ];

        return [$baseUrl, $headers, null];
    }

    private static function buildTicketPayload(array $data, bool $forUpdate = false): array
    {
        $ticket = self::filterEmpty([
            'subject'        => $data['subject'] ?? null,
            'priority'       => $data['priority'] ?? null,
            'status'         => $data['status'] ?? null,
            'type'           => $data['type'] ?? null,
            'group_id'       => $data['groupId'] ?? null,
            'assignee_id'    => $data['assigneeId'] ?? null,
            'brand_id'       => $data['brandId'] ?? null,
            'ticket_form_id' => $data['ticketFormId'] ?? null,
            'external_id'    => $data['externalId'] ?? null,
            'tags'           => self::stringToArray($data['tags'] ?? null),
        ]);

        if ($forUpdate) {
            return $ticket;
        }

        if (!empty($data['description'])) {
            $ticket['comment'] = ['body' => $data['description']];
        }
        if (!empty($data['requesterEmail'])) {
            $ticket['requester']['email'] = $data['requesterEmail'];
        }
        if (!empty($data['requesterName'])) {
            $ticket['requester']['name'] = $data['requesterName'];
        }

        return $ticket;
    }

    private static function buildUserPayload(array $data): array
    {
        return self::filterEmpty([
            'name'            => $data['name'] ?? null,
            'email'           => $data['email'] ?? null,
            'phone'           => $data['phone'] ?? null,
            'role'            => $data['role'] ?? null,
            'organization_id' => $data['organizationId'] ?? null,
            'external_id'     => $data['externalId'] ?? null,
            'tags'            => self::stringToArray($data['tags'] ?? null),
        ]);
    }

    private static function buildOrganizationPayload(array $data): array
    {
        return self::filterEmpty([
            'name'         => $data['name'] ?? null,
            'details'      => $data['details'] ?? null,
            'notes'        => $data['notes'] ?? null,
            'external_id'  => $data['externalId'] ?? null,
            'domain_names' => self::stringToArray($data['domainNames'] ?? null),
            'tags'         => self::stringToArray($data['tags'] ?? null),
        ]);
    }

    private static function dispatch($url, $method, $payload, $headers, $successKey = null)
    {
        $response = HttpHelper::request($url, $method, $payload, $headers);

        if (is_wp_error($response)) {
            return ['success' => false, 'message' => $response->get_error_message(), 'code' => 500];
        }

        // HttpHelper returns the raw body string when it isn't valid JSON. A non-empty
        // string means an HTML/plain error page (5xx, gateway, maintenance), not success —
        // important for DELETE, whose success branch otherwise ignores the body entirely.
        if (\is_string($response) && trim($response) !== '') {
            return ['success' => false, 'message' => __('Unexpected Zendesk response', 'bit-integrations-pro'), 'response' => $response, 'code' => 400];
        }

        if (\is_object($response) && (isset($response->error) || isset($response->details))) {
            $message = \is_string($response->error ?? null) ? $response->error : __('Zendesk request failed', 'bit-integrations-pro');

            return ['success' => false, 'message' => $message, 'response' => $response, 'code' => 400];
        }

        // DELETE returns empty body on success; other actions return the created/updated entity.
        if ($method === 'DELETE' || $successKey === null || (\is_object($response) && isset($response->{$successKey}))) {
            return ['success' => true, 'message' => __('Zendesk request completed successfully', 'bit-integrations-pro'), 'response' => $response];
        }

        return ['success' => false, 'message' => __('Unexpected Zendesk response', 'bit-integrations-pro'), 'response' => $response, 'code' => 400];
    }

    private static function requiredError(array $fields)
    {
        return [
            'success' => false,
            'message' => wp_sprintf(__('Required field(s) empty: %s', 'bit-integrations-pro'), implode(', ', $fields)),
            'code'    => 400,
        ];
    }

    private static function nothingToUpdate()
    {
        return [
            'success' => false,
            'message' => __('No fields provided to update', 'bit-integrations-pro'),
            'code'    => 400,
        ];
    }

    private static function filterEmpty(array $payload): array
    {
        return array_filter($payload, static function ($value) {
            if (\is_array($value)) {
                return !empty($value);
            }

            // Keep legitimate falsy scalars like 0, '0', and false; drop only null / ''.
            return $value !== null && $value !== '';
        });
    }

    private static function stringToArray($value): ?array
    {
        if ($value === null || $value === '') {
            return null;
        }

        $items = \is_array($value) ? $value : explode(',', (string) $value);
        $items = array_values(array_filter(array_map('trim', $items), static function ($item) {
            return $item !== '';
        }));

        return empty($items) ? null : $items;
    }
}
