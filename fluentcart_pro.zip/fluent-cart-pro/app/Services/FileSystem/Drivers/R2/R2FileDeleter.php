<?php

namespace FluentCartPro\App\Services\FileSystem\Drivers\R2;

class R2FileDeleter
{
    public static function delete(string $accountId, string $secret, string $accessKey, string $bucket, string $filePath)
    {
        $region = 'auto';
        $service = 's3';
        $host = $accountId . '.r2.cloudflarestorage.com';
        $path = '/' . $bucket . '/' . implode('/', array_map('rawurlencode', explode('/', $filePath)));
        $timestamp = gmdate('Ymd\THis\Z');
        $date = gmdate('Ymd');
        $payloadHash = hash('sha256', '');
        $canonicalHeaders = 'host:' . $host . "\n"
            . 'x-amz-content-sha256:' . $payloadHash . "\n"
            . 'x-amz-date:' . $timestamp . "\n";
        $signedHeaders = 'host;x-amz-content-sha256;x-amz-date';
        $canonicalRequest = 'DELETE' . "\n" . $path . "\n\n" . $canonicalHeaders . "\n" . $signedHeaders . "\n" . $payloadHash;
        $credentialScope = $date . '/' . $region . '/' . $service . '/aws4_request';
        $stringToSign = 'AWS4-HMAC-SHA256' . "\n" . $timestamp . "\n" . $credentialScope . "\n" . hash('sha256', $canonicalRequest);
        $kDate = hash_hmac('sha256', $date, 'AWS4' . $secret, true);
        $kRegion = hash_hmac('sha256', $region, $kDate, true);
        $kService = hash_hmac('sha256', $service, $kRegion, true);
        $kSigning = hash_hmac('sha256', 'aws4_request', $kService, true);
        $signature = hash_hmac('sha256', $stringToSign, $kSigning);

        $response = wp_remote_request('https://' . $host . $path, [
            'method'  => 'DELETE',
            'headers' => [
                'Authorization'        => 'AWS4-HMAC-SHA256 Credential=' . $accessKey . '/' . $credentialScope . ', SignedHeaders=' . $signedHeaders . ', Signature=' . $signature,
                'x-amz-date'           => $timestamp,
                'x-amz-content-sha256' => $payloadHash,
            ],
            'timeout' => 30,
        ]);

        if (is_wp_error($response)) {
            return $response;
        }

        $code = (int) wp_remote_retrieve_response_code($response);

        if ($code >= 200 && $code < 300) {
            return true;
        }

        return new \WP_Error(
            'r2_delete_failed',
            sprintf(__('Delete failed with code: %s', 'fluent-cart-pro'), $code)
        );
    }
}
