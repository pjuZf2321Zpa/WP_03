<?php
/** Paid AI Forms display settings, loaded by the Pro composition root. */
namespace WPAICG\Lib\AIForms;

if (!defined('ABSPATH')) {
    exit;
}

final class StorageSettings
{
    public static function is_available(): bool
    {
        return class_exists('\WPAICG\aipkit_dashboard') && \WPAICG\aipkit_dashboard::is_pro_plan();
    }

    public static function get_conversation_ui_preset(int $form_id): string
    {
        if (!self::is_available()) {
            return 'full';
        }
        return self::normalize_conversation_ui_preset((string) get_post_meta($form_id, '_aipkit_ai_form_conversation_ui_preset', true));
    }

    public static function save_conversation_ui_preset(int $form_id, array $settings): void
    {
        if (!self::is_available()) {
            return;
        }
        if (isset($settings['conversation_ui_preset'])) {
            update_post_meta($form_id, '_aipkit_ai_form_conversation_ui_preset', self::normalize_conversation_ui_preset($settings['conversation_ui_preset']));
        }
    }

    /** Missing or unavailable paid controls must leave saved metadata alone. */
    public static function get_submitted_conversation_ui_preset(array $post_data): ?string
    {
        if (!self::is_available() || !isset($post_data['conversation_ui_preset']) || $post_data['conversation_ui_preset'] === '') {
            return null;
        }
        return self::normalize_conversation_ui_preset($post_data['conversation_ui_preset']);
    }

    private static function normalize_conversation_ui_preset($preset): string
    {
        $preset = sanitize_key($preset);
        return in_array($preset, ['full', 'compact', 'minimal', 'none'], true) ? $preset : 'full';
    }

    public static function get_label_defaults(): array
    {
        if (!self::is_available()) {
            return [];
        }
        return [
            'conversation_back_button' => __('Back', 'gpt3-ai-content-generator'),
            'conversation_next_button' => __('Next', 'gpt3-ai-content-generator'),
            'conversation_step_title' => __('Step {number}', 'gpt3-ai-content-generator'),
            'conversation_step_progress' => __('Step {current} of {total}', 'gpt3-ai-content-generator'),
            'conversation_validation_message' => __('Please complete this step before continuing.', 'gpt3-ai-content-generator'),
        ];
    }
}
