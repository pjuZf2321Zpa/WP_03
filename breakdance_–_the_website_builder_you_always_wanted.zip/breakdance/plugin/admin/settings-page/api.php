<?php

namespace Breakdance\Admin\SettingsPage;

/*
this is the public API developers can use to add a tab to our settings page
hook breakdance_register_admin_settings_page_register_tabs, then call addTab
 */

/**
 * @param string $name
 * @param string $slug
 * @param callable $callback
 * @param int $order
 * @return void
 */
function addTab($name, $slug, $callback, $order)
{
    SettingsPageController::getInstance()->tabs[] = [
        'name' => $name,
        'slug' => $slug,
        'order' => $order
    ];

    add_action('breakdance_admin_settings_page_tabs_' . $slug . '_tab', $callback);
}

/**
 * wp-admin URL of the settings page, optionally deep-linked to one tab.
 *
 * The page slug differs per builder, so callers ask for it here instead of
 * assembling `admin.php?page=...` themselves.
 *
 * @param string $tab Tab slug, as passed to addTab(). Empty for the first tab.
 * @param string $fragment Optional #fragment, without the leading hash.
 * @return string
 */
function settings_page_url($tab = '', $fragment = '')
{
    $url = admin_url('admin.php?page=' . \Breakdance\BreakdanceOxygen\Strings\__bdox('admin_page_settings_slug'));

    if ($tab !== '') {
        $url .= '&tab=' . $tab;
    }

    if ($fragment !== '') {
        $url .= '#' . $fragment;
    }

    return $url;
}

add_action('init', function () {
    bdox_run_action('breakdance_register_admin_settings_page_register_tabs');
});
