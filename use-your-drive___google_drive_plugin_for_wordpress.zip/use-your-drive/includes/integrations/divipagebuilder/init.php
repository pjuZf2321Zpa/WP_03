<?php
/**
 * WP Cloud Plugins — Divi Page Builder integration.
 *
 * Bundled inside every WP Cloud Plugins product, so the guards below make sure
 * only the first copy that loads is used.
 */

namespace TheLion\Integrations\Divi;

defined('ABSPATH') || exit;

if (!function_exists(__NAMESPACE__.'\initialize_extension')) {
    /**
     * Boot the integration. Runs once per request.
     */
    function initialize_extension()
    {
        if (defined('WPCP_DIVI_EXTENSION_PATH')) {
            return;
        }

        define('WPCP_DIVI_EXTENSION_PATH', plugin_dir_path(__FILE__));
        define('WPCP_DIVI_EXTENSION_URL', plugin_dir_url(__FILE__));
        define('WPCP_DIVI_EXTENSION_VERSION', '2.0.0');

        // Registered on Divi 4 and Divi 5 alike: Divi 5 loads the Divi 4 framework
        // per module for layouts that have not been converted yet.
        add_action('divi_extensions_init', __NAMESPACE__.'\load_divi_4');

        require_once WPCP_DIVI_EXTENSION_PATH.'divi-5/bootstrap.php';
    }

    /**
     * Load the legacy Divi 4 extension.
     */
    function load_divi_4()
    {
        if (class_exists(__NAMESPACE__.'\WPCP_DiviExtension') || !class_exists('\DiviExtension')) {
            return;
        }

        require_once WPCP_DIVI_EXTENSION_PATH.'divi-4/includes/DiviExtension.php';
    }

    initialize_extension();
}
