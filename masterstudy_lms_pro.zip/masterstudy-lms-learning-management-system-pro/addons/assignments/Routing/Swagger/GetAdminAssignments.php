<?php

namespace MasterStudy\Lms\Pro\addons\assignments\Routing\Swagger;

use MasterStudy\Lms\Routing\Swagger\RequestInterface;
use MasterStudy\Lms\Routing\Swagger\ResponseInterface;
use MasterStudy\Lms\Routing\Swagger\Route;

class GetAdminAssignments extends Route implements RequestInterface, ResponseInterface {
	public function request(): array {
		return array(
			'per_page'          => array(
				'type'        => 'integer',
				'description' => 'Assignments per page. Default is 10.',
			),
			'page'              => array(
				'type'        => 'integer',
				'description' => 'Current page. Default is 1.',
			),
			'search'            => array(
				'type'        => 'string',
				'description' => 'Search assignments by title.',
			),
			'status'            => array(
				'type'        => 'string',
				'description' => 'Filter by WordPress post status.',
				'enum'        => array( 'any', 'publish', 'pending', 'draft', 'trash', 'private' ),
			),
			'assignment_status' => array(
				'type'        => 'string',
				'description' => 'Filter by student assignment submission status.',
				'enum'        => array( 'passed', 'not_passed', 'pending' ),
			),
			'sort'              => array(
				'type'        => 'string',
				'description' => 'Sort field and direction (e.g. title, -date, course, -total, passed, not_passed, pending).',
			),
			'date_range'        => array(
				'type'        => 'string',
				'description' => 'Date range filter.',
			),
			'lang'              => array(
				'type'        => 'string',
				'description' => 'WPML language code or all.',
			),
		);
	}

	public function response(): array {
		return array(
			'assignments'       => array(
				'type'  => 'array',
				'items' => array(
					'type'       => 'object',
					'properties' => array(
						'id'         => array(
							'type' => 'integer',
						),
						'title'      => array(
							'type' => 'string',
						),
						'date'       => array(
							'type' => 'string',
						),
						'status'     => array(
							'type' => 'string',
							'enum' => array( 'publish', 'pending', 'draft', 'trash', 'private' ),
						),
						'courses'    => array(
							'type'  => 'array',
							'items' => array(
								'type'       => 'object',
								'properties' => array(
									'id'    => array(
										'type' => 'integer',
									),
									'title' => array(
										'type' => 'string',
									),
								),
							),
						),
						'total'      => array(
							'type' => 'integer',
						),
						'passed'     => array(
							'type' => 'integer',
						),
						'not_passed' => array(
							'type' => 'integer',
						),
						'pending'    => array(
							'type' => 'integer',
						),
					),
				),
			),
			'pages'             => array(
				'type'        => 'integer',
				'description' => 'Total number of pages.',
			),
			'current_page'      => array(
				'type'        => 'integer',
				'description' => 'Current page number.',
			),
			'total_assignments' => array(
				'type'        => 'integer',
				'description' => 'Total number of assignments.',
			),
		);
	}

	public function get_summary(): string {
		return 'Get Admin Assignments';
	}

	public function get_description(): string {
		return 'Returns a paginated list of assignments for the admin panel.';
	}
}
