<?php

namespace FluentCartPro\App\Hooks\Handlers\BlockEditors\EmailBlocks\OrderItems;

use FluentCart\App\Hooks\Handlers\BlockEditors\BlockEditor;
use FluentCart\Framework\Support\Arr;

class OrderItemsBlockEditor extends BlockEditor
{
    use \FluentCartPro\App\Contracts\CanEnqueue;
    protected static string $editorName = 'email-order-items';

    public function getScripts(): array
    {
        return [
            [
                'source'       => 'admin/BlockEditor/EmailBlocks/OrderItems/OrderItemsBlockEditor.jsx',
                'dependencies' => ['wp-blocks', 'wp-components', 'wp-block-editor']
            ]
        ];
    }

    public function getStyles(): array
    {
        return [
            'admin/BlockEditor/EmailBlocks/OrderItems/style/order-items-block-editor.scss'
        ];
    }

    public function localizeData(): array
    {
        return [
            $this->getLocalizationKey() => [
                'slug'        => $this->slugPrefix,
                'name'        => static::getEditorName(),
                'title'       => __('Order Items', 'fluent-cart-pro'),
                'description' => __('Loops over order line items with a customizable template using {{item.*}} shortcodes.', 'fluent-cart-pro'),
            ],
            'fluent_cart_pro_block_translation' => \FluentCartPro\App\Services\Translations\Translations::blockStrings(),
        ];
    }

    public function blockAttributes(): array
    {
        return [
            'loopType' => [
                'type'    => 'string',
                'default' => 'orderItems',
            ],
            'showSeparator' => [
                'type'    => 'boolean',
                'default' => true,
            ],
            'separatorColor' => [
                'type'    => 'string',
                'default' => '#e5e7eb',
            ],
        ];
    }

    public function provideContext()
    {
        return [
            'fluent-cart/loopType' => 'loopType',
        ];
    }

    public function supports(): array
    {
        return [
            'html'       => false,
            'align'      => false,
            'color'      => [
                'text'       => true,
                'background' => true,
            ],
            'spacing'    => [
                'margin'  => true,
                'padding' => true,
            ],
            '__experimentalBorder' => [
                'color'  => true,
                'radius' => true,
                'style'  => true,
                'width'  => true,
            ],
        ];
    }

    public function render(array $attrs, $block = null, $content = ''): string
    {
        return $content;
    }
}
