<?php

defined('ABSPATH') || exit;

/**
 * A single priced line of an order quote.
 *
 * A line carries the engine's figures verbatim: under the
 * stripe-automatic engine the money is Stripe's allocation for the
 * basket, observed data that consumers copy and never recompute; under
 * the rate-based engine it is the blended math's output. The display
 * labels are the blended rate, description, and class the line shows
 * and persists. Lines never carry rate components: components are
 * engine internals for computing totals, and exposing them here would
 * invite consumers to recompute what must be copied.
 *
 * A line knows how to apply itself to the rows it priced (see
 * apply_to()); the write goes through the transaction's breakdown
 * method, so quote-sourced and charged-copy writes share one door.
 */
final class MeprOrderQuoteLine
{
    /**
     * The main product's line.
     *
     * @var string
     */
    const KIND_MAIN = 'main';

    /**
     * An order bump's line.
     *
     * @var string
     */
    const KIND_BUMP = 'bump';

    /**
     * A paid trial's upfront charge line.
     *
     * @var string
     */
    const KIND_TRIAL_CHARGE = 'trial_charge';

    /**
     * A subscription's first billing period line.
     *
     * @var string
     */
    const KIND_FIRST_PERIOD = 'first_period';

    /**
     * The engine-opaque line reference. Preview-stage lines use
     * product-positional keys (prd_{product_id}_{position}); submit-stage
     * lines use the persistent keys (txn_{id}, sub_{id}_first_period).
     *
     * @var string
     */
    public string $reference;

    /**
     * The product the line charges for.
     *
     * @var integer
     */
    public int $product_id;

    /**
     * The line kind, one of the KIND_* constants.
     *
     * @var string
     */
    public string $kind;

    /**
     * The pre-tax amount.
     *
     * @var float
     */
    public float $amount;

    /**
     * The tax amount (the engine's allocation for this line).
     *
     * @var float
     */
    public float $tax_amount;

    /**
     * The gross total (amount plus tax_amount).
     *
     * @var float
     */
    public float $total;

    /**
     * The blended tax rate the line displays and persists.
     *
     * @var float
     */
    public float $tax_rate;

    /**
     * The blended tax description (e.g., 'GST + QST').
     *
     * @var string
     */
    public string $tax_desc;

    /**
     * The blended tax class (e.g., 'gst,qst').
     *
     * @var string
     */
    public string $tax_class;

    /**
     * The VAT stripped from a reverse-charged line's price under
     * net-price removal (the charged-copy convention); 0.00 on every
     * other line, including reverse-charged lines without removal.
     *
     * @var float
     */
    public float $tax_reversal_amount;

    /**
     * Constructor for the MeprOrderQuoteLine class.
     *
     * @param string  $reference           The engine-opaque line reference.
     * @param integer $product_id          The product the line charges for.
     * @param string  $kind                The line kind, one of the KIND_* constants.
     * @param float   $amount              The pre-tax amount.
     * @param float   $tax_amount          The tax amount.
     * @param float   $total               The gross total.
     * @param float   $tax_rate            The blended tax rate.
     * @param string  $tax_desc            The blended tax description.
     * @param string  $tax_class           The blended tax class.
     * @param float   $tax_reversal_amount The reverse-charge reversal amount.
     */
    public function __construct(
        string $reference,
        int $product_id,
        string $kind,
        float $amount,
        float $tax_amount,
        float $total,
        float $tax_rate,
        string $tax_desc,
        string $tax_class,
        float $tax_reversal_amount = 0.00
    ) {
        $this->reference           = $reference;
        $this->product_id          = $product_id;
        $this->kind                = $kind;
        $this->amount              = $amount;
        $this->tax_amount          = $tax_amount;
        $this->total               = $total;
        $this->tax_rate            = $tax_rate;
        $this->tax_desc            = $tax_desc;
        $this->tax_class           = $tax_class;
        $this->tax_reversal_amount = $tax_reversal_amount;
    }

    /**
     * The line as a plain array snapshot (the cached form).
     *
     * @return array<string,mixed>
     */
    public function to_array(): array
    {
        return [
            'reference'           => $this->reference,
            'product_id'          => $this->product_id,
            'kind'                => $this->kind,
            'amount'              => $this->amount,
            'tax_amount'          => $this->tax_amount,
            'total'               => $this->total,
            'tax_rate'            => $this->tax_rate,
            'tax_desc'            => $this->tax_desc,
            'tax_class'           => $this->tax_class,
            'tax_reversal_amount' => $this->tax_reversal_amount,
        ];
    }

    /**
     * Rebuild a line from an array snapshot, or null when the payload
     * does not match the expected shape.
     *
     * @param  array<string,mixed> $data The snapshot.
     * @return self|null
     */
    public static function from_array(array $data): ?self
    {
        foreach (['reference', 'kind', 'tax_desc', 'tax_class'] as $key) {
            if (!is_string($data[$key] ?? null)) {
                return null;
            }
        }

        foreach (['amount', 'tax_amount', 'total', 'tax_rate', 'tax_reversal_amount'] as $key) {
            if (!is_float($data[$key] ?? null) && !is_int($data[$key] ?? null)) {
                return null;
            }
        }

        if (!is_int($data['product_id'] ?? null)) {
            return null;
        }

        if (!in_array($data['kind'], [self::KIND_MAIN, self::KIND_BUMP, self::KIND_TRIAL_CHARGE, self::KIND_FIRST_PERIOD], true)) {
            return null;
        }

        return new self(
            $data['reference'],
            $data['product_id'],
            $data['kind'],
            (float) $data['amount'],
            (float) $data['tax_amount'],
            (float) $data['total'],
            (float) $data['tax_rate'],
            $data['tax_desc'],
            $data['tax_class'],
            (float) $data['tax_reversal_amount']
        );
    }

    /**
     * Apply this line's figures to the rows it priced.
     *
     * The transaction write goes through the model's breakdown method,
     * the same door every charged copy writes through, so the field set
     * is identical whatever the source. A trial-charge line also writes
     * the trial trio and the stripped VAT onto the subscription; every
     * other kind leaves the subscription untouched, because its money
     * fields describe renewals. Persistence stays with the caller.
     *
     * @param  MeprTransaction       $txn The transaction the line priced.
     * @param  MeprSubscription|null $sub The transaction's subscription when recurring.
     * @return void
     */
    public function apply_to(MeprTransaction $txn, ?MeprSubscription $sub = null): void
    {
        $txn->apply_amount_breakdown([
            'amount'              => $this->amount,
            'total'               => $this->total,
            'tax_amount'          => $this->tax_amount,
            'tax_rate'            => $this->tax_rate,
            'tax_desc'            => $this->tax_desc,
            'tax_class'           => $this->tax_class,
            'tax_reversal_amount' => $this->tax_reversal_amount,
        ]);

        if ($this->kind === self::KIND_TRIAL_CHARGE && $sub instanceof MeprSubscription) {
            $sub->trial_amount              = $this->amount;
            $sub->trial_tax_amount          = $this->tax_amount;
            $sub->trial_total               = $this->total;
            $sub->trial_tax_reversal_amount = $this->tax_reversal_amount;
        }
    }
}
