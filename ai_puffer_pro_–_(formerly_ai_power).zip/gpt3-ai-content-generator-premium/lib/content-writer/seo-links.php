<?php

namespace WPAICG\ContentWriter\SEO;

if (!defined('ABSPATH')) {
    exit;
}

/** Shared site lookup; each link policy retains its own host normalization. */
trait AIPKit_Content_Writer_SEO_Link_Context_Trait
{
    private static function get_site_host(array $context): string
    {
        $url = (string) ($context['site_url'] ?? $context['home_url'] ?? '');
        if ($url === '') {
            $url = home_url();
        }

        $host = wp_parse_url($url, PHP_URL_HOST);
        return is_string($host) ? self::normalize_host($host) : '';
    }
}

/**
 * Provides verified internal link candidates for Smart SEO improvements.
 */
class AIPKit_Content_Writer_Smart_SEO_Internal_Link_Helper
{
    use AIPKit_Content_Writer_SEO_Link_Context_Trait;

    public static function get_candidates(array $draft, array $context = [], int $limit = 8, bool $include_home_fallback = true): array
    {
        $limit = max(1, min(10, $limit));
        $is_rank_math = self::is_rank_math_profile($context);
        $use_root_relative_urls = self::uses_root_relative_internal_urls($context);
        if ($is_rank_math) {
            $include_home_fallback = false;
        }
        $search_terms = self::build_search_terms($draft, $context);
        $post_types = self::get_public_post_types();
        $excluded_ids = self::get_excluded_post_ids($context);
        $excluded_lookup = array_fill_keys($excluded_ids, true);
        $scored_posts = [];

        foreach ($search_terms as $term_index => $term) {
            $query = new \WP_Query([
                'post_type' => $post_types,
                'post_status' => 'publish',
                'posts_per_page' => max(12, ($limit * 3) + 3),
                'fields' => 'ids',
                'no_found_rows' => true,
                'ignore_sticky_posts' => true,
                'orderby' => 'relevance',
                's' => $term,
            ]);

            $rank = 0;
            foreach ($query->posts as $post_id) {
                $post_id = absint($post_id);
                if ($post_id <= 0 || isset($excluded_lookup[$post_id])) {
                    continue;
                }

                if (!isset($scored_posts[$post_id])) {
                    $scored_posts[$post_id] = [
                        'post_id' => $post_id,
                        'score' => 0,
                    ];
                }

                $title = get_the_title($post_id);
                $title_bonus = self::text_contains_phrase((string) $title, $term) ? 30 : 0;
                $scored_posts[$post_id]['score'] += max(1, 80 - ($term_index * 10) - $rank) + $title_bonus;
                $rank++;
            }
        }

        if (empty($scored_posts)) {
            return $include_home_fallback ? [self::get_homepage_candidate($use_root_relative_urls)] : [];
        }

        uasort($scored_posts, static function (array $left, array $right): int {
            return ($right['score'] ?? 0) <=> ($left['score'] ?? 0);
        });

        $candidates = [];
        foreach ($scored_posts as $post) {
            $post_id = absint($post['post_id'] ?? 0);
            if ($post_id <= 0 || get_post_status($post_id) !== 'publish') {
                continue;
            }

            $url = get_permalink($post_id);
            if (!is_string($url) || trim($url) === '') {
                continue;
            }

            $url = esc_url_raw($url);
            $post_type_object = get_post_type_object((string) get_post_type($post_id));
            $candidates[] = [
                'id' => $post_id,
                'title' => sanitize_text_field((string) get_the_title($post_id)),
                'url' => $use_root_relative_urls ? self::to_root_relative_url($url) : $url,
                'absolute_url' => $url,
                'type' => $post_type_object && isset($post_type_object->labels->singular_name)
                    ? sanitize_text_field((string) $post_type_object->labels->singular_name)
                    : sanitize_text_field((string) get_post_type($post_id)),
                'homepage_fallback' => false,
            ];

            if (count($candidates) >= $limit) {
                break;
            }
        }

        return !empty($candidates) ? $candidates : ($include_home_fallback ? [self::get_homepage_candidate($use_root_relative_urls)] : []);
    }

    public static function format_candidates_for_prompt(array $candidates): string
    {
        if (empty($candidates)) {
            return 'Approved internal link candidates: none. Do not add a new internal link.';
        }

        $safe_candidates = [];
        foreach ($candidates as $candidate) {
            if (!is_array($candidate)) {
                continue;
            }

            $url = isset($candidate['url']) ? esc_url_raw((string) $candidate['url']) : '';
            if ($url === '') {
                continue;
            }

            $safe_candidates[] = [
                'title' => sanitize_text_field((string) ($candidate['title'] ?? '')),
                'url' => $url,
                'type' => sanitize_text_field((string) ($candidate['type'] ?? '')),
                'homepage_fallback' => !empty($candidate['homepage_fallback']),
            ];
        }

        if (empty($safe_candidates)) {
            return 'Approved internal link candidates: none. Do not add a new internal link.';
        }

        return 'Approved internal link candidates. Use only these URLs and do not invent internal URLs:' . "\n"
            . wp_json_encode($safe_candidates, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    }

    public static function get_candidate_urls(array $candidates): array
    {
        $urls = [];
        foreach ($candidates as $candidate) {
            if (!is_array($candidate)) {
                continue;
            }

            $url = isset($candidate['url']) ? esc_url_raw((string) $candidate['url']) : '';
            if ($url !== '') {
                $urls[] = $url;
            }

            $absolute_url = isset($candidate['absolute_url']) ? esc_url_raw((string) $candidate['absolute_url']) : '';
            if ($absolute_url !== '') {
                $urls[] = $absolute_url;
            }
        }

        return array_values(array_unique($urls));
    }

    public static function clean_invalid_internal_links(string $html, array $approved_candidates = [], array $context = []): string
    {
        if (trim($html) === '' || stripos($html, '<a') === false) {
            return $html;
        }

        $approved_urls = self::get_candidate_urls($approved_candidates);
        $cleaned = preg_replace_callback('/<a\b([^>]*)>(.*?)<\/a>/is', static function (array $match) use ($approved_urls, $context): string {
            $attributes = (string) ($match[1] ?? '');
            $inner_html = (string) ($match[2] ?? '');

            if (!preg_match('/\bhref=["\']([^"\']+)["\']/i', $attributes, $href_match)) {
                return (string) ($match[0] ?? '');
            }

            $href = trim((string) $href_match[1]);
            if (!self::is_internal_href($href, $context)) {
                return (string) ($match[0] ?? '');
            }

            return self::is_valid_internal_href($href, $context, $approved_urls)
                ? (string) ($match[0] ?? '')
                : $inner_html;
        }, $html);

        return wp_kses_post((string) $cleaned);
    }

    private static function build_search_terms(array $draft, array $context): array
    {
        $raw_terms = [
            (string) ($draft['focus_keyword'] ?? ''),
            (string) ($context['topic'] ?? ''),
            (string) ($draft['title'] ?? ''),
            (string) ($context['keywords'] ?? ''),
            (string) ($draft['tags'] ?? ''),
        ];

        $terms = [];
        foreach ($raw_terms as $raw_term) {
            foreach (preg_split('/[,|;]/', $raw_term) ?: [] as $part) {
                $term = self::normalize_search_term((string) $part);
                if ($term === '' || isset($terms[$term])) {
                    continue;
                }

                $terms[$term] = $term;
                if (count($terms) >= 5) {
                    break 2;
                }
            }
        }

        return array_values($terms);
    }

    private static function normalize_search_term(string $term): string
    {
        $term = sanitize_text_field(wp_strip_all_tags($term));
        $term = preg_replace('/\s+/u', ' ', trim((string) $term));
        if ($term === '') {
            return '';
        }

        $words = preg_split('/\s+/u', $term) ?: [];
        $term = implode(' ', array_slice($words, 0, 8));
        $length = function_exists('mb_strlen') ? mb_strlen($term, 'UTF-8') : strlen($term);
        return $length >= 3 ? $term : '';
    }

    private static function get_public_post_types(): array
    {
        $post_types = get_post_types(['public' => true], 'names');
        $post_types = is_array($post_types) ? array_values($post_types) : ['post', 'page'];
        $post_types = array_values(array_diff($post_types, ['attachment']));

        return !empty($post_types) ? $post_types : ['post', 'page'];
    }

    private static function get_excluded_post_ids(array $context): array
    {
        $ids = [];
        foreach (['post_id', 'current_post_id', 'exclude_post_id'] as $key) {
            $post_id = isset($context[$key]) ? absint($context[$key]) : 0;
            if ($post_id > 0) {
                $ids[] = $post_id;
            }
        }

        return array_values(array_unique($ids));
    }

    private static function get_homepage_candidate(bool $root_relative = false): array
    {
        $site_name = get_bloginfo('name');
        $site_name = is_string($site_name) && trim($site_name) !== '' ? trim($site_name) : __('Homepage', 'gpt3-ai-content-generator');
        $url = esc_url_raw(home_url('/'));

        return [
            'id' => 0,
            'title' => sanitize_text_field($site_name),
            'url' => $root_relative ? self::to_root_relative_url($url) : $url,
            'absolute_url' => $url,
            'type' => __('Homepage', 'gpt3-ai-content-generator'),
            'homepage_fallback' => true,
        ];
    }

    private static function text_contains_phrase(string $text, string $phrase): bool
    {
        $text = self::normalize_text($text);
        $phrase = self::normalize_text($phrase);
        return $text !== '' && $phrase !== '' && strpos($text, $phrase) !== false;
    }

    private static function normalize_text(string $text): string
    {
        $text = function_exists('remove_accents') ? remove_accents($text) : $text;
        $text = function_exists('mb_strtolower') ? mb_strtolower($text, 'UTF-8') : strtolower($text);
        return preg_replace('/\s+/u', ' ', trim((string) $text));
    }

    private static function is_internal_href(string $href, array $context): bool
    {
        $href = trim($href);
        if ($href === '' || strncmp($href, '#', strlen('#')) === 0 || preg_match('/^(mailto|tel|sms|javascript|data):/i', $href)) {
            return false;
        }

        if (strncmp($href, '/', strlen('/')) === 0 && strncmp($href, '//', strlen('//')) !== 0) {
            return true;
        }

        $host = wp_parse_url($href, PHP_URL_HOST);
        if (is_string($host) && $host !== '') {
            return self::normalize_host($host) === self::get_site_host($context);
        }

        return !preg_match('/^[a-z][a-z0-9+.-]*:/i', $href);
    }

    private static function is_valid_internal_href(string $href, array $context, array $approved_urls = []): bool
    {
        $absolute_url = self::absolute_internal_url($href, $context);
        if ($absolute_url === '') {
            return false;
        }

        $normalized_url = self::normalize_url_for_comparison($absolute_url);
        foreach ($approved_urls as $approved_url) {
            if ($normalized_url === self::normalize_url_for_comparison((string) $approved_url)) {
                return true;
            }
        }

        if (!empty($approved_urls)) {
            return false;
        }

        if (!self::is_rank_math_profile($context) && empty($approved_urls) && $normalized_url === self::normalize_url_for_comparison(home_url('/'))) {
            return true;
        }

        $post_id = url_to_postid($absolute_url);
        return $post_id > 0 && get_post_status($post_id) === 'publish';
    }

    private static function absolute_internal_url(string $href, array $context): string
    {
        $href = trim($href);
        if ($href === '') {
            return '';
        }

        $host = wp_parse_url($href, PHP_URL_HOST);
        if (is_string($host) && $host !== '') {
            return esc_url_raw($href);
        }

        if (strncmp($href, '//', strlen('//')) === 0) {
            return '';
        }

        return esc_url_raw(home_url('/' . ltrim($href, '/')));
    }

    private static function normalize_host(string $host): string
    {
        return preg_replace('/^www\./i', '', strtolower($host));
    }

    private static function normalize_url_for_comparison(string $url): string
    {
        $url = esc_url_raw($url);
        if ($url !== '' && !preg_match('/^[a-z][a-z0-9+.-]*:/i', $url) && strncmp($url, '//', strlen('//')) !== 0) {
            $url = home_url('/' . ltrim($url, '/'));
        }
        $url = strtok($url, '#') ?: $url;
        $url = strtok($url, '?') ?: $url;
        return rtrim(strtolower($url), '/');
    }

    private static function is_rank_math_profile(array $context): bool
    {
        return isset($context['profile']) && sanitize_key((string) $context['profile']) === 'rank_math';
    }

    private static function uses_root_relative_internal_urls(array $context): bool
    {
        $profile = isset($context['profile']) ? sanitize_key((string) $context['profile']) : '';
        return in_array($profile, ['rank_math', 'aioseo'], true);
    }

    private static function to_root_relative_url(string $url): string
    {
        $relative_url = function_exists('wp_make_link_relative') ? wp_make_link_relative($url) : '';
        $relative_url = is_string($relative_url) ? trim($relative_url) : '';

        return $relative_url !== '' && strncmp($relative_url, '/', strlen('/')) === 0
            ? $relative_url
            : esc_url_raw($url);
    }
}

/**
 * Cleans risky outbound links produced during Smart SEO improvement.
 */
class AIPKit_Content_Writer_Smart_SEO_External_Link_Helper
{
    use AIPKit_Content_Writer_SEO_Link_Context_Trait;

    public static function get_prompt_guidance(): string
    {
        return implode(' ', [
            'If outbound links are missing or all outbound links are nofollowed, add one relevant reputable external link.',
            'Use an absolute HTTPS URL only.',
            'Prefer official, educational, government, standards, documentation, primary research, or recognized reference sources.',
            'Do not use URL shorteners, tracking links, search result pages, social profile links, forums, affiliate links, or competitor sales pages.',
            'Use descriptive anchor text that explains the source; do not use the focus keyphrase as the outbound anchor.',
            'The normal outbound link must not include rel="nofollow", rel="sponsored", or rel="ugc".',
        ]);
    }

    public static function clean_outbound_links(string $html, array $context = []): string
    {
        if (trim($html) === '' || stripos($html, '<a') === false) {
            return $html;
        }

        $cleaned = preg_replace_callback('/<a\b([^>]*)>(.*?)<\/a>/is', static function (array $match) use ($context): string {
            $attributes = (string) ($match[1] ?? '');
            $inner_html = (string) ($match[2] ?? '');

            if (!preg_match('/\bhref=(["\'])(.*?)\1/i', $attributes, $href_match)) {
                return (string) ($match[0] ?? '');
            }

            $href = trim((string) ($href_match[2] ?? ''));
            if (!self::is_external_href($href, $context)) {
                return (string) ($match[0] ?? '');
            }

            if (!self::is_safe_outbound_href($href, $context)) {
                return $inner_html;
            }

            $clean_href = self::clean_outbound_href($href);
            if ($clean_href === '' || !self::is_safe_outbound_href($clean_href, $context)) {
                return $inner_html;
            }

            if ($clean_href === $href) {
                return (string) ($match[0] ?? '');
            }

            $safe_attributes = preg_replace(
                '/\bhref=(["\'])(.*?)\1/i',
                'href="' . esc_url($clean_href) . '"',
                $attributes,
                1
            );

            return '<a' . (string) $safe_attributes . '>' . $inner_html . '</a>';
        }, $html);

        return wp_kses_post((string) $cleaned);
    }

    public static function is_external_href(string $href, array $context = []): bool
    {
        $href = trim($href);
        if ($href === '' || preg_match('/^(mailto|tel|sms|javascript|data):/i', $href)) {
            return false;
        }

        $host = wp_parse_url($href, PHP_URL_HOST);
        if (!is_string($host) || $host === '') {
            return false;
        }

        return self::normalize_host($host) !== self::get_site_host($context);
    }

    public static function is_safe_outbound_href(string $href, array $context = []): bool
    {
        $href = trim($href);
        $scheme = wp_parse_url($href, PHP_URL_SCHEME);
        if (!is_string($scheme) || strtolower($scheme) !== 'https') {
            return false;
        }

        if (!self::is_external_href($href, $context)) {
            return false;
        }

        $host = wp_parse_url($href, PHP_URL_HOST);
        $host = is_string($host) ? self::normalize_host($host) : '';
        if (!self::is_safe_host($host)) {
            return false;
        }

        $path = wp_parse_url($href, PHP_URL_PATH);
        $path = is_string($path) ? strtolower($path) : '';
        if (preg_match('#/(login|signin|signup|cart|checkout|account)(/|$)#i', $path)) {
            return false;
        }

        return true;
    }

    private static function clean_outbound_href(string $href): string
    {
        $href = esc_url_raw($href);
        if ($href === '') {
            return '';
        }

        $parts = wp_parse_url($href);
        if (!is_array($parts) || empty($parts['scheme']) || empty($parts['host'])) {
            return $href;
        }

        $url = strtolower((string) $parts['scheme']) . '://' . strtolower((string) $parts['host']);
        if (!empty($parts['path'])) {
            $url .= (string) $parts['path'];
        }

        if (!empty($parts['query'])) {
            parse_str((string) $parts['query'], $query_args);
            foreach (array_keys($query_args) as $key) {
                $normalized_key = strtolower((string) $key);
                if (
                    strncmp($normalized_key, 'utm_', strlen('utm_')) === 0
                    || in_array($normalized_key, ['fbclid', 'gclid', 'msclkid', 'mc_cid', 'mc_eid', 'igshid'], true)
                ) {
                    unset($query_args[$key]);
                }
            }

            if (!empty($query_args)) {
                $url = add_query_arg($query_args, $url);
            }
        }

        return esc_url_raw($url);
    }

    private static function is_safe_host(string $host): bool
    {
        if ($host === '' || strpos($host, '.') === false || preg_match('/[^a-z0-9.-]/', $host)) {
            return false;
        }

        if (preg_match('/\.(local|localhost|test|invalid|example)$/i', $host)) {
            return false;
        }

        if (in_array($host, self::blocked_hosts(), true)) {
            return false;
        }

        foreach (self::blocked_host_suffixes() as $suffix) {
            if ($host === $suffix || substr_compare($host, '.' . $suffix, -strlen('.' . $suffix)) === 0) {
                return false;
            }
        }

        $ip = trim($host, '[]');
        if (filter_var($ip, FILTER_VALIDATE_IP)) {
            return filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE) !== false;
        }

        return (bool) preg_match('/\.[a-z]{2,}$/', $host);
    }

    private static function blocked_hosts(): array
    {
        return [
            'example.com',
            'example.org',
            'example.net',
            'bit.ly',
            'tinyurl.com',
            't.co',
            'goo.gl',
            'ow.ly',
            'buff.ly',
            'rebrand.ly',
            'is.gd',
            'cutt.ly',
            'shorturl.at',
            'localhost',
        ];
    }

    private static function blocked_host_suffixes(): array
    {
        return [
            'facebook.com',
            'instagram.com',
            'linkedin.com',
            'pinterest.com',
            'reddit.com',
            'tiktok.com',
            'x.com',
            'twitter.com',
            'youtube.com',
            'youtu.be',
        ];
    }

    private static function normalize_host(string $host): string
    {
        return preg_replace('/^www\./i', '', strtolower(trim($host)));
    }
}
