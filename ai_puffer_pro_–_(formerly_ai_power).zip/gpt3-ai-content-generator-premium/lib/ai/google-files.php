<?php

namespace WPAICG\Core\Providers\Google\Files;

use WP_Error;
use WPAICG\Core\AIPKit_HTTP_Request;
use WPAICG\Core\Providers\Google\Interactions\GoogleInteractionsErrorParser;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Builds and validates endpoints for Google's temporary Files API.
 */
final class GoogleFilesUrlBuilder
{
    // phpcs:ignore PluginCheck.CodeAnalysis.AIProvider.DirectIntegration -- Provider-specific API transport.
    public const DEFAULT_BASE_URL = 'https://generativelanguage.googleapis.com';
    public const API_VERSION = 'v1beta';

    /**
     * @param array<string, mixed> $connection
     * @return string|WP_Error
     */
    public static function build(string $operation, array $connection = [], string $file_name = '')
    {
        $base_url = self::base_url($connection);
        if (is_wp_error($base_url)) {
            return $base_url;
        }

        if ($operation === 'upload_start') {
            return $base_url . '/upload/' . self::API_VERSION . '/files';
        }

        $normalized_file_name = self::normalize_file_name($file_name);
        if (is_wp_error($normalized_file_name)) {
            return $normalized_file_name;
        }
        if (in_array($operation, ['get', 'delete'], true)) {
            return $base_url . '/' . self::API_VERSION . '/' . $normalized_file_name;
        }

        return new WP_Error(
            'google_files_unknown_operation',
            __('Unsupported Google Files API operation.', 'gpt3-ai-content-generator')
        );
    }

    /**
     * @return string|WP_Error
     */
    public static function normalize_file_name(string $file_name)
    {
        $file_name = trim($file_name, "/ \t\n\r\0\x0B");
        if (strpos($file_name, 'files/') !== 0) {
            return new WP_Error(
                'google_files_invalid_file_name',
                __('A complete Google Files API resource name is required.', 'gpt3-ai-content-generator')
            );
        }

        $file_id = (string) substr($file_name, strlen('files/'));
        if ($file_id === '' || strlen($file_id) > 256 || !preg_match('/^[A-Za-z0-9._~-]+$/', $file_id)) {
            return new WP_Error(
                'google_files_invalid_file_name',
                __('The Google Files API resource name is invalid.', 'gpt3-ai-content-generator')
            );
        }

        return 'files/' . $file_id;
    }

    /**
     * Google returns an opaque resumable URL. Restrict it to the configured
     * provider origin before sending private file bytes to it.
     *
     * @param array<string, mixed> $connection
     */
    public static function is_trusted_upload_url(string $upload_url, array $connection = []): bool
    {
        $base_url = self::base_url($connection);
        return !is_wp_error($base_url) && self::has_same_trusted_origin($upload_url, $base_url);
    }

    /**
     * @param array<string, mixed> $connection
     */
    public static function is_trusted_file_uri(string $file_uri, array $connection = []): bool
    {
        $base_url = self::base_url($connection);
        if (is_wp_error($base_url) || !self::has_same_trusted_origin($file_uri, $base_url)) {
            return false;
        }

        $uri_parts = wp_parse_url($file_uri);
        $base_parts = wp_parse_url($base_url);
        if (!is_array($uri_parts) || !is_array($base_parts) || isset($uri_parts['query']) || isset($uri_parts['fragment'])) {
            return false;
        }

        $base_path = rtrim((string) ($base_parts['path'] ?? ''), '/');
        $expected_prefix = $base_path . '/' . self::API_VERSION . '/files/';
        $uri_path = (string) ($uri_parts['path'] ?? '');
        if (strpos($uri_path, $expected_prefix) !== 0) {
            return false;
        }

        $file_id = (string) substr($uri_path, strlen($expected_prefix));
        return $file_id !== ''
            && strlen($file_id) <= 256
            && (bool) preg_match('/^[A-Za-z0-9._~-]+$/', $file_id);
    }

    /**
     * @param array<string, mixed> $connection
     * @return string|WP_Error
     */
    private static function base_url(array $connection)
    {
        $base_url = isset($connection['base_url']) && is_string($connection['base_url'])
            ? rtrim(trim($connection['base_url']), '/')
            : self::DEFAULT_BASE_URL;
        if ($base_url === '') {
            $base_url = self::DEFAULT_BASE_URL;
        }

        $parts = wp_parse_url($base_url);
        if (!is_array($parts)) {
            return self::invalid_base_url_error();
        }
        $scheme = strtolower((string) ($parts['scheme'] ?? ''));
        $host = strtolower((string) ($parts['host'] ?? ''));
        $has_credentials = isset($parts['user']) || isset($parts['pass']);
        $has_query_or_fragment = isset($parts['query']) || isset($parts['fragment']);
        $is_local_http = $scheme === 'http' && in_array($host, ['localhost', '127.0.0.1', '::1'], true);
        if (($scheme !== 'https' && !$is_local_http) || $host === '' || $has_credentials || $has_query_or_fragment) {
            return self::invalid_base_url_error();
        }

        return $base_url;
    }

    private static function has_same_trusted_origin(string $candidate_url, string $base_url): bool
    {
        $candidate = wp_parse_url($candidate_url);
        $base = wp_parse_url($base_url);
        if (!is_array($candidate) || !is_array($base)) {
            return false;
        }

        $candidate_scheme = strtolower((string) ($candidate['scheme'] ?? ''));
        $candidate_host = strtolower((string) ($candidate['host'] ?? ''));
        $base_scheme = strtolower((string) ($base['scheme'] ?? ''));
        $base_host = strtolower((string) ($base['host'] ?? ''));
        $candidate_port = self::effective_port($candidate, $candidate_scheme);
        $base_port = self::effective_port($base, $base_scheme);
        $has_credentials = isset($candidate['user']) || isset($candidate['pass']);
        $is_local_http = $candidate_scheme === 'http'
            && in_array($candidate_host, ['localhost', '127.0.0.1', '::1'], true);

        return ($candidate_scheme === 'https' || $is_local_http)
            && $candidate_scheme === $base_scheme
            && $candidate_host !== ''
            && $candidate_host === $base_host
            && $candidate_port === $base_port
            && !$has_credentials;
    }

    /**
     * @param array<string, mixed> $parts
     */
    private static function effective_port(array $parts, string $scheme): int
    {
        if (isset($parts['port'])) {
            return (int) $parts['port'];
        }
        return $scheme === 'https' ? 443 : 80;
    }

    private static function invalid_base_url_error(): WP_Error
    {
        return new WP_Error(
            'google_files_invalid_base_url',
            __('Google Files API requires an HTTPS endpoint or a local development endpoint.', 'gpt3-ai-content-generator')
        );
    }
}

/**
 * Minimal client for temporary Gemini Files API resources.
 */
final class GoogleFilesClient
{
    public const MAX_UPLOAD_BYTES = 52428800;

    /**
     * @param array<string, mixed> $connection
     * @return array<string, mixed>|WP_Error
     */
    public function upload_path(
        array $connection,
        string $file_path,
        string $display_name,
        string $mime_type
    ) {
        if ($file_path === '' || !is_readable($file_path)) {
            return new WP_Error(
                'google_files_unreadable_upload',
                __('The uploaded file cannot be read.', 'gpt3-ai-content-generator'),
                ['status' => 400, 'status_code' => 400]
            );
        }
        $file_size = filesize($file_path);
        if (!is_int($file_size) || $file_size < 1 || $file_size > self::MAX_UPLOAD_BYTES) {
            return new WP_Error(
                'google_files_invalid_upload_size',
                __('Google document uploads must contain data and cannot exceed 50 MB.', 'gpt3-ai-content-generator'),
                ['status' => 400, 'status_code' => 400]
            );
        }

        $mime_type = sanitize_mime_type($mime_type);
        if ($mime_type === '') {
            return new WP_Error(
                'google_files_invalid_mime_type',
                __('A valid MIME type is required for a Google file upload.', 'gpt3-ai-content-generator'),
                ['status' => 400, 'status_code' => 400]
            );
        }
        $api_key = self::api_key($connection);
        if (is_wp_error($api_key)) {
            return $api_key;
        }
        $start_url = GoogleFilesUrlBuilder::build('upload_start', $connection);
        if (is_wp_error($start_url)) {
            return $start_url;
        }

        $metadata_body = wp_json_encode([
            'file' => [
                'display_name' => sanitize_text_field($display_name),
            ],
        ]);
        if (!is_string($metadata_body)) {
            return self::json_encode_error();
        }

        $start_response = $this->perform_http_request(
            $start_url,
            [
                'method' => 'POST',
                'timeout' => self::timeout($connection),
                'headers' => [
                    'Content-Type' => 'application/json',
                    'x-goog-api-key' => $api_key,
                    'X-Goog-Upload-Protocol' => 'resumable',
                    'X-Goog-Upload-Command' => 'start',
                    'X-Goog-Upload-Header-Content-Length' => (string) $file_size,
                    'X-Goog-Upload-Header-Content-Type' => $mime_type,
                ],
                'body' => $metadata_body,
                'data_format' => 'body',
            ]
        );
        if (is_wp_error($start_response)) {
            return $start_response;
        }
        $start_error = self::http_error_from_response($start_response);
        if ($start_error !== null) {
            return $start_error;
        }

        $upload_url = wp_remote_retrieve_header($start_response, 'x-goog-upload-url');
        $upload_url = is_string($upload_url) ? trim($upload_url) : '';
        if ($upload_url === '' || !GoogleFilesUrlBuilder::is_trusted_upload_url($upload_url, $connection)) {
            return new WP_Error(
                'google_files_invalid_upload_url',
                __('Google did not return a trusted resumable upload URL.', 'gpt3-ai-content-generator'),
                ['status' => 502, 'status_code' => 502]
            );
        }

        // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- Reads a validated temporary upload for the remote Files API request.
        $contents = file_get_contents($file_path);
        if (!is_string($contents) || strlen($contents) !== $file_size) {
            return new WP_Error(
                'google_files_upload_read_error',
                __('The uploaded file could not be read completely.', 'gpt3-ai-content-generator'),
                ['status' => 400, 'status_code' => 400]
            );
        }

        $upload_response = $this->perform_http_request(
            $upload_url,
            [
                'method' => 'POST',
                'timeout' => self::timeout($connection),
                'headers' => [
                    'Content-Length' => (string) $file_size,
                    'Content-Type' => $mime_type,
                    'X-Goog-Upload-Offset' => '0',
                    'X-Goog-Upload-Command' => 'upload, finalize',
                ],
                'body' => $contents,
                'data_format' => 'body',
            ]
        );
        unset($contents);
        if (is_wp_error($upload_response)) {
            return $upload_response;
        }

        $decoded = $this->decode_http_response($upload_response);
        return is_wp_error($decoded) ? $decoded : self::normalize_file($decoded, $connection);
    }

    /**
     * @param array<string, mixed> $connection
     * @return array<string, mixed>|WP_Error
     */
    public function get(array $connection, string $file_name)
    {
        $url = GoogleFilesUrlBuilder::build('get', $connection, $file_name);
        if (is_wp_error($url)) {
            return $url;
        }
        $response = $this->request_json($connection, 'GET', $url);
        return is_wp_error($response) ? $response : self::normalize_file($response, $connection);
    }

    /**
     * @param array<string, mixed> $connection
     * @return true|WP_Error
     */
    public function delete(array $connection, string $file_name)
    {
        $url = GoogleFilesUrlBuilder::build('delete', $connection, $file_name);
        if (is_wp_error($url)) {
            return $url;
        }
        $response = $this->request_json($connection, 'DELETE', $url);
        if (is_wp_error($response)) {
            $error_data = $response->get_error_data();
            $status = is_array($error_data)
                ? (int) ($error_data['status_code'] ?? ($error_data['status'] ?? 0))
                : 0;
            return $status === 404 ? true : $response;
        }
        return true;
    }

    /**
     * @param array<string, mixed> $raw_response
     * @param array<string, mixed> $connection
     * @return array<string, mixed>|WP_Error
     */
    public static function normalize_file(array $raw_response, array $connection = [])
    {
        $raw_file = isset($raw_response['file']) && is_array($raw_response['file'])
            ? $raw_response['file']
            : $raw_response;
        $name = is_string($raw_file['name'] ?? null) ? trim((string) $raw_file['name']) : '';
        $normalized_name = GoogleFilesUrlBuilder::normalize_file_name($name);
        $uri = is_string($raw_file['uri'] ?? null) ? trim((string) $raw_file['uri']) : '';
        $mime_type = sanitize_mime_type((string) ($raw_file['mimeType'] ?? ''));
        if (
            is_wp_error($normalized_name)
            || $normalized_name !== $name
            || $uri === ''
            || !GoogleFilesUrlBuilder::is_trusted_file_uri($uri, $connection)
            || $mime_type === ''
        ) {
            return new WP_Error(
                'google_files_malformed_resource',
                __('Google returned a malformed Files API resource.', 'gpt3-ai-content-generator'),
                ['status' => 502, 'status_code' => 502]
            );
        }

        $state = strtoupper(sanitize_key((string) ($raw_file['state'] ?? 'ACTIVE')));
        if (!in_array($state, ['PROCESSING', 'ACTIVE', 'FAILED'], true)) {
            $state = 'PROCESSING';
        }

        return [
            'name' => $name,
            'uri' => $uri,
            'mime_type' => $mime_type,
            'display_name' => sanitize_text_field((string) ($raw_file['displayName'] ?? '')),
            'size_bytes' => absint($raw_file['sizeBytes'] ?? 0),
            'state' => $state,
            'create_time' => sanitize_text_field((string) ($raw_file['createTime'] ?? '')),
            'update_time' => sanitize_text_field((string) ($raw_file['updateTime'] ?? '')),
            'expiration_time' => sanitize_text_field((string) ($raw_file['expirationTime'] ?? '')),
        ];
    }

    /**
     * @param array<string, mixed> $connection
     * @return array<string, mixed>|WP_Error
     */
    private function request_json(array $connection, string $method, string $url)
    {
        $api_key = self::api_key($connection);
        if (is_wp_error($api_key)) {
            return $api_key;
        }
        $response = $this->perform_http_request(
            $url,
            [
                'method' => strtoupper($method),
                'timeout' => self::timeout($connection),
                'headers' => [
                    'Accept' => 'application/json',
                    'x-goog-api-key' => $api_key,
                ],
            ]
        );
        return is_wp_error($response) ? $response : $this->decode_http_response($response);
    }

    /**
     * @return array|WP_Error
     */
    private function perform_http_request(string $url, array $args)
    {
        $response = class_exists(AIPKit_HTTP_Request::class)
            ? AIPKit_HTTP_Request::request($url, $args, true)
            : wp_remote_request($url, $args);
        if (is_wp_error($response)) {
            return new WP_Error(
                'google_files_http_error',
                sprintf(
                    /* translators: %s: Transport error returned by the WordPress HTTP API. */
                    __('Google Files API request failed: %s', 'gpt3-ai-content-generator'),
                    $response->get_error_message()
                ),
                ['status' => 503, 'status_code' => 503]
            );
        }
        return $response;
    }

    /**
     * @param array $response WordPress HTTP response.
     * @return array<string, mixed>|WP_Error
     */
    private function decode_http_response(array $response)
    {
        $error = self::http_error_from_response($response);
        if ($error !== null) {
            return $error;
        }
        $body = (string) wp_remote_retrieve_body($response);
        if (trim($body) === '') {
            return [];
        }
        $decoded = json_decode($body, true);
        if (!is_array($decoded) || json_last_error() !== JSON_ERROR_NONE) {
            return new WP_Error(
                'google_files_invalid_json',
                __('Google returned an invalid JSON Files API response.', 'gpt3-ai-content-generator'),
                ['status' => 502, 'status_code' => 502]
            );
        }
        return $decoded;
    }

    /**
     * @param array $response WordPress HTTP response.
     */
    private static function http_error_from_response(array $response): ?WP_Error
    {
        $status_code = (int) wp_remote_retrieve_response_code($response);
        if ($status_code >= 200 && $status_code < 300) {
            return null;
        }
        return GoogleInteractionsErrorParser::to_wp_error(
            (string) wp_remote_retrieve_body($response),
            $status_code > 0 ? $status_code : 500,
            wp_remote_retrieve_header($response, 'retry-after')
        );
    }

    /**
     * @param array<string, mixed> $connection
     * @return string|WP_Error
     */
    private static function api_key(array $connection)
    {
        $api_key = isset($connection['api_key']) && is_string($connection['api_key'])
            ? trim($connection['api_key'])
            : '';
        if ($api_key === '') {
            return new WP_Error(
                'google_files_missing_api_key',
                __('A Google API key is required for file uploads.', 'gpt3-ai-content-generator'),
                ['status' => 400, 'status_code' => 400]
            );
        }
        return $api_key;
    }

    /**
     * @param array<string, mixed> $connection
     */
    private static function timeout(array $connection): int
    {
        return isset($connection['timeout']) && is_numeric($connection['timeout'])
            ? max(1, min(300, (int) $connection['timeout']))
            : 120;
    }

    private static function json_encode_error(): WP_Error
    {
        return new WP_Error(
            'google_files_json_encode_error',
            __('Failed to encode the Google Files API request.', 'gpt3-ai-content-generator'),
            ['status' => 500, 'status_code' => 500]
        );
    }
}

/**
 * Issues tamper-proof, short-lived references to temporary Google files.
 * The token binds a remote file to one user/session, chatbot, and conversation.
 */
final class GoogleFilesContextToken
{
    private const VERSION = 1;
    private const PROVIDER_LIFETIME_SECONDS = 172800;
    private const MAX_LOCAL_LIFETIME_SECONDS = 169200;
    private const EXPIRY_SAFETY_SECONDS = 300;

    /**
     * @param array<string, mixed> $file Normalized Google Files resource.
     * @param array<string, mixed> $binding Request ownership values.
     * @return array{token:string,expires_at:int}|WP_Error
     */
    public static function issue(array $file, array $binding)
    {
        $file_name = GoogleFilesUrlBuilder::normalize_file_name((string) ($file['name'] ?? ''));
        $file_uri = isset($file['uri']) && is_string($file['uri']) ? trim($file['uri']) : '';
        $mime_type = sanitize_mime_type((string) ($file['mime_type'] ?? ''));
        if (is_wp_error($file_name) || $file_uri === '' || $mime_type === '') {
            return new WP_Error(
                'google_file_context_invalid_resource',
                __('A valid Google file is required to create chat context.', 'gpt3-ai-content-generator'),
                ['status' => 500]
            );
        }

        $normalized_binding = self::normalize_binding($binding);
        if (is_wp_error($normalized_binding)) {
            return $normalized_binding;
        }

        $issued_at = time();
        $provider_expiry = self::parse_expiration_time((string) ($file['expiration_time'] ?? ''));
        if ($provider_expiry <= $issued_at) {
            $provider_expiry = $issued_at + self::PROVIDER_LIFETIME_SECONDS;
        }
        $expires_at = min(
            $provider_expiry - self::EXPIRY_SAFETY_SECONDS,
            $issued_at + self::MAX_LOCAL_LIFETIME_SECONDS
        );
        if ($expires_at <= $issued_at) {
            return new WP_Error(
                'google_file_context_already_expired',
                __('Google returned an expired temporary file.', 'gpt3-ai-content-generator'),
                ['status' => 410]
            );
        }

        $payload = [
            'v' => self::VERSION,
            'file_name' => $file_name,
            'file_uri' => $file_uri,
            'mime_type' => $mime_type,
            'original_filename' => sanitize_file_name((string) ($binding['original_filename'] ?? ($file['display_name'] ?? 'document'))),
            'bot_id' => $normalized_binding['bot_id'],
            'conversation_uuid' => $normalized_binding['conversation_uuid'],
            'owner' => $normalized_binding['owner'],
            'issued_at' => $issued_at,
            'expires_at' => $expires_at,
        ];
        $encoded_payload = wp_json_encode($payload);
        if (!is_string($encoded_payload)) {
            return new WP_Error(
                'google_file_context_encode_error',
                __('Could not create Google file context.', 'gpt3-ai-content-generator'),
                ['status' => 500]
            );
        }

        $payload_part = self::base64url_encode($encoded_payload);
        $signature_part = self::base64url_encode(hash_hmac('sha256', $payload_part, self::secret(), true));
        return [
            'token' => $payload_part . '.' . $signature_part,
            'expires_at' => $expires_at,
        ];
    }

    /**
     * @param array<string, mixed> $binding Current request ownership values.
     * @return array<string, mixed>|WP_Error
     */
    public static function verify(string $token, array $binding)
    {
        if ($token === '' || strlen($token) > 4096 || substr_count($token, '.') !== 1) {
            return self::invalid_token_error();
        }
        [$payload_part, $signature_part] = explode('.', $token, 2);
        $supplied_signature = self::base64url_decode($signature_part);
        if ($supplied_signature === null) {
            return self::invalid_token_error();
        }
        $expected_signature = hash_hmac('sha256', $payload_part, self::secret(), true);
        if (!hash_equals($expected_signature, $supplied_signature)) {
            return self::invalid_token_error();
        }

        $decoded_payload = self::base64url_decode($payload_part);
        if ($decoded_payload === null) {
            return self::invalid_token_error();
        }
        $payload = json_decode($decoded_payload, true);
        if (!is_array($payload) || json_last_error() !== JSON_ERROR_NONE || (int) ($payload['v'] ?? 0) !== self::VERSION) {
            return self::invalid_token_error();
        }

        $normalized_binding = self::normalize_binding($binding);
        if (is_wp_error($normalized_binding)) {
            return $normalized_binding;
        }
        if (
            (int) ($payload['bot_id'] ?? 0) !== $normalized_binding['bot_id']
            || (string) ($payload['conversation_uuid'] ?? '') !== $normalized_binding['conversation_uuid']
            || (string) ($payload['owner'] ?? '') !== $normalized_binding['owner']
        ) {
            return new WP_Error(
                'google_file_context_owner_mismatch',
                __('This temporary Google file does not belong to the current chat session.', 'gpt3-ai-content-generator'),
                ['status' => 403]
            );
        }

        $expires_at = (int) ($payload['expires_at'] ?? 0);
        if ($expires_at <= time()) {
            return new WP_Error(
                'google_file_context_expired',
                __('This Google file attachment has expired. Please upload it again.', 'gpt3-ai-content-generator'),
                ['status' => 410]
            );
        }

        $file_name = GoogleFilesUrlBuilder::normalize_file_name((string) ($payload['file_name'] ?? ''));
        $file_uri = isset($payload['file_uri']) && is_string($payload['file_uri']) ? trim($payload['file_uri']) : '';
        $mime_type = sanitize_mime_type((string) ($payload['mime_type'] ?? ''));
        if (is_wp_error($file_name) || $file_uri === '' || $mime_type === '') {
            return self::invalid_token_error();
        }
        $payload['file_name'] = $file_name;
        $payload['file_uri'] = $file_uri;
        $payload['mime_type'] = $mime_type;
        $payload['original_filename'] = sanitize_file_name((string) ($payload['original_filename'] ?? 'document'));
        return $payload;
    }

    /**
     * @param array<string, mixed> $payload Verified token payload.
     * @return array{type:string,uri:string,mime_type:string}
     */
    public static function document_input(array $payload): array
    {
        return [
            'type' => 'document',
            'uri' => (string) $payload['file_uri'],
            'mime_type' => (string) $payload['mime_type'],
        ];
    }

    /**
     * @param array<string, mixed> $binding
     * @return array{bot_id:int,conversation_uuid:string,owner:string}|WP_Error
     */
    private static function normalize_binding(array $binding)
    {
        $bot_id = absint($binding['bot_id'] ?? 0);
        $conversation_uuid = sanitize_key((string) ($binding['conversation_uuid'] ?? ''));
        $user_id = absint($binding['user_id'] ?? 0);
        $session_id = sanitize_text_field((string) ($binding['session_id'] ?? ''));
        if ($bot_id < 1 || $conversation_uuid === '') {
            return new WP_Error(
                'google_file_context_missing_chat',
                __('A chatbot and conversation are required for Google file context.', 'gpt3-ai-content-generator'),
                ['status' => 400]
            );
        }
        if ($user_id > 0) {
            $owner = 'user:' . $user_id;
        } elseif ($session_id !== '') {
            $owner = 'guest:' . hash('sha256', $session_id);
        } else {
            return new WP_Error(
                'google_file_context_missing_owner',
                __('A valid chat session is required for Google file context.', 'gpt3-ai-content-generator'),
                ['status' => 400]
            );
        }
        return [
            'bot_id' => $bot_id,
            'conversation_uuid' => $conversation_uuid,
            'owner' => $owner,
        ];
    }

    private static function parse_expiration_time(string $expiration_time): int
    {
        if ($expiration_time === '') {
            return 0;
        }
        $parsed = strtotime($expiration_time);
        return $parsed === false ? 0 : (int) $parsed;
    }

    private static function secret(): string
    {
        return wp_salt('auth') . '|aipkit-google-files-context-v1';
    }

    private static function base64url_encode(string $value): string
    {
        return rtrim(strtr(base64_encode($value), '+/', '-_'), '=');
    }

    private static function base64url_decode(string $value): ?string
    {
        if ($value === '' || !preg_match('/^[A-Za-z0-9_-]+$/', $value)) {
            return null;
        }
        $padding = strlen($value) % 4;
        if ($padding !== 0) {
            $value .= str_repeat('=', 4 - $padding);
        }
        $decoded = base64_decode(strtr($value, '-_', '+/'), true);
        return is_string($decoded) ? $decoded : null;
    }

    private static function invalid_token_error(): WP_Error
    {
        return new WP_Error(
            'google_file_context_invalid',
            __('The Google file attachment is invalid. Please upload it again.', 'gpt3-ai-content-generator'),
            ['status' => 400]
        );
    }
}
