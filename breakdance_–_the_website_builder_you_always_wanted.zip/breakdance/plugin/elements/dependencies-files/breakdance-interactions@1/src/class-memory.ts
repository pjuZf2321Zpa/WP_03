/*
 * Class changes made by interactions, remembered per element.
 *
 * In the builder canvas the elements are rendered by Vue, which rewrites an
 * element's whole class attribute whenever its own class list changes (for
 * example when the element is selected). That would silently drop the classes
 * an interaction added and bring back the ones it removed. So, inside the
 * builder, every element touched by these helpers is watched and the
 * remembered changes are reapplied after any outside rewrite. The classes an
 * interaction added are also published on the element as the
 * data-interaction-classes attribute, which the builder reads to list them in
 * the class dropdown. On the frontend nothing rewrites class attributes behind
 * our back and nothing reads the attribute, so neither is set up there.
 */

export const INTERACTION_CLASSES_ATTRIBUTE = "data-interaction-classes";

type ClassMemory = {
  added: Set<string>;
  removed: Set<string>;
};

const memory = new WeakMap<HTMLElement, ClassMemory>();

let observer: MutationObserver | null = null;

function isInsideBuilderCanvas() {
  return !!document.getElementById("breakdance_canvas");
}

function restoreRememberedClasses(target: HTMLElement) {
  const remembered = memory.get(target);
  if (!remembered) return;

  remembered.added.forEach(className => {
    if (!target.classList.contains(className)) target.classList.add(className);
  });

  remembered.removed.forEach(className => {
    if (target.classList.contains(className)) target.classList.remove(className);
  });
}

function publishAddedClasses(target: HTMLElement, remembered: ClassMemory) {
  if (!isInsideBuilderCanvas()) return;

  if (remembered.added.size) {
    target.setAttribute(
      INTERACTION_CLASSES_ATTRIBUTE,
      Array.from(remembered.added).join(" ")
    );
  } else {
    target.removeAttribute(INTERACTION_CLASSES_ATTRIBUTE);
  }
}

function watch(target: HTMLElement) {
  if (!observer) {
    observer = new MutationObserver(records => {
      records.forEach(record => restoreRememberedClasses(record.target as HTMLElement));
    });
  }

  observer.observe(target, { attributes: true, attributeFilter: ["class"] });
}

function getMemory(target: HTMLElement): ClassMemory {
  let remembered = memory.get(target);

  if (!remembered) {
    remembered = { added: new Set(), removed: new Set() };
    memory.set(target, remembered);

    if (isInsideBuilderCanvas()) watch(target);
  }

  return remembered;
}

export function addClassToElement(target: HTMLElement, className: string) {
  const remembered = getMemory(target);

  if (remembered.removed.has(className)) {
    remembered.removed.delete(className);
  } else if (!target.classList.contains(className)) {
    remembered.added.add(className);
  }

  target.classList.add(className);
  publishAddedClasses(target, remembered);
}

export function removeClassFromElement(target: HTMLElement, className: string) {
  const remembered = getMemory(target);

  if (remembered.added.has(className)) {
    remembered.added.delete(className);
  } else if (target.classList.contains(className)) {
    remembered.removed.add(className);
  }

  target.classList.remove(className);
  publishAddedClasses(target, remembered);
}

export function toggleClassOnElement(target: HTMLElement, className: string) {
  if (target.classList.contains(className)) {
    removeClassFromElement(target, className);
  } else {
    addClassToElement(target, className);
  }
}
