<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Core\Util\Hooks;
use BitApps\IntegrationsPro\Triggers\Charitable\CharitableController;

Hooks::add('charitable_after_save_donation', [CharitableController::class, 'handleDonationCreated'], 20, 1);
Hooks::add('charitable_donation_save', [CharitableController::class, 'handleDonationUpdated'], 20, 1);
Hooks::add('transition_post_status', [CharitableController::class, 'handleDonationStatusTransition'], 20, 3);
Hooks::add('charitable_campaign_processor_save_core', [CharitableController::class, 'handleCampaignSaveCore'], 20, 2);
Hooks::add('charitable_builder_save_campaign', [CharitableController::class, 'handleCampaignSavedInBuilder'], 20, 4);
Hooks::add('charitable_campaign_end', [CharitableController::class, 'handleCampaignEnded'], 20, 1);
Hooks::add('charitable_after_insert_donor', [CharitableController::class, 'handleDonorCreated'], 20, 1);
Hooks::add('charitable_donor_contact_consent_changed', [CharitableController::class, 'handleDonorConsentChanged'], 20, 3);
Hooks::add('charitable_after_insert_user', [CharitableController::class, 'handleUserCreated'], 20, 2);
Hooks::add('charitable_after_save_user', [CharitableController::class, 'handleUserUpdated'], 20, 2);
Hooks::add('charitable_user_verified', [CharitableController::class, 'handleUserVerified'], 20, 1);
Hooks::add('charitable_profile_updated', [CharitableController::class, 'handleProfileUpdated'], 20, 1);
