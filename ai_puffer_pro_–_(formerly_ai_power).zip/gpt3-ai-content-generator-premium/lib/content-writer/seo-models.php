<?php

namespace WPAICG\ContentWriter\SEO;

use WPAICG\AIPKit_Providers;
use WPAICG\Core\AIPKit_AI_Caller;
use WP_Error;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Chooses Smart SEO revision models independently from the main content model.
 */
class AIPKit_Content_Writer_Smart_SEO_Model_Policy
{
    /**
     * @return array|WP_Error
     */
    public static function make_standard_call(
        AIPKit_AI_Caller $ai_caller,
        string $provider,
        string $selected_model,
        array $messages,
        array $ai_params_override = [],
        ?string $base_system_instruction = null,
        array $instruction_context = []
    ) {
        $provider = self::normalize_provider($provider);
        $selected_model = sanitize_text_field($selected_model);
        if ($provider === '' || $selected_model === '') {
            return new WP_Error(
                'missing_smart_seo_model_policy_input',
                __('AI provider and model are required for Smart SEO improvement.', 'gpt3-ai-content-generator')
            );
        }

        $candidates = self::get_candidate_models($provider, $selected_model);
        if (empty($candidates)) {
            $candidates = [[
                'provider' => $provider,
                'model' => $selected_model,
                'source' => 'selected_model',
            ]];
        }

        $attempts = [];
        $last_error = null;
        foreach ($candidates as $candidate) {
            $candidate_provider = self::normalize_provider((string) ($candidate['provider'] ?? $provider));
            $candidate_model = sanitize_text_field((string) ($candidate['model'] ?? ''));
            if ($candidate_provider === '' || $candidate_model === '') {
                continue;
            }

            $candidate_ai_params = self::normalize_ai_params_for_candidate($candidate_provider, $candidate_model, $ai_params_override);
            $result = $ai_caller->make_standard_call(
                $candidate_provider,
                $candidate_model,
                $messages,
                $candidate_ai_params,
                $base_system_instruction,
                $instruction_context
            );

            if (!is_wp_error($result)) {
                $result['smart_seo_model'] = [
                    'provider' => $candidate_provider,
                    'model' => $candidate_model,
                    'source' => sanitize_key((string) ($candidate['source'] ?? 'smart_seo_policy')),
                ];
                if (!empty($attempts)) {
                    $result['smart_seo_model_fallbacks'] = $attempts;
                }
                return $result;
            }

            $attempts[] = self::format_failed_attempt($candidate_provider, $candidate_model, $result);
            $last_error = $result;
            if (!self::is_retryable_model_error($result)) {
                break;
            }
        }

        if ($last_error instanceof WP_Error) {
            $error_data = $last_error->get_error_data();
            $error_data = is_array($error_data) ? $error_data : [];
            $error_data['smart_seo_model_fallbacks'] = $attempts;
            $last_error->add_data($error_data);
            return $last_error;
        }

        return new WP_Error(
            'smart_seo_model_policy_no_candidates',
            __('No Smart SEO model candidate could be used.', 'gpt3-ai-content-generator'),
            ['smart_seo_model_fallbacks' => $attempts]
        );
    }

    /**
     * @return array<int, array{provider:string,model:string,source:string}>
     */
    public static function get_candidate_models(string $provider, string $selected_model = ''): array
    {
        $provider = self::normalize_provider($provider);
        $selected_model = sanitize_text_field($selected_model);
        if ($provider === '') {
            return [];
        }

        $candidate_models = self::get_catalog_models($provider);

        /**
         * Filters Smart SEO model candidates for a provider.
         *
         * @param array<int, string> $candidate_models Candidate model ids.
         * @param string             $provider         Normalized provider name.
         * @param string             $selected_model   User-selected model.
         */
        $candidate_models = apply_filters(
            'aipkit_smart_seo_model_candidates',
            $candidate_models,
            $provider,
            $selected_model
        );
        $candidate_models = is_array($candidate_models) ? $candidate_models : [];

        $candidate_models = self::normalize_model_id_list($candidate_models);
        $selected_key = self::model_key($selected_model);
        $approved_lookup = [];
        foreach ($candidate_models as $candidate_model) {
            $approved_lookup[self::model_key($candidate_model)] = $candidate_model;
        }
        $ordered = [];
        $seen = [];

        if ($selected_model !== '' && isset($approved_lookup[$selected_key])) {
            $ordered[] = [
                'provider' => $provider,
                'model' => $approved_lookup[$selected_key],
                'source' => 'selected_smart_seo_model',
            ];
            $seen[$selected_key] = true;
        }

        foreach ($candidate_models as $candidate_model) {
            $candidate_key = self::model_key($candidate_model);
            if ($candidate_key === '' || isset($seen[$candidate_key])) {
                continue;
            }
            $ordered[] = [
                'provider' => $provider,
                'model' => $candidate_model,
                'source' => 'smart_seo_recommended',
            ];
            $seen[$candidate_key] = true;
        }

        if ($selected_model !== '' && !isset($seen[$selected_key])) {
            $ordered[] = [
                'provider' => $provider,
                'model' => $selected_model,
                'source' => 'selected_fallback',
            ];
        }

        return $ordered;
    }

    /**
     * @return array<int, string>
     */
    private static function get_catalog_models(string $provider): array
    {
        if (class_exists(AIPKit_Providers::class)) {
            $recommended = AIPKit_Providers::get_recommended_models($provider);
            return self::normalize_model_id_list($recommended);
        }

        return [];
    }

    /**
     * @param mixed $models
     * @return array<int, string>
     */
    private static function normalize_model_id_list($models): array
    {
        if (!is_array($models)) {
            return [];
        }

        $normalized = [];
        $seen = [];
        foreach ($models as $model) {
            if (is_string($model)) {
                $model_id = sanitize_text_field($model);
            } elseif (is_array($model)) {
                $model_id = sanitize_text_field((string) ($model['id'] ?? $model['model'] ?? ''));
            } else {
                $model_id = '';
            }

            $model_key = self::model_key($model_id);
            if ($model_key === '' || isset($seen[$model_key])) {
                continue;
            }

            $normalized[] = $model_id;
            $seen[$model_key] = true;
        }

        return $normalized;
    }

    private static function is_retryable_model_error(WP_Error $error): bool
    {
        $code = sanitize_key($error->get_error_code());
        if (in_array($code, [
            'missing_api_key',
            'missing_azure_endpoint',
            'internal_error_instruction_manager',
            'json_decode_error',
        ], true)) {
            return false;
        }

        $data = $error->get_error_data();
        $data = is_array($data) ? $data : [];
        $status_code = isset($data['status_code']) ? absint($data['status_code']) : absint($data['status'] ?? 0);
        $message = strtolower($error->get_error_message() . ' ' . (string) ($data['response_body_for_debug'] ?? ''));

        if ($code === 'http_request_failed') {
            foreach (['timed out', 'timeout', 'curl error 28', 'operation timed out', 'deadline', 'temporarily', 'overloaded'] as $retryable_transport_signal) {
                if (strpos($message, $retryable_transport_signal) !== false) {
                    return true;
                }
            }

            return $status_code >= 500 && $status_code < 600;
        }

        foreach (['quota', 'billing', 'insufficient_quota', 'invalid api key', 'api key is missing', 'content policy', 'safety'] as $non_retryable) {
            if (strpos($message, $non_retryable) !== false) {
                return false;
            }
        }

        foreach ([
            'model',
            'does not exist',
            'not found',
            'not available',
            'unavailable',
            'unsupported',
            'access',
            'permission',
            'verification',
            'organization',
            'project',
            'tier',
            'plan',
            'rate limit',
            'overloaded',
            'temporarily',
        ] as $retryable_signal) {
            if (strpos($message, $retryable_signal) !== false) {
                return true;
            }
        }

        if ($status_code === 404) {
            return true;
        }

        if ($status_code >= 500 && $status_code < 600) {
            return true;
        }

        return false;
    }

    private static function normalize_ai_params_for_candidate(string $provider, string $model, array $params): array
    {
        if (self::candidate_disallows_temperature($provider, $model)) {
            unset($params['temperature']);
        }

        return $params;
    }

    private static function candidate_disallows_temperature(string $provider, string $model): bool
    {
        $provider = self::normalize_provider($provider);
        $model_key = self::model_key($model);

        if ($provider === 'Claude' && preg_match('/^claude-(opus|sonnet)-4/i', $model_key)) {
            return true;
        }

        if ($provider === 'OpenRouter' && preg_match('#^anthropic/claude-(opus|sonnet)-4#i', $model_key)) {
            return true;
        }

        return false;
    }

    /**
     * @return array{provider:string,model:string,error_code:string,message:string}
     */
    private static function format_failed_attempt(string $provider, string $model, WP_Error $error): array
    {
        return [
            'provider' => $provider,
            'model' => $model,
            'error_code' => sanitize_key($error->get_error_code()),
            'message' => sanitize_text_field($error->get_error_message()),
        ];
    }

    private static function normalize_provider(string $provider): string
    {
        return AIPKit_Providers::normalize_provider_label($provider);
    }

    private static function model_key(string $model): string
    {
        return strtolower(trim($model));
    }
}
