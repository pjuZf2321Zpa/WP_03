<?php

defined('ABSPATH') || exit;

/**
 * Builds the order quote for a checkout state.
 *
 * The builder consumes the prepared transactions AFTER coupon math and
 * produces one MeprOrderQuote for the basket. Under automatic tax, the
 * quote is priced through the Stripe surface that mirrors the charging
 * surface; the rate-based engine wraps the figures the central tax
 * pipeline already put on the prepared transactions, byte-for-byte
 * identical to shipped output. Every pre-charge surface reads the
 * quote's totals, and the submit stage applies its lines to the stored
 * rows, so one derivation serves display, charge, books, and filing.
 */
final class MeprOrderQuoteBuilder
{
    /**
     * The internal reference assigned to the preview's subscription
     * anchor line when the anchor carries no basket money (trial and
     * free-trial mains). Its 0.00 line is part of the invoice's shape,
     * not a priced component, so lines wearing this reference are
     * skipped. It is assigned on the response side by line type: a
     * subscription-sourced line cannot carry request metadata.
     *
     * @var string
     */
    const SUB_ANCHOR_REFERENCE = 'mepr_sub_anchor';

    /**
     * Price a submitted order and apply the result in one motion.
     *
     * This is the committing path: it prices the order fresh, then lands
     * the quote's lines on the given instances and their stored rows
     * before returning, so every later read, charge, and store in the
     * request sees the applied figures. A pricing failure propagates from
     * the build, so the attempt aborts rather than charging a number no
     * surface displayed. The stored bump transactions are wrapped into
     * pairs once, and the same pairs feed the build and the application,
     * so build/apply pairing cannot drift apart at a call site.
     *
     * @param  MeprTransaction       $txn               The main transaction.
     * @param  MeprSubscription|null $sub               The main's subscription when recurring.
     * @param  MeprTransaction[]     $bump_transactions The stored order-bump transactions.
     * @return MeprOrderQuote|null Null when the basket has no priceable component.
     * @throws Exception When pricing fails (the attempt aborts).
     */
    public function price_order(MeprTransaction $txn, ?MeprSubscription $sub, array $bump_transactions): ?MeprOrderQuote
    {
        $order_bumps = $this->order_bump_entries($bump_transactions);
        $quote       = $this->build_quote($txn, $sub, $order_bumps);

        if ($quote instanceof MeprOrderQuote) {
            $this->apply_to_state($quote, $txn, $sub, $order_bumps);
            $this->commit_applied_state($quote, $txn, $sub, $order_bumps);
        }

        return $quote;
    }

    /**
     * Build the preview quote for a checkout state.
     *
     * Preview pricing is the cached, fail-open policy bundle. An
     * unchanged state is served from a one-hour cache, keyed by the
     * fingerprints and salted with the plugin version; the pricing
     * account rides the customer fingerprint, because a quote belongs
     * to the account that priced it. A cached payload that does not
     * rehydrate is a miss by construction. Any pricing
     * failure degrades the quote to the rate-based wrap of the prepared
     * figures, logged, so a render never blocks. Lines carry
     * product-positional references.
     *
     * @param  MeprTransaction       $txn         The main prepared transaction.
     * @param  MeprSubscription|null $sub         The main's subscription when recurring.
     * @param  array                 $order_bumps The order bumps ([transaction, subscription] pairs).
     * @return MeprOrderQuote|null Null when the basket has no priceable component.
     */
    public function build_preview_quote(MeprTransaction $txn, ?MeprSubscription $sub = null, array $order_bumps = []): ?MeprOrderQuote
    {
        $components = $this->state_components($txn, $sub, $order_bumps);

        if (empty($components)) {
            return null;
        }

        $gateway              = $this->pricing_gateway($txn);
        $usr                  = $txn->user();
        $basket_fingerprint   = $this->basket_fingerprint($components);
        $customer_fingerprint = $this->customer_fingerprint($usr, $gateway);

        if ($this->uses_stripe_engine() && $gateway instanceof MeprStripeGateway) {
            $cache_key = $this->preview_cache_key($basket_fingerprint, $customer_fingerprint);
            $cached    = get_transient($cache_key);

            if (is_array($cached)) {
                $quote = MeprOrderQuote::from_array($cached);

                if ($quote instanceof MeprOrderQuote) {
                    return $quote;
                }
            }

            try {
                $quote = $this->attempt_stripe_quote($gateway, $components, $usr, $sub, MeprOrderQuote::STAGE_PREVIEW, $basket_fingerprint, $customer_fingerprint);

                if ($quote instanceof MeprOrderQuote) {
                    set_transient($cache_key, $quote->to_array(), HOUR_IN_SECONDS);

                    return $quote;
                }
            } catch (Exception $e) {
                // Previews fail open: the rate-based wrap below keeps
                // the render coherent, never mixing engines on one page.
            }
        }

        return $this->build_rate_based_quote($components, MeprOrderQuote::STAGE_PREVIEW, $basket_fingerprint, $customer_fingerprint);
    }

    /**
     * Drop the cached render quote for a priced basket.
     *
     * A submission whose fresh total differs from the amount the client
     * mounted bounces, and the form answers by refreshing its checkout
     * state. That refresh re-renders through the preview cache, so the
     * cached quote is dropped first and the refresh prices fresh; the
     * mount then agrees with what the next submission charges. The submit
     * quote identifies the render's entry, because both fingerprints
     * cover the priced state rather than row identity.
     *
     * @param MeprOrderQuote $quote The submit quote whose basket to forget.
     */
    public function forget_preview_quote(MeprOrderQuote $quote): void
    {
        delete_transient($this->preview_cache_key($quote->basket_fingerprint, $quote->customer_fingerprint));
    }

    /**
     * Build the submit quote for a submitted order.
     *
     * Submission pricing is the fresh, fail-closed policy bundle. The
     * quote always prices fresh, because its calculation becomes the
     * charge's attachment and filing source and is never shared across
     * users or orders; the preview cooldown never short-circuits it. A
     * Stripe pricing failure throws, so the attempt aborts rather than
     * charging a number no surface displayed. Lines carry persistent
     * references, so every priced row must be stored.
     *
     * @param  MeprTransaction       $txn         The main stored transaction.
     * @param  MeprSubscription|null $sub         The main's subscription when recurring.
     * @param  array                 $order_bumps The order bumps ([transaction, subscription] pairs).
     * @return MeprOrderQuote|null Null when the basket has no priceable component.
     * @throws Exception When pricing fails (the attempt aborts).
     */
    public function build_quote(MeprTransaction $txn, ?MeprSubscription $sub = null, array $order_bumps = []): ?MeprOrderQuote
    {
        $components = $this->state_components($txn, $sub, $order_bumps);

        if (empty($components)) {
            return null;
        }

        $gateway              = $this->pricing_gateway($txn);
        $usr                  = $txn->user();
        $basket_fingerprint   = $this->basket_fingerprint($components);
        $customer_fingerprint = $this->customer_fingerprint($usr, $gateway);

        if ($this->uses_stripe_engine() && $gateway instanceof MeprStripeGateway) {
            // No catch: a pricing failure propagates, so the attempt
            // aborts rather than charging a number no surface displayed.
            $quote = $this->attempt_stripe_quote($gateway, $components, $usr, $sub, MeprOrderQuote::STAGE_SUBMIT, $basket_fingerprint, $customer_fingerprint);

            if ($quote instanceof MeprOrderQuote) {
                return $quote;
            }
        }

        return $this->build_rate_based_quote($components, MeprOrderQuote::STAGE_SUBMIT, $basket_fingerprint, $customer_fingerprint);
    }

    /**
     * Attempt the Stripe pricing for a basket, with the shared failure
     * consequences.
     *
     * The one-minute cooldown gates preview attempts: while it is armed a
     * preview attempt is skipped (null), so a failing account is not retried
     * on every render. A submission always prices fresh and is never skipped,
     * because its calculation is the charge's filing source. A pricing failure
     * routes through the integration's deactivation policy, arms the cooldown,
     * logs, and rethrows; each caller decides whether the failure degrades
     * (preview) or aborts (submission). A priced quote clears the cooldown,
     * because a successful call falsifies the premise that the account is
     * failing.
     *
     * While the cooldown is armed, previews render rate-based figures while
     * submissions still price through Stripe. The ajax gateways'
     * mount-context gate rejects a submit whose displayed figures no longer
     * match, and the subscription and hosted paths reconcile the stored
     * rows from the charged invoice or session.
     *
     * @param  MeprStripeGateway         $gateway              The gateway pricing the basket.
     * @param  MeprOrderQuoteComponent[] $components           The basket components.
     * @param  MeprUser                  $usr                  The purchasing user.
     * @param  MeprSubscription|null     $sub                  The main's subscription when recurring (the surface selector).
     * @param  string                    $stage                The quote stage.
     * @param  string                    $basket_fingerprint   The basket fingerprint.
     * @param  string                    $customer_fingerprint The customer fingerprint.
     * @return MeprOrderQuote|null Null when the cooldown is armed or no Stripe surface can price the basket.
     * @throws Exception When a Stripe pricing request fails.
     */
    private function attempt_stripe_quote(MeprStripeGateway $gateway, array $components, MeprUser $usr, ?MeprSubscription $sub, string $stage, string $basket_fingerprint, string $customer_fingerprint): ?MeprOrderQuote
    {
        $cooldown = 'mepr_order_quote_cooldown_' . md5(wp_json_encode([$basket_fingerprint, $customer_fingerprint]));

        // The cooldown spares the hot preview path from retrying a failing
        // account on every render. A submission always prices fresh, because
        // its calculation is the charge's attachment and filing source, so it
        // is never skipped.
        if ($stage !== MeprOrderQuote::STAGE_SUBMIT && get_transient($cooldown)) {
            return null;
        }

        try {
            $quote = $this->build_stripe_quote($gateway, $components, $usr, $sub, $stage, $basket_fingerprint, $customer_fingerprint);

            // A priced quote falsifies the cooldown's premise that the
            // account is failing, so renders stop degrading the moment
            // Stripe answers again rather than at the end of the minute.
            if ($quote instanceof MeprOrderQuote) {
                delete_transient($cooldown);
            }

            return $quote;
        } catch (Exception $e) {
            // The integration owns the deactivation policy; the cooldown
            // keeps the hot checkout path from retrying a failing
            // account on every render.
            MeprStripeTaxIntegration::deactivate_on_inactive_account($e);
            set_transient($cooldown, 1, MINUTE_IN_SECONDS);
            MeprUtils::debug_log('stripe-tax-quote-failed: ' . $e->getMessage());

            throw $e;
        }
    }

    /**
     * Apply a quote's lines to the checkout state they priced.
     *
     * The enumeration mirrors {@see self::state_components()}, so every
     * priced component meets its own line, which applies itself to the
     * component's rows: the very instances the caller passed, so every
     * later read or store in the request sees the applied figures. A
     * saved row stores what was written, whatever the quote's stage
     * (the hosted session path applies a preview quote to saved rows,
     * with the trial trio storing on a trial line's subscription); an
     * unsaved preview row is only mutated in memory. A component
     * without a line (a fail-open quote built from a partially changed
     * state) is skipped, never fatal.
     *
     * A free-trial component charges nothing now, so the quote prices
     * no line for it; its row would otherwise keep the recurring price
     * until a webhook bakes the confirmation. The second pass stamps
     * the trial charge (0.00) onto such rows at submission, so every
     * row carries its first-period charge from birth and the
     * pre-webhook display never shows the recurring figure.
     *
     * @param  MeprOrderQuote        $quote       The quote priced from this state.
     * @param  MeprTransaction       $txn         The main prepared transaction.
     * @param  MeprSubscription|null $sub         The main's subscription when recurring.
     * @param  array                 $order_bumps The order bumps ([transaction, subscription] pairs).
     * @return void
     */
    public function apply_to_state(MeprOrderQuote $quote, MeprTransaction $txn, ?MeprSubscription $sub = null, array $order_bumps = []): void
    {
        foreach ($this->state_components($txn, $sub, $order_bumps) as $component) {
            $line = $quote->lines[$component->line_reference($quote->stage)] ?? null;

            if (!$line instanceof MeprOrderQuoteLine) {
                continue;
            }

            $line->apply_to($component->transaction, $component->subscription);
        }

        foreach (array_merge([[$txn, $sub]], $order_bumps) as $pair) {
            list($transaction, $subscription) = $pair;

            if (
                !$subscription instanceof MeprSubscription
                || !$subscription->trial
                || $subscription->trial_days <= 0
                || (float) $subscription->trial_total > 0.00
            ) {
                continue;
            }

            $transaction->apply_amount_breakdown($subscription->first_period_breakdown());
        }
    }

    /**
     * Store the state a quote was applied to.
     *
     * Applying a quote and committing it are separate concerns. A render and
     * a preview apply figures to instances they only display, while a
     * submission owns the charge and stores what it charged. The committing
     * wrapper is the only caller, so no display path reaches this method.
     *
     * Rows born unsaved are left alone because the flow that creates them
     * stores them once it has an order to attach them to.
     *
     * @param  MeprOrderQuote        $quote       The quote that was applied.
     * @param  MeprTransaction       $txn         The main transaction.
     * @param  MeprSubscription|null $sub         The main's subscription when recurring.
     * @param  array                 $order_bumps The order bumps ([transaction, subscription] pairs).
     * @return void
     */
    private function commit_applied_state(MeprOrderQuote $quote, MeprTransaction $txn, ?MeprSubscription $sub = null, array $order_bumps = []): void
    {
        foreach ($this->state_components($txn, $sub, $order_bumps) as $component) {
            $line = $quote->lines[$component->line_reference($quote->stage)] ?? null;

            if (!$line instanceof MeprOrderQuoteLine) {
                continue;
            }

            if ($component->transaction->id > 0) {
                $component->transaction->store();
            }

            if (
                $line->kind === MeprOrderQuoteLine::KIND_TRIAL_CHARGE
                && $component->subscription instanceof MeprSubscription
                && $component->subscription->id > 0
            ) {
                $component->subscription->store();
            }
        }

        foreach (array_merge([[$txn, $sub]], $order_bumps) as $pair) {
            list($transaction, $subscription) = $pair;

            if (
                !$subscription instanceof MeprSubscription
                || !$subscription->trial
                || $subscription->trial_days <= 0
                || (float) $subscription->trial_total > 0.00
                || $transaction->id <= 0
            ) {
                continue;
            }

            $transaction->store();
        }
    }

    /**
     * Wrap stored order-bump transactions into the [transaction,
     * subscription] pairs the builder consumes, resolving each
     * recurring row's subscription. The given instances ride into the
     * pairs unchanged, so applying a quote writes through the objects
     * the caller keeps using. A recurring row without a subscription is
     * dropped, a shape the checkout flows never produce.
     *
     * @param  MeprTransaction[] $transactions The stored bump transactions.
     * @return array<int,array{MeprTransaction,MeprSubscription|null}>
     */
    private function order_bump_entries(array $transactions): array
    {
        $entries = [];

        foreach ($transactions as $transaction) {
            if (!$transaction instanceof MeprTransaction) {
                continue;
            }

            if ($transaction->is_one_time_payment()) {
                $entries[] = [$transaction, null];

                continue;
            }

            $subscription = $transaction->subscription();

            if ($subscription instanceof MeprSubscription) {
                $entries[] = [$transaction, $subscription];
            }
        }

        return $entries;
    }

    /**
     * Whether the stripe-automatic engine prices quotes: the same option
     * pair as MeprStripeGateway::use_automatic_tax().
     *
     * @return boolean
     */
    private function uses_stripe_engine(): bool
    {
        return get_option('mepr_calculate_taxes') && get_option('mepr_tax_stripe_enabled');
    }

    /**
     * Build the stripe-automatic quote through the surface that mirrors
     * the charging surface.
     *
     * The MAIN product decides the surface, exactly as it decides the
     * charging mode: a subscription main's basket charges on its first
     * invoice, so its quote prices through an invoice preview (free); a
     * one-time main's basket charges on a bare PaymentIntent, so its
     * quote prices through a tax calculation. The customer details carry
     * the VAT tax ID exactly as every charging surface does, so B2B
     * reverse-charge baskets quote what they will be charged.
     *
     * @param  MeprStripeGateway         $gateway              The gateway pricing the basket.
     * @param  MeprOrderQuoteComponent[] $components           The basket components.
     * @param  MeprUser                  $usr                  The purchasing user.
     * @param  MeprSubscription|null     $main_sub             The main's subscription when recurring.
     * @param  string                    $stage                The quote stage.
     * @param  string                    $basket_fingerprint   The basket fingerprint.
     * @param  string                    $customer_fingerprint The customer fingerprint.
     * @return MeprOrderQuote|null Null when no Stripe surface can price the basket.
     * @throws MeprRemoteException When the API returns an error or the response cannot price every line.
     * @throws MeprHttpException When an HTTP request to Stripe fails.
     */
    private function build_stripe_quote(MeprStripeGateway $gateway, array $components, MeprUser $usr, ?MeprSubscription $main_sub, string $stage, string $basket_fingerprint, string $customer_fingerprint): ?MeprOrderQuote
    {
        $address = $usr->tax_address();

        if ($address === null || !preg_match('/^[A-Z][A-Z]$/', (string) ($address['country'] ?? ''))) {
            // A checkout without a priceable address is the normal
            // pre-input state (the customer has not typed one yet), so
            // it falls back silently: the rate-based wrap prices the
            // same no-address figures the central tax pipeline
            // prepared, and the entered address re-prices via the
            // customer fingerprint.
            return null;
        }

        // The two surfaces share the address and tax ids, but only the
        // calculations schema accepts address_source; the invoice
        // preview's customer_details rejects it, so the calculations
        // surface adds it itself.
        $customer_details = [
            'address' => $address,
        ];

        $tax_id = $gateway->get_customer_tax_id_data($usr);

        if ($tax_id !== null) {
            $customer_details['tax_ids'] = [$tax_id];
        }

        return $main_sub instanceof MeprSubscription
            ? $this->quote_from_invoice_preview($gateway, $components, $customer_details, $main_sub, $stage, $basket_fingerprint, $customer_fingerprint)
            : $this->quote_from_calculation($gateway, $components, $customer_details, $stage, $basket_fingerprint, $customer_fingerprint);
    }

    /**
     * Price a one-time-main basket through a tax calculation with one
     * referenced line per component, mirroring the PaymentIntent attach
     * step.
     *
     * A reverse-charged basket prices twice: the calculation hides the
     * would-be rate on reverse-charge rows, so a consumer twin (the same
     * calculation without the customer tax IDs) supplies the rates the
     * labels and per-rate rows display. The business calculation stays
     * the quote's calculation id.
     *
     * @param  MeprStripeGateway         $gateway              The designated gateway.
     * @param  MeprOrderQuoteComponent[] $components           The basket components.
     * @param  array<string,mixed>       $customer_details     The customer details (address and tax IDs).
     * @param  string                    $stage                The quote stage.
     * @param  string                    $basket_fingerprint   The basket fingerprint.
     * @param  string                    $customer_fingerprint The customer fingerprint.
     * @return MeprOrderQuote
     * @throws MeprRemoteException When the API returns an error or the response cannot price every line.
     * @throws MeprHttpException When an HTTP request to Stripe fails.
     */
    private function quote_from_calculation(MeprStripeGateway $gateway, array $components, array $customer_details, string $stage, string $basket_fingerprint, string $customer_fingerprint): MeprOrderQuote
    {
        $inclusive  = MeprOptions::fetch()->attr('tax_calc_type') === 'inclusive';
        $line_items = [];

        foreach ($components as $component) {
            $line_item = [
                'amount'       => MeprUtils::format_stripe_currency($inclusive ? $component->total : $component->amount),
                'reference'    => $component->line_reference($stage),
                'tax_behavior' => $inclusive ? 'inclusive' : 'exclusive',
            ];

            $tax_code = MeprStripeTaxIntegration::get_product_tax_code($component->product_id);

            if (!empty($tax_code)) {
                $line_item['tax_code'] = $tax_code;
            }

            $line_items[] = $line_item;
        }

        $customer_details['address_source'] = 'billing';

        $args = [
            'currency'         => strtolower(MeprOptions::fetch()->currency_code),
            'customer_details' => $customer_details,
            'line_items'       => $line_items,
            'expand'           => ['line_items.data.tax_breakdown'],
        ];

        $calculation = (object) $gateway->send_stripe_request('tax/calculations', $args);

        $lines      = $this->calculation_lines($gateway, $calculation);
        $order_rows = (array) ($calculation->tax_breakdown ?? []);

        // The calculations surface hides the would-be rate on
        // reverse-charge rows (percentage 0.0 at the order and line level
        // alike), so a reverse-charged basket learns its rates from a
        // consumer twin: the same calculation without the customer tax
        // IDs. The twin only relabels; the business calculation stays the
        // charge and filing basis.
        if (isset($customer_details['tax_ids']) && $this->contains_reverse_charge($order_rows)) {
            unset($args['customer_details']['tax_ids']);

            $twin  = (object) $gateway->send_stripe_request('tax/calculations', $args);
            $lines = $this->relabel_reverse_charged_lines($lines, $this->calculation_lines($gateway, $twin));
        }

        $divisor = MeprStripeGateway::is_zero_decimal_currency(MeprOptions::fetch()->currency_code) ? 1 : 100;
        $by_ref  = [];

        foreach ($lines as $line) {
            $amount = (int) ($line['amount'] ?? 0);
            $tax    = (int) ($line['amount_tax'] ?? 0);

            $by_ref[(string) ($line['reference'] ?? '')] = [
                'amount' => $amount,
                'tax'    => $tax,
                'fields' => MeprStripeTaxIntegration::line_tax_fields(
                    is_array($line['tax_breakdown'] ?? null) ? $line['tax_breakdown'] : [],
                    ($inclusive ? $amount : $amount + $tax) / $divisor
                ),
            ];
        }

        return $this->assemble_stripe_quote($components, $by_ref, (string) ($calculation->id ?? ''), $inclusive, $stage, $basket_fingerprint, $customer_fingerprint);
    }

    /**
     * The calculation's complete line list, fetched page by page until
     * Stripe reports no further pages.
     *
     * An uncompletable list is a response anomaly, not an unpriceable
     * state, so it throws: the stage's failure policy decides whether
     * the render degrades or the attempt aborts.
     *
     * @param  MeprStripeGateway $gateway     The designated gateway.
     * @param  stdClass          $calculation The calculation response.
     * @return array<int,array<string,mixed>>
     * @throws MeprRemoteException When the line list cannot be completed or the API returns an error.
     * @throws MeprHttpException When an HTTP request to Stripe fails.
     *
     * phpcs:ignore Squiz.Commenting.FunctionCommentThrowTag.WrongNumber
     */
    private function calculation_lines(MeprStripeGateway $gateway, stdClass $calculation): array
    {
        $embedded = is_array($calculation->line_items ?? null) ? $calculation->line_items : [];

        if (!is_array($embedded['data'] ?? null)) {
            throw new MeprRemoteException('The tax calculation response carries no line list.');
        }

        $data = array_map(static function ($line) {
            return (array) $line;
        }, $embedded['data']);

        $has_more = !empty($embedded['has_more']);
        $calc_id  = (string) ($calculation->id ?? '');

        while ($has_more) {
            if ($calc_id === '' || empty($data)) {
                throw new MeprRemoteException('The tax calculation line list cannot be paged to completion.');
            }

            $last = end($data);
            $page = (array) $gateway->send_stripe_request("tax/calculations/$calc_id/line_items", [
                'limit'          => 100,
                'starting_after' => (string) ($last['id'] ?? ''),
                'expand'         => ['data.tax_breakdown'],
            ], 'get');

            if (!is_array($page['data'] ?? null)) {
                throw new MeprRemoteException('The tax calculation line list cannot be paged to completion.');
            }

            foreach ($page['data'] as $line) {
                $data[] = (array) $line;
            }

            $has_more = !empty($page['has_more']);
        }

        return $data;
    }

    /**
     * Whether any tax row is reverse-charged.
     *
     * @param  array<int,array<string,mixed>> $rows The tax rows.
     * @return boolean
     */
    private function contains_reverse_charge(array $rows): bool
    {
        foreach ($rows as $row) {
            if (($row['taxability_reason'] ?? '') === 'reverse_charge') {
                return true;
            }
        }

        return false;
    }

    /**
     * Replace each reverse-charged line's tax rows with its consumer twin
     * line's rows reshaped to carry the would-be rates.
     *
     * Lines the business calculation did not reverse-charge (exempt or
     * untaxed lines) keep their own rows. A reverse-charged reference the
     * twin did not price is a response anomaly, so it throws and the
     * stage's failure policy decides.
     *
     * @param  array<int,array<string,mixed>> $lines      The business calculation's lines.
     * @param  array<int,array<string,mixed>> $twin_lines The consumer twin's lines.
     * @return array<int,array<string,mixed>>
     * @throws MeprRemoteException When the twin did not price a reverse-charged reference.
     */
    private function relabel_reverse_charged_lines(array $lines, array $twin_lines): array
    {
        $twin_rows = [];

        foreach ($twin_lines as $twin_line) {
            $twin_rows[(string) ($twin_line['reference'] ?? '')] = is_array($twin_line['tax_breakdown'] ?? null) ? $twin_line['tax_breakdown'] : [];
        }

        foreach ($lines as $i => $line) {
            if (!$this->contains_reverse_charge(is_array($line['tax_breakdown'] ?? null) ? $line['tax_breakdown'] : [])) {
                continue;
            }

            $reference = (string) ($line['reference'] ?? '');

            if (!isset($twin_rows[$reference])) {
                throw new MeprRemoteException("The consumer twin calculation did not price line $reference."); // phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped
            }

            $lines[$i]['tax_breakdown'] = $this->as_reverse_charge_rows($twin_rows[$reference]);
        }

        return $lines;
    }

    /**
     * Reshape consumer twin rows into the reverse-charge rows Stripe
     * would send if it exposed the rate: a zero amount, the
     * reverse_charge reason, and the rate details kept. Rows without a
     * positive rate carry nothing worth surfacing and are dropped.
     *
     * @param  array<int,array<string,mixed>> $rows The twin's tax rows.
     * @return array<int,array<string,mixed>>
     */
    private function as_reverse_charge_rows(array $rows): array
    {
        $reshaped = [];

        foreach ($rows as $row) {
            $details = (array) ($row['tax_rate_details'] ?? []);

            if ((float) ($details['percentage_decimal'] ?? 0) <= 0) {
                continue;
            }

            $reshaped[] = [
                'amount'            => 0,
                'taxability_reason' => 'reverse_charge',
                'tax_rate_details'  => $details,
            ];
        }

        return $reshaped;
    }

    /**
     * Price a subscription-main basket through an invoice preview shaped
     * like the real first invoice.
     *
     * The subscription anchor mirrors what the charge produces. A
     * non-trial main's anchor IS its first-period line. A trial (or
     * free-trial) main anchors a subscription in its trial period at the
     * recurring price, contributing 0.00 now, while the upfront trial
     * charge rides as a one-time invoice item. Every other component is
     * a referenced invoice item.
     *
     * @param  MeprStripeGateway         $gateway              The designated gateway.
     * @param  MeprOrderQuoteComponent[] $components           The basket components.
     * @param  array<string,mixed>       $customer_details     The customer details (address and tax IDs).
     * @param  MeprSubscription          $main_sub             The main's subscription.
     * @param  string                    $stage                The quote stage.
     * @param  string                    $basket_fingerprint   The basket fingerprint.
     * @param  string                    $customer_fingerprint The customer fingerprint.
     * @return MeprOrderQuote|null Null when the main subscription has no Stripe billing interval.
     * @throws MeprRemoteException When the API returns an error or the response cannot price every line.
     * @throws MeprHttpException When an HTTP request to Stripe fails.
     */
    private function quote_from_invoice_preview(MeprStripeGateway $gateway, array $components, array $customer_details, MeprSubscription $main_sub, string $stage, string $basket_fingerprint, string $customer_fingerprint): ?MeprOrderQuote
    {
        $recurring = $this->recurring_interval($main_sub);

        if ($recurring === null) {
            MeprUtils::debug_log('stripe-tax-quote-fallback: the main subscription has no Stripe billing interval');

            return null;
        }

        $inclusive    = MeprOptions::fetch()->attr('tax_calc_type') === 'inclusive';
        $tax_behavior = $inclusive ? 'inclusive' : 'exclusive';
        $currency     = strtolower(MeprOptions::fetch()->currency_code);

        // The anchor first: a preview is the upcoming invoice for a
        // subscription, so every preview needs exactly one. A non-trial
        // main's anchor IS its first-period component (priced money, so
        // the loop below places it on the subscription line). A trial or
        // free-trial main gets a synthetic anchor at the recurring price
        // instead: it trials, so its line prices 0.00 now, and the
        // upfront trial charge rides as a one-time invoice item exactly
        // like every other component.
        $main_component  = $components[0];
        $main_is_anchor  = $main_component->is_main && $main_component->kind === MeprOrderQuoteLine::KIND_FIRST_PERIOD;
        $sub_items       = [];
        $invoice_items   = [];

        $subscription_details = [];

        if (!$main_is_anchor) {
            $sub_items[] = [
                'price_data' => [
                    'currency'     => $currency,
                    'product'      => $gateway->get_product_id($main_sub->product()),
                    'unit_amount'  => MeprUtils::format_stripe_currency($inclusive ? $main_sub->total : $main_sub->price),
                    'recurring'    => $recurring,
                    'tax_behavior' => $tax_behavior,
                ],
            ];

            if ($main_sub->trial && $main_sub->trial_days > 0) {
                $subscription_details['trial_end'] = time() + MeprUtils::days((int) $main_sub->trial_days);
            }
        }

        foreach ($components as $component) {
            $reference  = $component->line_reference($stage);
            $price_data = [
                'currency'     => $currency,
                'product'      => $gateway->get_product_id(new MeprProduct($component->product_id)),
                'unit_amount'  => MeprUtils::format_stripe_currency($inclusive ? $component->total : $component->amount),
                'tax_behavior' => $tax_behavior,
            ];

            if ($main_is_anchor && $component->is_main) {
                // The subscription item carries no reference metadata:
                // a subscription-sourced line reflects the
                // subscription's metadata, never the item's, so the
                // response side pairs this line by its type instead.
                $price_data['recurring'] = $recurring;

                $sub_items[] = ['price_data' => $price_data];

                continue;
            }

            $invoice_items[] = [
                'price_data' => $price_data,
                'metadata'   => ['quote_reference' => $reference],
            ];
        }

        $subscription_details['items'] = $sub_items;

        $args = [
            'currency'             => $currency,
            'customer_details'     => $customer_details,
            'automatic_tax'        => ['enabled' => 'true'],
            'subscription_details' => $subscription_details,
            'expand'               => ['lines.data.tax_amounts.tax_rate'],
        ];

        if (!empty($invoice_items)) {
            $args['invoice_items'] = $invoice_items;
        }

        $preview = (object) $gateway->send_stripe_request('invoices/create_preview', $args);

        $lines = $this->preview_lines($gateway, $preview);

        $by_ref = [];

        foreach ($lines as $line) {
            $reference = (string) ($line['metadata']['quote_reference'] ?? '');

            if ($reference === '' && ($line['type'] ?? '') === 'subscription') {
                // A subscription-sourced line reflects the
                // subscription's metadata, never the item's, so its
                // reference cannot ride the request; the line's type
                // identifies it instead. The preview carries exactly
                // one subscription item: the priced main when it is the
                // anchor, otherwise the synthetic anchor, which prices
                // nothing.
                $reference = $main_is_anchor ? $main_component->line_reference($stage) : self::SUB_ANCHOR_REFERENCE;
            }

            if ($reference === '' || $reference === self::SUB_ANCHOR_REFERENCE) {
                continue;
            }

            $line_tax_rows = is_array($line['tax_amounts'] ?? null) ? $line['tax_amounts'] : [];
            $amount        = (int) ($line['amount'] ?? 0);
            $tax           = 0;

            foreach ($line_tax_rows as $row) {
                $tax += (int) (((array) $row)['amount'] ?? 0);
            }

            $divisor = MeprStripeGateway::is_zero_decimal_currency(MeprOptions::fetch()->currency_code) ? 1 : 100;

            $by_ref[$reference] = [
                'amount' => $amount,
                'tax'    => $tax,
                'fields' => MeprStripeTaxIntegration::line_tax_fields(
                    MeprStripeTaxIntegration::reshape_invoice_tax_rows($line_tax_rows),
                    ($inclusive ? $amount : $amount + $tax) / $divisor
                ),
            ];
        }

        return $this->assemble_stripe_quote($components, $by_ref, '', $inclusive, $stage, $basket_fingerprint, $customer_fingerprint);
    }

    /**
     * The preview's complete line list, following the pagination through
     * the preview invoice's own line list when the embedded page is
     * truncated. A preview invoice carries an id like any other invoice,
     * which addresses its lines.
     *
     * An uncompletable list is a response anomaly, not an unpriceable
     * state, so it throws: the stage's failure policy decides whether
     * the render degrades or the attempt aborts.
     *
     * @param  MeprStripeGateway $gateway The designated gateway.
     * @param  stdClass          $preview The preview response.
     * @return array<int,array<string,mixed>>
     * @throws MeprRemoteException When the line list cannot be completed or the API returns an error.
     * @throws MeprHttpException When an HTTP request to Stripe fails.
     *
     * phpcs:ignore Squiz.Commenting.FunctionCommentThrowTag.WrongNumber
     */
    private function preview_lines(MeprStripeGateway $gateway, stdClass $preview): array
    {
        $embedded = is_array($preview->lines ?? null) ? $preview->lines : [];

        if (!is_array($embedded['data'] ?? null)) {
            throw new MeprRemoteException('The invoice preview response carries no line list.');
        }

        $data = array_map(static function ($line) {
            return (array) $line;
        }, $embedded['data']);

        $has_more   = !empty($embedded['has_more']);
        $invoice_id = (string) ($preview->id ?? '');

        while ($has_more) {
            if (empty($data) || $invoice_id === '') {
                throw new MeprRemoteException('The invoice preview line list cannot be paged to completion.');
            }

            $last = end($data);

            $page = (array) $gateway->send_stripe_request("invoices/$invoice_id/lines", [
                'limit'          => 100,
                'starting_after' => (string) ($last['id'] ?? ''),
                'expand'         => ['data.tax_amounts.tax_rate'],
            ], 'get');

            if (!is_array($page['data'] ?? null)) {
                throw new MeprRemoteException('The invoice preview line list cannot be paged to completion.');
            }

            foreach ($page['data'] as $line) {
                $data[] = (array) $line;
            }

            $has_more = !empty($page['has_more']);
        }

        return $data;
    }

    /**
     * Assemble the stripe-automatic quote from per-reference allocations.
     *
     * The assembly is all-or-nothing: a component whose reference the
     * response did not price is a response anomaly and throws (the
     * stage's failure policy decides whether the render degrades or
     * the attempt aborts), so no line mixes copied and derived
     * figures. Each line carries fields from its own tax rows.
     *
     * @param  MeprOrderQuoteComponent[]                            $components           The basket components.
     * @param  array<string,array{amount:int,tax:int,fields:array}> $by_ref               The allocations keyed by reference.
     * @param  string                                               $calculation_id       The calculation id (empty for previews).
     * @param  boolean                                              $inclusive            Whether pricing is tax-inclusive.
     * @param  string                                               $stage                The quote stage.
     * @param  string                                               $basket_fingerprint   The basket fingerprint.
     * @param  string                                               $customer_fingerprint The customer fingerprint.
     * @return MeprOrderQuote
     * @throws MeprRemoteException When any component is missing its priced line.
     */
    private function assemble_stripe_quote(array $components, array $by_ref, string $calculation_id, bool $inclusive, string $stage, string $basket_fingerprint, string $customer_fingerprint): MeprOrderQuote
    {
        $divisor = MeprStripeGateway::is_zero_decimal_currency(MeprOptions::fetch()->currency_code) ? 1 : 100;
        $lines   = [];
        $net     = 0.00;
        $tax     = 0.00;

        foreach ($components as $component) {
            $reference = $component->line_reference($stage);

            if (!isset($by_ref[$reference])) {
                throw new MeprRemoteException("The pricing response has no priced line for reference $reference."); // phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped -- internal identifier, not rendered output.
            }

            $fields     = $by_ref[$reference]['fields'];
            $line_tax   = (float) $by_ref[$reference]['tax'] / $divisor;
            $line_gross = $inclusive
                ? (float) $by_ref[$reference]['amount'] / $divisor
                : ((float) $by_ref[$reference]['amount'] + (float) $by_ref[$reference]['tax']) / $divisor;
            $line_net   = round($line_gross - $line_tax, 2);

            $lines[] = new MeprOrderQuoteLine(
                $reference,
                $component->product_id,
                $component->kind,
                $line_net,
                round($line_tax, 2),
                round($line_gross, 2),
                $fields['rate'],
                $fields['desc'],
                $fields['class'],
                $fields['removal']
            );

            $net += $line_net;
            $tax += round($line_tax, 2);
        }

        return new MeprOrderQuote(
            MeprOrderQuote::ENGINE_STRIPE_AUTOMATIC,
            $stage,
            $calculation_id,
            $basket_fingerprint,
            $customer_fingerprint,
            $lines,
            [
                'net'   => round($net, 2),
                'tax'   => round($tax, 2),
                'total' => round($net + $tax, 2),
            ]
        );
    }

    /**
     * Wrap the prepared figures into a rate-based quote (also the
     * fail-open shape for a Stripe pricing failure).
     *
     * @param  MeprOrderQuoteComponent[] $components           The basket components.
     * @param  string                    $stage                The quote stage.
     * @param  string                    $basket_fingerprint   The basket fingerprint.
     * @param  string                    $customer_fingerprint The customer fingerprint.
     * @return MeprOrderQuote
     */
    private function build_rate_based_quote(array $components, string $stage, string $basket_fingerprint, string $customer_fingerprint): MeprOrderQuote
    {
        $lines = [];
        $net   = 0.00;
        $tax   = 0.00;

        foreach ($components as $component) {
            $lines[] = new MeprOrderQuoteLine(
                $component->line_reference($stage),
                $component->product_id,
                $component->kind,
                $component->amount,
                $component->tax_amount,
                $component->total,
                $component->tax_rate,
                $component->tax_desc,
                $component->tax_class,
                $component->tax_reversal_amount
            );

            $net += $component->amount;
            $tax += $component->tax_amount;
        }

        $totals = [
            'net'   => round($net, 2),
            'tax'   => round($tax, 2),
            'total' => round($net + $tax, 2),
        ];

        return new MeprOrderQuote(
            MeprOrderQuote::ENGINE_RATE_BASED,
            $stage,
            '',
            $basket_fingerprint,
            $customer_fingerprint,
            $lines,
            $totals
        );
    }

    /**
     * The Stripe recurring block for a subscription's billing period, or
     * null when the period does not map to a Stripe interval.
     *
     * @param  MeprSubscription $subscription The subscription.
     * @return array{interval:string,interval_count:int}|null
     */
    private function recurring_interval(MeprSubscription $subscription): ?array
    {
        $intervals = [
            'days'   => 'day',
            'weeks'  => 'week',
            'months' => 'month',
            'years'  => 'year',
        ];

        $period_type = (string) $subscription->period_type;

        if (!isset($intervals[$period_type])) {
            return null;
        }

        return [
            'interval'       => $intervals[$period_type],
            'interval_count' => max(1, (int) $subscription->period),
        ];
    }

    /**
     * List the basket's priced components from the prepared
     * transactions.
     *
     * Each component projects its first-period-aware figures (the trial
     * when one exists). Components charging nothing now have a
     * non-positive projected total and are skipped, matching the charge
     * enumeration; positions are assigned to kept components only. The
     * caller passes subscriptions where they exist; an entry without
     * one is one-time by contract.
     *
     * @param  MeprTransaction       $txn         The main prepared transaction.
     * @param  MeprSubscription|null $sub         The main's subscription when recurring.
     * @param  array                 $order_bumps The order bumps ([transaction, subscription] pairs).
     * @return MeprOrderQuoteComponent[]
     */
    private function state_components(MeprTransaction $txn, ?MeprSubscription $sub, array $order_bumps): array
    {
        $components = [];
        $entries    = array_merge([[$txn, $sub]], $order_bumps);

        foreach ($entries as $index => $entry) {
            list($transaction, $subscription) = $entry;

            if (!$transaction instanceof MeprTransaction) {
                continue;
            }

            $component = new MeprOrderQuoteComponent(
                $transaction,
                $subscription instanceof MeprSubscription ? $subscription : null,
                $index === 0,
                count($components)
            );

            if ($component->total <= 0) {
                continue;
            }

            $components[] = $component;
        }

        return $components;
    }

    /**
     * The basket fingerprint: the priced state's identity for caching
     * and verification. Covers the lines' money and kind, each product's
     * resolved Stripe tax code, the tax options, and the store currency,
     * so any change to a pricing input forces a fresh price. It covers
     * what the basket is priced from, not which rows carry it, so the
     * same basket fingerprints identically whether its rows are unsaved
     * (a checkout render) or stored (a submit-time gate recompute).
     *
     * @param  MeprOrderQuoteComponent[] $components The basket components.
     * @return string
     */
    private function basket_fingerprint(array $components): string
    {
        $rows = [];

        foreach ($components as $component) {
            $rows[] = [
                $component->product_id,
                $component->kind,
                (string) $component->amount,
                (string) $component->tax_amount,
                (string) $component->total,
                MeprStripeTaxIntegration::get_product_tax_code($component->product_id),
            ];
        }

        return md5(wp_json_encode([
            $rows,
            (bool) get_option('mepr_calculate_taxes'),
            (bool) get_option('mepr_tax_stripe_enabled'),
            (string) MeprOptions::fetch()->attr('tax_calc_type'),
            strtolower(MeprOptions::fetch()->currency_code),
        ]));
    }

    /**
     * The customer fingerprint: the pricing account, the pricing address,
     * and the VAT tax ID, the inputs that make one customer's tax
     * situation differ from another's. Entering or removing a VAT number
     * therefore re-prices instead of serving a cached quote computed
     * under the other tax treatment, and a quote priced on one account
     * never serves a surface pricing on another (the cache and cooldown
     * keys are built from the fingerprints).
     *
     * @param  MeprUser               $usr     The purchasing user.
     * @param  MeprStripeGateway|null $gateway The gateway pricing the basket, or null when none is available.
     * @return string
     */
    private function customer_fingerprint(MeprUser $usr, ?MeprStripeGateway $gateway): string
    {
        $address = $usr->tax_address();

        return md5(wp_json_encode([
            $gateway === null ? null : $gateway->id,
            $address === null ? 'none' : $address,
            $gateway === null ? null : $gateway->get_customer_tax_id_data($usr),
        ]));
    }

    /**
     * The transient key a render quote caches under, built from the two
     * fingerprints and salted with the plugin version.
     *
     * @param  string $basket_fingerprint   The basket fingerprint.
     * @param  string $customer_fingerprint The customer fingerprint.
     * @return string
     */
    private function preview_cache_key(string $basket_fingerprint, string $customer_fingerprint): string
    {
        return 'mepr_order_quote_' . md5(wp_json_encode([MEPR_VERSION, $basket_fingerprint, $customer_fingerprint]));
    }

    /**
     * The gateway that prices this basket: the transaction's own payment
     * method when it is a Stripe gateway (a quote must be priced on the
     * account that charges it, because calculation ids are account-scoped
     * and the mounted amount must match the submit total), otherwise the
     * designated Stripe Tax gateway (non-Stripe charges price and file on
     * the designated account by design). Payment-method-independent
     * surfaces prepare their transactions with the 'manual' gateway, so
     * they price on the designated account.
     *
     * @param  MeprTransaction $txn The main transaction.
     * @return MeprStripeGateway|null
     */
    private function pricing_gateway(MeprTransaction $txn): ?MeprStripeGateway
    {
        $payment_method = $txn->payment_method();

        return $payment_method instanceof MeprStripeGateway
            ? $payment_method
            : $this->designated_gateway();
    }

    /**
     * The designated Stripe Tax gateway.
     *
     * @return MeprStripeGateway|null
     */
    private function designated_gateway(): ?MeprStripeGateway
    {
        $payment_method_id = (string) get_option('mepr_tax_stripe_payment_method', '');

        if ($payment_method_id === '') {
            return null;
        }

        $payment_method = MeprOptions::fetch()->payment_method($payment_method_id);

        return $payment_method instanceof MeprStripeGateway ? $payment_method : null;
    }
}
