<?php

namespace FluentCartPro\App\Services\FileSystem\Drivers\R2;

use FluentCart\Framework\Support\Arr;

class R2FileList
{
    public static function get(string $accountId, string $secret, string $accessKey, string $bucket, string $search = ''): array
    {
        $region = 'auto';
        $service = 's3';
        $host = $accountId . '.r2.cloudflarestorage.com';
        $path = '/' . $bucket;
        $timestamp = gmdate('Ymd\THis\Z');
        $date = gmdate('Ymd');
        $queryParams = ['list-type' => '2'];

        if ($search) {
            $queryParams['prefix'] = $search;
        }

        ksort($queryParams);
        $canonicalQuery = http_build_query($queryParams);
        $payloadHash = hash('sha256', '');
        $canonicalHeaders = 'host:' . $host . "\n"
            . 'x-amz-content-sha256:' . $payloadHash . "\n"
            . 'x-amz-date:' . $timestamp . "\n";
        $signedHeaders = 'host;x-amz-content-sha256;x-amz-date';
        $canonicalRequest = 'GET' . "\n" . $path . "\n" . $canonicalQuery . "\n" . $canonicalHeaders . "\n" . $signedHeaders . "\n" . $payloadHash;
        $credentialScope = $date . '/' . $region . '/' . $service . '/aws4_request';
        $stringToSign = 'AWS4-HMAC-SHA256' . "\n" . $timestamp . "\n" . $credentialScope . "\n" . hash('sha256', $canonicalRequest);
        $kDate = hash_hmac('sha256', $date, 'AWS4' . $secret, true);
        $kRegion = hash_hmac('sha256', $region, $kDate, true);
        $kService = hash_hmac('sha256', $service, $kRegion, true);
        $kSigning = hash_hmac('sha256', 'aws4_request', $kService, true);
        $signature = hash_hmac('sha256', $stringToSign, $kSigning);

        $response = wp_remote_get('https://' . $host . $path . '?' . $canonicalQuery, [
            'headers' => [
                'Authorization'        => 'AWS4-HMAC-SHA256 Credential=' . $accessKey . '/' . $credentialScope . ', SignedHeaders=' . $signedHeaders . ', Signature=' . $signature,
                'x-amz-date'           => $timestamp,
                'x-amz-content-sha256' => $payloadHash,
            ],
            'timeout' => 30,
        ]);

        if (is_wp_error($response) || (int) wp_remote_retrieve_response_code($response) !== 200) {
            return [];
        }

        $xml = simplexml_load_string(wp_remote_retrieve_body($response));
        $array = json_decode(json_encode($xml), true);
        $contents = Arr::get($array, 'Contents', []);

        if (isset($contents['Key'])) {
            $contents = [$contents];
        }

        $files = [];
        foreach ($contents as $item) {
            $key = Arr::get($item, 'Key');
            if (!$key || substr($key, -1) === '/') {
                continue;
            }

            $files[] = [
                'name'          => basename($key),
                'path'          => $key,
                'size'          => Arr::get($item, 'Size'),
                'last_modified' => Arr::get($item, 'LastModified'),
                'driver'        => 'r2',
            ];
        }

        return $files;
    }
}
