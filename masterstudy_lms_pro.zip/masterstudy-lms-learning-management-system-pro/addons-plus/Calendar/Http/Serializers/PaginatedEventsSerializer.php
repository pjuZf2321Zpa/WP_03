<?php

namespace MasterStudy\Lms\Pro\AddonsPlus\Calendar\Http\Serializers;

use MasterStudy\Lms\Http\Serializers\AbstractSerializer;

final class PaginatedEventsSerializer extends AbstractSerializer {
	public function toArray( $data ): array { // phpcs:ignore WordPress.NamingConventions.ValidFunctionName.MethodNameInvalid
		$response = array(
			'events'     => ( new EventSerializer() )->collectionToArray( $data['events'] ?? array() ),
			'pagination' => array(
				'page'        => absint( $data['pagination']['page'] ?? 1 ),
				'per_page'    => absint( $data['pagination']['per_page'] ?? 0 ),
				'total'       => absint( $data['pagination']['total'] ?? 0 ),
				'total_pages' => absint( $data['pagination']['total_pages'] ?? 0 ),
				'has_more'    => ! empty( $data['pagination']['has_more'] ),
			),
		);

		if ( isset( $data['counts'] ) ) {
			$response['counts'] = array(
				'upcoming' => absint( $data['counts']['upcoming'] ?? 0 ),
				'past'     => absint( $data['counts']['past'] ?? 0 ),
			);
		}

		return $response;
	}
}
