<?php

namespace MasterStudy\Lms\Pro\AddonsPlus\Notifications\Services;

use MasterStudy\Lms\Pro\AddonsPlus\Notifications\Events;
use MasterStudy\Lms\Pro\AddonsPlus\Notifications\Repositories\DispatchQueueRepository;
use MasterStudy\Lms\Pro\AddonsPlus\Notifications\Repositories\NotificationRepository;
use MasterStudy\Lms\Pro\AddonsPlus\Notifications\Repositories\PushQueueRepository;

final class RecipientFanoutWorker {
	private DispatchQueueRepository $queue;
	private NotificationRepository $notifications;
	private PushQueueRepository $push_queue;
	private RecipientResolver $resolver;

	public function __construct() {
		$this->queue         = new DispatchQueueRepository();
		$this->notifications = new NotificationRepository();
		$this->push_queue    = new PushQueueRepository();
		$this->resolver      = new RecipientResolver();
	}

	public static function process(): void {
		try {
			( new self() )->process_batch();
		} catch ( \Throwable $error ) {
			return;
		}
	}

	public function process_batch( int $limit = 5 ): void {
		if ( ! $this->is_available() ) {
			return;
		}

		try {
			$rows = $this->queue->claim_available( $limit );
		} catch ( \Throwable $error ) {
			return;
		}

		foreach ( $rows as $row ) {
			try {
				$this->process_row( $row );
			} catch ( \Throwable $error ) {
				$this->queue->mark_failed(
					(int) $row['id'],
					(int) $row['attempts'] + 1,
					$this->safe_error_message( $error )
				);
			}
		}

		try {
			$has_pending = $this->queue->has_pending();
		} catch ( \Throwable $error ) {
			return;
		}

		if ( $has_pending ) {
			$this->schedule_next();
		}
	}

	private function process_row( array $row ): void {
		$notification = $this->notifications->get_notification( (int) $row['notification_id'] );

		if ( empty( $notification ) ) {
			$this->queue->mark_failed( (int) $row['id'], (int) $row['attempts'] + 1, 'Notification not found.', false );
			return;
		}

		$context  = $this->decode_context( $row, $notification );
		$channels = $this->enabled_channels( $this->decode_channels( $row ), (string) $notification['trigger_key'], $context );

		if ( empty( $channels ) ) {
			$this->queue->mark_done( (int) $row['id'] );
			return;
		}

		$batch_size     = max( 1, absint( $row['batch_size'] ?? 100 ) );
		$batch_cursor   = $this->get_batch_cursor( $row );
		$resolved       = $this->resolve_recipients( $row, $batch_size, $batch_cursor );
		$resolved_ids   = $resolved['user_ids'];
		$resolved_count = count( $resolved_ids );
		$recipient_ids  = $resolved_ids;
		$recipient_ids  = apply_filters( 'masterstudy_notifications_dispatch_recipients', $recipient_ids, (string) $notification['trigger_key'], $context );
		$recipient_ids  = $this->sanitize_ids( $recipient_ids );

		if ( ! empty( $recipient_ids ) ) {
			if ( in_array( Events::CHANNEL_ON_SITE, $channels, true ) ) {
				$this->notifications->add_recipients( (int) $row['notification_id'], $recipient_ids );
			}

			if ( in_array( Events::CHANNEL_PUSH, $channels, true ) ) {
				$this->push_queue->enqueue( (int) $row['notification_id'], $recipient_ids );
				$this->schedule_push_queue();
			}
		}

		if ( 'course_students' === (string) $row['target_type'] && $resolved_count >= $batch_size && $resolved['next_cursor'] > $batch_cursor ) {
			$this->queue->continue_target( (int) $row['id'], $resolved['next_cursor'] );
			return;
		}

		$this->queue->mark_done( (int) $row['id'] );
	}

	private function resolve_recipients( array $row, int $batch_size, int $batch_cursor ): array {
		if ( 'course_students' === (string) $row['target_type'] ) {
			return $this->resolver->course_students_batch_after( absint( $row['target_value'] ?? 0 ), $batch_size, $batch_cursor );
		}

		if ( 'explicit' !== (string) $row['target_type'] ) {
			return array(
				'user_ids'    => array(),
				'next_cursor' => $batch_cursor,
			);
		}

		$recipient_ids = json_decode( (string) ( $row['recipient_ids'] ?? '' ), true );

		return array(
			'user_ids'    => is_array( $recipient_ids ) ? $recipient_ids : array(),
			'next_cursor' => $batch_cursor,
		);
	}

	private function get_batch_cursor( array $row ): int {
		if ( ! empty( $row['cursor_value'] ) ) {
			return max( 0, absint( $row['cursor_value'] ) );
		}

		return max( 0, absint( $row['batch_offset'] ?? 0 ) );
	}

	private function enabled_channels( array $channels, string $trigger_key, array $context ): array {
		$dispatcher = new Dispatcher();
		$enabled    = array();

		foreach ( $channels as $channel ) {
			$is_enabled = $dispatcher->is_channel_enabled( $trigger_key, $channel );
			$is_enabled = (bool) apply_filters( 'masterstudy_notifications_should_dispatch_channel', $is_enabled, $channel, $trigger_key, $context );

			if ( $is_enabled ) {
				$enabled[] = $channel;
			}
		}

		return array_values( array_unique( $enabled ) );
	}

	private function decode_channels( array $row ): array {
		$channels = array_filter( array_map( 'sanitize_key', explode( ',', (string) ( $row['channels'] ?? '' ) ) ) );

		return array_values( array_unique( $channels ) );
	}

	private function decode_context( array $row, array $notification ): array {
		$context = json_decode( (string) ( $row['context'] ?? '' ), true );

		if ( ! is_array( $context ) ) {
			$context = json_decode( (string) ( $notification['metadata'] ?? '' ), true );
		}

		return is_array( $context ) ? $context : array();
	}

	private function sanitize_ids( array $ids ): array {
		return array_values( array_unique( array_filter( array_map( 'absint', $ids ) ) ) );
	}

	private function is_available(): bool {
		return function_exists( 'masterstudy_lms_is_notifications_addon_available' )
			&& masterstudy_lms_is_notifications_addon_available();
	}

	private function schedule_next(): void {
		if ( ! wp_next_scheduled( 'masterstudy_notifications_process_recipient_fanout' ) ) {
			wp_schedule_single_event( time() + 10, 'masterstudy_notifications_process_recipient_fanout' );
		}
	}

	private function schedule_push_queue(): void {
		if ( ! wp_next_scheduled( 'masterstudy_notifications_process_push_queue' ) ) {
			wp_schedule_single_event( time() + 10, 'masterstudy_notifications_process_push_queue' );
		}
	}

	private function safe_error_message( \Throwable $error ): string {
		$message = sanitize_textarea_field( $error->getMessage() );

		return '' !== $message ? $message : 'Recipient fanout failed.';
	}
}
