<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Actions\SureDash\SureDashRecordHelper;
use BitApps\IntegrationsPro\Config;
use BitApps\IntegrationsPro\Core\Util\Hooks;

Hooks::filter(Config::withFreePrefix('sure_dash_create_post'), [SureDashRecordHelper::class, 'createPost'], 10, 3);
Hooks::filter(Config::withFreePrefix('sure_dash_delete_post'), [SureDashRecordHelper::class, 'deletePost'], 10, 2);
Hooks::filter(Config::withFreePrefix('sure_dash_create_comment'), [SureDashRecordHelper::class, 'createComment'], 10, 3);
Hooks::filter(Config::withFreePrefix('sure_dash_delete_comment'), [SureDashRecordHelper::class, 'deleteComment'], 10, 2);
Hooks::filter(Config::withFreePrefix('sure_dash_update_user_profile'), [SureDashRecordHelper::class, 'updateUserProfile'], 10, 2);
Hooks::filter(Config::withFreePrefix('sure_dash_bookmark_item'), [SureDashRecordHelper::class, 'bookmarkItem'], 10, 2);
Hooks::filter(Config::withFreePrefix('sure_dash_react_to_entity'), [SureDashRecordHelper::class, 'reactToEntity'], 10, 2);
