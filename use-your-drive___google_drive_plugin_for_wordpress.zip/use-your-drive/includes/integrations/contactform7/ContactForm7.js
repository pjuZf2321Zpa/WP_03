jQuery(document).ready(function ($) {
    'use strict';

    // Define variables for elements
    let $useyourdrive_module_id = $('#tag-generator-panel-useyourdrive-module-id');
    let $useyourdrive_selector_button = $('button#tag-generator-panel-useyourdrive-module-selector');
    let $useyourdrive_dialog = $('dialog#tag-generator-panel-useyourdrive-module-selector-dialog');
    let $useyourdrive_dialog_close_button = $('button.tag-generator-panel-useyourdrive-module-close');
    let $iframe_template;

    // Event handler for selector button click
    $useyourdrive_selector_button.on('click', function (e) {
        e.preventDefault();
            // Add size to dialog
            $useyourdrive_dialog.css({
                height: '768px',
                width: '1024px',
                border: '0',
                padding: '0',
                overflow: 'hidden',
            });

            // Add iframe to dialog
            let moduleBuilderUrl = $useyourdrive_dialog.parents('fieldset').attr('data-src');
            let $iframe_template = $(
                "<iframe src='' width='1024' height='768' tabindex='-1' style='border:none' title='Module Selector'></iframe>"
            );
            $useyourdrive_dialog.append($iframe_template);

        
        let instanceId = window.WPCP_Bridge.createInstanceId();
        let unsubscribeBridge = window.WPCP_Bridge.subscribe(
            'use-your-drive',
            'wpcp-shortcode',
            instanceId,
            function (data) {
                if (!data || typeof data.shortcode !== 'string') {
                    return;
                }

                let moduleMatch = data.shortcode.match(/module="(\d+)"/);
                if (!moduleMatch) {
                    return;
                }

                $useyourdrive_module_id.val(moduleMatch[1]);
                $useyourdrive_module_id[0].dispatchEvent(new Event('change', { bubbles: true }));
                $useyourdrive_module_id[0].dispatchEvent(new Event('keyup', { bubbles: true }));
                unsubscribeBridge();

                // Delete Iframe
                $iframe_template.remove();
                $iframe_template = null;

                $useyourdrive_dialog[0].close();
            }
        );

        moduleBuilderUrl += '&wpcp_instance_id=' + encodeURIComponent(instanceId);

        // Append module ID or default shortcode to URL
        if ($useyourdrive_module_id.val() !== '') {
            moduleBuilderUrl += '&module=' + $useyourdrive_module_id.val();
        } else {
            moduleBuilderUrl +=
                '&shortcode=' +
                WPCP_shortcodeEncode(
                    '[useyourdrive mode="upload" viewrole="all" upload="1" uploadrole="all" upload_auto_start="0" userfolders="auto" viewuserfoldersrole="none"]'
                );
        }

        $iframe_template.attr('src', moduleBuilderUrl);

        // Show the dialog
        $useyourdrive_dialog[0].showModal();
    });

    // Event handler for dialog close button click
    $useyourdrive_dialog_close_button.on('click', function (e) {
        e.preventDefault();
        e.stopPropagation();

        // Delete Iframe
        $iframe_template.remove();
        $iframe_template = null;

        // Close the dialog
        $useyourdrive_dialog[0].close();
    });

});
