<?php

namespace FluentCartPro\App\Modules\PaymentMethods\PaddleGateway;

use FluentCartPro\App\Modules\PaymentMethods\PaddleGateway\API\API;
use FluentCart\Api\CurrencySettings;
use FluentCart\App\Helpers\Helper;
use FluentCart\App\Helpers\Status;
use FluentCart\App\Models\Order;
use FluentCart\App\Models\ProductVariation;
use FluentCart\App\Services\Payments\PaymentHelper;
use FluentCart\App\Services\Payments\PaymentInstance;
use FluentCart\App\Services\Payments\SubscriptionHelper;
use FluentCart\Framework\Support\Arr;

class Processor
{
    /**
     * Handle single payment processing
     */
    public function handleSinglePayment(PaymentInstance $paymentInstance)
    {
        $order = $paymentInstance->order;
        $transaction = $paymentInstance->transaction;

        $receiptUrl = $transaction->getReceiptPageUrl();
        if (!$receiptUrl || !filter_var($receiptUrl, FILTER_VALIDATE_URL)) {
            return new \WP_Error(
                'paddle_invalid_receipt_url',
                __('Paddle checkout requires a valid receipt page. Please configure it in FluentCart → Settings → Pages.', 'fluent-cart-pro')
            );
        }

        try {
            // Create or get Paddle customer
            $paddleCustomer = PaddleHelper::createOrGetPaddleCustomer($order->customer, $order->mode);
            
            if (is_wp_error($paddleCustomer)) {
                return $paddleCustomer;
            }

            $customerId = Arr::get($paddleCustomer, 'data.id');
            $paddleData = $this->preparePaddleOneTimeCheckoutData($order, $transaction, $customerId);

            if (is_wp_error($paddleData) && in_array($paddleData->get_error_code(), ['paddle_already_paid', 'paddle_checkout_replace_failed'], true)) {
                return $paddleData;
            }

            if (is_wp_error($paddleData)) {
                $errorData = $paddleData->get_error_data();
                // get error message from this type of errors
                $errors = Arr::get($errorData, 'response_body.error.errors', []);
                $errorMessage = '';
                if (empty($errors)) {
                   $errorMessage = 'Paddle Unknown Error';
                } else {
                    foreach ($errors as $error) {
                        $errorMessage .= 'field: ' . $error['field'] . ': ' . 'message: ' . $error['message'] . '<br>';
                    }
                }

                return new \WP_Error(
                    'paddle_payment_error',
                    $errorMessage
                );
            }

            $paddleData['customer_id'] = $customerId;

            return [
                'nextAction'         => 'paddle',
                'actionName'         => 'custom',
                'status'             => 'success',
                'data'               => [
                    'order'       => [
                        'hash' => $order->uuid,
                    ],
                    'transaction' => [
                        'hash' => $transaction->uuid,
                    ],
                    'customer' => [
                        'email'     => $order->customer->email,
                        'address'   => [
                            'countryCode' => $order->customer->country,
                            'postalCode' => $order->customer->postcode,
                        ]
                    ],
                ],
                'message' => __('Order has been placed successfully', 'fluent-cart-pro'),
                'response' => $paddleData,
            ];

        } catch (\Exception $e) {
            return new \WP_Error(
                'paddle_payment_error',
                $e->getMessage()
            );
        }
    }

    /**
     * Handle subscription payment processing
     */
    public function handleSubscriptionPayment(PaymentInstance $paymentInstance, $paymentArgs = [])
    {
        $order = $paymentInstance->order;
        $transaction = $paymentInstance->transaction;

        $receiptUrl = $transaction->getReceiptPageUrl();
        if (!$receiptUrl || !filter_var($receiptUrl, FILTER_VALIDATE_URL)) {
            return new \WP_Error(
                'paddle_invalid_receipt_url',
                __('Paddle checkout requires a valid receipt page. Please configure it in FluentCart → Settings → Pages.', 'fluent-cart-pro')
            );
        }

        $subscription = $paymentInstance->subscription;
        $orderType = $paymentInstance->order->type;
        $feeTotal = $orderType !== 'renewal' ? (int)$order->fee_total : 0;
        $initialAmount = (int)$subscription->signup_fee + $paymentInstance->getExtraAddonAmount() + $feeTotal;

        $transaction = $paymentInstance->transaction;
        $status = Status::SUBSCRIPTION_INTENDED;

        if (!$subscription) {
            return new \WP_Error(
                'no_subscription',
                __('No subscription found for this order', 'fluent-cart-pro')
            );
        }

        try {
            $paddleCustomer = PaddleHelper::createOrGetPaddleCustomer($order->customer, $order->mode);
            
            if (is_wp_error($paddleCustomer)) {
                return $paddleCustomer;
            }

            $productId = 'fct_paddle_product_' .
                $subscription->product_id . '_v_' .
                $subscription->variation_id . '_' .
                $subscription->recurring_total . '_' .
                $subscription->billing_interval . '_' .
                $subscription->trial_days . '_' .
                $subscription->bill_times . '_' .
                $subscription->signup_fee . '-' .
                $order->currency . '_' . $order->mode;

            // temporary
            $productIdtTest = 'fct_paddle_product_' . $subscription->product_id . '_' . $order->mode;

            $subscriptionItem = $order->order_items->filter(function ($item) {
                return $item->payment_type !== 'signup_fee' && $item->payment_type !== 'bundle';
            })->first();


            $productName = $subscriptionItem->post_title ? $subscriptionItem->post_title : $subscriptionItem->title;
            $productDescription = $subscriptionItem->post_title . ' - ' . $subscriptionItem->title;
            $subscriptionProductType = apply_filters('fluent_cart/paddle_subscription_product_type', 'standard', [
                'subscription' => $subscription
            ]);


            $paddleProduct = Product::createOrGetPaddleProduct([
                'fct_product_id' => $subscription->product_id,
                'product_id'     => $productIdtTest,
                'currency'       => $order->currency,
                'mode'           => $order->mode,
                'name'           => $productName,
                'description'    => $productDescription,
                'type'           => $subscriptionProductType
            ]);

            $priceName = $subscriptionItem->title ? $subscriptionItem->title : $subscriptionItem->post_title;
            $subscriptionPriceType = apply_filters('fluent_cart/paddle_subscription_price_type', 'standard', [
                'subscription' => $subscription
            ]);

            if ($orderType == 'renewal') {
                $status = $subscription->status;
                $initialAmount = 0;

                $data = [
                    'name'             => $priceName,
                    'mode'             => $order->mode,
                    'paddle_product_id'       => Arr::get($paddleProduct, 'data.id'),
                    'fct_product_id'   => $subscription->product_id,
                    'variation_id'     => $subscription->variation_id,
                    'trial_days'       => $subscription->getReactivationTrialDays(),
                    'billing_interval' => $subscription->billing_interval,
                    'currency'         => $order->currency,
                    'order_id'         => $order->id,
                    'interval_count'   => 1, // 1
                    'signup_fee'       => $initialAmount, // default setup fee in cents ($0.00)
                    'recurring_total'  => $subscription->getCurrentRenewalAmount(),
                    'bill_times'       => (int)$subscription->getRequiredBillTimes(), // 0 for unlimited
                    'type'             => $subscriptionPriceType
                ];
                $paddleRecurringPrice = Price::getOrCreatePaddleRecurringPrice($data);
            } else {
                $data = [
                    'name'             => $priceName,
                    'mode'             => $order->mode,
                    'paddle_product_id'       => Arr::get($paddleProduct, 'data.id'),
                    'fct_product_id'   => $subscription->product_id,
                    'variation_id'     => $subscription->variation_id,
                    'trial_days'       => $subscription->trial_days,
                    'billing_interval' => $subscription->billing_interval,
                    'currency'         => $order->currency,
                    'order_id'         => $order->id,
                    'interval_count'   => 1, // 1
                    'signup_fee'       => $initialAmount, // default setup fee in cents ($0.00)
                    'recurring_total'  => (int) $subscription->recurring_total, // internal ×100 units; Price formats for the wire
                    'bill_times'       => $subscription->getInitialRemoteBillTimes(), // 0 for unlimited; simulated-trial first installment excluded (feeds price description + cache key only — Paddle has no cycle cap)
                    'type'             => $subscriptionPriceType
                ];

                $paddleRecurringPrice = Price::getOrCreatePaddleRecurringPrice($data);
            }

            if (is_wp_error($paddleRecurringPrice)) {
                return $paddleRecurringPrice;
            }

            $priceIds = [
                [
                    'price_id' => Arr::get($paddleRecurringPrice, 'data.id'),
                    'quantity' => 1
                ]
            ];

            if ($initialAmount) {
                $initialPriceName = Arr::get($subscriptionItem->other_info, 'signup_fee_name', __('Signup Fee', 'fluent-cart-pro'));
                $subscriptionSignupFee = Arr::get($subscriptionItem->other_info, 'signup_fee', 0);
                if ($initialAmount != $subscriptionSignupFee) {
                    $initialPriceName = __('Initial Payment', 'fluent-cart-pro');
                }

                $signupFeePriceType = apply_filters('fluent_cart/paddle_signup_fee_price_type', 'custom', [
                    'subscription' => $subscription
                ]);
                $addonPrice = Price::getOrCreatePaddleSinglePrice([
                    'paddle_product_id'  => Arr::get($paddleProduct, 'data.id'),
                    'fct_product_id' => 0,
                    'variation_id'   => 0,
                    'currency'    => $order->currency,
                    'mode'        => $order->mode,
                    'name'        =>  $initialPriceName,
                    'description' => $subscriptionItem->title . ' - ' . $initialPriceName,
                    'amount'      => (int) $initialAmount,
                    'quantity'    => 1,
                    'type'        =>  $signupFeePriceType,
                    'order_id'    =>  $order->id
                ]);

                if (is_wp_error($addonPrice)) {
                    return $addonPrice;
                }

                $priceIds[] = [
                    'price_id' => Arr::get($addonPrice, 'data.id'),
                    'quantity' => 1
                ];
            }

            $this->persistExpectedCheckoutItems($transaction, $priceIds);

            // A reactivation checkout may be abandoned, so the subscription keeps
            // pointing at the gateway that still bills it; the Paddle refs are
            // bound once Paddle confirms the replacement.
            if ($orderType !== 'renewal') {
                $subscription->update([
                    'status'                 => $status,
                    'current_payment_method' => 'paddle',
                    'next_billing_date'      => SubscriptionHelper::getNextBillingDate($subscription),
                    'vendor_plan_id'         => Arr::get($paddleRecurringPrice, 'data.id'),
                    'vendor_customer_id'     => Arr::get($paddleCustomer, 'data.id'),
                ]);
            }

            // The first-cycle part of a coupon is not in the recurring price, so it
            // goes to Paddle as a one-off discount on the transaction; the recurring
            // part is already in the price and needs no discount object.
            $discountId = null;
            $firstCycleDiscount = $orderType !== 'renewal' ? (int) Arr::get($subscription->config, 'first_cycle_discount', 0) : 0;
            if ($firstCycleDiscount > 0) {
                $discountMode = apply_filters('fluent_cart/paddle_discount_mode', 'custom', [
                    'order' => $order,
                    'discount_amount' => $firstCycleDiscount
                ]);
                $discount = Price::createPaddleDiscount($order, $firstCycleDiscount, $discountMode);
                if (is_wp_error($discount)) {
                    return $discount;
                }
                $discountId = Arr::get($discount, 'data.id');
            }

            $paddleData = $this->createPaddleTransaction($order, $transaction, $priceIds, [
                'customer_id'  => Arr::get($paddleCustomer, 'data.id'),
                'subscription' => $subscription,
                'discount_id'  => $discountId,
            ]);

            if (is_wp_error($paddleData)) {
                return $paddleData;
            }

            return [
                'nextAction'         => 'paddle',
                'actionName'         => 'custom',
                'status'             => 'success',
                'data'               => [
                    'order' => [
                        'hash' => $order->uuid,
                    ],
                    'transaction' => [
                        'hash' => $transaction->uuid,
                    ],
                    'subscription' => [
                        'hash' => $subscription->uuid,
                    ],
                    'customer' => [
                        'email'     => $order->customer->email,
                        'address'   => [
                            'countryCode' => $order->customer->country,
                            'postalCode' => $order->customer->postcode,
                        ]
                    ],
                ],
                'message' => __('Order has been placed successfully', 'fluent-cart-pro'),
                'response' => $paddleData,
            ];

        } catch (\Exception $e) {
            return new \WP_Error(
                'paddle_subscription_error',
                $e->getMessage()
            );
        }
    }

    private function getPaddlePriceIdsForOneTimePayment(Order $order)
    {
        $prices = [];
        foreach ($order->order_items as $orderItem) {
            // Get item name from available properties
            if ($orderItem->payment_type === 'bundle') {
                continue;
            }     

            $productName = $orderItem->post_title ? $orderItem->post_title : $orderItem->title;
            $quantity = $orderItem->quantity;
            $perQuantityAmount   = $orderItem->unit_price;

            $variation = ProductVariation::query()->find($orderItem->object_id);
            $productId = 'fct_paddle_product_' .
                $variation->post_id . '_' .
                $variation->id . '_' .
                $variation->item_price . '_' .
                $order->currency . '_' .
                $variation->fulfillment_type . '_' .
                $variation->payment_type . '_' .
                $order->mode;

            $productId = apply_filters('fluent_cart/paddle_product_id', $productId, [
                'variation' => $variation
            ]);

            $onetimeProductType = apply_filters('fluent_cart/paddle_onetime_product_type', 'standard', [
                'variation' => $variation
            ]);
            $paddleProduct = Product::createOrGetPaddleProduct([
                'fct_product_id' => $variation->post_id,
                'variation_id'   => $variation->id,
                'product_id'     => $productId,
                'currency'       => $order->currency,
                'mode'           => $order->mode,
                'name'           => $productName,
                'type'           => $onetimeProductType,
                'order_id'       =>  $order->id
            ]);


            if (is_wp_error($paddleProduct)) {
                return $paddleProduct;
            }

            $paddleProductId = Arr::get($paddleProduct, 'data.id');
            $priceName = $orderItem->title ? $orderItem->title : $orderItem->post_title;
            $priceDescription = $orderItem->title . ' - ' . $orderItem->post_title;
            $onetimePriceType = apply_filters('fluent_cart/paddle_onetime_price_type', 'custom', [
                'variation' => $variation
            ]);
            // Create price for the product
            $price = Price::getOrCreatePaddleSinglePrice([
                'paddle_product_id'     => $paddleProductId,
                'fct_product_id'        => $variation->post_id,
                'variation_id'          => $variation->id,
                'currency'              => $order->currency,
                'mode'                  => $order->mode,
                'name'                  => $priceName,
                'description'           => $priceDescription,
                'amount'                => (int) $perQuantityAmount,
                'quantity'              => $quantity,
                'type'                  => $onetimePriceType
            ]);

            if (is_wp_error($price)) {
                return $price;
            }

            $prices[] = [
                'price_id' => Arr::get($price, 'data.id'),
                'quantity' => $quantity
            ];

        }


        if ($order->shipping_total > 0) {
            $addonProductType = apply_filters('fluent_cart/paddle_addon_product_type', 'custom', [
                'order' => $order
            ]);
             $shippingProduct = Product::getOrCreateAddOnProduct([
                 'product_id'     => 'fct_paddle_shipping_product_amount_' . $order->shipping_total . '_' . $order->currency . '_' . $order->mode,
                 'currency'       => $order->currency,
                 'mode'           => $order->mode,
                 'name'           => __('Shipping Fee', 'fluent-cart-pro'),
                 'type'           => $addonProductType
             ]);

             if (is_wp_error($shippingProduct)) {
                return $shippingProduct;
            }

            $paddleProductId = Arr::get($shippingProduct, 'data.id');

            // Create price for shipping
            $price = Price::getOrCreatePaddleSinglePrice([
                'paddle_product_id'     => $paddleProductId,
                'fct_product_id' => 0,
                'variation_id'   => 0,
                'currency'       => $order->currency,
                'mode'           => $order->mode,
                'name'           => __('Shipping Fee', 'fluent-cart-pro'),
                'description'    => 'Shipping Fee of ' . (string) ($order->shipping_total / 100) . ' ' . strtoupper($order->currency),
                'amount'         => (int) $order->shipping_total,
                'quantity'       => 1,
                'type'           => $addonProductType,
                'order_id'       =>  $order->id
            ]);

            if (is_wp_error($price)) {
                return $price;
            }

            $prices[] = [
                'price_id' => Arr::get($price, 'data.id'),
                'quantity' => 1
            ];
        }

        return $prices;
    }


    /**
     * Prepare Paddle checkout data for single payment
     */
    private function preparePaddleOneTimeCheckoutData($order, $transaction, $customerId = null)
    {
        $priceIds = $this->getPaddlePriceIdsForOneTimePayment($order);

        if (is_wp_error($priceIds)) {
            return $priceIds;
        }

        $this->persistExpectedCheckoutItems($transaction, $priceIds);

        $totalDiscount = $order->coupon_discount_total + $order->manual_discount_total;

        $discountId = null;
        if ($totalDiscount > 0) {
            $discountMode = apply_filters('fluent_cart/paddle_discount_mode', 'custom', [
                'order' => $order,
                'discount_amount' => $totalDiscount
            ]);
            $discount = Price::createPaddleDiscount($order, $totalDiscount, $discountMode);
            if (is_wp_error($discount)) {
                return $discount;
            }
            $discountId = Arr::get($discount, 'data.id');
        }

        return $this->createPaddleTransaction($order, $transaction, $priceIds, [
            'customer_id' => $customerId,
            'discount_id' => $discountId,
        ]);
    }

    /**
     * Persist the exact Paddle prices sent to checkout on the local transaction,
     * BEFORE any price_id reaches the browser — PaddleReconciler verifies the
     * final charge's line items against this set.
     */
    private function persistExpectedCheckoutItems($transaction, array $priceIds)
    {
        $items = [];
        foreach ($priceIds as $price) {
            $items[] = [
                'price_id' => (string) Arr::get((array) $price, 'price_id', ''),
                'quantity' => max(1, (int) Arr::get((array) $price, 'quantity', 1)),
            ];
        }

        $transaction->meta = array_merge((array) ($transaction->meta ?? []), [
            'paddle_expected_items' => $items,
        ]);
        $transaction->save();
    }

    /**
     * Create the Paddle transaction server-side. Items, discount, currency and
     * custom_data are fixed here before the browser is involved; the checkout
     * overlay only receives the resulting transaction id.
     *
     * Re-submitting a draft order reuses the same local transaction row, so the
     * Paddle transaction prepared last time is looked up first: still open, it is
     * updated in place and reopened; already paid, the payment is recorded and
     * the checkout refused; otherwise it is superseded by a fresh one.
     *
     * @param \FluentCart\App\Models\Order $order
     * @param \FluentCart\App\Models\OrderTransaction $transaction
     * @param array $priceIds [['price_id' => string, 'quantity' => int], ...]
     * @param array $options { customer_id?: string, discount_id?: string, subscription?: \FluentCart\App\Models\Subscription }
     * @return array|\WP_Error
     */
    private function createPaddleTransaction($order, $transaction, $priceIds, array $options = [])
    {
        $transactionData = $this->buildPaddleTransactionData($order, $transaction, $priceIds, $options);

        $meta = (array) ($transaction->meta ?? []);
        $previousId = (string) Arr::get($meta, 'paddle_expected_transaction_id', '');

        if ($previousId !== '') {
            $previous = API::getPaddleObject('transactions/' . $previousId, [], $order->mode);
            $previousStatus = is_wp_error($previous) ? '' : (string) Arr::get($previous, 'data.status', '');

            if (in_array($previousStatus, ['paid', 'completed'], true)) {
                (new Confirmations())->confirmPaymentSuccessByCharge($transaction, [
                    'vendor_charge_id' => $previousId,
                    'charge'           => Arr::get($previous, 'data'),
                ]);

                return new \WP_Error(
                    'paddle_already_paid',
                    __('This order has already been paid. Please refresh the page to see your receipt.', 'fluent-cart-pro')
                );
            }

            if (in_array($previousStatus, ['draft', 'ready'], true)) {
                // PATCH keeps fields it is not given, so a dropped discount must be cleared explicitly.
                $updateData = array_merge(['discount_id' => null], $transactionData);
                $updated = API::updatePaddleObject('transactions/' . $previousId, $updateData, $order->mode);

                if (!is_wp_error($updated)) {
                    $this->persistExpectedTransaction($transaction, $previousId, $options);

                    return $this->checkoutResponse($order, $transaction, $previousId);
                }

                // Two payable checkouts for one order is worse than a retry, so a
                // replacement is only created once the old one is confirmed closed.
                $canceled = API::updatePaddleObject('transactions/' . $previousId, ['status' => 'canceled'], $order->mode);

                if (is_wp_error($canceled)) {
                    return new \WP_Error(
                        'paddle_checkout_replace_failed',
                        __('Your checkout could not be refreshed. Please try again.', 'fluent-cart-pro')
                    );
                }
            }
        }

        $paddleTransaction = API::createPaddleObject('transactions', $transactionData, $order->mode);

        if (is_wp_error($paddleTransaction)) {
            return $paddleTransaction;
        }

        $paddleTransactionId = (string) Arr::get($paddleTransaction, 'data.id');

        $this->persistExpectedTransaction($transaction, $paddleTransactionId, $options, $previousId);

        return $this->checkoutResponse($order, $transaction, $paddleTransactionId);
    }

    private function buildPaddleTransactionData($order, $transaction, $priceIds, array $options): array
    {
        $items = array_map(function ($price) {
            return [
                'price_id' => $price['price_id'],
                'quantity' => (int) $price['quantity']
            ];
        }, $priceIds);

        $transactionData = [
            'items' => $items,
            'custom_data' => PaddleHelper::buildCheckoutCustomData($order, $transaction, Arr::get($options, 'subscription'))
        ];

        if (!empty($options['discount_id'])) {
            // Flat Paddle discounts are currency-bound — a discounted checkout is
            // always pinned to the order currency. The filter below does not apply.
            $transactionData['currency_code'] = strtoupper($order->currency);
            $transactionData['discount_id']   = $options['discount_id'];
        } else {
            $pinCurrency = apply_filters('fluent_cart/paddle_pin_checkout_currency', true, [
                'order'       => $order,
                'transaction' => $transaction,
            ]);

            // Pinned (default): the charge settles in the order currency. Unpinned:
            // Paddle localizes by country; capture takes the cross-currency route.
            if ($pinCurrency) {
                $transactionData['currency_code'] = strtoupper($order->currency);
            }
        }

        if (!empty($options['customer_id'])) {
            $transactionData['customer_id'] = $options['customer_id'];
        }

        return $transactionData;
    }

    /**
     * Record which Paddle transaction may confirm this local one. A replaced
     * transaction id is kept so a late payment on it is logged, not lost silently.
     */
    private function persistExpectedTransaction($transaction, string $paddleTransactionId, array $options, string $supersededId = '')
    {
        $meta = (array) ($transaction->meta ?? []);

        $meta['paddle_expected_transaction_id'] = $paddleTransactionId;

        if (!empty($options['discount_id'])) {
            $meta['paddle_expected_discount_id'] = (string) $options['discount_id'];
        } else {
            unset($meta['paddle_expected_discount_id']);
        }

        if ($supersededId !== '' && $supersededId !== $paddleTransactionId) {
            $superseded = (array) Arr::get($meta, 'paddle_superseded_transaction_ids', []);
            $superseded[] = $supersededId;
            $meta['paddle_superseded_transaction_ids'] = array_values(array_unique($superseded));
        }

        $transaction->meta = $meta;
        $transaction->save();
    }

    private function checkoutResponse($order, $transaction, string $paddleTransactionId): array
    {
        return [
            'paddle_transaction_id' => $paddleTransactionId,
            'total_amount' => PaddleHelper::formatAmount($order->total_amount),
            'currency' => strtoupper($order->currency),
            'return_url' => $transaction->getReceiptPageUrl(),
        ];
    }

}
