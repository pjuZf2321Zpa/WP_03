<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Core\Util\Route;
use BitApps\IntegrationsPro\Triggers\Dokan\DokanController;

Route::get('dokan/get', [DokanController::class, 'getAll']);
Route::post('dokan/get/form', [DokanController::class, 'get_a_form']);
