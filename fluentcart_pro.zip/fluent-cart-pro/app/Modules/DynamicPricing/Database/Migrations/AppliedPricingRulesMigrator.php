<?php

namespace FluentCartPro\App\Modules\DynamicPricing\Database\Migrations;

use FluentCartPro\App\Database\Migrations\DropTable;

class AppliedPricingRulesMigrator
{
    use DropTable;

    public static $tableName = 'fct_applied_pricing_rules';

    /**
     * Migrate the table.
     *
     * @return void
     */
    public static function migrate()
    {
        global $wpdb;

        $charsetCollate = $wpdb->get_charset_collate();
        $table = static::getTableName();

        if ($wpdb->get_var("SHOW TABLES LIKE '$table'") != $table) {
            $sql = "CREATE TABLE $table (
                `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                `order_id` BIGINT UNSIGNED NOT NULL,
                `rule_id` BIGINT UNSIGNED NULL COMMENT 'null when the originating rule has since been deleted',
                `rule_type` VARCHAR(50) NOT NULL,
                `rule_name` VARCHAR(191) NOT NULL COMMENT 'snapshot of the rule display name at apply time',
                `adjustment_type` VARCHAR(50) NOT NULL COMMENT 'discount / fee',
                `adjustment_amount` BIGINT NOT NULL DEFAULT 0 COMMENT 'in cents, negative for discounts',
                `created_at` DATETIME NULL,
                `updated_at` DATETIME NULL,
                PRIMARY KEY  (`id`),
                KEY `order_id` (`order_id`),
                KEY `rule_id` (`rule_id`)
            ) $charsetCollate;";
            dbDelta($sql);
        }
    }
}
