(function () {
  /**
   * Moves the WooCommerce review form (#review_form_wrapper) of the element
   * matched by `selector` into a modal, and puts the trigger button where the
   * form originally was. The trigger and modal shell are rendered by the
   * element's SSR (.bde-review-modal markup).
   */
  function BreakdanceReviewFormModal(selector) {
    var root = document.querySelector(selector);
    if (!root) return;

    // An element can render nested inside another one that also has the modal
    // enabled (e.g. a product's content inside a template's tabs description
    // panel), so only accept nodes whose nearest element root is this root.
    function owned(sel) {
      return Array.prototype.find.call(root.querySelectorAll(sel), function (candidate) {
        return candidate.closest(".bde-product-reviews, .bde-wooproducttabs") === root;
      }) || null;
    }

    var modal = owned(".bde-review-modal");
    var trigger = owned(".bde-review-modal-trigger");
    var content = modal && modal.querySelector(".bde-review-modal__content");
    var body = modal && modal.querySelector(".bde-review-modal__body");
    var form = owned("#review_form_wrapper");
    if (!modal || !trigger || !content || !body || !form) return;

    // The trigger takes the form's original place; the form goes into the modal.
    form.parentNode.insertBefore(trigger, form);
    body.appendChild(form);

    var closeTimer = null;
    var savedPaddingRight = "";

    // The dialog does not stop the page behind it from scrolling, and the
    // panel has its own scrollbar, so the page is pinned while the modal is
    // up. Hiding the page's scrollbar would widen the layout and shift it
    // sideways, so its width is handed back as padding.
    function lockPageScroll() {
      var html = document.documentElement;
      var scrollbarWidth = window.innerWidth - html.clientWidth;
      savedPaddingRight = html.style.paddingRight;
      if (scrollbarWidth > 0) {
        html.style.paddingRight = scrollbarWidth + "px";
      }
      html.style.overflow = "hidden";
    }

    function unlockPageScroll() {
      var html = document.documentElement;
      html.style.overflow = "";
      html.style.paddingRight = savedPaddingRight;
    }

    // Ends the close: dropping [open] is what actually hides the modal, and
    // .is-closing is only what kept it displayed while the animation played.
    function finishClose() {
      if (closeTimer) {
        clearTimeout(closeTimer);
        closeTimer = null;
      }
      if (!modal.classList.contains("is-closing")) return;
      modal.classList.remove("is-closing");
      if (modal.open) modal.close();
    }

    function open() {
      // Cancel a close still animating, then reopen from a clean state so the
      // open animation restarts rather than resuming the sink.
      finishClose();
      if (modal.open) return;
      // showModal() puts the dialog in the top layer, which is what keeps it
      // centred on the viewport even when an ancestor (an entrance animation's
      // transform, a filter, contain) would otherwise capture position:fixed.
      if (typeof modal.showModal === "function") {
        modal.showModal();
      } else {
        modal.setAttribute("open", "");
      }
      lockPageScroll();
    }

    function close() {
      if (!modal.open || modal.classList.contains("is-closing")) return;
      modal.classList.add("is-closing");
      unlockPageScroll();
      // The close animation ending is what normally hides the modal; the
      // timeout is the fallback for when no animation runs at all (a browser
      // that skips them, a background tab that never fires animationend).
      closeTimer = window.setTimeout(finishClose, 400);
    }

    content.addEventListener("animationend", function (e) {
      if (e.target === content) finishClose();
    });

    // Escape is handled by the dialog itself, which would close it instantly;
    // take it over so the close animation plays.
    modal.addEventListener("cancel", function (e) {
      e.preventDefault();
      close();
    });

    // Anything that closes the dialog without going through close() (a nested
    // form submit, a script elsewhere) still has to release the page scroll.
    modal.addEventListener("close", function () {
      modal.classList.remove("is-closing");
      unlockPageScroll();
    });

    trigger.addEventListener("click", open);
    modal.addEventListener("click", function (e) {
      if (e.target.closest(".bde-review-modal__close") || !e.target.closest(".bde-review-modal__content")) {
        close();
      }
    });
  }

  window.BreakdanceReviewFormModal = BreakdanceReviewFormModal;
})();
