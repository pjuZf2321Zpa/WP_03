<?php
/**
 * Divi 5 module registration.
 */

namespace TheLion\Integrations\Divi\D5;

defined('ABSPATH') || exit;

final class Modules
{
    /**
     * Divi 5 class whose absence means Divi 4 is active.
     */
    private const MODULE_LIBRARY = 'ET\Builder\Packages\ModuleLibrary\ModuleRegistration';

    /**
     * Product definitions, keyed by module slug. The slug is also the prefix of the
     * plugin's admin-ajax actions (`{slug}-getpopup`, `{slug}-module-preview`).
     *
     * @return array<string, array<string, string>>
     */
    public static function products(): array
    {
        return [
            'useyourdrive' => [
                'title' => 'Google Drive Module',
                'class' => Modules\UseyourDrive::class,
                'version_constant' => 'USEYOURDRIVE_VERSION',
                'admin_url_constant' => 'USEYOURDRIVE_ADMIN_URL',
                'bridge_product' => 'use-your-drive',
                'default_shortcode' => '[useyourdrive mode="files"]',
            ],
            'outofthebox' => [
                'title' => 'Dropbox Module',
                'class' => Modules\OutoftheBox::class,
                'version_constant' => 'OUTOFTHEBOX_VERSION',
                'admin_url_constant' => 'OUTOFTHEBOX_ADMIN_URL',
                'bridge_product' => 'out-of-the-box',
                'default_shortcode' => '[outofthebox mode="files"]',
            ],
            'letsbox' => [
                'title' => 'Box Module',
                'class' => Modules\LetsBox::class,
                'version_constant' => 'LETSBOX_VERSION',
                'admin_url_constant' => 'LETSBOX_ADMIN_URL',
                'bridge_product' => 'lets-box',
                'default_shortcode' => '[letsbox mode="files"]',
            ],
            'shareonedrive' => [
                'title' => 'OneDrive Module',
                'class' => Modules\ShareoneDrive::class,
                'version_constant' => 'SHAREONEDRIVE_VERSION',
                'admin_url_constant' => 'SHAREONEDRIVE_ADMIN_URL',
                'bridge_product' => 'share-one-drive',
                'default_shortcode' => '[shareonedrive mode="files"]',
            ],
        ];
    }

    /**
     * Definitions for the products that are installed.
     *
     * @return array<string, array<string, string>>
     */
    public static function active(): array
    {
        return array_filter(
            self::products(),
            static fn (string $slug): bool => self::is_product_active($slug),
            ARRAY_FILTER_USE_KEY
        );
    }

    /**
     * True when the product that owns a module is installed.
     */
    public static function is_product_active(string $slug): bool
    {
        $products = self::products();

        return isset($products[$slug])
            && defined($products[$slug]['version_constant'])
            && defined($products[$slug]['admin_url_constant']);
    }

    /**
     * Divi's dependency tree path. Divi 4 never fires the action that reaches this.
     *
     * @param object $dependency_tree Divi's dependency tree manager
     */
    public static function register($dependency_tree): void
    {
        if (!class_exists(self::MODULE_LIBRARY)) {
            return;
        }

        foreach (self::active() as $product) {
            $dependency_tree->add_dependency(new $product['class']());
        }
    }

    /**
     * Register every active module directly.
     *
     * The Divi 5 check must happen before any module class is touched: they implement
     * a Divi 5 interface, so autoloading them under Divi 4 is fatal and a guard inside
     * the class is never reached.
     */
    public static function register_modules(): void
    {
        if (!class_exists(self::MODULE_LIBRARY)) {
            Bootstrap::log('Divi 5 module library not available, skipping registration');

            return;
        }

        $slugs = array_keys(self::active());

        foreach (self::active() as $product) {
            $product['class']::register_module();
        }

        Bootstrap::log('registered: '.(implode(', ', $slugs) ?: 'none'));
    }
}
