/**
 * BuddyBoss Pro Blog Bookmarks — frontend toggle.
 *
 * ES5, no dependencies. Delegated click handler so it works for both the
 * single-post bookmark button and every row rendered on the profile
 * "Bookmarks" tab.
 *
 * @since [BBVERSION]
 */
( function () {
	'use strict';

	function bbBlogProToggleBookmark( button ) {
		if ( ! window.bbBlogProBookmarks || button.getAttribute( 'data-bb-blog-busy' ) ) {
			return;
		}

		var postId = button.getAttribute( 'data-post-id' );

		if ( ! postId ) {
			return;
		}

		button.setAttribute( 'data-bb-blog-busy', '1' );
		button.disabled = true;

		var data    = new window.FormData();
		data.append( 'action', 'bb_blog_pro_toggle_bookmark' );
		data.append( 'nonce', window.bbBlogProBookmarks.nonce );
		data.append( 'post_id', postId );

		window
			.fetch( window.bbBlogProBookmarks.ajaxUrl, {
				method: 'POST',
				credentials: 'same-origin',
				body: data,
			} )
			.then( function ( response ) {
				return response.json();
			} )
			.then( function ( response ) {
				if ( ! response || ! response.success ) {
					return;
				}

				bbBlogProUpdateButton( button, response.data.bookmarked );
			} )
			['catch']( function () {
				// Network/parse error -- leave button state unchanged.
			} )
			.then( function () {
				button.removeAttribute( 'data-bb-blog-busy' );
				button.disabled = false;
			} );
	}

	function bbBlogProUpdateButton( button, bookmarked ) {
		var labels = ( window.bbBlogProBookmarks && window.bbBlogProBookmarks.labels ) || {};

		// Keep the accessible name in sync with the toggle state. Both the
		// Platform Pro and BuddyBoss Theme markups render this button with a
		// server-set aria-label and no visible text node, so the screen-reader
		// label is the only thing to update alongside aria-pressed / the class.
		if ( bookmarked ) {
			button.classList.add( 'is-bookmarked' );
			button.setAttribute( 'aria-pressed', 'true' );
			if( labels.remove ) {
				button.setAttribute( 'aria-label', labels.remove);
				if( button.getAttribute( 'data-balloon' ) !== null ) {
					button.setAttribute( 'data-balloon', labels.remove);
				}
			}
		} else {
			button.classList.remove( 'is-bookmarked' );
			button.setAttribute( 'aria-pressed', 'false' );
			if ( labels.add ) {
				button.setAttribute( 'aria-label', labels.add);
				if( button.getAttribute( 'data-balloon' ) !== null ) {
					button.setAttribute( 'data-balloon', labels.add);
				}
			}
		}
	}

	document.addEventListener( 'click', function ( event ) {
		var button = event.target.closest ? event.target.closest( '.bb-blog-bookmark' ) : null;

		if ( ! button ) {
			return;
		}

		event.preventDefault();
		bbBlogProToggleBookmark( button );
	} );
} )();
