<?php

namespace FluentCartPro\App\Hooks\Handlers\BlockEditors\EmailBlocks\ConditionFallback;

use FluentCart\App\Hooks\Handlers\BlockEditors\BlockEditor;

class ConditionFallbackBlockEditor extends BlockEditor
{
    use \FluentCartPro\App\Contracts\CanEnqueue;
    protected static string $editorName = 'condition-fallback';

    public function getScripts(): array
    {
        return [
            [
                'source'       => 'admin/BlockEditor/EmailBlocks/ConditionFallback/ConditionFallbackBlockEditor.jsx',
                'dependencies' => ['wp-blocks', 'wp-block-editor']
            ]
        ];
    }

    public function getStyles(): array
    {
        return [];
    }

    public function localizeData(): array
    {
        return [
            $this->getLocalizationKey() => [
                'slug'        => $this->slugPrefix,
                'name'        => static::getEditorName(),
                'title'       => __('Condition Fallback', 'fluent-cart-pro'),
                'description' => __('Content shown when the condition is false.', 'fluent-cart-pro'),
            ],
            'fluent_cart_pro_block_translation' => \FluentCartPro\App\Services\Translations\Translations::blockStrings(),
        ];
    }

    public function blockAttributes(): array
    {
        return [];
    }

    public function supports(): array
    {
        return [
            'html'  => false,
            'align' => false,
        ];
    }

    public function render(array $attrs, $block = null, $content = ''): string
    {
        return $content;
    }
}
