<?php

namespace FluentCartPro\App\Hooks\Handlers\BlockEditors\PdfBlocks;

use FluentCart\App\Hooks\Handlers\BlockEditors\BlockEditor;

class ReceiptHeaderBlockEditor extends BlockEditor
{
    use \FluentCartPro\App\Contracts\CanEnqueue;

    protected static string $editorName = 'receipt-header';

    public function getScripts(): array
    {
        return [
            [
                'source'       => 'admin/BlockEditor/PdfBlocks/ReceiptHeaderBlockEditor.jsx',
                'dependencies' => ['wp-blocks', 'wp-components', 'wp-block-editor']
            ]
        ];
    }

    public function getStyles(): array
    {
        return [];
    }

    public function localizeData(): array
    {
        return [
            $this->getLocalizationKey() => [
                'slug'        => $this->slugPrefix,
                'name'        => static::getEditorName(),
                'title'       => __('Receipt Header', 'fluent-cart-pro'),
                'description' => __('Header section with store logo and document title for PDF receipts.', 'fluent-cart-pro'),
            ],
            'fluent_cart_block_translation' => \FluentCart\App\Services\Translations\TransStrings::blockStrings(),
        ];
    }

    public function blockAttributes(): array
    {
        return [
            'title'         => ['type' => 'string', 'default' => 'RECEIPT'],
            'logoPosition'  => ['type' => 'string', 'default' => 'left'],
            'titleColor'    => ['type' => 'string', 'default' => '#0E121B'],
            'titleFontSize' => ['type' => 'number', 'default' => 20],
            'showLogo'      => ['type' => 'boolean', 'default' => true],
        ];
    }

    public function supports(): array
    {
        return [
            'html'       => false,
            'align'      => false,
            'color'      => ['text' => true, 'background' => true],
            'spacing'    => ['margin' => true, 'padding' => true],
        ];
    }


    public function render(array $attrs, $block = null, $content = ''): string
    {
        if (!empty($content)) {
            return $content;
        }

        $title = $attrs['title'] ?? 'RECEIPT';
        $titleColor = $attrs['titleColor'] ?? '#0E121B';
        $titleFontSize = $attrs['titleFontSize'] ?? 20;
        $showLogo = $attrs['showLogo'] ?? true;

        $logoHtml = $showLogo ? '<div>{{settings.store_logo}}</div>' : '';

        return '<div style="display:flex;justify-content:space-between;align-items:center;padding:20px 0;border-bottom:2px solid #E1E4EA;">'
            . $logoHtml
            . '<div style="font-size:' . (int)$titleFontSize . 'px;font-weight:bold;color:' . esc_attr($titleColor) . ';">' . esc_html($title) . '</div>'
            . '</div>';
    }

}
