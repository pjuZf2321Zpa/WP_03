<?php

if (!defined('ABSPATH')) {
    exit;
}
    
use BitApps\IntegrationsPro\Core\Util\Hooks;
use BitApps\IntegrationsPro\Triggers\ConvertPro\ConvertProController;

Hooks::add('cpro_form_submit', [ConvertProController::class, 'handleFormSubmitted'], 10, 2);
