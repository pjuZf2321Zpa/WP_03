<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

function masterstudy_lms_notification_recipients_table_query() {
	global $wpdb;

	$table_name      = masterstudy_lms_notification_recipients_table_name( $wpdb );
	$charset_collate = $wpdb->get_charset_collate();

	$sql = "CREATE TABLE $table_name (
		id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
		notification_id BIGINT(20) UNSIGNED NOT NULL,
		user_id BIGINT(20) UNSIGNED NOT NULL,
		read_at_gmt DATETIME DEFAULT NULL,
		created_at_gmt DATETIME NOT NULL,
		PRIMARY KEY (id),
		UNIQUE KEY notification_user (notification_id,user_id),
		INDEX idx_user_read (user_id,read_at_gmt),
		INDEX idx_user_created (user_id,created_at_gmt),
		INDEX idx_user_created_id (user_id,created_at_gmt,id),
		INDEX idx_user_read_created (user_id,read_at_gmt,created_at_gmt),
		INDEX idx_user_read_created_id (user_id,read_at_gmt,created_at_gmt,id),
		INDEX idx_read_id (read_at_gmt,id),
		INDEX idx_read_created_id (read_at_gmt,created_at_gmt,id),
		INDEX idx_notification_id (notification_id)
	) $charset_collate;";

	require_once ABSPATH . 'wp-admin/includes/upgrade.php';

	dbDelta( $sql );
}
