<?php

namespace BitApps\IntegrationsPro\Actions\Booknetic\Services;

use BookneticApp\Backend\Services\Services\ServiceCatalogService;
use BookneticApp\Models\Appointment;
use BookneticApp\Models\Data;
use BookneticApp\Models\Holiday;
use BookneticApp\Models\Service;
use BookneticApp\Models\ServiceCategory;
use BookneticApp\Models\ServiceExtra;
use BookneticApp\Models\ServiceStaff;
use BookneticApp\Models\SpecialDay;
use BookneticApp\Models\Staff;
use BookneticApp\Models\Timesheet;
use BookneticApp\Providers\Helpers\Helper;
use BookneticApp\Providers\IoC\Container;

final class ServiceService extends BaseService
{
    private const INT_FIELDS = ['category_id', 'duration', 'timeslot_length', 'buffer_before', 'buffer_after', 'max_capacity'];

    private const FLOAT_FIELDS = ['price', 'deposit'];

    private const DEPOSIT_TYPES = ['percent', 'price'];

    public function createService(): array
    {
        $error = $this->validate([
            'name'        => [__('Name', 'bit-integrations-pro')],
            'price'       => [__('Price', 'bit-integrations-pro'), 'numeric'],
            'category_id' => [__('Service Category', 'bit-integrations-pro'), 'integer'],
            'duration'    => [__('Duration in Minutes', 'bit-integrations-pro'), 'integer'],
        ]);

        if ($error !== null) {
            return $error;
        }

        $data = $this->numericFields() + [
            'name'                   => $this->string('name'),
            'is_visible'             => 1,
            'timeslot_length'        => 0,
            'buffer_before'          => 0,
            'buffer_after'           => 0,
            'notes'                  => $this->string('notes'),
            'image'                  => '',
            'is_recurring'           => 0,
            'full_period_type'       => '',
            'full_period_value'      => 0,
            'repeat_type'            => '',
            'recurring_payment_type' => '',
            'repeat_frequency'       => 0,
            'max_capacity'           => 1,
            'color'                  => $this->string('color') ?: '#6c70dc',
            'deposit_type'           => $this->string('deposit_type') ?: 'percent',
            'deposit'                => 0,
            'is_active'              => 1,
            'hide_price'             => 0,
            'hide_duration'          => 0,
        ];

        $serviceError = self::serviceError($data);

        if ($serviceError !== null) {
            return $this->error($serviceError);
        }

        $staffIds = $this->ids('staff_ids');

        if (\count($staffIds) !== (int) Staff::query()->where('id', 'in', $staffIds ?: [0])->count()) {
            return $this->error(__('A selected staff member does not exist. Select different staff members.', 'bit-integrations-pro'));
        }

        $result = $this->createRecord(Service::class, $data);

        if (!$result['success']) {
            return $result;
        }

        $serviceId = (int) $result['data']['id'];

        foreach ($staffIds as $staffId) {
            ServiceStaff::query()->insert(
                [
                    'service_id'   => $serviceId,
                    'staff_id'     => $staffId,
                    'price'        => -1,
                    'deposit'      => -1,
                    'deposit_type' => 'percent',
                ]
            );
        }

        self::syncServiceOrder($serviceId, $data['category_id']);

        return $result;
    }

    public function updateService(): array
    {
        $error = $this->validate(['service_id' => [__('Service ID', 'bit-integrations-pro'), 'integer']]);

        if ($error !== null) {
            return $error;
        }

        $serviceId = $this->int('service_id');
        $service = Service::query()->get($serviceId);

        if (empty($service)) {
            return $this->error(__('The service does not exist. Select a different service.', 'bit-integrations-pro'));
        }

        $data = $this->optionalTextFields([
            'name'         => 'name',
            'notes'        => 'notes',
            'color'        => 'color',
            'deposit_type' => 'deposit_type',
        ]) + $this->numericFields();

        $serviceError = self::serviceError(array_merge($service->toArray(), $data), $serviceId);

        if ($serviceError !== null) {
            return $this->error($serviceError);
        }

        $result = $this->updateRecord(Service::class, $serviceId, $data);

        if ($result['success'] && isset($data['category_id'])) {
            self::syncServiceOrder($serviceId, $data['category_id']);
        }

        return $result;
    }

    public function deleteService(): array
    {
        $error = $this->validate(['service_id' => [__('Service ID', 'bit-integrations-pro'), 'integer']]);

        if ($error !== null) {
            return $error;
        }

        $serviceId = $this->int('service_id');

        if (empty(Service::query()->get($serviceId))) {
            return $this->error(__('The service does not exist. Select a different service.', 'bit-integrations-pro'));
        }

        if (Appointment::query()->where('service_id', $serviceId)->count() > 0) {
            return $this->error(__('The service has appointments. Delete the appointments first.', 'bit-integrations-pro'), 422);
        }

        ServiceExtra::query()->where('service_id', $serviceId)->delete();
        Holiday::query()->where('service_id', $serviceId)->delete();
        SpecialDay::query()->where('service_id', $serviceId)->delete();
        Timesheet::query()->where('service_id', $serviceId)->delete();
        Data::query()->where('table_name', 'services')->where('row_id', $serviceId)->delete();
        ServiceStaff::query()->where('service_id', $serviceId)->delete();

        return $this->deleteRecord(Service::class, $serviceId, __('The service is deleted.', 'bit-integrations-pro'));
    }

    public function duplicateService(): array
    {
        $error = $this->validate(['service_id' => [__('Service ID', 'bit-integrations-pro'), 'integer']]);

        if ($error !== null) {
            return $error;
        }

        $serviceId = $this->int('service_id');

        if (empty(Service::query()->get($serviceId))) {
            return $this->error(__('The service does not exist. Select a different service.', 'bit-integrations-pro'));
        }

        $newId = Container::get(ServiceCatalogService::class)->duplicate($serviceId);

        return $this->success(Service::query()->get($newId));
    }

    public function setServiceStatus(): array
    {
        $error = $this->validate([
            'service_id' => [__('Service ID', 'bit-integrations-pro'), 'integer'],
            'is_active'  => [__('Status', 'bit-integrations-pro')],
        ]);

        if ($error !== null) {
            return $error;
        }

        return $this->updateRecord(Service::class, $this->int('service_id'), ['is_active' => (int) $this->toBool($this->value('is_active'))]);
    }

    private function numericFields(): array
    {
        $data = $this->optionalIntFields(self::INT_FIELDS);

        foreach (self::FLOAT_FIELDS as $field) {
            if ($this->has($field)) {
                $data[$field] = (float) $this->string($field);
            }
        }

        return $data;
    }

    private static function serviceError(array $service, int $serviceId = 0): ?string
    {
        if (empty(ServiceCategory::query()->get((int) $service['category_id']))) {
            return __('The service category does not exist. Select a different category.', 'bit-integrations-pro');
        }

        if ((int) $service['duration'] < 1) {
            return __('The duration is less than 1 minute. Enter 1 or more minutes.', 'bit-integrations-pro');
        }

        if ((float) $service['price'] < 0 || (int) $service['max_capacity'] < 1) {
            return __('The price is less than 0 or the capacity is less than 1. Enter a correct value.', 'bit-integrations-pro');
        }

        if ((int) $service['timeslot_length'] < 0 || (int) $service['buffer_before'] < 0 || (int) $service['buffer_after'] < 0) {
            return __('The timeslot length or a buffer time is less than 0. Enter 0 or more.', 'bit-integrations-pro');
        }

        if (!\in_array($service['deposit_type'], self::DEPOSIT_TYPES, true)) {
            return __('The deposit type is not valid. Use percent or price.', 'bit-integrations-pro');
        }

        $depositLimit = $service['deposit_type'] === 'percent' ? 100 : (float) $service['price'];

        if ((float) $service['deposit'] < 0 || (float) $service['deposit'] > $depositLimit) {
            return __('The deposit is more than the price or 100 percent. Enter a smaller deposit.', 'bit-integrations-pro');
        }

        $nameTaken = Service::query()
            ->where('name', $service['name'])
            ->where('category_id', (int) $service['category_id'])
            ->where('id', '!=', $serviceId)
            ->count();

        return $nameTaken ? __('A service with this name exists in the category. Use a different name.', 'bit-integrations-pro') : null;
    }

    private static function syncServiceOrder(int $serviceId, int $categoryId): void
    {
        $order = json_decode(Helper::getOption('services_order', '[]'), true);

        if (empty($order) || !\is_array($order)) {
            return;
        }

        foreach ($order as $category => $serviceIds) {
            $order[$category] = array_values(array_diff((array) $serviceIds, [$serviceId]));
        }

        $order[$categoryId][] = $serviceId;
        Helper::setOption('services_order', wp_json_encode($order));
    }
}
