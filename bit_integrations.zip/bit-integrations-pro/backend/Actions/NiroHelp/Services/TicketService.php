<?php

namespace BitApps\IntegrationsPro\Actions\NiroHelp\Services;

use BitApps\IntegrationsPro\Actions\NiroHelp\NiroHelpHelper;
use BitApps\IntegrationsPro\Core\Util\Hooks;
use NiroHelp\Models\Event;
use NiroHelp\Models\Ticket;

if (!\defined('ABSPATH')) {
    exit;
}

final class TicketService extends BaseService
{
    private const UPDATABLE_FIELDS = ['title', 'description', 'status', 'urgency', 'product_id', 'reason_id', 'order', 'agent_id'];

    public function createTicket(): array
    {
        $error = $this->validateRequiredFields([
            'title'          => __('Subject', 'bit-integrations-pro'),
            'customer_email' => __('Customer Email', 'bit-integrations-pro'),
        ]);

        if ($error !== null) {
            return $error;
        }

        if (!is_email($this->getString('customer_email'))) {
            return $this->errorResponse(__('The customer email is not valid. Map a valid email address.', 'bit-integrations-pro'));
        }

        $fieldError = $this->checkTicketFields();

        if ($fieldError !== '') {
            return $this->errorResponse($fieldError);
        }

        $customerId = $this->findOrCreateCustomer($this->getString('customer_email'), $this->getString('customer_name'));

        if (is_wp_error($customerId)) {
            return $this->errorResponse($customerId->get_error_message());
        }

        $agentId = (int) $this->getInteger('agent_id');
        $ticketArgs = [
            'title'       => $this->getString('title'),
            'description' => $this->getString('description'),
            'user_id'     => $customerId,
            'status'      => $this->hasValue('status') ? $this->getString('status') : 'open',
            'meta'        => array_merge($this->ticketMeta(), $this->customFieldValues()),
            'taxo'        => [
                NiroHelpHelper::PRODUCT_TAXONOMY => $this->hasValue('product_id') ? [(int) $this->getInteger('product_id')] : [],
                NiroHelpHelper::REASON_TAXONOMY  => $this->hasValue('reason_id') ? [(int) $this->getInteger('reason_id')] : [],
            ],
        ];

        if ($agentId > 0) {
            $ticketArgs['assign'] = false;
        }

        $ticket = new Ticket();
        $ticketId = Event::with_source(
            'import',
            function () use ($ticket, $ticketArgs) {
                return $ticket->create($ticketArgs);
            }
        );

        if (!$ticketId) {
            return $this->errorResponse(__('NiroHelp did not create the ticket. Try again.', 'bit-integrations-pro'));
        }

        if ($agentId > 0) {
            $ticket->set_agent($agentId);
        }

        Hooks::run('nirohelp-tickets-ticket_created', $ticket);

        if ($this->hasValue('send_sign_in_link')) {
            $this->sendSignInLink($ticket);
        }

        return $this->successResponse(__('The ticket is created.', 'bit-integrations-pro'), NiroHelpHelper::getTicketData($ticketId));
    }

    public function updateTicket(): array
    {
        $error = $this->validateRequiredFields(['ticket_id' => __('Ticket ID', 'bit-integrations-pro')]);

        if ($error !== null) {
            return $error;
        }

        $ticket = $this->findTicket();

        if (!$ticket) {
            return $this->ticketNotFound();
        }

        $fieldError = $this->checkTicketFields();

        if ($fieldError !== '') {
            return $this->errorResponse($fieldError);
        }

        $customFields = $this->customFieldValues();
        $hasField = !empty($customFields);

        foreach (self::UPDATABLE_FIELDS as $field) {
            $hasField = $hasField || $this->hasValue($field);
        }

        if (!$hasField) {
            return $this->errorResponse(__('No field is set. Map one or more fields to update.', 'bit-integrations-pro'));
        }

        if ($this->hasValue('title') || $this->hasValue('description') || $this->hasValue('status')) {
            if ($this->hasValue('title')) {
                $ticket->set_title($this->getString('title'));
            }

            if ($this->hasValue('description')) {
                $ticket->set_description($this->getString('description'));
            }

            if ($this->hasValue('status')) {
                $ticket->set_status($this->getString('status'));
            }

            if (!$ticket->save()) {
                return $this->errorResponse(__('NiroHelp did not update the ticket. Try again.', 'bit-integrations-pro'));
            }
        }

        foreach (array_merge($this->ticketMeta(), $customFields) as $key => $value) {
            $ticket->update_meta($key, $value);
        }

        if ($this->hasValue('agent_id')) {
            $ticket->assign_agent((int) $this->getInteger('agent_id'));
        }

        if ($this->hasValue('product_id')) {
            $ticket->set_terms(NiroHelpHelper::PRODUCT_TAXONOMY, [(int) $this->getInteger('product_id')]);
        }

        if ($this->hasValue('reason_id')) {
            $ticket->set_terms(NiroHelpHelper::REASON_TAXONOMY, [(int) $this->getInteger('reason_id')]);
        }

        return $this->successResponse(__('The ticket is updated.', 'bit-integrations-pro'), NiroHelpHelper::getTicketData($ticket->get_id()));
    }

    public function changeTicketStatus(): array
    {
        $error = $this->validateRequiredFields([
            'ticket_id' => __('Ticket ID', 'bit-integrations-pro'),
            'status'    => __('Status', 'bit-integrations-pro'),
        ]);

        if ($error !== null) {
            return $error;
        }

        if (!$this->isTicketStatus($this->getString('status'))) {
            return $this->errorResponse(__('The status does not exist. Select a NiroHelp ticket status.', 'bit-integrations-pro'));
        }

        $ticket = $this->findTicket();

        if (!$ticket) {
            return $this->ticketNotFound();
        }

        if ($ticket->get_status() !== $this->getString('status')) {
            $ticket->set_status($this->getString('status'));

            if (!$ticket->save()) {
                return $this->errorResponse(__('NiroHelp did not change the ticket status. Try again.', 'bit-integrations-pro'));
            }
        }

        return $this->successResponse(__('The ticket status is changed.', 'bit-integrations-pro'), NiroHelpHelper::getTicketData($ticket->get_id()));
    }

    public function assignAgent(): array
    {
        $error = $this->validateRequiredFields([
            'ticket_id' => __('Ticket ID', 'bit-integrations-pro'),
            'agent_id'  => __('Agent', 'bit-integrations-pro'),
        ]);

        if ($error !== null) {
            return $error;
        }

        $agentId = (int) $this->getInteger('agent_id');

        if ($agentId < 0 || ($agentId > 0 && !$this->isAgent($agentId))) {
            return $this->errorResponse(__('The user cannot hold tickets. Select a NiroHelp agent.', 'bit-integrations-pro'));
        }

        $ticket = $this->findTicket();

        if (!$ticket) {
            return $this->ticketNotFound();
        }

        $ticket->assign_agent($agentId);

        return $this->successResponse(__('The ticket agent is changed.', 'bit-integrations-pro'), NiroHelpHelper::getTicketData($ticket->get_id()));
    }

    public function setSentiment(): array
    {
        $error = $this->validateRequiredFields([
            'ticket_id' => __('Ticket ID', 'bit-integrations-pro'),
            'sentiment' => __('Sentiment', 'bit-integrations-pro'),
        ]);

        if ($error !== null) {
            return $error;
        }

        $sentiment = $this->getString('sentiment');

        if ($sentiment !== 'clear' && !\array_key_exists($sentiment, nirohelp_sentiment_labels())) {
            return $this->errorResponse(__('The sentiment does not exist. Select Positive, Neutral, Negative or Clear sentiment.', 'bit-integrations-pro'));
        }

        $ticket = $this->findTicket();

        if (!$ticket) {
            return $this->ticketNotFound();
        }

        nirohelp_set_ticket_sentiment($ticket->get_id(), $sentiment === 'clear' ? '' : $sentiment);

        return $this->successResponse(__('The ticket sentiment is changed.', 'bit-integrations-pro'), NiroHelpHelper::getTicketData($ticket->get_id()));
    }

    public function deleteTicket(): array
    {
        $error = $this->validateRequiredFields(['ticket_id' => __('Ticket ID', 'bit-integrations-pro')]);

        if ($error !== null) {
            return $error;
        }

        $ticket = $this->findTicket();

        if (!$ticket) {
            return $this->ticketNotFound();
        }

        $ticketData = NiroHelpHelper::getTicketData($ticket->get_id());

        if (!$ticket->delete()) {
            return $this->errorResponse(__('NiroHelp did not delete the ticket. Try again.', 'bit-integrations-pro'));
        }

        return $this->successResponse(__('The ticket is deleted.', 'bit-integrations-pro'), $ticketData);
    }

    private function sendSignInLink(Ticket $ticket): void
    {
        $customer = $ticket->get_client();

        if (!$customer) {
            return;
        }

        Hooks::run(
            'nirohelp-tickets-magic_link_sent',
            $customer->user_email,
            nirohelp_login_link($ticket->get_client_id(), $ticket->get_url())
        );
    }

    private function ticketMeta(): array
    {
        $meta = [];

        foreach (['urgency', 'order'] as $key) {
            if ($this->hasValue($key)) {
                $meta[$key] = $this->getString($key);
            }
        }

        return $meta;
    }

    private function isTicketStatus(string $status): bool
    {
        return \array_key_exists($status, nirohelp_ticket_statuses());
    }

    private function checkTicketFields(): string
    {
        if ($this->hasValue('status') && !$this->isTicketStatus($this->getString('status'))) {
            return __('The status does not exist. Select a NiroHelp ticket status.', 'bit-integrations-pro');
        }

        if ($this->hasValue('urgency') && !\array_key_exists($this->getString('urgency'), nirohelp_urgencies())) {
            return __('The urgency does not exist. Select Low, Medium, High or Severe.', 'bit-integrations-pro');
        }

        if ($this->hasValue('product_id') && !$this->termExists('product_id', NiroHelpHelper::PRODUCT_TAXONOMY)) {
            return __('The product does not exist. Select a different product.', 'bit-integrations-pro');
        }

        if ($this->hasValue('reason_id') && !$this->termExists('reason_id', NiroHelpHelper::REASON_TAXONOMY)) {
            return __('The reason does not exist. Select a different reason.', 'bit-integrations-pro');
        }

        $agentId = (int) $this->getInteger('agent_id');

        if ($agentId > 0 && !$this->isAgent($agentId)) {
            return __('The user cannot hold tickets. Select a NiroHelp agent.', 'bit-integrations-pro');
        }

        $unknownField = $this->findUnknownCustomField();

        if ($unknownField !== '') {
            // translators: %s: custom field key
            return \sprintf(__('The custom field %s does not exist. Select a field from the ticket form.', 'bit-integrations-pro'), $unknownField);
        }

        return '';
    }
}
