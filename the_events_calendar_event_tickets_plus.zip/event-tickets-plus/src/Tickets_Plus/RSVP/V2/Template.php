<?php
/**
 * RSVP V2 Template class.
 *
 * @since 6.11.0
 *
 * @package TEC/Tickets_Plus/RSVP/V2
 */

namespace TEC\Tickets_Plus\RSVP\V2;

use Tribe__Template as Base_Template;
use Tribe__Tickets_Plus__Main as Tickets_Plus;

/**
 * RSVP V2 Template class.
 *
 * @since 6.11.0
 *
 * @package TEC/Tickets_Plus/RSVP/V2
 */
class Template extends Base_Template {
	/**
	 * Template constructor.
	 *
	 * @since 6.11.0
	 */
	public function __construct() {
		$this->set_template_origin( tribe( Tickets_Plus::instance() ) );
		$this->set_template_folder( 'src/views/rsvp' );
		$this->set_template_folder_lookup();
		$this->set_template_context_extract( true );
	}
}
