<?php

namespace BitApps\IntegrationsPro\Actions\MicrosoftExcel;

use stdClass;

final class MicrosoftExcelHelper
{
    public const MAX_ROW = 1048576;

    private const MAX_COLUMN = 16384;

    private $apiClient;

    private $fieldData;

    private $input;

    public function __construct($apiClient, $fieldData, $settings)
    {
        $this->apiClient = $apiClient;
        $this->fieldData = (array) $fieldData;
        $this->input = array_merge((array) $settings, $this->fieldData);
    }

    public function value(string $key): string
    {
        $value = $this->input[$key] ?? '';

        return \is_scalar($value) ? trim((string) $value) : '';
    }

    public function missing(array $keys): ?array
    {
        $missing = [];

        foreach ($keys as $key) {
            if ($this->value($key) === '') {
                $missing[] = self::label($key);
            }
        }

        if (empty($missing)) {
            return null;
        }

        // translators: %s: comma separated list of field names
        return self::failure(wp_sprintf(__('%s is required', 'bit-integrations-pro'), implode(', ', $missing)));
    }

    public function mappedButEmpty(string $key): ?array
    {
        if (!\array_key_exists($key, $this->fieldData) || $this->value($key) !== '') {
            return null;
        }

        // translators: %s: field name
        return self::failure(wp_sprintf(__('%s is mapped but has no value', 'bit-integrations-pro'), self::label($key)));
    }

    public function cells(): array
    {
        $cells = [];

        foreach ($this->fieldData as $key => $value) {
            if (!preg_match('/^[A-Z]{1,3}$/D', (string) $key)) {
                continue;
            }

            $column = self::columnIndex($key);

            if ($column <= self::MAX_COLUMN) {
                $cells[$column] = self::cellValue($value);
            }
        }

        ksort($cells);

        return $cells;
    }

    public function appendRow(string $worksheet, array $cells): array
    {
        $usedRange = $this->request('GET', $this->worksheetPath($worksheet, 'usedRange(valuesOnly=true)?$select=rowIndex,rowCount,cellCount'));

        if (!$usedRange['success']) {
            return $usedRange;
        }

        $firstRow = (int) ($usedRange['data']['rowIndex'] ?? 0) + 1;
        $nextRow = $firstRow + (int) ($usedRange['data']['rowCount'] ?? 0);

        if ((int) ($usedRange['data']['cellCount'] ?? 0) === 1) {
            $blank = $this->blankCheck($worksheet);

            if (!$blank['success']) {
                return $blank;
            }

            if ($blank['blank']) {
                $nextRow = $firstRow;
            }
        }

        if ($nextRow > self::MAX_ROW) {
            return self::failure(__('The worksheet has no empty row left below its data', 'bit-integrations-pro'));
        }

        return $this->writeRow($worksheet, $nextRow, $cells);
    }

    public function writeRow(string $worksheet, int $row, array $cells): array
    {
        $firstColumn = array_key_first($cells);
        $lastColumn = array_key_last($cells);
        $values = [];

        for ($column = $firstColumn; $column <= $lastColumn; ++$column) {
            $values[] = $cells[$column] ?? null;
        }

        $address = self::columnName($firstColumn) . $row . ':' . self::columnName($lastColumn) . $row;

        return $this->request('PATCH', $this->worksheetPath($worksheet, self::rangePath($address)), ['values' => [$values]]);
    }

    public function clear(string $worksheet, string $address, string $applyTo): array
    {
        $range = $address === '' ? 'range' : self::rangePath($address);

        return $this->request('POST', $this->worksheetPath($worksheet, $range . '/clear'), ['applyTo' => $applyTo]);
    }

    public function addWorksheet(string $name): array
    {
        return $this->request('POST', $this->workbookPath('worksheets/add'), $name === '' ? new stdClass() : ['name' => $name]);
    }

    public function deleteWorksheet(string $worksheet): array
    {
        return $this->request('DELETE', $this->worksheetPath($worksheet));
    }

    public function createTable(string $worksheet, string $address, bool $hasHeaders): array
    {
        $source = $address === '' ? 'usedRange(valuesOnly=true)' : self::rangePath($address);
        $range = $this->request('GET', $this->worksheetPath($worksheet, $source . '?$select=address,cellCount'));

        if (!$range['success']) {
            return $range;
        }

        if ($address === '' && (int) ($range['data']['cellCount'] ?? 0) === 1) {
            $blank = $this->blankCheck($worksheet);

            if (!$blank['success']) {
                return $blank;
            }

            if ($blank['blank']) {
                return self::failure(__('The worksheet has no data to turn into a table', 'bit-integrations-pro'));
            }
        }

        return $this->request(
            'POST',
            $this->worksheetPath($worksheet, 'tables/add'),
            ['address' => (string) ($range['data']['address'] ?? ''), 'hasHeaders' => $hasHeaders]
        );
    }

    public function deleteTable(string $table): array
    {
        return $this->request('DELETE', $this->workbookPath('tables/' . rawurlencode($table)));
    }

    public static function failure(string $message, int $code = 400): array
    {
        return [
            'success' => false,
            'message' => $message,
            'code'    => $code,
        ];
    }

    private function blankCheck(string $worksheet): array
    {
        $usedRange = $this->request('GET', $this->worksheetPath($worksheet, 'usedRange(valuesOnly=true)?$select=values'));

        if ($usedRange['success']) {
            $usedRange['blank'] = ($usedRange['data']['values'][0][0] ?? '') === '';
        }

        return $usedRange;
    }

    private function workbookPath(string $suffix): string
    {
        return '/me/drive/items/' . rawurlencode($this->value('workbook_id')) . '/workbook/' . $suffix;
    }

    private function worksheetPath(string $worksheet, string $suffix = ''): string
    {
        return $this->workbookPath('worksheets/' . rawurlencode($worksheet) . ($suffix === '' ? '' : '/' . $suffix));
    }

    private function request(string $method, string $path, $body = null): array
    {
        $payload = $body === null ? null : wp_json_encode($body);

        if ($payload === false) {
            return self::failure(__('A mapped value could not be sent to Microsoft Excel. Numbers must be finite.', 'bit-integrations-pro'));
        }

        $headers = $body === null ? [] : ['Content-Type' => 'application/json'];
        $response = $this->apiClient->request($method, $path, $payload, $headers);
        $data = self::toArray($response->getBody());

        if (!$response->success()) {
            $message = \is_array($data) ? ($data['error']['message'] ?? '') : '';

            if (!\is_string($message) || $message === '') {
                $message = $response->getError() ?: __('Microsoft Excel did not accept the request.', 'bit-integrations-pro');
            }

            return [
                'success' => false,
                'message' => $message,
                'code'    => $response->getStatus() ?: 400,
                'data'    => $data,
            ];
        }

        return [
            'success' => true,
            'message' => __('Action completed successfully', 'bit-integrations-pro'),
            'code'    => $response->getStatus(),
            'data'    => $data === '' || $data === null ? ['success' => true] : $data,
        ];
    }

    private static function rangePath(string $address): string
    {
        return "range(address='" . rawurlencode(str_replace("'", "''", $address)) . "')";
    }

    private static function label(string $key): string
    {
        $labels = [
            'name'         => __('Worksheet Name', 'bit-integrations-pro'),
            'range'        => __('Range', 'bit-integrations-pro'),
            'row_number'   => __('Row Number', 'bit-integrations-pro'),
            'table'        => __('Table Name or ID', 'bit-integrations-pro'),
            'workbook_id'  => __('Workbook', 'bit-integrations-pro'),
            'worksheet'    => __('Worksheet Name or ID', 'bit-integrations-pro'),
            'worksheet_id' => __('Worksheet', 'bit-integrations-pro'),
        ];

        return $labels[$key] ?? $key;
    }

    private static function cellValue($value)
    {
        if (\is_scalar($value)) {
            return $value;
        }

        if (\is_array($value) && \count(array_filter($value, 'is_scalar')) === \count($value)) {
            return implode(', ', $value);
        }

        return (string) wp_json_encode($value, JSON_UNESCAPED_UNICODE);
    }

    private static function columnIndex(string $letters): int
    {
        $index = 0;

        foreach (str_split($letters) as $letter) {
            $index = $index * 26 + \ord($letter) - 64;
        }

        return $index;
    }

    private static function columnName(int $index): string
    {
        $name = '';

        while ($index > 0) {
            $name = \chr(65 + ($index - 1) % 26) . $name;
            $index = intdiv($index - 1, 26);
        }

        return $name;
    }

    private static function toArray($value)
    {
        if (\is_object($value)) {
            return json_decode((string) wp_json_encode($value), true);
        }

        return $value;
    }
}
