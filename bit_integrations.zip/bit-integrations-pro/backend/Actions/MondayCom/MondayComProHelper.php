<?php

namespace BitApps\IntegrationsPro\Actions\MondayCom;

final class MondayComProHelper
{
    private const API_URL = 'https://api.monday.com/v2';

    private const API_VERSION = '2023-10';

    public static function createItem($isGetResponse, $fieldData, $integrationDetails, $apiToken)
    {
        $boardId = $integrationDetails->selectedBoard ?? '';
        $groupId = $integrationDetails->selectedGroup ?? '';
        $itemName = $fieldData['item_name'] ?? '';

        if (empty($boardId) || empty($itemName) || empty($apiToken)) {
            return self::requiredParamsError();
        }

        $columnValues = $fieldData;
        unset($columnValues['item_name']);
        $query = <<<'GRAPHQL'
        mutation ($boardId: ID!, $groupId: String, $itemName: String!, $columnValues: JSON) {
            create_item (
                board_id: $boardId,
                group_id: $groupId,
                item_name: $itemName,
                column_values: $columnValues
            ) {
                id
                name
            }
        }
        GRAPHQL;

        return self::request(
            $query,
            [
                'boardId'      => (string) $boardId,
                'groupId'      => $groupId ? (string) $groupId : null,
                'itemName'     => (string) $itemName,
                'columnValues' => wp_json_encode((object) $columnValues),
            ],
            $apiToken
        );
    }

    public static function updateItem($isGetResponse, $fieldData, $integrationDetails, $apiToken)
    {
        $boardId = $integrationDetails->selectedBoard ?? '';
        $itemId = $fieldData['item_id'] ?? '';

        if (empty($boardId) || empty($itemId) || empty($apiToken)) {
            return self::requiredParamsError();
        }

        $columnValues = $fieldData;
        unset($columnValues['item_id']);

        $query = <<<'GRAPHQL'
        mutation ($boardId: ID!, $itemId: ID!, $columnValues: JSON!) {
            change_multiple_column_values(
                board_id: $boardId,
                item_id: $itemId,
                column_values: $columnValues
            ) {
                id
            }
        }
        GRAPHQL;

        return self::request(
            $query,
            [
                'boardId'      => (string) $boardId,
                'itemId'       => (string) $itemId,
                'columnValues' => wp_json_encode((object) $columnValues),
            ],
            $apiToken
        );
    }

    public static function createSubitem($isGetResponse, $fieldData, $integrationDetails, $apiToken)
    {
        $itemId = $integrationDetails->selectedItem ?? '';
        $subitemName = $fieldData['subitem_name'] ?? '';

        if (empty($itemId) || empty($subitemName) || empty($apiToken)) {
            return self::requiredParamsError();
        }

        $query = <<<'GRAPHQL'
        mutation ($itemId: ID!, $subitemName: String!) {
            create_subitem (
                parent_item_id: $itemId,
                item_name: $subitemName
            ) {
                id
                name
                board {
                    id
                    name
                }
            }
        }
        GRAPHQL;

        return self::request(
            $query,
            [
                'itemId'      => (string) $itemId,
                'subitemName' => (string) $subitemName,
            ],
            $apiToken
        );
    }

    public static function moveItemToGroup($isGetResponse, $fieldData, $apiToken)
    {
        $itemId = $fieldData['item_id'] ?? '';
        $groupId = $fieldData['group_id'] ?? '';

        if (empty($itemId) || empty($groupId) || empty($apiToken)) {
            return self::requiredParamsError();
        }

        $query = <<<'GRAPHQL'
        mutation ($itemId: ID!, $groupId: String!) {
            move_item_to_group (
                item_id: $itemId,
                group_id: $groupId
            ) {
                id
                name
                group {
                    id
                    title
                }
            }
        }
        GRAPHQL;

        return self::request(
            $query,
            [
                'itemId'  => (string) $itemId,
                'groupId' => (string) $groupId,
            ],
            $apiToken
        );
    }

    public static function archiveItem($isGetResponse, $fieldData, $apiToken)
    {
        $itemId = $fieldData['item_id'] ?? '';

        if (empty($itemId) || empty($apiToken)) {
            return self::requiredParamsError();
        }

        $query = <<<'GRAPHQL'
        mutation ($itemId: ID!) {
            archive_item (item_id: $itemId) {
                id
            }
        }
        GRAPHQL;

        return self::request($query, ['itemId' => (string) $itemId], $apiToken);
    }

    public static function deleteItem($isGetResponse, $fieldData, $apiToken)
    {
        $itemId = $fieldData['item_id'] ?? '';

        if (empty($itemId) || empty($apiToken)) {
            return self::requiredParamsError();
        }

        $query = <<<'GRAPHQL'
        mutation ($itemId: ID!) {
            delete_item (item_id: $itemId) {
                id
            }
        }
        GRAPHQL;

        return self::request($query, ['itemId' => (string) $itemId], $apiToken);
    }

    public static function archiveBoard($isGetResponse, $fieldData, $apiToken)
    {
        $boardId = $fieldData['board_id'] ?? '';

        if (empty($boardId) || empty($apiToken)) {
            return self::requiredParamsError();
        }

        $query = <<<'GRAPHQL'
        mutation ($boardId: ID!) {
            archive_board (board_id: $boardId) {
                id
            }
        }
        GRAPHQL;

        return self::request($query, ['boardId' => (string) $boardId], $apiToken);
    }

    public static function archiveGroup($isGetResponse, $fieldData, $integrationDetails, $apiToken)
    {
        $boardId = $integrationDetails->selectedBoard ?? '';
        $groupId = $fieldData['group_id'] ?? '';

        if (empty($boardId) || empty($groupId) || empty($apiToken)) {
            return self::requiredParamsError();
        }

        $query = <<<'GRAPHQL'
        mutation ($boardId: ID!, $groupId: String!) {
            archive_group (
                board_id: $boardId,
                group_id: $groupId
            ) {
                id
                archived
            }
        }
        GRAPHQL;

        return self::request(
            $query,
            [
                'boardId' => (string) $boardId,
                'groupId' => (string) $groupId,
            ],
            $apiToken
        );
    }

    public static function deleteGroup($isGetResponse, $fieldData, $integrationDetails, $apiToken)
    {
        $boardId = $integrationDetails->selectedBoard ?? '';
        $groupId = $fieldData['group_id'] ?? '';

        if (empty($boardId) || empty($groupId) || empty($apiToken)) {
            return self::requiredParamsError();
        }

        $query = <<<'GRAPHQL'
        mutation ($boardId: ID!, $groupId: String!) {
            delete_group (
                board_id: $boardId,
                group_id: $groupId
            ) {
                id
                deleted
            }
        }
        GRAPHQL;

        return self::request(
            $query,
            [
                'boardId' => (string) $boardId,
                'groupId' => (string) $groupId,
            ],
            $apiToken
        );
    }

    public static function createGroup($isGetResponse, $fieldData, $integrationDetails, $apiToken)
    {
        $boardId = $integrationDetails->selectedBoard ?? '';
        $groupName = $fieldData['group_name'] ?? '';

        if (empty($boardId) || empty($groupName) || empty($apiToken)) {
            return self::requiredParamsError();
        }

        $query = <<<'GRAPHQL'
        mutation ($boardId: ID!, $groupName: String!) {
            create_group (
                board_id: $boardId,
                group_name: $groupName
            ) {
                id
                title
            }
        }
        GRAPHQL;

        return self::request(
            $query,
            [
                'boardId'   => (string) $boardId,
                'groupName' => (string) $groupName,
            ],
            $apiToken
        );
    }

    public static function duplicateGroup($isGetResponse, $fieldData, $integrationDetails, $apiToken)
    {
        $boardId = $integrationDetails->selectedBoard ?? '';
        $groupId = $fieldData['group_id'] ?? '';
        $groupTitle = $fieldData['group_title'] ?? '';
        $addToTop = !empty($integrationDetails->addToTop);

        if (empty($boardId) || empty($groupId) || empty($groupTitle) || empty($apiToken)) {
            return self::requiredParamsError();
        }

        $query = <<<'GRAPHQL'
        mutation ($boardId: ID!, $groupId: String!, $addToTop: Boolean, $groupTitle: String) {
            duplicate_group (
                board_id: $boardId,
                group_id: $groupId,
                add_to_top: $addToTop,
                group_title: $groupTitle
            ) {
                id
                title
            }
        }
        GRAPHQL;

        return self::request(
            $query,
            [
                'boardId'    => (string) $boardId,
                'groupId'    => (string) $groupId,
                'addToTop'   => $addToTop,
                'groupTitle' => (string) $groupTitle,
            ],
            $apiToken
        );
    }

    public static function createColumn($isGetResponse, $fieldData, $integrationDetails, $apiToken)
    {
        $boardId = $integrationDetails->selectedBoard ?? '';
        $columnType = $integrationDetails->columnType ?? '';
        $columnTitle = $fieldData['column_title'] ?? '';

        if (empty($boardId) || empty($columnTitle) || empty($columnType) || empty($apiToken)) {
            return self::requiredParamsError();
        }

        $query = <<<'GRAPHQL'
        mutation ($boardId: ID!, $columnTitle: String!, $columnType: ColumnType!) {
            create_column (
                board_id: $boardId,
                title: $columnTitle,
                column_type: $columnType
            ) {
                id
                title
                type
            }
        }
        GRAPHQL;

        return self::request(
            $query,
            [
                'boardId'     => (string) $boardId,
                'columnTitle' => (string) $columnTitle,
                'columnType'  => (string) $columnType,
            ],
            $apiToken
        );
    }

    private static function request($query, $variables, $apiToken)
    {
        $httpHelperClass = bit_integrations_get_class('Core\\Util\\HttpHelper');

        return $httpHelperClass::post(
            self::API_URL,
            wp_json_encode(
                [
                    'query'     => $query,
                    'variables' => $variables,
                ]
            ),
            self::setHeaders($apiToken)
        );
    }

    private static function requiredParamsError()
    {
        return (object) ['error' => __('Required params are empty!', 'bit-integrations-pro')];
    }

    private static function setHeaders($apiToken)
    {
        return [
            'Authorization' => $apiToken,
            'Content-Type'  => 'application/json',
            'API-Version'   => self::API_VERSION,
        ];
    }
}
