<?php

use FluentCart\Framework\Http\Router;
use FluentCart\Api\ModuleSettings;
use FluentCartPro\App\Modules\DataExport\Http\Controllers\DataExportController;

/**
 * @var Router $router
 */
$router->prefix( 'data-export/orders' )
    ->withPolicy( 'FluentCart\App\Http\Policies\OrderPolicy' )
    ->group( function ( Router $router ) {
        $router->get( '/schema', [DataExportController::class, 'ordersSchema'] )->meta( [
            'permissions' => 'orders/export',
        ] );
        $router->post( '/batch', [DataExportController::class, 'ordersBatch'] )->meta( [
            'permissions' => 'orders/export',
        ] );
    } );

$router->prefix( 'data-export/customers' )
    ->withPolicy( 'FluentCart\App\Http\Policies\CustomerPolicy' )
    ->group( function ( Router $router ) {
        $router->get( '/schema', [DataExportController::class, 'customersSchema'] )->meta( [
            'permissions' => 'customers/export',
        ] );
        $router->post( '/batch', [DataExportController::class, 'customersBatch'] )->meta( [
            'permissions' => 'customers/export',
        ] );
    } );

$router->prefix( 'data-export/subscriptions' )
    ->withPolicy( 'FluentCart\App\Http\Policies\OrderPolicy' )
    ->group( function ( Router $router ) {
        $router->get( '/schema', [DataExportController::class, 'subscriptionsSchema'] )->meta( [
            'permissions' => 'subscriptions/export',
        ] );
        $router->post( '/batch', [DataExportController::class, 'subscriptionsBatch'] )->meta( [
            'permissions' => 'subscriptions/export',
        ] );
    } );

if ( ModuleSettings::isActive( 'license' ) ) {
    $router->prefix( 'data-export/licenses' )
        ->withPolicy( 'FluentCartPro\App\Http\Policies\LicensePolicy' )
        ->group( function ( Router $router ) {
            $router->get( '/schema', [DataExportController::class, 'licensesSchema'] )->meta( [
                'permissions' => 'licenses/export',
            ] );
            $router->post( '/batch', [DataExportController::class, 'licensesBatch'] )->meta( [
                'permissions' => 'licenses/export',
            ] );
        } );
}
