<?php

namespace BitApps\IntegrationsPro\Actions\FollowUpBoss\Services;

final class UserService extends BaseService
{
    public function deleteUser(): array
    {
        $validationRules = [
            'user_id'           => ['required', 'integer'],
            'assign_to_user_id' => ['required', 'integer'],
        ];
        $error = $this->validateFields(
            $validationRules,
            [
                'user_id'           => __('User ID', 'bit-integrations-pro'),
                'assign_to_user_id' => __('Move People To', 'bit-integrations-pro'),
            ],
            ['assign_to_user_id']
        );

        if ($error !== null) {
            return $error;
        }

        $query = $this->removeEmptyValues(
            [
                'assignTo' => $this->getInteger('assign_to_user_id'),
            ]
        );

        return $this->dispatch('DELETE', '/users/' . rawurlencode($this->getString('user_id')), null, $query);
    }
}
