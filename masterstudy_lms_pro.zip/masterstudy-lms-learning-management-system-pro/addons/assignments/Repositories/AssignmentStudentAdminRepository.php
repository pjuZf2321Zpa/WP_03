<?php

namespace MasterStudy\Lms\Pro\addons\assignments\Repositories;

use MasterStudy\Lms\Plugin\PostType;
use MasterStudy\Lms\Repositories\StudentProgress\ProgressHelper;
use MasterStudy\Lms\Pro\AddonsPlus\Grades\Services\GradeCalculator;

final class AssignmentStudentAdminRepository {
	private const MAX_PER_PAGE      = 100;
	private const MAX_BULK_ITEMS    = 100;
	private const ERROR_FORBIDDEN   = 403;
	private const ERROR_BAD_REQUEST = 400;

	private string $user_assignments_table;

	private AssignmentStudentRepository $student_repository;

	private ProgressHelper $progress_helper;

	public function __construct() {
		global $wpdb;

		$this->user_assignments_table = stm_lms_user_assignments_name( $wpdb );
		$this->student_repository     = new AssignmentStudentRepository();
		$this->progress_helper        = new ProgressHelper();
	}

	public function get_list( array $params ): array {
		global $wpdb;

		$per_page = min( self::MAX_PER_PAGE, max( 1, (int) ( $params['per_page'] ?? 10 ) ) );
		$page     = max( 1, (int) ( $params['page'] ?? 1 ) );
		$offset   = ( $page - 1 ) * $per_page;

		$where_conditions = array(
			'p.post_type = %s',
			"p.post_status IN ('pending', 'publish', 'draft')",
		);
		$where_values     = array( PostType::USER_ASSIGNMENT );

		$this->apply_filters( $params, $where_conditions, $where_values );

		if ( ! current_user_can( 'manage_options' ) ) {
			$where_conditions[] = 'course_post.post_author = %d';
			$where_values[]     = get_current_user_id();
		}

		$where_sql = implode( ' AND ', $where_conditions );

		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare
		$count_sql = $wpdb->prepare(
			"
			SELECT COUNT(DISTINCT p.ID)
			FROM {$wpdb->posts} AS p
			INNER JOIN {$wpdb->postmeta} AS course_meta
				ON course_meta.post_id = p.ID
				AND course_meta.meta_key = 'course_id'
			INNER JOIN {$wpdb->postmeta} AS student_meta
				ON student_meta.post_id = p.ID
				AND student_meta.meta_key = 'student_id'
			LEFT JOIN {$wpdb->postmeta} AS try_meta
				ON try_meta.post_id = p.ID
				AND try_meta.meta_key = 'try_num'
			LEFT JOIN {$wpdb->postmeta} AS status_meta
				ON status_meta.post_id = p.ID
				AND status_meta.meta_key = 'status'
			LEFT JOIN {$wpdb->posts} AS course_post
				ON course_post.ID = CAST(course_meta.meta_value AS UNSIGNED)
			LEFT JOIN {$wpdb->users} AS student_user
				ON student_user.ID = CAST(student_meta.meta_value AS UNSIGNED)
			LEFT JOIN {$this->user_assignments_table} AS assignment_grade
				ON assignment_grade.user_assignment_id = p.ID
			WHERE {$where_sql}
			",
			$where_values
		);
		// phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare

		// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
		$total = (int) $wpdb->get_var( $count_sql );

		$order_by = $this->get_order_by_sql( $params['sort'] ?? '' );

		$list_values = array_merge( $where_values, array( $per_page, $offset ) );
		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber
		$list_sql = $wpdb->prepare(
			"
			SELECT
				p.ID,
				p.post_title,
				p.post_date,
				p.post_status,
				CAST(course_meta.meta_value AS UNSIGNED) AS course_id,
				CAST(student_meta.meta_value AS UNSIGNED) AS student_id,
				CAST(try_meta.meta_value AS UNSIGNED) AS try_num,
				MAX(assignment_grade.grade) AS grade,
				MAX(status_meta.meta_value) AS review_status,
				MAX(course_post.post_title) AS course_title,
				MAX(student_user.display_name) AS student_name,
				MAX(student_user.user_email) AS student_email
			FROM {$wpdb->posts} AS p
			INNER JOIN {$wpdb->postmeta} AS course_meta
				ON course_meta.post_id = p.ID
				AND course_meta.meta_key = 'course_id'
			INNER JOIN {$wpdb->postmeta} AS student_meta
				ON student_meta.post_id = p.ID
				AND student_meta.meta_key = 'student_id'
			LEFT JOIN {$wpdb->postmeta} AS try_meta
				ON try_meta.post_id = p.ID
				AND try_meta.meta_key = 'try_num'
			LEFT JOIN {$wpdb->postmeta} AS status_meta
				ON status_meta.post_id = p.ID
				AND status_meta.meta_key = 'status'
			LEFT JOIN {$wpdb->posts} AS course_post
				ON course_post.ID = CAST(course_meta.meta_value AS UNSIGNED)
			LEFT JOIN {$wpdb->users} AS student_user
				ON student_user.ID = CAST(student_meta.meta_value AS UNSIGNED)
			LEFT JOIN {$this->user_assignments_table} AS assignment_grade
				ON assignment_grade.user_assignment_id = p.ID
			WHERE {$where_sql}
			GROUP BY p.ID
			ORDER BY {$order_by}
			LIMIT %d OFFSET %d
			",
			$list_values
		);
		// phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber

		// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
		$list_results = $wpdb->get_results( $list_sql, ARRAY_A );
		$items        = array();

		if ( is_array( $list_results ) ) {
			foreach ( $list_results as $row ) {
				$status_slug = $this->resolve_status_slug(
					(string) ( $row['review_status'] ?? '' ),
					(string) ( $row['post_status'] ?? '' )
				);

				$post_date = (string) ( $row['post_date'] ?? '' );

				$items[] = array(
					'id'      => (int) $row['ID'],
					'title'   => $this->progress_helper->decode_progress_text( (string) ( $row['post_title'] ?? '' ) ),
					'student' => array(
						'id'    => (int) $row['student_id'],
						'name'  => (string) ( $row['student_name'] ?? '' ),
						'email' => (string) ( $row['student_email'] ?? '' ),
					),
					'course'  => array(
						'id'    => (int) $row['course_id'],
						'title' => $this->progress_helper->decode_progress_text( (string) ( $row['course_title'] ?? '' ) ),
					),
					'date'    => array(
						'raw'       => $post_date,
						'formatted' => ! empty( $post_date ) ? wp_date( get_option( 'date_format' ), strtotime( $post_date ) ) : '',
					),
					'attempt' => (int) ( $row['try_num'] ?? 0 ),
					'grade'   => $this->build_grade_data( (int) $row['ID'], $status_slug, $row['grade'] ?? null ),
					'status'  => array(
						'slug'  => $status_slug,
						'label' => $this->student_repository->get_status_html( $status_slug, false ),
					),
				);
			}
		}

		return array(
			'items'    => $items,
			'total'    => $total,
			'pages'    => (int) ceil( $total / $per_page ),
			'page'     => $page,
			'per_page' => $per_page,
		);
	}

	public function get_details( int $student_assignment_id ): ?array {
		if ( $student_assignment_id <= 0 || PostType::USER_ASSIGNMENT !== get_post_type( $student_assignment_id ) ) {
			return null;
		}

		$course_id = (int) get_post_meta( $student_assignment_id, 'course_id', true );
		if ( ! $this->current_user_can_manage_course( $course_id ) ) {
			return null;
		}

		$student_id    = (int) get_post_meta( $student_assignment_id, 'student_id', true );
		$attempt       = (int) get_post_meta( $student_assignment_id, 'try_num', true );
		$review_status = $this->resolve_status_slug(
			(string) get_post_meta( $student_assignment_id, 'status', true ),
			(string) get_post_status( $student_assignment_id )
		);
		$grade_value   = $this->student_repository->get_grade( $student_assignment_id );
		$settings      = class_exists( '\STM_LMS_Assignments' ) ? \STM_LMS_Assignments::stm_lms_get_settings() : array();
		$user          = get_userdata( $student_id );

		return array(
			'id'         => $student_assignment_id,
			'title'      => $this->progress_helper->decode_progress_text( get_the_title( $student_assignment_id ) ),
			'student'    => array(
				'id'    => $student_id,
				'name'  => $this->student_repository->get_display_name( $student_assignment_id ),
				'email' => $user instanceof \WP_User ? (string) $user->user_email : '',
			),
			'course'     => array(
				'id'    => $course_id,
				'title' => $this->progress_helper->decode_progress_text( get_the_title( $course_id ) ),
			),
			'date'       => get_the_date( get_option( 'date_format' ), $student_assignment_id ),
			'attempt'    => $attempt,
			'status'     => array(
				'slug'  => $review_status,
				'label' => $this->student_repository->get_status_html( $review_status, false ),
			),
			'submission' => array(
				'title'               => $this->progress_helper->decode_progress_text( get_the_title( $student_assignment_id ) ),
				'content'             => $this->progress_helper->normalize_rich_content( (string) get_post_field( 'post_content', $student_assignment_id ) ),
				'student_attachments' => $this->progress_helper->normalize_assignment_attachments( $student_assignment_id, 'student_attachments' ),
			),
			'review'     => array(
				'comment'                => wp_kses_post( (string) get_post_meta( $student_assignment_id, 'editor_comment', true ) ),
				'instructor_attachments' => $this->progress_helper->normalize_assignment_attachments( $student_assignment_id, 'instructor_attachments' ),
				'is_grades_enabled'      => $this->is_grades_review_enabled(),
				'status'                 => $review_status,
				'status_options'         => array(
					array(
						'value' => AssignmentStudentRepository::STATUS_PASSED,
						'label' => esc_html__( 'Passed', 'masterstudy-lms-learning-management-system-pro' ),
					),
					array(
						'value' => AssignmentStudentRepository::STATUS_NOT_PASSED,
						'label' => esc_html__( 'Failed', 'masterstudy-lms-learning-management-system-pro' ),
					),
				),
				'grading'                => $this->build_grading_data( $student_assignment_id, $grade_value ),
				'media_limits'           => array(
					'allow_files'      => ! empty( $settings['assignments_allow_upload_attachments'] ),
					'allow_audio'      => ! empty( $settings['assignments_allow_audio_recording'] ),
					'allow_video'      => ! empty( $settings['assignments_allow_video_recording'] ),
					'files_extensions' => array_values(
						array_filter(
							array_map(
								'trim',
								explode( ',', (string) ( $settings['files_ext'] ?? '' ) )
							)
						)
					),
					'files_max_number' => (int) ( $settings['max_files'] ?? 0 ),
					'files_max_size'   => (int) ( $settings['max_file_size'] ?? 0 ),
					'audio_max_size'   => (int) ( $settings['assignments_audio_recording_maxsize'] ?? 0 ),
					'video_max_size'   => (int) ( $settings['assignments_video_recording_maxsize'] ?? 0 ),
					'icon_base_url'    => trailingslashit( \STM_LMS_URL . 'assets/icons/files/new' ),
				),
			),
		);
	}

	public function delete( int $student_assignment_id ): void {
		if ( $student_assignment_id <= 0 || PostType::USER_ASSIGNMENT !== get_post_type( $student_assignment_id ) ) {
			throw new \RuntimeException(
				esc_html__( 'Invalid student assignment provided for deletion.', 'masterstudy-lms-learning-management-system-pro' ),
				self::ERROR_BAD_REQUEST
			);
		}

		if ( ! $this->current_user_can_manage_course( (int) get_post_meta( $student_assignment_id, 'course_id', true ) ) ) {
			throw new \RuntimeException(
				esc_html__( 'You do not have permission to delete this student assignment.', 'masterstudy-lms-learning-management-system-pro' ),
				self::ERROR_FORBIDDEN
			);
		}

		if ( ! current_user_can( 'delete_post', $student_assignment_id ) ) {
			throw new \RuntimeException(
				esc_html__( 'You do not have permission to delete this student assignment.', 'masterstudy-lms-learning-management-system-pro' ),
				self::ERROR_FORBIDDEN
			);
		}

		$result = wp_delete_post( $student_assignment_id, true );

		if ( false === $result || null === $result ) {
			throw new \RuntimeException(
				sprintf(
					/* translators: %d: student assignment ID. */
					esc_html__( 'Unable to delete student assignment %d.', 'masterstudy-lms-learning-management-system-pro' ),
					$student_assignment_id
				)
			);
		}
	}

	public function bulk_delete( array $student_assignments ): void {
		if ( count( $student_assignments ) > self::MAX_BULK_ITEMS ) {
			throw new \RuntimeException(
				sprintf(
					/* translators: %d: maximum number of student assignments allowed in one bulk request. */
					esc_html__( 'Too many student assignments in one request. Maximum allowed is %d.', 'masterstudy-lms-learning-management-system-pro' ),
					self::MAX_BULK_ITEMS
				),
				self::ERROR_BAD_REQUEST
			);
		}

		foreach ( $student_assignments as $student_assignment ) {
			$this->delete( $this->resolve_student_assignment_id( $student_assignment ) );
		}
	}

	/**
	 * @param array<int, string> $where_conditions
	 * @param array<int, mixed>  $where_values
	 */
	private function apply_filters( array $params, array &$where_conditions, array &$where_values ): void {
		global $wpdb;

		$search = isset( $params['search'] ) ? trim( (string) $params['search'] ) : '';
		if ( '' !== $search ) {
			$like = '%' . $wpdb->esc_like( $search ) . '%';

			$where_conditions[] = '(p.post_title LIKE %s OR course_post.post_title LIKE %s OR student_user.display_name LIKE %s OR student_user.user_email LIKE %s)';
			$where_values[]     = $like;
			$where_values[]     = $like;
			$where_values[]     = $like;
			$where_values[]     = $like;
		}

		$status = isset( $params['status'] ) ? sanitize_text_field( (string) $params['status'] ) : 'all';
		if ( ! empty( $status ) && 'all' !== $status ) {
			if ( AssignmentStudentRepository::STATUS_PENDING === $status ) {
				$where_conditions[] = "(
					status_meta.meta_value = 'pending'
					OR (
						(status_meta.meta_value IS NULL OR status_meta.meta_value = '')
						AND p.post_status = 'pending'
					)
				)";
			} elseif ( AssignmentStudentRepository::STATUS_DRAFT === $status ) {
				$where_conditions[] = "(
					status_meta.meta_value = 'draft'
					OR (
						(status_meta.meta_value IS NULL OR status_meta.meta_value = '')
						AND p.post_status = 'draft'
					)
				)";
			} else {
				$where_conditions[] = 'status_meta.meta_value = %s';
				$where_values[]     = $status;
			}
		}

		$student_id = absint( $params['student_id'] ?? 0 );
		if ( $student_id > 0 ) {
			$where_conditions[] = 'CAST(student_meta.meta_value AS UNSIGNED) = %d';
			$where_values[]     = $student_id;
		}

		$course_id = absint( $params['course_id'] ?? 0 );
		if ( $course_id > 0 ) {
			$where_conditions[] = 'CAST(course_meta.meta_value AS UNSIGNED) = %d';
			$where_values[]     = $course_id;
		}

		$assignment_id = absint( $params['assignment_id'] ?? 0 );
		if ( $assignment_id > 0 ) {
			$where_conditions[] = "EXISTS (
				SELECT 1 FROM {$wpdb->postmeta} AS am
				WHERE am.post_id = p.ID
				AND am.meta_key = 'assignment_id'
				AND CAST(am.meta_value AS UNSIGNED) = %d
			)";
			$where_values[]     = $assignment_id;
		}

		$date_range = isset( $params['date_range'] ) ? trim( (string) $params['date_range'] ) : '';
		if ( '' !== $date_range ) {
			$dates = explode( ',', $date_range );
			$from  = ! empty( $dates[0] ) ? sanitize_text_field( trim( $dates[0] ) ) : '';
			$to    = ! empty( $dates[1] ) ? sanitize_text_field( trim( $dates[1] ) ) : '';

			if ( ! empty( $from ) ) {
				$where_conditions[] = 'DATE(p.post_date) >= %s';
				$where_values[]     = $from;
			}

			if ( ! empty( $to ) ) {
				$where_conditions[] = 'DATE(p.post_date) <= %s';
				$where_values[]     = $to;
			}
		}
	}

	private function get_order_by_sql( string $sort ): string {
		$direction = 'DESC';
		$key       = 'date';

		if ( '' !== $sort && class_exists( '\STM_LMS_Helpers' ) ) {
			$sort_params = \STM_LMS_Helpers::get_sort_params_by_string( $sort );
			$key         = sanitize_key( (string) ( $sort_params['key'] ?? 'date' ) );
			$direction   = strtoupper( (string) ( $sort_params['direction'] ?? 'desc' ) );
			$direction   = in_array( $direction, array( 'ASC', 'DESC' ), true ) ? $direction : 'DESC';
		}

		switch ( $key ) {
			case 'student':
				return "student_user.display_name {$direction}, p.ID DESC";
			case 'course':
				return "course_post.post_title {$direction}, p.ID DESC";
			case 'attempt':
				return "CAST(try_meta.meta_value AS UNSIGNED) {$direction}, p.ID DESC";
			case 'grade':
				return "MAX(assignment_grade.grade) {$direction}, p.ID DESC";
			case 'status':
				return "MAX(status_meta.meta_value) {$direction}, p.ID DESC";
			case 'date':
			default:
				return "p.post_date {$direction}, p.ID DESC";
		}
	}

	private function current_user_can_manage_course( int $course_id ): bool {
		if ( current_user_can( 'manage_options' ) ) {
			return true;
		}

		return $course_id > 0
			&& PostType::COURSE === get_post_type( $course_id )
			&& get_current_user_id() === (int) get_post_field( 'post_author', $course_id );
	}

	private function resolve_status_slug( string $status, string $post_status ): string {
		if ( ! empty( $status ) ) {
			return $status;
		}

		if ( 'draft' === $post_status ) {
			return AssignmentStudentRepository::STATUS_DRAFT;
		}

		return AssignmentStudentRepository::STATUS_PENDING;
	}

	/**
	 * @param mixed $student_assignment
	 */
	private function resolve_student_assignment_id( $student_assignment ): int {
		if ( is_numeric( $student_assignment ) ) {
			return (int) $student_assignment;
		}

		if ( is_array( $student_assignment ) && isset( $student_assignment['id'] ) ) {
			return (int) $student_assignment['id'];
		}

		return 0;
	}

	/**
	 * @return array<string, mixed>
	 */
	private function build_grade_data( int $student_assignment_id, string $status_slug, $raw_grade ): array {
		$grade = null !== $raw_grade && '' !== $raw_grade ? (int) $raw_grade : $this->student_repository->get_grade( $student_assignment_id );

		return array(
			'value' => null !== $grade ? (int) $grade : null,
			'text'  => ( in_array( $status_slug, array( AssignmentStudentRepository::STATUS_PASSED, AssignmentStudentRepository::STATUS_NOT_PASSED ), true ) && null !== $grade )
				? (string) $grade
				: 'N/A',
			'html'  => ( $this->is_grades_review_enabled() && null !== $grade )
				? \MasterStudy\Lms\Pro\AddonsPlus\Grades\Services\GradeDisplay::get_instance()->detailed_render( $grade )
				: '',
		);
	}

	private function build_grading_data( int $student_assignment_id, ?int $grade_percent ): array {
		if ( ! $this->is_grades_review_enabled() ) {
			return array(
				'default_type'   => '',
				'selected_type'  => '',
				'selected_value' => '',
				'options'        => array(
					'grade' => array(),
					'point' => array(),
				),
				'percent'        => array(
					'min' => 0,
					'max' => 100,
				),
				'passing'        => array(),
				'hint'           => array(
					'title'   => '',
					'text'    => '',
					'button'  => '',
					'modal'   => '',
					'entries' => array(),
				),
			);
		}

		$grades_calculator = GradeCalculator::get_instance();
		$default_format    = (string) \STM_LMS_Options::get_option( 'grades_display', 'grade' );
		$grades_table      = $grades_calculator->get_grades_table();
		$passing_grade     = AssignmentStudentRepository::get_passing_grade( $student_assignment_id );
		$grade_type        = (string) get_post_meta( $student_assignment_id, 'grade_type', true );
		$grade_type        = ! empty( $grade_type ) ? $grade_type : $default_format;
		$grade_percent     = null !== $grade_percent ? $grade_percent : $this->student_repository->get_grade( $student_assignment_id );
		$grade_values      = $grades_calculator->calculate( (int) $grade_percent );
		$hint_grade        = ! empty( $grades_table[1] ) ? $grades_table[1] : ( $grades_table[0] ?? null );

		return array(
			'default_type'   => $default_format,
			'selected_type'  => $grade_type,
			'selected_value' => (string) ( $grade_values[ $grade_type ] ?? '' ),
			'options'        => array(
				'grade' => array_map(
					static function ( array $grade ) {
						return array(
							'value' => (string) $grade['grade'],
							'label' => (string) $grade['grade'],
						);
					},
					$grades_table
				),
				'point' => array_map(
					static function ( array $grade ) {
						return array(
							'value' => (string) $grade['point'],
							'label' => (string) $grade['point'],
						);
					},
					$grades_table
				),
			),
			'percent'        => array(
				'min' => $grades_calculator->get_min_range(),
				'max' => $grades_calculator->get_max_range(),
			),
			'passing'        => ! empty( $passing_grade ) ? array(
				'grade'   => sprintf(
					/* translators: %s: Grade. */
					__( 'Minimal passing grade is: %s', 'masterstudy-lms-learning-management-system-pro' ),
					$grades_calculator->get_passing_grade( $passing_grade, 'grade' )
				),
				'point'   => sprintf(
					/* translators: %s: Point. */
					__( 'Minimal passing point is: %s', 'masterstudy-lms-learning-management-system-pro' ),
					$grades_calculator->get_passing_grade( $passing_grade, 'point' )
				),
				'percent' => sprintf(
					/* translators: %s: Percent. */
					__( 'Minimal passing percent is: %s', 'masterstudy-lms-learning-management-system-pro' ),
					$grades_calculator->get_passing_grade( $passing_grade, 'percent' )
				),
			) : array(
				'empty' => __( 'Minimum passing grade is not set.', 'masterstudy-lms-learning-management-system-pro' ),
			),
			'hint'           => array(
				'title'       => __( 'Hint:', 'masterstudy-lms-learning-management-system-pro' ),
				'text'        => ! empty( $hint_grade ) ? sprintf(
					/* translators: %1$s: Point, %2$s: Range Start, %3$s: Range End, %4$s: Grade. */
					__( '%1$s Points = %2$s%% - %3$s%% or "%4$s" grade.', 'masterstudy-lms-learning-management-system-pro' ),
					$hint_grade['point'],
					$hint_grade['range'][0],
					$hint_grade['range'][1],
					$hint_grade['grade']
				) : '',
				'description' => __( 'The highest percentage for chosen Grade or Point will be saved in the system.', 'masterstudy-lms-learning-management-system-pro' ),
				'button'      => __( 'See Table', 'masterstudy-lms-learning-management-system-pro' ),
				'modal'       => __( 'Grades Table', 'masterstudy-lms-learning-management-system-pro' ),
				'entries'     => array_map(
					static function ( array $grade ) {
						return array(
							'grade' => (string) $grade['grade'],
							'point' => (string) $grade['point'],
							'from'  => (int) $grade['range'][0],
							'to'    => (int) $grade['range'][1],
							'color' => (string) $grade['color'],
						);
					},
					$grades_table
				),
			),
		);
	}

	private function is_grades_review_enabled(): bool {
		return \STM_LMS_Helpers::is_pro_plus() && is_ms_lms_addon_enabled( 'grades' );
	}

	/**
	 * @return array<int, array{id:int,label:string}>
	 */
	public function get_student_options(): array {
		$student_ids = array_filter( array_map( 'absint', AssignmentStudentRepository::get_all_students() ) );

		if ( empty( $student_ids ) ) {
			return array();
		}

		$users   = get_users( array( 'include' => $student_ids ) );
		$options = array();

		foreach ( $users as $user ) {
			$display_name = \STM_LMS_User::display_name( $user );

			$options[] = array(
				'id'    => $user->ID,
				'label' => ! empty( $display_name ) ? $display_name : $user->display_name,
			);
		}

		usort(
			$options,
			static function ( array $left, array $right ) {
				return strcasecmp( $left['label'], $right['label'] );
			}
		);

		return $options;
	}

	/**
	 * @return array<int, array{id:int,label:string}>
	 */
	public function get_course_options(): array {
		global $wpdb;

		$course_ids = $wpdb->get_col(
			$wpdb->prepare(
				"
				SELECT DISTINCT CAST(pm.meta_value AS UNSIGNED)
				FROM {$wpdb->postmeta} AS pm
				INNER JOIN {$wpdb->posts} AS p
					ON p.ID = pm.post_id
				WHERE pm.meta_key = 'course_id'
					AND p.post_type = %s
				",
				PostType::USER_ASSIGNMENT
			)
		);
		if ( empty( $course_ids ) ) {
			return array();
		}

		$course_ids = array_filter( array_map( 'absint', $course_ids ) );
		$courses    = get_posts(
			array(
				'post__in'       => $course_ids,
				'post_type'      => 'any',
				'posts_per_page' => -1,
				'no_found_rows'  => true,
			)
		);
		$options    = array();

		foreach ( $courses as $course ) {
			if ( ! empty( $course->post_title ) ) {
				$options[] = array(
					'id'    => $course->ID,
					'label' => $this->progress_helper->decode_progress_text( $course->post_title ),
				);
			}
		}

		usort(
			$options,
			static function ( array $left, array $right ) {
				return strcasecmp( $left['label'], $right['label'] );
			}
		);

		return $options;
	}
}
