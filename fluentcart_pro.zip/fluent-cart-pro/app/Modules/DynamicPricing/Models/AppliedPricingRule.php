<?php

namespace FluentCartPro\App\Modules\DynamicPricing\Models;

use FluentCart\App\Models\Model;
use FluentCart\App\Models\Order;

/**
 *
 *  Database Model for Applied Pricing Rules (audit trail)
 *
 * @package FluentCartPro\App\Modules\DynamicPricing
 *
 * @version 1.0.0
 */
class AppliedPricingRule extends Model
{
    protected $table = 'fct_applied_pricing_rules';

    protected $primaryKey = 'id';

    protected $guarded = ['id'];

    protected $fillable = [
        'order_id',
        'rule_id',
        'rule_type',
        'rule_name',
        'adjustment_type',
        'adjustment_amount',
    ];

    public function order()
    {
        return $this->belongsTo(Order::class, 'order_id', 'id');
    }

    public function rule()
    {
        return $this->belongsTo(PricingRule::class, 'rule_id', 'id');
    }
}
