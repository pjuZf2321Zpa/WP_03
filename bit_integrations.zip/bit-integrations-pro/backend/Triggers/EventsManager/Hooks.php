<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Core\Util\Hooks;
use BitApps\IntegrationsPro\Triggers\EventsManager\EventsManagerController;

// Events Manager routes every booking status transition through one hook, so each
// status trigger registers separately and filters for its own status.
Hooks::add('em_booking_status_changed', [EventsManagerController::class, 'handleBookingStatusChanged'], 20, 2);
Hooks::add('em_booking_status_changed', [EventsManagerController::class, 'handleBookingPending'], 20, 2);
Hooks::add('em_booking_status_changed', [EventsManagerController::class, 'handleBookingApproved'], 20, 2);
Hooks::add('em_booking_status_changed', [EventsManagerController::class, 'handleBookingRejected'], 20, 2);
Hooks::add('em_booking_status_changed', [EventsManagerController::class, 'handleBookingCancelled'], 20, 2);
Hooks::add('em_booking_status_changed', [EventsManagerController::class, 'handleBookingAwaitingPayment'], 20, 2);
Hooks::add('em_booking_status_changed', [EventsManagerController::class, 'handleBookingWaitlisted'], 20, 2);
Hooks::add('em_booking_status_changed', [EventsManagerController::class, 'handleWaitlistApproved'], 20, 2);
Hooks::add('em_booking_status_changed', [EventsManagerController::class, 'handleWaitlistExpired'], 20, 2);
Hooks::add('em_bookings_added', [EventsManagerController::class, 'handleBookingAdded'], 20, 1);
