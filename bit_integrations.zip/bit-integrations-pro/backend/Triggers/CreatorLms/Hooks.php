<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Core\Util\Hooks;
use BitApps\IntegrationsPro\Triggers\CreatorLms\CreatorLmsController;

Hooks::add('creator_lms_after_enrolled_student', [CreatorLmsController::class, 'studentEnrolledInCourse']);
Hooks::add('creator_lms_manual_student_enrollment', [CreatorLmsController::class, 'studentEnrolledInCourse'], 10, 2);
Hooks::add('creator_lms_course_completed', [CreatorLmsController::class, 'studentCompletedCourse'], 10, 3);
Hooks::add('creator_lms_lesson_completed', [CreatorLmsController::class, 'studentCompletedLesson'], 10, 3);
Hooks::add('creatorlms_new_course', [CreatorLmsController::class, 'courseCreated']);
Hooks::add('creatorlms_update_course', [CreatorLmsController::class, 'courseUpdated']);
