<?php

namespace MasterStudy\Lms\Pro\addons\assignments\Http\Controllers\Admin;

use MasterStudy\Lms\Http\WpResponseFactory;
use MasterStudy\Lms\Pro\addons\assignments\Repositories\AssignmentStudentAdminRepository;
use MasterStudy\Lms\Validation\Validator;
use WP_REST_Request;
use WP_REST_Response;

final class GetStudentAssignmentsController {
	public function __invoke( WP_REST_Request $request ): WP_REST_Response {
		$validator = new Validator(
			$request->get_params(),
			array(
				'per_page'      => 'nullable|integer',
				'page'          => 'nullable|integer',
				'search'        => 'nullable|string',
				'status'        => 'nullable|string|contains_list,all;pending;passed;not_passed;draft',
				'student_id'    => 'nullable|integer',
				'course_id'     => 'nullable|integer',
				'assignment_id' => 'nullable|integer',
				'date_range'    => 'nullable|string',
				'sort'          => 'nullable|string',
			)
		);

		if ( $validator->fails() ) {
			return WpResponseFactory::validation_failed( $validator->get_errors_array() );
		}

		return WpResponseFactory::ok_with_data(
			( new AssignmentStudentAdminRepository() )->get_list( $validator->get_validated() )
		);
	}
}
