<?php

/**
 * MailChimp Record Api
 */

namespace BitApps\IntegrationsPro\Actions\MailChimp;

use BitApps\IntegrationsPro\Core\Util\HttpHelper;
class MailChimpRecordHelper
{
    public static function addRemoveTag($module, $data, $endpoint, $defaultHeader)
    {
        $tags = [];
        $isActive = $module == 'add_tag_to_a_member';

        foreach ($data['tags'] as $value) {
            $tags['tags'][] = ['name' => $value, 'status' => $isActive ? 'active' : 'inactive'];
        }

        return HttpHelper::post($endpoint, wp_json_encode($tags), $defaultHeader);
    }

    public static function mapLanguageField($fieldData, $integrationDetails)
    {
        if (isset($integrationDetails->selectedLanguage)) {
            $fieldData['language'] = $integrationDetails->selectedLanguage;
        }

        return $fieldData;
    }

    public static function updateGDPRPermissions($subscriber, $gdprPermissions, $listId, $endPoint, $defaultHeader, $integrationID)
    {
        $logHandlerClass = bit_integrations_get_class('Log\\LogHandler');

        if (empty($subscriber) || empty($subscriber->id) || empty($gdprPermissions)) {
            return;
        }

        $data = [];
        $gdprPermissions = array_map('trim', explode(',', $gdprPermissions));

        foreach ($gdprPermissions as $value) {
            foreach ($subscriber->marketing_permissions as $permission) {
                if (strtolower($permission->text) === strtolower($value)) {
                    $data[] = [
                        'marketing_permission_id' => $permission->marketing_permission_id,
                        'enabled'                 => true
                    ];
                }
            }
        }

        if (!empty($data)) {
            $updateRecordEndpoint = $endPoint . "/lists/{$listId}/members/{$subscriber->id}";
            $data = ['marketing_permissions' => $data];

            $response = HttpHelper::request($updateRecordEndpoint, 'PUT', wp_json_encode($data), $defaultHeader);

            $logType = isset($response->status) && ($response->status === 400 || $response->status === 404) ? 'error' : 'success';

            $logHandlerClass::save($integrationID, ['type' => 'GDPR', 'type_name' => 'Add GDPR'], $logType, wp_json_encode($response));
        }
    }
}
