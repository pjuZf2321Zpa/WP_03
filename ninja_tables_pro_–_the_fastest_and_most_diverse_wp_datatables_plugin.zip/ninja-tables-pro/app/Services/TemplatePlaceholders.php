<?php

namespace NinjaTablesPro\App\Services;

class TemplatePlaceholders
{
    const PLACEHOLDER = '/\{[^\}]*\}/';

    // A whole HTML tag; quoted attribute values may contain ">".
    const TAG = '/<[a-zA-Z](?:"[^"]*"|\'[^\']*\'|[^\'">])*>/';

    const ATTRIBUTE = '/([^\s"\'<>\/=]+)(\s*=\s*)("[^"]*"|\'[^\']*\'|[^\s"\'>]+)/';

    private static $urlAttributes = ['href', 'src', 'action', 'formaction', 'poster', 'xlink:href'];

    /**
     * Fill {group.field} placeholders, escaping each value for where it lands.
     * wp_kses_post() is only safe in HTML text: inside an attribute it keeps
     * quotes and URL schemes, so those placements are escaped here instead.
     *
     * @param string $template
     * @param array  $raw  placeholder => unescaped value
     * @param array  $text placeholder => value already escaped for HTML text
     */
    public static function fill($template, array $raw, array $text)
    {
        $template = (string) $template;

        if (!$raw && !$text) {
            return $template;
        }

        $template = preg_replace_callback(self::TAG, function ($tag) use ($raw) {
            return preg_replace_callback(self::ATTRIBUTE, function ($attr) use ($raw) {
                return self::fillAttribute($attr, $raw);
            }, $tag[0]);
        }, $template);

        // One pass, so a filled-in value is never scanned for placeholders again.
        return preg_replace_callback(self::PLACEHOLDER, function ($match) use ($text, $template) {
            list($placeholder, $offset) = $match[0];

            if (!array_key_exists($placeholder, $text)) {
                return $placeholder;
            }

            // Still inside a tag (bare or malformed attribute): no escaping is safe there.
            if (preg_match('/<[a-zA-Z][^>]*$/', substr($template, 0, $offset))) {
                return '';
            }

            return is_scalar($text[$placeholder]) ? (string) $text[$placeholder] : '';
        }, $template, -1, $count, PREG_OFFSET_CAPTURE);
    }

    private static function fillAttribute($attr, array $raw)
    {
        $name  = strtolower($attr[1]);
        $value = $attr[3];

        if (strpos($value, '{') === false) {
            return $attr[0];
        }

        $quote = ($value[0] === '"' || $value[0] === "'") ? $value[0] : '';
        if ($quote) {
            $value = substr($value, 1, -1);
        }

        $isUrl   = in_array($name, self::$urlAttributes, true);
        $isEvent = strpos($name, 'on') === 0;
        $found   = false;
        $url     = '';
        $filled  = '';
        $cursor  = 0;

        preg_match_all(self::PLACEHOLDER, $value, $matches, PREG_OFFSET_CAPTURE);

        foreach ($matches[0] as $match) {
            list($placeholder, $offset) = $match;

            if (!array_key_exists($placeholder, $raw)) {
                continue;
            }

            $found  = true;
            $static = substr($value, $cursor, $offset - $cursor);
            $cursor = $offset + strlen($placeholder);
            $data   = is_scalar($raw[$placeholder]) ? (string) $raw[$placeholder] : '';

            if ($isUrl) {
                // Encode every "&" so the browser decodes back to exactly the URL checked below.
                $data    = str_replace('&amp;', '&', $data);
                $url    .= html_entity_decode($static, ENT_QUOTES, 'UTF-8') . $data;
                $escaped = htmlspecialchars($data, ENT_QUOTES, 'UTF-8', true);
            } elseif ($isEvent) {
                $escaped = esc_attr(esc_js($data));
            } else {
                $escaped = esc_attr($data);
            }

            // Keep the text pass from treating a value as a placeholder of its own.
            $filled .= $static . str_replace('{', '&#123;', $escaped);
        }

        if (!$found) {
            return $attr[0];
        }

        $static  = substr($value, $cursor);
        $filled .= $static;

        if ($isUrl && !self::isSafeUrl($url . html_entity_decode($static, ENT_QUOTES, 'UTF-8'))) {
            $filled = '#';
        }

        // An unquoted value could add attributes with a space, so it is always quoted.
        $quote = $quote ?: '"';

        return $attr[1] . $attr[2] . $quote . $filled . $quote;
    }

    private static function isSafeUrl($url)
    {
        $url = preg_replace('/[\x00-\x20]+/', '', (string) $url);

        if (!preg_match('/^([a-z][a-z0-9+.\-]*):/i', $url, $scheme)) {
            return true;
        }

        return in_array(strtolower($scheme[1]), wp_allowed_protocols(), true);
    }
}
