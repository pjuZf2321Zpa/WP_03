<?php

namespace WPAICG\Lib\Integrations\Apps;

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

class AIPKit_App_Connections
{
    private const OPTION_NAME = 'aipkit_native_app_recipes';

    /**
     * @return array<string, string>
     */
    public static function get_supported_app_options(): array
    {
        return [
            'slack' => __('Slack', 'gpt3-ai-content-generator'),
            'hubspot' => __('HubSpot', 'gpt3-ai-content-generator'),
            'notion' => __('Notion', 'gpt3-ai-content-generator'),
            'pipedrive' => __('Pipedrive', 'gpt3-ai-content-generator'),
            'zapier' => __('Zapier', 'gpt3-ai-content-generator'),
            'make' => __('Make', 'gpt3-ai-content-generator'),
            'n8n' => __('n8n', 'gpt3-ai-content-generator'),
        ];
    }

    /**
     * @return array<string, string>
     */
    public static function get_supported_auth_options(): array
    {
        return [
            'webhook' => __('Webhook', 'gpt3-ai-content-generator'),
            'token' => __('Token', 'gpt3-ai-content-generator'),
            'api_key' => __('API key', 'gpt3-ai-content-generator'),
            'oauth2' => __('OAuth 2', 'gpt3-ai-content-generator'),
            'custom' => __('Custom', 'gpt3-ai-content-generator'),
        ];
    }

    /**
     * @return array<string, array<int, string>>
     */
    public static function get_supported_auth_types_by_app(): array
    {
        return [
            'slack' => ['token', 'webhook'],
            'hubspot' => ['token'],
            'notion' => ['token'],
            'pipedrive' => ['api_key'],
            'zapier' => ['webhook'],
            'make' => ['webhook'],
            'n8n' => ['webhook'],
        ];
    }

    /**
     * @return array<string, string>
     */
    public static function get_default_auth_types_by_app(): array
    {
        return [
            'slack' => 'token',
            'hubspot' => 'token',
            'notion' => 'token',
            'pipedrive' => 'api_key',
            'zapier' => 'webhook',
            'make' => 'webhook',
            'n8n' => 'webhook',
        ];
    }

    public static function get_default_auth_type_for_app(string $app_slug): string
    {
        $defaults = self::get_default_auth_types_by_app();
        $app_key = sanitize_key($app_slug);

        if (isset($defaults[$app_key])) {
            return $defaults[$app_key];
        }

        return 'webhook';
    }

    public static function is_supported_auth_type_for_app(string $app_slug, string $auth_type): bool
    {
        $app_key = sanitize_key($app_slug);
        $auth_key = sanitize_key($auth_type);
        $supported_auth_types_by_app = self::get_supported_auth_types_by_app();
        $app_auth_types = $supported_auth_types_by_app[$app_key] ?? [];

        return in_array($auth_key, $app_auth_types, true);
    }

    /**
     * @return array<string, array<int, array<string, string>>>
     */
    public static function get_app_field_definitions(): array
    {
        return [
            'slack' => [
                [
                    'group' => 'workspace',
                    'key' => 'default_channel',
                    'label' => __('Default channel', 'gpt3-ai-content-generator'),
                    'type' => 'text',
                    'placeholder' => '#sales-updates',
                    'auth_types' => ['token'],
                ],
                [
                    'group' => 'credentials',
                    'key' => 'webhook_url',
                    'label' => __('Webhook URL', 'gpt3-ai-content-generator'),
                    'type' => 'url',
                    'placeholder' => 'https://hooks.slack.com/services/...',
                    'auth_types' => ['webhook'],
                ],
                [
                    'group' => 'credentials',
                    'key' => 'bot_token',
                    'label' => __('Bot token', 'gpt3-ai-content-generator'),
                    'type' => 'password',
                    'placeholder' => 'xoxb-...',
                    'auth_types' => ['token'],
                ],
            ],
            'hubspot' => [
                [
                    'group' => 'credentials',
                    'key' => 'private_app_token',
                    'label' => __('Private app token', 'gpt3-ai-content-generator'),
                    'type' => 'password',
                    'placeholder' => 'pat-...',
                    'auth_types' => ['token'],
                ],
                [
                    'group' => 'workspace',
                    'key' => 'portal_id',
                    'label' => __('Portal ID', 'gpt3-ai-content-generator'),
                    'type' => 'text',
                    'placeholder' => '1234567',
                    'auth_types' => ['token'],
                ],
                [
                    'group' => 'workspace',
                    'key' => 'default_list_id',
                    'label' => __('Default list ID', 'gpt3-ai-content-generator'),
                    'type' => 'text',
                    'placeholder' => '987654',
                    'auth_types' => ['token'],
                ],
            ],
            'notion' => [
                [
                    'group' => 'credentials',
                    'key' => 'integration_token',
                    'label' => __('Integration token', 'gpt3-ai-content-generator'),
                    'type' => 'password',
                    'placeholder' => 'secret_...',
                    'auth_types' => ['token'],
                ],
                [
                    'group' => 'workspace',
                    'key' => 'parent_page_id',
                    'label' => __('Parent page ID', 'gpt3-ai-content-generator'),
                    'type' => 'text',
                    'placeholder' => __('Enter parent page ID', 'gpt3-ai-content-generator'),
                    'auth_types' => ['token'],
                ],
                [
                    'group' => 'workspace',
                    'key' => 'database_id',
                    'label' => __('Database ID', 'gpt3-ai-content-generator'),
                    'type' => 'text',
                    'placeholder' => __('Target database for items', 'gpt3-ai-content-generator'),
                    'auth_types' => ['token'],
                ],
            ],
            'pipedrive' => [
                [
                    'group' => 'credentials',
                    'key' => 'api_token',
                    'label' => __('API token', 'gpt3-ai-content-generator'),
                    'type' => 'password',
                    'placeholder' => __('Enter API token', 'gpt3-ai-content-generator'),
                    'auth_types' => ['api_key'],
                ],
                [
                    'group' => 'workspace',
                    'key' => 'company_domain',
                    'label' => __('Company domain', 'gpt3-ai-content-generator'),
                    'type' => 'text',
                    'placeholder' => 'your-company',
                    'auth_types' => ['api_key'],
                ],
                [
                    'group' => 'workspace',
                    'key' => 'default_owner_id',
                    'label' => __('Default owner ID', 'gpt3-ai-content-generator'),
                    'type' => 'text',
                    'placeholder' => '12345',
                    'auth_types' => ['api_key'],
                ],
                [
                    'group' => 'workspace',
                    'key' => 'pipeline_id',
                    'label' => __('Pipeline ID', 'gpt3-ai-content-generator'),
                    'type' => 'text',
                    'placeholder' => '1',
                    'auth_types' => ['api_key'],
                ],
            ],
            'zapier' => [
                [
                    'group' => 'credentials',
                    'key' => 'webhook_url',
                    'label' => __('Webhook URL', 'gpt3-ai-content-generator'),
                    'type' => 'url',
                    'placeholder' => 'https://hooks.zapier.com/hooks/catch/...',
                    'auth_types' => ['webhook'],
                ],
                [
                    'group' => 'workspace',
                    'key' => 'zap_name',
                    'label' => __('Zap name', 'gpt3-ai-content-generator'),
                    'type' => 'text',
                    'placeholder' => __('Lead Router', 'gpt3-ai-content-generator'),
                    'auth_types' => ['webhook'],
                ],
            ],
            'make' => [
                [
                    'group' => 'credentials',
                    'key' => 'webhook_url',
                    'label' => __('Webhook URL', 'gpt3-ai-content-generator'),
                    'type' => 'url',
                    'placeholder' => 'https://hook.us1.make.com/...',
                    'auth_types' => ['webhook'],
                ],
                [
                    'group' => 'workspace',
                    'key' => 'scenario_name',
                    'label' => __('Scenario name', 'gpt3-ai-content-generator'),
                    'type' => 'text',
                    'placeholder' => __('Content Sync', 'gpt3-ai-content-generator'),
                    'auth_types' => ['webhook'],
                ],
            ],
            'n8n' => [
                [
                    'group' => 'credentials',
                    'key' => 'webhook_url',
                    'label' => __('Webhook URL', 'gpt3-ai-content-generator'),
                    'type' => 'url',
                    'placeholder' => 'https://n8n.example.com/webhook/...',
                    'auth_types' => ['webhook'],
                ],
                [
                    'group' => 'workspace',
                    'key' => 'workflow_name',
                    'label' => __('Workflow name', 'gpt3-ai-content-generator'),
                    'type' => 'text',
                    'placeholder' => __('Feedback Intake', 'gpt3-ai-content-generator'),
                    'auth_types' => ['webhook'],
                ],
            ],
        ];
    }

    public static function get_connection_field_value(array $connection, string $group, string $key): string
    {
        $group_value = $connection[$group] ?? [];
        if (!is_array($group_value)) {
            return '';
        }

        return sanitize_text_field((string) ($group_value[$key] ?? ''));
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    public static function get_connections(): array
    {
        $store = get_option(self::OPTION_NAME, []);
        if (!is_array($store)) {
            return [];
        }

        $connections = $store['connections'] ?? [];
        if (!is_array($connections)) {
            return [];
        }

        return array_values(array_filter($connections, 'is_array'));
    }

    /**
     * @return array<string, mixed>|null
     */
    public static function get_connection_by_id(string $connection_id): ?array
    {
        $connection_key = sanitize_text_field($connection_id);
        if ($connection_key === '') {
            return null;
        }

        $indexed = self::get_connections_indexed_by_id();

        return isset($indexed[$connection_key]) && is_array($indexed[$connection_key])
            ? $indexed[$connection_key]
            : null;
    }

    /**
     * @param array<int|string, mixed> $raw_connections
     */
    public static function save_connections(array $raw_connections, int $current_user_id = 0): void
    {
        $store = get_option(self::OPTION_NAME, []);
        if (!is_array($store)) {
            $store = [];
        }

        $existing_connections = self::get_connections_indexed_by_id();
        $sanitized_connections = [];

        foreach ($raw_connections as $raw_connection) {
            if (!is_array($raw_connection)) {
                continue;
            }

            $sanitized_connection = self::sanitize_connection(
                $raw_connection,
                $existing_connections,
                $current_user_id
            );

            if ($sanitized_connection === null) {
                continue;
            }

            $sanitized_connections[] = $sanitized_connection;
        }

        $store['connections'] = $sanitized_connections;
        update_option(self::OPTION_NAME, $store, 'no');
    }

    /**
     * @param array<string, mixed> $updates
     */
    public static function update_connection_runtime_state(string $connection_id, array $updates, int $current_user_id = 0): bool
    {
        $connection_key = sanitize_text_field($connection_id);
        if ($connection_key === '') {
            return false;
        }

        $store = get_option(self::OPTION_NAME, []);
        if (!is_array($store)) {
            return false;
        }

        $connections = $store['connections'] ?? [];
        if (!is_array($connections)) {
            return false;
        }

        $updated = false;
        foreach ($connections as $index => $connection) {
            if (!is_array($connection)) {
                continue;
            }

            $current_id = sanitize_text_field((string) ($connection['id'] ?? ''));
            if ($current_id !== $connection_key) {
                continue;
            }

            $app_slug = sanitize_key((string) ($connection['app_slug'] ?? ''));

            if (isset($updates['status'])) {
                $status = sanitize_key((string) $updates['status']);
                if (in_array($status, ['draft', 'active', 'inactive', 'error', 'reauth_required'], true)) {
                    $connection['status'] = $status;
                }
            }

            if (isset($updates['auth_type'])) {
                $auth_type = sanitize_key((string) $updates['auth_type']);
                if (self::is_supported_auth_type_for_app($app_slug, $auth_type)) {
                    $connection['auth_type'] = $auth_type;
                }
            }

            if (isset($updates['is_enabled'])) {
                $connection['is_enabled'] = (string) $updates['is_enabled'] === '1' || $updates['is_enabled'] === true;
            }

            foreach (['credentials', 'workspace'] as $group_name) {
                if (!isset($updates[$group_name]) || !is_array($updates[$group_name])) {
                    continue;
                }

                $existing_group = isset($connection[$group_name]) && is_array($connection[$group_name])
                    ? $connection[$group_name]
                    : [];
                $connection[$group_name] = self::sanitize_connection_group(
                    [$group_name => array_merge($existing_group, $updates[$group_name])],
                    $connection,
                    $app_slug,
                    $group_name
                );
            }

            $existing_meta = isset($connection['meta']) && is_array($connection['meta']) ? $connection['meta'] : [];
            if (isset($updates['meta']) && is_array($updates['meta'])) {
                $connection['meta'] = self::sanitize_meta_updates(array_merge($existing_meta, $updates['meta']));
            } else {
                $connection['meta'] = self::sanitize_meta_updates($existing_meta);
            }

            $connection['updated_by'] = $current_user_id ?: null;
            $connection['updated_at'] = gmdate('c');

            $connections[$index] = $connection;
            $updated = true;
            break;
        }

        if (!$updated) {
            return false;
        }

        $store['connections'] = array_values($connections);
        update_option(self::OPTION_NAME, $store, 'no');

        return true;
    }

    /**
     * @return array<string, array<string, mixed>>
     */
    private static function get_connections_indexed_by_id(): array
    {
        $indexed = [];
        foreach (self::get_connections() as $connection) {
            $connection_id = sanitize_text_field((string) ($connection['id'] ?? ''));
            if ($connection_id === '') {
                continue;
            }

            $indexed[$connection_id] = $connection;
        }

        return $indexed;
    }

    /**
     * @param array<string, mixed> $raw_connection
     * @param array<string, array<string, mixed>> $existing_connections
     * @return array<string, mixed>|null
     */
    private static function sanitize_connection(
        array $raw_connection,
        array $existing_connections,
        int $current_user_id = 0
    ): ?array {
        $supported_apps = self::get_supported_app_options();
        $connection_id = sanitize_text_field((string) ($raw_connection['id'] ?? ''));
        if ($connection_id === '') {
            $connection_id = wp_generate_uuid4();
        }

        $existing_connection = $existing_connections[$connection_id] ?? [];

        $app_slug = sanitize_key((string) ($raw_connection['app_slug'] ?? ''));
        if (!isset($supported_apps[$app_slug])) {
            $app_slug = 'slack';
        }

        $default_auth_type = self::get_default_auth_type_for_app($app_slug);
        $auth_type = sanitize_key((string) ($raw_connection['auth_type'] ?? $default_auth_type));
        if (!self::is_supported_auth_type_for_app($app_slug, $auth_type)) {
            $auth_type = $default_auth_type;
        }

        $status = sanitize_key((string) ($raw_connection['status'] ?? ($existing_connection['status'] ?? 'draft')));
        if (!in_array($status, ['draft', 'active', 'inactive', 'error', 'reauth_required'], true)) {
            $status = 'draft';
        }

        $name = sanitize_text_field((string) ($raw_connection['name'] ?? ''));
        $created_at = sanitize_text_field((string) ($existing_connection['created_at'] ?? gmdate('c')));
        $created_by = isset($existing_connection['created_by']) ? (int) $existing_connection['created_by'] : ($current_user_id ?: null);

        $meta = self::sanitize_meta_updates(
            isset($existing_connection['meta']) && is_array($existing_connection['meta']) ? $existing_connection['meta'] : []
        );
        $workspace = self::sanitize_connection_group($raw_connection, $existing_connection, $app_slug, 'workspace');
        $credentials = self::sanitize_connection_group($raw_connection, $existing_connection, $app_slug, 'credentials');
        if ($existing_connection && (
            $app_slug !== ($existing_connection['app_slug'] ?? '')
            || $auth_type !== ($existing_connection['auth_type'] ?? '')
            || $workspace !== ($existing_connection['workspace'] ?? [])
            || $credentials !== ($existing_connection['credentials'] ?? [])
        )) {
            // Verification belongs to the destination and credentials that were actually tested.
            foreach (array_keys($meta) as $key) {
                if (strpos($key, 'last_test') === 0 || strpos($key, 'last_runtime') === 0) {
                    unset($meta[$key]);
                }
            }
        }

        if (!self::has_required_connection_fields($raw_connection, $existing_connection, $app_slug, $auth_type)) {
            if (in_array($status, ['active', 'error', 'reauth_required'], true)) {
                $status = 'draft';
            }
            $meta['last_test_message'] = __('Add the required credentials before testing this connection.', 'gpt3-ai-content-generator');
        }

        return [
            'id' => $connection_id,
            'app_slug' => $app_slug,
            'name' => $name,
            'auth_type' => $auth_type,
            'status' => $status,
            'is_enabled' => isset($raw_connection['is_enabled']) && (string) ($raw_connection['is_enabled']) === '1',
            'workspace' => $workspace,
            'credentials' => $credentials,
            'capabilities' => isset($existing_connection['capabilities']) && is_array($existing_connection['capabilities']) ? $existing_connection['capabilities'] : [],
            'meta' => $meta,
            'created_by' => $created_by,
            'updated_by' => $current_user_id ?: null,
            'created_at' => $created_at,
            'updated_at' => gmdate('c'),
        ];
    }

    /**
     * @param array<string, mixed> $raw_connection
     * @param array<string, mixed> $existing_connection
     * @return array<string, string>
     */
    private static function sanitize_connection_group(
        array $raw_connection,
        array $existing_connection,
        string $app_slug,
        string $group_name
    ): array {
        $definitions = self::get_app_field_definitions();
        $app_definitions = $definitions[$app_slug] ?? [];
        $existing_group = isset($existing_connection[$group_name]) && is_array($existing_connection[$group_name])
            ? $existing_connection[$group_name]
            : [];
        $raw_group = isset($raw_connection[$group_name]) && is_array($raw_connection[$group_name])
            ? $raw_connection[$group_name]
            : [];

        $sanitized_group = [];
        foreach ($app_definitions as $field_definition) {
            $field_group = sanitize_key((string) ($field_definition['group'] ?? ''));
            if ($field_group !== $group_name) {
                continue;
            }

            $field_key = sanitize_key((string) ($field_definition['key'] ?? ''));
            if ($field_key === '') {
                continue;
            }

            $field_type = sanitize_key((string) ($field_definition['type'] ?? 'text'));
            $raw_value = $raw_group[$field_key] ?? ($existing_group[$field_key] ?? '');
            $sanitized_group[$field_key] = self::sanitize_connection_field_value($raw_value, $field_type);
        }

        return $sanitized_group;
    }

    /**
     * @param mixed $raw_value
     */
    private static function sanitize_connection_field_value($raw_value, string $field_type): string
    {
        if ($field_type === 'url') {
            // Webhook endpoints are integration credentials, not user-facing links.
            // Keep valid http(s) URLs intact instead of aggressively normalizing them away.
            $url_value = trim(str_replace(["\r", "\n", "\t"], '', (string) $raw_value));
            if ($url_value === '') {
                return '';
            }

            if (preg_match('#^https?://#i', $url_value)) {
                return $url_value;
            }

            return sanitize_text_field($url_value);
        }

        return sanitize_text_field((string) $raw_value);
    }

    /**
     * @param array<string, mixed> $raw_connection
     * @param array<string, mixed> $existing_connection
     */
    private static function has_required_connection_fields(
        array $raw_connection,
        array $existing_connection,
        string $app_slug,
        string $auth_type
    ): bool {
        $required_rules_by_app_and_auth = [
            'slack' => [
                'token' => [
                    'mode' => 'all',
                    'fields' => [
                        ['group' => 'credentials', 'key' => 'bot_token'],
                        ['group' => 'workspace', 'key' => 'default_channel'],
                    ],
                ],
                'webhook' => [
                    'mode' => 'all',
                    'fields' => [
                        ['group' => 'credentials', 'key' => 'webhook_url'],
                    ],
                ],
            ],
            'hubspot' => [
                'token' => [
                    'mode' => 'all',
                    'fields' => [
                        ['group' => 'credentials', 'key' => 'private_app_token'],
                    ],
                ],
            ],
            'notion' => [
                'token' => [
                    'mode' => 'all',
                    'fields' => [
                        ['group' => 'credentials', 'key' => 'integration_token'],
                    ],
                ],
            ],
            'pipedrive' => [
                'api_key' => [
                    'mode' => 'all',
                    'fields' => [
                        ['group' => 'credentials', 'key' => 'api_token'],
                        ['group' => 'workspace', 'key' => 'company_domain'],
                    ],
                ],
            ],
            'zapier' => [
                'webhook' => [
                    'mode' => 'all',
                    'fields' => [
                        ['group' => 'credentials', 'key' => 'webhook_url'],
                    ],
                ],
            ],
            'make' => [
                'webhook' => [
                    'mode' => 'all',
                    'fields' => [
                        ['group' => 'credentials', 'key' => 'webhook_url'],
                    ],
                ],
            ],
            'n8n' => [
                'webhook' => [
                    'mode' => 'all',
                    'fields' => [
                        ['group' => 'credentials', 'key' => 'webhook_url'],
                    ],
                ],
            ],
        ];

        $required_rule = $required_rules_by_app_and_auth[$app_slug][$auth_type] ?? null;
        if (!is_array($required_rule) || empty($required_rule['fields']) || !is_array($required_rule['fields'])) {
            return true;
        }

        $mode = sanitize_key((string) ($required_rule['mode'] ?? 'all'));
        $field_values = [];

        foreach ($required_rule['fields'] as $field_definition) {
            $group = sanitize_key((string) ($field_definition['group'] ?? ''));
            $key = sanitize_key((string) ($field_definition['key'] ?? ''));
            if ($group === '' || $key === '') {
                continue;
            }

            $raw_group = isset($raw_connection[$group]) && is_array($raw_connection[$group]) ? $raw_connection[$group] : [];
            $existing_group = isset($existing_connection[$group]) && is_array($existing_connection[$group]) ? $existing_connection[$group] : [];
            $value = sanitize_text_field((string) ($raw_group[$key] ?? ($existing_group[$key] ?? '')));
            $field_values[] = ($value !== '');
        }

        if (empty($field_values)) {
            return true;
        }

        if ($mode === 'any') {
            return in_array(true, $field_values, true);
        }

        return !in_array(false, $field_values, true);
    }

    /**
     * @param array<string, mixed> $meta
     * @return array<string, mixed>
     */
    private static function sanitize_meta_updates(array $meta): array
    {
        $sanitized = isset($meta) && is_array($meta) ? $meta : [];

        if (isset($sanitized['last_test_status'])) {
            $status = sanitize_key((string) $sanitized['last_test_status']);
            if (in_array($status, ['success', 'error', 'reauth_required'], true)) {
                $sanitized['last_test_status'] = $status;
            } else {
                unset($sanitized['last_test_status']);
            }
        }

        if (isset($sanitized['last_test_message'])) {
            $sanitized['last_test_message'] = sanitize_text_field((string) $sanitized['last_test_message']);
        }

        if (isset($sanitized['last_tested_at'])) {
            $sanitized['last_tested_at'] = sanitize_text_field((string) $sanitized['last_tested_at']);
        }

        if (isset($sanitized['last_test_http_code'])) {
            $sanitized['last_test_http_code'] = max(0, (int) $sanitized['last_test_http_code']);
        }

        if (isset($sanitized['last_test_details']) && !is_array($sanitized['last_test_details'])) {
            unset($sanitized['last_test_details']);
        }

        if (isset($sanitized['last_runtime_status'])) {
            $status = sanitize_key((string) $sanitized['last_runtime_status']);
            if (in_array($status, ['success', 'error', 'reauth_required'], true)) {
                $sanitized['last_runtime_status'] = $status;
            } else {
                unset($sanitized['last_runtime_status']);
            }
        }

        if (isset($sanitized['last_runtime_message'])) {
            $sanitized['last_runtime_message'] = sanitize_text_field((string) $sanitized['last_runtime_message']);
        }

        if (isset($sanitized['last_runtime_at'])) {
            $sanitized['last_runtime_at'] = sanitize_text_field((string) $sanitized['last_runtime_at']);
        }

        if (isset($sanitized['last_runtime_http_code'])) {
            $sanitized['last_runtime_http_code'] = max(0, (int) $sanitized['last_runtime_http_code']);
        }

        if (isset($sanitized['last_runtime_attempt_count'])) {
            $sanitized['last_runtime_attempt_count'] = max(0, (int) $sanitized['last_runtime_attempt_count']);
        }

        if (isset($sanitized['last_runtime_details']) && !is_array($sanitized['last_runtime_details'])) {
            unset($sanitized['last_runtime_details']);
        }

        return $sanitized;
    }
}
