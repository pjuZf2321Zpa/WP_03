<?php

namespace FluentCartPro\App\Modules\AccountingExport\Services;

use FluentCart\Api\StoreSettings;
use FluentCart\App\Helpers\Status;
use FluentCart\App\Models\Order;
use FluentCart\App\Models\OrderTransaction;
use FluentCart\App\Modules\MultiCurrency\Services\BaseCurrency;
use FluentCart\App\Modules\MultiCurrency\Services\CurrencySnapshot;
use FluentCart\App\Modules\MultiCurrency\Services\RoundingRules;
use FluentCart\App\Modules\Tax\TaxModule;
use FluentCart\App\Services\Localization\LocalizationManager;
use FluentCart\App\Services\Money;
use FluentCart\Framework\Support\Arr;

/**
 * OSS / accounting-ready rows for one store (multi-currency plan §15.3).
 *
 * One row per order tax line for each sale, and one negative row per tax
 * line for each refund. Amounts are in the order's currency, with the sales
 * rate frozen on the order, base-currency amounts and the ECB EUR rate for
 * the transaction date and its quarter end — every rate an accounting system
 * may need, so FluentCart never picks the conversion rule. This is the
 * store's own data, never a complete OSS return.
 */
class AccountingExportService
{
    const SCHEMA_VERSION = 1;

    /**
     * Charge statuses that mean the money was received: core's `succeeded`
     * (`authorized` is not captured), plus `completed`, `refunded` and
     * `partially_refunded` that older or imported charges carry.
     */
    const PAID_CHARGE_STATUSES = ['succeeded', 'completed', 'refunded', 'partially_refunded'];

    /**
     * Order payment statuses that say money was received. An order in one
     * of these with no paid charge at all (imported, or recorded by hand)
     * is one payment inferred from the order record — see recordPayment().
     */
    const PAID_ORDER_STATUSES = ['paid', 'partially_paid', 'partially_refunded', 'refunded'];

    /** @var array<string, string> memoised ECB lookups, "CUR|date" => rate */
    private $ecbRates = [];

    /** @var bool the rate provider failed (WP_Error) earlier in this batch */
    private $ecbUnavailable = false;

    /** @var array|null */
    private $taxSettings = null;

    /** plans key for the payment inferred from an order record (charge ids are > 0) */
    const RECORD_PAYMENT = 0;

    /** @var array<int, array|null> order id => its payment and refund shares */
    private $plans = [];

    public static function columns(): array
    {
        return [
            ['key' => 'row_type', 'label' => __('Row type', 'fluent-cart-pro')],
            ['key' => 'order_id', 'label' => __('Order ID', 'fluent-cart-pro')],
            ['key' => 'invoice_no', 'label' => __('Invoice number', 'fluent-cart-pro')],
            ['key' => 'transaction_id', 'label' => __('Transaction ID', 'fluent-cart-pro')],
            ['key' => 'date_utc', 'label' => __('Date (UTC)', 'fluent-cart-pro')],
            ['key' => 'period', 'label' => __('Period', 'fluent-cart-pro')],
            ['key' => 'tax_country', 'label' => __('Customer tax country', 'fluent-cart-pro')],
            ['key' => 'tax_scheme', 'label' => __('Tax scheme', 'fluent-cart-pro')],
            ['key' => 'reverse_charge', 'label' => __('Reverse charge', 'fluent-cart-pro')],
            ['key' => 'customer_vat_number', 'label' => __('Customer VAT number', 'fluent-cart-pro')],
            ['key' => 'store_vat_number', 'label' => __('Store VAT number', 'fluent-cart-pro')],
            ['key' => 'tax_label', 'label' => __('Tax label', 'fluent-cart-pro')],
            ['key' => 'tax_rate_percent', 'label' => __('Tax rate (%)', 'fluent-cart-pro')],
            ['key' => 'currency', 'label' => __('Currency', 'fluent-cart-pro')],
            ['key' => 'taxable_amount', 'label' => __('Taxable amount', 'fluent-cart-pro')],
            ['key' => 'tax', 'label' => __('Tax', 'fluent-cart-pro')],
            ['key' => 'order_net', 'label' => __('Order net', 'fluent-cart-pro')],
            ['key' => 'order_tax', 'label' => __('Order tax', 'fluent-cart-pro')],
            ['key' => 'order_gross', 'label' => __('Order gross', 'fluent-cart-pro')],
            ['key' => 'tax_estimated', 'label' => __('Tax estimated', 'fluent-cart-pro')],
            ['key' => 'base_currency', 'label' => __('Base currency', 'fluent-cart-pro')],
            ['key' => 'sales_rate', 'label' => __('Sales rate (per 1 base)', 'fluent-cart-pro')],
            ['key' => 'taxable_amount_base', 'label' => __('Taxable amount (base)', 'fluent-cart-pro')],
            ['key' => 'tax_base', 'label' => __('Tax (base)', 'fluent-cart-pro')],
            ['key' => 'order_gross_base', 'label' => __('Order gross (base)', 'fluent-cart-pro')],
            ['key' => 'ecb_eur_rate_on_date', 'label' => __('ECB rate on date (per 1 EUR)', 'fluent-cart-pro')],
            ['key' => 'ecb_eur_rate_period_end', 'label' => __('ECB rate at period end (per 1 EUR)', 'fluent-cart-pro')],
            ['key' => 'ecb_period_end_date', 'label' => __('Period end date', 'fluent-cart-pro')],
        ];
    }

    public static function schema(): array
    {
        return [
            'entity'         => 'accounting',
            'schema_version' => self::SCHEMA_VERSION,
            'formats'        => ['csv', 'json'],
            'csv_columns'    => self::columns(),
            'json_modules'   => [],
            'schemes'        => self::schemes(),
            'batching'       => ['initial_records' => 100],
            'base_currency'  => BaseCurrency::get(),
            'notice'         => __('This is this store\'s data only. It is not a complete OSS return: a business with several stores files one return for all of them.', 'fluent-cart-pro'),
        ];
    }

    /**
     * @return array<string, string> scheme key => label
     */
    public static function schemes(): array
    {
        return [
            'domestic'       => __('Domestic', 'fluent-cart-pro'),
            'oss'            => __('EU OSS', 'fluent-cart-pro'),
            'eu_other'       => __('EU, other registration', 'fluent-cart-pro'),
            'reverse_charge' => __('EU reverse charge', 'fluent-cart-pro'),
            'non_eu'         => __('Outside the EU', 'fluent-cart-pro'),
            'no_tax'         => __('No tax country', 'fluent-cart-pro'),
        ];
    }

    /**
     * One batch. The cursor walks sales (paid charge transactions by id),
     * then paid orders with no paid charge (orders by id), then refunds
     * (refund transactions by id): "sales:<id>", "records:<id>",
     * "refunds:<id>". At most $limit source rows are read per call.
     *
     * @param array $filters date_from, date_to (Y-m-d, UTC), scheme, include_test
     * @return array{records: array, total: int, has_more: bool, cursor: string, batch: array}
     */
    public function batch(array $filters, $cursor, int $limit): array
    {
        $limit = max(1, min(500, $limit));
        [$phase, $afterId] = $this->parseCursor($cursor);
        $records = [];

        $queries = [
            'sales'   => function () use ($filters) { return $this->salesQuery($filters); },
            'records' => function () use ($filters) { return $this->recordSalesQuery($filters); },
            'refunds' => function () use ($filters) { return $this->refundsQuery($filters); },
        ];
        $after = ['sales' => 'records', 'records' => 'refunds', 'refunds' => ''];
        $capacity = $limit;

        // Sales run on into the order-record sales in the same call while
        // there is room, so a finished sales walk hands over to refunds
        while (true) {
            $sources = $queries[$phase]()
                ->where('id', '>', $afterId)
                ->orderBy('id', 'ASC')
                ->limit($capacity)
                ->get();

            $this->preload($phase === 'records' ? $sources->pluck('id')->all() : $sources->pluck('order_id')->all());

            $lastId = $afterId;
            foreach ($sources as $source) {
                if ($phase === 'sales') {
                    $rows = $this->paymentRows($source);
                } elseif ($phase === 'records') {
                    $rows = $this->recordPaymentRows((int) $source->id);
                } else {
                    $rows = $this->refundRows($source);
                }
                $records = array_merge($records, $rows);
                $lastId = (int) $source->id;
            }
            $count = $sources->count();
            $capacity -= $count;

            if ($count === 0 || $capacity > 0) {
                // this phase is done
                if ($phase === 'sales' && $capacity > 0) {
                    $phase = 'records';
                    $afterId = 0;
                    continue;
                }
                $next = $after[$phase] === '' ? '' : $after[$phase] . ':0';
            } else {
                $next = $phase . ':' . $lastId;
            }
            break;
        }

        $scheme = sanitize_key((string) Arr::get($filters, 'scheme', ''));
        if ($scheme && $scheme !== 'all') {
            $records = array_values(array_filter($records, function ($row) use ($scheme) {
                return $row['tax_scheme'] === $scheme;
            }));
        }

        return [
            'records'  => $records,
            // Rows per transaction vary; the client finishes on has_more
            'total'    => 0,
            'has_more' => $next !== '',
            'cursor'   => $next,
            'batch'    => ['next_max' => $limit],
        ];
    }

    /**
     * Whether $scheme is a tax-scheme filter this export understands.
     */
    public static function isKnownScheme(string $scheme): bool
    {
        return $scheme === 'all' || array_key_exists($scheme, self::schemes());
    }

    /**
     * The whole order as one sale: one row per tax line, each with the base
     * that tax was charged on (taxable_amount) — stacked taxes (state +
     * county, GST + PST) show the same base twice. Any part of the order no
     * tax line covers (untaxed shipping, fees, exempt items) is a 0% row of
     * its own. The basis every payment and refund row is a share of.
     */
    public function saleRows(Order $order): array
    {
        $basis = $this->basis($order);
        $transactionId = $this->chargeTransactionId($order);
        $gross = (int) $order->total_amount;
        $disjoint = array_sum($basis['base']) === $gross - array_sum($basis['tax']);
        $conversion = $disjoint ? $this->conversion($order) : null;
        $inBase = $conversion ? $this->wholeInBase($basis, $gross, $conversion) : null;

        $rows = [];
        foreach ($basis['lines'] as $index => $line) {
            $rows[] = $this->row('sale', $order, $line, [
                'transaction_id' => $transactionId,
                'date'           => (string) $order->created_at,
                'taxable'        => $basis['base'][$index],
                'tax'            => $basis['tax'][$index],
                'order_tax'      => array_sum($basis['tax']),
                'order_gross'    => $gross,
                'tax_estimated'  => false,
                'in_base'        => $inBase ? ['taxable' => $inBase['base'][$index], 'tax' => $inBase['tax'][$index], 'gross' => $inBase['gross']] : null,
            ]);
        }

        return $rows;
    }

    /**
     * The order's tax lines (plus a 0% line for any untaxed part) with each
     * line's base and tax: what every payment and refund is a share of.
     *
     * @return array{lines: array, base: int[], tax: int[]}
     */
    private function basis(Order $order): array
    {
        $lines = $this->taxLines($order);
        $orderTax = array_sum(array_map(function ($line) {
            return (int) $line->total_tax;
        }, $lines));

        [$lines, $bases] = $this->lineBases($lines, (int) $order->total_amount - $orderTax, $this->taxedNet($order, $lines));

        $untaxed = null;
        foreach ($lines as $index => $line) {
            if ((float) Arr::get($this->meta($line), 'rate_percent', 0) <= 0) {
                $untaxed = $index;
                break;
            }
        }

        return [
            'lines'   => $lines,
            'base'    => $bases,
            'tax'     => array_map(function ($line) { return (int) $line->total_tax; }, $lines),
            'untaxed' => $untaxed,
        ];
    }

    /**
     * Rows for one payment (a paid charge), dated when it was paid. An
     * order paid at once gives the order's own figures; a part payment
     * gives its share of every line — see allocate().
     */
    public function paymentRows(OrderTransaction $charge): array
    {
        $plan = $this->plan((int) $charge->order_id);
        if (!$plan || !isset($plan['payments'][(int) $charge->id])) {
            return [];
        }

        $part = $plan['payments'][(int) $charge->id];
        if ($part['gross'] <= 0 && $plan['gross'] > 0) {
            return [];
        }

        return $this->partRows('sale', $plan, $part, $charge, $this->paidAt($charge), 1);
    }

    /**
     * Negative rows for one refund, dated by the refund transaction.
     * FluentCart records a refund's total only, so each line's base and tax
     * are estimated in proportion to the order — flagged in tax_estimated.
     * The refund that returns everything paid takes what the payments left,
     * so a fully refunded order nets to exactly zero.
     */
    public function refundRows(OrderTransaction $refund): array
    {
        $plan = $this->plan((int) $refund->order_id);
        if (!$plan || !isset($plan['refunds'][(int) $refund->id])) {
            return [];
        }

        $part = $plan['refunds'][(int) $refund->id];
        if ($part['gross'] <= 0) {
            return [];
        }

        return $this->partRows('refund', $plan, $part, $refund, (string) $refund->created_at, -1);
    }

    /**
     * Rows for a paid order that has no paid charge: one payment inferred
     * from the order record, dated by completed_at, else created_at. No
     * transaction id, and marked as estimated.
     */
    public function recordPaymentRows(int $orderId): array
    {
        $plan = $this->plan($orderId);
        if (!$plan || !isset($plan['payments'][self::RECORD_PAYMENT])) {
            return [];
        }

        $order = $plan['order'];
        $date = (string) ($order->completed_at ?: $order->created_at);

        return $this->partRows('sale', $plan, $plan['payments'][self::RECORD_PAYMENT], null, $date, 1);
    }

    private function partRows(string $type, array $plan, array $part, ?OrderTransaction $transaction, string $date, int $sign): array
    {
        $rows = [];
        foreach ($plan['lines'] as $index => $line) {
            $rows[] = $this->row($type, $plan['order'], $line, [
                'transaction_id' => $transaction ? (string) ($transaction->uuid ?: $transaction->id) : '',
                'date'           => $date,
                'taxable'        => $sign * $part['base'][$index],
                'tax'            => $sign * $part['tax'][$index],
                'order_tax'      => $sign * array_sum($part['tax']),
                'order_gross'    => $sign * $part['gross'],
                'tax_estimated'  => $part['estimated'],
                'in_base'        => isset($part['in_base']) ? [
                    'taxable' => $sign * $part['in_base']['base'][$index],
                    'tax'     => $sign * $part['in_base']['tax'][$index],
                    'gross'   => $sign * $part['in_base']['gross'],
                ] : null,
                // what the transactions before it took, for the base amounts
                'before'         => [
                    'taxable' => $part['before']['base'][$index],
                    'tax'     => $part['before']['tax'][$index],
                    'gross'   => $part['before']['gross'],
                ],
            ]);
        }

        return array_map([$this, 'publicRow'], $rows);
    }

    /**
     * Load the orders (with their tax lines and items), paid charges and
     * refunds of a batch in four queries.
     *
     * @param int[] $orderIds
     */
    private function preload(array $orderIds): void
    {
        $orderIds = array_values(array_diff(array_unique(array_map('intval', $orderIds)), array_keys($this->plans)));
        if (!$orderIds) {
            return;
        }

        $orders = Order::query()->with(['orderTaxRates', 'order_items'])->whereIn('id', $orderIds)->get()->keyBy('id');
        $transactions = OrderTransaction::query()
            ->whereIn('order_id', $orderIds)
            ->where(function ($query) {
                $query->where(function ($charges) {
                    $charges->where('transaction_type', Status::TRANSACTION_TYPE_CHARGE)
                        ->whereIn('status', self::PAID_CHARGE_STATUSES);
                })->orWhere(function ($refunds) {
                    $refunds->where('transaction_type', Status::TRANSACTION_TYPE_REFUND)
                        ->where('status', Status::TRANSACTION_REFUNDED);
                });
            })
            ->orderBy('id', 'ASC')
            ->get();

        $byOrder = [];
        foreach ($transactions as $transaction) {
            $byOrder[(int) $transaction->order_id][$transaction->transaction_type][] = $transaction;
        }

        foreach ($orderIds as $orderId) {
            $order = $orders->get($orderId);
            $this->plans[$orderId] = $order ? $this->buildPlan(
                $order,
                $byOrder[$orderId][Status::TRANSACTION_TYPE_CHARGE] ?? [],
                $byOrder[$orderId][Status::TRANSACTION_TYPE_REFUND] ?? []
            ) : null;
        }
    }

    private function plan(int $orderId): ?array
    {
        if (!array_key_exists($orderId, $this->plans)) {
            $this->preload([$orderId]);
        }

        return $this->plans[$orderId] ?? null;
    }

    /**
     * Every payment's and refund's share of one order, in the order's
     * currency, in whole units of a zero-decimal currency:
     *  - payments in id order (all of the order's, whatever period is
     *    exported); everything paid so far is that / order total of every
     *    line, rounded once, and each payment takes the step from the one
     *    before (see allocate()): never negative, and the payment that
     *    completes the order lands on its lines exactly;
     *  - refunds in id order, the same way against what was paid; the
     *    refund that returns everything paid takes what is left.
     */
    private function buildPlan(Order $order, array $charges, array $refunds): array
    {
        $basis = $this->basis($order);
        $gross = (int) $order->total_amount;
        $unit = $this->unit((string) $order->currency);
        $whole = ['tax' => $basis['tax'], 'base' => $basis['base']];
        $disjoint = array_sum($whole['base']) === $gross - array_sum($whole['tax']);

        $amounts = [];
        foreach ($charges as $charge) {
            $amounts[(int) $charge->id] = (int) $charge->total;
        }
        // No paid charge at all, but the order says it was paid: one
        // payment from the order record (never mixed with charges)
        $fromRecord = !$charges && $this->recordPayment($order) !== null;
        if ($fromRecord) {
            $amounts[self::RECORD_PAYMENT] = $this->recordPayment($order);
        }
        $payments = $this->allocate($amounts, $gross, $gross, $whole, $disjoint, $unit, $basis['untaxed']);
        if ($fromRecord) {
            $payments[self::RECORD_PAYMENT]['estimated'] = true;
        }

        // Refunds share out what was paid; an order with no payment at all
        // (older data) is taken as paid in full
        $paid = array_sum(array_column($payments, 'gross'));
        $paidParts = $payments ? [
            'tax'  => $this->sumParts($payments, 'tax', count($basis['lines'])),
            'base' => $this->sumParts($payments, 'base', count($basis['lines'])),
        ] : $whole;
        if (!$payments) {
            $paid = $gross;
        }

        $amounts = [];
        foreach ($refunds as $refund) {
            $amounts[(int) $refund->id] = (int) $refund->total;
        }
        // A refund is a share of what was paid, so what was paid is also
        // the denominator: amount / order total would prorate a part
        // payment's tax a second time (identical when paid in full)
        $refundParts = $this->allocate($amounts, $paid, $paid, $paidParts, $disjoint, $unit, $basis['untaxed']);
        foreach ($refundParts as &$part) {
            $part['estimated'] = true;
        }
        unset($part);

        // Base-currency amounts, one transaction after another, so each
        // transaction's lines make its gross in base too (see inBase()).
        // Stacked bases do not add up to the net even in the order's
        // currency; their lines are converted one by one (see row())
        $conversion = $disjoint ? $this->conversion($order) : null;
        if ($conversion) {
            $payments = $this->inBase($payments, $whole, $gross, $this->wholeInBase($whole, $gross, $conversion), $conversion);
            // refunds return what the payments took in base, exactly
            $paidInBase = $payments ? [
                'tax'   => $this->sumParts(array_column($payments, 'in_base'), 'tax', count($basis['lines'])),
                'base'  => $this->sumParts(array_column($payments, 'in_base'), 'base', count($basis['lines'])),
                'gross' => array_sum(array_column(array_column($payments, 'in_base'), 'gross')),
            ] : $this->wholeInBase($whole, $gross, $conversion);
            $refundParts = $this->inBase($refundParts, $paidParts, $paid, $paidInBase, $conversion);
        }

        return [
            'order'    => $order,
            'lines'    => $basis['lines'],
            'gross'    => $gross,
            'payments' => $payments,
            'refunds'  => $refundParts,
        ];
    }

    /**
     * Share $whole out over a sequence of transaction amounts.
     *
     * Each amount is capped so the running total never passes $cap. Shares
     * are taken from cumulative targets, never rounded one transaction at a
     * time: after each transaction, everything shared so far is what has
     * been paid so far ($running) / $total of $whole ($total is the amount
     * $whole is the figures of: the order total for payments, what was paid
     * for refunds), rounded to $unit, and the transaction takes that minus
     * what the transactions before it took. The tax target never falls
     * below what was given (no negative tax) nor rises by more than the
     * transaction (no negative net), and each line's target stays between
     * what it was given and its whole (see cumulativeSplit()), so every
     * share is >= 0 and the transaction that reaches $cap takes exactly
     * $whole minus everything before it. A share depends only on the
     * transactions before it, so it is the same in any period exported.
     *
     * Bases: the net (what was paid less the tax target) is split over
     * disjoint bases the same way; stacked bases are each scaled on their
     * own. Overlapping (stacked) bases next to an untaxed line: the net is
     * split between the taxed part and the untaxed line first, so the two
     * still make up the transaction's net exactly, and each taxed base is
     * scaled to the taxed part.
     *
     * Each part also keeps what the transactions before it took ('before'),
     * so its base-currency amounts are cumulative too (see row()).
     *
     * @param array<int, int> $amounts transaction id => amount, in order
     * @param array{tax: int[], base: int[]} $whole
     * @return array<int, array{gross: int, tax: int[], base: int[], estimated: bool, before: array}>
     */
    private function allocate(array $amounts, int $cap, int $total, array $whole, bool $disjoint, int $unit, ?int $untaxed = null): array
    {
        $parts = [];
        $given = ['tax' => array_fill(0, count($whole['tax']), 0), 'base' => array_fill(0, count($whole['base']), 0)];
        $wholeTax = array_sum($whole['tax']);
        $wholeNet = $total - $wholeTax;
        $wholeUntaxed = $untaxed !== null ? (int) $whole['base'][$untaxed] : 0;
        $wholeTaxed = max(0, $wholeNet - $wholeUntaxed);
        // what the transactions so far took in tax, and (stacked bases beside
        // an untaxed line) in taxed / untaxed net
        $givenTax = 0;
        $givenSplit = [0, 0];
        $running = 0;
        $first = true;

        foreach ($amounts as $id => $amount) {
            $before = ['gross' => $running, 'tax' => $given['tax'], 'base' => $given['base']];
            $amount = max(0, min($amount, $cap - $running));
            $running += $amount;
            $completes = $running >= $cap && ($amount > 0 || $cap === 0);

            if ($completes) {
                $tax = $this->minus($whole['tax'], $given['tax']);
                $base = $this->minus($whole['base'], $given['base']);
            } elseif ($amount <= 0 || $total <= 0) {
                $tax = array_fill(0, count($whole['tax']), 0);
                $base = array_fill(0, count($whole['base']), 0);
            } else {
                $ratio = $running / $total;
                $high = min($wholeTax, $givenTax + $amount);
                $low = min($high, max($givenTax, $running - $wholeNet));
                $taxTarget = max($low, min($high, $this->roundUnit($wholeTax * $ratio, $unit)));
                $netTarget = $running - $taxTarget;

                $taxSoFar = $this->cumulativeSplit($taxTarget, $whole['tax'], $given['tax'], $unit);
                if ($disjoint) {
                    $baseSoFar = $this->cumulativeSplit($netTarget, $whole['base'], $given['base'], $unit);
                } elseif ($untaxed !== null) {
                    $givenSplit = $this->cumulativeSplit($netTarget, [$wholeTaxed, $wholeUntaxed], $givenSplit, $unit);
                    $baseSoFar = [];
                    foreach ($whole['base'] as $index => $value) {
                        $scaled = $wholeTaxed > 0 ? $this->roundUnit($value * $givenSplit[0] / $wholeTaxed, $unit) : 0;
                        $baseSoFar[$index] = $this->between($scaled, $given['base'][$index], $value);
                    }
                    $baseSoFar[$untaxed] = $givenSplit[1];
                } else {
                    $baseSoFar = [];
                    foreach ($whole['base'] as $index => $value) {
                        $baseSoFar[$index] = $this->between($this->roundUnit($value * $ratio, $unit), $given['base'][$index], $value);
                    }
                }

                $tax = $this->minus($taxSoFar, $given['tax']);
                $base = $this->minus($baseSoFar, $given['base']);
                $givenTax = $taxTarget;
            }

            $given['tax'] = $this->plus($given['tax'], $tax);
            $given['base'] = $this->plus($given['base'], $base);
            $parts[$id] = [
                'gross'     => $amount,
                'tax'       => $tax,
                'base'      => $base,
                // the order's own figures only when one payment paid it all
                'estimated' => !($completes && $first),
                'before'    => $before,
            ];
            $first = false;
        }

        return $parts;
    }

    /**
     * Where a cumulative $target stands across lines that were already
     * given $given, out of $whole: the largest-remainder split of $target
     * (see largestRemainder()), each line kept between what it was given
     * and its whole, then any difference that keeping made moved onto the
     * lines furthest from their split that still have room — one $unit
     * each first, then whatever room is left (ties: earlier position
     * first). Two passes over the lines, no per-unit loop. Adds up to
     * $target whenever sum($given) <= $target <= sum($whole), which
     * allocate() guarantees; a line never drops below what it was given,
     * so the next share of every line is >= 0.
     *
     * @param int[] $whole
     * @param int[] $given
     * @return int[] each line's cumulative amount
     */
    private function cumulativeSplit(int $target, array $whole, array $given, int $unit): array
    {
        $whole = array_values($whole);
        $given = array_values($given);
        $ideal = $this->largestRemainder($target, $whole, $unit);

        $low = [];
        $high = [];
        $shares = [];
        foreach ($ideal as $index => $value) {
            $low[$index] = (int) $given[$index];
            $high[$index] = max($low[$index], (int) $whole[$index]);
            $shares[$index] = $this->between($value, $low[$index], $high[$index]);
        }

        return $this->settle($shares, $target, $low, $high, $ideal, $unit);
    }

    /**
     * Move $shares (each already between $low and $high) to add up to
     * $target: the difference goes onto the lines furthest from their
     * $exact value that still have room — one $unit each first, then
     * whatever room is left (ties: earlier position first). Two passes over
     * the lines, no per-unit loop.
     *
     * @param int[] $shares
     * @param int[] $low
     * @param int[] $high
     * @param array<int, int|float> $exact
     * @return int[]
     */
    private function settle(array $shares, int $target, array $low, array $high, array $exact, int $unit): array
    {
        $left = $target - array_sum($shares);
        if ($left === 0 || !$shares) {
            return $shares;
        }

        $sign = $left > 0 ? 1 : -1;
        $order = array_keys($shares);
        usort($order, function ($a, $b) use ($exact, $shares, $sign) {
            $gapA = $sign * ($exact[$a] - $shares[$a]);
            $gapB = $sign * ($exact[$b] - $shares[$b]);

            return $gapB <=> $gapA ?: $a <=> $b;
        });

        $left = abs($left);
        foreach ([$unit, PHP_INT_MAX] as $step) {
            foreach ($order as $index) {
                if ($left <= 0) {
                    break 2;
                }
                $room = $sign > 0 ? $high[$index] - $shares[$index] : $shares[$index] - $low[$index];
                $move = min($step, $room, $left);
                if ($move > 0) {
                    $shares[$index] += $sign * $move;
                    $left -= $move;
                }
            }
        }

        // Only when the bounds cannot hold $target (inconsistent data): the
        // shares still add up to it
        if ($left > 0) {
            $shares[$order[0]] += $sign * $left;
        }

        return $shares;
    }

    private function between(int $value, int $low, int $high): int
    {
        return max($low, min($high, $value));
    }

    /**
     * Split $target over $weights in proportion, in whole $unit steps, by
     * largest remainder: each share is floored, then the units left over go
     * one each to the largest remainders (ties: earlier position first).
     * Integer arithmetic, one sort — no per-unit loop.
     *
     * @param int[] $weights
     * @return int[]
     */
    private function largestRemainder(int $target, array $weights, int $unit): array
    {
        $count = count($weights);
        if (!$count) {
            return [];
        }

        $weights = array_map(function ($weight) { return max(0, (int) $weight); }, array_values($weights));
        $total = array_sum($weights);
        $shares = array_fill(0, $count, 0);
        $sign = $target < 0 ? -1 : 1;
        $units = intdiv(abs($target), $unit);
        $dust = abs($target) - $units * $unit;

        if ($total <= 0) {
            $shares[0] = $target;

            return $shares;
        }

        $remainders = [];
        $handed = 0;
        foreach ($weights as $index => $weight) {
            $product = $units * $weight;
            $shares[$index] = intdiv($product, $total);
            $remainders[$index] = $product % $total;
            $handed += $shares[$index];
        }

        $left = $units - $handed;
        if ($left > 0) {
            $order = array_keys($remainders);
            usort($order, function ($a, $b) use ($remainders) {
                return $remainders[$b] <=> $remainders[$a] ?: $a <=> $b;
            });
            foreach (array_slice($order, 0, $left) as $index) {
                $shares[$index]++;
            }
        }

        $shares = array_map(function ($share) use ($unit, $sign) {
            return $sign * $share * $unit;
        }, $shares);

        // An amount that is not a whole unit (odd data) keeps its dust on
        // the heaviest line, so the shares still add up to $target
        if ($dust) {
            $heaviest = array_search(max($weights), $weights, true);
            $shares[$heaviest] += $sign * $dust;
        }

        return $shares;
    }

    /**
     * The order's snapshot rate and its base currency's unit, or null when
     * the rate is unknown (no base amounts at all).
     *
     * @return array{rate: float, unit: int}|null
     */
    private function conversion(Order $order): ?array
    {
        $snapshot = CurrencySnapshot::fromOrder($order);
        $rate = (float) Arr::get($snapshot, 'rate', 1);
        if (!CurrencySnapshot::hasTrustedRate($snapshot) || $rate <= 0) {
            return null;
        }
        $base = strtoupper((string) Arr::get($snapshot, 'base_currency', '')) ?: BaseCurrency::get();

        return ['rate' => $rate, 'unit' => $this->unit($base)];
    }

    /**
     * An amount (stored units of the order's currency) in the base currency,
     * in whole units of the base: to the stored cent first, as a single
     * payment always was, then to the base's unit.
     */
    private function toBaseUnits(int $amount, array $conversion): int
    {
        return $this->roundUnit((float) round($amount / $conversion['rate']), $conversion['unit']);
    }

    /**
     * $whole (tax and disjoint bases per line, adding up to $gross) in base:
     * the gross converted once, each line's tax converted on its own, and
     * the net (gross less that tax) split over the bases, each as close to
     * its own conversion as the total allows (see settle()). Net + tax of
     * the lines is the gross exactly.
     *
     * @return array{tax: int[], base: int[], gross: int}
     */
    private function wholeInBase(array $whole, int $gross, array $conversion): array
    {
        $toBase = function ($amount) use ($conversion) { return $this->toBaseUnits((int) $amount, $conversion); };
        $exact = function ($amount) use ($conversion) { return $amount / $conversion['rate']; };
        $count = count($whole['base']);
        $grossInBase = $toBase($gross);
        $tax = array_map($toBase, array_values($whole['tax']));
        $base = $this->settle(
            array_map($toBase, array_values($whole['base'])),
            $grossInBase - array_sum($tax),
            array_fill(0, $count, 0),
            array_fill(0, $count, PHP_INT_MAX),
            array_map($exact, array_values($whole['base'])),
            $conversion['unit']
        );

        return ['tax' => $tax, 'base' => $base, 'gross' => $grossInBase];
    }

    /**
     * Each part's amounts in base ('in_base'), from cumulative targets like
     * allocate(): after each transaction, the gross so far converted once,
     * each line's tax so far converted on its own, the total tax kept so the
     * net never goes negative nor past its whole, and the net (gross less
     * tax) split over the bases (see settle()); every line stays between
     * what it was given and its whole in base. The transaction takes that
     * minus what the ones before it took, so its lines' net + tax is its
     * gross in base, every share is >= 0 and in whole base units, and the
     * transaction that completes $whole lands on $wholeInBase exactly.
     *
     * @param array<int, array> $parts allocate()'s parts, in order
     * @param array{tax: int[], base: int[]} $whole what the parts share out
     * @param array{tax: int[], base: int[], gross: int} $wholeInBase
     */
    private function inBase(array $parts, array $whole, int $wholeGross, array $wholeInBase, array $conversion): array
    {
        $count = count($whole['tax']);
        $zero = array_fill(0, $count, 0);
        $unit = $conversion['unit'];
        $toBase = function ($amount) use ($conversion) { return $this->toBaseUnits((int) $amount, $conversion); };
        $exact = function ($amount) use ($conversion) { return $amount / $conversion['rate']; };
        $sofar = ['tax' => $zero, 'base' => $zero, 'gross' => 0];
        $given = ['tax' => $zero, 'base' => $zero, 'gross' => 0];
        $wholeTax = array_sum($wholeInBase['tax']);
        $wholeNet = array_sum($wholeInBase['base']);

        foreach ($parts as $id => $part) {
            $sofar = [
                'tax'   => $this->plus($sofar['tax'], $part['tax']),
                'base'  => $this->plus($sofar['base'], $part['base']),
                'gross' => $sofar['gross'] + (int) $part['gross'],
            ];

            if ($sofar['gross'] === $wholeGross && $sofar['tax'] == array_values($whole['tax']) && $sofar['base'] == array_values($whole['base'])) {
                $now = $wholeInBase;
            } else {
                $gross = $this->between($toBase($sofar['gross']), $given['gross'], $wholeInBase['gross']);
                $taxIdeal = [];
                $netIdeal = [];
                foreach ($sofar['tax'] as $index => $value) {
                    $taxIdeal[$index] = $this->between($toBase($value), $given['tax'][$index], $wholeInBase['tax'][$index]);
                    $netIdeal[$index] = $this->between($toBase($sofar['base'][$index]), $given['base'][$index], $wholeInBase['base'][$index]);
                }
                $givenTax = array_sum($given['tax']);
                $high = min($wholeTax, $givenTax + $gross - $given['gross']);
                $low = min($high, max($givenTax, $gross - $wholeNet));
                $tax = $this->between(array_sum($taxIdeal), $low, $high);

                $now = [
                    'tax'   => $this->settle($taxIdeal, $tax, $given['tax'], $wholeInBase['tax'], array_map($exact, $sofar['tax']), $unit),
                    'base'  => $this->settle($netIdeal, $gross - $tax, $given['base'], $wholeInBase['base'], array_map($exact, $sofar['base']), $unit),
                    'gross' => $gross,
                ];
            }

            $parts[$id]['in_base'] = [
                'tax'   => $this->minus($now['tax'], $given['tax']),
                'base'  => $this->minus($now['base'], $given['base']),
                'gross' => $now['gross'] - $given['gross'],
            ];
            $given = $now;
        }

        return $parts;
    }

    /**
     * What an order with no paid charge was paid, from its record: total_paid
     * plus total_refund, capped at the order total. total_paid is gross on
     * current writers; the refund is added back for rows that an older
     * recount stored net of refunds. A paid / refunded order with neither set
     * counts as paid in full. Null when the order's payment status says it is
     * unpaid.
     */
    private function recordPayment(Order $order): ?int
    {
        if (!in_array((string) $order->payment_status, self::PAID_ORDER_STATUSES, true)) {
            return null;
        }

        $gross = (int) $order->total_amount;
        $paid = (int) $order->total_paid + (int) $order->total_refund;
        if ($paid <= 0) {
            if ($order->payment_status === Status::PAYMENT_PARTIALLY_PAID) {
                return null;
            }
            $paid = $gross;
        }

        return min($paid, $gross);
    }

    private function roundUnit(float $amount, int $unit): int
    {
        return (int) (round($amount / $unit) * $unit);
    }

    private function sumParts(array $parts, string $key, int $count): array
    {
        $sum = array_fill(0, $count, 0);
        foreach ($parts as $part) {
            $sum = $this->plus($sum, $part[$key]);
        }

        return $sum;
    }

    private function plus(array $a, array $b): array
    {
        return array_map(function ($x, $y) { return $x + $y; }, $a, $b);
    }

    private function minus(array $a, array $b): array
    {
        return array_map(function ($x, $y) { return $x - $y; }, $a, $b);
    }

    /**
     * When a charge was paid: the settlement time OrderTransaction records
     * as it turns succeeded (or the gateway's own charge time), else the
     * transaction's created_at — the same rule as SubscriptionHelper.
     */
    private function paidAt(OrderTransaction $charge): string
    {
        $settledAt = (string) Arr::get((array) $charge->meta, 'settled_at', '');

        return $settledAt !== '' ? $settledAt : (string) $charge->created_at;
    }

    private function salesQuery(array $filters)
    {
        $query = OrderTransaction::query()
            ->where('transaction_type', Status::TRANSACTION_TYPE_CHARGE)
            ->whereIn('status', self::PAID_CHARGE_STATUSES);

        $paidAt = "COALESCE(NULLIF(NULLIF(JSON_UNQUOTE(JSON_EXTRACT(meta, '$.settled_at')), ''), 'null'), created_at)";
        $from = $this->date(Arr::get($filters, 'date_from'));
        $to = $this->date(Arr::get($filters, 'date_to'));
        if ($from) {
            $query->whereRaw("{$paidAt} >= ?", [$from . ' 00:00:00']);
        }
        if ($to) {
            $query->whereRaw("{$paidAt} <= ?", [$to . ' 23:59:59']);
        }

        if (Arr::get($filters, 'include_test') !== 'yes') {
            $query->whereIn('order_id', Order::query()->select('id')->where('mode', 'live'));
        }

        return $query;
    }

    /**
     * Paid orders with no paid charge transaction, by when the order record
     * says they were paid (completed_at, else created_at).
     */
    private function recordSalesQuery(array $filters)
    {
        global $wpdb;
        $transactions = $wpdb->prefix . 'fct_order_transactions';
        $orders = $wpdb->prefix . 'fct_orders';
        $statuses = implode(', ', array_fill(0, count(self::PAID_CHARGE_STATUSES), '?'));

        $query = Order::query()
            ->select(['id'])
            ->whereIn('payment_status', self::PAID_ORDER_STATUSES)
            ->whereRaw(
                "NOT EXISTS (SELECT 1 FROM {$transactions} AS paid_charge WHERE paid_charge.order_id = {$orders}.id"
                . " AND paid_charge.transaction_type = ? AND paid_charge.status IN ({$statuses}))",
                array_merge([Status::TRANSACTION_TYPE_CHARGE], self::PAID_CHARGE_STATUSES)
            );

        $paidAt = 'COALESCE(completed_at, created_at)';
        $from = $this->date(Arr::get($filters, 'date_from'));
        $to = $this->date(Arr::get($filters, 'date_to'));
        if ($from) {
            $query->whereRaw("{$paidAt} >= ?", [$from . ' 00:00:00']);
        }
        if ($to) {
            $query->whereRaw("{$paidAt} <= ?", [$to . ' 23:59:59']);
        }

        if (Arr::get($filters, 'include_test') !== 'yes') {
            $query->where('mode', 'live');
        }

        return $query;
    }

    private function refundsQuery(array $filters)
    {
        $query = OrderTransaction::query()
            ->where('transaction_type', Status::TRANSACTION_TYPE_REFUND)
            ->where('status', Status::TRANSACTION_REFUNDED);

        $query = $this->applyDateFilters($query, $filters);

        if (Arr::get($filters, 'include_test') !== 'yes') {
            $query->whereIn('order_id', Order::query()->select('id')->where('mode', 'live'));
        }

        return $query;
    }

    private function applyDateFilters($query, array $filters)
    {
        $from = $this->date(Arr::get($filters, 'date_from'));
        $to = $this->date(Arr::get($filters, 'date_to'));

        if ($from) {
            $query->where('created_at', '>=', $from . ' 00:00:00');
        }
        if ($to) {
            $query->where('created_at', '<=', $to . ' 23:59:59');
        }

        return $query;
    }

    /**
     * The order's tax lines, without the no-tax placeholder row core writes
     * for every order — unless it is the only one (an untaxed sale still
     * gets a row).
     *
     * @return \FluentCart\App\Models\OrderTaxRate[]
     */
    private function taxLines(Order $order): array
    {
        $lines = $order->orderTaxRates ? $order->orderTaxRates->all() : [];

        $real = array_values(array_filter($lines, function ($line) {
            return !$this->isPlaceholder($line);
        }));

        if ($real) {
            return $real;
        }

        if ($lines) {
            return [reset($lines)];
        }

        // No tax data stored at all: one untaxed line
        return [new \FluentCart\App\Models\OrderTaxRate(['order_id' => $order->id, 'tax_rate_id' => 0, 'total_tax' => 0, 'order_tax' => 0, 'shipping_tax' => 0, 'meta' => []])];
    }

    private function isPlaceholder($line): bool
    {
        return (int) $line->tax_rate_id === 0
            && (int) $line->total_tax === 0
            && !(float) Arr::get($this->meta($line), 'rate_percent', 0);
    }

    /**
     * Each line's tax base, plus a 0% line for any part of the order the
     * lines do not cover. A taxed line's base is its recorded taxable base
     * when that is consistent with its tax (within a cent), else the base its
     * tax implies (tax ÷ rate) — a base mixing inclusive and exclusive items
     * is not. Bases may overlap (stacked taxes); they are never scaled.
     *
     * What the lines cover together is the taxed net core attributed to the
     * order's items (see taxedNet()). Without that attribution (older or
     * imported orders), bases that fit inside the order are taken as
     * disjoint, else the widest one is what is covered.
     *
     * @param int|null $taxedNet the order's taxed net from item attribution
     * @return array{0: array, 1: int[]} the lines (maybe one more) and their bases
     */
    private function lineBases(array $lines, int $orderNet, ?int $taxedNet = null): array
    {
        $bases = [];
        $zeroRateIndex = null;
        foreach ($lines as $index => $line) {
            $rate = (float) Arr::get($this->meta($line), 'rate_percent', 0);
            if ($rate <= 0) {
                $bases[$index] = 0;
                $zeroRateIndex = $zeroRateIndex === null ? $index : $zeroRateIndex;
                continue;
            }

            $recorded = $this->lineWeight($line);
            $implied = (int) round((int) $line->total_tax * 100 / $rate);
            // A saved shipping base can carry its own rate: check the items alone
            $shippingBase = $this->savedShippingBase($line);
            $consistent = $shippingBase === null
                ? abs((int) round($recorded * $rate / 100) - (int) $line->total_tax) <= 1
                : abs((int) round(($recorded - $shippingBase) * $rate / 100) - (int) $line->order_tax) <= 1;
            $base = $consistent ? $recorded : $implied;
            $bases[$index] = min($base, max(0, $orderNet));
        }

        $widest = max($bases ?: [0]);
        if ($taxedNet !== null) {
            // Never less than one line's base, never more than all of them
            // (or the order) together: the bases stay the order's own figures
            $covered = min(max($taxedNet, $widest), array_sum($bases), max(0, $orderNet));
        } else {
            // Disjoint bases that fall short of the order leave an untaxed
            // part; overlapping (stacked) bases cover the same amount, so
            // the widest one is what is covered
            $covered = array_sum($bases) <= $orderNet ? array_sum($bases) : $widest;
        }
        $remainder = $orderNet - $covered;

        if ($remainder > 0) {
            if ($zeroRateIndex !== null) {
                $bases[$zeroRateIndex] += $remainder;
            } else {
                $lines[] = $this->untaxedLine(reset($lines));
                $bases[] = $remainder;
            }
        }

        return [array_values($lines), array_values($bases)];
    }

    /**
     * The part of the order's net any tax was charged on, from the per-item,
     * per-rate tax core records on each order item at checkout
     * (line_meta.tax_config.rates; line_meta.rates on older signup-fee
     * items): the net of every item at least one rate charged tax on —
     * once, however many rates are stacked on it — plus the shipping the
     * tax lines charged shipping tax on, also once (rates sharing an item
     * share its shipping). Null when no item carries tax attribution (older
     * or imported orders).
     *
     * @param array $lines the order's tax lines
     */
    private function taxedNet(Order $order, array $lines): ?int
    {
        $items = $order->order_items;
        if (!$items || !count($items)) {
            return null;
        }

        $shippingRates = [];
        foreach ($lines as $line) {
            if ((float) Arr::get($this->meta($line), 'rate_percent', 0) > 0 && (int) $line->shipping_tax > 0) {
                $shippingRates[(int) $line->tax_rate_id] = true;
            }
        }

        $attributed = false;
        $taxed = 0;
        $rateItems = [];
        // Core saves each shipped item's shipping (line_meta.shipping_share); null once one is missing
        $taxedShares = 0;
        $sharesTotal = 0;
        foreach ($items as $index => $item) {
            $meta = $item->line_meta;
            if (!is_array($meta)) {
                continue;
            }
            $config = Arr::get($meta, 'tax_config');
            if (is_array($config)) {
                $rates = (array) Arr::get($config, 'rates', []);
                $inclusive = (bool) Arr::get($config, 'inclusive', false);
            } elseif (array_key_exists('rates', $meta)) {
                $rates = (array) Arr::get($meta, 'rates', []);
                $inclusive = (bool) Arr::get($meta, 'inclusive', false);
            } else {
                continue;
            }
            $attributed = true;

            if ($taxedShares !== null && $item->fulfillment_type === 'physical' && $item->payment_type !== 'bundle') {
                $share = Arr::get($meta, 'shipping_share');
                // An inclusive share is gross; the rate bases are net
                if ($share === null || $inclusive) {
                    $taxedShares = null;
                } else {
                    $sharesTotal += (int) $share;
                    foreach ($rates as $rate) {
                        $forShipping = Arr::get($rate, 'for_shipping');
                        $shippingRate = $forShipping !== null ? (float) $forShipping : (float) Arr::get($rate, 'rate_percent', 0);
                        if ($shippingRate > 0 && isset($shippingRates[(int) Arr::get($rate, 'rate_id', 0)])) {
                            $taxedShares += (int) $share;
                            break;
                        }
                    }
                }
            }

            // A rate's saved shipping base is the shipping of the shipped items it is on
            if ($item->fulfillment_type === 'physical') {
                foreach ($rates as $rate) {
                    $rateId = (int) Arr::get($rate, 'rate_id', 0);
                    if ($rateId) {
                        $rateItems[$rateId][$index] = true;
                    }
                }
            }

            $itemTax = 0;
            $taxable = null;
            $compoundTaxable = null;
            foreach ($rates as $rate) {
                if ((float) Arr::get($rate, 'rate_percent', 0) <= 0 || (float) Arr::get($rate, 'tax_amount', 0) <= 0) {
                    continue;
                }
                $itemTax += (int) round((float) Arr::get($rate, 'tax_amount', 0));
                $amount = (int) round((float) Arr::get($rate, 'taxable_amount', 0));
                // A compound rate's taxable amount includes the taxes before it
                if (Arr::get($rate, 'is_compound')) {
                    $compoundTaxable = $compoundTaxable === null ? $amount : min($compoundTaxable, $amount);
                } else {
                    $taxable = $taxable === null ? $amount : min($taxable, $amount);
                }
            }
            if ($taxable === null) {
                $taxable = $compoundTaxable;
            }
            if ($taxable === null) {
                continue;
            }

            // An inclusive taxable amount is gross: take every rate's tax off
            $taxed += max(0, $inclusive ? $taxable - $itemTax : $taxable);
        }

        if (!$attributed) {
            return null;
        }

        // Shares that still add up to the order's shipping are exact; else work it out from the rate bases
        if ($taxedShares !== null && $sharesTotal === (int) $order->shipping_total) {
            return $taxed + $taxedShares;
        }

        $bases = [];
        $loose = 0;
        foreach ($lines as $line) {
            $rate = (float) Arr::get($this->meta($line), 'rate_percent', 0);
            if ($rate > 0 && (int) $line->shipping_tax > 0) {
                $saved = $this->savedShippingBase($line);
                $rateId = (int) $line->tax_rate_id;
                // No saved base or no shipped item (rounding cent, unattributed item): may overlap anything
                if ($saved === null || !isset($rateItems[$rateId])) {
                    $loose = max($loose, $saved !== null ? $saved : (int) round((int) $line->shipping_tax * 100 / $rate));
                    continue;
                }
                $bases[$rateId] = $saved;
            }
        }

        // Rates that share a shipped item tax the same shipping cents: count each group once
        $exact = 0;
        $low = 0;
        $high = 0;
        while ($bases) {
            $group = [key($bases) => true];
            $groupItems = $rateItems[key($bases)];
            do {
                $grew = false;
                foreach ($bases as $rateId => $base) {
                    if (!isset($group[$rateId]) && array_intersect_key($rateItems[$rateId], $groupItems)) {
                        $group[$rateId] = true;
                        $groupItems += $rateItems[$rateId];
                        $grew = true;
                    }
                }
            } while ($grew);

            $groupBases = array_intersect_key($bases, $group);
            $bases = array_diff_key($bases, $group);
            // A rate on every item of the group was charged on all of its shipping
            $covering = array_filter(array_keys($groupBases), function ($rateId) use ($rateItems, $groupItems) {
                return count($rateItems[$rateId]) === count($groupItems);
            });
            if ($covering) {
                $exact += max(array_intersect_key($groupBases, array_flip($covering)));
            } else {
                $low += max($groupBases);
                $high += array_sum($groupBases);
            }
        }
        // shortcut: a chain no rate covers is capped at the order shipping; it counts high if a shipped item has untaxed shipping, exact once core saves item shipping shares
        $shipping = $exact + max($low, min($high, (int) $order->shipping_total - $exact));

        return $taxed + max($shipping, $loose);
    }

    /**
     * A 0% line for the untaxed part of a sale, in the sale's tax country.
     */
    private function untaxedLine($like)
    {
        $meta = $like ? $this->meta($like) : [];
        $meta['label'] = __('Not taxed', 'fluent-cart-pro');
        $meta['rate_percent'] = 0;
        $meta['taxable_amount'] = 0;

        return new \FluentCart\App\Models\OrderTaxRate([
            'order_id'     => $like ? $like->order_id : 0,
            'tax_rate_id'  => 0,
            'order_tax'    => 0,
            'shipping_tax' => 0,
            'total_tax'    => 0,
            'meta'         => $meta,
        ]);
    }

    /**
     * A line's recorded taxable base, net of tax: items (taxable_amount is
     * gross for inclusive prices) plus the shipping its shipping tax was
     * charged on.
     */
    private function lineWeight($line): int
    {
        $meta = $this->meta($line);
        $rate = (float) Arr::get($meta, 'rate_percent', 0);
        $taxable = (int) Arr::get($meta, 'taxable_amount', 0);
        $items = Arr::get($meta, 'inclusive') ? $taxable - (int) $line->order_tax : $taxable;
        $shipping = $this->savedShippingBase($line);
        if ($shipping === null) {
            $shipping = $rate > 0 ? (int) round((int) $line->shipping_tax * 100 / $rate) : 0;
        }

        return max(0, $items + $shipping);
    }

    /**
     * The shipping charge a line's shipping tax was charged on, when core saved
     * it. Older orders have none and work it back from the tax.
     */
    private function savedShippingBase($line): ?int
    {
        $meta = $this->meta($line);
        if ((int) $line->shipping_tax <= 0 || !isset($meta['shipping_taxable_amount'])) {
            return null;
        }

        return (int) $meta['shipping_taxable_amount'];
    }

    private function row(string $type, Order $order, $line, array $amounts): array
    {
        $meta = $this->meta($line);
        $currency = strtoupper((string) $order->currency);
        $snapshot = CurrencySnapshot::fromOrder($order);
        // The rate is per 1 unit of the base the order was sold against,
        // which is not today's base after a base-currency change
        $base = strtoupper((string) Arr::get($snapshot, 'base_currency', '')) ?: BaseCurrency::get();
        $trusted = CurrencySnapshot::hasTrustedRate($snapshot);
        $rate = (float) Arr::get($snapshot, 'rate', 1);
        $date = substr((string) $amounts['date'], 0, 10);
        $periodEnd = $this->quarterEnd($date);
        $taxable = (int) $amounts['taxable'];
        $tax = (int) $amounts['tax'];
        $orderTax = (int) $amounts['order_tax'];
        $orderGross = (int) $amounts['order_gross'];
        // A share of a split order converts cumulatively: what the
        // transactions up to it took, converted, less what the ones before it
        // took, converted. Shares never drift from the whole in base, and a
        // fully refunded order nets to zero in base too. Both cumulative
        // amounts are rounded to the base's own unit (whole yen) before
        // they are subtracted, so a share is never rounded again on its own
        // A share that comes with its own base amounts (in_base: the lines of
        // an order whose bases add up to its net, see inBase()) uses them
        $before = (array) ($amounts['before'] ?? []);
        $inBase = isset($amounts['in_base']) ? (array) $amounts['in_base'] : [];
        $conversion = ['rate' => $rate, 'unit' => $this->unit($base)];
        $toBase = function ($cents, $key) use ($trusted, $rate, $before, $inBase, $conversion) {
            if (!($trusted && $rate > 0)) {
                return null;
            }
            if (array_key_exists($key, $inBase)) {
                return (int) $inBase[$key];
            }
            $prior = (int) ($before[$key] ?? 0);

            return ($cents < 0 ? -1 : 1) * ($this->toBaseUnits($prior + abs($cents), $conversion) - $this->toBaseUnits($prior, $conversion));
        };

        $row = [
            'row_type'                => $type,
            'order_id'                => (int) $order->id,
            'invoice_no'              => $this->text((string) $order->invoice_no),
            'transaction_id'          => $this->text((string) $amounts['transaction_id']),
            'date_utc'                => (string) $amounts['date'],
            'period'                  => $date ? substr($date, 0, 4) . '-Q' . (int) ceil((int) substr($date, 5, 2) / 3) : '',
            'tax_country'             => (string) Arr::get($meta, 'tax_country', ''),
            'tax_scheme'              => $this->scheme($meta),
            'reverse_charge'          => Arr::get($meta, 'reverse_charge_applied') ? 'yes' : 'no',
            'customer_vat_number'     => $this->text((string) Arr::get($meta, 'vat_reverse.vat_number', '')),
            'store_vat_number'        => $this->text((string) Arr::get($meta, 'store_vat_number', '')),
            'tax_label'               => $this->text((string) Arr::get($meta, 'label', '')),
            'tax_rate_percent'        => $this->number((float) Arr::get($meta, 'rate_percent', 0)),
            'currency'                => $currency,
            'taxable_amount'          => $this->money($taxable, $currency),
            'tax'                     => $this->money($tax, $currency),
            'order_net'               => $this->money($orderGross - $orderTax, $currency),
            'order_tax'               => $this->money($orderTax, $currency),
            'order_gross'             => $this->money($orderGross, $currency),
            'tax_estimated'           => $amounts['tax_estimated'] ? 'yes' : 'no',
            'base_currency'           => $base,
            'sales_rate'              => $trusted ? $this->number($rate, 12) : '',
            'taxable_amount_base'     => $this->money($toBase($taxable, 'taxable'), $base),
            'tax_base'                => $this->money($toBase($tax, 'tax'), $base),
            'order_gross_base'        => $this->money($toBase($orderGross, 'gross'), $base),
            'ecb_eur_rate_on_date'    => $this->ecbEurRate($currency, $date),
            'ecb_eur_rate_period_end' => $periodEnd ? $this->ecbEurRate($currency, $periodEnd) : '',
            'ecb_period_end_date'     => $periodEnd,
        ];

        $row = (array) apply_filters('fluent_cart/accounting_export/row', $row, [
            'order'    => $order,
            'tax_line' => $line,
        ]);

        // Kept for refundRows(); stripped by publicRow() before rows leave
        $row['_base'] = $taxable;
        $row['_tax'] = $tax;
        $row['_line'] = $line;

        return $row;
    }

    /**
     * Strip internal keys before a row leaves the service.
     */
    private function publicRow(array $row): array
    {
        unset($row['_base'], $row['_tax'], $row['_line']);

        return $row;
    }

    /**
     * Sales rows keep their internal keys until refundRows() has used them;
     * batch() strips them on the way out.
     */
    public function exportRows(array $rows): array
    {
        return array_map([$this, 'publicRow'], $rows);
    }

    /**
     * The row's tax scheme, derived: FluentCart stores the tax country,
     * the store VAT number used and the reverse-charge flag, not a scheme.
     */
    private function scheme(array $meta): string
    {
        if (Arr::get($meta, 'reverse_charge_applied')) {
            return 'reverse_charge';
        }

        $country = strtoupper((string) Arr::get($meta, 'tax_country', ''));
        if ($country === '') {
            return 'no_tax';
        }

        $storeCountry = strtoupper((string) (new StoreSettings())->get('store_country'));
        if ($country === $storeCountry) {
            return 'domestic';
        }

        $localization = LocalizationManager::getInstance();
        if (!$localization->isEuTaxCountry($country)) {
            return 'non_eu';
        }

        $settings = $this->taxSettings();
        $ossVat = (string) Arr::get($settings, 'eu_vat_settings.oss_vat', '');
        $storeVat = (string) Arr::get($meta, 'store_vat_number', '');
        $isOss = ($ossVat !== '' && $storeVat === $ossVat)
            || ($storeVat === '' && Arr::get($settings, 'eu_vat_settings.method') === 'oss');

        return ($isOss && $localization->isEuTaxCountry($storeCountry)) ? 'oss' : 'eu_other';
    }

    /**
     * Units of $currency per 1 EUR published by the ECB for $date (the last
     * publication on or before it), or '' when no ECB rate is available.
     */
    private function ecbEurRate(string $currency, string $date): string
    {
        if ($date === '') {
            return '';
        }
        if ($currency === 'EUR') {
            return '1';
        }

        $key = $currency . '|' . $date;
        if (!array_key_exists($key, $this->ecbRates)) {
            // A provider that could not answer (WP_Error) is not asked again
            // for this batch: each further date would be another timeout
            if ($this->ecbUnavailable) {
                return '';
            }
            $found = apply_filters('fluent_cart/currency/historical_rate', null, [
                'base'  => 'EUR',
                'quote' => $currency,
                'date'  => $date,
            ]);
            if (is_wp_error($found)) {
                $this->ecbUnavailable = true;
            }
            $this->ecbRates[$key] = (is_array($found) && Arr::get($found, 'source') === 'ecb' && Arr::get($found, 'rate'))
                ? $this->number((float) $found['rate'], 6)
                : '';
        }

        return $this->ecbRates[$key];
    }

    /**
     * The last day of $date's calendar quarter, or '' while that quarter
     * has not ended (no period-end rate exists yet).
     */
    private function quarterEnd(string $date): string
    {
        if (!preg_match('/^(\d{4})-(\d{2})-\d{2}$/', $date, $parts)) {
            return '';
        }

        $endMonth = (int) ceil((int) $parts[2] / 3) * 3;
        $end = gmdate('Y-m-t', gmmktime(0, 0, 0, $endMonth, 1, (int) $parts[1]));

        return $end < gmdate('Y-m-d') ? $end : '';
    }

    /**
     * The smallest amount of $currency in stored (×100) units: 100 for a
     * zero-decimal currency, else 1.
     */
    private function unit(string $currency): int
    {
        if (method_exists(RoundingRules::class, 'unit')) {
            return RoundingRules::unit($currency);
        }

        return Money::getDecimals($currency) === 0 ? 100 : 1;
    }

    private function chargeTransactionId(Order $order): string
    {
        $charge = OrderTransaction::query()
            ->where('order_id', $order->id)
            ->where('transaction_type', Status::TRANSACTION_TYPE_CHARGE)
            ->orderBy('id', 'ASC')
            ->first();

        return $charge ? (string) ($charge->uuid ?: $charge->id) : '';
    }

    private function meta($line): array
    {
        $meta = $line->meta;
        if (is_string($meta)) {
            $meta = json_decode($meta, true);
        }

        return is_array($meta) ? $meta : [];
    }

    private function taxSettings(): array
    {
        if ($this->taxSettings === null) {
            $this->taxSettings = (array) (new TaxModule())->getSettings();
        }

        return $this->taxSettings;
    }

    private function parseCursor($cursor): array
    {
        if (is_string($cursor) && preg_match('/^(sales|records|refunds):(\d+)$/', $cursor, $parts)) {
            return [$parts[1], (int) $parts[2]];
        }

        return ['sales', 0];
    }

    private function date($value): string
    {
        $value = sanitize_text_field((string) $value);

        return preg_match('/^\d{4}-\d{2}-\d{2}$/', $value) ? $value : '';
    }

    /**
     * Cents (×100 for every currency) as a plain decimal string in the
     * currency's own precision; '' when the amount is unknown.
     *
     * @param int|null $cents
     */
    private function money($cents, string $currency): string
    {
        if ($cents === null) {
            return '';
        }

        $decimals = Money::getDecimals($currency) === 0 ? 0 : 2;

        return number_format($cents / 100, $decimals, '.', '');
    }

    private function number(float $value, int $precision = 4): string
    {
        $formatted = rtrim(rtrim(number_format($value, $precision, '.', ''), '0'), '.');

        return $formatted === '' || $formatted === '-0' ? '0' : $formatted;
    }

    /**
     * Text a spreadsheet must not run as a formula.
     */
    private function text(string $value): string
    {
        return preg_match('/^[=+\-@\t\r]/', $value) ? "'" . $value : $value;
    }
}
