<?php

namespace FluentCartPro\App\Http\Controllers;

use FluentCart\App\Models\Meta;
use FluentCart\Framework\Http\Request\Request;
use FluentCartPro\App\Http\Policies\SavedViewsPolicy;

class SavedViewsController extends Controller
{
    public function index(Request $request)
    {
        $objectType = sanitize_text_field($request->get('object_type', ''));

        if (!$objectType) {
            return $this->sendError([
                'message' => __('Table name (object_type) is required.', 'fluent-cart-pro'),
            ], 422);
        }

        $views = self::getViewsForUser(get_current_user_id(), $objectType);

        $data = [];
        foreach ($views as $view) {
            $data[] = self::formatView($view);
        }

        return $this->sendSuccess([
            'views' => $data,
        ]);
    }

    public function store(Request $request)
    {
        $objectType = sanitize_text_field($request->get('object_type', ''));

        if (!$objectType) {
            return $this->sendError([
                'message' => __('Table name (object_type) is required.', 'fluent-cart-pro'),
            ], 422);
        }

        $name = sanitize_text_field($request->get('name', ''));

        if (!$name || mb_strlen($name) > 50) {
            return $this->sendError([
                'message' => __('Name is required and must be 50 characters or fewer.', 'fluent-cart-pro'),
            ], 422);
        }

        $userId = get_current_user_id();
        $isPublic = (bool) $request->get('is_public', false);

        // Max 20 views per user per table, public ones included. A public view
        // stores object_id 0, so its owner is the creator_id in meta_value.
        $userViewCount = Meta::query()
            ->where('meta_key', 'saved_view')
            ->where('object_type', $objectType)
            ->where(function ($q) use ($userId) {
                $q->where('object_id', $userId)
                    ->orWhereNull('object_id')
                    ->orWhere('object_id', 0);
            })
            ->get()
            ->filter(function (Meta $meta) use ($userId) {
                $metaValue = is_array($meta->meta_value) ? $meta->meta_value : [];
                $ownerId = isset($metaValue['creator_id']) ? (int) $metaValue['creator_id'] : (int) $meta->object_id;
                return $ownerId === $userId;
            })
            ->count();

        if ($userViewCount >= 20) {
            return $this->sendError([
                'message' => __('Maximum of 20 saved views reached for this table.', 'fluent-cart-pro'),
            ], 422);
        }

        $description = sanitize_textarea_field($request->get('description', ''));
        $queryParams = self::sanitizeQueryParams($request->get('query_params', []));

        // Generate unique slug from name
        $slug = sanitize_title($name);
        if (!$slug) {
            $slug = 'view';
        }
        $slug .= '-' . substr(wp_generate_password(6, false), 0, 6);

        $meta = Meta::create([
            'object_type' => $objectType,
            'object_id'   => $isPublic ? 0 : $userId,
            'meta_key'    => 'saved_view',
            'meta_value'  => [
                'name'         => $name,
                'description'  => $description,
                'slug'         => $slug,
                'query_params' => $queryParams,
                'creator_id'   => $userId,
            ],
        ]);

        return $this->sendSuccess([
            'message' => __('View saved successfully.', 'fluent-cart-pro'),
            'view'    => self::formatView($meta),
        ], 201);
    }

    public function update(Request $request, $id)
    {
        $id = absint($id);

        $meta = Meta::query()
            ->where('id', $id)
            ->where('meta_key', 'saved_view')
            ->first();

        if (!$meta) {
            return $this->sendError([
                'message' => __('View not found.', 'fluent-cart-pro'),
            ], 404);
        }

        $userId = get_current_user_id();

        $metaValue = $meta->meta_value;
        if (!is_array($metaValue)) {
            $metaValue = [];
        }

        // Only the creator can update
        $creatorId = isset($metaValue['creator_id']) ? (int) $metaValue['creator_id'] : null;
        if ($creatorId && $creatorId !== $userId) {
            return $this->sendError([
                'message' => __('You do not have permission to update this view.', 'fluent-cart-pro'),
            ], 403);
        }

        if ($request->has('name')) {
            $name = sanitize_text_field($request->get('name'));
            if (!$name || mb_strlen($name) > 50) {
                return $this->sendError([
                    'message' => __('Name is required and must be 50 characters or fewer.', 'fluent-cart-pro'),
                ], 422);
            }
            $metaValue['name'] = $name;
        }

        if ($request->has('description')) {
            $metaValue['description'] = sanitize_textarea_field($request->get('description'));
        }

        if ($request->has('query_params')) {
            $metaValue['query_params'] = self::sanitizeQueryParams($request->get('query_params'));
        }

        if ($request->has('is_public')) {
            $isPublic = (bool) $request->get('is_public');
            $meta->object_id = $isPublic ? 0 : $userId;
        }

        $meta->meta_value = $metaValue;
        $meta->save();

        return $this->sendSuccess([
            'message' => __('View updated successfully.', 'fluent-cart-pro'),
            'view'    => self::formatView($meta),
        ]);
    }

    public function delete(Request $request, $id)
    {
        $id = absint($id);

        $meta = Meta::query()
            ->where('id', $id)
            ->where('meta_key', 'saved_view')
            ->first();

        if (!$meta) {
            return $this->sendError([
                'message' => __('View not found.', 'fluent-cart-pro'),
            ], 404);
        }

        $userId = get_current_user_id();

        // Only the creator can delete
        $metaValue = $meta->meta_value;
        $creatorId = is_array($metaValue) && isset($metaValue['creator_id']) ? (int) $metaValue['creator_id'] : null;
        if ($creatorId && $creatorId !== $userId) {
            return $this->sendError([
                'message' => __('You do not have permission to delete this view.', 'fluent-cart-pro'),
            ], 403);
        }

        $meta->delete();

        return $this->sendSuccess([
            'message' => __('View deleted successfully.', 'fluent-cart-pro'),
        ]);
    }

    /**
     * Format a Meta model into a view response array.
     */
    public static function formatView(Meta $meta)
    {
        $metaValue = $meta->meta_value;

        $creatorId = isset($metaValue['creator_id']) ? (int) $metaValue['creator_id'] : null;

        return [
            'id'           => (int) $meta->id,
            'object_type'  => $meta->object_type,
            'slug'         => isset($metaValue['slug']) ? $metaValue['slug'] : '',
            'name'         => isset($metaValue['name']) ? $metaValue['name'] : '',
            'description'  => isset($metaValue['description']) ? $metaValue['description'] : '',
            'query_params' => isset($metaValue['query_params']) ? $metaValue['query_params'] : [],
            'is_public'    => empty($meta->object_id),
            'owner_id'     => $creatorId ? $creatorId : (!empty($meta->object_id) ? (int) $meta->object_id : null),
        ];
    }

    /**
     * Load saved views for a user (own + public), optionally filtered by table.
     */
    public static function getViewsForUser($userId, $objectType = null)
    {
        $query = Meta::query()
            ->where('meta_key', 'saved_view')
            ->where(function ($q) use ($userId) {
                $q->where('object_id', $userId)
                    ->orWhereNull('object_id')
                    ->orWhere('object_id', 0);
            })
            ->orderBy('id', 'ASC');

        if ($objectType) {
            $query->where('object_type', $objectType);
        }

        return $query->get();
    }

    public static function resolveViewForFilter($userId, string $filterName, string $slug)
    {
        $objectType = static::getSavedViewObjectTypeForFilter($filterName);

        if (!SavedViewsPolicy::userCanAccessObjectType($userId, $objectType)) {
            return null;
        }

        $view = Meta::query()
            ->where('meta_key', 'saved_view')
            ->where('object_type', $objectType)
            ->where(function ($q) use ($userId) {
                $q->where('object_id', $userId)
                    ->orWhereNull('object_id')
                    ->orWhere('object_id', 0);
            })
            ->get()
            ->first(function (Meta $meta) use ($slug) {
                $metaValue = is_array($meta->meta_value) ? $meta->meta_value : [];
                return isset($metaValue['slug']) && $metaValue['slug'] === $slug;
            });

        return $view ? static::formatView($view) : null;
    }

    private static function getSavedViewObjectTypeForFilter(string $filterName): string
    {
        $map = [
            'orders'           => 'order_table',
            'products'         => 'product_table',
            'coupons'          => 'coupon_table',
            'logs'             => 'log_table',
            'taxes'            => 'taxes_table',
            'order_bump'       => 'order_bump_table',
            'shipping_zones'   => 'shipping_zone_table',
            'shipping_classes' => 'shipping_class_table',
        ];

        return isset($map[$filterName]) ? $map[$filterName] : $filterName;
    }

    /**
     * Sanitize query_params to only allowed keys.
     */
    private static function sanitizeQueryParams($queryParams)
    {
        if (!is_array($queryParams)) {
            return [];
        }

        $allowed = ['filter_type', 'advanced_filters', 'search', 'active_view'];
        $sanitized = [];

        foreach ($allowed as $key) {
            if (!isset($queryParams[$key])) {
                continue;
            }

            if ($key === 'advanced_filters') {
                // JSON string — validate it's valid JSON, don't sanitize_text_field
                $decoded = is_string($queryParams[$key]) ? json_decode($queryParams[$key], true) : null;
                $sanitized[$key] = is_array($decoded) ? wp_json_encode($decoded) : '[[]]';
            } else {
                $sanitized[$key] = is_string($queryParams[$key])
                    ? sanitize_text_field($queryParams[$key])
                    : $queryParams[$key];
            }
        }

        return $sanitized;
    }
}
