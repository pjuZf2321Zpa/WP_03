<?php


namespace Breakdance\DynamicData;

class PostFeaturedImageURL extends StringField
{

    /**
     * @inheritDoc
     */
    public function label()
    {
        return __('Featured Image (URL)', 'breakdance');
    }

    /**
     * @inheritDoc
     */
    public function category()
    {
        return __('Post', 'breakdance');
    }

    /**
     * @inheritDoc
     */
    public function slug()
    {
        return 'post_featured_image_url';
    }

    /**
     * @inheritDoc
     */
    public function returnTypes()
    {
        return ['url'];
    }

    /**
     * @inheritDoc
     */
    public function handler($attributes): StringData
    {
        // In case the current post is an attachment, we need to return the post ID itself.
        if (get_post_type() === 'attachment') {
            $attachment_id = get_the_ID();
        } else {
            $attachment_id = get_post_thumbnail_id(get_the_ID());
        }

        $attachment_url =  wp_get_attachment_image_url($attachment_id, 'full') ?? '';

        return StringData::fromString($attachment_url);
    }
}
