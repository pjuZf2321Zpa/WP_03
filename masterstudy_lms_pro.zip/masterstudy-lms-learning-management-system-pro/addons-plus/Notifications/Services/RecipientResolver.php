<?php

namespace MasterStudy\Lms\Pro\AddonsPlus\Notifications\Services;

final class RecipientResolver {
	public function course_students( int $course_id ): array {
		if ( $course_id <= 0 || ! function_exists( 'stm_lms_get_course_users' ) ) {
			return array();
		}

		$users = stm_lms_get_course_users( $course_id, array( 'user_id' ) );

		return $this->sanitize_user_ids( wp_list_pluck( (array) $users, 'user_id' ) );
	}

	public function course_students_batch_after( int $course_id, int $limit = 100, int $cursor = 0 ): array {
		global $wpdb;

		if ( $course_id <= 0 || ! function_exists( 'stm_lms_user_courses_name' ) ) {
			return array(
				'user_ids'    => array(),
				'next_cursor' => max( 0, $cursor ),
			);
		}

		$limit  = min( 500, max( 1, $limit ) );
		$cursor = max( 0, $cursor );
		$table  = stm_lms_user_courses_name( $wpdb );

		$rows = $wpdb->get_results(
			$wpdb->prepare(
				// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				"SELECT user_course_id, user_id FROM {$table} WHERE course_id = %d AND user_course_id > %d ORDER BY user_course_id ASC LIMIT %d",
				$course_id,
				$cursor,
				$limit
			),
			ARRAY_A
		);

		$last_row = ! empty( $rows ) ? end( $rows ) : array();

		return array(
			'user_ids'    => $this->sanitize_user_ids( wp_list_pluck( (array) $rows, 'user_id' ) ),
			'next_cursor' => max( $cursor, absint( is_array( $last_row ) ? ( $last_row['user_course_id'] ?? $cursor ) : $cursor ) ),
		);
	}

	public function admins(): array {
		$users = get_users(
			array(
				'capability' => 'manage_options',
				'fields'     => 'ID',
			)
		);

		if ( empty( $users ) ) {
			$users = get_users(
				array(
					'role'   => 'administrator',
					'fields' => 'ID',
				)
			);
		}

		return $this->sanitize_user_ids( (array) $users );
	}

	public function can_review_assignment_submission( int $user_id, int $course_id, int $assignment_id = 0 ): bool {
		$user_id       = absint( $user_id );
		$course_id     = absint( $course_id );
		$assignment_id = absint( $assignment_id );

		if ( $user_id <= 0 ) {
			return false;
		}

		if ( user_can( $user_id, 'manage_options' ) ) {
			return true;
		}

		return in_array( $user_id, $this->assignment_submission_reviewer_ids( $course_id, $assignment_id ), true );
	}

	public function assignment_submission_reviewer_ids( int $course_id, int $assignment_id = 0 ): array {
		$course_id     = absint( $course_id );
		$assignment_id = absint( $assignment_id );
		$reviewer_ids  = array();

		if ( $course_id > 0 ) {
			$reviewer_ids[] = absint( get_post_field( 'post_author', $course_id ) );
			$reviewer_ids   = array_merge( $reviewer_ids, $this->course_co_instructor_ids( $course_id ) );
		}

		if ( $assignment_id > 0 ) {
			$reviewer_ids[] = absint( get_post_field( 'post_author', $assignment_id ) );
		}

		$reviewer_ids = apply_filters( 'masterstudy_notifications_assignment_submission_reviewer_ids', $reviewer_ids, $course_id, $assignment_id );

		return $this->sanitize_user_ids( is_array( $reviewer_ids ) ? $reviewer_ids : array() );
	}

	public function users_by_emails( array $emails ): array {
		global $wpdb;

		$emails = array_values( array_unique( array_filter( array_map( 'sanitize_email', $emails ) ) ) );

		if ( empty( $emails ) ) {
			return array();
		}

		$user_ids = array();

		foreach ( array_chunk( $emails, 500 ) as $email_chunk ) {
			$placeholders = implode( ',', array_fill( 0, count( $email_chunk ), '%s' ) );
			$ids          = $wpdb->get_col(
				$wpdb->prepare(
					// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare -- User table and IN placeholders are generated internally.
					"SELECT ID FROM {$wpdb->users} WHERE user_email IN ({$placeholders})",
					$email_chunk
				)
			);

			$user_ids = array_merge( $user_ids, $ids );
		}

		return $this->sanitize_user_ids( $user_ids );
	}

	public function is_enrolled( int $user_id, int $course_id ): bool {
		if ( $user_id <= 0 || $course_id <= 0 || ! function_exists( 'stm_lms_get_user_course' ) ) {
			return false;
		}

		return ! empty( stm_lms_get_user_course( $user_id, $course_id, array( 'user_course_id' ) ) );
	}

	private function sanitize_user_ids( array $user_ids ): array {
		return array_values( array_unique( array_filter( array_map( 'absint', $user_ids ) ) ) );
	}

	private function course_co_instructor_ids( int $course_id ): array {
		$co_instructors = array();
		$co_meta        = get_post_meta( $course_id, 'co_instructor', false );

		foreach ( (array) $co_meta as $co_instructor ) {
			if ( is_array( $co_instructor ) ) {
				$co_instructors = array_merge( $co_instructors, $co_instructor );
				continue;
			}

			$co_instructors[] = $co_instructor;
		}

		return $this->sanitize_user_ids( $co_instructors );
	}
}
