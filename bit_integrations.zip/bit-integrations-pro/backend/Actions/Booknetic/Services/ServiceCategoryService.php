<?php

namespace BitApps\IntegrationsPro\Actions\Booknetic\Services;

use BookneticApp\Backend\Services\DTOs\Request\ServiceCategoryRequest;
use BookneticApp\Backend\Services\Services\ServiceCategoryService as BookneticServiceCategoryService;
use BookneticApp\Models\Service;
use BookneticApp\Models\ServiceCategory;
use BookneticApp\Providers\IoC\Container;

final class ServiceCategoryService extends BaseService
{
    public function createServiceCategory(): array
    {
        $error = $this->validate(['name' => [__('Name', 'bit-integrations-pro')]]);

        if ($error !== null) {
            return $error;
        }

        $name = $this->string('name');
        $parentId = $this->int('parent_id');
        $categoryError = self::categoryError($name, $parentId);

        if ($categoryError !== null) {
            return $this->error($categoryError);
        }

        $request = (new ServiceCategoryRequest())->setName($name)->setParentId($parentId);
        $categoryId = Container::get(BookneticServiceCategoryService::class)->create($request);

        return $this->success(ServiceCategory::query()->get($categoryId));
    }

    public function updateServiceCategory(): array
    {
        $error = $this->validate([
            'service_category_id' => [__('Service Category ID', 'bit-integrations-pro'), 'integer'],
            'name'                => [__('Name', 'bit-integrations-pro')],
        ]);

        if ($error !== null) {
            return $error;
        }

        $categoryId = $this->int('service_category_id');
        $category = ServiceCategory::query()->get($categoryId);

        if (empty($category)) {
            return $this->error(__('The service category does not exist. Select a different category.', 'bit-integrations-pro'));
        }

        $data = ['name' => $this->string('name')] + $this->optionalIntFields(['parent_id']);

        if (($data['parent_id'] ?? null) === $categoryId) {
            return $this->error(__('A category cannot be its own parent. Select a different parent category.', 'bit-integrations-pro'));
        }

        $categoryError = self::categoryError($data['name'], (int) ($data['parent_id'] ?? $category->parent_id), $categoryId);

        if ($categoryError !== null) {
            return $this->error($categoryError);
        }

        return $this->updateRecord(ServiceCategory::class, $categoryId, $data);
    }

    public function deleteServiceCategory(): array
    {
        $error = $this->validate(['service_category_id' => [__('Service Category ID', 'bit-integrations-pro'), 'integer']]);

        if ($error !== null) {
            return $error;
        }

        $categoryId = $this->int('service_category_id');

        if (Service::query()->where('category_id', $categoryId)->count() > 0) {
            return $this->error(__('The category has services. Move or delete the services first.', 'bit-integrations-pro'), 422);
        }

        if (ServiceCategory::query()->where('parent_id', $categoryId)->count() > 0) {
            return $this->error(__('The category has subcategories. Move or delete the subcategories first.', 'bit-integrations-pro'), 422);
        }

        return $this->deleteRecord(ServiceCategory::class, $categoryId, __('The service category is deleted.', 'bit-integrations-pro'));
    }

    private static function categoryError(string $name, int $parentId, int $categoryId = 0): ?string
    {
        if ($parentId > 0 && empty(ServiceCategory::query()->get($parentId))) {
            return __('The parent category does not exist. Select a different parent category.', 'bit-integrations-pro');
        }

        $nameTaken = ServiceCategory::query()
            ->where('name', $name)
            ->where('parent_id', $parentId)
            ->where('id', '!=', $categoryId)
            ->count();

        return $nameTaken ? __('A category with this name exists at this level. Use a different name.', 'bit-integrations-pro') : null;
    }
}
