<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Actions\GoogleCalendar\GoogleCalendarHelperPro;
use BitApps\IntegrationsPro\Config;
use BitApps\IntegrationsPro\Core\Util\Hooks;

Hooks::filter(Config::withFreePrefix('googlecalendar_rich_description'), [GoogleCalendarHelperPro::class, 'renderDescription'], 10, 3);
