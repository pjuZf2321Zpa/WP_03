<?php

/**
 * OmniSend Record Api
 */

namespace BitApps\IntegrationsPro\Actions\OmniSend;

class OmniSendHelperPro
{
    public static function setCustomProperties($requestParams, $customProperties, $fieldValues)
    {
        $commonClass = bit_integrations_get_class('Core\\Util\\Common');

        $properties = [];

        foreach ($customProperties as $property) {
            $triggerValue = $property->formField;
            $actionValue = $property->omniSendFormField;

            $properties[$actionValue] = ($triggerValue === 'custom' && !empty($property->customValue))
                ? $commonClass::replaceFieldWithValue($property->customValue, $fieldValues)
                : $fieldValues[$triggerValue] ?? null;
        }

        return (object) $properties;
    }
}
