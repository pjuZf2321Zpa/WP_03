<?php

namespace WPAICG\Lib\Integrations\Recipes;

use WPAICG\Lib\Integrations\Recipes\Contracts\AIPKit_Recipe_Executor_Interface;
use WPAICG\Lib\Integrations\Recipes\Contracts\AIPKit_Recipe_Registry_Interface;
use WP_Error;

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

class AIPKit_Recipe_Executor implements AIPKit_Recipe_Executor_Interface
{
    private ?AIPKit_Recipe_Registry_Interface $registry;

    public function __construct(?AIPKit_Recipe_Registry_Interface $registry = null)
    {
        $this->registry = $registry;
    }

    /**
     * @return bool|\WP_Error
     */
    public function can_execute(array $recipe, array $event_envelope)
    {
        if (!AIPKit_Recipe_Runtime_Gate::can_execute_recipe($recipe, ['event_envelope' => $event_envelope])) {
            return new WP_Error(
                'aipkit_recipe_execution_not_allowed',
                __('Native App Recipes is not available for the current plan or runtime context.', 'gpt3-ai-content-generator')
            );
        }

        $recipe_id = sanitize_text_field((string) ($recipe['id'] ?? ''));
        $connection_id = sanitize_text_field((string) ($recipe['connection_id'] ?? ''));
        $event_name = sanitize_text_field((string) ($recipe['event_name'] ?? ''));
        $app_slug = sanitize_key((string) ($recipe['app_slug'] ?? ''));
        $action_slug = sanitize_key((string) ($recipe['action_slug'] ?? ''));
        $envelope_event_name = sanitize_text_field((string) ($event_envelope['type'] ?? ''));

        if ($recipe_id === '' || $connection_id === '' || $event_name === '' || $app_slug === '' || $action_slug === '') {
            return new WP_Error(
                'aipkit_recipe_invalid',
                __('Recipe is missing one or more required execution fields.', 'gpt3-ai-content-generator')
            );
        }

        if ($envelope_event_name === '' || $event_name !== $envelope_event_name) {
            return false;
        }

        if (isset($recipe['is_enabled']) && !$recipe['is_enabled']) {
            return false;
        }

        if (class_exists(AIPKit_Stored_Recipes::class) && !AIPKit_Stored_Recipes::recipe_matches_event_filters($recipe, $event_envelope)) {
            return false;
        }

        return true;
    }

    /**
     * @return mixed[]|\WP_Error
     */
    public function execute(array $recipe, array $event_envelope, array $context = [])
    {
        $can_execute = $this->can_execute($recipe, $event_envelope);
        if (is_wp_error($can_execute)) {
            return $can_execute;
        }

        if ($can_execute !== true) {
            return new WP_Error(
                'aipkit_recipe_event_mismatch',
                __('Recipe cannot execute for the supplied event envelope.', 'gpt3-ai-content-generator')
            );
        }

        $template_slug = sanitize_key((string) ($recipe['template_slug'] ?? ''));
        if ($template_slug !== '' && $this->registry !== null && !$this->registry->has_template($template_slug)) {
            return new WP_Error(
                'aipkit_recipe_template_missing',
                sprintf(
                    /* translators: %s: recipe template slug */
                    __('Recipe template `%s` is not registered.', 'gpt3-ai-content-generator'),
                    $template_slug
                )
            );
        }

        $connection = isset($context['connection']) && is_array($context['connection']) ? $context['connection'] : [];
        if (class_exists(AIPKit_Recipe_Validator::class)) {
            $validation = AIPKit_Recipe_Validator::validate_recipe_for_execution($recipe, $connection);
            if (is_wp_error($validation)) {
                return $validation;
            }
        }

        $execution = [
            'status' => 'pending',
            'recipe_id' => sanitize_text_field((string) ($recipe['id'] ?? '')),
            'connection_id' => sanitize_text_field((string) ($recipe['connection_id'] ?? '')),
            'event_name' => sanitize_text_field((string) ($recipe['event_name'] ?? '')),
            'event_id' => sanitize_text_field((string) ($event_envelope['id'] ?? '')),
            'app_slug' => sanitize_key((string) ($recipe['app_slug'] ?? '')),
            'action_slug' => sanitize_key((string) ($recipe['action_slug'] ?? '')),
            'template_slug' => $template_slug,
            'attempt_count' => 0,
            'meta' => [
                'source_module' => sanitize_key((string) (($event_envelope['source']['module'] ?? '') ?: ($event_envelope['source']['origin'] ?? ''))),
            ],
        ];

        /**
         * Allows app adapters or future execution layers to execute a native app recipe.
         *
         * Returning null means no handler executed the recipe.
         *
         * @param array<string, mixed>|null $result
         * @param array<string, mixed> $execution
         * @param array<string, mixed> $recipe
         * @param array<string, mixed> $event_envelope
         * @param array<string, mixed> $context
         */
        $result = apply_filters(
            'aipkit_native_app_recipe_execute',
            null,
            $execution,
            $recipe,
            $event_envelope,
            $context
        );

        if ($result === null) {
            return new WP_Error(
                'aipkit_recipe_executor_unhandled',
                __('No premium app adapter is registered yet for this recipe action.', 'gpt3-ai-content-generator')
            );
        }

        if (is_wp_error($result)) {
            return $result;
        }

        if (!is_array($result)) {
            return new WP_Error(
                'aipkit_recipe_executor_invalid_result',
                __('Recipe executor returned an invalid result payload.', 'gpt3-ai-content-generator')
            );
        }

        return array_merge($execution, $result);
    }
}
