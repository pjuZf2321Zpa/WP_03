<?php

declare(strict_types=1);

namespace FluentCartPro\App\Services\Invoice\Domain\Tax;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Derives the EN 16931 VAT category code (UNCL 5305) from FluentCart's persisted
 * order tax state. Used for both the document VAT breakdown (BT-118) and per line
 * (BT-151), with the matching rate (BT-119 / BT-152) and exemption reason
 * (BT-120 text / BT-121 code).
 *
 * Handles:
 *   S  — Standard rate (rate > 0)
 *   Z  — Zero rated    (rate == 0, not exempt, not reverse charge)
 *   E  — Exempt        (explicitly flagged; carries an exemption reason)
 *   AE — Reverse charge (rate 0; carries seller + buyer VAT and an exemption reason)
 *
 * Stateless and side-effect free.
 */
final class TaxCategoryResolver
{
    const STANDARD = 'S';

    const ZERO = 'Z';

    const EXEMPT = 'E';

    const REVERSE_CHARGE = 'AE';

    /** EN 16931 VATEX code for the EU reverse-charge mechanism (Article 196). */
    const VATEX_REVERSE_CHARGE = 'VATEX-EU-AE';

    /**
     * Resolve the category for a standard / zero / exempt line or group.
     *
     * @param float $ratePercent Resolved VAT rate for the line / group.
     * @param bool  $isExempt    Whether the line is VAT-exempt (distinct from zero-rated).
     * @return array{categoryCode:string, ratePercent:float, exemptionReasonCode:string, exemptionReasonText:string}
     */
    public function resolve(float $ratePercent, bool $isExempt = false): array
    {
        if ($isExempt) {
            return $this->result(self::EXEMPT, 0.0, '', $this->defaultExemptReasonText());
        }

        if ($ratePercent > 0) {
            return $this->result(self::STANDARD, $ratePercent, '', '');
        }

        return $this->result(self::ZERO, 0.0, '', '');
    }

    /**
     * Resolve a reverse-charge (AE) line or group. Always rate 0 and carries the
     * VATEX-EU-AE exemption code plus a reason (the order's declaration text when
     * supplied, else a localized default).
     *
     * @return array{categoryCode:string, ratePercent:float, exemptionReasonCode:string, exemptionReasonText:string}
     */
    public function resolveReverseCharge(string $exemptionReasonText = ''): array
    {
        $text = $exemptionReasonText !== '' ? $exemptionReasonText : $this->defaultReverseChargeReasonText();

        return $this->result(self::REVERSE_CHARGE, 0.0, self::VATEX_REVERSE_CHARGE, $text);
    }

    /**
     * @return array{categoryCode:string, ratePercent:float, exemptionReasonCode:string, exemptionReasonText:string}
     */
    private function result(string $categoryCode, float $ratePercent, string $exemptionReasonCode, string $exemptionReasonText): array
    {
        return [
            'categoryCode'        => $categoryCode,
            'ratePercent'         => $ratePercent,
            'exemptionReasonCode' => $exemptionReasonCode,
            'exemptionReasonText' => $exemptionReasonText,
        ];
    }

    private function defaultExemptReasonText(): string
    {
        return __('Exempt from VAT', 'fluent-cart-pro');
    }

    private function defaultReverseChargeReasonText(): string
    {
        return __('Reverse charge: VAT to be accounted for by the recipient (Article 196 of Council Directive 2006/112/EC).', 'fluent-cart-pro');
    }
}
