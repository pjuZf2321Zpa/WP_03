/**
 * BuddyBoss Pro — "Subscribe to topics" modal.
 *
 * ES5, no dependencies. Opens on any click of `.js-bb-blog-subscribe-open`,
 * loads categories from the blog-subscriptions/categories REST endpoint, and
 * toggles per-category subscriptions via the generic subscriptions endpoint.
 *
 * @since [BBVERSION]
 */
( function () {
	'use strict';

	function cfg() {
		return window.bbBlogProModal || null;
	}

	function modalEl() {
		return document.getElementById( 'bb-blog-subscribe-modal' );
	}

	// Infinite-scroll pager state for the category list.
	var pager = {
		page: 1,
		perPage: 20,
		loading: false,
		hasMore: true,
		bound: false,
		ticking: false
	};

	function openModal() {
		var modal = modalEl();

		if ( ! modal || ! cfg() ) {
			return;
		}

		pager.perPage = parseInt( cfg().perPage, 10 ) || 20;

		modal.hidden = false;
		document.body.classList.add( 'bb-blog-modal-open' );

		// Bind the scroll listener once — the modal element persists in the DOM
		// across open/close, so re-binding on every open would stack handlers.
		var body = modal.querySelector( '[data-bb-blog-modal-body]' );
		if ( body && ! pager.bound ) {
			body.addEventListener( 'scroll', onBodyScroll );
			pager.bound = true;
		}

		loadCategories( true );
	}

	function closeModal() {
		var modal = modalEl();

		if ( ! modal ) {
			return;
		}

		modal.hidden = true;
		document.body.classList.remove( 'bb-blog-modal-open' );
	}

	/**
	 * Build the categories request URL for a given page.
	 */
	function categoriesUrl( page, perPage ) {
		var url = cfg().categoriesUrl;
		var sep = url.indexOf( '?' ) === -1 ? '?' : '&';

		return url + sep + 'page=' + page + '&per_page=' + perPage;
	}

	/**
	 * Load one page of categories and append it to the list.
	 *
	 * @param {boolean} reset When true, start over from page 1 (used on open).
	 */
	function loadCategories( reset ) {
		var modal = modalEl();

		if ( ! modal || ! cfg() ) {
			return;
		}

		var list        = modal.querySelector( '[data-bb-blog-modal-list]' );
		var loading     = modal.querySelector( '[data-bb-blog-modal-loading]' );
		var empty       = modal.querySelector( '[data-bb-blog-modal-empty]' );
		var loadingMore = modal.querySelector( '[data-bb-blog-modal-loading-more]' );

		if ( reset ) {
			pager.page     = 1;
			pager.hasMore  = true;
			list.innerHTML = '';
			empty.hidden   = true;
		}

		// Nothing left to fetch, or a request is already in flight.
		if ( pager.loading || ! pager.hasMore ) {
			return;
		}

		pager.loading = true;

		// First page uses the full-list loader; subsequent (infinite-scroll)
		// pages use the compact spinner row pinned to the bottom of the list.
		if ( reset ) {
			loading.hidden = false;
		} else if ( loadingMore ) {
			loadingMore.hidden = false;
		}

		window
			.fetch( categoriesUrl( pager.page, pager.perPage ), {
				method: 'GET',
				credentials: 'same-origin',
				headers: { 'X-WP-Nonce': cfg().nonce }
			} )
			.then( function ( response ) {
				return response.ok ? response.json() : [];
			} )
			.then( function ( items ) {
				pager.loading  = false;
				loading.hidden = true;
				if ( loadingMore ) {
					loadingMore.hidden = true;
				}

				var count = items ? items.length : 0;
				var i;

				for ( i = 0; i < count; i++ ) {
					list.appendChild( renderRow( items[ i ] ) );
				}

				// A short page (fewer rows than requested) is the last page.
				if ( count < pager.perPage ) {
					pager.hasMore = false;
				} else {
					pager.page += 1;
				}

				// Empty state only when the very first page returned nothing.
				empty.hidden = list.children.length > 0;
			} )
			['catch']( function () {
				pager.loading  = false;
				loading.hidden = true;
				if ( loadingMore ) {
					loadingMore.hidden = true;
				}
				empty.hidden = list.children.length > 0;
			} );
	}

	/**
	 * Near-bottom scroll handler: prefetch the next page.
	 */
	function onBodyScroll( event ) {
		// Capture the element synchronously — event.currentTarget is null once
		// the event finishes dispatching, before the rAF callback runs.
		var body = event.currentTarget;

		// Throttle: scroll fires many times per second, so coalesce to at most
		// one position check per animation frame.
		if ( pager.ticking ) {
			return;
		}
		pager.ticking = true;

		window.requestAnimationFrame( function () {
			pager.ticking = false;

			// In-flight guard: never start a second request while one is still
			// pending, and stop entirely once the last page has arrived.
			if ( pager.loading || ! pager.hasMore ) {
				return;
			}

			if ( body.scrollTop + body.clientHeight >= body.scrollHeight - 80 ) {
				loadCategories( false );
			}
		} );
	}

	/**
	 * Build one "<count> Posts on this topic" line, with the count in its own
	 * span so it can carry the darker/medium treatment from the design.
	 *
	 * Splits the translated string on `%d` rather than interpolating HTML into
	 * it, so translations stay intact and nothing is injected as markup.
	 */
	function fillCount( countEl, count ) {
		var template = ( cfg().i18n && cfg().i18n.postsOnTopic ) ? cfg().i18n.postsOnTopic : '%d Posts on this topic';
		var parts    = template.split( '%d' );
		var valueEl  = document.createElement( 'span' );

		valueEl.className   = 'bb-blog-subscribe-modal__count-value';
		valueEl.textContent = String( count );

		countEl.textContent = '';
		countEl.appendChild( document.createTextNode( parts[ 0 ] || '' ) );
		countEl.appendChild( valueEl );
		countEl.appendChild( document.createTextNode( parts[ 1 ] || '' ) );
	}

	/**
	 * One state of the toggle: an icon + label pair. All three are rendered up
	 * front and CSS reveals whichever the button's state calls for — the
	 * "Subscribed → Unsubscribed" swap is a pure hover effect, so it can't be
	 * driven from JS.
	 */
	function state( name, icon ) {
		return (
			'<span class="bb-blog-subscribe__state bb-blog-subscribe__state--' + name + '">' +
				'<i class="' + icon + ' bb-blog-subscribe__icon" aria-hidden="true"></i>' +
				'<span class="bb-blog-subscribe__label"></span>' +
			'</span>'
		);
	}

	/**
	 * Icon class for a control, from the localized map.
	 *
	 * The map is resolved server-side so ReadyLaunch keeps its own glyph font while
	 * other themes use the classic BuddyBoss icons that are already on the page.
	 *
	 * @since [BBVERSION]
	 *
	 * @param {string} key      Icon key.
	 * @param {string} fallback Class to use when the map is unavailable.
	 * @return {string} Icon class.
	 */
	function icon( key, fallback ) {
		var conf = cfg();
		return ( conf && conf.icons && conf.icons[ key ] ) ? conf.icons[ key ] : fallback;
	}

	function renderRow( item ) {
		var labels = cfg().labels || {};
		var li     = document.createElement( 'li' );
		li.className = 'bb-blog-subscribe-modal__item';

		li.innerHTML =
			'<span class="bb-blog-subscribe-modal__icon"><i class="' + icon( 'pin', 'bb-icons-rl-push-pin' ) + '" aria-hidden="true"></i></span>' +
			'<span class="bb-blog-subscribe-modal__meta">' +
				'<span class="bb-blog-subscribe-modal__name"></span>' +
				'<span class="bb-blog-subscribe-modal__count"></span>' +
			'</span>' +
			'<button type="button" class="bb-blog-subscribe' + ( item.subscribed ? ' is-subscribed' : '' ) + '" ' +
				'data-term-id="' + parseInt( item.term_id, 10 ) + '" ' +
				'data-subscription-id="' + parseInt( item.subscription_id, 10 ) + '" ' +
				'aria-pressed="' + ( item.subscribed ? 'true' : 'false' ) + '">' +
				state( 'subscribe', icon( 'plus', 'bb-icons-rl-plus' ) ) +
				state( 'subscribed', icon( 'bellRinging', 'bb-icons-rl-bell-ringing' ) ) +
				state( 'unsubscribe', icon( 'minus', 'bb-icons-rl-minus' ) ) +
			'</button>';

		// textContent avoids injecting term names / labels as HTML.
		li.querySelector( '.bb-blog-subscribe-modal__name' ).textContent = item.name;
		fillCount( li.querySelector( '.bb-blog-subscribe-modal__count' ), item.count );

		var stateLabels = [
			[ 'subscribe', labels.subscribe || 'Subscribe' ],
			[ 'subscribed', labels.subscribed || 'Subscribed' ],
			[ 'unsubscribe', labels.unsubscribed || 'Unsubscribed' ]
		];
		var i;

		for ( i = 0; i < stateLabels.length; i++ ) {
			li.querySelector(
				'.bb-blog-subscribe__state--' + stateLabels[ i ][ 0 ] + ' .bb-blog-subscribe__label'
			).textContent = stateLabels[ i ][ 1 ];
		}

		return li;
	}

	function toggle( button ) {
		if ( ! cfg() || button.getAttribute( 'data-bb-blog-busy' ) ) {
			return;
		}

		var termId = button.getAttribute( 'data-term-id' );

		if ( ! termId ) {
			return;
		}

		var isSubscribed   = button.classList.contains( 'is-subscribed' );
		var subscriptionId = button.getAttribute( 'data-subscription-id' );
		var base           = cfg().subscriptionsUrl;
		var url            = base;
		var method         = 'POST';
		var body           = null;
		var headers        = { 'X-WP-Nonce': cfg().nonce };

		if ( isSubscribed && subscriptionId && '0' !== subscriptionId ) {
			url    = base.replace( /\/$/, '' ) + '/' + subscriptionId;
			method = 'DELETE';
		} else {
			headers[ 'Content-Type' ] = 'application/json';
			body = JSON.stringify( { type: 'blog_category', item_id: parseInt( termId, 10 ) } );
		}

		button.setAttribute( 'data-bb-blog-busy', '1' );
		button.disabled = true;

		window
			.fetch( url, { method: method, credentials: 'same-origin', headers: headers, body: body } )
			.then( function ( response ) {
				if ( 204 === response.status ) {
					return {};
				}

				return response.ok ? response.json() : null;
			} )
			.then( function ( response ) {
				if ( null === response ) {
					return;
				}

				if ( isSubscribed ) {
					updateButton( button, false, 0 );

					if ( button.getAttribute( 'data-bb-remove-on-unsub' ) ) {
						var row = button.closest ? button.closest( '.bb-blog-subscription-item' ) : null;

						if ( row && row.parentNode ) {
							row.parentNode.removeChild( row );
						}
					}
				} else if ( response && response.id ) {
					updateButton( button, true, response.id );
				}
			} )
			['catch']( function () {} )
			.then( function () {
				button.removeAttribute( 'data-bb-blog-busy' );
				button.disabled = false;
			} );
	}

	/**
	 * Every icon/label pair already lives in the button (see `renderRow`), so
	 * flipping `is-subscribed` is all it takes — CSS picks the right one.
	 */
	function updateButton( button, subscribed, subscriptionId ) {
		button.setAttribute( 'data-subscription-id', subscriptionId );
		button.classList.toggle( 'is-subscribed', !! subscribed );
		button.setAttribute( 'aria-pressed', subscribed ? 'true' : 'false' );
	}

	document.addEventListener( 'click', function ( event ) {
		var opener = event.target.closest ? event.target.closest( '.js-bb-blog-subscribe-open' ) : null;

		if ( opener ) {
			event.preventDefault();
			openModal();
			return;
		}

		if ( event.target.closest && event.target.closest( '[data-bb-blog-modal-close]' ) ) {
			event.preventDefault();
			closeModal();
			return;
		}

		var toggleBtn = event.target.closest ? event.target.closest( '.bb-blog-subscribe' ) : null;

		if ( toggleBtn ) {
			event.preventDefault();
			toggle( toggleBtn );
		}
	} );

	document.addEventListener( 'keyup', function ( event ) {
		if ( 'Escape' === event.key ) {
			closeModal();
		}
	} );
} )();
