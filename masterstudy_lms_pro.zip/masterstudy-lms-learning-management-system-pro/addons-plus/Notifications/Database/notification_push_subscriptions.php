<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

function masterstudy_lms_notification_push_subscriptions_table_query() {
	global $wpdb;

	$table_name      = masterstudy_lms_notification_push_subscriptions_table_name( $wpdb );
	$charset_collate = $wpdb->get_charset_collate();

	$sql = "CREATE TABLE $table_name (
		id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
		user_id BIGINT(20) UNSIGNED NOT NULL,
		browser_key VARCHAR(191) NOT NULL,
		endpoint_hash VARCHAR(64) NOT NULL,
		endpoint TEXT NOT NULL,
		public_key TEXT NOT NULL,
		auth_token TEXT NOT NULL,
		content_encoding VARCHAR(30) DEFAULT 'aes128gcm',
		subscription LONGTEXT NOT NULL,
		status VARCHAR(20) NOT NULL DEFAULT 'active',
		user_agent TEXT,
		created_at_gmt DATETIME NOT NULL,
		updated_at_gmt DATETIME NOT NULL,
		PRIMARY KEY (id),
		UNIQUE KEY browser_key (browser_key),
		INDEX idx_endpoint_hash (endpoint_hash),
		INDEX idx_user_status (user_id,status),
		INDEX idx_user_status_updated (user_id,status,updated_at_gmt),
		INDEX idx_status_updated_id (status,updated_at_gmt,id)
	) $charset_collate;";

	require_once ABSPATH . 'wp-admin/includes/upgrade.php';

	dbDelta( $sql );
}
