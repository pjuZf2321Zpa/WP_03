<?php

namespace FluentCartPro\App\Modules\PaymentMethods\PaddleGateway;

use FluentCart\App\Helpers\CurrenciesHelper;
use FluentCart\Framework\Support\Arr;

/**
 * Gateway-agnostic normalized view of what a Merchant-of-Record actually captured.
 *
 * The reconciliation core reasons only against this struct, never against a raw
 * gateway payload. A thin per-gateway adapter (here: ::fromPaddle) maps the
 * provider response onto these fields. To onboard another MoR gateway, add a
 * sibling adapter that produces a CapturedCharge — the reconciler does not change.
 *
 * All money is in integer minor units (cents) in the charged currency.
 */
class CapturedCharge
{
    /** @var string Charged (buyer) currency, uppercased. Empty if unknown. */
    public $currency = '';

    /** @var int Net goods total before tax (after per-line discounts). */
    public $subtotal = 0;

    /** @var int Discount total. */
    public $discount = 0;

    /** @var int Tax total. 0 == tax not applied (exempt / reverse charge). */
    public $tax = 0;

    /** @var int Captured total = subtotal - discount + tax. */
    public $total = 0;

    /** @var array Raw totals blob (kept for meta/accounting). */
    public $totals = [];

    /** @var array Line items (provider shape, used for refund/recurring mapping). */
    public $lineItems = [];

    /** @var array Applied tax rates. Empty/0% corroborates reverse charge. */
    public $taxRatesUsed = [];

    /** @var array FX / payout blob (exchange_rate + settled amount). */
    public $fx = [];

    /** @var array Top-level checkout items (carry billing_cycle for recurring detection). */
    public $items = [];

    /** @var string Paddle business id (buyer's registered business), empty if the buyer checked out as an individual. */
    public $businessId = '';

    /** @var string Paddle customer id — required alongside businessId to fetch the business record (GET /customers/{id}/businesses/{id}). */
    public $customerId = '';

    /**
     * Build a normalized charge from a Paddle transaction object
     * (GET /transactions/{id} -> data, or a webhook transaction payload).
     */
    public static function fromPaddle($charge): self
    {
        $self = new self();

        $details = Arr::get($charge, 'details', []);
        $totals  = (array) Arr::get($details, 'totals', []);

        $self->currency = strtoupper((string) (
            Arr::get($charge, 'currency_code')
                ?: Arr::get($totals, 'currency_code', '')
        ));

        $self->subtotal     = (int) Arr::get($totals, 'subtotal', 0);
        $self->discount     = (int) Arr::get($totals, 'discount', 0);
        $self->tax          = (int) Arr::get($totals, 'tax', 0);
        $self->total        = (int) Arr::get($totals, 'total', 0);
        $self->totals       = $totals;
        $self->lineItems    = (array) Arr::get($details, 'line_items', []);
        $self->taxRatesUsed = (array) Arr::get($details, 'tax_rates_used', []);
        $self->fx           = (array) Arr::get($details, 'payout_totals', []);
        $self->items        = (array) Arr::get($charge, 'items', []);
        $self->businessId   = (string) Arr::get($charge, 'business_id', '');
        $self->customerId   = (string) Arr::get($charge, 'customer_id', '');

        // FluentCart stores all monetary amounts ×100 (cents convention), including
        // zero-decimal currencies like JPY. Paddle returns JPY as whole units (16168),
        // so multiply to match the internal convention — same as Stripe does.
        if ($self->currency && CurrenciesHelper::isZeroDecimal($self->currency)) {
            $self->subtotal *= 100;
            $self->discount *= 100;
            $self->tax      *= 100;
            $self->total    *= 100;
        }

        return $self;
    }
}
