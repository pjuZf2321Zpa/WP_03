<?php
/** Paid RSS, URL and Google Sheets source panels, shared by both writing screens. */
if (!defined('ABSPATH')) {
    exit;
}
if (empty($is_pro) || !class_exists('\\WPAICG\\aipkit_dashboard') || !\WPAICG\aipkit_dashboard::is_pro_plan()) {
    return;
}

$aipkit_autogpt_source_mode = !empty($aipkit_autogpt_source_mode);
$aipkit_show_rss_fetch_button = !empty($aipkit_show_rss_fetch_button);
switch ($aipkit_cw_source_mode ?? '') {
    case 'rss':
        ?>
<div class="aipkit_rss_import_container aipkit_cw_source_mode_shell aipkit_cw_source_mode_shell--rss" data-rss-container>
    <?php if (!$aipkit_autogpt_source_mode): ?>
    <div class="aipkit_cw_source_mode_header">
        <h3 class="aipkit_cw_source_mode_title"><?php esc_html_e('Import from RSS feeds', 'gpt3-ai-content-generator'); ?></h3>
        <p class="aipkit_cw_source_mode_desc"><?php esc_html_e('Add one feed URL per line, then filter titles before you fetch items into the writer.', 'gpt3-ai-content-generator'); ?></p>
    </div>
    <?php endif; ?>

    <div class="aipkit_cw_source_mode_stage">
        <div class="aipkit_rss_feeds_section" data-rss-input-zone>
            <div class="aipkit_rss_textarea_wrapper">
                <textarea
                    id="aipkit_cw_rss_feeds"
                    name="rss_feeds"
                    class="aipkit_form-input aipkit_rss_textarea aipkit_autosave_trigger"
                    rows="6"
                    placeholder="<?php esc_attr_e("https://example.com/feed/\nhttps://blog.example.org/rss", 'gpt3-ai-content-generator'); ?>"
                ></textarea>
            </div>
        </div>

        <input type="hidden" id="aipkit_cw_rss_items_count" name="rss_items_count" value="0" data-rss-items-count>

        <div class="aipkit_rss_filters_grid">
            <div class="aipkit_rss_filter_card" data-rss-quantity>
                <label class="aipkit_rss_filter_label" for="aipkit_cw_rss_quantity_mode">
                    <?php esc_html_e('Articles to fetch', 'gpt3-ai-content-generator'); ?>
                </label>
                <div class="aipkit_rss_quantity_controls">
                    <select id="aipkit_cw_rss_quantity_mode" class="aipkit_form-input aipkit_rss_filter_input" data-rss-quantity-mode aria-describedby="aipkit_cw_rss_quantity_hint">
                        <option value="all"><?php esc_html_e('All available', 'gpt3-ai-content-generator'); ?></option>
                        <option value="limit"><?php esc_html_e('Limit number', 'gpt3-ai-content-generator'); ?></option>
                    </select>
                    <div data-rss-quantity-number-wrapper hidden>
                        <label class="screen-reader-text" for="aipkit_cw_rss_quantity_number"><?php esc_html_e('Maximum articles across all feeds', 'gpt3-ai-content-generator'); ?></label>
                        <input type="number" id="aipkit_cw_rss_quantity_number" class="aipkit_form-input aipkit_rss_filter_input" value="3" min="1" step="1" inputmode="numeric" data-rss-quantity-number disabled aria-describedby="aipkit_cw_rss_quantity_hint">
                    </div>
                </div>
                <input type="hidden" name="rss_item_limit" value="0" class="aipkit_autosave_trigger" data-rss-item-limit>
            </div>

            <div class="aipkit_rss_filter_card aipkit_rss_filter_card--include">
                <div class="aipkit_rss_filter_header">
                    <label class="aipkit_rss_filter_label" for="aipkit_cw_rss_include_keywords">
                        <?php esc_html_e('Only titles containing', 'gpt3-ai-content-generator'); ?>
                    </label>
                </div>
                <input
                    type="text"
                    id="aipkit_cw_rss_include_keywords"
                    name="rss_include_keywords"
                    class="aipkit_form-input aipkit_rss_filter_input aipkit_autosave_trigger"
                    placeholder="<?php esc_attr_e('wordpress, ai, tutorial', 'gpt3-ai-content-generator'); ?>"
                >
            </div>

            <div class="aipkit_rss_filter_card aipkit_rss_filter_card--exclude">
                <div class="aipkit_rss_filter_header">
                    <label class="aipkit_rss_filter_label" for="aipkit_cw_rss_exclude_keywords">
                        <?php esc_html_e('Skip titles containing', 'gpt3-ai-content-generator'); ?>
                    </label>
                </div>
                <input
                    type="text"
                    id="aipkit_cw_rss_exclude_keywords"
                    name="rss_exclude_keywords"
                    class="aipkit_form-input aipkit_rss_filter_input aipkit_autosave_trigger"
                    placeholder="<?php esc_attr_e('review, sponsored, update', 'gpt3-ai-content-generator'); ?>"
                >
            </div>
            <span id="aipkit_cw_rss_quantity_hint" class="aipkit_rss_filter_hint" data-rss-quantity-hint><?php esc_html_e('Use all matching articles currently available across your feeds.', 'gpt3-ai-content-generator'); ?></span>
        </div>

        <div class="aipkit_rss_status_container" id="aipkit_cw_rss_status_container" data-rss-status hidden>
            <div class="aipkit_rss_status_card" data-rss-status-card>
                <div class="aipkit_rss_status_icon" data-rss-status-icon>
                    <span class="dashicons dashicons-yes-alt" aria-hidden="true"></span>
                </div>
                <div class="aipkit_rss_status_content">
                    <span class="aipkit_rss_status_title" data-rss-status-title></span>
                    <span class="aipkit_rss_status_message" data-rss-status-message></span>
                    <button
                        type="button"
                        class="aipkit_rss_title_preview_toggle"
                        data-rss-title-preview-toggle
                        aria-expanded="false"
                        aria-controls="aipkit_cw_rss_title_preview"
                        hidden
                    >
                        <span data-rss-title-preview-label><?php esc_html_e('Preview titles', 'gpt3-ai-content-generator'); ?></span>
                        <span class="dashicons dashicons-arrow-down-alt2" aria-hidden="true"></span>
                    </button>
                    <ol
                        id="aipkit_cw_rss_title_preview"
                        class="aipkit_rss_title_preview"
                        data-rss-title-preview
                        hidden
                    ></ol>
                </div>
                <button type="button" class="aipkit_rss_status_edit_btn" data-rss-edit-btn aria-label="<?php esc_attr_e('Edit feeds', 'gpt3-ai-content-generator'); ?>">
                    <span class="dashicons dashicons-edit" aria-hidden="true"></span>
                </button>
            </div>
        </div>

        <?php if ($aipkit_show_rss_fetch_button): ?>
            <div class="aipkit_rss_fetch_row">
                <button type="button" class="aipkit_rss_fetch_btn" data-rss-fetch-btn>
                    <span class="dashicons dashicons-rss" aria-hidden="true"></span>
                    <span class="aipkit_btn-text"><?php esc_html_e('Fetch feeds', 'gpt3-ai-content-generator'); ?></span>
                </button>
            </div>
        <?php endif; ?>
    </div>
</div>
        <?php
        break;
    case 'url':
        ?>
<div class="aipkit_url_import_container aipkit_cw_source_mode_shell aipkit_cw_source_mode_shell--url" data-url-container>
    <?php if (!$aipkit_autogpt_source_mode): ?>
    <div class="aipkit_cw_source_mode_header">
        <h3 class="aipkit_cw_source_mode_title"><?php esc_html_e('Import from web pages', 'gpt3-ai-content-generator'); ?></h3>
        <p class="aipkit_cw_source_mode_desc"><?php esc_html_e('Add one URL per line, then preview the first page before generating from the list.', 'gpt3-ai-content-generator'); ?></p>
    </div>
    <?php endif; ?>

    <div class="aipkit_cw_source_mode_stage">
        <div class="aipkit_url_input_section" data-url-input-zone>
            <textarea
                id="aipkit_cw_url_list"
                name="url_list"
                class="aipkit_form-input aipkit_url_textarea aipkit_autosave_trigger"
                rows="6"
                placeholder="<?php esc_attr_e("https://example.com/article-1\nhttps://blog.example.org/post", 'gpt3-ai-content-generator'); ?>"
            ></textarea>
            <p class="aipkit_url_count_caption" data-url-count-caption aria-live="polite">
                <span data-url-count>0</span>
                <span data-url-count-label><?php esc_html_e('URLs', 'gpt3-ai-content-generator'); ?></span>
            </p>
        </div>

        <div class="aipkit_url_status_container" id="aipkit_cw_scrape_results_wrapper" data-url-status hidden>
            <div class="aipkit_url_status_card" data-url-status-card>
                <div class="aipkit_url_status_header">
                    <div class="aipkit_url_status_icon" data-url-status-icon>
                        <span class="dashicons dashicons-yes-alt" aria-hidden="true"></span>
                    </div>
                    <div class="aipkit_url_status_title_block">
                        <span class="aipkit_url_status_title"><?php esc_html_e('Content preview', 'gpt3-ai-content-generator'); ?></span>
                        <span class="aipkit_url_status_hint" data-url-preview-hint></span>
                    </div>
                    <button type="button" class="aipkit_url_status_close_btn" data-url-preview-close aria-label="<?php esc_attr_e('Close preview', 'gpt3-ai-content-generator'); ?>">
                        <span class="dashicons dashicons-no-alt" aria-hidden="true"></span>
                    </button>
                </div>
                <div class="aipkit_url_preview_content">
                    <p class="aipkit_url_preview_metadata" data-url-preview-metadata hidden></p>
                    <div id="aipkit_cw_scrape_results" class="aipkit_url_preview_text" data-url-preview-text></div>
                </div>
            </div>
        </div>
    </div>

    <div class="aipkit_cw_source_mode_footer aipkit_url_footer">
        <div class="aipkit_url_actions">
            <button type="button" id="aipkit_cw_test_scrape_btn" class="button button-secondary aipkit_btn aipkit_btn-secondary aipkit_btn-small aipkit_cw_button_match aipkit_url_test_btn">
                <span class="aipkit_btn-text"><?php esc_html_e('Test first URL', 'gpt3-ai-content-generator'); ?></span>
                <span class="aipkit_spinner" style="display:none;"></span>
            </button>
        </div>
    </div>
</div>
        <?php
        break;
    case 'gsheets':
        ?>
<div class="aipkit_gsheets_import_container aipkit_gsheets_section_container aipkit_cw_source_mode_shell aipkit_cw_source_mode_shell--gsheets" data-gsheets-container>
    <?php if (!$aipkit_autogpt_source_mode): ?>
    <div class="aipkit_cw_source_mode_header">
        <h3 class="aipkit_cw_source_mode_title"><?php esc_html_e('Import from Google Sheets', 'gpt3-ai-content-generator'); ?></h3>
        <p class="aipkit_cw_source_mode_desc"><?php esc_html_e('Add your sheet ID, verify access with a service account JSON file, and use rows as generation input.', 'gpt3-ai-content-generator'); ?></p>
    </div>
    <?php endif; ?>

    <div class="aipkit_cw_source_mode_stage">
        <div class="aipkit_gsheets_connection_shell" data-gsheets-shell data-gsheets-lock-state="open">
            <div class="aipkit_gsheets_connection_summary aipkit_gsheets_connection_summary--compact" data-gsheets-summary hidden>
                <div class="aipkit_gsheets_summary_primary">
                    <span class="aipkit_gsheets_summary_badge" data-gsheets-summary-badge data-state="idle"></span>
                </div>

                <div class="aipkit_gsheets_summary_actions">
                    <button type="button" class="button button-secondary aipkit_btn aipkit_btn-secondary aipkit_btn-small aipkit_cw_button_match aipkit_gsheets_lock_toggle" data-gsheets-lock-toggle hidden>
                        <?php esc_html_e('Lock', 'gpt3-ai-content-generator'); ?>
                    </button>
                    <div class="aipkit_gsheets_shortcut_link_wrapper" style="display: none;">
                        <a href="#" target="_blank" rel="noopener noreferrer" class="button button-primary aipkit_btn aipkit_btn-primary aipkit_btn-small aipkit_cw_button_match aipkit_gsheets_shortcut_link" aria-label="<?php esc_attr_e('Open spreadsheet in new tab', 'gpt3-ai-content-generator'); ?>">
                            <span class="dashicons dashicons-external" aria-hidden="true"></span>
                            <span class="aipkit_gsheets_shortcut_label"><?php esc_html_e('Open', 'gpt3-ai-content-generator'); ?></span>
                        </a>
                    </div>
                </div>
            </div>

            <div class="aipkit_gsheets_editor" data-gsheets-editor>
                <div class="aipkit_gsheets_editor_grid">
                    <div class="aipkit_gsheets_input_section" data-gsheets-input-zone>
                        <div class="aipkit_gsheets_field_heading">
                            <label class="aipkit_gsheets_label" for="aipkit_cw_gsheets_sheet_id"><?php esc_html_e('Sheet ID', 'gpt3-ai-content-generator'); ?></label>
                            <span class="aipkit_gsheets_inline_status" data-gsheets-summary-sheet data-state="missing"><?php esc_html_e('Missing', 'gpt3-ai-content-generator'); ?></span>
                        </div>
                        <div class="aipkit_gsheets_id_input_wrapper">
                            <input
                                type="text"
                                id="aipkit_cw_gsheets_sheet_id"
                                name="gsheets_sheet_id"
                                class="aipkit_form-input aipkit_gsheets_id_input aipkit_autosave_trigger aipkit_gsheets_sheet_id_input"
                                placeholder="<?php esc_attr_e('Paste the ID from your sheet URL', 'gpt3-ai-content-generator'); ?>"
                            >
                        </div>
                    </div>

                    <div class="aipkit_gsheets_credentials_section">
                        <div class="aipkit_gsheets_field_heading">
                            <label class="aipkit_gsheets_label" for="aipkit_cw_gsheets_credentials_file"><?php esc_html_e('Credentials', 'gpt3-ai-content-generator'); ?></label>
                            <span class="aipkit_gsheets_inline_status" data-gsheets-summary-file data-state="missing"><?php esc_html_e('Missing', 'gpt3-ai-content-generator'); ?></span>
                        </div>
                        <?php if (!$aipkit_autogpt_source_mode): ?>
                            <div class="aipkit_gsheets_credentials_control">
                        <?php endif; ?>
                        <div class="aipkit_gsheets_upload_zone" data-gsheets-dropzone>
                            <div class="aipkit_gsheets_upload_content">
                                <div class="aipkit_gsheets_upload_icon_wrapper">
                                    <span class="dashicons dashicons-upload" aria-hidden="true"></span>
                                </div>
                                <div class="aipkit_gsheets_upload_text">
                                    <span class="aipkit_gsheets_upload_primary"><?php esc_html_e('Upload credentials.json', 'gpt3-ai-content-generator'); ?></span>
                                </div>
                            </div>
                            <input
                                type="file"
                                id="aipkit_cw_gsheets_credentials_file"
                                name="gsheets_credentials_file"
                                class="aipkit_gsheets_credentials_file_input"
                                accept=".json,application/json"
                            >
                            <textarea id="aipkit_cw_gsheets_credentials" name="gsheets_credentials" class="aipkit_autosave_trigger aipkit_gsheets_credentials_hidden_input" style="display:none;"></textarea>
                        </div>

                        <div class="aipkit_gsheets_file_badge" data-gsheets-file-badge style="display: none;">
                            <div class="aipkit_gsheets_file_info">
                                <span class="dashicons dashicons-media-code" aria-hidden="true"></span>
                                <span class="aipkit_gsheets_file_display"></span>
                            </div>
                            <button type="button" class="aipkit_gsheets_file_remove" data-gsheets-remove-file aria-label="<?php esc_attr_e('Remove file', 'gpt3-ai-content-generator'); ?>">
                                <span class="dashicons dashicons-no-alt" aria-hidden="true"></span>
                            </button>
                        </div>
                        <?php if (!$aipkit_autogpt_source_mode): ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="aipkit_gsheets_status_container" data-gsheets-status></div>
            </div>
        </div>
    </div>

    <p class="aipkit_cw_source_format_hint">
        <span><?php esc_html_e('Expected columns: topic, keywords, category ID, author login, post type, and schedule.', 'gpt3-ai-content-generator'); ?></span>
        <a href="https://docs.google.com/spreadsheets/d/18QIWggMmbTVTb-nztTo7SFdGJTUC6kwRxgc841xq4x0/edit?gid=0#gid=0" target="_blank" rel="noopener noreferrer" class="aipkit_cw_paste_sample_link"><?php esc_html_e('View sample sheet', 'gpt3-ai-content-generator'); ?></a>
    </p>
</div>
        <?php
        break;
}
