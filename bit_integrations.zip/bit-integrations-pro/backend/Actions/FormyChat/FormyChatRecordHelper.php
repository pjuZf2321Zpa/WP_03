<?php

namespace BitApps\IntegrationsPro\Actions\FormyChat;

final class FormyChatRecordHelper
{
    public static function createLead($response, $fieldData, $widgetId = null)
    {
        if (!class_exists(\FormyChat\Models\Lead::class)) {
            return ['success' => false, 'message' => __('FormyChat Lead model not found', 'bit-integrations-pro')];
        }

        if (empty($widgetId)) {
            return ['success' => false, 'message' => __('FormyChat widget ID is required', 'bit-integrations-pro')];
        }

        $note = $fieldData['note'] ?? '';
        $meta = $fieldData['_meta'] ?? [];
        $fields = array_filter(
            $fieldData,
            static function ($key) {
                return $key !== 'note' && $key !== '_meta';
            },
            ARRAY_FILTER_USE_KEY
        );

        $leadData = [
            'widget_id' => $widgetId,
            'field'     => $fields,
            'meta'      => $meta,
            'note'      => $note,
            'form'      => 'formychat',
        ];

        $leadId = \FormyChat\Models\Lead::create($leadData);

        if (empty($leadId)) {
            return [
                'success' => false,
                'message' => __('Failed to create FormyChat lead', 'bit-integrations-pro'),
            ];
        }

        $lead = \FormyChat\Models\Lead::find($leadId);

        return [
            'success' => true,
            'message' => __('FormyChat lead created successfully', 'bit-integrations-pro'),
            'data'    => $lead ? (array) $lead : ['id' => $leadId],
        ];
    }
}
