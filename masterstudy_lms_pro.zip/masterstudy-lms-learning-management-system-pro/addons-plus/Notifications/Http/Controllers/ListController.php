<?php

namespace MasterStudy\Lms\Pro\AddonsPlus\Notifications\Http\Controllers;

use MasterStudy\Lms\Http\WpResponseFactory;
use MasterStudy\Lms\Pro\AddonsPlus\Notifications\Http\Serializers\NotificationSerializer;
use MasterStudy\Lms\Pro\AddonsPlus\Notifications\Repositories\NotificationRepository;
use MasterStudy\Lms\Validation\Validator;
use WP_REST_Request;
use WP_REST_Response;

final class ListController {
	public function __invoke( WP_REST_Request $request ): WP_REST_Response {
		try {
			if ( ! function_exists( 'masterstudy_lms_is_notifications_frontend_available' ) || ! masterstudy_lms_is_notifications_frontend_available() ) {
				return WpResponseFactory::forbidden();
			}

			$validator = new Validator(
				$request->get_query_params(),
				array(
					'page'          => 'nullable|integer|min,1',
					'per_page'      => 'nullable|integer|min,1|max,50',
					'unread'        => 'nullable|boolean',
					'include_items' => 'nullable|boolean',
				)
			);

			if ( $validator->fails() ) {
				return WpResponseFactory::validation_failed( $validator->get_errors_array() );
			}

			$params = $validator->get_validated();

			$user_id       = get_current_user_id();
			$page          = max( 1, absint( $params['page'] ?? 1 ) );
			$per_page      = min( 50, max( 1, absint( $params['per_page'] ?? 20 ) ) );
			$unread_only   = rest_sanitize_boolean( $params['unread'] ?? false );
			$repository    = new NotificationRepository();
			$unread_count  = $repository->unread_count( $user_id );
			$include_items = ! array_key_exists( 'include_items', $params ) || rest_sanitize_boolean( $params['include_items'] );

			if ( ! $include_items ) {
				return new WP_REST_Response(
					array(
						'items'        => array(),
						'unread_count' => $unread_count,
						'has_more'     => false,
					)
				);
			}

			$rows     = $repository->get_for_user( $user_id, $page, $per_page, $unread_only, $per_page + 1 );
			$has_more = count( $rows ) > $per_page;

			return new WP_REST_Response(
				array(
					'items'        => ( new NotificationSerializer() )->collection_to_array( array_slice( $rows, 0, $per_page ) ),
					'unread_count' => $unread_count,
					'has_more'     => $has_more,
				)
			);
		} catch ( \Throwable $error ) {
			return WpResponseFactory::error( esc_html__( 'Unable to load notifications.', 'masterstudy-lms-learning-management-system-pro' ) );
		}
	}
}
