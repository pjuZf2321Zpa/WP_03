<?php

namespace BitApps\IntegrationsPro\Actions\NiroHelp\Services;

use BitApps\IntegrationsPro\Actions\NiroHelp\NiroHelpHelper;
use BitApps\IntegrationsPro\Core\Util\Hooks;
use NiroHelp\Models\Doc;

if (!\defined('ABSPATH')) {
    exit;
}

final class DocService extends BaseService
{
    public function createDoc(): array
    {
        $error = $this->validateRequiredFields([
            'title'     => __('Title', 'bit-integrations-pro'),
            'author_id' => __('Author', 'bit-integrations-pro'),
        ]);

        if ($error !== null) {
            return $error;
        }

        if (!get_userdata((int) $this->getInteger('author_id'))) {
            return $this->errorResponse(__('The author does not exist. Select a different user.', 'bit-integrations-pro'));
        }

        $fieldError = $this->checkDocFields();

        if ($fieldError !== '') {
            return $this->errorResponse($fieldError);
        }

        $doc = new Doc();
        $docId = $doc->create([
            'title'       => wp_slash($this->getString('title')),
            'slug'        => $this->getString('slug'),
            'description' => wp_slash($this->getString('content')),
            'status'      => $this->hasValue('status') ? $this->getString('status') : 'publish',
            'user_id'     => (int) $this->getInteger('author_id'),
            'taxo'        => $this->docTerms(),
        ]);

        if (!$docId) {
            return $this->errorResponse(__('NiroHelp did not create the doc. Try again.', 'bit-integrations-pro'));
        }

        Hooks::run('nirohelp-doc_created', $doc);

        return $this->successResponse(__('The doc is created.', 'bit-integrations-pro'), NiroHelpHelper::getDocData($docId));
    }

    public function updateDoc(): array
    {
        $error = $this->validateRequiredFields(['doc_id' => __('Doc ID', 'bit-integrations-pro')]);

        if ($error !== null) {
            return $error;
        }

        $doc = new Doc((int) $this->getInteger('doc_id'));

        if (!$doc->exists()) {
            return $this->docNotFound();
        }

        if ($doc->get_status() === 'trash') {
            return $this->errorResponse(__('The doc is in the Trash. Restore the doc in NiroHelp first.', 'bit-integrations-pro'));
        }

        $fieldError = $this->checkDocFields();

        if ($fieldError !== '') {
            return $this->errorResponse($fieldError);
        }

        $hasField = false;

        foreach (['title', 'slug', 'content', 'status', 'topic_id', 'product_id'] as $field) {
            $hasField = $hasField || $this->hasValue($field);
        }

        if (!$hasField) {
            return $this->errorResponse(__('No field is set. Map one or more fields to update.', 'bit-integrations-pro'));
        }

        $doc->set_title(wp_slash($this->hasValue('title') ? $this->getString('title') : (string) $doc->get_title()));
        $doc->set_description(wp_slash($this->hasValue('content') ? $this->getString('content') : (string) $doc->get_description()));

        if ($this->hasValue('slug')) {
            $doc->set_slug($this->getString('slug'));
        }

        if ($this->hasValue('status')) {
            $doc->set_status($this->getString('status'));
        }

        if (!$doc->save()) {
            return $this->errorResponse(__('NiroHelp did not update the doc. Try again.', 'bit-integrations-pro'));
        }

        foreach ($this->docTerms() as $taxonomy => $terms) {
            if (!empty($terms)) {
                $doc->set_terms($taxonomy, $terms);
            }
        }

        return $this->successResponse(__('The doc is updated.', 'bit-integrations-pro'), NiroHelpHelper::getDocData($doc->get_id()));
    }

    public function trashDoc(): array
    {
        $error = $this->validateRequiredFields(['doc_id' => __('Doc ID', 'bit-integrations-pro')]);

        if ($error !== null) {
            return $error;
        }

        $docId = (int) $this->getInteger('doc_id');

        if (!Doc::is_doc($docId)) {
            return $this->docNotFound();
        }

        if (get_post_status($docId) === 'trash') {
            return $this->errorResponse(__('The doc is already in the Trash. Map a different doc ID.', 'bit-integrations-pro'));
        }

        if (!Doc::trash($docId)) {
            return $this->errorResponse(__('NiroHelp did not move the doc to the Trash. Try again.', 'bit-integrations-pro'));
        }

        return $this->successResponse(__('The doc is moved to the Trash.', 'bit-integrations-pro'), NiroHelpHelper::getDocData($docId));
    }

    public function deleteDoc(): array
    {
        $error = $this->validateRequiredFields(['doc_id' => __('Doc ID', 'bit-integrations-pro')]);

        if ($error !== null) {
            return $error;
        }

        $doc = new Doc((int) $this->getInteger('doc_id'));

        if (!$doc->exists()) {
            return $this->docNotFound();
        }

        $docData = NiroHelpHelper::getDocData($doc->get_id());

        if (!$doc->delete()) {
            return $this->errorResponse(__('NiroHelp did not delete the doc. Try again.', 'bit-integrations-pro'));
        }

        return $this->successResponse(__('The doc is deleted.', 'bit-integrations-pro'), $docData);
    }

    private function docNotFound(): array
    {
        // translators: %d: doc ID
        return $this->errorResponse(\sprintf(__('No doc has the ID %d. Map a different doc ID.', 'bit-integrations-pro'), (int) $this->getInteger('doc_id')));
    }

    private function docTerms(): array
    {
        return [
            NiroHelpHelper::TOPIC_TAXONOMY   => $this->hasValue('topic_id') ? [(int) $this->getInteger('topic_id')] : [],
            NiroHelpHelper::PRODUCT_TAXONOMY => $this->hasValue('product_id') ? [(int) $this->getInteger('product_id')] : [],
        ];
    }

    private function checkDocFields(): string
    {
        if ($this->hasValue('status') && !\in_array($this->getString('status'), NiroHelpHelper::DOC_STATUSES, true)) {
            return __('The status is not valid. Select Published, Draft, Pending or Private.', 'bit-integrations-pro');
        }

        if ($this->hasValue('topic_id') && !$this->termExists('topic_id', NiroHelpHelper::TOPIC_TAXONOMY)) {
            return __('The topic does not exist. Select a different topic.', 'bit-integrations-pro');
        }

        if ($this->hasValue('product_id') && !$this->termExists('product_id', NiroHelpHelper::PRODUCT_TAXONOMY)) {
            return __('The product does not exist. Select a different product.', 'bit-integrations-pro');
        }

        return '';
    }
}
