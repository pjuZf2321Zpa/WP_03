<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Actions\UltimateAffiliatePro\UltimateAffiliateProProHelper;
use BitApps\IntegrationsPro\Config;
use BitApps\IntegrationsPro\Core\Util\Hooks;

Hooks::filter(Config::withFreePrefix('ultimateaffiliatepro_create_affiliate'), [UltimateAffiliateProProHelper::class, 'createAffiliate'], 10, 2);
Hooks::filter(Config::withFreePrefix('ultimateaffiliatepro_create_referral'), [UltimateAffiliateProProHelper::class, 'createReferral'], 10, 2);
Hooks::filter(Config::withFreePrefix('ultimateaffiliatepro_insert_payment'), [UltimateAffiliateProProHelper::class, 'insertPayment'], 10, 2);
Hooks::filter(Config::withFreePrefix('ultimateaffiliatepro_change_transaction_status'), [UltimateAffiliateProProHelper::class, 'changeTransactionStatus'], 10, 2);
