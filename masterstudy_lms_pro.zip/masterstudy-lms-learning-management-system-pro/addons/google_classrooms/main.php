<?php

require_once STM_LMS_PRO_ADDONS . '/google_classrooms/admin_ajax.php';
require_once STM_LMS_PRO_ADDONS . '/google_classrooms/auditory.php';
require_once STM_LMS_PRO_ADDONS . '/google_classrooms/module_ajax.php';
require_once STM_LMS_PRO_ADDONS . '/google_classrooms/popup.php';
require_once STM_LMS_PRO_ADDONS . '/google_classrooms/demo.php';
require_once STM_LMS_PRO_ADDONS . '/google_classrooms/Admin/Menus.php';
require_once STM_LMS_PRO_ADDONS . '/google_classrooms/Admin/ReactAdmin.php';

STM_LMS_Google_Classroom::getInstance();
new MSLMS_ClassroomsAdminMenus();
new MSLMS_ClassroomsReactAdmin();


class STM_LMS_Google_Classroom {

	private static $instance                = null;
	public static $course_classroom_name    = 'stm_lms_google_classroom_id';
	private $token_name                     = 'stm_lms_google_classroom_token';
	private static $config_name             = 'stm_lms_google_classroom_config';
	private $is_rendering_settings_fragment = false;
	private $client;
	private $service;
	public $admin_url;

	public function __construct() {
		/*ACTIONS*/
		add_action( 'wpcfto_options_page_setup', array( $this, 'stm_lms_settings_page' ) );

		add_action(
			'wpcfto_settings_screen_stm_lms_google_classrooms_settings_before',
			array( $this, 'render_admin_react_app' )
		);

		add_action(
			'wpcfto_settings_screen_stm_lms_google_classrooms_settings_before',
			array( $this, 'open_settings_root' ),
			20
		);

		add_action(
			'wpcfto_settings_screen_stm_lms_google_classrooms_settings_after',
			array( $this, 'close_settings_root' ),
			1
		);

		add_action(
			'init',
			function () {
				if ( ! current_user_can( 'administrator' ) ) {
					return;
				}

				if ( isset( $_GET['code'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
					$this->get_code();
				}

				if ( isset( $_GET['stm_lms_remove_token'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
					if ( empty( $this->admin_url ) ) {
						$this->admin_url = get_option( $this::$config_name )['web']['redirect_uris'][0];
					}
					$this->revoke_token();
					$this->redirect_to_admin();
				}

				if ( isset( $_GET['stm_lms_delete_credentials'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
					if ( empty( $this->admin_url ) ) {
						$this->admin_url = get_option( $this::$config_name )['web']['redirect_uris'][0];
					}
					$this->revoke_config();
					$this->redirect_to_admin();
				}
			}
		);

		add_action( 'stm_lms_register_custom_fields', array( $this, 'register_select_classroom' ) );

		add_action( 'stm_lms_user_registered', array( $this, 'user_registered' ), 10, 2 );

		add_action( 'vc_after_init', array( $this, 'vc_module' ) );

		add_action( 'wp_ajax_stm_lms_g_c_load_credentials', array( $this, 'load_credentials' ) );

		add_shortcode( 'stm_lms_google_classroom', array( $this, 'add_shortcode' ) );
	}

	public function vc_module() {
		vc_map(
			array(
				'name'          => esc_html__( 'STM Google Classrooms', 'masterstudy' ),
				'base'          => 'stm_lms_google_classroom',
				'icon'          => 'stm_lms_google_classroom',
				'description'   => esc_html__( 'Google Classrooms grid view', 'masterstudy' ),
				'html_template' => STM_LMS_PRO_ADDONS . '/google_classrooms/frontend_view/google_classroom.php',
				'category'      => array(
					esc_html__( 'Content', 'masterstudy' ),
				),
				'params'        => array(
					array(
						'type'       => 'textfield',
						'heading'    => __( 'Title', 'masterstudy' ),
						'param_name' => 'title',
					),
					array(
						'type'       => 'textfield',
						'heading'    => __( 'Number', 'masterstudy' ),
						'param_name' => 'number',
					),
				),
			)
		);
	}

	public static function getInstance() {
		if ( null === self::$instance ) {
			self::$instance = new STM_LMS_Google_Classroom();
		}

		return self::$instance;
	}

	public function setClient() {
		$config       = self::getAuthConfig();
		$this->client = new Google_Client();

		if ( ! empty( $config ) ) {
			$this->client->setAuthConfig( self::getAuthConfig() );
			$this->client->addScope( Google_Service_Classroom::CLASSROOM_COURSES_READONLY );
			$this->client->addScope( Google_Service_Classroom::CLASSROOM_TOPICS_READONLY );
		}
	}

	public static function add_shortcode( $atts ) {
		$atts = shortcode_atts(
			array(
				'title'  => '',
				'number' => '',
			),
			$atts
		);

		return STM_LMS_Templates::load_lms_template( 'shortcodes/google_classroom', $atts );
	}

	public function load_credentials() {
		if ( ! current_user_can( 'manage_options' ) ) {
			die;
		}

		$result = $this->store_credentials_file( $_FILES['file'] ?? array() );

		if ( is_wp_error( $result ) ) {
			wp_send_json( array( 'error' => $result->get_error_message() ) );
		}

		wp_send_json(
			array(
				'success' => esc_html__( 'JSON Loaded, reloading...', 'masterstudy-lms-learning-management-system-pro' ),
			)
		);
	}

	public static function getAuthConfig() {
		return get_option( self::$config_name, array() );
	}

	public function render_admin_react_app() {
		if ( $this->is_rendering_settings_fragment ) {
			return;
		}

		require_once __DIR__ . '/admin_view/google_api_classroom.php';
	}

	public function open_settings_root() {
		if ( $this->is_rendering_settings_fragment ) {
			return;
		}

		?>
		<div id="masterstudy-google-classrooms-settings-root" data-masterstudy-server-rendered="true">
			<div id="masterstudy-google-classrooms-settings-assets"></div>
			<div id="masterstudy-google-classrooms-settings-markup">
				<?php $this->render_settings_fragment_title(); ?>
		<?php
	}

	public function close_settings_root() {
		if ( $this->is_rendering_settings_fragment ) {
			return;
		}

		?>
			</div>
		</div>
		<?php
	}

	public function get_settings_fragment_payload() {
		$result = \MasterStudy\Lms\Utility\TemplateAssetCapture::capture( array( $this, 'render_settings_fragment' ) );

		return array(
			'html'    => $result['html'],
			'data'    => $this->get_settings_fragment_data(),
			'css_url' => $result['css_urls'],
			'js_url'  => $result['js_urls'],
		);
	}

	public function render_settings_fragment() {
		$this->enqueue_settings_fragment_assets();

		$setup                 = $this->get_settings_page_setup();
		$option_name           = $setup['option_name'];
		$fields                = $setup['fields'];
		$page                  = $setup['page'];
		$settings              = get_option( $option_name, array() );
		$metabox               = apply_filters(
			$option_name,
			array(
				'id'   => $option_name,
				'args' => array(
					$option_name => $fields,
				),
			)
		);
		$wpcfto_link           = array();
		$wpcfto_title          = ! empty( $setup['title'] ) ? $setup['title'] : '';
		$wpcfto_sub_title      = ! empty( $setup['sub_title'] ) ? $setup['sub_title'] : '';
		$wpcfto_logo           = ! empty( $setup['logo'] ) ? $setup['logo'] : STM_WPCFTO_URL . '/metaboxes/assets/images/stm-logo.svg';
		$wpcfto_settings_alert = ! empty( $setup['save_settings_alert'] ) ? $setup['save_settings_alert'] : array(
			'position'      => 'top_right',
			'success_alert' => array(
				'title'    => esc_html__( 'Saved!', 'nuxy' ),
				'subtitle' => esc_html__( 'Settings are changed', 'nuxy' ),
			),
			'error_alert'   => array(
				'title'    => esc_html__( 'Oops, something went wrong', 'nuxy' ),
				'subtitle' => esc_html__( 'Settings are not changed', 'nuxy' ),
			),
		);
		$wpcfto_header_menu    = array();

		foreach ( $metabox['args'][ $option_name ] as $section_name => $section ) {
			foreach ( $section['fields'] as $field_name => $field ) {
				$default_value = ! empty( $field['value'] ) ? $field['value'] : '';
				$metabox['args'][ $option_name ][ $section_name ]['fields'][ $field_name ]['value'] = isset( $settings[ $field_name ] )
					? $settings[ $field_name ]
					: $default_value;
			}
		}

		$this->is_rendering_settings_fragment = true;
		$this->render_settings_fragment_title();
		include STM_WPCFTO_PATH . '/settings/view/main.php';
		$this->is_rendering_settings_fragment = false;
	}

	public function render_settings_fragment_title() {
		?>
		<h2><?php esc_html_e( 'Google Classrooms Settings', 'masterstudy-lms-learning-management-system-pro' ); ?></h2>
		<?php
	}

	public function enqueue_settings_fragment_assets() {
		STM_Metaboxes::wpcfto_scripts();

		$assets = STM_WPCFTO_URL . 'metaboxes/assets';

		wp_enqueue_style( 'ctrumbowyg', $assets . '/vendors/trumbowyg/ctrumbowyg.css', array(), STM_WPCFTO_VERSION );
		wp_enqueue_style( 'color-trumbowyg', $assets . '/vendors/trumbowyg/color-trumbowyg.css', array(), STM_WPCFTO_VERSION );
		wp_enqueue_script( 'strumbowyg', $assets . '/vendors/trumbowyg/strumbowyg.js', array( 'jquery' ), STM_WPCFTO_VERSION, true );
		wp_enqueue_script( 'vtrumbowyg', $assets . '/vendors/trumbowyg/vtrumbowyg.js', array( 'jquery' ), STM_WPCFTO_VERSION, true );
		wp_enqueue_script( 'color-trumbowyg', $assets . '/vendors/trumbowyg/color-trumbowyg.js', array( 'jquery' ), STM_WPCFTO_VERSION, true );
	}

	public function get_settings_fragment_data() {
		return array(
			'stm_wpcfto_ajaxurl'     => esc_url_raw( admin_url( 'admin-ajax.php' ) ),
			'stm_wpcfto_nonces'      => $this->get_settings_fragment_nonces(),
			'wpcfto_global_settings' => array(
				'fonts_list'   => WPCFTO_Gfonts::google_fonts(),
				'variants'     => WPCFTO_Gfonts::variants(),
				'subsets'      => WPCFTO_Gfonts::subsets(),
				'align'        => WPCFTO_Gfonts::align(),
				'translations' => STM_Metaboxes::translations(),
				'transform'    => WPCFTO_Gfonts::transform(),
				'nonce'        => wp_create_nonce( 'stm_wpcfto_get_settings_nonce' ),
			),
			'wpcfto_icons_set'       => $this->get_settings_fragment_icons(),
		);
	}

	public function get_settings_fragment_nonces() {
		$nonces = array(
			'wpcfto_save_settings',
			'get_image_url',
			'wpcfto_upload_file',
			'wpcfto_search_posts',
			'wpcfto_regenerate_fonts',
			'wpcfto_create_term',
		);

		$nonces_list = array();

		foreach ( $nonces as $nonce_name ) {
			$nonces_list[ $nonce_name ] = wp_create_nonce( $nonce_name );
		}

		return $nonces_list;
	}

	public function get_settings_fragment_icons() {
		$font_awesome = stm_wpcfto_new_fa_icons();

		array_walk(
			$font_awesome,
			function ( &$icon ) {
				reset( $icon );
				$title = key( $icon );
				$icon  = array(
					'title'       => $title,
					'searchTerms' => array( $icon[ $title ] ),
				);
			}
		);

		return apply_filters( 'wpcfto_icons_set', $font_awesome );
	}

	public function get_settings_page_setup() {
		return array(
			'page'        => array(
				'parent_slug' => 'mslms_classrooms',
				'page_title'  => 'Import Classrooms',
				'menu_title'  => 'Import Classrooms',
				'menu_slug'   => 'google_classrooms',
			),
			'fields'      => $this->stm_lms_settings(),
			'option_name' => 'stm_lms_google_classrooms_settings',
		);
	}

	public function setService() {
		$this->client->setAccessToken( $this->get_auth_token() );
		$this->service = new Google_Service_Classroom( $this->client );
	}

	public function get_code() {
		$this->setClient();
		$this->admin_url = $this->get_admin_page_url();
		$this->save_auth_token( $this->client->fetchAccessTokenWithAuthCode( $_GET['code'] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$this->redirect_to_admin();
	}

	public function redirect_to_admin() {
		wp_safe_redirect( ! empty( $this->admin_url ) ? $this->admin_url : $this->get_admin_page_url() );
		exit;
	}

	public function save_auth_token( $token ) {
		if ( ! isset( $token['error'] ) ) {
			update_option( $this->token_name, $token );
		}
	}

	public function get_auth_token() {
		return get_option( $this->token_name, '' );
	}

	public function revoke_token() {
		delete_option( $this->token_name );
	}

	public function revoke_config() {
		delete_option( self::$config_name );
	}

	public function has_auth_config() {
		return ! empty( self::getAuthConfig() );
	}

	public function has_auth_token() {
		return ! empty( $this->get_auth_token() );
	}

	public function get_admin_page_url() {
		$config = self::getAuthConfig();

		if ( ! empty( $config['web']['redirect_uris'][0] ) ) {
			return esc_url_raw( $config['web']['redirect_uris'][0] );
		}

		return admin_url( 'admin.php?page=google_classrooms' );
	}

	public function store_credentials_file( $file ) {
		if ( empty( $file['name'] ) || empty( $file['tmp_name'] ) ) {
			return new WP_Error(
				'masterstudy_google_classrooms_missing_file',
				esc_html__( 'Credentials file is required.', 'masterstudy-lms-learning-management-system-pro' )
			);
		}

		$path_info = pathinfo( (string) $file['name'] );
		$extension = isset( $path_info['extension'] ) ? strtolower( (string) $path_info['extension'] ) : '';

		if ( 'json' !== $extension ) {
			return new WP_Error(
				'masterstudy_google_classrooms_invalid_extension',
				esc_html__( 'Not a JSON file', 'masterstudy-lms-learning-management-system-pro' )
			);
		}

		$file_content = file_get_contents( $file['tmp_name'] ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		$file_content = json_decode( $file_content, true );

		if ( empty( $file_content['web'] ) ) {
			return new WP_Error(
				'masterstudy_google_classrooms_invalid_payload',
				esc_html__( 'Wrong JSON file', 'masterstudy-lms-learning-management-system-pro' )
			);
		}

		if ( empty( $file_content['web']['client_id'] ) ||
			empty( $file_content['web']['project_id'] ) ||
			empty( $file_content['web']['auth_uri'] ) ||
			empty( $file_content['web']['token_uri'] ) ||
			empty( $file_content['web']['client_secret'] ) ||
			empty( $file_content['web']['auth_provider_x509_cert_url'] ) ) {
			return new WP_Error(
				'masterstudy_google_classrooms_invalid_config',
				esc_html__( 'Wrong JSON file', 'masterstudy-lms-learning-management-system-pro' )
			);
		}

		update_option( self::$config_name, $file_content );

		$this->admin_url = $this->get_admin_page_url();

		return $file_content;
	}

	public function get_auth_url() {
		$this->setClient();

		return $this->client->createAuthUrl();
	}

	public function courses() {
		$data           = $this->get_raw_courses();
		$imported_posts = $this->get_posts_by_google_ids(
			array_map(
				static function ( array $course ): int {
					return (int) ( $course['course_id'] ?? 0 );
				},
				$data['courses'] ?? array()
			)
		);

		foreach ( $data['courses'] as &$course_data ) {
			$lms_course_id = (int) ( $imported_posts[ (int) $course_data['course_id'] ] ?? 0 );

			if ( empty( $lms_course_id ) ) {
				continue;
			}

			$course_data['action_links'] = array(
				'status'          => get_post_status( $lms_course_id ),
				'course_url'      => get_permalink( $lms_course_id ),
				'course_url_edit' => get_edit_post_link( $lms_course_id, 'normal' ),
			);
		}
		unset( $course_data );

		return $data;
	}

	public function get_raw_courses() {
		$token = $this->get_auth_token();

		$this->setClient();
		$this->setService();

		$options = array(
			'pageSize' => 100,
		);

		$data = array( 'courses' => array() );

		if ( empty( $token ) ) {
			return $data;
		}

		try {
			$results = $this->service->courses->listCourses( $options );

			if ( count( $results->getCourses() ) ) {
				foreach ( $results->getCourses() as $item ) {
					$course_id   = (int) $item->id;
					$course_data = array(
						'course_id'          => $item->id,
						'name'               => $item->name,
						'section'            => $item->section,
						'descriptionHeading' => $item->descriptionHeading,
						'description'        => $item->description,
						'auditory'           => $item->room,
						'ownerId'            => $item->ownerId,
						'creationTime'       => $item->creationTime,
						'updateTime'         => $item->updateTime,
						'code'               => $item->enrollmentCode,
						'alternateLink'      => $item->alternateLink,
						'courseState'        => $item->courseState,
						'teacherGroupEmail'  => $item->teacherGroupEmail,
						'courseGroupEmail'   => $item->courseGroupEmail,
						'calendarId'         => $item->calendarId,
						'courseMaterialSets' => $item->courseMaterialSets,
						'teacherFolder'      => $item->teacherFolder,
					);

					set_transient( "stm_lms_google_classroom_course_{$course_id}", $course_data );
					$data['courses'][] = $course_data;
				}
			}
		} catch ( Exception $e ) {
			$this->revoke_token();
			$data['error'] = $e->getMessage();
		}

		return $data;
	}

	/*Settings*/
	public function stm_lms_settings_page( $setups ) {
		$setups[] = $this->get_settings_page_setup();

		return $setups;
	}

	public function stm_lms_settings() {
		return apply_filters(
			'stm_lms_google_classrooms_settings',
			array(
				'credentials' => array(
					'name'   => esc_html__( 'Credentials', 'masterstudy-lms-learning-management-system-pro' ),
					'fields' => array(
						'locked'       => array(
							'type'        => 'checkbox',
							'label'       => esc_html__( 'Only signed-in students will see the code', 'masterstudy-lms-learning-management-system-pro' ),
							'description' => esc_html__( 'Enable this option so that only students who are signed in will see the Google Classroom code', 'masterstudy-lms-learning-management-system-pro' ),
							'value'       => false,
						),
						'enable_popup' => array(
							'type'        => 'checkbox',
							'label'       => esc_html__( 'Enable popup', 'masterstudy-lms-learning-management-system-pro' ),
							'description' => esc_html__( 'Activate this setting to display a popup for Google Classroom', 'masterstudy-lms-learning-management-system-pro' ),
						),
						'popup_title'  => array(
							'type'        => 'text',
							'label'       => esc_html__( 'Popup Title', 'masterstudy-lms-learning-management-system-pro' ),
							'description' => esc_html__( 'Set the title of the popup', 'masterstudy-lms-learning-management-system-pro' ),
							'dependency'  => array(
								'key'   => 'enable_popup',
								'value' => 'not_empty',
							),
						),
						'popup_editor' => array(
							'type'        => 'editor',
							'label'       => esc_html__( 'Popup Editor', 'masterstudy-lms-learning-management-system-pro' ),
							'description' => esc_html__( 'Provide content for the popup using the popup editor', 'masterstudy-lms-learning-management-system-pro' ),
							'dependency'  => array(
								'key'   => 'enable_popup',
								'value' => 'not_empty',
							),
						),
						'popup_image'  => array(
							'type'        => 'image',
							'label'       => esc_html__( 'Popup Image', 'masterstudy-lms-learning-management-system-pro' ),
							'description' => esc_html__( 'Add an image to the popup', 'masterstudy-lms-learning-management-system-pro' ),
							'dependency'  => array(
								'key'   => 'enable_popup',
								'value' => 'not_empty',
							),
						),
						'popup_link'   => array(
							'type'        => 'text',
							'label'       => esc_html__( 'Google Classrooms page', 'masterstudy-lms-learning-management-system-pro' ),
							'description' => esc_html__( 'Put the page URL with Google classrooms', 'masterstudy-lms-learning-management-system-pro' ),
							'dependency'  => array(
								'key'   => 'enable_popup',
								'value' => 'not_empty',
							),
						),
					),
				),
			)
		);
	}

	public static function stm_lms_get_settings() {
		return get_option( 'stm_lms_google_classrooms_settings', array() );
	}

	public static function imported_course_id( $course ) {

		$course_id = '';

		$args = array(
			'post_type'      => 'stm-g-classrooms',
			'posts_per_page' => 1,
			'meta_query'     => array(
				array(
					'key'     => self::$course_classroom_name,
					'value'   => $course['course_id'],
					'compare' => '=',
				),
			),
		);

		$q = new WP_Query( $args );

		if ( $q->have_posts() ) {
			while ( $q->have_posts() ) {
				$q->the_post();

				$course_id = get_the_ID();
			}
		}

		$post_content = ! empty( $course['description'] ) ? $course['description'] : '';

		if ( empty( $post_content ) && ! empty( $course['descriptionHeading'] ) ) {
			$post_content = $course['descriptionHeading'];
		}

		$course_data = array(
			'post_title'        => $course['name'],
			'post_date'         => $course['creationTime'],
			'post_date_gmt'     => $course['creationTime'],
			'post_content'      => $post_content,
			'post_status'       => 'draft',
			'post_type'         => 'stm-g-classrooms',
			'post_modified'     => $course['updateTime'],
			'post_modified_gmt' => $course['updateTime'],
		);

		if ( ! empty( $course_id ) ) {
			$course_data['ID'] = $course_id;
		}

		$course_id = wp_insert_post( $course_data );

		update_post_meta( $course_id, self::$course_classroom_name, $course['course_id'] );

		return $course_id;
	}

	public function get_post_by_google_id( $google_id ) {
		$google_id = absint( $google_id );

		if ( empty( $google_id ) ) {
			return null;
		}

		$posts = $this->get_posts_by_google_ids( array( $google_id ) );

		return $posts[ $google_id ] ?? null;
	}

	public function get_posts_by_google_ids( array $google_ids ) {
		global $wpdb;

		$google_ids = array_values( array_unique( array_filter( array_map( 'absint', $google_ids ) ) ) );

		if ( empty( $google_ids ) ) {
			return array();
		}

		$placeholders = implode( ', ', array_fill( 0, count( $google_ids ), '%d' ) );
		$query        = $wpdb->prepare(
        // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			"SELECT post_id, meta_value FROM {$wpdb->postmeta} WHERE meta_key = %s AND meta_value IN ({$placeholders})",
			array_merge( array( self::$course_classroom_name ), $google_ids )
		);

        // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
		$results = $wpdb->get_results( $query, ARRAY_A );
		$posts   = array();

		foreach ( $results as $result ) {
			$posts[ (int) $result['meta_value'] ] = (int) $result['post_id'];
		}

		return $posts;
	}

	public function register_select_classroom() {
		$auditories = STM_LMS_Helpers::get_posts( 'stm-auditory' );
		STM_LMS_Templates::show_lms_template( 'account/parts/select_google_classroom_auditory', compact( 'auditories' ) );
	}

	public function user_registered( $user_id, $data ) {
		if ( ! empty( $data['auditory'] ) ) {
			update_user_meta( $user_id, 'google_classroom_auditory', intval( $data['auditory'] ) );
		}
	}
}

if ( class_exists( 'WPBakeryShortCode' ) ) {
	// phpcs:ignore Generic.Files.OneObjectStructurePerFile.MultipleFound
	class WPBakeryShortCode_Stm_Lms_Google_Classroom extends WPBakeryShortCode {
	}
}
