<?php

namespace FluentCartPro\App\Modules\MultiCurrency\Http\Requests;

use FluentCart\Framework\Foundation\RequestGuard;

class MultiCurrencySettingsRequest extends RequestGuard
{
    public function rules()
    {
        return [
            'enabled'                 => 'required|in:yes,no',
            'currencies'              => ['nullable', function ($_, $value) {
                if ($value !== null && !\is_array($value)) {
                    return esc_html__('Currencies must be a list.', 'fluent-cart-pro');
                }
                if (\is_array($value) && \count($value) > 50) {
                    return esc_html__('Up to 50 currencies can be enabled.', 'fluent-cart-pro');
                }
            }],
            'currencies.*.code'       => 'required|sanitizeText|maxLength:10',
            'currencies.*.rounding'   => 'nullable|sanitizeText|maxLength:50',
            'currencies.*.charm'      => 'nullable|sanitizeText|maxLength:50',
            'currencies.*.adjustment' => 'nullable|numeric|min:-50|max:100',
            'rate_lock_minutes'       => 'nullable|numeric|min:0|max:1440',
            'rate_provider'           => 'nullable|sanitizeText|maxLength:50',
            'rate_margin'             => 'nullable|numeric|min:0|max:10',
        ];
    }

    public function messages()
    {
        return [
            'enabled.required'            => esc_html__('Choose whether multi-currency is enabled.', 'fluent-cart-pro'),
            'currencies.*.code.required'  => esc_html__('Each currency needs a currency code.', 'fluent-cart-pro'),
            'currencies.*.adjustment.min' => esc_html__('A price adjustment must be between -50 and 100 percent.', 'fluent-cart-pro'),
            'currencies.*.adjustment.max' => esc_html__('A price adjustment must be between -50 and 100 percent.', 'fluent-cart-pro'),
            'rate_lock_minutes.min'       => esc_html__('The rate lock cannot be negative.', 'fluent-cart-pro'),
            'rate_lock_minutes.max'       => esc_html__('The rate lock can be at most 1440 minutes.', 'fluent-cart-pro'),
        ];
    }

    public function sanitize()
    {
        return [
            'enabled'                 => 'sanitize_text_field',
            'currencies.*.code'       => 'sanitize_text_field',
            'currencies.*.rounding'   => 'sanitize_key',
            'currencies.*.charm'      => 'sanitize_key',
            'currencies.*.adjustment' => 'floatval',
            'rate_lock_minutes'       => 'intval',
            'rate_provider'           => 'sanitize_key',
            'rate_margin'             => 'floatval',
        ];
    }
}
