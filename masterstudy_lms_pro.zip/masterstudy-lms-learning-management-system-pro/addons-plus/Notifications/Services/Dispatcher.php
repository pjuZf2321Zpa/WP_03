<?php

namespace MasterStudy\Lms\Pro\AddonsPlus\Notifications\Services;

use MasterStudy\Lms\Pro\AddonsPlus\Notifications\Events;
use MasterStudy\Lms\Pro\AddonsPlus\Notifications\Repositories\DispatchQueueRepository;
use MasterStudy\Lms\Pro\AddonsPlus\Notifications\Repositories\NotificationRepository;
use MasterStudy\Lms\Pro\AddonsPlus\Notifications\Repositories\PushQueueRepository;

final class Dispatcher {
	private const INLINE_RECIPIENT_LIMIT = 50;
	private const FANOUT_BATCH_SIZE      = 100;

	private NotificationRepository $notifications;
	private PushQueueRepository $push_queue;
	private DispatchQueueRepository $dispatch_queue;
	private MessageRenderer $renderer;
	private UrlResolver $url_resolver;

	public function __construct() {
		$this->notifications  = new NotificationRepository();
		$this->push_queue     = new PushQueueRepository();
		$this->dispatch_queue = new DispatchQueueRepository();
		$this->renderer       = new MessageRenderer();
		$this->url_resolver   = new UrlResolver();
	}

	public function dispatch( string $trigger_key, array $recipient_ids, array $context = array(), string $dedupe_key = '' ): int {
		$recipient_ids = $this->sanitize_recipient_ids( $recipient_ids );
		$recipient_ids = apply_filters( 'masterstudy_notifications_dispatch_recipients', $recipient_ids, $trigger_key, $context );
		$recipient_ids = $this->filter_recipients_by_trigger( $recipient_ids, $trigger_key, $context );

		if ( empty( $recipient_ids ) ) {
			return 0;
		}

		$prepared = $this->prepare_dispatch( $trigger_key, $context, $dedupe_key );

		if ( empty( $prepared ) ) {
			return 0;
		}

		$this->fanout_or_queue(
			$prepared['notification_id'],
			$recipient_ids,
			$prepared['channels'],
			$trigger_key,
			$context
		);

		return $prepared['notification_id'];
	}

	public function dispatch_to_course_students( string $trigger_key, int $course_id, array $context = array(), string $dedupe_key = '' ): int {
		if ( $course_id <= 0 ) {
			return 0;
		}

		$context['course_id'] = absint( $context['course_id'] ?? $course_id );
		$prepared             = $this->prepare_dispatch( $trigger_key, $context, $dedupe_key );

		if ( empty( $prepared ) ) {
			return 0;
		}

		$this->dispatch_queue->enqueue_target(
			$prepared['notification_id'],
			'course_students',
			$course_id,
			$prepared['channels'],
			$context,
			self::FANOUT_BATCH_SIZE
		);
		$this->schedule_recipient_fanout();

		return $prepared['notification_id'];
	}

	public function dispatch_to_course_students_and_users( string $trigger_key, int $course_id, array $recipient_ids, array $context = array(), string $dedupe_key = '' ): int {
		if ( $course_id <= 0 ) {
			return 0;
		}

		$context['course_id'] = absint( $context['course_id'] ?? $course_id );
		$prepared             = $this->prepare_dispatch( $trigger_key, $context, $dedupe_key );

		if ( empty( $prepared ) ) {
			return 0;
		}

		$this->dispatch_queue->enqueue_target(
			$prepared['notification_id'],
			'course_students',
			$course_id,
			$prepared['channels'],
			$context,
			self::FANOUT_BATCH_SIZE
		);

		$recipient_ids = $this->sanitize_recipient_ids( $recipient_ids );
		$recipient_ids = apply_filters( 'masterstudy_notifications_dispatch_recipients', $recipient_ids, $trigger_key, $context );
		$recipient_ids = $this->filter_recipients_by_trigger( $recipient_ids, $trigger_key, $context );

		if ( ! empty( $recipient_ids ) ) {
			$this->fanout_or_queue(
				$prepared['notification_id'],
				$recipient_ids,
				$prepared['channels'],
				$trigger_key,
				$context
			);
		}

		$this->schedule_recipient_fanout();

		return $prepared['notification_id'];
	}

	public function is_channel_enabled( string $trigger_key, string $channel ): bool {
		if ( ! $this->is_trigger_available( $trigger_key ) ) {
			return false;
		}

		$settings = get_option( 'stm_lms_settings', array() );
		$triggers = is_array( $settings ) && isset( $settings[ Events::SETTINGS_KEY ] ) && is_array( $settings[ Events::SETTINGS_KEY ] )
			? $settings[ Events::SETTINGS_KEY ]
			: array();

		if ( empty( $triggers[ $trigger_key ] ) || ! is_array( $triggers[ $trigger_key ] ) ) {
			return false;
		}

		return function_exists( 'masterstudy_lms_notifications_is_enabled_value' )
			&& masterstudy_lms_notifications_is_enabled_value( $triggers[ $trigger_key ][ $channel ] ?? false );
	}

	private function prepare_dispatch( string $trigger_key, array $context, string $dedupe_key ): ?array {
		if ( ! $this->is_available() ) {
			return null;
		}

		$event = Events::find( $trigger_key );

		if ( empty( $event ) ) {
			return null;
		}

		if ( ! $this->is_trigger_available( $trigger_key ) ) {
			return null;
		}

		$on_site_enabled = $this->is_channel_enabled( $trigger_key, Events::CHANNEL_ON_SITE );
		$push_enabled    = $this->is_channel_enabled( $trigger_key, Events::CHANNEL_PUSH );
		$on_site_enabled = (bool) apply_filters( 'masterstudy_notifications_should_dispatch_channel', $on_site_enabled, Events::CHANNEL_ON_SITE, $trigger_key, $context );
		$push_enabled    = (bool) apply_filters( 'masterstudy_notifications_should_dispatch_channel', $push_enabled, Events::CHANNEL_PUSH, $trigger_key, $context );

		if ( ! $on_site_enabled && ! $push_enabled ) {
			return null;
		}

		$message   = $this->renderer->render( $event, $context );
		$click_url = $this->url_resolver->resolve( (string) $event['click_action'], $context );
		$payload   = apply_filters(
			'masterstudy_notifications_payload',
			array(
				'trigger_key'        => $trigger_key,
				'title'              => $message['title'],
				'message'            => $message['message'],
				'context_label'      => sanitize_text_field( $context['context_label'] ?? $context['course_name'] ?? '' ),
				'course_id'          => absint( $context['course_id'] ?? 0 ),
				'item_id'            => absint( $context['item_id'] ?? 0 ),
				'assignment_id'      => absint( $context['assignment_id'] ?? 0 ),
				'user_assignment_id' => absint( $context['user_assignment_id'] ?? 0 ),
				'actor_user_id'      => absint( $context['actor_user_id'] ?? 0 ),
				'click_action'       => (string) $event['click_action'],
				'click_url'          => $click_url,
				'dedupe_key'         => $dedupe_key,
				'metadata'           => $context,
			),
			$event,
			$context
		);

		$notification_id = $this->notifications->create( $payload );

		if ( $notification_id <= 0 ) {
			return null;
		}

		return array(
			'notification_id' => $notification_id,
			'channels'        => $this->enabled_channels( $on_site_enabled, $push_enabled ),
		);
	}

	private function fanout_or_queue( int $notification_id, array $recipient_ids, array $channels, string $trigger_key, array $context ): void {
		$recipient_ids = $this->sanitize_recipient_ids( $recipient_ids );

		if ( empty( $recipient_ids ) ) {
			return;
		}

		if ( count( $recipient_ids ) > self::INLINE_RECIPIENT_LIMIT ) {
			$this->dispatch_queue->enqueue_recipients( $notification_id, $recipient_ids, $channels, $context, self::FANOUT_BATCH_SIZE );
			$this->schedule_recipient_fanout();
			return;
		}

		if ( in_array( Events::CHANNEL_ON_SITE, $channels, true ) ) {
			$this->notifications->add_recipients( $notification_id, $recipient_ids );
		}

		if ( in_array( Events::CHANNEL_PUSH, $channels, true ) ) {
			$this->push_queue->enqueue( $notification_id, $recipient_ids );
			$this->schedule_push_queue();
		}
	}

	private function sanitize_recipient_ids( array $recipient_ids ): array {
		return array_values( array_unique( array_filter( array_map( 'absint', $recipient_ids ) ) ) );
	}

	private function filter_recipients_by_trigger( array $recipient_ids, string $trigger_key, array $context ): array {
		$recipient_ids = $this->sanitize_recipient_ids( $recipient_ids );

		if ( 'new_assignment_submission' !== $trigger_key || empty( $recipient_ids ) ) {
			return $recipient_ids;
		}

		$resolver      = new RecipientResolver();
		$course_id     = absint( $context['course_id'] ?? 0 );
		$assignment_id = absint( $context['assignment_id'] ?? $context['item_id'] ?? 0 );

		return array_values(
			array_filter(
				$recipient_ids,
				static function ( int $recipient_id ) use ( $resolver, $course_id, $assignment_id ): bool {
					return $resolver->can_review_assignment_submission( $recipient_id, $course_id, $assignment_id );
				}
			)
		);
	}

	private function enabled_channels( bool $on_site_enabled, bool $push_enabled ): array {
		$channels = array();

		if ( $on_site_enabled ) {
			$channels[] = Events::CHANNEL_ON_SITE;
		}

		if ( $push_enabled ) {
			$channels[] = Events::CHANNEL_PUSH;
		}

		return $channels;
	}

	private function is_available(): bool {
		return function_exists( 'masterstudy_lms_is_notifications_addon_available' )
			&& masterstudy_lms_is_notifications_addon_available();
	}

	private function is_trigger_available( string $trigger_key ): bool {
		if ( function_exists( 'masterstudy_lms_notifications_is_trigger_available' ) ) {
			return masterstudy_lms_notifications_is_trigger_available( $trigger_key );
		}

		return $this->is_available();
	}

	private function schedule_push_queue(): void {
		if ( ! wp_next_scheduled( 'masterstudy_notifications_process_push_queue' ) ) {
			wp_schedule_single_event( time() + 10, 'masterstudy_notifications_process_push_queue' );
		}
	}

	private function schedule_recipient_fanout(): void {
		if ( ! wp_next_scheduled( 'masterstudy_notifications_process_recipient_fanout' ) ) {
			wp_schedule_single_event( time() + 10, 'masterstudy_notifications_process_recipient_fanout' );
		}
	}
}
