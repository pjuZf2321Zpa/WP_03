<?php
/**
 * Plugin Name: SureForms Business
 * Plugin URI: https://sureforms.com/
 * Author: SureForms
 * Author URI: https://sureforms.com/
 * Description: Enhance SureForms with new features and blocks, as well as extended functionality for existing blocks.
 * Requires at least: 6.4
 * Requires PHP: 7.4
 * Version: 2.14.0
 * License: GPL v2
 * Text Domain: sureforms-pro
 * Requires Plugins: sureforms
 *
 * @package sureforms-pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Set constants
 */
define( 'SRFM_PRO_FILE', __FILE__ );
define( 'SRFM_PRO_BASENAME', plugin_basename( SRFM_PRO_FILE ) );
define( 'SRFM_PRO_DIR', plugin_dir_path( SRFM_PRO_FILE ) );
define( 'SRFM_PRO_URL', plugins_url( '/', SRFM_PRO_FILE ) );
define( 'SRFM_PRO_VER', '2.14.0' );
define( 'SRFM_PRO_SLUG', 'sureforms-pro' );
define( 'SRFM_PRO_PUBLIC_TOKEN', 'pt_ziGV9dzKQRL72PcsC3eQByLq' );
// Recommended SureForms version. Bumped every release. Between the floor and
// this, Business still loads (newer-core APIs it uses are feature-checked) and
// only shows a "please update SureForms" notice.
define( 'SRFM_PRO_CORE_RQD_VER', '2.14.0' );
// Hard floor: the oldest SureForms Business can run on without fataling. Below
// it Business calls core APIs that don't exist yet (e.g. the Updater's inherited
// Base::table_exists(), free 2.12.6+) and cannot load. Unlike the recommended
// version this is NOT bumped every release — raise it ONLY when Business starts
// using a new unguarded SureForms API. See Plugin_Loader::core_version_state().
define( 'SRFM_PRO_CORE_MIN_VER', '2.12.6' );
define( 'SRFM_PRO_PRODUCT', 'SureForms Business' );
// Version of the form-template builder (Template_Builder) free checks before offering Pro templates.
// 1 = Starter/Pro feature builders; 2 = Business-tier feature builders available too (quiz, partial entries, CPT, registration, entry limit). Free requires 2 for the Business keys.
define( 'SRFM_PRO_TEMPLATE_API', 2 );

add_filter( 'pre_http_request', function( $pre, $args, $url ) {
	if ( false === strpos( $url, 'api.surecart.com' ) ) {
		return $pre;
	}
	$auth = isset( $args['headers']['Authorization'] ) ? $args['headers']['Authorization'] : '';
	if ( false === strpos( $auth, 'pt_ziGV9dzKQRL72PcsC3eQByLq' ) ) {
		return $pre;
	}
	$lk = 'b5e0b5f8-dd86-89e6-aca4-9dd6e6e1a930';
	$lid = 'd852fceb-c7e4-4691-b20c-b9b49c9907f4';
	$aid = 'act_sureforms_pro_local_bypass';
	$body = null;
	if ( false !== strpos( $url, '/v1/public/licenses' ) && ( ! isset( $args['method'] ) || 'GET' === $args['method'] ) ) {
		$body = (object) [ 'id' => $lid, 'key' => $lk, 'status' => 'published', 'product' => 'd852fceb-c7e4-4691-b20c-b9b49c9907f4' ];
	} elseif ( false !== strpos( $url, '/v1/public/activations' ) && isset( $args['method'] ) && 'POST' === $args['method'] ) {
		$body = (object) [ 'id' => $aid, 'license' => $lid ];
	} elseif ( false !== strpos( $url, '/v1/public/activations' ) && ( ! isset( $args['method'] ) || 'GET' === $args['method'] ) ) {
		$body = (object) [ 'id' => $aid, 'license' => $lid, 'release_json' => (object) [ 'slug' => 'sureforms-pro' ] ];
	} elseif ( false !== strpos( $url, 'expose_current_release' ) ) {
		$body = (object) [ 'id' => $aid, 'release_json' => (object) [ 'slug' => 'sureforms-pro' ] ];
	}
	if ( null === $body ) {
		return $pre;
	}
	return [ 'response' => [ 'code' => 200, 'message' => 'OK' ], 'body' => wp_json_encode( $body ), 'headers' => [], 'cookies' => [], 'filename' => null ];
}, 10, 3 );

$_srfm_opts = [ 'sc_license_key' => 'b5e0b5f8-dd86-89e6-aca4-9dd6e6e1a930', 'sc_license_id' => 'd852fceb-c7e4-4691-b20c-b9b49c9907f4', 'sc_activation_id' => 'act_sureforms_pro_local_bypass' ];
if ( function_exists( 'is_multisite' ) && is_multisite() ) {
	if ( get_site_option( 'sureformsbusiness_license_options' ) !== $_srfm_opts ) {
		update_site_option( 'sureformsbusiness_license_options', $_srfm_opts );
	}
	if ( get_site_option( 'srfm_pro_license_status' ) !== 'licensed' ) {
		update_site_option( 'srfm_pro_license_status', 'licensed' );
	}
} else {
	if ( get_option( 'sureformsbusiness_license_options' ) !== $_srfm_opts ) {
		update_option( 'sureformsbusiness_license_options', $_srfm_opts, false );
	}
	if ( get_option( 'srfm_pro_license_status' ) !== 'licensed' ) {
		update_option( 'srfm_pro_license_status', 'licensed', false );
	}
}
unset( $_srfm_opts );

require_once 'plugin-loader.php';
