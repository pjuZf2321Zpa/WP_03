<?php

namespace FluentCartPro\App\Hooks\Handlers\BlockEditors\PdfBlocks;

use FluentCart\App\Hooks\Handlers\BlockEditors\BlockEditor;

class ReceiptPaymentSummaryBlockEditor extends BlockEditor
{
    use \FluentCartPro\App\Contracts\CanEnqueue;

    protected static string $editorName = 'receipt-payment-summary';

    public function getScripts(): array
    {
        return [
            [
                'source'       => 'admin/BlockEditor/PdfBlocks/ReceiptPaymentSummaryBlockEditor.jsx',
                'dependencies' => ['wp-blocks', 'wp-components', 'wp-block-editor']
            ]
        ];
    }

    public function getStyles(): array
    {
        return [];
    }

    public function localizeData(): array
    {
        return [
            $this->getLocalizationKey() => [
                'slug'        => $this->slugPrefix,
                'name'        => static::getEditorName(),
                'title'       => __('Receipt Payment Summary', 'fluent-cart-pro'),
                'description' => __('Payment summary (subtotal, tax, shipping, total) for PDF receipts.', 'fluent-cart-pro'),
            ],
            'fluent_cart_block_translation' => \FluentCart\App\Services\Translations\TransStrings::blockStrings(),
        ];
    }

    public function blockAttributes(): array
    {
        return [
            'labelColor'    => ['type' => 'string', 'default' => '#525866'],
            'valueColor'    => ['type' => 'string', 'default' => '#0E121B'],
            'totalColor'    => ['type' => 'string', 'default' => '#0E121B'],
            'fontSize'      => ['type' => 'number', 'default' => 11],
            'totalFontSize' => ['type' => 'number', 'default' => 13],
            'totalLabel'    => ['type' => 'string', 'default' => 'Total'],
            'totalValue'    => ['type' => 'string', 'default' => '{{order.total_amount_formatted}}'],
            'rows'          => [
                'type'    => 'array',
                'default' => [
                    ['label' => 'Subtotal', 'value' => '{{order.subtotal_formatted}}'],
                    ['label' => 'Discount', 'value' => '{{order.discount_total_formatted}}'],
                    ['label' => 'Tax',      'value' => '{{order.tax_total_formatted}}'],
                    ['label' => 'Shipping', 'value' => '{{order.shipping_total_formatted}}'],
                ],
                'items'   => ['type' => 'object'],
            ],
        ];
    }

    public function supports(): array
    {
        return [
            'html'    => false,
            'align'   => false,
            'spacing' => ['margin' => true, 'padding' => true],
        ];
    }

    public function render(array $attrs, $block = null, $content = ''): string
    {
        $labelColor    = esc_attr($attrs['labelColor'] ?? '#525866');
        $valueColor    = esc_attr($attrs['valueColor'] ?? '#0E121B');
        $totalColor    = esc_attr($attrs['totalColor'] ?? '#0E121B');
        $fontSize      = (int)($attrs['fontSize'] ?? 11);
        $totalFontSize = (int)($attrs['totalFontSize'] ?? 13);
        $totalLabel    = esc_html($attrs['totalLabel'] ?? 'Total');
        $totalValue    = $attrs['totalValue'] ?? '{{order.total_amount_formatted}}';

        $rows = $attrs['rows'] ?? [
            ['label' => 'Subtotal', 'value' => '{{order.subtotal_formatted}}'],
            ['label' => 'Discount', 'value' => '{{order.discount_total_formatted}}'],
            ['label' => 'Fees',     'value' => '{{order.fee_lines}}'],
            ['label' => 'Tax',      'value' => '{{order.tax_breakdown}}'],
            ['label' => 'Shipping', 'value' => '{{order.shipping_total_formatted}}'],
        ];

        // Tax breakdown: both old saved templates using {{order.tax_total_formatted}}
        // and new ones using {{order.tax_breakdown}} are normalised to {{order.tax_breakdown}},
        // which OrderParser resolves to per-rate <tr> rows (with shipping tax when present).
        // Fee lines: {{order.fee_lines}} resolves to per-fee <tr> rows.
        $taxSmartcodes     = ['{{order.tax_breakdown}}', '{{order.tax_total_formatted}}'];
        $feeSmartcodes     = ['{{order.fee_lines}}'];

        $rowStyle   = "padding:5px 0;font-size:{$fontSize}px;";
        $totalStyle = "padding:10px 0 4px;font-size:{$totalFontSize}px;font-weight:bold;";

        $html = '<table width="100%" cellspacing="0" cellpadding="0" border="0"'
              . ' style="margin-top:16px;border-collapse:collapse;">';
        foreach ($rows as $row) {
            $value = $row['value'] ?? '';

            // Tax rows: replace with dynamic breakdown smartcode (generates own <tr> elements)
            if (in_array(trim($value), $taxSmartcodes)) {
                $html .= '{{order.tax_breakdown}}';
                continue;
            }

            // Fee rows: replace with dynamic fee-lines smartcode (generates own <tr> elements)
            if (in_array(trim($value), $feeSmartcodes)) {
                $html .= '{{order.fee_lines}}';
                continue;
            }

            $label = esc_html($row['label'] ?? '');
            $html .= '<tr>'
                   . '<td style="' . $rowStyle . 'color:' . $labelColor . ';">' . $label . '</td>'
                   . '<td style="' . $rowStyle . 'color:' . $valueColor . ';text-align:right;">' . $value . '</td>'
                   . '</tr>';
        }
        $html .= '<tr style="border-top:1px solid #DDDDDD;">'
               . '<td style="' . $totalStyle . 'color:' . $totalColor . ';">' . $totalLabel . '</td>'
               . '<td style="' . $totalStyle . 'color:' . $totalColor . ';text-align:right;">' . $totalValue . '</td>'
               . '</tr>'
               . '</table>';

        return $html;
    }
}
