<?php
/**
 * RSVP V2 IAC options for the attendee registration page (block editor).
 *
 * Rendered above the ARF field builder on the attendee-registration admin page.
 * The block editor loads that page in a same-origin iframe so the existing ARF
 * builder can be reused without re-implementing it as a React component.
 *
 * @since 6.11.0
 *
 * @version 6.11.0
 *
 * @var Tribe__Tickets_Plus__Admin__Views $this        [Global] Template object.
 * @var int                               $ticket_id   The ticket ID.
 * @var int                               $post_id     The post ID.
 * @var array                             $iac_options Available IAC options keyed by value.
 * @var string                            $selected    Currently selected IAC option for the ticket.
 */

defined( 'ABSPATH' ) || exit;
?>
<div class="tec-tickets-rsvp-iac-attendee-registration">
	<p class="tribe-intro">
		<?php esc_html_e( 'Select the default way to collect RSVPs. Enabling Individual Attendee Collection will allow respondents to enter a name and email for each RSVP.', 'event-tickets-plus' ); ?>
	</p>
	<div class="tec-tickets-rsvp-iac-options">
		<?php foreach ( $iac_options as $value => $label ) : ?>
			<div class="input_block">
				<input
					type="radio"
					name="ticket_iac"
					id="ticket_iac_setting_<?php echo esc_attr( sanitize_title_with_dashes( $value ) ); ?>"
					value="<?php echo esc_attr( $value ); ?>"
					<?php checked( $value, $selected ); ?>
				/>
				<label for="ticket_iac_setting_<?php echo esc_attr( sanitize_title_with_dashes( $value ) ); ?>">
					<?php echo esc_html( $label ); ?>
				</label>
			</div>
		<?php endforeach; ?>
	</div>
	<hr />
</div>
