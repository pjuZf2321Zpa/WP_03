<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Actions\TheEventsCalendar\TheEventsCalendarProHelper;
use BitApps\IntegrationsPro\Config;
use BitApps\IntegrationsPro\Core\Util\Hooks;

Hooks::filter(Config::withFreePrefix('the_events_calendar_create_event'), [TheEventsCalendarProHelper::class, 'createEvent'], 10, 3);
Hooks::filter(Config::withFreePrefix('the_events_calendar_update_event'), [TheEventsCalendarProHelper::class, 'updateEvent'], 10, 3);
Hooks::filter(Config::withFreePrefix('the_events_calendar_delete_event'), [TheEventsCalendarProHelper::class, 'deleteEvent'], 10, 3);
Hooks::filter(Config::withFreePrefix('the_events_calendar_update_event_status'), [TheEventsCalendarProHelper::class, 'updateEventStatus'], 10, 3);
Hooks::filter(Config::withFreePrefix('the_events_calendar_duplicate_event'), [TheEventsCalendarProHelper::class, 'duplicateEvent'], 10, 3);
Hooks::filter(Config::withFreePrefix('the_events_calendar_create_recurring_event'), [TheEventsCalendarProHelper::class, 'createRecurringEvent'], 10, 3);
Hooks::filter(Config::withFreePrefix('the_events_calendar_create_venue'), [TheEventsCalendarProHelper::class, 'createVenue'], 10, 3);
Hooks::filter(Config::withFreePrefix('the_events_calendar_update_venue'), [TheEventsCalendarProHelper::class, 'updateVenue'], 10, 3);
Hooks::filter(Config::withFreePrefix('the_events_calendar_delete_venue'), [TheEventsCalendarProHelper::class, 'deleteVenue'], 10, 3);
Hooks::filter(Config::withFreePrefix('the_events_calendar_create_organizer'), [TheEventsCalendarProHelper::class, 'createOrganizer'], 10, 3);
Hooks::filter(Config::withFreePrefix('the_events_calendar_update_organizer'), [TheEventsCalendarProHelper::class, 'updateOrganizer'], 10, 3);
Hooks::filter(Config::withFreePrefix('the_events_calendar_delete_organizer'), [TheEventsCalendarProHelper::class, 'deleteOrganizer'], 10, 3);
Hooks::filter(Config::withFreePrefix('the_events_calendar_create_event_category'), [TheEventsCalendarProHelper::class, 'createEventCategory'], 10, 3);
Hooks::filter(Config::withFreePrefix('the_events_calendar_create_series'), [TheEventsCalendarProHelper::class, 'createSeries'], 10, 3);
Hooks::filter(Config::withFreePrefix('the_events_calendar_add_event_to_series'), [TheEventsCalendarProHelper::class, 'addEventToSeries'], 10, 3);
