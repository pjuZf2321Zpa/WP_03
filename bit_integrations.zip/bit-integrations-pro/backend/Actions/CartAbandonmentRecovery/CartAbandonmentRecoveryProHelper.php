<?php

namespace BitApps\IntegrationsPro\Actions\CartAbandonmentRecovery;

use Cartflows_Ca_Email_Schedule;
use Cartflows_Ca_Helper;

final class CartAbandonmentRecoveryProHelper
{
    private const VALID_CART_STATUSES = ['normal', 'abandoned', 'completed', 'lost'];

    public static function deleteAbandonedCart($response, $fieldData, $integrationDetails = null)
    {
        if (!self::isPluginActive()) {
            return self::errorResponse(__('Cart Abandonment Recovery is not installed or activated', 'bit-integrations-pro'));
        }

        $sessionId = self::getSessionId($fieldData, $integrationDetails);
        if (empty($sessionId)) {
            return self::errorResponse(__('Session ID is required', 'bit-integrations-pro'));
        }

        $tableName = self::getCartTableName();
        if (empty($tableName)) {
            return self::errorResponse(__('Cart abandonment table is unavailable', 'bit-integrations-pro'));
        }

        global $wpdb;
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.DirectDatabaseQuery.DirectQuery
        $deleted = $wpdb->delete($tableName, ['session_id' => $sessionId]);

        if (!$deleted) {
            return self::errorResponse(__('No cart record found for the given session ID', 'bit-integrations-pro'));
        }

        return self::successResponse(__('Abandoned cart record deleted', 'bit-integrations-pro'), ['session_id' => $sessionId]);
    }

    public static function rescheduleRecoveryEmails($response, $fieldData, $integrationDetails = null)
    {
        if (!self::isPluginActive()) {
            return self::errorResponse(__('Cart Abandonment Recovery is not installed or activated', 'bit-integrations-pro'));
        }

        $sessionId = self::getSessionId($fieldData, $integrationDetails);
        if (empty($sessionId)) {
            return self::errorResponse(__('Session ID is required', 'bit-integrations-pro'));
        }

        if (!class_exists('Cartflows_Ca_Helper') || !class_exists('Cartflows_Ca_Email_Schedule')) {
            return self::errorResponse(__('Required WCAR plugin classes missing', 'bit-integrations-pro'));
        }

        $checkoutDetails = Cartflows_Ca_Helper::get_instance()->get_checkout_details($sessionId);
        if (!$checkoutDetails) {
            return self::errorResponse(__('No cart record found for the given session ID', 'bit-integrations-pro'));
        }

        Cartflows_Ca_Email_Schedule::get_instance()->schedule_emails($sessionId, true);

        return self::successResponse(__('Recovery emails rescheduled', 'bit-integrations-pro'), ['session_id' => $sessionId]);
    }

    public static function updateCartStatus($response, $fieldData, $integrationDetails = null)
    {
        if (!self::isPluginActive()) {
            return self::errorResponse(__('Cart Abandonment Recovery is not installed or activated', 'bit-integrations-pro'));
        }

        $sessionId = self::getSessionId($fieldData, $integrationDetails);
        $defaultStatus = \is_array($fieldData) && isset($fieldData['order_status']) ? $fieldData['order_status'] : '';
        $orderStatus = strtolower(sanitize_text_field(self::getIntegrationValue($integrationDetails, 'orderStatus', $defaultStatus)));

        if (empty($sessionId) || empty($orderStatus)) {
            return self::errorResponse(__('Session ID and order status are required', 'bit-integrations-pro'));
        }

        if (!\in_array($orderStatus, self::VALID_CART_STATUSES, true)) {
            return self::errorResponse(__('Invalid order status. Use: normal, abandoned, completed, or lost', 'bit-integrations-pro'));
        }

        $tableName = self::getCartTableName();
        if (empty($tableName)) {
            return self::errorResponse(__('Cart abandonment table is unavailable', 'bit-integrations-pro'));
        }

        global $wpdb;
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.DirectDatabaseQuery.DirectQuery
        $updated = $wpdb->update(
            $tableName,
            ['order_status' => $orderStatus],
            ['session_id'   => $sessionId]
        );

        if (!$updated) {
            return self::errorResponse(__('No cart record found or status unchanged', 'bit-integrations-pro'));
        }

        return self::successResponse(__('Cart status updated', 'bit-integrations-pro'), ['session_id' => $sessionId, 'order_status' => $orderStatus]);
    }

    private static function getSessionId($fieldData, $integrationDetails)
    {
        $selectedSessionId = self::getIntegrationValue($integrationDetails, 'sessionId', '');
        if ($selectedSessionId !== null && $selectedSessionId !== '') {
            return sanitize_text_field($selectedSessionId);
        }

        $sessionId = \is_array($fieldData) && isset($fieldData['session_id']) ? $fieldData['session_id'] : '';

        return sanitize_text_field($sessionId);
    }

    private static function getIntegrationValue($integrationDetails, $key, $default = '')
    {
        if (\is_object($integrationDetails) && isset($integrationDetails->{$key})) {
            return $integrationDetails->{$key};
        }

        if (\is_array($integrationDetails) && isset($integrationDetails[$key])) {
            return $integrationDetails[$key];
        }

        return $default;
    }

    private static function getCartTableName()
    {
        if (!\defined('CARTFLOWS_CA_CART_ABANDONMENT_TABLE')) {
            return '';
        }

        global $wpdb;

        return $wpdb->prefix . CARTFLOWS_CA_CART_ABANDONMENT_TABLE;
    }

    private static function isPluginActive()
    {
        return \defined('CARTFLOWS_CA_FILE');
    }

    private static function successResponse($message, $data = [])
    {
        return [
            'success' => true,
            'message' => $message,
            'data'    => $data,
        ];
    }

    private static function errorResponse($message)
    {
        return [
            'success' => false,
            'message' => $message,
        ];
    }
}
