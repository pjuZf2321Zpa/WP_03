<?php

namespace MasterStudy\Lms\Pro\addons\certificate_builder\Repositories;

use MasterStudy\Lms\Plugin\Addons;

final class CertificateAdminAccess {
	public static function can_access(): bool {
		if ( ! self::addon_enabled() ) {
			return false;
		}

		if ( current_user_can( 'administrator' ) ) {
			return true;
		}

		return self::instructors_certificates_enabled()
			&& class_exists( '\STM_LMS_Instructor' )
			&& \STM_LMS_Instructor::is_instructor();
	}

	public static function can_manage_all(): bool {
		return self::addon_enabled() && current_user_can( 'administrator' );
	}

	public static function can_filter_instructors(): bool {
		return self::can_manage_all();
	}

	private static function addon_enabled(): bool {
		return function_exists( 'is_ms_lms_addon_enabled' )
			&& is_ms_lms_addon_enabled( Addons::CERTIFICATE_BUILDER );
	}

	private static function instructors_certificates_enabled(): bool {
		if ( ! class_exists( '\STM_LMS_Options' ) ) {
			return false;
		}

		return (bool) \STM_LMS_Options::get_option( 'instructors_certificates', false );
	}
}
