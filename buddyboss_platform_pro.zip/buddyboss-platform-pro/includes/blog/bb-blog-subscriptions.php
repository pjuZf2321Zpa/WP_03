<?php
/**
 * BuddyBoss Pro Blog Subscriptions.
 *
 * Gate wiring + publish fan-out trigger for the `blog_category` subscription
 * type registered by `BB_Blog_Notification` (`class-bb-blog-notification.php`).
 *
 * @package BuddyBossPro
 *
 * @since 3.1.0
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

/**
 * Gate the `blog_category` subscription type's availability on the Pro
 * "Subscriptions" upgrade (option + `blogging` feature active + license).
 *
 * The subscription TYPE itself is always registered (see
 * `BB_Blog_Notification::register_notification_for_new_post()`) so it keeps
 * showing in Notifications admin/user settings; this filter controls
 * whether it is actually usable/sends.
 *
 * @since 3.1.0
 *
 * @param bool   $is_enabled        Whether the subscription type is enabled.
 * @param string $type              Subscription type.
 * @param string $notification_type Notification type.
 *
 * @return bool
 */
function bb_blog_pro_is_enabled_subscription( $is_enabled, $type, $notification_type = '' ) {
	if ( 'blog_category' === $type ) {
		return bb_blog_pro_is_subscriptions_enabled();
	}

	return $is_enabled;
}
add_filter( 'bb_is_enabled_subscription', 'bb_blog_pro_is_enabled_subscription', 10, 3 );

/**
 * Seed the `blog-new-post` default email post if it is missing.
 *
 * `register_email_type()` (called from `BB_Blog_Notification::load()`) only
 * adds the type to the *schema* -- the backing `bp-email` post that
 * `bp_send_email()` actually needs is normally created once by
 * `bp_core_install_emails()` during a fresh BuddyBoss install. A site that
 * is already installed and later enables the Pro "Subscriptions" option
 * never re-runs that install routine, so without this, `bp_get_email()`
 * would keep returning `WP_Error` and `bp_send_email( 'blog-new-post', ... )`
 * would silently no-op forever. Runs on `bp_init` priority 20 -- after
 * `BB_Blog_Notification::start()` (priority 5) has populated the schema --
 * and is idempotent (checks for the post before inserting).
 *
 * @since 3.1.0
 *
 * @return void
 */
function bb_blog_pro_maybe_install_email() {
	if ( ! function_exists( 'bp_get_email' ) || ! is_wp_error( bp_get_email( 'blog-new-post' ) ) ) {
		return;
	}

	$schema = bp_email_get_schema();

	if ( empty( $schema['blog-new-post'] ) ) {
		return;
	}

	$post_id = wp_insert_post(
		bp_parse_args(
			$schema['blog-new-post'],
			array(
				'post_status' => 'publish',
				'post_type'   => bp_get_email_post_type(),
			),
			'install_email_blog-new-post'
		)
	);

	if ( empty( $post_id ) || is_wp_error( $post_id ) ) {
		return;
	}

	$tt_ids = wp_set_object_terms( $post_id, 'blog-new-post', bp_get_email_tax_type() );

	if ( is_wp_error( $tt_ids ) ) {
		return;
	}

	$descriptions = bp_email_get_type_schema( 'description' );

	foreach ( $tt_ids as $tt_id ) {
		$term = get_term_by( 'term_taxonomy_id', (int) $tt_id, bp_get_email_tax_type() );

		if ( empty( $term ) || empty( $descriptions['blog-new-post'] ) ) {
			continue;
		}

		wp_update_term(
			(int) $term->term_id,
			bp_get_email_tax_type(),
			array(
				'description' => $descriptions['blog-new-post'],
			)
		);
	}
}
add_action( 'bp_init', 'bb_blog_pro_maybe_install_email', 20 );

/**
 * Notify blog category subscribers when a post is first published.
 *
 * Core worker invoked by both the `transition_post_status` and
 * `wp_after_insert_post` adapters below. Runs on the transition INTO
 * `publish` (old status not already `publish`) for post type `post`, and is
 * guarded per-post by the `_bb_blog_subscribers_notified` meta so re-saving
 * an already-published post (or a later status churn back to publish) never
 * re-fires the fan-out. Collects subscribers across every category assigned
 * to the post -- a union, deduped -- so a member subscribed to more than one
 * of the post's categories is notified exactly once; the author is excluded.
 * Large recipient lists are chunked to `$GLOBALS['bb_background_updater']`
 * (mirrors `bb_send_notifications_to_subscribers()` in
 * `bb-core-subscriptions.php`); a single chunk is sent synchronously.
 *
 * @since 3.1.0
 *
 * @param WP_Post $post Post object (already transitioned into publish).
 *
 * @return void
 */
function bb_blog_pro_notify_subscribers_on_publish( $post ) {
	if ( empty( $post ) || 'post' !== $post->post_type || 'publish' !== $post->post_status ) {
		return;
	}

	if ( ! bb_blog_pro_is_subscriptions_enabled() ) {
		return;
	}

	if ( ! function_exists( 'bb_get_subscription_users' ) ) {
		return;
	}

	$term_ids = wp_get_post_categories( $post->ID, array( 'fields' => 'ids' ) );

	if ( empty( $term_ids ) ) {
		// No categories yet. Do NOT claim the once-guard — REST/block-editor
		// publishes attach terms AFTER transition_post_status fires, so the
		// wp_after_insert_post pass (which runs after terms are saved) can still
		// pick this up. A post genuinely published without categories simply has
		// no subscribers to notify.
		return;
	}

	// Claim the once-guard atomically now that there are categories to fan out
	// to. add_post_meta( $unique = true ) is a no-op returning false when the
	// flag already exists, so the transition_post_status and wp_after_insert_post
	// passes (and any concurrent fires) never double-send.
	if ( ! add_post_meta( $post->ID, '_bb_blog_subscribers_notified', 1, true ) ) {
		return;
	}

	$user_ids          = array();
	$user_category_map = array();

	// @todo: This fetches every subscriber of every category into the request
	// and builds the full map in memory. Platform's bb_send_notifications_to_subscribers()
	// now routes very large lists through a paged background fan-out; this
	// trigger should move to that path (per-category pages, send-time
	// category resolution and a per-post dedupe marker) in a follow-up ticket.
	foreach ( $term_ids as $term_id ) {
		$subscribers = bb_get_subscription_users(
			array(
				'type'    => 'blog_category',
				'item_id' => $term_id,
				'status'  => true,
			),
			true
		);

		if ( empty( $subscribers['subscriptions'] ) ) {
			continue;
		}

		$user_ids = array_merge( $user_ids, $subscribers['subscriptions'] );

		// Track, per subscriber, which of the post's categories they actually
		// subscribe to, so each recipient's email lists only their matched
		// categories (not every category on the post). Keyed by term id so a
		// user can't be listed under the same category twice.
		$term = get_term( $term_id, 'category' );
		if ( $term && ! is_wp_error( $term ) ) {
			foreach ( $subscribers['subscriptions'] as $sub_user_id ) {
				$user_category_map[ (int) $sub_user_id ][ (int) $term_id ] = $term->name;
			}
		}
	}

	if ( empty( $user_ids ) ) {
		return;
	}

	$user_ids  = array_values( array_unique( array_map( 'absint', $user_ids ) ) );
	$author_id = (int) $post->post_author;

	if ( ! empty( $author_id ) ) {
		$author_key = array_search( $author_id, $user_ids, true );
		if ( false !== $author_key ) {
			unset( $user_ids[ $author_key ] );
		}
	}

	if ( empty( $user_ids ) ) {
		return;
	}

	$user_ids = array_values( $user_ids );

	$parse_args = array(
		'type'              => 'blog_category',
		'item_id'           => $post->ID,
		'notification_type' => 'bb_blog_new_post',
		'data'              => array(
			'author_id'         => $author_id,
			'category_names'    => implode( ', ', wp_list_pluck( get_the_category( $post->ID ), 'name' ) ),
			'user_category_map' => $user_category_map,
		),
	);

	// Clamp like Platform's dispatcher: a filter returning 0 or less would make
	// array_chunk() throw a ValueError on PHP 8 and fatal the publish.
	$min_count = max( 1, (int) apply_filters( 'bb_subscription_queue_min_count', 20 ) );
	$chunks    = array_chunk( $user_ids, $min_count );

	if ( count( $chunks ) > 1 && ! empty( $GLOBALS['bb_background_updater'] ) ) {
		global $bb_background_updater;

		foreach ( $chunks as $chunk ) {
			$chunk_args             = $parse_args;
			$chunk_args['user_ids'] = $chunk;

			// The category map is O(subscribers); carry only this chunk's
			// recipients in its row instead of duplicating the whole map into
			// every row of the queue table.
			if ( ! empty( $user_category_map ) ) {
				$chunk_args['data']['user_category_map'] = array_intersect_key( $user_category_map, array_flip( $chunk ) );
			}

			$bb_background_updater->data(
				array(
					'type'     => 'notification',
					'group'    => 'send_notifications_to_subscribers',
					'data_id'  => $post->ID,
					'priority' => 5,
					'callback' => array( BB_Blog_Notification::instance(), 'send_new_post_notifications' ),
					'args'     => array( $chunk_args ),
				)
			);

			$bb_background_updater->save();
		}

		$bb_background_updater->dispatch();
	} else {
		$parse_args['user_ids'] = $user_ids;
		call_user_func( array( BB_Blog_Notification::instance(), 'send_new_post_notifications' ), $parse_args );
	}
}
/**
 * Adapter for `transition_post_status`. Fires on the publish transition, including a
 * scheduled post published by WP-Cron (which wp_after_insert_post does not
 * cover). Categories set when the post was scheduled are present here.
 *
 * @since 3.1.0
 *
 * @param string  $new_status New post status.
 * @param string  $old_status Old post status.
 * @param WP_Post $post       Post object.
 *
 * @return void
 */
function bb_blog_pro_notify_subscribers_on_transition( $new_status, $old_status, $post ) {
	if ( 'publish' !== $new_status || 'publish' === $old_status ) {
		return;
	}

	bb_blog_pro_notify_subscribers_on_publish( $post );
}
add_action( 'transition_post_status', 'bb_blog_pro_notify_subscribers_on_transition', 10, 3 );

/**
 * Adapter for `wp_after_insert_post`. Fires AFTER terms/meta are saved, so a post
 * published via the block editor / REST — which attaches its categories in a
 * separate step after transition_post_status has already fired — is still
 * caught. The once-guard keeps this from double-notifying alongside the
 * transition pass.
 *
 * @since 3.1.0
 *
 * @param int          $post_id     Post ID.
 * @param WP_Post      $post        Post object.
 * @param bool         $update      Whether this is an update.
 * @param WP_Post|null $post_before Post object before the update, or null.
 *
 * @return void
 */
function bb_blog_pro_notify_subscribers_after_insert( $post_id, $post, $update, $post_before ) {
	if ( empty( $post ) || 'publish' !== $post->post_status ) {
		return;
	}

	if ( $post_before instanceof WP_Post && 'publish' === $post_before->post_status ) {
		return;
	}

	bb_blog_pro_notify_subscribers_on_publish( $post );
}
add_action( 'wp_after_insert_post', 'bb_blog_pro_notify_subscribers_after_insert', 10, 4 );

/**
 * Remove the `blog_category` type from the generic member Subscriptions tab
 * display — blog subscriptions get their own "Blog Subscriptions" tab. This
 * is display-only; the create/notify paths read the raw registry and are
 * unaffected.
 *
 * @since 3.1.0
 *
 * @param array $types Map of subscription_type => label.
 *
 * @return array
 */
function bb_blog_pro_hide_blog_category_from_generic_tab( $types ) {
	unset( $types['blog_category'] );

	return $types;
}
add_filter( 'bb_subscriptions_settings_visible_types', 'bb_blog_pro_hide_blog_category_from_generic_tab' );
