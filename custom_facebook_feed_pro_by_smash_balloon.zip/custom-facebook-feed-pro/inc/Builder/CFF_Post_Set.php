<?php

/**
 * Custom Facebook Feed Feed Post Set
 *
 * @since 4.0
 */

namespace CustomFacebookFeed\Builder;

use CustomFacebookFeed\CFF_Cache_System;
use CustomFacebookFeed\CFF_Parse_Pro;

if (!defined('ABSPATH')) {
	exit; // Exit if accessed directly
}

class CFF_Post_Set
{
	/**
	 * @var int
	 */
	private $feed_id;

	/**
	 * @var array
	 */
	private $feed_settings;

	/**
	 * @var array
	 */
	private $converted_settings;

	/**
	 * @var string
	 */
	private $transient_name;

	/**
	 * @var array|object
	 */
	private $data;

	/**
	 * @var array|object
	 */
	private $comments_data;

	public function __construct($feed_id)
	{
		$this->feed_id = $feed_id;
		$this->transient_name = '*' . $feed_id;
		$this->data = array();
	}

	/**
	 * @return array|object
	 *
	 * @since 4.0
	 */
	public function get_data()
	{
		return $this->data;
	}

	/**
	 * @return array|object
	 *
	 * @since 4.0
	 */
	public function get_comments_data()
	{
		return $this->comments_data;
	}

	/**
	 * @return array
	 *
	 * @since 4.0
	 */
	public function get_feed_settings()
	{
		return $this->feed_settings;
	}

	/**
	 * @return array
	 *
	 * @since 4.0
	 */
	public function get_converted_settings()
	{
		return $this->converted_settings;
	}

	/**
	 * Sets the settings in builder form as well as converted
	 * settings for general use in the plugin
	 *
	 * @since 4.0
	 */
	public function init($customizerBuilder = false, $previewSettings = false)
	{
		$saver = new CFF_Feed_Saver($this->feed_id);
		if ($customizerBuilder && $previewSettings != false) {
			if (isset($previewSettings['album'])) {
				$previewSettings['album'] = CFF_Source::extract_id($previewSettings['album'], 'album');
			}
			if (isset($previewSettings['playlist'])) {
				$previewSettings['playlist'] = CFF_Source::extract_id($previewSettings['playlist'], 'playlist');
			}
			// $this->feed_settings = $saver->get_feed_settings_preview( $previewSettings );
			$this->feed_settings =  $previewSettings;
		} else {
			$this->feed_settings = $saver->get_feed_settings();
		}

		$this->converted_settings = CFF_Post_Set::builder_to_general_settings_convert($this->feed_settings);
	}

	/**
	 * Gathers posts from the API until the minimum number of posts
	 * for the feed are retrieved then stores the results
	 *
	 * @since 4.0
	 */
	public function fetch()
	{
		$settings = $this->converted_settings;
		$transient = $settings['type'] === 'events' ? $this->feed_id : $this->transient_name;

		$facebook_feed = new \CustomFacebookFeed\CFF_Feed_Pro($transient, true);

		if ($facebook_feed->need_posts($settings['num']) && $facebook_feed->can_get_more_posts()) {
			while ($facebook_feed->need_posts($settings['num']) && $facebook_feed->can_get_more_posts()) {
				$facebook_feed->add_remote_posts($settings, $this->feed_id);
			}
		}
		$post_data = $facebook_feed->get_post_data();
		$this->data = $post_data;
	}

	public static function check_published_videos($data_array, $settings)
	{
		$result_posts = [];
		$i = 0;
		$videos_to_show = $settings['videotypetoshow'];

		foreach ($data_array as $post) {
			if (isset($post->status->publishing_phase->publish_time)
				&& $i < $settings['num']
			) {
				$video_type = self::video_type($post);
				if ( $videos_to_show === 'both'
					|| $video_type === $videos_to_show
				) {
					array_push($result_posts, $post);
				}
			}
			$i++;
		}
		$data_array = $result_posts;
		return $data_array;
	}


	/**
	 * Classify a video/Reel post as "reels", "videos", or not-a-video (false),
	 * on EITHER cached Graph shape CFF Pro produces.
	 *
	 * The `/videos` edge (feedtype 'videos') caches `embed_html` and Reels are
	 * classified from its iframe src permalink shape. For every post that
	 * actually carries `embed_html`, this returns exactly what the
	 * pre-SMASH-1909 implementation returned -- the substring test is
	 * unchanged and still runs against the whole embed markup, where the
	 * permalink appears URL-encoded inside the iframe src's `href` param.
	 *
	 * The `/posts` (timeline) edge never caches `embed_html` at all
	 * (CFF_Graph_Url::get_common_fields() has no `embed_html` in the
	 * `attachments` field list), so `video_type()` always returned `false`
	 * for every timeline post, Reel or not. SMASH-1909 closes that gap by
	 * applying the identical /reel//videos/ substring test to the video
	 * attachment's `unshimmed_url` instead, when `embed_html` is absent.
	 *
	 * The one input whose result changes is a post carrying a present-but-
	 * EMPTY `embed_html`: that used to short-circuit to false, and now falls
	 * through to the timeline test (see get_embed_html()). Nothing in either
	 * cached shape produces that post today -- the videos edge always fills
	 * `embed_html` and the timeline edge always omits it -- so this is
	 * hardening against a malformed cache, not a behaviour change to a shape
	 * the plugin actually stores.
	 *
	 * @since 4.13.0 (SMASH-1909) generalized to the timeline edge.
	 * @since 4.0 original videos-edge behaviour.
	 *
	 * @param object|array $video A raw (json_decode'd) post, either edge.
	 * @return string|false "reels", "videos", or false.
	 */
	public static function video_type($video)
	{
		$embed_html = self::get_embed_html($video);
		if ($embed_html !== false) {
			return self::classify_permalink_shape($embed_html);
		}

		// Timeline edge: no embed_html is ever cached here, so classify from
		// the video attachment's unshimmed_url instead. Posts whose first
		// attachment carries subattachments, or whose first attachment isn't
		// a video, are explicitly out of scope (see get_timeline_video_attachment())
		// -- they return false, same as "not a video", never a guess.
		$attachment = self::get_timeline_video_attachment($video);
		if (!$attachment) {
			return false;
		}

		return self::classify_permalink_shape(CFF_Parse_Pro::get_attachment_unshimmed_url($attachment));
	}

	/**
	 * Convenience boolean wrapper around video_type() for callers that only
	 * care whether a post is a Reel, not the videos/false distinction.
	 *
	 * @since 4.13.0 (SMASH-1909)
	 *
	 * @param object|array $post A raw (json_decode'd) post, either edge.
	 * @return bool True when the post classifies as a Reel.
	 */
	public static function is_reel($post)
	{
		return self::video_type($post) === 'reels';
	}

	/**
	 * The shared /reel/ vs /videos/ permalink-shape substring test. Facebook
	 * Graph has no dedicated Reels field for either edge CFF Pro reads, so
	 * this heuristic (originally videos-edge-only, see video_type() history)
	 * is now the one classification primitive both edges route through.
	 *
	 * `%2Freel%2F` / `%2Fvideos%2F` cover the URL-encoded shape that shows up
	 * when the permalink is itself a query-string value (the videos edge's
	 * embed_html iframe src wraps its permalink this way -- see
	 * get_video_permalink()).
	 *
	 * @since 4.13.0 (SMASH-1909) extracted from video_type().
	 *
	 * @param mixed $haystack embed_html markup, or a permalink/unshimmed_url string.
	 * @return string|false "reels", "videos", or false.
	 */
	private static function classify_permalink_shape($haystack)
	{
		if (!is_string($haystack) || $haystack === '') {
			return false;
		}

		if (
			strpos($haystack, '/reel/') !== false
			|| strpos($haystack, '%2Freel%2F') !== false
		) {
			return "reels";
		} elseif (
			strpos($haystack, '/videos/') !== false
			|| strpos($haystack, '%2Fvideos%2F') !== false
		) {
			return "videos";
		}
		return false;
	}

	/**
	 * Read the top-level `embed_html` field if present (the videos-edge
	 * signal), using the same shallow-array-cast access video_type() used
	 * pre-SMASH-1909 -- safe here because `embed_html` is always a top-level
	 * scalar, never a nested structure.
	 *
	 * A present-but-empty (or non-string) `embed_html` is reported as ABSENT,
	 * not as an empty videos-edge signal. This matters because every caller
	 * branches on "is this the videos edge or the timeline edge": returning
	 * `''` would claim the videos edge, classify against an empty haystack,
	 * and return false without ever trying the timeline `unshimmed_url`
	 * fallback that SMASH-1909 exists to add.
	 *
	 * @since 4.13.0 (SMASH-1909)
	 *
	 * @param object|array $video A raw (json_decode'd) post, either edge.
	 * @return string|false The embed markup, or false when absent/unusable.
	 */
	private static function get_embed_html($video)
	{
		$video_arr = is_array($video) ? $video : (array) $video;
		if (!isset($video_arr['embed_html'])) {
			return false;
		}

		$embed_html = $video_arr['embed_html'];
		if (!is_string($embed_html) || $embed_html === '') {
			return false;
		}

		return $embed_html;
	}

	/**
	 * Locate the single unambiguous video attachment on a timeline
	 * (`/posts` edge) post.
	 *
	 * Timeline posts carry their video, if any, at attachments.data[0] --
	 * but per swipe-view-experience-spec.md S2.1, "Posts carrying
	 * subattachments are out of scope -- do not assume the first
	 * attachment." A post whose first attachment carries `subattachments`
	 * (a multi-photo/video share, or a link "end card") is therefore
	 * explicitly declined rather than guessed at.
	 *
	 * @since 4.13.0 (SMASH-1909)
	 *
	 * @param object|array $post A raw (json_decode'd) timeline post.
	 * @return object|array|false The video attachment, or false when there is
	 *                             no single unambiguous video attachment.
	 */
	public static function get_timeline_video_attachment($post)
	{
		if (!empty(CFF_Parse_Pro::get_sub_attachments($post))) {
			return false;
		}

		$attachments = CFF_Parse_Pro::get_attachments($post);
		if (!is_array($attachments) || !isset($attachments[0])) {
			return false;
		}

		$attachment = $attachments[0];
		if (CFF_Parse_Pro::get_attachment_media_type($attachment) !== 'video') {
			return false;
		}

		return $attachment;
	}

	/**
	 * Recover the human-clickable permalink for a video/Reel post on either
	 * edge. CFF Pro never requests `permalink_url` from either the `/videos`
	 * or `/posts` edge (CFF_Graph_Url::get_call_type_fields_args() /
	 * get_common_fields()), so it is never cached and must be derived:
	 *
	 * - Timeline edge: the video attachment's own `unshimmed_url` already
	 *   IS the permalink (e.g. https://www.facebook.com/page/videos/123/ or
	 *   .../reel/123/) -- no extraction needed.
	 * - Videos edge: there is no permalink field at all, only `embed_html`.
	 *   Its iframe `src` (via CFF_Parse_Pro::get_embed_iframe_src()) is
	 *   itself a `.../plugins/video.php?href=<url-encoded permalink>&...`
	 *   wrapper rather than the bare permalink, so this method additionally
	 *   decodes the `href` query param to recover the actual
	 *   https://www.facebook.com/reel/... URL. If that decode fails, the
	 *   wrapper URL is returned as a graceful degrade -- it is still a
	 *   valid, clickable Facebook destination, just not the canonical bare
	 *   shape.
	 *
	 *   Note this deliberately does NOT reuse CFF_Shortcode.php's inline
	 *   iframe-src regex, whose greedy `.*` over-captures every attribute
	 *   after `src` -- see CFF_Parse_Pro::get_embed_iframe_src(). Feeding
	 *   that string to parse_url() happens to still yield the right `href`
	 *   (it is the first `&`-separated pair), but the degrade path above
	 *   would then return 330 characters of quoted HTML attributes as a
	 *   "permalink", which is not a URL and breaks out of any attribute it
	 *   is printed into.
	 *
	 * @since 4.13.0 (SMASH-1909)
	 *
	 * @param object|array $post A raw (json_decode'd) post, either edge.
	 * @return string|false The permalink, or false when it cannot be recovered.
	 */
	public static function get_video_permalink($post)
	{
		$embed_html = self::get_embed_html($post);
		if ($embed_html !== false) {
			$iframe_src = CFF_Parse_Pro::get_embed_iframe_src($embed_html);
			if ($iframe_src === false) {
				return false;
			}
			$decoded_href = self::decode_embed_href($iframe_src);
			return $decoded_href !== false ? $decoded_href : $iframe_src;
		}

		$attachment = self::get_timeline_video_attachment($post);
		if (!$attachment) {
			return false;
		}

		$unshimmed_url = CFF_Parse_Pro::get_attachment_unshimmed_url($attachment);
		return $unshimmed_url !== '' ? $unshimmed_url : false;
	}

	/**
	 * Decode the `href` query parameter out of a
	 * `.../plugins/video.php?href=<encoded permalink>&...` embed src, giving
	 * the bare permalink it wraps.
	 *
	 * @since 4.13.0 (SMASH-1909)
	 *
	 * @param string $iframe_src The embed iframe's src URL.
	 * @return string|false The decoded permalink, or false when absent.
	 */
	private static function decode_embed_href($iframe_src)
	{
		if (!is_string($iframe_src) || $iframe_src === '') {
			return false;
		}

		$query = parse_url($iframe_src, PHP_URL_QUERY);
		if (empty($query)) {
			return false;
		}

		parse_str($query, $params);
		return isset($params['href']) && $params['href'] !== '' ? $params['href'] : false;
	}

	/**
	 * The direct (non-embed) mp4/DASH `source` for a video/Reel post, on
	 * either edge -- top-level `source` on the videos edge, the video
	 * attachment's `media.source` on the timeline edge. Does NOT fall back
	 * to the embed iframe; that escalation is the swipe viewer's business
	 * (swipe-view-experience-spec.md S5, tier 2), not this detection layer's.
	 *
	 * Only a non-empty STRING counts as a source. Cached Graph payloads are
	 * third-party data replayed out of an encrypted transient, so `source`
	 * arriving as null, a number, or a nested structure is possible; every
	 * such value means "no usable direct source" here, and returning it raw
	 * would hand a non-string to is_known_unplayable_source()'s strpos(),
	 * which is a TypeError (fatal) on PHP 8.
	 *
	 * @since 4.13.0 (SMASH-1909)
	 *
	 * @param object|array $post A raw (json_decode'd) post, either edge.
	 * @return string|false A non-empty source URL, or false.
	 */
	public static function get_video_source($post)
	{
		$video_arr = is_array($post) ? $post : (array) $post;
		if (isset($video_arr['source'])) {
			$source = $video_arr['source'];
			return (is_string($source) && $source !== '') ? $source : false;
		}

		$attachment = self::get_timeline_video_attachment($post);
		if (!$attachment) {
			return false;
		}

		$source = CFF_Parse_Pro::get_attachment_media_source($attachment);
		return (is_string($source) && $source !== '') ? $source : false;
	}

	/**
	 * Whether a video/Reel post's only direct source is one the viewer
	 * already knows it cannot play: a DASH manifest (`.mpd`), or no `source`
	 * at all (swipe-view-experience-spec.md S5.4, "known-unplayable
	 * sources"). Callers should decline these up front rather than pay a
	 * visible failed-load round-trip per slide.
	 *
	 * PRECONDITION: call this on a post already known to be a video/Reel
	 * (see is_reel()). It answers "can the direct source play?", and a post
	 * that is not a video at all has no source, so it reports true here --
	 * true means "do not hand this to the native player", NOT "this is a
	 * broken video". A caller that inverts it to pick a decline state would
	 * put every photo and text post into that state.
	 *
	 * `.mpd` is matched as a substring, mirroring the two existing checks in
	 * CFF_Shortcode.php (lines 4150 and 5447) so all three agree on what
	 * counts as a DASH manifest.
	 *
	 * @since 4.13.0 (SMASH-1909)
	 *
	 * @param object|array $post A post already known to be a video/Reel.
	 * @return bool True when there is no playable direct source.
	 */
	public static function is_known_unplayable_source($post)
	{
		$source = self::get_video_source($post);
		if ($source === false) {
			return true;
		}
		return strpos($source, '.mpd') !== false;
	}


	/**
	 * Gathers comments for posts.
	 *
	 * @return array
	 *
	 * @since 4.0
	 */
	public function fetch_comments()
	{
		if (empty($this->data)) {
			return array();
		}

		$settings = $this->converted_settings;

		$comments = [];
		foreach ($this->data as $single_post) {
			$id = CFF_Parse_Pro::get_post_id($single_post);
			$json_object = \CustomFacebookFeed\CFF_Utils::cff_fetchUrl("https://graph.facebook.com/" . $id . "/?fields=comments.limit(5){created_time,from{name,id,picture{url},link},id,message,message_tags,attachment,like_count}&access_token=" . $settings['accesstoken']);
			$comments_return = json_decode($json_object);
			// Comment message and commenter name are attacker-influenceable (anyone with a Facebook
			// account can comment on the Page); strip markup on ingestion like the post fetch does.
			if (is_object($comments_return)) {
				\CustomFacebookFeed\CFF_Shortcode::cff_sanitize_untrusted_post_fields($comments_return);
			}
			if (isset($comments_return->comments->data)) {
				$comments[ $id ] = $comments_return->comments->data;
			}
		}

		$this->comments_data = $comments;

		return $comments;
	}

	/**
	 * Converts raw settings from the cff_feed_settings table into the
	 * more general way that the "CFF_Shortcode" class,
	 * "cff_get_processed_options" method does
	 *
	 * @param array $builder_settings
	 *
	 * @return array
	 *
	 * @since 4.0
	 */
	public static function builder_to_general_settings_convert($builder_settings)
	{
		$settings_with_multiples = array(
			'type',
			'include',
			'exclude',
			'filter',
			'exfilter'
		);

		foreach ($settings_with_multiples as $array_setting) {
			if (is_array($builder_settings) && is_array($builder_settings[ $array_setting ])) {
				$builder_settings[ $array_setting ] = implode(',', $builder_settings[ $array_setting ]);
			}
		}

		if (isset($builder_settings['sources']) && is_array($builder_settings['sources'])) {
			$access_tokens = array();
			$ids = array();
			$id_access_tokens = array();
			$sources_setting = array();
			foreach ($builder_settings['sources'] as $source) {
				$source_array = array();
				if (! is_array($source)) {
					$args = array( 'id' => $source );
					if (isset($builder_settings['feedtype']) && $builder_settings['feedtype'] == 'events') {
						$args['privilege'] = 'events';
					}
					$source_query = \CustomFacebookFeed\Builder\CFF_Db::source_query($args);
					if (isset($source_query[0])) {
						$source_array = $source_query[0];
						$sources_setting[] = $source_query[0];
					}
				} else {
					$source_array = $source;
				}

				if (! empty($source_array)) {
					$access_tokens[] = $source_array['access_token'];
					$ids[] = $source_array['account_id'];
					$id_access_tokens[ $source_array['account_id'] ] = $source_array['access_token'];
					$builder_settings['pagetype'] = $source_array['account_type'];
				}
			}

			if (! empty($sources_setting) && sizeof($sources_setting) > 0) {
				$builder_settings['sources'] = $sources_setting;
			}


			if (count($builder_settings['sources']) > 1) {
				$builder_settings['accesstoken'] = $id_access_tokens;
				$builder_settings['id'] = implode(',', $ids);
			} else {
				$builder_settings['accesstoken'] = implode(',', $access_tokens);
				$builder_settings['id'] = implode(',', $ids);
			}
		}

		$builder_settings['multifeedactive'] = \CustomFacebookFeed\CFF_FB_Settings::check_active_extension('multifeed');
		$builder_settings['daterangeactive'] = \CustomFacebookFeed\CFF_FB_Settings::check_active_extension('date_range');
		$builder_settings['featuredpostactive'] = \CustomFacebookFeed\CFF_FB_Settings::check_active_extension('featured_post');
		$builder_settings['albumactive'] = \CustomFacebookFeed\CFF_FB_Settings::check_active_extension('album');
		$builder_settings['carouselactive'] = \CustomFacebookFeed\CFF_FB_Settings::check_active_extension('carousel');
		$builder_settings['reviewsactive'] = \CustomFacebookFeed\CFF_FB_Settings::check_active_extension('reviews');

		if (
			empty($builder_settings['pagetoken'])
			 || (is_array($builder_settings['pagetoken']) && empty($builder_settings['pagetoken'][0]) )
		) {
			$builder_settings['pagetoken'] = ! empty($builder_settings['accesstoken']) ? $builder_settings['accesstoken'] : '';
		}

		if (! empty($builder_settings['feedtype']) && $builder_settings['feedtype'] === 'reviews') {
			$builder_settings['type'] = 'review';
		}

		return $builder_settings;
	}

	/**
	 * Convert settings from 3.x for use in the builder in 4.0+
	 *
	 * @param array $atts
	 *
	 * @return array
	 *
	 * @since 4.0.3
	 */
	public static function legacy_to_builder_convert($atts = array())
	{
		$options    = get_option('cff_style_settings', array());
		$legacy_feed_settings_obj = new \CustomFacebookFeed\CFF_FB_Settings($atts, $options);

		$processed_settings = $legacy_feed_settings_obj->get_settings();

		$settings_with_multiples = CFF_Post_Set::get_settings_with_multiple();

		foreach ($settings_with_multiples as $multiple_key) {
			if (
				isset($processed_settings[ $multiple_key ])
				 && ! is_array($processed_settings[ $multiple_key ])
			) {
				$processed_settings[ $multiple_key ] = explode(',', $processed_settings[ $multiple_key ]);
			}
		}

		if (
			$processed_settings['cols'] > 1
			 || $processed_settings['colsmobile'] > 1
		) {
			$processed_settings['feedlayout'] = 'masonry';
		} else {
			$processed_settings['feedlayout'] = 'list';
		}
		$processed_settings['feedtype'] = 'timeline';

		if (! in_array('likebox', $processed_settings['include'])) {
			$processed_settings['showlikebox'] = 'off';
		}
		if (! in_array('author', $processed_settings['include'])) {
			$processed_settings['showauthornew'] = false;
		} else {
			$processed_settings['showauthornew'] = true;
		}
		if (! in_array('link', $processed_settings['include'])) {
			$processed_settings['showfacebooklink'] = '';
			$processed_settings['showsharelink'] = '';
		} else {
			$processed_settings['showfacebooklink'] = 'on';
			$processed_settings['showsharelink'] = 'on';
		}
		$processed_settings['showfacebooklink'] = $processed_settings['showfacebooklink'] === 'on' || $processed_settings['showfacebooklink'] === 'true' ? 'on' : '';
		$processed_settings['showsharelink'] = $processed_settings['showsharelink'] === 'on' || $processed_settings['showsharelink'] === 'true' ? 'on' : '';

		$processed_settings['textlength'] = get_option('cff_title_length', '400');
		$processed_settings['desclength'] = get_option('cff_body_length', '200');

		$processed_settings['num'] = isset($processed_settings['num']) ? (string)$processed_settings['num'] : '5';

		$processed_settings = CFF_Post_Set::filter_builder_settings($processed_settings);

		return $processed_settings;
	}

	/**
	 * Settings that can include an array of values
	 *
	 * @return array
	 *
	 * @since 4.0.3
	 */
	public static function get_settings_with_multiple()
	{
		$settings_with_multiples = array(
			'type',
			'include',
			'exclude',
		);

		if (\CustomFacebookFeed\CFF_Utils::cff_is_pro_version()) {
			$settings_with_multiples = \CustomFacebookFeed\Builder\Pro\CFF_Post_Set_Pro::add_pro_settings_with_multiple($settings_with_multiples);
		}

		return $settings_with_multiples;
	}

	/**
	 * Used for changing the settings used for general front end feeds
	 *
	 * @param array $builder_settings
	 *
	 * @return array
	 *
	 * @since 4.0.3
	 */
	public static function filter_general_settings($builder_settings)
	{
		if (\CustomFacebookFeed\CFF_Utils::cff_is_pro_version()) {
			$builder_settings = \CustomFacebookFeed\Builder\Pro\CFF_Post_Set_Pro::add_general_pro_settings($builder_settings);
		}
		return $builder_settings;
	}

	/**
	 * Used for changing the settings for feeds being edited in the customizer
	 *
	 * @param array $processed_settings
	 *
	 * @return array
	 *
	 * @since 4.0.3
	 */
	public static function filter_builder_settings($processed_settings)
	{
		if (\CustomFacebookFeed\CFF_Utils::cff_is_pro_version()) {
			$processed_settings = \CustomFacebookFeed\Builder\Pro\CFF_Post_Set_Pro::add_builder_pro_settings($processed_settings);
		}
		return $processed_settings;
	}
}
