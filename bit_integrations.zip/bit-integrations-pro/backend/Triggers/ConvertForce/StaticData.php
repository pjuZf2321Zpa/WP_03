<?php

namespace BitApps\IntegrationsPro\Triggers\ConvertForce;

class StaticData
{
    public static function tasks()
    {
        return [
            [
                'form_name'           => __('Campaign Created', 'bit-integrations-pro'),
                'triggered_entity_id' => 'convert_force_campaign_created',
                'skipPrimaryKey'      => true,
            ],
            [
                'form_name'           => __('Campaign Updated', 'bit-integrations-pro'),
                'triggered_entity_id' => 'convert_force_campaign_updated',
                'skipPrimaryKey'      => true,
            ],
            [
                'form_name'           => __('Campaign Status Changed', 'bit-integrations-pro'),
                'triggered_entity_id' => 'convert_force_campaign_status_changed',
                'skipPrimaryKey'      => true,
            ],
            [
                'form_name'           => __('Campaign Deleted', 'bit-integrations-pro'),
                'triggered_entity_id' => 'convert_force_campaign_deleted',
                'skipPrimaryKey'      => true,
            ],
        ];
    }
}
