<?php

namespace BitApps\IntegrationsPro\Actions\Booknetic\Services;

use BitApps\IntegrationsPro\Triggers\Booknetic\BookneticHelper;

abstract class BaseService
{
    protected $fields;

    public function __construct($fieldData = [], $settings = [])
    {
        $mapped = array_filter((array) $fieldData, static function ($value) {
            return $value !== '' && $value !== null;
        });

        $this->fields = array_merge((array) $settings, $mapped);
    }

    protected function value(string $key)
    {
        $value = $this->fields[$key] ?? '';

        return \is_string($value) ? trim($value) : $value;
    }

    protected function has(string $key): bool
    {
        $value = $this->value($key);

        return $value !== '' && $value !== null && $value !== [];
    }

    protected function string(string $key): string
    {
        $value = $this->value($key);

        return \is_scalar($value) ? (string) $value : '';
    }

    protected function int(string $key): int
    {
        return (int) $this->value($key);
    }

    protected function validate(array $rules): ?array
    {
        foreach ($rules as $key => $rule) {
            $label = $rule[0];
            $type = $rule[1] ?? null;

            if (!$this->has($key)) {
                // translators: %s: field label
                return $this->error(wp_sprintf(__('%s is required. Map or select a value.', 'bit-integrations-pro'), $label));
            }

            $value = $this->string($key);

            if ($type === 'integer' && !ctype_digit($value)) {
                // translators: %s: field label
                return $this->error(wp_sprintf(__('%s is not a valid ID. Enter a whole number.', 'bit-integrations-pro'), $label));
            }

            if ($type === 'numeric' && !is_numeric($value)) {
                // translators: %s: field label
                return $this->error(wp_sprintf(__('%s is not a valid number. Enter a number.', 'bit-integrations-pro'), $label));
            }

            if ($type === 'email' && !is_email($value)) {
                // translators: %s: field label
                return $this->error(wp_sprintf(__('%s is not a valid email. Enter a correct email.', 'bit-integrations-pro'), $label));
            }
        }

        return null;
    }

    protected function success($data, ?string $message = null): array
    {
        return [
            'success' => true,
            'message' => $message ?? __('Action completed successfully', 'bit-integrations-pro'),
            'code'    => 200,
            'data'    => BookneticHelper::normalizePayload($data),
        ];
    }

    protected function error(string $message, int $code = 400): array
    {
        return [
            'success' => false,
            'message' => $message,
            'code'    => $code,
        ];
    }

    protected function createRecord($modelClass, array $data): array
    {
        if (!$modelClass::query()->insert($data)) {
            return $this->error(__('Booknetic did not create the record. Try again.', 'bit-integrations-pro'));
        }

        return $this->success($modelClass::query()->get((int) $modelClass::lastId()));
    }

    protected function updateRecord($modelClass, int $recordId, array $data): array
    {
        if (empty($modelClass::query()->get($recordId))) {
            return $this->error(__('The Booknetic record does not exist. Select a different record.', 'bit-integrations-pro'));
        }

        if (empty($data)) {
            return $this->error(__('No field is set. Map one or more fields to update.', 'bit-integrations-pro'));
        }

        if ($modelClass::query()->where('id', $recordId)->update($data) === false) {
            return $this->error(__('Booknetic did not update the record. Try again.', 'bit-integrations-pro'));
        }

        return $this->success($modelClass::query()->get($recordId));
    }

    protected function deleteRecord($modelClass, int $recordId, string $deletedMessage): array
    {
        if (empty($modelClass::query()->get($recordId))) {
            return $this->error(__('The Booknetic record does not exist. Select a different record.', 'bit-integrations-pro'));
        }

        if ($modelClass::query()->where('id', $recordId)->delete() === false) {
            return $this->error(__('Booknetic did not delete the record. Try again.', 'bit-integrations-pro'));
        }

        return $this->success(['id' => $recordId], $deletedMessage);
    }

    protected function optionalTextFields(array $fieldMap): array
    {
        $data = [];

        foreach ($fieldMap as $inputField => $modelField) {
            if ($this->has($inputField)) {
                $data[$modelField] = $this->string($inputField);
            }
        }

        return $data;
    }

    protected function optionalIntFields(array $keys): array
    {
        $data = [];

        foreach ($keys as $key) {
            if ($this->has($key)) {
                $data[$key] = $this->int($key);
            }
        }

        return $data;
    }

    protected function parseDate($value): ?string
    {
        $dateTime = date_create((string) $value, wp_timezone());

        return $dateTime ? $dateTime->format('Y-m-d') : null;
    }

    protected function parseTimestamp($value): int
    {
        if (is_numeric($value)) {
            return (int) $value;
        }

        $dateTime = date_create((string) $value, wp_timezone());

        return $dateTime ? $dateTime->getTimestamp() : 0;
    }

    protected function toBool($value): bool
    {
        return filter_var($value, FILTER_VALIDATE_BOOLEAN);
    }

    protected function missingWpUser($userId): bool
    {
        return (int) $userId > 0 && !get_userdata((int) $userId);
    }

    protected function linkWpUser($userId, string $role, $previousUserId = 0): void
    {
        $userId = (int) $userId;
        $previousUserId = (int) $previousUserId;

        if ($previousUserId > 0 && $previousUserId !== $userId && ($previousUser = get_userdata($previousUserId))) {
            $previousUser->remove_role($role);
        }

        if ($userId > 0 && ($user = get_userdata($userId))) {
            $user->add_role($role);
        }
    }

    protected function ids(string $key): array
    {
        $value = $this->value($key);

        if (\is_string($value)) {
            $decoded = json_decode($value, true);
            $value = \is_array($decoded) ? $decoded : explode(',', $value);
        }

        return array_values(array_unique(array_filter(array_map('intval', (array) $value))));
    }
}
