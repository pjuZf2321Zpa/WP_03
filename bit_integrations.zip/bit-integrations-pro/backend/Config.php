<?php

// phpcs:disable Squiz.NamingConventions.ValidVariableName

namespace BitApps\IntegrationsPro;

if (!\defined('ABSPATH')) {
    exit;
}

/**
 * Provides configuration for plugin.
 */
class Config
{
    public const SLUG = 'bit-integrations-pro';

    public const FREE_PLUGIN_SLUG = 'bit-integrations';

    public const TITLE = 'Bit Integrations Pro';

    public const FREE_TITLE = 'Bit Integrations';

    public const VAR_PREFIX = 'bit_integrations_pro_';

    public const VAR_FREE_PREFIX = 'bit_integrations_';

    public const VERSION = '2.8.8';

    public const DB_VERSION = '1.0';

    public const API_VERSION = '1.0';

    /**
     * Provides configuration for plugin.
     *
     * @param string $type    Type of conf
     * @param string $default Default value
     *
     * @return array|string|null
     */
    public static function get($type, $default = null)
    {
        switch ($type) {
            case 'MAIN_FILE':
                return BIT_INTEGRATIONS_PRO_PLUGIN_FILE;

            case 'BASENAME':
                return plugin_basename(trim(self::get('MAIN_FILE')));

            case 'BASEDIR':
                return plugin_dir_path(self::get('MAIN_FILE'));

            case 'BACKEND_DIR':
                return plugin_dir_path(self::get('MAIN_FILE')) . 'backend';

            case 'SITE_URL':
                $parsedUrl = wp_parse_url(get_admin_url());
                $siteUrl = $parsedUrl['scheme'] . '://' . $parsedUrl['host'];
                $siteUrl .= empty($parsedUrl['port']) ? null : ':' . $parsedUrl['port'];

                return $siteUrl;

            case 'ADMIN_URL':
                return str_replace(self::get('SITE_URL'), '', get_admin_url());

            case 'API_URL':
                return get_rest_url(null, '/' . self::SLUG . '/v1');

            case 'ROOT_URI':
                return set_url_scheme(plugins_url('', self::get('MAIN_FILE')), wp_parse_url(home_url())['scheme']);

            case 'ASSET_URI':
                return self::get('ROOT_URI') . '/build';

            case 'PLUGIN_PAGE_LINKS':
                return self::pluginPageLinks();

            case 'WP_DB_PREFIX':
                global $wpdb;

                return $wpdb->prefix;

            default:
                return $default;
        }
    }

    /**
     * Prefixed variable name with prefix.
     *
     * @param string $option Variable name
     *
     * @return string
     */
    public static function withPrefix($option)
    {
        return self::VAR_PREFIX . $option;
    }

    /**
     * Prefixed variable name with prefix.
     *
     * @param string $option Variable name
     *
     * @return string
     */
    public static function withFreePrefix($option)
    {
        return self::VAR_FREE_PREFIX . $option;
    }

    /**
     * Retrieves options from option table.
     *
     * @param string $option  Option name
     * @param bool   $default default value
     * @param bool   $wp      Whether option is default wp option
     *
     * @return mixed
     */
    public static function getOption($option, $default = false, $wp = false)
    {
        if ($wp) {
            return get_option($option, $default);
        }

        return get_option(self::withPrefix($option), $default);
    }

    /**
     * Delete option from option table.
     *
     * @param string $option Option name
     */
    public static function deleteOption($option)
    {
        return delete_option(self::withPrefix($option));
    }

    /**
     * Save or update option to option table.
     *
     * @param string $option   Option name
     * @param mixed  $value    Option value
     * @param bool   $autoload Whether option will autoload
     *
     * @return bool
     */
    public static function updateOption($option, $value, $autoload = null)
    {
        return update_option(self::withPrefix($option), $value, !\is_null($autoload) ? 'yes' : null);
    }

    /**
     * Provides links for plugin pages. Those links will bi displayed in
     * all plugin pages under the plugin name.
     *
     * @return array
     */
    private static function pluginPageLinks()
    {
        return [
            'settings' => [
                'title' => __('Settings', 'bit-integrations-pro'),
                'url'   => self::get('ADMIN_URL') . 'admin.php?page=bit-integrations#settings',
            ],
            'help' => [
                'title' => __('Help', 'bit-integrations-pro'),
                'url'   => self::get('ADMIN_URL') . 'admin.php?page=bit-integrations#help',
            ],
        ];
    }
}
