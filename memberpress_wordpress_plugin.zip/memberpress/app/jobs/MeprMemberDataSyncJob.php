<?php

defined('ABSPATH') || exit;

/**
 * Recurring background job that keeps the members table in sync.
 *
 * Each run first creates rows for users missing from the members table, then
 * re-syncs existing rows oldest-updated first. The re-sync makes rows whose
 * underlying data changed without firing a recompute hook (for example a
 * transaction lapsing by date) self-heal within one cycle.
 *
 * Missing rows take precedence and are not rate paced, so a bulk user import
 * defers the stale sweep until the fill drains. That work is deferred rather
 * than lost: the pacing window advances only when a run starts fresh, and the
 * heartbeat enqueues nothing while a chain of continuations is still queued,
 * so the next fresh run is credited for the whole time the fill took.
 *
 * The heartbeat cron in MeprMembersCtrl enqueues this job whenever one is not
 * already queued, so the sweep survives lost job rows.
 *
 * Because it runs indefinitely on a schedule rather than once, it must not
 * flush the object cache or suspend cache invalidation: on a site with a
 * persistent object cache that would cold-cache the whole site every run.
 * MeprBatchMigrator frees runtime memory between batches.
 *
 * @property integer $limit        The batch limit.
 * @property integer $stale_budget Unspent stale-row budget carried by a continuation.
 */
class MeprMemberDataSyncJob extends MeprBaseJob
{
    /**
     * Option storing the start time of the most recent run.
     *
     * @var string
     */
    const LAST_RUN_OPTION = 'mepr_member_data_sync_last_run';

    /**
     * Option storing when member rows with no user were last cleared.
     *
     * @var string
     */
    const ORPHAN_SWEEP_OPTION = 'mepr_member_data_orphan_sweep';

    /**
     * Queue priority. The worker takes jobs in ascending priority order, so
     * this sits behind the default of 10 and transactional jobs such as
     * emails are always worked first.
     *
     * @var integer
     */
    const PRIORITY = 20;

    /**
     * Minimum number of stale rows to re-sync per run, so small sites
     * converge quickly regardless of the pacing arithmetic.
     *
     * @var integer
     */
    const MIN_STALE_TARGET = 50;

    /**
     * Perform this job.
     *
     * @throws MeprException When a member's write does not land.
     */
    public function perform()
    {
        $mepr_db = MeprDb::fetch();

        if (!$mepr_db->table_exists($mepr_db->members)) {
            return;
        }

        // A job carrying a budget is the continuation of a run that hit the
        // time box: it spends what that run had left and stays inside its
        // pacing window, so the clock is only stamped when a window opens.
        $continuation = isset($this->stale_budget);

        if ($continuation) {
            $stale_target = max(0, $this->stale_budget);
        } else {
            // Rows whose user is gone are cleared before the table is counted,
            // so the pacing target covers only rows a sweep can reach.
            $this->sweep_orphans();

            $stale_target = $this->stale_target();
            update_option(self::LAST_RUN_OPTION, time(), false);
        }

        $processor = new class ($this->limit ?? 10, $stale_target) extends MeprBatchMigrator {
            /**
             * Seconds this batch loop may run for. The jobs worker admits
             * jobs until 45 seconds into a request that should finish within
             * 60, so a job admitted at the window's edge has only this much
             * room. A box this size never outlives the request no matter
             * when the job starts; the continuation the job queues carries
             * on in the next worker run.
             *
             * @var integer
             */
            const TIMEOUT = 15;

            /**
             * Stale-row budget still unspent.
             *
             * @var integer
             */
            private int $stale_budget;

            /**
             * Number of stale rows in the most recently fetched batch.
             *
             * @var integer
             */
            private int $stale_fetched = 0;

            /**
             * True once no user is missing a members row.
             *
             * @var boolean
             */
            private bool $fill_drained = false;

            /**
             * Initializes the batcher with its stale-row budget.
             *
             * @param integer $limit        The maximum number of items to retrieve in each batch.
             * @param integer $stale_budget The number of stale rows this run may re-sync.
             */
            public function __construct(int $limit, int $stale_budget)
            {
                parent::__construct($limit);
                $this->stale_budget = $stale_budget;
            }

            /**
             * The budget a continuation should inherit: what is unspent, plus
             * the stale rows of a fetched batch the caller never processed.
             *
             * @return integer
             */
            public function remaining_stale_budget(): int
            {
                return $this->stale_budget + $this->stale_fetched;
            }

            /**
             * Fetches the next batch of user IDs to sync: users missing from
             * the members table first, topped up with the oldest stale rows
             * while the budget lasts.
             *
             * This is a cursorless batcher (it declares no cursor_column()),
             * so termination relies on both source sets shrinking as items
             * are processed: missing users gain a members row, and stale rows
             * get their updated_at restamped.
             *
             * @return array
             */
            protected function fetch_batch(): array
            {
                $user_ids = [];

                // Proving nobody is missing a row means examining every user, so
                // it is asked once per run rather than once per batch. Anyone
                // registering in between gets their row from user_register, and
                // the next run picks up whatever that missed.
                if (!$this->fill_drained) {
                    $user_ids = MeprUser::get_update_all_member_data_user_ids(true, $this->limit);

                    $this->fill_drained = empty($user_ids);
                }

                $this->stale_fetched = 0;
                $top_up              = min($this->limit - count($user_ids), $this->stale_budget);

                if ($top_up > 0) {
                    $stale_ids           = MeprUser::get_stale_member_user_ids($top_up, MeprMemberDataSyncJob::cycle());
                    $this->stale_fetched = count($stale_ids);
                    $this->stale_budget -= $this->stale_fetched;
                    $user_ids            = array_merge($user_ids, $stale_ids);
                }

                return $user_ids;
            }
        };

        while ($processor->next_batch()) {
            $this->sync_batch($processor->get_items());
        }

        if ($processor->has_items()) {
            $job               = new static();
            $job->limit        = $processor->get_limit();
            $job->stale_budget = $processor->remaining_stale_budget();
            $job->enqueue('now', self::PRIORITY);
        }
    }

    /**
     * Recomputes a batch of members inside one transaction.
     *
     * Each row's write is durable on its own, so a run of them spends most of
     * its time flushing to disk rather than computing; one commit per batch
     * pays that cost once. The batch is the unit of work, so progress commits
     * as the run proceeds and row locks are held for a fraction of a second.
     *
     * A batch that does not reach its commit is rolled back. Leaving one open
     * would swallow every write the worker makes afterwards, including the jobs
     * table row recording this job's own failure and the completion of whatever
     * job it picks up next.
     *
     * Starting a transaction commits any transaction already in progress, so
     * this must not be called from inside one.
     *
     * Where it is available the batch reads at READ COMMITTED, so each
     * recompute sees the latest committed data. Under the default snapshot
     * isolation every row in the batch is computed from the state at the moment
     * the batch opened, and a member who changed mid-batch is written back
     * stale.
     *
     * @param  integer[] $user_ids The user IDs to recompute.
     * @return void
     *
     * @throws MeprException When a member's write does not land.
     */
    protected function sync_batch(array $user_ids)
    {
        global $wpdb;

        // The WordPress test harness wraps each test in its own transaction, and
        // starting one here would implicitly commit that, so the harness keeps
        // ownership of transaction control under test.
        $use_transaction = !defined('TESTS_RUNNING');
        $rollback        = false;

        try {
            if ($use_transaction) {
                if (self::read_committed_is_available()) {
                    $wpdb->query('SET TRANSACTION ISOLATION LEVEL READ COMMITTED');
                }

                $wpdb->query('START TRANSACTION');
                $rollback = true;
            }

            foreach ($user_ids as $user_id) {
                // A row whose write does not land is otherwise invisible:
                // wpdb reports the failure as a false return rather than an
                // exception, and the row would sort first into every future
                // batch and burn a slot there indefinitely. Failing rolls the
                // batch back and puts the reason on the job row via the worker.
                if (!MeprUser::update_member_data_static($user_id)) {
                    throw new MeprException(sprintf(
                        // Translators: %d: user ID.
                        esc_html__('Member data sync failed to write data for user ID %d', 'memberpress'),
                        $user_id
                    ));
                }
            }

            if ($use_transaction) {
                $wpdb->query('COMMIT');
            }

            $rollback = false;
        } finally {
            if ($rollback) {
                $wpdb->query('ROLLBACK');
            }
        }
    }

    /**
     * Whether a batch can read at READ COMMITTED.
     *
     * InnoDB logs row by row at that isolation level, so a server writing a
     * statement-based binary log refuses every write for the duration with
     * ER_BINLOG_STMT_MODE_AND_ROW_ENGINE, and every batch on such a server
     * would fail on its first row. Those servers keep the default isolation
     * and the mid-batch staleness that comes with it.
     *
     * @return boolean
     */
    protected static function read_committed_is_available(): bool
    {
        global $wpdb;

        static $available;

        if (isset($available)) {
            return $available;
        }

        $binlog = $wpdb->get_row('SELECT @@log_bin AS log_bin, @@binlog_format AS binlog_format');

        // An unreadable answer counts as unsafe: guessing wrong the other way
        // costs every write in the batch, where this costs read freshness.
        $available = !empty($binlog)
            && (empty($binlog->log_bin) || strtoupper((string) $binlog->binlog_format) !== 'STATEMENT');

        return $available;
    }

    /**
     * Clears member rows whose user is gone, at most once a day.
     *
     * The delete scans the members table and locks the rows it inspects, so a
     * checkout writing its own member row waits behind it. Rows only become
     * orphaned when a user is deleted, so a daily pass is frequent enough for
     * something that would otherwise sit in the table indefinitely.
     *
     * @return void
     */
    protected function sweep_orphans()
    {
        $swept = (int) get_option(self::ORPHAN_SWEEP_OPTION, 0);

        if ($swept > time() - MeprUtils::days(1)) {
            return;
        }

        update_option(self::ORPHAN_SWEEP_OPTION, time(), false);

        MeprUser::delete_orphan_member_data();
    }

    /**
     * The target period, in seconds, for one full re-sync pass over the
     * members table. Bounds how stale a cached row can get.
     *
     * @return integer
     */
    public static function cycle(): int
    {
        $default = MeprUtils::days(2);
        $cycle   = MeprHooks::apply_filters('mepr_member_data_sync_cycle', $default);

        // A non-numeric filter value casts to zero, which would make the whole
        // table due on every run, so fall back to the default instead.
        if (!is_numeric($cycle)) {
            return $default;
        }

        return max(1, (int) $cycle);
    }

    /**
     * The number of stale rows to re-sync in this run.
     *
     * Paces the sweep so the whole members table recomputes once per cycle,
     * spreading the load evenly across runs regardless of table size. The
     * target scales with the time elapsed since the previous run, so sites
     * with irregular wp-cron traffic still converge on the same cycle.
     *
     * @return integer
     */
    protected function stale_target(): int
    {
        global $wpdb;

        $cycle    = self::cycle();
        $last_run = (int) get_option(self::LAST_RUN_OPTION, 0);
        $elapsed  = $last_run > 0 ? min(max(time() - $last_run, 0), $cycle) : MeprUtils::minutes(10);

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery
        $count = (int) $wpdb->get_var("SELECT COUNT(*) FROM $wpdb->mepr_members");

        return max(self::MIN_STALE_TARGET, (int) ceil($count * $elapsed / $cycle));
    }
}
