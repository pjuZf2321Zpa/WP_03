<?php

namespace BitApps\IntegrationsPro\Actions\NiroHelp\Services;

use BitApps\IntegrationsPro\Actions\NiroHelp\NiroHelpHelper;
use NiroHelp\Models\Term;

if (!\defined('ABSPATH')) {
    exit;
}

final class TaxonomyService extends BaseService
{
    public function createProduct(): array
    {
        return $this->createTerm(NiroHelpHelper::PRODUCT_TAXONOMY, __('The product is created.', 'bit-integrations-pro'));
    }

    public function createReason(): array
    {
        return $this->createTerm(NiroHelpHelper::REASON_TAXONOMY, __('The reason is created.', 'bit-integrations-pro'));
    }

    public function createTopic(): array
    {
        return $this->createTerm(NiroHelpHelper::TOPIC_TAXONOMY, __('The topic is created.', 'bit-integrations-pro'));
    }

    private function createTerm(string $taxonomy, string $successMessage): array
    {
        $error = $this->validateRequiredFields(['name' => __('Name', 'bit-integrations-pro')]);

        if ($error !== null) {
            return $error;
        }

        $termArgs = [];

        if ($this->hasValue('slug')) {
            $termArgs['slug'] = $this->getString('slug');
        }

        if ($this->hasValue('description')) {
            $termArgs['description'] = wp_slash($this->getString('description'));
        }

        if ($this->hasValue('parent_id')) {
            if (!$this->termExists('parent_id', $taxonomy)) {
                return $this->errorResponse(__('The parent topic does not exist. Select a different topic.', 'bit-integrations-pro'));
            }

            $termArgs['parent'] = (int) $this->getInteger('parent_id');
        }

        $createdTerm = wp_insert_term(wp_slash($this->getString('name')), $taxonomy, $termArgs);

        if (is_wp_error($createdTerm)) {
            return $this->errorResponse($createdTerm->get_error_message());
        }

        $termId = (int) $createdTerm['term_id'];

        if ($taxonomy === NiroHelpHelper::TOPIC_TAXONOMY) {
            update_term_meta($termId, 'menu_order', Term::next_menu_order($taxonomy));
        }

        return $this->successResponse($successMessage, NiroHelpHelper::getTermData($termId));
    }
}
