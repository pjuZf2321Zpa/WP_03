<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Core\Util\Route;
use BitApps\IntegrationsPro\Triggers\AppointmentHourBooking\AppointmentHourBookingController;

Route::get('appointment_hour_booking/get', [AppointmentHourBookingController::class, 'getAllTasks']);
