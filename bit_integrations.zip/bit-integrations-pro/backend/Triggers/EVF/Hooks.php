<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Core\Util\Hooks;
use BitApps\IntegrationsPro\Triggers\EVF\EVFController;

Hooks::add('everest_forms_complete_entry_save', [EVFController::class, 'handleSubmission'], 10, 5);
