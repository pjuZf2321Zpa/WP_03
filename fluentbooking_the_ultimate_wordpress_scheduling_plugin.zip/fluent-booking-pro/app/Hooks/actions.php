<?php

defined( 'ABSPATH' ) || exit;

/**
 * @var $app \FluentBooking\Framework\Foundation\Application
 */

// Global Payment Handler
(new FluentBookingPro\App\Hooks\Handlers\GlobalPaymentHandler)->register();
(new FluentBookingPro\App\Hooks\Handlers\FrontendRenderer())->register();
(new FluentBookingPro\App\Hooks\Handlers\RecurringEventHandler())->register();
(new FluentBookingPro\App\Hooks\Handlers\UploadHandler($app));
(new FluentBookingPro\App\Hooks\Handlers\BookingExportHandler())->register();

/*
 * Pro's MCP tools. Registering a filter is all this does — the free registrar
 * only asks for classes in toolsets the operator switched on, and MCP itself
 * ships off. See fluent-booking/docs/mcp-server-spec.md.
 */
FluentBookingPro\App\Modules\MCP\PaymentTools::register();
(new FluentBookingPro\App\Hooks\Handlers\BookingNoteHandler())->register();

// Installs FluentHub, which carries the MCP adapter. Free asks for it through
// `fluent_toolkit/can_auto_install`; every Fluent pro plugin registers this.
(new FluentBookingPro\App\Modules\MCP\ToolkitInstaller())->init();

// Booking spam protection: reCAPTCHA (v2/v3) and Cloudflare Turnstile.
(new FluentBookingPro\App\Hooks\Handlers\CaptchaHandler())->register();
