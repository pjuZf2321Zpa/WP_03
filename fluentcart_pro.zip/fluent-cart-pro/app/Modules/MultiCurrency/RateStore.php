<?php

namespace FluentCartPro\App\Modules\MultiCurrency;

use FluentCart\App\Modules\MultiCurrency\Services\BaseCurrency;
use FluentCart\App\Modules\MultiCurrency\Services\CurrencySnapshot;
use FluentCart\App\Modules\MultiCurrency\Services\ExchangeRateService;
use FluentCart\App\Modules\MultiCurrency\Services\MultiCurrencySettings;
use FluentCart\App\Services\DateTime\DateTime;
use FluentCart\Framework\Support\Arr;
use FluentCartPro\App\Modules\MultiCurrency\Database\CurrencyRatesMigrator;
use FluentCartPro\App\Modules\MultiCurrency\Models\CurrencyRate;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Exchange rates: base -> quote, stored append-only in fct_currency_rates.
 * Core resolves rates through fluent_cart/currency/exchange_rate; this store answers it.
 *
 * `rate` = units of the quote (presentment) currency per 1 unit of base.
 */
class RateStore
{
    /** An automated rate that moves more than this from the previous one is held back */
    const SANITY_BAND = 0.10;

    /** @var array<string, CurrencyRate|null> */
    private static $activeRows = [];

    public function register(): void
    {
        // Needs core with multi-currency; Pro can be updated before core
        if (!class_exists(MultiCurrencySettings::class)) {
            return;
        }

        // Older core still reads the table itself
        if (class_exists('FluentCart\App\Models\CurrencyRate')) {
            return;
        }

        // Before providers at 10, so a live feed can still replace the stored rate
        add_filter('fluent_cart/currency/exchange_rate', [$this, 'storedRate'], 5, 2);
        add_action('fluent_cart/currency/prime_rates', [$this, 'primeRates']);
        add_action('fluent_cart/currency/rates_flushed', [$this, 'onRatesFlushed']);
    }

    /**
     * @param array|null $rate
     * @param array $context base, quote, context
     * @return array|null
     */
    public function storedRate($rate, $context = [])
    {
        if (is_array($rate)) {
            return $rate;
        }

        $row = self::activeRow((string) Arr::get($context, 'quote', ''));
        if (!$row) {
            return $rate;
        }

        return [
            'rate'         => CurrencySnapshot::normalizeRate($row->rate),
            'rate_id'      => (int) $row->id,
            'source'       => (string) $row->source,
            'margin'       => '0',
            'effective_at' => (string) $row->effective_at,
        ];
    }

    /**
     * @param array $payload base, quotes
     */
    public function primeRates($payload = []): void
    {
        self::activeRows((array) Arr::get($payload, 'quotes', []));
    }

    public function onRatesFlushed($payload = []): void
    {
        self::flushCache();
    }

    /**
     * The stored rate row in force now for base -> $quote, or null.
     */
    public static function activeRow($quote): ?CurrencyRate
    {
        $quote = strtoupper((string) $quote);
        $base = BaseCurrency::get();
        $key = $base . '>' . $quote;

        if (!array_key_exists($key, self::$activeRows)) {
            self::$activeRows[$key] = null;

            if (CurrencyRatesMigrator::isReady()) {
                self::$activeRows[$key] = CurrencyRate::query()
                    ->where('base', $base)
                    ->where('quote', $quote)
                    ->where('effective_at', '<=', DateTime::gmtNow()->format('Y-m-d H:i:s'))
                    ->orderBy('effective_at', 'DESC')
                    ->orderBy('id', 'DESC')
                    ->first();
            }
        }

        return self::$activeRows[$key];
    }

    /**
     * activeRow() for many quotes, reading uncached ones in a single query.
     *
     * @param string[] $quotes
     * @return array<string, CurrencyRate|null> keyed by upper-cased quote, in input order
     */
    public static function activeRows(array $quotes): array
    {
        $base = BaseCurrency::get();
        $codes = array_values(array_unique(array_map(function ($quote) {
            return strtoupper((string) $quote);
        }, $quotes)));

        $missing = array_values(array_filter($codes, function ($code) use ($base) {
            return !array_key_exists($base . '>' . $code, self::$activeRows);
        }));

        if ($missing) {
            $found = [];

            if (CurrencyRatesMigrator::isReady()) {
                $newest = CurrencyRate::query()
                    ->selectRaw('quote, MAX(effective_at) AS max_effective_at')
                    ->where('base', $base)
                    ->whereIn('quote', $missing)
                    ->where('effective_at', '<=', DateTime::gmtNow()->format('Y-m-d H:i:s'))
                    ->groupBy('quote');

                // Same pick as activeRow(): newest effective_at, then the highest id
                $rows = CurrencyRate::query()
                    ->select('fct_currency_rates.*')
                    ->joinSub($newest, 'newest', function ($join) {
                        $join->on('newest.quote', '=', 'fct_currency_rates.quote')
                            ->on('newest.max_effective_at', '=', 'fct_currency_rates.effective_at');
                    })
                    ->where('fct_currency_rates.base', $base)
                    ->orderBy('fct_currency_rates.id', 'DESC')
                    ->get();

                foreach ($rows as $row) {
                    $quote = strtoupper((string) $row->quote);
                    if (!isset($found[$quote])) {
                        $found[$quote] = $row;
                    }
                }
            }

            foreach ($missing as $code) {
                self::$activeRows[$base . '>' . $code] = $found[$code] ?? null;
            }
        }

        $active = [];
        foreach ($codes as $code) {
            $active[$code] = self::$activeRows[$base . '>' . $code];
        }

        return $active;
    }

    /**
     * Record a new rate for base -> $quote. Never updates an existing row.
     *
     * @param string $quote
     * @param string|float $rate
     * @param string $source 'manual' or a provider slug
     * @param array $args effective_at (GMT), created_by
     * @return CurrencyRate|\WP_Error
     */
    public static function record($quote, $rate, string $source = CurrencySnapshot::SOURCE_MANUAL, array $args = [])
    {
        $quote = strtoupper(sanitize_text_field((string) $quote));
        $base = BaseCurrency::get();
        $source = sanitize_key($source) ?: CurrencySnapshot::SOURCE_MANUAL;

        if (!preg_match('/^[A-Z]{3}$/', $quote) || $quote === $base) {
            return new \WP_Error('invalid_currency', __('A rate needs a currency other than the base currency.', 'fluent-cart-pro'));
        }

        // Validate what will be stored: a positive input below 12 decimals
        // would be saved as 0 and replace a working rate
        $rate = CurrencySnapshot::storableRate($rate);
        if ($rate === null) {
            return new \WP_Error('invalid_rate', __('An exchange rate must be a number greater than zero, with at most 12 digits before the decimal point and 12 after it.', 'fluent-cart-pro'));
        }

        if (!CurrencyRatesMigrator::isReady()) {
            return new \WP_Error('rates_unavailable', __('The exchange rate table is not installed yet. Reload this admin page and try again.', 'fluent-cart-pro'));
        }

        $previous = self::activeRow($quote);

        if ($source !== CurrencySnapshot::SOURCE_MANUAL && $previous && self::movesTooFar($previous->rate, $rate)) {
            fluent_cart_add_log(
                __('Exchange rate held back', 'fluent-cart-pro'),
                sprintf(
                    /* translators: 1: base currency, 2: quote currency, 3: new rate, 4: source, 5: previous rate */
                    __('%1$s to %2$s rate %3$s from %4$s moved more than 10%% from %5$s and was not activated. Prices keep using the previous rate.', 'fluent-cart-pro'),
                    $base,
                    $quote,
                    CurrencySnapshot::normalizeRate($rate),
                    $source,
                    CurrencySnapshot::normalizeRate($previous->rate)
                ),
                'warning',
                ['module_name' => 'activity', 'module_id' => 0]
            );

            do_action('fluent_cart/currency/rate_rejected', [
                'base'     => $base,
                'quote'    => $quote,
                'rate'     => CurrencySnapshot::normalizeRate($rate),
                'source'   => $source,
                'previous' => $previous,
            ]);

            return new \WP_Error('rate_out_of_band', __('The new rate differs from the current one by more than 10% and was not activated.', 'fluent-cart-pro'));
        }

        $row = CurrencyRate::query()->create([
            'base'         => $base,
            'quote'        => $quote,
            'rate'         => CurrencySnapshot::normalizeRate($rate),
            'source'       => $source,
            'effective_at' => Arr::get($args, 'effective_at') ?: DateTime::gmtNow()->format('Y-m-d H:i:s'),
            'created_by'   => Arr::get($args, 'created_by', $source === CurrencySnapshot::SOURCE_MANUAL ? (get_current_user_id() ?: null) : null),
        ]);

        // Through core, so its caches and every other listener drop the old rate too
        ExchangeRateService::flushCache();

        do_action('fluent_cart/currency/rate_changed', [
            'rate'     => $row,
            'previous' => $previous,
        ]);

        return $row;
    }

    /**
     * Newest first.
     *
     * @return CurrencyRate[]
     */
    public static function history($quote, int $limit = 20): array
    {
        if (!CurrencyRatesMigrator::isReady()) {
            return [];
        }

        return CurrencyRate::query()
            ->where('base', BaseCurrency::get())
            ->where('quote', strtoupper((string) $quote))
            ->orderBy('effective_at', 'DESC')
            ->orderBy('id', 'DESC')
            ->limit(min(max($limit, 1), 100))
            ->get()
            ->all();
    }

    public static function isStale(?CurrencyRate $row, int $maxAgeHours): bool
    {
        if (!$row || !$row->effective_at) {
            return true;
        }

        return strtotime($row->effective_at . ' UTC') < time() - $maxAgeHours * HOUR_IN_SECONDS;
    }

    public static function movesTooFar($previous, $next): bool
    {
        $previous = (float) $previous;
        if ($previous <= 0) {
            return false;
        }

        $band = (float) apply_filters('fluent_cart/currency/rate_sanity_band', self::SANITY_BAND);

        return abs((float) $next - $previous) / $previous > $band;
    }

    public static function flushCache(): void
    {
        self::$activeRows = [];
    }
}
