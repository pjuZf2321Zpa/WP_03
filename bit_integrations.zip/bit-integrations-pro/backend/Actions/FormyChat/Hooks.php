<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Actions\FormyChat\FormyChatRecordHelper;
use BitApps\IntegrationsPro\Config;
use BitApps\IntegrationsPro\Core\Util\Hooks;

Hooks::filter(Config::withFreePrefix('formy_chat_create_lead'), [FormyChatRecordHelper::class, 'createLead'], 10, 3);
