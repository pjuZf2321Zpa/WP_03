<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

function masterstudy_lms_notifications_table_query() {
	global $wpdb;

	$table_name      = masterstudy_lms_notifications_table_name( $wpdb );
	$charset_collate = $wpdb->get_charset_collate();

	$sql = "CREATE TABLE $table_name (
		id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
		trigger_key VARCHAR(100) NOT NULL,
		title TEXT NOT NULL,
		message TEXT NOT NULL,
		context_label VARCHAR(255) DEFAULT '',
		course_id BIGINT(20) UNSIGNED DEFAULT 0,
		item_id BIGINT(20) UNSIGNED DEFAULT 0,
		assignment_id BIGINT(20) UNSIGNED DEFAULT 0,
		user_assignment_id BIGINT(20) UNSIGNED DEFAULT 0,
		actor_user_id BIGINT(20) UNSIGNED DEFAULT 0,
		click_action VARCHAR(100) DEFAULT '',
		click_url TEXT,
		dedupe_key VARCHAR(191) DEFAULT NULL,
		metadata LONGTEXT,
		created_at_gmt DATETIME NOT NULL,
		PRIMARY KEY (id),
		UNIQUE KEY dedupe_key (dedupe_key),
		INDEX idx_trigger_key (trigger_key),
		INDEX idx_course_id (course_id),
		INDEX idx_item_id (item_id),
		INDEX idx_created_at_gmt (created_at_gmt)
	) $charset_collate;";

	require_once ABSPATH . 'wp-admin/includes/upgrade.php';

	dbDelta( $sql );
}
