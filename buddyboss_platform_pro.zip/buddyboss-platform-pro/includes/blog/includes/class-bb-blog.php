<?php
/**
 * BuddyBoss Pro Blog.
 *
 * @since 3.1.0
 * @package BuddyBossPro
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

/**
 * Setup the bb blog class.
 *
 * @since 3.1.0
 */
class BB_Blog {

	/**
	 * Class instance.
	 *
	 * @var $instance
	 */
	public static $instance;

	/**
	 * Unique ID for the blog module.
	 *
	 * @var string
	 *
	 * @since 3.1.0
	 */
	public $id = 'blog';

	/**
	 * Blog Constructor.
	 *
	 * @since 3.1.0
	 */
	public function __construct() {
		// Include the code.
		$this->includes();
		$this->setup_actions();
	}

	/**
	 * Get the instance of the class.
	 *
	 * @since 3.1.0
	 *
	 * @return BB_Blog
	 */
	public static function instance() {
		if ( is_null( self::$instance ) ) {
			$class_name     = __CLASS__;
			self::$instance = new $class_name();
		}

		return self::$instance;
	}

	/**
	 * Include required files.
	 *
	 * @since 3.1.0
	 */
	private function includes() {
		$slashed_path = trailingslashit( bb_platform_pro()->blog_dir );

		require_once $slashed_path . 'bb-blog-functions.php';

		// Settings 2.0 enrichment: unlocks the Post Settings pro_only fields
		// (Bookmarking, Subscriptions) when licensed. Always loaded — the filter
		// self-gates on feature id, field name and license, and must be live in
		// admin regardless of whether either option is currently enabled.
		require_once $slashed_path . 'bb-blog-settings.php';

		// The `post` bookmark type is registered unconditionally: Platform's
		// engine must be able to hydrate an existing bookmark row (in a REST
		// response, in the App sync, in a cleanup pass) even while the web
		// bookmarking option is off.
		if ( class_exists( 'BB_Bookmark_Type' ) ) {
			require_once $slashed_path . 'includes/class-bb-blog-bookmark-type.php';
			BB_Blog_Bookmark_Type::instance();
		}

		// App sync: always loaded, never gated on the bookmarking option. The
		// enable-setting listeners must be live even while web bookmarking is
		// OFF — that is exactly the state from which the app can turn it on.
		require_once $slashed_path . 'includes/class-bb-blog-bookmarks-app-sync.php';
		BB_Blog_Bookmarks_App_Sync::instance();

		if ( bp_get_option( 'bb_blog_enable_bookmarking', 0 ) ) {
			// Frontend (button, profile subnav, screen): required whenever the
			// option is on, same as the storage/AJAX file above -- calling the
			// full gate (`bb_blog_pro_is_bookmarking_enabled()`) here would be
			// too early (this runs during `bp_setup_components`, before the
			// Settings 2.0 feature registry class is loaded). Every hook
			// registered by this file re-checks the full gate itself at the
			// time it actually runs (bp_setup_nav / wp_enqueue_scripts / etc.).
			require_once $slashed_path . 'bb-blog-bookmarks-frontend.php';
		}

		// Subscriptions engine type + publish fan-out: required whenever the
		// option is on, same rationale as the bookmarking files above -- this
		// runs during `bp_setup_components`, before the Settings 2.0 feature
		// registry class is loaded, so only the raw option can be checked
		// here. The notification/subscription type registers regardless of
		// the full gate (mirrors how forum subscriptions stay registered
		// while gated on `bbp_is_subscriptions_active()`); the full gate
		// (`bb_blog_pro_is_subscriptions_enabled()`) is re-checked at
		// runtime inside the `bb_is_enabled_subscription` filter, the
		// subscription type's `validate_callback`, and the publish trigger.
		if ( bp_get_option( 'bb_blog_enable_subscriptions', 0 ) ) {
			require_once $slashed_path . 'includes/class-bb-blog-notification.php';

			// Instantiated here (not at the class file's scope) so the
			// notification/email/subscription types register only while the
			// option is on — a bare class_exists() autoload can't bootstrap it.
			BB_Blog_Notification::instance();

			require_once $slashed_path . 'bb-blog-subscriptions.php';
			require_once $slashed_path . 'includes/class-bb-rest-blog-subscriptions-endpoint.php';

			// Frontend (category archive subscribe button): required whenever
			// the option is on, same rationale as the bookmarking frontend file
			// above -- every hook it registers re-checks the full gate
			// (`bb_blog_pro_is_subscriptions_enabled()`) itself at the time it
			// actually runs (the render callbacks / wp_enqueue_scripts).
			require_once $slashed_path . 'bb-blog-subscriptions-frontend.php';
		}
	}

	/**
	 * Setup actions for the blog module.
	 *
	 * @since 3.1.0
	 */
	public function setup_actions() {
		if ( bp_get_option( 'bb_blog_enable_subscriptions', 0 ) ) {
			add_action( 'rest_api_init', array( $this, 'register_rest_routes' ) );
		}

		/**
		 * Fires after the blog module has finished setting up.
		 *
		 * @since 3.1.0
		 */
		do_action( 'bb_blog_pro_loaded' );
	}

	/**
	 * Register the blog subscriptions REST controller.
	 *
	 * @since 3.1.0
	 *
	 * @return void
	 */
	public function register_rest_routes() {
		if ( ! class_exists( 'BB_REST_Blog_Subscriptions_Endpoint' ) ) {
			return;
		}

		$controller = new BB_REST_Blog_Subscriptions_Endpoint();
		$controller->register_routes();
	}
}
