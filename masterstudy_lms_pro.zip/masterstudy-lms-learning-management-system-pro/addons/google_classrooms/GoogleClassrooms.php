<?php

namespace MasterStudy\Lms\Pro\addons\google_classrooms;

use MasterStudy\Lms\Plugin;

class GoogleClassrooms implements \MasterStudy\Lms\Plugin\Addon {

	public function get_name(): string {
		return Plugin\Addons::GOOGLE_CLASSROOMS;
	}

	public function register( Plugin $plugin ): void {
		$plugin->get_router()->load_routes( __DIR__ . '/Admin/routes.php' );
	}
}
