<?php
/**
 * Shared recipe template data.
 *
 * Callers set the local $aipkit_translate_labels flag: registry false, UI fallback true.
 * Each require returns fresh definitions without loading registry or storage classes.
 */
if (!defined('ABSPATH')) {
    exit;
}

return [
    [
        'template_slug' => 'form_submitted_to_slack_message',
        'label' => $aipkit_translate_labels ? __('AI form submission to Slack', 'gpt3-ai-content-generator') : 'AI form submission to Slack',
        'app_slug' => 'slack',
        'action_slug' => 'slack_message_create',
        'event_name' => 'form.submitted',
        'object_type' => 'lead',
        'default_mapping' => [
            'fields' => [
                ['target_field' => 'title', 'source_path' => 'data.form.name'],
                ['target_field' => 'body', 'source_path' => 'data.response.text'],
            ],
        ],
        'tags' => ['lead', 'notifications'],
    ],
    [
        'template_slug' => 'form_submitted_to_hubspot_contact',
        'label' => $aipkit_translate_labels ? __('AI form submission to HubSpot contact', 'gpt3-ai-content-generator') : 'AI form submission to HubSpot contact',
        'app_slug' => 'hubspot',
        'action_slug' => 'hubspot_contact_upsert',
        'event_name' => 'form.submitted',
        'object_type' => 'contact',
        'default_mapping' => [
            'fields' => [
                ['target_field' => 'email', 'source_path' => 'data.inputs.email'],
                ['target_field' => 'firstname', 'source_path' => 'data.inputs.first_name'],
                ['target_field' => 'lastname', 'source_path' => 'data.inputs.last_name'],
            ],
        ],
        'tags' => ['crm', 'lead'],
    ],
    [
        'template_slug' => 'chatbot_form_submitted_to_hubspot_contact',
        'label' => $aipkit_translate_labels ? __('Chatbot form submission to HubSpot contact', 'gpt3-ai-content-generator') : 'Chatbot form submission to HubSpot contact',
        'app_slug' => 'hubspot',
        'action_slug' => 'hubspot_contact_upsert',
        'event_name' => 'chatbot.form_submitted',
        'object_type' => 'contact',
        'default_mapping' => [
            'fields' => [
                ['target_field' => 'email', 'source_path' => 'data.inputs.email'],
                ['target_field' => 'firstname', 'source_path' => 'data.inputs.first_name'],
                ['target_field' => 'lastname', 'source_path' => 'data.inputs.last_name'],
                ['target_field' => 'phone', 'source_path' => 'data.inputs.phone'],
                ['target_field' => 'company', 'source_path' => 'data.inputs.company'],
            ],
        ],
        'tags' => ['crm', 'lead', 'chatbot'],
    ],
    [
        'template_slug' => 'chatbot_form_submitted_to_slack_message',
        'label' => $aipkit_translate_labels ? __('Chatbot form submission to Slack', 'gpt3-ai-content-generator') : 'Chatbot form submission to Slack',
        'app_slug' => 'slack',
        'action_slug' => 'slack_message_create',
        'event_name' => 'chatbot.form_submitted',
        'object_type' => 'lead',
        'default_mapping' => [
            'fields' => [
                ['target_field' => 'title', 'source_path' => 'data.form.name'],
                ['target_field' => 'body', 'source_path' => 'data.summary'],
            ],
        ],
        'tags' => ['lead', 'notifications', 'chatbot'],
    ],
    [
        'template_slug' => 'content_generated_to_notion_page',
        'label' => $aipkit_translate_labels ? __('Generated content to Notion page', 'gpt3-ai-content-generator') : 'Generated content to Notion page',
        'app_slug' => 'notion',
        'action_slug' => 'notion_page_create',
        'event_name' => 'content.generated',
        'object_type' => 'content',
        'default_mapping' => [
            'fields' => [
                ['target_field' => 'title', 'source_path' => 'data.title'],
                ['target_field' => 'content', 'source_path' => 'data.content'],
            ],
        ],
        'tags' => ['content', 'knowledge'],
    ],
    [
        'template_slug' => 'content_generated_to_slack_message',
        'label' => $aipkit_translate_labels ? __('Generated content to Slack', 'gpt3-ai-content-generator') : 'Generated content to Slack',
        'app_slug' => 'slack',
        'action_slug' => 'slack_message_create',
        'event_name' => 'content.generated',
        'object_type' => 'content',
        'default_mapping' => [
            'fields' => [
                ['target_field' => 'title', 'source_path' => 'data.title'],
                ['target_field' => 'body', 'source_path' => 'data.content'],
            ],
        ],
        'tags' => ['content', 'notifications'],
    ],
    [
        'template_slug' => 'task_item_completed_to_slack_message',
        'label' => $aipkit_translate_labels ? __('Completed task to Slack', 'gpt3-ai-content-generator') : 'Completed task to Slack',
        'app_slug' => 'slack',
        'action_slug' => 'slack_message_create',
        'event_name' => 'task.item_completed',
        'object_type' => 'task',
        'default_mapping' => [
            'fields' => [
                ['target_field' => 'title', 'source_path' => 'data.task.name'],
                ['target_field' => 'body', 'source_path' => 'data.result.message'],
            ],
        ],
        'tags' => ['automation', 'notifications'],
    ],
    [
        'template_slug' => 'image_generated_to_notion_database_item',
        'label' => $aipkit_translate_labels ? __('Generated image to Notion', 'gpt3-ai-content-generator') : 'Generated image to Notion',
        'app_slug' => 'notion',
        'action_slug' => 'notion_database_item_create',
        'event_name' => 'image.generated',
        'object_type' => 'asset',
        'default_mapping' => [
            'fields' => [
                ['target_field' => 'title', 'source_path' => 'data.prompt'],
                ['target_field' => 'asset_url', 'source_path' => 'data.outputs.images.0.media_library_url'],
            ],
        ],
        'tags' => ['assets', 'creative'],
    ],
    [
        'template_slug' => 'kb_source_indexed_to_slack_message',
        'label' => $aipkit_translate_labels ? __('Indexed KB source to Slack', 'gpt3-ai-content-generator') : 'Indexed KB source to Slack',
        'app_slug' => 'slack',
        'action_slug' => 'slack_message_create',
        'event_name' => 'kb.source_indexed',
        'object_type' => 'knowledge_base',
        'default_mapping' => [
            'fields' => [
                ['target_field' => 'title', 'source_path' => 'data.source.post_title'],
                ['target_field' => 'body', 'source_path' => 'data.message'],
            ],
        ],
        'tags' => ['knowledge_base', 'notifications'],
    ],
    [
        'template_slug' => 'chat_user_message_to_slack_message',
        'label' => $aipkit_translate_labels ? __('Chat user message to Slack', 'gpt3-ai-content-generator') : 'Chat user message to Slack',
        'app_slug' => 'slack',
        'action_slug' => 'slack_message_create',
        'event_name' => 'chatbot.user_message_submitted',
        'object_type' => 'message',
        'default_mapping' => [
            'fields' => [
                ['target_field' => 'title', 'source_path' => 'data.bot.name'],
                ['target_field' => 'body', 'source_path' => 'data.message.text'],
            ],
        ],
        'tags' => ['chatbot', 'questions', 'notifications'],
    ],
    [
        'template_slug' => 'chat_response_to_slack_message',
        'label' => $aipkit_translate_labels ? __('Chat response to Slack', 'gpt3-ai-content-generator') : 'Chat response to Slack',
        'app_slug' => 'slack',
        'action_slug' => 'slack_message_create',
        'event_name' => 'chatbot.response_generated',
        'object_type' => 'response',
        'default_mapping' => [
            'fields' => [
                ['target_field' => 'title', 'source_path' => 'data.bot.name'],
                ['target_field' => 'body', 'source_path' => 'data.response.text'],
            ],
        ],
        'tags' => ['chatbot', 'responses', 'notifications'],
    ],
    [
        'template_slug' => 'chat_feedback_to_notion_database_item',
        'label' => $aipkit_translate_labels ? __('Chat feedback to Notion', 'gpt3-ai-content-generator') : 'Chat feedback to Notion',
        'app_slug' => 'notion',
        'action_slug' => 'notion_database_item_create',
        'event_name' => 'chatbot.fb_submitted',
        'object_type' => 'feedback',
        'default_mapping' => [
            'fields' => [
                ['target_field' => 'feedback', 'source_path' => 'data.feedback'],
                ['target_field' => 'bot_name', 'source_path' => 'data.bot.name'],
            ],
        ],
        'tags' => ['feedback', 'chatbot'],
    ],
    [
        'template_slug' => 'form_submitted_to_pipedrive_person',
        'label' => $aipkit_translate_labels ? __('AI form submission to Pipedrive person', 'gpt3-ai-content-generator') : 'AI form submission to Pipedrive person',
        'app_slug' => 'pipedrive',
        'action_slug' => 'pipedrive_person_upsert',
        'event_name' => 'form.submitted',
        'object_type' => 'contact',
        'default_mapping' => [
            'fields' => [
                ['target_field' => 'name', 'source_path' => 'data.inputs.name'],
                ['target_field' => 'email', 'source_path' => 'data.inputs.email'],
                ['target_field' => 'phone', 'source_path' => 'data.inputs.phone'],
                ['target_field' => 'org_name', 'source_path' => 'data.inputs.company'],
            ],
        ],
        'tags' => ['crm', 'lead'],
    ],
    [
        'template_slug' => 'content_generated_to_zapier_webhook',
        'label' => $aipkit_translate_labels ? __('Generated content to Zapier', 'gpt3-ai-content-generator') : 'Generated content to Zapier',
        'app_slug' => 'zapier',
        'action_slug' => 'zapier_webhook_trigger',
        'event_name' => 'content.generated',
        'object_type' => 'content',
        'default_mapping' => [
            'fields' => [
                ['target_field' => 'title', 'source_path' => 'data.title'],
                ['target_field' => 'body', 'source_path' => 'data.content'],
                ['target_field' => 'source_url', 'source_path' => 'data.post.url'],
            ],
        ],
        'tags' => ['content', 'automation'],
    ],
    [
        'template_slug' => 'task_item_completed_to_make_webhook',
        'label' => $aipkit_translate_labels ? __('Completed task to Make', 'gpt3-ai-content-generator') : 'Completed task to Make',
        'app_slug' => 'make',
        'action_slug' => 'make_webhook_trigger',
        'event_name' => 'task.item_completed',
        'object_type' => 'task',
        'default_mapping' => [
            'fields' => [
                ['target_field' => 'title', 'source_path' => 'data.task.name'],
                ['target_field' => 'body', 'source_path' => 'data.result.message'],
            ],
        ],
        'tags' => ['automation', 'webhook'],
    ],
    [
        'template_slug' => 'chat_session_started_to_n8n_webhook',
        'label' => $aipkit_translate_labels ? __('Chat session started to n8n', 'gpt3-ai-content-generator') : 'Chat session started to n8n',
        'app_slug' => 'n8n',
        'action_slug' => 'n8n_webhook_trigger',
        'event_name' => 'chatbot.session_started',
        'object_type' => 'conversation',
        'default_mapping' => [
            'fields' => [
                ['target_field' => 'title', 'source_path' => 'data.bot.name'],
                ['target_field' => 'body', 'source_path' => 'data.message.text'],
            ],
        ],
        'tags' => ['chatbot', 'session', 'automation'],
    ],
    [
        'template_slug' => 'chat_feedback_to_n8n_webhook',
        'label' => $aipkit_translate_labels ? __('Chat feedback to n8n', 'gpt3-ai-content-generator') : 'Chat feedback to n8n',
        'app_slug' => 'n8n',
        'action_slug' => 'n8n_webhook_trigger',
        'event_name' => 'chatbot.fb_submitted',
        'object_type' => 'feedback',
        'default_mapping' => [
            'fields' => [
                ['target_field' => 'title', 'source_path' => 'data.bot.name'],
                ['target_field' => 'body', 'source_path' => 'data.feedback'],
            ],
        ],
        'tags' => ['feedback', 'automation'],
    ],
];
