<?php

if (!defined('ABSPATH')) {
    die('You are not allowed to call this page directly.');
}

class MeprView
{
    /**
     * Get the file for a given slug.
     *
     * @param string $slug  The slug of the file.
     * @param array  $paths The paths to search for the file.
     *
     * @return string The path to the file.
     */
    public static function file($slug, $paths = [])
    {
        $paths = (empty($paths) ? self::paths() : $paths);
        $find  = $slug . '.php';

        if (!preg_match('#^/#', $find)) {
            $find = '/' . $find;
        }

        // Since we're including our default path, the file will be
        // found so we're not doing any validation for that here.
        foreach ($paths as $path) {
            if (file_exists($path . $find)) {
                return $path . $find;
            }
        }

        return false;
    }

    /**
     * Used to get a string of a view. We can use this when calling a file to
     * pass all the locally defined variables as the args variable:
     *
     * MeprView::get_string('mycoolstuff/what', get_defined_vars());
     *
     * @param string $slug  The slug of the view.
     * @param array  $vars  The variables to pass to the view.
     * @param array  $paths The paths to search for the view.
     *
     * @return string|null
     */
    public static function get_string($slug, $vars = [], $paths = [])
    {
        $paths = MeprHooks::apply_filters('mepr_view_paths_get_string_' . $slug, $paths, $slug, $vars);
        $paths = MeprHooks::apply_filters('mepr_view_paths_get_string', $paths, $slug, $vars);

        $template_part_slug = 'memberpress/' . dirname($slug);
        $template_part_name = basename($slug);

        // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHookname
        do_action("get_template_part_{$template_part_slug}", $template_part_slug, $template_part_name); // Bypass MeprHooks for this one.

        $file = self::file($slug, $paths);

        if (!$file) {
            return null;
        }

        // Render inside a closure that declares no parameters and creates no
        // locals: func_get_arg() reads the file path and vars without binding
        // any names, so the view scope contains exactly the caller's variables
        // and no name is reserved for internal use.
        $view = self::capture(static function () use ($file, $vars) {
            (static function () {
                extract(func_get_arg(1), EXTR_SKIP);
                require func_get_arg(0);
            })($file, $vars);
        });

        $view = MeprHooks::apply_filters('mepr_view_get_string_' . $slug, $view, $vars); // Slug specific filter.
        $view = MeprHooks::apply_filters('mepr_view_get_string', $view, $slug, $vars); // General filter.

        return $view;
    }

    /**
     * Used to render a view. We can use this when calling a file to
     * pass all the locally defined variables as the args variable:
     *
     * MeprView::render('mycoolstuff/what', get_defined_vars());
     *
     * @param string $slug  The slug of the view.
     * @param array  $vars  The variables to pass to the view.
     * @param array  $paths The paths to search for the view.
     *
     * @return string The string of the view.
     */
    public static function render($slug, $vars = [], $paths = [])
    {
        $view = self::get_string($slug, $vars, $paths);

        echo $view; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped

        return $view;
    }

    /**
     * Opens an output buffer owned by the caller and returns the buffer
     * level from immediately before it opened. Pass the returned level to
     * capture_end() in a finally block to close only this buffer, even if
     * the code that runs in between opens further buffers of its own
     * without closing them.
     *
     * If buffering fails to start, no buffer is opened and the paired
     * capture_end() call safely returns without capturing.
     *
     * @return integer The output buffer level owned by the caller.
     */
    public static function capture_start(): int
    {
        $owned_level = ob_get_level();
        ob_start();

        return $owned_level;
    }

    /**
     * Closes the buffer owned by the matching capture_start() call.
     *
     * Buffers left open above it are closed and their raw contents kept, without running their handlers' flush.
     * A non-removable one stops the unwind and leaves the owned buffer open to PHP's shutdown flush.
     * A nested handler that throws while closing is logged, not allowed to replace the throwable in flight.
     *
     * @param integer $owned_level The level returned by capture_start().
     *
     * @return string The captured buffer contents, or an empty string if
     *                the owned buffer could not be reached.
     */
    public static function capture_end(int $owned_level): string
    {
        $owned_level = max(0, $owned_level);

        while (ob_get_level() > $owned_level + 1) {
            $level_before = ob_get_level();
            $contents     = (string) ob_get_contents();

            try {
                /*
                 * A handler that is not removable cannot be closed. Stop
                 * rather than spin, and leave the buffers in place.
                 */
                if (!ob_end_clean()) {
                    break;
                }
            } catch (\Throwable $cleanup_failure) {
                /*
                 * A nested handler threw while closing. It must not
                 * replace the throwable already in flight, so swallow it
                 * and let the progress check below decide whether to
                 * keep unwinding. Logged for visibility since it would
                 * otherwise vanish silently; wrapped so logging itself
                 * can never introduce a second failure here.
                 */
                try {
                    MeprUtils::debug_log(
                        'MeprView::capture_end() nested output handler threw while closing: ' . $cleanup_failure->getMessage(),
                        [$cleanup_failure]
                    );
                } catch (\Throwable $logging_failure) {
                    // Logging must never fail this function.
                }
            }

            if (ob_get_level() >= $level_before) {
                break;
            }

            // A flush would run the handler, which can send headers (ob_gzhandler) for output we may discard.
            echo $contents; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
        }

        if (ob_get_level() !== $owned_level + 1) {
            return '';
        }

        try {
            $captured = ob_get_clean();
        } catch (\Throwable $owned_close_failure) {
            /*
             * The owned buffer's own handler threw while closing. It must
             * not replace the throwable already in flight (if any), so
             * swallow it and log for visibility, matching the nested-buffer
             * handling above.
             */
            try {
                MeprUtils::debug_log(
                    'MeprView::capture_end() owned output handler threw while closing: ' . $owned_close_failure->getMessage(),
                    [$owned_close_failure]
                );
            } catch (\Throwable $logging_failure) {
                // Logging must never fail this function.
            }

            return '';
        }

        return is_string($captured) ? $captured : '';
    }

    /**
     * Runs a callable inside a buffer owned by the caller and returns its output.
     *
     * The buffer is closed whether the callable returns or throws. Output from buffers the
     * callable leaves open is folded into it; on a throw, all of it is discarded.
     *
     * @param callable $render The callable to run inside the buffer.
     *
     * @return string The captured buffer contents.
     *
     * @throws \Throwable Whatever $render() throws, after the buffer is closed.
     */
    public static function capture(callable $render): string
    {
        $owned_level = self::capture_start();

        try {
            $render();
        } finally {
            $captured = self::capture_end($owned_level);
        }

        return $captured;
    }

    /**
     * Get the paths for the views.
     *
     * @return array The paths for the views.
     */
    public static function paths()
    {
        $paths = [];

        $template_path   = get_template_directory();
        $stylesheet_path = get_stylesheet_directory();

        // Put child theme's first if one's being used.
        if ($stylesheet_path !== $template_path) {
            $paths[] = "{$stylesheet_path}/memberpress";
        }

        $paths[] = "{$template_path}/memberpress";
        $paths[] = MEPR_BRAND_VIEWS_PATH;
        $paths[] = MEPR_VIEWS_PATH;

        return MeprHooks::apply_filters('mepr_view_paths', $paths);
    }
}
