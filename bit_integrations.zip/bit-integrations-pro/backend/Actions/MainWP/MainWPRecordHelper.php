<?php

namespace BitApps\IntegrationsPro\Actions\MainWP;

use Exception;

if (!\defined('ABSPATH')) {
    exit;
}

final class MainWPRecordHelper
{
    private const MAINWP_DB_CLASS = '\MainWP\Dashboard\MainWP_DB';

    private const MAINWP_SYNC_CLASS = '\MainWP\Dashboard\MainWP_Sync';

    private const MAINWP_CONNECT_CLASS = '\MainWP\Dashboard\MainWP_Connect';

    /**
     * Cron hook that processes queued sync batches in the background.
     */
    public const SYNC_BATCH_HOOK = 'bit_integrations_pro_mainwp_sync_batch';

    /**
     * Number of sites synced per request before the rest are offloaded to wp-cron.
     */
    private const SYNC_BATCH_SIZE = 10;

    /**
     * Runtime cache for class_exists checks.
     *
     * @var array<string, bool>
     */
    private static $classAvailability = [];

    private static $encodedPayloadCache = [];

    public static function syncSite($response, $fieldData, $utilities = [], $integrationDetails = null): array
    {
        $siteData = self::resolveWebsiteData(
            $fieldData,
            self::MAINWP_SYNC_CLASS,
            __('MainWP Sync class not found', 'bit-integrations-pro')
        );

        if (isset($siteData['error'])) {
            return $siteData['error'];
        }

        $result = \MainWP\Dashboard\MainWP_Sync::sync_website($siteData['website']);

        if (is_wp_error($result)) {
            return self::errorResponse($result->get_error_message());
        }

        if ($result) {
            return self::successResponse(__('Site synced successfully', 'bit-integrations-pro'));
        }

        return self::errorResponse(__('Site sync failed', 'bit-integrations-pro'));
    }

    public static function syncAllSites($response, $fieldData, $utilities = [], $integrationDetails = null): array
    {
        $activeError = self::ensureActive();
        if ($activeError) {
            return $activeError;
        }

        $syncClassError = self::ensureClassAvailable(
            self::MAINWP_SYNC_CLASS,
            __('MainWP Sync class not found', 'bit-integrations-pro')
        );
        if ($syncClassError) {
            return $syncClassError;
        }

        $websites = \MainWP\Dashboard\MainWP_DB::instance()->get_sites();
        if (empty($websites)) {
            return self::successResponse(__('No sites found to sync', 'bit-integrations-pro'));
        }

        $siteIds = [];
        foreach ($websites as $website) {
            if (!empty($website->id)) {
                $siteIds[] = (int) $website->id;
            }
        }

        // Sync the first batch in this request; queue the rest to wp-cron so large
        // networks don't hit request timeouts or exhaust memory in a single loop.
        $batches    = array_chunk($siteIds, self::SYNC_BATCH_SIZE);
        $firstBatch = array_shift($batches) ?: [];
        $results    = self::runSyncBatch($firstBatch);

        $queued = 0;
        foreach ($batches as $index => $batch) {
            // Stagger queued batches so cron processes them one chunk at a time.
            wp_schedule_single_event(
                time() + (($index + 1) * MINUTE_IN_SECONDS),
                self::SYNC_BATCH_HOOK,
                [$batch]
            );
            $queued += \count($batch);
        }

        if ($queued > 0) {
            return self::successResponse(
                \sprintf(
                    /* translators: 1: sites synced now, 2: sites queued for background sync */
                    __('Synced %1$d sites; %2$d more queued for background sync', 'bit-integrations-pro'),
                    \count($firstBatch),
                    $queued
                ),
                $results
            );
        }

        return self::successResponse(__('All sites synced', 'bit-integrations-pro'), $results);
    }

    /**
     * wp-cron callback: sync a queued batch of sites by id.
     *
     * @param mixed $siteIds
     */
    public static function processSyncBatch($siteIds): void
    {
        if (!\is_array($siteIds) || empty($siteIds)) {
            return;
        }

        self::runSyncBatch($siteIds);
    }

    public static function createPost($response, $fieldData, $utilities = [], $integrationDetails = null): array
    {
        $siteData = self::resolveWebsiteData(
            $fieldData,
            self::MAINWP_CONNECT_CLASS,
            __('MainWP Connect class not found', 'bit-integrations-pro')
        );
        if (isset($siteData['error'])) {
            return $siteData['error'];
        }

        if (empty($fieldData['post_title'])) {
            return self::errorResponse(__('Post title is required', 'bit-integrations-pro'));
        }

        $postData = $fieldData;
        unset($postData['site_id']);

        if (empty($postData['post_type'])) {
            $postData['post_type'] = 'post';
        }

        if (empty($postData['post_status'])) {
            $postData['post_status'] = 'draft';
        }

        $payload = self::buildPostPayload($postData);

        $request = self::callConnect($siteData['website'], 'newpost', $payload);
        if (isset($request['error'])) {
            return $request['error'];
        }

        return self::successResponse(__('Post created successfully', 'bit-integrations-pro'), $request['data']);
    }

    public static function updatePost($response, $fieldData, $utilities = [], $integrationDetails = null): array
    {
        $siteData = self::resolveWebsiteData(
            $fieldData,
            self::MAINWP_CONNECT_CLASS,
            __('MainWP Connect class not found', 'bit-integrations-pro')
        );
        if (isset($siteData['error'])) {
            return $siteData['error'];
        }

        $postId = (int) ($fieldData['post_id'] ?? 0);

        if (!$postId) {
            return self::errorResponse(__('Post ID is required', 'bit-integrations-pro'));
        }

        $postData = $fieldData;
        unset($postData['site_id'], $postData['post_id']);
        $postData['ID'] = $postId;

        $payload = self::buildPostPayload($postData);

        $request = self::callConnect($siteData['website'], 'newpost', $payload);
        if (isset($request['error'])) {
            return $request['error'];
        }

        return self::successResponse(__('Post updated successfully', 'bit-integrations-pro'), $request['data']);
    }

    public static function deletePost($response, $fieldData, $utilities = [], $integrationDetails = null): array
    {
        $siteData = self::resolveWebsiteData(
            $fieldData,
            self::MAINWP_CONNECT_CLASS,
            __('MainWP Connect class not found', 'bit-integrations-pro')
        );
        if (isset($siteData['error'])) {
            return $siteData['error'];
        }

        $postId = (int) ($fieldData['post_id'] ?? 0);

        if (!$postId) {
            return self::errorResponse(__('Post ID is required', 'bit-integrations-pro'));
        }

        $request = self::callConnect(
            $siteData['website'],
            'post_action',
            ['action' => 'delete', 'id' => $postId]
        );
        if (isset($request['error'])) {
            return $request['error'];
        }

        return self::successResponse(__('Post deleted successfully', 'bit-integrations-pro'), $request['data']);
    }

    public static function activatePlugin($response, $fieldData, $utilities = [], $integrationDetails = null): array
    {
        return self::performPluginAction('activate', $fieldData);
    }

    public static function deactivatePlugin($response, $fieldData, $utilities = [], $integrationDetails = null): array
    {
        return self::performPluginAction('deactivate', $fieldData);
    }

    public static function createUser($response, $fieldData, $utilities = [], $integrationDetails = null): array
    {
        $siteData = self::resolveWebsiteData(
            $fieldData,
            self::MAINWP_CONNECT_CLASS,
            __('MainWP Connect class not found', 'bit-integrations-pro')
        );
        if (isset($siteData['error'])) {
            return $siteData['error'];
        }

        if (empty($fieldData['user_login'])) {
            return self::errorResponse(__('Username is required', 'bit-integrations-pro'));
        }

        if (empty($fieldData['user_email'])) {
            return self::errorResponse(__('User email is required', 'bit-integrations-pro'));
        }

        $userData = $fieldData;
        unset($userData['site_id']);

        $payload = [
            'new_user'      => base64_encode(wp_json_encode($userData)), // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions
            'send_password' => 0,
        ];

        $request = self::callConnect($siteData['website'], 'newuser', $payload);
        if (isset($request['error'])) {
            return $request['error'];
        }

        return self::successResponse(__('User created successfully', 'bit-integrations-pro'), $request['data']);
    }

    private static function isActive(): bool
    {
        return self::classExistsCached(self::MAINWP_DB_CLASS);
    }

    private static function getWebsite(int $siteId)
    {
        return \MainWP\Dashboard\MainWP_DB::instance()->get_website_by_id($siteId);
    }

    /**
     * Sync a batch of sites by id and collect per-site results.
     *
     * @param array<int> $siteIds
     *
     * @return array<int, array{id: int, url: string, synced: bool}>
     */
    private static function runSyncBatch(array $siteIds): array
    {
        if (empty($siteIds) || !self::isActive() || !self::classExistsCached(self::MAINWP_SYNC_CLASS)) {
            return [];
        }

        $results = [];
        foreach ($siteIds as $siteId) {
            $website = self::getWebsite((int) $siteId);
            if (empty($website)) {
                continue;
            }

            $syncResult = \MainWP\Dashboard\MainWP_Sync::sync_website($website);
            $results[] = [
                'id'     => (int) $siteId,
                'url'    => $website->url ?? '',
                'synced' => !is_wp_error($syncResult) && (bool) $syncResult,
            ];
        }

        return $results;
    }

    private static function encode($value): string
    {
        return base64_encode(wp_json_encode($value)); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions
    }

    private static function performPluginAction(string $action, array $fieldData): array
    {
        $siteData = self::resolveWebsiteData(
            $fieldData,
            self::MAINWP_CONNECT_CLASS,
            __('MainWP Connect class not found', 'bit-integrations-pro')
        );
        if (isset($siteData['error'])) {
            return $siteData['error'];
        }

        if (empty($fieldData['plugin_slug'])) {
            return self::errorResponse(__('Plugin slug is required', 'bit-integrations-pro'));
        }

        $request = self::callConnect(
            $siteData['website'],
            'plugin_action',
            ['action' => $action, 'plugin' => $fieldData['plugin_slug']]
        );
        if (isset($request['error'])) {
            return $request['error'];
        }

        $message = 'activate' === $action
            ? __('Plugin activated successfully', 'bit-integrations-pro')
            : __('Plugin deactivated successfully', 'bit-integrations-pro');

        return self::successResponse($message, $request['data']);
    }

    private static function buildPostPayload(array $postData): array
    {
        return [
            'new_post'            => self::encode($postData),
            'post_custom'         => self::encodedEmptyArray(),
            'post_featured_image' => null,
            'featured_image_data' => null,
            'mainwp_upload_dir'   => self::encodedUploadDir(),
            'post_gallery_images' => self::encodedEmptyArray(),
            'post_category'       => self::encodedEmptyString(),
        ];
    }

    private static function resolveWebsiteData(array $fieldData, string $requiredClass, string $classNotFoundMessage): array
    {
        $activeError = self::ensureActive();
        if ($activeError) {
            return ['error' => $activeError];
        }

        $siteId = (int) ($fieldData['site_id'] ?? 0);
        if (!$siteId) {
            return ['error' => self::errorResponse(__('Site ID is required', 'bit-integrations-pro'))];
        }

        $website = self::getWebsite($siteId);
        if (empty($website)) {
            return ['error' => self::errorResponse(__('Site not found', 'bit-integrations-pro'))];
        }

        $classError = self::ensureClassAvailable($requiredClass, $classNotFoundMessage);
        if ($classError) {
            return ['error' => $classError];
        }

        return ['website' => $website];
    }

    private static function ensureActive(): ?array
    {
        if (self::isActive()) {
            return null;
        }

        return self::errorResponse(__('MainWP is not installed or activated', 'bit-integrations-pro'));
    }

    private static function ensureClassAvailable(string $className, string $message): ?array
    {
        if (self::classExistsCached($className)) {
            return null;
        }

        return self::errorResponse($message);
    }

    private static function classExistsCached(string $className): bool
    {
        if (!empty(self::$classAvailability[$className])) {
            return true;
        }

        $exists = class_exists($className);
        if ($exists) {
            self::$classAvailability[$className] = true;
        }

        return $exists;
    }

    private static function callConnect($website, string $route, array $payload): array
    {
        try {
            $result = \MainWP\Dashboard\MainWP_Connect::fetch_url_authed($website, $route, $payload);
        } catch (Exception $e) {
            return ['error' => self::errorResponse($e->getMessage())];
        }

        if (is_wp_error($result)) {
            return ['error' => self::errorResponse($result->get_error_message())];
        }

        return ['data' => $result];
    }

    private static function encodedEmptyArray(): string
    {
        if (!isset(self::$encodedPayloadCache['empty_array'])) {
            self::$encodedPayloadCache['empty_array'] = self::encode([]);
        }

        return self::$encodedPayloadCache['empty_array'];
    }

    private static function encodedEmptyString(): string
    {
        if (!isset(self::$encodedPayloadCache['empty_string'])) {
            self::$encodedPayloadCache['empty_string'] = self::encode('');
        }

        return self::$encodedPayloadCache['empty_string'];
    }

    private static function encodedUploadDir(): string
    {
        if (!isset(self::$encodedPayloadCache['upload_dir'])) {
            self::$encodedPayloadCache['upload_dir'] = self::encode(wp_upload_dir());
        }

        return self::$encodedPayloadCache['upload_dir'];
    }

    private static function errorResponse(string $message): array
    {
        return ['success' => false, 'message' => $message];
    }

    private static function successResponse(string $message, $data = null): array
    {
        $response = ['success' => true, 'message' => $message];

        if (null !== $data) {
            $response['data'] = $data;
        }

        return $response;
    }
}
