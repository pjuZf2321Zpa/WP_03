<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

function masterstudy_lms_notification_push_queue_table_query() {
	global $wpdb;

	$table_name      = masterstudy_lms_notification_push_queue_table_name( $wpdb );
	$charset_collate = $wpdb->get_charset_collate();

	$sql = "CREATE TABLE $table_name (
		id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
		notification_id BIGINT(20) UNSIGNED NOT NULL,
		recipient_user_id BIGINT(20) UNSIGNED NOT NULL,
		status VARCHAR(20) NOT NULL DEFAULT 'pending',
		claim_id VARCHAR(64) NOT NULL DEFAULT '',
		attempts SMALLINT(5) UNSIGNED NOT NULL DEFAULT 0,
		available_at_gmt DATETIME NOT NULL,
		processed_at_gmt DATETIME DEFAULT NULL,
		last_error TEXT,
		created_at_gmt DATETIME NOT NULL,
		updated_at_gmt DATETIME NOT NULL,
		PRIMARY KEY (id),
		UNIQUE KEY notification_recipient (notification_id,recipient_user_id),
		INDEX idx_status_available (status,available_at_gmt),
		INDEX idx_status_available_id (status,available_at_gmt,id),
		INDEX idx_status_available_updated (status,available_at_gmt,updated_at_gmt),
		INDEX idx_status_updated (status,updated_at_gmt),
		INDEX idx_claim_id (claim_id),
		INDEX idx_recipient_user_id (recipient_user_id),
		INDEX idx_notification_id (notification_id)
	) $charset_collate;";

	require_once ABSPATH . 'wp-admin/includes/upgrade.php';

	dbDelta( $sql );
}
