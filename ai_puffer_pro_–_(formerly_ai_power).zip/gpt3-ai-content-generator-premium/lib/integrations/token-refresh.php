<?php

namespace WPAICG\Lib\Integrations\Auth;

use WPAICG\Lib\Integrations\Apps\AIPKit_App_Connections;
use WP_Error;

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

class AIPKit_App_Token_Refresh
{
    /**
     * @param array<string, mixed> $connection
     * @param array<string, mixed> $recipe
     * @param array<string, mixed> $execution
     * @param array<string, mixed> $failure_context
     * @return array<string, mixed>|WP_Error|null
     */
    public static function maybe_refresh_connection(
        array $connection,
        array $recipe,
        array $execution,
        array $failure_context = []
    ) {
        $refresh_result = apply_filters(
            'aipkit_native_app_recipe_refresh_connection',
            null,
            $connection,
            $recipe,
            $execution,
            $failure_context
        );

        if ($refresh_result === null || $refresh_result === false || $refresh_result === []) {
            return null;
        }

        if (is_wp_error($refresh_result)) {
            return $refresh_result;
        }

        if (!is_array($refresh_result)) {
            return null;
        }

        $connection_id = sanitize_text_field((string) ($connection['id'] ?? ''));
        $explicit_connection = isset($refresh_result['connection']) && is_array($refresh_result['connection'])
            ? $refresh_result['connection']
            : [];

        $updates = self::normalize_refresh_updates($refresh_result);
        if (!empty($updates) && $connection_id !== '') {
            AIPKit_App_Connections::update_connection_runtime_state($connection_id, $updates);

            $reloaded_connection = AIPKit_App_Connections::get_connection_by_id($connection_id);
            if (is_array($reloaded_connection) && !empty($reloaded_connection)) {
                return $reloaded_connection;
            }
        }

        if (!empty($explicit_connection)) {
            return $explicit_connection;
        }

        if (!empty($updates)) {
            return self::merge_connection_updates($connection, $updates);
        }

        return null;
    }

    /**
     * @param array<string, mixed> $refresh_result
     * @return array<string, mixed>
     */
    private static function normalize_refresh_updates(array $refresh_result): array
    {
        $candidate_updates = isset($refresh_result['updates']) && is_array($refresh_result['updates'])
            ? $refresh_result['updates']
            : $refresh_result;

        $allowed_keys = ['status', 'auth_type', 'is_enabled', 'credentials', 'workspace', 'meta'];
        $updates = [];

        foreach ($allowed_keys as $allowed_key) {
            if (!array_key_exists($allowed_key, $candidate_updates)) {
                continue;
            }

            $updates[$allowed_key] = $candidate_updates[$allowed_key];
        }

        return $updates;
    }

    /**
     * @param array<string, mixed> $connection
     * @param array<string, mixed> $updates
     * @return array<string, mixed>
     */
    private static function merge_connection_updates(array $connection, array $updates): array
    {
        $merged = $connection;

        if (isset($updates['status'])) {
            $merged['status'] = sanitize_key((string) $updates['status']);
        }

        if (isset($updates['auth_type'])) {
            $merged['auth_type'] = sanitize_key((string) $updates['auth_type']);
        }

        if (isset($updates['is_enabled'])) {
            $merged['is_enabled'] = (string) $updates['is_enabled'] === '1' || $updates['is_enabled'] === true;
        }

        foreach (['credentials', 'workspace', 'meta'] as $group_key) {
            if (!isset($updates[$group_key]) || !is_array($updates[$group_key])) {
                continue;
            }

            $existing_group = isset($merged[$group_key]) && is_array($merged[$group_key])
                ? $merged[$group_key]
                : [];
            $merged[$group_key] = array_merge($existing_group, $updates[$group_key]);
        }

        $merged['updated_at'] = gmdate('c');

        return $merged;
    }
}
