<?php

/**
 * @author WP Cloud Plugins
 * @copyright Copyright (c) 2023, WP Cloud Plugins
 *
 * @since       2.0
 * @see https://www.wpcloudplugins.com
 */

namespace TheLion\UseyourDrive;

defined('ABSPATH') || exit;

class CacheNode
{
    /**
     * ID of the Node = ID of the Cached Entry.
     *
     * @var mixed
     */
    private $_id;

    /**
     * ID of the Account.
     *
     * @var mixed
     */
    private $_account_id;

    /**
     * ID of the Drive the entry is on.
     *
     * @var mixed
     */
    private $_drive_id;

    /**
     * The NAME of the node = NAME of the Cached Entry.
     *
     * @var string
     */
    private $_name;

    /**
     * The cached Entry.
     *
     * @var Entry
     */
    private $_entry;

    /**
     * Is this node for a folder or a file.
     *
     * @var bool
     */
    private $_is_dir = false;

    /**
     * Contains the parent note.
     *
     * @var CacheNode
     */
    private $_parent;

    /**
     * Is the parent of this node already found/cached?
     *
     * @var bool
     */
    private $_parent_found = false;

    /**
     * Contains the array of children.
     *
     * @var CacheNode[]
     */
    private $_children = [];

    /**
     * Are the children already found/cached?
     *
     * @var bool
     */
    private $_children_loaded = false;

    /**
     * Are all subfolders inside this node found.
     *
     * @var bool
     */
    private $_all_childfolders_loaded = false;

    /**
     * Is the node the root of account?
     *
     * @var bool
     */
    private $_root = false;

    /**
     * When does this node expire? Value is set in the Cache of the Cloud Service.
     *
     * @var int
     */
    private $_expires;

    /**
     * Entry is only loaded via GetFolder or GetEntry, not when the tree is built.
     *
     * @var bool
     */
    private $_loaded = false;

    // Trashed files will be deleted when the cache is saved
    private $_trashed = false;

    // In some special cases, an entry or folder should be hidden
    private $_hidden = false;

    /**
     * ID of original node if is shortcut.
     */
    private $_original_node_id;

    /**
     * IDs of files that are a shortcut to this node;.
     *
     * @var array|bool
     */
    private $_original_node_for = [];

    /**
     * Contains the file handle in case the plugin has to work
     * with a file for unlocking/locking.
     *
     * @var type
     */
    private $_cache_file_handle;

    /**
     * Is set to true when a change has been made in the cache.
     * Forcing the plugin to save the cache when needed.
     *
     * @var bool
     */
    private $_updated = false;

    /**
     * Is this CacheNode already initialized via a cache file (i.e. is $entry already present.
     *
     * @var bool
     */
    private $_initialized = false;

    /**
     * Set when the cache file of this node couldn't be read during this request.
     * Used to prevent the plugin from reading the same file over and over again.
     * This value is never stored in the cache itself.
     *
     * @var bool
     */
    private $_load_failed = false;

    /**
     * Folders that only have a structural function and cannot be used to perform any actions (e.g. delete/rename/zip)
     * Team Drives and Computers are such folders.
     */
    private $_virtual_folder = false;

    public function __construct($params = null)
    {
        if (!empty($params)) {
            foreach ($params as $key => $val) {
                $this->{$key} = $val;
            }
        }
    }

    /**
     * Serialize this node to JSON-safe folder-cache data without topology.
     */
    public function to_cache_array(): array
    {
        $data = get_object_vars($this);

        unset($data['_cache_file_handle'], $data['_updated'], $data['_parent'], $data['_children'], $data['_load_failed']);

        $data['_entry'] = $this->_entry?->to_cache_array();

        if (!empty($this->_entry) && !$this->is_dir()) {
            $data['_initialized'] = true;
        }

        return EntryAbstract::normalize_for_cache($data);
    }

    /**
     * Hydrate this node from cached plain data without changing topology.
     *
     * @param array $data cached node data
     */
    public function hydrate_from_cache_array(array $data): void
    {
        $allowed_keys = array_keys(get_object_vars($this));
        $blocked_keys = ['_cache_file_handle', '_updated', '_parent', '_children', '_load_failed'];

        foreach ($data as $key => $value) {
            if (in_array($key, $blocked_keys, true) || !in_array($key, $allowed_keys, true)) {
                continue;
            }

            if ('_entry' === $key) {
                $this->_entry = is_array($value) ? Entry::from_cache_array($value) : null;

                continue;
            }

            /*
             * Folders are stored in their own cache file, and in the cache file
             * of their parent folder. When the copy in the parent folder doesn't
             * contain any data, it may not mark this folder as initialized, as
             * its own cache file would never be read again.
             */
            if ('_initialized' === $key && true === $value && empty($data['_entry']) && !empty($data['_is_dir'])) {
                continue;
            }

            if (is_scalar($value) || is_array($value) || null === $value) {
                $this->{$key} = $value;
            }
        }
    }

    public function get_full_id()
    {
        return "{$this->get_account_id()}-{$this->get_drive_id()}-{$this->get_id()}";
    }

    public function get_id()
    {
        return $this->_id;
    }

    public function get_drive_id()
    {
        return $this->_drive_id;
    }

    public function get_account_id()
    {
        return $this->_account_id;
    }

    public function get_account_uuid()
    {
        return Accounts::instance()->account_id_to_uuid($this->_account_id);
    }

    public function set_name($name)
    {
        $this->_name = $name;

        return $this;
    }

    public function get_name()
    {
        return $this->_name;
    }

    public function has_entry()
    {
        return null !== $this->get_entry();
    }

    /**
     * @return Entry
     */
    public function get_entry()
    {
        if (false === $this->_initialized) {
            if ($this->is_dir()) {
                $this->load();
            } else {
                if ($this->has_parent()) {
                    $this->get_parent()->load();
                }
            }
        }

        return $this->_entry;
    }

    /**
     * @param Entry $entry
     *
     * @return CacheNode
     */
    public function set_entry($entry)
    {
        $this->_entry = $entry;
        $this->set_updated();

        return $this;
    }

    public function has_parent()
    {
        return null !== $this->get_parent();
    }

    /**
     * @return CacheNode
     */
    public function get_parent()
    {
        return $this->_parent;
    }

    public function set_parent(CacheNode $pnode)
    {
        if (false === $this->get_parent_found()) {
            $this->remove_parent();
            $this->_parent_found = true;
        }

        $pnode->add_child($this);
        $this->_parent = $pnode;
        $this->set_parent_found();

        return $this;
    }

    public function remove_parent()
    {
        if (false === $this->has_parent()) {
            return;
        }

        if ($this->get_parent() instanceof CacheNode) {
            $this->get_parent()->remove_child($this);

            $this->_parent = null;

            $this->set_updated();
        }

        $this->_parent = null;
    }

    public function is_in_folder($parent_id)
    {
        $cache_group = 'wpcp-'.CORE::$slug.'-nodes';
        $cache_key = Cache::build_key($cache_group, 'wpcp-n-'.$this->get_full_id().'-'.$parent_id);
        $is_in_folder = wp_cache_get($cache_key, $cache_group, false);

        if (in_array($is_in_folder, ['in_folder', 'not_in_folder'])) {
            return 'in_folder' === $is_in_folder;
        }

        if (null === $this->get_entry()) {
            $fresh_entry = Client::instance()->get_entry($this->get_id(), true);
            if (!empty($fresh_entry)) {
                wp_cache_set($cache_key, 'not_in_folder', $cache_group, 300);

                return false;
            }
        }

        // Is node just the folder?
        if ($this->get_id() === $parent_id) {
            wp_cache_set($cache_key, 'in_folder', $cache_group, 300);

            return true;
        }

        if (in_array($this->get_virtual_folder(), ['drive'])) {
            wp_cache_set($cache_key, 'not_in_folder', $cache_group, 300);

            return false; // This is the root node, there are no parents beyond
        }

        // Check if this parent is in folder
        if ($this->has_parent() && true === $this->get_parent()->is_in_folder($parent_id)) {
            wp_cache_set($cache_key, 'in_folder', $cache_group, 300);

            return true;
        }

        // Check if this has shortcuts
        $shortcut_nodes = Cache::instance()->get_shortcut_nodes_by_id($this->get_id());

        if (count($shortcut_nodes)) {
            // No Shortcuts found
        }

        foreach ($shortcut_nodes as $other_node) {
            // First check if one of the nodes is the root folder

            if (!empty($other_node) && true === $other_node->is_in_folder($parent_id)) {
                wp_cache_set($cache_key, 'in_folder', $cache_group, 300);

                return true;
            }
        }

        // If we end up here, we haven't found the parent yet.
        // It might be possible that we are dealing with a shortcut, of which the parent is not yet loaded in the Cache
        $all_shortcuts = Client::instance()->get_shortcuts_for_entry($this);
        $missing_shortcuts = array_diff_key($all_shortcuts, $shortcut_nodes);

        foreach ($missing_shortcuts as $shortcut_node) {
            // First check if one of the nodes is the root folder
            if (empty($shortcut_node)) {
                continue;
            }

            if (is_string($shortcut_node)) {
                $shortcut_node = Cache::instance()->get_node_by_id($shortcut_node);
            }

            if (true === $shortcut_node->is_in_folder($parent_id)) {
                return true;
            }
        }

        wp_cache_set($cache_key, 'not_in_folder', $cache_group, 300);

        return false;
    }

    public function set_root($value = true)
    {
        $this->_root = $value;

        return $this;
    }

    public function is_root()
    {
        return $this->_root;
    }

    public function set_parent_found($value = true)
    {
        $this->_parent_found = $value;

        return $this;
    }

    public function get_parent_found()
    {
        return $this->_parent_found;
    }

    public function has_children()
    {
        return count($this->_children) > 0;
    }

    /**
     * @return CacheNode[]
     */
    public function get_children()
    {
        return $this->_children;
    }

    public function add_child(CacheNode $cnode)
    {
        $child_id = $cnode->get_id();

        foreach ($this->_children as $key => $existing) {
            if (!$existing instanceof CacheNode && (string) $existing === (string) $child_id) {
                unset($this->_children[$key]);
            }
        }

        $this->_children[$child_id] = $cnode;

        return $this;
    }

    public function remove_child_by_id($id)
    {
        $this->set_updated();
        unset($this->_children[$id]);
    }

    public function remove_child(CacheNode $cnode)
    {
        $this->set_updated();
        unset($this->_children[$cnode->get_id()]);

        return $this;
    }

    public function remove_children()
    {
        foreach ($this->get_children() as $child) {
            $this->remove_child($child);
        }

        return $this;
    }

    public function has_loaded_children()
    {
        return $this->_children_loaded;
    }

    public function set_loaded_children($value = true)
    {
        $this->_children_loaded = $value;

        return $this->_children_loaded;
    }

    public function has_loaded_all_childfolders()
    {
        return $this->_all_childfolders_loaded;
    }

    public function set_loaded_all_childfolders($value = true)
    {
        foreach ($this->get_all_sub_folders() as $child_folder) {
            $child_folder->set_loaded_all_childfolders($value);
        }

        $this->_all_childfolders_loaded = $value;

        return $this->_all_childfolders_loaded;
    }

    public function is_expired()
    {
        if (null === $this->get_entry()) {
            return true;
        }

        if (!$this->is_loaded()) {
            return true;
        }

        // Folders itself cannot expire
        if ($this->get_entry()->is_dir() && $this->has_loaded_children() && !$this->has_children()) {
            return false;
        }

        // Check if the entry needs to be refreshed
        if ($this->get_entry()->is_file() && $this->_expires < time()) {
            return true;
        }

        // Some special folders can't expire
        if ($this->is_virtual_folder()) {
            return false;
        }

        // Also check if the files in a folder are still OK
        if ($this->has_children()) {
            foreach ($this->get_children() as $child) {
                if (!$child instanceof CacheNode) {
                    return true;
                }

                if (!$child->has_entry()) {
                    return true;
                }

                if ($child->get_entry()->is_file() && $child->_expires < time()) {
                    return true;
                }
            }
        }

        return false;
    }

    /**
     * @return CacheNode[]
     */
    public function get_all_child_folders()
    {
        $list = [];
        if ($this->has_children()) {
            foreach ($this->get_children() as $child) {
                if (!$child->has_entry() || $child->get_entry()->is_file()) {
                    continue;
                }

                if ($child->has_entry()) {
                    $list[$child->get_id()] = $child;
                }

                if ($child->has_children()) {
                    $folders_in_child = $child->get_all_child_folders();
                    $list = array_merge($list, $folders_in_child);
                }
            }
        }

        return $list;
    }

    public function get_all_sub_folders()
    {
        $list = [];
        if ($this->has_children()) {
            foreach ($this->get_children() as $child) {
                if ($child->has_entry() && $child->get_entry()->is_dir()) {
                    $list[$child->get_id()] = $child;
                }
            }
        }

        return $list;
    }

    public function get_all_parent_folders()
    {
        $list = [];
        if ($this->has_parent()) {
            $list[$this->get_parent()->get_id()] = $this->get_parent();
            $list = array_merge($list, $this->get_parent()->get_all_parent_folders());
        }

        return $list;
    }

    public function get_linked_users()
    {
        $linked_users = [];
        $all_parent_folders = $this->get_all_parent_folders();

        // First obtain all users that are manually linked to the entry or its parents
        global $wpdb;

        $meta_query = [
            'relation' => 'OR',
            [
                'key' => $wpdb->prefix.'use_your_drive_linkedto',
                'value' => '"'.$this->get_id().'"',
                'compare' => 'LIKE',
            ],
        ];

        if (!empty($all_parent_folders)) {
            foreach ($all_parent_folders as $parent_folder) {
                $meta_query[] = [
                    'key' => $wpdb->prefix.'use_your_drive_linkedto',
                    'value' => '"'.$parent_folder->get_id().'"',
                    'compare' => 'LIKE',
                ];
            }
        }

        $manually_linked_users = get_users(['meta_query' => $meta_query]);

        foreach ($manually_linked_users as $userdata) {
            $linked_users[$userdata->ID] = $userdata;
        }

        /* Secondly obtain all users that are automatically linked to the entry or its parents
         * The folder has to contain the email address of the user */

        $all_parent_folders[] = $this; // Add current entry to prevent duplicate code

        foreach ($all_parent_folders as $parent) {
            $extracted_email = Helpers::extract_email_from_string($parent->get_name());

            if (false === $extracted_email) {
                continue;
            }

            $userdata = \WP_User::get_data_by('email', $extracted_email);

            if (!$userdata) {
                continue;
            }

            $linked_users[$userdata->ID] = $userdata;
        }

        return $linked_users;
    }

    public function get_path($to_parent_id)
    {
        if ($to_parent_id === $this->get_id()) {
            return '/'.$this->get_name();
        }

        if ($this->has_parent()) {
            if ($this->get_parent()->get_id() === $to_parent_id) {
                return '/'.$this->get_name();
            }

            $path = $this->get_parent()->get_path($to_parent_id);
            if (false !== $path) {
                return $path.'/'.$this->get_name();
            }
        }

        if ($this->is_root()) {
            return '';
        }

        return false;
    }

    public function set_expired($value)
    {
        return $this->_expires = $value;
    }

    public function get_expired()
    {
        return $this->_expires;
    }

    public function set_loaded($value)
    {
        return $this->_loaded = $value;
    }

    public function is_loaded()
    {
        return $this->_loaded;
    }

    public function set_initialized($value)
    {
        return $this->_initialized = $value;
    }

    public function is_initialized()
    {
        return $this->_initialized;
    }

    public function set_hidden($value)
    {
        return $this->_hidden = $value;
    }

    public function is_hidden()
    {
        return $this->_hidden;
    }

    public function set_trashed($value = true)
    {
        return $this->_trashed = $value;
    }

    public function is_trashed()
    {
        return true === $this->_trashed;
    }

    public function set_is_dir($value = true)
    {
        return $this->_is_dir = $value;
    }

    public function is_dir()
    {
        return true === $this->_is_dir;
    }

    public function is_shortcut()
    {
        return null !== $this->_original_node_id;
    }

    /**
     * @return CacheNode
     */
    public function get_original_node()
    {
        if (empty($this->get_original_node_id())) {
            return null;
        }

        return Client::instance()->get_entry($this->get_original_node_id(), false);
    }

    public function get_original_node_id()
    {
        return $this->_original_node_id;
    }

    public function set_original_node_id($node_id)
    {
        $this->_original_node_id = $node_id;

        return $this;
    }

    public function get_original_node_for()
    {
        return $this->_original_node_for;
    }

    public function add_original_node_for($_original_node_for = [])
    {
        $this->_original_node_for = array_unique(array_merge($this->_original_node_for, $_original_node_for));

        return $this;
    }

    public function get_virtual_folder()
    {
        return $this->_virtual_folder;
    }

    public function set_virtual_folder($value)
    {
        $this->_virtual_folder = $value;
    }

    public function is_virtual_folder()
    {
        return false !== $this->_virtual_folder;
    }

    public function is_updated()
    {
        return $this->_updated;
    }

    public function set_updated($value = true)
    {
        $this->_updated = (bool) $value;

        return $this->_updated;
    }

    public function get_cache_name()
    {
        $prefix = (in_array($this->_id, ['drive', 'shared-with-me', 'shared-drives', 'computers', 'app_data_folder'])) ? App::get_current_account()->get_id() : '';

        return Helpers::filter_filename($prefix, false).'_'.$this->_id.'.index';
    }

    public function get_cache_location()
    {
        return USEYOURDRIVE_CACHEDIR.'/'.$this->get_cache_name();
    }

    /**
     * Load the data of this node from its own cache file.
     *
     * @return bool true when the cached data is loaded
     */
    public function load()
    {
        // Only try to read the cache file once per request
        if (true === $this->_load_failed) {
            return false;
        }

        /*
         * Don't create the cache file while reading it, as it would be filled
         * with the data that this node is missing in the first place.
         */
        if (false === file_exists($this->get_cache_location())) {
            $this->_load_failed = true;

            return false;
        }

        $cache = $this->_read_local_cache('close');

        if (function_exists('gzdecode')) {
            $cache = @gzdecode($cache);
        }

        /*
         * Leave the node uninitialized when its cache file couldn't be read.
         * Marking it as initialized would present the node as a folder without
         * any data, and would allow that empty data to be written to the cache.
         */
        if (empty($cache) || is_array($cache)) {
            $this->_load_failed = true;

            return false;
        }

        if (false === $this->_unserialize_for_folder($cache)) {
            $this->_load_failed = true;

            return false;
        }

        $this->set_initialized(true);

        return true;
    }

    public function update_cache()
    {
        if ($this->is_updated() && $this->is_dir()) {
            if (false === $this->is_initialized()) {
                return false;
            }

            // The node is only marked as saved when writing the file succeeded
            $this->_save_local_cache();
        }
    }

    public function delete_cache()
    {
        if ($this->is_dir()) {
            @unlink($this->get_cache_location());
        }
    }

    public function to_index()
    {
        $_children = [];
        foreach ($this->_children as $child) {
            if ($child instanceof CacheNode) {
                $_children[] = $child->get_id();
            } else {
                $_children[] = $child;
            }
        }

        return [
            '_id' => $this->_id,
            '_account_id' => $this->_account_id,
            '_drive_id' => $this->_drive_id,
            '_name' => $this->_name,
            '_parent' => ($this->has_parent()) ? $this->get_parent()->get_id() : null,
            '_children' => $_children,
            '_original_node_id' => $this->_original_node_id,
            '_original_node_for' => $this->_original_node_for,
            '_is_dir' => $this->_is_dir,
        ];
    }

    protected function _set_cache_file_handle($handle)
    {
        return $this->_cache_file_handle = $handle;
    }

    protected function _get_cache_file_handle()
    {
        return $this->_cache_file_handle;
    }

    protected function _read_local_cache($close = false)
    {
        $handle = $this->_get_cache_file_handle();
        if (empty($handle)) {
            if (false === $this->_create_local_lock(LOCK_SH)) {
                return '';
            }
        }

        $handle = $this->_get_cache_file_handle();
        if (empty($handle)) {
            return '';
        }

        // Clear PHP’s stat cache so filesize() is up-to-date
        clearstatcache();
        rewind($handle);

        $contents = '';

        // Read until end-of-file in 8 192-byte chunks
        while (filesize($this->get_cache_location()) > 0 && !feof($handle)) {
            $chunk = fread($handle, 8192);
            if (false === $chunk) {
                // sth went wrong—break out and return what we have
                break;
            }
            $contents .= $chunk;
        }

        if (false !== $close) {
            $this->_unlock_local_cache();
        }

        return $contents;
    }

    protected function _create_local_lock($type)
    {
        // Check if file exists
        $file = $this->get_cache_location();

        if (!file_exists($file)) {
            $data = $this->_serialize_for_folder();

            @file_put_contents($file, $data);

            if (!is_writable($file)) {
                Helpers::log_error('Cache file is not writable', 'Cache', ['file' => $file], __LINE__);

                return false;
            }
        }

        // Check if the file is more than 1 minute old.
        $requires_unlock = ((filemtime($file) + 60) < time());

        // Temporarily workaround when flock is disabled. Can cause problems when plugin is used in multiple processes
        $flock_disabled = (false !== strpos(ini_get('disable_functions'), 'flock'));
        if ($flock_disabled) {
            $requires_unlock = false;
        }

        // Check if file is already opened and locked in this process
        $handle = $this->_get_cache_file_handle();
        if (empty($handle)) {
            $handle = fopen($file, 'c+');
            if (!is_resource($handle)) {
                Helpers::log_error('Cache file is not writable', 'Cache', ['file' => $file], __LINE__);

                return false;
            }
            $this->_set_cache_file_handle($handle);
        }

        Helpers::set_time_limit(60);

        if (!flock($this->_get_cache_file_handle(), $type)) {
            /*
             * If the file cannot be unlocked and the last time
             * it was modified was 1 minute, assume that
             * the previous process died and unlock the file manually
             */
            if ($requires_unlock) {
                $this->_unlock_local_cache();
                $handle = fopen($file, 'c+');
                if (!is_resource($handle)) {
                    Helpers::log_error('Cache file cannot be reopened', 'Cache', ['file' => $file], __LINE__);

                    return false;
                }
                $this->_set_cache_file_handle($handle);
            } elseif (false === $flock_disabled) {
                return false;
            }

            // Try to lock the file again
            if (!flock($this->_get_cache_file_handle(), $type)) {
                Helpers::log_error('Lock not obtained after retry', 'Cache', ['file' => $file], __LINE__);

                return false;
            }
        }
        Helpers::set_time_limit(60);

        touch($file);

        return true;
    }

    protected function _save_local_cache()
    {
        $data = $this->_serialize_for_folder();
        if (false === $data || '' === $data) {
            return false;
        }

        if (!$this->_create_local_lock(LOCK_EX)) {
            return false;
        }

        ftruncate($this->_get_cache_file_handle(), 0);
        rewind($this->_get_cache_file_handle());
        fwrite($this->_get_cache_file_handle(), $data);

        $this->_unlock_local_cache();
        $this->set_updated(false);

        return true;
    }

    protected function _unlock_local_cache()
    {
        $handle = $this->_get_cache_file_handle();
        if (!empty($handle)) {
            $unlocked = flock($this->_get_cache_file_handle(), LOCK_UN);
            fclose($this->_get_cache_file_handle());
            $this->_set_cache_file_handle(null);
        }

        clearstatcache();

        return true;
    }

    private function _serialize_for_folder()
    {
        $children = [];
        foreach ($this->get_children() as $child) {
            if ($child instanceof self) {
                $children[] = $child->to_cache_array();
            }
        }

        $data = [
            'folder' => $this->to_cache_array(),
            'children' => $children,
        ];

        try {
            $data_str = json_encode($data, JSON_THROW_ON_ERROR | JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
        } catch (\JsonException $ex) {
            Helpers::log_error('Failed to JSON-encode folder cache.', 'Cache', ['id' => $this->_id], __LINE__, $ex);

            return '';
        }

        $data_str = "WPCP\x01".$data_str;

        if (function_exists('gzencode')) {
            $data_str = gzencode($data_str);
        }

        return $data_str;
    }

    /**
     * Restore the data of this node, and of its children, from its cache file.
     *
     * @param string $data contents of the cache file
     *
     * @return bool true when the data is restored
     */
    private function _unserialize_for_folder($data)
    {
        if (!is_string($data) || 0 !== strncmp($data, "WPCP\x01", 5)) {
            @unlink($this->get_cache_location());

            return false;
        }

        try {
            $values = json_decode(substr($data, 5), true, 512, JSON_THROW_ON_ERROR);
        } catch (\JsonException $ex) {
            @unlink($this->get_cache_location());

            return false;
        }

        if (!is_array($values) || !isset($values['folder']) || !is_array($values['folder']) || (isset($values['children']) && !is_array($values['children']))) {
            @unlink($this->get_cache_location());

            return false;
        }

        if (!empty($values['children'])) {
            foreach ($values['children'] as $child_data) {
                if (!is_array($child_data)) {
                    continue;
                }

                $child_node = Cache::instance()->get_node_by_id($child_data['_id'] ?? null, false);
                if (empty($child_node)) {
                    continue;
                }

                $child_node->hydrate_from_cache_array($child_data);
            }
        }

        $node = Cache::instance()->get_node_by_id($this->_id, false);
        if (empty($node)) {
            return false;
        }

        $node->hydrate_from_cache_array($values['folder']);

        /*
         * A cache file without any data doesn't say anything about the folder.
         * Report it as unreadable, so that the folder is requested from the API
         * again instead of being presented as an empty folder.
         * Read the property directly: has_entry() would call load() again, as
         * the node isn't initialized yet.
         */
        if (null === $node->_entry) {
            return false;
        }

        return true;
    }
}
