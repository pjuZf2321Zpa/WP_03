<?php

namespace BitApps\IntegrationsPro\Actions\Booknetic\Services;

use BookneticApp\Models\Location;
use BookneticApp\Models\LocationCategory;

final class LocationCategoryService extends BaseService
{
    public function createLocationCategory(): array
    {
        $error = $this->validate(['name' => [__('Name', 'bit-integrations-pro')]]);

        if ($error !== null) {
            return $error;
        }

        return $this->createRecord(LocationCategory::class, ['name' => $this->string('name')]);
    }

    public function updateLocationCategory(): array
    {
        $error = $this->validate([
            'location_category_id' => [__('Location Category ID', 'bit-integrations-pro'), 'integer'],
            'name'                 => [__('Name', 'bit-integrations-pro')],
        ]);

        if ($error !== null) {
            return $error;
        }

        return $this->updateRecord(LocationCategory::class, $this->int('location_category_id'), ['name' => $this->string('name')]);
    }

    public function deleteLocationCategory(): array
    {
        $error = $this->validate(['location_category_id' => [__('Location Category ID', 'bit-integrations-pro'), 'integer']]);

        if ($error !== null) {
            return $error;
        }

        $categoryId = $this->int('location_category_id');

        if (Location::query()->where('category_id', $categoryId)->count() > 0) {
            return $this->error(__('The category has locations. Move or delete the locations first.', 'bit-integrations-pro'), 422);
        }

        return $this->deleteRecord(LocationCategory::class, $categoryId, __('The location category is deleted.', 'bit-integrations-pro'));
    }
}
