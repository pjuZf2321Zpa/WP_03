<?php

namespace FluentCartPro\App\Modules\StorageDrivers\R2;

use FluentCart\App\Helpers\Helper;
use FluentCart\App\Modules\StorageDrivers\BaseStorageDriver;
use FluentCart\Framework\Support\Arr;
use FluentCartPro\App\Services\FileSystem\Drivers\R2\R2BucketCreator;
use FluentCartPro\App\Services\FileSystem\Drivers\R2\R2BucketList;
use FluentCartPro\App\Services\FileSystem\Drivers\R2\R2ConnectionVerify;
use FluentCartPro\App\Services\CoreCompat;
use FluentCartPro\App\Services\FileSystem\Drivers\R2\R2Driver;
use FluentCartPro\App\Utils\Enqueuer\Vite;

class R2 extends BaseStorageDriver
{
    public function __construct()
    {
        parent::__construct(
            __('Cloudflare R2', 'fluent-cart-pro'),
            'r2',
            '#f38020'
        );
    }

    public function registerHooks()
    {
        add_filter('fluent_cart/verify_driver_connect_info_' . $this->slug, [$this, 'verifyConnectInfo'], 10, 2);
        add_filter('fluent_cart/get_dynamic_search_r2_bucket_list', [$this, 'getBucketList'], 10, 2);

        // Core draws storage_r2_settings from the storage module (module API 3); older cores get the notice template.
        if (CoreCompat::hasFctComponents()) {
            add_action('fluent_cart/loading_app', [$this, 'enqueueSettingsScreen']);
            add_filter('fluent_cart/admin_translations', [$this, 'addAdminTranslations'], 10, 2);
        }
    }

    public function enqueueSettingsScreen(): void
    {
        wp_enqueue_script('fluent_cart_pro_storage', FLUENTCART_PRO_PLUGIN_URL . 'assets/modules/storage.js', [], FLUENTCART_PRO_PLUGIN_VERSION, true);

        add_filter('script_loader_tag', function ($tag, $handle) {
            if ($handle !== 'fluent_cart_pro_storage') {
                return $tag;
            }

            return str_replace('<script ', '<script type="module" ', $tag);
        }, 10, 2);
    }

    public function addAdminTranslations($translations, $args = [])
    {
        return array_merge(require dirname(__DIR__) . '/storage-translation.php', (array)$translations);
    }

    public function getBucketList($buckets = [], $args = []): array
    {
        $resolvedCredentials = $this->resolveCredentials(Arr::get($args, 'driver_settings', []));

        if (
            empty($resolvedCredentials['account_id']) ||
            empty($resolvedCredentials['access_key']) ||
            empty($resolvedCredentials['secret_key'])
        ) {
            return [];
        }

        $bucketList = R2BucketList::get(
            $resolvedCredentials['account_id'],
            $resolvedCredentials['secret_key'],
            $resolvedCredentials['access_key']
        );

        if (is_wp_error($bucketList)) {
            return [];
        }

        $options = [];
        foreach ($bucketList as $bucket) {
            $options[] = [
                'label' => $bucket,
                'value' => $bucket,
            ];
        }

        return $options;
    }

    public function getLogo(): string
    {
        return Vite::getAssetUrl('images/storage-drivers/r2.svg');
    }

    public function getDarkLogo(): string
    {
        return Vite::getAssetUrl('images/storage-drivers/r2-dark.svg');
    }



    public function hasBucket(): bool
    {
        return true;
    }

    public function getEffectiveBucket(): string
    {
        return R2Settings::resolveEffectiveBucket($this->getSettings());
    }

    public function getDescription()
    {
        return esc_html__('Cloudflare R2 allows you to store downloadable product files in Cloudflare object storage.', 'fluent-cart-pro');
    }

    public function isEnabled(): bool
    {
        return (new R2Settings())->isActive();
    }

    public function getConnectedProviderName()
    {
        return $this->isEnabled() ? 'Cloudflare R2' : null;
    }

    public function getSettings()
    {
        return (new R2Settings())->get();
    }

    public function getSettingsTemplate(): ?string
    {
        // Module API 3 draws the R2 screen from Pro's storage module instead.
        if (!CoreCompat::hasFctComponents()) {
            return CoreCompat::updateNoticeTemplate();
        }

        return null;
    }

    public function getSettingsTemplatePayload(array $response = []): array
    {
        return array_merge(parent::getSettingsTemplatePayload($response), [
            'connection_verify_endpoint' => 'settings/storage-drivers/verify-info',
            'create_bucket_endpoint'     => 'settings/storage-drivers/create-bucket',
            'bucket_list_endpoint'       => 'settings/storage-drivers/bucket-list',
            'reset_endpoint'             => 'settings/storage-drivers/reset',
            'save_endpoint'              => 'settings/storage-drivers',
            'supports_template_mode'     => true,
        ]);
    }

    public function listBuckets(array $data, array $args = [])
    {
        $credentialError = $this->requireCredentials($data);
        if ($credentialError) {
            return $credentialError;
        }

        return $this->getBucketList([], [
            'driver_settings' => $data,
            'query'           => Arr::get($args, 'query'),
        ]);
    }

    public function createBucket(array $data)
    {
        $credentialError = $this->requireCredentials($data);
        if ($credentialError) {
            return $credentialError;
        }

        $resolvedCredentials = $this->resolveCredentials($data);
        $accountId = sanitize_text_field(Arr::get($resolvedCredentials, 'account_id', ''));
        $accessKey = sanitize_text_field(Arr::get($resolvedCredentials, 'access_key', ''));
        $secretKey = Arr::get($resolvedCredentials, 'secret_key', '');

        if (!$accountId || !$accessKey || !$secretKey) {
            return new \WP_Error('invalid_credentials', __('Invalid R2 credentials for bucket creation.', 'fluent-cart-pro'));
        }

        $newBucket = strtolower(sanitize_text_field(Arr::get($data, 'new_bucket_name')));
        $newBucket = preg_replace('/[^a-z0-9\.-]/', '-', $newBucket);
        $newBucket = preg_replace('/-+/', '-', $newBucket);
        $newBucket = trim($newBucket, '-.');
        $newRegion = sanitize_text_field(Arr::get($data, 'new_bucket_region', 'auto')) ?: 'auto';

        if (!$newBucket) {
            return new \WP_Error('invalid_bucket', __('Bucket name is required.', 'fluent-cart-pro'));
        }

        return R2BucketCreator::create($accountId, $secretKey, $accessKey, $newBucket, $newRegion);
    }

    public function updateSettings($data)
    {
        $settings = $this->getSettings();

        if (!array_key_exists('auth_method', $data) && isset($settings['auth_method'])) {
            $data['auth_method'] = $settings['auth_method'];
        }

        if (!array_key_exists('buckets', $data) && isset($settings['buckets'])) {
            $data['buckets'] = $settings['buckets'];
        }

        $mergeKeys = array_diff($this->hiddenSettingKeys(), ['create_new_bucket', 'new_bucket_name', 'new_bucket_region']);
        $credentialKeys = ['access_key', 'secret_key', 'account_id'];
        $storedAuthMethod = Arr::get($settings, 'auth_method');

        foreach ($mergeKeys as $key) {
            $isCredential = in_array($key, $credentialKeys, true);

            // In define mode getSettings() resolves credentials from the wp-config
            // constants, so merging one here would copy it into the database and
            // break revocation. Never fall back to a value we do not own.
            if ($isCredential && $storedAuthMethod === 'define') {
                continue;
            }

            // Credentials are stripped from the settings response, so an empty
            // submitted value means "unchanged" and must fall back to storage.
            $isMissing = $isCredential
                ? empty($data[$key])
                : !array_key_exists($key, $data);

            if ($isMissing && isset($settings[$key])) {
                $data[$key] = $settings[$key];
            }
        }

        if (
            Arr::get($data, 'is_active') === 'no' &&
            !Arr::get($data, 'verify_only_credentials') &&
            !Arr::get($data, 'check_bucket_exists') &&
            Arr::get($data, 'preserve_settings')
        ) {
            $settings['is_active'] = 'no';
            parent::updateSettings($this->prepareSettingsForStorage($settings));

            return [
                'data'         => Arr::except($settings, $this->hiddenSettingKeys()),
                'message'      => __('R2 is deactivated successfully.', 'fluent-cart-pro'),
                'shouldReload' => false,
            ];
        }

        $credentialError = $this->requireCredentials($data);
        if ($credentialError) {
            return $credentialError;
        }

        $resolvedCredentials = $this->resolveCredentials($data);

        if (Arr::get($data, 'verify_only_credentials')) {
            $verifyResult = $this->verifyConnectInfo($data);
            if (is_wp_error($verifyResult)) {
                return $verifyResult;
            }
        }

        if (Arr::get($data, 'create_new_bucket') === 'yes') {
            $creationResult = $this->createBucket($data);
            if (is_wp_error($creationResult)) {
                return $creationResult;
            }

            $data['bucket'] = Arr::get($creationResult, 'bucket', '');
            $data['region'] = Arr::get($creationResult, 'region', 'auto');
        }

        // A credentials-only step must not run a bucket check: a failure here
        // aborts the save and discards the credentials the user just entered.
        if (!empty($data['bucket']) && !Arr::get($data, 'verify_only_credentials')) {
            $bucketCheck = R2ConnectionVerify::checkBucketExistence(
                sanitize_text_field(Arr::get($resolvedCredentials, 'account_id', '')),
                (string) Arr::get($resolvedCredentials, 'secret_key', ''),
                sanitize_text_field(Arr::get($resolvedCredentials, 'access_key', '')),
                sanitize_text_field(Arr::get($data, 'bucket'))
            );

            if (is_wp_error($bucketCheck)) {
                return $bucketCheck;
            }

            $data['region'] = Arr::get($bucketCheck, 'region', 'auto');
            $data['connection_error'] = '';
        }

        parent::updateSettings($this->prepareSettingsForStorage($data));

        return [
            'data'         => Arr::except($data, $this->hiddenSettingKeys()),
            'message'      => Arr::get($data, 'is_active') === 'yes'
                ? __('Your R2 storage is activated successfully.', 'fluent-cart-pro')
                : __('Settings saved successfully.', 'fluent-cart-pro'),
            'shouldReload' => Arr::get($data, 'is_active') === 'yes',
        ];
    }

    public function resetSettings()
    {
        fluent_cart_update_option($this->driverHandler, []);
        R2Settings::$cachedSettings = null;

        return $this->getSettings();
    }

    private function prepareSettingsForStorage(array $settings): array
    {
        if (Arr::get($settings, 'auth_method') === 'define') {
            unset($settings['account_id'], $settings['access_key'], $settings['secret_key']);
        } else {
            if (!empty($settings['access_key'])) {
                $settings['access_key'] = Helper::encryptKey($settings['access_key']);
            }

            if (!empty($settings['secret_key'])) {
                $settings['secret_key'] = Helper::encryptKey($settings['secret_key']);
            }
        }

        unset($settings['create_new_bucket'], $settings['new_bucket_name'], $settings['new_bucket_region']);
        unset($settings['verify_credentials'], $settings['verify_only_credentials'], $settings['preserve_settings'], $settings['check_bucket_exists']);

        return $settings;
    }

    protected function resolveCredentials(array $data): array
    {
        $settings = $this->getSettings();
        $authMethod = Arr::get($data, 'auth_method', Arr::get($settings, 'auth_method'));

        if ($authMethod === 'define') {
            $definedCredentials = R2Settings::getDefinedCredentials();
            if ($definedCredentials) {
                return $definedCredentials;
            }
        }

        $accessKey = Arr::get($data, 'access_key');
        if (empty($accessKey)) {
            $accessKey = Arr::get($settings, 'access_key');
        }

        $secretKey = Arr::get($data, 'secret_key');
        if (empty($secretKey)) {
            $secretKey = Arr::get($settings, 'secret_key');
        }

        $accountId = Arr::get($data, 'account_id');
        if (empty($accountId)) {
            $accountId = Arr::get($settings, 'account_id');
        }

        return [
            'access_key' => $accessKey,
            'secret_key' => $secretKey,
            'account_id' => $accountId,
        ];
    }

    public function verifyConnectInfo(array $data, $args = [])
    {
        $credentialError = $this->requireCredentials($data);
        if ($credentialError) {
            return $credentialError;
        }

        $resolvedCredentials = $this->resolveCredentials($data);
        $accessKey = sanitize_text_field(Arr::get($resolvedCredentials, 'access_key', ''));
        $secretKey = (string) Arr::get($resolvedCredentials, 'secret_key', '');
        $accountId = sanitize_text_field(Arr::get($resolvedCredentials, 'account_id', ''));

        if (!$accessKey || !$secretKey || !$accountId) {
            return new \WP_Error('invalid_credentials', __('R2 credentials are not defined.', 'fluent-cart-pro'), ['status' => 422]);
        }

        $bucket = '';
        if (!Arr::get($data, 'verify_only_credentials')) {
            $bucket = sanitize_text_field(Arr::get($data, 'bucket', ''));
        }

        $result = R2ConnectionVerify::verify($accountId, $secretKey, $accessKey, $bucket);

        if (!is_wp_error($result)) {
            $result['is_active'] = 'yes';
        }

        return $result;
    }

    public function fields(): array
    {
        return [
            'is_active' => ['type' => 'checkbox'],
            'auth_method' => ['type' => 'text'],
            'account_id' => ['type' => 'text'],
            'access_key' => ['type' => 'text'],
            'secret_key' => ['type' => 'text'],
            'bucket' => ['type' => 'text'],
            'region' => ['type' => 'text'],
            'buckets' => ['type' => 'array'],
            'connection_error' => ['type' => 'text'],
        ];
    }

    public function getDriverClass(): string
    {
        return R2Driver::class;
    }

    public function hiddenSettingKeys(): array
    {
        return [
            'access_key',
            'secret_key',
            'account_id',
            'create_new_bucket',
            'new_bucket_name',
            'new_bucket_region',
            'verify_credentials',
            'verify_only_credentials',
            'preserve_settings',
            'check_bucket_exists',
        ];
    }

    private function requireCredentials(array $data)
    {
        $settings   = $this->getSettings();
        $authMethod = Arr::get($data, 'auth_method', Arr::get($settings, 'auth_method', 'define'));

        if ($authMethod === 'define' && !R2Settings::hasDefinedCredentials()) {
            return new \WP_Error(
                'missing_credentials',
                __('R2 credentials are not defined in wp-config.php. Please add them and try again.', 'fluent-cart-pro')
            );
        }

        return null;
    }
}
