<?php
/**
 * Normalized Facebook event value object.
 *
 * The common event shape produced by the Events Provider API and consumed
 * by the calendar target adapters. Recurring events are expanded so each
 * occurrence is its own NormalizedEvent.
 *
 * @package CustomFacebookFeed\Events_Integration
 * @since 4.11
 */

namespace CustomFacebookFeed\Events_Integration;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class NormalizedEvent {

	/**
	 * Facebook event ID.
	 *
	 * @var string
	 */
	public $source_event_id = '';

	/**
	 * Occurrence ID from event_times[], empty for non-recurring events.
	 *
	 * @var string
	 */
	public $occurrence_id = '';

	/**
	 * @var string
	 */
	public $title = '';

	/**
	 * @var string
	 */
	public $description = '';

	/**
	 * Event start, in the event's timezone.
	 *
	 * @var \DateTimeImmutable|null
	 */
	public $start;

	/**
	 * Event end, in the event's timezone. Always set: when Facebook omits
	 * end_time the normalizer applies a default duration.
	 *
	 * @var \DateTimeImmutable|null
	 */
	public $end;

	/**
	 * IANA timezone string, e.g. "Europe/Paris".
	 *
	 * @var string
	 */
	public $timezone = '';

	/**
	 * @var bool
	 */
	public $all_day = false;

	/**
	 * Whether the event is canceled on Facebook (mirrored as a deletion).
	 *
	 * @var bool
	 */
	public $is_canceled = false;

	/**
	 * Location parts: name, street, city, state, zip, country, latitude, longitude.
	 * Values may be empty strings when Facebook provides no place data.
	 *
	 * @var array
	 */
	public $location = array(
		'name'      => '',
		'street'    => '',
		'city'      => '',
		'state'     => '',
		'zip'       => '',
		'country'   => '',
		'latitude'  => '',
		'longitude' => '',
	);

	/**
	 * Cover image URL (may be empty).
	 *
	 * @var string
	 */
	public $cover_url = '';

	/**
	 * Graph updated_time as a UTC timestamp; 0 when unavailable.
	 *
	 * @var int
	 */
	public $updated_time = 0;

	/**
	 * @var string
	 */
	public $ticket_uri = '';

	/**
	 * Source page ID the event was fetched from.
	 *
	 * @var string
	 */
	public $source_id = '';

	/**
	 * Sync key uniquely identifying this event/occurrence across re-syncs.
	 *
	 * @return string
	 */
	public function sync_key() {
		return '' !== $this->occurrence_id
			? $this->source_event_id . '_' . $this->occurrence_id
			: $this->source_event_id;
	}

	/**
	 * Canonical Facebook permalink for the event.
	 *
	 * @return string
	 */
	public function permalink() {
		return 'https://facebook.com/events/' . $this->source_event_id;
	}

	/**
	 * Start timestamp (UTC), 0 when unknown.
	 *
	 * @return int
	 */
	public function start_timestamp() {
		return $this->start instanceof \DateTimeImmutable ? $this->start->getTimestamp() : 0;
	}

	/**
	 * End timestamp (UTC), 0 when unknown.
	 *
	 * @return int
	 */
	public function end_timestamp() {
		return $this->end instanceof \DateTimeImmutable ? $this->end->getTimestamp() : 0;
	}

	/**
	 * Single-line location string, e.g. "Venue Name, 1 Main St, Springfield, IL, USA".
	 *
	 * @return string
	 */
	public function location_string() {
		$parts = array_filter(
			array(
				$this->location['name'],
				$this->location['street'],
				$this->location['city'],
				$this->location['state'],
				$this->location['zip'],
				$this->location['country'],
			)
		);

		return implode( ', ', $parts );
	}
}
