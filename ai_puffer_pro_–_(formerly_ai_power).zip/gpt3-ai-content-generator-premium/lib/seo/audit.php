<?php

namespace WPAICG\SEO\Audit;

use WPAICG\ContentWriter\SEO\AIPKit_Content_Writer_SEO_Config;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Contract for one SEO audit check.
 */
interface AIPKit_SEO_Audit_Rule_Interface
{
    public function get_id(): string;

    public function get_label(): string;

    public function get_weight(): int;

    public function get_severity(): string;

    public function get_field(): string;

    public function is_fixable(): bool;

    public function applies(array $draft, array $context = []): bool;

    public function evaluate(array $draft, array $context = []): array;
}

/**
 * Shared helpers for SEO audit rules.
 */
abstract class AIPKit_SEO_Audit_Abstract_Rule implements AIPKit_SEO_Audit_Rule_Interface
{
    private $id;
    private $label;
    private $weight;
    private $severity;
    private $field;
    private $fixable;

    public function __construct(string $id, string $label, int $weight, string $severity, string $field, bool $fixable = true)
    {
        $this->id = $id;
        $this->label = $label;
        $this->weight = max(1, $weight);
        $this->severity = in_array($severity, ['low', 'medium', 'high'], true) ? $severity : 'medium';
        $this->field = $field;
        $this->fixable = $fixable;
    }

    public function get_id(): string
    {
        return $this->id;
    }

    public function get_label(): string
    {
        return $this->label;
    }

    public function get_weight(): int
    {
        return $this->weight;
    }

    public function get_severity(): string
    {
        return $this->severity;
    }

    public function get_field(): string
    {
        return $this->field;
    }

    public function is_fixable(): bool
    {
        return $this->fixable;
    }

    public function applies(array $draft, array $context = []): bool
    {
        return true;
    }

    protected function pass(string $message = '', array $extra = []): array
    {
        return array_merge(['status' => 'pass', 'message' => $message !== '' ? $message : $this->label], $extra);
    }

    protected function warning(string $message, array $extra = []): array
    {
        return array_merge(['status' => 'warning', 'message' => $message], $extra);
    }

    protected function fail(string $message, array $extra = []): array
    {
        return array_merge(['status' => 'fail', 'message' => $message], $extra);
    }

    protected function supports_focus_keyword(array $context): bool
    {
        if (array_key_exists('supports_focus_keyword', $context)) {
            return (bool) $context['supports_focus_keyword'];
        }

        return !$this->profile_in($context, ['framework', 'aipkit']);
    }

    protected function profile(array $context): string
    {
        return isset($context['profile']) ? sanitize_key((string) $context['profile']) : '';
    }

    protected function profile_is(array $context, string $profile): bool
    {
        return $this->profile($context) === $profile;
    }

    protected function profile_in(array $context, array $profiles): bool
    {
        return in_array($this->profile($context), $profiles, true);
    }

    protected function focus_keyword(array $draft): string
    {
        $keyword = trim((string) ($draft['focus_keyword'] ?? ''));
        if ($keyword === '') {
            return '';
        }

        $parts = array_map('trim', explode(',', $keyword));
        return $parts[0] ?? $keyword;
    }

    protected function clean_text(string $html): string
    {
        $text = function_exists('strip_shortcodes') ? strip_shortcodes($html) : $html;
        $text = wp_strip_all_tags($text);
        $text = html_entity_decode($text, ENT_QUOTES | ENT_HTML5, get_bloginfo('charset') ?: 'UTF-8');
        $text = preg_replace('/\s+/u', ' ', $text);
        return trim((string) $text);
    }

    protected function normalized_text(string $text): string
    {
        $text = function_exists('remove_accents') ? remove_accents($text) : $text;
        $text = function_exists('mb_strtolower') ? mb_strtolower($text, 'UTF-8') : strtolower($text);
        return preg_replace('/\s+/u', ' ', trim((string) $text));
    }

    protected function contains_phrase(string $haystack, string $needle): bool
    {
        $needle = $this->normalized_text($needle);
        if ($needle === '') {
            return false;
        }

        return strpos($this->normalized_text($haystack), $needle) !== false;
    }

    protected function starts_with_phrase(string $haystack, string $needle): bool
    {
        $needle = $this->normalized_text($needle);
        if ($needle === '') {
            return false;
        }

        $haystack = ltrim($this->normalized_text($this->clean_text($haystack)), " \t\n\r\0\x0B\"'“”‘’([{");
        if ($haystack === $needle) {
            return true;
        }

        return preg_match('/^' . preg_quote($needle, '/') . '(?=$|[^\p{L}\p{N}])/u', $haystack) === 1;
    }

    protected function word_count(string $text): int
    {
        $text = $this->clean_text($text);
        if ($text === '') {
            return 0;
        }

        if (preg_match_all('/[\p{L}\p{N}][\p{L}\p{N}\'-]*/u', $text, $matches)) {
            return count($matches[0]);
        }

        return str_word_count($text);
    }

    protected function get_sentences(string $html): array
    {
        $prepared = preg_replace('/<br\s*\/?>/i', '. ', $html);
        $prepared = preg_replace('/<\/(p|li|h[1-6]|blockquote|td|th)>/i', '. ', (string) $prepared);
        $text = $this->clean_text((string) $prepared);
        if ($text === '') {
            return [];
        }

        $parts = preg_split('/(?<=[.!?])\s+/u', $text);
        if (!is_array($parts)) {
            $parts = [$text];
        }

        $sentences = [];
        foreach ($parts as $part) {
            $sentence = trim((string) $part);
            $sentence = trim($sentence, " \t\n\r\0\x0B.?!;:");
            if ($sentence !== '' && $this->word_count($sentence) > 0) {
                $sentences[] = $sentence;
            }
        }

        return $sentences;
    }

    protected function get_sentence_first_word(string $sentence): string
    {
        $sentence = $this->clean_text($sentence);
        if ($sentence === '') {
            return '';
        }

        if (preg_match('/^[^\p{L}\p{N}]*([\p{L}\p{N}][\p{L}\p{N}\'’-]*)/u', $sentence, $match)) {
            return $this->normalized_text((string) $match[1]);
        }

        return '';
    }

    protected function first_words(string $text, int $limit): string
    {
        $text = $this->clean_text($text);
        if ($text === '') {
            return '';
        }

        $words = preg_split('/\s+/u', $text);
        return implode(' ', array_slice($words ?: [], 0, $limit));
    }

    protected function text_length(string $text): int
    {
        $text = trim(wp_strip_all_tags($text));
        return function_exists('mb_strlen') ? mb_strlen($text, 'UTF-8') : strlen($text);
    }

    protected function get_headings(string $html, array $levels = [2, 3]): array
    {
        $levels = array_values(array_filter(array_map('absint', $levels), static function (int $level): bool {
            return $level >= 1 && $level <= 6;
        }));
        $levels = !empty($levels) ? $levels : [2, 3];
        $level_pattern = implode('', array_unique($levels));

        if (!preg_match_all('/<h[' . preg_quote($level_pattern, '/') . '][^>]*>(.*?)<\/h[' . preg_quote($level_pattern, '/') . ']>/is', $html, $matches)) {
            return [];
        }

        return array_values(array_filter(array_map(function ($heading) {
            return $this->clean_text($heading);
        }, $matches[1])));
    }

    protected function count_h1_headings(string $html): int
    {
        if (!preg_match_all('/<h1\b[^>]*>.*?<\/h1>/is', $html, $matches)) {
            return 0;
        }

        return count($matches[0]);
    }

    protected function get_images(array $draft): array
    {
        $images = [];
        $content = (string) ($draft['content'] ?? '');

        if (preg_match_all('/<img\b[^>]*>/i', $content, $matches)) {
            foreach ($matches[0] as $tag) {
                $src = '';
                $alt = '';
                if (preg_match('/\bsrc=["\']([^"\']*)["\']/i', $tag, $src_match)) {
                    $src = trim((string) $src_match[1]);
                }
                if (preg_match('/\balt=["\']([^"\']*)["\']/i', $tag, $alt_match)) {
                    $alt = trim(wp_strip_all_tags((string) $alt_match[1]));
                }
                $images[] = [
                    'src' => $src,
                    'alt' => $alt,
                ];
            }
        }

        if (!empty($draft['images']) && is_array($draft['images'])) {
            foreach ($draft['images'] as $image) {
                if (!is_array($image)) {
                    continue;
                }
                $images[] = [
                    'src' => isset($image['src']) ? trim((string) $image['src']) : '',
                    'alt' => isset($image['alt']) ? trim(wp_strip_all_tags((string) $image['alt'])) : '',
                ];
            }
        }

        $seen = [];
        $unique_images = [];
        foreach ($images as $image) {
            $key = ($image['src'] ?? '') . '|' . ($image['alt'] ?? '');
            if (isset($seen[$key])) {
                continue;
            }
            $seen[$key] = true;
            $unique_images[] = $image;
        }

        return $unique_images;
    }

    protected function count_phrase_occurrences(string $text, string $phrase): int
    {
        $normalized_text = $this->normalized_text($this->clean_text($text));
        $normalized_phrase = $this->normalized_text($phrase);
        if ($normalized_text === '' || $normalized_phrase === '') {
            return 0;
        }

        $pattern = '/(?<![\p{L}\p{N}])' . preg_quote($normalized_phrase, '/') . '(?![\p{L}\p{N}])/u';
        $match_count = preg_match_all($pattern, $normalized_text, $matches);
        if ($match_count !== false) {
            return count($matches[0]);
        }

        return substr_count($normalized_text, $normalized_phrase);
    }

    protected function get_paragraphs(string $html): array
    {
        if (preg_match_all('/<p[^>]*>(.*?)<\/p>/is', $html, $matches)) {
            return array_values(array_filter(array_map(function ($paragraph) {
                return $this->clean_text($paragraph);
            }, $matches[1])));
        }

        return array_values(array_filter(array_map('trim', preg_split('/\R{2,}/u', $this->clean_text($html)) ?: [])));
    }

    protected function get_link_details(string $html): array
    {
        if (!preg_match_all('/<a\b([^>]*)>(.*?)<\/a>/is', $html, $matches, PREG_SET_ORDER)) {
            return [];
        }

        $links = [];
        foreach ($matches as $match) {
            $attributes = (string) ($match[1] ?? '');
            if (!preg_match('/\bhref=["\']([^"\']+)["\']/i', $attributes, $href_match)) {
                continue;
            }

            $rel = '';
            if (preg_match('/\brel=["\']([^"\']*)["\']/i', $attributes, $rel_match)) {
                $rel = trim((string) $rel_match[1]);
            }

            $links[] = [
                'href' => trim((string) $href_match[1]),
                'rel' => $rel,
                'anchor' => $this->clean_text((string) ($match[2] ?? '')),
            ];
        }

        return $links;
    }

    protected function link_has_rel(string $rel, string $token): bool
    {
        $rel = $this->normalized_text($rel);
        $token = $this->normalized_text($token);
        if ($rel === '' || $token === '') {
            return false;
        }

        $tokens = preg_split('/\s+/u', $rel) ?: [];
        return in_array($token, $tokens, true);
    }

    protected function get_site_host(array $context): string
    {
        $url = (string) ($context['site_url'] ?? $context['home_url'] ?? '');
        if ($url === '' && function_exists('home_url')) {
            $url = home_url();
        }

        $host = $url !== '' ? wp_parse_url($url, PHP_URL_HOST) : '';
        return is_string($host) ? preg_replace('/^www\./i', '', strtolower($host)) : '';
    }

    protected function is_internal_href(string $href, array $context): bool
    {
        $href = trim($href);
        if ($href === '' || strncmp($href, '#', strlen('#')) === 0 || preg_match('/^(mailto|tel|sms|javascript|data):/i', $href)) {
            return false;
        }

        if (strncmp($href, '/', strlen('/')) === 0 && strncmp($href, '//', strlen('//')) !== 0) {
            return true;
        }

        $host = wp_parse_url($href, PHP_URL_HOST);
        if (is_string($host) && $host !== '') {
            return preg_replace('/^www\./i', '', strtolower($host)) === $this->get_site_host($context);
        }

        return !preg_match('/^[a-z][a-z0-9+.-]*:/i', $href);
    }

    protected function is_external_href(string $href, array $context): bool
    {
        $href = trim($href);
        if ($href === '' || preg_match('/^(mailto|tel|sms|javascript|data):/i', $href)) {
            return false;
        }

        $host = wp_parse_url($href, PHP_URL_HOST);
        if (!is_string($host) || $host === '') {
            return false;
        }

        return $this->normalize_host($host) !== $this->get_site_host($context);
    }

    protected function is_safe_outbound_href(string $href, array $context): bool
    {
        $scheme = wp_parse_url($href, PHP_URL_SCHEME);
        if (!is_string($scheme) || strtolower($scheme) !== 'https') {
            return false;
        }

        if (!$this->is_external_href($href, $context)) {
            return false;
        }

        $host = wp_parse_url($href, PHP_URL_HOST);
        $host = is_string($host) ? $this->normalize_host($host) : '';
        if (!$this->is_safe_outbound_host($host)) {
            return false;
        }

        $path = wp_parse_url($href, PHP_URL_PATH);
        $path = is_string($path) ? strtolower($path) : '';
        if (preg_match('#/(login|signin|signup|cart|checkout|account)(/|$)#i', $path)) {
            return false;
        }

        return true;
    }

    protected function internal_href_resolves(string $href, array $context): bool
    {
        $absolute_url = $this->absolute_internal_url($href);
        if ($absolute_url === '') {
            return false;
        }

        $normalized_url = $this->normalize_url_for_comparison($absolute_url);
        $approved_urls = isset($context['approved_internal_urls']) && is_array($context['approved_internal_urls'])
            ? $context['approved_internal_urls']
            : [];
        foreach ($approved_urls as $approved_url) {
            $approved_absolute_url = $this->absolute_internal_url((string) $approved_url);
            if ($approved_absolute_url !== '' && $normalized_url === $this->normalize_url_for_comparison($approved_absolute_url)) {
                return true;
            }
        }

        if (!empty($approved_urls)) {
            return false;
        }

        $is_rank_math = $this->profile_is($context, 'rank_math');
        if (!$is_rank_math && empty($approved_urls) && $normalized_url === $this->normalize_url_for_comparison(home_url('/'))) {
            return true;
        }

        $post_id = url_to_postid($absolute_url);
        return $post_id > 0 && get_post_status($post_id) === 'publish';
    }

    private function absolute_internal_url(string $href): string
    {
        $href = trim($href);
        if ($href === '') {
            return '';
        }

        $host = wp_parse_url($href, PHP_URL_HOST);
        if (is_string($host) && $host !== '') {
            return esc_url_raw($href);
        }

        if (strncmp($href, '//', strlen('//')) === 0) {
            return '';
        }

        return esc_url_raw(home_url('/' . ltrim($href, '/')));
    }

    private function normalize_url_for_comparison(string $url): string
    {
        $url = esc_url_raw($url);
        $url = strtok($url, '#') ?: $url;
        $url = strtok($url, '?') ?: $url;
        return rtrim(strtolower($url), '/');
    }

    private function normalize_host(string $host): string
    {
        return preg_replace('/^www\./i', '', strtolower(trim($host)));
    }

    private function is_safe_outbound_host(string $host): bool
    {
        if ($host === '' || strpos($host, '.') === false || preg_match('/[^a-z0-9.-]/', $host)) {
            return false;
        }

        if (preg_match('/\.(local|localhost|test|invalid|example)$/i', $host)) {
            return false;
        }

        if (in_array($host, $this->blocked_outbound_hosts(), true)) {
            return false;
        }

        foreach ($this->blocked_outbound_host_suffixes() as $suffix) {
            if ($host === $suffix || substr_compare($host, '.' . $suffix, -strlen('.' . $suffix)) === 0) {
                return false;
            }
        }

        $ip = trim($host, '[]');
        if (filter_var($ip, FILTER_VALIDATE_IP)) {
            return filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE) !== false;
        }

        return (bool) preg_match('/\.[a-z]{2,}$/', $host);
    }

    private function blocked_outbound_hosts(): array
    {
        return [
            'example.com',
            'example.org',
            'example.net',
            'bit.ly',
            'tinyurl.com',
            't.co',
            'goo.gl',
            'ow.ly',
            'buff.ly',
            'rebrand.ly',
            'is.gd',
            'cutt.ly',
            'shorturl.at',
            'localhost',
        ];
    }

    private function blocked_outbound_host_suffixes(): array
    {
        return [
            'facebook.com',
            'instagram.com',
            'linkedin.com',
            'pinterest.com',
            'reddit.com',
            'tiktok.com',
            'x.com',
            'twitter.com',
            'youtube.com',
            'youtu.be',
        ];
    }
}

/**
 * Normalized SEO audit result for UI, logs, and post meta.
 */
class AIPKit_SEO_Audit_Result
{
    private $score;
    private $target;
    private $profile;
    private $checks;
    private $passed;
    private $warnings;
    private $failed;

    public function __construct(int $score, int $target, string $profile, array $checks)
    {
        $this->score = max(0, min($score, 100));
        $this->target = max(0, min($target, 100));
        $this->profile = $profile !== '' ? $profile : 'aipkit';
        $this->checks = array_values($checks);
        $this->passed = 0;
        $this->warnings = 0;
        $this->failed = 0;

        foreach ($this->checks as $check) {
            $status = isset($check['status']) ? (string) $check['status'] : '';
            if ($status === 'pass') {
                $this->passed++;
            } elseif ($status === 'warning') {
                $this->warnings++;
            } elseif ($status === 'fail') {
                $this->failed++;
            }
        }
    }

    public function get_score(): int
    {
        return $this->score;
    }

    public function get_target(): int
    {
        return $this->target;
    }

    public function get_profile(): string
    {
        return $this->profile;
    }

    public function get_checks(): array
    {
        return $this->checks;
    }

    public function reached_target(): bool
    {
        return $this->score >= $this->target;
    }

    public function to_array(): array
    {
        return [
            'score' => $this->score,
            'target' => $this->target,
            'profile' => $this->profile,
            'reached_target' => $this->reached_target(),
            'passed' => $this->passed,
            'warnings' => $this->warnings,
            'failed' => $this->failed,
            'checks' => $this->checks,
        ];
    }
}

/**
 * Holds the SEO audit rules used by an audit profile.
 */
class AIPKit_SEO_Audit_Rule_Registry
{
    private $rules = [];

    public function register(AIPKit_SEO_Audit_Rule_Interface $rule): void
    {
        $this->rules[$rule->get_id()] = $rule;
    }

    public function all(): array
    {
        return array_values($this->rules);
    }

    public function has_rules(): bool
    {
        return !empty($this->rules);
    }
}

/**
 * Creates the default Content Writer SEO audit rule registry.
 */
class AIPKit_SEO_Audit_Default_Registry
{
    public static function create(): AIPKit_SEO_Audit_Rule_Registry
    {
        $registry = new AIPKit_SEO_Audit_Rule_Registry();
        $rules = [
            new AIPKit_SEO_Audit_Focus_Keyword_Exists_Rule(),
            new AIPKit_SEO_Audit_Focus_Keyword_In_Title_Rule(),
            new AIPKit_SEO_Audit_Focus_Keyword_In_Introduction_Rule(),
            new AIPKit_SEO_Audit_Focus_Keyword_In_Meta_Rule(),
            new AIPKit_SEO_Audit_Focus_Keyword_In_Heading_Rule(),
            new AIPKit_SEO_Audit_Focus_Keyword_In_Slug_Rule(),
            new AIPKit_SEO_Audit_Focus_Keyword_Length_Rule(),
            new AIPKit_SEO_Audit_Meta_Description_Exists_Rule(),
            new AIPKit_SEO_Audit_Meta_Description_Length_Rule(),
            new AIPKit_SEO_Audit_Title_Length_Rule(),
            new AIPKit_SEO_Audit_Yoast_Title_Width_Rule(),
            new AIPKit_SEO_Audit_Rank_Math_Title_Start_Rule(),
            new AIPKit_SEO_Audit_Rank_Math_Title_Number_Rule(),
            new AIPKit_SEO_Audit_Rank_Math_Title_Power_Word_Rule(),
            new AIPKit_SEO_Audit_Rank_Math_Title_Sentiment_Rule(),
            new AIPKit_SEO_Audit_Rank_Math_Permalink_Length_Rule(),
            new AIPKit_SEO_Audit_AIOSEO_Keyphrase_In_Content_Rule(),
            new AIPKit_SEO_Audit_AIOSEO_Keyphrase_In_Introduction_Rule(),
            new AIPKit_SEO_Audit_AIOSEO_Keyphrase_In_Meta_Rule(),
            new AIPKit_SEO_Audit_AIOSEO_Keyphrase_In_Image_Alt_Rule(),
            new AIPKit_SEO_Audit_AIOSEO_Keyphrase_In_Subheadings_Rule(),
            new AIPKit_SEO_Audit_AIOSEO_Keyphrase_Length_Rule(),
            new AIPKit_SEO_Audit_AIOSEO_Meta_Description_Length_Rule(),
            new AIPKit_SEO_Audit_AIOSEO_Content_Length_Rule(),
            new AIPKit_SEO_Audit_AIOSEO_Internal_Link_Rule(),
            new AIPKit_SEO_Audit_AIOSEO_External_Link_Rule(),
            new AIPKit_SEO_Audit_AIOSEO_Title_Beginning_Rule(),
            new AIPKit_SEO_Audit_AIOSEO_Title_Length_Rule(),
            new AIPKit_SEO_Audit_AIOSEO_Headline_Score_Rule(),
            new AIPKit_SEO_Audit_AIOSEO_Content_Assets_Rule(),
            new AIPKit_SEO_Audit_AIOSEO_Sentence_Length_Rule(),
            new AIPKit_SEO_Audit_AIOSEO_Passive_Voice_Rule(),
            new AIPKit_SEO_Audit_AIOSEO_Transition_Words_Rule(),
            new AIPKit_SEO_Audit_AIOSEO_Consecutive_Sentences_Rule(),
            new AIPKit_SEO_Audit_AIOSEO_Subheading_Distribution_Rule(),
            new AIPKit_SEO_Audit_AIOSEO_Flesch_Reading_Rule(),
            new AIPKit_SEO_Audit_Content_Length_Rule(),
            new AIPKit_SEO_Audit_Paragraph_Length_Rule(),
            new AIPKit_SEO_Audit_Heading_Distribution_Rule(),
            new AIPKit_SEO_Audit_Rank_Math_TOC_Rule(),
            new AIPKit_SEO_Audit_Yoast_Consecutive_Sentence_Starts_Rule(),
            new AIPKit_SEO_Audit_Yoast_Transition_Words_Rule(),
            new AIPKit_SEO_Audit_Yoast_Sentence_Length_Rule(),
            new AIPKit_SEO_Audit_Yoast_Passive_Voice_Rule(),
            new AIPKit_SEO_Audit_Internal_Link_Rule(),
            new AIPKit_SEO_Audit_External_Link_Rule(),
            new AIPKit_SEO_Audit_Image_Exists_Rule(),
            new AIPKit_SEO_Audit_Rank_Math_Content_Assets_Rule(),
            new AIPKit_SEO_Audit_Image_Alt_Keyphrase_Rule(),
            new AIPKit_SEO_Audit_Single_H1_Rule(),
            new AIPKit_SEO_Audit_Previously_Used_Keyphrase_Rule(),
            new AIPKit_SEO_Audit_Competing_Links_Rule(),
            new AIPKit_SEO_Audit_Keyword_Density_Rule(),
            new AIPKit_SEO_Audit_Rank_Math_Keyword_Density_Rule(),
        ];

        foreach ($rules as $rule) {
            $registry->register($rule);
        }

        return $registry;
    }
}

/**
 * Runs SEO audit rules against generated draft content.
 */
class AIPKit_SEO_Audit_Engine
{
    private $registry;

    public function __construct(?AIPKit_SEO_Audit_Rule_Registry $registry = null)
    {
        $this->registry = $registry ?: AIPKit_SEO_Audit_Default_Registry::create();
    }

    public function audit(array $draft, array $context = []): AIPKit_SEO_Audit_Result
    {
        $draft = $this->normalize_draft($draft);
        $target = isset($context['target']) ? absint($context['target']) : 100;
        $target = max(0, min($target, 100));
        $profile = isset($context['profile']) ? sanitize_key((string) $context['profile']) : 'aipkit';
        $profile = $profile !== '' ? $profile : 'aipkit';

        $checks = [];
        $earned_weight = 0.0;
        $total_weight = 0;
        $disabled_rule_ids = $this->disabled_rule_id_set($context);
        $disabled_applicable_rules = 0;

        foreach ($this->registry->all() as $rule) {
            if (isset($disabled_rule_ids[$rule->get_id()])) {
                if ($rule->applies($draft, $context)) {
                    $disabled_applicable_rules++;
                }
                continue;
            }

            if (!$rule->applies($draft, $context)) {
                continue;
            }

            $weight = max(1, $rule->get_weight());
            $check = $this->normalize_check($rule, $rule->evaluate($draft, $context), $weight);
            $checks[] = $check;
            $total_weight += $weight;
            $earned_weight += $weight * $check['score_fraction'];
        }

        $score = $total_weight > 0 ? (int) round(($earned_weight / $total_weight) * 100) : ($disabled_applicable_rules > 0 ? 100 : 0);

        return new AIPKit_SEO_Audit_Result($score, $target, $profile, $checks);
    }

    private function disabled_rule_id_set(array $context): array
    {
        $raw_ids = $context['disabled_rule_ids']
            ?? $context['seo_score_disabled_rules']
            ?? (class_exists(AIPKit_Content_Writer_SEO_Config::class) ? AIPKit_Content_Writer_SEO_Config::default_disabled_rule_ids() : []);
        if (is_string($raw_ids)) {
            $decoded = json_decode(trim($raw_ids), true);
            if (!is_array($decoded)) {
                $decoded = json_decode(stripslashes(trim($raw_ids)), true);
            }
            $raw_ids = is_array($decoded) ? $decoded : explode(',', $raw_ids);
        }

        if (!is_array($raw_ids)) {
            return [];
        }

        $disabled = [];
        foreach ($raw_ids as $key => $raw_rule_id) {
            $rule_id = is_string($key) && !is_numeric($key) && !empty($raw_rule_id)
                ? $key
                : $raw_rule_id;
            if (!is_scalar($rule_id)) {
                continue;
            }

            $rule_id = sanitize_key((string) $rule_id);
            if ($rule_id !== '') {
                $disabled[$rule_id] = true;
            }
        }

        return $disabled;
    }

    private function normalize_draft(array $draft): array
    {
        $defaults = [
            'title' => '',
            'content' => '',
            'meta_description' => '',
            'focus_keyword' => '',
            'excerpt' => '',
            'tags' => '',
            'slug' => '',
            'post_type' => 'post',
            'images' => [],
            'featured_image_alt' => '',
        ];

        $normalized = wp_parse_args($draft, $defaults);
        foreach ($defaults as $key => $default) {
            if ($key === 'images') {
                $normalized[$key] = is_array($normalized[$key]) ? $normalized[$key] : [];
                continue;
            }

            $normalized[$key] = is_scalar($normalized[$key]) ? (string) $normalized[$key] : $default;
        }

        return $normalized;
    }

    private function normalize_check(AIPKit_SEO_Audit_Rule_Interface $rule, array $raw_check, int $weight): array
    {
        $status = isset($raw_check['status']) ? sanitize_key((string) $raw_check['status']) : 'fail';
        if (!in_array($status, ['pass', 'warning', 'fail'], true)) {
            $status = 'fail';
        }

        $severity = isset($raw_check['severity']) ? sanitize_key((string) $raw_check['severity']) : $rule->get_severity();
        if (!in_array($severity, ['low', 'medium', 'high'], true)) {
            $severity = 'medium';
        }

        $field = isset($raw_check['field']) ? sanitize_key((string) $raw_check['field']) : $rule->get_field();
        $message = isset($raw_check['message']) ? sanitize_text_field((string) $raw_check['message']) : $rule->get_label();

        return [
            'id' => $rule->get_id(),
            'label' => $rule->get_label(),
            'status' => $status,
            'severity' => $severity,
            'field' => $field,
            'fixable' => isset($raw_check['fixable']) ? (bool) $raw_check['fixable'] : $rule->is_fixable(),
            'message' => $message,
            'weight' => $weight,
            'score_fraction' => $this->normalize_score_fraction($raw_check, $status),
        ];
    }

    private function normalize_score_fraction(array $raw_check, string $status): float
    {
        if (isset($raw_check['score_fraction']) && is_numeric($raw_check['score_fraction'])) {
            return max(0.0, min((float) $raw_check['score_fraction'], 1.0));
        }

        switch ($status) {
            case 'pass':
                return 1.0;
            case 'warning':
                return 0.5;
            default:
                return 0.0;
        }
    }
}
