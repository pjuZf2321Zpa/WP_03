<?php

defined('ABSPATH') || exit;

/**
 * Sends a cart order's receipt after a delay, so funnel upsells purchased post-checkout are included.
 *
 * @property int $order_id The cart order ID.
 */
class MeprCartReceiptJob extends MeprBaseJob
{
    /**
     * Perform this job.
     */
    public function perform()
    {
        $order_id = (int) ($this->order_id ?? 0);

        if ($order_id <= 0 || !class_exists('MeprOrder')) {
            return;
        }

        $order = new MeprOrder($order_id);

        // Only ever send a cart receipt for an actual cart order.
        if ((int) $order->id > 0 && $order->order_type === MeprOrder::$cart_type_str) {
            MeprCartCheckoutService::send_cart_receipt_once($order);
        }
    }
}
