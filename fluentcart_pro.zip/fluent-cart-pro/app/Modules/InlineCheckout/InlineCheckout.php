<?php

namespace FluentCartPro\App\Modules\InlineCheckout;

use FluentCartPro\App\Modules\InlineCheckout\Cart\InlineCartService;
use FluentCartPro\App\Modules\InlineCheckout\Checkout\CheckoutSurface;
use FluentCartPro\App\Modules\InlineCheckout\Checkout\ItemsFragment;
use FluentCartPro\App\Modules\InlineCheckout\Editor\CheckoutBlockAttributes;
use FluentCartPro\App\Modules\InlineCheckout\Http\InlineCheckoutAjaxHandler;
use FluentCartPro\App\Modules\InlineCheckout\Scheduler\AbandonedInlineCartSweeper;

/**
 * Checkout Product Selector.
 *
 * Lets a store owner turn any existing checkout — the `fluent-cart/checkout`
 * block or the `[fluent_cart_checkout]` shortcode — into one that OFFERS
 * products for the shopper to pick from, so a landing page can carry a working
 * "choose your plan and pay" form without the shopper ever visiting a product
 * page.
 *
 * It is a mode of the existing checkout, not a new block. Configure variations
 * and the summary becomes a selectable list; configure nothing and the checkout
 * behaves exactly as it always did. That opt-in split is the design guarantee:
 * every checkout on every store is untouched until an author asks for this.
 *
 * There is deliberately no module settings toggle. Order Bump has one because
 * it gates real setup cost — two tables, an admin screen, REST routes, a
 * migration. This has none of those, and the opt-in already exists at exactly
 * the right granularity: per checkout, in the author's hands. A store-wide off
 * switch would only add a way to silently empty every live offer page.
 */
class InlineCheckout
{
    /**
     * @param \FluentCart\Framework\Foundation\Application $app
     * @return void
     */
    public function register($app): void
    {
        // The storefront surfaces.
        (new CheckoutSurface())->register();
        (new ItemsFragment())->register();
        (new InlineCheckoutAjaxHandler())->register();

        // The block inspector.
        (new CheckoutBlockAttributes())->register();

        // Garbage collection for carts nobody came back to.
        (new AbandonedInlineCartSweeper())->register();

        // Teach core's hash lookup about this module's cart group, so every
        // later checkout request — coupon, address, place order — resolves the
        // same row the selector rendered from.
        //
        // Unconditional, and it stays registered for the life of the module: a
        // cart materialized yesterday must still resolve today.
        add_filter('fluent_cart/cart/hash_resolvable_cart_groups', function ($groups) {
            $groups[] = InlineCartService::CART_GROUP;

            return $groups;
        });
    }
}
