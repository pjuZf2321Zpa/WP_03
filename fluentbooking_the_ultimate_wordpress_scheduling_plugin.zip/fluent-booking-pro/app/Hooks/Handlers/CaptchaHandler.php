<?php

namespace FluentBookingPro\App\Hooks\Handlers;

use FluentBooking\App\Models\Booking;
use FluentBooking\Framework\Support\Arr;
use FluentBookingPro\App\Services\Captcha\CaptchaManager;

class CaptchaHandler
{
    public function register()
    {
        add_filter('fluent_booking/settings_menu_items', [$this, 'enableMenuItem'], 10, 1);
        add_filter('fluent_calendar/global_booking_vars', [$this, 'addPublicVars'], 10, 1);
        add_filter('fluent_booking/pre_schedule_validation_error', [$this, 'verify'], 10, 3);
        add_filter('fluent_booking/dashboard_notices', [$this, 'maybeAddSetupNotice'], 10, 1);
    }

    /**
     * Free registers the item as disabled; pro switches it on.
     *
     * @param array $items
     * @return array
     */
    public function enableMenuItem($items)
    {
        if (isset($items['spam_protection'])) {
            $items['spam_protection']['disable'] = false;
        }

        return $items;
    }

    /**
     * @param array $vars
     * @return array
     */
    public function addPublicVars($vars)
    {
        $captcha = CaptchaManager::publicVars();

        if ($captcha) {
            $vars['captcha'] = $captcha;
        }

        return $vars;
    }

    /**
     * Reject a public booking request that carries no valid captcha token.
     *
     * @param \WP_Error|null $error
     * @param array          $postedData
     * @param mixed          $calendarEvent
     * @return \WP_Error|null
     */
    public function verify($error, $postedData, $calendarEvent = null)
    {
        if (is_wp_error($error)) {
            return $error;
        }

        // A reschedule is not a new booking, and its page shows no widget. The
        // hash is unchecked public input, so only a hash that belongs to a real
        // booking on this event skips the captcha.
        if ($this->isReschedule(Arr::get($postedData, 'rescheduling_hash'), $calendarEvent)) {
            return $error;
        }

        $result = CaptchaManager::verifyRequest($postedData, $calendarEvent);

        return is_wp_error($result) ? $result : $error;
    }

    /**
     * @param mixed $hash
     * @param mixed $calendarEvent
     * @return bool
     */
    private function isReschedule($hash, $calendarEvent)
    {
        if (!$hash || !is_string($hash) || !$calendarEvent) {
            return false;
        }

        return (bool)Booking::where('hash', sanitize_text_field($hash))
            ->where('event_id', $calendarEvent->id)
            ->first();
    }

    /**
     * The plugin's own admin screens drop WordPress admin notices, so the
     * warning goes through the dashboard notice list the Vue app renders.
     *
     * @param array $notices
     * @return array
     */
    public function maybeAddSetupNotice($notices)
    {
        if (!current_user_can('manage_options')) {
            return $notices;
        }

        $error = CaptchaManager::getSetupError();

        if (!$error) {
            return $notices;
        }

        $message = sprintf(
            /* translators: %s: the captcha provider name, for example Google reCAPTCHA. */
            __('Spam protection: %s refused the secret key, so FluentBooking accepts bookings without a check. Open Settings, Spam Protection and save the correct keys.', 'fluent-booking-pro'),
            (string)Arr::get($error, 'provider', '')
        );

        // The `error` class is what the dashboard notice block styles.
        $notices[] = '<div class="error">' . esc_html($message) . '</div>';

        return $notices;
    }
}
