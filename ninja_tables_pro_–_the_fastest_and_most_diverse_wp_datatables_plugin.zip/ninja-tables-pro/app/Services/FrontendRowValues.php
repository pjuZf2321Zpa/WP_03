<?php

namespace NinjaTablesPro\App\Services;

use NinjaTables\Framework\Support\Arr;

class FrontendRowValues
{
    /**
     * Keys of the columns the table's front-end editor is allowed to write.
     */
    public static function editableKeys($tableId)
    {
        $editPref = get_post_meta($tableId, '_ninja_table_frontedit_pref', true);
        if (!$editPref || empty($editPref['editing_items']) || !is_array($editPref['editing_items'])) {
            return array();
        }

        return array_keys(array_filter($editPref['editing_items'], function ($val) {
            return $val == 'yes';
        }));
    }

    /**
     * Drop every submitted key that is not an editable column. The editor form
     * only has inputs for editable columns, so anything else was hand-crafted.
     * Administrators are not limited: they can edit any cell in wp-admin anyway.
     */
    public static function onlyEditable($tableId, array $values)
    {
        if (current_user_can('administrator')) {
            return $values;
        }

        return array_intersect_key($values, array_flip(self::editableKeys($tableId)));
    }

    /**
     * wp_kses() keeps URL schemes in plain text, so link-type columns are
     * cleaned here before they are stored.
     */
    public static function sanitizeUrlColumns($tableId, array $values)
    {
        foreach (ninja_table_get_table_columns($tableId, 'admin') as $column) {
            $key  = Arr::get($column, 'key');
            $type = Arr::get($column, 'data_type');

            if (!isset($values[$key])) {
                continue;
            }

            if ($type === 'button' && is_scalar($values[$key])) {
                $values[$key] = esc_url_raw((string) $values[$key]);
            } elseif ($type === 'image' && is_array($values[$key])) {
                foreach (array('image_thumb', 'image_full', 'permalink') as $urlKey) {
                    if (isset($values[$key][$urlKey]) && is_scalar($values[$key][$urlKey])) {
                        $values[$key][$urlKey] = esc_url_raw((string) $values[$key][$urlKey]);
                    }
                }
            }
        }

        return $values;
    }

    /**
     * Encode shortcode brackets in front-end-submitted text so a stored value
     * such as "[gallery]" cannot execute when the cell is later rendered.
     * Default-provider cells are run through do_shortcode on output as trusted,
     * admin-authored content; with front-end editing on, a non-admin can write
     * them, so their brackets are neutralised here. Entities render as literal
     * brackets, so legitimate text is unaffected. Admins are not touched.
     */
    public static function neutralizeShortcodes(array $values)
    {
        foreach ($values as $key => $value) {
            if (is_array($value)) {
                $values[$key] = self::neutralizeShortcodes($value);
            } elseif (is_string($value)) {
                $values[$key] = str_replace(['[', ']'], ['&#91;', '&#93;'], $value);
            }
        }

        return $values;
    }
}
