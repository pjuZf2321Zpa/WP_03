<?php

namespace WPAICG\ContentWriter\Ajax\Actions;

use WPAICG\ContentWriter\Ajax\AIPKit_Content_Writer_Base_Ajax_Action;
use WPAICG\ContentWriter\SEO\AIPKit_Content_Writer_SEO_Config;
use WPAICG\ContentWriter\SEO\AIPKit_Content_Writer_Smart_SEO_Image_Tag_Guard;
use WPAICG\ContentWriter\SEO\AIPKit_Content_Writer_Smart_SEO_Internal_Link_Helper;
use WPAICG\SEO\AIPKit_SEO_Helper;
use WPAICG\SEO\Audit\AIPKit_SEO_Audit_Engine;
use WP_Error;
use WPAICG\ContentWriter\SEO\AIPKit_Content_Writer_Smart_SEO_AIOSEO_Content_Helper;
use WPAICG\ContentWriter\SEO\AIPKit_Content_Writer_Smart_SEO_AIOSEO_Headline_Helper;
use WPAICG\ContentWriter\SEO\AIPKit_Content_Writer_Smart_SEO_External_Link_Helper;
use WPAICG\ContentWriter\SEO\AIPKit_Content_Writer_Smart_SEO_Keyphrase_Content_Helper;
use WPAICG\ContentWriter\SEO\AIPKit_Content_Writer_Smart_SEO_Keyword_Resolver;
use WPAICG\ContentWriter\SEO\AIPKit_Content_Writer_Smart_SEO_Model_Policy;
use WPAICG\ContentWriter\SEO\AIPKit_Content_Writer_Smart_SEO_Naturalness_Guard;
use WPAICG\ContentWriter\SEO\AIPKit_Content_Writer_Smart_SEO_Prompt_Guidance_Trait;
use WPAICG\ContentWriter\SEO\AIPKit_Content_Writer_SEO_Audit_Context_Trait;
use WPAICG\ContentWriter\SEO\AIPKit_Content_Writer_SEO_Revision_Context_Trait;
use WPAICG\ContentWriter\SEO\AIPKit_Content_Writer_Smart_SEO_Title_Helper;
use WPAICG\ContentWriter\SEO\AIPKit_Content_Writer_Smart_SEO_Yoast_Content_Helper;

if (!defined('ABSPATH')) {
    exit;
}

/** Shared draft image decoding; each action retains its own image inclusion policy. */
trait AIPKit_Content_Writer_SEO_Images_Trait
{
    use \WPAICG\ContentWriter\SEO\AIPKit_Content_Writer_SEO_Image_Context_Trait;

    private function extract_featured_image_alt(array $raw_post): string
    {
        $image_data = $this->decode_image_data($raw_post);
        if (empty($image_data)) {
            return '';
        }

        foreach (['featured_image_alt', 'featured_alt', 'featured_alt_text'] as $key) {
            if (!empty($image_data[$key]) && is_scalar($image_data[$key])) {
                return sanitize_text_field((string) $image_data[$key]);
            }
        }

        $attachment_id = isset($image_data['featured_image_id']) ? absint($image_data['featured_image_id']) : 0;
        if ($attachment_id > 0) {
            $stored_alt = get_post_meta($attachment_id, '_wp_attachment_image_alt', true);
            return is_string($stored_alt) ? sanitize_text_field($stored_alt) : '';
        }

        return '';
    }

    private function decode_image_data(array $raw_post): array
    {
        $image_data = $raw_post['draft_image_data'] ?? null;
        if (is_string($image_data)) {
            $decoded = json_decode(trim($image_data), true);
            if (!is_array($decoded)) {
                $decoded = json_decode(stripslashes(trim($image_data)), true);
            }
            $image_data = is_array($decoded) ? $decoded : [];
        }

        return is_array($image_data) ? $image_data : [];
    }
}

/**
 * Runs the paid SEO audit against a generated Content Writer draft.
 */
class AIPKit_Content_Writer_SEO_Audit_Action extends AIPKit_Content_Writer_Base_Ajax_Action
{
    use AIPKit_Content_Writer_SEO_Images_Trait;
    use AIPKit_Content_Writer_SEO_Audit_Context_Trait;

    public function handle(): void
    {
        $permission_check = $this->check_module_access_permissions('content-writer', 'aipkit_content_writer_nonce');
        if (is_wp_error($permission_check)) {
            $this->send_wp_error($permission_check);
            return;
        }

        if (!class_exists(AIPKit_Content_Writer_SEO_Config::class) || !AIPKit_Content_Writer_SEO_Config::is_pro_plan()) {
            $this->send_wp_error(new WP_Error(
                'pro_feature_required',
                __('SEO score audits are a Pro feature. Please upgrade.', 'gpt3-ai-content-generator'),
                ['status' => 403]
            ));
            return;
        }

        if (!class_exists(AIPKit_SEO_Audit_Engine::class)) {
            $this->send_wp_error(new WP_Error(
                'missing_seo_audit_engine',
                __('SEO audit engine is unavailable.', 'gpt3-ai-content-generator'),
                ['status' => 500]
            ));
            return;
        }

        // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce checked above.
        $raw_post = wp_unslash($_POST);
        $config = AIPKit_Content_Writer_SEO_Config::normalize(is_array($raw_post) ? $raw_post : [], false, true);
        $profile = $this->resolve_profile((string) ($config[AIPKit_Content_Writer_SEO_Config::KEY_PROFILE] ?? 'auto'));
        $target = absint($config[AIPKit_Content_Writer_SEO_Config::KEY_TARGET] ?? 100);
        $target = max(80, min($target, 100));
        $exclude_post_id = $this->resolve_excluded_post_id($raw_post);
        $disabled_rule_ids = AIPKit_Content_Writer_SEO_Config::disabled_rule_ids($config);

        $draft = [
            'title' => isset($raw_post['draft_title']) ? sanitize_text_field((string) $raw_post['draft_title']) : '',
            'content' => isset($raw_post['draft_content']) ? wp_kses_post((string) $raw_post['draft_content']) : '',
            'meta_description' => isset($raw_post['draft_meta_description']) ? sanitize_textarea_field((string) $raw_post['draft_meta_description']) : '',
            'focus_keyword' => isset($raw_post['draft_focus_keyword']) ? sanitize_text_field((string) $raw_post['draft_focus_keyword']) : '',
            'excerpt' => isset($raw_post['draft_excerpt']) ? sanitize_textarea_field((string) $raw_post['draft_excerpt']) : '',
            'tags' => isset($raw_post['draft_tags']) ? sanitize_text_field((string) $raw_post['draft_tags']) : '',
            'slug' => isset($raw_post['draft_slug']) ? sanitize_title((string) $raw_post['draft_slug']) : '',
            'post_type' => isset($raw_post['post_type']) ? sanitize_key((string) $raw_post['post_type']) : 'post',
            'images' => $this->extract_images($raw_post),
            'featured_image_alt' => $this->extract_featured_image_alt($raw_post),
        ];
        if (class_exists(AIPKit_Content_Writer_Smart_SEO_Image_Tag_Guard::class)) {
            $draft = AIPKit_Content_Writer_Smart_SEO_Image_Tag_Guard::sanitize_draft($draft);
        }

        if ($draft['title'] === '' && $draft['content'] === '') {
            $this->send_wp_error(new WP_Error(
                'missing_seo_audit_draft',
                __('Generated title or content is required for SEO audit.', 'gpt3-ai-content-generator'),
                ['status' => 400]
            ));
            return;
        }

        $internal_link_candidates = class_exists(AIPKit_Content_Writer_Smart_SEO_Internal_Link_Helper::class)
            ? AIPKit_Content_Writer_Smart_SEO_Internal_Link_Helper::get_candidates($draft, [
                'topic' => isset($raw_post['content_title']) ? sanitize_text_field((string) $raw_post['content_title']) : '',
                'keywords' => isset($raw_post['content_keywords']) ? sanitize_text_field((string) $raw_post['content_keywords']) : '',
                'profile' => $profile['profile'],
                'home_url' => home_url(),
                'site_url' => site_url(),
            ])
            : [];
        $context = [
            'target' => $target,
            'profile' => $profile['profile'],
            'profile_label' => $profile['label'],
            'supports_focus_keyword' => $profile['supports_focus_keyword'],
            'generate_seo_slug' => isset($raw_post['generate_seo_slug']) && (string) $raw_post['generate_seo_slug'] === '1' ? '1' : '0',
            'generate_toc' => isset($raw_post['generate_toc']) && (string) $raw_post['generate_toc'] === '1' ? '1' : '0',
            'min_words' => $this->minimum_words_for_length(isset($raw_post['content_length']) ? sanitize_key((string) $raw_post['content_length']) : 'medium'),
            'home_url' => home_url(),
            'site_url' => site_url(),
            'used_focus_keyword_count' => $this->count_used_focus_keyword($draft['focus_keyword'], $exclude_post_id),
            'disabled_rule_ids' => $disabled_rule_ids,
            'approved_internal_urls' => class_exists(AIPKit_Content_Writer_Smart_SEO_Internal_Link_Helper::class)
                ? AIPKit_Content_Writer_Smart_SEO_Internal_Link_Helper::get_candidate_urls($internal_link_candidates)
                : [],
        ];

        $engine = new AIPKit_SEO_Audit_Engine();
        $result = $engine->audit($draft, $context)->to_array();
        $result['profile_label'] = $profile['label'];
        $result['profile_logo_url'] = $profile['logo_url'] ?? '';
        $result['profile_logo_initials'] = $profile['logo_initials'] ?? '';
        $result['status'] = !empty($result['reached_target']) ? 'target_reached' : 'needs_review';
        $result['passes'] = 0;
        $result['max_passes'] = absint($config[AIPKit_Content_Writer_SEO_Config::KEY_MAX_PASSES] ?? 3);
        $result['can_improve'] = $this->has_fixable_issue($result['checks'] ?? []);
        $result['disabled_rule_ids'] = $disabled_rule_ids;

        wp_send_json_success($result);
    }

    private function extract_images(array $raw_post): array
    {
        $image_data = $this->decode_image_data($raw_post);
        if (empty($image_data)) {
            return [];
        }

        $images = [];
        foreach ($image_data['in_content_images'] ?? [] as $image) {
            if (!is_array($image)) {
                continue;
            }
            $images[] = $this->normalize_image($image);
        }

        return array_values(array_filter($images, static function (array $image): bool {
            return ($image['src'] ?? '') !== '' || ($image['alt'] ?? '') !== '';
        }));
    }

    private function resolve_excluded_post_id(array $raw_post): int
    {
        foreach (['exclude_post_id', 'post_id', 'current_post_id', 'draft_post_id', 'object_id', 'objectID'] as $key) {
            $post_id = isset($raw_post[$key]) ? absint($raw_post[$key]) : 0;
            if ($post_id > 0) {
                return $post_id;
            }
        }

        return 0;
    }

}

/**
 * Improves a generated Content Writer draft against failed SEO audit checks.
 */
class AIPKit_Content_Writer_SEO_Improve_Action extends AIPKit_Content_Writer_Base_Ajax_Action
{
    use AIPKit_Content_Writer_SEO_Images_Trait;
    use AIPKit_Content_Writer_Smart_SEO_Prompt_Guidance_Trait;
    use AIPKit_Content_Writer_SEO_Revision_Context_Trait;

    public function handle(): void
    {
        $permission_check = $this->check_module_access_permissions('content-writer', 'aipkit_content_writer_nonce');
        if (is_wp_error($permission_check)) {
            $this->send_wp_error($permission_check);
            return;
        }

        if (!class_exists(AIPKit_Content_Writer_SEO_Config::class) || !AIPKit_Content_Writer_SEO_Config::is_pro_plan()) {
            $this->send_wp_error(new WP_Error(
                'pro_feature_required',
                __('SEO score improvement is a Pro feature. Please upgrade.', 'gpt3-ai-content-generator'),
                ['status' => 403]
            ));
            return;
        }

        if (!$this->get_ai_caller()) {
            $this->send_wp_error(new WP_Error(
                'missing_ai_caller',
                __('AI generation component is unavailable.', 'gpt3-ai-content-generator'),
                ['status' => 500]
            ));
            return;
        }

        // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce checked above.
        $raw_post = wp_unslash($_POST);
        $config = AIPKit_Content_Writer_SEO_Config::normalize(is_array($raw_post) ? $raw_post : [], false, true);
        if (($config[AIPKit_Content_Writer_SEO_Config::KEY_ENABLED] ?? '0') !== '1') {
            $this->send_wp_error(new WP_Error(
                'seo_improvement_disabled',
                __('SEO score improvement is not enabled for this request.', 'gpt3-ai-content-generator'),
                ['status' => 400]
            ));
            return;
        }

        $draft = $this->extract_draft(is_array($raw_post) ? $raw_post : []);
        if ($draft['title'] === '' && $draft['content'] === '') {
            $this->send_wp_error(new WP_Error(
                'missing_seo_improvement_draft',
                __('Generated title or content is required for SEO improvement.', 'gpt3-ai-content-generator'),
                ['status' => 400]
            ));
            return;
        }

        $checks = $this->extract_fixable_checks(is_array($raw_post) ? $raw_post : []);
        if (empty($checks)) {
            wp_send_json_success([
                'draft' => $draft,
                'changes' => __('No fixable SEO issues were available for an automatic pass.', 'gpt3-ai-content-generator'),
                'changed' => false,
            ]);
            return;
        }

        $provider = $this->normalize_provider(isset($raw_post['ai_provider']) ? sanitize_text_field((string) $raw_post['ai_provider']) : '');
        $model = isset($raw_post['ai_model']) ? sanitize_text_field((string) $raw_post['ai_model']) : '';
        if ($provider === '' || $model === '') {
            $this->send_wp_error(new WP_Error(
                'missing_ai_model',
                __('AI provider and model are required for SEO improvement.', 'gpt3-ai-content-generator'),
                ['status' => 400]
            ));
            return;
        }

        $target = max(80, min(absint($config[AIPKit_Content_Writer_SEO_Config::KEY_TARGET] ?? 100), 100));
        $profile = $this->resolve_profile((string) ($config[AIPKit_Content_Writer_SEO_Config::KEY_PROFILE] ?? 'auto'));
        $disabled_rule_ids = AIPKit_Content_Writer_SEO_Config::disabled_rule_ids($config);
        $original_draft = $draft;
        $profile_label = isset($raw_post['profile_label'])
            ? sanitize_text_field((string) $raw_post['profile_label'])
            : $profile['label'];
        $pass = max(1, absint($raw_post['seo_improvement_pass'] ?? 1));
        $current_score = max(0, min(absint($raw_post['current_score'] ?? 0), 100));
        $change_summaries = [];
        $usage = null;
        $smart_seo_model = null;
        $smart_seo_model_fallbacks = [];

        $prompt_context = [
            'target' => $target,
            'profile' => $profile['profile'],
            'profile_label' => $profile_label,
            'pass' => $pass,
            'current_score' => $current_score,
            'topic' => isset($raw_post['content_title']) ? sanitize_text_field((string) $raw_post['content_title']) : '',
            'keywords' => isset($raw_post['content_keywords']) ? sanitize_text_field((string) $raw_post['content_keywords']) : '',
            'home_url' => home_url(),
            'site_url' => site_url(),
            'disabled_rule_ids' => $disabled_rule_ids,
        ];
        $checks = $this->filter_disabled_checks($checks, $disabled_rule_ids);
        if (empty($checks)) {
            wp_send_json_success([
                'draft' => $draft,
                'changes' => __('All available SEO issues are disabled for this Smart SEO pass.', 'gpt3-ai-content-generator'),
                'changed' => false,
            ]);
            return;
        }

        $keyword_resolution = $this->maybe_resolve_focus_keyword_before_revision(
            $draft,
            $checks,
            $config,
            $provider,
            $model,
            $prompt_context
        );
        if (!empty($keyword_resolution['changed'])) {
            $previous_focus_keyword = $draft['focus_keyword'];
            $draft['focus_keyword'] = (string) $keyword_resolution['keyword'];
            if ($draft['slug'] === '' || $this->slug_matches_focus_keyword($draft['slug'], $previous_focus_keyword)) {
                $draft['slug'] = sanitize_title($draft['focus_keyword']);
            }
            $prompt_context['keywords'] = $draft['focus_keyword'];
            $prompt_context['resolved_focus_keyword'] = $draft['focus_keyword'];
            $checks = $this->replace_keyphrase_checks_after_resolution($checks, $draft['focus_keyword']);
            $usage = $this->merge_usage($usage, $keyword_resolution['usage'] ?? null);
            if (!empty($keyword_resolution['smart_seo_model']) && is_array($keyword_resolution['smart_seo_model'])) {
                $smart_seo_model = $keyword_resolution['smart_seo_model'];
            }
            if (!empty($keyword_resolution['smart_seo_model_fallbacks']) && is_array($keyword_resolution['smart_seo_model_fallbacks'])) {
                $smart_seo_model_fallbacks = array_merge($smart_seo_model_fallbacks, $keyword_resolution['smart_seo_model_fallbacks']);
            }
            $change_summaries[] = sprintf(
                /* translators: %s: resolved focus keyphrase */
                __('Changed duplicate or unsuitable focus keyphrase to "%s".', 'gpt3-ai-content-generator'),
                $draft['focus_keyword']
            );
        }
        if (class_exists(AIPKit_Content_Writer_Smart_SEO_Keyphrase_Content_Helper::class)) {
            $aligned_draft = AIPKit_Content_Writer_Smart_SEO_Keyphrase_Content_Helper::maybe_align_draft($draft, $prompt_context);
            if ($aligned_draft !== $draft) {
                $draft = $aligned_draft;
                $change_summaries[] = __('Aligned the Rank Math focus keyphrase across the article body and SEO fields.', 'gpt3-ai-content-generator');
            }
        }
        $internal_link_candidates = class_exists(AIPKit_Content_Writer_Smart_SEO_Internal_Link_Helper::class)
            ? AIPKit_Content_Writer_Smart_SEO_Internal_Link_Helper::get_candidates($draft, $prompt_context)
            : [];
        $prompt_context['internal_link_candidates'] = $internal_link_candidates;

        $prompt = $this->build_prompt($draft, $checks, $prompt_context);

        $system_instruction = implode(' ', [
            'You are an expert SEO editor for WordPress content.',
            'Rewrite only what is needed to satisfy the supplied audit checks.',
            'Return a single valid JSON object and no surrounding prose.',
        ]);

        $ai_caller = $this->get_ai_caller();
        $ai_params = $this->revision_ai_params($prompt_context);
        $result = class_exists(AIPKit_Content_Writer_Smart_SEO_Model_Policy::class)
            ? AIPKit_Content_Writer_Smart_SEO_Model_Policy::make_standard_call(
                $ai_caller,
                $provider,
                $model,
                [['role' => 'user', 'content' => $prompt]],
                $ai_params,
                $system_instruction,
                []
            )
            : $ai_caller->make_standard_call(
                $provider,
                $model,
                [['role' => 'user', 'content' => $prompt]],
                $ai_params,
                $system_instruction,
                []
            );

        if (is_wp_error($result)) {
            $this->send_wp_error($result);
            return;
        }
        $usage = $this->merge_usage($usage, $result['usage'] ?? null);
        if (!empty($result['smart_seo_model']) && is_array($result['smart_seo_model'])) {
            $smart_seo_model = $result['smart_seo_model'];
        }
        if (!empty($result['smart_seo_model_fallbacks']) && is_array($result['smart_seo_model_fallbacks'])) {
            $smart_seo_model_fallbacks = array_merge($smart_seo_model_fallbacks, $result['smart_seo_model_fallbacks']);
        }

        $decoded = $this->decode_json_response((string) ($result['content'] ?? ''));
        if (is_wp_error($decoded)) {
            $retry_instruction = $system_instruction . ' Your previous response was not valid JSON. Return only the JSON object requested by the prompt.';
            $retry_prompt = $prompt . "\n\nThe previous Smart SEO response could not be parsed as JSON. Retry now with one complete valid JSON object only. Do not use markdown fences, comments, explanations, or trailing text.";
            $retry_params = $this->revision_ai_params($prompt_context, true);
            $retry_result = class_exists(AIPKit_Content_Writer_Smart_SEO_Model_Policy::class)
                ? AIPKit_Content_Writer_Smart_SEO_Model_Policy::make_standard_call(
                    $ai_caller,
                    $provider,
                    $model,
                    [['role' => 'user', 'content' => $retry_prompt]],
                    $retry_params,
                    $retry_instruction,
                    []
                )
                : $ai_caller->make_standard_call(
                    $provider,
                    $model,
                    [['role' => 'user', 'content' => $retry_prompt]],
                    $retry_params,
                    $retry_instruction,
                    []
                );

            if (is_wp_error($retry_result)) {
                $this->send_wp_error($retry_result);
                return;
            }

            $retry_decoded = $this->decode_json_response((string) ($retry_result['content'] ?? ''));
            if (is_wp_error($retry_decoded)) {
                $this->send_wp_error($decoded);
                return;
            }

            $result = $retry_result;
            $decoded = $retry_decoded;
            $usage = $this->merge_usage($usage, $result['usage'] ?? null);
            if (!empty($result['smart_seo_model']) && is_array($result['smart_seo_model'])) {
                $smart_seo_model = $result['smart_seo_model'];
            }
            if (!empty($result['smart_seo_model_fallbacks']) && is_array($result['smart_seo_model_fallbacks'])) {
                $smart_seo_model_fallbacks = array_merge($smart_seo_model_fallbacks, $result['smart_seo_model_fallbacks']);
            }
        }

        $improved_draft = $this->normalize_improved_draft($decoded, $draft);
        if (class_exists(AIPKit_Content_Writer_Smart_SEO_Internal_Link_Helper::class)) {
            $improved_draft['content_html'] = AIPKit_Content_Writer_Smart_SEO_Internal_Link_Helper::clean_invalid_internal_links(
                (string) ($improved_draft['content_html'] ?? ''),
                $internal_link_candidates,
                $prompt_context
            );
            $improved_draft['content'] = $improved_draft['content_html'];
        }
        if (class_exists(AIPKit_Content_Writer_Smart_SEO_External_Link_Helper::class)) {
            $improved_draft['content_html'] = AIPKit_Content_Writer_Smart_SEO_External_Link_Helper::clean_outbound_links(
                (string) ($improved_draft['content_html'] ?? ''),
                $prompt_context
            );
            $improved_draft['content'] = $improved_draft['content_html'];
        }
        if (class_exists(AIPKit_Content_Writer_Smart_SEO_AIOSEO_Headline_Helper::class)) {
            $improved_draft = AIPKit_Content_Writer_Smart_SEO_AIOSEO_Headline_Helper::maybe_improve_title($improved_draft, $prompt_context);
        }
        if (class_exists(AIPKit_Content_Writer_Smart_SEO_AIOSEO_Content_Helper::class)) {
            $improved_draft = AIPKit_Content_Writer_Smart_SEO_AIOSEO_Content_Helper::maybe_improve_content($improved_draft, $prompt_context);
        }
        if (class_exists(AIPKit_Content_Writer_Smart_SEO_Yoast_Content_Helper::class)) {
            $improved_draft = AIPKit_Content_Writer_Smart_SEO_Yoast_Content_Helper::maybe_improve_draft($improved_draft, $prompt_context);
        }
        if (class_exists(AIPKit_Content_Writer_Smart_SEO_Keyphrase_Content_Helper::class)) {
            $improved_draft = AIPKit_Content_Writer_Smart_SEO_Keyphrase_Content_Helper::maybe_align_draft($improved_draft, $prompt_context);
        }
        if (class_exists(AIPKit_Content_Writer_Smart_SEO_Image_Tag_Guard::class)) {
            $improved_draft = AIPKit_Content_Writer_Smart_SEO_Image_Tag_Guard::sanitize_draft($improved_draft);
        }
        if (!$this->can_change_focus_keyword($checks)) {
            $improved_draft['focus_keyword'] = $draft['focus_keyword'];
        }
        if (class_exists(AIPKit_Content_Writer_Smart_SEO_Title_Helper::class)) {
            $improved_draft = AIPKit_Content_Writer_Smart_SEO_Title_Helper::maybe_align_title($improved_draft, $prompt_context);
        }
        if (
            class_exists(AIPKit_Content_Writer_Smart_SEO_Naturalness_Guard::class)
            && AIPKit_Content_Writer_Smart_SEO_Naturalness_Guard::should_keep_previous($improved_draft, $draft)
        ) {
            $improved_draft = $draft;
            $decoded['change_summary'] = __('Skipped an SEO rewrite that forced awkward exact-keyphrase phrasing.', 'gpt3-ai-content-generator');
        }
        $ai_change_summary = isset($decoded['change_summary']) ? sanitize_text_field((string) $decoded['change_summary']) : '';
        if ($ai_change_summary !== '') {
            $change_summaries[] = $ai_change_summary;
        }

        wp_send_json_success([
            'draft' => $improved_draft,
            'changes' => implode(' ', array_values(array_filter($change_summaries))),
            'changed' => $improved_draft !== $original_draft,
            'usage' => $usage,
            'smart_seo_model' => is_array($smart_seo_model) ? $smart_seo_model : null,
            'smart_seo_model_fallbacks' => $this->unique_model_fallbacks($smart_seo_model_fallbacks),
        ]);
    }

    private function extract_draft(array $raw_post): array
    {
        $draft = [
            'title' => isset($raw_post['draft_title']) ? sanitize_text_field((string) $raw_post['draft_title']) : '',
            'content' => isset($raw_post['draft_content']) ? wp_kses_post((string) $raw_post['draft_content']) : '',
            'content_html' => isset($raw_post['draft_content']) ? wp_kses_post((string) $raw_post['draft_content']) : '',
            'meta_description' => isset($raw_post['draft_meta_description']) ? sanitize_textarea_field((string) $raw_post['draft_meta_description']) : '',
            'focus_keyword' => isset($raw_post['draft_focus_keyword']) ? sanitize_text_field((string) $raw_post['draft_focus_keyword']) : '',
            'excerpt' => isset($raw_post['draft_excerpt']) ? sanitize_textarea_field((string) $raw_post['draft_excerpt']) : '',
            'tags' => isset($raw_post['draft_tags']) ? sanitize_text_field((string) $raw_post['draft_tags']) : '',
            'slug' => isset($raw_post['draft_slug']) ? sanitize_title((string) $raw_post['draft_slug']) : '',
            'post_type' => isset($raw_post['post_type']) ? sanitize_key((string) $raw_post['post_type']) : 'post',
            'images' => $this->extract_images($raw_post),
            'featured_image_alt' => $this->extract_featured_image_alt($raw_post),
        ];

        return class_exists(AIPKit_Content_Writer_Smart_SEO_Image_Tag_Guard::class)
            ? AIPKit_Content_Writer_Smart_SEO_Image_Tag_Guard::sanitize_draft($draft)
            : $draft;
    }

    private function extract_images(array $raw_post): array
    {
        $image_data = $this->decode_image_data($raw_post);
        if (empty($image_data)) {
            return [];
        }

        $images = [];
        foreach ($image_data['in_content_images'] ?? [] as $image) {
            if (!is_array($image)) {
                continue;
            }
            $images[] = $this->normalize_image($image);
        }

        return array_values(array_filter($images, static function (array $image): bool {
            return ($image['src'] ?? '') !== '' || ($image['alt'] ?? '') !== '' || !empty($image['attachment_id']);
        }));
    }

    private function extract_fixable_checks(array $raw_post): array
    {
        $raw_checks = $raw_post['audit_checks'] ?? '[]';
        if (is_string($raw_checks)) {
            $decoded = json_decode(trim($raw_checks), true);
            if (!is_array($decoded)) {
                $decoded = json_decode(stripslashes(trim($raw_checks)), true);
            }
            $raw_checks = is_array($decoded) ? $decoded : [];
        }

        if (!is_array($raw_checks)) {
            return [];
        }

        $checks = [];
        foreach ($raw_checks as $check) {
            if (!is_array($check)) {
                continue;
            }
            $status = isset($check['status']) ? sanitize_key((string) $check['status']) : '';
            if ($status === 'pass' || empty($check['fixable'])) {
                continue;
            }

            $message = isset($check['message']) ? trim(wp_strip_all_tags((string) $check['message'])) : '';
            $label = isset($check['label']) ? trim(wp_strip_all_tags((string) $check['label'])) : '';
            if ($message === '' && $label === '') {
                continue;
            }

            $checks[] = [
                'id' => isset($check['id']) ? sanitize_key((string) $check['id']) : '',
                'label' => $label,
                'message' => $message,
                'field' => isset($check['field']) ? sanitize_key((string) $check['field']) : '',
                'severity' => isset($check['severity']) ? sanitize_key((string) $check['severity']) : 'medium',
            ];

            if (count($checks) >= 10) {
                break;
            }
        }

        return $checks;
    }

    private function filter_disabled_checks(array $checks, array $disabled_rule_ids): array
    {
        if (empty($disabled_rule_ids)) {
            return $checks;
        }

        $disabled = array_fill_keys(array_map('sanitize_key', $disabled_rule_ids), true);
        return array_values(array_filter($checks, static function (array $check) use ($disabled): bool {
            $id = isset($check['id']) ? sanitize_key((string) $check['id']) : '';
            return $id === '' || !isset($disabled[$id]);
        }));
    }

    private function can_change_focus_keyword(array $checks): bool
    {
        foreach ($checks as $check) {
            if (!is_array($check)) {
                continue;
            }

            $id = isset($check['id']) ? sanitize_key((string) $check['id']) : '';
            if ($id === 'previously_used_keyphrase' || $id === 'focus_keyword_length') {
                return true;
            }

            $label = isset($check['label']) ? strtolower((string) $check['label']) : '';
            $message = isset($check['message']) ? strtolower((string) $check['message']) : '';
            $text = $label . ' ' . $message;
            if (
                strpos($text, 'previously used') !== false
                || strpos($text, 'used this keyphrase') !== false
                || strpos($text, 'keyphrase length') !== false
                || strpos($text, 'focus keyword length') !== false
            ) {
                return true;
            }
        }

        return false;
    }

    private function maybe_resolve_focus_keyword_before_revision(array $draft, array $checks, array $config, string $provider, string $model, array $context): array
    {
        if (!$this->can_change_focus_keyword($checks)) {
            return [];
        }

        $focus_keyword = isset($draft['focus_keyword']) ? trim((string) $draft['focus_keyword']) : '';
        if ($focus_keyword === '' || !class_exists(AIPKit_Content_Writer_Smart_SEO_Keyword_Resolver::class) || !$this->get_ai_caller()) {
            return [];
        }

        $resolver = new AIPKit_Content_Writer_Smart_SEO_Keyword_Resolver();
        return $resolver->maybe_resolve_keyword(
            $focus_keyword,
            array_merge($config, [
                'ai_provider' => $provider,
                'ai_model' => $model,
                'content_title' => (string) ($context['topic'] ?? $draft['title'] ?? ''),
            ]),
            $this->get_ai_caller(),
            [
                'ai_provider' => $provider,
                'ai_model' => $model,
                'topic' => (string) ($context['topic'] ?? $draft['title'] ?? ''),
                'title' => (string) ($draft['title'] ?? ''),
                'keywords' => (string) ($context['keywords'] ?? ''),
                'content_summary' => wp_trim_words(wp_strip_all_tags((string) ($draft['content_html'] ?? $draft['content'] ?? '')), 80, ''),
            ]
        );
    }

    private function replace_keyphrase_checks_after_resolution(array $checks, string $focus_keyword): array
    {
        $filtered = [];
        foreach ($checks as $check) {
            if (!is_array($check) || $this->is_keyphrase_check($check)) {
                continue;
            }
            $filtered[] = $check;
        }

        array_unshift($filtered, [
            'id' => 'focus_keyword_alignment',
            'label' => __('Focus keyword alignment', 'gpt3-ai-content-generator'),
            'message' => sprintf(
                /* translators: %s: resolved focus keyphrase */
                __('Smart SEO changed the focus keyphrase to "%s". Keep this focus keyphrase and align the title, introduction, subheadings, meta description, slug, excerpt, tags, and image alt text with it where natural.', 'gpt3-ai-content-generator'),
                $focus_keyword
            ),
            'field' => 'focus_keyword',
            'severity' => 'high',
        ]);

        return array_slice($filtered, 0, 10);
    }

    private function is_keyphrase_check(array $check): bool
    {
        $id = isset($check['id']) ? sanitize_key((string) $check['id']) : '';
        if ($id === '') {
            return false;
        }

        return strpos($id, 'focus_keyword') !== false
            || strpos($id, 'keyphrase') !== false
            || strpos($id, 'keyword_density') !== false;
    }

    private function slug_matches_focus_keyword(string $slug, string $focus_keyword): bool
    {
        $slug = sanitize_title($slug);
        $focus_slug = sanitize_title($focus_keyword);
        return $slug !== '' && $focus_slug !== '' && strpos($slug, $focus_slug) !== false;
    }

    private function build_prompt(array $draft, array $checks, array $context): string
    {
        return $this->build_smart_seo_revision_prompt($draft, $checks, $context, [
            'include_resolved_focus_keyword' => true,
            'include_focus_keyword_alignment' => true,
        ]);
    }

    /**
     * @return array{profile:string,label:string}
     */
    private function resolve_profile(string $requested_profile): array
    {
        $profile = sanitize_key($requested_profile);
        if ($profile === 'auto' || $profile === '') {
            if (class_exists(AIPKit_SEO_Helper::class)) {
                $active_profile = AIPKit_SEO_Helper::get_active_plugin_profile();
                $profile_key = isset($active_profile['profile']) ? sanitize_key((string) $active_profile['profile']) : 'aipkit';
                return [
                    'profile' => $profile_key !== '' ? $profile_key : 'aipkit',
                    'label' => isset($active_profile['label']) ? (string) $active_profile['label'] : __('AIPKit SEO', 'gpt3-ai-content-generator'),
                ];
            }
            $profile = 'aipkit';
        }

        $profiles = [
            'aipkit' => __('AIPKit SEO', 'gpt3-ai-content-generator'),
            'yoast' => __('Yoast SEO', 'gpt3-ai-content-generator'),
            'rank_math' => __('Rank Math', 'gpt3-ai-content-generator'),
            'aioseo' => __('All in One SEO', 'gpt3-ai-content-generator'),
            'framework' => __('The SEO Framework', 'gpt3-ai-content-generator'),
        ];

        if (!isset($profiles[$profile])) {
            $profile = 'aipkit';
        }

        return [
            'profile' => $profile,
            'label' => $profiles[$profile],
        ];
    }

    /**
     * @return mixed[]|\WP_Error
     */
    private function decode_json_response(string $content)
    {
        $clean = trim($content);
        $clean = preg_replace('/^```(?:json)?\s*/i', '', $clean);
        $clean = preg_replace('/\s*```$/', '', (string) $clean);

        $decoded = json_decode((string) $clean, true);
        if (is_array($decoded)) {
            return $decoded;
        }

        if (preg_match('/\{.*\}/s', (string) $clean, $match)) {
            $decoded = json_decode($match[0], true);
            if (is_array($decoded)) {
                return $decoded;
            }
        }

        return new WP_Error(
            'seo_improvement_invalid_json',
            __('SEO improvement did not return a valid draft update.', 'gpt3-ai-content-generator'),
            ['status' => 500]
        );
    }

    private function normalize_improved_draft(array $decoded, array $fallback): array
    {
        $content_html = isset($decoded['content_html']) ? wp_kses_post((string) $decoded['content_html']) : $fallback['content_html'];
        if (class_exists(\WPAICG\ContentWriter\AIPKit_Content_Writer_Output_Cleaner::class)) {
            $content_html = \WPAICG\ContentWriter\AIPKit_Content_Writer_Output_Cleaner::clean_article_content((string) $content_html);
        }
        if (trim(wp_strip_all_tags($content_html)) === '') {
            $content_html = $fallback['content_html'];
        }

        $normalized = [
            'title' => isset($decoded['title']) && trim((string) $decoded['title']) !== ''
                ? sanitize_text_field((string) $decoded['title'])
                : $fallback['title'],
            'content' => $content_html,
            'content_html' => $content_html,
            'meta_description' => isset($decoded['meta_description'])
                ? sanitize_textarea_field((string) $decoded['meta_description'])
                : $fallback['meta_description'],
            'focus_keyword' => isset($decoded['focus_keyword'])
                ? sanitize_text_field((string) $decoded['focus_keyword'])
                : $fallback['focus_keyword'],
            'excerpt' => isset($decoded['excerpt'])
                ? sanitize_textarea_field((string) $decoded['excerpt'])
                : $fallback['excerpt'],
            'tags' => isset($decoded['tags'])
                ? sanitize_text_field((string) $decoded['tags'])
                : $fallback['tags'],
            'slug' => isset($decoded['slug']) && trim((string) $decoded['slug']) !== ''
                ? sanitize_title((string) $decoded['slug'])
                : $fallback['slug'],
            'post_type' => $fallback['post_type'],
            'images' => isset($fallback['images']) && is_array($fallback['images']) ? $fallback['images'] : [],
            'featured_image_alt' => isset($fallback['featured_image_alt']) ? (string) $fallback['featured_image_alt'] : '',
        ];

        if (class_exists(\WPAICG\ContentWriter\AIPKit_Content_Writer_Output_Cleaner::class)) {
            $normalized['title'] = \WPAICG\ContentWriter\AIPKit_Content_Writer_Output_Cleaner::clean_title(
                (string) $normalized['title'],
                (string) $normalized['focus_keyword']
            );
            $normalized['meta_description'] = \WPAICG\ContentWriter\AIPKit_Content_Writer_Output_Cleaner::clean_meta_description(
                (string) $normalized['meta_description']
            );
            $normalized['content_html'] = \WPAICG\ContentWriter\AIPKit_Content_Writer_Output_Cleaner::clean_article_content(
                (string) $normalized['content_html'],
                (string) $normalized['focus_keyword']
            );
            $normalized['content'] = $normalized['content_html'];
        }

        return class_exists(AIPKit_Content_Writer_Smart_SEO_Image_Tag_Guard::class)
            ? AIPKit_Content_Writer_Smart_SEO_Image_Tag_Guard::sanitize_draft($normalized)
            : $normalized;
    }

    /**
     * @param mixed $primary_usage
     * @param mixed $secondary_usage
     * @return mixed
     */
    private function merge_usage($primary_usage, $secondary_usage)
    {
        if (!is_array($secondary_usage)) {
            return $primary_usage;
        }

        if (!is_array($primary_usage)) {
            return $secondary_usage;
        }

        $merged = $primary_usage;
        $merged['input_tokens'] = (int) ($primary_usage['input_tokens'] ?? 0) + (int) ($secondary_usage['input_tokens'] ?? 0);
        $merged['output_tokens'] = (int) ($primary_usage['output_tokens'] ?? 0) + (int) ($secondary_usage['output_tokens'] ?? 0);
        $merged['total_tokens'] = (int) ($primary_usage['total_tokens'] ?? 0) + (int) ($secondary_usage['total_tokens'] ?? 0);

        if (isset($secondary_usage['provider_raw'])) {
            $primary_raw = isset($primary_usage['provider_raw']) ? $primary_usage['provider_raw'] : [];
            $merged['provider_raw'] = array_merge(is_array($primary_raw) ? $primary_raw : [$primary_raw], [$secondary_usage['provider_raw']]);
        }

        return $merged;
    }

}
