<?php
use FluentCart\App\Models\ProductReview;
use FluentCart\App\Services\ProductReviewService;
use FluentCart\Framework\Support\Arr;
use FluentCartPro\App\Modules\Reviews\Models\ReviewInteraction;
use FluentCartPro\App\Modules\Reviews\Services\ReviewMediaService;
use FluentCartPro\App\Modules\Reviews\Services\ReviewModalFooterRenderer;
use FluentCartPro\App\Modules\Reviews\Services\ReviewService;

// Include media + vote counts in public response
add_filter('fluent_cart/review/public_response', function ($responseData, $postId) {
    $settings = ProductReviewService::getReviewSettings();

    $reviewsData = $responseData['reviews']['data'] ?? [];
    $reviewIds = array_map(function ($review) {
        return is_array($review) ? ($review['id'] ?? null) : ($review->id ?? null);
    }, $reviewsData);
    $reviewIds = array_filter($reviewIds);

    if (empty($reviewIds)) {
        return $responseData;
    }

    // Attach media to each review + build photo gallery
    if (!empty($settings['enable_photo_reviews']) && $settings['enable_photo_reviews'] === 'yes') {
        // Photo gallery: find approved reviews that have media attached —
        // media_count > 0 rides the (post_id, media_count) index. Post id 0 is
        // the store-wide list, which has no product gallery and no index to ride.
        $approvedIdsWithMedia = $postId ? ProductReview::query()
            ->ofProduct($postId)
            ->approved()
            ->topLevel()
            ->withMedia()
            ->orderBy('created_at', 'DESC')
            ->orderBy('id', 'DESC')
            ->limit(50)
            ->pluck('id')
            ->toArray() : [];

        // Single batch fetch: merge page review IDs + gallery IDs, deduplicate
        $allIds = array_unique(array_merge($reviewIds, $approvedIdsWithMedia));
        $allMedia = !empty($allIds) ? ReviewMediaService::getMediaForReviews($allIds) : [];

        foreach ($responseData['reviews']['data'] as &$review) {
            $reviewId = $review['id'] ?? ($review->id ?? null);
            $review['media'] = $allMedia[$reviewId] ?? [];
        }
        unset($review);

        $gallery = [];
        foreach ($approvedIdsWithMedia as $approvedId) {
            $items = $allMedia[$approvedId] ?? [];
            foreach ($items as $item) {
                $item['review_id'] = $approvedId;
                $gallery[] = $item;
                if (count($gallery) >= 20) {
                    break 2;
                }
            }
        }
        $responseData['photo_gallery'] = $gallery;
    }

    // Attach vote counts to each review. The votes relation ships in the
    // free plugin, so it is skipped when the two plugins are on mismatched
    // versions rather than fatalling on an unresolvable relation.
    if (!empty($settings['enable_helpful_votes']) && $settings['enable_helpful_votes'] === 'yes'
        && ReviewInteraction::isVotesRelationAvailable()
    ) {
        $voteCounts = ProductReview::query()
            ->whereIn('id', $reviewIds)
            ->withCount([
                'votes as helpful' => function ($voteQuery) {
                    $voteQuery->helpful();
                },
                'votes as not_helpful' => function ($voteQuery) {
                    $voteQuery->notHelpful();
                },
            ])
            ->get()
            ->keyBy('id');

        $userId = get_current_user_id();
        $userVotes = $userId ? ReviewInteraction::votes()
            ->whereIn('review_id', $reviewIds)
            ->where('user_id', $userId)
            ->pluck('value', 'review_id')->all() : [];

        foreach ($responseData['reviews']['data'] as &$review) {
            $reviewId = $review['id'] ?? ($review->id ?? null);
            $review['user_vote'] = (int) ($userVotes[$reviewId] ?? 0);
            $counts = $voteCounts[$reviewId] ?? null;
            $review['helpful_count'] = $counts ? (int) $counts->helpful : 0;
            $review['not_helpful_count'] = $counts ? (int) $counts->not_helpful : 0;
        }
        unset($review);
    }

    return $responseData;
}, 10, 2);

// Add PRO data attributes to the reviews container
add_filter('fluent_cart/review/container_data_attrs', function ($attrs, $postId, $options) {
    $settings = ProductReviewService::getReviewSettings();

    if (!empty($settings['enable_photo_reviews']) && $settings['enable_photo_reviews'] === 'yes') {
        $attrs['enable-photos'] = '1';
    }
    if (!empty($settings['enable_helpful_votes']) && $settings['enable_helpful_votes'] === 'yes') {
        $attrs['enable-votes'] = '1';
    }

    return $attrs;
}, 10, 3);

// Extend JS vars with PRO translations and config
add_filter('fluent_cart/review/js_vars', function ($reviewVars) {
    $settings = ProductReviewService::getReviewSettings();

    // Capability signal for the free list renderer: show the zero-reply
    // "Reply" trigger only when the thread reply UI will actually appear.
    Arr::set($reviewVars, 'can_thread', ReviewService::isThreadedRepliesEnabled() && is_user_logged_in());

    Arr::set($reviewVars, 'pro', [
        'photo_reviews' => Arr::get($settings, 'enable_photo_reviews') === 'yes',
        'helpful_votes' => Arr::get($settings, 'enable_helpful_votes') === 'yes',
        'max_photos'    => ReviewMediaService::getMaxPhotosPerReview(),
        'max_size_mb'   => ReviewMediaService::getMaxPhotoSizeMb(),
    ]);

    Arr::set($reviewVars, 'trans.helpful', __('Helpful', 'fluent-cart-pro'));
    Arr::set($reviewVars, 'trans.not_helpful', __('Not Helpful', 'fluent-cart-pro'));

    return $reviewVars;
});

// Attach media to the customer dashboard's My Reviews history.
//
// The same photos the product page shows, on the customer's own list of what
// they wrote — a review that has a photo reads as one wherever it appears.
// One batch query for the page, the way the public list does it, rather than
// one per row.
//
// Gated on enable_photo_reviews, like the public list: a store that has turned
// photo reviews off is not showing photos on the storefront, and the customer's
// own history is a storefront surface.
add_filter('fluent_cart/review/customer_reviews_response', function ($responseData, $context) {
    $settings = ProductReviewService::getReviewSettings();

    if (empty($settings['enable_photo_reviews']) || $settings['enable_photo_reviews'] !== 'yes') {
        return $responseData;
    }

    $rows = Arr::get($responseData, 'reviews.data', []);

    $reviewIds = array_filter(array_map(function ($review) {
        return is_array($review) ? Arr::get($review, 'id') : ($review->id ?? null);
    }, $rows));

    if (!$reviewIds) {
        return $responseData;
    }

    $allMedia = ReviewMediaService::getMediaForReviews($reviewIds);

    foreach ($responseData['reviews']['data'] as &$review) {
        $reviewId = is_array($review) ? Arr::get($review, 'id') : ($review->id ?? null);
        $review['media'] = Arr::get($allMedia, $reviewId, []);
    }
    unset($review);

    return $responseData;
}, 10, 2);

// Attach vote counts + media to admin single review response
add_filter('fluent_cart/review/admin_single_response', function ($responseData, $review) {
    $settings = ProductReviewService::getReviewSettings();

    if (!empty($settings['enable_helpful_votes']) && $settings['enable_helpful_votes'] === 'yes') {
        $responseData['vote_counts'] = ReviewInteraction::voteCountsFor($review->id);
    }

    // Not gated on enable_photo_reviews. That setting decides whether shoppers
    // are offered an upload zone on the storefront; it must not hide media
    // that is already attached from the moderator looking at the review —
    // including photos a moderator attached themselves, which the admin
    // add-review form allows regardless of the setting. Returns [] when the
    // review carries none, so the admin view simply renders nothing.
    $responseData['review_media'] = ReviewMediaService::getMediaForReview($review->id);

    return $responseData;
}, 10, 2);

// Threaded replies are the Pro capability — ReviewService owns the public
// fluent_cart/review/allow_threaded_replies filter and bridges it onto the
// free plugin's neutral allow_multiple_replies switch.
add_filter('fluent_cart/review/allow_multiple_replies', [ReviewService::class, 'allowMultipleReplies']);

// Reviewer reply form inside the server-rendered thread modal.
ReviewModalFooterRenderer::register();