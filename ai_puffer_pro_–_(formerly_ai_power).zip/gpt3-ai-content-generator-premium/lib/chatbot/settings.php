<?php
/**
 * Paid chatbot trigger and realtime-voice settings.
 * Loaded by the licensed Pro bootstrap; shared storage keeps safe Free defaults.
 */

namespace WPAICG\Chat\Storage\GetterMethods;

use WPAICG\Chat\Storage\BotSettingsManager;
use WPAICG\AIPKit_Providers;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Retrieves trigger configuration for a bot.
 * Returns the raw JSON string from post meta, or an empty array string '[]' if not set or invalid.
 *
 * @param int $bot_id The ID of the bot post.
 * @param callable $get_meta_fn A function to retrieve post meta (used to get the trigger meta key).
 * @return array Associative array containing 'triggers_json'.
 */
function get_trigger_config_logic(int $bot_id, callable $get_meta_fn): array
{
    $settings = [];

    $trigger_meta_key = '_aipkit_chatbot_triggers'; // Fallback key
    $trigger_storage_class_name = '\WPAICG\Lib\Chat\Triggers\AIPKit_Trigger_Storage'; // New Pro location/namespace

    if (class_exists($trigger_storage_class_name)) {
        $trigger_meta_key = $trigger_storage_class_name::META_KEY;
    }

    // Use the passed $get_meta_fn to retrieve the value for the determined meta key
    // Default to an empty JSON array string if the meta key is not found or is empty.
    $triggers_json_string = $get_meta_fn($trigger_meta_key, '[]');

    // Ensure $triggers_json_string is a string before trying to decode
    if (!is_string($triggers_json_string) || trim($triggers_json_string) === '') {
        $triggers_json_string = '[]';
    }

    $decoded = json_decode($triggers_json_string, true);
    if (json_last_error() !== JSON_ERROR_NONE || !is_array($decoded)) {
        // Attempt a targeted repair for unescaped quotes in body_template (common cause of invalid JSON).
        $repaired = preg_replace_callback(
            '/("body_template"\s*:\s*")(.+?)(")\s*,\s*"timeout_seconds"/s',
            static function (array $matches): string {
                $value = $matches[2];
                $value = str_replace('\\', '\\\\', $value);
                $value = str_replace('"', '\\"', $value);
                return $matches[1] . $value . $matches[3] . ', "timeout_seconds"';
            },
            $triggers_json_string,
            -1,
            $repair_count
        );
        if (!empty($repair_count)) {
            $decoded = json_decode($repaired, true);
            if (json_last_error() === JSON_ERROR_NONE && is_array($decoded)) {
                $triggers_json_string = $repaired;
            }
        }
    }

    if (json_last_error() === JSON_ERROR_NONE && is_array($decoded)) {
        $settings['triggers_json'] = wp_json_encode($decoded, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    } else {
        $settings['triggers_json'] = '[]';
    }
    return $settings;
}

// --- fn-get-voice-agent-config.php ---
/**
 * Retrieves Realtime Voice Agent configuration settings.
 *
 * @param int $bot_id The ID of the bot post.
 * @param callable $get_meta_fn A function to retrieve post meta.
 * @return array Associative array of voice agent settings.
 */
function get_voice_agent_config_logic(int $bot_id, callable $get_meta_fn): array
{
    $settings = [];

    // Ensure BotSettingsManager is loaded for constants, or provide fallbacks.
    
    $default_enable_realtime = BotSettingsManager::DEFAULT_ENABLE_REALTIME_VOICE ?? '0';
    $default_direct_voice_mode = BotSettingsManager::DEFAULT_DIRECT_VOICE_MODE ?? '0';
    $default_realtime_model = BotSettingsManager::get_default_model_id('OpenAIRealtime');
    $default_realtime_voice = BotSettingsManager::get_default_model_id('OpenAIRealtimeVoices');
    $default_turn_detection = BotSettingsManager::DEFAULT_TURN_DETECTION ?? 'server_vad';
    $default_speed = BotSettingsManager::DEFAULT_SPEED ?? 1.0;
    $default_input_audio_format = BotSettingsManager::DEFAULT_INPUT_AUDIO_FORMAT ?? 'pcm16';
    $default_output_audio_format = BotSettingsManager::DEFAULT_OUTPUT_AUDIO_FORMAT ?? 'pcm16';
    $default_noise_reduction = BotSettingsManager::DEFAULT_INPUT_AUDIO_NOISE_REDUCTION ?? '1';

    $settings['enable_realtime_voice'] = $get_meta_fn('_aipkit_enable_realtime_voice', $default_enable_realtime);
    $settings['direct_voice_mode'] = $get_meta_fn('_aipkit_direct_voice_mode', $default_direct_voice_mode);
    $settings['realtime_model'] = $get_meta_fn('_aipkit_realtime_model', $default_realtime_model);
    $settings['realtime_voice'] = $get_meta_fn('_aipkit_realtime_voice', $default_realtime_voice);
    $settings['turn_detection'] = $get_meta_fn('_aipkit_turn_detection', $default_turn_detection);
    $settings['speed'] = floatval($get_meta_fn('_aipkit_speed', $default_speed));
    $settings['input_audio_format'] = $get_meta_fn('_aipkit_input_audio_format', $default_input_audio_format);
    $settings['output_audio_format'] = $get_meta_fn('_aipkit_output_audio_format', $default_output_audio_format);
    $settings['input_audio_noise_reduction'] = $get_meta_fn('_aipkit_input_audio_noise_reduction', $default_noise_reduction);
    
    // Validate values to be safe
    $valid_audio_formats = ['pcm16', 'g711_ulaw', 'g711_alaw'];
    if (!in_array($settings['input_audio_format'], $valid_audio_formats, true)) {
        $settings['input_audio_format'] = $default_input_audio_format;
    }
    if (!in_array($settings['output_audio_format'], $valid_audio_formats, true)) {
        $settings['output_audio_format'] = $default_output_audio_format;
    }
    $allowed_realtime_models = array_column(AIPKit_Providers::get_openai_realtime_models(), 'id');
    if (!in_array($settings['realtime_model'], $allowed_realtime_models, true)) {
        $settings['realtime_model'] = $default_realtime_model;
    }
    $allowed_realtime_voices = array_column(AIPKit_Providers::get_openai_realtime_voices(), 'id');
    if (!in_array($settings['realtime_voice'], $allowed_realtime_voices, true)) {
        $settings['realtime_voice'] = $default_realtime_voice;
    }
    if (!in_array($settings['turn_detection'], ['server_vad', 'semantic_vad'], true)) {
        $settings['turn_detection'] = $default_turn_detection;
    }
    $settings['speed'] = max(0.25, min(1.5, $settings['speed']));

    $live = [];
    foreach (\WPAICG\Lib\Chat\LiveSettings::defaults() as $key => $default) {
        $live[$key] = $get_meta_fn('_aipkit_' . $key, $default);
    }
    return array_merge($settings, \WPAICG\Lib\Chat\LiveSettings::sanitize($live));
}

namespace WPAICG\Chat\Storage\SaverMethods;

use WPAICG\Chat\Storage\BotSettingsManager;
use WPAICG\AIPKit_Providers;
use WP_Error;

/** Sanitize the realtime-voice fields submitted with chatbot settings. */
function sanitize_voice_agent_settings_logic(array $raw_settings): array
{
    $sanitized = [];
    $sanitized['enable_realtime_voice'] = (isset($raw_settings['enable_realtime_voice']) && $raw_settings['enable_realtime_voice'] === '1') ? '1' : '0';
    $sanitized['direct_voice_mode'] = (isset($raw_settings['direct_voice_mode']) && $raw_settings['direct_voice_mode'] === '1') ? '1' : '0';
    $allowed_realtime_models = array_column(AIPKit_Providers::get_openai_realtime_models(), 'id');
    $sanitized['realtime_model'] = isset($raw_settings['realtime_model']) && in_array($raw_settings['realtime_model'], $allowed_realtime_models, true) ? $raw_settings['realtime_model'] : BotSettingsManager::get_default_model_id('OpenAIRealtime');
    $allowed_realtime_voices = array_column(AIPKit_Providers::get_openai_realtime_voices(), 'id');
    $sanitized['realtime_voice'] = isset($raw_settings['realtime_voice']) && in_array($raw_settings['realtime_voice'], $allowed_realtime_voices, true) ? $raw_settings['realtime_voice'] : BotSettingsManager::get_default_model_id('OpenAIRealtimeVoices');
    $sanitized['turn_detection'] = isset($raw_settings['turn_detection']) && in_array($raw_settings['turn_detection'], ['server_vad', 'semantic_vad'], true) ? $raw_settings['turn_detection'] : BotSettingsManager::DEFAULT_TURN_DETECTION;
    $sanitized['speed'] = isset($raw_settings['speed']) ? max(0.25, min(1.5, floatval($raw_settings['speed']))) : 1.0;
    $valid_audio_formats = ['pcm16', 'g711_ulaw', 'g711_alaw'];
    $sanitized['input_audio_format'] = isset($raw_settings['input_audio_format']) && in_array($raw_settings['input_audio_format'], $valid_audio_formats) ? $raw_settings['input_audio_format'] : 'pcm16';
    $sanitized['output_audio_format'] = isset($raw_settings['output_audio_format']) && in_array($raw_settings['output_audio_format'], $valid_audio_formats) ? $raw_settings['output_audio_format'] : 'pcm16';
    $sanitized['input_audio_noise_reduction'] = (isset($raw_settings['input_audio_noise_reduction']) && $raw_settings['input_audio_noise_reduction'] === '1') ? '1' : '0';
    return array_merge($sanitized, \WPAICG\Lib\Chat\LiveSettings::sanitize($raw_settings));
}

/** Persist validated realtime-voice fields for a chatbot. */
function save_voice_agent_settings_logic(int $botId, array $sanitized_settings): void
{
    \WPAICG\Lib\Chat\LiveSettings::save($botId, $sanitized_settings);
    update_post_meta($botId, '_aipkit_enable_realtime_voice', $sanitized_settings['enable_realtime_voice']);
    update_post_meta($botId, '_aipkit_direct_voice_mode', $sanitized_settings['direct_voice_mode']);
    update_post_meta($botId, '_aipkit_realtime_model', $sanitized_settings['realtime_model']);
    update_post_meta($botId, '_aipkit_realtime_voice', $sanitized_settings['realtime_voice']);
    update_post_meta($botId, '_aipkit_turn_detection', $sanitized_settings['turn_detection']);
    update_post_meta($botId, '_aipkit_speed', (string)$sanitized_settings['speed']);
    update_post_meta($botId, '_aipkit_input_audio_format', $sanitized_settings['input_audio_format']);
    update_post_meta($botId, '_aipkit_output_audio_format', $sanitized_settings['output_audio_format']);
    update_post_meta($botId, '_aipkit_input_audio_noise_reduction', $sanitized_settings['input_audio_noise_reduction']);
}

/** Persist normalized triggers, or return the existing validation error. */
function save_trigger_settings_logic(int $botId, array $sanitized_settings)
{
    $trigger_meta_key = '_aipkit_chatbot_triggers'; // Fallback key
    $trigger_storage_class_name = '\WPAICG\Lib\Chat\Triggers\AIPKit_Trigger_Storage';

    if (class_exists($trigger_storage_class_name)) {
        $trigger_meta_key = $trigger_storage_class_name::META_KEY;
    }

    $triggers_json_string = $sanitized_settings['triggers_json'] ?? '[]';
    $decoded_triggers_for_validation = json_decode($triggers_json_string, true);
    if (json_last_error() !== JSON_ERROR_NONE) {
        return new WP_Error('invalid_trigger_json_meta', __('Invalid JSON format for triggers. Triggers were not saved.', 'gpt3-ai-content-generator'));
    }
    if (!is_array($decoded_triggers_for_validation)) {
        $triggers_json_string = '[]';
    } else {
        // Normalize stored JSON to ensure nested strings (e.g. body_template) are properly escaped.
        $triggers_json_string = wp_json_encode(
            $decoded_triggers_for_validation,
            JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES
        );
    }

    $trigger_validator_class = '\\WPAICG\\Lib\\Chat\\Triggers\\Validation\\AIPKit_Trigger_Validator';
    if (!class_exists($trigger_validator_class) && defined('WPAICG_LIB_DIR')) {
        $validator_path = WPAICG_LIB_DIR . 'chatbot/trigger-validation.php';
        if (file_exists($validator_path)) {
            require_once $validator_path;
        }
    }
    if (class_exists($trigger_validator_class)) {
        $validation_result = $trigger_validator_class::validate_triggers_array($decoded_triggers_for_validation);
        if (is_wp_error($validation_result)) {
            return $validation_result;
        }
    }
    update_post_meta($botId, $trigger_meta_key, $triggers_json_string);

    return true;
}

namespace WPAICG\Chat\Storage;

/** Initialize paid defaults only while the Pro implementation is available. */
function initialize_paid_bot_settings_logic(int $post_id): void
{
    \WPAICG\Lib\Chat\LiveSettings::save($post_id, \WPAICG\Lib\Chat\LiveSettings::defaults());
    $trigger_meta_key = '_aipkit_chatbot_triggers'; // Fallback key
    if (class_exists('\WPAICG\Lib\Chat\Triggers\AIPKit_Trigger_Storage')) { // Check for the class in its new Pro location
        $trigger_meta_key = \WPAICG\Lib\Chat\Triggers\AIPKit_Trigger_Storage::META_KEY;
    }

    update_post_meta($post_id, '_aipkit_enable_realtime_voice', BotSettingsManager::DEFAULT_ENABLE_REALTIME_VOICE);
    update_post_meta($post_id, '_aipkit_direct_voice_mode', BotSettingsManager::DEFAULT_DIRECT_VOICE_MODE);
    update_post_meta($post_id, '_aipkit_realtime_model', BotSettingsManager::get_default_model_id('OpenAIRealtime'));
    update_post_meta($post_id, '_aipkit_realtime_voice', BotSettingsManager::get_default_model_id('OpenAIRealtimeVoices'));
    update_post_meta($post_id, '_aipkit_turn_detection', BotSettingsManager::DEFAULT_TURN_DETECTION);
    update_post_meta($post_id, '_aipkit_speed', (string)BotSettingsManager::DEFAULT_SPEED);
    update_post_meta($post_id, '_aipkit_input_audio_format', BotSettingsManager::DEFAULT_INPUT_AUDIO_FORMAT);
    update_post_meta($post_id, '_aipkit_output_audio_format', BotSettingsManager::DEFAULT_OUTPUT_AUDIO_FORMAT);
    update_post_meta($post_id, '_aipkit_input_audio_noise_reduction', BotSettingsManager::DEFAULT_INPUT_AUDIO_NOISE_REDUCTION);

    update_post_meta($post_id, $trigger_meta_key, '[]'); // Use the determined meta key
}

namespace WPAICG\Lib\Chat;

/** One schema for Live defaults, full saves, partial audio saves and rendering. */
final class LiveSettings
{
    public static function defaults(): array
    {
        return [
            'voice_engine' => 'realtime',
            'live_voice' => 'marin',
            'live_backend_model' => 'gpt-5.6-terra',
            'live_max_seconds' => '300',
        ];
    }

    public static function voices(): array
    {
        return explode(' ', 'alloy ash ballad beacon bossa cedar cinder coral delta echo gleam marin meridian quartz ripple sage shimmer stone tempo verse vesper willow');
    }

    public static function choices(): array
    {
        return [
            'voice_engine' => ['realtime', 'live'],
            'live_voice' => self::voices(),
            'live_backend_model' => ['gpt-5.6-terra', 'gpt-5.6-luna'],
            'live_max_seconds' => ['60', '180', '300', '600', '900'],
        ];
    }

    public static function sanitize(array $raw): array
    {
        $result = self::defaults();
        foreach (self::choices() as $key => $allowed) {
            if (isset($raw[$key]) && is_scalar($raw[$key]) && in_array((string) $raw[$key], $allowed, true)) {
                $result[$key] = (string) $raw[$key];
            }
        }
        return $result;
    }

    /** Partial saves leave absent fields intact, including while switching engines. */
    public static function save(int $bot_id, array $raw): void
    {
        foreach (self::sanitize($raw) as $key => $value) {
            if (array_key_exists($key, $raw)) {
                update_post_meta($bot_id, '_aipkit_' . $key, $value);
            }
        }
    }
}
