<?php

namespace BitApps\IntegrationsPro\Actions\Booknetic\Services;

use BookneticApp\Models\Notification;

final class NotificationService extends BaseService
{
    private const IN_APP_TYPE = 'in_app_notification';

    public function createInAppNotification(): array
    {
        $error = $this->validate([
            'user_id' => [__('WordPress User', 'bit-integrations-pro'), 'integer'],
            'title'   => [__('Title', 'bit-integrations-pro')],
            'message' => [__('Message', 'bit-integrations-pro')],
        ]);

        if ($error !== null) {
            return $error;
        }

        if (!get_userdata($this->int('user_id'))) {
            return $this->error(__('The WordPress user does not exist. Select a different user.', 'bit-integrations-pro'));
        }

        $data = [
            'user_id'     => $this->int('user_id'),
            'type'        => self::IN_APP_TYPE,
            'title'       => sanitize_text_field($this->string('title')),
            'message'     => sanitize_textarea_field($this->string('message')),
            'action_type' => '',
            'action_data' => '',
        ];

        if (!Notification::query()->withoutGlobalScope('user_id')->insert($data)) {
            return $this->error(__('Booknetic did not create the notification. Try again.', 'bit-integrations-pro'));
        }

        return $this->success(Notification::query()->withoutGlobalScope('user_id')->get((int) Notification::lastId()));
    }
}
