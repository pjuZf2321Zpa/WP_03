<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Actions\OmniSend\OmniSendHelperPro;
use BitApps\IntegrationsPro\Config;
use BitApps\IntegrationsPro\Core\Util\Hooks;

// Deprecated since v2.7.8 - use bit_integrations_omnisend_* hooks instead
if (bit_integrations_version_below('2.7.8')) {
    Hooks::filter('btcbi_omnisend_custom_properties', [OmniSendHelperPro::class, 'setCustomProperties'], 10, 3);
}

// New hooks since v2.7.8
Hooks::filter(Config::withFreePrefix('omnisend_custom_properties'), [OmniSendHelperPro::class, 'setCustomProperties'], 10, 3);
