<?php

/**
 * MailPoet    Record Api
 */

namespace BitApps\IntegrationsPro\Actions\MailPoet;

class MailPoetProHelper
{
    public static function updateRecord($id, $subscriber)
    {
        try {
            $subscriber = \MailPoet\API\API::MP('v1')->updateSubscriber($id, $subscriber);

            return [
                'success' => true,
                'id'      => $subscriber['id'],
            ];
        } catch (\MailPoet\API\MP\v1\APIException $e) {
            return [
                'success' => false,
                'code'    => $e->getCode(),
                'message' => $e->getMessage(),
            ];
        }
    }
}
