<?php

if (!defined('ABSPATH')) {
    die('You are not allowed to call this page directly.');
}

/**
 * Represents a cart session in the system.
 *
 * @property int $id
 * @property string $session_key
 * @property int|null $user_id
 * @property string $cart_data
 * @property string|null $ip_address
 * @property string|null $created_at
 * @property string $expires_at
 */
#[AllowDynamicProperties]
class MeprCartSession extends MeprBaseModel
{
    /**
     * Constructor for the MeprCartSession class.
     *
     * @param mixed $obj Optional. The object to initialize the cart session with.
     */
    public function __construct($obj = null)
    {
        $this->initialize(
            [
                'id'          => 0,
                'session_key' => '',
                'user_id'     => null,
                'cart_data'   => '{}',
                'ip_address'  => null,
                'created_at'  => null,
                'expires_at'  => null,
            ],
            $obj
        );
    }

    /**
     * Create a new cart session record in the database.
     *
     * @param MeprCartSession $session The cart session object to create.
     *
     * @return integer The ID of the created cart session.
     */
    public static function create(MeprCartSession $session)
    {
        $mepr_db = new MeprDb();

        if (is_null($session->created_at) || empty($session->created_at)) {
            $session->created_at = MeprUtils::ts_to_mysql_date(time());
        }

        $args = (array) $session->get_values();

        // Remove null-valued fields so the DB uses the column's DEFAULT NULL.
        // This prevents prepare() from coercing null to an empty string in bigint columns.
        // Note: use strict null check (not empty()) to preserve legitimate zero values.
        foreach ($args as $key => $value) {
            if (is_null($value)) {
                unset($args[$key]);
            }
        }

        return $mepr_db->create_record($mepr_db->cart_sessions, $args, false);
    }

    /**
     * Find a cart session by its session key.
     *
     * @param  string $session_key The session key to look up.
     * @param  string $return_type Optional. The return type. Default OBJECT.
     * @return object|array|null The cart session record or null if not found.
     */
    public static function find_by_key($session_key, $return_type = OBJECT)
    {
        $mepr_db = new MeprDb();

        return $mepr_db->get_one_record($mepr_db->cart_sessions, ['session_key' => $session_key], $return_type);
    }

    /**
     * Find all cart sessions for a given user.
     *
     * @param  integer $user_id  The user ID.
     * @param  string  $order_by Optional. ORDER BY clause.
     * @param  string  $limit    Optional. LIMIT clause.
     * @return array
     */
    public static function find_by_user($user_id, $order_by = '', $limit = '')
    {
        $mepr_db = new MeprDb();

        return $mepr_db->get_records($mepr_db->cart_sessions, ['user_id' => $user_id], $order_by, $limit);
    }

    /**
     * Update an existing cart session record in the database.
     *
     * @param MeprCartSession $session The cart session object to update.
     *
     * @return integer The ID of the updated cart session.
     */
    public static function update(MeprCartSession $session)
    {
        $mepr_db = new MeprDb();
        $args    = (array) $session->get_values();

        return $mepr_db->update_record($mepr_db->cart_sessions, $session->id, $args);
    }

    /**
     * Persist the cart session (create if new, update if existing).
     *
     * @return integer The session ID.
     */
    public function store()
    {
        if (isset($this->id) && !is_null($this->id) && (int) $this->id > 0) {
            self::update($this);
        } else {
            $this->id = self::create($this);
        }

        return (int) $this->id;
    }

    /**
     * Returns true when the session's expires_at timestamp is in the past.
     *
     * @return boolean
     */
    public function is_expired(): bool
    {
        if (empty($this->expires_at)) {
            return false;
        }
        return strtotime($this->expires_at) < time();
    }

    /**
     * Delete the cart session from the database.
     *
     * @return boolean|integer False on failure, number of rows deleted on success.
     */
    public function destroy()
    {
        $mepr_db = new MeprDb();
        $id      = $this->id;
        $args    = compact('id');

        return $mepr_db->delete_records($mepr_db->cart_sessions, $args);
    }
}
