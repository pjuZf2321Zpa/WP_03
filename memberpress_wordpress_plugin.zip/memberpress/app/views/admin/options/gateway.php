<?php if (!defined('ABSPATH')) {
    die('You are not allowed to call this page directly.');
} ?>
<div id="mepr-integration-<?php echo esc_attr($obj->id); ?>" class="mepr-integration" data-id="<?php echo esc_attr($obj->id); ?>" data-gateway="<?php echo esc_attr(get_class($obj)); ?>">
  <div class="mepr-integration-delete">
    <a href=""><i class="mp-icon mp-icon-cancel-circled mp-16"></i></a>
  </div>
  <div class="mp-row">
    <div class="mepr-integration-setup-form">
      <input type="hidden" value="<?php echo esc_attr($obj->id); ?>" name="<?php echo esc_attr("{$mepr_options->integrations_str}[{$obj->id}][id]"); ?>" />
      <input type="hidden" value="1" name="<?php echo esc_attr("{$mepr_options->integrations_str}[{$obj->id}][saved]"); ?>" />
      <div class="mp-row">
        <strong><?php esc_html_e('Name:', 'memberpress'); ?></strong>
        <input type="text" id="<?php echo esc_attr("{$mepr_options->integrations_str}-{$obj->id}-label"); ?>" name="<?php echo esc_attr("{$mepr_options->integrations_str}[{$obj->id}][label]"); ?>" value="<?php echo esc_attr($obj->label); ?>" />
      </div>
      <div class="mp-row">
        <strong><?php esc_html_e('Gateway:', 'memberpress'); ?></strong>
        <?php
        if (isset($obj->settings->gateway) && isset($obj->settings->saved) && $obj->settings->saved) : ?>
          <input type="hidden" value="<?php echo esc_attr($obj->settings->gateway); ?>" name="<?php echo esc_attr("{$mepr_options->integrations_str}[{$obj->id}][gateway]"); ?>" />
          <span><?php echo esc_html($obj->name); ?></span>
            <?php if (!empty($obj->icon)) : ?>
            <div><img src="<?php echo esc_url($obj->icon); ?>" height="32px" /></div>
            <?php endif; ?>
            <?php
        else :
            MeprOptionsHelper::gateways_dropdown("{$mepr_options->integrations_str}[{$obj->id}][gateway]", isset($obj->settings->gateway) ? $obj->settings->gateway : '', $obj->id);
        endif; ?>
      </div>
      <div class="mp-row">
        <strong><?php esc_html_e('ID:', 'memberpress'); ?></strong>
        <?php echo esc_html($obj->id); ?>
      </div>
      <div class="mp-row">
        <div><label><input type="checkbox" id="<?php echo esc_attr("{$mepr_options->integrations_str}-{$obj->id}-use_label"); ?>" name="<?php echo esc_attr("{$mepr_options->integrations_str}[{$obj->id}][use_label]"); ?>" value="<?php echo esc_attr($obj->use_label); ?>" <?php checked($obj->use_label); ?> />&nbsp;&nbsp;<?php esc_html_e('Show Payment Label', 'memberpress'); ?></label></div>
        <div><label><input type="checkbox" id="<?php echo esc_attr("{$mepr_options->integrations_str}-{$obj->id}-use_icon"); ?>" name="<?php echo esc_attr("{$mepr_options->integrations_str}[{$obj->id}][use_icon]"); ?>" value="<?php echo esc_attr($obj->use_icon); ?>" <?php checked($obj->use_icon); ?> />&nbsp;&nbsp;<?php esc_html_e('Show Payment Icon', 'memberpress'); ?></label></div>
        <div><label><input type="checkbox" id="<?php echo esc_attr("{$mepr_options->integrations_str}-{$obj->id}-use_desc"); ?>" name="<?php echo esc_attr("{$mepr_options->integrations_str}[{$obj->id}][use_desc]"); ?>" value="<?php echo esc_attr($obj->use_desc); ?>" <?php checked($obj->use_desc); ?> />&nbsp;&nbsp;<?php esc_html_e('Show Payment Description', 'memberpress'); ?></label></div>
        <div class="mepr-cart-gateway-toggle"><label><input type="checkbox" id="<?php echo esc_attr("{$mepr_options->integrations_str}-{$obj->id}-enable_for_cart"); ?>" name="<?php echo esc_attr("{$mepr_options->integrations_str}[{$obj->id}][enable_for_cart]"); ?>" value="1" <?php checked($cart_capable && !empty($obj->settings->enable_for_cart)); ?> <?php disabled(!$cart_capable); ?> />&nbsp;&nbsp;<?php esc_html_e('Enable for cart', 'memberpress'); ?></label><?php if (!$cart_capable) {
            MeprAppHelper::info_tooltip(
                "{$obj->id}-enable-for-cart",
                __('Enable for cart', 'memberpress'),
                __('Cart checkout doesn\'t support this payment method yet.', 'memberpress')
            );
                                                                                } elseif ($obj instanceof MeprStripeGateway) {
                                                                                    MeprAppHelper::info_tooltip(
                                                                                        "{$obj->id}-enable-for-cart",
                                                                                        __('Enable for cart', 'memberpress'),
                                                                                        __('The cart always uses Stripe Elements (on-site). The Elements / Checkout choice in this gateway only affects the standalone registration page — it does not change the cart.', 'memberpress')
                                                                                    );
                                                                                } ?></div>
      </div>
    </div>
    <div class="mepr-integration-gateway-form">
      <?php
        if ($obj instanceof MeprBaseRealGateway) {
            $obj->display_options_form();
        }
        ?>
    </div>
  </div>
</div>

