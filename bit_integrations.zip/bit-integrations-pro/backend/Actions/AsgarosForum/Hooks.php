<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Actions\AsgarosForum\AsgarosForumProHelper;
use BitApps\IntegrationsPro\Config;
use BitApps\IntegrationsPro\Core\Util\Hooks;

Hooks::filter(Config::withFreePrefix('asgaros_forum_create_topic'), [AsgarosForumProHelper::class, 'createTopic'], 10, 2);
Hooks::filter(Config::withFreePrefix('asgaros_forum_create_forum'), [AsgarosForumProHelper::class, 'createForum'], 10, 2);
Hooks::filter(Config::withFreePrefix('asgaros_forum_post_reply_in_topic'), [AsgarosForumProHelper::class, 'postReplyInTopic'], 10, 2);
Hooks::filter(Config::withFreePrefix('asgaros_forum_subscribe_user_in_forum'), [AsgarosForumProHelper::class, 'subscribeUserInForum'], 10, 2);
