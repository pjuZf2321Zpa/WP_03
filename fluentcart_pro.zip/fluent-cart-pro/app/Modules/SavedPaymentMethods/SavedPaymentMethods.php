<?php

namespace FluentCartPro\App\Modules\SavedPaymentMethods;

use FluentCart\Api\StoreSettings;
use FluentCartPro\App\Modules\SavedPaymentMethods\Settings\SettingsHandler;

/**
 * Saved Payment Methods (Cards on File) — pro feature entry point.
 *
 * Ships in fluent-cart-pro using core extension hooks. SPM-01 wires the
 * merchant setting; the customer-facing surfaces (profile section, checkout
 * selector, off-session charge) all gate on isEnabled().
 *
 * The portal UI is a section of core's Profile page rather than a page of its
 * own — see ProfileSection.
 */
class SavedPaymentMethods
{
    public function register($app): void
    {
        // The merchant setting is always available so the toggle can be found.
        (new SettingsHandler())->register();

        // Bound at boot, NOT from inside the init callback below. Core fires
        // fluent_cart/register_payment_methods from its own init callback, which
        // is queued at plugin-include time (Application::requireCommonFiles ->
        // app/Hooks/actions.php) and therefore always runs before one bound here
        // on `fluentcart_loaded`. Binding from inside an init callback means the
        // action has already fired and the gateway never registers at all — an
        // order whose payment_method is `fct_saved_card` then cannot resolve a
        // gateway and never charges. The feature gate lives in the callback body,
        // which runs during init where store settings are reliably readable.
        // This mirrors how the other pro gateways register (boot/app.php).
        add_action('fluent_cart/register_payment_methods', function () {
            if (!self::isEnabled()) {
                return;
            }

            Gateway\SavedCardGateway::register();
        });

        add_action('init', function () use ($app) {
            // Everything customer-facing is gated behind the setting.
            if (!self::isEnabled()) {
                return;
            }

            (new ProfileSection())->register();
            (new Checkout\CheckoutSaveHandler())->register();
            (new Checkout\SavePaymentMethodHandler())->register();
            (new Checkout\SavedCardSelector())->register();
            (new PayPal\PayPalVaultNotice())->register();

            $app->router->group(function ($router) {
                require __DIR__ . '/Http/Routes/routes.php';
            });
        });
    }

    /**
     * Master gate for the whole feature. Every later surface checks this.
     */
    public static function isEnabled(): bool
    {
        return (new StoreSettings())->get(SettingsHandler::SETTING_KEY, 'no') === 'yes';
    }
}
