<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Core\Util\Route;
use BitApps\IntegrationsPro\Triggers\FluentBooking\FluentBookingController;

Route::get('fluentbooking/get', [FluentBookingController::class, 'getAll']);
Route::post('fluentbooking/get/form', [FluentBookingController::class, 'get_a_form']);
Route::post('fluentbooking/get/fields', [FluentBookingController::class, 'fields']);
