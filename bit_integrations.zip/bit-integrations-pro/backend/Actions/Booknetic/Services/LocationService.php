<?php

namespace BitApps\IntegrationsPro\Actions\Booknetic\Services;

use BookneticApp\Backend\Locations\DTOs\Request\CreateLocationRequest;
use BookneticApp\Backend\Locations\DTOs\Request\UpdateLocationRequest;
use BookneticApp\Backend\Locations\Services\LocationService as BookneticLocationService;
use BookneticApp\Models\Appointment;
use BookneticApp\Models\Location;
use BookneticApp\Models\LocationCategory;
use BookneticApp\Models\Staff;
use BookneticApp\Providers\IoC\Container;

final class LocationService extends BaseService
{
    private const REQUEST_FIELDS = [
        'name'              => 'name',
        'address'           => 'address',
        'phone'             => 'phone_number',
        'note'              => 'notes',
        'latitude'          => 'latitude',
        'longitude'         => 'longitude',
        'addressComponents' => 'address_components',
    ];

    public function createLocation(): array
    {
        $error = $this->validate(['name' => [__('Name', 'bit-integrations-pro')]]);

        if ($error !== null) {
            return $error;
        }

        if ($this->missingCategory()) {
            return $this->error(__('The location category does not exist. Select a different category.', 'bit-integrations-pro'));
        }

        $request = new CreateLocationRequest();
        $this->populateRequest($request);

        $locationId = Container::get(BookneticLocationService::class)->create($request);

        return $this->success(Location::query()->get($locationId));
    }

    public function updateLocation(): array
    {
        $error = $this->validate(['location_id' => [__('Location ID', 'bit-integrations-pro'), 'integer']]);

        if ($error !== null) {
            return $error;
        }

        $locationId = $this->int('location_id');
        $location = Location::query()->get($locationId);

        if (empty($location)) {
            return $this->error(__('The location does not exist. Select a different location.', 'bit-integrations-pro'));
        }

        if ($this->missingCategory()) {
            return $this->error(__('The location category does not exist. Select a different category.', 'bit-integrations-pro'));
        }

        $request = new UpdateLocationRequest();
        $this->populateRequest($request, $location);

        Container::get(BookneticLocationService::class)->update($locationId, $request);

        return $this->success(Location::query()->get($locationId));
    }

    public function deleteLocation(): array
    {
        $error = $this->validate(['location_id' => [__('Location ID', 'bit-integrations-pro'), 'integer']]);

        if ($error !== null) {
            return $error;
        }

        $locationId = $this->int('location_id');

        if (empty(Location::query()->get($locationId))) {
            return $this->error(__('The location does not exist. Select a different location.', 'bit-integrations-pro'));
        }

        if (Staff::query()->whereFindInSet('locations', $locationId)->count() > 0) {
            return $this->error(__('Staff members work at this location. Remove the location from the staff members first.', 'bit-integrations-pro'));
        }

        if (Appointment::query()->where('location_id', $locationId)->count() > 0) {
            return $this->error(__('The location has appointments. Delete the appointments first.', 'bit-integrations-pro'));
        }

        Container::get(BookneticLocationService::class)->delete($locationId);

        return $this->success(['location_id' => $locationId], __('The location is deleted.', 'bit-integrations-pro'));
    }

    public function duplicateLocation(): array
    {
        $error = $this->validate(['location_id' => [__('Location ID', 'bit-integrations-pro'), 'integer']]);

        if ($error !== null) {
            return $error;
        }

        $locationId = $this->int('location_id');

        if (empty(Location::query()->get($locationId))) {
            return $this->error(__('The location does not exist. Select a different location.', 'bit-integrations-pro'));
        }

        $newId = Container::get(BookneticLocationService::class)->duplicate($locationId);

        return $this->success(Location::query()->get($newId));
    }

    public function setLocationStatus(): array
    {
        $error = $this->validate([
            'location_id' => [__('Location ID', 'bit-integrations-pro'), 'integer'],
            'is_active'   => [__('Status', 'bit-integrations-pro')],
        ]);

        if ($error !== null) {
            return $error;
        }

        return $this->updateRecord(Location::class, $this->int('location_id'), ['is_active' => (int) $this->toBool($this->value('is_active'))]);
    }

    private function missingCategory(): bool
    {
        return $this->has('category_id') && empty(LocationCategory::query()->get($this->int('category_id')));
    }

    private function populateRequest($request, $location = null): void
    {
        foreach (self::REQUEST_FIELDS as $property => $column) {
            $value = $this->string($column);

            if ($value === '' && $location !== null) {
                $value = (string) ($location->{$column} ?? '');
            }

            $request->{$property} = $value;
        }

        $categoryId = $this->string('category_id');

        if ($categoryId === '' && $location !== null) {
            $categoryId = $location->category_id;
        }

        $request->categoryId = (int) $categoryId;
        $request->translations = '';
    }
}
