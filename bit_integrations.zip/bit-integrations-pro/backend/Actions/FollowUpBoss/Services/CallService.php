<?php

namespace BitApps\IntegrationsPro\Actions\FollowUpBoss\Services;

final class CallService extends BaseService
{
    public function logCall(): array
    {
        $validationRules = [
            'person_id'   => ['required', 'integer'],
            'phone'       => ['required'],
            'is_incoming' => ['required', 'boolean'],
            'duration'    => ['nullable', 'integer'],
        ];
        $error = $this->validateFields(
            $validationRules,
            [
                'person_id'   => __('Person ID', 'bit-integrations-pro'),
                'phone'       => __('Phone', 'bit-integrations-pro'),
                'is_incoming' => __('Call Direction', 'bit-integrations-pro'),
                'duration'    => __('Duration', 'bit-integrations-pro'),
            ],
            ['is_incoming']
        );

        if ($error !== null) {
            return $error;
        }

        $payload = $this->removeEmptyValues(
            [
                'personId'     => $this->getInteger('person_id'),
                'phone'        => $this->getString('phone'),
                'isIncoming'   => $this->getBoolean('is_incoming'),
                'note'         => $this->getString('note'),
                'outcome'      => $this->getString('outcome'),
                'duration'     => $this->getInteger('duration'),
                'toNumber'     => $this->getString('to_number'),
                'fromNumber'   => $this->getString('from_number'),
                'userId'       => $this->getInteger('user_id'),
                'recordingUrl' => $this->getString('recording_url'),
            ]
        );

        return $this->dispatch('POST', '/calls', $payload);
    }

    public function updateCall(): array
    {
        $validationRules = [
            'call_id'  => ['required', 'integer'],
            'duration' => ['nullable', 'integer'],
        ];
        $error = $this->validateFields(
            $validationRules,
            [
                'call_id'  => __('Call ID', 'bit-integrations-pro'),
                'duration' => __('Duration', 'bit-integrations-pro'),
            ]
        );

        if ($error !== null) {
            return $error;
        }

        $payload = $this->removeEmptyValues(
            [
                'personId'     => $this->getInteger('person_id'),
                'phone'        => $this->getString('phone'),
                'isIncoming'   => $this->getBoolean('is_incoming'),
                'note'         => $this->getString('note'),
                'outcome'      => $this->getString('outcome'),
                'duration'     => $this->getInteger('duration'),
                'toNumber'     => $this->getString('to_number'),
                'fromNumber'   => $this->getString('from_number'),
                'userId'       => $this->getInteger('user_id'),
                'recordingUrl' => $this->getString('recording_url'),
            ]
        );

        return $this->dispatch('PUT', '/calls/' . rawurlencode($this->getString('call_id')), $payload);
    }
}
