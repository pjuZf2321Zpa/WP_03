<?php

namespace WPAICG\Lib\Integrations\Apps\Ajax;

use WPAICG\AIPKit_Role_Manager;
use WPAICG\Lib\Integrations\Apps\AIPKit_App_Connection_Diagnostics;
use WP_Error;

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

class AIPKit_App_Connections_Ajax_Handler
{
    public function handle(): void
    {
        $permission_check = $this->check_permissions();
        if (is_wp_error($permission_check)) {
            $this->send_wp_error($permission_check);
            return;
        }

        // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Verified in check_permissions().
        $connection_id = sanitize_text_field((string) wp_unslash($_POST['connection_id'] ?? ''));
        if ($connection_id === '') {
            $this->send_wp_error(
                new WP_Error(
                    'aipkit_missing_connection_id',
                    __('Connection ID is required.', 'gpt3-ai-content-generator'),
                    ['status' => 400]
                )
            );
            return;
        }

        $result = AIPKit_App_Connection_Diagnostics::test_connection_by_id($connection_id, get_current_user_id());
        if (is_wp_error($result)) {
            $this->send_wp_error($result);
            return;
        }

        wp_send_json_success($result);
    }

    /**
     * @return bool|\WP_Error
     */
    private function check_permissions()
    {
        if (!check_ajax_referer('aipkit_nonce', '_ajax_nonce', false)) {
            return new WP_Error(
                'nonce_failure',
                __('Security check failed (nonce).', 'gpt3-ai-content-generator'),
                ['status' => 403]
            );
        }

        if (!AIPKit_Role_Manager::user_can_access_module('settings')) {
            return new WP_Error(
                'permission_denied',
                __('You do not have permission to perform this action.', 'gpt3-ai-content-generator'),
                ['status' => 403]
            );
        }

        return true;
    }

    private function send_wp_error(WP_Error $error): void
    {
        $error_data = [
            'message' => $error->get_error_message(),
            'code' => $error->get_error_code(),
        ];

        $details = $error->get_error_data();
        $status_code = is_array($details) && isset($details['status']) ? (int) $details['status'] : 400;
        if (is_array($details) && !empty($details)) {
            $error_data['details'] = $details;
        }

        wp_send_json_error($error_data, $status_code);
    }
}
