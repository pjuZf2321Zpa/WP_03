<?php

namespace MasterStudy\Lms\Pro\AddonsPlus\Calendar\Routing\Swagger\Routes;

use MasterStudy\Lms\Routing\Swagger\RequestInterface;
use MasterStudy\Lms\Routing\Swagger\ResponseInterface;
use MasterStudy\Lms\Routing\Swagger\Route;

final class DayEvents extends Route implements RequestInterface, ResponseInterface {
	public function request(): array {
		return array(
			'date'     => array(
				'type'        => 'string',
				'description' => 'Calendar date in Y-m-d format.',
				'required'    => true,
			),
			'page'     => array(
				'type'        => 'integer',
				'description' => 'Page number.',
				'required'    => false,
				'default'     => 1,
			),
			'per_page' => array(
				'type'        => 'integer',
				'description' => 'Events per page.',
				'required'    => false,
				'default'     => 10,
			),
			'type'     => array(
				'type'        => 'string',
				'description' => 'Optional event type filter.',
				'required'    => false,
				'enum'        => array( 'zoom', 'meet', 'stream', 'deadline', 'quiz', 'available' ),
			),
		);
	}

	public function response(): array {
		return array(
			'events'     => array(
				'type'        => 'array',
				'description' => 'Calendar events.',
				'items'       => array(
					'type'       => 'object',
					'properties' => EventSchema::properties(),
				),
			),
			'pagination' => array(
				'type'        => 'object',
				'description' => 'Pagination metadata.',
				'properties'  => EventSchema::pagination(),
			),
		);
	}

	public function get_summary(): string {
		return 'Get Calendar Day Events';
	}

	public function get_description(): string {
		return 'Returns paginated events for one calendar day.';
	}
}
