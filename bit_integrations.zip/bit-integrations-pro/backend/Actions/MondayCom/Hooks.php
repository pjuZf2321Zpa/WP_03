<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Actions\MondayCom\MondayComProHelper;
use BitApps\IntegrationsPro\Config;
use BitApps\IntegrationsPro\Core\Util\Hooks;

Hooks::filter(Config::withFreePrefix('mondayCom_create_item'), [MondayComProHelper::class, 'createItem'], 10, 4);
Hooks::filter(Config::withFreePrefix('mondayCom_update_item'), [MondayComProHelper::class, 'updateItem'], 10, 4);
Hooks::filter(Config::withFreePrefix('mondayCom_create_subitem'), [MondayComProHelper::class, 'createSubitem'], 10, 4);
Hooks::filter(Config::withFreePrefix('mondayCom_move_item_to_group'), [MondayComProHelper::class, 'moveItemToGroup'], 10, 3);
Hooks::filter(Config::withFreePrefix('mondayCom_archive_item'), [MondayComProHelper::class, 'archiveItem'], 10, 4);
Hooks::filter(Config::withFreePrefix('mondayCom_delete_item'), [MondayComProHelper::class, 'deleteItem'], 10, 4);
Hooks::filter(Config::withFreePrefix('mondayCom_archive_board'), [MondayComProHelper::class, 'archiveBoard'], 10, 3);
Hooks::filter(Config::withFreePrefix('mondayCom_archive_group'), [MondayComProHelper::class, 'archiveGroup'], 10, 4);
Hooks::filter(Config::withFreePrefix('mondayCom_delete_group'), [MondayComProHelper::class, 'deleteGroup'], 10, 4);
Hooks::filter(Config::withFreePrefix('mondayCom_create_group'), [MondayComProHelper::class, 'createGroup'], 10, 4);
Hooks::filter(Config::withFreePrefix('mondayCom_duplicate_group'), [MondayComProHelper::class, 'duplicateGroup'], 10, 4);
Hooks::filter(Config::withFreePrefix('mondayCom_create_column'), [MondayComProHelper::class, 'createColumn'], 10, 4);
