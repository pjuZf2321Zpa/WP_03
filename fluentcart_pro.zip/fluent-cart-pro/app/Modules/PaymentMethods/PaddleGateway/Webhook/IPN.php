<?php

namespace FluentCartPro\App\Modules\PaymentMethods\PaddleGateway\Webhook;

use FluentCart\App\App;
use FluentCartPro\App\Modules\PaymentMethods\PaddleGateway\API\API;
use FluentCartPro\App\Modules\PaymentMethods\PaddleGateway\Confirmations;
use FluentCartPro\App\Modules\PaymentMethods\PaddleGateway\PaddleHelper;
use FluentCartPro\App\Modules\PaymentMethods\PaddleGateway\PaddleReconciler;
use FluentCartPro\App\Modules\PaymentMethods\PaddleGateway\PaddleSettings;
use FluentCart\App\Events\Subscription\SubscriptionActivated;
use FluentCart\App\Events\Subscription\SubscriptionCanceled;
use FluentCart\App\Helpers\CurrenciesHelper;
use FluentCart\App\Helpers\Status;
use FluentCart\App\Helpers\StatusHelper;
use FluentCart\App\Models\OrderTransaction;
use FluentCart\App\Models\Order;
use FluentCart\App\Models\Subscription;
use FluentCart\App\Services\Payments\SubscriptionHelper;
use FluentCart\Framework\Support\Arr;

class IPN
{
    private PaddleSettings $settings;

    /**
     * Handlers run on the instance registered in init(), not the one answering the
     * webhook, so a processing failure is handed back through this shared slot.
     *
     * @var \WP_Error|null
     */
    private static $processingError = null;

    public function __construct()
    {
        $this->settings = new PaddleSettings();
    }

    public function init(): void
    {
        // Register webhook event handlers
        add_action('fluent_cart/payments/paddle/webhook_transaction_paid', [$this, 'handleTransactionPaid'], 10, 1); //done
        add_action('fluent_cart/payments/paddle/webhook_transaction_completed', [$this, 'handleTransactionCompleted'], 10, 1); //done
        add_action('fluent_cart/payments/paddle/webhook_subscription_payment_received', [$this, 'handleSubscriptionPaymentReceived'], 10, 1); // done
        add_action('fluent_cart/payments/paddle/webhook_transaction_payment_failed', [$this, 'handleTransactionPaymentFailed'], 10, 1);
        add_action('fluent_cart/payments/paddle/webhook_subscription_created', [$this, 'handleSubscriptionActivated'], 10, 1); //done
        add_action('fluent_cart/payments/paddle/webhook_subscription_activated', [$this, 'handleSubscriptionActivated'], 10, 1); // done
        add_action('fluent_cart/payments/paddle/webhook_subscription_past_due', [$this, 'handleSubscriptionUpdated'], 10, 1); // done
        add_action('fluent_cart/payments/paddle/webhook_subscription_updated', [$this, 'handleSubscriptionUpdated'], 10, 1); // done
        add_action('fluent_cart/payments/paddle/webhook_subscription_canceled', [$this, 'handleSubscriptionCanceled'], 10, 1); //done
        add_action('fluent_cart/payments/paddle/webhook_subscription_paused', [$this, 'handleSubscriptionUpdated'], 10, 1); //done
        add_action('fluent_cart/payments/paddle/webhook_subscription_resumed', [$this, 'handleSubscriptionUpdated'], 10, 1); //done

        // adjustments/ refunds
        add_action('fluent_cart/payments/paddle/webhook_adjustment_created', [$this, 'handleAdjustmentCreated'], 10, 1); //done
        add_action('fluent_cart/payments/paddle/webhook_adjustment_updated', [$this, 'handleAdjustmentUpdated'], 10, 1); //done
    }

    /**
     * Verify and process webhook
     */
    public function verifyAndProcess()
    {
        $rawPayload = file_get_contents('php://input');
        $payload = json_decode($rawPayload, true);

        if (!$payload) {
            $this->sendResponse(400, 'Invalid JSON payload');
            return;
        }

        // Verify webhook signature if not disabled
        if (!$this->settings->isWebhookVerificationDisabled()) {

            $webhookSecret = $this->settings->getWebhookSecret();

            $signatureValid = false;
            if (!empty($webhookSecret)) {
                $verifier        = new WebhookVerifier($webhookSecret);
                $paddleSignature = $verifier->getPaddleSignatureFromHeaders($_SERVER) ?? '';
                $signatureValid  = $verifier->verify($paddleSignature, $rawPayload);
            }

            if (!$signatureValid) {
                $isAutoRecoverEnabled = apply_filters('fluent_cart/paddle/webhook_auto_recover_enabled', true, [
                    'payload' => $payload
                ]);

                if (!$isAutoRecoverEnabled) {
                    $this->sendResponse(401, 'Invalid webhook signature & auto-recover disabled');
                    return;
                }

                // Bypass enabled — pull entity from Paddle API to confirm the request
                // refers to a real entity in the expected state. Replaces payload data
                // with the authoritative API response; entity state is validated against
                // the claimed event before any handler is dispatched.
                $apiEntityData = $this->fetchEntityFromApi($payload);
                if (!$apiEntityData) {
                    $this->sendResponse(401, 'Entity not found or API error!');
                    return;
                }

                // Guard: event_type is still attacker-supplied. Validate that the fetched
                // entity's actual Paddle status is consistent with the claimed event so a
                // forged subscription.canceled cannot cancel an active subscription.
                $bypassEventType = Arr::get($payload, 'event_type', '');
                if (!$this->entityStateMatchesEvent($bypassEventType, $apiEntityData)) {
                    error_log('Paddle Webhook: bypass rejected — entity state inconsistent with event: ' . $bypassEventType);
                    $this->sendResponse(401, 'Entity state inconsistent with event, expected: ' . $bypassEventType . ' (actual: ' . Arr::get($apiEntityData, 'status', 'unknown') . ')');
                    return;
                }

                $payload['data'] = $apiEntityData;
                do_action('fluent_cart/paddle/webhook_signature_bypass', [
                    'event_type' => $bypassEventType,
                    'entity_id'  => Arr::get($apiEntityData, 'id'),
                ]);
            }
        }

        $order = PaddleHelper::getOrderFromWebhookData($payload);

        if (!$order) {
            $this->sendResponse(200, 'Order not found');
            return;
        }

        $eventType = Arr::get($payload, 'event_type');

        $acceptedEvents = [
            'transaction.paid',
            'transaction.completed',
            'transaction.payment_failed',
            'transaction.refunded',
            'adjustment.created',
            'adjustment.updated',
            'subscription.created',
            'subscription.activated',
            'subscription.updated',
            'subscription.canceled',
            'subscription.paused',
            'subscription.resumed',
            'subscription.past_due'
        ];

        if (!in_array($eventType, $acceptedEvents)) {
            $this->sendResponse(200, 'Event type not handled');
            return;
        }

        // Log webhook for debugging
        do_action('fluent_cart/paddle_webhook_received', [
            'event_type' => $eventType,
            'data' => $payload,
            'raw' => $rawPayload,
            'order' => $order
        ]);

        // Process the webhook event
        $eventTypeFormatted = str_replace('.', '_', $eventType);

        if ($eventTypeFormatted === 'transaction_completed') {
            $paddleTransaction = Arr::get($payload, 'data');
            $vendorSubscriptionId = Arr::get($paddleTransaction, 'subscription_id');

            if ($vendorSubscriptionId) {
                $eventTypeFormatted = 'subscription_payment_received';
            }
        }
        
        if (has_action('fluent_cart/payments/paddle/webhook_' . $eventTypeFormatted)) {
            self::$processingError = null;

            do_action('fluent_cart/payments/paddle/webhook_' . $eventTypeFormatted, [
                'event_type' => $eventType,
                'data' => $payload,
                'raw' => $rawPayload,
                'order' => $order
            ]);

            // A non-2xx makes Paddle redeliver the event, which is the durable retry.
            if (is_wp_error(self::$processingError)) {
                $this->sendResponse(500, 'Webhook processing failed: ' . self::$processingError->get_error_message());
            }

            $this->sendResponse(200, 'Webhook processed successfully');
        } else {
            $this->sendResponse(200, 'No handler found for event type');
        }
    }

    public function handleTransactionPaid($webhookData)
    {
        $payload = Arr::get($webhookData, 'data');
        $paddleTransaction = Arr::get($payload, 'data');
        $paddleTransactionId = Arr::get($paddleTransaction, 'id');

        $customData = Arr::get($paddleTransaction, 'custom_data', []);
        $transactionHash = Arr::get($customData, 'fct_transaction_hash');

        $transactionModel = OrderTransaction::query()->where('vendor_charge_id', $paddleTransactionId)->first();

        if (!$transactionModel && $transactionHash) {
            $transactionModel = OrderTransaction::query()->where('uuid', $transactionHash)->first();
        }

        if (!$transactionModel) {
            return false;
        }

        $order = Order::query()->where('id', $transactionModel->order_id)->first();

        if (!$order) {
            return false;
        }

        if (!PaddleHelper::isExpectedCheckoutTransaction($transactionModel, $order, $paddleTransactionId)) {
            return false;
        }

        if ($transactionModel->status === Status::TRANSACTION_SUCCEEDED) {
            // Already confirmed elsewhere — re-run reconciliation idempotently to normalize
            // any buyer-currency total left on the order before syncing statuses.
            $reconcile = PaddleReconciler::reconcile($transactionModel, $paddleTransaction, $order);
            if ($reconcile['changed']) {
                $transactionModel->total    = (int) $reconcile['amount'];
                $transactionModel->currency = $reconcile['currency'];
                $transactionModel->meta     = array_merge($transactionModel->meta ?? [], $reconcile['meta']);
                $transactionModel->save();
                $order = Order::query()->where('id', $order->id)->first();
            }
            (new StatusHelper($order))->syncOrderStatuses($transactionModel);
            return false;
        }

        (new Confirmations())->confirmPaymentSuccessByCharge($transactionModel, [
            'vendor_charge_id' => $paddleTransactionId,
            'charge' => $paddleTransaction
        ]);

        return true;
    }

    public function handleTransactionCompleted($webhookData)
    {
        
        $this->handleTransactionPaid($webhookData);
        // transaction.completed fires after transaction.paid — invoicing, tax receipts, entitlement provisioning.
        // Payment confirmation is already handled by handleTransactionPaid; calling it again here
        // causes duplicate OrderPaid events and double admin emails.
    }

    public function handleAdjustmentCreated($webhookData)
    {
        $payload = Arr::get($webhookData, 'data');
        $paddleAdjustment = Arr::get($payload, 'data');
        $paddleAdjustmentId = Arr::get($paddleAdjustment, 'id');
        $action = Arr::get($paddleAdjustment, 'action');

        // We are only handling refunds adjustment for now
        if ($action !== 'refund') {
            return false;
        }

        $parentTransactionId = Arr::get($paddleAdjustment, 'transaction_id');

        $order = Arr::get($webhookData, 'order');

        $parentTransaction = OrderTransaction::query()->where('vendor_charge_id', $parentTransactionId)->first();

        if (!$parentTransaction) {
            return false;
        }

        $parentTaxMode = Arr::get($parentTransaction, 'meta.tax_mode', '');

        if (!$parentTaxMode) {
            $parentTaxMode = (new PaddleSettings())->get('tax_mode');
        }

        $paddleRefundAmount = 0;
        foreach (Arr::get($paddleAdjustment, 'items', []) as $item) {
            if ($parentTaxMode === 'external') {
                $paddleRefundAmount += Arr::get($item, 'totals.subtotal', 0);
            } else {
                $paddleRefundAmount += Arr::get($item, 'totals.total', 0);
            }
        }

        // Adjustment totals are in the charged (buyer) currency, in Paddle's native units:
        // zero-decimal currencies (JPY) arrive as whole units while FluentCart stores every
        // amount ×100 — same normalization as CapturedCharge::fromPaddle.
        $paddleTotals    = (array) Arr::get($parentTransaction->meta ?? [], 'paddle_totals', []);
        $chargedCurrency = strtoupper((string) Arr::get($paddleTotals, 'currency_code', ''));
        if (!$chargedCurrency && $order) {
            $chargedCurrency = strtoupper((string) $order->currency);
        }
        $chargedIsZeroDecimal = $chargedCurrency && CurrenciesHelper::isZeroDecimal($chargedCurrency);
        if ($chargedIsZeroDecimal) {
            $paddleRefundAmount *= 100;
        }

        // When the checkout was localized to a different currency than the order, convert
        // back to the order currency using the charged-total ↔ recorded-total ratio so
        // refund accounting matches the normalized transaction.
        if ($order && $chargedCurrency && $chargedCurrency !== strtoupper((string) $order->currency)) {
            $chargedTotal = (int) Arr::get($paddleTotals, 'total', 0);
            if ($chargedIsZeroDecimal) {
                $chargedTotal *= 100;
            }
            if ($chargedTotal > 0 && (int) $parentTransaction->total > 0) {
                $paddleRefundAmount = (int) round($paddleRefundAmount * ((int) $parentTransaction->total / $chargedTotal));
            }
        }

        $status = self::transformAdjustmentStatus(Arr::get($paddleAdjustment, 'status'));

        $recorded = \FluentCart\App\Services\Payments\Refund::createOrRecordRefund([
            'vendor_charge_id' => $paddleAdjustmentId,
            'payment_method'   => 'paddle',
            'status'           => $status,
            'total'            => $paddleRefundAmount,
        ], $parentTransaction);

        if (is_wp_error($recorded) && $recorded->get_error_code() === 'refund_lock_timeout') {
            self::$processingError = $recorded;
        }

        return $recorded;

   }

   public static function transformAdjustmentStatus($paddleStatus)
   {
       $statusMap = [
            'approved' => Status::TRANSACTION_REFUNDED,
            'pending_approval' => Status::TRANSACTION_PENDING,
            'rejected' => Status::TRANSACTION_FAILED,
        ];

        return Arr::get($statusMap, strtolower($paddleStatus), Status::TRANSACTION_PENDING);
   }

   public function handleAdjustmentUpdated($webhookData)
    {
        return $this->handleAdjustmentCreated($webhookData);
    }

    public function handleSubscriptionPaymentReceived($webhookData)
    {
        $order = Arr::get($webhookData, 'order');
        $payload = Arr::get($webhookData, 'data');

        $paddleSubscriptionId = Arr::get($payload, 'data.subscription_id');

        $subscriptionModel = Subscription::query()->where('vendor_subscription_id', $paddleSubscriptionId)->first();

        if (!$subscriptionModel) {
            $subscriptionModel = Subscription::query()->where('parent_order_id', $order->id)->first();
        }

        if (!$subscriptionModel) {
            do_action('fluent_cart/paddle/webhook_subscription_unmatched', [
                'paddle_subscription_id' => $paddleSubscriptionId,
                'event_type'             => Arr::get($webhookData, 'data.event_type'),
                'order_id'               => $order ? $order->id : null,
            ]);
            return false;
        }

        $result = $subscriptionModel->reSyncFromRemote();

        if (is_wp_error($result)) {
            self::$processingError = $result;
            return $result;
        }

        return true;
    }

    /**
     * Handle transaction payment failed webhook
     */
    public function handleTransactionPaymentFailed($webhookData)
    {
        $payload = Arr::get($webhookData, 'data');
        $paddleTransaction = Arr::get($payload, 'data');

        $customData = Arr::get($payload, 'data.custom_data', []);
        $transactionHash = Arr::get($customData, 'fct_transaction_hash');

        $paddleTransactionId = Arr::get($paddleTransaction, 'id');

        $transactionModel = OrderTransaction::query()->where('vendor_charge_id', $paddleTransactionId)->first();

        if (!$transactionModel && $transactionHash) {
            // Renewals inherit the checkout hash, so it can resolve to the root order's
            // transaction. Only the row created for this exact Paddle transaction qualifies.
            $candidate = OrderTransaction::query()->where('uuid', $transactionHash)->first();
            $expectedTransactionId = $candidate ? (string) Arr::get((array) ($candidate->meta ?? []), 'paddle_expected_transaction_id', '') : '';
            if ($candidate && $expectedTransactionId === (string) $paddleTransactionId) {
                $transactionModel = $candidate;
            }
        }

        if (!$transactionModel || ($transactionModel->vendor_charge_id && $transactionModel->vendor_charge_id != $paddleTransactionId) || !in_array($transactionModel->status, [Status::TRANSACTION_PENDING, Status::TRANSACTION_FAILED], true)) {
            return false;
        }

        $transactionModel->fill([
            'vendor_charge_id' => $paddleTransactionId,
            'status' => Status::TRANSACTION_FAILED
        ]);

        $transactionModel->save();

        return true;
    }

    public function handleSubscriptionActivated($webhookData)
    {
        $data = Arr::get($webhookData, 'data');
        $paddleSubscription = Arr::get($data, 'data');
        $order = Arr::get($webhookData, 'order');

        $customData = Arr::get($paddleSubscription, 'custom_data', []);
        $subscriptionHash = Arr::get($customData, 'fct_subscription_hash');

        $vendorSubscriptionId = Arr::get($paddleSubscription, 'id');
        $subscription = Subscription::query()->where('vendor_subscription_id', $vendorSubscriptionId)->first();

        if (!$subscription) {
            $subscription = Subscription::query()->where('uuid', $subscriptionHash)->first();
        }

        if (!$subscription) {
            return false;
        }

        $billCount = $subscription->calculateBillCount();
        $updateData = array_merge([
            'vendor_subscription_id' => Arr::get($paddleSubscription, 'id'),
            'current_payment_method' => 'paddle',
            'status' => PaddleHelper::transformSubscriptionStatus(Arr::get($paddleSubscription, 'status')),
            'bill_count' => $billCount,
            'vendor_response' => json_encode($paddleSubscription)
        ], array_filter(PaddleHelper::getSubscriptionVendorRefs($paddleSubscription)));

        $nextBillingDate = Arr::get($paddleSubscription, 'next_billed_at');
        if ($nextBillingDate) {
            $updateData['next_billing_date'] = SubscriptionHelper::safeTimestampToDatetime($nextBillingDate);
        } elseif (!$subscription->next_billing_date) {
            $updateData['next_billing_date'] = SubscriptionHelper::getNextBillingDate($subscription);
        }

        $oldStatus = $subscription->status;
        $oldVendorSubscriptionId = $subscription->vendor_subscription_id;
        $oldPaymentMethod = $subscription->current_payment_method;

        $subscription->update($updateData);

        if (in_array($subscription->status, [Status::SUBSCRIPTION_ACTIVE, Status::SUBSCRIPTION_TRIALING]) && !in_array($oldStatus, [Status::SUBSCRIPTION_ACTIVE, Status::SUBSCRIPTION_TRIALING]) && $subscription->bill_count === 0) {
            (new SubscriptionActivated($subscription, $order, $order->customer))->dispatch();
        }

        if ($oldVendorSubscriptionId && $oldVendorSubscriptionId !== $vendorSubscriptionId) {
            // we have a new vendor subscription ID or payment method, so let's cancel the old subscription
            $gateway = App::gateway($oldPaymentMethod);
            if ($gateway && $gateway->has('subscriptions')) {
                $result = $gateway->subscriptions->cancel($oldVendorSubscriptionId, [
                    'mode'           => $order->mode,
                    'effective_from' => 'immediately',
                ]);

                if (is_wp_error($result)) {
                    $order->addLog(
                        'OLD Subscription cancellation failed for renewal - ' . $oldPaymentMethod,
                        'Failed to cancel the old subscription with ID: ' . $oldVendorSubscriptionId,
                        'error'
                    );
                } else {
                    $order->addLog(
                        'Old Subscription cancelled on subscription reactivation - ' . $oldPaymentMethod,
                        'Old subscription with ID: ' . $oldVendorSubscriptionId . ' has been cancelled.',
                        'info'
                    );
                }
            }
        }
    }

    /**
     * Handle subscription updated webhook
     */
    public function handleSubscriptionUpdated($webhookData)
    {
        $payload = Arr::get($webhookData, 'data');
        $paddleSubscription = Arr::get($payload, 'data');

        $subscriptionId = Arr::get($paddleSubscription, 'id');
        $subscription = Subscription::query()->where('vendor_subscription_id', $subscriptionId)->first();

        if (!$subscription) {
            return false;
        }

        // End-of-period cancel arrives as subscription.updated with scheduled_change.action=cancel
        if (Arr::get($paddleSubscription, 'scheduled_change.action') === 'cancel') {
            return $this->handleSubscriptionCanceled($webhookData);
        }

        // Re-sync subscription from remote
        $subscription->reSyncFromRemote();

        return true;
    }

    public function handleSubscriptionCanceled($webhookData)
    {
        $payload = Arr::get($webhookData, 'data');
        $paddleSubscription = Arr::get($payload, 'data');

        $subscriptionId = Arr::get($paddleSubscription, 'id');
        $subscription = Subscription::query()->where('vendor_subscription_id', $subscriptionId)->first();

        if (!$subscription || $subscription->status === Status::SUBSCRIPTION_CANCELED || $subscription->status === Status::SUBSCRIPTION_EXPIRED || $subscription->status === Status::SUBSCRIPTION_COMPLETED) {
            return false;
        }

        // Parse canceled_at from webhook data
        $canceledAt = Arr::get($paddleSubscription, 'canceled_at');
        $scheduledChange = Arr::get($paddleSubscription, 'scheduled_change');

        // active + scheduled cancel = will expire at end of billing period
        if ($subscription->status === Status::SUBSCRIPTION_ACTIVE && Arr::get($scheduledChange, 'action') === 'cancel') {
            $effectiveAt = Arr::get($scheduledChange, 'effective_at');
            $canceledAt = $effectiveAt ? $effectiveAt : $canceledAt;
        }

        // Update subscription status
        $subscription->status = Status::SUBSCRIPTION_CANCELED;
        if ($canceledAt) {
            $subscription->canceled_at = SubscriptionHelper::safeTimestampToDatetime($canceledAt);
        } else {
            $subscription->canceled_at = gmdate('Y-m-d H:i:s');
        }
        $subscription->save();

        // Fire subscription_canceled event
        (new SubscriptionCanceled(
            $subscription,
            $subscription->order,
            $subscription->customer,
            'Canceled via Paddle webhook'
        ))->dispatch();

        return true;

    }

    /**
     * Validate that the Paddle entity's actual status is consistent with the claimed event_type.
     * Prevents a forged event (e.g. subscription.canceled) from acting on an entity in a
     * different state (e.g. an active subscription) when running in the signature-bypass path.
     * Events with no status requirement (subscription.updated, adjustment.*) always pass.
     */
    private function entityStateMatchesEvent(string $eventType, array $entityData): bool
    {
        $status = Arr::get($entityData, 'status', '');

        // Statuses sourced from Paddle Billing API docs (developer.paddle.com).
        $requiredStatuses = [
            'subscription.canceled'      => ['canceled'],
            'subscription.paused'        => ['paused'],
            // dunning can exhaust and flip to 'canceled' before this bypass GET lands.
            'subscription.past_due'      => ['past_due', 'canceled'],
            'subscription.activated'     => ['active'],
            'subscription.created'       => ['active', 'trialing'],
            'subscription.resumed'       => ['active'],
            // 'completed' is downstream of 'paid' — zero-value/no-invoice txns can advance
            // past 'paid' before this bypass GET lands, so both prove payment succeeded.
            'transaction.paid'           => ['paid', 'completed'],
            'transaction.completed'      => ['completed'],
            // (subscription renewal) txns are already 'billed', moving to 'past_due' only
            // after dunning exhausts — accept all three pre-terminal states.
            'transaction.payment_failed' => ['ready', 'billed', 'past_due'],
        ];

        if (!isset($requiredStatuses[$eventType])) {
            return true;
        }

        return in_array($status, $requiredStatuses[$eventType], true);
    }

    /**
     * Fallback: fetch the entity from Paddle API when HMAC signature fails.
     * Returns the entity data array from the API response, or null if not found/invalid.
     * Caller must replace payload['data'] with this to discard attacker-controlled fields.
     */
    private function fetchEntityFromApi(array $payload): ?array
    {
        $eventType = Arr::get($payload, 'event_type', '');
        $entityId  = Arr::get($payload, 'data.id', '');

        if (empty($eventType) || empty($entityId)) {
            return null;
        }

        // Paddle IDs are alphanumeric + underscore/hyphen only. Reject anything else to
        // prevent path traversal in the API URL (e.g. "txn_/../subscriptions/sub_xxx").
        if (!preg_match('/^[a-zA-Z0-9_-]+$/', $entityId)) {
            return null;
        }

        $prefix = explode('.', $eventType)[0] ?? '';
        $resourceMap = [
            'transaction'  => 'transactions',
            'subscription' => 'subscriptions',
            'adjustment'   => 'adjustments',
        ];

        $resource = $resourceMap[$prefix] ?? '';
        if (!$resource) {
            return null;
        }

        // Confirm entity ID prefix matches the resource type so event_type and data.id cannot
        // be mixed (e.g. transaction event with a sub_xxx ID).
        $idPrefixMap = [
            'transactions'  => 'txn_',
            'subscriptions' => 'sub_',
            'adjustments'   => 'adj_',
        ];
        $expectedPrefix = $idPrefixMap[$resource] ?? '';
        if ($expectedPrefix && !str_starts_with($entityId, $expectedPrefix)) {
            error_log('Paddle Webhook: fetchEntityFromApi ID/resource mismatch — expected ' . $expectedPrefix . ', got: ' . $entityId);
            return null;
        }

        $response = API::makeRequest($resource . '/' . $entityId, [], 'GET');

        if (is_wp_error($response)) {
            return null;
        }

        $entityData = Arr::get($response, 'data');

        if (!is_array($entityData) || Arr::get($entityData, 'id') !== $entityId) {
            return null;
        }

        return $entityData;
    }

    /**
     * Send HTTP response
     */
    private function sendResponse($code, $message)
    {
        http_response_code($code);
        echo $message;
        exit;
    }
}
