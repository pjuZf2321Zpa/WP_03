<?php

namespace FluentCartPro\App\Modules\PaymentMethods\PaddleGateway;


use FluentCart\App\Helpers\CartHelper;
use FluentCart\App\Modules\PaymentMethods\Core\GatewayManager;
use FluentCartPro\App\Modules\PaymentMethods\PaddleGateway\Webhook\IPN;
use FluentCartPro\App\Modules\PaymentMethods\PaddleGateway\API\API;
use FluentCart\Api\CurrencySettings;
use FluentCart\Api\StoreSettings;
use FluentCart\App\Helpers\CartCheckoutHelper;
use FluentCart\App\Helpers\Helper;
use FluentCart\App\Helpers\Status;
use FluentCart\App\Helpers\StatusHelper;
use FluentCart\App\Hooks\Cart\WebCheckoutHandler;
use FluentCart\App\Models\Order;
use FluentCart\App\Models\OrderTransaction;
use FluentCart\App\Models\Subscription;
use FluentCart\App\Modules\PaymentMethods\Core\AbstractPaymentGateway;
use FluentCart\App\Services\Payments\PaymentHelper;
use FluentCart\App\Services\Payments\PaymentInstance;
use FluentCartPro\App\Utils\Enqueuer\Vite;
use FluentCart\Framework\Support\Arr;


class Paddle extends AbstractPaymentGateway
{
    private $methodSlug = 'paddle';
    public array $supportedFeatures = [
        'payment',
        'refund',
        'webhook',
        'subscriptions',
        'custom_payment',
        'upgrade_plan',
        'resume_subscription',
        'manual_subscription',
        'first_cycle_discount',
        'multi_currency',
    ];

    public function __construct()
    {
        parent::__construct(
            new PaddleSettings(),
            new PaddleSubscriptions()
        );

        PaddleMoRHooks::register();

      add_filter('fluent_cart/payment_methods_with_custom_checkout_buttons', function ($methods) {
          $methods[] = 'paddle';
          return $methods;
      });
    }

    public function meta(): array
    {
        return [
            'title' => __('Paddle', 'fluent-cart-pro'),
            'route' => 'paddle',
            'slug' => 'paddle',
            'description' => __('Pay securely with Paddle - Complete payment solution', 'fluent-cart-pro'),
            'logo' => Vite::getAssetUrl("images/payment-methods/paddle-logo.svg"),
            'logo_light' => Vite::getAssetUrl("images/payment-methods/paddle-logo-light.svg"),
            'icon' => Vite::getAssetUrl("images/payment-methods/paddle-logo.svg"),
            'brand_color' => '#7c3aed',
            'status' => $this->settings->get('is_active') === 'yes',
            'supported_features' => $this->supportedFeatures,
        ];
    }

    public function canUpdateSubscriptionPaymentMethod(Subscription $subscription): bool
    {
        return !in_array($subscription->status, [Status::SUBSCRIPTION_CANCELED, Status::SUBSCRIPTION_EXPIRED, Status::SUBSCRIPTION_COMPLETED], true);
    }

    public function boot()
    {
        (new IPN())->init();
        (new Confirmations())->init();

        add_action('template_redirect', [$this, 'handleCheckoutRecovery']);
        add_action('wp_ajax_fluent_cart_paddle_update_payment_url', [$this, 'handleUpdatePaymentRedirect']);
        add_filter('fluent_cart/customer_portal/subscription_data', [$this, 'overrideCustomerPortalSubscriptionUrl'], 10, 2);

        add_filter('fluent_cart/order/view', [$this, 'maybeNormalizeCrossCurrencyOrder'], 10, 2);

        // Paddle is a Merchant of Record — only allow explicitly listed emails.
        // Admins can extend via the fluent_cart/paddle_allowed_email_notifications filter.
        add_filter('fluent_cart/should_send_email_notification', function ($should, $args) {
            $order = $args['order'];

            if ($order->payment_method !== 'paddle') {
                return $should;
            }

            $allowedEmails = apply_filters('fluent_cart/paddle_allowed_email_notifications', [
                'order_paid_customer',
                'order_paid_admin',
                'subscription_renewal_customer',
                'subscription_renewal_admin',
                'subscription_renewal_reminder_customer',
                'subscription_renewal_reminder_admin',
                'subscription_canceled_customer',
                'subscription_canceled_admin',
                'order_refunded_customer',
                'order_refunded_admin',
            ]);

            return in_array($args['mail_name'], $allowedEmails, true);
        }, 10, 2);
    }

    /**
     * Self-heal Paddle orders stuck pending because Paddle charged in the buyer's
     * currency: the foreign-currency transaction total sits below the order total,
     * so the order never reaches paid. Runs when an admin opens the order; the fix
     * is persisted and logged.
     */
    public function maybeNormalizeCrossCurrencyOrder($orderData, $context)
    {
        if (!is_array($orderData) || Arr::get($orderData, 'payment_method') !== $this->methodSlug) {
            return $orderData;
        }

        $order = Order::query()->where('id', Arr::get($orderData, 'id'))->first();

        if (!$order) {
            return $orderData;
        }

        $transaction = OrderTransaction::query()
            ->where('order_id', $order->id)
            ->where('transaction_type', Status::TRANSACTION_TYPE_CHARGE)
            ->whereIn('status', Status::getTransactionSuccessStatuses())
            ->orderBy('id', 'DESC')
            ->first();

        if (!$transaction) {
            return $orderData;
        }

        $reconcile = PaddleReconciler::reconcileFromTransaction($transaction, $order);

        if (!$reconcile['changed']) {
            return $orderData;
        }

        $transaction->total    = (int) $reconcile['amount'];
        $transaction->currency = $reconcile['currency'];
        $transaction->meta     = array_merge($transaction->meta ?? [], $reconcile['meta']);
        $transaction->save();

        $order = (new StatusHelper($order))->syncOrderStatuses($transaction);

        $orderData['total_amount']   = $order->total_amount;
        $orderData['total_paid']     = $order->total_paid;
        $orderData['status']         = $order->status;
        $orderData['payment_status'] = $order->payment_status;
        $orderData['business_info']  = $order->business_info;

        if (isset($orderData['transactions'])) {
            $orderData['transactions'] = OrderTransaction::query()
                ->where('order_id', $order->id)
                ->get()
                ->toArray();
        }

        return $orderData;
    }

    /*
     * Handle Paddle checkout recovery URLs (?_paction=recovery&_ptxn=txn_xxx)
     */
    public function handleCheckoutRecovery()
    {
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended
        $action = sanitize_text_field(wp_unslash($_GET['_paction'] ?? ''));
        if ($action !== 'recovery') {
            return;
        }

        // phpcs:ignore WordPress.Security.NonceVerification.Recommended
        $paddleTransactionId = sanitize_text_field(wp_unslash($_GET['_ptxn'] ?? ''));
        if (empty($paddleTransactionId)) {
            return;
        }

        $order = $this->resolveOrderFromPaddleTransaction($paddleTransactionId);
        if (!$order) {
            return;
        }

        if (!$this->canAccessRecoveryOrder($order)) {
            wp_redirect(home_url());
            exit;
        }

        // Re-fetch to avoid TOCTOU race with concurrent webhook payment processing
        $order = Order::query()->where('id', $order->id)->first();
        $totalDue = $order->total_amount - $order->total_paid;

        if ($totalDue > 0) {
            wp_redirect(PaymentHelper::getCustomPaymentLink($order->uuid));
            exit;
        }

        $transaction = OrderTransaction::query()
            ->where('order_id', $order->id)
            ->where('payment_method', 'paddle')
            ->orderBy('id', 'DESC')
            ->first();

        wp_redirect($transaction ? $transaction->getReceiptPageUrl() : home_url());
        exit;
    }

    private function canAccessRecoveryOrder($order): bool
    {
        if (!is_user_logged_in()) {
            return true; // Guest access allowed — recovery emails are the auth factor
        }

        $customer = $order->customer;
        if (!$customer || !$customer->user_id) {
            return true;
        }

        return $customer->user_id === get_current_user_id()
            || current_user_can('manage_options');
    }

    private function resolveOrderFromPaddleTransaction(string $paddleTransactionId)
    {
        $transaction = OrderTransaction::query()
            ->where('vendor_charge_id', $paddleTransactionId)
            ->where('payment_method', 'paddle')
            ->first();

        if ($transaction && $transaction->order) {
            return $transaction->order;
        }

        $paddleTransaction = API::getPaddleObject("transactions/{$paddleTransactionId}");
        if (is_wp_error($paddleTransaction)) {
            return null;
        }

        $orderHash = Arr::get($paddleTransaction, 'data.custom_data.fct_order_hash');

        return $orderHash ? Order::query()->where('uuid', $orderHash)->first() : null;
    }

    public function makePaymentFromPaymentInstance(PaymentInstance $paymentInstance)
    {
        $order = $paymentInstance->order;

        if ($paymentInstance->subscription) {
            $subscription = $paymentInstance->subscription;

            if ($this->shouldChargeSubscriptionAsOneTime($paymentInstance)) {
                return (new Processor())->handleSinglePayment($paymentInstance);
            }

            if ($subscription->collection_method === 'manual') {
                $previousPaymentMethod = $subscription->current_payment_method;
                $conversionResult = $this->convertManualSubscription($subscription);
                if (is_wp_error($conversionResult)) {
                    return $conversionResult;
                }
                $result = (new Processor())->handleSubscriptionPayment($paymentInstance);
                if (is_wp_error($result)) {
                    $subscription->update([
                        'collection_method'      => 'manual',
                        'current_payment_method' => $previousPaymentMethod,
                    ]);
                } else {
                    $subscription->addLog(
                        'Converted to automatic billing',
                        sprintf('Subscription converted from manual to automatic billing via %s', 'Paddle'),
                        'info'
                    );
                    do_action('fluent_cart/subscription_converted_to_automatic', [
                        'subscription'   => $subscription,
                        'payment_method' => 'paddle',
                    ]);
                }
                return $result;
            }

            return (new Processor())->handleSubscriptionPayment($paymentInstance);
        }

        return (new Processor())->handleSinglePayment($paymentInstance);
    }

    public function convertManualSubscription($subscription)
    {
        if (!$subscription || $subscription->collection_method !== 'manual') {
            return new \WP_Error('invalid_subscription', __('Subscription is not manual or does not exist', 'fluent-cart-pro'));
        }

        if (in_array($subscription->status, ['completed'])) {
            return new \WP_Error('subscription_invalid_status', __('Cannot convert completed subscriptions', 'fluent-cart-pro'));
        }

        $subscription->collection_method = 'automatic';
        $subscription->current_payment_method = 'paddle';
        $subscription->save();

        return true;
    }

    private function shouldRenderAsSubscriptionMode($hasSubscription): bool
    {
        return $hasSubscription;
    }

    public function processRefund($transaction, $amount, $args)
    {
        if (!$amount) {
            return new \WP_Error(
                'paddle_refund_error',
                __('Refund amount is required.', 'fluent-cart-pro')
            );
        }

        return PaddleHelper::processRemoteRefund($transaction, $amount, $args);
    }

    public function handleIPN(): void
    {
        (new IPN())->verifyAndProcess();
    }

    public static function validateSettings($data): array
    {

        $mode = Arr::get($data, 'payment_mode', 'live');
        $apiKey = Arr::get($data, $mode . '_api_key');

        if (empty($apiKey)) {
            return [
                'status' => 'failed',
                'message' => __('API key is required.', 'fluent-cart-pro')
            ];
        }

        return [
            'status' => 'success',
            'message' => __('Paddle gateway credentials verified successfully!', 'fluent-cart-pro')
        ];
    }

    public function testConnection(string $mode)
    {
        $apiKey = (string) $this->settings->getApiKey($mode);

        if (!$apiKey) {
            return new \WP_Error('missing_credentials', $mode === 'live'
                ? __('No live API key is saved.', 'fluent-cart-pro')
                : __('No sandbox API key is saved.', 'fluent-cart-pro'));
        }

        // Keys created before May 2025 carry no prefix; those are left to the API to reject.
        if ($mode === 'live' && strpos($apiKey, 'pdl_sdbx_') === 0) {
            return new \WP_Error('mode_mismatch', __('The live API key field holds a sandbox key. Paste a key that starts with pdl_live_.', 'fluent-cart-pro'));
        }

        if ($mode === 'test' && strpos($apiKey, 'pdl_live_') === 0) {
            return new \WP_Error('mode_mismatch', __('The sandbox API key field holds a live key. Paste a key that starts with pdl_sdbx_.', 'fluent-cart-pro'));
        }

        // Needs no API key permission: https://developer.paddle.com/api-reference/about
        $result = API::makeRequest('event-types', [], 'GET', $mode);

        if (is_wp_error($result)) {
            return $result;
        }

        if (!is_array(Arr::get($result, 'data'))) {
            return new \WP_Error('paddle_api_error', __('Paddle returned a response that could not be read.', 'fluent-cart-pro'));
        }

        return [
            'message' => $mode === 'live'
                ? __('Paddle accepted the live API key.', 'fluent-cart-pro')
                : __('Paddle accepted the sandbox API key.', 'fluent-cart-pro')
        ];
    }

    public function getOrderInfo(array $data)
    {
        $cart = CartHelper::getCart();
        $checkOutHelper = new CartCheckoutHelper(true);
        $shippingChargeData = (new WebCheckoutHandler())->getShippingChargeData($cart);
        $shippingCharge = Arr::get($shippingChargeData, 'charge');
        $totalPrice = $checkOutHelper->getItemsAmountTotal(false) + $shippingCharge;

        $items = $checkOutHelper->getItems();

        $hasSubscription = $this->validateSubscriptions($items);

        $subTotal = 0;
        foreach ($items as $item) {
            $subTotal += intval($item['quantity'] * $item['unit_price']);
        }

        $clientToken = $this->settings->getClientToken();

        // Make client token optional for now to avoid blocking checkout
        if (empty($clientToken)) {
            fluent_cart_add_log('Paddle Client Token', 'Client token is empty, proceeding without it', 'warning', ['log_type' => 'payment']);
        }

        $settings = $this->settings->get();

        $paymentArgs = [
            'client_token'  => $clientToken ?: '',
            'mode'          => $this->settings->getMode(),
            'paddle_checkout_button_text' => Arr::get($settings, 'paddle_checkout_button_text', ''),
            'paddle_checkout_button_color' => Arr::get($settings, 'paddle_checkout_button_color', ''),
            'paddle_checkout_button_hover_color' => Arr::get($settings, 'paddle_checkout_button_hover_color', ''),
            'paddle_checkout_button_text_color' => Arr::get($settings, 'paddle_checkout_button_text_color', ''),
            'paddle_checkout_button_font_size' => Arr::get($settings, 'paddle_checkout_button_font_size', '')
        ];


        $paymentDetails = [
            'mode'      => 'payment',
            'theme'      => Arr::get($settings, 'paddle_checkout_theme', 'light'),
            'amount'    => Helper::toDecimalWithoutComma($totalPrice),
            'currency'  => strtoupper(CurrencySettings::get('currency')),
            'locale'    => (new StoreSettings())->get('locale', 'en'),
        ];

        $renderAsSubscription = $this->shouldRenderAsSubscriptionMode($hasSubscription);

        if ($renderAsSubscription) {
            $paymentDetails['mode'] = 'subscription';
        }

        $this->checkCurrencySupport();

        wp_send_json([
            'status'           => 'success',
            'payment_args'     => $paymentArgs,
            'intent'           => $paymentDetails,
            'has_subscription' => $hasSubscription,
            'message'          => __('Order info retrieved!', 'fluent-cart-pro')
        ], 200);
    }

    public function getEventshtml()
    {
        // Build events list and render each as <code> for easy copy
        $events = $this->settings->getWebhookEventsToSubscribe();
        if (empty($events)) {
            $events = [
                'transaction.completed', 'transaction.paid', 'transaction.payment_failed',
                'adjustment.created', 'adjustment.updated',
                'subscription.created', 'subscription.activated', 'subscription.updated',
                'subscription.past_due', 'subscription.paused', 'subscription.resumed', 'subscription.canceled'
            ];
        }

        return implode(' ', array_map(function ($event) {
            return '<code class="copyable-content" data-copy="' . esc_attr($event) . '">' . esc_html($event) . '</code>';
        }, $events));
    }

    public function getWebhookInstructions(): array
    {
        $svg = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor"><path d="M10 6V8H5V19H16V14H18V20C18 20.5523 17.5523 21 17 21H4C3.44772 21 3 20.5523 3 20V7C3 6.44772 3.44772 6 4 6H10ZM21 3V11H19L18.9999 6.413L11.2071 14.2071L9.79289 12.7929L17.5849 5H13V3H21Z"></path></svg>';

        /* translators: %1$s: "Add webhook" link with icon */
        $step = fn($url) => \sprintf(
            '<p>%s</p>',
            \sprintf(
                esc_html__('Click %1$s and paste the webhook URL above', 'fluent-cart-pro'),
                \sprintf(
                    '<a href="%s" target="_blank" rel="noopener noreferrer">%s %s</a>',
                    esc_url($url),
                    esc_html__('Add webhook', 'fluent-cart-pro'),
                    $svg
                )
            )
        );

        return [
            'title'       => __('Webhook URL', 'fluent-cart-pro'),
            'webhook_url' => $this->getWebhookUrl(),
            'description' => __('You should configure your Paddle webhooks to get all updates of your payments remotely. You can do it by following the instructions below. Or provide valid API Key and save the settings and reload.', 'fluent-cart-pro'),
            'steps'       => [
                'title' => __('How to configure?', 'fluent-cart-pro'),
                'list'  => [
                    __('In your Paddle Dashboard, go to Developer Tools → Notifications', 'fluent-cart-pro'),
                    $step('https://developer.paddle.com/webhooks/overview'),
                ],
            ],
            'events'      => [
                'title' => __('Select these events', 'fluent-cart-pro'),
                'list'  => [
                    'transaction.completed',
                    'transaction.paid',
                    'transaction.payment_failed',
                    'adjustment.created',
                    'adjustment.updated',
                    'subscription.created',
                    'subscription.activated',
                    'subscription.updated',
                    'subscription.past_due',
                    'subscription.paused',
                    'subscription.resumed',
                    'subscription.canceled'
                ],
            ],
        ];
    }

    public function fields(): array
    {
        $webhookInstructions = $this->getWebhookInstructions();

        $testSchema = [
            'test_api_key' => array(
                'value' => '',
                'label' => __('Sandbox API Key', 'fluent-cart-pro'),
                'type' => 'password',
                'placeholder' => __('Your sandbox API key', 'fluent-cart-pro'),
                'help_text' => __('Get your API key from Paddle Dashboard > Developer Tools > Authentication', 'fluent-cart-pro')
            ),
            'test_client_token' => array(
                'value' => '',
                'label' => __('Sandbox Client Token / Public Key', 'fluent-cart-pro'),
                'type' => 'text',
                'placeholder' => __('Your sandbox client token', 'fluent-cart-pro'),
                'help_text' => __('Optional: Used for frontend checkout integration', 'fluent-cart-pro')
            ),
            'test_webhook_secret' => array(
                'value' => '',
                'label' => __('Sandbox Webhook Secret', 'fluent-cart-pro'),
                'type' => 'password',
                'placeholder' => __('Your sandbox webhook secret', 'fluent-cart-pro'),
                'help_text' => __('Used to verify webhook signatures', 'fluent-cart-pro')
            ),
            'test_webhook_desc' => array(
                'value' => $webhookInstructions,
                'label' => __('Webhook Configuration', 'fluent-cart-pro'),
                'type' => 'html_attr'
            ),
        ];

        $liveSchema = [
            'live_api_key' => array(
                'value' => '',
                'label' => __('Live API Key', 'fluent-cart-pro'),
                'type' => 'password',
                'placeholder' => __('Your live API key', 'fluent-cart-pro'),
                'help_text' => __('Get your API key from Paddle Dashboard > Developer Tools > Authentication', 'fluent-cart-pro')
            ),
            'live_client_token' => array(
                'value' => '',
                'label' => __('Live Client Token / Public Key', 'fluent-cart-pro'),
                'type' => 'text',
                'placeholder' => __('Your live client token', 'fluent-cart-pro'),
                'help_text' => __('Optional: Used for frontend checkout integration', 'fluent-cart-pro')
            ),
            'live_webhook_secret' => array(
                'value' => '',
                'label' => __('Live Webhook Secret', 'fluent-cart-pro'),
                'type' => 'password',
                'placeholder' => __('Your live webhook secret', 'fluent-cart-pro'),
                'help_text' => __('Used to verify webhook signatures', 'fluent-cart-pro')
            ),
            'live_webhook_desc' => array(
                'value' => $webhookInstructions,
                'label' => __('Webhook Configuration', 'fluent-cart-pro'),
                'type' => 'html_attr'
            ),
        ];

        if (!empty($this->settings->get('test_webhook_secret'))) {
            // Use the same sanitized, code-tag list of events
            $configuredHtml =
                '<div class="paddle-webhook-instructions" style="padding:12px 0;">'
                . '<p><strong>' . esc_html__('Webhook URL:', 'fluent-cart-pro') . '</strong> '
                . '<code class="copyable-content" data-copy="' . esc_attr($this->getWebhookUrl()) . '">' . esc_html($this->getWebhookUrl()) . '</code></p>'
                . '<p>' . esc_html__('Webhook is configured and listening to the following events:', 'fluent-cart-pro') . '</p>'
                . '<p style="display:flex;align-items:center;flex-wrap:wrap;gap:8px 4px;">' . wp_kses_post($this->getEventshtml()). '</p>'
                . '</div>';

            $testSchema['test_webhook_desc']['value'] = $configuredHtml;
        }

        if (!empty(Arr::get($this->settings->get(), 'live_webhook_secret'))) {
            $configuredHtml =
                '<div class="paddle-webhook-instructions" style="padding:12px 0;">'
                . '<p><strong>' . esc_html__('Webhook URL:', 'fluent-cart-pro') . '</strong> '
                . '<code class="copyable-content" data-copy="' . esc_attr($this->getWebhookUrl()) . '">' . esc_html($this->getWebhookUrl()) . '</code></p>'
                . '<p>' . esc_html__('Webhook is configured and listening to the following events:', 'fluent-cart-pro') . '</p>'
                . '<p style="display:flex;align-items:center;flex-wrap:wrap;gap:8px 4px;">' . wp_kses_post($this->getEventshtml()) . '</p>'
                . '</div>';

            $liveSchema['live_webhook_desc']['value'] = $configuredHtml;
        }

        $receiptPageNotice = '';
        $receiptPageUrl = (new StoreSettings())->getReceiptPage();
        if (!$receiptPageUrl || !filter_var($receiptPageUrl, FILTER_VALIDATE_URL)) {
            $receiptMessage = sprintf(
                /* translators: %1$s: URL to FluentCart pages settings */
                __('Receipt page is not configured or the page does not exist (it may be in draft or deleted). Paddle requires a valid receipt page to redirect customers after payment. <a href="%1$s">Configure it here</a>.', 'fluent-cart-pro'),
                esc_url(admin_url('admin.php?page=fluent-cart#/settings/store-settings/pages_setup'))
            );
            $receiptPageNotice = '<p class="text-red-500">'
                . '<svg class="w-4 h-4 inline-block mr-1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor"><path fill-rule="evenodd" d="M9.401 3.003c1.155-2 4.043-2 5.197 0l7.355 12.748c1.154 2-.29 4.5-2.599 4.5H4.645c-2.309 0-3.752-2.5-2.598-4.5L9.4 3.003zM12 8.25a.75.75 0 01.75.75v3.75a.75.75 0 01-1.5 0V9a.75.75 0 01.75-.75zm0 8.25a.75.75 0 100-1.5.75.75 0 000 1.5z" clip-rule="evenodd" /></svg>'
                . $receiptMessage
                . '</p>';
        }

        return array(
            'notice' => [
                'value' => $this->renderStoreModeNotice(),
                'label' => __('Store Mode notice', 'fluent-cart-pro'),
                'type' => 'notice'
            ],
            'receipt_page_notice' => [
                'value' => $receiptPageNotice,
                'label' => __('Receipt Page', 'fluent-cart-pro'),
                'type' => 'html_attr'
            ],
            'payment_mode' => [
                'type'   => 'tabs',
                'schema' => [
                    [
                        'type'   => 'tab',
                        'label'  => __('Live credentials', 'fluent-cart-pro'),
                        'value'  => 'live',
                        'schema' => $liveSchema
                    ],
                    [
                        'type'   => 'tab',
                        'label'  => __('Test credentials', 'fluent-cart-pro'),
                        'value'  => 'test',
                        'schema' => $testSchema
                    ]
                ]
            ],
            'tax_mode' => [
                'value' => 'external',
                'label' => __('Tax Mode', 'fluent-cart-pro'),
                'type' => 'select',
                'options' => [
                    'internal' => [
                        'label' => __('Internal', 'fluent-cart-pro'),
                        'value' => 'internal'
                    ],
                    'external' => [
                        'label' => __('External', 'fluent-cart-pro'),
                        'value' => 'external'
                    ],
                    'account_setting' => [
                        'label' => __('Use Paddle Account Settings', 'fluent-cart-pro'),
                        'value' => 'account_setting'
                    ]
                ],
                'tooltip' => __('Tax mode to use for Paddle transactions', 'fluent-cart-pro')
            ],
            'tax_mode_notice' => [
                'value' => '<div class="paddle-tax-mode-notice" style="padding:10px 12px;border-left:3px solid #e6a23c;background:#fdf6ec;color:#7a5b1e;border-radius:4px;">'
                    . '<p style="margin:0 0 6px;"><strong>' . esc_html__('Important: this setting decides how Paddle taxes your prices.', 'fluent-cart-pro') . '</strong></p>'
                    . '<p style="margin:0;">'
                    . esc_html__('Paddle is a Merchant of Record and does NOT use FluentCart\'s tax module or its "tax included / excluded in price" setting. Only this Tax Mode applies:', 'fluent-cart-pro')
                    . '</p>'
                    . '<ul style="margin:6px 0 0;padding-left:18px;">'
                    . '<li>' . esc_html__('External — tax is added on top of your price (customer pays price + VAT). Use this if your prices exclude tax.', 'fluent-cart-pro') . '</li>'
                    . '<li>' . esc_html__('Internal — your price already includes tax; Paddle deducts VAT from it, so you receive less than the listed price.', 'fluent-cart-pro') . '</li>'
                    . '<li>' . esc_html__('Use Paddle Account Settings — follows your Paddle dashboard default, which is tax-inclusive on new Paddle accounts.', 'fluent-cart-pro') . '</li>'
                    . '</ul>'
                    . '</div>',
                'label' => '',
                'type' => 'html_attr'
            ],
            'paddle_checkout_theme' => [
                'value' => 'light',
                'label' => __('Paddle Checkout Theme', 'fluent-cart-pro'),
                'type' => 'select',
                'options' => [
                    'light' => [
                        'label' => __('Light', 'fluent-cart-pro'),
                        'value' => 'light'
                    ],
                    'dark' => [
                        'label' => __('Dark', 'fluent-cart-pro'),
                        'value' => 'dark'
                    ]
                ],
                'tooltip' => __('Theme to use for Paddle checkout modal', 'fluent-cart-pro')
            ],
            'paddle_checkout_button_text' => [
                'value' => __('Pay with Paddle', 'fluent-cart-pro'),
                'label' => __('Paddle Checkout Button Text', 'fluent-cart-pro'),
                'type' => 'text',
                'placeholder' => __('Pay with Paddle', 'fluent-cart-pro'),
                'tooltip' => __('Text to display on the Paddle checkout button', 'fluent-cart-pro')
            ],
            'paddle_checkout_button_color' => [
                'value' => '',
                'label' => __('Paddle Checkout Button Color', 'fluent-cart-pro'),
                'type' => 'color',
                'tooltip' => __('Color of the Paddle checkout button', 'fluent-cart-pro')
            ],
            'paddle_checkout_button_hover_color' => [
                'value' => '',
                'label' => __('Paddle Checkout Button Hover Color', 'fluent-cart-pro'),
                'type' => 'color',
                'tooltip' => __('Hover color of the Paddle checkout button', 'fluent-cart-pro')
            ],
            'paddle_checkout_button_text_color' => [
                'value' => '',
                'label' => __('Paddle Checkout Button Text Color', 'fluent-cart-pro'),
                'type' => 'color',
                'tooltip' => __('Text color of the Paddle checkout button', 'fluent-cart-pro')
            ],
            'paddle_checkout_button_font_size' => [
                'value' => '16px',
                'label' => __('Paddle Checkout Button Font Size', 'fluent-cart-pro'),
                'type' => 'text',
                'tooltip' => __('Font size of the Paddle checkout button', 'fluent-cart-pro')
            ],
            'disable_webhook_verification' => [
                'value' => 'no',
                'label' => __('Disable Webhook Verification (Test purpose only)', 'fluent-cart-pro'),
                'type' => 'checkbox',
                'tooltip' => __('Only disable this for testing purposes. Keep enabled for production.', 'fluent-cart-pro')
            ]
        );
    }

    public static function beforeSettingsUpdate($data, $oldSettings): array
    {
        $mode = Arr::get($data, 'payment_mode', 'live');
        $apiKeyField = $mode . '_api_key';
       
        $data[$apiKeyField] = Helper::encryptKey($data[$apiKeyField]);
       

        // subscribe to webhook events working but not sure , we'll decide later
//        $events = (new PaddleSettings())->getWebhookEventsToSubscribe();
//        $notificationId = Arr::get($data, $mode . '_notification_id');
//        if ($notificationId && !empty($data[$apiKeyField])) {
//            $response = API::getPaddleObject('notification-settings/' . $notificationId);
//
//            if (!is_wp_error($response)) {
//                $alreadySubscribedEvents = Arr::get($response, 'data.subscribed_events');
//                $alreadySubscribedEvents = array_map(function ($event) {
//                    return $event['name'];
//                }, $alreadySubscribedEvents);
//
//                $missingEvents = array_diff($events, $alreadySubscribedEvents);
//                if (!empty($missingEvents)) {
//                    $alreadySubscribedEvents = array_merge($alreadySubscribedEvents, $missingEvents);
//                    API::updatePaddleObject('notification-settings/' . $notificationId, [
//                        'subscribed_events' => $alreadySubscribedEvents
//                    ]);
//                }
//            }
//
//        } else if (!$notificationId && !empty($data[$apiKeyField])) {
//            $response = API::createPaddleObject('notification-settings',
//                [
//                    'description' => __('FluentCart Test Paddle Webhook', 'fluent-cart-pro'),
//                    'type' => 'url',
//                    'destination' => (new Paddle())->getWebhookUrl(),
//                    'api_version' => 1,
//                    'traffic_source' => 'all',
//                    'subscribed_events' => $events
//                ]);
//
//            if (!is_wp_error($response)) {
//                $data[$mode . '_notification_id'] = Arr::get($response, 'data.id');
//                $data[$mode . '_webhook_secret'] = Arr::get($response, 'data.endpoint_secret_key');
//            }
//        }

        return $data;
    }

    public function getEnqueueScriptSrc($hasSubscription = 'no'): array
    {
        $paddleJsUrl = 'https://cdn.paddle.com/paddle/v2/paddle.js';

        return [
            [
                'handle' => 'fluent-cart-checkout-sdk-paddle-js',
                'src' => $paddleJsUrl,
            ],
            [
                'handle' => 'fluent-cart-paddle-checkout',
                'src' => Vite::getEnqueuePath('public/payment-methods/paddle-checkout.js'),
                'deps' => ['fluent-cart-checkout-sdk-paddle-js']
            ]
        ];
    }

    public function getEnqueueVersion()
    {
       return FLUENTCART_PRO_PLUGIN_VERSION;
    }


    public function getLocalizeData(): array
    {
        return [
            'fct_paddle_data' => [
                'translations' => [
                    'Paddle SDK is not loaded. Please ensure the Paddle script is included.' => __('Paddle SDK is not loaded. Please ensure the Paddle script is included.', 'fluent-cart-pro'),
                    'Paddle client token is missing or invalid.' => __('Paddle client token is missing or invalid.', 'fluent-cart-pro'),
                    'Pay with Paddle' => __('Pay with Paddle', 'fluent-cart-pro'),
                    'Secure payment powered by Paddle' => __('Secure payment powered by Paddle', 'fluent-cart-pro'),
                    'Order creation failed' => __('Order creation failed', 'fluent-cart-pro'),
                    'Failed to create order' => __('Failed to create order', 'fluent-cart-pro'),
                    'Order handler not available' => __('Order handler not available', 'fluent-cart-pro'),
                    'Order handler is not properly configured' => __('Order handler is not properly configured', 'fluent-cart-pro'),
                    'No Paddle price IDs found in order data. Please ensure Paddle products are properly configured.' => __('No Paddle price IDs found in order data. Please ensure Paddle products are properly configured.', 'fluent-cart-pro'),
                    'Failed to prepare valid Paddle items from order data.' => __('Failed to prepare valid Paddle items from order data.', 'fluent-cart-pro'),
                    'Error: Missing transaction ID' => __('Error: Missing transaction ID', 'fluent-cart-pro'),
                    'Confirmation failed' => __('Confirmation failed', 'fluent-cart-pro'),
                    'Network error' => __('Network error', 'fluent-cart-pro'),
                    'Error: %1$s' => __('Error: %1$s', 'fluent-cart-pro'),
                    'Payment failed' => __('Payment failed', 'fluent-cart-pro'),
                    'Error occurred' => __('Error occurred', 'fluent-cart-pro'),
                    'An error occurred. Please try again.' => __('An error occurred. Please try again.', 'fluent-cart-pro'),
                    'An error occurred while loading Paddle.' => __('An error occurred while loading Paddle.', 'fluent-cart-pro'),
                    'Payment received but confirmation failed. Please check your email for order details.' => __('Payment received but confirmation failed. Please check your email for order details.', 'fluent-cart-pro'),
                ]
            ]
        ];
    }

    public function getEnqueueStyleSrc(): array
    {
        return [
            [
                'handle' => 'fluent-cart-paddle-styles',
                'src' => '',
            ]
        ];
    }


    private function verifyWebhookSignature($payload)
    {
        $signature = $_SERVER['HTTP_PADDLE_SIGNATURE'] ?? '';
        $publicKey = $this->settings->getPublicKey();
        
        if (!$signature || !$publicKey) {
            return false;
        }

        // Paddle signature verification logic would go here
        // This is a simplified version - actual implementation would use Paddle's verification method
        return true;
    }

    private function getWebhookUrl()
    {
        return site_url('?fluent-cart=fct_payment_listener_ipn&method=paddle');
    }

    public function getTransactionUrl($url, $data)
    {
        if (Arr::get($data, 'transaction_type') === 'refund') { // refund url is not separate in paddle
            $parentTransaction = OrderTransaction::query()->where('id', Arr::get($data, 'transaction.meta.parent_id'))->first();
            $data['vendor_charge_id'] = $parentTransaction->vendor_charge_id;
        }

        if (Arr::get($data, 'payment_mode') === 'test') {
            return 'https://sandbox-vendors.paddle.com/transactions-v2/' . Arr::get($data, 'vendor_charge_id');
        }

        return 'https://vendors.paddle.com/transactions-v2/' . Arr::get($data, 'vendor_charge_id');
    }

    public function getSubscriptionUrl($url, $data)
    {
        if (Arr::get($data, 'payment_mode') === 'test') {
            return 'https://sandbox-vendors.paddle.com/subscriptions-v2/' . Arr::get($data, 'vendor_subscription_id');
        }

        return 'https://vendors.paddle.com/subscriptions-v2/' . Arr::get($data, 'vendor_subscription_id');
    }

    public function overrideCustomerPortalSubscriptionUrl($formattedData, $context)
    {
        $subscription = Arr::get($context, 'subscription');
        if (!$subscription || $subscription->current_payment_method !== 'paddle') {
            return $formattedData;
        }

        $formattedData['card_update_url'] = add_query_arg([
            'action' => 'fluent_cart_paddle_update_payment_url',
            'sub'    => $subscription->uuid,
            'nonce'  => wp_create_nonce('fc_paddle_update_payment_' . $subscription->uuid),
        ], admin_url('admin-ajax.php'));

        return $formattedData;
    }

    public function handleUpdatePaymentRedirect()
    {
        $uuid  = sanitize_text_field(isset($_GET['sub']) ? $_GET['sub'] : '');
        $nonce = sanitize_text_field(isset($_GET['nonce']) ? $_GET['nonce'] : '');

        if (!$uuid || !wp_verify_nonce($nonce, 'fc_paddle_update_payment_' . $uuid)) {
            $this->abortUpdate(__('Invalid request.', 'fluent-cart-pro'), 403);
        }

        if (!is_user_logged_in()) {
            $this->abortUpdate(__('You must be logged in to update your payment method.', 'fluent-cart-pro'), 403);
        }

        $subscription = Subscription::query()->where('uuid', $uuid)->first();
        if (!$subscription) {
            $this->abortUpdate(__('Subscription not found.', 'fluent-cart-pro'), 404);
        }

        $order    = $subscription->order;
        $customer = $order ? $order->customer : null;

        if (!$customer || (int) $customer->user_id !== get_current_user_id()) {
            $this->abortUpdate(__('You do not have permission to update this subscription.', 'fluent-cart-pro'), 403);
        }

        $paddleCustomerId = $subscription->vendor_customer_id;

        if (!$paddleCustomerId) {
            $this->abortUpdate(__('Paddle customer record not found. Please contact support.', 'fluent-cart-pro'), 404);
        }

        $mode = $order ? $order->mode : $this->settings->getMode();

        $response = API::makeRequest(
            'customers/' . $paddleCustomerId . '/portal-sessions',
            ['subscription_ids' => [$subscription->vendor_subscription_id]],
            'POST',
            $mode
        );

        if (is_wp_error($response)) {
            $this->abortUpdate($response->get_error_message(), 502);
        }

        $subscriptionUrls = Arr::get($response, 'data.urls.subscriptions', []);
        $updateUrl = Arr::get($subscriptionUrls, '0.update_payment_method')
            ?: Arr::get($response, 'data.urls.general.overview');

        if (!$updateUrl) {
            $this->abortUpdate(__('Unable to generate the payment update link. Please contact support.', 'fluent-cart-pro'), 502);
        }

        wp_redirect($updateUrl);
        exit;
    }

    private function abortUpdate($message, $status = 400)
    {
        wp_die(
            esc_html($message),
            esc_html__('Payment Update', 'fluent-cart-pro'),
            ['response' => $status, 'back_link' => true]
        );
    }


    public function getSuccessUrl($transaction, $args = [])
    {
        $paymentHelper = new PaymentHelper($this->getMeta('route'));
        return $paymentHelper->successUrl($transaction->uuid, $args);
    }

    public function isCurrencySupported(): bool
    {
        $supportedCurrencies = [
            'USD', 'EUR', 'GBP', 'JPY', 'AUD', 'CAD', 'CHF', 'HKD', 'SGD', 'SEK',
            'ARS', 'BRL', 'CNY', 'COP', 'CZK', 'DKK', 'HUF', 'ILS', 'INR', 'KRW',
            'MXN', 'NOK', 'NZD', 'PLN', 'RUB', 'THB', 'TRY', 'TWD', 'UAH', 'VND', 'ZAR',
            'CLP', 'PEN'
        ];

        return in_array(strtoupper(CurrencySettings::get('currency')), $supportedCurrencies);
    }

    private function checkCurrencySupport()
    {
        if (!$this->isCurrencySupported()) {
            $currentCurrency = CurrencySettings::get('currency');
            wp_send_json([
                'status' => 'failed',
                'message' => sprintf(
                    /* translators: %1$s: store currency code */
                    __('Currency %1$s is not supported by Paddle. Please check supported currencies.', 'fluent-cart-pro'),
                    $currentCurrency
                )
            ], 422);
        }
    }

    public static function register(){
        fluent_cart_api()->registerCustomPaymentMethod('paddle', new self());
    }

}
