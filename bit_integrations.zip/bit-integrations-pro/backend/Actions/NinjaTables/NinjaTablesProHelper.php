<?php

namespace BitApps\IntegrationsPro\Actions\NinjaTables;

use Exception;

class NinjaTablesProHelper
{
    public const TABLE_NAME = 'ninja_table_items';

    private static $tableName;

    public static function addRowInTable($defaultResponse, $rowData)
    {
        if (!self::isPluginActive()) {
            return self::errorResponse(__('Ninja Tables is not installed or activated', 'bit-integrations-pro'));
        }

        $validationResult = self::validateAddRowData($rowData);
        if ($validationResult !== true) {
            return self::errorResponse($validationResult);
        }

        try {
            $tableId = absint($rowData['table_id']);
            $ownerId = absint($rowData['owner_id']);
            $rowFields = $rowData['row_fields'];

            $newRowId = self::insertRow(self::prepareInsertData($tableId, $ownerId, $rowFields));
            $insertedRow = self::getEnrichedRowById($newRowId);

            do_action('ninja_table_after_add_item', $newRowId, $tableId, $rowFields);

            return self::successResponse(__('Row added successfully', 'bit-integrations-pro'), ['row' => $insertedRow]);
        } catch (Exception $e) {
            return self::errorResponse($e->getMessage());
        }
    }

    public static function updateRowInTable($defaultResponse, $rowData)
    {
        if (!self::isPluginActive()) {
            return self::errorResponse(__('Ninja Tables is not installed or activated', 'bit-integrations-pro'));
        }

        $validationResult = self::validateUpdateRowData($rowData);
        if ($validationResult !== true) {
            return self::errorResponse($validationResult);
        }

        try {
            $tableId = absint($rowData['table_id']);
            $rowId = absint($rowData['row_id']);
            $ownerId = isset($rowData['owner_id']) ? absint($rowData['owner_id']) : 0;
            $rowFields = $rowData['row_fields'];

            $currentRow = self::fetchRowById($rowId);
            $mergedRowData = self::mergeRowData($currentRow, $rowFields);

            self::updateRow($rowId, self::prepareUpdateData($tableId, $ownerId, $mergedRowData));
            $modifiedRow = self::getEnrichedRowById($rowId);

            do_action('ninja_table_after_update_item', $rowId, $tableId, $rowFields);

            return self::successResponse(__('Row updated successfully', 'bit-integrations-pro'), ['row' => $modifiedRow]);
        } catch (Exception $e) {
            return self::errorResponse($e->getMessage());
        }
    }

    private static function validateAddRowData($rowData)
    {
        $tableId = isset($rowData['table_id']) ? absint($rowData['table_id']) : 0;
        $ownerId = isset($rowData['owner_id']) ? absint($rowData['owner_id']) : 0;
        $rowFields = isset($rowData['row_fields']) && \is_array($rowData['row_fields']) ? $rowData['row_fields'] : [];

        if (empty($tableId)) {
            return __('Table ID is required', 'bit-integrations-pro');
        }

        if (empty($ownerId)) {
            return __('Owner ID is required', 'bit-integrations-pro');
        }

        if (empty($rowFields)) {
            return __('Row fields are required', 'bit-integrations-pro');
        }

        if (!get_userdata($ownerId)) {
            return __('Specified user does not exist', 'bit-integrations-pro');
        }

        return true;
    }

    private static function validateUpdateRowData($rowData)
    {
        $tableId = isset($rowData['table_id']) ? absint($rowData['table_id']) : 0;
        $rowId = isset($rowData['row_id']) ? absint($rowData['row_id']) : 0;
        $ownerId = isset($rowData['owner_id']) ? absint($rowData['owner_id']) : 0;
        $rowFields = isset($rowData['row_fields']) && \is_array($rowData['row_fields']) ? $rowData['row_fields'] : [];

        if (empty($tableId)) {
            return __('Table ID is required', 'bit-integrations-pro');
        }

        if (empty($rowId)) {
            return __('Row ID is required', 'bit-integrations-pro');
        }

        if (empty($rowFields)) {
            return __('Row fields are required', 'bit-integrations-pro');
        }

        if (!self::fetchRowById($rowId)) {
            return __('Specified row does not exist', 'bit-integrations-pro');
        }

        if (!empty($ownerId) && !get_userdata($ownerId)) {
            return __('Specified user does not exist', 'bit-integrations-pro');
        }

        return true;
    }

    // ===== Data Preparation Methods =====
    private static function prepareInsertData($tableId, $ownerId, $rowFields)
    {
        return [
            'table_id'   => $tableId,
            'owner_id'   => $ownerId,
            'attribute'  => 'value',
            'value'      => wp_json_encode($rowFields),
            'created_at' => current_time('mysql', true),
            'updated_at' => current_time('mysql', true),
        ];
    }

    private static function prepareUpdateData($tableId, $ownerId, $mergedRowData)
    {
        $updateData = [
            'table_id'   => $tableId,
            'attribute'  => 'value',
            'value'      => wp_json_encode($mergedRowData),
            'updated_at' => current_time('mysql', true),
        ];

        if ($ownerId) {
            $updateData['owner_id'] = $ownerId;
        }

        return $updateData;
    }

    // ===== Database Operation Methods =====
    private static function getTableName()
    {
        if (self::$tableName === null) {
            global $wpdb;
            self::$tableName = $wpdb->prefix . self::TABLE_NAME;
        }

        return self::$tableName;
    }

    /**
     * Insert a new row into the database
     *
     * @param mixed $insertData
     */
    private static function insertRow($insertData)
    {
        global $wpdb;
        $tableName = self::getTableName();

        $inserted = $wpdb->insert($tableName, $insertData);

        if ($inserted === false) {
            throw new Exception(__('Database insertion failed. Unable to add row to table.', 'bit-integrations-pro'));
        }

        return $wpdb->insert_id;
    }

    private static function updateRow($rowId, $updateData)
    {
        global $wpdb;
        $tableName = self::getTableName();

        $updated = $wpdb->update(
            $tableName,
            $updateData,
            ['id' => $rowId],
            null,
            ['%d']
        );

        if ($updated === false) {
            throw new Exception(__('Database update failed. Unable to modify row in table.', 'bit-integrations-pro'));
        }

        return true;
    }

    private static function fetchRowById($rowId)
    {
        global $wpdb;
        $tableName = self::getTableName();

        $query = "SELECT * FROM {$tableName} WHERE id = %d LIMIT 1";

        return $wpdb->get_row($wpdb->prepare($query, $rowId), ARRAY_A);
    }

    // ===== Data Processing Methods =====
    /**
     * Enrich row data with decoded JSON and owner information
     *
     * @param mixed $row
     */
    private static function enrichRowData($row)
    {
        if (empty($row)) {
            return $row;
        }

        if (!empty($row['value'])) {
            $row['value'] = json_decode($row['value'], true);
        }

        if (!empty($row['owner_id']) && ($userData = get_userdata($row['owner_id']))) {
            $row['owner'] = [
                'ID'         => $userData->ID,
                'user_login' => $userData->user_login,
                'user_email' => $userData->user_email,
                'first_name' => get_user_meta($userData->ID, 'first_name', true),
                'last_name'  => get_user_meta($userData->ID, 'last_name', true),
            ];
        }

        return $row;
    }

    private static function mergeRowData($currentRow, $updatedFields)
    {
        if (empty($currentRow['value']) || $currentRow['value'] === 'null') {
            return $updatedFields;
        }

        $currentRowData = json_decode($currentRow['value'], true);

        return array_replace(\is_array($currentRowData) ? $currentRowData : [], $updatedFields);
    }

    private static function getEnrichedRowById($rowId)
    {
        $row = self::fetchRowById($rowId);

        return $row ? self::enrichRowData($row) : null;
    }

    private static function isPluginActive()
    {
        return \defined('NINJA_TABLES_VERSION');
    }

    private static function successResponse($message, $data = [])
    {
        return [
            'success' => true,
            'message' => $message,
            'data'    => $data
        ];
    }

    private static function errorResponse($message)
    {
        return [
            'success' => false,
            'message' => $message
        ];
    }
}
