<?php

namespace WPAICG\Lib\ContentWriter;

use WPAICG\Chat\Storage\LogStorage;
use WPAICG\Lib\Chat\Triggers\AIPKit_Trigger_Storage;
use WPAICG\Lib\Chat\Triggers\AIPKit_Trigger_Manager;
use WP_Error;

if (!defined('ABSPATH')) {
    exit;
}

/** Dispatches paid validation events for a Content Writer stream request. */
final class StreamTriggers
{
    private $enabled;
    private $log_storage;
    private $context;

    public function __construct(LogStorage $log_storage, $user_id, $provider, $model)
    {
        // Capture access at request preparation, before logging or retrieval runs.
        $this->enabled = class_exists('\\WPAICG\\aipkit_dashboard') && \WPAICG\aipkit_dashboard::is_pro_plan();
        $this->log_storage = $log_storage;
        $this->context = [
            'bot_id' => null, 'user_id' => $user_id, 'session_id' => null,
            'module' => 'content_writer', 'operation' => '',
            'failed_provider' => $provider, 'failed_model' => $model,
        ];
    }

    public function error(WP_Error $error, string $operation): void
    {
        if (!$this->enabled || !class_exists(AIPKit_Trigger_Manager::class) || !class_exists(AIPKit_Trigger_Storage::class)) {
            return;
        }

        $context = [
            'error_code' => $error->get_error_code(),
            'error_message' => $error->get_error_message(),
        ] + $this->context;
        $context['operation'] = $operation;
        $storage = new AIPKit_Trigger_Storage();
        $manager = new AIPKit_Trigger_Manager($storage, $this->log_storage);
        $manager->process_event(0, 'system_error_occurred', $context);
    }
}
