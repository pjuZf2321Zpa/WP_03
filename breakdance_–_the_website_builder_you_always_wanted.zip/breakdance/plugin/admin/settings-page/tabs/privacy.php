<?php

namespace Breakdance\Admin\SettingsPage\PrivacyTab;

use function Breakdance\BreakdanceOxygen\Strings\__bdox;
use function Breakdance\Settings\get_bool_setting;
use function Breakdance\Settings\save_tab_from_post;
use function Breakdance\Telemetry\is_exempt_as_pro;
use function Breakdance\Telemetry\is_opted_out;
use function Breakdance\Util\is_post_request;

add_action('breakdance_register_admin_settings_page_register_tabs', '\Breakdance\Admin\SettingsPage\PrivacyTab\register');

function register()
{
    \Breakdance\Admin\SettingsPage\addTab(esc_html__('Privacy', 'breakdance'), 'privacy', '\Breakdance\Admin\SettingsPage\PrivacyTab\tab', 1200);
}

function tab()
{
    $nonce_action = 'breakdance_admin_privacy_tab';
    if (is_post_request() && check_admin_referer($nonce_action)) {
        // Every field is named after the option it saves; see save_tab_from_post().
        save_tab_from_post('privacy');
    }

    $disable_page_and_session_tracking_cookies = get_bool_setting('breakdance_settings_disable_view_tracking_cookies');

    $is_pro = is_exempt_as_pro();

    $telemetry_opt_out = is_opted_out();

    $hide_partner_discounts = get_bool_setting('settings_hide_partner_discounts');

    $builder_integration = get_bool_setting('settings_hide_builder_integration');

    $plugin_name = __bdox('plugin_name');
?>

    <h2><?php esc_html_e('Privacy', 'breakdance'); ?></h2>

    <form action="" method="post">
        <?php wp_nonce_field($nonce_action); ?>
        <table class="form-table" role="presentation">
            <tbody>
                <?php if (!bdox_run_filters('breakdance_disable_track_view_and_session_counts', false)) { ?>
                <tr>
                    <th scope="row">
                        <?php esc_html_e('Disable Page & Session Cookies', 'breakdance'); ?>
                    </th>
                    <td>
                        <fieldset>
                            <label for="disable_page_and_session_tracking_cookies">
                                <input type="checkbox" <?php echo $disable_page_and_session_tracking_cookies ? 'checked' : ''; ?> name="breakdance_settings_disable_view_tracking_cookies" value="yes" id="disable_page_and_session_tracking_cookies"> <?php esc_html_e('Disable', 'breakdance'); ?>
                            </label>
                        </fieldset>
                        <p class="description">
                            <?php
                                /* translators: 1: Plugin name, 2: Condition name in <code> tags, 3: Another condition name in <code> tags */
                                printf(esc_html__('%1$s provides conditions to show or hide certain content based on page view and session count. Enabling this option will prevent %1$s from setting the tracking cookies necessary for this functionality. The %2$s and %3$s conditions will not work.', 'breakdance'), $plugin_name, '<code>' . esc_html__('Page View Count', 'breakdance') . '</code>', '<code>' . esc_html__('Session Count', 'breakdance') . '</code>');
                            ?>
                        </p>
                    </td>
                </tr>
                <?php } ?>
                <?php if (BREAKDANCE_MODE === 'breakdance') { ?>
                <tr>
                    <th scope="row">
                        <?php esc_html_e('Usage Tracking', 'breakdance'); ?>
                    </th>
                    <td>
                        <fieldset>
                            <label for="telemetry_opt_out">
                                <input type="checkbox" <?php echo ($is_pro || $telemetry_opt_out) ? 'checked' : ''; ?> <?php echo $is_pro ? 'disabled' : ''; ?> name="telemetry_opt_out" value="yes" id="telemetry_opt_out"> <?php esc_html_e('Opt out of usage tracking', 'breakdance'); ?>
                            </label>
                            <a href="https://breakdance.com/documentation/settings/privacy/" target="_blank"><?php esc_html_e('Learn more', 'breakdance'); ?></a>
                            <?php if ($is_pro) { ?>
                                <?php // Disabled checkboxes aren't submitted; keep the stored choice for if the site goes back to Free. ?>
                                <input type="hidden" name="telemetry_opt_out" value="<?php echo $telemetry_opt_out ? 'yes' : ''; ?>">
                            <?php } ?>
                        </fieldset>
                        <p class="description"><?php esc_html_e('Breakdance doesn\'t collect usage data once a Pro license key is entered.', 'breakdance'); ?></p>
                    </td>
                </tr>
                <?php } ?>
                <tr>
                    <th scope="row">
                        <?php esc_html_e('Partner Discounts', 'breakdance'); ?>
                    </th>
                    <td>
                        <fieldset>
                            <label for="hide_partner_discounts_page">
                                <input type="checkbox" <?php echo $hide_partner_discounts ? 'checked' : ''; ?> name="settings_hide_partner_discounts" value="yes" id="hide_partner_discounts_page"> <?php esc_html_e('Hide the Partner Discounts page from the admin menu', 'breakdance'); ?>
                            </label>
                        </fieldset>
                    </td>
                </tr>

                <tr>
                    <th scope="row"><?php esc_html_e('Builder Integration', 'breakdance'); ?></th>
                    <td>
                        <fieldset>
                            <label for="builder_integration">
                                <input type="checkbox" id="builder_integration" name="settings_hide_builder_integration" value="true" <?= $builder_integration ? 'checked' : '' ?> />
                                <?php esc_html_e('Hide integrations in the builder (Breakdance AI Writing Assistant and WPCodeBox)', 'breakdance'); ?>
                            </label>
                        </fieldset>
                    </td>
                </tr>
            </tbody>
        </table>

        <p class="submit">
            <input type="submit" name="submit" id="submit" class="button button-primary" value="<?php esc_attr_e('Save Changes', 'breakdance'); ?>">
        </p>

    </form>
<?php
}
?>
