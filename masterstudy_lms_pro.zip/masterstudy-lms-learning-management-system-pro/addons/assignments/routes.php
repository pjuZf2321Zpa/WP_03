<?php

/** @var \MasterStudy\Lms\Routing\Router $router */

use MasterStudy\Lms\Routing\Router;

$router->post(
	'/assignments',
	\MasterStudy\Lms\Pro\addons\assignments\Http\Controllers\CreateController::class,
	\MasterStudy\Lms\Pro\addons\assignments\Routing\Swagger\Create::class,
);

$router->get(
	'/assignments/{assignment_id}',
	\MasterStudy\Lms\Pro\addons\assignments\Http\Controllers\GetController::class,
	\MasterStudy\Lms\Pro\addons\assignments\Routing\Swagger\Get::class,
);

$router->put(
	'/assignments/{assignment_id}',
	\MasterStudy\Lms\Pro\addons\assignments\Http\Controllers\UpdateController::class,
	\MasterStudy\Lms\Pro\addons\assignments\Routing\Swagger\Update::class,
);

$router->delete(
	'/assignments/{assignment_id}',
	\MasterStudy\Lms\Pro\addons\assignments\Http\Controllers\DeleteController::class,
	\MasterStudy\Lms\Pro\addons\assignments\Routing\Swagger\Delete::class,
);

$router->get(
	'/assignments',
	\MasterStudy\Lms\Pro\addons\assignments\Http\Controllers\Frontend\GetAssignmentsController::class,
	\MasterStudy\Lms\Pro\addons\assignments\Routing\Swagger\Frontend\GetAssignments::class
);

$router->get(
	'/student-assignments',
	\MasterStudy\Lms\Pro\addons\assignments\Http\Controllers\Frontend\GetStudentAssignmentsController::class,
	\MasterStudy\Lms\Pro\addons\assignments\Routing\Swagger\Frontend\GetStudentAssignments::class
);

$router->group(
	array(
		'middleware' => array(
			\MasterStudy\Lms\Routing\Middleware\Authentication::class,
			\MasterStudy\Lms\Routing\Middleware\AdminOrInstructor::class,
		),
	),
	function ( Router $router ) {
		$router->get(
			'/admin-assignments',
			\MasterStudy\Lms\Pro\addons\assignments\Http\Controllers\Admin\GetAssignmentsController::class,
			\MasterStudy\Lms\Pro\addons\assignments\Routing\Swagger\GetAdminAssignments::class
		);

		$router->patch(
			'/admin-assignments/{assignment_id}/status',
			\MasterStudy\Lms\Pro\addons\assignments\Http\Controllers\Admin\UpdateStatusController::class,
			\MasterStudy\Lms\Pro\addons\assignments\Routing\Swagger\UpdateAdminAssignmentStatus::class
		);

		$router->post(
			'/admin-assignments/bulk-update',
			\MasterStudy\Lms\Pro\addons\assignments\Http\Controllers\Admin\BulkUpdateController::class,
			\MasterStudy\Lms\Pro\addons\assignments\Routing\Swagger\BulkUpdateAdminAssignments::class
		);

		$router->post(
			'/admin-assignments/bulk-delete',
			\MasterStudy\Lms\Pro\addons\assignments\Http\Controllers\Admin\BulkDeleteController::class,
			\MasterStudy\Lms\Pro\addons\assignments\Routing\Swagger\BulkDeleteAdminAssignments::class
		);

		$router->get(
			'/admin-student-assignments',
			\MasterStudy\Lms\Pro\addons\assignments\Http\Controllers\Admin\GetStudentAssignmentsController::class,
			\MasterStudy\Lms\Pro\addons\assignments\Routing\Swagger\GetAdminStudentAssignments::class
		);

		$router->get(
			'/admin-student-assignments/students',
			\MasterStudy\Lms\Pro\addons\assignments\Http\Controllers\Admin\GetStudentAssignmentStudentsController::class,
			\MasterStudy\Lms\Pro\addons\assignments\Routing\Swagger\GetAdminStudentAssignmentStudents::class
		);

		$router->get(
			'/admin-student-assignments/courses',
			\MasterStudy\Lms\Pro\addons\assignments\Http\Controllers\Admin\GetStudentAssignmentCoursesController::class,
			\MasterStudy\Lms\Pro\addons\assignments\Routing\Swagger\GetAdminStudentAssignmentCourses::class
		);

		$router->get(
			'/admin-student-assignments/{student_assignment_id}',
			\MasterStudy\Lms\Pro\addons\assignments\Http\Controllers\Admin\GetStudentAssignmentController::class,
			\MasterStudy\Lms\Pro\addons\assignments\Routing\Swagger\GetAdminStudentAssignment::class
		);

		$router->delete(
			'/admin-student-assignments/{student_assignment_id}',
			\MasterStudy\Lms\Pro\addons\assignments\Http\Controllers\Admin\DeleteStudentAssignmentController::class,
			\MasterStudy\Lms\Pro\addons\assignments\Routing\Swagger\DeleteAdminStudentAssignment::class
		);

		$router->post(
			'/admin-student-assignments/bulk-delete',
			\MasterStudy\Lms\Pro\addons\assignments\Http\Controllers\Admin\BulkDeleteStudentAssignmentsController::class,
			\MasterStudy\Lms\Pro\addons\assignments\Routing\Swagger\BulkDeleteAdminStudentAssignments::class
		);

		$router->put(
			'/admin-student-assignments/{student_assignment_id}/review',
			\MasterStudy\Lms\Pro\addons\assignments\Http\Controllers\Admin\ReviewStudentAssignmentController::class,
			\MasterStudy\Lms\Pro\addons\assignments\Routing\Swagger\ReviewAdminStudentAssignment::class
		);

		$router->post(
			'/admin-student-assignments/{student_assignment_id}/attachments',
			\MasterStudy\Lms\Pro\addons\assignments\Http\Controllers\Admin\AddStudentAssignmentAttachmentController::class,
			\MasterStudy\Lms\Pro\addons\assignments\Routing\Swagger\AddAdminStudentAssignmentAttachment::class
		);

		$router->delete(
			'/admin-student-assignments/{student_assignment_id}/attachments/{attachment_id}',
			\MasterStudy\Lms\Pro\addons\assignments\Http\Controllers\Admin\DeleteStudentAssignmentAttachmentController::class,
			\MasterStudy\Lms\Pro\addons\assignments\Routing\Swagger\DeleteAdminStudentAssignmentAttachment::class
		);
	}
);
