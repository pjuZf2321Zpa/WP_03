<?php

namespace BitApps\IntegrationsPro\Actions\ProfilePress;

use Exception;
use ProfilePress\Core\Membership\Models\Customer\CustomerEntity;
use ProfilePress\Core\Membership\Models\Customer\CustomerFactory;
use ProfilePress\Core\Membership\Models\Order\OrderFactory;
use ProfilePressVendor\Carbon\CarbonImmutable;
use WP_Error;

/**
 * ProfilePress write actions.
 *
 * Ported from bit-pi's ProfilePressServices. The plan id arrives on
 * $integrationDetails as flow configuration (selectedPlan); everything else
 * arrives on $fieldData from the field map.
 */
class ProfilePressProHelper
{
    /**
     * Subscribe a customer to a plan, creating the resulting order.
     *
     * @param array       $defaultResponse
     * @param array       $fieldData
     * @param null|object $utilities
     * @param null|object $integrationDetails
     *
     * @return array
     */
    public static function addNewOrder($defaultResponse, $fieldData, $utilities = null, $integrationDetails = null)
    {
        if (!ProfilePressHelper::isPluginActive()) {
            return ProfilePressHelper::errorResponse(__('ProfilePress is not installed or activated', 'bit-integrations-pro'));
        }

        // CarbonImmutable is deliberately absent here — it is only needed when a flow
        // maps Order Date, so it is checked inside subscribeUserToPlan instead of
        // failing orders that never supply one.
        $missingDependency = ProfilePressHelper::getMissingDependency(
            [
                '\ProfilePress\Core\Membership\Models\Customer\CustomerFactory',
                '\ProfilePress\Core\Membership\Services\Calculator',
                '\ProfilePress\Core\Membership\Models\Order\OrderFactory',
            ],
            ['ppress_get_plan', 'ppress_subscribe_user_to_plan', 'ppress_clean']
        );

        if ($missingDependency) {
            return ProfilePressHelper::missingDependencyResponse($missingDependency);
        }

        $planId = absint(self::configValue($integrationDetails, 'selectedPlan', 0));

        if (empty($planId)) {
            return ProfilePressHelper::errorResponse(__('Plan is required', 'bit-integrations-pro'));
        }

        if ($invalid = ProfilePressHelper::requireFields($fieldData, ['customer_email'])) {
            return $invalid;
        }

        $plan = ppress_get_plan($planId);

        if (!$plan || empty($plan->id)) {
            return ProfilePressHelper::errorResponse(__('The selected plan does not exist.', 'bit-integrations-pro'));
        }

        $customer = self::resolveCustomerByEmail($fieldData['customer_email']);

        if (ProfilePressHelper::isError($customer)) {
            return $customer;
        }

        $customerId = absint($customer->get_id());

        $response = self::subscribeUserToPlan($fieldData, $utilities, $plan, $planId, $customerId);

        if (is_wp_error($response)) {
            return ProfilePressHelper::errorResponse($response->get_error_message());
        }

        if (empty($response['order_id'])) {
            return ProfilePressHelper::errorResponse(__('Order creation failed.', 'bit-integrations-pro'));
        }

        $order = OrderFactory::fromId(absint($response['order_id']));

        // OrderRepository::retrieve() builds an entity from an empty row when there is
        // no match, so it never returns null. Without exists() the billing loop would
        // populate a phantom entity and save() would insert an orphan order.
        if (!$order || !$order->exists()) {
            return ProfilePressHelper::errorResponse(
                // translators: %s: order id
                wp_sprintf(__('The subscription was created but order %s could not be loaded.', 'bit-integrations-pro'), absint($response['order_id']))
            );
        }

        $billingKeys = ['billing_address', 'billing_city', 'billing_country', 'billing_state', 'billing_postcode', 'billing_phone'];
        $billingSupplied = false;

        foreach ($billingKeys as $key) {
            // Unlike bit-pi, an unmapped key is left alone rather than overwritten
            // with an empty string, so a partial mapping keeps the rest of the address.
            if (!isset($fieldData[$key]) || $fieldData[$key] === '') {
                continue;
            }

            $order->{$key} = ppress_clean($fieldData[$key], 'sanitize_text_field');
            $billingSupplied = true;
        }

        if ($billingSupplied) {
            $order->save();
        }

        return ProfilePressHelper::successResponse(
            __('Order created successfully', 'bit-integrations-pro'),
            [
                'order_id'       => $order->get_id(),
                'plan_id'        => $planId,
                'customer_id'    => $customerId,
                'customer_email' => $customer->get_email(),
            ]
        );
    }

    public static function addOrUpdateCustomer($defaultResponse, $fieldData)
    {
        if (!ProfilePressHelper::isPluginActive()) {
            return ProfilePressHelper::errorResponse(__('ProfilePress is not installed or activated', 'bit-integrations-pro'));
        }

        if ($invalid = ProfilePressHelper::requireFields($fieldData, ['user_email', 'user_name'])) {
            return $invalid;
        }

        if (!is_email($fieldData['user_email'])) {
            return ProfilePressHelper::errorResponse(__('A valid email address is required.', 'bit-integrations-pro'));
        }

        $missingDependency = ProfilePressHelper::getMissingDependency(
            [
                '\ProfilePress\Core\Membership\Models\Customer\CustomerFactory',
                '\ProfilePress\Core\Membership\Models\Customer\CustomerEntity',
            ]
        );

        if ($missingDependency) {
            return ProfilePressHelper::missingDependencyResponse($missingDependency);
        }

        $userId = ProfilePressHelper::createOrUpdateCustomer($fieldData);

        if (is_wp_error($userId)) {
            return ProfilePressHelper::errorResponse($userId->get_error_message());
        }

        ProfilePressHelper::updateCustomerMetaData($fieldData, $userId);

        $customer = CustomerFactory::fromUserId($userId);

        if (!$customer->exists()) {
            $newCustomer = new CustomerEntity();
            $newCustomer->user_id = $userId;
            $customerId = $newCustomer->save();

            if (empty($customerId)) {
                return ProfilePressHelper::errorResponse(__('Error creating customer record.', 'bit-integrations-pro'));
            }

            $customer = CustomerFactory::fromId(absint($customerId));
        }

        return ProfilePressHelper::successResponse(
            __('Customer saved successfully', 'bit-integrations-pro'),
            [
                'customer_id' => $customer->get_id(),
                'user_id'     => $userId,
                'email'       => $customer->get_email(),
            ]
        );
    }

    /**
     * Resolve a ProfilePress customer from an email address.
     *
     * ProfilePress offers no email lookup — CustomerFactory exposes only fromId()
     * and fromUserId() — but every customer is bound to a WP user, so the address
     * is resolved through that. The two failure modes are reported separately
     * because "no such user" and "user has never been a customer" need different
     * fixes from whoever built the flow.
     *
     * @param string $email
     *
     * @return array|object Error envelope, or the CustomerEntity
     */
    private static function resolveCustomerByEmail($email)
    {
        $email = sanitize_email($email);

        if (!is_email($email)) {
            return ProfilePressHelper::errorResponse(__('A valid customer email address is required.', 'bit-integrations-pro'));
        }

        $user = get_user_by('email', $email);

        if (!$user) {
            return ProfilePressHelper::errorResponse(
                // translators: %s: email address
                wp_sprintf(__('No WordPress user found with the email %s.', 'bit-integrations-pro'), $email)
            );
        }

        $customer = CustomerFactory::fromUserId($user->ID);

        // retrieveByUserID() builds an entity from an empty row when there is no
        // match, so it always returns an object — exists() is the real check.
        if (!$customer || !$customer->exists()) {
            return ProfilePressHelper::errorResponse(
                // translators: %s: email address
                wp_sprintf(__('%s has a WordPress account but no ProfilePress customer record.', 'bit-integrations-pro'), $email)
            );
        }

        return $customer;
    }

    private static function subscribeUserToPlan($fieldData, $utilities, $plan, $planId, $customerId)
    {
        $dateCreated = current_time('mysql');

        if (!empty($fieldData['order_date'])) {
            // Checked here rather than up front so an order that never maps a date is
            // not blocked by a class it does not use.
            if (!class_exists('\ProfilePressVendor\Carbon\CarbonImmutable')) {
                return new WP_Error(
                    'missing_dependency',
                    __('Order Date needs ProfilePress\'s bundled Carbon library, which is not available.', 'bit-integrations-pro')
                );
            }

            try {
                $dateCreated = CarbonImmutable::parse($fieldData['order_date'], wp_timezone())
                    ->setTimeFromTimeString(CarbonImmutable::now(wp_timezone())->toTimeString())
                    ->utc()
                    ->toDateTimeString();
            } catch (Exception $e) {
                return new WP_Error('invalid_date_format', $e->getMessage());
            }
        }

        $orderData = [
            // A mapped-but-blank field arrives as '' rather than being absent, so ??
            // alone would not fall back. Tested against '' rather than with empty(),
            // because 0 is a valid amount — a comped or fully discounted order — and
            // empty() would silently charge it at the plan price instead.
            'amount' => isset($fieldData['amount']) && $fieldData['amount'] !== ''
                ? $fieldData['amount']
                : $plan->get_price(),
            'order_status'   => self::utilityValue($utilities, 'selected_order_status', 'pending'),
            'payment_method' => $fieldData['payment_method'] ?? '',
            'transaction_id' => $fieldData['transaction_id'] ?? '',
            'date_created'   => $dateCreated,
        ];

        $sendReceipt = self::utilityValue($utilities, 'selected_send_receipt', '') === 'yes';

        return ppress_subscribe_user_to_plan($planId, $customerId, $orderData, $sendReceipt);
    }

    /**
     * Read a flow configuration value set by a dropdown in the integration layout.
     *
     * @param null|object $integrationDetails
     * @param string      $key
     * @param mixed       $default
     *
     * @return mixed
     */
    private static function configValue($integrationDetails, $key, $default = '')
    {
        return isset($integrationDetails->{$key}) && $integrationDetails->{$key} !== ''
            ? $integrationDetails->{$key}
            : $default;
    }

    /**
     * Read an optional value set by a Utilities checkbox.
     *
     * @param null|object $utilities
     * @param string      $key
     * @param mixed       $default
     *
     * @return mixed
     */
    private static function utilityValue($utilities, $key, $default = '')
    {
        return isset($utilities->{$key}) && $utilities->{$key} !== ''
            ? $utilities->{$key}
            : $default;
    }
}
