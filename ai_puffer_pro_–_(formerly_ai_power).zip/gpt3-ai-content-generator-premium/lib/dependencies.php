<?php

namespace WPAICG\Lib\DependencyLoaders;

if (!defined('ABSPATH')) {
    exit;
}

/** Paid feature dependency loading; declarations are shared, execution remains feature-specific. */
class Smart_SEO_Dependencies_Loader
{
    public static function load(): void
    {
        $files_to_load = [
            WPAICG_PLUGIN_DIR . 'classes/content-writer/seo.php',
            WPAICG_LIB_DIR . 'content-writer/seo-rules.php',
            WPAICG_LIB_DIR . 'seo/audit.php',
            WPAICG_LIB_DIR . 'seo/rules.php',
            WPAICG_LIB_DIR . 'content-writer/seo-keyphrase-usage.php',
            WPAICG_LIB_DIR . 'content-writer/seo-models.php',
            WPAICG_LIB_DIR . 'content-writer/seo-keyword-resolution.php',
            WPAICG_LIB_DIR . 'content-writer/seo-images.php',
            WPAICG_LIB_DIR . 'content-writer/seo-naturalness.php',
            WPAICG_LIB_DIR . 'content-writer/seo-rank-math.php',
            WPAICG_LIB_DIR . 'content-writer/seo-yoast.php',
            WPAICG_LIB_DIR . 'content-writer/seo-aioseo.php',
            WPAICG_LIB_DIR . 'content-writer/seo-links.php',
            WPAICG_LIB_DIR . 'content-writer/seo-context.php',
            WPAICG_LIB_DIR . 'content-writer/seo-service.php',
            WPAICG_LIB_DIR . 'content-writer/seo-actions.php',
        ];

        foreach ($files_to_load as $full_path) {
            if (file_exists($full_path)) {
                require_once $full_path;
            }
        }
    }
}

class Integrations_Recipes_Dependencies_Loader
{
    public static function load(): void
    {
        if (!defined('WPAICG_LIB_DIR')) {
            return;
        }

        $files = [
            WPAICG_LIB_DIR . 'integrations/token-refresh.php',
            WPAICG_LIB_DIR . 'integrations/connections.php',
            WPAICG_LIB_DIR . 'integrations/connection-diagnostics.php',
            WPAICG_LIB_DIR . 'integrations/actions.php',
            WPAICG_LIB_DIR . 'integrations/delivery-log.php',
            WPAICG_LIB_DIR . 'integrations/delivery-maintenance.php',
            WPAICG_LIB_DIR . 'integrations/recipe-gates.php',
            WPAICG_LIB_DIR . 'integrations/recipe-contracts.php',
            WPAICG_LIB_DIR . 'integrations/recipe-registry.php',
            WPAICG_LIB_DIR . 'integrations/recipes.php',
            WPAICG_LIB_DIR . 'integrations/recipe-validation.php',
            WPAICG_LIB_DIR . 'integrations/recipe-fields.php',
            WPAICG_LIB_DIR . 'integrations/recipe-executor.php',
            WPAICG_LIB_DIR . 'integrations/recipe-runtime.php',
        ];

        foreach ($files as $file) {
            if (file_exists($file)) {
                require_once $file;
            }
        }

        if (class_exists(\WPAICG\Lib\Integrations\Recipes\AIPKit_Stored_Recipes::class)) {
            add_filter('aipkit_event_delivery_has_subscribers', [\WPAICG\Lib\Integrations\Recipes\AIPKit_Stored_Recipes::class, 'has_event_delivery_subscribers'], 10, 2);
        }
    }
}

class Triggers_Dependencies_Loader
{
    public static function load()
    {
        self::load_schemas();
        self::load_actions();
        self::load_conditions();
        self::load_manager();
        self::load_storage();
        self::load_core();
    }

    /**
     * Loads trigger schema definitions.
     */
    private static function load_schemas(): void {
        if (!defined('WPAICG_LIB_DIR')) {
            return;
        }

        $trigger_schemas_path = WPAICG_LIB_DIR . 'chatbot/trigger-schemas.php';
        if (file_exists($trigger_schemas_path)) {
            require_once $trigger_schemas_path;
        }
    }

    /**
     * Loads trigger action classes.
     */
    private static function load_actions(): void {
        if (!defined('WPAICG_LIB_DIR')) {
            return;
        }
        $placeholder_path = WPAICG_LIB_DIR . 'chatbot/trigger-context.php';
        if (file_exists($placeholder_path)) {
            if (!class_exists('\\WPAICG\\Lib\\Chat\\Triggers\\Actions\\AIPKit_Placeholder_Processor')) {
                require_once $placeholder_path;
            }
        }

        $local_actions_path = WPAICG_LIB_DIR . 'chatbot/trigger-actions.php';
        if (file_exists($local_actions_path)) {
            require_once $local_actions_path;
        }

        $webhook_path = WPAICG_LIB_DIR . 'chatbot/trigger-webhook.php';
        if (file_exists($webhook_path)) {
            if (!class_exists('\\WPAICG\\Lib\\Chat\\Triggers\\Actions\\AIPKit_Action_Call_Webhook')) {
                require_once $webhook_path;
            }
        }
    }

    /**
     * Loads the trigger condition evaluator.
     */
    private static function load_conditions(): void {
        if (!defined('WPAICG_LIB_DIR')) {
            return;
        }
        $conditions_path = WPAICG_LIB_DIR . 'chatbot/trigger-conditions.php';
        if (file_exists($conditions_path)) {
            require_once $conditions_path;
        }
    }

    /**
     * Loads trigger manager component classes.
     */
    private static function load_manager(): void {
        if (!defined('WPAICG_LIB_DIR')) {
            return;
        }
        $events_path = WPAICG_LIB_DIR . 'chatbot/trigger-events.php';
        if (file_exists($events_path)) {
            require_once $events_path;
        }
    }

    /**
     * Loads trigger storage component classes.
     */
    private static function load_storage(): void {
        if (!defined('WPAICG_LIB_DIR')) {
            return;
        }
        $storage_path = WPAICG_LIB_DIR . 'chatbot/trigger-storage.php';
        if (file_exists($storage_path)) {
            require_once $storage_path;
        }
    }

    /**
     * Loads core trigger facade classes and handler function.
     */
    private static function load_core(): void {
        if (!defined('WPAICG_LIB_DIR')) {
            return;
        }

        $form_state_store_path = WPAICG_LIB_DIR . 'chatbot/trigger-state.php';
        if (file_exists($form_state_store_path)) {
            require_once $form_state_store_path;
        }

        // Preserve the existing class lookup names and dependency order.
        $core_trigger_files = [
            'chatbot/trigger-executor.php' => '\\WPAICG\\Lib\\Chat\\Triggers\\AIPKitTriggerActionExecutor',
            'chatbot/trigger-manager.php' => '\\WPAICG\\Lib\\Chat\\Triggers\\AIPKitTriggerManager',
        ];
        foreach ($core_trigger_files as $file => $class) {
            $full_path = WPAICG_LIB_DIR . $file;
            if (file_exists($full_path) && !class_exists($class)) {
                require_once $full_path;
            }
        }

        $handler_path = WPAICG_LIB_DIR . 'chatbot/trigger-chat.php';
        if (file_exists($handler_path) && !function_exists('\WPAICG\Lib\Chat\Triggers\process_chat_triggers')) {
            require_once $handler_path;
        }

        $form_state_store_class = '\\WPAICG\\Lib\\Chat\\Triggers\\State\\AIPKit_Conversation_Form_State_Store';
        if (class_exists($form_state_store_class) && is_callable([$form_state_store_class, 'register_hooks'])) {
            $form_state_store_class::register_hooks();
        }
    }
}
