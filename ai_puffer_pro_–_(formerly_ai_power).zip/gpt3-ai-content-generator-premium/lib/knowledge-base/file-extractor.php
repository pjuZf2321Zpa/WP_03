<?php

namespace WPAICG\Lib\Utils;

use WP_Error;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * AIPKit_File_Text_Extractor
 * Pro-only utility to extract and normalize text from uploaded files for vector indexing.
 * Supports: text/plain, application/pdf, text/html, docx.
 */
class AIPKit_File_Text_Extractor
{
    /**
     * Extracts text from the given uploaded file (from $_FILES array entry).
     * Returns cleaned UTF-8 text or WP_Error on failure.
     *
     * @param array $file_data
     * @return string|WP_Error
     */
    public function extract(array $file_data)
    {
        $tmp = $file_data['tmp_name'] ?? '';
        if (!$tmp || !is_readable($tmp)) {
            return new WP_Error('file_unreadable', __('Uploaded file is not readable.', 'gpt3-ai-content-generator'));
        }

        $mime = $this->detect_mime($file_data);
        $ext  = strtolower(pathinfo($file_data['name'] ?? '', PATHINFO_EXTENSION));

        // Binary document extensions must reach their parser, even when a
        // corrupt file is detected as plain text.
        if ($ext === 'pdf') {
            $mime = 'application/pdf';
        } elseif ($ext === 'docx') {
            $mime = 'application/vnd.openxmlformats-officedocument.wordprocessingml.document';
        }

        switch ($mime) {
            case 'text/plain':
            case 'text/csv':
            case 'application/csv':
            case 'application/vnd.ms-excel':
            case 'text/comma-separated-values':
            case 'application/json':
            case 'text/json':
                $raw = @file_get_contents($tmp);
                if ($raw === false) {
                    return new WP_Error('file_read_error', __('Could not read file content.', 'gpt3-ai-content-generator'));
                }
                return $this->clean_text($raw);

            case 'application/pdf':
            case 'application/x-pdf':
                if (!class_exists(AIPKit_Pdf_Parser::class)) {
                    return new WP_Error('pdf_parser_missing', __('PDF parser not available.', 'gpt3-ai-content-generator'));
                }
                $parser = new AIPKit_Pdf_Parser();
                $out = $parser->extract_text($tmp);
                if (is_wp_error($out)) {
                    return $out;
                }
                return $this->clean_text($out);

            case 'text/html':
            case 'application/xhtml+xml':
                $raw = @file_get_contents($tmp);
                if ($raw === false) {
                    return new WP_Error('file_read_error_html', __('Could not read HTML file.', 'gpt3-ai-content-generator'));
                }
                // Use WP helper to strip tags; decode entities first for better results
                $decoded = html_entity_decode($raw, ENT_QUOTES | ENT_HTML5, 'UTF-8');
                $text    = wp_strip_all_tags($decoded);
                return $this->clean_text($text);

            default:
                // Heuristic docx detection by extension when MIME is generic
                if ($ext === 'docx' || $mime === 'application/vnd.openxmlformats-officedocument.wordprocessingml.document') {
                    $text = $this->extract_docx_text($tmp);
                    if (is_wp_error($text)) {
                        return $text;
                    }
                    return $this->clean_text($text);
                }
                if (in_array($ext, ['csv', 'json'], true)) {
                    $raw = @file_get_contents($tmp);
                    if ($raw === false) {
                        return new WP_Error('file_read_error', __('Could not read file content.', 'gpt3-ai-content-generator'));
                    }
                    return $this->clean_text($raw);
                }
                /* translators: %s: file type (MIME type or extension) */
                return new WP_Error('unsupported_file_type', sprintf(__('Unsupported file type: %s', 'gpt3-ai-content-generator'), esc_html($mime ?: $ext ?: 'unknown')));
        }
    }

    private function detect_mime(array $file_data): string
    {
        $tmp = $file_data['tmp_name'] ?? '';
        $mime = '';
        if ($tmp && function_exists('mime_content_type')) {
            $det = @mime_content_type($tmp);
            if (is_string($det) && $det !== '') $mime = $det;
        }
        if (!$mime && !empty($file_data['type'])) {
            $mime = (string)$file_data['type'];
        }
        return strtolower($mime);
    }

    /**
     * Minimal docx reader: open as zip and read word/document.xml, strip tags.
     * @return string|\WP_Error
     */
    private function extract_docx_text(string $path)
    {
        if (!class_exists('ZipArchive')) {
            return new WP_Error('zip_missing', __('DOCX extraction requires ZipArchive extension.', 'gpt3-ai-content-generator'));
        }
        $zip = new \ZipArchive();
        if ($zip->open($path) !== true) {
            return new WP_Error('docx_open_failed', __('Failed to open DOCX file.', 'gpt3-ai-content-generator'));
        }
        $index = $zip->locateName('word/document.xml');
        if ($index === false) {
            $zip->close();
            return new WP_Error('docx_xml_missing', __('DOCX main document.xml not found.', 'gpt3-ai-content-generator'));
        }
        $xml = $zip->getFromIndex($index);
        $zip->close();
        if ($xml === false) {
            return new WP_Error('docx_read_failed', __('Failed to read DOCX XML.', 'gpt3-ai-content-generator'));
        }
        // Insert paragraph breaks where appropriate (<w:p>) then strip tags
        $xml = preg_replace('#</w:p>#i', "\n\n", $xml);
        $text = wp_strip_all_tags($xml);
        return $text;
    }

    /**
     * Normalize text: ensure UTF-8, normalize newlines, collapse excessive whitespace while preserving paragraphs,
     * remove control chars, trim, and allow final customization via filter.
     */
    public function clean_text(string $text): string
    {
        $original = $text;
        $orig_len = function_exists('mb_strlen') ? mb_strlen($original) : strlen($original);

        // Ensure UTF-8. Some PDF parsers return mostly-valid UTF-8 with a few
        // invalid bytes; converting the whole string from Latin-1 would mojibake
        // valid non-English text, so strip invalid UTF-8 first.
        $is_valid_utf8 = function_exists('mb_check_encoding')
            ? mb_check_encoding($text, 'UTF-8')
            : (function_exists('wp_check_invalid_utf8') && wp_check_invalid_utf8($text, true) === $text);
        if (!$is_valid_utf8) {
            $utf8_cleaned = $this->strip_invalid_utf8_bytes($text);
            if ($this->is_usable_utf8_cleanup($text, $utf8_cleaned)) {
                $text = $utf8_cleaned;
            } else {
                $detected = function_exists('mb_detect_encoding') ? @mb_detect_encoding($text, 'UTF-8, ISO-8859-1, ISO-8859-15, Windows-1252, ASCII', true) : false;
                if ($detected && $detected !== 'UTF-8') {
                    $converted = function_exists('iconv') ? @iconv($detected, 'UTF-8//IGNORE', $text) : @mb_convert_encoding($text, 'UTF-8', $detected);
                    if (is_string($converted) && $converted !== '') {
                        $text = $converted;
                    } else {
                        $text = function_exists('wp_check_invalid_utf8') ? wp_check_invalid_utf8($text, true) : $text;
                    }
                } else {
                    $text = $utf8_cleaned !== '' ? $utf8_cleaned : (function_exists('wp_check_invalid_utf8') ? wp_check_invalid_utf8($text, true) : $text);
                }
            }
        }
        $text = $this->repair_utf8_mojibake($text);
        // Remove BOM
        $text = preg_replace('/^\xEF\xBB\xBF/', '', $text);
        // Normalize newlines to \n
        $text = str_replace(["\r\n", "\r"], "\n", $text);
        // Remove zero-width and control chars except tab and newline
        $text = preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F\x{200B}-\x{200F}\x{FEFF}]/u', '', $text);
        // Collapse 3+ newlines to 2 (preserve paragraph breaks)
        $text = preg_replace("/\n{3,}/", "\n\n", $text);
        // Collapse spaces around newlines
        $text = preg_replace("/[ \t]*\n[ \t]*/", "\n", $text);
        // Trim lines
        $text = implode("\n", array_map('trim', explode("\n", $text)));
        // Final trim
        $text = trim($text);
        // If cleaning nuked everything but original was non-empty, apply safer fallback
        $final_len = function_exists('mb_strlen') ? mb_strlen($text) : strlen($text);
        if ($final_len === 0 && $orig_len > 0) {
            // Replace NBSP with space, normalize newlines, keep characters otherwise
            $fallback = str_replace(["\xC2\xA0"], ' ', $original); // NBSP
            $fallback = str_replace(["\r\n", "\r"], "\n", $fallback);
            $fallback = preg_replace('/^\xEF\xBB\xBF/', '', $fallback);
            $fallback = trim($fallback);
            $text = $fallback;
        }
        // Allow customization
        return apply_filters('aipkit_vector_clean_text', $text);
    }

    private function strip_invalid_utf8_bytes(string $text): string
    {
        $cleaned = function_exists('iconv') ? @iconv('UTF-8', 'UTF-8//IGNORE', $text) : false;
        if (is_string($cleaned) && $cleaned !== '') {
            return $cleaned;
        }

        if (function_exists('wp_check_invalid_utf8')) {
            $cleaned = wp_check_invalid_utf8($text, true);
            if (is_string($cleaned)) {
                return $cleaned;
            }
        }

        return '';
    }

    private function is_usable_utf8_cleanup(string $original, string $cleaned): bool
    {
        if ($cleaned === '') {
            return false;
        }

        $original_len = strlen($original);
        $cleaned_len = strlen($cleaned);
        if ($original_len <= 0) {
            return true;
        }

        return ($cleaned_len / $original_len) >= 0.85;
    }

    private function repair_utf8_mojibake(string $text): string
    {
        if (!$this->looks_like_utf8_mojibake($text)) {
            return $text;
        }

        foreach (['ISO-8859-1', 'Windows-1252'] as $encoding) {
            if (!function_exists('iconv')) {
                continue;
            }
            $bytes = @iconv('UTF-8', $encoding . '//IGNORE', $text);
            if (!is_string($bytes) || $bytes === '') {
                continue;
            }
            if (function_exists('mb_check_encoding') && !mb_check_encoding($bytes, 'UTF-8')) {
                continue;
            }
            if ($this->mojibake_score($bytes) < $this->mojibake_score($text)) {
                return $bytes;
            }
        }

        return $text;
    }

    private function looks_like_utf8_mojibake(string $text): bool
    {
        return $this->mojibake_score($text) >= 3;
    }

    private function mojibake_score(string $text): int
    {
        $patterns = [
            'Ã', 'Â', 'â', 'â€™', 'â€œ', 'â€', 'Ä±', 'Ä°', 'Ä', 'Å', 'ÅŸ', 'Å', 'Åž',
            'ÄŸ', 'Ã§', 'Ã¶', 'Ã¼', 'Ã‡', 'Ã–', 'Ãœ',
        ];
        $score = 0;
        foreach ($patterns as $pattern) {
            $score += substr_count($text, $pattern);
        }
        return $score;
    }
}
