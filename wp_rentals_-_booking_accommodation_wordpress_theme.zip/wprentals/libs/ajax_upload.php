<?php

add_action('wp_ajax_wpestate_delete_file',             'wpestate_delete_file');

if( !function_exists('wpestate_delete_file') ):
     /**
     * AJAX handler for deleting a media attachment associated with a property.
     *
     * Validates the request nonce, ensures the requester is logged in, verifies the
     * attachment and property relationship, and enforces ownership/capability checks
     * before removing the featured image reference and permanently deleting the file.
     */

    function wpestate_delete_file(){

        $is_admin_request = isset($_POST['isadmin']) && intval($_POST['isadmin']) === 1;

        if ( $is_admin_request ) {
            check_ajax_referer( 'wpestate_attach_delete', 'security' );
        } else {
            check_ajax_referer( 'wpestate_image_upload', 'security' );
        }


        $current_user = wp_get_current_user();
        $userID       = $current_user->ID;

        if ( ! is_user_logged_in() ) {
            exit('ko');
        }

        if ( $userID === 0 ) {
            exit('out pls');
        }


        $attach_id  = isset($_POST['attach_id']) ? intval($_POST['attach_id']) : 0;
        $propertyID = isset($_POST['propertyID']) ? intval($_POST['propertyID']) : 0;

        if ( $attach_id === 0 || $propertyID === 0 ) {
            exit('missing data');
        }

        $attachment = get_post( $attach_id );
        $property   = get_post( $propertyID );

        if ( ! $attachment || 'attachment' !== $attachment->post_type ) {
            exit('invalid attachment');
        }

         if ( ! $property ) {
            exit('invalid property');
        }

        // Compute ownership and capability flags used for authorization decisions.
        $user_owns_attachment = (int) $attachment->post_author === $userID;
        $user_owns_property    = (int) $property->post_author === $userID;
        $can_delete_attachment = current_user_can( 'delete_post', $attach_id );

        // Require property ownership or an explicit capability to delete the attachment.
        if ( ! $user_owns_property && ! $can_delete_attachment ) {
            exit('you don\'t have the right to delete this');
        }

        // Ensure the attachment is linked to the property when the user lacks global delete capabilities.
        $attachment_parent_id = (int) wp_get_post_parent_id( $attach_id );

        if ( $attachment_parent_id && $attachment_parent_id !== $propertyID && ! $can_delete_attachment ) {
            exit('you don\'t have the right to delete this');
        }

        // Remove the featured image reference if the attachment is currently set as thumbnail.
        if ( get_post_thumbnail_id( $propertyID ) === $attach_id ) {
            delete_post_thumbnail( $propertyID );
        }

        // Delete the attachment when the user owns it, owns the property, or has the capability to delete.
        if ( $user_owns_attachment || $can_delete_attachment || $user_owns_property ) {
            wp_delete_attachment( $attach_id, true );
        }


        exit;
    }
endif;



add_action('wp_ajax_wpestate_me_upload',             'wpestate_me_upload');

/**
 * wpestate_me_upload
 *
 * AJAX handler for Plupload file uploads from the user dashboard (listing
 * images, profile picture, iCal attachments, etc.). Invoked by the client via
 * admin-ajax.php with a `nonce` query arg created with wp_create_nonce('aaiu_allow')
 * in libs/css_js_include.php.
 *
 * Security note (CRIT-3, fixed 2026-04-13):
 *   - A prior version had no CSRF nonce verification — any cross-origin form
 *     could force a logged-in user to upload arbitrary files. Nonce is now
 *     verified via check_ajax_referer('aaiu_allow', 'nonce').
 *   - The client-side Plupload MIME filter is bypassable. We now enforce a
 *     server-side MIME/extension allowlist via wp_check_filetype_and_ext().
 *
 * Known remaining issue (HIGH-9, not yet fixed): handle_file()/fileupload_process()
 * attaches uploads to $_GET['propid'] without ownership verification.
 *
 * @return void  Emits JSON and exits.
 */
function wpestate_me_upload(){
    // CRIT-3 fix: CSRF nonce must be verified before touching $_FILES.
    check_ajax_referer( 'aaiu_allow', 'nonce' );

    // Resolve the current user for the logged-in check below.
    $current_user = wp_get_current_user();
    $userID                         =   $current_user->ID;

    // Reject anonymous callers — uploads require an authenticated session.
    if ( !is_user_logged_in() ) {
        exit('ko');
    }
    if($userID === 0 ){
        exit('out pls');
    }

    // The button_id identifies which uploader widget triggered the request
    // (used later to decide attachment post_status / parent).
    $button_id=esc_html($_POST['button_id']);

    // CRIT-3 fix: server-side MIME + extension allowlist. Plupload's client
    // filter is cosmetic; an attacker can POST any file type without it.
    // Must match the extensions advertised in libs/css_js_include.php.
    $allowed_mimes = array(
        'jpg|jpeg|jpe' => 'image/jpeg',
        'gif'          => 'image/gif',
        'png'          => 'image/png',
        'webp'         => 'image/webp',
        'pdf'          => 'application/pdf',
    );
    $check = wp_check_filetype_and_ext( $_FILES['aaiu_upload_file']['tmp_name'], $_FILES['aaiu_upload_file']['name'], $allowed_mimes );
    if ( empty( $check['type'] ) ) {
        // File failed the allowlist — abort before wp_handle_upload() runs.
        echo json_encode( array( 'success' => false, 'error' => 'invalid_file_type' ) );
        exit;
    }

    // Repackage $_FILES into the shape expected by wp_handle_upload().
    $file = array(
        'name'      => $_FILES['aaiu_upload_file']['name'],
        'type'      => $_FILES['aaiu_upload_file']['type'],
        'tmp_name'  => $_FILES['aaiu_upload_file']['tmp_name'],
        'error'     => $_FILES['aaiu_upload_file']['error'],
        'size'      => $_FILES['aaiu_upload_file']['size']
    );

    // Delegate to the process/handle helpers which create the attachment post.
    $file = fileupload_process($file,$button_id);
}  
    
    
    
function fileupload_process($file,$button_id=''){

    $attachment = handle_file($file,$button_id);

    if (is_array($attachment)) {
        $html = getHTML($attachment);

        $response = array(
            'success'   => true,
            'html'      => $html,
            'attach'    => $attachment['id']
        );

    
        
        echo json_encode($response);
        exit;
    }

    $response = array('success' => false);
    echo json_encode($response);
    exit;
}
    
    
function handle_file($upload_data,$button_id=''){

    $return = false;
    $uploaded_file = wp_handle_upload($upload_data, array('test_form' => false));

    if (isset($uploaded_file['file'])) {
        $file_loc   =   $uploaded_file['file'];
        $file_name  =   basename($upload_data['name']);
        $file_type  =   wp_check_filetype($file_name);

        $attachment = array(
            'post_mime_type' => $file_type['type'],
            'post_title' => preg_replace('/\.[^.]+$/', '', basename($file_name)),
            'post_content' => '',
            'post_status' => 'inherit'
        );
        
        
        
        if( isset($_GET['propid']) && is_numeric($_GET['propid'] ) ){
            $prop_id        = intval( $_GET['propid'] );
            $prop_post      = get_post( $prop_id );
            $current_uid    = get_current_user_id();

            if ( $prop_post
                && ( intval( $prop_post->post_author ) === intval( $current_uid )
                     || current_user_can( 'edit_others_posts' ) ) ) {
                $attachment['post_parent'] = $prop_id;
            }
        }
        if($button_id=='user-id-uploader'){
            $attachment['post_status']='private';
        }

        $attach_id      =   wp_insert_attachment($attachment, $file_loc);
        $attach_data    =   wp_generate_attachment_metadata($attach_id, $file_loc);
        wp_update_attachment_metadata($attach_id, $attach_data);
        $return = array('data' => $attach_data, 'id' => $attach_id);
        
        
        return $return;
    }

    return $return;
}
    
    
function getHTML($attachment){
    $attach_id  =   $attachment['id'];
    $file='';
    $html='';

    if( isset($attachment['data']['file'])){
        $file       =   explode('/', $attachment['data']['file']);
        $file       =   array_slice($file, 0, count($file) - 1);
        $path       =   implode('/', $file);

        if(is_page_template('user_dashboard_add_step1.php') ){
            $image      =   $attachment['data']['sizes']['thumbnail']['file'];
        }else{
            $image      =   $attachment['data']['sizes']['wpestate_property_listings']['file'];
            if ($image==''){
                $get_name=explode('/',$attachment['data']['file']);
                $image      = $get_name[2]  ;
            }
        }
        $post       =   get_post($attach_id);
        $dir        =   wp_upload_dir();
        $path       =   $dir['baseurl'] . '/' . $path;
        $html       =   '';
        
        $current_user = wp_get_current_user();
     
        $userID  =   $current_user->ID;
        $html   .=   $path.'/'.$image; 

    }
    
   
    
    return $html;
}

?>