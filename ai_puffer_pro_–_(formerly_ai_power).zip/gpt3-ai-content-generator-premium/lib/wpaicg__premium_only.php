<?php

/**
 * Composes the paid library when it is shipped with the plugin.
 * Cleanup and declaration-only utilities load before the entitlement check.
 * Feature registration retains its plan, module and request-context gates.
 */

if (!defined('WPINC')) {
    die;
}

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- This file only uses local helper/template variables and does not define public globals.

if (!function_exists('aipkit_pro_plan_active')) {
    function aipkit_pro_plan_active(): bool
    {
        return class_exists('\WPAICG\aipkit_dashboard') && \WPAICG\aipkit_dashboard::is_pro_plan();
    }
}

if (!function_exists('aipkit_pro_require_once')) {
    function aipkit_pro_require_once(string $path): bool
    {
        if (!file_exists($path)) {
            return false;
        }

        require_once $path;
        return true;
    }
}

if (!function_exists('aipkit_pro_require_many')) {
    function aipkit_pro_require_many(array $paths): void
    {
        foreach ($paths as $path) {
            aipkit_pro_require_once($path);
        }
    }
}

if (!function_exists('aipkit_pro_require_class_if_missing')) {
    function aipkit_pro_require_class_if_missing(string $path, string $class_name): bool
    {
        if (class_exists($class_name, false)) {
            return true;
        }

        return aipkit_pro_require_once($path);
    }
}

if (!function_exists('aipkit_pro_call_static')) {
    function aipkit_pro_call_static(string $path, string $class_name, string $method, array $args = []): bool
    {
        if (!aipkit_pro_require_once($path) || !is_callable([$class_name, $method])) {
            return false;
        }

        call_user_func_array([$class_name, $method], $args);
        return true;
    }
}

if (!function_exists('aipkit_pro_call_instance_method')) {
    function aipkit_pro_call_instance_method(string $path, string $class_name, string $method, array $args = []): bool
    {
        if (!aipkit_pro_require_once($path) || !class_exists($class_name)) {
            return false;
        }

        $instance = new $class_name();
        if (!is_callable([$instance, $method])) {
            return false;
        }

        call_user_func_array([$instance, $method], $args);
        return true;
    }
}

if (!function_exists('aipkit_pro_register_ajax_handler')) {
    function aipkit_pro_register_ajax_handler(string $path, string $class_name, string $ajax_action, string $method = 'handle'): bool
    {
        if (!aipkit_pro_require_once($path) || !class_exists($class_name)) {
            return false;
        }

        $handler = new $class_name();
        if (!is_callable([$handler, $method])) {
            return false;
        }

        add_action('wp_ajax_' . $ajax_action, [$handler, $method]);
        return true;
    }
}

if (!function_exists('aipkit_pro_is_admin_like_request')) {
    function aipkit_pro_is_admin_like_request(): bool
    {
        // admin-ajax.php sets WP_ADMIN; front-end AJAX endpoints may set
        // DOING_AJAX only after the admin dependencies have been skipped.
        return is_admin();
    }
}

$aipkit_vendor_autoload = __DIR__ . '/vendor/autoload.php';
if (!class_exists(\Smalot\PdfParser\Parser::class) && file_exists($aipkit_vendor_autoload)) {
    require_once $aipkit_vendor_autoload;
}

$aipkit_lib_dir = __DIR__;

// Premium PDF reading reuses the existing PDF module and libraries.
aipkit_pro_call_static($aipkit_lib_dir . '/knowledge-base/pdf-parser.php', '\WPAICG\Lib\Utils\AIPKit_Pdf_Parser', 'register_mcp');

// Premium theme abilities stay entirely in the paid library; execution rechecks plan and WordPress permissions.
aipkit_pro_call_static($aipkit_lib_dir . '/mcp/themes.php', '\WPAICG\Lib\Mcp\Themes', 'register');

// Keep Pro worker cleanup available during deactivation even if entitlement
// checks no longer pass while a previously queued job still exists.
aipkit_pro_require_once(
    $aipkit_lib_dir . '/knowledge-base/reindex-worker.php'
);
if (class_exists('\WPAICG\Lib\KnowledgeBase\AIPKit_Knowledge_Reindex_Worker')) {
    add_action(
        'aipkit_deactivate_background_workers',
        ['\WPAICG\Lib\KnowledgeBase\AIPKit_Knowledge_Reindex_Worker', 'deactivate']
    );
}

aipkit_pro_require_once($aipkit_lib_dir . '/security/consent.php');
aipkit_pro_call_static($aipkit_lib_dir . '/chatbot/live.php', '\\WPAICG\\Lib\\Chat\\LiveSessions', 'register');

$aipkit_pro_utility_files = [
    $aipkit_lib_dir . '/knowledge-base/pdf-parser.php',
    $aipkit_lib_dir . '/knowledge-base/file-extractor.php',
    $aipkit_lib_dir . '/knowledge-base/openai-chunking.php',
    $aipkit_lib_dir . '/content-writer/url-scraper.php',
    $aipkit_lib_dir . '/integrations/google-auth.php',
];
aipkit_pro_require_many($aipkit_pro_utility_files);

if (aipkit_pro_plan_active()) {
    aipkit_pro_require_many([
        $aipkit_lib_dir . '/knowledge-base/upload-context.php',
        $aipkit_lib_dir . '/settings/actions.php',
        $aipkit_lib_dir . '/ai/google-files.php',
        $aipkit_lib_dir . '/ai/model-sync.php',
        $aipkit_lib_dir . '/chatbot/settings.php',
        $aipkit_lib_dir . '/chatbot/logs.php',
        $aipkit_lib_dir . '/chatbot/frontend.php',
        $aipkit_lib_dir . '/chatbot/ai-service.php',
        $aipkit_lib_dir . '/chatbot/stream.php',
        $aipkit_lib_dir . '/chatbot/form-actions.php',
    ]);
    aipkit_pro_call_static($aipkit_lib_dir . '/chatbot/embed-cors.php', '\WPAICG\Lib\Chat\EmbedCors', 'register');
    aipkit_pro_require_many([
        $aipkit_lib_dir . '/streaming/triggers.php',
        $aipkit_lib_dir . '/content-writer/stream.php',
        $aipkit_lib_dir . '/ai-forms/storage.php',
        $aipkit_lib_dir . '/ai-forms/blueprints.php',
        $aipkit_lib_dir . '/ai-forms/shortcode.php',
        $aipkit_lib_dir . '/ai-forms/processor.php',
    ]);

    $aipkit_knowledge_reindex_files = [
        $aipkit_lib_dir . '/knowledge-base/extraction-fingerprint.php',
        $aipkit_lib_dir . '/knowledge-base/source-state.php',
        $aipkit_lib_dir . '/knowledge-base/reindex-worker.php',
        $aipkit_lib_dir . '/knowledge-base/reindex-actions.php',
    ];
    aipkit_pro_require_many($aipkit_knowledge_reindex_files);
    aipkit_pro_call_static(
        $aipkit_lib_dir . '/knowledge-base/extraction-fingerprint.php',
        '\WPAICG\Lib\KnowledgeBase\AIPKit_Knowledge_Extraction_Fingerprint',
        'register_hooks'
    );
    aipkit_pro_call_static(
        $aipkit_lib_dir . '/knowledge-base/source-state.php',
        '\WPAICG\Lib\KnowledgeBase\AIPKit_Knowledge_Source_State_Store',
        'register_hooks'
    );
    aipkit_pro_call_static(
        $aipkit_lib_dir . '/knowledge-base/reindex-worker.php',
        '\WPAICG\Lib\KnowledgeBase\AIPKit_Knowledge_Reindex_Worker',
        'register_hooks'
    );
    aipkit_pro_register_ajax_handler(
        $aipkit_lib_dir . '/knowledge-base/reindex-actions.php',
        '\WPAICG\Lib\KnowledgeBase\AIPKit_Knowledge_Reindex_Ajax_Handler',
        'aipkit_manage_knowledge_reindex_queue'
    );
    aipkit_pro_call_instance_method(
        $aipkit_lib_dir . '/admin/assets.php',
        '\WPAICG\Lib\Admin\Assets\AIPKit_Knowledge_Reindex_Assets',
        'register_hooks'
    );

    // Usage: automatic log cleanup (retention) settings, status and deletion preview.
    foreach ([
        'aipkit_stats_get_log_retention' => 'ajax_get_status',
        'aipkit_stats_preview_log_retention' => 'ajax_preview',
        'aipkit_stats_save_log_retention' => 'ajax_save',
    ] as $aipkit_retention_action => $aipkit_retention_method) {
        aipkit_pro_register_ajax_handler(
            $aipkit_lib_dir . '/usage/log-retention.php',
            '\WPAICG\Lib\Usage\AIPKit_Log_Retention_Ajax_Handler',
            $aipkit_retention_action,
            $aipkit_retention_method
        );
    }
    aipkit_pro_call_instance_method(
        $aipkit_lib_dir . '/admin/assets.php',
        '\WPAICG\Lib\Admin\Assets\AIPKit_Usage_Pro_Assets',
        'register_hooks'
    );

    add_action('init', static function (): void {
        if (!aipkit_pro_is_admin_like_request()) {
            return;
        }

        aipkit_pro_register_ajax_handler(
            WPAICG_LIB_DIR . 'knowledge-base/upload-google.php',
            '\\WPAICG\\Lib\\VectorStores\\GoogleFileSearch\\AIPKit_Google_File_Search_Upload_Ajax_Handler',
            'aipkit_upload_file_to_google_file_search'
        );
    }, 20);

    $aipkit_ollama_hook_registrars = [
        '\\WPAICG\\Addons\\Ollama\\AIPKit_Ollama_Provider_Gating_Integration',
        '\\WPAICG\\Addons\\Ollama\\AIPKit_Ollama_Model_Sync_Classifier',
        '\\WPAICG\\Addons\\Ollama\\AIPKit_Ollama_Embedding_Integration',
        '\\WPAICG\\Addons\\Ollama\\AIPKit_Ollama_Upload_Gate_Integration',
        '\\WPAICG\\Addons\\Ollama\\AIPKit_Ollama_Vision_Integration',
    ];
    foreach ($aipkit_ollama_hook_registrars as $aipkit_ollama_registrar) {
        aipkit_pro_call_static($aipkit_lib_dir . '/ai/ollama.php', $aipkit_ollama_registrar, 'register_hooks');
    }

    aipkit_pro_call_static(
        $aipkit_lib_dir . '/knowledge-base/openai-chunking.php',
        '\\WPAICG\\Lib\\Utils\\AIPKit_OpenAI_File_Search_Chunking',
        'register_hooks'
    );

    $module_settings = \WPAICG\aipkit_dashboard::get_module_settings();
    if (!empty($module_settings['content_writer']) || !empty($module_settings['autogpt'])) {
        aipkit_pro_require_many([
            $aipkit_lib_dir . '/content-writer/rss-feed.php',
            $aipkit_lib_dir . '/content-writer/rss-selection.php',
            $aipkit_lib_dir . '/content-writer/google-sheets.php',
        ]);

        add_action('init', static function (): void {
            if (!aipkit_pro_is_admin_like_request()) {
                return;
            }

            $ajax_handlers = [
                [
                    'class' => '\\WPAICG\\Lib\\ContentWriter\\Ajax\\Actions\\AIPKit_Content_Writer_Verify_Gsheets_Action',
                    'action' => 'aipkit_content_writer_verify_gsheets',
                ],
                [
                    'class' => '\\WPAICG\\ContentWriter\\Ajax\\Actions\\AIPKit_Content_Writer_Scrape_Url_Action',
                    'action' => 'aipkit_content_writer_scrape_url',
                ],
                [
                    'class' => '\\WPAICG\\Lib\\ContentWriter\\Ajax\\Actions\\AIPKit_Content_Writer_Fetch_Rss_Action',
                    'action' => 'aipkit_content_writer_fetch_rss',
                ],
            ];

            foreach ($ajax_handlers as $handler) {
                aipkit_pro_register_ajax_handler(WPAICG_LIB_DIR . 'content-writer/source-actions.php', $handler['class'], $handler['action']);
            }

            $smart_seo_loader_path = WPAICG_LIB_DIR . 'dependencies.php';
            if (
                aipkit_pro_require_once($smart_seo_loader_path) &&
                class_exists('\\WPAICG\\Lib\\DependencyLoaders\\Smart_SEO_Dependencies_Loader')
            ) {
                \WPAICG\Lib\DependencyLoaders\Smart_SEO_Dependencies_Loader::load();

                aipkit_pro_register_ajax_handler(
                    WPAICG_LIB_DIR . 'content-writer/seo-actions.php',
                    '\\WPAICG\\ContentWriter\\Ajax\\Actions\\AIPKit_Content_Writer_SEO_Audit_Action',
                    'aipkit_content_writer_seo_audit'
                );
                aipkit_pro_register_ajax_handler(
                    WPAICG_LIB_DIR . 'content-writer/seo-actions.php',
                    '\\WPAICG\\ContentWriter\\Ajax\\Actions\\AIPKit_Content_Writer_SEO_Improve_Action',
                    'aipkit_content_writer_seo_improve'
                );
            }
        }, 20);

        aipkit_pro_call_instance_method(
            WPAICG_LIB_DIR . 'admin/assets.php',
            '\\WPAICG\\Lib\\Admin\\Assets\\AIPKit_Content_Writer_Pro_Assets',
            'register_hooks'
        );
    }

    if (!empty($module_settings['ai_forms'])) {
        aipkit_pro_call_instance_method(
            WPAICG_LIB_DIR . 'admin/assets.php',
            '\\WPAICG\\Lib\\Admin\\Assets\\AIPKit_AI_Forms_Pro_Assets',
            'register_hooks'
        );
        aipkit_pro_call_static(
            WPAICG_LIB_DIR . 'ai-forms/workflows.php',
            '\\WPAICG\\Addons\\AIFormsWorkflows\\AIPKit_AI_Forms_Workflows',
            'register_hooks'
        );
    }

    aipkit_pro_call_static(
        WPAICG_LIB_DIR . 'dependencies.php',
        '\\WPAICG\\Lib\\DependencyLoaders\\Triggers_Dependencies_Loader',
        'load'
    );
    aipkit_pro_call_static(
        WPAICG_LIB_DIR . 'dependencies.php',
        '\\WPAICG\\Lib\\DependencyLoaders\\Integrations_Recipes_Dependencies_Loader',
        'load'
    );
    aipkit_pro_call_static(
        WPAICG_LIB_DIR . 'integrations/recipe-runtime.php',
        '\\WPAICG\\Lib\\Integrations\\Recipes\\AIPKit_Recipe_Runtime_Provider',
        'register_hooks'
    );
    aipkit_pro_call_static(
        WPAICG_LIB_DIR . 'integrations/recipe-runtime.php',
        '\\WPAICG\\Lib\\Integrations\\Recipes\\AIPKit_Recipe_Event_Bridge',
        'register_hooks'
    );
    aipkit_pro_call_static(
        WPAICG_LIB_DIR . 'integrations/delivery-maintenance.php',
        '\\WPAICG\\Lib\\Integrations\\Logs\\AIPKit_Recipe_Delivery_Log_Maintenance',
        'register_hooks'
    );
    add_action('init', static function (): void {
        if (!aipkit_pro_is_admin_like_request()) {
            return;
        }

        aipkit_pro_register_ajax_handler(
            WPAICG_LIB_DIR . 'integrations/connection-actions.php',
            '\\WPAICG\\Lib\\Integrations\\Apps\\Ajax\\AIPKit_App_Connections_Ajax_Handler',
            'aipkit_test_app_connection'
        );
        aipkit_pro_register_ajax_handler(
            WPAICG_LIB_DIR . 'integrations/delivery-actions.php',
            '\\WPAICG\\Lib\\Integrations\\Logs\\Ajax\\AIPKit_Recipe_Delivery_Log_Replay_Ajax_Handler',
            'aipkit_replay_recipe_delivery_log'
        );
        aipkit_pro_register_ajax_handler(
            WPAICG_LIB_DIR . 'integrations/delivery-actions.php',
            '\\WPAICG\\Lib\\Integrations\\Logs\\Ajax\\AIPKit_Recipe_Delivery_Log_Clear_Ajax_Handler',
            'aipkit_clear_recipe_delivery_log'
        );
    }, 20);
    aipkit_pro_call_instance_method(
        WPAICG_LIB_DIR . 'admin/assets.php',
        '\\WPAICG\\Lib\\Admin\\Assets\\AIPKit_Trigger_Builder_Assets',
        'register_hooks'
    );

    aipkit_pro_require_class_if_missing(
        WPAICG_PLUGIN_DIR . 'classes/chatbot/ajax-support.php',
        '\\WPAICG\\Chat\\Admin\\Ajax\\BaseAjaxHandler'
    );

    aipkit_pro_require_many([
        WPAICG_LIB_DIR . 'chatbot/uploads.php',
        WPAICG_LIB_DIR . 'knowledge-base/ingestion-settings.php',
        WPAICG_LIB_DIR . 'knowledge-base/file-ingestion.php',
        WPAICG_LIB_DIR . 'chatbot/upload-openai.php',
        WPAICG_LIB_DIR . 'chatbot/upload-vector.php',
        WPAICG_LIB_DIR . 'chatbot/upload-claude.php',
        WPAICG_LIB_DIR . 'chatbot/upload-google.php',
    ]);

    aipkit_pro_require_once(WPAICG_LIB_DIR . 'chatbot/realtime.php');
    aipkit_pro_require_once(WPAICG_LIB_DIR . 'chatbot/live-usage.php');
}
