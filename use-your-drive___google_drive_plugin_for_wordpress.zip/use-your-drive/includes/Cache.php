<?php

/**
 * @author WP Cloud Plugins
 * @copyright Copyright (c) 2023, WP Cloud Plugins
 *
 * @since       2.0
 * @see https://www.wpcloudplugins.com
 */

namespace TheLion\UseyourDrive;

defined('ABSPATH') || exit;

class Cache
{
    /**
     * The single instance of the class.
     *
     * @var Cache
     */
    protected static $_instance;

    /**
     * Set after how much time the cached noded should be refreshed.
     * This value can be overwritten by Cloud Service Cache classes
     * Default:  needed for download/thumbnails urls (1 hour?).
     *
     * @var int
     */
    protected $_max_entry_age = 1800;

    /**
     * Tracks the single shutdown save callback for the active singleton.
     *
     * @var bool
     */
    private static $_shutdown_save_registered = false;

    /**
     * Per-request runtime cache for group version salts.
     *
     * Avoids repeated get_option() lookups during a single request and
     * keeps the version stable within the request even after a bump.
     *
     * @var array<string,string>
     */
    private static $_group_version_runtime = [];

    /**
     * The file name of the requested cache. This will be set in construct.
     *
     * @var string
     */
    private $_cache_name;

    /**
     * Contains the location to the cache file.
     *
     * @var string
     */
    private $_cache_location;

    /**
     * Contains the file handle in case the plugin has to work
     * with a file for unlocking/locking.
     *
     * @var type
     */
    private $_cache_file_handle;

    /**
     * $_nodes contains all the cached files that are present
     * in the Cache File or Database.
     *
     * @var CacheNode[]
     */
    private $_nodes = [];

    /**
     * ID of the root node.
     *
     * @var string
     */
    private $_root_node_id;

    /**
     * Is set to true when a change has been made in the cache.
     * Forcing the plugin to save the cache when needed.
     *
     * @var bool
     */
    private $_updated = false;

    /**
     * $_last_update contains a timestamp of the latest check
     * for new updates.
     *
     * @var array
     */
    private $_last_check_for_update = [];

    /**
     * $_last_id contains an ID of the latest update check
     * This can be anything (e.g. a File ID or Change ID), it differs per Cloud Service.
     *
     * @var array
     */
    private $_last_check_token = [];

    /**
     * How often do we need to poll for changes? (default: 15 minutes)
     * Each Cloud service has its own optimum setting.
     * WARNING: Please don't lower this setting when you are not using your own Apps!!!
     *
     * @var int
     */
    private $_max_change_age = 900;

    public function __construct()
    {
        $cache_id = get_current_blog_id();
        if (null !== App::get_current_account()) {
            $cache_id = App::get_current_account()->get_id();
        }

        $this->_cache_name = Helpers::filter_filename($cache_id, false).'.index';
        $this->_cache_location = USEYOURDRIVE_CACHEDIR.'/'.$this->_cache_name;

        if (false === self::$_shutdown_save_registered) {
            register_shutdown_function(static function (): void {
                if (null !== self::$_instance) {
                    self::$_instance->save_on_shutdown();
                }
            });
            self::$_shutdown_save_registered = true;
        }

        // Load Cache
        $this->load_cache();
    }

    /**
     * Cache Instance.
     *
     * Ensures only one instance is loaded or can be loaded.
     *
     * @return Cache - Cache instance
     *
     * @static
     */
    public static function instance()
    {
        if (is_null(self::$_instance)) {
            self::$_instance = new self();
        }

        return self::$_instance;
    }

    public static function instance_unload()
    {
        if (is_null(self::$_instance)) {
            return;
        }

        self::instance()->update_cache();
        self::$_instance = null;
    }

    public function load_cache()
    {
        $raw = $this->_read_local_cache('close');

        if (empty($raw)) {
            return;
        }

        if (function_exists('gzdecode')) {
            $decoded = @gzdecode($raw);
            if (false === $decoded) {
                Helpers::log_error(
                    'Failed to decode cache file, possibly due to corruption or incompatible format.',
                    'Cache',
                    ['file' => $this->_cache_location],
                    __LINE__
                );
                $this->_nodes = [];

                return;
            }
            $raw = $decoded;
        }

        if (!is_string($raw) || '' === $raw) {
            return;
        }

        $this->_unserialize_cache($raw);

        // Hydrate
        if (!empty($this->_nodes)) {
            foreach ($this->_nodes as $node_data) {
                if (is_array($node_data)) {
                    $this->init_cache_node($node_data);
                }
            }
        }
    }

    public function init_cache_node($node = [])
    {
        if (!is_array($node) || !isset($node['_id'])) {
            return false;
        }

        $id = $node['_id'];

        if (isset($this->_nodes[$id]) && $this->_nodes[$id] instanceof CacheNode) {
            return $this->_nodes[$id];
        }

        $node_obj = $this->_nodes[$id] = new CacheNode($node);

        // Connect Parent
        if ($node_obj->has_parent()) {
            $parent_ref = $node_obj->get_parent();

            if (!$parent_ref instanceof CacheNode) {
                $parent_id = $parent_ref;
                $parent_raw = $this->_nodes[$parent_id] ?? null;

                if ($parent_raw instanceof CacheNode) {
                    $node_obj->set_parent($parent_raw);
                } elseif (is_array($parent_raw)) {
                    $parent_node = $this->init_cache_node($parent_raw);
                    if ($parent_node instanceof CacheNode) {
                        $node_obj->set_parent($parent_node);
                    }
                } else {
                    // Orphan: parent niet in cache → log en behandel als topnode
                    Helpers::log_error(
                        'Orphan node tijdens cache-load (parent ontbreekt)',
                        'Cache',
                        ['node_id' => $id, 'missing_parent' => $parent_id],
                        __LINE__
                    );
                    $node_obj->remove_parent();
                }
            }
        }

        // Connect Children
        if ($node_obj->has_children()) {
            foreach ($node_obj->get_children() as $child) {
                if ($child instanceof CacheNode) {
                    continue;
                }

                $child_id = $child;
                $child_raw = $this->_nodes[$child_id] ?? null;

                if ($child_raw instanceof CacheNode) {
                    $child_raw->set_parent($node_obj);
                } elseif (is_array($child_raw)) {
                    $child_node = $this->init_cache_node($child_raw);
                    if ($child_node instanceof CacheNode) {
                        $child_node->set_parent($node_obj);
                    }
                } else {
                    // Child verwijst naar onbekend id → opruimen
                    $node_obj->remove_child_by_id($child_id);
                }
            }
        }

        return $node_obj;
    }

    public function reset_cache()
    {
        // Invalidate object cache groups via version salts; works on every
        // object cache backend, including those without flush_group support
        // (e.g. Memcached). self::flush_group() also calls
        // wp_cache_flush_group() when the backend supports it.
        self::flush_group('wpcp-'.CORE::$slug.'-nodes');
        self::flush_group('wpcp-'.CORE::$slug.'-entries');

        $this->_nodes = [];
        $this->reset_last_check_for_update();
        $this->reset_last_check_token();
        $this->update_cache();

        return true;
    }

    public function update_cache($clear_request_cache = true)
    {
        if ($this->is_updated() && !empty(App::get_current_account())) {
            // Clear Cached Requests, not needed if we only pulled for updates without receiving any changes
            if ($clear_request_cache && null !== App::get_current_account()) {
                CacheRequest::clear_local_cache_for_shortcode(App::get_current_account()->get_id(), Processor::instance()->get_listtoken());
            }

            // Save each loaded folder
            foreach ($this->get_nodes() as $node) {
                if ($node->is_initialized() && $node->is_dir() && $node->is_updated()) {
                    $node->update_cache();
                }
            }

            // The cache is only marked as saved when writing the file succeeded
            $this->_save_local_cache();
        }
    }

    /**
     * Persist dirty folder nodes and the master cache at shutdown.
     */
    public function save_on_shutdown(): void
    {
        try {
            $error = error_get_last();
            if (null !== $error && E_ERROR === $error['type'] && isset($error['file']) && false !== strpos($error['file'], USEYOURDRIVE_ROOTDIR)) {
                return;
            }

            foreach ($this->get_nodes() as $node) {
                if ($node->is_initialized() && $node->is_dir() && $node->is_updated()) {
                    $node->update_cache();
                }
            }

            /*
             * Only store the cache when this request actually changed something.
             * Requests that merely read the cache would otherwise overwrite the
             * changes that other requests made in the meantime.
             */
            if (false === $this->is_updated()) {
                return;
            }

            $this->_save_local_cache();
        } catch (\Throwable $ex) {
            // Shutdown handlers must never surface cache persistence failures.
        }
    }

    public function is_cached($value, $findby = 'id', $as_parent = false)
    {
        // Find the node by ID/NAME
        $node = null;
        if ('id' === $findby) {
            $node = $this->get_node_by_id($value);
        } elseif ('name' === $findby) {
            $node = $this->get_node_by_name($value);
        }

        // Return if nothing can be found in the cache
        if (empty($node)) {
            return false;
        }

        if (null === $node->get_entry()) {
            return false;
        }

        if (!$as_parent && !$node->is_loaded()) {
            return false;
        }

        // Check if the children of the node are loaded.
        if (!$as_parent && !$node->has_loaded_children()) {
            return false;
        }

        // Check if the requested node is expired
        if (!$as_parent && $node->is_expired()) {
            return false;
        }

        return $node;
    }

    /**
     * @return CacheNode
     */
    public function add_to_cache(EntryAbstract $entry)
    {
        // Check if entry is present in cache
        $cached_node = $this->get_node_by_id($entry->get_id());

        /* If entry is not yet present in the cache,
         * create a new Node
         */
        if (false === $cached_node) {
            $cached_node = $this->add_node($entry);
        }

        if ($cached_node->is_virtual_folder()) {
            $entry->set_name($cached_node->get_name());
        }

        $cached_node->set_name($entry->get_name());

        $cached_node->set_updated();
        $this->set_updated();

        // Set new Expire date
        if ($entry->is_file()) {
            $cached_node->set_expired(time() + $this->get_max_entry_age());
        } else {
            $cached_node->set_is_dir();
        }

        // FIX: FOLDERS SHARED WITH ACCOUNT NOT ALWAYS PROVIDE PARENT INFOMRATION WHEN ITEM ITSELF IS LOADED
        if ('shared-with-me' === $entry->get_parent_id() && $cached_node->has_parent() && 'shared-with-me' !== $cached_node->get_parent()->get_id()) {
            $entry->set_parent_id($cached_node->get_parent()->get_id());
        }
        // END FIX;

        // Preserve sharing permissions fetched earlier; list/changes calls no longer include them
        if ($cached_node->is_initialized()) {
            $old_entry = $cached_node->get_entry();
            if ($old_entry instanceof EntryAbstract
                && empty($entry->get_permission('users'))
                && !empty($old_entry->get_permission('users'))) {
                $entry->set_permissions_by_key('users', $old_entry->get_permission('users'));
            }
        }

        // Set new Entry in node
        $cached_node->set_entry($entry);
        $cached_node->set_loaded(true);

        /*
         * The node contains fresh data now. Mark it as initialized, as its own
         * cache file could have been missing or unreadable when it was loaded.
         * Nodes that aren't initialized are never written to the cache.
         */
        $cached_node->set_initialized(true);

        // Set Loaded_Children to true if entry isn't a folder
        if ($entry->is_file()) {
            $cached_node->set_loaded_children(true);
        }

        // If $entry doesn't have a parent, it is the root or an orphan entry
        if (!$entry->has_parent()) {
            $cached_node->set_parent_found(true);
            $this->set_updated();

            return $cached_node;
        }

        /*
         * If parent of $entry doesn't exist in our cache yet,
         * We need to get it via the API
         */
        $parent_id = $entry->get_parent_id();

        $parent_in_tree = $this->is_cached($parent_id, 'id', 'as_parent');
        if ($parent_in_tree) {
            $cached_node->set_parent($parent_in_tree);
            $parent_in_tree->set_updated();
        } else {
            Client::instance()->get_folder($parent_id, false);
        }

        $cached_node->set_parent_found(true);

        // If entry is a shortcut, make sure that the original file is also present in cache
        if ($entry->is_shortcut()) {
            $target_id = $entry->get_shortcut_details('targetId');

            $cached_node->set_original_node_id($target_id);

            $shortcut_node = $this->get_node_by_id($target_id);
            if (false === $shortcut_node || null === $shortcut_node->get_entry()) {
                // Try to find the original node.
                $result = Client::instance()->get_entry($target_id, false);

                if (empty($result)) {
                    // It is possible that the shortcut is pointing to a removed file.
                    // In that case make the node inaccessible
                    $this->remove_from_cache($entry->get_id(), 'deleted');
                    Helpers::log_error('Shortcut points to a removed file', 'Cache', ['entry' => $entry->get_id()], __LINE__);

                    $this->set_updated();

                    // Return the cached Node
                    return $cached_node;
                }
                $shortcut_node = $this->get_node_by_id($target_id);
            }

            // Use Thumbnails from original file
            $entry->set_icon($shortcut_node->get_entry()->get_icon());
            $entry->set_thumbnail_icon($shortcut_node->get_entry()->get_thumbnail_icon());
            $entry->set_thumbnail_small($shortcut_node->get_entry()->get_thumbnail_small());
            $entry->set_thumbnail_small_cropped($shortcut_node->get_entry()->get_thumbnail_small_cropped());
            $entry->set_thumbnail_large($shortcut_node->get_entry()->get_thumbnail_large());
            $entry->set_thumbnail_original($shortcut_node->get_entry()->get_thumbnail_original());
            $cached_node->set_entry($entry);

            $shortcut_node->add_original_node_for([$entry->get_id()]);
        }

        $this->set_updated();

        // Return the cached Node
        return $cached_node;
    }

    public function remove_from_cache($entry_id, $reason = 'update')
    {
        $node = $this->get_node_by_id($entry_id);

        if (false === $node) {
            return false;
        }

        $node->set_updated();

        if ('update' === $reason) {
            $node->remove_parent();
        } elseif ('moved' === $reason) {
            $node->remove_parent();
        } elseif ('deleted' === $reason) {
            $node->remove_parent();
            $node->delete_cache();
            unset($this->_nodes[$entry_id]);
        }

        $this->set_updated();

        return true;
    }

    /**
     * @return bool|CacheNode
     */
    public function get_root_node()
    {
        if (0 === count($this->get_nodes())) {
            return false;
        }

        return $this->get_node_by_id($this->get_root_node_id());
    }

    public function get_root_node_id()
    {
        return $this->_root_node_id;
    }

    public function set_root_node_id($id)
    {
        return $this->_root_node_id = $id;
    }

    public function get_node_by_id($id, $loadoninit = true)
    {
        if (!isset($this->_nodes[$id])) {
            return false;
        }

        if ($loadoninit && !$this->_nodes[$id]->is_initialized() && $this->_nodes[$id]->is_dir()) {
            $this->_nodes[$id]->load();
        }

        return $this->_nodes[$id];
    }

    public function get_node_by_name($search_name, $parent = null)
    {
        if (!$this->has_nodes()) {
            return false;
        }

        $search_name = apply_filters('useyourdrive_cache_node_by_name_set_search_name', $search_name, $this);

        $parent_id = ($parent instanceof CacheNode) ? $parent->get_id() : $parent;

        /**
         * @var CacheNode $node
         */
        foreach ($this->_nodes as $node) {
            $node_name = apply_filters('useyourdrive_cache_node_by_name_set_node_name', $node->get_name(), $this);

            if ($node_name === $search_name) {
                if (null === $parent) {
                    return $node;
                }

                if ($node->is_in_folder($parent_id)) {
                    return $node;
                }
            }
        }

        return false;
    }

    public function get_drive_id_by_entry_id($entry_id)
    {
        $node = $this->get_node_by_id($entry_id);

        if (false === $node) {
            return null;
        }

        if (null !== $node->get_drive_id()) {
            return $node->get_drive_id();
        }

        if ($node->has_parent()) {
            return $this->get_drive_id_by_entry_id($node->get_parent()->get_id());
        }

        return null;
    }

    public function get_shortcut_nodes_by_id($id)
    {
        $shortcut_nodes = [];
        foreach ($this->_nodes as $node) {
            if ($id === $node->get_original_node_id()) {
                $shortcut_nodes[] = $node;
            }
        }

        return $shortcut_nodes;
    }

    public function has_nodes()
    {
        return count($this->_nodes) > 0;
    }

    /**
     * @return CacheNode[]
     */
    public function get_nodes()
    {
        return $this->_nodes;
    }

    public function add_node(EntryAbstract $entry)
    {
        $cached_node = new CacheNode(
            [
                '_id' => $entry->get_id(),
                '_drive_id' => $entry->get_drive_id(),
                '_account_id' => App::get_current_account()->get_id(),
                '_name' => $entry->get_name(),
                '_initialized' => true,
            ]
        );

        return $this->set_node($cached_node);
    }

    public function set_node(CacheNode $node)
    {
        $id = $node->get_id();
        $this->_nodes[$id] = $node;

        return $this->_nodes[$id];
    }

    public function pull_for_changes($folder_id, $force_update = false, $buffer = 10)
    {
        $force = (defined('FORCE_REFRESH') ? true : $force_update);

        if (empty($folder_id)) {
            $folder_id = Processor::instance()->get_shortcode_option('root');
        }

        $drive_id = $this->get_drive_id_by_entry_id($folder_id);

        // Skip check for changes for specific actions
        $action = isset($_REQUEST['action']) ? sanitize_key((string) $_REQUEST['action']) : '';
        if (in_array($action, ['useyourdrive-create-zip'], true)) {
            return true;
        }

        // Check if we need to check for updates
        $current_time = time();
        $last_check_time = $this->get_last_check_for_update($drive_id);
        $update_needed = ($last_check_time + $this->get_max_change_age());

        if (($current_time < $update_needed) && !$force) {
            return true;
        }

        if (true === $force && ($last_check_time > $current_time - $buffer)) {
            // Don't pull again if the request was within $buffer seconds
            return true;
        }

        // Reset Cache if the last time we used this cache is more than a day ago
        if (!empty($last_check_time) && $last_check_time < ($current_time - 60 * 60 * 24)) {
            Processor::reset_complete_cache(false);
            $this->set_last_check_for_update($drive_id);

            $this->update_cache();

            return true;
        }

        if (in_array($drive_id, ['drive', null])) {
            // Reset the complete Drive cache including shared folders and shared with me
            if ($force) {
                Processor::reset_complete_cache(false);
            }

            $this->set_last_check_for_update($drive_id);

            $this->update_cache();

            return true;
        }

        if (!$this->_create_local_lock(LOCK_EX | LOCK_NB)) {
            return false;
        }

        $result = Client::instance()->get_changes($drive_id, $this->get_last_check_token($drive_id));

        if (empty($result)) {
            return false;
        }

        $this->set_last_check_token($drive_id, $result['new_change_token']);
        $this->set_last_check_for_update($drive_id);

        if (is_array($result['changes']) && count($result['changes']) > 0) {
            $this->_process_changes($result['changes']);

            if (!defined('HAS_CHANGES')) {
                define('HAS_CHANGES', true);
            }

            $this->update_cache();

            return true;
        }

        $this->update_cache(false);

        return true;
    }

    public function is_updated()
    {
        return $this->_updated;
    }

    public function set_updated($value = true)
    {
        $this->_updated = (bool) $value;

        return $this->_updated;
    }

    public function get_cache_name()
    {
        return $this->_cache_name;
    }

    public function get_cache_location()
    {
        return $this->_cache_location;
    }

    public function get_last_check_for_update($drive_id)
    {
        $key = (string) $drive_id;

        return $this->_last_check_for_update[$key] ?? null;
    }

    public function reset_last_check_for_update()
    {
        $this->_last_check_for_update = [];
        $this->set_updated();
    }

    public function set_last_check_for_update($drive_id)
    {
        $this->_last_check_for_update[(string) $drive_id] = time();
        $this->set_updated();

        return $this->_last_check_for_update[(string) $drive_id];
    }

    public function reset_last_check_token()
    {
        $this->_last_check_token = [];
        $this->set_updated();
    }

    public function get_last_check_token($drive_id)
    {
        if (!isset($this->_last_check_token[(string) $drive_id])) {
            $this->_last_check_token[(string) $drive_id] = null;
        }

        return $this->_last_check_token[(string) $drive_id];
    }

    public function set_last_check_token($drive_id, $token)
    {
        $this->_last_check_token[(string) $drive_id] = $token;

        return $this->_last_check_token[(string) $drive_id];
    }

    public function get_max_entry_age()
    {
        return $this->_max_entry_age;
    }

    public function set_max_entry_age($value)
    {
        return $this->_max_entry_age = $value;
    }

    public function get_max_change_age()
    {
        return $this->_max_change_age;
    }

    public function set_max_change_age($value)
    {
        return $this->_max_change_age = $value;
    }

    /**
     * Get the current version salt for an object cache group.
     *
     * The salt is persisted as a WordPress option (autoload = false) so it
     * survives across requests on backends that cannot flush by group
     * (e.g. Memcached). It is included in every cache key built via
     * self::build_key(), which means bumping the salt instantly invalidates
     * every entry that belonged to the group.
     *
     * @param string $group object cache group name (e.g. 'wpcp-use-your-drive-entries')
     *
     * @return string version salt to embed in cache keys
     */
    public static function get_group_version($group)
    {
        if (isset(self::$_group_version_runtime[$group])) {
            return self::$_group_version_runtime[$group];
        }

        $option_key = 'wpcp_cache_ver_'.md5($group);
        $version = \get_option($option_key, false);

        if (false === $version || '' === $version) {
            $version = (string) microtime(true);
            // autoload = false: salts must not be loaded on every page request.
            \update_option($option_key, $version, false);
        }

        return self::$_group_version_runtime[$group] = $version;
    }

    /**
     * Invalidate every cache entry that belongs to a group.
     *
     * The correctness mechanism is the version bump, which makes every
     * future call to self::build_key() produce a new key. As an additional
     * optimization, wp_cache_flush_group() is invoked when the active
     * object cache backend supports it, so old keys are released
     * immediately instead of expiring via TTL.
     *
     * @param string $group object cache group name
     */
    public static function flush_group($group)
    {
        $option_key = 'wpcp_cache_ver_'.md5($group);
        $new_version = (string) microtime(true);
        \update_option($option_key, $new_version, false);
        self::$_group_version_runtime[$group] = $new_version;

        // Optimization: actively drop old keys on backends that support it.
        if (\function_exists('wp_cache_supports') && \wp_cache_supports('flush_group')) {
            \wp_cache_flush_group($group);
        }
    }

    /**
     * Build a salted cache key for a given group.
     *
     * Always use this helper when calling wp_cache_get()/wp_cache_set() so
     * that group invalidation via self::flush_group() works on every
     * object cache backend, including ones without flush_group support.
     *
     * @param string $group   object cache group name
     * @param string $raw_key the unsalted key identifying the data
     *
     * @return string salted cache key
     */
    public static function build_key($group, $raw_key)
    {
        return self::get_group_version($group).':'.$raw_key;
    }

    /**
     * Invalidate the entries cache for this plugin instance.
     *
     * Convenience wrapper used by mutation paths (uploads, deletions,
     * hard refresh) so callers do not need to know the full group name.
     */
    public static function invalidate_entries()
    {
        self::flush_group('wpcp-'.CORE::$slug.'-entries');
    }

    protected function _read_local_cache($close = false)
    {
        $handle = $this->_get_cache_file_handle();
        if (empty($handle)) {
            $this->_create_local_lock(LOCK_SH);
        }

        // Clear PHP’s stat cache so filesize() is up-to-date
        clearstatcache();
        rewind($this->_get_cache_file_handle());

        $contents = '';

        // Read until end-of-file in 8 192-byte chunks
        while (filesize($this->get_cache_location()) > 0 && !feof($this->_get_cache_file_handle())) {
            // If we are reaching our memory limit, clear the cache file and return empty
            if (Helpers::is_close_to_memory_limit()) {
                $this->reset_cache();
                Helpers::log_error('Reached memory limit when reading cache file, clearing cache file', 'Cache', ['file' => $this->get_cache_location()], __LINE__);

                $contents = '';

                break;
            }

            $chunk = fread($this->_get_cache_file_handle(), 8192);
            if (false === $chunk) {
                // sth went wrong—break out and return what we have
                break;
            }
            $contents .= $chunk;
        }

        if (false !== $close) {
            $this->_unlock_local_cache();
        }

        return $contents;
    }

    protected function _create_local_lock($type)
    {
        // Check if file exists
        $file = $this->get_cache_location();

        if (!file_exists($file)) {
            @file_put_contents($file, $this->_serialize_cache());

            if (!is_writable($file)) {
                Helpers::log_error('Cache file is not writable', 'Cache', ['file' => $file], __LINE__);

                return false;
            }
        }

        // Check if the file is more than 1 minute old.
        $requires_unlock = ((filemtime($file) + 60) < time());

        // Temporarily workaround when flock is disabled. Can cause problems when plugin is used in multiple processes
        $flock_disabled = (false !== strpos(ini_get('disable_functions'), 'flock'));
        if ($flock_disabled) {
            $requires_unlock = false;
        }

        // Check if file is already opened and locked in this process
        $handle = $this->_get_cache_file_handle();
        if (empty($handle)) {
            $handle = fopen($file, 'c+');
            if (!is_resource($handle)) {
                Helpers::log_error('Cache file is not writable', 'Cache', ['file' => $file], __LINE__);

                return false;
            }
            $this->_set_cache_file_handle($handle);
        }

        Helpers::set_time_limit(60);

        if (!flock($this->_get_cache_file_handle(), $type)) {
            /*
             * If the file cannot be unlocked and the last time
             * it was modified was 1 minute, assume that
             * the previous process died and unlock the file manually
             */
            if ($requires_unlock) {
                $this->_unlock_local_cache();
                $handle = fopen($file, 'c+');

                if (!is_resource($handle)) {
                    Helpers::log_error('Cache file cannot be reopened', 'Cache', ['file' => $file], __LINE__);

                    return false;
                }

                $this->_set_cache_file_handle($handle);
            } elseif (false === $flock_disabled) {
                return false;
            }
            // Try to lock the file again
            if (!flock($this->_get_cache_file_handle(), $type)) {
                Helpers::log_error('Lock not obtained after retry', 'Cache', ['file' => $file], __LINE__);

                return false;
            }
        }
        Helpers::set_time_limit(60);

        touch($file);

        return true;
    }

    protected function _save_local_cache()
    {
        $data = $this->_serialize_cache();
        if (false === $data || '' === $data) {
            return false;
        }

        if (!$this->_create_local_lock(LOCK_EX)) {
            return false;
        }

        $handle = $this->_get_cache_file_handle();
        if (empty($handle)) {
            return false;
        }

        ftruncate($handle, 0);
        rewind($handle);
        fwrite($handle, $data);

        $this->_unlock_local_cache();
        $this->set_updated(false);

        return true;
    }

    protected function _unlock_local_cache()
    {
        $handle = $this->_get_cache_file_handle();
        if (!empty($handle)) {
            flock($this->_get_cache_file_handle(), LOCK_UN);
            fclose($this->_get_cache_file_handle());
            $this->_set_cache_file_handle(null);
        }

        clearstatcache();

        return true;
    }

    protected function _set_cache_file_handle($handle)
    {
        return $this->_cache_file_handle = $handle;
    }

    protected function _get_cache_file_handle()
    {
        return $this->_cache_file_handle;
    }

    private function _process_changes($changes = [])
    {
        foreach ($changes as $entry_id => $change) {
            if ('deleted' === $change) {
                $this->remove_from_cache($entry_id, 'deleted');
            } else {
                $this->remove_from_cache($entry_id, 'update');
                // Update cache with new entry
                if ($change instanceof EntryAbstract) {
                    $this->add_to_cache($change);
                }
            }
        }

        $this->set_updated(true);
    }

    private function _serialize_cache()
    {
        $nodes_index = [];
        foreach ($this->_nodes as $id => $node) {
            $nodes_index[$id] = $node->to_index();
        }

        $data = [
            '_nodes' => $nodes_index,
            '_root_node_id' => $this->_root_node_id,
            '_last_check_token' => $this->_last_check_token,
            '_last_check_for_update' => $this->_last_check_for_update,
        ];

        $data_str = json_encode($data);

        if (function_exists('gzencode')) {
            $data_str = gzencode($data_str);
        }

        return $data_str;
    }

    private function _unserialize_cache($data)
    {
        if (!is_string($data) || '' === $data) {
            return;
        }

        $values = json_decode($data, true);
        if (JSON_ERROR_NONE !== json_last_error() || !is_array($values)) {
            return;
        }

        $allowed = [
            '_nodes',
            '_root_node_id',
            '_last_check_token',
            '_last_check_for_update',
        ];

        foreach ($values as $key => $value) {
            if (!in_array($key, $allowed, true)) {
                continue;
            }

            if ('_nodes' === $key) {
                if (!is_array($value)) {
                    continue;
                }
                $clean = [];
                foreach ($value as $node_id => $raw) {
                    if (is_array($raw) && isset($raw['_id'])) {
                        $clean[$node_id] = $raw;
                    }
                }
                $this->_nodes = $clean;

                continue;
            }

            if (is_scalar($value) || is_array($value) || null === $value) {
                $this->{$key} = $value;
            }
        }

        unset($data, $values);
    }
}
