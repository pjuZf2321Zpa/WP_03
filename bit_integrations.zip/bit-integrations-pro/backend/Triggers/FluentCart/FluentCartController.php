<?php

namespace BitApps\IntegrationsPro\Triggers\FluentCart;

use BitApps\IntegrationsPro\Config;

final class FluentCartController
{
    public static function info()
    {
        return [
            'name'              => 'FluentCart',
            'type'              => 'custom_form_submission',
            'is_active'         => self::isPluginInstalled(),
            'documentation_url' => 'https://bit-integrations.com/wp-docs/trigger/fluentcart-integrations/',
            'tutorial_url'      => '#',
            'tasks'             => [
                'action' => 'fluent-cart/get',
                'method' => 'get',
            ],
            'fetch' => [
                'action' => 'trigger/test',
                'method' => 'post',
            ],
            'fetch_remove' => [
                'action' => 'trigger/test/remove',
                'method' => 'post',
            ],
            'isPro' => true
        ];
    }

    public function getAllTasks()
    {
        if (!self::isPluginInstalled()) {
            wp_send_json_error(\sprintf(__('%s is not installed or activated', 'bit-integrations-pro'), 'FluentCart'));
        }

        wp_send_json_success(StaticData::tasks());
    }

    public static function productPurchased($data)
    {
        if (empty($data['cart']) || empty($data['order'])) {
            return;
        }

        $data['cart'] = $data['cart']->toArray();
        $data['order'] = $data['order']->toArray();

        return self::flowExecute('fluent_cart/checkout/prepare_other_data', $data);
    }

    public static function productUpdated($data)
    {
        if (empty($data['product'])) {
            return;
        }

        $data['product'] = $data['product']->toArray();

        return self::flowExecute('fluent_cart/product_updated', $data);
    }

    public static function productStockUpdated($data)
    {
        if (empty($data['product'])) {
            return;
        }

        $data['product'] = $data['product']->toArray();

        return self::flowExecute('fluent_cart/product_stock_changed', $data);
    }

    public static function couponCreated($data)
    {
        if (empty($data['coupon'])) {
            return;
        }

        $data['coupon'] = $data['coupon']->toArray();

        return self::flowExecute('fluent_cart/coupon_created', $data);
    }

    public static function couponUpdated($data)
    {
        if (empty($data['coupon'])) {
            return;
        }

        $data['coupon'] = $data['coupon']->toArray();

        return self::flowExecute('fluent_cart/coupon_updated', $data);
    }

    public static function cartItemAdded($data)
    {
        return self::executeCartTriggers('fluent_cart/cart/item_added', $data);
    }

    public static function cartItemRemoved($data)
    {
        return self::executeCartTriggers('fluent_cart/cart/item_removed', $data);
    }

    public static function cartItemsUpdated($data)
    {
        return self::executeCartTriggers('fluent_cart/cart/cart_data_items_updated', $data);
    }

    public static function cartUpdated($data)
    {
        if (empty($data['cart'])) {
            return;
        }

        $data['cart'] = $data['cart']->toArray();

        return self::flowExecute('fluent_cart/checkout/cart_amount_updated', $data);
    }

    public static function cartCompleted($data)
    {
        if (empty($data['cart']) || empty($data['order'])) {
            return;
        }

        $data['cart'] = $data['cart']->toArray();
        $data['order'] = $data['order']->toArray();

        return self::flowExecute('fluent_cart/cart_completed', $data);
    }

    public static function orderReceiptRendered($data)
    {
        if (empty($data['order'])) {
            return;
        }

        $data['order'] = $data['order']->toArray();
        $data['order_operation'] = isset($data['order_operation']) ? $data['order_operation']->toArray() : [];

        return self::flowExecute('fluent_cart/after_receipt', $data);
    }

    public static function orderCreated($data)
    {
        return self::executeOrderPaymentTrigger('fluent_cart/order_created', $data);
    }

    public static function orderUpdated($data)
    {
        if (empty($data['order'])) {
            return;
        }

        $data['order'] = $data['order']->toArray();
        $data['old_order'] = isset($data['old_order']) ? $data['old_order']->toArray() : [];

        return self::flowExecute('fluent_cart/order_updated', $data);
    }

    public static function orderDeleted($data)
    {
        if (empty($data['order'])) {
            return;
        }

        $data['order'] = $data['order']->toArray();
        $data['customer'] = isset($data['customer']) ? $data['customer']->toArray() : [];

        return self::flowExecute('fluent_cart/order_deleted', $data);
    }

    public static function orderRefunded($data)
    {
        return self::executeOrderPaymentTrigger('fluent_cart/order_refunded', $data);
    }

    public static function orderPartiallyRefunded($data)
    {
        return self::executeOrderPaymentTrigger('fluent_cart/order_partially_refunded', $data);
    }

    public static function orderFullyRefunded($data)
    {
        return self::executeOrderPaymentTrigger('fluent_cart/order_fully_refunded', $data);
    }

    public static function orderCancelled($data)
    {
        return self::executeOrderStatusTrigger('fluent_cart/order_status_changed_to_canceled', $data);
    }

    public static function orderStatusChanged($data)
    {
        return self::executeOrderStatusTrigger('fluent_cart/order_status_changed', $data);
    }

    public static function orderStatusUpdatedToProcessing($data)
    {
        return self::executeOrderStatusTrigger('fluent_cart/order_status_changed_to_processing', $data);
    }

    public static function orderStatusUpdatedToCompleted($data)
    {
        return self::executeOrderStatusTrigger('fluent_cart/order_status_changed_to_completed', $data);
    }

    public static function orderStatusUpdatedToOnHold($data)
    {
        return self::executeOrderStatusTrigger('fluent_cart/order_status_changed_to_on-hold', $data);
    }

    public static function orderShippingStatusChanged($data)
    {
        return self::executeOrderStatusTrigger('fluent_cart/shipping_status_changed', $data);
    }

    public static function orderShipped($data)
    {
        return self::executeOrderStatusTrigger('fluent_cart/shipping_status_changed_to_shipped', $data);
    }

    public static function orderUnshipped($data)
    {
        return self::executeOrderStatusTrigger('fluent_cart/shipping_status_changed_to_unshipped', $data);
    }

    public static function orderUnshippable($data)
    {
        return self::executeOrderStatusTrigger('fluent_cart/shipping_status_changed_to_unshippable', $data);
    }

    public static function orderDelivered($data)
    {
        return self::executeOrderStatusTrigger('fluent_cart/shipping_status_changed_to_delivered', $data);
    }

    public static function orderMarkedAsPaid($data)
    {
        return self::executeOrderStatusTrigger('fluent_cart/order_paid_done', $data);
    }

    public static function orderCustomerChanged($data)
    {
        if (empty($data['order']) || empty($data['old_customer']) || empty($data['new_customer'])) {
            return;
        }

        $data['order'] = $data['order']->toArray();
        $data['old_customer'] = $data['old_customer']->toArray();
        $data['new_customer'] = $data['new_customer']->toArray();

        return self::flowExecute('fluent_cart/order_customer_changed', $data);
    }

    public static function customerCreated($userId)
    {
        $userInfo = self::getUserInfo($userId);

        return self::flowExecute('fluent_cart/user/after_register', $userInfo);
    }

    public static function getUserInfo($user_id)
    {
        $userInfo = get_userdata($user_id);
        $user = [];
        if ($userInfo) {
            $userData = $userInfo->data;
            $user_meta = get_user_meta($user_id);
            $user = [
                'user_id'    => $user_id,
                'first_name' => isset($user_meta['first_name'][0]) ? $user_meta['first_name'][0] : '',
                'last_name'  => isset($user_meta['last_name'][0]) ? $user_meta['last_name'][0] : '',
                'user_email' => $userData->user_email,
                'nickname'   => $userData->user_nicename,
                'avatar_url' => get_avatar_url($user_id),
            ];
        }

        return $user;
    }

    private static function executeOrderStatusTrigger($entityId, $data)
    {
        if (empty($data['order'])) {
            return;
        }

        $data['order'] = $data['order']->toArray();

        return self::flowExecute($entityId, $data);
    }

    private static function executeOrderPaymentTrigger($entityId, $data)
    {
        if (empty($data['order']) || empty($data['customer']) || empty($data['transaction'])) {
            return;
        }

        $data['order'] = $data['order']->toArray();
        $data['customer'] = $data['customer']->toArray();
        $data['transaction'] = $data['transaction']->toArray();

        return self::flowExecute($entityId, $data);
    }

    private static function executeCartTriggers($entityId, $data)
    {
        if (empty($data['cart'])) {
            return;
        }

        $data['cart'] = $data['cart']->toArray();

        return self::flowExecute($entityId, $data);
    }

    private static function flowExecute($entityId, $data)
    {
        $helperClass = bit_integrations_get_class('Core\\Util\\Helper');
        $flowClass = bit_integrations_get_class('Flow\\Flow');

        $formData = $helperClass::prepareFetchFormatFields($data);

        if (empty($formData) || !\is_array($formData)) {
            return;
        }

        $helperClass::setTestData(Config::withFreePrefix("{$entityId}_test"), array_values($formData));

        $flows = $flowClass::exists('FluentCart', $entityId);

        if (!$flows) {
            return;
        }

        $data = array_column($formData, 'value', 'name');

        $flowClass::execute('FluentCart', $entityId, $data, $flows);

        return ['type' => 'success'];
    }

    private static function isPluginInstalled()
    {
        return \defined('FLUENTCART_PLUGIN_PATH');
    }
}
