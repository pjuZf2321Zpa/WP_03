<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Core\Util\Hooks;
use BitApps\IntegrationsPro\Triggers\BookingsAndAppointmentsForWoocommerce\BookingsAndAppointmentsForWoocommerceController;

Hooks::add('ph_booking_status_changed', [BookingsAndAppointmentsForWoocommerceController::class, 'handleStatusChanged'], 20, 3);
Hooks::add('ph_booking_details_updated', [BookingsAndAppointmentsForWoocommerceController::class, 'handleDetailsUpdated'], 20, 4);
Hooks::add('ph_booking_order_items_modified', [BookingsAndAppointmentsForWoocommerceController::class, 'handleItemsModified'], 20, 2);
Hooks::add('ph_bookings_reminder_schedule_for_item', [BookingsAndAppointmentsForWoocommerceController::class, 'handleBookingCreated'], 20, 2);
Hooks::add('ph_bookings_process_bulk_action', [BookingsAndAppointmentsForWoocommerceController::class, 'handleBulkActionProcessed'], 20, 2);
// Most bulk actions redirect and exit before ph_bookings_process_bulk_action fires; the notice transient they set first is the reliable signal.
Hooks::add('setted_transient', [BookingsAndAppointmentsForWoocommerceController::class, 'handleBulkNoticeTransient'], 20, 2);
Hooks::add('ph_bookings_bulk_icalendar_download', [BookingsAndAppointmentsForWoocommerceController::class, 'handleBulkIcalendarDownloaded'], 20, 1);
Hooks::add('ph_booking_payment_processed', [BookingsAndAppointmentsForWoocommerceController::class, 'handlePaymentProcessed'], 20, 1);
Hooks::add('ph_booking_payment_audit', [BookingsAndAppointmentsForWoocommerceController::class, 'handlePaymentAudit'], 20, 3);
Hooks::add('ph_woocommerce_order_status_failed', [BookingsAndAppointmentsForWoocommerceController::class, 'handleOrderFailed'], 20, 1);
Hooks::add('ph_zoom_create_meeting_for_paid_order', [BookingsAndAppointmentsForWoocommerceController::class, 'handlePaidBookingReadyForMeeting'], 20, 3);
Hooks::add('ph_booking_item_calender_resynced', [BookingsAndAppointmentsForWoocommerceController::class, 'handleCalendarResynced'], 20, 3);
Hooks::add('ph_bookings_order_created_from_google_calendar', [BookingsAndAppointmentsForWoocommerceController::class, 'handleCreatedFromGoogleCalendar'], 20, 2);
Hooks::add('ph_booking_google_calender_sync_for_admin_bookings', [BookingsAndAppointmentsForWoocommerceController::class, 'handleAdminGoogleCalendarSynced'], 20, 1);
Hooks::add('ph_bookings_insert_data_in_availability_table_from_cart', [BookingsAndAppointmentsForWoocommerceController::class, 'handleAddedToCart'], 20, 1);
