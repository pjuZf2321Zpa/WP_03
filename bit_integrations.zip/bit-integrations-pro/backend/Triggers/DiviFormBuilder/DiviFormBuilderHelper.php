<?php

namespace BitApps\IntegrationsPro\Triggers\DiviFormBuilder;

class DiviFormBuilderHelper
{
    public static function isPrimaryKeysMatch($postArray, $flowDetails, $formIdField)
    {
        $helperClass = bit_integrations_get_class('Core\\Util\\Helper');

        $recordData = self::prepareDataForFlow($postArray, $formIdField);

        foreach ($flowDetails->primaryKey as $primaryKey) {
            $valueFromPath = $helperClass::extractValueFromPath($recordData, $primaryKey->key, 'DiviFormBuilder');

            if (\is_array($valueFromPath)) {
                $valueFromPath = $valueFromPath['value'];
            }

            if ($primaryKey->value != $valueFromPath) {
                return false;
            }
        }

        return true;
    }

    public static function prepareDataForFlow($postArray, $formIdField)
    {
        if (\is_array($postArray['field_name']) && \count($postArray['field_name']) === 0 && key_exists('meta_input', $postArray)) {
            return array_merge($postArray['meta_input'], $formIdField);
        }

        $fieldNames = $postArray['field_name'] ?? array_map('strtolower', $postArray['field_title']);
        $data = [];

        foreach ($fieldNames as $name) {
            $valueKey = str_replace('de_fb_', '', $name);
            $value = $postArray[$valueKey] ?? '';

            if (\is_array($value)) {
                $value = implode(',', $postArray[$valueKey]);
            } else {
                $explodeValue = explode(',', $value ?? '');
                $attachmentUrls = [];

                if (is_numeric($explodeValue[0])) {
                    foreach ($explodeValue as $item) {
                        $url = wp_get_attachment_url($item);
                        if ($url) {
                            $attachmentUrls[] = $url;
                        }
                    }

                    if (\count($explodeValue) === \count($attachmentUrls)) {
                        $value = $attachmentUrls;
                    }
                }
            }

            $data[$name] = $value;
        }

        return array_merge($data, $formIdField);
    }

    public static function setFields($formId, $postArray)
    {
        $allFields = [
            ['name' => 'id', 'type' => 'text', 'label' => __('Form Id', 'bit-integrations-pro') . " ({$formId})", 'value' => $formId]
        ];

        if (\is_array($postArray['field_name']) && \count($postArray['field_name']) === 0 && key_exists('meta_input', $postArray)) {
            foreach ($postArray['meta_input'] as $key => $value) {
                $label = array_filter($postArray['field_title'], function ($title) use ($key) {
                    return strtolower($title) === str_replace('de_fb_', '', $key);
                });

                $allFields[] = [
                    'name'  => $key,
                    'type'  => 'text',
                    'label' => (isset($label[0]) ? $label[0] : $key) . " ({$value})",
                    'value' => $value
                ];
            }

            return $allFields;
        }

        $fieldTitles = $postArray['field_title'];
        $fieldName = $postArray['field_name'] ?? array_map('strtolower', $fieldTitles);

        foreach ($fieldTitles as $key => $title) {
            $valueKey = str_replace('de_fb_', '', $fieldName[$key]);
            $value = $postArray[$valueKey] ?? '';

            if (\is_array($value)) {
                $value = implode(',', $postArray[$valueKey]);
            } else {
                $explodeValue = explode(',', $value ?? '');
                $attachmentUrls = [];

                if (is_numeric($explodeValue[0])) {
                    foreach ($explodeValue as $item) {
                        $url = wp_get_attachment_url($item);
                        if ($url) {
                            $attachmentUrls[] = $url;
                        }
                    }

                    if (\count($explodeValue) === \count($attachmentUrls)) {
                        $value = $attachmentUrls;
                    }
                }
            }

            $allFields[] = [
                'name'  => $fieldName[$key],
                'type'  => 'text',
                'label' => (!\is_null($title) ? $title : $fieldName[$key]) . " ({$value})",
                'value' => $value
            ];
        }

        return $allFields;
    }

    public static function isPluginInstalled()
    {
        return is_plugin_active('divi-form-builder/divi-form-builder.php');
    }
}
