<?php

namespace BitApps\IntegrationsPro\Triggers\FluentAffiliate;

class StaticData
{
    public static function forms()
    {
        return [
            [
                'form_name'           => __('Affiliate Created', 'bit-integrations-pro'),
                'triggered_entity_id' => 'fluent_affiliate/affiliate_created',
                'skipPrimaryKey'      => true,
            ],
            [
                'form_name'           => __('Affiliate Updated', 'bit-integrations-pro'),
                'triggered_entity_id' => 'fluent_affiliate/affiliate_updated',
                'skipPrimaryKey'      => true,
            ],
            [
                'form_name'           => __('Affiliate Approved Or Activated', 'bit-integrations-pro'),
                'triggered_entity_id' => 'fluent_affiliate/affiliate_status_to_active',
                'skipPrimaryKey'      => true,
            ],
            [
                'form_name'           => __('Affiliate Pending', 'bit-integrations-pro'),
                'triggered_entity_id' => 'fluent_affiliate/affiliate_status_to_pending',
                'skipPrimaryKey'      => true,
            ],
            [
                'form_name'           => __('Affiliate Inactivate Or Deactivated', 'bit-integrations-pro'),
                'triggered_entity_id' => 'fluent_affiliate/affiliate_status_to_inactive',
                'skipPrimaryKey'      => true,
            ],
            [
                'form_name'           => __('Affiliate Deleted', 'bit-integrations-pro'),
                'triggered_entity_id' => 'fluent_affiliate/before_delete_affiliate',
                'skipPrimaryKey'      => true,
            ],
            [
                'form_name'           => __('Referral Created', 'bit-integrations-pro'),
                'triggered_entity_id' => 'fluent_affiliate/referral_created',
                'skipPrimaryKey'      => true,
            ],
            [
                'form_name'           => __('Referral Deleted', 'bit-integrations-pro'),
                'triggered_entity_id' => 'fluent_affiliate/referral/before_delete',
                'skipPrimaryKey'      => true,
            ],
        ];
    }
}
