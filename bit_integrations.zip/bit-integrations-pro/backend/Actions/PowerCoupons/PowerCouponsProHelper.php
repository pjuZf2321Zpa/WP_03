<?php

namespace BitApps\IntegrationsPro\Actions\PowerCoupons;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Power Coupons write actions (Pro). Free fires the hooks, the logic lives here.
 */
final class PowerCouponsProHelper
{
    private static $datePattern = '/^\d{4}-\d{2}-\d{2}$/';

    public static function createCoupon($defaultResponse, $fieldData, $integrationDetails = null)
    {
        if ($error = self::guard()) {
            return $error;
        }

        $code = self::couponCode(isset($fieldData['code']) ? $fieldData['code'] : '');

        if ($code === '') {
            return self::errorResponse(__('Coupon code is required', 'bit-integrations-pro'));
        }

        if (wc_get_coupon_id_by_code($code)) {
            return self::errorResponse(__('A coupon with this code already exists', 'bit-integrations-pro'));
        }

        foreach (['discount_type', 'amount'] as $required) {
            if (!isset($fieldData[$required]) || $fieldData[$required] === '') {
                // translators: %s is the missing field name.
                return self::errorResponse(sprintf(__('%s is required to create a coupon', 'bit-integrations-pro'), ucfirst(str_replace('_', ' ', $required))));
            }
        }

        if ($error = self::validateCouponData($fieldData)) {
            return $error;
        }

        return self::tryRun(
            function () use ($fieldData) {
                $coupon = new \WC_Coupon();

                self::setCouponFields($coupon, $fieldData, false);
                $couponId = $coupon->save();
                self::savePowerCouponsMeta((int) $couponId, $fieldData, false);

                return self::successResponse(
                    __('Coupon created successfully', 'bit-integrations-pro'),
                    ['coupon' => self::formatCoupon((int) $couponId)]
                );
            }
        );
    }

    public static function updateCoupon($defaultResponse, $fieldData, $integrationDetails = null)
    {
        if ($error = self::guard()) {
            return $error;
        }

        $coupon = self::resolveCoupon($fieldData, $integrationDetails);

        if (\is_array($coupon)) {
            return $coupon;
        }

        if ($error = self::validateCouponData($fieldData, (int) $coupon->get_id())) {
            return $error;
        }

        if (!self::hasUpdateData($fieldData)) {
            return self::errorResponse(__('Map at least one coupon field to update', 'bit-integrations-pro'));
        }

        return self::tryRun(
            function () use ($coupon, $fieldData) {
                self::setCouponFields($coupon, $fieldData, true);
                $couponId = (int) $coupon->save();
                self::savePowerCouponsMeta($couponId, $fieldData, true);

                return self::successResponse(
                    __('Coupon updated successfully', 'bit-integrations-pro'),
                    ['coupon' => self::formatCoupon($couponId)]
                );
            }
        );
    }

    public static function deleteCoupon($defaultResponse, $fieldData, $integrationDetails = null)
    {
        if ($error = self::guard()) {
            return $error;
        }

        $coupon = self::resolveCoupon($fieldData, $integrationDetails);

        if (\is_array($coupon)) {
            return $coupon;
        }

        $couponId = (int) $coupon->get_id();
        $couponCode = $coupon->get_code();
        $permanent = self::toBool(isset($fieldData['permanent_delete']) ? $fieldData['permanent_delete'] : false);

        return self::tryRun(
            function () use ($couponId, $couponCode, $permanent) {
                $deleted = wp_delete_post($couponId, $permanent);

                if (!$deleted) {
                    return self::errorResponse(__('Failed to delete coupon', 'bit-integrations-pro'));
                }

                return self::successResponse(
                    $permanent
                        ? __('Coupon permanently deleted successfully', 'bit-integrations-pro')
                        : __('Coupon moved to trash successfully', 'bit-integrations-pro'),
                    ['coupon_code' => $couponCode]
                );
            }
        );
    }

    public static function toggleAutoApply($defaultResponse, $fieldData, $integrationDetails = null)
    {
        return self::toggleMeta(
            $fieldData,
            $integrationDetails,
            '_power_coupon_auto_apply',
            __('Auto apply updated successfully', 'bit-integrations-pro')
        );
    }

    public static function toggleShowInSlideout($defaultResponse, $fieldData, $integrationDetails = null)
    {
        return self::toggleMeta(
            $fieldData,
            $integrationDetails,
            '_power_coupon_show_in_slideout',
            __('Show in slideout updated successfully', 'bit-integrations-pro')
        );
    }

    private static function toggleMeta($fieldData, $integrationDetails, $metaKey, $message)
    {
        if ($error = self::guard()) {
            return $error;
        }

        $coupon = self::resolveCoupon($fieldData, $integrationDetails);

        if (\is_array($coupon)) {
            return $coupon;
        }

        if (!\array_key_exists('enabled', $fieldData) || $fieldData['enabled'] === '') {
            return self::errorResponse(__('Enabled value is required', 'bit-integrations-pro'));
        }

        $couponId = (int) $coupon->get_id();

        return self::tryRun(
            function () use ($couponId, $fieldData, $metaKey, $message) {
                update_post_meta($couponId, $metaKey, self::toBool($fieldData['enabled']) ? 'yes' : 'no');
                self::clearCouponCache($couponId);

                return self::successResponse($message, ['coupon' => self::formatCoupon($couponId)]);
            }
        );
    }

    private static function setCouponFields(\WC_Coupon $coupon, array $fieldData, $partial)
    {
        $fields = [
            'code'                        => 'set_code',
            'description'                 => 'set_description',
            'discount_type'               => 'set_discount_type',
            'amount'                      => 'set_amount',
            'free_shipping'               => 'set_free_shipping',
            'individual_use'              => 'set_individual_use',
            'exclude_sale_items'          => 'set_exclude_sale_items',
            'minimum_amount'              => 'set_minimum_amount',
            'maximum_amount'              => 'set_maximum_amount',
            'usage_limit'                 => 'set_usage_limit',
            'usage_limit_per_user'        => 'set_usage_limit_per_user',
            'product_ids'                 => 'set_product_ids',
            'excluded_product_ids'        => 'set_excluded_product_ids',
            'product_categories'          => 'set_product_categories',
            'excluded_product_categories' => 'set_excluded_product_categories',
            'email_restrictions'          => 'set_email_restrictions',
            'expiry_date'                 => 'set_date_expires',
        ];

        foreach ($fields as $field => $setter) {
            if (!\array_key_exists($field, $fieldData)) {
                continue;
            }

            $coupon->$setter(self::normalizeCouponValue($field, $fieldData[$field]));
        }
    }

    private static function normalizeCouponValue($field, $value)
    {
        switch ($field) {
            case 'code':
                return self::couponCode($value);

            case 'description':
                return sanitize_textarea_field($value);

            case 'discount_type':
                $discountType = sanitize_key($value);

                return self::isAllowedDiscountType($discountType) ? $discountType : 'percent';

            case 'amount':
            case 'minimum_amount':
            case 'maximum_amount':
                return wc_format_decimal($value);

            case 'free_shipping':
            case 'individual_use':
            case 'exclude_sale_items':
                return self::toBool($value);

            case 'usage_limit':
            case 'usage_limit_per_user':
                return $value === '' ? null : absint($value);

            case 'product_ids':
            case 'excluded_product_ids':
            case 'product_categories':
            case 'excluded_product_categories':
                return self::integerList($value);

            case 'email_restrictions':
                return self::textList($value);

            case 'expiry_date':
                $date = sanitize_text_field($value);

                return self::isDate($date) ? $date : null;

            default:
                return sanitize_text_field($value);
        }
    }

    private static function savePowerCouponsMeta($couponId, array $fieldData, $partial)
    {
        if (!$partial || \array_key_exists('auto_apply', $fieldData)) {
            update_post_meta($couponId, '_power_coupon_auto_apply', self::toBool(isset($fieldData['auto_apply']) ? $fieldData['auto_apply'] : false) ? 'yes' : 'no');
        }

        if (!$partial || \array_key_exists('show_in_slideout', $fieldData)) {
            update_post_meta($couponId, '_power_coupon_show_in_slideout', self::toBool(isset($fieldData['show_in_slideout']) ? $fieldData['show_in_slideout'] : false) ? 'yes' : 'no');
        }

        if (!$partial || \array_key_exists('start_date', $fieldData)) {
            $startDate = sanitize_text_field(isset($fieldData['start_date']) ? $fieldData['start_date'] : '');

            if ($startDate !== '' && self::isDate($startDate)) {
                update_post_meta($couponId, '_power_coupon_start_date', $startDate);
            } elseif ($partial || $startDate === '') {
                delete_post_meta($couponId, '_power_coupon_start_date');
            }
        }

        if (!$partial || \array_key_exists('rules_enabled', $fieldData)) {
            self::saveRulesEnabled($couponId, self::toBool(isset($fieldData['rules_enabled']) ? $fieldData['rules_enabled'] : false));
        }

        self::clearCouponCache($couponId);
    }

    private static function validateCouponData(array $fieldData, $currentCouponId = 0)
    {
        if (\array_key_exists('code', $fieldData)) {
            $code = self::couponCode($fieldData['code']);

            if ($code === '') {
                return self::errorResponse(__('Coupon code cannot be empty', 'bit-integrations-pro'));
            }

            $existingCouponId = wc_get_coupon_id_by_code($code);

            if ($existingCouponId && (int) $existingCouponId !== (int) $currentCouponId) {
                return self::errorResponse(__('A coupon with this code already exists', 'bit-integrations-pro'));
            }
        }

        if (
            \array_key_exists('discount_type', $fieldData)
            && !self::isAllowedDiscountType(sanitize_key($fieldData['discount_type']))
        ) {
            return self::errorResponse(__('Invalid discount type. Use percent, fixed_cart, or fixed_product.', 'bit-integrations-pro'));
        }

        foreach (['expiry_date', 'start_date'] as $dateField) {
            if (
                \array_key_exists($dateField, $fieldData)
                && $fieldData[$dateField] !== ''
                && !self::isDate(sanitize_text_field($fieldData[$dateField]))
            ) {
                return self::errorResponse(__('Invalid date. Use YYYY-MM-DD format.', 'bit-integrations-pro'));
            }
        }

        foreach (['amount', 'minimum_amount', 'maximum_amount'] as $amountField) {
            if (
                \array_key_exists($amountField, $fieldData)
                && $fieldData[$amountField] !== ''
                && !is_numeric($fieldData[$amountField])
            ) {
                return self::errorResponse(__('Amount fields must be numeric.', 'bit-integrations-pro'));
            }
        }

        foreach (['usage_limit', 'usage_limit_per_user'] as $limitField) {
            if (
                \array_key_exists($limitField, $fieldData)
                && $fieldData[$limitField] !== ''
                && (!is_numeric($fieldData[$limitField]) || (float) $fieldData[$limitField] < 0)
            ) {
                return self::errorResponse(__('Usage limit fields must be zero or positive numbers.', 'bit-integrations-pro'));
            }
        }

        return false;
    }

    private static function hasUpdateData(array $fieldData)
    {
        $lookupFields = [
            'coupon_code' => true,
        ];

        foreach ($fieldData as $field => $value) {
            if (!isset($lookupFields[$field])) {
                return true;
            }
        }

        return false;
    }

    private static function saveRulesEnabled($couponId, $enabled)
    {
        $value = $enabled ? 'yes' : 'no';

        if (class_exists('\Power_Coupons\Includes\Power_Coupons_Rules_Registry')) {
            \Power_Coupons\Includes\Power_Coupons_Rules_Registry::save_meta(
                $couponId,
                ['_pc_rule_enable_conditions' => $value]
            );
        } else {
            update_post_meta($couponId, '_pc_rule_enable_conditions', $value);
        }
    }

    private static function resolveCoupon($fieldData, $integrationDetails = null)
    {
        $couponCode = empty($fieldData['coupon_code']) ? '' : self::couponCode($fieldData['coupon_code']);

        $couponId = $couponCode === '' ? 0 : wc_get_coupon_id_by_code($couponCode);

        if (!$couponId) {
            return self::errorResponse(__('Coupon code is required', 'bit-integrations-pro'));
        }

        $post = get_post($couponId);

        if (!is_object($post) || $post->post_type !== 'shop_coupon') {
            return self::errorResponse(__('Coupon not found', 'bit-integrations-pro'));
        }

        try {
            $coupon = new \WC_Coupon($couponId);
        } catch (\Exception $e) {
            return self::errorResponse($e->getMessage());
        }

        if (!$coupon->get_id()) {
            return self::errorResponse(__('Coupon not found', 'bit-integrations-pro'));
        }

        return $coupon;
    }

    private static function formatCoupon($couponId)
    {
        $coupon = new \WC_Coupon($couponId);
        $expiry = $coupon->get_date_expires();

        return [
            'id'                          => $couponId,
            'code'                        => $coupon->get_code(),
            'description'                 => $coupon->get_description(),
            'discount_type'               => $coupon->get_discount_type(),
            'amount'                      => $coupon->get_amount(),
            'free_shipping'               => $coupon->get_free_shipping(),
            'individual_use'              => $coupon->get_individual_use(),
            'exclude_sale_items'          => $coupon->get_exclude_sale_items(),
            'minimum_amount'              => $coupon->get_minimum_amount(),
            'maximum_amount'              => $coupon->get_maximum_amount(),
            'usage_limit'                 => $coupon->get_usage_limit(),
            'usage_limit_per_user'        => $coupon->get_usage_limit_per_user(),
            'product_ids'                 => $coupon->get_product_ids(),
            'excluded_product_ids'        => $coupon->get_excluded_product_ids(),
            'product_categories'          => $coupon->get_product_categories(),
            'excluded_product_categories' => $coupon->get_excluded_product_categories(),
            'email_restrictions'          => $coupon->get_email_restrictions(),
            'expiry_date'                 => $expiry ? $expiry->date('Y-m-d') : '',
            'auto_apply'                  => get_post_meta($couponId, '_power_coupon_auto_apply', true),
            'show_in_slideout'            => get_post_meta($couponId, '_power_coupon_show_in_slideout', true),
            'start_date'                  => get_post_meta($couponId, '_power_coupon_start_date', true),
            'rules_enabled'               => get_post_meta($couponId, '_pc_rule_enable_conditions', true),
            'url_edit'                    => admin_url('post.php?post=' . $couponId . '&action=edit'),
        ];
    }

    private static function guard()
    {
        if (!self::isPowerCouponsActive()) {
            return self::errorResponse(__('Power Coupons for WooCommerce is not installed or activated', 'bit-integrations-pro'));
        }

        if (!class_exists('\WC_Coupon') || !function_exists('wc_get_coupon_id_by_code')) {
            return self::errorResponse(__('WooCommerce coupons are not available', 'bit-integrations-pro'));
        }

        return false;
    }

    private static function isPowerCouponsActive()
    {
        return (class_exists('\WooCommerce') || function_exists('WC'))
            && (
                defined('POWER_COUPONS_VERSION')
                || function_exists('power_coupons')
                || class_exists('\Power_Coupons\Power_Coupons_Loader')
            );
    }

    private static function couponCode($code)
    {
        $code = sanitize_text_field($code);

        return function_exists('wc_format_coupon_code') ? wc_format_coupon_code($code) : strtolower($code);
    }

    private static function integerList($value)
    {
        $items = \is_array($value) ? $value : explode(',', (string) $value);
        $items = array_map('absint', $items);

        return array_values(array_filter($items));
    }

    private static function textList($value)
    {
        $items = \is_array($value) ? $value : explode(',', (string) $value);
        $items = array_map('sanitize_text_field', array_map('trim', $items));

        return array_values(
            array_filter(
                $items,
                function ($item) {
                    return $item !== '';
                }
            )
        );
    }

    private static function toBool($value)
    {
        if (\is_bool($value)) {
            return $value;
        }

        if (\is_numeric($value)) {
            return (int) $value === 1;
        }

        return \in_array(strtolower(trim((string) $value)), ['1', 'yes', 'true', 'on', 'enabled'], true);
    }

    private static function isDate($value)
    {
        if (!\is_string($value) || !(bool) preg_match(self::$datePattern, $value)) {
            return false;
        }

        $parts = array_map('intval', explode('-', $value));

        return checkdate($parts[1], $parts[2], $parts[0]);
    }

    private static function isAllowedDiscountType($discountType)
    {
        return \in_array($discountType, ['percent', 'fixed_cart', 'fixed_product'], true);
    }

    private static function clearCouponCache($couponId)
    {
        clean_post_cache($couponId);
        wp_cache_delete($couponId, 'post_meta');
    }

    private static function tryRun($callback)
    {
        try {
            return $callback();
        } catch (\Exception $e) {
            return self::errorResponse($e->getMessage());
        }
    }

    private static function successResponse($message, array $data = [])
    {
        return [
            'success' => true,
            'message' => $message,
            'data'    => $data,
        ];
    }

    private static function errorResponse($message)
    {
        return [
            'success' => false,
            'message' => $message,
        ];
    }
}
