<?php

namespace FluentCartPro\App\Hooks\Handlers;

use FluentCart\Api\ModuleSettings;
use FluentCart\App\App;
use FluentCart\App\Services\Permission\PermissionManager;

class AdvancedInventoryMenuHandler
{
    public function register()
    {
        add_action('admin_enqueue_scripts', function () {
            wp_register_style('fluent-cart-admin', false);
            wp_enqueue_style('fluent-cart-admin');

            wp_add_inline_style('fluent-cart-admin', '
                .toplevel_page_fluent-cart li.fluent_cart_inventory {
                    display: none;
                }
            ');
        });

        add_action('fluent_cart/admin_submenu_added', [$this, 'addInventoryMenu'], 10, 1);
    }

    public function addInventoryMenu($submenu)
    {
        if (!$this->shouldShowInventoryMenu()) {
            return;
        }

        global $submenu;

        $capability = 'manage_options';

        if (!current_user_can('manage_options') && App::isProActive()) {
            $capability = PermissionManager::ADMIN_CAP;
        }

        if (isset($submenu['fluent-cart'])) {
            $inventoryMenu = [
                '↳ ' . __('Inventory', 'fluent-cart-pro'),
                $capability,
                'admin.php?page=fluent-cart#/products/inventory',
                '',
                'fluent_cart_inventory'
            ];

            $newSubmenu = [];
            $inserted = false;

            foreach ($submenu['fluent-cart'] as $key => $item) {
                $newSubmenu[$key] = $item;

                if ($key === 'products' && !$inserted) {
                    $newSubmenu['inventory'] = $inventoryMenu;
                    $inserted = true;
                }
            }

            if (!$inserted) {
                $newSubmenu['inventory'] = $inventoryMenu;
            }

            $submenu['fluent-cart'] = $newSubmenu;
        }
    }

    private function shouldShowInventoryMenu(): bool
    {
        if (!PermissionManager::hasPermission(['products/view'])) {
            return false;
        }

        if (!ModuleSettings::isActive('stock_management')) {
            return false;
        }

        if (ModuleSettings::getSettings('stock_management.enable_advanced_inventory') !== 'yes') {
            return false;
        }

        if (!App::isProActive()) {
            return false;
        }

        return true;
    }
}
