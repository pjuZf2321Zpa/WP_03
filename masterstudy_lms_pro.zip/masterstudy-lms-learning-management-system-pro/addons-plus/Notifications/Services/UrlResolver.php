<?php

namespace MasterStudy\Lms\Pro\AddonsPlus\Notifications\Services;

final class UrlResolver {
	public function resolve( string $click_action, array $context ): string {
		$course_id     = absint( $context['course_id'] ?? 0 );
		$item_id       = absint( $context['item_id'] ?? 0 );
		$assignment_id = absint( $context['assignment_id'] ?? 0 );

		switch ( $click_action ) {
			case 'course_single':
				return $course_id > 0 ? get_permalink( $course_id ) : '';
			case 'course_player_assignment':
				return $this->course_player_url( $course_id, $assignment_id > 0 ? $assignment_id : $item_id );
			case 'course_player_lesson':
			case 'course_player_meeting':
				return $this->course_player_url( $course_id, $item_id );
			case 'course_player_lesson_discussions':
				$url = $this->course_player_url( $course_id, $item_id );

				return $url ? add_query_arg( 'discussions_open', 'yes', $url ) : '';
			case 'course_assignments_table':
				if ( function_exists( 'ms_plugin_user_account_url' ) ) {
					return $course_id > 0
						? add_query_arg( 'course_id', $course_id, ms_plugin_user_account_url( 'assignments' ) )
						: ms_plugin_user_account_url( 'assignments' );
				}

				return '';
			case 'admin_instructors':
				return admin_url( 'admin.php?page=manage_instructors' );
			case 'none':
			default:
				return '';
		}
	}

	private function course_player_url( int $course_id, int $item_id ): string {
		if ( $course_id <= 0 ) {
			return '';
		}

		if ( class_exists( 'STM_LMS_Lesson' ) ) {
			return (string) \STM_LMS_Lesson::get_lesson_url( $course_id, $item_id );
		}

		return get_permalink( $course_id );
	}
}
