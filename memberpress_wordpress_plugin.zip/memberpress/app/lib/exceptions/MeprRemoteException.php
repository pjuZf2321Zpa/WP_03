<?php

if (!defined('ABSPATH')) {
    die('You are not allowed to call this page directly.');
}

class MeprRemoteException extends Exception
{
    /**
     * The machine-readable error code the remote API returned (Stripe's
     * `error.code`, for example), or an empty string when the response
     * carried none.
     *
     * @var string
     */
    private string $error_code;

    /**
     * Constructor for the MeprRemoteException class.
     *
     * @param string $message    The human-readable error message.
     * @param string $error_code The remote API's machine-readable error code.
     */
    public function __construct(string $message = '', string $error_code = '')
    {
        parent::__construct($message);

        $this->error_code = $error_code;
    }

    /**
     * The remote API's machine-readable error code.
     *
     * @return string The error code, or an empty string when the response carried none.
     */
    public function get_error_code(): string
    {
        return $this->error_code;
    }
}
