<?php

namespace FluentCartPro\App\Modules\Promotional\OrderBump\Cards;

class HighlightCard extends AbstractCard
{
    public static function key(): string
    {
        return 'highlight';
    }

    public static function title(): string
    {
        return __('Highlight Box', 'fluent-cart-pro');
    }

    public static function description(): string
    {
        return __('A yellow bar with the checkbox on top.', 'fluent-cart-pro');
    }

    public static function content(): string
    {
        $checkbox = '<!-- wp:fluent-cart/order-bump-checkbox ' . wp_json_encode(['label' => sprintf(__('Grab it for %s', 'fluent-cart-pro'), '{{bump.price}}')]) . ' /-->';

        $prices = static::group(
            'fct_bump_highlight__prices',
            static::element('original-price', 'fct_bump_highlight__was') . "\n\n" . static::element('price', 'fct_bump_highlight__price')
        );

        $details = static::element('title', 'fct_bump_highlight__badge') . "\n\n"
            . static::element('product-title', 'fct_bump_highlight__name') . "\n\n"
            . static::element('variation-title', 'fct_bump_highlight__variation') . "\n\n"
            . static::group(
                'fct_bump_highlight__row',
                static::element('original-price', 'fct_bump_highlight__was') . "\n\n"
                . static::element('price', 'fct_bump_highlight__price') . "\n\n"
                . static::element('savings', 'fct_bump_highlight__savings')
            );

        return static::group(
            'fct_bump_highlight',
            static::group('fct_bump_highlight__bar', $checkbox . "\n\n" . $prices) . "\n\n"
            . static::group(
                'fct_bump_highlight__body',
                static::element('image', 'fct_bump_highlight__image') . "\n\n" . static::group('fct_bump_highlight__details', $details)
            )
        );
    }

    public static function css(): string
    {
        return <<<'CSS'
.fct_bump_highlight {
    position: relative;
    overflow: hidden;
    box-sizing: border-box;
    border: 1px dashed #d9dce1;
    border-radius: 8px;
    background: var(--fct-card-bg-color, #fff);
    color: var(--fct-primary-text-color, #111827);
}
.fct_bump_highlight__bar {
    display: flex;
    align-items: center;
    justify-content: space-between;
    column-gap: 12px;
    min-height: 46px;
    padding: 0 16px;
    background: #fdf7c8;
    color: #6b3a0e;
}
.fct_bump_highlight .fct_bump_highlight__bar label.fct_order_promotion_toggle {
    flex: 1;
    min-width: 0;
    margin: 0;
    padding: 0;
    color: inherit;
    font-size: 14px;
    font-weight: 600;
}
/* The label covers the whole card, so a click anywhere toggles the checkbox. */
.fct_bump_highlight .fct_bump_highlight__bar label.fct_order_promotion_toggle::after {
    content: "";
    position: absolute;
    inset: 0;
}
.fct_bump_highlight .fct_bump_highlight__bar input.fct_order_promotion_input {
    appearance: none;
    -webkit-appearance: none;
    position: relative;
    flex: none;
    box-sizing: border-box;
    width: 16px;
    height: 16px;
    margin: 0;
    padding: 0;
    background: #fff;
    border: 1px solid #6b3a0e;
    border-radius: 3px;
}
.fct_bump_highlight:hover .fct_bump_highlight__bar input.fct_order_promotion_input {
    border-color: #3d1f06;
}
.fct_bump_highlight .fct_bump_highlight__bar input.fct_order_promotion_input:checked {
    background: #6b3a0e;
    border-color: #6b3a0e;
}
.fct_bump_highlight:hover .fct_bump_highlight__bar input.fct_order_promotion_input:checked {
    background: #3d1f06;
    border-color: #3d1f06;
}
.fct_bump_highlight .fct_bump_highlight__bar input.fct_order_promotion_input::before {
    content: "";
    position: absolute;
    top: 1px;
    left: 4px;
    box-sizing: border-box;
    width: 5px;
    height: 9px;
    border: solid #fff;
    border-width: 0 1.5px 1.5px 0;
    transform: rotate(45deg);
    opacity: 0;
}
.fct_bump_highlight .fct_bump_highlight__bar input.fct_order_promotion_input:checked::before {
    opacity: 1;
}
.fct_bump_highlight__prices {
    display: flex;
    align-items: baseline;
    column-gap: 8px;
    font-size: 14px;
    font-weight: 600;
}
.fct_bump_highlight__body {
    display: flex;
    align-items: center;
    column-gap: 14px;
    padding: 18px 16px;
}
.fct_bump_highlight__image {
    flex: none;
    width: 60px;
    height: 60px;
    overflow: hidden;
    border-radius: 8px;
    background: #f3f4f6;
}
.fct_bump_highlight__image img {
    display: block;
    width: 100%;
    height: 100%;
    object-fit: cover;
}
.fct_bump_highlight__details {
    flex: 1;
    min-width: 0;
}
.fct_bump_highlight p,
.fct_bump_highlight figure {
    margin: 0;
}
.fct_bump_highlight__badge {
    font-size: 13px;
    line-height: 1.4;
    color: var(--fct-secondary-text-color, #6b7280);
}
.fct_bump_highlight__name {
    font-size: 15px;
    font-weight: 600;
    line-height: 1.4;
}
.fct_bump_highlight__variation {
    font-size: 13px;
    line-height: 1.4;
    color: var(--fct-secondary-text-color, #6b7280);
}
.fct_bump_highlight__row {
    display: flex;
    flex-wrap: wrap;
    align-items: baseline;
    column-gap: 8px;
    margin-top: 2px;
    font-size: 15px;
}
.fct_bump_highlight__was {
    text-decoration: line-through;
    color: var(--fct-secondary-text-color, #6b7280);
}
.fct_bump_highlight__bar .fct_bump_highlight__was {
    color: inherit;
    opacity: 0.7;
}
.fct_bump_highlight__price {
    font-weight: 600;
}
.fct_bump_highlight__savings {
    font-size: 13px;
    color: #c0392b;
}
.fct_bump_highlight__badge:empty,
.fct_bump_highlight__variation:empty,
.fct_bump_highlight__was:empty,
.fct_bump_highlight__savings:empty {
    display: none;
}
CSS;
    }
}
