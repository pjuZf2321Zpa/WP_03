<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Core\Util\Route;
use BitApps\IntegrationsPro\Triggers\ConvertPro\ConvertProController;

Route::get('convert_pro/get', [ConvertProController::class, 'getAllTasks']);
