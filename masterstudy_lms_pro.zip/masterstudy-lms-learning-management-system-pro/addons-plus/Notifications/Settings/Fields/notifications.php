<?php
/**
 * Notifications triggers field template.
 *
 * @var $field
 * @var $field_value
 */

$field_key = "data['{$section_name}']['fields']['{$field_name}']";

wp_enqueue_style(
	'masterstudy-notifications-settings',
	STM_LMS_PRO_URL . 'assets/css/admin/notifications-settings.css',
	array(),
	STM_LMS_PRO_VERSION,
	'all'
);

wp_enqueue_script(
	'masterstudy-notifications-settings',
	STM_LMS_PRO_URL . 'addons-plus/Notifications/Settings/Fields/assets/js/notifications.js',
	array( 'vue.js', 'wpcfto_metaboxes.js' ),
	STM_LMS_PRO_VERSION,
	true
);
?>

<wpcfto_masterstudy_notifications_triggers
	:fields="<?php echo esc_attr( $field_key ); ?>"
	:field_value="<?php echo esc_attr( $field_value ); ?>"
	@wpcfto-get-value="<?php echo esc_attr( $field_value ); ?> = $event">
</wpcfto_masterstudy_notifications_triggers>
