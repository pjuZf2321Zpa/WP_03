<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Actions\Line\LineHelperPro;
use BitApps\IntegrationsPro\Config;
use BitApps\IntegrationsPro\Core\Util\Hooks;

// Deprecated since v2.7.8 - use bit_integrations_line_* hooks instead
if (bit_integrations_version_below('2.7.8')) {
    Hooks::filter('btcbi_line_reply_message', [LineHelperPro::class, 'sendReplyMessage'], 10, 4);
    Hooks::filter('btcbi_line_broadcast_message', [LineHelperPro::class, 'sendBroadcastMessage'], 10, 4);
}

// New hooks since v2.7.8
Hooks::filter(Config::withFreePrefix('line_reply_message'), [LineHelperPro::class, 'sendReplyMessage'], 10, 4);
Hooks::filter(Config::withFreePrefix('line_broadcast_message'), [LineHelperPro::class, 'sendBroadcastMessage'], 10, 4);
