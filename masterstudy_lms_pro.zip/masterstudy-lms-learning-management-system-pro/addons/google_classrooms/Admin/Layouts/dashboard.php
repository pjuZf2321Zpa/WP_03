<?php

$current_page = sanitize_text_field( wp_unslash( $_GET['page'] ?? '' ) );

if ( in_array( $current_page, array( 'mslms_classrooms', 'mslms_classroom_auditory' ), true ) ) {
	STM_LMS_Templates::show_lms_template( 'components/admin-react-app/main' );
} else {
	wp_safe_redirect( admin_url( 'admin.php?page=mslms_classrooms' ) );
	exit;
}
