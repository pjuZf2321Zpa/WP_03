<?php

namespace BitApps\IntegrationsPro\Actions\FollowUpBoss\Services;

final class EmailTemplateService extends BaseService
{
    public function createEmailTemplate(): array
    {
        $validationRules = [
            'name'    => ['required'],
            'subject' => ['required'],
            'body'    => ['required'],
        ];
        $error = $this->validateFields(
            $validationRules,
            [
                'name'    => __('Template Name', 'bit-integrations-pro'),
                'subject' => __('Subject', 'bit-integrations-pro'),
                'body'    => __('Body', 'bit-integrations-pro'),
            ]
        );

        if ($error !== null) {
            return $error;
        }

        $payload = $this->removeEmptyValues(
            [
                'name'     => $this->getString('name'),
                'subject'  => $this->getString('subject'),
                'body'     => $this->getString('body'),
                'isShared' => $this->getBoolean('is_shared'),
            ]
        );

        return $this->dispatch('POST', '/templates', $payload);
    }

    public function updateEmailTemplate(): array
    {
        $validationRules = ['template_id' => ['required', 'integer']];
        $error = $this->validateFields(
            $validationRules,
            [
                'template_id' => __('Email Template ID', 'bit-integrations-pro'),
            ]
        );

        if ($error !== null) {
            return $error;
        }

        $payload = $this->removeEmptyValues(
            [
                'name'     => $this->getString('name'),
                'subject'  => $this->getString('subject'),
                'body'     => $this->getString('body'),
                'isShared' => $this->getBoolean('is_shared'),
            ]
        );

        $currentValues = $this->getMissingCurrentValues('/templates/' . rawurlencode($this->getString('template_id')), $payload, ['name', 'subject', 'body']);

        if (isset($currentValues['success'])) {
            return $currentValues;
        }

        $payload += $currentValues;

        return $this->dispatch('PUT', '/templates/' . rawurlencode($this->getString('template_id')), $payload);
    }

    public function deleteEmailTemplate(): array
    {
        $validationRules = ['template_id' => ['required', 'integer']];
        $error = $this->validateFields(
            $validationRules,
            [
                'template_id' => __('Email Template ID', 'bit-integrations-pro'),
            ]
        );

        if ($error !== null) {
            return $error;
        }

        return $this->dispatch('DELETE', '/templates/' . rawurlencode($this->getString('template_id')));
    }
}
