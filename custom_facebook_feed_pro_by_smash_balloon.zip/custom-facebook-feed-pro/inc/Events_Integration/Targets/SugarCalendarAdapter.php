<?php
/**
 * Sugar Calendar target adapter: writes events exclusively through Sugar
 * Calendar's public API (sc_event post + event row).
 *
 * @package CustomFacebookFeed\Events_Integration
 * @since 4.11
 */

namespace CustomFacebookFeed\Events_Integration\Targets;

use CustomFacebookFeed\Events_Integration\Config;
use CustomFacebookFeed\Events_Integration\NormalizedEvent;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class SugarCalendarAdapter implements TargetAdapterInterface {

	/**
	 * @inheritDoc
	 */
	public function id() {
		return Config::TARGET_SUGAR_CALENDAR;
	}

	/**
	 * @inheritDoc
	 */
	public function label() {
		return __( 'Sugar Calendar', 'custom-facebook-feed' );
	}

	/**
	 * @inheritDoc
	 */
	public function is_available() {
		return function_exists( 'sugar_calendar_add_event' )
			&& function_exists( 'sugar_calendar_get_event_post_type_id' );
	}

	/**
	 * @inheritDoc
	 */
	public function post_type() {
		return sugar_calendar_get_event_post_type_id();
	}

	/**
	 * @inheritDoc
	 */
	public function create( NormalizedEvent $event ) {
		$post_id = wp_insert_post(
			array(
				'post_type'    => $this->post_type(),
				'post_title'   => $event->title,
				'post_content' => $event->description,
				'post_status'  => 'publish',
			),
			true
		);

		if ( is_wp_error( $post_id ) ) {
			return $post_id;
		}

		$this->assign_calendar_term( $post_id );

		$event_id = sugar_calendar_add_event( $this->event_data( $post_id, $event ) );
		if ( empty( $event_id ) ) {
			wp_delete_post( $post_id, true );
			return new \WP_Error( 'cff_events_sync_sc_add', __( 'Sugar Calendar did not accept the event.', 'custom-facebook-feed' ) );
		}

		return (int) $post_id;
	}

	/**
	 * @inheritDoc
	 */
	public function update( $post_id, NormalizedEvent $event ) {
		$result = wp_update_post(
			array(
				'ID'           => $post_id,
				'post_title'   => $event->title,
				'post_content' => $event->description,
			),
			true
		);
		if ( is_wp_error( $result ) ) {
			return $result;
		}

		$sc_event = sugar_calendar_get_event_by_object( $post_id );
		if ( empty( $sc_event ) || empty( $sc_event->id ) ) {
			// The event row vanished: recreate it to keep the mapping intact.
			$event_id = sugar_calendar_add_event( $this->event_data( $post_id, $event ) );
			return empty( $event_id ) ? new \WP_Error( 'cff_events_sync_sc_add', __( 'Sugar Calendar did not accept the event.', 'custom-facebook-feed' ) ) : true;
		}

		$data    = $this->event_data( $post_id, $event );
		$updated = sugar_calendar_update_event( $sc_event->id, $data );

		// update_event() also returns false when nothing changed; only treat
		// it as a failure when the stored row doesn't match what we sent.
		if ( ! $updated && ! $this->event_row_matches( $sc_event->id, $data ) ) {
			return new \WP_Error( 'cff_events_sync_sc_update', __( 'Sugar Calendar could not update the event.', 'custom-facebook-feed' ) );
		}

		return true;
	}

	/**
	 * Whether the stored Sugar Calendar event row already matches the data
	 * we tried to write (distinguishes a no-op update from a failed one).
	 *
	 * @param int   $event_id Sugar Calendar event ID.
	 * @param array $data     Data passed to sugar_calendar_update_event().
	 * @return bool
	 */
	private function event_row_matches( $event_id, array $data ) {
		$stored = function_exists( 'sugar_calendar_get_event' ) ? sugar_calendar_get_event( $event_id ) : null;
		if ( empty( $stored ) ) {
			return false;
		}

		foreach ( array( 'title', 'start', 'end', 'start_tz', 'end_tz', 'all_day', 'location' ) as $field ) {
			if ( isset( $data[ $field ] ) && (string) $stored->{$field} !== (string) $data[ $field ] ) {
				return false;
			}
		}

		return true;
	}

	/**
	 * @inheritDoc
	 */
	public function delete( $post_id ) {
		$sc_event = sugar_calendar_get_event_by_object( $post_id );
		if ( ! empty( $sc_event ) && ! empty( $sc_event->id ) ) {
			sugar_calendar_delete_event( $sc_event->id );
		}

		return (bool) wp_delete_post( $post_id, true );
	}

	/**
	 * Map a NormalizedEvent to the sugar_calendar_add_event() data shape.
	 *
	 * @param int             $post_id Backing sc_event post ID.
	 * @param NormalizedEvent $event   Normalized event.
	 * @return array
	 */
	private function event_data( $post_id, NormalizedEvent $event ) {
		return array(
			'object_id'           => $post_id,
			'object_type'         => 'post',
			'object_subtype'      => $this->post_type(),
			'title'               => $event->title,
			'content'             => $event->description,
			'status'              => 'publish',
			'start'               => $event->start ? $event->start->format( 'Y-m-d H:i:s' ) : '',
			'start_tz'            => $event->timezone,
			'end'                 => $event->end ? $event->end->format( 'Y-m-d H:i:s' ) : '',
			'end_tz'              => $event->timezone,
			'all_day'             => (int) $event->all_day,
			// Recurring events arrive pre-expanded; no SC recurrence needed.
			'recurrence'          => '',
			'recurrence_interval' => 0,
			'recurrence_count'    => 0,
			'recurrence_end'      => '',
			'recurrence_end_tz'   => '',
			'location'            => $event->location_string(),
		);
	}

	/**
	 * Assign the configured Sugar Calendar term to a new event post.
	 *
	 * @param int $post_id Post ID.
	 */
	private function assign_calendar_term( $post_id ) {
		$settings = Config::get_settings();
		$term_id  = (int) $settings['sc_calendar_term'];

		if ( $term_id > 0 && function_exists( 'sugar_calendar_get_calendar_taxonomy_id' ) ) {
			wp_set_object_terms( $post_id, $term_id, sugar_calendar_get_calendar_taxonomy_id() );
		}
	}
}
