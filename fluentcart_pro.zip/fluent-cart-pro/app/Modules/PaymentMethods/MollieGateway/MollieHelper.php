<?php

namespace FluentCartPro\App\Modules\PaymentMethods\MollieGateway;

use FluentCart\App\Helpers\Status;
use FluentCart\App\Models\Subscription;
use FluentCart\App\Services\Payments\PaymentHelper;
use FluentCart\Framework\Support\Arr;
use FluentCart\App\Models\Order;
use FluentCart\App\Services\DateTime\DateTime;
use FluentCartPro\App\Modules\PaymentMethods\MollieGateway\API\MollieAPI;

class MollieHelper
{

    /**
     * Logs a raw upstream Mollie WP_Error server-side and returns a generic,
     * customer-safe replacement — Mollie's own `detail`/`title` text must never
     * reach checkout responses or admin-facing error strings verbatim.
     *
     * $code must be call-site-specific (e.g. 'mollie_refund_lookup_failed'), not
     * reused from $error — every site in MollieAPI::remoteRequest() throws the same
     * generic 'api_error', so passing that through would make every failure look
     * identical to a developer grepping error codes/logs.
     */
    public static function sanitizeApiError(\WP_Error $error, $code, $genericMessage, array $logContext = [])
    {
        fluent_cart_warning_log(
            'Mollie API error',
            $error->get_error_message(),
            array_merge(['log_type' => 'api'], $logContext)
        );

        return new \WP_Error($code, $genericMessage);
    }

    public static function processRemoteRefund($transaction, $amount, $args)
    {
        $paymentId = $transaction->vendor_charge_id;

        if (!$paymentId) {
            return new \WP_Error(
                'mollie_refund_error',
                __('Payment ID not found for refund', 'fluent-cart-pro')
            );
        }

        $mode = $transaction->payment_mode ?: 'current';

        $payment = (new MollieAPI())->getMollieObject('payments/' . $paymentId, [], $mode);

        if (is_wp_error($payment)) {
            return self::sanitizeApiError(
                $payment,
                'mollie_refund_payment_lookup_failed',
                __('We could not verify this payment with Mollie. Please try again in a moment.', 'fluent-cart-pro'),
                ['module_name' => 'order', 'module_id' => $transaction->order_id]
            );
        }

        $amountAvailable = Arr::get($payment, 'amountRemaining.value', '0.00');
        $currency = Arr::get($payment, 'amount.currency');

        $refundAmount = self::formatAmountForMollie($amount, $currency);

        if (floatval($refundAmount) > floatval($amountAvailable)) {
            return new \WP_Error(
                'mollie_refund_error',
                sprintf(
                    __('Refund amount %s exceeds available amount %s', 'fluent-cart-pro'),
                    $refundAmount,
                    $amountAvailable
                )
            );
        }

        $refundData = [
            'amount' => [
                'currency' => $currency,
                'value'    => $refundAmount
            ]
        ];

        if (!empty($args['note'])) {
            $refundData['description'] = $args['note'];
        }

        // Add reason as description if provided and no note
        if (empty($args['note']) && !empty($args['reason'])) {
            $reasonMap = [
                'duplicate' => 'Duplicate payment',
                'fraudulent' => 'Fraudulent payment',
                'requested_by_customer' => 'Requested by customer'
            ];
            $refundData['description'] = $reasonMap[$args['reason']] ?? $args['reason'];
        }

        $refund = (new MollieAPI())->createMollieObject('payments/' . $paymentId . '/refunds', $refundData, $mode);

        if (is_wp_error($refund)) {
            return self::sanitizeApiError(
                $refund,
                'mollie_refund_create_failed',
                __('Mollie could not process this refund. Please check your Mollie dashboard.', 'fluent-cart-pro'),
                ['module_name' => 'order', 'module_id' => $transaction->order_id]
            );
        }

        $status = Arr::get($refund, 'status');
        $acceptedStatus = ['queued', 'pending', 'processing', 'refunded'];
        if (!in_array($status, $acceptedStatus)) {
            return new \WP_Error('refund_failed', __('Refund could not be processed with Mollie. Please check your Mollie account', 'fluent-cart-pro'));
        }

        return Arr::get($refund, 'id');
    }

    /**
     * Guards checkout create-payment calls against duplicate charges from a resubmit
     * (back button, stale tab, cart-recovery link) on a transaction that already holds
     * a Mollie payment id — covers the sequential-resubmit gap CheckoutApi's cart lock
     * doesn't (the prior create call may have already finished, payment still payable).
     *
     * Lookup/cancel failures fail CLOSED (WP_Error) rather than falling through to
     * create, or a transient Mollie error would let a second payment get created.
     *
     * @return array|\WP_Error|null Existing Mollie payment to reuse as-is, an
     *   already-succeeded redirect response, WP_Error to stop, or null to create fresh.
     */
    public static function guardExistingMolliePayment($transaction, $order, $paymentData)
    {
        $existingPaymentId = $transaction->vendor_charge_id;

        // Not a Mollie id at all (e.g. another gateway's charge id from an earlier
        // attempt) — nothing to guard, create fresh.
        if (!$existingPaymentId || strpos($existingPaymentId, 'tr_') !== 0) {
            return null;
        }

        $existingPayment = (new MollieAPI())->getMollieObject('payments/' . $existingPaymentId, [], $transaction->payment_mode ?: 'current');

        if (is_wp_error($existingPayment)) {
            fluent_cart_warning_log(
                'Mollie existing payment lookup failed',
                $existingPayment->get_error_message() . ' (' . $existingPaymentId . ')',
                [
                    'module_name' => 'order',
                    'module_id'   => $transaction->order_id,
                    'log_type'    => 'api'
                ]
            );
            return new \WP_Error(
                'mollie_payment_lookup_failed',
                __('We could not verify your previous payment attempt. Please wait a moment and try again.', 'fluent-cart-pro')
            );
        }

        $status = Arr::get($existingPayment, 'status');

        if (in_array($status, ['paid', 'authorized'], true)) {
            // Self-heal instead of erroring the customer — fire the same hook the real
            // webhook would, then send them to the receipt.
            do_action('fluent_cart/payments/mollie/webhook_payment_' . $status, [
                'mollie_payment' => $existingPayment,
                'order'          => $order,
            ]);

            return [
                'fct_redirect' => true,
                'status'       => 'success',
                'redirect_to'  => $transaction->getSuccessUrl(),
                'message'      => __('Your payment has already been processed. Redirecting to your order...', 'fluent-cart-pro')
            ];
        }

        if ($status === 'pending') {
            return [
                'fct_wait' => true,
                'status'   => 'pending',
                'message'  => __('Your previous payment attempt is still being processed by Mollie. Please wait a moment before trying again, or check your email for confirmation.', 'fluent-cart-pro')
            ];
        }

        if ($status === 'open') {
            $chargeMaterialMatches = strtoupper((string) Arr::get($existingPayment, 'amount.currency')) === strtoupper((string) Arr::get($paymentData, 'amount.currency'))
                && (string) Arr::get($existingPayment, 'amount.value') === (string) Arr::get($paymentData, 'amount.value');

            if ($chargeMaterialMatches) {
                return $existingPayment;
            }

            $cancelResponse = (new MollieAPI())->deleteMollieObject('payments/' . $existingPaymentId, [], $transaction->payment_mode ?: 'current');
            if (is_wp_error($cancelResponse)) {
                fluent_cart_warning_log(
                    'Mollie stale payment cancel failed',
                    $cancelResponse->get_error_message() . ' (' . $existingPaymentId . ')',
                    [
                        'module_name' => 'order',
                        'module_id'   => $transaction->order_id,
                        'log_type'    => 'api'
                    ]
                );
                return new \WP_Error(
                    'mollie_payment_cancel_failed',
                    __('We could not update your previous payment attempt. Please wait a moment and try again.', 'fluent-cart-pro')
                );
            }
        }

        // canceled/expired/failed (or just retired above) -> safe to create fresh. Bump
        // payment_attempt ourselves rather than waiting on the webhook — it's the
        // idempotency seed, so a resubmit in this race window would otherwise replay
        // the dead payment's own key.
        if (!in_array($transaction->status, [Status::TRANSACTION_FAILED], true)) {
            self::markLocallyFailedForRetry($transaction, $status);
        }

        return null;
    }

    /**
     * Rolls the idempotency seed forward when we've determined, ahead of the
     * webhook, that the previous Mollie payment is dead. Mirrors what
     * CheckoutProcessor::getAdjustedOrder does on a normal FAILED resubmit.
     */
    private static function markLocallyFailedForRetry($transaction, $mollieStatus)
    {
        $attempt = (int) Arr::get($transaction->meta ?: [], 'payment_attempt', 0);

        $transaction->update([
            'status' => Status::TRANSACTION_FAILED,
            'meta'   => array_merge($transaction->meta ?? [], [
                'payment_attempt' => $attempt + 1,
                'mollie_status'   => $mollieStatus
            ])
        ]);
    }

    /**
     * @param \FluentCart\App\Services\Payments\PaymentInstance $paymentInstance
     * @param string $objectType e.g. 'payment'
     * @param array  $fingerprint every charge-material param (amount, currency,
     *   customer, sequence type) — NOT volatile decoration like descriptions/urls
     */
    public static function buildIdempotencyKey($paymentInstance, $objectType, $fingerprint)
    {
        $seed = $paymentInstance->getIdempotencySeed();

        if (!$seed) {
            return null;
        }

        return 'fct_mollie_' . $objectType . '_' . md5($seed . '|' . wp_json_encode($fingerprint));
    }

    public static function formatAmountForMollie($amount, $currency)
    {
        $zeroDecimalCurrencies = ['JPY', 'ISK'];

        $currency = strtoupper($currency);

        if (in_array($currency, $zeroDecimalCurrencies, true)) {
            return number_format($amount / 100, 0, '.', '');
        }

        return number_format($amount / 100, 2, '.', '');
    }


    public static function convertToCents($amount, $currency)
    {
        return (int) round(floatval($amount) * 100);
    }

    public static function getSubscriptionUpdateData($mollieSubscription, $subscriptionModel)
    {
        $status = self::transformSubscriptionStatus($mollieSubscription, $subscriptionModel);

        $subscriptionUpdateData = array_filter([
            'current_payment_method' => 'mollie',
            'status'                 => $status
        ]);

        // Handle cancellation
        if ($status === Status::SUBSCRIPTION_CANCELED) {
            $canceledAt = Arr::get($mollieSubscription, 'canceledAt');
            if ($canceledAt) {
                $subscriptionUpdateData['canceled_at'] = DateTime::anyTimeToGmt($canceledAt)->format('Y-m-d H:i:s');
            }
        }

        // Handle next billing date
        $nextPaymentDate = Arr::get($mollieSubscription, 'nextPaymentDate');
        if ($nextPaymentDate) {
            $subscriptionUpdateData['next_billing_date'] = DateTime::anyTimeToGmt($nextPaymentDate)->format('Y-m-d H:i:s');
        }

        return $subscriptionUpdateData;
    }

    public static function generateSubscriptionDescription($subscriptionModel, $currency = '', $orderType = '')
    {
        $recurringTotal = $subscriptionModel->recurring_total;
        $initialTrial = $subscriptionModel->trial_days;
        $signUpfee = $subscriptionModel->signup_fee;

        if ($orderType == 'renewal') {
            $recurringTotal = $subscriptionModel->getCurrentRenewalAmount();
            $initialTrial = $subscriptionModel->getReactivationTrialDays();
            $signUpfee = 0;
        }

        $intervalMap = [
            'daily'       => '1 day',
            'weekly'      => '1 week',
            'monthly'     => '1 month',
            'quarterly'   => '3 months',
            'half_yearly' => '6 months',
            'yearly'      => '12 months'
        ];

        $description = $subscriptionModel->item_name . ' - ' . self::formatAmountForMollie($recurringTotal, $currency) . ' every ' . $intervalMap[$subscriptionModel->billing_interval];

        // useful in case of allowing same multiple subscriptions with the same description
        $description = apply_filters('fluent_cart/mollie/subscription_description', $description, [
            'subscription_model' => $subscriptionModel,
            'currency' => $currency,
        ]);

        if ($initialTrial > 0 && Arr::get($subscriptionModel->config, 'is_trial_days_simulated', 'no') != 'yes') {
            $description .= ' ( ' . __(' after', 'fluent-cart-pro') . ' ' . $initialTrial . ' ' . __('day', 'fluent-cart-pro') . ' ' . __('trial', 'fluent-cart-pro') . ' )';
        }

        if ($signUpfee > 0) {
            $description .= ' ' . __(' with', 'fluent-cart-pro') . self::formatAmountForMollie($signUpfee, $currency) . __(' sign-up fee', 'fluent-cart-pro');
        }

        return $description;
    }

    /**
     * A reactivation keeps the replaced vendor subscription id until its first
     * payment starts a new Mollie subscription, so that id counts as none.
     */
    public static function currentVendorSubscriptionId(Subscription $subscription, $transaction): string
    {
        $vendorSubscriptionId = (string) $subscription->vendor_subscription_id;
        $order = $transaction ? $transaction->order : null;

        if ($vendorSubscriptionId && $order && $order->type === Status::ORDER_TYPE_RENEWAL
            && $vendorSubscriptionId === (string) Arr::get($order->config, 'old_vendor_subscription_id', '')) {
            return '';
        }

        return $vendorSubscriptionId;
    }

    public static function calculateSubscriptionStartDate($subscriptionModel, $order)
    {
        // For renewal orders, start date is today
        if ($order->type == 'renewal') {
            $trialDays = $subscriptionModel->getReactivationTrialDays();
            if ($trialDays > 0) {
                $startDate = strtotime(DateTime::now()) + ($trialDays * DAY_IN_SECONDS);
                return DateTime::anytimeToGmt($startDate)->format('Y-m-d');
            } else {
                $intervalDays = PaymentHelper::getIntervalDays($subscriptionModel->billing_interval);
                $startDate = strtotime(DateTime::now()) + $intervalDays * DAY_IN_SECONDS;
                return DateTime::anytimeToGmt($startDate)->format('Y-m-d');
            }
          
        } else {
            // add trail days if any, add interval days to last order date
            $trialDays = $subscriptionModel->trial_days;
           
            $intervalDays = PaymentHelper::getIntervalDays($subscriptionModel->billing_interval);

            if ($trialDays > 0) {
                $startDate = strtotime(DateTime::now()) + ($trialDays * DAY_IN_SECONDS);
                return DateTime::anytimeToGmt($startDate)->format('Y-m-d');
            } else {
                $startDate = strtotime(DateTime::now()) + $intervalDays * DAY_IN_SECONDS;
                return DateTime::anytimeToGmt($startDate)->format('Y-m-d');
            }

        }
    }

    public static function transformSubscriptionStatus($mollieSubscription, $subscriptionModel = null)
    {
        $mollieStatus = strtolower(Arr::get($mollieSubscription, 'status', ''));

        switch ($mollieStatus) {
            case 'active':
                return Status::SUBSCRIPTION_ACTIVE;
            case 'pending':
                return Status::SUBSCRIPTION_PENDING;
            case 'canceled':
                return Status::SUBSCRIPTION_CANCELED;
            case 'suspended':
                return Status::SUBSCRIPTION_PAUSED;
            case 'completed':
                return Status::SUBSCRIPTION_COMPLETED;
            default:
                return Status::SUBSCRIPTION_PENDING;
        }
    }

    public static function getCorrectTransactionStatus($mollieStatus)
    {
        switch ($mollieStatus) {
            case 'paid':
                return Status::TRANSACTION_SUCCEEDED;
            case 'authorized':
                return Status::TRANSACTION_AUTHORIZED;
            case 'canceled':
                return Status::TRANSACTION_FAILED;
            case 'expired':
                return Status::TRANSACTION_FAILED;
            case 'refunded':
                return Status::TRANSACTION_REFUNDED;
            case 'failed':
                return Status::TRANSACTION_FAILED;
            case 'open':
            case 'pending':
            default:
                return Status::TRANSACTION_PENDING;
        }
    }


    public static function getTransactionUrl($paymentId, $isLive = true)
    {
        return 'https://www.mollie.com/dashboard/payments/' . $paymentId;
    }

    public static function getSubscriptionUrl($subscriptionId, $isLive = true)
    {
        $subscriptionModel = Subscription::query()->where('id', $subscriptionId)->first();

        if (!$subscriptionModel) {
            return '';
        }

        return 'https://www.mollie.com/dashboard/customers/' . $subscriptionModel->vendor_customer_id;
    }

    public static function formatAddress($fcCustomer, $customerAddress)
    {
        // Mollie treats an address object as all-or-nothing: if one is sent, it must
        // contain at least streetAndNumber, city and country, otherwise the API
        // responds with a 422. Return null for incomplete addresses so callers can
        // omit the field entirely — Mollie only requires an address for BNPL methods.
        if (!$customerAddress || !$customerAddress->address_1 || !$customerAddress->city || !$customerAddress->country) {
            return null;
        }

        $address = [
            'givenName'       => $fcCustomer->first_name,
            'familyName'      => $fcCustomer->last_name,
            'email'           => $fcCustomer->email,
            'streetAndNumber' => $customerAddress->address_1,
            'city'            => $customerAddress->city,
            'country'         => $customerAddress->country,
        ];

        if ($customerAddress->postcode) {
            $address['postalCode'] = $customerAddress->postcode;
        }

        return $address;
    }
}

