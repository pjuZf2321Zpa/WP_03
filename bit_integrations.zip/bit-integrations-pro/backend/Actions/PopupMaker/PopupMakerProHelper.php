<?php

namespace BitApps\IntegrationsPro\Actions\PopupMaker;

use BitApps\IntegrationsPro\Triggers\PopupMaker\PopupMakerController;
use BitApps\IntegrationsPro\Triggers\PopupMaker\PopupMakerHelper;
use PUM_Admin_Popups;
use PUM_Analytics;
use PUM_DB_Subscribers;

class PopupMakerProHelper
{
    public const POPUP_POST_TYPE = 'popup';

    public const POPUP_STATUSES = ['publish', 'draft', 'pending', 'private'];

    public static function createPopup($defaultResponse, $fieldData, $utilities = null, $integrationDetails = null)
    {
        if (!self::isPopupMakerActive()) {
            return self::errorResponse(\sprintf(__('%s is not installed or activated', 'bit-integrations-pro'), 'Popup Maker'));
        }

        $title = isset($fieldData['title']) ? $fieldData['title'] : '';

        if (empty($title)) {
            return self::errorResponse(__('Popup Name is required', 'bit-integrations-pro'));
        }

        $status = self::readStatus($utilities, 'publish');
        $invalidStatus = self::rejectUnknownStatus($status, self::POPUP_STATUSES);

        if (!empty($invalidStatus)) {
            return $invalidStatus;
        }

        $popupId = wp_insert_post(
            [
                'post_type'    => self::POPUP_POST_TYPE,
                'post_title'   => $title,
                'post_content' => $fieldData['content'] ?? '',
                'post_status'  => $status,
            ],
            true
        );

        if (is_wp_error($popupId)) {
            return self::errorResponse($popupId->get_error_message());
        }

        self::applySettings($popupId, $fieldData, $utilities, $integrationDetails, true);

        return self::successResponse(__('Popup created successfully', 'bit-integrations-pro'), self::getPopupData($popupId));
    }

    public static function updatePopup($defaultResponse, $fieldData, $utilities = null, $integrationDetails = null)
    {
        if (!self::isPopupMakerActive()) {
            return self::errorResponse(\sprintf(__('%s is not installed or activated', 'bit-integrations-pro'), 'Popup Maker'));
        }

        $popupId = isset($fieldData['popup_id']) ? (int) $fieldData['popup_id'] : 0;

        if (empty($popupId) || !self::resolvePopup($popupId)) {
            return self::errorResponse(__('No popup found with the given id', 'bit-integrations-pro'));
        }

        $status = self::readStatus($utilities, '');
        $invalidStatus = self::rejectUnknownStatus($status, self::POPUP_STATUSES);

        if (!empty($invalidStatus)) {
            return $invalidStatus;
        }

        $postData = self::withoutEmpty(
            [
                'post_title'   => $fieldData['title'] ?? '',
                'post_content' => $fieldData['content'] ?? '',
                'post_status'  => $status,
            ]
        );

        if (!empty($postData)) {
            $postData['ID'] = $popupId;
            $updated = wp_update_post($postData, true);

            if (is_wp_error($updated)) {
                return self::errorResponse($updated->get_error_message());
            }
        }

        self::applySettings($popupId, $fieldData, $utilities, $integrationDetails, false);

        return self::successResponse(__('Popup updated successfully', 'bit-integrations-pro'), self::getPopupData($popupId));
    }

    public static function deletePopup($defaultResponse, $fieldData, $utilities = null)
    {
        if (!self::isPopupMakerActive()) {
            return self::errorResponse(\sprintf(__('%s is not installed or activated', 'bit-integrations-pro'), 'Popup Maker'));
        }

        $popupId = isset($fieldData['popup_id']) ? (int) $fieldData['popup_id'] : 0;

        if (empty($popupId) || !self::resolvePopup($popupId)) {
            return self::errorResponse(__('No popup found with the given id', 'bit-integrations-pro'));
        }

        $forceDelete = isset($utilities->selected_force_delete) && $utilities->selected_force_delete === 'yes';

        $deleted = wp_delete_post($popupId, $forceDelete);

        if (!$deleted) {
            return self::errorResponse(__('Failed to delete the popup', 'bit-integrations-pro'));
        }

        return self::successResponse(
            __('Popup deleted successfully', 'bit-integrations-pro'),
            ['popup_id' => $popupId, 'force_delete' => $forceDelete]
        );
    }

    public static function changePopupStatus($defaultResponse, $fieldData, $integrationDetails = null)
    {
        if (!self::isPopupMakerActive()) {
            return self::errorResponse(\sprintf(__('%s is not installed or activated', 'bit-integrations-pro'), 'Popup Maker'));
        }

        $popupId = isset($fieldData['popup_id']) ? (int) $fieldData['popup_id'] : 0;

        if (empty($popupId) || !self::resolvePopup($popupId)) {
            return self::errorResponse(__('No popup found with the given id', 'bit-integrations-pro'));
        }

        $status = isset($integrationDetails->selectedStatus) ? $integrationDetails->selectedStatus : '';
        $invalidStatus = self::rejectUnknownStatus($status, array_merge(self::POPUP_STATUSES, ['trash']), false);

        if (!empty($invalidStatus)) {
            return $invalidStatus;
        }

        $updated = wp_update_post(['ID' => $popupId, 'post_status' => $status], true);

        if (is_wp_error($updated)) {
            return self::errorResponse($updated->get_error_message());
        }

        return self::successResponse(__('Popup status changed successfully', 'bit-integrations-pro'), self::getPopupData($popupId));
    }

    public static function resetPopupCounts($defaultResponse, $fieldData)
    {
        if (!self::isPopupMakerActive()) {
            return self::errorResponse(\sprintf(__('%s is not installed or activated', 'bit-integrations-pro'), 'Popup Maker'));
        }

        $popupId = isset($fieldData['popup_id']) ? (int) $fieldData['popup_id'] : 0;
        $popup = $popupId ? self::resolvePopup($popupId) : null;

        if (!$popup) {
            return self::errorResponse(__('No popup found with the given id', 'bit-integrations-pro'));
        }

        if (!method_exists($popup, 'reset_counts')) {
            return self::errorResponse(__('Popup analytics reset is not supported by this Popup Maker version', 'bit-integrations-pro'));
        }

        $popup->reset_counts();

        return self::successResponse(__('Popup counts reset successfully', 'bit-integrations-pro'), self::getPopupData($popupId));
    }

    public static function trackPopupEvent($defaultResponse, $fieldData, $integrationDetails = null)
    {
        if (!self::isPopupMakerActive()) {
            return self::errorResponse(\sprintf(__('%s is not installed or activated', 'bit-integrations-pro'), 'Popup Maker'));
        }

        $popupId = isset($fieldData['popup_id']) ? (int) $fieldData['popup_id'] : 0;

        if (empty($popupId) || !self::resolvePopup($popupId)) {
            return self::errorResponse(__('No popup found with the given id', 'bit-integrations-pro'));
        }

        if (!class_exists('PUM_Analytics')) {
            return self::errorResponse(__('Popup Maker analytics is not available', 'bit-integrations-pro'));
        }

        $event = isset($integrationDetails->selectedEvent) ? $integrationDetails->selectedEvent : '';

        if (!\in_array($event, PUM_Analytics::valid_events(), true)) {
            return self::errorResponse(__('Invalid analytics event. Use open or conversion', 'bit-integrations-pro'));
        }

        $countKey = 'popup_' . $event . '_count';
        $countBefore = (int) get_post_meta($popupId, $countKey, true);

        // PUM_Analytics::track() re-emits pum_analytics_{event}, which is the very hook the
        // Popup Opened trigger listens on, so a flow that tracks an open would re-enter
        // itself. Detach the listener for the duration of the call.
        $listener = [PopupMakerController::class, 'handlePopupOpened'];
        $wasListening = remove_action('pum_analytics_' . $event, $listener, 10);

        PUM_Analytics::track(['pid' => $popupId, 'event' => $event]);

        if ($wasListening) {
            add_action('pum_analytics_' . $event, $listener, 10, 1);
        }

        // track() returns nothing and drops the event silently when Popup Maker's
        // per-visitor rate limit kicks in, so the counter is what proves it landed.
        if ((int) get_post_meta($popupId, $countKey, true) === $countBefore) {
            return self::errorResponse(__('Popup Maker did not record the event, it was most likely rate limited', 'bit-integrations-pro'));
        }

        return self::successResponse(__('Popup event tracked successfully', 'bit-integrations-pro'), self::getPopupData($popupId));
    }

    public static function createSubscriber($defaultResponse, $fieldData, $utilities = null, $integrationDetails = null)
    {
        $email = isset($fieldData['email']) ? $fieldData['email'] : '';

        if (empty($email) || !is_email($email)) {
            return self::errorResponse(__('A valid Email is required', 'bit-integrations-pro'));
        }

        $subscribers = self::subscribers();

        if (!$subscribers) {
            return self::errorResponse(__('Popup Maker subscribers table is not available', 'bit-integrations-pro'));
        }

        $data = [
            'uuid'         => wp_generate_uuid4(),
            'popup_id'     => isset($integrationDetails->selectedPopup) ? (int) $integrationDetails->selectedPopup : 0,
            'email'        => $email,
            'email_hash'   => md5($email),
            'name'         => $fieldData['name'] ?? '',
            'fname'        => $fieldData['fname'] ?? '',
            'lname'        => $fieldData['lname'] ?? '',
            'user_id'      => self::resolveUserId($email),
            'consent'      => isset($utilities->selected_consent) ? $utilities->selected_consent : 'no',
            'consent_args' => $fieldData['consent_args'] ?? '',
            'created'      => current_time('mysql'),
        ];

        $subscriberId = $subscribers->insert($data);

        if (!$subscriberId) {
            return self::errorResponse(__('Failed to create the subscriber', 'bit-integrations-pro'));
        }

        return self::successResponse(__('Subscriber created successfully', 'bit-integrations-pro'), array_merge(['ID' => $subscriberId], $data));
    }

    public static function updateSubscriber($defaultResponse, $fieldData, $utilities = null, $integrationDetails = null)
    {
        $subscriberId = isset($fieldData['subscriber_id']) ? (int) $fieldData['subscriber_id'] : 0;

        if (empty($subscriberId)) {
            return self::errorResponse(__('No subscriber found with the given id', 'bit-integrations-pro'));
        }

        $subscribers = self::subscribers();

        if (!$subscribers) {
            return self::errorResponse(__('Popup Maker subscribers table is not available', 'bit-integrations-pro'));
        }

        $subscriber = $subscribers->get($subscriberId);

        if (!$subscriber) {
            return self::errorResponse(__('No subscriber found with the given id', 'bit-integrations-pro'));
        }

        $data = self::withoutEmpty(
            [
                'email'    => $fieldData['email'] ?? '',
                'name'     => $fieldData['name'] ?? '',
                'fname'    => $fieldData['fname'] ?? '',
                'lname'    => $fieldData['lname'] ?? '',
                'popup_id' => empty($integrationDetails->selectedPopup) ? '' : (int) $integrationDetails->selectedPopup,
                'consent'  => isset($utilities->selected_consent) ? $utilities->selected_consent : '',
            ]
        );

        if (empty($data)) {
            return self::errorResponse(__('At least one field is required to update the subscriber', 'bit-integrations-pro'));
        }

        if (isset($data['email'])) {
            if (!is_email($data['email'])) {
                return self::errorResponse(__('A valid Email is required', 'bit-integrations-pro'));
            }

            $data['email_hash'] = md5($data['email']);
        }

        if (!$subscribers->update($subscriberId, $data)) {
            return self::errorResponse(__('Failed to update the subscriber', 'bit-integrations-pro'));
        }

        return self::successResponse(__('Subscriber updated successfully', 'bit-integrations-pro'), array_merge((array) $subscriber, $data));
    }

    public static function deleteSubscriber($defaultResponse, $fieldData)
    {
        $subscriberId = isset($fieldData['subscriber_id']) ? (int) $fieldData['subscriber_id'] : 0;

        if (empty($subscriberId)) {
            return self::errorResponse(__('No subscriber found with the given id', 'bit-integrations-pro'));
        }

        $subscribers = self::subscribers();

        if (!$subscribers) {
            return self::errorResponse(__('Popup Maker subscribers table is not available', 'bit-integrations-pro'));
        }

        $subscriber = $subscribers->get($subscriberId);

        if (!$subscriber) {
            return self::errorResponse(__('No subscriber found with the given id', 'bit-integrations-pro'));
        }

        if (!$subscribers->delete($subscriberId)) {
            return self::errorResponse(__('Failed to delete the subscriber', 'bit-integrations-pro'));
        }

        return self::successResponse(
            __('Subscriber deleted successfully', 'bit-integrations-pro'),
            ['subscriber_id' => $subscriberId, 'subscriber' => (array) $subscriber]
        );
    }

    private static function applySettings($popupId, $fieldData, $utilities, $integrationDetails, $fillDefaults)
    {
        $popup = self::resolvePopup($popupId);

        if (!$popup) {
            return;
        }

        if (!empty($fieldData['popup_title'])) {
            $popup->update_meta('popup_title', $fieldData['popup_title']);
        }

        $settings = [];

        if (isset($integrationDetails->selectedTheme) && $integrationDetails->selectedTheme !== '') {
            $settings['theme_id'] = $integrationDetails->selectedTheme;
        }

        if (isset($utilities->selected_size) && $utilities->selected_size !== '') {
            $settings['size'] = $utilities->selected_size;
        }

        if (isset($utilities->selected_animation_type) && $utilities->selected_animation_type !== '') {
            $settings['animation_type'] = $utilities->selected_animation_type;
        }

        if ($fillDefaults && class_exists('PUM_Admin_Popups')) {
            $settings = PUM_Admin_Popups::fill_missing_defaults($settings);
        }

        if (!empty($settings)) {
            $popup->update_settings($settings);
        }
    }

    private static function resolveUserId($email)
    {
        $user = get_user_by('email', $email);

        return $user ? (int) $user->ID : get_current_user_id();
    }

    private static function readStatus($utilities, $fallback)
    {
        return isset($utilities->selected_status) && $utilities->selected_status !== ''
            ? $utilities->selected_status
            : $fallback;
    }

    private static function rejectUnknownStatus($status, $allowedStatuses, $allowEmpty = true)
    {
        if (($allowEmpty && $status === '') || \in_array($status, $allowedStatuses, true)) {
            return;
        }

        return self::errorResponse(
            \sprintf(__('Invalid popup status. Use one of: %s', 'bit-integrations-pro'), implode(', ', $allowedStatuses))
        );
    }

    private static function withoutEmpty($data)
    {
        return array_filter(
            $data,
            static function ($value) {
                return $value !== null && $value !== '';
            }
        );
    }

    private static function getPopupData($popupId)
    {
        $data = PopupMakerHelper::getPopupData($popupId);

        if (!empty($data['popup_id'])) {
            $data['edit_link'] = get_edit_post_link($data['popup_id'], '');
        }

        return $data;
    }

    private static function resolvePopup($popupId)
    {
        if (!\function_exists('pum_get_popup') || !\function_exists('pum_is_popup')) {
            return;
        }

        $popup = pum_get_popup((int) $popupId);

        return pum_is_popup($popup) ? $popup : null;
    }

    private static function subscribers()
    {
        if (!self::isPopupMakerActive() || !class_exists('PUM_DB_Subscribers')) {
            return;
        }

        return PUM_DB_Subscribers::instance();
    }

    private static function isPopupMakerActive()
    {
        return \defined('POPMAKE_VERSION') || class_exists('PUM_Model_Popup');
    }

    private static function successResponse($message, $data = [])
    {
        return [
            'success' => true,
            'message' => $message,
            'data'    => $data
        ];
    }

    private static function errorResponse($message)
    {
        return [
            'success' => false,
            'message' => $message
        ];
    }
}
