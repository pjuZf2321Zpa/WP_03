<?php

declare(strict_types=1);

namespace FluentCartPro\App\Services\Invoice\Domain;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Immutable value object for monetary amounts.
 *
 * FluentCart stores ALL currencies with * 100 (even zero-decimal ones like JPY).
 * So amountInCents is always the DB value, and division by 100 always gives the real amount.
 */
final class Money
{
    /** ISO 4217 zero-decimal currencies */
    private const ZERO_DECIMAL = [
        'BIF', 'CLP', 'DJF', 'GNF', 'JPY', 'KMF', 'KRW', 'MGA',
        'PYG', 'RWF', 'UGX', 'VND', 'VUV', 'XAF', 'XOF', 'XPF',
    ];

    private string $currency;

    private int $amountInCents;

    public function __construct(string $currency, int $amountInCents)
    {
        $this->currency      = $currency;
        $this->amountInCents = $amountInCents;
    }

    public function getCurrency(): string
    {
        return $this->currency;
    }

    public function getAmountInCents(): int
    {
        return $this->amountInCents;
    }

    /** Cents in the currency's smallest unit: 100 for zero-decimal currencies, else 1. */
    public function minorUnitCents(): int
    {
        return $this->isZeroDecimal() ? 100 : 1;
    }

    /**
     * Convert to decimal string for XML/output.
     * Uses 0 decimals for zero-decimal currencies (JPY, KRW, etc.), 2 otherwise.
     */
    public function toDecimalString(): string
    {
        $decimals = $this->isZeroDecimal() ? 0 : 2;

        return number_format($this->amountInCents / 100, $decimals, '.', '');
    }

    /** Core rounds tax by its own decimals table; the invoice must use the same one. */
    private function isZeroDecimal(): bool
    {
        if (method_exists(\FluentCart\App\Services\Money::class, 'getDecimals')) {
            return \FluentCart\App\Services\Money::getDecimals($this->currency) === 0;
        }

        return in_array(strtoupper($this->currency), self::ZERO_DECIMAL, true);
    }
}
