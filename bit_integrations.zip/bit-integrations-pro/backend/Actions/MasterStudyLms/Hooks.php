<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Actions\MasterStudyLms\MasterStudyLmsProHelper;
use BitApps\IntegrationsPro\Config;
use BitApps\IntegrationsPro\Core\Util\Hooks;

Hooks::filter(Config::withFreePrefix('master_study_lms_enroll_user'), [MasterStudyLmsProHelper::class, 'enrollUser'], 10, 2);
Hooks::filter(Config::withFreePrefix('master_study_lms_unenroll_user'), [MasterStudyLmsProHelper::class, 'unenrollUser'], 10, 2);
Hooks::filter(Config::withFreePrefix('master_study_lms_mark_course_complete'), [MasterStudyLmsProHelper::class, 'markCourseComplete'], 10, 2);
Hooks::filter(Config::withFreePrefix('master_study_lms_mark_lesson_complete'), [MasterStudyLmsProHelper::class, 'markLessonComplete'], 10, 2);
