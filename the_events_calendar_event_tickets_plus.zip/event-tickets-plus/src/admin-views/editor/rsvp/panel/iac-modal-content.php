<?php
/**
 * RSVP V2 IAC Modal Content template.
 *
 * Contains the attendee information collection form for RSVP tickets.
 *
 * @since 6.11.0
 *
 * @version 6.11.0
 *
 * @var Tribe__Tickets_Plus__Admin__Views                  $this                [Global] Template object.
 * @var int                                                $post_id             The post ID.
 * @var int                                                $ticket_id           The ticket ID.
 * @var array                                              $iac_options         Available IAC options.
 * @var string                                             $selected            Current IAC option for the ticket.
 * @var array                                              $field_types         Available field types.
 * @var array                                              $saved_fieldsets     Saved fieldsets.
 * @var Tribe__Tickets_Plus__Meta__Field__Abstract_Field[] $current_meta_fields Current meta fields for this ticket.
 */

defined( 'ABSPATH' ) || exit;

$meta_object = tribe( 'tickets-plus.meta' );

$classes = [
	'eventtable',
	'tribe-tickets-attendee-info-form',
	'ticket_advanced',
	'ticket_advanced_meta',
	'tec-tickets-rsvp-iac-modal-content',
];

?>
<div
	id="tribe-tickets-rsvp-attendee-info-form"
	<?php tec_classes( $classes ); ?>
>
	<p class="tribe-intro">
		<?php esc_html_e( 'Select the default way to collect RSVPs. Enabling Individual Attendee Collection will allow respondents to enter a name and email for each RSVP.', 'event-tickets-plus' ); ?>
	</p>

	<div class="tec-tickets-rsvp-iac-options">
		<?php foreach ( $iac_options as $value => $label ) : ?>
			<div class="input_block">
				<input
					type="radio"
					name="ticket_iac"
					id="ticket_iac_setting_<?php echo esc_attr( sanitize_title_with_dashes( $value ) ); ?>"
					value="<?php echo esc_attr( $value ); ?>"
					<?php checked( $value, $selected ); ?>
				/>
				<label for="ticket_iac_setting_<?php echo esc_attr( sanitize_title_with_dashes( $value ) ); ?>">
					<?php echo esc_html( $label ); ?>
				</label>
			</div>
		<?php endforeach; ?>
	</div>

	<table class="eventtable">
		<tr class="tribe-attendee-fields-box">
			<td class='tribe-attendee-fields-new'>
				<?php
				$this->template(
					'attendee-meta/fields-new',
					[
						'ticket_id'     => $ticket_id,
						'field_types'   => $field_types,
						'fieldset_form' => false,
					]
				);
				?>
			</td>
			<td class='tribe-attendee-fields-existing'>
				<?php
				$this->template(
					'attendee-meta/fields-existing',
					[
						'ticket_id'     => $ticket_id,
						'templates'     => $saved_fieldsets,
						'active_meta'   => $current_meta_fields,
						'meta_object'   => $meta_object,
						'fieldset_form' => false,
					]
				);
				?>
			</td>
		</tr>
	</table>

	<div class="tec-tickets-rsvp-iac-modal-actions">
		<button
			type="button"
			class="button button-primary tec-tickets-rsvp-iac-save"
			data-post-id="<?php echo esc_attr( $post_id ); ?>"
			data-ticket-id="<?php echo esc_attr( $ticket_id ); ?>"
		>
			<?php esc_html_e( 'Save', 'event-tickets-plus' ); ?>
		</button>
		<button
			type="button"
			class="button button-secondary tec-tickets-rsvp-iac-cancel"
		>
			<?php esc_html_e( 'Cancel', 'event-tickets-plus' ); ?>
		</button>
	</div>
</div>
