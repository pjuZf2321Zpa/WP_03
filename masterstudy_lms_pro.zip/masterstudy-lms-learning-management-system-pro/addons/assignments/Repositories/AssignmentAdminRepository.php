<?php

namespace MasterStudy\Lms\Pro\addons\assignments\Repositories;

use MasterStudy\Lms\Database\CurriculumMaterial;
use MasterStudy\Lms\Database\CurriculumSection;
use MasterStudy\Lms\Plugin\PostType;
use MasterStudy\Lms\Repositories\CurriculumRepository;
use MasterStudy\Lms\Utility\WpDate;
use MasterStudy\Lms\Utility\Wpml;
use RuntimeException;
use WP_Query;

final class AssignmentAdminRepository {
	private const ERROR_BAD_REQUEST           = 400;
	private const ERROR_FORBIDDEN             = 403;
	private const MAX_PER_PAGE                = 100;
	private const ALLOWED_STATUSES            = array( 'publish', 'pending', 'draft', 'trash', 'private' );
	private const ALLOWED_SUBMISSION_STATUSES = array( 'passed', 'not_passed', 'pending' );
	private const ALLOWED_SORTS               = array( 'title', 'course', 'total', 'passed', 'not_passed', 'pending', 'date' );
	private const COUNT_SORT_STATUSES         = array(
		'passed'     => AssignmentStudentRepository::STATUS_PASSED,
		'not_passed' => AssignmentStudentRepository::STATUS_NOT_PASSED,
		'pending'    => AssignmentStudentRepository::STATUS_PENDING,
	);
	private const MAX_BULK_ITEMS              = 100;

	public function get_list( array $params ): array {
		$per_page          = min( self::MAX_PER_PAGE, max( 1, (int) ( $params['per_page'] ?? 10 ) ) );
		$page              = max( 1, (int) ( $params['page'] ?? 1 ) );
		$search            = isset( $params['search'] ) ? trim( (string) $params['search'] ) : '';
		$status            = isset( $params['status'] ) ? (string) $params['status'] : 'any';
		$assignment_status = isset( $params['assignment_status'] ) ? sanitize_text_field( (string) $params['assignment_status'] ) : '';
		$lang              = isset( $params['lang'] ) ? sanitize_key( (string) $params['lang'] ) : '';
		$post_type         = get_post_type_object( PostType::ASSIGNMENT );

		$query_args = array(
			'post_type'              => PostType::ASSIGNMENT,
			'post_status'            => 'any' === $status ? self::ALLOWED_STATUSES : $status,
			'ignore_sticky_posts'    => true,
			'posts_per_page'         => $per_page,
			'paged'                  => $page,
			'no_found_rows'          => false,
			'update_post_meta_cache' => false,
			'update_post_term_cache' => false,
		);

		$query_args = array_merge( $query_args, Wpml::query_language_args( $lang ) );

		if ( in_array( $assignment_status, self::ALLOWED_SUBMISSION_STATUSES, true ) ) {
			$assignment_ids_by_status = $this->get_assignment_ids_by_submission_status( $assignment_status );

			if ( empty( $assignment_ids_by_status ) ) {
				return array(
					'posts'             => array(),
					'pages'             => 0,
					'current_page'      => $page,
					'total_assignments' => 0,
				);
			}

			$query_args['post__in'] = $assignment_ids_by_status;
		}

		if ( '' !== $search ) {
			$query_args['s'] = $search;
		}

		$date_range = isset( $params['date_range'] ) ? trim( (string) $params['date_range'] ) : '';
		if ( '' !== $date_range ) {
			$range = WpDate::date_range_to_gmt_bounds( $date_range );

			if ( $range['after'] || $range['before'] ) {
				$date_query = array(
					'inclusive' => true,
					'column'    => 'post_modified_gmt',
				);

				if ( $range['after'] ) {
					$date_query['after'] = $range['after'];
				}

				if ( $range['before'] ) {
					$date_query['before'] = $range['before'];
				}

				$query_args['date_query'] = array( $date_query );
			}
		}

		if ( $post_type && ! current_user_can( $post_type->cap->edit_others_posts ) ) {
			$query_args['author'] = get_current_user_id();
		}

		$sort        = isset( $params['sort'] ) ? trim( (string) $params['sort'] ) : '';
		$sort_params = '' === $sort
			? array(
				'key'       => 'date',
				'direction' => 'DESC',
			)
			: $this->parse_sort( $sort );
		$orderby_sql = $this->apply_sorting( $query_args, $sort_params['key'], $sort_params['direction'] );

		$query          = $this->get_list_query( $query_args, $orderby_sql );
		$assignment_ids = wp_list_pluck( $query->posts, 'ID' );
		$course_ids_map = ( new CurriculumRepository() )->get_course_ids_by_post_ids( $assignment_ids );
		$course_titles  = $this->get_course_titles_map( $course_ids_map );
		$counts_map     = $this->get_submission_counts( $assignment_ids );

		foreach ( $query->posts as $post ) {
			$post_course_ids = $course_ids_map[ $post->ID ] ?? array();
			$post->courses   = array_values(
				array_filter(
					array_map(
						static function ( int $course_id ) use ( $course_titles ) {
							if ( empty( $course_titles[ $course_id ] ) ) {
								return null;
							}

							return array(
								'id'    => $course_id,
								'title' => $course_titles[ $course_id ],
							);
						},
						$post_course_ids
					)
				)
			);

			$post->total      = (int) ( $counts_map[ $post->ID ]['total'] ?? 0 );
			$post->passed     = (int) ( $counts_map[ $post->ID ]['passed'] ?? 0 );
			$post->not_passed = (int) ( $counts_map[ $post->ID ]['not_passed'] ?? 0 );
			$post->pending    = (int) ( $counts_map[ $post->ID ]['pending'] ?? 0 );
		}

		return array(
			'posts'             => $query->posts,
			'pages'             => (int) $query->max_num_pages,
			'current_page'      => $page,
			'total_assignments' => (int) $query->found_posts,
		);
	}

	private function get_list_query( array $query_args, string $orderby_sql = '' ): WP_Query {
		if ( '' === $orderby_sql ) {
			return new WP_Query( $query_args );
		}

		$query_args['masterstudy_assignment_custom_order'] = true;

		$orderby_filter = static function ( $orderby, $query ) use ( $orderby_sql ) {
			return $query->get( 'masterstudy_assignment_custom_order' ) ? $orderby_sql : $orderby;
		};

		add_filter( 'posts_orderby', $orderby_filter, 10, 2 );

		try {
			return new WP_Query( $query_args );
		} finally {
			remove_filter( 'posts_orderby', $orderby_filter, 10 );
		}
	}

	private function parse_sort( string $sort ): array {
		$sort      = trim( $sort );
		$direction = 'ASC';

		if ( isset( $sort[0] ) && '-' === $sort[0] ) {
			$direction = 'DESC';
			$sort      = substr( $sort, 1 );
		}

		$key = sanitize_key( $sort );

		if ( ! in_array( $key, self::ALLOWED_SORTS, true ) ) {
			$key = 'date';
		}

		return array(
			'key'       => $key,
			'direction' => $direction,
		);
	}

	private function apply_sorting( array &$query_args, string $key, string $direction ): string {
		$direction = $this->normalize_direction( $direction );

		if ( 'title' === $key ) {
			$query_args['orderby'] = 'title';
			$query_args['order']   = $direction;

			return '';
		}

		$query_args['orderby'] = 'none';
		$query_args['order']   = $direction;

		if ( 'course' === $key ) {
			return $this->get_course_orderby_sql( $direction );
		}

		return 'date' === $key
			? WpDate::modified_gmt_posts_orderby_sql( $direction )
			: $this->get_count_orderby_sql( $key, $direction );
	}

	private function normalize_direction( string $direction ): string {
		return 'DESC' === strtoupper( $direction ) ? 'DESC' : 'ASC';
	}

	private function get_course_orderby_sql( string $direction ): string {
		global $wpdb;

		$materials_table = esc_sql( ( new CurriculumMaterial() )->get_table() );
		$sections_table  = esc_sql( ( new CurriculumSection() )->get_table() );
		$posts_table     = esc_sql( $wpdb->posts );

		return "(SELECT MIN(course_posts.post_title)
			FROM {$materials_table} AS materials
			INNER JOIN {$sections_table} AS sections ON sections.id = materials.section_id
			INNER JOIN {$posts_table} AS course_posts ON course_posts.ID = sections.course_id
			WHERE materials.post_id = {$posts_table}.ID
		) {$direction}, {$posts_table}.ID DESC";
	}

	private function get_count_orderby_sql( string $key, string $direction ): string {
		global $wpdb;

		$status      = self::COUNT_SORT_STATUSES[ $key ] ?? '';
		$posts_table = esc_sql( $wpdb->posts );
		$table_name  = esc_sql( $wpdb->prefix . 'stm_lms_user_assignments' );

		if ( 'total' === $key ) {
			return $wpdb->prepare(
				// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				"(SELECT COUNT(*) FROM {$table_name}
					WHERE assignment_id = {$posts_table}.ID
					AND status != %s
				) {$direction}, {$posts_table}.ID DESC",
				// phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				'trash'
			);
		}

		return '' !== $status ? $wpdb->prepare(
			// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			"(SELECT COUNT(*) FROM {$table_name}
				WHERE assignment_id = {$posts_table}.ID
				AND status = %s
			) {$direction}, {$posts_table}.ID DESC",
			// phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			$status
		) : '';
	}

	public function bulk_delete( array $assignments ): void {
		if ( count( $assignments ) > self::MAX_BULK_ITEMS ) {
			throw new RuntimeException(
				sprintf(
					/* translators: %d: maximum number of assignments allowed in one bulk request. */
					esc_html__( 'Too many assignments in one request. Maximum allowed is %d.', 'masterstudy-lms-learning-management-system-pro' ),
					self::MAX_BULK_ITEMS
				),
				self::ERROR_BAD_REQUEST
			);
		}

		foreach ( $assignments as $assignment ) {
			$assignment_id = $this->resolve_assignment_id( $assignment );

			if ( ! $assignment_id || PostType::ASSIGNMENT !== get_post_type( $assignment_id ) ) {
				throw new RuntimeException(
					esc_html__( 'Invalid assignment provided for bulk delete.', 'masterstudy-lms-learning-management-system-pro' ),
					self::ERROR_BAD_REQUEST
				);
			}

			if ( ! current_user_can( 'delete_post', $assignment_id ) ) {
				throw new RuntimeException(
					esc_html__( 'You do not have permission to delete this assignment.', 'masterstudy-lms-learning-management-system-pro' ),
					self::ERROR_FORBIDDEN
				);
			}

			$result = wp_delete_post( $assignment_id, true );

			if ( false === $result || null === $result ) {
				throw new RuntimeException(
					sprintf(
						/* translators: %d: assignment ID. */
						esc_html__( 'Unable to delete assignment %d.', 'masterstudy-lms-learning-management-system-pro' ),
						$assignment_id
					)
				);
			}
		}
	}

	public function update_status( int $assignment_id, string $status ): void {
		if ( PostType::ASSIGNMENT !== get_post_type( $assignment_id ) ) {
			throw new RuntimeException(
				esc_html__( 'Invalid assignment provided for status update.', 'masterstudy-lms-learning-management-system-pro' ),
				self::ERROR_BAD_REQUEST
			);
		}

		if ( ! current_user_can( 'edit_post', $assignment_id ) ) {
			throw new RuntimeException(
				esc_html__( 'You do not have permission to edit this assignment.', 'masterstudy-lms-learning-management-system-pro' ),
				self::ERROR_FORBIDDEN
			);
		}

		if ( 'trash' === get_post_status( $assignment_id ) ) {
			$untrashed = wp_untrash_post( $assignment_id );
			if ( ! $untrashed ) {
				throw new RuntimeException(
					esc_html__( 'Unable to restore assignment from trash.', 'masterstudy-lms-learning-management-system-pro' )
				);
			}
		}

		$updated = wp_update_post(
			array(
				'ID'          => $assignment_id,
				'post_status' => $status,
			),
			true
		);

		if ( is_wp_error( $updated ) ) {
			throw new RuntimeException( $updated->get_error_message() );
		}
	}

	public function bulk_update_status( array $assignments, string $status ): void {
		if ( count( $assignments ) > self::MAX_BULK_ITEMS ) {
			throw new RuntimeException(
				sprintf(
					/* translators: %d: maximum number of assignments allowed in one bulk request. */
					esc_html__( 'Too many assignments in one request. Maximum allowed is %d.', 'masterstudy-lms-learning-management-system-pro' ),
					self::MAX_BULK_ITEMS
				),
				self::ERROR_BAD_REQUEST
			);
		}

		foreach ( $assignments as $assignment ) {
			$assignment_id = $this->resolve_assignment_id( $assignment );

			$this->update_status( $assignment_id, $status );
		}
	}

	/**
	 * @param mixed $assignment
	 */
	private function resolve_assignment_id( $assignment ): int {
		if ( is_numeric( $assignment ) ) {
			return (int) $assignment;
		}

		if ( is_array( $assignment ) && isset( $assignment['id'] ) ) {
			return (int) $assignment['id'];
		}

		return 0;
	}

	/**
	 * @param array<int, array<int, int>> $course_ids_map
	 *
	 * @return array<int, string>
	 */
	private function get_course_titles_map( array $course_ids_map ): array {
		global $wpdb;

		$course_ids = array();

		foreach ( $course_ids_map as $course_ids_by_assignment ) {
			foreach ( $course_ids_by_assignment as $course_id ) {
				$course_ids[ $course_id ] = $course_id;
			}
		}

		if ( empty( $course_ids ) ) {
			return array();
		}

		$course_ids   = array_values( $course_ids );
		$posts_table  = esc_sql( $wpdb->posts );
		$placeholders = implode( ',', array_fill( 0, count( $course_ids ), '%d' ) );
		$params       = array_merge( array( PostType::COURSE ), $course_ids );
		$courses      = $wpdb->get_results(
			$wpdb->prepare(
				// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare
				"SELECT ID, post_title FROM {$posts_table} WHERE post_type = %s AND ID IN ({$placeholders})",
				$params
				// phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare
			),
			ARRAY_A
		);

		$titles = array();

		if ( ! is_array( $courses ) ) {
			return $titles;
		}

		foreach ( $courses as $course ) {
			$course_id = isset( $course['ID'] ) ? (int) $course['ID'] : 0;

			if ( $course_id <= 0 ) {
				continue;
			}

			$titles[ $course_id ] = isset( $course['post_title'] )
				? html_entity_decode( (string) $course['post_title'], ENT_QUOTES | ENT_HTML5, 'UTF-8' )
				: '';
		}

		return $titles;
	}

	/**
	 * @param array<int, int> $assignment_ids
	 *
	 * @return array<int, array{total: int, passed: int, not_passed: int, pending: int}>
	 */
	private function get_submission_counts( array $assignment_ids ): array {
		global $wpdb;

		$assignment_ids = array_values(
			array_filter(
				array_map( 'absint', $assignment_ids )
			)
		);

		if ( empty( $assignment_ids ) ) {
			return array();
		}

		$counts       = array();
		$table_name   = esc_sql( $wpdb->prefix . 'stm_lms_user_assignments' );
		$placeholders = implode( ',', array_fill( 0, count( $assignment_ids ), '%d' ) );
		$params       = array_merge(
			array(
				'trash',
				AssignmentStudentRepository::STATUS_PASSED,
				AssignmentStudentRepository::STATUS_NOT_PASSED,
				AssignmentStudentRepository::STATUS_PENDING,
			),
			$assignment_ids
		);

		$results = $wpdb->get_results(
        // phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare,WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber
			$wpdb->prepare(
				"SELECT assignment_id,
					SUM(CASE WHEN status != %s THEN 1 ELSE 0 END) AS total,
					SUM(CASE WHEN status = %s THEN 1 ELSE 0 END) AS passed,
					SUM(CASE WHEN status = %s THEN 1 ELSE 0 END) AS not_passed,
					SUM(CASE WHEN status = %s THEN 1 ELSE 0 END) AS pending
				FROM {$table_name}
				WHERE assignment_id IN ({$placeholders})
				GROUP BY assignment_id",
				$params
			),
            // phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare
			ARRAY_A
		);

		if ( ! is_array( $results ) ) {
			return $counts;
		}

		foreach ( $results as $result ) {
			$assignment_id = isset( $result['assignment_id'] ) ? absint( $result['assignment_id'] ) : 0;

			if ( ! $assignment_id ) {
				continue;
			}

			$counts[ $assignment_id ] = array(
				'total'      => isset( $result['total'] ) ? (int) $result['total'] : 0,
				'passed'     => isset( $result['passed'] ) ? (int) $result['passed'] : 0,
				'not_passed' => isset( $result['not_passed'] ) ? (int) $result['not_passed'] : 0,
				'pending'    => isset( $result['pending'] ) ? (int) $result['pending'] : 0,
			);
		}

		return $counts;
	}

	/**
	 * @return array<int, int>
	 */
	private function get_assignment_ids_by_submission_status( string $status ): array {
		global $wpdb;

		if ( ! in_array( $status, self::ALLOWED_SUBMISSION_STATUSES, true ) ) {
			return array();
		}

		$table_name = esc_sql( $wpdb->prefix . 'stm_lms_user_assignments' );

		$assignment_ids = $wpdb->get_col(
			$wpdb->prepare(
				// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				"SELECT DISTINCT assignment_id FROM {$table_name} WHERE status = %s AND assignment_id > 0",
				$status
                // phpcs:enable
			)
		);

		if ( ! is_array( $assignment_ids ) ) {
			return array();
		}

		return array_values(
			array_filter(
				array_map( 'absint', $assignment_ids )
			)
		);
	}
}
