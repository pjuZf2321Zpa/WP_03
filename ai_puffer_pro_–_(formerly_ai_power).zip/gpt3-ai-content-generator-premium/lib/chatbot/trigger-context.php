<?php

namespace WPAICG\Lib\Chat\Triggers\Actions;

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

/**
 * AIPKit_Placeholder_Processor
 *
 * Handles replacing placeholders in string templates with context data.
 */
class AIPKit_Placeholder_Processor {

    const LOG_SNIPPET_LENGTH = 75; // Max length for snippets in log_summary mode
    private const DYNAMIC_FORM_PLACEHOLDER_REGEX = '/\{\{(submitted|submitted_display|submitted_label)\.([^{}\s]+)\}\}/';
    private const DYNAMIC_FORM_PLACEHOLDER_EXACT_REGEX = '/^\{\{(submitted|submitted_display|submitted_label)\.([^{}\s]+)\}\}$/';
    private const EXACT_PLACEHOLDER_REGEX = '/^\{\{[^{}\s]+\}\}$/';

    /**
     * Normalize any mixed value into a string for placeholder replacement.
     *
     * @param mixed $value
     * @return string
     */
    private static function stringify_value($value): string {
        if (is_array($value)) {
            $parts = [];
            foreach ($value as $item) {
                $item_string = self::stringify_value($item);
                if ($item_string !== '') {
                    $parts[] = $item_string;
                }
            }
            return implode(', ', $parts);
        }

        if (is_bool($value)) {
            return $value ? '1' : '0';
        }
        if ($value === null) {
            return '';
        }
        if (is_scalar($value)) {
            return (string) $value;
        }

        $encoded = wp_json_encode($value, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        return is_string($encoded) ? $encoded : '';
    }

    /**
     * Output formatting by mode.
     *
     * @param string $value
     * @param string $mode
     * @return string
     */
    private static function format_for_mode(string $value, string $mode): string {
        if ($mode === 'display') {
            return esc_html($value);
        }
        return $value;
    }

    /**
     * Build submitted form datasets and JSON representations used by placeholders.
     *
     * @param array $context_data
     * @return array{submitted_data:array,submitted_data_display:array,submitted_data_labels:array,submitted_data_json:string,submitted_data_display_json:string,submitted_data_labels_json:string}
     */
    private static function get_submitted_data_context(array $context_data): array {
        $submitted_data = isset($context_data['submitted_data']) && is_array($context_data['submitted_data'])
            ? $context_data['submitted_data']
            : [];
        $submitted_data_display = isset($context_data['submitted_data_display']) && is_array($context_data['submitted_data_display'])
            ? $context_data['submitted_data_display']
            : $submitted_data;
        $submitted_data_labels = isset($context_data['submitted_data_labels']) && is_array($context_data['submitted_data_labels'])
            ? $context_data['submitted_data_labels']
            : [];

        $submitted_context = [
            'submitted_data' => $submitted_data,
            'submitted_data_display' => $submitted_data_display,
            'submitted_data_labels' => $submitted_data_labels,
        ];

        foreach ([
            'submitted_data' => '[Form Data]',
            'submitted_data_display' => '[Form Data]',
            'submitted_data_labels' => '{}',
        ] as $key => $fallback) {
            $json_key = $key . '_json';
            $json = $context_data[$json_key] ?? wp_json_encode($submitted_context[$key], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
            $submitted_context[$json_key] = is_string($json) && $json !== '' ? $json : $fallback;
        }

        return $submitted_context;
    }

    /**
     * Build raw placeholder map from context.
     *
     * @param array $context_data
     * @return array<string,mixed>
     */
    private static function build_placeholder_map(array $context_data): array {
        $submitted_context = self::get_submitted_data_context($context_data);
        $user_id = isset($context_data['user_id']) ? absint($context_data['user_id']) : 0;

        $placeholder_map = [
            '{{user_id}}' => $context_data['user_id'] ?? 'guest',
            '{{bot_id}}' => $context_data['bot_id'] ?? 'unknown',
            '{{bot_name}}' => $context_data['bot_settings']['name'] ?? 'Chatbot',
            '{{post_id}}' => $context_data['post_id'] ?? '0',
            '{{post_title}}' => (isset($context_data['post_id']) && (int) $context_data['post_id'] > 0) ? get_the_title((int) $context_data['post_id']) : '',
            '{{user_ip}}' => $context_data['client_ip'] ?? '',
            '{{form_id}}' => $context_data['form_id'] ?? '',
            '{{form_submission_summary}}' => $context_data['form_submission_summary'] ?? '',
            '{{user_message_text}}' => $context_data['user_message_text'] ?? '',
            '{{submitted_data_json}}' => $submitted_context['submitted_data_json'],
            '{{submitted_data_display_json}}' => $submitted_context['submitted_data_display_json'],
            '{{submitted_data_labels_json}}' => $submitted_context['submitted_data_labels_json'],
        ];

        if ($user_id > 0) {
            $user_info = get_userdata($user_id);
            $placeholder_map['{{user_name}}'] = $user_info ? $user_info->display_name : 'User';
        } else {
            $placeholder_map['{{user_name}}'] = 'Guest';
        }

        return $placeholder_map;
    }

    /**
     * Resolve a dynamic form placeholder to its original value.
     *
     * @param string $group
     * @param string $field_key_raw
     * @param array $submitted_data
     * @param array $submitted_data_display
     * @param array $submitted_data_labels
     * @param bool|null $found
     * @return mixed
     */
    private static function resolve_dynamic_form_placeholder_value(
        string $group,
        string $field_key_raw,
        array $submitted_data,
        array $submitted_data_display,
        array $submitted_data_labels,
        ?bool &$found = null
    ) {
        if ($field_key_raw === '') {
            $found = false;
            return '';
        }

        $source = [];
        if ($group === 'submitted') {
            $source = $submitted_data;
        } elseif ($group === 'submitted_display') {
            $source = $submitted_data_display;
        } elseif ($group === 'submitted_label') {
            $source = $submitted_data_labels;
        }

        $lookup_keys = array_unique([
            (string) $field_key_raw,
            sanitize_text_field((string) $field_key_raw),
            sanitize_key((string) $field_key_raw),
        ]);

        foreach ($lookup_keys as $lookup_key) {
            if ($lookup_key === '' || !array_key_exists($lookup_key, $source)) {
                continue;
            }

            $found = true;
            return $source[$lookup_key];
        }

        $found = false;
        return '';
    }

    /**
     * Normalize a placeholder token into {{token}} format.
     *
     * @param string $placeholder_token
     * @return string
     */
    private static function normalize_placeholder_token(string $placeholder_token): string {
        $normalized = trim($placeholder_token);
        if ($normalized === '') {
            return '';
        }

        if (strncmp($normalized, '{{', strlen('{{')) !== 0) {
            $normalized = '{{' . $normalized;
        }
        if (substr_compare($normalized, '}}', -strlen('}}')) !== 0) {
            $normalized .= '}}';
        }

        return $normalized;
    }

    /**
     * Resolve a single placeholder token to its raw typed value.
     *
     * Returns null when the token is unknown.
     *
     * @param string $placeholder_token Placeholder token (e.g., {{user_id}} or submitted.field_id)
     * @param array $context_data
     * @return mixed|null
     */
    public static function resolve_placeholder_value(string $placeholder_token, array $context_data) {
        $normalized_token = self::normalize_placeholder_token($placeholder_token);
        if ($normalized_token === '' || !preg_match(self::EXACT_PLACEHOLDER_REGEX, $normalized_token)) {
            return null;
        }

        $submitted_context = self::get_submitted_data_context($context_data);

        if (preg_match(self::DYNAMIC_FORM_PLACEHOLDER_EXACT_REGEX, $normalized_token, $matches)) {
            $found = false;
            $resolved = self::resolve_dynamic_form_placeholder_value(
                $matches[1] ?? '',
                $matches[2] ?? '',
                $submitted_context['submitted_data'],
                $submitted_context['submitted_data_display'],
                $submitted_context['submitted_data_labels'],
                $found
            );

            return $found ? $resolved : null;
        }

        $placeholder_map = self::build_placeholder_map($context_data);
        if (!array_key_exists($normalized_token, $placeholder_map)) {
            return null;
        }

        return $placeholder_map[$normalized_token];
    }

    /**
     * Replace dynamic form placeholders:
     * - {{submitted.field_id}}
     * - {{submitted_display.field_id}}
     * - {{submitted_label.field_id}}
     *
     * @param string $template
     * @param array $context_data
     * @param string $mode
     * @return string
     */
    private static function resolve_dynamic_form_placeholders(string $template, array $context_data, string $mode): string {
        $submitted_context = self::get_submitted_data_context($context_data);

        $resolved_string = preg_replace_callback(
            self::DYNAMIC_FORM_PLACEHOLDER_REGEX,
            static function (array $matches) use ($submitted_context, $mode) {
                $found = false;
                $resolved = self::resolve_dynamic_form_placeholder_value(
                    (string) ($matches[1] ?? ''),
                    (string) ($matches[2] ?? ''),
                    $submitted_context['submitted_data'],
                    $submitted_context['submitted_data_display'],
                    $submitted_context['submitted_data_labels'],
                    $found
                );

                if (!$found) {
                    return '';
                }

                return self::format_for_mode(self::stringify_value($resolved), $mode);
            },
            $template
        );

        return is_string($resolved_string) ? $resolved_string : $template;
    }

    /**
     * Replaces placeholders in a string with values from context_data.
     * Example placeholders: {{user_message_text}}, {{user_name}}, {{bot_name}}.
     *
     * @param string $template The string template with placeholders.
     * @param array  $context_data Associative array of context data.
     * @param string $mode 'display' (default) for user-facing output, 'log_summary' for concise log messages, 'raw' for non-HTML output (e.g., webhooks).
     * @return string The processed string.
     */
    public static function process(string $template, array $context_data, string $mode = 'display'): string {
        $processed_string = $template;

        $placeholder_map = self::build_placeholder_map($context_data);

        // Mode-specific handling for sensitive/long placeholders
        if ($mode === 'log_summary') {
            $user_message_raw = self::stringify_value($placeholder_map['{{user_message_text}}'] ?? '');
            $placeholder_map['{{user_message_text}}'] = '[User Message Snippet: ' . mb_substr($user_message_raw, 0, self::LOG_SNIPPET_LENGTH) . (mb_strlen($user_message_raw) > self::LOG_SNIPPET_LENGTH ? '...' : '') . ']';
            $placeholder_map['{{submitted_data_json}}'] = '[Form Data Submitted - See Details]';
            $placeholder_map['{{submitted_data_display_json}}'] = '[Form Data Submitted - Display Mapping]';
            $placeholder_map['{{submitted_data_labels_json}}'] = '[Form Labels Mapping]';
        }

        // Dynamic placeholders for specific form fields.
        $processed_string = self::resolve_dynamic_form_placeholders($processed_string, $context_data, $mode);

        foreach ($placeholder_map as $placeholder => $value) {
            $replacement_value = self::format_for_mode(self::stringify_value($value), $mode);
            $processed_string = str_replace($placeholder, $replacement_value, $processed_string);
        }

        return $processed_string;
    }
}
