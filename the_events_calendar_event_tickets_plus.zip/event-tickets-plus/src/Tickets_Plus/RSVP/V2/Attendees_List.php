<?php
/**
 * Attendees List visibility handler for RSVP V2.
 *
 * @since 6.11.0
 *
 * @package TEC\Tickets_Plus\RSVP\V2
 */

namespace TEC\Tickets_Plus\RSVP\V2;

/**
 * Class Attendees_List
 *
 * Controls visibility of attendees list and opt-out option for RSVP V2.
 *
 * @since 6.11.0
 *
 * @package TEC\Tickets_Plus\RSVP\V2
 */
class Attendees_List {
	// phpcs:disable Generic.CodeAnalysis.UnusedFunctionParameter.FoundAfterLastUsed

	/**
	 * Filter to show or hide attendees list opt-out based on ticket meta.
	 *
	 * @since 6.11.0
	 *
	 * @param bool $hide_attendee_list_optout Whether to hide attendees list opt-out.
	 * @param int  $post_id                   The post ID that the ticket belongs to.
	 * @param int  $ticket_id                 The ticket ID.
	 *
	 * @return bool Whether to show attendees list opt-out.
	 */
	public function filter_show_optout( bool $hide_attendee_list_optout, int $post_id, int $ticket_id ): bool {
		return tribe_is_truthy( get_post_meta( $post_id, Constants::SHOW_RSVP_META_KEY, true ) );
	}

	// phpcs:enable Generic.CodeAnalysis.UnusedFunctionParameter.FoundAfterLastUsed

	/**
	 * Filter the attendees list visibility for RSVPs.
	 *
	 * @since 6.11.0
	 *
	 * @param bool         $is_hidden Whether the attendees list is hidden.
	 * @param \WP_Post|int $post      The post object or post ID.
	 *
	 * @return bool Whether the attendees list should be hidden.
	 */
	public function filter_visibility( bool $is_hidden, $post ): bool {
		if ( ! $is_hidden ) {
			return false;
		}

		$post_id = is_object( $post ) && isset( $post->ID ) ? $post->ID : $post;

		$show_rsvp_meta_key  = Constants::SHOW_RSVP_META_KEY;
		$show_rsvp_attendees = get_post_meta( $post_id, $show_rsvp_meta_key, true );

		if ( metadata_exists( 'post', $post_id, $show_rsvp_meta_key ) ) {
			return empty( $show_rsvp_attendees );
		}

		return true;
	}
}
