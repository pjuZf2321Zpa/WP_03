<?php

namespace MasterStudy\Lms\Pro\AddonsPlus\Notifications;

use MasterStudy\Lms\Plugin;
use MasterStudy\Lms\Plugin\Addon;
use MasterStudy\Lms\Plugin\Addons;
use MasterStudy\Lms\Pro\AddonsPlus\Notifications\Services\Cleanup;
use MasterStudy\Lms\Pro\AddonsPlus\Notifications\Services\CourseAccessExpirationSweep;
use MasterStudy\Lms\Pro\AddonsPlus\Notifications\Services\Push\QueueWorker;
use MasterStudy\Lms\Pro\AddonsPlus\Notifications\Services\Push\ServiceWorker;
use MasterStudy\Lms\Pro\AddonsPlus\Notifications\Services\QueueRecovery;
use MasterStudy\Lms\Pro\AddonsPlus\Notifications\Services\RecipientFanoutWorker;

final class Notifications implements Addon {
	public function get_name(): string {
		return defined( Addons::class . '::NOTIFICATIONS' )
			? Addons::NOTIFICATIONS
			: 'notifications';
	}

	public function register( Plugin $plugin ): void {
		$plugin->load_file( __DIR__ . '/Events.php' );
		$plugin->load_file( __DIR__ . '/Frontend.php' );
		$plugin->load_file( __DIR__ . '/Settings/main.php' );
		$plugin->load_file( __DIR__ . '/Database/notifications.php' );
		$plugin->load_file( __DIR__ . '/Database/notification_recipients.php' );
		$plugin->load_file( __DIR__ . '/Database/notification_push_subscriptions.php' );
		$plugin->load_file( __DIR__ . '/Database/notification_push_queue.php' );
		$plugin->load_file( __DIR__ . '/Database/notification_dispatch_queue.php' );
		$plugin->load_file( __DIR__ . '/Database/tables.php' );
		$plugin->get_router()->load_routes( __DIR__ . '/routes.php' );

		EventListeners::register();
		ServiceWorker::register();

		add_action( 'masterstudy_notifications_process_recipient_fanout', array( RecipientFanoutWorker::class, 'process' ) );
		add_action( 'masterstudy_notifications_process_push_queue', array( QueueWorker::class, 'process' ) );
		add_action( 'masterstudy_notifications_recover_queues', array( QueueRecovery::class, 'process' ) );
		add_action( 'masterstudy_notifications_course_access_expiration_sweep', array( CourseAccessExpirationSweep::class, 'process' ) );
		add_action( Cleanup::HOOK, array( Cleanup::class, 'process' ) );
		add_action( 'masterstudy_notifications_cleanup_continue', array( Cleanup::class, 'process' ) );
	}
}
