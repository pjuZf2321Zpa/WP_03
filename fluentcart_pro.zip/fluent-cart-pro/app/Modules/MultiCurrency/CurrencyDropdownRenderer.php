<?php

namespace FluentCartPro\App\Modules\MultiCurrency;

use FluentCart\App\Modules\MultiCurrency\Services\CurrencyContext;
use FluentCart\Framework\Support\Arr;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * The currency dropdown panel opened by any nav trigger
 * ([data-fluent-cart-currency-switcher] or .fct-currency-switcher-toggle).
 */
class CurrencyDropdownRenderer
{
    const PANEL_ID = 'fct-currency-dropdown';

    /**
     * @var array[] each {code, symbol, name, flag}
     */
    protected $currencies = [];

    protected $current = '';

    public function __construct(array $currencies, string $current)
    {
        $this->currencies = $currencies;
        $this->current = $current;
    }

    public function render(): void
    {
        echo $this->getHtml(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- built from escaped parts; filter consumers own their markup
    }

    public function getHtml(): string
    {
        $itemsHtml = '';
        foreach ($this->currencies as $currency) {
            $itemsHtml .= $this->renderItem($currency);
        }

        ob_start();
        ?>
        <div class="fct-currency-dropdown" id="<?php echo esc_attr(self::PANEL_ID); ?>" data-fluent-cart-currency-dropdown hidden>
            <ul class="fct-currency-dropdown-list" aria-label="<?php esc_attr_e('Select currency', 'fluent-cart-pro'); ?>">
                <?php echo $itemsHtml; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- built from escaped parts; filter consumers own their markup ?>
            </ul>
        </div>
        <?php
        $html = (string) ob_get_clean();

        /**
         * The whole dropdown panel. The JS needs [data-fluent-cart-currency-dropdown]
         * on the panel and [data-fluent-cart-currency-option="CODE"] on each option.
         *
         * @param string $html
         * @param array  $context ['currencies' => array[], 'current' => string, 'items_html' => string]
         */
        return (string) apply_filters('fluent_cart/currency_switcher/dropdown_html', $html, [
            'currencies' => $this->currencies,
            'current'    => $this->current,
            'items_html' => $itemsHtml,
        ]);
    }

    /**
     * @param array $currency {code, symbol, name, flag}
     */
    public function renderItem(array $currency): string
    {
        $code = (string) Arr::get($currency, 'code', '');
        $name = (string) Arr::get($currency, 'name', '');
        $flag = (string) Arr::get($currency, 'flag', '');
        $symbol = (string) Arr::get($currency, 'symbol', '');
        $isCurrent = $code === $this->current;
        $url = add_query_arg(CurrencyContext::QUERY_PARAM, $code);
        $label = $name !== '' ? $name . ' (' . $code . ')' : $code;

        ob_start();
        ?>
        <li class="fct-currency-dropdown-item<?php echo $isCurrent ? ' is-current' : ''; ?>">
            <a class="fct-currency-dropdown-link"
               href="<?php echo esc_url($url); ?>"
               data-fluent-cart-currency-option="<?php echo esc_attr($code); ?>"
               <?php echo $isCurrent ? 'aria-current="true"' : ''; ?>>
                <?php if ($flag !== '') : ?>
                    <img class="fct-currency-dropdown-flag" src="<?php echo esc_url($flag); ?>" alt="" width="20" height="15" loading="lazy" decoding="async"/>
                <?php else : ?>
                    <span class="fct-currency-dropdown-flag is-placeholder" aria-hidden="true"><?php echo esc_html($symbol !== '' ? $symbol : $code); ?></span>
                <?php endif; ?>
                <span class="fct-currency-dropdown-label"><?php echo esc_html($label); ?></span>
                <svg class="fct-currency-dropdown-check" width="16" height="16" viewBox="0 0 16 16" aria-hidden="true" focusable="false">
                    <path d="M3 8.5L6.5 12L13 4.5" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
            </a>
        </li>
        <?php
        $html = (string) ob_get_clean();

        /**
         * One option in the currency dropdown.
         *
         * @param string $html
         * @param array  $context ['currency' => {code, symbol, name, flag}, 'is_current' => bool, 'url' => string]
         */
        return (string) apply_filters('fluent_cart/currency_switcher/item_html', $html, [
            'currency'   => $currency,
            'is_current' => $isCurrent,
            'url'        => $url,
        ]);
    }

    /**
     * The trigger [fluent_cart_currency_switcher] and the block render in Pro.
     *
     * @param array $atts display (name_code|name|code|symbol|flag, default code and sign), flag (yes|no), symbol (yes|no), flag_position (left|right),
     *                    list_display (name_code|name|code|symbol|flag, default name and code), list_flag (yes|no), list_symbol (yes|no), list_flag_position (left|right)
     */
    public function renderButton(array $atts = []): string
    {
        $currency = ['code' => $this->current, 'symbol' => '', 'name' => '', 'flag' => ''];
        foreach ($this->currencies as $candidate) {
            if (Arr::get($candidate, 'code', '') === $this->current) {
                $currency = $candidate;
                break;
            }
        }

        $display = (string) Arr::get($atts, 'display', '');
        if (!in_array($display, ['name_code', 'name', 'code', 'symbol', 'flag'], true)) {
            $display = '';
        }
        // Flag only: the flag is the label and the code stays for screen readers.
        // A currency with no flag shows its code instead of an empty button.
        $flagOnly = $display === 'flag' && (string) Arr::get($currency, 'flag', '') !== '';
        $showFlag = $flagOnly || Arr::get($atts, 'flag', 'yes') !== 'no';
        $flag = $showFlag ? (string) Arr::get($currency, 'flag', '') : '';
        $showSymbol = (string) Arr::get($atts, 'symbol', '');
        if (!in_array($showSymbol, ['yes', 'no'], true)) {
            $showSymbol = '';
        }
        $flagRight = Arr::get($atts, 'flag_position', '') === 'right';

        $displayAttrs = '';
        if ($display !== '') {
            $displayAttrs .= ' data-currency-display="' . esc_attr($display) . '"';
        }
        if ($showSymbol !== '') {
            $displayAttrs .= ' data-currency-symbol="' . esc_attr($showSymbol) . '"';
        }

        // The dropdown is shared, so the list options ride on the trigger and apply when it opens
        $listData = [];
        $listDisplay = (string) Arr::get($atts, 'list_display', '');
        if (in_array($listDisplay, ['name_code', 'name', 'code', 'symbol', 'flag'], true)) {
            $listData['list-display'] = $listDisplay;
        }
        if (Arr::get($atts, 'list_flag', '') === 'no') {
            $listData['list-flag'] = 'no';
        }
        if (Arr::get($atts, 'list_symbol', '') === 'yes') {
            $listData['list-symbol'] = 'yes';
        }
        if (Arr::get($atts, 'list_flag_position', '') === 'right') {
            $listData['list-flag-position'] = 'right';
        }
        $listAttrs = '';
        foreach ($listData as $name => $value) {
            $listAttrs .= ' data-' . $name . '="' . esc_attr($value) . '"';
        }

        $flagHtml = $flag !== ''
            ? '<img class="fct-current-currency-flag" src="' . esc_url($flag) . '" alt="" width="18" height="14" decoding="async"/>'
            : '';

        ob_start();
        ?>
        <button type="button" class="fct-currency-switcher-button" data-fluent-cart-currency-switcher<?php echo $listAttrs; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- allowlisted names, escaped values ?>>
            <span class="screen-reader-text"><?php esc_html_e('Currency:', 'fluent-cart-pro'); ?></span>
            <?php echo $flagRight ? '' : $flagHtml; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped above ?>
            <span class="fct-current-currency<?php echo $flagOnly ? ' screen-reader-text' : ''; ?>"<?php echo $displayAttrs; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped above ?>><?php echo esc_html(self::label($currency, $display, $showSymbol)); ?></span>
            <?php echo $flagRight ? $flagHtml : ''; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped above ?>
            <svg class="fct-currency-switcher-caret" width="10" height="10" viewBox="0 0 10 10" aria-hidden="true" focusable="false">
                <path d="M2 3.5L5 6.5L8 3.5" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
            </svg>
        </button>
        <?php
        $html = (string) ob_get_clean();

        /**
         * The shortcode/block trigger. Keep [data-fluent-cart-currency-switcher]
         * on the clickable element so it still opens the dropdown.
         *
         * @param string $html
         * @param array  $context ['currency' => {code, symbol, name, flag}, 'display' => string, 'show_flag' => bool,
         *                        'show_symbol' => ''|'yes'|'no', 'flag_position' => 'left'|'right', 'atts' => array]
         */
        return (string) apply_filters('fluent_cart/currency_switcher/button_html', $html, [
            'currency'      => $currency,
            'display'       => $display,
            'show_flag'     => $showFlag,
            'show_symbol'   => $showSymbol,
            'flag_position' => $flagRight ? 'right' : 'left',
            'atts'          => $atts,
        ]);
    }

    /**
     * Mirrors #format() in currency-dropdown.js, so the label doesn't change when the script runs.
     *
     * @param string $showSymbol yes|no adds or drops the sign; empty keeps the display's own rule
     *                           (only the default display carries it), so old shortcodes don't change
     */
    public static function label(array $currency, string $display = '', string $showSymbol = ''): string
    {
        $code = (string) Arr::get($currency, 'code', '');
        $symbol = (string) Arr::get($currency, 'symbol', '');
        $hasSymbol = $symbol !== '' && $symbol !== $code;

        switch ($display) {
            case 'flag':
                // The flag is shown; this is the screen-reader text
                return $code;
            case 'symbol':
                return $hasSymbol ? $symbol : $code;
            case 'name':
                $label = (string) Arr::get($currency, 'name', '') ?: $code;
                break;
            case 'name_code':
                $name = (string) Arr::get($currency, 'name', '');
                $label = $name !== '' ? $name . ' (' . $code . ')' : $code;
                break;
            default:
                $label = $code;
        }

        $addSymbol = $showSymbol === 'yes' || ($showSymbol === '' && $display === '');

        return $addSymbol && $hasSymbol ? $label . ' ' . $symbol : $label;
    }
}
