<?php
/**
 * Paid file-upload controls shared by Knowledge Base and Chatbot source forms.
 */
if (!defined('ABSPATH')) {
    exit;
}

if (!class_exists('\WPAICG\aipkit_dashboard') || !\WPAICG\aipkit_dashboard::is_pro_plan()) {
    return;
}
?>
<input
    id="aipkit_training_files_input"
    class="aipkit_training_files_input"
    type="file"
    multiple
    accept=".pdf,.docx,.txt,.md,.csv,.json"
    hidden
>
<button
    type="button"
    class="aipkit_btn aipkit_btn-secondary aipkit_builder_action_btn aipkit_training_files_button"
><?php esc_html_e('Browse', 'gpt3-ai-content-generator'); ?></button>
