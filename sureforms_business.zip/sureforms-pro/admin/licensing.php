<?php
/**
 * Licensing Class
 *
 * This class handles all licensing related stuff.
 *
 * @package sureforms-pro.
 * @since 0.0.1
 */

namespace SRFM_Pro\Admin;

use SRFM_Pro\Inc\Traits\Get_Instance;
use SRFM\Inc\Helper;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Licensing handler class.
 *
 * @since 0.0.1
 */

class Licensing {

	use Get_Instance;

	/**
	 * Transient key holding the cached result of the remote license check.
	 *
	 * @since 2.12.8
	 */
	const LICENSE_STATUS_TRANSIENT = 'srfm_pro_license_status_cache';

	/**
	 * SureCart product ids whose license keys unlock this plugin.
	 *
	 * Only Business ships, so only a Business key activates it.
	 *
	 * @since 2.13.1
	 */
	const PRODUCT_IDS = [
		'd852fceb-c7e4-4691-b20c-b9b49c9907f4', // SureForms Business.
	];

	/**
	 * SureCart product ids of the retired tiers, mapped to their names.
	 *
	 * A key for one of these is refused like any other non-Business key, but with a
	 * message that points the customer to their free upgrade to Business.
	 *
	 * @since 2.13.1
	 */
	const RETIRED_TIER_PRODUCT_IDS = [
		'6fc4d877-bea9-49bd-b72c-98c751685ef2' => 'SureForms Starter',
		'd18058be-9dc2-44dc-9024-a4a54ef004fc' => 'SureForms Pro',
	];

	/**
	 * Options where the Starter and Pro builds of the SDK stored their license key.
	 *
	 * The SDK names its option after the product, so a site updated from one of those
	 * builds to Business still has its key here while the Business option is empty.
	 * The key is not adopted -- it cannot activate Business -- but its presence is how
	 * the site is recognised as owed a free upgrade.
	 *
	 * @since 2.13.1
	 */
	const RETIRED_TIER_OPTIONS = [
		'sureformsstarter_license_options' => 'SureForms Starter',
		'sureformspro_license_options'     => 'SureForms Pro',
	];

	/**
	 * Where a customer holding a retired tier's key gets their Business key.
	 *
	 * Named once so the activation error and the admin notice cannot drift onto
	 * different support channels.
	 *
	 * @since 2.13.1
	 */
	const SUPPORT_EMAIL = 'support@sureforms.com';

	/**
	 * Error messages.
	 *
	 * @var array
	 */
	public $error_messages = [];

	/**
	 * Memoised SureCart client. See licensing_setup().
	 *
	 * A class property rather than a static local: before PHP 8.1 a static
	 * local is not shared with subclasses, so a subclass would build a second
	 * client and register the update check twice again.
	 *
	 * @since 2.13.0
	 * @var \SureCart\Licensing\Client|null
	 */
	private static $client = null;

	/**
	 * Class constructor
	 *
	 * @since 0.0.1
	 * @return void
	 */
	public function __construct() {
		// licensing_setup() loads the SDK itself, so there is no separate require here.
		self::licensing_setup();

		$this->set_error_messages();

		add_action( 'wp_ajax_sureforms_activate_license', [ $this, 'activate_license' ] );
		add_action( 'wp_ajax_sureforms_deactivate_license', [ $this, 'deactivate_license' ] );

		add_filter( 'pre_set_site_transient_update_plugins', [ $this, 'add_sureforms_pro_logo']);

		add_action( 'admin_init', [ $this, 'register_retired_tier_upgrade_notice' ] );
	}

	/**
	 * Licensing setup.
	 * Returns a cached SureCart Client instance.
	 *
	 * Memoised because the Client constructor has side effects: it builds an
	 * Updater, which registers check_plugin_update() on
	 * pre_set_site_transient_update_plugins. WordPress keys object callbacks by
	 * object identity, so a second Client is a second callback that nothing
	 * deduplicates.
	 *
	 * Most of the time the duplicates are cheap: they share one version-info
	 * transient (the key comes from the slug), so the extra callbacks find the
	 * cache warm. They cost real requests in two cases. On update-core.php the
	 * SDK skips that cache on purpose, so N clients mean N blocking requests to
	 * the licensing API. And a failed lookup caches nothing, so every duplicate
	 * retries it.
	 *
	 * Safe to share: Settings reads every value straight from get_option(), so
	 * one long-lived client holds no stale settings. The one per-instance memo
	 * in the SDK, License::$is_valid_license, is never reset by deactivate() or
	 * clear_options(). Nothing here calls License::is_valid() today; revisit
	 * this before anything does.
	 *
	 * @since 0.0.1
	 * @since 2.13.0 Memoised; every call now returns the same instance.
	 * @return \SureCart\Licensing\Client
	 */
	public static function licensing_setup() {
		if ( null === self::$client ) {
			if ( ! class_exists( 'SureCart\Licensing\Client' ) ) {
				require_once SRFM_PRO_DIR . '/licensing/Client.php';
			}

			self::$client = new \SureCart\Licensing\Client(
				SRFM_PRO_PRODUCT,
				SRFM_PRO_PUBLIC_TOKEN,
				SRFM_PRO_FILE
			);
		}

		return self::$client;
	}

	/**
	 * Tell a Starter or Pro site that its key no longer activates, and that the
	 * upgrade to Business is free.
	 *
	 * These sites are updated to the Business build by SureCart, and the SDK reads
	 * its key from an option named after the product. The Business option is empty
	 * on such a site, so without this notice the only symptoms are silent: updates
	 * stop arriving, and Stripe checkout sends an empty license key, which is billed
	 * at the unlicensed rate. The key itself is never read or printed -- only
	 * whether one is stored.
	 *
	 * @since 2.13.1
	 * @return void
	 */
	public function register_retired_tier_upgrade_notice() {
		if ( ! class_exists( 'SRFM\Admin\Notice_Manager' ) || ! current_user_can( 'manage_options' ) ) {
			return;
		}

		$business = get_option( 'sureformsbusiness_license_options', [] );
		if ( is_array( $business ) && ! empty( $business['sc_license_key'] ) ) {
			return;
		}

		$retired_tier = '';
		foreach ( self::RETIRED_TIER_OPTIONS as $option => $tier ) {
			$stored = get_option( $option, [] );
			if ( is_array( $stored ) && ! empty( $stored['sc_license_key'] ) ) {
				$retired_tier = $tier;
				break;
			}
		}

		if ( '' === $retired_tier ) {
			return;
		}

		\SRFM\Admin\Notice_Manager::register_notice(
			[
				'id'      => 'sureforms-pro-retired-tier-license',
				'variant' => 'warning',
				// Notice_Manager stores these verbatim and AdminNotice.js renders them
				// as React text, so escaping here would print the entities themselves:
				// an apostrophe in a translation would reach the admin as "&#039;".
				'title'   => __( 'Your license needs upgrading to SureForms Business', 'sureforms-pro' ),
				'message' => sprintf(
					/* translators: %s: retired product name, SureForms Starter or SureForms Pro. */
					__( 'This site is licensed for %s, which has been merged into SureForms Business. Until a Business key is activated the site will not receive updates, and payment forms are charged at the unlicensed rate. Your upgrade is free.', 'sureforms-pro' ),
					$retired_tier
				),
				'actions' => [
					[
						// The address in the label, not only behind the button: an admin
						// with no mail client configured gets nothing from a mailto.
						'label'   => sprintf(
							/* translators: %s: SureForms support email address. */
							__( 'Email %s', 'sureforms-pro' ),
							self::SUPPORT_EMAIL
						),
						'url'     => 'mailto:' . self::SUPPORT_EMAIL,
						'variant' => 'primary',
					],
				],
				'pages'   => [ 'all' ],
			]
		);
	}

	/**
	 * A SureCart error as the admin should read it.
	 *
	 * The SDK runs the store's message through esc_html() before wrapping it in a
	 * WP_Error (`licensing/Client.php`), and both screens that show it render the
	 * string as React text -- so an apostrophe arrives as "&#039;". Decoding here
	 * is safe for the same reason it is necessary: nothing downstream parses HTML.
	 *
	 * @param \WP_Error $error Error from the licensing client.
	 * @since 2.13.1
	 * @return string
	 */
	private static function readable_error( $error ) {
		return wp_specialchars_decode( $error->get_error_message(), ENT_QUOTES );
	}

	/**
	 * Set error messages.
	 *
	 * @since 0.0.1
	 * @return void
	 */
	private function set_error_messages() {
		$this->error_messages = [
			'nonce' => __( 'Invalid nonce.', 'sureforms-pro' ),
			'permission' => __( 'You do not have permission to activate license.', 'sureforms-pro' ),
			'invalid_license' => __( 'Please enter a valid license key', 'sureforms-pro' ),
		];

	}

	/**
	 * Activate license
	 *
	 * @hooked wp_ajax_sureforms_activate_license
	 * @since 0.0.1
	 * @return void
	 */
	public function activate_license() {
		if( ! check_ajax_referer( 'srfm_pro_licensing_nonce', 'nonce', false ) ) {
			wp_send_json_error( [ 'message' => $this->error_messages['nonce'] ] );
		}

		if( ! Helper::current_user_can() ) {
			wp_send_json_error( [ 'message' => $this->error_messages['permission'] ] );
		}

		$license_key = ! empty( $_POST['license_key'] ) ? sanitize_text_field( wp_unslash( $_POST['license_key'] ) ) : '';

		if ( empty( $license_key ) ) {
			wp_send_json_error( [ 'message' => $this->error_messages['invalid_license'] ] );
		}

		$client = self::licensing_setup();

		$get_license = $client->license()->retrieve( $license_key );

		/*
		 * Reading ->product off a WP_Error yields nothing, so without this branch
		 * every failed lookup was reported as a wrong key -- including the ones that
		 * say nothing about the key at all. Split the two, the same way
		 * is_license_active() does: a 404 is a verdict on the key, and anything else
		 * -- timeout, 429, 5xx -- is a verdict on the store, reported as SureCart
		 * worded it rather than as the customer's mistake.
		 */
		if ( is_wp_error( $get_license ) ) {
			$message = 'not_found' === $get_license->get_error_code()
				? __( 'Incorrect License key for this product.', 'sureforms-pro' )
				: self::readable_error( $get_license );

			wp_send_json_error( [ 'message' => $message ] );
		}

		// Deny is the fallthrough here: only a response that names the Business product
		// activates. An absent, empty, non-string or expanded-object product proves
		// nothing, and the release check cannot tell the tiers apart because they all
		// ship under the same slug. is_license_active() stays lenient on purpose --
		// failing there would lock out a live site -- but refusing here only shows an
		// error to the administrator doing the activation.
		$product = is_string( $get_license->product ?? null ) ? $get_license->product : '';

		if ( ! in_array( $product, self::PRODUCT_IDS, true ) ) {
			if ( isset( self::RETIRED_TIER_PRODUCT_IDS[ $product ] ) ) {
				wp_send_json_error(
					[
						'message' => sprintf(
							/* translators: 1: retired product name, SureForms Starter or SureForms Pro. 2: support email address. */
							__( 'This is a %1$s license key. You are eligible for a free upgrade to SureForms Business. Contact %2$s to get your Business license key.', 'sureforms-pro' ),
							self::RETIRED_TIER_PRODUCT_IDS[ $product ],
							self::SUPPORT_EMAIL
						),
					]
				);
			}

			wp_send_json_error( [ 'message' => __( 'Incorrect License key for this product.', 'sureforms-pro' ) ] );
		}

		$response = $client->license()->activate( $license_key );

		if ( is_wp_error( $response ) ) {
			wp_send_json_error( [ 'message' => self::readable_error( $response ) ] );
		}

		// Update the license status in the database after activating the license.
		update_option( 'srfm_pro_license_status', 'licensed' );
		self::flush_license_status_cache();
		wp_send_json_success( [ 'message' => __( 'License activated successfully.', 'sureforms-pro' ) ] );
	}

	/**
	 * Deactivate license.
	 *
	 * @hooked wp_ajax_sureforms_deactivate_license
	 * @since 0.0.1
	 * @return void
	 */
	public function deactivate_license() {
		if( ! check_ajax_referer( 'srfm_pro_licensing_nonce', 'nonce', false ) ) {
			wp_send_json_error( [ 'message' => $this->error_messages['nonce'] ] );
		}

		if( ! Helper::current_user_can() ) {
			wp_send_json_error( [ 'message' => $this->error_messages['permission'] ] );
		}

		$client = self::licensing_setup();

		$response = $client->license()->deactivate();

		if ( is_wp_error( $response ) ) {
			wp_send_json_error( [ 'message' => self::readable_error( $response ) ] );
		}

		// Update the license status in the database after deactivating the license.
		update_option( 'srfm_pro_license_status', 'unlicensed' );
		self::flush_license_status_cache();
		wp_send_json_success( [ 'message' => __( 'License deactivated successfully.', 'sureforms-pro' ) ] );
	}

	/**
	 * Checks if license is active.
	 *
	 * This is a read-through cache that writes: a *verified* answer is stored in a
	 * transient and mirrored into the `srfm_pro_license_status` option, so admin
	 * screens - which can call this on every page load - do not make two blocking
	 * API requests each time. The cache is flushed on activation and deactivation.
	 *
	 * A check that could not reach SureCart is never treated as a verdict. It neither
	 * writes the option nor takes the long cache window; it returns the last known
	 * status and retries shortly. Only a successful response, a real `not_found`, a
	 * wrong-product key or a missing key are allowed to persist a status.
	 *
	 * @param bool $allow_remote_check Whether a cache miss is allowed to hit the API.
	 *                                 Pass false from unattended contexts such as cron,
	 *                                 where a blocking request should never be made.
	 * @since 0.0.1
	 * @since 2.12.8 Added caching and the $allow_remote_check parameter.
	 * @return boolean
	 */
	public static function is_license_active( $allow_remote_check = true ) {
		$cached = get_transient( self::LICENSE_STATUS_TRANSIENT );

		if ( false !== $cached ) {
			return 'active' === $cached;
		}

		if ( ! $allow_remote_check ) {
			// Nothing cached and we must not block on the API, so fall back to the last known status.
			return self::get_stored_license_status();
		}

		$client = self::licensing_setup();

		// getting license key from settings.
		// We want to determine if the saved license key is valid for this product.
		$license_key = $client->settings()->license_key;

		/*
		 * No key stored is a verified "inactive", so it is cached like any other verdict.
		 * This also repairs sites damaged by SDK 1.0.1, whose clear_options() wiped the
		 * key while leaving srfm_pro_license_status on its stale 'licensed' value.
		 */
		if ( empty( $license_key ) ) {
			self::cache_license_status( false );
			return false;
		}

		$activation_id = $client->settings()->activation_id;

		// A key with no activation for this site is inactive without asking the API.
		if ( empty( $activation_id ) ) {
			self::cache_license_status( false );
			return false;
		}

		// retrieve the license from the server.
		$get_license = $client->license()->retrieve( $license_key );

		if ( is_wp_error( $get_license ) ) {
			// A 404 here means the key itself no longer exists - that is a verdict.
			if ( 'not_found' === $get_license->get_error_code() ) {
				self::cache_license_status( false );
				return false;
			}

			return self::hold_last_known_status();
		}

		// A product that names something else is a verdict; one this cannot read is not.
		// Only a string can be compared against the allowlist, so an absent, empty or
		// expanded product leaves the licence alone -- this runs on every request of
		// every live site, and switching Business off because the API answered in a
		// shape we did not expect is the one failure mode worth avoiding here.
		// activate_license() refuses the same response, where the cost is an error
		// shown to the administrator doing the activation.
		$product = $get_license->product ?? null;
		if ( is_string( $product ) && '' !== $product && ! in_array( $product, self::PRODUCT_IDS, true ) ) {
			self::cache_license_status( false );
			return false;
		}

		$activation = $client->activation()->get( $activation_id );

		if ( is_wp_error( $activation ) ) {
			// A 404 is SureCart telling us the activation is gone - that is a verdict.
			if ( 'not_found' === $activation->get_error_code() ) {
				self::cache_license_status( false );
				return false;
			}

			// Anything else - timeout, 429, 5xx, 401 - proves nothing either way.
			return self::hold_last_known_status();
		}

		$is_active = ! empty( $activation->id );

		self::cache_license_status( $is_active );

		return $is_active;
	}

	/**
	 * Read the last status that was actually verified against SureCart.
	 *
	 * @since 2.12.8
	 * @return bool
	 */
	private static function get_stored_license_status() {
		return 'licensed' === get_option( 'srfm_pro_license_status' );
	}

	/**
	 * Handle a check that could not be completed.
	 *
	 * Keeps serving the last verified status and schedules a short retry. Deliberately
	 * does not touch `srfm_pro_license_status`: an unreachable API is not evidence that
	 * a license is valid, and that option is what unattended callers trust.
	 *
	 * @since 2.12.8
	 * @return bool
	 */
	private static function hold_last_known_status() {
		$last_known = self::get_stored_license_status();

		set_transient(
			self::LICENSE_STATUS_TRANSIENT,
			$last_known ? 'active' : 'inactive',
			15 * MINUTE_IN_SECONDS
		);

		return $last_known;
	}

	/**
	 * Cache a verified result of the remote license check.
	 *
	 * An active license is cached for longer than an inactive one so that a site
	 * recovers quickly once the license is fixed, without re-checking on every load.
	 *
	 * The stored status is kept in sync as well, since that is what unattended
	 * contexts fall back to when the cache has expired. Only call this with a status
	 * SureCart actually confirmed - see hold_last_known_status() for the other case.
	 *
	 * @param bool $is_active Whether the license is currently active.
	 * @since 2.12.8
	 * @return void
	 */
	private static function cache_license_status( $is_active ) {
		set_transient(
			self::LICENSE_STATUS_TRANSIENT,
			$is_active ? 'active' : 'inactive',
			$is_active ? 12 * HOUR_IN_SECONDS : HOUR_IN_SECONDS
		);

		update_option( 'srfm_pro_license_status', $is_active ? 'licensed' : 'unlicensed' );
	}

	/**
	 * Flush the cached license status.
	 *
	 * @since 2.12.8
	 * @return void
	 */
	public static function flush_license_status_cache() {
		delete_transient( self::LICENSE_STATUS_TRANSIENT );
	}

	/**
	 * Adds logo for SureForms Pro plugins on updater page
	 *
	 * @param object $transient
	 * @since 1.7.0
	 * @return object
	 */
	public function add_sureforms_pro_logo( $transient ) {
		$plugin_slug = 'sureforms-pro/sureforms-pro.php';

		if (isset($transient->response[$plugin_slug])) {
			$plugin_data = $transient->response[$plugin_slug];

			// Only update the icons
			$plugin_data->icons = [
				'1x' => SRFM_PRO_URL . 'assets/icons/icon-128x128.gif',
				'2x' => SRFM_PRO_URL . 'assets/icons/icon-256x256.gif',
			];

			$transient->response[$plugin_slug] = $plugin_data;
		}

		return $transient;
	}
}
