<?php

namespace FluentCartPro\App\Modules\SavedPaymentMethods\PayPal;

use FluentCart\App\Modules\PaymentMethods\PayPalGateway\API\API;
use FluentCart\App\Modules\PaymentMethods\PayPalGateway\PayPalHelper;
use FluentCart\App\Modules\PaymentMethods\PayPalGateway\Processor;
use FluentCart\App\Services\Payments\PaymentInstance;
use FluentCart\Framework\Support\Arr;

/**
 * One-time, merchant-initiated charge of a saved PayPal account.
 *
 * Core already does this for renewals — Processor::chargeVaultedRenewal() — but
 * that method requires $paymentInstance->subscription and reads the token from
 * subscription meta, so it cannot serve a plain saved-PayPal checkout. This is the
 * same Orders v2 call (payment_source.paypal.vault_id) driven by a customer-scoped
 * token instead.
 *
 * Settlement is delegated to core's Processor::settleVaultChargeResponse() rather
 * than reimplemented: its PENDING branch is money-critical (a settling eCheck is
 * neither paid nor failed) and a copy here would drift.
 *
 * Idempotency (see coding-rules/payment-idempotency.md): the key seeds from
 * PaymentInstance::getIdempotencySeed(), NOT from core's renewal key shape
 * (fct_system_charge_{order}_{attempt}). The seed is stable across duplicate
 * submissions of one attempt and rolls after an observed failure, which is what
 * makes a double-click dedupe while a genuine retry is never blocked.
 */
class PayPalTokenCharger
{
    /**
     * @param PaymentInstance $paymentInstance
     * @param string $token The PayPal vault payment-token id
     * @return true|string|\WP_Error true = captured, 'processing' = settling
     */
    public function charge(PaymentInstance $paymentInstance, $token)
    {
        $order = $paymentInstance->order;
        $transaction = $paymentInstance->transaction;

        if (!$order || !$transaction) {
            return new \WP_Error('fct_saved_pp_no_txn', __('Could not start the payment.', 'fluent-cart-pro'));
        }

        if (!$token) {
            return new \WP_Error('fct_saved_pp_no_token', __('The selected PayPal account is no longer available.', 'fluent-cart-pro'));
        }

        $purchaseUnit = [
            'reference_id' => $transaction->uuid,
            'custom_id'    => $transaction->uuid,
            'amount'       => [
                'currency_code' => strtoupper($transaction->currency),
                'value'         => PayPalHelper::formatAmount((int) $transaction->total, $transaction->currency),
            ],
        ];

        $extraHeaders = [];
        $key = $this->idempotencyKey($paymentInstance, $token, $purchaseUnit);
        if ($key) {
            $extraHeaders['PayPal-Request-Id'] = $key;
        }

        $paypalOrder = API::createOrder($purchaseUnit, [
            'payment_source' => ['paypal' => ['vault_id' => $token]],
        ], $extraHeaders);

        if (is_wp_error($paypalOrder)) {
            return $paypalOrder;
        }

        return (new Processor())->settleVaultChargeResponse($transaction, $paypalOrder);
    }

    /**
     * Fingerprint covers every charge-material parameter: change any of them and
     * the buyer is charged something different, so the key must change too. A
     * reused id with a changed body is a PayPal 422 DUPLICATE_REQUEST_ID, which
     * would brick checkout for the id's retention window.
     *
     * Empty seed (no charge transaction) => no key at all, never a shared constant.
     */
    private function idempotencyKey(PaymentInstance $paymentInstance, $token, array $purchaseUnit)
    {
        $seed = $paymentInstance->getIdempotencySeed();
        if (!$seed) {
            return null;
        }

        return 'fct_saved_pp_' . md5($seed . '|' . wp_json_encode([
            'amount'   => Arr::get($purchaseUnit, 'amount.value'),
            'currency' => Arr::get($purchaseUnit, 'amount.currency_code'),
            'vault_id' => $token,
        ]));
    }
}
