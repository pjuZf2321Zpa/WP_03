<?php

namespace Breakdance\BloatEliminator;

use function Breakdance\Data\get_global_option;

add_action('init', 'Breakdance\BloatEliminator\bloatEliminator', 99);

/**
 * The WordPress features the Performance tab can switch off, as slug => the
 * row heading the tab shows for it.
 *
 * Single source of truth for the tab's save handler and the MCP settings
 * tools, so a feature added to the tab cannot be silently unsettable over MCP.
 * The tab keeps its own per-row explanations; only the slugs and their names
 * live here.
 *
 * @return array<string, string>
 */
function features()
{
    return [
        'gutenberg-blocks-css' => __('Gutenberg Blocks CSS', 'breakdance'),
        'xml-rpc'              => __('XML-RPC Pingbacks', 'breakdance'),
        'wp-emoji'             => __('WP Emoji', 'breakdance'),
        'wp-dashicons'         => __('Dashicons', 'breakdance'),
        'wp-oembed'            => __('OEmbed', 'breakdance'),
        'rsd-links'            => __('RSD Links', 'breakdance'),
        'wlw-link'             => __('WLW Link', 'breakdance'),
        'rest-api'             => __('REST API', 'breakdance'),
        'wp-generator'         => __('WP Generator', 'breakdance'),
        'shortlink'            => __('Remove Shortlink', 'breakdance'),
        'rel-links'            => __('Relational Links', 'breakdance'),
        'feed-links'           => __('RSS Feed', 'breakdance'),
    ];
}

/**
 * Switch off exactly this set of features, in the canonical order of
 * features(), which is the order the settings tab writes.
 *
 * @param string[] $slugs Unknown slugs are dropped.
 * @return void
 */
function setEnabledFeatures($slugs)
{
    \Breakdance\Data\set_global_option(
        'breakdance_settings_bloat_eliminator',
        array_values(array_intersect(array_keys(features()), array_map('strval', $slugs)))
    );
}

/**
 * The feature slugs currently switched off on this site.
 *
 * @return string[]
 */
function enabledFeatures()
{
    /** @var mixed $options */
    $options = get_global_option('breakdance_settings_bloat_eliminator');

    if (!is_array($options)) {
        return [];
    }

    /** @var string[] $slugs */
    $slugs = array_filter($options, 'is_string');

    return array_values(array_intersect(array_keys(features()), $slugs));
}

/**
 * @return void
 */
function bloatEliminator()
{
    $options = enabledFeatures();

    if (in_array('rsd-links', $options)) {
        remove_action('wp_head', 'rsd_link');
    }

    if (in_array('wlw-link', $options)) {
        remove_action('wp_head', 'wlwmanifest_link');
    }

    if (in_array('rest-api', $options)) {
        disableJSONRestAPI();
    }

    if (in_array('shortlink', $options)) {
        remove_action('wp_head', 'wp_shortlink_wp_head');
    }

    if (in_array('rel-links', $options)) {
        remove_action('wp_head', 'adjacent_posts_rel_link_wp_head');
    }

    if (in_array('wp-generator', $options)) {
        remove_action('wp_head', 'wp_generator');

        // hide it from RSS
        add_filter('the_generator', '__return_false');
    }

    if (in_array('feed-links', $options)) {
        // Remove Main RSS Feed Link
        add_filter('feed_links_show_posts_feed', '__return_false');
        remove_action('wp_head', 'feed_links_extra', 3);

        // Remove Comment RSS Feed Link
        add_filter('feed_links_show_comments_feed', '__return_false');
    }

    if (in_array('gutenberg-blocks-css', $options)) {
        add_action('wp_enqueue_scripts', '\Breakdance\BloatEliminator\disableGutenbergBlocksCss');
    }

    if (in_array('xml-rpc', $options)) {
        disableXmlRPC();
    }

    if (in_array('wp-emoji', $options)) {
        disableWPEmoji();
    }

    if (in_array('wp-oembed', $options)) {
        disableWPOembed();
    }

    if (in_array('wp-dashicons', $options)) {
        add_action('wp_enqueue_scripts', 'Breakdance\BloatEliminator\disableWPDashiconForGuestUsers');
    }
}

/**
 * @return void
 */
function disableWPEmoji()
{
    remove_action('wp_head', 'print_emoji_detection_script', 7);
    remove_action('admin_print_scripts', 'print_emoji_detection_script');
    remove_action('wp_print_styles', 'print_emoji_styles');
    remove_action('admin_print_styles', 'print_emoji_styles');
    remove_filter('the_content_feed', 'wp_staticize_emoji');
    remove_filter('comment_text_rss', 'wp_staticize_emoji');
    remove_filter('wp_mail', 'wp_staticize_emoji_for_email');

    /**
     * New Filters
     */
    add_filter('tiny_mce_plugins', 'Breakdance\BloatEliminator\disableTinyMCEEmojis');
    add_filter('wp_resource_hints', 'Breakdance\BloatEliminator\removeEmojiDNSPrefetch', 10, 2);
}

/**
 * @param array|null $plugins
 * @return array
 */
function disableTinyMCEEmojis($plugins)
{
    if (!is_array($plugins)) {
        return [];
    }

    return array_diff($plugins, ['wpemoji']);
}

/**
 * @param array $urls
 * @param string $relationType
 * @return array
 */
function removeEmojiDNSPrefetch($urls, $relationType)
{
    if ('dns-prefetch' === $relationType) {
        /**
         * This filter is documented in wp-includes/formatting.php
         *
         * @var string
         */
        $emoji_svg_url = apply_filters('emoji_svg_url', 'https://s.w.org/images/core/emoji/2/svg/');

        $urls = array_diff($urls, [$emoji_svg_url]);
    }

    return $urls;
}

/**
 * @return void
 */
function disableJSONRestAPI()
{
    // Remove the REST API lines from the HTML Header
    remove_action('wp_head', 'rest_output_link_wp_head', 10);

    // The REST API can't be switched off since WP 4.7 (the old `rest_enabled`
    // filter is ignored and only triggers a deprecation notice), so just drop JSONP.
    add_filter('rest_jsonp_enabled', '__return_false');
}

/**
 * @return void
 */
function disableWPOembed()
{
    remove_action('wp_head', 'wp_oembed_add_discovery_links', 10);

    // Remove the REST API endpoint.
    remove_action('rest_api_init', 'wp_oembed_register_route');

    // Turn off oEmbed auto discovery.
    add_filter('embed_oembed_discover', '__return_false');

    // Don't filter oEmbed results.
    remove_filter('oembed_dataparse', 'wp_filter_oembed_result', 10);

    // Remove oEmbed discovery links.
    remove_action('wp_head', 'wp_oembed_add_discovery_links');

    // Remove oEmbed-specific JavaScript from the front-end and back-end.
    remove_action('wp_head', 'wp_oembed_add_host_js');
}

/**
 * @return void
 */
function disableWPDashiconForGuestUsers()
{
    if (is_user_logged_in()) {
        return;
    }
    wp_deregister_style('dashicons');
}

/**
 * @return void
 */
function disableXmlRPC()
{
    // Disable Pingback method
    add_filter(
        'xmlrpc_methods',
        /**
         * @param array $methods
         * @return array
         */
        static function ($methods) {
            unset($methods['pingback.ping'], $methods['pingback.extensions.getPingbacks']);
            return $methods;
        }
    );

    // Remove X-Pingback HTTP header
    add_filter(
        'wp_headers',
        /**
         * @param array $headers
         * @return array
         */
        static function ($headers) {
            unset($headers['X-Pingback']);
            return $headers;
        }
    );

    // Removes all other artifacts
    add_filter('xmlrpc_enabled', '__return_false');
}

// function removeMetaTags()
// {
//     add_filter(
//         'wp_resource_hints',
//         /**
//          * @param array $hints
//          * @param string $relation_type
//          */
//         function ($hints, $relation_type) {
//             if ('dns-prefetch' === $relation_type) {
//                 return array_diff(wp_dependencies_unique_hosts(), $hints);
//             }

//             return $hints;
//         },
//         10,
//         2
//     );
// }

// Remove Gutenberg Block Library CSS from loading on the frontend
function disableGutenbergBlocksCss()
{
    wp_dequeue_style('wp-block-library');
    wp_dequeue_style('wp-block-library-theme');
    wp_dequeue_style('breakdance-global-block-css');
    // Remove WooCommerce block CSS
    wp_dequeue_style('wc-blocks-style');

    wp_dequeue_style('global-styles');
    wp_dequeue_style('classic-theme-styles');

    /**
     * @psalm-suppress UndefinedFunction
     */
    remove_action('wp_body_open', 'wp_global_styles_render_svg_filters');
}
