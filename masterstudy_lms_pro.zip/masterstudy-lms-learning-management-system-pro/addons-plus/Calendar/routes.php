<?php

use MasterStudy\Lms\Routing\Router;

/** @var Router $router */

$router->group(
	array(
		'middleware' => array(
			\MasterStudy\Lms\Routing\Middleware\Authentication::class,
			\MasterStudy\Lms\Pro\AddonsPlus\Calendar\Routing\Middleware\Available::class,
		),
	),
	function ( Router $router ) {
		$router->get(
			'/calendar/events/summary',
			\MasterStudy\Lms\Pro\AddonsPlus\Calendar\Http\Controllers\SummaryController::class,
			\MasterStudy\Lms\Pro\AddonsPlus\Calendar\Routing\Swagger\Routes\Summary::class
		);

		$router->get(
			'/calendar/events',
			\MasterStudy\Lms\Pro\AddonsPlus\Calendar\Http\Controllers\EventsController::class,
			\MasterStudy\Lms\Pro\AddonsPlus\Calendar\Routing\Swagger\Routes\Events::class
		);

		$router->get(
			'/calendar/events/day',
			\MasterStudy\Lms\Pro\AddonsPlus\Calendar\Http\Controllers\DayEventsController::class,
			\MasterStudy\Lms\Pro\AddonsPlus\Calendar\Routing\Swagger\Routes\DayEvents::class
		);
	}
);
