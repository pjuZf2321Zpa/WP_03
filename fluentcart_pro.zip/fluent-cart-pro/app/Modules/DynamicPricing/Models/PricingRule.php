<?php

namespace FluentCartPro\App\Modules\DynamicPricing\Models;

use FluentCart\App\Models\Model;

/**
 *
 *  Database Model for Pricing Rules
 *
 * @package FluentCartPro\App\Modules\DynamicPricing
 *
 * @version 1.0.0
 */
class PricingRule extends Model
{
    // Object cache entry for the active rules a checkout prices with.
    const ACTIVE_RULES_CACHE_KEY = 'active_rules';
    const CACHE_GROUP = 'fluent_cart_pricing_rules';

    protected $table = 'fct_pricing_rules';

    protected $primaryKey = 'id';

    protected $guarded = ['id'];

    protected $fillable = [
        'name',
        'display_name',
        'rule_type',
        'price_type',
        'status',
        'config',
        'applies_to',
        'start_date',
        'end_date',
    ];

    protected $casts = [
        'start_date' => 'datetime',
        'end_date'   => 'datetime',
    ];

    public static function boot()
    {
        parent::boot();
        static::creating(function ($model) {
            $config = $model->config ?: [];

            if (empty($config['apply_as'])) {
                $config['apply_as'] = 'percentage';
            }

            $model->config = $config;

            // A new rule has no conditions or schedule yet, so it must not price
            // checkouts until someone activates it.
            if (empty($model->status)) {
                $model->status = 'inactive';
            }

            if (empty($model->price_type)) {
                $model->price_type = 'discount';
            }
        });

        // Drop the cached active rules, so the next checkout reads them fresh.
        static::saved(function () {
            static::clearRulesCache();
        });

        static::deleted(function () {
            static::clearRulesCache();
        });
    }

    /**
     * Drop the cached active rules, so the next checkout reads them fresh.
     * Called by the model events above, and by any write that bypasses them
     * (a bulk query fires no model event).
     *
     * Bumps the group's last-changed version rather than deleting the entry:
     * the cache key carries that version, so rules a checkout read just before
     * this change and stores just after land under a key nobody reads again.
     *
     * @return void
     */
    public static function clearRulesCache()
    {
        wp_cache_set_last_changed(static::CACHE_GROUP);
    }

    public function setConfigAttribute($value)
    {
        if (is_array($value) || is_object($value)) {
            $value = json_encode($value, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        }
        $this->attributes['config'] = $value;
    }

    public function getConfigAttribute($value)
    {
        if (is_string($value)) {
            return json_decode($value, true);
        }

        return $value;
    }

    /**
     * Whether a fee from this rule is taxed. Rules saved before the setting existed are.
     *
     * @return bool
     */
    public function isFeeTaxable(): bool
    {
        $config = is_array($this->config) ? $this->config : [];

        return ($config['fee_taxable'] ?? 'yes') !== 'no';
    }

    public function appliedRules()
    {
        return $this->hasMany(AppliedPricingRule::class, 'rule_id', 'id');
    }
}
