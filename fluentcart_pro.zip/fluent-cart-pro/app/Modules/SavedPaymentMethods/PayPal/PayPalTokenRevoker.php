<?php

namespace FluentCartPro\App\Modules\SavedPaymentMethods\PayPal;

use FluentCart\App\Modules\PaymentMethods\PayPalGateway\API\API;
use FluentCart\Framework\Support\Arr;

/**
 * Deletes a vaulted PayPal payment token at PayPal (Vault v3).
 *
 * Removing a saved method has to revoke it at the provider, not just drop the
 * local record — otherwise the customer is told it is gone while it remains
 * chargeable. That is the failure mode this class exists to prevent, so it
 * reports failure honestly and lets the caller keep the record.
 */
class PayPalTokenRevoker
{
    /**
     * @param string $tokenId Vault payment-token id
     * @return true|\WP_Error true when the token no longer exists at PayPal
     */
    public function revoke($tokenId)
    {
        if (!$tokenId) {
            return new \WP_Error('fct_pp_revoke_no_token', __('No PayPal token to remove.', 'fluent-cart-pro'));
        }

        $response = API::makeRequest('vault/payment-tokens/' . rawurlencode($tokenId), 'v3', 'DELETE');

        if (!is_wp_error($response)) {
            return true; // 204 No Content
        }

        // Already gone at PayPal — deleted from the PayPal account directly, or a
        // retry of a revoke that actually succeeded. The customer's intent is
        // satisfied either way, so let the local record be removed rather than
        // stranding an entry that can never be deleted.
        if ($this->isAlreadyGone($response)) {
            return true;
        }

        return $response;
    }

    /**
     * PayPal reports a missing resource as RESOURCE_NOT_FOUND in the error body.
     * API::makeRequest maps any >299 to WP_Error and passes that body through as
     * the error data, which is the only place the distinction survives — the
     * error code itself collapses to 'general_error'.
     */
    private function isAlreadyGone(\WP_Error $error): bool
    {
        $body = $error->get_error_data();

        if (is_array($body) && strtoupper((string) Arr::get($body, 'name')) === 'RESOURCE_NOT_FOUND') {
            return true;
        }

        return false;
    }
}
