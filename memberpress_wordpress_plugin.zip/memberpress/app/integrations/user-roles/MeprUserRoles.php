<?php

if (!defined('ABSPATH')) {
    die('You are not allowed to call this page directly.');
}

/**
 * Integration of User Roles into MemberPress
 */
class MeprUserRoles
{
    /**
     * Constructor for the MeprUserRoles class.
     */
    public function __construct()
    {
        add_action('mepr_txn_store', [$this, 'process_status_changes']);
        add_action('mepr_txn_expired', [$this, 'process_status_changes'], 10, 2);
        add_action('mepr_account_is_active', [$this, 'process_status_changes']);
        add_action('mepr_post_delete_transaction', [$this, 'process_destroy_txn'], 10, 4);
        add_action('mepr_product_advanced_metabox', [$this, 'display_product_override']);
        add_action('mepr_product_save_meta', [$this, 'save_product_override']);
        add_action('profile_update', [$this, 'process_profile_update'], 10, 2);

        // Enqueue scripts.
        add_action('mepr_membership_admin_enqueue_script', [$this, 'admin_enqueue_product_scripts']);
    }

    /**
     * Enqueues admin scripts for product management.
     *
     * @param string $hook The current admin page hook.
     *
     * @return void
     */
    public function admin_enqueue_product_scripts($hook)
    {
        wp_enqueue_script('mp-userroles-product-js', plugin_dir_url(__FILE__) . 'userroles_product.js', ['jquery'], 'MEPR_VERSION', true);
    }

    /**
     * This will ensure that the roles persist after the profile is updated
     *
     * @see   add_action('profile_update')
     * @param integer $user_id       The ID of the user being updated.
     * @param array   $old_user_data The old user data before update.
     *
     * @return void
     */
    public function process_profile_update($user_id, $old_user_data)
    {
        // Restrict to admin user profile updates.
        if (is_admin()) {
            $wp_user = get_user_by('id', $user_id);

            if (!$wp_user) {
                return;
            }

            $this->set_users_roles($wp_user);
        }
    }

    /**
     * Processes the destruction of a transaction.
     *
     * @param integer         $id     The ID of the transaction.
     * @param WP_User         $user   The user object.
     * @param string          $result The result of the transaction.
     * @param MeprTransaction $txn    The transaction object.
     *
     * @return void
     */
    public function process_destroy_txn($id, $user, $result, $txn)
    {
        $this->process_status_changes($txn);
    }

    /**
     * Processes status changes for transactions.
     *
     * @param MeprTransaction $obj        The transaction object.
     * @param string          $sub_status The status of the subscription.
     *
     * @return void
     */
    public function process_status_changes($obj, $sub_status = false)
    {
        if ($obj instanceof MeprTransaction && $sub_status !== false && $sub_status === MeprSubscription::$active_str) {
            // This is an expiring transaction which is part of an active subscription, so check if there is a new txn
            // if there is a new txn then don't remove the user's roles.
            $sub = $obj->subscription();
            if ($sub) {
                $latest_txn = $sub->latest_txn();
                if ($latest_txn->is_active()) {
                    return;
                }
            }
        }

        $wp_user = get_user_by('id', $obj->user_id);

        if (!$wp_user) {
            return;
        }

        if (true === MeprHooks::apply_filters('mepr_bypass_user_roles_setup', false, $obj, $sub_status, $wp_user)) {
            return; // No need to process user roles.
        }

        $this->set_users_roles($wp_user);
    }

    /**
     * Sets roles for users based on their memberships.
     *
     * Both filters resolve before anything is written, and additions are applied
     * before removals, so no state written along the way drops the user below
     * the role set they end up holding.
     *
     * @param WP_User $wp_user The user object.
     *
     * @return void
     */
    public function set_users_roles($wp_user)
    {
        // Resolved once and handed to both: each of these forces the transaction
        // query, and they must agree on which memberships are active.
        $mepr_user          = new MeprUser($wp_user->ID);
        $active_product_ids = $mepr_user->active_product_subscriptions('ids', true);

        $roles_user_should_have = $this->get_users_active_roles($wp_user, $active_product_ids);
        $roles_to_remove        = $this->get_roles_to_remove($wp_user, $active_product_ids);

        $roles_to_remove        = MeprHooks::apply_filters('mepr_userroles_remove_roles', $roles_to_remove, $wp_user);
        $roles_user_should_have = MeprHooks::apply_filters('mepr_userroles_add_roles', $roles_user_should_have, $wp_user);

        // Nothing records which membership granted a role, so the site default is
        // the only one that can safely be treated as not membership-owned.
        $current_roles = array_values((array)$wp_user->roles);
        $final_roles   = $this->final_roles($current_roles, $roles_to_remove, $roles_user_should_have);

        // No usable role to land on, so leave the user as they are. Stripping
        // them would only trade one broken account for another.
        if (empty($final_roles)) {
            return;
        }

        // Add before removing, so every state written along the way is a
        // superset of the final one and the user is never stored role-less.
        $roles_to_add = array_diff($final_roles, $current_roles);
        if (!empty($roles_to_add)) {
            $this->add_roles($wp_user, $roles_to_add);
        }

        $roles_to_drop = array_diff($current_roles, $final_roles);
        if (!empty($roles_to_drop)) {
            $this->remove_roles($wp_user, $roles_to_drop);
        }

        // Reset the user caches.
        clean_user_cache($wp_user);

        // Last resort. add_role() and remove_role() fire actions a third party
        // can act on, so re-read the user rather than trust what we computed.
        $wp_user = get_user_by('id', $wp_user->ID);

        if ($wp_user !== false && empty($wp_user->roles)) {
            $this->reset_role($wp_user);
        }
    }

    /**
     * Retrieves all roles from all memberships.
     *
     * @return array List of roles
     */
    public function get_all_roles_from_all_memberships()
    {
        $products = get_posts([
            'meta_key'    => '_mepruserroles_enabled',
            'meta_value'  => '1',
            'numberposts' => -1,
            'fields'      => 'ids',
        ]);

        return $this->get_roles_from_products_array($products);
    }

    /**
     * Retrieves active roles for a user.
     *
     * @param WP_User    $wp_user            The user object.
     * @param array|null $active_product_ids Active membership IDs, looked up when not given.
     *
     * @return array List of active roles
     */
    public function get_users_active_roles($wp_user, $active_product_ids = null)
    {
        if (!is_array($active_product_ids)) {
            $mp_user            = new MeprUser($wp_user->ID);
            $active_product_ids = $mp_user->active_product_subscriptions('ids', true);
        }

        return $this->get_roles_from_products_array($active_product_ids);
    }

    /**
     * Retrieves roles to be removed from a user.
     *
     * Active memberships are the caller's snapshot where one is given, so the two
     * lists cannot disagree about what is active and misread a renewal as lapsed.
     *
     * @param WP_User    $wp_user            The user object.
     * @param array|null $active_product_ids Active membership IDs, looked up when not given.
     *
     * @return array List of roles to remove
     */
    public function get_roles_to_remove($wp_user, $active_product_ids = null)
    {
        $inactive_memberships = [];

        $mepr_user   = new MeprUser($wp_user->ID);
        $memberships = $mepr_user->active_product_subscriptions('ids', true, false);

        if (!is_array($active_product_ids)) {
            $active_product_ids = $mepr_user->active_product_subscriptions('ids', true);
        }

        $active_product_ids = array_map('intval', $active_product_ids);

        if (!empty($memberships)) {
            foreach ($memberships as $membership) {
                if (!in_array((int)$membership, $active_product_ids, true)) {
                    $inactive_memberships[] = $membership;
                }
            }
        }

        $roles = $this->get_roles_from_products_array($inactive_memberships);

        // WordPress grants the default role at registration, so this method
        // excludes it; mepr_userroles_remove_roles is the opt-in to reclaim it.
        $default_role = $this->default_role();

        return $default_role === '' ? array_values($roles) : array_values(array_diff($roles, [$default_role]));
    }

    /**
     * Retrieves roles from a products array.
     *
     * Memberships with the override switched off are skipped: the stored role
     * list outlives the checkbox, and stale meta must not move anyone's roles.
     *
     * @param array $products The array of product IDs.
     *
     * @return array List of roles
     */
    public function get_roles_from_products_array($products)
    {
        // No products?
        if (empty($products)) {
            return [];
        }

        $roles = [];

        foreach ($products as $id) {
            if (!get_post_meta($id, '_mepruserroles_enabled', true)) {
                continue;
            }

            $prd_roles = get_post_meta($id, '_mepruserroles_roles', true);

            if (!empty($prd_roles) && is_array($prd_roles)) {
                $roles = array_merge($roles, $prd_roles);
            }
        }

        return $roles;
    }

    /**
     * The role set a user should come out of a reconcile holding.
     *
     * Unregistered slugs are dropped - WordPress stores them but they grant no
     * capabilities. An empty result falls back to the site default, reseeded even
     * where a filter asked for it, and stays empty when that default is unusable.
     *
     * @param array $current_roles   Roles the user holds now.
     * @param array $roles_to_remove Roles inactive memberships have claimed back.
     * @param array $roles_to_add    Roles active memberships grant.
     *
     * @return array
     */
    protected function final_roles($current_roles, $roles_to_remove, $roles_to_add)
    {
        $final_roles = array_unique(array_merge(
            array_diff($current_roles, (array)$roles_to_remove),
            (array)$roles_to_add
        ));

        $wp_roles    = wp_roles();
        $final_roles = array_values(array_filter($final_roles, function ($role) use ($wp_roles) {
            return $wp_roles->is_role($role);
        }));

        if (empty($final_roles)) {
            $default_role = $this->default_role();

            $final_roles = $default_role === '' ? [] : [$default_role];
        }

        return $final_roles;
    }

    /**
     * The site's default role, or an empty string when it is unusable.
     *
     * An unregistered slug is worth no more here than anywhere else: it would
     * be stored happily and still leave the account showing no role.
     *
     * @return string
     */
    protected function default_role()
    {
        $default_role = get_option('default_role');

        if (!is_string($default_role) || !wp_roles()->is_role($default_role)) {
            return '';
        }

        return $default_role;
    }

    // Be very careful here - this will WIPE OUT all user's roles and reset it to only one Role
    // Probably should ONLY call this if the $user->roles is empty.
    /**
     * Resets a user's role to the default WordPress role.
     *
     * @param WP_User $wp_user The user object.
     *
     * @return void
     */
    public function reset_role($wp_user)
    {
        $default_role = $this->default_role();

        // Nothing usable to reset to, so leave the user alone rather than swap
        // one unusable role set for another.
        if ($default_role === '') {
            return;
        }

        $wp_user->set_role($default_role);

        // Reset the user caches.
        clean_user_cache($wp_user);
    }

    /**
     * Adds roles to a user.
     *
     * @param WP_User $wp_user The user object.
     * @param array   $roles   The array of roles to add.
     *
     * @return void
     */
    public function add_roles($wp_user, $roles)
    {
        if (!empty($roles)) {
            foreach ($roles as $role) {
                $wp_user->add_role($role);
            }
        }

        // Reset the user caches.
        clean_user_cache($wp_user);
    }

    /**
     * Removes roles from a user.
     *
     * @param WP_User $wp_user The user object.
     * @param array   $roles   The array of roles to remove.
     * @param boolean $reset   Whether to reset the user caches.
     *
     * @return void
     */
    public function remove_roles($wp_user, $roles, $reset = true)
    {
        if (!empty($roles)) {
            foreach ($roles as $role) {
                $wp_user->remove_role($role);
            }
        }

        // Reset the user caches.
        clean_user_cache($wp_user);
    }

    /**
     * Retrieves all roles available.
     *
     * @return array List of all roles
     */
    public function get_all_roles()
    {
        $formatted_roles = $this->get_formatted_roles_from_array(get_editable_roles());

        // The bbPress Roles (they don't store these in the DB for some reason).
        if (function_exists('bbp_get_dynamic_roles')) {
            $formatted_roles = array_merge($formatted_roles, $this->get_formatted_roles_from_array(bbp_get_dynamic_roles()));
        }

        return $formatted_roles;
    }

    /**
     * Formats roles from an array.
     *
     * @param  array $roles The array of roles to format.
     * @return array Formatted roles
     */
    public function get_formatted_roles_from_array($roles)
    {
        if (empty($roles)) {
            return [];
        }

        $formatted_roles = [];

        foreach ($roles as $role => $details) {
            $temp              = [];
            $temp['slug']      = esc_attr($role);
            $temp['name']      = translate_user_role($details['name']);
            $formatted_roles[] = $temp;
        }

        return $formatted_roles;
    }

    /**
     * Displays product override options.
     *
     * @param  MeprProduct $product The product object.
     * @return void
     */
    public function display_product_override($product)
    {
        $enabled   = (bool)get_post_meta($product->ID, '_mepruserroles_enabled', true);
        $roles     = get_post_meta($product->ID, '_mepruserroles_roles', true);
        $all_roles = $this->get_all_roles();

        if (empty($roles)) {
            $roles = [];
        }

        ?>
    <div id="mepr-userroles" class="mepr-product-adv-item">
      <input type="checkbox" name="mepruserroles_enabled" id="mepruserroles_enabled" <?php checked($enabled); ?> />
      <label for="mepruserroles_enabled"><?php esc_html_e('User Roles for this Product', 'memberpress'); ?></label>

        <?php MeprAppHelper::info_tooltip(
            'mepruserroles-list-override',
            __('Enable Product User Roles', 'memberpress'),
            __('These Roles will be added to and removed from the user automatically based on their current subscription status to this Product level. When they are not active on any Products, their Role will go back to the Role you have set in your WordPress -> Settings -> General page.', 'memberpress')
        );
        ?>

      <div id="mepruserroles_enabled_area" class="mepr-hidden product-options-panel">
        <select name="mepruserroles_product_roles[]" id="mepruserroles_product_roles" class="mepr-text-input form-field" multiple="multiple" size="5" style="width:99%;">
          <?php foreach ($all_roles as $role) : ?>
            <option value="<?php echo esc_attr($role['slug']); ?>" <?php selected(in_array($role['slug'], $roles, true)); ?>><?php echo esc_html($role['name']); ?></option>
          <?php endforeach; ?>
        </select>
        <br/>
        <small><?php esc_html_e('Hold the Control Key (Command Key on the Mac) in order to select or deselect multiple roles', 'memberpress'); ?></small>
      </div>
    </div>
        <?php
    }

    /**
     * Saves product override settings.
     *
     * @param MeprProduct $product The product object.
     *
     * @return void
     */
    public function save_product_override($product)
    {
        if (isset($_POST['mepruserroles_enabled']) && isset($_POST['mepruserroles_product_roles'])) {
            update_post_meta($product->ID, '_mepruserroles_enabled', true);
            $roles = array_map('sanitize_text_field', wp_unslash($_POST['mepruserroles_product_roles']));
            update_post_meta($product->ID, '_mepruserroles_roles', wp_slash($roles));
        } else {
            update_post_meta($product->ID, '_mepruserroles_enabled', false);
            update_post_meta($product->ID, '_mepruserroles_roles', []);
        }
    }
}
