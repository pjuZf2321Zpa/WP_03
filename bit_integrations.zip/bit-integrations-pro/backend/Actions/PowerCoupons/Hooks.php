<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Actions\PowerCoupons\PowerCouponsProHelper;
use BitApps\IntegrationsPro\Config;
use BitApps\IntegrationsPro\Core\Util\Hooks;

Hooks::filter(Config::withFreePrefix('power_coupons_create_coupon'), [PowerCouponsProHelper::class, 'createCoupon'], 10, 3);
Hooks::filter(Config::withFreePrefix('power_coupons_update_coupon'), [PowerCouponsProHelper::class, 'updateCoupon'], 10, 3);
Hooks::filter(Config::withFreePrefix('power_coupons_delete_coupon'), [PowerCouponsProHelper::class, 'deleteCoupon'], 10, 3);
Hooks::filter(Config::withFreePrefix('power_coupons_toggle_auto_apply'), [PowerCouponsProHelper::class, 'toggleAutoApply'], 10, 3);
Hooks::filter(Config::withFreePrefix('power_coupons_toggle_show_in_slideout'), [PowerCouponsProHelper::class, 'toggleShowInSlideout'], 10, 3);
