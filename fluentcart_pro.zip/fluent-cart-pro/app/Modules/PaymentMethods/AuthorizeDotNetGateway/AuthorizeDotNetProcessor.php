<?php

namespace FluentCartPro\App\Modules\PaymentMethods\AuthorizeDotNetGateway;

use FluentCartPro\App\Modules\PaymentMethods\AuthorizeDotNetGateway\API\AuthorizeDotNetAPI;
use FluentCart\App\App;
use FluentCart\App\Helpers\Status;
use FluentCart\App\Helpers\StatusHelper;
use FluentCart\App\Services\Payments\PaymentHelper;
use FluentCart\App\Services\DateTime\DateTime;
use FluentCart\App\Events\Subscription\SubscriptionActivated;
use FluentCart\App\Modules\Subscriptions\Services\SubscriptionService;
use FluentCart\App\Services\Payments\PaymentInstance;
use FluentCart\Framework\Support\Arr;

class AuthorizeDotNetProcessor
{
    protected AuthorizeDotNetSettings $settings;
    protected AuthorizeDotNetAPI $api;

    public function __construct(AuthorizeDotNetSettings $settings)
    {
        $this->settings = $settings;
        $this->api = new AuthorizeDotNetAPI();
    }

    public function handleSinglePayment(PaymentInstance $paymentInstance)
    {
        $order = $paymentInstance->order;
        $transaction = $paymentInstance->transaction;

        $fcCustomer = $paymentInstance->order->customer;
        $billingAddress = $paymentInstance->order->billing_address;
        $shippingAddress = $paymentInstance->order->shipping_address ?? $billingAddress;

        $descriptor = $this->getRequestValue('dataDescriptor');
        $dataValue = $this->getRequestValue('dataValue');
        $paymentMethod = $this->getRequestValue('paymentMethod', 'card');


        if (!$descriptor || !$dataValue) {
            return new \WP_Error(
                'authnet_missing_token',
                __('Payment token could not be generated. Please try again.', 'fluent-cart-pro')
            );
        }

        $amount = AuthorizeDotNetHelper::formatAmount($transaction->total, $transaction->currency);
        $poNumber = AuthorizeDotNetHelper::buildPurchaseOrderNumber($paymentInstance->getIdempotencySeed());

        $lineItems = AuthorizeDotNetHelper::buildLineItems($order);

        // Element order must match Auth.net XSD sequence: payment → order → lineItems → billTo → shipTo
        $transactionRequest = [
            'transactionType' => 'authCaptureTransaction',
            'amount'          => $amount,
            'payment'         => [
                'opaqueData' => [
                    'dataDescriptor' => $descriptor,
                    'dataValue'      => $dataValue,
                ]
            ],
            'order' => AuthorizeDotNetHelper::buildOrderInfo($order),
        ];

        if ($lineItems) {
            $transactionRequest['lineItems'] = ['lineItem' => $lineItems];
        }

        $transactionRequest['billTo'] = AuthorizeDotNetHelper::formatAddress($billingAddress, $fcCustomer, true);
        $transactionRequest['shipTo'] = AuthorizeDotNetHelper::formatAddress($shippingAddress, $fcCustomer, false);

        $transactionRequest = apply_filters('fluent_cart/authorize_dot_net/transaction_request', $transactionRequest, [
            'order'       => $order,
            'transaction' => $transaction,
        ]);

        $refId = substr($transaction->uuid, 0, 20);

        $response = $this->sendCharge($transactionRequest, $transaction, $refId, $poNumber);

        if (is_wp_error($response)) {
            fluent_cart_error_log('Authorize.Net Payment', 'Payment failed: ' . $response->get_error_message(), [
                'module_name' => 'order',
                'module_id'   => $transaction->order_id,
            ]);
            return $response;
        }


        if (!AuthorizeDotNetAPI::isSuccessResponse($response)) {
            return new \WP_Error(
                'authnet_payment_failed',
                AuthorizeDotNetAPI::extractErrorMessage($response)
            );
        }

        $transactionResponse = Arr::get($response, 'transactionResponse', []);
        $responseCode = (string) Arr::get($transactionResponse, 'responseCode');
        $vendorChargeId = Arr::get($transactionResponse, 'transId');
        $authCode = Arr::get($transactionResponse, 'authCode');

        if (!$vendorChargeId) {
            return new \WP_Error('authnet_missing_transaction', __('Unable to process payment. No transaction ID returned by Authorize.Net.', 'fluent-cart-pro'));
        }

        $details = AuthorizeDotNetHelper::extractPaymentDetails($transactionResponse, $paymentMethod);


        $meta = array_merge($transaction->meta ?? [], [
            'authnet_invoice' => (string) $order->id,
            'authnet_auth_code' => $authCode,
            'authnet_response' => $transactionResponse,
            'authnet_ref_id' => $refId,
        ]);

        $transaction->fill(array_filter([
            'vendor_charge_id'    => $vendorChargeId,
            'payment_method_type' => $details['method'],
            'card_last_4'         => $details['last_four'],
            'card_brand'          => $details['method'] === 'card' ? $details['brand'] : null,
            'meta'                => $meta,
        ]));

        if ($responseCode === '1') {
            $transaction->status = Status::TRANSACTION_SUCCEEDED;
        } elseif ($responseCode === '4') {
            $transaction->status = Status::TRANSACTION_PENDING;
        } else {
            $transaction->status = Status::TRANSACTION_FAILED;
        }

        $transaction->save();


        if ($transaction->status === Status::TRANSACTION_SUCCEEDED) {
            (new StatusHelper($order))->syncOrderStatuses($transaction);
        } elseif ($transaction->status === Status::TRANSACTION_PENDING) {
            AuthorizeDotNetHelper::markTransactionPending(
                $transaction,
                $transactionResponse,
                __('Transaction is held for review by Authorize.Net.', 'fluent-cart-pro')
            );
        } else {
            AuthorizeDotNetHelper::markTransactionFailed(
                $transaction,
                __('Authorize.Net declined the transaction.', 'fluent-cart-pro'),
                $transactionResponse
            );

            return new \WP_Error(
                'authnet_declined',
                AuthorizeDotNetAPI::extractErrorMessage($response, __('Authorize.Net declined the transaction.', 'fluent-cart-pro'))
            );
        }

        wp_send_json([
            'status'       => 'success',
            'redirect_to' => $transaction->getReceiptPageUrl(),
        ]);
    }

    public function handleSubscription(PaymentInstance $paymentInstance)
    {
        @set_time_limit(120);

        $order = $paymentInstance->order;
        $transaction = $paymentInstance->transaction;
        $subscriptionModel = $paymentInstance->subscription;
        
        $descriptor = $this->getRequestValue('dataDescriptor');
        $dataValue = $this->getRequestValue('dataValue');

        $billTo = AuthorizeDotNetHelper::formatAddress($order->billing_address, $order->customer, true);
        $shipTo = AuthorizeDotNetHelper::formatAddress($order->shipping_address, $order->customer, false);

        if (!$descriptor || !$dataValue) {
            return new \WP_Error(
                'authnet_missing_token',
                __('Payment token could not be generated. Please try again.', 'fluent-cart-pro')
            );
        }

        $billingPeriod = $this->resolveBillingPeriod($subscriptionModel);
        if (!$this->isBillingPeriodSupported($billingPeriod)) {
            $subscriptionModel->addLog(
                __('Authorize.Net Subscription', 'fluent-cart-pro'),
                __('Checkout refused before charging: Authorize.Net ARB cannot bill more often than every 7 days. Change the subscription interval to weekly or longer.', 'fluent-cart-pro'),
                'error'
            );

            return new \WP_Error(
                'authnet_minimum_days',
                __('This subscription bills more often than Authorize.Net allows. Please choose another payment method.', 'fluent-cart-pro')
            );
        }

        $customer = $order->customer;
        $profile = null;
        $firstPaymentResult = [];

        $savedProfileId = $this->resolveCustomerProfileId($customer);
        if (is_wp_error($savedProfileId)) {
            return $savedProfileId;
        }

        if ($savedProfileId) {
            $added = $this->registerPaymentProfileFromToken($savedProfileId, $billTo, $descriptor, $dataValue);
            if (!is_wp_error($added)) {
                $profile = [
                    'customerProfileId'        => Arr::get($added, 'customerProfileId'),
                    'customerPaymentProfileId' => Arr::get($added, 'customerPaymentProfileId'),
                ];
                $this->logProfileReady($subscriptionModel, Arr::get($added, 'source', 'saved profile'), $profile);
            } else {
                if ($subscriptionModel) {
                    $subscriptionModel->addLog(
                        __('Authorize.Net Customer Profile', 'fluent-cart-pro'),
                        __('Could not add the entered card to the saved customer profile: ', 'fluent-cart-pro') . $added->get_error_message(),
                        'error'
                    );
                }
                return $added;
            }
        }

        if ($transaction->total > 0) {
            $poNumber = AuthorizeDotNetHelper::buildPurchaseOrderNumber($paymentInstance->getIdempotencySeed());

            if ($profile) {
                // Charge first payment using the stored profile (token already consumed above).
                $firstPaymentResult = $this->handleFirstPayment($transaction, $order, $profile, [], $poNumber);
            } else {
                // Single call: charge the first payment AND create the customer profile together
                // (createTransactionRequest with opaqueData + profile.createProfile). Avoids a separate
                // profile round-trip and consumes the one-time token exactly once.
                $firstPaymentResult = $this->handleFirstPayment($transaction, $order, null, [
                    'descriptor' => $descriptor,
                    'dataValue'  => $dataValue,
                    'billTo'     => $billTo,
                ], $poNumber);
            }

            if (is_wp_error($firstPaymentResult)) {
                return $firstPaymentResult;
            }

            if (!$profile) {
                $profile = Arr::get($firstPaymentResult, 'profile');
                if ($profile) {
                    $customer->updateMeta('authorize_dot_net_profile_id', $profile['customerProfileId']);
                    $this->logProfileReady($subscriptionModel, 'created with first payment', $profile);
                } else {
                    // Existing profile found but the paid card could not be attached yet:
                    // pin the profile so deferred activation retries the same attach.
                    $duplicateProfileId = (string) Arr::get($firstPaymentResult, 'duplicate_profile_id');
                    if ($duplicateProfileId) {
                        $customer->updateMeta('authorize_dot_net_profile_id', $duplicateProfileId);
                        $this->rememberPaymentProfile($transaction, ['customerProfileId' => $duplicateProfileId]);
                    }

                    if ($subscriptionModel) {
                        $subscriptionModel->addLog(
                            __('Authorize.Net Customer Profile', 'fluent-cart-pro'),
                            __('First payment captured but customer profile was not created: ', 'fluent-cart-pro') . Arr::get($firstPaymentResult, 'profile_error', 'unknown'),
                            'warning'
                        );
                    }
                }
            }

            if ($profile) {
                $this->rememberPaymentProfile($transaction, $profile);
            }

            if (Arr::get($firstPaymentResult, 'reason') === 'transaction_held_for_review') {
                fluent_cart_warning_log('Authorize.Net Subscription', 'Transaction is held for review by Authorize.Net. Once the transaction is approved, subscription will be activated.', [
                    'module_name' => 'order',
                    'module_id'   => $order->id,
                ]);

                if ($subscriptionModel) {
                    $subscriptionModel->addLog(__('Authorize.Net Subscription', 'fluent-cart-pro'), __('Transaction is held for review by Authorize.Net. Once the transaction is approved, subscription will be activated.', 'fluent-cart-pro'), 'warning');
                }

                wp_send_json([
                    'status'       => 'success',
                    'redirect_to' => $transaction->getReceiptPageUrl(),
                ]);
            }
        } else {
            // Nothing to charge today (real trial) — create the profile from the token
            if (!$profile) {
                $profileResult = $this->createCustomerProfileFromToken($customer, $billTo, $descriptor, $dataValue);
                if (is_wp_error($profileResult)) {
                    if ($subscriptionModel) {
                        $subscriptionModel->addLog(
                            __('Authorize.Net Customer Profile', 'fluent-cart-pro'),
                            __('Customer profile setup failed: ', 'fluent-cart-pro') . $profileResult->get_error_message(),
                            'error'
                        );
                    }
                    return $profileResult;
                }

                $profile = [
                    'customerProfileId'        => Arr::get($profileResult, 'customerProfileId'),
                    'customerPaymentProfileId' => Arr::get($profileResult, 'customerPaymentProfileId'),
                ];
                $this->logProfileReady($subscriptionModel, Arr::get($profileResult, 'source', 'unknown'), $profile);
            }

            $transaction->status = Status::TRANSACTION_SUCCEEDED;
            $transaction->save();
            $this->rememberPaymentProfile($transaction, $profile);
        }
        // first payment done

        // ARB needs a customer profile — payment is already captured, so queue the
        // subscription creation for the background retry / webhook instead of failing.
        if (!$profile) {
            return $this->deferSubscriptionCreationAndRespond($transaction, $subscriptionModel, __('customer profile is not available yet', 'fluent-cart-pro'));
        }

        // now subscribe
        $intervalInDays = PaymentHelper::getIntervalDays($subscriptionModel->billing_interval);

        if ($order->type == 'renewal') {

           $amount = AuthorizeDotNetHelper::formatAmount($subscriptionModel->getCurrentRenewalAmount(), $transaction->currency);
           $trialDays = $subscriptionModel->getReactivationTrialDays();
           $totalOccurrences = AuthorizeDotNetSubscriptions::reactivationOccurrences($subscriptionModel, $transaction);

           // This payment was the last installment: no new ARB, core marks it completed
           if (!$totalOccurrences) {
               SubscriptionService::syncSubscriptionStates($subscriptionModel, []);
               (new StatusHelper($order))->syncOrderStatuses($transaction);

               wp_send_json([
                   'status'      => 'success',
                   'redirect_to' => $transaction->getReceiptPageUrl(),
               ]);
           }

            if (!$trialDays) {
                $trialDays = $intervalInDays;
            }

            $startDate = DateTime::now();
            $startDate->addDays($trialDays);
            $startDateStr = $startDate->format('Y-m-d');

            $subscriptionData = [
                'name' => mb_substr($subscriptionModel->item_name, 0, 50) ?: 'Subscription',
                'paymentSchedule' => [
                    'interval' => [
                        'length' => (string) Arr::get($billingPeriod, 'interval_frequency'),
                        'unit'   => Arr::get($billingPeriod, 'interval_unit'),
                    ],
                    'startDate'        => $startDateStr,
                    'totalOccurrences' => (string) $totalOccurrences,
                ],
                'amount'  => $amount,
                'profile' => $profile,
            ];

            $refId = substr($subscriptionModel->uuid, 0, 20);

            $data = [
                'merchantAuthentication' => $this->api->getMerchantAuthentication(),
                'refId'                  => $refId,
                'subscription'           => $subscriptionData,
            ];


        } else {
          
            // Calculate total occurrences
            $totalOccurrences = 9999; // Unlimited by default

            if ($subscriptionModel->bill_times) {
                // simulated-trial first installment is collected outside the ARB cycles
                $totalOccurrences = $subscriptionModel->getInitialRemoteBillTimes();
            }


            // startDate = next billing date after the manual first payment
            $trialDays = $subscriptionModel->trial_days ?: $intervalInDays;

            $startDate = DateTime::now();
            $startDate->addDays($trialDays);
            $startDateStr = $startDate->format('Y-m-d');

            // Format recurring amount
            $amount = AuthorizeDotNetHelper::formatAmount($subscriptionModel->recurring_total, $transaction->currency);

            $subscriptionData = [
                'name' => mb_substr($subscriptionModel->item_name, 0, 50) ?: 'Subscription',
                'paymentSchedule' => [
                    'interval' => [
                        'length' => (string) Arr::get($billingPeriod, 'interval_frequency'),
                        'unit'   => Arr::get($billingPeriod, 'interval_unit'),
                    ],
                    'startDate'        => $startDateStr,
                    'totalOccurrences' => (string) $totalOccurrences,
                ],
                'amount'  => $amount,
                'profile' => $profile,
            ];

            $refId = substr($subscriptionModel->uuid, 0, 20);

            $data = [
                'merchantAuthentication' => $this->api->getMerchantAuthentication(),
                'refId'                  => $refId,
                'subscription'           => $subscriptionData,
            ];

        }

        fluent_cart_add_log(
            'Authorize.Net Subscription',
            sprintf(
                'ARBCreateSubscriptionRequest — profileId: %s, paymentProfileId: %s, startDate: %s, amount: %s',
                Arr::get($data, 'subscription.profile.customerProfileId', 'NULL'),
                Arr::get($data, 'subscription.profile.customerPaymentProfileId', 'NULL'),
                Arr::get($data, 'subscription.paymentSchedule.startDate', 'NULL'),
                Arr::get($data, 'subscription.amount', 'NULL')
            ),
            'info',
            [
                'module_name' => 'subscription',
                'module_id'   => $subscriptionModel ? $subscriptionModel->id : null,
            ]
        );

        $response = $this->api->createAuthorizeNetObject('ARBCreateSubscriptionRequest', $data);

        if (is_wp_error($response)) {
            // check if error message contains 'You have submitted a duplicate of Subscription'
            $errorMessage = $response->get_error_message();
            if (str_contains($errorMessage, 'You have submitted a duplicate of Subscription')) {
                return $this->handleSubscriptionCreationFailure(
                    new \WP_Error('authnet_duplicate_subscription', __('You have already subscribed to this plan.', 'fluent-cart-pro')),
                    $transaction,
                    $subscriptionModel,
                    $profile
                );
            }

            // E00040: Auth.Net's ARB service reads replicated CIM data — a just-created profile
            // may not be visible to it yet. Payment is captured; queue creation and retry.
            if (str_contains($errorMessage, 'The record cannot be found')) {
                return $this->deferSubscriptionCreationAndRespond($transaction, $subscriptionModel, $errorMessage, $profile, Arr::get($data, 'subscription'));
            }

            return $this->handleSubscriptionCreationFailure($response, $transaction, $subscriptionModel, $profile);
        }


        if (!AuthorizeDotNetAPI::isSuccessResponse($response)) {
            return $this->handleSubscriptionCreationFailure(
                new \WP_Error(
                    'authnet_payment_failed',
                    AuthorizeDotNetAPI::extractErrorMessage($response)
                ),
                $transaction,
                $subscriptionModel,
                $profile
            );
        }

        $vendorSubscriptionId = Arr::get($response, 'subscriptionId');
        $vendorCustomerId = Arr::get($response, 'profile.customerProfileId');

        if (!$vendorSubscriptionId) {
            return $this->handleSubscriptionCreationFailure(
                new \WP_Error('authnet_missing_subscription_id', __('Unable to process subscription. No subscription ID returned by Authorize.Net.', 'fluent-cart-pro')),
                $transaction,
                $subscriptionModel,
                $profile
            );
        }
    
        $updateData = [
            'vendor_subscription_id' => $vendorSubscriptionId,
            'vendor_customer_id'    => $vendorCustomerId,
            'status'                => Status::SUBSCRIPTION_ACTIVE,
            'current_payment_method' => 'authorize_dot_net',
            'vendor_response'        => json_encode($response),
        ];

        if ($startDate) {
            $updateData['next_billing_date'] = DateTime::anyTimeToGmt($startDateStr)->format('Y-m-d H:i:s');
        }

        $subscriptionModel->update($updateData);
        SubscriptionService::syncSubscriptionStates($subscriptionModel, []);

        $activePaymentMethod = [
            'customer_profile_id' => Arr::get($response, 'profile.customerProfileId'),
            'payment_profile_id' => Arr::get($response, 'profile.customerPaymentProfileId'),
        ];

        if (!empty($firstPaymentResult['billing_info'])) {
            $activePaymentMethod['type'] = Arr::get($firstPaymentResult, 'billing_info.type');
            $activePaymentMethod['last_four'] = Arr::get($firstPaymentResult, 'billing_info.last_four');
            $activePaymentMethod['brand'] = Arr::get($firstPaymentResult, 'billing_info.brand');
            $activePaymentMethod['details'] = [
                'type' => Arr::get($firstPaymentResult, 'billing_info.type'),
                'last_4' => Arr::get($firstPaymentResult, 'billing_info.last_four'),
                'brand' => Arr::get($firstPaymentResult, 'billing_info.brand'),
            ];
        }

        // update 'active_payment_method' meta
        $subscriptionModel->updateMeta('active_payment_method', $activePaymentMethod);


        (new SubscriptionActivated($subscriptionModel, $order, $order->customer))->dispatch();

        (new StatusHelper($order))->syncOrderStatuses($transaction);

        wp_send_json([
            'status'       => 'success',
            'redirect_to' => $transaction->getReceiptPageUrl(),
        ]);
    }

    protected function getRequestValue(string $key, $default = null)
    {
        $value = App::request()->get($key);
        if (is_array($value)) {
            return $default;
        }

        $value = is_string($value) ? sanitize_text_field(wp_unslash($value)) : $value;
        return $value !== null && $value !== '' ? $value : $default;
    }

    /**
     * @param string $poNumber seed-derived purchase order number; see sendCharge()
     */
    protected function handleFirstPayment($transaction, $order, $profile = null, array $tokenArgs = [], string $poNumber = '')
    {
        $amount    = AuthorizeDotNetHelper::formatAmount($transaction->total, $transaction->currency);
        $lineItems = AuthorizeDotNetHelper::buildLineItems($order);

        // JSON API is order-sensitive (translated to XML): payment → profile → order → lineItems → customer → billTo
        $transactionRequest = [
            'transactionType' => 'authCaptureTransaction',
            'amount'          => $amount,
        ];

        if ($profile) {
            $transactionRequest['profile'] = [
                'customerProfileId' => $profile['customerProfileId'],
                'paymentProfile'    => [
                    'paymentProfileId' => $profile['customerPaymentProfileId'],
                ],
            ];
        } else {
            // Charge with the one-time token and create the customer profile in the same call
            $transactionRequest['payment'] = [
                'opaqueData' => [
                    'dataDescriptor' => Arr::get($tokenArgs, 'descriptor'),
                    'dataValue'      => Arr::get($tokenArgs, 'dataValue'),
                ],
            ];
            $transactionRequest['profile'] = ['createProfile' => true];
        }

        $transactionRequest['order'] = AuthorizeDotNetHelper::buildOrderInfo($order);

        if ($lineItems) {
            $transactionRequest['lineItems'] = ['lineItem' => $lineItems];
        }

        if (!$profile) {
            $transactionRequest['customer'] = [
                'id'    => (string) $order->customer->id,
                'email' => $order->customer->email,
            ];
            if (!empty($tokenArgs['billTo'])) {
                $transactionRequest['billTo'] = $tokenArgs['billTo'];
            }
        }

        $transactionRequest = apply_filters('fluent_cart/authorize_dot_net/transaction_request', $transactionRequest, [
            'order'       => $order,
            'transaction' => $transaction,
        ]);

        $refId = substr($transaction->uuid, 0, 20);

        $firstPayment = $this->sendCharge($transactionRequest, $transaction, $refId, $poNumber);

        if (is_wp_error($firstPayment)) {
            fluent_cart_error_log('Authorize.Net Subscription', 'First payment failed: ' . $firstPayment->get_error_message(), [
                'module_name' => 'order',
                'module_id'   => $transaction->order_id,
            ]);

            return $firstPayment;
        }

        if (!AuthorizeDotNetAPI::isSuccessResponse($firstPayment)) {
            return new \WP_Error('authnet_payment_failed', AuthorizeDotNetAPI::extractErrorMessage($firstPayment));
        }

        $transactionResponse = Arr::get($firstPayment, 'transactionResponse', []);
        $responseCode = (string) Arr::get($transactionResponse, 'responseCode');
        $vendorChargeId = Arr::get($transactionResponse, 'transId');
        $authCode = Arr::get($transactionResponse, 'authCode');

        if (!$vendorChargeId) {
            return new \WP_Error('authnet_missing_transaction', __('Unable to process payment. No transaction ID returned by Authorize.Net.', 'fluent-cart-pro'));
        }

        $details = AuthorizeDotNetHelper::extractPaymentDetails($transactionResponse, 'card');


        $meta = array_merge($transaction->meta ?? [], [
            'authnet_auth_code' => $authCode,
            'authnet_response' => $transactionResponse,
            'authnet_ref_id' => $refId,
        ]);

        if ($responseCode === '1') {
            $transaction->status = Status::TRANSACTION_SUCCEEDED;
        } elseif ($responseCode === '4') {
            $transaction->status = Status::TRANSACTION_PENDING;
        } else {
            $transaction->status = Status::TRANSACTION_FAILED;
        }
    

        $transaction->fill(array_filter([
            'vendor_charge_id'    => $vendorChargeId,
            'payment_method_type' => Arr::get($details, 'method', 'card'),
            'card_last_4'         => Arr::get($details, 'last_four'),
            'card_brand'          => Arr::get($details, 'brand', null),
            'meta'                => $meta,
        ]));


        $transaction->save();

        if ($transaction->status === Status::TRANSACTION_FAILED) {
            AuthorizeDotNetHelper::markTransactionFailed(
                $transaction,
                __('Authorize.Net declined the transaction.', 'fluent-cart-pro'),
                $transactionResponse
            );

            return new \WP_Error(
                'authnet_declined',
                AuthorizeDotNetAPI::extractErrorMessage($firstPayment, __('Authorize.Net declined the transaction.', 'fluent-cart-pro'))
            );
        }

        $billingInfo = [
            'type'      => Arr::get($details, 'method', 'card'),
            'last_four' => Arr::get($details, 'last_four'),
            'brand'     => Arr::get($details, 'brand'),
        ];

        $result = ['billing_info' => $billingInfo];

        if ($responseCode === '4') {
            $result['reason'] = 'transaction_held_for_review';
        }

        // profileResponse is present when the request carried profile.createProfile = true.
        // The charge can succeed while profile creation fails — report both separately.
        $profileResponse = Arr::get($firstPayment, 'profileResponse', []);
        if ($profileResponse) {
            $profileId     = (string) Arr::get($profileResponse, 'customerProfileId');
            $paymentIdList = Arr::get($profileResponse, 'customerPaymentProfileIdList', []);
            if (isset($paymentIdList['numericString'])) {
                $paymentIdList = (array) $paymentIdList['numericString'];
            }
            $paymentProfileId = (string) Arr::first((array) $paymentIdList);

            if (strtoupper((string) Arr::get($profileResponse, 'messages.resultCode')) === 'OK' && $profileId && $paymentProfileId) {
                $result['profile'] = [
                    'customerProfileId'        => $profileId,
                    'customerPaymentProfileId' => $paymentProfileId,
                ];
            } else {
                $result['profile_error'] = AuthorizeDotNetAPI::extractErrorMessage($profileResponse, __('Unknown profile creation error.', 'fluent-cart-pro'));

                $duplicateProfileId = $profileId ?: AuthorizeDotNetHelper::extractDuplicateProfileIdFromError($result['profile_error']);
                if ($duplicateProfileId) {
                    $attached = (new AuthorizeDotNetSubscriptions($this->settings))
                        ->attachPaidCardToProfile((string) $vendorChargeId, $duplicateProfileId);

                    if (is_wp_error($attached)) {
                        $result['duplicate_profile_id'] = $duplicateProfileId;
                        $result['profile_error'] .= ' ' . $attached->get_error_message();
                    } else {
                        $result['profile'] = $attached;
                        unset($result['profile_error']);
                    }
                }
            }
        }

        return $result;
    }

    /**
     * Send createTransactionRequest with the duplicate window widened to 8h and the
     * seed-derived PO number stamped on the transaction first, so a resubmit whose
     * original response was lost comes back as Auth.Net error 11 carrying the original
     * transId instead of charging the card again. The PO number is the recovery key,
     * so it is applied after the request filter and cannot be altered by it.
     *
     * @return array|\WP_Error
     */
    protected function sendCharge(array $transactionRequest, $transaction, string $refId, string $poNumber)
    {
        // Without it Auth.net charges the number in the account currency
        $transactionRequest = AuthorizeDotNetHelper::setTransactionRequestField(
            $transactionRequest,
            'currencyCode',
            strtoupper((string) $transaction->currency)
        );

        if ($poNumber) {
            $transactionRequest = AuthorizeDotNetHelper::setTransactionRequestField($transactionRequest, 'poNumber', $poNumber);

            $transaction->fill([
                'meta' => array_merge($transaction->meta ?? [], [
                    AuthorizeDotNetHelper::PO_NUMBER_META_KEY => $poNumber,
                ]),
            ]);
            $transaction->save();
        }

        $response = $this->createTransaction($transactionRequest, $refId, AuthorizeDotNetHelper::DUPLICATE_WINDOW_SECONDS);

        if (!is_wp_error($response) || !$poNumber) {
            return $response;
        }

        $original = $this->resolveDuplicateOriginal($response, $transaction, $poNumber);
        if (is_wp_error($original) || is_array($original)) {
            return $original;
        }

        // The original was declined or voided: the customer is retrying a failed
        // attempt, so let this one through the duplicate check.
        return $this->createTransaction($transactionRequest, $refId, 0);
    }

    /**
     * @return array|\WP_Error
     */
    protected function createTransaction(array $transactionRequest, string $refId, int $duplicateWindow)
    {
        $transactionRequest = AuthorizeDotNetHelper::setTransactionRequestField(
            $transactionRequest,
            'transactionSettings',
            AuthorizeDotNetHelper::duplicateWindowSetting($duplicateWindow)
        );

        return $this->api->createAuthorizeNetObject('createTransactionRequest', [
            'merchantAuthentication' => $this->api->getMerchantAuthentication(),
            'refId'                  => $refId,
            'transactionRequest'     => $transactionRequest,
        ]);
    }

    /**
     * Turn an error-11 duplicate rejection into the original charge it points at.
     * Returns a success-shaped response when the original was approved or held for
     * review, false when it was declined/voided (safe to resend), or a WP_Error when
     * the rejection is not a recoverable duplicate.
     *
     * @return array|false|\WP_Error
     */
    protected function resolveDuplicateOriginal(\WP_Error $error, $transaction, string $poNumber)
    {
        $errorData = (array) $error->get_error_data();
        $firstError = Arr::first((array) Arr::get($errorData, 'transactionResponse.errors', []));
        $originalId = (string) Arr::get($errorData, 'transactionResponse.transId');

        if ((string) Arr::get((array) $firstError, 'errorCode') !== '11' || !$originalId) {
            return $error;
        }

        $details = $this->api->getTransactionDetails($originalId);

        if (!$details
            || (string) Arr::get($details, 'order.purchaseOrderNumber') !== $poNumber
            || !$this->detailsMatchTransaction($details, $transaction)
        ) {
            fluent_cart_error_log('Authorize.Net Payment', sprintf('Authorize.Net reported transaction %s as a duplicate but it could not be matched to this checkout.', $originalId), [
                'module_name' => 'order',
                'module_id'   => $transaction->order_id,
            ]);

            return new \WP_Error(
                'authnet_duplicate_transaction',
                __('Authorize.Net flagged this payment as a duplicate of an earlier one. Please contact us before trying again.', 'fluent-cart-pro')
            );
        }

        $responseCode = (string) Arr::get($details, 'responseCode');
        $status = (string) Arr::get($details, 'transactionStatus');

        if (!in_array($responseCode, ['1', '4'], true) || $status === 'voided') {
            return false;
        }

        fluent_cart_add_log(
            __('Authorize.Net Payment', 'fluent-cart-pro'),
            sprintf(__('Recovered transaction %s whose response was lost; the card was not charged again.', 'fluent-cart-pro'), $originalId),
            'info',
            [
                'module_name' => 'order',
                'module_id'   => $transaction->order_id,
            ]
        );

        $response = [
            'messages'            => ['resultCode' => 'Ok'],
            'transactionResponse' => [
                'responseCode'  => $responseCode,
                'transId'       => $originalId,
                'authCode'      => Arr::get($details, 'authCode'),
                'payment'       => Arr::get($details, 'payment', []),
                'submitTimeUTC' => Arr::get($details, 'submitTimeUTC'),
                'recoveredFrom' => 'duplicate',
            ],
        ];

        // A first payment sent with profile.createProfile answers with profileResponse;
        // the details record carries the same ids once the profile exists.
        $profile = Arr::get($details, 'profile', []);
        if (Arr::get($profile, 'customerProfileId') && Arr::get($profile, 'customerPaymentProfileId')) {
            $response['profileResponse'] = [
                'messages'                     => ['resultCode' => 'Ok'],
                'customerProfileId'            => (string) Arr::get($profile, 'customerProfileId'),
                'customerPaymentProfileIdList' => ['numericString' => [(string) Arr::get($profile, 'customerPaymentProfileId')]],
            ];
        }

        return $response;
    }

    protected function detailsMatchTransaction(array $details, $transaction): bool
    {
        $chargedAmount = Arr::get($details, 'settleAmount') ?: Arr::get($details, 'authAmount');

        return (int) Arr::get($details, 'order.invoiceNumber') === (int) $transaction->order_id
            && AuthorizeDotNetHelper::formatAmount($transaction->total, $transaction->currency)
                === AuthorizeDotNetHelper::formatAmount((int) round(((float) $chargedAmount) * 100), $transaction->currency);
    }

    /**
     * Create a customer with the entered card after customer resolution found no match.
     *
     * @return array{customerProfileId: string, customerPaymentProfileId: string, source: string}|\WP_Error
     *   Error code `authnet_duplicate_profile` when Auth.Net reports a duplicate the
     *   lookup could not see; the duplicate id is saved so the next attempt uses it.
     */
    protected function createCustomerProfileFromToken($customer, $billTo, $descriptor, $dataValue)
    {
        $createData = [
            'merchantAuthentication' => $this->api->getMerchantAuthentication(),
            'profile'                => [
                'merchantCustomerId' => (string) $customer->id,
                'email'              => $customer->email,
                'paymentProfiles'    => [
                    'customerType' => 'individual',
                    'billTo'       => $billTo,
                    'payment'      => [
                        'opaqueData' => [
                            'dataDescriptor' => $descriptor,
                            'dataValue'      => $dataValue,
                        ],
                    ],
                ],
            ],
            'validationMode' => $this->settings->getMode() === 'test' ? 'testMode' : 'liveMode',
        ];

        $response = $this->api->createAuthorizeNetObject('createCustomerProfileRequest', $createData);

        if (is_wp_error($response)) {
            // E00039: a profile with this merchant customer id exists but the lookup did
            // not return it yet. The token was submitted, so stop and remember the id.
            $errorData         = (array) $response->get_error_data();
            $duplicateProfileId = Arr::get($errorData, 'customerProfileId')
                ?: AuthorizeDotNetHelper::extractDuplicateProfileIdFromError($response->get_error_message());
            if ($duplicateProfileId) {
                $customer->updateMeta('authorize_dot_net_profile_id', $duplicateProfileId);

                return new \WP_Error(
                    'authnet_duplicate_profile',
                    __('An existing Authorize.Net customer record was found for you. Please submit your payment again.', 'fluent-cart-pro'),
                    $errorData
                );
            }
            return $response;
        }

        $profileId        = (string) Arr::get($response, 'customerProfileId');
        $paymentProfileId = (string) Arr::first(Arr::get($response, 'customerPaymentProfileIdList', []));

        if (!$profileId || !$paymentProfileId) {
            return new \WP_Error('authnet_profile_creation_failed', __('Failed to create Authorize.Net customer profile.', 'fluent-cart-pro'));
        }

        $customer->updateMeta('authorize_dot_net_profile_id', $profileId);

        return [
            'customerProfileId'        => $profileId,
            'customerPaymentProfileId' => $paymentProfileId,
            'source'                   => 'newly created',
        ];
    }

    /**
     * Resolve the customer without submitting payment data. Only E00040 means
     * missing; all other lookup errors stop checkout before the token is sent.
     *
     * @return string|null|\WP_Error Profile ID, null when absent, or lookup error.
     */
    protected function resolveCustomerProfileId($customer)
    {
        $savedProfileId = $customer->getMeta('authorize_dot_net_profile_id');
        $lookups = [];
        if ($savedProfileId) {
            $lookups[] = ['customerProfileId' => (string) $savedProfileId];
        }
        $lookups[] = ['merchantCustomerId' => (string) $customer->id];

        foreach ($lookups as $lookup) {
            $response = $this->api->createAuthorizeNetObject('getCustomerProfileRequest', array_merge([
                'merchantAuthentication' => $this->api->getMerchantAuthentication(),
            ], $lookup));

            if (is_wp_error($response)) {
                if (Arr::get((array) $response->get_error_data(), 'messages.message.0.code') === 'E00040') {
                    continue;
                }

                return $response;
            }

            $profileId = (string) Arr::get($response, 'profile.customerProfileId');
            if (!$profileId) {
                return new \WP_Error('authnet_profile_lookup_failed', __('Authorize.Net did not return a customer profile ID.', 'fluent-cart-pro'));
            }

            $customer->updateMeta('authorize_dot_net_profile_id', $profileId);

            return $profileId;
        }

        return null;
    }

    /**
     * Submits the entered card token as a new payment profile on a customer profile
     * already known to exist. If Auth.Net reports the card as a duplicate, returns
     * the matching payment profile ID from that response.
     *
     * @return array{customerProfileId: string, customerPaymentProfileId: string, source: string}|\WP_Error
     */
    protected function registerPaymentProfileFromToken($customerProfileId, array $billTo, $descriptor, $dataValue)
    {
        $data = [
            'merchantAuthentication' => $this->api->getMerchantAuthentication(),
            'customerProfileId'      => (string) $customerProfileId,
            'paymentProfile'         => [
                'customerType' => 'individual',
                'billTo'       => $billTo,
                'payment'      => [
                    'opaqueData' => [
                        'dataDescriptor' => $descriptor,
                        'dataValue'      => $dataValue,
                    ],
                ],
            ],
            'validationMode' => $this->settings->getMode() === 'test' ? 'testMode' : 'liveMode',
        ];

        $response = $this->api->createAuthorizeNetObject('createCustomerPaymentProfileRequest', $data);

        if (is_wp_error($response)) {
            $errorMessage = $response->get_error_message();
            $errorData    = (array) $response->get_error_data();

            $existingPaymentProfileId = (string) Arr::get($errorData, 'customerPaymentProfileId');
  
            if ($existingPaymentProfileId && stripos($errorMessage, 'duplicate') !== false) {
                return [
                    'customerProfileId'        => (string) $customerProfileId,
                    'customerPaymentProfileId' => $existingPaymentProfileId,
                    'source'                   => 'saved profile (card already stored)',
                ];
            }

            return $response;
        }

        $paymentProfileId = (string) Arr::get($response, 'customerPaymentProfileId');
        if (!$paymentProfileId) {
            return new \WP_Error('authnet_payment_profile_failed', __('Failed to add the card to the Authorize.Net customer profile.', 'fluent-cart-pro'));
        }

        return [
            'customerProfileId'        => (string) $customerProfileId,
            'customerPaymentProfileId' => $paymentProfileId,
            'source'                   => 'saved profile (card added)',
        ];
    }

    /**
     * The ARB schedule may be created later (held-for-review approval, E00040 retry);
     * the transaction carries which payment profile actually paid so that run binds
     * to the same card. A customer profile id without a payment profile id means the
     * paid card still has to be attached to that profile — deferred activation retries
     * exactly that and never substitutes another card or profile.
     */
    protected function rememberPaymentProfile($transaction, array $profile): void
    {
        $transaction->meta = array_merge($transaction->meta ?? [], [
            'authnet_customer_profile_id' => (string) Arr::get($profile, 'customerProfileId'),
            'authnet_payment_profile_id'  => (string) Arr::get($profile, 'customerPaymentProfileId'),
        ]);
        $transaction->save();
    }

    protected function logProfileReady($subscriptionModel, $source, array $profile): void
    {
        if (!$subscriptionModel) {
            return;
        }

        $subscriptionModel->addLog(
            __('Authorize.Net Customer Profile', 'fluent-cart-pro'),
            sprintf(
                /* translators: 1: profile source, 2: customer profile id, 3: payment profile id */
                __('Customer profile ready (%1$s) — profileId: %2$s, paymentProfileId: %3$s', 'fluent-cart-pro'),
                $source,
                Arr::get($profile, 'customerProfileId', 'NULL'),
                Arr::get($profile, 'customerPaymentProfileId', 'NULL')
            )
        );
    }

    /**
     * The first payment is captured but the ARB subscription can't be created yet
     * (usually E00040 — Auth.Net's ARB service hasn't replicated the new profile).
     * Flag it for the five-minute sweep, log it, and finish checkout normally.
     *
     * $subscriptionPayload, when given, is the already-built ARB `subscription` array
     * so the retry doesn't have to recompute interval/trial/startDate from scratch.
     *
     * Formerly queueArbRetryAndRespond().
     */
    protected function deferSubscriptionCreationAndRespond($transaction, $subscriptionModel, $reason, array $profile = [], ?array $subscriptionPayload = null)
    {
        AuthorizeDotNetSubscriptions::deferSubscriptionCreation($subscriptionModel, $subscriptionPayload);

        $profileContext = '';
        if ($profile) {
            $profileContext = sprintf(
                ' (profileId: %s, paymentProfileId: %s)',
                Arr::get($profile, 'customerProfileId', 'NULL'),
                Arr::get($profile, 'customerPaymentProfileId', 'NULL')
            );
        }

        $subscriptionModel->addLog(
            __('Authorize.Net Subscription Deferred', 'fluent-cart-pro'),
            sprintf(
                /* translators: %s: reason the schedule could not be created yet */
                __('Payment received, but the Authorize.Net subscription schedule could not be created yet: %s. It will be retried automatically.', 'fluent-cart-pro'),
                $reason
            ) . $profileContext,
            'warning'
        );

        (new StatusHelper($transaction->order))->syncOrderStatuses($transaction);

        wp_send_json([
            'status'      => 'success',
            'redirect_to' => $transaction->getReceiptPageUrl(),
        ]);
    }

    /** @deprecated 1.6.5 Use deferSubscriptionCreationAndRespond(). */
    protected function queueArbRetryAndRespond($transaction, $subscriptionModel, $reason, array $profile = [], ?array $subscriptionPayload = null)
    {
        _deprecated_function(__METHOD__, '1.6.5', __CLASS__ . '::deferSubscriptionCreationAndRespond()');
        return $this->deferSubscriptionCreationAndRespond($transaction, $subscriptionModel, $reason, $profile, $subscriptionPayload);
    }

    /**
     * Handles subscription creation failure after first payment may have already been charged.
     * Auth.Net charges remain unsettled/pending after capture — neither void nor refund is
     * reliably available at this point — so we do NOT attempt auto-reversal here. Instead we
     * log the failure and flag the transaction so an admin can void/refund manually once
     * the charge reaches a reversible state.
     * Returns the original WP_Error so caller can bubble it up.
     * Payment confirmation via IPN can try subscription creation again.
     */
    protected function resolveBillingPeriod($subscriptionModel): array
    {
        $interval = $subscriptionModel->billing_interval;
        $intervalMap = [
            'daily'       => 'days',
            'weekly'      => 'days',
            'monthly'     => 'months',
            'yearly'      => 'months',
            'quarterly'   => 'months',
            'half_yearly' => 'months',
        ];

        $intervalCount = 1;

        if ($interval === 'weekly') {
            $intervalCount = 7;
        } elseif ($interval === 'yearly') {
            $intervalCount = 12;
        } elseif ($interval === 'quarterly') {
            $intervalCount = 3;
        } elseif ($interval === 'half_yearly') {
            $intervalCount = 6;
        }

        return apply_filters('fluent_cart/subscription_billing_period', [
                'interval_frequency' => $intervalCount,
                'interval_unit'      => $intervalMap[$interval] ?? 'months',
            ],
            [
                'subscription_interval' => $interval,
                'payment_method'        => 'authorize_dot_net',
            ]
        );
    }

    /**
     * ARB accepts 7 to 365 days or 1 to 12 months. Checked before any charge so a
     * schedule Authorize.Net would refuse never takes the first payment.
     */
    protected function isBillingPeriodSupported(array $billingPeriod): bool
    {
        $frequency = Arr::get($billingPeriod, 'interval_frequency');
        if (!is_numeric($frequency) || (int) $frequency != $frequency) {
            return false;
        }

        $limits = ['days' => [7, 365], 'months' => [1, 12]];
        $unit = Arr::get($billingPeriod, 'interval_unit');
        if (!isset($limits[$unit])) {
            return false;
        }

        return (int) $frequency >= $limits[$unit][0] && (int) $frequency <= $limits[$unit][1];
    }

    protected function handleSubscriptionCreationFailure(\WP_Error $wpError, $transaction, $subscriptionModel, array $profile = []): \WP_Error
    {
        $logContext = [
            'module_name' => 'subscription',
            'module_id'   => $subscriptionModel ? $subscriptionModel->id : null,
        ];

        $profileContext = '';
        if ($profile) {
            $profileContext = sprintf(
                ' (profileId: %s, paymentProfileId: %s)',
                Arr::get($profile, 'customerProfileId', 'NULL'),
                Arr::get($profile, 'customerPaymentProfileId', 'NULL')
            );
        }

        fluent_cart_add_log(
            __('Authorize.Net Subscription Creation Error', 'fluent-cart-pro'),
            $wpError->get_error_message() . $profileContext,
            'error',
            $logContext
        );

        $hasCapturedFirstPayment = $transaction
            && (int) $transaction->total > 0
            && !empty($transaction->vendor_charge_id)
            && $transaction->status === Status::TRANSACTION_SUCCEEDED;

        if ($hasCapturedFirstPayment) {
            $manualReviewMessage = sprintf(
                /* translators: %s: vendor transaction id */
                __('First payment was captured (Auth.Net transaction ID: %s) but subscription creation failed. Please void or refund the charge manually from Authorize.Net dashboard.', 'fluent-cart-pro'),
                $transaction->vendor_charge_id
            );

            // Flag transaction meta so admins can find these in reports
            $transaction->fill([
                'meta' => array_merge($transaction->meta ?? [], [
                    'authnet_subscription_setup_failed' => true,
                    'authnet_subscription_failure_reason' => $wpError->get_error_message(),
                    'authnet_manual_action_required' => 'void_or_refund',
                ]),
            ]);
            $transaction->save();

            fluent_cart_add_log(
                __('Authorize.Net Manual Action Required', 'fluent-cart-pro'),
                $manualReviewMessage,
                'warning',
                $logContext
            );
        }

        if ($subscriptionModel) {
            $subscriptionModel->addLog(
                __('Authorize.Net Subscription', 'fluent-cart-pro'),
                __('Subscription creation failed: ', 'fluent-cart-pro') . $wpError->get_error_message() . $profileContext,
                'error'
            );
        }

        (new StatusHelper($transaction->order))->syncOrderStatuses($transaction);

        wp_send_json([
            'status'       => 'success',
            'redirect_to' => $transaction->getReceiptPageUrl(),
        ]);
        
    }

}
