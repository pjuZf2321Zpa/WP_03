<?php

namespace BitApps\IntegrationsPro\Triggers\Breakdance;

use BitApps\IntegrationsPro\Config;
use Breakdance\Forms\Actions\Action;

if (class_exists('Breakdance\Forms\Actions\Action')) {
    class BreakdanceAction extends Action
    {
        public static function name()
        {
            return 'Bit Integrations';
        }

        public static function slug()
        {
            return 'bit-integrations-pro';
        }

        public function run($form, $settings, $extra)
        {
            $flowClass = bit_integrations_get_class('Flow\\Flow');
            $helperClass = bit_integrations_get_class('Core\\Util\\Helper');

            $reOrganizeId = "{$extra['formId']}-{$extra['postId']}";
            $formData = BreakdanceHelper::setFields($extra, $form);

            if (get_option(Config::withFreePrefix('BreakdanceHook_test')) !== false) {
                update_option(Config::withFreePrefix('BreakdanceHook_test'), [
                    'formData'   => $formData,
                    'primaryKey' => [(object) ['key' => 'formId', 'value' => $extra['formId']]]
                ]);
            }

            global $wpdb;
            $flows = $wpdb->get_results($wpdb->prepare(
                "SELECT * FROM {$wpdb->prefix}btcbi_flow 
                    WHERE status = true 
                    AND triggered_entity = 'Breakdance' 
                    AND (triggered_entity_id = 'BreakdanceHook' OR triggered_entity_id = %s)",
                $reOrganizeId
            ));

            if (!$flows) {
                return;
            }

            foreach ($flows as $flow) {
                $flowDetails = json_decode($flow->flow_details);

                if (!isset($flowDetails->primaryKey) && $flow->triggered_entity_id == $reOrganizeId) {
                    $flowClass::execute('Breakdance', $reOrganizeId, $extra['fields'], [$flow]);

                    continue;
                }

                if (!\is_array($flowDetails->primaryKey)) {
                    continue;
                }

                $isPrimaryKeysMatch = true;
                foreach ($flowDetails->primaryKey as $primaryKey) {
                    $primaryKeyValue = $helperClass::extractValueFromPath($extra, $primaryKey->key, 'Breakdance');

                    if ($primaryKey->value != $primaryKeyValue) {
                        $isPrimaryKeysMatch = false;

                        break;
                    }
                }

                if ($isPrimaryKeysMatch) {
                    $data = array_column($formData, 'value', 'name');
                    $flowClass::execute('Breakdance', 'BreakdanceHook', $data, [$flow]);
                }
            }

            return ['type' => 'success'];
        }
    }
}
