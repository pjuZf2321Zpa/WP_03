<?php
/**
 * Plugin Loader.
 *
 * @package sureforms-pro
 * @since 0.0.1
 */

namespace SRFM_Pro;

use SRFM_Pro\Admin\Admin;
use SRFM_Pro\Admin\Analytics;
use SRFM_Pro\Admin\Licensing;
use SRFM_Pro\Inc\Block_Assets;
use SRFM_Pro\Inc\Features;
use SRFM_Pro\Inc\Abilities\Pro_Abilities_Registrar;
use SRFM_Pro\Inc\Extensions\Conditional_Logic;
use SRFM_Pro\Inc\Extensions\Additional_Form_Restrictions;
use SRFM_Pro\Inc\Extensions\Migrator_CF7;
use SRFM_Pro\Inc\Extensions\Migrator_WPForms;
use SRFM_Pro\Inc\Extensions\Migrator_Gravity;
use SRFM_Pro\Inc\Extensions\Migrator_Ninja;
use SRFM_Pro\Inc\Extensions\Field_Restrictions;
use SRFM_Pro\Inc\Extensions\Entries_Management;
use SRFM_Pro\Inc\Extensions\Entries_Shortcode;
use SRFM_Pro\Inc\Extensions\Gutenberg_Hooks;
use SRFM_Pro\Inc\Extensions\Hooks;
use SRFM_Pro\Inc\Extensions\Page_Break;
use SRFM_Pro\Inc\Extensions\Sanitize_Callbacks;
use SRFM_Pro\Inc\Extensions\Attach_Uploads;
use SRFM_Pro\Inc\Extensions\Conditional_Emails;
use SRFM_Pro\Inc\Extensions\Conditional_Confirmations;
use SRFM_Pro\Inc\Extensions\Embed_Styling;
use SRFM_Pro\Inc\Extensions\Google_Maps;
use SRFM_Pro\Inc\Extensions\Template_Builder;
use SRFM_Pro\Inc\Global_Settings;
use SRFM_Pro\Inc\Global_Settings\Advanced_Restriction_Defaults;
use SRFM_Pro\Inc\Global_Settings\Distraction_Free;
use SRFM_Pro\Inc\Page_Builders\Bricks\Form_Widget_Pro as Bricks_Form_Widget_Pro;
use SRFM_Pro\Inc\Page_Builders\Elementor\Form_Widget_Pro;
use SRFM_Pro\Inc\Integrations\Webhooks;
use SRFM_Pro\Inc\Updater;
use SRFM\Inc\Helper as Core_Helper;
use SRFM_Pro\Inc\Calculation;
use SRFM_Pro\Inc\Conversational_Form;
use SRFM_Pro\Inc\Custom_App\Load as Custom_App;
use SRFM_Pro\Inc\Custom_Post_Type\Init as Custom_Post_Type;
use SRFM_Pro\Inc\Databases\Register as DB_Register;
use SRFM_Pro\Inc\Databases\Tables\Save_Resume as Save_Resume_Table;
use SRFM_Pro\Inc\Dynamic_Options\Init as Dynamic_Options;
use SRFM_Pro\Inc\Native_Integrations;
use SRFM_Pro\Inc\Partial_Entries\Init as Partial_Entries;
use SRFM_Pro\Inc\Payments\PayPal\Admin_PayPal_Handler;
use SRFM_Pro\Inc\Payments\PayPal\Frontend as Paypal_Frontend;
use SRFM_Pro\Inc\Payments\PayPal\Settings as Paypal_Settings;
use SRFM_Pro\Inc\Payments\PayPal\Webhook_Listener;
use SRFM_Pro\Inc\Pdf\Pdf;
use SRFM_Pro\Inc\Quiz\Init as Quiz;
use SRFM_Pro\Inc\Recurring_Entry_Limit\Init as Recurring_Entry_Limit;
use SRFM_Pro\Inc\Repeater\Init as Repeater;
use SRFM_Pro\Inc\Save_Resume\Init as Save_Resume;
use SRFM_Pro\Inc\Signature\Init as Signature;
use SRFM_Pro\Inc\Surecontact_Integration;
use SRFM_Pro\Inc\Survey\Init as Survey;
use SRFM_Pro\Inc\User_Registration\Init as User_Registration;
use SRFM_Pro\Inc\User_Registration\Processor as User_Registration_Processor;
use SRFM_Pro\Inc\Zapier;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Plugin Loader.
 *
 * @package sureforms-pro
 * @since 0.0.1
 */
class Plugin_Loader {
	/**
	 * User meta holding "<SureForms version>|<recommended version>" when the user dismissed the
	 * "please update SureForms" notice. The notice returns once either version changes.
	 *
	 * @since 2.14.0
	 */
	public const CORE_NOTICE_DISMISSED_META = 'srfm_pro_core_update_notice_dismissed';

	/**
	 * The admin-post action, also used as the nonce action, that dismisses that notice.
	 *
	 * @since 2.14.0
	 */
	public const CORE_NOTICE_DISMISS_ACTION = 'srfm_pro_dismiss_core_update_notice';

	/**
	 * Instance
	 *
	 * @access private
	 * @var object Class Instance.
	 * @since 0.0.1
	 */
	private static $instance;

	/**
	 * Namespaces that moved when inc/pro and inc/business were flattened into inc/.
	 *
	 * The autoloader aliases a class requested by its old name to the class at its
	 * new name, so code outside this plugin keeps working. WP Fusion's SureForms
	 * actions extend SRFM_Pro\Inc\Pro\Native_Integrations\WordPress_Action, so
	 * keep this map until that plugin uses the new names. Longer prefixes come first.
	 *
	 * @since 2.13.1
	 * @var array<string, string>
	 */
	const MOVED_NAMESPACES = [
		'SRFM_Pro\\Inc\\Pro\\Database\\'      => 'SRFM_Pro\\Inc\\Databases\\',
		'SRFM_Pro\\Inc\\Business\\Database\\' => 'SRFM_Pro\\Inc\\Databases\\',
		'SRFM_Pro\\Inc\\Pro\\'                => 'SRFM_Pro\\Inc\\',
		'SRFM_Pro\\Inc\\Business\\'           => 'SRFM_Pro\\Inc\\',
	];

	/**
	 * Constructor
	 *
	 * @since 0.0.1
	 */
	public function __construct() {
		spl_autoload_register( [ $this, 'autoload' ] );

		add_filter( 'srfm_blocks', [ $this, 'add_pro_blocks' ] );
		// Added before plugins_loaded, when SureForms first reads the feature rows.
		add_filter( 'srfm_features', [ Features::class, 'register' ] );
		add_filter( 'srfm_feature_labels', [ Features::class, 'labels' ] );
		add_action( 'init', [ $this, 'on_plugin_init' ] );
		register_activation_hook(
			SRFM_PRO_FILE,
			[ $this, 'activation_reset' ]
		);
		// Stop the partial-entries worker with the plugin. It reschedules itself on
		// init once reactivated, and the reminder staleness guard keeps that restart from
		// emailing visitors whose drafts went stale while it was off.
		register_deactivation_hook(
			SRFM_PRO_FILE,
			static function () {
				if ( class_exists( 'SRFM_Pro\\Inc\\Partial_Entries\\Lifecycle' ) ) {
					\SRFM_Pro\Inc\Partial_Entries\Lifecycle::deactivate();
				}
				// The lifecycle backfill's own cron event. Its progress options stay:
				// the pass is resumable, and a reactivated site should carry on rather
				// than re-scan a table it has already classified.
				if ( class_exists( 'SRFM_Pro\\Inc\\Databases\\Tables\\Save_Resume' ) ) {
					wp_clear_scheduled_hook( \SRFM_Pro\Inc\Databases\Tables\Save_Resume::BACKFILL_CRON_HOOK );
				}
			}
		);
		add_action( 'admin_init', [ $this, 'activation_redirect' ] );
		add_action( 'plugins_loaded', [ $this, 'load_textdomain' ] );
	}

	/**
	 * Initiator
	 *
	 * @since 0.0.1
	 * @return object initialized object of class.
	 */
	public static function get_instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Autoload classes.
	 *
	 * @param string $class class name.
	 * @return void
	 */
	public function autoload( $class ) {
		if ( 0 !== strpos( $class, __NAMESPACE__ ) ) {
			return;
		}

		foreach ( self::MOVED_NAMESPACES as $old_prefix => $new_prefix ) {
			if ( 0 !== strpos( $class, $old_prefix ) ) {
				continue;
			}

			$current = $new_prefix . substr( $class, strlen( $old_prefix ) );
			if ( class_exists( $current ) || interface_exists( $current ) || trait_exists( $current ) ) {
				class_alias( $current, $class );
			}
			return;
		}

		$class_to_load = $class;

		$filename = preg_replace(
			[ '/^' . __NAMESPACE__ . '\\\/', '/([a-z])([A-Z])/', '/_/', '/\\\/' ],
			[ '', '$1-$2', '-', DIRECTORY_SEPARATOR ],
			$class_to_load
		);

		if ( is_string( $filename ) ) {
			$filename = strtolower( $filename );

			$file = SRFM_PRO_DIR . $filename . '.php';

			// if the file redable, include it.
			if ( is_readable( $file ) ) {
				require_once $file;
			}
		}
	}

	/**
	 * Set Redirect flag on activation.
	 *
	 * @Hooked - register_activation_hook
	 *
	 * @return void
	 * @since 0.0.1
	 */
	public function activation_reset() {
		update_option( '__srfm_pro_do_redirect', true );
	}

	/**
	 * Handle the activation redirect to the Dashboard.
	 *
	 * @Hooked - admin_init
	 *
	 * @return void
	 * @since 0.0.1
	 */
	public function activation_redirect() {

		// Avoid redirection in case of WP_CLI calls.
		if ( defined( 'WP_CLI' ) && \WP_CLI ) {
			return;
		}

		// Avoid redirection in case of ajax calls.
		if ( wp_doing_ajax() ) {
			return;
		}

		$do_redirect = apply_filters( 'srfm_pro_enable_redirect_activation', get_option( '__srfm_pro_do_redirect' ) );

		if ( $do_redirect && is_plugin_active( 'sureforms/sureforms.php' ) ) {

			update_option( '__srfm_pro_do_redirect', false );

			if ( ! is_multisite() ) {
				wp_safe_redirect(
					add_query_arg(
						[
							'page'                         => 'sureforms_form_settings',
							'tab'                          => 'account-settings',
							'srfm-pro-activation-redirect' => true,
						],
						admin_url( 'admin.php' )
					)
				);
				exit;
			}
		}
	}

	/**
	 * Classify the active SureForms version against Business's floor and recommended versions.
	 *
	 * The floor (SRFM_PRO_CORE_MIN_VER) is the oldest SureForms that Business can
	 * run on without fataling — below it, Business calls core APIs that don't exist
	 * yet (e.g. the Updater's inherited Base::table_exists(), free 2.12.6+), so it
	 * must not load. Unlike the recommended version it is NOT bumped every release.
	 * Between the floor and the recommended version Business keeps loading; the
	 * newer-core APIs it uses in that band are feature-checked before use.
	 *
	 * @param string $core_ver Active SureForms version (SRFM_VER).
	 * @since 2.14.0
	 * @return string 'incompatible' when below SRFM_PRO_CORE_MIN_VER (Business cannot load),
	 *                'update' when loadable but below SRFM_PRO_CORE_RQD_VER (loads + update notice),
	 *                'ok' otherwise.
	 */
	public static function core_version_state( $core_ver ) {
		if ( ! version_compare( $core_ver, SRFM_PRO_CORE_MIN_VER, '>=' ) ) {
			return 'incompatible';
		}
		if ( ! version_compare( $core_ver, SRFM_PRO_CORE_RQD_VER, '>=' ) ) {
			return 'update';
		}
		return 'ok';
	}

	/**
	 * Whether the user dismissed the "please update SureForms" notice for the current versions.
	 *
	 * The hard "not compatible" notice is never dismissible: below the floor Business doesn't load.
	 *
	 * @param bool $incompatible Whether SureForms is below SRFM_PRO_CORE_MIN_VER.
	 * @param int  $user_id      User ID.
	 * @since 2.14.0
	 * @return bool True when the soft notice was dismissed for this SureForms and recommended version.
	 */
	public static function is_core_notice_dismissed( $incompatible, $user_id ) {
		if ( $incompatible || $user_id <= 0 ) {
			return false;
		}

		return self::core_notice_dismiss_key() === get_user_meta( $user_id, self::CORE_NOTICE_DISMISSED_META, true );
	}

	/**
	 * The value a dismissal stores: the active SureForms version and the recommended version.
	 *
	 * @since 2.14.0
	 * @return string "<SureForms version>|<recommended version>".
	 */
	public static function core_notice_dismiss_key() {
		return ( defined( 'SRFM_VER' ) ? SRFM_VER : '' ) . '|' . SRFM_PRO_CORE_RQD_VER;
	}

	/**
	 * Nonced admin-post URL that dismisses the "please update SureForms" notice.
	 * Unescaped, because the React notice navigates to it; the PHP notice escapes it on output.
	 *
	 * @since 2.14.0
	 * @return string The URL.
	 */
	private static function core_notice_dismiss_url() {
		return add_query_arg(
			[
				'action'   => self::CORE_NOTICE_DISMISS_ACTION,
				'_wpnonce' => wp_create_nonce( self::CORE_NOTICE_DISMISS_ACTION ),
			],
			admin_url( 'admin-post.php' )
		);
	}

	/**
	 * Handle the admin-post request that dismisses the "please update SureForms" notice for the current user and
	 * versions, then return to the previous admin screen.
	 *
	 * @since 2.14.0
	 * @return void
	 */
	public function dismiss_core_update_notice() {
		if ( ! current_user_can( 'update_plugins' ) ) {
			wp_die( esc_html__( 'You are not allowed to do this.', 'sureforms-pro' ), '', [ 'response' => 403 ] );
		}

		check_admin_referer( self::CORE_NOTICE_DISMISS_ACTION );

		update_user_meta( get_current_user_id(), self::CORE_NOTICE_DISMISSED_META, self::core_notice_dismiss_key() );

		$referer = wp_get_referer();
		wp_safe_redirect( $referer ? $referer : admin_url() );
		exit;
	}

	/**
	 * Raw text for the outdated-SureForms notice, shared by the PHP and React notices.
	 * The PHP notice escapes it on output; React escapes it when rendering.
	 *
	 * Below the floor Business cannot load, so it keeps the existing "not compatible" text and its
	 * translations. Above the floor Business still works, so it only recommends an update.
	 *
	 * @param bool $incompatible Whether SureForms is below SRFM_PRO_CORE_MIN_VER.
	 * @since 2.14.0
	 * @return string Unescaped notice text.
	 */
	private static function out_of_date_message( $incompatible ) {
		if ( $incompatible ) {
			return __( 'SureForms Premium is not compatible with the current SureForms free version.', 'sureforms-pro' );
		}

		return sprintf(
			/* translators: %s: paid plugin name. */
			__( 'Some %s features need a newer version of SureForms. Please update SureForms to get the latest features.', 'sureforms-pro' ),
			'SureForms Premium'
		);
	}

	/**
	 * After Finish loading SureForms Free, then loaded pro core functionality
	 *
	 * Hooked - srfm_core_loaded
	 *
	 * @return void
	 * @since 0.0.1
	 */
	public function on_plugin_init() {

		if ( ! defined( 'SRFM_VER' ) ) {
			add_action( 'admin_notices', [ $this, 'fail_load' ] );
			// Register for React early (before admin_enqueue_scripts).
			add_action( 'admin_init', [ $this, 'register_fail_load_react_notice' ], 5 );
			return;
		}

		// Bail when SureForms never finished loading (its srfm_core_loaded hook never
		// fired, so its classes aren't available) or is below the hard floor (Business
		// would call core APIs that don't exist yet and fatal every request). The
		// floor is NOT the per-release recommended version — see core_version_state().
		if ( ! did_action( 'srfm_core_loaded' ) || 'incompatible' === self::core_version_state( SRFM_VER ) ) {
			add_action( 'admin_notices', [ $this, 'fail_load_out_of_date' ] );
			// Register for React early (before admin_enqueue_scripts).
			add_action( 'admin_init', [ $this, 'register_fail_load_out_of_date_react_notice' ], 5 );
			return;
		}

		// Between the floor and the recommended version Business keeps loading — it
		// never shuts off just because SureForms is a release or two behind. Only
		// nudge an update; the newer-core APIs used in this band are feature-checked.
		if ( 'update' === self::core_version_state( SRFM_VER ) ) {
			add_action( 'admin_notices', [ $this, 'fail_load_out_of_date' ] );
			add_action( 'admin_init', [ $this, 'register_fail_load_out_of_date_react_notice' ], 5 );
			add_action( 'admin_post_' . self::CORE_NOTICE_DISMISS_ACTION, [ $this, 'dismiss_core_update_notice' ] );
		}

		Analytics::get_instance();
		Page_Break::get_instance();
		// Webhooks are configured in the Integrations tab, so they follow Native integrations.
		if ( Features::is_on( 'native_integrations' ) ) {
			Webhooks::get_instance();
		}
		Pro_Abilities_Registrar::get_instance();
		Hooks::get_instance();
		Embed_Styling::get_instance();
		Updater::get_instance();

		// Initialize Elementor Pro integration if Elementor is active.
		if ( class_exists( '\Elementor\Plugin' ) ) {
			Form_Widget_Pro::get_instance();
		}

		// Initialize Bricks Pro integration if Bricks is active.
		if ( class_exists( '\Bricks\Elements' ) ) {
			Bricks_Form_Widget_Pro::get_instance();
		}

		if ( is_admin() ) {
			Admin::get_instance();
			Gutenberg_Hooks::get_instance();
			if ( Features::is_on( 'entries' ) ) {
				Entries_Management::get_instance();
			}
		} else {
			Global_Settings::get_instance();
			Block_Assets::get_instance();
		}
		Licensing::get_instance();
		if ( Features::is_on( 'conditional_logic' ) ) {
			Conditional_Logic::get_instance();
		}
		// Teach Free's CF7 migrator to emit Pro blocks (date-picker, upload,
		// hidden, slider, page-break) via the `srfm_migrator_*` filters.
		Migrator_CF7::get_instance();
		// Same seams, applied for the WPForms importer — adds date-time,
		// signature, repeater, rating, NPS, HTML, divider, password,
		// address, and the other Pro/addon WPForms field types.
		Migrator_WPForms::get_instance();
		// Pro-block routing for the Gravity Forms importer (sureforms#2793).
		Migrator_Gravity::get_instance();
		// Pro-block routing for the Ninja Forms importer (sureforms#2794).
		Migrator_Ninja::get_instance();
		Additional_Form_Restrictions::get_instance();
		Advanced_Restriction_Defaults::get_instance();
		Distraction_Free::get_instance();
		Field_Restrictions::get_instance();
		Sanitize_Callbacks::get_instance();
		Attach_Uploads::get_instance();
		if ( Features::is_on( 'conditional_emails' ) ) {
			Conditional_Emails::get_instance();
		}
		if ( Features::is_on( 'conditional_confirmations' ) ) {
			Conditional_Confirmations::get_instance();
		}
		// Builds the Pro features free's form templates declare.
		Template_Builder::get_instance();
		Google_Maps::get_instance();
		Entries_Shortcode::get_instance();

		$this->load_features();
	}

	/**
	 * Load every feature that used to be split across the Pro and Business tiers.
	 *
	 * @since 2.13.1
	 * @return void
	 */
	public function load_features() {
		// This is the single SureForms Business build. Free used to read the plan
		// from per-tier loader classes this build no longer ships, so it is told
		// the tier directly; free applies both filters on every read. Registered
		// only once on_plugin_init() has passed the SureForms version check, so an
		// older core that cannot render these features is never offered them.
		add_filter( 'srfm_pro_tier', static fn() => 'business' );
		add_filter( 'srfm_ai_field_mapping_has_business', '__return_true' );

		DB_Register::init();
		// Keeps the v13 lifecycle backfill going on admin requests and cron until every
		// legacy row is classified. No-op once it is done.
		Save_Resume_Table::schedule_backfill();
		// The OttoKit app follows the core OttoKit automations switch.
		if ( Features::is_on( 'ottokit' ) && method_exists( Core_Helper::class, 'is_suretriggers_ready' ) && Core_Helper::is_suretriggers_ready() ) {
			Custom_App::get_instance();
		}
		if ( Features::is_on( 'calculations' ) ) {
			Calculation::get_instance();
		}
		if ( Features::is_on( 'post_feeds' ) ) {
			Custom_Post_Type::get_instance();
		}
		if ( Features::is_on( 'quiz' ) ) {
			Quiz::get_instance();
		}
		Dynamic_Options::get_instance();
		Repeater::get_instance();
		Recurring_Entry_Limit::get_instance();
		if ( Features::is_on( 'pdf' ) ) {
			Pdf::get_instance();
		}
		if ( Features::is_on( 'user_registration' ) ) {
			User_Registration::get_instance();
		} else {
			// A password field can still arrive (e.g. from a cached copy of a form); it is
			// never stored or emailed, whatever the switch says.
			add_filter( 'srfm_before_prepare_submission_data', [ User_Registration_Processor::class, 'remove_password_field_from_form_data' ] );
		}
		// PayPal is a Payment block gateway, so it follows the core Payments switch.
		if ( Features::is_on( 'payments' ) ) {
			Paypal_Settings::get_instance();
			Paypal_Frontend::get_instance();
			Admin_PayPal_Handler::get_instance();
		}
		// Booted whatever the Payments switch says: renewals, refunds and disputes on
		// existing subscriptions keep arriving and must still be recorded.
		Webhook_Listener::get_instance();
		if ( Features::is_on( 'partial_entries' ) ) {
			Partial_Entries::get_instance();
		}
		Signature::get_instance();
		if ( Features::is_on( 'native_integrations' ) ) {
			Zapier::get_instance();
			Surecontact_Integration::get_instance();
		}
		if ( Features::is_on( 'conversational' ) ) {
			Conversational_Form::get_instance();
		}
		// Partial entries restores answers with the Save & Resume frontend script, so it
		// boots that class too; with Save & resume off, the class hooks only that script.
		if ( Features::is_on( 'save_resume' ) || Features::is_on( 'partial_entries' ) ) {
			Save_Resume::get_instance();
		}
		// Keep Survey after Pdf and Partial_Entries, where the Pro tier booted it.
		// Survey_Smart_Tags and Pdf both hook srfm_before_entry_data at priority 10,
		// so registration order decides which runs first: the PDF has to be built
		// while the submission is still in flight. Survey_Reports and Partial
		// Entries also both ask for submenu position 6 on admin_menu @30.
		if ( Features::is_on( 'survey' ) ) {
			Survey::get_instance();
		}
		if ( Features::is_on( 'native_integrations' ) ) {
			Native_Integrations::get_instance();
		}
	}

	/**
	 * Adds the pro blocks in the list free SureForms blocks.
	 *
	 * @param array<string> $blocks SureForms block list.
	 * @since 0.0.1
	 * @return array<string>
	 */
	public function add_pro_blocks( $blocks ) {
		$pro_blocks = [
			// pro blocks.
			'srfm/date-picker',
			'srfm/time-picker',
			'srfm/hidden',
			'srfm/slider',
			'srfm/rating',
			'srfm/upload',
			'srfm/html',
			'srfm/nps',
		];

		return array_merge( $blocks, $pro_blocks );
	}

	/**
	 * Check sureforms core is installed or not.
	 *
	 * @return bool
	 * @since 0.0.1
	 */
	public function is_core_installed() {
		$path    = 'sureforms/sureforms.php';
		$plugins = get_plugins();

		return isset( $plugins[ $path ] );
	}

	/**
	 * Admin Notice Callback if failed to load core.
	 *
	 * Hooked - admin_notices
	 *
	 * @return void
	 * @since 0.0.1
	 */
	public function fail_load() {
		$screen = get_current_screen();

		if ( empty( $screen ) ) {
			return;
		}

		if ( isset( $screen->parent_file ) && 'plugins.php' === $screen->parent_file && 'update' === $screen->id ) {
			return;
		}

		if ( 'sureforms_page_add-new-form' === $screen->id ) {
			return;
		}

		$plugin          = 'sureforms/sureforms.php';
		$pro_plugin_name = defined( 'SRFM_PRO_PRODUCT' ) ? SRFM_PRO_PRODUCT : 'SureForms Business';

		if ( $this->is_core_installed() ) {
			if ( ! current_user_can( 'activate_plugins' ) ) {
				return;
			}

			$activation_url = wp_nonce_url( 'plugins.php?action=activate&amp;plugin=' . $plugin . '&amp;plugin_status=all&amp;paged=1&amp;s', 'activate-plugin_' . $plugin );

			// Build PHP message for WordPress core pages.
			$php_message = '<h3>' . esc_html__( 'Activate the SureForms Plugin', 'sureforms-pro' ) . '</h3>';
			// translators: %s: this plugin's product name.
			$php_message .= '<p>' . sprintf( esc_html__( 'Before you can use all the features of %s, you need to activate the SureForms plugin first.', 'sureforms-pro' ), esc_html( $pro_plugin_name ) ) . '</p>';
			$php_message .= '<p>' . sprintf( '<a href="%s" class="button-primary">%s</a>', esc_url( $activation_url ), esc_html__( 'Activate Now', 'sureforms-pro' ) ) . '</p>';
		} else {
			if ( ! current_user_can( 'install_plugins' ) ) {
				return;
			}

			$install_url = wp_nonce_url( self_admin_url( 'update.php?action=install-plugin&plugin=sureforms' ), 'install-plugin_sureforms' );

			// Build PHP message for WordPress core pages.
			$php_message = '<h3>' . esc_html__( 'Install and Activate the SureForms Plugin', 'sureforms-pro' ) . '</h3>';
			// translators: %s: this plugin's product name.
			$php_message .= '<p>' . sprintf( esc_html__( 'Before you can use all the features of %s, you need to install and activate the SureForms plugin first.', 'sureforms-pro' ), esc_html( $pro_plugin_name ) ) . '</p>';
			$php_message .= '<p>' . sprintf( '<a href="%s" class="button-primary">%s</a>', esc_url( $install_url ), esc_html__( 'Install SureForms', 'sureforms-pro' ) ) . '</p>';
		}

		// Display in PHP (existing behavior - continues to work on WordPress core pages).
		// Each part of $php_message is escaped where it's built; wp_kses_post() keeps the markup.
		echo '<div class="error">' . wp_kses_post( $php_message ) . '</div>';

		// Note: React notice registration happens earlier on admin_init hook
		// See register_fail_load_react_notice() method.
	}

	/**
	 * Admin Notice Callback if failed to load updated core.
	 *
	 * Hooked - admin_notices
	 *
	 * @return void
	 * @since 0.0.1
	 */
	public function fail_load_out_of_date() {
		$screen = get_current_screen();

		if ( empty( $screen ) ) {
			return;
		}

		if ( ! current_user_can( 'update_plugins' ) ) {
			return;
		}

		$file_path = 'sureforms/sureforms.php';

		$upgrade_link = add_query_arg(
			[
				'action'   => 'upgrade-plugin',
				'plugin'   => $file_path,
				'_wpnonce' => wp_create_nonce( 'upgrade-plugin_' . $file_path ),
			],
			self_admin_url( 'update.php' )
		);
		$incompatible = 'incompatible' === self::core_version_state( SRFM_VER );
		if ( self::is_core_notice_dismissed( $incompatible, get_current_user_id() ) ) {
			return;
		}
		$message = self::out_of_date_message( $incompatible );

		// Display in PHP (existing behavior - continues to work on WordPress core pages).
		$php_message = '<p>' . esc_html( $message ) . '</p>';
		/* translators: %s: Recommended SureForms version number */
		$php_message .= '<p>' . sprintf( '<a href="%s" class="button-primary">%s</a>', esc_url( $upgrade_link ), esc_html( sprintf( __( 'Update SureForms to %s', 'sureforms-pro' ), SRFM_PRO_CORE_RQD_VER ) ) );
		if ( ! $incompatible ) {
			$php_message .= ' ' . sprintf( '<a href="%s" class="button">%s</a>', esc_url( self::core_notice_dismiss_url() ), esc_html__( 'Dismiss', 'sureforms-pro' ) );
		}
		$php_message  .= '</p>';
		$wrapper_class = $incompatible ? 'notice notice-error' : 'notice notice-warning';
		// Each part of $php_message is escaped where it's built; wp_kses_post() keeps the markup.
		echo '<div class="' . esc_attr( $wrapper_class ) . '">' . wp_kses_post( $php_message ) . '</div>';

		// Note: React notice registration happens earlier on admin_init hook.
		// See register_fail_load_out_of_date_react_notice() method.
	}

	/**
	 * Register React notice for missing core plugin.
	 * Called early on admin_init to ensure notices are registered before script localization.
	 *
	 * @return void
	 * @since 2.5.0
	 */
	public function register_fail_load_react_notice() {
		// Only register for React if Notice_Manager is available.
		if ( ! class_exists( 'SRFM\Admin\Notice_Manager' ) ) {
			return;
		}

		if ( ! current_user_can( 'install_plugins' ) && ! current_user_can( 'activate_plugins' ) ) {
			return;
		}

		$plugin          = 'sureforms/sureforms.php';
		$pro_plugin_name = defined( 'SRFM_PRO_PRODUCT' ) ? SRFM_PRO_PRODUCT : 'SureForms Business';

		if ( $this->is_core_installed() ) {
			if ( ! current_user_can( 'activate_plugins' ) ) {
				return;
			}

			$activation_url = wp_nonce_url( 'plugins.php?action=activate&amp;plugin=' . $plugin . '&amp;plugin_status=all&amp;paged=1&amp;s', 'activate-plugin_' . $plugin );
			$react_title    = esc_html__( 'Activate the SureForms Plugin', 'sureforms-pro' );
			/* translators: %s: Pro plugin name */
			$react_message = sprintf( esc_html__( 'Before you can use all the features of %s, you need to activate the SureForms plugin first.', 'sureforms-pro' ), esc_html( $pro_plugin_name ) );
			$action_label  = esc_html__( 'Activate Now', 'sureforms-pro' );
			$action_url    = $activation_url;
		} else {
			if ( ! current_user_can( 'install_plugins' ) ) {
				return;
			}

			$install_url = wp_nonce_url( self_admin_url( 'update.php?action=install-plugin&plugin=sureforms' ), 'install-plugin_sureforms' );
			$react_title = esc_html__( 'Install and Activate the SureForms Plugin', 'sureforms-pro' );
			/* translators: %s: Pro plugin name */
			$react_message = sprintf( esc_html__( 'Before you can use all the features of %s, you need to install and activate the SureForms plugin first.', 'sureforms-pro' ), esc_html( $pro_plugin_name ) );
			$action_label  = esc_html__( 'Install SureForms', 'sureforms-pro' );
			$action_url    = $install_url;
		}

		\SRFM\Admin\Notice_Manager::register_notice(
			[
				'id'      => 'sureforms-pro-missing-core',
				'variant' => 'error',
				'title'   => $react_title,
				'message' => $react_message,
				'actions' => [
					[
						'label'   => $action_label,
						'url'     => $action_url,
						'variant' => 'primary',
					],
				],
				'pages'   => [ 'all' ],
			]
		);
	}

	/**
	 * Register React notice for outdated core plugin.
	 * Called early on admin_init to ensure notices are registered before script localization.
	 *
	 * @return void
	 * @since 2.5.0
	 */
	public function register_fail_load_out_of_date_react_notice() {
		// Only register for React if Notice_Manager is available.
		if ( ! class_exists( 'SRFM\Admin\Notice_Manager' ) ) {
			return;
		}

		if ( ! current_user_can( 'update_plugins' ) ) {
			return;
		}

		$file_path    = 'sureforms/sureforms.php';
		$upgrade_link = add_query_arg(
			[
				'action'   => 'upgrade-plugin',
				'plugin'   => $file_path,
				'_wpnonce' => wp_create_nonce( 'upgrade-plugin_' . $file_path ),
			],
			self_admin_url( 'update.php' )
		);
		$incompatible = 'incompatible' === self::core_version_state( SRFM_VER );
		if ( self::is_core_notice_dismissed( $incompatible, get_current_user_id() ) ) {
			return;
		}
		$message = self::out_of_date_message( $incompatible );
		$actions = [
			[
				/* translators: %s: Recommended SureForms version number */
				'label'   => sprintf( __( 'Update SureForms to %s', 'sureforms-pro' ), SRFM_PRO_CORE_RQD_VER ),
				'url'     => $upgrade_link,
				'variant' => 'primary',
			],
		];
		if ( ! $incompatible ) {
			$actions[] = [
				'label'   => __( 'Dismiss', 'sureforms-pro' ),
				'url'     => self::core_notice_dismiss_url(),
				'variant' => 'secondary',
			];
		}

		\SRFM\Admin\Notice_Manager::register_notice(
			[
				'id'      => 'sureforms-pro-outdated-core',
				'variant' => $incompatible ? 'error' : 'warning',
				'message' => $message,
				'actions' => $actions,
				'pages'   => [ 'all' ],
			]
		);
	}

	/**
	 * Load Plugin Text Domain.
	 * This will load the translation textdomain depending on the file priorities.
	 *      1. Global Languages /wp-content/languages/sureforms-pro/ folder
	 *      2. Local directory /wp-content/plugins/sureforms-pro/languages/ folder
	 *
	 * @since 1.2.2
	 * @return void
	 */
	public function load_textdomain() {
		/**
		 * Filters the languages directory path to use for plugin.
		 *
		 * @param string $lang_dir The languages directory path.
		 */
		$lang_dir = apply_filters( 'srfm_languages_directory', SRFM_PRO_DIR . 'languages/' );

		// Traditional WordPress plugin locale filter.
		global $wp_version;

		$get_locale = get_locale();

		if ( $wp_version >= 4.7 ) {
			$get_locale = get_user_locale();
		}

		/**
		 * Language Locale for plugin
		 *
		 * Uses get_user_locale()` in WordPress 4.7 or greater,
		 * otherwise uses `get_locale()`.
		 */
		$locale = apply_filters( 'plugin_locale', $get_locale, 'sureforms-pro' );//phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- wordpress hook
		$mofile = sprintf( '%1$s-%2$s.mo', 'sureforms-pro', $locale );

		// Setup paths to current locale file.
		$mofile_global = WP_LANG_DIR . '/plugins/' . $mofile;
		$mofile_local  = $lang_dir . $mofile;

		if ( file_exists( $mofile_global ) ) {
			// Look in global /wp-content/languages/sureforms-pro/ folder.
			load_textdomain( 'sureforms-pro', $mofile_global );
		} elseif ( file_exists( $mofile_local ) ) {
			// Look in local /wp-content/plugins/sureforms-pro/languages/ folder.
			load_textdomain( 'sureforms-pro', $mofile_local );
		} else {
			// Load the default language files.
			load_plugin_textdomain( 'sureforms-pro', false, $lang_dir );
		}
	}
}

/**
 * Kicking this off by calling 'get_instance()' method
 */
Plugin_Loader::get_instance();
