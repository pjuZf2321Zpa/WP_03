<?php

/**
 * All registered action's handlers should be in app\Hooks\Handlers,
 * addAction is similar to add_action and addCustomAction is just a
 * wrapper over add_action which will add a prefix to the hook name
 * using the plugin slug to make it unique in all wordpress plugins,
 * ex: $app->addCustomAction('foo', ['FooHandler', 'handleFoo']) is
 * equivalent to add_action('slug-foo', ['FooHandler', 'handleFoo']).
 */

/**
 * @var $app FluentCartPro\App\Core\Application
 */


$app->addAction('admin_menu', 'AdminMenuHandler@add');

(new \FluentCartPro\App\Hooks\Handlers\AdvancedInventoryMenuHandler())->register();
(new \FluentCartPro\App\Hooks\Handlers\UpgradeHandler())->register();
(new \FluentCartPro\App\Hooks\Handlers\SubscriptionRenewalHandler())->register();
(new \FluentCartPro\App\Hooks\Handlers\EarlyInstallmentPaymentHandler())->register();
(new \FluentCartPro\App\Hooks\Handlers\FluentCartBlockEditorHandler())->register();

// Multi-currency: daily ECB exchange rates, opt-in from core's settings
(new \FluentCartPro\App\Modules\MultiCurrency\EcbRateProvider())->register();
(new \FluentCartPro\App\Modules\MultiCurrency\CurrencyDropdown())->register();
(new \FluentCartPro\App\Modules\MultiCurrency\CurrencySwitcherEditor())->register();

// MCP — provide the Fluent Toolkit auto-installer for FluentCart free's
// "Install Fluent Toolkit" button (site-wide fluent_toolkit/* hook contract).
(new \FluentCartPro\App\Modules\MCP\MCPInit())->init();

// Add editor frame URL to admin app data
add_filter('fluent_cart/admin_app_data', function ($data) {
    $data['fct_editor_frame'] = site_url('?fluent_cart_block_editor=1&_fct_nonce=' . wp_create_nonce('fct_block_editor'));
    return $data;
});

// E-Invoice (ZUGFeRD/Factur-X) XML generation for PDF receipts
add_filter('fluent_cart/pdf_einvoice_data', function ($data, $order, $meta) {
    $sellerService = \FluentCartPro\App\Services\PDF\SellerDetailsService::class;

    if (!$sellerService::isZugferdEnabled()) {
        return $data;
    }

    try {
        $xmlGenerator = new \FluentCartPro\App\Services\Invoice\ZugferdXmlGenerator();
        $xml = $xmlGenerator->generate($order);

        $hasWatermark = !empty(\FluentCart\Framework\Support\Arr::get($meta, '_fluent_cart_watermark_enabled', 0));
        $pdfaCompatible = !$hasWatermark;

        if (!$pdfaCompatible) {
            fluent_cart_add_log(
                'ZUGFeRD PDF/A-3 Incompatible',
                'Watermark enabled — ZUGFeRD XML not embedded in PDF.',
                'info'
            );
        }

        return [
            'enabled'         => true,
            'xml'             => $xml,
            'pdfa_compatible' => $pdfaCompatible,
        ];
    } catch (\InvalidArgumentException $e) {
        fluent_cart_add_log('ZUGFeRD XML Validation Error', $e->getMessage(), 'warning');
    } catch (\Exception $e) {
        fluent_cart_add_log('ZUGFeRD XML Generation Error', $e->getMessage(), 'error');
    }

    return $data;
}, 10, 3);

// Allow pro to save custom email templates (restore stripped template data)
add_filter('fluent_cart/prepare_email_template_data', function ($stripped, $full) {
    return $full;
}, 10, 2);

// Parse email block content with FluentBlockParser
add_filter('fluent_cart/parse_email_block_content', function ($parsed, $blockContent, $data) {
    return (new \FluentCartPro\App\Services\Email\FluentBlockParser($data))->parse($blockContent);
}, 10, 3);

// Render the block editor email template from pro
add_filter('fluent_cart/render_block_email_template', function ($html, $templateData) {
    $templatePath = FLUENTCART_PRO_PLUGIN_DIR . 'app/Views/emails/block_editor_template.php';
    if (!file_exists($templatePath)) {
        return $html;
    }

    extract($templateData);
    ob_start();
    include $templatePath;
    return ob_get_clean();
}, 10, 2);
