<?php

namespace MasterStudy\Lms\Pro\addons\assignments\Http\Controllers\Admin;

use MasterStudy\Lms\Http\WpResponseFactory;
use MasterStudy\Lms\Pro\addons\assignments\Repositories\AssignmentStudentAdminRepository;
use WP_REST_Response;

final class GetStudentAssignmentController {
	public function __invoke( int $student_assignment_id ): WP_REST_Response {
		$data = ( new AssignmentStudentAdminRepository() )->get_details( $student_assignment_id );

		if ( null === $data ) {
			return WpResponseFactory::not_found();
		}

		return WpResponseFactory::ok_with_data( $data );
	}
}
