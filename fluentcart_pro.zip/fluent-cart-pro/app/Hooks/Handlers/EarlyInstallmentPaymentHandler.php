<?php

namespace FluentCartPro\App\Hooks\Handlers;

use FluentCart\Api\Resource\CustomerResource;
use FluentCart\Api\StoreSettings;
use FluentCart\App\Helpers\CartHelper;
use FluentCart\App\Helpers\Status;
use FluentCart\App\Models\OrderTransaction;
use FluentCart\App\Models\Subscription;
use FluentCart\App\Modules\MultiCurrency\Services\CartCurrency;
use FluentCart\Framework\Support\Arr;

class EarlyInstallmentPaymentHandler
{
    public function register()
    {
        // url: /?fluent-cart=early-installment-payment&subscription_hash=xxx
        add_action('fluent_cart_action_early-installment-payment', [$this, 'handleEarlyPaymentRedirect'], 10, 1);
        add_action('fluent_cart/early_installment_order_created', [$this, 'handleEarlyInstallmentOrderCreated'], 10, 1);
        add_action('fluent_cart/early_installment_cart_completed', [$this, 'handleEarlyInstallmentCartCompleted'], 10, 1);

        add_filter('fluent_cart/checkout/validate_before_process', [$this, 'validateEarlyPaymentCheckoutOwnership'], 10, 2);
    }

    public function handleEarlyPaymentRedirect($data = [])
    {
        if (!is_user_logged_in()) {
            $this->showError(__('You are not logged in. Please log in to access this payment link.', 'fluent-cart-pro'));
        }

        $currentCustomer = CustomerResource::getCurrentCustomer();

        if (!$currentCustomer) {
            $this->showError(__('You don\'t have permission to make this payment.', 'fluent-cart-pro'));
        }

        $subscriptionUID = $data['subscription_hash'] ?? '';

        if (empty($subscriptionUID)) {
            $this->showError(__('Subscription UID is required.', 'fluent-cart-pro'));
        }

        $subscription = Subscription::query()->where('uuid', $subscriptionUID)->first();

        if (!$subscription) {
            $this->showError(__('Subscription not found.', 'fluent-cart-pro'));
        }

        if ($subscription->customer_id != $currentCustomer->id) {
            $this->showError(__('Cannot process this payment.', 'fluent-cart-pro'));
        }

        if (!in_array($subscription->status, [Status::SUBSCRIPTION_ACTIVE, Status::SUBSCRIPTION_TRIALING])) {
            $this->showError(__('This subscription is not active.', 'fluent-cart-pro'));
        }

        if ($subscription->bill_times <= 0) {
            $this->showError(__('Early payment is only available for installment subscriptions.', 'fluent-cart-pro'));
        }

        $remaining = $subscription->bill_times - $subscription->bill_count;

        if ($remaining <= 0) {
            $this->showError(__('All installments have already been paid.', 'fluent-cart-pro'));
        }

        if ($subscription->recurring_total <= 0) {
            $this->showError(__('The recurring amount for this subscription is not valid.', 'fluent-cart-pro'));
        }

        $parentOrder = $subscription->order;

        if (!$parentOrder || !in_array($parentOrder->payment_status, Status::getOrderPaymentSuccessStatuses())) {
            $this->showError(__('The parent order of this subscription is not in a valid state.', 'fluent-cart-pro'));
        }

        $perInstallmentAmount = $subscription->recurring_total;
        $totalAmount = $perInstallmentAmount * $remaining;

        $variation = $subscription->variation;
        $product = $subscription->product;

        $itemTitle = $product ? $product->post_title : $subscription->item_name;
        $variationTitle = ($variation && $product) ? $variation->variation_title : '';

        // Build a one-time payment cart item for all remaining installments
        $newItem = [
            'id'               => $variation ? $variation->id : 0,
            'post_id'          => $subscription->product_id,
            'object_id'        => $subscription->variation_id,
            'item_price'       => $totalAmount,
            'payment_type'     => 'onetime',
            'fulfillment_type' => 'digital',
            'post_title'       => $itemTitle,
            'variation_title'  => $variationTitle,
            'variation_type'   => $variation ? ($variation->product_detail ? $variation->product_detail->variation_type : 'single') : 'single',
            'other_info'       => [
                'payment_type' => 'onetime',
            ],
        ];

        $instantCart = CartHelper::generateCartFromCustomVariation($newItem);
        $instantCart->cart_group = 'instant';
        $instantCart->first_name = $subscription->customer->first_name;
        $instantCart->last_name = $subscription->customer->last_name;
        $instantCart->email = $subscription->customer->email;
        $instantCart->customer_id = $subscription->customer->id;
        $instantCart->user_id = $subscription->customer->user_id;
        $instantCart->cart_hash = md5('early_pay_' . wp_generate_uuid4() . time());
        $instantCart->checkout_data = [
            'is_locked'              => 'yes',
            'disable_coupons'        => 'yes',
            'early_installment_data' => [
                'subscription_hash'          => $subscription->uuid,
                'subscription_id'            => $subscription->id,
                'installment_count'          => $remaining,
                'per_installment_amount'     => $perInstallmentAmount,
                'old_vendor_subscription_id' => $subscription->vendor_subscription_id,
                'old_payment_method'         => $subscription->current_payment_method,
                'parent_order_id'            => $parentOrder->id,
                'customer_id'                => $subscription->customer_id,
            ]
        ];

        $instantCart->checkout_data = array_merge(
            $instantCart->checkout_data,
            $instantCart->addDraftCreatedActions([
                'fluent_cart/early_installment_order_created',
            ]),
            $instantCart->addSuccessActions([
                'fluent_cart/early_installment_cart_completed',
            ]),
            $instantCart->addCartNotices([
                [
                    'id'      => 'early_payment_notice',
                    'type'    => 'info',
                    'content' => sprintf(
                        __('You are paying the remaining %1$d installment(s) to complete: %2$s.', 'fluent-cart-pro'),
                        $remaining,
                        $itemTitle
                    ),
                ]
            ])
        );

        if (method_exists(CartCurrency::class, 'holdToSubscription') && !CartCurrency::holdToSubscription($instantCart, $subscription)) {
            $this->refuseUnpricedSubscription($subscription);
        }

        $instantCart->save();
        $cartHash = $instantCart->cart_hash;

        $checkoutUrl = add_query_arg(
            [
                'fct_cart_hash' => $cartHash,
            ],
            (new StoreSettings())->getCheckoutPage()
        );

        wp_redirect($checkoutUrl);
        exit();
    }

    public function handleEarlyInstallmentOrderCreated($data)
    {
        $cartModel = Arr::get($data, 'cart', null);
        $order = Arr::get($data, 'order', null);

        if (!$cartModel || !$order) {
            return;
        }

        $earlyPayData = Arr::get($cartModel->checkout_data, 'early_installment_data', []);
        $subscriptionHash = Arr::get($earlyPayData, 'subscription_hash', '');

        if (empty($subscriptionHash)) {
            return;
        }

        $subscription = Subscription::query()->where('uuid', $subscriptionHash)->first();

        if (!$subscription) {
            return;
        }

        // Do NOT set order->type to 'renewal' here.
        // PaymentInstance checks order->type to decide between subscription vs single payment.
        // Setting 'renewal' causes it to load the original subscription and route through
        // Stripe's handleSubscription() (Setup Intent), but our checkout uses 'payment' mode.
        // We'll set the type to 'renewal' after payment succeeds in handleEarlyInstallmentCartCompleted.

        $config = $order->config;
        $config['early_installment_data'] = [
            'subscription_id'            => $subscription->id,
            'subscription_parent_order'  => $subscription->parent_order_id,
            'installment_count'          => Arr::get($earlyPayData, 'installment_count', 1),
            'old_vendor_subscription_id' => Arr::get($earlyPayData, 'old_vendor_subscription_id', ''),
            'old_payment_method'         => Arr::get($earlyPayData, 'old_payment_method', ''),
        ];
        $order->config = $config;
        $order->save();

        // Remove any auto-created subscription from the checkout (same pattern as reactivation)
        Subscription::query()->where('parent_order_id', $order->id)->delete();

        $order->addLog(
            'Early installment payment order created.',
            sprintf('Customer initiated early payment for %d remaining installment(s).', Arr::get($earlyPayData, 'installment_count', 1)),
            'info'
        );
    }

    public function handleEarlyInstallmentCartCompleted($data)
    {
        $cart = Arr::get($data, 'cart', null);
        $order = Arr::get($data, 'order', null);

        if (!$cart || !$order) {
            return;
        }

        $earlyPayData = Arr::get($order->config, 'early_installment_data', []);
        $subscriptionId = Arr::get($earlyPayData, 'subscription_id');
        $installmentCount = (int)Arr::get($earlyPayData, 'installment_count', 1);
        $subscriptionParentOrder = Arr::get($earlyPayData, 'subscription_parent_order');

        if (!$subscriptionId || $installmentCount < 1) {
            return;
        }

        $subscription = Subscription::query()->find($subscriptionId);

        if (!$subscription) {
            return;
        }

        // Now that payment succeeded, set order type to renewal and link to parent
        $order->parent_id = $subscriptionParentOrder ?: $subscription->parent_order_id;
        $order->type = Status::ORDER_TYPE_RENEWAL;
        $order->save();

        // Link the transaction to the subscription
        OrderTransaction::query()->where('order_id', $order->id)
            ->update([
                'order_type'      => Status::ORDER_TYPE_RENEWAL,
                'subscription_id' => $subscription->id,
            ]);

        // Re-validate subscription is still eligible
        if (!in_array($subscription->status, [Status::SUBSCRIPTION_ACTIVE, Status::SUBSCRIPTION_TRIALING])) {
            $order->addLog(
                'Early installment payment skipped.',
                'Subscription is no longer active. Status: ' . $subscription->status,
                'error'
            );
            return;
        }

        $remaining = $subscription->bill_times - $subscription->bill_count;
        $installmentCount = min($installmentCount, $remaining);

        if ($installmentCount <= 0) {
            return;
        }

         // Record early payment history in subscription meta
        $history = $subscription->getMeta('early_payment_history', []);
        $history[] = [
            'count'            => $installmentCount,
            'order_id'         => $order->id,
            'paid_at'          => gmdate('Y-m-d H:i:s'),
            'bill_count_after' => $subscription->bill_count,
        ];
        $subscription->updateMeta('early_payment_history', $history);

        $order->addLog(
            'Early installment payment completed.',
            sprintf('Successfully recorded %d early installment payment(s). Bill count: %d/%d.', $installmentCount, $subscription->bill_count, $subscription->bill_times),
            'info'
        );

        do_action('fluent_cart/subscription/early_payment_completed', [
            'subscription'      => $subscription,
            'order'             => $order,
            'installment_count' => $installmentCount,
        ]);

        $subscription->reSyncFromRemote();
    }

    public function validateEarlyPaymentCheckoutOwnership($validation, $data)
    {
        $cart = CartHelper::getCart();

        if (!$cart) {
            return $validation;
        }

        $earlyPayData = Arr::get($cart->checkout_data, 'early_installment_data');

        if (empty($earlyPayData)) {
            return $validation;
        }

        $cartCustomerId = Arr::get($earlyPayData, 'customer_id');

        if (!$cartCustomerId) {
            return $validation;
        }

        if (!is_user_logged_in()) {
            return new \WP_Error(
                'early_payment_auth_required',
                __('You must be logged in to complete this payment.', 'fluent-cart-pro')
            );
        }

        $currentCustomer = CustomerResource::getCurrentCustomer();

        if (!$currentCustomer) {
            return new \WP_Error(
                'early_payment_auth_failed',
                __('Unable to verify your identity. Please log in again.', 'fluent-cart-pro')
            );
        }

        if ($cartCustomerId != $currentCustomer->id) {
            return new \WP_Error(
                'early_payment_unauthorized',
                __('This payment belongs to a different customer. You cannot complete this checkout.', 'fluent-cart-pro')
            );
        }

        return $validation;
    }

    private function showError($message)
    {
        die($message);
    }

    /**
     * Core could not quote the subscription's currency (no rate today and no
     * trusted snapshot), so no cart is built — never one priced in the base
     * currency for a subscription billed in another. Mirrors
     * UpgradeHandler::refuseUnpricedUpgrade().
     */
    private function refuseUnpricedSubscription($subscription)
    {
        wp_die(
            esc_html(sprintf(
                /* translators: %1$s: currency code, e.g. GBP */
                __('This payment is not available because no exchange rate is set for %1$s. Please contact the store.', 'fluent-cart-pro'),
                strtoupper((string) $subscription->currency)
            )),
            esc_html__('Payment not available', 'fluent-cart-pro'),
            ['response' => 409, 'back_link' => true]
        );
    }
}
