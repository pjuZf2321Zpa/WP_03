<?php

namespace Breakdance\BloatEliminator;

use function Breakdance\Util\is_post_request;

add_action('breakdance_register_admin_settings_page_register_tabs', 'Breakdance\BloatEliminator\register');

function register()
{
    \Breakdance\Admin\SettingsPage\addTab(
        esc_html__('Performance', 'breakdance'),
        'bloat_eliminator',
        'Breakdance\BloatEliminator\tab',
        1050
    );
}

function saveBloatEliminatorSettings()
{
    $options = [];

    foreach (array_keys(features()) as $feature) {
        if (array_key_exists($feature, $_POST)) {
            $options[] = $feature;
        }
    }

    setEnabledFeatures($options);
}

function tab()
{
    $nonce_action = 'breakdance_admin_bloat-eliminator_tab';
    if (is_post_request() && check_admin_referer($nonce_action)) {
        saveBloatEliminatorSettings();
    }

    $bloatOptions = enabledFeatures();

    require_once __DIR__ . '/bloat-eliminator-template.php';
}
