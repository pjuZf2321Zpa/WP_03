<?php

namespace FluentCartPro\App\Http\Policies;

use FluentCart\App\Http\Policies\Policy;
use FluentCart\Framework\Http\Request\Request;

/**
 * Gates the accounting export on the route's meta permission
 * (`reports/export`); core's ReportPolicy only checks `reports/view`.
 */
class AccountingExportPolicy extends Policy
{
    public function verifyRequest(Request $request)
    {
        return $this->hasRoutePermissions();
    }
}
