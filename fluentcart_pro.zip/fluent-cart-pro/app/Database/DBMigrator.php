<?php

namespace FluentCartPro\App\Database;

require_once(ABSPATH . 'wp-admin/includes/upgrade.php');

abstract class DBMigrator
{
    public function run($networkWide = false)
    {
        $this->migrate();
    }

    abstract public function migrate();

    abstract public function dropTable();
}
