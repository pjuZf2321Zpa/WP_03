<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Core\Util\Hooks;
use BitApps\IntegrationsPro\Actions\WhatsApp\WhatsAppHelperPro;
use BitApps\IntegrationsPro\Config;

// Deprecated since v2.7.8 - use bit_integrations_whatsapp_* hooks instead
if (class_exists('BitApps\\IntegrationsPro\\Config') && version_compare(BitApps\IntegrationsPro\Config::VERSION, '2.7.8', '<')) {
    Hooks::filter('btcbi_whatsapp_send_text_messages', [WhatsAppHelperPro::class, 'sendTextMessages'], 10, 5);
    Hooks::filter('btcbi_whatsapp_send_media_messages', [WhatsAppHelperPro::class, 'sendMediaMessages'], 10, 5);
    Hooks::filter('btcbi_whatsapp_send_contact_messages', [WhatsAppHelperPro::class, 'sendContactMessages'], 10, 5);
}

// New hooks since v2.7.8
Hooks::filter(Config::withFreePrefix('whatsapp_send_text_messages'), [WhatsAppHelperPro::class, 'sendTextMessages'], 10, 5);
Hooks::filter(Config::withFreePrefix('whatsapp_send_media_messages'), [WhatsAppHelperPro::class, 'sendMediaMessages'], 10, 5);
Hooks::filter(Config::withFreePrefix('whatsapp_send_contact_messages'), [WhatsAppHelperPro::class, 'sendContactMessages'], 10, 5);
Hooks::filter(Config::withFreePrefix('whatsapp_template_components'), [WhatsAppHelperPro::class, 'buildTemplateComponents'], 10, 2);
