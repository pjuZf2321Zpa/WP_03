<?php

namespace FluentCartPro\App\Hooks\Handlers\BlockEditors\OrderBumpBlocks;

/**
 * One block for each text and picture of a card: the offer title, the product title, the three
 * price parts and so on. In the editor each one shows sample data in the card's own layout; on
 * the shop it prints its placeholder, which the card renderer fills for each offer.
 */
class OrderBumpElementBlockEditor extends OrderBumpBlockEditor
{
    protected static string $editorName = 'order-bump-elements';

    /**
     * @return array<string,array> block name => placeholder, tag, title, description, sample
     */
    public static function elements(): array
    {
        return [
            'order-bump-image'           => ['placeholder' => 'image', 'tag' => 'div', 'title' => __('Order Bump Image', 'fluent-cart-pro'), 'description' => __('The picture of the offer.', 'fluent-cart-pro'), 'sample' => ''],
            'order-bump-title'           => ['placeholder' => 'title', 'tag' => 'p', 'title' => __('Order Bump Title', 'fluent-cart-pro'), 'description' => __('The title of the offer.', 'fluent-cart-pro'), 'sample' => 'Zipper Hoodie deal'],
            'order-bump-product-title'   => ['placeholder' => 'product_title', 'tag' => 'p', 'title' => __('Order Bump Product Title', 'fluent-cart-pro'), 'description' => __('The name of the product on offer.', 'fluent-cart-pro'), 'sample' => 'Zipper Hoodie'],
            'order-bump-variation-title' => ['placeholder' => 'variation_title', 'tag' => 'p', 'title' => __('Order Bump Variation', 'fluent-cart-pro'), 'description' => __('The variation of the product, when it has one.', 'fluent-cart-pro'), 'sample' => 'White'],
            'order-bump-original-price'  => ['placeholder' => 'original_price', 'tag' => 'p', 'title' => __('Order Bump Original Price', 'fluent-cart-pro'), 'description' => __('The price before the discount. It is empty when there is no discount.', 'fluent-cart-pro'), 'sample' => '$12.50'],
            'order-bump-price'           => ['placeholder' => 'price', 'tag' => 'p', 'title' => __('Order Bump Price', 'fluent-cart-pro'), 'description' => __('The price the shopper pays.', 'fluent-cart-pro'), 'sample' => '$10.00'],
            'order-bump-savings'         => ['placeholder' => 'savings', 'tag' => 'p', 'title' => __('Order Bump Savings', 'fluent-cart-pro'), 'description' => __('The amount saved. It is empty when there is no discount.', 'fluent-cart-pro'), 'sample' => 'Save $2.50'],
            'order-bump-description'     => ['placeholder' => 'description', 'tag' => 'div', 'title' => __('Order Bump Description', 'fluent-cart-pro'), 'description' => __('The description of the offer.', 'fluent-cart-pro'), 'sample' => 'A short description of the offer.'],
        ];
    }

    public static function blockNames(): array
    {
        return array_map(function ($name) {
            return 'fluent-cart/' . $name;
        }, array_keys(static::elements()));
    }

    public function registerBlockType(): void
    {
        foreach (static::elements() as $name => $element) {
            register_block_type($this->slugPrefix . '/' . $name, [
                'api_version'     => 3,
                'category'        => 'fluent-cart',
                'supports'        => $this->supports(),
                'render_callback' => function () use ($element) {
                    return $this->renderElement($element);
                },
            ]);
        }
    }

    public function getScripts(): array
    {
        return [
            [
                'source'       => 'admin/BlockEditor/OrderBumpBlocks/OrderBumpElementBlockEditor.jsx',
                'dependencies' => ['wp-blocks', 'wp-components', 'wp-block-editor']
            ]
        ];
    }

    public function localizeData(): array
    {
        $elements = [];
        foreach (static::elements() as $name => $element) {
            $elements[] = [
                'name'        => $name,
                'title'       => $element['title'],
                'description' => $element['description'],
                'tag'         => $element['tag'],
                'sample'      => $element['sample'],
            ];
        }

        return [
            $this->getLocalizationKey() => [
                'slug'     => $this->slugPrefix,
                'elements' => $elements,
            ],
            'fluent_cart_block_translation' => \FluentCart\App\Services\Translations\TransStrings::blockStrings(),
        ];
    }

    public function render(array $attrs, $block = null, $content = ''): string
    {
        return '';
    }

    // The wrapper attributes carry the block's class, colour, typography and spacing settings.
    private function renderElement(array $element): string
    {
        return sprintf(
            '<%1$s %2$s>{{bump.%3$s}}</%1$s>',
            $element['tag'],
            get_block_wrapper_attributes(),
            $element['placeholder']
        );
    }
}
