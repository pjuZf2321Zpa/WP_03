<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Actions\Registration\RegistrationHelperPro;
use BitApps\IntegrationsPro\Config;
use BitApps\IntegrationsPro\Core\Util\Hooks;

Hooks::filter(Config::withFreePrefix('deleteExistingUser'), [RegistrationHelperPro::class, 'deleteUser'], 10, 2);

Hooks::filter(Config::withFreePrefix('updateUserMetadata'), [RegistrationHelperPro::class, 'updateUserMetadata'], 10, 2);

Hooks::filter(Config::withFreePrefix('createRole'), [RegistrationHelperPro::class, 'createRole'], 10, 2);
Hooks::filter(Config::withFreePrefix('deleteRole'), [RegistrationHelperPro::class, 'deleteRole'], 10, 2);
Hooks::filter(Config::withFreePrefix('addUserRoles'), [RegistrationHelperPro::class, 'addUserRoles'], 10, 2);
Hooks::filter(Config::withFreePrefix('removeUserRole'), [RegistrationHelperPro::class, 'removeUserRole'], 10, 2);
Hooks::filter(Config::withFreePrefix('updateUserRole'), [RegistrationHelperPro::class, 'updateUserRole'], 10, 2);

Hooks::filter(Config::withFreePrefix('addRoleCapabilities'), [RegistrationHelperPro::class, 'addRoleCapabilities'], 10, 2);
Hooks::filter(Config::withFreePrefix('removeRoleCapabilities'), [RegistrationHelperPro::class, 'removeRoleCapabilities'], 10, 2);
Hooks::filter(Config::withFreePrefix('addUserCapabilities'), [RegistrationHelperPro::class, 'addUserCapabilities'], 10, 2);
Hooks::filter(Config::withFreePrefix('removeUserCapabilities'), [RegistrationHelperPro::class, 'removeUserCapabilities'], 10, 2);
