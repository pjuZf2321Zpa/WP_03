<?php

namespace FluentCartPro\App\Modules\Reports\Http\Controllers;

use FluentCart\App\Http\Controllers\Controller;
use FluentCart\App\Services\Report\ReportHelper;
use FluentCart\Framework\Http\Request\Request;
use FluentCartPro\App\Modules\Reports\Services\PaymentInsightsService;

class PaymentInsightsController extends Controller
{
    public function disputes(Request $request): array
    {
        return PaymentInsightsService::make()->getDisputes($this->processed($request));
    }

    public function methods(Request $request): array
    {
        return PaymentInsightsService::make()->getMethods($this->processed($request));
    }

    // The same filters as core's payment-methods route
    private function processed(Request $request): array
    {
        return ReportHelper::processParams((array) $request->get('params', []), ['paymentStatus', 'orderTypes'], true);
    }
}
