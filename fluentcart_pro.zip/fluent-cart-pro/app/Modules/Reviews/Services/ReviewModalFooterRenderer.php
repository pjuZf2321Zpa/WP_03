<?php

namespace FluentCartPro\App\Modules\Reviews\Services;

use FluentCart\App\Models\ProductReview;

/**
 * Reviewer reply form inside the thread modal.
 *
 * Free renders the modal server-side and exposes
 * fluent_cart/review/modal_footer for extensions; this renders the form
 * there so the markup arrives with the modal instead of being appended by
 * JS afterwards. The storefront script still owns submit behaviour — it
 * binds to this markup when the modal-opened event fires.
 */
class ReviewModalFooterRenderer
{
    const MAX_LENGTH = 2000;

    public static function register()
    {
        add_action('fluent_cart/review/modal_footer', [static::class, 'render']);
    }

    /**
     * @param array $payload ['review' => ProductReview] from
     *                       fluent_cart/review/modal_footer
     */
    public static function render($payload)
    {
        $review = is_array($payload) ? ($payload['review'] ?? null) : $payload;

        if (!$review instanceof ProductReview) {
            return;
        }

        if (!ReviewService::isThreadedRepliesEnabled()) {
            return;
        }

        // Only the reviewer may reply to their own review, and only once it
        // is published — the same rule the reply endpoint enforces, applied
        // here so the form is not rendered for anyone who cannot use it.
        $userId = get_current_user_id();
        if (!$userId || (int) $review->user_id !== $userId) {
            return;
        }

        $placeholder = __('Write a reply...', 'fluent-cart-pro');
        ?>
        <div class="fct-review-modal-footer">
            <div class="fct-review-reply-form" data-review-reply-form
                 data-review-id="<?php echo esc_attr($review->id); ?>">
                <div class="fct-review-reply-box">
                    <textarea
                        class="fct-review-reply-input"
                        data-review-reply-input
                        rows="3"
                        placeholder="<?php echo esc_attr($placeholder); ?>"
                        aria-label="<?php echo esc_attr($placeholder); ?>"
                        maxlength="<?php echo esc_attr(static::MAX_LENGTH); ?>"
                    ></textarea>
                    <span class="fct-review-reply-counter" data-reply-counter aria-hidden="true">0/<?php echo esc_html(static::MAX_LENGTH); ?></span>
                </div>
                <button type="button" class="fct-review-reply-submit" data-review-reply-submit>
                    <?php esc_html_e('Send a Reply', 'fluent-cart-pro'); ?>
                </button>
            </div>
        </div>
        <?php
    }
}
