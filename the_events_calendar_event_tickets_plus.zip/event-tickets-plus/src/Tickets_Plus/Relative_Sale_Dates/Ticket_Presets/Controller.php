<?php
/**
 * The controller of the relative sales dates of ticket presets.
 *
 * @since 6.12.0
 *
 * @package TEC\Tickets_Plus\Relative_Sale_Dates\Ticket_Presets
 */

namespace TEC\Tickets_Plus\Relative_Sale_Dates\Ticket_Presets;

use TEC\Common\Contracts\Provider\Controller as Controller_Contract;

/**
 * Gives ticket presets Event Tickets' relative sales window, through the hooks of the Ticket Presets feature.
 *
 * @since 6.12.0
 *
 * @package TEC\Tickets_Plus\Relative_Sale_Dates\Ticket_Presets
 */
final class Controller extends Controller_Contract {
	/**
	 * Unregisters the controller.
	 *
	 * @since 6.12.0
	 *
	 * @return void
	 */
	public function unregister(): void {
		remove_filter( 'tec_tickets_plus_ticket_presets_save_data', $this->container->callback( Sales_Window::class, 'filter_save_data' ) );
		remove_filter( 'tec_tickets_plus_ticket_presets_editor_data', $this->container->callback( Sales_Window::class, 'filter_editor_data' ) );
		remove_filter( Preset_Form::SALE_PERIOD_PRE_HTML_HOOK, $this->container->callback( Preset_Form::class, 'render_sale_period' ) );

		$this->container->get( Assets::class )->unregister();
	}

	/**
	 * Registers the controller.
	 *
	 * @since 6.12.0
	 *
	 * @return void
	 */
	protected function do_register(): void {
		$this->container->singleton( Sales_Window::class );
		$this->container->singleton( Preset_Form::class );

		add_filter( 'tec_tickets_plus_ticket_presets_save_data', $this->container->callback( Sales_Window::class, 'filter_save_data' ), 10, 2 );
		add_filter( 'tec_tickets_plus_ticket_presets_editor_data', $this->container->callback( Sales_Window::class, 'filter_editor_data' ) );
		add_filter( Preset_Form::SALE_PERIOD_PRE_HTML_HOOK, $this->container->callback( Preset_Form::class, 'render_sale_period' ), 10, 5 );

		$this->container->register( Assets::class );
	}
}
