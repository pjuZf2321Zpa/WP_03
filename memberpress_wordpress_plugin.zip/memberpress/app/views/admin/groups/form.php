<?php if (!defined('ABSPATH')) {
    die('You are not allowed to call this page directly.');
} ?>

<div id="mepr-groups-form">
  <table class="form-table">
    <tbody>
      <tr valign="top">
        <th scope="row">
          <label for="<?php echo esc_attr(MeprGroup::$is_upgrade_path_str); ?>">
            <?php esc_html_e('Upgrade Path', 'memberpress'); ?>
          </label>
          <?php
            // Keep the translation calls in this file on ONE line with phpcs:ignore after
            // the closing paren. The Lite text-domain converter skips any call carrying a
            // directive inside its argument list, silently shipping the wrong domain
            // (memberpress-lite#63). Re-wrap only once memberpress-lite#64 lands.
            MeprAppHelper::info_tooltip(
                'mepr-group-page-upgrade-path',
                __('This group is a membership product upgrade path', 'memberpress'),
                __('Enabling this will mean that users can only be subscribed to one of these membership products at a time. If un-checked, users may be subscribed to each of these membership products simultaneously.', 'memberpress') // phpcs:ignore Generic.Files.LineLength.TooLong
            );
            ?>
        </th>
        <td>
          <input type="checkbox"
            id="<?php echo esc_attr(MeprGroup::$is_upgrade_path_str); ?>"
            name="<?php echo esc_attr(MeprGroup::$is_upgrade_path_str); ?>"
            class="mepr-toggle-checkbox"
            data-box="mepr_is_upgrade_path_box"
            <?php checked($group->is_upgrade_path); ?>
          />
        </td>
      </tr>
    </tbody>
  </table>

  <div id="mepr_is_upgrade_path_box" class="mepr-sub-box mepr_is_upgrade_path_box">
    <div class="mepr-arrow mepr-gray mepr-up mepr-sub-box-arrow"> </div>
    <table class="form-table">
      <tbody>
        <tr valign="top">
          <th scope="row">
            <label for="<?php echo esc_attr(MeprGroup::$upgrade_path_reset_period_str); ?>">
              <?php esc_html_e('Reset billing period', 'memberpress'); ?>
            </label>
            <?php
              MeprAppHelper::info_tooltip(
                  'mepr-group-upgrade-path-reset-period',
                  __('Reset billing period when upgrading', 'memberpress'),
                  __(
                      'If this is checked, the billing period will be reset when a recurring membership product is upgraded.',
                      'memberpress'
                  )
              );
                ?>
          </th>
          <td>
            <input type="checkbox"
              id="<?php echo esc_attr(MeprGroup::$upgrade_path_reset_period_str); ?>"
              name="<?php echo esc_attr(MeprGroup::$upgrade_path_reset_period_str); ?>"
              <?php checked($group->upgrade_path_reset_period); ?>
            />
          </td>
        </tr>
      </tbody>
    </table>
  </div>

  <h4><strong><?php esc_html_e('Downgrade Path', 'memberpress'); ?></strong>
  <?php
    MeprAppHelper::info_tooltip(
        'mepr-group-page-downgrade-path',
        __('Fallback group when membership product expires or is cancelled', 'memberpress'),
        __('Select which membership product in the group to fall back to when the paid subscription expires or is cancelled. If you are unsure, leave the default.', 'memberpress') // phpcs:ignore Generic.Files.LineLength.TooLong
    );
    ?>
  <?php MeprGroupsHelper::get_product_fallback_dropdown($group); ?>
  <h4><strong><?php esc_html_e('Membership Products:', 'memberpress'); ?></strong>
  <?php
    MeprAppHelper::info_tooltip(
        'mepr-group-products-list',
        __('Membership Products', 'memberpress'),
        sprintf(
          // Translators: %1$s: line break.
            __('Here you can add/remove membership products from this group pricing page.%1$s%1$sThe order of the membership products is important here. Order the membership products so that the lowest tier membership product is at the top of the list and the highest tier membership product is at the bottom, with the other membership products in order in between.', 'memberpress'), // phpcs:ignore Generic.Files.LineLength.TooLong
            '<br />'
        )
    );
    ?>
  </h4>

  <div class="notice-warning is-dismissible"
    id="readylaunch-group-limit"
    style="padding: 10px;">
    <?php
    esc_html_e('ReadyLaunch is enabled for Groups in your MemberPress > Settings > ReadyLaunch tab. ReadyLaunch can currently only show 5 Membership Products per Group.', 'memberpress'); // phpcs:ignore Generic.Files.LineLength.TooLong
    ?>
  </div>


  <ol id="sortable-products" class="mepr-sortable">
    <?php MeprGroupsHelper::get_existing_products_list($group); ?>
  </ol>
  <a href="" id="add-new-product"
    title="<?php esc_attr_e('Add Membership Product', 'memberpress'); ?>">
    <i class="mp-icon mp-icon-plus-circled mp-24"></i>
  </a>
  <div id="hidden-line-item">
    <li class="product-item">
      <?php MeprGroupsHelper::get_products_dropdown(); ?>
      <span class="remove-span">
        <a href="" class="remove-product-item"
          title="<?php esc_attr_e('Remove Membership Product', 'memberpress'); ?>">
          <i class="mp-icon mp-icon-cancel-circled mp-16"></i>
        </a>
      </span>
    </li>
  </div>

  <?php MeprHooks::do_action('mepr_admin_group_form', $group, $mepr_options); ?>

  <br/><br/>
  <input type="checkbox"
    id="<?php echo esc_attr(MeprGroup::$disable_change_plan_popup_str); ?>"
    name="<?php echo esc_attr(MeprGroup::$disable_change_plan_popup_str); ?>"
    <?php checked($group->disable_change_plan_popup); ?>
  />
  <label for="<?php echo esc_attr(MeprGroup::$disable_change_plan_popup_str); ?>">
    <?php esc_html_e('Disable Change Plan Pop-Up', 'memberpress'); ?>
  </label>
  <?php
    MeprAppHelper::info_tooltip(
        'mepr-disable-change-plan-pop-up',
        __('Disable Change Plan Pop-Up', 'memberpress'),
        __('This will take the user to the Group pricing page when they click on Change Plan instead of showing them the quick selection pop-up.', 'memberpress') // phpcs:ignore Generic.Files.LineLength.TooLong
    );
    ?>
  <br/><br/>
  <input type="checkbox"
    id="<?php echo esc_attr(MeprGroup::$pricing_page_disabled_str); ?>"
    name="<?php echo esc_attr(MeprGroup::$pricing_page_disabled_str); ?>"
    <?php checked($group->pricing_page_disabled); ?>
  />
  <label for="<?php echo esc_attr(MeprGroup::$pricing_page_disabled_str); ?>">
    <?php esc_html_e('Disable Pricing Page', 'memberpress'); ?>
  </label>
  <?php
    MeprAppHelper::info_tooltip(
        'mepr-group-disable-pricing-page',
        __('Disable Pricing Page', 'memberpress'),
        __('This will disable the pricing page from being accessed on the front end of your site. It will return a 404 (not found) page if a user attempts to access it.<br/><br/>You can optionally provide an alternate URL to take the member to if they try to visit this page.', 'memberpress') // phpcs:ignore Generic.Files.LineLength.TooLong
    );
    ?>
  <br/>
  <div class="<?php
    echo isset($mepr_options->design_enable_pricing_template)
      && $mepr_options->design_enable_pricing_template
      ? 'mepr_hidden' : '';
    ?>">
    <div id="mepr_hidden_pricing_page_theme">
      <?php MeprView::render('/admin/groups/template_selector', get_defined_vars()); ?>
        <!-- Legacy theme options (inside #mepr-legacy-themes-section opened by template_selector) -->
        <label for="<?php echo esc_attr(MeprGroup::$group_theme_str); ?>">
          <?php esc_html_e('Pricing Page Theme:', 'memberpress'); ?>
        </label>
        <?php MeprGroupsHelper::theme_dropdown($group->group_theme); ?>
        <br/><br/>

        <label>
          <?php esc_html_e('Custom Button CSS classes (optional):', 'memberpress'); ?>
        </label><br/>
        <input type="text"
          class="mepr-group-button-css"
          name="<?php echo esc_attr(MeprGroup::$page_button_class_str); ?>"
          id="<?php echo esc_attr(MeprGroup::$page_button_class_str); ?>"
          value="<?php echo esc_attr($group->page_button_class); ?>"
        />
        <br/><br/>

        <label>
          <?php esc_html_e('Custom Highlighted Button CSS classes (optional):', 'memberpress'); ?>
        </label><br/>
        <input type="text"
          class="mepr-group-button-css"
          name="<?php echo esc_attr(MeprGroup::$page_button_highlighted_class_str); ?>"
          id="<?php echo esc_attr(MeprGroup::$page_button_highlighted_class_str); ?>"
          value="<?php echo esc_attr($group->page_button_highlighted_class); ?>"
        />
        <br/><br/>

        <label>
          <?php esc_html_e('Custom Disabled Button CSS classes (optional):', 'memberpress'); ?>
        </label><br/>
        <input type="text"
          class="mepr-group-button-css"
          name="<?php echo esc_attr(MeprGroup::$page_button_disabled_class_str); ?>"
          id="<?php echo esc_attr(MeprGroup::$page_button_disabled_class_str); ?>"
          value="<?php echo esc_attr($group->page_button_disabled_class); ?>"
        />
      </div><!-- /#mepr-legacy-themes-section -->
    </div><!-- /#mepr-template-section -->
    </div><!-- /#mepr_hidden_pricing_page_theme -->
  </div>

  <div id="mepr_hidden_alternate_group_url">
    <label><?php esc_html_e('Alternate Group URL:', 'memberpress'); ?></label><br/>
    <input type="text"
      class="mepr-group-button-css"
      name="<?php echo esc_attr(MeprGroup::$alternate_group_url_str); ?>"
      id="<?php echo esc_attr(MeprGroup::$alternate_group_url_str); ?>"
      value="<?php echo esc_attr($group->alternate_group_url); ?>"
    />
  </div>
  <br/>
  <div id="mepr-manually-place-group-boxes">
    <a href="#"
      data-target="#mepr-group-price-box-shortcodes"
      class="mepr-slide-toggle">
      <?php esc_html_e('Group Price Boxes Shortcodes', 'memberpress'); ?>
    </a>
    <?php
      MeprAppHelper::info_tooltip(
          'mepr-group-manual-place-pricing-boxes',
          __('Manually place group price boxes', 'memberpress'),
          __('By default MemberPress will append the pricing boxes to the end of the Group page.<br/><br/>If you\'d like to show them in a different place on the group page or some other page on this site just copy and paste a shortcode where you\'d like the price boxes for this group to appear.', 'memberpress') // phpcs:ignore Generic.Files.LineLength.TooLong
      );
        ?>
    <div id="mepr-group-price-box-shortcodes" class="mepr-radius-border">
      <p class="description">
        <?php esc_html_e('Shortcode to be used on this group page.', 'memberpress'); ?>
      </p>
      [mepr_group_price_boxes]<br/><br/>
      <p class="description">
        <?php // phpcs:ignore Generic.Files.LineLength.TooLong ?>
        <?php esc_html_e('Shortcode which can be used on any other WordPress page, post or custom post type.', 'memberpress'); ?>
      </p>
      [mepr_group_price_boxes group_id="<?php echo esc_html($group->ID); ?>"]
    </div>
  </div>

  <!-- The NONCE below prevents post meta from being blanked on move to trash -->
  <input type="hidden"
    name="<?php echo esc_attr(MeprGroup::$nonce_str); ?>"
    value="<?php echo esc_attr(wp_create_nonce(MeprGroup::$nonce_str . wp_salt())); ?>"
  />
</div>
