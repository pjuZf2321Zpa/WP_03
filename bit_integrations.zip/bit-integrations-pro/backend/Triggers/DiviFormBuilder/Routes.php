<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Core\Util\Route;
use BitApps\IntegrationsPro\Triggers\DiviFormBuilder\DiviFormBuilderController;

Route::get('diviformbuilder/get', [DiviFormBuilderController::class, 'getAllTasks']);
