<?php

namespace FluentCartPro\App\Modules\Reviews\Http\Controllers\Concerns;

trait RateLimitsTrait
{
    /**
     * Increment under an atomic cache operation or a database advisory lock.
     * Return PHP_INT_MAX if the counter cannot be safely persisted, so callers
     * refuse an uncounted action using their normal rate-limit response.
     *
     * @param string $key Cache/transient key
     * @param int    $ttl Time-to-live in seconds
     * @return int New count, or PHP_INT_MAX when counting is unavailable
     */
    protected function atomicIncrement( $key, $ttl = HOUR_IN_SECONDS )
    {
        if ( wp_using_ext_object_cache() ) {
            // add() cannot overwrite a counter another request initialized.
            wp_cache_add( $key, 0, 'fct_rate_limit', $ttl );
            $result = wp_cache_incr( $key, 1, 'fct_rate_limit' );

            return $result === false ? PHP_INT_MAX : (int) $result;
        }

        global $wpdb;
        $lockName = 'fct_rl_' . md5( DB_NAME . ':' . $wpdb->options . ':' . $key );
        $locked = $wpdb->get_var( $wpdb->prepare( 'SELECT GET_LOCK(%s, 1)', $lockName ) );
        if ( (string) $locked !== '1' ) {
            return PHP_INT_MAX;
        }

        try {
            // A waiting request may have cached these before acquiring the
            // lock. Read the latest committed counter and expiry from MySQL.
            wp_cache_delete( '_transient_' . $key, 'options' );
            wp_cache_delete( '_transient_timeout_' . $key, 'options' );
            wp_cache_delete( 'notoptions', 'options' );
            $newCount = (int) get_transient( $key ) + 1;

            return set_transient( $key, $newCount, $ttl ) ? $newCount : PHP_INT_MAX;
        } finally {
            $wpdb->get_var( $wpdb->prepare( 'SELECT RELEASE_LOCK(%s)', $lockName ) );
        }
    }

    /**
     * Get client IP address from REMOTE_ADDR only.
     * HTTP headers like X-Forwarded-For are client-spoofable and not used.
     *
     * @return string Validated IP or empty string
     */
    protected function getClientIp()
    {
        $ip = !empty($_SERVER['REMOTE_ADDR']) ? sanitize_text_field($_SERVER['REMOTE_ADDR']) : '';

        return filter_var($ip, FILTER_VALIDATE_IP) ? $ip : '';
    }
}
