<?php //phpcs:ignore
/**
 * LoginPress LifterLMS Captcha Trait One.
 *
 * Contains all the methods related to captchas on Lifter forms.
 *
 * @package   LoginPress-Pro
 * @subpackage Traits\Loginpress-Integration-One
 * @since 6.2.0
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! trait_exists( 'LoginPress_Lifter_Captcha_Trait_One' ) ) {
	/**
	 * LoginPress LifterLMS Captcha Trait One.
	 *
	 * Contains specific methods related to captchas on Lifter forms.
	 *
	 * @package   LoginPress-Pro
	 * @subpackage Traits\Loginpress-Integration-One
	 * @since 6.2.0
	 */
	trait LoginPress_Lifter_Captcha_Trait_One {

		/**
		 * Authenticate turnstile on the LifterLMS lost password page.
		 *
		 * @param WP_Error $err The error object.
		 * @param WP_User  $user The user object.
		 * @return WP_Error The error object with turnstile validation result.
		 * @since 5.0.0
		 * @version 6.1.0
		 */
		public function loginpress_llms_turnstile_lostpass( $err, $user ) {
			if ( $user && isset( $_POST['_lost_password_nonce'] ) ) { // phpcs:ignore
				// Retrieve the secret key from the plugin settings.
				$secret_key = isset( $this->loginpress_settings['secret_key_cf'] ) ? $this->loginpress_settings['secret_key_cf'] : '';
				// Sanitize the Turnstile response from the form submission.
				$response = isset( $_POST['cf-turnstile-response'] ) ? sanitize_text_field( wp_unslash( $_POST['cf-turnstile-response'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing
				// If no response is received, return a captcha error.
				if ( ! $response ) {
					return new WP_Error( 'captcha_error', __( 'Please wait for the captcha to complete.', 'loginpress-pro' ) );
				}

				// Verify the Turnstile response with Cloudflare's siteverify API.
				$verify_response = wp_remote_post(
					'https://challenges.cloudflare.com/turnstile/v0/siteverify',
					array(
						'body' => array(
							'secret'   => $secret_key,         // Your secret key.
							'response' => $response,           // Captcha response from user.
							'remoteip' => $this->get_address(), // User's IP address.
						),
					)
				);

					// Retrieve and decode the API response.
					$response_body = wp_remote_retrieve_body( $verify_response );
					$result        = json_decode( $response_body, true );
				if ( empty( $result['success'] ) ) {
					$err->add( 'llms_pass_reset_email_failure', __( '<b>Error:</b> Please verify captcha', 'loginpress-pro' ) );
					return $err;
				} else {
					return $err;
				}
			} else {
				return $err;
			}
		}

		/**
		 * Adds hCaptcha field to LifterLMS login fields.
		 *
		 * @param array $fields LifterLMS login fields.
		 * @return array LifterLMS login fields with hCaptcha added.
		 * @since 5.0.0
		 */
		public function loginpress_add_hcaptcha_to_lifter_login_fields( $fields ) {
			ob_start();
			/* LoginPress_Hcaptcha CAPTCHA Settings */
			$lp_hcaptcha = LoginPress_Hcaptcha::instance();
			$lp_hcaptcha->loginpress_hcaptcha_field();
			$lp_hcaptcha->loginpress_hcaptcha_enqueue( 'llms' );
			$hcaptcha_field = ob_get_clean();

			$hcaptcha_field = array(
				'id'          => 'hcaptcha-lifter',
				'type'        => 'html',
				'description' => $hcaptcha_field,

			);
			array_splice( $fields, count( $fields ) - 3, 0, array( $hcaptcha_field ) );

			return $fields;
		}

		/**
		 * Enable hCaptcha on LifterLMS login form.
		 *
		 * This function checks if hCaptcha is enabled and if the user has entered a valid response.
		 * If the response is invalid, it adds a filter to display an error message.
		 *
		 * @param array $creds An array containing the user's login credentials.
		 * @return array|void The user credentials or void.
		 * @since 5.0.0
		 * @version 6.1.0
		 */
		public function loginpress_llms_login_form_hcaptcha_enable( $creds ) {
			if ( $creds ) {
				$lp_recaptcha    = LoginPress_Hcaptcha::instance();
				$hcap_secret_key = isset( $this->loginpress_settings['hcaptcha_secret_key'] ) ? $this->loginpress_settings['hcaptcha_secret_key'] : '';
				if ( isset( $_POST['h-captcha-response'] ) || isset( $_POST['captcha_response'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing
					$post_response = isset( $_POST['h-captcha-response'] ) ? sanitize_text_field( wp_unslash( $_POST['h-captcha-response'] ) ) : sanitize_text_field( wp_unslash( $_POST['captcha_response'] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Missing
					$response      = wp_remote_post(
						'https://hcaptcha.com/siteverify',
						array(
							'body' => array(
								'secret'   => $hcap_secret_key,
								'response' => $post_response,
								'remoteip' => $this->get_address(),
							),
						)
					);

					$response_body = wp_remote_retrieve_body( $response );
					$result        = json_decode( $response_body );

					if ( ! $result->success ) {
						add_filter( 'lifterlms_user_login_errors', array( $this, 'llla_login_lifterlms_hcaptcha_error_callback' ) );
					} else {
						return $creds;
					}
				} elseif ( ( isset( $_POST['wp-submit'] ) || isset( $_POST['login'] ) ) && ! isset( $_POST['h-captcha-response'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing
					add_filter( 'lifterlms_user_login_errors', array( $this, 'llla_login_lifterlms_hcaptcha_error_callback' ) );
				}
			} else {
				return $creds;
			}
		}

		/**
		 * Adds hCaptcha field to LifterLMS register fields.
		 *
		 * @return void
		 * @since 5.0.0
		 */
		public function loginpress_add_hcaptcha_to_lifter_register_fields() {
			ob_start();

			/* Cloudflare CAPTCHA Settings. */
			$lp_hcaptcha = LoginPress_Hcaptcha::instance();
			$lp_hcaptcha->loginpress_hcaptcha_field();
			$lp_hcaptcha->loginpress_hcaptcha_enqueue( 'llms-reg' );
			$hcaptcha_field = ob_get_clean();

			llms_form_field(
				array(
					'id'          => 'hcaptcha-lifter',
					'type'        => 'html',
					'description' => $hcaptcha_field,

				)
			);
		}

		/**
		 * Enables hCaptcha on the LifterLMS register form.
		 *
		 * @param mixed  $valid The current validation status of the form.
		 * @param array  $posted_data The data submitted via the form.
		 * @param string $location The location of the form.
		 * @return mixed The updated validation status of the form.
		 * @since 5.0.0
		 * @version 6.1.0
		 */
		public function loginpress_llms_register_form_hcaptcha_enable( $valid, $posted_data, $location ) {
			$lifter_register = isset( $this->settings['enable_captcha_llms']['lifter_register_form'] ) ? $this->settings['enable_captcha_llms']['lifter_register_form'] : false;
			$lifter_purchase = isset( $this->settings['enable_captcha_llms']['lifter_purchase_form'] ) ? $this->settings['enable_captcha_llms']['lifter_purchase_form'] : false;
			if ( 'registration' === $location && false === $lifter_register ) {
				return;
			}
			if ( 'checkout' === $location && false === $lifter_purchase ) {
				return;
			}
			if ( $posted_data ) {
				$hcap_secret_key = isset( $this->loginpress_settings['hcaptcha_secret_key'] ) ? $this->loginpress_settings['hcaptcha_secret_key'] : '';
				if ( isset( $_POST['h-captcha-response'] ) || isset( $_POST['captcha_response'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing
					$response = wp_remote_post(
						'https://hcaptcha.com/siteverify',
						array(
							'body' => array(
								'secret'   => $hcap_secret_key,
								'response' => sanitize_text_field( wp_unslash( $_POST['h-captcha-response'] ) ), // phpcs:ignore WordPress.Security.NonceVerification.Missing
								'remoteip' => $this->get_address(),
							),
						)
					);

					$response_body = wp_remote_retrieve_body( $response );
					$result        = json_decode( $response_body );

					if ( ! $result->success ) {
						return new WP_Error( 'lifterlms_user_data_invalid', __( '<b>Error:</b> Please verify the Hcaptcha', 'loginpress-pro' ) );
					}
				} elseif ( ! isset( $_POST['h-captcha-response'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing
					return new WP_Error( 'lifterlms_user_data_invalid', __( '<b>Error:</b> Please verify the Hcaptcha', 'loginpress-pro' ) );
				}
			} else {
				return $valid;
			}
		}

		/**
		 * Adds hCaptcha field to LifterLMS lost password fields.
		 *
		 * @param array $fields LifterLMS lost password fields.
		 * @return array LifterLMS lost password fields with hCaptcha added.
		 * @since 5.0.0
		 */
		public function loginpress_add_hcaptcha_to_lifter_lostpass_fields( $fields ) {
			ob_start();
			$lp_hcaptcha = LoginPress_Hcaptcha::instance();
			$lp_hcaptcha->loginpress_hcaptcha_field();
			$lp_hcaptcha->loginpress_hcaptcha_enqueue();
			$hcaptcha_field = ob_get_clean();

			$hcaptcha_field =
					array(
						array(
							'id'          => 'hcaptcha-lifter',
							'type'        => 'html',
							'description' => $hcaptcha_field,

						),
						array(
							'id'    => 'hcaptcha-lifter2',
							'type'  => 'hidden',
							'value' => do_action( 'lifterlms_lost_do_action' ),
						),
					);
			array_splice( $fields, count( $fields ) - 1, 0, $hcaptcha_field );
			return $fields;
		}

		/**
		 * Authenticate hCaptcha on the LifterLMS lost password page.
		 *
		 * @param WP_Error $err The error object.
		 * @param WP_User  $user The user object.
		 * @return WP_Error The error object with hCaptcha validation result.
		 * @since 5.0.0
		 * @version 6.1.0
		 */
		public function loginpress_auth_hcaptcha_lostpassword_llms( $err, $user ) {

			if ( $user && isset( $_POST['_lost_password_nonce'] ) ) { // phpcs:ignore
				$hcap_secret_key = isset( $this->loginpress_settings['hcaptcha_secret_key'] ) ? $this->loginpress_settings['hcaptcha_secret_key'] : '';
				$cap_response    = isset( $_POST['captcha_response'] ) ? sanitize_text_field( wp_unslash( $_POST['captcha_response'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing
				if ( isset( $_POST['h-captcha-response'] ) || $cap_response ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing
					$response = wp_remote_post(
						'https://hcaptcha.com/siteverify',
						array(
							'body' => array(
								'secret'   => $hcap_secret_key,
								'response' => $cap_response ? $cap_response : sanitize_text_field( wp_unslash( $_POST['h-captcha-response'] ) ), // phpcs:ignore WordPress.Security.NonceVerification.Missing
								'remoteip' => $this->get_address(),
							),
						)
					);

					$response_body = wp_remote_retrieve_body( $response );
					$result        = json_decode( $response_body );

					if ( ! $result->success ) {
						$err->add( 'llms_pass_reset_email_failure', __( '<b>Error:</b> Please verify hCaptcha', 'loginpress-pro' ) );
						return $err;
					}
				} elseif ( ! isset( $_POST['h-captcha-response'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing
					$err->add( 'llms_pass_reset_email_failure', __( '<b>Error:</b> Please verify hCaptcha', 'loginpress-pro' ) );
					return $err;
				}
			} else {
				return $err;
			}
		}

		/**
		 * Start session early for LifterLMS integration, specifically for math captcha.
		 *
		 * @since 6.1.0
		 */
		public function loginpress_llms_start_session() {
			// Only start session if math captcha is enabled for LifterLMS.
			$captchas_enabled = isset( $this->loginpress_settings['enable_captchas'] ) ? $this->loginpress_settings['enable_captchas'] : 'off';
			$captchas_type    = isset( $this->loginpress_settings['captchas_type'] ) ? $this->loginpress_settings['captchas_type'] : 'type_recaptcha';

			if ( 'off' !== $captchas_enabled && 'type_math' === $captchas_type ) {
				if ( ! session_id() ) {
					session_start();
				}
			}
		}

		/**
		 * Error callback for the LLMS login form when Math Captcha is enabled.
		 *
		 * @since 6.1.0
		 *
		 * @param WP_Error $err The error object to add the error message to.
		 * @return WP_Error The error object with the error message added.
		 */
		public function loginpress_llms_math_error_callback( $err ) {
			/* translators: 1: Opening HTML tag, 2: Closing HTML tag */
			$err = new WP_Error( 'login-error', sprintf( __( '%1$sError:%2$s Please provide correct Captcha answer', 'loginpress-pro' ), '<b>', '</b>' ) );
			return $err;
		}

		/**
		 * Add the math captcha field to the LifterLMS checkout.
		 *
		 * @since 6.1.0
		 *
		 * @param array $fields The checkout fields.
		 *
		 * @return array The modified checkout fields.
		 */
		public function loginpress_llms_math_captcha_field( $fields ) {

			ob_start();
			$lp_math_captcha = new LoginPress_Math_Captcha( 'llms' );
			$lp_math_captcha->loginpress_math_captcha_field();

			/* LoginPress_Math_Captcha CAPTCHA Settings */
			$math_captcha_field = ob_get_clean();

			$math_captcha_field = array(
				'id'          => 'math-captcha-lifter',
				'type'        => 'html',
				'description' => $math_captcha_field,

			);
			array_splice( $fields, count( $fields ) - 3, 0, array( $math_captcha_field ) );

			return $fields;
		}

		/**
		 * Adds a Math CAPTCHA field to the LLMS lost password form.
		 *
		 * @param array $fields Array of fields to add the Math CAPTCHA field to.
		 *
		 * @return array Array of fields with the Math CAPTCHA field added.
		 * @since 6.1.0
		 */
		public function loginpress_math_captcha_lostpass_field( $fields ) {
			ob_start();
			$lp_math_captcha = new LoginPress_Math_Captcha( 'llms' );
			$lp_math_captcha->loginpress_math_captcha_field();

			/* LoginPress_Math_Captcha CAPTCHA Settings */
			$math_captcha_field = ob_get_clean();

			$math_captcha_field = array(
				array(
					'id'          => 'math-captcha-lifter',
					'type'        => 'html',
					'description' => $math_captcha_field,
				),
			);
			array_splice( $fields, count( $fields ) - 1, 0, $math_captcha_field );

			return $fields;
		}

		/**
		 * Validates Math CAPTCHA on the LLMS lost password form.
		 *
		 * @param WP_Error $err Error object.
		 * @param WP_User  $user User object.
		 *
		 * @return WP_Error Error object with Math CAPTCHA validation result.
		 * @since 6.1.0
		 */
		public function loginpress_llms_auth_math_lostpass( $err, $user ) {

			if ( $user ) {
				if ( isset( $_POST['math_captcha'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing

					$user_answer    = isset( $_POST['math_captcha'] ) ? intval( $_POST['math_captcha'] ) : null; // phpcs:ignore WordPress.Security.NonceVerification.Missing
					$correct_answer = isset( $_SESSION['loginpress_math_llms_lost_captcha'] ) ? $_SESSION['loginpress_math_llms_lost_captcha'] : null; // @codingStandardsIgnoreLine.
					if ( $user_answer !== $correct_answer ) {
						/* translators: 1: Opening HTML tag, 2: Closing HTML tag */
						$err->add( 'llms_pass_reset_email_failure', sprintf( __( '%1$sError:%2$s Please provide correct Captcha answer', 'loginpress-pro' ), '<b>', '</b>' ) );
						return $err;
					} else {
						// Validation passed - return credentials.
						unset( $_SESSION['loginpress_math_llms_lost_captcha'] );
						return $err;
					}
				} elseif ( ! isset( $_POST['math_captcha'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing
					/* translators: 1: Opening HTML tag, 2: Closing HTML tag */
					$err->add( 'llms_pass_reset_email_failure', sprintf( __( '%1$sError:%2$s Please provide correct Captcha answer', 'loginpress-pro' ), '<b>', '</b>' ) );
					return $err;
				}

				unset( $_SESSION['loginpress_math_llms_lost_captcha'] );
			} else {
				return $err;
			}
		}

		/**
		 * Validates Math CAPTCHA on the LLMS login form.
		 *
		 * @since 6.1.0
		 *
		 * @param WP_User|WP_Error $creds The user object if CAPTCHA is correct, otherwise WP_Error.
		 *
		 * @return WP_User|WP_Error The user object if CAPTCHA is correct, otherwise WP_Error.
		 */
		public function loginpress_llms_login_form_math_captcha_enable( $creds ) {

			if ( $creds ) {

				if ( isset( $_POST['math_captcha'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing

					$user_answer    = isset( $_POST['math_captcha'] ) ? intval( $_POST['math_captcha'] ) : null; // phpcs:ignore WordPress.Security.NonceVerification.Missing
					$correct_answer = isset( $_SESSION['loginpress_math_llms_login_captcha'] ) ? $_SESSION['loginpress_math_llms_login_captcha'] : null; // @codingStandardsIgnoreLine.
					if ( $user_answer !== $correct_answer ) {
						add_filter( 'lifterlms_person_login_fields', array( $this, 'loginpress_llms_math_captcha_field' ), 99 );
						add_filter( 'lifterlms_user_login_errors', array( $this, 'loginpress_llms_math_error_callback' ) );
					} else {
						// Validation passed - return credentials.
						unset( $_SESSION['loginpress_math_llms_login_captcha'] );
						return $creds;
					}
				} elseif ( ! isset( $_POST['math_captcha'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing
					add_filter( 'lifterlms_person_login_fields', array( $this, 'loginpress_llms_math_captcha_field' ), 99 );
					add_filter( 'lifterlms_user_login_errors', array( $this, 'loginpress_llms_math_error_callback' ) );
				}

				unset( $_SESSION['loginpress_math_llms_login_captcha'] );
			} else {
				return $creds;
			}
		}

		/**
		 * Validates Math CAPTCHA on the LLMS registration form.
		 *
		 * @param bool   $valid      The current validation status of the form.
		 * @param array  $posted_data The data submitted via the form.
		 * @param string $location   The location of the form.
		 *
		 * @since 6.1.0
		 *
		 * @return bool|WP_Error The updated validation status of the form.
		 */
		public function loginpress_llms_register_form_math_captcha_enable( $valid, $posted_data, $location ) {

			$lifter_register = isset( $this->settings['enable_captcha_llms']['lifter_register_form'] ) ? $this->settings['enable_captcha_llms']['lifter_register_form'] : false;
			$lifter_purchase = isset( $this->settings['enable_captcha_llms']['lifter_purchase_form'] ) ? $this->settings['enable_captcha_llms']['lifter_purchase_form'] : false;

			if ( ( 'registration' === $location && false === $lifter_register ) || ( 'checkout' === $location && false === $lifter_purchase ) ) {
				return;
			}

			if ( $posted_data ) {

				if ( isset( $_POST['math_captcha'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing

					$user_answer = isset( $_POST['math_captcha'] ) ? intval( $_POST['math_captcha'] ) : null; // phpcs:ignore WordPress.Security.NonceVerification.Missing
					// Determine which session key to use based on the current action/context.
					$correct_answer = null;
					if ( isset( $_SESSION['loginpress_math_llms_reg_captcha'] ) ) {
						$correct_answer = isset( $_SESSION['loginpress_math_llms_reg_captcha'] ) ? $_SESSION['loginpress_math_llms_reg_captcha'] : null; // @codingStandardsIgnoreLine.
						$session_key    = 'loginpress_math_llms_reg_captcha';
					}

					if ( $user_answer !== $correct_answer ) {
						/* translators: 1: Opening HTML tag, 2: Closing HTML tag */
						return new WP_Error( 'lifterlms_user_data_invalid', sprintf( __( '%1$sError:%2$s Please provide correct Captcha answer', 'loginpress-pro' ), '<b>', '</b>' ) );
					}
				} elseif ( ! isset( $_POST['math_captcha'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing
					/* translators: 1: Opening HTML tag, 2: Closing HTML tag */
					return new WP_Error( 'lifterlms_user_data_invalid', sprintf( __( '%1$sError:%2$s Please provide correct Captcha answer', 'loginpress-pro' ), '<b>', '</b>' ) );
				}

				unset( $_SESSION[ $session_key ] );
				return $valid;
			} else {
				return $valid;
			}
		}
	}
}
