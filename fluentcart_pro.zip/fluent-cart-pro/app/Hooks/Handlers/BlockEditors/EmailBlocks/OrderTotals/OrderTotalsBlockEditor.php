<?php

namespace FluentCartPro\App\Hooks\Handlers\BlockEditors\EmailBlocks\OrderTotals;

use FluentCart\App\Hooks\Handlers\BlockEditors\BlockEditor;

class OrderTotalsBlockEditor extends BlockEditor
{
    use \FluentCartPro\App\Contracts\CanEnqueue;
    protected static string $editorName = 'email-order-totals';

    public function getScripts(): array
    {
        return [
            [
                'source'       => 'admin/BlockEditor/EmailBlocks/OrderTotals/OrderTotalsBlockEditor.jsx',
                'dependencies' => ['wp-blocks', 'wp-components', 'wp-block-editor']
            ]
        ];
    }

    public function getStyles(): array
    {
        return [
            'admin/BlockEditor/EmailBlocks/OrderTotals/style/order-totals-block-editor.scss'
        ];
    }

    public function localizeData(): array
    {
        return [
            $this->getLocalizationKey() => [
                'slug'        => $this->slugPrefix,
                'name'        => static::getEditorName(),
                'title'       => __('Order Totals', 'fluent-cart-pro'),
                'description' => __('Breakdown of subtotal, shipping, tax, discount, and total.', 'fluent-cart-pro'),
            ],
            'fluent_cart_pro_block_translation' => \FluentCartPro\App\Services\Translations\Translations::blockStrings(),
        ];
    }

    public function blockAttributes(): array
    {
        return [];
    }

    public function supports(): array
    {
        return [
            'html'       => false,
            'align'      => false,
            'color'      => [
                'text'       => true,
                'background' => true,
                'link'       => true,
            ],
            'typography' => [
                'fontSize'   => true,
                'lineHeight' => true,
            ],
            'spacing'    => [
                'margin'  => true,
                'padding' => true,
            ],
            '__experimentalBorder' => [
                'color'  => true,
                'radius' => true,
                'style'  => true,
                'width'  => true,
            ],
        ];
    }

    public function render(array $attrs, $block = null, $content = ''): string
    {
        return $content;
    }
}
