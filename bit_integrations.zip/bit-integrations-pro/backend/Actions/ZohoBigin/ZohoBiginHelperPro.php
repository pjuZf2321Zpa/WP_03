<?php

namespace BitApps\IntegrationsPro\Actions\ZohoBigin;

class ZohoBiginHelperPro
{
    public static function getTagList($tags, $accessToken, $dataCenter, $module)
    {
        $httpHelperClass = bit_integrations_get_class('Core\\Util\\HttpHelper');

        $tagsMetaApiEndpoint = "http://www.zohoapis.{$dataCenter}/bigin/v1/settings/tags?module={$module}";
        $authorizationHeader['Authorization'] = "Zoho-oauthtoken {$accessToken}";
        $tagsMetaResponse = $httpHelperClass::get($tagsMetaApiEndpoint, null, $authorizationHeader);

        if (!is_wp_error($tagsMetaResponse)) {
            return array_column($tagsMetaResponse->tags ?? $tags, 'name');
        }

        return $tags;
    }

    public static function addTagsToRecords($recordID, $module, $tags, $apiDomain, $defaultHeader)
    {
        $httpHelperClass = bit_integrations_get_class('Core\\Util\\HttpHelper');

        $tagsMetaApiEndpoint = "{$apiDomain}/bigin/v1/{$module}/actions/add_tags?ids={$recordID}&tag_names={$tags}";

        return $httpHelperClass::post($tagsMetaApiEndpoint, null, $defaultHeader);
    }
}
