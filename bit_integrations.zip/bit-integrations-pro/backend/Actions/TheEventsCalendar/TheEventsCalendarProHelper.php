<?php

namespace BitApps\IntegrationsPro\Actions\TheEventsCalendar;

use BitApps\IntegrationsPro\Actions\TheEventsCalendar\Services\CategoryService;
use BitApps\IntegrationsPro\Actions\TheEventsCalendar\Services\EventService;
use BitApps\IntegrationsPro\Actions\TheEventsCalendar\Services\OrganizerService;
use BitApps\IntegrationsPro\Actions\TheEventsCalendar\Services\SeriesService;
use BitApps\IntegrationsPro\Actions\TheEventsCalendar\Services\VenueService;

if (!\defined('ABSPATH')) {
    exit;
}

final class TheEventsCalendarProHelper
{
    public static function createEvent($response, $fieldData, $settings = [])
    {
        return self::runService(EventService::class, 'createEvent', $fieldData, $settings);
    }

    public static function updateEvent($response, $fieldData, $settings = [])
    {
        return self::runService(EventService::class, 'updateEvent', $fieldData, $settings);
    }

    public static function deleteEvent($response, $fieldData, $settings = [])
    {
        return self::runService(EventService::class, 'deleteEvent', $fieldData, $settings);
    }

    public static function updateEventStatus($response, $fieldData, $settings = [])
    {
        return self::runService(EventService::class, 'updateEventStatus', $fieldData, $settings);
    }

    public static function duplicateEvent($response, $fieldData, $settings = [])
    {
        return self::runService(EventService::class, 'duplicateEvent', $fieldData, $settings);
    }

    public static function createRecurringEvent($response, $fieldData, $settings = [])
    {
        return self::runService(EventService::class, 'createRecurringEvent', $fieldData, $settings);
    }

    public static function createVenue($response, $fieldData, $settings = [])
    {
        return self::runService(VenueService::class, 'createVenue', $fieldData, $settings);
    }

    public static function updateVenue($response, $fieldData, $settings = [])
    {
        return self::runService(VenueService::class, 'updateVenue', $fieldData, $settings);
    }

    public static function deleteVenue($response, $fieldData, $settings = [])
    {
        return self::runService(VenueService::class, 'deleteVenue', $fieldData, $settings);
    }

    public static function createOrganizer($response, $fieldData, $settings = [])
    {
        return self::runService(OrganizerService::class, 'createOrganizer', $fieldData, $settings);
    }

    public static function updateOrganizer($response, $fieldData, $settings = [])
    {
        return self::runService(OrganizerService::class, 'updateOrganizer', $fieldData, $settings);
    }

    public static function deleteOrganizer($response, $fieldData, $settings = [])
    {
        return self::runService(OrganizerService::class, 'deleteOrganizer', $fieldData, $settings);
    }

    public static function createEventCategory($response, $fieldData, $settings = [])
    {
        return self::runService(CategoryService::class, 'createEventCategory', $fieldData, $settings);
    }

    public static function createSeries($response, $fieldData, $settings = [])
    {
        return self::runService(SeriesService::class, 'createSeries', $fieldData, $settings);
    }

    public static function addEventToSeries($response, $fieldData, $settings = [])
    {
        return self::runService(SeriesService::class, 'addEventToSeries', $fieldData, $settings);
    }

    private static function runService(string $serviceClass, string $method, $fieldData, $settings = [])
    {
        if (!TheEventsCalendarHelper::isPluginActive()) {
            return [
                'success' => false,
                'message' => __('The Events Calendar is not active. Activate The Events Calendar plugin.', 'bit-integrations-pro'),
            ];
        }

        return (new $serviceClass($fieldData, $settings))->{$method}();
    }
}
