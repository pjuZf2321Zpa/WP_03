<?php

namespace FluentCartPro\App\Hooks\Handlers\BlockEditors\OrderBumpBlocks;

class OrderBumpAddButtonBlockEditor extends OrderBumpActionBlockEditor
{
    protected static string $editorName = 'order-bump-add-button';

    protected function action(): string
    {
        return 'add';
    }

    protected function defaultLabel(): string
    {
        return __('Add', 'fluent-cart-pro');
    }

    protected function blockTitle(): string
    {
        return __('Order Bump Add Button', 'fluent-cart-pro');
    }

    protected function blockDescription(): string
    {
        return __('The button that adds the offer to the cart.', 'fluent-cart-pro');
    }
}
