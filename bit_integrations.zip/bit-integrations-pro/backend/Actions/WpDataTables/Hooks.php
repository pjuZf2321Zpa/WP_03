<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Actions\WpDataTables\WpDataTablesRecordHelper;
use BitApps\IntegrationsPro\Config;
use BitApps\IntegrationsPro\Core\Util\Hooks;

Hooks::filter(Config::withFreePrefix('wp_data_tables_add_row'), [WpDataTablesRecordHelper::class, 'addRow'], 10, 3);
