<?php

namespace FluentCartPro\App\Modules\PaymentMethods\MollieGateway;

use FluentCart\App\Helpers\Status;
use FluentCart\App\Models\OrderTransaction;
use FluentCart\App\Models\Subscription;
use FluentCart\App\Modules\PaymentMethods\Core\AbstractSubscriptionModule;
use FluentCart\App\Modules\Subscriptions\Services\SubscriptionService;
use FluentCart\App\Helpers\StatusHelper;
use FluentCart\App\Services\DateTime\DateTime;
use FluentCart\Framework\Support\Arr;
use FluentCartPro\App\Modules\PaymentMethods\MollieGateway\API\MollieAPI;

class MollieSubscriptions extends AbstractSubscriptionModule
{
    public function reSyncSubscriptionFromRemote(Subscription $subscriptionModel)
    {
        if ($subscriptionModel->current_payment_method !== 'mollie') {
            return new \WP_Error('invalid_payment_method', __('This subscription is not using Mollie as payment method.', 'fluent-cart-pro'));
        }

        
        $order = $subscriptionModel->order;
        $vendorSubscriptionId = $subscriptionModel->vendor_subscription_id;

        if (!$vendorSubscriptionId) {
            return new \WP_Error(
                'invalid_subscription',
                __('Invalid vendor subscription ID.', 'fluent-cart-pro')
            );
        }

        $mode = $order->mode ?: 'current';

        $mollieSubscription = (new MollieAPI())->getMollieObject('customers/' . $subscriptionModel->vendor_customer_id . '/subscriptions/' . $vendorSubscriptionId, [], $mode);

        if (is_wp_error($mollieSubscription)) {
            return MollieHelper::sanitizeApiError(
                $mollieSubscription,
                'mollie_subscription_resync_fetch_failed',
                __('We could not sync this subscription with Mollie. Please try again in a moment.', 'fluent-cart-pro'),
                ['module_name' => 'subscription', 'module_id' => $subscriptionModel->id]
            );
        }

        $subscriptionUpdateData = MollieHelper::getSubscriptionUpdateData($mollieSubscription, $subscriptionModel);

        // Mollie pages payments at 50/request by default; a subscription's full history
        // can span many pages, and a missing-webhook payment can be on any of them. Walk
        // _links.next until exhausted (capped, so a malformed/self-referencing link can't
        // loop forever) rather than only inspecting the newest page.
        $paymentsUrl = 'customers/' . $subscriptionModel->vendor_customer_id . '/subscriptions/' . $vendorSubscriptionId . '/payments';
        $paymentsQuery = ['limit' => 250];
        $molliePayments = [];
        $pagesFetched = 0;
        $maxPages = 50;

        while ($paymentsUrl && $pagesFetched < $maxPages) {
            $paymentsPage = (new MollieAPI())->getMollieObject($paymentsUrl, $paymentsQuery, $mode);

            if (is_wp_error($paymentsPage)) {
                return MollieHelper::sanitizeApiError(
                    $paymentsPage,
                    'mollie_subscription_resync_payments_fetch_failed',
                    __('We could not sync this subscription with Mollie. Please try again in a moment.', 'fluent-cart-pro'),
                    ['module_name' => 'subscription', 'module_id' => $subscriptionModel->id]
                );
            }

            $molliePayments = array_merge($molliePayments, Arr::get($paymentsPage, '_embedded.payments', []));

            $paymentsUrl = Arr::get($paymentsPage, '_links.next.href');
            $paymentsQuery = [];
            $pagesFetched++;
        }

        // Hitting the cap with pages still remaining means the history is only partially
        // read; reconciling against it would mark the resync done while older payments
        // stay missing. Fail loud instead.
        if ($paymentsUrl) {
            return MollieHelper::sanitizeApiError(
                new \WP_Error('mollie_pagination_incomplete', 'Mollie subscription payments exceeded ' . $maxPages . ' pages'),
                'mollie_subscription_resync_payments_fetch_failed',
                __('We could not sync this subscription with Mollie. Please try again in a moment.', 'fluent-cart-pro'),
                ['module_name' => 'subscription', 'module_id' => $subscriptionModel->id]
            );
        }

        $newPayment = false;

        // Pagination can return hundreds/thousands of payments; looking each one up with
        // its own query (as before) turns that into as many DB round-trips. Batch the
        // vendor_charge_id lookup into one query and index it in PHP instead.
        $paidPaymentIds = array_values(array_unique(array_filter(array_map(function ($payment) {
            return Arr::get($payment, 'status') === 'paid' ? Arr::get($payment, 'id') : null;
        }, $molliePayments))));

        $existingTransactionsByChargeId = [];
        if ($paidPaymentIds) {
            foreach (OrderTransaction::query()->whereIn('vendor_charge_id', $paidPaymentIds)->get() as $existingTransaction) {
                $existingTransactionsByChargeId[$existingTransaction->vendor_charge_id] = $existingTransaction;
            }
        }

        // The checkout-created initial transaction (no vendor_charge_id yet) is a single
        // row per subscription, not per-payment - fetch it once, outside the loop.
        $pendingInitialTransaction = OrderTransaction::query()
            ->where('subscription_id', $subscriptionModel->id)
            ->where('vendor_charge_id', '')
            ->where('transaction_type', Status::TRANSACTION_TYPE_CHARGE)
            ->first();

        foreach($molliePayments as $payment){
            $paymentId = Arr::get($payment, 'id');

            if (Arr::get($payment, 'status') == 'paid') {

                // Mollie's paidAt is when the money actually moved; that is the
                // settlement moment, not this resync's run time.
                $paidAt = Arr::get($payment, 'paidAt');
                $settledAt = $paidAt ? DateTime::anyTimeToGmt($paidAt)->format('Y-m-d H:i:s') : null;

                $amount = MollieHelper::convertToCents(Arr::get($payment, 'amount.value', '0.00'), Arr::get($payment, 'amount.currency'));
                $methodType  = Arr::get($payment, 'method');
                $cardLast4 =  Arr::get($payment, 'details.cardNumber', null);
                $cardBrand = Arr::get($payment, 'details.cardLabel', null);

                $transaction = $existingTransactionsByChargeId[$paymentId] ?? null;

                if (!$transaction) {

                    $transaction = $pendingInitialTransaction;

                    if ($transaction) {
                        $meta = array_merge($transaction->meta ?? [], [
                            'mollie_payment_id' => $paymentId,
                            'payment_method_type' => $methodType,
                        ]);
                        if ($settledAt && empty($meta['settled_at'])) {
                            $meta['settled_at'] = $settledAt;
                        }

                        $transaction->update([
                            'vendor_charge_id' => $paymentId,
                            'status'           => Status::TRANSACTION_SUCCEEDED,
                            'total'            => $amount,
                            'meta'             => $meta,
                            'card_last_4'    => $cardLast4,
                            'card_brand'       => $cardBrand,
                            'payment_method_type' => $methodType
                        ]);

                        (new StatusHelper($transaction->order))->syncOrderStatuses($transaction);

                        $existingTransactionsByChargeId[$paymentId] = $transaction;
                        $pendingInitialTransaction = null;

                        continue;
                    }
                    // Create new transaction
                    $transactionData = [
                        'order_id'         => $order->id,
                        'total'            => $amount,
                        'currency'         => Arr::get($payment, 'amount.currency'),
                        'vendor_charge_id' => $paymentId,
                        'status'           => MollieHelper::getCorrectTransactionStatus(strtolower(Arr::get($payment, 'status', ''))),
                        'payment_method'   => 'mollie',
                        'transaction_type' => Status::TRANSACTION_TYPE_CHARGE,
                        'card_last_4'       => $cardLast4,
                        'card_brand'       => $cardBrand,
                        'created_at'       => DateTime::anyTimeToGmt(Arr::get($payment, 'paidAt'))->format('Y-m-d H:i:s'),
                    ];
                    if ($settledAt) {
                        $transactionData['meta'] = array_merge($transactionData['meta'] ?? [], ['settled_at' => $settledAt]);
                    }
                    $newPayment = true;
                    SubscriptionService::recordRenewalPayment($transactionData, $subscriptionModel, $subscriptionUpdateData);
                } else if ($transaction->status !== Status::TRANSACTION_SUCCEEDED) {
                    if ($settledAt && empty($transaction->meta['settled_at'])) {
                        $transaction->meta = array_merge($transaction->meta ?? [], [
                            'settled_at' => $settledAt
                        ]);
                    }

                    // Update existing transaction if status has changed
                    $transaction->update([
                        'status' => MollieHelper::getCorrectTransactionStatus(strtolower(Arr::get($payment, 'status', ''))),
                    ]);

                    (new StatusHelper($transaction->order))->syncOrderStatuses($transaction);
                }
            }
        }

        // Update subscription data
        if (!$newPayment) {
            $subscriptionModel = SubscriptionService::syncSubscriptionStates($subscriptionModel, $subscriptionUpdateData);
        } else {
            $subscriptionModel = Subscription::query()->find($subscriptionModel->id);
        }

        return $subscriptionModel;
    }

    public function cancel($vendorSubscriptionId, $args = [])
    {
        
        $subscriptionModel = Subscription::query()->where('vendor_subscription_id', $vendorSubscriptionId)->first();

        // A reactivation cancels the Mollie subscription it replaced, which no row holds any more
        if (!$subscriptionModel && Arr::get($args, 'subscription_id')) {
            $subscriptionModel = Subscription::query()->find(Arr::get($args, 'subscription_id'));
        }

        if (!$subscriptionModel) {
            return new \WP_Error(
                'invalid_subscription',
                __('Invalid vendor subscription ID.', 'fluent-cart-pro')
            );
        }

        // Core passes the payment's original mode via $args['mode'] (cancelRemoteSubscription);
        // maybeConvertToManualSubscription doesn't, so fall back to the subscription's order.
        $mode = Arr::get($args, 'mode') ?: ($subscriptionModel->order->mode ?: 'current');

        // check if the subscription is already canceled in Mollie, if yes then just update the status in our database instead of calling cancel api again
        $mollieSubscription = (new MollieAPI())->getMollieObject('customers/' . $subscriptionModel->vendor_customer_id . '/subscriptions/' . $vendorSubscriptionId, [], $mode);

        if (is_wp_error($mollieSubscription)) {
            return MollieHelper::sanitizeApiError(
                $mollieSubscription,
                'mollie_subscription_cancel_lookup_failed',
                __('We could not cancel this subscription with Mollie. Please try again in a moment.', 'fluent-cart-pro'),
                ['module_name' => 'subscription', 'module_id' => $subscriptionModel->id]
            );
        }

        $status = MollieHelper::transformSubscriptionStatus($mollieSubscription, $subscriptionModel);
        if ($status === Status::SUBSCRIPTION_CANCELED) {
            return [
                'status' => Status::SUBSCRIPTION_CANCELED,
                'canceled_at' => DateTime::anyTimeToGmt(Arr::get($mollieSubscription, 'canceledAt'))->format('Y-m-d H:i:s')
            ];
        }


        $response = (new MollieAPI())->deleteMollieObject('customers/' . $subscriptionModel->vendor_customer_id .'/subscriptions/' . $vendorSubscriptionId, [], $mode);

        if (is_wp_error($response)) {
            return MollieHelper::sanitizeApiError(
                $response,
                'mollie_subscription_cancel_failed',
                __('We could not cancel this subscription with Mollie. Please try again in a moment.', 'fluent-cart-pro'),
                ['module_name' => 'subscription', 'module_id' => $subscriptionModel->id]
            );
        }
 

        return [
            'status' => Status::SUBSCRIPTION_CANCELED,
            'canceled_at' => DateTime::anyTimeToGmt(Arr::get($response, 'canceledAt'))->format('Y-m-d H:i:s')
        ];
    
    }

}
