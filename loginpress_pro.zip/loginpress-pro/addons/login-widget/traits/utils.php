<?php // phpcs:ignore
/**
 * LoginPress Login Widget Utils Trait.
 *
 * Handles Some helping functions from login-widget file.
 *
 * @package   LoginPress
 * @subpackage Traits\LoginWidget
 * @since 6.2.0
 */

/**
 * Prevent direct access.
 *
 * @package LoginPress
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! trait_exists( 'LoginPress_Login_Widget_Trait' ) ) {

	/**
	 * LoginPress Login Widget Trait.
	 *
	 * @package   LoginPress
	 * @subpackage Traits\LoginWidget
	 * @since 6.2.0
	 */
	trait LoginPress_Login_Widget_Trait {

		/**
		 * Check if the login widget is present on the current page.
		 *
		 * @since 6.2.0
		 * @return bool True if widget is present, false otherwise.
		 */
		private function loginpress_is_widget_present() {

			$block_name  = 'loginpress/login-widget';
			$widget_slug = 'loginpress-login-widget';

			$sidebars_widgets = wp_get_sidebars_widgets();
			if ( is_array( $sidebars_widgets ) ) {
				foreach ( $sidebars_widgets as $sidebar_widgets ) {
					if ( empty( $sidebar_widgets ) || ! is_array( $sidebar_widgets ) ) {
						continue;
					}

					foreach ( $sidebar_widgets as $widget_id ) {
						if ( strpos( $widget_id, $widget_slug ) === 0 ) {
							return true;
						}
					}
				}
			}

			if ( function_exists( 'has_block' ) && is_singular() ) {
				$post = get_post();
				if ( $post && has_block( $block_name, $post->post_content ) ) {
					return true;
				}
			}

			$widget_blocks = get_option( 'widget_block' );
			if ( function_exists( 'has_block' ) && is_array( $widget_blocks ) ) {

				foreach ( $widget_blocks as $widget ) {
					if ( empty( $widget['content'] ) ) {
						continue;
					}

					if ( has_block( $block_name, $widget['content'] ) ) {
						return true;
					}
				}
			}

			if ( function_exists( 'wp_is_block_theme' ) && wp_is_block_theme() ) {

				$templates = array(
					'header',
					'footer',
					'sidebar',
					'singular',
					'home',
					'front-page',
					'archive',
				);

				foreach ( $templates as $slug ) {
					$template = get_block_template( get_stylesheet() . '//' . $slug );
					if ( $template && ! empty( $template->content ) ) {
						if ( has_block( $block_name, $template->content ) ) {
							return true;
						}
					}
				}
			}

			return false;
		}

		/**
		 * Get error messages for widget forms.
		 *
		 * @since 6.2.0
		 * @return array Array of error messages.
		 */
		private function loginpress_get_widget_error() {
			$loginpress_key = get_option( 'loginpress_customization' ) ?: array(); // @codingStandardsIgnoreLine

			/* Translators: For Invalid username. */
			$invalid_usrname = array_key_exists( 'incorrect_username', $loginpress_key ) && ! empty( $loginpress_key['incorrect_username'] ) ? $loginpress_key['incorrect_username'] : sprintf( __( '%1$sError:%2$s Invalid Username.', 'loginpress-pro' ), '<strong>', '</strong>' );

			/* Translators: For Invalid password. */
			$invalid_pasword = array_key_exists( 'incorrect_password', $loginpress_key ) && ! empty( $loginpress_key['incorrect_password'] ) ? $loginpress_key['incorrect_password'] : sprintf( __( '%1$sError:%2$s Invalid Password.', 'loginpress-pro' ), '<strong>', '</strong>' );

			/* Translators: If username field is empty. */
			$empty_username = array_key_exists( 'empty_username', $loginpress_key ) && ! empty( $loginpress_key['empty_username'] ) ? $loginpress_key['empty_username'] : sprintf( __( '%1$sError:%2$s The username field is empty.', 'loginpress-pro' ), '<strong>', '</strong>' );

			/* Translators: For empty password. */
			$empty_password = array_key_exists( 'empty_password', $loginpress_key ) && ! empty( $loginpress_key['empty_password'] ) ? $loginpress_key['empty_password'] : sprintf( __( '%1$sError:%2$s The password field is empty.', 'loginpress-pro' ), '<strong>', '</strong>' );

			/* Translators: For invalid email. */
			$invalid_email = array_key_exists( 'invalid_email', $loginpress_key ) && ! empty( $loginpress_key['invalid_email'] ) ? $loginpress_key['invalid_email'] : sprintf( __( '%1$sError:%2$s The email address isn\'t correct..', 'loginpress-pro' ), '<strong>', '</strong>' );

			return array(
				'empty_username'   => $empty_username,
				'empty_password'   => $empty_password,
				'invalid_username' => $invalid_usrname,
				'invalid_password' => $invalid_pasword,
				'invalid_email'    => $invalid_email,
			);
		}

		/**
		 * Get widget parameters for JavaScript localization.
		 *
		 * @since 6.2.0
		 * @return array Array of widget parameters.
		 */
		private function loginpress_get_widget_params() {
			$loginpress_setting    = get_option( 'loginpress_setting' );
			$enable_pass_strength  = isset( $loginpress_setting['enable_pass_strength'] ) ? $loginpress_setting['enable_pass_strength'] : 'off';
			$enable_on_form        = isset( $loginpress_setting['enable_pass_strength_forms']['register'] ) ? $loginpress_setting['enable_pass_strength_forms']['register'] : 'off';
			$min_length            = isset( $loginpress_setting['minimum_pass_char'] ) ? $loginpress_setting['minimum_pass_char'] : '';
			$require_upper_lower   = isset( $loginpress_setting['pass_strength']['lower_upper_char_must'] ) ? $loginpress_setting['pass_strength']['lower_upper_char_must'] : 'off';
			$require_special_char  = isset( $loginpress_setting['pass_strength']['special_char_must'] ) ? $loginpress_setting['pass_strength']['special_char_must'] : 'off';
			$integer_no_must       = isset( $loginpress_setting['pass_strength']['integer_no_must'] ) ? $loginpress_setting['pass_strength']['integer_no_must'] : 'off';
			$enable_reg_pass_field = isset( $loginpress_setting['enable_reg_pass_field'] ) ? $loginpress_setting['enable_reg_pass_field'] : 'off';

			$error_messages = $this->loginpress_get_widget_error();

			return array(
				'ajaxurl'               => admin_url( 'admin-ajax.php' ),
				'force_ssl_admin'       => force_ssl_admin() ? 1 : 0,
				'is_ssl'                => is_ssl() ? 1 : 0,
				'empty_username'        => $error_messages['empty_username'],
				'empty_password'        => $error_messages['empty_password'],
				'invalid_username'      => $error_messages['invalid_username'],
				'invalid_password'      => $error_messages['invalid_password'],
				'invalid_email'         => $error_messages['invalid_email'],
				'lp_widget_nonce'       => wp_create_nonce( 'loginpress_login_widget_security' ),
				'enable_pass_strength'  => $enable_pass_strength,
				'enable_on_form'        => $enable_on_form,
				'min_length'            => $min_length,
				'require_upper_lower'   => $require_upper_lower,
				'require_special_char'  => $require_special_char,
				'integer_no_must'       => $integer_no_must,
				'enable_reg_pass_field' => $enable_reg_pass_field,
			);
		}

		/**
		 * Start PHP session if not already started.
		 *
		 * @since 6.2.0
		 * @return void
		 */
		private function loginpress_start_session() {
			try {
				if ( PHP_SESSION_NONE === session_status() && ! session_id() ) {
					session_start();
				}
			} catch ( Exception $e ) {
				error_log( 'Failed to start session: ' . $e->getMessage() ); // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
			}
		}

		/**
		 * Handles the registration process for the login widget.
		 *
		 * Called by the login widget via an AJAX request.
		 *
		 * @since 4.0.0
		 * @version 6.2.0
		 *
		 * @return void|null
		 */
		public function loginpress_widget_register_process() {
			// Check nonce for security.
			check_ajax_referer( 'loginpress_login_widget_security', 'nonce' );

			// Get registration data from the AJAX request.
			$username                    = isset( $_POST['user_login'] ) ? sanitize_user( wp_unslash( $_POST['user_login'] ) ) : '';
			$email                       = isset( $_POST['user_email'] ) ? sanitize_email( wp_unslash( $_POST['user_email'] ) ) : '';
			$pass                        = isset( $_POST['loginpress-reg-pass'] ) ? sanitize_text_field( wp_unslash( $_POST['loginpress-reg-pass'] ) ) : '';
			$errors                      = new WP_Error();
			$captcha_response            = isset( $_POST['captcha_response'] ) ? sanitize_text_field( wp_unslash( $_POST['captcha_response'] ) ) : '';
			$math_captcha_raw            = isset( $_POST['math_captcha'] ) ? sanitize_text_field( wp_unslash( $_POST['math_captcha'] ) ) : '';
			$math_captcha_answer         = ! empty( $math_captcha_raw ) ? intval( $math_captcha_raw ) : null;
			$math_captcha_hash           = isset( $_POST['loginpress_math_captcha_hash'] ) ? sanitize_text_field( wp_unslash( $_POST['loginpress_math_captcha_hash'] ) ) : '';
			$loginpress_captcha_settings = $this->captcha_settings;
			$loginpress_settings         = $this->general_settings;
			$enable_verification         = isset( $loginpress_settings['enable_user_verification'] ) ? $loginpress_settings['enable_user_verification'] : '';
			$cap_register                = isset( $loginpress_captcha_settings['captcha_enable']['register_form'] ) ? $loginpress_captcha_settings['captcha_enable']['register_form'] : false;
			$cap_reg_cf                  = isset( $loginpress_captcha_settings['captcha_enable_cf']['register_form'] ) ? $loginpress_captcha_settings['captcha_enable_cf']['register_form'] : false;
			$hcaptcha_reg                = isset( $loginpress_captcha_settings['hcaptcha_enable']['register_form'] ) ? $loginpress_captcha_settings['hcaptcha_enable']['register_form'] : 'off';
			$math_reg                    = isset( $loginpress_captcha_settings['math_captcha_enable']['register_form'] ) ? $loginpress_captcha_settings['math_captcha_enable']['register_form'] : 'off';
			$captchas_type               = isset( $loginpress_captcha_settings['captchas_type'] ) ? $loginpress_captcha_settings['captchas_type'] : 'type_recaptcha';
			if ( isset( $loginpress_captcha_settings['enable_captchas'] ) && 'on' === $loginpress_captcha_settings['enable_captchas'] ) {
				if ( ( 'off' !== $hcaptcha_reg && 'type_hcaptcha' === $captchas_type ) ||
				( 'off' !== $cap_register && 'type_recaptcha' === $captchas_type ) ||
				( $cap_reg_cf && 'type_cloudflare' === $captchas_type ) ||
				( 'off' !== $math_reg && 'type_math' === $captchas_type ) ) {
					if ( 'type_math' === $captchas_type && 'off' !== $math_reg ) {
						// Validate math captcha - check if field is empty.
						if ( empty( $math_captcha_raw ) && empty( $math_captcha_hash ) ) {
							wp_send_json_error(
								array(
									'no_response' => true,
									'message'     => __( 'Please verify the Captcha', 'loginpress-pro' ),
								)
							);
							wp_die();
						}
						// Start session if needed.
						$this->loginpress_start_session();
						$correct_answer = isset( $_SESSION['loginpress_math_widget_reg_captcha'] ) ? $_SESSION['loginpress_math_widget_reg_captcha'] : null; // @codingStandardsIgnoreLine.
						if ( $math_captcha_hash ) {
							$salt = wp_salt();
							if ( md5( $math_captcha_answer . $salt ) !== $math_captcha_hash ) {
								wp_send_json_error(
									array(
										'message' => __( 'Please provide correct Captcha answer', 'loginpress-pro' ),
									)
								);
								wp_die();
							}
						} elseif ( null !== $math_captcha_answer && $math_captcha_answer !== $correct_answer ) {
							wp_send_json_error(
								array(
									'message' => __( 'Please provide correct Captcha answer', 'loginpress-pro' ),
								)
							);
							wp_die();
						}
						unset( $_SESSION['loginpress_math_widget_reg_captcha'] ); // @codingStandardsIgnoreLine.
					} elseif ( $captcha_response ) {
						if ( class_exists( 'LoginPress_Recaptcha' ) ) {
							if ( $cap_register || $cap_reg_cf ) {
								if ( 'type_recaptcha' === $loginpress_captcha_settings['captchas_type'] ) {
									$captcha = new LoginPress_Recaptcha( $loginpress_settings, $loginpress_captcha_settings );
									add_filter( 'registration_errors', array( $captcha, 'loginpress_recaptcha_registration_auth' ), 10, 3 );
								} elseif ( 'type_hcaptcha' === $loginpress_captcha_settings['captchas_type'] ) {
									$hcaptcha = new LoginPress_Hcaptcha( $loginpress_captcha_settings );
									add_filter( 'registration_errors', array( $hcaptcha, 'loginpress_hcaptcha_registration_auth' ), 10, 3 );
								} elseif ( 'type_cloudflare' === $loginpress_captcha_settings['captchas_type'] ) {
									$cf = new LoginPress_Turnstile( $loginpress_captcha_settings );
									add_filter( 'registration_errors', array( $cf, 'loginpress_turnstile_auth_widget' ), 10, 4 );
								}
							}
						}
					} else {
						wp_send_json_error(
							array(
								'no_response' => true,
								'message'     => __( 'Please verify the Captcha', 'loginpress-pro' ),
							)
						);
						wp_die();
					}
				}
			}

			// Check if the username or email already exists.
			if ( username_exists( $username ) ) {
				wp_send_json_error(
					array(
						'username_exists' => true,
						'message'         => __( 'This username is already taken.', 'loginpress-pro' ),
					)
				);
			}
			if ( email_exists( $email ) ) {
				wp_send_json_error(
					array(
						'email_exists' => true,
						'message'      => __( 'This email is already registered.', 'loginpress-pro' ),
					)
				);
			}

			// If no errors, proceed with registration.
			if ( empty( $errors->get_error_messages() ) ) {
				if ( empty( $pass ) ) {
					$password = wp_generate_password(); // Automatically generate a password.
					$user_id  = wp_create_user( $username, $password, $email );
				} else {
					$user_id = wp_create_user( $username, $pass, $email );
				}

				if ( ! is_wp_error( $user_id ) && 'on' !== $enable_verification ) {
					wp_new_user_notification( $user_id, null, 'user' );
					wp_send_json_success( array( 'message' => __( 'Registration successful. Please check your email.', 'loginpress-pro' ) ) );
				} elseif ( ! is_wp_error( $user_id ) && 'on' === $enable_verification ) {
					wp_send_json_success(
						array(
							'message' => __(
								'Registration successful. An email has been sent to the site administrator. The administrator will review the information that has been submitted and either approved or deny your request. You will receive an email with instructions on what you will need to do next. Thanks for your patience.',
								'loginpress-pro'
							),
						)
					);
				} else {
					wp_send_json_error( array( 'message' => __( 'An error occurred during registration. Please try again.', 'loginpress-pro' ) ) );
				}
			} else {
				wp_send_json_error( array( 'message' => __( 'An unknown error occurred. Please try again.', 'loginpress-pro' ) ) );
			}

			wp_die();
		}

		/**
		 * Handles the lost password form submission.
		 *
		 * Verifies the Captcha response (if Captcha is enabled) and then attempts to retrieve user info based on the input.
		 * If a user is found, generates and sends a password reset email to the user.
		 *
		 * @since 4.0.0
		 * @version 6.2.0
		 * @return void|null
		 */
		public function loginpress_widget_lost_password_process() {
			check_ajax_referer( 'loginpress_login_widget_security', 'nonce' );
			$user_login                  = isset( $_POST['user_login'] ) ? sanitize_text_field( wp_unslash( $_POST['user_login'] ) ) : '';
			$captcha_response            = isset( $_POST['captcha_response'] ) ? sanitize_text_field( wp_unslash( $_POST['captcha_response'] ) ) : '';
			$math_captcha_raw            = isset( $_POST['math_captcha'] ) ? sanitize_text_field( wp_unslash( $_POST['math_captcha'] ) ) : '';
			$math_captcha_answer         = ! empty( $math_captcha_raw ) ? intval( $math_captcha_raw ) : '';
			$math_captcha_hash           = isset( $_POST['loginpress_math_captcha_hash'] ) ? sanitize_text_field( wp_unslash( $_POST['loginpress_math_captcha_hash'] ) ) : '';
			$loginpress_captcha_settings = $this->captcha_settings;
			$cap_lost                    = isset( $loginpress_captcha_settings['captcha_enable']['lostpassword_form'] ) ? $loginpress_captcha_settings['captcha_enable']['lostpassword_form'] : false;
			$cap_lost_cf                 = isset( $loginpress_captcha_settings['captcha_enable_cf']['lostpassword_form'] ) ? $loginpress_captcha_settings['captcha_enable_cf']['lostpassword_form'] : false;
			$hcaptcha_lost               = isset( $loginpress_captcha_settings['hcaptcha_enable']['lostpassword_form'] ) ? $loginpress_captcha_settings['hcaptcha_enable']['lostpassword_form'] : 'off';
			$math_lost                   = isset( $loginpress_captcha_settings['math_captcha_enable']['lostpassword_form'] ) ? $loginpress_captcha_settings['math_captcha_enable']['lostpassword_form'] : 'off';
			$captchas_type               = isset( $loginpress_captcha_settings['captchas_type'] ) ? $loginpress_captcha_settings['captchas_type'] : 'type_recaptcha';

			if ( isset( $loginpress_captcha_settings['enable_captchas'] ) && 'on' === $loginpress_captcha_settings['enable_captchas'] ) {
				if ( ( 'off' !== $hcaptcha_lost && 'type_hcaptcha' === $captchas_type ) ||
				( 'off' !== $cap_lost && 'type_recaptcha' === $captchas_type ) ||
				( $cap_lost_cf && 'type_cloudflare' === $captchas_type ) ||
				( 'off' !== $math_lost && 'type_math' === $captchas_type ) ) {
					if ( 'type_math' === $captchas_type && 'off' !== $math_lost ) {
						// Validate math captcha - check if field is empty.
						if ( empty( $math_captcha_raw ) && empty( $math_captcha_hash ) ) {
							wp_send_json_error( array( 'message' => __( 'Please verify Captcha.', 'loginpress-pro' ) ) );
							wp_die();
						}
						// Start session if needed.
						$this->loginpress_start_session();
						$correct_answer = isset( $_SESSION['loginpress_math_widget_lost_captcha'] ) ? $_SESSION['loginpress_math_widget_lost_captcha'] : null; // @codingStandardsIgnoreLine.
						if ( $math_captcha_hash ) {
							$salt = wp_salt();
							if ( md5( $math_captcha_answer . $salt ) !== $math_captcha_hash ) {
								wp_send_json_error( array( 'message' => __( 'Please provide correct Captcha answer', 'loginpress-pro' ) ) );
								wp_die();
							}
						} elseif ( $math_captcha_answer !== $correct_answer ) {
							wp_send_json_error( array( 'message' => __( 'Please provide correct Captcha answer', 'loginpress-pro' ) ) );
							wp_die();
						}
						unset( $_SESSION['loginpress_math_widget_lost_captcha'] ); // @codingStandardsIgnoreLine.
					} elseif ( $captcha_response ) {
						if ( $cap_lost || $cap_lost_cf ) {
							if ( 'type_recaptcha' === $loginpress_captcha_settings['captchas_type'] ) {
								$captcha = new LoginPress_Recaptcha( $this->general_settings, $loginpress_captcha_settings );
								add_filter( 'allow_password_reset', array( $captcha, 'loginpress_recaptcha_lostpassword_auth' ), 10, 2 );
							} elseif ( 'type_hcaptcha' === $loginpress_captcha_settings['captchas_type'] ) {
								$hcaptcha = new LoginPress_Hcaptcha( $loginpress_captcha_settings );
								add_filter( 'allow_password_reset', array( $hcaptcha, 'loginpress_hcaptcha_lostpassword_auth' ), 10, 2 );
							} elseif ( 'type_cloudflare' === $loginpress_captcha_settings['captchas_type'] ) {
								$cf = new LoginPress_Turnstile( $loginpress_captcha_settings );
								add_filter( 'allow_password_reset', array( $cf, 'loginpress_turnstile_auth_widget' ), 10, 4 );
							}
						}
					} else {
						wp_send_json_error( array( 'message' => __( 'Please verify Captcha.', 'loginpress-pro' ) ) );
						wp_die();
					}
				}
			}

			if ( empty( $user_login ) ) {
				wp_send_json_error( array( 'message' => __( 'Username or Email is required', 'loginpress-pro' ) ) );
			}

			// Attempt to retrieve user info based on input.
			$user = get_user_by( 'login', $user_login );
			if ( ! $user ) {
				$user = get_user_by( 'email', $user_login );
			}

			if ( ! $user ) {
				wp_send_json_error( array( 'message' => 'No user found with that username or email' ) );
			}

			// Generate and send the reset password email.
			$reset_email_sent = retrieve_password( $user_login );

			if ( is_wp_error( $reset_email_sent ) ) {
				wp_send_json_error( array( 'message' => $reset_email_sent->get_error_message() ) );
			}

			// Return success response.
			wp_send_json_success( array( 'message' => 'Password reset link has been sent to your email address.' ) );

			wp_die();
		}
	}
}
