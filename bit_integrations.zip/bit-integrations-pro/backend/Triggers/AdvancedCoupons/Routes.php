<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Core\Util\Route;
use BitApps\IntegrationsPro\Triggers\AdvancedCoupons\AdvancedCouponsController;

Route::get('advanced_coupons/get', [AdvancedCouponsController::class, 'getAllTasks']);
