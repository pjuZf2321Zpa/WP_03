<?php

namespace FluentCartPro\App\Hooks\Handlers\BlockEditors\OrderBumpBlocks;

class OrderBumpRemoveButtonBlockEditor extends OrderBumpActionBlockEditor
{
    protected static string $editorName = 'order-bump-remove-button';

    protected function action(): string
    {
        return 'remove';
    }

    protected function defaultLabel(): string
    {
        return __('Remove', 'fluent-cart-pro');
    }

    protected function blockTitle(): string
    {
        return __('Order Bump Remove Button', 'fluent-cart-pro');
    }

    protected function blockDescription(): string
    {
        return __('The button that takes the offer out of the cart.', 'fluent-cart-pro');
    }
}
