<?php

namespace BitApps\AssistPro\Model;

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\Assist\Model\Widget as FreeWidget;

class Widget extends FreeWidget
{
}
