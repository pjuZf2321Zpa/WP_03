<?php

namespace MasterStudy\Lms\Pro\AddonsPlus\Calendar\Routing\Middleware;

use MasterStudy\Lms\Http\WpResponseFactory;
use MasterStudy\Lms\Routing\MiddlewareInterface;

final class Available implements MiddlewareInterface {
	public function process( $request, callable $next ) {
		if ( function_exists( 'masterstudy_lms_calendar_available' ) && masterstudy_lms_calendar_available() ) {
			return $next( $request );
		}

		return WpResponseFactory::forbidden();
	}
}
