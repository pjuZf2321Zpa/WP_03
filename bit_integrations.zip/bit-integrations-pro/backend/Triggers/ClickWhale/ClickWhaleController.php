<?php

namespace BitApps\IntegrationsPro\Triggers\ClickWhale;

use BitApps\IntegrationsPro\Config;

final class ClickWhaleController
{
    public static function info()
    {
        return [
            'name'              => 'ClickWhale',
            'type'              => 'custom_form_submission',
            'is_active'         => static::isPluginInstalled(),
            'documentation_url' => '#',
            'tutorial_url'      => '#',
            'tasks'             => [
                'action' => 'clickwhale/get',
                'method' => 'get',
            ],
            'fetch' => [
                'action' => 'trigger/test',
                'method' => 'post',
            ],
            'fetch_remove' => [
                'action' => 'trigger/test/remove',
                'method' => 'post',
            ],
            'isPro' => true
        ];
    }

    public function getAllTasks()
    {
        if (!static::isPluginInstalled()) {
            wp_send_json_error(\sprintf(__('%s is not installed or activated', 'bit-integrations-pro'), 'ClickWhale'));
        }

        wp_send_json_success(
            [
                ['form_name' => __('Link Clicked', 'bit-integrations-pro'), 'triggered_entity_id' => 'clickwhale/link_clicked', 'skipPrimaryKey' => true],
                ['form_name' => __('Link Created', 'bit-integrations-pro'), 'triggered_entity_id' => 'clickwhale_link_inserted', 'skipPrimaryKey' => true],
                ['form_name' => __('Link Updated', 'bit-integrations-pro'), 'triggered_entity_id' => 'clickwhale_link_updated', 'skipPrimaryKey' => true],
                ['form_name' => __('Link Deleted', 'bit-integrations-pro'), 'triggered_entity_id' => 'clickwhale_link_deleted', 'skipPrimaryKey' => true],
            ]
        );
    }

    /**
     * @param array $link   Link row
     * @param int   $linkId
     * @param int   $userId 0 for a logged-out visitor
     *
     * @return null|array
     */
    public static function handleLinkClicked($link, $linkId = null, $userId = null)
    {
        if (empty($link) || empty($linkId)) {
            return;
        }

        // clickwhale/link_clicked fires on the public redirect, so this runs on every
        // visitor click. Gate before building the payload — getAuthorInfo alone costs
        // two queries that would otherwise be discarded on a site with no flows.
        if (!static::shouldRun('clickwhale/link_clicked')) {
            return;
        }

        $data = array_merge(
            static::flatten((array) $link),
            [
                'link_id' => (int) $linkId,
                'user_id' => (int) $userId,
            ],
            static::prefixKeys(static::getAuthorInfo((int) $linkId), 'author_')
        );

        return static::flowExecute('clickwhale/link_clicked', $data);
    }

    public static function handleLinkCreated($linkId, $linkData = null)
    {
        return static::handleLinkWrite('clickwhale_link_inserted', $linkId, $linkData);
    }

    /**
     * @param int   $linkId
     * @param array $linkData Submitted form data, or just the UTM values during an import
     *
     * @return null|array
     */
    public static function handleLinkUpdated($linkId, $linkData = null)
    {
        return static::handleLinkWrite('clickwhale_link_updated', $linkId, $linkData);
    }

    /**
     * ClickWhale deletes in bulk and passes an array of ids, so the flow runs once
     * per link rather than once per click of Delete.
     *
     * @param array|int $linkIds
     *
     * @return null|array
     */
    public static function handleLinkDeleted($linkIds)
    {
        if (empty($linkIds)) {
            return;
        }

        $executed = 0;

        foreach ((array) $linkIds as $linkId) {
            $result = static::flowExecute(
                'clickwhale_link_deleted',
                [
                    'link_id'    => (int) $linkId,
                    'deleted_at' => current_time('mysql'),
                ]
            );

            if (!empty($result)) {
                ++$executed;
            }
        }

        // Counted rather than overwritten: returning only the last iteration reported
        // nothing whenever the final link happened not to match a flow.
        return $executed > 0 ? ['type' => 'success', 'executed' => $executed] : null;
    }

    /**
     * Shared by the created and updated hooks, which carry the same arguments.
     *
     * @param string $triggeredEntityId
     * @param int    $linkId
     * @param mixed  $linkData
     *
     * @return null|array
     */
    private static function handleLinkWrite($triggeredEntityId, $linkId, $linkData)
    {
        if (empty($linkId)) {
            return;
        }

        $submitted = (array) $linkData;

        // Form plumbing, not link data.
        unset($submitted['action'], $submitted['nonce'], $submitted['submit'], $submitted['_wpnonce'], $submitted['_wp_http_referer']);

        $data = array_merge(
            static::flatten($submitted),
            ['link_id' => (int) $linkId],
            static::prefixKeys(static::getAuthorInfo((int) $linkId), 'author_')
        );

        return static::flowExecute($triggeredEntityId, $data);
    }

    /**
     * Trigger fields are a flat name/value list, so nested values are encoded rather
     * than passed through as arrays.
     *
     * @param array $data
     *
     * @return array
     */
    private static function flatten($data)
    {
        $flat = [];

        foreach ($data as $key => $value) {
            $flat[$key] = \is_scalar($value) || $value === null ? $value : wp_json_encode($value);
        }

        return $flat;
    }

    private static function prefixKeys($data, $prefix)
    {
        $prefixed = [];

        foreach ($data as $key => $value) {
            $prefixed[$prefix . $key] = \is_scalar($value) || $value === null ? $value : wp_json_encode($value);
        }

        return $prefixed;
    }

    /**
     * Look up the WordPress user who owns a link.
     *
     * @param int $linkId
     *
     * @return array
     */
    private static function getAuthorInfo($linkId)
    {
        global $wpdb;

        if (!$wpdb || empty($linkId)) {
            return [];
        }

        $table = \is_callable(['\clickwhale\includes\helpers\Helper', 'get_db_table_name'])
            ? \clickwhale\includes\helpers\Helper::get_db_table_name('links')
            : $wpdb->prefix . 'clickwhale_links';

        // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery -- table name comes from ClickWhale's own accessor
        $authorId = $wpdb->get_var($wpdb->prepare("SELECT author FROM {$table} WHERE id = %d", $linkId));

        if (empty($authorId)) {
            return [];
        }

        $user = get_user_by('id', (int) $authorId);

        if (!$user) {
            return ['id' => (int) $authorId];
        }

        return [
            'id'           => (int) $user->ID,
            'email'        => $user->user_email,
            'login'        => $user->user_login,
            'display_name' => $user->display_name,
            'first_name'   => $user->first_name,
            'last_name'    => $user->last_name,
        ];
    }

    /**
     * Cheap gate before any payload work.
     *
     * Returns true when a flow is listening, or when the flow builder is waiting on
     * a sample for this trigger — the second case is why flowExecute cannot simply
     * check Flow::exists() and bail, since the fetch button needs a payload even
     * before a flow is saved.
     *
     * @param string $triggered_entity_id
     *
     * @return bool
     */
    private static function shouldRun($triggered_entity_id)
    {
        $flowClass = bit_integrations_get_class('Flow\\Flow');

        if (!empty($flowClass::exists('ClickWhale', $triggered_entity_id))) {
            return true;
        }

        return get_option(Config::withFreePrefix("{$triggered_entity_id}_test")) !== false;
    }

    private static function flowExecute($triggered_entity_id, $formData)
    {
        $helperClass = bit_integrations_get_class('Core\\Util\\Helper');
        $flowClass = bit_integrations_get_class('Flow\\Flow');

        $formData = $helperClass::prepareFetchFormatFields($formData);

        if (empty($formData) || !\is_array($formData)) {
            return;
        }

        $helperClass::setTestData(Config::withFreePrefix("{$triggered_entity_id}_test"), array_values($formData));

        $flows = $flowClass::exists('ClickWhale', $triggered_entity_id);

        if (empty($flows)) {
            return;
        }

        $flowClass::execute('ClickWhale', $triggered_entity_id, array_column($formData, 'value', 'name'), $flows);

        return ['type' => 'success'];
    }

    private static function isPluginInstalled()
    {
        return \defined('CLICKWHALE_VERSION');
    }
}
