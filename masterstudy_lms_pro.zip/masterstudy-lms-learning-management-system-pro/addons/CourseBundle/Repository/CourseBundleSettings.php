<?php

namespace MasterStudy\Lms\Pro\addons\CourseBundle\Repository;

class CourseBundleSettings {
	const OPTION_NAME = 'stm_lms_course_bundle_settings';

	private array $settings;

	public function __construct() {
		$this->settings = get_option( self::OPTION_NAME, array() );
	}

	public function get_bundles_limit(): int {
		return $this->get_positive_int_setting( 'bundle_limit', 6 );
	}

	public function get_bundle_courses_limit(): int {
		return $this->get_positive_int_setting( 'bundle_courses_limit', 5 );
	}

	private function get_positive_int_setting( string $key, int $default ): int {
		$value = intval( $this->settings[ $key ] ?? $default );

		return $value > 0 ? $value : $default;
	}
}
