<?php

namespace WPAICG\Lib\Usage;

use WPAICG\AIPKit_Role_Manager;
use WPAICG\Chat\Storage\LogCronManager;
use WPAICG\Chat\Storage\LogStorage;
use WPAICG\Chat\Utils\LogConfig;

if (!defined('ABSPATH')) {
    exit;
}

/** Paid log retention: saved settings, cleanup status and the deletion preview shown before saving. */
class AIPKit_Log_Retention_Ajax_Handler
{
    /**
     * @return array{enabled:bool,days:int,state:string,status_text:string,last_run_label:string}
     */
    public static function status(bool $repair_schedule = false): array
    {
        $settings = LogConfig::get_log_settings();
        $enabled = !empty($settings['enable_pruning']);
        $next = wp_next_scheduled(LogCronManager::HOOK_NAME);

        // A missing event while cleanup is on is repaired so the status never contradicts the setting.
        if ($repair_schedule && $enabled && $next === false) {
            LogCronManager::schedule_event();
            $next = wp_next_scheduled(LogCronManager::HOOK_NAME);
        }

        $state = 'disabled';
        $status_text = __('Off. Logs stay until you delete them.', 'gpt3-ai-content-generator');
        if ($enabled && $next !== false) {
            $state = 'scheduled';
            $status_text = (int) $next <= time()
                ? __('Next cleanup is due', 'gpt3-ai-content-generator')
                /* translators: %s: time until the next cleanup, such as "6 hours". */
                : sprintf(__('Next cleanup in %s', 'gpt3-ai-content-generator'), human_time_diff(time(), (int) $next));
        } elseif ($enabled) {
            $state = 'pending';
            $status_text = __('Scheduling the next cleanup…', 'gpt3-ai-content-generator');
        }

        $last_run = (string) get_option('aipkit_log_pruning_last_run', '');
        $last_run_label = $last_run !== ''
            /* translators: %s: date and time of the last cleanup. */
            ? sprintf(__('Last run %s', 'gpt3-ai-content-generator'), wp_date(get_option('date_format') . ' ' . get_option('time_format'), strtotime($last_run . ' UTC')))
            : __('No cleanup has run yet', 'gpt3-ai-content-generator');

        return [
            'enabled' => $enabled,
            'days' => (int) ($settings['retention_period_days'] ?? 90),
            'state' => $state,
            'status_text' => $status_text,
            'last_run_label' => $last_run_label,
        ];
    }

    public function ajax_get_status(): void
    {
        if ($this->verify()) {
            wp_send_json_success(self::status(true));
        }
    }

    /** Counts the logs the next cleanup would delete for a period, before the owner saves it. */
    public function ajax_preview(): void
    {
        if (!$this->verify()) {
            return;
        }
        $days = $this->posted_days();
        if ($days === null) {
            return;
        }
        $cutoff = time() - $days * DAY_IN_SECONDS;
        // Cleanup deletes rows whose last message is older than the cutoff; count the same rows.
        $count = (new LogStorage())->count_logs(['start_ts' => 1, 'end_ts' => $cutoff - 1]);

        wp_send_json_success([
            'count' => $count,
            'cutoff_label' => wp_date(get_option('date_format'), $cutoff),
        ]);
    }

    public function ajax_save(): void
    {
        if (!$this->verify()) {
            return;
        }
        $days = $this->posted_days();
        if ($days === null) {
            return;
        }
        // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce is checked in verify().
        $enabled = isset($_POST['enable_pruning']) && sanitize_key(wp_unslash($_POST['enable_pruning'])) === '1';
        update_option('aipkit_log_settings', [
            'enable_pruning' => $enabled,
            'retention_period_days' => $days,
        ], 'no');
        if ($enabled) {
            LogCronManager::schedule_event();
        } else {
            LogCronManager::unschedule_event();
        }

        wp_send_json_success(self::status() + [
            'message' => __('Log retention saved.', 'gpt3-ai-content-generator'),
        ]);
    }

    private function verify(): bool
    {
        if (!check_ajax_referer('aipkit_nonce', '_ajax_nonce', false)) {
            wp_send_json_error(['message' => __('Security check failed (nonce).', 'gpt3-ai-content-generator'), 'code' => 'nonce_failure'], 403);
            return false;
        }
        if (!class_exists(AIPKit_Role_Manager::class) || !AIPKit_Role_Manager::user_can_access_module('stats')) {
            wp_send_json_error(['message' => __('You do not have permission to perform this action.', 'gpt3-ai-content-generator'), 'code' => 'permission_denied'], 403);
            return false;
        }
        if (!class_exists('\\WPAICG\\aipkit_dashboard') || !\WPAICG\aipkit_dashboard::is_pro_plan()) {
            wp_send_json_error(['message' => __('Automatic log cleanup is a Pro feature.', 'gpt3-ai-content-generator'), 'code' => 'pro_required'], 403);
            return false;
        }
        return true;
    }

    private function posted_days(): ?int
    {
        // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce is checked in verify().
        $days = isset($_POST['retention_period_days']) ? absint(wp_unslash($_POST['retention_period_days'])) : 0;
        // Only the offered choices: LogConfig::is_valid_period() accepts any number from 1 to 365.
        if (!array_key_exists($days, LogConfig::get_retention_periods())) {
            wp_send_json_error(['message' => __('Choose how long to keep logs.', 'gpt3-ai-content-generator'), 'code' => 'invalid_retention_period'], 400);
            return null;
        }
        return $days;
    }
}
