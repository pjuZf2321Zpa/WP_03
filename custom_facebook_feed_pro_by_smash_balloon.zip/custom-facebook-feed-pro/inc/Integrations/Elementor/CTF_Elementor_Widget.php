<?php

namespace CustomFacebookFeed\Integrations\Elementor;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use CustomFacebookFeed\Builder\CFF_Db;

if (!defined('ABSPATH')) {
	exit; // Exit if accessed directly
}

class CTF_Elementor_Widget extends Widget_Base
{
	public function get_name()
	{
		return 'ctf-widget';
	}
	public function get_title()
	{
		return esc_html__('Twitter Feed', 'custom-facebook-feed');
	}
	public function get_icon()
	{
		return 'sb-elem-icon sb-elem-inactive sb-elem-twitter';
	}
	public function get_categories()
	{
		return array('smash-balloon');
	}
	public function show_in_panel()
	{
		return false;
	}
	public function hide_on_search()
	{
		return true;
	}
	public function get_script_depends()
	{
		return [
			'elementor-handler'
		];
	}
}
