<?php

namespace BitApps\IntegrationsPro\Actions\WpErp;

class WpErpProHelper
{
    private static $functionAvailability = [];

    private static $classAvailability = [];

    public static function createContact($defaultResponse, $fieldData, $utilities = [])
    {
        if (!self::isErpActive()) {
            return self::errorResponse(__('WP ERP is not installed or activated', 'bit-integrations-pro'));
        }

        if (!self::isFunctionAvailable('erp_insert_people')) {
            return self::errorResponse(__('Required WP ERP function erp_insert_people is not available', 'bit-integrations-pro'));
        }

        if (empty($fieldData['first_name']) || empty($fieldData['email'])) {
            return self::errorResponse(__('First name and email are required to create a contact', 'bit-integrations-pro'));
        }

        $fieldData['type'] = 'contact';
        $lifeStage = self::utility($utilities, 'lifeStage');

        if (!empty($lifeStage)) {
            $fieldData['life_stage'] = $lifeStage;
        }

        $result = erp_insert_people($fieldData);

        if (is_wp_error($result)) {
            return self::errorResponse($result->get_error_message());
        }

        $contactId = self::resultId($result);

        $groupIds = self::utility($utilities, 'groupId');
        if (!empty($groupIds) && !empty($contactId) && self::isFunctionAvailable('erp_crm_create_new_contact_subscriber')) {
            foreach ((array) $groupIds as $groupId) {
                if (empty($groupId)) {
                    continue;
                }

                erp_crm_create_new_contact_subscriber(['group_id' => $groupId, 'user_id' => $contactId]);
            }
        }

        return self::successResponse(__('Contact created successfully', 'bit-integrations-pro'), self::fetchPeople($contactId));
    }

    public static function updateContact($defaultResponse, $fieldData, $utilities = [])
    {
        if (!self::isErpActive() || !self::isFunctionAvailable('erp_insert_people')) {
            return self::errorResponse(__('WP ERP is not installed or activated', 'bit-integrations-pro'));
        }

        if (empty($fieldData['id'])) {
            return self::errorResponse(__('Contact id is required to update a contact', 'bit-integrations-pro'));
        }

        $fieldData['type'] = 'contact';
        $lifeStage = self::utility($utilities, 'lifeStage');
        if (!empty($lifeStage)) {
            $fieldData['life_stage'] = $lifeStage;
        }

        $result = erp_insert_people($fieldData);

        if (is_wp_error($result)) {
            return self::errorResponse($result->get_error_message());
        }

        $id = self::resultId($result);

        return self::successResponse(__('Contact updated successfully', 'bit-integrations-pro'), self::fetchPeople($id));
    }

    public static function createCompany($defaultResponse, $fieldData)
    {
        if (!self::isErpActive() || !self::isFunctionAvailable('erp_insert_people')) {
            return self::errorResponse(__('WP ERP is not installed or activated', 'bit-integrations-pro'));
        }

        if (empty($fieldData['company']) || empty($fieldData['email'])) {
            return self::errorResponse(__('Company name and email are required', 'bit-integrations-pro'));
        }

        $fieldData['type'] = 'company';
        $result = erp_insert_people($fieldData);

        if (is_wp_error($result)) {
            return self::errorResponse($result->get_error_message());
        }

        $id = self::resultId($result);

        return self::successResponse(__('Company created successfully', 'bit-integrations-pro'), self::fetchPeople($id));
    }

    public static function updateCompany($defaultResponse, $fieldData, $utilities = [])
    {
        if (!self::isErpActive() || !self::isFunctionAvailable('erp_insert_people')) {
            return self::errorResponse(__('WP ERP is not installed or activated', 'bit-integrations-pro'));
        }

        if (empty($fieldData['id'])) {
            return self::errorResponse(__('Company id is required to update a company', 'bit-integrations-pro'));
        }

        $payload = $fieldData;
        $payload['id'] = $fieldData['id'];
        $payload['type'] = 'company';

        $result = erp_insert_people($payload);

        if (is_wp_error($result)) {
            return self::errorResponse($result->get_error_message());
        }

        $id = self::resultId($result);

        return self::successResponse(__('Company updated successfully', 'bit-integrations-pro'), self::fetchPeople($id));
    }

    public static function createContactGroup($defaultResponse, $fieldData)
    {
        if (!self::isCrmActive() || !self::isFunctionAvailable('erp_crm_save_contact_group')) {
            return self::errorResponse(__('WP ERP CRM module is not available', 'bit-integrations-pro'));
        }

        if (empty($fieldData['name'])) {
            return self::errorResponse(__('Group name is required', 'bit-integrations-pro'));
        }

        $result = erp_crm_save_contact_group($fieldData);

        return self::successResponse(__('Contact group created successfully', 'bit-integrations-pro'), self::normalize($result));
    }

    public static function addContactToGroup($defaultResponse, $fieldData, $utilities = [])
    {
        if (!self::isCrmActive() || !self::isFunctionAvailable('erp_crm_create_new_contact_subscriber')) {
            return self::errorResponse(__('WP ERP CRM module is not available', 'bit-integrations-pro'));
        }

        $contactId = $fieldData['contact_id'] ?? null;
        $groupIds = self::utility($utilities, 'groupId');

        if (empty($contactId) || empty($groupIds)) {
            return self::errorResponse(__('Contact id and group id are required', 'bit-integrations-pro'));
        }

        $results = [];
        foreach ((array) $groupIds as $groupId) {
            $result = erp_crm_create_new_contact_subscriber(['group_id' => $groupId, 'user_id' => $contactId]);

            if (is_wp_error($result)) {
                $results[] = ['group_id' => $groupId, 'error' => $result->get_error_message()];

                continue;
            }

            $results[] = self::normalize($result);
        }

        return self::successResponse(__('Contact added to group(s)', 'bit-integrations-pro'), $results);
    }

    public static function removeContactFromGroup($defaultResponse, $fieldData, $utilities = [])
    {
        if (!self::isCrmActive()) {
            return self::errorResponse(__('WP ERP CRM module is not available', 'bit-integrations-pro'));
        }

        $contactId = $fieldData['contact_id'] ?? null;
        $groupIds = self::utility($utilities, 'groupId');

        if (empty($contactId) || empty($groupIds)) {
            return self::errorResponse(__('Contact id and group id are required', 'bit-integrations-pro'));
        }

        global $wpdb;

        $results = [];
        foreach ((array) $groupIds as $groupId) {
            $deleted = $wpdb->delete(
                $wpdb->prefix . 'erp_crm_contact_subscriber',
                ['user_id' => $contactId, 'group_id' => $groupId],
                ['%d', '%d']
            );

            if ($deleted) {
                do_action('erp_crm_delete_contact_subscriber', $contactId, $groupId);
            }

            $results[] = ['group_id' => $groupId, 'removed' => (bool) $deleted];
        }

        return self::successResponse(__('Contact removed from group(s)', 'bit-integrations-pro'), $results);
    }

    public static function addNote($defaultResponse, $fieldData)
    {
        if (!self::isCrmActive() || !self::isFunctionAvailable('erp_crm_save_customer_feed_data')) {
            return self::errorResponse(__('WP ERP CRM module is not available', 'bit-integrations-pro'));
        }

        if (empty($fieldData['user_id']) || empty($fieldData['message'])) {
            return self::errorResponse(__('User id and message are required', 'bit-integrations-pro'));
        }

        $result = erp_crm_save_customer_feed_data([
            'user_id'    => $fieldData['user_id'],
            'created_by' => get_current_user_id(),
            'message'    => $fieldData['message'],
            'type'       => 'log_activity',
            'log_type'   => 'note',
            'start_date' => current_time('mysql'),
        ]);

        return self::successResponse(__('Note added successfully', 'bit-integrations-pro'), (array) $result);
    }

    public static function createTask($defaultResponse, $fieldData, $utilities = [])
    {
        if (!self::isCrmActive() || !self::isFunctionAvailable('erp_crm_save_customer_feed_data')) {
            return self::errorResponse(__('WP ERP CRM module is not available', 'bit-integrations-pro'));
        }

        if (empty($fieldData['title']) || empty($fieldData['contact_id'])) {
            return self::errorResponse(__('Title and contact id are required', 'bit-integrations-pro'));
        }

        $defaultTime = current_time('mysql');
        $currentUserId = get_current_user_id();
        $assignedTo = $fieldData['assigned_to'] ?? $currentUserId;

        $result = erp_crm_save_customer_feed_data([
            'user_id'    => $fieldData['contact_id'],
            'created_by' => $currentUserId,
            'message'    => $fieldData['title'] . (!empty($fieldData['message']) ? "\n" . $fieldData['message'] : ''),
            'type'       => 'tasks',
            'log_type'   => '',
            'start_date' => !empty($fieldData['start_date']) ? $fieldData['start_date'] : $defaultTime,
            'end_date'   => !empty($fieldData['end_date']) ? $fieldData['end_date'] : $defaultTime,
            'extra'      => base64_encode(wp_json_encode(['invite_contact' => [$assignedTo]])),
        ]);

        return self::successResponse(__('Task created successfully', 'bit-integrations-pro'), self::normalize($result));
    }

    public static function createDepartment($defaultResponse, $fieldData)
    {
        if (!self::isErpActive() || !self::isFunctionAvailable('erp_hr_create_department')) {
            return self::errorResponse(__('WP ERP HRM module is not available', 'bit-integrations-pro'));
        }

        if (empty($fieldData['title'])) {
            return self::errorResponse(__('Department title is required', 'bit-integrations-pro'));
        }

        if (empty($fieldData['lead'])) {
            $fieldData['lead'] = 0;
        }
        if (empty($fieldData['parent'])) {
            $fieldData['parent'] = 0;
        }

        $departmentId = erp_hr_create_department($fieldData);

        if (is_wp_error($departmentId)) {
            return self::errorResponse($departmentId->get_error_message());
        }

        return self::successResponse(__('Department created successfully', 'bit-integrations-pro'), ['department_id' => $departmentId]);
    }

    public static function createDesignation($defaultResponse, $fieldData)
    {
        if (!self::isErpActive() || !self::isFunctionAvailable('erp_hr_create_designation')) {
            return self::errorResponse(__('WP ERP HRM module is not available', 'bit-integrations-pro'));
        }

        if (empty($fieldData['title'])) {
            return self::errorResponse(__('Designation title is required', 'bit-integrations-pro'));
        }

        $designationId = erp_hr_create_designation($fieldData);

        if (is_wp_error($designationId)) {
            return self::errorResponse($designationId->get_error_message());
        }

        return self::successResponse(__('Designation created successfully', 'bit-integrations-pro'), ['designation_id' => $designationId]);
    }

    public static function createHoliday($defaultResponse, $fieldData)
    {
        if (!self::isErpActive() || !self::isFunctionAvailable('erp_hr_leave_insert_holiday')) {
            return self::errorResponse(__('WP ERP HRM module is not available', 'bit-integrations-pro'));
        }

        if (empty($fieldData['title']) || empty($fieldData['start']) || empty($fieldData['end'])) {
            return self::errorResponse(__('Title, start and end are required', 'bit-integrations-pro'));
        }

        $holidayId = erp_hr_leave_insert_holiday($fieldData);

        if (is_wp_error($holidayId)) {
            return self::errorResponse($holidayId->get_error_message());
        }

        return self::successResponse(__('Holiday created successfully', 'bit-integrations-pro'), ['holiday_id' => $holidayId]);
    }

    public static function createExpense($defaultResponse, $fieldData)
    {
        if (!self::isFunctionAvailable('erp_acct_insert_expense')) {
            return self::errorResponse(__('WP ERP Accounting module is not available', 'bit-integrations-pro'));
        }

        if (!isset($fieldData['amount']) || !is_numeric($fieldData['amount'])) {
            return self::errorResponse(__('A numeric amount is required', 'bit-integrations-pro'));
        }

        $currentTime = current_time('mysql');

        $payload = [
            'people_id'        => $fieldData['people_id'] ?? 0,
            'voucher_date'     => !empty($fieldData['voucher_date']) ? $fieldData['voucher_date'] : $currentTime,
            'trn_date'         => !empty($fieldData['trn_date']) ? $fieldData['trn_date'] : $currentTime,
            'amount'           => $fieldData['amount'] ?? 0,
            'ref'              => $fieldData['ref'] ?? '',
            'check_no'         => $fieldData['check_no'] ?? '',
            'name'             => $fieldData['name'] ?? '',
            'particulars'      => $fieldData['particulars'] ?? '',
            'status'           => $fieldData['status'] ?? 1,
            'trn_by'           => $fieldData['trn_by'] ?? 1,
            'trn_by_ledger_id' => $fieldData['ledger_id'] ?? 0,
            'attachments'      => '',
            'billing_address'  => '',
            'bill_details'     => [],
        ];

        $result = erp_acct_insert_expense($payload);

        if (is_wp_error($result)) {
            return self::errorResponse($result->get_error_message());
        }

        return self::successResponse(__('Expense created successfully', 'bit-integrations-pro'), \is_array($result) ? $result : ['id' => $result]);
    }

    public static function createPayment($defaultResponse, $fieldData)
    {
        if (!self::isFunctionAvailable('erp_acct_insert_payment')) {
            return self::errorResponse(__('WP ERP Accounting module is not available', 'bit-integrations-pro'));
        }

        if (!isset($fieldData['amount']) || !is_numeric($fieldData['amount'])) {
            return self::errorResponse(__('A numeric amount is required', 'bit-integrations-pro'));
        }

        $currentTime = current_time('mysql');

        $payload = [
            'customer_id'         => $fieldData['customer_id'] ?? 0,
            'trn_date'            => !empty($fieldData['trn_date']) ? $fieldData['trn_date'] : $currentTime,
            'amount'              => $fieldData['amount'] ?? 0,
            'particulars'         => $fieldData['particulars'] ?? '',
            'ref'                 => $fieldData['ref'] ?? '',
            'deposit_to'          => $fieldData['deposit_to'] ?? 0,
            'status'              => $fieldData['status'] ?? 1,
            'trn_by'              => $fieldData['trn_by'] ?? 1,
            'attachments'         => '',
            'invoice_no'          => '',
            'bill_details'        => [],
            'pay_invoice_details' => [],
            'particulars_items'   => [],
        ];

        $result = erp_acct_insert_payment($payload);

        if (is_wp_error($result)) {
            return self::errorResponse($result->get_error_message());
        }

        return self::successResponse(__('Payment created successfully', 'bit-integrations-pro'), \is_array($result) ? $result : ['id' => $result]);
    }

    private static function isErpActive()
    {
        return self::isFunctionAvailable('erp_insert_people');
    }

    private static function isCrmActive()
    {
        return self::isFunctionAvailable('erp_crm_get_contact_groups') || self::isClassAvailable('\WeDevs\ERP\CRM\Models\ContactGroup');
    }

    private static function isFunctionAvailable($functionName)
    {
        if (!isset(self::$functionAvailability[$functionName])) {
            self::$functionAvailability[$functionName] = \function_exists($functionName);
        }

        return self::$functionAvailability[$functionName];
    }

    private static function isClassAvailable($className)
    {
        if (!isset(self::$classAvailability[$className])) {
            self::$classAvailability[$className] = class_exists($className);
        }

        return self::$classAvailability[$className];
    }

    private static function errorResponse($message)
    {
        return ['success' => false, 'message' => $message];
    }

    private static function successResponse($message, $data = [])
    {
        return ['success' => true, 'message' => $message, 'data' => $data];
    }

    private static function normalize($data)
    {
        if (empty($data)) {
            return [];
        }

        if (\is_object($data) && method_exists($data, 'toArray')) {
            return $data->toArray();
        }

        if (\is_object($data) && method_exists($data, 'to_array')) {
            return $data->to_array();
        }

        return (array) $data;
    }

    private static function utility($utilities, $key, $default = null)
    {
        if (\is_object($utilities)) {
            return $utilities->{$key} ?? $default;
        }

        if (\is_array($utilities)) {
            return $utilities[$key] ?? $default;
        }

        return $default;
    }

    private static function resultId($result)
    {
        return \is_object($result) ? ($result->id ?? null) : $result;
    }

    private static function fetchPeople($id)
    {
        if (empty($id) || !self::isFunctionAvailable('erp_get_people_by')) {
            return [];
        }

        return self::normalize(erp_get_people_by('id', $id));
    }
}
