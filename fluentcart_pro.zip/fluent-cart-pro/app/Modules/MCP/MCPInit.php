<?php

namespace FluentCartPro\App\Modules\MCP;

use FluentCart\Api\ModuleSettings;

/**
 * Bootstrap for FluentCart Pro's MCP additions.
 *
 * Wires the FluentHub auto-installer (so the "Install FluentHub" button in
 * FluentCart free can install the MCP adapter in one click when Pro is active)
 * and, when a Pro module that exposes MCP tools is enabled, pushes those tools
 * onto the free `fluent-cart` server via the documented extension seam:
 *   - `fluent_cart/mcp_loaded`        → register the abilities
 *   - `fluent_cart/mcp_ability_names` → expose them on the server
 *
 * Registration is gated per Pro module, so a site without Licensing pays no
 * cost and the agent never sees license tools it cannot use.
 */
class MCPInit
{
    public function init()
    {
        (new ToolkitInstaller())->init();

        $this->registerProAbilities();
    }

    /**
     * Hook Pro tool registration into the free MCP lifecycle. Only the tools
     * whose backing module is active are wired in.
     */
    private function registerProAbilities()
    {
        // License tools require the Licensing module to be enabled.
        if (!ModuleSettings::isActive('license')) {
            return;
        }

        add_action('fluent_cart/mcp_loaded', function () {
            AbilitiesRegistrar::register();
        });

        add_filter('fluent_cart/mcp_ability_names', function ($names) {
            return array_merge((array) $names, array_keys(AbilitiesRegistrar::getDefinitions()));
        });
    }
}
