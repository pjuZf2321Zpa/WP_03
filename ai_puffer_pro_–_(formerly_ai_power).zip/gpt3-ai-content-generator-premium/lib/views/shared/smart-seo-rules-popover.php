<?php
/**
 * Shared Smart SEO approach modal.
 *
 * Expected variables:
 * - $aipkit_smart_seo_rules_popover_id
 * - $aipkit_smart_seo_rules_profile_key
 * - $aipkit_smart_seo_rules_profile_label
 * - $aipkit_smart_seo_rules_profile_logo_url
 * - $aipkit_smart_seo_rules_profile_logo_initials
 */

if (!defined('ABSPATH')) {
    exit;
}

$aipkit_smart_seo_rules_popover_id = isset($aipkit_smart_seo_rules_popover_id) ? (string) $aipkit_smart_seo_rules_popover_id : '';
$aipkit_smart_seo_rules_profile_key = isset($aipkit_smart_seo_rules_profile_key) ? sanitize_key((string) $aipkit_smart_seo_rules_profile_key) : 'aipkit';
$aipkit_smart_seo_rules_profile_label = isset($aipkit_smart_seo_rules_profile_label) ? (string) $aipkit_smart_seo_rules_profile_label : __('AIPKit SEO', 'gpt3-ai-content-generator');
$aipkit_smart_seo_rules_profile_logo_url = isset($aipkit_smart_seo_rules_profile_logo_url) ? (string) $aipkit_smart_seo_rules_profile_logo_url : '';
$aipkit_smart_seo_rules_profile_logo_initials = isset($aipkit_smart_seo_rules_profile_logo_initials) ? (string) $aipkit_smart_seo_rules_profile_logo_initials : 'AI';
$aipkit_smart_seo_rules_title_id = $aipkit_smart_seo_rules_popover_id . '_title';
$aipkit_smart_seo_rules_description_id = $aipkit_smart_seo_rules_popover_id . '_description';
$aipkit_smart_seo_rules_class = '\\WPAICG\\ContentWriter\\SEO\\AIPKit_Content_Writer_Smart_SEO_Rules';
$aipkit_smart_seo_rule_groups = class_exists($aipkit_smart_seo_rules_class)
    ? $aipkit_smart_seo_rules_class::grouped_rule_catalog()
    : [];
$aipkit_smart_seo_rule_presets = class_exists($aipkit_smart_seo_rules_class)
    ? $aipkit_smart_seo_rules_class::rule_presets()
    : [];
$aipkit_smart_seo_groups_to_render = ['shared'];
if (in_array($aipkit_smart_seo_rules_profile_key, ['yoast', 'rank_math', 'aioseo'], true)) {
    $aipkit_smart_seo_groups_to_render[] = $aipkit_smart_seo_rules_profile_key;
}

$aipkit_smart_seo_rules_to_render = [];
foreach ($aipkit_smart_seo_groups_to_render as $aipkit_smart_seo_group_key) {
    foreach (($aipkit_smart_seo_rule_groups[$aipkit_smart_seo_group_key] ?? []) as $aipkit_smart_seo_rule) {
        $aipkit_smart_seo_rules_to_render[] = $aipkit_smart_seo_rule;
    }
}
/* translators: %s: base Smart SEO preset name. */
$aipkit_smart_seo_note_template = __('Based on %s', 'gpt3-ai-content-generator');
/* translators: 1: enabled SEO check count, 2: total SEO check count. */
$aipkit_smart_seo_summary_template = __('%1$d of %2$d on', 'gpt3-ai-content-generator');
?>

<?php if ($aipkit_smart_seo_rules_popover_id !== '' && !empty($aipkit_smart_seo_rules_to_render)) : ?>
    <div
        class="aipkit-modal-overlay aipkit_smart_seo_rules_modal"
        id="<?php echo esc_attr($aipkit_smart_seo_rules_popover_id); ?>"
        aria-hidden="true"
        data-aipkit-smart-seo-modal
    >
        <div
            class="aipkit-modal-content aipkit-modal-shell aipkit_smart_seo_rules_modal_panel"
            role="dialog"
            aria-modal="true"
            aria-labelledby="<?php echo esc_attr($aipkit_smart_seo_rules_title_id); ?>"
            aria-describedby="<?php echo esc_attr($aipkit_smart_seo_rules_description_id); ?>"
        >
            <div class="aipkit-modal-header aipkit-modal-shell-header aipkit_smart_seo_rules_modal_header">
                <div class="aipkit-modal-shell-intro">
                    <h2 class="aipkit-modal-shell-title" id="<?php echo esc_attr($aipkit_smart_seo_rules_title_id); ?>">
                        <?php esc_html_e('SEO approach', 'gpt3-ai-content-generator'); ?>
                    </h2>
                    <p class="aipkit-modal-shell-copy" id="<?php echo esc_attr($aipkit_smart_seo_rules_description_id); ?>">
                        <?php esc_html_e('Choose how closely each post should follow your SEO checks.', 'gpt3-ai-content-generator'); ?>
                    </p>
                </div>
                <button
                    type="button"
                    class="aipkit-modal-close-btn aipkit-modal-shell-close aipkit_smart_seo_rules_modal_close"
                    data-aipkit-smart-seo-modal-cancel
                    aria-label="<?php esc_attr_e('Close', 'gpt3-ai-content-generator'); ?>"
                >
                    <span class="dashicons dashicons-no-alt" aria-hidden="true"></span>
                </button>
            </div>
            <div
                class="aipkit-modal-body aipkit-modal-shell-body aipkit_smart_seo_rules_modal_body"
                data-aipkit-smart-seo-rules
                data-aipkit-smart-seo-active-profile="<?php echo esc_attr($aipkit_smart_seo_rules_profile_key); ?>"
                data-aipkit-smart-seo-staged="1"
            >
                <div class="aipkit_smart_seo_rules_intro">
                    <span class="aipkit_smart_seo_rules_profile">
                        <span
                            class="aipkit_smart_seo_rules_profile_logo"
                            data-aipkit-seo-profile="<?php echo esc_attr($aipkit_smart_seo_rules_profile_key); ?>"
                            aria-hidden="true"
                        >
                            <?php if ($aipkit_smart_seo_rules_profile_logo_url !== '') : ?>
                                <img src="<?php echo esc_url($aipkit_smart_seo_rules_profile_logo_url); ?>" alt="">
                            <?php else : ?>
                                <span><?php echo esc_html($aipkit_smart_seo_rules_profile_logo_initials); ?></span>
                            <?php endif; ?>
                        </span>
                        <?php
                        printf(
                            /* translators: %s: active SEO plugin name. */
                            esc_html__('Optimizing for %s', 'gpt3-ai-content-generator'),
                            esc_html($aipkit_smart_seo_rules_profile_label)
                        );
                        ?>
                    </span>
                </div>

                <?php if (!empty($aipkit_smart_seo_rule_presets)) : ?>
                    <div class="aipkit_smart_seo_presets" data-aipkit-smart-seo-presets>
                        <div class="aipkit_smart_seo_presets_header">
                            <span class="aipkit_smart_seo_presets_label"><?php esc_html_e('Choose an approach', 'gpt3-ai-content-generator'); ?></span>
                        </div>
                        <div class="aipkit_smart_seo_presets_buttons" role="radiogroup" aria-label="<?php esc_attr_e('Smart SEO rule presets', 'gpt3-ai-content-generator'); ?>">
                            <?php foreach ($aipkit_smart_seo_rule_presets as $aipkit_smart_seo_preset_key => $aipkit_smart_seo_preset) : ?>
                                <?php
                                $aipkit_smart_seo_preset_key = sanitize_key((string) $aipkit_smart_seo_preset_key);
                                if ($aipkit_smart_seo_preset_key === '') {
                                    continue;
                                }
                                $aipkit_smart_seo_preset_label = (string) ($aipkit_smart_seo_preset['label'] ?? $aipkit_smart_seo_preset_key);
                                $aipkit_smart_seo_preset_description = (string) ($aipkit_smart_seo_preset['description'] ?? '');
                                $aipkit_smart_seo_preset_disabled_rules = array_values(array_filter(array_map(
                                    static fn($rule_id): string => sanitize_key((string) $rule_id),
                                    (array) ($aipkit_smart_seo_preset['disabled_rules'] ?? [])
                                )));
                                $aipkit_smart_seo_preset_disabled_json = wp_json_encode($aipkit_smart_seo_preset_disabled_rules);
                                ?>
                                <button
                                    type="button"
                                    class="aipkit_smart_seo_preset_option aipkit_smart_seo_preset_btn"
                                    data-aipkit-smart-seo-preset
                                    data-aipkit-smart-seo-preset-key="<?php echo esc_attr($aipkit_smart_seo_preset_key); ?>"
                                    data-aipkit-smart-seo-preset-label="<?php echo esc_attr($aipkit_smart_seo_preset_label); ?>"
                                    data-aipkit-smart-seo-preset-disabled-rules="<?php echo esc_attr(is_string($aipkit_smart_seo_preset_disabled_json) ? $aipkit_smart_seo_preset_disabled_json : '[]'); ?>"
                                    role="radio"
                                    aria-checked="false"
                                >
                                    <span class="aipkit_smart_seo_preset_indicator" aria-hidden="true"></span>
                                    <span class="aipkit_smart_seo_preset_copy">
                                        <span class="aipkit_smart_seo_preset_name_line">
                                            <span class="aipkit_smart_seo_preset_name"><?php echo esc_html($aipkit_smart_seo_preset_label); ?></span>
                                            <?php if ($aipkit_smart_seo_preset_key === 'balanced') : ?>
                                                <span class="aipkit_smart_seo_recommended_badge"><?php esc_html_e('Recommended', 'gpt3-ai-content-generator'); ?></span>
                                            <?php endif; ?>
                                        </span>
                                        <?php if ($aipkit_smart_seo_preset_description !== '') : ?>
                                            <span class="aipkit_smart_seo_preset_description"><?php echo esc_html($aipkit_smart_seo_preset_description); ?></span>
                                        <?php endif; ?>
                                    </span>
                                </button>
                            <?php endforeach; ?>

                            <div
                                class="aipkit_smart_seo_preset_option aipkit_smart_seo_custom_preset"
                                data-aipkit-smart-seo-custom-preset
                                data-aipkit-smart-seo-preset-label="<?php esc_attr_e('Custom', 'gpt3-ai-content-generator'); ?>"
                                data-aipkit-smart-seo-note-template="<?php echo esc_attr($aipkit_smart_seo_note_template); ?>"
                                role="radio"
                                aria-checked="false"
                                hidden
                            >
                                <span class="aipkit_smart_seo_preset_indicator" aria-hidden="true"></span>
                                <span class="aipkit_smart_seo_preset_copy">
                                    <span class="aipkit_smart_seo_preset_name"><?php esc_html_e('Custom', 'gpt3-ai-content-generator'); ?></span>
                                    <span class="aipkit_smart_seo_preset_description" data-aipkit-smart-seo-custom-note></span>
                                </span>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>

                <details class="aipkit_smart_seo_advanced">
                    <summary class="aipkit_smart_seo_advanced_summary">
                        <span class="aipkit_smart_seo_advanced_label"><?php esc_html_e('SEO checks', 'gpt3-ai-content-generator'); ?></span>
                        <span class="aipkit_smart_seo_advanced_meta">
                            <span
                                class="aipkit_smart_seo_rules_summary"
                                data-aipkit-smart-seo-rules-summary
                                data-aipkit-smart-seo-summary-template="<?php echo esc_attr($aipkit_smart_seo_summary_template); ?>"
                            ></span>
                            <span class="dashicons dashicons-arrow-down-alt2 aipkit_smart_seo_advanced_chevron" aria-hidden="true"></span>
                        </span>
                    </summary>
                    <div class="aipkit_smart_seo_rules_list">
                        <?php foreach ($aipkit_smart_seo_rules_to_render as $aipkit_smart_seo_rule) : ?>
                            <?php
                            $aipkit_smart_seo_rule_id = isset($aipkit_smart_seo_rule['id']) ? sanitize_key((string) $aipkit_smart_seo_rule['id']) : '';
                            if ($aipkit_smart_seo_rule_id === '') {
                                continue;
                            }
                            ?>
                            <label class="aipkit_smart_seo_rule_row">
                                <span class="aipkit_smart_seo_rule_text">
                                    <span class="aipkit_smart_seo_rule_label"><?php echo esc_html((string) ($aipkit_smart_seo_rule['label'] ?? $aipkit_smart_seo_rule_id)); ?></span>
                                    <span class="aipkit_smart_seo_rule_helper"><?php echo esc_html((string) ($aipkit_smart_seo_rule['description'] ?? '')); ?></span>
                                </span>
                                <span class="aipkit_switch aipkit_smart_seo_rule_switch">
                                    <input
                                        type="checkbox"
                                        value="<?php echo esc_attr($aipkit_smart_seo_rule_id); ?>"
                                        data-aipkit-smart-seo-rule-toggle
                                        checked
                                    >
                                    <span class="aipkit_switch_slider"></span>
                                </span>
                            </label>
                        <?php endforeach; ?>
                    </div>
                </details>
            </div>
            <div class="aipkit-modal-footer aipkit_smart_seo_rules_modal_footer">
                <button type="button" class="aipkit_btn aipkit_btn-secondary" data-aipkit-smart-seo-modal-cancel>
                    <?php esc_html_e('Cancel', 'gpt3-ai-content-generator'); ?>
                </button>
                <button type="button" class="aipkit_btn aipkit_btn-primary" data-aipkit-smart-seo-modal-done>
                    <?php esc_html_e('Done', 'gpt3-ai-content-generator'); ?>
                </button>
            </div>
        </div>
    </div>
<?php endif; ?>
