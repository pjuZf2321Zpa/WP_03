<?php

namespace MasterStudy\Lms\Pro\AddonsPlus\Calendar\Http\Controllers;

use DateTimeImmutable;
use MasterStudy\Lms\Http\WpResponseFactory;
use MasterStudy\Lms\Pro\AddonsPlus\Calendar\Services\CalendarEventsProvider;
use MasterStudy\Lms\Validation\Validator;
use RuntimeException;
use WP_REST_Request;
use WP_REST_Response;

abstract class Controller {
	private static bool $validators_registered = false;

	protected function provider(): CalendarEventsProvider {
		return new CalendarEventsProvider( get_current_user_id() );
	}

	protected function month_rules(): array {
		return array(
			'year'  => 'required|calendar_year',
			'month' => 'required|calendar_month',
		);
	}

	protected function pagination_rules( int $max_per_page ): array {
		return array(
			'page'     => 'nullable|integer|min,1',
			'per_page' => 'nullable|integer|min,1|max,' . $max_per_page,
		);
	}

	protected function event_type_rules(): array {
		return array(
			'type' => 'nullable|calendar_event_type',
		);
	}

	protected function validate( WP_REST_Request $request, array $rules ) {
		$this->register_validators();

		$validator = new Validator( $request->get_params(), $rules );

		if ( $validator->fails() ) {
			return WpResponseFactory::validation_failed( $validator->get_errors_array() );
		}

		return $validator->get_validated();
	}

	protected function get_page( array $data ): int {
		return max( 1, absint( $data['page'] ?? 1 ) );
	}

	protected function get_per_page( array $data, int $default, int $max ): int {
		$per_page = absint( $data['per_page'] ?? $default );

		if ( ! $per_page ) {
			$per_page = $default;
		}

		return min( $max, max( 1, $per_page ) );
	}

	protected function get_search( array $data ): string {
		return sanitize_text_field( (string) ( $data['search'] ?? '' ) );
	}

	protected function get_status( array $data ): string {
		$status = sanitize_key( (string) ( $data['status'] ?? '' ) );

		return in_array( $status, array( 'upcoming', 'past' ), true ) ? $status : '';
	}

	protected function get_event_type( array $data ): string {
		$type = sanitize_key( (string) ( $data['type'] ?? '' ) );

		return in_array( $type, $this->event_types(), true ) ? $type : '';
	}

	/**
	 * @return DateTimeImmutable|WP_REST_Response
	 */
	protected function get_date( array $data ) {
		$date   = sanitize_text_field( (string) ( $data['date'] ?? '' ) );
		$parsed = DateTimeImmutable::createFromFormat( '!Y-m-d', $date, wp_timezone() );

		if ( $parsed ) {
			return $parsed;
		}

		return WpResponseFactory::validation_failed( array( 'date' => array( __( 'Invalid calendar date.', 'masterstudy-lms-learning-management-system-pro' ) ) ) );
	}

	private function register_validators(): void {
		if ( self::$validators_registered ) {
			return;
		}

		$this->add_validator(
			'calendar_year',
			static function ( $field, $value ): bool {
				return filter_var( $value, FILTER_VALIDATE_INT ) !== false && absint( $value ) >= 1970 && absint( $value ) <= 2100;
			},
			__( 'The {field} field must be a valid calendar year.', 'masterstudy-lms-learning-management-system-pro' )
		);

		$this->add_validator(
			'calendar_month',
			static function ( $field, $value ): bool {
				return filter_var( $value, FILTER_VALIDATE_INT ) !== false && absint( $value ) >= 1 && absint( $value ) <= 12;
			},
			__( 'The {field} field must be a valid calendar month.', 'masterstudy-lms-learning-management-system-pro' )
		);

		$this->add_validator(
			'calendar_date',
			static function ( $field, $value ): bool {
				$date = DateTimeImmutable::createFromFormat( '!Y-m-d', (string) $value, wp_timezone() );

				return $date && $date->format( 'Y-m-d' ) === (string) $value;
			},
			__( 'The {field} field must be a valid calendar date.', 'masterstudy-lms-learning-management-system-pro' )
		);

		$this->add_validator(
			'calendar_event_status',
			static function ( $field, $value ): bool {
				return in_array( (string) $value, array( 'upcoming', 'past' ), true );
			},
			__( 'The {field} field must be a valid calendar event status.', 'masterstudy-lms-learning-management-system-pro' )
		);

		$this->add_validator(
			'calendar_event_type',
			function ( $field, $value ): bool {
				return '' === (string) $value || in_array( (string) $value, $this->event_types(), true );
			},
			__( 'The {field} field must be a valid calendar event type.', 'masterstudy-lms-learning-management-system-pro' )
		);

		self::$validators_registered = true;
	}

	private function event_types(): array {
		return array( 'zoom', 'meet', 'stream', 'deadline', 'quiz', 'available' );
	}

	private function add_validator( string $name, callable $callback, string $message ): void {
		try {
			Validator::add_validator( $name, $callback, $message );
		} catch ( RuntimeException $exception ) {
			Validator::set_error_message( $name, $message );
			return;
		}
	}
}
