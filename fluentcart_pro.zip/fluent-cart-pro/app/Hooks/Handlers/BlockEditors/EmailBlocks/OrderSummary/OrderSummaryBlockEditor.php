<?php

namespace FluentCartPro\App\Hooks\Handlers\BlockEditors\EmailBlocks\OrderSummary;

use FluentCart\App\Hooks\Handlers\BlockEditors\BlockEditor;

class OrderSummaryBlockEditor extends BlockEditor
{
    use \FluentCartPro\App\Contracts\CanEnqueue;
    protected static string $editorName = 'email-order-summary';

    public function getScripts(): array
    {
        return [
            [
                'source'       => 'admin/BlockEditor/EmailBlocks/OrderSummary/OrderSummaryBlockEditor.jsx',
                'dependencies' => ['wp-blocks', 'wp-components', 'wp-block-editor']
            ]
        ];
    }

    public function getStyles(): array
    {
        return [
            'admin/BlockEditor/EmailBlocks/OrderSummary/style/order-summary-block-editor.scss'
        ];
    }

    public function localizeData(): array
    {
        return [
            $this->getLocalizationKey() => [
                'slug'        => $this->slugPrefix,
                'name'        => static::getEditorName(),
                'title'       => __('Order Summary', 'fluent-cart-pro'),
                'description' => __('A styled card showing key order details like invoice number, date, payment method, and total.', 'fluent-cart-pro'),
            ],
            'fluent_cart_pro_block_translation' => \FluentCartPro\App\Services\Translations\Translations::blockStrings(),
        ];
    }

    public function blockAttributes(): array
    {
        return [];
    }

    public function supports(): array
    {
        return [
            'html'       => false,
            'align'      => false,
            'color'      => [
                'text'       => true,
                'background' => true,
                'link'       => true,
            ],
            'typography' => [
                'fontSize'   => true,
                'lineHeight' => true,
            ],
            'spacing'    => [
                'margin'  => true,
                'padding' => true,
            ],
            '__experimentalBorder' => [
                'color'  => true,
                'radius' => true,
                'style'  => true,
                'width'  => true,
            ],
        ];
    }

    public function render(array $attrs, $block = null, $content = ''): string
    {
        return $content;
    }
}
