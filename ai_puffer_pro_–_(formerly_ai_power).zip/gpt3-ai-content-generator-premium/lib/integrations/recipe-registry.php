<?php

namespace WPAICG\Lib\Integrations\Recipes;

use WPAICG\Core\AIPKit_Event_Registry;
use WPAICG\Lib\Integrations\Recipes\Contracts\AIPKit_Recipe_Registry_Interface;
use WP_Error;

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

class AIPKit_Recipe_Registry implements AIPKit_Recipe_Registry_Interface
{
    /**
     * @var array<string, array<string, mixed>>
     */
    private array $templates = [];

    /**
     * @param array<int, array<string, mixed>> $initial_templates
     */
    public function __construct(array $initial_templates = [])
    {
        $templates_to_register = !empty($initial_templates)
            ? $initial_templates
            : self::get_default_templates();

        foreach ($templates_to_register as $template) {
            $this->register_template($template);
        }
    }

    /**
     * @return bool|\WP_Error
     */
    public function register_template(array $template)
    {
        $normalized_template = $this->normalize_template($template);
        if (is_wp_error($normalized_template)) {
            return $normalized_template;
        }

        $template_slug = $normalized_template['template_slug'];
        $this->templates[$template_slug] = $normalized_template;

        return true;
    }

    public function get_template(string $template_slug): ?array
    {
        $normalized_slug = sanitize_key($template_slug);
        if ($normalized_slug === '') {
            return null;
        }

        return $this->templates[$normalized_slug] ?? null;
    }

    public function has_template(string $template_slug): bool
    {
        return $this->get_template($template_slug) !== null;
    }

    public function get_templates(array $filters = []): array
    {
        if (empty($filters)) {
            return array_values($this->templates);
        }

        $filtered_templates = array_filter(
            $this->templates,
            static function (array $template) use ($filters): bool {
                foreach ($filters as $filter_key => $filter_value) {
                    if (!array_key_exists($filter_key, $template)) {
                        return false;
                    }

                    if ((string) $template[$filter_key] !== (string) $filter_value) {
                        return false;
                    }
                }

                return true;
            }
        );

        return array_values($filtered_templates);
    }

    /**
     * @param array<string, mixed> $template
     * @return array<string, mixed>|WP_Error
     */
    private function normalize_template(array $template)
    {
        $template_slug = sanitize_key((string) ($template['template_slug'] ?? ''));
        $label = sanitize_text_field((string) ($template['label'] ?? ''));
        $app_slug = sanitize_key((string) ($template['app_slug'] ?? ''));
        $action_slug = sanitize_key((string) ($template['action_slug'] ?? ''));
        $event_name = sanitize_text_field((string) ($template['event_name'] ?? ''));

        if ($template_slug === '' || $label === '' || $app_slug === '' || $action_slug === '' || $event_name === '') {
            return new WP_Error(
                'aipkit_recipe_template_invalid',
                __('Recipe template is missing one or more required fields.', 'gpt3-ai-content-generator')
            );
        }

        if (class_exists(AIPKit_Event_Registry::class) && !AIPKit_Event_Registry::has_event($event_name)) {
            return new WP_Error(
                'aipkit_recipe_template_event_invalid',
                sprintf(
                    /* translators: %s: unsupported event name */
                    __('Recipe template references unsupported event `%s`.', 'gpt3-ai-content-generator'),
                    $event_name
                )
            );
        }

        $default_mapping = isset($template['default_mapping']) && is_array($template['default_mapping'])
            ? $template['default_mapping']
            : ['fields' => []];

        $tags = isset($template['tags']) && is_array($template['tags'])
            ? array_values(array_unique(array_filter(array_map('sanitize_key', $template['tags']))))
            : [];

        return [
            'template_slug' => $template_slug,
            'label' => $label,
            'app_slug' => $app_slug,
            'action_slug' => $action_slug,
            'event_name' => $event_name,
            'object_type' => sanitize_key((string) ($template['object_type'] ?? 'generic')),
            'default_mapping' => $default_mapping,
            'tags' => $tags,
        ];
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    public static function get_default_templates(): array
    {
        $aipkit_translate_labels = false;
        return require __DIR__ . '/recipe-templates.php';
    }
}
