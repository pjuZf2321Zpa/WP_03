<?php
if (!defined('ABSPATH')) {
    die('You are not allowed to call this page directly.');
}
?>
<div class="wrap">
    <h2><?php esc_html_e('Cart Orders', 'memberpress'); ?></h2>

    <form id="mepr-cart-orders-list-form" method="get">
        <input type="hidden" name="page" value="memberpress-orders" />

        <?php
        // Filter + search share one .mepr-search-box (same pattern as Members/Subscriptions)
        // so the currency filter and search field stack/align instead of floating apart.
        MeprHooks::do_action('mepr_cart_orders_search');
        ?>
        <br class="clear" />
        <?php
        $list_table->views();
        $list_table->display();
        ?>
    </form>
</div>
