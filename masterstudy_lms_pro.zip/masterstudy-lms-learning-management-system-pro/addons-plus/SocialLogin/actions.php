<?php

use MasterStudy\Lms\Pro\AddonsPlus\SocialLogin\SocialLoginManager;

function masterstudy_lms_social_login_init() {
	// phpcs:ignore WordPress.Security.NonceVerification.Recommended
	if ( isset( $_GET['addon'], $_GET['provider'], $_GET['code'] ) && 'social_login' === $_GET['addon'] ) {
		// An authorization code works only once: a repeated callback request (reload, back button) of a user
		// who is already logged in must not exchange it again.
		if ( is_user_logged_in() ) {
			wp_safe_redirect( \STM_LMS_User::user_page_url() );
			exit;
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$provider = SocialLoginManager::get_provider( sanitize_text_field( $_GET['provider'] ) );

		if ( $provider ) {
			// phpcs:ignore WordPress.Security.NonceVerification.Recommended
			$provider->set_token_exchange_code( sanitize_text_field( $_GET['code'] ) );
		}
	}
}
add_action( 'init', 'masterstudy_lms_social_login_init' );
