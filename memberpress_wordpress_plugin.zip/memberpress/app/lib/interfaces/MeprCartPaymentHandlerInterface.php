<?php

if (!defined('ABSPATH')) {
    die('You are not allowed to call this page directly.');
}

/**
 * Contract for per-gateway cart payment handlers.
 *
 * Implement this interface to add cart checkout support for a new gateway.
 * Register via the 'mepr_cart_payment_handlers' filter:
 *
 *   add_filter('mepr_cart_payment_handlers', function (array $handlers): array {
 *       $handlers[MyGateway::class] = MyCartHandler::class;
 *       return $handlers;
 *   });
 *
 * The handler is instantiated with the active gateway passed to __construct().
 * Each gateway declares its own capabilities and JS config so the central
 * service never needs to know concrete gateway classes (Open/Closed).
 *
 * Coupon references are nullable type hints only — they never autoload, so
 * this file is safe in coupon-stripped builds. mepr:coupon-surface
 */
interface MeprCartPaymentHandlerInterface
{
    /**
     * Bind the handler to the gateway instance it wraps.
     *
     * @param MeprBaseRealGateway $gateway The configured gateway instance.
     */
    public function __construct(MeprBaseRealGateway $gateway);

    /**
     * The id of the gateway this handler wraps. Lets the service resolve/re-tag the
     * order without knowing the concrete gateway class.
     */
    public function gateway_id(): string;

    /**
     * Whether this gateway can charge off-session (stored payment method).
     * Drives funnel upsell eligibility and save-card forcing.
     */
    public function supports_off_session(): bool;

    /**
     * Gateway-specific config merged into the per-gateway entry localized to JS
     * and passed to the payment step template. The service adds id/key/label;
     * this returns only the keys this gateway needs (e.g. stripe_key,
     * manually_complete, offline_payment_desc).
     *
     * @return array<string, mixed>
     */
    public function js_config(): array;

    /**
     * Build the payment-step mount config WITHOUT creating an order or a gateway intent.
     * Called when the payment step becomes active so the UI can render (deferred Stripe
     * Element / offline notice / saved methods) with no premature order or PaymentIntent.
     * The order + intent are created later, only on Pay Now (initiate()). Must make no
     * gateway API write.
     *
     * Returns e.g. ['elements_options' => [...], 'saved_methods' => [...], 'setup_intent' => bool,
     * 'total' => float] for Stripe, or ['offline' => true, 'manually_complete' => bool,
     * 'total' => float] for offline.
     *
     * @param  integer         $user_id   The buyer's user ID (0 for guests).
     * @param  MeprCartSession $session   The active cart session.
     * @param  array           $totals    Calculated totals from calculate_totals().
     * @param  boolean         $save_card Whether the payment method should be stored for reuse.
     * @param  MeprCoupon|null $coupon    The applied coupon, or null.
     * @return array<string, mixed>
     */
    public function prepare(
        int $user_id,
        MeprCartSession $session,
        array $totals,
        bool $save_card,
        ?MeprCoupon $coupon
    ): array;

    /**
     * Initiate payment for the given (already resolved/created) order, returning the JS
     * payload. The service resolves or reuses the pending order and applies totals before
     * calling this; the handler only performs gateway-specific setup (e.g. a PaymentIntent).
     *
     * @param  MeprOrder       $order         The pending order to take payment for.
     * @param  integer         $user_id       The buyer's user ID.
     * @param  MeprCartSession $session       The active cart session.
     * @param  array           $totals        Calculated totals from calculate_totals().
     * @param  boolean         $save_card     Whether the payment method should be stored for reuse.
     * @param  MeprCoupon|null $coupon        The applied coupon, or null.
     * @param  array           $checkout_data Persisted checkout data for the session.
     * @return array<string, mixed>
     * @throws \Exception On any setup failure.
     */
    public function initiate(
        MeprOrder $order,
        int $user_id,
        MeprCartSession $session,
        array $totals,
        bool $save_card,
        ?MeprCoupon $coupon,
        array $checkout_data
    ): array;

    /**
     * Confirm payment and complete the order.
     *
     * Returns ['redirect' => URL] on success, ['redirect' => URL, 'pending' => true]
     * for offline manually_complete, or ['error' => msg, 'status' => int] on failure.
     *
     * @param  MeprOrder $order     The order being paid.
     * @param  array     $post_data Sanitized POST data from the Pay Now request.
     * @return array<string, mixed>
     */
    public function confirm(MeprOrder $order, array $post_data): array;

    /**
     * Process a refund.
     *
     * Returns ['success' => bool, 'error' => string (on failure), ...].
     *
     * @param  MeprOrder    $order          The order to refund.
     * @param  integer|null $transaction_id Line transaction ID for a per-line refund, or null for order-level.
     * @param  float|null   $amount         Partial amount, or null for a full refund.
     * @param  string       $reason         Admin-entered refund reason.
     * @return array<string, mixed>
     */
    public function refund(MeprOrder $order, ?int $transaction_id, ?float $amount, string $reason): array;
}
