<?php

namespace FluentCartPro\App\Modules\PaymentMethods\PaddleGateway;

use FluentCart\App\Models\OrderItem;
use FluentCart\App\Models\Subscription;
use FluentCart\App\Services\Payments\SubscriptionHelper;
use FluentCartPro\App\Modules\PaymentMethods\PaddleGateway\API\API;
use FluentCart\Api\CurrencySettings;
use FluentCart\App\Helpers\CurrenciesHelper;
use FluentCart\App\Helpers\Helper;
use FluentCart\App\Helpers\Status;
use FluentCart\App\Models\Customer;
use FluentCart\App\Models\Order;
use FluentCart\App\Models\OrderTransaction;
use FluentCart\App\Models\Product;
use FluentCart\App\Models\ProductVariation;
use FluentCart\Framework\Support\Arr;

class PaddleHelper
{
    const CUSTOM_DATA_RESERVED_PREFIX = 'fct_';

    /**
     * Whether $paddleTransactionId may confirm the local transaction. Only the
     * Paddle transaction prepared last is accepted; meta absent means the row
     * predates server-side creation (legacy/renewal) and is not restricted.
     * A payment landing on a replaced checkout is refused but written to the
     * order log so the money can be found and refunded from Paddle.
     */
    public static function isExpectedCheckoutTransaction(OrderTransaction $transaction, Order $order, $paddleTransactionId): bool
    {
        $meta = (array) ($transaction->meta ?? []);
        $expectedTransactionId = (string) Arr::get($meta, 'paddle_expected_transaction_id', '');

        if ($expectedTransactionId === '' || $expectedTransactionId === (string) $paddleTransactionId) {
            return true;
        }

        $superseded = (array) Arr::get($meta, 'paddle_superseded_transaction_ids', []);
        if (in_array((string) $paddleTransactionId, array_map('strval', $superseded), true)) {
            $order->addLog(
                __('Paddle payment on replaced checkout', 'fluent-cart-pro'),
                sprintf(
                    /* translators: 1: Paddle transaction id that was paid, 2: Paddle transaction id currently expected */
                    __('Paddle reported a payment on transaction %1$s, which was replaced by %2$s when the checkout was reopened. The payment was not applied to this order. Review it in the Paddle dashboard and refund it if the order was paid another way.', 'fluent-cart-pro'),
                    $paddleTransactionId,
                    $expectedTransactionId
                ),
                'warning'
            );
        }

        return false;
    }

    /**
     * Process remote refund via Paddle API
     */
    public static function processRemoteRefund($transaction, $amount, $args)
    {
        $reason = Arr::get($args, 'reason', '');
        $itemIds = Arr::get($args, 'item_ids', []);
        $order = $transaction->order;

        $paddleTransactionId = $transaction->vendor_charge_id;
        if (!$paddleTransactionId) {
            return new \WP_Error('invalid_refund', __('Invalid transaction ID for refund.', 'fluent-cart-pro'));
        }

        $type = Arr::get($args, 'type', 'partial');

        $meta                   = (array)($transaction->meta ?? []);
        $paddleCapturedTotal    = (int) Arr::get($meta, 'paddle_captured', 0);
        $paddleCapturedCurrency = strtoupper((string) Arr::get($meta, 'paddle_captured_currency', ''));
        $orderCurrency          = strtoupper((string) ($order->currency ?? ''));
        $isCrossCurrency        = $paddleCapturedCurrency && $paddleCapturedCurrency !== $orderCurrency;

        // Cross-currency: txn.total = order.total_amount in order currency → threshold is txn.total.
        // Reverse-charge (same currency): paddle_captured < txn.total (gross cover); full refund
        // means returning everything Paddle captured, so compare against paddle_captured instead.
        if ($amount >= (int) $transaction->total) {
            $type = 'full';
        } elseif (!$isCrossCurrency && $paddleCapturedTotal > 0 && $amount >= $paddleCapturedTotal) {
            $type = 'full';
        }

        $taxMode = '';
        if (isset($args['tax_mode'])) {
            $taxMode = $args['tax_mode'];
        }

        if (!$taxMode) {
            $taxMode = (new PaddleSettings())->get('tax_mode');
        }

        $reason = !empty($reason) ? $reason : 'Refunded on Customer Request';

        $mappedPaddleItemIds = Arr::get($transaction->meta, 'mapped_paddle_item_ids', []);
        $itemsWithProportionalAmount = self::getPlannedItemAmounts(Arr::get($args, 'refunded_items', []), $amount);
        if (!$itemsWithProportionalAmount) {
            $itemsWithProportionalAmount = self::getItemIdsWithProportionalRefundableAmount($transaction, $itemIds, $amount);
        }
        $totalRefundableAmountFromItems = 0;
        foreach ($itemsWithProportionalAmount as $item) {
            $totalRefundableAmountFromItems += $item['amount'];
        }

        if ($totalRefundableAmountFromItems < $amount && !empty($itemIds)) {
            return new \WP_Error('invalid_refund', __('Invalid refund amount. Please check the items available refund amounts.', 'fluent-cart-pro'));
        } else if ($totalRefundableAmountFromItems < $amount && empty($itemIds)){
            $type = 'full';
        }

        if ($type == 'partial' && (empty($mappedPaddleItemIds) || !$itemsWithProportionalAmount)) {
            return new \WP_Error('invalid_refund', __('Partial refund not allowed without any items selected.', 'fluent-cart-pro'));
        }

        if ($type == 'partial' && $totalRefundableAmountFromItems < $amount) {
            return new \WP_Error('invalid_refund', __('Invalid refund amount. Please check the items available refund amounts.', 'fluent-cart-pro'));
        }

        // total_paid stays gross for a MoR reverse-charge order (cover invariant — see
        // Order::netAmount()); net it out here so a full refund of the actually
        // captured amount doesn't get misread as short of the outstanding balance.
        $netPaidTotal = $order->netAmount((int) $order->total_paid);
        if ($type == 'full' && $amount < ($netPaidTotal - $order->total_refund) ) {
            return new \WP_Error('invalid_refund', __('Partial refund not allowed without any items selected.', 'fluent-cart-pro'));
        }

        $refundData = [
            'action' => 'refund',
            'reason' => $reason,
            'type' => $type,
            'transaction_id' => $paddleTransactionId
        ];

        // Convert FC-unit admin amounts → Paddle native (charged-currency) amounts.
        //
        // FC convention: all amounts ×100, including zero-decimal currencies (JPY 16168 → stored 1616800).
        // Paddle expects native units: JPY 16168, EUR 10710, USD 10000.
        //
        // Cross-currency: factor = (paddle_captured_FC / 100_if_zero_decimal) / txn.total_FC
        //   e.g. USD→JPY: (1616800 / 100) / 10000 = 1.6168 → 10000 × 1.6168 = 16168 JPY ✓
        //   e.g. USD→EUR: 10710 / 10000 = 1.071 → 10000 × 1.071 = 10710 EUR ✓
        // Same-currency zero-decimal (JPY shop): factor = 0.01 (FC→native is always ÷100)
        // Same-currency decimal: factor = 1 (FC amount = Paddle cents, no conversion needed)
        // For match transactions paddle_captured_currency is absent — fall back to order currency.
        // Same-currency: fallback = order currency (correct). Cross-currency: captured currency is
        // always set (capturedMeta is called on all non-match paths), so fallback never fires there.
        $effectiveCapturedCurrency = $paddleCapturedCurrency ?: $orderCurrency;
        $capturedIsZeroDecimal     = CurrenciesHelper::isZeroDecimal($effectiveCapturedCurrency);
        $conversionFactor      = 1;
        $transactionTotal      = (int) $transaction->total;

        if ($isCrossCurrency && $paddleCapturedTotal > 0 && $transactionTotal > 0) {
            $conversionFactor = $capturedIsZeroDecimal
                ? $paddleCapturedTotal / ($transactionTotal * 100)
                : $paddleCapturedTotal / $transactionTotal;
        } elseif (!$isCrossCurrency && $paddleCapturedTotal > 0 && $transactionTotal > 0
            && $paddleCapturedTotal < $transactionTotal) {
            // Reverse charge (captured net < gross order total) — scale items to the net.
            $conversionFactor = $capturedIsZeroDecimal
                ? ($paddleCapturedTotal / 100) / $transactionTotal
                : $paddleCapturedTotal / $transactionTotal;
        } elseif (!$isCrossCurrency && $capturedIsZeroDecimal) {
            $conversionFactor = 0.01;
        }

        if ($type == 'partial') {
            // Several order items can share one Paddle line (signup fee, fees and
            // add-ons all bill through the "Initial Payment" price); Paddle takes
            // one entry per line.
            $amountByLine = [];
            foreach ($itemsWithProportionalAmount as $item) {
                if (empty($mappedPaddleItemIds[$item['id']])) {
                    return new \WP_Error('invalid_refund', __('Selected item is not linked to a Paddle line item. Refund it from the Paddle dashboard instead.', 'fluent-cart-pro'));
                }

                $lineId = $mappedPaddleItemIds[$item['id']];
                $amountByLine[$lineId] = ($amountByLine[$lineId] ?? 0) + $item['amount'];
            }

            $items = [];
            foreach ($amountByLine as $lineId => $lineAmount) {
                $items[] = [
                    'item_id' => $lineId,
                    'type' => 'partial',
                    'amount' => (string) (int) round($lineAmount * $conversionFactor)
                ];
            }

            $refundData['items'] = $items;

            if (in_array($taxMode, ['external', 'internal'], true)) {
                $refundData['tax_mode'] = $taxMode;
            }
        }

        $refunded = (new API())->createPaddleObject('adjustments', $refundData, $transaction->payment_mode);

        if (is_wp_error($refunded)) {
            return $refunded;
        }

        $status = Arr::get($refunded, 'data.status');

        $acceptedStatus = ['approved', 'pending_approval'];
        if (!in_array($status, $acceptedStatus)) {
            return new \WP_Error('refund_failed', __('Refund could not be processed in paddle. Please check on your paddle account', 'fluent-cart-pro'));
        }

        if ($status == 'approved') {
            $status = 'refunded';
        }

        if ($status == 'pending_approval') {
            $status = 'pending_approval';
        }

        return Arr::get($refunded, 'data.id');
    }

    /**
     * The per-item amounts core already recorded, so Paddle refunds the split the order shows.
     * Empty when they do not add up to the refund (shipping is refunded with the items).
     *
     * @param array $refundedItems rows with id and refund_amount, from RefundPlanner
     * @param int   $amount        refund amount in cents
     * @return array rows with id and amount
     */
    private static function getPlannedItemAmounts($refundedItems, $amount): array
    {
        $items = [];
        foreach ((array) $refundedItems as $row) {
            $items[] = [
                'id'     => (int) Arr::get($row, 'id'),
                'amount' => (int) Arr::get($row, 'refund_amount', 0),
            ];
        }

        if (!$items || array_sum(array_column($items, 'amount')) !== (int) $amount) {
            return [];
        }

        return $items;
    }

    public static function getItemIdsWithProportionalRefundableAmount($transactionModel, $itemIds, $refundedAmount) : array
    {
        $totalItems = count($itemIds);

        if ($totalItems === 1) {
            return [
                [
                    'id' => $itemIds[0],
                    'amount' => $refundedAmount
                ]
            ];
        }

        if ($totalItems === 0) {
            $itemIds = OrderItem::query()->where('order_id', $transactionModel->order_id)
                ->pluck('id')->toArray();
        }


        // Calculate remaining amount for each item
        $items = [];
        $totalRemain = 0;
        foreach ($itemIds as $itemId) {
            $orderItem = OrderItem::find($itemId);
            $remain = max(0, $orderItem->line_total - $orderItem->refund_total);
            $items[] = [
                'model'  => $orderItem,
                'remain' => $remain
            ];
            $totalRemain += $remain;
        }

        if ($totalRemain == 0) {
            return [];
        }

        if ($totalRemain < $refundedAmount) {
            $refundedAmount = $totalRemain;
        }

        // Distribute refund proportionally
        $itemsWithProportionalAmount = [];
        $distributed = 0;
        foreach ($items as $index => $item) {
            if ($index === count($items) - 1) {
                $amount = $refundedAmount - $distributed;
            } else {
                $amount = $refundedAmount * ($item['remain'] / $totalRemain);
                $distributed += $amount;
            }
            $itemsWithProportionalAmount[] = [
                'id' => $item['model']->id,
                'amount' => $amount
            ];
        }

        return $itemsWithProportionalAmount;
    }

    /**
     * FluentCart identifiers stored on Paddle catalog objects (shown in Paddle dashboard details)
     *
     * @param int|string|null $fctProductId
     * @param int|string|null $fctVariationId
     * @return array
     */
    public static function getCatalogCustomData($fctProductId = null, $fctVariationId = null)
    {
        $customData = [];

        if ($fctProductId) {
            $customData['fct_product_id'] = (string)$fctProductId;
        }

        if ($fctVariationId) {
            $customData['fct_variation_id'] = (string)$fctVariationId;
        }

        return $customData;
    }

    /**
     * Build the custom_data sent with a Paddle checkout/transaction.
     *
     * Third parties may add keys through the filter; our identifiers are
     * re-stamped from the models afterwards, so they cannot be dropped or shadowed.
     *
     * @param Order $order
     * @param OrderTransaction $transaction
     * @param Subscription|null $subscription
     * @return array
     */
    public static function buildCheckoutCustomData($order, $transaction, $subscription = null)
    {
        $reserved = [
            'fct_order_hash'       => $order->uuid,
            'fct_transaction_hash' => $transaction->uuid,
        ];

        if ($subscription) {
            $reserved['fct_subscription_hash'] = $subscription->uuid;
        }

        $customData = apply_filters('fluent_cart/paddle/checkout_custom_data', $reserved, [
            'order'        => $order,
            'transaction'  => $transaction,
            'subscription' => $subscription,
        ]);

        return static::sanitizeCustomData($customData, $reserved);
    }

    /**
     * Keep filtered custom_data flat and scalar, then restore the reserved keys
     * from the source of truth.
     *
     * @param mixed $customData
     * @param array $reserved
     * @return array
     */
    public static function sanitizeCustomData($customData, array $reserved)
    {
        if (!is_array($customData)) {
            $customData = [];
        }

        $clean = [];

        foreach ($customData as $key => $value) {
            if (!is_string($key) || !preg_match('/^[a-zA-Z0-9_]{1,40}$/', $key)) {
                continue;
            }

            if (strpos($key, static::CUSTOM_DATA_RESERVED_PREFIX) === 0) {
                continue;
            }

            if (is_bool($value)) {
                $value = $value ? '1' : '0';
            } elseif (is_int($value) || is_float($value)) {
                $value = (string)$value;
            }

            // Webhook readers treat custom_data as a flat string map
            if (!is_string($value)) {
                continue;
            }

            $clean[$key] = mb_substr($value, 0, 500);
        }

        return array_merge($clean, $reserved);
    }

    /**
     * PATCH a Paddle catalog object when its custom_data misses our identifiers
     *
     * @param string $endpoint
     * @param array $paddleObject
     * @param array $customData
     * @param string $mode
     * @return array
     */
    public static function syncCatalogCustomData($endpoint, $paddleObject, $customData, $mode = '')
    {
        if (!$customData) {
            return $paddleObject;
        }

        $existing = Arr::get($paddleObject, 'data.custom_data');
        $existing = is_array($existing) ? $existing : [];

        if (!array_diff_assoc($customData, $existing)) {
            return $paddleObject;
        }

        $updated = API::updatePaddleObject($endpoint . '/' . Arr::get($paddleObject, 'data.id'), [
            'custom_data' => array_merge($existing, $customData)
        ], $mode);

        return is_wp_error($updated) ? $paddleObject : $updated;
    }

    /**
     * Create or get Paddle customer
     */
    public static function createOrGetPaddleCustomer(Customer $customer, $mode = '')
    {
        // Check if customer already has a Paddle customer ID
        $paddleCustomerId = $customer->getMeta('paddle_customer_id_' . $mode);
        
        if ($paddleCustomerId) {
            // Verify customer still exists in Paddle
            $paddleCustomer = API::getPaddleObject("customers/{$paddleCustomerId}", [], $mode);
            if (!is_wp_error($paddleCustomer)) {
                return $paddleCustomer;
            }
        }

        // Create new customer in Paddle
        $customerData = [
            'name' => $customer->full_name,
            'email' => $customer->email,
            'custom_data' => [
                'fct_cart_customer_hash' => $customer->uuid
            ]
        ];

        $paddleCustomer = API::createPaddleObject('customers', $customerData, $mode);

        if (is_wp_error($paddleCustomer)) {
            $errorData = $paddleCustomer->get_error_data();
            $errorCode = Arr::get($errorData, 'response_body.error.code', '');

            if ($errorCode === 'customer_already_exists') {
                $detail = Arr::get($errorData, 'response_body.error.detail', '');

                preg_match('/ctm_[a-z0-9]+/', $detail, $matches);
                $paddleCustomerId = !empty($matches) ? $matches[0] : '';

                $customer->updateMeta('paddle_customer_id_' . $mode, $paddleCustomerId);

                return API::getPaddleObject("customers/{$paddleCustomerId}", [], $mode);

            } else {
                return $paddleCustomer;
            }
        }

        $customer->updateMeta('paddle_customer_id_' . $mode, Arr::get($paddleCustomer, 'data.id'));

        return $paddleCustomer;
    }

    public static function getTransactionMeta($paddleTransaction, $order)
    {
        $paddleLineItems = Arr::get($paddleTransaction, 'details.line_items', []);

        // filter out items from paddleItemIds if total is <= 0
        $paddleLineItems = array_values(array_filter($paddleLineItems, function ($item) {
            return Arr::get($item, 'totals.total') > 0;
        }));

        $details = Arr::get($paddleTransaction, 'details');

        return [
            'mapped_paddle_item_ids'   => self::mapOrderItemsToPaddleLineItems($order, $paddleLineItems, Arr::get($paddleTransaction, 'items', [])),
            'paddle_totals'     => Arr::get($details, 'totals'),
            // payout_totals carries Paddle's authoritative exchange_rate (transaction
            // currency -> your payout currency, margin included) and the settled amount.
            // Stored for reconciliation/accounting — NOT used to validate the charge,
            // since it does not express the order-currency -> buyer-currency rate.
            'paddle_payout_totals' => Arr::get($details, 'payout_totals'),
            'tax_mode'          => Arr::get($details, 'tax_mode')
        ];
    }

    /**
     * Map local order items to Paddle line items (txnitm_*) for item-level refunds.
     *
     * Catalog prices carry the local variation id in custom_data (see
     * getCatalogCustomData), so a line item can be tied to the order item that
     * holds the same object_id. Bundle rows never reach Paddle and are skipped.
     *
     * A subscription checkout sends one recurring price plus, when there is
     * anything to charge up front, a single "Initial Payment" price with no
     * custom_data that folds the signup fee, fees and one-time add-ons together
     * (Processor::handleSubscriptionPayment). The order items behind that
     * price all point at the same line so a partial refund of any of them
     * targets the line that billed it. A trial order has no recurring line
     * (zero total), so its subscription item stays unmapped.
     *
     * Positional pairing (nth order item = nth line item) only applies when no
     * price carries custom_data at all (transactions created before it was
     * stamped) and the two lists are the same length. Anything else stays
     * unmapped and fails closed in processRemoteRefund.
     *
     * @param \FluentCart\App\Models\Order $order
     * @param array $paddleLineItems details.line_items with a positive total, re-indexed
     * @param array $paddleItems     items[] from the transaction (price.id, price.custom_data)
     * @return array {orderItemId => paddleLineItemId}
     */
    public static function mapOrderItemsToPaddleLineItems($order, array $paddleLineItems, array $paddleItems): array
    {
        $orderItems = $order->order_items->filter(function ($item) {
            return $item->payment_type !== 'bundle';
        })->values();

        $variationByPriceId = [];
        foreach ($paddleItems as $paddleItem) {
            $priceId = Arr::get($paddleItem, 'price.id');
            $variationId = (int) Arr::get($paddleItem, 'price.custom_data.fct_variation_id', 0);
            if ($priceId && $variationId) {
                $variationByPriceId[$priceId] = $variationId;
            }
        }

        $mapped = [];

        if (!$variationByPriceId) {
            if (count($orderItems) === count($paddleLineItems)) {
                foreach ($orderItems as $index => $orderItem) {
                    $mapped[$orderItem->id] = Arr::get($paddleLineItems[$index], 'id');
                }
            }
            return $mapped;
        }

        $usedOrderItemIds = [];
        $anonymousLineIds = [];
        foreach ($paddleLineItems as $lineItem) {
            $variationId = Arr::get($variationByPriceId, Arr::get($lineItem, 'price_id'));
            if (!$variationId) {
                $anonymousLineIds[] = Arr::get($lineItem, 'id');
                continue;
            }

            foreach ($orderItems as $orderItem) {
                if ((int) $orderItem->object_id === $variationId && !isset($usedOrderItemIds[$orderItem->id])) {
                    $mapped[$orderItem->id] = Arr::get($lineItem, 'id');
                    $usedOrderItemIds[$orderItem->id] = true;
                    break;
                }
            }
        }

        $hasSubscriptionItem = $orderItems->contains(function ($item) {
            return $item->payment_type === 'subscription';
        });

        if ($hasSubscriptionItem && count($anonymousLineIds) === 1) {
            foreach ($orderItems as $orderItem) {
                if ($orderItem->payment_type !== 'subscription' && !isset($usedOrderItemIds[$orderItem->id])) {
                    $mapped[$orderItem->id] = $anonymousLineIds[0];
                }
            }
        }

        return $mapped;
    }

    /**
     * Transform Paddle subscription status to FluentCart status
     */
    public static function transformSubscriptionStatus($paddleStatus)
    {
        $statusMap = [
            'active' => Status::SUBSCRIPTION_ACTIVE,
            'trialing' => Status::SUBSCRIPTION_TRIALING,
            'past_due' => Status::SUBSCRIPTION_PAST_DUE,
            'paused' => Status::SUBSCRIPTION_PAUSED,
            'canceled' => Status::SUBSCRIPTION_CANCELED,
        ];

        return Arr::get($statusMap, strtolower($paddleStatus), Status::SUBSCRIPTION_PENDING);
    }

    /**
     * Transform Paddle transaction status to FluentCart status
     */
    public static function transformTransactionStatus($paddleStatus)
    {
        $statusMap = [
            'completed' => Status::TRANSACTION_SUCCEEDED,
            'paid' => Status::TRANSACTION_SUCCEEDED,
            'billed' => Status::TRANSACTION_SUCCEEDED,
            'ready' => Status::TRANSACTION_PENDING,
            'draft' => Status::TRANSACTION_PENDING,
        ];

        return Arr::get($statusMap, strtolower($paddleStatus), Status::TRANSACTION_PENDING);
    }

    /**
     * Format order items for Paddle transaction
     * a reference
     */
    public static function formatOrderItemsForPaddle($orderItems, Order $order)
    {
        $items = [];
        
        foreach ($orderItems as $item) {
            $unitPrice = Helper::toDecimal($item['unit_price'], false, null, true, true, false);
            
            $items[] = [
                'price_id' => null, // Will be set when creating price
                'quantity' => $item['quantity'],
                'price' => [
                    'description' => $item['item_name'],
                    'product_id' => null, // Will be set when creating product
                    'unit_price' => [
                        'amount' => $unitPrice,
                        'currency_code' => strtoupper($order->currency)
                    ],
                    'tax_mode' => 'account_setting'
                ]
            ];
        }

        return $items;
    }

    /**
     * Get subscription update data from Paddle subscription
     */
    public static function getSubscriptionUpdateData($paddleSubscription, $localSubscription)
    {
        $status = self::transformSubscriptionStatus(Arr::get($paddleSubscription, 'data.status'));

        // active + scheduled cancel = subscription will expire at end of billing period
        $scheduledChange = Arr::get($paddleSubscription, 'data.scheduled_change');
        if ($status === Status::SUBSCRIPTION_ACTIVE && Arr::get($scheduledChange, 'action') === 'cancel') {
            $status = Status::SUBSCRIPTION_CANCELED;
        }

        $updateData = [
            'status'          => $status,
            'vendor_response' => json_encode($paddleSubscription),
        ];

        // Update next billing date if available
        $nextBillingAt = Arr::get($paddleSubscription, 'data.next_billed_at');
        if ($nextBillingAt) {
            $updateData['next_billing_date'] = SubscriptionHelper::safeTimestampToDatetime($nextBillingAt);
        }

        $trialEndsAt = Arr::get($paddleSubscription, 'data.trial_dates.ends_at');
        if ($trialEndsAt) {
            $updateData['trial_ends_at'] = SubscriptionHelper::safeTimestampToDatetime($trialEndsAt);
        }

        if ($status === Status::SUBSCRIPTION_CANCELED) {
            $canceledAt = Arr::get($paddleSubscription, 'data.canceled_at')
                ?? Arr::get($scheduledChange, 'effective_at');
            if ($canceledAt) {
                $updateData['canceled_at'] = SubscriptionHelper::safeTimestampToDatetime($canceledAt);
            }
        }

        return $updateData;
    }

    /**
     * Customer and recurring price refs from a Paddle subscription entity
     * (the `data` object, not the API envelope).
     *
     * @param array $paddleSubscription
     * @return array{vendor_customer_id: string, vendor_plan_id: string}
     */
    public static function getSubscriptionVendorRefs($paddleSubscription)
    {
        $items = (array) Arr::get($paddleSubscription, 'items', []);

        $recurring = null;
        foreach ($items as $item) {
            if (Arr::get($item, 'price.billing_cycle')) {
                $recurring = $item;
                break;
            }
        }

        if (!$recurring) {
            $recurring = reset($items) ?: [];
        }

        return [
            'vendor_customer_id' => (string) Arr::get($paddleSubscription, 'customer_id', ''),
            'vendor_plan_id'     => (string) Arr::get($recurring, 'price.id', ''),
        ];
    }

    /**
     * Generate checkout URL for Paddle
     */
    public static function generateCheckoutUrl($transactionData, $mode = '')
    {
        $settings = new PaddleSettings();
        $checkoutUrl = $settings->getCheckoutUrl($mode);
        
        $queryParams = [
            'items' => json_encode($transactionData['items']),
            'customer_email' => $transactionData['customer_email'],
            'custom_data' => json_encode($transactionData['custom_data'] ?? [])
        ];

        return add_query_arg($queryParams, $checkoutUrl);
    }

    /**
     * Get order from Paddle webhook data
     */
    public static function getOrderFromWebhookData($webhookData)
    {
        $customData = Arr::get($webhookData, 'data.custom_data', []);

        if (!$customData) {
            // Let's try to get the order from transaction
            $vendorTransactionId = Arr::get($webhookData, 'data.transaction_id');
            if ($vendorTransactionId) {
                $transaction = OrderTransaction::query()->where('vendor_charge_id', $vendorTransactionId)->first();
                if ($transaction) {
                    return $transaction->order;
                }
            }
        }

        $orderHash = Arr::get($customData, 'fct_order_hash');

        if ($orderHash) {
            return Order::query()->where('uuid', $orderHash)->first();
        }

        $paddleSubscriptionId = Arr::get($webhookData, 'data.subscription_id');

        if (!$paddleSubscriptionId) {
            $entityId = Arr::get($webhookData, 'data.id');
            if ($entityId && str_starts_with((string) $entityId, 'sub_')) {
                $paddleSubscriptionId = $entityId;
            }
        }

        if ($paddleSubscriptionId) {
            $subscription = Subscription::query()
                ->where('vendor_subscription_id', $paddleSubscriptionId)
                ->where('current_payment_method', 'paddle')
                ->first();

            if ($subscription && $subscription->parent_order_id) {
                return Order::query()->where('id', $subscription->parent_order_id)->first();
            }
        }

        return null;
    }

    /**
     * Get billing cycle configuration from subscription
     */
    public static function getBillingCycleFromSubscription($subscription)
    {
        $interval = $subscription->billing_interval;
        $intervalCount = $subscription->billing_interval_count ?: 1;

        $paddleInterval = [
            'day' => 'day',
            'week' => 'week',
            'month' => 'month',
            'year' => 'year'
        ];

        return [
            'interval' => Arr::get($paddleInterval, $interval, 'month'),
            'frequency' => $intervalCount
        ];
    }

    public static function formatAmount($amount, $currency = '')
    {
        $amount = (int) $amount;

        if ($currency && CurrenciesHelper::isZeroDecimal($currency)) {
            $amount = (int) round($amount / 100);
        }

        return (string) $amount;
    }
}
