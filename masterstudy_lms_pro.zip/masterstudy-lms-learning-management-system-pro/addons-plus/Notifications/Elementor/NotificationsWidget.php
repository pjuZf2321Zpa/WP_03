<?php

namespace MasterStudy\Lms\Pro\AddonsPlus\Notifications\Elementor;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Widget_Base;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class NotificationsWidget extends Widget_Base {
	public function get_name() {
		return 'masterstudy_notifications';
	}

	public function get_title() {
		return esc_html__( 'Notifications', 'masterstudy-lms-learning-management-system-pro' );
	}

	public function get_icon() {
		return 'stmlms-bell-outlined lms-icon';
	}

	public function get_categories() {
		return array( 'stm_lms' );
	}

	public function get_style_depends() {
		return array( 'masterstudy-notifications-elementor' );
	}

	public function get_script_depends() {
		return array( 'masterstudy-notifications-elementor' );
	}

	protected function register_controls() {
		$this->start_controls_section(
			'content_section',
			array(
				'label' => esc_html__( 'Notifications', 'masterstudy-lms-learning-management-system-pro' ),
			)
		);

		$this->add_control(
			'show_label',
			array(
				'label'        => esc_html__( 'Show label', 'masterstudy-lms-learning-management-system-pro' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Show', 'masterstudy-lms-learning-management-system-pro' ),
				'label_off'    => esc_html__( 'Hide', 'masterstudy-lms-learning-management-system-pro' ),
				'return_value' => 'yes',
				'default'      => '',
			)
		);

		$this->add_control(
			'label',
			array(
				'label'     => esc_html__( 'Label', 'masterstudy-lms-learning-management-system-pro' ),
				'type'      => Controls_Manager::TEXT,
				'default'   => esc_html__( 'Notifications', 'masterstudy-lms-learning-management-system-pro' ),
				'condition' => array(
					'show_label' => 'yes',
				),
			)
		);

		$this->add_control(
			'popup_alignment',
			array(
				'label'   => esc_html__( 'Popup alignment', 'masterstudy-lms-learning-management-system-pro' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'right',
				'options' => array(
					'left'  => esc_html__( 'Left', 'masterstudy-lms-learning-management-system-pro' ),
					'right' => esc_html__( 'Right', 'masterstudy-lms-learning-management-system-pro' ),
				),
			)
		);

		$this->add_responsive_control(
			'alignment',
			array(
				'label'     => esc_html__( 'Alignment', 'masterstudy-lms-learning-management-system-pro' ),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => array(
					'flex-start' => array(
						'title' => esc_html__( 'Left', 'masterstudy-lms-learning-management-system-pro' ),
						'icon'  => 'eicon-text-align-left',
					),
					'center'     => array(
						'title' => esc_html__( 'Center', 'masterstudy-lms-learning-management-system-pro' ),
						'icon'  => 'eicon-text-align-center',
					),
					'flex-end'   => array(
						'title' => esc_html__( 'Right', 'masterstudy-lms-learning-management-system-pro' ),
						'icon'  => 'eicon-text-align-right',
					),
				),
				'default'   => 'flex-end',
				'selectors' => array(
					'{{WRAPPER}} .masterstudy-notifications-elementor' => 'justify-content: {{VALUE}};',
				),
			)
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'trigger_style_section',
			array(
				'label' => esc_html__( 'Trigger', 'masterstudy-lms-learning-management-system-pro' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_responsive_control(
			'trigger_size',
			array(
				'label'      => esc_html__( 'Size', 'masterstudy-lms-learning-management-system-pro' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array(
					'px' => array(
						'min' => 32,
						'max' => 96,
					),
				),
				'default'    => array(
					'unit' => 'px',
					'size' => 44,
				),
				'selectors'  => array(
					'{{WRAPPER}} .masterstudy-notifications-elementor__trigger' => 'min-width: {{SIZE}}{{UNIT}}; min-height: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_responsive_control(
			'icon_size',
			array(
				'label'      => esc_html__( 'Icon size', 'masterstudy-lms-learning-management-system-pro' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array(
					'px' => array(
						'min' => 12,
						'max' => 48,
					),
				),
				'default'    => array(
					'unit' => 'px',
					'size' => 20,
				),
				'selectors'  => array(
					'{{WRAPPER}} .masterstudy-notifications-elementor__icon' => 'font-size: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_control(
			'trigger_color',
			array(
				'label'     => esc_html__( 'Icon and label color', 'masterstudy-lms-learning-management-system-pro' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#4d5e6f',
				'selectors' => array(
					'{{WRAPPER}} .masterstudy-notifications-elementor__trigger' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'trigger_hover_color',
			array(
				'label'     => esc_html__( 'Hover color', 'masterstudy-lms-learning-management-system-pro' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#227aff',
				'selectors' => array(
					'{{WRAPPER}} .masterstudy-notifications-elementor__trigger:hover, {{WRAPPER}} .masterstudy-notifications-elementor_open .masterstudy-notifications-elementor__trigger' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'trigger_background',
			array(
				'label'     => esc_html__( 'Background', 'masterstudy-lms-learning-management-system-pro' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .masterstudy-notifications-elementor__trigger' => 'background-color: {{VALUE}};',
				),
			)
		);

		$this->add_responsive_control(
			'trigger_border_radius',
			array(
				'label'      => esc_html__( 'Border radius', 'masterstudy-lms-learning-management-system-pro' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%' ),
				'default'    => array(
					'top'      => 4,
					'right'    => 4,
					'bottom'   => 4,
					'left'     => 4,
					'unit'     => 'px',
					'isLinked' => true,
				),
				'selectors'  => array(
					'{{WRAPPER}} .masterstudy-notifications-elementor__trigger' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'      => 'label_typography',
				'selector'  => '{{WRAPPER}} .masterstudy-notifications-elementor__label',
				'condition' => array(
					'show_label' => 'yes',
				),
			)
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'badge_style_section',
			array(
				'label' => esc_html__( 'Badge', 'masterstudy-lms-learning-management-system-pro' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'badge_background',
			array(
				'label'     => esc_html__( 'Background', 'masterstudy-lms-learning-management-system-pro' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#e42652',
				'selectors' => array(
					'{{WRAPPER}} .masterstudy-notifications-elementor__badge' => 'background-color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'badge_color',
			array(
				'label'     => esc_html__( 'Text color', 'masterstudy-lms-learning-management-system-pro' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => array(
					'{{WRAPPER}} .masterstudy-notifications-elementor__badge' => 'color: {{VALUE}};',
				),
			)
		);

		$this->end_controls_section();
	}

	protected function render() {
		$is_editor = class_exists( '\\Elementor\\Plugin' )
			&& \Elementor\Plugin::$instance->editor
			&& \Elementor\Plugin::$instance->editor->is_edit_mode();

		if ( ! is_user_logged_in() || ! masterstudy_lms_notifications_is_frontend_allowed() ) {
			if ( $is_editor ) {
				echo '<div class="masterstudy-notifications-elementor__editor-notice">';
				echo esc_html__( 'Enable at least one on-site notification to display this widget.', 'masterstudy-lms-learning-management-system-pro' );
				echo '</div>';
			}

			return;
		}

		$settings               = $this->get_settings_for_display();
		$labels                 = masterstudy_lms_notifications_account_labels();
		$unread_count           = masterstudy_lms_notifications_unread_count();
		$formatted_unread_count = $unread_count > 99 ? '99+' : (string) $unread_count;
		$popup_alignment        = 'left' === ( $settings['popup_alignment'] ?? '' ) ? 'left' : 'right';
		$panel_id               = 'masterstudy-notifications-elementor-panel-' . $this->get_id();
		$show_label             = 'yes' === ( $settings['show_label'] ?? '' );
		$label                  = ! empty( $settings['label'] ) ? $settings['label'] : $labels['notifications'];

		masterstudy_lms_notifications_localize_elementor_assets( $unread_count );
		?>
		<div class="masterstudy-notifications-elementor masterstudy-notifications-elementor_panel-<?php echo esc_attr( $popup_alignment ); ?>" data-masterstudy-notifications-elementor>
			<button type="button" class="masterstudy-notifications-elementor__trigger" data-masterstudy-notifications-elementor-open aria-expanded="false" aria-controls="<?php echo esc_attr( $panel_id ); ?>" aria-label="<?php echo esc_attr( $labels['notifications'] ); ?>">
				<span class="masterstudy-notifications-elementor__icon-wrap">
					<i class="masterstudy-notifications-elementor__icon stmlms-bell-outlined" aria-hidden="true"></i>
					<span class="masterstudy-notifications-elementor__badge masterstudy-notifications-account__count<?php echo 0 === $unread_count ? ' masterstudy-notifications-account__count_hidden' : ''; ?>" data-masterstudy-notifications-count>
						<?php echo esc_html( $formatted_unread_count ); ?>
					</span>
				</span>
				<?php if ( $show_label ) : ?>
					<span class="masterstudy-notifications-elementor__label"><?php echo esc_html( $label ); ?></span>
				<?php endif; ?>
			</button>

			<div id="<?php echo esc_attr( $panel_id ); ?>" class="masterstudy-notifications-account__panel" data-masterstudy-notifications-elementor-panel role="dialog" aria-label="<?php echo esc_attr( $labels['notifications'] ); ?>" aria-hidden="true" inert hidden>
				<div class="masterstudy-notifications-account__panel-header">
					<div class="masterstudy-notifications-account__title"><?php echo esc_html( $labels['notifications'] ); ?></div>
					<button type="button" class="masterstudy-notifications-account__mark-read" data-masterstudy-notifications-mark-all-read>
						<?php echo esc_html( $labels['mark_all_read'] ); ?>
					</button>
				</div>
				<div class="masterstudy-notifications-account__tabs" role="tablist" aria-label="<?php echo esc_attr( $labels['notifications'] ); ?>">
					<button type="button" class="masterstudy-notifications-account__tab masterstudy-notifications-account__tab_active" data-masterstudy-notifications-tab="all" role="tab" aria-selected="true">
						<?php echo esc_html( $labels['all'] ); ?>
					</button>
					<button type="button" class="masterstudy-notifications-account__tab" data-masterstudy-notifications-tab="unread" role="tab" aria-selected="false">
						<?php echo esc_html( $labels['unread'] ); ?>
					</button>
				</div>
				<?php \STM_LMS_Templates::show_lms_template( 'account/parts/notifications/list', array() ); ?>
			</div>
		</div>
		<?php
	}
}
