'use strict';


var CustomFacebookFeedElementor = window.CustomFacebookFeedElementor || ( function( document, window, $ ) {

	var vars = {};

	var app = {

		init: function() {
			app.events();
		},

		events: function() {

			var registerHooks = function() {
				// Legacy "cff-widget": this script owns its init (cff_init).
				elementorFrontend.hooks.addAction('frontend/element_ready/cff-widget.default', app.frontendWidgetInit);
				// Modern "sb-facebook-feed": the shared framework already runs
				// cff_init, so we only heal the masonry layout here.
				elementorFrontend.hooks.addAction('frontend/element_ready/sb-facebook-feed.default', app.scheduleMasonryHeal);
				if( 'undefined' !== typeof elementor ){
					elementor.hooks.addAction( 'panel/open_editor/widget/cff-widget', app.widgetPanelOpen );
				}
			};

			if ( window.elementorFrontend && window.elementorFrontend.hooks ) {
				registerHooks();
			} else {
				$( window ).on( 'elementor/frontend/init', registerHooks );
			}

		},

		CffInitWidget: function() {
			if ( typeof window.cff_init === 'function' ) {
				window.cff_init();
				if( jQuery('#cff.cff-lb').length && jQuery('#cff-lightbox-wrapper').length == 0) cffLightbox();
			}

			app.scheduleMasonryHeal();
		},

		// In the Chromium preview iframe the masonry layout collapses: masonry
		// itemizes 0 items and pins .cff-posts-wrap at height:0, so the posts
		// overflow and overlap each other and the Load-more button. We re-run
		// the REAL masonry layout (see recomputeMasonry/patchItemFilter) rather
		// than substituting a CSS layout that fights masonry's positioning.
		//
		// cff-scripts.js re-runs cffAddMasonry() on its own timers and on
		// resize, any of which can re-collapse the wrap after our retries fire,
		// so a MutationObserver re-heals for the whole editor session. Firefox /
		// the live frontend lay out fine, so this is preview + Chromium only.
		scheduleMasonryHeal: function () {
			if ( ! app.isChromium() ) { return; }
			app.healMasonry();
			setTimeout( app.healMasonry, 500 );
			setTimeout( app.healMasonry, 1500 );
			app.startMasonryObserver();
		},

		// Connect a single debounced observer that re-heals collapsed feeds
		// whenever the preview DOM changes. The height guard in healMasonry()
		// makes each pass near-free once a feed is laid out, so it converges.
		_masonryObserverStarted: false,
		startMasonryObserver: function () {
			if ( app._masonryObserverStarted ) { return; }
			if ( ! window.MutationObserver || ! document.body ) { return; }
			app._masonryObserverStarted = true;

			var t;
			var mo = new MutationObserver( function () {
				clearTimeout( t );
				t = setTimeout( app.healMasonry, 250 );
			} );
			mo.observe( document.body, { childList: true, subtree: true } );
		},

		// Chromium-based only (Chrome/Edge/Opera). Firefox renders the preview
		// masonry fine. A UA test is more reliable than the non-standard
		// window.chrome, which is undefined in some headless Chromium.
		isChromium: function () {
			return /Chrome\//.test( navigator.userAgent ) || /Edg\//.test( navigator.userAgent );
		},

		// masonry collapses a failed layout to ~0px; anything taller is healthy.
		MASONRY_COLLAPSED_HEIGHT_PX: 50,

		// Re-run the real masonry layout on one feed's live .cff-posts-wrap.
		recomputeMasonry: function ( $wrap, $cff ) {
			var wrap = $wrap.get( 0 );

			// Drop the height masonry pinned while collapsed; layout recomputes
			// it from the real item heights.
			wrap.style.height = '';
			wrap.style.minHeight = '';

			if ( typeof $wrap.masonry !== 'function' ) { return; }

			// Determine the correct itemSelector for THIS feed. window.cffMasonrySettings
			// is a shared global that cffAddMasonry() rewrites per feed/init, so a
			// stale instance can end up itemizing the wrong selector (e.g. the
			// '.cff-album-item' default against a post feed) and find 0 items.
			var itemSelector = $cff.find( '.cff-album-item' ).length && ! $cff.find( '.cff-item' ).length
				? '.cff-album-item, .cff-likebox'
				: '.cff-new, .cff-item, .cff-likebox';

			// Clean re-init bound to the current wrap + children, then patch the
			// instance's element filter (see patchItemFilter) before itemizing.
			try {
				if ( $wrap.data( 'masonry' ) ) {
					$wrap.masonry( 'destroy' );
				}
				$wrap.masonry( {
					itemSelector: itemSelector,
					transitionDuration: 0,
					percentPosition: true
				} );
				app.patchItemFilter( $wrap.data( 'masonry' ) );
				$wrap.masonry( 'reloadItems' );
				$wrap.masonry( 'layout' );
			} catch ( e ) {}
		},

		// The framework's Elementor editor injects the feed as DOM nodes from
		// the PARENT window's realm. Masonry runs inside this preview iframe and
		// filters items with `node instanceof HTMLElement` -- which is false for
		// cross-realm nodes -- so it itemizes 0 items and lays the feed out to
		// height 0. Replace the instance's element filter with a realm-agnostic
		// one (nodeType + matches) so the items are found regardless of realm.
		patchItemFilter: function ( inst ) {
			if ( ! inst || inst._cffItemFilterPatched ) { return; }
			inst._cffItemFilterPatched = true;
			inst._filterFindItemElements = function ( elems ) {
				var selector = this.options.itemSelector;
				var found = [];
				Array.prototype.forEach.call( elems || [], function ( el ) {
					if ( ! el || el.nodeType !== 1 ) { return; }
					if ( ! selector ) { found.push( el ); return; }
					if ( el.matches && el.matches( selector ) ) { found.push( el ); }
					var kids = el.querySelectorAll ? el.querySelectorAll( selector ) : [];
					for ( var i = 0; i < kids.length; i++ ) { found.push( kids[ i ] ); }
				} );
				return found;
			};
		},

		// Heal every collapsed JS-masonry feed in the preview. Only feeds with
		// the cff-masonry-js class are touched, so grid/list/carousel feeds --
		// and CSS-only masonry (cff-masonry-css) -- are left alone.
		healMasonry: function () {
			if ( ! app.isChromium() ) { return; }

			jQuery( '.cff.cff-masonry-js' ).each( function () {
				var $cff = jQuery( this );
				if ( $cff.hasClass( 'cff-masonry-css' ) ) { return; } // CSS-only masonry, untouched

				// id="cff" is reused by every feed, so scope the wrap to THIS
				// container instead of looking it up by id.
				var $wrap = $cff.find( '.cff-posts-wrap' ).first();
				if ( ! $wrap.length || ! $wrap.children().length ) { return; }
				if ( $wrap.height() > app.MASONRY_COLLAPSED_HEIGHT_PX ) { return; } // already laid out

				app.recomputeMasonry( $wrap, $cff );

				// Backstop: any image still loading skews the measurement, so
				// re-pack when it finishes.
				$wrap.find( 'img' ).each( function () {
					if ( ! this.complete ) {
						this.addEventListener( 'load', function () {
							try {
								$wrap.masonry( 'reloadItems' );
								$wrap.masonry( 'layout' );
							} catch ( e ) {}
						}, { once: true } );
					}
				} );
			} );
		},

		registerWidgetEvents: function( $scope ) {
			$scope
				.on( 'change', '.sb-elementor-cta-feedselector', app.selectFeedInPreview );

		},

		frontendWidgetInit : function( $scope ){
			app.CffInitWidget();
			app.registerWidgetEvents( $scope );
		},

		findFeedSelector: function( event ) {

			vars.$select = event && event.$el ?
				event.$el.closest( '#elementor-controls' ).find( 'select[data-setting="feed_id"]' ) :
				window.parent.jQuery( '#elementor-controls select[data-setting="feed_id"]' );
		},


		selectFeedInPreview : function( event ){

			vars.feedId = $( this ).val();

			app.findFeedSelector();

			vars.$select.val( vars.feedId ).trigger( 'change' );

		},


		widgetPanelOpen: function( panel, model ) {
			panel.$el.find( '.elementor-control.elementor-control-feed_id' ).find( 'select' ).on( 'change', function(){
				setTimeout(function(){
					app.CffInitWidget();
				}, 4000)
			});
		},



	};

	return app;



}( document, window, jQuery ) );


CustomFacebookFeedElementor.init();
