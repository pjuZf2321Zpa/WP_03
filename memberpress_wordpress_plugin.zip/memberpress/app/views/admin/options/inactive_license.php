<?php
/**
 * View admin/options/inactive_license.
 *
 * @var MemberPress\GroundLevel\Mothership\Manager\LicenseManager $license_manager
 */

defined('ABSPATH') || exit;
?>

<p class="description">
  <?php
    printf(
      // Translators: %1$s: opening link tag for website, %2$s: closing link tag, %3$s: opening link tag for login, %4$s: closing link tag.
        esc_html__('A License Key is required to enable automatic updates for MemberPress, access admin areas, and receive support. If you don\'t have a license, please %1$svisit our website%2$s to get one. If you already have a license, you can %3$slog in to your account%4$s to manage your licenses and site activations.', 'memberpress'),
        '<a href="' . esc_url(MeprUtils::get_link_url('home')) . '">',
        '</a>',
        '<a href="' . esc_url(MeprUtils::get_link_url('login')) . '">',
        '</a>'
    );
    ?>
</p>

<br />

<?php echo $license_manager->generateActivationForm(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
