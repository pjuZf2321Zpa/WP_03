<?php if (!defined('ABSPATH')) {
    die('You are not allowed to call this page directly.');
} ?>
<div id="header" style="width: 680px; padding: 0px; margin: 0 auto; text-align: left;">
  <h1 style="font-size: 30px; margin-bottom: 0;"><?php echo esc_html_x('Order Receipt', 'email', 'memberpress'); ?></h1>
  <h2 style="margin-top: 0; color: #999; font-weight: normal;"><?php echo esc_html_x('Order #{$order_id}', 'email', 'memberpress'); ?></h2>
</div>
<div id="body" style="width: 600px; background: white; padding: 40px; margin: 0 auto; text-align: left;">

  <p style="font-size: 16px;"><?php echo esc_html_x('Hi {$user_first_name},', 'email', 'memberpress'); ?></p>
  <p><?php echo esc_html_x('Thank you for your order. Here\'s your receipt:', 'email', 'memberpress'); ?></p>

  {$order_items}

  <table style="clear: both; width: 100%;" class="transaction">
    <tr><th style="text-align: left;"><?php echo esc_html_x('Order Date:', 'email', 'memberpress'); ?></th><td>{$order_date}</td></tr>
    <tr><th style="text-align: left;"><?php echo esc_html_x('Payment Method:', 'email', 'memberpress'); ?></th><td>{$payment_method}</td></tr>
    <tr><th style="text-align: left;"><?php echo esc_html_x('Order Total:', 'email', 'memberpress'); ?></th><td><strong>{$order_total}</strong></td></tr>
  </table>

  <table style="clear: both; width: 100%; margin-top: 24px;" class="labels">
    <tr>
      <td style="vertical-align: top;">
        <fieldset style="border: none; border-top: 1px solid #dedede; margin: 20px 40px 20px 0;" class="billing">
          <legend style="display: block; font-weight: bold; color: #999;"><?php echo esc_html_x('Billed to', 'email', 'memberpress'); ?></legend>
          <address style="font-style: normal;">
            <div class="address_name" style="display: block; font-size: 115%;"><big>{$user_first_name} {$user_last_name}</big></div>
            <div class="address_email" style="display: block;">{$user_email}</div>
          </address>
        </fieldset>
      </td>
    </tr>
  </table>

</div>
