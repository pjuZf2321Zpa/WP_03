<?php

namespace MasterStudy\Lms\Pro\AddonsPlus\Calendar;

use MasterStudy\Lms\Plugin;
use MasterStudy\Lms\Plugin\Addon;
use MasterStudy\Lms\Plugin\Addons;

final class Calendar implements Addon {
	public function get_name(): string {
		return defined( Addons::class . '::CALENDAR' )
			? Addons::CALENDAR
			: 'calendar';
	}

	public function register( Plugin $plugin ): void {
		$plugin->load_file( __DIR__ . '/filters.php' );
		$plugin->get_router()->load_routes( __DIR__ . '/routes.php' );
	}
}
