<?php

namespace FluentCartPro\App\Modules\SavedPaymentMethods\PayPal;

use FluentCart\App\Models\Customer;
use FluentCart\App\Modules\PaymentMethods\PayPalGateway\API\API;
use FluentCart\App\Services\Payments\PaymentHelper;
use FluentCart\Framework\Support\Arr;
use FluentCartPro\App\Modules\SavedPaymentMethods\SavedPaymentMethodRepository;

/**
 * Persists a vaulted PayPal account to the CUSTOMER's saved_payment_method meta.
 *
 * Core already vaults PayPal accounts, but only ever writes the token to a
 * SUBSCRIPTION (Processor::maybePersistVaultToken — which early-returns unless the
 * transaction belongs to a system subscription, so it never fires for the one-time
 * orders this module cares about). Nothing writes the per-customer record; this is
 * the PayPal counterpart of core's Stripe writer
 * (StripeGateway\Confirmations::savePaymentMethodToCustomerMeta).
 *
 * The captured order is re-fetched rather than passed in: the two core call sites
 * that hold the captured body (PayPal.php AJAX confirmation, IPN webhook) expose no
 * hook, and order_paid is the one place guaranteed to fire exactly once for a paid
 * order. The Stripe sibling re-fetches its PaymentIntent for the same reason.
 */
class PayPalSavedMethodWriter
{
    const GATEWAY = 'paypal';

    /**
     * @param Customer $customer
     * @param \FluentCart\App\Models\OrderTransaction $transaction
     * @return bool true when a record was written (or already present)
     */
    public function persist(Customer $customer, $transaction): bool
    {
        $paypalOrderId = Arr::get($transaction->meta ?? [], 'paypal_order_id');
        if (!$paypalOrderId) {
            return false;
        }

        $paypalOrder = API::verifyPayment($paypalOrderId);
        if (is_wp_error($paypalOrder) || !is_array($paypalOrder)) {
            return false;
        }

        $card = $this->normalize($paypalOrder);
        if (!$card) {
            // No vault token on the captured order. Either the buyer declined the
            // save agreement in PayPal's UI, or the account silently ignored the
            // vault attributes because it is not approved for vaulting. Neither
            // fails the purchase.
            //
            // The two are distinguishable: a declined agreement still returns a
            // payment_source.paypal block for the account that paid, whereas a
            // rejected vault comes back with no vault container at all. Only the
            // latter is a merchant configuration problem worth reporting.
            if (!Arr::has($paypalOrder, 'payment_source.paypal.attributes.vault')) {
                (new PayPalVaultCapability())->markUnavailable(
                    __('PayPal completed the order but returned no saved payment method.', 'fluent-cart-pro')
                );
            }

            return false;
        }

        // A save came back, so this account can vault after all — clear any
        // earlier verdict rather than leaving the feature switched off.
        (new PayPalVaultCapability())->markAvailable();

        return $this->store($customer, $card, Arr::get($paypalOrder, 'payment_source.paypal.attributes.vault.customer.id', ''));
    }

    /**
     * Pull the vault token and display fields off a captured Orders-v2 order.
     * Field paths mirror core's Processor::maybePersistVaultToken so the two
     * writers cannot drift on where PayPal puts things.
     *
     * @return array|null
     */
    private function normalize(array $paypalOrder)
    {
        $tokenId = Arr::get($paypalOrder, 'payment_source.paypal.attributes.vault.id', '');
        if (!$tokenId) {
            return null;
        }

        $payerEmail = Arr::get($paypalOrder, 'payment_source.paypal.email_address', '');
        if (!$payerEmail) {
            $payerEmail = Arr::get($paypalOrder, 'payer.email_address', '');
        }

        $payerName = trim(
            Arr::get($paypalOrder, 'payer.name.given_name', '') . ' ' .
            Arr::get($paypalOrder, 'payer.name.surname', '')
        );

        $details = Arr::get(PaymentHelper::parsePaymentMethodDetails('paypal', [
            'email'    => $payerEmail,
            'payer_id' => Arr::get($paypalOrder, 'payer.payer_id', ''),
            'name'     => $payerName,
        ]), 'details', []);

        // Stored in the same per-card shape the reader already normalizes. A PayPal
        // account has no brand/last4/expiry, so those keys are deliberately absent
        // rather than blank — the reader emits null and the UI renders a PayPal row.
        return [
            'id'       => sanitize_text_field($tokenId),
            'type'     => 'paypal',
            'email'    => Arr::get($details, 'email', ''),
            'payer_id' => Arr::get($details, 'payer_id', ''),
            'name'     => sanitize_text_field($payerName),
        ];
    }

    /**
     * Append to the paypal branch of saved_payment_method, deduped by token id.
     *
     * PayPal has no card-fingerprint equivalent, so the vault token id is the only
     * stable identity available — the same account vaulted twice yields two tokens
     * and would show twice. Dedupe additionally on payer_id to collapse that.
     */
    private function store(Customer $customer, array $card, $vaultCustomerId): bool
    {
        $meta = $customer->getMeta(SavedPaymentMethodRepository::META_KEY);
        if (!is_array($meta)) {
            $meta = [];
        }

        $branch = Arr::get($meta, self::GATEWAY, []);
        if (!is_array($branch)) {
            $branch = [];
        }

        $methods = Arr::get($branch, 'payment_methods', []);
        if (!is_array($methods)) {
            $methods = [];
        }

        foreach ($methods as $existing) {
            if (!is_array($existing)) {
                continue;
            }
            if (Arr::get($existing, 'id') === $card['id']) {
                return true; // already stored (webhook/AJAX race)
            }
            if ($card['payer_id'] && Arr::get($existing, 'payer_id') === $card['payer_id']) {
                return true; // same PayPal account, new token — do not list twice
            }
        }

        $methods[] = $card;

        $branch['payment_methods'] = $methods;
        if ($vaultCustomerId) {
            $branch['customer_id'] = sanitize_text_field($vaultCustomerId);
        }

        $meta[self::GATEWAY] = $branch;
        $customer->updateMeta(SavedPaymentMethodRepository::META_KEY, $meta);

        do_action('fluent_cart/saved_payment_method/saved', [
            'customer_id' => $customer->id,
            'gateway'     => self::GATEWAY,
            'token_id'    => $card['id'],
        ]);

        return true;
    }
}
