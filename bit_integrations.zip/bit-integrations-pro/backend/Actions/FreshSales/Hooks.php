<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Actions\FreshSales\FreshSalesRecordApiHelper;
use BitApps\IntegrationsPro\Config;
use BitApps\IntegrationsPro\Core\Util\Hooks;

// Deprecated since v2.7.8 - use bit_integrations_freshsales_* hooks instead
if (bit_integrations_version_below('2.7.8')) {
    Hooks::filter('btcbi_freshsales_upsert_record', [FreshSalesRecordApiHelper::class, 'upsertRecord'], 10, 5);
}

// New hooks since v2.7.8
Hooks::filter(Config::withFreePrefix('freshsales_upsert_record'), [FreshSalesRecordApiHelper::class, 'upsertRecord'], 10, 5);
