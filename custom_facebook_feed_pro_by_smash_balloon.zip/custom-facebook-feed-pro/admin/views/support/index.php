<div id="cff-support" class="cff-support">
	<?php
		CustomFacebookFeed\CFF_View::render('sections.header');
	?>
	<main>
	<?php
		CustomFacebookFeed\CFF_View::render('support.content');
	?>
	</main>

	<?php
		include_once CFF_BUILDER_DIR . 'templates/sections/popup/license-learn-more.php';
		include_once CFF_BUILDER_DIR . 'templates/sections/popup/why-renew-license-popup.php';
	?>
</div>