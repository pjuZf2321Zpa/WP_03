<?php

namespace FluentCartPro\App\Hooks\Handlers\BlockEditors\OrderBumpBlocks;

/**
 * The "Added" note of a cart card. It shows once the offer is in the cart, in the same
 * swap as the Remove button.
 */
class OrderBumpAddedBlockEditor extends OrderBumpBlockEditor
{
    protected static string $editorName = 'order-bump-added';

    public function getScripts(): array
    {
        return [
            [
                'source'       => 'admin/BlockEditor/OrderBumpBlocks/OrderBumpAddedBlockEditor.jsx',
                'dependencies' => ['wp-blocks', 'wp-components', 'wp-block-editor']
            ]
        ];
    }

    public function localizeData(): array
    {
        return [
            $this->getLocalizationKey() => [
                'slug'        => $this->slugPrefix,
                'name'        => static::getEditorName(),
                'title'       => __('Order Bump Added Note', 'fluent-cart-pro'),
                'description' => __('The note that shows when the offer is in the cart.', 'fluent-cart-pro'),
            ],
            'fluent_cart_block_translation' => \FluentCart\App\Services\Translations\TransStrings::blockStrings(),
        ];
    }

    public function blockAttributes(): array
    {
        return [
            'label' => ['type' => 'string', 'default' => 'Added'],
        ];
    }

    public function render(array $attrs, $block = null, $content = ''): string
    {
        $bump = $this->bump($block);
        if (!$bump) {
            return '';
        }

        $label = !empty($attrs['label']) ? $attrs['label'] : __('Added', 'fluent-cart-pro');
        $attributes = ['class' => 'fct_cart_bump_added', 'data-fct_show' => 'remove'];
        if (empty($bump['is_added'])) {
            $attributes['hidden'] = 'hidden';
        }

        // The wrapper attributes carry the block's colour, typography and spacing settings.
        return '<span ' . get_block_wrapper_attributes($attributes) . '><span aria-hidden="true">&#10003;</span> ' . esc_html($label) . '</span>';
    }
}
