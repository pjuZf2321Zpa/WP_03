<?php
/**
 * LoginPress Pro plugin update notices and gating.
 *
 * - Inactive license + Pro update available: custom plugins list row.
 * - Active license + both free and Pro pending: block Pro until free is updated.
 *
 * @package LoginPress-pro
 * @since   6.2.3
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Update dependency and license renewal notices for LoginPress Pro.
 *
 * @since 6.2.3
 */
class LoginPress_Pro_Update_Dependency {

	/**
	 * Block reason: no gating.
	 *
	 * @var string
	 */
	const BLOCK_NONE = 'none';

	/**
	 * Block reason: update free (core) before Pro.
	 *
	 * @var string
	 */
	const BLOCK_CORE_FIRST = 'core_first';

	/**
	 * Block reason: inactive license; renew required.
	 *
	 * @var string
	 */
	const BLOCK_LICENSE = 'license';

	/**
	 * Free plugin basename.
	 *
	 * @var string
	 */
	const FREE_PLUGIN = 'loginpress/loginpress.php';

	/**
	 * Pro plugin basename.
	 *
	 * @var string
	 */
	const PRO_PLUGIN = 'loginpress-pro/loginpress-pro.php';

	/**
	 * Style handle.
	 *
	 * @var string
	 */
	const STYLE_HANDLE = 'loginpress-pro-plugin-update-notice';

	/**
	 * Script handle.
	 *
	 * @var string
	 */
	const SCRIPT_HANDLE = 'loginpress-pro-plugin-update-bulk';

	/**
	 * Singleton instance.
	 *
	 * @var self|null
	 */
	private static $instance = null;

	/**
	 * Boot hooks during Pro plugin initialization.
	 *
	 * @since 6.2.3
	 * @return self
	 */
	public static function loginpress_boot() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Register WordPress hooks.
	 *
	 * @since 6.2.3
	 */
	private function __construct() {
		add_filter( 'site_transient_update_plugins', array( $this, 'loginpress_strip_pro_package' ), 999, 1 );
		add_filter( 'pre_set_site_transient_update_plugins', array( $this, 'loginpress_strip_pro_package' ), 9999, 1 );
		add_action( 'load-plugins.php', array( $this, 'loginpress_suppress_core_update_row' ), 21 );
		add_action( 'admin_enqueue_scripts', array( $this, 'loginpress_enqueue_update_dependency_assets' ) );
		add_action( 'after_plugin_row_' . self::PRO_PLUGIN, array( $this, 'loginpress_render_plugin_update_row' ), 10, 2 );
		add_action( 'in_plugin_update_message-' . self::PRO_PLUGIN, array( $this, 'loginpress_append_core_first_message' ), 10, 2 );
	}

	/**
	 * Whether the user can update plugins.
	 *
	 * @since 6.2.3
	 * @return bool
	 */
	private function loginpress_user_can_update_plugins() {
		return current_user_can( 'update_plugins' );
	}

	/**
	 * Whether a plugin has a pending update in the transient.
	 *
	 * @since 6.2.3
	 * @param object|false $transient Plugin update transient.
	 * @param string       $basename  Plugin basename.
	 * @return bool
	 */
	private function loginpress_has_pending_update( $transient, $basename ) {
		return is_object( $transient )
			&& ! empty( $transient->response )
			&& is_array( $transient->response )
			&& isset( $transient->response[ $basename ] );
	}

	/**
	 * Determine why Pro updates are blocked.
	 *
	 * @since 6.2.3
	 * @param object|false|null $transient Plugin update transient; loads cached value when null.
	 * @return string One of BLOCK_* constants.
	 */
	public function loginpress_get_block_state( $transient = null ) {
		if ( null === $transient ) {
			$transient = get_site_transient( 'update_plugins' );
		}

		if ( ! $this->loginpress_has_pending_update( $transient, self::PRO_PLUGIN ) ) {
			return self::BLOCK_NONE;
		}

		if ( ! class_exists( 'LoginPress_Pro' ) || ! LoginPress_Pro::is_activated() ) {
			return self::BLOCK_LICENSE;
		}

		if ( $this->loginpress_has_pending_update( $transient, self::FREE_PLUGIN ) ) {
			return self::BLOCK_CORE_FIRST;
		}

		return self::BLOCK_NONE;
	}

	/**
	 * Strip Pro package when updates are blocked.
	 *
	 * @since 6.2.3
	 * @param mixed $transient update_plugins transient value.
	 * @return mixed
	 */
	public function loginpress_strip_pro_package( $transient ) {
		if ( self::BLOCK_NONE === $this->loginpress_get_block_state( $transient ) ) {
			return $transient;
		}

		if ( ! isset( $transient->response[ self::PRO_PLUGIN ] )
			|| ! is_object( $transient->response[ self::PRO_PLUGIN ] ) ) {
			return $transient;
		}

		$pro_update = $transient->response[ self::PRO_PLUGIN ];

		if ( property_exists( $pro_update, 'package' ) ) {
			$pro_update->package = false;
		}

		if ( property_exists( $pro_update, 'download_link' ) ) {
			$pro_update->download_link = '';
		}

		return $transient;
	}

	/**
	 * License settings tab URL.
	 *
	 * @since 6.2.3
	 * @return string
	 */
	private function loginpress_get_license_settings_url() {
		$url = esc_url( 'https://wpbrigade.com/account/' );

		/**
		 * Filters the license / renew URL in the inactive-license update notice.
		 *
		 * @since 6.2.3
		 *
		 * @param string $url Admin URL for the LoginPress Pro license tab.
		 */
		return apply_filters( 'loginpress_license_settings_url', $url );
	}

	/**
	 * Learn-more URL for an available Pro version.
	 *
	 * @since 6.2.3
	 * @param string $version Available Pro version.
	 * @return string
	 */
	private function loginpress_get_release_url( $version ) {
		$url = 'https://loginpress.pro/changelog/';

		/**
		 * Filters the release / changelog URL in the inactive-license update notice.
		 *
		 * @since 6.2.3
		 *
		 * @param string $url     Release URL.
		 * @param string $version Available Pro version number.
		 */
		return apply_filters( 'loginpress_release_url', $url, $version );
	}

	/**
	 * Plugins table column count.
	 *
	 * @since 6.2.3
	 * @return int
	 */
	private function loginpress_get_plugins_table_colspan() {
		$wp_list_table = _get_list_table( 'WP_Plugins_List_Table' );

		return $wp_list_table ? (int) $wp_list_table->get_column_count() : 4;
	}

	/**
	 * Active class for the Pro plugin row.
	 *
	 * @since 6.2.3
	 * @return string
	 */
	private function loginpress_get_pro_row_active_class() {
		return is_plugin_active( self::PRO_PLUGIN ) ? ' active' : '';
	}

	/**
	 * Remove default Pro update row when showing a custom notice row.
	 *
	 * The 'wp_plugin_update_row' action is registered during list-table render, so removal is
	 * deferred to after_plugin_row at priority 0 (before priority 10 callbacks).
	 *
	 * @since 6.2.3
	 * @return void
	 */
	public function loginpress_suppress_core_update_row() {
		if ( ! $this->loginpress_user_can_update_plugins() ) {
			return;
		}

		$state = $this->loginpress_get_block_state();

		if ( self::BLOCK_LICENSE !== $state
			&& ( is_multisite() || self::BLOCK_CORE_FIRST !== $state ) ) {
			return;
		}

		add_action(
			'after_plugin_row_' . self::PRO_PLUGIN,
			array( $this, 'loginpress_remove_default_plugin_update_row' ),
			0
		);
	}

	/**
	 * Unhook core update row so only the custom notice row is shown.
	 *
	 * @since 6.2.3
	 * @return void
	 */
	public function loginpress_remove_default_plugin_update_row() {
		remove_action( 'after_plugin_row_' . self::PRO_PLUGIN, 'wp_plugin_update_row', 10 );
	}

	/**
	 * Enqueue scoped admin assets on plugins.php and update-core.php.
	 *
	 * @since 6.2.3
	 * @param string $hook_suffix Current admin page hook suffix.
	 * @return void
	 */
	public function loginpress_enqueue_update_dependency_assets( $hook_suffix ) {
		if ( ! $this->loginpress_user_can_update_plugins() ) {
			return;
		}

		$version = defined( 'LOGINPRESS_PRO_VERSION' ) ? LOGINPRESS_PRO_VERSION : '6.2.4';
		$state   = $this->loginpress_get_block_state();

		if ( 'plugins.php' === $hook_suffix && self::BLOCK_LICENSE === $state ) {
			wp_enqueue_style(
				self::STYLE_HANDLE,
				plugins_url( 'assets/css/loginpress-plugin-update.css', LOGINPRESS_PRO_UPGRADE_PATH ),
				array(),
				$version
			);
		}

		if ( 'update-core.php' === $hook_suffix && self::BLOCK_NONE !== $state ) {
			wp_enqueue_script(
				self::SCRIPT_HANDLE,
				plugins_url( 'assets/js/loginpress-plugin-update.js', LOGINPRESS_PRO_UPGRADE_PATH ),
				array(),
				$version,
				true
			);

			wp_localize_script(
				self::SCRIPT_HANDLE,
				'loginpressProUpdateBulk',
				array(
					'proBasename' => self::PRO_PLUGIN,
				)
			);
		}
	}

	/**
	 * Append core-first message inside the default update row (multisite EDD row).
	 *
	 * @since 6.2.3
	 * @param array  $plugin_data Plugin data.
	 * @param object $response    Update response.
	 * @return void
	 */
	public function loginpress_append_core_first_message( $plugin_data, $response ) { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter.FoundAfterLastUsed -- WP callback signature.
		unset( $plugin_data, $response );

		if ( ! is_multisite() || self::BLOCK_CORE_FIRST !== $this->loginpress_get_block_state() ) {
			return;
		}

		echo ' <strong>' . esc_html__( 'Please update LoginPress before updating LoginPress Pro.', 'loginpress-pro' ) . '</strong>';
	}

	/**
	 * Render custom update row on plugins.php (license + single-site core-first).
	 *
	 * @since 6.2.3
	 * @param string $plugin_file Plugin basename.
	 * @param array  $plugin_data Plugin metadata.
	 * @return void
	 */
	public function loginpress_render_plugin_update_row( $plugin_file, $plugin_data ) { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter.FoundAfterLastUsed -- WP callback signature.
		unset( $plugin_data );

		if ( is_multisite() || ! $this->loginpress_user_can_update_plugins() || self::PRO_PLUGIN !== $plugin_file ) {
			return;
		}

		$state = $this->loginpress_get_block_state();

		if ( self::BLOCK_LICENSE === $state ) {
			$this->loginpress_render_license_notice_row();
			return;
		}

		if ( self::BLOCK_CORE_FIRST === $state ) {
			$this->loginpress_render_core_first_notice_row();
		}
	}

	/**
	 * Output inactive-license notice row (template).
	 *
	 * @since 6.2.3
	 * @return void
	 */
	private function loginpress_render_license_notice_row() {
		$transient = get_site_transient( 'update_plugins' );

		if ( ! $this->loginpress_has_pending_update( $transient, self::PRO_PLUGIN ) ) {
			return;
		}

		$pro_response = $transient->response[ self::PRO_PLUGIN ];
		$version      = isset( $pro_response->new_version ) ? (string) $pro_response->new_version : '';

		$loginpress_notice_data = array(
			'version'      => $version,
			'release_url'  => $this->loginpress_get_release_url( $version ),
			'renew_url'    => $this->loginpress_get_license_settings_url(),
			'colspan'      => $this->loginpress_get_plugins_table_colspan(),
			'active_class' => $this->loginpress_get_pro_row_active_class(),
		);

		$path = __DIR__ . '/update-core-dependency-notice.php';

		if ( is_readable( $path ) ) {
			include $path;
		}

		unset( $loginpress_notice_data );
	}

	/**
	 * Output core-first notice row on single-site (EDD removes default wp_plugin_update_row).
	 *
	 * @since 6.2.3
	 * @return void
	 */
	private function loginpress_render_core_first_notice_row() {
		$transient = get_site_transient( 'update_plugins' );

		if ( ! $this->loginpress_has_pending_update( $transient, self::PRO_PLUGIN ) ) {
			return;
		}

		$pro_response = $transient->response[ self::PRO_PLUGIN ];
		$version      = isset( $pro_response->new_version ) ? (string) $pro_response->new_version : '';
		$colspan      = $this->loginpress_get_plugins_table_colspan();
		$active_class = $this->loginpress_get_pro_row_active_class();

		$free_update_url = wp_nonce_url(
			self_admin_url( 'update.php?action=upgrade-plugin&plugin=' . rawurlencode( self::FREE_PLUGIN ) ),
			'upgrade-plugin_' . self::FREE_PLUGIN
		);

		?>
		<tr class="plugin-update-tr<?php echo esc_attr( $active_class ); ?>" id="loginpress-pro-update" data-slug="loginpress-pro" data-plugin="<?php echo esc_attr( self::PRO_PLUGIN ); ?>">
			<td colspan="<?php echo (int) $colspan; ?>" class="plugin-update colspanchange">
				<div class="update-message notice inline notice-warning notice-alt">
					<p>
					<?php
					printf(
						/* translators: %s: available Pro version number. */
						esc_html__( 'There is a new version of LoginPress Pro available (%s). ', 'loginpress-pro' ),
						esc_html( $version )
					);
					echo '<strong>' . esc_html__( 'Please update LoginPress before updating Pro. ', 'loginpress-pro' ) . '</strong>';
					printf(
						'<a href="%1$s">%2$s</a> ',
						esc_url( $free_update_url ),
						esc_html__( 'Update LoginPress', 'loginpress-pro' )
					);
					?>
					</p>
				</div>
			</td>
		</tr>
		<?php
	}
}
