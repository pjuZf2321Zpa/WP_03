<?php

namespace BitApps\IntegrationsPro\Actions\SecureCustomFields;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Pro side implementation of the Secure Custom Fields "update" actions.
 *
 * Each method receives the default $response (passed through from Free) and the
 * mapped $fieldData, and returns ['success' => bool, 'message' => string].
 */
final class SecureCustomFieldsRecordHelper
{
    public static function updatePostAcfValue($response, $fieldData)
    {
        $missing = self::missingFields($fieldData, ['post_id', 'field_name', 'field_value']);

        if ($missing) {
            return self::error($missing);
        }

        $unavailable = self::functionsUnavailable();

        if ($unavailable) {
            return self::error($unavailable);
        }

        if (!self::persist($fieldData['field_name'], $fieldData['field_value'], \intval($fieldData['post_id']))) {
            return self::error(__('Failed to update Secure Custom Fields field. Please check the field name and post ID.', 'bit-integrations-pro'));
        }

        return self::success(__('Secure Custom Fields field updated successfully.', 'bit-integrations-pro'));
    }

    public static function updateUserAcfValue($response, $fieldData)
    {
        $missing = self::missingFields($fieldData, ['user_id', 'field_name', 'field_value']);

        if ($missing) {
            return self::error($missing);
        }

        $unavailable = self::functionsUnavailable();

        if ($unavailable) {
            return self::error($unavailable);
        }

        if (!self::persist($fieldData['field_name'], $fieldData['field_value'], 'user_' . \intval($fieldData['user_id']))) {
            return self::error(__('Failed to update Secure Custom Fields field. Please check the field name and user ID.', 'bit-integrations-pro'));
        }

        return self::success(__('Secure Custom Fields field updated successfully.', 'bit-integrations-pro'));
    }

    public static function updateOptionAcfValue($response, $fieldData)
    {
        $missing = self::missingFields($fieldData, ['field_name', 'field_value']);

        if ($missing) {
            return self::error($missing);
        }

        $unavailable = self::functionsUnavailable();

        if ($unavailable) {
            return self::error($unavailable);
        }

        if (!self::persist($fieldData['field_name'], $fieldData['field_value'], 'option')) {
            return self::error(__('Failed to update Secure Custom Fields option field. Please check the field name.', 'bit-integrations-pro'));
        }

        return self::success(__('Secure Custom Fields option field updated successfully.', 'bit-integrations-pro'));
    }

    public static function updateGroupFieldValue($response, $payload)
    {
        $missing = self::missingFields($payload, ['post_id', 'group_name']);

        if ($missing) {
            return self::error($missing);
        }

        if (empty($payload['fields']) || !\is_array($payload['fields'])) {
            return self::error(__('No group sub-fields are mapped. Please map at least one sub-field.', 'bit-integrations-pro'));
        }

        $unavailable = self::functionsUnavailable();

        if ($unavailable) {
            return self::error($unavailable);
        }

        $postId    = \intval($payload['post_id']);
        $groupName = $payload['group_name'];

        $groupData = get_field($groupName, $postId);

        if (!\is_array($groupData)) {
            $groupData = [];
        }

        foreach ($payload['fields'] as $subFieldName => $value) {
            $groupData[$subFieldName] = $value;
        }

        if (!self::persist($groupName, $groupData, $postId)) {
            return self::error(__('Failed to update Secure Custom Fields group field. Please check the group name and post ID.', 'bit-integrations-pro'));
        }

        return self::success(__('Secure Custom Fields group field updated successfully.', 'bit-integrations-pro'));
    }

    public static function updateRepeaterFieldValue($response, $payload)
    {
        $missing = self::missingFields($payload, ['post_id', 'repeater_name']);

        if ($missing) {
            return self::error($missing);
        }

        if (empty($payload['rows']) || !\is_array($payload['rows'])) {
            return self::error(__('No repeater rows are mapped. Please map at least one sub-field.', 'bit-integrations-pro'));
        }

        $unavailable = self::functionsUnavailable();

        if ($unavailable) {
            return self::error($unavailable);
        }

        $postId       = \intval($payload['post_id']);
        $repeaterName = $payload['repeater_name'];

        $repeaterData = get_field($repeaterName, $postId);

        if (!\is_array($repeaterData)) {
            $repeaterData = [];
        }

        foreach ($payload['rows'] as $rowIndex => $subFields) {
            if (!\is_array($subFields)) {
                continue;
            }

            if (!isset($repeaterData[$rowIndex]) || !\is_array($repeaterData[$rowIndex])) {
                $repeaterData[$rowIndex] = [];
            }

            foreach ($subFields as $subFieldName => $value) {
                $repeaterData[$rowIndex][$subFieldName] = $value;
            }
        }

        // ACF repeaters expect a sequential, 0-based list of rows.
        ksort($repeaterData);
        $repeaterData = array_values($repeaterData);

        if (!self::persist($repeaterName, $repeaterData, $postId)) {
            return self::error(__('Failed to update Secure Custom Fields repeater field. Please check the repeater name and post ID.', 'bit-integrations-pro'));
        }

        return self::success(__('Secure Custom Fields repeater field updated successfully.', 'bit-integrations-pro'));
    }

    /**
     * Write a value through Secure Custom Fields, treating an unchanged value as success.
     *
     * update_field() (via update_metadata()/update_option()) returns false both on a
     * real failure AND when the new value equals the stored one (a no-op). To avoid
     * reporting a false error for idempotent writes, a falsy return is reconciled
     * against a re-read of the stored value.
     *
     * @param string     $selector
     * @param mixed      $value
     * @param int|string $id
     *
     * @return bool
     */
    private static function persist($selector, $value, $id)
    {
        if (update_field($selector, $value, $id)) {
            return true;
        }

        // update_field() returns false on a no-op; confirm the stored value already matches.
        return get_field($selector, $id) == $value;
    }

    /**
     * Ensure the Secure Custom Fields read/write functions are available.
     *
     * @return string Error message when unavailable, '' otherwise.
     */
    private static function functionsUnavailable()
    {
        if (\function_exists('update_field') && \function_exists('get_field')) {
            return '';
        }

        return __('Secure Custom Fields functions are not available. Please ensure the Secure Custom Fields plugin is installed and activated.', 'bit-integrations-pro');
    }

    private static function missingFields($fieldData, array $required)
    {
        $missing = [];
        foreach ($required as $key) {
            if (!isset($fieldData[$key]) || $fieldData[$key] === '') {
                $missing[] = $key;
            }
        }

        if (empty($missing)) {
            return '';
        }

        // translators: %s: comma separated list of missing field names
        return wp_sprintf(__('Missing required fields: %s', 'bit-integrations-pro'), implode(', ', $missing));
    }

    private static function success($message)
    {
        return ['success' => true, 'message' => $message];
    }

    private static function error($message)
    {
        return ['success' => false, 'message' => $message];
    }
}
