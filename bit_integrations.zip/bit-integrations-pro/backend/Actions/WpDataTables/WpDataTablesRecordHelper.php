<?php

namespace BitApps\IntegrationsPro\Actions\WpDataTables;

final class WpDataTablesRecordHelper
{
    public static function addRow($response, $fieldData, $tableId = null)
    {
        if (!class_exists('WDTConfigController')) {
            return [
                'success' => false,
                'message' => __('wpDataTables is not installed or activated', 'bit-integrations-pro'),
            ];
        }

        if (empty($tableId) || !is_numeric($tableId)) {
            return [
                'success' => false,
                'message' => __('A valid table must be selected', 'bit-integrations-pro'),
            ];
        }

        if (empty($fieldData) || !\is_array($fieldData)) {
            return [
                'success' => false,
                'message' => __('No column data provided', 'bit-integrations-pro'),
            ];
        }

        $tableId = (int) $tableId;

        global $wpdb;
        $table = $wpdb->get_row(
            $wpdb->prepare("SELECT table_type, mysql_table_name, connection FROM {$wpdb->prefix}wpdatatables WHERE id = %d", $tableId)
        );

        if (!empty($table) && $table->table_type === 'manual') {
            return self::addManualRow($table, $tableId, $fieldData);
        }

        ksort($fieldData, SORT_REGULAR);

        $row = (object) [
            'cells' => array_values(
                array_map(
                    static function ($value) {
                        return (object) [
                            'data'   => $value,
                            'hidden' => false,
                            'type'   => 'text',
                            'meta'   => [],
                        ];
                    },
                    $fieldData
                )
            ),
        ];

        $inserted = $wpdb->insert(
            $wpdb->prefix . 'wpdatatables_rows',
            [
                'table_id' => $tableId,
                'data'     => wp_json_encode($row),
            ]
        );

        if (!$inserted) {
            return [
                'success' => false,
                'message' => __('Failed to insert row into wpDataTables', 'bit-integrations-pro'),
            ];
        }

        do_action('wpdatatables_before_create_row', $tableId, $row);
        do_action('wpdatatables_after_save_row');

        return [
            'success' => true,
            'message' => __('Row added successfully', 'bit-integrations-pro'),
            'data'    => array_merge(['id' => $wpdb->insert_id], $fieldData),
        ];
    }

    private static function addManualRow($table, $tableId, $fieldData)
    {
        global $wpdb;

        if (!empty($table->connection) || empty($table->mysql_table_name)) {
            return [
                'success' => false,
                'message' => __('Only manual tables stored in the WordPress database are supported', 'bit-integrations-pro'),
            ];
        }

        $columns = $wpdb->get_col(
            $wpdb->prepare("SELECT orig_header FROM {$wpdb->prefix}wpdatatables_columns WHERE table_id = %d AND id_column = 0 AND column_type <> 'formula'", $tableId)
        );

        $allowedColumns = array_flip($columns);
        $row = array_intersect_key($fieldData, $allowedColumns);

        if (empty($row)) {
            return [
                'success' => false,
                'message' => __('No valid column data provided', 'bit-integrations-pro'),
            ];
        }

        $user = wp_get_current_user();
        $userLogin = $user->exists() ? $user->user_login : 'anonymous_user';
        $now = current_time('mysql');
        $metaValues = [
            'wdt_created_by'     => $userLogin,
            'wdt_created_at'     => $now,
            'wdt_last_edited_by' => $userLogin,
            'wdt_last_edited_at' => $now,
        ];

        $row = array_intersect_key($metaValues, $allowedColumns) + $row;

        $inserted = $wpdb->insert($table->mysql_table_name, $row);

        if (!$inserted) {
            return [
                'success' => false,
                'message' => __('Failed to insert row into wpDataTables', 'bit-integrations-pro'),
            ];
        }

        return [
            'success' => true,
            'message' => __('Row added successfully', 'bit-integrations-pro'),
            'data'    => array_merge(['id' => $wpdb->insert_id], $row),
        ];
    }
}
