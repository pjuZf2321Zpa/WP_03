<?php

namespace BitApps\IntegrationsPro\Triggers\AvadaForms;

class AvadaFormsHelper
{
    public static function formatFields($formSubmission, $formId)
    {
        $helperClass = bit_integrations_get_class('Core\\Util\\Helper');
        $userClass = bit_integrations_get_class('Core\\Util\\User');

        $fields = ['form_id' => $formId];
        $fieldTypes = self::postedFieldTypes();
        $submissionsData = $formSubmission['data'] ?? [];

        foreach ($submissionsData as $key => $value) {
            $type = $fieldTypes[$key] ?? '';

            if ('submit' === $type) {
                continue;
            }

            if ('checkbox' === $type) {
                $value = ('' === $value) ? [''] : $value;
                $value = (\is_array($value) && 1 === \count($value)) ? $value[0] : wp_json_encode($value);
            }

            if (\is_array($value) || \is_object($value)) {
                $fields = $helperClass::flattenNestedData($fields, $key, $value);
            } else {
                $fields[$key] = $value;
            }
        }

        foreach ($formSubmission['submission'] ?? [] as $key => $value) {
            $fields['submission_' . $key] = $value;
        }

        $fields = array_merge($fields, $userClass::currentUser());

        return $helperClass::prepareFetchFormatFields($fields);
    }

    /**
     * Field name to field type map that Avada posts alongside the submission.
     *
     * Used only to look a type up; the submitted data decides which fields exist.
     *
     * @return array
     */
    private static function postedFieldTypes()
    {
        // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Avada verified the submission before firing fusion_form_submission_data.
        if (!isset($_POST['field_types'])) {
            return [];
        }

        // phpcs:ignore WordPress.Security.NonceVerification.Missing -- see above.
        $decoded = json_decode(wp_unslash($_POST['field_types']), true);

        if (!\is_array($decoded)) {
            return [];
        }

        $types = [];
        foreach ($decoded as $name => $type) {
            if (\is_scalar($type)) {
                $types[$name] = sanitize_text_field($type);
            }
        }

        return $types;
    }

    public static function isPluginInstalled()
    {
        return class_exists('Fusion_Builder_Form_Helper');
    }
}
