<?php

/**
 * SureContact Record Api.
 */

namespace BitApps\IntegrationsPro\Actions\SureContact;

/**
 * Every SureContact action runs here — the free plugin only builds the payload, owns the
 * connection and fires the hook. The ApiClient arrives already scoped to the connection.
 */
class SureContactHelperPro
{
    /**
     * slug => [verb, path template, body shaper].
     *
     * `{placeholder}` segments are filled from the field map and removed from the body,
     * so the identifier a user maps from trigger data never leaks into the payload.
     */
    private const ACTIONS = [
        'addContactsToList' => ['POST', '/lists/{list_uuid}/contacts/add', 'plain', ['list_uuid', 'contact_emails']],
        'addContactsToTag' => ['POST', '/tags/{tag_uuid}/contacts/add', 'plain', ['tag_uuid', 'contact_emails']],
        'attachContactsToTask' => ['POST', '/tasks/{task_uuid}/contacts/attach', 'plain', ['task_uuid', 'contact_emails']],
        'attachListsToContact' => ['POST', '/contacts/{contact_uuid}/lists/attach', 'plain', ['contact_email', 'list_uuids']],
        'attachTagsToContact' => ['POST', '/contacts/{contact_uuid}/tags/attach', 'plain', ['contact_email', 'tag_uuids']],
        'bulkDeleteCampaigns' => ['POST', '/campaigns/bulk-delete', 'plain', ['uuids']],
        'cancelPurchase' => ['POST', '/purchases/{purchase_uuid}/cancel', 'plain', ['purchase_uuid']],
        'copyList' => ['POST', '/lists/{list_uuid}/copy', 'plain', ['list_uuid', 'name']],
        'createCampaign' => ['POST', '/campaigns', 'plain', ['name']],
        'createContact' => ['POST', '/contacts', 'contact', ['email']],
        'createContactActivity' => ['POST', '/contacts/{contact_uuid}/activities', 'plain', ['contact_email', 'description']],
        'createContactNote' => ['POST', '/contacts/{contact_uuid}/notes', 'note', ['contact_email', 'content']],
        'createList' => ['POST', '/lists', 'plain', ['name']],
        'createPage' => ['POST', '/pages', 'plain', ['name']],
        'createPurchase' => ['POST', '/purchases', 'plain', ['contact_email', 'order_id', 'total_amount']],
        'createTag' => ['POST', '/tags', 'plain', ['name']],
        'createTask' => ['POST', '/tasks', 'plain', ['contact_emails', 'title']],
        'deleteCampaign' => ['DELETE', '/campaigns/{campaign_uuid}', 'plain', ['campaign_uuid']],
        'deleteContact' => ['DELETE', '/contacts/{contact_uuid}', 'plain', ['contact_email']],
        'deleteList' => ['DELETE', '/lists/{list_uuid}', 'plain', ['list_uuid']],
        'deleteNote' => ['DELETE', '/notes/{note_uuid}', 'plain', ['note_uuid']],
        'deletePage' => ['DELETE', '/pages/{page_uuid}', 'plain', ['page_uuid']],
        'deleteTag' => ['DELETE', '/tags/{tag_uuid}', 'plain', ['tag_uuid']],
        'deleteTask' => ['DELETE', '/tasks/{task_uuid}', 'plain', ['task_uuid']],
        'detachContactsFromTask' => ['POST', '/tasks/{task_uuid}/contacts/detach', 'plain', ['task_uuid', 'contact_emails']],
        'detachListsFromContact' => ['POST', '/contacts/{contact_uuid}/lists/detach', 'plain', ['contact_email', 'list_uuids']],
        'detachTagsFromContact' => ['POST', '/contacts/{contact_uuid}/tags/detach', 'plain', ['contact_email', 'tag_uuids']],
        'duplicateCampaign' => ['POST', '/campaigns/{campaign_uuid}/duplicate', 'plain', ['campaign_uuid']],
        'markTaskDone' => ['POST', '/tasks/{task_uuid}/done', 'plain', ['task_uuid']],
        'markTaskUndone' => ['POST', '/tasks/{task_uuid}/undone', 'plain', ['task_uuid']],
        'refundPurchase' => ['POST', '/purchases/{purchase_uuid}/refund', 'plain', ['purchase_uuid']],
        'removeContactsFromList' => ['POST', '/lists/{list_uuid}/contacts/remove', 'plain', ['list_uuid', 'contact_emails']],
        'removeContactsFromTag' => ['POST', '/tags/{tag_uuid}/contacts/remove', 'plain', ['tag_uuid', 'contact_emails']],
        'updateCampaign' => ['PUT', '/campaigns/{campaign_uuid}', 'plain', ['campaign_uuid']],
        'updateContact' => ['PUT', '/contacts/{contact_uuid}', 'contact', ['contact_email']],
        'updateContactStatus' => ['PATCH', '/contacts/{contact_uuid}/status', 'plain', ['contact_email']],
        'updateList' => ['PUT', '/lists/{list_uuid}', 'plain', ['list_uuid']],
        'updateNote' => ['PUT', '/notes/{note_uuid}', 'note', ['note_uuid', 'content']],
        'updatePage' => ['PUT', '/pages/{page_uuid}', 'plain', ['page_uuid']],
        'updateTag' => ['PUT', '/tags/{tag_uuid}', 'plain', ['tag_uuid', 'name']],
        'updateTask' => ['PUT', '/tasks/{task_uuid}', 'plain', ['task_uuid']],
        'upsertContact' => ['POST', '/contacts/upsert', 'contact', ['email']],
    ];

    /**
     * SureContact takes the standard contact attributes nested under `primary_fields`;
     * a flat body is rejected with "Primary fields are required."
     */
    private const CONTACT_PRIMARY_FIELDS = [
        'email', 'first_name', 'last_name', 'phone', 'company', 'job_title',
        'birthdate', 'gender', 'anniversary', 'prefix', 'suffix', 'timezone', 'language',
    ];

    public static function addContactsToList($response, $fieldData, $apiClient, $settings)
    {
        return self::run('addContactsToList', $fieldData, $apiClient, $settings);
    }

    public static function addContactsToTag($response, $fieldData, $apiClient, $settings)
    {
        return self::run('addContactsToTag', $fieldData, $apiClient, $settings);
    }

    public static function attachContactsToTask($response, $fieldData, $apiClient, $settings)
    {
        return self::run('attachContactsToTask', $fieldData, $apiClient, $settings);
    }

    public static function attachListsToContact($response, $fieldData, $apiClient, $settings)
    {
        return self::run('attachListsToContact', $fieldData, $apiClient, $settings);
    }

    public static function attachTagsToContact($response, $fieldData, $apiClient, $settings)
    {
        return self::run('attachTagsToContact', $fieldData, $apiClient, $settings);
    }

    public static function bulkDeleteCampaigns($response, $fieldData, $apiClient, $settings)
    {
        return self::run('bulkDeleteCampaigns', $fieldData, $apiClient, $settings);
    }

    public static function cancelPurchase($response, $fieldData, $apiClient, $settings)
    {
        return self::run('cancelPurchase', $fieldData, $apiClient, $settings);
    }

    public static function copyList($response, $fieldData, $apiClient, $settings)
    {
        return self::run('copyList', $fieldData, $apiClient, $settings);
    }

    public static function createCampaign($response, $fieldData, $apiClient, $settings)
    {
        return self::run('createCampaign', $fieldData, $apiClient, $settings);
    }

    public static function createContact($response, $fieldData, $apiClient, $settings)
    {
        return self::run('createContact', $fieldData, $apiClient, $settings);
    }

    public static function createContactActivity($response, $fieldData, $apiClient, $settings)
    {
        return self::run('createContactActivity', $fieldData, $apiClient, $settings);
    }

    public static function createContactNote($response, $fieldData, $apiClient, $settings)
    {
        return self::run('createContactNote', $fieldData, $apiClient, $settings);
    }

    public static function createList($response, $fieldData, $apiClient, $settings)
    {
        return self::run('createList', $fieldData, $apiClient, $settings);
    }

    public static function createPage($response, $fieldData, $apiClient, $settings)
    {
        return self::run('createPage', $fieldData, $apiClient, $settings);
    }

    public static function createPurchase($response, $fieldData, $apiClient, $settings)
    {
        return self::run('createPurchase', $fieldData, $apiClient, $settings);
    }

    public static function createTag($response, $fieldData, $apiClient, $settings)
    {
        return self::run('createTag', $fieldData, $apiClient, $settings);
    }

    public static function createTask($response, $fieldData, $apiClient, $settings)
    {
        return self::run('createTask', $fieldData, $apiClient, $settings);
    }

    public static function deleteCampaign($response, $fieldData, $apiClient, $settings)
    {
        return self::run('deleteCampaign', $fieldData, $apiClient, $settings);
    }

    public static function deleteContact($response, $fieldData, $apiClient, $settings)
    {
        return self::run('deleteContact', $fieldData, $apiClient, $settings);
    }

    public static function deleteList($response, $fieldData, $apiClient, $settings)
    {
        return self::run('deleteList', $fieldData, $apiClient, $settings);
    }

    public static function deleteNote($response, $fieldData, $apiClient, $settings)
    {
        return self::run('deleteNote', $fieldData, $apiClient, $settings);
    }

    public static function deletePage($response, $fieldData, $apiClient, $settings)
    {
        return self::run('deletePage', $fieldData, $apiClient, $settings);
    }

    public static function deleteTag($response, $fieldData, $apiClient, $settings)
    {
        return self::run('deleteTag', $fieldData, $apiClient, $settings);
    }

    public static function deleteTask($response, $fieldData, $apiClient, $settings)
    {
        return self::run('deleteTask', $fieldData, $apiClient, $settings);
    }

    public static function detachContactsFromTask($response, $fieldData, $apiClient, $settings)
    {
        return self::run('detachContactsFromTask', $fieldData, $apiClient, $settings);
    }

    public static function detachListsFromContact($response, $fieldData, $apiClient, $settings)
    {
        return self::run('detachListsFromContact', $fieldData, $apiClient, $settings);
    }

    public static function detachTagsFromContact($response, $fieldData, $apiClient, $settings)
    {
        return self::run('detachTagsFromContact', $fieldData, $apiClient, $settings);
    }

    public static function duplicateCampaign($response, $fieldData, $apiClient, $settings)
    {
        return self::run('duplicateCampaign', $fieldData, $apiClient, $settings);
    }

    public static function markTaskDone($response, $fieldData, $apiClient, $settings)
    {
        return self::run('markTaskDone', $fieldData, $apiClient, $settings);
    }

    public static function markTaskUndone($response, $fieldData, $apiClient, $settings)
    {
        return self::run('markTaskUndone', $fieldData, $apiClient, $settings);
    }

    public static function refundPurchase($response, $fieldData, $apiClient, $settings)
    {
        return self::run('refundPurchase', $fieldData, $apiClient, $settings);
    }

    public static function removeContactsFromList($response, $fieldData, $apiClient, $settings)
    {
        return self::run('removeContactsFromList', $fieldData, $apiClient, $settings);
    }

    public static function removeContactsFromTag($response, $fieldData, $apiClient, $settings)
    {
        return self::run('removeContactsFromTag', $fieldData, $apiClient, $settings);
    }

    public static function updateCampaign($response, $fieldData, $apiClient, $settings)
    {
        return self::run('updateCampaign', $fieldData, $apiClient, $settings);
    }

    public static function updateContact($response, $fieldData, $apiClient, $settings)
    {
        return self::run('updateContact', $fieldData, $apiClient, $settings);
    }

    public static function updateContactStatus($response, $fieldData, $apiClient, $settings)
    {
        return self::run('updateContactStatus', $fieldData, $apiClient, $settings);
    }

    public static function updateList($response, $fieldData, $apiClient, $settings)
    {
        return self::run('updateList', $fieldData, $apiClient, $settings);
    }

    public static function updateNote($response, $fieldData, $apiClient, $settings)
    {
        return self::run('updateNote', $fieldData, $apiClient, $settings);
    }

    public static function updatePage($response, $fieldData, $apiClient, $settings)
    {
        return self::run('updatePage', $fieldData, $apiClient, $settings);
    }

    public static function updateTag($response, $fieldData, $apiClient, $settings)
    {
        return self::run('updateTag', $fieldData, $apiClient, $settings);
    }

    public static function updateTask($response, $fieldData, $apiClient, $settings)
    {
        return self::run('updateTask', $fieldData, $apiClient, $settings);
    }

    public static function upsertContact($response, $fieldData, $apiClient, $settings)
    {
        return self::run('upsertContact', $fieldData, $apiClient, $settings);
    }

    /**
     * Resolve the action, build the URL and body, call SureContact, normalise the reply.
     *
     * @param string $slug      action key in self::ACTIONS
     * @param array  $fieldData mapped field values
     * @param mixed  $apiClient connection-scoped client from the free plugin
     * @param array  $settings  dropdown selections and Utilities toggles
     *
     * @return array
     */
    private static function run($slug, $fieldData, $apiClient, $settings)
    {
        list($verb, $template, $shaper, $required) = self::ACTIONS[$slug];

        $fieldData = self::resolveContactUuid($fieldData, $apiClient);

        if (isset($fieldData['__error'])) {
            return $fieldData['__error'];
        }

        $fieldData = self::resolveContactUuids($fieldData, $apiClient);

        if (isset($fieldData['__error'])) {
            return $fieldData['__error'];
        }

        $missing = self::missingFields($required, $template, $fieldData);

        if ($missing !== []) {
            return [
                'success' => false,
                // translators: %s: comma separated list of field names
                'message' => wp_sprintf(__('%s is required', 'bit-integrations-pro'), implode(', ', $missing)),
                'code'    => 400,
            ];
        }

        $path = self::buildPath($template, $fieldData);
        $body = self::buildBody($shaper, $template, $fieldData, $settings);

        // An update whose only mapped field is the identifier would post an empty body
        // and come back as "Primary fields are required", which reads like a bug rather
        // than an empty form.
        if ($shaper === 'contact' && $body === []) {
            return [
                'success' => false,
                'message' => __('Map at least one contact field to send.', 'bit-integrations-pro'),
                'code'    => 400,
            ];
        }

        // Both come from a node dropdown rather than the field map, so missingFields()
        // never sees them — yet the API rejects the call without either.
        if (str_ends_with($template, '/activities') && empty($settings['activity_type'])) {
            return [
                'success' => false,
                'message' => __('Select an activity type.', 'bit-integrations-pro'),
                'code'    => 400,
            ];
        }

        if (str_ends_with($template, '/status') && empty($settings['contact_status'])) {
            return [
                'success' => false,
                'message' => __('Select a contact status.', 'bit-integrations-pro'),
                'code'    => 400,
            ];
        }

        // wp_remote_request form-encodes an array body whatever the Content-Type says,
        // so a JSON API has to receive an already encoded string or it parses nothing.
        $response = $apiClient->request($verb, $path, $body === [] ? null : wp_json_encode($body));

        if (!$response->success()) {
            return [
                'success' => false,
                'message' => self::errorMessage($response),
                'code'    => $response->getStatus() ?: 400,
                'errors'  => self::toArray($response->getBodyValue('errors')),
            ];
        }

        return [
            'success' => true,
            'message' => __('Action completed successfully', 'bit-integrations-pro'),
            'code'    => 200,
            'data'    => $response->getBody(),
        ];
    }

    /**
     * WPKit decodes a JSON body to stdClass, so anything that gets indexed by key has
     * to be normalised first — `is_array()` on a stdClass is false and silently skips
     * the branch.
     *
     * @param mixed $value
     *
     * @return array<string, mixed>
     */
    private static function toArray($value)
    {
        if (\is_array($value)) {
            return $value;
        }

        if (\is_object($value)) {
            $decoded = json_decode((string) wp_json_encode($value), true);

            return \is_array($decoded) ? $decoded : [];
        }

        return [];
    }

    /**
     * SureContact answers a validation failure as `{ message, errors: { field: [reason] } }`;
     * the per-field reasons say far more than the generic message, so they are folded in.
     *
     * @param mixed $response
     */
    private static function errorMessage($response)
    {
        $message = $response->getBodyValue('message');
        $message = \is_string($message) && $message !== '' ? $message : '';

        $errors = self::toArray($response->getBodyValue('errors'));
        $details = [];

        foreach ($errors as $field => $reasons) {
            foreach ((array) $reasons as $reason) {
                if (\is_string($reason) && $reason !== '') {
                    // The field name is the useful half — "email is required" says
                    // nothing about which of the nested keys the API rejected.
                    $details[] = \is_string($field) ? $field . ': ' . $reason : $reason;
                }
            }
        }

        $details = array_unique($details);

        if ($details !== []) {
            $message = $message === '' ? implode(' ', $details) : $message . ' ' . implode(' ', $details);
        }

        return $message !== '' ? $message : __('SureContact rejected the request', 'bit-integrations-pro');
    }

    /**
     * Trigger data carries an email, never a SureContact UUID, so an action that needs a
     * contact accepts `contact_email` and is resolved to the real id here — the email
     * path is the one every flow uses.
     *
     * A mapped `contact_uuid` still wins, for the site that already stores SureContact
     * ids and can supply one from trigger data. Nothing chains it in from a previous
     * action: Flow::execute hands every action the same trigger payload and never folds
     * an action's response back into it.
     *
     * @param array $fieldData mapped field values
     * @param mixed $apiClient connection-scoped client
     *
     * @return array<string, mixed>
     */
    private static function resolveContactUuid($fieldData, $apiClient)
    {
        if (!empty($fieldData['contact_uuid']) || empty($fieldData['contact_email'])) {
            unset($fieldData['contact_email']);

            return $fieldData;
        }

        $email = $fieldData['contact_email'];
        unset($fieldData['contact_email']);

        $uuid = self::lookupContactUuid($email, $apiClient);

        if ($uuid === null) {
            $fieldData['__error'] = self::contactNotFound([$email]);

            return $fieldData;
        }

        $fieldData['contact_uuid'] = $uuid;

        return $fieldData;
    }

    /**
     * The same trade for the actions that act on several contacts at once. They accept
     * `contact_emails` as a comma separated list, and a mapped `contact_uuids` still wins.
     * One unknown address fails the whole call rather than silently acting on a subset.
     *
     * @param array $fieldData mapped field values
     * @param mixed $apiClient connection-scoped client
     *
     * @return array<string, mixed>
     */
    private static function resolveContactUuids($fieldData, $apiClient)
    {
        if (!empty($fieldData['contact_uuids']) || empty($fieldData['contact_emails'])) {
            unset($fieldData['contact_emails']);

            return $fieldData;
        }

        $emails = self::toList($fieldData['contact_emails']);
        unset($fieldData['contact_emails']);

        $uuids = [];
        $unknown = [];

        foreach ($emails as $email) {
            $uuid = self::lookupContactUuid($email, $apiClient);

            if ($uuid === null) {
                $unknown[] = $email;

                continue;
            }

            $uuids[] = $uuid;
        }

        if ($unknown !== []) {
            $fieldData['__error'] = self::contactNotFound($unknown);

            return $fieldData;
        }

        $fieldData['contact_uuids'] = $uuids;

        return $fieldData;
    }

    /**
     * The contact id behind an email address, or null when SureContact does not know it.
     *
     * @param string $email
     * @param mixed  $apiClient
     *
     * @return null|string
     */
    private static function lookupContactUuid($email, $apiClient)
    {
        $response = $apiClient->get('/contacts/email/' . rawurlencode($email));

        if (!$response->success()) {
            return null;
        }

        $body = self::toArray($response->getBody());
        $uuid = $body['data']['uuid']
            ?? $body['data']['contact']['uuid']
            ?? $body['contact']['uuid']
            ?? $body['uuid']
            ?? '';

        return $uuid === '' ? null : $uuid;
    }

    private static function contactNotFound($emails)
    {
        return [
            'success' => false,
            'message' => wp_sprintf(
                // translators: %s: comma separated list of email addresses
                __('No SureContact contact found for %s', 'bit-integrations-pro'),
                implode(', ', $emails)
            ),
            'code' => 404,
        ];
    }

    /**
     * Everything the action cannot run without: the ids the URL interpolates plus the
     * body fields the node marks required. Reported with the label the user sees, so the
     * message matches the field they need to fill.
     *
     * @param array  $required required field-map keys
     * @param string $template url template
     * @param array  $fieldData mapped field values
     *
     * @return array<int, string>
     */
    private static function missingFields($required, $template, $fieldData)
    {
        $missing = [];

        foreach (array_unique(array_merge(self::placeholders($template), $required)) as $key) {
            // Both have already been traded for their uuid by the time this runs, and a
            // directly mapped uuid means the address was never needed.
            if ($key === 'contact_email' && !empty($fieldData['contact_uuid'])) {
                continue;
            }

            if ($key === 'contact_emails' && !empty($fieldData['contact_uuids'])) {
                continue;
            }

            if (empty($fieldData[$key])) {
                $missing[] = self::fieldLabel($key);
            }
        }

        return $missing;
    }

    /**
     * Turn a field key into the label the node shows.
     */
    private static function fieldLabel($key)
    {
        if ($key === 'contact_uuid') {
            return __('Contact Email', 'bit-integrations-pro');
        }

        if ($key === 'contact_uuids') {
            return __('Contact Emails', 'bit-integrations-pro');
        }

        return ucwords(str_replace(['_uuid', '_'], ['', ' '], $key));
    }

    private static function placeholders($template)
    {
        preg_match_all('/\{(\w+)\}/', $template, $matches);

        return $matches[1];
    }

    private static function buildPath($template, $fieldData)
    {
        $path = $template;

        foreach (self::placeholders($template) as $key) {
            $path = str_replace('{' . $key . '}', rawurlencode($fieldData[$key]), $path);
        }

        return $path;
    }

    private static function buildBody($shaper, $template, $fieldData, $settings)
    {
        // A mapped identifier belongs in the URL, never in the payload.
        foreach (self::placeholders($template) as $key) {
            unset($fieldData[$key]);
        }

        if ($shaper === 'contact') {
            return self::contactBody($fieldData, $settings);
        }

        if ($shaper === 'note') {
            // The notes endpoint keys the text as `content`; the docs say `body`, and
            // the API answers "Note content is required" to that.
            return self::filterEmpty(['content' => $fieldData['content'] ?? '']);
        }

        // Both are fixed option sets the API enforces, so they arrive as node selections.
        if (str_ends_with($template, '/status') && !empty($settings['contact_status'])) {
            $fieldData['status'] = $settings['contact_status'];
        }

        if (str_ends_with($template, '/activities') && !empty($settings['activity_type'])) {
            $fieldData['type'] = $settings['activity_type'];
        }

        return self::listifyUuids(self::filterEmpty($fieldData));
    }

    private static function contactBody($fieldData, $settings)
    {
        $primary = [];

        foreach (self::CONTACT_PRIMARY_FIELDS as $field) {
            $primary[$field] = $fieldData[$field] ?? '';
            unset($fieldData[$field]);
        }

        if (!empty($settings['selected_gender'])) {
            $primary['gender'] = $settings['selected_gender'];
        }

        $primary = self::filterEmpty($primary);
        $body = $primary === [] ? [] : ['primary_fields' => $primary];

        foreach (['list_uuids', 'tag_uuids'] as $key) {
            $selected = self::toList($settings[$key] ?? '');

            if ($selected !== []) {
                $body[$key] = $selected;
            }
        }

        $custom = self::filterEmpty($fieldData);

        if ($custom !== []) {
            $body['custom_fields'] = $custom;
        }

        return $body;
    }

    /**
     * `*_uuids` fields are typed as a comma separated list in the field map so they stay
     * mappable from trigger data; the API wants arrays. The campaign bulk delete keys its
     * list as a bare `uuids`, which the suffix test alone would miss.
     *
     * @return array<string, mixed>
     */
    private static function listifyUuids($payload)
    {
        foreach ($payload as $key => $value) {
            if ($key === 'uuids' || substr($key, -6) === '_uuids') {
                $payload[$key] = self::toList($value);
            }
        }

        return $payload;
    }

    private static function toList($value)
    {
        if (\is_array($value)) {
            return array_values(array_filter($value));
        }

        if ($value === '' || $value === null) {
            return [];
        }

        return array_values(array_filter(array_map('trim', explode(',', (string) $value))));
    }

    private static function filterEmpty($payload)
    {
        return array_filter(
            (array) $payload,
            static function ($value) {
                if (\is_bool($value) || is_numeric($value)) {
                    return true;
                }

                return !empty($value);
            }
        );
    }
}
