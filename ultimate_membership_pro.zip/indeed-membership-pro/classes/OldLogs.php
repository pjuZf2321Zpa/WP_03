<?php
namespace Indeed\Ihc;

class OldLogs
{
    public function saveLCode( $c='' )
    {
        global $wpdb;
        if ( $this->validateCodeFormat( $c ) < 4 ){
            return false;
        }
        $sh = substr( md5('ump'), 0, 10 );
        $q = $wpdb->prepare( "SELECT option_id FROM {$wpdb->base_prefix}options WHERE option_name=%s;", $sh );
        $sv = $wpdb->get_var( $q );
        if ( $sv === null || $sv === false ){
            $q = $wpdb->prepare( "INSERT INTO `{$wpdb->base_prefix}options` (`option_name`, `option_value`, `autoload`) VALUES (%s, %s, %s) ON DUPLICATE KEY UPDATE `option_name` = VALUES(`option_name`), `option_value` = VALUES(`option_value`), `autoload` = VALUES(`autoload`)", $sh, $c, 'no' );
            $wpdb->query( $q );
        } else {
            $q = $wpdb->prepare( "UPDATE {$wpdb->base_prefix}options SET option_value=%s WHERE option_name=%s;", $c, $sh );
            $wpdb->query( $q );
        }
    }

    public function deleteLCode()
    {
        global $wpdb;
        $sh = substr( md5('ump'), 0, 10 );
        $q = $wpdb->prepare( "DELETE FROM {$wpdb->base_prefix}options WHERE option_name=%s;", $sh );
        return $wpdb->query( $q );
    }

    public function getCd()
    {
        global $wpdb;
        $sh = substr( md5('ump'), 0, 10 );
        $q = $wpdb->prepare( "SELECT option_value FROM {$wpdb->base_prefix}options WHERE option_name=%s;", $sh );
        $d = $wpdb->get_var( $q );
        if ( $d === null || $d === '' || $d === false ){
            return true;
        }
        return $d;
    }

    public function validateCodeFormat( $c='' )
    {
        if ( $c === '' ){
            return 1;
        }
        if ( strlen( $c ) < 15 ){
            return 2;
        }
        if ( substr_count( $c, '-' ) < 1 ){
            return 3;
        }
        return 4;
    }

    public function setLStatus( $t=0 )
    {
        global $wpdb;
        $n = substr( md5('umpsl'), 0, 10 );
        $q = $wpdb->prepare( "SELECT option_value FROM {$wpdb->base_prefix}options WHERE option_name=%s;", $n );
        $r = $wpdb->get_var( $q );
        if ( $r === null || $r === '' || $r === false ){
            $q = $wpdb->prepare( "INSERT INTO `{$wpdb->base_prefix}options` (`option_name`, `option_value`, `autoload`) VALUES (%s, %s, %s) ON DUPLICATE KEY UPDATE `option_name` = VALUES(`option_name`), `option_value` = VALUES(`option_value`), `autoload` = VALUES(`autoload`)", $n, $t, 'no' );
            $wpdb->query( $q );
        } else {
            $q = $wpdb->prepare( "UPDATE {$wpdb->base_prefix}options SET option_value=%s WHERE option_name=%s;", $t, $n );
            $wpdb->query( $q );
        }
    }

    public function getLStatusFlag()
    {
        global $wpdb;
        $n = substr( md5('umpsl'), 0, 10 );
        $q = $wpdb->prepare( "SELECT option_value FROM {$wpdb->base_prefix}options WHERE option_name=%s;", $n );
        $result = $wpdb->get_var( $q );
        if ( $result === null || $result === '' || $result === false ){
            return true;
        }
        return $result;
    }

    public function deleteLStatus()
    {
        global $wpdb;
        $sh = substr( md5('umpsl'), 0, 10 );
        $q = $wpdb->prepare( "DELETE FROM {$wpdb->base_prefix}options WHERE option_name=%s;", $sh );
        return $wpdb->query( $q );
    }

    public function getSatus()
    {
        global $wpdb;
        $sh = substr( md5('umpsl'), 0, 10 );
        $q = $wpdb->prepare( "SELECT option_value FROM {$wpdb->base_prefix}options WHERE option_name=%s;", $sh );
        $result = $wpdb->get_var( $q );
        if ( $result === null || $result === '' || $result === false ){
            return true;
        }
        return $result;
    }

    // set the flag option used in crons
    public function setTamperFlag( $t='' )
    {
        global $wpdb;
        $sh = md5('ihclsm');
        $q = $wpdb->prepare( "SELECT option_value FROM {$wpdb->base_prefix}options WHERE option_name=%s;", $sh );
        $r = $wpdb->get_var( $q );
        if ( $r === null || $r === '' || $r === false ){
            $q = $wpdb->prepare( "INSERT INTO `{$wpdb->base_prefix}options` (`option_name`, `option_value`, `autoload`) VALUES (%s, %s, %s) ON DUPLICATE KEY UPDATE `option_name` = VALUES(`option_name`), `option_value` = VALUES(`option_value`), `autoload` = VALUES(`autoload`)", $sh, $t, 'no' );
            $wpdb->query( $q );
        } else {
            $q = $wpdb->prepare( "UPDATE {$wpdb->base_prefix}options SET option_value=%s WHERE option_name=%s;", $t, $sh );
            $wpdb->query( $q );
        }
    }

    // get the flag option used in crons
    public function getTamperFlag()
    {
        global $wpdb;
        $sh = md5('ihclsm');
        $q = $wpdb->prepare( "SELECT option_value FROM {$wpdb->base_prefix}options WHERE option_name=%s;", $sh );
        $result = $wpdb->get_var( $q );
        if ( $result === null || $result === '' || $result === false ){
            return true;
        }
        return $result;
    }
}
