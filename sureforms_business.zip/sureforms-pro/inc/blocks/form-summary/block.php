<?php
/**
 * PHP render for the review step.
 *
 * @package sureforms-pro
 * @since 2.13.0
 */

namespace SRFM_Pro\Inc\Blocks\Form_Summary;

use SRFM_Pro\Inc\Blocks\Base;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Review step block.
 *
 * Never placed by an author: Page_Break::form_pagination() and the
 * conversational renderer append it as the last step when the Review Step
 * setting is on. It renders an empty shell, and the rows are built in the
 * browser from the answers the visitor has actually given, because nothing has
 * been submitted yet when it renders.
 *
 * @since 2.13.0
 */
class Block extends Base {
	/**
	 * Render the block.
	 *
	 * @param array<mixed> $attributes Block attributes: `notice`, the author's
	 *                                 text above the answers. Blank falls back to
	 *                                 the default reminder.
	 * @since 2.13.0
	 * @return string|bool
	 */
	public function render( $attributes ) {
		$notice = isset( $attributes['notice'] ) && is_string( $attributes['notice'] ) ? trim( $attributes['notice'] ) : '';
		if ( '' === $notice ) {
			$notice = __( 'Please take a moment to review your answers before submitting.', 'sureforms-pro' );
		}
		ob_start();
		?>
		<div
			class="srfm-block srfm-form-summary-block"
			data-block-id="srfm-review-step"
			data-show-edit="true"
			data-show-empty="false"
			data-edit-label="<?php echo esc_attr__( 'Edit', 'sureforms-pro' ); ?>"
			<?php // translators: %s is the label of the field the button jumps back to. ?>
			data-edit-aria="<?php echo esc_attr__( 'Edit %s', 'sureforms-pro' ); ?>"
			data-empty-text="<?php echo esc_attr__( 'Nothing to review yet.', 'sureforms-pro' ); ?>"
			data-return-label="<?php echo esc_attr__( 'Save & Review', 'sureforms-pro' ); ?>"
			<?php // translators: Shown on the review step in place of a ticked checkbox or GDPR consent. ?>
			data-checked-label="<?php echo esc_attr__( 'Checked', 'sureforms-pro' ); ?>"
			<?php // translators: Shown on the review step in place of a signature the visitor has drawn. ?>
			data-signed-label="<?php echo esc_attr__( 'Signed', 'sureforms-pro' ); ?>"
		>
			<p class="srfm-form-summary-notice" role="note">
				<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><circle cx="12" cy="12" r="10"/><path d="M12 16v-4"/><path d="M12 8h.01"/></svg>
				<span><?php echo esc_html( $notice ); ?></span>
			</p>
			<dl class="srfm-form-summary-list"></dl>
		</div>
		<?php
		return ob_get_clean();
	}
}
