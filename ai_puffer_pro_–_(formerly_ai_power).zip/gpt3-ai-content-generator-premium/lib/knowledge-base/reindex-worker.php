<?php

namespace WPAICG\Lib\KnowledgeBase;

use WPAICG\AutoGPT\Cron\AIPKit_Option_Lock;
use WPAICG\Vector\PostProcessor\Chroma\ChromaPostProcessor;
use WPAICG\Vector\PostProcessor\Google\GooglePostProcessor;
use WPAICG\Vector\PostProcessor\OpenAI\OpenAIPostProcessor;
use WPAICG\Vector\PostProcessor\Pinecone\PineconePostProcessor;
use WPAICG\Vector\PostProcessor\Qdrant\QdrantPostProcessor;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Processes the Pro stale-source queue in small, provider-safe batches.
 */
final class AIPKit_Knowledge_Reindex_Worker
{
    public const CRON_HOOK = 'aipkit_process_knowledge_reindex_queue';

    private const LOCK_OPTION = 'aipkit_knowledge_reindex_worker_lock_v1';
    private const LOCK_TTL = 30 * MINUTE_IN_SECONDS;
    private const FOLLOW_UP_DELAY = 30;

    private static $registered = false;

    public static function register_hooks(): void
    {
        if (self::$registered) {
            return;
        }

        self::load_lock_class();
        add_action('init', [self::class, 'ensure_scheduled'], 20);
        add_action(self::CRON_HOOK, [self::class, 'run_wp_cron']);
        add_filter(
            'aipkit_automation_runner_additional_queue_results',
            [self::class, 'append_server_queue_result'],
            10,
            3
        );
        add_action('aipkit_deactivate_background_workers', [self::class, 'deactivate']);
        self::$registered = true;
    }

    public static function run_wp_cron(): void
    {
        self::process_queue_batch('wp_cron', true);
    }

    public static function ensure_scheduled(): void
    {
        if (wp_doing_cron()) {
            return;
        }

        if (AIPKit_Knowledge_Source_State_Store::has_pending()) {
            self::schedule();
        }
    }

    /**
     * @param array<mixed> $results Existing additional queue results.
     * @return array<mixed>
     */
    public static function append_server_queue_result(
        array $results,
        string $source,
        bool $schedule_follow_up
    ): array {
        $results['knowledge_reindex'] = self::process_queue_batch($source, $schedule_follow_up);

        return $results;
    }

    /** @return array{status:string,processed_items:int,failed_items:int,recovered_items:int,has_remaining_items:bool} */
    public static function process_queue_batch(string $source = 'wp_cron', bool $schedule_follow_up = true): array
    {
        $result = [
            'status' => 'success',
            'processed_items' => 0,
            'failed_items' => 0,
            'recovered_items' => 0,
            'has_remaining_items' => false,
        ];

        if (!AIPKit_Knowledge_Source_State_Store::maybe_install()) {
            $result['status'] = 'unavailable';
            return $result;
        }

        self::load_lock_class();
        if (!class_exists(AIPKit_Option_Lock::class)) {
            $result['status'] = 'unavailable';
            return $result;
        }

        $token = AIPKit_Option_Lock::acquire(self::LOCK_OPTION, self::LOCK_TTL);
        if ($token === '') {
            $result['status'] = 'busy';
            $result['has_remaining_items'] = AIPKit_Knowledge_Source_State_Store::has_pending();
            if ($result['has_remaining_items'] && $schedule_follow_up) {
                self::schedule(self::FOLLOW_UP_DELAY);
            }
            return $result;
        }

        try {
            $result['recovered_items'] = AIPKit_Knowledge_Source_State_Store::recover_abandoned_work();
            $item = AIPKit_Knowledge_Source_State_Store::claim_next();
            if (is_array($item)) {
                ++$result['processed_items'];
                $process_result = self::process_item($item);
                if (($process_result['status'] ?? '') !== 'success') {
                    ++$result['failed_items'];
                }
            }
            $result['has_remaining_items'] = AIPKit_Knowledge_Source_State_Store::has_pending();
        } finally {
            AIPKit_Option_Lock::release(self::LOCK_OPTION, $token);
        }

        if ($result['has_remaining_items'] && $schedule_follow_up) {
            self::schedule(self::FOLLOW_UP_DELAY);
        }

        return $result;
    }

    public static function schedule(int $delay = 5): bool
    {
        $enabled = (bool) apply_filters('aipkit_knowledge_reindex_schedule_enabled', true);
        if (!$enabled || wp_next_scheduled(self::CRON_HOOK)) {
            return false;
        }

        return wp_schedule_single_event(time() + max(1, $delay), self::CRON_HOOK);
    }

    public static function deactivate(): void
    {
        wp_clear_scheduled_hook(self::CRON_HOOK);
        delete_option(self::LOCK_OPTION);
    }

    /**
     * @param array<string,mixed> $item Claimed source state.
     * @return array{status:string,message:string}
     */
    private static function process_item(array $item): array
    {
        $source_key = sanitize_text_field((string) ($item['source_key'] ?? ''));
        $post_id = absint($item['post_id'] ?? 0);
        $post = $post_id > 0 ? get_post($post_id) : null;
        if (!$post) {
            AIPKit_Knowledge_Source_State_Store::delete_by_source_key($source_key);
            return ['status' => 'error', 'message' => __('The source post no longer exists.', 'gpt3-ai-content-generator')];
        }

        try {
            $provider_result = self::route_to_provider($item);
        } catch (\Throwable $throwable) {
            $provider_result = [
                'status' => 'error',
                'message' => sanitize_text_field($throwable->getMessage()),
            ];
        }

        $status = sanitize_key((string) ($provider_result['status'] ?? ''));
        $message = sanitize_text_field((string) ($provider_result['message'] ?? ''));
        if ($status !== 'success') {
            AIPKit_Knowledge_Source_State_Store::mark_failed(
                $source_key,
                $message !== '' ? $message : __('Reindexing failed.', 'gpt3-ai-content-generator')
            );
            return [
                'status' => 'error',
                'message' => $message !== '' ? $message : __('Reindexing failed.', 'gpt3-ai-content-generator'),
            ];
        }

        $provider = sanitize_text_field((string) ($item['provider'] ?? ''));
        if ($provider === 'Google' || !empty($provider_result['processing'])) {
            $latest_state = AIPKit_Knowledge_Source_State_Store::get($source_key);
            if (sanitize_key((string) ($latest_state['status'] ?? '')) !== 'current') {
                AIPKit_Knowledge_Source_State_Store::mark_processing($source_key);
            }
        } else {
            $latest_state = AIPKit_Knowledge_Source_State_Store::get($source_key);
            $new_source_recorded = is_array($latest_state)
                && absint($latest_state['source_log_id'] ?? 0) > absint($item['source_log_id'] ?? 0)
                && sanitize_key((string) ($latest_state['status'] ?? '')) === 'current';
            if (!$new_source_recorded) {
                $target_fingerprint = (string) ($item['target_fingerprint'] ?? '');
                $current_fingerprint = AIPKit_Knowledge_Extraction_Fingerprint::for_post_type(
                    (string) $item['post_type']
                );
                if ($target_fingerprint !== '' && hash_equals($target_fingerprint, $current_fingerprint)) {
                    AIPKit_Knowledge_Source_State_Store::mark_complete($source_key, $target_fingerprint);
                } else {
                    AIPKit_Knowledge_Source_State_Store::mark_failed(
                        $source_key,
                        __('Reindexing completed, but its extraction fingerprint could not be confirmed.', 'gpt3-ai-content-generator')
                    );
                }
            }
        }

        return [
            'status' => 'success',
            'message' => $message !== '' ? $message : __('Content reindexed.', 'gpt3-ai-content-generator'),
        ];
    }

    /**
     * @param array<string,mixed> $item Claimed source state.
     * @return array<string,mixed>
     */
    private static function route_to_provider(array $item): array
    {
        self::load_processors();
        $provider = sanitize_text_field((string) ($item['provider'] ?? ''));
        $post_id = absint($item['post_id'] ?? 0);
        $store_id = sanitize_text_field((string) ($item['vector_store_id'] ?? ''));
        $store_name = sanitize_text_field((string) ($item['vector_store_name'] ?? ''));
        $embedding_provider = sanitize_key((string) ($item['embedding_provider'] ?? ''));
        $embedding_model = sanitize_text_field((string) ($item['embedding_model'] ?? ''));

        switch ($provider) {
            case 'OpenAI':
                return (new OpenAIPostProcessor())->index_single_post_to_store($post_id, $store_id, $store_name);
            case 'Google':
                return (new GooglePostProcessor())->index_single_post_to_store($post_id, $store_id, $store_name);
            case 'Pinecone':
                return (new PineconePostProcessor())->index_single_post_to_index(
                    $post_id,
                    $store_id,
                    $embedding_provider,
                    $embedding_model
                );
            case 'Qdrant':
                return (new QdrantPostProcessor())->index_single_post_to_collection(
                    $post_id,
                    $store_id,
                    $embedding_provider,
                    $embedding_model
                );
            case 'Chroma':
                return (new ChromaPostProcessor())->index_single_post_to_collection(
                    $post_id,
                    $store_id,
                    $embedding_provider,
                    $embedding_model
                );
            default:
                return [
                    'status' => 'error',
                    'message' => __('Unsupported vector provider.', 'gpt3-ai-content-generator'),
                ];
        }
    }

    private static function load_lock_class(): void
    {
        if (class_exists(AIPKit_Option_Lock::class)) {
            return;
        }

        $path = WPAICG_PLUGIN_DIR . 'classes/automations/lock.php';
        if (file_exists($path)) {
            require_once $path;
        }
    }

    private static function load_processors(): void
    {
        $path = WPAICG_PLUGIN_DIR . 'classes/automations/events.php';
        if (file_exists($path)) {
            require_once $path;
        }
        if (function_exists('WPAICG\\AutoGPT\\Cron\\EventProcessor\\Helpers\\load_required_classes_logic')) {
            \WPAICG\AutoGPT\Cron\EventProcessor\Helpers\load_required_classes_logic();
        }
    }
}
