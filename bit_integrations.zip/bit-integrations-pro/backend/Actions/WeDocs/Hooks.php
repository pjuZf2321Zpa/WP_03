<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Actions\WeDocs\WeDocsProHelper;
use BitApps\IntegrationsPro\Config;
use BitApps\IntegrationsPro\Core\Util\Hooks;

Hooks::filter(Config::withFreePrefix('wedocs_create_documentation'), [WeDocsProHelper::class, 'createDocumentation'], 10, 2);
Hooks::filter(Config::withFreePrefix('wedocs_create_section'), [WeDocsProHelper::class, 'createSection'], 10, 2);
Hooks::filter(Config::withFreePrefix('wedocs_create_article'), [WeDocsProHelper::class, 'createArticle'], 10, 2);
