<?php

namespace BitApps\IntegrationsPro\Actions\Pointics;

use Throwable;

final class PointicsProHelper
{
    public const POINTS_SERVICE = '\Pointics\Points\Points_Service';

    public const CHANNEL_SERVICE = '\Pointics\Channels\Channel_Service';

    public const REWARD_REDEMPTION_SERVICE = '\Pointics\Rewards\Reward_Redemption_Service';

    public const TIER_SERVICE = '\Pointics\Tiers\Tier_Service';

    public const REFERRAL_SERVICE = '\Pointics\Referrals\Referral_Service';

    public static function adjustPoints($defaultResponse, $fieldData)
    {
        $userId = self::resolveUserIdByEmail($fieldData, 'user_email');
        $points = $fieldData['points'] ?? '';

        if (!$userId) {
            return self::errorResponse(__('A valid Member Email is required, and it must belong to a registered user.', 'bit-integrations-pro'));
        }

        if (!is_numeric($points) || 0 === (int) $points) {
            return self::errorResponse(__('Points must be a non-zero number. Use a negative value to debit.', 'bit-integrations-pro'));
        }

        $service = self::resolve(self::POINTS_SERVICE);

        if (!$service) {
            return self::serviceUnavailable();
        }

        $dedupeKey = isset($fieldData['idempotency_key']) && '' !== $fieldData['idempotency_key']
            ? $fieldData['idempotency_key']
            : null;

        try {
            $entry = $service->adjust(
                $userId,
                (int) $points,
                $fieldData['description'] ?? '',
                isset($fieldData['source']) && '' !== $fieldData['source'] ? $fieldData['source'] : 'admin',
                $dedupeKey
            );
        } catch (Throwable $exception) {
            return self::errorResponse($exception->getMessage());
        }

        if (!$entry) {
            return self::errorResponse(__('Could not adjust points. The balance may be insufficient, or the idempotency key was already used.', 'bit-integrations-pro'));
        }

        return self::successResponse(__('Points adjusted successfully', 'bit-integrations-pro'), self::toArray($entry));
    }

    public static function awardChannelPoints($defaultResponse, $fieldData, $integrationDetails = null)
    {
        $userId = self::resolveUserIdByEmail($fieldData, 'user_email');
        $channelId = isset($integrationDetails->selectedChannel) ? absint($integrationDetails->selectedChannel) : 0;
        $dedupeKey = $fieldData['dedupe_key'] ?? '';

        if (!$userId) {
            return self::errorResponse(__('A valid Member Email is required, and it must belong to a registered user.', 'bit-integrations-pro'));
        }

        if (!$channelId) {
            return self::errorResponse(__('A Channel must be selected', 'bit-integrations-pro'));
        }

        if ('' === $dedupeKey) {
            return self::errorResponse(__('Dedupe Key is required so a replayed event never awards twice', 'bit-integrations-pro'));
        }

        $service = self::resolve(self::CHANNEL_SERVICE);

        if (!$service) {
            return self::serviceUnavailable();
        }

        $channel = $service->get($channelId);

        if (!$channel) {
            return self::errorResponse(__('Channel not found', 'bit-integrations-pro'));
        }

        try {
            $entry = $service->award_channel(
                $channel,
                $userId,
                $dedupeKey,
                isset($fieldData['amount']) && '' !== $fieldData['amount'] ? (float) $fieldData['amount'] : 0.0
            );
        } catch (Throwable $exception) {
            return self::errorResponse($exception->getMessage());
        }

        if (!$entry) {
            return self::errorResponse(__('Award produced no points or was blocked by the channel frequency cap or conditions', 'bit-integrations-pro'));
        }

        return self::successResponse(__('Channel points awarded successfully', 'bit-integrations-pro'), self::toArray($entry));
    }

    public static function cancelRedemption($defaultResponse, $fieldData)
    {
        return self::redemptionAction($fieldData, 'cancel', __('Redemption cancelled and points returned', 'bit-integrations-pro'));
    }

    public static function recomputeMemberTier($defaultResponse, $fieldData, $utilities = null)
    {
        $userId = self::resolveUserIdByEmail($fieldData, 'user_email');

        if (!$userId) {
            return self::errorResponse(__('A valid Member Email is required, and it must belong to a registered user.', 'bit-integrations-pro'));
        }

        $service = self::resolve(self::TIER_SERVICE);

        if (!$service) {
            return self::serviceUnavailable();
        }

        $promoteOnly = isset($utilities->selected_promote_only) && 'yes' === $utilities->selected_promote_only;

        try {
            $tier = $service->recompute($userId, $promoteOnly);
        } catch (Throwable $exception) {
            return self::errorResponse($exception->getMessage());
        }

        return self::successResponse(
            __('Member tier recomputed', 'bit-integrations-pro'),
            [
                'user_id'           => $userId,
                'tier'              => $tier ? self::toArray($tier) : null,
                'qualifying_points' => $service->qualifying_points($userId),
            ]
        );
    }

    public static function sendReferralInvite($defaultResponse, $fieldData)
    {
        $userId = self::resolveUserIdByEmail($fieldData, 'referrer_email');
        $email = $fieldData['email'] ?? '';

        if (!$userId) {
            return self::errorResponse(__('A valid Referrer Email is required, and it must belong to a registered user.', 'bit-integrations-pro'));
        }

        if (!is_email($email)) {
            return self::errorResponse(__('A valid Referee Email is required', 'bit-integrations-pro'));
        }

        $service = self::resolve(self::REFERRAL_SERVICE);

        if (!$service) {
            return self::serviceUnavailable();
        }

        try {
            $result = $service->invite($userId, $email);
        } catch (Throwable $exception) {
            return self::errorResponse($exception->getMessage());
        }

        if (empty($result['referral'])) {
            return self::errorResponse(self::inviteErrorMessage($result['error'] ?? ''));
        }

        return self::successResponse(__('Referral invite sent', 'bit-integrations-pro'), self::toArray($result['referral']));
    }

    public static function cancelReferralInvite($defaultResponse, $fieldData)
    {
        $userId = self::resolveUserIdByEmail($fieldData, 'referrer_email');
        $referralId = self::positiveId($fieldData, 'referral_id');

        if (!$userId || !$referralId) {
            return self::errorResponse(__('A registered Referrer Email and a Referral Id are required', 'bit-integrations-pro'));
        }

        $service = self::resolve(self::REFERRAL_SERVICE);

        if (!$service) {
            return self::serviceUnavailable();
        }

        try {
            $status = $service->cancel_invite($userId, $referralId);
        } catch (Throwable $exception) {
            return self::errorResponse($exception->getMessage());
        }

        if ('cancelled' !== $status) {
            return self::errorResponse(
                'not_owner' === $status
                    ? __('That invite belongs to another member', 'bit-integrations-pro')
                    : __('That invite already completed and cannot be cancelled', 'bit-integrations-pro')
            );
        }

        return self::successResponse(__('Referral invite cancelled', 'bit-integrations-pro'), ['referral_id' => $referralId, 'status' => $status]);
    }

    public static function completeReferralRegistration($defaultResponse, $fieldData)
    {
        $refereeId = self::resolveUserIdByEmail($fieldData, 'referee_email');

        if (!$refereeId) {
            return self::errorResponse(__('A valid Referee Email is required, and it must belong to a registered user.', 'bit-integrations-pro'));
        }

        $service = self::resolve(self::REFERRAL_SERVICE);

        if (!$service) {
            return self::serviceUnavailable();
        }

        try {
            $referral = $service->complete_registration($refereeId, self::optionalUserIdByEmail($fieldData, 'referrer_email'));
        } catch (Throwable $exception) {
            return self::errorResponse($exception->getMessage());
        }

        if (!$referral) {
            return self::errorResponse(__('No referral was completed. The referee may already be attributed, or the referrer could not be resolved.', 'bit-integrations-pro'));
        }

        return self::successResponse(__('Referral registration completed', 'bit-integrations-pro'), self::toArray($referral));
    }

    public static function completeReferralPurchase($defaultResponse, $fieldData)
    {
        $refereeId = self::resolveUserIdByEmail($fieldData, 'referee_email');
        $amount = $fieldData['amount'] ?? '';

        if (!$refereeId) {
            return self::errorResponse(__('A valid Referee Email is required, and it must belong to a registered user.', 'bit-integrations-pro'));
        }

        if (!is_numeric($amount)) {
            return self::errorResponse(__('Order Amount must be a number', 'bit-integrations-pro'));
        }

        $service = self::resolve(self::REFERRAL_SERVICE);

        if (!$service) {
            return self::serviceUnavailable();
        }

        try {
            $referral = $service->complete_purchase($refereeId, (float) $amount, self::optionalUserIdByEmail($fieldData, 'referrer_email'));
        } catch (Throwable $exception) {
            return self::errorResponse($exception->getMessage());
        }

        if (!$referral) {
            return self::errorResponse(__('No referral was completed. The order may be below the minimum value, or the referee is already attributed.', 'bit-integrations-pro'));
        }

        return self::successResponse(__('Referral purchase completed', 'bit-integrations-pro'), self::toArray($referral));
    }

    private static function redemptionAction($fieldData, $method, $successMessage)
    {
        $userId = self::resolveUserIdByEmail($fieldData, 'user_email');
        $redemptionId = self::positiveId($fieldData, 'redemption_id');

        if (!$userId || !$redemptionId) {
            return self::errorResponse(__('A registered Member Email and a Redemption Id are required', 'bit-integrations-pro'));
        }

        $service = self::resolve(self::REWARD_REDEMPTION_SERVICE);

        if (!$service) {
            return self::serviceUnavailable();
        }

        try {
            $result = $service->{$method}($userId, $redemptionId);
        } catch (Throwable $exception) {
            return self::errorResponse($exception->getMessage());
        }

        return self::successResponse($successMessage, $result);
    }

    private static function positiveId($fieldData, $key)
    {
        return isset($fieldData[$key]) && (int) $fieldData[$key] > 0 ? (int) $fieldData[$key] : 0;
    }

    private static function resolveUserIdByEmail($fieldData, $key)
    {
        $email = isset($fieldData[$key]) ? trim((string) $fieldData[$key]) : '';

        if ('' === $email || !is_email($email)) {
            return 0;
        }

        $user = get_user_by('email', $email);

        return $user ? (int) $user->ID : 0;
    }

    private static function optionalUserIdByEmail($fieldData, $key)
    {
        $id = self::resolveUserIdByEmail($fieldData, $key);

        return $id > 0 ? $id : null;
    }

    private static function inviteErrorMessage($code)
    {
        $messages = [
            'invite_invalid'            => __('The referrer or the email address is missing', 'bit-integrations-pro'),
            'invite_suppressed'         => __('That address opted out of referral invites', 'bit-integrations-pro'),
            'invite_rate_limited'       => __('The referrer sent too many invites. Try again later.', 'bit-integrations-pro'),
            'invite_self'               => __('A member cannot refer themselves', 'bit-integrations-pro'),
            'invite_already_registered' => __('That address already has an account', 'bit-integrations-pro'),
            'invite_mail_failed'        => __('The invite email could not be sent. Check the site mailer.', 'bit-integrations-pro'),
        ];

        return $messages[$code] ?? __('Could not send that invite', 'bit-integrations-pro');
    }

    private static function resolve($className)
    {
        if (!\defined('POINTICS_VERSION') || !\function_exists('pointics_container') || !class_exists($className)) {
            return null;
        }

        try {
            return pointics_container()->make($className);
        } catch (Throwable $exception) {
            return null;
        }
    }

    private static function toArray($value)
    {
        if (\is_array($value)) {
            return $value;
        }

        if (\is_object($value) && method_exists($value, 'to_array')) {
            return (array) $value->to_array();
        }

        if (\is_object($value)) {
            return get_object_vars($value);
        }

        return [];
    }

    private static function serviceUnavailable()
    {
        return self::errorResponse(__('Pointics is not installed or activated', 'bit-integrations-pro'));
    }

    private static function errorResponse($message)
    {
        return ['success' => false, 'message' => $message];
    }

    private static function successResponse($message, $data = [])
    {
        return ['success' => true, 'message' => $message, 'data' => $data];
    }
}
