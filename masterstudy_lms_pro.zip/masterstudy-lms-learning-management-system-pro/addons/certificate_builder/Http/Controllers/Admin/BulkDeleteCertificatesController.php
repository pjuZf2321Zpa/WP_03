<?php

namespace MasterStudy\Lms\Pro\addons\certificate_builder\Http\Controllers\Admin;

use MasterStudy\Lms\Http\WpResponseFactory;
use MasterStudy\Lms\Pro\addons\certificate_builder\Repositories\CertificateAdminAccess;
use MasterStudy\Lms\Pro\addons\certificate_builder\Repositories\CertificateAdminRepository;
use MasterStudy\Lms\Validation\Validator;
use WP_REST_Request;
use WP_REST_Response;

final class BulkDeleteCertificatesController {
	private const MAX_BULK_CERTIFICATES = 100;

	public function __invoke( WP_REST_Request $request ): WP_REST_Response {
		if ( ! CertificateAdminAccess::can_access() ) {
			return WpResponseFactory::forbidden();
		}

		$validator = new Validator(
			$request->get_params(),
			array(
				'certificates' => 'required|array',
			)
		);

		if ( $validator->fails() ) {
			return WpResponseFactory::validation_failed( $validator->get_errors_array() );
		}

		$certificates = (array) $validator->get_validated()['certificates'];

		if ( count( $certificates ) > self::MAX_BULK_CERTIFICATES ) {
			return WpResponseFactory::bad_request(
				sprintf(
					/* translators: %d: maximum number of certificates allowed in one bulk request. */
					esc_html__( 'Too many certificates in one request. Maximum allowed is %d.', 'masterstudy-lms-learning-management-system' ),
					self::MAX_BULK_CERTIFICATES
				)
			);
		}

		try {
			( new CertificateAdminRepository() )->bulk_delete( $certificates );
		} catch ( \RuntimeException $e ) {
			if ( 403 === $e->getCode() ) {
				return WpResponseFactory::forbidden();
			}

			if ( 400 === $e->getCode() ) {
				return WpResponseFactory::bad_request( $e->getMessage() );
			}

			return WpResponseFactory::error( $e->getMessage() );
		}

		return WpResponseFactory::ok_with_data(
			array(
				'success' => true,
			)
		);
	}
}
