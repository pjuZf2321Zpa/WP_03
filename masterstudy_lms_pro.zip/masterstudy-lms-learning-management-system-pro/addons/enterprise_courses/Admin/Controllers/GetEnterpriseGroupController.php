<?php

namespace MasterStudy\Lms\Pro\addons\enterprise_courses\Admin\Controllers;

use MasterStudy\Lms\Http\WpResponseFactory;
use MasterStudy\Lms\Pro\addons\enterprise_courses\Admin\Repositories\EnterpriseGroupsRepository;
use WP_REST_Response;

final class GetEnterpriseGroupController {
	public function __invoke( string $group_id ): WP_REST_Response {
		$group = ( new EnterpriseGroupsRepository() )->get_group_for_edit( (int) $group_id );

		if ( ! $group ) {
			return WpResponseFactory::bad_request( esc_html__( 'Enterprise group not found.', 'masterstudy-lms-learning-management-system-pro' ) );
		}

		return new WP_REST_Response( array( 'group' => $group ) );
	}
}
