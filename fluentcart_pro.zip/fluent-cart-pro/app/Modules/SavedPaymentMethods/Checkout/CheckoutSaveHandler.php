<?php

namespace FluentCartPro\App\Modules\SavedPaymentMethods\Checkout;

use FluentCart\Api\Resource\CustomerResource;
use FluentCart\Framework\Support\Arr;
use FluentCart\Api\StoreSettings;
use FluentCartPro\App\Modules\SavedPaymentMethods\PayPal\PayPalVaultCapability;
use FluentCartPro\App\Modules\SavedPaymentMethods\Settings\SettingsHandler;

/**
 * Checkout-time half of "save card at checkout":
 *  - renders the opt-in checkbox (logged-in buyers, or subscription checkouts)
 *  - persists the opt-in onto the order so order_paid can act on it later
 *  - sets setup_future_usage on BOTH the client Elements config (via the core
 *    fluent_cart/stripe/client_setup_future_usage filter) and the real one-time
 *    PaymentIntent (fluent_cart/payments/stripe_onetime_intent_args), so Stripe
 *    vaults the confirmed card. The two MUST match or the confirmation fails
 *    ("setup_future_usage does not match").
 *
 * Both halves resolve from the SAME signal — the buyer's ticked checkbox — which
 * is what keeps them in lockstep. The checkout script sends it as a query
 * parameter on the get_order_info request (a GET, so it does carry parameters)
 * and keeps the mounted Elements instance updated when it is toggled; the server
 * half reads the flag persisted onto the order from the same checkbox in the
 * place-order POST. An unticked box means no card is vaulted at Stripe at all.
 */
class CheckoutSaveHandler
{
    const ORDER_FLAG_META = '_fct_save_payment_method';

    // Marker set when we applied setup_future_usage to a one-time intent, so
    // order_paid knows a card was vaulted and can honor an opt-out (detach).
    const SFU_APPLIED_META = '_fct_spm_sfu_applied';

    public function register(): void
    {
        add_action('fluent_cart/after_payment_methods', [$this, 'renderCheckbox']);
        add_action('fluent_cart/checkout/prepare_other_data', [$this, 'persistFlag']);
        add_filter('fluent_cart/stripe/client_setup_future_usage', [$this, 'clientSetupFutureUsage'], 10, 2);
        add_filter('fluent_cart/payments/stripe_onetime_intent_args', [$this, 'maybeSetupFutureUsage'], 10, 2);
        add_filter('fluent_cart/payments/stripe_checkout_session_args', [$this, 'maybeVaultOnSession'], 10, 2);
        add_filter('fluent_cart/payments/paypal_vault_one_time', [$this, 'maybeVaultPayPal'], 10, 2);
    }

    /**
     * PayPal half. Core vaults a PayPal account during the purchase when this
     * returns true; the buyer approves the save agreement inside PayPal's own UI,
     * so there is no separate client/server value to keep matched as there is for
     * Stripe Elements.
     *
     * Reads the same persisted consent flag as the Stripe halves, so all three
     * gateways share one signal.
     *
     * @param bool $vault
     * @param array $context ['order'=>Order, 'transaction'=>OrderTransaction, 'subscription'=>Subscription|null]
     * @return bool
     */
    public function maybeVaultPayPal($vault, $context)
    {
        if ($vault) {
            return $vault; // core already decided to vault (system subscription)
        }

        $order = Arr::get($context, 'order');
        if (!$order || $order->getMeta(self::ORDER_FLAG_META) !== 'yes') {
            return $vault;
        }

        // Subscriptions vault through core's own flow; never override it here.
        if (Arr::get($context, 'subscription')) {
            return $vault;
        }

        // Do not ask an account that has already refused. Core would retry
        // without the attributes anyway, but that costs an extra round trip on
        // every order and re-logs the same failure.
        if (!(new PayPalVaultCapability())->isAvailable()) {
            return $vault;
        }

        return true;
    }

    /**
     * Render the opt-in checkbox after the payment-method list. A tiny inline
     * script reveals it only while the Stripe method is selected (and clears it
     * otherwise) so the flag can't ride along with a non-card gateway.
     */
    public function renderCheckbox($context = [])
    {
        // Only offer to save the card when there is (or will be) a customer to
        // attach it to: a logged-in customer, or a subscription checkout — which
        // creates the customer AND vaults the card off-session via core's Stripe
        // flow (setup_future_usage=off_session). A guest one-time purchase has
        // neither, and a card charged one-time cannot be re-vaulted, so hide it.
        $cart = Arr::get($context, 'cart');
        $isSubscription = $cart && method_exists($cart, 'hasSubscription') && $cart->hasSubscription();
        if (!is_user_logged_in() && !$isSubscription) {
            return;
        }

        // Offering a save PayPal will refuse is worse than not offering it.
        $payPalSavable = (new PayPalVaultCapability())->isAvailable() ? 'true' : 'false';

        $label = esc_html__('Save this card for faster checkout next time', 'fluent-cart-pro');
        $note = esc_html__('Your card details are never stored on this site — your payment provider keeps them and gives us a secure token. Nothing is charged until you place an order.', 'fluent-cart-pro');

        /**
         * Whether the consent box starts ticked.
         *
         * Driven by the merchant setting, which ships OFF. A pre-ticked consent
         * box is not valid consent under the GDPR (Recital 32; CJEU Planet49,
         * C-673/17 — consent requires an affirmative act, and a box the buyer has
         * to clear is not one), so the plugin cannot ship it ticked for everyone.
         * A merchant switching it on is making that call for their own market.
         *
         * The filter still wins, for programmatic control and for anyone needing
         * to vary it per cart or per region.
         *
         * @param bool $checked
         * @param array $context ['cart' => Cart|null]
         */
        $checkedByDefault = (new StoreSettings())->get(SettingsHandler::PRECHECK_KEY, 'no') === 'yes';

        $checkedByDefault = (bool) apply_filters('fluent_cart/saved_payment_methods/consent_checked_by_default', $checkedByDefault, [
            'cart' => $cart,
        ]);

        echo '<div class="fct-spm-save" data-fct-spm-save style="display:none;margin:12px 0 20px">'
            . '<label style="display:flex;align-items:center;gap:8px;font-size:13px;cursor:pointer">'
            . '<input type="checkbox" name="save_payment_method" value="yes"' . ($checkedByDefault ? ' checked' : '') . '> '
            . '<span>' . $label . '</span>'
            . '</label>'
            . '<p style="margin:6px 0 0 24px;font-size:12px;line-height:1.5;opacity:.7">' . $note . '</p>'
            . '</div>';

        echo '<script>(function(){'
            . 'var w=document.querySelector("[data-fct-spm-save]");if(!w)return;'
            . 'var c=w.querySelector("input");'
            . 'var def=' . ($checkedByDefault ? 'true' : 'false') . ';'
            . 'var touched=false;var syncing=false;'
            // A buyer who changes the box owns it from then on. `syncing` keeps our
            // own programmatic writes from being mistaken for that choice.
            . 'if(c){c.addEventListener("change",function(){if(!syncing)touched=true;});}'
            // Every write dispatches change: the Stripe Elements config listens for
            // it, and a silent write would desync setup_future_usage.
            . 'function set(v){if(!c||c.checked===v)return;syncing=true;c.checked=v;'
            . 'c.dispatchEvent(new Event("change",{bubbles:true}));syncing=false;}'
            // Shown only for card gateways. Hidden => cleared, so a consent given
            // for a card can never ride along with another gateway. Coming back
            // into view restores the default ONLY if the buyer never touched it —
            // re-ticking a box they deliberately cleared would be the bug this
            // whole flow exists to avoid.
            . 'function s(){var r=document.querySelector(\'input[name="_fct_pay_method"]:checked\');'
            . 'var ppOk=' . $payPalSavable . ';'
            . 'var on=r&&(r.value==="stripe"||(r.value==="paypal"&&ppOk));w.style.display=on?"":"none";'
            . 'if(!on){set(false);}else if(!touched){set(def);}}'
            . 'document.addEventListener("change",function(e){if(e.target&&e.target.name==="_fct_pay_method")s();});'
            . 's();})();</script>';
    }

    /**
     * Persist the opt-in onto the order (fires after draft-order creation,
     * before the charge) so both the intent filter and order_paid can read it.
     */
    public function persistFlag($data)
    {
        $order = Arr::get($data, 'order');
        if (!$order) {
            return;
        }

        if (Arr::get($data, 'request_data.save_payment_method') !== 'yes') {
            // Consent withdrawal: a draft order is reused across submit retries,
            // so an earlier tick must not survive an untick — clear both the
            // opt-in and the applied-SFU marker or the card vaults anyway.
            if ($order->getMeta(self::ORDER_FLAG_META)) {
                $order->deleteMeta(self::ORDER_FLAG_META);
                $order->deleteMeta(self::SFU_APPLIED_META);
            }
            return;
        }

        // Client-side checkbox visibility is NOT an authorization boundary — a
        // crafted request could carry save_payment_method=yes. Enforce consent
        // server-side to match renderCheckbox:
        //  - a logged-in buyer must own the order;
        //  - a guest may opt in only on a SUBSCRIPTION checkout, which creates
        //    the customer and vaults the card; the order created in this same
        //    request is the buyer's own, so its customer is the right target.
        if (is_user_logged_in()) {
            $currentCustomer = CustomerResource::getCurrentCustomer();
            if (!$currentCustomer || (int) $currentCustomer->id !== (int) $order->customer_id) {
                return;
            }
        } elseif (!(method_exists($order, 'isSubscription') && $order->isSubscription())) {
            return;
        }

        $order->updateMeta(self::ORDER_FLAG_META, 'yes');
    }

    /**
     * Client-side half: set setup_future_usage on the Stripe Elements config
     * (core getOrderInfo) so the confirmed card is vaulted.
     *
     * Resolved from CONSENT, not from login state: the buyer's ticked checkbox is
     * the only thing that authorises storing a card. The checkout script carries
     * the checkbox into this request and keeps the mounted Elements instance in
     * step with it (see bindSaveCardConsent in stripe-checkout.js).
     *
     * MUST stay in lockstep with maybeSetupFutureUsage (the real intent) — any
     * divergence is a Stripe "setup_future_usage does not match" failure. Both
     * read the same checkbox, which is what keeps them aligned.
     *
     * @param string|null $value
     * @param array $context ['data'=>array, 'has_subscription'=>bool]
     * @return string|null
     */
    public function clientSetupFutureUsage($value, $context)
    {
        // Preserve core's system-subscription mandate; this filter only runs in payment mode.
        if ( $value === 'off_session' ) {
            return $value;
        }

        if (Arr::get($context, 'data.save_payment_method') === 'yes') {
            // off_session, not core's on_session: a saved card is charged later
            // with the buyer absent (one-tap checkout, renewals). This value must
            // equal what maybeSetupFutureUsage puts on the real PaymentIntent.
            return 'off_session';
        }

        return $value;
    }

    /**
     * Server-side half: mirror clientSetupFutureUsage on the REAL one-time
     * PaymentIntent so the vault actually happens and the confirmation matches
     * the client Elements. The intent already carries a Stripe customer
     * (Processor sets one), which Stripe requires for setup_future_usage.
     *
     * Reads the consent flag persisted by persistFlag() on
     * fluent_cart/checkout/prepare_other_data, which fires before finalizeOrder
     * and therefore before this intent is built (CheckoutApi.php:276/284). Using
     * the stored flag rather than the raw request means the ownership checks in
     * persistFlag() gate this too.
     *
     * @param array $intentData
     * @param array $context ['order'=>Order, 'transaction'=>OrderTransaction]
     * @return array
     */
    public function maybeSetupFutureUsage($intentData, $context)
    {
        $order = Arr::get($context, 'order');
        if (!$order) {
            return $intentData;
        }

        if ($order->getMeta(self::ORDER_FLAG_META) !== 'yes') {
            return $intentData;
        }

        // This one-time filter also handles store-billed subscription payments.
        $intentData['setup_future_usage'] = 'off_session';
        $order->updateMeta(self::SFU_APPLIED_META, 'yes');

        return $intentData;
    }

    /**
     * Hosted-mode half. Processor::handleSinglePayment returns into
     * handleHostedCheckout BEFORE the stripe_onetime_intent_args filter above
     * (Processor.php:462), and the hosted path takes setup_future_usage from
     * $paymentArgs, which nothing here populates — so on a hosted-mode store the
     * save-card checkbox rendered and vaulted nothing at all.
     *
     * A mode: payment Checkout Session only vaults when setup_future_usage is set
     * on payment_intent_data. Reads the same persisted consent flag as
     * maybeSetupFutureUsage, so both checkout modes share one consent signal.
     *
     * Hosted mode never loads Elements, so there is no client/server config to
     * keep in step here — only the session needs the value.
     *
     * @param array $sessionData
     * @param array $context ['order'=>Order, 'transaction'=>OrderTransaction]
     * @return array
     */
    public function maybeVaultOnSession($sessionData, $context)
    {
        // This filter has TWO call sites: the payment session (Processor.php:644)
        // and the hosted SETUP-ONLY session for zero-payable free trials
        // (Processor.php:411), which is mode: setup and carries no
        // payment_intent_data at all — Stripe rejects that key on a setup session.
        // Gate on the mode rather than assuming the payment path.
        if (Arr::get($sessionData, 'mode') !== 'payment') {
            return $sessionData;
        }

        $order = Arr::get($context, 'order');
        if (!$order) {
            return $sessionData;
        }

        if ($order->getMeta(self::ORDER_FLAG_META) !== 'yes') {
            return $sessionData;
        }

        // Merge, never assign: core sets payment_intent_data itself for the
        // subscription paths (Processor.php:628-632) and another filter may have
        // added its own keys.
        $paymentIntentData = Arr::get($sessionData, 'payment_intent_data', []);
        if (!is_array($paymentIntentData)) {
            $paymentIntentData = [];
        }

        $paymentIntentData['setup_future_usage'] = 'off_session';
        $sessionData['payment_intent_data'] = $paymentIntentData;

        $order->updateMeta(self::SFU_APPLIED_META, 'yes');

        return $sessionData;
    }
}
