<?php

namespace FluentCartPro\App\Modules\DynamicPricing\Pricing;

use FluentCart\App\Models\Order;
use FluentCart\App\Services\DateTime\DateTime;
use FluentCart\Framework\Support\Arr;
use FluentCartPro\App\Modules\DynamicPricing\Models\AppliedPricingRule;

/**
 * Records which rules priced an order.
 *
 * The order stores what it charged, not who decided it. The rules work that out
 * while the cart is priced — before the order exists — so the answer waits on
 * the cart until it does, and is written here.
 *
 * Rows are a snapshot: the name is kept as it read at the time, so the history
 * survives the rule being renamed or deleted.
 *
 * @package FluentCartPro\App\Modules\DynamicPricing
 *
 * @version 1.0.0
 */
class AppliedRuleRecorder
{
    public function register()
    {
        add_action('fluent_cart/order/after_items_calculated', [$this, 'record']);
    }

    /**
     * @param array $data ['order' => Order, 'cart' => Cart]
     * @return void
     */
    public function record($data)
    {
        $order = Arr::get((array)$data, 'order');
        $cart = Arr::get((array)$data, 'cart');

        // A payment link pays an order that already holds its pricing history.
        if (!$order instanceof Order || !$cart || DynamicPricingService::isPaymentLinkCart($cart)) {
            return;
        }

        // placeOrder() holds its own instance of this row, loaded before the
        // persister wrote the note and saved it. Read the row as it stands, or
        // the note is invisible from here and the order records nothing.
        $cart = $cart->fresh() ?: $cart;

        $checkoutData = is_array($cart->checkout_data) ? $cart->checkout_data : [];

        $rows = array_merge(
            (array)Arr::get($checkoutData, DynamicDiscountPersister::APPLIED_KEY, []),
            $this->shippingRules(),
            $this->feeRules($order)
        );

        // Rows of its own mean this order was priced before, so a retry that no
        // longer earns a rule has to clear them. Nothing either way and no rule
        // ever touched this order — its history is not ours to rewrite.
        $shouldWrite = $rows || AppliedPricingRule::query()->where('order_id', $order->id)->exists();

        if (!$shouldWrite) {
            return;
        }

        $this->replaceRowsFor((int)$order->id, $rows);

        unset($checkoutData[DynamicDiscountPersister::APPLIED_KEY]);
        $cart->checkout_data = $checkoutData;
        $cart->save();
    }

    /**
     * The shipping rules that discounted this order's postage.
     *
     * Asked for rather than read off the cart: the postage is discounted long
     * before the order exists, and place-order rewrites the cart's
     * checkout_data in between.
     *
     * @return array
     */
    protected function shippingRules(): array
    {
        $rows = [];

        foreach ((array)apply_filters('fluent_cart/dynamic_pricing/last_shipping_rules', []) as $rule) {
            $rows[] = [
                'rule_id'           => (int)Arr::get($rule, 'rule_id'),
                'rule_type'         => (string)Arr::get($rule, 'rule_type', ''),
                'rule_name'         => (string)Arr::get($rule, 'rule_name', ''),
                'adjustment_type'   => 'discount',
                'adjustment_amount' => (int)Arr::get($rule, 'amount', 0),
            ];
        }

        return $rows;
    }

    /**
     * The fee rules that charged this order.
     *
     * Fees need no note on the cart: they reach the order as their own items,
     * already carrying the rule they came from. Read here rather than captured
     * earlier, so there is one less thing to keep in step.
     *
     * @param Order $order
     * @return array
     */
    protected function feeRules(Order $order): array
    {
        $rows = [];

        foreach ($order->feeItems()->get() as $item) {
            $info = is_array($item->other_info) ? $item->other_info : [];

            if (Arr::get($info, 'source') !== CartAdjustmentApplier::FEE_SOURCE) {
                continue;
            }

            $ruleId = (int)str_replace('rule_', '', (string)Arr::get($info, 'fee_key', ''));

            if (!$ruleId) {
                continue;
            }

            $rows[] = [
                'rule_id'           => $ruleId,
                'rule_type'         => (string)Arr::get($info, 'meta.rule_type', ''),
                'rule_name'         => (string)$item->title,
                'adjustment_type'   => 'fee',
                'adjustment_amount' => (int)$item->subtotal,
            ];
        }

        return $rows;
    }

    /**
     * Write rows for an order that never had a cart — a renewal order.
     *
     * Runs inside the caller's transaction, so the rows are committed or
     * rolled back with the order they explain. It must not open its own: a
     * nested START TRANSACTION would commit the caller's early.
     *
     * @param int $orderId
     * @param array $rows
     * @return void
     */
    public function recordFor(int $orderId, array $rows)
    {
        $this->insertRows($orderId, $this->buildRows($orderId, $rows));
    }

    /**
     * Write this order's rules, replacing whatever it held.
     *
     * A failed payment that is retried reuses the same order and prices it
     * again, so the rows have to describe the attempt that stands rather than
     * the one before it. The rows are shaped first and written in one
     * statement, so the round trips do not grow with the rule count, and the
     * delete and insert commit together, so the order is never left holding
     * half a snapshot.
     *
     * @param int $orderId
     * @param array $rows
     * @return void
     */
    protected function replaceRowsFor(int $orderId, array $rows)
    {
        $inserts = $this->buildRows($orderId, $rows);

        $db = AppliedPricingRule::query()->getConnection();
        $db->beginTransaction();

        try {
            // Serialize on the order row, so a double submit rebuilds the
            // snapshot one pass at a time rather than interleaving its delete
            // with the other pass's insert.
            Order::query()->where('id', $orderId)->lockForUpdate()->first();

            $this->insertRows($orderId, $inserts);

            $db->commit();
        } catch (\Exception $e) {
            // A failed insert takes the delete with it, so the order keeps the
            // snapshot it already had rather than being left with none.
            $db->rollBack();
            throw $e;
        }
    }


    /**
     * @param int $orderId
     * @param array $inserts Built by buildRows().
     * @return void
     */
    protected function insertRows(int $orderId, array $inserts)
    {
        AppliedPricingRule::query()->where('order_id', $orderId)->delete();

        // One statement whatever the rule count, so a store with many
        // rules does not pay a round trip per rule at checkout.
        if ($inserts) {
            AppliedPricingRule::query()->insert($inserts);
        }
    }

    /**
     * The rows as the table stores them: zero amounts dropped, discounts
     * negative, fees positive, timestamps set.
     *
     * @param int $orderId
     * @param array $rows
     * @return array
     */
    protected function buildRows(int $orderId, array $rows): array
    {
        $now = DateTime::gmtNow();
        $inserts = [];

        foreach ($rows as $row) {
            $amount = (int)Arr::get($row, 'adjustment_amount', 0);

            if (!$amount) {
                continue;
            }

            $type = (string)Arr::get($row, 'adjustment_type', 'discount');

            $inserts[] = [
                'order_id'   => $orderId,
                'rule_id'    => (int)Arr::get($row, 'rule_id') ?: null,
                'rule_type'  => (string)Arr::get($row, 'rule_type', ''),
                'rule_name'  => (string)Arr::get($row, 'rule_name', ''),
                'adjustment_type' => $type,
                'adjustment_amount' => $type === 'discount' ? -abs($amount) : abs($amount),
                // A bulk insert writes the columns it is given, so the
                // timestamps the model would have set are set here.
                'created_at' => $now,
                'updated_at' => $now,
            ];
        }

        return $inserts;
    }
}
