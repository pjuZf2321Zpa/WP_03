<?php

declare(strict_types=1);

namespace FluentCartPro\App\Services\Invoice\Mapper;

if (!defined('ABSPATH')) {
    exit;
}

use FluentCart\Api\StoreSettings;
use FluentCart\App\Helpers\Status;
use FluentCart\App\Models\Order;
use FluentCart\Framework\Support\Arr;
use FluentCart\App\Services\Renderer\Receipt\TaxSummaryHelper;
use FluentCartPro\App\Services\Invoice\Domain\Customer;
use FluentCartPro\App\Services\Invoice\Domain\DocumentCharge;
use FluentCartPro\App\Services\Invoice\Domain\En16931Invoice;
use FluentCartPro\App\Services\Invoice\Domain\InvoiceLine;
use FluentCartPro\App\Services\Invoice\Domain\Money;
use FluentCartPro\App\Services\Invoice\Domain\Seller;
use FluentCartPro\App\Services\Invoice\Domain\Tax\TaxCategoryResolver;
use FluentCartPro\App\Services\Invoice\Domain\Tax\VatIdentifier;
use FluentCartPro\App\Services\PDF\SellerDetailsService;

/**
 * Maps FluentCart Order model to En16931Invoice DTO.
 */
final class En16931InvoiceMapper
{
    private UnitMapper $unitMapper;

    private TaxCategoryResolver $taxCategoryResolver;

    private string $sellerCountry;

    private StoreSettings $storeSettings;

    /** Per-order reverse-charge state, computed once at the start of map(). */
    private bool $reverseChargeApplies = false;

    private string $reverseChargeReasonText = '';

    public function __construct(?UnitMapper $unitMapper = null, ?TaxCategoryResolver $taxCategoryResolver = null)
    {
        $this->unitMapper          = $unitMapper ?? new UnitMapper();
        $this->taxCategoryResolver = $taxCategoryResolver ?? new TaxCategoryResolver();
        $this->storeSettings       = new StoreSettings();
        $this->sellerCountry       = strtoupper(trim((string) $this->storeSettings->get('store_country', '')));
    }

    /**
     * Resolve seller identity fields for this order.
     *
     * The store_business_info meta key is written at order placement by
     * TaxModule::storeBusinessInfoOnOrder() in the fluent-cart (free) plugin
     * (hooked on fluent_cart/checkout/prepare_other_data, priority 9).
     * See: fluent-cart/app/Modules/Tax/TaxModule.php — storeBusinessInfoOnOrder()
     *
     * Reads from that snapshot so the e-invoice reflects the store identity that was
     * valid when the order was placed. Falls back to live SellerDetailsService for
     * orders placed before this feature (no meta key present).
     */
    private function resolveSellerDetails(Order $order): array
    {
        $details  = SellerDetailsService::getSellerDetails();
        $snapshot = $order->getMeta('store_business_info', false);
        if ($snapshot !== false) {
            if (isset($snapshot['seller_vat_id']))          $details['seller_vat_id']                = (string) $snapshot['seller_vat_id'];
            if (isset($snapshot['seller_tax_id']))          $details['seller_tax_id']                = (string) $snapshot['seller_tax_id'];
            if (isset($snapshot['company_name']))           $details['seller_legal_name']            = (string) $snapshot['company_name'];
            if (isset($snapshot['legal_registration_id']))  $details['seller_legal_registration_id'] = (string) $snapshot['legal_registration_id'];
        }
        return $details;
    }

    /**
     * Map an Order (with relations loaded) to an En16931Invoice DTO.
     *
     * FluentCart stores all monetary amounts as BIGINT cents in the database.
     * The model 'double' casts return the raw cent value as a PHP float
     * (e.g., $10.00 is stored as 1000, model returns 1000.0).
     */
    public function map(Order $order): En16931Invoice
    {
        // Checkout deducts gifted upgrade discounts after tax; they are not payments.
        if ((int) Arr::get($order->config, 'upgrade_discount', 0) > 0) {
            throw new \InvalidArgumentException(
                __('E-invoice cannot be generated for a post-tax upgrade discount. The discount must be reconciled with the taxable invoice amounts before export.', 'fluent-cart-pro')
            );
        }

        $sellerDetails   = $this->resolveSellerDetails($order);
        $sellerVatRaw    = trim((string) ($sellerDetails['seller_vat_id'] ?? ''));
        $vatId           = VatIdentifier::fromRaw($sellerVatRaw, $this->sellerCountry);
        $sellerLegalName = trim((string) ($sellerDetails['seller_legal_name'] ?? ''));
        $sellerName      = $sellerLegalName !== '' ? $sellerLegalName : (string) $this->storeSettings->get('store_name', '');

        $seller = new Seller([
            'name'                      => $sellerName,
            'address_line_1'            => (string) $this->storeSettings->get('store_address1', ''),
            'address_line_2'            => (string) $this->storeSettings->get('store_address2', ''),
            'city'                      => (string) $this->storeSettings->get('store_city', ''),
            'state'                     => (string) $this->storeSettings->get('store_state', ''),
            'zip'                       => (string) $this->storeSettings->get('store_postcode', ''),
            'country_code'              => $this->sellerCountry,
            'vat_id'                    => $vatId->asString(),
            'legal_registration_id'     => (string) ($sellerDetails['seller_legal_registration_id'] ?? ''),
            'legal_registration_scheme' => (string) ($sellerDetails['seller_legal_registration_scheme'] ?? ''),
            'electronic_address'        => (string) ($sellerDetails['seller_electronic_address'] ?? '') ?: null,
        ]);

        $sellerCountry = $this->sellerCountry;

        $billing      = $order->billing_address;
        $buyerCountry = $billing ? strtoupper(trim((string) ($billing->country ?? ''))) : '';
        if ($buyerCountry === '' && $sellerCountry !== '') {
            $buyerCountry = $sellerCountry;
        }

        $customerModel = $order->customer;
        $customerName  = '';
        $companyName   = '';
        $email         = '';

        if ($customerModel) {
            $customerName = trim((string) ($customerModel->first_name ?? '') . ' ' . (string) ($customerModel->last_name ?? ''));
            $email        = (string) ($customerModel->email ?? '');
        }

        if ($billing) {
            if (empty($customerName)) {
                $customerName = (string) ($billing->name ?? '');
            }
            $companyName = (string) ($billing->company_name ?? '');
        }

        // BT-48 Buyer VAT identifier — sourced from already-persisted order tax data.
        // Precedence: business_info tax number → billing address vat_number → ''.
        // Both reads are null-safe so legacy / B2C orders without buyer VAT yield ''.
        $businessInfo = $order->getBusinessInfo();
        $buyerVatId   = '';
        if (!empty($businessInfo['tax_number'])) {
            $buyerVatId = trim((string) $businessInfo['tax_number']);
        } elseif ($billing && !empty($billing->vat_number)) {
            $buyerVatId = trim((string) $billing->vat_number);
        }

        // Reverse-charge state for this order, resolved once. isReverseChargeTaxOrder()
        // reads the persisted reverse_charge_applied flag and falls back to the
        // validated-VAT + zero-tax heuristic, so legacy/migrated RC orders are caught too.
        $this->reverseChargeApplies    = (bool) $order->isReverseChargeTaxOrder();
        $this->reverseChargeReasonText = $this->reverseChargeApplies
            ? trim((string) ($businessInfo['reverse_charge_declaration'] ?? ''))
            : '';

        /**
         * Filter the buyer VAT identifier (BT-48) before it is written to the e-invoice XML.
         * Lets integrations normalize or override the value (e.g. strip a country prefix).
         *
         * @param string $buyerVatId The resolved buyer VAT identifier.
         * @param array  $context    ['order' => Order]
         */
        $buyerVatId = (string) apply_filters('fluent_cart/einvoice/buyer_vat_id', $buyerVatId, [
            'order' => $order,
        ]);

        $buyer = new Customer([
            'customer_name'           => $customerName,
            'company_name'            => $companyName,
            'email'                   => $email,
            'address_line_1'          => $billing ? (string) ($billing->address_1 ?? '') : '',
            'address_line_2'          => $billing ? (string) ($billing->address_2 ?? '') : '',
            'city'                    => $billing ? (string) ($billing->city ?? '') : '',
            'state'                   => $billing ? (string) ($billing->state ?? '') : '',
            'zip'                     => $billing ? (string) ($billing->postcode ?? '') : '',
            'country_code'            => $buyerCountry,
            'buyer_vat_id'            => $buyerVatId,
            'buyer_electronic_address' => null,
        ]);

        $currency   = (string) ($order->currency ?? 'EUR');
        $orderRates = $this->recordedOrderRates($order);

        $feeTaxLines = $this->readArray($order->getMeta('fee_tax_lines', []));
        if (!$feeTaxLines && (int) $order->getMeta('fee_tax', 0) > 0) {
            $feeTaxLines = [['label' => '', 'tax_amount' => (int) $order->getMeta('fee_tax', 0), 'inclusive' => false]];
        }

        $amounts = [];
        foreach ($order->order_items ?: [] as $item) {
            $otherInfo = $this->readArray($item->other_info ?? null);
            // Core leaves trial items out of the order subtotal.
            if ((int) Arr::get($otherInfo, 'trial_days', 0) > 0) {
                continue;
            }
            $feeTax = $item->payment_type === 'fee' && Arr::get($otherInfo, 'taxable', true)
                ? $this->takeFeeTaxLine($feeTaxLines, (string) $item->title)
                : null;
            $amounts[] = $this->describeItem($item, $order, $orderRates, $feeTax);
        }
        $shipping = $this->describeShipping($order, $orderRates);
        if ($shipping) {
            $amounts[] = $shipping;
        }
        $amounts = $this->balanceInclusiveCategories($amounts, (new Money($currency, 0))->minorUnitCents());

        $grossCents = 0;
        foreach ($amounts as $amount) {
            $grossCents += $amount['net'] + $amount['vat'];
        }

        $lines   = [];
        $charges = [];
        foreach ($amounts as $amount) {
            if ($amount['item'] === null) {
                $charges[] = new DocumentCharge(
                    new Money($currency, $amount['net']),
                    $amount['tax']['categoryCode'],
                    $amount['percent'],
                    'Shipping',
                    $amount['tax']['exemptionReasonCode'],
                    $amount['tax']['exemptionReasonText']
                );
                continue;
            }
            $lines[] = $this->mapLine($amount, $currency, (string) (count($lines) + 1));
        }

        // Prorated credit represents payment carried over from the previous plan.
        $orderTotalCents    = (int) round((float) ($order->total_amount ?? 0));
        $postTaxCreditCents = min(
            (int) Arr::get($order->config, 'prorate_credit', 0),
            max(0, $grossCents - $orderTotalCents)
        );
        $payableCents = $orderTotalCents + $postTaxCreditCents;
        $prepaidCents = min($payableCents, (int) round((float) ($order->total_paid ?? 0)) + $postTaxCreditCents);

        /** 
        *  payment due date or the payment terms should be added 
        * [BR-CO-25]-In case the Amount due for payment (BT-115) is positive, either the Payment due date (BT-9) or the Payment terms (BT-20) shall be present.
        * 
        */

        return new En16931Invoice([
            'invoiceNumber'       => (string) ($order->invoice_no ?? ''),
            'issueDate'           => $this->formatDateForDto($order->created_at ?? null),
            'dueDate'             => $this->formatDateForDto($order->created_at ?? null), //required !!!
            'currency'            => $currency,
            'seller'              => $seller,
            'buyer'               => $buyer,
            'lines'               => $lines,
            'allowances'          => [],
            'charges'             => $charges,
            'prepaidAmountCents'  => $prepaidCents,
            'payableAmountCents'  => $payableCents,
            'paymentMeans'        => $this->mapPaymentMeans($order->payment_method ?? ''),
            'notes'               => (string) ($order->note ?? ''),
            'buyer_reference'     => '',
            'purchase_order_ref'  => '',
            'payment_term'        => __('Due upon receipt', 'fluent-cart-pro'),
        ]);
    }

    /**
     * Net amount of an order item before category balancing. Checkout items carry gross
     * subtotals when tax-inclusive; renewal items always carry net subtotals.
     */
    private function describeItem(object $item, Order $order, array $orderRates, ?array $feeTax = null): array
    {
        $taxCents      = (int) round((float) ($item->tax_amount ?? 0));
        $subtotalCents = (int) round((float) ($item->subtotal ?? 0));
        $discountCents = (int) round((float) ($item->discount_total ?? 0));
        $quantity      = (int) ($item->quantity ?? 1);
        $unitCents     = (int) round((float) ($item->unit_price ?? 0));
        $taxConfig     = $this->lineTaxConfig($item);
        $inclusive     = (bool) Arr::get($taxConfig, 'inclusive', (int) $order->tax_behavior === 2);

        // Item refunds reduce quantity and tax in place; the invoice shows the order as issued.
        $originalQuantity = (int) Arr::get($this->readArray($item->line_meta ?? null), 'original_quantity', 0);
        $rateLines        = (array) Arr::get($taxConfig, 'rates', []);
        if ($originalQuantity > 0 && $rateLines) {
            $quantity = $originalQuantity;
            $taxCents = (int) array_sum(array_map('intval', array_column($rateLines, 'tax_amount')));
        }

        if ($feeTax !== null) {
            $taxCents  = (int) Arr::get($feeTax, 'tax_amount', 0);
            $inclusive = !empty($feeTax['inclusive']);
        }

        if ($order->type === Status::ORDER_TYPE_RENEWAL) {
            $netCents = $subtotalCents - $discountCents;
        } elseif ($inclusive) {
            $netCents = $subtotalCents - $discountCents - $taxCents;
        } else {
            $netCents = $unitCents * $quantity - $discountCents;
        }

        $rate = $this->resolveLineTaxRate($item, $taxCents, $netCents, $orderRates);
        $tax  = $this->resolveTaxCategory($rate, $this->isLineTaxExempt($item), $order, $item);

        return [
            'item'      => $item,
            'quantity'  => $quantity,
            'net'       => $netCents,
            'vat'       => $taxCents,
            'inclusive' => $inclusive,
            'listGross' => $inclusive && $order->type !== Status::ORDER_TYPE_RENEWAL ? $subtotalCents : null,
            'tax'       => $tax,
            'percent'   => number_format((float) $tax['ratePercent'], 2, '.', ''),
        ];
    }

    /** Fee items carry no tax; core stores it per fee in order meta. */
    private function takeFeeTaxLine(array &$feeTaxLines, string $label): ?array
    {
        $index = key($feeTaxLines);
        foreach ($feeTaxLines as $key => $line) {
            if ((string) Arr::get($line, 'label', '') === $label) {
                $index = $key;
                break;
            }
        }
        if ($index === null) {
            return null;
        }
        $line = $feeTaxLines[$index];
        unset($feeTaxLines[$index]);

        return is_array($line) ? $line : null;
    }

    /** Signup-fee items written before tax_config existed keep rates at the line_meta root. */
    private function lineTaxConfig(object $item): array
    {
        $lineMeta = $this->readArray($item->line_meta ?? null);
        $config   = Arr::get($lineMeta, 'tax_config');

        return is_array($config) ? $config : $lineMeta;
    }

    private function describeShipping(Order $order, array $orderRates): ?array
    {
        $shippingCents = (int) round((float) ($order->shipping_total ?? 0));
        if ($shippingCents <= 0) {
            return null;
        }

        $taxCents  = (int) round((float) ($order->shipping_tax ?? 0));
        $inclusive = TaxSummaryHelper::isShippingTaxInclusive($order);
        $netCents  = $inclusive ? $shippingCents - $taxCents : $shippingCents;

        $shippingRates = array_unique(array_map('floatval', array_column($order->getDisplayShippingTaxLines(), 'rate_percent')));
        if (count($shippingRates) === 1 && reset($shippingRates) > 0) {
            $rate = reset($shippingRates);
        } else {
            $rate = ($netCents > 0 && $taxCents > 0) ? $this->snapRate($taxCents / $netCents * 100, $orderRates) : 0.0;
        }
        $tax = $this->resolveTaxCategory($rate, false, $order, null);

        return [
            'item'      => null,
            'net'       => $netCents,
            'vat'       => $taxCents,
            'inclusive' => $inclusive,
            'tax'       => $tax,
            'percent'   => number_format((float) $tax['ratePercent'], 2, '.', ''),
        ];
    }

    /**
     * Allocate category rounding within inclusive line capacities. Unallocated cents
     * remain in the invoice rounding amount instead of making line prices negative.
     */
    private function balanceInclusiveCategories(array $amounts, int $unitCents): array
    {
        $categories = [];
        foreach ($amounts as $index => $amount) {
            $categories[$amount['tax']['categoryCode'] . '|' . $amount['percent']][] = $index;
        }

        foreach ($categories as $indexes) {
            $rate = (float) $amounts[$indexes[0]]['percent'];
            $inclusiveIndexes = [];
            $lineGross = [];
            $gross = 0;
            $net = 0;
            $vat = 0;
            foreach ($indexes as $index) {
                $gross += $amounts[$index]['net'] + $amounts[$index]['vat'];
                $lineGross[$index] = (int) round(($amounts[$index]['net'] + $amounts[$index]['vat']) / $unitCents) * $unitCents;
                $amounts[$index]['net'] = (int) round($amounts[$index]['net'] / $unitCents) * $unitCents;
                $net += $amounts[$index]['net'];
                $vat += $amounts[$index]['vat'];
                if ($amounts[$index]['inclusive']) {
                    $inclusiveIndexes[] = $index;
                }
            }
            $expectedVat = (int) round($net * $rate / 100 / $unitCents) * $unitCents;
            if (abs($expectedVat - $vat) > count($indexes) * $unitCents) {
                throw new \InvalidArgumentException(
                    __('E-invoice recorded VAT does not match the taxable amounts and rate within rounding tolerance.', 'fluent-cart-pro')
                );
            }
            if ($rate <= 0 || !$inclusiveIndexes) {
                continue;
            }
            usort($inclusiveIndexes, function ($left, $right) use ($amounts): int {
                return ($amounts[$right]['net'] <=> $amounts[$left]['net']) ?: ($left <=> $right);
            });
            $remaining = $this->netForGross($gross, $rate, $net, $vat, $unitCents) - $net;
            foreach ($inclusiveIndexes as $index) {
                $capacity = $remaining < 0
                    ? max(0, $amounts[$index]['net'])
                    : max(0, $lineGross[$index] - $amounts[$index]['net']);
                $adjustment = min(abs($remaining), $unitCents, $capacity) * ($remaining < 0 ? -1 : 1);
                $amounts[$index]['net'] += $adjustment;
                $remaining -= $adjustment;
                if ($remaining === 0) {
                    break;
                }
            }
        }

        return $amounts;
    }

    /**
     * Net base whose VAT at $rate adds back up to $grossCents. Some gross amounts have no
     * exact split; then the closest one that does not overstate the recorded VAT wins and
     * the remaining cent goes to the invoice rounding amount.
     */
    private function netForGross(int $grossCents, float $rate, int $recordedNetCents, int $recordedVatCents, int $unitCents): int
    {
        $best      = $recordedNetCents;
        $bestScore = null;
        $center    = (int) round($grossCents * 100 / (100 + $rate) / $unitCents) * $unitCents;
        for ($candidate = $center - 2 * $unitCents; $candidate <= $center + 2 * $unitCents; $candidate += $unitCents) {
            $candidateVat = (int) round($candidate * $rate / 100 / $unitCents) * $unitCents;
            $score = [
                abs($candidate + $candidateVat - $grossCents),
                $candidateVat > $recordedVatCents ? 1 : 0,
                abs($candidate - $recordedNetCents),
            ];
            if ($bestScore === null || $score < $bestScore) {
                $best      = $candidate;
                $bestScore = $score;
            }
        }

        return $best;
    }

    private function mapLine(array $amount, string $currency, string $lineId): InvoiceLine
    {
        $item          = $amount['item'];
        $netCents      = $amount['net'];
        $quantity      = $amount['quantity'];
        $unitCents     = (new Money($currency, 0))->minorUnitCents();
        $priceCents    = (int) round((float) ($item->unit_price ?? 0));
        $discountCents = (int) round((float) ($item->discount_total ?? 0));
        $baseQuantity  = 1;

        if ($amount['inclusive'] || $priceCents * $quantity - $discountCents !== $netCents) {
            if (!$amount['inclusive']) {
                $listNetCents = $netCents + $discountCents;
            } elseif ($discountCents > 0 && $amount['listGross'] !== null) {
                $listNetCents = max($netCents, (int) round($amount['listGross'] * 100 / (100 + (float) $amount['percent']) / $unitCents) * $unitCents);
            } else {
                $listNetCents = $netCents;
            }
            $discountCents = $listNetCents - $netCents;
            $priceCents    = $listNetCents;
            // A price per full quantity (BT-149) keeps cents a per-unit price would round away.
            if ($quantity > 1 && $listNetCents % ($quantity * $unitCents) !== 0) {
                $baseQuantity = $quantity;
            } else {
                $priceCents = intdiv($listNetCents, max(1, $quantity));
            }
        }

        $name = trim((string) ($item->title ?: ($item->post_title ?? '')));

        return new InvoiceLine([
            'id'                  => $lineId,
            'name'                => $name === '' ? '-' : $name,
            'quantity'            => $quantity,
            'unitCode'            => $this->unitMapper->resolveFromItem($item),
            'currency'            => $currency,
            'netUnitPriceCents'   => $priceCents,
            'priceBaseQuantity'   => $baseQuantity,
            'taxCategory'         => $amount['tax']['categoryCode'],
            'taxPercent'          => $amount['percent'],
            'exemptionReasonCode' => $amount['tax']['exemptionReasonCode'],
            'exemptionReasonText' => $amount['tax']['exemptionReasonText'],
            'lineAllowanceCents'  => $discountCents,
            'lineChargeCents'     => 0,
            'lineTotalCents'      => $netCents,
        ]);
    }

    /**
     * Prefer the single rate the Tax module stored on the line. Older lines only have amounts,
     * so the derived rate is snapped to a rate recorded on the order.
     */
    private function resolveLineTaxRate(object $item, int $taxAmountCents, int $netAmountCents, array $orderRates = []): float
    {
        $rates = Arr::get($this->lineTaxConfig($item), 'rates', []);
        if (is_array($rates) && count($rates) === 1 && isset($rates[0]['rate_percent']) && $rates[0]['rate_percent'] !== '') {
            return round((float) $rates[0]['rate_percent'], 2);
        }

        if ($taxAmountCents > 0 && $netAmountCents > 0) {
            return $this->snapRate($taxAmountCents / $netAmountCents * 100, $orderRates);
        }

        return 0.0;
    }

    /** @return float[] */
    private function recordedOrderRates(Order $order): array
    {
        $lines = array_merge($order->getDisplayTaxLines(), $order->getDisplayShippingTaxLines());
        $rates = array_filter(array_map('floatval', array_column($lines, 'rate_percent')));

        return array_values(array_unique($rates));
    }

    private function snapRate(float $derivedRate, array $orderRates): float
    {
        $closest = null;
        foreach ($orderRates as $rate) {
            if (abs($rate - $derivedRate) < 0.5 && ($closest === null || abs($rate - $derivedRate) < abs($closest - $derivedRate))) {
                $closest = $rate;
            }
        }

        return $closest !== null ? round($closest, 2) : round($derivedRate, 2);
    }

    /**
     * Best-effort exempt detection. tax_exempt is authored on the product variation
     * and is not reliably persisted onto the order line; it is honored here only when
     * present. Absent → treated as not-exempt (zero-rated), preserving prior behavior.
     * Stores can also force category E via the fluent_cart/einvoice/tax_category filter.
     */
    private function isLineTaxExempt(object $item): bool
    {
        $otherInfo = $this->readArray($item->other_info ?? null);

        return isset($otherInfo['tax_exempt']) && $otherInfo['tax_exempt'] === 'yes';
    }

    /**
     * Resolve the EN 16931 VAT category for a line or shipping charge and let
     * integrations override it.
     *
     * @param object|null $line The order item, or null for shipping/document charges.
     * @return array{categoryCode:string, ratePercent:float, exemptionReasonCode:string, exemptionReasonText:string}
     */
    private function resolveTaxCategory(float $ratePercent, bool $isExempt, Order $order, $line): array
    {
        if ($this->reverseChargeApplies) {
            // Whole-order reverse charge: every line and shipping charge is AE, rate 0,
            // with the VATEX-EU-AE exemption reason. Seller + buyer VAT (BT-31/BT-48)
            // are carried by the seller/buyer DTOs and asserted by the profile (BR-AE).
            $resolved = $this->taxCategoryResolver->resolveReverseCharge($this->reverseChargeReasonText);
        } else {
            $resolved = $this->taxCategoryResolver->resolve($ratePercent, $isExempt);
        }

        /**
         * Filter the derived EN 16931 VAT category before it is written to the XML.
         * Lets regional add-ons map a line to a different category (e.g. force E with a
         * VATEX reason). Must return the same array shape it received.
         *
         * @param array $resolved {categoryCode, ratePercent, exemptionReasonCode, exemptionReasonText}
         * @param array $context  ['order' => Order, 'line' => object|null]
         */
        $filtered = apply_filters('fluent_cart/einvoice/tax_category', $resolved, [
            'order' => $order,
            'line'  => $line,
        ]);

        if (!is_array($filtered)) {
            return $resolved;
        }

        return [
            'categoryCode'        => (string) ($filtered['categoryCode'] ?? $resolved['categoryCode']),
            'ratePercent'         => (float) ($filtered['ratePercent'] ?? $resolved['ratePercent']),
            'exemptionReasonCode' => (string) ($filtered['exemptionReasonCode'] ?? $resolved['exemptionReasonCode']),
            'exemptionReasonText' => (string) ($filtered['exemptionReasonText'] ?? $resolved['exemptionReasonText']),
        ];
    }

    /**
     * Normalize a model attribute that may be an array, a JSON string, or null.
     */
    private function readArray($value): array
    {
        if (is_array($value)) {
            return $value;
        }
        if (is_string($value) && $value !== '') {
            $decoded = json_decode($value, true);
            return is_array($decoded) ? $decoded : [];
        }
        return [];
    }

    /**
     * Map FluentCart payment method to UN/CEFACT payment means code.
     */
    private function mapPaymentMeans(string $method): string
    {
        $map = [
            'stripe'     => '48', // Bank card
            'paypal'     => '68', // Online payment service
            'mollie'     => '68',
            'square'     => '48',
            'airwallex'  => '48',
            'paystack'   => '48',
            'razorpay'   => '48',
            'cod'        => '10', // In cash
        ];

        return $map[$method] ?? '1'; // Instrument not defined
    }

    private function formatDateForDto($value): ?string
    {
        if ($value === null || $value === '') {
            return null;
        }
        if ($value instanceof \DateTimeInterface) {
            return $value->format('Y-m-d');
        }
        try {
            $date = new \DateTime((string) $value);
            return $date->format('Y-m-d');
        } catch (\Exception $e) {
            return null;
        }
    }
}
