<?php

namespace BitApps\IntegrationsPro\Actions\WebbaBooking;

use Exception;
use WBK_Booking_Factory;
use WBK_Model_Utils;

if (!\defined('ABSPATH')) {
    exit;
}

/**
 * Webba Booking write actions (Pro). Free fires the hooks, the logic lives here.
 */
final class WebbaBookingProActions
{
    public static function createBooking($defaultResponse, $fieldData, $integrationDetails = null)
    {
        if ($error = self::guard()) {
            return $error;
        }

        $serviceId = (int) self::detail($integrationDetails, 'selectedService');

        if (empty($serviceId)) {
            return self::errorResponse(__('Service is required to create a booking', 'bit-integrations-pro'));
        }

        foreach (['name', 'email', 'time', 'duration', 'quantity'] as $required) {
            if (empty($fieldData[$required])) {
                // translators: %s is the missing field name.
                return self::errorResponse(\sprintf(__('%s is required to create a booking', 'bit-integrations-pro'), ucfirst($required)));
            }
        }

        $time = Helper::toTimestamp($fieldData['time']);

        if ($time <= 0) {
            return self::errorResponse(__('Invalid booking date/time. Use a Unix timestamp or a date such as 2026-06-10 14:30.', 'bit-integrations-pro'));
        }

        $data = [
            'name'             => sanitize_text_field($fieldData['name']),
            'email'            => sanitize_email($fieldData['email']),
            'phone'            => sanitize_text_field($fieldData['phone'] ?? ''),
            'description'      => sanitize_textarea_field($fieldData['description'] ?? ''),
            'service_id'       => $serviceId,
            'service_category' => (int) self::detail($integrationDetails, 'selectedCategory'),
            'duration'         => (int) $fieldData['duration'],
            'quantity'         => (int) $fieldData['quantity'],
            'time_offset'      => (int) ($fieldData['time_offset'] ?? 0),
            'time'             => $time,
            'extra'            => '',
            'attachment'       => '',
        ];

        if ($staffId = (int) self::detail($integrationDetails, 'selectedStaff')) {
            $data['staff_member_id'] = $staffId;
        }

        if ($locationId = (int) self::detail($integrationDetails, 'selectedLocation')) {
            $data['location_id'] = $locationId;
        }

        $factory = new WBK_Booking_Factory();
        $result = $factory->build_from_array($data);

        if (!\is_array($result) || empty($result[0])) {
            return self::errorResponse($result[1] ?? __('Failed to create booking', 'bit-integrations-pro'));
        }

        $bookingId = (int) $result[1];
        $factory->post_production([$bookingId], 'on_manual_booking');

        $booking = Helper::getBookingData($bookingId);

        if (empty($booking)) {
            return self::errorResponse(__('Failed to create booking', 'bit-integrations-pro'));
        }

        return self::successResponse(__('Booking created successfully', 'bit-integrations-pro'), ['booking' => $booking]);
    }

    public static function updateBookingStatus($defaultResponse, $fieldData, $integrationDetails = null)
    {
        if ($error = self::guard('\WBK_Model_Utils')) {
            return $error;
        }

        $bookingId = (int) self::detail($integrationDetails, 'selectedBooking');
        $status = (string) self::detail($integrationDetails, 'selectedStatus');

        if (empty($bookingId) || $status === '') {
            return self::errorResponse(__('Booking and status are required', 'bit-integrations-pro'));
        }

        if (!Helper::bookingExists($bookingId)) {
            return self::errorResponse(__('Booking not found in Webba Booking', 'bit-integrations-pro'));
        }

        return self::tryRun(static function () use ($bookingId, $status) {
            WBK_Model_Utils::set_booking_status($bookingId, $status);

            return self::successResponse(__('Booking status updated successfully', 'bit-integrations-pro'), ['booking' => Helper::getBookingData($bookingId)]);
        });
    }

    public static function approveBooking($defaultResponse, $fieldData, $integrationDetails = null)
    {
        if ($error = self::guard()) {
            return $error;
        }

        $bookingId = self::resolveBookingId($integrationDetails);

        if (\is_array($bookingId)) {
            return $bookingId;
        }

        return self::tryRun(static function () use ($bookingId) {
            (new WBK_Booking_Factory())->set_as_approved([$bookingId]);

            return self::successResponse(__('Booking approved successfully', 'bit-integrations-pro'), ['booking' => Helper::getBookingData($bookingId)]);
        });
    }

    public static function cancelBooking($defaultResponse, $fieldData, $integrationDetails = null)
    {
        if ($error = self::guard()) {
            return $error;
        }

        $bookingId = self::resolveBookingId($integrationDetails);

        if (\is_array($bookingId)) {
            return $bookingId;
        }

        $by = \in_array($fieldData['by'] ?? '', ['customer', 'administrator', 'auto'], true)
            ? $fieldData['by']
            : 'administrator';

        return self::tryRun(static function () use ($bookingId, $by) {
            (new WBK_Booking_Factory())->destroy($bookingId, $by, false);

            return self::successResponse(__('Booking cancelled successfully', 'bit-integrations-pro'), ['booking_id' => $bookingId]);
        });
    }

    public static function deleteBooking($defaultResponse, $fieldData, $integrationDetails = null)
    {
        if ($error = self::guard()) {
            return $error;
        }

        $bookingId = self::resolveBookingId($integrationDetails);

        if (\is_array($bookingId)) {
            return $bookingId;
        }

        return self::tryRun(static function () use ($bookingId) {
            (new WBK_Booking_Factory())->destroy($bookingId, '', true);

            return self::successResponse(__('Booking deleted successfully', 'bit-integrations-pro'), ['booking_id' => $bookingId]);
        });
    }

    public static function setBookingAsPaid($defaultResponse, $fieldData, $integrationDetails = null)
    {
        if ($error = self::guard()) {
            return $error;
        }

        $bookingId = (int) self::detail($integrationDetails, 'selectedBooking');

        if (empty($bookingId)) {
            return self::errorResponse(__('Booking is required', 'bit-integrations-pro'));
        }

        if (empty($fieldData['method']) || !isset($fieldData['amount']) || $fieldData['amount'] === '') {
            return self::errorResponse(__('Payment method and amount are required', 'bit-integrations-pro'));
        }

        if (!Helper::bookingExists($bookingId)) {
            return self::errorResponse(__('Booking not found in Webba Booking', 'bit-integrations-pro'));
        }

        $method = sanitize_text_field($fieldData['method']);
        $amount = (float) $fieldData['amount'];

        return self::tryRun(static function () use ($bookingId, $method, $amount) {
            (new WBK_Booking_Factory())->set_as_paid([$bookingId], $method, $amount);

            return self::successResponse(__('Booking marked as paid successfully', 'bit-integrations-pro'), ['booking' => Helper::getBookingData($bookingId)]);
        });
    }

    public static function createCoupon($defaultResponse, $fieldData)
    {
        if ($error = self::guard()) {
            return $error;
        }

        if (empty($fieldData['name'])) {
            return self::errorResponse(__('Coupon name is required', 'bit-integrations-pro'));
        }

        return self::saveModel('\WBK_Coupon', null, self::couponColumns($fieldData), 'Coupon');
    }

    public static function updateCoupon($defaultResponse, $fieldData, $integrationDetails = null)
    {
        if ($error = self::guard()) {
            return $error;
        }

        $couponId = (int) self::detail($integrationDetails, 'selectedCoupon');

        if (empty($couponId)) {
            return self::errorResponse(__('Coupon is required', 'bit-integrations-pro'));
        }

        return self::saveModel('\WBK_Coupon', $couponId, self::couponColumns($fieldData), 'Coupon');
    }

    public static function createService($defaultResponse, $fieldData, $integrationDetails = null)
    {
        if ($error = self::guard()) {
            return $error;
        }

        if (empty($fieldData['name'])) {
            return self::errorResponse(__('Service name is required', 'bit-integrations-pro'));
        }

        return self::saveModel('\WBK_Service', null, self::serviceColumns($fieldData, $integrationDetails), 'Service');
    }

    public static function updateService($defaultResponse, $fieldData, $integrationDetails = null)
    {
        if ($error = self::guard()) {
            return $error;
        }

        $serviceId = (int) self::detail($integrationDetails, 'selectedService');

        if (empty($serviceId)) {
            return self::errorResponse(__('Service is required', 'bit-integrations-pro'));
        }

        return self::saveModel('\WBK_Service', $serviceId, self::serviceColumns($fieldData, $integrationDetails), 'Service');
    }

    public static function createServiceCategory($defaultResponse, $fieldData)
    {
        if ($error = self::guard()) {
            return $error;
        }

        if (empty($fieldData['name'])) {
            return self::errorResponse(__('Category name is required', 'bit-integrations-pro'));
        }

        $columns = ['name' => sanitize_text_field($fieldData['name'])];

        if (isset($fieldData['list']) && $fieldData['list'] !== '') {
            $columns['list'] = sanitize_text_field($fieldData['list']);
        }

        return self::saveModel('\WBK_Service_Category', null, $columns, 'Service category');
    }

    public static function createStaffMember($defaultResponse, $fieldData)
    {
        if ($error = self::guard()) {
            return $error;
        }

        if (empty($fieldData['name'])) {
            return self::errorResponse(__('Staff member name is required', 'bit-integrations-pro'));
        }

        $columns = ['name' => sanitize_text_field($fieldData['name'])];

        if (!empty($fieldData['email'])) {
            $columns['email'] = sanitize_email($fieldData['email']);
        }

        return self::saveModel('\WBK_Staff_Member', null, $columns, 'Staff member');
    }

    public static function createLocation($defaultResponse, $fieldData)
    {
        if ($error = self::guard()) {
            return $error;
        }

        if (empty($fieldData['name'])) {
            return self::errorResponse(__('Location name is required', 'bit-integrations-pro'));
        }

        $columns = ['name' => sanitize_text_field($fieldData['name'])];

        foreach (['description', 'address'] as $optional) {
            if (isset($fieldData[$optional]) && $fieldData[$optional] !== '') {
                $columns[$optional] = sanitize_text_field($fieldData[$optional]);
            }
        }

        return self::saveModel('\WBK_Location', null, $columns, 'Location');
    }

    private static function couponColumns($fieldData)
    {
        $columns = [];

        if (isset($fieldData['name']) && $fieldData['name'] !== '') {
            $columns['name'] = sanitize_text_field($fieldData['name']);
        }

        foreach (['amount_percentage', 'amount_fixed', 'maximum'] as $numericField) {
            if (isset($fieldData[$numericField]) && $fieldData[$numericField] !== '') {
                $columns[$numericField] = (float) $fieldData[$numericField];
            }
        }

        return $columns;
    }

    private static function serviceColumns($fieldData, $integrationDetails)
    {
        $columns = [];

        if (isset($fieldData['name']) && $fieldData['name'] !== '') {
            $columns['name'] = sanitize_text_field($fieldData['name']);
        }

        if (isset($fieldData['description']) && $fieldData['description'] !== '') {
            $columns['description'] = sanitize_textarea_field($fieldData['description']);
        }

        foreach (['duration', 'quantity'] as $intField) {
            if (isset($fieldData[$intField]) && $fieldData[$intField] !== '') {
                $columns[$intField] = (int) $fieldData[$intField];
            }
        }

        if (isset($fieldData['price']) && $fieldData['price'] !== '') {
            $columns['price'] = (float) $fieldData['price'];
        }

        if ($categoryId = (int) self::detail($integrationDetails, 'selectedCategory')) {
            $columns['categories'] = $categoryId;
        }

        return $columns;
    }

    /**
     * Verify the plugin is active and an optional dependency class is loaded.
     *
     * @param null|string $requiredClass extra class the action needs, beyond the core factory
     *
     * @return null|array null when ready, an error response otherwise
     */
    private static function guard($requiredClass = null)
    {
        if (!Helper::isPluginActive() || ($requiredClass !== null && !class_exists($requiredClass))) {
            return self::errorResponse(__('Webba Booking is not installed or activated', 'bit-integrations-pro'));
        }
    }

    /**
     * Resolve and validate the selected booking id.
     *
     * @param mixed $integrationDetails
     *
     * @return array|int the booking id on success, an error response otherwise
     */
    private static function resolveBookingId($integrationDetails)
    {
        $bookingId = (int) self::detail($integrationDetails, 'selectedBooking');

        if (empty($bookingId)) {
            return self::errorResponse(__('Booking is required', 'bit-integrations-pro'));
        }

        if (!Helper::bookingExists($bookingId)) {
            return self::errorResponse(__('Booking not found in Webba Booking', 'bit-integrations-pro'));
        }

        return $bookingId;
    }

    /**
     * Run a factory operation, converting any thrown exception into an error response.
     *
     * @param callable $operation
     *
     * @return array
     */
    private static function tryRun(callable $operation)
    {
        try {
            return $operation();
        } catch (Exception $e) {
            return self::errorResponse($e->getMessage());
        }
    }

    /**
     * Persist a WBK_* model and shape the response.
     *
     * @param string   $class
     * @param null|int $id
     * @param array    $columns
     * @param string   $label
     *
     * @return array
     */
    private static function saveModel($class, $id, array $columns, $label)
    {
        if (!class_exists($class)) {
            // translators: %s is the class name that is missing.
            return self::errorResponse(\sprintf(__('Required class %s does not exist', 'bit-integrations-pro'), $class));
        }

        if (empty($columns)) {
            return self::errorResponse(__('No fields provided to save', 'bit-integrations-pro'));
        }

        return self::tryRun(static function () use ($class, $id, $columns, $label) {
            $savedId = Helper::persistModel($class, $id, $columns);

            if ($savedId === false) {
                // translators: %s is the entity label, e.g. "coupon".
                return self::errorResponse(\sprintf(__('Failed to save the %s', 'bit-integrations-pro'), strtolower($label)));
            }

            // translators: %s is the entity label, e.g. "Coupon".
            return self::successResponse(\sprintf(__('%s saved successfully', 'bit-integrations-pro'), $label), ['id' => $savedId]);
        });
    }

    private static function detail($integrationDetails, $key)
    {
        if (\is_object($integrationDetails)) {
            return $integrationDetails->{$key} ?? '';
        }

        if (\is_array($integrationDetails)) {
            return $integrationDetails[$key] ?? '';
        }

        return '';
    }

    private static function successResponse($message, $data = [])
    {
        return [
            'success' => true,
            'message' => $message,
            'data'    => $data
        ];
    }

    private static function errorResponse($message)
    {
        return [
            'success' => false,
            'message' => $message
        ];
    }
}
