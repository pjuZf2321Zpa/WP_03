<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Actions\SystemeIO\SystemeIOHelperPro;
use BitApps\IntegrationsPro\Config;
use BitApps\IntegrationsPro\Core\Util\Hooks;

Hooks::filter(Config::withFreePrefix('systemeio_update_contact'), [SystemeIOHelperPro::class, 'updateContact'], 10, 5);
Hooks::filter(Config::withFreePrefix('systemeio_add_tag_to_existing_contact'), [SystemeIOHelperPro::class, 'addTagToExistingContact'], 10, 5);
