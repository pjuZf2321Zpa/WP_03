<?php

defined('ABSPATH') || exit;

class MeprDeactivationSurveyCtrl extends MeprBaseCtrl
{
    /**
     * Load hooks.
     *
     * @return void
     */
    public function load_hooks()
    {
        add_action('admin_enqueue_scripts', [$this, 'enqueue']);
        add_action('admin_footer', [$this, 'popup']);
    }

    /**
     * Checks whether the survey is skipped on the current request.
     *
     * The screen check runs first: the survey only exists on the Plugins
     * screen, and the development-URL lookup may consult the licensing
     * portal, so it is only evaluated there. The result is computed once per
     * request, so the skip filter fires once.
     *
     * @return boolean
     */
    protected function should_skip(): bool
    {
        static $skip = null;

        if (null === $skip) {
            $skip = !$this->is_plugin_page()
                || MeprHooks::apply_filters('mepr_deactivation_survey_skip', MeprUtils::is_dev_url());
        }

        return $skip;
    }

    /**
     * Enqueue scripts/styles.
     *
     * @return void
     */
    public function enqueue()
    {
        if ($this->should_skip()) {
            return;
        }

        wp_enqueue_style('mepr-deactivation-survey', MEPR_CSS_URL . '/admin-deactivation-survey.css', [], MEPR_VERSION);
        wp_enqueue_script('mepr-deactivation-survey', MEPR_JS_URL . '/admin_deactivation_survey.js', ['jquery'], MEPR_VERSION, true);

        wp_localize_script('mepr-deactivation-survey', 'MeprDeactivationSurvey', [
            'slug'                 => MEPR_PLUGIN_SLUG,
            'pleaseSelectAnOption' => __('Please select an option', 'memberpress'),
            'siteUrl'              => site_url(),
            'apiUrl'               => 'https://hooks.zapier.com/hooks/catch/43914/otu86c9/silent/',
        ]);
    }

    /**
     * Renders the deactivation survey popup.
     *
     * @return void
     */
    public function popup()
    {
        if ($this->should_skip()) {
            return;
        }

        $plugin = MEPR_PLUGIN_NAME;

        $options = [
            1 => [
                'label' => __('I no longer need the plugin', 'memberpress'),
            ],
            2 => [
                'label'   => __('I\'m switching to a different plugin', 'memberpress'),
                'details' => __('Please share which plugin', 'memberpress'),
            ],
            3 => [
                'label' => __('I couldn\'t get the plugin to work', 'memberpress'),
            ],
            4 => [
                'label' => __('It\'s a temporary deactivation', 'memberpress'),
            ],
            5 => [
                'label'   => __('Other', 'memberpress'),
                'details' => __('Please share the reason', 'memberpress'),
            ],
        ];

        MeprView::render('/admin/popups/deactivation_survey', compact('plugin', 'options'));
    }

    /**
     * Checks if the current page is a plugin page.
     *
     * @return boolean
     */
    protected function is_plugin_page()
    {
        return in_array(MeprUtils::get_current_screen_id(), ['plugins', 'plugins-network'], true);
    }
}
