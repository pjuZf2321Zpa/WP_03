<?php

namespace FluentCartPro\App\Services\FileSystem\Drivers\R2;

class R2ConnectionVerify
{
    public static function verify(string $accountId, string $secret, string $accessKey, string $bucket = '')
    {
        if (!$bucket) {
            $buckets = R2BucketList::get($accountId, $secret, $accessKey);

            if (is_wp_error($buckets)) {
                return $buckets;
            }

            return [
                'status'  => 'success',
                'message' => __('Connection successful', 'fluent-cart-pro'),
            ];
        }

        return static::checkBucketExistence($accountId, $secret, $accessKey, $bucket);
    }

    public static function checkBucketExistence(string $accountId, string $secret, string $accessKey, string $bucket)
    {
        if (!$accountId || !$secret || !$accessKey) {
            return new \WP_Error('missing_r2_credentials', __('R2 credentials are missing.', 'fluent-cart-pro'));
        }

        $bucket = sanitize_text_field($bucket);
        $endpoint = 'https://' . $accountId . '.r2.cloudflarestorage.com/' . $bucket;

        $headResult = static::headBucket($endpoint, $secret, $accessKey, 'auto', $bucket);
        if (is_wp_error($headResult)) {
            return $headResult;
        }

        return [
            'status' => 'success',
            'region' => static::fetchBucketRegion($endpoint, $secret, $accessKey, $bucket) ?: 'auto',
        ];
    }

    protected static function fetchBucketRegion(string $endpoint, string $secret, string $accessKey, string $bucket): string
    {
        $method = 'GET';
        $service = 's3';
        $host = (string) parse_url($endpoint, PHP_URL_HOST);
        $timestamp = gmdate('Ymd\THis\Z');
        $date = gmdate('Ymd');
        $canonicalUri = '/' . $bucket;
        $canonicalQuery = 'location=';
        $payloadHash = hash('sha256', '');
        $canonicalHeaders = 'host:' . $host . "\n"
            . 'x-amz-content-sha256:' . $payloadHash . "\n"
            . 'x-amz-date:' . $timestamp . "\n";
        $signedHeaders = 'host;x-amz-content-sha256;x-amz-date';

        $canonicalRequest = $method . "\n" . $canonicalUri . "\n" . $canonicalQuery . "\n"
            . $canonicalHeaders . "\n" . $signedHeaders . "\n" . $payloadHash;

        $credentialScope = $date . '/auto/' . $service . '/aws4_request';
        $stringToSign = 'AWS4-HMAC-SHA256' . "\n" . $timestamp . "\n" . $credentialScope . "\n" . hash('sha256', $canonicalRequest);

        $kDate = hash_hmac('sha256', $date, 'AWS4' . $secret, true);
        $kRegion = hash_hmac('sha256', 'auto', $kDate, true);
        $kService = hash_hmac('sha256', $service, $kRegion, true);
        $kSigning = hash_hmac('sha256', 'aws4_request', $kService, true);
        $signature = hash_hmac('sha256', $stringToSign, $kSigning);

        $response = wp_remote_request($endpoint . '?location', [
            'method'  => $method,
            'headers' => [
                'Authorization'        => 'AWS4-HMAC-SHA256 Credential=' . $accessKey . '/' . $credentialScope . ', SignedHeaders=' . $signedHeaders . ', Signature=' . $signature,
                'x-amz-date'           => $timestamp,
                'x-amz-content-sha256' => $payloadHash,
            ],
        ]);

        if (is_wp_error($response) || (int) wp_remote_retrieve_response_code($response) !== 200) {
            return 'auto';
        }

        $xml = @simplexml_load_string(wp_remote_retrieve_body($response));
        if (!$xml) {
            return 'auto';
        }

        $location = (string) $xml;

        return $location ?: 'auto';
    }

    protected static function headBucket(string $endpoint, string $secret, string $accessKey, string $region, string $bucket)
    {
        $method = 'HEAD';
        $service = 's3';
        $host = (string) parse_url($endpoint, PHP_URL_HOST);
        $timestamp = gmdate('Ymd\THis\Z');
        $date = gmdate('Ymd');
        $payloadHash = hash('sha256', '');
        $canonicalHeaders = 'host:' . $host . "\n"
            . 'x-amz-content-sha256:' . $payloadHash . "\n"
            . 'x-amz-date:' . $timestamp . "\n";
        $signedHeaders = 'host;x-amz-content-sha256;x-amz-date';

        $canonicalRequest = $method . "\n/" . $bucket . "\n\n"
            . $canonicalHeaders . "\n"
            . $signedHeaders . "\n"
            . $payloadHash;

        $credentialScope = $date . '/' . $region . '/' . $service . '/aws4_request';
        $stringToSign = 'AWS4-HMAC-SHA256' . "\n" . $timestamp . "\n" . $credentialScope . "\n" . hash('sha256', $canonicalRequest);

        $kDate = hash_hmac('sha256', $date, 'AWS4' . $secret, true);
        $kRegion = hash_hmac('sha256', $region, $kDate, true);
        $kService = hash_hmac('sha256', $service, $kRegion, true);
        $kSigning = hash_hmac('sha256', 'aws4_request', $kService, true);
        $signature = hash_hmac('sha256', $stringToSign, $kSigning);

        $response = wp_remote_request($endpoint, [
            'method'  => $method,
            'headers' => [
                'Authorization'        => 'AWS4-HMAC-SHA256 Credential=' . $accessKey . '/' . $credentialScope . ', SignedHeaders=' . $signedHeaders . ', Signature=' . $signature,
                'x-amz-date'           => $timestamp,
                'x-amz-content-sha256' => $payloadHash,
            ],
        ]);

        if (is_wp_error($response)) {
            return $response;
        }

        $code = (int) wp_remote_retrieve_response_code($response);
        if ($code === 200) {
            return ['status' => 'success', 'region' => $region];
        }

        if ($code === 404) {
            return new \WP_Error('r2_bucket_not_found', __('Bucket not found.', 'fluent-cart-pro'));
        }

        if ($code === 403) {
            return new \WP_Error('r2_bucket_access_denied', __('Access denied to bucket. Check permissions.', 'fluent-cart-pro'));
        }

        return new \WP_Error('r2_bucket_verification_failed', sprintf(__('Could not verify bucket. API code: %s', 'fluent-cart-pro'), $code));
    }
}
