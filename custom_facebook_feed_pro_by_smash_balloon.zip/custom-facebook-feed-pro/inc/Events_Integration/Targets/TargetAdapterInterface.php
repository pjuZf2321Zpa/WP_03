<?php
/**
 * Contract for calendar target adapters.
 *
 * An adapter is a thin mapping layer between the NormalizedEvent shape and
 * one calendar plugin's public write API. Adapters must not require any
 * code changes inside the target plugin.
 *
 * @package CustomFacebookFeed\Events_Integration
 * @since 4.11
 */

namespace CustomFacebookFeed\Events_Integration\Targets;

use CustomFacebookFeed\Events_Integration\NormalizedEvent;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

interface TargetAdapterInterface {

	/**
	 * Target ID (matches the Config::TARGET_* constants).
	 *
	 * @return string
	 */
	public function id();

	/**
	 * Human-readable target name for the settings UI.
	 *
	 * @return string
	 */
	public function label();

	/**
	 * Whether the target plugin is active and its public API is present.
	 *
	 * @return bool
	 */
	public function is_available();

	/**
	 * Post type of the calendar events created by this adapter.
	 *
	 * @return string
	 */
	public function post_type();

	/**
	 * Create a calendar event from a normalized Facebook event.
	 *
	 * @param NormalizedEvent $event Normalized event.
	 * @return int|\WP_Error Created WordPress post ID.
	 */
	public function create( NormalizedEvent $event );

	/**
	 * Update an existing calendar event in place.
	 *
	 * @param int             $post_id Calendar event post ID.
	 * @param NormalizedEvent $event   Normalized event.
	 * @return true|\WP_Error
	 */
	public function update( $post_id, NormalizedEvent $event );

	/**
	 * Delete a calendar event created by this adapter.
	 *
	 * @param int $post_id Calendar event post ID.
	 * @return bool
	 */
	public function delete( $post_id );
}
