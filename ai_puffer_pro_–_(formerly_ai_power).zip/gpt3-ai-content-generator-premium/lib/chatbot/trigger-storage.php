<?php

namespace WPAICG\Lib\Chat\Triggers;

use WPAICG\Chat\Admin\AdminSetup;
use WP_Error;

if (!defined('ABSPATH')) {
    exit;
}

/** Stores chatbot trigger JSON and repairs the supported legacy body template format. */
class AIPKit_Trigger_Storage {
    const META_KEY = '_aipkit_chatbot_triggers';

    /**
     * Retrieves the array of trigger objects for a given bot ID.
     *
     * @param int $bot_id The ID of the chatbot CPT.
     * @return array An array of trigger objects, or an empty array if none found or on error.
     */
    public function get_triggers(int $bot_id): array {
        if (!$this->is_chatbot($bot_id)) {
            return [];
        }

        $triggers_json = get_post_meta($bot_id, self::META_KEY, true);
        if (empty($triggers_json) || !is_string($triggers_json)) {
            return [];
        }

        $triggers_array = json_decode($triggers_json, true);
        $json_error = json_last_error();
        if ($json_error !== JSON_ERROR_NONE || !is_array($triggers_array)) {

            // Attempt a targeted repair for unescaped quotes in body_template (common legacy issue).
            $repaired = preg_replace_callback(
                '/("body_template"\\s*:\\s*")(.+?)(")\\s*,\\s*"timeout_seconds"/s',
                static function (array $matches): string {
                    $value = $matches[2];
                    $value = str_replace('\\', '\\\\', $value);
                    $value = str_replace('"', '\\"', $value);
                    return $matches[1] . $value . $matches[3] . ', "timeout_seconds"';
                },
                $triggers_json,
                -1,
                $repair_count
            );

            if (!empty($repair_count)) {
                $triggers_array = json_decode($repaired, true);
                if (json_last_error() === JSON_ERROR_NONE && is_array($triggers_array)) {
                    // Persist repaired JSON so runtime and UI stay in sync.
                    update_post_meta(
                        $bot_id,
                        self::META_KEY,
                        wp_json_encode($triggers_array, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)
                    );
                }
            }
        }

        if (json_last_error() !== JSON_ERROR_NONE || !is_array($triggers_array)) {
            return [];
        }

        return $triggers_array;
    }

    /**
     * Saves an array of trigger objects for a given bot ID.
     * Overwrites any existing triggers for that bot.
     *
     * @param int $bot_id The ID of the chatbot CPT.
     * @param array $triggers_array An array of trigger objects to save.
     * @return bool True on success, false on failure.
     */
    public function save_triggers(int $bot_id, array $triggers_array): bool {
        if (!$this->is_chatbot($bot_id)) {
            return false;
        }

        $triggers_json = wp_json_encode($triggers_array, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
        if (json_last_error() !== JSON_ERROR_NONE) {
            return false;
        }

        return update_post_meta($bot_id, self::META_KEY, $triggers_json);
    }

    /**
     * Adds a new trigger object to a bot's trigger configuration.
     *
     * @param int $bot_id The ID of the chatbot CPT.
     * @param array $trigger_object The trigger object to add. Must include a unique 'id'.
     * @return bool|WP_Error True on success, WP_Error on failure or if ID conflicts.
     */
    public function add_trigger(int $bot_id, array $trigger_object) {
        if (!isset($trigger_object['id']) || empty(trim($trigger_object['id']))) {
            return new WP_Error('missing_trigger_id', __('Trigger object must have a unique "id".', 'gpt3-ai-content-generator'));
        }

        $triggers = $this->get_triggers($bot_id);

        // Check for ID conflict
        foreach ($triggers as $existing_trigger) {
            if (isset($existing_trigger['id']) && $existing_trigger['id'] === $trigger_object['id']) {
                /* translators: %s is the trigger ID */
                return new WP_Error('duplicate_trigger_id', sprintf(__('A trigger with ID "%s" already exists for this bot.', 'gpt3-ai-content-generator'), esc_html($trigger_object['id'])));
            }
        }

        $triggers[] = $trigger_object;
        return $this->save_triggers($bot_id, $triggers);
    }

    /**
     * Updates an existing trigger object for a bot.
     *
     * @param int $bot_id The ID of the chatbot CPT.
     * @param string $trigger_id The ID of the trigger to update.
     * @param array $updated_trigger_object The new trigger object data.
     * @return bool|WP_Error True on success, WP_Error on failure or if trigger not found.
     */
    public function update_trigger(int $bot_id, string $trigger_id, array $updated_trigger_object) {
        if (empty($trigger_id)) {
            return new WP_Error('missing_trigger_id_for_update', __('Trigger ID is required for update.', 'gpt3-ai-content-generator'));
        }
        // Ensure the ID in the object matches the trigger_id being updated
        $updated_trigger_object['id'] = $trigger_id;

        $triggers = $this->get_triggers($bot_id);
        $found_index = -1;

        foreach ($triggers as $index => $existing_trigger) {
            if (isset($existing_trigger['id']) && $existing_trigger['id'] === $trigger_id) {
                $found_index = $index;
                break;
            }
        }

        if ($found_index === -1) {
            /* translators: %s is the trigger ID */
            return new WP_Error('trigger_not_found_for_update', sprintf(__('Trigger with ID "%s" not found for this bot.', 'gpt3-ai-content-generator'), esc_html($trigger_id)));
        }

        $triggers[$found_index] = $updated_trigger_object;
        return $this->save_triggers($bot_id, $triggers);
    }

    /**
     * Deletes a trigger object from a bot's configuration by its ID.
     *
     * @param int $bot_id The ID of the chatbot CPT.
     * @param string $trigger_id The ID of the trigger to delete.
     * @return bool True if deletion was successful or if the trigger didn't exist. False on save error.
     */
    public function delete_trigger(int $bot_id, string $trigger_id): bool {
        if (empty($trigger_id)) {
            return true; // Already absent.
        }

        $triggers = $this->get_triggers($bot_id);
        $original_count = count($triggers);

        $updated_triggers = array_filter($triggers, function ($trigger) use ($trigger_id) {
            return !(isset($trigger['id']) && $trigger['id'] === $trigger_id);
        });

        // Only save if something actually changed (trigger was found and removed)
        if (count($updated_triggers) < $original_count) {
            return $this->save_triggers($bot_id, array_values($updated_triggers)); // Re-index array
        }
        return true; // Trigger not found, so it's effectively "deleted"
    }

    private function is_chatbot(int $bot_id): bool {
        if (!class_exists(AdminSetup::class)) {
            $admin_setup_path = WPAICG_PLUGIN_DIR . 'classes/chatbot/admin.php';
            if (file_exists($admin_setup_path)) {
                require_once $admin_setup_path;
            } else {
                return false;
            }
        }

        return get_post_type($bot_id) === AdminSetup::POST_TYPE;
    }
}
