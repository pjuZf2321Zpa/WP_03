<?php

namespace BitApps\IntegrationsPro\Triggers\DiviFormBuilder;

use BitApps\IntegrationsPro\Config;

final class DiviFormBuilderController
{
    public static function info()
    {
        return [
            'name'              => 'Divi Form by Divi Engine',
            'title'             => __('Divi Form Builder by Divi Engine', 'bit-integrations-pro'),
            'type'              => 'custom_form_submission',
            'is_active'         => DiviFormBuilderHelper::isPluginInstalled(),
            'documentation_url' => 'https://bit-integrations.com/wp-docs/trigger/divi-form-builder-by-divi-engine-integrations/',
            'tutorial_url'      => 'https://www.youtube.com/playlist?list=PL7c6CDwwm-AJIFMSKcIExniukLBJ_tFtG',
            'tasks'             => [
                'action' => 'diviformbuilder/get',
                'method' => 'get',
            ],
            'fetch' => [
                'action' => 'trigger/test',
                'method' => 'post',
            ],
            'fetch_remove' => [
                'action' => 'trigger/test/remove',
                'method' => 'post',
            ],
            'isPro' => true
        ];
    }

    public function getAllTasks()
    {
        if (!DiviFormBuilderHelper::isPluginInstalled()) {
            wp_send_json_error(\sprintf(__('%s is not installed or activated', 'bit-integrations-pro'), 'Divi Form by Divi Engine'));
        }

        wp_send_json_success([
            ['form_name' => __('Form Submission', 'bit-integrations-pro'), 'triggered_entity_id' => 'df_after_process', 'skipPrimaryKey' => false],
        ]);
    }

    public static function handleDiviFormBuilderSubmit($formId, $postArray, $formType)
    {
        $helperClass = bit_integrations_get_class('Core\\Util\\Helper');
        $flowClass = bit_integrations_get_class('Flow\\Flow');

        if (\is_null($formId) || empty($postArray) || \is_null($formType)) {
            return;
        }

        if ($formType === 'contact') {
            $formData = DiviFormBuilderHelper::setFields($formId, $postArray);
        } else {
            $postArray['form_id'] = $formId;
            $formData = $helperClass::prepareFetchFormatFields($postArray);
        }

        if (get_option(Config::withFreePrefix('df_after_process_test')) !== false) {
            update_option(Config::withFreePrefix('df_after_process_test'), [
                'formData'   => $formData,
                'primaryKey' => !empty($formId) ? [(object) ['key' => 'id', 'value' => $formId]] : ''
            ]);
        }

        if ($flows = $flowClass::exists('DiviFormBuilder', 'df_after_process')) {
            $formIdField = ['id' => $formId];

            foreach ($flows as $flow) {
                $flowDetails = static::parseFlowDetails($flow->flow_details);

                if (!isset($flowDetails->primaryKey)) {
                    continue;
                }

                if ($formType === 'contact') {
                    $data = DiviFormBuilderHelper::prepareDataForFlow($postArray, $formIdField);
                } else {
                    $data = array_column($formData, 'value', 'name');
                }

                if (DiviFormBuilderHelper::isPrimaryKeysMatch($postArray, $flowDetails, $formIdField)) {
                    $flowClass::execute('DiviFormBuilder', 'df_after_process', $data, [$flow]);
                }
            }
        }

        return ['type' => 'success'];
    }

    private static function parseFlowDetails($flowDetails)
    {
        return \is_string($flowDetails) ? json_decode($flowDetails) : $flowDetails;
    }
}
