<?php

namespace FluentBookingPro\App\Http\Controllers;

use FluentBooking\App\Http\Controllers\Controller;
use FluentBooking\App\Models\Booking;
use FluentBooking\Framework\Http\Request\Request;
use FluentBookingPro\App\Services\BookingNoteService;

defined('ABSPATH') || exit;

class BookingNoteController extends Controller
{
    public function getNotes(Request $request, $bookingId)
    {
        $booking = Booking::findOrFail($bookingId);

        return [
            'notes' => BookingNoteService::listForAdmin($booking),
            'crm'   => BookingNoteService::crmTarget($booking),
        ];
    }

    public function addNote(Request $request, $bookingId)
    {
        $booking = Booking::findOrFail($bookingId);

        $this->validate($request->all(), [
            'note'  => 'required',
            'title' => 'nullable',
        ]);

        $note = BookingNoteService::add($booking, $request->get('note'), $request->get('title', ''));

        if (is_wp_error($note)) {
            return $this->sendError(['message' => $note->get_error_message()]);
        }

        // The booking note is saved either way; a failed CRM copy is reported, not fatal.
        $crmWarning = '';

        if ($request->get('add_to_crm') === 'yes') {
            $copied = BookingNoteService::copyToCrm($booking, $note);

            if (is_wp_error($copied)) {
                $crmWarning = $copied->get_error_message();
            }
        }

        return [
            'message'     => $crmWarning ? esc_html__('Note added, but not to the CRM profile.', 'fluent-booking-pro') : esc_html__('Note added', 'fluent-booking-pro'),
            'crm_warning' => $crmWarning,
            'note'        => BookingNoteService::present($note),
        ];
    }

    public function updateNote(Request $request, $bookingId, $noteId)
    {
        $booking = Booking::findOrFail($bookingId);

        $this->validate($request->all(), [
            'note'  => 'required',
            'title' => 'nullable',
        ]);

        $activity = BookingNoteService::find($booking, $noteId);

        if (is_wp_error($activity)) {
            return $this->sendError(['message' => $activity->get_error_message()], 404);
        }

        $note = BookingNoteService::update($booking, $activity, $request->get('note'), $request->get('title', ''));

        if (is_wp_error($note)) {
            return $this->sendError(['message' => $note->get_error_message()]);
        }

        return [
            'message' => esc_html__('Note updated', 'fluent-booking-pro'),
            'note'    => BookingNoteService::present($note),
        ];
    }

    public function deleteNote(Request $request, $bookingId, $noteId)
    {
        $booking = Booking::findOrFail($bookingId);

        $activity = BookingNoteService::find($booking, $noteId);

        if (is_wp_error($activity)) {
            return $this->sendError(['message' => $activity->get_error_message()], 404);
        }

        $deleted = BookingNoteService::delete($booking, $activity);

        if (is_wp_error($deleted)) {
            return $this->sendError(['message' => $deleted->get_error_message()], 404);
        }

        return [
            'message' => esc_html__('Note deleted', 'fluent-booking-pro'),
        ];
    }
}
