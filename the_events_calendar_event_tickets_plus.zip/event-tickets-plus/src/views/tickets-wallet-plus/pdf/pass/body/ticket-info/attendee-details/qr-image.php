<?php
/**
 * PDF Pass: Body - Ticket Info - Attendee Details - QR Image
 *
 * Override this template in your own theme by creating a file at:
 * [your-theme]/tribe/tickets-plus/tickets-wallet-plus/pdf/pass/body/ticket-info/attendee-details/qr-image.php
 *
 * See more documentation about our views templating system.
 *
 * @link https://evnt.is/event-tickets-wallet-plus-tpl Help article for Wallet Plus template files.
 *
 * @since 1.0.0
 * @since 6.11.1 Prefer the `$qr_image_src` data URI over `$qr_image_url`.
 *
 * @version 6.11.1
 */

// A data URI lets TCPDF read the QR image without fetching it over HTTP.
$qr_src = empty( $qr_image_src ) ? $qr_image_url ?? '' : $qr_image_src;

if ( empty( $qr_enabled ) || empty( $qr_src ) ) {
	return;
}

?>
<td width="120" rowspan="2">
	<img width="100" src="<?php echo esc_url( $qr_src, [ 'http', 'https', 'data' ] ); ?>" />
</td>
