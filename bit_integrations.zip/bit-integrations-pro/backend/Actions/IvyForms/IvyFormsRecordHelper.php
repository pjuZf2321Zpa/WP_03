<?php

namespace BitApps\IntegrationsPro\Actions\IvyForms;

use IvyForms\Common\Helpers\EntryHelper;
use IvyForms\Factory\Entry\EntryFactory;
use Throwable;

final class IvyFormsRecordHelper
{
    private const FORM_SERVICE = '\IvyForms\Services\Form\FormService';
    private const FIELD_SERVICE = '\IvyForms\Services\Field\FieldService';
    private const ENTRY_SERVICE = '\IvyForms\Services\Entry\EntryService';

    public static function createEntry($response, $fieldData, $formId = 0)
    {
        if (!self::isPluginInstalled()) {
            return self::errorResponse(__('IvyForms is not installed or activated', 'bit-integrations-pro'));
        }

        $formId = (int) $formId;

        if ($formId <= 0) {
            return self::errorResponse(__('A valid IvyForms form is required', 'bit-integrations-pro'));
        }

        if (empty($fieldData)) {
            return self::errorResponse(__('At least one field mapping is required', 'bit-integrations-pro'));
        }

        $services = self::getServices();

        if (empty($services)) {
            return self::errorResponse(__('Unable to access IvyForms services', 'bit-integrations-pro'));
        }

        try {
            $form = $services['form']->getFormById($formId);
            $isStoreEntries = $form->isStoreEntries();

            if (!$isStoreEntries) {
                return self::errorResponse(__('Failed to create IvyForms entry', 'bit-integrations-pro'));
            }

            $formFields = $services['field']->getAllFields($formId) ?? [];
            $fieldData = self::prepareFieldData($fieldData, $formFields);

            $entryData = EntryHelper::buildEntryData($formId);
            $entryObject = EntryFactory::create($entryData);

            $entryId = $services['entry']->getEntryManager()->createEntry($entryObject);

            if (!$entryId) {
                return self::errorResponse(__('Failed to create IvyForms entry', 'bit-integrations-pro'));
            }

            $services['entry']->getEntryFieldManager()->addEntryFields($formFields, $entryId, $fieldData);
        } catch (Throwable $th) {
            return self::errorResponse($th->getMessage() ?: __('Failed to create IvyForms entry', 'bit-integrations-pro'));
        }

        return [
            'success' => true,
            'message' => __('IvyForms entry created successfully', 'bit-integrations-pro'),
            'data'    => [
                'entry_id' => $entryId,
                'form_id'  => $formId,
                'stored'   => $isStoreEntries,
            ],
        ];
    }

    private static function prepareFieldData($fieldData, $formFields)
    {
        $parentIds = self::getFieldParentIds($formFields);
        $preparedData = [];

        foreach ($fieldData as $id => $value) {
            $parentId = $parentIds[$id] ?? 0;

            if ($parentId > 0) {
                $preparedData[$parentId][$id] = $value;
                continue;
            }

            $preparedData[$id] = $value;
        }

        return $preparedData;
    }

    private static function getFieldParentIds($formFields)
    {
        $parentIds = [];

        foreach ($formFields as $field) {
            $fieldId = self::getFieldId($field);

            if ($fieldId <= 0) {
                continue;
            }

            $parentId = self::getFieldParentId($field);

            if ($parentId > 0) {
                $parentIds[$fieldId] = $parentId;
            }
        }

        return $parentIds;
    }

    private static function getFieldId($field)
    {
        if (\is_object($field) && method_exists($field, 'getId')) {
            return (int) $field->getId();
        }

        if (\is_array($field) && isset($field['id'])) {
            return (int) $field['id'];
        }

        if (\is_object($field) && isset($field->id)) {
            return (int) $field->id;
        }

        return 0;
    }

    private static function getFieldParentId($field)
    {
        if (\is_object($field) && method_exists($field, 'getParentId')) {
            return (int) $field->getParentId();
        }

        if (\is_array($field) && isset($field['parentId'])) {
            return (int) $field['parentId'];
        }

        if (\is_object($field) && isset($field->parentId)) {
            return (int) $field->parentId;
        }

        return 0;
    }

    private static function getServices()
    {
        if (!self::isPluginInstalled()) {
            return [];
        }

        $plugin = \IvyForms\Plugin\Plugin::getInstance();

        if (!$plugin || empty($plugin->container)) {
            return [];
        }

        try {
            $services = [
                'form'  => $plugin->container->get(self::FORM_SERVICE),
                'field' => $plugin->container->get(self::FIELD_SERVICE),
                'entry' => $plugin->container->get(self::ENTRY_SERVICE),
            ];

            return (!$services['form'] || !$services['field'] || !$services['entry']) ? [] : $services;
        } catch (Throwable $th) {
            return [];
        }
    }

    private static function isPluginInstalled()
    {
        return class_exists('\IvyForms\Plugin\Plugin');
    }

    private static function errorResponse($message)
    {
        return ['success' => false, 'message' => $message];
    }
}
