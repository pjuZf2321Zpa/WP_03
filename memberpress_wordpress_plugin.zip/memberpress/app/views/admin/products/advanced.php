<?php if (!defined('ABSPATH')) {
    die('You are not allowed to call this page directly.');
} ?>

<?php
// Generic sellable noun for option labels.
$type_noun = MeprProduct::singular_label();
?>
<div class="product-options-panel">
  <div id="mepr-product-access-url">
    <?php // Translators: %s: product noun. ?>
    <label for="<?php echo esc_attr(MeprProduct::$access_url_str); ?>"><?php echo esc_html(sprintf(__('%s Access URL', 'memberpress'), $type_noun)); ?></label>
    <?php MeprAppHelper::info_tooltip(
        'mepr-product-access-url',
        // Translators: %s: product noun.
        sprintf(__('%s Access URL', 'memberpress'), $type_noun),
        // Translators: %s: product noun.
        sprintf(__('This is the URL where those who purchase this %s can get the content they now have access to.', 'memberpress'), $type_noun) . '<br/><br/>' .
        // Translators: 1: product noun (2 uses).
        sprintf(__('When set, the %1$s Access URL will make this %1$s name clickable when a member views their Subscriptions/Payments tabs on the Account page.', 'memberpress'), $type_noun)
    );
                ?>
    &nbsp;&nbsp;
    <input type="text" name="<?php echo esc_attr(MeprProduct::$access_url_str); ?>" id="<?php echo esc_attr(MeprProduct::$access_url_str); ?>" value="<?php echo esc_attr(stripslashes($product->access_url)); ?>" size="50" />
  </div>

  <div id="mepr-register-price" class="mepr-product-adv-item">
    <label for="<?php echo esc_attr(MeprProduct::$register_price_action_str); ?>">
      <?php // Translators: %s: product noun. ?>
      <span><?php echo esc_html(sprintf(__('%s Pricing Terms:', 'memberpress'), $type_noun)); ?></span>
      <select name="<?php echo esc_attr(MeprProduct::$register_price_action_str); ?>" id="<?php echo esc_attr(MeprProduct::$register_price_action_str); ?>">
        <option value="default"<?php selected($product->register_price_action, 'default'); ?>><?php esc_html_e('Default', 'memberpress'); ?></option>
        <option value="custom"<?php selected($product->register_price_action, 'custom'); ?>><?php esc_html_e('Custom', 'memberpress'); ?></option>
        <option value="hidden"<?php selected($product->register_price_action, 'hidden'); ?>><?php esc_html_e('Hidden', 'memberpress'); ?></option>
      </select>
      <?php
        $type_noun_lc = strtolower($type_noun);
        MeprAppHelper::info_tooltip(
            'mepr-register-price',
            // Translators: %s: product noun.
            sprintf(__('%s Pricing Terms', 'memberpress'), $type_noun),
            // Translators: %s: product noun (lowercase).
            sprintf(__('By default MemberPress will automatically generate the pricing terms for you on the %s registration page. But in some cases you\'ll want to either present custom text for the terms ... or hide it alltogether.', 'memberpress'), $type_noun_lc) . '<br/><br/>' .
                                     // Translators: %s: product noun (lowercase).
                                     sprintf(__('This will allow you to customize the pricing terms on the <b>Registration, Payment, and Account Subscription\'s pages</b> for this %s. Here\'s a description of these options:', 'memberpress'), $type_noun_lc) . '<br/><br/>' .
                                     // Translators: %s: product noun (lowercase).
                                     sprintf(__('<b>Default:</b> This will enable the system-generated %s terms.', 'memberpress'), $type_noun_lc) . '<br/><br/>' .
                                     // Translators: %s: product noun (lowercase).
                                     sprintf(__('<b>Custom:</b> This will enable you to enter your own description for your %s terms.', 'memberpress'), $type_noun_lc) . '<br/><br/>' .
            // Translators: %s: product noun (lowercase).
            sprintf(__('<b>Hidden:</b> This will hide the %s terms.', 'memberpress'), $type_noun_lc)
        );
        ?>
    </label>

    <div class="product-options-panel mepr-hidden">
      <span><?php esc_html_e('Custom Registration Pricing Terms:', 'memberpress'); ?></span>
      <input type="text" name="<?php echo esc_attr(MeprProduct::$register_price_str); ?>" id="<?php echo esc_attr(MeprProduct::$register_price_str); ?>" value="<?php echo esc_attr(stripslashes($product->register_price)); ?>" size="50" />
    </div>
  </div>

  <div id="mepr-custom-login-redirect-urls">
    <input type="checkbox" name="<?php echo esc_attr(MeprProduct::$custom_login_urls_enabled_str); ?>" id="<?php echo esc_attr(MeprProduct::$custom_login_urls_enabled_str); ?>" <?php checked($product->custom_login_urls_enabled); ?> />
    <label for="<?php echo esc_attr(MeprProduct::$custom_login_urls_enabled_str); ?>"><?php esc_html_e('Custom Login Redirect URLs', 'memberpress'); ?></label>
    <?php
        MeprAppHelper::info_tooltip(
            'mepr-customize-login-redirections',
            __('Custom Login Redirect URLs', 'memberpress'),
            __('By default MemberPress will redirect members to the page setup in options. This will allow you to override that default behavior and customize it any way you want.', 'memberpress')
        );
        ?>

    <div id="mepr-custom-login-urls-area">
      <label><?php esc_html_e('Default Login Redirect URL', 'memberpress'); ?></label>
      <input type="text" name="<?php echo esc_attr(MeprProduct::$custom_login_urls_default_str); ?>" value="<?php echo esc_attr($product->custom_login_urls_default); ?>" size="50" />
      <?php
        MeprAppHelper::info_tooltip(
            'mepr-custom-login-urls-default',
            __('Default Login Redirect URL', 'memberpress'),
            // Translators: %s: product noun (lowercase).
            sprintf(__('If the member logging in has an active Subscription to this %s and none of the custom URLs below apply, they will be redirected to this URL after logging in.', 'memberpress'), strtolower($type_noun)) . '<br/><br/>' . __('Note: This overrides the Login Redirect URL setting in the MemberPress Options. Leave this option blank to use the Login Redirect URL in the MemberPress Options instead.', 'memberpress')
        );
        ?>
      <div id="custom-login-urls-list-area">
        <label><?php esc_html_e('Add Custom Login Redirect URLs', 'memberpress'); ?>:</label>
        <?php
          MeprAppHelper::info_tooltip(
              'mepr-add-custom-login-urls',
              __('Add Custom Login Redirect URLs', 'memberpress'),
              __('This allows you to redirect a user to different URLs based on how many times they have already logged in. So for example, if you wanted to show upsell pages to members on their 3rd and 6th logins, you can do that by setting the URL to send the member to when they login for the 3rd time and again on the 6th time.', 'memberpress')
          );
            ?>
        <ul id="custom-login-urls-list">
          <?php if (!empty($product->custom_login_urls)) : ?>
                <?php foreach ($product->custom_login_urls as $url) : ?>
              <li>
                <span class="custom_login_urls_item">
                  <label><?php esc_html_e('URL', 'memberpress'); ?></label>
                  <input type="text" name="<?php echo esc_attr(MeprProduct::$custom_login_urls_str); ?>[]" value="<?php echo esc_attr(stripslashes($url->url)); ?>" size="50" />
                  &nbsp;
                  <label><?php esc_html_e('Login #', 'memberpress'); ?></label>
                  <input type="text" name="_mepr_custom_login_urls_count[]" value="<?php echo esc_attr($url->count); ?>" size="5" />

                  <span class="remove-span">
                    <a href="" class="custom_login_urls_remove_url" title="<?php esc_attr_e('Remove URL', 'memberpress'); ?>"><i class="mp-icon mp-icon-cancel-circled mp-16"></i></a>
                  </span>
                </span>
              </li>
                <?php endforeach; ?>
          <?php else : ?>
              <li>
                <span class="custom_login_urls_item">
                  <label><?php esc_html_e('URL', 'memberpress'); ?></label>
                  <input type="text" name="<?php echo esc_attr(MeprProduct::$custom_login_urls_str); ?>[]" value="" size="50" />
                  &nbsp;
                  <label><?php esc_html_e('Login #', 'memberpress'); ?></label>
                  <input type="text" name="_mepr_custom_login_urls_count[]" value="1" size="3" />

                  <span class="remove-span">
                    <a href="" class="custom_login_urls_remove_url" title="<?php esc_attr_e('Remove URL', 'memberpress'); ?>"><i class="mp-icon mp-icon-cancel-circled mp-16"></i></a>
                  </span>
                </span>
              </li>
          <?php endif; ?>
        </ul>

        <span>
          <a href="" class="custom-login-urls-new-url" title="<?php esc_attr_e('Add URL', 'memberpress'); ?>"><i class="mp-icon mp-icon-plus-circled mp-24"></i></a>
        </span>
      </div>
    </div>
  </div>

  <?php MeprHooks::do_action('mepr_product_advanced_metabox', $product); ?>
</div>
