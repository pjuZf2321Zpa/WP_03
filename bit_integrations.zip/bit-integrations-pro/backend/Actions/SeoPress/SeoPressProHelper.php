<?php

namespace BitApps\IntegrationsPro\Actions\SeoPress;

use Exception;

class SeoPressProHelper
{
    private static $metaKeyMap;

    public static function updatePostMeta($defaultResponse, $postData)
    {
        if (!\defined('SEOPRESS_VERSION')) {
            return self::errorResponse('SEOPress is not installed or activated');
        }

        $postId = !empty($postData['post_id']) ? absint($postData['post_id']) : 0;

        if (!$postId || !get_post($postId)) {
            return self::errorResponse(__('Invalid or missing post ID', 'bit-integrations-pro'));
        }

        try {
            $metaKeyMap = self::getMetaKeyMap();
            $updatedFields = [];

            foreach ($postData as $fieldKey => $fieldValue) {
                if ($fieldKey === 'post_id' || !isset($metaKeyMap[$fieldKey])) {
                    continue;
                }

                $sanitizedValue = self::sanitizeMetaValue($fieldKey, $fieldValue);
                update_post_meta($postId, $metaKeyMap[$fieldKey], $sanitizedValue);
                $updatedFields[$fieldKey] = $sanitizedValue;
            }

            if (empty($updatedFields)) {
                return self::errorResponse(__('No valid SEO fields provided to update', 'bit-integrations-pro'));
            }

            return self::successResponse(
                __('SEO meta updated successfully', 'bit-integrations-pro'),
                [
                    'post_id'        => $postId,
                    'updated_fields' => $updatedFields,
                    'post_meta_data' => self::getPostSeoMeta($postId),
                ]
            );
        } catch (Exception $e) {
            return self::errorResponse($e->getMessage());
        }
    }

    private static function getMetaKeyMap()
    {
        if (self::$metaKeyMap === null) {
            self::$metaKeyMap = [
                'title'             => '_seopress_titles_title',
                'description'       => '_seopress_titles_desc',
                'keywords'          => '_seopress_analysis_target_kw',
                'canonical'         => '_seopress_robots_canonical',
                'robots_index'      => '_seopress_robots_index',
                'robots_follow'     => '_seopress_robots_follow',
                'robots_archive'    => '_seopress_robots_archive',
                'robots_snippet'    => '_seopress_robots_snippet',
                'robots_imageindex' => '_seopress_robots_imageindex',
                'target_kw'         => '_seopress_analysis_target_kw',
                'primary_cat'       => '_seopress_robots_primary_cat',
                'og_title'          => '_seopress_social_fb_title',
                'og_description'    => '_seopress_social_fb_desc',
                'og_img'            => '_seopress_social_fb_img',
                'twitter_title'     => '_seopress_social_twitter_title',
                'twitter_desc'      => '_seopress_social_twitter_desc',
                'twitter_img'       => '_seopress_social_twitter_img',
            ];
        }

        return self::$metaKeyMap;
    }

    private static function sanitizeMetaValue($fieldKey, $value)
    {
        if (\in_array($fieldKey, ['canonical', 'og_img', 'twitter_img'], true)) {
            return esc_url_raw($value);
        }

        if (\in_array($fieldKey, ['description', 'og_description', 'twitter_desc'], true)) {
            return sanitize_textarea_field($value);
        }

        return sanitize_text_field($value);
    }

    private static function getPostSeoMeta($postId)
    {
        $post = get_post($postId);

        if (!$post) {
            return [];
        }

        $metaKeyMap = self::getMetaKeyMap();

        // Batch retrieve all meta values at once
        $metaKeys = array_values($metaKeyMap);
        $allMeta = array_fill_keys($metaKeys, '');

        $postMeta = get_post_meta($postId);

        foreach ($postMeta as $key => $values) {
            if (\in_array($key, $metaKeys, true)) {
                $allMeta[$key] = isset($values[0]) ? (string) $values[0] : '';
            }
        }

        // Build response with friendly keys
        $seoMetaData = [
            'post_id'    => $postId,
            'post_title' => $post->post_title,
            'post_type'  => $post->post_type,
        ];

        foreach ($metaKeyMap as $friendlyKey => $metaKey) {
            $seoMetaData[$friendlyKey] = $allMeta[$metaKey];
        }

        return $seoMetaData;
    }

    private static function successResponse($message, $data = [])
    {
        return [
            'success' => true,
            'message' => $message,
            'data'    => $data
        ];
    }

    private static function errorResponse($message)
    {
        return [
            'success' => false,
            'message' => $message
        ];
    }
}
