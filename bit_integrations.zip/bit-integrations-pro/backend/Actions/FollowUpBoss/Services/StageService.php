<?php

namespace BitApps\IntegrationsPro\Actions\FollowUpBoss\Services;

final class StageService extends BaseService
{
    public function createStage(): array
    {
        $validationRules = [
            'name'         => ['required'],
            'order_weight' => ['nullable', 'integer'],
        ];
        $error = $this->validateFields(
            $validationRules,
            [
                'name'         => __('Name', 'bit-integrations-pro'),
                'order_weight' => __('Sort Order', 'bit-integrations-pro'),
            ]
        );

        if ($error !== null) {
            return $error;
        }

        $payload = $this->removeEmptyValues(
            [
                'name'        => $this->getString('name'),
                'orderWeight' => $this->getInteger('order_weight'),
            ]
        );

        return $this->dispatch('POST', '/stages', $payload);
    }

    public function updateStage(): array
    {
        $validationRules = [
            'stage_id'     => ['required', 'integer'],
            'order_weight' => ['nullable', 'integer'],
        ];
        $error = $this->validateFields(
            $validationRules,
            [
                'stage_id'     => __('Stage ID', 'bit-integrations-pro'),
                'order_weight' => __('Sort Order', 'bit-integrations-pro'),
            ]
        );

        if ($error !== null) {
            return $error;
        }

        $payload = $this->removeEmptyValues(
            [
                'name'        => $this->getString('name'),
                'orderWeight' => $this->getInteger('order_weight'),
            ]
        );

        return $this->dispatch('PUT', '/stages/' . rawurlencode($this->getString('stage_id')), $payload);
    }

    public function deleteStage(): array
    {
        $validationRules = [
            'stage_id'        => ['required', 'integer'],
            'assign_stage_id' => ['required', 'integer'],
        ];
        $error = $this->validateFields(
            $validationRules,
            [
                'stage_id'        => __('Stage ID', 'bit-integrations-pro'),
                'assign_stage_id' => __('Stage for Action Plans', 'bit-integrations-pro'),
            ],
            ['assign_stage_id']
        );

        if ($error !== null) {
            return $error;
        }

        $query = $this->removeEmptyValues(
            [
                'assignStageId' => $this->getInteger('assign_stage_id'),
            ]
        );

        return $this->dispatch('DELETE', '/stages/' . rawurlencode($this->getString('stage_id')), null, $query);
    }
}
