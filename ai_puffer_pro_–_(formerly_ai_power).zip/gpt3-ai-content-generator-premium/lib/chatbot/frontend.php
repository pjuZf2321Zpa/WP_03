<?php
/**
 * Paid chatbot rendering controls and frontend asset requirements.
 * Loaded by the Pro bootstrap; every entry point also checks the current plan.
 */
namespace WPAICG\Lib\Chat;

use WPAICG\aipkit_dashboard;
use WPAICG\Chat\Frontend\Assets;
use WPAICG\Lib\Addons\AIPKit_Consent_Compliance;

if (!defined('ABSPATH')) {
    exit;
}

final class ShortcodeFeatures
{
    public static function is_available(): bool
    {
        return class_exists(aipkit_dashboard::class) && aipkit_dashboard::is_pro_plan();
    }

    /**
     * Build the external embed snippet shared by the builder and bot-switch state.
     */
    public static function embed_code(int $bot_id): string
    {
        if (!self::is_available() || $bot_id <= 0) {
            return '';
        }

        if (!function_exists('wpaicg_gacg_fs')) {
            return '';
        }

        if (wpaicg_gacg_fs()->can_use_premium_code__premium_only()) {
            $embed_script_url = WPAICG_PLUGIN_URL . 'dist/js/embed-bootstrap.bundle.js';
            $embed_target_div = 'aipkit-chatbot-container-' . $bot_id;
            $embed_config_url = rest_url('aipkit/v1/chatbots/' . $bot_id . '/embed-config');

            $embed_script = sprintf(
                '(function(){var d=document;var c=d.createElement("div");c.id="%1$s";var s=d.createElement("script");s.src="%2$s";s.setAttribute("data-bot-id","%3$d");s.setAttribute("data-config-url","%4$s");s.async=true;var t=d.currentScript||d.getElementsByTagName("script")[0];t.parentNode.insertBefore(c,t);t.parentNode.insertBefore(s,t);}());',
                esc_js($embed_target_div),
                esc_js($embed_script_url),
                $bot_id,
                esc_js($embed_config_url)
            );

            return '<script type="text/javascript">' . $embed_script . '</script>';
        }

        return '';
    }

    public static function pdf_enabled(array $core_flags, bool $is_pro_plan): bool
    {
        return self::is_available() && $is_pro_plan && ($core_flags['enable_download'] ?? false);
    }

    public static function file_upload_enabled(array $core_flags, bool $is_pro_plan, string $provider): bool
    {
        return self::is_available() && $is_pro_plan && ($core_flags['enable_file_upload_setting'] ?? false) && $provider !== '';
    }

    public static function realtime_enabled(array $core_flags): bool
    {
        return self::is_available() && ($core_flags['enable_realtime_voice_setting'] ?? false);
    }

    public static function requires_consent(array $settings): bool
    {
        if (!self::is_available() || ($settings['enable_consent_compliance'] ?? '0') !== '1') {
            return false;
        }
        if (!class_exists(AIPKit_Consent_Compliance::class)) {
            $path = __DIR__ . '/../security/consent.php';
            if (file_exists($path)) {
                require_once $path;
            }
        }
        return class_exists(AIPKit_Consent_Compliance::class) && AIPKit_Consent_Compliance::is_required();
    }

    public static function direct_voice_enabled(array $settings, array $feature_flags): bool
    {
        return self::is_available() && ($feature_flags['popup_enabled'] ?? false)
            && ($feature_flags['enable_realtime_voice_ui'] ?? false)
            && ($settings['direct_voice_mode'] ?? '0') === '1';
    }

    public static function direct_voice_popup(array $config): array
    {
        if (!self::is_available() || empty($config['directVoiceMode'])) {
            return [];
        }
        return [
            'icon' => '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="icon icon-tabler icons-tabler-outline icon-tabler-volume"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M15 8a5 5 0 0 1 0 8"/><path d="M17.7 5a9 9 0 0 1 0 14"/><path d="M6 15h-2a1 1 0 0 1 -1 -1v-4a1 1 0 0 1 1 -1h2l3.5 -4.5a.8 .8 0 0 1 1.5 .5v14a.8 .8 0 0 1 -1.5 .5l-3.5 -4.5"/></svg>',
            'open_label' => __('Start voice conversation', 'gpt3-ai-content-generator'),
            'close_label' => __('Close voice consent', 'gpt3-ai-content-generator'),
            'icon_type' => 'default',
            'trigger_attributes' => 'aria-pressed="false" data-aipkit-direct-voice="true"',
        ];
    }

    public static function file_upload_trigger(): array
    {
        if (!self::is_available()) {
            return [];
        }
        return [
            'icon' => '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="icon icon-tabler icons-tabler-outline icon-tabler-file-upload"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M14 3v4a1 1 0 0 0 1 1h4" /><path d="M17 21h-10a2 2 0 0 1 -2 -2v-14a2 2 0 0 1 2 -2h7l5 5v11a2 2 0 0 1 -2 2z" /><path d="M12 11v6" /><path d="M9.5 13.5l2.5 -2.5l2.5 2.5" /></svg>',
            'label' => __('Upload File (TXT, PDF)', 'gpt3-ai-content-generator'),
        ];
    }

    public static function render_realtime_button(bool $realtime_voice_enabled_ui): void
    {
        if (!self::is_available()) {
            return;
        }
        $volume_svg = '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="icon icon-tabler icons-tabler-outline icon-tabler-volume"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M15 8a5 5 0 0 1 0 8" /><path d="M17.7 5a9 9 0 0 1 0 14" /><path d="M6 15h-2a1 1 0 0 1 -1 -1v-4a1 1 0 0 1 1 -1h2l3.5 -4.5a.8 .8 0 0 1 1.5 .5v14a.8 .8 0 0 1 -1.5 .5l-3.5 -4.5" /></svg>';
        ?>
                    <button
                        class="aipkit_input_action_btn aipkit_realtime_voice_agent_btn"
                        aria-label="<?php esc_attr_e('Start Voice Conversation', 'gpt3-ai-content-generator'); ?>"
                        title="<?php esc_attr_e('Start Voice Conversation', 'gpt3-ai-content-generator'); ?>"
                        type="button"
                        <?php if (!$realtime_voice_enabled_ui): ?>hidden<?php endif; ?>
                    >
                        <?php echo $volume_svg; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
                    </button>
        <?php
    }

    public static function render_pdf_option(array $frontend_config): void
    {
        if (!self::is_available()) {
            return;
        }
        ?>
                            <button type="button" class="aipkit_download_menu_item" role="menuitem" data-format="pdf"><?php echo esc_html($frontend_config['text']['downloadPdf']); ?></button>
        <?php
    }

    public static function render_upload_menu(string $input_action_menu_id, string $image_upload_svg): void
    {
        if (!self::is_available()) {
            return;
        }
        $file_upload_svg = self::file_upload_trigger()['icon'];
        ?>
            <div class="aipkit_input_action_menu" id="<?php echo esc_attr($input_action_menu_id); ?>" role="menu" aria-hidden="true" hidden>
                    <button type="button" class="aipkit_input_action_menu_item" role="menuitem" data-aipkit-upload-action="image" aria-label="<?php esc_attr_e('Upload image', 'gpt3-ai-content-generator'); ?>">
                        <span class="aipkit_input_action_menu_icon" aria-hidden="true"><?php echo $image_upload_svg; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
                        <span class="aipkit_input_action_menu_label"><?php esc_html_e('Upload image', 'gpt3-ai-content-generator'); ?></span>
                    </button>
                    <button type="button" class="aipkit_input_action_menu_item" role="menuitem" data-aipkit-upload-action="file" aria-label="<?php esc_attr_e('Upload File (TXT, PDF)', 'gpt3-ai-content-generator'); ?>">
                        <span class="aipkit_input_action_menu_icon" aria-hidden="true"><?php echo $file_upload_svg; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
                        <span class="aipkit_input_action_menu_label"><?php esc_html_e('Upload file', 'gpt3-ai-content-generator'); ?></span>
                    </button>
            </div>
        <?php
    }
}

/** Asset flags shared by shortcode rendering and site-wide placement. */
final class AssetRequirements
{
    public static function set_flags(bool $needs_chat_file_upload, bool $needs_realtime_voice): void
    {
        if (!ShortcodeFeatures::is_available()) {
            return;
        }
        if ($needs_chat_file_upload) {
            Assets::$chat_file_upload_needed = true;
        }
        if ($needs_realtime_voice) {
            Assets::$realtime_voice_needed = true;
        }
    }
}
