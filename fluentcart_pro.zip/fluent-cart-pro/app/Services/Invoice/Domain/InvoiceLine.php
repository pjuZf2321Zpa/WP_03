<?php

declare(strict_types=1);

namespace FluentCartPro\App\Services\Invoice\Domain;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Invoice line DTO. Immutable. No calculation inside.
 */
final class InvoiceLine
{
    public string $id;

    public string $name;

    public int $quantity;

    public string $unitCode;

    public Money $netUnitPrice;

    /** BT-149: quantity the net price applies to. */
    public int $priceBaseQuantity;

    public string $taxCategory;

    public string $taxPercent;

    /** BT-121: coded VAT exemption reason for the line's category. Carried for breakdown aggregation. */
    public string $exemptionReasonCode;

    /** BT-120: free-text VAT exemption reason for the line's category. Carried for breakdown aggregation. */
    public string $exemptionReasonText;

    public Money $lineAllowance;

    public Money $lineCharge;

    /** Line total (net) for serialization. */
    public Money $lineTotal;

    /**
     * @param array<string, mixed> $data
     */
    public function __construct(array $data = [])
    {
        $currency           = (string) ($data['currency'] ?? 'EUR');
        $this->id           = (string) ($data['id'] ?? '');
        $this->name         = (string) ($data['name'] ?? '');
        $this->quantity     = (int) ($data['quantity'] ?? 1);
        $this->unitCode     = (string) ($data['unitCode'] ?? 'H87');
        $this->netUnitPrice = ($data['netUnitPrice'] ?? null) instanceof Money ? $data['netUnitPrice'] : new Money($currency, (int) ($data['netUnitPriceCents'] ?? 0));
        $this->priceBaseQuantity = max(1, (int) ($data['priceBaseQuantity'] ?? 1));
        $this->taxCategory  = (string) ($data['taxCategory'] ?? 'Z');
        $this->taxPercent   = (string) ($data['taxPercent'] ?? '0.00');
        $this->exemptionReasonCode = (string) ($data['exemptionReasonCode'] ?? '');
        $this->exemptionReasonText = (string) ($data['exemptionReasonText'] ?? '');
        $this->lineAllowance = ($data['lineAllowance'] ?? null) instanceof Money ? $data['lineAllowance'] : new Money($currency, (int) ($data['lineAllowanceCents'] ?? 0));
        $this->lineCharge   = ($data['lineCharge'] ?? null) instanceof Money ? $data['lineCharge'] : new Money($currency, (int) ($data['lineChargeCents'] ?? 0));
        $this->lineTotal    = ($data['lineTotal'] ?? null) instanceof Money ? $data['lineTotal'] : new Money($currency, (int) ($data['lineTotalCents'] ?? 0));
    }
}
