<?php

use NinjaTablesPro\App\Http\Controllers\PermissionController;
use NinjaTablesPro\App\Http\Controllers\SortableController;
use NinjaTablesPro\App\Http\Controllers\CustomFilterController;
use NinjaTablesPro\App\Http\Controllers\LicenseController;
use NinjaTablesPro\App\Http\Controllers\GoogleSheetSyncController;

defined('ABSPATH') || exit;

/**
 * @var $router NinjaTables\Framework\Http\Router
 */

// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- required inside a method of Application, so this is local
$policy = 'NinjaTablesPro\App\Http\Policies\UserPolicy';

// Apply the policy per child group rather than once around both. The router
// pops the policy stack when a group exits, and its push/inheritance indexing
// only lines up for a top-level withPolicy — so a shared parent policy here is
// drained by the first child's exit and every later sibling registers ungated.
// Carrying the policy on each group makes each re-push its own, independent of
// sibling order.
$router->prefix('pro')->group(function ($route) use ($policy) {
    // Gate the permission endpoint at the route: it writes site-wide capability
    // options, so it must not rely on PermissionController's own manage_options
    // re-check alone. Applied per-route rather than via another group so it
    // does not disturb the router's group-policy stack (which the sibling
    // groups below depend on).
    $route->post('permission', [PermissionController::class, 'store'])->withPolicy($policy);

    $route->group(['prefix' => 'sortable', 'policy' => $policy], function ($route) {
        $route->post('/init', [SortableController::class, 'init']);
        $route->post('/', [SortableController::class, 'store']);
    });

    $route->group(['prefix' => 'custom-filter', 'policy' => $policy], function ($route) {
        $route->get('', [CustomFilterController::class, 'index']);
        $route->post('/', [CustomFilterController::class, 'store']);
    });

    $route->group(['prefix' => 'license', 'policy' => 'NinjaTablesPro\App\Http\Policies\LicensePolicy'], function ($route) {
        $route->get('', [LicenseController::class, 'getStatus']);
        $route->post('/', [LicenseController::class, 'saveLicense']);
        $route->delete('/', [LicenseController::class, 'deactivateLicense']);
        $route->post('/deactivate', [LicenseController::class, 'deactivateLicense']);
    });

    $route->group(['prefix' => 'gsheet-sync', 'policy' => $policy], function ($route) {
        $route->post('/fetch-headers', [GoogleSheetSyncController::class, 'fetchHeaders']);
        $route->post('/create', [GoogleSheetSyncController::class, 'createTable']);
        $route->post('/{id}/update', [GoogleSheetSyncController::class, 'updateSettings'])->int('id');
        $route->post('/{id}/sync-now', [GoogleSheetSyncController::class, 'triggerSync'])->int('id');
        $route->post('/{id}/process-chunk', [GoogleSheetSyncController::class, 'processChunk'])->int('id');
        $route->get('/{id}/sync-status', [GoogleSheetSyncController::class, 'getSyncStatus'])->int('id');
    });
});
