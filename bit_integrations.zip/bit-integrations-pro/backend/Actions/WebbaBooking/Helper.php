<?php

namespace BitApps\IntegrationsPro\Actions\WebbaBooking;

use WBK_Booking;
use WBK_Service;

if (!\defined('ABSPATH')) {
    exit;
}

/**
 * Shared data helpers for the Webba Booking action.
 */
final class Helper
{
    /**
     * Columns exposed on the bookings (wp_wbk_appointments) table.
     *
     * @var string[]
     */
    private const BOOKING_COLUMNS = [
        'id', 'name', 'email', 'phone', 'service_id', 'service_category', 'unit_id',
        'staff_member_id', 'location_id', 'day', 'time', 'end', 'duration', 'quantity',
        'number_of_people', 'status', 'prev_status', 'created_by', 'created_on',
        'payment_method', 'amount_paid', 'paid_with_coupon', 'coupon', 'moment_price',
        'description', 'extra', 'booking_extra', 'attachment', 'token', 'lang', 'user_ip',
    ];

    public static function isPluginActive()
    {
        return class_exists('\WBK_Booking_Factory');
    }

    /**
     * Re-load a booking by id and flatten every column into a payload.
     *
     * @param int $bookingId
     *
     * @return array
     */
    public static function getBookingData($bookingId)
    {
        $booking = self::loadBooking($bookingId);

        if ($booking === null) {
            return [];
        }

        $data = [];

        foreach (self::BOOKING_COLUMNS as $column) {
            $data[$column] = $booking->get($column);
        }

        $data['service_name'] = self::resolveServiceName($data['service_id'] ?? 0);
        $data['time_formatted'] = self::formatTimestamp($data['time'] ?? 0);
        $data['day_formatted'] = self::formatTimestamp($data['day'] ?? 0, false);
        $data['end_formatted'] = self::formatTimestamp($data['end'] ?? 0);
        $data['created_on_formatted'] = self::formatTimestamp($data['created_on'] ?? 0);

        return $data;
    }

    public static function bookingExists($bookingId)
    {
        return self::loadBooking($bookingId) !== null;
    }

    /**
     * Convert a user-supplied date/time (Unix timestamp or human-readable string
     * in the site timezone) into a Unix timestamp. Returns 0 when unparseable.
     *
     * @param int|string $value
     *
     * @return int
     */
    public static function toTimestamp($value)
    {
        if (is_numeric($value)) {
            return (int) $value;
        }

        $dateTime = date_create((string) $value, wp_timezone());

        return $dateTime ? $dateTime->getTimestamp() : 0;
    }

    /**
     * Format a Unix timestamp using the site date/time format and timezone.
     *
     * @param int  $timestamp
     * @param bool $withTime
     *
     * @return string
     */
    public static function formatTimestamp($timestamp, $withTime = true)
    {
        $timestamp = (int) $timestamp;

        if ($timestamp <= 0) {
            return '';
        }

        static $formats = [];
        $key = $withTime ? 'datetime' : 'date';

        if (!isset($formats[$key])) {
            $format = get_option('date_format', 'Y-m-d');

            if ($withTime) {
                $format .= ' ' . get_option('time_format', 'H:i');
            }

            $formats[$key] = $format;
        }

        return wp_date($formats[$key], $timestamp);
    }

    /**
     * Load a WBK_* model by id and save the supplied columns.
     *
     * @param string   $class   fully-qualified WBK class name
     * @param null|int $id      null to create, id to update
     * @param array    $columns column => value pairs
     *
     * @return false|int false on failure, the new/updated id on success
     */
    public static function persistModel($class, $id, array $columns)
    {
        if (!class_exists($class)) {
            return false;
        }

        $model = $id === null ? new $class(null) : new $class((int) $id);

        foreach ($columns as $column => $value) {
            $model->set($column, $value);
        }

        $result = $model->save();

        if ($result === false) {
            return false;
        }

        if ($id === null) {
            return $result > 0 ? (int) $result : false;
        }

        return (int) $id;
    }

    /**
     * Load a booking by id, returning the model only when it exists.
     *
     * @param int $bookingId
     *
     * @return null|WBK_Booking
     */
    private static function loadBooking($bookingId)
    {
        $bookingId = (int) $bookingId;

        if ($bookingId <= 0 || !class_exists('\WBK_Booking')) {
            return null;
        }

        $booking = new WBK_Booking($bookingId);

        return $booking->is_loaded() ? $booking : null;
    }

    private static function resolveServiceName($serviceId)
    {
        $serviceId = (int) $serviceId;

        if ($serviceId <= 0 || !class_exists('\WBK_Service')) {
            return '';
        }

        $service = new WBK_Service($serviceId);

        if (!$service->is_loaded()) {
            return '';
        }

        return $service->get_name();
    }
}
