<?php

namespace Breakdance\Elements;

// These global constants must be defined before any element file loads:
// twig-functions.php bakes the URL into a JS twig callable at load time. __FILE__
// is in the element library directory, so plugin_dir_url resolves to the right place.
if (!defined('BREAKDANCE_ELEMENTS_PLUGIN_URL')) {
    define('BREAKDANCE_ELEMENTS_PLUGIN_URL', plugin_dir_url(__FILE__));
}
if (!defined('__BREAKDANCE_ELEMENTS_DIR__')) {
    define('__BREAKDANCE_ELEMENTS_DIR__', __DIR__);
}

require_once __DIR__ . '/Element.class.php';
require_once __DIR__ . '/elements-helpers.php';
require_once __DIR__ . '/hidden-elements.php';
require_once __DIR__ . '/elements-for-builder.php';
require_once __DIR__ . '/universal-controls/base.php';
require_once __DIR__ . '/element-categories.php';
require_once __DIR__ . '/twig-functions.php';
require_once __DIR__ . '/filtered-gets.php';
require_once __DIR__ . '/twig-macros.php';
require_once __DIR__ . '/twig-i18n.php';
require_once __DIR__ . '/preset-sections.php';
require_once __DIR__ . "/preset-sections/base.php";
require_once __DIR__ . "/assets/base.php";
require_once __DIR__ . "/button/base.php";
require_once __DIR__ . "/tabs/base.php";
require_once __DIR__ . "/menu/base.php";
require_once __DIR__ . "/util.php";
require_once __DIR__ . "/global-actions.php";

// First-party element library.
require_once __DIR__ . "/essential-elements.php";
