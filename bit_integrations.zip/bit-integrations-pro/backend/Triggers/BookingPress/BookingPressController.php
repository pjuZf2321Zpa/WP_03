<?php

namespace BitApps\IntegrationsPro\Triggers\BookingPress;

use BitApps\IntegrationsPro\Config;

final class BookingPressController
{
    public static function info()
    {
        return [
            'name'              => 'BookingPress',
            'type'              => 'custom_form_submission',
            'is_active'         => self::isPluginInstalled(),
            'tutorial_url'      => '#',
            'isPro'             => true,
            'tasks'             => [
                'action' => 'booking_press/get',
                'method' => 'get'
            ],
            'fetch' => [
                'action' => 'trigger/test',
                'method' => 'post'
            ],
            'fetch_remove' => [
                'action' => 'trigger/test/remove',
                'method' => 'post'
            ],
        ];
    }

    public static function getAllTasks()
    {
        if (!self::isPluginInstalled()) {
            wp_send_json_error(
                \sprintf(__('%s is not installed or activated', 'bit-integrations-pro'), 'BookingPress')
            );
        }

        wp_send_json_success(BookingPressHelper::tasks());
    }

    public static function handleAppointmentBooked($appointmentId)
    {
        $data = BookingPressHelper::getAppointmentData($appointmentId);
        if (empty($data)) {
            return;
        }
        self::flowExecute('bookingpress_after_insert_appointment', $data);
    }

    public static function handleAppointmentCancelled($appointmentId)
    {
        $data = BookingPressHelper::getAppointmentData($appointmentId);
        if (empty($data)) {
            return;
        }
        self::flowExecute('bookingpress_after_cancel_appointment', $data);
    }

    public static function handleAppointmentStatusChanged($appointmentId, $newStatus)
    {
        $data = BookingPressHelper::getAppointmentData($appointmentId);
        if (empty($data)) {
            return;
        }
        $data['new_status'] = $newStatus;
        self::flowExecute('bookingpress_after_change_appointment_status', $data);
    }

    public static function handleAppointmentRescheduled($appointmentId)
    {
        $data = BookingPressHelper::getAppointmentData($appointmentId);
        if (empty($data)) {
            return;
        }
        self::flowExecute('bookingpress_after_rescheduled_appointment', $data);
    }

    public static function handleAppointmentUpdated($appointmentId)
    {
        $data = BookingPressHelper::getAppointmentData($appointmentId);
        if (empty($data)) {
            return;
        }
        self::flowExecute('bookingpress_after_update_appointment', $data);
    }

    public static function handleCustomerCreated($customerId)
    {
        $data = BookingPressHelper::getCustomerData($customerId);
        if (empty($data)) {
            return;
        }
        self::flowExecute('bookingpress_customer_created', $data);
    }

    public static function handleCustomerUpdated($customerId)
    {
        $data = BookingPressHelper::getCustomerData($customerId);
        if (empty($data)) {
            return;
        }
        self::flowExecute('bookingpress_after_update_customer', $data);
    }

    private static function isPluginInstalled()
    {
        return class_exists('BookingPress');
    }

    private static function flowExecute($triggeredEntityId, $data)
    {
        if (empty($data) || !\is_array($data)) {
            return;
        }

        $helperClass = bit_integrations_get_class('Core\\Util\\Helper');
        $flowClass = bit_integrations_get_class('Flow\\Flow');

        $formData = $helperClass::prepareFetchFormatFields($data);

        $helperClass::setTestData(Config::withFreePrefix("{$triggeredEntityId}_test"), array_values($formData));

        $flows = $flowClass::exists('BookingPress', $triggeredEntityId);

        if (!$flows) {
            return;
        }

        $flowClass::execute('BookingPress', $triggeredEntityId, array_column($formData, 'value', 'name'), $flows);

        return ['type' => 'success'];
    }
}
