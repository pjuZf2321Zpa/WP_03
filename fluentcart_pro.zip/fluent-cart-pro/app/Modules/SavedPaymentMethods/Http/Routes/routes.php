<?php

use FluentCart\Framework\Http\Router;
use FluentCartPro\App\Modules\SavedPaymentMethods\Http\Controllers\CustomerPaymentMethodController;

/** @var Router $router */

$router->prefix('saved-payment-methods')
    ->withPolicy('\FluentCart\App\Http\Policies\CustomerFrontendPolicy')
    ->group(function (Router $router) {
        $router->get('/', [CustomerPaymentMethodController::class, 'index']);
        $router->post('/', [CustomerPaymentMethodController::class, 'store']);
        $router->get('setup-intent-attempts', [CustomerPaymentMethodController::class, 'remainingAttempts']);
        $router->post('{id}/default', [CustomerPaymentMethodController::class, 'setDefault']);
        $router->delete('{id}', [CustomerPaymentMethodController::class, 'destroy']);
    });
