<?php

namespace FluentBookingPro\App\Services\Integrations;

use FluentBooking\App\Models\Meta;

/**
 * Loads per-host meta for many hosts in one query instead of one query per host.
 */
class HostMetaHelper
{
    /**
     * @param string $objectType
     * @param array $hostIds
     * @param string|null $key
     * @return array [hostId => Meta[]] each list ordered by id
     */
    public static function getMetasByHost($objectType, $hostIds, $key = null)
    {
        $hostIds = array_filter(array_map('intval', (array) $hostIds));

        if (!$hostIds) {
            return [];
        }

        $query = Meta::where('object_type', $objectType)
            ->whereIn('object_id', array_values(array_unique($hostIds)))
            ->orderBy('id', 'ASC');

        if ($key) {
            $query->where('key', $key);
        }

        $metasByHost = [];
        foreach ($query->get() as $meta) {
            $metasByHost[(int) $meta->object_id][] = $meta;
        }

        return $metasByHost;
    }

    /**
     * @param string $objectType
     * @param array $hostIds
     * @param string|null $key
     * @return array [hostId => Meta] the oldest row per host, like a per-host ->first()
     */
    public static function getFirstMetaByHost($objectType, $hostIds, $key = null)
    {
        return array_map(function ($metas) {
            return $metas[0];
        }, self::getMetasByHost($objectType, $hostIds, $key));
    }

    /**
     * Batched RemoteCalendarHelper::getUserRemoteCreatableCalendarSettings().
     *
     * @param array $hostIds
     * @return array [hostId => array]
     */
    public static function getRemoteCreatableCalendarSettings($hostIds)
    {
        return array_map(function ($meta) {
            return is_array($meta->value) ? $meta->value : [];
        }, self::getFirstMetaByHost('_calendar_user_meta', $hostIds, 'create_remote_calendar'));
    }
}
