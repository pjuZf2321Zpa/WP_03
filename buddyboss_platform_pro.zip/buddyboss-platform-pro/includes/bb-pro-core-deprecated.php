<?php
/**
 * Deprecated BuddyBoss Platform Pro functions and hooks.
 *
 * Polls, Reactions (the emotion layer) and Social Login / SSO were removed from
 * Platform Pro in 3.2.0 (PROD-10191) and now live in the standalone BuddyBoss
 * Addons plugin. This file keeps the removed PUBLIC surface reachable for code
 * that was written against Pro and has not been updated — third-party plugins,
 * the BuddyBoss App, and site-specific customisations.
 *
 * Two rules govern everything here, and both matter:
 *
 * 1. NEVER stub the add-on's dormancy markers. The Addons plugin decides whether
 *    to load each module by testing for the function Pro's loader used to define
 *    — `bb_register_poll()`, `bp_register_reaction()`, `bb_register_sso()`.
 *    Defining any of those here would make the add-on believe Pro still ships
 *    the feature and stand down permanently, disabling it site-wide.
 *
 * 2. Register LATE and only when nothing else provided the function. The add-on
 *    defines the real implementations UNGUARDED at `bp_setup_components`
 *    (bp_loaded:2, polls + SSO) and `bb_after_register_features` (bp_loaded:5,
 *    reactions). Pro's own `includes()` runs far earlier, on `plugins_loaded`,
 *    so declaring the fallbacks at file-load time would win the race and fatal
 *    with "cannot redeclare" the moment the add-on loaded. Everything below is
 *    therefore deferred to `bp_init` (WP `init`, strictly after every add-on
 *    load point) and guarded with `function_exists()`.
 *
 * @package BuddyBossPro/Deprecated
 *
 * @since 3.2.0
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

/**
 * Install no-op fallbacks for the public functions that moved to BuddyBoss Addons.
 *
 * Each fallback returns the removed function's documented "nothing happened"
 * value, so an un-updated caller degrades instead of fatalling. Runs on `bp_init`
 * — see rule 2 in the file docblock for why the timing is not negotiable.
 *
 * @since 3.2.0
 */
function bb_pro_install_moved_feature_fallbacks() {

	// -------------------------------------------------------------------------
	// Polls — moved to buddyboss-addons/addons/polls/.
	// -------------------------------------------------------------------------

	if ( ! function_exists( 'bb_platform_poll_version' ) ) {
		/**
		 * Minimum Platform version the Polls feature required.
		 *
		 * @since      2.6.00
		 * @deprecated 3.2.0 Polls moved to the BuddyBoss Addons plugin, which
		 *                   exposes `bb_addons_polls_min_platform_version()`.
		 *
		 * @return string Minimum supported BuddyBoss Platform version.
		 */
		function bb_platform_poll_version() {
			_deprecated_function( __FUNCTION__, '3.2.0', 'bb_addons_polls_min_platform_version()' );

			return '2.6.90';
		}
	}

	if ( ! function_exists( 'bb_load_polls' ) ) {
		/**
		 * Accessor for the Polls controller.
		 *
		 * @since      2.6.00
		 * @deprecated 3.2.0 Polls moved to the BuddyBoss Addons plugin.
		 *
		 * @return null Always null — the feature is unavailable without the add-on.
		 */
		function bb_load_polls() {
			_deprecated_function( __FUNCTION__, '3.2.0', 'the BuddyBoss Addons plugin' );

			return null;
		}
	}

	if ( ! function_exists( 'bb_is_enabled_activity_post_polls' ) ) {
		/**
		 * Whether polls may be posted to the activity feed.
		 *
		 * @since      2.6.00
		 * @deprecated 3.2.0 Polls moved to the BuddyBoss Addons plugin.
		 *
		 * @param bool $default Optional. Unused. Default false.
		 * @return bool Always false — the feature is unavailable without the add-on.
		 */
		function bb_is_enabled_activity_post_polls( $default = false ) { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter.Found
			_deprecated_function( __FUNCTION__, '3.2.0', 'the BuddyBoss Addons plugin' );

			return false;
		}
	}

	// -------------------------------------------------------------------------
	// Reactions (emotion layer) — moved to buddyboss-addons/addons/reactions/.
	// NOTE: the Platform still owns the reaction DATA MODEL (`BB_Reaction`,
	// singular). Only the Pro emotion layer moved, so nothing here shadows it.
	// -------------------------------------------------------------------------

	if ( ! function_exists( 'bb_pro_get_reactions' ) ) {
		/**
		 * Fetch the configured reactions.
		 *
		 * @since      2.4.50
		 * @deprecated 3.2.0 The emotion layer moved to the BuddyBoss Addons plugin.
		 *
		 * @param string $type       Optional. Reaction type. Unused.
		 * @param bool   $only_first Optional. Unused.
		 * @return array Always empty — the feature is unavailable without the add-on.
		 */
		function bb_pro_get_reactions( $type = 'emotions', $only_first = false ) { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter.Found
			_deprecated_function( __FUNCTION__, '3.2.0', 'the BuddyBoss Addons plugin' );

			return array();
		}
	}

	if ( ! function_exists( 'bb_pro_reaction_migration' ) ) {
		/**
		 * Seed the default emotion set.
		 *
		 * @since      2.4.50
		 * @deprecated 3.2.0 The emotion layer moved to the BuddyBoss Addons plugin.
		 *
		 * @return void
		 */
		function bb_pro_reaction_migration() {
			_deprecated_function( __FUNCTION__, '3.2.0', 'the BuddyBoss Addons plugin' );
		}
	}

	if ( ! function_exists( 'bb_pro_reaction_get_migration_status' ) ) {
		/**
		 * Current likes/emotions migration status.
		 *
		 * @since      2.4.50
		 * @deprecated 3.2.0 The emotion layer moved to the BuddyBoss Addons plugin.
		 *
		 * @return string Always '' — no migration can be in flight without the add-on.
		 */
		function bb_pro_reaction_get_migration_status() {
			_deprecated_function( __FUNCTION__, '3.2.0', 'the BuddyBoss Addons plugin' );

			return '';
		}
	}

	// -------------------------------------------------------------------------
	// Social Login / SSO — moved to buddyboss-addons/addons/social-login/.
	// -------------------------------------------------------------------------

	if ( ! function_exists( 'bb_enable_sso' ) ) {
		/**
		 * Whether Social Login is enabled.
		 *
		 * @since      2.6.30
		 * @deprecated 3.2.0 Social Login moved to the BuddyBoss Addons plugin.
		 *
		 * @return bool Always false — the feature is unavailable without the add-on.
		 */
		function bb_enable_sso() {
			_deprecated_function( __FUNCTION__, '3.2.0', 'the BuddyBoss Addons plugin' );

			return false;
		}
	}
}
add_action( 'bp_init', 'bb_pro_install_moved_feature_fallbacks', 1 );

/**
 * Bridge the removed "feature included" action hooks.
 *
 * `load_sso()`, `load_reactions()` and `load_polls()` each fired an action once
 * their feature finished loading, and third-party code hooked those to run setup
 * at a point where the feature was guaranteed available. Pro no longer loads any
 * of them, so instead of firing the deprecated hooks unconditionally — which
 * would run legacy callbacks in an environment where the feature does NOT exist,
 * the exact situation they were written to avoid — each bridge is attached to the
 * add-on's equivalent "module loaded" action. A legacy callback therefore still
 * fires, at an equivalent point, and only when the feature is genuinely present.
 *
 * When the add-on is absent the add-on actions never fire, so neither do the
 * bridges — which is the correct outcome.
 *
 * @since 3.2.0
 *
 * @return void
 */
function bb_pro_bridge_moved_feature_hooks() {
	$bridges = array(
		'bb_addons_social_login_loaded' => 'bb_platform_pro_core_sso_included',
		'bb_addons_reactions_loaded'    => 'bb_platform_pro_core_reactions_included',
		'bb_addons_polls_loaded'        => 'bb_platform_pro_core_polls_included',
	);

	foreach ( $bridges as $addon_hook => $legacy_hook ) {
		add_action(
			$addon_hook,
			function () use ( $legacy_hook ) {
				/*
				 * Fires after the feature has loaded.
				 *
				 * @since      2.4.50
				 * @deprecated 3.2.0 The feature moved to the BuddyBoss Addons plugin.
				 */
				do_action_deprecated( $legacy_hook, array(), '3.2.0', '', 'The feature moved to the BuddyBoss Addons plugin.' ); // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.DynamicHooknameFound
			}
		);
	}
}
add_action( 'bp_loaded', 'bb_pro_bridge_moved_feature_hooks', 0 );
