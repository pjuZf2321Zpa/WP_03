<?php

namespace FluentCartPro\App\Modules\Reports\Http\Controllers;

use FluentCart\App\Http\Controllers\Controller;
use FluentCart\App\Services\Report\ReportHelper;
use FluentCart\Framework\Http\Request\Request;
use FluentCartPro\App\Modules\Reports\Services\OrderPatternsService;
use FluentCartPro\App\Modules\Reports\Services\RefundTimingService;

class OrderPatternsController extends Controller
{
    protected $params = [
        'orderTypes',
        'paymentStatus',
    ];

    public function orderValueDistribution(Request $request)
    {
        return ['data' => OrderPatternsService::make()->getOrderValueDistribution($this->processed($request))];
    }

    public function byDayAndHour(Request $request)
    {
        return OrderPatternsService::make()->getReportByDayAndHour($this->processed($request));
    }

    public function itemCountDistribution(Request $request)
    {
        return ['data' => OrderPatternsService::make()->getItemCountDistribution($this->processed($request))];
    }

    public function completionTime(Request $request)
    {
        return ['data' => OrderPatternsService::make()->getOrderCompletionTime($this->processed($request))];
    }

    public function weeksBetweenRefund(Request $request): array
    {
        return ['data' => RefundTimingService::make()->weeksBetweenRefund($this->processed($request))];
    }

    private function processed(Request $request): array
    {
        return ReportHelper::processParams($request->get('params'), $this->params, true);
    }
}
