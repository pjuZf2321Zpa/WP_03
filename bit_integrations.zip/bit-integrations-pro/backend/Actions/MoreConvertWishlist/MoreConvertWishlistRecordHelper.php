<?php

namespace BitApps\IntegrationsPro\Actions\MoreConvertWishlist;

use Exception;
use WLFMC_Customer;
use WLFMC_Wishlist;
use WLFMC_Wishlist_Factory;

if (!\defined('ABSPATH')) {
    exit;
}

final class MoreConvertWishlistRecordHelper
{
    public static function createWishlist($defaultResponse, $fieldData, $utilities = [])
    {
        if (!self::isPluginActive()) {
            return self::errorResponse(__('MoreConvert Wishlist for WooCommerce is not installed or activated', 'bit-integrations-pro'));
        }

        if (empty($fieldData['name'])) {
            return self::errorResponse(__('Wishlist name is required', 'bit-integrations-pro'));
        }

        $utilities = (array) $utilities;

        try {
            $wishlist = new WLFMC_Wishlist();
            self::applyWishlistFields($wishlist, $fieldData, $utilities);

            if (!empty($utilities['customerId']) && (int) $utilities['customerId'] > 0) {
                $wishlist->set_customer_id((int) $utilities['customerId']);
            }

            if (!empty($utilities['userId']) && (int) $utilities['userId'] > 0) {
                $wishlist->set_user_id((int) $utilities['userId']);
            }

            $wishlist->save();

            return self::successResponse(__('Wishlist created successfully', 'bit-integrations-pro'), ['wishlist' => self::prepareData($wishlist)]);
        } catch (Exception $e) {
            return self::errorResponse($e->getMessage());
        }
    }

    public static function updateWishlist($defaultResponse, $fieldData, $utilities = [])
    {
        if (!self::isPluginActive()) {
            return self::errorResponse(__('MoreConvert Wishlist for WooCommerce is not installed or activated', 'bit-integrations-pro'));
        }

        if (empty($fieldData['id'])) {
            return self::errorResponse(__('Wishlist ID is required', 'bit-integrations-pro'));
        }

        $wishlist = WLFMC_Wishlist_Factory::get_wishlist((int) $fieldData['id']);
        if (!$wishlist) {
            return self::errorResponse(__('Wishlist not found', 'bit-integrations-pro'));
        }

        $utilities = (array) $utilities;

        try {
            self::applyWishlistFields($wishlist, $fieldData, $utilities);
            $wishlist->save();

            return self::successResponse(__('Wishlist updated successfully', 'bit-integrations-pro'), ['wishlist' => self::prepareData($wishlist)]);
        } catch (Exception $e) {
            return self::errorResponse($e->getMessage());
        }
    }

    public static function deleteWishlist($defaultResponse, $fieldData)
    {
        if (!self::isPluginActive()) {
            return self::errorResponse(__('MoreConvert Wishlist for WooCommerce is not installed or activated', 'bit-integrations-pro'));
        }

        if (empty($fieldData['id'])) {
            return self::errorResponse(__('Wishlist ID is required', 'bit-integrations-pro'));
        }

        $wishlist = WLFMC_Wishlist_Factory::get_wishlist((int) $fieldData['id']);
        if (!$wishlist) {
            return self::errorResponse(__('Wishlist not found', 'bit-integrations-pro'));
        }

        if (!method_exists($wishlist, 'delete')) {
            return self::errorResponse(__('Wishlist cannot be deleted', 'bit-integrations-pro'));
        }

        try {
            $wishlist->delete();

            return self::successResponse(__('Wishlist deleted successfully', 'bit-integrations-pro'), ['wishlist_id' => (int) $fieldData['id']]);
        } catch (Exception $e) {
            return self::errorResponse($e->getMessage());
        }
    }

    public static function addProductToWishlist($defaultResponse, $fieldData, $utilities = [])
    {
        if (!self::isPluginActive()) {
            return self::errorResponse(__('MoreConvert Wishlist for WooCommerce is not installed or activated', 'bit-integrations-pro'));
        }

        $utilities = (array) $utilities;
        $wishlistId = $utilities['wishlistId'] ?? '';

        if (empty($wishlistId) || empty($fieldData['productId'])) {
            return self::errorResponse(__('Wishlist and Product ID are required', 'bit-integrations-pro'));
        }

        $wishlist = WLFMC_Wishlist_Factory::get_wishlist((int) $wishlistId);
        if (!$wishlist) {
            return self::errorResponse(__('Wishlist not found', 'bit-integrations-pro'));
        }

        try {
            $item = $wishlist->add_product((int) $fieldData['productId']);

            if (!$item) {
                return self::errorResponse(__('Product could not be added. It may be invalid or already in the wishlist.', 'bit-integrations-pro'));
            }

            $wishlist->save();

            return self::successResponse(__('Product added to wishlist successfully', 'bit-integrations-pro'), [
                'item'     => self::prepareWishlistItem($item),
                'wishlist' => self::prepareData($wishlist),
            ]);
        } catch (Exception $e) {
            return self::errorResponse($e->getMessage());
        }
    }

    public static function removeProductFromWishlist($defaultResponse, $fieldData, $utilities = [])
    {
        if (!self::isPluginActive()) {
            return self::errorResponse(__('MoreConvert Wishlist for WooCommerce is not installed or activated', 'bit-integrations-pro'));
        }

        $utilities = (array) $utilities;
        $wishlistId = $utilities['wishlistId'] ?? '';

        if (empty($wishlistId) || empty($fieldData['productId'])) {
            return self::errorResponse(__('Wishlist and Product ID are required', 'bit-integrations-pro'));
        }

        $wishlist = WLFMC_Wishlist_Factory::get_wishlist((int) $wishlistId);
        if (!$wishlist) {
            return self::errorResponse(__('Wishlist not found', 'bit-integrations-pro'));
        }

        try {
            $removed = $wishlist->remove_product((int) $fieldData['productId']);

            if (!$removed) {
                return self::errorResponse(__('Product is not in the wishlist', 'bit-integrations-pro'));
            }

            $wishlist->save();

            return self::successResponse(__('Product removed from wishlist successfully', 'bit-integrations-pro'), [
                'wishlist' => self::prepareData($wishlist),
            ]);
        } catch (Exception $e) {
            return self::errorResponse($e->getMessage());
        }
    }

    public static function createCustomer($defaultResponse, $fieldData, $utilities = [])
    {
        if (!self::isPluginActive()) {
            return self::errorResponse(__('MoreConvert Wishlist for WooCommerce is not installed or activated', 'bit-integrations-pro'));
        }

        $email = isset($fieldData['email']) ? sanitize_email($fieldData['email']) : '';
        if (empty($email)) {
            return self::errorResponse(__('Email is required', 'bit-integrations-pro'));
        }

        $utilities = (array) $utilities;

        try {
            $customer = new WLFMC_Customer();
            $customer->set_email($email);

            if (!empty($fieldData['firstName'])) {
                $customer->set_first_name($fieldData['firstName']);
            }
            if (!empty($fieldData['lastName'])) {
                $customer->set_last_name($fieldData['lastName']);
            }
            if (!empty($fieldData['phone'])) {
                $customer->set_phone($fieldData['phone']);
            }

            if (!empty($utilities['userId']) && (int) $utilities['userId'] > 0) {
                $customer->set_user_id((int) $utilities['userId']);
            } else {
                $customer->set_session_id(md5(uniqid('wlfmc_', true)));
            }

            $customer->save();

            return self::successResponse(__('Customer created successfully', 'bit-integrations-pro'), ['customer' => self::prepareData($customer)]);
        } catch (Exception $e) {
            return self::errorResponse($e->getMessage());
        }
    }

    public static function subscribeCustomer($defaultResponse, $fieldData)
    {
        return self::toggleCustomerSubscription($fieldData, true);
    }

    public static function unsubscribeCustomer($defaultResponse, $fieldData)
    {
        return self::toggleCustomerSubscription($fieldData, false);
    }

    private static function toggleCustomerSubscription($fieldData, $subscribe)
    {
        if (!self::isPluginActive()) {
            return self::errorResponse(__('MoreConvert Wishlist for WooCommerce is not installed or activated', 'bit-integrations-pro'));
        }

        if (empty($fieldData['id'])) {
            return self::errorResponse(__('Customer ID is required', 'bit-integrations-pro'));
        }

        $customer = WLFMC_Wishlist_Factory::get_customer((int) $fieldData['id']);
        if (!$customer) {
            return self::errorResponse(__('Customer not found', 'bit-integrations-pro'));
        }

        try {
            if ($subscribe) {
                WLFMC_Wishlist_Factory::subscribe_customer($customer);
            } else {
                WLFMC_Wishlist_Factory::unsubscribe_customer($customer);
            }

            return self::successResponse(
                $subscribe ? __('Customer subscribed successfully', 'bit-integrations-pro') : __('Customer unsubscribed successfully', 'bit-integrations-pro'),
                ['customer_id' => (int) $fieldData['id']]
            );
        } catch (Exception $e) {
            return self::errorResponse($e->getMessage());
        }
    }

    private static function applyWishlistFields($wishlist, $fieldData, $utilities = [])
    {
        if (isset($fieldData['name']) && $fieldData['name'] !== '') {
            $wishlist->set_name($fieldData['name']);
        }
        if (isset($fieldData['description']) && $fieldData['description'] !== '') {
            $wishlist->set_description($fieldData['description']);
        }
        if (isset($utilities['privacy']) && $utilities['privacy'] !== '') {
            $wishlist->set_privacy((int) $utilities['privacy']);
        }
        if (isset($utilities['isDefault']) && $utilities['isDefault'] !== '') {
            $wishlist->set_is_default((int) (bool) $utilities['isDefault']);
        }
    }

    private static function prepareData($data)
    {
        if (empty($data)) {
            return [];
        }
        if (\is_array($data)) {
            return $data;
        }
        if (\is_object($data) && method_exists($data, 'get_data')) {
            $base = $data->get_data();
            if (method_exists($data, 'get_id')) {
                $base['id'] = $data->get_id();
            }

            return $base;
        }
        if (\is_object($data) && method_exists($data, 'toArray')) {
            return $data->toArray();
        }

        return (array) $data;
    }

    private static function prepareWishlistItem($item)
    {
        if (empty($item)) {
            return [];
        }
        $data = self::prepareData($item);
        if (\is_object($item) && method_exists($item, 'get_product_id')) {
            $data['product_id'] = $item->get_product_id();
        }
        if (\is_object($item) && method_exists($item, 'get_wishlist_id')) {
            $data['wishlist_id'] = $item->get_wishlist_id();
        }
        if (\is_object($item) && method_exists($item, 'get_quantity')) {
            $data['quantity'] = $item->get_quantity();
        }

        return $data;
    }

    private static function isPluginActive()
    {
        return class_exists('WLFMC') && \function_exists('WLFMC') && class_exists('WLFMC_Wishlist_Factory');
    }

    private static function successResponse($message, $data = [])
    {
        return [
            'success' => true,
            'message' => $message,
            'data'    => $data,
        ];
    }

    private static function errorResponse($message)
    {
        return [
            'success' => false,
            'message' => $message,
        ];
    }
}
