jQuery(document).ready(function ($) {
    'use strict';

    // Define variables for elements
    let $outofthebox_module_id = $('#tag-generator-panel-outofthebox-module-id');
    let $outofthebox_selector_button = $('button#tag-generator-panel-outofthebox-module-selector');
    let $outofthebox_dialog = $('dialog#tag-generator-panel-outofthebox-module-selector-dialog');
    let $outofthebox_dialog_close_button = $('button.tag-generator-panel-outofthebox-module-close');
    let $iframe_template;

    // Event handler for selector button click
    $outofthebox_selector_button.on('click', function (e) {
        e.preventDefault();
            // Add size to dialog
            $outofthebox_dialog.css({
                height: '768px',
                width: '1024px',
                border: '0',
                padding: '0',
                overflow: 'hidden',
            });

            // Add iframe to dialog
            let moduleBuilderUrl = $outofthebox_dialog.parents('fieldset').attr('data-src');
            let $iframe_template = $(
                "<iframe src='' width='1024' height='768' tabindex='-1' style='border:none' title='Module Selector'></iframe>"
            );
            $outofthebox_dialog.append($iframe_template);

        
        let instanceId = window.WPCP_Bridge.createInstanceId();
        let unsubscribeBridge = window.WPCP_Bridge.subscribe(
            'out-of-the-box',
            'wpcp-shortcode',
            instanceId,
            function (data) {
                if (!data || typeof data.shortcode !== 'string') {
                    return;
                }

                let moduleMatch = data.shortcode.match(/module="(\d+)"/);
                if (!moduleMatch) {
                    return;
                }

                $outofthebox_module_id.val(moduleMatch[1]);
                $outofthebox_module_id[0].dispatchEvent(new Event('change', { bubbles: true }));
                $outofthebox_module_id[0].dispatchEvent(new Event('keyup', { bubbles: true }));
                unsubscribeBridge();

                // Delete Iframe
                $iframe_template.remove();
                $iframe_template = null;

                $outofthebox_dialog[0].close();
            }
        );

        moduleBuilderUrl += '&wpcp_instance_id=' + encodeURIComponent(instanceId);

        // Append module ID or default shortcode to URL
        if ($outofthebox_module_id.val() !== '') {
            moduleBuilderUrl += '&module=' + $outofthebox_module_id.val();
        } else {
            moduleBuilderUrl +=
                '&shortcode=' +
                WPCP_shortcodeEncode(
                    '[outofthebox mode="upload" viewrole="all" upload="1" uploadrole="all" upload_auto_start="0" userfolders="auto" viewuserfoldersrole="none"]'
                );
        }

        $iframe_template.attr('src', moduleBuilderUrl);

        // Show the dialog
        $outofthebox_dialog[0].showModal();
    });

    // Event handler for dialog close button click
    $outofthebox_dialog_close_button.on('click', function (e) {
        e.preventDefault();
        e.stopPropagation();

        // Delete Iframe
        $iframe_template.remove();
        $iframe_template = null;

        // Close the dialog
        $outofthebox_dialog[0].close();
    });

});
