<?php

namespace BitApps\IntegrationsPro\Triggers\CreatorLms;

class StaticData
{
    public static function events()
    {
        return [
            [
                'form_name'           => __('Student Enrolled in Course', 'bit-integrations-pro'),
                'triggered_entity_id' => 'creator_lms_after_enrolled_student',
                'skipPrimaryKey'      => true,
            ],
            [
                'form_name'           => __('Student Completed Course', 'bit-integrations-pro'),
                'triggered_entity_id' => 'creator_lms_course_completed',
                'skipPrimaryKey'      => true,
            ],
            [
                'form_name'           => __('Student Completed Lesson', 'bit-integrations-pro'),
                'triggered_entity_id' => 'creator_lms_lesson_completed',
                'skipPrimaryKey'      => true,
            ],
            [
                'form_name'           => __('Course Created', 'bit-integrations-pro'),
                'triggered_entity_id' => 'creatorlms_new_course',
                'skipPrimaryKey'      => true,
            ],
            [
                'form_name'           => __('Course Updated', 'bit-integrations-pro'),
                'triggered_entity_id' => 'creatorlms_update_course',
                'skipPrimaryKey'      => true,
            ],
        ];
    }
}
