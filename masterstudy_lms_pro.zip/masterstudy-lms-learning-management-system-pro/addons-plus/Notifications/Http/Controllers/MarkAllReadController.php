<?php

namespace MasterStudy\Lms\Pro\AddonsPlus\Notifications\Http\Controllers;

use MasterStudy\Lms\Http\WpResponseFactory;
use MasterStudy\Lms\Pro\AddonsPlus\Notifications\Repositories\NotificationRepository;
use WP_REST_Response;

final class MarkAllReadController {
	public function __invoke(): WP_REST_Response {
		try {
			if ( ! function_exists( 'masterstudy_lms_is_notifications_frontend_available' ) || ! masterstudy_lms_is_notifications_frontend_available() ) {
				return WpResponseFactory::forbidden();
			}

			$repository = new NotificationRepository();
			$repository->mark_all_read( get_current_user_id() );

			return WpResponseFactory::ok_with_data(
				array(
					'unread_count' => 0,
				)
			);
		} catch ( \Throwable $error ) {
			return WpResponseFactory::error( esc_html__( 'Unable to update notifications.', 'masterstudy-lms-learning-management-system-pro' ) );
		}
	}
}
