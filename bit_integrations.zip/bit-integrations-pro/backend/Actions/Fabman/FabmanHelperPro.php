<?php

namespace BitApps\IntegrationsPro\Actions\Fabman;

class FabmanHelperPro
{
    public static function updateMember($defaultValue, $data, $header, $apiEndPoint, $memberId)
    {
        $httpHelperClass = bit_integrations_get_class('Core\\Util\\HttpHelper');
        $response = $httpHelperClass::put($apiEndPoint . '/members/' . $memberId, $data, $header);

        if ($httpHelperClass && $httpHelperClass::$responseCode == 200) {
            return __('Member Updated Successfully', 'bit-integrations-pro');
        }
        if (\is_object($response) && isset($response->message)) {
            return $response->message;
        }

        return $response;
    }

    public static function deleteMember($defaultValue, $header, $apiEndPoint, $memberId)
    {
        $httpHelperClass = bit_integrations_get_class('Core\\Util\\HttpHelper');

        $response = $httpHelperClass::request($apiEndPoint . '/members/' . $memberId, 'DELETE', null, $header);

        if (empty($response)) {
            return __('Member Deleted Successfully', 'bit-integrations-pro');
        }
        if (\is_object($response) && isset($response->message)) {
            return $response->message;
        }

        return $response;
    }

    public static function createSpace($defaultValue, $data, $header, $apiEndPoint)
    {
        $httpHelperClass = bit_integrations_get_class('Core\\Util\\HttpHelper');
        $response = $httpHelperClass::post($apiEndPoint . '/spaces', $data, $header);

        if ($httpHelperClass && $httpHelperClass::$responseCode == 201) {
            return __('Space Created Successfully', 'bit-integrations-pro');
        }
        if (\is_object($response) && isset($response->message)) {
            return $response->message;
        }

        return $response;
    }

    public static function updateSpace($defaultValue, $data, $header, $apiEndPoint, $spaceId)
    {
        $httpHelperClass = bit_integrations_get_class('Core\\Util\\HttpHelper');
        $response = $httpHelperClass::put($apiEndPoint . '/spaces/' . $spaceId, $data, $header);

        if ($httpHelperClass && $httpHelperClass::$responseCode == 200) {
            return __('Space Updates Successfully', 'bit-integrations-pro');
        }
        if (\is_object($response) && isset($response->message)) {
            return $response->message;
        }

        return $response;
    }
}
