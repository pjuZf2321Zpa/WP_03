<?php

namespace FluentCartPro\App\Modules\StorageDrivers\R2;

use FluentCart\App\Helpers\Helper;
use FluentCart\Framework\Support\Arr;

class R2Settings
{
    protected const MISSING_DEFINE_CREDENTIALS_MESSAGE = 'R2 was configured previously, but the wp-config.php credentials are missing now. Add them again to continue.';

    protected array $settings;

    protected string $driverHandler = 'fluent_cart_storage_settings_r2';

    public static ?array $cachedSettings = null;

    public bool $isUsingDefineMode = false;

    public function __construct()
    {
        $this->isUsingDefineMode = self::hasDefinedCredentials();

        if (self::$cachedSettings !== null) {
            $this->settings = self::$cachedSettings;

            return;
        }

        $settings = fluent_cart_get_option($this->driverHandler, []);
        $hasStoredAuthMethod = !empty(Arr::get($settings, 'auth_method'));

        $this->settings = wp_parse_args($settings, static::getDefaults());

        if (!$hasStoredAuthMethod && $this->isUsingDefineMode) {
            $this->settings['auth_method'] = 'define';
        }

        $this->settings['defined_in_wp_config'] = $this->isUsingDefineMode;

        $this->applyDefineCredentialsState();

        self::$cachedSettings = $this->settings;
    }

    public static function getDefaults(): array
    {
        return [
            'is_active'                         => 'no',
            'auth_method'                       => 'define',
            'account_id'                        => '',
            'access_key'                        => '',
            'secret_key'                        => '',
            'bucket'                            => '',
            'region'                            => 'auto',
            'buckets'                           => [],
            'connection_error'                  => '',
            'define_credentials_missing'        => false,
            'define_credentials_missing_message' => '',
        ];
    }

    public function get(string $key = '')
    {
        $settings = $this->settings;
        $authMethod = Arr::get($settings, 'auth_method', 'define');

        if ($authMethod === 'define') {
            $definedCredentials = self::getDefinedCredentials();

            if ($definedCredentials) {
                $settings['account_id'] = Arr::get($definedCredentials, 'account_id', '');
                $settings['access_key'] = Arr::get($definedCredentials, 'access_key', '');
                $settings['secret_key'] = Arr::get($definedCredentials, 'secret_key', '');
            } else {
                $settings['account_id'] = '';
                $settings['access_key'] = '';
                $settings['secret_key'] = '';
            }
        } else {
            if (!empty($settings['access_key'])) {
                $settings['access_key'] = Helper::decryptKey($settings['access_key']) ?: $settings['access_key'];
            }

            if (!empty($settings['secret_key'])) {
                $settings['secret_key'] = Helper::decryptKey($settings['secret_key']) ?: $settings['secret_key'];
            }
        }

        if ($key) {
            return Arr::get($settings, $key);
        }

        return $settings;
    }

    protected function applyDefineCredentialsState(): void
    {
        $isDefineWithoutCredentials = Arr::get($this->settings, 'auth_method') === 'define' && !$this->isUsingDefineMode;
        $hadPreviousDefineContext = !empty(Arr::get($this->settings, 'bucket')) || Arr::get($this->settings, 'is_active') === 'yes';

        $this->settings['define_credentials_missing'] = $isDefineWithoutCredentials && $hadPreviousDefineContext;
        $this->settings['define_credentials_missing_message'] = $this->settings['define_credentials_missing']
            ? __(self::MISSING_DEFINE_CREDENTIALS_MESSAGE, 'fluent-cart-pro')
            : '';

        if ($this->settings['define_credentials_missing']) {
            $this->settings['is_active'] = 'no';
        }
    }

    /**
     * The single bucket this store has configured for R2. Mirrors
     * S3Settings::resolveEffectiveBucket, including the legacy `buckets` list
     * that older installs saved before the settings page moved to one bucket.
     */
    public static function resolveEffectiveBucket(array $settings): string
    {
        $bucket = trim((string) Arr::get($settings, 'bucket', ''));
        if ($bucket !== '') {
            return $bucket;
        }

        $legacyBuckets = Arr::get($settings, 'buckets', []);
        if (!is_array($legacyBuckets)) {
            return '';
        }

        foreach ($legacyBuckets as $legacyBucket) {
            $legacyBucket = trim((string) $legacyBucket);
            if ($legacyBucket !== '') {
                return $legacyBucket;
            }
        }

        return '';
    }

    public function isActive(): bool
    {
        $settings = $this->get();

        if (Arr::get($settings, 'is_active') !== 'yes') {
            return false;
        }

        if ($this->getAuthMethod() === 'define') {
            return self::hasDefinedCredentials() && !empty(Arr::get($settings, 'bucket'));
        }

        $requiredKeys = ['secret_key', 'access_key', 'account_id', 'bucket'];

        return $this->hasRequiredKeys($settings, $requiredKeys);
    }

    public function getAuthMethod(): string
    {
        return Arr::get($this->settings, 'auth_method', 'define');
    }

    protected function hasRequiredKeys(array $settings, array $requiredKeys): bool
    {
        foreach ($requiredKeys as $key) {
            if (empty(Arr::get($settings, $key))) {
                return false;
            }
        }

        return true;
    }

    public static function hasDefinedCredentials(): bool
    {
        return !empty(self::getDefinedCredentials());
    }

    public static function getDefinedCredentials(): array
    {
        if (
            defined('FCT_R2_ACCOUNT_ID') &&
            defined('FCT_R2_ACCESS_KEY') &&
            defined('FCT_R2_SECRET_KEY')
        ) {
            return [
                'account_id' => FCT_R2_ACCOUNT_ID,
                'access_key' => FCT_R2_ACCESS_KEY,
                'secret_key' => FCT_R2_SECRET_KEY,
            ];
        }

        return [];
    }
}
