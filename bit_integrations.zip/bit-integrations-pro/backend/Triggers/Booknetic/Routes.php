<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Core\Util\Route;
use BitApps\IntegrationsPro\Triggers\Booknetic\BookneticController;

Route::get('booknetic/get', [BookneticController::class, 'getAllTasks']);
