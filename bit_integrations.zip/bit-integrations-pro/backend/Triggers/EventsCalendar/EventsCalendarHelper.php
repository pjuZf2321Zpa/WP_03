<?php

namespace BitApps\IntegrationsPro\Triggers\EventsCalendar;

class EventsCalendarHelper
{
    // TEC changes event queries to hide past events and to return occurrence IDs; these flags turn that off.
    private const EVENT_QUERY_ARGS = ['tec_events_ignore' => true, 'tribe_suppress_query_filters' => true];

    public static function getAllEvents($data = null)
    {
        $taskId = \is_object($data) && isset($data->id) ? $data->id : '';
        $queryArgs = \in_array($taskId, EventsCalendarRecordController::EVENT_FILTER_TASKS, true) ? self::EVENT_QUERY_ARGS : [];

        $events = get_posts(
            [
                'post_type'      => 'tribe_events',
                'orderby'        => 'title',
                'order'          => 'ASC',
                'post_status'    => 'publish',
                'posts_per_page' => -1,
            ] + $queryArgs
        );

        $eventList[] = (object) [
            'value' => 'any',
            'label' => __('Any Event', 'bit-integrations-pro')
        ];

        if (!empty($events)) {
            foreach ($events as $event) {
                $eventList[] = (object) ['value' => (string) $event->ID, 'label' => $event->post_title];
            }
        }

        return $eventList;
    }

    public static function getAllSeries()
    {
        $seriesList = [(object) ['value' => 'any', 'label' => __('Any Series', 'bit-integrations-pro')]];

        $series = get_posts(
            [
                'post_type'      => 'tribe_event_series',
                'orderby'        => 'title',
                'order'          => 'ASC',
                'post_status'    => 'publish',
                'posts_per_page' => -1,
            ]
        );

        foreach ($series as $seriesPost) {
            $seriesList[] = (object) ['value' => (string) $seriesPost->ID, 'label' => $seriesPost->post_title];
        }

        return $seriesList;
    }

    public static function getFields($data)
    {
        if (\is_string($data)) {
            $id = $data;
        } else {
            $id = $data->id;
        }

        if (empty($id)) {
            return;
        }

        $fields = [];

        if ($id === 'events_calendar-1' || $id === 'events_calendar-2') {
            $fields = self::attendsEventFields();
        } elseif ($id === 'events_calendar-3' || $id === 'events_calendar-4') {
            $fields = self::newAttendeeFields();
        } else {
            $fields = self::recordFields($id);
        }

        return $fields;
    }

    public static function formatAttendsEventData($attendee)
    {
        if (empty($attendee)) {
            return false;
        }

        $data['purchaser_name'] = $attendee['purchaser_name'] ?? '';
        $data['purchaser_email'] = $attendee['purchaser_email'] ?? '';
        $data['holder_name'] = $attendee['holder_name'] ?? '';
        $data['holder_email'] = $attendee['holder_email'] ?? '';
        $data['attendee_id'] = $attendee['attendee_id'] ?? '';
        $data['ticket_id'] = $attendee['ticket_id'] ?? '';
        $data['ticket_name'] = $attendee['ticket_name'] ?? '';
        $data['qr_ticket_id'] = $attendee['qr_ticket_id'] ?? '';
        $data['price_paid'] = $attendee['price_paid'] ?? '';
        $data['currency'] = $attendee['currency'] ?? '';
        $data['attendee_date'] = $attendee['post_date'] ?? '';
        $data['attendee_date_gmt'] = $attendee['post_date_gmt'] ?? '';
        $data['attendee_modified'] = $attendee['post_modified'] ?? '';
        $data['attendee_modified_gmt'] = $attendee['post_modified_gmt'] ?? '';
        $data['order_id'] = $attendee['order_id'] ?? '';
        $data['order_status'] = $attendee['order_status'] ?? '';
        $data['check_in'] = $attendee['check_in'] ?? '';
        $data['ticket_sent'] = $attendee['ticket_sent'] ?? '';
        $data['is_subscribed'] = $attendee['is_subscribed'] ?? '';
        $data['is_purchaser'] = $attendee['is_purchaser'] ?? '';
        $data['ticket_exists'] = $attendee['ticket_exists'] ?? '';
        $data['event_id'] = $attendee['event_id'] ?? '';
        $data['security_code'] = $attendee['security_code'] ?? '';
        $data['purchase_time'] = $attendee['purchase_time'] ?? '';

        $event = [];

        if (\function_exists('tribe_events_get_ticket_event')) {
            $event = (array) tribe_events_get_ticket_event($attendee['ticket_id']);
        }

        if (!isset($event['post_title'])) {
            $event = get_post($attendee['event_id'], ARRAY_A);
        }

        $data['event_name'] = $event['post_title'] ?? '';
        $data['event_date'] = $event['post_date'] ?? '';
        $data['event_date_gmt'] = $event['post_date_gmt'] ?? '';
        $data['event_modified'] = $event['post_modified'] ?? '';
        $data['event_modified_gmt'] = $event['post_modified_gmt'] ?? '';
        $data['event_guid'] = $event['guid'] ?? '';

        return $data;
    }

    public static function formatNewAttendeeData($event, $orderId)
    {
        if (empty($event) || empty($orderId)) {
            return false;
        }

        if (!class_exists('Tribe__Tickets__Main')) {
            return false;
        }

        $event = (array) $event;
        $data = ['purchaser_name' => '', 'purchaser_email' => '', 'holder_names' => '', 'holder_emails' => '', 'attendee_ids' => '', 'ticket_ids' => '', 'qr_ticket_ids' => '', 'ticket_name' => '', 'order_ids' => '', 'order_status' => '', 'purchase_time' => ''];

        $attendees = tribe_tickets_get_attendees($orderId);

        if (empty($attendees)) {
            return false;
        }

        foreach ($attendees as $attendee) {
            $purchaserName = $attendee['purchaser_name'];
            $purchaserEmail = $attendee['purchaser_email'];
            $holderNames[$attendee['holder_name']] = $attendee['holder_name'];
            $holderEmails[$attendee['holder_email']] = $attendee['holder_email'];
            $attendeeIds[] = $attendee['attendee_id'];
            $ticketIds[] = $attendee['ticket_id'];
            $qrTicketIds[] = $attendee['qr_ticket_id'];
            $ticketName = $attendee['ticket_name'];
            $orderIds[] = $attendee['order_id'];
            $orderStatus = $attendee['order_status'];
            $purchaseTime = $attendee['purchase_time'];
        }

        $data['purchaser_name'] = $purchaserName;
        $data['purchaser_email'] = $purchaserEmail;

        if (!empty($holderNames)) {
            $data['holder_names'] = implode(',', $holderNames);
        }

        if (!empty($holderEmails)) {
            $data['holder_emails'] = implode(',', $holderEmails);
        }

        if (!empty($attendeeIds)) {
            $data['attendee_ids'] = implode(',', $attendeeIds);
        }

        if (!empty($ticketIds)) {
            $data['ticket_ids'] = implode(',', $ticketIds);
        }

        if (!empty($qrTicketIds)) {
            $data['qr_ticket_ids'] = implode(',', $qrTicketIds);
        }

        if (!empty($orderIds)) {
            $data['order_ids'] = implode(',', $orderIds);
        }

        $data['ticket_name'] = $ticketName;
        $data['order_status'] = $orderStatus;
        $data['purchase_time'] = $purchaseTime;

        $data['event_name'] = $event['post_title'] ?? '';
        $data['event_date'] = $event['post_date'] ?? '';
        $data['event_date_gmt'] = $event['post_date_gmt'] ?? '';
        $data['event_modified'] = $event['post_modified'] ?? '';
        $data['event_modified_gmt'] = $event['post_modified_gmt'] ?? '';
        $data['event_guid'] = $event['guid'] ?? '';

        return $data;
    }

    public static function flowFilter($flows, $key, $value)
    {
        $filteredFlows = [];

        if (\is_array($flows) || \is_object($flows)) {
            foreach ($flows as $flow) {
                if (\is_string($flow->flow_details)) {
                    $flow->flow_details = json_decode($flow->flow_details);
                }

                if (!isset($flow->flow_details->{$key}) || $flow->flow_details->{$key} === 'any' || $flow->flow_details->{$key} == $value || $flow->flow_details->{$key} === '' || $value === 'empty_terms') {
                    $filteredFlows[] = $flow;
                }
            }
        }

        return $filteredFlows;
    }

    private static function recordFields($id)
    {
        switch ($id) {
            case 'events_calendar-9':
            case 'events_calendar-10':
                $labels = self::eventFieldLabels() + ['previous_event_status' => __('Previous Event Status', 'bit-integrations-pro')];

                break;

            case 'events_calendar-13':
                $labels = self::eventFieldLabels() + ['original_event_id' => __('Original Event ID', 'bit-integrations-pro'), 'original_event_title' => __('Original Event Title', 'bit-integrations-pro')];

                break;

            case 'events_calendar-14':
            case 'events_calendar-15':
            case 'events_calendar-16':
                $labels = self::venueFieldLabels();

                break;

            case 'events_calendar-17':
            case 'events_calendar-18':
            case 'events_calendar-19':
                $labels = self::organizerFieldLabels();

                break;

            case 'events_calendar-20':
                $labels = self::eventFieldLabels() + self::addedToSeriesFieldLabels();

                break;

            case 'events_calendar-21':
                $labels = self::seriesFieldLabels();

                break;

            default:
                $labels = self::eventFieldLabels();

                break;
        }

        $fields = [];

        foreach ($labels as $name => $label) {
            $fields[] = ['name' => $name, 'type' => 'text', 'label' => $label];
        }

        return $fields;
    }

    private static function eventFieldLabels()
    {
        return [
            'event_id'            => __('Event ID', 'bit-integrations-pro'),
            'title'               => __('Event Title', 'bit-integrations-pro'),
            'description'         => __('Event Description', 'bit-integrations-pro'),
            'excerpt'             => __('Event Excerpt', 'bit-integrations-pro'),
            'status'              => __('Post Status', 'bit-integrations-pro'),
            'slug'                => __('Event Slug', 'bit-integrations-pro'),
            'url'                 => __('Event URL', 'bit-integrations-pro'),
            'author_id'           => __('Author ID', 'bit-integrations-pro'),
            'start_date'          => __('Start Date', 'bit-integrations-pro'),
            'end_date'            => __('End Date', 'bit-integrations-pro'),
            'start_date_utc'      => __('Start Date UTC', 'bit-integrations-pro'),
            'end_date_utc'        => __('End Date UTC', 'bit-integrations-pro'),
            'timezone'            => __('Time Zone', 'bit-integrations-pro'),
            'all_day'             => __('All Day', 'bit-integrations-pro'),
            'duration'            => __('Duration (seconds)', 'bit-integrations-pro'),
            'cost'                => __('Cost', 'bit-integrations-pro'),
            'currency_symbol'     => __('Currency Symbol', 'bit-integrations-pro'),
            'event_website'       => __('Event Website', 'bit-integrations-pro'),
            'featured'            => __('Featured', 'bit-integrations-pro'),
            'event_status'        => __('Event Status', 'bit-integrations-pro'),
            'event_status_reason' => __('Event Status Reason', 'bit-integrations-pro'),
            'is_recurring'        => __('Is Recurring', 'bit-integrations-pro'),
            'is_virtual'          => __('Is Virtual', 'bit-integrations-pro'),
            'virtual_url'         => __('Virtual URL', 'bit-integrations-pro'),
            'featured_image_url'  => __('Featured Image URL', 'bit-integrations-pro'),
            'venue_id'            => __('Venue ID', 'bit-integrations-pro'),
            'venue_name'          => __('Venue Name', 'bit-integrations-pro'),
            'venue_address'       => __('Venue Address', 'bit-integrations-pro'),
            'venue_city'          => __('Venue City', 'bit-integrations-pro'),
            'venue_state'         => __('Venue State or Province', 'bit-integrations-pro'),
            'venue_zip'           => __('Venue Postal Code', 'bit-integrations-pro'),
            'venue_country'       => __('Venue Country', 'bit-integrations-pro'),
            'organizer_ids'       => __('Organizer IDs', 'bit-integrations-pro'),
            'organizer_names'     => __('Organizer Names', 'bit-integrations-pro'),
            'organizer_emails'    => __('Organizer Emails', 'bit-integrations-pro'),
            'category_ids'        => __('Category IDs', 'bit-integrations-pro'),
            'categories'          => __('Categories', 'bit-integrations-pro'),
            'tags'                => __('Tags', 'bit-integrations-pro'),
            'series_id'           => __('Series ID', 'bit-integrations-pro'),
            'series_title'        => __('Series Title', 'bit-integrations-pro'),
            'created_at'          => __('Created At', 'bit-integrations-pro'),
            'modified_at'         => __('Modified At', 'bit-integrations-pro'),
        ];
    }

    private static function venueFieldLabels()
    {
        return [
            'venue_id'      => __('Venue ID', 'bit-integrations-pro'),
            'name'          => __('Venue Name', 'bit-integrations-pro'),
            'description'   => __('Description', 'bit-integrations-pro'),
            'status'        => __('Post Status', 'bit-integrations-pro'),
            'url'           => __('Venue URL', 'bit-integrations-pro'),
            'address'       => __('Address', 'bit-integrations-pro'),
            'city'          => __('City', 'bit-integrations-pro'),
            'state'         => __('State or Province', 'bit-integrations-pro'),
            'zip'           => __('Postal Code', 'bit-integrations-pro'),
            'country'       => __('Country', 'bit-integrations-pro'),
            'phone'         => __('Phone', 'bit-integrations-pro'),
            'website'       => __('Website', 'bit-integrations-pro'),
            'show_map'      => __('Show Map', 'bit-integrations-pro'),
            'show_map_link' => __('Show Map Link', 'bit-integrations-pro'),
            'created_at'    => __('Created At', 'bit-integrations-pro'),
            'modified_at'   => __('Modified At', 'bit-integrations-pro'),
        ];
    }

    private static function organizerFieldLabels()
    {
        return [
            'organizer_id' => __('Organizer ID', 'bit-integrations-pro'),
            'name'         => __('Organizer Name', 'bit-integrations-pro'),
            'description'  => __('Description', 'bit-integrations-pro'),
            'status'       => __('Post Status', 'bit-integrations-pro'),
            'url'          => __('Organizer URL', 'bit-integrations-pro'),
            'phone'        => __('Phone', 'bit-integrations-pro'),
            'website'      => __('Website', 'bit-integrations-pro'),
            'email'        => __('Email', 'bit-integrations-pro'),
            'created_at'   => __('Created At', 'bit-integrations-pro'),
            'modified_at'  => __('Modified At', 'bit-integrations-pro'),
        ];
    }

    private static function seriesFieldLabels()
    {
        return [
            'series_id'    => __('Series ID', 'bit-integrations-pro'),
            'title'        => __('Series Title', 'bit-integrations-pro'),
            'description'  => __('Description', 'bit-integrations-pro'),
            'status'       => __('Post Status', 'bit-integrations-pro'),
            'url'          => __('Series URL', 'bit-integrations-pro'),
            'event_ids'    => __('Event IDs', 'bit-integrations-pro'),
            'event_titles' => __('Event Titles', 'bit-integrations-pro'),
            'created_at'   => __('Created At', 'bit-integrations-pro'),
            'modified_at'  => __('Modified At', 'bit-integrations-pro'),
        ];
    }

    private static function addedToSeriesFieldLabels()
    {
        return [
            'series_description'  => __('Series Description', 'bit-integrations-pro'),
            'series_status'       => __('Series Post Status', 'bit-integrations-pro'),
            'series_url'          => __('Series URL', 'bit-integrations-pro'),
            'series_event_ids'    => __('Series Event IDs', 'bit-integrations-pro'),
            'series_event_titles' => __('Series Event Titles', 'bit-integrations-pro'),
            'series_created_at'   => __('Series Created At', 'bit-integrations-pro'),
            'series_modified_at'  => __('Series Modified At', 'bit-integrations-pro'),
        ];
    }

    private static function attendsEventFields($type = null, array $unsetFields = [])
    {
        $fields = [
            [
                'name'  => 'purchaser_name',
                'type'  => 'text',
                'label' => __('Purchaser Name', 'bit-integrations-pro'),
            ],
            [
                'name'  => 'purchaser_email',
                'type'  => 'text',
                'label' => __('Purchaser Email', 'bit-integrations-pro'),
            ],
            [
                'name'  => 'holder_name',
                'type'  => 'text',
                'label' => __('Holder Name', 'bit-integrations-pro'),
            ],
            [
                'name'  => 'holder_email',
                'type'  => 'text',
                'label' => __('Holder Email', 'bit-integrations-pro'),
            ],
            [
                'name'  => 'attendee_id',
                'type'  => 'text',
                'label' => __('Attendee ID', 'bit-integrations-pro'),
            ],
            [
                'name'  => 'ticket_id',
                'type'  => 'text',
                'label' => __('Ticket ID', 'bit-integrations-pro'),
            ],
            [
                'name'  => 'ticket_name',
                'type'  => 'text',
                'label' => __('Ticket Name', 'bit-integrations-pro'),
            ],
            [
                'name'  => 'qr_ticket_id',
                'type'  => 'text',
                'label' => __('QR Ticket ID', 'bit-integrations-pro'),
            ],
            [
                'name'  => 'price_paid',
                'type'  => 'text',
                'label' => __('Price Paid', 'bit-integrations-pro'),
            ],
            [
                'name'  => 'currency',
                'type'  => 'text',
                'label' => __('Currency', 'bit-integrations-pro'),
            ],
            [
                'name'  => 'attendee_date',
                'type'  => 'text',
                'label' => __('Attendee Date', 'bit-integrations-pro'),
            ],
            [
                'name'  => 'attendee_date_gmt',
                'type'  => 'text',
                'label' => __('Attendee Date GMT', 'bit-integrations-pro'),
            ],
            [
                'name'  => 'attendee_modified',
                'type'  => 'text',
                'label' => __('Attendee Modified', 'bit-integrations-pro'),
            ],
            [
                'name'  => 'attendee_modified_gmt',
                'type'  => 'text',
                'label' => __('Attendee Modified GMT', 'bit-integrations-pro'),
            ],
            [
                'name'  => 'order_id',
                'type'  => 'text',
                'label' => __('Order ID', 'bit-integrations-pro'),
            ],
            [
                'name'  => 'order_status',
                'type'  => 'text',
                'label' => __('Order Status', 'bit-integrations-pro'),
            ],
            [
                'name'  => 'event_id',
                'type'  => 'text',
                'label' => __('Event ID', 'bit-integrations-pro'),
            ],
            [
                'name'  => 'event_name',
                'type'  => 'text',
                'label' => __('Event Name', 'bit-integrations-pro'),
            ],
            [
                'name'  => 'event_date',
                'type'  => 'text',
                'label' => __('Event Date', 'bit-integrations-pro'),
            ],
            [
                'name'  => 'event_date_gmt',
                'type'  => 'text',
                'label' => __('Event Date GMT', 'bit-integrations-pro'),
            ],
            [
                'name'  => 'event_modified',
                'type'  => 'text',
                'label' => __('Event Modified', 'bit-integrations-pro'),
            ],
            [
                'name'  => 'event_modified_gmt',
                'type'  => 'text',
                'label' => __('Event Modified GMT', 'bit-integrations-pro'),
            ],
            [
                'name'  => 'event_guid',
                'type'  => 'text',
                'label' => __('Event GUID', 'bit-integrations-pro'),
            ],
            [
                'name'  => 'check_in',
                'type'  => 'text',
                'label' => __('Check In', 'bit-integrations-pro'),
            ],
            [
                'name'  => 'ticket_sent',
                'type'  => 'text',
                'label' => __('Ticket Sent', 'bit-integrations-pro'),
            ],
            [
                'name'  => 'is_subscribed',
                'type'  => 'text',
                'label' => __('Is Subscribed', 'bit-integrations-pro'),
            ],
            [
                'name'  => 'is_purchaser',
                'type'  => 'text',
                'label' => __('Is Purchaser', 'bit-integrations-pro'),
            ],
            [
                'name'  => 'ticket_exists',
                'type'  => 'text',
                'label' => __('Ticket Exists', 'bit-integrations-pro'),
            ],
            [
                'name'  => 'security_code',
                'type'  => 'text',
                'label' => __('Attendee Security Code', 'bit-integrations-pro'),
            ],
            [
                'name'  => 'purchase_time',
                'type'  => 'text',
                'label' => __('Purchase Time', 'bit-integrations-pro'),
            ],
        ];

        if (!empty($unsetFields)) {
            foreach ($unsetFields as $fieldKey) {
                unset($fields[$fieldKey]);
            }
        }

        return $fields;
    }

    private static function newAttendeeFields($type = null, array $unsetFields = [])
    {
        $fields = [
            [
                'name'  => 'purchaser_name',
                'type'  => 'text',
                'label' => __('Purchaser Name', 'bit-integrations-pro'),
            ],
            [
                'name'  => 'purchaser_email',
                'type'  => 'text',
                'label' => __('Purchaser Email', 'bit-integrations-pro'),
            ],
            [
                'name'  => 'holder_names',
                'type'  => 'text',
                'label' => __('Holder Name(s)', 'bit-integrations-pro'),
            ],
            [
                'name'  => 'holder_emails',
                'type'  => 'text',
                'label' => __('Holder Email(s)', 'bit-integrations-pro'),
            ],
            [
                'name'  => 'attendee_ids',
                'type'  => 'text',
                'label' => __('Attendee ID(s)', 'bit-integrations-pro'),
            ],
            [
                'name'  => 'ticket_ids',
                'type'  => 'text',
                'label' => __('Ticket ID(s)', 'bit-integrations-pro'),
            ],
            [
                'name'  => 'qr_ticket_ids',
                'type'  => 'text',
                'label' => __('QR Ticket ID(s)', 'bit-integrations-pro'),
            ],
            [
                'name'  => 'ticket_name',
                'type'  => 'text',
                'label' => __('Ticket Name', 'bit-integrations-pro'),
            ],
            [
                'name'  => 'order_ids',
                'type'  => 'text',
                'label' => __('Order ID(s)', 'bit-integrations-pro'),
            ],
            [
                'name'  => 'order_status',
                'type'  => 'text',
                'label' => __('Order Status', 'bit-integrations-pro'),
            ],
            [
                'name'  => 'purchase_time',
                'type'  => 'text',
                'label' => __('Purchase Time', 'bit-integrations-pro'),
            ],
            [
                'name'  => 'event_id',
                'type'  => 'text',
                'label' => __('Event ID', 'bit-integrations-pro'),
            ],
            [
                'name'  => 'event_name',
                'type'  => 'text',
                'label' => __('Event Name', 'bit-integrations-pro'),
            ],
            [
                'name'  => 'event_date',
                'type'  => 'text',
                'label' => __('Event Date', 'bit-integrations-pro'),
            ],
            [
                'name'  => 'event_date_gmt',
                'type'  => 'text',
                'label' => __('Event Date GMT', 'bit-integrations-pro'),
            ],
            [
                'name'  => 'event_modified',
                'type'  => 'text',
                'label' => __('Event Modified', 'bit-integrations-pro'),
            ],
            [
                'name'  => 'event_modified_gmt',
                'type'  => 'text',
                'label' => __('Event Modified GMT', 'bit-integrations-pro'),
            ],
            [
                'name'  => 'event_guid',
                'type'  => 'text',
                'label' => __('Event GUID', 'bit-integrations-pro'),
            ],
        ];

        if (!empty($unsetFields)) {
            foreach ($unsetFields as $fieldKey) {
                unset($fields[$fieldKey]);
            }
        }

        return $fields;
    }
}
