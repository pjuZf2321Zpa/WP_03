<?php

namespace WPAICG\Lib\Integrations\Recipes;

use WPAICG\Lib\Integrations\Apps\AIPKit_App_Connections;
use WPAICG\Lib\Integrations\Apps\AIPKit_App_Connection_Diagnostics;
use WP_Error;

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

class AIPKit_Recipe_Validator
{
    /**
     * @return array<int, string>
     */
    public static function get_runtime_supported_actions(): array
    {
        return [
            'slack_message_create',
            'hubspot_contact_upsert',
            'notion_page_create',
            'notion_database_item_create',
            'pipedrive_person_upsert',
            'zapier_webhook_trigger',
            'make_webhook_trigger',
            'n8n_webhook_trigger',
        ];
    }

    /**
     * @return array<string, array<string, mixed>>
     */
    public static function get_action_requirement_definitions(): array
    {
        return [
            'slack_message_create' => [
                'mode' => 'any_of',
                'field_sets' => [
                    [
                        ['group' => 'credentials', 'key' => 'webhook_url'],
                    ],
                    [
                        ['group' => 'credentials', 'key' => 'bot_token'],
                        ['group' => 'workspace', 'key' => 'default_channel'],
                    ],
                ],
                'message' => __('Slack needs either a webhook URL or a bot token with a default channel.', 'gpt3-ai-content-generator'),
            ],
            'hubspot_contact_upsert' => [
                'mode' => 'all_of',
                'field_sets' => [
                    [
                        ['group' => 'credentials', 'key' => 'private_app_token'],
                    ],
                ],
                'message' => __('HubSpot contact recipes need a private app token.', 'gpt3-ai-content-generator'),
            ],
            'notion_page_create' => [
                'mode' => 'all_of',
                'field_sets' => [
                    [
                        ['group' => 'credentials', 'key' => 'integration_token'],
                        ['group' => 'workspace', 'key' => 'parent_page_id'],
                    ],
                ],
                'message' => __('Notion page recipes need an integration token and parent page ID.', 'gpt3-ai-content-generator'),
            ],
            'notion_database_item_create' => [
                'mode' => 'all_of',
                'field_sets' => [
                    [
                        ['group' => 'credentials', 'key' => 'integration_token'],
                        ['group' => 'workspace', 'key' => 'database_id'],
                    ],
                ],
                'message' => __('Notion database item recipes need an integration token and database ID.', 'gpt3-ai-content-generator'),
            ],
            'pipedrive_person_upsert' => [
                'mode' => 'all_of',
                'field_sets' => [
                    [
                        ['group' => 'credentials', 'key' => 'api_token'],
                        ['group' => 'workspace', 'key' => 'company_domain'],
                    ],
                ],
                'message' => __('Pipedrive person recipes need an API token and company domain.', 'gpt3-ai-content-generator'),
            ],
            'zapier_webhook_trigger' => [
                'mode' => 'all_of',
                'field_sets' => [
                    [
                        ['group' => 'credentials', 'key' => 'webhook_url'],
                    ],
                ],
                'message' => __('Zapier webhook recipes need a webhook URL.', 'gpt3-ai-content-generator'),
            ],
            'make_webhook_trigger' => [
                'mode' => 'all_of',
                'field_sets' => [
                    [
                        ['group' => 'credentials', 'key' => 'webhook_url'],
                    ],
                ],
                'message' => __('Make webhook recipes need a webhook URL.', 'gpt3-ai-content-generator'),
            ],
            'n8n_webhook_trigger' => [
                'mode' => 'all_of',
                'field_sets' => [
                    [
                        ['group' => 'credentials', 'key' => 'webhook_url'],
                    ],
                ],
                'message' => __('n8n webhook recipes need a webhook URL.', 'gpt3-ai-content-generator'),
            ],
        ];
    }

    /**
     * @return array<string, array<string, mixed>>
     */
    public static function get_mapping_requirement_definitions(): array
    {
        return [
            'hubspot_contact_upsert' => [
                'required_targets' => ['email'],
                'message' => __('HubSpot contact recipes need an Email mapping.', 'gpt3-ai-content-generator'),
            ],
            'pipedrive_person_upsert' => [
                'required_targets' => ['name'],
                'message' => __('Pipedrive person recipes need a Name mapping.', 'gpt3-ai-content-generator'),
            ],
        ];
    }

    /**
     * @return array<string, mixed>
     */
    public static function get_ui_validation_definitions(): array
    {
        return [
            'runtime_supported_actions' => self::get_runtime_supported_actions(),
            'action_requirements' => self::get_action_requirement_definitions(),
            'mapping_requirements' => self::get_mapping_requirement_definitions(),
        ];
    }

    /**
     * @param array<string, mixed> $recipe
     * @param array<string, mixed>|null $connection
     * @return bool|WP_Error
     */
    public static function validate_recipe_for_execution(array $recipe, ?array $connection = null)
    {
        $app_slug = sanitize_key((string) ($recipe['app_slug'] ?? ''));
        $action_slug = sanitize_key((string) ($recipe['action_slug'] ?? ''));
        $connection_id = sanitize_text_field((string) ($recipe['connection_id'] ?? ''));

        if ($action_slug === '' || !in_array($action_slug, self::get_runtime_supported_actions(), true)) {
            return new WP_Error(
                'aipkit_recipe_action_not_available',
                __('This recipe action is not available yet.', 'gpt3-ai-content-generator'),
                ['status' => 'error']
            );
        }

        if ($connection_id === '') {
            return new WP_Error(
                'aipkit_recipe_connection_required',
                __('Select a connection before enabling this recipe.', 'gpt3-ai-content-generator'),
                ['status' => 'error']
            );
        }

        if ((!is_array($connection) || empty($connection)) && $connection_id !== '') {
            $resolved_connection = AIPKit_App_Connections::get_connection_by_id($connection_id);
            if (is_array($resolved_connection)) {
                $connection = $resolved_connection;
            }
        }

        if (!is_array($connection) || empty($connection)) {
            return new WP_Error(
                'aipkit_recipe_connection_missing',
                __('The selected app connection could not be resolved.', 'gpt3-ai-content-generator'),
                ['status' => 'error']
            );
        }

        $connection_app_slug = sanitize_key((string) ($connection['app_slug'] ?? ''));
        if ($app_slug === '' || $connection_app_slug === '' || $app_slug !== $connection_app_slug) {
            return new WP_Error(
                'aipkit_recipe_connection_app_mismatch',
                __('The selected connection belongs to a different app.', 'gpt3-ai-content-generator'),
                ['status' => 'error']
            );
        }

        if (empty($connection['is_enabled'])) {
            return new WP_Error(
                'aipkit_recipe_connection_disabled',
                __('The selected connection is disabled.', 'gpt3-ai-content-generator'),
                ['status' => 'error']
            );
        }

        $connection_status = sanitize_key((string) ($connection['status'] ?? 'draft'));
        if ($connection_status === 'reauth_required') {
            return new WP_Error(
                'aipkit_recipe_connection_reauth_required',
                __('Reconnect this app connection before using the recipe.', 'gpt3-ai-content-generator'),
                ['status' => 'reauth_required']
            );
        }

        $connection_requirements = self::validate_connection_for_action($connection, $action_slug);
        if (is_wp_error($connection_requirements)) {
            return $connection_requirements;
        }

        $mapping_requirements = self::validate_mapping_for_action($recipe, $action_slug);
        if (is_wp_error($mapping_requirements)) {
            return $mapping_requirements;
        }

        return true;
    }

    /**
     * @param array<string, mixed> $recipe
     * @param array<string, mixed>|null $connection
     * @return array<string, string>
     */
    public static function get_recipe_ui_state(array $recipe, ?array $connection = null): array
    {
        $validation = self::validate_recipe_for_execution($recipe, $connection);
        if (is_wp_error($validation)) {
            $error_data = $validation->get_error_data();
            $status = is_array($error_data)
                ? sanitize_key((string) ($error_data['status'] ?? 'error'))
                : 'error';

            return [
                'status_key' => in_array($status, ['reauth_required', 'warning'], true) ? $status : 'error',
                'summary' => sanitize_text_field($validation->get_error_message()),
            ];
        }

        $connection_status = 'draft';
        if (is_array($connection)) {
            $connection_status = sanitize_key((string) ($connection['status'] ?? 'draft'));
            $diagnostics_class = AIPKit_App_Connection_Diagnostics::class;
            if (class_exists($diagnostics_class) && method_exists($diagnostics_class, 'get_effective_connection_status')) {
                $connection_status = $diagnostics_class::get_effective_connection_status($connection);
                if (in_array($connection_status, ['error', 'reauth_required'], true)) {
                    $diagnostics = $diagnostics_class::get_connection_ui_state($connection);
                    return ['status_key' => $connection_status, 'summary' => $diagnostics['summary']];
                }
            }
        }
        $connection_auth_type = is_array($connection)
            ? sanitize_key((string) ($connection['auth_type'] ?? ''))
            : '';

        if ($connection_status !== 'active') {
            return [
                'status_key' => 'warning',
                'summary' => $connection_auth_type === 'webhook'
                    ? __('Webhook connection is ready. Delivery is verified at runtime.', 'gpt3-ai-content-generator')
                    : __('Connection is saved but has not been verified yet.', 'gpt3-ai-content-generator'),
            ];
        }

        return [
            'status_key' => 'ready',
            'summary' => __('Recipe is ready to run.', 'gpt3-ai-content-generator'),
        ];
    }

    /**
     * @param array<string, mixed> $connection
     * @return bool|WP_Error
     */
    public static function validate_connection_for_action(array $connection, string $action_slug)
    {
        $connection_app_slug = sanitize_key((string) ($connection['app_slug'] ?? ''));
        $connection_auth_type = sanitize_key((string) ($connection['auth_type'] ?? ''));
        if ($action_slug === 'slack_message_create' && $connection_app_slug === 'slack') {
            if ($connection_auth_type === 'webhook') {
                $webhook_url = AIPKit_App_Connections::get_connection_field_value($connection, 'credentials', 'webhook_url');
                if ($webhook_url !== '') {
                    return true;
                }

                return new WP_Error(
                    'aipkit_recipe_action_requirements_missing',
                    __('Slack webhook recipes need a webhook URL.', 'gpt3-ai-content-generator'),
                    ['status' => 'error']
                );
            }

            $bot_token = AIPKit_App_Connections::get_connection_field_value($connection, 'credentials', 'bot_token');
            $default_channel = AIPKit_App_Connections::get_connection_field_value($connection, 'workspace', 'default_channel');
            if ($bot_token !== '' && $default_channel !== '') {
                return true;
            }

            return new WP_Error(
                'aipkit_recipe_action_requirements_missing',
                __('Slack token recipes need a bot token and default channel.', 'gpt3-ai-content-generator'),
                ['status' => 'error']
            );
        }

        $definitions = self::get_action_requirement_definitions();
        $action_key = sanitize_key($action_slug);
        $definition = $definitions[$action_key] ?? null;
        if (!is_array($definition)) {
            return new WP_Error(
                'aipkit_recipe_action_not_available',
                __('This recipe action is not available yet.', 'gpt3-ai-content-generator'),
                ['status' => 'error']
            );
        }

        $mode = sanitize_key((string) ($definition['mode'] ?? 'all_of'));
        $field_sets = isset($definition['field_sets']) && is_array($definition['field_sets'])
            ? $definition['field_sets']
            : [];
        if (empty($field_sets)) {
            return true;
        }

        $matches = [];
        foreach ($field_sets as $field_set) {
            if (!is_array($field_set)) {
                continue;
            }

            $matches[] = self::does_connection_field_set_match($connection, $field_set);
        }

        $passes = $mode === 'any_of'
            ? in_array(true, $matches, true)
            : !in_array(false, $matches, true);

        if ($passes) {
            return true;
        }

        return new WP_Error(
            'aipkit_recipe_action_requirements_missing',
            sanitize_text_field((string) ($definition['message'] ?? __('This app action is missing required connection fields.', 'gpt3-ai-content-generator'))),
            ['status' => 'error']
        );
    }

    /**
     * @param array<string, mixed> $recipe
     * @return bool|WP_Error
     */
    public static function validate_mapping_for_action(array $recipe, string $action_slug)
    {
        $definitions = self::get_mapping_requirement_definitions();
        $action_key = sanitize_key($action_slug);
        $definition = $definitions[$action_key] ?? null;
        if (!is_array($definition)) {
            return true;
        }

        $required_targets = isset($definition['required_targets']) && is_array($definition['required_targets'])
            ? array_values(array_filter(array_map('sanitize_key', $definition['required_targets'])))
            : [];
        if (empty($required_targets)) {
            return true;
        }

        $mapping_fields = isset($recipe['mapping']['fields']) && is_array($recipe['mapping']['fields'])
            ? $recipe['mapping']['fields']
            : [];

        foreach ($required_targets as $target_field) {
            $has_target = false;
            foreach ($mapping_fields as $mapping_field) {
                if (!is_array($mapping_field)) {
                    continue;
                }

                $mapped_target = sanitize_key((string) ($mapping_field['target_field'] ?? ''));
                $source_path = sanitize_text_field((string) ($mapping_field['source_path'] ?? ''));
                $fallback_value = is_scalar($mapping_field['fallback_value'] ?? '')
                    ? trim((string) ($mapping_field['fallback_value'] ?? ''))
                    : '';

                if ($mapped_target !== $target_field) {
                    continue;
                }

                if ($source_path !== '' || $fallback_value !== '') {
                    $has_target = true;
                    break;
                }
            }

            if (!$has_target) {
                return new WP_Error(
                    'aipkit_recipe_mapping_required_target_missing',
                    sanitize_text_field((string) ($definition['message'] ?? __('This recipe is missing a required field mapping.', 'gpt3-ai-content-generator'))),
                    ['status' => 'error']
                );
            }
        }

        return true;
    }

    /**
     * @param array<string, mixed> $connection
     * @param array<int, array<string, string>> $field_set
     */
    private static function does_connection_field_set_match(array $connection, array $field_set): bool
    {
        foreach ($field_set as $field_definition) {
            if (!is_array($field_definition)) {
                return false;
            }

            $group = sanitize_key((string) ($field_definition['group'] ?? ''));
            $key = sanitize_key((string) ($field_definition['key'] ?? ''));
            if ($group === '' || $key === '') {
                return false;
            }

            $value = AIPKit_App_Connections::get_connection_field_value($connection, $group, $key);
            if ($value === '') {
                return false;
            }
        }

        return true;
    }
}
