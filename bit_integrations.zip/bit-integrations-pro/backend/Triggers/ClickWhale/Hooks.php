<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Core\Util\Hooks;
use BitApps\IntegrationsPro\Triggers\ClickWhale\ClickWhaleController;

Hooks::add('clickwhale/link_clicked', [ClickWhaleController::class, 'handleLinkClicked'], 20, 3);
Hooks::add('clickwhale_link_inserted', [ClickWhaleController::class, 'handleLinkCreated'], 20, 2);
Hooks::add('clickwhale_link_updated', [ClickWhaleController::class, 'handleLinkUpdated'], 20, 2);
Hooks::add('clickwhale_link_deleted', [ClickWhaleController::class, 'handleLinkDeleted'], 20, 1);
