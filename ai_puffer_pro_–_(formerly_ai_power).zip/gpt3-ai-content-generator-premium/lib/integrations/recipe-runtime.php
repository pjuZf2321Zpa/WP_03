<?php

namespace WPAICG\Lib\Integrations\Recipes;

use WPAICG\Lib\Integrations\Apps\AIPKit_App_Action_Dispatcher;
use WPAICG\Lib\Integrations\Apps\AIPKit_App_Connections;
use WPAICG\Lib\Integrations\Logs\AIPKit_Recipe_Delivery_Log_Store;
use WPAICG\Lib\Integrations\Recipes\Contracts\AIPKit_Recipe_Executor_Interface;
use WPAICG\Lib\Integrations\Recipes\Contracts\AIPKit_Recipe_Registry_Interface;
use WP_Error;

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

class AIPKit_Recipe_Runtime_Provider
{
    public static function register_hooks(): void
    {
        if (!AIPKit_Recipe_Runtime_Gate::can_load_runtime()) {
            return;
        }

        add_filter('aipkit_native_app_recipe_runtime_recipes', [__CLASS__, 'filter_runtime_recipes'], 10, 5);
        add_filter('aipkit_native_app_recipe_runtime_connection', [__CLASS__, 'resolve_runtime_connection'], 10, 5);
        add_filter('aipkit_native_app_recipe_execute', [__CLASS__, 'execute_recipe'], 10, 5);

        add_action('aipkit_native_app_recipe_runtime_executed', [__CLASS__, 'handle_execution_success'], 10, 4);
        add_action('aipkit_native_app_recipe_runtime_failed', [__CLASS__, 'handle_execution_failure'], 10, 4);
    }

    /**
     * @param mixed $recipes
     * @return array<int, array<string, mixed>>
     */
    public static function filter_runtime_recipes($recipes, string $event_name, array $envelope = [], array $dispatch_result = [], array $event_context = []): array
    {
        $runtime_recipes = is_array($recipes) ? array_values(array_filter($recipes, 'is_array')) : [];
        $stored_recipes = AIPKit_Stored_Recipes::get_matching_enabled_recipes($event_name);
        if (empty($stored_recipes)) {
            return $runtime_recipes;
        }

        foreach ($stored_recipes as $stored_recipe) {
            if (!AIPKit_Stored_Recipes::recipe_matches_event_filters($stored_recipe, $envelope, $dispatch_result, $event_context)) {
                continue;
            }

            $recipe_id = sanitize_text_field((string) ($stored_recipe['id'] ?? ''));
            if ($recipe_id === '') {
                continue;
            }

            $already_present = false;
            foreach ($runtime_recipes as $runtime_recipe) {
                if (sanitize_text_field((string) ($runtime_recipe['id'] ?? '')) === $recipe_id) {
                    $already_present = true;
                    break;
                }
            }

            if (!$already_present) {
                $runtime_recipes[] = $stored_recipe;
            }
        }

        return $runtime_recipes;
    }

    /**
     * @param mixed $connection
     * @return array<string, mixed>
     */
    public static function resolve_runtime_connection($connection, array $recipe, string $event_name, array $envelope = [], array $dispatch_result = [], array $event_context = []): array
    {
        if (is_array($connection) && !empty($connection)) {
            return $connection;
        }

        $connection_id = sanitize_text_field((string) ($recipe['connection_id'] ?? ''));
        if ($connection_id === '') {
            return [];
        }

        $resolved_connection = AIPKit_App_Connections::get_connection_by_id($connection_id);
        if (!is_array($resolved_connection) || empty($resolved_connection)) {
            return [];
        }

        if (empty($resolved_connection['is_enabled'])) {
            return [];
        }

        return $resolved_connection;
    }

    /**
     * @param mixed $result
     * @return array<string, mixed>|WP_Error|null
     */
    public static function execute_recipe($result, array $execution, array $recipe, array $event_envelope, array $context = [])
    {
        if ($result !== null) {
            return $result;
        }

        return AIPKit_App_Action_Dispatcher::execute($execution, $recipe, $event_envelope, $context);
    }

    /**
     * @param array<string, mixed> $result
     * @param array<string, mixed> $recipe
     * @param array<string, mixed> $execution_context
     * @param array<string, mixed> $envelope
     */
    public static function handle_execution_success(array $result, array $recipe, array $execution_context = [], array $envelope = []): void
    {
        $completed_at = gmdate('c');
        $attempt_count = max(1, (int) ($result['attempt_count'] ?? (($result['dispatch']['meta']['attempt_count'] ?? 1))));
        $success_message = sanitize_text_field((string) (($result['dispatch']['message'] ?? '') ?: __('Recipe executed successfully.', 'gpt3-ai-content-generator')));

        $recipe_id = sanitize_text_field((string) ($recipe['id'] ?? ''));
        if ($recipe_id !== '') {
            AIPKit_Stored_Recipes::update_recipe_runtime_state($recipe_id, [
                'status' => 'active',
                'last_delivery_at' => $completed_at,
            ]);
        }

        $connection = isset($execution_context['connection']) && is_array($execution_context['connection'])
            ? $execution_context['connection']
            : [];
        $connection_id = sanitize_text_field((string) ($connection['id'] ?? ''));
        if ($connection_id !== '') {
            $connection_auth_type = sanitize_key((string) ($connection['auth_type'] ?? ''));
            $meta_updates = [
                'last_runtime_status' => 'success',
                'last_runtime_message' => $success_message,
                'last_runtime_at' => $completed_at,
                'last_runtime_http_code' => max(0, (int) ($result['dispatch']['http_code'] ?? 0)),
                'last_runtime_attempt_count' => $attempt_count,
                'last_runtime_details' => [
                    'request_meta' => isset($result['dispatch']['meta']['request_meta']) && is_array($result['dispatch']['meta']['request_meta'])
                        ? $result['dispatch']['meta']['request_meta']
                        : [],
                ],
            ];

            if ($connection_auth_type !== 'webhook') {
                $meta_updates['last_test_status'] = 'success';
                $meta_updates['last_test_message'] = $success_message;
                $meta_updates['last_tested_at'] = $completed_at;
                $meta_updates['last_test_http_code'] = max(0, (int) ($result['dispatch']['http_code'] ?? 0));
            }

            AIPKit_App_Connections::update_connection_runtime_state($connection_id, [
                'status' => 'active',
                'meta' => $meta_updates,
            ]);
        }
    }

    /**
     * @param WP_Error $error
     * @param array<string, mixed> $recipe
     * @param array<string, mixed> $execution_context
     * @param array<string, mixed> $envelope
     */
    public static function handle_execution_failure(WP_Error $error, array $recipe, array $execution_context = [], array $envelope = []): void
    {
        $error_data = $error->get_error_data();
        $error_meta = is_array($error_data) ? $error_data : [];
        $failure_status = sanitize_key((string) ($error_meta['status'] ?? 'error'));
        if (!in_array($failure_status, ['error', 'reauth_required'], true)) {
            $failure_status = 'error';
        }
        $failed_at = gmdate('c');

        $recipe_id = sanitize_text_field((string) ($recipe['id'] ?? ''));
        if ($recipe_id !== '') {
            AIPKit_Stored_Recipes::update_recipe_runtime_state($recipe_id, [
                'status' => 'error',
                'last_delivery_at' => $failed_at,
            ]);
        }

        $connection = isset($execution_context['connection']) && is_array($execution_context['connection'])
            ? $execution_context['connection']
            : [];
        $connection_id = sanitize_text_field((string) ($connection['id'] ?? ''));
        if ($connection_id !== '') {
            $http_code = max(0, (int) ($error_meta['http_code'] ?? 0));
            $attempt_count = max(1, (int) ($error_meta['attempt_count'] ?? 1));
            $details = isset($error_meta['details']) && is_array($error_meta['details']) ? $error_meta['details'] : [];
            $meta_updates = [
                'last_runtime_status' => $failure_status === 'reauth_required' ? 'reauth_required' : 'error',
                'last_runtime_message' => sanitize_text_field($error->get_error_message()),
                'last_runtime_at' => $failed_at,
                'last_runtime_http_code' => $http_code,
                'last_runtime_attempt_count' => $attempt_count,
                'last_runtime_details' => $details,
            ];
            $runtime_updates = [
                'meta' => $meta_updates,
            ];

            if ($failure_status === 'reauth_required') {
                $runtime_updates['status'] = $failure_status;
                $meta_updates['last_test_status'] = 'reauth_required';
                $meta_updates['last_test_message'] = sanitize_text_field($error->get_error_message());
                $meta_updates['last_tested_at'] = $failed_at;
                $meta_updates['last_test_http_code'] = $http_code;
                $meta_updates['last_test_details'] = $details;
                $runtime_updates['meta'] = $meta_updates;
            }

            AIPKit_App_Connections::update_connection_runtime_state($connection_id, $runtime_updates);
        }

        if (empty($execution_context['skip_failure_log']) && class_exists(AIPKit_Recipe_Delivery_Log_Store::class)) {
            AIPKit_Recipe_Delivery_Log_Store::log_failed_attempt($recipe, $execution_context, $envelope, $error);
        }
    }
}

/** Bridges shared emitted events into recipe execution through runtime filters. */
class AIPKit_Recipe_Event_Bridge
{
    private static ?AIPKit_Recipe_Registry_Interface $registry = null;

    private static ?AIPKit_Recipe_Executor_Interface $executor = null;

    public static function register_hooks(): void
    {
        if (!AIPKit_Recipe_Runtime_Gate::can_load_runtime()) {
            return;
        }

        add_action('aipkit_event_webhooks_emitted', [__CLASS__, 'handle_emitted_event'], 10, 2);
    }

    /**
     * @param array<string, mixed> $dispatch_result
     * @param array<string, mixed> $event_context
     */
    public static function handle_emitted_event(array $dispatch_result, array $event_context = []): void
    {
        if (!AIPKit_Recipe_Runtime_Gate::can_load_recipes()) {
            return;
        }

        $event_name = sanitize_text_field((string) ($dispatch_result['event_name'] ?? ''));
        $envelope = isset($dispatch_result['envelope']) && is_array($dispatch_result['envelope'])
            ? $dispatch_result['envelope']
            : [];

        if ($event_name === '' || empty($envelope)) {
            return;
        }

        $recipes = apply_filters(
            'aipkit_native_app_recipe_runtime_recipes',
            [],
            $event_name,
            $envelope,
            $dispatch_result,
            $event_context
        );

        if (!is_array($recipes) || empty($recipes)) {
            return;
        }

        $executor = self::get_executor();
        foreach ($recipes as $recipe) {
            if (!is_array($recipe)) {
                continue;
            }

            if (!AIPKit_Recipe_Runtime_Gate::can_execute_recipe($recipe, [
                'dispatch_result' => $dispatch_result,
                'event_context' => $event_context,
                'envelope' => $envelope,
            ])) {
                continue;
            }

            $recipe_event_name = sanitize_text_field((string) ($recipe['event_name'] ?? ''));
            if ($recipe_event_name !== '' && $recipe_event_name !== $event_name) {
                continue;
            }

            $connection = apply_filters(
                'aipkit_native_app_recipe_runtime_connection',
                [],
                $recipe,
                $event_name,
                $envelope,
                $dispatch_result,
                $event_context
            );

            $execution_context = [
                'dispatch_result' => $dispatch_result,
                'event_context' => $event_context,
                'connection' => is_array($connection) ? $connection : [],
            ];

            do_action(
                'aipkit_native_app_recipe_runtime_before_execute',
                $recipe,
                $execution_context,
                $envelope
            );

            $can_execute = $executor->can_execute($recipe, $envelope);
            if (is_wp_error($can_execute)) {
                do_action(
                    'aipkit_native_app_recipe_runtime_failed',
                    $can_execute,
                    $recipe,
                    $execution_context,
                    $envelope
                );
                continue;
            }

            if ($can_execute !== true) {
                continue;
            }

            $result = $executor->execute($recipe, $envelope, $execution_context);
            if (is_wp_error($result)) {
                do_action(
                    'aipkit_native_app_recipe_runtime_failed',
                    $result,
                    $recipe,
                    $execution_context,
                    $envelope
                );
                continue;
            }

            do_action(
                'aipkit_native_app_recipe_runtime_executed',
                $result,
                $recipe,
                $execution_context,
                $envelope
            );
        }
    }

    private static function get_registry(): AIPKit_Recipe_Registry_Interface
    {
        if (self::$registry === null) {
            self::$registry = new AIPKit_Recipe_Registry();
        }

        $filtered_registry = apply_filters('aipkit_native_app_recipe_runtime_registry', self::$registry);
        if ($filtered_registry instanceof AIPKit_Recipe_Registry_Interface) {
            self::$registry = $filtered_registry;
        }

        return self::$registry;
    }

    private static function get_executor(): AIPKit_Recipe_Executor_Interface
    {
        if (self::$executor === null) {
            self::$executor = new AIPKit_Recipe_Executor(self::get_registry());
        }

        $filtered_executor = apply_filters('aipkit_native_app_recipe_runtime_executor', self::$executor, self::get_registry());
        if ($filtered_executor instanceof AIPKit_Recipe_Executor_Interface) {
            self::$executor = $filtered_executor;
        }

        return self::$executor;
    }
}
