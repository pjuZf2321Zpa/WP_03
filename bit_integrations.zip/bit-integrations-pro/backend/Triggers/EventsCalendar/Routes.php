<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Core\Util\Route;
use BitApps\IntegrationsPro\Triggers\EventsCalendar\EventsCalendarController;
use BitApps\IntegrationsPro\Triggers\EventsCalendar\EventsCalendarHelper;

Route::get('eventscalendar/get', [EventsCalendarController::class, 'getAll']);
Route::post('eventscalendar/get/form', [EventsCalendarController::class, 'get_a_form']);
Route::get('eventscalendar/get/events', [EventsCalendarHelper::class, 'getAllEvents']);
Route::get('eventscalendar/get/series', [EventsCalendarHelper::class, 'getAllSeries']);
