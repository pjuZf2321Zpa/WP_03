<?php

namespace WPAICG\Chat\Storage\ProLogMethods;

use WPAICG\Chat\Storage\LogCronManager;
use WPAICG\Chat\Storage\LogManager;
use WPAICG\aipkit_dashboard;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Schedules automatic cleanup only while the paid entitlement is active.
 */
function schedule_event(): void
{
    if (!class_exists(aipkit_dashboard::class) || !aipkit_dashboard::is_pro_plan()) {
        LogCronManager::unschedule_event();
        return;
    }
    if (!wp_next_scheduled(LogCronManager::HOOK_NAME)) {
        wp_schedule_event(time(), 'daily', LogCronManager::HOOK_NAME);
    }
}

/**
 * Runs enabled retention cleanup and records the existing last-run marker.
 */
function run_pruning(): void
{
    if (!class_exists(aipkit_dashboard::class) || !aipkit_dashboard::is_pro_plan()) {
        LogCronManager::unschedule_event();
        return;
    }
    $log_settings = get_option('aipkit_log_settings', [
        'enable_pruning' => false,
        'retention_period_days' => 90,
    ]);
    $enable_pruning = (bool) ($log_settings['enable_pruning'] ?? false);
    $retention_period_days = (float) ($log_settings['retention_period_days'] ?? 90);
    if ($enable_pruning && $retention_period_days > 0) {
        $log_manager = new LogManager();
        $log_manager->prune_logs($retention_period_days);
        update_option('aipkit_log_pruning_last_run', current_time('mysql', true), 'no');
    }
}

/**
 * Deletes conversation rows older than the retention period.
 *
 * @return int|false
 */
function prune_logs(\wpdb $wpdb, string $table_name, float $days)
{
    if ($days <= 0 || !class_exists(aipkit_dashboard::class) || !aipkit_dashboard::is_pro_plan()) {
        return 0;
    }
    $timestamp_threshold = time() - (int) ($days * DAY_IN_SECONDS);
    // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter -- LogManager supplies its fixed prefixed custom-table name; the cutoff is prepared. Identifier placeholders require WordPress 6.2, above our 6.0 minimum.
    return $wpdb->query($wpdb->prepare("DELETE FROM {$table_name} WHERE last_message_ts < %d", $timestamp_threshold));
}

/**
 * Adds paid trigger evaluation and action details to the shared message envelope.
 */
function build_trigger_message(array $log_data, array $new_message): array
{
    // Populate trigger_log_details if provided in $log_data
    if (isset($log_data['trigger_log_details']) && is_array($log_data['trigger_log_details'])) {
        $trigger_details = $log_data['trigger_log_details'];
        $sanitized_details = [];
        // Always copy common fields
        $sanitized_details['log_subtype'] = isset($trigger_details['log_subtype']) ? sanitize_key($trigger_details['log_subtype']) : 'unknown';
        $sanitized_details['trigger_id'] = isset($trigger_details['trigger_id']) ? sanitize_key($trigger_details['trigger_id']) : 'unknown';
        $sanitized_details['trigger_name'] = isset($trigger_details['trigger_name']) ? sanitize_text_field($trigger_details['trigger_name']) : 'Unnamed Trigger';
        $sanitized_details['event_name_processed'] = isset($trigger_details['event_name_processed']) ? sanitize_key($trigger_details['event_name_processed']) : 'unknown_event';

        // Subtype-specific fields
        if ($sanitized_details['log_subtype'] === 'trigger_evaluation') {
            $sanitized_details['conditions_met'] = isset($trigger_details['conditions_met']) ? (bool)$trigger_details['conditions_met'] : false;
            if (isset($trigger_details['conditions_summary'])) {
                $sanitized_details['conditions_summary'] = sanitize_text_field($trigger_details['conditions_summary']);
            }
        } elseif ($sanitized_details['log_subtype'] === 'action_execution_start') {
            $sanitized_details['action_type'] = isset($trigger_details['action_type']) ? sanitize_key($trigger_details['action_type']) : 'unknown_action';
            if (isset($trigger_details['action_payload_summary'])) {
                // Keep payload summary as an array/object, it will be JSON encoded later
                $sanitized_details['action_payload_summary'] = $trigger_details['action_payload_summary'];
            }
        } elseif ($sanitized_details['log_subtype'] === 'action_execution_result') {
            $sanitized_details['action_type'] = isset($trigger_details['action_type']) ? sanitize_key($trigger_details['action_type']) : 'unknown_action';
            $sanitized_details['status'] = isset($trigger_details['status']) ? sanitize_key($trigger_details['status']) : 'unknown';
            if (isset($trigger_details['result_summary'])) {
                $sanitized_details['result_summary'] = sanitize_text_field($trigger_details['result_summary']);
            }
            if (isset($trigger_details['error_details'])) {
                $sanitized_details['error_details'] = sanitize_text_field($trigger_details['error_details']);
            }
        } elseif ($sanitized_details['log_subtype'] === 'form_submission_stored') {
            if (isset($trigger_details['form_id'])) {
                $sanitized_details['form_id'] = sanitize_text_field($trigger_details['form_id']);
            }
            if (isset($trigger_details['submitted_data_snapshot'])) {
                // submitted_data_snapshot is an array, it will be JSON encoded by the logger.
                // No complex sanitization needed here as it's structured data for logging.
                $sanitized_details['submitted_data_snapshot'] = $trigger_details['submitted_data_snapshot'];
            }
        }
        $new_message['trigger_log_details'] = $sanitized_details;
    }
    return $new_message;
}
