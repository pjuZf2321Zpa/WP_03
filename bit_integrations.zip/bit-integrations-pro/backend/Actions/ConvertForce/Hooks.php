<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Actions\ConvertForce\ConvertForceProHelper;
use BitApps\IntegrationsPro\Config;
use BitApps\IntegrationsPro\Core\Util\Hooks;

Hooks::filter(Config::withFreePrefix('convertforce_create_campaign'), [ConvertForceProHelper::class, 'createCampaign'], 10, 2);
Hooks::filter(Config::withFreePrefix('convertforce_update_campaign'), [ConvertForceProHelper::class, 'updateCampaign'], 10, 2);
Hooks::filter(Config::withFreePrefix('convertforce_update_campaign_status'), [ConvertForceProHelper::class, 'updateCampaignStatus'], 10, 2);
Hooks::filter(Config::withFreePrefix('convertforce_delete_campaign'), [ConvertForceProHelper::class, 'deleteCampaign'], 10, 2);
