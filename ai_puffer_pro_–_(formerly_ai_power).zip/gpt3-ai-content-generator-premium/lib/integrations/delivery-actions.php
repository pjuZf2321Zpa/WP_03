<?php

namespace WPAICG\Lib\Integrations\Logs\Ajax;

use WPAICG\AIPKit_Role_Manager;
use WPAICG\Lib\Integrations\Apps\AIPKit_App_Connections;
use WPAICG\Lib\Integrations\Logs\AIPKit_Recipe_Delivery_Log_Store;
use WPAICG\Lib\Integrations\Recipes\AIPKit_Recipe_Executor;
use WPAICG\Lib\Integrations\Recipes\AIPKit_Recipe_Registry;
use WPAICG\Lib\Integrations\Recipes\AIPKit_Stored_Recipes;
use WPAICG\Lib\Views\Settings\AIPKit_App_Delivery_Issues_View;
use WP_Error;

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

trait AIPKit_Recipe_Delivery_Request_Trait
{
    /**
     * @return bool|\WP_Error
     */
    private function check_permissions()
    {
        if (!check_ajax_referer('aipkit_nonce', '_ajax_nonce', false)) {
            return new WP_Error(
                'nonce_failure',
                __('Security check failed (nonce).', 'gpt3-ai-content-generator'),
                ['status' => 403]
            );
        }

        if (!AIPKit_Role_Manager::user_can_access_module('settings')) {
            return new WP_Error(
                'permission_denied',
                __('You do not have permission to perform this action.', 'gpt3-ai-content-generator'),
                ['status' => 403]
            );
        }

        return true;
    }

    private function send_wp_error(WP_Error $error): void
    {
        $error_data = [
            'message' => $error->get_error_message(),
            'code' => $error->get_error_code(),
        ];

        $details = $error->get_error_data();
        $status_code = is_array($details) && isset($details['status']) ? (int) $details['status'] : 400;
        if (is_array($details) && !empty($details)) {
            $error_data['details'] = $details;
        }

        wp_send_json_error($error_data, $status_code);
    }
}

class AIPKit_Recipe_Delivery_Log_Replay_Ajax_Handler
{
    use AIPKit_Recipe_Delivery_Request_Trait;
    public function handle(): void
    {
        $permission_check = $this->check_permissions();
        if (is_wp_error($permission_check)) {
            $this->send_wp_error($permission_check);
            return;
        }

        // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Verified in check_permissions().
        $attempt_uuid = sanitize_text_field((string) wp_unslash($_POST['attempt_uuid'] ?? ''));
        if ($attempt_uuid === '') {
            $this->send_wp_error(new WP_Error(
                'aipkit_missing_attempt_uuid',
                __('Delivery issue ID is required.', 'gpt3-ai-content-generator'),
                ['status' => 400]
            ));
            return;
        }

        $attempt = AIPKit_Recipe_Delivery_Log_Store::get_attempt_by_uuid($attempt_uuid);
        if (!is_array($attempt) || sanitize_key((string) ($attempt['status'] ?? '')) !== 'failed') {
            $this->send_wp_error(new WP_Error(
                'aipkit_delivery_issue_not_found',
                __('The selected delivery issue is not available for replay.', 'gpt3-ai-content-generator'),
                ['status' => 404]
            ));
            return;
        }

        $event_snapshot = isset($attempt['event_snapshot']) && is_array($attempt['event_snapshot'])
            ? $attempt['event_snapshot']
            : [];
        if (empty($event_snapshot)) {
            $this->send_wp_error(new WP_Error(
                'aipkit_delivery_issue_missing_snapshot',
                __('This delivery issue cannot be replayed because the event snapshot is missing.', 'gpt3-ai-content-generator'),
                ['status' => 400]
            ));
            return;
        }

        $recipe = AIPKit_Stored_Recipes::get_recipe_by_id((string) ($attempt['recipe_id'] ?? ''));
        if (!is_array($recipe) || empty($recipe)) {
            $this->send_wp_error(new WP_Error(
                'aipkit_recipe_missing',
                __('The original recipe no longer exists.', 'gpt3-ai-content-generator'),
                ['status' => 404]
            ));
            return;
        }

        $connection = AIPKit_App_Connections::get_connection_by_id((string) ($recipe['connection_id'] ?? ''));
        if (!is_array($connection) || empty($connection)) {
            $this->send_wp_error(new WP_Error(
                'aipkit_connection_missing',
                __('The recipe connection could not be resolved.', 'gpt3-ai-content-generator'),
                ['status' => 400]
            ));
            return;
        }

        $execution_context = [
            'connection' => $connection,
            'event_context' => [
                'origin' => 'manual_replay',
            ],
            'skip_failure_log' => true,
        ];

        $executor = new AIPKit_Recipe_Executor(new AIPKit_Recipe_Registry());
        $result = $executor->execute($recipe, $event_snapshot, $execution_context);

        if (is_wp_error($result)) {
            do_action(
                'aipkit_native_app_recipe_runtime_failed',
                $result,
                $recipe,
                $execution_context,
                $event_snapshot
            );

            $replacement_attempt_uuid = AIPKit_Recipe_Delivery_Log_Store::log_failed_attempt(
                $recipe,
                $execution_context,
                $event_snapshot,
                $result,
                ['replayed_from_attempt_uuid' => $attempt_uuid]
            );

            AIPKit_Recipe_Delivery_Log_Store::mark_attempt_discarded($attempt_uuid, [
                'resolution' => 'replay_failed',
                'message' => __('Replay was attempted and failed again.', 'gpt3-ai-content-generator'),
                'replacement_attempt_uuid' => is_string($replacement_attempt_uuid) ? $replacement_attempt_uuid : '',
            ]);

            $replacement_attempt = is_string($replacement_attempt_uuid)
                ? AIPKit_Recipe_Delivery_Log_Store::get_attempt_by_uuid($replacement_attempt_uuid)
                : null;

            if (is_array($replacement_attempt)) {
                require_once __DIR__ . '/../views/settings/app-delivery-issues.php';
            }

            // The rule's panel shows the new failure in place of the old one, in the same plain words.
            wp_send_json_success([
                'status' => 'failed',
                'message' => __('Replay failed. A new delivery issue was recorded.', 'gpt3-ai-content-generator'),
                'replacement' => is_array($replacement_attempt)
                    ? AIPKit_App_Delivery_Issues_View::describe($replacement_attempt, AIPKit_App_Connections::get_supported_app_options())
                    : null,
            ]);
            return;
        }

        do_action(
            'aipkit_native_app_recipe_runtime_executed',
            $result,
            $recipe,
            $execution_context,
            $event_snapshot
        );

        AIPKit_Recipe_Delivery_Log_Store::mark_attempt_discarded($attempt_uuid, [
            'resolution' => 'replay_succeeded',
            'message' => __('Replay succeeded and the delivery issue was resolved.', 'gpt3-ai-content-generator'),
        ]);

        wp_send_json_success([
            'status' => 'resolved',
            'message' => __('Replay succeeded. The delivery issue was resolved.', 'gpt3-ai-content-generator'),
        ]);
    }

}

class AIPKit_Recipe_Delivery_Log_Clear_Ajax_Handler
{
    use AIPKit_Recipe_Delivery_Request_Trait;
    public function handle(): void
    {
        $permission_check = $this->check_permissions();
        if (is_wp_error($permission_check)) {
            $this->send_wp_error($permission_check);
            return;
        }

        // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Verified in check_permissions().
        $post_data = wp_unslash($_POST);
        $clear_all = !empty($post_data['clear_all'] ?? '');
        if ($clear_all) {
            $cleared_count = AIPKit_Recipe_Delivery_Log_Store::clear_all_failed_attempts();

            wp_send_json_success([
                'status' => 'cleared',
                'cleared_count' => $cleared_count,
                'message' => $cleared_count > 0
                    ? __('Delivery issues were cleared.', 'gpt3-ai-content-generator')
                    : __('There were no delivery issues to clear.', 'gpt3-ai-content-generator'),
            ]);
            return;
        }

        $attempt_uuid = sanitize_text_field((string) ($post_data['attempt_uuid'] ?? ''));
        if ($attempt_uuid === '') {
            $this->send_wp_error(new WP_Error(
                'aipkit_missing_attempt_uuid',
                __('Delivery issue ID is required.', 'gpt3-ai-content-generator'),
                ['status' => 400]
            ));
            return;
        }

        $attempt = AIPKit_Recipe_Delivery_Log_Store::get_attempt_by_uuid($attempt_uuid);
        if (!is_array($attempt) || sanitize_key((string) ($attempt['status'] ?? '')) !== 'failed') {
            $this->send_wp_error(new WP_Error(
                'aipkit_delivery_issue_not_found',
                __('The selected delivery issue is not available to clear.', 'gpt3-ai-content-generator'),
                ['status' => 404]
            ));
            return;
        }

        if (!AIPKit_Recipe_Delivery_Log_Store::clear_attempt($attempt_uuid)) {
            $this->send_wp_error(new WP_Error(
                'aipkit_delivery_issue_clear_failed',
                __('Failed to clear the selected delivery issue.', 'gpt3-ai-content-generator'),
                ['status' => 500]
            ));
            return;
        }

        wp_send_json_success([
            'status' => 'cleared',
            'message' => __('Delivery issue cleared.', 'gpt3-ai-content-generator'),
        ]);
    }

}
