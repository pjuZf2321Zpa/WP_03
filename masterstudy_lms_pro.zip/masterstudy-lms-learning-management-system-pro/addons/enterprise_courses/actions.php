<?php

/**
 * Admin actions for enterprise groups.
 */

function masterstudy_lms_enterprise_groups_can_access_admin_page() {
	return is_ms_lms_addon_enabled( 'enterprise_courses' ) && current_user_can( 'manage_options' );
}

function masterstudy_lms_enterprise_groups_admin_submenu_items( $items ) {
	if ( ! is_ms_lms_addon_enabled( 'enterprise_courses' ) ) {
		return $items;
	}

	$items['manage_enterprise_groups'] = array(
		'aliases'         => array( 'edit.php?post_type=stm-ent-groups' ),
		'order'           => 160,
		'register'        => true,
		'page_title'      => esc_html__( 'Enterprise Groups', 'masterstudy-lms-learning-management-system-pro' ),
		'menu_title'      => esc_html__( 'Enterprise Groups', 'masterstudy-lms-learning-management-system-pro' ),
		'capability'      => 'manage_options',
		'callback'        => 'masterstudy_lms_render_admin_react_page',
		'access_callback' => 'masterstudy_lms_enterprise_groups_can_access_admin_page',
	);

	return $items;
}
add_filter( 'masterstudy_lms_admin_submenu_items', 'masterstudy_lms_enterprise_groups_admin_submenu_items' );

function masterstudy_lms_enterprise_groups_instructor_react_menu_items( $items ) {
	if ( ! is_ms_lms_addon_enabled( 'enterprise_courses' ) ) {
		return $items;
	}

	$items['manage_enterprise_groups'] = array(
		'page_title' => esc_html__( 'Enterprise Groups', 'masterstudy-lms-learning-management-system-pro' ),
		'menu_title' => esc_html__( 'Enterprise Groups', 'masterstudy-lms-learning-management-system-pro' ),
		'capability' => 'stm_lms_instructor',
		'menu_slug'  => 'manage_enterprise_groups',
		'icon_url'   => 'dashicons-admin-post',
		'position'   => 34,
		'app_slug'   => 'react_enterprise_groups',
	);

	return $items;
}
add_filter( 'masterstudy_lms_instructor_react_menu_items', 'masterstudy_lms_enterprise_groups_instructor_react_menu_items' );
