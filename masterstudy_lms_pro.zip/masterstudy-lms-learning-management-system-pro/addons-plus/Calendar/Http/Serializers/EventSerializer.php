<?php

namespace MasterStudy\Lms\Pro\AddonsPlus\Calendar\Http\Serializers;

use MasterStudy\Lms\Http\Serializers\AbstractSerializer;

final class EventSerializer extends AbstractSerializer {
	public function toArray( $data ): array { // phpcs:ignore WordPress.NamingConventions.ValidFunctionName.MethodNameInvalid
		return array(
			'id'             => (string) ( $data['id'] ?? '' ),
			'title'          => (string) ( $data['title'] ?? '' ),
			'type'           => (string) ( $data['type'] ?? 'available' ),
			'timestamp'      => absint( $data['timestamp'] ?? 0 ),
			'date'           => (string) ( $data['date'] ?? '' ),
			'time'           => (string) ( $data['time'] ?? '' ),
			'formatted_time' => (string) ( $data['formatted_time'] ?? '' ),
			'duration'       => (string) ( $data['duration'] ?? '' ),
			'course'         => (string) ( $data['course'] ?? '' ),
			'location'       => (string) ( $data['location'] ?? '' ),
			'url'            => esc_url_raw( (string) ( $data['url'] ?? '' ) ),
			'course_id'      => absint( $data['course_id'] ?? 0 ),
			'item_id'        => absint( $data['item_id'] ?? 0 ),
			'source'         => (string) ( $data['source'] ?? '' ),
			'status'         => (string) ( $data['status'] ?? 'upcoming' ),
			'is_past'        => ! empty( $data['is_past'] ),
		);
	}
}
