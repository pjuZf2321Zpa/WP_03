<?php

defined('ABSPATH') || exit;

/**
 * Marker interface for brand stubs.
 *
 * When a brand excludes a controller, helper, or model from the build, the
 * brand provides a stub replacement that implements this interface. Tests can
 * detect stubs via is_subclass_of($class, 'MeprBaseStub') and skip accordingly.
 */
interface MeprBaseStub
{
}
