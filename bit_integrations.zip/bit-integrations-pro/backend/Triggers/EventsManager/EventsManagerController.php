<?php

namespace BitApps\IntegrationsPro\Triggers\EventsManager;

use BitApps\IntegrationsPro\Config;

final class EventsManagerController
{
    /**
     * Booking statuses, as Events Manager defines them in EM_Booking::$status_array.
     */
    private const STATUS_PENDING = 0;

    private const STATUS_APPROVED = 1;

    private const STATUS_REJECTED = 2;

    private const STATUS_CANCELLED = 3;

    private const STATUS_AWAITING_ONLINE_PAYMENT = 4;

    private const STATUS_AWAITING_PAYMENT = 5;

    private const STATUS_WAITLIST = 6;

    private const STATUS_WAITLIST_APPROVED = 7;

    private const STATUS_WAITLIST_EXPIRED = 8;

    public static function info()
    {
        return [
            'name'              => 'Events Manager',
            'type'              => 'custom_form_submission',
            'is_active'         => static::isPluginInstalled(),
            'documentation_url' => '#',
            'tutorial_url'      => '#',
            'tasks'             => [
                'action' => 'eventsmanager/get',
                'method' => 'get',
            ],
            'fetch' => [
                'action' => 'trigger/test',
                'method' => 'post',
            ],
            'fetch_remove' => [
                'action' => 'trigger/test/remove',
                'method' => 'post',
            ],
            'isPro' => true
        ];
    }

    public function getAllTasks()
    {
        if (!static::isPluginInstalled()) {
            wp_send_json_error(
                // translators: %s: the name of the required plugin
                \sprintf(__('%s is not installed or activated', 'bit-integrations-pro'), 'Events Manager')
            );
        }

        wp_send_json_success(
            [
                ['form_name' => __('Booking Status Changed (any)', 'bit-integrations-pro'), 'triggered_entity_id' => 'em_booking_status_changed', 'skipPrimaryKey' => true],
                ['form_name' => __('Booking Pending', 'bit-integrations-pro'), 'triggered_entity_id' => 'em_booking_pending', 'skipPrimaryKey' => true],
                ['form_name' => __('Booking Approved', 'bit-integrations-pro'), 'triggered_entity_id' => 'em_booking_approved', 'skipPrimaryKey' => true],
                ['form_name' => __('Booking Rejected', 'bit-integrations-pro'), 'triggered_entity_id' => 'em_booking_rejected', 'skipPrimaryKey' => true],
                ['form_name' => __('Booking Cancelled', 'bit-integrations-pro'), 'triggered_entity_id' => 'em_booking_cancelled', 'skipPrimaryKey' => true],
                ['form_name' => __('Booking Awaiting Payment', 'bit-integrations-pro'), 'triggered_entity_id' => 'em_booking_awaiting_payment', 'skipPrimaryKey' => true],
                ['form_name' => __('Booking Waitlisted', 'bit-integrations-pro'), 'triggered_entity_id' => 'em_booking_waitlisted', 'skipPrimaryKey' => true],
                ['form_name' => __('Waitlist Approved', 'bit-integrations-pro'), 'triggered_entity_id' => 'em_booking_waitlist_approved', 'skipPrimaryKey' => true],
                ['form_name' => __('Waitlist Expired', 'bit-integrations-pro'), 'triggered_entity_id' => 'em_booking_waitlist_expired', 'skipPrimaryKey' => true],
                ['form_name' => __('User Registered for Event', 'bit-integrations-pro'), 'triggered_entity_id' => 'em_booking_added', 'skipPrimaryKey' => true],
            ]
        );
    }

    /**
     * Fires on any booking status transition.
     *
     * @param object $booking      EM_Booking
     * @param array  $statusChange ['status' => int, 'email' => bool, ...]
     *
     * @return null|array
     */
    public static function handleBookingStatusChanged($booking, $statusChange = [])
    {
        if (!static::isBooking($booking)) {
            return;
        }

        return static::flowExecute('em_booking_status_changed', $booking, static::statusOf($statusChange));
    }

    public static function handleBookingPending($booking, $statusChange = [])
    {
        if (!static::isBooking($booking) || !static::hasStatus($statusChange, [self::STATUS_PENDING])) {
            return;
        }

        return static::flowExecute('em_booking_pending', $booking, self::STATUS_PENDING);
    }

    public static function handleBookingApproved($booking, $statusChange = [])
    {
        if (!static::isBooking($booking) || !static::hasStatus($statusChange, [self::STATUS_APPROVED])) {
            return;
        }

        return static::flowExecute('em_booking_approved', $booking, self::STATUS_APPROVED);
    }

    public static function handleBookingRejected($booking, $statusChange = [])
    {
        if (!static::isBooking($booking) || !static::hasStatus($statusChange, [self::STATUS_REJECTED])) {
            return;
        }

        return static::flowExecute('em_booking_rejected', $booking, self::STATUS_REJECTED);
    }

    /**
     * Also covers a user cancelling their own booking — Events Manager routes both
     * through the same status.
     *
     * @param object $booking
     * @param array  $statusChange
     *
     * @return null|array
     */
    public static function handleBookingCancelled($booking, $statusChange = [])
    {
        if (!static::isBooking($booking) || !static::hasStatus($statusChange, [self::STATUS_CANCELLED])) {
            return;
        }

        return static::flowExecute('em_booking_cancelled', $booking, self::STATUS_CANCELLED);
    }

    /**
     * Events Manager has two awaiting-payment states, offline and online, and this
     * trigger covers both.
     *
     * @param object $booking
     * @param array  $statusChange
     *
     * @return null|array
     */
    public static function handleBookingAwaitingPayment($booking, $statusChange = [])
    {
        $statuses = [self::STATUS_AWAITING_ONLINE_PAYMENT, self::STATUS_AWAITING_PAYMENT];

        if (!static::isBooking($booking) || !static::hasStatus($statusChange, $statuses)) {
            return;
        }

        return static::flowExecute('em_booking_awaiting_payment', $booking, static::statusOf($statusChange));
    }

    public static function handleBookingWaitlisted($booking, $statusChange = [])
    {
        if (!static::isBooking($booking) || !static::hasStatus($statusChange, [self::STATUS_WAITLIST])) {
            return;
        }

        return static::flowExecute('em_booking_waitlisted', $booking, self::STATUS_WAITLIST);
    }

    public static function handleWaitlistApproved($booking, $statusChange = [])
    {
        if (!static::isBooking($booking) || !static::hasStatus($statusChange, [self::STATUS_WAITLIST_APPROVED])) {
            return;
        }

        return static::flowExecute('em_booking_waitlist_approved', $booking, self::STATUS_WAITLIST_APPROVED);
    }

    public static function handleWaitlistExpired($booking, $statusChange = [])
    {
        if (!static::isBooking($booking) || !static::hasStatus($statusChange, [self::STATUS_WAITLIST_EXPIRED])) {
            return;
        }

        return static::flowExecute('em_booking_waitlist_expired', $booking, self::STATUS_WAITLIST_EXPIRED);
    }

    /**
     * Fires once when a booking is first created.
     *
     * @param object $booking EM_Booking
     *
     * @return null|array
     */
    public static function handleBookingAdded($booking)
    {
        if (!static::isBooking($booking)) {
            return;
        }

        return static::flowExecute('em_booking_added', $booking, null);
    }

    private static function isBooking($booking)
    {
        // booking_id is included because bookingData() looks the record up by it — a
        // direct property read, which warns on an object that has not been saved yet.
        return \is_object($booking)
            && isset($booking->booking_id, $booking->event_id, $booking->person_id);
    }

    private static function statusOf($statusChange)
    {
        return isset($statusChange['status']) ? (int) $statusChange['status'] : null;
    }

    private static function hasStatus($statusChange, array $expected)
    {
        $status = static::statusOf($statusChange);

        return $status !== null && \in_array($status, $expected, true);
    }

    /**
     * Flat trigger payload for a booking.
     *
     * @param object   $booking
     * @param null|int $status
     *
     * @return array
     */
    private static function bookingData($booking, $status)
    {
        global $wpdb;

        $bookingsTable = $wpdb->prefix . 'em_bookings';
        $eventsTable = $wpdb->prefix . 'em_events';

        $record = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT bookings.booking_id, bookings.event_id, bookings.person_id, bookings.booking_status,
                        bookings.booking_price, bookings.booking_spaces, bookings.booking_comment, bookings.booking_date,
                        events.event_name, events.event_slug, events.post_id, events.location_id,
                        events.event_start_date, events.event_end_date
                 FROM {$bookingsTable} AS bookings
                 LEFT JOIN {$eventsTable} AS events ON bookings.event_id = events.event_id
                 WHERE bookings.booking_id = %d",
                $booking->booking_id
            ),
            ARRAY_A
        );

        if (empty($record)) {
            return [];
        }

        $user = get_userdata($booking->person_id);

        $data = [
            'booking_id'       => $record['booking_id'],
            'booking_status'   => $status === null ? $record['booking_status'] : $status,
            'booking_price'    => $record['booking_price'],
            'booking_spaces'   => $record['booking_spaces'],
            'booking_comment'  => $record['booking_comment'],
            'booking_date'     => $record['booking_date'],
            'event_id'         => $record['post_id'],
            'event_name'       => $record['event_name'],
            'event_slug'       => $record['event_slug'],
            'event_start_date' => $record['event_start_date'],
            'event_end_date'   => $record['event_end_date'],
            'user_id'          => $booking->person_id,
            'user_email'       => $user ? $user->user_email : '',
            'user_login'       => $user ? $user->user_login : '',
            'first_name'       => $user ? $user->first_name : '',
            'last_name'        => $user ? $user->last_name : '',
            'display_name'     => $user ? $user->display_name : '',
        ];

        return array_merge($data, static::ticketData($record['booking_id']), static::venueData($record['location_id']));
    }

    /**
     * Ticket bought with this booking. Flattened rather than nested so the fields are
     * mappable individually.
     *
     * Always returns the full key set. The flow builder learns a trigger's fields from
     * one sampled booking, so a key that appears only when a ticket exists would be
     * unmappable for anyone whose sample happened not to have one.
     *
     * @param int $bookingId
     *
     * @return array
     */
    private static function ticketData($bookingId)
    {
        global $wpdb;

        $ticketBookings = $wpdb->prefix . 'em_tickets_bookings';
        $tickets = $wpdb->prefix . 'em_tickets';

        $ticket = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT tickets.ticket_name, tickets.ticket_description, tickets.ticket_price,
                        ticket_bookings.ticket_booking_spaces, ticket_bookings.ticket_booking_price
                 FROM {$ticketBookings} AS ticket_bookings
                 LEFT JOIN {$tickets} AS tickets ON ticket_bookings.ticket_id = tickets.ticket_id
                 WHERE ticket_bookings.booking_id = %d
                 ORDER BY ticket_bookings.ticket_booking_id DESC
                 LIMIT 1",
                $bookingId
            ),
            ARRAY_A
        );

        return [
            'ticket_name'        => $ticket['ticket_name'] ?? '',
            'ticket_description' => $ticket['ticket_description'] ?? '',
            'ticket_price'       => $ticket['ticket_price'] ?? '',
            'ticket_spaces'      => $ticket['ticket_booking_spaces'] ?? '',
            'ticket_total'       => $ticket['ticket_booking_price'] ?? '',
        ];
    }

    /**
     * Venue the event is held at. Always returns the full key set, for the same reason
     * as ticketData() — an event with no venue must not shrink the field list.
     *
     * @param null|int $locationId
     *
     * @return array
     */
    private static function venueData($locationId)
    {
        $venue = [];

        if (!empty($locationId)) {
            global $wpdb;

            $locations = $wpdb->prefix . 'em_locations';

            $venue = $wpdb->get_row(
                $wpdb->prepare(
                    "SELECT location_name, location_address, location_town, location_state, location_postcode, location_country
                     FROM {$locations} WHERE location_id = %d",
                    $locationId
                ),
                ARRAY_A
            );
        }

        return [
            'venue_name'     => $venue['location_name'] ?? '',
            'venue_address'  => $venue['location_address'] ?? '',
            'venue_town'     => $venue['location_town'] ?? '',
            'venue_state'    => $venue['location_state'] ?? '',
            'venue_postcode' => $venue['location_postcode'] ?? '',
            'venue_country'  => $venue['location_country'] ?? '',
        ];
    }

    /**
     * Takes the booking rather than a built payload: assembling one costs three
     * queries, and every booking status change reaches two handlers, so building it
     * up front would spend six queries on a site with no Events Manager flows at all.
     *
     * @param string   $triggered_entity_id
     * @param object   $booking
     * @param null|int $status
     *
     * @return null|array
     */
    private static function flowExecute($triggered_entity_id, $booking, $status = null)
    {
        $helperClass = bit_integrations_get_class('Core\\Util\\Helper');
        $flowClass = bit_integrations_get_class('Flow\\Flow');

        $flows = $flowClass::exists('EventsManager', $triggered_entity_id);
        $samplePending = get_option(Config::withFreePrefix("{$triggered_entity_id}_test")) !== false;

        if (empty($flows) && !$samplePending) {
            return;
        }

        $formData = $helperClass::prepareFetchFormatFields(static::bookingData($booking, $status));

        if (empty($formData) || !\is_array($formData)) {
            return;
        }

        $helperClass::setTestData(Config::withFreePrefix("{$triggered_entity_id}_test"), array_values($formData));

        if (empty($flows)) {
            return;
        }

        $flowClass::execute('EventsManager', $triggered_entity_id, array_column($formData, 'value', 'name'), $flows);

        return ['type' => 'success'];
    }

    private static function isPluginInstalled()
    {
        return class_exists('EM_Events');
    }
}
