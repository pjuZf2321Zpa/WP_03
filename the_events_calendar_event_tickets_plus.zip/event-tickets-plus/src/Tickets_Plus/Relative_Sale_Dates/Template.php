<?php
/**
 * The admin templates of the Relative Sale Dates feature.
 *
 * @since 6.12.0
 *
 * @package TEC\Tickets_Plus\Relative_Sale_Dates
 */

namespace TEC\Tickets_Plus\Relative_Sale_Dates;

use Tribe__Template as Base_Template;
use Tribe__Tickets_Plus__Main as Tickets_Plus;

/**
 * Renders the admin templates of the Relative Sale Dates feature.
 *
 * @since 6.12.0
 *
 * @package TEC\Tickets_Plus\Relative_Sale_Dates
 */
final class Template extends Base_Template {
	/**
	 * Template constructor.
	 *
	 * @since 6.12.0
	 */
	public function __construct() {
		$this->set_template_origin( Tickets_Plus::instance() );
		$this->set_template_folder( 'src/admin-views/relative-sale-dates' );

		// The templates render Event Tickets' options, whose markup its scripts rely on: a theme copy would drift from it.
		$this->set_template_folder_lookup( false );

		$this->set_template_context_extract( true );
	}
}
