<?php

/**
 * Class CFF_GDPR_Integrations
 *
 * Adds GDPR related workarounds for third-party plugins:
 * https://wordpress.org/plugins/cookie-law-info/
 *
 * @since 2.6/3.17
 */

namespace CustomFacebookFeed;

if (! defined('ABSPATH')) {
	exit;
}

class CFF_GDPR_Integrations
{
	/**
	 * Throttle for automatic re-tests while the resizing features test as broken.
	 */
	public const RETEST_TRANSIENT = 'cff_gdpr_retest_throttle';
	public const RETEST_INTERVAL  = 12 * HOUR_IN_SECONDS;
	public const RETEST_NONCE     = 'cff-gdpr-retest';

	/**
	 * Nothing currently for CFF
	 *
	 * @since 2.6/3.17
	 */
	public static function init()
	{
		add_action('admin_init', array( 'CustomFacebookFeed\CFF_GDPR_Integrations', 'clear_resizing_once' ));
		add_filter('wt_cli_third_party_scripts', array( 'CustomFacebookFeed\CFF_GDPR_Integrations', 'undo_script_blocking' ), 11);
	}

	/**
	 * Prevents changes made to how JavaScript file is added to
	 * pages.
	 *
	 * @param array $blocking
	 *
	 * @return array
	 *
	 * @since 2.6/3.17
	 */
	public static function undo_script_blocking($blocking)
	{
		$options = get_option('cff_style_settings', array());
		if (! CFF_GDPR_Integrations::doing_gdpr($options)) {
			return $blocking;
		}
		remove_filter('wt_cli_third_party_scripts', 'wt_cli_facebook_feed_script');

		return $blocking;
	}

	/**
	 * Whether or not consent plugins that Custom Facebook Feed
	 * is compatible with are active.
	 *
	 * @return bool|string
	 *
	 * @since 2.6/3.17
	 */
	public static function gdpr_plugins_active()
	{
		if ( function_exists( 'WPConsent' ) ) {
			return 'WPConsent by the WPConsent team';
		}
		if ( defined( 'RCB_ROOT_SLUG' ) ) {
			return 'Real Cookie Banner by devowl.io';
		}
		if ( function_exists( 'gdpr_cookie_is_accepted' ) ) {
			return 'GDPR Cookie Compliance by Moove Agency';
		}
		if ( class_exists( 'Cookie_Notice' ) ) {
			return 'Cookie Notice by dFactory';
		}
		if ( function_exists( 'run_cookie_law_info' ) || class_exists( 'Cookie_Law_Info' ) ) {
			return 'GDPR Cookie Consent by WebToffee';
		}
		if ( defined( 'CKY_APP_ASSETS_URL' ) ) {
			return 'CookieYes | GDPR Cookie Consent by CookieYes';
		}
		if ( class_exists( 'Cookiebot_WP' ) ) {
			return 'Cookiebot by Cybot A/S';
		}
		if ( class_exists( 'COMPLIANZ' ) ) {
			return 'Complianz by Really Simple Plugins';
		}
		if (function_exists('BorlabsCookieHelper')  || ( defined('BORLABS_COOKIE_VERSION') && version_compare(BORLABS_COOKIE_VERSION, '3.0', '>=') )) {
			return 'Borlabs Cookie by Borlabs';
		}
		if ( is_admin() && ! empty( $_GET['page'] ) && $_GET['page'] === 'cff-feed-builder' ) {
			return false;
		}

		return false;
	}

	/**
	 * GDPR features can be added automatically, forced enabled,
	 * or forced disabled.
	 *
	 * @param $settings
	 *
	 * @return bool
	 *
	 * @since 2.6/3.17
	 */
	public static function doing_gdpr($settings)
	{
		$gdpr = isset($settings['gdpr']) ? $settings['gdpr'] : 'auto';
		if ($gdpr === 'no') {
			return false;
		}
		if ($gdpr === 'yes') {
			return true;
		}
		return (CFF_GDPR_Integrations::gdpr_plugins_active() !== false);
	}

	/**
	 * If the image resizing and local storage feature isn't working,
	 * CDN images are allowed to be displayed.
	 *
	 * @param $settings
	 *
	 * @return bool
	 *
	 * @since 2.6/3.17
	 */
	public static function blocking_cdn($settings)
	{
		$gdpr = isset($settings['gdpr']) ? $settings['gdpr'] : 'auto';
		if ($gdpr === 'no') {
			return false;
		}
		if ($gdpr === 'yes') {
			return true;
		}
		if (CFF_GDPR_Integrations::gdpr_plugins_active() === false) {
			return false;
		}

		// Under "Automatic" the CDN is blocked whenever the local-copy machinery works. This used
		// to read a one-shot flag written at install time (cff_statuses['gdpr']['from_update_success'])
		// that was never re-evaluated, so a single failed install-time test — or a wiped
		// cff_statuses option — silently disabled blocking forever (SMASH-1638).
		return CFF_GDPR_Integrations::resizing_healthy();
	}

	/**
	 * Whether the image resizing / local storage features currently work.
	 *
	 * Reads the cached test results, and — when they say "broken" — re-runs the tests
	 * at most once per CFF_GDPR_Integrations::RETEST_INTERVAL so the CDN fallback
	 * self-heals once the server issue is fixed, without hammering the image editor
	 * on every page load. The re-test does remote I/O (image editor probe), so it only
	 * runs from admin / cron requests, never inside a visitor's page render.
	 *
	 * @return bool
	 *
	 * @since 4.13.1
	 */
	public static function resizing_healthy()
	{
		if (CFF_GDPR_Integrations::gdpr_tests_successful()) {
			return true;
		}

		// admin-ajax.php also reports is_admin() — and the feed's "Load more" runs there for
		// logged-out visitors — so exclude AJAX; the admin retest paths call the test directly.
		if (! wp_doing_cron() && ( ! is_admin() || wp_doing_ajax() )) {
			return false;
		}
		if (get_transient(CFF_GDPR_Integrations::RETEST_TRANSIENT) !== false) {
			return false;
		}
		set_transient(CFF_GDPR_Integrations::RETEST_TRANSIENT, 1, CFF_GDPR_Integrations::RETEST_INTERVAL);

		return CFF_GDPR_Integrations::gdpr_tests_successful(true);
	}

	/**
	 * True when GDPR is set to "Automatic", a consent plugin is detected, but the CDN is
	 * NOT being blocked because the local-copy features test as broken. Surfaced in admin
	 * so the fallback is never silent.
	 *
	 * @param array $settings Feed / global style settings holding the 'gdpr' key.
	 *
	 * @return bool
	 *
	 * @since 4.13.1
	 */
	public static function cdn_fallback_active($settings)
	{
		$gdpr = isset($settings['gdpr']) ? $settings['gdpr'] : 'auto';
		if ($gdpr !== 'auto') {
			return false;
		}
		if (CFF_GDPR_Integrations::gdpr_plugins_active() === false) {
			return false;
		}

		// Called from admin screens, so this also drives the throttled auto re-test:
		// an admin visiting the plugin pages is what heals a fixed install.
		return ! CFF_GDPR_Integrations::resizing_healthy();
	}

	/**
	 * GDPR features are reliant on the image resizing features
	 *
	 * @param bool $retest
	 *
	 * @return bool
	 *
	 * @since 2.6/3.17
	 */
	public static function gdpr_tests_successful($retest = false)
	{
		$cff_statuses_option = get_option('cff_statuses', array());

		if (
			! isset($cff_statuses_option['gdpr']['image_editor'])
			|| ! isset($cff_statuses_option['gdpr']['upload_dir'])
			|| ! isset($cff_statuses_option['gdpr']['tables'])
			|| $retest
		) {
			$test_image = trailingslashit(CFF_PLUGIN_URL) . 'assets/img/placeholder.png';

			$image_editor = wp_get_image_editor($test_image);

			// not uncommon for the image editor to not work using it this way
			$cff_statuses_option['gdpr']['image_editor'] = false;
			// not uncommon for the image editor to not work using it this way
			if (! is_wp_error($image_editor)) {
				$cff_statuses_option['gdpr']['image_editor'] = true;
			} elseif ( class_exists( '\FacebookFeed\Vendor\Smashballoon\Framework\Packages\Consent\ConsentManager' ) && \FacebookFeed\Vendor\Smashballoon\Framework\Packages\Consent\ConsentManager::is_dsc_enabled() ) {
				// External image-editor probe is consent-gated (phone-home). With
				// consent off, the flag stays false and feeds still render.
				$image_editor = wp_get_image_editor('https://plugin.smashballoon.com/editor-test.png');
				if (! is_wp_error($image_editor)) {
					$cff_statuses_option['gdpr']['image_editor'] = true;
				}
			}

			$upload     = wp_upload_dir();
			$upload_dir = $upload['basedir'];
			$upload_dir = trailingslashit($upload_dir) . CFF_UPLOADS_NAME;
			if (file_exists($upload_dir)) {
				$cff_statuses_option['gdpr']['upload_dir'] = true;
			} else {
				$cff_statuses_option['gdpr']['upload_dir'] = false;
			}

			global $wpdb;
			$table_name = esc_sql($wpdb->prefix . CFF_POSTS_TABLE);
			$cff_statuses_option['gdpr']['tables'] = true;
			if ($wpdb->get_var("show tables like '$table_name'") != $table_name) {
				$cff_statuses_option['gdpr']['tables'] = false;
			}

			$feeds_posts_table_name = esc_sql($wpdb->prefix . CFF_POSTS_TABLE);
			if ($wpdb->get_var("show tables like '$feeds_posts_table_name'") != $feeds_posts_table_name) {
				$cff_statuses_option['gdpr']['tables'] = false;
			}

			$cff_statuses_option['gdpr']['last_tested'] = time();

			update_option('cff_statuses', $cff_statuses_option);
		}
		if ($retest) {
			\cff_main_pro()->cff_error_reporter->add_action_log('Retesting GDPR features.');
		}

		if (
			empty($cff_statuses_option['gdpr']['upload_dir'])
			 || empty($cff_statuses_option['gdpr']['tables'])
			 || empty($cff_statuses_option['gdpr']['image_editor'])
		) {
			return false;
		}

		return true;
	}
	/**
	 * Error message HTML, if any
	 *
	 * @return string
	 *
	 * @since 2.6/3.17
	 */
	public static function gdpr_tests_error_message()
	{
		$cff_statuses_option = get_option('cff_statuses', array());

		$errors = array();
		if (empty($cff_statuses_option['gdpr']['upload_dir'])) {
			$errors[] =  __('A folder for storing resized images was not successfully created.');
		}
		if (empty($cff_statuses_option['gdpr']['tables'])) {
			$errors[] = __('Tables used for storing information about resized images were not successfully created.');
		}
		if (empty($cff_statuses_option['gdpr']['image_editor'])) {
			$errors[] = sprintf(__('An image editor is not available on your server. Facebook Feed is unable to create local resized images. See %sthis FAQ%s for more information'), '<a href="https://smashballoon.com/doc/the-images-in-my-feed-are-missing-or-showing-errors/?facebook&utm_campaign=facebook-pro&utm_source=error-message&utm_medium=docs" target="_blank" rel="noopener noreferrer">', '</a>');
		}

		$errors[] = '<a href="' . esc_url(CFF_GDPR_Integrations::retest_url()) . '" class="button button-secondary">'
			. __('Retest', 'custom-facebook-feed') . '</a>';

		return implode('<br>', $errors);
	}

	/**
	 * Nonce-protected URL that re-runs the GDPR feature tests (handled in CFF_Admin_Notices).
	 *
	 * @return string
	 *
	 * @since 4.13.1
	 */
	public static function retest_url()
	{
		return wp_nonce_url(
			add_query_arg(array( 'cff_gdpr_retest' => '1' ), admin_url('admin.php?page=cff-settings')),
			CFF_GDPR_Integrations::RETEST_NONCE
		);
	}

	/**
	 * Only medium sized images are created unless the GDPR features are enabled.
	 * This clears the resizing tables and resets any caches the first time
	 * the GDPR features are active.
	 *
	 * @since 2.6/3.17
	 */
	public static function clear_resizing_once()
	{
		$cff_statuses_option = get_option('cff_statuses', array());
		$options = get_option('cff_style_settings', array());

		if (
			CFF_GDPR_Integrations::doing_gdpr($options)
			&& ! isset($cff_statuses_option['gdpr']['clear_resizing_once'])
		) {
			$cff_statuses_option['gdpr']['clear_resizing_once'] = true;
			CFF_Resizer::delete_resizing_table_and_images();
			CFF_Resizer::create_resizing_table_and_uploads_folder();
			cff_delete_cache();
			update_option('cff_statuses', $cff_statuses_option);
		}
	}
}
