<?php

namespace FluentCartPro\App\Modules\SavedPaymentMethods\Settings;

use FluentCart\Framework\Support\Arr;

/**
 * Registers the "Saved Payment Methods" merchant setting into the core
 * Store Settings → Cart & Checkout section via the additive store_settings
 * filter trio. No core file is edited.
 *
 * The sanitizer filter is mandatory: SettingsController drops any submitted
 * key that has no registered sanitizer (SettingsController.php:64-70).
 */
class SettingsHandler
{
    const SETTING_KEY = 'enable_saved_payment_methods';

    /**
     * Whether the checkout consent box starts ticked.
     *
     * Off by default and merchant-controlled on purpose. A pre-ticked consent box
     * is not valid consent under the GDPR (Recital 32; CJEU Planet49, C-673/17 —
     * consent requires an affirmative act), so the plugin must not ship it ticked
     * for everyone. A merchant who turns this on is making that call knowingly for
     * their own market, which is a materially different thing.
     */
    const PRECHECK_KEY = 'saved_payment_methods_precheck_consent';

    public function register(): void
    {
        add_filter('fluent_cart/store_settings/values', [$this, 'addDefaultValue'], 10, 2);
        add_filter('fluent_cart/store_settings/fields', [$this, 'addField'], 10, 2);
        add_filter('fluent_cart/store_settings/sanitizer', [$this, 'addSanitizer']);
    }

    public function addDefaultValue($defaults)
    {
        if (!is_array($defaults)) {
            $defaults = [];
        }

        if (!isset($defaults[self::SETTING_KEY])) {
            $defaults[self::SETTING_KEY] = 'no';
        }

        if (!isset($defaults[self::PRECHECK_KEY])) {
            $defaults[self::PRECHECK_KEY] = 'no';
        }

        return $defaults;
    }

    public function addField($fields)
    {
        $schemaPath = 'setting_tabs.schema.cart_and_checkout.schema';
        $schema = Arr::get($fields, $schemaPath);

        if (!is_array($schema)) {
            return $fields;
        }

        $labelHtml = sprintf(
            /* translators: 1: setting label, 2: setting description note */
            '<span class="setting-label">%1$s</span>
                <div class="form-note">%2$s</div>',
            __('Saved Payment Methods', 'fluent-cart-pro'),
            __('Card details are never stored on your site. Your payment provider keeps the card and returns a token.', 'fluent-cart-pro')
        );

        $schema['saved_payment_methods_hr'] = [
            'type'  => 'html',
            'value' => '<hr class="settings-divider">',
        ];

        // Mirrors the User Account Creation Mode row directly above: a short
        // label and note in the first column, and a nested grid spanning the
        // other two that carries each control with its own title and note.
        // Matching that structure is what makes the two rows read as one
        // settings page rather than two different ideas of one.
        $schema['saved_payment_methods_grid'] = [
            'type'            => 'grid',
            'columns'         => [
                'default' => 1,
                'md'      => 3,
            ],
            'disable_nesting' => true,
            'schema'          => [
                'label'                          => [
                    'type'  => 'html',
                    'value' => $labelHtml,
                ],
                'saved_payment_methods_controls' => [
                    'type'            => 'grid',
                    'columns'         => [
                        'default' => 1,
                        'md'      => 1,
                    ],
                    'disable_nesting' => true,
                    'wrapperClass'    => 'col-span-2 flex flex-col gap-4',
                    'schema'          => [
                        self::SETTING_KEY  => [
                            'label' => __('Enable saved payment methods', 'fluent-cart-pro'),
                            'type'  => 'checkbox',
                            'value' => 'no',
                            'note'  => __('Logged-in customers can save a card or PayPal account and reuse it next time.', 'fluent-cart-pro'),
                        ],
                        // Empty-string labels are required for checkboxes, but a
                        // real one is wanted here: the component renders
                        // {{ label }} itself, and FormRenderer deliberately skips
                        // its own label for this type. `false` would print the
                        // literal text "false".
                        self::PRECHECK_KEY => [
                            'label'      => __('Pre-select it at checkout', 'fluent-cart-pro'),
                            'type'       => 'checkbox',
                            'value'      => 'no',
                            'note'       => __('Ticks the save box for customers, who can still clear it. Leave off for the EU and UK, where consent must be given rather than withdrawn.', 'fluent-cart-pro'),
                            // Hidden until the feature above is on — on its own it
                            // controls nothing, and a live-looking control that
                            // does nothing is worse than an absent one.
                            // FormModel::isVisible() evaluates this; with
                            // disable_nesting the sibling key resolves straight
                            // against the flat settings values.
                            'conditions' => [
                                [
                                    'key'      => self::SETTING_KEY,
                                    'operator' => '==',
                                    'value'    => 'yes',
                                ],
                            ],
                        ],
                    ],
                ],
            ],
        ];

        Arr::set($fields, $schemaPath, $schema);

        return $fields;
    }

    public function addSanitizer($sanitizers)
    {
        if (!is_array($sanitizers)) {
            $sanitizers = [];
        }

        $sanitizers[self::SETTING_KEY] = 'sanitize_text_field';
        // Mandatory: SettingsController drops any submitted key with no
        // registered sanitizer, so without this the toggle would never save.
        $sanitizers[self::PRECHECK_KEY] = 'sanitize_text_field';

        return $sanitizers;
    }
}
