<?php

namespace MasterStudy\Lms\Pro\addons\google_classrooms\Admin\Http\Controllers;

use MasterStudy\Lms\Http\WpResponseFactory;
use MasterStudy\Lms\Pro\addons\google_classrooms\Admin\Repositories\AuditoryRepository;
use WP_REST_Request;
use WP_REST_Response;

final class GetAuditoryUsersController {
	public function __invoke( int $id, WP_REST_Request $request ): WP_REST_Response {
		$repository = new AuditoryRepository();

		if ( ! $repository->exists( $id ) ) {
			return WpResponseFactory::not_found();
		}

		$users = $repository->get_users( $id );

		return WpResponseFactory::ok_with_data(
			array(
				'users' => $users,
			)
		);
	}
}
