<div id="cff-about" class="cff-about">
	<?php
		CustomFacebookFeed\CFF_View::render('sections.header');
	?>
	<main>
	<?php
		CustomFacebookFeed\CFF_View::render('about.content');
	?>
	</main>
	<?php
		include_once CFF_BUILDER_DIR . 'templates/sections/popup/license-learn-more.php';
		include_once CFF_BUILDER_DIR . 'templates/sections/popup/why-renew-license-popup.php';
	?>


	<div class="sb-notification-ctn" :data-active="notificationElement.shown" :data-type="notificationElement.type">
		<div class="sb-notification-icon" v-html="svgIcons[notificationElement.type+'Notification']"></div>
		<span class="sb-notification-text" v-html="notificationElement.text"></span>
	</div>
</div>