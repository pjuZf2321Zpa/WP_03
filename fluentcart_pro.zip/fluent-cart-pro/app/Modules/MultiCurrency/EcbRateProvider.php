<?php

namespace FluentCartPro\App\Modules\MultiCurrency;

use FluentCart\App\Modules\MultiCurrency\Services\BaseCurrency;
use FluentCart\App\Modules\MultiCurrency\Services\MultiCurrencySettings;
use FluentCart\App\Services\DateTime\DateTime;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Daily exchange rates from the European Central Bank.
 * fluent-cart dev-docs/multi-currency/08-exchange-rates.md, "Sources" and "ECB history".
 *
 * The ECB publishes EUR-based reference rates once per working day. For a
 * store whose base currency is not EUR the rate is a cross rate:
 *   base -> quote = (EUR -> quote) / (EUR -> base)
 *
 * Opt-in: registered as a provider in core's settings and active only when
 * the merchant chooses it. Rows are written through RateStore, so an
 * automated rate that moves more than the sanity band is held back there,
 * and a failed fetch leaves the last good rate in force — never a fallback to 1.
 */
class EcbRateProvider
{
    const SLUG = 'ecb';

    const HOOK = 'fluent_cart_pro/currency/refresh_ecb_rates';

    const FEED_URL = 'https://www.ecb.europa.eu/stats/eurofxref/eurofxref-daily.xml';

    /** Every reference rate since 1999, for the accounting export's dated ECB columns */
    const HISTORY_URL = 'https://www.ecb.europa.eu/stats/eurofxref/eurofxref-hist.xml';

    /** @var string|null the history feed, once downloaded in this request */
    private $historyXml = null;

    /**
     * @var \WP_Error|null a failed history download, kept for the rest of
     * this request so a run over many dates waits out one timeout, not one
     * per date. Never cached beyond the request: the next run asks again.
     */
    private $historyError = null;

    public function register(): void
    {
        // Needs core with multi-currency
        if (!class_exists(MultiCurrencySettings::class)) {
            return;
        }

        add_filter('fluent_cart/currency/rate_providers', [$this, 'addProvider']);
        add_filter('fluent_cart/currency/rate_provider_notes', [$this, 'addNote']);
        add_action('fluent_cart/currency/settings_saved', [$this, 'onSettingsSaved']);
        add_action(self::HOOK, [$this, 'refresh']);
        add_action('admin_init', [$this, 'syncSchedule']);

        // Action Scheduler fails a job whose callback is gone every time it
        // runs, so the daily refresh leaves with Pro
        if (defined('FLUENTCART_PRO_PLUGIN_FILE_PATH')) {
            register_deactivation_hook(FLUENTCART_PRO_PLUGIN_FILE_PATH, [$this, 'unschedule']);
        }

        // Dated rates for the accounting export's ECB columns
        add_filter('fluent_cart/currency/historical_rate', [$this, 'historicalRate'], 10, 2);
    }

    /**
     * base -> quote on $context['date'], or the latest earlier publication
     * within a week (the ECB publishes on working days only).
     *
     * Contract (consumer: AccountingExportService): an array is the rate, null
     * is "no rate that day" (the cell stays empty), a WP_Error is "the provider
     * could not answer" (the export stops asking for that request). An answer
     * or error from an earlier provider is returned unchanged.
     *
     * @param array|\WP_Error|null $rate
     * @param array $context base, quote, date (Y-m-d)
     * @return array|\WP_Error|null {rate, source}
     */
    public function historicalRate($rate, $context = [])
    {
        if (is_array($rate) || is_wp_error($rate)) {
            return $rate;
        }

        $series = $this->historySeries((string) ($context['base'] ?? ''), (string) ($context['quote'] ?? ''));
        if (is_wp_error($series)) {
            return $series;
        }

        if (!$series) {
            return $rate;
        }

        $day = strtotime((string) ($context['date'] ?? '') . ' 00:00:00 UTC');
        if (!$day) {
            return $rate;
        }

        for ($back = 0; $back < 7; $back++) {
            $date = gmdate('Y-m-d', $day - $back * DAY_IN_SECONDS);
            if (isset($series[$date])) {
                return ['rate' => $series[$date], 'source' => self::SLUG];
            }
        }

        return $rate;
    }

    /**
     * date => base -> quote cross rate for every ECB publication.
     *
     * A parsed feed is cached — an empty series too, as it is the feed's
     * answer that the ECB does not publish one of the two currencies. A
     * failed download or a broken feed is never cached, so the next run
     * asks again.
     *
     * @return array<string, string>|\WP_Error
     */
    private function historySeries(string $base, string $quote)
    {
        $base = strtoupper($base);
        $quote = strtoupper($quote);
        if (!preg_match('/^[A-Z]{3}$/', $base) || !preg_match('/^[A-Z]{3}$/', $quote)) {
            return [];
        }

        $cacheKey = 'fct_ecb_hist_' . $base . '_' . $quote;
        $cached = get_transient($cacheKey);
        // Earlier builds cached a bare array, a failure included: refetch those
        if (is_array($cached) && isset($cached['series']) && is_array($cached['series'])) {
            return $cached['series'];
        }

        $xml = $this->historyFeed();
        if (is_wp_error($xml)) {
            return $xml;
        }

        $series = self::parseHistory($xml, $base, $quote);
        if (is_wp_error($series)) {
            return $series;
        }

        set_transient($cacheKey, ['series' => $series], 12 * HOUR_IN_SECONDS);

        return $series;
    }

    /**
     * The full history feed (several MB), downloaded at most once a request
     * whatever the number of currencies asked about — a failed download
     * too, which is not tried again until the next request.
     *
     * @return string|\WP_Error
     */
    private function historyFeed()
    {
        if ($this->historyXml !== null) {
            return $this->historyXml;
        }
        if ($this->historyError !== null) {
            return $this->historyError;
        }

        $response = wp_remote_get(self::HISTORY_URL, ['timeout' => 30]);
        if (is_wp_error($response)) {
            return $this->historyError = $response;
        }

        $code = (int) wp_remote_retrieve_response_code($response);
        if ($code !== 200) {
            return $this->historyError = new \WP_Error('ecb_http', sprintf('HTTP %d', $code));
        }

        $this->historyXml = (string) wp_remote_retrieve_body($response);

        return $this->historyXml;
    }

    /**
     * Stream the history feed (several MB) keeping only the two currencies
     * needed, then turn each day into a base -> quote cross rate.
     *
     * An empty series means the feed is good but does not publish one of
     * the two currencies. A feed that is not the ECB's, holds no
     * publication, or ends early (a cut download) is a WP_Error — a partial
     * series would silently miss days.
     *
     * @return array<string, string>|\WP_Error date => 12-decimal rate
     */
    public static function parseHistory(string $xml, string $base, string $quote)
    {
        if ($xml === '' || !class_exists('XMLReader')) {
            return new \WP_Error('ecb_parse', 'Empty or unreadable history feed');
        }

        $previous = libxml_use_internal_errors(true);
        libxml_clear_errors();

        $reader = new \XMLReader();
        if (!$reader->XML($xml, null, LIBXML_NONET)) {
            libxml_use_internal_errors($previous);
            return new \WP_Error('ecb_parse', 'Malformed history feed');
        }

        $wanted = array_flip([$base, $quote]);
        $days = [];
        $published = 0;
        $date = null;

        while (@$reader->read()) {
            if ($reader->nodeType !== \XMLReader::ELEMENT || $reader->localName !== 'Cube') {
                continue;
            }

            $time = $reader->getAttribute('time');
            if ($time) {
                $date = $time;
                $published++;
                continue;
            }

            $currency = strtoupper((string) $reader->getAttribute('currency'));
            if ($date && isset($wanted[$currency])) {
                $days[$date][$currency] = (float) $reader->getAttribute('rate');
            }
        }
        $reader->close();

        $broken = false;
        foreach (libxml_get_errors() as $error) {
            if ($error->level >= LIBXML_ERR_ERROR) {
                $broken = true;
                break;
            }
        }
        libxml_clear_errors();
        libxml_use_internal_errors($previous);

        if ($broken) {
            return new \WP_Error('ecb_parse', 'Malformed or truncated history feed');
        }

        if (!$published) {
            return new \WP_Error('ecb_parse', 'No rates in history feed');
        }

        $series = [];
        foreach ($days as $day => $rates) {
            $eurToBase = $base === 'EUR' ? 1.0 : ($rates[$base] ?? 0.0);
            $eurToQuote = $quote === 'EUR' ? 1.0 : ($rates[$quote] ?? 0.0);
            if ($eurToBase > 0 && $eurToQuote > 0) {
                $series[$day] = self::crossRate($eurToBase, $eurToQuote);
            }
        }

        return $series;
    }

    /**
     * @param array $providers
     * @return array
     */
    public function addProvider($providers)
    {
        $providers[self::SLUG] = __('European Central Bank (updated daily)', 'fluent-cart-pro');

        return $providers;
    }

    /**
     * Shown beside the provider in Settings -> Multi-Currency: the source
     * credit the ECB asks for, and its own caveat about using reference
     * rates for transactions.
     *
     * @param array $notes
     * @return array
     */
    public function addNote($notes)
    {
        $notes[self::SLUG] = __('Source: European Central Bank euro foreign exchange reference rates. The ECB publishes them for information purposes only, once per working day (not at weekends or on TARGET holidays), for about 30 currencies, at mid-market rates with no spread. Add a margin to cover what your payment gateway charges on conversion; currencies the ECB does not publish keep their manual rate.', 'fluent-cart-pro');

        return $notes;
    }

    public function isActive(): bool
    {
        return MultiCurrencySettings::isEnabled() && MultiCurrencySettings::rateProvider() === self::SLUG;
    }

    /**
     * @param array $payload ['settings' => array]
     */
    public function onSettingsSaved($payload = []): void
    {
        $this->syncSchedule();

        if ($this->isActive()) {
            $this->refresh();
        }
    }

    /**
     * Keep one daily refresh scheduled while ECB is the provider, none otherwise.
     */
    public function syncSchedule(): void
    {
        if (!function_exists('as_next_scheduled_action')) {
            return;
        }

        $scheduled = as_next_scheduled_action(self::HOOK);

        if ($this->isActive() && !$scheduled) {
            as_schedule_recurring_action(self::nextRunAt(time()), DAY_IN_SECONDS, self::HOOK, [], 'fluent-cart');
        } elseif (!$this->isActive() && $scheduled) {
            $this->unschedule();
        }
    }

    public function unschedule(): void
    {
        if (function_exists('as_unschedule_all_actions')) {
            as_unschedule_all_actions(self::HOOK);
        }
    }

    /**
     * The next 16:00 UTC after $now. The ECB publishes around 16:00 CET
     * (14:00 or 15:00 UTC), so a daily run then picks up that day's rates.
     */
    public static function nextRunAt(int $now): int
    {
        $today = strtotime(gmdate('Y-m-d', $now) . ' 16:00:00 UTC');

        return $today > $now ? $today : $today + DAY_IN_SECONDS;
    }

    /**
     * Fetch the feed and record a rate for every enabled currency.
     *
     * @return array{recorded: string[], skipped: array<string, string>}
     */
    public function refresh(): array
    {
        $report = ['recorded' => [], 'skipped' => []];

        if (!$this->isActive()) {
            return $report;
        }

        $eurRates = $this->fetchEurRates();
        if (is_wp_error($eurRates)) {
            $this->log(sprintf(
                /* translators: %1$s: error message */
                __('ECB exchange rates could not be fetched: %1$s. Prices keep using the last rates.', 'fluent-cart-pro'),
                $eurRates->get_error_message()
            ));
            return $report;
        }

        $base = BaseCurrency::get();
        $eurToBase = $base === 'EUR' ? 1.0 : ($eurRates[$base] ?? null);

        if (!$eurToBase) {
            $this->log(sprintf(
                /* translators: %1$s: currency code */
                __('The ECB does not publish a rate for the base currency %1$s, so ECB rates cannot be used for this store.', 'fluent-cart-pro'),
                $base
            ));
            return $report;
        }

        $effectiveAt = DateTime::gmtNow()->format('Y-m-d H:i:s');

        foreach (MultiCurrencySettings::currencyCodes() as $quote) {
            $eurToQuote = $quote === 'EUR' ? 1.0 : ($eurRates[$quote] ?? null);

            if (!$eurToQuote) {
                $report['skipped'][$quote] = 'not_published';
                continue;
            }

            $row = RateStore::record($quote, self::crossRate($eurToBase, $eurToQuote), self::SLUG, [
                'effective_at' => $effectiveAt,
            ]);

            if (is_wp_error($row)) {
                $report['skipped'][$quote] = $row->get_error_code();
                continue;
            }

            $report['recorded'][] = $quote;
        }

        if ($report['skipped']) {
            $this->log(sprintf(
                /* translators: %1$s: comma-separated currency codes */
                __('ECB rates were not updated for: %1$s. Those currencies keep their previous rate.', 'fluent-cart-pro'),
                implode(', ', array_keys($report['skipped']))
            ));
        }

        return $report;
    }

    /**
     * base -> quote from two EUR-based rates, as a 12-decimal string.
     */
    public static function crossRate(float $eurToBase, float $eurToQuote): string
    {
        return number_format($eurToQuote / $eurToBase, 12, '.', '');
    }

    /**
     * @return array<string, float>|\WP_Error currency => units per 1 EUR
     */
    public function fetchEurRates()
    {
        $response = wp_remote_get(self::FEED_URL, ['timeout' => 15]);

        if (is_wp_error($response)) {
            return $response;
        }

        if ((int) wp_remote_retrieve_response_code($response) !== 200) {
            return new \WP_Error('ecb_http', sprintf('HTTP %d', (int) wp_remote_retrieve_response_code($response)));
        }

        return self::parseFeed((string) wp_remote_retrieve_body($response));
    }

    /**
     * @return array<string, float>|\WP_Error
     */
    public static function parseFeed(string $xml)
    {
        if ($xml === '' || !function_exists('simplexml_load_string')) {
            return new \WP_Error('ecb_parse', 'Empty or unreadable feed');
        }

        $previous = libxml_use_internal_errors(true);
        $document = simplexml_load_string($xml, 'SimpleXMLElement', LIBXML_NONET);
        libxml_use_internal_errors($previous);

        if (!$document) {
            return new \WP_Error('ecb_parse', 'Malformed feed');
        }

        $rates = [];
        foreach ($document->xpath('//*[@currency][@rate]') ?: [] as $cube) {
            $currency = strtoupper((string) $cube['currency']);
            $rate = (float) $cube['rate'];
            if (preg_match('/^[A-Z]{3}$/', $currency) && $rate > 0) {
                $rates[$currency] = $rate;
            }
        }

        return $rates ?: new \WP_Error('ecb_parse', 'No rates in feed');
    }

    private function log(string $message): void
    {
        fluent_cart_add_log(__('ECB exchange rates', 'fluent-cart-pro'), $message, 'warning', [
            'module_name' => 'activity',
            'module_id'   => 0,
        ]);
    }
}
