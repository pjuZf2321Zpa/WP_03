<?php

/**
 * LMFWC    Record Api
 */

namespace BitApps\IntegrationsPro\Actions\LMFWC;

class LMFWCProHelper
{
    public static function updateLicense($state, $finalData, $apiUrl, $integrationDetails, $defaultHeader)
    {
        $httpHelperClass = bit_integrations_get_class('Core\\Util\\HttpHelper');

        if (isset($integrationDetails->selectedStatus) || !empty($integrationDetails->selectedStatus)) {
            $finalData['status'] = $integrationDetails->selectedStatus;
        }
        if (isset($integrationDetails->selectedCustomer) || !empty($integrationDetails->selectedCustomer)) {
            $finalData['user_id'] = $integrationDetails->selectedCustomer;
        }
        if (isset($integrationDetails->selectedOrder) || !empty($integrationDetails->selectedOrder)) {
            $finalData['order_id'] = $integrationDetails->selectedOrder;
        }
        if (isset($integrationDetails->selectedProduct) || !empty($integrationDetails->selectedProduct)) {
            $finalData['product_id'] = $integrationDetails->selectedProduct;
        }

        $apiEndpoint = $apiUrl . '/licenses/' . $integrationDetails->selectedLicense;

        return $httpHelperClass::put($apiEndpoint, wp_json_encode($finalData), $defaultHeader, ['sslverify' => false]);
    }

    public static function activateLicense($state, $apiUrl, $licenseKey, $defaultHeader)
    {
        $httpHelperClass = bit_integrations_get_class('Core\\Util\\HttpHelper');

        $apiEndpoint = $apiUrl . '/licenses/activate/' . $licenseKey;

        return $httpHelperClass::get($apiEndpoint, null, $defaultHeader, ['sslverify' => false]);
    }

    public static function createGenerator($state, $apiUrl, $finalData, $defaultHeader)
    {
        $httpHelperClass = bit_integrations_get_class('Core\\Util\\HttpHelper');

        $apiEndpoint = $apiUrl . '/generators/';

        return $httpHelperClass::post($apiEndpoint, wp_json_encode($finalData), $defaultHeader, ['sslverify' => false]);
    }

    public static function UpdateGenerator($state, $apiUrl, $finalData, $defaultHeader, $id)
    {
        $httpHelperClass = bit_integrations_get_class('Core\\Util\\HttpHelper');

        $apiEndpoint = $apiUrl . '/generators/' . $id;

        return $httpHelperClass::put($apiEndpoint, wp_json_encode($finalData), $defaultHeader, ['sslverify' => false]);
    }

    public static function deactivateLicense($state, $apiUrl, $licenseKey, $defaultHeader, $token = null)
    {
        $httpHelperClass = bit_integrations_get_class('Core\\Util\\HttpHelper');

        if (!empty($token)) {
            $apiEndpoint = $apiUrl . '/licenses/deactivate/' . $licenseKey . '?token=' . $token;
        } else {
            $apiEndpoint = $apiUrl . '/licenses/deactivate/' . $licenseKey;
        }

        return $httpHelperClass::get($apiEndpoint, null, $defaultHeader, ['sslverify' => false]);
    }

    public static function reactivateLicense($state, $apiUrl, $licenseKey, $defaultHeader, $token = null)
    {
        $httpHelperClass = bit_integrations_get_class('Core\\Util\\HttpHelper');

        $apiEndpoint = $apiUrl . '/licenses/activate/' . $licenseKey;
        if (!empty($token)) {
            $apiEndpoint .= '?token=' . $token;
        }

        return $httpHelperClass::get($apiEndpoint, null, $defaultHeader, ['sslverify' => false]);
    }

    public static function deleteLicense($state, $apiUrl, $licenseKey, $defaultHeader)
    {
        $httpHelperClass = bit_integrations_get_class('Core\\Util\\HttpHelper');

        $apiEndpoint = $apiUrl . '/licenses/' . $licenseKey;

        return $httpHelperClass::request($apiEndpoint, 'DELETE', null, $defaultHeader, ['sslverify' => false]);
    }
}
