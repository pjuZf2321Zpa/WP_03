<?php

namespace FluentCartPro\App\Modules\MultiCurrency\Http\Requests;

use FluentCart\Framework\Foundation\RequestGuard;

class CurrencyRateRequest extends RequestGuard
{
    public function rules()
    {
        return [
            'currency' => 'required|sanitizeText|maxLength:10',
            'rate'     => 'required|numeric',
        ];
    }

    public function messages()
    {
        return [
            'currency.required' => esc_html__('Choose the currency this rate is for.', 'fluent-cart-pro'),
            'rate.required'     => esc_html__('Enter an exchange rate.', 'fluent-cart-pro'),
            'rate.numeric'      => esc_html__('An exchange rate must be a number.', 'fluent-cart-pro'),
        ];
    }

    public function sanitize()
    {
        return [
            'currency' => 'sanitize_text_field',
            // kept as a string so the full DECIMAL(24,12) precision survives
            'rate'     => 'sanitize_text_field',
        ];
    }
}
