<?php

namespace WPAICG\Lib\ContentWriter;

use WP_Error;
use WPAICG\Core\AIPKit_AI_Caller;
use WPAICG\Lib\Utils\AIPKit_Google_Credentials_Handler;
use WPAICG\ContentWriter\SEO\AIPKit_Content_Writer_SEO_Config;
use WPAICG\ContentWriter\SEO\AIPKit_Content_Writer_Smart_SEO_Keyword_Resolver;
use WPAICG\ContentWriter\SEO\AIPKit_Content_Writer_Smart_SEO_Keyphrase_Usage;

if (!defined('ABSPATH')) {
    exit;
}

/** Paid Content Writer operations, reached after the shared action verifies access. */
final class Actions
{
    private static function is_pro_plan(): bool
    {
        return class_exists('\\WPAICG\\aipkit_dashboard') && \WPAICG\aipkit_dashboard::is_pro_plan();
    }

    private static function pro_error(): WP_Error
    {
        return new WP_Error('pro_feature_required', __('This generation mode is a Pro feature.', 'gpt3-ai-content-generator'), ['status' => 403]);
    }

    public static function maybe_update_gsheets_row_status_logic(array $settings, string $status_prefix)
    {
        $generation_mode = isset($settings['cw_generation_mode'])
            ? sanitize_key((string) $settings['cw_generation_mode'])
            : '';

        if ($generation_mode !== 'gsheets') {
            return true;
        }

        if (!self::is_pro_plan()) {
            return self::pro_error();
        }

        $sheet_id = isset($settings['gsheets_sheet_id'])
            ? sanitize_text_field((string) $settings['gsheets_sheet_id'])
            : '';
        $row_index = isset($settings['gsheets_row_index'])
            ? absint($settings['gsheets_row_index'])
            : 0;

        if ($sheet_id === '' || $row_index <= 0) {
            return new WP_Error(
                'missing_gsheets_status_context',
                __('Google Sheets status update is missing the sheet ID or row index.', 'gpt3-ai-content-generator')
            );
        }

        if (!class_exists(AIPKit_Google_Credentials_Handler::class)) {
            return new WP_Error(
                'gsheets_credentials_handler_missing',
                __('Google Sheets credentials handler is unavailable.', 'gpt3-ai-content-generator')
            );
        }

        $credentials = AIPKit_Google_Credentials_Handler::process_credentials($settings['gsheets_credentials'] ?? null);
        if (!is_array($credentials) || empty($credentials['private_key']) || empty($credentials['client_email'])) {
            return new WP_Error(
                'invalid_gsheets_status_credentials',
                __('Google Sheets status update is missing valid service account credentials.', 'gpt3-ai-content-generator')
            );
        }

        if (!class_exists(AIPKit_Google_Sheets_Parser::class)) {
            return new WP_Error(
                'gsheets_parser_missing',
                __('Google Sheets parser component is missing.', 'gpt3-ai-content-generator')
            );
        }

        try {
            $sheets_parser = new AIPKit_Google_Sheets_Parser($credentials);
            $status_text = trim($status_prefix) . ' ' . current_time('mysql');

            return $sheets_parser->update_row_status($sheet_id, $row_index, $status_text);
        } catch (\Exception $e) {
            return new WP_Error(
                'gsheets_status_update_exception',
                sprintf(
                    /* translators: %s: Exception message. */
                    __('Failed to update Google Sheets status: %s', 'gpt3-ai-content-generator'),
                    $e->getMessage()
                )
            );
        }
    }

    public static function resolve_smart_seo_keywords_logic(array $validated_params, ?AIPKit_AI_Caller $ai_caller, array $context = []): array
    {
        $source = '';
        $keywords = '';

        if (!empty($validated_params['inline_keywords'])) {
            $source = 'inline';
            $keywords = (string) $validated_params['inline_keywords'];
        } elseif (!empty($validated_params['content_keywords'])) {
            $source = 'global';
            $keywords = (string) $validated_params['content_keywords'];
        }

        if ($source === '' || trim($keywords) === '' || !$ai_caller) {
            return [
                'params' => $validated_params,
                'resolution' => [],
            ];
        }

        self::load_smart_seo_keyword_resolver_logic();
        if (
            !class_exists(AIPKit_Content_Writer_SEO_Config::class)
            || !AIPKit_Content_Writer_SEO_Config::is_enabled($validated_params)
            || !class_exists(AIPKit_Content_Writer_Smart_SEO_Keyword_Resolver::class)
        ) {
            return [
                'params' => $validated_params,
                'resolution' => [],
            ];
        }

        $resolver = new AIPKit_Content_Writer_Smart_SEO_Keyword_Resolver();
        $resolver_context = array_merge([
            'ai_provider' => $validated_params['provider'] ?? $validated_params['ai_provider'] ?? '',
            'ai_model' => $validated_params['model'] ?? $validated_params['ai_model'] ?? '',
            'topic' => $validated_params['content_title'] ?? '',
            'title' => $validated_params['content_title'] ?? '',
            'keywords' => $keywords,
        ], $context);

        $result = $resolver->maybe_resolve_keywords($keywords, $validated_params, $ai_caller, $resolver_context);
        if (empty($result['changed'])) {
            return [
                'params' => $validated_params,
                'resolution' => $result,
            ];
        }

        $resolved_keywords = sanitize_text_field((string) ($result['keywords'] ?? $keywords));
        if ($source === 'inline') {
            $validated_params['inline_keywords'] = $resolved_keywords;
        } else {
            $validated_params['content_keywords'] = $resolved_keywords;
        }

        $result['source'] = $source;
        $result['resolved_content_title'] = self::build_resolved_content_title_logic(
            (string) ($validated_params['content_title'] ?? ''),
            $resolved_keywords,
            $source
        );

        return [
            'params' => $validated_params,
            'resolution' => $result,
        ];
    }

    private static function load_smart_seo_keyword_resolver_logic(): void
    {
        if (
            class_exists(AIPKit_Content_Writer_Smart_SEO_Keyword_Resolver::class)
            && class_exists(AIPKit_Content_Writer_Smart_SEO_Keyphrase_Usage::class)
        ) {
            return;
        }

        if (!defined('WPAICG_LIB_DIR')) {
            return;
        }

        $loader_class = '\\WPAICG\\Lib\\DependencyLoaders\\Smart_SEO_Dependencies_Loader';
        $loader_path = WPAICG_LIB_DIR . 'dependencies.php';
        if (!class_exists($loader_class) && file_exists($loader_path)) {
            require_once $loader_path;
        }

        if (class_exists($loader_class)) {
            $loader_class::load();
        }
    }

    private static function build_resolved_content_title_logic(string $topic, string $resolved_keywords, string $source): string
    {
        $topic = trim($topic);
        $resolved_keywords = trim($resolved_keywords);

        if ($source !== 'inline' || $resolved_keywords === '') {
            return $topic;
        }

        return $topic !== '' ? $topic . ' | ' . $resolved_keywords : $resolved_keywords;
    }

    /** Verifies access before creating a Google Sheets automation. */
    public static function verify_gsheets_task(array $settings)
    {
        if (!self::is_pro_plan()) {
            return self::pro_error();
        }
        if (!class_exists(AIPKit_Google_Sheets_Parser::class)) {
            return new WP_Error('gsheets_pro_feature_missing', __('Google Sheets integration is a Pro feature or its components are missing.', 'gpt3-ai-content-generator'));
        }
        $sheet_id = $settings['gsheets_sheet_id'] ?? '';
        $credentials_json = $settings['gsheets_credentials'] ?? '';
        if (empty($sheet_id) || empty($credentials_json)) {
            return new WP_Error('missing_gsheets_info', __('Google Sheet ID and Credentials are required.', 'gpt3-ai-content-generator'));
        }
        try {
            $credentials_array = json_decode($credentials_json, true);
            if (json_last_error() !== JSON_ERROR_NONE || !is_array($credentials_array)) {
                throw new \Exception('Invalid JSON format for Google credentials.');
            }
            $sheets_parser = new AIPKit_Google_Sheets_Parser($credentials_array);
            return $sheets_parser->verify_access($sheet_id);
        } catch (\Exception $e) {
            return new WP_Error('gsheets_parser_error', 'Failed to process Google Sheet: ' . $e->getMessage());
        }
    }

    /** Resolves a generated keyphrase for both standard generation and the keyword action. */
    public static function resolve_generated_keyword(string $keyword, array $config, ?AIPKit_AI_Caller $ai_caller, array $context): array
    {
        if (!$ai_caller) {
            return [];
        }
        self::load_smart_seo_keyword_resolver_logic();
        if (!class_exists(AIPKit_Content_Writer_Smart_SEO_Keyword_Resolver::class)) {
            return [];
        }
        $resolver = new AIPKit_Content_Writer_Smart_SEO_Keyword_Resolver();
        $resolution = $resolver->maybe_resolve_keyword($keyword, $config, $ai_caller, $context);
        if (!empty($resolution['changed'])) {
            $resolution['source'] = 'generated';
            $resolution['resolved_content_title'] = $context['title'] ?? '';
        }
        return $resolution;
    }
}
