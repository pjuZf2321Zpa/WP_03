<?php
/**
 * Paid chatbot request helpers, loaded by the Pro composition root.
 * Existing namespaces are retained for request-helper compatibility.
 */

namespace WPAICG\Chat\Core\AIService\GenerateResponse;

use WP_Error;
use WPAICG\Chat\Storage\LogStorage;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Handles logging and trigger dispatch for AI call errors.
 *
 * @param WP_Error $ai_call_error_result The WP_Error object from the AI call.
 * @param bool $triggers_enabled Whether triggers are enabled.
 * @param \WPAICG\Chat\Storage\LogStorage|null $log_storage_for_triggers Instance of LogStorage for triggers.
 * @param array $base_log_data Base log data (may be empty if not passed down).
 * @param string $main_provider The main AI provider.
 * @param string $model The selected AI model.
 * @param int|null $bot_id The ID of the bot.
 */
function handle_ai_call_error_logic(
    WP_Error $ai_call_error_result,
    bool $triggers_enabled,
    ?LogStorage $log_storage_for_triggers,
    array $base_log_data, // This might be empty depending on the orchestrator
    string $main_provider,
    string $model,
    ?int $bot_id
): void {

    $trigger_storage_class = '\WPAICG\Lib\Chat\Triggers\AIPKit_Trigger_Storage';
    $trigger_manager_class = '\WPAICG\Lib\Chat\Triggers\AIPKit_Trigger_Manager';

    if ($triggers_enabled && class_exists($trigger_manager_class) && class_exists($trigger_storage_class)) {
        // Only proceed if log storage is available for the trigger manager
        if ($log_storage_for_triggers) {
            $error_data_from_caller = $ai_call_error_result->get_error_data() ?? [];
            $error_event_context = [
                'error_code'    => $ai_call_error_result->get_error_code(),
                'error_message' => $ai_call_error_result->get_error_message(),
                'bot_id'        => $bot_id ?? ($base_log_data['bot_id'] ?? null),
                'user_id'       => $base_log_data['user_id'] ?? null,
                'session_id'    => $base_log_data['session_id'] ?? null,
                'module'        => 'chat_ai_service',
                'operation'     => 'make_standard_call_in_generate_response',
                'failed_provider' => $error_data_from_caller['provider'] ?? $main_provider,
                'failed_model'    => $error_data_from_caller['model'] ?? $model,
                'status_code'   => $error_data_from_caller['status_code'] ?? null,
            ];
            $trigger_storage = new $trigger_storage_class();
            $trigger_manager = new $trigger_manager_class($trigger_storage, $log_storage_for_triggers);
            $trigger_manager->process_event($bot_id ?? 0, 'system_error_occurred', $error_event_context);
        }
    }
}

namespace WPAICG\Chat\Core\AIService\GenerateResponse\AiParams;

use WPAICG\Core\AIPKit_OpenAI_Reasoning;

/**
 * Apply Ollama thinking controls using the existing reasoning setting.
 *
 * The provider strategy maps this normalized effort into Ollama's `think`
 * payload shape, including GPT-OSS level-based values.
 *
 * @param array<string, mixed> $final_ai_params
 * @param array<string, mixed> $bot_settings
 * @return void
 */
function apply_ollama_thinking_logic(array &$final_ai_params, array $bot_settings): void
{
    $reasoning_effort = AIPKit_OpenAI_Reasoning::sanitize_effort($bot_settings['reasoning_effort'] ?? '');
    if ($reasoning_effort === '' || $reasoning_effort === 'none') {
        return;
    }

    $final_ai_params['reasoning'] = ['effort' => $reasoning_effort];
}

/**
 * Attach the temporary document uploaded through the paid Claude Files handler.
 */
function apply_claude_file_context_logic(array &$final_ai_params, array $bot_settings, ?string $frontend_active_claude_file_id): void
{
    $vector_store_provider = sanitize_key((string) ($bot_settings['vector_store_provider'] ?? ''));
    $claude_file_id = sanitize_text_field((string) $frontend_active_claude_file_id);
    if (
        $vector_store_provider === 'claude_files' &&
        $claude_file_id !== '' &&
        preg_match('/^file_[a-zA-Z0-9_-]+$/', $claude_file_id)
    ) {
        $final_ai_params['claude_file_ids'] = [$claude_file_id];
    }
}
