<?php
/**
 * Paid automation content-writing enrichment and source completion.
 */
namespace WPAICG\Lib\Automations;

use WPAICG\Core\AIPKit_AI_Caller;
use WPAICG\ContentWriter\AIPKit_Content_Writer_Output_Cleaner;
use WPAICG\ContentWriter\SEO\AIPKit_Content_Writer_Smart_SEO_Keyword_Resolver;
use WPAICG\ContentWriter\SEO\AIPKit_Content_Writer_Smart_SEO_Service;
use function WPAICG\ContentWriter\Ajax\Actions\Shared\merge_smart_seo_usage_logic;

if (!defined('ABSPATH')) {
    exit;
}

class ContentWriting {
    public static function resolve_keywords(array $item_config, AIPKit_AI_Caller $ai_caller, array $context = []): array
    {
        $source = '';
        $keywords = '';
        if (!empty($item_config['inline_keywords'])) {
            $source = 'inline';
            $keywords = (string) $item_config['inline_keywords'];
        } elseif (!empty($item_config['content_keywords'])) {
            $source = 'global';
            $keywords = (string) $item_config['content_keywords'];
        }

        if ($source === '' || trim($keywords) === '' || !class_exists(AIPKit_Content_Writer_Smart_SEO_Keyword_Resolver::class)) {
            return [
                'config' => $item_config,
                'resolution' => [],
            ];
        }

        $resolver = new AIPKit_Content_Writer_Smart_SEO_Keyword_Resolver();
        $result = $resolver->maybe_resolve_keywords($keywords, $item_config, $ai_caller, array_merge([
            'ai_provider' => $item_config['ai_provider'] ?? '',
            'ai_model' => $item_config['ai_model'] ?? '',
            'topic' => $item_config['content_title'] ?? '',
            'title' => $item_config['content_title'] ?? '',
            'keywords' => $keywords,
        ], $context));

        if (empty($result['changed'])) {
            return [
                'config' => $item_config,
                'resolution' => $result,
            ];
        }

        $resolved_keywords = sanitize_text_field((string) ($result['keywords'] ?? $keywords));
        if ($source === 'inline') {
            $item_config['inline_keywords'] = $resolved_keywords;
        } else {
            $item_config['content_keywords'] = $resolved_keywords;
        }

        $result['source'] = $source;
        $result['resolved_content_title'] = $source === 'inline' && $resolved_keywords !== ''
            ? trim((string) ($item_config['content_title'] ?? '')) . ' | ' . $resolved_keywords
            : trim((string) ($item_config['content_title'] ?? ''));

        return [
            'config' => $item_config,
            'resolution' => $result,
        ];
    }

    public static function resolve_generated_keyword(array $item_config, AIPKit_AI_Caller $ai_caller, string $final_title, string $content_summary, &$focus_keyword, &$final_keywords, &$keyword_usage, &$smart_seo_keyword_resolution): void
    {
        if (class_exists(AIPKit_Content_Writer_Smart_SEO_Keyword_Resolver::class)) {
            $keyword_resolver = new AIPKit_Content_Writer_Smart_SEO_Keyword_Resolver();
            $keyword_resolution = $keyword_resolver->maybe_resolve_keyword(
                $focus_keyword,
                $item_config,
                $ai_caller,
                [
                    'ai_provider' => $item_config['ai_provider'] ?? '',
                    'ai_model' => $item_config['ai_model'] ?? '',
                    'topic' => $item_config['content_title'] ?? $final_title,
                    'title' => $final_title,
                    'content_summary' => $content_summary,
                ]
            );
            if (!empty($keyword_resolution['changed'])) {
                $focus_keyword = (string) $keyword_resolution['keyword'];
                $final_keywords = $focus_keyword;
                $keyword_usage = merge_smart_seo_usage_logic($keyword_usage, $keyword_resolution['usage'] ?? null);
                $keyword_resolution['source'] = 'generated';
                $keyword_resolution['resolved_content_title'] = $final_title;
                $smart_seo_keyword_resolution = $keyword_resolution;
            }
        }
    }

    public static function improve_draft(array &$item_config, AIPKit_AI_Caller $ai_caller, array $state): array
    {
        [
            'final_title' => $final_title,
            'generated_content' => $generated_content,
            'meta_description' => $meta_description,
            'focus_keyword' => $focus_keyword,
            'excerpt' => $excerpt,
            'tags' => $tags,
            'image_data' => $image_data,
        ] = $state;
        $smart_seo_result = null;
        $smart_seo_usage = null;
        $smart_seo_warning = null;
        if (($item_config['seo_score_improvement_enabled'] ?? '0') === '1') {
            if (class_exists(AIPKit_Content_Writer_Smart_SEO_Service::class)) {
                $smart_seo_service = new AIPKit_Content_Writer_Smart_SEO_Service();
                $smart_seo_draft = [
                    'title' => $final_title,
                    'content' => $generated_content,
                    'content_format' => 'markdown',
                    'meta_description' => $meta_description ?? '',
                    'focus_keyword' => $focus_keyword ?? '',
                    'excerpt' => $excerpt ?? '',
                    'tags' => $tags ?? '',
                    'slug' => '',
                    'post_type' => $item_config['post_type'] ?? 'post',
                    'image_data' => $image_data ?? [],
                ];
                $smart_seo_run = $smart_seo_service->run(
                    $smart_seo_draft,
                    $item_config,
                    $ai_caller,
                    [
                        'ai_provider' => $item_config['ai_provider'] ?? '',
                        'ai_model' => $item_config['ai_model'] ?? '',
                        'topic' => $item_config['content_title'] ?? $final_title,
                        'keywords' => $item_config['content_keywords'] ?? '',
                        'source_url' => $item_config['source_url'] ?? '',
                        'content_format' => 'markdown',
                        'image_data' => $image_data ?? [],
                    ]
                );

                if (is_wp_error($smart_seo_run)) {
                    $smart_seo_warning = $smart_seo_run->get_error_message();
                } elseif (!empty($smart_seo_run['skipped'])) {
                    if (($smart_seo_run['skip_reason'] ?? '') === 'pro_required') {
                        $smart_seo_warning = __('Smart SEO skipped because the Pro plan is not active.', 'gpt3-ai-content-generator');
                    }
                } else {
                    $smart_seo_result = $smart_seo_run;
                    $smart_seo_usage = $smart_seo_run['usage'] ?? null;
                    $improved_draft = isset($smart_seo_run['draft']) && is_array($smart_seo_run['draft']) ? $smart_seo_run['draft'] : [];

                    if (!empty($improved_draft['title'])) {
                        $final_title = (string) $improved_draft['title'];
                    }
                    if (!empty($improved_draft['content_html'])) {
                        $generated_content = (string) $improved_draft['content_html'];
                        $item_config['content_is_html'] = '1';
                        $item_config['aipkit_content_is_html'] = '1';
                    } elseif (!empty($improved_draft['content'])) {
                        $generated_content = (string) $improved_draft['content'];
                        $item_config['content_is_html'] = '1';
                        $item_config['aipkit_content_is_html'] = '1';
                    }
                    if (!empty($improved_draft['meta_description'])) {
                        $meta_description = AIPKit_Content_Writer_Output_Cleaner::clean_meta_description((string) $improved_draft['meta_description']);
                    }
                    if (!empty($improved_draft['focus_keyword'])) {
                        $focus_keyword = (string) $improved_draft['focus_keyword'];
                    }
                    if (!empty($improved_draft['excerpt'])) {
                        $excerpt = (string) $improved_draft['excerpt'];
                    }
                    if (!empty($improved_draft['tags'])) {
                        $tags = (string) $improved_draft['tags'];
                    }
                    if (!empty($improved_draft['slug'])) {
                        $item_config['smart_seo_slug'] = (string) $improved_draft['slug'];
                    }
                }
            } else {
                $smart_seo_warning = __('Smart SEO runtime is unavailable.', 'gpt3-ai-content-generator');
            }
        }
        return compact('final_title', 'generated_content', 'meta_description', 'focus_keyword', 'excerpt', 'tags', 'smart_seo_result', 'smart_seo_usage', 'smart_seo_warning');
    }

    public static function record_rss_item(array $item_config): void
    {
        if (isset($item_config['rss_item_guid']) && !empty($item_config['rss_item_guid']) && isset($item_config['task_id'])) {
            global $wpdb;
            $history_table_name = $wpdb->prefix . 'aipkit_rss_history';
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Reason: Direct insert to a custom table. Caches will be invalidated.
            $wpdb->insert(
                $history_table_name,
                [
                    'task_id'   => absint($item_config['task_id']),
                    'item_guid' => $item_config['rss_item_guid'],
                ],
                ['%d', '%s']
            );
        }
    }

    public static function mark_sheet_row_processed(array $item_config): void
    {
        if (isset($item_config['cw_generation_mode']) && $item_config['cw_generation_mode'] === 'gsheets' &&
            isset($item_config['gsheets_row_index']) && isset($item_config['gsheets_sheet_id'])) {
            if (class_exists('\WPAICG\Lib\ContentWriter\AIPKit_Google_Sheets_Parser')) {
                try {
                    $credentials_array = $item_config['gsheets_credentials'] ?? [];
                    if (!empty($credentials_array)) {
                        $sheets_parser = new \WPAICG\Lib\ContentWriter\AIPKit_Google_Sheets_Parser($credentials_array);
                        $status_to_write = 'Processed on ' . current_time('mysql');
                        $sheets_parser->update_row_status(
                            $item_config['gsheets_sheet_id'],
                            $item_config['gsheets_row_index'],
                            $status_to_write
                        );
                    }
                } catch (\Exception $e) {
                    // Don't fail the whole post generation for this. Just log the error.
                }
            }
        }
    }
}
