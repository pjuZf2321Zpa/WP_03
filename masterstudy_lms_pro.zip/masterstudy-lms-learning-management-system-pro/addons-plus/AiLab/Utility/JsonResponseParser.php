<?php

namespace MasterStudy\Lms\Pro\AddonsPlus\AiLab\Utility;

use Exception;

class JsonResponseParser {
	public static function parse_course_info( string $content, array $expected_keys ): array {
		$decoded = self::decode_json( $content );

		if ( ! is_array( $decoded ) ) {
			throw new Exception( esc_html__( 'AI returned invalid course info format.', 'masterstudy-lms-learning-management-system-pro' ) );
		}

		$result = array();

		foreach ( $expected_keys as $key ) {
			if ( ! array_key_exists( $key, $decoded ) ) {
				continue;
			}

			$normalized_items = self::normalize_string_list( $decoded[ $key ] );

			if ( ! empty( $normalized_items ) ) {
				$result[ $key ] = $normalized_items;
			}
		}

		if ( empty( $result ) ) {
			throw new Exception( esc_html__( 'AI returned empty course info.', 'masterstudy-lms-learning-management-system-pro' ) );
		}

		return $result;
	}

	public static function parse_faq( string $content, int $count ): array {
		$decoded = self::decode_json( $content );

		if ( isset( $decoded['faq'] ) && is_array( $decoded['faq'] ) ) {
			$decoded = $decoded['faq'];
		}

		if ( isset( $decoded['faqs'] ) && is_array( $decoded['faqs'] ) ) {
			$decoded = $decoded['faqs'];
		}

		if ( ! is_array( $decoded ) ) {
			throw new Exception( esc_html__( 'AI returned invalid FAQ format.', 'masterstudy-lms-learning-management-system-pro' ) );
		}

		$result = array();

		foreach ( $decoded as $item ) {
			if ( ! is_array( $item ) ) {
				continue;
			}

			$question = sanitize_text_field( trim( (string) ( $item['question'] ?? '' ) ) );
			$answer   = sanitize_textarea_field( trim( (string) ( $item['answer'] ?? '' ) ) );

			if ( empty( $question ) || empty( $answer ) ) {
				continue;
			}

			$result[] = array(
				'question' => $question,
				'answer'   => $answer,
			);
		}

		if ( empty( $result ) || count( $result ) < max( 1, min( $count, 2 ) ) ) {
			throw new Exception( esc_html__( 'AI returned empty FAQ items.', 'masterstudy-lms-learning-management-system-pro' ) );
		}

		return $result;
	}

	public static function parse_curriculum( string $content ): array {
		$decoded = self::decode_json( $content );

		if ( isset( $decoded['curriculum'] ) && is_array( $decoded['curriculum'] ) ) {
			$decoded = $decoded['curriculum'];
		}

		if ( isset( $decoded['sections'] ) && is_array( $decoded['sections'] ) ) {
			$decoded = $decoded['sections'];
		}

		if ( ! is_array( $decoded ) ) {
			throw new Exception( esc_html__( 'AI returned invalid curriculum format.', 'masterstudy-lms-learning-management-system-pro' ) );
		}

		$result = array();

		foreach ( $decoded as $item ) {
			if ( ! is_array( $item ) ) {
				continue;
			}

			$section   = isset( $item['section'] ) && is_array( $item['section'] ) ? $item['section'] : $item;
			$title     = trim( (string) ( $section['title'] ?? '' ) );
			$materials = array_values(
				array_filter(
					$section['materials'] ?? array(),
					function ( $material ) {
						return is_array( $material ) && '' !== trim( (string) ( $material['title'] ?? '' ) );
					}
				)
			);

			if ( '' === $title || empty( $materials ) ) {
				continue;
			}

			$section['title']     = $title;
			$section['materials'] = $materials;
			$result[]             = $section;
		}

		if ( empty( $result ) ) {
			throw new Exception( esc_html__( 'AI returned empty curriculum.', 'masterstudy-lms-learning-management-system-pro' ) );
		}

		return $result;
	}

	private static function decode_json( string $content ) {
		$content = trim( $content );

		if ( empty( $content ) ) {
			return null;
		}

		$decoded = json_decode( $content, true );

		if ( JSON_ERROR_NONE === json_last_error() ) {
			return $decoded;
		}

		$content = preg_replace( '/^```(?:json)?\s*|\s*```$/i', '', $content );
		$content = trim( (string) $content );

		$decoded = json_decode( $content, true );

		if ( JSON_ERROR_NONE === json_last_error() ) {
			return $decoded;
		}

		foreach ( array( array( '[', ']' ), array( '{', '}' ) ) as $pair ) {
			$candidate = self::extract_json_candidate( $content, $pair[0], $pair[1] );

			if ( null === $candidate ) {
				continue;
			}

			$decoded = json_decode( $candidate, true );

			if ( JSON_ERROR_NONE === json_last_error() ) {
				return $decoded;
			}
		}

		return null;
	}

	private static function extract_json_candidate( string $content, string $start_char, string $end_char ): ?string {
		$start = strpos( $content, $start_char );
		$end   = strrpos( $content, $end_char );

		if ( false === $start || false === $end || $end <= $start ) {
			return null;
		}

		return substr( $content, $start, $end - $start + 1 );
	}

	private static function normalize_string_list( $value ): array {
		if ( is_string( $value ) ) {
			$value = array( $value );
		}

		if ( ! is_array( $value ) ) {
			return array();
		}

		$result = array();

		foreach ( $value as $item ) {
			$item = sanitize_text_field( trim( (string) $item ) );

			if ( '' !== $item ) {
				$result[] = $item;
			}
		}

		return $result;
	}
}
