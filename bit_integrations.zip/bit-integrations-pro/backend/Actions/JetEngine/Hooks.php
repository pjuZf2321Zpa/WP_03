<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Actions\JetEngine\JetEngineRecordHelper;
use BitApps\IntegrationsPro\Config;
use BitApps\IntegrationsPro\Core\Util\Hooks;

// Deprecated since v2.7.8 - use bit_integrations_jet_engine_* hooks instead
if (bit_integrations_version_below('2.7.8')) {
    Hooks::filter('btcbi_jet_engine_create_post_type_actions', [JetEngineRecordHelper::class, 'createPostTypeActions'], 10, 3);
    Hooks::filter('btcbi_jet_engine_create_content_type_actions', [JetEngineRecordHelper::class, 'createContentTypeActions'], 10, 3);
    Hooks::filter('btcbi_jet_engine_create_taxonomy_actions', [JetEngineRecordHelper::class, 'createTaxonomyActions'], 10, 3);
    Hooks::filter('btcbi_jet_engine_create_relation_actions', [JetEngineRecordHelper::class, 'createRelationActions'], 10, 3);
}

// New hooks since v2.7.8
Hooks::filter(Config::withFreePrefix('jet_engine_create_post_type_actions'), [JetEngineRecordHelper::class, 'createPostTypeActions'], 10, 3);
Hooks::filter(Config::withFreePrefix('jet_engine_create_content_type_actions'), [JetEngineRecordHelper::class, 'createContentTypeActions'], 10, 3);
Hooks::filter(Config::withFreePrefix('jet_engine_create_taxonomy_actions'), [JetEngineRecordHelper::class, 'createTaxonomyActions'], 10, 3);
Hooks::filter(Config::withFreePrefix('jet_engine_create_relation_actions'), [JetEngineRecordHelper::class, 'createRelationActions'], 10, 3);
