<?php

namespace FluentBookingPro\App\Http\Policies;

use FluentBooking\App\Services\PermissionManager;
use FluentBooking\Framework\Foundation\Policy;
use FluentBooking\Framework\Http\Request\Request;

/**
 * Pro's install-wide settings: the site's own payment gateway credentials.
 *
 * Same contract as the free plugin's PlatformPolicy, kept here so pro does not
 * require a free release that ships it. On a single site the answer is
 * SettingsPolicy's; a host serving several accounts from one install answers
 * fluent_booking/can_manage_platform with false for a tenant, because one
 * account's Stripe keys would otherwise take every account's payments.
 */
class PlatformPolicy extends Policy
{
    /**
     * @param \FluentBooking\Framework\Http\Request\Request $request
     * @return bool
     */
    public function verifyRequest(Request $request)
    {
        return (bool) apply_filters(
            'fluent_booking/can_manage_platform',
            PermissionManager::userCan('manage_all_data'),
            $request
        );
    }
}
