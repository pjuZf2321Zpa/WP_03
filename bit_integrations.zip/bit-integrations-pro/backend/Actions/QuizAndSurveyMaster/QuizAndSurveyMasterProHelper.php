<?php

namespace BitApps\IntegrationsPro\Actions\QuizAndSurveyMaster;

use QMNQuizCreator;
use QSM_Questions;

final class QuizAndSurveyMasterProHelper
{
    public static function createQuiz($response, $fieldData, $utilities = null)
    {
        global $mlwQuizMasterNext, $wpdb;

        if ($error = self::guard(['quiz_name' => $fieldData['quiz_name'] ?? ''])) {
            return $error;
        }

        if (empty($mlwQuizMasterNext->quizCreator)) {
            return self::failure(__('Quiz And Survey Master is not fully loaded', 'bit-integrations-pro'));
        }

        $themeId = (int) self::utility($utilities, 'selected_theme');
        $quizzesTable = $wpdb->prefix . 'mlw_quizzes';
        $highestBefore = (int) $wpdb->get_var("SELECT MAX(quiz_id) FROM {$quizzesTable}");

        $redirectPriority = has_action('qmn_quiz_created', 'qsm_redirect_to_edit_page');

        if ($redirectPriority !== false) {
            remove_action('qmn_quiz_created', 'qsm_redirect_to_edit_page', $redirectPriority);
        }

        $mlwQuizMasterNext->quizCreator->create_quiz($fieldData['quiz_name'], $themeId);

        if ($redirectPriority !== false) {
            add_action('qmn_quiz_created', 'qsm_redirect_to_edit_page', $redirectPriority);
        }

        $quizId = (int) $mlwQuizMasterNext->quizCreator->get_id();

        if ($quizId <= $highestBefore) {
            return self::failure(__('Failed to create the quiz', 'bit-integrations-pro'));
        }

        return self::success(__('Quiz created successfully', 'bit-integrations-pro'), ['quiz_id' => $quizId]);
    }

    public static function updateQuizName($response, $fieldData)
    {
        global $mlwQuizMasterNext;

        if ($error = self::guard(['quiz_id' => $fieldData['quiz_id'] ?? '', 'quiz_name' => $fieldData['quiz_name'] ?? ''])) {
            return $error;
        }

        $quizId = (int) $fieldData['quiz_id'];

        if (!self::quizExists($quizId)) {
            return self::failure(__('Quiz not found in Quiz And Survey Master', 'bit-integrations-pro'));
        }

        if (empty($mlwQuizMasterNext->quizCreator)) {
            return self::failure(__('Quiz And Survey Master is not fully loaded', 'bit-integrations-pro'));
        }

        $mlwQuizMasterNext->quizCreator->edit_quiz_name($quizId, $fieldData['quiz_name'], self::quizPostId($quizId));

        return self::success(__('Quiz name updated successfully', 'bit-integrations-pro'), ['quiz_id' => $quizId]);
    }

    public static function duplicateQuiz($response, $fieldData, $utilities = null)
    {
        global $wpdb;

        if ($error = self::guard(['quiz_id' => $fieldData['quiz_id'] ?? '', 'quiz_name' => $fieldData['quiz_name'] ?? ''])) {
            return $error;
        }

        $quizId = (int) $fieldData['quiz_id'];
        $quizzesTable = $wpdb->prefix . 'mlw_quizzes';

        $sourceQuiz = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$quizzesTable} WHERE quiz_id = %d LIMIT 1", $quizId), ARRAY_A);

        if (empty($sourceQuiz)) {
            return self::failure(__('Quiz not found in Quiz And Survey Master', 'bit-integrations-pro'));
        }

        $duplicateQuestions = self::isEnabled(self::utility($utilities, 'selected_duplicate_questions'));
        $settings = maybe_unserialize($sourceQuiz['quiz_settings']);
        $settings = \is_array($settings) ? $settings : [];

        unset($sourceQuiz['quiz_id']);

        $currentUser = wp_get_current_user();

        $sourceQuiz['quiz_name'] = $fieldData['quiz_name'];
        $sourceQuiz['quiz_views'] = 0;
        $sourceQuiz['quiz_taken'] = 0;
        $sourceQuiz['deleted'] = 0;
        $sourceQuiz['quiz_author_id'] = $currentUser->ID;
        $sourceQuiz['last_activity'] = current_time('mysql');

        if ($wpdb->insert($quizzesTable, $sourceQuiz) === false) {
            return self::failure(__('Failed to duplicate the quiz', 'bit-integrations-pro'));
        }

        $newQuizId = (int) $wpdb->insert_id;

        $quizPostId = wp_insert_post([
            'post_title'   => $fieldData['quiz_name'],
            'post_content' => "[mlw_quizmaster quiz={$newQuizId}]",
            'post_status'  => 'draft',
            'post_author'  => $currentUser->ID,
            'post_type'    => 'qsm_quiz',
        ]);

        if (!is_wp_error($quizPostId)) {
            add_post_meta($quizPostId, 'quiz_id', $newQuizId);
        }

        $settings = self::copyQuestions($quizId, $newQuizId, $settings, $duplicateQuestions);

        $wpdb->update($quizzesTable, ['quiz_settings' => maybe_serialize($settings)], ['quiz_id' => $newQuizId], ['%s'], ['%d']);

        if (class_exists('QMNQuizCreator') && method_exists(QMNQuizCreator::class, 'add_quiz_templates')) {
            QMNQuizCreator::add_quiz_templates($newQuizId);
        }

        do_action('qmn_quiz_duplicated', $quizId, $newQuizId);

        return self::success(__('Quiz duplicated successfully', 'bit-integrations-pro'), ['quiz_id' => $newQuizId]);
    }

    public static function deleteQuiz($response, $fieldData, $utilities = null)
    {
        global $wpdb;

        if ($error = self::guard(['quiz_id' => $fieldData['quiz_id'] ?? ''])) {
            return $error;
        }

        $quizId = (int) $fieldData['quiz_id'];

        if (!self::quizExists($quizId)) {
            return self::failure(__('Quiz not found in Quiz And Survey Master', 'bit-integrations-pro'));
        }

        $deletePermanently = self::isEnabled(self::utility($utilities, 'selected_delete_permanently'));
        $deleteQuestions = self::isEnabled(self::utility($utilities, 'selected_delete_questions'));

        $quizzesTable = $wpdb->prefix . 'mlw_quizzes';
        $questionsTable = $wpdb->prefix . 'mlw_questions';
        $quizPostId = self::quizPostId($quizId);

        if ($deletePermanently) {
            $wpdb->delete($quizzesTable, ['quiz_id' => $quizId], ['%d']);
        } else {
            $wpdb->update($quizzesTable, ['deleted' => 1], ['quiz_id' => $quizId], ['%d'], ['%d']);
        }

        if ($deleteQuestions) {
            $questionIds = $wpdb->get_col($wpdb->prepare("SELECT question_id FROM {$questionsTable} WHERE quiz_id = %d", $quizId));

            if ($deletePermanently) {
                $wpdb->delete($questionsTable, ['quiz_id' => $quizId], ['%d']);
            } else {
                $wpdb->update($questionsTable, ['deleted' => 1], ['quiz_id' => $quizId], ['%d'], ['%d']);
            }

            foreach ((array) $questionIds as $questionId) {
                do_action('qsm_question_deleted', (int) $questionId);
            }
        }

        if (!empty($quizPostId)) {
            if ($deletePermanently) {
                wp_delete_post($quizPostId, true);
            } else {
                wp_trash_post($quizPostId);
            }
        }

        if ($deletePermanently && class_exists('QMNQuizCreator') && method_exists(QMNQuizCreator::class, 'purge_quiz_state')) {
            QMNQuizCreator::purge_quiz_state($quizId);
        }

        do_action('qmn_quiz_deleted', $quizId);

        return self::success(
            $deletePermanently
                ? __('Quiz deleted permanently', 'bit-integrations-pro')
                : __('Quiz moved to trash', 'bit-integrations-pro'),
            ['quiz_id' => $quizId]
        );
    }

    public static function createQuestion($response, $fieldData, $utilities = null, $integrationDetails = null)
    {
        if ($error = self::guard(['quiz_id' => $fieldData['quiz_id'] ?? '', 'question_name' => $fieldData['question_name'] ?? ''])) {
            return $error;
        }

        $quizId = (int) $fieldData['quiz_id'];

        if (!self::quizExists($quizId)) {
            return self::failure(__('Quiz not found in Quiz And Survey Master', 'bit-integrations-pro'));
        }

        if (!class_exists('QSM_Questions')) {
            return self::failure(__('Required Quiz And Survey Master class QSM_Questions does not exist', 'bit-integrations-pro'));
        }

        $questionId = QSM_Questions::create_question(
            self::questionData($fieldData, self::conf($integrationDetails, 'selectedQuestionType')),
            self::answers($fieldData),
            self::questionSettings($utilities, self::conf($integrationDetails, 'selectedQuestionType'))
        );

        if (empty($questionId)) {
            return self::failure(__('Failed to create the question', 'bit-integrations-pro'));
        }

        self::addQuestionToLayout($quizId, (int) $questionId);

        return self::success(__('Question created successfully', 'bit-integrations-pro'), ['question_id' => (int) $questionId]);
    }

    public static function updateQuestion($response, $fieldData, $utilities = null, $integrationDetails = null)
    {
        if ($error = self::guard(['question_id' => $fieldData['question_id'] ?? ''])) {
            return $error;
        }

        $questionId = (int) $fieldData['question_id'];
        $existing = self::questionRow($questionId);

        if (empty($existing)) {
            return self::failure(__('Question not found in Quiz And Survey Master', 'bit-integrations-pro'));
        }

        if (!class_exists('QSM_Questions')) {
            return self::failure(__('Required Quiz And Survey Master class QSM_Questions does not exist', 'bit-integrations-pro'));
        }

        $questionType = self::conf($integrationDetails, 'selectedQuestionType');

        $data = self::questionData($fieldData, $questionType, $existing);
        $answers = self::answers($fieldData);

        if (empty($answers)) {
            $stored = maybe_unserialize($existing['answer_array']);
            $answers = \is_array($stored) ? $stored : [];
        }

        $storedSettings = maybe_unserialize($existing['question_settings']);
        $settings = array_merge(
            \is_array($storedSettings) ? $storedSettings : [],
            self::questionSettings($utilities, $questionType)
        );

        QSM_Questions::save_question($questionId, $data, $answers, $settings);

        return self::success(__('Question updated successfully', 'bit-integrations-pro'), ['question_id' => $questionId]);
    }

    public static function deleteQuestion($response, $fieldData)
    {
        if ($error = self::guard(['question_id' => $fieldData['question_id'] ?? ''])) {
            return $error;
        }

        $questionId = (int) $fieldData['question_id'];
        $existing = self::questionRow($questionId);

        if (empty($existing)) {
            return self::failure(__('Question not found in Quiz And Survey Master', 'bit-integrations-pro'));
        }

        if (!class_exists('QSM_Questions')) {
            return self::failure(__('Required Quiz And Survey Master class QSM_Questions does not exist', 'bit-integrations-pro'));
        }

        QSM_Questions::delete_question($questionId);

        self::removeQuestionFromLayout((int) $existing['quiz_id'], $questionId);

        do_action('qsm_question_deleted', $questionId);

        return self::success(__('Question deleted successfully', 'bit-integrations-pro'), ['question_id' => $questionId]);
    }

    public static function deleteResult($response, $fieldData, $utilities = null)
    {
        global $wpdb;

        if ($error = self::guard(['result_id' => $fieldData['result_id'] ?? ''])) {
            return $error;
        }

        $resultId = (int) $fieldData['result_id'];
        $resultsTable = $wpdb->prefix . 'mlw_results';

        $exists = $wpdb->get_var($wpdb->prepare("SELECT result_id FROM {$resultsTable} WHERE result_id = %d", $resultId));

        if (empty($exists)) {
            return self::failure(__('Quiz result not found in Quiz And Survey Master', 'bit-integrations-pro'));
        }

        do_action('qsm_before_delete_result', $resultId);

        $deletePermanently = self::isEnabled(self::utility($utilities, 'selected_delete_permanently'));

        $deleted = $deletePermanently
            ? $wpdb->delete($resultsTable, ['result_id' => $resultId], ['%d'])
            : $wpdb->update($resultsTable, ['deleted' => 1], ['result_id' => $resultId], ['%d'], ['%d']);

        if ($deleted === false) {
            return self::failure(__('Failed to delete the quiz result', 'bit-integrations-pro'));
        }

        return self::success(
            $deletePermanently
                ? __('Quiz result deleted permanently', 'bit-integrations-pro')
                : __('Quiz result moved to trash', 'bit-integrations-pro'),
            ['result_id' => $resultId]
        );
    }

    private static function guard($required)
    {
        foreach ($required as $key => $value) {
            if ($value === '' || $value === null) {
                return self::failure(
                    // translators: %s: field name
                    wp_sprintf(__('%s is required', 'bit-integrations-pro'), $key)
                );
            }
        }
    }

    private static function success($message, $data = [])
    {
        return ['success' => true, 'message' => $message, 'data' => $data];
    }

    private static function failure($message)
    {
        return ['success' => false, 'message' => $message];
    }

    private static function utility($utilities, $key)
    {
        if (\is_object($utilities)) {
            return $utilities->{$key} ?? '';
        }

        return \is_array($utilities) ? ($utilities[$key] ?? '') : '';
    }

    private static function conf($integrationDetails, $key)
    {
        if (\is_object($integrationDetails)) {
            return $integrationDetails->{$key} ?? '';
        }

        return \is_array($integrationDetails) ? ($integrationDetails[$key] ?? '') : '';
    }

    private static function isEnabled($value)
    {
        return \in_array((string) $value, ['1', 'yes', 'true'], true);
    }

    private static function quizExists($quizId)
    {
        global $wpdb;

        return (bool) $wpdb->get_var(
            $wpdb->prepare("SELECT quiz_id FROM {$wpdb->prefix}mlw_quizzes WHERE quiz_id = %d LIMIT 1", (int) $quizId)
        );
    }

    private static function questionRow($questionId)
    {
        global $wpdb;

        return $wpdb->get_row(
            $wpdb->prepare("SELECT * FROM {$wpdb->prefix}mlw_questions WHERE question_id = %d LIMIT 1", (int) $questionId),
            ARRAY_A
        );
    }

    private static function quizPostId($quizId)
    {
        global $wpdb;

        return (int) $wpdb->get_var(
            $wpdb->prepare("SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = 'quiz_id' AND meta_value = %s LIMIT 1", (string) $quizId)
        );
    }

    private static function questionData($fieldData, $questionType, $existing = [])
    {
        return [
            'quiz_id'     => (int) ($fieldData['quiz_id'] ?? ($existing['quiz_id'] ?? 0)),
            'type'        => (string) ($questionType !== '' ? $questionType : ($existing['question_type_new'] ?? '0')),
            'name'        => (string) ($fieldData['question_name'] ?? ($existing['question_name'] ?? '')),
            'answer_info' => (string) ($fieldData['answer_info'] ?? ($existing['question_answer_info'] ?? '')),
            'comments'    => (string) ($existing['comments'] ?? '1'),
            'hint'        => (string) ($fieldData['hint'] ?? ($existing['hints'] ?? '')),
            'order'       => (int) ($fieldData['question_order'] ?? ($existing['question_order'] ?? 1)),
            'category'    => (string) ($fieldData['category'] ?? ($existing['category'] ?? '')),
        ];
    }

    private static function answers($fieldData)
    {
        $answers = [];

        for ($index = 1; $index <= 4; $index++) {
            $text = $fieldData["answer_{$index}"] ?? '';

            if ($text === '') {
                continue;
            }

            $answers[] = [
                $text,
                (float) ($fieldData["answer_{$index}_points"] ?? 0),
                self::isEnabled($fieldData["answer_{$index}_correct"] ?? '') ? 1 : 0,
            ];
        }

        return $answers;
    }

    private static function questionSettings($utilities, $questionType)
    {
        $settings = [];

        $required = self::utility($utilities, 'selected_required');

        if ($required !== '') {
            $settings['required'] = self::isEnabled($required) ? 1 : 0;
        }

        if ($questionType !== '') {
            $settings['question_type_new'] = $questionType;
        }

        return $settings;
    }

    private static function addQuestionToLayout($quizId, $questionId)
    {
        self::updateLayout($quizId, static function ($pages, $qpages) use ($questionId) {
            $lastPage = \count($pages) - 1;
            $pages[$lastPage][] = $questionId;

            if (isset($qpages[$lastPage]['questions']) && \is_array($qpages[$lastPage]['questions'])) {
                $qpages[$lastPage]['questions'][] = $questionId;
            }

            return [$pages, $qpages];
        });
    }

    private static function removeQuestionFromLayout($quizId, $questionId)
    {
        self::updateLayout($quizId, static function ($pages, $qpages) use ($questionId) {
            foreach ($pages as $index => $page) {
                $pages[$index] = array_values(array_diff((array) $page, [$questionId]));
            }

            foreach ($qpages as $index => $qpage) {
                if (isset($qpage['questions']) && \is_array($qpage['questions'])) {
                    $qpages[$index]['questions'] = array_values(array_diff($qpage['questions'], [$questionId]));
                }
            }

            return [$pages, $qpages];
        });
    }

    private static function updateLayout($quizId, callable $mutate)
    {
        global $mlwQuizMasterNext;

        if ($quizId <= 0 || empty($mlwQuizMasterNext->pluginHelper)) {
            return;
        }

        $mlwQuizMasterNext->pluginHelper->prepare_quiz($quizId);

        $pages = $mlwQuizMasterNext->pluginHelper->get_quiz_setting('pages', [], 'bit-integrations-pro');
        $qpages = $mlwQuizMasterNext->pluginHelper->get_quiz_setting('qpages', [], 'bit-integrations-pro');

        if (!\is_array($pages) || $pages === []) {
            return;
        }

        $qpages = \is_array($qpages) ? $qpages : [];

        list($pages, $qpages) = $mutate($pages, $qpages);

        $mlwQuizMasterNext->pluginHelper->update_quiz_setting('pages', $pages);

        if ($qpages !== []) {
            $mlwQuizMasterNext->pluginHelper->update_quiz_setting('qpages', $qpages);
        }
    }

    private static function copyQuestions($quizId, $newQuizId, $settings, $duplicateQuestions)
    {
        global $wpdb;

        if (!$duplicateQuestions) {
            $settings['pages'] = [];
            $settings['qpages'] = [];

            return $settings;
        }

        $questionsTable = $wpdb->prefix . 'mlw_questions';

        $questions = $wpdb->get_results(
            $wpdb->prepare("SELECT * FROM {$questionsTable} WHERE quiz_id = %d AND deleted = 0", $quizId),
            ARRAY_A
        );

        $idMap = [];

        foreach ((array) $questions as $question) {
            $oldId = (int) $question['question_id'];

            unset($question['question_id']);
            $question['quiz_id'] = $newQuizId;

            if ($wpdb->insert($questionsTable, $question) !== false) {
                $idMap[$oldId] = (int) $wpdb->insert_id;
            }
        }

        $settings['pages'] = self::remapPages(maybe_unserialize($settings['pages'] ?? []), $idMap);

        $qpages = maybe_unserialize($settings['qpages'] ?? []);

        if (\is_array($qpages)) {
            foreach ($qpages as $key => $qpage) {
                if (isset($qpage['questions']) && \is_array($qpage['questions'])) {
                    $qpages[$key]['questions'] = self::remapIds($qpage['questions'], $idMap);
                }
            }
        }

        $settings['qpages'] = $qpages;

        return $settings;
    }

    private static function remapPages($pages, $idMap)
    {
        if (!\is_array($pages)) {
            return [];
        }

        foreach ($pages as $key => $page) {
            $pages[$key] = \is_array($page) ? self::remapIds($page, $idMap) : $page;
        }

        return $pages;
    }

    private static function remapIds($questionIds, $idMap)
    {
        $mapped = [];

        foreach ($questionIds as $questionId) {
            $mapped[] = $idMap[(int) $questionId] ?? $questionId;
        }

        return $mapped;
    }
}
