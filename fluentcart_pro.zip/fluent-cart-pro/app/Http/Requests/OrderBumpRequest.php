<?php

namespace FluentCartPro\App\Http\Requests;


use FluentCart\Framework\Foundation\RequestGuard;

class OrderBumpRequest extends RequestGuard
{

    public function rules(): array
    {
        return [
            'type'            => 'nullable|sanitizeText|maxLength:50',
            'status'          => 'nullable|sanitizeText|maxLength:50',
            'src_object_id'   => 'required|numeric',
            'src_object_type' => 'nullable|sanitizeText|maxLength:50',
            'title'           => 'required|sanitizeText|maxLength:194',
            'description'     => 'nullable',
            'config'          => 'nullable|array',
            'conditions'      => 'nullable|array',
            'priority'        => 'nullable|numeric|min:1',
        ];
    }

    /**
     * @return array
     */
    public function sanitize(): array
    {
        return [
            'type'            => 'sanitize_text_field',
            'status'          => 'sanitize_text_field',
            'src_object_id'   => 'intval',
            'src_object_type' => 'sanitize_text_field',
            'title'           => 'sanitize_text_field',
            'description'     => function ($value) {
                return wp_kses_post($value);
            },
            'config'          => function ($value) {
                if (is_array($value)) {
                    $allowed = ['above_customer', 'below_customer', 'above_summary', 'below_summary', 'above_payment', 'below_payment', 'disabled'];
                    $position = isset($value['position']) ? $value['position'] : '';
                    $value['position'] = in_array($position, $allowed, true) ? $position : '';
                    $value['show_in_cart'] = isset($value['show_in_cart']) && $value['show_in_cart'] === 'yes' ? 'yes' : 'no';

                    $image = isset($value['image']) && is_array($value['image']) ? $value['image'] : [];
                    $imageId = isset($image['id']) && is_scalar($image['id']) ? absint($image['id']) : 0;
                    // The client url is only a preview hint; render time re-resolves the id.
                    if (!$imageId || !wp_attachment_is_image($imageId)) {
                        $imageId = 0;
                    }
                    $value['image'] = [
                        'id'  => $imageId,
                        'url' => $imageId && isset($image['url']) && is_string($image['url']) ? esc_url_raw($image['url']) : '',
                    ];
                }

                return $value;
            },
            'conditions'      => function ($value) {
                return $value;
            },
            'priority'        => 'intval',
        ];
    }
}
