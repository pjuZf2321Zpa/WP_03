<?php

namespace NinjaTablesPro\App\Hooks\Handlers;

use NinjaTablesPro\App\Modules\DataProviders\CsvProvider;
use NinjaTablesPro\App\Modules\DataProviders\RawSqlProvider;
use NinjaTablesPro\App\Modules\DataProviders\WoocommercePostsProvider;
use NinjaTablesPro\App\Modules\DataProviders\WoocommerceReviewsProvider;
use NinjaTablesPro\App\Modules\DataProviders\WPPostsProvider;
use NinjaTablesPro\App\Modules\GoogleSheetSync\GoogleSheetSyncProvider;


class DataProviderHandler
{
    public function handle()
    {
        (new WPPostsProvider())->boot();
        (new WoocommercePostsProvider())->boot();
        (new WoocommerceReviewsProvider())->boot();
        (new CsvProvider())->boot();
        (new RawSqlProvider())->boot();
        (new GoogleSheetSyncProvider())->boot();
    }
}
