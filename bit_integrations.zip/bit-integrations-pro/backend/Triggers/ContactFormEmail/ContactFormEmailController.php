<?php

namespace BitApps\IntegrationsPro\Triggers\ContactFormEmail;

use BitApps\IntegrationsPro\Config;

final class ContactFormEmailController
{
    public static function info()
    {
        return [
            'name'              => 'Contact Form Email',
            'type'              => 'custom_form_submission',
            'is_active'         => static::isPluginInstalled(),
            'documentation_url' => '#',
            'tutorial_url'      => '#',
            'tasks'             => [
                'action' => 'contact-form-email/get',
                'method' => 'get',
            ],
            'fetch' => [
                'action' => 'trigger/test',
                'method' => 'post',
            ],
            'fetch_remove' => [
                'action' => 'trigger/test/remove',
                'method' => 'post',
            ],
            'isPro' => true
        ];
    }

    public function getAllTasks()
    {
        if (!static::isPluginInstalled()) {
            wp_send_json_error(\sprintf(__('%s is not installed or activated', 'bit-integrations-pro'), 'Contact Form Email'));
        }

        wp_send_json_success([
            [
                'form_name'           => __('Form Submission', 'bit-integrations-pro'),
                'triggered_entity_id' => 'cfte_process_data',
                'skipPrimaryKey'      => false
            ]
        ]);
    }

    public static function handleFormSubmitted($params)
    {
        $helperClass = bit_integrations_get_class('Core\\Util\\Helper');
        $flowClass = bit_integrations_get_class('Flow\\Flow');

        if (isset($_POST['cp_contactformtoemail_id'])) {
            $formId = sanitize_text_field(wp_unslash($_POST['cp_contactformtoemail_id']));
        }

        if (empty($formId)) {
            return;
        }

        $params['form_id'] = $formId;

        $formData = $helperClass::prepareFetchFormatFields($params);

        if (empty($formData) || !\is_array($formData)) {
            return;
        }

        $helperClass::setTestData(Config::withFreePrefix('cfte_process_data_test'), array_values($formData), 'form_id.value', $formId);

        $flows = $flowClass::exists('ContactFormEmail', 'cfte_process_data');

        if (!$flows) {
            return;
        }

        foreach ($flows as $flow) {
            $flowDetails = $helperClass::parseFlowDetails($flow->flow_details);

            if (
                !isset($flowDetails->primaryKey)
                || !$helperClass::isPrimaryKeysMatch($formData, $flowDetails->primaryKey)
            ) {
                continue;
            }

            $data = array_column($formData, 'value', 'name');

            $flowClass::execute('ContactFormEmail', 'cfte_process_data', $data, [$flow]);
        }

        return ['type' => 'success'];
    }

    private static function isPluginInstalled()
    {
        return class_exists('CP_CFTEMAIL_BaseClass');
    }
}
