<?php

namespace BitApps\IntegrationsPro\Actions\FollowUpBoss\Services;

final class GroupService extends BaseService
{
    public function createGroup(): array
    {
        $validationRules = [
            'name'         => ['required'],
            'users'        => ['required'],
            'claim_window' => ['nullable', 'integer'],
        ];
        $error = $this->validateFields(
            $validationRules,
            [
                'name'         => __('Group Name', 'bit-integrations-pro'),
                'users'        => __('Members', 'bit-integrations-pro'),
                'claim_window' => __('Claim Window', 'bit-integrations-pro'),
            ],
            ['users']
        );

        if ($error !== null) {
            return $error;
        }

        $payload = $this->removeEmptyValues(
            [
                'name'           => $this->getString('name'),
                'users'          => $this->getIntegerList('users'),
                'type'           => $this->getString('group_type'),
                'distribution'   => $this->getString('distribution'),
                'claimWindow'    => $this->getInteger('claim_window'),
                'defaultGroupId' => $this->getInteger('default_group_id'),
                'defaultPondId'  => $this->getInteger('default_pond_id'),
                'defaultUserId'  => $this->getInteger('default_user_id'),
            ]
        );

        return $this->dispatch('POST', '/groups', $payload);
    }

    public function updateGroup(): array
    {
        $validationRules = [
            'group_id'     => ['required', 'integer'],
            'claim_window' => ['nullable', 'integer'],
        ];
        $error = $this->validateFields(
            $validationRules,
            [
                'group_id'     => __('Group ID', 'bit-integrations-pro'),
                'claim_window' => __('Claim Window', 'bit-integrations-pro'),
            ]
        );

        if ($error !== null) {
            return $error;
        }

        $payload = $this->removeEmptyValues(
            [
                'name'           => $this->getString('name'),
                'users'          => $this->getIntegerList('users'),
                'type'           => $this->getString('group_type'),
                'distribution'   => $this->getString('distribution'),
                'claimWindow'    => $this->getInteger('claim_window'),
                'defaultGroupId' => $this->getInteger('default_group_id'),
                'defaultPondId'  => $this->getInteger('default_pond_id'),
                'defaultUserId'  => $this->getInteger('default_user_id'),
            ]
        );

        if (!isset($payload['users'])) {
            $current = $this->dispatch('GET', '/groups/' . rawurlencode($this->getString('group_id')));

            if (!$current['success']) {
                return $current;
            }

            $payload['users'] = array_column($current['data']['users'] ?? [], 'id');
        }

        return $this->dispatch('PUT', '/groups/' . rawurlencode($this->getString('group_id')), $payload);
    }

    public function deleteGroup(): array
    {
        $validationRules = ['group_id' => ['required', 'integer']];
        $error = $this->validateFields(
            $validationRules,
            [
                'group_id' => __('Group ID', 'bit-integrations-pro'),
            ]
        );

        if ($error !== null) {
            return $error;
        }

        return $this->dispatch('DELETE', '/groups/' . rawurlencode($this->getString('group_id')));
    }
}
