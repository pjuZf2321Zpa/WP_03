<?php

namespace FluentCartPro\App\Modules\Promotional\OrderBump\Cards;

/**
 * A built-in order bump card: its block markup and its own stylesheet.
 * The markup uses the card's own class names (the root class is the scope for every CSS rule),
 * so one card's rules never change another card.
 */
abstract class AbstractCard
{
    abstract public static function key(): string;

    abstract public static function title(): string;

    abstract public static function description(): string;

    abstract public static function content(): string;

    // Rules for every place the card shows: checkout, cart drawer, cart page and the editor.
    abstract public static function css(): string;

    // A card element block (image, title, price ...) with the class the card's stylesheet styles.
    protected static function element(string $name, string $class): string
    {
        return '<!-- wp:fluent-cart/order-bump-' . $name . ' ' . wp_json_encode(['className' => $class]) . ' /-->';
    }

    // A plain group block with the class the card's stylesheet styles.
    protected static function group(string $class, string $inner): string
    {
        return '<!-- wp:group ' . wp_json_encode(['className' => $class]) . " -->\n"
            . '<div class="wp-block-group ' . $class . '">' . $inner . "</div>\n<!-- /wp:group -->";
    }
}
