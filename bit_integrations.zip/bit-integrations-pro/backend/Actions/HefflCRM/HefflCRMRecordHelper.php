<?php

namespace BitApps\IntegrationsPro\Actions\HefflCRM;

final class HefflCRMRecordHelper
{
    private const BASE_URL = 'https://api.heffl.com/api/v1';

    private const BILLING_ADDRESS_MAP = [
        'billingCity'       => 'city',
        'billingStreet'     => 'address',
        'billingLandmark'   => 'landmark',
        'billingState'      => 'state',
        'billingCountry'    => 'country',
        'billingPostalCode' => 'postalCode',
    ];

    private const PRIMARY_CONTACT_MAP = [
        'primaryContactFirstName'  => 'firstName',
        'primaryContactLastName'   => 'lastName',
        'primaryContactEmail'      => 'email',
        'primaryContactPhone'      => 'phone',
        'primaryContactSalutation' => 'salutation',
        'primaryContactJobTitle'   => 'jobTitle',
    ];

    public static function createLead($response, $apiKey, $fieldData, $integrationDetails = null)
    {
        $error = self::requireFields($fieldData, ['name' => __('Name', 'bit-integrations-pro')]);
        if ($error) {
            return $error;
        }

        return self::request('/leads', [
            'name'            => $fieldData['name'] ?? null,
            'email'           => $fieldData['email'] ?? null,
            'mobile'          => $fieldData['mobile'] ?? null,
            'secondaryMobile' => $fieldData['secondaryMobile'] ?? null,
            'title'           => $fieldData['title'] ?? null,
            'value'           => self::toFloat($fieldData['value'] ?? null),
            'website'         => $fieldData['website'] ?? null,
            'sourceId'        => $integrationDetails->leadSourceId ?? null,
            'stageId'         => $integrationDetails->leadStageId ?? null,
        ], $apiKey);
    }

    public static function createClient($response, $apiKey, $fieldData, $integrationDetails = null)
    {
        $clientType = $integrationDetails->clientType ?? 'company';

        $required = $clientType === 'contact'
            ? ['firstName' => __('First Name', 'bit-integrations-pro')]
            : ['name' => __('Name', 'bit-integrations-pro')];

        $error = self::requireFields($fieldData, $required);
        if ($error) {
            return $error;
        }

        $payload = [
            'type'           => $clientType,
            'name'           => $fieldData['name'] ?? null,
            'firstName'      => $fieldData['firstName'] ?? null,
            'lastName'       => $fieldData['lastName'] ?? null,
            'salutation'     => $fieldData['salutation'] ?? null,
            'email'          => $fieldData['email'] ?? null,
            'phone'          => $fieldData['phone'] ?? null,
            'jobTitle'       => $fieldData['jobTitle'] ?? null,
            'website'        => $fieldData['website'] ?? null,
            'taxNumber'      => $fieldData['taxNumber'] ?? null,
            'openingBalance' => self::toFloat($fieldData['openingBalance'] ?? null),
        ];

        $billing = self::buildNested($fieldData, self::BILLING_ADDRESS_MAP);
        if (!empty($billing)) {
            $payload['billingAddress'] = $billing;
        }

        $primary = self::buildNested($fieldData, self::PRIMARY_CONTACT_MAP);
        if (!empty($primary)) {
            $payload['primaryContact'] = $primary;
        }

        return self::request('/clients', $payload, $apiKey);
    }

    public static function createDeal($response, $apiKey, $fieldData, $integrationDetails = null)
    {
        $clientId = $integrationDetails->clientId ?? ($fieldData['clientId'] ?? null);
        $leadId = $integrationDetails->leadId ?? ($fieldData['leadId'] ?? null);

        $error = self::requireFields(
            [
                'title'      => $fieldData['title'] ?? null,
                'pipelineId' => $integrationDetails->pipelineId ?? null,
                'stageId'    => $integrationDetails->dealStageId ?? null,
                'clientId'   => $clientId,
            ],
            [
                'title'      => __('Title', 'bit-integrations-pro'),
                'pipelineId' => __('Pipeline', 'bit-integrations-pro'),
                'stageId'    => __('Deal Stage', 'bit-integrations-pro'),
                'clientId'   => __('Client', 'bit-integrations-pro'),
            ]
        );
        if ($error) {
            return $error;
        }

        $priority = $integrationDetails->priority ?? null;
        if ($priority !== null && !\in_array($priority, ['LOW', 'MEDIUM', 'HIGH'], true)) {
            return [
                'success' => false,
                'message' => __('Invalid deal priority. Must be LOW, MEDIUM, or HIGH.', 'bit-integrations-pro'),
            ];
        }

        return self::request('/deals', [
            'title'             => $fieldData['title'] ?? null,
            'pipelineId'        => $integrationDetails->pipelineId ?? null,
            'stageId'           => $integrationDetails->dealStageId ?? null,
            'clientId'          => $clientId,
            'leadId'            => $leadId,
            'sourceId'          => $integrationDetails->dealSourceId ?? null,
            'priority'          => $priority,
            'price'             => self::toFloat($fieldData['price'] ?? null),
            'expectedCloseDate' => self::toIso8601($fieldData['expectedCloseDate'] ?? null),
        ], $apiKey);
    }

    private static function request($path, array $payload, $apiKey)
    {
        if (empty($apiKey)) {
            return ['success' => false, 'message' => __('Heffl CRM API key missing', 'bit-integrations-pro')];
        }

        $payload = array_filter($payload, static function ($value) {
            return $value !== null && $value !== '';
        });

        $httpHelperClass = bit_integrations_get_class('Core\\Util\\HttpHelper');

        $apiResponse = $httpHelperClass::post(self::BASE_URL . $path, wp_json_encode($payload), [
            'x-api-key'    => $apiKey,
            'Content-Type' => 'application/json',
            'Accept'       => 'application/json',
        ]);

        $statusCode = $httpHelperClass::$responseCode;

        if ($statusCode >= 200 && $statusCode < 300) {
            return ['success' => true, 'message' => __('Record created successfully', 'bit-integrations-pro'), 'data' => $apiResponse];
        }

        return ['success' => false, 'message' => self::errorMessage($apiResponse), 'data' => $apiResponse];
    }

    private static function requireFields(array $source, array $required)
    {
        $missing = [];
        foreach ($required as $key => $label) {
            $value = $source[$key] ?? null;
            if (\is_string($value)) {
                $value = trim($value);
            }
            if ($value === null || $value === '') {
                $missing[] = $label;
            }
        }

        if (empty($missing)) {
            return;
        }

        return [
            'success' => false,
            'message' => \sprintf(
                // translators: %s: comma-separated list of required field labels
                __('Heffl CRM: missing required field(s): %s', 'bit-integrations-pro'),
                implode(', ', $missing)
            ),
        ];
    }

    private static function buildNested(array $source, array $map)
    {
        $out = [];
        foreach ($map as $flatKey => $nestedKey) {
            $value = $source[$flatKey] ?? null;
            if ($value !== null && $value !== '') {
                $out[$nestedKey] = $value;
            }
        }

        return $out;
    }

    private static function toFloat($value)
    {
        if ($value === null) {
            return;
        }
        if (\is_string($value)) {
            $value = trim($value);
            if ($value === '') {
                return;
            }
        }

        return is_numeric($value) ? (float) $value : null;
    }

    private static function toIso8601($value)
    {
        if ($value === null) {
            return;
        }
        if (\is_string($value)) {
            $value = trim($value);
            if ($value === '') {
                return;
            }
        }

        $timestamp = is_numeric($value) ? (int) $value : strtotime((string) $value);
        if ($timestamp === false || $timestamp <= 0) {
            return;
        }

        return gmdate('Y-m-d\TH:i:s\Z', $timestamp);
    }

    private static function errorMessage($apiResponse)
    {
        if (\is_object($apiResponse) && isset($apiResponse->message)) {
            return $apiResponse->message;
        }

        if (\is_string($apiResponse) && $apiResponse !== '') {
            return $apiResponse;
        }

        return __('Heffl CRM API request failed', 'bit-integrations-pro');
    }
}
