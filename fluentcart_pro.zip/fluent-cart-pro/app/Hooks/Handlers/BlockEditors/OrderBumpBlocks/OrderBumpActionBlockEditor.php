<?php

namespace FluentCartPro\App\Hooks\Handlers\BlockEditors\OrderBumpBlocks;

/**
 * An Add or a Remove button of a cart card. Each is its own block; both are in the markup and the
 * one that does not fit the cart state is hidden, so the checkout can switch them without a redraw.
 * They print the markup the cart script already listens to.
 */
abstract class OrderBumpActionBlockEditor extends OrderBumpBlockEditor
{
    abstract protected function action(): string;

    abstract protected function defaultLabel(): string;

    abstract protected function blockTitle(): string;

    abstract protected function blockDescription(): string;

    public function getScripts(): array
    {
        return [
            [
                'source'       => 'admin/BlockEditor/OrderBumpBlocks/' . $this->jsName() . '.jsx',
                'dependencies' => ['wp-blocks', 'wp-components', 'wp-block-editor']
            ]
        ];
    }

    private function jsName(): string
    {
        return 'OrderBump' . ucfirst($this->action()) . 'ButtonBlockEditor';
    }

    public function localizeData(): array
    {
        return [
            $this->getLocalizationKey() => [
                'slug'        => $this->slugPrefix,
                'name'        => static::getEditorName(),
                'title'       => $this->blockTitle(),
                'description' => $this->blockDescription(),
            ],
            'fluent_cart_block_translation' => \FluentCart\App\Services\Translations\TransStrings::blockStrings(),
        ];
    }

    public function blockAttributes(): array
    {
        return ['label' => ['type' => 'string', 'default' => $this->defaultLabel()]];
    }

    public function render(array $attrs, $block = null, $content = ''): string
    {
        $bump = $this->bump($block);
        if (!$bump) {
            return '';
        }

        $isRemove = $this->action() === 'remove';
        $isAdded = !empty($bump['is_added']);
        $productTitle = isset($bump['product_title']) ? (string) $bump['product_title'] : '';
        $label = !empty($attrs['label']) ? $attrs['label'] : $this->defaultLabel();

        $attributes = [
            'type'                 => 'button',
            'class'                => 'fct_cart_bump_btn',
            'data-fct_cart_bump'   => '',
            'data-fct_bump_action' => $this->action(),
            'data-fct_bump_id'     => (int) $bump['id'],
            'data-fct_show'        => $this->action(),
            'data-fct_announce'    => $isRemove ? __('Removed from your order', 'fluent-cart-pro') : __('Added to your order', 'fluent-cart-pro'),
            'aria-label'           => trim($label . ' ' . $productTitle),
        ];

        // Only the button that fits the cart state shows.
        if ($isRemove !== $isAdded) {
            $attributes['hidden'] = 'hidden';
        }

        // The wrapper attributes carry the block's colour, typography and spacing settings.
        return '<button ' . get_block_wrapper_attributes($attributes) . '>' . esc_html($label) . '</button>';
    }
}
