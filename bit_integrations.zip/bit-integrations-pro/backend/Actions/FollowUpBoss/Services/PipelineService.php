<?php

namespace BitApps\IntegrationsPro\Actions\FollowUpBoss\Services;

final class PipelineService extends BaseService
{
    public function createPipeline(): array
    {
        $validationRules = [
            'name'         => ['required'],
            'order_weight' => ['nullable', 'integer'],
        ];
        $error = $this->validateFields(
            $validationRules,
            [
                'name'         => __('Pipeline Name', 'bit-integrations-pro'),
                'order_weight' => __('Sort Order', 'bit-integrations-pro'),
            ]
        );

        if ($error !== null) {
            return $error;
        }

        $payload = $this->removeEmptyValues(
            [
                'name'        => $this->getString('name'),
                'description' => $this->getString('description'),
                'orderWeight' => $this->getInteger('order_weight'),
                'stages'      => $this->getPipelineStages(),
            ]
        );

        return $this->dispatch('POST', '/pipelines', $payload);
    }

    public function updatePipeline(): array
    {
        $validationRules = [
            'pipeline_id'  => ['required', 'integer'],
            'order_weight' => ['nullable', 'integer'],
        ];
        $error = $this->validateFields(
            $validationRules,
            [
                'pipeline_id'  => __('Pipeline ID', 'bit-integrations-pro'),
                'order_weight' => __('Sort Order', 'bit-integrations-pro'),
            ]
        );

        if ($error !== null) {
            return $error;
        }

        $payload = $this->removeEmptyValues(
            [
                'name'        => $this->getString('name'),
                'description' => $this->getString('description'),
                'orderWeight' => $this->getInteger('order_weight'),
            ]
        );

        return $this->dispatch('PUT', '/pipelines/' . rawurlencode($this->getString('pipeline_id')), $payload);
    }

    public function deletePipeline(): array
    {
        $validationRules = ['pipeline_id' => ['required', 'integer']];
        $error = $this->validateFields(
            $validationRules,
            [
                'pipeline_id' => __('Pipeline ID', 'bit-integrations-pro'),
            ]
        );

        if ($error !== null) {
            return $error;
        }

        return $this->dispatch('DELETE', '/pipelines/' . rawurlencode($this->getString('pipeline_id')));
    }

    private function getPipelineStages(): array
    {
        $names = $this->getList('stages');
        $lastIndex = \count($names) - 1;
        $stages = [];

        foreach ($names as $index => $name) {
            $stages[] = ['name' => $name, 'closedStage' => $index === $lastIndex];
        }

        return $stages;
    }
}
