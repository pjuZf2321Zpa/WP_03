<?php

if (!defined('ABSPATH')) {
    die('You are not allowed to call this page directly.');
}

/**
 * Controller for cart checkout: page rendering, step system, and all AJAX endpoints.
 *
 * This is the integration point between the checkout UI (Plan 03), payment processing
 * (Plan 05), and the checkout service (Plan 01). All business logic is delegated to
 * MeprCartCheckoutService and MeprCartSessionService.
 *
 * Step system:
 *   Steps are defined as a filterable array via `mepr_checkout_stages`. The shipping step
 *   is conditional — shown only when the cart contains physical products. Addons can
 *   add/remove/reorder steps by filtering `mepr_checkout_stages`.
 *
 * AJAX endpoints (all require mepr_cart_checkout_nonce):
 *   - mepr_cart_checkout_validate_step — validate a step's fields before advancing
 *   - mepr_cart_checkout_save_step     — persist step data to session checkout_data
 *   - mepr_cart_recalculate            — recalculate totals after item/coupon change
 *   - mepr_cart_apply_coupon           — apply a discount code
 *   - mepr_cart_remove_coupon          — remove the applied discount code
 *   - mepr_cart_create_payment_intent  — create/retrieve Stripe PaymentIntent
 *   - mepr_cart_place_order            — complete the order after payment confirmation
 *   - mepr_cart_update_sidebar         — update the invoice sidebar after item edits
 */
class MeprCartCheckoutCtrl extends MeprBaseCartCtrl
{
    /**
     * Memoized result of has_unavailable_cart_items() — null means not yet computed.
     *
     * @var boolean|null
     */
    private $cart_has_unavailable = null;

    /**
     * Cached unpurchasable-item check: null = not computed, false = all ok, string = error message.
     *
     * @var null|false|string
     */
    private $cart_unpurchasable_message = null;

    /**
     * Return whether the given cart items contain any unavailable (trashed/deleted) products.
     * Result is memoized — subsequent calls ignore $items and return the cached value.
     *
     * @param  array $items Cart items keyed by product_id.
     * @return boolean
     */
    private function has_unavailable_cart_items(array $items): bool
    {
        if ($this->cart_has_unavailable === null) {
            $this->cart_has_unavailable = !empty(MeprCartSessionService::get_unavailable_items($items));
        }
        return $this->cart_has_unavailable;
    }

    /**
     * Return an error message when any cart item fails the already-subscribed /
     * can_you_buy_me() gates (parity with classic signup), or false when every item
     * is purchasable. Memoized like has_unavailable_cart_items().
     *
     * @param  array                $items   Cart items keyed by product_id.
     * @param  MeprCartSession|null $session Optional session for the purchase filter.
     * @return string|false
     */
    private function unpurchasable_cart_items_message(array $items, $session = null)
    {
        if ($this->cart_unpurchasable_message === null) {
            $this->cart_unpurchasable_message = MeprCartSessionService::first_unpurchasable_message($items, $session);
        }

        return $this->cart_unpurchasable_message;
    }

    /**
     * Halt the AJAX request when the cart has unavailable or unpurchasable items.
     *
     * @param  array                $items   Cart items keyed by product_id.
     * @param  MeprCartSession|null $session Optional session for the purchase filter.
     * @return void
     */
    private function reject_if_cart_blocked(array $items, $session = null)
    {
        if ($this->has_unavailable_cart_items($items)) {
            wp_send_json_error(['message' => MeprCartSessionService::unavailable_cart_items_message()], 400);
        }

        $unpurchasable_message = $this->unpurchasable_cart_items_message($items, $session);
        if ($unpurchasable_message) {
            wp_send_json_error(['message' => $unpurchasable_message], 400);
        }
    }

    /**
     * Resolve the applied coupon from saved checkout data, or null when none/invalid.
     *
     * @param  array $checkout_data Checkout data (carries 'coupon_code').
     * @return MeprCoupon|null
     */
    private function resolve_coupon_from_data(array $checkout_data): ?MeprCoupon
    {
        $code = (string) ($checkout_data['coupon_code'] ?? '');

        // Stripped builds resolve to "no coupon"; downstream is null-safe. mepr:coupon-surface.
        if ($code === '' || !MeprFeatures::class_usable('MeprCoupon')) {
            return null;
        }

        $coupon = MeprCoupon::get_one_from_code($code);

        return $coupon instanceof MeprCoupon ? $coupon : null;
    }

    /**
     * Calculate sidebar totals for a cart session, keeping tax when billing is known.
     *
     * Prefer live POST billing/VAT (coupon AJAX sends them), else saved checkout_data
     * billing. Includes selected order bumps so coupon apply/remove don't wipe tax or
     * drop bump lines from the grand total.
     *
     * @param  MeprCartSession $session Current cart session.
     * @param  MeprCoupon|null $coupon  Coupon to apply, or null when none.
     * @return array
     */
    private function calculate_checkout_totals_for_session($session, $coupon = null)
    {
        $checkout_data = MeprCartCheckoutService::get_checkout_data($session);
        $billing       = isset($checkout_data['billing']) && is_array($checkout_data['billing'])
            ? $checkout_data['billing']
            : [];

        // phpcs:disable WordPress.Security.NonceVerification.Missing -- callers verify nonce first.
        $country  = isset($_POST['billing_country'])
            ? sanitize_text_field(wp_unslash($_POST['billing_country']))
            : (string) ($billing['country'] ?? '');
        $state    = isset($_POST['billing_state'])
            ? sanitize_text_field(wp_unslash($_POST['billing_state']))
            : (string) ($billing['state'] ?? '');
        $postcode = isset($_POST['billing_postcode'])
            ? sanitize_text_field(wp_unslash($_POST['billing_postcode']))
            : (string) ($billing['postcode'] ?? '');
        $city     = isset($_POST['billing_city'])
            ? sanitize_text_field(wp_unslash($_POST['billing_city']))
            : (string) ($billing['city'] ?? '');
        $street   = isset($_POST['billing_street'])
            ? sanitize_text_field(wp_unslash($_POST['billing_street']))
            : (string) ($billing['street'] ?? '');
        // phpcs:enable WordPress.Security.NonceVerification.Missing

        $items      = MeprCartSessionService::get_items($session);
        $bump_ids   = isset($checkout_data['bump_ids']) && is_array($checkout_data['bump_ids'])
            ? $checkout_data['bump_ids']
            : [];
        $bump_items = [];
        foreach ($bump_ids as $bump_id) {
            $bump_items[(int) $bump_id] = ['qty' => 1];
        }

        $tax_user = null;
        if (is_user_logged_in()) {
            $tax_user = new MeprUser(get_current_user_id());
        }

        $totals = MeprCartCheckoutService::calculate_totals(
            $items + $bump_items,
            $country,
            $state,
            $postcode,
            $city,
            $street,
            $coupon,
            MeprCurrencyService::get_active_currency(),
            $tax_user
        );

        $checkout_data = MeprCartCheckoutService::merge_tax_calculation_meta(
            $checkout_data,
            $totals
        );
        MeprCartCheckoutService::save_checkout_data($session, $checkout_data);

        return $totals;
    }

    /**
     * Register hooks for page rendering, script enqueueing, and all AJAX endpoints.
     *
     * @return void
     */
    public function load_hooks()
    {
        // Render checkout form via the_content filter (ReadyLaunch template takes over the page).
        add_filter('the_content', [$this, 'maybe_render_cart_checkout'], 10);

        // Step validation endpoint.
        add_action('wp_ajax_mepr_cart_checkout_validate_step', [$this, 'validate_step']);
        add_action('wp_ajax_nopriv_mepr_cart_checkout_validate_step', [$this, 'validate_step']);

        // Step save endpoint.
        add_action('wp_ajax_mepr_cart_checkout_save_step', [$this, 'save_step']);
        add_action('wp_ajax_nopriv_mepr_cart_checkout_save_step', [$this, 'save_step']);

        // Cart recalculate endpoint (totals, tax, shipping).
        add_action('wp_ajax_mepr_cart_recalculate', [$this, 'recalculate']);
        add_action('wp_ajax_nopriv_mepr_cart_recalculate', [$this, 'recalculate']);

        // Coupon endpoints — registered only while the coupons feature ships
        // (the sidebar coupon UI is gated the same way). mepr:coupon-surface.
        if (MeprFeatures::active('coupons')) {
            add_action('wp_ajax_mepr_cart_apply_coupon', [$this, 'apply_coupon']);
            add_action('wp_ajax_nopriv_mepr_cart_apply_coupon', [$this, 'apply_coupon']);
            add_action('wp_ajax_mepr_cart_remove_coupon', [$this, 'remove_coupon']);
            add_action('wp_ajax_nopriv_mepr_cart_remove_coupon', [$this, 'remove_coupon']);
        }

        // Payment-step mount config (no order/intent created).
        add_action('wp_ajax_mepr_cart_payment_config', [$this, 'payment_config']);
        add_action('wp_ajax_nopriv_mepr_cart_payment_config', [$this, 'payment_config']);

        // Order + Stripe PaymentIntent creation (deferred to Pay Now).
        add_action('wp_ajax_mepr_cart_create_payment_intent', [$this, 'create_payment_intent']);
        add_action('wp_ajax_nopriv_mepr_cart_create_payment_intent', [$this, 'create_payment_intent']);

        // Place order (post-payment confirmation).
        add_action('wp_ajax_mepr_cart_place_order', [$this, 'place_order']);
        add_action('wp_ajax_nopriv_mepr_cart_place_order', [$this, 'place_order']);

        // Sidebar update (qty/remove edits from invoice sidebar).
        add_action('wp_ajax_mepr_cart_update_sidebar', [$this, 'update_sidebar']);
        add_action('wp_ajax_nopriv_mepr_cart_update_sidebar', [$this, 'update_sidebar']);

        // Tax recalculation endpoint (dedicated — separate from general recalculate).
        add_action('wp_ajax_mepr_calculate_cart_tax', [$this, 'calculate_cart_tax']);
        add_action('wp_ajax_nopriv_mepr_calculate_cart_tax', [$this, 'calculate_cart_tax']);

        // Step index persistence endpoint (STEP-07) — saves current_step to cart session for resume.
        add_action('wp_ajax_mepr_cart_save_step', [$this, 'ajax_save_step']);
        add_action('wp_ajax_nopriv_mepr_cart_save_step', [$this, 'ajax_save_step']);

        // VAT number inline validation endpoint.
        add_action('wp_ajax_mepr_cart_validate_vat', [$this, 'validate_vat_number']);
        add_action('wp_ajax_nopriv_mepr_cart_validate_vat', [$this, 'validate_vat_number']);

        // Inline login endpoint (nopriv — guest AJAX).
        add_action('wp_ajax_nopriv_mepr_cart_checkout_login', [$this, 'inline_login']);
        add_action('wp_ajax_mepr_cart_checkout_login', [$this, 'inline_login']);

        // Enqueue scripts on frontend.
        add_action('wp_enqueue_scripts', [$this, 'enqueue_checkout_scripts']);

        // Template routing: empty-cart redirect + CL/non-CL mode handling.
        add_filter('template_include', [$this, 'override_checkout_template'], 999999);


        // Populate cart from ?product= URL param before coupon auto-apply reads the session.
        add_action('template_redirect', [$this, 'maybe_add_product_from_url']);
    }

    /**
     * Build the active checkout step array.
     *
     * Steps are defined here, filtered through `mepr_checkout_stages`, then any step
     * whose condition callable returns false is removed. The shipping step is conditional
     * on physical products being in the cart.
     *
     * Each step array:
     *   - id              (string)       Unique identifier for the step
     *   - label           (string)       Human-readable label for progress bar
     *   - view            (string)       Filename (without .php) relative to views/readylaunch/cart-checkout/steps/
     *   - condition       (callable|null) Callable returning bool; null means always shown
     *   - validate_action (string|null)  AJAX action name for step validation; null if N/A
     *
     * @return array Active steps with sequential numeric keys.
     */
    public function get_checkout_steps()
    {
        $session    = MeprCartSessionService::current_session();
        $cart_items = $session ? MeprCartSessionService::get_items($session) : [];
        return MeprCheckoutStepsHelper::get_effective_steps($cart_items);
    }

    /**
     * Determine whether the current cart contains any physical products.
     *
     * Used as the condition callable for the shipping step.
     *
     * @return boolean True if at least one physical product is in the cart.
     */
    public function cart_has_physical_products()
    {
        $session = MeprCartSessionService::current_session();

        if (!$session) {
            return false;
        }

        $items = MeprCartSessionService::get_items($session);

        foreach ($items as $product_id => $item) {
            $type = $item['product_type'] ?? MeprProduct::effective_type_for($product_id);
            if ($type === MeprProduct::TYPE_PHYSICAL) {
                return true;
            }
        }

        return false;
    }

    /**
     * The the_content filter: render the cart checkout form on the checkout page.
     *
     * If ReadyLaunch template_enabled('cart_checkout') is active, the ReadyLaunch
     * layout/app.php takes over page rendering. This filter still runs but the
     * content output is inside the ReadyLaunch layout. If ReadyLaunch is disabled,
     * the form renders inline as the post content.
     *
     * @param  string $content The original post content.
     * @return string Modified content with checkout form, or redirect.
     */
    public function maybe_render_cart_checkout($content)
    {
        global $post;

        $options = MeprOptions::fetch();

        // Only apply on the designated checkout page, or any page with slug "checkout" (fallback if setting is wrong/unset).
        $is_checkout_page = !empty($options->cart_checkout_page_id) && is_page($options->cart_checkout_page_id);
        $is_checkout_slug = is_singular('page') && $post && isset($post->post_name) && $post->post_name === 'checkout';
        if (!$is_checkout_page && !$is_checkout_slug) {
            return $content;
        }

        // Prevent running on excerpts, widgets, or secondary queries.
        // Note: do NOT use in_the_loop() — ReadyLaunch calls the_content() outside the WP loop.
        static $rendered = false;
        if ($rendered) {
            return $content;
        }
        $rendered = true;

        $session = MeprCartSessionService::current_session();

        // Empty cart — render a message with link back to shop/cart.
        // Note: we cannot wp_safe_redirect() here because the ReadyLaunch header
        // has already been output by the time the_content runs. The primary redirect
        // is handled earlier in the template_include filter (override_checkout_template).
        if (!$session || MeprCartSessionService::item_count($session) === 0) {
            $cart_url = $options->cart_page_url();
            return '<div class="mepr-cart-empty-notice">'
                . '<p>' . esc_html__('Your cart is empty.', 'memberpress') . '</p>'
                . '<a href="' . esc_url($cart_url) . '" class="mepr-btn mepr-btn--primary">'
                . esc_html__('Return to Cart', 'memberpress')
                . '</a></div>';
        }

        $steps = $this->get_checkout_steps();

        // Checkout mode: 'wizard' (default, step-by-step) or 'single' (all sections visible).
        $checkout_mode = MeprCheckoutStepsHelper::is_wizard_enabled() ? 'wizard' : 'single';

        // Retrieve persisted checkout data from session (returns [] if none).
        $checkout_data = MeprCartCheckoutService::get_checkout_data($session);

        // Current step: from checkout_data or default to first step.
        $current_step_id = isset($checkout_data['current_step']) ? $checkout_data['current_step'] : ($steps[0]['id'] ?? 'account');

        // Allow add-ons to clamp the restored step (e.g. funnels forces order_bumps before payment).
        $current_step_id = apply_filters('mepr_checkout_clamp_restore_step', $current_step_id, array_column($steps, 'id'), $session);

        // Auto-apply coupon from URL parameter (CHKT-09). Cold static lookups — skipped
        // entirely when the coupons feature is stripped. mepr:coupon-surface.
        if (!empty($_GET['coupon']) && empty($checkout_data['coupon_code']) && MeprFeatures::class_usable('MeprCoupon')) {
            $url_coupon_code = sanitize_text_field(wp_unslash($_GET['coupon']));
            $url_coupon      = MeprCoupon::get_one_from_code($url_coupon_code);
            if ($url_coupon instanceof MeprCoupon) {
                // Allow add-ons to block auto-apply (e.g. gift coupons must use product claim URL).
                $can_apply = MeprHooks::apply_filters('mepr_cart_apply_coupon', true, $url_coupon, $session, 'url');
                if (true === $can_apply) {
                    // Validate coupon applies to at least one cart item.
                    $items_check = MeprCartSessionService::get_items($session);
                    foreach ($items_check as $product_id => $item) {
                        if (MeprCoupon::is_valid_coupon_code($url_coupon_code, (int) $product_id)) {
                            $checkout_data['coupon_code']   = $url_coupon_code;
                            $checkout_data['coupon_notice'] = sprintf(
                                // Translators: %s: coupon code.
                                __('Coupon %s applied!', 'memberpress'),
                                $url_coupon_code
                            );
                            MeprCartCheckoutService::save_checkout_data($session, $checkout_data);
                            break;
                        }
                    }
                } elseif (is_wp_error($can_apply)) {
                    $checkout_data['coupon_notice'] = $can_apply->get_error_message();
                }
            }
        }

        // Allow add-ons to sync cart before sidebar/totals are built (e.g. auto-add required bumps).
        MeprHooks::do_action('mepr_cart_checkout_before_prepare', $session);

        // Cart items and totals for the invoice sidebar.
        $items = MeprCartSessionService::get_items($session);

        // Trashed/deleted products → full-page notice. Unpurchasable → keep form, alert + disable Pay.
        $has_unavailable_items = $this->has_unavailable_cart_items($items);

        // Already-subscribed / who-can-purchase — inline alert + disabled Pay (not a full-page takeover).
        $unpurchasable_message = $has_unavailable_items
            ? false
            : $this->unpurchasable_cart_items_message($items, $session);

        // Determine coupon for totals.
        $coupon = $this->resolve_coupon_from_data($checkout_data);

        // Detach an orphaned coupon on load (its product was removed in a prior action) so a reload
        // can't silently resurrect it. Quiet here — the removal action itself surfaces the modal.
        if ($coupon instanceof MeprCoupon && !MeprCartCheckoutService::coupon_applies_to_any_item($items, $coupon)) {
            unset($checkout_data['coupon_code']);
            MeprCartCheckoutService::save_checkout_data($session, $checkout_data);
            $coupon = null;
        }

        // Seed billing address for tax pre-calculation on page load.
        // Priority: saved checkout session → account-level user meta (logged-in only).
        $saved_billing   = isset($checkout_data['billing']) && is_array($checkout_data['billing']) ? $checkout_data['billing'] : [];
        // Restore saved VAT identity for this render (a page load carries no VAT POST),
        // so a later-step reload keeps B2B reverse charge. Live POST always wins.
        MeprCartCheckoutService::apply_vat_to_request($saved_billing, true);
        $billing_country  = $saved_billing['country']  ?? '';
        $billing_state    = $saved_billing['state']    ?? '';
        $billing_postcode = $saved_billing['postcode'] ?? '';
        $billing_city     = $saved_billing['city']     ?? '';
        $billing_street   = $saved_billing['street']   ?? '';
        if (empty($billing_country) && empty($billing_postcode) && is_user_logged_in()) {
            $mepr_user        = new MeprUser(get_current_user_id());
            $billing_country  = (string) $mepr_user->address('country', false);
            $billing_state    = (string) $mepr_user->address('state', false);
            $billing_postcode = (string) $mepr_user->address('zip', false);
            $billing_city     = (string) $mepr_user->address('city', false);
            $billing_street   = (string) $mepr_user->address('one', false);
        }
        // Billing known but tax not computable synchronously → sidebar paints the tax
        // spinner (the boot tax AJAX overwrites it); guests with no billing keep the
        // "Enter billing address" placeholder.
        $tax_pending = ($billing_country !== '');

        // Pass the logged-in user so U/D proration (maybe_line_proration) shapes line_base /
        // grand_total the same way the tax AJAX path already does.
        $checkout_user = is_user_logged_in() ? new MeprUser(get_current_user_id()) : null;
        $totals_data   = MeprCartCheckoutService::calculate_totals(
            $items,
            $billing_country,
            $billing_state,
            $billing_postcode,
            $billing_city,
            $billing_street,
            $coupon,
            MeprCurrencyService::get_active_currency(),
            $checkout_user
        );
        $subtotal       = $totals_data['subtotal'];
        $shipping_total = $totals_data['shipping_total'];
        $grand_total    = $totals_data['grand_total'];

        // Order bumps from the addon are legacy-registration-only.
        // Cart/funnel checkout uses funnel builder order_bump steps exclusively.
        $order_bumps        = [];
        $mandatory_bump_ids = [];

        // Build cart_items array for the sidebar view (with product_type and line_total).
        $cart_items = [];
        foreach ($totals_data['line_items'] as $line_item) {
            $pid          = $line_item['product_id'];
            $product      = new MeprProduct($pid);
            $product_type = $product->effective_type();
            $trial        = (bool) get_post_meta($pid, MeprProduct::$trial_str, true);
            $trial_days   = (int) get_post_meta($pid, MeprProduct::$trial_days_str, true);
            $trial_amount = (float) get_post_meta($pid, MeprProduct::$trial_amount_str, true);

            // Same as thank-you / Approach A: net line when inclusive tax has split,
            // listed otherwise. Coupon dollars stay in the Discount row.
            $paint_base = (float) $line_item['line_base'];

            $cart_items[$pid] = array_merge(
                $items[$pid] ?? [],
                [
                    'qty'          => $line_item['qty'],
                    'product_type' => $product_type,
                    'line_total'   => $paint_base,
                    'line_base'    => $paint_base,
                    'period'       => (int) get_post_meta($pid, MeprProduct::$period_str, true),
                    'period_type'  => (string) get_post_meta($pid, MeprProduct::$period_type_str, true),
                    'trial'        => $trial,
                    'trial_days'   => $trial_days,
                    'trial_amount' => $trial_amount,
                ]
            );
        }

        $gw_config          = MeprCartPaymentService::get_js_config();
        $available_gateways = $gw_config['available_gateways'];

        // With no cart gateway a free cart still checks out through the built-in free path.
        $free_without_gateway = empty($available_gateways)
            && MeprCartCheckoutService::is_free_checkout((float) $grand_total, $items, $coupon);

        // Pre-compute payment step template data here — templates must not query the DB.
        $is_logged_in = MeprUtils::is_user_logged_in();

        $has_recurring = false;
        foreach ($items as $product_id => $item_data) {
            if (get_post_meta((int) $product_id, '_mepr_product_billing_type', true) === 'recurring') {
                $has_recurring = true;
                break;
            }
        }

        $saved_methods  = [];
        $default_method = null;
        if ($is_logged_in) {
            // Filtered to the active-currency Stripe customer (GAP-MC-3) — same list the
            // payment-step AJAX payloads use, so the server render can never show a card
            // the current currency's customer can't charge.
            $saved_methods = MeprCartPaymentService::saved_methods_for_display(get_current_user_id());

            foreach ($saved_methods as $i => $method) {
                if (!empty($method['is_default'])) {
                    $default_method = $method;
                }
            }
            if (!$default_method && !empty($saved_methods)) {
                $saved_methods[0]['is_default'] = true;
                $default_method                 = $saved_methods[0];
            }
        }

        $currency_symbol = MeprCurrencyService::get_symbol(MeprCurrencyService::get_active_currency());

        $totals = $totals_data;

        // Coupon-aware billing terms per line for the sidebar (allocation-aware: lines a capped
        // coupon doesn't attach to render their terms without the coupon wording).
        $bylines = MeprCartCheckoutService::billing_bylines(
            $items,
            $coupon,
            null,
            $totals_data['line_items'] ?? [],
            $totals_data['tax_items'] ?? []
        );

        $vars = compact(
            'session',
            'items',
            'cart_items',
            'tax_pending',
            'steps',
            'checkout_mode',
            'current_step_id',
            'checkout_data',
            'subtotal',
            'shipping_total',
            'grand_total',
            'totals',
            'order_bumps',
            'mandatory_bump_ids',
            'is_logged_in',
            'has_recurring',
            'saved_methods',
            'default_method',
            'currency_symbol',
            'available_gateways',
            'free_without_gateway',
            'options',
            'has_unavailable_items',
            'unpurchasable_message',
            'bylines'
        );

        $vars['nonce']        = wp_create_nonce('mepr_cart_checkout_nonce');
        $vars['cart_url']     = $options->cart_page_url();
        $vars['thankyou_url'] = $options->thankyou_page_url();
        $vars['coupon_code']  = isset($checkout_data['coupon_code']) ? $checkout_data['coupon_code'] : '';

        // Coupon notice from URL ?coupon= auto-apply.
        $vars['coupon_notice'] = isset($checkout_data['coupon_notice']) ? $checkout_data['coupon_notice'] : '';

        // Render the checkout form view.
        return MeprView::get_string('/readylaunch/cart-checkout/form', $vars);
    }

    /**
     * States from MeprUtils::states() with the i18n HTML entities (e.g. &ntilde;) decoded to plain text.
     *
     * @return array
     */
    private function plain_text_states(): array
    {
        $states = [];
        foreach (MeprUtils::states() as $country => $labels) {
            $states[$country] = array_map(
                static function ($label) {
                    return html_entity_decode($label, ENT_QUOTES, 'UTF-8');
                },
                $labels
            );
        }
        return $states;
    }

    /**
     * Enqueue cart-checkout JS and CSS on the checkout page only.
     *
     * @return void
     */
    public function enqueue_checkout_scripts()
    {
        global $post;
        $options = MeprOptions::fetch();

        $on_checkout = (!empty($options->cart_checkout_page_id) && is_page($options->cart_checkout_page_id))
            || (is_singular('page') && $post && isset($post->post_name) && $post->post_name === 'checkout');
        if (!$on_checkout) {
            return;
        }

        // Dev cache-buster: in debug mode version assets by mtime so edits always reload.
        $css_ver = (defined('WP_DEBUG') && WP_DEBUG) ? (string) @filemtime(MEPR_CSS_PATH . '/cart-checkout.css') : MEPR_VERSION;
        $js_ver  = (defined('WP_DEBUG') && WP_DEBUG) ? (string) @filemtime(MEPR_JS_PATH . '/readylaunch/cart-checkout.js') : MEPR_VERSION;

        // Base theme CSS — enqueued independently so cart-checkout.css renders correctly
        // even when the ReadyLaunch full-page template is disabled. WordPress deduplicates
        // CSS — always enqueued (needed for the unavailable notice too).
        wp_enqueue_style('mp-pro-cart-checkout', MEPR_CSS_URL . '/cart-checkout.css', ['mepr-cart-tokens', 'mepr-ds-components'], $css_ver);

        // Password strength meter — guests only (logged-in buyers have no password fields).
        if (!is_user_logged_in() && MeprOptions::fetch()->enforce_strong_password) {
            wp_register_script('mepr-zxcvbn', MEPR_JS_URL . '/zxcvbn-async.js', ['jquery', 'zxcvbn-async'], $js_ver, true);
            wp_localize_script('mepr-zxcvbn', 'MeprZXCVBN', MeprZxcvbnCtrl::get_i18n_array());
            wp_enqueue_script('mepr-zxcvbn');
            wp_enqueue_style('mepr-zxcvbn-css', MEPR_CSS_URL . '/zxcvbn.css', [], $css_ver);
        }

        // Skip Stripe and checkout JS only when products are trashed/deleted (full-page notice).
        // Unpurchasable carts still render the form (wizard nav), with Pay disabled server-side.
        $enqueue_session = MeprCartSessionService::current_session();
        $enqueue_items   = $enqueue_session ? MeprCartSessionService::get_items($enqueue_session) : [];
        if ($this->has_unavailable_cart_items($enqueue_items)) {
            return;
        }

        // Enqueue Stripe.js if any globally configured gateway is Stripe.
        // Product-level filtering happens at render time when cart items are known.
        $gw_config  = MeprCartPaymentService::get_js_config();
        $has_stripe = !empty(array_filter($gw_config['available_gateways'], fn($gw) => $gw['key'] === 'stripe'));

        // Stripe.js — only enqueued when at least one Stripe gateway is configured.
        if ($has_stripe) {
            wp_enqueue_script('stripe-js', 'https://js.stripe.com/v3/', [], null);
        }

        $stripe_dep = $has_stripe ? ['jquery', 'stripe-js'] : ['jquery'];
        wp_enqueue_script('mepr-cart-checkoutjs', MEPR_JS_URL . '/readylaunch/cart-checkout.js', $stripe_dep, $js_ver, true);

        $steps         = $this->get_checkout_steps();
        $step_ids      = array_column($steps, 'id');
        $checkout_mode = MeprCheckoutStepsHelper::is_wizard_enabled() ? 'wizard' : 'single';

        $active_currency = MeprCurrencyService::get_active_currency();

        wp_localize_script('mepr-cart-checkoutjs', 'MeprCartCheckout', [
            'ajax_url'           => admin_url('admin-ajax.php'),
            'nonce'              => wp_create_nonce('mepr_cart_checkout_nonce'),
            'thankyou_url'       => $options->thankyou_page_url(),
            'cart_url'           => $options->cart_page_url(),
            'available_gateways' => $gw_config['available_gateways'],
            'currency'           => strtolower($active_currency),
            'currency_symbol'    => MeprCurrencyService::get_symbol($active_currency),
            'symbol_after'       => MeprCurrencyService::is_symbol_after($active_currency),
            'is_zero_decimal'    => MeprCurrencyService::is_zero_decimal($active_currency),
            // Tax recalc follows "Enable Tax Calculations" only — "Enable VAT" gates EU VAT UI, not tax math.
            'tax_enabled'        => (bool) get_option('mepr_calculate_taxes'),
            'tax_inclusive'      => (bool) MeprCartTaxService::is_inclusive(),
            'mode'               => $checkout_mode,
            'steps'              => implode(',', $step_ids),
            'payment_element_terms' => $has_stripe ? MeprStripeGateway::get_payment_element_terms() : new stdClass(),
            'i18n'               => [
                'tax'            => __('Tax', 'memberpress'),
                'subtotal'       => __('Subtotal', 'memberpress'),
                'discount'       => __('Discount', 'memberpress'),
                'tax_included'   => __('(included)', 'memberpress'),
                'enter_billing'  => __('Enter billing address', 'memberpress'),
                'tax_error'      => __('Tax could not be calculated. Please verify your billing address.', 'memberpress'),
                'reverse_charge' => __('Reverse Charge', 'memberpress'),
                'reverse_charge_suffix' => _x('reverse charge', 'tax line suffix when VAT is not collected', 'memberpress'),
                'coupon_empty'   => __('Please enter a coupon code.', 'memberpress'),
                'coupon_invalid' => __('Invalid coupon code.', 'memberpress'),
                'coupon_error'   => __('An error occurred. Please try again.', 'memberpress'),
                // Translators: %s: coupon code.
                'coupon_auto_removed' => __('Coupon "%s" was removed because it no longer applies to your cart.', 'memberpress'),
                'coupon_remove'       => __('Remove coupon', 'memberpress'),
                'coupon_toggle'       => __('Have a discount code?', 'memberpress'),
                'coupon_placeholder'  => __('Enter code', 'memberpress'),
                'coupon_code_label'   => __('Coupon code', 'memberpress'),
                'coupon_apply'        => __('Apply', 'memberpress'),
                'coupon_applying'     => __('Applying...', 'memberpress'),
                'dismiss'             => __('Dismiss', 'memberpress'),
                'generic_error'  => __('An error occurred. Please try again.', 'memberpress'),
                // Translators: %s: card last-4 digits.
                'ending_in'      => __('ending in %s', 'memberpress'),
                'use_new_method' => __('Use a new payment method', 'memberpress'),
                'tos_required'   => __('You must agree to the Terms of Service', 'memberpress'),
                'privacy_required' => __('You must agree to the Privacy Policy', 'memberpress'),
                // Translators: %s: checkout step label.
                'step_completed_back' => __('%s, completed — click to go back', 'memberpress'),
                'please_select_state' => __('-- Select State --', 'memberpress'),
                'processing'          => __('Processing...', 'memberpress'),
                'complete_order'      => __('Complete Order', 'memberpress'),
            ],
            // Same source as classic signup, decoded for the wizard's text-node option rendering.
            'states'                   => $this->plain_text_states(),
            'countries_without_states' => MeprUtils::get_countries_without_states(),
        ]);

        // Inline EU VAT country list for VAT field show/hide (static page-load data).
        if (get_option('mepr_calculate_taxes') && get_option('mepr_vat_enabled')) {
            $vat_ctrl      = MeprCtrlFactory::fetch('MeprVatTaxCtrl');
            $vat_countries = method_exists($vat_ctrl, 'get_vat_country_codes')
                ? $vat_ctrl->get_vat_country_codes()
                : [];
            wp_localize_script('mepr-cart-checkoutjs', 'meprVatCountries', $vat_countries);
        }

        // Enqueue intlTelInput for tel-type custom fields shown in cart checkout.
        $mepr_options = MeprOptions::fetch();
        $has_phone    = false;
        if (!empty($mepr_options->custom_fields)) {
            foreach ($mepr_options->custom_fields as $field) {
                $field_type = is_array($field) ? ($field['field_type'] ?? '') : ($field->field_type ?? '');
                if ($field_type === 'tel' && MeprCheckoutStepsHelper::is_checkout_custom_field_visible($field)) {
                    $has_phone = true;
                    break;
                }
            }
        }

        if ($has_phone) {
            wp_enqueue_style('mepr-phone-css', MEPR_CSS_URL . '/vendor/intlTelInput.min.css', [], MEPR_INTL_TEL_INPUT_CSS_VERSION);
            wp_enqueue_style('mepr-tel-config-css', MEPR_CSS_URL . '/tel_input.css', [], MEPR_VERSION);
            wp_enqueue_script('mepr-phone-js', MEPR_JS_URL . '/vendor/intlTelInput.js', [], MEPR_INTL_TEL_INPUT_VERSION, true);
            wp_enqueue_script('mepr-tel-config-js', MEPR_JS_URL . '/tel_input.js', ['mepr-phone-js', 'mepr-cart-checkoutjs'], MEPR_VERSION, true);
            wp_localize_script('mepr-tel-config-js', 'meprTel', MeprHooks::apply_filters('mepr_phone_input_config', MeprUtils::get_phone_input_config()));
        }
    }

    /**
     * Handle template routing for the cart checkout page.
     *
     * Performs the empty-cart redirect (must happen at template_include time, before
     * any output). When ReadyLaunch is disabled the theme's template is returned
     * unchanged — same pattern as memberpress-courses in non-classroom mode.
     * When ReadyLaunch is enabled, MeprReadyLaunchCtrl::override_page_templates()
     * already swapped the template; this method simply returns.
     *
     * @param  string $template Current template path.
     * @return string
     */
    public function override_checkout_template($template)
    {
        global $post;
        $options = MeprOptions::fetch();

        $on_checkout = (!empty($options->cart_checkout_page_id) && is_page($options->cart_checkout_page_id))
            || (is_singular('page') && $post && isset($post->post_name) && $post->post_name === 'checkout');
        if (!$on_checkout) {
            return $template;
        }

        // Empty cart — redirect to cart page BEFORE any output is sent.
        // This must happen here (template_include filter) rather than in the_content
        // filter, because by the time the_content runs the ReadyLaunch header has
        // already been output and wp_safe_redirect() would fail (headers already sent).
        $session = MeprCartSessionService::current_session();
        if (!$session || MeprCartSessionService::item_count($session) === 0) {
            $cart_url = $options->cart_page_url();
            wp_safe_redirect($cart_url);
            exit;
        }

        // When the ReadyLaunch cart-checkout template is disabled, let the theme handle
        // layout — same pattern as memberpress-courses' override_template() in non-classroom mode.
        if (!MeprReadyLaunchCtrl::template_enabled('cart_checkout')) {
            return $template;
        }

        // ReadyLaunch is active — MeprReadyLaunchCtrl::override_page_templates() already
        // handled the template swap at priority 999999; nothing more to do here.
        return $template;
    }

    // -------------------------------------------------------------------------
    // AJAX Endpoints
    // -------------------------------------------------------------------------

    /**
     * AJAX: Validate the fields for a given checkout step.
     *
     * Expects POST: step (string), nonce. Step-specific fields vary by step.
     * On success, persists step data to the cart session checkout_data.
     *
     * @return void Sends JSON response and exits.
     */
    public function validate_step()
    {
        if (!$this->verify_checkout_nonce()) {
            wp_send_json_error(['message' => __('Security check failed.', 'memberpress')], 403);
        }

        $step = isset($_POST['step']) ? sanitize_key(wp_unslash($_POST['step'])) : '';

        if (empty($step)) {
            wp_send_json_error(['message' => __('Invalid step.', 'memberpress')], 400);
        }

        $session = MeprCartSessionService::current_session();

        if (!$session) {
            wp_send_json_error(['message' => __('No active cart session.', 'memberpress')], 400);
        }

        $items = MeprCartSessionService::get_items($session);
        $this->reject_if_cart_blocked($items, $session);

        switch ($step) {
            case 'account':
                $this->validate_account_step($session);
                break;

            case 'billing':
                $this->validate_billing_step($session);
                break;

            case 'shipping':
                $this->validate_shipping_step($session);
                break;

            default:
                // Allow add-ons to validate custom steps (e.g. order_bumps required check).
                $addon_errors = apply_filters('mepr_checkout_step_validate_errors', [], $session, $step);
                if (!empty($addon_errors)) {
                    wp_send_json_error(['message' => reset($addon_errors)], 422);
                }
                // Handle custom field steps (your-details or admin-configured custom steps).
                $this->validate_custom_fields_step($session, $step);
                break;
        }
    }

    /**
     * Validate and process the account step.
     *
     * For guests: validate email + password, check for email collision, create account if valid.
     * For logged-in users: nothing to validate; persist current user data.
     *
     * @param  MeprCartSession $session The current cart session.
     * @return void Exits with JSON response.
     */
    private function validate_account_step(MeprCartSession $session)
    {
        if (MeprUtils::is_user_logged_in()) {
            // Logged-in users: persist their account data and move on.
            $current_user = wp_get_current_user();
            $step_data    = [
                'email'      => $current_user->user_email,
                'first_name' => $current_user->first_name,
                'last_name'  => $current_user->last_name,
            ];
            $this->merge_and_save_step($session, 'account', $step_data);
            wp_send_json_success([
                'message'   => __('Account verified.', 'memberpress'),
                'new_nonce' => wp_create_nonce('mepr_cart_checkout_nonce'),
            ]);
        }

        list($user_id, ) = $this->create_guest_account_or_bail($session);

        wp_send_json_success([
            'message'   => __('Account created successfully.', 'memberpress'),
            'user_id'   => $user_id,
            'new_nonce' => wp_create_nonce('mepr_cart_checkout_nonce'),
            'redirect'  => true,
        ]);
    }

    /**
     * Validate the guest account fields from $_POST and create the account, terminating with a
     * JSON error on any failure (field errors 422, email collision 409). Shared by the wizard
     * account step and the single-page payment entry points. When $align_request_cookies is true
     * the new login's cookie is also exposed to THIS request, so nonces minted afterwards verify
     * against the session the browser sends next.
     *
     * @param  MeprCartSession $session               The active cart session to merge into the account.
     * @param  boolean         $align_request_cookies Whether to expose the new login cookie to this request.
     * @return array{0: int, 1: MeprCartSession} The new user id and the merged session.
     */
    private function create_guest_account_or_bail(MeprCartSession $session, bool $align_request_cookies = false): array
    {
        $mepr_options = MeprOptions::fetch();
        // phpcs:disable WordPress.Security.NonceVerification.Missing -- nonce already verified in validate_step().
        $first_name       = isset($_POST['account']['first_name']) ? sanitize_text_field(wp_unslash($_POST['account']['first_name'])) : '';
        $last_name        = isset($_POST['account']['last_name']) ? sanitize_text_field(wp_unslash($_POST['account']['last_name'])) : '';
        $email            = isset($_POST['account']['email']) ? sanitize_email(wp_unslash($_POST['account']['email'])) : '';
        $password         = isset($_POST['account']['password']) ? wp_unslash($_POST['account']['password']) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
        $password_confirm = isset($_POST['account']['password_confirm']) ? wp_unslash($_POST['account']['password_confirm']) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
        // phpcs:enable WordPress.Security.NonceVerification.Missing

        // The disable_checkout_password_fields option: auto-generate password, skip field validation.
        if ($mepr_options->disable_checkout_password_fields) {
            $password         = wp_generate_password(24, true, true);
            $password_confirm = $password;
        }

        $errors = [];

        // Name fields honor the legacy "Name Fields: Require" setting.
        if ($mepr_options->require_fname_lname) {
            if (empty($first_name)) {
                $errors['first_name'] = __('First name is required.', 'memberpress');
            }

            if (empty($last_name)) {
                $errors['last_name'] = __('Last name is required.', 'memberpress');
            }
        }

        if (empty($email) || !is_email($email)) {
            $errors['email'] = __('A valid email address is required.', 'memberpress');
        }

        if (!$mepr_options->disable_checkout_password_fields) {
            if (empty($password) || strlen($password) < 6) {
                $errors['password'] = __('Password must be at least 6 characters.', 'memberpress');
            }

            if ($password !== $password_confirm) {
                $errors['password_confirm'] = __('Passwords do not match.', 'memberpress');
            }
        }

        // Math captcha guards guest account creation, reusing the legacy validator (HMAC-based,
        // stateless — works over AJAX; it no-ops for logged-in users).
        if ($mepr_options->enable_math_captcha) {
            $captcha_errors = MeprCtrlFactory::fetch('MeprMathCaptchaCtrl')->validate_answer([]);
            if (!empty($captcha_errors)) {
                $errors['mepr_math_quiz'] = reset($captcha_errors);
            }
        }

        // Minimum password strength, reusing the legacy validator (reads the client-computed
        // mp-pass-strength score). Skipped when passwords are auto-generated.
        if ($mepr_options->enforce_strong_password && !$mepr_options->disable_checkout_password_fields) {
            $strength_errors = MeprZxcvbnCtrl::validate_signup([]);
            if (!empty($strength_errors)) {
                $errors['password'] = reset($strength_errors);
            }
        }

        if (!empty($errors)) {
            wp_send_json_error([
                'message' => reset($errors),
                'errors'  => $errors,
            ], 422);
        }

        // Email collision check.
        if (email_exists($email)) {
            wp_send_json_error([
                'message'         => __('An account with this email already exists. Please log in to continue.', 'memberpress'),
                'email_collision' => true,
                'email'           => $email,
            ], 409);
        }

        // All valid — create the user account.
        $user_id = wp_create_user($email, $password, $email);

        if (is_wp_error($user_id)) {
            wp_send_json_error(['message' => $user_id->get_error_message()], 500);
        }

        // Set display name.
        wp_update_user([
            'ID'           => $user_id,
            'first_name'   => $first_name,
            'last_name'    => $last_name,
            'display_name' => trim($first_name . ' ' . $last_name),
        ]);

        // Send password reset notification when password was auto-generated.
        if ($mepr_options->disable_checkout_password_fields) {
            $mepr_new_user = new MeprUser($user_id);
            $mepr_new_user->send_password_notification('new');
        }

        // Fire autoresponder compat action (mirrors legacy MeprCheckoutCtrl pattern).
        $mepr_user_for_hooks = new MeprUser($user_id);
        MeprHooks::do_action('mepr_signup_user_loaded', $mepr_user_for_hooks);

        // The mepr_auto_login filter: allow integrations to block auto-login after account creation.
        // Pass 0 as product_id (cart has no single product) to match legacy filter signature.
        if (MeprHooks::apply_filters('mepr_auto_login', true, 0, $mepr_user_for_hooks)) {
            $expiration = time() + (int) apply_filters('auth_cookie_expiration', 2 * DAY_IN_SECONDS, $user_id, false);
            $token      = WP_Session_Tokens::get_instance($user_id)->create($expiration);

            wp_set_current_user($user_id);
            wp_set_auth_cookie($user_id, false, '', $token);

            if ($align_request_cookies) {
                // The wp_set_auth_cookie() function only queues Set-Cookie headers — expose the logged-in
                // cookie to the current request too so wp_create_nonce() uses this session token.
                $_COOKIE[LOGGED_IN_COOKIE] = wp_generate_auth_cookie($user_id, $expiration, 'logged_in', $token);
            }
        }

        // Preserve the guest's checkout_data (billing, coupon, bumps) — the merge below
        // destroys the guest session. The new user has none, so the guest values win.
        $guest_cart_raw      = json_decode($session->cart_data ?? '{}', true);
        $guest_checkout_data = is_array($guest_cart_raw) && isset($guest_cart_raw['checkout_data']) ? (array) $guest_cart_raw['checkout_data'] : [];

        // Merge guest cart into the new user's session.
        $new_session = MeprCartSessionService::merge_guest_into_user($session, $user_id);

        if (!empty($guest_checkout_data)) {
            $user_cart_raw      = json_decode($new_session->cart_data ?? '{}', true);
            $user_checkout_data = is_array($user_cart_raw) && isset($user_cart_raw['checkout_data']) ? (array) $user_cart_raw['checkout_data'] : [];
            MeprCartCheckoutService::save_checkout_data($new_session, array_merge($guest_checkout_data, $user_checkout_data));
        }

        $step_data = [
            'email'      => $email,
            'first_name' => $first_name,
            'last_name'  => $last_name,
        ];

        $this->merge_and_save_step($new_session, 'account', $step_data);

        return [$user_id, $new_session];
    }

    /**
     * Single-page mode posts the guest's account fields with the payment request — create the
     * account inline (legacy SPC parity) so a guest pays in one click. No-op for logged-in
     * buyers and for requests without account fields (the wizard never sends them here).
     */
    private function maybe_create_guest_account_inline(): void
    {
        if (is_user_logged_in()) {
            return;
        }

        // phpcs:disable WordPress.Security.NonceVerification.Missing -- nonce verified by the caller.
        if (empty($_POST['account']) || !is_array($_POST['account'])) {
            return;
        }
        // phpcs:enable WordPress.Security.NonceVerification.Missing

        $session = MeprCartSessionService::current_session();
        if (!$session) {
            wp_send_json_error(['message' => __('Could not initialize cart session.', 'memberpress')], 500);
        }

        $this->create_guest_account_or_bail($session, true);

        if (!is_user_logged_in()) {
            // An integration blocked auto-login (mepr_auto_login filter) — the account exists,
            // so a reload lands the buyer on the collision/login path to finish the purchase.
            wp_send_json_error([
                'message' => __('Your account was created. Please log in to complete your purchase.', 'memberpress'),
                'reload'  => true,
            ], 401);
        }
    }

    /**
     * Validate the billing step fields.
     *
     * Required: country, state, city, postcode. Street is optional.
     *
     * @param  MeprCartSession $session The current cart session.
     * @return void Exits with JSON response.
     */
    private function validate_billing_step(MeprCartSession $session)
    {
        // phpcs:disable WordPress.Security.NonceVerification.Missing -- nonce already verified in validate_step().
        $billing = isset($_POST['billing']) && is_array($_POST['billing']) ? wp_unslash($_POST['billing']) : []; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
        // phpcs:enable WordPress.Security.NonceVerification.Missing

        $country  = isset($billing['country']) ? sanitize_text_field($billing['country']) : '';
        $state    = isset($billing['state']) ? sanitize_text_field($billing['state']) : '';
        $city     = isset($billing['city']) ? sanitize_text_field($billing['city']) : '';
        $postcode = isset($billing['postcode']) ? sanitize_text_field($billing['postcode']) : '';
        $street   = isset($billing['street']) ? sanitize_text_field($billing['street']) : '';

        $errors = [];

        // Determine whether full address validation is required based on tax/product config.
        $cart_items         = MeprCartSessionService::get_items($session);
        $needs_full_address = MeprCheckoutStepsHelper::needs_full_address($cart_items);

        if ($needs_full_address) {
            if (empty($country)) {
                $errors['country'] = __('Country is required.', 'memberpress');
            }

            // Match classic signup: countries without provinces skip the state requirement.
            $state_required = !in_array($country, MeprUtils::get_countries_without_states(), true);
            if ($state_required && empty($state)) {
                $errors['state'] = __('State / Province is required.', 'memberpress');
            }

            if (empty($city)) {
                $errors['city'] = __('City is required.', 'memberpress');
            }
        }

        // Street matches classic signup mepr-address-one (required => require_address_fields).
        if (MeprOptions::fetch()->require_address_fields && empty($street)) {
            $errors['street'] = __('Street address is required.', 'memberpress');
        }

        // Postal code is always required (needed for Stripe payment verification).
        if (empty($postcode)) {
            $errors['postcode'] = __('Postal code is required.', 'memberpress');
        }

        if (!empty($errors)) {
            wp_send_json_error([
                'message' => reset($errors),
                'errors'  => $errors,
            ], 422);
        }

        $step_data = compact('country', 'state', 'city', 'postcode', 'street');
        $this->merge_and_save_step($session, 'billing', $step_data);

        // HOOK: add-ons persist any wizard-step data that must survive to place_order().
        // phpcs:disable WordPress.Security.NonceVerification.Missing -- nonce already verified in validate_step().
        MeprHooks::do_action('mepr_checkout_billing_step_saved', $_POST, $session);
        // phpcs:enable WordPress.Security.NonceVerification.Missing

        wp_send_json_success([
            'message'   => __('Billing address saved.', 'memberpress'),
            'new_nonce' => wp_create_nonce('mepr_cart_checkout_nonce'),
        ]);
    }

    /**
     * Validate the shipping step fields.
     *
     * If same_as_billing is checked, no field validation needed — just persist the flag.
     * Otherwise, validate all shipping fields.
     *
     * @param  MeprCartSession $session The current cart session.
     * @return void Exits with JSON response.
     */
    private function validate_shipping_step(MeprCartSession $session)
    {
        // phpcs:disable WordPress.Security.NonceVerification.Missing -- nonce already verified in validate_step().
        $shipping = isset($_POST['shipping']) && is_array($_POST['shipping']) ? wp_unslash($_POST['shipping']) : []; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
        // phpcs:enable WordPress.Security.NonceVerification.Missing

        $same_as_billing = !empty($shipping['same_as_billing']);

        if ($same_as_billing) {
            $this->merge_and_save_step($session, 'shipping', ['same_as_billing' => true]);
            wp_send_json_success([
                'message'   => __('Shipping address saved.', 'memberpress'),
                'new_nonce' => wp_create_nonce('mepr_cart_checkout_nonce'),
            ]);
        }

        $street   = isset($shipping['street']) ? sanitize_text_field($shipping['street']) : '';
        $city     = isset($shipping['city']) ? sanitize_text_field($shipping['city']) : '';
        $state    = isset($shipping['state']) ? sanitize_text_field($shipping['state']) : '';
        $postcode = isset($shipping['postcode']) ? sanitize_text_field($shipping['postcode']) : '';
        $country  = isset($shipping['country']) ? sanitize_text_field($shipping['country']) : '';

        $errors = [];

        if (empty($street)) {
            $errors['street'] = __('Street address is required.', 'memberpress');
        }

        if (empty($city)) {
            $errors['city'] = __('City is required.', 'memberpress');
        }

        if (empty($state)) {
            $errors['state'] = __('State / Province is required.', 'memberpress');
        }

        if (empty($postcode)) {
            $errors['postcode'] = __('Postal code is required.', 'memberpress');
        }

        if (empty($country)) {
            $errors['country'] = __('Country is required.', 'memberpress');
        }

        if (!empty($errors)) {
            wp_send_json_error([
                'message' => reset($errors),
                'errors'  => $errors,
            ], 422);
        }

        $step_data = compact('street', 'city', 'state', 'postcode', 'country', 'same_as_billing');
        $this->merge_and_save_step($session, 'shipping', $step_data);

        wp_send_json_success([
            'message'   => __('Shipping address saved.', 'memberpress'),
            'new_nonce' => wp_create_nonce('mepr_cart_checkout_nonce'),
        ]);
    }

    /**
     * Validate a custom fields step (your-details or admin-configured custom step).
     *
     * Validates any required custom fields assigned to the step. Persists the
     * custom field values to checkout_data under the step ID key.
     *
     * @param  MeprCartSession $session The current cart session.
     * @param  string          $step_id The step identifier (e.g., 'your-details', 'company-info').
     * @return void Exits with JSON response.
     */
    private function validate_custom_fields_step(MeprCartSession $session, string $step_id): void
    {
        // Find the step config to get field_keys.
        $cart_items  = MeprCartSessionService::get_items($session);
        $all_steps   = MeprCheckoutStepsHelper::get_effective_steps($cart_items);
        $step_config = null;
        foreach ($all_steps as $step) {
            if ($step['id'] === $step_id) {
                $step_config = $step;
                break;
            }
        }

        $field_keys = ($step_config && !empty($step_config['field_keys'])) ? $step_config['field_keys'] : [];

        // A custom-fields step always owns a non-empty field_keys list. Any other step that lands here
        // (e.g. order_bumps, which the default case also routes through) has none — without this guard
        // the loop below treats "no keys" as "all keys" and wrongly requires every custom field.
        if (empty($field_keys)) {
            wp_send_json_success([
                'message'   => __('Step validated.', 'memberpress'),
                'new_nonce' => wp_create_nonce('mepr_cart_checkout_nonce'),
            ]);
        }

        $mepr_options = MeprOptions::fetch();
        $errors       = [];
        $step_data    = [];

        $user_id = get_current_user_id();
        $to_save = [];

        foreach ($mepr_options->custom_fields as $line) {
            // Only fields with Show at Checkout (show_on_signup) are cart-eligible.
            if (!MeprCheckoutStepsHelper::is_checkout_custom_field_visible($line)) {
                continue;
            }
            if (!empty($field_keys) && !in_array($line->field_key, $field_keys, true)) {
                continue;
            }

            // phpcs:disable WordPress.Security.NonceVerification.Missing -- nonce already verified in validate_step().
            $raw = isset($_POST[ $line->field_key ]) ? wp_unslash($_POST[ $line->field_key ]) : null; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
            // phpcs:enable WordPress.Security.NonceVerification.Missing

            // Type-aware emptiness: file uploads ($_FILES) and array fields (checkboxes/multiselect)
            // are not plain strings, so a scalar check would wrongly flag a filled field as empty.
            if ($line->field_type === 'file') {
                $has_upload = isset($_FILES[ $line->field_key ]['error']) && (int) $_FILES[ $line->field_key ]['error'] !== UPLOAD_ERR_NO_FILE;
                $is_empty   = !$has_upload && (string) get_user_meta($user_id, $line->field_key, true) === '';
            } elseif (is_array($raw)) {
                $is_empty = empty(array_filter($raw, static function ($v) {
                    return $v !== '';
                }));
            } else {
                $is_empty = (trim((string) $raw) === '');
            }

            if ($line->required && $is_empty) {
                // Translators: %s: field name.
                $errors[ $line->field_key ] = sprintf(__('%s is required.', 'memberpress'), stripslashes($line->field_name));
                continue;
            }

            $to_save[] = $line;
            // Keep the value for step prefill on back-navigation (arrays preserved as-is).
            $step_data[ $line->field_key ] = is_array($raw) ? $raw : sanitize_text_field((string) $raw);
        }

        if (!empty($errors)) {
            wp_send_json_error([
                'message' => reset($errors),
                'errors'  => $errors,
            ], 422);
        }

        // Persist in-request via the shared type-aware saver (arrays, file uploads, etc.), mirroring
        // the legacy non-SPC signup which saves fields before payment. The user already exists here
        // (created on the Account step, or logged in), since custom steps follow the Account step.
        if ($user_id > 0) {
            $saved = [];
            foreach ($to_save as $line) {
                MeprUsersCtrl::save_custom_field_value($user_id, $line);
                $saved[ $line->field_key ] = isset($_POST[ $line->field_key ]) ? wp_unslash($_POST[ $line->field_key ]) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
            }
            if (!empty($saved)) {
                MeprHooks::do_action('mepr_cart_checkout_save_custom_fields', $user_id, $saved, $session);
            }
        }

        $this->merge_and_save_step($session, $step_id, $step_data);

        wp_send_json_success([
            'message'   => __('Details saved.', 'memberpress'),
            'new_nonce' => wp_create_nonce('mepr_cart_checkout_nonce'),
        ]);
    }

    /**
     * Verify the checkout nonce with fallback for guest-to-user transitions.
     *
     * WordPress nonces are tied to the user ID. After a guest creates an account
     * on the Account step, the user identity changes but the browser's auth cookie
     * may not be sent with the next AJAX request yet (race condition). When the
     * standard nonce check fails, we fall back to verifying a valid cart session
     * exists — the cart session cookie (HttpOnly + SameSite=Lax) provides CSRF
     * protection equivalent to a nonce.
     *
     * @return boolean True if the request is verified, false if both checks fail.
     */
    private function verify_checkout_nonce(): bool
    {
        // Standard WP nonce check — works for same-user requests.
        if (check_ajax_referer('mepr_cart_checkout_nonce', 'nonce', false)) {
            return true;
        }

        // Fallback only for step-transition actions where the nonce may have
        // rotated immediately after account creation/inline login.
        // Allow session-based fallback for non-payment actions (nonce may have
        // rotated after account creation in step 1). Payment-critical actions
        // (place_order, create_payment_intent) MUST always have a valid nonce.
        $action          = isset($_POST['action']) ? sanitize_key(wp_unslash($_POST['action'])) : '';
        $blocked_actions = ['mepr_cart_place_order', 'mepr_cart_create_payment_intent'];
        if (in_array($action, $blocked_actions, true)) {
            return false;
        }

        // Verify a valid cart session with items — the mepr_cart cookie is
        // HttpOnly + SameSite=Lax so it cannot be sent cross-origin.
        $session = MeprCartSessionService::current_session();
        if ($session && MeprCartSessionService::item_count($session) > 0) {
            return true;
        }

        return false;
    }

    /**
     * Terminates the request with a 403 if the current IP is blocked by anti-fraud.
     * Called at the top of both create_payment_intent() and place_order().
     */
    private function check_anti_fraud_or_bail(): void
    {
        $options = MeprOptions::fetch();
        if ($options->anti_card_testing_enabled) {
            $ctrl = MeprCtrlFactory::fetch('MeprAntiCardTestingCtrl');
            if ($ctrl->is_ip_blocked()) {
                wp_send_json_error([
                    'message' => __('We are not able to complete your purchase at this time. Please contact us for more information.', 'memberpress'),
                ], 403);
            }
        }
    }

    /**
     * Terminates the request with a 422 when a required Terms of Service or Privacy
     * Policy acceptance is missing. Same settings and field names as the legacy
     * registration form; callers verify the nonce first.
     */
    private function validate_purchase_consents(): void
    {
        $mepr_options = MeprOptions::fetch();

        // phpcs:disable WordPress.Security.NonceVerification.Missing -- nonce verified by the caller.
        if ($mepr_options->require_tos && empty($_POST['mepr_agree_to_tos'])) {
            wp_send_json_error(['message' => __('You must agree to the Terms of Service', 'memberpress')], 422);
        }

        if (
            $mepr_options->require_privacy_policy
            && MeprAppHelper::privacy_policy_page_link()
            && empty($_POST['mepr_agree_to_privacy_policy'])
        ) {
            wp_send_json_error(['message' => __('You must agree to the Privacy Policy', 'memberpress')], 422);
        }
        // phpcs:enable WordPress.Security.NonceVerification.Missing
    }

    /**
     * Merge step data into the existing checkout_data and persist it.
     *
     * Uses MeprCartCheckoutService::get_checkout_data() and save_checkout_data()
     * to ensure the 'items' key in cart_data is never overwritten.
     *
     * @param  MeprCartSession $session   The current cart session.
     * @param  string          $step_id   The step identifier ('account', 'billing', etc.).
     * @param  array           $step_data The step-specific data to persist.
     * @return void
     */
    private function merge_and_save_step(MeprCartSession $session, string $step_id, array $step_data): void
    {
        $existing           = MeprCartCheckoutService::get_checkout_data($session);
        $existing[$step_id] = $step_data;
        MeprCartCheckoutService::save_checkout_data($session, $existing);
    }

    /**
     * AJAX: Save step data to the cart session (checkout_data JSON field).
     *
     * Saves without validation — used for back-navigation data preservation.
     * Expects POST: step (string), data (array of step fields), nonce.
     *
     * @return void Sends JSON response and exits.
     */
    public function save_step()
    {
        if (!$this->verify_checkout_nonce()) {
            wp_send_json_error(['message' => __('Security check failed.', 'memberpress')], 403);
        }

        $step = isset($_POST['step']) ? sanitize_key(wp_unslash($_POST['step'])) : '';

        if (empty($step)) {
            wp_send_json_success(); // Fire-and-forget; no step = nothing to save.
        }

        $session = MeprCartSessionService::current_session();

        if (!$session) {
            wp_send_json_success(); // No session — silently succeed (fire-and-forget).
        }

        // Build allowed steps dynamically: built-in steps + any custom field steps.
        $cart_items    = MeprCartSessionService::get_items($session);
        $active_steps  = MeprCheckoutStepsHelper::get_effective_steps($cart_items);
        $allowed_steps = array_column($active_steps, 'id');

        if (!in_array($step, $allowed_steps, true)) {
            wp_send_json_success(); // Unknown step — silently succeed.
        }

        // Sanitize the incoming step data. We accept a flat array of text fields.
        // phpcs:disable WordPress.Security.NonceVerification.Missing -- nonce already verified above.
        $raw_data = isset($_POST['data']) && is_array($_POST['data']) ? wp_unslash($_POST['data']) : []; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
        // phpcs:enable WordPress.Security.NonceVerification.Missing

        // Apply sanitize_text_field only to scalar values; skip nested arrays.
        $clean_data = [];
        foreach ($raw_data as $key => $value) {
            if (is_string($value)) {
                $clean_data[ sanitize_key($key) ] = sanitize_text_field($value);
            }
        }

        $this->merge_and_save_step($session, $step, $clean_data);

        wp_send_json_success();
    }

    /**
     * AJAX: Persist current step index to cart session checkout_data.
     *
     * Called from JS after each successful step transition so that navigating away
     * and returning restores the user to their last step (STEP-07).
     *
     * Expects POST: step_id (string), nonce.
     *
     * @return void Sends JSON response and exits.
     */
    public function ajax_save_step()
    {
        check_ajax_referer('mepr_cart_checkout_nonce', 'nonce');

        // phpcs:disable WordPress.Security.NonceVerification.Missing -- nonce already verified above.
        $step_id = isset($_POST['step_id']) ? sanitize_text_field(wp_unslash($_POST['step_id'])) : 'account';
        // phpcs:enable WordPress.Security.NonceVerification.Missing

        $session = MeprCartSessionService::current_session();

        if ($session) {
            $checkout_data                 = MeprCartCheckoutService::get_checkout_data($session);
            $checkout_data['current_step'] = $step_id;
            MeprCartCheckoutService::save_checkout_data($session, $checkout_data);

            // Notify add-ons when a step becomes active (e.g. funnels marks order_bumps_shown).
            do_action('mepr_checkout_step_persisted', $step_id, $session);
        }

        wp_send_json_success(['current_step' => $step_id]);
    }

    /**
     * AJAX: Inline login during checkout when email collision is detected.
     *
     * Expects POST: email (string), password (string), nonce.
     * On success, logs the user in, merges guest cart, and returns success.
     * Client-side will reload the checkout page.
     *
     * @return void Sends JSON response and exits.
     */
    public function inline_login()
    {
        if (!$this->verify_checkout_nonce()) {
            wp_send_json_error(['message' => __('Security check failed.', 'memberpress')], 403);
        }

        // phpcs:disable WordPress.Security.NonceVerification.Missing -- nonce already verified above.
        $email    = isset($_POST['email']) ? sanitize_email(wp_unslash($_POST['email'])) : '';
        $password = isset($_POST['password']) ? wp_unslash($_POST['password']) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
        // phpcs:enable WordPress.Security.NonceVerification.Missing

        if (empty($email) || empty($password)) {
            wp_send_json_error(['message' => __('Email and password are required.', 'memberpress')], 422);
        }

        $user = get_user_by('email', $email);

        if (!$user) {
            wp_send_json_error(['message' => __('Invalid email or password.', 'memberpress')], 401);
        }

        $result = wp_authenticate_username_password(null, $user->user_login, $password);

        if (is_wp_error($result)) {
            wp_send_json_error(['message' => __('Invalid email or password.', 'memberpress')], 401);
        }

        // Preserve guest's checkout_data before merge destroys the guest session.
        $guest_session       = MeprCartSessionService::current_session();
        $guest_checkout_data = [];
        if ($guest_session && !$guest_session->user_id) {
            $guest_cart_raw      = json_decode($guest_session->cart_data ?? '{}', true);
            $guest_checkout_data = $guest_cart_raw['checkout_data'] ?? [];
        }

        // Merge guest cart into user session.
        if ($guest_session && !$guest_session->user_id) {
            MeprCartSessionService::merge_guest_into_user($guest_session, $user->ID);
        }

        // Merge guest checkout_data into user session: guest fills gaps, user data takes precedence.
        if (!empty($guest_checkout_data)) {
            $user_session_after = MeprCartSessionService::current_session();
            if ($user_session_after) {
                $user_cart_raw      = json_decode($user_session_after->cart_data ?? '{}', true);
                $user_checkout_data = $user_cart_raw['checkout_data'] ?? [];
                $merged_checkout    = array_merge($guest_checkout_data, $user_checkout_data);
                MeprCartCheckoutService::save_checkout_data($user_session_after, $merged_checkout);
            }
        }

        // Log the user in.
        wp_set_current_user($user->ID);
        wp_set_auth_cookie($user->ID);

        wp_send_json_success([
            'message'   => __('Logged in successfully.', 'memberpress'),
            'redirect'  => true,
            'new_nonce' => wp_create_nonce('mepr_cart_checkout_nonce'),
        ]);
    }

    /**
     * AJAX: Recalculate cart totals (tax, shipping, discounts) and return updated sidebar data.
     *
     * Expects POST: nonce. Optional: billing_country, billing_state, billing_postcode, billing_city, bump_ids[].
     *
     * @return void Sends JSON response and exits.
     */
    public function recalculate()
    {
        if (!$this->verify_checkout_nonce()) {
            wp_send_json_error(['message' => __('Security check failed.', 'memberpress')], 403);
        }

        $session = MeprCartSessionService::current_session();

        if (!$session) {
            wp_send_json_error(['message' => __('No active cart session.', 'memberpress')], 400);
        }

        // phpcs:disable WordPress.Security.NonceVerification.Missing -- nonce already checked above.
        $country  = isset($_POST['billing_country'])  ? sanitize_text_field(wp_unslash($_POST['billing_country'])) : '';
        $state    = isset($_POST['billing_state'])    ? sanitize_text_field(wp_unslash($_POST['billing_state'])) : '';
        $postcode = isset($_POST['billing_postcode']) ? sanitize_text_field(wp_unslash($_POST['billing_postcode'])) : '';
        $city     = isset($_POST['billing_city'])     ? sanitize_text_field(wp_unslash($_POST['billing_city'])) : '';
        $street   = isset($_POST['billing_street'])   ? sanitize_text_field(wp_unslash($_POST['billing_street'])) : '';
        $bump_ids = isset($_POST['bump_ids']) && is_array($_POST['bump_ids']) ? array_map('intval', wp_unslash($_POST['bump_ids'])) : [];
        // phpcs:enable WordPress.Security.NonceVerification.Missing

        // Get cart items.
        $items = MeprCartSessionService::get_items($session);
        $this->reject_if_cart_blocked($items, $session);

        // Retrieve coupon from checkout_data if set.
        $checkout_data = MeprCartCheckoutService::get_checkout_data($session);
        $coupon        = $this->resolve_coupon_from_data($checkout_data);

        // Include bump items in calculation if bump_ids provided.
        $bump_items = [];
        if (!empty($bump_ids)) {
            foreach ($bump_ids as $bump_id) {
                $bump_items[$bump_id] = ['qty' => 1];
            }
        }

        // Use union operator (+) to preserve numeric product ID keys.
        // array_merge() re-indexes numeric keys, losing product IDs.
        $all_items = $items + $bump_items;

        $checkout_user = is_user_logged_in() ? new MeprUser(get_current_user_id()) : null;
        $totals        = MeprCartCheckoutService::calculate_totals(
            $all_items,
            $country,
            $state,
            $postcode,
            $city,
            $street,
            $coupon,
            MeprCurrencyService::get_active_currency(),
            $checkout_user
        );

        // Save updated billing data to checkout_data.
        if (!empty($country) || !empty($state) || !empty($postcode) || !empty($city) || !empty($street)) {
            $checkout_data['billing']  = array_merge(
                isset($checkout_data['billing']) ? $checkout_data['billing'] : [],
                compact('country', 'state', 'postcode', 'city', 'street')
            );
            $checkout_data['bump_ids'] = $bump_ids;
            $checkout_data = MeprCartCheckoutService::merge_tax_calculation_meta($checkout_data, $totals);
            MeprCartCheckoutService::save_checkout_data($session, $checkout_data);
        }

        // If a PaymentIntent already exists for this session, update its amount so it
        // matches the new sidebar total (Pitfall 5: PaymentIntent mismatch).
        $existing_pi_id  = isset($checkout_data['payment_intent_id']) ? $checkout_data['payment_intent_id'] : '';
        $order_id_for_pi = isset($checkout_data['order_id']) ? (int) $checkout_data['order_id'] : 0;
        if (!empty($existing_pi_id) && $order_id_for_pi > 0) {
            try {
                // Skip PI amount sync for offline gateway — no PaymentIntent exists.
                $active_gw = MeprCartPaymentService::supports_upsells()
                    ? MeprCartPaymentService::get_active_gateway()
                    : null;
                if ($active_gw instanceof MeprStripeGateway) {
                    $active_gw->send_stripe_request(
                        "payment_intents/{$existing_pi_id}",
                        ['amount' => (int) $active_gw->to_zero_decimal_amount($totals['grand_total'], MeprCurrencyService::get_active_currency())],
                        'post'
                    );
                }
            } catch (Exception $e) {
                // Non-fatal: log silently, totals still returned to client.
            }
        }

        // $totals includes subtotal, discount_total, tax_total, tax_items, shipping_total,
        // grand_total, and line_items — tax_items array is used by the sidebar JS (Plan 03).
        $totals['bylines'] = MeprCartCheckoutService::billing_bylines(
            $all_items,
            $coupon,
            $checkout_user,
            $totals['line_items'] ?? [],
            $totals['tax_items'] ?? []
        );
        wp_send_json_success(self::add_formatted_totals($totals));
    }

    /**
     * Add display strings to a totals payload, the way MeprCartCtrl does for the cart page.
     *
     * The sidebar repaints these after every recalc, and formatting them here keeps
     * MeprAppHelper::format_currency() the only place that knows about symbols, placement,
     * separators and zero-decimal rounding.
     *
     * Public so add-ons that answer the sidebar's repaint with their own totals payload can
     * reuse it. Anything handed to MeprCartCheckout.updateTotalsDisplay() should pass through
     * here, or the JS falls back to formatting in the visitor's browser locale.
     *
     * @param array $totals The totals returned by calculate_totals().
     *
     * @return array The same array with *_formatted siblings added.
     */
    public static function add_formatted_totals(array $totals)
    {
        $currency = MeprCurrencyService::get_active_currency();

        foreach (['subtotal', 'discount_total', 'tax_total', 'shipping_total', 'grand_total'] as $key) {
            if (isset($totals[$key])) {
                $totals[$key . '_formatted'] = MeprAppHelper::format_currency_for_json((float) $totals[$key], true, false, false, $currency);
            }
        }

        if (!empty($totals['line_items']) && is_array($totals['line_items'])) {
            foreach ($totals['line_items'] as $i => $line) {
                // The sidebar shows line_base when present, so format whichever it will paint.
                $amount = isset($line['line_base']) ? $line['line_base'] : ($line['line_total'] ?? null);

                if ($amount !== null) {
                    $totals['line_items'][$i]['line_total_formatted'] = MeprAppHelper::format_currency_for_json((float) $amount, true, false, false, $currency);
                }
            }
        }

        if (!empty($totals['tax_items']) && is_array($totals['tax_items'])) {
            foreach ($totals['tax_items'] as $i => $item) {
                if (isset($item['amount'])) {
                    $totals['tax_items'][$i]['amount_formatted'] = MeprAppHelper::format_currency_for_json((float) $item['amount'], true, false, false, $currency);
                }
            }
        }

        $totals['zero_formatted'] = MeprAppHelper::format_currency_for_json(0, true, false, false, $currency);

        return $totals;
    }

    /**
     * The template_redirect handler: add a product to the cart session when ?product= is present.
     *
     * This fires before the coupon auto-apply (which reads the session on template_redirect)
     * so the product is in the cart when ?coupon= validation runs. Designed for the
     * Special Offers "Get This Deal" links that include both ?product= and ?coupon= params.
     *
     * Only operates on the configured cart checkout page. Creates a new session if
     * none exists. Skips silently if the product is already in the cart.
     *
     * When ATC is blocked (purchase gate / add_item failure), redirects to the product
     * permalink instead of leaving the user on empty checkout → cart. The product page
     * already surfaces cant-purchase via can_you_buy_me UI.
     *
     * @return void
     */
    public function maybe_add_product_from_url(): void
    {
        // Only on the checkout page.
        $options          = MeprOptions::fetch();
        $is_checkout_page = !empty($options->cart_checkout_page_id) && is_page($options->cart_checkout_page_id);
        $is_checkout_slug = is_singular('page') && ($GLOBALS['post'] ?? null) && ($GLOBALS['post']->post_name ?? '') === 'checkout';

        if (!$is_checkout_page && !$is_checkout_slug) {
            return;
        }

        // phpcs:ignore WordPress.Security.NonceVerification.Recommended
        if (empty($_GET['product'])) {
            return;
        }

        // phpcs:ignore WordPress.Security.NonceVerification.Recommended
        $product_id = absint($_GET['product']);
        if ($product_id < 1) {
            return;
        }

        // Validate that the product actually exists before adding to cart.
        $product = new MeprProduct($product_id);
        if (!isset($product->ID) || (int) $product->ID <= 0) {
            return;
        }

        $session = MeprCartSessionService::current_session();
        if (!$session) {
            return;
        }

        // Only add if not already in cart.
        $items = MeprCartSessionService::get_items($session);
        if (!isset($items[$product_id])) {
            $user_id = is_user_logged_in() ? get_current_user_id() : null;
            $result  = MeprCartSessionService::add_item($session, $product_id, 1, $user_id);

            if (empty($result['success'])) {
                $this->redirect_blocked_url_product_add($product);
            }
        }
    }

    /**
     * Redirect after a blocked checkout/?product= ATC attempt.
     *
     * Prefer the product's single/register permalink (not $product->url(), which can
     * loop back to checkout/?product= when registration page is off). Fall back to the
     * cart page, then home, when the permalink cannot be resolved.
     *
     * @param MeprProduct $product Product that failed to add.
     */
    private function redirect_blocked_url_product_add($product)
    {
        $redirect = MeprUtils::get_permalink((int) $product->ID);

        if (empty($redirect)) {
            $options  = MeprOptions::fetch();
            $redirect = $options->cart_page_url();
        }

        if (empty($redirect)) {
            $redirect = home_url('/');
        }

        wp_safe_redirect($redirect);
        exit;
    }

    /**
     * AJAX: Apply a coupon code to the cart.
     *
     * Validates per-product applicability. Saves coupon to checkout_data and recalculates.
     * Fires mepr_cart_coupon_applied hook on success.
     *
     * Expects POST: coupon_code (string), nonce.
     *
     * @return void Sends JSON response and exits.
     */
    public function apply_coupon()
    {
        if (!$this->verify_checkout_nonce()) {
            wp_send_json_error(['message' => __('Security check failed.', 'memberpress')], 403);
        }

        // phpcs:disable WordPress.Security.NonceVerification.Missing -- nonce already checked above.
        $code = isset($_POST['coupon_code']) ? sanitize_text_field(wp_unslash($_POST['coupon_code'])) : '';
        // phpcs:enable WordPress.Security.NonceVerification.Missing

        if (empty($code)) {
            wp_send_json_error(['message' => __('Please enter a coupon code.', 'memberpress')]);
        }

        $session = MeprCartSessionService::current_session();

        if (!$session) {
            wp_send_json_error(['message' => __('No active cart session.', 'memberpress')], 400);
        }

        // Look up the coupon.
        $coupon = MeprCoupon::get_one_from_code($code);

        if (!$coupon instanceof MeprCoupon) {
            wp_send_json_error(['message' => __('This coupon code is not valid.', 'memberpress')]);
        }

        // Allow add-ons to block apply (e.g. gift coupons must use product claim URL).
        $can_apply = MeprHooks::apply_filters('mepr_cart_apply_coupon', true, $coupon, $session, 'ajax');
        if (is_wp_error($can_apply)) {
            wp_send_json_error(['message' => $can_apply->get_error_message()]);
        }
        if (true !== $can_apply) {
            wp_send_json_error(['message' => __('This coupon cannot be applied.', 'memberpress')]);
        }

        // Validate per-product: check if coupon applies to at least one item in cart.
        $items      = MeprCartSessionService::get_items($session);
        $applies_to = false;

        foreach ($items as $product_id => $item) {
            if (MeprCoupon::is_valid_coupon_code($code, (int) $product_id)) {
                $applies_to = true;
                break;
            }
        }

        if (!$applies_to) {
            wp_send_json_error(['message' => __('This coupon is not valid for items in your cart.', 'memberpress')]);
        }

        // Save coupon code to checkout_data.
        $checkout_data                = MeprCartCheckoutService::get_checkout_data($session);
        $checkout_data['coupon_code'] = $code;
        MeprCartCheckoutService::save_checkout_data($session, $checkout_data);

        // Recalculate with coupon + saved/live billing so tax is not wiped to $0.
        $totals = $this->calculate_checkout_totals_for_session($session, $coupon);

        // Fire coupon applied hook (HOOK-01).
        MeprHooks::do_action('mepr_cart_coupon_applied', $coupon, $session);

        $bylines = MeprCartCheckoutService::billing_bylines(
            $items,
            $coupon,
            null,
            $totals['line_items'] ?? [],
            $totals['tax_items'] ?? []
        );

        // $totals includes tax_items array for sidebar JS to render grouped tax lines.
        wp_send_json_success([
            'totals'      => self::add_formatted_totals($totals),
            'coupon_code' => $code,
            'discount'    => $totals['discount_total'],
            'bylines'     => $bylines,
        ]);
    }

    /**
     * AJAX: Remove the currently applied coupon from the cart.
     *
     * Removes coupon_code from checkout_data and recalculates.
     * Fires mepr_cart_coupon_removed hook.
     *
     * Expects POST: nonce.
     *
     * @return void Sends JSON response and exits.
     */
    public function remove_coupon()
    {
        if (!$this->verify_checkout_nonce()) {
            wp_send_json_error(['message' => __('Security check failed.', 'memberpress')], 403);
        }

        $session = MeprCartSessionService::current_session();

        if (!$session) {
            wp_send_json_error(['message' => __('No active cart session.', 'memberpress')], 400);
        }

        $checkout_data = MeprCartCheckoutService::get_checkout_data($session);
        $old_code      = isset($checkout_data['coupon_code']) ? $checkout_data['coupon_code'] : '';

        // Remove coupon from checkout_data.
        unset($checkout_data['coupon_code']);
        MeprCartCheckoutService::save_checkout_data($session, $checkout_data);

        // Recalculate without coupon + saved/live billing so tax is not wiped to $0.
        $items  = MeprCartSessionService::get_items($session);
        $totals = $this->calculate_checkout_totals_for_session($session, null);

        // Fire coupon removed hook (HOOK-01).
        MeprHooks::do_action('mepr_cart_coupon_removed', $old_code, $session);

        // $totals includes tax_items array for sidebar JS to render grouped tax lines.
        wp_send_json_success([
            'totals'  => self::add_formatted_totals($totals),
            'bylines' => MeprCartCheckoutService::billing_bylines(
                $items,
                null,
                null,
                $totals['line_items'] ?? [],
                $totals['tax_items'] ?? []
            ),
        ]);
    }

    /**
     * Shared preamble for the payment-step AJAX endpoints (payment_config + create_payment_intent):
     * nonce, anti-fraud, login, session/items, availability guard, totals (incl. order bumps),
     * free-checkout detection, and save_card/gateway resolution. On any failure (or the $0 free
     * path) it sends the JSON response and exits; otherwise it returns the resolved context.
     *
     * @param  boolean $nonce_verified Whether the caller already verified the nonce.
     * @param  boolean $require_login  Whether a logged-in user is required.
     * @param  boolean $skip_tax_cache Price the Stripe Tax basket live: true for create_payment_intent, whose
     *                                 grand_total is charged, false for payment_config, which only previews.
     * @return array<string, mixed>
     */
    private function resolve_payment_request(bool $nonce_verified = false, bool $require_login = true, bool $skip_tax_cache = false): array
    {
        // A guest nonce cannot re-verify after inline account creation switches the request's
        // user, so callers that already checked the nonce pass $nonce_verified = true.
        if (!$nonce_verified && !$this->verify_checkout_nonce()) {
            wp_send_json_error(['message' => __('Security check failed.', 'memberpress')], 403);
        }

        $this->check_anti_fraud_or_bail();

        // Payment execution requires a user (wizard creates it at the account step; single-page
        // creates it inside the payment request). The read-only mount config allows guests.
        if ($require_login && !is_user_logged_in()) {
            wp_send_json_error(['message' => __('You must be logged in to complete your purchase.', 'memberpress')], 403);
        }

        $session = MeprCartSessionService::current_session();
        if (!$session) {
            wp_send_json_error(['message' => __('No active cart session.', 'memberpress')], 400);
        }

        $items = MeprCartSessionService::get_items($session);
        if (empty($items)) {
            wp_send_json_error(['message' => __('Your cart is empty.', 'memberpress')], 400);
        }

        // Unavailable / already-subscribed / who-can-purchase — same gates as classic signup.
        $this->reject_if_cart_blocked($items, $session);

        $checkout_data = MeprCartCheckoutService::get_checkout_data($session);
        $billing       = isset($checkout_data['billing']) && is_array($checkout_data['billing']) ? $checkout_data['billing'] : [];
        $country       = isset($billing['country'])  ? $billing['country']  : '';
        $state         = isset($billing['state'])    ? $billing['state']    : '';
        $postcode      = isset($billing['postcode']) ? $billing['postcode'] : '';
        $city          = isset($billing['city'])     ? $billing['city']     : '';
        $street        = isset($billing['street'])   ? $billing['street']   : '';

        // Resolve coupon.
        $coupon = $this->resolve_coupon_from_data($checkout_data);

        // Calculate totals (including any order bumps stored in checkout_data).
        $bump_ids   = isset($checkout_data['bump_ids']) && is_array($checkout_data['bump_ids']) ? $checkout_data['bump_ids'] : [];
        $bump_items = [];
        foreach ($bump_ids as $bump_id) {
            $bump_items[(int) $bump_id] = ['qty' => 1];
        }
        $all_items       = $items + $bump_items;
        $active_currency = MeprCurrencyService::get_active_currency();
        $checkout_user_id = get_current_user_id();
        // Tax AJAX sends VAT in POST; payment_config / Pay Now do not. Put the
        // saved billing VAT on this request only (not user meta) so B2B net
        // matches the sidebar. Meta is written at order completion.
        if (!empty($billing)) {
            MeprCartCheckoutService::apply_vat_to_request($billing);
        }
        $checkout_user = $checkout_user_id > 0 ? new MeprUser($checkout_user_id) : null;

        // Read before the totals: a calculation is account-scoped, so the charged total prices
        // on the gateway that will charge it. Non-Stripe or unknown keeps the designated method.
        // phpcs:disable WordPress.Security.NonceVerification.Missing -- nonce already checked above.
        $gateway_id = isset($_POST['gateway_id']) ? sanitize_text_field(wp_unslash($_POST['gateway_id'])) : '';
        // phpcs:enable WordPress.Security.NonceVerification.Missing
        $charge_gateway = $gateway_id === '' ? null : MeprOptions::fetch()->payment_method($gateway_id);
        $tax_gateway    = $charge_gateway instanceof MeprStripeGateway ? $charge_gateway : null;

        $totals          = MeprCartCheckoutService::calculate_totals(
            $all_items,
            $country,
            $state,
            $postcode,
            $city,
            $street,
            $coupon,
            $active_currency,
            $checkout_user,
            $skip_tax_cache,
            $tax_gateway
        );

        $requires_payment = MeprCartCheckoutService::cart_requires_payment($all_items, $coupon);

        // Free checkout only when nothing is due now or at renewal. A $0-now-but-renews cart
        // falls through to the caller (Stripe handler routes it to a SetupIntent at Pay Now).
        if (MeprCartCheckoutService::is_free_checkout((float) $totals['grand_total'], $all_items, $coupon)) {
            wp_send_json_success([
                'free_checkout' => true,
                'message'       => __('Complete Order', 'memberpress'),
            ]);
        }

        // phpcs:disable WordPress.Security.NonceVerification.Missing -- nonce already checked above.
        $save_card = $requires_payment || !empty($_POST['save_card']);
        // phpcs:enable WordPress.Security.NonceVerification.Missing

        // Force-save the card when an add-on (e.g. funnels) needs a stored PaymentMethod.
        $save_card = (bool) MeprHooks::apply_filters('mepr_cart_should_save_card', $save_card, $items);

        return [
            'user_id'       => get_current_user_id(),
            'session'       => $session,
            'items'         => $items,
            'checkout_data' => $checkout_data,
            'totals'        => $totals,
            'coupon'        => $coupon,
            'save_card'     => $save_card,
            'gateway_id'    => $gateway_id,
        ];
    }

    /**
     * AJAX: Build the payment-step mount config (deferred Stripe Element options / offline notice /
     * saved methods) WITHOUT creating an order or PaymentIntent. Fired when the payment step becomes
     * active; the order + intent are deferred to Pay Now (create_payment_intent / place_order).
     *
     * Expects POST: nonce, gateway_id.
     *
     * @return void Sends JSON response and exits.
     */
    public function payment_config()
    {
        // Mount config only (no order, no intent, no charge) — guests may fetch it so the
        // single-page payment section can initialize before the account exists.
        $ctx = $this->resolve_payment_request(false, false);

        // A paid cart with no cart gateway has nothing to mount; the free case already returned above.
        if (empty(MeprCartPaymentService::get_available_gateways())) {
            wp_send_json_success(['no_gateway' => true]);
        }

        try {
            $payload = MeprCartPaymentService::payment_config(
                $ctx['user_id'],
                $ctx['session'],
                $ctx['totals'],
                $ctx['save_card'],
                $ctx['coupon'],
                $ctx['gateway_id']
            );

            // The Pay button label is rendered from this, so send the display string too.
            if (isset($payload['total'])) {
                $payload['total_formatted'] = MeprAppHelper::format_currency_for_json(
                    (float) $payload['total'],
                    true,
                    false,
                    false,
                    MeprCurrencyService::get_active_currency()
                );
            }

            wp_send_json_success($payload);
        } catch (\Exception $e) {
            wp_send_json_error(['message' => $e->getMessage()], 500);
        }
    }

    /**
     * AJAX: Create the order + Stripe PaymentIntent/SetupIntent at Pay Now.
     *
     * Called from the place-order click (after elements.submit() for a new card), NOT on
     * payment-step entry — so the order is created only when the customer commits. Returns
     * client_secret for the deferred Payment Element to confirm against.
     *
     * Expects POST: nonce, gateway_id, save_card.
     *
     * @return void Sends JSON response and exits.
     */
    public function create_payment_intent()
    {
        if (!$this->verify_checkout_nonce()) {
            wp_send_json_error(['message' => __('Security check failed.', 'memberpress')], 403);
        }

        // Fraud and consent checks come first — no account creation and no Stripe object without them.
        $this->check_anti_fraud_or_bail();
        $this->validate_purchase_consents();

        // Single-page guests: create the account inside the payment request (one-click pay).
        $this->maybe_create_guest_account_inline();

        // The grand_total from here is the PaymentIntent amount, so tax is priced live — a
        // cached basket would charge day-old tax while charge_quote() files a fresh calculation.
        $ctx = $this->resolve_payment_request(true, true, true);

        try {
            $payload = MeprCartPaymentService::initiate_payment(
                $ctx['user_id'],
                $ctx['session'],
                $ctx['totals'],
                $ctx['save_card'],
                $ctx['coupon'],
                $ctx['checkout_data'],
                $ctx['gateway_id']
            );

            // The account may have just been created above — hand the client a nonce for the
            // new session so the follow-up place_order request verifies.
            $payload['new_nonce'] = wp_create_nonce('mepr_cart_checkout_nonce');

            wp_send_json_success($payload);
        } catch (\Exception $e) {
            wp_send_json_error(['message' => $e->getMessage()], 500);
        }
    }

    /**
     * AJAX: Place the cart order after Stripe payment confirmation.
     *
     * Called AFTER Stripe confirms the payment on the client side.
     * Expects POST: order_id (int), payment_intent_id (string), nonce.
     *
     * @return void Sends JSON response and exits.
     */
    public function place_order()
    {
        if (!$this->verify_checkout_nonce()) {
            wp_send_json_error(['message' => __('Security check failed.', 'memberpress')], 403);
        }

        $this->check_anti_fraud_or_bail();

        // Consents come first — no account creation without them.
        $this->validate_purchase_consents();

        // Single-page guests paying offline/free: create the account inside this request.
        $this->maybe_create_guest_account_inline();

        if (!is_user_logged_in()) {
            wp_send_json_error(['message' => __('You must be logged in to complete your purchase.', 'memberpress')], 403);
        }

        // phpcs:disable WordPress.Security.NonceVerification.Missing -- nonce already checked above.
        $order_id          = isset($_POST['order_id'])          ? (int) $_POST['order_id']                                               : 0;
        $payment_intent_id = isset($_POST['payment_intent_id']) ? sanitize_text_field(wp_unslash($_POST['payment_intent_id'])) : '';
        $saved_token       = isset($_POST['payment_method'])    ? sanitize_text_field(wp_unslash($_POST['payment_method']))    : '';
        $save_card         = !empty($_POST['save_card']);
        $is_free           = isset($_POST['free_checkout']) && $_POST['free_checkout'] === 'true';
        // phpcs:enable WordPress.Security.NonceVerification.Missing

        $session_for_avail = MeprCartSessionService::current_session();
        $items_for_avail   = $session_for_avail ? MeprCartSessionService::get_items($session_for_avail) : [];
        $this->reject_if_cart_blocked($items_for_avail, $session_for_avail);

        // Free checkout path: no Stripe PI required for $0 orders.
        if ($is_free) {
            $session_for_free = MeprCartSessionService::current_session();
            if (!$session_for_free) {
                wp_send_json_error(['message' => __('No active cart session.', 'memberpress')], 400);
            }

            // Resolve the applied coupon so a 100%-off order nets to zero (otherwise the
            // zero-total guard below rejects it and the discount is lost on the order).
            $cd_for_free     = MeprCartCheckoutService::get_checkout_data($session_for_free);
            $coupon_for_free = $this->resolve_coupon_from_data($cd_for_free);

            // Verify totals are actually zero (prevent client-side manipulation).
            $checkout_user_free = is_user_logged_in() ? new MeprUser(get_current_user_id()) : null;
            $totals_for_free    = MeprCartCheckoutService::calculate_totals(
                MeprCartSessionService::get_items($session_for_free),
                '',
                '',
                '',
                '',
                '',
                $coupon_for_free,
                MeprCurrencyService::get_active_currency(),
                $checkout_user_free
            );
            if ($totals_for_free['grand_total'] > 0) {
                wp_send_json_error(['message' => __('Order total is not zero.', 'memberpress')], 400);
            }

            // Only a genuinely free cart may use the no-card free path.
            $free_items = MeprCartSessionService::get_items($session_for_free);
            if (MeprCartCheckoutService::cart_requires_payment($free_items, $coupon_for_free)) {
                wp_send_json_error(['message' => __('A payment method is required to complete this order.', 'memberpress')], 400);
            }

            // Reuse the existing pending order (e.g. one created under Stripe before the coupon
            // made the total $0) instead of creating a new one — otherwise the pending order is
            // orphaned. resolve_or_create_order() re-tags it to the free gateway and re-applies totals.
            $user_id_for_free = get_current_user_id();

            try {
                $order_for_free = MeprCartPaymentService::resolve_or_create_order(
                    $session_for_free,
                    $user_id_for_free,
                    MeprTransaction::$free_gateway_str,
                    $coupon_for_free,
                    $cd_for_free,
                    $totals_for_free
                );

                // Complete as free order.
                $result_free = MeprCartCheckoutService::complete_cart_order_free($order_for_free, $session_for_free, $user_id_for_free);
            } catch (\Exception $e) {
                wp_send_json_error(['message' => $e->getMessage()], 500);
            }

            wp_send_json_success(['redirect' => MeprCartPaymentService::build_thankyou_url($order_for_free, MeprOptions::fetch())]);
        }

        // Offline gateway places the order on this click — no create_payment_intent prepare step
        // runs for offline, so there is no prepared order_id. Create (or reuse) the order now; the
        // confirm path below completes it. resolve_or_create_order reuses a prior pending order from
        // checkout_data (e.g. a Stripe attempt before switching to offline) and re-tags it.
        // phpcs:disable WordPress.Security.NonceVerification.Missing -- nonce already checked above.
        $gateway_id = isset($_POST['gateway_id']) ? sanitize_text_field(wp_unslash($_POST['gateway_id'])) : '';
        // phpcs:enable WordPress.Security.NonceVerification.Missing
        if ($order_id <= 0 && $gateway_id !== '' && MeprCartPaymentService::is_offline($gateway_id)) {
            $offline_session = MeprCartSessionService::current_session();
            if (!$offline_session) {
                wp_send_json_error(['message' => __('No active cart session.', 'memberpress')], 400);
            }

            // Validate the live cart at commit time — the customer may have emptied or changed it
            // (e.g. in another tab) since the payment step rendered. Don't build an order from a
            // stale assumption. (The Stripe path is already guarded in create_payment_intent.).
            $offline_items = MeprCartSessionService::get_items($offline_session);
            if (empty($offline_items)) {
                wp_send_json_error(['message' => __('Your cart is empty.', 'memberpress')], 400);
            }
            $this->reject_if_cart_blocked($offline_items, $offline_session);

            $cd_offline      = MeprCartCheckoutService::get_checkout_data($offline_session);
            $coupon_offline  = $this->resolve_coupon_from_data($cd_offline);
            // Billing-aware totals so the (possibly pending) offline order carries the right tax from
            // creation — matches the Stripe path. complete_cart_order recomputes authoritatively too.
            // Tax is priced live (skip_tax_cache): these figures are booked on the order rows and no
            // stamp_quote_on_order_rows() runs on the offline path, while filing mints fresh.
            $billing_offline = isset($cd_offline['billing']) && is_array($cd_offline['billing']) ? $cd_offline['billing'] : [];
            // The place_order request carries no VAT identity, so restore the saved one.
            // Without it these booked figures price a B2B buyer at standard VAT while the
            // sidebar and the filing mint both apply reverse charge.
            if (!empty($billing_offline)) {
                MeprCartCheckoutService::apply_vat_to_request($billing_offline);
            }
            $checkout_user_offline = is_user_logged_in() ? new MeprUser(get_current_user_id()) : null;
            $totals_offline        = MeprCartCheckoutService::calculate_totals(
                MeprCartSessionService::get_items($offline_session),
                isset($billing_offline['country'])  ? $billing_offline['country']  : '',
                isset($billing_offline['state'])    ? $billing_offline['state']    : '',
                isset($billing_offline['postcode']) ? $billing_offline['postcode'] : '',
                isset($billing_offline['city'])     ? $billing_offline['city']     : '',
                isset($billing_offline['street'])   ? $billing_offline['street']   : '',
                $coupon_offline,
                MeprCurrencyService::get_active_currency(),
                $checkout_user_offline,
                true
            );

            try {
                $offline_order = MeprCartPaymentService::resolve_or_create_order(
                    $offline_session,
                    get_current_user_id(),
                    $gateway_id,
                    $coupon_offline,
                    $cd_offline,
                    $totals_offline
                );
            } catch (\Exception $e) {
                wp_send_json_error(['message' => $e->getMessage()], 500);
            }

            $order_id = (int) $offline_order->id;
        }

        if ($order_id <= 0) {
            wp_send_json_error(['message' => __('Invalid order.', 'memberpress')], 400);
        }

        $order = new MeprOrder($order_id);
        if (!(int) $order->id || (int) $order->user_id !== get_current_user_id()) {
            wp_send_json_error(['message' => __('Order not found.', 'memberpress')], 404);
        }

        // HOOK: add-ons restore any wizard-step data they persisted at billing step save.
        $place_order_session = MeprCartSessionService::current_session();
        if ($place_order_session) {
            MeprHooks::do_action('mepr_checkout_restore_step_data', $place_order_session);
        }

        // HOOK-02: Allow addons to act before order is placed.
        MeprHooks::do_action('mepr_before_cart_checkout', $order);

        // If already complete (webhook beat us), return success idempotently.
        // Backfill transaction-completed when the webhook used a path that skipped
        // fire_legacy_signup_hooks — otherwise Stripe Tax / TaxJar never see the sale.
        if ($order->is_complete()) {
            MeprCartCheckoutService::maybe_backfill_completion_events($order);

            $session = MeprCartSessionService::current_session();
            if ($session) {
                MeprCartSessionService::clear($session);
            }

            $funnel_redirect = MeprHooks::apply_filters('mepr_cart_funnel_redirect', null, $order);
            wp_send_json_success(['redirect' => $funnel_redirect ?: MeprCartPaymentService::build_thankyou_url($order, MeprOptions::fetch())]);
        }

        // Delegate payment verification and order completion to the service.
        // phpcs:disable WordPress.Security.NonceVerification.Missing -- nonce already checked above.
        $result = MeprCartPaymentService::confirm_payment($order, $_POST);
        // phpcs:enable WordPress.Security.NonceVerification.Missing

        if (!empty($result['error'])) {
            $error_payload = ['message' => $result['error']];
            if (!empty($result['error_code'])) {
                $error_payload['error_code'] = $result['error_code'];
            }
            wp_send_json_error($error_payload, $result['status'] ?? 500);
        }

        // Custom field values are persisted in-request as each step is submitted (Account step for
        // signup fields, custom-field steps for checkout fields) via the shared type-aware saver —
        // mirroring the legacy non-SPC signup that saves fields before payment. No completion-time
        // save is needed here, and that path can't handle file uploads ($_FILES is long gone).
        $session = MeprCartSessionService::current_session();

        // Clear the cart session.
        if ($session) {
            MeprCartSessionService::clear($session);
        }

        // HOOK-02: mepr_after_cart_checkout already fired inside complete_cart_order.
        // Let an add-on (e.g. funnels) take over the post-order redirect (upsell interstitial).
        // Runs for pending offline orders too — offline upsells settle as pending transactions
        // and complete when the admin marks the order paid. Falls back to the service redirect
        // (the pending thank-you URL when manually_complete=true, else the normal thank-you).
        $funnel_redirect = MeprHooks::apply_filters('mepr_cart_funnel_redirect', null, $order);
        wp_send_json_success(['redirect' => $funnel_redirect ?: $result['redirect']]);
    }

    /**
     * AJAX: Update the invoice sidebar after qty/remove edits from within the sidebar.
     *
     * Expects POST: nonce, sub_action ('update_qty'|'remove'), product_id, qty (when update_qty).
     * Returns updated totals and item_count. If cart is empty after remove, returns redirect_to_cart flag.
     *
     * @return void Sends JSON response and exits.
     */
    public function update_sidebar()
    {
        if (!$this->verify_checkout_nonce()) {
            wp_send_json_error(['message' => __('Security check failed.', 'memberpress')], 403);
        }

        $session = MeprCartSessionService::current_session();

        if (!$session) {
            wp_send_json_error(['message' => __('No active cart session.', 'memberpress')], 400);
        }

        // phpcs:disable WordPress.Security.NonceVerification.Missing -- nonce already checked above.
        $sub_action = isset($_POST['sub_action']) ? sanitize_key(wp_unslash($_POST['sub_action'])) : '';
        $product_id = isset($_POST['product_id']) ? (int) $_POST['product_id'] : 0;
        $qty        = isset($_POST['qty'])        ? (int) $_POST['qty'] : 1;
        // phpcs:enable WordPress.Security.NonceVerification.Missing

        if ($product_id <= 0) {
            wp_send_json_error(['message' => __('Invalid product ID.', 'memberpress')], 400);
        }

        switch ($sub_action) {
            case 'update_qty':
                $qty = max(1, min(MeprCartSessionService::MAX_ITEM_QTY, $qty));
                MeprCartSessionService::update_quantity($session, $product_id, $qty);
                break;

            case 'remove':
                $removed = MeprCartSessionService::remove_item($session, $product_id);
                if (!empty($removed['error'])) {
                    wp_send_json_error(['message' => $removed['error']], 403);
                }
                break;

            default:
                wp_send_json_error(['message' => __('Unknown sidebar action.', 'memberpress')], 400);
        }

        // Check if cart is now empty.
        $item_count = MeprCartSessionService::item_count($session);
        if ($item_count === 0) {
            wp_send_json_success(['redirect_to_cart' => true]);
        }

        // Recalculate totals.
        $items         = MeprCartSessionService::get_items($session);
        $checkout_data = MeprCartCheckoutService::get_checkout_data($session);

        $coupon = $this->resolve_coupon_from_data($checkout_data);

        // Auto-detach an orphaned coupon: removing/changing items can leave the applied coupon
        // valid for nothing in the cart. Drop it from the session (so a reload can't resurrect it)
        // and tell the JS to notify the buyer — before recalculating without it.
        $coupon_removed = '';
        if ($coupon instanceof MeprCoupon && !MeprCartCheckoutService::coupon_applies_to_any_item($items, $coupon)) {
            $coupon_removed = (string) $coupon->post_title;
            unset($checkout_data['coupon_code']);
            MeprCartCheckoutService::save_checkout_data($session, $checkout_data);
            // Same hook as manual remove_coupon() so add-ons hear auto-detach too.
            MeprHooks::do_action('mepr_cart_coupon_removed', $coupon_removed, $session);
            $coupon = null;
        }

        $billing  = isset($checkout_data['billing']) && is_array($checkout_data['billing']) ? $checkout_data['billing'] : [];
        $country  = isset($billing['country'])  ? $billing['country']  : '';
        $state    = isset($billing['state'])    ? $billing['state']    : '';
        $postcode = isset($billing['postcode']) ? $billing['postcode'] : '';
        $city     = isset($billing['city'])     ? $billing['city']     : '';
        $street   = isset($billing['street'])   ? $billing['street']   : '';
        $active_currency = MeprCurrencyService::get_active_currency();

        // The sidebar quantity stepper and line removal carry no VAT identity, so restore the
        // saved one for this request or a B2B basket repaints at standard VAT.
        MeprCartCheckoutService::apply_vat_to_request($billing, true);

        $checkout_user = is_user_logged_in() ? new MeprUser(get_current_user_id()) : null;
        $totals        = MeprCartCheckoutService::calculate_totals(
            $items,
            $country,
            $state,
            $postcode,
            $city,
            $street,
            $coupon,
            $active_currency,
            $checkout_user
        );

        $checkout_data = MeprCartCheckoutService::merge_tax_calculation_meta($checkout_data, $totals);
        MeprCartCheckoutService::save_checkout_data($session, $checkout_data);

        // Update the PaymentIntent amount to match the new cart total (Stripe only).
        // Automatic-tax sites skip this: initiate() always creates a fresh PI there,
        // so the PATCH is a stray write — and it may resolve a different Stripe
        // gateway than the one the order was set up with.
        $existing_pi_id = isset($checkout_data['payment_intent_id']) ? $checkout_data['payment_intent_id'] : '';
        $stripe_gw      = MeprCartPaymentService::supports_upsells() ? MeprCartPaymentService::get_active_gateway() : null;
        if (!empty($existing_pi_id) && $stripe_gw instanceof MeprStripeGateway && !MeprStripeGateway::use_automatic_tax()) {
            try {
                $stripe_gw->send_stripe_request(
                    "payment_intents/{$existing_pi_id}",
                    ['amount' => (int) $stripe_gw->to_zero_decimal_amount($totals['grand_total'], $active_currency)],
                    'post'
                );
            } catch (Exception $e) {
                MeprUtils::debug_log('MeprCartCheckoutCtrl::update_sidebar() PI update failed: ' . $e->getMessage());
            }
        }

        wp_send_json_success([
            'totals'           => self::add_formatted_totals($totals),
            'item_count'       => $item_count,
            'cart_count'       => $item_count,
            'redirect_to_cart' => false,
            'bylines'          => MeprCartCheckoutService::billing_bylines(
                $items,
                $coupon,
                null,
                $totals['line_items'] ?? [],
                $totals['tax_items'] ?? []
            ),
            'sidebar_html'     => $this->safe_sidebar_html($session, $totals),
            'coupon_removed'   => $coupon_removed,
        ]);
    }

    /**
     * Render sidebar HTML without letting template errors break AJAX handlers.
     *
     * @param  MeprCartSession $session Current cart session.
     * @param  array|null      $totals  Optional precomputed totals.
     * @return string
     */
    private function safe_sidebar_html($session, $totals = null)
    {
        try {
            return $this->get_sidebar_html($session, $totals);
        } catch (Throwable $e) {
            MeprUtils::debug_log('MeprCartCheckoutCtrl::get_sidebar_html() failed: ' . $e->getMessage());
            return '';
        }
    }

    /**
     * Render the checkout Order Summary sidebar from the PHP template (single source of truth).
     *
     * Used by AJAX handlers (sidebar qty/remove, funnel bump toggle) so client JS does not
     * rebuild line-item markup that can drift from sidebar.php.
     *
     * @param  MeprCartSession $session Current cart session.
     * @param  array|null      $totals  Optional precomputed totals (avoids a second calc).
     * @return string                   Sidebar HTML (outer #mepr-checkout-sidebar).
     */
    public function get_sidebar_html($session, $totals = null)
    {
        $items         = MeprCartSessionService::get_items($session);
        $checkout_data = MeprCartCheckoutService::get_checkout_data($session);
        $coupon        = $this->resolve_coupon_from_data($checkout_data);

        if (!is_array($totals)) {
            $billing       = isset($checkout_data['billing']) && is_array($checkout_data['billing']) ? $checkout_data['billing'] : [];
            $country       = isset($billing['country'])  ? $billing['country']  : '';
            $state         = isset($billing['state'])    ? $billing['state']    : '';
            $postcode      = isset($billing['postcode']) ? $billing['postcode'] : '';
            $city          = isset($billing['city'])     ? $billing['city']     : '';
            $street        = isset($billing['street'])   ? $billing['street']   : '';
            $checkout_user = is_user_logged_in() ? new MeprUser(get_current_user_id()) : null;
            $totals        = MeprCartCheckoutService::calculate_totals(
                $items,
                $country,
                $state,
                $postcode,
                $city,
                $street,
                $coupon,
                MeprCurrencyService::get_active_currency(),
                $checkout_user
            );
        }

        $cart_items = [];
        foreach (($totals['line_items'] ?? []) as $line_item) {
            $pid          = (int) $line_item['product_id'];
            $product      = new MeprProduct($pid);
            $product_type = $product->effective_type();
            $trial        = (bool) get_post_meta($pid, MeprProduct::$trial_str, true);
            $trial_days   = (int) get_post_meta($pid, MeprProduct::$trial_days_str, true);
            $trial_amount = (float) get_post_meta($pid, MeprProduct::$trial_amount_str, true);
            $paint_base   = (float) $line_item['line_base'];

            $cart_items[$pid] = array_merge(
                $items[$pid] ?? [],
                [
                    'qty'          => $line_item['qty'],
                    'product_type' => $product_type,
                    'line_total'   => $paint_base,
                    'line_base'    => $paint_base,
                    'period'       => (int) get_post_meta($pid, MeprProduct::$period_str, true),
                    'period_type'  => (string) get_post_meta($pid, MeprProduct::$period_type_str, true),
                    'trial'        => $trial,
                    'trial_days'   => $trial_days,
                    'trial_amount' => $trial_amount,
                ]
            );
        }

        $vars = [
            'cart_items'          => $cart_items,
            'totals'              => $totals,
            'checkout_data'       => $checkout_data,
            'coupon_code'         => isset($checkout_data['coupon_code']) ? (string) $checkout_data['coupon_code'] : '',
            'bylines'             => MeprCartCheckoutService::billing_bylines(
                $items,
                $coupon,
                null,
                $totals['line_items'] ?? [],
                $totals['tax_items'] ?? []
            ),
            'order_bumps'         => [],
            'mandatory_bump_ids'  => [],
            'recurring_note'      => '',
        ];

        return (string) MeprView::get_string('/readylaunch/cart-checkout/sidebar', $vars);
    }

    /**
     * AJAX handler: calculate tax items for the current cart based on billing address.
     *
     * POST params: billing_country, billing_state, billing_city, billing_postcode, billing_street, nonce
     * Response: { tax_items: [...], subtotal: float, tax_total: float, grand_total: float }
     *
     * @return void Sends JSON response and exits.
     */
    public function calculate_cart_tax()
    {
        if (!$this->verify_checkout_nonce()) {
            wp_send_json_error(['message' => __('Security check failed.', 'memberpress')], 403);
        }

        $session = MeprCartSessionService::current_session();
        if (!$session) {
            wp_send_json_error(['message' => __('No active cart session.', 'memberpress')], 400);
        }

        // phpcs:disable WordPress.Security.NonceVerification.Missing -- nonce already verified above.
        $country  = isset($_POST['billing_country'])  ? sanitize_text_field(wp_unslash($_POST['billing_country'])) : '';
        $state    = isset($_POST['billing_state'])    ? sanitize_text_field(wp_unslash($_POST['billing_state'])) : '';
        $city     = isset($_POST['billing_city'])     ? sanitize_text_field(wp_unslash($_POST['billing_city'])) : '';
        $postcode = isset($_POST['billing_postcode']) ? sanitize_text_field(wp_unslash($_POST['billing_postcode'])) : '';
        $street   = isset($_POST['billing_street'])   ? sanitize_text_field(wp_unslash($_POST['billing_street'])) : '';
        $vat_number    = isset($_POST['mepr_vat_number']) ? sanitize_text_field(wp_unslash($_POST['mepr_vat_number'])) : '';
        $customer_type = isset($_POST['mepr_vat_customer_type']) ? sanitize_text_field(wp_unslash($_POST['mepr_vat_customer_type'])) : '';
        // phpcs:enable WordPress.Security.NonceVerification.Missing

        $items = MeprCartSessionService::get_items($session);

        // Retrieve coupon from checkout_data.
        $checkout_data = MeprCartCheckoutService::get_checkout_data($session);
        $coupon        = $this->resolve_coupon_from_data($checkout_data);

        // Server-authoritative fallback: a recalc from a non-billing surface may omit
        // address/VAT fields — fill the gaps from the saved session (live POST wins),
        // the same source the charge path uses. The displayed tax can then never be
        // computed with less identity than the charge would use.
        $saved_billing = isset($checkout_data['billing']) && is_array($checkout_data['billing']) ? $checkout_data['billing'] : [];
        if ($country === '') {
            $country  = (string) ($saved_billing['country']  ?? '');
            $state    = $state    !== '' ? $state    : (string) ($saved_billing['state']    ?? '');
            $city     = $city     !== '' ? $city     : (string) ($saved_billing['city']     ?? '');
            $postcode = $postcode !== '' ? $postcode : (string) ($saved_billing['postcode'] ?? '');
            $street   = $street   !== '' ? $street   : (string) ($saved_billing['street']   ?? '');
        }
        if ($vat_number === '' && $customer_type === '') {
            MeprCartCheckoutService::apply_vat_to_request($saved_billing, true);
            // phpcs:disable WordPress.Security.NonceVerification.Missing -- nonce verified above; keys just set from saved billing.
            $vat_number    = isset($_POST['mepr_vat_number']) ? sanitize_text_field(wp_unslash($_POST['mepr_vat_number'])) : $vat_number;
            $customer_type = isset($_POST['mepr_vat_customer_type']) ? sanitize_text_field(wp_unslash($_POST['mepr_vat_customer_type'])) : $customer_type;
            // phpcs:enable WordPress.Security.NonceVerification.Missing
        }

        // Use calculate_totals() so we get accurate subtotal + grand_total with coupon.
        // Pass the logged-in user so VAT-by-user-meta integrations (e.g. Stripe Tax) and
        // the mepr_find_tax_rate filter resolve reverse charge in the displayed tax too.
        // The VAT number / customer type ride in via $_POST from the recalc request.
        $currency = MeprCurrencyService::get_active_currency();
        $tax_user = null;
        if (is_user_logged_in()) {
            // Mirror the entered billing into the user's address so the tax engines
            // (core VAT geo rules, Stripe Tax) evaluate the address being bought from —
            // not a stale saved address. Completion persists the same way (parity).
            MeprCartCheckoutService::sync_billing_to_user_meta(get_current_user_id(), [
                'country'  => $country,
                'state'    => $state,
                'city'     => $city,
                'postcode' => $postcode,
                'street'   => $street,
            ]);
            $tax_user = new MeprUser(get_current_user_id());
        }
        $totals   = MeprCartCheckoutService::calculate_totals(
            $items,
            $country,
            $state,
            $postcode,
            $city,
            $street,
            $coupon,
            $currency,
            $tax_user
        );

        // Keep session billing in sync (incl. street) so create/completion use the same address.
        if (!empty($country) || !empty($state) || !empty($postcode) || !empty($city) || !empty($street)) {
            $checkout_data = MeprCartCheckoutService::get_checkout_data($session);
            $billing_merge = compact('country', 'state', 'postcode', 'city', 'street');
            if ($vat_number !== '') {
                $billing_merge['mepr_vat_number'] = $vat_number;
            }
            if ($customer_type !== '') {
                $billing_merge['mepr_vat_customer_type'] = $customer_type;
            }
            $checkout_data['billing'] = array_merge(
                isset($checkout_data['billing']) && is_array($checkout_data['billing']) ? $checkout_data['billing'] : [],
                $billing_merge
            );
            $checkout_data = MeprCartCheckoutService::merge_tax_calculation_meta($checkout_data, $totals);
            MeprCartCheckoutService::save_checkout_data($session, $checkout_data);
        }

        // Update the Stripe PaymentIntent amount if one exists, so the charge
        // matches the tax-inclusive total (same pattern as recalculate()).
        $checkout_data  = MeprCartCheckoutService::get_checkout_data($session);
        $existing_pi_id = $checkout_data['payment_intent_id'] ?? '';
        $stripe_for_tax = MeprCartPaymentService::supports_upsells() ? MeprCartPaymentService::get_active_gateway() : null;
        if (!empty($existing_pi_id) && $stripe_for_tax instanceof MeprStripeGateway) {
            try {
                $stripe_for_tax->send_stripe_request(
                    "payment_intents/{$existing_pi_id}",
                    ['amount' => (int) $stripe_for_tax->to_zero_decimal_amount($totals['grand_total'], MeprCurrencyService::get_active_currency())],
                    'post'
                );
            } catch (Exception $e) {
                // Non-fatal: log silently, totals still returned to client.
            }
        }

        // The JS hands this whole payload to updateTotalsDisplay(), so the display strings
        // have to sit alongside the numbers here rather than under a totals key.
        $totals = self::add_formatted_totals($totals);

        wp_send_json_success([
            'tax_items'              => $totals['tax_items'],
            'tax_total'              => $totals['tax_total'],
            'tax_total_formatted'    => $totals['tax_total_formatted'] ?? '',
            'subtotal'               => $totals['subtotal'],
            'subtotal_formatted'     => $totals['subtotal_formatted'] ?? '',
            'discount_total'         => $totals['discount_total'],
            'discount_total_formatted' => $totals['discount_total_formatted'] ?? '',
            'display_subtotal'       => $totals['display_subtotal'] ?? $totals['subtotal'],
            'display_discount_total' => $totals['display_discount_total'] ?? $totals['discount_total'],
            'grand_total'            => $totals['grand_total'],
            'grand_total_formatted'  => $totals['grand_total_formatted'] ?? '',
            'zero_formatted'         => $totals['zero_formatted'] ?? '',
            'line_items'             => $totals['line_items'],
            'tax_inclusive'          => !empty($totals['tax_inclusive']),
            'calculation_id'         => $totals['calculation_id'] ?? '',
            'tax_engine'             => $totals['tax_engine'] ?? '',
            'bylines'                => MeprCartCheckoutService::billing_bylines(
                $items,
                $coupon,
                $tax_user,
                $totals['line_items'] ?? [],
                $totals['tax_items'] ?? []
            ),
        ]);
    }

    /**
     * AJAX handler: validate a VAT number for EU reverse-charge detection.
     *
     * POST params: vat_number, billing_country, nonce
     * Response success: { valid: bool, reverse_charge: bool }
     * Response error:   { message: string }
     *
     * @return void Sends JSON response and exits.
     */
    public function validate_vat_number()
    {
        if (!$this->verify_checkout_nonce()) {
            wp_send_json_error(['message' => __('Security check failed.', 'memberpress')], 403);
        }

        if (!get_option('mepr_calculate_taxes') || !get_option('mepr_vat_enabled')) {
            wp_send_json_success([
                'valid'          => false,
                'reverse_charge' => false,
            ]);
            return;
        }

        // phpcs:disable WordPress.Security.NonceVerification.Missing -- nonce already verified above.
        $vat_number = isset($_POST['vat_number'])      ? sanitize_text_field(wp_unslash($_POST['vat_number'])) : '';
        $country    = isset($_POST['billing_country']) ? sanitize_text_field(wp_unslash($_POST['billing_country'])) : '';
        // phpcs:enable WordPress.Security.NonceVerification.Missing

        if (empty($vat_number) || empty($country)) {
            wp_send_json_success([
                'valid'          => false,
                'reverse_charge' => false,
            ]);
            return;
        }

        $vat_ctrl       = MeprCtrlFactory::fetch('MeprVatTaxCtrl');
        $is_valid       = $vat_ctrl->vat_number_is_valid($vat_number, $country);
        $reverse_charge = MeprVatTaxCtrl::is_reverse_charge_applicable($country, $is_valid);

        if ($is_valid) {
            wp_send_json_success([
                'valid'          => true,
                'reverse_charge' => $reverse_charge,
            ]);
        } else {
            wp_send_json_error([
                'message' => __('VAT number not found. Tax will be calculated based on your billing address.', 'memberpress'),
            ]);
        }
    }
}
