<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Actions\ClickWhale\ClickWhaleProHelper;
use BitApps\IntegrationsPro\Config;
use BitApps\IntegrationsPro\Core\Util\Hooks;

Hooks::filter(Config::withFreePrefix('clickwhale_create_link'), [ClickWhaleProHelper::class, 'createLink'], 10, 4);
Hooks::filter(Config::withFreePrefix('clickwhale_update_link'), [ClickWhaleProHelper::class, 'updateLink'], 10, 3);
Hooks::filter(Config::withFreePrefix('clickwhale_delete_link'), [ClickWhaleProHelper::class, 'deleteLink'], 10, 2);
