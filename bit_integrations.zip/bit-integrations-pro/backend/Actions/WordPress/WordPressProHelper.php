<?php

namespace BitApps\IntegrationsPro\Actions\WordPress;

class WordPressProHelper
{
    public static function registerPostType($defaultResponse, $fieldData, $integrationDetails)
    {
        $key = $fieldData['key'] ?? null;
        $label = $fieldData['label'] ?? null;
        $public = self::getIntegrationValue($integrationDetails, 'public', false);
        $hierarchy = self::getIntegrationValue($integrationDetails, 'hierarchy', false);
        $showUI = self::getIntegrationValue($integrationDetails, 'showUI', false);
        $showInMenu = self::getIntegrationValue($integrationDetails, 'showInMenu', false);
        $showInNavMenu = self::getIntegrationValue($integrationDetails, 'showInNavMenu', false);
        $showInAdminBar = self::getIntegrationValue($integrationDetails, 'showInAdminBar', false);

        if (empty($key)) {
            return self::error(__('Post Type Key is required', 'bit-integrations-pro'));
        }

        $supports = self::convertStringToArray($fieldData['supports'] ?? '');

        $postType = register_post_type($key, [
            'label'             => $label,
            'public'            => $public,
            'hierarchical'      => $hierarchy,
            'show_ui'           => $showUI,
            'show_in_menu'      => $showInMenu,
            'show_in_nav_menus' => $showInNavMenu,
            'show_in_admin_bar' => $showInAdminBar,
            'menu_position'     => $fieldData['menuPosition'] ?? null,
            'supports'          => $supports,
            'description'       => $fieldData['description'] ?? '',
            'rewrite'           => ['slug' => $fieldData['rewriteSlug'] ?? $key],
        ]);

        if (is_wp_error($postType)) {
            return self::error($postType->get_error_message());
        }

        return self::success(['post_type' => $key]);
    }

    public static function unregisterPostType($defaultResponse, $fieldData, $integrationDetails)
    {
        $key = $fieldData['key'] ?? null;

        if (empty($key)) {
            return self::error(__('Post Type Key is required', 'bit-integrations-pro'));
        }

        if (!post_type_exists($key)) {
            return self::error(__('Post Type not found.', 'bit-integrations-pro'));
        }

        $status = unregister_post_type($key);

        if (is_wp_error($status)) {
            return self::error($status->get_error_message());
        }

        return self::success(__('Successfully unregistered the Post Type.', 'bit-integrations-pro'));
    }

    public static function addPostTypeFeatures($defaultResponse, $fieldData, $integrationDetails)
    {
        $key = $fieldData['key'] ?? null;
        $supports = self::convertStringToArray($fieldData['supports'] ?? '');

        if (empty($key)) {
            return self::error(__('Post Type Key is required', 'bit-integrations-pro'));
        }

        if (empty($supports)) {
            return self::error(__('Features (supports) are required', 'bit-integrations-pro'));
        }

        if (!post_type_exists($key)) {
            return self::error(__('Post Type not found.', 'bit-integrations-pro'));
        }

        foreach ($supports as $support) {
            add_post_type_support($key, $support);
        }

        return self::success(__('Post type features added.', 'bit-integrations-pro'));
    }

    // =========================================================================
    // Tags / Taxonomy on Posts
    // =========================================================================

    public static function createPostTag($defaultResponse, $fieldData, $integrationDetails)
    {
        return self::createTermByTax($fieldData, 'post_tag');
    }

    public static function updatePostTag($defaultResponse, $fieldData, $integrationDetails)
    {
        return self::updateTermByTax($fieldData, 'post_tag');
    }

    public static function deletePostTag($defaultResponse, $fieldData, $integrationDetails)
    {
        return self::deleteTermByTax($fieldData, 'post_tag');
    }

    public static function addTaxonomyToPost($defaultResponse, $fieldData, $integrationDetails)
    {
        $postId = $fieldData['postId'] ?? null;
        $taxonomy = $fieldData['taxonomy'] ?? null;
        $terms = self::convertStringToArray($fieldData['term'] ?? '');
        $append = self::getIntegrationValue($integrationDetails, 'append', false);

        if (empty($postId)) {
            return self::error(__('Post id is required', 'bit-integrations-pro'));
        }

        if (empty($taxonomy)) {
            return self::error(__('Taxonomy is required', 'bit-integrations-pro'));
        }

        if (empty($terms)) {
            return self::error(__('Term is required', 'bit-integrations-pro'));
        }

        $result = wp_set_object_terms($postId, $terms, $taxonomy, $append);

        if (is_wp_error($result)) {
            return self::error($result->get_error_message());
        }

        return self::success($result);
    }

    public static function removeTaxonomyFromPost($defaultResponse, $fieldData, $integrationDetails)
    {
        $postId = $fieldData['postId'] ?? null;
        $taxonomy = $fieldData['taxonomy'] ?? null;
        $terms = self::convertStringToArray($fieldData['term'] ?? '');

        if (empty($postId)) {
            return self::error(__('Post id is required', 'bit-integrations-pro'));
        }

        if (empty($taxonomy)) {
            return self::error(__('Taxonomy is required', 'bit-integrations-pro'));
        }

        if (empty($terms)) {
            return self::error(__('Term is required', 'bit-integrations-pro'));
        }

        $status = wp_remove_object_terms($postId, $terms, $taxonomy);

        if (!$status || is_wp_error($status)) {
            return self::error(__('Taxonomy could not be removed', 'bit-integrations-pro'));
        }

        return self::success(__('Taxonomy removed successfully', 'bit-integrations-pro'));
    }

    public static function addTagsToPost($defaultResponse, $fieldData, $integrationDetails)
    {
        $postId = $fieldData['postId'] ?? null;
        $tags = self::convertStringToArray($fieldData['tags'] ?? '');
        $append = self::getIntegrationValue($integrationDetails, 'append', false);

        if (empty($postId)) {
            return self::error(__('Post id is required', 'bit-integrations-pro'));
        }

        if (empty($tags)) {
            return self::error(__('Post Tags are required', 'bit-integrations-pro'));
        }

        $result = wp_set_post_terms($postId, $tags, 'post_tag', $append);

        if (is_wp_error($result)) {
            return self::error($result->get_error_message());
        }

        return self::success($result);
    }

    public static function removeTagsFromPost($defaultResponse, $fieldData, $integrationDetails)
    {
        $postId = $fieldData['postId'] ?? null;
        $tags = self::convertStringToArray($fieldData['tags'] ?? '');

        if (empty($postId)) {
            return self::error(__('Post id is required', 'bit-integrations-pro'));
        }

        if (empty($tags)) {
            return self::error(__('Post Tags are required', 'bit-integrations-pro'));
        }

        $status = wp_remove_object_terms($postId, $tags, 'post_tag');

        if (!$status || is_wp_error($status)) {
            return self::error(__('Tags could not be removed', 'bit-integrations-pro'));
        }

        return self::success(__('Tags removed successfully', 'bit-integrations-pro'));
    }

    public static function addNewImage($defaultResponse, $fieldData, $integrationDetails)
    {
        $url = filter_var($fieldData['image_url'] ?? '', FILTER_SANITIZE_URL);
        $hasTitle = \array_key_exists('title', $fieldData);
        $hasCaption = \array_key_exists('caption', $fieldData);
        $hasDescription = \array_key_exists('description', $fieldData);
        $title = $fieldData['title'] ?? null;
        $altText = $fieldData['altText'] ?? null;
        $caption = $fieldData['caption'] ?? null;
        $description = $fieldData['description'] ?? null;

        if (empty($url)) {
            return self::error(__('Image URL is required', 'bit-integrations-pro'));
        }

        self::ensureMediaIncludes();

        $imageId = media_sideload_image($url, 0, null, 'id');
        if (is_wp_error($imageId)) {
            return self::error($imageId->get_error_message());
        }

        $attachmentUrl = wp_get_attachment_url((int) $imageId);

        if (empty($attachmentUrl)) {
            return self::error(__('Failed to upload image.', 'bit-integrations-pro'));
        }

        $updateData = ['ID' => (int) $imageId];
        $shouldUpdateImage = false;

        if ($hasTitle) {
            $updateData['post_title'] = $title;
            $shouldUpdateImage = true;
        }

        if ($hasCaption) {
            $updateData['post_excerpt'] = $caption;
            $shouldUpdateImage = true;
        }

        if ($hasDescription) {
            $updateData['post_content'] = $description;
            $shouldUpdateImage = true;
        }

        if ($shouldUpdateImage) {
            $status = wp_update_post($updateData, true);

            if (is_wp_error($status) || !$status) {
                return self::error(__('Failed to update image metadata.', 'bit-integrations-pro'));
            }
        }

        if (!empty($altText)) {
            update_post_meta($imageId, '_wp_attachment_image_alt', $altText);
        }

        return self::success(['image_id' => $imageId, 'image_url' => $attachmentUrl]);
    }

    public static function deleteMedia($defaultResponse, $fieldData, $integrationDetails)
    {
        $id = $fieldData['id'] ?? null;
        $forceDelete = self::getIntegrationValue($integrationDetails, 'forceDelete', false);

        if (empty($id)) {
            return self::error(__('Media id is required', 'bit-integrations-pro'));
        }

        $status = wp_delete_attachment($id, $forceDelete);

        if (!$status) {
            return self::error(__('Failed to delete media', 'bit-integrations-pro'));
        }

        return self::success(__('Media deleted successfully', 'bit-integrations-pro'));
    }

    public static function renameMedia($defaultResponse, $fieldData, $integrationDetails)
    {
        $id = $fieldData['id'] ?? null;
        $title = $fieldData['title'] ?? null;

        if (empty($id)) {
            return self::error(__('Media id is required', 'bit-integrations-pro'));
        }

        if (empty($title)) {
            return self::error(__('Media new title is required', 'bit-integrations-pro'));
        }

        $media = get_post($id);

        if (!$media || $media->post_type !== 'attachment') {
            return self::error(__('Media not found with the provided ID or invalid media type.', 'bit-integrations-pro'));
        }

        $status = wp_update_post(['ID' => $id, 'post_title' => $title]);

        if (is_wp_error($status) || !$status) {
            return self::error(__('Failed to rename media.', 'bit-integrations-pro'));
        }

        return self::success(__('Media renamed successfully', 'bit-integrations-pro'));
    }

    public static function registerTaxonomy($defaultResponse, $fieldData, $integrationDetails)
    {
        $slug = $fieldData['slug'] ?? null;
        $name = $fieldData['name'] ?? null;
        $postTypes = self::convertStringToArray($fieldData['postTypes'] ?? '');
        $public = self::getIntegrationValue($integrationDetails, 'public', false);
        $adminUI = self::getIntegrationValue($integrationDetails, 'adminUI', false);
        $hierarchy = self::getIntegrationValue($integrationDetails, 'hierarchy', false);
        $restApi = self::getIntegrationValue($integrationDetails, 'restApi', false);

        if (empty($slug)) {
            return self::error(__('Taxonomy Identifier is required', 'bit-integrations-pro'));
        }

        if (empty($name)) {
            return self::error(__('Taxonomy Name is required', 'bit-integrations-pro'));
        }

        if (empty($postTypes)) {
            return self::error(__('Post Types is required', 'bit-integrations-pro'));
        }

        $taxonomy = register_taxonomy($slug, $postTypes, [
            'label'        => $name,
            'public'       => $public,
            'show_ui'      => $adminUI,
            'hierarchical' => $hierarchy,
            'description'  => $fieldData['description'] ?? '',
            'rewrite'      => ['slug' => $fieldData['rewriteSlug'] ?? $slug],
            'show_in_rest' => $restApi,
        ]);

        if (is_wp_error($taxonomy)) {
            return self::error($taxonomy->get_error_message());
        }

        return self::success(['taxonomy' => $slug]);
    }

    public static function unregisterTaxonomy($defaultResponse, $fieldData, $integrationDetails)
    {
        $slug = $fieldData['slug'] ?? null;

        if (empty($slug)) {
            return self::error(__('Taxonomy Identifier is required', 'bit-integrations-pro'));
        }

        if (!taxonomy_exists($slug)) {
            return self::error(__('Taxonomy not found with provided slug', 'bit-integrations-pro'));
        }

        $status = unregister_taxonomy($slug);

        if (!$status) {
            return self::error(__('Failed to unregister the taxonomy.', 'bit-integrations-pro'));
        }

        return self::success(__('Successfully unregistered the taxonomy.', 'bit-integrations-pro'));
    }

    public static function createNewTerm($defaultResponse, $fieldData, $integrationDetails)
    {
        return self::createTermByTax($fieldData, $fieldData['taxonomy'] ?? null);
    }

    public static function updateTerm($defaultResponse, $fieldData, $integrationDetails)
    {
        return self::updateTermByTax($fieldData, $fieldData['taxonomy'] ?? null);
    }

    public static function termDelete($defaultResponse, $fieldData, $integrationDetails)
    {
        $taxonomy = $fieldData['taxonomy'] ?? null;

        return self::deleteTermByTax($fieldData, $taxonomy);
    }

    public static function createCategory($defaultResponse, $fieldData, $integrationDetails)
    {
        return self::createTermByTax($fieldData, 'category');
    }

    public static function updateCategory($defaultResponse, $fieldData, $integrationDetails)
    {
        return self::updateTermByTax($fieldData, 'category');
    }

    public static function deleteCategory($defaultResponse, $fieldData, $integrationDetails)
    {
        return self::deleteTermByTax($fieldData, 'category');
    }

    public static function addCategoryToPost($defaultResponse, $fieldData, $integrationDetails)
    {
        $postId = $fieldData['postId'] ?? null;
        $categories = self::convertStringToArray($fieldData['categories'] ?? []);
        $append = self::getIntegrationValue($integrationDetails, 'append', false);

        if (empty($categories)) {
            $categories = self::convertStringToArray(self::getIntegrationValue($integrationDetails, 'categories', []));
        }

        if (empty($postId)) {
            return self::error(__('Post id is required', 'bit-integrations-pro'));
        }

        if (empty($categories)) {
            return self::error(__('Post category is required', 'bit-integrations-pro'));
        }

        $result = wp_set_post_categories($postId, $categories, $append);

        if (is_wp_error($result) || $result === false) {
            return self::error(__('Failed to add post category', 'bit-integrations-pro'));
        }

        return self::success($result);
    }

    // =========================================================================
    // Product Tags / Categories / Types (WooCommerce)
    // =========================================================================

    public static function createProductTag($defaultResponse, $fieldData, $integrationDetails)
    {
        return self::createTermByTax($fieldData, 'product_tag');
    }

    public static function updateProductTag($defaultResponse, $fieldData, $integrationDetails)
    {
        return self::updateTermByTax($fieldData, 'product_tag');
    }

    public static function deleteProductTag($defaultResponse, $fieldData, $integrationDetails)
    {
        return self::deleteTermByTax($fieldData, 'product_tag');
    }

    public static function createProductCategory($defaultResponse, $fieldData, $integrationDetails)
    {
        return self::createTermByTax($fieldData, 'product_cat');
    }

    public static function updateProductCategory($defaultResponse, $fieldData, $integrationDetails)
    {
        return self::updateTermByTax($fieldData, 'product_cat');
    }

    public static function deleteProductCategory($defaultResponse, $fieldData, $integrationDetails)
    {
        return self::deleteTermByTax($fieldData, 'product_cat');
    }

    public static function createProductType($defaultResponse, $fieldData, $integrationDetails)
    {
        return self::createTermByTax($fieldData, 'product_type');
    }

    public static function updateProductType($defaultResponse, $fieldData, $integrationDetails)
    {
        return self::updateTermByTax($fieldData, 'product_type');
    }

    public static function deleteProductType($defaultResponse, $fieldData, $integrationDetails)
    {
        return self::deleteTermByTax($fieldData, 'product_type');
    }

    public static function checkPluginActivationStatus($defaultResponse, $fieldData, $integrationDetails)
    {
        $pluginFile = $fieldData['pluginFile'] ?? null;

        if (empty($pluginFile)) {
            return self::error(__('Plugin File is required', 'bit-integrations-pro'));
        }

        self::ensurePluginIncludes();

        $isActive = is_plugin_active($pluginFile);

        return self::success($isActive ? __('Plugin is active.', 'bit-integrations-pro') : __('Plugin is not active.', 'bit-integrations-pro'));
    }

    public static function activatePlugin($defaultResponse, $fieldData, $integrationDetails)
    {
        $pluginFile = $fieldData['pluginFile'] ?? null;

        if (empty($pluginFile)) {
            return self::error(__('Plugin File is required', 'bit-integrations-pro'));
        }

        self::ensurePluginIncludes();

        if (is_plugin_active($pluginFile)) {
            return self::error(__('Plugin is already activated', 'bit-integrations-pro'));
        }

        $activate = activate_plugin($pluginFile);

        if (is_wp_error($activate)) {
            return self::error(__('Failed to activate the plugin.', 'bit-integrations-pro'));
        }

        return self::success(__('Plugin is successfully activated.', 'bit-integrations-pro'));
    }

    private static function success($data)
    {
        return ['success' => true, 'message' => $data];
    }

    private static function error($message)
    {
        return ['success' => false, 'message' => $message];
    }

    private static function convertStringToArray($value)
    {
        if (!\is_array($value)) {
            if (empty($value)) {
                return [];
            }

            $value = explode(',', (string) $value);
        }

        $items = [];

        foreach ($value as $item) {
            if (!\is_scalar($item)) {
                continue;
            }

            $item = trim((string) $item);

            if ($item === '') {
                continue;
            }

            $items[] = $item;
        }

        return array_values(array_unique($items));
    }

    private static function getIntegrationValue($integrationDetails, $key, $default = null)
    {
        if (!\is_object($integrationDetails)) {
            return $default;
        }

        if (property_exists($integrationDetails, $key)) {
            return $integrationDetails->{$key};
        }

        return $default;
    }

    private static function ensureMediaIncludes()
    {
        if (!\function_exists('media_sideload_image')) {
            include_once ABSPATH . 'wp-admin/includes/media.php';
        }

        if (!\function_exists('download_url')) {
            include_once ABSPATH . 'wp-admin/includes/file.php';
        }

        if (!\function_exists('wp_generate_attachment_metadata')) {
            include_once ABSPATH . 'wp-admin/includes/image.php';
        }
    }

    private static function ensurePluginIncludes()
    {
        if (!\function_exists('is_plugin_active') || !\function_exists('activate_plugin')) {
            include_once ABSPATH . 'wp-admin/includes/plugin.php';
        }
    }

    private static function buildTermArgs($name = null, $slug = null, $description = null)
    {
        $args = [];

        if ($name !== null && $name !== '') {
            $args['name'] = $name;
        }

        if ($slug !== null && $slug !== '') {
            $args['slug'] = $slug;
        }

        if ($description !== null && $description !== '') {
            $args['description'] = $description;
        }

        return $args;
    }

    private static function isValidTerm($id, $taxonomy)
    {
        $term = get_term($id, $taxonomy);

        return $term && !is_wp_error($term);
    }

    private static function createTermByTax(array $fieldData, $taxonomy)
    {
        $name = $fieldData['name'] ?? null;
        $slug = $fieldData['slug'] ?? null;
        $description = $fieldData['description'] ?? null;

        if (empty($name)) {
            return self::error(__('Name is required', 'bit-integrations-pro'));
        }

        if (empty($taxonomy)) {
            return self::error(__('Taxonomy is required', 'bit-integrations-pro'));
        }

        $termArgs = self::buildTermArgs(null, $slug, $description);
        $term = wp_insert_term($name, $taxonomy, $termArgs);

        if (is_wp_error($term)) {
            return self::error($term->get_error_message());
        }

        return self::success($term);
    }

    private static function updateTermByTax(array $fieldData, $taxonomy)
    {
        $id = $fieldData['termId'] ?? null;
        $name = $fieldData['name'] ?? null;
        $slug = $fieldData['slug'] ?? null;
        $description = $fieldData['description'] ?? null;

        if (empty($id)) {
            return self::error(__('Id is required', 'bit-integrations-pro'));
        }

        if (empty($taxonomy)) {
            return self::error(__('Taxonomy is required', 'bit-integrations-pro'));
        }

        if (!self::isValidTerm($id, $taxonomy)) {
            return self::error(__('Term not found.', 'bit-integrations-pro'));
        }

        $args = self::buildTermArgs($name, $slug, $description);

        if (empty($args)) {
            return self::error(__('Nothing to update.', 'bit-integrations-pro'));
        }

        $term = wp_update_term($id, $taxonomy, $args);

        if (is_wp_error($term)) {
            return self::error($term->get_error_message());
        }

        return self::success($term);
    }

    private static function deleteTermByTax(array $fieldData, $taxonomy)
    {
        $id = $fieldData['termId'] ?? null;

        if (empty($id)) {
            return self::error(__('Id is required', 'bit-integrations-pro'));
        }

        if (empty($taxonomy)) {
            return self::error(__('Taxonomy is required', 'bit-integrations-pro'));
        }

        if (!self::isValidTerm($id, $taxonomy)) {
            return self::error(__('Term not found.', 'bit-integrations-pro'));
        }

        $status = wp_delete_term($id, $taxonomy);

        if (!$status) {
            return self::error(__('Failed to delete term', 'bit-integrations-pro'));
        }

        return self::success(__('Term deleted successfully', 'bit-integrations-pro'));
    }
}
