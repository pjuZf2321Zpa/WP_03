<?php

namespace BitApps\IntegrationsPro\Triggers\AvadaForms;

use BitApps\IntegrationsPro\Config;

final class AvadaFormsController
{
    public static function info()
    {
        return [
            'name'              => 'Avada Forms',
            'title'             => __('Capture Avada Forms form submission to trigger the workflow.', 'bit-integrations-pro'),
            'type'              => 'custom_form_submission',
            'is_active'         => AvadaFormsHelper::isPluginInstalled(),
            'documentation_url' => 'https://bit-integrations.com/wp-docs/trigger/avada-forms-integrations/',
            'tutorial_url'      => 'https://www.youtube.com/playlist?list=PL7c6CDwwm-AIPl58sHN5fQALU8ofvu1Qb',
            'tasks'             => [
                'action' => 'avada-forms/get',
                'method' => 'get',
            ],
            'fetch' => [
                'action' => 'trigger/test',
                'method' => 'post',
            ],
            'fetch_remove' => [
                'action' => 'trigger/test/remove',
                'method' => 'post',
            ],
            'isPro' => true
        ];
    }

    public function getAllTasks()
    {
        if (!AvadaFormsHelper::isPluginInstalled()) {
            wp_send_json_error(\sprintf(__('%s is not installed or activated', 'bit-integrations-pro'), 'Avada Forms'));
        }

        wp_send_json_success([
            ['form_name' => __('Form Submission', 'bit-integrations-pro'), 'triggered_entity_id' => 'fusion_form_submission_data', 'skipPrimaryKey' => false],
        ]);
    }

    public static function handleFormSubmission($formSubmission, $formId)
    {
        $helperClass = bit_integrations_get_class('Core\\Util\\Helper');

        $formData = AvadaFormsHelper::formatFields($formSubmission, $formId);

        if (empty($formData) || !\is_array($formData)) {
            return;
        }

        $helperClass::setTestData(Config::withFreePrefix('fusion_form_submission_data_test'), array_values($formData), 'form_id.value', $formData['form_id']['value']);

        return static::flowExecute('fusion_form_submission_data', $formData);
    }

    private static function flowExecute($triggered_entity_id, $formData)
    {
        $helperClass = bit_integrations_get_class('Core\\Util\\Helper');
        $flowClass = bit_integrations_get_class('Flow\\Flow');

        $flows = $flowClass::exists('AvadaForms', $triggered_entity_id);

        if (!$flows) {
            return;
        }

        foreach ($flows as $flow) {
            $flowDetails = $helperClass::parseFlowDetails($flow->flow_details);

            if (!isset($flowDetails->primaryKey)) {
                continue;
            }

            if ($helperClass::isPrimaryKeysMatch($formData, $flowDetails->primaryKey)) {
                $data = array_column($formData, 'value', 'name');
                $flowClass::execute('AvadaForms', $flow->triggered_entity_id, $data, [$flow]);
            }
        }

        return ['type' => 'success'];
    }
}
