<?php

namespace FluentCartPro\App\Modules\Reviews\Models;

use FluentCart\App\Models\Model;
use FluentCart\App\Models\ProductReview;

class ReviewInteraction extends Model
{
    const UPDATED_AT = null;

    const TYPE_VOTE = 'vote';
    const TYPE_REPORT = 'report';

    // Vote direction. -1 rather than 0 for "not helpful" so an unset or
    // miscast value can never read as a vote, and SUM(value) stays a usable
    // net score.
    const VALUE_HELPFUL = 1;
    const VALUE_NOT_HELPFUL = -1;

    protected $table = 'fct_review_interactions';

    protected $primaryKey = 'id';

    protected $guarded = ['id'];

    protected $fillable = [
        'review_id',
        'user_id',
        'ip_address',
        'type',
        'value',
        'note',
    ];

    protected $casts = [
        'review_id' => 'integer',
        'user_id'   => 'integer',
        'value'     => 'integer',
    ];

    public function scopeVotes($query)
    {
        return $query->where('type', self::TYPE_VOTE);
    }

    public function scopeReports($query)
    {
        return $query->where('type', self::TYPE_REPORT);
    }

    public function scopeForReview($query, $reviewId)
    {
        return $query->where('review_id', (int) $reviewId);
    }

    public function scopeHelpful($query)
    {
        return $query->where('value', self::VALUE_HELPFUL);
    }

    public function scopeNotHelpful($query)
    {
        return $query->where('value', self::VALUE_NOT_HELPFUL);
    }

    /**
     * Helpful / not-helpful tallies for one review — the shape every vote
     * count surface needs, so the two queries live in one place.
     *
     * @param int $reviewId
     * @return array{helpful:int,not_helpful:int}
     */
    public static function voteCountsFor($reviewId): array
    {
        return [
            'helpful'     => static::votes()->forReview($reviewId)->helpful()->count(),
            'not_helpful' => static::votes()->forReview($reviewId)->notHelpful()->count(),
        ];
    }

    /**
     * Whether the free plugin's ProductReview::votes() relation is usable by
     * this Pro version.
     *
     * The relation lives in the free plugin but targets a Pro model, so a
     * store that updates one plugin without the other can have a votes()
     * method pointing at a class this version no longer ships — checking the
     * method alone is not enough, the relation has to resolve.
     */
    public static function isVotesRelationAvailable(): bool
    {
        static $available = null;

        if ($available === null) {
            try {
                $available = method_exists(ProductReview::class, 'votes')
                    && (new ProductReview())->votes()->getRelated() instanceof self;
            } catch (\Throwable $e) {
                $available = false;
            }
        }

        return $available;
    }

    public function getReview()
    {
        return ProductReview::query()->find($this->review_id);
    }
}
