<?php

namespace WPAICG\Lib\Chat\Frontend\Ajax\Handlers;

use WPAICG\Lib\Chat\Frontend\Ajax\Utils\ChatUploadLogger;
use WPAICG\Lib\Chat\Frontend\Ajax\Utils\ChatUploadConfigLoader;
use WPAICG\AIPKit_Providers;
use WPAICG\Chat\Core\AIPKit_Chat_File_Upload_Provider_Resolver;
use WPAICG\Chat\Storage\BotStorage;
use WPAICG\Core\AIPKit_AI_Caller;
use WPAICG\Lib\VectorStores\FileUpload\AIPKit_Vector_File_Ingestion_Job;
use WP_Error;

if (!defined('ABSPATH')) {
    exit;
}

/** Shared chunked ingestion for external and Local chat uploads. */
trait AIPKit_Chat_Vector_Upload
{
    private $logger;
    private $bot_storage;
    private $ai_caller;
    private $vector_store_manager;

    public function __construct(ChatUploadConfigLoader $config_loader, ChatUploadLogger $logger)
    {
        $this->logger = $logger;

        // Pinecone relies on the main loader; Qdrant and Chroma also support lazy dependencies.
        if (self::UPLOAD_PROVIDER !== 'pinecone') {
            $dependencies = [
                BotStorage::class => 'classes/chatbot/bots.php',
                AIPKit_AI_Caller::class => 'classes/ai/caller.php',
                AIPKit_Providers::class => 'classes/ai/settings.php',
            ];
            foreach ($dependencies as $class => $relative_path) {
                if (!class_exists($class)) {
                    $path = WPAICG_PLUGIN_DIR . $relative_path;
                    if (file_exists($path)) {
                        require_once $path;
                    }
                }
            }
        }

        $this->bot_storage = class_exists(BotStorage::class) ? new BotStorage() : null;
        $this->ai_caller = class_exists(AIPKit_AI_Caller::class) ? new AIPKit_AI_Caller() : null;
        $this->vector_store_manager = $config_loader->get_vector_store_manager();
    }

    /** @return array<string,mixed>|WP_Error */
    private function create_upload_job(array $file_data, ?int $user_id, ?string $session_id, int $bot_id, string $conversation_uuid = '')
    {
        $bot_settings = $this->get_bot_settings_or_error($bot_id);
        if (is_wp_error($bot_settings)) {
            return $bot_settings;
        }

        return AIPKit_Vector_File_Ingestion_Job::create_from_uploaded_file([
            'provider' => self::UPLOAD_PROVIDER,
            'target_id' => (string) $bot_settings[self::UPLOAD_TARGET_SETTING],
            'embedding_provider_key' => (string) $bot_settings['vector_embedding_provider'],
            'embedding_model' => (string) $bot_settings['vector_embedding_model'],
            'file_data' => $file_data,
            'context' => 'chat',
            'user_id' => $user_id ?: 0,
            'session_id' => $session_id ?: '',
            'bot_id' => $bot_id,
            'conversation_uuid' => $conversation_uuid,
            'allowed_mime_types' => apply_filters('aipkit_chat_upload_allowed_mime_types', ['text/plain', 'application/pdf']),
            'log_callback' => [$this->logger, 'log_event'],
        ]);
    }

    /** @return array<string,mixed>|WP_Error */
    private function process_upload_job(string $job_id, array $provider_config, array $binding)
    {
        if (!$this->ai_caller || !$this->vector_store_manager) {
            return $this->get_dependency_error();
        }

        return AIPKit_Vector_File_Ingestion_Job::process_job(
            $job_id,
            $this->vector_store_manager,
            $this->ai_caller,
            $provider_config,
            [$this->logger, 'log_event'],
            $binding
        );
    }
}

/** Pinecone chatbot uploads through the shared chunked ingestion worker. */
class ChatFileUploadPineconeHandler
{
    use AIPKit_Chat_Vector_Upload;

    private const UPLOAD_PROVIDER = 'pinecone';
    private const UPLOAD_TARGET_SETTING = 'pinecone_index_name';

    /** @return array<string,string>|WP_Error */
    public function get_provider_api_config()
    {
        if (!class_exists(AIPKit_Providers::class)) {
            return new WP_Error('dependency_missing_pinecone_providers', __('Provider configuration component is missing for Pinecone.', 'gpt3-ai-content-generator'), ['status' => 500]);
        }
        $pinecone_data = AIPKit_Providers::get_provider_data('Pinecone');
        if (empty($pinecone_data['api_key'])) {
            return new WP_Error('missing_pinecone_api_key', __('Pinecone API Key is not configured.', 'gpt3-ai-content-generator'), ['status' => 500]);
        }
        return ['api_key' => $pinecone_data['api_key']];
    }

    /**
     * Keep the provider-specific argument name for existing callers.
     * Job credentials are resolved by the ingestion worker.
     * @return array<string,mixed>|WP_Error
     */
    public function process_upload(array $file_data, ?int $user_id, ?string $session_id, array $pinecone_config, int $bot_id, string $conversation_uuid = '')
    {
        return $this->create_upload_job($file_data, $user_id, $session_id, $bot_id, $conversation_uuid);
    }

    /** @return array<string,mixed>|WP_Error */
    public function continue_upload_job(string $job_id, array $pinecone_config, array $binding = [])
    {
        return $this->process_upload_job($job_id, $pinecone_config, $binding);
    }

    private function get_dependency_error(): WP_Error
    {
        return new WP_Error('internal_error_pinecone_deps', __('Core components for Pinecone file upload are not available.', 'gpt3-ai-content-generator'), ['status' => 500]);
    }

    /** @return array<string,mixed>|WP_Error */
    private function get_bot_settings_or_error(int $bot_id)
    {
        if (!$this->bot_storage || !$this->ai_caller || !$this->vector_store_manager) {
            return $this->get_dependency_error();
        }

        $bot_settings = $this->bot_storage->get_chatbot_settings($bot_id);
        $pinecone_index_name = AIPKit_Chat_File_Upload_Provider_Resolver::vector_target('pinecone', $bot_settings);
        $embedding_provider_key = $bot_settings['vector_embedding_provider'] ?? null;
        $embedding_model = $bot_settings['vector_embedding_model'] ?? null;

        if (empty($pinecone_index_name)) {
            return new WP_Error('pinecone_index_not_configured', __('This chatbot is not configured for Pinecone file uploads (index name missing).', 'gpt3-ai-content-generator'), ['status' => 400]);
        }
        if (empty($embedding_provider_key) || empty($embedding_model)) {
            return new WP_Error('embedding_config_missing', __('Embedding provider or model is not configured for this chatbot.', 'gpt3-ai-content-generator'), ['status' => 400]);
        }

        return [
            'pinecone_index_name' => (string) $pinecone_index_name,
            'vector_embedding_provider' => (string) $embedding_provider_key,
            'vector_embedding_model' => (string) $embedding_model,
        ];
    }
}

/** Qdrant chatbot uploads through the shared chunked ingestion worker. */
class ChatFileUploadQdrantHandler
{
    use AIPKit_Chat_Vector_Upload;

    private const UPLOAD_PROVIDER = 'qdrant';
    private const UPLOAD_TARGET_SETTING = 'qdrant_collection_name';

    /** @return array<string,string>|WP_Error */
    public function get_provider_api_config()
    {
        if (!class_exists(AIPKit_Providers::class)) {
            return new WP_Error('dependency_missing_qdrant_handler_config', __('Provider configuration component is missing for Qdrant.', 'gpt3-ai-content-generator'), ['status' => 500]);
        }

        $qdrant_data = AIPKit_Providers::get_provider_data('Qdrant');
        if (empty($qdrant_data['url'])) {
            return new WP_Error('missing_qdrant_url_config', __('Qdrant URL is not configured in global settings.', 'gpt3-ai-content-generator'), ['status' => 500]);
        }
        if (empty($qdrant_data['api_key'])) {
            return new WP_Error('missing_qdrant_api_key_config', __('Qdrant API Key is not configured in global settings.', 'gpt3-ai-content-generator'), ['status' => 500]);
        }

        return ['url' => $qdrant_data['url'], 'api_key' => $qdrant_data['api_key']];
    }

    /**
     * Keep the provider-specific argument name for existing callers.
     * Job credentials are resolved by the ingestion worker.
     * @return array<string,mixed>|WP_Error
     */
    public function process_upload(array $file_data, ?int $user_id, ?string $session_id, array $qdrant_config, int $bot_id, string $conversation_uuid = '')
    {
        return $this->create_upload_job($file_data, $user_id, $session_id, $bot_id, $conversation_uuid);
    }

    /** @return array<string,mixed>|WP_Error */
    public function continue_upload_job(string $job_id, array $qdrant_config, array $binding = [])
    {
        return $this->process_upload_job($job_id, $qdrant_config, $binding);
    }

    private function get_dependency_error(): WP_Error
    {
        return new WP_Error('internal_error_qdrant_deps_process', __('Core components for Qdrant file upload are not available.', 'gpt3-ai-content-generator'), ['status' => 500]);
    }

    /** @return array<string,mixed>|WP_Error */
    private function get_bot_settings_or_error(int $bot_id)
    {
        if (!$this->bot_storage || !$this->ai_caller || !$this->vector_store_manager) {
            return $this->get_dependency_error();
        }

        $bot_settings = $this->bot_storage->get_chatbot_settings($bot_id);
        $qdrant_collection_name = AIPKit_Chat_File_Upload_Provider_Resolver::vector_target('qdrant', $bot_settings);
        $embedding_provider_key = $bot_settings['vector_embedding_provider'] ?? null;
        $embedding_model = $bot_settings['vector_embedding_model'] ?? null;

        if (empty($qdrant_collection_name)) {
            return new WP_Error('qdrant_collection_not_configured', __('This chatbot is not configured for Qdrant file uploads (collection name missing).', 'gpt3-ai-content-generator'), ['status' => 400]);
        }
        if (empty($embedding_provider_key) || empty($embedding_model)) {
            return new WP_Error('embedding_config_missing_qdrant', __('Embedding provider or model is not configured for this chatbot.', 'gpt3-ai-content-generator'), ['status' => 400]);
        }

        return [
            'qdrant_collection_name' => (string) $qdrant_collection_name,
            'vector_embedding_provider' => (string) $embedding_provider_key,
            'vector_embedding_model' => (string) $embedding_model,
        ];
    }
}

/** Chroma chatbot uploads through the shared chunked ingestion worker. */
class ChatFileUploadChromaHandler
{
    use AIPKit_Chat_Vector_Upload;

    private const UPLOAD_PROVIDER = 'chroma';
    private const UPLOAD_TARGET_SETTING = 'chroma_collection_name';

    /** @return array<string,string>|WP_Error */
    public function get_provider_api_config()
    {
        if (!class_exists(AIPKit_Providers::class)) {
            return new WP_Error('dependency_missing_chroma_handler_config', __('Provider configuration component is missing for Chroma.', 'gpt3-ai-content-generator'), ['status' => 500]);
        }

        $chroma_data = AIPKit_Providers::get_provider_data('Chroma');
        if (empty($chroma_data['url'])) {
            return new WP_Error('missing_chroma_url_config', __('Chroma URL is not configured in global settings.', 'gpt3-ai-content-generator'), ['status' => 500]);
        }

        return [
            'url' => (string) $chroma_data['url'],
            'api_key' => (string) ($chroma_data['api_key'] ?? ''),
            'tenant' => (string) ($chroma_data['tenant'] ?? 'default_tenant'),
            'database' => (string) ($chroma_data['database'] ?? 'default_database'),
        ];
    }

    /**
     * Keep the provider-specific argument name for existing callers.
     * Job credentials are resolved by the ingestion worker.
     * @return array<string,mixed>|WP_Error
     */
    public function process_upload(array $file_data, ?int $user_id, ?string $session_id, array $chroma_config, int $bot_id, string $conversation_uuid = '')
    {
        return $this->create_upload_job($file_data, $user_id, $session_id, $bot_id, $conversation_uuid);
    }

    /** @return array<string,mixed>|WP_Error */
    public function continue_upload_job(string $job_id, array $chroma_config, array $binding = [])
    {
        return $this->process_upload_job($job_id, $chroma_config, $binding);
    }

    private function get_dependency_error(): WP_Error
    {
        return new WP_Error('internal_error_chroma_deps_process', __('Core components for Chroma file upload are not available.', 'gpt3-ai-content-generator'), ['status' => 500]);
    }

    /** @return array<string,mixed>|WP_Error */
    private function get_bot_settings_or_error(int $bot_id)
    {
        if (!$this->bot_storage || !$this->ai_caller || !$this->vector_store_manager) {
            return $this->get_dependency_error();
        }

        $bot_settings = $this->bot_storage->get_chatbot_settings($bot_id);
        $chroma_collection_name = AIPKit_Chat_File_Upload_Provider_Resolver::vector_target('chroma', $bot_settings);
        $embedding_provider_key = $bot_settings['vector_embedding_provider'] ?? null;
        $embedding_model = $bot_settings['vector_embedding_model'] ?? null;

        if (empty($chroma_collection_name)) {
            return new WP_Error('chroma_collection_not_configured', __('This chatbot is not configured for Chroma file uploads (collection name missing).', 'gpt3-ai-content-generator'), ['status' => 400]);
        }
        if (empty($embedding_provider_key) || empty($embedding_model)) {
            return new WP_Error('embedding_config_missing_chroma', __('Embedding provider or model is not configured for this chatbot.', 'gpt3-ai-content-generator'), ['status' => 400]);
        }

        return [
            'chroma_collection_name' => (string) $chroma_collection_name,
            'vector_embedding_provider' => (string) $embedding_provider_key,
            'vector_embedding_model' => (string) $embedding_model,
        ];
    }
}

/** Local storage uses the same extraction, embedding and job handling as external stores. */
class ChatFileUploadLocalHandler
{
    use AIPKit_Chat_Vector_Upload;
    private const UPLOAD_PROVIDER = 'local';
    private const UPLOAD_TARGET_SETTING = 'local_store_id';

    public function get_provider_api_config(): array { return []; }

    public function process_upload(array $file_data, ?int $user_id, ?string $session_id, array $config, int $bot_id, string $conversation_uuid = '')
    {
        return $this->create_upload_job($file_data, $user_id, $session_id, $bot_id, $conversation_uuid);
    }

    public function continue_upload_job(string $job_id, array $config, array $binding = [])
    {
        return $this->process_upload_job($job_id, $config, $binding);
    }

    private function get_dependency_error(): WP_Error
    {
        return new WP_Error('local_upload_dependencies_missing', __('File upload components are unavailable.', 'gpt3-ai-content-generator'), ['status' => 500]);
    }

    private function get_bot_settings_or_error(int $bot_id)
    {
        if (!$this->bot_storage || !$this->ai_caller || !$this->vector_store_manager) { return $this->get_dependency_error(); }
        $settings = $this->bot_storage->get_chatbot_settings($bot_id);
        $settings['local_store_id'] = AIPKit_Chat_File_Upload_Provider_Resolver::vector_target('local', $settings);
        if ($settings['local_store_id'] === '' || empty($settings['vector_embedding_provider']) || empty($settings['vector_embedding_model'])) {
            return new WP_Error('local_upload_not_configured', __('Select a Local store and embedding model for this chatbot.', 'gpt3-ai-content-generator'), ['status' => 400]);
        }
        return $settings;
    }
}
