<?php

/**
 * MailerLite    Record Api
 */

namespace BitApps\IntegrationsPro\Actions\MailerLite;

class MailerLiteHelperPro
{
    public static function deleteSubscriber($default, $subscriberId, $finalData, $baseUrl, $headers, $forget = false)
    {
        $httpHelperClass = bit_integrations_get_class('Core\\Util\\HttpHelper');

        $apiEndpoint = $forget
            ? $baseUrl . 'subscribers/' . $subscriberId . '/forget'
            : $baseUrl . 'subscribers/' . $subscriberId;

        $response = $httpHelperClass::request($apiEndpoint, $forget ? 'POST' : 'DELETE', $finalData, $headers);

        return !$forget && empty($response) ? true : $response;
    }

    public static function unassignSubscriberFromGroup($default, $subscriberId, $groupId, $baseUrl, $headers)
    {
        if (empty($groupId) || empty($subscriberId)) {
            return [
                'success' => false,
                'message' => __('Group and subscriber are required', 'bit-integrations-pro'),
                'code'    => 400
            ];
        }

        $httpHelperClass = bit_integrations_get_class('Core\\Util\\HttpHelper');

        $apiEndpoint = $baseUrl . "subscribers/{$subscriberId}/groups/{$groupId}";

        return $httpHelperClass::delete($apiEndpoint, null, $headers);
    }
}
