<?php

namespace BitApps\IntegrationsPro\Actions\ClickWhale;

/**
 * ClickWhale link write actions.
 *
 * Ported from bit-pi's ClickWhaleService. ClickWhale exposes no write API, so the
 * links table is written directly — the same approach bit-pi takes.
 */
class ClickWhaleProHelper
{
    public static function createLink($defaultResponse, $fieldData, $utilities = null, $integrationDetails = null)
    {
        if (!ClickWhaleHelper::isPluginActive()) {
            return ClickWhaleHelper::errorResponse(__('ClickWhale is not installed or activated', 'bit-integrations-pro'));
        }

        if ($invalid = ClickWhaleHelper::requireFields($fieldData, ['title', 'url'])) {
            return $invalid;
        }

        $url = esc_url_raw($fieldData['url']);

        if (empty($url)) {
            return ClickWhaleHelper::errorResponse(__('A valid URL is required.', 'bit-integrations-pro'));
        }

        global $wpdb;

        $slug = self::resolveSlug($fieldData);

        // ClickWhale has no unique index on slug and does not check for collisions on
        // save, but its redirect resolves with LIMIT 1 — so a duplicate slug would
        // insert cleanly and then be permanently unreachable. Fail instead.
        if ($slug !== '' && self::slugExists($slug)) {
            return ClickWhaleHelper::errorResponse(
                // translators: %s: link slug
                wp_sprintf(__('The slug %s is already in use by another ClickWhale link.', 'bit-integrations-pro'), $slug)
            );
        }

        $now = current_time('mysql');

        $linkData = [
            'title'       => sanitize_text_field($fieldData['title']),
            'url'         => $url,
            'slug'        => $slug,
            'description' => sanitize_textarea_field($fieldData['description'] ?? ''),
            // bit-pi hardcoded 301; the redirect type is now selectable in Utilities
            // and still defaults to 301 when left unset.
            'redirection' => (int) ClickWhaleHelper::utilityValue($utilities, 'selected_redirection', 301),
            'author'      => self::resolveAuthorId($integrationDetails),
            'created_at'  => $now,
            'updated_at'  => $now,
        ];

        foreach (['nofollow', 'sponsored'] as $flag) {
            $value = ClickWhaleHelper::flagValue($utilities, 'selected_' . $flag);

            if ($value !== null) {
                $linkData[$flag] = $value;
            }
        }

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery -- ClickWhale exposes no write API
        if (!$wpdb->insert(ClickWhaleHelper::getTableName(), $linkData)) {
            return ClickWhaleHelper::errorResponse(__('Failed to create link in ClickWhale.', 'bit-integrations-pro'));
        }

        return ClickWhaleHelper::successResponse(
            __('Link created successfully', 'bit-integrations-pro'),
            ClickWhaleHelper::getLinkRecord($wpdb->insert_id)
        );
    }

    public static function updateLink($defaultResponse, $fieldData, $utilities = null)
    {
        if (!ClickWhaleHelper::isPluginActive()) {
            return ClickWhaleHelper::errorResponse(__('ClickWhale is not installed or activated', 'bit-integrations-pro'));
        }

        if ($invalid = ClickWhaleHelper::requireFields($fieldData, ['link_id'])) {
            return $invalid;
        }

        $linkId = (int) $fieldData['link_id'];
        $existing = ClickWhaleHelper::getLinkRecord($linkId);

        if (empty($existing)) {
            return ClickWhaleHelper::errorResponse(__('Link not found.', 'bit-integrations-pro'));
        }

        // bit-pi read title, slug and description back off the existing row rather than
        // the field map, so an update could only ever change the URL. Mapped values are
        // honoured here, and anything unmapped is left untouched.
        $fields = ['updated_at' => current_time('mysql')];

        if (isset($fieldData['title']) && $fieldData['title'] !== '') {
            $fields['title'] = sanitize_text_field($fieldData['title']);
        }

        if (isset($fieldData['url']) && $fieldData['url'] !== '') {
            $url = esc_url_raw($fieldData['url']);

            if (empty($url)) {
                return ClickWhaleHelper::errorResponse(__('A valid URL is required.', 'bit-integrations-pro'));
            }

            $fields['url'] = $url;
        }

        if (isset($fieldData['slug']) && $fieldData['slug'] !== '') {
            // sanitize_title directly rather than resolveSlug: the title fallback only
            // makes sense on create, and this branch already knows the slug is set.
            $slug = sanitize_title($fieldData['slug']);

            if ($slug !== '' && self::slugExists($slug, $linkId)) {
                return ClickWhaleHelper::errorResponse(
                    // translators: %s: link slug
                    wp_sprintf(__('The slug %s is already in use by another ClickWhale link.', 'bit-integrations-pro'), $slug)
                );
            }

            $fields['slug'] = $slug;
        }

        if (isset($fieldData['description']) && $fieldData['description'] !== '') {
            $fields['description'] = sanitize_textarea_field($fieldData['description']);
        }

        $redirection = ClickWhaleHelper::utilityValue($utilities, 'selected_redirection', '');

        if ($redirection !== '') {
            $fields['redirection'] = (int) $redirection;
        }

        foreach (['nofollow', 'sponsored'] as $flag) {
            $value = ClickWhaleHelper::flagValue($utilities, 'selected_' . $flag);

            if ($value !== null) {
                $fields[$flag] = $value;
            }
        }

        // Only updated_at means the flow mapped nothing but link_id. Writing that would
        // bump the timestamp and report success while changing nothing the author asked
        // for, so say so instead.
        if (\count($fields) === 1) {
            return ClickWhaleHelper::errorResponse(
                __('Nothing to update — map at least one field, or enable a setting under Utilities.', 'bit-integrations-pro')
            );
        }

        global $wpdb;

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery -- ClickWhale exposes no write API
        $updated = $wpdb->update(ClickWhaleHelper::getTableName(), $fields, ['id' => $linkId]);

        if ($updated === false) {
            return ClickWhaleHelper::errorResponse(__('Failed to update link.', 'bit-integrations-pro'));
        }

        return ClickWhaleHelper::successResponse(
            __('Link updated successfully', 'bit-integrations-pro'),
            ClickWhaleHelper::getLinkRecord($linkId)
        );
    }

    public static function deleteLink($defaultResponse, $fieldData)
    {
        if (!ClickWhaleHelper::isPluginActive()) {
            return ClickWhaleHelper::errorResponse(__('ClickWhale is not installed or activated', 'bit-integrations-pro'));
        }

        if ($invalid = ClickWhaleHelper::requireFields($fieldData, ['link_id'])) {
            return $invalid;
        }

        $linkId = (int) $fieldData['link_id'];

        if (empty(ClickWhaleHelper::getLinkRecord($linkId))) {
            return ClickWhaleHelper::errorResponse(__('Link not found.', 'bit-integrations-pro'));
        }

        global $wpdb;

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery -- ClickWhale exposes no write API
        $deleted = $wpdb->delete(ClickWhaleHelper::getTableName(), ['id' => $linkId]);

        if ($deleted === false) {
            return ClickWhaleHelper::errorResponse(__('Failed to delete link.', 'bit-integrations-pro'));
        }

        return ClickWhaleHelper::successResponse(
            __('Link deleted successfully', 'bit-integrations-pro'),
            ['link_id' => $linkId]
        );
    }

    /**
     * Slugs are what ClickWhale redirects on, so a mapped value is sanitised and an
     * unmapped one is derived from the title rather than left blank.
     *
     * @param array $fieldData
     *
     * @return string
     */
    private static function resolveSlug($fieldData)
    {
        if (!empty($fieldData['slug'])) {
            return sanitize_title($fieldData['slug']);
        }

        return !empty($fieldData['title']) ? sanitize_title($fieldData['title']) : '';
    }

    /**
     * Is this slug already taken by another link?
     *
     * @param string   $slug
     * @param null|int $ignoreId Link being updated, so it does not match itself
     *
     * @return bool
     */
    private static function slugExists($slug, $ignoreId = null)
    {
        global $wpdb;

        $table = ClickWhaleHelper::getTableName();

        if ($ignoreId) {
            // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery -- table name comes from ClickWhale's own accessor
            $found = $wpdb->get_var($wpdb->prepare("SELECT id FROM {$table} WHERE slug = %s AND id != %d LIMIT 1", $slug, (int) $ignoreId));
        } else {
            // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery -- table name comes from ClickWhale's own accessor
            $found = $wpdb->get_var($wpdb->prepare("SELECT id FROM {$table} WHERE slug = %s LIMIT 1", $slug));
        }

        return !empty($found);
    }

    /**
     * Decide who owns a created link.
     *
     * The owner is a per-flow choice rather than something that varies per run, so it
     * comes from the selectedAuthor dropdown rather than the field map. Falling back
     * to get_current_user_id() alone would write author 0 for any front-end trigger,
     * leaving rows the ClickWhale admin cannot attribute.
     *
     * @param null|object $integrationDetails
     *
     * @return int
     */
    private static function resolveAuthorId($integrationDetails)
    {
        $selected = isset($integrationDetails->selectedAuthor) ? $integrationDetails->selectedAuthor : '';

        if ($selected !== '') {
            $user = get_user_by('id', (int) $selected);

            if ($user) {
                return (int) $user->ID;
            }
        }

        return get_current_user_id();
    }
}
