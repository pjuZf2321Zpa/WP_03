<?php

namespace FluentCartPro\App\Hooks\Handlers;

use FluentCart\App\Modules\MultiCurrency\Services\PriceConverter;
use FluentCart\App\Modules\MultiCurrency\Services\CurrencySnapshot;
use FluentCart\App\Modules\MultiCurrency\Services\CartCurrency;
use FluentCart\Api\Resource\CustomerResource;
use FluentCart\Api\StoreSettings;
use FluentCart\App\Helpers\CartHelper;
use FluentCart\App\Helpers\Helper;
use FluentCart\App\Events\PlanChanged;
use FluentCart\App\Helpers\Status;
use FluentCart\App\Models\Meta;
use FluentCart\App\Models\Order;
use FluentCart\App\Models\OrderItem;
use FluentCart\App\Models\ProductVariation;
use FluentCart\App\Models\Subscription;
use FluentCart\App\Services\PlanUpgradeService;
use FluentCart\App\Services\Reminders\SubscriptionReminderService;
use FluentCart\Framework\Support\Arr;

class UpgradeHandler
{
    public function register()
    {
        add_action('fluent_cart_action_upgrade_plan', [$this, 'handleUpgradePlanRedirect'], 10, 1);

        add_action('fluent_cart/upgraded_order_created', [$this, 'handleUpgradedOrderCreated'], 10, 1);
        add_action('fluent_cart/upgrade_plan_completed', [$this, 'handleUpgradePlanCompleted'], 10, 1);

        add_filter('fluent_cart/checkout/validate_before_process', [$this, 'validateUpgradeCheckoutOwnership'], 10, 2);

        add_action('fluent_cart/cart/cart_data_items_updated', [$this, 'requoteUpgradeCredits'], 10, 1);
    }

    public function handleUpgradePlanRedirect($data = [])
    {
        if (!is_user_logged_in()) {
            wp_die( esc_html__( 'You are not logged in. Please log in to access this upgrade link.', 'fluent-cart-pro' ) );
        }

        $currentCustomer = CustomerResource::getCurrentCustomer();

        if (!$currentCustomer) {
            wp_die( esc_html__( 'You don\'t have permission to access this upgrade.', 'fluent-cart-pro' ) );
        }

        $fromOrderHash = sanitize_text_field(Arr::get($data, 'order_hash', ''));
        $parentOrder = Order::query()->where('uuid', $fromOrderHash)->first();

        if (!$parentOrder || !$fromOrderHash) {
            wp_die( esc_html__( 'Invalid Upgrade Link Provided!', 'fluent-cart-pro' ) );
        }

        if ($parentOrder->customer_id != $currentCustomer->id) {
            wp_die( esc_html__( 'You don\'t have permission to access this upgrade.', 'fluent-cart-pro' ) );
        }

        if (!in_array($parentOrder->payment_status, [Status::PAYMENT_PAID, Status::PAYMENT_PARTIALLY_PAID, Status::PAYMENT_PARTIALLY_REFUNDED])) {
            wp_die( esc_html__( 'You can only upgrade a paid order!', 'fluent-cart-pro' ) );
        }

        if ( $this->hasConsumedUpgradeCredit( $parentOrder ) ) {
            wp_die(
                esc_html__( 'This order has already been upgraded.', 'fluent-cart-pro' ),
                esc_html__( 'Upgrade not available', 'fluent-cart-pro' ),
                ['response' => 409, 'back_link' => true]
            );
        }

        // The order the credit (and its currency) comes from — core's rule,
        // so the checkout credits what the portal showed: the latest paid
        // or partially refunded renewal, never an unpaid one
        if (method_exists(PlanUpgradeService::class, 'upgradeSourceOrder')) {
            $latestOrder = PlanUpgradeService::upgradeSourceOrder($parentOrder);
        } else {
            $latestOrder = $parentOrder;
            if ($parentOrder->type === Status::ORDER_TYPE_SUBSCRIPTION) {
                $latestRenewal = Order::query()
                    ->where('parent_id', $parentOrder->id)
                    ->where('type', Status::ORDER_TYPE_RENEWAL)
                    ->orderBy('id', 'DESC')
                    ->first();

                if ($latestRenewal) {
                    $latestOrder = $latestRenewal;
                }
            }
        }

        $upgradePath = Meta::query()->where('meta_key', 'variant_upgrade_path')
            ->where('object_type', 'variant_upgrade')
            ->where('id', (int)Arr::get($data, 'path_id'))
            ->first();

        if (!$upgradePath) {
            wp_die( esc_html__( 'Invalid Upgrade Path Provided!', 'fluent-cart-pro' ) );
        }

        $targetVariantId = (int)Arr::get($data, 'target_id', 0);
        if (!in_array($targetVariantId, $upgradePath->meta_value['to_variants'])) {
            wp_die( esc_html__( 'Invalid Upgrade Path Provided!', 'fluent-cart-pro' ) );
        }

        $upgradeConfig = [
            'is_prorate'      => !!$upgradePath->meta_value['is_prorate'],
            'discount_amount' => Helper::toCent($upgradePath->meta_value['discount_amount']),
            'from_variant_id' => (int)$upgradePath->object_id,
            'to_variant_id'   => $targetVariantId,
        ];

        $originalItem = OrderItem::query()->where('order_id', $latestOrder->id)
            ->where('object_id', $upgradePath->object_id)
            ->first();

        if (!$originalItem) {
            wp_die( esc_html__( 'Invalid Upgrade Path Provided! Original item not found in the order.', 'fluent-cart-pro' ) );
        }


        if (Arr::get($originalItem->line_meta, 'parent_item_id')) {
            wp_die( esc_html__( 'Upgrade is not allowed for bundle items.', 'fluent-cart-pro' ) );
        }

        $upgradeToItem = ProductVariation::query()
            ->where('id', $targetVariantId)
            ->first();

        if (!$upgradeToItem) {
            wp_die( esc_html__( 'Invalid Upgrade Path Provided! Target variant not found.', 'fluent-cart-pro' ) );
        }

        $canPurchase = $upgradeToItem->canPurchase(1);
        if (is_wp_error($canPurchase)) {
            wp_die( esc_html( $canPurchase->get_error_message() ) );
        }

        $newItem = $upgradeToItem->toArray();

        $proRateCredit = 0;
        if ($upgradeConfig['is_prorate']) {
            $proRateCredit = PlanUpgradeService::calculateUpgradeToDiscount($latestOrder, $originalItem);
        }

        $discountAmount = Arr::get($upgradeConfig, 'discount_amount', 0);

        // Under core multi-currency an upgrade is a new order: priced in the
        // shopper's chosen currency (else the subscription's) at today's rate.
        // The prorate credit is what was paid, in the old order's currency —
        // converted through its frozen rate; the path discount is a base amount.
        $currencyQuote = null;
        $paidAt = null;
        $paidCredit = $proRateCredit;
        $baseDiscount = $discountAmount;
        if (class_exists(CartCurrency::class)) {
            $paidAt = CurrencySnapshot::fromOrder($latestOrder);

            // No rate for the order's currency (a legacy foreign order): core
            // lists the path as unavailable with no link, so a hand-built link
            // is refused too — before any cart, never priced in the base
            // currency and never converted 1:1
            $orderQuote = method_exists(PlanUpgradeService::class, 'orderCurrencyQuote')
                ? PlanUpgradeService::orderCurrencyQuote($latestOrder)
                : CartCurrency::quoteFor((string) $latestOrder->currency, $paidAt);
            if (!$orderQuote) {
                $this->refuseUnpricedUpgrade($latestOrder);
            }

            // A core that can convert the credit lets the shopper's chosen
            // currency price the upgrade; an older one keeps the order's
            $currencyQuote = $orderQuote;
            if (method_exists(CartCurrency::class, 'upgradeQuote') && method_exists(PriceConverter::class, 'between')) {
                $currencyQuote = CartCurrency::upgradeQuote($latestOrder);
                if (!$currencyQuote) {
                    $this->refuseUnpricedUpgrade($latestOrder);
                }

                if ($proRateCredit) {
                    $proRateCredit = PriceConverter::between($proRateCredit, $paidAt, $currencyQuote);
                    if ($proRateCredit === null) {
                        // The paid rate is not trusted: the credit cannot change currency
                        $this->refuseUnpricedUpgrade($latestOrder);
                    }
                }
            }

            $discountAmount = PriceConverter::toQuote($discountAmount, $currencyQuote);
        }

        $totalCredit = $proRateCredit + $discountAmount;

        Arr::set($newItem, 'post_title', $upgradeToItem->product->post_title);
        Arr::set($newItem, 'variation_type', $upgradeToItem->product_detail->variation_type);

        $estimatedPrice = Arr::get($newItem, 'item_price', 0)
            + (int) Arr::get($newItem, 'other_info.signup_fee', 0);
        if ($currencyQuote) {
            // The cart prices the plan with the currency's pricing rules
            $toPrice = method_exists(PriceConverter::class, 'toPrice') ? 'toPrice' : 'toQuote';
            $estimatedPrice = PriceConverter::$toPrice(Arr::get($newItem, 'item_price', 0), $currencyQuote)
                + PriceConverter::$toPrice((int) Arr::get($newItem, 'other_info.signup_fee', 0), $currencyQuote);
        }
        if ($totalCredit > $estimatedPrice) {
            // Cap combined credit at full first-payment (plan + signup fee); discount_amount takes priority
            $discountAmount = min($discountAmount, $estimatedPrice);
            $proRateCredit  = max(0, $estimatedPrice - $discountAmount);
        }

        // The admin-configured upgrade discount is a post-tax adjustment like the prorate
        // credit: tax is charged on the full plan price, then both are subtracted from the
        // payable total (checkout_data.upgrade_discount below). It is intentionally NOT set
        // as an item-level manual_discount, which would reduce the taxable base.

        // on upgrade, trial days is not applicable for now
        if (Arr::get($newItem, 'other_info.trial_days', 0) > 0) {
            $newItem['other_info']['trial_days'] = 0;
        }

        $instantCart = CartHelper::generateCartFromCustomVariation($newItem);
        $instantCart->cart_group = 'instant';
        $instantCart->first_name = $parentOrder->customer->first_name;
        $instantCart->last_name = $parentOrder->customer->last_name;
        $instantCart->email = $parentOrder->customer->email;
        $instantCart->customer_id = $parentOrder->customer->id;
        $instantCart->user_id = $parentOrder->customer->user_id;
        $instantCart->cart_hash = md5('upgrade_cart_' . wp_generate_uuid4() . time());
        $instantCart->checkout_data = [
            'is_locked'                       => 'no',
            'upgrade_data'                    => [
                'upgrade_from_order_id' => $parentOrder->id,
                'upgrade_path_id'       => $upgradePath->id,
                'from_variant_id'       => $upgradeConfig['from_variant_id'],
                'prorated_credit'       => $proRateCredit,
                'discount_amount'       => $discountAmount,
                'customer_id'           => $parentOrder->customer_id,
            ],
            '__on_success_actions__'          => [
                'fluent_cart/upgrade_plan_completed'
            ],
            '__after_draft_created_actions__' => [
                'fluent_cart/upgraded_order_created'
            ],
            '__cart_notices'                  => [
                [
                    'id'      => 'upgrade_notice',
                    'type'    => 'info',
                    'content' => sprintf(
                        /* translators: %1$s Item Title, %2$s Variation Title */
                        __('You are upgrading your plan from %1$s to %2$s.','fluent-cart-pro'),
                        $originalItem->title,
                        $upgradeToItem->variation_title
                    ),
                ]
            ],
            'upgrade_discount'                => [
                'amount' => $discountAmount,
                'title'  => __('Upgrade Discount', 'fluent-cart-pro')
            ],
            'prorate_credit'                  => [
                'amount' => $proRateCredit,
                'title'  => __('Prorate Credit', 'fluent-cart-pro')
            ]
        ];

        if ($currencyQuote) {
            // Kept so an expired rate lock can convert the credits again
            $checkoutData = $instantCart->checkout_data;
            $checkoutData['upgrade_data']['currency_source'] = [
                'prorated_credit' => $paidCredit,
                'paid_at'         => $paidAt,
                'discount_amount' => $baseDiscount,
                'item_price'      => (int) Arr::get($newItem, 'item_price', 0),
                'signup_fee'      => (int) Arr::get($newItem, 'other_info.signup_fee', 0),
            ];
            $instantCart->checkout_data = $checkoutData;

            // Hold the cart to the upgrade's currency — the credits above are
            // amounts in it; its items are converted from their base price on save
            $sameCurrency = strcasecmp((string) $currencyQuote['currency'], (string) $latestOrder->currency) === 0;
            CartCurrency::force($instantCart, (string) $currencyQuote['currency'], $sameCurrency ? $paidAt : null);
        }

        $instantCart->save();

        $cartHash = $instantCart->cart_hash;
        $checkoutUrl = add_query_arg(
            [
                'fct_cart_hash' => $cartHash,
            ],
            (new StoreSettings())->getCheckoutPage()
        );

        wp_redirect($checkoutUrl);
        exit();
    }

    /**
     * An expired rate lock re-prices the upgrade plan at today's rate. Convert
     * the credits again from what was paid, so the order doesn't mix two rates.
     */
    public function requoteUpgradeCredits($data)
    {
        if (Arr::get($data, 'scope') !== 'currency_repriced') {
            return;
        }

        $cart = Arr::get($data, 'cart');
        $quote = Arr::get($data, 'scope_data');
        if (!$cart || !is_array($quote)) {
            return;
        }

        $checkoutData = (array) $cart->checkout_data;
        $source = Arr::get($checkoutData, 'upgrade_data.currency_source');
        if (!is_array($source)) {
            return;
        }

        $proRateCredit = (int) Arr::get($source, 'prorated_credit', 0);
        if ($proRateCredit) {
            $proRateCredit = PriceConverter::between($proRateCredit, (array) Arr::get($source, 'paid_at', []), $quote);
            if ($proRateCredit === null) {
                return;
            }
        }

        $discountAmount = PriceConverter::toQuote((int) Arr::get($source, 'discount_amount', 0), $quote);

        $estimatedPrice = PriceConverter::toPrice((int) Arr::get($source, 'item_price', 0), $quote)
            + PriceConverter::toPrice((int) Arr::get($source, 'signup_fee', 0), $quote);
        if ($proRateCredit + $discountAmount > $estimatedPrice) {
            $discountAmount = min($discountAmount, $estimatedPrice);
            $proRateCredit = max(0, $estimatedPrice - $discountAmount);
        }

        Arr::set($checkoutData, 'upgrade_data.prorated_credit', $proRateCredit);
        Arr::set($checkoutData, 'upgrade_data.discount_amount', $discountAmount);
        Arr::set($checkoutData, 'prorate_credit.amount', $proRateCredit);
        Arr::set($checkoutData, 'upgrade_discount.amount', $discountAmount);
        $cart->checkout_data = $checkoutData;
        $cart->save();
    }

    public function handleUpgradePlanCompleted($data)
    {
        $cartModel = Arr::get($data, 'cart', null);
        $newOrder = Arr::get($data, 'order', null);

        $upgradeFromOrderId = Arr::get($cartModel->checkout_data, 'upgrade_data.upgrade_from_order_id', 0);

        $upgradeFromOrder = Order::query()->find($upgradeFromOrderId);

        if ($upgradeFromOrder) {
            $prevConfig = $upgradeFromOrder->config;
            $prevConfig['upgraded_to'] = $newOrder->id;
            $upgradeFromOrder->config = $prevConfig;
            $upgradeFromOrder->save();

            $oldSubscription = Subscription::query()->where('parent_order_id', $upgradeFromOrder->id)->first();
            $newSubscription = Subscription::query()->where('parent_order_id', $newOrder->id)->first();

            if ($oldSubscription) {
                $prevConfig = $oldSubscription->config;
                $prevConfig['upgraded_to_sub_id'] = $newSubscription ? $newSubscription->id : 0;
                $prevConfig['upgraded_to_order_id'] = $newOrder->id;
                $oldSubscription->config = $prevConfig;
                $oldSubscription->save();

                // Canceling old subscription due to upgrade
                $result = $oldSubscription->cancelRemoteSubscription([
                    'fire_hooks'     => false,
                    'reason'         => 'upgraded_to_new_plan',
                    'effective_from' => 'immediately',
                ]);

                if (is_wp_error($result)) {
                    fluent_cart_add_log(
                        'Remote subscription cancellation failed on upgrade',
                        'Subscription #' . $oldSubscription->id . ': ' . $result->get_error_message(),
                        'error',
                        [
                            'module_name' => 'subscription',
                            'module_id' => $oldSubscription->id
                        ]
                    );
                } else {
                    // Clear reminder state for the old subscription since fire_hooks is false
                    // and the SubscriptionCanceled event won't trigger the automatic cleanup
                    (new SubscriptionReminderService())->clearState($oldSubscription);
                }
            }

            if ($newSubscription) {
                $newConfig = $newSubscription->config;
                $newConfig['is_upgraded'] = 'yes';
                $newConfig['upgraded_from_sub_id'] = $oldSubscription ? $oldSubscription->id : 0;
                $newConfig['upgraded_from_order_id'] = $upgradeFromOrder ? $upgradeFromOrder->id : 0;
                $newSubscription->config = $newConfig;
                $newSubscription->save();
            }

            do_action('fluent_cart/order/upgraded', [
                'order'           => $newOrder,
                'from_order'      => $upgradeFromOrder,
                'cart'            => $cartModel,
                'from_variant_id' => Arr::get($cartModel->checkout_data, 'upgrade_data.from_variant_id', 0),
                'transaction'     => Arr::get($data, 'transaction', null)
            ]);

            $fromVariation = ProductVariation::query()->find(Arr::get($cartModel->checkout_data, 'upgrade_data.from_variant_id', 0));
            // Upgrade carts refuse bumps, so the first item is the target; signup-fee rows come after it.
            $newItem = OrderItem::query()->where('order_id', $newOrder->id)->orderBy('id', 'ASC')->first();
            $toVariation = $newItem ? ProductVariation::query()->find($newItem->object_id) : null;

            if ($fromVariation && $toVariation) {
                (new PlanChanged($newOrder, $toVariation, $fromVariation, [
                    'from_order_id'        => $upgradeFromOrder->id,
                    'from_subscription_id' => $oldSubscription ? $oldSubscription->id : 0,
                    'subscription_id'      => $newSubscription ? $newSubscription->id : 0,
                ]))->dispatch();
            }
        }

    }

    /**
     * An upgrade from an order whose currency cannot be priced (no rate
     * today, no trusted rate of its own) is refused with a 409 page before
     * any cart is built.
     *
     * @param Order $order
     */
    private function refuseUnpricedUpgrade($order)
    {
        wp_die(
            esc_html(sprintf(
                /* translators: %1$s: currency code, e.g. GBP */
                __('This upgrade is not available because no exchange rate is set for %1$s. Please contact the store.', 'fluent-cart-pro'),
                strtoupper((string) $order->currency)
            )),
            esc_html__('Upgrade not available', 'fluent-cart-pro'),
            ['response' => 409, 'back_link' => true]
        );
    }

    public function handleUpgradedOrderCreated($data)
    {
        $cartModel = Arr::get($data, 'cart', null);
        if (!$cartModel) {
            return;
        }

        $upgradeFromOrderId = Arr::get($cartModel->checkout_data, 'upgrade_data.upgrade_from_order_id', 0);
        if (!$upgradeFromOrderId) {
            return;
        }

        $createdOrder = $data['order'];
        $prevConfig = $createdOrder->config;
        $prevConfig['upgraded_from'] = $upgradeFromOrderId;
        if ($proratedCredit = Arr::get($cartModel->checkout_data, 'upgrade_data.prorated_credit', 0)) {
            $prevConfig['prorated_credit'] = $proratedCredit;
        }

        if ($discountAmount = Arr::get($cartModel->checkout_data, 'upgrade_data.discount_amount', 0)) {
            $prevConfig['discounted_amount'] = $discountAmount;
        }

        $createdOrder->config = $prevConfig;
        $createdOrder->save();
    }

    private function hasConsumedUpgradeCredit( Order $order ): bool
    {
        if ( Arr::get( $order->config, 'upgraded_to' ) ) {
            return true;
        }

        // Payment can finish before the completion hook marks the source order.
        return Order::query()
            ->where( 'customer_id', $order->customer_id )
            ->where( function ( $query ) use ( $order ) {
                $query->whereJsonContains( 'config', ['upgraded_from' => (int) $order->id] )
                    ->orWhereJsonContains( 'config', ['upgraded_from' => (string) $order->id] );
            } )
            ->whereIn( 'payment_status', [
                Status::PAYMENT_PAID,
                Status::PAYMENT_PARTIALLY_PAID,
                Status::PAYMENT_PARTIALLY_REFUNDED,
                Status::PAYMENT_REFUNDED,
            ] )
            ->exists();
    }

    public function validateUpgradeCheckoutOwnership($validation, $data)
    {
        $cart = \FluentCart\App\Helpers\CartHelper::getCart();

        if (!$cart) {
            return $validation;
        }

        $upgradeData = Arr::get($cart->checkout_data, 'upgrade_data');
        if (empty($upgradeData)) {
            return $validation;
        }

        $cartCustomerId = Arr::get($upgradeData, 'customer_id');
        if (!$cartCustomerId) {
            return $validation;
        }

        if (!is_user_logged_in()) {
            return new \WP_Error(
                'upgrade_auth_required',
                __('You must be logged in to complete this upgrade.', 'fluent-cart-pro')
            );
        }

        $currentCustomer = CustomerResource::getCurrentCustomer();

        if (!$currentCustomer) {
            return new \WP_Error(
                'upgrade_auth_failed',
                __('Cannot process this upgrade.', 'fluent-cart-pro')
            );
        }

        if ($cartCustomerId != $currentCustomer->id) {
            return new \WP_Error(
                'upgrade_unauthorized',
                __('Cannot process this upgrade.', 'fluent-cart-pro')
            );
        }

        $sourceOrder = Order::query()->find( (int) Arr::get( $upgradeData, 'upgrade_from_order_id', 0 ) );
        if ( !$sourceOrder || $sourceOrder->customer_id != $currentCustomer->id ) {
            return new \WP_Error(
                'upgrade_unauthorized',
                __( 'Cannot process this upgrade.', 'fluent-cart-pro' )
            );
        }

        if ( $this->hasConsumedUpgradeCredit( $sourceOrder ) ) {
            return new \WP_Error(
                'upgrade_already_completed',
                __( 'This order has already been upgraded.', 'fluent-cart-pro' )
            );
        }

        return $validation;
    }
}
