<?php

// Don't redefine the functions if included multiple times.

if ( ! defined( 'ABSPATH' ) ) { exit; }
if (!function_exists('NxProGA\GuzzleHttp\Psr7\str')) {
    require __DIR__ . '/functions.php';
}
