<?php
/**
 * BuddyBoss Pro Blog Functions.
 *
 * @package BuddyBossPro
 *
 * @since 3.1.0
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

/**
 * Build a URL relative to the blog module directory.
 *
 * @since 3.1.0
 *
 * @param string $path Optional. Relative path to append.
 *
 * @return string
 */
function bb_blog_pro_url( $path = '' ) {
	return trailingslashit( bb_platform_pro()->blog_url ) . ltrim( $path, '/' );
}

/**
 * Build a filesystem path relative to the blog module directory.
 *
 * @since 3.1.0
 *
 * @param string $path Optional. Relative path to append.
 *
 * @return string
 */
function bb_blog_pro_path( $path = '' ) {
	return trailingslashit( bb_platform_pro()->blog_dir ) . ltrim( $path, '/' );
}

/**
 * Check whether the Pro license currently unlocks gated features.
 *
 * @since 3.1.0
 *
 * @return bool
 */
function bb_blog_pro_is_license_unlocked() {
	if ( function_exists( 'bb_pro_should_lock_features' ) ) {
		return ! bb_pro_should_lock_features();
	}

	return function_exists( 'bbp_pro_is_license_valid' ) && bbp_pro_is_license_valid();
}

/**
 * Whether the Blogs "Bookmarking" pro upgrade is enabled.
 *
 * Gated on: the `bb_blog_enable_bookmarking` option, the Platform `blogging`
 * feature being active, and a valid/unlocked Pro license.
 *
 * @since 3.1.0
 *
 * @return bool
 */
function bb_blog_pro_is_bookmarking_enabled() {
	$enabled = (bool) bp_get_option( 'bb_blog_enable_bookmarking', 0 );

	if ( $enabled && function_exists( 'bb_feature_registry' ) ) {
		$enabled = bb_feature_registry()->bb_is_feature_active( 'blogging' );
	}

	if ( $enabled ) {
		$enabled = bb_blog_pro_is_license_unlocked();
	}

	/**
	 * Filters whether blog post bookmarking is enabled.
	 *
	 * @since 3.1.0
	 *
	 * @param bool $enabled Whether bookmarking is enabled.
	 */
	return (bool) apply_filters( 'bb_blog_pro_is_bookmarking_enabled', $enabled );
}

/**
 * Whether the Blogs "Subscriptions" pro upgrade is enabled.
 *
 * Gated on: the `bb_blog_enable_subscriptions` option, the Platform `blogging`
 * feature being active, and a valid/unlocked Pro license.
 *
 * @since 3.1.0
 *
 * @return bool
 */
function bb_blog_pro_is_subscriptions_enabled() {
	$enabled = (bool) bp_get_option( 'bb_blog_enable_subscriptions', 0 );

	if ( $enabled && function_exists( 'bb_feature_registry' ) ) {
		$enabled = bb_feature_registry()->bb_is_feature_active( 'blogging' );
	}

	if ( $enabled ) {
		$enabled = bb_blog_pro_is_license_unlocked();
	}

	/**
	 * Filters whether blog category subscriptions are enabled.
	 *
	 * @since 3.1.0
	 *
	 * @param bool $enabled Whether subscriptions are enabled.
	 */
	return (bool) apply_filters( 'bb_blog_pro_is_subscriptions_enabled', $enabled );
}

/**
 * The bookmark type slug used for blog posts.
 *
 * Identical to the BuddyBoss App plugin's own type, so rows mirror 1:1.
 *
 * @since 3.1.0
 */
if ( ! defined( 'BB_BLOG_PRO_BOOKMARK_TYPE' ) ) {
	define( 'BB_BLOG_PRO_BOOKMARK_TYPE', 'post' );
}

/**
 * Whether Platform's bookmark engine is available.
 *
 * Pro may be running against a Platform build that predates it.
 *
 * @since 3.1.0
 *
 * @return bool
 */
function bb_blog_pro_has_bookmark_engine() {
	return function_exists( 'bb_bookmark_toggle' ) && class_exists( 'BB_Bookmarks' );
}

/**
 * Get the post IDs a user has bookmarked.
 *
 * Kept as a flat array of IDs for backward compatibility — the theme and
 * Platform's blogging component both consume this shape directly.
 *
 * @since 3.1.0
 *
 * @param int $user_id Optional. Defaults to the current user.
 *
 * @return int[] Bookmarked post IDs, most recently bookmarked first.
 */
function bb_blog_pro_get_user_bookmarks( $user_id = 0 ) {
	if ( ! bb_blog_pro_has_bookmark_engine() ) {
		return array();
	}

	$user_id = ! empty( $user_id ) ? absint( $user_id ) : get_current_user_id();

	if ( empty( $user_id ) ) {
		return array();
	}

	$result = bb_bookmark_get_user_items(
		array(
			'type'     => BB_BLOG_PRO_BOOKMARK_TYPE,
			'user_id'  => $user_id,
			'status'   => 1,
			'fields'   => 'item_id',
			'order_by' => 'date_recorded',
			'order'    => 'DESC',
			'count'    => false,
		)
	);

	$post_ids = ! empty( $result['bookmarks'] ) ? $result['bookmarks'] : array();

	return array_values( array_unique( array_map( 'absint', (array) $post_ids ) ) );
}

/**
 * How many posts a user has bookmarked.
 *
 * Prefer this over `count( bb_blog_pro_get_user_bookmarks() )` — it is a single
 * COUNT(*) rather than loading every row.
 *
 * @since 3.1.0
 *
 * @param int $user_id Optional. Defaults to the current user.
 *
 * @return int
 */
function bb_blog_pro_get_user_bookmark_count( $user_id = 0 ) {
	if ( ! bb_blog_pro_has_bookmark_engine() ) {
		return 0;
	}

	$user_id = ! empty( $user_id ) ? absint( $user_id ) : get_current_user_id();

	if ( empty( $user_id ) ) {
		return 0;
	}

	$result = bb_bookmark_get_user_items(
		array(
			'type'       => BB_BLOG_PRO_BOOKMARK_TYPE,
			'user_id'    => $user_id,
			'status'     => 1,
			'count_only' => true,
		)
	);

	return ! empty( $result['total'] ) ? (int) $result['total'] : 0;
}

/**
 * Whether a user has bookmarked a post.
 *
 * @since 3.1.0
 *
 * @param int $post_id Post ID.
 * @param int $user_id Optional. Defaults to the current user.
 *
 * @return bool
 */
function bb_blog_pro_is_bookmarked( $post_id, $user_id = 0 ) {
	if ( ! bb_blog_pro_has_bookmark_engine() ) {
		return false;
	}

	$user_id = ! empty( $user_id ) ? absint( $user_id ) : get_current_user_id();

	return bb_bookmark_is_bookmarked( BB_BLOG_PRO_BOOKMARK_TYPE, absint( $post_id ), $user_id );
}

/**
 * How many users have bookmarked a post.
 *
 * @since 3.1.0
 *
 * @param int $post_id Post ID.
 *
 * @return int
 */
function bb_blog_pro_get_bookmark_count( $post_id ) {
	if ( ! bb_blog_pro_has_bookmark_engine() ) {
		return 0;
	}

	return bb_bookmark_get_count( BB_BLOG_PRO_BOOKMARK_TYPE, absint( $post_id ) );
}

/**
 * Toggle the current user's bookmark on a post.
 *
 * Returns the store's real result, never a hardcoded success.
 *
 * @since 3.1.0
 *
 * @param int $post_id Post ID.
 * @param int $user_id Optional. Defaults to the current user.
 *
 * @return bool|WP_Error True when now bookmarked, false when removed, WP_Error on failure.
 */
function bb_blog_pro_toggle_bookmark( $post_id, $user_id = 0 ) {
	if ( ! bb_blog_pro_has_bookmark_engine() ) {
		return new WP_Error( 'bb_blog_pro_no_engine', __( 'Bookmarking is unavailable.', 'buddyboss-pro' ) );
	}

	if ( ! bb_blog_pro_is_bookmarking_enabled() ) {
		return new WP_Error( 'bb_blog_pro_bookmark_disabled', __( 'Blog bookmarking is not enabled.', 'buddyboss-pro' ) );
	}

	$post_id = absint( $post_id );
	$user_id = ! empty( $user_id ) ? absint( $user_id ) : get_current_user_id();

	// Adding requires a real, published post the user is actually allowed to
	// read. Removing does NOT — see bb_bookmark_toggle(); a user must always be
	// able to un-bookmark. Platform's bookmark engine is type-agnostic and does
	// no per-item read check (by design), so the blog layer enforces it here:
	// without this, any logged-in user could POST an arbitrary post_id and
	// bookmark a password-protected post, or one hidden by a third-party access
	// control integration that leaves post_status as 'publish' — leaking its
	// title/permalink onto their Bookmarked profile tab. `user_can()` matches
	// the acting bookmarker (not just the current session), and
	// `post_password_required()` blocks an unlocked password-protected post.
	if ( ! bb_blog_pro_is_bookmarked( $post_id, $user_id ) ) {
		$post = get_post( $post_id );

		if (
			empty( $post )
			|| 'post' !== $post->post_type
			|| 'publish' !== $post->post_status
			|| ! user_can( $user_id, 'read_post', $post_id )
			|| post_password_required( $post )
		) {
			return new WP_Error( 'bb_blog_pro_bookmark_invalid_post', __( 'This item cannot be bookmarked.', 'buddyboss-pro' ) );
		}
	}

	return bb_bookmark_toggle( BB_BLOG_PRO_BOOKMARK_TYPE, $post_id, $user_id );
}

/**
 * Whether a theme other than the BuddyBoss Theme is rendering, with ReadyLaunch off.
 *
 * Deliberately self-contained rather than calling Platform's equivalent: the blog
 * bookmark and subscribe controls are Pro features, so Pro must not need a specific
 * Platform version to decide which icon set and render hook to use. It relies only on
 * long-standing APIs — the theme's own `buddyboss_theme_get_option()` and Platform's
 * `bb_is_readylaunch_enabled()`.
 *
 * @since 3.1.1
 *
 * @return bool True when neither the BuddyBoss Theme nor ReadyLaunch is rendering.
 */
function bb_blog_pro_is_third_party_theme() {
	$readylaunch = function_exists( 'bb_is_readylaunch_enabled' ) && bb_is_readylaunch_enabled();

	$is_third_party = ! function_exists( 'buddyboss_theme_get_option' ) && ! $readylaunch;

	/**
	 * Filter whether a third-party theme is rendering the blog controls.
	 *
	 * @since 3.1.1
	 *
	 * @param bool $is_third_party Whether neither the BuddyBoss Theme nor ReadyLaunch is rendering.
	 */
	return (bool) apply_filters( 'bb_blog_pro_is_third_party_theme', $is_third_party );
}

/**
 * Resolve the icon class to use for a blog control in the current theme context.
 *
 * ReadyLaunch and the BuddyBoss Theme load the ReadyLaunch icon font, so controls
 * rendered there use `bb-icons-rl-*` glyphs. Other themes never load that font —
 * but Platform enqueues its legacy BuddyBoss icon font (`bb-icon-*`) site-wide, so
 * the classic glyph is used instead of pulling a second icon font onto the page for
 * two buttons.
 *
 * @since 3.1.1
 *
 * @param string $rl_class     Glyph class for ReadyLaunch / BuddyBoss Theme.
 * @param string $legacy_class Glyph class for every other theme.
 *
 * @return string Icon class to render.
 */
function bb_blog_pro_icon_class( $rl_class, $legacy_class ) {
	$is_third_party = bb_blog_pro_is_third_party_theme();
	$icon_class     = $is_third_party ? $legacy_class : $rl_class;

	/**
	 * Filter the icon class used for a blog control.
	 *
	 * @since 3.1.1
	 *
	 * @param string $icon_class     Resolved icon class.
	 * @param string $rl_class       ReadyLaunch glyph class.
	 * @param string $legacy_class   Legacy BuddyBoss glyph class.
	 * @param bool   $is_third_party Whether a third-party theme is rendering.
	 */
	$icon_class = (string) apply_filters( 'bb_blog_pro_icon_class', $icon_class, $rl_class, $legacy_class, $is_third_party );

	/*
	 * These classes are interpolated into markup by the subscribe modal script as
	 * well as echoed here, and the value above is filterable. Constrain it to real
	 * CSS class tokens so a careless filter cannot inject markup.
	 */
	return implode( ' ', array_filter( array_map( 'sanitize_html_class', explode( ' ', $icon_class ) ) ) );
}

/**
 * Icon classes for the blog controls, resolved for the current theme context.
 *
 * Passed to the subscribe scripts so client-rendered markup (modal rows, button
 * states) uses the same icon font as the server-rendered controls. Keys are stable;
 * only the values change between ReadyLaunch and other themes.
 *
 * @since 3.1.1
 *
 * @return array Map of icon key => class.
 */
function bb_blog_pro_icon_classes() {
	return array(
		'close'       => bb_blog_pro_icon_class( 'bb-icons-rl-x', 'bb-icon-l bb-icon-times' ),
		'pin'         => bb_blog_pro_icon_class( 'bb-icons-rl-push-pin', 'bb-icon-l bb-icon-thumbtack' ),
		'plus'        => bb_blog_pro_icon_class( 'bb-icons-rl-plus', 'bb-icon-l bb-icon-plus' ),
		'minus'       => bb_blog_pro_icon_class( 'bb-icons-rl-minus', 'bb-icon-l bb-icon-minus' ),
		'bell'        => bb_blog_pro_icon_class( 'bb-icons-rl-bell', 'bb-icon-l bb-icon-bell-plus' ),
		'bellRinging' => bb_blog_pro_icon_class( 'bb-icons-rl-bell-ringing', 'bb-icon-l bb-icon-bell-plus' ),
		'bellSlash'   => bb_blog_pro_icon_class( 'bb-icons-rl-bell-slash', 'bb-icon-l bb-icon-bell-slash' ),
	);
}

/**
 * Append the blog actions row to single posts on third-party themes.
 *
 * The BuddyBoss Theme and ReadyLaunch render these controls from their own
 * single-post meta-actions hooks. Other themes have no such hook, so Pro appends its
 * own row here rather than relying on a seam in Platform — the blog bookmark and
 * subscribe features are Pro's, and updating Pro alone has to be enough to get them
 * working. For the same reason the wrapper carries a Pro-owned class with its own
 * layout, instead of `.bb-blog-share`, whose flex rules live in Platform's
 * ReadyLaunch stylesheet and are not loaded on other themes.
 *
 * @since 3.1.1
 *
 * @param string $content Post content.
 *
 * @return string Content, with the actions row appended when applicable.
 */
function bb_blog_pro_append_blog_actions( $content ) {
	static $rendered = array();

	if ( ! bb_blog_pro_is_third_party_theme() ) {
		return $content;
	}

	if ( ! is_singular( 'post' ) || ! in_the_loop() || ! is_main_query() ) {
		return $content;
	}

	$post_id = (int) get_the_ID();

	if ( empty( $post_id ) || isset( $rendered[ $post_id ] ) ) {
		return $content;
	}

	/*
	 * These renderers live in bb-blog-bookmarks-frontend.php and
	 * bb-blog-subscriptions-frontend.php, which class-bb-blog.php only requires when
	 * the matching option is on -- and both default to off. This file is always
	 * loaded, so the functions have to be checked rather than assumed, or a default
	 * install fatals on every single post.
	 */
	$render_bookmark  = function_exists( 'bb_blog_pro_render_bookmark_button' );
	$render_subscribe = function_exists( 'bb_blog_pro_render_single_subscribe_bell' );

	if ( ! $render_bookmark && ! $render_subscribe ) {
		return $content;
	}

	$rendered[ $post_id ] = true;

	ob_start();

	if ( $render_bookmark ) {
		bb_blog_pro_render_bookmark_button( $post_id );
	}

	if ( $render_subscribe ) {
		bb_blog_pro_render_single_subscribe_bell( $post_id );
	}

	$actions = trim( (string) ob_get_clean() );

	// A loaded renderer still bails for logged-out visitors, and when the feature is
	// licence-locked, so only emit the wrapper once something actually rendered.
	if ( '' === $actions ) {
		return $content;
	}

	return $content . '<div class="bb-blog-pro-actions">' . $actions . '</div>';
}
add_filter( 'the_content', 'bb_blog_pro_append_blog_actions', 99 );

