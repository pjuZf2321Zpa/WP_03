<?php

namespace WPAICG\Lib\Chat;

use WP_Error;
use WPAICG\Chat\Storage\LogStorage;
use WPAICG\Chat\Core\AIPKit_Chat_File_Upload_Provider_Resolver;
use WPAICG\Core\Stream\Contexts\Chat\Process;
use WPAICG\Lib\Chat\Triggers\AIPKit_Trigger_Storage;
use WPAICG\Lib\Chat\Triggers\AIPKit_Trigger_Manager;

if (!defined('ABSPATH')) {
    exit;
}

/** Paid trigger, required-form and document preparation for chatbot streams. */
final class Stream
{
    /**
     * Handles the 'session_started' trigger event processing.
     *
     * @param array $context An associative array containing all necessary parameters:
     *    'user_id', 'session_id', 'bot_id', 'bot_settings', 'client_ip', 'post_id',
     *    'user_message_text' (first user message), 'system_instruction_for_ai' (current system instruction),
     *    'user_wp_role', 'current_provider', 'current_model_id', 'base_log_data', 'log_storage'.
     * @return array|WP_Error The result of trigger processing, which could be a WP_Error
     *                        if the trigger blocks or sends a direct reply, or an array
     *                        with potentially modified context data.
     *                        Structure of array: ['status', 'message_to_user', 'message_id', 'modified_context_data', 'stop_ai_processing', 'display_form_event_data']
     */
    public static function process_session_start_trigger_logic(array $context)
    {
        $trigger_storage_class = '\WPAICG\Lib\Chat\Triggers\AIPKit_Trigger_Storage';
        $trigger_manager_class = '\WPAICG\Lib\Chat\Triggers\AIPKit_Trigger_Manager';
        $trigger_function_name = '\WPAICG\Lib\Chat\Triggers\process_chat_triggers';
        $triggers_enabled = false;

        if (class_exists('\WPAICG\aipkit_dashboard')) {
            $triggers_enabled = \WPAICG\aipkit_dashboard::is_pro_plan();
        }

        $neutral_result = Process\neutral_trigger_result_logic($context, []);

        if (!$triggers_enabled || !class_exists($trigger_storage_class) || !class_exists($trigger_manager_class) || !function_exists($trigger_function_name)) {
            return $neutral_result; // No triggers to run or components missing
        }

        $session_trigger_context_data = [
            'event_type'        => 'session_started',
            'is_new_session'    => true,
            'user_id'           => $context['user_id'],
            'session_id'        => $context['session_id'],
            'bot_id'            => $context['bot_id'],
            'bot_settings'      => $context['bot_settings'],
            'client_ip'         => $context['client_ip'],
            'post_id'           => $context['post_id'],
            'user_message_text' => $context['user_message_text'], // First user message
            'current_history'   => [], // History is empty for session_started event itself
            'message_count'     => 0,
            'system_instruction' => $context['system_instruction_for_ai'],
            'user_roles'        => $context['user_wp_role'] ? array_map('trim', explode(',', $context['user_wp_role'])) : ['guest'],
            'current_provider'  => $context['current_provider'],
            'current_model_id'  => $context['current_model_id'],
            'base_log_data'     => $context['base_log_data'],
            'log_storage'       => $context['log_storage']
        ];

        // Call the global trigger processing function
        $session_trigger_result = $trigger_function_name($session_trigger_context_data);

        $trigger_error = self::trigger_response_error($session_trigger_result, true);
        if ($trigger_error !== null) {
            return $trigger_error;
        }

        // Return the full result from trigger processing, including modified context
        return $session_trigger_result;
    }

    /**
     * Processes 'user_message_received' triggers.
     *
     * @param array $context Context data including bot_id, bot_settings, user_id, session_id, etc.
     *                       Also includes `user_message_text`, `final_history_for_ai`,
     *                       and `system_instruction_for_ai` which may have been modified
     *                       by `session_started` triggers.
     * @return array|WP_Error Result of trigger processing or WP_Error if blocked/direct reply.
     */
    public static function process_user_message_trigger_logic(array $context)
    {
        $trigger_storage_class = '\WPAICG\Lib\Chat\Triggers\AIPKit_Trigger_Storage';
        $trigger_manager_class = '\WPAICG\Lib\Chat\Triggers\AIPKit_Trigger_Manager';
        $trigger_function_name = '\WPAICG\Lib\Chat\Triggers\process_chat_triggers';
        $triggers_enabled = false;

        if (class_exists('\WPAICG\aipkit_dashboard')) {
            $triggers_enabled = \WPAICG\aipkit_dashboard::is_pro_plan();
        }

        // Prepare a neutral result that reflects the input context if no triggers modify it.
        $neutral_result = Process\neutral_trigger_result_logic($context, $context['final_history_for_ai']);

        if (!$triggers_enabled || !class_exists($trigger_storage_class) || !class_exists($trigger_manager_class) || !function_exists($trigger_function_name)) {
            return $neutral_result; // No triggers to run or components missing
        }

        // Data to pass to the global trigger processor `process_chat_triggers`
        // This uses specific keys that `process_chat_triggers` expects for 'user_message_received'
        $message_count_for_trigger = isset($context['user_message_count'])
            ? absint($context['user_message_count'])
            : count(array_filter($context['final_history_for_ai'], static function ($message): bool {
                return is_array($message) && sanitize_key((string) ($message['role'] ?? '')) === 'user';
            })) + 1;
        $user_message_trigger_context_data = [
            'event_type'        => 'user_message_received',
            'user_id'           => $context['user_id'],
            'session_id'        => $context['session_id'],
            'bot_id'            => $context['bot_id'],
            'conversation_uuid' => $context['conversation_uuid'] ?? ($context['base_log_data']['conversation_uuid'] ?? ''),
            'module'            => 'chat',
            'bot_settings'      => $context['bot_settings'],
            'user_message_text' => $context['user_message_text'],
            'current_history'   => $context['final_history_for_ai'], // Use final_history_for_ai
            'client_ip'         => $context['client_ip'],
            'post_id'           => $context['post_id'],
            'message_count'     => $message_count_for_trigger, // Calculated count
            'system_instruction'=> $context['system_instruction_for_ai'],
            'user_roles'        => $context['user_wp_role'] ? array_map('trim', explode(',', $context['user_wp_role'])) : ['guest'],
            'current_provider'  => $context['current_provider'],
            'current_model_id'  => $context['current_model_id'],
            'base_log_data'     => $context['base_log_data'],
            'log_storage'       => $context['log_storage']
        ];

        // $trigger_function_name is \WPAICG\Lib\Chat\Triggers\process_chat_triggers
        $user_message_trigger_result = $trigger_function_name($user_message_trigger_context_data);

        $trigger_error = self::trigger_response_error($user_message_trigger_result, false);
        if ($trigger_error !== null) {
            return $trigger_error;
        }

        // If not blocked or direct replied, update the neutral_result with the outcome
        $neutral_result['status'] = $user_message_trigger_result['status']; // Should still be 'processed'
        $neutral_result['message_to_user'] = $user_message_trigger_result['message_to_user'] ?? $neutral_result['message_to_user'];
        $neutral_result['message_id'] = $user_message_trigger_result['message_id'] ?? $neutral_result['message_id'];
        $neutral_result['stop_ai_processing'] = $user_message_trigger_result['stop_ai_processing'] ?? $neutral_result['stop_ai_processing'];
        $neutral_result['display_form_event_data'] = $user_message_trigger_result['display_form_event_data'] ?? $neutral_result['display_form_event_data'];

        // Apply modifications from triggers to the context that will be passed to the AI
        // The keys in $user_message_trigger_result['modified_context_data'] are 'system_instruction', 'user_message_text', 'current_history'
        $neutral_result['modified_context_data']['system_instruction'] = $user_message_trigger_result['modified_context_data']['system_instruction'] ?? $context['system_instruction_for_ai'];
        $neutral_result['modified_context_data']['user_message_text']  = $user_message_trigger_result['modified_context_data']['user_message_text'] ?? $context['user_message_text'];
        $neutral_result['modified_context_data']['current_history']    = $user_message_trigger_result['modified_context_data']['current_history'] ?? $context['final_history_for_ai'];

        return $neutral_result;
    }

    /** Convert trigger interruptions while retaining session and message defaults. */
    private static function trigger_response_error(array $result, bool $session_start): ?WP_Error
    {
        if ($result['status'] === 'blocked') {
            $message_id = $result['message_id'] ?? (($session_start ? 'trigger-session-block-' : 'trigger-block-') . uniqid());
            $message = $result['message_to_user'] ?? ($session_start
                ? __('Session blocked by system.', 'gpt3-ai-content-generator')
                : __('Message blocked.', 'gpt3-ai-content-generator'));
            return new WP_Error('trigger_blocked', $message, ['status' => 400, 'is_trigger_response' => true, 'message_id' => $message_id]);
        }
        if (isset($result['display_form_event_data']) && is_array($result['display_form_event_data'])) {
            return new WP_Error('trigger_display_form', __('Form display requested by trigger.', 'gpt3-ai-content-generator'), ['status' => 200, 'display_form_event_data' => $result['display_form_event_data']]);
        }
        if (isset($result['message_to_user']) && ($result['stop_ai_processing'] ?? false)) {
            $message_id = $result['message_id'] ?? (($session_start ? 'trigger-session-reply-' : 'trigger-reply-') . uniqid());
            return new WP_Error('trigger_direct_reply', $result['message_to_user'], ['status' => 200, 'is_trigger_response' => true, 'message_id' => $message_id]);
        }
        return null;
    }

    /** Dispatches a paid validation event while preserving the original validation failure. */
    public static function validation_error(WP_Error $error, ?LogStorage $log_storage, int $bot_id, ?int $user_id, ?string $session_id, string $module, string $operation, int $default_status): void
    {
        $enabled = class_exists('\\WPAICG\\aipkit_dashboard') && \WPAICG\aipkit_dashboard::is_pro_plan();
        if (!$enabled || !class_exists(AIPKit_Trigger_Manager::class) || !class_exists(AIPKit_Trigger_Storage::class) || !$log_storage) {
            return;
        }
        $error_data = $error->get_error_data() ?: [];
        $context = [
            'error_code' => $error->get_error_code(),
            'error_message' => $error->get_error_message(),
            'bot_id' => $bot_id,
            'user_id' => $user_id ?: null,
            'session_id' => $session_id,
            'module' => $module,
            'operation' => $operation,
            'status_code' => is_array($error_data) && isset($error_data['status']) ? (int) $error_data['status'] : $default_status,
        ];
        try {
            $storage = new AIPKit_Trigger_Storage();
            $manager = new AIPKit_Trigger_Manager($storage, $log_storage);
            $manager->process_event($bot_id, 'system_error_occurred', $context);
        } catch (\Exception $e) {
            // Keep the validation error if a trigger fails.
        }
    }

    /** Resolve file identifiers exclusively from the signed context for this conversation. */
    public static function apply_uploaded_file_context(array &$params, array &$settings)
    {
        $keys = ['active_openai_vs_id', 'active_pinecone_index_name', 'active_pinecone_namespace', 'active_qdrant_collection_name', 'active_qdrant_file_upload_context_id', 'active_chroma_collection_name', 'active_chroma_file_upload_context_id', 'active_claude_file_id'];
        $has_unsigned_context = false;
        foreach ($keys as $key) { $has_unsigned_context = $has_unsigned_context || !empty($params[$key]); $params[$key] = null; }
        $token = (string) ($params['active_file_context_token'] ?? '');
        if ($token === '' && !$has_unsigned_context) { return true; }
        $context = \WPAICG\Utils\AIPKit_Identifier_Utils::verify_upload_token($token, $params, 'file');
        if (is_wp_error($context)) { return $context; }
        $routes = ['OpenAI' => 'openai', 'Pinecone' => 'pinecone', 'Qdrant' => 'qdrant', 'Chroma' => 'chroma', 'Local' => 'local', 'Claude' => 'claude_files'];
        $provider = (string) ($context['provider'] ?? '');
        if (!\WPAICG\aipkit_dashboard::is_pro_plan() || ($settings['enable_file_upload'] ?? '0') !== '1'
            || !isset($routes[$provider]) || AIPKit_Chat_File_Upload_Provider_Resolver::resolve($settings) !== $routes[$provider]) {
            return new WP_Error('chat_upload_mode_changed', __('File upload settings changed. Please upload the file again.', 'gpt3-ai-content-generator'), ['status' => 403]);
        }
        $map = [
            'OpenAI' => ['active_openai_vs_id' => 'vector_store_id'],
            'Pinecone' => ['active_pinecone_index_name' => 'index_name', 'active_pinecone_namespace' => 'namespace'],
            'Qdrant' => ['active_qdrant_collection_name' => 'collection_name', 'active_qdrant_file_upload_context_id' => 'file_upload_context_id'],
            'Chroma' => ['active_chroma_collection_name' => 'collection_name', 'active_chroma_file_upload_context_id' => 'file_upload_context_id'],
            'Claude' => ['active_claude_file_id' => 'file_id'],
        ];
        if ($provider === 'Local') {
            $settings['active_local_file_upload_context_id'] = (string) ($context['file_upload_context_id'] ?? '');
            $settings['active_local_store_id'] = (string) ($context['collection_name'] ?? '');
        } else {
            foreach ($map[$provider] as $key => $field) { $params[$key] = (string) ($context[$field] ?? ''); }
        }
        return true;
    }

    /** Verifies a signed temporary Google document against the current chat scope. */
    public static function google_document(array $params, array $bot_settings)
    {
        if (
            !class_exists(AIPKit_Chat_File_Upload_Provider_Resolver::class)
            || AIPKit_Chat_File_Upload_Provider_Resolver::resolve($bot_settings) !== 'google'
            || ($bot_settings['enable_file_upload'] ?? '0') !== '1'
        ) {
            return new WP_Error(
                'google_chat_file_mode_mismatch',
                __('This chatbot is no longer configured for Google document upload.', 'gpt3-ai-content-generator'),
                ['status' => 400]
            );
        }
        if (!class_exists('\WPAICG\Core\Providers\Google\Files\GoogleFilesContextToken')) {
            return new WP_Error(
                'google_chat_file_context_missing',
                __('Google file context validation is unavailable.', 'gpt3-ai-content-generator'),
                ['status' => 500]
            );
        }
        $verified_google_file = \WPAICG\Core\Providers\Google\Files\GoogleFilesContextToken::verify(
            (string) $params['active_google_file_context_token'],
            [
                'user_id' => $params['user_id'],
                'session_id' => $params['session_id'],
                'bot_id' => $params['bot_id'],
                'conversation_uuid' => $params['conversation_uuid'],
            ]
        );
        if (is_wp_error($verified_google_file)) {
            return $verified_google_file;
        }
        return \WPAICG\Core\Providers\Google\Files\GoogleFilesContextToken::document_input($verified_google_file);
    }

    /** Restores the submitted form and original user message before quota and moderation. */
    public static function prepare_form_resume(array &$params, LogStorage $log_storage)
    {
        $form_resume_user_message_id = null;
        $resume_token_result = self::validate_form_submission_resume_token_logic($params);
        if (is_wp_error($resume_token_result)) {
            return $resume_token_result;
        }
        $form_resume_state = is_array($resume_token_result) ? $resume_token_result : [];

        $existing_history = $log_storage->get_conversation_thread_history(
            $params['user_id'] ? (int) $params['user_id'] : null,
            $params['user_id'] ? null : (string) $params['session_id'],
            (int) $params['bot_id'],
            (string) $params['conversation_uuid']
        );
        $params['user_message_text'] = '';
        if (is_array($existing_history)) {
            for ($index = count($existing_history) - 1; $index >= 0; $index--) {
                $history_item = $existing_history[$index] ?? [];
                if (!is_array($history_item) || sanitize_key((string) ($history_item['role'] ?? '')) !== 'user') {
                    continue;
                }
                $logged_user_message = isset($history_item['content']) ? trim((string) $history_item['content']) : '';
                if ($logged_user_message === '') {
                    continue;
                }
                $params['user_message_text'] = $logged_user_message;
                $form_resume_user_message_id = sanitize_key((string) ($history_item['message_id'] ?? ''));
                break;
            }
        }
        if ($params['user_message_text'] === '') {
            return new WP_Error('missing_form_resume_user_message', __('No captured user message was found for this form resume.', 'gpt3-ai-content-generator'), ['status' => 403]);
        }

        if (isset($form_resume_state['form_submission_context']) && is_array($form_resume_state['form_submission_context'])) {
            $params['form_submission_context'] = $form_resume_state['form_submission_context'];
        }
        return ['message_id' => $form_resume_user_message_id];
    }

    /** Re-displays a required form before processing another chat message. */
    public static function pending_form_error(array $params)
    {
        if (!class_exists('\\WPAICG\\Lib\\Chat\\Triggers\\State\\AIPKit_Conversation_Form_State_Store')) {
            return null;
        }
        $form_state_store = new \WPAICG\Lib\Chat\Triggers\State\AIPKit_Conversation_Form_State_Store();
        $pending_form_state = $form_state_store->get_pending_form(
            (int) $params['bot_id'],
            $params['user_id'] ? (int) $params['user_id'] : null,
            $params['user_id'] ? null : (string) $params['session_id'],
            (string) $params['conversation_uuid']
        );
        if (is_array($pending_form_state) && !empty($pending_form_state['form_definition'])) {
            return new WP_Error(
                'trigger_display_form',
                __('Please complete the required form before continuing.', 'gpt3-ai-content-generator'),
                [
                    'status' => 200,
                    'display_form_event_data' => [
                        'type' => 'display_form',
                        'form_definition' => $pending_form_state['form_definition'],
                        'discarded_message_id' => sanitize_key((string) ($params['client_user_message_id'] ?? '')),
                    ],
                ]
            );
        }
        return null;
    }

    /**
     * Builds a system instruction that lets the resumed stream continue after a required chat form.
     *
     * @param array<string, mixed> $form_submission_context
     * @return string
     */
    public static function build_form_submission_resume_instruction_logic(array $form_submission_context): string
    {
        $form_id = sanitize_text_field((string) ($form_submission_context['form_id'] ?? ''));
        $submitted_display = isset($form_submission_context['submitted_data_display']) && is_array($form_submission_context['submitted_data_display'])
            ? $form_submission_context['submitted_data_display']
            : (isset($form_submission_context['submitted_data']) && is_array($form_submission_context['submitted_data']) ? $form_submission_context['submitted_data'] : []);
        $submitted_labels = isset($form_submission_context['submitted_data_labels']) && is_array($form_submission_context['submitted_data_labels'])
            ? $form_submission_context['submitted_data_labels']
            : [];

        $lines = [];
        foreach ($submitted_display as $field_key => $value) {
            $label = isset($submitted_labels[$field_key]) && is_string($submitted_labels[$field_key]) && trim($submitted_labels[$field_key]) !== ''
                ? $submitted_labels[$field_key]
                : (string) $field_key;
            $display_value = self::stringify_form_submission_resume_value($value);
            if ($display_value === '') {
                continue;
            }
            $lines[] = '- ' . sanitize_text_field($label) . ': ' . sanitize_text_field($display_value);
        }

        $instruction = "The visitor submitted the requested chat form. Continue answering the visitor's previous question now. Do not ask for the same form again unless genuinely more information is required.";
        if ($form_id !== '') {
            $instruction .= "\nForm ID: " . $form_id;
        }
        if (!empty($lines)) {
            $instruction .= "\nSubmitted form data:\n" . implode("\n", $lines);
        }

        return $instruction;
    }

    /**
     * Verifies that the resume stream was initiated by a successful chat form submission.
     *
     * @param array<string, mixed> $params
     * @return array<string, mixed>|WP_Error
     */
    private static function validate_form_submission_resume_token_logic(array $params)
    {
        $token = sanitize_text_field((string) ($params['form_resume_token'] ?? ''));
        if ($token === '') {
            return new WP_Error('missing_form_resume_token', __('Form resume token is missing.', 'gpt3-ai-content-generator'), ['status' => 403]);
        }

        $resume_state = get_transient('aipkit_chat_form_resume_' . sha1($token));
        delete_transient('aipkit_chat_form_resume_' . sha1($token));
        if (!is_array($resume_state)) {
            return new WP_Error('invalid_form_resume_token', __('Form resume token is invalid or expired.', 'gpt3-ai-content-generator'), ['status' => 403]);
        }

        $form_id = sanitize_text_field((string) ($resume_state['form_id'] ?? ''));

        if (
            $form_id === ''
            ||
            absint($resume_state['bot_id'] ?? 0) !== absint($params['bot_id'] ?? 0)
            || sanitize_key((string) ($resume_state['conversation_uuid'] ?? '')) !== sanitize_key((string) ($params['conversation_uuid'] ?? ''))
        ) {
            return new WP_Error('invalid_form_resume_scope', __('Form resume token does not match this chat session.', 'gpt3-ai-content-generator'), ['status' => 403]);
        }

        $user_id = absint($params['user_id'] ?? 0);
        if ($user_id > 0) {
            if (absint($resume_state['user_id'] ?? 0) !== $user_id) {
                return new WP_Error('invalid_form_resume_user', __('Form resume token does not match this user.', 'gpt3-ai-content-generator'), ['status' => 403]);
            }
            return $resume_state;
        }

        $session_id = sanitize_text_field((string) ($params['session_id'] ?? ''));
        if ($session_id === '' || sanitize_text_field((string) ($resume_state['session_id'] ?? '')) !== $session_id) {
            return new WP_Error('invalid_form_resume_session', __('Form resume token does not match this guest session.', 'gpt3-ai-content-generator'), ['status' => 403]);
        }

        return $resume_state;
    }

    /**
     * @param mixed $value
     * @return string
     */
    private static function stringify_form_submission_resume_value($value): string
    {
        if (is_array($value)) {
            $parts = [];
            foreach ($value as $item) {
                $item_value = self::stringify_form_submission_resume_value($item);
                if ($item_value !== '') {
                    $parts[] = $item_value;
                }
            }
            return implode(', ', $parts);
        }

        if (is_bool($value)) {
            return $value ? '1' : '0';
        }

        if ($value === null) {
            return '';
        }

        return (string) $value;
    }

    /** Adds a paid temporary upload without changing persistent Knowledge configuration. */
    public static function add_openai_file_context(array $ids, array $bot_settings, ?string $active_id): array
    {
        $temporary_openai_vs_id = ($bot_settings['enable_file_upload'] ?? '0') === '1'
            && class_exists(AIPKit_Chat_File_Upload_Provider_Resolver::class)
            && AIPKit_Chat_File_Upload_Provider_Resolver::resolve($bot_settings) === 'openai'
            ? sanitize_text_field((string) $active_id)
            : '';
        if ($temporary_openai_vs_id !== '' && !in_array($temporary_openai_vs_id, $ids, true)) {
            $ids[] = $temporary_openai_vs_id;
        }
        return $ids;
    }

    /** Attaches a paid native document after its upload scope has been resolved. */
    public static function apply_document_context(array &$ai_params_for_payload, string $provider, array $bot_settings, ?string $frontend_active_claude_file_id, ?array $frontend_active_google_document): void
    {
        if ($provider === 'Claude') {
            $claude_file_id = sanitize_text_field((string) $frontend_active_claude_file_id);
            if (
                ($bot_settings['enable_file_upload'] ?? '0') === '1' &&
                class_exists(AIPKit_Chat_File_Upload_Provider_Resolver::class) &&
                AIPKit_Chat_File_Upload_Provider_Resolver::resolve($bot_settings) === 'claude_files' &&
                $claude_file_id !== '' &&
                preg_match('/^file_[a-zA-Z0-9_-]+$/', $claude_file_id)
            ) {
                $ai_params_for_payload['claude_file_ids'] = [$claude_file_id];
            }
        } elseif ($provider === 'Google') {
            if (!empty($frontend_active_google_document)) {
                $ai_params_for_payload['google_document_input'] = $frontend_active_google_document;
            }
        }
    }
}
