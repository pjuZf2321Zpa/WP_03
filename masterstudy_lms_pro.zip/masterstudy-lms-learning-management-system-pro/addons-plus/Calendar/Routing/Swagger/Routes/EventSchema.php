<?php

namespace MasterStudy\Lms\Pro\AddonsPlus\Calendar\Routing\Swagger\Routes;

final class EventSchema {
	public static function properties(): array {
		return array(
			'id'        => array(
				'type'        => 'string',
				'description' => 'Stable event id for the calendar result.',
			),
			'title'     => array(
				'type'        => 'string',
				'description' => 'Event title.',
			),
			'type'      => array(
				'type'        => 'string',
				'description' => 'Event visual type.',
				'enum'        => array( 'zoom', 'meet', 'stream', 'deadline', 'quiz', 'available' ),
			),
			'timestamp' => array(
				'type'        => 'integer',
				'description' => 'Event start timestamp in site timezone.',
			),
			'date'      => array(
				'type'        => 'string',
				'description' => 'Event date in Y-m-d format.',
			),
			'time'      => array(
				'type'        => 'string',
				'description' => 'Event time in H:i format.',
			),
			'formatted_time' => array(
				'type'        => 'string',
				'description' => 'Event time formatted with the site time format setting.',
			),
			'duration'  => array(
				'type'        => 'string',
				'description' => 'Human-readable duration label.',
			),
			'course'    => array(
				'type'        => 'string',
				'description' => 'Related course title.',
			),
			'location'  => array(
				'type'        => 'string',
				'description' => 'Meeting or event location label.',
			),
			'url'       => array(
				'type'        => 'string',
				'description' => 'Course-player or course URL for the event action.',
			),
			'course_id' => array(
				'type'        => 'integer',
				'description' => 'Related course id.',
			),
			'item_id'   => array(
				'type'        => 'integer',
				'description' => 'Related curriculum item id.',
			),
			'source'    => array(
				'type'        => 'string',
				'description' => 'Backend source used to create the event.',
			),
			'status'    => array(
				'type'        => 'string',
				'description' => 'Event time status.',
				'enum'        => array( 'upcoming', 'past' ),
			),
			'is_past'   => array(
				'type'        => 'boolean',
				'description' => 'Whether the event has already ended.',
			),
		);
	}

	public static function pagination(): array {
		return array(
			'page'        => array(
				'type'        => 'integer',
				'description' => 'Current page.',
			),
			'per_page'    => array(
				'type'        => 'integer',
				'description' => 'Events per page.',
			),
			'total'       => array(
				'type'        => 'integer',
				'description' => 'Total events in the result.',
			),
			'total_pages' => array(
				'type'        => 'integer',
				'description' => 'Total page count.',
			),
			'has_more'    => array(
				'type'        => 'boolean',
				'description' => 'Whether another page is available.',
			),
		);
	}

	public static function counts(): array {
		return array(
			'upcoming' => array(
				'type'        => 'integer',
				'description' => 'Upcoming events count for the current month/search scope.',
			),
			'past'     => array(
				'type'        => 'integer',
				'description' => 'Past events count for the current month/search scope.',
			),
		);
	}
}
