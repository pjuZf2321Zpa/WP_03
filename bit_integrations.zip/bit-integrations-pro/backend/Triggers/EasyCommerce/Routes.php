<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Core\Util\Route;
use BitApps\IntegrationsPro\Triggers\EasyCommerce\EasyCommerceController;

Route::get('easy_commerce/get', [EasyCommerceController::class, 'getAllTasks']);
