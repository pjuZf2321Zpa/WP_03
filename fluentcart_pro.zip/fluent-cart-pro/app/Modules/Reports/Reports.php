<?php

namespace FluentCartPro\App\Modules\Reports;

use FluentCart\App\Services\Report\ChannelRules;
use FluentCartPro\App\Modules\Reports\Services\LocationInsightsService;

/**
 * Pro report sections: their REST routes, and the screens core renders in its report pages by name
 * (`reports.<page>.<section>` on `fluent_cart_admin_components`).
 */
class Reports
{
    public function register($app): void
    {
        // The sections import FluentCart's layout components (module API 3); older cores get only the update notice.
        if (!defined('FLUENTCART_MODULE_API') || FLUENTCART_MODULE_API < 3) {
            return;
        }

        $app->router->group(function ($router) {
            require_once __DIR__ . '/Http/routes.php';
        });

        // Core's Sources report applies the store's own channel rules only through this filter
        add_filter('fluent_cart/report/channel_rules', function () {
            return ChannelRules::get();
        });

        // Core's Future Renewals sends renewals by variant only when asked
        add_filter('fluent_cart/report/future_renewals_by_variation', '__return_true');
        // ...and the installment schedule, starts by month and collection rate
        add_filter('fluent_cart/report/installment_forecast', '__return_true');
        // ...and MRR by plan and interval with trial conversion
        add_filter('fluent_cart/report/mrr_breakdown', '__return_true');
        // ...and the Order Sources groupings by product, time and referrer
        add_filter('fluent_cart/report/source_groupings', '__return_true');
        // ...and MRR cohorts, billing intervals and rebuy-adjusted retention
        add_filter('fluent_cart/report/cohort_options', '__return_true');
        // ...and coupon quality: coupon vs full price, value of customers won, refund rate
        add_filter('fluent_cart/report/coupon_quality', '__return_true');
        // ...and the most refunded products
        add_filter('fluent_cart/report/refund_products', '__return_true');

        // Core's Locations report: states, cities, lifetime value and the biggest movers
        add_filter('fluent_cart/report/locations', function ($report, $params) {
            return LocationInsightsService::make()->getDetails($params);
        }, 10, 2);

        add_action('fluent_cart/loading_app', [$this, 'enqueueAdminApp']);
        add_filter('fluent_cart/admin_translations', [$this, 'addAdminTranslations'], 10, 2);
    }

    public function enqueueAdminApp(): void
    {
        $baseUrl = FLUENTCART_PRO_PLUGIN_URL . 'assets/modules/';

        wp_enqueue_style('fluent_cart_pro_reports', $baseUrl . 'reports.css', [], FLUENTCART_PRO_PLUGIN_VERSION);
        wp_enqueue_script('fluent_cart_pro_reports', $baseUrl . 'reports.js', [], FLUENTCART_PRO_PLUGIN_VERSION, true);

        add_filter('script_loader_tag', function ($tag, $handle) {
            if ($handle !== 'fluent_cart_pro_reports') {
                return $tag;
            }

            return str_replace('<script ', '<script type="module" ', $tag);
        }, 10, 2);
    }

    public function addAdminTranslations($translations, $args = [])
    {
        return array_merge(require __DIR__ . '/reports-translation.php', (array)$translations);
    }
}
