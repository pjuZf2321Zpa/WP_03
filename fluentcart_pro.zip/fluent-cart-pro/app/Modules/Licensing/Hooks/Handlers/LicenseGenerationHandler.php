<?php

namespace FluentCartPro\App\Modules\Licensing\Hooks\Handlers;

use FluentCart\App\Helpers\Status;
use FluentCart\App\Models\Order;
use FluentCart\App\Models\ProductMeta;
use FluentCart\App\Models\ProductVariation;
use FluentCart\App\Models\Subscription;
use FluentCart\Framework\Support\Arr;
use FluentCartPro\App\Modules\Licensing\Models\License;
use FluentCartPro\App\Modules\Licensing\Services\LicenseHelper;

class LicenseGenerationHandler
{

    public function register()
    {
        // fluent_cart/order_paid -> generate
        add_action('fluent_cart/order_paid', [$this, 'maybeGenerateLicensesOnPurchaseSuccess'], 10, 1);

        // fluent_cart/order_payment_failed -> revoke
        add_action('fluent_cart/order_payment_failed', [$this, 'maybeRevokeLicensesOnPaymentFailed'], 10, 1);

        // fluent_cart/order_fully_refunded -> revoke
        add_action('fluent_cart/order_fully_refunded', [$this, 'maybeRevokeLicensesOnFullRefund'], 10, 1);

        // fluent_cart/subscription_renewed -> extend validity
        add_action('fluent_cart/subscription_renewed', [$this, 'maybeExtendOnRenewal'], 10, 1);

        // fluent_cart/subscription_expired_validity -> expire the license
        // fluent_cart/payments/subscription_expired -> expire the license
        add_action('fluent_cart/subscription_expired_validity', [$this, 'maybeExpireLicenseOnSubscriptionExpired'], 10, 1);
        add_action('fluent_cart/payments/subscription_expired', [$this, 'maybeExpireLicenseOnSubscriptionExpired'], 10, 1);

        // fluent_cart/payments/subscription_completed
        add_action('fluent_cart/payments/subscription_completed', [$this, 'maybeExtendLicenseToLifeTimeOnEot'], 10, 1);

        // Handle Order Upgraded here
        add_action('fluent_cart/order/upgraded', [$this, 'handleUpgradedOrderCompleted'], 10, 1);

        add_action('fluent_cart/subscription/data_updated', [$this, 'syncLicensesOnSubscriptionUpdate'], 10, 1);

        add_filter('fluent_cart/order/expected_license_count', [$this, 'expectedLicenseCount'], 10, 2);

        add_action('fluent_cart/order/generateMissingLicenses', [$this, 'generateMissingLicenses'], 10, 1);

        add_action('fluent_cart/subscription_reactivated', [$this, 'maybeReactivateDisabledLicenses'], 10, 1);

    }


    public function generateMissingLicenses($data)
    {
        $orderModel = Arr::get($data, 'order', null);

        $accpetedTypes = [
            Status::ORDER_TYPE_PAYMENT,
            Status::ORDER_TYPE_SUBSCRIPTION
        ];

        if (!$orderModel || !in_array($orderModel->type, $accpetedTypes) || License::query()->where('order_id', $orderModel->id)->exists()) {
            return;
        }

        $formattedLicenses = $this->getFormattedLicensesByOrder($orderModel);

        if (!$formattedLicenses) {
            return false;
        }

        if ($orderModel->lienses) {
            //pluck all product_id
            $existingProductIds = $orderModel->licenses->pluck('product_id')->toArray();

            //now filter the $formattedLicenses to remove the existing product_ids
            $formattedLicenses = array_filter($formattedLicenses, function ($formatedLicense) use ($existingProductIds) {
                return !in_array($formatedLicense['post_id'], $existingProductIds);
            });
        }

        $subscription = Subscription::query()->where('parent_order_id', $orderModel->id)->first();

        foreach ($formattedLicenses as $licenseData) {
            $this->addNewLicense($licenseData, $orderModel, $subscription);
        }

        wp_send_json([
            'message' => __('Licenses generated successfully', 'fluent-cart-pro')
        ], 200);
    }


    public function maybeGenerateLicensesOnPurchaseSuccess($data)
    {
        $orderModel = Arr::get($data, 'order', null);

        $accpetedTypes = [
            Status::ORDER_TYPE_PAYMENT,
            Status::ORDER_TYPE_SUBSCRIPTION
        ];

        if (!$orderModel || !in_array($orderModel->type, $accpetedTypes) || License::query()->where('order_id', $orderModel->id)->exists()) {
            return;
        }

        $formattedLicenses = $this->getFormattedLicensesByOrder($orderModel);

        if (!$formattedLicenses) {
            return false;
        }

        $subscription = Subscription::query()->where('parent_order_id', $orderModel->id)->first();

        foreach ($formattedLicenses as $licenseData) {
            $this->addNewLicense($licenseData, $orderModel, $subscription);
        }

        return true;
    }

    public function maybeRevokeLicensesOnPaymentFailed($data)
    {
        $revokeLicenseOnPaymentFailed = apply_filters('fluent_cart/licensing/revoke_license_on_payment_failed', true, $data);

        if (!$revokeLicenseOnPaymentFailed) {
            return false;
        }

        $orderModel = Arr::get($data, 'order');

        if (!$orderModel) {
            return false;
        }

        $licenses = License::query()
            ->where('order_id', $orderModel->id)
            ->get();

        if ($licenses->isEmpty()) {
            return false;
        }

        foreach ($licenses as $license) {
            $prevConfig = $license->config;
            if (!is_array($prevConfig)) {
                $prevConfig = [];
            }

            $prevConfig['reason'] = 'Payment Failed';

            $license->fill([
                'status' => 'disabled',
                'config' => $prevConfig,
            ]);

            $license->save();

            do_action('fluent_cart/licensing/license_disabled', [
                'license' => $license,
                'order'   => $orderModel,
                'reason'  => 'payment_failed',
            ]);

        }

        return true;
    }

    public function maybeRevokeLicensesOnFullRefund($data)
    {
        $orderModel = Arr::get($data, 'order');

        $licenses = License::query()
            ->whereIn('order_id', array_filter([$orderModel->id, $orderModel->parent_id]))
            ->get();

        if ($licenses->isEmpty()) {
            return false;
        }

        foreach ($licenses as $license) {
            $prevConfig = $license->config;
            if (!is_array($prevConfig)) {
                $prevConfig = [];
            }

            $prevConfig['reason'] = 'Refunded';

            $license->fill([
                'status' => 'disabled',
                'config' => $prevConfig,
            ]);

            $license->save();

            do_action('fluent_cart/licensing/license_disabled', [
                'license' => $license,
                'order'   => $orderModel,
            ]);

        }

    }

    public function maybeExtendOnRenewal($data)
    {
        $subscription = Arr::get($data, 'subscription');
        if (!$subscription) {
            return;
        }

        $licenses = License::query()
            ->where('subscription_id', $subscription->id)
            ->get();

        if ($licenses->isEmpty()) {
            return;
        }

        foreach ($licenses as $license) {
            $oldExpirationDate = $license->expiration_date;
            $license->expiration_date = $subscription->next_billing_date ?: null;
            $prevStatus = $license->status;

            if (!$license->isValid()) {
                $license->status = 'active';
            }

            $license->save();

            $this->dispatchLicenseUpdateEvents($license, $subscription, $oldExpirationDate, $prevStatus);
        }

        return true;
    }

    /**
     * Follows next_billing_date changes from gateway syncs and admin edits.
     *
     * The payload carries no payment, so a disabled license is never restored here;
     * a paid renewal re-enables it through fluent_cart/subscription_renewed. When the
     * subscription status changed too, the status handlers own the license status.
     */
    public function syncLicensesOnSubscriptionUpdate($data)
    {
        $subscription = Arr::get($data, 'subscription');
        $updatedData = Arr::get($data, 'updated_data', []);

        if (!$subscription || !is_array($updatedData) || !array_key_exists('next_billing_date', $updatedData)) {
            return;
        }

        $nextBillingDate = $subscription->next_billing_date;
        if (!$nextBillingDate) {
            return;
        }

        $licenses = License::query()
            ->where('subscription_id', $subscription->id)
            ->where('status', '!=', 'disabled')
            ->get();

        $statusChanged = array_key_exists('status', $updatedData);

        foreach ($licenses as $license) {
            $oldExpirationDate = $license->expiration_date;
            $prevStatus = $license->status;

            $license->expiration_date = $nextBillingDate;

            if (!$statusChanged && $license->status === 'expired' && strtotime($nextBillingDate) > time()) {
                $license->status = 'active';
            }

            $license->save();

            $this->dispatchLicenseUpdateEvents($license, $subscription, $oldExpirationDate, $prevStatus);
        }

        return true;
    }

    private function dispatchLicenseUpdateEvents(License $license, $subscription, $oldExpirationDate, $prevStatus)
    {
        if ($oldExpirationDate !== $license->expiration_date) {
            do_action('fluent_cart/licensing/license_renewed', [
                'license'      => $license,
                'subscription' => $subscription,
                'prev_status'  => $prevStatus,
            ]);
        }

        if ($prevStatus !== $license->status) {
            do_action('fluent_cart/licensing/license_reactivated', [
                'license'      => $license,
                'subscription' => $subscription,
            ]);
        }
    }

    public function maybeExpireLicenseOnSubscriptionExpired($data)
    {
        $subscription = Arr::get($data, 'subscription');
        if (!$subscription) {
            return;
        }

        $licenses = License::query()
            ->where('subscription_id', $subscription->id)
            ->get();

        if ($licenses->isEmpty()) {
            return;
        }

        foreach ($licenses as $license) {
            if ($license->status === 'expired' || $license->status === 'disabled') {
                continue;
            }

            $prevStatus = $license->status;

            $license->status = 'expired';
            $license->save();

            do_action('fluent_cart/licensing/license_expired', [
                'license'      => $license,
                'subscription' => $subscription,
                'prev_status'  => $prevStatus,
            ]);
        }

        return true;
    }

    public function maybeExtendLicenseToLifeTimeOnEot($data)
    {
        $subscription = Arr::get($data, 'subscription');
        if (!$subscription) {
            return;
        }

        $licenses = License::query()
            ->where('subscription_id', $subscription->id)
            ->get();

        if ($licenses->isEmpty()) {
            return;
        }

        foreach ($licenses as $license) {
            $prevStatus = $license->status;

            if (!$license->isValid()) {
                $license->status = 'active';
            }

            $license->expiration_date = null; // Set expiration date to null for lifetime license
            $license->save();

            do_action('fluent_cart/licensing/extended_to_lifetime', [
                'license'      => $license,
                'subscription' => $subscription,
                'prev_status'  => $prevStatus,
            ]);
        }

        return true;
    }

    public function handleUpgradedOrderCompleted($data)
    {
        $newOrderModel = Arr::get($data, 'order', null);
        $oldOrderModel = Arr::get($data, 'from_order', null);
        $upgradedFromVariantId = Arr::get($data, 'from_variant_id');

        if (!$newOrderModel || !$oldOrderModel) {
            return;
        }

        $oldOrderLicences = License::query()
            ->where('order_id', $oldOrderModel->id)
            ->get();

        if ($oldOrderLicences->isEmpty()) {
            return;
        }

        /**
         * Steps:
         *  - Find all licenses associated with the old order
         *  - Update the licenses to point to the new order
         *  - Maybe we have new limits and validity, so we need to check the new order items
         *  - Set the status of the licenses to 'active'
         *  - maybe it's a lifetime license, so we need to check if the new order has a lifetime licenses
         *  - check the subscription if it exists, and update the subscription_id in the licenses
         */
        $newFormattedLicenses = $this->getFormattedLicensesByOrder($newOrderModel);
        if (!$newFormattedLicenses) {
            return;
        }

        $subscription = Subscription::query()->where('parent_order_id', $newOrderModel->id)->first();

        foreach ($newFormattedLicenses as $newLicenseData) {

            $existingLicense = License::query()->where('product_id', $newLicenseData['product_id'])
                ->where('variation_id', $upgradedFromVariantId)
                ->where('order_id', $oldOrderModel->id)
                ->first();

            if ($existingLicense) {
                // This is the exisitng license, we need to update it
                $prevConfig = $existingLicense->config;
                $prevOrderIds = Arr::get($prevConfig, 'prev_order_ids', []);
                $prevOrderIds[] = $oldOrderModel->id;
                $prevConfig['prev_order_ids'] = array_values(array_unique($prevOrderIds));

                $existingLicense->fill([
                    'limit'              => $newLicenseData['limit'],
                    'expiration_date'    => $subscription ? ($subscription->next_billing_date ?: null) : $newLicenseData['expiration_date'],
                    'variation_id'       => $newLicenseData['variation_id'],
                    'order_id'           => $newOrderModel->id,
                    'subscription_id'    => $subscription ? $subscription->id : null,
                    'last_reminder_sent' => null,
                    'last_reminder_type' => null,
                    'config'             => $prevConfig,
                    'customer_id'        => $newOrderModel->customer_id,
                ]);

                $updates = $existingLicense->getDirty();
                $updates = array_map(fn($v) => $v instanceof \FluentCart\Framework\Database\Query\Expression ? null : $v, $updates);
                $existingLicense->save();

                do_action('fluent_cart/licensing/license_upgraded', [
                    'license'      => $existingLicense,
                    'order'        => $newOrderModel,
                    'subscription' => $subscription,
                    'updates'      => $updates
                ]);
            } else {
                // This is a new license, we need to create it
                $this->addNewLicense($newLicenseData, $newOrderModel, $subscription);
            }
        }

        return true;
    }

    public function maybeReactivateDisabledLicenses($data)
    {
        $subscription = Arr::get($data, 'subscription');
        if (!$subscription) {
            return;
        }

        $licenses = License::query()
            ->where('subscription_id', $subscription->id)
            ->whereIn('status', [Status::LICENSE_DISABLED, 'expired'])
            ->get();

        if ($licenses->isEmpty()) {
            return;
        }

        foreach ($licenses as $license) {
            $newStatus = $license->activation_count > 0 ? Status::LICENSE_ACTIVE : 'inactive';
            $license->fill([
                'status'          => $newStatus,
                'expiration_date' => $subscription->next_billing_date ?: $license->expiration_date,
            ]);
            $license->save();

            do_action('fluent_cart/licensing/license_reactivated', [
                'license'      => $license,
                'subscription' => $subscription,
            ]);
        }
    }

    private function getFormattedLicensesByOrder(Order $orderModel)
    {
        $productIds = [];
        $variationIds = [];
        $quantityMaps = [];

        foreach ($orderModel->order_items as $item) {
            if ($item->payment_type == 'signup_fee') {
                continue;
            }

            $productIds[] = $item->post_id;
            $variationIds[] = $item->object_id;
            $quantityMaps[$item->object_id] = $item->quantity;
        }

        $productIds = array_values(array_unique($productIds));
        $variationIds = array_values(array_unique($variationIds));

        if (!$productIds || !$variationIds) {
            return false;
        }

        $licenseConfigs = ProductMeta::query()->whereIn('object_id', $productIds)
            ->where('meta_key', 'license_settings')
            ->get();

        if ($licenseConfigs->isEmpty()) {
            return;
        }

        $formattedLicenses = [];
        foreach ($licenseConfigs as $licenseConfig) {
            $value = $licenseConfig->meta_value;
            if (Arr::get($value, 'enabled') !== 'yes') {
                continue;
            }

            $variations = Arr::get($value, 'variations', []);
            foreach ($variations as $variation) {
                if (!in_array($variation['variation_id'], $variationIds)) {
                    continue;
                }

                $limit = (int)Arr::get($variation, 'activation_limit', 0);
                if ($limit < 0) {
                    continue;
                }

                $variantItem = ProductVariation::query()->where('id', $variation['variation_id'])
                    ->first();

                if (!$variantItem) {
                    continue;
                }

                if (!empty($quantityMaps[$variantItem->id])) {
                    $limit = $limit * $quantityMaps[$variantItem->id];
                }

                $formattedLicenses[$variation['variation_id']] = [
                    'prefix'          => Arr::get($value, 'prefix', ''),
                    'variation'       => $variantItem,
                    'limit'           => (int)$limit,
                    'product_id'      => $licenseConfig->object_id,
                    'variation_id'    => $variantItem->id,
                    'expiration_date' => LicenseHelper::getExpirationDateByVariation($variantItem)
                ];
            }
        }

        return $formattedLicenses;
    }

    public function expectedLicenseCount($expectedLicenseCount, array $args)
    {
        $productIds = [];
        foreach (Arr::get($args, 'order_items', []) as $item) {
            if (Arr::get($item, 'payment_type') == 'signup_fee') {
                continue;
            }
            $productIds[] = Arr::get($item, 'post_id');
        }

        $productIds = array_values(array_unique($productIds)) ?? [];

        $licenseConfigs = ProductMeta::query()->whereIn('object_id', $productIds)
            ->where('meta_key', 'license_settings')
            ->whereRaw('JSON_VALID(meta_value) = 1')
            ->whereRaw("JSON_UNQUOTE(JSON_EXTRACT(meta_value, '$.enabled')) = 'yes'")
            ->get();

        if (!$licenseConfigs->isEmpty()) {
            $expectedLicenseCount = $licenseConfigs->count();
        }

        return $expectedLicenseCount;
    }

    private function addNewLicense($licenseData, $orderModel, $subscription = null)
    {
        $data = [
            'status'          => 'inactive',
            'limit'           => $licenseData['limit'],
            'order_id'        => $orderModel->id,
            'product_id'      => $licenseData['product_id'],
            'variation_id'    => $licenseData['variation_id'],
            'customer_id'     => $orderModel->customer_id,
            'expiration_date' => $licenseData['expiration_date'],
            'config'          => [],
            'license_key'     => $licenseData['prefix'] . md5(
                    $licenseData['product_id'] . '-' . $licenseData['variation_id'] . '-' . $orderModel->id . '-' . wp_generate_uuid4()
                ),
        ];

        $isBundleOrderItem = false;

        foreach ($orderModel->order_items as $item) {
            if ($item->payment_type == 'bundle' && $item->object_id == $licenseData['variation_id']) {
                $isBundleOrderItem = true;
                break;
            }
        }

        if ($subscription && $licenseData['expiration_date']) {
            $data['subscription_id'] = $subscription->id;
            $data['expiration_date'] = $subscription->next_billing_date ?: ($licenseData['expiration_date'] ?: null);
        } else if ($isBundleOrderItem && !$subscription) { 
            $data['expiration_date'] = null; // overriding item's expiration date for bundle order, if the bundle order is not a subscription
        }

        $data = apply_filters('fluent_cart/licensing/license_create_data', $data, [
            'order'        => $orderModel,
            'variation'    => $licenseData['variation'],
            'subscription' => $subscription,
        ]);

        if (is_wp_error($data)) {
            return $data;
        }

        $license = License::query()->create($data);
        do_action('fluent_cart/licensing/license_issued', [
            'license'      => $license,
            'data'         => $data,
            'order'        => $orderModel,
            'subscription' => $subscription,
        ]);

        return $license;
    }

}
