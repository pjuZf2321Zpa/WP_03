<?php

namespace MasterStudy\Lms\Pro\addons\point_system\Http\Controllers\Admin;

use MasterStudy\Lms\Http\WpResponseFactory;
use MasterStudy\Lms\Pro\addons\point_system\Http\Serializers\PointStatisticsHistorySerializer;
use MasterStudy\Lms\Pro\addons\point_system\Repositories\PointStatisticsAdminAccess;
use MasterStudy\Lms\Pro\addons\point_system\Repositories\PointStatisticsRepository;
use MasterStudy\Lms\Validation\Validator;
use WP_REST_Request;
use WP_REST_Response;

final class GetUserHistoryController {
	public function __invoke( WP_REST_Request $request ): WP_REST_Response {
		if ( ! PointStatisticsAdminAccess::can_access() ) {
			return WpResponseFactory::forbidden();
		}

		$validator = new Validator(
			$request->get_params(),
			array(
				'user_id'  => 'required|integer',
				'per_page' => 'nullable|integer',
				'page'     => 'nullable|integer',
			)
		);

		if ( $validator->fails() ) {
			return WpResponseFactory::validation_failed( $validator->get_errors_array() );
		}

		$params  = $validator->get_validated();
		$user_id = absint( $params['user_id'] ?? 0 );

		if ( ! $user_id || ! get_userdata( $user_id ) ) {
			return WpResponseFactory::not_found();
		}

		$data          = ( new PointStatisticsRepository() )->get_user_history( $user_id, $params );
		$data['items'] = ( new PointStatisticsHistorySerializer() )->collectionToArray( $data['items'] );

		return WpResponseFactory::ok_with_data( $data );
	}
}
