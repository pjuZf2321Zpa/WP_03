<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Core\Util\Hooks;
use BitApps\IntegrationsPro\Triggers\Coblocks\CoblocksController;

Hooks::add('coblocks_form_submit', [CoblocksController::class, 'coblocksHandler'], 10, PHP_INT_MAX);
