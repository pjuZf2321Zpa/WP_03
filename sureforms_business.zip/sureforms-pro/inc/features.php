<?php
/**
 * SureForms Pro rows for Settings → Features.
 *
 * The registry, the option and the settings tab live in SureForms
 * (`SRFM\Inc\Features`). Pro only adds its rows through `srfm_features` and
 * asks `Features::is_on()` before booting a module.
 *
 * @package sureforms-pro
 * @since 2.14.0
 */

namespace SRFM_Pro\Inc;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Pro feature rows.
 *
 * @since 2.14.0
 */
class Features {
	/**
	 * Whether a feature is on.
	 *
	 * With a SureForms that predates the registry every feature is on, so Pro
	 * behaves exactly as it did before.
	 *
	 * @param string $key Feature key.
	 * @since 2.14.0
	 * @return bool
	 */
	public static function is_on( $key ) {
		if ( ! class_exists( '\SRFM\Inc\Features' ) ) {
			return true;
		}
		return \SRFM\Inc\Features::is_enabled( $key );
	}

	/**
	 * Add the Pro rows, and the Pro entry routes to the Entries row.
	 *
	 * Hooked on `srfm_features`.
	 *
	 * @param array<string,array<string,mixed>> $rows Feature rows.
	 * @since 2.14.0
	 * @return array<string,array<string,mixed>>
	 */
	public static function register( $rows ) {
		// Edit, notes, logs and resend are part of Entries, not a feature of their own.
		if ( isset( $rows['entries'] ) ) {
			$rows['entries']['routes'] = array_merge(
				is_array( $rows['entries']['routes'] ?? null ) ? $rows['entries']['routes'] : [],
				[
					'entry/(?P<id>\d+)/logs/(?P<log_id>\d+)',
					'entry/(?P<id>\d+)/notes',
					'entries/resend-notification',
					'entries/(?P<form_id>\d+)/enabled-email-notifications',
					'entry/edit',
				]
			);
		}

		// Quiz, Survey and PDF read or write stored entries, and Partial Entries stores
		// form data, so each is off whenever Entries is.
		$pro = [
			'quiz'                      => [
				'depends_on'  => [ 'entries' ],
				'usage_meta'  => [ '_srfm_quiz_meta' ],
				'admin_pages' => [ 'sureforms_quiz_entries' ],
			],
			'survey'                    => [
				'depends_on'  => [ 'entries' ],
				'usage_meta'  => [ '_srfm_survey_meta' ],
				'admin_pages' => [ 'sureforms_survey_reports' ],
			],
			'pdf'                       => [
				'depends_on' => [ 'entries' ],
				'usage_meta' => [ '_srfm_pdf_meta' ],
			],
			'partial_entries'           => [
				'depends_on'  => [ 'entries' ],
				'cron_hooks'  => [ 'srfm_partial_lifecycle_tick', 'srfm_partial_entry_notify' ],
				'usage_meta'  => [ '_srfm_partial_entries' ],
				'admin_pages' => [ 'sureforms_partial_entries' ],
			],
			'save_resume'               => [
				'usage_meta' => [ '_srfm_save_resume' ],
			],
			'conversational'            => [
				'usage_meta' => [ '_srfm_conversational_form' ],
			],
			// A payment whose amount comes from a calculated field is refused while this is off.
			'calculations'              => [
				'usage_attrs' => [ 'enableCalculation' ],
			],
			'conditional_logic'         => [],
			'conditional_emails'        => [],
			'conditional_confirmations' => [],
			'post_feeds'                => [
				'usage_meta' => [ '_srfm_raw_cpt_meta' ],
			],
			'native_integrations'       => [],
			'user_registration'         => [
				'usage_blocks' => [ 'srfm/register', 'srfm/login', 'srfm/lost-password', 'srfm/reset-password', 'srfm/password' ],
			],
		];

		foreach ( $pro as $key => $row ) {
			$row['group'] = 'pro';
			$rows[ $key ] = $row;
		}

		return $rows;
	}

	/**
	 * Label and description of each Pro feature.
	 *
	 * Hooked on `srfm_feature_labels`, which is read only on admin screens, so
	 * these strings are never translated before `init`.
	 *
	 * @param array<string,array<string,string>> $labels Keyed by feature key.
	 * @since 2.14.0
	 * @return array<string,array<string,string>>
	 */
	public static function labels( $labels ) {
		$labels['quiz']                      = [
			'label'       => __( 'Quizzes', 'sureforms-pro' ),
			'description' => __( 'Turning this off stops quiz scoring and hides quiz results.', 'sureforms-pro' ),
		];
		$labels['survey']                    = [
			'label'       => __( 'Surveys & polls', 'sureforms-pro' ),
			'description' => __( 'Turning this off hides survey reports and live poll results.', 'sureforms-pro' ),
		];
		$labels['pdf']                       = [
			'label'       => __( 'PDF generation', 'sureforms-pro' ),
			'description' => __( 'Turning this off stops creating PDFs and attaching them to emails.', 'sureforms-pro' ),
		];
		$labels['partial_entries']           = [
			'label'       => __( 'Partial entries', 'sureforms-pro' ),
			'description' => __( 'Turning this off stops partial saves and reminder emails.', 'sureforms-pro' ),
		];
		$labels['save_resume']               = [
			'label'       => __( 'Save & resume', 'sureforms-pro' ),
			'description' => __( 'Turning this off removes the option to save a form and finish it later.', 'sureforms-pro' ),
		];
		$labels['conversational']            = [
			'label'       => __( 'Conversational forms', 'sureforms-pro' ),
			'description' => __( 'Turning this off turns conversational forms into regular ones.', 'sureforms-pro' ),
		];
		$labels['user_registration']         = [
			'label'       => __( 'User registration & login', 'sureforms-pro' ),
			'description' => __( 'Turning this off removes login and registration fields from your forms.', 'sureforms-pro' ),
		];
		$labels['calculations']              = [
			'label'       => __( 'Calculations', 'sureforms-pro' ),
			'description' => __( 'Turning this off stops calculated fields from working out their values, so payments that take their amount from one are refused.', 'sureforms-pro' ),
			'usage'       => __( 'has a calculated field', 'sureforms-pro' ),
		];
		$labels['conditional_logic']         = [
			'label'       => __( 'Conditional logic', 'sureforms-pro' ),
			'description' => __( 'Turning this off shows every field, ignoring show and hide rules.', 'sureforms-pro' ),
		];
		$labels['conditional_emails']        = [
			'label'       => __( 'Conditional emails', 'sureforms-pro' ),
			'description' => __( 'Turning this off sends every enabled email, whatever the answers.', 'sureforms-pro' ),
		];
		$labels['conditional_confirmations'] = [
			'label'       => __( 'Conditional confirmations', 'sureforms-pro' ),
			'description' => __( 'Turning this off shows every visitor the default confirmation.', 'sureforms-pro' ),
		];
		$labels['post_feeds']                = [
			'label'       => __( 'Post creation', 'sureforms-pro' ),
			'description' => __( 'Turning this off stops submissions from creating posts.', 'sureforms-pro' ),
		];
		$labels['native_integrations']       = [
			'label'       => __( 'Integrations & webhooks', 'sureforms-pro' ),
			'description' => __( 'Turning this off stops sending submissions to webhooks and apps.', 'sureforms-pro' ),
		];
		return $labels;
	}
}
