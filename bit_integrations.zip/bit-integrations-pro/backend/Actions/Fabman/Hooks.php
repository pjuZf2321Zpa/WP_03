<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Actions\Fabman\FabmanHelperPro;
use BitApps\IntegrationsPro\Config;
use BitApps\IntegrationsPro\Core\Util\Hooks;

// Deprecated since v2.7.8 - use bit_integrations_fabman_* hooks instead
if (bit_integrations_version_below('2.7.8')) {
    Hooks::filter('btcbi_fabman_update_member', [FabmanHelperPro::class, 'updateMember'], 10, 5);
    Hooks::filter('btcbi_fabman_delete_member', [FabmanHelperPro::class, 'deleteMember'], 10, 4);
    Hooks::filter('btcbi_fabman_create_space', [FabmanHelperPro::class, 'createSpace'], 10, 4);
    Hooks::filter('btcbi_fabman_update_space', [FabmanHelperPro::class, 'updateSpace'], 10, 5);
}

// New hooks since v2.7.8
Hooks::filter(Config::withFreePrefix('fabman_update_member'), [FabmanHelperPro::class, 'updateMember'], 10, 5);
Hooks::filter(Config::withFreePrefix('fabman_delete_member'), [FabmanHelperPro::class, 'deleteMember'], 10, 4);
Hooks::filter(Config::withFreePrefix('fabman_create_space'), [FabmanHelperPro::class, 'createSpace'], 10, 4);
Hooks::filter(Config::withFreePrefix('fabman_update_space'), [FabmanHelperPro::class, 'updateSpace'], 10, 5);
