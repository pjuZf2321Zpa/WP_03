<?php

namespace BitApps\IntegrationsPro\Actions\FollowUpBoss\Services;

final class DealService extends BaseService
{
    public function createDeal(): array
    {
        $validationRules = [
            'name'             => ['required'],
            'stage_id'         => ['required', 'integer'],
            'price'            => ['nullable', 'integer'],
            'commission_value' => ['nullable', 'integer'],
            'agent_commission' => ['nullable', 'integer'],
            'team_commission'  => ['nullable', 'integer'],
            'order_weight'     => ['nullable', 'integer'],
        ];
        $error = $this->validateFields(
            $validationRules,
            [
                'name'             => __('Deal Name', 'bit-integrations-pro'),
                'stage_id'         => __('Stage', 'bit-integrations-pro'),
                'price'            => __('Price', 'bit-integrations-pro'),
                'commission_value' => __('Commission Value', 'bit-integrations-pro'),
                'agent_commission' => __('Agent Commission', 'bit-integrations-pro'),
                'team_commission'  => __('Team Commission', 'bit-integrations-pro'),
                'order_weight'     => __('Sort Order', 'bit-integrations-pro'),
            ],
            ['stage_id']
        );

        if ($error !== null) {
            return $error;
        }

        $payload = $this->removeEmptyValues(
            [
                'name'                 => $this->getString('name'),
                'stageId'              => $this->getInteger('stage_id'),
                'description'          => $this->getString('description'),
                'peopleIds'            => $this->getIntegerList('people_ids'),
                'userIds'              => $this->getIntegerList('user_ids'),
                'price'                => $this->getInteger('price'),
                'projectedCloseDate'   => $this->getString('projected_close_date'),
                'commissionValue'      => $this->getInteger('commission_value'),
                'agentCommission'      => $this->getInteger('agent_commission'),
                'teamCommission'       => $this->getInteger('team_commission'),
                'earnestMoneyDueDate'  => $this->getString('earnest_money_due_date'),
                'mutualAcceptanceDate' => $this->getString('mutual_acceptance_date'),
                'dueDiligenceDate'     => $this->getString('due_diligence_date'),
                'finalWalkThroughDate' => $this->getString('final_walk_through_date'),
                'possessionDate'       => $this->getString('possession_date'),
                'orderWeight'          => $this->getInteger('order_weight'),
            ]
        );

        return $this->dispatch('POST', '/deals', $payload);
    }

    public function updateDeal(): array
    {
        $validationRules = [
            'deal_id'          => ['required', 'integer'],
            'price'            => ['nullable', 'integer'],
            'commission_value' => ['nullable', 'integer'],
            'agent_commission' => ['nullable', 'integer'],
            'team_commission'  => ['nullable', 'integer'],
            'order_weight'     => ['nullable', 'integer'],
        ];
        $error = $this->validateFields(
            $validationRules,
            [
                'deal_id'          => __('Deal ID', 'bit-integrations-pro'),
                'price'            => __('Price', 'bit-integrations-pro'),
                'commission_value' => __('Commission Value', 'bit-integrations-pro'),
                'agent_commission' => __('Agent Commission', 'bit-integrations-pro'),
                'team_commission'  => __('Team Commission', 'bit-integrations-pro'),
                'order_weight'     => __('Sort Order', 'bit-integrations-pro'),
            ]
        );

        if ($error !== null) {
            return $error;
        }

        $payload = $this->removeEmptyValues(
            [
                'name'                 => $this->getString('name'),
                'stageId'              => $this->getInteger('stage_id'),
                'description'          => $this->getString('description'),
                'peopleIds'            => $this->getIntegerList('people_ids'),
                'userIds'              => $this->getIntegerList('user_ids'),
                'price'                => $this->getInteger('price'),
                'projectedCloseDate'   => $this->getString('projected_close_date'),
                'commissionValue'      => $this->getInteger('commission_value'),
                'agentCommission'      => $this->getInteger('agent_commission'),
                'teamCommission'       => $this->getInteger('team_commission'),
                'earnestMoneyDueDate'  => $this->getString('earnest_money_due_date'),
                'mutualAcceptanceDate' => $this->getString('mutual_acceptance_date'),
                'dueDiligenceDate'     => $this->getString('due_diligence_date'),
                'finalWalkThroughDate' => $this->getString('final_walk_through_date'),
                'possessionDate'       => $this->getString('possession_date'),
                'orderWeight'          => $this->getInteger('order_weight'),
            ]
        );

        return $this->dispatch('PUT', '/deals/' . rawurlencode($this->getString('deal_id')), $payload);
    }

    public function deleteDeal(): array
    {
        $validationRules = ['deal_id' => ['required', 'integer']];
        $error = $this->validateFields(
            $validationRules,
            [
                'deal_id' => __('Deal ID', 'bit-integrations-pro'),
            ]
        );

        if ($error !== null) {
            return $error;
        }

        return $this->dispatch('DELETE', '/deals/' . rawurlencode($this->getString('deal_id')));
    }
}
