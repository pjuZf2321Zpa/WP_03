<?php

use FluentCart\Framework\Http\Router;
use FluentCartPro\App\Modules\Promotional\Http\Controllers\OrderBumpController;

/**
 * @var $router Router
 */

$router->prefix('order_bump')->withPolicy('OrderBumpPolicy')->group(function ($router) {
    $router->get('/', [OrderBumpController::class, 'index'])->meta([
        'permissions' => 'store/sensitive' // TODO: i will change this later
    ]);
    $router->post('/', [OrderBumpController::class, 'store'])->meta([
        'permissions' => 'store/sensitive' // TODO: i will change this later
    ]);

    $router->get('/settings', [OrderBumpController::class, 'getSettings'])->meta([
        'permissions' => 'store/sensitive'
    ]);
    $router->post('/settings', [OrderBumpController::class, 'saveSettings'])->meta([
        'permissions' => 'store/sensitive'
    ]);

    $router->post('/templates', [OrderBumpController::class, 'createTemplate'])->meta([
        'permissions' => 'store/sensitive'
    ]);
    $router->get('/templates/{template_id}', [OrderBumpController::class, 'getTemplate'])->meta([
        'permissions' => 'store/sensitive'
    ]);
    $router->post('/templates/{template_id}', [OrderBumpController::class, 'saveTemplate'])->meta([
        'permissions' => 'store/sensitive'
    ]);
    $router->post('/templates/{template_id}/reset', [OrderBumpController::class, 'resetTemplate'])->meta([
        'permissions' => 'store/sensitive'
    ]);
    $router->delete('/templates/{template_id}', [OrderBumpController::class, 'deleteTemplate'])->meta([
        'permissions' => 'store/sensitive'
    ]);

    $router->get('/{id}', [OrderBumpController::class, 'show'])->meta([
        'permissions' => 'store/sensitive' // TODO: i will change this later
    ])->int('id');

    $router->put('/{id}', [OrderBumpController::class, 'update'])->meta([
        'permissions' => 'store/sensitive' // TODO: i will change this later
    ])->int('id');

    $router->put('/{id}/status', [OrderBumpController::class, 'updateStatus'])->meta([
        'permissions' => 'store/sensitive'
    ])->int('id');

    $router->delete('/{id}', [OrderBumpController::class, 'delete'])->meta([
        'permissions' => 'store/sensitive' // TODO: i will change this later
    ])->int('id');


});
