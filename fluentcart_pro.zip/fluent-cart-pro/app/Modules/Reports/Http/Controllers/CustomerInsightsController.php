<?php

namespace FluentCartPro\App\Modules\Reports\Http\Controllers;

use FluentCart\App\Http\Controllers\Controller;
use FluentCart\App\Services\Permission\PermissionManager;
use FluentCart\App\Services\Report\ReportHelper;
use FluentCart\Framework\Http\Request\Request;
use FluentCartPro\App\Modules\Reports\Services\CustomerInsightsService;

class CustomerInsightsController extends Controller
{
    public function value(Request $request)
    {
        $params = ReportHelper::processParams($request->get('params'), ['paymentStatus'], true);

        $service = CustomerInsightsService::make();
        // "All time" concentration reads every customer: only when the switch asks for it
        if ($request->get('span') === 'lifetime') {
            return ['concentration' => ['lifetime' => $service->getLifetimeConcentration($params)]];
        }

        return $service->getValue($params);
    }

    public function repeat(Request $request)
    {
        $params = ReportHelper::processParams($request->get('params'), ['paymentStatus'], true);

        return CustomerInsightsService::make()->getRepeat($params);
    }

    public function segments(Request $request)
    {
        $params = ReportHelper::processParams($request->get('params'), ['paymentStatus'], true);

        return CustomerInsightsService::make()->getSegments($params);
    }

    public function segmentCustomers(Request $request)
    {
        // Customer names and emails in bulk: report access alone is not enough
        if (!PermissionManager::hasPermission('customers/export')) {
            return $this->sendError([
                'message' => __('You do not have permission to export customers.', 'fluent-cart-pro')
            ], 403);
        }

        $params = ReportHelper::processParams($request->get('params'), ['paymentStatus'], true);

        return CustomerInsightsService::make()->getSegmentCustomers(
            $params,
            sanitize_key((string) $request->get('segment', '')),
            absint($request->get('page', 1)),
            absint($request->get('per_page', 1000)),
            CustomerInsightsService::validCuts($request->get('cuts')),
            sanitize_text_field((string) $request->get('as_of', ''))
        );
    }
}
