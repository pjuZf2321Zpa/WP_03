<?php
/**
 * Shared RSS selection policy for previews, inline writing and automation runs.
 *
 * @package AI_Puffer
 */

namespace WPAICG\Lib\ContentWriter;

use WP_Error;
use WPAICG\aipkit_dashboard;
use WPAICG\AutoGPT\Cron\EventProcessor\Trigger\Modules;

if (!defined('ABSPATH')) {
    exit;
}

require_once WPAICG_LIB_DIR . 'automations/module-triggers.php';

class AIPKit_Rss_Item_Selector
{
    /**
     * Missing/empty means legacy behavior; zero explicitly means all available.
     * Reject invalid values instead of accidentally converting them to unlimited.
     *
     * @return true|WP_Error
     */
    public static function validate_config(array $config)
    {
        if (($config['cw_generation_mode'] ?? '') !== 'rss' && ($config['task_type'] ?? '') !== 'content_writing_rss') {
            return true;
        }
        $value = $config['rss_item_limit'] ?? '';
        if ($value === '') {
            return true;
        }
        if ((!is_string($value) && !is_int($value)) || !preg_match('/^(0|[1-9][0-9]*)$/D', (string) $value) || filter_var($value, FILTER_VALIDATE_INT, ['options' => ['min_range' => 0]]) === false) {
            return new WP_Error('invalid_rss_item_limit', __('Choose All available or enter a positive whole number of articles.', 'gpt3-ai-content-generator'), ['status' => 400]);
        }
        return true;
    }

    public static function uses_legacy_selection(array $config): bool
    {
        return !isset($config['rss_item_limit']) || $config['rss_item_limit'] === '';
    }

    /**
     * Select before queue insertion, using exactly the same policy for previews.
     * History and queued entries are task-scoped; inline runs use task ID zero.
     *
     * @return array|WP_Error Items and the eligible count before the user's limit.
     */
    public static function select(array $config, int $task_id = 0, ?string $last_run_time = null)
    {
        if (!aipkit_dashboard::is_pro_plan()) {
            return new WP_Error('rss_feature_unavailable', __('RSS generation is a Pro feature.', 'gpt3-ai-content-generator'), ['status' => 403]);
        }
        $validation = self::validate_config(array_merge($config, ['cw_generation_mode' => 'rss']));
        if (is_wp_error($validation)) {
            return $validation;
        }
        $legacy = self::uses_legacy_selection($config);
        $limit = $legacy ? 0 : (int) $config['rss_item_limit'];
        $parser = new AIPKit_Rss_Feed_Parser();
        // A timestamp cutoff would permanently skip the unselected remainder of
        // a limited run. Reconsider available entries, then exclude task history.
        $items = $parser->get_latest_items($config['rss_feeds'] ?? '', $legacy ? $last_run_time : null, $legacy ? 15 : 0);
        $items = array_values(Modules\apply_include_exclude_keywords_logic(
            $items,
            $config['rss_include_keywords'] ?? '',
            $config['rss_exclude_keywords'] ?? ''
        ));
        if (!$legacy) {
            usort($items, static function (array $a, array $b): int {
                $date_order = $b['timestamp'] <=> $a['timestamp'];
                return $date_order ?: strcmp((string) $a['guid'], (string) $b['guid']);
            });
        }
        $excluded = self::get_existing_identifiers($task_id, wp_list_pluck($items, 'guid'));
        if (is_wp_error($excluded)) {
            return $excluded;
        }
        $seen_guids = [];
        $seen_links = [];
        $eligible = [];
        foreach ($items as $item) {
            $guid = (string) ($item['guid'] ?? '');
            $link = (string) ($item['link'] ?? '');
            if ($guid === '' || trim($item['title'] ?? '') === '' || isset($excluded[$guid]) || isset($seen_guids[$guid]) || ($link !== '' && isset($seen_links[$link]))) {
                continue;
            }
            $seen_guids[$guid] = true;
            if ($link !== '') {
                $seen_links[$link] = true;
            }
            $eligible[] = $item;
        }
        return [
            'items' => $limit > 0 ? array_slice($eligible, 0, $limit) : $eligible,
            'matching_count' => count($eligible),
            'limited' => $limit > 0,
        ];
    }

    /**
     * Query in bounded groups; do not load a task's entire queue/history.
     *
     * @return array|WP_Error
     */
    private static function get_existing_identifiers(int $task_id, array $guids)
    {
        if ($task_id <= 0 || !$guids) {
            return [];
        }
        global $wpdb;
        $history_table = esc_sql($wpdb->prefix . 'aipkit_rss_history');
        $queue_table = esc_sql($wpdb->prefix . 'aipkit_automated_task_queue');
        $existing = [];
        foreach (array_chunk(array_values(array_unique($guids)), 500) as $chunk) {
            $placeholders = implode(', ', array_fill(0, count($chunk), '%s'));
            $args = array_merge([$task_id], $chunk);
            // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Escaped plugin-owned table identifier; placeholders generated above, values prepared below.
            $history_sql = $wpdb->prepare("SELECT item_guid FROM `{$history_table}` WHERE task_id = %d AND item_guid IN ({$placeholders})", $args);
            // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Escaped plugin-owned table identifier; placeholders generated above, values prepared below.
            $queue_sql = $wpdb->prepare("SELECT target_identifier FROM `{$queue_table}` WHERE task_id = %d AND target_identifier IN ({$placeholders})", $args);
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared -- Prepared above; eligibility must reflect current history.
            $processed = $wpdb->get_col($history_sql);
            if ($wpdb->last_error) {
                return new WP_Error('rss_history_unavailable', __('Could not check previously fetched articles. Please try again.', 'gpt3-ai-content-generator'), ['status' => 500]);
            }
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared -- Prepared above; include all queue statuses to preserve existing retry semantics.
            $queued = $wpdb->get_col($queue_sql);
            if ($wpdb->last_error) {
                return new WP_Error('rss_queue_unavailable', __('Could not check queued articles. Please try again.', 'gpt3-ai-content-generator'), ['status' => 500]);
            }
            foreach (array_merge($processed, $queued) as $identifier) {
                $existing[$identifier] = true;
            }
        }
        return $existing;
    }
}
