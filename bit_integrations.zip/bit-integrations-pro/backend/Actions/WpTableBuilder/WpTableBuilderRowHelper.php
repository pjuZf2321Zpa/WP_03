<?php

namespace BitApps\IntegrationsPro\Actions\WpTableBuilder;

use DOMDocument;
use DOMElement;
use DOMXPath;

/**
 * Row-level manipulation of a WP Table Builder table.
 *
 * WP Table Builder stores a table as rendered HTML, not as structured data, so a new
 * row is produced by cloning an existing one and swapping the cell text. Cloning is
 * what keeps the table intact: every data-wptb-* attribute, class and inline style the
 * front-end reconstructor depends on is carried over verbatim. Synthesising the markup
 * by hand would mean reproducing that contract from the outside and re-checking it on
 * every WP Table Builder release.
 */
final class WpTableBuilderRowHelper
{
    /**
     * Append a row to a table's stored markup.
     *
     * @param string $content stored table HTML
     * @param array  $values  cell text, in column order
     *
     * @return null|string updated markup, or null when the table has no row to clone
     */
    public static function appendRow($content, array $values)
    {
        $dom = self::loadDocument($content);

        if (!$dom) {
            return;
        }

        $xpath = new DOMXPath($dom);
        $rows = $xpath->query('//tr');

        // Nothing to clone: an empty table carries no cell markup to copy, and guessing
        // it is exactly what this helper exists to avoid.
        if (!$rows->length) {
            return;
        }

        $template = self::pickTemplateRow($xpath, $rows);

        if (!$template) {
            return;
        }

        $newRow = $template->cloneNode(true);

        $cells = $xpath->query('.//th|.//td', $newRow);

        if (!$cells->length) {
            return;
        }

        foreach ($cells as $index => $cell) {
            self::setCellText($dom, $xpath, $cell, isset($values[$index]) ? $values[$index] : '');
        }

        // A cloned header cell would render a second header mid-table.
        self::demoteHeaderCells($dom, $xpath, $newRow);

        $template->parentNode->appendChild($newRow);

        $table = $xpath->query('//table')->item(0);

        return $table ? $dom->saveHTML($table) : null;
    }

    /**
     * Count the columns in a table, so a row can be rejected before it is written.
     *
     * @param string $content
     *
     * @return int
     */
    public static function columnCount($content)
    {
        $dom = self::loadDocument($content);

        if (!$dom) {
            return 0;
        }

        $xpath = new DOMXPath($dom);
        $firstRow = $xpath->query('//tr')->item(0);

        return $firstRow ? $xpath->query('.//th|.//td', $firstRow)->length : 0;
    }

    /**
     * Pick the row whose layout a new row should copy.
     *
     * The last row is preferred because it carries the table's current data styling,
     * but a table can end in a row that is not shaped like a data row — a colspan
     * footer, a merged summary line. Cloning one of those would silently drop every
     * mapped value past its cell count, so the search walks backwards for the last row
     * that actually has as many cells as the table has columns.
     *
     * @param DOMNodeList $rows
     *
     * @return null|DOMNode
     */
    private static function pickTemplateRow(DOMXPath $xpath, $rows)
    {
        $columnCount = $xpath->query('.//th|.//td', $rows->item(0))->length;

        if (!$columnCount) {
            return;
        }

        for ($index = $rows->length - 1; $index >= 0; $index--) {
            $row = $rows->item($index);

            if ($xpath->query('.//th|.//td', $row)->length === $columnCount) {
                return $row;
            }
        }

        // Only the header matches its own cell count, so it is the one consistent
        // layout available; demoteHeaderCells turns the clone into a data row.
        return $rows->item(0);
    }

    /**
     * Parse stored table markup into a DOM document.
     *
     * @param string $content
     *
     * @return null|DOMDocument
     */
    private static function loadDocument($content)
    {
        if (empty($content) || !class_exists('DOMDocument')) {
            return;
        }

        $dom = new DOMDocument();
        $previous = libxml_use_internal_errors(true);

        // The stored value is a fragment of authored HTML; libxml complains about it
        // routinely and those warnings must not reach the response.
        $loaded = $dom->loadHTML(
            '<?xml encoding="utf-8" ?>' . $content,
            LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD
        );

        libxml_clear_errors();
        libxml_use_internal_errors($previous);

        return $loaded ? $dom : null;
    }

    /**
     * Replace a cell's text while leaving its wrapper markup in place.
     *
     * WP Table Builder puts the visible text inside a .wptb-text-container div; writing
     * over the cell itself would delete that wrapper and the cell would lose its styling.
     *
     * @param DOMNode $cell
     * @param string  $value
     */
    private static function setCellText(DOMDocument $dom, DOMXPath $xpath, $cell, $value)
    {
        $holder = $xpath->query('.//div[contains(@class, "wptb-text-container")]', $cell)->item(0);
        $target = $holder ? $holder : $cell;

        while ($target->firstChild) {
            $target->removeChild($target->firstChild);
        }

        // createTextNode escapes on serialisation, so a submitted value cannot introduce
        // markup into the table.
        $target->appendChild($dom->createTextNode((string) $value));
    }

    /**
     * Convert any th in the cloned row to td.
     *
     * @param DOMNode $row
     */
    private static function demoteHeaderCells(DOMDocument $dom, DOMXPath $xpath, $row)
    {
        foreach (iterator_to_array($xpath->query('.//th', $row)) as $headerCell) {
            $cell = $dom->createElement('td');

            if ($headerCell instanceof DOMElement) {
                foreach (iterator_to_array($headerCell->attributes) as $attribute) {
                    // scope is meaningless on a td and trips accessibility checkers.
                    if ($attribute->nodeName !== 'scope') {
                        $cell->setAttribute($attribute->nodeName, $attribute->nodeValue);
                    }
                }
            }

            while ($headerCell->firstChild) {
                $cell->appendChild($headerCell->firstChild);
            }

            $headerCell->parentNode->replaceChild($cell, $headerCell);
        }
    }
}
