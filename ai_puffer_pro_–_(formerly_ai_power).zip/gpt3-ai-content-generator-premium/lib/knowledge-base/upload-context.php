<?php

namespace WPAICG\Utils;

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

/**
 * Generates context identifiers for paid chat uploads and vector ingestion.
 */
class AIPKit_Identifier_Utils {

    /** Signed upload handles never authorize a different visitor, conversation or chatbot. */
    public static function sign_upload_token(array $payload, array $binding, string $purpose): string
    {
        $claims = ['payload' => $payload, 'binding' => self::upload_binding($binding), 'purpose' => $purpose, 'expires' => time() + DAY_IN_SECONDS];
        $encoded = rtrim(strtr(base64_encode(wp_json_encode($claims)), '+/', '-_'), '=');
        return $encoded . '.' . hash_hmac('sha256', $encoded, wp_salt('auth'));
    }

    /** @return array|\WP_Error */
    public static function verify_upload_token(string $token, array $binding, string $purpose)
    {
        $parts = explode('.', $token);
        if (count($parts) === 2 && strlen($token) <= 16384
            && hash_equals(hash_hmac('sha256', $parts[0], wp_salt('auth')), $parts[1])) {
            $claims = json_decode(base64_decode(strtr($parts[0], '-_', '+/'), true), true);
            if (is_array($claims) && ($claims['purpose'] ?? '') === $purpose
                && (int) ($claims['expires'] ?? 0) > time()
                && hash_equals(self::upload_binding($binding), (string) ($claims['binding'] ?? ''))
                && is_array($claims['payload'] ?? null)) {
                return $claims['payload'];
            }
        }
        return new \WP_Error('chat_upload_context_invalid', __('This file is unavailable for this conversation. Please upload it again.', 'gpt3-ai-content-generator'), ['status' => 403, 'stop_batch' => true]);
    }

    private static function upload_binding(array $binding): string
    {
        $user_id = absint($binding['user_id'] ?? 0);
        return hash_hmac('sha256', wp_json_encode([
            $user_id, $user_id ? '' : (string) ($binding['session_id'] ?? ''),
            absint($binding['bot_id'] ?? 0), (string) ($binding['conversation_uuid'] ?? ''),
        ]), wp_salt('auth'));
    }

    /**
     * Generates a unique identifier string suitable for contexts like
     * OpenAI Vector Store names, Pinecone namespaces, or Qdrant metadata.
     *
     * The generated identifier will be sanitized to be safe for such uses.
     *
     * @param int|null $user_id The user ID, if applicable.
     * @param string|null $session_id The session ID, if applicable (for guests).
     * @param string $prefix A prefix for the identifier (e.g., 'aipkit_chat_file_ctx').
     * @param int $random_length The length of the random suffix.
     * @return string A unique identifier string.
     */
    public static function generate_chat_context_identifier(
        ?int $user_id,
        ?string $session_id,
        string $prefix = 'aipkit_ctx',
        int $random_length = 8
    ): string {
        if ($user_id && $user_id > 0) {
            $identifier_base = "u{$user_id}";
        } elseif (!empty($session_id)) {
            // Sanitize session_id: remove non-alphanumeric and limit length to avoid overly long identifiers
            $sanitized_session_id = preg_replace('/[^a-zA-Z0-9]/', '', $session_id);
            $sanitized_session_id = substr($sanitized_session_id, 0, 20); // Limit length of session part
            $identifier_base = "g_{$sanitized_session_id}";
        } else {
            $identifier_base = "unk"; // Unknown user/session
        }

        $timestamp = time();
        // Generate a short, URL-safe random string
        $random_suffix_chars = '0123456789abcdefghijklmnopqrstuvwxyz';
        $random_suffix = '';
        for ($i = 0; $i < $random_length; $i++) {
            $random_suffix .= $random_suffix_chars[wp_rand(0, strlen($random_suffix_chars) - 1)];
        }

        // Preserve context prefixes and the existing WordPress sanitize_key filter.
        $raw_identifier = strtolower("{$prefix}_{$identifier_base}_{$timestamp}_{$random_suffix}");

        return sanitize_key($raw_identifier);
    }
}
