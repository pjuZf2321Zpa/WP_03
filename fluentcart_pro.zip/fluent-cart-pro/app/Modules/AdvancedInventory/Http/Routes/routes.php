<?php

/**
 * @var $router Router
 */

use FluentCartPro\App\Modules\AdvancedInventory\Http\Controllers\AdvancedInventoryController;
use FluentCart\Framework\Http\Router;

$router->prefix('inventory')->withPolicy('ProductPolicy')->group(function (Router $router) {
    $router->get('stats', [AdvancedInventoryController::class, 'stats'])->meta([
        'permissions' => 'products/view'
    ]);
    $router->get('/', [AdvancedInventoryController::class, 'index'])->meta([
        'permissions' => 'products/view'
    ]);
    $router->get('variants', [AdvancedInventoryController::class, 'variants'])->meta([
        'permissions' => 'products/view'
    ]);
    $router->get('adjustment-history', [AdvancedInventoryController::class, 'adjustmentHistory'])->meta([
        'permissions' => 'products/view'
    ]);
    $router->post('update-stock', [AdvancedInventoryController::class, 'updateStock'])->meta([
        'permissions' => 'products/edit'
    ]);
    $router->post('bulk-update', [AdvancedInventoryController::class, 'bulkUpdate'])->meta([
        'permissions' => 'products/edit'
    ]);
    $router->post('export', [AdvancedInventoryController::class, 'export'])->meta([
        'permissions' => 'products/view'
    ]);
});
