<?php

namespace CustomFacebookFeed\Abilities\Services;

use CustomFacebookFeed\Builder\CFF_Db;
use CustomFacebookFeed\Builder\CFF_Feed_Saver;
use CustomFacebookFeed\Builder\CFF_Feed_Saver_Manager;
use CustomFacebookFeed\CFF_Cache;

if (!defined('ABSPATH')) {
	exit;
}

/**
 * Reads/writes Feed Builder feeds for the Abilities API.
 *
 * Wraps CFF_Db / CFF_Feed_Saver and REDACTS everything an agent must not see:
 * CFF_Feed_Saver::get_feed_settings() hydrates connected sources with the
 * DECRYPTED access token (via SB_Facebook_Data_Encryption), so this service
 * never returns raw source rows.
 *
 * @since 4.13
 */
class CFF_Feed_Settings_Service
{
	const MAX_PER_PAGE = 50;

	/**
	 * Per-feed keys whose change alters which posts are fetched from Facebook.
	 *
	 * @var string[]
	 */
	const RETRIEVAL_KEYS = array('num', 'nummobile', 'feedtype');

	/** Keys never allowed to leak from a hydrated source row. */
	const SOURCE_REDACT_KEYS = array(
		'access_token', 'accesstoken', 'ownaccesstoken', 'pagetoken', 'info', 'error',
	);

	/**
	 * Feed templates the builder ships — the exact `type` values from
	 * CFF_Feed_Builder::get_feed_templates() (what admin/builder/assets/js's
	 * template picker sends back as `feedtemplate`) and checked verbatim by
	 * CFF_Feed_Templates_Settings::get_{timeline,photos,videos}_feedtemplate_settings().
	 * Previously this listed Instagram Feed's `ft_*` template slugs, which this
	 * plugin's own template-settings trait never matches — every ability
	 * create-feed call that requested a template silently fell through to a
	 * bare default feed (SBR-497).
	 *
	 * @var string[]
	 */
	const FEED_TEMPLATES = array(
		'default',
		'simple_masonry',
		'widget',
		'simple_cards',
		'latest_post',
		'showcase_carousel',
		'simple_carousel',
	);

	/**
	 * @param int $page 1-based.
	 * @param int $per_page
	 * @param string $status publish|draft|trash|all (default publish).
	 * @return array{feeds: array, total: int, page: int, per_page: int, total_pages: int}
	 */
	public function list_feeds($page = 1, $per_page = 20, $status = 'publish')
	{
		global $wpdb;

		$page     = max(1, (int) $page);
		$per_page = min(self::MAX_PER_PAGE, max(1, (int) $per_page));
		$offset   = ($page - 1) * $per_page;
		$table    = $wpdb->prefix . 'cff_feeds';

		$status = in_array($status, array('publish', 'draft', 'trash', 'all'), true) ? $status : 'publish';
		if ($status === 'all') {
			// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- table name is $wpdb->prefix + constant.
			$sql = $wpdb->prepare(
				"SELECT id, feed_name, feed_title, settings, status, last_modified
				FROM {$table} ORDER BY id ASC LIMIT %d OFFSET %d",
				$per_page,
				$offset
			);
		} else {
			// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- table name is $wpdb->prefix + constant.
			$sql = $wpdb->prepare(
				"SELECT id, feed_name, feed_title, settings, status, last_modified
				FROM {$table} WHERE status = %s ORDER BY id ASC LIMIT %d OFFSET %d",
				$status,
				$per_page,
				$offset
			);
		}
		$rows = $wpdb->get_results($sql, ARRAY_A);

		$feeds = array();
		foreach ((array) $rows as $row) {
			$settings = json_decode($row['settings'], true);
			$settings = is_array($settings) ? $settings : array();
			$feeds[]  = array(
				'id'            => (int) $row['id'],
				'feed_name'     => (string) $row['feed_name'],
				'feed_title'    => (string) $row['feed_title'],
				'feedtype'      => isset($settings['feedtype']) ? (string) $settings['feedtype'] : 'timeline',
				'feedlayout'    => isset($settings['feedlayout']) ? (string) $settings['feedlayout'] : 'list',
				'status'        => (string) $row['status'],
				'last_modified' => (string) $row['last_modified'],
				'shortcode'     => '[custom-facebook-feed feed=' . (int) $row['id'] . ']',
			);
		}

		if ($status === 'all') {
			$total = CFF_Db::feeds_count();
		} else {
			// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- table name is $wpdb->prefix + constant.
			$total = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$table} WHERE status = %s", $status));
		}

		return array(
			'feeds'       => $feeds,
			'total'       => $total,
			'page'        => $page,
			'per_page'    => $per_page,
			'total_pages' => (int) ceil($total / $per_page),
		);
	}

	/**
	 * @param int $feed_id
	 * @return array|null Null when the feed does not exist.
	 */
	public function get_feed($feed_id)
	{
		$feed_id = (int) $feed_id;
		if ($feed_id <= 0) {
			return null;
		}

		$saver    = new CFF_Feed_Saver($feed_id);
		$settings = $saver->get_feed_settings();
		if (!is_array($settings)) {
			return null;
		}
		$db = $saver->get_feed_db_data();

		$defaults = CFF_Feed_Saver::settings_defaults();
		$schema   = CFF_Settings_Schema::feed_settings();
		$out      = array();
		foreach ($schema as $key => $def) {
			$out[$key] = CFF_Settings_Schema::cast_out(
				$def,
				isset($settings[$key]) ? $settings[$key] : null,
				isset($defaults[$key]) ? $defaults[$key] : null
			);
		}
		$out['feed_name'] = isset($db['feed_name']) ? (string) $db['feed_name'] : $out['feed_name'];

		list($sources, $warnings) = $this->resolve_raw_sources($feed_id);

		return array(
			'id'            => $feed_id,
			'feed_title'    => isset($db['feed_title']) ? (string) $db['feed_title'] : '',
			'status'        => isset($db['status']) ? (string) $db['status'] : '',
			'last_modified' => isset($db['last_modified']) ? (string) $db['last_modified'] : '',
			'shortcode'     => '[custom-facebook-feed feed=' . $feed_id . ']',
			'sources'       => $sources,
			'warnings'      => $warnings,
			'settings'      => $out,
		);
	}

	/**
	 * Keep only what identifies the account. Never tokens, `info`, or errors.
	 *
	 * @param array $sources
	 * @return array<int, array{username: string, account_type: string}>
	 */
	private function redact_sources($sources)
	{
		$out = array();
		foreach ((array) $sources as $source) {
			if (!is_array($source)) {
				continue;
			}
			foreach (self::SOURCE_REDACT_KEYS as $redacted) {
				if (array_key_exists($redacted, $source)) {
					unset($source[$redacted]);
				}
			}
			$out[] = array(
				'username'     => isset($source['username']) ? (string) $source['username'] : '',
				'account_type' => isset($source['account_type']) ? (string) $source['account_type'] : '',
			);
		}
		return $out;
	}

	/**
	 * Resolve `get-feed`'s `sources` from the RAW `cff_feeds.settings` row,
	 * never from `CFF_Feed_Saver::get_feed_settings()`'s hydrated array.
	 *
	 * `get_feed_settings()` is the render path's hydrator. It used to fall
	 * back to `CFF_Db::source_query()` with NO arguments when a feed's saved
	 * source id no longer resolved, which returned whichever connected account
	 * the query happened to return first, and `get_feed()` reported that
	 * unrelated account's username/type as if it were this feed's source
	 * (AgDR-9004 finding L2). The saver no longer does that (SMASH-2625): an
	 * unresolved feed gets an empty token, or keeps its own when it had no
	 * `sources`. This method still reads the raw row so that what it reports
	 * is only what the feed itself persisted. An agent acting
	 * on that misreport could re-point or delete the wrong source. This
	 * reads the feed's OWN persisted source ids and reports only what
	 * genuinely resolves; anything that doesn't resolve is surfaced as an
	 * explicit warning instead of silently substituted.
	 *
	 * @param int $feed_id
	 * @return array{0: array<int, array{username: string, account_type: string}>, 1: string[]}
	 */
	private function resolve_raw_sources($feed_id)
	{
		$rows = CFF_Db::feeds_query(array('id' => $feed_id));
		$raw  = (!empty($rows) && isset($rows[0]['settings'])) ? json_decode($rows[0]['settings'], true) : array();
		$raw  = is_array($raw) ? $raw : array();

		$raw_sources = isset($raw['sources']) ? $raw['sources'] : array();
		$ids         = array();
		if (is_array($raw_sources)) {
			foreach ($raw_sources as $source) {
				$id = is_array($source) ? (isset($source['account_id']) ? $source['account_id'] : null) : $source;
				if ($id !== null && $id !== '') {
					$ids[] = $id;
				}
			}
		} elseif (is_scalar($raw_sources) && $raw_sources !== '') {
			$ids[] = $raw_sources;
		}

		if (empty($ids)) {
			return array(array(), array());
		}

		// Rex round 2, finding B: CFF_Db::source_query()'s WHERE clause is
		// `account_id IN (...) AND ((privilege = %s AND account_type =
		// 'page') OR account_type = 'group')` — a page-type source only
		// matches when $args['privilege'] equals ITS OWN stored privilege
		// exactly ('' for an ordinary page, 'events' for an events page).
		// Calling source_query() with no `privilege` key defaults the bound
		// value to '', so an events feed's page source (privilege='events')
		// never matches and every one of its sources was reported
		// "no longer connected" even when it was. Determine the privilege
		// from the feed's OWN raw settings the exact same way
		// CFF_Feed_Saver::get_feed_settings() does, so this lookup matches
		// what the render path would actually resolve.
		$source_args     = array('id' => $ids);
		$is_events_feed  = (
			isset($raw['type'])
			&& $raw['type'] === 'events'
			&& isset($raw['eventsource'])
			&& $raw['eventsource'] === 'eventspage'
		) || (isset($raw['feedtype']) && $raw['feedtype'] === 'events');
		if ($is_events_feed) {
			$source_args['privilege'] = 'events';
		}

		$found_rows = CFF_Db::source_query($source_args);
		$found_rows = is_array($found_rows) ? $found_rows : array();

		// Mirror CFF_Feed_Saver::get_feed_settings()'s retry: when the
		// privilege-qualified query comes back empty, flip the privilege
		// and try once more before giving up on a source. The saver used
		// to follow that with a CFF_Db::source_query() call with no
		// arguments, which returned whichever connected account came back
		// first (AgDR-9004 finding L2); SMASH-2625 removed it there. This
		// method never had it, and a source that still doesn't resolve
		// after the privilege flip is reported as "no longer connected"
		// below, not swapped for an unrelated account.
		if (empty($found_rows)) {
			$retry_args = $source_args;
			if (isset($retry_args['privilege'])) {
				unset($retry_args['privilege']);
			} else {
				$retry_args['privilege'] = 'events';
			}
			$found_rows = CFF_Db::source_query($retry_args);
			$found_rows = is_array($found_rows) ? $found_rows : array();
		}

		$found_ids = array();
		foreach ($found_rows as $row) {
			$found_ids[] = isset($row['account_id']) ? stripslashes($row['account_id']) : null;
		}

		$warnings = array();
		foreach ($ids as $id) {
			if (!in_array((string) $id, $found_ids, true)) {
				$warnings[] = sprintf(
					/* translators: %s: the feed's stored source id */
					__('Source %s is no longer connected and was left out of "sources".', 'custom-facebook-feed'),
					(string) $id
				);
			}
		}

		$unslashed_rows = array_map(
			function ($row) {
				return array(
					'username'     => isset($row['username']) ? stripslashes($row['username']) : '',
					'account_type' => isset($row['account_type']) ? stripslashes($row['account_type']) : '',
				);
			},
			$found_rows
		);

		return array($this->redact_sources($unslashed_rows), $warnings);
	}

	/**
	 * Apply a partial update to one feed's settings.
	 *
	 * CFF_Feed_Saver::set_data()/update_or_insert() REPLACES the stored
	 * settings JSON with whatever was passed, so we merge into the RAW stored
	 * row (never the token-hydrated get_feed_settings() array), run the same
	 * saver the Feed Builder uses, and clear the feed cache exactly like
	 * CFF_Feed_Saver_Manager::builder_update() does.
	 *
	 * @param int      $feed_id
	 * @param array    $partial key => value, already schema-validated by core.
	 * @param callable $tier_available fn(string $feature): bool
	 * @return array{feed_id: int, updated: string[], ignored: object, warnings: string[]}|\WP_Error|null
	 *         Null when the feed does not exist. WP_Error also covers an
	 *         incomplete coupled-key write (e.g. colorpalette: custom with no
	 *         custom colours) — see CFF_Settings_Schema::COUPLED_GROUPS.
	 */
	public function update_feed($feed_id, array $partial, $tier_available)
	{
		$feed_id = (int) $feed_id;
		if ($feed_id <= 0) {
			return null;
		}
		$rows = CFF_Db::feeds_query(array('id' => $feed_id));
		if (empty($rows)) {
			return null;
		}
		$row    = $rows[0];
		$stored = json_decode($row['settings'], true);
		$stored = is_array($stored) ? $stored : array();

		$schema   = CFF_Settings_Schema::feed_settings();
		$writable = CFF_Settings_Schema::writable($schema);
		$updated  = array();
		$ignored  = array();
		$clean    = array();
		$new_name = null;

		foreach ($partial as $key => $value) {
			if (!isset($schema[$key])) {
				$ignored[$key] = 'unknown_setting';
				continue;
			}
			if (!isset($writable[$key])) {
				$ignored[$key] = 'read_only';
				continue;
			}
			if (isset($schema[$key]['tier']) && !call_user_func($tier_available, $schema[$key]['tier'])) {
				$ignored[$key] = 'feature_unavailable';
				continue;
			}
			// Per-value gate (Hakim T1): e.g. feedlayout's tier_values only
			// restricts the 'carousel' value — list/grid/masonry pass
			// straight through regardless of tier. `$value` is unvalidated
			// agent input at this point, so guard is_scalar() first — a
			// non-scalar (array/object) used as an array key would trigger
			// an "Illegal offset type" warning from isset() (harmless, but
			// noisy) instead of just falling through to validate_in(),
			// which already rejects non-scalar values with a proper error.
			if (
				is_scalar($value)
				&& isset($schema[$key]['tier_values'][$value])
				&& !call_user_func($tier_available, $schema[$key]['tier_values'][$value])
			) {
				$ignored[$key] = 'feature_unavailable';
				continue;
			}
			$v = CFF_Settings_Schema::validate_in($schema[$key], $value, $key);
			if (is_wp_error($v)) {
				return $v;
			}
			if ($key === 'feed_name') {
				$new_name  = $v;
				$updated[] = $key;
				continue;
			}
			$clean[$key] = $this->to_native($schema[$key], $v);
		}

		if (empty($clean) && $new_name === null) {
			return array(
				'feed_id'  => $feed_id,
				'updated'  => array(),
				'ignored'  => (object) $ignored,
				'warnings' => array(),
			);
		}

		$merged = array_merge($stored, $clean);

		$coupling_error = $this->check_coupled_groups($clean, $merged);
		if (is_wp_error($coupling_error)) {
			return $coupling_error;
		}

		$saver = new CFF_Feed_Saver($feed_id);
		$saver->set_feed_name($new_name !== null ? $new_name : (string) $row['feed_name']);
		$saver->set_data($merged);
		// CFF_Db::feeds_update() returns $wpdb->update(): rows changed, or false on
		// error. An idempotent replay can legitimately change 0 rows.
		if ($saver->update_or_insert() === false) {
			return new \WP_Error(
				'cff_feed_save_failed',
				__('The feed could not be saved.', 'custom-facebook-feed'),
				array('status' => 500)
			);
		}
		$updated = array_merge($updated, array_keys($clean));

		if (class_exists('\CustomFacebookFeed\CFF_Cache')) {
			$cache = new CFF_Cache($feed_id);
			// 'all' only empties the rendered/header cache rows (local, cheap) so the
			// change shows immediately. 'posts' forces a Facebook API refetch, so it is
			// limited to keys that change WHAT is fetched — otherwise an agent looping
			// over cosmetic keys would burn Graph API quota.
			$cache->clear('all');
			if (array_intersect(self::RETRIEVAL_KEYS, array_keys($clean))) {
				$cache->clear('posts');
			}
		}

		/**
		 * Fires after an AI agent updated a feed through the Abilities API.
		 *
		 * @param int      $feed_id
		 * @param string[] $updated Keys that were written.
		 */
		do_action('cff_abilities_feed_settings_updated', $feed_id, $updated);

		return array(
			'feed_id'  => $feed_id,
			'updated'  => $updated,
			'ignored'  => (object) $ignored,
			'warnings' => array(),
		);
	}

	/**
	 * Create a feed the way the builder's new_insert path does: template
	 * defaults + validated quick settings + resolved sources.
	 *
	 * @param array    $input {feed_name?, feedtemplate?, sources?, settings?}
	 * @param callable $tier_available fn(string $feature): bool
	 * @return array|\WP_Error
	 */
	public function create_feed(array $input, $tier_available)
	{
		// CFF_Feed_Templates_Settings dispatches on `feedtype` (timeline/events →
		// timeline templates; photos/singlealbum; videos/albums), exactly as the
		// builder's new_insert path in CFF_Feed_Saver_Manager sets it before
		// expanding the template. Keying this `type` instead left the expansion a
		// silent no-op (SBR-497). `feedtemplate` defaults to 'default' like the
		// builder so the expansion always runs and the stored row carries the slug
		// the customizer displays.
		$settings_data = array(
			'feedtype'     => 'timeline',
			'feedtemplate' => !empty($input['feedtemplate']) ? (string) $input['feedtemplate'] : 'default',
		);

		if (
			trait_exists('\CustomFacebookFeed\Admin\Traits\CFF_Feed_Templates_Settings')
			&& method_exists(CFF_Feed_Saver_Manager::class, 'get_feed_settings_by_feed_templates')
		) {
			$settings_data = CFF_Feed_Saver_Manager::get_feed_settings_by_feed_templates($settings_data);
		}

		// Licence tiers on the abilities write path (cross-cutting fix 1): the
		// template expansion above can set fields the schema tier-gates —
		// e.g. simple_carousel/showcase_carousel set carouselheight,
		// carouseldesktop_cols, and carouselmobile_cols, which require the
		// advanced_feed_layouts feature. The per-key tier check further down
		// only runs over keys the agent explicitly named in `settings`; it
		// never covered what the TEMPLATE just wrote, so naming a template
		// was a way around the tier gate entirely. Re-run the same gate over
		// every key the template touched, falling back to the plugin's own
		// default (never inventing one) and recording a warning. Extracted
		// to a static method so tests/check-create-feed-tier-gate.php exercises
		// this EXACT code path instead of a duplicated copy of the loop.
		$template_warnings = array();
		list($settings_data, $template_warnings) = self::apply_template_tier_gate(
			$settings_data,
			$tier_available
		);

		$ignored = array();
		$updated = array();
		if (!empty($input['settings']) && is_array($input['settings'])) {
			$schema   = CFF_Settings_Schema::feed_settings();
			$writable = CFF_Settings_Schema::writable($schema);
			foreach ($input['settings'] as $key => $value) {
				if ($key === 'feed_name' || !isset($writable[$key])) {
					$ignored[$key] = isset($schema[$key]) ? 'read_only' : 'unknown_setting';
					continue;
				}
				if (isset($schema[$key]['tier']) && !call_user_func($tier_available, $schema[$key]['tier'])) {
					$ignored[$key] = 'feature_unavailable';
					continue;
				}
				// Per-value gate (Hakim T1): e.g. feedlayout's tier_values
				// only restricts the 'carousel' value — list/grid/masonry
				// pass straight through regardless of tier. `$value` is
				// unvalidated agent input, so guard is_scalar() first (see
				// the matching comment on the sibling gate above).
				if (
					is_scalar($value)
					&& isset($schema[$key]['tier_values'][$value])
					&& !call_user_func($tier_available, $schema[$key]['tier_values'][$value])
				) {
					$ignored[$key] = 'feature_unavailable';
					continue;
				}
				$v = CFF_Settings_Schema::validate_in($schema[$key], $value, $key);
				if (is_wp_error($v)) {
					return $v;
				}
				$settings_data[$key] = $this->to_native($schema[$key], $v);
				$updated[]           = $key;
			}

			$coupling_error = $this->check_coupled_groups($settings_data, $settings_data);
			if (is_wp_error($coupling_error)) {
				return $coupling_error;
			}
		}

		$source_usernames = array();
		if (!empty($input['sources']) && is_array($input['sources'])) {
			$resolved = (new CFF_Source_Service())->resolve_sources($input['sources']);
			if (!empty($resolved['missing'])) {
				return new \WP_Error(
					'cff_source_not_found',
					sprintf(
						/* translators: %s: comma-separated account names */
						__(
							'These accounts are not connected to this site: %s. '
							. 'Use get-connect-url to connect one first.',
							'custom-facebook-feed'
						),
						implode(', ', $resolved['missing'])
					),
					array('status' => 404)
				);
			}
			// The authoritative persisted source list is `sources` — a flat list of
			// account_id strings, exactly as CFF_Feed_Saver_Manager builds it
			// (inc/Builder/CFF_Feed_Saver_Manager.php:676). `id` is a DERIVED legacy
			// scalar that CFF_Feed_Saver::get_feed_settings() overwrites on read
			// (inc/Builder/CFF_Feed_Saver.php:428) — writing it here does nothing
			// for hydration and, for 2+ sources, stores an un-collapsed array that
			// trim()s fatally on PHP 8 at render time (inc/CFF_Utils.php:937).
			$settings_data['sources'] = $resolved['ids'];
			foreach ($resolved['details'] as $d) {
				$source_usernames[] = $d['username'];
			}
		}
		// A sourceless feed (no connected page yet) is intentionally allowed —
		// the same way the builder lets you create a feed then connect later.

		$feed_name = !empty($input['feed_name'])
			? sanitize_text_field((string) $input['feed_name'])
			: CFF_Db::feeds_query_name(
				!empty($source_usernames) ? $source_usernames[0] : __('Facebook Feed', 'custom-facebook-feed')
			);

		// CFF_Db::feeds_insert() returns $wpdb->insert_id, but on a site's VERY
		// FIRST feed, update_option('cff_pro_first_feed_created', ...) falls
		// through to add_option() — an INSERT into wp_options — which clobbers
		// $wpdb->insert_id before feeds_insert() reads it (pre-existing plugin
		// bug, confirmed against inc/Builder/CFF_Db.php; tracked separately —
		// not patched here since it also affects the native builder's first-feed
		// path). Pre-setting the option here, before invoking the saver, means
		// that branch never runs during an ability call, so get_feed_id() below
		// is always the real feeds-table id.
		if (!get_option('cff_pro_first_feed_created', false)) {
			update_option('cff_pro_first_feed_created', true);
		}

		$saver = new CFF_Feed_Saver(false);
		$saver->set_feed_name($feed_name);
		$saver->set_data($settings_data);
		if (!$saver->update_or_insert()) {
			return new \WP_Error(
				'cff_feed_save_failed',
				__('The feed could not be created.', 'custom-facebook-feed'),
				array('status' => 500)
			);
		}
		$feed_id = (int) $saver->get_feed_id();

		/** This action is documented in CFF_Feed_Settings_Service::update_feed(). */
		do_action('cff_abilities_feed_settings_updated', $feed_id, $updated);

		return array(
			'feed_id'   => $feed_id,
			'feed_name' => $feed_name,
			'shortcode' => '[custom-facebook-feed feed=' . $feed_id . ']',
			'updated'   => $updated,
			'ignored'   => (object) $ignored,
			'warnings'  => $template_warnings,
		);
	}

	/**
	 * Re-run the tier gate over every key a template expansion just wrote,
	 * clamping any gated key/value back to the plugin's own default and
	 * recording a warning (cross-cutting fix 1 — see the call site in
	 * create_feed()). Extracted to a static method (rather than left
	 * inline) specifically so tests/check-create-feed-tier-gate.php can
	 * call this SAME code path instead of maintaining its own duplicated
	 * copy of the loop.
	 *
	 * @param array    $settings_data  Template-expanded settings.
	 * @param callable $tier_available fn(string $feature): bool
	 * @return array{0: array, 1: string[]} [$settings_data (clamped), $warnings]
	 */
	public static function apply_template_tier_gate(array $settings_data, $tier_available)
	{
		$template_warnings = array();
		$tier_schema        = CFF_Settings_Schema::feed_settings();
		$tier_defaults      = CFF_Feed_Saver::settings_defaults();

		foreach ($tier_schema as $tier_key => $tier_def) {
			if (!array_key_exists($tier_key, $settings_data)) {
				continue;
			}

			// Whole-key gate (carouselheight, carouseldesktop_cols, ...): only
			// fires for keys a template ACTUALLY SETS, which today is only the
			// carousel templates — the default template never touches these
			// keys, so a default-tier create-feed on the lowest tier never
			// warns here. Keep it that way: this loop must never warn just
			// because a preset left a tier-gated key at ITS OWN default: a
			// gate belongs on a value that ENABLES the feature, not on a key
			// merely being present with a non-feature-requiring value.
			if (isset($tier_def['tier']) && !call_user_func($tier_available, $tier_def['tier'])) {
				$settings_data[$tier_key] = isset($tier_defaults[$tier_key]) ? $tier_defaults[$tier_key] : null;
				$template_warnings[]      = sprintf(
					/* translators: 1: template slug, 2: setting key, 3: licence feature */
					__(
						'Template "%1$s" sets %2$s, which requires a plan with %3$s; '
							. 'used the default instead.',
						'custom-facebook-feed'
					),
					$settings_data['feedtemplate'],
					$tier_key,
					$tier_def['tier']
				);
				continue;
			}

			// Per-VALUE gate (feedlayout: only 'carousel' requires a tier).
			// Only the templates that set feedlayout to the gated value ever
			// reach this branch — the default template sets feedlayout='list',
			// which isn't in tier_values at all, so this is a no-op for it.
			// is_scalar() guards the array-key lookup below in case a
			// template ever expands a key to a non-scalar value.
			if (
				is_scalar($settings_data[$tier_key])
				&& isset($tier_def['tier_values'][$settings_data[$tier_key]])
				&& !call_user_func($tier_available, $tier_def['tier_values'][$settings_data[$tier_key]])
			) {
				$gated_value              = $settings_data[$tier_key];
				$settings_data[$tier_key] = isset($tier_defaults[$tier_key]) ? $tier_defaults[$tier_key] : null;
				$template_warnings[]      = sprintf(
					/* translators: 1: template slug, 2: setting key, 3: gated value, 4: licence feature */
					__(
						'Template "%1$s" sets %2$s to "%3$s", which requires a plan with %4$s; '
							. 'used the default instead.',
						'custom-facebook-feed'
					),
					$settings_data['feedtemplate'],
					$tier_key,
					$gated_value,
					$tier_def['tier_values'][$gated_value]
				);
			}
		}

		return array($settings_data, $template_warnings);
	}

	/**
	 * Attach already-connected accounts to a feed (replaces the source list).
	 *
	 * @param int      $feed_id
	 * @param string[] $handles usernames or account ids.
	 * @return array|\WP_Error|null Null when the feed does not exist.
	 */
	public function set_feed_sources($feed_id, array $handles)
	{
		$feed_id = (int) $feed_id;
		$rows    = CFF_Db::feeds_query(array('id' => $feed_id));
		if ($feed_id <= 0 || empty($rows)) {
			return null;
		}
		$resolved = (new CFF_Source_Service())->resolve_sources($handles);
		if (!empty($resolved['missing'])) {
			return new \WP_Error(
				'cff_source_not_found',
				sprintf(
					/* translators: %s: comma-separated account names */
					__(
						'These accounts are not connected to this site: %s. '
						. 'Use get-connect-url to connect one first.',
						'custom-facebook-feed'
					),
					implode(', ', $resolved['missing'])
				),
				array('status' => 404)
			);
		}
		if (empty($resolved['ids'])) {
			return new \WP_Error(
				'cff_invalid_value',
				__('At least one connected account is required.', 'custom-facebook-feed'),
				array('status' => 400)
			);
		}

		$stored = json_decode($rows[0]['settings'], true);
		$stored = is_array($stored) ? $stored : array();
		// `sources` is the authoritative persisted source list (see the identical
		// note in create_feed() above) — `id` is a derived legacy scalar that
		// get_feed_settings() overwrites on read and never actually consults on
		// write, so writing it here was a silent no-op: the feed's real source
		// list was never touched. CFF_Feed_Saver::format_settings() collapses a
		// single-element `sources` list to its scalar element on save; passing
		// the resolved array through unchanged is safe — the saver performs the
		// collapse itself.
		$stored['sources'] = $resolved['ids'];

		$saver = new CFF_Feed_Saver($feed_id);
		$saver->set_feed_name((string) $rows[0]['feed_name']);
		$saver->set_data($stored);
		if ($saver->update_or_insert() === false) {
			return new \WP_Error(
				'cff_feed_save_failed',
				__('The feed could not be saved.', 'custom-facebook-feed'),
				array('status' => 500)
			);
		}

		if (class_exists('\CustomFacebookFeed\CFF_Cache')) {
			$cache = new CFF_Cache($feed_id);
			$cache->clear('all');
			$cache->clear('posts'); // source change always alters what is fetched.
		}

		/** This action is documented in CFF_Feed_Settings_Service::update_feed(). */
		do_action('cff_abilities_feed_settings_updated', $feed_id, array('sources'));

		return array(
			'feed_id' => $feed_id,
			'sources' => array_map(
				function ($d) {
					return $d['username'];
				},
				$resolved['details']
			),
		);
	}

	/**
	 * Re-encode a validated value into the shape settings_defaults() expects
	 * for that key (booleans only — see CFF_Settings_Schema::encode_bool()).
	 *
	 * @param array $def
	 * @param mixed $v
	 * @return mixed
	 */
	private function to_native(array $def, $v)
	{
		if ($def['type'] === 'boolean') {
			return CFF_Settings_Schema::encode_bool($v, $def);
		}
		return is_scalar($v) ? (string) $v : $v;
	}

	/**
	 * Refuse a write that sets a coupled trigger key (colorpalette, dateformat)
	 * to its "requires companions" value without those companions resolving to
	 * a real value — either in this same write or already stored. Without this,
	 * an agent can set `colorpalette: custom` (A4) or `dateformat: custom` (A6)
	 * and land the feed in a state it can never see is incomplete: the
	 * companion colour/format keys stay blank and the feed renders with
	 * whatever CFF falls back to for an unset custom colour/format, with no
	 * signal that anything is wrong (AgDR-0504 requirement 2 — "refuses an
	 * incomplete pair", same spirit as Twitter's set-feed-type-and-terms).
	 *
	 * @param array $clean  Keys being written THIS call (already validated).
	 * @param array $merged Resulting settings row (stored merged with $clean).
	 * @return \WP_Error|null
	 */
	private function check_coupled_groups(array $clean, array $merged)
	{
		foreach (CFF_Settings_Schema::COUPLED_GROUPS as $trigger_key => $group) {
			if (!isset($clean[$trigger_key]) || $clean[$trigger_key] !== $group['trigger']) {
				continue; // Trigger not being set to its coupled value THIS call — nothing to enforce here.
			}
			$missing = array();
			foreach ($group['requires'] as $companion) {
				$value = isset($merged[$companion]) ? $merged[$companion] : '';
				$value = is_scalar($value) ? CFF_Settings_Schema::normalize_color((string) $value) : '';
				if ($value === '') {
					$missing[] = $companion;
				}
			}
			if (!empty($missing)) {
				return new \WP_Error(
					'cff_incomplete_setting',
					sprintf(
						/* translators: 1: trigger key, 2: trigger value, 3: comma-separated companion keys */
						__(
							'Setting %1$s to "%2$s" also requires: %3$s. Include them in the same write.',
							'custom-facebook-feed'
						),
						$trigger_key,
						$group['trigger'],
						implode(', ', $missing)
					),
					array('status' => 400)
				);
			}
		}
		return null;
	}
}
