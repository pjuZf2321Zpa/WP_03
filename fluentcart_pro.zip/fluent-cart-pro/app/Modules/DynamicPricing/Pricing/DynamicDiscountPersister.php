<?php

namespace FluentCartPro\App\Modules\DynamicPricing\Pricing;

use FluentCart\App\Models\Cart;
use FluentCart\Framework\Support\Arr;

/**
 * Writes rule discounts into the saved cart at place-order time.
 *
 * The checkout page computes rule discounts on a throwaway copy of cart_data
 * (Cart::getEstimatedTotal()), but the order is built from the saved
 * cart_data. This listener bridges the two the way coupons do in
 * Cart::reValidateCoupons(): take back what it wrote last time, apply fresh,
 * save once.
 *
 * @package FluentCartPro\App\Modules\DynamicPricing
 *
 * @version 1.0.0
 */
class DynamicDiscountPersister
{
    /**
     * checkout_data key holding what this class added to each item's
     * manual_discount, by item key — the counterpart of the coupons'
     * `__per_coupon_discounts`. It is what makes the write reversible.
     */
    const BOOKKEEPING_KEY = '__dynamic_pricing_discounts';

    /**
     * checkout_data key holding what each rule took, one entry per rule. The
     * amounts are known while the cart is priced but the order does not exist
     * yet, so they wait here until it does.
     */
    const APPLIED_KEY = '__dynamic_pricing_applied';

    public function register()
    {
        add_action('fluent_cart/checkout/before_order_processing', [$this, 'persist']);

        /*
         * A persisted cart that comes back to checkout (failed payment, back
         * button) would be discounted a second time by the display filter on
         * top of the saved cents. Priority 5, so the withdrawal lands before
         * TaxModule (10) recalculates on these items.
         */
        add_action('fluent_cart/cart/cart_data_items_updated', [$this, 'release'], 5);
    }

    /**
     * Put a persisted cart back to its live-display state.
     *
     * Does nothing unless persist() has written to this cart, so of the many
     * places the hook fires, only a cart carrying saved rule discounts is
     * touched — and only once, since the withdrawal empties the bookkeeping.
     *
     * @param array $data ['cart' => Cart]
     * @return void
     */
    public function release($data)
    {
        $cart = Arr::get((array)$data, 'cart');

        if (!$cart instanceof Cart) {
            return;
        }

        if (!Arr::get($cart->checkout_data, self::BOOKKEEPING_KEY)) {
            return;
        }

        $cart->cart_data = $this->withdrawOwnDiscounts($cart);

        $checkoutData = $cart->checkout_data;
        unset($checkoutData[self::BOOKKEEPING_KEY]);
        $cart->checkout_data = $checkoutData;

        $cart->save();
    }

    /**
     * Reset → apply → save, once per place-order.
     *
     * @param array $data ['cart' => Cart]
     * @return void
     */
    public function persist($data)
    {
        $cart = Arr::get((array)$data, 'cart');

        if (!$cart instanceof Cart || !is_array($cart->cart_data) || !$cart->cart_data) {
            return;
        }

        $items = $this->withdrawOwnDiscounts($cart);

        // The same filter the checkout display uses, so the order carries
        // exactly the discount the customer saw.
        $discounted = apply_filters('fluent_cart/cart/item_dynamic_discount', $items, [
            'cart' => $cart,
        ]);

        $ours = [];
        foreach ((array)$discounted as $key => $item) {
            $before = (int)Arr::get((array)Arr::get($items, $key, []), 'manual_discount', 0);
            $delta = (int)Arr::get((array)$item, 'manual_discount', 0) - $before;

            if ($delta > 0) {
                $ours[$key] = $delta;
            }
        }

        $hadPrevious = (bool)Arr::get($cart->checkout_data, self::BOOKKEEPING_KEY);

        // Nothing written before, nothing to write now — leave the cart alone.
        if (!$ours && !$hadPrevious) {
            return;
        }

        $cart->cart_data = $ours ? $discounted : $items;

        $checkoutData = is_array($cart->checkout_data) ? $cart->checkout_data : [];
        $checkoutData[self::BOOKKEEPING_KEY] = $ours;
        $checkoutData[self::APPLIED_KEY] = $this->appliedRules();
        $cart->checkout_data = $checkoutData;

        $cart->save();
    }

    /**
     * What each rule took, shaped for the audit row the order will hold.
     *
     * The rules were run by the filter above; this asks what they did rather
     * than working it out again. Amounts stay positive here — the recorder
     * applies the sign the schema wants.
     *
     * @return array
     */
    protected function appliedRules(): array
    {
        $rows = [];

        foreach ((array)apply_filters('fluent_cart/dynamic_pricing/last_applied_rules', []) as $rule) {
            $rows[] = [
                'rule_id'           => (int)Arr::get($rule, 'rule_id'),
                'rule_type'         => (string)Arr::get($rule, 'rule_type', ''),
                'rule_name'         => (string)Arr::get($rule, 'rule_name', ''),
                'adjustment_type'   => 'discount',
                'adjustment_amount' => (int)Arr::get($rule, 'amount', 0),
            ];
        }

        return $rows;
    }

    /**
     * Take back exactly the cents this class saved last time.
     *
     * Only the bookkeeping amounts come off manual_discount, so genuine
     * manual discounts — renewal flows set them — are untouched. Running it
     * with empty bookkeeping changes nothing, which is what makes persist()
     * safe to run again on a double submit or a failed-payment retry.
     *
     * @param Cart $cart
     * @return array The cart items with this class's cents removed.
     */
    public function withdrawOwnDiscounts(Cart $cart): array
    {
        $items = is_array($cart->cart_data) ? $cart->cart_data : [];
        $map = (array)Arr::get($cart->checkout_data, self::BOOKKEEPING_KEY, []);

        foreach ($map as $key => $cents) {
            if (!isset($items[$key])) {
                continue;
            }

            $item = (array)$items[$key];

            $subtotal = (int)Arr::get($item, 'subtotal', 0);
            $manual = max(0, (int)Arr::get($item, 'manual_discount', 0) - (int)$cents);
            $coupon = (int)Arr::get($item, 'coupon_discount', 0);
            $total = min($manual + $coupon, $subtotal);

            $item['manual_discount'] = $manual;
            $item['discount_total'] = $total;
            $item['line_total'] = $subtotal - $total;

            $items[$key] = $item;
        }

        return $items;
    }
}
