<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Core\Util\Hooks;
use BitApps\IntegrationsPro\Triggers\B2BKing\B2BKingController;

Hooks::add('b2bking_account_approved_finish', [B2BKingController::class, 'handleAccountApproved'], 10, 1);
Hooks::add('b2bking_user_group_updated', [B2BKingController::class, 'handleUserGroupUpdated'], 10, 3);
Hooks::add('b2bking_new_message', [B2BKingController::class, 'handleNewMessage'], 10, 4);
