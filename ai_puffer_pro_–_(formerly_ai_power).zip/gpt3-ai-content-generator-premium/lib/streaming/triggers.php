<?php

namespace WPAICG\Lib\Streaming;

use WP_Error;
use WPAICG\Chat\Storage\LogStorage;
use WPAICG\Core\Stream\Formatter\SSEResponseFormatter;
use WPAICG\Core\Stream\Processor\SSEStreamProcessor;
use WPAICG\Lib\Chat\Triggers\AIPKit_Trigger_Storage;
use WPAICG\Lib\Chat\Triggers\AIPKit_Trigger_Manager;

if (!defined('ABSPATH')) {
    exit;
}

/** Paid trigger dispatch and control responses for an SSE request. */
final class TriggerHandler
{
    private $enabled;

    public function __construct()
    {
        $this->enabled = class_exists('\WPAICG\aipkit_dashboard') && \WPAICG\aipkit_dashboard::is_pro_plan();
    }

    public function component_error(array $get_data, string $message): void
    {
        $this->dispatch_error($get_data, 'sse_component_not_ready', $message, [
            'module' => 'chat_stream_handler', 'operation' => 'initialize_sse_components',
        ]);
    }

    public function request_error(array $get_data, WP_Error $error): void
    {
        $data = $error->get_error_data() ?: [];
        $this->dispatch_error($get_data, $error->get_error_code(), $error->get_error_message(), [
            'module' => $data['failed_module'] ?? 'chat_stream_handler',
            'operation' => $data['failed_operation'] ?? 'process_initial_sse_request',
            'failed_provider' => $data['failed_provider'] ?? null,
            'failed_model' => $data['failed_model'] ?? null,
            'http_code' => is_array($data) && isset($data['status']) && is_int($data['status']) ? $data['status'] : 500,
        ]);
    }

    public function exception(array $get_data, \Throwable $error): void
    {
        $status = is_int($error->getCode()) && $error->getCode() >= 400 ? $error->getCode() : 500;
        $this->dispatch_error($get_data, 'sse_handler_exception_' . $status, $error->getMessage(), [
            'module' => 'chat_stream_handler', 'operation' => 'process_stream_request', 'http_code' => $status,
        ]);
    }

    private function dispatch_error(array $get_data, string $code, string $message, array $details): void
    {
        if (!$this->enabled || !class_exists(AIPKit_Trigger_Manager::class)
            || !class_exists(AIPKit_Trigger_Storage::class) || !class_exists(LogStorage::class)) {
            return;
        }
        $bot_id = isset($get_data['bot_id']) ? absint($get_data['bot_id']) : null;
        $log_storage = new LogStorage();
        $context = array_merge([
            'error_code' => $code, 'error_message' => $message,
            'bot_id' => $bot_id, 'user_id' => get_current_user_id() ?: null,
            'session_id' => isset($get_data['session_id']) ? sanitize_text_field($get_data['session_id']) : null,
        ], $details);
        $manager = new AIPKit_Trigger_Manager(new AIPKit_Trigger_Storage(), $log_storage);
        $manager->process_event($bot_id ?? 0, 'system_error_occurred', $context);
    }

    /** Return true when a paid control response has completed the stream. */
    public function send_control_response(WP_Error $error, SSEResponseFormatter $formatter): bool
    {
        if (!$this->enabled) {
            return false;
        }
        $data = $error->get_error_data() ?: [];
        $message = $error->get_error_message();
        switch ($error->get_error_code()) {
            case 'trigger_blocked':
                $formatter->send_sse_error($message, false);
                break;
            case 'trigger_direct_reply':
                $message_id = is_array($data) && isset($data['message_id']) ? $data['message_id'] : ('trigger-reply-' . uniqid());
                $formatter->send_sse_event('message_start', ['message_id' => $message_id]);
                $formatter->send_sse_data(['delta' => $message]);
                break;
            case 'trigger_display_form':
                $event = $data['display_form_event_data'] ?? null;
                if ($event) {
                    $formatter->send_sse_event('display_form_event', $event);
                } else {
                    $formatter->send_sse_error(__('Form display requested but data is missing.', 'gpt3-ai-content-generator'), false);
                }
                break;
            default:
                return false;
        }
        $formatter->send_sse_done();
        return true;
    }

    public function send_initial_reply(array $processed_data, SSEResponseFormatter $formatter): void
    {
        if (!$this->enabled || !isset($processed_data['initial_trigger_reply_data'])
            || !is_array($processed_data['initial_trigger_reply_data'])) {
            return;
        }
        $reply = $processed_data['initial_trigger_reply_data'];
        if (!empty($reply['message_id']) && !empty($reply['message'])) {
            $formatter->send_sse_event('message_start', ['message_id' => $reply['message_id']]);
            $formatter->send_sse_data(['delta' => $reply['message']]);
        }
    }
}

/** Paid error events produced while setting up or executing a stream. */
final class ProcessorTriggers
{
    private $enabled;
    private $processor;
    private $base_log_data;
    private $provider;
    private $model;

    public function __construct(SSEStreamProcessor $processor, array $base_log_data, string $provider, string $model)
    {
        $this->enabled = class_exists('\WPAICG\aipkit_dashboard') && \WPAICG\aipkit_dashboard::is_pro_plan();
        $this->processor = $processor;
        $this->base_log_data = $base_log_data;
        $this->provider = $provider;
        $this->model = $model;
    }

    /** Factory and URL failures use the request's original module field. */
    public function error($code, string $message, string $operation, ?int $http_code = null, bool $use_base_module = false): void
    {
        if (!$this->enabled || !class_exists(AIPKit_Trigger_Manager::class) || !class_exists(AIPKit_Trigger_Storage::class)) {
            return;
        }

        $logs = $this->processor->get_log_storage();
        if (!$logs) {
            return;
        }

        $base = $this->base_log_data;
        $context = [
            'error_code' => $code,
            'error_message' => $message,
            'bot_id' => $base['bot_id'] ?? null,
            'user_id' => $base['user_id'] ?? null,
            'session_id' => $base['session_id'] ?? null,
            'module' => $use_base_module ? ($base['module'] ?? 'unknown_stream') : $this->processor->get_current_stream_context(),
            'operation' => $operation,
            'failed_provider' => $this->provider,
            'failed_model' => $this->model,
        ];
        if ($http_code !== null) {
            $context['http_code'] = $http_code;
        }

        $manager = new AIPKit_Trigger_Manager(new AIPKit_Trigger_Storage(), $logs);
        $manager->process_event($base['bot_id'] ?? 0, 'system_error_occurred', $context);
    }
}
