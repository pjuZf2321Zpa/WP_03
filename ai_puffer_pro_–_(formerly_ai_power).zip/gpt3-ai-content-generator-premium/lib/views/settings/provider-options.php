<?php
/**
 * Paid provider option definitions for the shared Settings renderer.
 */
if (!defined('ABSPATH')) {
    exit;
}

if (!class_exists('\WPAICG\aipkit_dashboard') || !\WPAICG\aipkit_dashboard::is_pro_plan()) {
    return [];
}

return [
    'OpenAI' => [[
        'id' => 'expiration_policy',
        'type' => 'number',
        'name' => 'openai_expiration_policy',
        'label' => __('Chat upload retention', 'gpt3-ai-content-generator'),
        'description' => __('Temporary OpenAI stores created for files uploaded in chat expire after this many inactive days.', 'gpt3-ai-content-generator'),
        'group' => 'options',
        'value' => (string) ($openai_data['expiration_policy'] ?? 7),
        'min' => '1',
        'max' => '365',
        'step' => '1',
        'suffix' => __('days', 'gpt3-ai-content-generator'),
    ]],
    'Ollama' => [$aipkit_build_model_field('Ollama', 'ollama')],
];
