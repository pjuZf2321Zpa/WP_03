<?php

namespace BitApps\IntegrationsPro\Actions\WPCafe;

use Exception;
use WpCafe\Models\Reservation_Model;

class WPCafeProHelper
{
    public static function createReservation($defaultResponse, $reservationData)
    {
        $helperClass = bit_integrations_get_class('Core\\Util\\Helper');

        if (!self::isWPCafeActive()) {
            return self::errorResponse('WP Cafe is not installed or activated');
        }

        if (
            !isset($reservationData['name'])
            || !isset($reservationData['email'])
            || !isset($reservationData['phone'])
            || !isset($reservationData['date'])
            || !isset($reservationData['start_time'])
            || !isset($reservationData['total_guest'])
        ) {
            return self::errorResponse('Name, Email, Phone, Date, Start Time, and Total Guest are required');
        }

        if (!is_email($reservationData['email'])) {
            return self::errorResponse('Invalid email address');
        }

        try {
            $capacityValidation = Reservation_Model::validate_guest_capacity(
                $reservationData['total_guest'] ?? 1,
                $reservationData['date'] ?? '',
                $reservationData['start_time'] ?? '',
                $reservationData['end_time'] ?? '',
                $reservationData['branch_id'] ?? ''
            );

            if (is_wp_error($capacityValidation)) {
                return self::errorResponse($capacityValidation->get_error_message());
            }

            $reservationData['invoice'] = 'WPC' . wp_rand(1000, 9999);

            $reservation = Reservation_Model::create($reservationData);
            if (is_wp_error($reservation)) {
                return self::errorResponse($reservation->get_error_message());
            }

            if (\function_exists('WC') && WC()->session) {
                self::setSessionData($reservation);
            }

            do_action('wpcafe_after_reservation_create', $reservation);

            return self::successResponse(__('Reservation created successfully'), ['reservation' => $helperClass::jsonEncodeDecode($reservation)]);
        } catch (Exception $e) {
            return self::errorResponse($e->getMessage());
        }
    }

    public static function updateReservation($defaultResponse, $reservationData)
    {
        $helperClass = bit_integrations_get_class('Core\\Util\\Helper');

        if (!self::isWPCafeActive()) {
            return self::errorResponse('WP Cafe is not installed or activated');
        }

        $reservationId = isset($reservationData['reservation_id']) ? absint($reservationData['reservation_id']) : 0;
        unset($reservationData['reservation_id']);

        if (empty($reservationId)) {
            return self::errorResponse('Reservation ID is required');
        }

        try {
            $reservation = Reservation_Model::find($reservationId);

            if (!$reservation) {
                return self::errorResponse(__('Reservation not found.', 'bit-integrations-pro'));
            }

            if (empty($reservationData)) {
                return self::errorResponse(__('No data provided to update', 'bit-integrations-pro'));
            }

            $oldStatus = $reservation->status;
            $updated = $reservation->update($reservationData);

            if (!$updated) {
                return self::errorResponse(__('Failed to update reservation', 'bit-integrations-pro'));
            }

            if ($oldStatus !== 'cancelled' && isset($reservationData['status']) && $reservationData['status'] === 'cancelled') {
                do_action('wpcafe_after_reservation_cancelled', $reservation);
            }

            do_action('wpcafe_after_reservation_update', $reservation);

            return self::successResponse(__('Reservation updated successfully', 'bit-integrations-pro'), ['reservation' => $helperClass::jsonEncodeDecode($reservation)]);
        } catch (Exception $e) {
            return self::errorResponse($e->getMessage());
        }
    }

    public static function deleteReservation($defaultResponse, $reservationId)
    {
        $helperClass = bit_integrations_get_class('Core\\Util\\Helper');

        if (!self::isWPCafeActive()) {
            return self::errorResponse(__('WP Cafe is not installed or activated', 'bit-integrations-pro'));
        }

        if (empty($reservationId)) {
            return self::errorResponse(__('Reservation ID is required', 'bit-integrations-pro'));
        }

        try {
            $reservation = Reservation_Model::find($reservationId);

            if (!$reservation) {
                return self::errorResponse(__('Reservation not found.', 'bit-integrations-pro'));
            }

            $deleted = $reservation->delete();

            if (!$deleted) {
                return self::errorResponse(__('Failed to delete reservation', 'bit-integrations-pro'));
            }

            do_action('wpcafe_after_reservation_delete', $deleted);

            return self::successResponse(__('Reservation deleted successfully', 'bit-integrations-pro'), ['reservation' => $helperClass::jsonEncodeDecode($deleted)]);
        } catch (Exception $e) {
            return self::errorResponse($e->getMessage());
        }
    }

    private static function setSessionData($reservation)
    {
        $sessionData = [
            'reservation_id'   => $reservation->id,
            'reservation_date' => $reservation->date ?? '',
            'start_time'       => $reservation->start_time ?? '',
            'end_time'         => $reservation->end_time ?? '',
            'name'             => $reservation->name ?? '',
            'email'            => $reservation->email ?? '',
            'phone'            => $reservation->phone ?? '',
            'total_guest'      => $reservation->total_guest ?? '',
            'notes'            => $reservation->notes ?? '',
            'branch_name'      => $reservation->branch_name ?? ''
        ];

        if (!empty($reservation->custom_fields)) {
            $sessionData['custom_fields'] = $reservation->custom_fields;
        }

        WC()->session->set('wpc_reservation_data', $sessionData);
    }

    private static function isWPCafeActive()
    {
        return class_exists('WpCafe\Init')
            && class_exists('\WpCafe\Models\Reservation_Model')
            && class_exists('\WpCafe\Models\Location_Model');
    }

    private static function successResponse($message, $data = [])
    {
        return [
            'success' => true,
            'message' => $message,
            'data'    => $data
        ];
    }

    private static function errorResponse($message)
    {
        return [
            'success' => false,
            'message' => $message,
        ];
    }
}
