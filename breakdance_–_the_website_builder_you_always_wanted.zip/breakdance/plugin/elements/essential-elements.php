<?php

/**
 * First-party Breakdance element library (elements, macros, presets).
 *
 * Elements use the main 'breakdance' text domain (no separate element domain);
 * their strings are part of the core 'breakdance' catalog loaded by
 * Breakdance\I18n\registerPlugin(), so nothing extra is loaded here.
 */

namespace EssentialElements;

use function Breakdance\Util\getDirectoryPathRelativeToPluginFolder;

// BREAKDANCE_ELEMENTS_PLUGIN_URL and __BREAKDANCE_ELEMENTS_DIR__ are defined in
// elements/base.php (before any element file loads) so they are available while
// twig-functions.php is being required.

require __DIR__ . "/macros-manual/woo/base.php";
require_once __DIR__ . "/lib/base.php";

// Priority 5 so the element save locations are registered *before*
// include_elements() (element-studio/load.php, priority 10) loads the element
// class files. element-studio is required before this module in plugin/base.php,
// so at the default priority its callback would run first and load nothing for
// EssentialElements, leaving classes like EssentialElements\Effectspreset undefined.
add_action('breakdance_loaded', function() {
    \Breakdance\I18n\Elements\registerElementTranslations( 'EssentialElements', 'breakdance' );

    \Breakdance\ElementStudio\registerSaveLocation(
        getDirectoryPathRelativeToPluginFolder(__DIR__) . '/essential',
        'EssentialElements',
        'element',
        'Breakdance Elements',
        true
    );

    \Breakdance\ElementStudio\registerSaveLocation(
        getDirectoryPathRelativeToPluginFolder(__DIR__) . '/manual',
        'EssentialElements',
        'element',
        'Breakdance Manual Elements', 'breakdance-elements',
        true,
        true
    );

    \Breakdance\ElementStudio\registerSaveLocation(
        getDirectoryPathRelativeToPluginFolder(__DIR__) . '/macros',
        'EssentialElements',
        'macro',
        'Breakdance Macros',
        true,
    );

    \Breakdance\ElementStudio\registerSaveLocation(
        getDirectoryPathRelativeToPluginFolder(__DIR__) . '/presets',
        'EssentialElements',
        'preset',
        'Breakdance Presets',
        true,
    );

    // TODO move all presets?
    // TODO: create a manual folder? Register them? Some of them need to be done through an element instead????!
}, 5);
