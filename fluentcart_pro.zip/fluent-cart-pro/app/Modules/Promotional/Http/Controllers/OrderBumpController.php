<?php

namespace FluentCartPro\App\Modules\Promotional\Http\Controllers;

use FluentCart\App\Services\Filter\OrderBumpFilter;
use FluentCart\Framework\Http\Controller;
use FluentCart\Framework\Http\Request\Request;
use FluentCart\Framework\Support\Arr;
use FluentCartPro\App\Http\Requests\OrderBumpRequest;
use FluentCartPro\App\Modules\Promotional\Models\OrderPromotion;
use FluentCartPro\App\Modules\Promotional\OrderBump\OrderBumpBoot;
use FluentCartPro\App\Modules\Promotional\OrderBump\OrderBumpSettings;
use FluentCartPro\App\Modules\Promotional\OrderBump\OrderBumpTemplateService;
use FluentCartPro\App\Modules\Promotional\OrderBump\RegistryBusyException;

class OrderBumpController extends Controller
{

    public function index(Request $request)
    {

        $orderBy = $request->get('sort_by', 'id');
        $order = $request->get('sort_type', 'desc');

        $orderBumps = OrderPromotion::query()->where('type', 'order_bump')
            ->orderBy($orderBy, $order)
            ->with(['product_variant.product'])
            ->when($activeView = $request->get('active_view'), function ($query) use ($activeView) {
                if ($activeView === 'active') {
                    $query->where('status', 'active');
                } elseif ($activeView === 'draft') {
                    $query->where('status', 'draft');
                }
            })
            ->when($search = $request->get('search'), function ($query) use ($search) {
                $query->where(function ($query) use ($search) {
                    $query->where('title', 'like', '%' . $search . '%')
                        ->orWhere('description', 'like', '%' . $search . '%');
                });
            })
            ->paginate();

        return [
            'order_bumps' => $orderBumps
        ];
    }

    public function store(Request $request)
    {
        $title = sanitize_text_field(Arr::get($request->all(), 'title', ''));
        $srcObjectId = intval(Arr::get($request->all(), 'src_object_id', 0));

        if (empty($title) || empty($srcObjectId)) {
            return $this->sendError([
                'message' => __('Title and source object id are required', 'fluent-cart-pro')
            ], 400);
        }

        $data = [
            'title'         => $title,
            'type'          => 'order_bump',
            'src_object_id' => $srcObjectId
        ];

        $isCreated = OrderPromotion::create($data);

        if (!$isCreated) {
            return $this->sendError([
                'message' => __('Failed to create order bump', 'fluent-cart-pro')
            ], 400);
        }

        return [
            'message' => __('Order bump created successfully', 'fluent-cart-pro'),
            'id'      => $isCreated->id
        ];
    }

    public function show(Request $request, $id)
    {
        $orderBump = OrderPromotion::query()
            ->where('id', $id)
            ->where('type', 'order_bump')
            ->first();

        if (!$orderBump) {
            return $this->sendError([
                'message' => __('Order bump not found', 'fluent-cart-pro')
            ], 404);
        }

        // set default config
        if (empty($orderBump->config)) {
            $orderBump->config = [
                'discount'              => [
                    'discount_type'   => 'percentage',
                    'discount_amount' => 0,
                ],
                'display_conditions_if' => '',
                'call_to_action'        => '',
                'position'              => '',
                'show_in_cart'          => 'no',
                'image'                 => ['id' => 0, 'url' => '']
            ];
        }

        $variant = $orderBump->product_variant;

        if ($variant) {
            $variant->load('product');
        }


        return [
            'order_bump' => $orderBump,
            'variant'    => $variant
        ];
    }

    public function update(OrderBumpRequest $request, $id)
    {
        $data = $request->getSafe($request->sanitize());

        $data['type'] = 'order_bump';

        // An offer with no discount gives the shopper nothing, so it is refused here, not only in the form.
        if (!$this->hasPositiveDiscount($data['config']['discount']['discount_amount'] ?? null)) {
            return $this->discountRequiredError();
        }

        $isUpdated = OrderPromotion::query()->where('id', $id)->update($data);
        OrderBumpBoot::flushCartFlag();
        OrderPromotion::clearActiveCache(); // a bulk query fires no model event

        if (!$isUpdated) {
            return $this->sendError([
                'message' => __('Failed to update order bump', 'fluent-cart-pro')
            ], 400);
        }

        return [
            'message' => __('Order bump updated successfully', 'fluent-cart-pro')
        ];
    }

    // The list switch sends only the status, so the rest of the bump is never rewritten.
    public function updateStatus(Request $request, $id)
    {
        $status = $request->get('status');
        if (!in_array($status, ['active', 'draft'], true)) {
            return $this->sendError([
                'message' => __('Please choose a valid status', 'fluent-cart-pro')
            ], 422);
        }

        $query = OrderPromotion::query()->where('id', $id)->where('type', 'order_bump');
        $bump = $query->first();
        if (!$bump) {
            return $this->sendError([
                'message' => __('Order bump not found', 'fluent-cart-pro')
            ], 404);
        }

        // Turning a bump on makes it shopper-facing, so it needs a discount; turning it off is always allowed.
        if ($status === 'active' && !$this->hasPositiveDiscount(Arr::get($bump->config, 'discount.discount_amount'))) {
            return $this->discountRequiredError();
        }

        $query->update(['status' => $status]);
        OrderBumpBoot::flushCartFlag();
        OrderPromotion::clearActiveCache(); // a bulk query fires no model event

        return [
            'message' => __('Order bump updated successfully', 'fluent-cart-pro'),
            'status'  => $status
        ];
    }

    // A plain positive decimal only: is_numeric() would also take 1e3 or 1e999 (infinity).
    private function hasPositiveDiscount($amount): bool
    {
        if (is_int($amount) || is_float($amount)) {
            return is_finite((float) $amount) && $amount > 0;
        }

        if (!is_string($amount)) {
            return false;
        }

        $amount = trim($amount);

        return (bool) preg_match('/^(\d+\.?\d*|\.\d+)$/', $amount) && (float) $amount > 0;
    }

    private function discountRequiredError()
    {
        return $this->sendError([
            'message' => __('Enter a discount amount greater than 0.', 'fluent-cart-pro')
        ], 422);
    }

    public function getSettings()
    {
        $custom = [];
        foreach (OrderBumpTemplateService::customTitles() as $key => $title) {
            $custom[] = ['key' => $key, 'title' => $title];
        }

        return [
            'settings'   => ['template' => OrderBumpSettings::activeTemplate()],
            'templates'  => OrderBumpSettings::allKeys(),
            'custom'     => $custom,
            'customized' => (new OrderBumpTemplateService())->customizedKeys()
        ];
    }

    public function saveSettings(Request $request)
    {
        $saved = OrderBumpSettings::save($request->get('template'));
        if (is_wp_error($saved)) {
            return $this->sendError(['message' => $saved->get_error_message()], (int) ($saved->get_error_data()['status'] ?? 422));
        }

        return [
            'message'  => __('The active card was updated.', 'fluent-cart-pro'),
            'settings' => $saved
        ];
    }

    public function getTemplate(Request $request, $templateId)
    {
        $template = (new OrderBumpTemplateService())->getTemplate(sanitize_text_field($templateId));
        if (!$template) {
            return $this->sendError(['message' => __('Template not found', 'fluent-cart-pro')], 404);
        }

        return ['template' => $template];
    }

    public function createTemplate(Request $request)
    {
        $title = trim(sanitize_text_field((string) $request->get('title', '')));
        if ($title === '') {
            return $this->sendError(['message' => __('Please enter a name for the card.', 'fluent-cart-pro')], 422);
        }

        $service = new OrderBumpTemplateService();
        try {
            $key = $service->createCustom(mb_substr($title, 0, 100));
        } catch (RegistryBusyException $e) {
            return $this->busyError();
        }
        if ($key === '') {
            return $this->sendError([
                'message' => sprintf(__('You can add up to %d cards. Delete one to add another.', 'fluent-cart-pro'), OrderBumpTemplateService::MAX_CUSTOM)
            ], 422);
        }

        return [
            'message'  => __('Card created successfully', 'fluent-cart-pro'),
            'key'      => $key,
            'template' => $service->getTemplate($key)
        ];
    }

    public function deleteTemplate(Request $request, $templateId)
    {
        $templateId = sanitize_text_field($templateId);
        $service = new OrderBumpTemplateService();

        if (!$service->getTemplate($templateId)) {
            return $this->sendError(['message' => __('Template not found', 'fluent-cart-pro')], 404);
        }

        if (in_array($templateId, OrderBumpSettings::TEMPLATES, true)) {
            return $this->sendError(['message' => __('Built-in cards cannot be deleted', 'fluent-cart-pro')], 422);
        }

        try {
            $deleted = $service->deleteCustom($templateId);
        } catch (RegistryBusyException $e) {
            return $this->busyError();
        }

        // Another admin may have deleted it since the check above.
        if (!$deleted) {
            return $this->sendError(['message' => __('Template not found', 'fluent-cart-pro')], 404);
        }

        return ['message' => __('Card deleted successfully', 'fluent-cart-pro')];
    }

    private function busyError()
    {
        return $this->sendError(['message' => __('Another change is being saved. Please try again.', 'fluent-cart-pro')], 409);
    }

    public function saveTemplate(Request $request, $templateId)
    {
        // The request class strips backslashes, which would break block attributes such as \u0026.
        $content = $request->isJson() ? $request->json('content') : null;
        if (!is_string($content)) {
            $content = $request->get('content');
        }
        if (!is_string($content) || trim($content) === '') {
            return $this->sendError(['message' => __('No template data provided', 'fluent-cart-pro')], 422);
        }

        if (!(new OrderBumpTemplateService())->saveContent(sanitize_text_field($templateId), $content)) {
            return $this->sendError(['message' => __('Template not found', 'fluent-cart-pro')], 404);
        }

        return ['message' => __('Template saved successfully', 'fluent-cart-pro')];
    }

    public function resetTemplate(Request $request, $templateId)
    {
        $service = new OrderBumpTemplateService();
        $templateId = sanitize_text_field($templateId);

        if (!$service->reset($templateId)) {
            return $this->sendError(['message' => __('Template not found', 'fluent-cart-pro')], 404);
        }

        return [
            'message'  => __('Reverted to the default template', 'fluent-cart-pro'),
            'template' => $service->getTemplate($templateId)
        ];
    }

    public function delete(Request $request, $id)
    {
        $isDeleted = OrderPromotion::query()->where('id', $id)->delete();
        OrderBumpBoot::flushCartFlag();
        OrderPromotion::clearActiveCache(); // a bulk query fires no model event

        if (!$isDeleted) {
            return $this->sendError([
                'message' => __('Failed to delete order bump', 'fluent-cart-pro')
            ], 400);
        }

        return [
            'message' => __('Order bump deleted successfully', 'fluent-cart-pro')
        ];
    }

}
