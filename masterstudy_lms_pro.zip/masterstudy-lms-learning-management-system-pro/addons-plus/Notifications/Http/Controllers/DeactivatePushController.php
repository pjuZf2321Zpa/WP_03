<?php

namespace MasterStudy\Lms\Pro\AddonsPlus\Notifications\Http\Controllers;

use MasterStudy\Lms\Http\WpResponseFactory;
use MasterStudy\Lms\Pro\AddonsPlus\Notifications\Repositories\PushSubscriptionRepository;
use MasterStudy\Lms\Validation\Validator;
use WP_REST_Request;
use WP_REST_Response;

final class DeactivatePushController {
	public function __invoke( WP_REST_Request $request ): WP_REST_Response {
		try {
			$params = $request->get_json_params();

			if ( empty( $params ) ) {
				$params = $request->get_params();
			}

			$validator = new Validator(
				$params,
				array( 'browser_key' => 'nullable|string' )
			);

			if ( $validator->fails() ) {
				return WpResponseFactory::validation_failed( $validator->get_errors_array() );
			}

			$validated   = $validator->get_validated();
			$browser_key = sanitize_text_field( (string) ( $validated['browser_key'] ?? '' ) );

			if ( '' === $browser_key && isset( $_COOKIE['masterstudy_notifications_push_browser_key'] ) && ! is_array( $_COOKIE['masterstudy_notifications_push_browser_key'] ) ) {
				$browser_key = sanitize_text_field( wp_unslash( $_COOKIE['masterstudy_notifications_push_browser_key'] ) );
			}

			if ( '' === $browser_key ) {
				return WpResponseFactory::ok();
			}

			( new PushSubscriptionRepository() )->deactivate_by_browser_key( get_current_user_id(), $browser_key );

			return WpResponseFactory::ok();
		} catch ( \Throwable $error ) {
			return WpResponseFactory::error( esc_html__( 'Unable to update push subscription.', 'masterstudy-lms-learning-management-system-pro' ) );
		}
	}
}
