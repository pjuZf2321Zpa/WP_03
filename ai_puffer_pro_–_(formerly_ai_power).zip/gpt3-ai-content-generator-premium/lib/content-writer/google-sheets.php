<?php

namespace WPAICG\Lib\ContentWriter;

use WPAICG\Lib\Utils\AIPKit_Google_Credentials_Handler;
use WPAICG\Lib\Utils\AIPKit_Google_Service_Account_Token_Service;
use WP_Error;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Minimal Google Sheets REST client for the plugin's current Sheets feature set.
 */
class AIPKit_Google_Sheets_REST_Client
{
    private const BASE_URL = 'https://sheets.googleapis.com/v4/spreadsheets/';
    private const REQUEST_TIMEOUT = 20;

    private AIPKit_Google_Service_Account_Token_Service $token_service;

    public function __construct(AIPKit_Google_Service_Account_Token_Service $token_service)
    {
        $this->token_service = $token_service;
    }

    /**
     * @return bool|\WP_Error
     */
    public function verify_access(string $spreadsheet_id)
    {
        $response = $this->request(
            'GET',
            $this->build_spreadsheet_url($spreadsheet_id),
            [],
            [
                'fields' => 'properties.title',
            ]
        );

        return is_wp_error($response) ? $response : true;
    }

    /**
     * @return mixed[]|\WP_Error
     */
    public function get_rows_from_sheet(string $spreadsheet_id)
    {
        $response = $this->request(
            'GET',
            $this->build_values_url($spreadsheet_id, 'A:G')
        );

        if (is_wp_error($response)) {
            return $response;
        }

        $values = $response['values'] ?? [];
        if (!is_array($values)) {
            return new WP_Error(
                'google_sheets_invalid_values_response',
                __('Google Sheets returned an unexpected values response.', 'gpt3-ai-content-generator')
            );
        }

        $rows = [];
        foreach ($values as $index => $row) {
            if (!is_array($row)) {
                continue;
            }

            $status = trim((string) ($row[6] ?? ''));
            if (!empty(array_filter($row)) && !empty(trim((string) ($row[0] ?? ''))) && $status === '') {
                $rows[] = [
                    'row_index' => $index + 1,
                    'topic' => trim((string) ($row[0] ?? '')),
                    'keywords' => trim((string) ($row[1] ?? '')),
                    'category' => trim((string) ($row[2] ?? '')),
                    'author' => trim((string) ($row[3] ?? '')),
                    'post_type' => trim((string) ($row[4] ?? '')),
                    'schedule_date' => trim((string) ($row[5] ?? '')),
                ];
            }
        }

        return $rows;
    }

    /**
     * @return bool|\WP_Error
     */
    public function update_row_status(string $spreadsheet_id, int $row_index, string $status)
    {
        $response = $this->request(
            'PUT',
            $this->build_values_url($spreadsheet_id, 'G' . $row_index),
            [
                'values' => [[$status]],
            ],
            [
                'valueInputOption' => 'USER_ENTERED',
            ]
        );

        return is_wp_error($response) ? $response : true;
    }

    private function build_spreadsheet_url(string $spreadsheet_id): string
    {
        return self::BASE_URL . rawurlencode($spreadsheet_id);
    }

    private function build_values_url(string $spreadsheet_id, string $range): string
    {
        return self::BASE_URL . rawurlencode($spreadsheet_id) . '/values/' . rawurlencode($range);
    }

    /**
     * @param array<string, mixed> $body
     * @param array<string, string> $query_params
     * @return array<string, mixed>|WP_Error
     */
    private function request(string $method, string $url, array $body = [], array $query_params = [])
    {
        $access_token = $this->token_service->get_access_token();
        if (is_wp_error($access_token)) {
            return $access_token;
        }

        if (!empty($query_params)) {
            $url = add_query_arg($query_params, $url);
        }

        $request_args = [
            'method' => strtoupper($method),
            'timeout' => self::REQUEST_TIMEOUT,
            'headers' => [
                'Authorization' => 'Bearer ' . $access_token,
                'Accept' => 'application/json',
            ],
        ];

        if (!empty($body) && in_array($request_args['method'], ['POST', 'PUT', 'PATCH'], true)) {
            $request_args['headers']['Content-Type'] = 'application/json';
            $request_args['body'] = wp_json_encode($body);
        }

        $response = wp_remote_request($url, $request_args);
        if (is_wp_error($response)) {
            return new WP_Error(
                'google_sheets_request_failed',
                sprintf(
                    /* translators: %s: Network error message returned by WordPress HTTP API. */
                    __('Google Sheets request failed: %s', 'gpt3-ai-content-generator'),
                    $response->get_error_message()
                )
            );
        }

        $status_code = wp_remote_retrieve_response_code($response);
        $response_body = wp_remote_retrieve_body($response);
        $decoded_body = json_decode($response_body, true);

        if ($status_code < 200 || $status_code >= 300) {
            return $this->map_error_response($status_code, $decoded_body, $response_body);
        }

        if ($response_body === '') {
            return [];
        }

        if (!is_array($decoded_body)) {
            return new WP_Error(
                'google_sheets_invalid_json_response',
                __('Google Sheets returned invalid JSON.', 'gpt3-ai-content-generator')
            );
        }

        return $decoded_body;
    }

    /**
     * @param mixed $decoded_body
     */
    private function map_error_response(int $status_code, $decoded_body, string $response_body): WP_Error
    {
        $google_status = '';
        $error_message = '';

        if (is_array($decoded_body) && !empty($decoded_body['error']) && is_array($decoded_body['error'])) {
            $google_status = isset($decoded_body['error']['status']) && is_string($decoded_body['error']['status'])
                ? $decoded_body['error']['status']
                : '';
            $error_message = isset($decoded_body['error']['message']) && is_string($decoded_body['error']['message'])
                ? $decoded_body['error']['message']
                : '';
        }

        if ($error_message === '' && is_array($decoded_body) && !empty($decoded_body['error']) && is_string($decoded_body['error'])) {
            $error_message = $decoded_body['error'];
        }

        if ($error_message === '') {
            $error_message = trim($response_body);
        }

        if ($error_message === '') {
            $error_message = __('Unknown Google Sheets API error.', 'gpt3-ai-content-generator');
        }

        $error_code = 'google_sheets_api_error';
        if ($status_code === 404 || $google_status === 'NOT_FOUND') {
            $error_code = 'google_sheets_not_found';
        } elseif ($status_code === 403 || $google_status === 'PERMISSION_DENIED') {
            $error_code = 'google_sheets_permission_denied';
        }

        return new WP_Error(
            $error_code,
            $error_message,
            [
                'status' => $status_code,
                'google_status' => $google_status,
            ]
        );
    }
}

/**
 * Parses Google Sheets to extract topics for content generation.
 */
class AIPKit_Google_Sheets_Parser
{
    /**
     * @var array<string, mixed>
     */
    private array $service_account_credentials;

    private AIPKit_Google_Sheets_REST_Client $client;

    public function __construct(array $service_account_credentials)
    {
        $normalized_credentials = AIPKit_Google_Credentials_Handler::process_credentials($service_account_credentials);
        $this->service_account_credentials = is_array($normalized_credentials) ? $normalized_credentials : $service_account_credentials;
        if (empty($this->service_account_credentials['private_key']) || empty($this->service_account_credentials['client_email'])) {
            throw new \Exception('Invalid Service Account credentials array: missing private_key or client_email.');
        }

        $token_service = new AIPKit_Google_Service_Account_Token_Service($this->service_account_credentials);
        $this->client = new AIPKit_Google_Sheets_REST_Client($token_service);
    }

    /**
     * Gets structured data from the first 7 columns of the specified Google Sheet.
     * A: Topic, B: Keywords, C: Category ID, D: Author Login, E: Post Type, F: Schedule Date, G: Status.
     * It filters out rows that have any value in the Status column (Column G).
     *
     * @param string $spreadsheet_id The ID of the Google Sheet.
     * @return array|WP_Error An array of structured row data or a WP_Error on failure.
     */
    public function get_rows_from_sheet(string $spreadsheet_id)
    {
        if (empty($spreadsheet_id)) {
            return new WP_Error('missing_sheet_id', __('Google Sheet ID is required.', 'gpt3-ai-content-generator'));
        }

        try {
            $rows = $this->client->get_rows_from_sheet($spreadsheet_id);
            if (is_wp_error($rows)) {
                return new WP_Error(
                    'google_api_error',
                    'Error connecting to Google Sheets: ' . $rows->get_error_message(),
                    $rows->get_error_data()
                );
            }

            return $rows;
        } catch (\Exception $e) {
            return new WP_Error('google_api_error', 'Error connecting to Google Sheets: ' . $e->getMessage());
        }
    }

    /**
     * Updates the Status column (G) for a specific row in a Google Sheet.
     *
     * @param string $spreadsheet_id The ID of the Google Sheet.
     * @param int    $row_index      The 1-based index of the row to update.
     * @param string $status         The text to write into the status column.
     * @return bool|WP_Error True on success, or a WP_Error on failure.
     */
    public function update_row_status(string $spreadsheet_id, int $row_index, string $status)
    {
        if (empty($spreadsheet_id) || $row_index <= 0) {
            return new WP_Error('invalid_params_update_status', __('Spreadsheet ID and a valid row index are required.', 'gpt3-ai-content-generator'));
        }
        try {
            $result = $this->client->update_row_status($spreadsheet_id, $row_index, $status);
            if (is_wp_error($result)) {
                return new WP_Error(
                    'google_api_update_error',
                    __('Error updating Google Sheet status: ', 'gpt3-ai-content-generator') . $result->get_error_message(),
                    $result->get_error_data()
                );
            }
            return true;
        } catch (\Exception $e) {
            return new WP_Error('google_api_update_error', __('Error updating Google Sheet status: ', 'gpt3-ai-content-generator') . $e->getMessage());
        }
    }


    /**
     * Verifies that the service account has access to the given Google Sheet.
     *
     * @param string $spreadsheet_id The ID of the Google Sheet.
     * @return true|WP_Error True on success, or a WP_Error on failure.
     */
    public function verify_access(string $spreadsheet_id)
    {
        if (empty($spreadsheet_id)) {
            return new WP_Error('missing_sheet_id_verify', __('Google Sheet ID is required for verification.', 'gpt3-ai-content-generator'));
        }

        try {
            $result = $this->client->verify_access($spreadsheet_id);
            if (is_wp_error($result)) {
                $message = $result->get_error_message();
                if ($result->get_error_code() === 'google_sheets_not_found') {
                    $message = __('Sheet not found or not shared with the service account email.', 'gpt3-ai-content-generator');
                } elseif ($result->get_error_code() === 'google_sheets_permission_denied') {
                    $message = __('Permission denied. Ensure the sheet is shared with the service account email.', 'gpt3-ai-content-generator');
                }

                return new WP_Error(
                    'google_api_error_verify',
                    'Error connecting to Google Sheets: ' . $message,
                    $result->get_error_data()
                );
            }
            return true;
        } catch (\Exception $e) {
            $message = $e->getMessage();
            // Try to provide a more user-friendly message for common errors
            if (strpos($message, 'Requested entity was not found') !== false) {
                $message = __('Sheet not found or not shared with the service account email.', 'gpt3-ai-content-generator');
            } elseif (strpos($message, 'PERMISSION_DENIED') !== false) {
                $message = __('Permission denied. Ensure the sheet is shared with the service account email.', 'gpt3-ai-content-generator');
            }
            return new WP_Error('google_api_error_verify', 'Error connecting to Google Sheets: ' . $message);
        }
    }
}
