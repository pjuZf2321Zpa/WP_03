<?php

// Don't redefine the functions if included multiple times.

if ( ! defined( 'ABSPATH' ) ) { exit; }
if (!function_exists('NxProGA\GuzzleHttp\uri_template')) {
    require __DIR__ . '/functions.php';
}
