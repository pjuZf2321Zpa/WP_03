<?php

namespace BitApps\IntegrationsPro\Actions\Bookly;

use Bookly\Lib\Entities\Appointment;
use Bookly\Lib\Entities\Customer;
use Bookly\Lib\Entities\CustomerAppointment;
use Exception;

final class BooklyRecordHelper
{
    private const CUSTOMER_SETTER_MAP = [
        'full_name'  => 'setFullName',
        'first_name' => 'setFirstName',
        'last_name'  => 'setLastName',
        'email'      => 'setEmail',
        'phone'      => 'setPhone',
        'wp_user_id' => 'setWpUserId',
    ];

    public static function createAppointment($response, $fieldData, $utilities = [])
    {
        if (!self::hasRequiredClasses(['Bookly\Lib\Entities\Appointment', 'Bookly\Lib\Entities\CustomerAppointment'])) {
            return self::errorResponse(__('Bookly is not installed or activated', 'bit-integrations-pro'));
        }

        $utils = \is_object($utilities) ? $utilities : (object) $utilities;
        $staffId = !empty($utils->staffId) ? (int) $utils->staffId : 0;
        $serviceId = !empty($utils->serviceId) ? (int) $utils->serviceId : null;
        $status = $utils->status ?? '';

        $customerEmail = $fieldData['customer_email'] ?? '';
        $startDate = $fieldData['start_date'] ?? '';
        $endDate = $fieldData['end_date'] ?? '';

        if (empty($staffId) || empty($status) || empty($customerEmail) || empty($startDate) || empty($endDate)) {
            return self::errorResponse(self::getRequiredCreateAppointmentMessage($staffId, $status, $customerEmail, $startDate, $endDate));
        }

        $customer = self::findCustomerByEmail($customerEmail);
        if (!$customer) {
            return self::errorResponse(__('No customer found with that email', 'bit-integrations-pro'));
        }

        $appointment = null;

        try {
            $numberOfPersons = !empty($fieldData['number_of_persons']) ? (int) $fieldData['number_of_persons'] : 1;

            $appointment = new Appointment();
            $appointment
                ->setStaffId($staffId)
                ->setServiceId($serviceId)
                ->setStartDate($startDate)
                ->setEndDate($endDate)
                ->setInternalNote($fieldData['internal_note'] ?? '')
                ->save();

            $customerAppointment = new CustomerAppointment();
            $customerAppointment
                ->setCustomerId($customer->getId())
                ->setAppointmentId($appointment->getId())
                ->setStatus($status)
                ->setNumberOfPersons($numberOfPersons)
                ->setNotes($fieldData['notes'] ?? '')
                ->setCreatedFrom('backend')
                ->setCreatedAt(current_time('mysql'))
                ->save();

            return [
                'success' => true,
                'message' => __('Appointment created successfully', 'bit-integrations-pro'),
                'data'    => self::getCustomerAppointmentData($customerAppointment->getId()),
            ];
        } catch (Exception $e) {
            if ($appointment && $appointment->getId()) {
                $appointment->delete();
            }

            return self::errorResponse($e->getMessage());
        }
    }

    public static function updateAppointmentStatus($response, $fieldData, $utilities = [])
    {
        if (!self::hasRequiredClasses(['Bookly\Lib\Entities\CustomerAppointment'])) {
            return self::errorResponse(__('Bookly is not installed or activated', 'bit-integrations-pro'));
        }

        $utils = \is_object($utilities) ? $utilities : (object) $utilities;
        $appointmentId = (int) ($fieldData['customer_appointment_id'] ?? 0);
        $status = $utils->status ?? '';

        if (empty($appointmentId) || empty($status)) {
            return self::errorResponse(empty($appointmentId) ? __('Customer Appointment ID is required', 'bit-integrations-pro') : __('Status is required', 'bit-integrations-pro'));
        }

        $customerAppointment = new CustomerAppointment();
        if (!$customerAppointment->load($appointmentId)) {
            return self::errorResponse(__('Customer appointment not found', 'bit-integrations-pro'));
        }

        try {
            $customerAppointment->setStatus($status)->save();

            return [
                'success' => true,
                'message' => __('Appointment status updated successfully', 'bit-integrations-pro'),
                'data'    => self::getCustomerAppointmentData($customerAppointment->getId()),
            ];
        } catch (Exception $e) {
            return self::errorResponse($e->getMessage());
        }
    }

    public static function deleteAppointment($response, $fieldData)
    {
        if (!self::hasRequiredClasses(['Bookly\Lib\Entities\CustomerAppointment'])) {
            return self::errorResponse(__('Bookly is not installed or activated', 'bit-integrations-pro'));
        }

        $appointmentId = (int) ($fieldData['customer_appointment_id'] ?? 0);

        if (empty($appointmentId)) {
            return self::errorResponse(__('Customer Appointment ID is required', 'bit-integrations-pro'));
        }

        $customerAppointment = new CustomerAppointment();
        if (!$customerAppointment->load($appointmentId)) {
            return self::errorResponse(__('Customer appointment not found', 'bit-integrations-pro'));
        }

        try {
            $customerAppointment->deleteCascade();

            return ['success' => true, 'message' => __('Appointment deleted successfully', 'bit-integrations-pro')];
        } catch (Exception $e) {
            return self::errorResponse($e->getMessage());
        }
    }

    public static function createCustomer($response, $fieldData)
    {
        if (!self::hasRequiredClasses(['Bookly\Lib\Entities\Customer'])) {
            return self::errorResponse(__('Bookly is not installed or activated', 'bit-integrations-pro'));
        }

        if (empty($fieldData['full_name']) && (empty($fieldData['first_name']) || empty($fieldData['last_name']))) {
            return self::errorResponse(__('Either full name or first name and last name are required', 'bit-integrations-pro'));
        }

        try {
            $customer = new Customer();
            self::hydrateCustomerFromFields($customer, $fieldData);

            $customer->setCreatedAt(current_time('mysql'));
            $customer->save();

            return [
                'success' => true,
                'message' => __('Customer created successfully', 'bit-integrations-pro'),
                'data'    => self::getCustomerData($customer->getId()),
            ];
        } catch (Exception $e) {
            return self::errorResponse($e->getMessage());
        }
    }

    public static function updateCustomer($response, $fieldData)
    {
        if (!self::hasRequiredClasses(['Bookly\Lib\Entities\Customer'])) {
            return self::errorResponse(__('Bookly is not installed or activated', 'bit-integrations-pro'));
        }

        $customerEmail = $fieldData['customer_email'] ?? '';
        if (empty($customerEmail)) {
            return self::errorResponse(__('Customer email is required', 'bit-integrations-pro'));
        }

        $customer = self::findCustomerByEmail($customerEmail);
        if (!$customer) {
            return self::errorResponse(__('No customer found with that email', 'bit-integrations-pro'));
        }

        try {
            self::hydrateCustomerFromFields($customer, $fieldData);

            $customer->save();

            return [
                'success' => true,
                'message' => __('Customer updated successfully', 'bit-integrations-pro'),
                'data'    => self::getCustomerData($customer->getId()),
            ];
        } catch (Exception $e) {
            return self::errorResponse($e->getMessage());
        }
    }

    public static function deleteCustomer($response, $fieldData)
    {
        if (!self::hasRequiredClasses(['Bookly\Lib\Entities\Customer'])) {
            return self::errorResponse(__('Bookly is not installed or activated', 'bit-integrations-pro'));
        }

        $customerEmail = $fieldData['customer_email'] ?? '';
        if (empty($customerEmail)) {
            return self::errorResponse(__('Customer email is required', 'bit-integrations-pro'));
        }

        $customer = self::findCustomerByEmail($customerEmail);
        if (!$customer) {
            return self::errorResponse(__('No customer found with that email', 'bit-integrations-pro'));
        }

        try {
            $customer->delete();

            return ['success' => true, 'message' => __('Customer deleted successfully', 'bit-integrations-pro')];
        } catch (Exception $e) {
            return self::errorResponse($e->getMessage());
        }
    }

    private static function hasRequiredClasses(array $classNames): bool
    {
        foreach ($classNames as $className) {
            if (!class_exists($className)) {
                return false;
            }
        }

        return true;
    }

    private static function findCustomerByEmail(string $email)
    {
        return Customer::query()->where('email', $email)->findOne();
    }

    private static function hydrateCustomerFromFields(Customer $customer, array $fieldData): void
    {
        foreach (self::CUSTOMER_SETTER_MAP as $key => $setter) {
            if (!\array_key_exists($key, $fieldData)) {
                continue;
            }

            $value = $key === 'wp_user_id' ? (int) $fieldData[$key] : $fieldData[$key];
            $customer->{$setter}($value);
        }
    }

    private static function errorResponse(string $message): array
    {
        return ['success' => false, 'message' => $message];
    }

    private static function getRequiredCreateAppointmentMessage(int $staffId, string $status, string $customerEmail, string $startDate, string $endDate): string
    {
        if (empty($staffId)) {
            return __('Staff is required', 'bit-integrations-pro');
        }

        if (empty($status)) {
            return __('Status is required', 'bit-integrations-pro');
        }

        if (empty($customerEmail)) {
            return __('Customer email is required', 'bit-integrations-pro');
        }

        if (empty($startDate)) {
            return __('Start date is required', 'bit-integrations-pro');
        }

        return __('End date is required', 'bit-integrations-pro');
    }

    private static function getCustomerAppointmentData(int $id): array
    {
        $customerAppointment = new CustomerAppointment();
        if (!$customerAppointment->load($id)) {
            return [];
        }

        return [
            'customer_appointment_id' => $customerAppointment->getId(),
            'appointment_id'          => $customerAppointment->getAppointmentId(),
            'customer_id'             => $customerAppointment->getCustomerId(),
            'status'                  => $customerAppointment->getStatus(),
            'number_of_persons'       => $customerAppointment->getNumberOfPersons(),
            'notes'                   => $customerAppointment->getNotes(),
            'created_at'              => $customerAppointment->getCreatedAt(),
            'updated_at'              => $customerAppointment->getUpdatedAt(),
        ];
    }

    private static function getCustomerData(int $id): array
    {
        $customer = new Customer();
        if (!$customer->load($id)) {
            return [];
        }

        return [
            'customer_id' => $customer->getId(),
            'full_name'   => $customer->getFullName(),
            'first_name'  => $customer->getFirstName(),
            'last_name'   => $customer->getLastName(),
            'email'       => $customer->getEmail(),
            'phone'       => $customer->getPhone(),
            'created_at'  => $customer->getCreatedAt(),
        ];
    }
}
