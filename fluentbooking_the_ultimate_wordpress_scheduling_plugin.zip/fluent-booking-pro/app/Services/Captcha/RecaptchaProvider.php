<?php

namespace FluentBookingPro\App\Services\Captcha;

use FluentBooking\Framework\Support\Arr;

class RecaptchaProvider extends AbstractCaptchaProvider
{
    const VERIFY_URL = 'https://www.google.com/recaptcha/api/siteverify';

    /**
     * The v3 action name. verify() rejects a token minted for another action
     * on the same site key.
     */
    const V3_ACTION = 'fluent_booking';

    const TOKEN_FIELD = 'g-recaptcha-response';

    public function getKey()
    {
        return 'recaptcha';
    }

    public function getTitle()
    {
        return __('Google reCAPTCHA', 'fluent-booking-pro');
    }

    public function getDefaults()
    {
        return [
            'version'            => 'v3',
            'v3_site_key'        => '',
            'v3_secret_key'      => '',
            'v3_score_threshold' => 0.5,
            'v2_site_key'        => '',
            'v2_secret_key'      => '',
        ];
    }

    public function secretFields()
    {
        return ['v3_secret_key', 'v2_secret_key'];
    }

    public function sanitize($input, $prev = [])
    {
        if (!is_array($input)) {
            $input = [];
        }

        $threshold = (float)Arr::get($input, 'v3_score_threshold', 0.5);
        $threshold = max(0, min(1, $threshold));

        return [
            'version'            => Arr::get($input, 'version') === 'v2' ? 'v2' : 'v3',
            'v3_site_key'        => sanitize_text_field(Arr::get($input, 'v3_site_key', '')),
            'v3_secret_key'      => $this->resolveSecret(Arr::get($input, 'v3_secret_key', ''), Arr::get($prev, 'v3_secret_key', '')),
            'v3_score_threshold' => $threshold,
            'v2_site_key'        => sanitize_text_field(Arr::get($input, 'v2_site_key', '')),
            'v2_secret_key'      => $this->resolveSecret(Arr::get($input, 'v2_secret_key', ''), Arr::get($prev, 'v2_secret_key', '')),
        ];
    }

    public function isConfigured($settings)
    {
        // The stored value, not the decrypted one: a secret that no longer
        // decrypts must still reach verify(), which reports it.
        return (bool)($this->getSiteKey($settings) && Arr::get($settings, $this->getVersion($settings) . '_secret_key'));
    }

    public function publicVars($settings)
    {
        return [
            'provider'    => $this->getKey(),
            'version'     => $this->getVersion($settings),
            'site_key'    => $this->getSiteKey($settings),
            'token_field' => self::TOKEN_FIELD,
            'action'      => self::V3_ACTION,
        ];
    }

    public function verify($settings, $token)
    {
        $secret = $this->getSecretKey($settings);

        if (!$secret) {
            // No usable key is a setup error, so it fails open like a wrong key.
            return [
                'status' => 'unreachable',
                'code'   => 'invalid_secret',
                'reason' => 'The stored reCAPTCHA secret key is missing or cannot be read.',
            ];
        }

        $body = [
            'secret'   => $secret,
            'response' => $token,
        ];

        /**
         * The IP is optional to Google. An operator can return an empty string
         * to keep it out of the call.
         *
         * @param string $ip
         * @param array  $settings
         */
        $remoteIp = apply_filters('fluent_booking/recaptcha_remoteip', $this->getIpAddress(), $settings);

        if ($remoteIp) {
            $body['remoteip'] = $remoteIp;
        }

        $response = $this->remoteVerify(self::VERIFY_URL, $body);

        if ($response['unreachable']) {
            return [
                'status' => 'unreachable',
                'code'   => 'provider_unreachable',
                'reason' => $response['reason'],
            ];
        }

        $result = $response['result'];

        if (empty($result['success'])) {
            return $this->resultFromErrorCodes($result);
        }

        if ($this->getVersion($settings) !== 'v3') {
            return [
                'status' => 'valid',
                'code'   => '',
            ];
        }

        if (Arr::get($result, 'action') !== self::V3_ACTION) {
            return [
                'status' => 'invalid',
                'code'   => 'captcha_failed',
            ];
        }

        /**
         * The score a v3 token must reach.
         *
         * @param float $threshold
         * @param array $settings
         */
        $threshold = (float)apply_filters(
            'fluent_booking/recaptcha_v3_score_threshold',
            (float)Arr::get($settings, 'v3_score_threshold', 0.5),
            $settings
        );

        $score = isset($result['score']) ? (float)$result['score'] : 0;

        if ($score < $threshold) {
            return [
                'status' => 'invalid',
                'code'   => 'captcha_failed',
            ];
        }

        return [
            'status' => 'valid',
            'code'   => '',
        ];
    }

    public function validateCredentials($settings, $token)
    {
        $secret = $this->getSecretKey($settings);

        if (!$secret) {
            return [
                'valid'   => false,
                'message' => __('Add a Secret Key first.', 'fluent-booking-pro'),
            ];
        }

        if (!$this->getSiteKey($settings)) {
            return [
                'valid'   => false,
                'message' => __('Add a Site Key first.', 'fluent-booking-pro'),
            ];
        }

        // Google checks the token before the secret, so a test without a real
        // token proves nothing about the keys.
        if (!$token) {
            return [
                'valid'   => false,
                'message' => __('FluentBooking could not get a token from Google. Check the Site Key, and make sure this domain is on the key.', 'fluent-booking-pro'),
            ];
        }

        $response = $this->remoteVerify(self::VERIFY_URL, [
            'secret'   => $secret,
            'response' => $token,
        ], 1);

        if ($response['unreachable']) {
            return [
                'valid'   => false,
                'message' => __('FluentBooking cannot connect to Google. Try again in a minute.', 'fluent-booking-pro'),
            ];
        }

        $result = $response['result'];

        if (!empty($result['success'])) {
            if ($this->getVersion($settings) === 'v3' && Arr::get($result, 'action') !== self::V3_ACTION) {
                return [
                    'valid'   => false,
                    'message' => __('Google answered for a different action. Use a key that is not shared with another form.', 'fluent-booking-pro'),
                ];
            }

            $score = isset($result['score']) ? sprintf(' (score %s)', (float)$result['score']) : '';

            return [
                'valid'   => true,
                /* translators: %s: the reCAPTCHA v3 score, for example " (score 0.9)". */
                'message' => sprintf(__('Google accepted both keys%s.', 'fluent-booking-pro'), $score),
            ];
        }

        $codes = array_map('strval', (array)Arr::get($result, 'error-codes', []));

        if (in_array('invalid-input-secret', $codes, true) || in_array('missing-input-secret', $codes, true)) {
            return [
                'valid'   => false,
                'message' => __('Google refused this Secret Key. Check the key in your reCAPTCHA admin console.', 'fluent-booking-pro'),
            ];
        }

        if (in_array('invalid-input-response', $codes, true) || in_array('timeout-or-duplicate', $codes, true)) {
            return [
                'valid'   => false,
                'message' => __('Google refused the token. The Site Key and the Secret Key must come from the same reCAPTCHA key.', 'fluent-booking-pro'),
            ];
        }

        return [
            'valid'   => false,
            'message' => __('Google refused these keys. Check both keys and try again.', 'fluent-booking-pro'),
        ];
    }

    /**
     * @param array $settings
     * @return string
     */
    private function getVersion($settings)
    {
        return Arr::get($settings, 'version') === 'v2' ? 'v2' : 'v3';
    }

    /**
     * @param array $settings
     * @return string
     */
    private function getSiteKey($settings)
    {
        return (string)Arr::get($settings, $this->getVersion($settings) . '_site_key', '');
    }

    /**
     * @param array $settings
     * @return string
     */
    private function getSecretKey($settings)
    {
        return $this->decryptSecret(Arr::get($settings, $this->getVersion($settings) . '_secret_key', ''));
    }
}
