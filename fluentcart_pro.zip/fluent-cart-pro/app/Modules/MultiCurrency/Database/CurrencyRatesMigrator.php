<?php

namespace FluentCartPro\App\Modules\MultiCurrency\Database;

use FluentCart\Database\Migrations\Migrator;
use FluentCart\Framework\Database\Schema;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Exchange-rate history for multi-currency. Append-only: editing a rate
 * inserts a row, so "what rate was used on 12 March, and who set it" is
 * answerable from the table alone. The active rate for a pair is the newest
 * row with effective_at <= now.
 */
class CurrencyRatesMigrator extends Migrator
{
    public static string $tableName = 'fct_currency_rates';

    /** Written only once the table is verified, so a failed CREATE is retried */
    const OPTION = '_fluentcart_pro_currency_rates_version';

    public static function getSqlSchema(): string
    {
        $indexPrefix = static::getDbPrefix() . 'fct_cr_';

        return "`id` BIGINT UNSIGNED NOT NULL PRIMARY KEY AUTO_INCREMENT,
                `base` VARCHAR(10) NOT NULL,
                `quote` VARCHAR(10) NOT NULL,
                `rate` DECIMAL(24,12) NOT NULL,
                `source` VARCHAR(50) NOT NULL DEFAULT 'manual',
                `effective_at` DATETIME NOT NULL,
                `created_by` BIGINT UNSIGNED NULL,
                `created_at` DATETIME NULL,
                `updated_at` DATETIME NULL,
                INDEX `{$indexPrefix}_pair_effective_idx` (`base` ASC, `quote` ASC, `effective_at` ASC, `id` ASC)";
    }

    public static function isInstalled(): bool
    {
        return Schema::hasTable(static::$tableName);
    }

    /**
     * Whether the table may be queried. A storefront request never checks the
     * schema; until an admin load or activation verifies it, there are no rates.
     */
    public static function isReady(): bool
    {
        return get_option(self::OPTION) === '1';
    }

    /**
     * Create the table and record it once verified. Without $force it runs
     * only until it has succeeded once.
     */
    public static function install(bool $force = false): void
    {
        if (!$force && self::isReady()) {
            return;
        }

        static::migrate();

        if (static::isInstalled()) {
            update_option(self::OPTION, '1', true);
        } else {
            delete_option(self::OPTION);
        }
    }
}
