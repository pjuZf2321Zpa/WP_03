<?php

namespace MasterStudy\Lms\Pro\addons\enterprise_courses\Admin\Repositories;

use MasterStudy\Lms\Plugin\PostType;
use WP_Post;
use WP_Query;
use WP_User;
use wpdb;

final class EnterpriseGroupsRepository {
	private string $post_type = PostType::COURSE_GROUPS;

	/**
	 * @return array{items: array<int, array<string, mixed>>, total: int, pages: int}
	 */
	public function get_list( array $params ): array {
		$per_page = max( 1, min( 100, (int) ( $params['per_page'] ?? 10 ) ) );
		$page     = max( 1, (int) ( $params['page'] ?? 1 ) );
		$search   = sanitize_text_field( $params['search'] ?? '' );

		$query = new WP_Query(
			array(
				'post_type'      => $this->post_type,
				'post_status'    => array( 'publish', 'draft' ),
				'posts_per_page' => $per_page,
				'paged'          => $page,
				's'              => $search,
				'orderby'        => 'date',
				'order'          => 'DESC',
				'fields'         => 'ids',
				'meta_query'     => ! current_user_can( 'manage_options' )
					? array(
						array(
							'key'   => 'author_id',
							'value' => get_current_user_id(),
						),
					)
					: array(),
			)
		);

		$items = array_map( array( $this, 'serialize_list_item' ), array_map( 'intval', $query->posts ) );

		return array(
			'items' => $items,
			'total' => (int) $query->found_posts,
			'pages' => (int) $query->max_num_pages,
		);
	}

	public function get_group( int $group_id ): ?WP_Post {
		$group = get_post( $group_id );

		if ( ! $group instanceof WP_Post || $this->post_type !== $group->post_type ) {
			return null;
		}

		if ( ! $this->current_user_can_manage_group( $group_id ) ) {
			return null;
		}

		return $group;
	}

	/**
	 * @return array<string, mixed>|null
	 */
	public function get_group_for_edit( int $group_id ): ?array {
		$group = $this->get_group( $group_id );

		if ( ! $group ) {
			return null;
		}

		return array(
			'id'          => $group->ID,
			'title'       => html_entity_decode( $group->post_title, ENT_QUOTES, 'UTF-8' ),
			'emails'      => $this->get_group_member_emails( $group->ID ),
			'users_limit' => $this->get_users_limit(),
		);
	}

	/**
	 * @return array{data: array<int, array<string, mixed>>, total: int, pages: int}
	 */
	public function get_members( int $group_id, int $page = 1, int $per_page = 10 ): array {
		$members          = $this->get_group_members( $group_id );
		$total            = count( $members );
		$pages            = max( 1, (int) ceil( $total / $per_page ) );
		$offset           = max( 0, ( $page - 1 ) * $per_page );
		$members_page     = array_slice( $members, $offset, $per_page );
		$group_course_ids = $this->get_group_course_ids( $group_id );
		$data             = array();

		foreach ( $members_page as $member ) {
			$data[] = $this->serialize_member( $member, $group_id, $group_course_ids );
		}

		return array(
			'data'  => $data,
			'total' => $total,
			'pages' => $pages,
		);
	}

	/**
	 * @return array<string, mixed>|\WP_Error
	 */
	public function create( array $data ) {
		if ( ! $this->is_group_manage_allowed() ) {
			return new \WP_Error( 'group_manage_not_allowed', esc_html__( 'Group management is disabled.', 'masterstudy-lms-learning-management-system-pro' ) );
		}

		$title = sanitize_text_field( $data['title'] ?? '' );
		if ( empty( $title ) ) {
			return new \WP_Error( 'invalid_group_title', esc_html__( 'Specify group name', 'masterstudy-lms-learning-management-system-pro' ) );
		}

		$emails = $this->normalize_emails( $data['emails'] ?? array() );
		if ( empty( $emails ) ) {
			return new \WP_Error( 'invalid_group_emails', esc_html__( 'Add at least one valid email address.', 'masterstudy-lms-learning-management-system-pro' ) );
		}

		$group_id = wp_insert_post(
			array(
				'post_title' => $title,
				'post_type'  => $this->post_type,
			),
			true
		);

		if ( is_wp_error( $group_id ) ) {
			return $group_id;
		}

		update_post_meta( $group_id, 'author_id', get_current_user_id() );
		update_post_meta( $group_id, 'emails', implode( ',', $emails ) );

		$this->sync_group_members( (int) $group_id, $emails, array() );
		do_action( 'stm_lms_adding_enterprice_groups', $group_id );

		return $this->get_group_for_edit( (int) $group_id );
	}

	/**
	 * @return array<string, mixed>|\WP_Error
	 */
	public function update( int $group_id, array $data ) {
		if ( ! $this->is_group_manage_allowed() ) {
			return new \WP_Error( 'group_manage_not_allowed', esc_html__( 'Group management is disabled.', 'masterstudy-lms-learning-management-system-pro' ) );
		}

		$group = $this->get_group( $group_id );
		if ( ! $group ) {
			return new \WP_Error( 'group_not_found', esc_html__( 'Enterprise group not found.', 'masterstudy-lms-learning-management-system-pro' ) );
		}

		$title = sanitize_text_field( $data['title'] ?? '' );
		if ( empty( $title ) ) {
			return new \WP_Error( 'invalid_group_title', esc_html__( 'Specify group name', 'masterstudy-lms-learning-management-system-pro' ) );
		}

		$emails = $this->normalize_emails( $data['emails'] ?? array() );
		if ( empty( $emails ) ) {
			return new \WP_Error( 'invalid_group_emails', esc_html__( 'Add at least one valid email address.', 'masterstudy-lms-learning-management-system-pro' ) );
		}

		$result = wp_update_post(
			array(
				'ID'         => $group_id,
				'post_title' => $title,
				'post_type'  => $this->post_type,
			),
			true
		);

		if ( is_wp_error( $result ) ) {
			return $result;
		}

		$old_emails = $this->get_group_member_emails( $group_id );

		update_post_meta( $group_id, 'emails', implode( ',', $emails ) );

		$this->sync_group_members( $group_id, $emails, $old_emails );
		do_action( 'stm_lms_adding_enterprice_groups', $group_id );

		return $this->get_group_for_edit( $group_id );
	}

	/**
	 * @return true|\WP_Error
	 */
	public function delete( int $group_id ) {
		$group = $this->get_group( $group_id );
		if ( ! $group ) {
			return new \WP_Error( 'group_not_found', esc_html__( 'Enterprise group not found.', 'masterstudy-lms-learning-management-system-pro' ) );
		}

		if ( ! $this->is_group_manage_allowed() ) {
			return new \WP_Error( 'group_manage_not_allowed', esc_html__( 'Group management is disabled.', 'masterstudy-lms-learning-management-system-pro' ) );
		}

		$wpdb  = $this->wpdb();
		$table = $this->user_courses_table();

		$wpdb->query(
			$wpdb->prepare(
				// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Internal table name from user_courses_table().
				"DELETE FROM {$table} WHERE enterprise_id = %d",
				$group_id
			)
		);

		wp_delete_post( $group_id, true );

		return true;
	}

	/**
	 * @return true|\WP_Error
	 */
	public function change_admin( int $group_id, int $user_id ) {
		$group = $this->get_group( $group_id );
		if ( ! $group ) {
			return new \WP_Error( 'group_not_found', esc_html__( 'Enterprise group not found.', 'masterstudy-lms-learning-management-system-pro' ) );
		}

		$member = get_userdata( $user_id );
		if ( ! $member instanceof WP_User || ! $this->user_belongs_to_group( $group_id, $member ) ) {
			return new \WP_Error( 'invalid_group_member', esc_html__( 'Selected user is not a member of this group.', 'masterstudy-lms-learning-management-system-pro' ) );
		}

		if ( ! $this->is_group_manage_allowed() ) {
			return new \WP_Error( 'group_manage_not_allowed', esc_html__( 'Group management is disabled.', 'masterstudy-lms-learning-management-system-pro' ) );
		}

		$group_course_ids = $this->get_group_course_ids( $group_id );

		foreach ( $group_course_ids as $course_id ) {
			if ( ! $this->user_has_group_course( $group_id, $user_id, $course_id ) ) {
				\STM_LMS_Course::add_user_course( $course_id, $user_id, 0, 0, false, $group_id );
			}
		}

		update_post_meta( $group_id, 'author_id', $user_id );

		return true;
	}

	/**
	 * @return true|\WP_Error
	 */
	public function delete_member( int $group_id, int $user_id ) {
		$group = $this->get_group( $group_id );
		$user  = get_userdata( $user_id );

		if ( ! $group ) {
			return new \WP_Error( 'group_not_found', esc_html__( 'Enterprise group not found.', 'masterstudy-lms-learning-management-system-pro' ) );
		}

		if ( ! $user instanceof WP_User || ! $this->user_belongs_to_group( $group_id, $user ) ) {
			return new \WP_Error( 'invalid_group_member', esc_html__( 'Selected user is not a member of this group.', 'masterstudy-lms-learning-management-system-pro' ) );
		}

		if ( ! $this->is_group_manage_allowed() ) {
			return new \WP_Error( 'group_manage_not_allowed', esc_html__( 'Group management is disabled.', 'masterstudy-lms-learning-management-system-pro' ) );
		}

		$emails = $this->get_group_member_emails( $group_id );
		$emails = array_values(
			array_filter(
				$emails,
				static function ( string $email ) use ( $user ) {
					return sanitize_email( $user->user_email ) !== $email;
				}
			)
		);

		$wpdb  = $this->wpdb();
		$table = $this->user_courses_table();

		$wpdb->delete(
			$table,
			array(
				'user_id'       => $user_id,
				'enterprise_id' => $group_id,
			)
		);

		update_post_meta( $group_id, 'emails', implode( ',', $emails ) );

		$handler = $this->get_legacy_handler();
		if ( $handler ) {
			$handler->group_removed_email( $user_id, $group_id );
		}

		return true;
	}

	/**
	 * @return true|\WP_Error
	 */
	public function add_member_course( int $group_id, int $user_id, int $course_id ) {
		$group = $this->get_group( $group_id );
		$user  = get_userdata( $user_id );

		if ( ! $group ) {
			return new \WP_Error( 'group_not_found', esc_html__( 'Enterprise group not found.', 'masterstudy-lms-learning-management-system-pro' ) );
		}

		if ( ! $user instanceof WP_User || ! $this->user_belongs_to_group( $group_id, $user ) ) {
			return new \WP_Error( 'invalid_group_member', esc_html__( 'Selected user is not a member of this group.', 'masterstudy-lms-learning-management-system-pro' ) );
		}

		if ( PostType::COURSE !== get_post_type( $course_id ) ) {
			return new \WP_Error( 'invalid_course', esc_html__( 'Course not found.', 'masterstudy-lms-learning-management-system-pro' ) );
		}

		if ( ! $this->is_group_manage_allowed() ) {
			return new \WP_Error( 'group_manage_not_allowed', esc_html__( 'Group management is disabled.', 'masterstudy-lms-learning-management-system-pro' ) );
		}

		if ( ! $this->user_has_group_course( $group_id, $user_id, $course_id ) ) {
			\STM_LMS_Course::add_user_course( $course_id, $user_id, 0, 0, false, $group_id );

			$handler = $this->get_legacy_handler();
			if ( $handler ) {
				$handler->course_added_email( $user_id, $group_id, $course_id );
			}
		}

		return true;
	}

	/**
	 * @return true|\WP_Error
	 */
	public function delete_member_course( int $group_id, int $user_id, int $course_id ) {
		$group = $this->get_group( $group_id );
		$user  = get_userdata( $user_id );

		if ( ! $group ) {
			return new \WP_Error( 'group_not_found', esc_html__( 'Enterprise group not found.', 'masterstudy-lms-learning-management-system-pro' ) );
		}

		if ( ! $user instanceof WP_User || ! $this->user_belongs_to_group( $group_id, $user ) ) {
			return new \WP_Error( 'invalid_group_member', esc_html__( 'Selected user is not a member of this group.', 'masterstudy-lms-learning-management-system-pro' ) );
		}

		if ( ! $this->is_group_manage_allowed() ) {
			return new \WP_Error( 'group_manage_not_allowed', esc_html__( 'Group management is disabled.', 'masterstudy-lms-learning-management-system-pro' ) );
		}

		$wpdb  = $this->wpdb();
		$table = $this->user_courses_table();

		$wpdb->delete(
			$table,
			array(
				'user_id'       => $user_id,
				'course_id'     => $course_id,
				'enterprise_id' => $group_id,
			)
		);

		$handler = $this->get_legacy_handler();
		if ( $handler ) {
			$handler->course_removed_email( $user_id, $group_id, $course_id );
		}

		return true;
	}

	/**
	 * @return array<string, mixed>
	 */
	private function serialize_list_item( int $group_id ): array {
		$post_date = get_post_field( 'post_date', $group_id );

		return array(
			'id'             => $group_id,
			'title'          => html_entity_decode( get_the_title( $group_id ), ENT_QUOTES, 'UTF-8' ),
			'courses_count'  => count( $this->get_group_course_ids( $group_id ) ),
			'users_count'    => count( $this->get_group_users( $group_id, true ) ),
			'date'           => get_post_time( 'c', false, $group_id ),
			'date_formatted' => \STM_LMS_Helpers::format_date( $post_date ),
		);
	}

	/**
	 * @param array<int, int> $group_course_ids
	 *
	 * @return array<string, mixed>
	 */
	private function serialize_member( WP_User $member, int $group_id, array $group_course_ids ): array {
		$courses = array();
		$admin   = $this->get_group_admin( $group_id );

		foreach ( $group_course_ids as $course_id ) {
			$courses[] = array(
				'course_id' => $course_id,
				'title'     => html_entity_decode( get_the_title( $course_id ), ENT_QUOTES, 'UTF-8' ),
				'image_url' => (string) get_the_post_thumbnail_url( $course_id, 'img-300-225' ),
				'assigned'  => $this->user_has_group_course( $group_id, $member->ID, $course_id ),
			);
		}

		return array(
			'user'     => array(
				'id'         => $member->ID,
				'login'      => ! empty( $member->display_name ) ? $member->display_name : $member->user_login,
				'email'      => $member->user_email,
				'avatar_url' => (string) \STM_LMS_User::get_avatar_url( $member->ID ),
			),
			'is_admin' => $admin instanceof WP_User && $admin->ID === $member->ID,
			'courses'  => $courses,
		);
	}

	/**
	 * @return array<int, string>
	 */
	private function get_group_member_emails( int $group_id ): array {
		$emails = $this->get_group_stored_emails( $group_id );
		$author = $this->get_group_admin( $group_id );

		if ( $author instanceof WP_User ) {
			$author_email = sanitize_email( $author->user_email );
			$emails       = array_filter(
				$emails,
				static function ( string $email ) use ( $author_email ): bool {
					return $email !== $author_email;
				}
			);
		}

		return array_values( $emails );
	}

	/**
	 * @return array<int, string>
	 */
	private function get_group_stored_emails( int $group_id ): array {
		$emails = get_post_meta( $group_id, 'emails', true );
		if ( empty( $emails ) ) {
			return array();
		}

		$emails = is_array( $emails ) ? $emails : explode( ',', (string) $emails );
		$emails = array_map( 'sanitize_email', $emails );
		$emails = array_filter( $emails );

		return array_values( array_unique( $emails ) );
	}

	/**
	 * @return array<int, WP_User>
	 */
	private function get_group_users( int $group_id, bool $include_admin = false ): array {
		$members = array();

		if ( $include_admin ) {
			$admin = $this->get_group_admin( $group_id );

			if ( $admin instanceof WP_User ) {
				$members[ $admin->ID ] = $admin;
			}
		}

		foreach ( $this->get_group_stored_emails( $group_id ) as $email ) {
			$user = get_user_by( 'email', $email );
			if ( $user instanceof WP_User ) {
				$members[ $user->ID ] = $user;
			}
		}

		return array_values( $members );
	}

	/**
	 * @return array<int, WP_User>
	 */
	private function get_group_members( int $group_id ): array {
		return $this->get_group_users( $group_id, true );
	}

	private function get_group_admin( int $group_id ): ?WP_User {
		$admin = get_userdata( (int) get_post_meta( $group_id, 'author_id', true ) );

		return $admin instanceof WP_User ? $admin : null;
	}

	/**
	 * @return array<int, int>
	 */
	private function get_group_course_ids( int $group_id ): array {
		$wpdb      = $this->wpdb();
		$table     = $this->user_courses_table();
		$author_id = (int) get_post_meta( $group_id, 'author_id', true );

		if ( $author_id > 0 ) {
			$course_ids = $wpdb->get_col(
				$wpdb->prepare(
					// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Internal table name from user_courses_table().
					"SELECT DISTINCT course_id FROM {$table} WHERE enterprise_id = %d AND user_id = %d",
					$group_id,
					$author_id
				)
			);

			if ( ! empty( $course_ids ) ) {
				return array_map( 'intval', $course_ids );
			}
		}

		$course_ids = $wpdb->get_col(
			$wpdb->prepare(
				// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Internal table name from user_courses_table().
				"SELECT DISTINCT course_id FROM {$table} WHERE enterprise_id = %d",
				$group_id
			)
		);

		return array_map( 'intval', $course_ids );
	}

	private function user_has_group_course( int $group_id, int $user_id, int $course_id ): bool {
		$wpdb  = $this->wpdb();
		$table = $this->user_courses_table();

		$count = $wpdb->get_var(
			$wpdb->prepare(
				// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Internal table name from user_courses_table().
				"SELECT COUNT(*) FROM {$table} WHERE user_id = %d AND course_id = %d AND enterprise_id = %d",
				$user_id,
				$course_id,
				$group_id
			)
		);

		return (int) $count > 0;
	}

	private function user_belongs_to_group( int $group_id, WP_User $user ): bool {
		return in_array( sanitize_email( $user->user_email ), $this->get_group_member_emails( $group_id ), true );
	}

	/**
	 * @param mixed $emails
	 *
	 * @return array<int, string>
	 */
	private function normalize_emails( $emails ): array {
		$emails = is_array( $emails ) ? $emails : array();
		$emails = array_map( 'sanitize_email', $emails );
		$emails = array_filter(
			$emails,
			static function ( string $email ): bool {
				return (bool) filter_var( $email, FILTER_VALIDATE_EMAIL );
			}
		);

		return array_slice( array_values( array_unique( $emails ) ), 0, $this->get_users_limit() );
	}

	/**
	 * @param array<int, string> $emails
	 * @param array<int, string> $old_emails
	 */
	private function sync_group_members( int $group_id, array $emails, array $old_emails ): void {
		$new_emails = array_values( array_diff( $emails, $old_emails ) );
		$old_emails = array_values( array_diff( $old_emails, $emails ) );

		if ( ! empty( $new_emails ) ) {
			$this->create_or_invite_group_users( $group_id, $new_emails );
			$this->assign_group_courses_to_emails( $group_id, $new_emails );
		}

		if ( ! empty( $old_emails ) ) {
			$this->remove_group_users( $group_id, $old_emails );
		}
	}

	/**
	 * @param array<int, string> $emails
	 */
	private function create_or_invite_group_users( int $group_id, array $emails ): void {
		foreach ( $emails as $email ) {
			$user = get_user_by( 'email', $email );

			if ( $user instanceof WP_User ) {
				$this->send_group_invite_email( $group_id, $user );
				continue;
			}

			$username = $this->generate_username( $email );
			$password = wp_generate_password();
			$user_id  = wp_create_user( $username, $password, $email );

			if ( is_wp_error( $user_id ) ) {
				continue;
			}

			$user = get_userdata( (int) $user_id );

			if ( $user instanceof WP_User ) {
				$this->send_new_user_credentials_email( $group_id, $user, $password );
			}
		}
	}

	/**
	 * @param array<int, string> $emails
	 */
	private function assign_group_courses_to_emails( int $group_id, array $emails ): void {
		$group_course_ids = $this->get_group_course_ids( $group_id );

		if ( empty( $group_course_ids ) ) {
			return;
		}

		foreach ( $emails as $email ) {
			$user = get_user_by( 'email', $email );

			if ( ! $user instanceof WP_User ) {
				continue;
			}

			foreach ( $group_course_ids as $course_id ) {
				if ( $this->user_has_group_course( $group_id, $user->ID, $course_id ) ) {
					continue;
				}

				\STM_LMS_Course::add_user_course( $course_id, $user->ID, 0, 0, false, $group_id );

				$handler = $this->get_legacy_handler();
				if ( $handler ) {
					$handler->course_added_email( $user->ID, $group_id, $course_id );
				}
			}
		}
	}

	/**
	 * @param array<int, string> $emails
	 */
	private function remove_group_users( int $group_id, array $emails ): void {
		$wpdb  = $this->wpdb();
		$table = $this->user_courses_table();

		foreach ( $emails as $email ) {
			$user = get_user_by( 'email', $email );

			if ( ! $user instanceof WP_User ) {
				continue;
			}

			$wpdb->delete(
				$table,
				array(
					'user_id'       => $user->ID,
					'enterprise_id' => $group_id,
				)
			);

			$handler = $this->get_legacy_handler();
			if ( $handler ) {
				$handler->group_removed_email( $user->ID, $group_id );
			}
		}
	}

	private function generate_username( string $email ): string {
		$email_parts = explode( '@', $email );
		$base        = sanitize_user( $email_parts[0] ?? '', true );
		$base        = ! empty( $base ) ? $base : 'enterprise-user';
		$username    = $base;
		$suffix      = 1;

		while ( username_exists( $username ) ) {
			$username = "{$base}-{$suffix}";
			++$suffix;
		}

		return $username;
	}

	private function send_group_invite_email( int $group_id, WP_User $user ): void {
		$subject    = esc_html__( '{{user_login}}, You Have Been Invited to a Group!', 'masterstudy-lms-learning-management-system-pro' );
		$message    = wp_kses_post(
			'Dear {{user_login}},<br>
			You’ve just been added to the enterprise group {{group_name}} by {{admin_login}}.<br>
			As a member of this group, you now have full access to all courses purchased under it.<br>
			If you believe this was a mistake or have any questions, please don’t hesitate to contact us.'
		);
		$email_data = array(
			'admin_login' => $this->get_group_admin_login( $group_id ),
			'group_name'  => get_the_title( $group_id ),
			'user_login'  => \STM_LMS_Helpers::masterstudy_lms_get_user_full_name_or_login( $user->ID ),
			'blog_name'   => \STM_LMS_Helpers::masterstudy_lms_get_site_name(),
			'site_url'    => \MS_LMS_Email_Template_Helpers::link( \STM_LMS_Helpers::masterstudy_lms_get_site_url() ),
			'date'        => gmdate( 'Y-m-d H:i:s' ),
		);

		\STM_LMS_Helpers::send_email(
			$user->user_email,
			$subject,
			$message,
			'stm_lms_new_group_invite',
			$email_data
		);
	}

	private function send_new_user_credentials_email( int $group_id, WP_User $user, string $password ): void {
		$subject = esc_html__( 'New user credentials for enterprise group', 'masterstudy-lms-learning-management-system-pro' );
		$message = sprintf(
			/* translators: %1$s Username, %2$s Password, %3$s Site URL */
			esc_html__( 'Login: %1$s Password: %2$s Site URL: %3$s', 'masterstudy-lms-learning-management-system-pro' ),
			$user->user_login,
			$password,
			get_bloginfo( 'url' )
		);
		$email_data = array(
			'admin_login' => $this->get_group_admin_login( $group_id ),
			'group_name'  => get_the_title( $group_id ),
			'blog_name'   => \STM_LMS_Helpers::masterstudy_lms_get_site_name(),
			'site_url'    => \MS_LMS_Email_Template_Helpers::link( \STM_LMS_Helpers::masterstudy_lms_get_site_url() ),
			'date'        => gmdate( 'Y-m-d H:i:s' ),
			'username'    => $user->user_login,
			'password'    => $password,
			'login_url'   => \MS_LMS_Email_Template_Helpers::link( \STM_LMS_Helpers::masterstudy_lms_get_login_url() ),
		);

		\STM_LMS_Helpers::send_email(
			$user->user_email,
			$subject,
			$message,
			'stm_lms_new_user_creds',
			$email_data
		);
	}

	private function get_group_admin_login( int $group_id ): string {
		$admin = \STM_LMS_User::get_current_user( (int) get_post_meta( $group_id, 'author_id', true ) );

		return (string) ( $admin['login'] ?? '' );
	}

	private function get_users_limit(): int {
		if ( class_exists( '\STM_LMS_Enterprise_Courses' ) ) {
			return (int) \STM_LMS_Enterprise_Courses::get_group_common_limit();
		}

		return 5;
	}

	private function is_group_manage_allowed(): bool {
		return (bool) apply_filters( 'stm_lms_allow_group_manage', true );
	}

	private function current_user_can_manage_group( int $group_id ): bool {
		if ( current_user_can( 'manage_options' ) ) {
			return true;
		}

		return $group_id > 0 && get_current_user_id() === (int) get_post_meta( $group_id, 'author_id', true );
	}

	private function wpdb(): wpdb {
		global $wpdb;

		return $wpdb;
	}

	private function user_courses_table(): string {
		return stm_lms_user_courses_name( $this->wpdb() );
	}

	private function get_legacy_handler(): ?\STM_LMS_Enterprise_Courses {
		if ( ! class_exists( '\STM_LMS_Enterprise_Courses' ) ) {
			return null;
		}

		return ( new \ReflectionClass( \STM_LMS_Enterprise_Courses::class ) )->newInstanceWithoutConstructor();
	}
}
