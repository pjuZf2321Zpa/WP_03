<?php

namespace BitApps\IntegrationsPro\Core\Util;

use DateTime;
use DateTimeZone;

final class DateTimeHelper
{
    private $_dateFormat;

    private $_timeFormat;

    private $_timezone;

    private $_currentTime;

    private $_currentFormat;

    public function __construct()
    {
        $this->_dateFormat = get_option('date_format');
        $this->_timeFormat = get_option('time_format');
        $this->_timezone = self::wp_timezone();
        $this->_currentTime = current_time('mysql');
        $this->_currentFormat = 'Y-m-d H:i:s';
    }

    public function getFormated($dateString, $currentFormat, $currentTZ, $expectedFormat, $expectedTZ)
    {
        if ($currentFormat === false) {
            $dateObject = new DateTime($dateString, $currentTZ);
        } else {
            $dateObject = DateTime::createFromFormat($currentFormat, $dateString, $currentTZ);
        }

        if (!\is_null($expectedTZ)) {
            $dateObject->setTimezone($expectedTZ);
        }

        if ($dateObject) {
            return $dateObject->format($expectedFormat);
        }

        return false;
    }

    public static function wp_timezone_string()
    {
        if (\function_exists('wp_timezone_string')) {
            return wp_timezone_string();
        }

        $timezone_string = get_option('timezone_string');

        if ($timezone_string) {
            return $timezone_string;
        }

        $offset = (float) get_option('gmt_offset');
        $hours = (int) $offset;
        $minutes = ($offset - $hours);

        $sign = ($offset < 0) ? '-' : '+';
        $abs_hour = abs($hours);
        $abs_mins = abs($minutes * 60);

        return \sprintf('%s%02d:%02d', $sign, $abs_hour, $abs_mins);
    }

    public static function wp_timezone()
    {
        if (\function_exists('wp_timezone')) {
            return wp_timezone();
        }

        return new DateTimeZone(self::wp_timezone_string());
    }
}
