<?php

namespace FluentCartPro\App\Services;

class CoreCompat
{
    /**
     * FluentCart module API 3 registers the fct-* components Pro's runtime-compiled templates use.
     */
    public static function hasFctComponents(): bool
    {
        return defined('FLUENTCART_MODULE_API') && FLUENTCART_MODULE_API >= 3;
    }

    /**
     * Plain-HTML stand-in for a runtime template on an older FluentCart: it compiles on any core.
     */
    public static function updateNoticeTemplate(): string
    {
        return '<div class="fct-alert fct-alert-warning"><p class="m-0">'
            . esc_html__('Update FluentCart to the latest version to use this setting.', 'fluent-cart-pro')
            . '</p></div>';
    }
}
