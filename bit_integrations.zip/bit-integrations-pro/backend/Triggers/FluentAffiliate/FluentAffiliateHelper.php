<?php

namespace BitApps\IntegrationsPro\Triggers\FluentAffiliate;

class FluentAffiliateHelper
{
    public static function FormatAffiliateData($affiliate, $oldStatus = null)
    {
        $helperClass = bit_integrations_get_class('Core\\Util\\Helper');

        $affiliate = (array) $helperClass::jsonEncodeDecode($affiliate);

        if (!empty($oldStatus)) {
            $affiliate['old_status'] = $oldStatus;
        }

        return $helperClass::prepareFetchFormatFields($affiliate);
    }

    public static function FormatAffiliateUpdatedData($affiliate, $updatedBy, $updatedData)
    {
        $helperClass = bit_integrations_get_class('Core\\Util\\Helper');

        $affiliate = (array) $helperClass::jsonEncodeDecode($affiliate);

        $mergedData = array_merge(
            ['updated_by' => $updatedBy],
            $affiliate,
            $updatedData
        );

        return $helperClass::prepareFetchFormatFields($mergedData);
    }

    public static function isPluginInstalled()
    {
        return \defined('FLUENT_AFFILIATE_VERSION');
    }
}
