<?php

namespace MasterStudy\Lms\Pro\AddonsPlus\Notifications;

use MasterStudy\Lms\Repositories\CurriculumRepository;
use MasterStudy\Lms\Pro\AddonsPlus\Notifications\Services\CourseAccessExpirationSweep;
use MasterStudy\Lms\Pro\AddonsPlus\Notifications\Services\Dispatcher;
use MasterStudy\Lms\Pro\AddonsPlus\Notifications\Services\RecipientResolver;
use MasterStudy\Lms\Pro\AddonsPlus\Notifications\Services\Scheduler;

final class EventListeners {
	public static function register(): void {
		add_action( 'add_user_course', array( __CLASS__, 'course_enrolled' ), 10, 2 );
		add_action( 'masterstudy_lms_before_delete_user_course', array( __CLASS__, 'cancel_enrollment' ), 10, 2 );
		add_action( 'stm_lms_assignment_passed', array( __CLASS__, 'assignment_graded' ), 10, 3 );
		add_action( 'stm_lms_assignment_not_passed', array( __CLASS__, 'assignment_graded' ), 10, 3 );
		add_action( 'stm_lms_announcement_ready_to_send', array( __CLASS__, 'announcement_posted' ), 10, 3 );
		add_action( 'masterstudy_lms_after_lesson_comment_added', array( __CLASS__, 'qa_comment_added' ), 10, 6 );
		add_action( 'masterstudy_lms_instructor_application_submitted', array( __CLASS__, 'instructor_application_submitted' ), 10, 3 );
		add_action( 'masterstudy_lms_instructor_application_status_updated', array( __CLASS__, 'instructor_application_status_updated' ), 10, 4 );
		add_action( 'masterstudy_lms_enterprise_request_received', array( __CLASS__, 'enterprise_request_received' ), 10, 1 );
		add_action( 'masterstudy_lms_coming_soon_course', array( __CLASS__, 'preordered_course_released' ), 20, 1 );
		add_action( 'masterstudy_lms_assignment_submitted_for_review', array( __CLASS__, 'assignment_submitted_for_review' ), 10, 5 );
		add_action( 'masterstudy_lms_assignment_timer_created', array( __CLASS__, 'assignment_timer_created' ), 10, 4 );
		add_action( 'masterstudy_lms_course_update_access', array( __CLASS__, 'course_access_updated' ), 10, 2 );
		add_action( 'save_post', array( __CLASS__, 'item_saved' ), 20, 3 );
		add_action( 'masterstudy_notifications_scheduled_event', array( Scheduler::class, 'run' ), 10, 4 );
		add_action( 'masterstudy_notifications_scheduled_target_event', array( Scheduler::class, 'run_target' ), 10, 5 );
	}

	public static function course_enrolled( $user_id, $course_id ): void {
		self::guard(
			static function () use ( $user_id, $course_id ): void {
				$user_id   = absint( $user_id );
				$course_id = absint( $course_id );
				$context   = self::course_context( $course_id );

				( new Dispatcher() )->dispatch(
					'course_enrolled',
					array( $user_id ),
					$context,
					"course_enrolled:{$user_id}:{$course_id}"
				);

				self::schedule_course_access_expiration( $course_id, array( $user_id ) );
				self::schedule_course_items( $course_id, array( $user_id ) );
			}
		);
	}

	public static function cancel_enrollment( $user_id, $course_id ): void {
		self::guard(
			static function () use ( $user_id, $course_id ): void {
				$user_id   = absint( $user_id );
				$course_id = absint( $course_id );

				( new Dispatcher() )->dispatch(
					'cancel_enrollment',
					array( $user_id ),
					self::course_context( $course_id ),
					"cancel_enrollment:{$user_id}:{$course_id}:" . time()
				);
			}
		);
	}

	public static function assignment_graded( $student_id, $user_assignment_id, $course_id ): void {
		self::guard(
			static function () use ( $student_id, $user_assignment_id, $course_id ): void {
				$student_id         = absint( $student_id );
				$user_assignment_id = absint( $user_assignment_id );
				$course_id          = absint( $course_id );
				$assignment_id      = absint( get_post_meta( $user_assignment_id, 'assignment_id', true ) );

				( new Dispatcher() )->dispatch(
					'assignment_graded',
					array( $student_id ),
					self::course_context(
						$course_id,
						$assignment_id,
						array(
							'assignment_id'      => $assignment_id,
							'user_assignment_id' => $user_assignment_id,
							'assignment_name'    => get_the_title( $assignment_id ),
						)
					),
					"assignment_graded:{$student_id}:{$user_assignment_id}"
				);
			}
		);
	}

	public static function announcement_posted( $course_id, $user_id, $mail ): void {
		self::guard(
			static function () use ( $course_id, $user_id ): void {
				$course_id = absint( $course_id );

				( new Dispatcher() )->dispatch_to_course_students(
					'new_announcement_posted',
					$course_id,
					self::course_context( $course_id, 0, array( 'actor_user_id' => absint( $user_id ) ) ),
					"announcement_posted:{$course_id}:" . time()
				);
			}
		);
	}

	public static function qa_comment_added( $comment, $parent_comment, $lesson_id, $course_id, $user, $is_reply_to_own_comment ): void {
		self::guard(
			static function () use ( $comment, $parent_comment, $lesson_id, $course_id, $user, $is_reply_to_own_comment ): void {
				if ( ! $parent_comment || $is_reply_to_own_comment ) {
					return;
				}

				$recipient_id = absint( $parent_comment->user_id );

				if ( $recipient_id <= 0 ) {
					return;
				}

				( new Dispatcher() )->dispatch(
					'qa_message_answered',
					array( $recipient_id ),
					self::course_context(
						absint( $course_id ),
						absint( $lesson_id ),
						array(
							'lesson_name'   => get_the_title( $lesson_id ),
							'actor_user_id' => absint( $user['id'] ?? 0 ),
						)
					),
					'qa_message_answered:' . absint( $comment['comment_ID'] ?? 0 )
				);
			}
		);
	}

	public static function instructor_application_submitted( $user_id, $status, $data ): void {
		self::guard(
			static function () use ( $user_id, $status ): void {
				if ( 'approved' === $status ) {
					( new Dispatcher() )->dispatch(
						'instructor_application_accepted',
						array( absint( $user_id ) ),
						array( 'actor_user_id' => absint( $user_id ) ),
						"instructor_application_accepted:{$user_id}:" . time()
					);

					return;
				}

				if ( 'pending' !== $status ) {
					return;
				}

				( new Dispatcher() )->dispatch(
					'instructor_application_received',
					( new RecipientResolver() )->admins(),
					array(
						'actor_user_id' => absint( $user_id ),
						'context_label' => self::user_name( absint( $user_id ) ),
					),
					"instructor_application_received:{$user_id}:" . time()
				);
			}
		);
	}

	public static function instructor_application_status_updated( $user_id, $status, $admin_message, $history ): void {
		self::guard(
			static function () use ( $user_id, $status ): void {
				$trigger_key = '';

				if ( 'approved' === $status ) {
					$trigger_key = 'instructor_application_accepted';
				} elseif ( 'rejected' === $status ) {
					$trigger_key = 'instructor_application_rejected';
				}

				if ( '' === $trigger_key ) {
					return;
				}

				( new Dispatcher() )->dispatch(
					$trigger_key,
					array( absint( $user_id ) ),
					array(
						'actor_user_id' => get_current_user_id(),
					),
					"{$trigger_key}:{$user_id}:" . time()
				);
			}
		);
	}

	public static function enterprise_request_received( $data ): void {
		self::guard(
			static function () use ( $data ): void {
				( new Dispatcher() )->dispatch(
					'new_enterprise_request',
					( new RecipientResolver() )->admins(),
					array( 'context_label' => sanitize_text_field( $data['name'] ?? $data['email'] ?? '' ) ),
					'new_enterprise_request:' . time()
				);
			}
		);
	}

	public static function preordered_course_released( $course_id ): void {
		self::guard(
			static function () use ( $course_id ): void {
				$course_id    = absint( $course_id );
				$resolver     = new RecipientResolver();
				$emails       = get_post_meta( $course_id, 'coming_soon_student_emails', true );
				$email_values = array();

				foreach ( (array) $emails as $email ) {
					$email_values[] = is_array( $email ) ? ( $email['email'] ?? '' ) : $email;
				}

				( new Dispatcher() )->dispatch_to_course_students_and_users(
					'preordered_course_released',
					$course_id,
					$resolver->users_by_emails( $email_values ),
					self::course_context( $course_id ),
					"preordered_course_released:{$course_id}"
				);
			}
		);
	}

	public static function assignment_submitted_for_review( $user_assignment_id, $course_id, $assignment_id, $student_id, $instructor_id ): void {
		self::guard(
			static function () use ( $user_assignment_id, $course_id, $assignment_id, $student_id, $instructor_id ): void {
				$course_id     = absint( $course_id );
				$assignment_id = absint( $assignment_id );

				( new Dispatcher() )->dispatch(
					'new_assignment_submission',
					array( absint( $instructor_id ) ),
					self::course_context(
						$course_id,
						$assignment_id,
						array(
							'assignment_id'      => $assignment_id,
							'user_assignment_id' => absint( $user_assignment_id ),
							'assignment_name'    => get_the_title( $assignment_id ),
							'actor_user_id'      => absint( $student_id ),
						)
					),
					"new_assignment_submission:{$user_assignment_id}"
				);
			}
		);
	}

	public static function assignment_timer_created( $user_id, $user_assignment_id, $start_ts, $end_ts ): void {
		self::guard(
			static function () use ( $user_id, $user_assignment_id, $end_ts ): void {
				$user_assignment_id = absint( $user_assignment_id );
				$assignment_id      = absint( get_post_meta( $user_assignment_id, 'assignment_id', true ) );
				$course_id          = absint( get_post_meta( $user_assignment_id, 'course_id', true ) );

				( new Scheduler() )->schedule_reminders(
					'assignment_deadline_approaching',
					absint( $end_ts ),
					array( absint( $user_id ) ),
					self::course_context(
						$course_id,
						$assignment_id,
						array(
							'assignment_id'      => $assignment_id,
							'user_assignment_id' => $user_assignment_id,
							'assignment_name'    => get_the_title( $assignment_id ),
						)
					),
					"assignment_deadline:{$user_id}:{$user_assignment_id}:{$end_ts}"
				);
			}
		);
	}

	public static function course_access_updated( $course_id, $data ): void {
		self::guard(
			static function (): void {
				CourseAccessExpirationSweep::ensure_scheduled();
			}
		);
	}

	public static function item_saved( $post_id, $post, $update ): void {
		self::guard(
			static function () use ( $post_id, $post ): void {
				if ( wp_is_post_revision( $post_id ) || 'auto-draft' === $post->post_status ) {
					return;
				}

				$course_ids = class_exists( CurriculumRepository::class )
					? ( new CurriculumRepository() )->get_post_course_ids( absint( $post_id ) )
					: array();

				foreach ( $course_ids as $course_id ) {
					self::schedule_course_items_for_target( absint( $course_id ), array( absint( $post_id ) ) );
				}
			}
		);
	}

	private static function schedule_course_access_expiration( int $course_id, array $user_ids ): void {
		if ( $course_id <= 0 || empty( $user_ids ) || ! class_exists( 'STM_LMS_Course' ) || ! class_exists( 'STM_LMS_Helpers' ) || ! function_exists( 'stm_lms_get_user_course' ) ) {
			return;
		}

		$duration = (int) \STM_LMS_Course::get_course_duration_time( $course_id );

		if ( $duration <= 0 ) {
			return;
		}

		$scheduler = new Scheduler();

		foreach ( $user_ids as $user_id ) {
			$user_course = \STM_LMS_Helpers::simplify_db_array( stm_lms_get_user_course( absint( $user_id ), $course_id, array( 'start_time' ) ) );
			$start_time  = absint( $user_course['start_time'] ?? 0 );
			$expires_at  = $start_time + $duration;

			$scheduler->schedule(
				$expires_at,
				'course_access_expired',
				absint( $user_id ),
				self::course_context( $course_id, 0, array( 'target_timestamp' => $expires_at ) ),
				"course_access_expired:{$user_id}:{$course_id}:{$expires_at}"
			);
		}
	}

	private static function schedule_course_items( int $course_id, array $user_ids, array $only_item_ids = array() ): void {
		if ( $course_id <= 0 || empty( $user_ids ) || ! class_exists( CurriculumRepository::class ) ) {
			return;
		}

		$curriculum = ( new CurriculumRepository() )->get_curriculum( $course_id );
		$materials  = $curriculum['materials'] ?? array();
		$item_ids   = array_filter( array_map( 'absint', $only_item_ids ) );

		foreach ( $materials as $material ) {
			$item_id = absint( $material['post_id'] ?? 0 );

			if ( $item_id <= 0 || ( ! empty( $item_ids ) && ! in_array( $item_id, $item_ids, true ) ) ) {
				continue;
			}

			self::schedule_item( $course_id, $item_id, $user_ids );
		}
	}

	private static function schedule_course_items_for_target( int $course_id, array $only_item_ids = array() ): void {
		if ( $course_id <= 0 || ! class_exists( CurriculumRepository::class ) ) {
			return;
		}

		$curriculum = ( new CurriculumRepository() )->get_curriculum( $course_id );
		$materials  = $curriculum['materials'] ?? array();
		$item_ids   = array_filter( array_map( 'absint', $only_item_ids ) );

		foreach ( $materials as $material ) {
			$item_id = absint( $material['post_id'] ?? 0 );

			if ( $item_id <= 0 || ( ! empty( $item_ids ) && ! in_array( $item_id, $item_ids, true ) ) ) {
				continue;
			}

			self::schedule_item_for_target( $course_id, $item_id );
		}
	}

	private static function schedule_item( int $course_id, int $item_id, array $user_ids ): void {
		$lesson_type = (string) get_post_meta( $item_id, 'type', true );
		$scheduler   = new Scheduler();

		if ( 'stream' === $lesson_type && class_exists( 'STM_LMS_Live_Streams' ) ) {
			$starts_at = absint( \STM_LMS_Live_Streams::stream_start_time( $item_id ) );
			$scheduler->schedule_reminders(
				'live_lesson_starting_soon',
				$starts_at,
				$user_ids,
				self::course_context( $course_id, $item_id, array( 'lesson_name' => get_the_title( $item_id ) ) ),
				"live_lesson_starting_soon:{$course_id}:{$item_id}:{$starts_at}"
			);
			return;
		}

		if ( 'zoom_conference' === $lesson_type && class_exists( 'MSLMS_StmZoom' ) ) {
			$data      = \MSLMS_StmZoom::meeting_time_data( $item_id );
			$starts_at = absint( $data['meeting_date'] ?? 0 );
			self::schedule_meeting_reminders( $scheduler, $course_id, $item_id, $user_ids, $starts_at );
			return;
		}

		if ( 'stm-google-meets' === get_post_type( $item_id ) && function_exists( 'masterstudy_lms_google_meet_start_time' ) ) {
			self::schedule_meeting_reminders( $scheduler, $course_id, $item_id, $user_ids, absint( masterstudy_lms_google_meet_start_time( $item_id ) ) );
			return;
		}

		if ( class_exists( 'STM_LMS_Sequential_Drip_Content' ) ) {
			$starts_at = absint( \STM_LMS_Sequential_Drip_Content::lesson_start_time( $item_id, $course_id ) );

			foreach ( $user_ids as $user_id ) {
				$scheduler->schedule(
					$starts_at,
					'lesson_now_available',
					absint( $user_id ),
					self::course_context(
						$course_id,
						$item_id,
						array(
							'lesson_name'      => get_the_title( $item_id ),
							'target_timestamp' => $starts_at,
						)
					),
					"lesson_now_available:{$user_id}:{$course_id}:{$item_id}:{$starts_at}"
				);
			}
		}
	}

	private static function schedule_item_for_target( int $course_id, int $item_id ): void {
		$lesson_type = (string) get_post_meta( $item_id, 'type', true );
		$scheduler   = new Scheduler();

		if ( 'stream' === $lesson_type && class_exists( 'STM_LMS_Live_Streams' ) ) {
			$starts_at = absint( \STM_LMS_Live_Streams::stream_start_time( $item_id ) );
			$scheduler->schedule_target_reminders(
				'live_lesson_starting_soon',
				$starts_at,
				'course_students',
				$course_id,
				self::course_context( $course_id, $item_id, array( 'lesson_name' => get_the_title( $item_id ) ) ),
				"live_lesson_starting_soon:{$course_id}:{$item_id}:{$starts_at}"
			);
			return;
		}

		if ( 'zoom_conference' === $lesson_type && class_exists( 'MSLMS_StmZoom' ) ) {
			$data      = \MSLMS_StmZoom::meeting_time_data( $item_id );
			$starts_at = absint( $data['meeting_date'] ?? 0 );
			self::schedule_meeting_target_reminders( $scheduler, $course_id, $item_id, $starts_at );
			return;
		}

		if ( 'stm-google-meets' === get_post_type( $item_id ) && function_exists( 'masterstudy_lms_google_meet_start_time' ) ) {
			self::schedule_meeting_target_reminders( $scheduler, $course_id, $item_id, absint( masterstudy_lms_google_meet_start_time( $item_id ) ) );
			return;
		}

		if ( class_exists( 'STM_LMS_Sequential_Drip_Content' ) ) {
			$starts_at = absint( \STM_LMS_Sequential_Drip_Content::lesson_start_time( $item_id, $course_id ) );

			$scheduler->schedule_target(
				$starts_at,
				'lesson_now_available',
				'course_students',
				$course_id,
				self::course_context(
					$course_id,
					$item_id,
					array(
						'lesson_name'      => get_the_title( $item_id ),
						'target_timestamp' => $starts_at,
					)
				),
				"lesson_now_available:{$course_id}:{$item_id}:{$starts_at}"
			);
		}
	}

	private static function schedule_meeting_reminders( Scheduler $scheduler, int $course_id, int $item_id, array $user_ids, int $starts_at ): void {
		$scheduler->schedule_reminders(
			'meeting_starting_soon',
			$starts_at,
			$user_ids,
			self::course_context( $course_id, $item_id, array( 'meeting_name' => get_the_title( $item_id ) ) ),
			"meeting_starting_soon:{$course_id}:{$item_id}:{$starts_at}"
		);
	}

	private static function schedule_meeting_target_reminders( Scheduler $scheduler, int $course_id, int $item_id, int $starts_at ): void {
		$scheduler->schedule_target_reminders(
			'meeting_starting_soon',
			$starts_at,
			'course_students',
			$course_id,
			self::course_context( $course_id, $item_id, array( 'meeting_name' => get_the_title( $item_id ) ) ),
			"meeting_starting_soon:{$course_id}:{$item_id}:{$starts_at}"
		);
	}

	private static function course_context( int $course_id, int $item_id = 0, array $extra = array() ): array {
		return array_merge(
			array(
				'course_id'     => $course_id,
				'item_id'       => $item_id,
				'course_name'   => get_the_title( $course_id ),
				'context_label' => get_the_title( $course_id ),
			),
			$extra
		);
	}

	private static function user_name( int $user_id ): string {
		$user = get_userdata( $user_id );

		return $user ? (string) $user->display_name : '';
	}

	private static function guard( callable $callback ): void {
		try {
			$callback();
		} catch ( \Throwable $error ) {
			return;
		}
	}
}
