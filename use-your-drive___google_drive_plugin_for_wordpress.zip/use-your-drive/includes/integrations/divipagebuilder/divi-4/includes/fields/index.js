import ShortcodeField from './ShortcodeField/ShortcodeField';

export default [ShortcodeField];