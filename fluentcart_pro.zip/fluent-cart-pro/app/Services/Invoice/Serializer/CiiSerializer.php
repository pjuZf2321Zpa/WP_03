<?php

declare(strict_types=1);

namespace FluentCartPro\App\Services\Invoice\Serializer;

if (!defined('ABSPATH')) {
    exit;
}

use FluentCartPro\App\Services\Invoice\Domain\CalculatedTotals;
use FluentCartPro\App\Services\Invoice\Domain\Customer;
use FluentCartPro\App\Services\Invoice\Domain\DocumentCharge;
use FluentCartPro\App\Services\Invoice\Domain\En16931Invoice;
use FluentCartPro\App\Services\Invoice\Domain\InvoiceLine;
use FluentCartPro\App\Services\Invoice\Domain\Money;
use FluentCartPro\App\Services\Invoice\Domain\Seller;
use FluentCartPro\App\Services\Invoice\Profile\InvoiceProfileInterface;

/**
 * CII (Cross Industry Invoice) serializer. Maps DTO + CalculatedTotals to XML only; no calculations.
 * Element order follows Factur-X 1.07.3 EN 16931 sequence.
 */
final class CiiSerializer implements InvoiceSerializerInterface
{
    public function serialize(En16931Invoice $invoice, CalculatedTotals $totals, InvoiceProfileInterface $profile): string
    {
        $doc = new \DOMDocument('1.0', 'UTF-8');
        $doc->formatOutput = false;

        $root = $doc->createElement('rsm:CrossIndustryInvoice');
        $root->setAttribute('xmlns:rsm', 'urn:un:unece:uncefact:data:standard:CrossIndustryInvoice:100');
        $root->setAttribute('xmlns:ram', 'urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:100');
        $root->setAttribute('xmlns:udt', 'urn:un:unece:uncefact:data:standard:UnqualifiedDataType:100');
        $root->setAttribute('xmlns:qdt', 'urn:un:unece:uncefact:data:standard:QualifiedDataType:100');
        $doc->appendChild($root);

        $context = $doc->createElement('rsm:ExchangedDocumentContext');
        $guideline = $doc->createElement('ram:GuidelineSpecifiedDocumentContextParameter');
        $this->appendText($doc, $guideline, 'ram:ID', $profile->getProfileId());
        $context->appendChild($guideline);
        $root->appendChild($context);

        $docHeader = $doc->createElement('rsm:ExchangedDocument');
        $this->appendText($doc, $docHeader, 'ram:ID', $invoice->invoiceNumber);
        $this->appendText($doc, $docHeader, 'ram:TypeCode', $invoice->typeCode);
        $issueDate = $this->formatDate($invoice->issueDate);
        if ($issueDate !== null) {
            $issueDateTime = $doc->createElement('ram:IssueDateTime');
            $dateString = $doc->createElement('udt:DateTimeString', $issueDate);
            $dateString->setAttribute('format', '102');
            $issueDateTime->appendChild($dateString);
            $docHeader->appendChild($issueDateTime);
        }
        $root->appendChild($docHeader);

        $trade = $doc->createElement('rsm:SupplyChainTradeTransaction');

        $lineIndex = 1;
        foreach ($invoice->lines as $line) {
            $trade->appendChild($this->createLineItem($doc, $line, $lineIndex++, $invoice->currency));
        }

        $agreement = $doc->createElement('ram:ApplicableHeaderTradeAgreement');
        $this->appendTextIfNonEmpty($doc, $agreement, 'ram:BuyerReference', $invoice->buyer_reference);

        $this->appendSellerParty($doc, $agreement, $invoice->seller);
        $this->appendBuyerParty($doc, $agreement, $invoice->buyer);

        if ($invoice->purchase_order_ref !== '') {
            $buyerOrder = $doc->createElement('ram:BuyerOrderReferencedDocument');
            $this->appendText($doc, $buyerOrder, 'ram:IssuerAssignedID', $invoice->purchase_order_ref);
            $agreement->appendChild($buyerOrder);
        }
        $trade->appendChild($agreement);

        // ApplicableHeaderTradeDelivery is mandatory in CII but may have no real delivery data.
        // PEPPOL-EN16931-R008 flags any ram:* element that is completely empty (no text, no children),
        // so we always add an ActualDeliverySupplyChainEvent using the invoice issue date as a fallback.
        $delivery = $doc->createElement('ram:ApplicableHeaderTradeDelivery');
        $deliveryDateStr = $this->formatDate($invoice->issueDate);
        if ($deliveryDateStr !== null) {
            $deliveryEvent    = $doc->createElement('ram:ActualDeliverySupplyChainEvent');
            $deliveryDateTime = $doc->createElement('ram:OccurrenceDateTime');
            $deliveryDateEl   = $doc->createElement('udt:DateTimeString', $deliveryDateStr);
            $deliveryDateEl->setAttribute('format', '102');
            $deliveryDateTime->appendChild($deliveryDateEl);
            $deliveryEvent->appendChild($deliveryDateTime);
            $delivery->appendChild($deliveryEvent);
        }
        $trade->appendChild($delivery);

        $settlement = $doc->createElement('ram:ApplicableHeaderTradeSettlement');
        $this->appendText($doc, $settlement, 'ram:InvoiceCurrencyCode', $invoice->currency);
        $paymentMeans = $doc->createElement('ram:SpecifiedTradeSettlementPaymentMeans');
        $this->appendText($doc, $paymentMeans, 'ram:TypeCode', $invoice->paymentMeans !== '' ? $invoice->paymentMeans : '1');
        $settlement->appendChild($paymentMeans);

        foreach ($totals->taxSummaries as $tax) {
            $taxEl = $doc->createElement('ram:ApplicableTradeTax');
            $this->appendText($doc, $taxEl, 'ram:CalculatedAmount', $tax->taxAmount->toDecimalString());
            $this->appendText($doc, $taxEl, 'ram:TypeCode', 'VAT');
            // BT-120 exemption reason text — CII sequence: after TypeCode, before BasisAmount.
            $this->appendTextIfNonEmpty($doc, $taxEl, 'ram:ExemptionReason', $tax->exemptionReasonText);
            $this->appendText($doc, $taxEl, 'ram:BasisAmount', $tax->taxableAmount->toDecimalString());
            $this->appendText($doc, $taxEl, 'ram:CategoryCode', $tax->taxCategory);
            // BT-121 exemption reason code — CII sequence: after CategoryCode, before RateApplicablePercent.
            $this->appendTextIfNonEmpty($doc, $taxEl, 'ram:ExemptionReasonCode', $tax->exemptionReasonCode);
            $this->appendText($doc, $taxEl, 'ram:RateApplicablePercent', $tax->taxPercent);
            $settlement->appendChild($taxEl);
        }

        // Document-level charges (e.g., shipping)
        foreach ($invoice->charges as $charge) {
            if ($charge instanceof DocumentCharge) {
                $chargeEl = $doc->createElement('ram:SpecifiedTradeAllowanceCharge');
                $chargeIndicator = $doc->createElement('ram:ChargeIndicator');
                $this->appendText($doc, $chargeIndicator, 'udt:Indicator', 'true');
                $chargeEl->appendChild($chargeIndicator);
                $this->appendText($doc, $chargeEl, 'ram:ActualAmount', $charge->amount->toDecimalString());
                if ($charge->reason !== '') {
                    $this->appendText($doc, $chargeEl, 'ram:Reason', $charge->reason);
                }
                $chargeTax = $doc->createElement('ram:CategoryTradeTax');
                $this->appendText($doc, $chargeTax, 'ram:TypeCode', 'VAT');
                $this->appendText($doc, $chargeTax, 'ram:CategoryCode', $charge->taxCategory);
                $this->appendText($doc, $chargeTax, 'ram:RateApplicablePercent', $charge->taxPercent);
                $chargeEl->appendChild($chargeTax);
                $settlement->appendChild($chargeEl);
            }
        }

        if ($invoice->payment_term !== '') {
            $paymentTerms = $doc->createElement('ram:SpecifiedTradePaymentTerms');
            $this->appendText($doc, $paymentTerms, 'ram:Description', $invoice->payment_term);
            $settlement->appendChild($paymentTerms);
        }

        // Monetary summation fields are intentionally recomputed here from the invoice DTO
        // rather than derived solely from CalculatedTotals. This is because the EN 16931
        // monetary summation (BR-CO-10, BR-CO-13) requires individual sub-totals
        // (LineTotalAmount, ChargeTotalAmount, AllowanceTotalAmount, TaxBasisTotalAmount)
        // that the engine does not expose separately — it only returns grand totals.
        //
        // Note on charge tax interplay: the engine puts charge nets into their tax category
        // basis before computing category VAT, and the serializer adds the full charge
        // net amount to TaxBasisTotalAmount here (BR-CO-13: basis includes charge net, not
        // charge tax). These are intentionally separate concerns — the engine owns VAT math,
        // the serializer owns XML structure per the CII spec.
        $chargeTotalCents = 0;

        foreach ($invoice->charges as $charge) {
            if ($charge instanceof DocumentCharge) {
                $chargeTotalCents += $charge->amount->getAmountInCents();
            }
        }

        $allowanceTotalCents = 0;

        $chargeTotal    = new Money($invoice->currency, $chargeTotalCents);
        $allowanceTotal = new Money($invoice->currency, $allowanceTotalCents);

        // TaxBasisTotalAmount = LineTotalAmount - AllowanceTotalAmount + ChargeTotalAmount (BR-CO-13)
        // Intentionally recomputed from invoice data rather than engine output to match CII schema requirements.
        $taxBasisCents = $totals->totalNet->getAmountInCents() - $allowanceTotalCents + $chargeTotalCents;
        $taxBasis      = new Money($invoice->currency, $taxBasisCents);

        $summary = $doc->createElement('ram:SpecifiedTradeSettlementHeaderMonetarySummation');
        $this->appendText($doc, $summary, 'ram:LineTotalAmount', $totals->totalNet->toDecimalString());
        $this->appendText($doc, $summary, 'ram:ChargeTotalAmount', $chargeTotal->toDecimalString());
        $this->appendText($doc, $summary, 'ram:AllowanceTotalAmount', $allowanceTotal->toDecimalString());
        $this->appendText($doc, $summary, 'ram:TaxBasisTotalAmount', $taxBasis->toDecimalString());
        if ($invoice->currency !== '') {
            $taxTotalNode = $doc->createElement('ram:TaxTotalAmount');
            $taxTotalNode->appendChild($doc->createTextNode($totals->totalVat->toDecimalString()));
            $taxTotalNode->setAttribute('currencyID', $invoice->currency);
            $summary->appendChild($taxTotalNode);
        }
        if ($totals->rounding->getAmountInCents() !== 0) {
            $this->appendText($doc, $summary, 'ram:RoundingAmount', $totals->rounding->toDecimalString());
        }
        $this->appendText($doc, $summary, 'ram:GrandTotalAmount', $totals->grandTotal->toDecimalString());
        if ($totals->totalPrepaid->getAmountInCents() > 0) {
            $this->appendText($doc, $summary, 'ram:TotalPrepaidAmount', $totals->totalPrepaid->toDecimalString());
        }
        $this->appendText($doc, $summary, 'ram:DuePayableAmount', $totals->duePayable->toDecimalString());
        $settlement->appendChild($summary);
        $trade->appendChild($settlement);

        $root->appendChild($trade);

        return $doc->saveXML();
    }

    private function createLineItem(\DOMDocument $doc, InvoiceLine $line, int $lineId, string $currency): \DOMElement
    {
        $lineEl = $doc->createElement('ram:IncludedSupplyChainTradeLineItem');
        $lineDoc = $doc->createElement('ram:AssociatedDocumentLineDocument');
        $this->appendText($doc, $lineDoc, 'ram:LineID', (string) $lineId);
        $lineEl->appendChild($lineDoc);

        $product = $doc->createElement('ram:SpecifiedTradeProduct');
        $this->appendText($doc, $product, 'ram:Name', $line->name !== '' ? $line->name : '-');
        $lineEl->appendChild($product);

        $lineAgreement = $doc->createElement('ram:SpecifiedLineTradeAgreement');
        $price = $doc->createElement('ram:NetPriceProductTradePrice');
        $this->appendText($doc, $price, 'ram:ChargeAmount', $line->netUnitPrice->toDecimalString());
        if ($line->priceBaseQuantity !== 1) {
            $basis = $doc->createElement('ram:BasisQuantity', (string) $line->priceBaseQuantity);
            $basis->setAttribute('unitCode', $line->unitCode);
            $price->appendChild($basis);
        }
        $lineAgreement->appendChild($price);
        $lineEl->appendChild($lineAgreement);

        $lineDelivery = $doc->createElement('ram:SpecifiedLineTradeDelivery');
        $quantity = $doc->createElement('ram:BilledQuantity', (string) $line->quantity);
        $quantity->setAttribute('unitCode', $line->unitCode);
        $lineDelivery->appendChild($quantity);
        $lineEl->appendChild($lineDelivery);

        $lineSettlement = $doc->createElement('ram:SpecifiedLineTradeSettlement');
        $lineTax = $doc->createElement('ram:ApplicableTradeTax');
        $this->appendText($doc, $lineTax, 'ram:TypeCode', 'VAT');
        $this->appendText($doc, $lineTax, 'ram:CategoryCode', $line->taxCategory);
        $this->appendText($doc, $lineTax, 'ram:RateApplicablePercent', $line->taxPercent);
        $lineSettlement->appendChild($lineTax);
        foreach (['false' => $line->lineAllowance, 'true' => $line->lineCharge] as $indicator => $amount) {
            if ($amount->getAmountInCents() <= 0) {
                continue;
            }
            $adjustment = $doc->createElement('ram:SpecifiedTradeAllowanceCharge');
            $chargeIndicator = $doc->createElement('ram:ChargeIndicator');
            $this->appendText($doc, $chargeIndicator, 'udt:Indicator', $indicator);
            $adjustment->appendChild($chargeIndicator);
            $this->appendText($doc, $adjustment, 'ram:ActualAmount', $amount->toDecimalString());
            $this->appendText($doc, $adjustment, 'ram:Reason', $indicator === 'true' ? 'Charge' : 'Discount');
            $lineSettlement->appendChild($adjustment);
        }
        $lineTotals = $doc->createElement('ram:SpecifiedTradeSettlementLineMonetarySummation');
        $this->appendText($doc, $lineTotals, 'ram:LineTotalAmount', $line->lineTotal->toDecimalString());
        $lineSettlement->appendChild($lineTotals);
        $lineEl->appendChild($lineSettlement);

        return $lineEl;
    }

    private function appendSellerParty(\DOMDocument $doc, \DOMElement $agreement, Seller $seller): void
    {
        $sellerParty = $doc->createElement('ram:SellerTradeParty');
        $this->appendText($doc, $sellerParty, 'ram:Name', $seller->name !== '' ? $seller->name : 'N/A');

        // SpecifiedLegalOrganization (BT-30) must appear BEFORE PostalTradeAddress in the CII sequence.
        $hasSellerVat = $seller->vat_id !== null && $seller->vat_id !== '';
        $hasLegalReg  = $seller->legal_registration_id !== '';
        if ($hasLegalReg) {
            $legalReg = $doc->createElement('ram:SpecifiedLegalOrganization');
            $idEl     = $doc->createElement('ram:ID');
            $idEl->appendChild($doc->createTextNode($seller->legal_registration_id));
            if ($seller->legal_registration_scheme !== '') {
                $idEl->setAttribute('schemeID', $seller->legal_registration_scheme);
            }
            $legalReg->appendChild($idEl);
            $sellerParty->appendChild($legalReg);
        } elseif (!$hasSellerVat) {
            // No VAT ID and no legal registration — use seller name as BT-30 fallback (BR-CO-26).
            $legalRegFallback = $doc->createElement('ram:SpecifiedLegalOrganization');
            $this->appendText($doc, $legalRegFallback, 'ram:ID', $seller->name !== '' ? $seller->name : 'N/A');
            $sellerParty->appendChild($legalRegFallback);
        }

        $sellerAddress = $doc->createElement('ram:PostalTradeAddress');
        $this->appendTextIfNonEmpty($doc, $sellerAddress, 'ram:PostcodeCode', $seller->zip);
        $this->appendTextIfNonEmpty($doc, $sellerAddress, 'ram:LineOne', $seller->address_line_1);
        $this->appendTextIfNonEmpty($doc, $sellerAddress, 'ram:LineTwo', $seller->address_line_2);
        $this->appendTextIfNonEmpty($doc, $sellerAddress, 'ram:CityName', $seller->city);
        if ($seller->country_code !== '') {
            $this->appendText($doc, $sellerAddress, 'ram:CountryID', $seller->country_code);
        }
        $sellerParty->appendChild($sellerAddress);

        if ($hasSellerVat) {
            $taxReg = $doc->createElement('ram:SpecifiedTaxRegistration');
            $idEl   = $doc->createElement('ram:ID');
            $idEl->appendChild($doc->createTextNode($seller->vat_id));
            $idEl->setAttribute('schemeID', 'VA');
            $taxReg->appendChild($idEl);
            $sellerParty->appendChild($taxReg);
        }

        $agreement->appendChild($sellerParty);
    }

    private function appendBuyerParty(\DOMDocument $doc, \DOMElement $agreement, Customer $buyer): void
    {
        $buyerParty = $doc->createElement('ram:BuyerTradeParty');
        $buyerName = $buyer->company_name !== '' ? $buyer->company_name : $buyer->customer_name;
        if ($buyerName === '') {
            $buyerName = $buyer->email !== '' ? $buyer->email : 'Unknown';
        }
        $this->appendText($doc, $buyerParty, 'ram:Name', $buyerName);

        if ($buyer->country_code !== '') {
            $buyerAddress = $doc->createElement('ram:PostalTradeAddress');
            $this->appendTextIfNonEmpty($doc, $buyerAddress, 'ram:PostcodeCode', $buyer->zip);
            $this->appendTextIfNonEmpty($doc, $buyerAddress, 'ram:LineOne', $buyer->address_line_1);
            $this->appendTextIfNonEmpty($doc, $buyerAddress, 'ram:LineTwo', $buyer->address_line_2);
            $this->appendTextIfNonEmpty($doc, $buyerAddress, 'ram:CityName', $buyer->city);
            $this->appendText($doc, $buyerAddress, 'ram:CountryID', $buyer->country_code);
            $buyerParty->appendChild($buyerAddress);
        }

        if ($buyer->buyer_vat_id !== '') {
            $buyerTaxReg = $doc->createElement('ram:SpecifiedTaxRegistration');
            $buyerTaxId  = $doc->createElement('ram:ID');
            $buyerTaxId->appendChild($doc->createTextNode($buyer->buyer_vat_id));
            $buyerTaxId->setAttribute('schemeID', 'VA');
            $buyerTaxReg->appendChild($buyerTaxId);
            $buyerParty->appendChild($buyerTaxReg);
        }
        $agreement->appendChild($buyerParty);
    }

    private function appendText(\DOMDocument $doc, \DOMElement $parent, string $name, string $value): void
    {
        $element = $doc->createElement($name);
        $element->appendChild($doc->createTextNode($value));
        $parent->appendChild($element);
    }

    private function appendTextIfNonEmpty(\DOMDocument $doc, \DOMElement $parent, string $name, string $value): void
    {
        $trimmed = trim($value);
        if ($trimmed === '') {
            return;
        }
        $this->appendText($doc, $parent, $name, $trimmed);
    }

    private function formatDate(?string $value): ?string
    {
        if ($value === null || $value === '') {
            return null;
        }
        try {
            $date = new \DateTime($value);
            return $date->format('Ymd');
        } catch (\Exception $e) {
            return null;
        }
    }
}
