<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Core\Util\Route;
use BitApps\IntegrationsPro\Triggers\FluentAffiliate\FluentAffiliateController;

Route::get('fluent_affiliate/get', [FluentAffiliateController::class, 'getAllTasks']);
