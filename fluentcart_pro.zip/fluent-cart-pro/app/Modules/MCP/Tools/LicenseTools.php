<?php

namespace FluentCartPro\App\Modules\MCP\Tools;

use FluentCart\App\Modules\MCP\Support\AdvancedSearch;
use FluentCart\App\Modules\MCP\Support\MCPHelper;
use FluentCart\App\Modules\MCP\Support\PermissionGate;
use FluentCartPro\App\Modules\Licensing\Models\License;

/**
 * License tools (FluentCart Pro) — find software licenses, then load one fully.
 *
 * Read-only surface, registered only when the Licensing module is active (see
 * MCPInit). Reuses the free plugin's MCPHelper envelope/pagination/money and
 * the existing `licenses/view` capability, so the MCP user sees exactly what an
 * admin with that role sees in Settings → Licenses.
 *
 * Parameter design mirrors list-subscriptions: filter on what owners triage by
 * (status, product, customer) plus the expiry window — expiring_before is the
 * renewal-prevention lever ("which licenses lapse in the next 30 days?").
 *
 * Statuses are the stored values active|inactive|expired|disabled. "expiring"
 * is a computed display state (past expiration_date, not yet expired) and is
 * not a stored value — use expiring_before to find those.
 */
class LicenseTools
{
    const STATUSES = ['active', 'inactive', 'expired', 'disabled'];

    public static function definitions()
    {
        return [
            'fluent-cart/list-licenses' => [
                'label'       => __('List Licenses', 'fluent-cart-pro'),
                'description' => __('Find and filter software licenses. Compact rows: license key, product, customer, status, activation usage, expiration. Use expiring_before to find licenses lapsing soon, pair status=active with it for at-risk renewals. For conditions these flat filters cannot express (OR groups, activation-count comparisons, customer name, variation-level product filters, labels) pass advanced_filters — call get-search-schema entity=licenses first.', 'fluent-cart-pro'),
                'input_schema' => [
                    'type'       => 'object',
                    'properties' => [
                        'status'           => ['type' => 'string', 'enum' => self::STATUSES],
                        'customer_id'      => ['type' => 'integer'],
                        'product_id'       => ['type' => 'integer'],
                        'license_key'      => ['type' => 'string', 'description' => 'Exact license key lookup.'],
                        'expiring_after'   => ['type' => 'string', 'description' => 'YYYY-MM-DD or ISO 8601, UTC. Expiration on or after this date.'],
                        'expiring_before'  => ['type' => 'string', 'description' => 'YYYY-MM-DD or ISO 8601, UTC. Expiration on or before this date. Use to find upcoming expiries.'],
                        'lifetime'         => ['type' => 'boolean', 'description' => 'true = only lifetime licenses (no expiry); false = only expiring licenses. Omit for both.'],
                        'advanced_filters' => ['type' => 'array', 'items' => ['type' => ['object', 'array']], 'description' => 'Condition groups {property, operator, value} — outer array = OR groups, inner = AND. Call get-search-schema entity=licenses FIRST for properties/operators/format. AND-combines with the other filters here. An empty array means no advanced filter.'],
                        'sort_by'          => ['type' => 'string', 'enum' => ['id', 'expiration_date', 'created_at', 'activation_count'], 'default' => 'id'],
                        'sort_type'        => ['type' => 'string', 'enum' => ['ASC', 'DESC'], 'default' => 'DESC'],
                        'page'             => ['type' => 'integer', 'default' => 1],
                        'per_page'         => ['type' => 'integer', 'default' => 15, 'description' => 'Max 100.'],
                    ],
                ],
                'execute_callback'    => [self::class, 'listLicenses'],
                'permission_callback' => function () {
                    return PermissionGate::can('licenses/view');
                },
                'annotations' => ['readonly' => true],
            ],

            'fluent-cart/get-license' => [
                'label'       => __('Get License', 'fluent-cart-pro'),
                'description' => __('Full detail for one license: status, activation limit and usage, expiration, linked product, customer, order and subscription. Add include[] for activations to see which sites it is active on. Identify by license_id or license_key. The license key is masked by default; pass reveal_key:true to return the full key (requires the licenses/manage capability).', 'fluent-cart-pro'),
                'input_schema' => [
                    'type'       => 'object',
                    'properties' => [
                        'license_id'  => ['type' => 'integer'],
                        'license_key' => ['type' => 'string'],
                        'reveal_key'  => ['type' => 'boolean', 'default' => false, 'description' => 'Return the full, unmasked license key (a bearer secret). Requires the licenses/manage capability; ignored otherwise.'],
                        'include'     => [
                            'type'  => 'array',
                            'items' => ['type' => 'string', 'enum' => ['activations']],
                        ],
                    ],
                ],
                'execute_callback'    => [self::class, 'getLicense'],
                'permission_callback' => function () {
                    return PermissionGate::can('licenses/view');
                },
                'annotations' => ['readonly' => true],
            ],
        ];
    }

    public static function listLicenses($params = [])
    {
        $paging = MCPHelper::pagination($params);

        // advanced_filters routes through the free plugin's AdvancedSearch
        // bridge into the same LicenseFilter engine the admin list uses
        // (validated first — a bad condition errors, never silently drops);
        // the named filters below then AND onto the same query either way.
        $advWarnings = [];
        if (!empty($params['advanced_filters'])) {
            // Pro can be updated ahead of the free core, where AdvancedSearch
            // lives. Guard so a version skew returns a clean error rather than a
            // fatal (the classmap-authoritative autoloader has no PSR-4 fallback).
            if (!class_exists('FluentCart\\App\\Modules\\MCP\\Support\\AdvancedSearch')) {
                return MCPHelper::error(
                    'unsupported',
                    __('advanced_filters requires a newer version of the FluentCart core plugin. Update FluentCart, or omit advanced_filters and use the named filters.', 'fluent-cart-pro')
                );
            }
            $built = AdvancedSearch::buildQuery('licenses', $params['advanced_filters']);
            if (is_wp_error($built)) {
                return $built;
            }
            $query       = $built['query'];
            $advWarnings = $built['warnings'];
        } else {
            $query = License::query();
        }
        $query->with(['customer', 'product']);

        if (!empty($params['status'])) {
            $query->where('status', sanitize_text_field($params['status']));
        }
        if (!empty($params['customer_id'])) {
            $query->where('customer_id', (int) $params['customer_id']);
        }
        if (!empty($params['product_id'])) {
            $query->where('product_id', (int) $params['product_id']);
        }
        if (!empty($params['license_key'])) {
            $query->where('license_key', sanitize_text_field($params['license_key']));
        }
        foreach (['expiring_after' => '>=', 'expiring_before' => '<='] as $field => $op) {
            if (!empty($params[$field])) {
                $date = self::toDbDate($params[$field]);
                if ($date === null) {
                    return MCPHelper::error(
                        'invalid_date',
                        sprintf(
                            /* translators: 1: field name */
                            __('%1$s is not a valid date. Use YYYY-MM-DD or ISO 8601.', 'fluent-cart-pro'),
                            $field
                        ),
                        ['fields' => [$field]]
                    );
                }
                $query->where('expiration_date', $op, $date);
            }
        }

        // Lifetime licenses store NULL — but legacy rows carry '0000-00-00 00:00:00'
        // and mean the same thing, which is why LicenseSchedulerHandler runs an
        // hourly job rewriting them. This is a query builder, so it reads the column
        // raw: License::getExpirationDateAttribute() normalises the two for every
        // model read (including License::isLifetime(), used by formatRow below), and
        // matching only NULL here would report a zero-date license as not-lifetime
        // while its own row says is_lifetime: true. Mirrors License::scopeStatus().
        if (isset($params['lifetime'])) {
            if ($params['lifetime']) {
                // Grouped: a bare orWhere() would OR against the filters above it and
                // match every zero-date license regardless of status or product.
                $query->where(function ($q) {
                    $q->whereNull('expiration_date')
                        ->orWhere('expiration_date', '0000-00-00 00:00:00');
                });
            } else {
                $query->whereNotNull('expiration_date')
                    ->where('expiration_date', '!=', '0000-00-00 00:00:00');
            }
        }

        $sortBy   = self::allowed($params, 'sort_by', ['id', 'expiration_date', 'created_at', 'activation_count'], 'id');
        $sortType = strtoupper(isset($params['sort_type']) ? $params['sort_type'] : 'DESC') === 'ASC' ? 'ASC' : 'DESC';
        $query->orderBy($sortBy, $sortType);
        if ($sortBy !== 'id') {
            $query->orderBy('id', 'DESC');
        }

        $paginator = $query->paginate($paging['per_page'], ['*'], 'page', $paging['page']);
        $total     = MCPHelper::paginatorTotal($paginator);

        $rows = [];
        foreach (MCPHelper::paginatorItems($paginator) as $license) {
            $rows[] = self::formatRow($license);
        }

        $meta = MCPHelper::pagingMeta($paginator);
        if ($advWarnings) {
            $meta['warnings'] = $advWarnings;
        }

        return MCPHelper::envelope(
            sprintf(
                /* translators: %d: number of matching licenses */
                _n('%d license found.', '%d licenses found.', $total, 'fluent-cart-pro'),
                $total
            ),
            ['licenses' => $rows],
            $meta
        );
    }

    /**
     * Mask a license key (a bearer secret) for agent-facing output: keep the last
     * 4 characters for recognition, hide the rest. The full key only leaves the
     * server via get-license with reveal_key + the licenses/manage capability.
     */
    private static function maskKey($key)
    {
        $key = (string) $key;
        $len = strlen($key);
        if ($len === 0) {
            return null;
        }
        if ($len <= 4) {
            return str_repeat('*', $len);
        }
        return str_repeat('*', $len - 4) . substr($key, -4);
    }

    private static function formatRow($license)
    {
        $customer = ($license->relationLoaded('customer') && $license->customer) ? $license->customer : null;
        $product  = ($license->relationLoaded('product') && $license->product) ? $license->product : null;

        return [
            'license_id'       => (int) $license->id,
            'license_key'      => self::maskKey($license->license_key),
            'status'           => $license->status,
            'status_label'     => $license->getHumanReadableStatus(),
            'product'          => $product ? ['id' => (int) $license->product_id, 'title' => $product->post_title] : null,
            'customer'         => $customer ? ['id' => (int) $customer->id, 'name' => MCPHelper::personName($customer), 'email' => $customer->email] : null,
            'activation_limit' => (int) $license->limit,
            'activation_count' => (int) $license->activation_count,
            'expiration_date'  => MCPHelper::toIso8601($license->expiration_date),
            'is_lifetime'      => $license->isLifetime(),
            'created_at'       => MCPHelper::toIso8601($license->created_at),
        ];
    }

    public static function getLicense($params = [])
    {
        $query = License::query()->with(['customer', 'product']);

        if (!empty($params['license_id'])) {
            $query->where('id', (int) $params['license_id']);
        } elseif (!empty($params['license_key'])) {
            $query->where('license_key', sanitize_text_field($params['license_key']));
        } else {
            return MCPHelper::error('missing_identifier', __('license_id or license_key is required.', 'fluent-cart-pro'));
        }

        $license = $query->first();
        if (!$license) {
            return MCPHelper::error('license_not_found', __('No license found for the given identifier.', 'fluent-cart-pro'));
        }

        $include  = isset($params['include']) ? (array) $params['include'] : [];
        $product  = $license->product;
        $customer = $license->customer;

        // Reveal the full key only on explicit request AND a stronger capability;
        // otherwise mask it so the secret never lands in the agent transcript.
        $revealKey = !empty($params['reveal_key']) && PermissionGate::can('licenses/manage');

        $data = [
            'license_id'       => (int) $license->id,
            'license_key'      => $revealKey ? $license->license_key : self::maskKey($license->license_key),
            'status'           => $license->status,
            'status_label'     => $license->getHumanReadableStatus(),
            'product'          => $product ? ['id' => (int) $license->product_id, 'title' => $product->post_title] : null,
            'variation_id'     => $license->variation_id ? (int) $license->variation_id : null,
            'customer'         => $customer ? ['id' => (int) $customer->id, 'name' => MCPHelper::personName($customer), 'email' => $customer->email] : null,
            'order_id'         => $license->order_id ? (int) $license->order_id : null,
            'subscription_id'  => $license->subscription_id ? (int) $license->subscription_id : null,
            'parent_id'        => $license->parent_id ? (int) $license->parent_id : null,
            'activation_limit' => (int) $license->limit,
            'activation_count' => (int) $license->activation_count,
            'expiration_date'  => MCPHelper::toIso8601($license->expiration_date),
            'is_lifetime'      => $license->isLifetime(),
            'created_at'       => MCPHelper::toIso8601($license->created_at),
        ];

        if (in_array('activations', $include, true)) {
            // Activations expose per-site URLs (customer infrastructure). Gate
            // behind the stronger licenses/manage cap, like full-key reveal.
            if (PermissionGate::can('licenses/manage')) {
                $data['activations'] = self::activations($license);
            } else {
                $data['activations_omitted'] = __('Activation site URLs require the licenses/manage capability.', 'fluent-cart-pro');
            }
        }

        return MCPHelper::envelope(self::label($license, $customer, $product), $data);
    }

    private static function activations($license)
    {
        $license->load('activations.site');
        $out = [];
        if (!$license->relationLoaded('activations')) {
            return $out;
        }
        foreach ($license->activations as $activation) {
            $site = $activation->relationLoaded('site') ? $activation->site : null;
            $out[] = [
                'id'                  => (int) $activation->id,
                'site_url'            => $site ? $site->site_url : null,
                'status'              => $activation->status,
                'activation_method'   => $activation->activation_method,
                'last_update_version' => $activation->last_update_version,
                'last_update_date'    => MCPHelper::toIso8601($activation->last_update_date),
            ];
        }
        return $out;
    }

    private static function label($license, $customer, $product)
    {
        $who  = $customer ? MCPHelper::personName($customer) : __('Customer', 'fluent-cart-pro');
        $name = $product ? $product->post_title : __('License', 'fluent-cart-pro');

        return sprintf(
            /* translators: 1: product name, 2: customer name, 3: status */
            __('%1$s license for %2$s — %3$s', 'fluent-cart-pro'),
            $name,
            $who,
            $license->getHumanReadableStatus()
        );
    }

    private static function allowed($params, $key, array $allowed, $default)
    {
        $val = isset($params[$key]) ? $params[$key] : $default;
        return in_array($val, $allowed, true) ? $val : $default;
    }

    private static function toDbDate($value)
    {
        try {
            return (new \DateTime((string) $value, new \DateTimeZone('UTC')))->format('Y-m-d H:i:s');
        } catch (\Exception $e) {
            // Signal invalid input so callers can reject it. Substituting an epoch
            // here would silently turn a typo'd expiring_after into "match all".
            return null;
        }
    }
}
