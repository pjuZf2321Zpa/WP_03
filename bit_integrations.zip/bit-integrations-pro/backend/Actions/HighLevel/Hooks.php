<?php

use BitApps\IntegrationsPro\Actions\HighLevel\HighLevelUtilitiesPro;
use BitApps\IntegrationsPro\Config;
use BitApps\IntegrationsPro\Core\Util\Hooks;

if (!defined('ABSPATH')) {
    exit;
}

// Deprecated since v2.7.8 - use bit_integrations_high_level_* hooks instead
if (bit_integrations_version_below('2.7.8')) {
    Hooks::filter('btcbi_high_level_contact_utilities', [HighLevelUtilitiesPro::class, 'contactUtilities'], 10, 3);
    Hooks::filter('btcbi_high_level_opportunity_utilities', [HighLevelUtilitiesPro::class, 'opportunityUtilities'], 10, 3);
    Hooks::filter('btcbi_high_level_v2_create_contact', [HighLevelUtilitiesPro::class, 'createContact'], 10, 4);
    Hooks::filter('btcbi_high_level_v2_update_contact', [HighLevelUtilitiesPro::class, 'updateContact'], 10, 4);
    Hooks::filter('btcbi_high_level_v2_create_task', [HighLevelUtilitiesPro::class, 'createTask'], 10, 4);
    Hooks::filter('btcbi_high_level_v2_update_task', [HighLevelUtilitiesPro::class, 'updateTask'], 10, 5);
    Hooks::filter('btcbi_high_level_v2_create_opportunity', [HighLevelUtilitiesPro::class, 'createOpportunity'], 10, 5);
    Hooks::filter('btcbi_high_level_v2_update_opportunity', [HighLevelUtilitiesPro::class, 'updateOpportunity'], 10, 5);
}

// New hooks since v2.7.8
Hooks::filter(Config::withFreePrefix('high_level_contact_utilities'), [HighLevelUtilitiesPro::class, 'contactUtilities'], 10, 3);
Hooks::filter(Config::withFreePrefix('high_level_opportunity_utilities'), [HighLevelUtilitiesPro::class, 'opportunityUtilities'], 10, 3);
Hooks::filter(Config::withFreePrefix('high_level_v2_create_contact'), [HighLevelUtilitiesPro::class, 'createContact'], 10, 4);
Hooks::filter(Config::withFreePrefix('high_level_v2_update_contact'), [HighLevelUtilitiesPro::class, 'updateContact'], 10, 4);
Hooks::filter(Config::withFreePrefix('high_level_v2_create_task'), [HighLevelUtilitiesPro::class, 'createTask'], 10, 4);
Hooks::filter(Config::withFreePrefix('high_level_v2_update_task'), [HighLevelUtilitiesPro::class, 'updateTask'], 10, 5);
Hooks::filter(Config::withFreePrefix('high_level_v2_create_opportunity'), [HighLevelUtilitiesPro::class, 'createOpportunity'], 10, 5);
Hooks::filter(Config::withFreePrefix('high_level_v2_update_opportunity'), [HighLevelUtilitiesPro::class, 'updateOpportunity'], 10, 5);
