<?php

namespace MasterStudy\Lms\Pro\addons\assignments\Routing\Swagger;

use MasterStudy\Lms\Routing\Swagger\RequestInterface;
use MasterStudy\Lms\Routing\Swagger\ResponseInterface;
use MasterStudy\Lms\Routing\Swagger\Route;

class GetAdminStudentAssignments extends Route implements RequestInterface, ResponseInterface {
	public function request(): array {
		return array(
			'per_page'   => array(
				'type' => 'integer',
			),
			'page'       => array(
				'type' => 'integer',
			),
			'search'     => array(
				'type' => 'string',
			),
			'status'     => array(
				'type' => 'string',
				'enum' => array( 'all', 'pending', 'passed', 'not_passed', 'draft' ),
			),
			'student_id' => array(
				'type' => 'integer',
			),
			'course_id'  => array(
				'type' => 'integer',
			),
			'date_range' => array(
				'type' => 'string',
			),
			'sort'       => array(
				'type' => 'string',
			),
		);
	}

	public function response(): array {
		return array(
			'items'    => array(
				'type' => 'array',
			),
			'total'    => array(
				'type' => 'integer',
			),
			'pages'    => array(
				'type' => 'integer',
			),
			'page'     => array(
				'type' => 'integer',
			),
			'per_page' => array(
				'type' => 'integer',
			),
		);
	}

	public function get_summary(): string {
		return 'Get Admin Student Assignments';
	}

	public function get_description(): string {
		return 'Returns a paginated list of student assignment attempts for the React admin page.';
	}
}
