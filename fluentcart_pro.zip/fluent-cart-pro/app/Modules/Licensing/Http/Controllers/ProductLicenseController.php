<?php

namespace FluentCartPro\App\Modules\Licensing\Http\Controllers;

use FluentCart\App\Models\ProductMeta;
use FluentCart\Framework\Http\Controller;
use FluentCart\Framework\Http\Request\Request;
use FluentCart\Framework\Support\Arr;
use FluentCart\Framework\Validator\ValidationException;
use FluentCart\App\Models\ProductVariation;
use FluentCart\App\Models\Product;
use FluentCartPro\App\Modules\Licensing\Services\LicenseHelper;
use FluentCartPro\App\Modules\Licensing\Services\ReleaseSignature;

class ProductLicenseController extends Controller
{
    public function getSettings(Request $request, $id): array
    {
        $product = Product::query()->find($id);
        $isBundleProduct = $product && $product->isBundleProduct();

        $settings = LicenseHelper::getProductLicenseConfig($id, 'edit');

        $changeLog = ProductMeta::query()->where('object_id', $id)->where('meta_key', '_fluent_sl_changelog')->first();
        $settings['changelog'] = $changeLog ? $changeLog->meta_value : '';

        $licenseKeys = ProductMeta::query()->where('object_id', $id)->where('meta_key', 'license_keys')->first();
        $settings['license_keys'] = $licenseKeys ? $licenseKeys->meta_value : '';

        // Force disable licensing for bundle products
        if ($isBundleProduct) {
            $settings['enabled'] = 'no';
        }

        return [
            'settings' => $settings,
            'is_bundle_product' => $isBundleProduct,
            // Gates the two release-signing inputs on the screen. Stores that
            // don't sign releases never see the fields, and their saved
            // settings never carry them.
            'signed_releases_enabled' => ReleaseSignature::isEnabled(),
        ];
    }

    public function saveSettings(Request $request, $id): array
    {
        $product = Product::query()->find($id);
        $isBundleProduct = $product && $product->isBundleProduct();

        // Prevent saving license settings for bundle products
        if ($isBundleProduct) {
            return $this->sendError([
                'message' => __('License settings cannot be saved for bundle products. Licenses are generated according to bundle items\' license settings.', 'fluent-cart-pro'),
            ], 422);
        }

        $data = $request->get('settings', []);

        $licenseSettings = Arr::only($data, [
            'enabled', 'version', 'global_update_file', 'variations', 'wp', 'prefix'
        ]);

        $isEnabled = $licenseSettings['enabled'] === 'yes';

        if ($isEnabled) {
            $this->validate($licenseSettings, [
                'version' => 'required'
            ]);
        }

        // The release manifest and its signature are opaque here. They are
        // produced by the vendor's signing step, verified on the customer's
        // site, and stored byte for byte in between — so this path only ever
        // accepts or rejects them, and trims nothing but the whitespace a
        // paste leaves around the edges.
        $manifest = trim((string) Arr::get($data, 'manifest', ''));
        $signature = trim((string) Arr::get($data, 'signature', ''));

        unset($licenseSettings['manifest'], $licenseSettings['signature']);

        // Read before the write, which is what makes the old values
        // unrecoverable. The version is passed to the hook further down; the
        // manifest is what the incoming one is checked against.
        $storedSettings = LicenseHelper::getProductLicenseConfig($id, 'view');
        $previousVersion = (string) Arr::get($storedSettings, 'version', '');

        if ($manifest !== '' || $signature !== '') {
            $signatureErrors = ReleaseSignature::errors(
                $manifest,
                $signature,
                (string) Arr::get($licenseSettings, 'version', ''),
                (string) Arr::get($storedSettings, 'manifest', '')
            );

            // Thrown rather than run through $this->validate(), which only
            // rethrows inside a REST request and otherwise returns and lets
            // the caller carry on — here that would mean writing the very
            // value the check just rejected.
            if ($signatureErrors) {
                throw new ValidationException(
                    reset($signatureErrors),
                    422,
                    null,
                    array_map(function ($message) {
                        return [$message];
                    }, $signatureErrors)
                );
            }

            $licenseSettings['manifest'] = $manifest;
            $licenseSettings['signature'] = $signature;
        }

        $formattedVariations = [];
        foreach ($licenseSettings['variations'] as $variation) {
            $variationId = $variation['variation_id'];
            $formattedVariations[$variationId] = Arr::only($variation, [
                'variation_id', 'activation_limit', 'validity'
            ]);

            $variation = ProductVariation::query()->find($variationId);

            $formattedVariations[$variationId]['validity'] = apply_filters('fluent_cart/license/validity_by_variation', $formattedVariations[$variationId]['validity'], [
                'variation' => $variation
            ]);


            $this->validate($formattedVariations[$variationId], [
                'activation_limit' => [function ($attribute, $value) use ($variation) {
                    if ($value != '' && $value < 0) {
                        return __('Activation limit must be greater than or equal to 0', 'fluent-cart-pro');
                    }
                }],

            ]);


            if ($isEnabled) {
                $this->validate($formattedVariations[$variationId]['validity'], [
                    'unit' => 'required'
                ], [
                    'unit.required' => sprintf(__('Validity type is required for %s.', 'fluent-cart-pro'), $variation['title'])
                ]);
            }
        }

        $licenseSettings['variations'] = $formattedVariations;

        ProductMeta::updateOrCreate(
            ['object_id' => $id, 'meta_key'  => 'license_settings'],
            ['meta_value' => $licenseSettings]
        );

        $version = (string) Arr::get($licenseSettings, 'version', '');

        if ($version !== $previousVersion) {
            /**
             * A product's licensed software version changed — i.e. a release
             * happened, and every site holding a license for this product is
             * now behind.
             *
             * Fires only on an actual change, not on every settings save, so a
             * listener can treat each call as one release. Anything expensive
             * or outbound belongs here rather than in the plugin: this is a
             * public plugin and must not carry a store's endpoints, secrets or
             * CDN details.
             */
            do_action('fluent_cart_sl/product_version_updated', [
                'product_id'       => (int) $id,
                'version'          => $version,
                'previous_version' => $previousVersion,
                'license_settings' => $licenseSettings
            ]);
        }

        $previousManifest = (string) Arr::get($storedSettings, 'manifest', '');
        $previousSignature = (string) Arr::get($storedSettings, 'signature', '');

        if ($manifest !== $previousManifest || $signature !== $previousSignature) {
            /**
             * The signed release artifacts for a product changed.
             *
             * Deliberately separate from product_version_updated, which stays
             * one call per release: this pair can move without the version
             * moving — signing switched on for an already-published version, a
             * corrected paste, a re-sign during a key rotation — and something
             * caching version responses has to treat each of those as an
             * invalidation too. A customer's site verifies the pair and refuses
             * the update when it doesn't match, so a cached response carrying
             * the old pair blocks updates rather than merely being stale.
             *
             * Fires alongside product_version_updated when a release changes
             * both, and on a clear (empty new values) as well, which is equally
             * an invalidation.
             */
            do_action('fluent_cart_sl/product_release_artifacts_updated', [
                'product_id'         => (int) $id,
                'version'            => $version,
                'manifest'           => $manifest,
                'signature'          => $signature,
                'previous_manifest'  => $previousManifest,
                'previous_signature' => $previousSignature
            ]);
        }

        // Both are optional, and a payload omitting them is normal rather than
        // exceptional — reading them directly raised an undefined-key warning
        // on any save that left them out.
        $changelog = Arr::get($data, 'changelog');
        if ($changelog) {
            ProductMeta::updateOrCreate(
                ['object_id' => $id, 'meta_key'  => '_fluent_sl_changelog'],
                ['meta_value' => wp_kses_post($changelog)]
            );
        }

        $licenseKeys = Arr::get($data, 'license_keys');
        if ($licenseKeys) {
            ProductMeta::updateOrCreate(
                ['object_id' => $id, 'meta_key'  => 'license_keys'],
                ['meta_value' => wp_kses_post($licenseKeys)]
            );
        }

        return [
            'message' => __('Settings has been updated successfully.', 'fluent-cart-pro'),
        ];
    }
}
