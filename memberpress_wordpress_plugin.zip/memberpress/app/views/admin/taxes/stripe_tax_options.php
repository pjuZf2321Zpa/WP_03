<?php if (!defined('ABSPATH')) {
    die('You are not allowed to call this page directly.');
} ?>
<tr valign="top">
  <th scope="row">
    <label for="mepr_tax_stripe_enabled"><a href="https://stripe.com/tax" target="_blank"><?php esc_html_e('Enable Stripe Tax', 'memberpress'); ?></a></label>
    <?php
      MeprAppHelper::info_tooltip(
          'mepr-enable-tax-stripe',
          __('Enable Stripe Tax', 'memberpress'),
          __('Use Stripe Tax for automatic tax calculations.', 'memberpress')
      );
        ?>
  </th>
  <td>
    <?php if (empty($stripe_payment_methods)) : ?>
      <p><?php esc_html_e('You must add a Stripe payment method on the Payments tab and connect to Stripe to use Stripe Tax.', 'memberpress'); ?></p>
    <?php else : ?>
      <input type="checkbox" id="mepr_tax_stripe_enabled" name="mepr_tax_stripe_enabled" class="mepr-toggle-checkbox" data-box="mepr_tax_stripe_box" value="1" <?php checked($tax_stripe_enabled); ?> />
      <img src="<?php echo esc_url(MEPR_IMAGES_URL . '/square-loader.gif'); ?>" alt="<?php esc_attr_e('Loading...', 'memberpress'); ?>" id="mepr-loader-validate-stripe-tax-enable" class="mepr_loader" style="display:none;">
    <?php endif; ?>
  </td>
</tr>
<?php if (is_array($stripe_payment_methods) && count($stripe_payment_methods)) : ?>
    <?php
    $multi_stripe_gateway = count($stripe_payment_methods) > 1;
    ?>
  <tr valign="top">
    <td colspan="2" class="mepr-sub-box-wrapper">
      <div id="mepr_tax_stripe_box" class="mepr-sub-box mepr_tax_stripe_box">
        <div class="mepr-arrow mepr-gray mepr-up mepr-sub-box-arrow"> </div>
        <table class="form-table">
          <tbody>
            <tr valign="top">
              <th scope="row">
                <label for="mepr_tax_stripe_payment_method"><?php esc_html_e('Stripe Tax Payment Method', 'memberpress'); ?>*</label>
                <?php
                  MeprAppHelper::info_tooltip(
                      'mepr-tax-stripe-payment-method',
                      __('Stripe Tax Payment Method', 'memberpress'),
                      esc_html__('The selected gateway calculates checkout tax for the entire site and records tax for non-Stripe charges.', 'memberpress')
                  );
                ?>
              </th>
              <td>
                <select id="mepr_tax_stripe_payment_method" name="mepr_tax_stripe_payment_method" class="regular-text">
                  <?php if (!array_key_exists($selected_payment_method, $stripe_payment_methods)) : ?>
                    <option value=""><?php esc_html_e('Please select', 'memberpress'); ?></option>
                  <?php endif; ?>
                  <?php foreach ($stripe_payment_methods as $payment_method_id => $label) : ?>
                    <option value="<?php echo esc_attr($payment_method_id); ?>" <?php echo selected($selected_payment_method, $payment_method_id); ?>><?php echo esc_html($label); ?></option>
                  <?php endforeach; ?>
                </select>
                <img src="<?php echo esc_url(MEPR_IMAGES_URL . '/square-loader.gif'); ?>" alt="<?php esc_attr_e('Loading...', 'memberpress'); ?>" id="mepr-loader-validate-stripe-tax" class="mepr_loader">
                <?php if ($multi_stripe_gateway) : ?>
                <p class="description"><?php esc_html_e('Make sure Stripe Tax is enabled and the same tax jurisdictions are registered in every connected Stripe account. Each Stripe gateway records subscriptions and one-off transactions to its own Stripe account, so checkout tax can differ from what is recorded if registrations don\'t match.', 'memberpress'); ?></p>
                <?php endif; ?>
                <div id="mepr-stripe-tax-inactive-popup" class="mepr-shared-popup mepr-dialog-hidden">
                  <?php if ($multi_stripe_gateway) : ?>
                  <h2 class="mepr-text-align-center"><?php esc_html_e('Stripe Tax is not active on every Stripe account', 'memberpress'); ?></h2>
                  <p class="mepr-text-align-center">
                        <?php
                        printf(
                        // Translators: %1$s: open link tag, %2$s: close link tag, %3$s: open link tag, %4$s: close link tag.
                            esc_html__('Stripe Tax must be enabled in every connected Stripe account, with the same registrations in each. In the Stripe dashboard, ensure that %1$sStripe Tax is enabled%2$s and a %3$sRegistration is added%4$s for each location where tax should be collected — repeat this for every Stripe account you have connected.', 'memberpress'),
                            '<a href="https://dashboard.stripe.com/tax" target="_blank">',
                            '</a>',
                            '<a href="https://dashboard.stripe.com/tax/registrations" target="_blank">',
                            '</a>'
                        );
                        ?>
                  </p>
                  <?php else : ?>
                  <h2 class="mepr-text-align-center"><?php esc_html_e('Stripe Tax is not active on that Stripe account', 'memberpress'); ?></h2>
                  <p class="mepr-text-align-center">
                      <?php
                        printf(
                        // Translators: %1$s: open link tag, %2$s: close link tag, %3$s: open link tag, %4$s: close link tag.
                            esc_html__('In the Stripe dashboard, please ensure that %1$sStripe Tax is enabled%2$s and that a %3$sRegistration is added%4$s for each location where tax should be collected.', 'memberpress'),
                            '<a href="https://dashboard.stripe.com/tax" target="_blank">',
                            '</a>',
                            '<a href="https://dashboard.stripe.com/tax/registrations" target="_blank">',
                            '</a>'
                        );
                        ?>
                  </p>
                  <?php endif; ?>
                </div>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </td>
  </tr>
<?php endif; ?>
