<?php
/** Paid Log retention controls inside the Usage dialog shell. */

use WPAICG\Chat\Utils\LogConfig;
use WPAICG\Lib\Usage\AIPKit_Log_Retention_Ajax_Handler;

if (!defined('ABSPATH')) {
    exit;
}

require_once WPAICG_LIB_DIR . 'usage/log-retention.php';

$aipkit_retention = AIPKit_Log_Retention_Ajax_Handler::status();
$aipkit_retention_periods = LogConfig::get_retention_periods();
// The common choices show first; the rest sit behind "More…" unless one of them is saved.
$aipkit_retention_main = [7, 30, 90, 180, 365];
$aipkit_retention_extra_open = !in_array($aipkit_retention['days'], $aipkit_retention_main, true);
?>
<div
    class="aipkit-modal-body aipkit-modal-shell-body aipkit_usage_retention_body"
    data-aipkit-retention
    data-enabled="<?php echo esc_attr($aipkit_retention['enabled'] ? '1' : '0'); ?>"
    data-days="<?php echo esc_attr((string) $aipkit_retention['days']); ?>"
>
    <div class="aipkit_usage_retention_row">
        <div>
            <label class="aipkit_usage_retention_label" for="aipkit_usage_retention_enabled"><?php esc_html_e('Delete old logs automatically', 'gpt3-ai-content-generator'); ?></label>
            <p class="aipkit_usage_retention_hint"><?php esc_html_e('Runs once a day in the background.', 'gpt3-ai-content-generator'); ?></p>
        </div>
        <label class="aipkit_switch">
            <input type="checkbox" class="aipkit_toggle_switch" id="aipkit_usage_retention_enabled" data-aipkit-retention-enabled data-aipkit-retention-focus <?php checked($aipkit_retention['enabled']); ?> />
            <span class="aipkit_switch_slider" aria-hidden="true"></span>
        </label>
    </div>

    <fieldset class="aipkit_usage_retention_periods" data-aipkit-retention-periods <?php echo $aipkit_retention['enabled'] ? '' : 'hidden'; ?>>
        <legend class="aipkit_usage_retention_label"><?php esc_html_e('Keep logs for', 'gpt3-ai-content-generator'); ?></legend>
        <div class="aipkit_usage_retention_choices">
            <?php foreach ($aipkit_retention_periods as $aipkit_period_days => $aipkit_period_label) : ?>
                <?php $aipkit_period_extra = !in_array((int) $aipkit_period_days, $aipkit_retention_main, true); ?>
                <label class="aipkit_usage_retention_choice" <?php echo $aipkit_period_extra ? 'data-aipkit-retention-extra' : ''; ?> <?php echo $aipkit_period_extra && !$aipkit_retention_extra_open ? 'hidden' : ''; ?>>
                    <input type="radio" name="aipkit_usage_retention_days" value="<?php echo esc_attr((string) $aipkit_period_days); ?>" <?php checked((int) $aipkit_period_days, $aipkit_retention['days']); ?> />
                    <span><?php echo esc_html($aipkit_period_label); ?></span>
                </label>
            <?php endforeach; ?>
            <button type="button" class="aipkit_usage_retention_more" data-aipkit-retention-more aria-expanded="<?php echo $aipkit_retention_extra_open ? 'true' : 'false'; ?>" <?php echo $aipkit_retention_extra_open ? 'hidden' : ''; ?>><?php esc_html_e('More…', 'gpt3-ai-content-generator'); ?></button>
        </div>
    </fieldset>

    <p class="aipkit_usage_retention_warning" data-aipkit-retention-warning role="status" hidden></p>

    <div class="aipkit_usage_retention_status" data-state="<?php echo esc_attr($aipkit_retention['state']); ?>" data-aipkit-retention-status>
        <span class="aipkit_usage_retention_dot" aria-hidden="true"></span>
        <strong data-aipkit-retention-status-text><?php echo esc_html($aipkit_retention['status_text']); ?></strong>
        <span data-aipkit-retention-last-run><?php echo esc_html($aipkit_retention['last_run_label']); ?></span>
    </div>

    <p class="aipkit_usage_retention_note">
        <span data-aipkit-log-storage="summary" hidden></span><span data-aipkit-log-storage="detail" hidden></span>
        <span><?php esc_html_e('AI request history and Cloud credits aren’t affected.', 'gpt3-ai-content-generator'); ?></span>
    </p>
</div>
<div class="aipkit_usage_retention_foot">
    <span class="aipkit_usage_retention_message" data-aipkit-retention-message role="status"></span>
    <button type="button" class="aipkit_usage_btn" data-aipkit-retention-cancel><?php esc_html_e('Cancel', 'gpt3-ai-content-generator'); ?></button>
    <button type="button" class="aipkit_usage_btn aipkit_usage_btn--primary" data-aipkit-retention-save><?php esc_html_e('Save', 'gpt3-ai-content-generator'); ?></button>
</div>
