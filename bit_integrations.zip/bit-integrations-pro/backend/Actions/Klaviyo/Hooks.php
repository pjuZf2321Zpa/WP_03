<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Actions\Klaviyo\KlaviyoHelperPro;
use BitApps\IntegrationsPro\Config;
use BitApps\IntegrationsPro\Core\Util\Hooks;

// Deprecated since v2.7.8 - use bit_integrations_klaviyo_* hooks instead
if (bit_integrations_version_below('2.7.8')) {
    Hooks::filter('btcbi_klaviyo_custom_properties', [KlaviyoHelperPro::class, 'setCustomProperties'], 10, 3);
    Hooks::filter('btcbi_klaviyo_update_profile', [KlaviyoHelperPro::class, 'updateProfile'], 10, 4);
}

// New hooks since v2.7.8
Hooks::filter(Config::withFreePrefix('klaviyo_custom_properties'), [KlaviyoHelperPro::class, 'setCustomProperties'], 10, 3);
Hooks::filter(Config::withFreePrefix('klaviyo_update_profile'), [KlaviyoHelperPro::class, 'updateProfile'], 10, 4);
