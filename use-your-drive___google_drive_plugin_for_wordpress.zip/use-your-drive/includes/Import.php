<?php

/**
 * @author WP Cloud Plugins
 * @copyright Copyright (c) 2023, WP Cloud Plugins
 *
 * @since       3.0
 * @see https://www.wpcloudplugins.com
 */

namespace TheLion\UseyourDrive;

defined('ABSPATH') || exit;

class Import
{
    /**
     * Node object representing the file to be imported.
     *
     * @var CacheNode
     */
    public $node;

    /**
     * @var string the name of the attachment
     */
    public $attachment_name;

    /**
     * URL to download the file.
     *
     * @var string
     */
    public $download_url;

    /**
     * Path where the file will be imported.
     *
     * @var string
     */
    public $import_path;

    /**
     * The single instance of the class.
     *
     * @var Import
     */
    protected static $_instance;

    /**
     * Validated file type from the pre-write allowlist check.
     *
     * @var array<string, string>
     */
    protected $validated_file_type = [];

    /**
     * Constructor.
     */
    public function __construct()
    {
        if (!function_exists('wp_generate_attachment_metadata')) {
            require_once ABSPATH.'wp-admin/includes/image.php';

            include_once ABSPATH.'wp-admin/includes/media.php';
        }
    }

    /**
     * Get the single instance of the class.
     *
     * @return Import - Import instance
     */
    public static function instance()
    {
        if (is_null(self::$_instance)) {
            self::$_instance = new self();
        }

        return self::$_instance;
    }

    /**
     * Add a file to the media library.
     *
     * @param CacheNode $node node object representing the file
     *
     * @return int attachment ID
     */
    public function add_to_media_library($node)
    {
        $this->node = $node;
        $this->validated_file_type = [];
        $this->import_path = null;

        if (apply_filters('useyourdrive_import_require_capability', true, $node)
            && !current_user_can('upload_files')) {
            Helpers::log_error('Import rejected: insufficient capabilities', 'Import', ['file' => $node->get_name()], __LINE__);

            return false;
        }
        
        // Set Attachment name
        $this->attachment_name = sanitize_file_name($this->node->get_name());

        $this->download_url = 'https://www.googleapis.com/drive/v3/files/'.$node->get_id().'?alt=media';

        // Google Docs convert
        $export_formats = $node->get_entry()->get_save_as();
        if (!empty($export_formats)) {
            $format = $export_formats['PDF'] ?? reset($export_formats);
            $this->attachment_name = sanitize_file_name($this->node->get_name().'.'.$format['extension']);
            $this->download_url = 'https://www.googleapis.com/drive/v3/files/'.$node->get_id().'/export?alt=media&mimeType='.$format['mimetype'];
        }

        if (false === $this->download_file_to_uploads()) {
            return false;
        }

        return $this->insert_attachment_to_library();
    }

    /**
     * Download the file to the uploads folder.
     *
     * @return bool false when the file was rejected or could not be stored
     */
    public function download_file_to_uploads()
    {
        $upload_dir = wp_upload_dir();

        if (!empty($upload_dir['error'])) {
            Helpers::log_error('Upload directory not available', 'Import', ['error' => $upload_dir['error']], __LINE__);

            return false;
        }

        // 1. Reject disallowed filetypes BEFORE touching the filesystem.
        //    get_allowed_mime_types() honours the upload_mimes filter and unfiltered_upload,
        //    so site owners who legitimately need extra types configure this the WordPress way.
        $allowed_mimes = apply_filters('useyourdrive_import_allowed_mime_types', get_allowed_mime_types());
        $filetype = wp_check_filetype($this->attachment_name, $allowed_mimes);

        if (empty($filetype['ext']) || empty($filetype['type'])) {
            Helpers::log_error(
                'Import rejected: filetype not allowed',
                'Import',
                ['file' => $this->attachment_name],
                __LINE__
            );

            return false;
        }

        $this->validated_file_type = [
            'ext' => (string) $filetype['ext'],
            'type' => (string) $filetype['type'],
        ];

        // 2. Collision-safe filename. time().'_'.$name is not concurrency-safe.
        $filename = wp_unique_filename($upload_dir['path'], $this->attachment_name);
        $target_path = $upload_dir['path'].'/'.$filename;

        // 3. Belt and braces: never write outside the uploads directory.
        $real_dir = realpath($upload_dir['path']);
        if (false === $real_dir || 0 !== strpos(wp_normalize_path($target_path), wp_normalize_path($real_dir).'/')) {
            Helpers::log_error('Import rejected: path outside uploads', 'Import', ['file' => $filename], __LINE__);

            return false;
        }

        // 4. Stream to a temporary file, so a rejected or partial download never sits in uploads
        //    under a name the webserver might serve.
        $temp_path = wp_tempnam($filename);
        if (empty($temp_path)) {
            Helpers::log_error('Cannot create temp file', 'Import', ['file' => $filename], __LINE__);

            return false;
        }

        $file_handle = fopen($temp_path, 'wb');

        if (false === $file_handle) {
            Helpers::log_error('Cannot open temp file for writing', 'Import', ['file' => $temp_path], __LINE__);

            return false;
        }

        $chunk_size = Download::get_chunk_size();
        $chunk_start = 0;
        $chunk_end = $this->node->get_entry()->get_size() - 1;

        Helpers::set_time_limit(0);

        try {
            while ($chunk_start <= $chunk_end) {
                $chunk_end = ((($chunk_start + $chunk_size) > $chunk_end) ? $chunk_end : $chunk_start + $chunk_size);
                $this->_stream_get_chunk($chunk_start, $chunk_end, $file_handle);

                $chunk_start = $chunk_end + 1;

                Download::throttle();
            }
        } catch (\Exception $e) {
            fclose($file_handle);
            @unlink($temp_path);
            Helpers::log_error('Cannot store file in upload folder', 'Import', ['file' => $temp_path], __LINE__, $e);

            return false;
        }

        fclose($file_handle);

        // 5. Verify the actual bytes, not just the name. This is what wp_handle_upload() does.
        if (apply_filters('useyourdrive_import_verify_file_contents', true, $this->node)) {
            $checked = wp_check_filetype_and_ext($temp_path, $filename, $allowed_mimes);

            if (empty($checked['type'])) {
                @unlink($temp_path);
                Helpers::log_error(
                    'Import rejected: file contents do not match extension',
                    'Import',
                    ['file' => $filename],
                    __LINE__
                );

                return false;
            }

            // wp_check_filetype_and_ext() can propose a corrected filename (e.g. .jpeg -> .jpg).
            if (!empty($checked['proper_filename'])) {
                $filename = wp_unique_filename($upload_dir['path'], $checked['proper_filename']);
                $target_path = $upload_dir['path'].'/'.$filename;
            }

            $this->validated_file_type = [
                'ext' => (string) ($checked['ext'] ?: $filetype['ext']),
                'type' => (string) $checked['type'],
            ];
        }

        // 6. Move into place only now.
        if (!@rename($temp_path, $target_path)) {
            @unlink($temp_path);
            Helpers::log_error('Cannot move imported file into place', 'Import', ['file' => $target_path], __LINE__);

            return false;
        }

        $perms = defined('FS_CHMOD_FILE') ? FS_CHMOD_FILE : (fileperms(dirname($target_path)) & 0000666);
        @chmod($target_path, $perms);

        $this->attachment_name = $filename;
        $this->import_path = $target_path;

        return true;
    }

    /**
     * Insert the downloaded file as an attachment.
     *
     * @return int attachment ID
     */
    public function insert_attachment_to_library()
    {
        $file_path = $this->import_path;

        if (empty($this->validated_file_type['type'])) {
            Helpers::log_error('Import rejected: missing validated file type', 'Import', ['file' => $file_path], __LINE__);

            return false;
        }

        $upload_dir = wp_upload_dir();

        $attachment = [
            'guid' => $upload_dir['url'].'/'.basename($file_path),
            'post_mime_type' => $this->validated_file_type['type'],
            'post_title' => sanitize_title($this->node->get_entry()->get_basename()),
            'post_content' => sanitize_text_field($this->node->get_entry()->get_description()),
            'post_status' => 'inherit',
        ];

        $attach_id = wp_insert_attachment($attachment, $file_path, 0, true);

        if (is_wp_error($attach_id) || $attach_id <= 0) {
            @unlink($file_path);
            Helpers::log_error('Cannot insert imported attachment.', 'Import', ['file' => $file_path], __LINE__);

            return false;
        }

        $attach_data = wp_generate_attachment_metadata($attach_id, $file_path);
        wp_update_attachment_metadata($attach_id, $attach_data);

        return $attach_id;
    }

    /**
     * Function to get a range of bytes via the API.
     *
     * @param int      $start
     * @param int      $end
     * @param resource $file_handle
     */
    private function _stream_get_chunk($start, $end, $file_handle)
    {
        $headers = $this->get_request_headers($start, $end);

        $request = new \UYDGoogle_Http_Request($this->download_url, 'GET', $headers);
        $request->disableGzip();

        App::instance()->get_sdk_client()->getIo()->setOptions(
            [
                CURLOPT_RETURNTRANSFER => false,
                CURLOPT_FOLLOWLOCATION => true,
                CURLOPT_RANGE => null,
                CURLOPT_NOBODY => null,
                CURLOPT_HEADER => false,
                CURLOPT_WRITEFUNCTION => function ($curl, $data) use ($file_handle) {
                    return fwrite($file_handle, $data);
                },
                CURLOPT_CONNECTTIMEOUT => null,
                CURLOPT_TIMEOUT => null,
            ]
        );

        App::instance()->get_sdk_client()->getAuth()->authenticatedRequest($request);
    }

    /**
     * Helper function to get headers for the request.
     *
     * @param int $start
     * @param int $end
     *
     * @return array
     */
    private function get_request_headers($start, $end)
    {
        $headers = ['Range' => 'bytes='.$start.'-'.$end];

        // Add Resources key to give permission to access the item
        if ($this->node->get_entry()->has_resourcekey()) {
            $headers['X-Goog-Drive-Resource-Keys'] = $this->node->get_id().'/'.$this->node->get_entry()->get_resourcekey();
        }

        return $headers;
    }
}
