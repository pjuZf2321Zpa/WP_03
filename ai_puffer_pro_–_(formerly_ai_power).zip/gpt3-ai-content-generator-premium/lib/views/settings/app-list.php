<?php
/**
 * Partial (Pro): Apps as a list, like the AI providers and Connections.
 * Each app opens a side panel with its connection first and the rules that send to it;
 * a rule opens its own panel over the app's. Saves go through the settings form.
 */
if (!defined('ABSPATH')) {
    exit;
}

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Template-local helpers and data.

$is_pro_plan = class_exists('\WPAICG\\aipkit_dashboard') && \WPAICG\aipkit_dashboard::is_pro_plan();
$app_connections_class = '\WPAICG\\Lib\\Integrations\\Apps\\AIPKit_App_Connections';
$recipes_class = '\WPAICG\\Lib\\Integrations\\Recipes\\AIPKit_Stored_Recipes';
$diagnostics_class = '\WPAICG\\Lib\\Integrations\\Apps\\AIPKit_App_Connection_Diagnostics';
$validator_class = '\WPAICG\\Lib\\Integrations\\Recipes\\AIPKit_Recipe_Validator';

if (!$is_pro_plan || !class_exists($app_connections_class)) {
    return;
}

$call = static function (string $class, string $method, array $args = [], $fallback = []) {
    return class_exists($class) && method_exists($class, $method) ? $class::$method(...$args) : $fallback;
};

$apps = (array) $call($app_connections_class, 'get_supported_app_options');
$auth_types_by_app = (array) $call($app_connections_class, 'get_supported_auth_types_by_app');
$default_auth_by_app = (array) $call($app_connections_class, 'get_default_auth_types_by_app');
$field_definitions = (array) $call($app_connections_class, 'get_app_field_definitions');
$stored_connections = array_values(array_filter((array) $call($app_connections_class, 'get_connections'), 'is_array'));
$has_rules = class_exists($recipes_class);
$stored_recipes = $has_rules ? array_values(array_filter((array) $call($recipes_class, 'get_recipes'), 'is_array')) : [];
$event_options = $has_rules ? (array) $call($recipes_class, 'get_event_options') : [];
$action_options = $has_rules ? (array) $call($recipes_class, 'get_action_options') : [];
$actions_by_app = $has_rules ? (array) $call($recipes_class, 'get_action_options_by_app') : [];
$template_definitions = $has_rules ? (array) $call($recipes_class, 'get_template_definitions') : [];
$mapping_definitions = $has_rules ? (array) $call($recipes_class, 'get_mapping_ui_definitions') : [];
$chatbot_scope_options = $has_rules ? (array) $call($recipes_class, 'get_chatbot_scope_options') : [];
$ai_form_scope_options = $has_rules ? (array) $call($recipes_class, 'get_ai_form_scope_options') : [];
$validation_definitions = (array) $call($validator_class, 'get_ui_validation_definitions');
// Failed sends show on the rule that sent them, not in a list of their own.
$delivery_view_class = '\WPAICG\Lib\Views\Settings\AIPKit_App_Delivery_Issues_View';
if ($has_rules && !class_exists($delivery_view_class, false) && is_readable(__DIR__ . '/app-delivery-issues.php')) {
    require_once __DIR__ . '/app-delivery-issues.php';
}
$rule_failures = $has_rules && class_exists($delivery_view_class) ? (array) $delivery_view_class::failures_by_rule($apps) : [];

// What each app asks for first, worded like an API key, and where to get it. Other fields follow; optional ones fold.
$app_view = [
    'slack' => [
        'tagline' => __('Post chats, leads and new content to a channel.', 'gpt3-ai-content-generator'),
        'auth' => [
            'token' => ['key' => 'credentials.bot_token', 'link' => __('Get your Slack bot token', 'gpt3-ai-content-generator'), 'url' => 'https://api.slack.com/apps', 'switch' => __('Use a webhook URL instead', 'gpt3-ai-content-generator'), 'required' => ['workspace.default_channel']],
            'webhook' => ['key' => 'credentials.webhook_url', 'link' => __('Get your Slack webhook URL', 'gpt3-ai-content-generator'), 'url' => 'https://api.slack.com/messaging/webhooks', 'switch' => __('Use a bot token instead', 'gpt3-ai-content-generator')],
        ],
        'hints' => ['workspace.default_channel' => __('Rules post here unless they name another channel.', 'gpt3-ai-content-generator')],
    ],
    'hubspot' => [
        'tagline' => __('Add leads from chats and forms as contacts.', 'gpt3-ai-content-generator'),
        'auth' => ['token' => ['key' => 'credentials.private_app_token', 'link' => __('Get your HubSpot private app token', 'gpt3-ai-content-generator'), 'url' => 'https://developers.hubspot.com/docs/api/private-apps']],
        'optional' => ['workspace.portal_id', 'workspace.default_list_id'],
    ],
    'notion' => [
        'tagline' => __('Save content, images and feedback as pages.', 'gpt3-ai-content-generator'),
        'auth' => ['token' => ['key' => 'credentials.integration_token', 'link' => __('Get your Notion integration token', 'gpt3-ai-content-generator'), 'url' => 'https://www.notion.so/my-integrations']],
        'hints' => [
            'workspace.parent_page_id' => __('Rules that create pages add them under this page.', 'gpt3-ai-content-generator'),
            'workspace.database_id' => __('Rules that add database items add them here.', 'gpt3-ai-content-generator'),
        ],
    ],
    'pipedrive' => [
        'tagline' => __('Add leads from forms as people.', 'gpt3-ai-content-generator'),
        'auth' => ['api_key' => ['key' => 'credentials.api_token', 'link' => __('Get your Pipedrive API token', 'gpt3-ai-content-generator'), 'url' => 'https://app.pipedrive.com/settings/api', 'required' => ['workspace.company_domain']]],
        'hints' => ['workspace.company_domain' => __('The first part of your Pipedrive address, before .pipedrive.com.', 'gpt3-ai-content-generator')],
        'optional' => ['workspace.default_owner_id', 'workspace.pipeline_id'],
    ],
    'zapier' => [
        'tagline' => __('Pass any event on to a Zap.', 'gpt3-ai-content-generator'),
        'auth' => ['webhook' => ['key' => 'credentials.webhook_url', 'link' => __('Get your Zapier webhook URL', 'gpt3-ai-content-generator'), 'url' => 'https://zapier.com/apps/webhook/integrations']],
        'optional' => ['workspace.zap_name'],
    ],
    'make' => [
        'tagline' => __('Pass any event on to a scenario.', 'gpt3-ai-content-generator'),
        'auth' => ['webhook' => ['key' => 'credentials.webhook_url', 'link' => __('Get your Make webhook URL', 'gpt3-ai-content-generator'), 'url' => 'https://www.make.com/en/help/tools/webhooks']],
        'optional' => ['workspace.scenario_name'],
    ],
    'n8n' => [
        'tagline' => __('Pass any event on to a workflow.', 'gpt3-ai-content-generator'),
        'auth' => ['webhook' => ['key' => 'credentials.webhook_url', 'link' => __('Get your n8n webhook URL', 'gpt3-ai-content-generator'), 'url' => 'https://docs.n8n.io/integrations/builtin/core-nodes/n8n-nodes-base.webhook/']],
        'optional' => ['workspace.workflow_name'],
    ],
];

// Plain words for what happens and what the app does, as the chatbot's Connected apps panel words them.
$event_words = [
    'chatbot.session_started' => ['controls-play', __('A chat starts', 'gpt3-ai-content-generator')],
    'chatbot.user_message_submitted' => ['format-chat', __('A visitor sends a message', 'gpt3-ai-content-generator')],
    'chatbot.response_generated' => ['admin-comments', __('The chatbot replies', 'gpt3-ai-content-generator')],
    'chatbot.fb_submitted' => ['thumbs-up', __('A visitor rates a reply', 'gpt3-ai-content-generator')],
    'chatbot.form_submitted' => ['feedback', __('A visitor fills in the chat form', 'gpt3-ai-content-generator')],
    'content.generated' => ['edit-page', __('New content is written', 'gpt3-ai-content-generator')],
    'task.item_completed' => ['yes-alt', __('An automation task finishes', 'gpt3-ai-content-generator')],
    'form.submitted' => ['forms', __('Someone sends an AI form', 'gpt3-ai-content-generator')],
    'image.generated' => ['format-image', __('An image is made', 'gpt3-ai-content-generator')],
    'kb.source_indexed' => ['database', __('A knowledge base source is added', 'gpt3-ai-content-generator')],
];
$action_words = [
    'slack_message_create' => __('Post a message', 'gpt3-ai-content-generator'),
    'hubspot_contact_upsert' => __('Add or update a contact', 'gpt3-ai-content-generator'),
    'notion_page_create' => __('Create a page', 'gpt3-ai-content-generator'),
    'notion_database_item_create' => __('Add a database item', 'gpt3-ai-content-generator'),
    'pipedrive_person_upsert' => __('Add or update a person', 'gpt3-ai-content-generator'),
    'zapier_webhook_trigger' => __('Send it to the webhook', 'gpt3-ai-content-generator'),
    'make_webhook_trigger' => __('Send it to the webhook', 'gpt3-ai-content-generator'),
    'n8n_webhook_trigger' => __('Send it to the webhook', 'gpt3-ai-content-generator'),
];
$event_label = static function (string $event) use ($event_words, $event_options): string {
    return (string) ($event_words[$event][1] ?? ($event_options[$event] ?? $event));
};
$event_icon = static function (string $event) use ($event_words): string {
    return (string) ($event_words[$event][0] ?? 'admin-generic');
};
$action_label = static function (string $action) use ($action_words, $action_options): string {
    return (string) ($action_words[$action] ?? ($action_options[$action] ?? $action));
};
$status_words = [
    'ready' => __('Ready', 'gpt3-ai-content-generator'),
    'warning' => __('Check setup', 'gpt3-ai-content-generator'),
    'error' => __('Not working', 'gpt3-ai-content-generator'),
    'reauth_required' => __('Sign in again', 'gpt3-ai-content-generator'),
    'paused' => __('Paused', 'gpt3-ai-content-generator'),
];

// The same square marks as the free Apps row.
$render_app_mark = require dirname(__DIR__, 3) . '/admin/views/settings/app-mark.php';

$field_index = [];
foreach ($field_definitions as $slug => $definitions) {
    foreach ((array) $definitions as $definition) {
        if (!is_array($definition)) {
            continue;
        }
        $path = sanitize_key((string) ($definition['group'] ?? '')) . '.' . sanitize_key((string) ($definition['key'] ?? ''));
        $field_index[sanitize_key((string) $slug)][$path] = $definition;
    }
}
$field_value = static function (array $connection, string $path): string {
    [$group, $key] = array_pad(explode('.', $path, 2), 2, '');
    $values = isset($connection[$group]) && is_array($connection[$group]) ? $connection[$group] : [];
    return sanitize_text_field((string) ($values[$key] ?? ''));
};
$mask = static function (string $secret): string {
    if ($secret === '') {
        return '';
    }
    $dots = str_repeat('•', 12);
    $length = strlen($secret);
    if ($length < 9) {
        return $dots;
    }
    $prefix = $length >= 16 ? 8 : 3;
    $suffix = $length >= 16 ? 4 : 3;
    return substr($secret, 0, $prefix) . $dots . substr($secret, -$suffix);
};
// The ways into an app that both this view and the app support.
$auth_allowed = static function (string $slug) use ($auth_types_by_app, $app_view): array {
    $known = array_keys((array) ($app_view[$slug]['auth'] ?? []));
    $allowed = array_values(array_intersect($known, (array) ($auth_types_by_app[$slug] ?? $known)));
    return $allowed ?: $known;
};
$auth_for = static function (string $slug, array $connection) use ($auth_allowed, $default_auth_by_app): string {
    $allowed = $auth_allowed($slug);
    $auth = sanitize_key((string) ($connection['auth_type'] ?? ''));
    if (!in_array($auth, $allowed, true)) {
        $auth = sanitize_key((string) ($default_auth_by_app[$slug] ?? ($allowed[0] ?? '')));
    }
    return in_array($auth, $allowed, true) ? $auth : (string) ($allowed[0] ?? '');
};
// Connected means the app has what it needs to send: its key, and the fields that go with that key.
$is_connected = static function (string $slug, array $connection) use ($app_view, $auth_for, $field_value): bool {
    if (empty($connection)) {
        return false;
    }
    $auth = $auth_for($slug, $connection);
    $view = (array) ($app_view[$slug]['auth'][$auth] ?? []);
    foreach (array_merge([(string) ($view['key'] ?? '')], (array) ($view['required'] ?? [])) as $path) {
        if ($path !== '' && $field_value($connection, $path) === '') {
            return false;
        }
    }
    return true;
};

// Connections and rules, by app, in the order they are stored.
$connections_by_app = [];
foreach ($stored_connections as $connection) {
    $slug = sanitize_key((string) ($connection['app_slug'] ?? ''));
    $connections_by_app[isset($apps[$slug]) ? $slug : (string) array_key_first($apps)][] = $connection;
}
$connection_records = [];
foreach ($stored_connections as $connection) {
    $connection_records[sanitize_text_field((string) ($connection['id'] ?? ''))] = $connection;
}
$recipes_by_app = [];
foreach ($stored_recipes as $recipe) {
    $slug = sanitize_key((string) ($recipe['app_slug'] ?? ''));
    $recipes_by_app[isset($apps[$slug]) ? $slug : (string) array_key_first($apps)][] = $recipe;
}
$rule_state = static function (array $recipe) use ($validator_class, $connection_records, $status_words): array {
    $connection = $connection_records[sanitize_text_field((string) ($recipe['connection_id'] ?? ''))] ?? null;
    $state = class_exists($validator_class) && method_exists($validator_class, 'get_recipe_ui_state')
        ? (array) $validator_class::get_recipe_ui_state($recipe, is_array($connection) ? $connection : null)
        : ['status_key' => 'warning', 'summary' => ''];
    $key = sanitize_key((string) ($state['status_key'] ?? 'warning'));
    if (!isset($status_words[$key]) || $key === 'paused') {
        $key = 'warning';
    }
    // A webhook can't be checked before it is used, so a webhook rule with everything filled in is ready.
    if ($key === 'warning' && is_array($connection) && sanitize_key((string) ($connection['auth_type'] ?? '')) === 'webhook') {
        $key = 'ready';
    }
    return ['key' => $key, 'summary' => sanitize_text_field((string) ($state['summary'] ?? ''))];
};
$source_groups_for = static function (string $event) use ($mapping_definitions): array {
    $groups = [];
    foreach ((array) ($mapping_definitions['source_groups_by_event'][$event] ?? []) as $group) {
        if (is_array($group) && !empty($group['options']) && is_array($group['options'])) {
            $groups[] = ['label' => (string) ($group['label'] ?? ''), 'options' => $group['options']];
        }
    }
    if (!$groups && !empty($mapping_definitions['source_options_by_event'][$event]) && is_array($mapping_definitions['source_options_by_event'][$event])) {
        $groups[] = ['label' => '', 'options' => $mapping_definitions['source_options_by_event'][$event]];
    }
    return $groups;
};

$connection_index = 0;
$recipe_index = 0;

// One connection's fields. Returns its index in the saved list, or '' while it isn't saved yet.
$render_connection = static function (string $slug, array $connection, bool $primary) use (&$connection_index, $app_view, $field_index, $field_value, $mask, $auth_for, $auth_allowed, $is_connected, $apps, $diagnostics_class): string {
    $live = !empty($connection);
    $index = $live ? (string) $connection_index++ : '';
    $name_for = static function (string $path) use ($index, $live): string {
        if (!$live) {
            return '';
        }
        $parts = explode('.', $path);
        return 'native_app_recipes[connections][' . $index . '][' . implode('][', array_map('sanitize_key', $parts)) . ']';
    };
    $connected = $is_connected($slug, $connection);
    $current_auth = $auth_for($slug, $connection);
    $status = sanitize_key((string) ($connection['status'] ?? 'draft'));
    $ui_state = $live && class_exists($diagnostics_class) && method_exists($diagnostics_class, 'get_connection_ui_state')
        ? (array) $diagnostics_class::get_connection_ui_state($connection)
        : [];
    $error_status = $connected && in_array(sanitize_key((string) ($ui_state['status_key'] ?? $status)), ['error', 'reauth_required'], true);
    $app_name = (string) ($apps[$slug] ?? $slug);
    $connection_id = sanitize_text_field((string) ($connection['id'] ?? ''));
    $hidden = [
        'id' => $connection_id,
        'app_slug' => $slug,
        'auth_type' => $current_auth,
        'status' => in_array($status, ['draft', 'active', 'inactive', 'error', 'reauth_required'], true) ? $status : 'draft',
        'is_enabled' => !$live || !array_key_exists('is_enabled', $connection) || !empty($connection['is_enabled']) ? '1' : '0',
    ];
    ?>
    <div
        class="aipkit_settings_app_connection"
        data-aipkit-app-connection
        data-aipkit-app-connection-primary="<?php echo $primary ? 'true' : 'false'; ?>"
        data-aipkit-app-connected="<?php echo $connected ? 'true' : 'false'; ?>"
        data-aipkit-app-testable="<?php echo in_array($current_auth, ['token', 'api_key'], true) ? 'true' : 'false'; ?>"
        <?php echo $error_status ? 'data-aipkit-app-connection-error="' . esc_attr((string) ($ui_state['summary'] ?? '')) . '"' : ''; ?>
    >
        <?php foreach ($hidden as $key => $value) : ?>
            <input type="hidden" name="<?php echo esc_attr($name_for($key)); ?>" value="<?php echo esc_attr($value); ?>" data-aipkit-app-connection-field="<?php echo esc_attr($key); ?>" />
        <?php endforeach; ?>
        <?php if ($primary) : ?>
            <input type="hidden" name="<?php echo esc_attr($name_for('name')); ?>" value="<?php echo esc_attr((string) ($connection['name'] ?? '') !== '' ? (string) $connection['name'] : $app_name); ?>" data-aipkit-app-connection-field="name" />
        <?php else : ?>
            <div class="aipkit_settings_provider_option">
                <label class="aipkit_settings_provider_option_label"><?php esc_html_e('Name', 'gpt3-ai-content-generator'); ?>
                    <input type="text" class="aipkit_form-input aipkit_autosave_trigger" name="<?php echo esc_attr($name_for('name')); ?>" value="<?php echo esc_attr((string) ($connection['name'] ?? '')); ?>" data-aipkit-app-connection-field="name" />
                </label>
            </div>
        <?php endif; ?>
        <?php foreach (array_intersect_key((array) ($app_view[$slug]['auth'] ?? []), array_flip($auth_allowed($slug))) as $auth => $view) :
            $key_path = (string) $view['key'];
            $key_definition = (array) ($field_index[$slug][$key_path] ?? []);
            // A key is secret unless it is a webhook address; without a field definition, assume secret.
            $is_secret = (string) ($key_definition['type'] ?? (substr($key_path, -strlen('webhook_url')) === 'webhook_url' ? 'url' : 'password')) === 'password';
            $key_value = $live ? $field_value($connection, $key_path) : '';
            $key_mask = $is_secret && $auth === $current_auth ? $mask($key_value) : '';
            $is_current = $auth === $current_auth;
            $input_id = 'aipkit_app_' . sanitize_html_class($slug) . '_' . sanitize_html_class($connection_id !== '' ? $connection_id : 'new') . '_' . sanitize_html_class(str_replace('.', '_', $key_path));
            ?>
            <div class="aipkit_settings_app_auth" data-aipkit-app-auth="<?php echo esc_attr($auth); ?>" <?php echo $is_current ? '' : 'hidden'; ?>>
                <div class="aipkit_settings_provider_field">
                    <label class="aipkit_settings_provider_option_label" for="<?php echo esc_attr($input_id); ?>"><?php echo esc_html((string) ($key_definition['label'] ?? __('API key', 'gpt3-ai-content-generator'))); ?></label>
                    <div class="aipkit_settings_provider_credential_row">
                        <div class="aipkit_settings_provider_credential_wrap">
                            <input
                                type="<?php echo $is_secret ? 'password' : 'url'; ?>"
                                id="<?php echo esc_attr($input_id); ?>"
                                name="<?php echo $key_mask !== '' || !$is_current ? '' : esc_attr($name_for($key_path)); ?>"
                                class="aipkit_form-input aipkit_autosave_trigger aipkit_settings_provider_credential<?php echo $is_secret ? ' is-secret' : ''; ?><?php echo $key_mask !== '' ? ' is-visually-masked' : ''; ?>"
                                value="<?php echo $is_secret ? '' : esc_attr($is_current ? $key_value : ''); ?>"
                                <?php /* translators: 1: what an app asks for, e.g. "bot token", 2: app name. */ ?>
                                placeholder="<?php echo esc_attr(sprintf(__('Paste your %2$s %1$s', 'gpt3-ai-content-generator'), strtolower((string) ($key_definition['label'] ?? '')), $app_name)); ?>"
                                data-aipkit-app-connection-field="<?php echo esc_attr($key_path); ?>"
                                data-aipkit-app-key
                                data-aipkit-app-required
                                <?php if ($is_secret) : ?>data-aipkit-app-secret data-aipkit-has-credential="<?php echo $key_mask !== '' ? 'true' : 'false'; ?>"<?php endif; ?>
                                autocomplete="off" autocorrect="off" autocapitalize="off" spellcheck="false" data-lpignore="true" data-1p-ignore="true" data-form-type="other"
                                <?php echo $key_mask !== '' ? 'readonly' : ''; ?>
                                <?php echo $is_current ? '' : 'disabled'; ?>
                            />
                            <?php if ($is_secret) : ?>
                                <span class="aipkit_settings_provider_credential_mask" data-aipkit-app-secret-mask aria-hidden="true" <?php echo $key_mask === '' ? 'hidden' : ''; ?>><?php echo esc_html($key_mask); ?></span>
                            <?php endif; ?>
                        </div>
                        <?php if ($primary) : ?>
                            <button type="button" class="aipkit_btn aipkit_btn-primary aipkit_settings_provider_connect" data-aipkit-app-connect <?php echo $connected ? 'hidden' : ''; ?>><?php esc_html_e('Connect', 'gpt3-ai-content-generator'); ?></button>
                        <?php endif; ?>
                    </div>
                    <div class="aipkit_settings_provider_field_links">
                        <span class="aipkit_settings_provider_option_help" data-aipkit-app-replace-help <?php echo $connected && $is_current ? '' : 'hidden'; ?>><?php esc_html_e('Paste a new key to replace it. It saves by itself.', 'gpt3-ai-content-generator'); ?></span>
                        <a class="aipkit_settings_provider_key_link" href="<?php echo esc_url((string) $view['url']); ?>" target="_blank" rel="noopener noreferrer">
                            <span><?php echo esc_html((string) $view['link']); ?></span>
                            <span class="dashicons dashicons-external" aria-hidden="true"></span>
                        </a>
                    </div>
                </div>
                <?php
                // Fields this way in also needs or offers, after the key: required ones and plain ones show, optional ones fold.
                foreach ((array) ($field_index[$slug] ?? []) as $path => $definition) :
                    $auth_types = array_map('sanitize_key', (array) ($definition['auth_types'] ?? []));
                    if ($path === $key_path || ($auth_types && !in_array($auth, $auth_types, true)) || in_array($path, (array) ($app_view[$slug]['optional'] ?? []), true) || strpos($path, 'credentials.') === 0) {
                        continue;
                    }
                    $required = in_array($path, (array) ($view['required'] ?? []), true);
                    $field_id = $input_id . '_' . sanitize_html_class(str_replace('.', '_', $path));
                    ?>
                    <div class="aipkit_settings_provider_option">
                        <div class="aipkit_settings_provider_option_copy">
                            <label class="aipkit_settings_provider_option_label" for="<?php echo esc_attr($field_id); ?>"><?php echo esc_html((string) ($definition['label'] ?? $path)); ?></label>
                            <?php if (!empty($app_view[$slug]['hints'][$path])) : ?>
                                <span class="aipkit_settings_provider_option_help"><?php echo esc_html((string) $app_view[$slug]['hints'][$path]); ?></span>
                            <?php endif; ?>
                        </div>
                        <div class="aipkit_settings_provider_option_control">
                            <div class="aipkit_settings_provider_option_input">
                                <input
                                    type="text"
                                    id="<?php echo esc_attr($field_id); ?>"
                                    name="<?php echo $is_current ? esc_attr($name_for($path)) : ''; ?>"
                                    class="aipkit_form-input aipkit_autosave_trigger"
                                    value="<?php echo esc_attr($live ? $field_value($connection, $path) : ''); ?>"
                                    placeholder="<?php echo esc_attr((string) ($definition['placeholder'] ?? '')); ?>"
                                    data-aipkit-app-connection-field="<?php echo esc_attr($path); ?>"
                                    <?php echo $required ? 'data-aipkit-app-required required' : ''; ?>
                                    <?php echo $is_current ? '' : 'disabled'; ?>
                                />
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
                <?php if ($primary && count($auth_allowed($slug)) > 1 && !empty($view['switch'])) :
                    $other = (string) array_values(array_diff($auth_allowed($slug), [$auth]))[0];
                    ?>
                    <button type="button" class="aipkit_settings_app_auth_switch" data-aipkit-app-auth-switch="<?php echo esc_attr($other); ?>"><?php echo esc_html((string) $view['switch']); ?></button>
                <?php endif; ?>
            </div>
        <?php endforeach; ?>
        <?php if (!$primary) : ?>
            <button type="button" class="aipkit_settings_provider_remove aipkit_settings_app_connection_remove" data-aipkit-app-connection-remove
                <?php /* translators: %s: name of an app connection. */ ?>
                data-confirm-title="<?php echo esc_attr(sprintf(__('Remove %s?', 'gpt3-ai-content-generator'), (string) ($connection['name'] ?? $app_name))); ?>"
                data-confirm-text="<?php esc_attr_e('Rules that use this connection stop sending until you choose another.', 'gpt3-ai-content-generator'); ?>"
                data-confirm-button="<?php esc_attr_e('Remove', 'gpt3-ai-content-generator'); ?>"
                data-cancel-button="<?php esc_attr_e('Cancel', 'gpt3-ai-content-generator'); ?>"
            ><?php esc_html_e('Remove this connection', 'gpt3-ai-content-generator'); ?></button>
        <?php endif; ?>
        <div class="aipkit_settings_provider_error" data-aipkit-app-error role="alert" <?php echo $error_status ? '' : 'hidden'; ?>>
            <span class="dashicons dashicons-warning" aria-hidden="true"></span>
            <div class="aipkit_settings_provider_error_content"><p data-aipkit-app-error-message><?php echo esc_html($error_status ? (string) ($ui_state['summary'] ?? '') : ''); ?></p></div>
        </div>
    </div>
    <?php
    return $index;
};

$render_mapping_row = static function (string $name_prefix, array $field, string $event, string $action) use ($source_groups_for, $mapping_definitions): void {
    $target = sanitize_key((string) ($field['target_field'] ?? ''));
    $source = sanitize_text_field((string) ($field['source_path'] ?? ''));
    $transform = sanitize_key((string) ($field['transform'] ?? ''));
    $fallback = is_scalar($field['fallback_value'] ?? '') ? (string) ($field['fallback_value'] ?? '') : '';
    $required = !empty($field['is_required']);
    $named = static function (string $key) use ($name_prefix): string {
        return $name_prefix === '' ? '' : $name_prefix . '[' . $key . ']';
    };
    $targets = (array) ($mapping_definitions['target_options_by_action'][$action] ?? []);
    $unsupported_hubspot_field = $action === 'hubspot_contact_upsert' && $target !== '' && !array_key_exists($target, $targets);
    $groups = $source_groups_for($event);
    $source_known = false;
    foreach ($groups as $group) {
        $source_known = $source_known || array_key_exists($source, (array) $group['options']);
    }
    ?>
    <div class="aipkit_settings_app_mapping_row" data-aipkit-app-mapping-row>
        <div class="aipkit_settings_app_mapping_main">
            <select class="aipkit_form-input aipkit_autosave_trigger" name="<?php echo esc_attr($named('target_field')); ?>" data-aipkit-app-mapping-field="target_field" aria-label="<?php esc_attr_e('Field in the app', 'gpt3-ai-content-generator'); ?>">
                <option value=""><?php esc_html_e('Choose a field', 'gpt3-ai-content-generator'); ?></option>
                <?php foreach ($targets as $key => $label) : ?>
                    <option value="<?php echo esc_attr((string) $key); ?>" <?php selected($target, (string) $key); ?>><?php echo esc_html((string) $label); ?></option>
                <?php endforeach; ?>
                <?php if ($target !== '' && !array_key_exists($target, $targets)) : ?>
                    <option value="<?php echo esc_attr($target); ?>" selected><?php echo esc_html($unsupported_hubspot_field && $target === 'note' ? __('Internal note (not sent)', 'gpt3-ai-content-generator') : $target); ?></option>
                <?php endif; ?>
            </select>
            <span class="aipkit_settings_app_mapping_from"><?php esc_html_e('from', 'gpt3-ai-content-generator'); ?></span>
            <select class="aipkit_form-input aipkit_autosave_trigger" name="<?php echo esc_attr($named('source_path')); ?>" data-aipkit-app-mapping-field="source_path" aria-label="<?php esc_attr_e('What to send', 'gpt3-ai-content-generator'); ?>">
                <option value=""><?php esc_html_e('Choose what to send', 'gpt3-ai-content-generator'); ?></option>
                <?php foreach ($groups as $group) : ?>
                    <?php if ($group['label'] !== '') : ?><optgroup label="<?php echo esc_attr($group['label']); ?>"><?php endif; ?>
                    <?php foreach ((array) $group['options'] as $path => $label) : ?>
                        <option value="<?php echo esc_attr((string) $path); ?>" <?php selected($source, (string) $path); ?>><?php echo esc_html((string) $label); ?></option>
                    <?php endforeach; ?>
                    <?php if ($group['label'] !== '') : ?></optgroup><?php endif; ?>
                <?php endforeach; ?>
                <?php if ($source !== '' && !$source_known) : ?>
                    <option value="<?php echo esc_attr($source); ?>" selected><?php echo esc_html($source); ?></option>
                <?php endif; ?>
            </select>
            <button type="button" class="aipkit_settings_icon_button" data-aipkit-app-mapping-more aria-expanded="false" aria-label="<?php esc_attr_e('More for this field', 'gpt3-ai-content-generator'); ?>" title="<?php esc_attr_e('More for this field', 'gpt3-ai-content-generator'); ?>"><span class="dashicons dashicons-admin-generic" aria-hidden="true"></span></button>
            <button type="button" class="aipkit_settings_icon_button" data-aipkit-app-mapping-remove aria-label="<?php esc_attr_e('Remove this field', 'gpt3-ai-content-generator'); ?>" title="<?php esc_attr_e('Remove this field', 'gpt3-ai-content-generator'); ?>"><span class="dashicons dashicons-no-alt" aria-hidden="true"></span></button>
        </div>
        <p class="aipkit_settings_provider_panel_hint" data-aipkit-app-mapping-warning role="status" <?php echo $unsupported_hubspot_field ? '' : 'hidden'; ?>><?php esc_html_e('This field is no longer supported and is not sent to HubSpot. Choose another field or remove this mapping.', 'gpt3-ai-content-generator'); ?></p>
        <div class="aipkit_settings_app_mapping_extra" data-aipkit-app-mapping-extra hidden>
            <label><span><?php esc_html_e('Change it', 'gpt3-ai-content-generator'); ?></span>
                <select class="aipkit_form-input aipkit_autosave_trigger" name="<?php echo esc_attr($named('transform')); ?>" data-aipkit-app-mapping-field="transform">
                    <?php foreach ((array) ($mapping_definitions['transform_options'] ?? ['' => __('No transform', 'gpt3-ai-content-generator')]) as $key => $label) : ?>
                        <option value="<?php echo esc_attr((string) $key); ?>" <?php selected($transform, (string) $key); ?>><?php echo esc_html((string) $label); ?></option>
                    <?php endforeach; ?>
                </select>
            </label>
            <label><span><?php esc_html_e('If empty, send', 'gpt3-ai-content-generator'); ?></span>
                <input type="text" class="aipkit_form-input aipkit_autosave_trigger" name="<?php echo esc_attr($named('fallback_value')); ?>" value="<?php echo esc_attr($fallback); ?>" data-aipkit-app-mapping-field="fallback_value" />
            </label>
            <label class="aipkit_settings_app_mapping_required">
                <input type="checkbox" class="aipkit_autosave_trigger" value="1" name="<?php echo esc_attr($named('is_required')); ?>" data-aipkit-app-mapping-field="is_required" <?php checked($required); ?> />
                <span><?php esc_html_e('Skip sending when this is empty', 'gpt3-ai-content-generator'); ?></span>
            </label>
        </div>
    </div>
    <?php
};

// One rule: its panel is printed; the row that opens it is returned for the app panel's list.
$render_rule = static function (string $slug, array $recipe, bool $template = false) use (&$recipe_index, $apps, $event_options, $event_label, $event_icon, $actions_by_app, $action_options, $action_label, $connections_by_app, $chatbot_scope_options, $ai_form_scope_options, $rule_state, $status_words, $render_mapping_row, $render_app_mark, $template_definitions, $rule_failures): string {
    $index = $template ? '' : (string) $recipe_index++;
    $named = static function (string $key) use ($index, $template): string {
        return $template ? '' : 'native_app_recipes[recipes][' . $index . '][' . $key . ']';
    };
    $id = sanitize_text_field((string) ($recipe['id'] ?? ''));
    $key = $template ? '__RULE__' : ($id !== '' ? $id : 'rule-' . $index);
    $app_actions = array_values(array_filter((array) ($actions_by_app[$slug] ?? []), static fn ($candidate) => is_string($candidate) && ($action_options === [] || isset($action_options[$candidate]))));
    $event = sanitize_text_field((string) ($recipe['event_name'] ?? ''));
    if (!isset($event_options[$event])) {
        $event = (string) array_key_first($event_options);
    }
    $action = sanitize_key((string) ($recipe['action_slug'] ?? ''));
    if (!in_array($action, $app_actions, true)) {
        $action = (string) ($app_actions[0] ?? $action);
    }
    $name = (string) ($recipe['name'] ?? '');
    $template_slug = sanitize_key((string) ($recipe['template_slug'] ?? ''));
    if ($template_slug !== '' && $name === $template_slug && isset($template_definitions[$template_slug])) {
        $name = (string) ($template_definitions[$template_slug]['name'] ?? ($template_definitions[$template_slug]['label'] ?? $name));
    }
    $enabled = !empty($recipe['is_enabled']);
    $state = $template ? ['key' => 'warning', 'summary' => ''] : $rule_state($recipe);
    $failures = $template ? [] : (array) ($rule_failures[$id] ?? []);
    $chip = $failures ? 'failed' : ($enabled ? $state['key'] : 'paused');
    /* translators: %s: how long ago, e.g. "2 hours ago". */
    $failed_label = $failures ? sprintf(__('Failed %s', 'gpt3-ai-content-generator'), (string) $failures[0]['when']) : '';
    $chip_label = $failures ? $failed_label : $status_words[$chip];
    $live_connections = (array) ($connections_by_app[$slug] ?? []);
    $connection_id = sanitize_text_field((string) ($recipe['connection_id'] ?? ''));
    if ($connection_id === '' && $live_connections) {
        $connection_id = sanitize_text_field((string) ($live_connections[0]['id'] ?? ''));
    }
    $bot_ids = array_values(array_filter(array_map('absint', (array) ($recipe['filters']['chatbot']['bot_ids'] ?? []))));
    $form_ids = array_values(array_filter(array_map('absint', (array) ($recipe['filters']['ai_form']['form_ids'] ?? []))));
    $is_chat_event = strpos($event, 'chatbot.') === 0;
    $is_form_event = $event === 'form.submitted';
    $scope_label = $is_chat_event
        ? ($bot_ids ? (string) ($chatbot_scope_options[$bot_ids[0]] ?? __('One chatbot', 'gpt3-ai-content-generator')) : __('All chatbots', 'gpt3-ai-content-generator'))
        : ($is_form_event ? ($form_ids ? (string) ($ai_form_scope_options[$form_ids[0]] ?? __('One AI form', 'gpt3-ai-content-generator')) : __('All AI forms', 'gpt3-ai-content-generator')) : '');
    $fields = array_values(array_filter((array) ($recipe['mapping']['fields'] ?? []), 'is_array'));
    $modal = 'app-rule-' . $key;
    $title_id = 'aipkit_settings_app_rule_' . sanitize_html_class($key) . '_title';
    $display_name = $name !== '' ? $name : __('Untitled rule', 'gpt3-ai-content-generator');
    $rows_html = '';
    if (!$template) {
        ob_start();
        ?>
        <button type="button" class="aipkit_settings_app_rule_row" data-aipkit-provider-settings-open="<?php echo esc_attr($modal); ?>" data-aipkit-app-rule-row="<?php echo esc_attr($key); ?>" aria-haspopup="dialog">
            <span class="aipkit_settings_app_rule_icon dashicons dashicons-<?php echo esc_attr($event_icon($event)); ?>" data-aipkit-app-rule-icon aria-hidden="true"></span>
            <span class="aipkit_settings_app_rule_copy">
                <span class="aipkit_settings_app_rule_title" data-aipkit-app-rule-title><?php echo esc_html($display_name); ?></span>
                <span class="aipkit_settings_app_rule_meta" data-aipkit-app-rule-meta><?php echo esc_html(implode(' · ', array_filter([$event_label($event), $scope_label]))); ?></span>
            </span>
            <span class="aipkit_settings_app_rule_status" data-aipkit-app-rule-status="<?php echo esc_attr($chip); ?>"><?php echo esc_html($chip_label); ?></span>
            <span class="dashicons dashicons-arrow-right-alt2" aria-hidden="true"></span>
        </button>
        <?php
        $rows_html = (string) ob_get_clean();
    }
    ?>
    <div
        class="aipkit-modal-overlay aipkit_settings_provider_modal aipkit_settings_app_rule_modal"
        data-aipkit-provider-modal="<?php echo esc_attr($modal); ?>"
        data-aipkit-app-rule="<?php echo esc_attr($key); ?>"
        data-aipkit-app-parent="app-<?php echo esc_attr($slug); ?>"
        data-aipkit-app-rule-state="<?php echo esc_attr($chip); ?>"
        aria-hidden="true"
    >
        <div class="aipkit-modal-content aipkit_settings_provider_panel" role="dialog" aria-modal="true" aria-labelledby="<?php echo esc_attr($title_id); ?>">
            <div class="aipkit_settings_provider_panel_header">
                <button type="button" class="aipkit_settings_provider_panel_close aipkit_settings_app_back" data-aipkit-app-back aria-label="<?php esc_attr_e('Back', 'gpt3-ai-content-generator'); ?>"><span class="dashicons dashicons-arrow-left-alt2" aria-hidden="true"></span></button>
                <span class="aipkit_settings_provider_logo aipkit_settings_app_logo" aria-hidden="true"><?php $render_app_mark($slug); ?></span>
                <div class="aipkit_settings_provider_panel_heading">
                    <div class="aipkit_settings_provider_panel_title_row">
                        <h2 class="aipkit_settings_provider_panel_title" id="<?php echo esc_attr($title_id); ?>" data-aipkit-app-rule-heading><?php echo esc_html($display_name); ?></h2>
                        <span class="aipkit_settings_app_rule_status" data-aipkit-app-rule-status="<?php echo esc_attr($chip); ?>"><?php echo esc_html($chip_label); ?></span>
                    </div>
                    <p class="aipkit_settings_provider_panel_hint" data-aipkit-app-rule-hint><?php echo esc_html(implode(' · ', [(string) ($apps[$slug] ?? $slug), $action_label($action)])); ?></p>
                </div>
            </div>
            <div class="aipkit_settings_provider_panel_body">
                <?php foreach (['id' => $template ? '' : $id, 'app_slug' => $slug, 'template_slug' => $template_slug, 'status' => sanitize_key((string) ($recipe['status'] ?? 'draft')), 'is_enabled' => $enabled ? '1' : '0'] as $field => $value) : ?>
                    <input type="hidden" name="<?php echo esc_attr($named($field)); ?>" value="<?php echo esc_attr($value); ?>" data-aipkit-app-rule-field="<?php echo esc_attr($field); ?>" />
                <?php endforeach; ?>
                <?php if ($failures) :
                    $failure_count = count($failures);
                    ?>
                    <div
                        class="aipkit_settings_provider_error aipkit_settings_app_failure"
                        data-aipkit-app-rule-failures="<?php echo esc_attr(wp_json_encode(array_column($failures, 'uuid'))); ?>"
                        data-chip-label="<?php echo esc_attr($failed_label); ?>"
                        <?php /* translators: %s: how long ago, e.g. "2 hours ago". */ ?>
                        data-chip-template="<?php esc_attr_e('Failed %s', 'gpt3-ai-content-generator'); ?>"
                        <?php /* translators: %d: number of failed sends. */ ?>
                        data-title-many="<?php esc_attr_e('%d failed sends need attention', 'gpt3-ai-content-generator'); ?>"
                        data-title-one="<?php esc_attr_e('A failed send needs attention', 'gpt3-ai-content-generator'); ?>"
                        data-retry-one="<?php esc_attr_e('Send it again', 'gpt3-ai-content-generator'); ?>"
                        data-retry-many="<?php esc_attr_e('Send them again', 'gpt3-ai-content-generator'); ?>"
                        data-done="<?php esc_attr_e('Sent. It went through this time.', 'gpt3-ai-content-generator'); ?>"
                        role="alert"
                    >
                        <span class="dashicons dashicons-warning" aria-hidden="true"></span>
                        <div class="aipkit_settings_provider_error_content">
                            <?php /* translators: %d: number of failed sends. */ ?>
                            <p class="aipkit_settings_app_failure_title" data-aipkit-app-failure-title><?php echo esc_html($failure_count > 1 ? sprintf(__('%d failed sends need attention', 'gpt3-ai-content-generator'), $failure_count) : __('A failed send needs attention', 'gpt3-ai-content-generator')); ?></p>
                            <p data-aipkit-app-failure-reason><?php echo esc_html((string) $failures[0]['reason']); ?></p>
                            <p class="aipkit_settings_app_failure_when" data-aipkit-app-failure-when><?php echo esc_html((string) $failures[0]['when']); ?></p>
                            <div class="aipkit_settings_app_failure_actions">
                                <button type="button" class="aipkit_settings_app_failure_retry" data-aipkit-app-failure-retry><span class="dashicons dashicons-update" aria-hidden="true"></span><span data-aipkit-app-failure-retry-label><?php echo $failure_count > 1 ? esc_html__('Send them again', 'gpt3-ai-content-generator') : esc_html__('Send it again', 'gpt3-ai-content-generator'); ?></span></button>
                                <button type="button" class="aipkit_settings_app_failure_dismiss" data-aipkit-app-failure-dismiss><?php esc_html_e('Dismiss', 'gpt3-ai-content-generator'); ?></button>
                            </div>
                            <details class="aipkit_settings_provider_error_details">
                                <summary><?php esc_html_e('View details', 'gpt3-ai-content-generator'); ?></summary>
                                <p data-aipkit-app-failure-details><?php echo esc_html((string) $failures[0]['details']); ?></p>
                            </details>
                        </div>
                    </div>
                <?php endif; ?>
                <p class="aipkit_settings_app_failure_done" data-aipkit-app-failure-done role="status" hidden></p>
                <div class="aipkit_settings_provider_error is-warning" data-aipkit-app-rule-note role="status" <?php echo !$template && !$failures && $enabled && $state['key'] !== 'ready' && $state['summary'] !== '' ? '' : 'hidden'; ?>>
                    <span class="dashicons dashicons-warning" aria-hidden="true"></span>
                    <div class="aipkit_settings_provider_error_content"><p data-aipkit-app-rule-note-text><?php echo esc_html($state['summary']); ?></p></div>
                </div>

                <section class="aipkit_settings_provider_panel_section">
                    <h3 class="aipkit_settings_provider_panel_section_title"><?php esc_html_e('When', 'gpt3-ai-content-generator'); ?></h3>
                    <div class="aipkit_settings_provider_option">
                        <label class="aipkit_settings_provider_option_label"><?php esc_html_e('Something happens', 'gpt3-ai-content-generator'); ?></label>
                        <div class="aipkit_settings_provider_option_control">
                            <select class="aipkit_form-input aipkit_autosave_trigger" name="<?php echo esc_attr($named('event_name')); ?>" data-aipkit-app-rule-field="event_name">
                                <?php foreach ($event_options as $event_key => $unused) : ?>
                                    <option value="<?php echo esc_attr((string) $event_key); ?>" <?php selected($event, (string) $event_key); ?>><?php echo esc_html($event_label((string) $event_key)); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                    <div class="aipkit_settings_provider_option" data-aipkit-app-rule-scope="chatbot" <?php echo $is_chat_event ? '' : 'hidden'; ?>>
                        <label class="aipkit_settings_provider_option_label"><?php esc_html_e('From', 'gpt3-ai-content-generator'); ?></label>
                        <div class="aipkit_settings_provider_option_control">
                            <select class="aipkit_form-input aipkit_autosave_trigger" name="<?php echo esc_attr($template ? '' : $named('filters') . '[chatbot][bot_ids][0]'); ?>" data-aipkit-app-rule-field="filters.chatbot" <?php echo $is_chat_event ? '' : 'disabled'; ?>>
                                <option value=""><?php esc_html_e('All chatbots', 'gpt3-ai-content-generator'); ?></option>
                                <?php foreach ($chatbot_scope_options as $bot_id => $bot_name) : ?>
                                    <option value="<?php echo esc_attr((string) $bot_id); ?>" <?php selected((string) ($bot_ids[0] ?? ''), (string) $bot_id); ?>><?php echo esc_html((string) $bot_name); ?></option>
                                <?php endforeach; ?>
                                <?php if ($bot_ids && !isset($chatbot_scope_options[$bot_ids[0]])) : ?>
                                    <?php /* translators: %d: chatbot ID. */ ?>
                                    <option value="<?php echo esc_attr((string) $bot_ids[0]); ?>" selected><?php echo esc_html(sprintf(__('Chatbot #%d', 'gpt3-ai-content-generator'), $bot_ids[0])); ?></option>
                                <?php endif; ?>
                            </select>
                        </div>
                    </div>
                    <div class="aipkit_settings_provider_option" data-aipkit-app-rule-scope="ai_form" <?php echo $is_form_event ? '' : 'hidden'; ?>>
                        <label class="aipkit_settings_provider_option_label"><?php esc_html_e('From', 'gpt3-ai-content-generator'); ?></label>
                        <div class="aipkit_settings_provider_option_control">
                            <select class="aipkit_form-input aipkit_autosave_trigger" name="<?php echo esc_attr($template ? '' : $named('filters') . '[ai_form][form_ids][0]'); ?>" data-aipkit-app-rule-field="filters.ai_form" <?php echo $is_form_event ? '' : 'disabled'; ?>>
                                <option value=""><?php esc_html_e('All AI forms', 'gpt3-ai-content-generator'); ?></option>
                                <?php foreach ($ai_form_scope_options as $form_id => $form_name) : ?>
                                    <option value="<?php echo esc_attr((string) $form_id); ?>" <?php selected((string) ($form_ids[0] ?? ''), (string) $form_id); ?>><?php echo esc_html((string) $form_name); ?></option>
                                <?php endforeach; ?>
                                <?php if ($form_ids && !isset($ai_form_scope_options[$form_ids[0]])) : ?>
                                    <?php /* translators: %d: AI form ID. */ ?>
                                    <option value="<?php echo esc_attr((string) $form_ids[0]); ?>" selected><?php echo esc_html(sprintf(__('AI form #%d', 'gpt3-ai-content-generator'), $form_ids[0])); ?></option>
                                <?php endif; ?>
                            </select>
                        </div>
                    </div>
                </section>

                <?php // An app with more than one thing to do, or more than one connection, asks which; the rest don't. ?>
                <section class="aipkit_settings_provider_panel_section" data-aipkit-app-rule-send <?php echo count($app_actions) > 1 || count($live_connections) > 1 ? '' : 'hidden'; ?>>
                    <h3 class="aipkit_settings_provider_panel_section_title"><?php esc_html_e('Send', 'gpt3-ai-content-generator'); ?></h3>
                    <div class="aipkit_settings_provider_option" <?php echo count($app_actions) > 1 ? '' : 'hidden'; ?>>
                        <label class="aipkit_settings_provider_option_label"><?php esc_html_e('Do this', 'gpt3-ai-content-generator'); ?></label>
                        <div class="aipkit_settings_provider_option_control">
                            <select class="aipkit_form-input aipkit_autosave_trigger" name="<?php echo esc_attr($named('action_slug')); ?>" data-aipkit-app-rule-field="action_slug">
                                <?php foreach ($app_actions as $action_key) : ?>
                                    <option value="<?php echo esc_attr($action_key); ?>" <?php selected($action, $action_key); ?>><?php echo esc_html($action_label($action_key)); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                    <div class="aipkit_settings_provider_option" data-aipkit-app-rule-connection-row <?php echo count($live_connections) > 1 ? '' : 'hidden'; ?>>
                        <label class="aipkit_settings_provider_option_label"><?php esc_html_e('Connection', 'gpt3-ai-content-generator'); ?></label>
                        <div class="aipkit_settings_provider_option_control">
                            <select class="aipkit_form-input aipkit_autosave_trigger" name="<?php echo esc_attr($named('connection_id')); ?>" data-aipkit-app-rule-field="connection_id">
                                <?php foreach ($live_connections as $live_connection) :
                                    $live_id = sanitize_text_field((string) ($live_connection['id'] ?? ''));
                                    ?>
                                    <option value="<?php echo esc_attr($live_id); ?>" <?php selected($connection_id, $live_id); ?>><?php echo esc_html((string) ($live_connection['name'] ?? '') !== '' ? (string) $live_connection['name'] : (string) ($apps[$slug] ?? $slug)); ?></option>
                                <?php endforeach; ?>
                                <?php if ($connection_id !== '' && !in_array($connection_id, array_map(static fn ($item) => sanitize_text_field((string) ($item['id'] ?? '')), $live_connections), true)) : ?>
                                    <option value="<?php echo esc_attr($connection_id); ?>" selected><?php esc_html_e('A removed connection', 'gpt3-ai-content-generator'); ?></option>
                                <?php endif; ?>
                            </select>
                        </div>
                    </div>
                </section>

                <section class="aipkit_settings_provider_panel_section">
                    <h3 class="aipkit_settings_provider_panel_section_title"><?php esc_html_e('What to send', 'gpt3-ai-content-generator'); ?></h3>
                    <div class="aipkit_settings_app_mapping_list" data-aipkit-app-mapping-list>
                        <?php foreach ($fields as $field_number => $field) {
                            $render_mapping_row($template ? '' : $named('mapping') . '[fields][' . $field_number . ']', $field, $event, $action);
                        } ?>
                    </div>
                    <div class="aipkit_settings_provider_field_links">
                        <span class="aipkit_settings_provider_option_help"><?php esc_html_e('Each field in the app, and what fills it.', 'gpt3-ai-content-generator'); ?></span>
                        <button type="button" class="aipkit_settings_app_text_button" data-aipkit-app-mapping-add><span class="dashicons dashicons-plus-alt2" aria-hidden="true"></span><span><?php esc_html_e('Add a field', 'gpt3-ai-content-generator'); ?></span></button>
                    </div>
                </section>

                <section class="aipkit_settings_provider_panel_section aipkit_settings_provider_options">
                    <h3 class="aipkit_settings_provider_panel_section_title"><?php esc_html_e('Options', 'gpt3-ai-content-generator'); ?></h3>
                    <div class="aipkit_settings_provider_option_list">
                        <div class="aipkit_settings_provider_option">
                            <label class="aipkit_settings_provider_option_label" for="<?php echo esc_attr($title_id); ?>_name"><?php esc_html_e('Name', 'gpt3-ai-content-generator'); ?></label>
                            <div class="aipkit_settings_provider_option_control">
                                <div class="aipkit_settings_provider_option_input">
                                    <input type="text" id="<?php echo esc_attr($title_id); ?>_name" class="aipkit_form-input aipkit_autosave_trigger" name="<?php echo esc_attr($named('name')); ?>" value="<?php echo esc_attr($name); ?>" placeholder="<?php esc_attr_e('Untitled rule', 'gpt3-ai-content-generator'); ?>" data-aipkit-app-rule-field="name" />
                                </div>
                            </div>
                        </div>
                        <div class="aipkit_settings_provider_option is-inline">
                            <div class="aipkit_settings_provider_option_copy">
                                <label class="aipkit_settings_provider_option_label" for="<?php echo esc_attr($title_id); ?>_on"><?php esc_html_e('Send this rule', 'gpt3-ai-content-generator'); ?></label>
                                <span class="aipkit_settings_provider_option_help"><?php esc_html_e('Turn it off to stop sending without losing it.', 'gpt3-ai-content-generator'); ?></span>
                            </div>
                            <div class="aipkit_settings_provider_option_control">
                                <label class="aipkit_switch" for="<?php echo esc_attr($title_id); ?>_on">
                                    <input type="checkbox" id="<?php echo esc_attr($title_id); ?>_on" value="1" data-aipkit-app-rule-enabled <?php checked($enabled); ?> />
                                    <span class="aipkit_switch_slider" aria-hidden="true"></span>
                                </label>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
            <div class="aipkit_settings_provider_modal_footer">
                <button type="button" class="aipkit_settings_provider_remove" data-aipkit-app-rule-remove
                    data-confirm-title="<?php esc_attr_e('Delete this rule?', 'gpt3-ai-content-generator'); ?>"
                    data-confirm-text="<?php esc_attr_e('It stops sending, and it can’t be brought back.', 'gpt3-ai-content-generator'); ?>"
                    data-confirm-button="<?php esc_attr_e('Delete', 'gpt3-ai-content-generator'); ?>"
                    data-cancel-button="<?php esc_attr_e('Cancel', 'gpt3-ai-content-generator'); ?>"
                ><?php esc_html_e('Delete rule', 'gpt3-ai-content-generator'); ?></button>
                <button type="button" class="aipkit_btn aipkit_btn-primary aipkit_settings_provider_done" data-aipkit-app-back><?php esc_html_e('Done', 'gpt3-ai-content-generator'); ?></button>
            </div>
        </div>
    </div>
    <?php
    return $rows_html;
};

// The browser needs the same definitions to fill in new rules and to recheck them as they change.
$client_definitions = [
    'templates' => $template_definitions,
    'mapping' => $mapping_definitions,
    'validation' => $validation_definitions,
    'events' => array_map(static fn ($pair) => $pair[1], $event_words),
    'eventIcons' => array_map(static fn ($pair) => $pair[0], $event_words),
    'actions' => $action_words,
    'status' => $status_words,
    'scope' => [
        'allChatbots' => __('All chatbots', 'gpt3-ai-content-generator'),
        'allForms' => __('All AI forms', 'gpt3-ai-content-generator'),
    ],
    'appNames' => $apps,
    'connectionAuth' => array_map(static fn ($config) => array_map(static fn ($auth) => array_merge([(string) $auth['key']], (array) ($auth['required'] ?? [])), (array) $config['auth']), $app_view),
    'text' => [
        /* translators: %d: number of rules. */
        'ruleOne' => __('%d rule', 'gpt3-ai-content-generator'),
        /* translators: %d: number of rules. */
        'ruleMany' => __('%d rules', 'gpt3-ai-content-generator'),
        'noRules' => __('No rules yet', 'gpt3-ai-content-generator'),
        'checkSetup' => __('Check setup', 'gpt3-ai-content-generator'),
        /* translators: %d: number of failed sends. */
        'failedOne' => __('%d failed send', 'gpt3-ai-content-generator'),
        /* translators: %d: number of failed sends. */
        'failedMany' => __('%d failed sends', 'gpt3-ai-content-generator'),
        'untitled' => __('Untitled rule', 'gpt3-ai-content-generator'),
        'chooseField' => __('Choose a field', 'gpt3-ai-content-generator'),
        'legacyHubspotNote' => __('Internal note (not sent)', 'gpt3-ai-content-generator'),
        'chooseSource' => __('Choose what to send', 'gpt3-ai-content-generator'),
        'noConnection' => __('Connect the app before this rule can send.', 'gpt3-ai-content-generator'),
        'unverified' => __('Connection is saved but has not been verified yet.', 'gpt3-ai-content-generator'),
        'testFailed' => __('This key didn’t work. Check it, or create a new one, and paste it again.', 'gpt3-ai-content-generator'),
        'unsupported' => __('This app can’t do that yet.', 'gpt3-ai-content-generator'),
        'disabled' => __('This connection is turned off.', 'gpt3-ai-content-generator'),
        'reauth' => __('Connect the app again before this rule can send.', 'gpt3-ai-content-generator'),
    ],
    // What a rule still needs, in the panel's words; the server's checks are the same.
    'needs' => [
        'slack_message_create' => __('Slack needs a bot token with a default channel, or a webhook URL.', 'gpt3-ai-content-generator'),
        'hubspot_contact_upsert' => __('HubSpot needs a private app token.', 'gpt3-ai-content-generator'),
        'notion_page_create' => __('To create pages, add a parent page ID to the Notion connection.', 'gpt3-ai-content-generator'),
        'notion_database_item_create' => __('To add database items, add a database ID to the Notion connection.', 'gpt3-ai-content-generator'),
        'pipedrive_person_upsert' => __('Pipedrive needs an API token and your company domain.', 'gpt3-ai-content-generator'),
        'zapier_webhook_trigger' => __('Zapier needs a webhook URL.', 'gpt3-ai-content-generator'),
        'make_webhook_trigger' => __('Make needs a webhook URL.', 'gpt3-ai-content-generator'),
        'n8n_webhook_trigger' => __('n8n needs a webhook URL.', 'gpt3-ai-content-generator'),
    ],
    'fieldNeeds' => [
        'hubspot_contact_upsert' => __('HubSpot needs an email for every contact. Choose what fills Email under What to send.', 'gpt3-ai-content-generator'),
        'pipedrive_person_upsert' => __('Pipedrive needs a name for every person. Choose what fills Name under What to send.', 'gpt3-ai-content-generator'),
    ],
];
?>
<div class="aipkit_settings_app_list" data-aipkit-app-list>
    <script type="application/json" data-aipkit-app-definitions><?php echo wp_json_encode($client_definitions, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT); ?></script>
    <div class="aipkit_settings_provider_cards aipkit_settings_integration_cards aipkit_settings_app_cards">
        <?php foreach ($apps as $slug => $app_name) :
            $slug = sanitize_key((string) $slug);
            $app_name = (string) $app_name;
            if (!isset($app_view[$slug])) {
                continue;
            }
            $app_connections = (array) ($connections_by_app[$slug] ?? []);
            $primary = (array) ($app_connections[0] ?? []);
            $connected = $is_connected($slug, $primary);
            $app_rules = (array) ($recipes_by_app[$slug] ?? []);
            $problem = false;
            foreach ($app_rules as $app_rule) {
                $problem = $problem || (!empty($app_rule['is_enabled']) && $rule_state($app_rule)['key'] !== 'ready');
            }
            $rule_count = count($app_rules);
            $failed_sends = 0;
            foreach ($app_rules as $app_rule) {
                $failed_sends += count((array) ($rule_failures[sanitize_text_field((string) ($app_rule['id'] ?? ''))] ?? []));
            }
            /* translators: %d: number of rules. */
            $summary = $rule_count ? sprintf(_n('%d rule', '%d rules', $rule_count, 'gpt3-ai-content-generator'), $rule_count) : __('No rules yet', 'gpt3-ai-content-generator');
            if ($failed_sends) {
                /* translators: %d: number of failed sends. */
                $summary .= ' · ' . sprintf(_n('%d failed send', '%d failed sends', $failed_sends, 'gpt3-ai-content-generator'), $failed_sends);
            } elseif ($problem) {
                $summary .= ' · ' . __('Check setup', 'gpt3-ai-content-generator');
            }
            $modal = 'app-' . $slug;
            $modal_id = 'aipkit_settings_app_' . $slug . '_modal';
            $primary_state = !empty($primary) && class_exists($diagnostics_class) && method_exists($diagnostics_class, 'get_connection_ui_state')
                ? (array) $diagnostics_class::get_connection_ui_state($primary) : [];
            $has_error = $connected && in_array(sanitize_key((string) ($primary_state['status_key'] ?? '')), ['error', 'reauth_required'], true);
            ?>
            <article
                id="aipkit_settings_app_card_<?php echo esc_attr($slug); ?>"
                class="aipkit_settings_provider_card aipkit_settings_app_card<?php echo $has_error ? ' has-provider-error' : ''; ?><?php echo $failed_sends ? ' has-failed-sends' : ''; ?>"
                data-aipkit-app-card="<?php echo esc_attr($slug); ?>"
                data-aipkit-provider-connected="<?php echo $connected ? 'true' : 'false'; ?>"
            >
                <div class="aipkit_settings_provider_card_main">
                    <span class="aipkit_settings_provider_logo aipkit_settings_app_logo" aria-hidden="true"><?php $render_app_mark($slug); ?></span>
                    <div class="aipkit_settings_provider_card_text">
                        <div class="aipkit_settings_provider_card_title">
                            <h4 class="aipkit_settings_provider_name"><?php echo esc_html($app_name); ?></h4>
                        </div>
                        <p class="aipkit_settings_provider_card_status">
                            <span class="aipkit_settings_provider_status aipkit_settings_provider_status--connected" <?php echo $connected ? '' : 'hidden'; ?>><?php esc_html_e('Connected', 'gpt3-ai-content-generator'); ?></span>
                            <span class="aipkit_settings_provider_status aipkit_settings_provider_status--disconnected" <?php echo $connected ? 'hidden' : ''; ?>><?php esc_html_e('Not connected', 'gpt3-ai-content-generator'); ?></span>
                            <span class="aipkit_settings_provider_status aipkit_settings_provider_status--sync-error" data-aipkit-app-error-status <?php echo $has_error ? '' : 'hidden'; ?>><?php esc_html_e('Not working', 'gpt3-ai-content-generator'); ?></span>
                            <span class="aipkit_settings_provider_summary<?php echo $failed_sends ? ' is-failed' : ($problem ? ' is-empty' : ''); ?>" data-aipkit-app-summary <?php echo $connected ? '' : 'hidden'; ?>><?php echo esc_html($summary); ?></span>
                            <span class="aipkit_settings_provider_tagline"><?php echo esc_html((string) $app_view[$slug]['tagline']); ?></span>
                        </p>
                    </div>
                    <button type="button" class="aipkit_settings_provider_card_action" data-aipkit-provider-settings-open="<?php echo esc_attr($modal); ?>" aria-haspopup="dialog" aria-controls="<?php echo esc_attr($modal_id); ?>">
                        <span class="aipkit_settings_provider_card_manage">
                            <?php /* translators: %s: app name. */ ?>
                            <span class="screen-reader-text"><?php echo esc_html(sprintf(__('Manage %s', 'gpt3-ai-content-generator'), $app_name)); ?></span>
                            <span class="dashicons dashicons-arrow-right-alt2" aria-hidden="true"></span>
                        </span>
                        <span class="aipkit_settings_provider_card_connect"><?php esc_html_e('Connect', 'gpt3-ai-content-generator'); ?><span class="screen-reader-text"><?php echo esc_html($app_name); ?></span></span>
                    </button>
                </div>

                <?php
                // Rules render first, so their rows are ready for the app panel's list.
                $rule_rows = [];
                ob_start();
                foreach ($app_rules as $app_rule) {
                    $rule_rows[] = $render_rule($slug, $app_rule);
                }
                $rule_modals = (string) ob_get_clean();
                ?>
                <div class="aipkit-modal-overlay aipkit_settings_provider_modal" id="<?php echo esc_attr($modal_id); ?>" data-aipkit-provider-modal="<?php echo esc_attr($modal); ?>" aria-hidden="true">
                    <div class="aipkit-modal-content aipkit_settings_provider_panel" role="dialog" aria-modal="true" aria-labelledby="<?php echo esc_attr($modal_id); ?>_title">
                        <div class="aipkit_settings_provider_panel_header">
                            <span class="aipkit_settings_provider_logo aipkit_settings_app_logo" aria-hidden="true"><?php $render_app_mark($slug); ?></span>
                            <div class="aipkit_settings_provider_panel_heading">
                                <div class="aipkit_settings_provider_panel_title_row">
                                    <h2 class="aipkit_settings_provider_panel_title" id="<?php echo esc_attr($modal_id); ?>_title"><?php echo esc_html($app_name); ?></h2>
                                    <span class="aipkit_settings_provider_pill aipkit_settings_provider_pill--on"><?php esc_html_e('Connected', 'gpt3-ai-content-generator'); ?></span>
                                    <span class="aipkit_settings_provider_pill aipkit_settings_provider_pill--off"><?php esc_html_e('Not connected', 'gpt3-ai-content-generator'); ?></span>
                                    <span class="aipkit_settings_provider_pill aipkit_settings_provider_pill--invalid"><?php esc_html_e('Key rejected', 'gpt3-ai-content-generator'); ?></span>
                                    <span class="aipkit_settings_provider_pill aipkit_settings_provider_pill--error"><?php esc_html_e('Not working', 'gpt3-ai-content-generator'); ?></span>
                                </div>
                                <p class="aipkit_settings_provider_panel_hint"><?php echo esc_html((string) $app_view[$slug]['tagline']); ?></p>
                            </div>
                            <button type="button" class="aipkit_settings_provider_panel_close" data-aipkit-provider-modal-close aria-label="<?php esc_attr_e('Close', 'gpt3-ai-content-generator'); ?>"><span class="dashicons dashicons-no-alt" aria-hidden="true"></span></button>
                        </div>
                        <div class="aipkit_settings_provider_panel_body">
                            <section class="aipkit_settings_provider_panel_section aipkit_settings_provider_connection_fields">
                                <h3 class="aipkit_settings_provider_panel_section_title"><?php esc_html_e('Connection', 'gpt3-ai-content-generator'); ?></h3>
                                <?php $primary_index = $render_connection($slug, $primary, true); ?>
                            </section>

                            <?php if ($has_rules) : ?>
                                <section class="aipkit_settings_provider_panel_section" data-aipkit-app-connected-only <?php echo $connected ? '' : 'hidden'; ?>>
                                    <h3 class="aipkit_settings_provider_panel_section_title"><?php esc_html_e('Rules', 'gpt3-ai-content-generator'); ?></h3>
                                    <div class="aipkit_settings_app_rule_list" data-aipkit-app-rule-list>
                                        <?php echo $rule_rows ? implode('', $rule_rows) : ''; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Rendered and escaped above. ?>
                                        <button type="button" class="aipkit_settings_app_rule_add" data-aipkit-provider-settings-open="app-add-<?php echo esc_attr($slug); ?>" aria-haspopup="dialog">
                                            <span class="dashicons dashicons-plus-alt2" aria-hidden="true"></span><span><?php esc_html_e('Add a rule', 'gpt3-ai-content-generator'); ?></span>
                                        </button>
                                    </div>
                                    <p class="aipkit_settings_provider_option_help"><?php esc_html_e('Each rule says when to send and what. A chatbot shows the rules that cover it.', 'gpt3-ai-content-generator'); ?></p>
                                </section>
                            <?php endif; ?>

                            <?php
                            $optional_paths = array_values(array_filter((array) ($app_view[$slug]['optional'] ?? []), static fn ($path) => isset($field_index[$slug][$path])));
                            if ($optional_paths) :
                                $fold_values = array_filter(array_map(static fn ($path) => $field_value($primary, $path), $optional_paths));
                                ?>
                                <details class="aipkit_settings_provider_fold" data-aipkit-app-connected-only <?php echo $connected ? '' : 'hidden'; ?>>
                                    <summary>
                                        <span class="aipkit_settings_provider_option_copy">
                                            <?php /* translators: %s: app name. */ ?>
                                            <span class="aipkit_settings_provider_option_label"><?php echo esc_html(sprintf(__('More %s settings', 'gpt3-ai-content-generator'), $app_name)); ?></span>
                                            <span class="aipkit_settings_provider_option_help" data-aipkit-app-fold-summary data-empty="<?php esc_attr_e('Optional', 'gpt3-ai-content-generator'); ?>"><?php echo esc_html($fold_values ? implode(' · ', $fold_values) : __('Optional', 'gpt3-ai-content-generator')); ?></span>
                                        </span>
                                        <span class="dashicons dashicons-arrow-down-alt2" aria-hidden="true"></span>
                                    </summary>
                                    <div class="aipkit_settings_provider_fold_body" data-aipkit-app-optional-fields>
                                        <?php foreach ($optional_paths as $path) :
                                            $definition = (array) $field_index[$slug][$path];
                                            $field_id = 'aipkit_app_' . sanitize_html_class($slug) . '_optional_' . sanitize_html_class(str_replace('.', '_', $path));
                                            ?>
                                            <div class="aipkit_settings_provider_option">
                                                <label class="aipkit_settings_provider_option_label" for="<?php echo esc_attr($field_id); ?>"><?php echo esc_html((string) ($definition['label'] ?? $path)); ?></label>
                                                <div class="aipkit_settings_provider_option_control">
                                                    <div class="aipkit_settings_provider_option_input">
                                                        <input type="text" id="<?php echo esc_attr($field_id); ?>" class="aipkit_form-input aipkit_autosave_trigger" name="<?php echo $primary_index === '' ? '' : esc_attr('native_app_recipes[connections][' . $primary_index . '][' . str_replace('.', '][', $path) . ']'); ?>" value="<?php echo esc_attr($field_value($primary, $path)); ?>" placeholder="<?php echo esc_attr((string) ($definition['placeholder'] ?? '')); ?>" data-aipkit-app-optional-field="<?php echo esc_attr($path); ?>" />
                                                    </div>
                                                </div>
                                            </div>
                                        <?php endforeach; ?>
                                    </div>
                                </details>
                            <?php endif; ?>

                            <details class="aipkit_settings_provider_fold" data-aipkit-app-connected-only <?php echo $connected ? '' : 'hidden'; ?> <?php echo count($app_connections) > 1 ? 'open' : ''; ?>>
                                <summary>
                                    <span class="aipkit_settings_provider_option_copy">
                                        <?php /* translators: %s: app name. */ ?>
                                        <span class="aipkit_settings_provider_option_label"><?php echo esc_html(sprintf(__('Another %s connection?', 'gpt3-ai-content-generator'), $app_name)); ?></span>
                                        <span class="aipkit_settings_provider_option_help"><?php esc_html_e('For a second account or workspace. Rules then choose which one.', 'gpt3-ai-content-generator'); ?></span>
                                    </span>
                                    <span class="dashicons dashicons-arrow-down-alt2" aria-hidden="true"></span>
                                </summary>
                                <div class="aipkit_settings_provider_fold_body" data-aipkit-app-extra-connections>
                                    <?php foreach (array_slice($app_connections, 1) as $extra_connection) {
                                        $render_connection($slug, $extra_connection, false);
                                    } ?>
                                    <button type="button" class="aipkit_settings_app_text_button" data-aipkit-app-connection-add><span class="dashicons dashicons-plus-alt2" aria-hidden="true"></span><span><?php esc_html_e('Add a connection', 'gpt3-ai-content-generator'); ?></span></button>
                                </div>
                            </details>
                        </div>
                        <div class="aipkit_settings_provider_modal_footer">
                            <button type="button" class="aipkit_settings_provider_remove" data-aipkit-app-disconnect data-aipkit-app-connected-only <?php echo $connected ? '' : 'hidden'; ?>
                                <?php /* translators: %s: app name. */ ?>
                                data-confirm-title="<?php echo esc_attr(sprintf(__('Disconnect %s?', 'gpt3-ai-content-generator'), $app_name)); ?>"
                                <?php /* translators: %s: app name. */ ?>
                                data-confirm-text="<?php echo esc_attr(sprintf(__('Rules that send to %s stop until you connect it again. They are kept.', 'gpt3-ai-content-generator'), $app_name)); ?>"
                                data-confirm-button="<?php esc_attr_e('Disconnect', 'gpt3-ai-content-generator'); ?>"
                                data-cancel-button="<?php esc_attr_e('Cancel', 'gpt3-ai-content-generator'); ?>"
                            ><?php
                                /* translators: %s: app name. */
                                echo esc_html(sprintf(__('Disconnect %s', 'gpt3-ai-content-generator'), $app_name));
                            ?></button>
                            <button type="button" class="aipkit_btn aipkit_btn-primary aipkit_settings_provider_done" data-aipkit-provider-modal-close><?php esc_html_e('Done', 'gpt3-ai-content-generator'); ?></button>
                        </div>
                    </div>
                </div>

                <?php echo $rule_modals; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Rendered and escaped above. ?>

                <?php if ($has_rules) : ?>
                    <div class="aipkit-modal-overlay aipkit_settings_provider_modal" data-aipkit-provider-modal="app-add-<?php echo esc_attr($slug); ?>" data-aipkit-app-parent="<?php echo esc_attr($modal); ?>" aria-hidden="true">
                        <div class="aipkit-modal-content aipkit_settings_provider_panel" role="dialog" aria-modal="true" aria-labelledby="<?php echo esc_attr($modal_id); ?>_add_title">
                            <div class="aipkit_settings_provider_panel_header">
                                <button type="button" class="aipkit_settings_provider_panel_close aipkit_settings_app_back" data-aipkit-app-back aria-label="<?php esc_attr_e('Back', 'gpt3-ai-content-generator'); ?>"><span class="dashicons dashicons-arrow-left-alt2" aria-hidden="true"></span></button>
                                <span class="aipkit_settings_provider_logo aipkit_settings_app_logo" aria-hidden="true"><?php $render_app_mark($slug); ?></span>
                                <div class="aipkit_settings_provider_panel_heading">
                                    <h2 class="aipkit_settings_provider_panel_title" id="<?php echo esc_attr($modal_id); ?>_add_title"><?php esc_html_e('Add a rule', 'gpt3-ai-content-generator'); ?></h2>
                                    <p class="aipkit_settings_provider_panel_hint"><?php echo esc_html($app_name); ?></p>
                                </div>
                            </div>
                            <div class="aipkit_settings_provider_panel_body">
                                <section class="aipkit_settings_provider_panel_section">
                                    <?php /* translators: %s: app name. */ ?>
                                    <h3 class="aipkit_settings_provider_panel_section_title"><?php echo esc_html(sprintf(__('What should go to %s?', 'gpt3-ai-content-generator'), $app_name)); ?></h3>
                                    <div class="aipkit_settings_app_rule_list">
                                        <?php foreach ($template_definitions as $template_slug => $template) :
                                            if (!is_array($template) || sanitize_key((string) ($template['app_slug'] ?? '')) !== $slug) {
                                                continue;
                                            }
                                            $template_event = (string) ($template['event_name'] ?? '');
                                            ?>
                                            <button type="button" class="aipkit_settings_app_rule_row" data-aipkit-app-rule-create="<?php echo esc_attr((string) $template_slug); ?>">
                                                <span class="aipkit_settings_app_rule_icon dashicons dashicons-<?php echo esc_attr($event_icon($template_event)); ?>" aria-hidden="true"></span>
                                                <span class="aipkit_settings_app_rule_copy">
                                                    <span class="aipkit_settings_app_rule_title"><?php echo esc_html((string) ($template['label'] ?? $template_slug)); ?></span>
                                                    <span class="aipkit_settings_app_rule_meta"><?php echo esc_html($event_label($template_event)); ?></span>
                                                </span>
                                                <span class="aipkit_settings_app_rule_cta"><?php esc_html_e('Add', 'gpt3-ai-content-generator'); ?></span>
                                            </button>
                                        <?php endforeach; ?>
                                        <button type="button" class="aipkit_settings_app_rule_row" data-aipkit-app-rule-create="">
                                            <span class="aipkit_settings_app_rule_icon dashicons dashicons-admin-generic" aria-hidden="true"></span>
                                            <span class="aipkit_settings_app_rule_copy">
                                                <span class="aipkit_settings_app_rule_title"><?php esc_html_e('Start from scratch', 'gpt3-ai-content-generator'); ?></span>
                                                <span class="aipkit_settings_app_rule_meta"><?php esc_html_e('Choose when it sends and each field yourself.', 'gpt3-ai-content-generator'); ?></span>
                                            </span>
                                            <span class="aipkit_settings_app_rule_cta"><?php esc_html_e('Add', 'gpt3-ai-content-generator'); ?></span>
                                        </button>
                                    </div>
                                    <p class="aipkit_settings_provider_option_help"><?php esc_html_e('A rule starts with its fields filled in, and it sends right away. Change anything after.', 'gpt3-ai-content-generator'); ?></p>
                                </section>
                            </div>
                            <div class="aipkit_settings_provider_modal_footer">
                                <button type="button" class="aipkit_btn aipkit_btn-primary aipkit_settings_provider_done" data-aipkit-app-back><?php esc_html_e('Done', 'gpt3-ai-content-generator'); ?></button>
                            </div>
                        </div>
                    </div>
                    <template data-aipkit-app-rule-template="<?php echo esc_attr($slug); ?>"><?php $render_rule($slug, ['is_enabled' => true], true); ?></template>
                <?php endif; ?>
                <template data-aipkit-app-connection-template="<?php echo esc_attr($slug); ?>"><?php $render_connection($slug, [], false); ?></template>
            </article>
        <?php endforeach; ?>
    </div>
    <?php if ($has_rules) : ?>
        <template data-aipkit-app-mapping-template><?php $render_mapping_row('', [], '', ''); ?></template>
    <?php endif; ?>
</div>
