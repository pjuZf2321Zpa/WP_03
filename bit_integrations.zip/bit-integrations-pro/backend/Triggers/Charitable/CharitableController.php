<?php

namespace BitApps\IntegrationsPro\Triggers\Charitable;

use BitApps\IntegrationsPro\Config;
use WP_Post;

final class CharitableController
{
    private const STATUS_TRIGGER_STATUSES = [
        'charitable-completed',
        'charitable-refunded',
        'charitable-cancelled',
        'charitable-failed',
        'charitable-pending',
    ];

    public static function info()
    {
        return [
            'name'              => 'Charitable',
            'title'             => __('The best WordPress donation and fundraising plugin', 'bit-integrations-pro'),
            'type'              => 'custom_form_submission',
            'is_active'         => static::isPluginInstalled(),
            'tutorial_url'      => '#',
            'tasks'             => [
                'action' => 'charitable/get',
                'method' => 'get',
            ],
            'fetch' => [
                'action' => 'trigger/test',
                'method' => 'post',
            ],
            'fetch_remove' => [
                'action' => 'trigger/test/remove',
                'method' => 'post',
            ],
            'isPro' => true
        ];
    }

    public function getAllTasks()
    {
        if (!static::isPluginInstalled()) {
            wp_send_json_error(\sprintf(__('%s is not installed or activated', 'bit-integrations-pro'), 'Charitable'));
        }

        wp_send_json_success([
            ['form_name' => __('Donation Created', 'bit-integrations-pro'), 'triggered_entity_id' => 'charitable_after_save_donation', 'skipPrimaryKey' => true, 'note' => 'When a donation is saved, whether from the donation form or created programmatically.'],
            ['form_name' => __('Donation Updated', 'bit-integrations-pro'), 'triggered_entity_id' => 'charitable_donation_save', 'skipPrimaryKey' => true, 'note' => 'When a donation is saved from the admin donation screen.'],
            ['form_name' => __('Donation Status Changed', 'bit-integrations-pro'), 'triggered_entity_id' => 'charitable_donation_status_changed', 'skipPrimaryKey' => true, 'note' => 'When a donation moves to any new status. Carries both the old and the new status.'],
            ['form_name' => __('Donation Completed', 'bit-integrations-pro'), 'triggered_entity_id' => 'charitable_donation_status_charitable-completed', 'skipPrimaryKey' => true, 'note' => 'When a donation is marked as paid.'],
            ['form_name' => __('Donation Refunded', 'bit-integrations-pro'), 'triggered_entity_id' => 'charitable_donation_status_charitable-refunded', 'skipPrimaryKey' => true, 'note' => 'When a donation is refunded.'],
            ['form_name' => __('Donation Cancelled', 'bit-integrations-pro'), 'triggered_entity_id' => 'charitable_donation_status_charitable-cancelled', 'skipPrimaryKey' => true, 'note' => 'When a donation is cancelled.'],
            ['form_name' => __('Donation Failed', 'bit-integrations-pro'), 'triggered_entity_id' => 'charitable_donation_status_charitable-failed', 'skipPrimaryKey' => true, 'note' => 'When a donation payment fails.'],
            ['form_name' => __('Donation Pending', 'bit-integrations-pro'), 'triggered_entity_id' => 'charitable_donation_status_charitable-pending', 'skipPrimaryKey' => true, 'note' => 'When a donation moves back to pending.'],
            ['form_name' => __('Campaign Created', 'bit-integrations-pro'), 'triggered_entity_id' => 'charitable_campaign_created', 'skipPrimaryKey' => true, 'note' => 'When a new campaign is inserted.'],
            ['form_name' => __('Campaign Updated', 'bit-integrations-pro'), 'triggered_entity_id' => 'charitable_campaign_updated', 'skipPrimaryKey' => true, 'note' => 'When an existing campaign is updated.'],
            ['form_name' => __('Campaign Saved in Builder', 'bit-integrations-pro'), 'triggered_entity_id' => 'charitable_builder_save_campaign', 'skipPrimaryKey' => true, 'note' => 'When a campaign is saved from the campaign builder. Preview saves are ignored.'],
            ['form_name' => __('Campaign Ended', 'bit-integrations-pro'), 'triggered_entity_id' => 'charitable_campaign_end', 'skipPrimaryKey' => true, 'note' => 'When a campaign reaches its end date.'],
            ['form_name' => __('Donor Created', 'bit-integrations-pro'), 'triggered_entity_id' => 'charitable_after_insert_donor', 'skipPrimaryKey' => true, 'note' => 'When a new donor record is added.'],
            ['form_name' => __('Donor Contact Consent Changed', 'bit-integrations-pro'), 'triggered_entity_id' => 'charitable_donor_contact_consent_changed', 'skipPrimaryKey' => true, 'note' => 'When a donor grants or withdraws contact consent.'],
            ['form_name' => __('User Created', 'bit-integrations-pro'), 'triggered_entity_id' => 'charitable_after_insert_user', 'skipPrimaryKey' => true, 'note' => 'When Charitable registers a new WordPress user.'],
            ['form_name' => __('User Updated', 'bit-integrations-pro'), 'triggered_entity_id' => 'charitable_after_save_user', 'skipPrimaryKey' => true, 'note' => 'When Charitable saves a WordPress user.'],
            ['form_name' => __('User Verified', 'bit-integrations-pro'), 'triggered_entity_id' => 'charitable_user_verified', 'skipPrimaryKey' => true, 'note' => 'When a user confirms their email address.'],
            ['form_name' => __('Profile Updated', 'bit-integrations-pro'), 'triggered_entity_id' => 'charitable_profile_updated', 'skipPrimaryKey' => true, 'note' => 'When a donor updates their profile from the front-end profile form.'],
        ]);
    }

    public static function handleDonationCreated($donationId)
    {
        return static::flowExecute('charitable_after_save_donation', static::getDonationData($donationId));
    }

    public static function handleDonationUpdated($donationId)
    {
        return static::flowExecute('charitable_donation_save', static::getDonationData($donationId));
    }

    public static function handleDonationStatusTransition($newStatus, $oldStatus, $post)
    {
        if (!static::isDonationStatusTransition($newStatus, $oldStatus, $post)) {
            return;
        }

        $formData = static::getDonationData($post->ID);

        if (empty($formData)) {
            return;
        }

        $formData['old_status'] = $oldStatus;

        if (\in_array($newStatus, self::STATUS_TRIGGER_STATUSES, true)) {
            static::flowExecute("charitable_donation_status_{$newStatus}", $formData);
        }

        $formData['new_status'] = $newStatus;

        return static::flowExecute('charitable_donation_status_changed', $formData);
    }

    public static function handleCampaignSaveCore($type, $campaignId)
    {
        if ($type !== 'insert' && $type !== 'update') {
            return;
        }

        $triggeredEntityId = $type === 'insert' ? 'charitable_campaign_created' : 'charitable_campaign_updated';

        return static::flowExecute($triggeredEntityId, static::getCampaignData($campaignId));
    }

    public static function handleCampaignSavedInBuilder($campaignId, $campaignSettings = [], $campaignPost = [], $isPreview = false)
    {
        if ($isPreview) {
            return;
        }

        $formData = static::getCampaignData($campaignId);

        if (empty($formData)) {
            return;
        }

        $formData['builder_settings'] = $campaignSettings;
        $formData['builder_fields'] = $campaignPost;

        return static::flowExecute('charitable_builder_save_campaign', $formData);
    }

    public static function handleCampaignEnded($campaignId)
    {
        return static::flowExecute('charitable_campaign_end', static::getCampaignData($campaignId));
    }

    public static function handleDonorCreated($donorId)
    {
        return static::flowExecute('charitable_after_insert_donor', static::getDonorData($donorId));
    }

    public static function handleDonorConsentChanged($consentChanged, $statementChanged, $donorId)
    {
        $formData = static::getDonorData($donorId);

        if (empty($formData)) {
            return;
        }

        $formData['consent_changed'] = (bool) $consentChanged;
        $formData['statement_changed'] = (bool) $statementChanged;

        return static::flowExecute('charitable_donor_contact_consent_changed', $formData);
    }

    public static function handleUserCreated($userId, $values = [])
    {
        return static::flowExecute('charitable_after_insert_user', static::getUserData($userId, $values));
    }

    public static function handleUserUpdated($userId, $values = [])
    {
        return static::flowExecute('charitable_after_save_user', static::getUserData($userId, $values));
    }

    public static function handleUserVerified($user)
    {
        if (!\is_object($user) || empty($user->ID)) {
            return;
        }

        return static::flowExecute('charitable_user_verified', static::getUserData($user->ID));
    }

    public static function handleProfileUpdated($submitted)
    {
        if (!\is_array($submitted)) {
            return;
        }

        $userId = isset($submitted['ID']) ? (int) $submitted['ID'] : get_current_user_id();

        return static::flowExecute('charitable_profile_updated', static::getUserData($userId, $submitted));
    }

    private static function isDonationStatusTransition($newStatus, $oldStatus, $post)
    {
        if (!$post instanceof WP_Post || $post->post_type !== 'donation' || $newStatus === $oldStatus) {
            return false;
        }

        if (\in_array($oldStatus, ['new', 'auto-draft'], true) || !\function_exists('charitable_get_valid_donation_statuses')) {
            return false;
        }

        return \array_key_exists($newStatus, charitable_get_valid_donation_statuses());
    }

    private static function getDonationData($donationId)
    {
        $donationId = (int) $donationId;

        if ($donationId <= 0 || !\function_exists('charitable_get_donation')) {
            return [];
        }

        wp_cache_delete($donationId, 'charitable_donation');

        $donation = charitable_get_donation($donationId);

        if (!$donation) {
            return [];
        }

        $campaigns = [];

        foreach ((array) $donation->get_campaign_donations() as $campaignDonation) {
            $campaigns[] = (array) $campaignDonation;
        }

        $donorId = (int) $donation->get_donor_id();

        return [
            'donation_id'    => $donationId,
            'donation_key'   => $donation->get_donation_key(),
            'status'         => $donation->get_status(),
            'status_label'   => $donation->get_status_label(),
            'total'          => $donation->get_total_donation_amount(),
            'currency'       => $donation->get_currency(),
            'gateway'        => $donation->get_gateway(),
            'gateway_label'  => $donation->get_gateway_label(),
            'transaction_id' => $donation->get_gateway_transaction_id(),
            'date'           => $donation->get_date('Y-m-d H:i:s'),
            'note'           => $donation->get_notes(),
            'campaigns'      => $campaigns,
            'donor_id'       => $donorId,
            'donor'          => static::getDonorData($donorId),
        ];
    }

    private static function getCampaignData($campaignId)
    {
        $campaignId = (int) $campaignId;

        if ($campaignId <= 0 || get_post_type($campaignId) !== 'campaign') {
            return [];
        }

        $post = get_post($campaignId);

        $data = [
            'campaign_id' => $campaignId,
            'title'       => $post->post_title,
            'content'     => $post->post_content,
            'status'      => $post->post_status,
            'permalink'   => get_permalink($campaignId),
            'date'        => $post->post_date,
            'creator_id'  => (int) $post->post_author,
            'categories'  => static::getTermNames($campaignId, 'campaign_category'),
            'tags'        => static::getTermNames($campaignId, 'campaign_tag'),
        ];

        if (\function_exists('charitable_get_campaign')) {
            $campaign = charitable_get_campaign($campaignId);

            if ($campaign) {
                $data['goal'] = $campaign->get_goal();
                $data['donated_amount'] = $campaign->get_donated_amount();
                $data['percent_donated'] = $campaign->get_percent_donated_raw();
                $data['donor_count'] = $campaign->get_donor_count();
                $data['end_date'] = $campaign->get_end_date('Y-m-d H:i:s');
                $data['has_ended'] = $campaign->has_ended();
            }
        }

        return $data;
    }

    private static function getDonorData($donorId)
    {
        $donorId = (int) $donorId;

        if ($donorId <= 0 || !\function_exists('charitable_get_table')) {
            return [];
        }

        $rows = charitable_get_table('donors')->get_personal_data_by_donor_id($donorId);
        $donor = \is_array($rows) ? reset($rows) : $rows;

        if (!$donor) {
            return [];
        }

        $data = (array) $donor;
        $data['donor_id'] = $donorId;

        return $data;
    }

    private static function getUserData($userId, $submitted = [])
    {
        $userId = (int) $userId;

        if ($userId <= 0) {
            return [];
        }

        $userClass = bit_integrations_get_class('Core\\Util\\User');
        $data = (array) $userClass::get($userId);

        if (empty($data)) {
            return [];
        }

        if (\function_exists('charitable_get_table')) {
            $donorId = (int) charitable_get_table('donors')->get_donor_id($userId);

            if ($donorId > 0) {
                $data['donor_id'] = $donorId;
                $data['donor'] = static::getDonorData($donorId);
            }
        }

        if (!empty($submitted) && \is_array($submitted)) {
            unset($submitted['user_pass'], $submitted['user_pass_repeat'], $submitted['current_pass']);

            $data['submitted'] = $submitted;
        }

        return $data;
    }

    private static function getTermNames($campaignId, $taxonomy)
    {
        $terms = wp_get_object_terms($campaignId, $taxonomy, ['fields' => 'names']);

        return is_wp_error($terms) ? [] : $terms;
    }

    private static function flowExecute($triggered_entity_id, $formData)
    {
        if (empty($formData) || !\is_array($formData)) {
            return;
        }

        $helperClass = bit_integrations_get_class('Core\\Util\\Helper');
        $flowClass = bit_integrations_get_class('Flow\\Flow');

        $formData = $helperClass::prepareFetchFormatFields($formData);

        if (empty($formData)) {
            return;
        }

        $helperClass::setTestData(Config::withFreePrefix("{$triggered_entity_id}_test"), array_values($formData));

        $flows = $flowClass::exists('Charitable', $triggered_entity_id);

        if (empty($flows)) {
            return;
        }

        $flowClass::execute('Charitable', $triggered_entity_id, array_column($formData, 'value', 'name'), $flows);

        return ['type' => 'success'];
    }

    private static function isPluginInstalled()
    {
        return class_exists('Charitable');
    }
}
