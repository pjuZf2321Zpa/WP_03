<?php

namespace FluentBookingPro\App\Hooks\Handlers;

use FluentBooking\App\Models\Booking;
use FluentBookingPro\App\Modules\MCP\BookingNoteTools;
use FluentBookingPro\App\Services\BookingNoteService;

defined('ABSPATH') || exit;

/**
 * Wires host notes into the free plugin: the MCP booking projection, and
 * the move that keeps a group's notes when the anchor guest is deleted.
 *
 * The admin list is its own request. It is not added to the booking
 * details payload.
 */
class BookingNoteHandler
{
    public function register()
    {
        add_filter('fluent_booking/mcp_booking_full', [$this, 'appendMcpNotes'], 10, 4);
        add_action('fluent_booking/before_delete_booking', [$this, 'reassignNotes']);

        BookingNoteTools::register();
    }

    /**
     * @param array $data
     * @param Booking $booking
     * @param string $timezone
     * @param array $include
     * @return array
     */
    public function appendMcpNotes($data, $booking, $timezone, $include)
    {
        if (!is_array($data) || !$booking instanceof Booking || !in_array('notes', (array) $include, true)) {
            return $data;
        }

        $data['notes'] = BookingNoteTools::projectAll($booking, $timezone);

        return $data;
    }

    /**
     * @param Booking $booking
     * @return void
     */
    public function reassignNotes($booking)
    {
        if (!$booking instanceof Booking) {
            return;
        }

        BookingNoteService::reassignOnDelete($booking);
    }
}
