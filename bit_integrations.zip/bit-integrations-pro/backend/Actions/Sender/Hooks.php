<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Actions\Sender\SenderProHelper;
use BitApps\IntegrationsPro\Config;
use BitApps\IntegrationsPro\Core\Util\Hooks;

Hooks::filter(Config::withFreePrefix('sender_create_or_update_subscriber'), [SenderProHelper::class, 'createOrUpdateSubscriber'], 10, 3);
Hooks::filter(Config::withFreePrefix('sender_update_subscriber'), [SenderProHelper::class, 'updateSubscriber'], 10, 3);
Hooks::filter(Config::withFreePrefix('sender_delete_subscriber'), [SenderProHelper::class, 'deleteSubscriber'], 10, 3);
Hooks::filter(Config::withFreePrefix('sender_remove_phone_from_subscriber'), [SenderProHelper::class, 'removePhoneFromSubscriber'], 10, 3);
Hooks::filter(Config::withFreePrefix('sender_add_subscriber_to_group'), [SenderProHelper::class, 'addSubscriberToGroup'], 10, 3);
Hooks::filter(Config::withFreePrefix('sender_remove_subscriber_from_group'), [SenderProHelper::class, 'removeSubscriberFromGroup'], 10, 3);
Hooks::filter(Config::withFreePrefix('sender_create_group'), [SenderProHelper::class, 'createGroup'], 10, 3);
Hooks::filter(Config::withFreePrefix('sender_update_group'), [SenderProHelper::class, 'updateGroup'], 10, 3);
Hooks::filter(Config::withFreePrefix('sender_delete_group'), [SenderProHelper::class, 'deleteGroup'], 10, 3);
