<?php
/**
 * Orchestrates the Facebook Events → calendar sync module. Instantiated
 * from Custom_Facebook_Feed_Pro::instance(); hooks via register_hooks().
 *
 * @package CustomFacebookFeed\Events_Integration
 * @since 4.11
 */

namespace CustomFacebookFeed\Events_Integration;

use CustomFacebookFeed\Events_Integration\Admin\EventsSyncPromo;
use CustomFacebookFeed\Events_Integration\Admin\EventsSyncSettings;
use CustomFacebookFeed\Events_Integration\Provider\EventsProvider;
use CustomFacebookFeed\Events_Integration\Sync\ImageSideloader;
use CustomFacebookFeed\Events_Integration\Sync\Scheduler;
use CustomFacebookFeed\Events_Integration\Sync\SyncEngine;
use CustomFacebookFeed\Events_Integration\Sync\SyncState;
use CustomFacebookFeed\Events_Integration\Targets\SugarCalendarAdapter;
use CustomFacebookFeed\Events_Integration\Targets\TECAdapter;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class EventsIntegration {

	/**
	 * @var EventsProvider
	 */
	private $provider;

	/**
	 * @var SyncEngine
	 */
	private $engine;

	/**
	 * @var Scheduler
	 */
	private $scheduler;

	/**
	 * @var EventsSyncSettings
	 */
	private $admin;

	/**
	 * @var EventsSyncPromo
	 */
	private $promo;

	public function __construct() {
		$this->provider  = new EventsProvider();
		// Adapters resolve lazily so cff_events_sync_adapters filters added
		// on plugins_loaded/init are included (we're constructed earlier).
		$this->engine    = new SyncEngine( $this->provider, new SyncState(), new ImageSideloader(), array( self::class, 'adapters' ) );
		$this->scheduler = new Scheduler();
		$this->admin     = new EventsSyncSettings( $this->engine, $this->scheduler );
		$this->promo     = new EventsSyncPromo();
	}

	/**
	 * All target adapters, keyed by target ID.
	 *
	 * @return array<string, Targets\TargetAdapterInterface>
	 */
	public static function adapters() {
		$adapters = array(
			Config::TARGET_SUGAR_CALENDAR => new SugarCalendarAdapter(),
			Config::TARGET_TEC            => new TECAdapter(),
		);

		/**
		 * Filter the registered calendar target adapters.
		 *
		 * @param array $adapters Adapters keyed by target ID.
		 */
		return apply_filters( 'cff_events_sync_adapters', $adapters );
	}

	/**
	 * Register WordPress hooks. Called once from the plugin bootstrap.
	 */
	public function register_hooks() {
		add_action( 'init', array( $this->scheduler, 'maybe_schedule' ) );
		add_action( Config::CRON_HOOK, array( $this, 'run_scheduled_sync' ) );
		add_action( Config::BATCH_HOOK, array( $this, 'run_batch' ) );

		$this->admin->register_hooks();
		$this->promo->register_hooks();
	}

	/**
	 * Cron entry point: start a sync run from the first source.
	 */
	public function run_scheduled_sync() {
		if ( ! Config::is_enabled() ) {
			return;
		}
		$this->engine->run();
	}

	/**
	 * Batch-continuation entry point.
	 *
	 * @param array $cursor Cursor saved by the previous pass.
	 */
	public function run_batch( $cursor = array() ) {
		if ( ! Config::is_enabled() ) {
			return;
		}
		$this->engine->run( is_array( $cursor ) ? $cursor : array() );
	}
}
