<?php

namespace BitApps\IntegrationsPro\Triggers\BookingCalendar;

use BitApps\IntegrationsPro\Config;

final class BookingCalendarController
{
    public static function info()
    {
        return [
            'name'              => 'Booking Calendar',
            'title'             => __('Booking Calendar', 'bit-integrations-pro'),
            'type'              => 'custom_form_submission',
            'is_active'         => static::isPluginInstalled(),
            'documentation_url' => '#',
            'tutorial_url'      => '#',
            'tasks'             => [
                'action' => 'booking-calendar/get',
                'method' => 'get',
            ],
            'fetch' => [
                'action' => 'trigger/test',
                'method' => 'post',
            ],
            'fetch_remove' => [
                'action' => 'trigger/test/remove',
                'method' => 'post',
            ],
            'isPro' => true
        ];
    }

    public function getAllTasks()
    {
        if (!static::isPluginInstalled()) {
            wp_send_json_error(\sprintf(__('%s is not installed or activated', 'bit-integrations-pro'), 'Booking Calendar'));
        }

        wp_send_json_success([
            ['form_name' => __('Booking Created', 'bit-integrations-pro'), 'triggered_entity_id' => 'wpbc_track_new_booking', 'skipPrimaryKey' => true],
            ['form_name' => __('Booking Updated', 'bit-integrations-pro'), 'triggered_entity_id' => 'wpbc_track_edit_booking', 'skipPrimaryKey' => true],
        ]);
    }

    public static function handleBookingCreated($params)
    {
        if (empty($params) || !\is_array($params)) {
            return;
        }

        return static::flowExecute('wpbc_track_new_booking', static::getTrackingPayload($params));
    }

    public static function handleBookingUpdated($params)
    {
        if (empty($params) || !\is_array($params)) {
            return;
        }

        return static::flowExecute('wpbc_track_edit_booking', static::getTrackingPayload($params));
    }

    private static function flowExecute($triggeredEntityId, $formData)
    {
        $helperClass = bit_integrations_get_class('Core\\Util\\Helper');
        $flowClass = bit_integrations_get_class('Flow\\Flow');

        $formData = $helperClass::prepareFetchFormatFields((array) $formData);
        if (empty($formData) || !\is_array($formData)) {
            return;
        }

        $helperClass::setTestData(Config::withFreePrefix("{$triggeredEntityId}_test"), array_values($formData));

        $flows = $flowClass::exists('BookingCalendar', $triggeredEntityId);
        if (empty($flows)) {
            return;
        }

        $flowClass::execute('BookingCalendar', $triggeredEntityId, array_column($formData, 'value', 'name'), $flows);

        return ['type' => 'success'];
    }

    private static function isPluginInstalled()
    {
        return \defined('WP_BK_VERSION_NUM') || \defined('WPBC_FILE') || \function_exists('wpbc_api_booking_add_new');
    }

    private static function getTrackingPayload(array $params)
    {
        $bookingId = (int) ($params['booking_id'] ?? 0);

        return [
            'booking_id'           => $bookingId,
            'resource_id'          => (int) ($params['resource_id'] ?? 0),
            'initial_resource_id'  => (int) ($params['initial_resource_id'] ?? 0),
            'dates'                => (string) ($params['str_dates__dd_mm_yyyy'] ?? ''),
            'times_array'          => $params['times_array'] ?? [],
            'form_data'            => (string) ($params['form_data'] ?? ''),
            'is_edit_booking'      => (int) ($params['is_edit_booking'] ?? 0),
            'is_duplicate_booking' => (int) ($params['is_duplicate_booking'] ?? 0),
            'is_from_admin_panel'  => (bool) ($params['is_from_admin_panel'] ?? false),
            'is_show_payment_form' => (int) ($params['is_show_payment_form'] ?? 0),
            'booking'              => static::getBookingData($bookingId),
            'occurred_at'          => current_time('mysql'),
        ];
    }

    private static function getBookingData($bookingId)
    {
        global $wpdb;

        $bookingId = (int) $bookingId;

        if ($bookingId <= 0) {
            return [];
        }

        $table = static::resolveTable('booking');

        if (empty($table)) {
            return [];
        }

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $booking = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table} WHERE booking_id = %d", $bookingId), ARRAY_A);

        if (empty($booking)) {
            return [];
        }

        $booking['booking_id'] = (int) $booking['booking_id'];
        $booking['booking_type'] = (int) $booking['booking_type'];
        $booking['is_new'] = (int) $booking['is_new'];
        $booking['trash'] = (int) $booking['trash'];
        $booking['dates'] = static::getBookingDates($bookingId);
        $booking['form_fields'] = static::parseBookingForm((string) ($booking['form'] ?? ''));
        $booking['booking_options_array'] = maybe_unserialize($booking['booking_options'] ?? '');

        return $booking;
    }

    private static function getBookingDates($bookingId)
    {
        global $wpdb;

        $table = static::resolveTable('bookingdates');

        if (empty($table)) {
            return [];
        }

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $rows = $wpdb->get_results($wpdb->prepare("SELECT * FROM {$table} WHERE booking_id = %d ORDER BY booking_date ASC", (int) $bookingId), ARRAY_A);

        if (empty($rows) || !\is_array($rows)) {
            return [];
        }

        foreach ($rows as &$row) {
            $row['booking_dates_id'] = (int) $row['booking_dates_id'];
            $row['booking_id'] = (int) $row['booking_id'];
            $row['approved'] = (int) $row['approved'];
        }

        return $rows;
    }

    private static function parseBookingForm($formData)
    {
        $fields = [];

        foreach (explode('~', (string) $formData) as $field) {
            if ($field === '') {
                continue;
            }

            $parts = explode('^', $field, 3);

            if (\count($parts) < 3) {
                continue;
            }

            $fields[] = [
                'type'  => (string) $parts[0],
                'name'  => (string) $parts[1],
                'value' => (string) $parts[2],
            ];
        }

        return $fields;
    }

    private static function resolveTable($suffix)
    {
        global $wpdb;

        $tables = [
            'booking'      => 'booking',
            'bookingdates' => 'bookingdates',
        ];

        if (!isset($tables[(string) $suffix])) {
            return;
        }

        $table = $wpdb->prefix . $tables[(string) $suffix];

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $found = $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $wpdb->esc_like($table)));

        if ($found !== $table) {
            return;
        }

        return $table;
    }
}
