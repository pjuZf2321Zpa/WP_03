<?php if (!defined('ABSPATH')) {
    die('You are not allowed to call this page directly.');
} ?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta http-equiv="Content-Type" content="<?php bloginfo('html_type'); ?>; charset=<?php echo esc_attr(get_option('blog_charset')); ?>" />
  <meta name="robots" content="noindex,nofollow" />
  <title><?php esc_html_e('MemberPress needs to upgrade your database', 'memberpress'); ?></title>
  <?php
    wp_register_style('memberpress-bootstrap-css', MEPR_CSS_URL . '/vendor/bootstrap.min.css', [], MEPR_BOOTSTRAP_VERSION);
    wp_register_style(
        'memberpress-db-upgrade',
        MEPR_CSS_URL . '/db-upgrade.css',
        ['memberpress-bootstrap-css'],
        MEPR_VERSION
    );
    wp_register_script('memberpress-bootstrap-js', MEPR_JS_URL . '/vendor/bootstrap.bundle.min.js', [], MEPR_BOOTSTRAP_VERSION, false);
    wp_register_script(
        'memberpress-db-upgrade',
        MEPR_JS_URL . '/db_upgrade.js',
        ['jquery', 'memberpress-bootstrap-js'],
        MEPR_VERSION,
        false
    );
    wp_localize_script('memberpress-db-upgrade', 'MeprDbUpgrade', [
        'ajax_url'          => admin_url('admin-ajax.php'),
        'success_url'       => MeprUtils::admin_url(
            'admin-ajax.php',
            ['db_upgrade_success', 'mepr_db_upgrade_nonce'],
            ['action' => 'mepr_db_upgrade_success']
        ),
        'not_needed_url'    => MeprUtils::admin_url(
            'admin-ajax.php',
            ['db_upgrade_not_needed', 'mepr_db_upgrade_nonce'],
            ['action' => 'mepr_db_upgrade_not_needed']
        ),
        'error_url'         => MeprUtils::admin_url(
            'admin-ajax.php',
            ['db_upgrade_error', 'mepr_db_upgrade_nonce'],
            ['action' => 'mepr_db_upgrade_error']
        ),
        'upgrade_nonce'     => wp_create_nonce('db_upgrade'),
        'in_progress_nonce' => wp_create_nonce('db_upgrade_in_progress'),
        'upgrading_text'    => __('Upgrading...', 'memberpress'),
    ]);

    wp_print_styles(['memberpress-bootstrap-css', 'memberpress-db-upgrade']);
    wp_print_scripts(['jquery', 'memberpress-bootstrap-js', 'memberpress-db-upgrade']);
    ?>
</head>
<body>
  <div class="container">
    <div class="row">&nbsp;</div>
    <div class="row">
      <div class="col-md-10 offset-md-1">
        <div class="card border-primary">
          <div class="card-header bg-primary text-white"><h2><?php esc_html_e('MemberPress needs to upgrade your database', 'memberpress'); ?></h2></div>
          <div class="card-body">
            <p>&nbsp;</p>
            <p><?php esc_html_e('Before starting the upgrade process <strong>make sure your <em>database is backed up</em></strong>.', 'memberpress'); ?></p>
            <p><?php esc_html_e('And please be patient, the upgrade process <em>may take a few minutes</em>.', 'memberpress'); ?></p>
            <p>&nbsp;</p>
            <!-- <p><a class="btn btn-primary" href="<?php
              echo esc_url(MeprUtils::admin_url(
                  'admin-ajax.php',
                  ['db_upgrade', 'mepr_db_upgrade_nonce'],
                  ['action' => 'mepr_db_upgrade']
              ));
                ?>"><?php esc_html_e('Upgrade', 'memberpress'); ?></a></p> -->
            <!-- Button trigger modal -->
            <p>
              <button type="button" class="btn btn-primary btn-lg" id="upgrade_db_trigger"><?php esc_html_e('Upgrade', 'memberpress'); ?></button>
            </p>
          </div>
        </div>
      </div>
    </div>
    <!-- Modal -->
    <div class="modal fade" id="upgrade_db" tabindex="-1" role="dialog" aria-labelledby="upgrade_db_label">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-body">
            <h2 id="upgrade_db_label"><?php esc_html_e('Your database is being upgraded', 'memberpress'); ?></h2>
            <p><?php esc_html_e('Please be patient this could take a few minutes.', 'memberpress'); ?></p>
            <p>&nbsp;</p>
            <div class="progress">
              <div class="progress-bar progress-bar-striped progress-bar-animated" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" style="width: 0%"> </div>
            </div>
            <p class="progress-bar-status"> </p>
          </div>
        </div>
      </div>
    </div>
  </div>
</body>
</html>
