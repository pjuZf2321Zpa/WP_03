<?php

use MasterStudy\Lms\Routing\Router;

/** @var Router $router */

$router->group(
	array(
		'middleware' => array(
			\MasterStudy\Lms\Routing\Middleware\Authentication::class,
		),
	),
	function ( Router $router ) {
		$router->get(
			'/notifications',
			\MasterStudy\Lms\Pro\AddonsPlus\Notifications\Http\Controllers\ListController::class
		);

		$router->post(
			'/notifications/{recipient_id}/read',
			\MasterStudy\Lms\Pro\AddonsPlus\Notifications\Http\Controllers\MarkReadController::class
		);

		$router->post(
			'/notifications/read-all',
			\MasterStudy\Lms\Pro\AddonsPlus\Notifications\Http\Controllers\MarkAllReadController::class
		);

		$router->post(
			'/notifications/push/subscribe',
			\MasterStudy\Lms\Pro\AddonsPlus\Notifications\Http\Controllers\SubscribePushController::class
		);

		$router->post(
			'/notifications/push/deactivate',
			\MasterStudy\Lms\Pro\AddonsPlus\Notifications\Http\Controllers\DeactivatePushController::class
		);
	}
);
