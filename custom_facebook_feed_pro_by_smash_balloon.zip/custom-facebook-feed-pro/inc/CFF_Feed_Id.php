<?php
/**
 * Validation for the feed ID the image-resize request records posts under (SMASH-2496).
 *
 * @package CustomFacebookFeed
 */

namespace CustomFacebookFeed;

if (! defined('ABSPATH')) {
	exit;
}

class CFF_Feed_Id
{
	/**
	 * The feed ID the front end sends is the feed's transient name, built by
	 * CFF_Settings_Pro::set_feed_type_and_terms(): a "cff_" prefix, then the page ID, locale,
	 * limits, flags and the first and last characters of any Date Range value, then an optional
	 * "_" and the pagination suffix. Those parts are free text: a relative date such as
	 * "-1 days" holds a space and a vanity page ID can be URL-encoded. So the check does not
	 * list allowed characters. It rejects the ones that matter in HTML ("<", ">", "&", quotes)
	 * and control characters, which is enough for text shown with v-text and stored with
	 * prepared queries.
	 *
	 * The name is cut to 45 characters before the suffix. The suffix is an "until" timestamp,
	 * an "after" cursor of at most 15 characters or an offset, so a real ID is under 70 bytes.
	 * The cap is 120 bytes, which leaves room for multibyte page IDs and stops an oversized
	 * suffix from the caller's next URL. "\z" ends the match at the true end of the string;
	 * "$" would also accept a trailing newline.
	 */
	public const PATTERN = '/\Acff_[^<>&"\'\x00-\x1F\x7F]{1,120}\z/';

	/**
	 * Whether a value is a feed ID this plugin could have generated.
	 *
	 * @param mixed $feed_id Value to test.
	 *
	 * @return bool
	 */
	public static function is_valid($feed_id)
	{
		return is_string($feed_id) && 1 === preg_match(self::PATTERN, $feed_id);
	}

	/**
	 * Removes feed-post rows whose feed ID fails is_valid(), so rows a request planted before
	 * SMASH-2496 do not stay in the table. Every valid row is kept.
	 *
	 * @return void
	 */
	public static function remove_invalid_feeds_posts()
	{
		global $wpdb;
		$table_name = $wpdb->prefix . CFF_FEEDS_POSTS_TABLE;

		if ($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $table_name)) !== $table_name) {
			return;
		}

		$feed_ids = $wpdb->get_col("SELECT DISTINCT feed_id FROM $table_name");
		foreach ($feed_ids as $feed_id) {
			if (! self::is_valid($feed_id)) {
				$wpdb->delete($table_name, array( 'feed_id' => $feed_id ), array( '%s' ));
			}
		}
	}
}
