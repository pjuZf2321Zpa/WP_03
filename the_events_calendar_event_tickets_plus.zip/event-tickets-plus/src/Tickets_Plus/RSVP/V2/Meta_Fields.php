<?php
/**
 * Meta Fields handler for RSVP V2.
 *
 * @since 6.11.0
 *
 * @package TEC\Tickets_Plus\RSVP\V2
 */

namespace TEC\Tickets_Plus\RSVP\V2;

use TEC\Tickets\Commerce\Ticket;
use TEC\Tickets\RSVP\V2\Constants as RSVP_Constants;
use TEC\Tickets_Plus\Waitlist\Waitlist as Waitlist_Service;
use TEC\Tickets_Plus\Waitlist\Waitlists;
use Tribe\Tickets\Plus\Attendee_Registration\IAC;
use Tribe__Tickets_Plus__Meta as Meta;
use Tribe__Utils__Array as Arr;

/**
 * Class Meta_Fields
 *
 * Handles meta field persistence, formatting, and enablement for RSVP V2.
 *
 * @since 6.11.0
 *
 * @package TEC\Tickets_Plus\RSVP\V2
 */
class Meta_Fields {
	/**
	 * Save additional RSVP fields for meta-only updates.
	 *
	 * @since 6.11.0
	 *
	 * @param int   $ticket_id      The ticket ID being updated.
	 * @param int   $post_id        The post ID.
	 * @param array $request_params The original request parameters.
	 */
	public function save_meta_only_fields( int $ticket_id, int $post_id, array $request_params ): void {
		$this->save_iac_setting( $ticket_id, $request_params );
		$this->save_meta_fields( $ticket_id, $post_id, $request_params );
	}

	/**
	 * Save RSVP-specific fields when a ticket is created or updated.
	 *
	 * Handles waitlist meta on the ticket, upserts the Waitlist service,
	 * and saves show_attendees meta on the post.
	 *
	 * @since 6.11.0
	 *
	 * @param int   $ticket_id The ticket ID.
	 * @param int   $post_id   The post ID.
	 * @param array $data      The ticket data that was used to save.
	 */
	public function save_rsvp_fields( int $ticket_id, int $post_id, array $data ): void {
		$ticket_type = $data['ticket_type'] ?? get_post_meta( $ticket_id, '_type', true );

		if ( RSVP_Constants::TC_RSVP_TYPE !== $ticket_type ) {
			return;
		}

		// A request without either key (e.g. a block editor update) leaves the waitlist as it is.
		$has_waitlist_data    = isset( $data['rsvp_waitlist_before_sale'] ) || isset( $data['rsvp_waitlist_sold_out'] );
		$waitlist_before_sale = get_post_meta( $ticket_id, '_tec_rsvp_waitlist_before_sale', true );
		$waitlist_sold_out    = get_post_meta( $ticket_id, '_tec_rsvp_waitlist_sold_out', true );

		if ( isset( $data['rsvp_waitlist_before_sale'] ) ) {
			$waitlist_before_sale = $data['rsvp_waitlist_before_sale'];
			update_post_meta( $ticket_id, '_tec_rsvp_waitlist_before_sale', $waitlist_before_sale );
		}

		if ( isset( $data['rsvp_waitlist_sold_out'] ) ) {
			$waitlist_sold_out = $data['rsvp_waitlist_sold_out'];
			update_post_meta( $ticket_id, '_tec_rsvp_waitlist_sold_out', $waitlist_sold_out );
		}

		$waitlist_enabled = ! empty( $waitlist_before_sale ) || ! empty( $waitlist_sold_out );
		if ( $has_waitlist_data && did_action( 'tec_tickets_plus_waitlist_registered' ) ) {
			$waitlists   = tribe( Waitlists::class );
			$conditional = Waitlist_Service::ALWAYS_CONDITIONAL;

			if ( ! empty( $waitlist_before_sale ) && ! empty( $waitlist_sold_out ) ) {
				$conditional = Waitlist_Service::ALWAYS_CONDITIONAL;
			} elseif ( ! empty( $waitlist_before_sale ) ) {
				$conditional = Waitlist_Service::BEFORE_SALE_CONDITIONAL;
			} elseif ( ! empty( $waitlist_sold_out ) ) {
				$conditional = Waitlist_Service::ON_SOLD_OUT_CONDITIONAL;
			}

			$waitlists->upsert_waitlist_for_post(
				$post_id,
				[
					'enabled'     => $waitlist_enabled,
					'conditional' => $conditional,
				],
				Waitlist_Service::RSVP_TYPE
			);
		}

		if ( isset( $data['rsvp_show_attendees'] ) ) {
			$show_attendees = sanitize_text_field( $data['rsvp_show_attendees'] );
			update_post_meta( $post_id, Constants::SHOW_RSVP_META_KEY, $show_attendees );
		}

		if ( isset( $data['iac'] ) ) {
			$this->save_iac_setting( $ticket_id, [ 'ticket_iac' => $data['iac'] ] );
		}
	}

	/**
	 * Cleans up ET+ RSVP meta stored on the event when an RSVP ticket is removed.
	 *
	 * @since 6.11.0
	 *
	 * @param int      $ticket_id The ticket ID being removed.
	 * @param int|null $event_id  The event ID, if already known.
	 *
	 * @return void
	 */
	public function cleanup_rsvp_fields_on_ticket_removal( int $ticket_id, ?int $event_id = null ): void {
		if ( ! $this->is_tc_rsvp_ticket( $ticket_id ) ) {
			return;
		}

		if ( ! $event_id ) {
			$event_id = (int) get_post_meta( $ticket_id, '_tec_tickets_commerce_event', true );
		}

		if ( ! $event_id ) {
			return;
		}

		delete_post_meta( $event_id, Constants::SHOW_RSVP_META_KEY );

		if ( ! did_action( 'tec_tickets_plus_waitlist_registered' ) ) {
			return;
		}

		$waitlists     = tribe( Waitlists::class );
		$rsvp_waitlist = $waitlists->get_posts_rsvp_waitlist( $event_id );

		if ( $rsvp_waitlist ) {
			$rsvp_waitlist->delete();
		}
	}

	/**
	 * Cleans up ET+ RSVP meta when a ticket is deleted through Tickets Commerce.
	 *
	 * @since 6.11.0
	 *
	 * @param int $ticket_id  The ticket ID being removed.
	 * @param int $event_id   The event ID.
	 *
	 * @return void
	 */
	public function cleanup_rsvp_fields_on_commerce_ticket_deleted( int $ticket_id, int $event_id ): void {
		$this->cleanup_rsvp_fields_on_ticket_removal( $ticket_id, $event_id );
	}

	/**
	 * Cleans up ET+ RSVP meta when an RSVP ticket post is trashed.
	 *
	 * @since 6.11.0
	 *
	 * @param int $post_id The post ID being trashed.
	 *
	 * @return void
	 */
	public function cleanup_rsvp_fields_on_ticket_trash( int $post_id ): void {
		if ( Ticket::POSTTYPE !== get_post_type( $post_id ) ) {
			return;
		}

		$this->cleanup_rsvp_fields_on_ticket_removal( $post_id );
	}

	/**
	 * Cleans up ET+ RSVP meta when an RSVP ticket post is permanently deleted.
	 *
	 * @since 6.11.0
	 *
	 * @param int $post_id The post ID being deleted.
	 *
	 * @return void
	 */
	public function cleanup_rsvp_fields_on_ticket_delete( int $post_id ): void {
		if ( Ticket::POSTTYPE !== get_post_type( $post_id ) ) {
			return;
		}

		$this->cleanup_rsvp_fields_on_ticket_removal( $post_id );
	}

	/**
	 * Checks whether a ticket post is a TC-RSVP ticket.
	 *
	 * @since 6.11.0
	 *
	 * @param int $ticket_id The ticket ID.
	 *
	 * @return bool
	 */
	private function is_tc_rsvp_ticket( int $ticket_id ): bool {
		return RSVP_Constants::TC_RSVP_TYPE === get_post_meta( $ticket_id, '_type', true );
	}

	/**
	 * Save IAC (Individual Attendee Collection) setting for a ticket.
	 *
	 * @since 6.11.0
	 *
	 * @param int   $ticket_id      The ticket ID being updated.
	 * @param array $request_params The original request parameters.
	 */
	public function save_iac_setting( int $ticket_id, array $request_params ): void {
		$ticket_iac = sanitize_text_field( Arr::get( $request_params, 'ticket_iac', '' ) );
		if ( ! in_array( $ticket_iac, [ IAC::NONE_KEY, IAC::ALLOWED_KEY, IAC::REQUIRED_KEY ], true ) ) {
			return;
		}

		/** @var IAC $iac */
		$iac             = tribe( 'tickets-plus.attendee-registration.iac' );
		$ticket_meta_key = $iac->get_iac_setting_ticket_meta_key();
		update_post_meta( $ticket_id, $ticket_meta_key, $ticket_iac );
	}

	/**
	 * Save meta fields for a ticket.
	 *
	 * @since 6.11.0
	 *
	 * @param int   $ticket_id      The ticket ID being updated.
	 * @param int   $post_id        The post ID.
	 * @param array $request_params The original request parameters.
	 */
	public function save_meta_fields( int $ticket_id, int $post_id, array $request_params ): void {
		$meta_fields = Arr::get( $request_params, 'meta_fields', [] );
		if ( ! is_array( $meta_fields ) ) {
			return;
		}

		/** @var Meta $meta */
		$meta = tribe( 'tickets-plus.meta' );

		$ticket = \Tribe__Tickets__Tickets::load_ticket_object( $ticket_id );
		if ( ! $ticket ) {
			return;
		}

		$formatted_fields = $this->format_meta_fields_for_save( $meta_fields );
		$data             = [ 'tribe-tickets-input' => $formatted_fields ];

		$meta->save_meta( $post_id, $ticket, $data );
	}

	/**
	 * Filter to ensure RSVPs have meta enabled regardless of IAC setting.
	 *
	 * @since 6.11.0
	 *
	 * @param bool $has_meta  Whether the ticket has meta enabled.
	 * @param int  $ticket_id The ticket ID.
	 *
	 * @return bool Whether the ticket has meta enabled.
	 */
	public function filter_has_meta_enabled( bool $has_meta, int $ticket_id ): bool {
		if ( $has_meta ) {
			return $has_meta;
		}

		$ticket = get_post( $ticket_id );
		if ( ! $ticket || 'tec_tc_ticket' !== $ticket->post_type ) {
			return $has_meta;
		}

		/** @var Meta $meta */
		$meta        = tribe( 'tickets-plus.meta' );
		$meta_fields = $meta->get_meta_fields_by_ticket( $ticket_id );

		if ( ! empty( $meta_fields ) ) {
			update_post_meta( $ticket_id, Meta::ENABLE_META_KEY, 'yes' );
			return true;
		}

		/** @var IAC $iac */
		$iac         = tribe( 'tickets-plus.attendee-registration.iac' );
		$iac_setting = $iac->get_iac_setting_for_ticket( $ticket_id );

		if ( IAC::NONE_KEY !== $iac_setting ) {
			return true;
		}

		return $has_meta;
	}

	/**
	 * Format meta fields array for saving.
	 *
	 * @since 6.11.0
	 *
	 * @param array $meta_fields Raw meta fields from request.
	 *
	 * @return array Formatted meta fields.
	 */
	private function format_meta_fields_for_save( array $meta_fields ): array {
		$formatted_fields = [];

		foreach ( $meta_fields as $field ) {
			$formatted_field = $this->format_single_meta_field( $field );
			if ( ! empty( $formatted_field ) ) {
				$formatted_fields[] = $formatted_field;
			}
		}

		return $formatted_fields;
	}

	/**
	 * Format a single meta field for saving.
	 *
	 * @since 6.11.0
	 *
	 * @param array $field Raw field data from request.
	 *
	 * @return array Formatted field data.
	 */
	private function format_single_meta_field( array $field ): array {
		if ( ! isset( $field['type'], $field['label'] ) ) {
			return [];
		}

		$formatted_field = [
			'type'     => $field['type'],
			'label'    => $field['label'],
			'required' => ! empty( $field['required'] ) ? 'on' : '',
		];

		// Add placeholder if provided.
		if ( isset( $field['placeholder'] ) ) {
			$formatted_field['placeholder'] = $field['placeholder'];
		}

		// Add description if provided.
		if ( isset( $field['description'] ) ) {
			$formatted_field['description'] = $field['description'];
		}

		// Add extra data (e.g., select/checkbox options) if provided.
		if ( isset( $field['extra'] ) && is_array( $field['extra'] ) ) {
			$formatted_field['extra'] = $field['extra'];
		}

		return $formatted_field;
	}
}
