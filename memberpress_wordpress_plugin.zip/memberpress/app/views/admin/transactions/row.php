<?php
if (!defined('ABSPATH')) {
    die('You are not allowed to call this page directly.');
}

if (!empty($records)) {
    $row_index = 0;
    foreach ($records as $rec) {
        $alternate = ($row_index++ % 2 ? '' : 'alternate');

        // Open the line.
        ?>
        <tr id="record_<?php echo esc_attr($rec->id); ?>" class="<?php echo esc_attr($alternate); ?>">
            <?php
            foreach ($columns as $column_name => $column_display_name) {
                // Style attributes for each col.
                $class_value = $column_name . ' column-' . $column_name;
                $is_hidden   = in_array($column_name, $hidden, true);

                $editlink = admin_url('user-edit.php?user_id=' . (int) $rec->user_id);

                // Display the cell.
                switch ($column_name) {
                    case 'col_id':
                        ?>
                        <td class="<?php echo esc_attr($class_value); ?>"<?php echo $is_hidden ? ' style="display:none;"' : ''; ?>><?php echo esc_html($rec->id); ?></td>
                        <?php
                        break;
                    case 'col_created_at':
                        ?>
                        <td class="<?php echo esc_attr($class_value); ?>"<?php echo $is_hidden ? ' style="display:none;"' : ''; ?>><?php echo esc_html(MeprAppHelper::format_date($rec->created_at)); ?></td>
                        <?php
                        break;
                    case 'col_expires_at':
                        ?>
                        <td class="<?php echo esc_attr($class_value); ?>"<?php echo $is_hidden ? ' style="display:none;"' : ''; ?>>
                            <?php echo esc_html(MeprAppHelper::format_date($rec->expires_at, __('Never', 'memberpress'))); ?>
                        </td>
                        <?php
                        break;
                    case 'col_user_login':
                        ?>
                        <td class="<?php echo esc_attr($class_value); ?>"<?php echo $is_hidden ? ' style="display:none;"' : ''; ?>>
                            <?php if (!empty($rec->user_id)) : ?>
                                <a href="<?php echo esc_url($editlink); ?>"
                                    title="<?php esc_attr_e('View member\'s profile', 'memberpress'); ?>"><?php echo esc_html($rec->user_login); ?></a>
                            <?php else : ?>
                                <?php esc_html_e('Deleted', 'memberpress'); ?>
                            <?php endif; ?>
                        </td>
                        <?php
                        break;
                    case 'col_product':
                        ?>
                        <td class="<?php echo esc_attr($class_value); ?>"<?php echo $is_hidden ? ' style="display:none;"' : ''; ?>>
                            <?php
                            if ($rec->product_id) {
                                $prd = new MeprProduct($rec->product_id);
                                echo '<a href="' . esc_url($prd->edit_url()) . '">' . esc_html($rec->product_name) . '</a>';

                                // Cart shows one transaction per line item, so surface the line quantity
                                // here (amount already reflects unit x qty). A cart-flow txn is historical
                                // fact — show its qty regardless of whether the cart is currently enabled.
                                // Detect via the selected flow_type column so non-cart rows never hydrate a
                                // transaction — only true cart lines pay that cost.
                                if (
                                    isset($rec->flow_type)
                                    && $rec->flow_type === MeprTransaction::$flow_type_cart_str
                                ) {
                                    $line_qty = (int) (new MeprTransaction($rec->id))->cart_line_pricing()['qty'];
                                    if ($line_qty > 1) {
                                        $qty_title = sprintf(
                                            // Translators: %d: quantity purchased.
                                            __('Quantity: %d', 'memberpress'),
                                            $line_qty
                                        );
                                        printf(
                                            ' <span class="mepr-txn-qty-badge" title="%s">&times;%d</span>',
                                            esc_attr($qty_title),
                                            (int) $line_qty
                                        );
                                    }
                                }
                            } else {
                                esc_html_e('Unknown', 'memberpress');
                            }
                            ?>
                        </td>
                        <?php
                        break;
                    case 'col_payment_system':
                        ?>
                        <td class="<?php echo esc_attr($class_value); ?>"<?php echo $is_hidden ? ' style="display:none;"' : ''; ?>><?php
                            $pm = MeprOptions::fetch()->payment_method($rec->gateway);
                        if ($pm instanceof MeprBaseGateway) {
                            echo esc_html($pm->label ?: ucwords(str_replace('_', ' ', $pm->name)));
                        } else {
                            echo esc_html($rec->gateway);
                        }
                        ?></td>
                        <?php
                        break;
                    case 'col_trans_num':
                        ?>
                        <td class="<?php echo esc_attr($class_value); ?>"<?php echo $is_hidden ? ' style="display:none;"' : ''; ?>>
                            <a href="<?php echo esc_url(admin_url('admin.php?page=memberpress-trans&action=edit&id=' . $rec->id)); ?>"
                                title="<?php esc_attr_e('Edit transaction', 'memberpress'); ?>" <?php echo MeprTransactionsHelper::get_tooltip_attributes($rec); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>><b><?php echo esc_html($rec->trans_num); ?></b></a> <img
                                src="<?php echo esc_url(MEPR_IMAGES_URL . '/square-loader.gif'); ?>" alt="<?php esc_attr_e('Loading...', 'memberpress'); ?>"
                                class="mepr_loader" />
                            <div class="mepr-row-actions">
                                <?php echo MeprUtils::render_row_action_links(MeprTransactionsHelper::get_admin_action_links($rec)); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
                            </div>
                            <?php
                            // Show parent cart order link in row actions.
                            $_row_order_id = (int) ($rec->order_id ?? 0);
                            if ($_row_order_id > 0) :
                                $_row_order = MeprOrder::get_one($_row_order_id);
                                if ($_row_order && ($_row_order->order_type ?? '') === MeprOrder::$cart_type_str) :
                                    ?>
                            <div class="mepr-row-actions">
                                <span class="mepr-order-link">
                                    <a href="<?php echo esc_url(admin_url('admin.php?page=memberpress-orders&action=detail&id=' . $_row_order_id)); ?>">
                                        <?php
                                        // Translators: %s: order number.
                                        printf(esc_html__('Order %s', 'memberpress'), esc_html($_row_order->trans_num));
                                        ?>
                                    </a>
                                </span>
                            </div>
                                <?php endif;
                            endif; ?>
                        </td>
                        <?php
                        break;
                    case 'col_subscr_id':
                        ?>
                        <td class="<?php echo esc_attr($class_value); ?>"<?php echo $is_hidden ? ' style="display:none;"' : ''; ?>>
                            <?php
                            if (!empty($rec->sub_id)) :
                                ?>
                                <a href="<?php echo esc_url(admin_url('admin.php?page=memberpress-subscriptions&subscription=' . $rec->sub_id)); ?>"
                                    title="<?php esc_attr_e('View Subscription', 'memberpress'); ?>"><?php echo esc_html($rec->subscr_id); ?></a>
                                <?php
                            else :
                                esc_html_e('None', 'memberpress');
                            endif;
                            ?>
                        </td><?php
                        break;
                    case 'col_net':
                        $txn_currency_net = !empty($rec->currency) ? $rec->currency : MeprOptions::fetch()->currency_code;
                        $primary_code_net = MeprOptions::fetch()->currency_code;
                        ?>
                        <td class="<?php echo esc_attr($class_value); ?>"<?php echo $is_hidden ? ' style="display:none;"' : ''; ?>>
                            <span class="mepr-txn-currency">
                                <span class="mepr-txn-currency__amount"><?php echo esc_html(MeprAppHelper::format_currency($rec->amount, true, false, false, $txn_currency_net)); ?></span>
                                <?php if ($txn_currency_net !== $primary_code_net) : ?>
                                    <span class="mepr-txn-currency__code"><?php echo esc_html($txn_currency_net); ?></span>
                                <?php endif; ?>
                            </span>
                        </td>
                        <?php
                        break;
                    case 'col_tax':
                        $txn_currency_tax = !empty($rec->currency) ? $rec->currency : MeprOptions::fetch()->currency_code;
                        $primary_code_tax = MeprOptions::fetch()->currency_code;
                        ?>
                        <td class="<?php echo esc_attr($class_value); ?>"<?php echo $is_hidden ? ' style="display:none;"' : ''; ?>>
                            <span class="mepr-txn-currency">
                                <span class="mepr-txn-currency__amount"><?php echo esc_html(MeprAppHelper::format_currency($rec->tax_amount, true, false, false, $txn_currency_tax)); ?></span>
                                <?php if ($txn_currency_tax !== $primary_code_tax) : ?>
                                    <span class="mepr-txn-currency__code"><?php echo esc_html($txn_currency_tax); ?></span>
                                <?php endif; ?>
                            </span>
                        </td>
                        <?php
                        break;
                    case 'col_total':
                        $txn_currency_total = !empty($rec->currency) ? $rec->currency : MeprOptions::fetch()->currency_code;
                        $primary_code_total = MeprOptions::fetch()->currency_code;
                        $total_display      = ((float) $rec->total === 0.00 && (float) $rec->amount > 0.00) ? $rec->amount : $rec->total;
                        ?>
                        <td class="<?php echo esc_attr($class_value); ?>"<?php echo $is_hidden ? ' style="display:none;"' : ''; ?>>
                            <span class="mepr-txn-currency">
                                <span class="mepr-txn-currency__amount"><?php echo esc_html(MeprAppHelper::format_currency($total_display, true, false, false, $txn_currency_total)); ?></span>
                                <?php if ($txn_currency_total !== $primary_code_total) : ?>
                                    <span class="mepr-txn-currency__code"><?php echo esc_html($txn_currency_total); ?></span>
                                <?php endif; ?>
                            </span>
                        </td>
                        <?php
                        break;
                    case 'col_status':
                        $is_cart_txn       = isset($rec->flow_type)
                            && $rec->flow_type === MeprTransaction::$flow_type_cart_str;
                        $_status_order_id  = (int) ($rec->order_id ?? 0);
                        $_status_order_url = $_status_order_id > 0
                            ? admin_url('admin.php?page=memberpress-orders&action=detail&id=' . $_status_order_id)
                            : '';
                        $status_html       = MeprHooks::apply_filters(
                            'mepr_admin_transactions_list_table_status_html',
                            sprintf(
                                '<a href="" title="%s">%s</a>',
                                esc_attr__('Change transaction\'s status', 'memberpress'),
                                esc_html(MeprAppHelper::human_readable_status($rec->status))
                            ),
                            $rec
                        ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
                        ?>
                        <td class="<?php echo esc_attr($class_value); ?>"<?php echo $is_hidden ? ' style="display:none;"' : ''; ?>>
                            <div class="status_initial mepr_status_<?php echo esc_attr($rec->status); ?> status_initial_<?php echo esc_attr($rec->id); ?>" data-value="<?php echo esc_attr($rec->id); ?>">
                                <?php echo $status_html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
                            </div>
                            <div class="status_editable status_editable_<?php echo esc_attr($rec->id); ?>">
                                <?php
                                if ($is_cart_txn) {
                                    MeprAppHelper::info_tooltip(
                                        'mepr-transactions-status-cart-' . $rec->id,
                                        __('Editing Cart Transaction Status', 'memberpress'),
                                        __('Pending, Failed, and Complete only update the status on your site. Saving Refunded processes a real refund for this cart order line item at the payment gateway and updates the cart order. To cancel a subscription, use Subscriptions or Cancel on the cart order — not this dropdown.', 'memberpress')
                                    );
                                } else {
                                    MeprAppHelper::info_tooltip(
                                        'mepr-transactions-status-' . $rec->id,
                                        __('Editing Transaction Status', 'memberpress'),
                                        __("Changing the status here will ONLY change the status on your site, not at the Gateway itself. To cancel a Transaction either you or the member should click the Cancel link next to the Subscription. You must use your Payment Gateway's web interface to refund a transaction.", 'memberpress')
                                    );
                                }
                                ?>
                                <select class="status_edit status_edit_<?php echo esc_attr($rec->id); ?>" data-value="<?php echo esc_attr($rec->id); ?>"<?php
                                if ($is_cart_txn) :
                                    // Remaining is read by JS to skip the gateway-refund confirm when already settled by amount meta.
                                    ?> data-cart-txn="1" data-refundable-remaining="<?php echo esc_attr((new MeprTransaction($rec->id))->get_refundable_remaining()); ?>"<?php
                                endif;
                                ?>>
                                    <option value="pending" <?php echo (stripslashes($rec->status) === 'pending') ? 'selected="selected"' : ''; ?>><?php esc_html_e('Pending', 'memberpress'); ?></option>
                                    <option value="failed" <?php echo (stripslashes($rec->status) === 'failed') ? 'selected="selected"' : ''; ?>><?php esc_html_e('Failed', 'memberpress'); ?></option>
                                    <option value="refunded" <?php echo (stripslashes($rec->status) === 'refunded') ? 'selected="selected"' : ''; ?>><?php esc_html_e('Refunded', 'memberpress'); ?></option>
                                    <option value="complete" <?php echo (stripslashes($rec->status) === 'complete') ? 'selected="selected"' : ''; ?>><?php esc_html_e('Complete', 'memberpress'); ?></option>
                                </select><br />
                                <a href="" class="button status_save"
                                    data-value="<?php echo esc_attr($rec->id); ?>"><?php esc_html_e('Save', 'memberpress'); ?></a>
                                <a href="" class="button cancel_change"
                                    data-value="<?php echo esc_attr($rec->id); ?>"><?php esc_html_e('Cancel', 'memberpress'); ?></a>
                            </div>
                            <div class="status_saving status_saving_<?php echo esc_attr($rec->id); ?>">
                                <?php esc_html_e('Saving ...', 'memberpress'); ?>
                            </div>
                            <?php if ($is_cart_txn && $_status_order_url !== '') : ?>
                                <div class="mepr-cart-txn-view-order">
                                    <a href="<?php echo esc_url($_status_order_url); ?>">
                                        <?php esc_html_e('View order', 'memberpress'); ?>
                                    </a>
                                </div>
                            <?php endif; ?>
                        </td>
                        <?php
                        break;
                    case 'col_propername':
                        if (empty($rec->first_name) && empty($rec->last_name)) {
                            $full_name = __('Unknown', 'memberpress');
                        } elseif (empty($rec->first_name) && !empty($rec->last_name)) {
                            $full_name = stripslashes($rec->last_name);
                        } elseif (!empty($rec->first_name) && empty($rec->last_name)) {
                            $full_name = stripslashes($rec->first_name);
                        } else {
                            $full_name = stripslashes($rec->last_name) . ', ' . stripslashes($rec->first_name);
                        }
                        ?>
                        <td class="<?php echo esc_attr($class_value); ?>"<?php echo $is_hidden ? ' style="display:none;"' : ''; ?>>
                            <?php echo esc_html($full_name); ?>
                        </td>
                        <?php
                        break;
                    default:
                        $attributes = 'class="' . esc_attr($class_value) . '"' . ($is_hidden ? ' style="display:none;"' : '');
                        MeprHooks::do_action('mepr_admin_transactions_cell', $column_name, $rec, $attributes);
                        break;
                }
            }
            ?>
        </tr>
        <?php
    }
}
