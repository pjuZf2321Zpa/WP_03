<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Actions\MailPoet\MailPoetProHelper;
use BitApps\IntegrationsPro\Config;
use BitApps\IntegrationsPro\Core\Util\Hooks;

// Deprecated since v2.7.8 - use bit_integrations_mailpoet_* hooks instead
if (bit_integrations_version_below('2.7.8')) {
    Hooks::filter('btcbi_mailpoet_update_subscriber', [MailPoetProHelper::class, 'updateRecord'], 10, 2);
}

// New hooks since v2.7.8
Hooks::filter(Config::withFreePrefix('mailpoet_update_subscriber'), [MailPoetProHelper::class, 'updateRecord'], 10, 2);
