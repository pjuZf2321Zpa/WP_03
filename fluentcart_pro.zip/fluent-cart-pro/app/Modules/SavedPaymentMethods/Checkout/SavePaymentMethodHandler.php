<?php

namespace FluentCartPro\App\Modules\SavedPaymentMethods\Checkout;

use FluentCart\App\Helpers\Status;
use FluentCart\App\Modules\PaymentMethods\StripeGateway\API\API;
use FluentCart\App\Modules\PaymentMethods\StripeGateway\Confirmations;
use FluentCart\Framework\Support\Arr;
use FluentCartPro\App\Modules\SavedPaymentMethods\PayPal\PayPalSavedMethodWriter;

/**
 * Persistence half of "save card at checkout". The card is vaulted at charge
 * time by setup_future_usage (CheckoutSaveHandler sets it on both the client
 * Elements and the real intent), so here we only reconcile against the buyer's
 * choice on a paid order:
 *  - opted in  -> record the (already attached) card via core's writer
 *    (Confirmations::savePaymentMethodToCustomerMeta — allow_redisplay +
 *    fingerprint dedupe + write to the `saved_payment_method` customer meta);
 *  - opted out but vaulted -> detach the PM to honor the opt-out.
 *
 * Idempotent: order_paid can fire more than once (webhook + status transitions).
 * A per-order guard short-circuits repeats, and the core writer dedupes by card
 * fingerprint as a second line of defense.
 */
class SavePaymentMethodHandler
{
    const STORED_GUARD_META = '_fct_saved_payment_method_stored';

    // A failed PayPal persist is retried on later order_paid firings, but only
    // this many times — order_paid can refire indefinitely (webhook + status
    // transitions) and each retry costs a PayPal API round trip.
    const PAYPAL_ATTEMPTS_META = '_fct_spm_paypal_attempts';
    const MAX_PAYPAL_ATTEMPTS = 3;

    public function register(): void
    {
        add_action('fluent_cart/order_paid', [$this, 'maybeSaveCard'], 20, 1);
        add_action('fluent_cart/renewal_paid', [$this, 'maybeSaveRenewalCard'], 20, 1);
    }

    public function maybeSaveRenewalCard( $data ): void
    {
        $order = Arr::get( $data, 'order' );
        if ( ! $order || $order->payment_status !== Status::PAYMENT_PAID ) {
            return;
        }

        // Renewal events carry only the order; use its successful charge, never a refund.
        $transaction = $order->transactions()
            ->where( 'transaction_type', Status::TRANSACTION_TYPE_CHARGE )
            ->where( 'status', Status::TRANSACTION_SUCCEEDED )
            ->orderBy( 'id', 'DESC' )
            ->first();

        $this->maybeSaveCard( [
            'order' => $order,
            'transaction' => $transaction,
        ] );
    }

    /**
     * @param array $data ['order'=>Order, 'customer'=>Customer, 'transaction'=>OrderTransaction]
     */
    public function maybeSaveCard($data)
    {
        try {
            $order = Arr::get($data, 'order');
            $transaction = Arr::get($data, 'transaction');
            if (!$order || !$transaction) {
                return;
            }

            // Store/clean up once per order (order_paid can fire more than once).
            if ($order->getMeta(self::STORED_GUARD_META) === 'yes') {
                return;
            }

            // PayPal persists through its own writer: the token is vaulted by
            // PayPal during the purchase, so there is no opt-out cleanup to do and
            // none of the Stripe customer/PaymentIntent plumbing below applies.
            if ($order->payment_method === 'paypal') {
                $this->savePayPalAccount($order, $transaction);
                return;
            }

            if ($order->payment_method !== 'stripe') {
                return;
            }

            $optedIn    = $order->getMeta(CheckoutSaveHandler::ORDER_FLAG_META) === 'yes';
            $sfuApplied = $order->getMeta(CheckoutSaveHandler::SFU_APPLIED_META) === 'yes';

            // Nothing to do unless the buyer opted in, or we vaulted a card
            // (setup_future_usage) that now needs cleaning up because they opted out.
            if (!$optedIn && !$sfuApplied) {
                return;
            }

            $customer = $order->customer;
            if (!$customer) {
                return;
            }

            $vendorCustomer = $customer->getMeta('stripe_customer_id');
            $paymentIntentId = $transaction->vendor_charge_id;
            if (!$vendorCustomer || !$paymentIntentId) {
                return;
            }

            $paymentMethodId = $this->resolvePaymentMethodId($paymentIntentId);
            if (!$paymentMethodId) {
                return;
            }

            if ($optedIn) {
                // setup_future_usage already attached the PM to the customer; the
                // writer lists it and records it in the customer's saved_payment_method meta.
                (new Confirmations())->savePaymentMethodToCustomerMeta($vendorCustomer, $paymentMethodId, $order);
            } else {
                // Safety net only: consent now gates setup_future_usage itself, so a
                // card should never be vaulted without an opt-in. This still fires for
                // an order stamped by an older build, where the flag was applied before
                // consent gated it. A failed detach leaves a card vaulted without
                // consent, so it must be logged rather than assumed to have worked.
                $detached = (new API())->createStripeObject('payment_methods/' . $paymentMethodId . '/detach', []);

                if (is_wp_error($detached)) {
                    fluent_cart_error_log(
                        'Saved payment method detach failed',
                        sprintf(
                            'Payment method %1$s stayed attached for order %2$d after an opt-out: %3$s',
                            $paymentMethodId,
                            (int) $order->id,
                            $detached->get_error_message()
                        )
                    );

                    // Leave the guard unset so a later order_paid can retry the detach.
                    return;
                }
            }

            $order->updateMeta(self::STORED_GUARD_META, 'yes');
        } catch (\Throwable $e) {
            fluent_cart_error_log('Saved payment method persist error', $e->getMessage());
        }
    }

    /**
     * PayPal half: record the account PayPal vaulted during this purchase.
     *
     * Only runs on explicit consent. Unlike Stripe there is no opt-out branch —
     * without consent the vault attribute is never sent (the
     * fluent_cart/payments/paypal_vault_one_time filter returns false), so PayPal
     * has nothing to detach afterwards.
     */
    private function savePayPalAccount($order, $transaction): void
    {
        if ($order->getMeta(CheckoutSaveHandler::ORDER_FLAG_META) !== 'yes') {
            return;
        }

        $customer = $order->customer;
        if (!$customer) {
            return;
        }

        $attempts = (int) $order->getMeta(self::PAYPAL_ATTEMPTS_META);
        if ($attempts >= self::MAX_PAYPAL_ATTEMPTS) {
            return;
        }
        $order->updateMeta(self::PAYPAL_ATTEMPTS_META, $attempts + 1);

        if ((new PayPalSavedMethodWriter())->persist($customer, $transaction)) {
            $order->updateMeta(self::STORED_GUARD_META, 'yes');
        }
    }

    /**
     * Read the payment method (pm_) off the succeeded PaymentIntent, falling
     * back to the latest charge if the top-level field is cleared.
     */
    private function resolvePaymentMethodId($paymentIntentId)
    {
        $intent = (new API())->getStripeObject('payment_intents/' . $paymentIntentId);
        if (is_wp_error($intent)) {
            return null;
        }

        $paymentMethodId = Arr::get($intent, 'payment_method');
        if ($paymentMethodId) {
            return $paymentMethodId;
        }

        $charge = (new API())->getStripeObject('payment_intents/' . $paymentIntentId . '?expand[]=latest_charge');
        if (is_wp_error($charge)) {
            return null;
        }

        return Arr::get($charge, 'latest_charge.payment_method');
    }
}
