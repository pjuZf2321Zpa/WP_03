<?php

namespace MasterStudy\Lms\Pro\AddonsPlus\Notifications\Services;

final class CronManager {
	private const ADDONS_OPTION     = 'stm_lms_addons';
	private const ADDON_NAME        = 'notifications';
	private const LAST_CHECK_OPTION = 'masterstudy_notifications_cron_last_check';
	private const CHECK_INTERVAL    = HOUR_IN_SECONDS;

	private const HOOKS = array(
		'masterstudy_notifications_process_recipient_fanout',
		'masterstudy_notifications_process_push_queue',
		'masterstudy_notifications_recover_queues',
		'masterstudy_notifications_course_access_expiration_sweep',
		'masterstudy_notifications_cleanup',
		'masterstudy_notifications_cleanup_continue',
		'masterstudy_notifications_scheduled_event',
		'masterstudy_notifications_scheduled_target_event',
	);

	public static function register(): void {
		add_action( 'update_option_' . self::ADDONS_OPTION, array( self::class, 'addons_updated' ), 10, 2 );
		add_action( 'add_option_' . self::ADDONS_OPTION, array( self::class, 'addons_added' ), 10, 2 );
		add_action( 'admin_init', array( self::class, 'maybe_self_heal' ), 20 );
	}

	public static function activate(): void {
		delete_option( self::LAST_CHECK_OPTION );

		if ( function_exists( 'masterstudy_lms_is_notifications_addon_available' ) ) {
			self::sync();
		}
	}

	public static function deactivate(): void {
		self::unschedule();
		delete_option( self::LAST_CHECK_OPTION );
	}

	public static function addons_updated( $_old_value, $value ): void {
		self::sync( is_array( $value ) ? $value : array() );
	}

	public static function addons_added( string $_option, $value ): void {
		self::sync( is_array( $value ) ? $value : array() );
	}

	public static function maybe_self_heal(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		$last_check = (int) get_option( self::LAST_CHECK_OPTION, 0 );

		if ( time() - $last_check < self::CHECK_INTERVAL ) {
			return;
		}

		self::sync();
	}

	private static function sync( ?array $addons = null ): void {
		$addons = $addons ?? get_option( self::ADDONS_OPTION, array() );

		if (
			! empty( $addons[ self::ADDON_NAME ] )
			&& function_exists( 'masterstudy_lms_is_notifications_addon_available' )
			&& masterstudy_lms_is_notifications_addon_available()
		) {
			QueueRecovery::ensure_scheduled();
			CourseAccessExpirationSweep::ensure_scheduled();
			Cleanup::ensure_scheduled();
		} else {
			self::unschedule();
		}

		update_option( self::LAST_CHECK_OPTION, time(), false );
	}

	private static function unschedule(): void {
		foreach ( self::HOOKS as $hook ) {
			wp_clear_scheduled_hook( $hook );
		}
	}
}
