<?php

namespace WPAICG\Lib\Chat\Triggers\Actions;

use WP_Error;

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- This file intentionally uses core WordPress hook names.

/**
 * AIPKit_Action_Call_Webhook
 *
 * Handles the 'call_webhook' trigger action.
 */
class AIPKit_Action_Call_Webhook {
    private const EXACT_PLACEHOLDER_REGEX = '/^\{\{[^{}\s]+\}\}$/';

    /**
     * Check whether request body should be treated as JSON.
     *
     * @param array $headers
     * @param string $content_type_key
     * @return bool
     */
    private function is_json_content_type(array $headers, string $content_type_key): bool {
        return isset($headers[$content_type_key]) && stripos((string) $headers[$content_type_key], 'application/json') !== false;
    }

    /**
     * Resolve placeholders in JSON body template safely.
     *
     * For valid JSON templates, placeholders are resolved per-value and the payload is
     * re-encoded to prevent malformed JSON when values include quotes/newlines.
     * If the template is not valid JSON before replacement, fallback to the legacy raw
     * replacement flow for backward compatibility.
     *
     * @param string $body_template
     * @param array $context_data
     * @param callable $process_placeholders
     * @return string|WP_Error
     */
    private function process_json_body_template(string $body_template, array $context_data, callable $process_placeholders) {
        $decoded_template = json_decode($body_template, true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            // Backward-compatible path for legacy templates that rely on raw replacement first.
            $legacy_processed_body = (string) call_user_func($process_placeholders, $body_template, $context_data, 'raw');
            json_decode($legacy_processed_body);
            if (json_last_error() !== JSON_ERROR_NONE) {
                return new WP_Error('invalid_webhook_body_json', __('Webhook body template is not valid JSON after processing placeholders.', 'gpt3-ai-content-generator'));
            }

            return $legacy_processed_body;
        }

        $resolved_template = $this->resolve_json_template_values($decoded_template, $context_data, $process_placeholders);
        $encoded_body = wp_json_encode($resolved_template, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        if (!is_string($encoded_body)) {
            return new WP_Error('invalid_webhook_body_json', __('Webhook body template could not be encoded as JSON after placeholder processing.', 'gpt3-ai-content-generator'));
        }

        return $encoded_body;
    }

    /**
     * Recursively resolve placeholders in decoded JSON template values.
     *
     * @param mixed $value
     * @param array $context_data
     * @param callable $process_placeholders
     * @return mixed
     */
    private function resolve_json_template_values($value, array $context_data, callable $process_placeholders) {
        if (is_array($value)) {
            $resolved = [];
            foreach ($value as $key => $item) {
                $resolved[$key] = $this->resolve_json_template_values($item, $context_data, $process_placeholders);
            }
            return $resolved;
        }

        if (!is_string($value)) {
            return $value;
        }

        if (preg_match(self::EXACT_PLACEHOLDER_REGEX, $value) === 1 && class_exists(AIPKit_Placeholder_Processor::class) && method_exists(AIPKit_Placeholder_Processor::class, 'resolve_placeholder_value')) {
            $resolved_value = AIPKit_Placeholder_Processor::resolve_placeholder_value($value, $context_data);
            if ($resolved_value !== null) {
                return $resolved_value;
            }
        }

        return (string) call_user_func($process_placeholders, $value, $context_data, 'raw');
    }

    /**
     * Executes the 'call_webhook' action.
     *
     * @param array $payload Payload for the webhook.
     * @param array $context_data Contextual data for placeholders.
     * @param int   $bot_id Bot ID.
     * @return array|WP_Error Action result or WP_Error.
     */
    public function execute(array $payload, array $context_data, int $bot_id) {
        $endpoint_url_template = $payload['endpoint_url'] ?? null;
        $http_method = strtoupper($payload['http_method'] ?? 'POST');
        $headers_template = $payload['headers'] ?? [];
        $body_template = $payload['body_template'] ?? null;
        $timeout_seconds = isset($payload['timeout_seconds']) ? absint($payload['timeout_seconds']) : 10;
        $timeout_seconds = max(1, min($timeout_seconds, 30));

        if (empty($endpoint_url_template)) {
            return new WP_Error('missing_webhook_endpoint', __('Webhook endpoint URL is required.', 'gpt3-ai-content-generator'));
        }
        if (!in_array($http_method, ['GET', 'POST', 'PUT', 'DELETE'], true)) {
            return new WP_Error('invalid_webhook_method', __('Invalid HTTP method for webhook.', 'gpt3-ai-content-generator'));
        }

        // Ensure PlaceholderProcessor class exists
        if (!class_exists(\WPAICG\Lib\Chat\Triggers\Actions\AIPKit_Placeholder_Processor::class)) {
             $process_placeholders = function ($str, $ctx = null, $mode = 'display') { return $str; }; // No-op
        } else {
            $process_placeholders = [\WPAICG\Lib\Chat\Triggers\Actions\AIPKit_Placeholder_Processor::class, 'process'];
        }


        $endpoint_url = esc_url_raw(trim(call_user_func($process_placeholders, $endpoint_url_template, $context_data, 'raw')));
        if (empty($endpoint_url) || !wp_http_validate_url($endpoint_url)) {
             return new WP_Error('invalid_webhook_url', __('Invalid or unsafe webhook URL after processing placeholders.', 'gpt3-ai-content-generator'));
        }

        $processed_headers = [];
        if (is_array($headers_template)) {
            foreach ($headers_template as $key => $value_template) {
                $processed_headers[sanitize_key($key)] = call_user_func($process_placeholders, (string)$value_template, $context_data, 'raw');
            }
        }
        $content_type_key = 'content-type';
        if (!isset($processed_headers[$content_type_key]) && in_array($http_method, ['POST', 'PUT'], true)) {
             $processed_headers[$content_type_key] = 'application/json; charset=utf-8';
        }

        $request_body = null;
        if (in_array($http_method, ['POST', 'PUT']) && !empty($body_template)) {
            if ($this->is_json_content_type($processed_headers, $content_type_key)) {
                $request_body_string = $this->process_json_body_template((string) $body_template, $context_data, $process_placeholders);
                if (is_wp_error($request_body_string)) {
                    return $request_body_string;
                }
            } else {
                $request_body_string = (string) call_user_func($process_placeholders, (string) $body_template, $context_data, 'raw');
            }

            $request_body = $request_body_string;
        }

        $args = [
            'method'    => $http_method,
            'headers'   => $processed_headers,
            'timeout'   => $timeout_seconds,
            'sslverify' => apply_filters('https_local_ssl_verify', true),
        ];
        if ($request_body !== null) {
            $args['body'] = $request_body;
        }

        $response = wp_remote_request($endpoint_url, $args);

        if (is_wp_error($response)) {
            return new WP_Error('webhook_request_failed', __('Webhook request failed: ', 'gpt3-ai-content-generator') . $response->get_error_message());
        }

        $response_code = wp_remote_retrieve_response_code($response);
        $response_body_content = wp_remote_retrieve_body($response);


        $result = [
            'type' => 'webhook_sent',
            'status' => $response_code >= 400 ? 'failed' : 'success',
            'http_code' => $response_code,
        ];
        if ($response_code >= 400) {
            /* translators: %d is the HTTP status code */
            $result['message'] = sprintf(__('Webhook call failed with HTTP status %d.', 'gpt3-ai-content-generator'), $response_code);
        }
        $result['response_body_snippet'] = substr($response_body_content, 0, 200);

        return $result;
    }
}
