<?php // phpcs:ignore WordPress.Files.FileName.InvalidClassFileName
/**
 * LoginPress math captcha.
 *
 * @since 6.2.0
 * @package LoginPress
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'LoginPress_Math_Captcha' ) ) {
	/**
	 * LoginPress_Math_Captcha
	 *
	 * @since 6.2.0
	 */
	class LoginPress_Math_Captcha {

		/**
		 *  Captcha settings.
		 *
		 * @var string
		 * @since 6.2.0
		 */
		public $loginpress_captcha_settings;

		/**
		 * Constructor.
		 *
		 * @param array $captcha The captcha settings.
		 * @since 6.2.0
		 */
		public function __construct( $captcha ) {
			$this->loginpress_captcha_settings = $captcha;
			$this->hooks();
		}

		/**
		 * Hooks.
		 *
		 * @since 6.2.0
		 */
		public function hooks() {

			$captchas_enabled = isset( $this->loginpress_captcha_settings['enable_captchas'] ) ? $this->loginpress_captcha_settings['enable_captchas'] : 'off';

			if ( 'off' !== $captchas_enabled ) {
				$captchas_type = isset( $this->loginpress_captcha_settings['captchas_type'] ) ? $this->loginpress_captcha_settings['captchas_type'] : 'type_recaptcha';
				if ( 'type_math' === $captchas_type ) {
					add_action( 'init', array( $this, 'loginpress_start_session' ) );
					$math_login   = isset( $this->loginpress_captcha_settings['math_captcha_enable']['login_form'] ) ? $this->loginpress_captcha_settings['math_captcha_enable']['login_form'] : 'off';
					$math_lost    = isset( $this->loginpress_captcha_settings['math_captcha_enable']['lostpassword_form'] ) ? $this->loginpress_captcha_settings['math_captcha_enable']['lostpassword_form'] : 'off';
					$math_reg     = isset( $this->loginpress_captcha_settings['math_captcha_enable']['register_form'] ) ? $this->loginpress_captcha_settings['math_captcha_enable']['register_form'] : 'off';
					$math_comment = isset( $this->loginpress_captcha_settings['math_captcha_enable']['comment_form_defaults'] ) ? $this->loginpress_captcha_settings['math_captcha_enable']['comment_form_defaults'] : false;

					// WooCommerce math captcha hooks are registered in LoginPress_Woocommerce_Integration.

					// Adding Math Captcha to the login form.
					if ( 'off' !== $math_login ) {
						add_action( 'login_form', array( $this, 'loginpress_math_captcha_field' ) );
						// For Widget.
						add_action( 'loginpress_after_login_form_widget', array( $this, 'loginpress_math_captcha_field' ) );
					}

					if ( ! isset( $_GET['customize_changeset_uuid'] ) && 'off' !== $math_login && ! isset( $_POST['woocommerce-login-nonce'] ) ) { // @codingStandardsIgnoreLine.
						add_filter( 'authenticate', array( $this, 'loginpress_validate_math_captcha' ), 300, 3 );
					}
					// Adding Math Captcha to the register form.
					if ( 'off' !== $math_reg ) {
						add_action( 'register_form', array( $this, 'loginpress_math_captcha_field' ) );
						// For Widget.
						add_action( 'loginpress_after_reg_form_widget', array( $this, 'loginpress_math_captcha_field' ) );
					}

					// Authentication reCAPTCHA on registration form.
					if ( 'off' !== $math_reg && isset( $_GET['action'] ) && 'register' === $_GET['action'] ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
						add_filter( 'registration_errors', array( __CLASS__, 'loginpress_math_registration_auth' ), 10, 3 );
					}

					// Adding Math Captcha to the lost password form.
					if ( 'off' !== $math_lost ) {
						add_action( 'lostpassword_form', array( $this, 'loginpress_math_captcha_field' ) );
						add_action( 'loginpress_after_lost_password_form_widget', array( $this, 'loginpress_math_captcha_field' ) );
					}
					// Authentication reCAPTCHA on lost-password form.
					if ( 'off' !== $math_lost && isset( $_GET['action'] ) && 'lostpassword' === $_GET['action'] ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
						add_filter( 'allow_password_reset', array( $this, 'loginpress_math_lostpassword_auth' ), 10, 2 );
					}

					/**
					 * Add Math CAPTCHA on comments form. And do authentication.
					 *
					 * @since 6.2.0
					 */
					if ( $math_comment ) {
						add_action( 'comment_id_fields', array( $this, 'comment_loginpress_math_field' ) );
						add_filter( 'preprocess_comment', array( $this, 'loginpress_math_comment' ), 10, 1 );
					}
				}
			}
		}

		/**
		 * Start PHP session if not already started.
		 *
		 * @since 6.2.0
		 * @return void
		 */
		public static function loginpress_start_session() {
			try {
				if ( PHP_SESSION_NONE === session_status() && ! session_id() ) {
					session_start();
				}
			} catch ( Exception $e ) {
				error_log( 'Failed to start session: ' . $e->getMessage() ); // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
			}
		}

		/**
		 * Returns enabled math operators from settings.
		 *
		 * @return array
		 * @since 6.2.0
		 */
		private static function loginpress_get_enabled_operations() {
			$loginpress_captcha_settings = get_option( 'loginpress_captcha_settings' );
			$addition                    = isset( $loginpress_captcha_settings['math_captcha_types']['addition'] ) ? $loginpress_captcha_settings['math_captcha_types']['addition'] : 'off';
			$subtraction                 = isset( $loginpress_captcha_settings['math_captcha_types']['subtraction'] ) ? $loginpress_captcha_settings['math_captcha_types']['subtraction'] : 'off';
			$multiplication              = isset( $loginpress_captcha_settings['math_captcha_types']['multiplication'] ) ? $loginpress_captcha_settings['math_captcha_types']['multiplication'] : 'off';
			$division                    = isset( $loginpress_captcha_settings['math_captcha_types']['division'] ) ? $loginpress_captcha_settings['math_captcha_types']['division'] : 'off';

			$enabled_operations = array();
			if ( 'off' !== $addition ) {
				$enabled_operations[] = '+';
			}
			if ( 'off' !== $subtraction ) {
				$enabled_operations[] = '-';
			}
			if ( 'off' !== $multiplication ) {
				$enabled_operations[] = '*';
			}
			if ( 'off' !== $division ) {
				$enabled_operations[] = '/';
			}

			return $enabled_operations;
		}

		/**
		 * Generate math challenge values and answer.
		 *
		 * @param array $enabled_operations Enabled operators.
		 * @return array|null
		 * @since 6.2.0
		 */
		private static function loginpress_generate_math_challenge( $enabled_operations ) {
			if ( empty( $enabled_operations ) ) {
				return null;
			}

			$operator = $enabled_operations[ array_rand( $enabled_operations, 1 ) ];
			$lp_num1  = rand( 1, 9 ); // @codingStandardsIgnoreLine.
			$lp_num2  = rand( 1, 9 ); // @codingStandardsIgnoreLine.
			$symbol   = '';
			$answer   = 0;

			switch ( $operator ) {
				case '+':
					$answer = $lp_num1 + $lp_num2;
					$symbol = '+';
					break;
				case '-':
					if ( $lp_num1 < $lp_num2 ) {
						list( $lp_num1, $lp_num2 ) = array( $lp_num2, $lp_num1 );
					}
					$answer = $lp_num1 - $lp_num2;
					$symbol = '-';
					break;
				case '*':
					$answer = $lp_num1 * $lp_num2;
					$symbol = 'x';
					break;
				case '/':
					$lp_num2 = rand( 1, 9 ); // Avoid zero. // @codingStandardsIgnoreLine.
					$answer  = rand( 1, 9 ); // @codingStandardsIgnoreLine.
					$lp_num1 = $lp_num2 * $answer;
					$symbol  = '÷';
					break;
			}

			return array(
				'num1'   => $lp_num1,
				'num2'   => $lp_num2,
				'symbol' => $symbol,
				'answer' => $answer,
				'hash'   => md5( $answer . wp_salt() ),
			);
		}

		/**
		 * Render math captcha markup.
		 *
		 * @param array $challenge Math challenge array.
		 * @param bool  $wrap_widget Wrap for widget replacement.
		 * @param bool  $clear_value Keep answer empty when regenerating.
		 * @return string
		 * @since 6.2.0
		 */
		private static function loginpress_render_math_captcha_markup( $challenge, $wrap_widget = false, $clear_value = false ) {
			if ( empty( $challenge ) ) {
				return '';
			}

			$input_value = $clear_value ? ' value=""' : '';
			ob_start();
			if ( $wrap_widget ) {
				echo '<div class="loginpress-widget-math-captcha-wrap">';
			}
			echo '<p>';
			echo '<label for="math_captcha">Math CAPTCHA: What is ' . esc_html( $challenge['num1'] ) . ' ' . esc_html( $challenge['symbol'] ) . ' ' . esc_html( $challenge['num2'] ) . '?</label>';
			echo '<input type="text" name="math_captcha" id="math_captcha" class="input" size="30"' . esc_attr( $input_value ) . ' />';
			echo '<input type="hidden" name="loginpress_math_captcha_hash" value="' . esc_attr( $challenge['hash'] ) . '" />';
			echo '</p>';
			if ( $wrap_widget ) {
				echo '</div>';
			}

			return ob_get_clean();
		}

		/**
		 * Output the Math Captcha field in the login form.
		 *
		 * @since 6.2.0
		 */
		public static function loginpress_math_captcha_field() {
			$enabled_operations = self::loginpress_get_enabled_operations();
			$challenge          = self::loginpress_generate_math_challenge( $enabled_operations );
			if ( null === $challenge ) {
				return; // No operators enabled.
			}

			$current_hook = current_filter();
			switch ( $current_hook ) {
				case 'woocommerce_register_form':
					$_SESSION['loginpress_math_wc_reg_captcha'] = $challenge['answer'];
					break;
				case 'woocommerce_login_form':
					$_SESSION['loginpress_math_wc_captcha'] = $challenge['answer'];
					break;
				case 'woocommerce_after_order_notes':
					$_SESSION['loginpress_math_wc_checkout_captcha'] = $challenge['answer'];
					break;
				case 'bp_before_registration_submit_buttons':
					$_SESSION['loginpress_math_bb_reg_captcha'] = $challenge['answer'];
					break;
				case 'edd_login_fields_after':
					$_SESSION['loginpress_math_edd_captcha'] = $challenge['answer'];
					break;
				case 'edd_register_form_fields_after':
					$_SESSION['loginpress_math_edd_captcha'] = $challenge['answer'];
					break;
				case 'edd_purchase_form_user_info_fields':
					$_SESSION['loginpress_math_edd_captcha'] = $challenge['answer'];
					break;
				case 'lifterlms_person_login_fields':
					$_SESSION['loginpress_math_llms_login_captcha'] = $challenge['answer'];
					break;
				case 'lifterlms_before_registration_button':
					$_SESSION['loginpress_math_llms_reg_captcha'] = $challenge['answer'];
					break;
				case 'llms_checkout_footer_before':
					$_SESSION['loginpress_math_llms_reg_captcha'] = $challenge['answer'];
					break;
				case 'lifterlms_lost_password_fields':
					$_SESSION['loginpress_math_llms_lost_captcha'] = $challenge['answer'];
					break;
				case 'login_form_middle':
					$_SESSION['loginpress_math_ld_login_captcha'] = $challenge['answer'];
					break;
				case 'register_form':
					$_SESSION['loginpress_math_ld_reg_captcha'] = $challenge['answer'];
					break;
				case 'loginpress_after_login_form_widget':
					$_SESSION['loginpress_math_widget_login_captcha'] = $challenge['answer'];
					break;
				case 'loginpress_after_reg_form_widget':
					$_SESSION['loginpress_math_widget_reg_captcha'] = $challenge['answer'];
					break;
				case 'loginpress_after_lost_password_form_widget':
					$_SESSION['loginpress_math_widget_lost_captcha'] = $challenge['answer'];
					break;
				default:
					$_SESSION['loginpress_math_captcha'] = $challenge['answer'];
					break;
			}

			$widget_hooks = array(
				'loginpress_after_login_form_widget',
				'loginpress_after_reg_form_widget',
				'loginpress_after_lost_password_form_widget',
			);
			$wrap_widget  = in_array( $current_hook, $widget_hooks, true );

			echo self::loginpress_render_math_captcha_markup( $challenge, $wrap_widget ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		}

		/**
		 * Build a new math captcha HTML fragment for LoginPress widget/block AJAX refresh.
		 *
		 * @param string $context One of login, register, lost.
		 * @return string Empty string if math captcha cannot be rendered.
		 * @since 6.2.0
		 */
		public static function loginpress_math_widget_refresh_fragment( $context ) {
			$allowed = array( 'login', 'register', 'lost' );
			if ( ! in_array( $context, $allowed, true ) ) {
				return '';
			}

			self::loginpress_start_session();
			$enabled_operations = self::loginpress_get_enabled_operations();
			$challenge          = self::loginpress_generate_math_challenge( $enabled_operations );
			if ( null === $challenge ) {
				return '';
			}

			switch ( $context ) {
				case 'login':
					$_SESSION['loginpress_math_widget_login_captcha'] = $challenge['answer'];
					break;
				case 'register':
					$_SESSION['loginpress_math_widget_reg_captcha'] = $challenge['answer'];
					break;
				case 'lost':
					$_SESSION['loginpress_math_widget_lost_captcha'] = $challenge['answer'];
					break;
			}

			return self::loginpress_render_math_captcha_markup( $challenge, true, true );
		}

		/**
		 * Validate the Math CAPTCHA answer submitted in the login form.
		 *
		 * @param WP_User|WP_Error $user     The user object or WP_Error on failure.
		 * @param string           $username The username.
		 * @param string           $password The password.
		 *
		 * @since 6.2.0
		 * @return WP_User|WP_Error The user object if CAPTCHA is correct, otherwise WP_Error.
		 */
		public function loginpress_validate_math_captcha( $user, $username, $password ) { // @codingStandardsIgnoreLine.
			if ( 'POST' !== $_SERVER['REQUEST_METHOD'] || isset( $_POST['_llms_login_user_nonce'] ) ) { // @codingStandardsIgnoreLine.
				return $user; // Not a POST request, no validation needed.
			}

			if ( ! isset( $_POST['math_captcha'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing
				return new WP_Error( 'math_captcha_error', $this->loginpress_math_captcha_error() );
			}

			$user_answer = intval( wp_unslash( $_POST['math_captcha'] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Missing

			if ( isset( $_POST['loginpress_math_captcha_hash'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing
				$hash = sanitize_text_field( wp_unslash( $_POST['loginpress_math_captcha_hash'] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Missing
				$salt = wp_salt();
				if ( md5( (string) $user_answer . $salt ) !== $hash ) {
					return new WP_Error( 'math_captcha_error', $this->loginpress_math_captcha_error() );
				}
			} else {
				self::loginpress_start_session();
				$correct_answer = null;
				if ( isset( $_SESSION['loginpress_math_captcha'] ) ) {
					$correct_answer = absint( $_SESSION['loginpress_math_captcha'] );
				} elseif ( isset( $_SESSION['loginpress_math_widget_login_captcha'] ) ) {
					$correct_answer = absint( $_SESSION['loginpress_math_widget_login_captcha'] );
				}

				if ( null === $correct_answer || $user_answer !== $correct_answer ) {
					return new WP_Error( 'math_captcha_error', $this->loginpress_math_captcha_error() );
				}
			}

			unset( $_SESSION['loginpress_math_captcha'], $_SESSION['loginpress_math_widget_login_captcha'] );

			return $user;
		}

		/**
		 * Math CAPTCHA Lost Password Authentication.
		 *
		 * @param bool $allow To allow user access.
		 * @param int  $user_id User ID.
		 *
		 * @since 6.2.0
		 */
		public function loginpress_math_lostpassword_auth( $allow, $user_id ) { // @codingStandardsIgnoreLine.

			if ( ! isset( $_POST['math_captcha'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing
				return new WP_Error( 'math_captcha_error', $this->loginpress_math_captcha_error() );
			}

			$user_answer = intval( wp_unslash( $_POST['math_captcha'] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Missing

			if ( isset( $_POST['loginpress_math_captcha_hash'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing
				$hash = sanitize_text_field( wp_unslash( $_POST['loginpress_math_captcha_hash'] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Missing
				$salt = wp_salt();
				if ( md5( (string) $user_answer . $salt ) !== $hash ) {
					return new WP_Error( 'math_captcha_error', $this->loginpress_math_captcha_error() );
				}
			} else {
				self::loginpress_start_session();
				$correct_answer = null;
				if ( isset( $_SESSION['loginpress_math_captcha'] ) ) {
					$correct_answer = absint( $_SESSION['loginpress_math_captcha'] );
				} elseif ( isset( $_SESSION['loginpress_math_widget_lost_captcha'] ) ) {
					$correct_answer = absint( $_SESSION['loginpress_math_widget_lost_captcha'] );
				}

				if ( null === $correct_answer || $user_answer !== $correct_answer ) {
					return new WP_Error( 'math_captcha_error', $this->loginpress_math_captcha_error() );
				}
			}

			unset( $_SESSION['loginpress_math_captcha'], $_SESSION['loginpress_math_widget_lost_captcha'] );

			return $allow;
		}

		/**
		 * MAth Captcha error message.
		 *
		 * @return [string] [Custom error message]
		 * @since 6.2.0
		 */
		public static function loginpress_math_captcha_error() {
			$loginpress_settings = get_option( 'loginpress_customization' );
			$math_message        = isset( $loginpress_settings['math_error_message'] ) ? $loginpress_settings['math_error_message'] : __( '<strong>ERROR:</strong> Please provide correct Captcha answer', 'loginpress-pro' );

			$allowed_html = array(
				'a'      => array(),
				'br'     => array(),
				'em'     => array(),
				'strong' => array(),
				'i'      => array(),
			);
			return wp_kses( $math_message, $allowed_html );
		}

		/**
		 * Math CAPTCHA Registration Authentication.
		 *
		 * @param array  $errors The Error/s.
		 * @param string $sanitized_user_login The sanitized user login.
		 * @param string $user_email The user email.
		 * @return array $errors The Error/s.
		 *
		 * @version 6.1.0
		 */
		public static function loginpress_math_registration_auth( $errors, $sanitized_user_login, $user_email ) { // @codingStandardsIgnoreLine.

			self::loginpress_start_session();

			$correct_answer = null;
			if ( isset( $_SESSION['loginpress_math_wc_reg_captcha'] ) ) {
				$correct_answer = absint( $_SESSION['loginpress_math_wc_reg_captcha'] );
			} elseif ( isset( $_SESSION['loginpress_math_ld_reg_captcha'] ) ) {
				$correct_answer = absint( $_SESSION['loginpress_math_ld_reg_captcha'] );
			} elseif ( isset( $_SESSION['loginpress_math_widget_reg_captcha'] ) ) {
				$correct_answer = absint( $_SESSION['loginpress_math_widget_reg_captcha'] );
			}

			if ( null === $correct_answer ) {
				return new WP_Error( 'math_captcha_error', __( 'Please provide correct Captcha answer', 'loginpress-pro' ) );
			}

			if ( ! isset( $_POST['math_captcha'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing
				return new WP_Error( 'math_captcha_error', __( 'Please provide correct Captcha answer', 'loginpress-pro' ) );
			}

			$user_answer = intval( wp_unslash( $_POST['math_captcha'] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Missing

			if ( $user_answer !== $correct_answer ) {
				return new WP_Error( 'math_captcha_error', __( 'Please provide correct Captcha answer', 'loginpress-pro' ) );
			}

			unset( $_SESSION['loginpress_math_wc_reg_captcha'], $_SESSION['loginpress_math_ld_reg_captcha'], $_SESSION['loginpress_math_widget_reg_captcha'] );

			return $errors;
		}

		/**
		 * WooCommerce Login Form Math CAPTCHA Authentication.
		 *
		 * @param object $validation_error The validation error.
		 * @param string $username The username.
		 * @param string $password The password.
		 * @return object $validation_error The validation error.
		 *
		 * @since 6.2.0
		 */
		public static function loginpress_math_wc_auth( $validation_error, $username, $password ) { // @codingStandardsIgnoreLine.

			self::loginpress_start_session();

			$correct_answer = isset( $_SESSION['loginpress_math_wc_captcha'] ) ? absint( $_SESSION['loginpress_math_wc_captcha'] ) : null;

			if ( null === $correct_answer ) {
				$validation_error->add( 'math_captcha_error', __( 'Please provide correct Captcha answer', 'loginpress-pro' ) );
			} elseif ( ! isset( $_POST['math_captcha'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing
				$validation_error->add( 'math_captcha_error', __( 'Please provide correct Captcha answer', 'loginpress-pro' ) );
			} else {
				$user_answer = intval( wp_unslash( $_POST['math_captcha'] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Missing
				if ( $user_answer !== $correct_answer ) {
					$validation_error->add( 'math_captcha_error', __( 'Please provide correct Captcha answer', 'loginpress-pro' ) );
				}
			}

			unset( $_SESSION['loginpress_math_wc_captcha'] );

			return $validation_error;
		}

		/**
		 * WooCommerce checkout math CAPTCHA validation.
		 *
		 * @return void
		 * @since 6.2.0
		 */
		public static function loginpress_math_wc_checkout_auth() {
			if ( ! isset( $_POST['woocommerce-process-checkout-nonce'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing
				return;
			}
			self::loginpress_start_session();
			if ( isset( $_POST['math_captcha'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing
				$user_answer    = isset( $_POST['math_captcha'] ) ? intval( wp_unslash( $_POST['math_captcha'] ) ) : null; // phpcs:ignore WordPress.Security.NonceVerification.Missing
				$correct_answer = isset( $_SESSION['loginpress_math_wc_checkout_captcha'] ) ? absint( $_SESSION['loginpress_math_wc_checkout_captcha'] ) : null; // phpcs:ignore WordPress.Security.NonceVerification.Missing

				if ( $user_answer !== $correct_answer ) {
					wc_add_notice( self::loginpress_math_captcha_error(), 'error' );
				}
			} else {
				wc_add_notice( self::loginpress_math_captcha_error(), 'error' );
			}
			unset( $_SESSION['loginpress_math_wc_checkout_captcha'] ); // phpcs:ignore WordPress.Security.NonceVerification.Missing
		}

		/**
		 * Add Math Captcha field just before the Post button
		 *
		 * @param array $default_value Default parameter array for Math Captcha.
		 * @since 6.2.0
		 * @return array $default_value all the fields.
		 */
		public function comment_loginpress_math_field( $default_value ) {
			$this->loginpress_math_captcha_field();

			return $default_value;
		}

		/**
		 * Math Captcha on comments section authentication.
		 *
		 * @param array $commentdata Comment data.
		 * @return array Comment data.
		 * @since 6.2.0
		 */
		public function loginpress_math_comment( $commentdata ) {
			if ( ! isset( $_POST['math_captcha'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing
				wp_die( $this->loginpress_math_captcha_error() ); // @codingStandardsIgnoreLine.
			}

			$user_answer = intval( wp_unslash( $_POST['math_captcha'] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Missing

			if ( isset( $_POST['loginpress_math_captcha_hash'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing
				$hash = sanitize_text_field( wp_unslash( $_POST['loginpress_math_captcha_hash'] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Missing
				$salt = wp_salt();
				if ( md5( (string) $user_answer . $salt ) !== $hash ) {
					wp_die( $this->loginpress_math_captcha_error() ); // @codingStandardsIgnoreLine.
				}
			} else {
				self::loginpress_start_session();
				$correct_answer = isset( $_SESSION['loginpress_math_captcha'] ) ? absint( $_SESSION['loginpress_math_captcha'] ) : null;
				if ( null === $correct_answer || $user_answer !== $correct_answer ) {
					wp_die( $this->loginpress_math_captcha_error() ); // @codingStandardsIgnoreLine.
				}
			}

			unset( $_SESSION['loginpress_math_captcha'] );

			return $commentdata;
		}
	}
}
