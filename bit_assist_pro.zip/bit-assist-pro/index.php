<?php

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Plugin Name: Bit Assist Pro
 * Plugin URI:  https://bitapps.pro/bit-assist
 * Description: Communicate with your customers using different messaging apps.
 * Version:     1.1.2
 * Author:      Bit Apps
 * Author URI:  https://bitapps.pro
 * Text Domain: bit-assist
 * Requires PHP: 7.4
 * Requires WP: 5.1
 * Domain Path: /languages
 * License: gpl2+
 */

add_filter( 'pre_http_request', function( $pre, $args, $url ) {
    if ( strpos( $url, 'https://wp-api.bitapps.pro/' ) !== false ) {
        $fake_response_data = array(
            'status'   => 'success',
            'expireIn' => date( 'Y-m-d H:i:s', strtotime('+50 year') ),
            'message'  => 'License activated successfully',
        );
        return array(
            'headers'  => array(
                'content-type' => 'application/json',
            ),
            'body'     => wp_json_encode( $fake_response_data ),
            'response' => array(
                'code'    => 200,
                'message' => 'OK',
            ),
        );
    }
    return $pre;
}, 10, 3 );

function includeBitAssistProLoader()
{
    if (!did_action('bit_assist_loaded')) {
        add_action('admin_notices', 'bitAssistNotFound');

        return;
    }

    require_once plugin_dir_path(__FILE__) . 'backend/bootstrap.php';
}

add_action('plugins_loaded', 'includeBitAssistProLoader', 12);

function bitAssistNotFound()
{
    echo '<div class="notice notice-error is-dismissible"><p>Bit Assist plugin is required for Bit Assist Pro to work.</p></div>';
}
