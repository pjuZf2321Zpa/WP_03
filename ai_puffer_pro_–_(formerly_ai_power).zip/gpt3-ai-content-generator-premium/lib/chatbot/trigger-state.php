<?php

namespace WPAICG\Lib\Chat\Triggers\State;

use WPAICG\Lib\Chat\Triggers\AIPKit_Trigger_Storage;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Persists display-form trigger state independently from the chat transcript.
 */
class AIPKit_Conversation_Form_State_Store
{
    private const STATE_VERSION = 1;
    private const STATUS_PENDING = 'pending';
    private const STATUS_COMPLETED = 'completed';

    /** @var \wpdb */
    private $wpdb;

    /** @var string */
    private $table_name;

    /** @var bool */
    private static $hooks_registered = false;

    public function __construct()
    {
        global $wpdb;
        $this->wpdb = $wpdb;
        $this->table_name = $wpdb->prefix . 'aipkit_chat_logs';
    }

    /**
     * Registers the Pro-only frontend capability signal.
     */
    public static function register_hooks(): void
    {
        if (self::$hooks_registered) {
            return;
        }

        add_filter('aipkit_chat_form_gate_enabled', [self::class, 'filter_form_gate_enabled'], 10, 2);
        self::$hooks_registered = true;
    }

    /**
     * Enables form-gate restoration only for bots with an active display-form rule.
     *
     * @param bool $enabled Existing filtered state.
     * @param int  $bot_id Chatbot post ID.
     * @return bool
     */
    public static function filter_form_gate_enabled(bool $enabled, int $bot_id): bool
    {
        if ($enabled) {
            return true;
        }

        return !empty(self::get_active_display_form_trigger_ids($bot_id));
    }

    /**
     * Returns persisted state for one trigger in one conversation.
     *
     * @return array<string, mixed>|null
     */
    public function get_trigger_state(
        int $bot_id,
        ?int $user_id,
        ?string $session_id,
        string $conversation_uuid,
        string $trigger_id
    ): ?array {
        $trigger_id = sanitize_key($trigger_id);
        if ($trigger_id === '') {
            return null;
        }

        $row = $this->get_conversation_row($bot_id, $user_id, $session_id, $conversation_uuid);
        if (!$row) {
            return null;
        }

        $state = $this->decode_state($row['form_state'] ?? '');
        $trigger_state = $state['triggers'][$trigger_id] ?? null;

        return is_array($trigger_state) ? $trigger_state : null;
    }

    /**
     * Finds trigger state by form ID for compatibility with cached frontend bundles.
     *
     * @return array<string, mixed>|null
     */
    public function get_form_state_by_form_id(
        int $bot_id,
        ?int $user_id,
        ?string $session_id,
        string $conversation_uuid,
        string $form_id
    ): ?array {
        $form_id = sanitize_text_field($form_id);
        if ($form_id === '') {
            return null;
        }

        $row = $this->get_conversation_row($bot_id, $user_id, $session_id, $conversation_uuid);
        if (!$row) {
            return null;
        }

        $state = $this->decode_state($row['form_state'] ?? '');
        foreach ($state['triggers'] as $trigger_state) {
            if (is_array($trigger_state) && ($trigger_state['form_id'] ?? '') === $form_id) {
                return $trigger_state;
            }
        }

        return null;
    }

    /**
     * Returns the oldest pending form whose display-form trigger is still active.
     *
     * @return array<string, mixed>|null
     */
    public function get_pending_form(
        int $bot_id,
        ?int $user_id,
        ?string $session_id,
        string $conversation_uuid
    ): ?array {
        $row = $this->get_conversation_row($bot_id, $user_id, $session_id, $conversation_uuid);
        if (!$row) {
            return null;
        }

        $active_trigger_ids = self::get_active_display_form_trigger_ids($bot_id);
        if (empty($active_trigger_ids)) {
            return null;
        }

        $state = $this->decode_state($row['form_state'] ?? '');
        $pending_states = [];
        foreach ($state['triggers'] as $trigger_id => $trigger_state) {
            if (
                !isset($active_trigger_ids[$trigger_id])
                || !is_array($trigger_state)
                || ($trigger_state['status'] ?? '') !== self::STATUS_PENDING
                || empty($trigger_state['form_definition'])
                || !is_array($trigger_state['form_definition'])
            ) {
                continue;
            }
            $pending_states[] = $trigger_state;
        }

        if (empty($pending_states)) {
            return null;
        }

        usort($pending_states, static function (array $left, array $right): int {
            return absint($left['created_at'] ?? 0) <=> absint($right['created_at'] ?? 0);
        });

        return $pending_states[0];
    }

    /**
     * Stores a pending form for a trigger.
     */
    public function mark_pending(
        int $bot_id,
        ?int $user_id,
        ?string $session_id,
        string $conversation_uuid,
        string $trigger_id,
        array $form_definition
    ): bool {
        $trigger_id = sanitize_key($trigger_id);
        $form_id = sanitize_text_field((string) ($form_definition['form_id'] ?? ''));
        if ($trigger_id === '' || $form_id === '') {
            return false;
        }

        $row = $this->get_conversation_row($bot_id, $user_id, $session_id, $conversation_uuid);
        if (!$row) {
            return false;
        }

        $state = $this->decode_state($row['form_state'] ?? '');
        $existing_state = $state['triggers'][$trigger_id] ?? null;
        if (is_array($existing_state) && ($existing_state['status'] ?? '') === self::STATUS_COMPLETED) {
            return false;
        }

        $created_at = is_array($existing_state) ? absint($existing_state['created_at'] ?? 0) : 0;
        $state['triggers'][$trigger_id] = [
            'trigger_id' => $trigger_id,
            'form_id' => $form_id,
            'status' => self::STATUS_PENDING,
            'form_definition' => $this->sanitize_form_definition($form_definition),
            'created_at' => $created_at > 0 ? $created_at : time(),
            'updated_at' => time(),
        ];

        return $this->write_state(absint($row['id']), $state);
    }

    /**
     * Marks a pending form as completed and removes its restorable definition.
     */
    public function mark_completed(
        int $bot_id,
        ?int $user_id,
        ?string $session_id,
        string $conversation_uuid,
        string $trigger_id,
        string $form_id
    ): bool {
        $trigger_id = sanitize_key($trigger_id);
        $form_id = sanitize_text_field($form_id);
        if ($trigger_id === '' || $form_id === '') {
            return false;
        }

        $row = $this->get_conversation_row($bot_id, $user_id, $session_id, $conversation_uuid);
        if (!$row) {
            return false;
        }

        $state = $this->decode_state($row['form_state'] ?? '');
        $existing_state = $state['triggers'][$trigger_id] ?? null;
        if (!is_array($existing_state) || ($existing_state['form_id'] ?? '') !== $form_id) {
            return false;
        }
        if (($existing_state['status'] ?? '') === self::STATUS_COMPLETED) {
            return true;
        }
        if (($existing_state['status'] ?? '') !== self::STATUS_PENDING) {
            return false;
        }

        $state['triggers'][$trigger_id] = [
            'trigger_id' => $trigger_id,
            'form_id' => $form_id,
            'status' => self::STATUS_COMPLETED,
            'created_at' => absint($existing_state['created_at'] ?? time()),
            'updated_at' => time(),
            'completed_at' => time(),
        ];

        return $this->write_state(absint($row['id']), $state);
    }

    /**
     * Returns active display-form trigger IDs as a lookup map.
     *
     * @return array<string, true>
     */
    private static function get_active_display_form_trigger_ids(int $bot_id): array
    {
        if ($bot_id <= 0 || !class_exists(AIPKit_Trigger_Storage::class)) {
            return [];
        }

        $trigger_storage = new AIPKit_Trigger_Storage();
        $triggers = $trigger_storage->get_triggers($bot_id);
        $ids = [];
        foreach ($triggers as $trigger) {
            if (!is_array($trigger)) {
                continue;
            }
            $is_active = in_array($trigger['is_active'] ?? false, [true, 1, '1'], true);
            $action_type = sanitize_key((string) ($trigger['action']['type'] ?? ''));
            $trigger_id = sanitize_key((string) ($trigger['id'] ?? ''));
            if ($is_active && $action_type === 'display_form' && $trigger_id !== '') {
                $ids[$trigger_id] = true;
            }
        }

        return $ids;
    }

    /**
     * Finds the chat log row bound to the current visitor and conversation.
     *
     * @return array<string, mixed>|null
     */
    private function get_conversation_row(
        int $bot_id,
        ?int $user_id,
        ?string $session_id,
        string $conversation_uuid
    ): ?array {
        $conversation_uuid = sanitize_key($conversation_uuid);
        $session_id = sanitize_text_field((string) $session_id);
        if ($bot_id <= 0 || $conversation_uuid === '' || (!$user_id && $session_id === '')) {
            return null;
        }

        $where_sql = 'bot_id = %d AND conversation_uuid = %s AND module = %s AND ';
        $params = [$bot_id, $conversation_uuid, 'chat'];
        if ($user_id) {
            $where_sql .= 'user_id = %d';
            $params[] = $user_id;
        } else {
            $where_sql .= '(user_id IS NULL AND session_id = %s AND is_guest = 1)';
            $params[] = $session_id;
        }

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare, PluginCheck.Security.DirectDB.UnescapedDBParameter -- Prepared lookup against a plugin-owned table whose identifier is derived from $wpdb->prefix.
        $row = $this->wpdb->get_row($this->wpdb->prepare("SELECT id, form_state FROM {$this->table_name} WHERE {$where_sql} LIMIT 1", $params), ARRAY_A);

        return is_array($row) ? $row : null;
    }

    /**
     * Normalizes persisted state and preserves forward-compatible trigger entries.
     *
     * @return array{version:int,triggers:array<string,mixed>}
     */
    private function decode_state($raw_state): array
    {
        $decoded = is_string($raw_state) && $raw_state !== '' ? json_decode($raw_state, true) : [];
        if (!is_array($decoded)) {
            $decoded = [];
        }

        return [
            'version' => self::STATE_VERSION,
            'triggers' => isset($decoded['triggers']) && is_array($decoded['triggers']) ? $decoded['triggers'] : [],
        ];
    }

    /**
     * Sanitizes a server-generated form before storing it for restoration.
     *
     * @return array<string, mixed>
     */
    private function sanitize_form_definition(array $form_definition): array
    {
        $sanitize_value = static function ($value) use (&$sanitize_value) {
            if (is_array($value)) {
                $sanitized = [];
                foreach ($value as $key => $item) {
                    $safe_key = is_int($key) ? $key : sanitize_key((string) $key);
                    if (!is_int($safe_key) && $safe_key === '') {
                        continue;
                    }
                    $sanitized[$safe_key] = $sanitize_value($item);
                }
                return $sanitized;
            }
            if (is_bool($value) || is_int($value) || is_float($value) || $value === null) {
                return $value;
            }
            return sanitize_textarea_field((string) $value);
        };

        $sanitized = $sanitize_value($form_definition);
        return is_array($sanitized) ? $sanitized : [];
    }

    /**
     * Writes only the independent state column so transcript updates cannot be overwritten.
     */
    private function write_state(int $row_id, array $state): bool
    {
        $encoded_state = wp_json_encode($state, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        if ($row_id <= 0 || !is_string($encoded_state)) {
            return false;
        }

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- Direct update to a plugin-owned custom table is required for conversation state.
        $updated = $this->wpdb->update(
            $this->table_name,
            ['form_state' => $encoded_state],
            ['id' => $row_id],
            ['%s'],
            ['%d']
        );

        return $updated !== false;
    }
}
