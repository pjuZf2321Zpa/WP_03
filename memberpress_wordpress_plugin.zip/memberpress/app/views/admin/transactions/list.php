<?php
if (!defined('ABSPATH')) {
    die('You are not allowed to call this page directly.');
}

$member          = (isset($_GET['member'])) ? sanitize_text_field(wp_unslash($_GET['member'])) : '';
$member          = (isset($_GET['search']) && isset($_GET['search-field']) && (sanitize_text_field(wp_unslash($_GET['search-field'])) === 'user' || sanitize_text_field(wp_unslash($_GET['search-field'])) === 'email')) ? sanitize_text_field(wp_unslash($_GET['search'])) : '';
$member_str      = !empty($member) ? __('for', 'memberpress') . ' ' . rawurldecode($member) : '';
$subscription_id = intval($_GET['subscription'] ?? 0);

$add_new_txn_url = admin_url('admin.php?page=memberpress-trans&action=new&user=' . $member);
if ($subscription_id > 0) {
    $add_new_txn_url .= '&subscription=' . $subscription_id;
}
?>
<div class="wrap">
  <h1 class="wp-heading-inline"><?php esc_html_e('Transactions', 'memberpress'); ?> <?php echo esc_html($member_str); ?></h1>
  <a href="<?php echo esc_url($add_new_txn_url); ?>" class="page-title-action"><?php esc_html_e('Add New', 'memberpress'); ?></a>
  <hr class="wp-header-end">
  <input type="hidden" name="mepr-update-transactions" value="Y" />

    <?php MeprHooks::do_action('mepr_admin_transactions_list_header'); ?>

    <?php $list_table->display(); ?>
</div>
