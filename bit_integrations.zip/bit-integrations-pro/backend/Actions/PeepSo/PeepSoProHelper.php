<?php

namespace BitApps\IntegrationsPro\Actions\PeepSo;

class PeepSoProHelper
{
    private const ACTIVITY_POST_MODULE_ID = 1;

    private const SYSTEM_ROLES = ['member', 'admin', 'ban', 'register', 'verified'];

    private const PEEPSO_CLASS = 'PeepSo';

    private const ACTIVITY_STREAM_CLASS = 'PeepSoActivityStream';

    private const USER_CLASS = 'PeepSoUser';

    private const FOLLOWER_CLASS = 'PeepSoUserFollower';

    public static function addPostActivityStream($defaultResponse, $fieldData)
    {
        if (!self::isPeepSoActive()) {
            return self::errorResponse(__('PeepSo is not installed or activated', 'bit-integrations-pro'));
        }

        $validationError = self::validateRequiredFields(
            $fieldData,
            [
                'user_email'   => __('User email is required', 'bit-integrations-pro'),
                'post_title'   => __('Post title is required', 'bit-integrations-pro'),
                'post_content' => __('Post content is required', 'bit-integrations-pro'),
            ]
        );

        if ($validationError) {
            return $validationError;
        }

        $user = self::getUserByEmail($fieldData['user_email']);
        if (!$user) {
            return self::errorResponse(__('User not found', 'bit-integrations-pro'));
        }

        $userId = $user->ID;
        $content = wp_kses_post($fieldData['post_content']);

        $postId = self::createActivityPost($userId, $fieldData['post_title'], $content);

        if (!$postId || is_wp_error($postId)) {
            return self::errorResponse(__('Unable to create post', 'bit-integrations-pro'));
        }

        add_post_meta($postId, '_peepso_display_link_preview', 1, true);

        $profileAccessibility = self::getProfileAccessibility($userId);
        $activityData = self::buildActivityData($userId, $postId, $profileAccessibility);

        if (!self::insertActivity($activityData)) {
            return self::errorResponse(__('Unable to create activity', 'bit-integrations-pro'));
        }

        if (absint($activityData['act_module_id']) === self::ACTIVITY_POST_MODULE_ID) {
            update_user_meta($userId, 'peepso_last_used_post_privacy', $profileAccessibility);
        }

        $filteredContent = self::updatePostContent($postId, $content);

        $post = get_post($postId);
        if (!$post) {
            return self::errorResponse(__('Unable to retrieve created post', 'bit-integrations-pro'));
        }

        return self::successResponse(
            __('Activity post created successfully', 'bit-integrations-pro'),
            self::buildPostResponseData($filteredContent, $post, $userId)
        );
    }

    public static function changeUserRole($defaultResponse, $fieldData)
    {
        if (!self::isPeepSoActive()) {
            return self::errorResponse(__('PeepSo is not installed or activated', 'bit-integrations-pro'));
        }

        $validationError = self::validateRequiredFields(
            $fieldData,
            [
                'user_email' => __('User email is required', 'bit-integrations-pro'),
                'new_role'   => __('New role is required', 'bit-integrations-pro'),
            ]
        );

        if ($validationError) {
            return $validationError;
        }

        $user = self::getUserByEmail($fieldData['user_email']);
        if (!$user) {
            return self::errorResponse(__('User not found', 'bit-integrations-pro'));
        }

        $userId = $user->ID;
        $newRole = sanitize_key($fieldData['new_role']);

        if (!self::isValidSystemRole($newRole)) {
            return self::errorResponse(__('The selected role doesn\'t exist', 'bit-integrations-pro'));
        }

        $peepSoUser = self::getValidPeepSoUser($userId);
        if (!$peepSoUser) {
            return self::errorResponse(__('Invalid User', 'bit-integrations-pro'));
        }

        $peepSoClass = self::PEEPSO_CLASS;
        if ($peepSoClass::is_admin($userId) && $newRole === 'ban') {
            return self::errorResponse(__('You cannot ban administrators', 'bit-integrations-pro'));
        }

        $peepSoUser->approve_user();
        $peepSoUser->set_user_role($newRole);

        return self::successResponse(__('User role changed successfully', 'bit-integrations-pro'), [
            'user_id'  => $userId,
            'new_role' => $newRole,
        ]);
    }

    public static function followUser($defaultResponse, $fieldData)
    {
        if (!self::isPeepSoActive(self::FOLLOWER_CLASS)) {
            return self::errorResponse(__('PeepSo is not installed or activated', 'bit-integrations-pro'));
        }

        $validationError = self::validateRequiredFields(
            $fieldData,
            [
                'user_email'        => __('Follower email is required', 'bit-integrations-pro'),
                'follow_user_email' => __('Follow user email is required', 'bit-integrations-pro'),
            ]
        );

        if ($validationError) {
            return $validationError;
        }

        $user = self::getUserByEmail($fieldData['user_email']);
        if (!$user) {
            return self::errorResponse(__('Follower user not found', 'bit-integrations-pro'));
        }

        $followUser = self::getUserByEmail($fieldData['follow_user_email']);
        if (!$followUser) {
            return self::errorResponse(__('User to follow not found', 'bit-integrations-pro'));
        }

        $userId = $user->ID;
        $followUserId = $followUser->ID;

        if (!self::setUserFollowStatus($followUserId, $userId, 1)) {
            return self::errorResponse(__('Unable to follow user', 'bit-integrations-pro'));
        }

        return self::successResponse(__('User followed successfully', 'bit-integrations-pro'), [
            'follower_id'  => $userId,
            'following_id' => $followUserId,
        ]);
    }

    private static function isPeepSoActive($requiredClass = null)
    {
        if (!class_exists(self::PEEPSO_CLASS)) {
            return false;
        }

        return ! ($requiredClass !== null && !class_exists($requiredClass))

        ;
    }

    private static function validateRequiredFields($fieldData, $requiredFields)
    {
        foreach ($requiredFields as $field => $message) {
            if (empty($fieldData[$field])) {
                return self::errorResponse($message);
            }
        }
    }

    private static function getUserByEmail($email)
    {
        return get_user_by('email', sanitize_email($email));
    }

    private static function createActivityPost($userId, $postTitle, $content)
    {
        $activityStreamClass = self::ACTIVITY_STREAM_CLASS;

        return wp_insert_post(
            [
                'post_title'   => sanitize_text_field($postTitle),
                'post_excerpt' => $content,
                'post_content' => $content,
                'post_status'  => 'publish',
                'post_author'  => $userId,
                'post_type'    => $activityStreamClass::CPT_POST,
            ]
        );
    }

    private static function getProfileAccessibility($userId)
    {
        $userClass = self::USER_CLASS;
        $peepSoUser = $userClass::get_instance($userId);

        return $peepSoUser->get_profile_accessibility();
    }

    private static function buildActivityData($userId, $postId, $profileAccessibility)
    {
        $peepSoClass = self::PEEPSO_CLASS;

        $activityData = [
            'act_owner_id'    => $userId,
            'act_module_id'   => self::ACTIVITY_POST_MODULE_ID,
            'act_external_id' => $postId,
            'act_access'      => $profileAccessibility,
            'act_ip'          => $peepSoClass::get_ip_address(),
        ];

        $filteredData = apply_filters('peepso_activity_insert_data', $activityData);

        return \is_array($filteredData) ? $filteredData : $activityData;
    }

    private static function insertActivity($activityData)
    {
        global $wpdb;

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        $result = $wpdb->insert($wpdb->prefix . 'peepso_activities', $activityData);

        return \is_int($result);
    }

    private static function updatePostContent($postId, $content)
    {
        $filteredContent = apply_filters('peepso_activity_post_content', $content, $postId);

        wp_update_post(
            [
                'ID'           => $postId,
                'post_content' => $filteredContent,
            ]
        );

        return $filteredContent;
    }

    private static function buildPostResponseData($filteredContent, $post, $userId)
    {
        $peepSoClass = self::PEEPSO_CLASS;

        return [
            'content'   => $filteredContent,
            'status'    => 'published',
            'permalink' => $peepSoClass::get_page('activity_status') . $post->post_title,
            'post'      => $post,
            'user_id'   => $userId,
        ];
    }

    private static function isValidSystemRole($role)
    {
        return \in_array($role, self::SYSTEM_ROLES, true);
    }

    private static function getValidPeepSoUser($userId)
    {
        $userClass = self::USER_CLASS;
        $peepSoUser = $userClass::get_instance($userId);

        if (!$peepSoUser || $peepSoUser->get_id() === null) {
            return;
        }

        return $peepSoUser;
    }

    private static function setUserFollowStatus($followUserId, $followerId, $status)
    {
        $followerClass = self::FOLLOWER_CLASS;
        $peepsoUserFollower = new $followerClass($followUserId, $followerId, true);
        $peepsoUserFollower->set('follow', absint($status));

        return !empty($peepsoUserFollower->follow);
    }

    private static function successResponse($message, $data = [])
    {
        return [
            'success' => true,
            'message' => $message,
            'data'    => $data
        ];
    }

    private static function errorResponse($message)
    {
        return [
            'success' => false,
            'message' => $message
        ];
    }
}
