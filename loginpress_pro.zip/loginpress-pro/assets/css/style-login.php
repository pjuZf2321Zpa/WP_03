<?php
/**
 * LoginPress Pro - Login Page Style Generator
 *
 * This file generates dynamic CSS and JavaScript for the custom login page styling.
 * It handles Google Fonts integration, reCAPTCHA scaling, and responsive design
 * for the LoginPress Pro plugin's login page customization.
 *
 * @package LoginPress Pro
 * @subpackage Assets
 * @since 1.0.0
 * @version 6.2.0
 *
 * @author WPBrigadeance
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$loginpress_pro_array = (array) get_option( 'loginpress_customization' );

/**
 * Retrieve a specific option key from the LoginPress Pro array.
 *
 * @param string $loginpress_key The key to retrieve from the array.
 * @param array  $loginpress_pro_array The array of LoginPress Pro options.
 * @return mixed|null The value of the key if it exists, null otherwise.
 * @since 1.0.0
 */
function loginpress_pro_get_option_key( $loginpress_key, $loginpress_pro_array ) {

	if ( array_key_exists( $loginpress_key, $loginpress_pro_array ) ) {

		return $loginpress_pro_array[ $loginpress_key ];
	}
}

$loginpress_google_font = loginpress_pro_get_option_key( 'google_font', $loginpress_pro_array );

/**
* Register custom fonts.
*/
if ( $loginpress_google_font ) {

	$loginpress_json_file       = file_get_contents( LOGINPRESS_PRO_ROOT_PATH . '/fonts/google-web-fonts.txt' ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
	$loginpress_json_font       = json_decode( $loginpress_json_file );
	$loginpress_json_font_array = $loginpress_json_font->items;

	$loginpress_font_array = array();
	foreach ( $loginpress_json_font_array as $loginpress_key ) {

		$loginpress_get_font = $loginpress_google_font === $loginpress_key->family ? $loginpress_google_font : false;
		if ( $loginpress_get_font ) :
			$loginpress_font_array[] = $loginpress_key;
endif;
	}

	if ( ! empty( $loginpress_font_array ) ) {
		// Font was found.
		$loginpress_font_name = $loginpress_font_array[0]->family;
		$loginpress_font_weights         = $loginpress_font_array[0]->variants;
		$loginpress_font_weight          = implode( ',', $loginpress_font_weights );
		$loginpress_subsets              = $loginpress_font_array[0]->subsets;
		$loginpress_subset               = implode( ',', $loginpress_subsets );

		$loginpress_font_families   = array();
		$loginpress_font_families[] = "{$loginpress_font_name}:{$loginpress_font_weight}";

		$loginpress_query_args = array(
			'family' => rawurlencode( implode( '|', $loginpress_font_families ) ), // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.urlencode_urlencode
			'subset' => rawurlencode( $loginpress_subset ), // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.urlencode_urlencode
		);

		$loginpress_fonts_url = esc_url_raw( add_query_arg( $loginpress_query_args, 'https://fonts.googleapis.com/css' ) );

	} else {
		// Font not found in current list — fallback.
		$loginpress_font_name = 'sans-serif'; // Fallback.
		$loginpress_fonts_url = ''; // No external font.
	}
}

if ( $loginpress_google_font ) { ?>
	<link href="<?php echo esc_url( $loginpress_fonts_url ); // phpcs:ignore ?>" rel='stylesheet'>
	<style type="text/css">
		body{
			font-family: <?php echo wp_strip_all_tags( '"' . $loginpress_font_name . '"' ); ?> !important;
		}
		.wp-core-ui #login .wp-generate-pw,
		.login input[type="submit"], .login form .input, .login input[type="text"] {
			font-family: <?php echo wp_strip_all_tags( '"' . $loginpress_font_name . '"' ); ?> !important;
		}
	</style>

<?php } ?>
