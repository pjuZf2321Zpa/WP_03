<?php // phpcs:ignore WordPress.Files.FileName.InvalidClassFileName
/**
 * LoginPress_Social_Login_Check
 *
 * @package LoginPress_Social_Login
 * @since 1.0.0
 * @version 6.2.0
 */

defined( 'ABSPATH' ) || die( 'No script kiddies please!' );

if ( ! class_exists( 'LoginPress_Social_Login_Check' ) ) {
	include_once __DIR__ . '/traits/providers-1.php';
	include_once __DIR__ . '/traits/providers-2.php';
	include_once __DIR__ . '/traits/providers-3.php';
	include_once __DIR__ . '/traits/providers-4.php';
	/**
	 * LoginPress_Social_Login_Check
	 *
	 * @since 1.0.0
	 * @version 6.1.0
	 */
	class LoginPress_Social_Login_Check {
		use LoginPress_Social_Login_Providers_Trait;
		use LoginPress_Social_Login_Providers2_Trait;
		use LoginPress_Social_Login_Providers3_Trait;
		use LoginPress_Social_Login_Providers4_Trait;

		/**
		 * Class constructor.
		 *
		 * @return void
		 * @since 1.0.0
		 */
		public function __construct() {
				$this->set_redirect_to();
				$this->loginpress_check();

			if ( isset( $_REQUEST['oauth_verifier'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
				$lp_twitter_oauth = get_option( 'loginpress_twitter_oauth' );
				if ( isset( $lp_twitter_oauth['oauth_token'] ) ) {
					$this->loginpress_on_twitter_login();
				}
			}
			// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- OAuth callback flow, state parameter provides CSRF protection.
			if ( isset( $_GET['code'] ) && isset( $_GET['state'] ) ) {
				if ( isset( $_GET['lpsl_login_id'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
					$exploder = explode( '_', sanitize_text_field( wp_unslash( $_GET['lpsl_login_id'] ) ) ); // phpcs:ignore
					if ( 'twitter' === $exploder[0] ) {
						$this->loginpress_on_twitter_login();
					}
				}
			}
		}

		/**
		 * Set Cookie for the `redirect_to` args.
		 *
		 * @return void
		 * @since 3.0.0
		 * @version 6.1.0
		 */
		public function set_redirect_to() {
			// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Redirect parameter for OAuth flow.
			if ( isset( $_REQUEST['redirect_to'] ) ) {
				$redirect_to = esc_url_raw( wp_unslash( $_REQUEST['redirect_to'] ) ); // phpcs:ignore
				// 60 seconds ( 1 minute) * 20 = 20 minutes.
				setcookie( 'lg_redirect_to', $redirect_to, time() + ( 60 * 20 ) ); // phpcs:ignore WordPress.VIP.RestrictedFunctions.cookies_setcookie
			}
		}
		/**
		 * Execute the specific Social login.
		 *
		 * @since 1.0.0
		 * @version 6.1.0
		 * @return void
		 */
		public function loginpress_check() {
			// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Verification parameter for OAuth provider verification.
			if ( isset( $_GET['verification'] ) ) {
				set_transient( 'loginpress_verify_status', 1, 120 );
			}
			// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- OAuth callback flow, state/code parameters provide CSRF protection.
			if ( isset( $_GET['lpsl_login_id'] ) ) {
				$exploder = explode( '_', sanitize_text_field( wp_unslash( $_GET['lpsl_login_id'] ) ) ); // phpcs:ignore
				if ( 'facebook' === $exploder[0] ) {
					if ( version_compare( PHP_VERSION, '5.4.0', '<' ) ) {
						esc_html_e( 'The Facebook SDK requires PHP version 5.4 or higher. Please notify about this error to site admin.', 'loginpress-pro' );
						die();
					}
					$this->loginpress_on_facebook_login();
				} elseif ( 'twitter' === $exploder[0] ) {
					$this->loginpress_on_twitter_login();
				} elseif ( 'gplus' === $exploder[0] ) {
					$this->loginpress_on_google_login();
				} elseif ( 'linkedin' === $exploder[0] ) {
					$this->loginpress_on_linkedin_login();
				} elseif ( 'microsoft' === $exploder[0] ) {
					$this->loginpress_on_microsoft_login();
				} elseif ( 'apple' === $exploder[0] ) {
					$this->loginpress_on_apple_login();
				} elseif ( 'github' === $exploder[0] ) {
					$this->loginpress_on_github_login();
				} elseif ( 'discord' === $exploder[0] ) {
					$this->loginpress_on_discord_login();
				} elseif ( 'wordpress' === $exploder[0] ) { // phpcs:ignore
					$this->loginpress_on_wordpress_login();
				} elseif ( 'amazon' === $exploder[0] ) {
					$this->loginpress_on_amazon_login();
				} elseif ( 'pinterest' === $exploder[0] ) {
					$this->loginpress_on_pinterest_login();
				} elseif ( 'disqus' === $exploder[0] ) {
					$this->loginpress_on_disqus_login();
				} elseif ( 'reddit' === $exploder[0] ) {
					$this->loginpress_on_reddit_login();
				} elseif ( 'spotify' === $exploder[0] ) {
					$this->loginpress_on_spotify_login();
				} elseif ( 'twitch' === $exploder[0] ) {
					$this->loginpress_on_twitch_login();
				}
			}

			if ( isset( $_GET['state'] ) && false !== strpos( sanitize_text_field( wp_unslash( $_GET['state'] ) ), 'lpsl_login=microsoft' ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
				$this->loginpress_on_microsoft_login();
			}
			if ( isset( $_GET['state'] ) && false !== strpos( sanitize_text_field( wp_unslash( $_GET['state'] ) ), 'pinterest' ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
				$this->loginpress_on_pinterest_login();
			}
		}

		/**
		 * Check if the user is verifying the provider.
		 *
		 * @return bool True if verification flow is active, false otherwise.
		 * @since 6.0.0
		 */
		private function lp_check_verification_flow() {
			if ( get_transient( 'loginpress_verify_status' ) ) {
				echo '<script>
					if (window.opener) {
						window.close();
						window.opener.postMessage("verified", window.location.origin);
						
					}
				</script>';
				delete_transient( 'loginpress_verify_status' );
				return true;
			}
			return false;
		}

		/**
		 * Apply provider-specific filters to default user fields and assign to result object.
		 *
		 * @since 6.2.0
		 * @param object $result            Result object to modify.
		 * @param string $filter_prefix     Filter name prefix (e.g. 'google' for gplus; WordPress.com provider uses its own slug).
		 * @param string $default_username  Default username.
		 * @param string $default_first_name Default first name.
		 * @param string $default_last_name  Default last name.
		 * @param string $default_image      Default avatar URL.
		 * @return void
		 */
		private function loginpress_apply_provider_defaults( $result, $filter_prefix, $default_username, $default_first_name, $default_last_name, $default_image ) {
			$result->username   = sanitize_text_field( (string) apply_filters( 'loginpress_sl_' . $filter_prefix . '_username', $default_username ) );
			$result->first_name = sanitize_text_field( (string) apply_filters( 'loginpress_sl_' . $filter_prefix . '_firstname', $default_first_name ) );
			$result->last_name  = sanitize_text_field( (string) apply_filters( 'loginpress_sl_' . $filter_prefix . '_lastname', $default_last_name ) );
			$result->deuimage   = esc_url_raw( (string) apply_filters( 'loginpress_sl_' . $filter_prefix . '_avatar', $default_image ) );
		}

		/**
		 * Create result object for loginpress.
		 *
		 * @since 5.0.0
		 * @version 6.2.0
		 * @param array  $profile   Profile data.
		 * @param string $deutype  Type of the social login.
		 * @param array  $overrides Overrides for specific providers.
		 * @return object Result object.
		 */
		public function loginpress_create_result_obj( $profile, $deutype, $overrides = array() ) {

			// initialize the result object.
			$result = new stdClass();

			// Default values.
			$result->status   = 'SUCCESS';
			$result->deutype  = $deutype;
			$result->gender   = '';
			$result->url      = '';
			$result->about    = '';
			$result->deuimage = 'https://secure.gravatar.com/avatar/75d23af433e0cea4c0e45a56dba18b30?s=96&d=mm';

			// Handle provider-specific logic.
			switch ( $deutype ) {
				case 'github':
					// Find the noreply address dynamically to extract the stable GitHub numeric user ID.
					$noreply_email = '';
					foreach ( $profile as $email_obj ) {
						if ( isset( $email_obj['email'] ) && false !== strpos( $email_obj['email'], '@users.noreply.github.com' ) ) {
							$noreply_email = $email_obj['email'];
							break;
						}
					}
					preg_match( '/^(\d+)\+([^\@]+)@/', $noreply_email, $matches );
					$result->deuid      = isset( $matches[1] ) ? $matches[1] : '';
					$result->email      = isset( $overrides['email'] ) ? $overrides['email'] : '';
					$default_username   = $result->email ? $result->email : ( isset( $matches[2] ) ? strtolower( $matches[2] ) : '' );
					$default_first_name = isset( $matches[2] ) ? $matches[2] : '';
					$default_last_name  = '';
					$this->loginpress_apply_provider_defaults( $result, 'github', $default_username, $default_first_name, $default_last_name, '' );
					break;

				case 'WordPress':
					$result->deuid      = isset( $profile['ID'] ) ? $profile['ID'] : '';
					$result->email      = isset( $profile['email'] ) ? $profile['email'] : '';
					$default_username   = isset( $profile['email'] ) ? $profile['email'] : strtolower( $profile['display_name'] );
					$default_first_name = isset( $profile['display_name'] ) ? $profile['display_name'] : '';
					$default_last_name  = '';
					$default_image      = isset( $profile['avatar_URL'] ) ? $profile['avatar_URL'] : $result->deuimage;
					$this->loginpress_apply_provider_defaults( $result, 'wordpress', $default_username, $default_first_name, $default_last_name, $default_image ); // phpcs:ignore WordPress.WP.CapitalPDangit -- Filter slug is lowercase.
					break;

				case 'linkedin':
					$result->deuid         = isset( $overrides['deuid'] ) ? $overrides['deuid'] : '';
					$result->email         = ! empty( $overrides['email_address'] ) ? $overrides['email_address'] : $result->deuid . '@linkedin.com';
					$result->gender        = 'N/A';
					$result->error_message = '';
					$default_username      = isset( $result->email ) ? $result->email : strtolower( $result->first_name . '_' . $result->last_name );
					$default_first_name    = isset( $overrides['first_name'] ) ? $overrides['first_name'] : '';
					$default_last_name     = isset( $overrides['last_name'] ) ? $overrides['last_name'] : '';
					$default_image         = isset( $overrides['large_avatar'] ) ? $overrides['large_avatar'] : $result->deuimage;
					$this->loginpress_apply_provider_defaults( $result, 'linkedin', $default_username, $default_first_name, $default_last_name, $default_image );
					break;

				case 'gplus':
					$result->deuid      = isset( $profile['sub'] ) ? $profile['sub'] : '';
					$result->email      = isset( $profile['email'] ) ? $profile['email'] : '';
					$default_username   = isset( $profile['email'] ) ? $profile['email'] : strtolower( $profile['given_name'] );
					$default_first_name = isset( $profile['given_name'] ) ? $profile['given_name'] : '';
					$default_last_name  = '';
					$default_image      = isset( $profile['picture'] ) ? $profile['picture'] : $result->deuimage;
					$this->loginpress_apply_provider_defaults( $result, 'google', $default_username, $default_first_name, $default_last_name, $default_image );
					break;

				case 'amazon':
					$result->deuid      = isset( $profile['user_id'] ) ? $profile['user_id'] : '';
					$result->email      = isset( $profile['email'] ) ? $profile['email'] : '';
					$default_username   = isset( $profile['email'] ) ? $profile['email'] : strtolower( $profile['name'] );
					$default_first_name = isset( $profile['name'] ) ? $profile['name'] : '';
					$default_last_name  = '';
					$this->loginpress_apply_provider_defaults( $result, 'amazon', $default_username, $default_first_name, $default_last_name, '' );
					break;

				case 'pinterest':
					$result->deuid      = isset( $profile['id'] ) ? $profile['id'] : '';
					$result->email      = isset( $overrides['email'] ) ? $overrides['email'] : '';
					$default_username   = isset( $overrides['email'] ) ? $overrides['email'] : strtolower( $profile['username'] );
					$default_first_name = ! empty( $profile['business_name'] ) ? $profile['business_name'] : ( isset( $profile['name'] ) ? $profile['name'] : '' );
					$default_last_name  = '';
					$default_image      = isset( $profile['profile_image'] ) ? $profile['profile_image'] : $result->deuimage;
					$this->loginpress_apply_provider_defaults( $result, 'pinterest', $default_username, $default_first_name, $default_last_name, $default_image );
					break;

				case 'reddit':
					$result->deuid      = isset( $profile['id'] ) ? $profile['id'] : '';
					$result->email      = isset( $overrides['email'] ) ? $overrides['email'] : '';
					$default_username   = isset( $overrides['email'] ) ? $overrides['email'] : strtolower( $profile['name'] );
					$default_first_name = ! empty( $profile['name'] ) ? $profile['name'] : ( isset( $profile['subreddit']['name'] ) ? $profile['subreddit']['name'] : '' );
					$default_last_name  = '';
					$default_image      = isset( $profile['icon_img'] ) ? $profile['icon_img'] : $result->deuimage;
					$this->loginpress_apply_provider_defaults( $result, 'reddit', $default_username, $default_first_name, $default_last_name, $default_image );
					break;

				case 'spotify':
					$result->deuid      = isset( $profile['id'] ) ? $profile['id'] : '';
					$result->email      = isset( $profile['email'] ) ? $profile['email'] : ( isset( $profile['display_name'] ) ? $profile['display_name'] . '@spotify.com' : '' );
					$default_username   = isset( $result->email ) ? $result->email : strtolower( $profile['display_name'] );
					$default_first_name = isset( $profile['display_name'] ) ? $profile['display_name'] : '';
					$default_last_name  = '';
					$default_image      = isset( $profile['images'][0]['url'] ) ? $profile['images'][0]['url'] : $result->deuimage;
					$this->loginpress_apply_provider_defaults( $result, 'spotify', $default_username, $default_first_name, $default_last_name, $default_image );
					break;

				case 'twitch':
					$result->deuid      = isset( $profile['data'][0]['id'] ) ? $profile['data'][0]['id'] : '';
					$result->email      = isset( $profile['data'][0]['email'] ) ? $profile['data'][0]['email'] : ( isset( $profile['display_name'] ) ? $profile['display_name'] . '@spotify.com' : '' );
					$default_username   = isset( $result->email ) ? $result->email : strtolower( $profile['data'][0]['display_name'] );
					$default_first_name = ! empty( $profile['data'][0]['display_name'] ) ? $profile['data'][0]['display_name'] : ( isset( $profile['data'][0]['login'] ) ? $profile['data'][0]['login'] : '' );
					$default_last_name  = '';
					$default_image      = isset( $profile['data'][0]['profile_image_url'] ) ? $profile['data'][0]['profile_image_url'] : $result->deuimage;
					$this->loginpress_apply_provider_defaults( $result, 'twitch', $default_username, $default_first_name, $default_last_name, $default_image );
					break;

				case 'discord':
					$result->deuid      = isset( $profile['id'] ) ? $profile['id'] : '';
					$result->email      = isset( $profile['email'] ) ? $profile['email'] : '';
					$default_username   = isset( $profile['email'] ) ? $profile['email'] : strtolower( $profile['username'] );
					$default_first_name = isset( $profile['global_name'] ) ? $profile['global_name'] : '';
					$default_last_name  = '';
					// Extract user details.
					$user_id       = $profile['id'];
					$avatar_hash   = isset( $profile['avatar'] ) ? $profile['avatar'] : '';
					$format        = ( is_string( $avatar_hash ) && strpos( $avatar_hash, 'a_' ) === 0 ) ? 'gif' : 'png';
					$avatar_url    = "https://cdn.discordapp.com/avatars/{$user_id}/{$avatar_hash}.{$format}";
					$default_image = $avatar_hash ? $avatar_url : '';
					$this->loginpress_apply_provider_defaults( $result, 'discord', $default_username, $default_first_name, $default_last_name, $default_image );
					break;

				case 'disqus':
					$result->deuid      = isset( $profile['response']['id'] ) ? $profile['response']['id'] : '';
					$result->email      = ( $profile['response']['username'] ?? '' ) . '@disqus.com';
					$default_username   = isset( $result->email ) ? $result->email : strtolower( $profile['response']['username'] );
					$default_first_name = isset( $profile['response']['name'] ) ? $profile['response']['name'] : '';
					$default_last_name  = '';
					$default_image      = $profile['response']['avatar']['permalink'] ?? $result->deuimage;
					$this->loginpress_apply_provider_defaults( $result, 'disqus', $default_username, $default_first_name, $default_last_name, $default_image );
					break;

				case 'apple':
					if ( is_object( $profile ) ) {
						$result->deuid      = isset( $profile->deuid ) ? $profile->deuid : '';
						$result->email      = isset( $profile->email ) ? $profile->email : '';
						$default_username   = isset( $profile->email ) ? $profile->email : $profile->username;
						$default_first_name = isset( $profile->first_name ) ? $profile->first_name : '';
						$default_last_name  = isset( $profile->last_name ) ? $profile->last_name : '';
						$this->loginpress_apply_provider_defaults( $result, 'apple', $default_username, $default_first_name, $default_last_name, '' );
					}
					break;
			}

			// Sanitize provider-sourced data before return (defense in depth).
			$result->deuid  = isset( $result->deuid ) ? sanitize_text_field( (string) $result->deuid ) : '';
			$result->email  = isset( $result->email ) ? sanitize_email( (string) $result->email ) : '';
			$result->gender = isset( $result->gender ) ? sanitize_text_field( (string) $result->gender ) : '';
			$result->url    = isset( $result->url ) ? esc_url_raw( (string) $result->url ) : '';
			$result->about  = isset( $result->about ) ? sanitize_text_field( (string) $result->about ) : '';
			if ( isset( $result->error_message ) ) {
				$result->error_message = sanitize_text_field( (string) $result->error_message );
			}

			return $result;
		}


		/**
		 * Function loginpress_is_eligible_social_domain to check whether email is eligible or not.
		 *
		 * @param mixed $email Full email address o user taken from social provider.
		 * @param mixed $eligible_domains List of partial eligible domains.
		 * @return bool $found If string is found or not.
		 * @since 3.0.0
		 */
		public function loginpress_is_eligible_social_domain( $email, $eligible_domains ) {
			$found = false;

			foreach ( $eligible_domains as $partial ) {
				if ( strpos( $email, $partial ) !== false ) {
					$found = true;
					break;
				}
			}
			return $found;
		}

		/**
		 * Show loginpress WordPress social login error/s.
		 *
		 * @param int    $user The User ID.
		 * @param string $username The Username.
		 * @param string $password The Password.
		 *
		 * @return WP_Error $error the Error.
		 * @since 5.0.2.
		 */
		public function loginpress_wp_social_login_error( $user, $username, $password ) { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter.FoundAfterLastUsed
			$error = new WP_Error();
			/**
			 * Filter the error message shown when WordPress.com email is not verified.
			 *
			 * @since 5.0.2
			 *
			 * @param string $message Default error message.
			 * @param string $username Entered username.
			 */
			$message = apply_filters(
				'loginpress_wp_social_login_unverified_email_message',
				sprintf(    /* Translators: The Error Message. */
					__( '%1$sERROR%2$s: Your WordPress.com account email is not verified. Please verify your email at WordPress.com before logging in.', 'loginpress-pro' ),
					'<strong>',
					'</strong>'
				),
				$username
			);

			$error->add( 'loginpress_social_login', $message );

			return $error;
		}

		/**
		 * Check if user is restricted from social login.
		 *
		 * @param WP_User|false $user_object User object.
		 * @return bool True if user is restricted.
		 * @since 6.0.0
		 */
		private function lp_is_user_restricted_from_sl( $user_object ) {
			/**
			 * Fires when a user is checked for social login restriction.
			 *
			 * This enables logging, notifications, or custom logic by site owners.
			 *
			 * @since 6.0.0
			 *
			 * @param WP_User $user_object The user object being checked.
			 */
			do_action( 'loginpress_before_social_login_restricted', $user_object );
			if ( ! $user_object || ! is_a( $user_object, 'WP_User' ) ) {
				return false;
			}

			// Check if user is super admin (multisite only).
			if ( is_multisite() && is_super_admin( $user_object->ID ) ) {
				return true;
			} elseif ( in_array( 'administrator', $user_object->roles, true ) ) {
				return true;
			}

			$is_restricted = false;
			/**
			 * Filters whether a user is restricted from using social login.
			 *
			 * Developers can use this filter to apply advanced restrictions,
			 * such as limiting by email domain, user meta, or other conditions.
			 *
			 * @since 6.0.0
			 *
			 * @param bool    $is_restricted Whether the user is restricted. Default false.
			 * @param WP_User $user_object   The user object being checked.
			 */
			$is_restricted = apply_filters(
				'loginpress_is_user_restricted_from_social_login',
				$is_restricted,
				$user_object
			);

			return $is_restricted;
		}

		/**
		 * Show social login restriction error.
		 *
		 * @return void
		 * @since 6.0.0
		 */
		private function lp_show_social_login_restriction_error() {
			wp_safe_redirect(
				add_query_arg(
					array(
						'lp_social_login_admin_error' => 'true',
						'lp_social_restricted'        => '1',
					),
					wp_login_url()
				)
			);
			exit;
		}

		/**
		 * Get a social login row by provider identifier.
		 *
		 * @param string $provider   Provider slug.
		 * @param string $identifier Provider user ID.
		 * @param string $sha_verifier SHA verifier string.
		 * @return object|null
		 * @since 6.2.4
		 */
		protected function loginpress_get_social_login_row_by_identifier( $provider, $identifier, $sha_verifier ) {
			global $wpdb;

			return $wpdb->get_row( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
				$wpdb->prepare(
					"SELECT user_id, identifier, email_verified FROM `{$wpdb->prefix}loginpress_social_login_details` WHERE `provider_name` = %s AND `identifier` = %s AND `sha_verifier` = %s LIMIT 1",
					sanitize_key( $provider ),
					(string) $identifier,
					$sha_verifier
				)
			);
		}

		/**
		 * Get a verified social login row for a WordPress user.
		 *
		 * @param int    $user_id    WordPress user ID.
		 * @param string $provider   Provider slug.
		 * @param string $identifier Optional provider user ID.
		 * @return object|null
		 * @since 6.2.4
		 */
		protected function loginpress_get_verified_social_login_row_by_user( $user_id, $provider, $identifier = '' ) {
			global $wpdb;

			if ( ! empty( $identifier ) ) {
				return $wpdb->get_row( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
					$wpdb->prepare(
						"SELECT user_id, identifier, email_verified FROM `{$wpdb->prefix}loginpress_social_login_details` WHERE `user_id` = %d AND `provider_name` = %s AND `email_verified` = %s AND `identifier` = %s LIMIT 1",
						absint( $user_id ),
						sanitize_key( $provider ),
						'1',
						(string) $identifier
					)
				);
			}

			return $wpdb->get_row( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
				$wpdb->prepare(
					"SELECT user_id, identifier, email_verified FROM `{$wpdb->prefix}loginpress_social_login_details` WHERE `user_id` = %d AND `provider_name` = %s AND `email_verified` = %s LIMIT 1",
					absint( $user_id ),
					sanitize_key( $provider ),
					'1'
				)
			);
		}

		/**
		 * Whether a social login row has confirmed email ownership.
		 *
		 * @param object|null $row Social login row.
		 * @return bool
		 * @since 6.2.4
		 */
		protected function loginpress_is_social_email_verified( $row ) {
			return is_object( $row ) && isset( $row->email_verified ) && '1' === (string) $row->email_verified;
		}

		/**
		 * Complete Spotify login redirect for a user.
		 *
		 * @param WP_User                     $user_object          User object.
		 * @param LoginPress_Social_Utilities $loginpress_utilities Utilities instance.
		 * @param string                      $role                 Default site role.
		 * @return void
		 * @since 6.2.4
		 */
		protected function loginpress_complete_spotify_login( $user_object, $loginpress_utilities, $role ) {
			if ( 'subscriber' === $role ) {
				$loginpress_utilities->_home_url( $user_object, 'success_spotify', 'subscriber' );
			}

			$loginpress_utilities->_home_url( $user_object, 'success_spotify' );
		}

		/**
		 * Perform a safe redirect to the login URL with the given query args and halt execution.
		 *
		 * @param array $args Query args to append to the login URL.
		 * @return void
		 * @since 6.2.4
		 */
		private function loginpress_spotify_redirect( array $args ) {
			wp_safe_redirect( add_query_arg( $args, wp_login_url() ) );
			exit;
		}

		/**
		 * Redirect when Spotify does not return a usable email address.
		 *
		 * @return void
		 * @since 6.2.4
		 */
		protected function loginpress_redirect_spotify_no_email() {
			$this->loginpress_spotify_redirect( array( 'lp_social_error' => 'spotify' ) );
		}

		/**
		 * Redirect after a Spotify email verification message has been sent.
		 *
		 * @return void
		 * @since 6.2.4
		 */
		protected function loginpress_redirect_spotify_email_pending() {
			$this->loginpress_spotify_redirect( array( 'lp_social_pending' => 'spotify' ) );
		}

		/**
		 * Send a Spotify email verification request.
		 *
		 * @param string $type    Verification type (social_link|social_register).
		 * @param string $email   Email address.
		 * @param int    $user_id WordPress user ID for link requests.
		 * @param object $result  Social login result object.
		 * @return void
		 * @since 6.2.4
		 */
		protected function loginpress_request_spotify_email_verification( $type, $email, $user_id, $result ) {
			if ( ! class_exists( 'LoginPress_Email_Verification' ) ) {
				$this->loginpress_redirect_spotify_no_email();
			}

			$sent = LoginPress_Email_Verification::instance()->loginpress_email_verification_create_and_send(
				array(
					'type'     => $type,
					'email'    => $email,
					'user_id'  => absint( $user_id ),
					'provider' => 'spotify',
					'payload'  => LoginPress_Social_Email_Verification::loginpress_social_result_object_to_payload( $result ),
				)
			);

			if ( is_wp_error( $sent ) ) {
				$this->loginpress_redirect_spotify_no_email();
			}

			$this->loginpress_redirect_spotify_email_pending();
		}
	}
}
$loginpress_login_check = new LoginPress_Social_Login_Check();
