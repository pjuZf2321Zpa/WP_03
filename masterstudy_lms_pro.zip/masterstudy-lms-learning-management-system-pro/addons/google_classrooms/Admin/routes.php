<?php

/** @var \MasterStudy\Lms\Routing\Router $router */

use MasterStudy\Lms\Routing\Router;

$router->group(
	array(
		'middleware' => array(
			\MasterStudy\Lms\Routing\Middleware\Authentication::class,
			\MasterStudy\Lms\Routing\Middleware\Administrator::class,
		),
	),
	function ( Router $router ) {
		$router->get(
			'/google-classrooms-import/bootstrap',
			\MasterStudy\Lms\Pro\addons\google_classrooms\Admin\Http\Controllers\GetGoogleClassroomsImportBootstrapController::class
		);

		$router->get(
			'/google-classrooms-import/settings-fragment',
			\MasterStudy\Lms\Pro\addons\google_classrooms\Admin\Http\Controllers\GetGoogleClassroomsSettingsFragmentController::class
		);

		$router->post(
			'/google-classrooms-import/credentials',
			\MasterStudy\Lms\Pro\addons\google_classrooms\Admin\Http\Controllers\UploadGoogleClassroomsCredentialsController::class
		);

		$router->post(
			'/google-classrooms-import/token/revoke',
			\MasterStudy\Lms\Pro\addons\google_classrooms\Admin\Http\Controllers\RevokeGoogleClassroomsTokenController::class
		);

		$router->post(
			'/google-classrooms-import/credentials/delete',
			\MasterStudy\Lms\Pro\addons\google_classrooms\Admin\Http\Controllers\DeleteGoogleClassroomsCredentialsController::class
		);

		$router->post(
			'/google-classrooms-import/archive-page',
			\MasterStudy\Lms\Pro\addons\google_classrooms\Admin\Http\Controllers\CreateGoogleClassroomsArchivePageController::class
		);

		$router->get(
			'/google-classrooms-import/classrooms',
			\MasterStudy\Lms\Pro\addons\google_classrooms\Admin\Http\Controllers\GetGoogleClassroomsImportClassroomsController::class
		);

		$router->post(
			'/google-classrooms-import/classrooms/(?P<google_id>\d+)/import',
			\MasterStudy\Lms\Pro\addons\google_classrooms\Admin\Http\Controllers\ImportGoogleClassroomController::class
		);

		$router->post(
			'/google-classrooms-import/classrooms/(?P<google_id>\d+)/publish',
			\MasterStudy\Lms\Pro\addons\google_classrooms\Admin\Http\Controllers\PublishGoogleClassroomController::class
		);

	}
);

$router->group(
	array(
		'middleware' => array(
			\MasterStudy\Lms\Routing\Middleware\Authentication::class,
			\MasterStudy\Lms\Routing\Middleware\AdminOrInstructor::class,
		),
	),
	function ( Router $router ) {
		$router->get(
			'/classrooms',
			\MasterStudy\Lms\Pro\addons\google_classrooms\Admin\Http\Controllers\GetClassroomsController::class
		);

		$router->post(
			'/classrooms',
			\MasterStudy\Lms\Pro\addons\google_classrooms\Admin\Http\Controllers\CreateClassroomController::class
		);

		$router->put(
			'/classrooms/(?P<id>\d+)',
			\MasterStudy\Lms\Pro\addons\google_classrooms\Admin\Http\Controllers\UpdateClassroomController::class
		);

		$router->delete(
			'/classrooms/(?P<id>\d+)',
			\MasterStudy\Lms\Pro\addons\google_classrooms\Admin\Http\Controllers\DeleteClassroomController::class
		);

		$router->post(
			'/classrooms/bulk-delete',
			\MasterStudy\Lms\Pro\addons\google_classrooms\Admin\Http\Controllers\BulkDeleteClassroomsController::class
		);

		$router->get(
			'/classroom-auditory',
			\MasterStudy\Lms\Pro\addons\google_classrooms\Admin\Http\Controllers\GetAuditoriesController::class
		);

		$router->post(
			'/classroom-auditory',
			\MasterStudy\Lms\Pro\addons\google_classrooms\Admin\Http\Controllers\CreateAuditoryController::class
		);

		$router->put(
			'/classroom-auditory/(?P<id>\d+)',
			\MasterStudy\Lms\Pro\addons\google_classrooms\Admin\Http\Controllers\UpdateAuditoryController::class
		);

		$router->delete(
			'/classroom-auditory/(?P<id>\d+)',
			\MasterStudy\Lms\Pro\addons\google_classrooms\Admin\Http\Controllers\DeleteAuditoryController::class
		);

		$router->post(
			'/classroom-auditory/bulk-delete',
			\MasterStudy\Lms\Pro\addons\google_classrooms\Admin\Http\Controllers\BulkDeleteAuditoriesController::class
		);

		$router->get(
			'/classroom-auditory/(?P<id>\d+)/users',
			\MasterStudy\Lms\Pro\addons\google_classrooms\Admin\Http\Controllers\GetAuditoryUsersController::class
		);
	}
);
