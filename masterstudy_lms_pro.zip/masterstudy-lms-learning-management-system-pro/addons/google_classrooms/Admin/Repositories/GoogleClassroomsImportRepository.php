<?php

namespace MasterStudy\Lms\Pro\addons\google_classrooms\Admin\Repositories;

use RuntimeException;

final class GoogleClassroomsImportRepository {
	private const TRANSIENT_PREFIX = 'stm_lms_google_classroom_course_';
	private const UPDATEABLE_META  = array(
		'auditory',
		'ownerId',
		'code',
		'alternateLink',
		'courseState',
		'teacherGroupEmail',
		'courseGroupEmail',
		'calendarId',
		'courseMaterialSets',
		'section',
	);

	/**
	 * @var \STM_LMS_Google_Classroom
	 */
	private $google_classroom;

	public function __construct() {
		$this->google_classroom = \STM_LMS_Google_Classroom::getInstance();
	}

	public function get_bootstrap(): array {
		$has_credentials = $this->google_classroom->has_auth_config();
		$has_token       = $this->google_classroom->has_auth_token();

		return array(
			'has_credentials' => $has_credentials,
			'has_token'       => $has_token,
			'authorize_url'   => $has_credentials && ! $has_token ? (string) $this->google_classroom->get_auth_url() : '',
			'can_manage'      => current_user_can( 'manage_options' ),
			'redirect_url'    => $this->google_classroom->get_admin_page_url(),
			'step'            => $has_token ? 'import_classrooms' : ( $has_credentials ? 'authorize_google' : 'upload_credentials' ),
		);
	}

	public function upload_credentials( array $file ): array {
		$result = $this->google_classroom->store_credentials_file( $file );

		if ( is_wp_error( $result ) ) {
			throw new RuntimeException( $result->get_error_message(), 400 );
		}

		return $this->get_bootstrap();
	}

	public function revoke_token(): array {
		$this->google_classroom->revoke_token();

		return $this->get_bootstrap();
	}

	public function delete_credentials(): array {
		$this->google_classroom->revoke_token();
		$this->google_classroom->revoke_config();

		return $this->get_bootstrap();
	}

	public function create_or_get_archive_page(): array {
		$page_meta = stm_lms_g_c_page_find();
		$page_id   = 0;

		if ( empty( $page_meta ) ) {
			$page_id = wp_insert_post(
				array(
					'post_content' => '[stm_lms_google_classroom title="Classrooms" number="8"]',
					'post_title'   => 'Google Classrooms',
					'post_type'    => 'page',
					'post_status'  => 'publish',
				),
				true
			);

			if ( is_wp_error( $page_id ) ) {
				throw new RuntimeException( $page_id->get_error_message(), 400 );
			}

			update_post_meta( $page_id, 'stm_lms_google_classroom_page', 'page' );
			update_post_meta( $page_id, '_wpb_vc_js_status', true );
		} else {
			$page_meta = \STM_LMS_Helpers::simplify_db_array( $page_meta );
			$page_id   = (int) ( $page_meta['post_id'] ?? 0 );
		}

		if ( empty( $page_id ) ) {
			throw new RuntimeException(
				esc_html__( 'Unable to resolve the Google Classrooms archive page.', 'masterstudy-lms-learning-management-system-pro' ),
				400
			);
		}

		return array(
			'page_id'        => $page_id,
			'title'          => (string) get_the_title( $page_id ),
			'url'            => (string) get_permalink( $page_id ),
			'edit_post_link' => (string) get_edit_post_link( $page_id, 'normal' ),
		);
	}

	public function get_classrooms( string $search = '' ): array {
		$data = $this->google_classroom->get_raw_courses();

		if ( ! empty( $data['error'] ) ) {
			throw new RuntimeException( (string) $data['error'], 400 );
		}

		$courses        = $data['courses'] ?? array();
		$imported_posts = $this->google_classroom->get_posts_by_google_ids(
			array_map(
				static function ( array $course ): int {
					return (int) ( $course['course_id'] ?? 0 );
				},
				$courses
			)
		);
		$items          = array_map(
			function ( array $course ) use ( $imported_posts ): array {
				return $this->map_classroom_item( $course, $imported_posts );
			},
			$courses
		);

		if ( '' !== $search ) {
			$items = array_values(
				array_filter(
					$items,
					static function ( array $item ) use ( $search ) {
						return false !== stripos( $item['name'], $search );
					}
				)
			);
		}

		return array(
			'items' => $items,
			'total' => count( $items ),
		);
	}

	public function import_classroom( int $google_id ): array {
		$course = $this->get_google_course( $google_id );

		$imported_course_id = \STM_LMS_Google_Classroom::imported_course_id( $course );

		do_action( 'stm_lms_google_classroom_course_imported', $course, $imported_course_id );

		foreach ( self::UPDATEABLE_META as $meta_key ) {
			if ( isset( $course[ $meta_key ] ) ) {
				update_post_meta( $imported_course_id, $meta_key, $course[ $meta_key ] );
			}
		}

		return array(
			'item' => $this->build_item_from_post( $google_id, $course, $imported_course_id ),
		);
	}

	public function publish_classroom( int $google_id ): array {
		$course   = $this->get_google_course( $google_id );
		$post_id  = (int) $this->google_classroom->get_post_by_google_id( $google_id );
		$post_arr = array(
			'ID'          => $post_id,
			'post_status' => 'publish',
		);

		if ( empty( $post_id ) ) {
			throw new RuntimeException(
				esc_html__( 'This classroom has not been imported yet.', 'masterstudy-lms-learning-management-system-pro' ),
				400
			);
		}

		if ( ! empty( $course['creationTime'] ) ) {
			$post_arr['post_date'] = $course['creationTime'];
		}

		$result = wp_update_post( $post_arr, true );

		if ( is_wp_error( $result ) ) {
			throw new RuntimeException( $result->get_error_message(), 400 );
		}

		return array(
			'item' => $this->build_item_from_post( $google_id, $course, $post_id ),
		);
	}

	private function get_google_course( int $google_id ): array {
		$course = get_transient( self::TRANSIENT_PREFIX . $google_id );

		if ( ! empty( $course ) ) {
			return $course;
		}

		$data = $this->google_classroom->get_raw_courses();

		foreach ( $data['courses'] ?? array() as $item ) {
			if ( (int) ( $item['course_id'] ?? 0 ) === $google_id ) {
				return $item;
			}
		}

		throw new RuntimeException(
			esc_html__( 'Google Classroom data is missing. Please refresh the list and try again.', 'masterstudy-lms-learning-management-system-pro' ),
			400
		);
	}

	private function map_classroom_item( array $course, array $imported_posts ): array {
		$post_id = (int) ( $imported_posts[ (int) ( $course['course_id'] ?? 0 ) ] ?? 0 );

		if ( ! empty( $post_id ) ) {
			return $this->build_item_from_post( (int) $course['course_id'], $course, $post_id );
		}

		return array(
			'google_id'    => (int) $course['course_id'],
			'name'         => wp_strip_all_tags( (string) ( $course['name'] ?? '' ) ),
			'auditory'     => wp_strip_all_tags( (string) ( $course['auditory'] ?? '' ) ),
			'status'       => 'not_imported',
			'status_label' => esc_html__( 'Not Imported Yet', 'masterstudy-lms-learning-management-system-pro' ),
			'is_imported'  => false,
			'can_publish'  => false,
			'preview_url'  => '',
			'edit_url'     => '',
		);
	}

	private function build_item_from_post( int $google_id, array $course, int $post_id ): array {
		$status        = (string) get_post_status( $post_id );
		$status_object = get_post_status_object( $status );

		return array(
			'google_id'    => $google_id,
			'name'         => wp_strip_all_tags( (string) ( $course['name'] ?? get_the_title( $post_id ) ) ),
			'auditory'     => wp_strip_all_tags( (string) ( $course['auditory'] ?? '' ) ),
			'status'       => $status,
			'status_label' => ! empty( $status_object->label ) ? (string) $status_object->label : ucfirst( $status ),
			'is_imported'  => true,
			'can_publish'  => 'draft' === $status,
			'preview_url'  => (string) get_permalink( $post_id ),
			'edit_url'     => (string) get_edit_post_link( $post_id, 'normal' ),
		);
	}
}
