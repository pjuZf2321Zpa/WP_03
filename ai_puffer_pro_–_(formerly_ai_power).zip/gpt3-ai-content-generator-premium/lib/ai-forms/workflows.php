<?php

namespace WPAICG\Addons\AIFormsWorkflows;

use WPAICG\AIForms\Admin\AIPKit_AI_Form_Admin_Setup;
use WPAICG\AIForms\Admin\AIPKit_AI_Form_Settings_Ajax_Handler;
use WPAICG\AIForms\Storage\AIPKit_AI_Form_Storage;

if (!defined('ABSPATH')) {
    exit;
}

class AIPKit_AI_Forms_Workflows
{
    private const META_KEY = '_aipkit_ai_form_workflow_config';
    private const MAX_NODES = 25;
    private const MAX_EDGES = 50;

    public static function register_hooks(): void
    {
        add_action('aipkit_ai_forms_editor_left_accordion_after_multistep', [self::class, 'render_editor_panel'], 10, 2);
        add_filter('aipkit_ai_forms_allow_workflow_config_save', [self::class, 'allow_workflow_config_save'], 10, 3);
        add_filter('aipkit_ai_forms_sanitize_save_settings', [self::class, 'sanitize_save_settings'], 10, 3);
        add_action('aipkit_ai_forms_after_save_form_settings', [self::class, 'save_workflow_settings'], 10, 3);
        add_filter('aipkit_ai_forms_get_form_data', [self::class, 'append_workflow_data'], 10, 3);
        add_filter('aipkit_ai_forms_after_delete_form_messages', [self::class, 'cleanup_deleted_form_references'], 10, 3);
        add_filter('aipkit_ai_forms_prepare_form_export_data', [self::class, 'prepare_export_data'], 10, 2);
        add_filter('aipkit_ai_forms_import_form_settings_before_create', [self::class, 'strip_workflow_config_before_import_create'], 10, 4);
        add_filter('aipkit_ai_forms_import_result_messages', [self::class, 'restore_imported_workflow_links'], 10, 4);
        add_filter('aipkit_ai_forms_list_forms_data', [self::class, 'append_list_workflow_data'], 10, 3);
        add_filter('aipkit_ai_forms_frontend_wrapper_attributes', [self::class, 'frontend_wrapper_attributes'], 10, 2);
        add_action('aipkit_ai_forms_frontend_after_results', [self::class, 'render_frontend_workflow_slot'], 10, 1);
        add_action('wp_ajax_aipkit_ai_form_render_workflow_form', [self::class, 'ajax_render_workflow_form']);
        add_action('wp_ajax_nopriv_aipkit_ai_form_render_workflow_form', [self::class, 'ajax_render_workflow_form']);
    }

    public static function allow_workflow_config_save(bool $allowed, array $post_data, ?int $form_id): bool
    {
        return $allowed || self::is_pro_plan();
    }

    public static function render_editor_panel(bool $is_pro, string $upgrade_url = ''): void
    {
        if (!$is_pro) {
            ?>
            <div class="aipkit_accordion aipkit_ai_forms_workflow_accordion">
                <div class="aipkit_accordion-header">
                    <?php esc_html_e('Workflow', 'gpt3-ai-content-generator'); ?>
                    <a
                        href="<?php echo esc_url($upgrade_url); ?>"
                        target="_blank"
                        rel="noopener noreferrer"
                        class="aipkit_pro_tag aipkit_pro_badge"
                        onclick="event.stopPropagation();"
                    ><?php esc_html_e('Pro', 'gpt3-ai-content-generator'); ?></a>
                </div>
                <div class="aipkit_accordion-content">
                    <div class="aipkit_popover_options_list aipkit_ai_forms_workflow_panel_body">
                        <div class="aipkit_popover_option_row aipkit_ai_form_multistep_upgrade_notice">
                            <div class="aipkit_popover_option_main aipkit_popover_option_main--stacked aipkit_ai_form_multistep_upgrade_inner">
                                <div class="aipkit_ai_form_multistep_upgrade_copy">
                                    <span class="aipkit_popover_option_label"><?php esc_html_e('Connect AI Forms into guided workflows.', 'gpt3-ai-content-generator'); ?></span>
                                    <p class="aipkit_form-help"><?php esc_html_e('Send AI output and submitted answers into the next form, with conditional routes.', 'gpt3-ai-content-generator'); ?></p>
                                </div>
                                <a class="aipkit_btn aipkit_ai_form_upgrade_btn aipkit_pro_upgrade_button" href="<?php echo esc_url($upgrade_url); ?>" target="_blank" rel="noopener noreferrer">
                                    <?php esc_html_e('Upgrade', 'gpt3-ai-content-generator'); ?>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php
            return;
        }

        $default_config_json = wp_json_encode(self::get_default_config(), JSON_UNESCAPED_SLASHES);
        if (!is_string($default_config_json) || $default_config_json === '') {
            $default_config_json = '{"version":1,"enabled":false,"auto_submit":false,"next_form_id":0,"routes":[],"mappings":[],"nodes":[],"edges":[]}';
        }
        $available_forms = self::get_available_forms();
        ?>
        <div class="aipkit_accordion aipkit_ai_forms_workflow_accordion" data-aipkit-ai-forms-workflow-panel>
            <div class="aipkit_accordion-header">
                <?php esc_html_e('Workflow', 'gpt3-ai-content-generator'); ?>
            </div>
            <div class="aipkit_accordion-content">
                <div class="aipkit_popover_options_list aipkit_ai_forms_workflow_panel_body">
                    <div class="aipkit_popover_option_row">
                        <div class="aipkit_popover_option_main aipkit_ai_forms_workflow_toggle_row">
                            <span class="aipkit_popover_option_label"><?php esc_html_e('Enable Workflow', 'gpt3-ai-content-generator'); ?></span>
                            <div class="aipkit_popover_option_actions">
                                <label class="aipkit_switch" for="aipkit_ai_form_workflow_enabled">
                                    <input type="checkbox" id="aipkit_ai_form_workflow_enabled" class="aipkit_toggle_switch">
                                    <span class="aipkit_switch_slider"></span>
                                </label>
                            </div>
                        </div>
                    </div>
                    <div class="aipkit_popover_option_row aipkit_ai_forms_workflow_next_form_group">
                        <div class="aipkit_popover_option_main aipkit_popover_option_main--stacked">
                            <label class="aipkit_popover_option_label" for="aipkit_ai_form_workflow_next_form_id">
                                <?php esc_html_e('Next AI Form', 'gpt3-ai-content-generator'); ?>
                            </label>
                            <select id="aipkit_ai_form_workflow_next_form_id" class="aipkit_popover_option_select">
                                <option value=""><?php esc_html_e('No next form', 'gpt3-ai-content-generator'); ?></option>
                                <?php foreach ($available_forms as $available_form): ?>
                                    <option
                                        value="<?php echo esc_attr((string) $available_form['id']); ?>"
                                        data-form-title="<?php echo esc_attr($available_form['title']); ?>"
                                    >
                                        <?php echo esc_html($available_form['title']); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                    <div class="aipkit_popover_option_row aipkit_ai_forms_workflow_mapping_group">
                        <div class="aipkit_popover_option_main aipkit_popover_option_main--stacked">
                            <label class="aipkit_popover_option_label" for="aipkit_ai_form_workflow_ai_output_target_field">
                                <?php esc_html_e('Send AI output to', 'gpt3-ai-content-generator'); ?>
                            </label>
                            <select id="aipkit_ai_form_workflow_ai_output_target_field" class="aipkit_popover_option_select" disabled>
                                <option value=""><?php esc_html_e('Do not prefill', 'gpt3-ai-content-generator'); ?></option>
                            </select>
                        </div>
                    </div>
                    <div class="aipkit_popover_option_row aipkit_ai_forms_workflow_field_mappings_group">
                        <div class="aipkit_ai_forms_workflow_mapping_header">
                            <span class="aipkit_popover_option_label"><?php esc_html_e('Map submitted answers', 'gpt3-ai-content-generator'); ?></span>
                            <button type="button" id="aipkit_ai_form_workflow_add_mapping" class="aipkit_btn aipkit_btn-secondary aipkit_btn-small">
                                <?php esc_html_e('Add Mapping', 'gpt3-ai-content-generator'); ?>
                            </button>
                        </div>
                        <div class="aipkit_ai_forms_workflow_field_mappings" data-aipkit-workflow-field-mappings></div>
                    </div>
                    <div class="aipkit_popover_option_row aipkit_ai_forms_workflow_routes_group">
                        <div class="aipkit_ai_forms_workflow_mapping_header">
                            <span class="aipkit_popover_option_label"><?php esc_html_e('Conditional routes', 'gpt3-ai-content-generator'); ?></span>
                            <button type="button" id="aipkit_ai_form_workflow_add_route" class="aipkit_btn aipkit_btn-secondary aipkit_btn-small">
                                <?php esc_html_e('Add Route', 'gpt3-ai-content-generator'); ?>
                            </button>
                        </div>
                        <div class="aipkit_ai_forms_workflow_routes" data-aipkit-workflow-routes></div>
                    </div>
                    <div class="aipkit_popover_option_row aipkit_ai_forms_workflow_auto_submit_group">
                        <div class="aipkit_popover_option_main aipkit_ai_forms_workflow_toggle_row">
                            <span class="aipkit_popover_option_label"><?php esc_html_e('Auto-submit next form', 'gpt3-ai-content-generator'); ?></span>
                            <div class="aipkit_popover_option_actions">
                                <label class="aipkit_switch" for="aipkit_ai_form_workflow_auto_submit">
                                    <input type="checkbox" id="aipkit_ai_form_workflow_auto_submit" class="aipkit_toggle_switch">
                                    <span class="aipkit_switch_slider"></span>
                                </label>
                            </div>
                        </div>
                    </div>
                    <div class="aipkit_popover_option_row aipkit_ai_forms_workflow_summary_group">
                        <div class="aipkit_ai_forms_workflow_summary" data-aipkit-workflow-summary>
                            <div class="aipkit_ai_forms_workflow_summary_header">
                                <span class="aipkit_popover_option_label"><?php esc_html_e('Workflow Summary', 'gpt3-ai-content-generator'); ?></span>
                            </div>
                            <div class="aipkit_ai_forms_workflow_summary_body" data-aipkit-workflow-summary-body></div>
                        </div>
                    </div>
                    <input
                        type="hidden"
                        id="aipkit_ai_form_workflow_config"
                        name="workflow_config"
                        value="<?php echo esc_attr($default_config_json); ?>"
                    >
                    <script type="application/json" id="aipkit_ai_form_workflow_forms_index"><?php echo wp_json_encode($available_forms, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_UNESCAPED_SLASHES); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- JSON script data encoded for safe embedding. ?></script>
                </div>
            </div>
        </div>
        <?php
    }

    public static function sanitize_save_settings(array $settings, array $post_data, ?int $form_id): array
    {
        if (!self::is_pro_plan() || !array_key_exists('workflow_config', $post_data)) {
            return $settings;
        }

        $current_form_id = !empty($form_id) ? absint($form_id) : 0;
        $config = self::sanitize_config($post_data['workflow_config'], $current_form_id);
        if ($current_form_id > 0) {
            if (absint($config['next_form_id'] ?? 0) === $current_form_id) {
                $config['next_form_id'] = 0;
            }
            $config['routes'] = array_values(array_filter(
                $config['routes'] ?? [],
                static fn ($route): bool => absint($route['next_form_id'] ?? 0) !== $current_form_id
            ));
            if (!self::has_workflow_target($config)) {
                $config['mappings'] = [];
                $config['nodes'] = [];
                $config['edges'] = [];
            }
        }
        $settings['workflow_config'] = $config;
        return $settings;
    }

    public static function save_workflow_settings(int $form_id, array $settings, $storage_instance = null): void
    {
        if (!self::is_pro_plan() || !isset($settings['workflow_config']) || !is_array($settings['workflow_config'])) {
            return;
        }

        update_post_meta(
            $form_id,
            self::META_KEY,
            wp_json_encode($settings['workflow_config'], JSON_UNESCAPED_SLASHES)
        );
    }

    public static function append_workflow_data(array $data, int $form_id, $storage_instance = null): array
    {
        if (!self::is_pro_plan()) {
            return $data;
        }

        $data['workflow_config'] = self::get_config($form_id);
        return $data;
    }

    public static function cleanup_deleted_form_references(array $messages, int $deleted_form_id, $storage_instance = null): array
    {
        if (!self::is_pro_plan() || $deleted_form_id <= 0) {
            return $messages;
        }

        $updated_count = 0;
        foreach (self::get_all_form_ids() as $form_id) {
            if ($form_id === $deleted_form_id) {
                continue;
            }

            $raw_config = self::decode_config(get_post_meta($form_id, self::META_KEY, true));
            if (empty($raw_config)) {
                continue;
            }

            $cleaned_config = self::remove_form_references_from_config($raw_config, $deleted_form_id);
            if (wp_json_encode($cleaned_config) === wp_json_encode($raw_config)) {
                continue;
            }

            $sanitized_config = self::sanitize_config($cleaned_config, $form_id);
            if (!self::has_workflow_target($sanitized_config)) {
                $sanitized_config['enabled'] = false;
                $sanitized_config['mappings'] = [];
                $sanitized_config['nodes'] = [];
                $sanitized_config['edges'] = [];
            }

            update_post_meta($form_id, self::META_KEY, wp_json_encode($sanitized_config, JSON_UNESCAPED_SLASHES));
            $updated_count++;
        }

        if ($updated_count > 0) {
            $messages[] = sprintf(
                /* translators: %d is the number of workflow forms updated after deleting a connected form. */
                _n('%d workflow connection was updated.', '%d workflow connections were updated.', $updated_count, 'gpt3-ai-content-generator'),
                $updated_count
            );
        }

        return $messages;
    }

    public static function prepare_export_data(array $form_data, array $context): array
    {
        if (!self::is_pro_plan()) {
            return $form_data;
        }

        $scope = sanitize_key((string) ($context['scope'] ?? 'single'));
        if (!in_array($scope, ['all', 'selected'], true)) {
            unset($form_data['workflow_config']);
            return $form_data;
        }

        $form_id = absint($context['form_id'] ?? ($form_data['id'] ?? 0));
        if ($form_id <= 0) {
            return $form_data;
        }

        $exported_ids = array_map('absint', is_array($context['form_ids'] ?? null) ? $context['form_ids'] : []);
        $form_data['_aipkit_export_key'] = self::build_export_key($form_id);

        if (isset($form_data['workflow_config'])) {
            $workflow_config = self::add_export_keys_to_config($form_data['workflow_config'], $exported_ids);
            if (self::config_has_export_keys($workflow_config)) {
                $form_data['workflow_config'] = $workflow_config;
            } else {
                unset($form_data['workflow_config']);
            }
        }

        return $form_data;
    }

    public static function strip_workflow_config_before_import_create(array $settings, array $form_data, array $forms_to_import, $form_storage = null): array
    {
        unset($settings['workflow_config']);
        return $settings;
    }

    public static function restore_imported_workflow_links(array $messages, array $imported_records, array $forms_to_import, $form_storage = null): array
    {
        if (!self::is_pro_plan() || empty($imported_records)) {
            return $messages;
        }

        $key_to_new_id = [];
        foreach ($imported_records as $record) {
            if (!is_array($record) || empty($record['source']) || !is_array($record['source'])) {
                continue;
            }
            $source = $record['source'];
            $export_key = self::sanitize_export_key($source['_aipkit_export_key'] ?? '');
            $new_id = absint($record['new_id'] ?? 0);
            if ($export_key !== '' && $new_id > 0) {
                $key_to_new_id[$export_key] = $new_id;
            }
        }

        if (empty($key_to_new_id)) {
            return $messages;
        }

        $restored_count = 0;
        $skipped_count = 0;
        foreach ($imported_records as $record) {
            if (!is_array($record) || empty($record['source']) || !is_array($record['source'])) {
                continue;
            }

            $new_id = absint($record['new_id'] ?? 0);
            $source = $record['source'];
            if ($new_id <= 0 || !isset($source['workflow_config'])) {
                continue;
            }
            if (!self::config_has_export_keys($source['workflow_config'])) {
                continue;
            }

            $remapped_config = self::remap_imported_workflow_config($source['workflow_config'], $key_to_new_id);
            $sanitized_config = self::sanitize_config($remapped_config, $new_id);
            if (!self::has_workflow_target($sanitized_config)) {
                $skipped_count++;
                continue;
            }

            update_post_meta($new_id, self::META_KEY, wp_json_encode($sanitized_config, JSON_UNESCAPED_SLASHES));
            $restored_count++;
        }

        if ($restored_count > 0) {
            $messages[] = sprintf(
                /* translators: %d is the number of workflow links restored after import. */
                _n('%d workflow link was restored.', '%d workflow links were restored.', $restored_count, 'gpt3-ai-content-generator'),
                $restored_count
            );
        }
        if ($skipped_count > 0) {
            $messages[] = sprintf(
                /* translators: %d is the number of workflow links skipped after import. */
                _n('%d workflow link was skipped because its target was not in the import file.', '%d workflow links were skipped because their targets were not in the import file.', $skipped_count, 'gpt3-ai-content-generator'),
                $skipped_count
            );
        }

        return $messages;
    }

    public static function append_list_workflow_data(array $forms_data, array $post_ids, $storage_instance = null): array
    {
        if (!self::is_pro_plan() || empty($forms_data)) {
            return $forms_data;
        }

        $stats = self::build_workflow_list_stats();
        foreach ($forms_data as &$form_data) {
            $form_id = absint($form_data['id'] ?? 0);
            if ($form_id <= 0 || !isset($stats[$form_id])) {
                continue;
            }
            $form_data['workflow'] = $stats[$form_id];
        }
        unset($form_data);

        return $forms_data;
    }

    public static function frontend_wrapper_attributes(string $attributes, array $form_data): string
    {
        if (!self::is_pro_plan()) {
            return $attributes;
        }

        $config = isset($form_data['workflow_config'])
            ? self::sanitize_config($form_data['workflow_config'], absint($form_data['id'] ?? 0))
            : self::get_default_config();
        $next_form_id = self::get_next_form_id_from_config($config);
        if (empty($config['enabled']) || !self::has_workflow_target($config)) {
            return $attributes;
        }

        $attributes .= ' data-aipkit-workflow-enabled="1"';
        if (!empty($config['auto_submit'])) {
            $attributes .= ' data-aipkit-workflow-auto-submit="1"';
        }
        $attributes .= ' data-aipkit-workflow-next-form-id="' . esc_attr((string) $next_form_id) . '"'
            . ' data-aipkit-workflow-routes="' . esc_attr(wp_json_encode($config['routes'] ?? [], JSON_UNESCAPED_SLASHES)) . '"'
            . ' data-aipkit-workflow-mappings="' . esc_attr(wp_json_encode($config['mappings'] ?? [], JSON_UNESCAPED_SLASHES)) . '"';

        return $attributes;
    }

    public static function render_frontend_workflow_slot(array $form_data): void
    {
        if (!self::is_pro_plan()) {
            return;
        }

        $config = isset($form_data['workflow_config'])
            ? self::sanitize_config($form_data['workflow_config'], absint($form_data['id'] ?? 0))
            : self::get_default_config();
        $next_form_id = self::get_primary_workflow_target_id($config);
        if (empty($config['enabled']) || $next_form_id <= 0) {
            return;
        }
        ?>
        <div
            class="aipkit-ai-form-workflow-next"
            data-aipkit-workflow-next-container
            data-aipkit-workflow-source-form-id="<?php echo esc_attr((string) ($form_data['id'] ?? 0)); ?>"
            data-aipkit-workflow-target-form-id="<?php echo esc_attr((string) $next_form_id); ?>"
            hidden
        ></div>
        <?php
    }

    public static function ajax_render_workflow_form(): void
    {
        if (!self::is_pro_plan()) {
            wp_send_json_error(['message' => __('AI Form workflows require a Pro plan.', 'gpt3-ai-content-generator')], 403);
        }

        check_ajax_referer('aipkit_frontend_chat_nonce', '_ajax_nonce');

        // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Verified above.
        $post_data = wp_unslash($_POST);
        $source_form_id = isset($post_data['source_form_id']) ? absint($post_data['source_form_id']) : 0;
        $target_form_id = isset($post_data['target_form_id']) ? absint($post_data['target_form_id']) : 0;

        if ($source_form_id <= 0 || $target_form_id <= 0 || $source_form_id === $target_form_id) {
            wp_send_json_error(['message' => __('Invalid workflow form target.', 'gpt3-ai-content-generator')], 400);
        }

        $source_config = self::get_config($source_form_id);
        if (empty($source_config['enabled']) || !self::is_workflow_target_allowed($source_config, $target_form_id)) {
            wp_send_json_error(['message' => __('This workflow step is not available.', 'gpt3-ai-content-generator')], 403);
        }

        if (!class_exists(AIPKit_AI_Form_Storage::class)) {
            wp_send_json_error(['message' => __('AI Form storage is not available.', 'gpt3-ai-content-generator')], 500);
        }

        $renderer_path = defined('WPAICG_PLUGIN_DIR')
            ? WPAICG_PLUGIN_DIR . 'classes/ai-forms/shortcode.php'
            : '';
        if (
            !function_exists('\\WPAICG\\AIForms\\Frontend\\Shortcode\\render_form_html_logic')
            && $renderer_path
            && file_exists($renderer_path)
        ) {
            require_once $renderer_path;
        }

        if (!function_exists('\\WPAICG\\AIForms\\Frontend\\Shortcode\\render_form_html_logic')) {
            wp_send_json_error(['message' => __('AI Form renderer is not available.', 'gpt3-ai-content-generator')], 500);
        }

        $storage = new AIPKit_AI_Form_Storage();
        $form_data = $storage->get_form_data($target_form_id);
        if (is_wp_error($form_data)) {
            wp_send_json_error(['message' => $form_data->get_error_message()], 404);
        }

        $theme = isset($post_data['theme']) ? sanitize_key((string) $post_data['theme']) : 'light';
        if (!in_array($theme, ['light', 'dark', 'custom'], true)) {
            $theme = 'light';
        }

        $frontend_display_settings = [];
        if (class_exists(AIPKit_AI_Form_Settings_Ajax_Handler::class)) {
            $all_settings = AIPKit_AI_Form_Settings_Ajax_Handler::get_settings();
            $frontend_display_settings = $all_settings['frontend_display'] ?? [];
        }
        $allowed_providers_str = $frontend_display_settings['allowed_providers'] ?? '';

        $custom_css = '';
        if ($theme === 'custom' && class_exists(AIPKit_AI_Form_Settings_Ajax_Handler::class)) {
            $settings = AIPKit_AI_Form_Settings_Ajax_Handler::get_settings();
            $custom_css = $settings['custom_theme']['custom_css'] ?? '';
        }

        $unique_form_html_id = wp_unique_id('aipkit-ai-form-' . $target_form_id . '-workflow-');
        $html = \WPAICG\AIForms\Frontend\Shortcode\render_form_html_logic(
            $form_data,
            $unique_form_html_id,
            wp_create_nonce('aipkit_process_ai_form_' . $target_form_id),
            $theme,
            self::post_bool($post_data['show_provider'] ?? false),
            self::post_bool($post_data['show_model'] ?? false),
            self::post_bool($post_data['save_button'] ?? false),
            self::post_bool($post_data['pdf_download'] ?? false),
            self::post_bool($post_data['copy_button'] ?? false),
            $custom_css,
            is_string($allowed_providers_str) ? $allowed_providers_str : ''
        );

        wp_send_json_success([
            'html' => $html,
            'form_id' => $target_form_id,
        ]);
    }

    public static function get_config(int $form_id): array
    {
        $raw = get_post_meta($form_id, self::META_KEY, true);
        return self::sanitize_config($raw, $form_id);
    }

    public static function get_default_config(): array
    {
        return [
            'version' => 1,
            'enabled' => false,
            'auto_submit' => false,
            'next_form_id' => 0,
            'routes' => [],
            'mappings' => [],
            'nodes' => [],
            'edges' => [],
        ];
    }

    private static function decode_config($raw_config): array
    {
        if (is_string($raw_config) && $raw_config !== '') {
            $decoded = json_decode($raw_config, true);
            $raw_config = json_last_error() === JSON_ERROR_NONE ? $decoded : [];
        }

        return is_array($raw_config) ? $raw_config : [];
    }

    private static function get_all_form_ids(): array
    {
        $post_type = class_exists(AIPKit_AI_Form_Admin_Setup::class)
            ? AIPKit_AI_Form_Admin_Setup::POST_TYPE
            : 'aipkit_ai_form';

        $ids = get_posts([
            'post_type' => $post_type,
            'post_status' => ['publish', 'draft'],
            'posts_per_page' => -1,
            'fields' => 'ids',
        ]);

        return array_values(array_filter(array_map('absint', is_array($ids) ? $ids : [])));
    }

    private static function build_export_key(int $form_id): string
    {
        return 'form_' . absint($form_id);
    }

    private static function sanitize_export_key($value): string
    {
        $value = preg_replace('/[^a-zA-Z0-9_-]/', '', (string) $value);
        return is_string($value) ? substr($value, 0, 80) : '';
    }

    private static function get_form_id_from_export_key($value, array $key_to_new_id): int
    {
        $key = self::sanitize_export_key($value);
        return $key !== '' && isset($key_to_new_id[$key]) ? absint($key_to_new_id[$key]) : 0;
    }

    private static function add_export_keys_to_config($raw_config, array $exported_ids): array
    {
        $config = self::decode_config($raw_config);
        $exported_ids = array_values(array_unique(array_filter(array_map('absint', $exported_ids))));

        $next_form_id = absint($config['next_form_id'] ?? 0);
        if ($next_form_id > 0 && in_array($next_form_id, $exported_ids, true)) {
            $config['next_form_export_key'] = self::build_export_key($next_form_id);
        }

        if (!empty($config['routes']) && is_array($config['routes'])) {
            foreach ($config['routes'] as &$route) {
                if (!is_array($route)) {
                    continue;
                }
                $route_target_id = absint($route['next_form_id'] ?? 0);
                if ($route_target_id > 0 && in_array($route_target_id, $exported_ids, true)) {
                    $route['next_form_export_key'] = self::build_export_key($route_target_id);
                }
            }
            unset($route);
        }

        if (!empty($config['nodes']) && is_array($config['nodes'])) {
            foreach ($config['nodes'] as &$node) {
                if (!is_array($node)) {
                    continue;
                }
                $node_form_id = absint($node['form_id'] ?? 0);
                if ($node_form_id > 0 && in_array($node_form_id, $exported_ids, true)) {
                    $node['form_export_key'] = self::build_export_key($node_form_id);
                }
            }
            unset($node);
        }

        return $config;
    }

    private static function config_has_export_keys($raw_config): bool
    {
        $config = self::decode_config($raw_config);
        if (self::sanitize_export_key($config['next_form_export_key'] ?? '') !== '') {
            return true;
        }

        if (!empty($config['routes']) && is_array($config['routes'])) {
            foreach ($config['routes'] as $route) {
                if (is_array($route) && self::sanitize_export_key($route['next_form_export_key'] ?? '') !== '') {
                    return true;
                }
            }
        }

        if (!empty($config['nodes']) && is_array($config['nodes'])) {
            foreach ($config['nodes'] as $node) {
                if (is_array($node) && self::sanitize_export_key($node['form_export_key'] ?? '') !== '') {
                    return true;
                }
            }
        }

        return false;
    }

    private static function remove_form_references_from_config(array $config, int $deleted_form_id): array
    {
        if (absint($config['next_form_id'] ?? 0) === $deleted_form_id) {
            $config['next_form_id'] = 0;
            $config['mappings'] = [];
        }

        if (!empty($config['routes']) && is_array($config['routes'])) {
            $config['routes'] = array_values(array_filter(
                $config['routes'],
                static fn ($route): bool => is_array($route) && absint($route['next_form_id'] ?? 0) !== $deleted_form_id
            ));
        }

        $removed_node_ids = [];
        if (!empty($config['nodes']) && is_array($config['nodes'])) {
            $config['nodes'] = array_values(array_filter($config['nodes'], static function ($node) use ($deleted_form_id, &$removed_node_ids): bool {
                if (!is_array($node)) {
                    return false;
                }
                if (absint($node['form_id'] ?? 0) !== $deleted_form_id) {
                    return true;
                }
                $node_id = (string) ($node['id'] ?? '');
                if ($node_id !== '') {
                    $removed_node_ids[] = $node_id;
                }
                return false;
            }));
        }

        if (!empty($removed_node_ids) && !empty($config['edges']) && is_array($config['edges'])) {
            $config['edges'] = array_values(array_filter($config['edges'], static function ($edge) use ($removed_node_ids): bool {
                if (!is_array($edge)) {
                    return false;
                }
                return !in_array((string) ($edge['source'] ?? ''), $removed_node_ids, true)
                    && !in_array((string) ($edge['target'] ?? ''), $removed_node_ids, true);
            }));
        }

        return $config;
    }

    private static function remap_imported_workflow_config($raw_config, array $key_to_new_id): array
    {
        $config = self::decode_config($raw_config);
        if (empty($config)) {
            return self::get_default_config();
        }

        $next_form_id = self::get_form_id_from_export_key($config['next_form_export_key'] ?? '', $key_to_new_id);
        $config['next_form_id'] = $next_form_id;
        if ($next_form_id <= 0) {
            $config['mappings'] = [];
        }
        unset($config['next_form_export_key']);

        $routes = [];
        if (!empty($config['routes']) && is_array($config['routes'])) {
            foreach ($config['routes'] as $route) {
                if (!is_array($route)) {
                    continue;
                }
                $route_target_id = self::get_form_id_from_export_key($route['next_form_export_key'] ?? '', $key_to_new_id);
                if ($route_target_id <= 0) {
                    continue;
                }
                $route['next_form_id'] = $route_target_id;
                unset($route['next_form_export_key']);
                $routes[] = $route;
            }
        }
        $config['routes'] = $routes;

        $node_id_map = [];
        $removed_node_ids = [];
        $nodes = [];
        if (!empty($config['nodes']) && is_array($config['nodes'])) {
            foreach ($config['nodes'] as $node) {
                if (!is_array($node)) {
                    continue;
                }
                $old_node_id = (string) ($node['id'] ?? '');
                $node_form_id = 0;
                if (!empty($node['form_export_key'])) {
                    $node_form_id = self::get_form_id_from_export_key($node['form_export_key'], $key_to_new_id);
                    if ($node_form_id <= 0) {
                        if ($old_node_id !== '') {
                            $removed_node_ids[] = $old_node_id;
                        }
                        continue;
                    }
                    $new_node_id = 'form-' . $node_form_id;
                    if ($old_node_id !== '') {
                        $node_id_map[$old_node_id] = $new_node_id;
                    }
                    $node['id'] = $new_node_id;
                    $node['form_id'] = $node_form_id;
                } elseif (absint($node['form_id'] ?? 0) > 0 && !in_array($old_node_id, ['current', 'source'], true)) {
                    if ($old_node_id !== '') {
                        $removed_node_ids[] = $old_node_id;
                    }
                    continue;
                }
                unset($node['form_export_key']);
                $nodes[] = $node;
            }
        }
        $config['nodes'] = $nodes;

        $edges = [];
        if (!empty($config['edges']) && is_array($config['edges'])) {
            foreach ($config['edges'] as $edge) {
                if (!is_array($edge)) {
                    continue;
                }
                $source = (string) ($edge['source'] ?? '');
                $target = (string) ($edge['target'] ?? '');
                if (in_array($source, $removed_node_ids, true) || in_array($target, $removed_node_ids, true)) {
                    continue;
                }
                if (isset($node_id_map[$source])) {
                    $edge['source'] = $node_id_map[$source];
                }
                if (isset($node_id_map[$target])) {
                    $edge['target'] = $node_id_map[$target];
                }
                $edges[] = $edge;
            }
        }
        $config['edges'] = $edges;

        return $config;
    }

    private static function get_raw_workflow_target_ids(array $raw_config): array
    {
        $target_ids = [];
        $next_form_id = absint($raw_config['next_form_id'] ?? 0);
        if ($next_form_id > 0) {
            $target_ids[] = $next_form_id;
        }

        if (!empty($raw_config['routes']) && is_array($raw_config['routes'])) {
            foreach ($raw_config['routes'] as $route) {
                if (!is_array($route)) {
                    continue;
                }
                $route_target_id = absint($route['next_form_id'] ?? 0);
                if ($route_target_id > 0) {
                    $target_ids[] = $route_target_id;
                }
            }
        }

        if (!empty($raw_config['nodes']) && is_array($raw_config['nodes'])) {
            foreach ($raw_config['nodes'] as $node) {
                if (!is_array($node)) {
                    continue;
                }
                $node_form_id = absint($node['form_id'] ?? 0);
                $node_id = (string) ($node['id'] ?? '');
                if ($node_form_id > 0 && !in_array($node_id, ['current', 'source'], true)) {
                    $target_ids[] = $node_form_id;
                }
            }
        }

        return array_values(array_unique($target_ids));
    }

    private static function build_workflow_list_stats(): array
    {
        $form_ids = self::get_all_form_ids();
        $stats = [];
        $incoming_counts = [];
        foreach ($form_ids as $form_id) {
            $stats[$form_id] = [
                'enabled' => false,
                'outgoing_count' => 0,
                'route_count' => 0,
                'incoming_count' => 0,
                'default_target_id' => 0,
                'default_target_title' => '',
                'has_missing_target' => false,
            ];
            $incoming_counts[$form_id] = 0;
        }

        foreach ($form_ids as $form_id) {
            $raw_config = self::decode_config(get_post_meta($form_id, self::META_KEY, true));
            if (empty($raw_config)) {
                continue;
            }

            $config = self::sanitize_config($raw_config, $form_id);
            $target_ids = self::get_workflow_target_ids($config);
            foreach ($target_ids as $target_id) {
                if (isset($incoming_counts[$target_id])) {
                    $incoming_counts[$target_id]++;
                }
            }

            $default_target_id = absint($config['next_form_id'] ?? 0);
            $raw_target_ids = self::get_raw_workflow_target_ids($raw_config);
            $stats[$form_id]['enabled'] = !empty($config['enabled']) && !empty($target_ids);
            $stats[$form_id]['outgoing_count'] = count($target_ids);
            $stats[$form_id]['route_count'] = is_array($config['routes'] ?? null) ? count($config['routes']) : 0;
            $stats[$form_id]['default_target_id'] = $default_target_id;
            $stats[$form_id]['default_target_title'] = $default_target_id > 0 ? self::get_form_title($default_target_id) : '';
            $stats[$form_id]['has_missing_target'] = self::to_bool($raw_config['enabled'] ?? false)
                && count($raw_target_ids) > count($target_ids);
        }

        foreach ($incoming_counts as $form_id => $incoming_count) {
            if (isset($stats[$form_id])) {
                $stats[$form_id]['incoming_count'] = $incoming_count;
            }
        }

        return $stats;
    }

    private static function get_form_title(int $form_id): string
    {
        $title = trim((string) get_the_title($form_id));
        if ($title !== '') {
            return $title;
        }
        /* translators: %d: AI form post ID. */
        return sprintf(__('AI Form #%d', 'gpt3-ai-content-generator'), $form_id);
    }

    public static function sanitize_config($raw_config, int $current_form_id = 0): array
    {
        $raw_config = self::decode_config($raw_config);

        $nodes = self::sanitize_nodes($raw_config['nodes'] ?? [], $current_form_id);
        $edges = self::sanitize_edges($raw_config['edges'] ?? []);
        $next_form_id = isset($raw_config['next_form_id']) ? absint($raw_config['next_form_id']) : 0;
        if ($next_form_id <= 0) {
            $next_form_id = self::derive_next_form_id_from_graph($nodes, $edges);
        }
        if ($next_form_id > 0 && ($next_form_id === $current_form_id || !self::is_valid_form_id($next_form_id))) {
            $next_form_id = 0;
        }

        return [
            'version' => 1,
            'enabled' => self::to_bool($raw_config['enabled'] ?? false),
            'auto_submit' => self::to_bool($raw_config['auto_submit'] ?? false),
            'next_form_id' => $next_form_id,
            'routes' => self::sanitize_routes($raw_config['routes'] ?? [], $current_form_id),
            'mappings' => self::sanitize_mappings($raw_config['mappings'] ?? []),
            'nodes' => $nodes,
            'edges' => $edges,
        ];
    }

    private static function sanitize_routes($routes, int $current_form_id = 0): array
    {
        if (!is_array($routes)) {
            return [];
        }

        $sanitized = [];
        $allowed_operators = ['equals', 'contains', 'not_empty'];
        foreach (array_slice(array_values($routes), 0, 10) as $route) {
            if (!is_array($route)) {
                continue;
            }

            $source = sanitize_key((string) ($route['source'] ?? ''));
            $operator = sanitize_key((string) ($route['operator'] ?? 'contains'));
            if (!in_array($operator, $allowed_operators, true)) {
                $operator = 'contains';
            }

            $next_form_id = absint($route['next_form_id'] ?? ($route['target_form_id'] ?? 0));
            if ($next_form_id <= 0 || $next_form_id === $current_form_id || !self::is_valid_form_id($next_form_id)) {
                continue;
            }

            $value = sanitize_text_field((string) ($route['value'] ?? ''));
            if ($operator !== 'not_empty' && $value === '') {
                continue;
            }

            if ($source === 'ai_output') {
                $sanitized[] = [
                    'source' => 'ai_output',
                    'operator' => $operator,
                    'value' => $operator === 'not_empty' ? '' : $value,
                    'next_form_id' => $next_form_id,
                    'mappings' => self::sanitize_mappings($route['mappings'] ?? []),
                ];
                continue;
            }

            if ($source === 'field' || $source === 'input') {
                $source_field_id = self::sanitize_field_id($route['source_field_id'] ?? '');
                if ($source_field_id === '') {
                    continue;
                }
                $sanitized[] = [
                    'source' => 'field',
                    'source_field_id' => $source_field_id,
                    'operator' => $operator,
                    'value' => $operator === 'not_empty' ? '' : $value,
                    'next_form_id' => $next_form_id,
                    'mappings' => self::sanitize_mappings($route['mappings'] ?? []),
                ];
            }
        }

        return $sanitized;
    }

    private static function sanitize_mappings($mappings): array
    {
        if (!is_array($mappings)) {
            return [];
        }

        $sanitized = [];
        foreach (array_slice(array_values($mappings), 0, 10) as $mapping) {
            if (!is_array($mapping)) {
                continue;
            }

            $source = sanitize_key((string) ($mapping['source'] ?? ''));
            $target_field_id = self::sanitize_field_id($mapping['target_field_id'] ?? '');
            if ($target_field_id === '') {
                continue;
            }

            if ($source === 'ai_output') {
                $sanitized[] = [
                    'source' => 'ai_output',
                    'target_field_id' => $target_field_id,
                ];
                continue;
            }

            if ($source === 'field' || $source === 'input') {
                $source_field_id = self::sanitize_field_id($mapping['source_field_id'] ?? '');
                if ($source_field_id === '') {
                    continue;
                }
                $sanitized[] = [
                    'source' => 'field',
                    'source_field_id' => $source_field_id,
                    'target_field_id' => $target_field_id,
                ];
            }
        }

        return $sanitized;
    }

    private static function sanitize_nodes($nodes, int $current_form_id = 0): array
    {
        if (!is_array($nodes)) {
            return [];
        }

        $sanitized = [];
        $allowed_types = ['form', 'ai', 'condition', 'action', 'notification', 'webhook'];
        foreach (array_slice(array_values($nodes), 0, self::MAX_NODES) as $index => $node) {
            if (!is_array($node)) {
                continue;
            }

            $id = self::sanitize_identifier($node['id'] ?? '');
            if ($id === '') {
                $id = 'node-' . substr(md5((string) $index . wp_json_encode($node)), 0, 12);
            }

            $type = sanitize_key((string) ($node['type'] ?? 'form'));
            if (!in_array($type, $allowed_types, true)) {
                $type = 'form';
            }

            $form_id = isset($node['form_id']) ? absint($node['form_id']) : 0;
            if ($form_id > 0 && ($form_id === $current_form_id || !self::is_valid_form_id($form_id))) {
                $form_id = 0;
            }

            $sanitized[] = [
                'id' => $id,
                'type' => $type,
                'label' => sanitize_text_field((string) ($node['label'] ?? '')),
                'form_id' => $form_id,
            ];
        }

        return $sanitized;
    }

    private static function sanitize_edges($edges): array
    {
        if (!is_array($edges)) {
            return [];
        }

        $sanitized = [];
        foreach (array_slice(array_values($edges), 0, self::MAX_EDGES) as $index => $edge) {
            if (!is_array($edge)) {
                continue;
            }

            $source = self::sanitize_identifier($edge['source'] ?? '');
            $target = self::sanitize_identifier($edge['target'] ?? '');
            if ($source === '' || $target === '') {
                continue;
            }

            $id = self::sanitize_identifier($edge['id'] ?? '');
            if ($id === '') {
                $id = 'edge-' . substr(md5((string) $index . $source . $target), 0, 12);
            }

            $sanitized[] = [
                'id' => $id,
                'source' => $source,
                'target' => $target,
                'label' => sanitize_text_field((string) ($edge['label'] ?? '')),
            ];
        }

        return $sanitized;
    }

    private static function sanitize_identifier($value): string
    {
        $value = sanitize_key((string) $value);
        if ($value === '') {
            return '';
        }

        return substr($value, 0, 64);
    }

    private static function sanitize_field_id($value): string
    {
        $value = preg_replace('/[^a-zA-Z0-9_]/', '', (string) $value);
        if (!is_string($value) || $value === '') {
            return '';
        }

        return substr($value, 0, 80);
    }

    private static function to_bool($value): bool
    {
        return $value === true || $value === 1 || $value === '1' || $value === 'true' || $value === 'yes';
    }

    private static function get_next_form_id_from_config(array $config): int
    {
        $next_form_id = isset($config['next_form_id']) ? absint($config['next_form_id']) : 0;
        if ($next_form_id > 0) {
            return $next_form_id;
        }

        $nodes = isset($config['nodes']) && is_array($config['nodes']) ? $config['nodes'] : [];
        $edges = isset($config['edges']) && is_array($config['edges']) ? $config['edges'] : [];
        return self::derive_next_form_id_from_graph($nodes, $edges);
    }

    private static function get_workflow_target_ids(array $config): array
    {
        $target_ids = [];
        $default_next_form_id = self::get_next_form_id_from_config($config);
        if ($default_next_form_id > 0) {
            $target_ids[] = $default_next_form_id;
        }

        $routes = isset($config['routes']) && is_array($config['routes']) ? $config['routes'] : [];
        foreach ($routes as $route) {
            if (!is_array($route)) {
                continue;
            }
            $route_target_id = absint($route['next_form_id'] ?? 0);
            if ($route_target_id > 0 && self::is_valid_form_id($route_target_id)) {
                $target_ids[] = $route_target_id;
            }
        }

        return array_values(array_unique($target_ids));
    }

    private static function has_workflow_target(array $config): bool
    {
        return !empty(self::get_workflow_target_ids($config));
    }

    private static function get_primary_workflow_target_id(array $config): int
    {
        $target_ids = self::get_workflow_target_ids($config);
        return !empty($target_ids) ? absint($target_ids[0]) : 0;
    }

    private static function is_workflow_target_allowed(array $config, int $target_form_id): bool
    {
        if ($target_form_id <= 0) {
            return false;
        }

        return in_array($target_form_id, self::get_workflow_target_ids($config), true);
    }

    private static function derive_next_form_id_from_graph(array $nodes, array $edges): int
    {
        if (empty($nodes)) {
            return 0;
        }

        $target_node_id = '';
        foreach ($edges as $edge) {
            if (!is_array($edge)) {
                continue;
            }
            $source = (string) ($edge['source'] ?? '');
            if ($source === 'current' || $source === 'source') {
                $target_node_id = (string) ($edge['target'] ?? '');
                break;
            }
        }

        foreach ($nodes as $node) {
            if (!is_array($node)) {
                continue;
            }
            $node_id = (string) ($node['id'] ?? '');
            if ($target_node_id !== '' && $node_id !== $target_node_id) {
                continue;
            }
            $form_id = isset($node['form_id']) ? absint($node['form_id']) : 0;
            if ($form_id > 0 && $node_id !== 'current' && $node_id !== 'source' && self::is_valid_form_id($form_id)) {
                return $form_id;
            }
        }

        return 0;
    }

    private static function is_valid_form_id(int $form_id): bool
    {
        if ($form_id <= 0) {
            return false;
        }

        $post = get_post($form_id);
        if (!$post) {
            return false;
        }

        $post_type = class_exists(AIPKit_AI_Form_Admin_Setup::class)
            ? AIPKit_AI_Form_Admin_Setup::POST_TYPE
            : 'aipkit_ai_form';

        return $post->post_type === $post_type && in_array($post->post_status, ['publish', 'draft'], true);
    }

    private static function get_available_forms(): array
    {
        $post_type = class_exists(AIPKit_AI_Form_Admin_Setup::class)
            ? AIPKit_AI_Form_Admin_Setup::POST_TYPE
            : 'aipkit_ai_form';
        $posts = get_posts([
            'post_type' => $post_type,
            'post_status' => ['publish', 'draft'],
            'posts_per_page' => 200,
            'orderby' => 'title',
            'order' => 'ASC',
        ]);

        if (!is_array($posts)) {
            return [];
        }

        return array_map(static function ($post): array {
            $title = trim((string) ($post->post_title ?? ''));
            $form_id = absint($post->ID ?? 0);
            /* translators: %d: AI form post ID. */
            $fallback_title = sprintf(__('AI Form #%d', 'gpt3-ai-content-generator'), $form_id);
            return [
                'id' => $form_id,
                'title' => $title !== '' ? $title : $fallback_title,
                'fields' => self::get_mappable_fields_for_form($form_id),
            ];
        }, $posts);
    }

    private static function get_mappable_fields_for_form(int $form_id): array
    {
        if ($form_id <= 0) {
            return [];
        }

        $structure_json = get_post_meta($form_id, '_aipkit_ai_form_structure', true);
        $structure = json_decode((string) $structure_json, true);
        if (!is_array($structure)) {
            return [];
        }

        $fields = [];
        self::collect_mappable_fields($structure, $fields);
        return array_values($fields);
    }

    private static function collect_mappable_fields(array $items, array &$fields): void
    {
        foreach ($items as $item) {
            if (!is_array($item)) {
                continue;
            }

            if (!empty($item['columns']) && is_array($item['columns'])) {
                foreach ($item['columns'] as $column) {
                    if (!empty($column['elements']) && is_array($column['elements'])) {
                        self::collect_mappable_fields($column['elements'], $fields);
                    }
                }
                continue;
            }

            $type = sanitize_key((string) ($item['type'] ?? ''));
            if (!in_array($type, ['text-input', 'textarea'], true)) {
                continue;
            }

            $field_id = self::sanitize_field_id($item['fieldId'] ?? '');
            if ($field_id === '' || isset($fields[$field_id])) {
                continue;
            }

            $label = sanitize_text_field((string) ($item['label'] ?? ''));
            $fields[$field_id] = [
                'field_id' => $field_id,
                'label' => $label !== '' ? $label : $field_id,
                'type' => $type,
            ];
        }
    }

    private static function post_bool($value): bool
    {
        return $value === true || $value === 1 || $value === '1' || $value === 'true';
    }

    private static function is_pro_plan(): bool
    {
        return class_exists('\\WPAICG\\aipkit_dashboard') && \WPAICG\aipkit_dashboard::is_pro_plan();
    }
}
