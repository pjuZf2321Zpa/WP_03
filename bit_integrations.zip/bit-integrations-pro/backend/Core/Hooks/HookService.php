<?php

namespace BitApps\IntegrationsPro\Core\Hooks;

use BitApps\IntegrationsPro\Config;
use BitApps\IntegrationsPro\Core\Util\Hooks;
use BitApps\IntegrationsPro\Core\Util\Request;
use FilesystemIterator;

class HookService
{
    public function __construct()
    {
        $this->loadTriggersHooks();
        $this->loadTriggersRoutes();
        $this->loadAppHooks();
        $this->loadActionsHooks();
        Hooks::add('rest_api_init', [$this, 'loadApi']);
    }

    /**
     * Helps to register integration ajax
     *
     * @return void
     */
    public function loadActionsHooks()
    {
        $this->_includeActionTaskHooks('Actions');
    }

    public function loadApi()
    {
        if (is_readable(Config::get('BASEDIR') . 'backend' . DIRECTORY_SEPARATOR . 'Routes' . DIRECTORY_SEPARATOR . 'api.php')) {
            include Config::get('BASEDIR') . 'backend' . DIRECTORY_SEPARATOR . 'Routes' . DIRECTORY_SEPARATOR . 'api.php';
        }
    }

    protected function loadAppHooks()
    {
        if (Request::Check('ajax') && is_readable(Config::get('BASEDIR') . 'backend' . DIRECTORY_SEPARATOR . 'Routes' . DIRECTORY_SEPARATOR . 'ajax.php')) {
            include Config::get('BASEDIR') . 'backend' . DIRECTORY_SEPARATOR . 'Routes' . DIRECTORY_SEPARATOR . 'ajax.php';
        }
        if (is_readable(Config::get('BASEDIR') . 'backend' . DIRECTORY_SEPARATOR . 'hooks.php')) {
            include Config::get('BASEDIR') . 'backend' . DIRECTORY_SEPARATOR . 'hooks.php';
        }
    }

    /**
     * Helps to register Triggers ajax
     *
     * @return null
     */
    protected function loadTriggersHooks()
    {
        if (bit_integrations_version_below('2.0.0')) {
            return;
        }

        $activeTrigger = [];
        if (bit_integrations_class_and_method_exists('Core\\Util\\StoreInCache', 'getActiveFlowEntities')) {
            $storeInCacheClass = bit_integrations_get_class('Core\\Util\\StoreInCache');
            $activeTrigger = $storeInCacheClass::getActiveFlowEntities() ?? [];
        }

        $configClass = bit_integrations_get_class('Config');
        $listedTrigger = $configClass ? \call_user_func([$configClass, 'getOption'], 'selected_trigger', []) : [];
        $activeTrigger = array_unique(
            array_merge(
                $activeTrigger,
                \is_string($listedTrigger)
                    ? [$listedTrigger]
                    : $listedTrigger
            )
        );

        if (empty($activeTrigger)) {
            return;
        }

        foreach ($activeTrigger as $key => $triggerName) {
            $this->_includeTriggerTaskHooks($triggerName);
        }
    }

    private function _includeTriggerTaskHooks($task_name)
    {
        if (!\is_string($task_name) || empty($task_name)) {
            return;
        }

        $task_dir = Config::get('BASEDIR') . 'backend' . DIRECTORY_SEPARATOR;
        $task_path = $task_dir . 'Triggers' . DIRECTORY_SEPARATOR . $task_name . DIRECTORY_SEPARATOR;
        if (is_readable($task_path . 'Hooks.php')) {
            include $task_path . 'Hooks.php';
        }
    }

    private function loadTriggersRoutes()
    {
        $task_dir = Config::get('BASEDIR') . 'backend' . DIRECTORY_SEPARATOR . 'Triggers';
        $dirs = new FilesystemIterator($task_dir);
        foreach ($dirs as $dirInfo) {
            if ($dirInfo->isDir()) {
                $task_name = basename($dirInfo);
                $task_path = $task_dir . DIRECTORY_SEPARATOR . $task_name . DIRECTORY_SEPARATOR;
                if (is_readable($task_path . 'Routes.php') && Request::Check('ajax') && Request::Check('admin')) {
                    include $task_path . 'Routes.php';
                }
            }
        }
    }

    private function _includeActionTaskHooks($task_name)
    {
        $task_dir = Config::get('BASEDIR') . 'backend' . DIRECTORY_SEPARATOR . $task_name;
        $dirs = new FilesystemIterator($task_dir);
        foreach ($dirs as $dirInfo) {
            if ($dirInfo->isDir()) {
                $task_name = basename($dirInfo);
                $task_path = $task_dir . DIRECTORY_SEPARATOR . $task_name . DIRECTORY_SEPARATOR;
                if (is_readable($task_path . 'Routes.php') && Request::Check('ajax') && Request::Check('admin')) {
                    include $task_path . 'Routes.php';
                }
                if (is_readable($task_path . 'Hooks.php')) {
                    include $task_path . 'Hooks.php';
                }
            }
        }
    }
}
