<?php

namespace MasterStudy\Lms\Pro\AddonsPlus\AiLab\Utility;

use MasterStudy\Lms\Utility\Media;
use WP_Error;

class ImageUploader {
	private const GENERATED_IMAGE_META_KEY = '_masterstudy_ai_generated_image';

	public static function create_attachment( string $image, string $custom_title = '', bool $return_attachment = false ) {
		if ( ! self::is_data_image( $image ) ) {
			$attachment_id = attachment_url_to_postid( html_entity_decode( $image ) );

			if ( $attachment_id > 0 && get_post_meta( $attachment_id, self::GENERATED_IMAGE_META_KEY, true ) ) {
				return self::get_existing_attachment( $attachment_id, $custom_title, $return_attachment );
			}

			return Media::create_attachment_from_url( $image, $custom_title, $return_attachment );
		}

		return self::create_attachment_from_data_uri( $image, $custom_title, $return_attachment );
	}

	public static function is_data_image( string $image ): bool {
		return 0 === strpos( $image, 'data:image/' );
	}

	private static function create_attachment_from_data_uri( string $image, string $custom_title = '', bool $return_attachment = false ) {
		$separator_position = strpos( $image, ',' );
		$header             = false !== $separator_position ? substr( $image, 0, $separator_position ) : '';

		if ( false === $separator_position || ! preg_match( '/^data:(image\/[a-zA-Z0-9.+-]+);base64$/i', $header, $matches ) ) {
			return self::format_error(
				new WP_Error(
					'invalid_image_data',
					esc_html__( 'Invalid image data.', 'masterstudy-lms-learning-management-system-pro' )
				),
				$return_attachment
			);
		}

		return self::create_attachment_from_base64(
			substr( $image, $separator_position + 1 ),
			strtolower( $matches[1] ),
			$custom_title,
			$return_attachment
		);
	}

	public static function create_attachment_from_base64(
		string $encoded_image,
		string $mime_type = 'image/png',
		string $custom_title = '',
		bool $return_attachment = false
	) {
		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/image.php';
		require_once ABSPATH . 'wp-admin/includes/media.php';

		$mime_type = strtolower( $mime_type );
		$extension = self::get_extension_by_mime_type( $mime_type );

		if ( empty( $extension ) ) {
			return self::format_error(
				new WP_Error(
					'invalid_image_type',
					esc_html__( 'Unsupported image format.', 'masterstudy-lms-learning-management-system-pro' )
				),
				$return_attachment
			);
		}

		if ( preg_match( '/\s/', $encoded_image ) ) {
			$encoded_image = (string) preg_replace( '/\s+/', '', $encoded_image );
		}

		$decoded_image = base64_decode( $encoded_image, true );

		if ( false === $decoded_image ) {
			return self::format_error(
				new WP_Error(
					'invalid_image_data',
					esc_html__( 'Invalid image data.', 'masterstudy-lms-learning-management-system-pro' )
				),
				$return_attachment
			);
		}

		$attachment_title = $custom_title;

		if ( empty( $attachment_title ) ) {
			$attachment_title = esc_html__( 'AI Image', 'masterstudy-lms-learning-management-system-pro' );
		}

		$filename = sanitize_file_name( $attachment_title ) . '.' . $extension;

		if ( empty( sanitize_file_name( $attachment_title ) ) ) {
			$filename = 'ai-image-' . wp_generate_password( 12, false ) . '.' . $extension;
		}

		$upload = wp_upload_bits( $filename, null, $decoded_image );
		unset( $decoded_image );

		if ( ! empty( $upload['error'] ) ) {
			return self::format_error(
				new WP_Error(
					'image_upload_error',
					$upload['error']
				),
				$return_attachment
			);
		}

		$attachment_id = wp_insert_attachment(
			array(
				'post_mime_type' => $mime_type,
				'post_title'     => sanitize_text_field( $attachment_title ),
				'post_status'    => 'inherit',
			),
			$upload['file']
		);

		if ( is_wp_error( $attachment_id ) ) {
			return self::format_error( $attachment_id, $return_attachment );
		}

		$metadata = wp_generate_attachment_metadata( $attachment_id, $upload['file'] );

		if ( ! empty( $metadata ) ) {
			wp_update_attachment_metadata( $attachment_id, $metadata );
		}

		update_post_meta( $attachment_id, '_wp_attachment_image_alt', wp_slash( $attachment_title ) );
		update_post_meta( $attachment_id, self::GENERATED_IMAGE_META_KEY, 1 );

		return self::get_existing_attachment( $attachment_id, '', $return_attachment );
	}

	private static function get_existing_attachment( int $attachment_id, string $custom_title, bool $return_attachment ) {
		if ( '' !== $custom_title ) {
			wp_update_post(
				array(
					'ID'         => $attachment_id,
					'post_title' => sanitize_text_field( $custom_title ),
				)
			);
			update_post_meta( $attachment_id, '_wp_attachment_image_alt', wp_slash( $custom_title ) );
		}

		$attachment = get_post( $attachment_id );

		if (
			! $attachment
			|| 'attachment' !== $attachment->post_type
			|| 0 !== strpos( $attachment->post_mime_type, 'image/' )
		) {
			return self::format_error(
				new WP_Error(
					'invalid_image_attachment',
					esc_html__( 'Invalid image attachment.', 'masterstudy-lms-learning-management-system-pro' )
				),
				$return_attachment
			);
		}

		if ( $return_attachment ) {
			return $attachment;
		}

		$attached_file = get_attached_file( $attachment_id, true );

		return array(
			'id'       => $attachment_id,
			'title'    => $attachment->post_title,
			'url'      => wp_get_attachment_url( $attachment_id ),
			'type'     => $attachment->post_mime_type,
			'date'     => gmdate( 'Y-m-d', strtotime( $attachment->post_date ) ),
			'modified' => gmdate( 'Y-m-d', strtotime( $attachment->post_modified ) ),
			'size'     => $attached_file && file_exists( $attached_file ) ? size_format( filesize( $attached_file ) ) : '',
		);
	}

	private static function get_extension_by_mime_type( string $mime_type ): string {
		$allowed_types = array(
			'image/jpeg' => 'jpg',
			'image/jpg'  => 'jpg',
			'image/png'  => 'png',
			'image/gif'  => 'gif',
			'image/webp' => 'webp',
		);

		return $allowed_types[ $mime_type ] ?? '';
	}

	private static function format_error( WP_Error $error, bool $return_attachment ) {
		return $return_attachment
			? $error
			: array(
				'error' => $error->get_error_message(),
			);
	}
}
