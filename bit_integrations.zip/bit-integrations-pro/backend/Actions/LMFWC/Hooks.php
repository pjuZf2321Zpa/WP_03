<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Core\Util\Hooks;
use BitApps\IntegrationsPro\Actions\LMFWC\LMFWCProHelper;
use BitApps\IntegrationsPro\Config;

// Deprecated since v2.7.8 - use bit_integrations_lmfwc_* hooks instead
if (class_exists('BitApps\\IntegrationsPro\\Config') && version_compare(BitApps\IntegrationsPro\Config::VERSION, '2.7.8', '<')) {
    Hooks::add('btcbi_lmfwc_update_licence', [LMFWCProHelper::class, 'updateLicense'], 10, 5);
    Hooks::add('btcbi_lmfwc_activate_licence', [LMFWCProHelper::class, 'activateLicense'], 10, 4);
    Hooks::add('btcbi_lmfwc_deactivate_licence', [LMFWCProHelper::class, 'deactivateLicense'], 10, 5);
    Hooks::add('btcbi_lmfwc_reactivate_licence', [LMFWCProHelper::class, 'reactivateLicense'], 10, 5);
    Hooks::add('btcbi_lmfwc_delete_licence', [LMFWCProHelper::class, 'deleteLicense'], 10, 4);
    Hooks::add('btcbi_lmfwc_create_generator', [LMFWCProHelper::class, 'createGenerator'], 10, 4);
    Hooks::add('btcbi_lmfwc_update_generator', [LMFWCProHelper::class, 'UpdateGenerator'], 10, 5);
}

// New hooks since v2.7.8
Hooks::add(Config::withFreePrefix('lmfwc_update_licence'), [LMFWCProHelper::class, 'updateLicense'], 10, 5);
Hooks::add(Config::withFreePrefix('lmfwc_activate_licence'), [LMFWCProHelper::class, 'activateLicense'], 10, 4);
Hooks::add(Config::withFreePrefix('lmfwc_deactivate_licence'), [LMFWCProHelper::class, 'deactivateLicense'], 10, 5);
Hooks::add(Config::withFreePrefix('lmfwc_reactivate_licence'), [LMFWCProHelper::class, 'reactivateLicense'], 10, 5);
Hooks::add(Config::withFreePrefix('lmfwc_delete_licence'), [LMFWCProHelper::class, 'deleteLicense'], 10, 4);
Hooks::add(Config::withFreePrefix('lmfwc_create_generator'), [LMFWCProHelper::class, 'createGenerator'], 10, 4);
Hooks::add(Config::withFreePrefix('lmfwc_update_generator'), [LMFWCProHelper::class, 'UpdateGenerator'], 10, 5);
