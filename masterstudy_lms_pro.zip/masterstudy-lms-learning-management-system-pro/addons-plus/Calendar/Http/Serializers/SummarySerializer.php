<?php

namespace MasterStudy\Lms\Pro\AddonsPlus\Calendar\Http\Serializers;

use MasterStudy\Lms\Http\Serializers\AbstractSerializer;

final class SummarySerializer extends AbstractSerializer {
	public function toArray( $data ): array { // phpcs:ignore WordPress.NamingConventions.ValidFunctionName.MethodNameInvalid
		$event_serializer = new EventSerializer();
		$days             = array();

		foreach ( (array) ( $data['days'] ?? array() ) as $date => $day ) {
			$days[ $date ] = array(
				'total'  => absint( $day['total'] ?? 0 ),
				'events' => $event_serializer->collectionToArray( $day['events'] ?? array() ),
			);
		}

		return array(
			'year'  => absint( $data['year'] ?? 0 ),
			'month' => absint( $data['month'] ?? 0 ),
			'days'  => $days,
		);
	}
}
