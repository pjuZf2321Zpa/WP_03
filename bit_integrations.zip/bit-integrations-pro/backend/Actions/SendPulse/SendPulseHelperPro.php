<?php

/**
 * SendPulse    Record Api
 */

namespace BitApps\IntegrationsPro\Actions\SendPulse;

class SendPulseHelperPro
{
    public static function refreshFields($fields, $apiEndpoint, $token)
    {
        $httpHelperClass = bit_integrations_get_class('Core\\Util\\HttpHelper');

        $headers = ['Authorization' => 'Bearer ' . $token];

        $sendPulseResponse = $httpHelperClass::get($apiEndpoint, null, $headers);

        if (!is_wp_error($sendPulseResponse)) {
            $allFields = $sendPulseResponse;

            foreach ($allFields as $field) {
                if (!\array_key_exists(ucfirst($field->name), $fields)) {
                    $fields[$field->name] = (object) [
                        'fieldName'  => $field->name,
                        'fieldValue' => $field->name,
                        'required'   => strtolower($field->name) == 'email' ? true : false
                    ];
                }
            }
        }

        return $fields;
    }
}
