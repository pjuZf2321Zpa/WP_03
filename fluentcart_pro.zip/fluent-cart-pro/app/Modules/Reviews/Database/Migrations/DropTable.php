<?php

namespace FluentCartPro\App\Modules\Reviews\Database\Migrations;

trait DropTable
{
    public static function getTableName()
    {
        global $wpdb;
        return $wpdb->prefix . static::$tableName;
    }

    public static function dropTable()
    {
        global $wpdb;
        $table = esc_sql(static::getTableName());

        if ($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $table)) === $table) {
            $wpdb->query("ALTER TABLE `{$table}` DISABLE KEYS;");
        }

        $wpdb->query("DROP TABLE IF EXISTS `{$table}`");
    }
}
