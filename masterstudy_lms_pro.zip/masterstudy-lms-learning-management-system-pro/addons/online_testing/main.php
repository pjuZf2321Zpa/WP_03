<?php

new STM_LMS_Testing_Online();

class STM_LMS_Testing_Online {

	public function __construct() {
		add_filter( 'user_answers__user_id', array( $this, 'change_user_id' ), 100, 1 );
		add_filter( 'user_answers__course_id', array( $this, 'change_course_id' ), 100, 2 );
		add_filter( 'user_answers__course_url', array( $this, 'change_course_url' ), 100, 2 );
		add_action( 'add_meta_boxes', array( $this, 'meta_box' ) );

	}

	public function meta_box() {
		add_meta_box( 'meta-box-id', esc_html__( 'Online Testing', 'masterstudy-lms-learning-management-system-pro' ), array( $this, 'meta_box_display' ), 'stm-quizzes', 'side' );
	}

	public function meta_box_display() {
		/* translators: %s ID */
		printf( __( 'To insert this quize on a page please use a shortcode<br/><br/>[stm_lms_quiz_online id=%s]' ), get_the_ID() ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}

	public static function change_user_id( $user ) {
		if ( 0 === $user ) {
			$user = time() . wp_rand( 1000, 9999 );
		}
		return $user;
	}

	public static function change_course_id( $course_id, $source ) {
		return ( ! empty( $source ) ) ? $source : $course_id;
	}

	public static function change_course_url( $url, $source ) {
		return ( ! empty( $source ) ) ? '<a class="btn btn-default" href="' . get_the_permalink( $source ) . '">' . esc_html__( 'Close', 'masterstudy-lms-learning-management-system-pro' ) . '</a>' : $url;
	}

	public static function shortcode( $atts ) {
		if ( empty( $atts['id'] ) ) {
			return false;
		}
		$item_id = intval( $atts['id'] );

		return STM_LMS_Templates::load_lms_template( 'global/online-testing/main', array( 'item_id' => $item_id ) );
	}

}

add_shortcode( 'stm_lms_quiz_online', array( 'STM_LMS_Testing_Online', 'shortcode' ) );
