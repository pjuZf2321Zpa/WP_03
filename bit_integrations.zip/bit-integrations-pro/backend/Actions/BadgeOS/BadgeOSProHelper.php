<?php

namespace BitApps\IntegrationsPro\Actions\BadgeOS;

use Exception;

class BadgeOSProHelper
{
    public static function awardAchievementToUser($defaultResponse, $fieldData, $integrationDetails = null)
    {
        if (!self::isBadgeOSActive()) {
            return self::errorResponse(__('BadgeOS is not installed or activated', 'bit-integrations-pro'));
        }

        $achievementId = isset($integrationDetails->selectedAchievement) ? absint($integrationDetails->selectedAchievement) : 0;

        if (empty($achievementId)) {
            return self::errorResponse(__('Achievement is required', 'bit-integrations-pro'));
        }

        $userId = self::resolveUserId($fieldData['user_id'] ?? '');

        if (empty($userId)) {
            return self::errorResponse(__('User not found', 'bit-integrations-pro'));
        }

        if (!badgeos_is_achievement($achievementId)) {
            return self::errorResponse(__('Failed to award achievement. Please check if the achievement ID is valid.', 'bit-integrations-pro'));
        }

        try {
            badgeos_award_achievement_to_user($achievementId, $userId);

            return self::successResponse(
                __('Achievement awarded successfully', 'bit-integrations-pro'),
                [
                    'user_id'        => $userId,
                    'achievement_id' => $achievementId,
                ]
            );
        } catch (Exception $e) {
            return self::errorResponse($e->getMessage());
        }
    }

    /**
     * Resolve a mapped value to a WP user id. Accepts a user id, email or login,
     * because trigger data commonly carries an email rather than an id.
     *
     * @param mixed $value
     *
     * @return int
     */
    private static function resolveUserId($value)
    {
        if (empty($value)) {
            return 0;
        }

        if (is_numeric($value)) {
            $user = get_user_by('id', (int) $value);

            return $user ? (int) $user->ID : 0;
        }

        $value = sanitize_text_field($value);
        $user = is_email($value) ? get_user_by('email', $value) : get_user_by('login', $value);

        return $user ? (int) $user->ID : 0;
    }

    private static function isBadgeOSActive()
    {
        return class_exists('BadgeOS')
            && \function_exists('badgeos_award_achievement_to_user')
            && \function_exists('badgeos_is_achievement');
    }

    private static function errorResponse($message)
    {
        return [
            'success' => false,
            'message' => $message
        ];
    }

    private static function successResponse($message, $data = [])
    {
        return [
            'success' => true,
            'message' => $message,
            'data'    => $data
        ];
    }
}
