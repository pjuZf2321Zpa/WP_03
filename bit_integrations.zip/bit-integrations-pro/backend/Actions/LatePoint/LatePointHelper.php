<?php

namespace BitApps\IntegrationsPro\Actions\LatePoint;

use Exception;
use Throwable;

/**
 * Shared helpers for the LatePoint action handlers.
 *
 * Ported from bit-pi's LatePoint helper, with the bit-pi status_code envelope
 * replaced by the success/message envelope Bit Integrations logs.
 */
final class LatePointHelper
{
    public static function isPluginInstalled()
    {
        return class_exists('LatePoint');
    }

    /**
     * Ensure the LatePoint model classes an action needs are loaded.
     *
     * @param array|string $classes Short keys from the map below, or raw class names
     *
     * @return null|array Error envelope when a class is missing, null when all present
     */
    public static function validateClassExistence($classes)
    {
        $classes = \is_array($classes) ? $classes : [$classes];
        $classMap = [
            'booking'      => 'OsBookingModel',
            'customer'     => 'OsCustomerModel',
            'agent'        => 'OsAgentModel',
            'order'        => 'OsOrderModel',
            'order_item'   => 'OsOrderItemModel',
            'order_helper' => 'OsOrdersHelper',
            'coupon'       => 'OsCouponModel',
            'bundle'       => 'OsBundleModel',
        ];

        foreach ($classes as $class) {
            $className = $classMap[$class] ?? $class;

            if (!class_exists($className)) {
                return self::errorResponse(
                    // translators: %s: LatePoint model name
                    wp_sprintf(__('%s is not available. It may require LatePoint Pro.', 'bit-integrations-pro'), $className)
                );
            }
        }
    }

    /**
     * Verify every required key is present and non-empty.
     *
     * @param array $fieldData
     * @param array $required
     *
     * @return null|array Error envelope listing the missing keys, null when satisfied
     */
    public static function requireFields($fieldData, array $required)
    {
        $missing = [];

        foreach ($required as $key) {
            if (!isset($fieldData[$key]) || $fieldData[$key] === '' || $fieldData[$key] === null) {
                $missing[] = $key;
            }
        }

        if (!empty($missing)) {
            return self::errorResponse(
                // translators: %s: comma separated field names
                wp_sprintf(__('Missing required field(s): %s', 'bit-integrations-pro'), implode(', ', $missing))
            );
        }
    }

    /**
     * True when the value is one of this class's error envelopes rather than a model.
     *
     * @param mixed $response
     *
     * @return bool
     */
    public static function isError($response)
    {
        return \is_array($response) && isset($response['success']) && $response['success'] === false;
    }

    /**
     * Convert an HH:MM string to minutes past midnight, as LatePoint stores it.
     *
     * @param null|string $time
     *
     * @throws Exception When the string is not HH:MM
     *
     * @return null|int
     */
    public static function convertTimeToMinutes($time)
    {
        if (!$time) {
            return;
        }

        if (!preg_match('/^\d{2}:\d{2}$/', $time)) {
            throw new Exception(__('Invalid time format. Expected HH:MM.', 'bit-integrations-pro'));
        }

        [$hours, $minutes] = array_map('intval', explode(':', $time));

        return ($hours * 60) + $minutes;
    }

    /**
     * Split a comma, pipe or newline delimited list into trimmed values.
     *
     * @param null|array|int|string $value
     *
     * @return array
     */
    public static function parseDelimitedValues($value)
    {
        if ($value === null || $value === '') {
            return [];
        }

        if (\is_string($value)) {
            $items = preg_split('/[,|\n]/', $value);
        } elseif (\is_array($value)) {
            $items = $value;
        } else {
            return [];
        }

        $result = [];

        foreach ($items as $item) {
            $item = trim((string) $item);

            if ($item !== '') {
                $result[] = $item;
            }
        }

        return $result;
    }

    /**
     * Flatten a LatePoint model to an array.
     *
     * @param array|object $model
     *
     * @return array
     */
    public static function prepareData($model)
    {
        try {
            if (!\is_array($model) && \is_object($model) && method_exists($model, 'get_data_vars')) {
                $dataVars = $model->get_data_vars();

                if (!empty($dataVars)) {
                    return $dataVars;
                }
            }

            return (array) json_decode((string) wp_json_encode($model), true);
        } catch (Throwable $th) {
            return (array) json_decode((string) wp_json_encode($model), true);
        }
    }

    /**
     * Surface a LatePoint model's own validation error when it exposes one.
     *
     * @param object $model
     * @param string $fallback
     *
     * @return array
     */
    public static function modelErrorResponse($model, $fallback)
    {
        $errors = \is_object($model) && method_exists($model, 'get_error_messages') ? $model->get_error_messages() : [];

        return self::errorResponse($errors[0] ?? $fallback);
    }

    public static function errorResponse($message)
    {
        return [
            'success' => false,
            'message' => $message
        ];
    }

    public static function successResponse($message, $data = [])
    {
        return [
            'success' => true,
            'message' => $message,
            'data'    => $data
        ];
    }
}
