<?php

defined('ABSPATH') || exit;

/**
 * A single tax line behind an automatic-tax rate, mirroring what Stripe
 * returns (a `tax_breakdown` row on a calculation or a `total_tax_amounts`
 * row on an invoice). Compound jurisdictions produce several of these
 * (a federal and a provincial line, for example). Stripe rounds each
 * line's tax half away from zero independently, so estimate math must
 * keep the lines apart rather than blending them into one percentage.
 *
 * A plain immutable value object: it carries no persistence and no
 * behavior beyond its data.
 */
final class MeprTaxRateComponent
{
    /**
     * The percentage of this tax line (e.g., 9.5).
     *
     * @var float
     */
    public float $percentage;

    /**
     * The Stripe tax type (e.g., 'gst', 'qst', 'vat', 'sales_tax'), or an
     * empty string when Stripe reports none.
     *
     * @var string
     */
    public string $tax_type;

    /**
     * The human-readable description (e.g., 'GST', 'VAT', 'Sales Tax').
     *
     * @var string
     */
    public string $description;

    /**
     * Constructor for the MeprTaxRateComponent class.
     *
     * @param float  $percentage  The percentage of this tax line.
     * @param string $tax_type    The Stripe tax type.
     * @param string $description The human-readable description.
     */
    public function __construct(float $percentage, string $tax_type = '', string $description = '')
    {
        $this->percentage  = $percentage;
        $this->tax_type    = $tax_type;
        $this->description = $description;
    }

    /**
     * The tax class this line contributes to a rate (the tax type, or
     * 'standard' when Stripe reports none).
     *
     * @return string
     */
    public function tax_class(): string
    {
        return $this->tax_type === '' ? 'standard' : $this->tax_type;
    }
}
