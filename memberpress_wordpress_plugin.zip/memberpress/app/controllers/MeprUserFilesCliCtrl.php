<?php

if (!defined('ABSPATH')) {
    die('You are not allowed to call this page directly.');
}

/**
 * WP-CLI commands for the files uploaded through file custom fields.
 */
class MeprUserFilesCliCtrl extends MeprBaseCtrl
{
    /**
     * File names that are never treated as uploads.
     *
     * @var array
     */
    const IGNORED_FILES = ['index.php', 'index.html', 'index.htm', '.htaccess', 'web.config'];

    /**
     * Registers the WP-CLI commands.
     *
     * @return void
     */
    public function load_hooks()
    {
        if (!defined('WP_CLI') || !WP_CLI) {
            return;
        }

        WP_CLI::add_command('memberpress user-files cleanup', [$this, 'cleanup']);
    }

    /**
     * Finds files in the user files directory that no user meta points at.
     *
     * Replacing a file used to leave the previous one behind, so upgrading sites need a one-off
     * sweep. Only user meta is searched; see the mepr_referenced_user_files filter.
     *
     * ## OPTIONS
     *
     * [--delete]
     * : Delete the orphaned files. Without it the command only reports what it found.
     *
     * [--min-age=<hours>]
     * : Ignore files modified within this many hours, so an upload still in flight is never
     * removed. Defaults to 1.
     *
     * ## EXAMPLES
     *
     *     # Report what would be removed.
     *     $ wp memberpress user-files cleanup
     *
     *     # Remove the orphaned files.
     *     $ wp memberpress user-files cleanup --delete
     *
     * @param  array $args       The positional arguments.
     * @param  array $assoc_args The associative arguments.
     * @return void
     */
    public function cleanup($args, $assoc_args)
    {
        $delete  = !empty($assoc_args['delete']);
        $min_age = 1;
        $dir     = MeprUsersHelper::get_user_files_dir();

        if (isset($assoc_args['min-age'])) {
            if (!is_numeric($assoc_args['min-age']) || (float) $assoc_args['min-age'] < 0) {
                // Left to cast, a typo would silently become 0 and disable the guard that
                // keeps an upload still in flight from being swept.
                WP_CLI::error(sprintf('--min-age must be a number of hours, got "%s".', $assoc_args['min-age']));
            }

            $min_age = (float) $assoc_args['min-age'];
        }

        if (!is_dir($dir)) {
            WP_CLI::success(sprintf('Nothing to do, %s does not exist.', $dir));
            return;
        }

        $found = $this->find_orphans($min_age);

        if ($found['checked'] === 0) {
            WP_CLI::success(sprintf('Nothing to do, %s holds no uploads.', $dir));
            return;
        }

        $orphans = $found['orphans'];
        $bytes   = 0;

        foreach ($orphans as $file) {
            $bytes += (int) filesize($file);
        }

        WP_CLI::log(sprintf(
            '%d file(s) in %s, %d referenced by user meta.',
            $found['checked'],
            $dir,
            $found['referenced']
        ));

        if ($found['too_recent'] > 0) {
            WP_CLI::log(sprintf(
                '%d unreferenced file(s) skipped as newer than %s hour(s).',
                $found['too_recent'],
                $min_age
            ));
        }

        if (empty($orphans)) {
            WP_CLI::success('No orphaned files found.');
            return;
        }

        WP_CLI::log(sprintf('Found %d orphaned file(s), %s in total:', count($orphans), size_format($bytes)));

        foreach ($orphans as $file) {
            WP_CLI::log(sprintf(' - %s (%s)', wp_basename($file), size_format((int) filesize($file))));
        }

        if (!$delete) {
            WP_CLI::success('Nothing was deleted. Back the directory up, then re-run with --delete.');
            return;
        }

        $deleted = 0;
        $kept    = 0;

        foreach ($orphans as $file) {
            $url = MeprUsersHelper::get_user_files_url() . '/' . wp_basename($file);

            // The same switch that governs deletion everywhere else, so a site that filters
            // it to retain files is not overruled here.
            if (!MeprHooks::apply_filters('mepr_delete_user_file', true, $url, 0, '')) {
                ++$kept;
                continue;
            }

            wp_delete_file($file);

            if (file_exists($file)) {
                WP_CLI::warning(sprintf('Could not delete %s.', $file));
                continue;
            }

            ++$deleted;
        }

        MeprUsersHelper::forget_user_file_names_on_disk();

        if ($kept > 0) {
            WP_CLI::log(sprintf('%d file(s) kept by the mepr_delete_user_file filter.', $kept));
        }

        WP_CLI::success(sprintf('Deleted %d of %d orphaned file(s).', $deleted, count($orphans)));
    }

    /**
     * Selects the files in the user files directory that nothing references any more.
     *
     * Separate from cleanup() so the decision about what is safe to delete is testable without
     * a WP-CLI runtime. Returns the unreferenced paths in "orphans", plus "checked",
     * "referenced" and "too_recent" counts for reporting.
     *
     * @param  float $min_age Ignore files modified within this many hours.
     * @return array
     */
    private function find_orphans($min_age)
    {
        $dir   = MeprUsersHelper::get_user_files_dir();
        $files = glob($dir . '/*');

        $referenced = $this->get_referenced_file_names();
        $cutoff     = time() - (int) round($min_age * HOUR_IN_SECONDS);
        $orphans    = [];
        $checked    = 0;
        $in_use     = 0;
        $too_recent = 0;

        foreach ((array) $files as $file) {
            if (!is_file($file)) {
                continue;
            }

            $name = wp_basename($file);

            if (in_array($name, self::IGNORED_FILES, true)) {
                continue;
            }

            ++$checked;

            if (isset($referenced[$name])) {
                // Counted here rather than from the reference set, which spans the whole site
                // and would otherwise report more files as referenced than the directory holds.
                ++$in_use;
                continue;
            }

            if (filemtime($file) > $cutoff) {
                ++$too_recent;
                continue;
            }

            $orphans[] = $file;
        }

        return [
            'orphans'    => $orphans,
            'checked'    => $checked,
            'referenced' => $in_use,
            'too_recent' => $too_recent,
        ];
    }

    /**
     * Collects the name of every user file still referenced in user meta.
     *
     * Searches every meta row, not just the configured fields, so a file left by a removed field
     * still counts. Names come from MeprUsersHelper::extract_user_file_names(), so this and the
     * replace path cannot disagree. Costs rows x files: tens of seconds on a 20k/20k site.
     *
     * @return array File names as keys.
     */
    private function get_referenced_file_names()
    {
        global $wpdb;

        $names = [];

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $values = $wpdb->get_col(
            $wpdb->prepare(
                "SELECT meta_value FROM {$wpdb->usermeta} WHERE meta_value LIKE %s",
                '%' . $wpdb->esc_like(MeprUsersHelper::get_user_files_path_fragment()) . '%'
            )
        );

        foreach ((array) $values as $value) {
            foreach (MeprUsersHelper::extract_user_file_names($value) as $name) {
                $names[$name] = true;
            }
        }

        foreach ((array) MeprHooks::apply_filters('mepr_referenced_user_files', []) as $url) {
            if (!is_string($url) || trim($url) === '') {
                continue;
            }

            $path = wp_parse_url(trim($url), PHP_URL_PATH);

            if (!empty($path)) {
                $names[wp_basename(rawurldecode($path))] = true;
            }
        }

        return $names;
    }
}
