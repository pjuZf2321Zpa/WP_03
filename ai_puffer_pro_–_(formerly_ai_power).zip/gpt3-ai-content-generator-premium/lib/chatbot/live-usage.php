<?php
/** Validate browser-forwarded Live events without inventing Realtime-style turns. */
namespace WPAICG\Lib\Chat;

use WP_Error;

if (!defined('ABSPATH')) {
    exit;
}

final class LiveUsage
{
    public static function voice_context(int $bot_id, int $seconds, int $previous = 0): array
    {
        return [
            'provider' => 'OpenAI', 'model' => 'gpt-live-1', 'operation' => 'live_voice',
            'pricing_scope_type' => 'chatbot', 'pricing_scope_id' => $bot_id,
            'usage_data' => ['duration_seconds' => $seconds, 'previous_duration_seconds' => $previous],
        ];
    }

    public static function record_voice(array $session, int $seconds, $tokens, string $source, bool $final = false): array
    {
        $previous = (int) ($session['billed_seconds'] ?? 0);
        if ($seconds <= $previous) {
            return $session;
        }
        $context = self::voice_context($session['bot_id'], $seconds, $previous);
        if (!array_key_exists('voice_pricing_rule', $session)) {
            $session['voice_pricing_rule'] = $tokens->estimate_usage_charge(0, 'chat', $context)['resolved_rule'];
        }
        $context['pricing_rule_snapshot'] = $session['voice_pricing_rule'];
        $context['idempotency_key'] = 'live_voice_' . hash('sha256', $session['id'] . ':' . $seconds);
        $context['usage_data'] += ['live_session_id' => $session['id'], 'usage_source' => $source, 'live_usage_complete' => $final];
        $tokens->record_token_usage($session['user_id'] ?: null, $session['session_id'], $session['bot_id'], 0, 'chat', $context);
        $session['billed_seconds'] = $seconds;
        return $session;
    }

    public static function record(array $session, array $batch, $logs, $tokens)
    {
        $fragments = $batch['transcripts'] ?? [];
        $responses = $batch['responses'] ?? [];
        $seconds = $batch['seconds'] ?? 0;
        $error = new WP_Error('invalid_live_usage', __('Invalid Live usage report.', 'gpt3-ai-content-generator'), ['status' => 400]);
        if (!is_array($fragments) || count($fragments) > 200 || !is_array($responses) || count($responses) > 32
            || !is_numeric($seconds) || !is_finite((float) $seconds) || $seconds < 0
            || $seconds > max(15, time() - $session['created'] + 30)) {
            return $error;
        }
        // Validate the whole batch before recording any charge or message.
        foreach ($fragments as $fragment) {
            if (!is_array($fragment) || !in_array($fragment['role'] ?? '', ['user', 'bot'], true)
                || !is_string($fragment['text'] ?? null) || strlen($fragment['text']) > 16000
                || !isset($fragment['start_ms'], $fragment['end_ms'])
                || !is_numeric($fragment['start_ms']) || !is_numeric($fragment['end_ms'])
                || $fragment['start_ms'] < 0 || $fragment['end_ms'] < $fragment['start_ms']
                || $fragment['end_ms'] > (time() - $session['created'] + 30) * 1000) {
                return $error;
            }
        }
        $normalized = [];
        foreach ($responses as $response) {
            if (!is_array($response) || !is_string($response['id'] ?? null) || !preg_match('/^[a-zA-Z0-9_-]{1,200}$/D', $response['id'])
                || !is_array($response['usage'] ?? null)) {
                return $error;
            }
            $usage = $response['usage'];
            foreach (['input_tokens', 'output_tokens', 'total_tokens'] as $field) {
                if (!isset($usage[$field]) || !is_int($usage[$field]) || $usage[$field] < 0 || $usage[$field] > 1000000) {
                    return $error;
                }
            }
            if ($usage['total_tokens'] !== $usage['input_tokens'] + $usage['output_tokens']) {
                return $error;
            }
            $normalized[$response['id']] = [
                'input_tokens' => $usage['input_tokens'], 'output_tokens' => $usage['output_tokens'], 'total_tokens' => $usage['total_tokens'],
                'input_tokens_details' => ['cached_tokens' => min($usage['input_tokens'], max(0, (int) ($usage['input_tokens_details']['cached_tokens'] ?? 0)))],
                'output_tokens_details' => ['reasoning_tokens' => min($usage['output_tokens'], max(0, (int) ($usage['output_tokens_details']['reasoning_tokens'] ?? 0)))],
            ];
        }
        $base = [
            'bot_id' => $session['bot_id'], 'user_id' => $session['user_id'] ?: null,
            'session_id' => $session['user_id'] ? null : $session['session_id'],
            'conversation_uuid' => $session['conversation_uuid'], 'module' => 'chat',
            'is_guest' => !$session['user_id'], 'timestamp' => time(), 'ai_provider' => 'OpenAILive', 'ai_model' => 'gpt-live-1',
        ];
        foreach ($fragments as $fragment) {
            if (trim($fragment['text']) !== '') {
                $logs->log_message(array_merge($base, [
                    'message_role' => $fragment['role'],
                    // Keep fragment spacing until assembly, then sanitize once for persistence.
                    'message_content' => sanitize_textarea_field($fragment['text']),
                    'usage' => ['live_session_id' => $session['id'], 'transcript_start_ms' => (int) $fragment['start_ms'], 'transcript_end_ms' => (int) $fragment['end_ms'], 'transcript_segment' => true],
                ]));
            }
        }
        foreach ($normalized as $id => $usage) {
            if (isset($session['responses'][$id])) {
                continue;
            }
            $tokens->record_token_usage($session['user_id'] ?: null, $session['session_id'], $session['bot_id'], $usage['total_tokens'], 'chat', [
                'provider' => 'OpenAI', 'model' => $session['model'], 'operation' => 'chat',
                'pricing_scope_type' => 'chatbot', 'pricing_scope_id' => $session['bot_id'],
                'idempotency_key' => 'live_response_' . hash('sha256', $session['id'] . ':' . $id),
                'usage_data' => array_merge($usage, ['live_session_id' => $session['id'], 'response_id' => $id, 'usage_source' => 'browser_report']),
            ]);
            $logs->log_message(array_merge($base, [
                'message_role' => 'system', 'message_content' => __('GPT Live reasoning usage', 'gpt3-ai-content-generator'),
                'ai_model' => $session['model'], 'openai_response_id' => $id,
                'usage' => array_merge($usage, ['live_session_id' => $session['id'], 'usage_source' => 'browser_report']),
            ]));
            $session['responses'][$id] = true;
        }
        // Provider snapshots are cumulative, not increments. Voice seconds never become tokens.
        $session['seconds'] = max($session['seconds'], (float) $seconds);
        // OpenAI's initialization minimum is credited against elapsed time, not added to it.
        $billable_seconds = ($session['seconds'] > 0 || !empty($batch['final'])) ? max(15, (int) ceil($session['seconds'])) : 0;
        $session = self::record_voice($session, $billable_seconds, $tokens, 'browser_report', !empty($batch['final']));
        if (!empty($batch['ended']) && (empty($session['usage_logged']) || (!empty($batch['final']) && empty($session['usage_final_logged'])))) {
            $logs->log_message(array_merge($base, [
                'message_role' => 'system', 'message_content' => __('GPT Live voice session ended', 'gpt3-ai-content-generator'),
                'usage' => ['live_session_id' => $session['id'], 'live_seconds' => $session['seconds'], 'billable_seconds' => (int) ($session['billed_seconds'] ?? 0), 'usage_source' => 'browser_report', 'live_usage_complete' => !empty($batch['final'])],
                'response_data' => ['voice_seconds' => $session['seconds'], 'final_usage_received' => !empty($batch['final']), 'reasoning_model' => $session['model']],
            ]));
            $session['usage_logged'] = true;
            $session['usage_final_logged'] = !empty($batch['final']);
        }
        $session['sequence'] = $batch['sequence'];
        return $session;
    }
}
