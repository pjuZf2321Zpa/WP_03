<?php

namespace FluentCartPro\App\Modules\AdvancedInventory;

use FluentCart\Api\ModuleSettings;
use FluentCart\Framework\Support\Arr;

class AdvancedInventory
{
    public function register($app)
    {
        add_action('fluent_cart/module/activated/stock_management', function ($newData, $oldData) {
            if (Arr::get($newData, 'enable_advanced_inventory') === 'yes') {
                (new \FluentCartPro\App\Modules\AdvancedInventory\Database\DBMigrator())->migrate();
            }
        }, 10, 2);

        if (!ModuleSettings::isActive('stock_management') || ModuleSettings::getSettings('stock_management.enable_advanced_inventory') !== 'yes') {
            return;
        }

        $app->router->group(function ($router) {
            require_once __DIR__ . '/Http/Routes/routes.php';
        });
    }
}
