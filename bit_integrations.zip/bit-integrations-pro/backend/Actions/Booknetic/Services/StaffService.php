<?php

namespace BitApps\IntegrationsPro\Actions\Booknetic\Services;

use BitApps\IntegrationsPro\Core\Util\Hooks;
use BookneticApp\Backend\Staff\Repository\ServiceStaffRepository;
use BookneticApp\Backend\Staff\Services\StaffService as BookneticStaffService;
use BookneticApp\Models\Appointment;
use BookneticApp\Models\Location;
use BookneticApp\Models\Service;
use BookneticApp\Models\Staff;
use BookneticApp\Providers\IoC\Container;

final class StaffService extends BaseService
{
    public function createStaff(): array
    {
        $error = $this->validate([
            'name'         => [__('Name', 'bit-integrations-pro')],
            'email'        => [__('Email', 'bit-integrations-pro'), 'email'],
            'location_ids' => [__('Locations', 'bit-integrations-pro')],
        ]);

        if ($error !== null) {
            return $error;
        }

        $locations = $this->ids('location_ids');

        if (empty($locations)) {
            return $this->error(__('No location is selected. Select one or more locations.', 'bit-integrations-pro'));
        }

        $relationsError = $this->relationsError();

        if ($relationsError !== null) {
            return $this->error($relationsError);
        }

        $email = $this->string('email');

        if (Staff::query()->where('email', $email)->count() > 0) {
            return $this->error(__('A staff member with this email exists. Use a different email.', 'bit-integrations-pro'));
        }

        $data = [
            'name'          => $this->string('name'),
            'email'         => $email,
            'phone_number'  => $this->string('phone_number'),
            'about'         => $this->string('about'),
            'profile_image' => '',
            'locations'     => implode(',', $locations),
            'profession'    => $this->string('profession'),
            'is_active'     => 1,
            'user_id'       => $this->int('user_id'),
        ];

        if (!Staff::query()->insert($data)) {
            return $this->error(__('Booknetic did not create the staff member. Try again.', 'bit-integrations-pro'));
        }

        $staffId = Staff::lastId();
        $this->saveStaffServices($staffId, $this->ids('service_ids'));
        $this->linkWpUser($data['user_id'], 'booknetic_staff');
        Hooks::run('bkntc_staff_created', $staffId);

        return $this->success(Staff::query()->get($staffId));
    }

    public function updateStaff(): array
    {
        $error = $this->validate(['staff_id' => [__('Staff ID', 'bit-integrations-pro'), 'integer']]);

        if ($error !== null) {
            return $error;
        }

        $staffId = $this->int('staff_id');
        $staff = Staff::query()->get($staffId);

        if (empty($staff)) {
            return $this->error(__('The staff member does not exist. Select a different staff member.', 'bit-integrations-pro'));
        }

        $relationsError = $this->relationsError();

        if ($relationsError !== null) {
            return $this->error($relationsError);
        }

        $data = $this->optionalTextFields([
            'name'         => 'name',
            'phone_number' => 'phone_number',
            'about'        => 'about',
            'profession'   => 'profession',
        ]) + $this->optionalIntFields(['user_id']);

        if ($this->has('email')) {
            $email = $this->string('email');

            if (!is_email($email)) {
                return $this->error(__('The staff email is not valid. Enter a correct email.', 'bit-integrations-pro'));
            }

            if (Staff::query()->where('email', $email)->where('id', '<>', $staffId)->count() > 0) {
                return $this->error(__('A staff member with this email exists. Use a different email.', 'bit-integrations-pro'));
            }

            $data['email'] = $email;
        }

        if ($this->has('location_ids')) {
            $locations = $this->ids('location_ids');

            if (empty($locations)) {
                return $this->error(__('No location is selected. Select one or more locations.', 'bit-integrations-pro'));
            }

            $data['locations'] = implode(',', $locations);
        }

        $result = $this->updateRecord(Staff::class, $staffId, $data);

        if (!$result['success']) {
            return $result;
        }

        if (isset($data['user_id'])) {
            $this->linkWpUser($data['user_id'], 'booknetic_staff', $staff->user_id);
        }

        $serviceIds = $this->ids('service_ids');

        if (!empty($serviceIds)) {
            $this->saveStaffServices($staffId, $serviceIds);
        }

        Hooks::run('bkntc_after_request_staff_save_staff', ['staff_id' => $staffId, 'is_edit' => true]);

        return $result;
    }

    public function deleteStaff(): array
    {
        $error = $this->validate(['staff_id' => [__('Staff ID', 'bit-integrations-pro'), 'integer']]);

        if ($error !== null) {
            return $error;
        }

        $staffId = $this->int('staff_id');

        if (empty(Staff::query()->get($staffId))) {
            return $this->error(__('The staff member does not exist. Select a different staff member.', 'bit-integrations-pro'));
        }

        if (Appointment::query()->where('staff_id', $staffId)->count() > 0) {
            return $this->error(__('The staff member has appointments. Delete the appointments first.', 'bit-integrations-pro'));
        }

        $response = Container::get(BookneticStaffService::class)->delete([$staffId], false);

        return $this->success(['staff_id' => $staffId, 'response' => $response], __('The staff member is deleted.', 'bit-integrations-pro'));
    }

    public function duplicateStaff(): array
    {
        $error = $this->validate(['staff_id' => [__('Staff ID', 'bit-integrations-pro'), 'integer']]);

        if ($error !== null) {
            return $error;
        }

        $staffId = $this->int('staff_id');

        if (empty(Staff::query()->get($staffId))) {
            return $this->error(__('The staff member does not exist. Select a different staff member.', 'bit-integrations-pro'));
        }

        $newId = Container::get(BookneticStaffService::class)->duplicate($staffId);

        return $this->success(Staff::query()->get($newId));
    }

    public function setStaffStatus(): array
    {
        $error = $this->validate([
            'staff_id'  => [__('Staff ID', 'bit-integrations-pro'), 'integer'],
            'is_active' => [__('Status', 'bit-integrations-pro')],
        ]);

        if ($error !== null) {
            return $error;
        }

        return $this->updateRecord(Staff::class, $this->int('staff_id'), ['is_active' => (int) $this->toBool($this->value('is_active'))]);
    }

    private function saveStaffServices(int $staffId, array $serviceIds): void
    {
        $repository = new ServiceStaffRepository();
        $existing = $repository->getIdsByStaffId($staffId);

        foreach (array_diff($existing, $serviceIds) as $serviceId) {
            $repository->delete($staffId, $serviceId);
        }

        foreach (array_diff($serviceIds, $existing) as $serviceId) {
            $repository->insert($staffId, $serviceId);
        }
    }

    private function relationsError(): ?string
    {
        $locationIds = $this->ids('location_ids');

        if (!empty($locationIds) && \count($locationIds) !== (int) Location::query()->where('id', 'in', $locationIds)->count()) {
            return __('A selected location does not exist. Select different locations.', 'bit-integrations-pro');
        }

        $serviceIds = $this->ids('service_ids');

        if (!empty($serviceIds) && \count($serviceIds) !== (int) Service::query()->where('id', 'in', $serviceIds)->count()) {
            return __('A selected service does not exist. Select different services.', 'bit-integrations-pro');
        }

        return $this->missingWpUser($this->int('user_id')) ? __('The WordPress user does not exist. Select a different user.', 'bit-integrations-pro') : null;
    }
}
