<?php

namespace MasterStudy\Lms\Pro\addons\point_system\Http\Controllers\Admin;

use MasterStudy\Lms\Http\WpResponseFactory;
use MasterStudy\Lms\Pro\addons\point_system\Http\Serializers\PointStatisticsUserSerializer;
use MasterStudy\Lms\Pro\addons\point_system\Repositories\PointStatisticsAdminAccess;
use MasterStudy\Lms\Pro\addons\point_system\Repositories\PointStatisticsRepository;
use MasterStudy\Lms\Validation\Validator;
use WP_REST_Request;
use WP_REST_Response;

final class GetUsersController {
	public function __invoke( WP_REST_Request $request ): WP_REST_Response {
		if ( ! PointStatisticsAdminAccess::can_access() ) {
			return WpResponseFactory::forbidden();
		}

		$validator = new Validator(
			$request->get_params(),
			array(
				'per_page' => 'nullable|integer',
				'page'     => 'nullable|integer',
				'search'   => 'nullable|string',
			)
		);

		if ( $validator->fails() ) {
			return WpResponseFactory::validation_failed( $validator->get_errors_array() );
		}

		$data          = ( new PointStatisticsRepository() )->get_users( $validator->get_validated() );
		$data['items'] = ( new PointStatisticsUserSerializer() )->collectionToArray( $data['users'] );
		unset( $data['users'] );

		return WpResponseFactory::ok_with_data( $data );
	}
}
