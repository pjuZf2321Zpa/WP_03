<?php

declare(strict_types=1);

namespace FluentCartPro\App\Services\Invoice\Profile;

if (!defined('ABSPATH')) {
    exit;
}

use FluentCartPro\App\Services\Invoice\Domain\CalculatedTotals;
use FluentCartPro\App\Services\Invoice\Domain\En16931Invoice;

interface InvoiceProfileInterface
{
    /**
     * Validate invoice and totals against profile rules. Throw on violation.
     */
    public function validate(En16931Invoice $invoice, CalculatedTotals $totals): void;

    /**
     * Profile identifier (e.g. urn:cen.eu:en16931:2017).
     */
    public function getProfileId(): string;

    /**
     * Syntax for serializer selection: "CII" or "UBL".
     */
    public function getSyntax(): string;
}
