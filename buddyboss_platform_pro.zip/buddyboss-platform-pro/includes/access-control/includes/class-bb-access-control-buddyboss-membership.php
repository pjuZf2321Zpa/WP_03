<?php
/**
 * BuddyBoss Membership Access Control Class.
 *
 * @package BuddyBossPro
 *
 * @since   3.3.0
 */

defined( 'ABSPATH' ) || exit;

/**
 * Setup the bp BuddyBoss Membership access control class.
 *
 * @since 3.3.0
 */
class BB_Access_Control_Buddyboss_Membership extends BB_Access_Control_Abstract {

	/**
	 * The single instance of the class.
	 *
	 * @since 3.3.0
	 *
	 * @var self
	 */
	private static $instance = null;

	/**
	 * BB_Access_Control_Buddyboss_Membership constructor.
	 *
	 * @since 3.3.0
	 */
	public function __construct() {
		add_action( 'bbms_event_create', array( $this, 'bb_access_control_bbms_event_create' ), PHP_INT_MAX, 1 );
	}

	/**
	 * Do things when a user becomes active on a membership, and when they become inactive on a membership.
	 *
	 * @param object $event Event Object.
	 *
	 * @since 3.3.0
	 */
	public function bb_access_control_bbms_event_create( $event ) {

		/**
		 * Fires when a BuddyBoss Membership event is recorded.
		 *
		 * Re-fires the membership plugin's event (transaction completed/expired,
		 * subscription status change, etc.) so access-control consumers can react
		 * when a user gains or loses a membership.
		 *
		 * @since 3.3.0
		 *
		 * @param object $event BuddyBoss Membership event object.
		 */
		do_action( 'bb_access_control_bbms_event_create', $event );
	}

	/**
	 * Get the instance of this class.
	 *
	 * @since 3.3.0
	 *
	 * @return BB_Access_Control_Buddyboss_Membership The single instance of the class.
	 */
	public static function instance() {

		if ( null === self::$instance ) {
			$class_name           = __CLASS__;
			self::$instance       = new $class_name();
			self::$instance->slug = 'buddyboss_membership';
		}

		return self::$instance;
	}

	/**
	 * Function will return all the available membership.
	 *
	 * @since 3.3.0
	 *
	 * @return array list of available membership.
	 */
	public function get_level_lists() {

		if ( bb_pro_should_lock_features() ) {
			return array();
		}

		$results = bb_access_control_get_posts( 'bm-product' );

		/**
		 * Filters the list of BuddyBoss Membership plans available for access control.
		 *
		 * @since 3.3.0
		 *
		 * @param array $results List of membership plans. Each item contains id, text, and default keys.
		 */
		return apply_filters( 'buddyboss_membership_access_control_get_level_lists', $results );

	}

	/**
	 * Function will check whether user has access or not.
	 *
	 * @param int     $user_id       user id.
	 * @param array   $settings_data DB settings.
	 * @param boolean $threaded      threaded check.
	 *
	 * @since 3.3.0
	 *
	 * @return boolean whether user has access to do a particular given action.
	 */
	public function has_access( $user_id = 0, $settings_data = array(), $threaded = false ) {

		$has_access = parent::has_access( $user_id, $settings_data, $threaded );

		if ( ! is_null( $has_access ) ) {
			return $has_access;
		}

		$has_access = false;

		if ( ! class_exists( 'BbmsUser' ) ) {

			/**
			 * Filters whether the user has access based on their BuddyBoss Membership plans.
			 *
			 * The dynamic portion of the hook name, `$this->slug`, refers to
			 * the provider slug `buddyboss_membership`.
			 *
			 * @since 3.3.0
			 *
			 * @param boolean $has_access Whether the user has access to perform the given action.
			 */
			return apply_filters( 'bb_access_control_' . $this->slug . '_has_access', $has_access );
		}

		$user                = new BbmsUser( $user_id );
		$get_access_controls = $user->active_product_subscriptions();

		if ( $threaded ) {
			$current_user                     = new BbmsUser( bp_loggedin_user_id() );
			$current_user_get_access_controls = $current_user->active_product_subscriptions();
			if ( ! empty( $current_user_get_access_controls ) ) {
				$current_user_get_access_controls = array_values( array_unique( $current_user_get_access_controls ) );
			} else {
				$current_user_get_access_controls = array();
			}
			if ( $current_user_get_access_controls ) {
				foreach ( $current_user_get_access_controls as $current_user_get_access_control ) {
					if ( in_array( $current_user_get_access_control, $settings_data['access-control-options'], true ) ) {
						$arr_key = 'access-control-' . $current_user_get_access_control . '-options';
						if ( empty( $settings_data[ $arr_key ] ) ) {
							$has_access = true;
							break;
						}

						if ( ! $has_access && in_array( 'all', $settings_data[ $arr_key ] ) ) { // phpcs:ignore WordPress.PHP.StrictInArray.MissingTrueStrict
							$has_access = true;
							break;
						}
						if ( ! empty( $get_access_controls ) ) {
							$user_memberships = array_values( array_unique( $get_access_controls ) );
						} else {
							$user_memberships = array();
						}
						if ( $user_memberships ) {
							foreach ( $user_memberships as $user_membership ) {
								if ( in_array( $user_membership, $settings_data[ $arr_key ], true ) ) {
									$has_access = true;
									break;
								}
							}
							if ( ! $has_access && in_array( 'all', $settings_data[ $arr_key ] ) ) { // phpcs:ignore WordPress.PHP.StrictInArray.MissingTrueStrict
								foreach ( $user_memberships as $user_membership ) {
									if ( in_array( $user_membership, wp_list_pluck( self::get_level_lists(), 'id' ), true ) ) {
										$has_access = true;
										break;
									}
								}
							}
						}
					}
				}
			}
		} else {
			if ( ! empty( $get_access_controls ) ) {
				$user_memberships = array_values( array_unique( $get_access_controls ) );
			} else {
				$user_memberships = array();
			}
			if ( $user_memberships ) {
				foreach ( $user_memberships as $user_membership ) {
					if ( in_array( $user_membership, $settings_data['access-control-options'], true ) ) {
						$has_access = true;
						break;
					}
				}
			}
		}

		/** This filter is documented in includes/access-control/includes/class-bb-access-control-buddyboss-membership.php */
		return apply_filters( 'bb_access_control_' . $this->slug . '_has_access', $has_access );

	}
}
