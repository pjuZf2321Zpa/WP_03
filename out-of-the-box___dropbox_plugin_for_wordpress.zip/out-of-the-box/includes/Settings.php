<?php

/**
 * @author WP Cloud Plugins
 * @copyright Copyright (c) 2023, WP Cloud Plugins
 *
 * @since       2.11
 * @see https://www.wpcloudplugins.com
 */

namespace TheLion\OutoftheBox;

defined('ABSPATH') || exit;

class Settings
{
    public static $db_key = 'out_of_the_box_settings';
    public static $db_network_key = 'outfthebox_network_settings';

    public static $settings;

    /**
     * The single instance of the class.
     *
     * @var Settings
     */
    protected static $_instance;

    public function __construct()
    {
        // Load settings from DB
        $settings = get_option(self::$db_key, self::get_defaults());

        // Update settings if needed
        $settings = Update::update_database($settings);

        if (Core::is_network_authorized()) {
            $settings = array_merge($settings, get_site_option(self::$db_network_key, []));
        }

        self::$settings = $settings;
    }

    /**
     * Settings Instance.
     *
     * Ensures only one instance is loaded or can be loaded.
     *
     * @return Settings - Settings instance
     *
     * @static
     */
    public static function instance()
    {
        if (is_null(self::$_instance)) {
            self::$_instance = new self();
        }

        return self::$_instance;
    }

    public static function reload()
    {
        self::$_instance = new self();

        return self::$_instance;
    }

    public static function get($key, $default = null)
    {
        if (1 == preg_match('/(.*?)\[(.*?)\]/', $key, $keys)) {
            $setting = self::get($keys[1]);

            if (empty($setting) || empty($setting[$keys[2]])) {
                return $default;
            }

            return $setting[$keys[2]];
        }

        return array_key_exists($key, self::instance()::$settings) ? self::instance()::$settings[$key] : $default;
    }

    public static function save($key, $value)
    {
        self::instance()::$settings[$key] = $value;

        return update_option(self::$db_key, self::instance()::$settings);
    }

    public static function save_for_network($key, $value)
    {
        $network_settings = get_site_option(self::$db_network_key, []);
        $network_settings[$key] = $value;

        return update_site_option(self::$db_network_key, $network_settings);
    }

    /**
     * Save settings configurated via Admin Menu.
     */
    public static function save_ajax_setting()
    {
        // Check AJAX call
        check_ajax_referer('outofthebox-admin-action');

        $setting_key = self::get_valid_ajax_setting_key($_POST['key'] ?? null);
        if (null === $setting_key || !isset($_POST['value'])) {
            Helpers::log_error('Invalid plugin setting requested.', 'Settings', ['key' => sanitize_key($_POST['key'] ?? '')], __LINE__);

            http_response_code(400);

            exit('-1');
        }

        $is_network_setting = self::get_ajax_request_boolean($_POST['network'] ?? false);

        // Check if the user is allowed to change the settings
        if (false === Helpers::check_user_role(self::get('permissions_edit_settings'))) {
            Helpers::log_error('User is not allowed to change the plugin settings.', 'Settings', ['key' => sanitize_key($_POST['key'] ?? '')], __LINE__);

            http_response_code(403);

            exit('-1');
        }

        // Changing who may edit the settings, or network-wide settings,
        // always requires a full site administrator
        if (($is_network_setting || 0 === strpos($setting_key, 'permissions_')) && !current_user_can('manage_options')) {
            http_response_code(403);

            exit('-1');
        }
        
        // Get setting data
        $new_value = self::sanitize_ajax_setting_value($setting_key, wp_unslash($_POST['value']));
        $return = [];

        if ($is_network_setting) {
            $current_settings = $old_settings = get_site_option(self::$db_network_key, []);
            $old_value = $old_settings[$setting_key] ?? null;
        } else {
            $old_value = self::get($setting_key);
            $current_settings = $old_settings = self::$settings;
        }

        // Process setting value
        if ('true' === $new_value) {
            $new_value = 'Yes';
        } elseif ('false' === $new_value) {
            $new_value = 'No';
        }

        if (is_string($new_value)) {
            $new_value = trim($new_value);
        }

        // Store the ID of fields using tagify data
        if (is_string($new_value) && false !== strpos($new_value, '[{')) {
            $new_value = self::_format_tagify_data($new_value);
        }

        if ('dropbox_app_own' === $setting_key && 'No' === $new_value) {
            $current_settings['dropbox_app_key'] = '';
            $current_settings['dropbox_app_secret'] = '';
            $return['dropbox_app_key'] = '';
            $return['dropbox_app_secret'] = '';
        }

        if ('webhook_active' === $setting_key && 'No' === $new_value) {
            $current_settings['webhook_endpoint_url'] = '';
            $return['webhook_endpoint_url'] = '';
        }

        if ('icon_set' === $setting_key) {
            $new_value = rtrim($new_value, '/').'/';
        }

        if (in_array($setting_key, ['icon_set', 'mask_account_id']) && $new_value !== $old_value) {
            Processor::reset_complete_cache();
        }

        if ('network_wide' === $setting_key) {
            $return['reload'] = true;
        }

        if (1 == preg_match('/(.*?)\[(.*?)\]/', $setting_key, $setting_keys)) {
            $current_settings[$setting_keys[1]][$setting_keys[2]] = $new_value;
        } else {
            $current_settings[$setting_key] = $new_value;
        }

        // Save new settings
        if ($new_value === $old_value || empty($new_value) && empty($old_value)) {
            // do nothing
            $return[$setting_key] = $new_value;
            echo wp_json_encode($return, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT);

            exit;
        }

        if ($is_network_setting) {
            if ('purchase_code' === $setting_key) {
                $saved = update_site_option('outofthebox_purchaseid', $new_value);
            } else {
                $saved = update_site_option(self::$db_network_key, $current_settings);
            }
        } else {
            $saved = update_option(self::$db_key, $current_settings);
        }

        if ($saved) {
            self::reload();
            $return[$setting_key] = $new_value;

            if (in_array($setting_key, ['dropbox_app_key', 'dropbox_app_secret'], true)) {
                Helpers::log(empty($new_value) ? 'Own App credential removed.' : (empty($old_value) ? 'Own App credential added.' : 'Own App credential changed.'), 'Settings', ['setting' => $setting_key], __LINE__);
            } elseif ('dropbox_app_own' === $setting_key && 'No' === $new_value) {
                Helpers::log('Own App credentials removed. The default App is used.', 'Settings', null, __LINE__);
            }
        } else {
            http_response_code(500);

            exit('-1');
        }

        if (false === $is_network_setting) {
            // Update Cron Job settings
            if (self::get('event_summary') !== $old_settings['event_summary'] || self::get('event_summary_period') !== $old_settings['event_summary_period']) {
                $summary_cron_job = wp_next_scheduled('outofthebox_send_event_summary');
                if (false !== $summary_cron_job) {
                    wp_unschedule_event($summary_cron_job, 'outofthebox_send_event_summary');
                }
            }
            // If needed, a new cron job will be set when the plugin initiates again

            // Keep account data
            if (empty(Settings::get('accounts'))) {
                self::save('accounts', $old_settings['accounts'] ?? []);
            }
        }

        echo wp_json_encode($return, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT);

        exit;
    }

    /**
     * Return a validated setting key accepted by the AJAX settings endpoint.
     *
     * @param mixed $setting_key Untrusted setting key.
     *
     * @return string|null Valid setting key or null when it is not supported.
     */
    private static function get_valid_ajax_setting_key($setting_key)
    {
        if (!is_string($setting_key)) {
            return null;
        }

        $setting_key = wp_unslash($setting_key);
        if (1 !== preg_match('/^([a-z0-9_]+)(?:\[([a-z0-9_]+)\])?$/', $setting_key, $matches)) {
            return null;
        }

        $default_settings = self::get_defaults();
        $base_key = $matches[1];
        $nested_key = $matches[2] ?? null;

        // Network Wide Authorization is stored separately from the regular settings.
        if ('network_wide' === $base_key) {
            return null === $nested_key ? $setting_key : null;
        }

        if (!array_key_exists($base_key, $default_settings)) {
            return null;
        }

        if (null === $nested_key) {
            return $setting_key;
        }

        $allowed_nested_settings = [
            'colors' => ['style', 'accent', 'black', 'dark1', 'dark2', 'background-dark', 'white', 'light1', 'light2', 'background'],
            'loaders' => ['style', 'loading', 'no_results', 'protected', 'iframe'],
            'userfolder_backend_auto_root' => ['view_roles'],
            'woocommerce_upload_locations' => ['product', 'cart', 'checkout', 'order'],
            'slack_event_types' => ['outofthebox_previewed_entry', 'outofthebox_edited_entry', 'outofthebox_downloaded_entry', 'outofthebox_streamed_entry', 'outofthebox_created_link_to_entry', 'outofthebox_renamed_entry', 'outofthebox_deleted_entry', 'outofthebox_created_entry', 'outofthebox_moved_entry', 'outofthebox_updated_description', 'outofthebox_uploaded_entry', 'outofthebox_uploaded_failed'],
            'integrations' => array_keys($default_settings['integrations']),
        ];

        if (!isset($allowed_nested_settings[$base_key]) || !in_array($nested_key, $allowed_nested_settings[$base_key], true)) {
            return null;
        }

        return $setting_key;
    }

    /**
     * Convert an AJAX request flag to a boolean value.
     *
     * @param mixed $value Untrusted request value.
     *
     * @return bool Whether the request flag is enabled.
     */
    private static function get_ajax_request_boolean($value)
    {
        if (!is_scalar($value)) {
            return false;
        }

        return filter_var(wp_unslash((string) $value), FILTER_VALIDATE_BOOLEAN);
    }

    /**
     * Sanitize a value submitted through the AJAX settings endpoint.
     *
     * @param string $setting_key Validated setting key.
     * @param mixed  $value       Untrusted setting value.
     *
     * @return array|string Sanitized setting value.
     */
    private static function sanitize_ajax_setting_value($setting_key, $value)
    {
        $html_settings = [
            'download_template',
            'upload_template',
            'delete_template',
            'move_template',
            'copy_template',
            'proof_template',
            'filelist_template',
            'userfolder_noaccess',
            'accessibility_loginmessage',
            'accessibility_passwordmessage',
            'accessibility_leadmessage',
            'forms_upload_list_html_template',
        ];

        if (in_array($setting_key, $html_settings, true)) {
            return is_string($value) ? wp_kses($value, self::get_allowed_email_template_html()) : '';
        }

        if ('custom_css' === $setting_key) {
            return is_string($value) ? wp_strip_all_tags($value) : '';
        }

        if (in_array($setting_key, ['accessibility_loginurl', 'webhook_endpoint_url', 'slack_endpoint_url', 'mediaplayer_ads_tagurl'], true)) {
            return is_string($value) ? esc_url_raw($value) : '';
        }

        if ('slack_blocks' === $setting_key) {
            if (!is_string($value)) {
                return '';
            }

            json_decode($value);

            return JSON_ERROR_NONE === json_last_error() ? $value : '';
        }

        if (is_array($value)) {
            return map_deep($value, 'sanitize_text_field');
        }

        return is_scalar($value) ? sanitize_text_field((string) $value) : '';
    }

    /**
     * Get the HTML tags and attributes supported in notification templates.
     *
     * @return array Allowed HTML tags and attributes.
     */
    private static function get_allowed_email_template_html()
    {
        $allowed_html = wp_kses_allowed_html('post');

        $allowed_html['table'] = array_merge($allowed_html['table'] ?? [], [
            'align' => true,
            'background' => true,
            'bgcolor' => true,
            'border' => true,
            'bordercolor' => true,
            'cellpadding' => true,
            'cellspacing' => true,
            'height' => true,
            'role' => true,
            'style' => true,
            'valign' => true,
            'width' => true,
        ]);
        $allowed_html['td'] = array_merge($allowed_html['td'] ?? [], [
            'align' => true,
            'background' => true,
            'bgcolor' => true,
            'border' => true,
            'bordercolor' => true,
            'colspan' => true,
            'height' => true,
            'rowspan' => true,
            'style' => true,
            'valign' => true,
            'width' => true,
        ]);
        $allowed_html['th'] = array_merge($allowed_html['th'] ?? [], $allowed_html['td']);
        $allowed_html['tr'] = array_merge($allowed_html['tr'] ?? [], [
            'align' => true,
            'bgcolor' => true,
            'height' => true,
            'style' => true,
            'valign' => true,
        ]);
        $allowed_html['img'] = array_merge($allowed_html['img'] ?? [], [
            'align' => true,
            'border' => true,
            'hspace' => true,
            'style' => true,
            'vspace' => true,
        ]);
        $allowed_html['center'] = ['align' => true, 'style' => true];
        $allowed_html['font'] = ['color' => true, 'face' => true, 'size' => true, 'style' => true];

        foreach (['div', 'p', 'span'] as $tag) {
            $allowed_html[$tag] = array_merge($allowed_html[$tag] ?? [], ['align' => true, 'style' => true]);
        }

        return $allowed_html;
    }

    /**
     * Add settings to Database when plugin is activated.
     */
    public static function add_settings_to_db()
    {
        add_option(self::$db_key, self::get_defaults());
    }

    /**
     * Default for plugin settings.
     */
    public static function get_defaults()
    {
        return [
            'accounts' => [],
			'purchase_code' => '',
            'dropbox_app_own' => 'No',
            'dropbox_app_key' => '',
            'dropbox_app_secret' => '',
            'integrations' => [
                'advancedcustomfields' => 'Yes',
                'beaverbuilder' => 'Yes',
                'contactform7' => 'Yes',
                'classiceditor' => 'Yes',
                'divipagebuilder' => 'Yes',
                'elementor' => 'Yes',
                'easydigitaldownloads' => 'Yes',
                'fluentforms' => 'Yes',
                'formidableforms' => 'Yes',
                'gravityforms' => 'Yes',
                'gravitypdf' => 'Yes',
                'gutenberg' => 'Yes',
                'ninjaforms' => 'Yes',
                'prettylinks' => 'Yes',
                'slack' => 'No',
                'ultimatemember' => 'Yes',
                'uncannyautomator' => 'Yes',
                'woocommerce' => 'Yes',
                'wpbakerypagebuilder' => 'No',
                'wpforms' => 'Yes',
            ],
            'lostauthorization_notification' => '',
            'google_analytics' => 'No',
            'gallery_navbar_onhover' => 'Yes',
            'loadimages' => 'thumbnail',
            'lightbox_skin' => 'metro-black',
            'lightbox_path' => 'horizontal',
            'lightbox_rightclick' => 'No',
            'lightbox_thumbnails' => 'Yes',
            'lightbox_showcaption' => 'always',
            'lightbox_showheader' => 'always',
            'lightbox_thumbnailbar' => 'hover',
            'mediaplayer_skin' => 'Default_Skin',
            'mediaplayer_load_native_mediaelement' => 'No',
            'mediaplayer_ads_tagurl' => '',
            'mediaplayer_ads_hide_role' => ['users'],
            'mediaplayer_ads_skipable' => 'Yes',
            'mediaplayer_ads_skipable_after' => '5',
            'userfolder_name' => '%user_login% (%user_email%)',
            'userfolder_name_guest_prefix' => 'Guests - ',
            'userfolder_oncreation' => 'Yes',
            'userfolder_oncreation_share' => 'No',
            'userfolder_onfirstvisit' => 'No',
            'userfolder_update' => 'Yes',
            'userfolder_remove' => 'Yes',
            'userfolder_backend' => 'No',
            'userfolder_backend_auto_root' => [],
            'userfolder_noaccess' => '',
            'notification_from_name' => '',
            'notification_from_email' => '',
            'notification_replyto_email' => '',
            'notification_antiphishing_code' => '',
            'download_template_subject' => '',
            'download_template_subject_zip' => '',
            'download_template' => '',
            'upload_template_subject' => '',
            'upload_template' => '',
            'delete_template_subject' => '',
            'delete_template' => '',
            'move_template_subject' => '',
            'move_template' => '',
            'copy_template_subject' => '',
            'copy_template' => '',
            'proof_template_subject' => '',
            'proof_template' => '',
            'filelist_template' => '',
            'permissions_edit_settings' => ['administrator'],
            'permissions_link_users' => ['administrator', 'editor'],
            'permissions_see_dashboard' => ['administrator', 'editor'],
            'permissions_see_filebrowser' => ['administrator'],
            'permissions_add_shortcodes' => ['administrator', 'editor', 'author', 'contributor'],
            'permissions_add_links' => ['administrator', 'editor', 'author', 'contributor'],
            'permissions_add_embedded' => ['administrator', 'editor', 'author', 'contributor'],
            'custom_css' => '',
            'loaders' => [],
            'colors' => [],
            'layout_border_radius' => '10',
            'layout_gap' => '10',
            'layout_pdfviewer' => 'pdfjs',
            'download_method' => 'redirect',
            'remember_last_location' => 'Yes',
            'gzipcompression' => 'No',
            'upload_block_executables' => 'Yes',
            'polyfill' => 'No',
            'always_load_scripts' => 'No',
            'nonce_validation' => 'Yes',
            'ajax_domain_verification' => 'Yes',
            'cloud_security_folder_check' => 'Yes',
            'mask_account_id' => 'No',
            'share_buttons' => [],
            'shortlinks' => 'None',
            'bitly_login' => '',
            'bitly_apikey' => '',
            'shortest_apikey' => '',
            'tinyurl_apikey' => '',
            'tinyurl_domain' => '',
            'rebrandly_apikey' => '',
            'rebrandly_domain' => '',
            'rebrandly_workspace' => '',
            'log_events' => 'Yes',
            'icon_set' => '',
            'use_team_folders' => 'Yes',
            'use_app_folder' => 'No',
            'recaptcha_sitekey' => '',
            'recaptcha_secret' => '',
            'accessibility_loginmessage' => '',
            'accessibility_loginurl' => '',
            'accessibility_passwordmessage' => '',
            'accessibility_leadmessage' => '',
            'tools_export_fields' => '',
            'woocommerce_upload_locations' => ['order'],
            'woocommerce_checkout_section' => 'woocommerce_after_order_notes',
            'woocommerce_temporary_upload_folder' => [],
            'slack_endpoint_url' => '',
            'slack_event_types' => ['outofthebox_uploaded_entry' => 'Yes', 'outofthebox_uploaded_failed' => 'Yes'],
            'slack_blocks' => '',
            'forms_upload_list_html_template' => '',
            'forms_upload_list_text_template' => '',
            'event_retention_period' => '6 month',
            'event_summary' => 'No',
            'event_summary_period' => 'daily',
            'event_summary_recipients' => get_site_option('admin_email'),
            'webhook_active' => 'No',
            'webhook_endpoint_url' => '',
            'webhook_endpoint_secret' => '',
            'usage_period' => '1 day',
            'usage_allow_individual_limits' => 'Yes',
            'download_limits' => 'No',
            'downloads_per_user' => '',
            'downloads_per_user_per_file' => '',
            'zip_downloads_per_user' => '',
            'bandwidth_per_user' => '',
            'download_limits_notification' => '',
            'download_limits_excluded_roles' => ['administrator'],
            'download_limits_block_untraceable_users' => 'Yes',
            'proofing_password_by_default' => 'No',
            'proofing_max_items' => '',
            'proofing_use_labels' => 'Yes',
            'proofing_labels' => [],
            'modules_random_slug' => 'Yes',
            'auto_updates' => 'No',
            'beta_updates' => 'No',
            'uninstall_reset' => 'No',
        ];
    }

    /**
     * Format Tagify data.
     *
     * @param mixed  $data
     * @param string $field
     */
    private static function _format_tagify_data($data, $field = 'id')
    {
        if (is_array($data)) {
            return $data;
        }

        $data_obj = json_decode($data);

        if (null === $data_obj) {
            return $data;
        }

        $new_data = [];

        foreach ($data_obj as $value) {
            $new_data[] = $value->{$field} ?? $value->value;
        }

        return $new_data;
    }
}
