<?php

/**
 * Moosend    Record Api
 */

namespace BitApps\IntegrationsPro\Actions\Moosend;

class MoosendProHelper
{
    public static function mapCustomFields($dataFinal, $data, $field_map)
    {
        $moosendHelperClass = bit_integrations_get_class('Actions\\Moosend\\MoosendHelper');
        $commonClass = bit_integrations_get_class('Core\\Util\\Common');

        $dataFinal['CustomFields'] = [];

        foreach ($field_map as $key => $value) {
            $triggerValue = $value->formFields;
            $actionValue = $value->moosendFormFields;

            $formattedValue = isset($data[$triggerValue]) ? $moosendHelperClass::formatPhoneNumber($data[$triggerValue]) : null;

            if (strpos($actionValue, 'custom_field_') === 0) {
                $actionValue = str_replace('custom_field_', '', $actionValue);
                $dataFinal['CustomFields'][] = "{$actionValue}=" . ($triggerValue === 'custom'
                    ? $commonClass::replaceFieldWithValue($value->customValue, $data)
                    : $formattedValue);
            }
        }

        if (empty($dataFinal['CustomFields'])) {
            unset($dataFinal['CustomFields']);
        }

        return $dataFinal;
    }
}
