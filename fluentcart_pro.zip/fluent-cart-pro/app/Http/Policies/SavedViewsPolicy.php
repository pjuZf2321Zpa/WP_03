<?php

namespace FluentCartPro\App\Http\Policies;

use FluentCart\App\Http\Policies\Policy;
use FluentCart\App\Models\Meta;
use FluentCart\App\Services\Permission\PermissionManager;
use FluentCart\Framework\Http\Request\Request;
use FluentCartPro\App\Core\App;

class SavedViewsPolicy extends Policy
{
    public static function getPermissionMap(): array
    {
        $map = [
            'product_table'        => 'products/view',
            'order_table'          => 'orders/view',
            'customers'            => 'customers/view',
            'coupon_table'         => 'coupons/view',
            'subscriptions'        => 'subscriptions/view',
            'licenses'             => 'licenses/view',
            'license_sites'        => 'licenses/view',
            'order_bump_table'     => 'products/view',
            'log_table'            => 'orders/view',
            'taxes_table'          => 'is_super_admin',
            'shipping_zone_table'  => 'is_super_admin',
            'shipping_class_table' => 'is_super_admin',
        ];

        return (array) apply_filters('fluent_cart/saved_views_permission_map', $map);
    }

    public static function userCanAccessObjectType($userId, string $objectType): bool
    {
        if (!$userId) {
            return false;
        }

        $map = static::getPermissionMap();
        if (!isset($map[$objectType])) {
            return false;
        }

        $permission = $map[$objectType];

        if ($permission === 'is_super_admin') {
            $user = get_user_by('ID', $userId);
            return $user ? user_can($user, 'manage_options') : false;
        }

        return PermissionManager::hasPermission([$permission], $userId);
    }

    public function verifyRequest(Request $request): bool
    {
        $objectType = sanitize_text_field($request->get('object_type', ''));

        if ($objectType) {
            return $this->checkPermissionForType($objectType);
        }

        // For update/delete routes the object_type is not in the request body —
        // extract the record ID from the URL and look up the object_type.
        $id = $this->resolveIdFromUri();

        if (!$id) {
            return false;
        }

        $meta = Meta::query()
            ->where('id', $id)
            ->where('meta_key', 'saved_view')
            ->first();

        if (!$meta) {
            // Record not found — deny here; controller would return 404 anyway.
            return false;
        }

        return $this->checkPermissionForType($meta->object_type);
    }

    private function checkPermissionForType(string $objectType): bool
    {
        return static::userCanAccessObjectType(get_current_user_id(), $objectType);
    }

    /**
     * Parses the numeric record ID from the request URI for PUT/DELETE routes.
     * Route pattern: /saved-views/{id}
     */
    private function resolveIdFromUri(): int
    {
        App::getInstance('request');
        $uri = isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '';
        preg_match('/saved-views\/(\d+)/', $uri, $matches);

        return isset($matches[1]) ? (int) $matches[1] : 0;
    }
}
