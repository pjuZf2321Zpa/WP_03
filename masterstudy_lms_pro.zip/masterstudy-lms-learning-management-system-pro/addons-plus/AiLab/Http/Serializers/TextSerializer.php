<?php

namespace MasterStudy\Lms\Pro\AddonsPlus\AiLab\Http\Serializers;

use MasterStudy\Lms\Http\Serializers\AbstractSerializer;

final class TextSerializer extends AbstractSerializer {
	public function toArray( $data ): array {
		$text = '';

		if ( is_string( $data ) ) {
			$text = $data;
		} elseif ( ! empty( $data['message']['content'] ) ) {
			$text = $data['message']['content'];
		} elseif ( ! empty( $data['text'] ) ) {
			$text = $data['text'];
		}

		return array(
			'index' => $data['index'] ?? 0,
			'text'  => $text,
		);
	}
}
