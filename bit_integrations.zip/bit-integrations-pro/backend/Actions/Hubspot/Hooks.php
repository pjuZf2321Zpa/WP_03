<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Actions\Hubspot\HubspotHelperPro;
use BitApps\IntegrationsPro\Config;
use BitApps\IntegrationsPro\Core\Util\Hooks;

// Deprecated since v2.7.8 - use bit_integrations_hubspot_* hooks instead
if (bit_integrations_version_below('2.7.8')) {
    Hooks::filter('btcbi_hubspot_update_entity', [HubspotHelperPro::class, 'updateEntity'], 10, 4);
}

// New hooks since v2.7.8
Hooks::filter(Config::withFreePrefix('hubspot_update_entity'), [HubspotHelperPro::class, 'updateEntity'], 10, 4);
