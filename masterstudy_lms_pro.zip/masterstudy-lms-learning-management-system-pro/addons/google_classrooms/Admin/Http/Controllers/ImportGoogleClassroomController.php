<?php

namespace MasterStudy\Lms\Pro\addons\google_classrooms\Admin\Http\Controllers;

use MasterStudy\Lms\Http\WpResponseFactory;
use MasterStudy\Lms\Pro\addons\google_classrooms\Admin\Repositories\GoogleClassroomsImportRepository;
use RuntimeException;
use WP_REST_Response;

final class ImportGoogleClassroomController {
	public function __invoke( int $google_id ): WP_REST_Response {
		try {
			$data = ( new GoogleClassroomsImportRepository() )->import_classroom( $google_id );

			return WpResponseFactory::ok_with_data( $data );
		} catch ( RuntimeException $e ) {
			return WpResponseFactory::bad_request( $e->getMessage() );
		}
	}
}
