<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Actions\SecureCustomFields\SecureCustomFieldsRecordHelper;
use BitApps\IntegrationsPro\Config;
use BitApps\IntegrationsPro\Core\Util\Hooks;

Hooks::filter(Config::withFreePrefix('secure_custom_fields_update_post_acf_value'), [SecureCustomFieldsRecordHelper::class, 'updatePostAcfValue'], 10, 2);
Hooks::filter(Config::withFreePrefix('secure_custom_fields_update_user_acf_value'), [SecureCustomFieldsRecordHelper::class, 'updateUserAcfValue'], 10, 2);
Hooks::filter(Config::withFreePrefix('secure_custom_fields_update_option_acf_value'), [SecureCustomFieldsRecordHelper::class, 'updateOptionAcfValue'], 10, 2);
Hooks::filter(Config::withFreePrefix('secure_custom_fields_update_group_field_value'), [SecureCustomFieldsRecordHelper::class, 'updateGroupFieldValue'], 10, 2);
Hooks::filter(Config::withFreePrefix('secure_custom_fields_update_repeater_field_value'), [SecureCustomFieldsRecordHelper::class, 'updateRepeaterFieldValue'], 10, 2);
