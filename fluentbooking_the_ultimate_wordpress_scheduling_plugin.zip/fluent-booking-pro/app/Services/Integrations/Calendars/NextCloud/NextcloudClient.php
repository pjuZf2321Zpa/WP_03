<?php

namespace FluentBookingPro\App\Services\Integrations\Calendars\NextCloud;

use FluentBooking\App\Services\Integrations\Calendars\RemoteCalendarHelper;
use FluentBooking\Framework\Support\Arr;
use FluentBooking\Package\CalDav\Clients\NextCloud;
use FluentBooking\Package\CalDav\ICal\Event;

class NextcloudClient
{
    private $client;

    private $baseUrl = '';

    public function __construct($baseUrl, $userName, $password)
    {
        $this->baseUrl = $baseUrl;
        $this->client = new NextCloud([
            'base_url' => $this->baseUrl,
            'username' => $userName,
            'password' => $password
        ]);

        // Every request carries the host's password, so refuse internal addresses and redirects to them.
        // An older free plugin has no setRequestArgs(), so check before calling it.
        if (method_exists($this->client, 'setRequestArgs')) {
            $this->client->setRequestArgs([
                'reject_unsafe_urls' => RemoteCalendarHelper::shouldRejectUnsafeUrl($this->baseUrl, 'next_cloud_calendar')
            ]);
        }
    }

    public function getCalendars()
    {
        try {
            $calendars = $this->client->getCalendars();

            $formattedCalendars = [];

            foreach ($calendars as $calendar) {
                $formattedCalendars[] = [
                    'id'        => $calendar->href,
                    'title'     => $calendar->displayname,
                    'can_write' => 'yes',
                    'getctag'   => $calendar->getctag
                ];
            }

            return $formattedCalendars;

        } catch (\Exception $e) {
            return new \WP_Error($e->getCode(), $e->getMessage());
        }
    }

    public function getEvents($calendarId, $args)
    {
        return $this->client->getEvents($calendarId, $args);
    }

    public function getClient()
    {
        return $this->client;
    }

    public function createEvent($calendarId, $data = [])
    {

        $event = new Event();

        $values = array_filter(Arr::only($data, [
            'dtstart', 'dtend', 'status', 'summary', 'description', 'location'
        ]));

        if (empty($values['status'])) {
            $values['status'] = 'confirmed';
        }

        foreach ($values as $key => $value) {
            $event->{$key} = $value;
        }

        try {

            return $this->client->addEvent($calendarId, $event);

        } catch (\Exception $e) {
            return new \WP_Error($e->getCode(), $e->getMessage());
        }
    }

}
