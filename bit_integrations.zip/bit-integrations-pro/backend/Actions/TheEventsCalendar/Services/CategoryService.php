<?php

namespace BitApps\IntegrationsPro\Actions\TheEventsCalendar\Services;

use BitApps\IntegrationsPro\Actions\TheEventsCalendar\TheEventsCalendarHelper;

if (!\defined('ABSPATH')) {
    exit;
}

final class CategoryService extends BaseService
{
    public function createEventCategory(): array
    {
        $error = $this->validateRequiredFields(['name' => __('Category Name', 'bit-integrations-pro')]);

        if ($error !== null) {
            return $error;
        }

        $termArgs = array_filter(
            [
                'slug'        => $this->getString('slug'),
                'description' => $this->getString('description'),
                'parent'      => (int) $this->getInteger('parent_id'),
            ]
        );

        $term = wp_insert_term($this->getString('name'), TheEventsCalendarHelper::CATEGORY_TAXONOMY, $termArgs);

        if (is_wp_error($term)) {
            return $this->errorResponse($term->get_error_message());
        }

        return $this->successResponse(__('The event category is created.', 'bit-integrations-pro'), TheEventsCalendarHelper::getCategoryData($term['term_id']));
    }
}
