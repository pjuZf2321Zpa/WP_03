<?php if (!defined('ABSPATH')) {
    die('You are not allowed to call this page directly.');
} ?>

<?php
$current_type = $product->type ?: 'membership';
// New products (never saved) default registration page to OFF (cart-first).
// Existing products without the meta (pre-cart upgrade) default to ON (backward compat via getter).
$reg_meta_raw             = get_post_meta($product->ID, MeprProduct::$enable_registration_page_str, true);
$is_new_product           = ('' === $reg_meta_raw && get_post_status($product->ID) === 'auto-draft');
$enable_registration_page = $is_new_product ? false : $product->get_enable_registration_page();
$sku                      = $product->sku;
$shop_visibility          = $product->shop_visibility ?: 'visible';
$max_quantity             = $product->max_quantity ?: '';
$requires_shipping        = $product->requires_shipping;
$shipping_cost            = $product->shipping_cost ?: '0.00';
$weight                   = get_post_meta($product->ID, MeprProduct::$weight_str, true);
$weight_unit              = get_post_meta($product->ID, MeprProduct::$weight_unit_str, true);
$weight_unit              = ('' === $weight_unit) ? MeprHooks::apply_filters('mepr_default_weight_unit', 'lbs') : $weight_unit;
?>

<div class="product-options-panel">

  <table class="form-table">

    <tr id="mepr-registration-page-row" data-show-for-types="membership">
      <th scope="row">
        <label for="<?php echo esc_attr(MeprProduct::$enable_registration_page_str); ?>">
          <?php esc_html_e('Registration Page', 'memberpress'); ?>
        </label>
        <?php MeprAppHelper::info_tooltip(
            'mepr-product-registration-page',
            __('Registration Page', 'memberpress'),
            __('Enable to keep the standalone registration page for this product. Disable to sell only through the cart/shop.', 'memberpress'),
            'right'
        ); ?>
      </th>
      <td>
        <input type="checkbox"
               id="<?php echo esc_attr(MeprProduct::$enable_registration_page_str); ?>"
               name="<?php echo esc_attr(MeprProduct::$enable_registration_page_str); ?>"
               <?php checked($enable_registration_page); ?> />
        <label for="<?php echo esc_attr(MeprProduct::$enable_registration_page_str); ?>">
          <?php esc_html_e('Standalone registration page', 'memberpress'); ?>
        </label>
      </td>
    </tr>
    <?php // SKU field hidden for now — restore from git history if needed. ?>

    <tr data-show-for-types="physical">
      <th scope="row">
        <label for="<?php echo esc_attr(MeprProduct::$weight_str); ?>">
          <?php esc_html_e('Weight', 'memberpress'); ?>
        </label>
      </th>
      <td>
        <input type="number"
               id="<?php echo esc_attr(MeprProduct::$weight_str); ?>"
               name="<?php echo esc_attr(MeprProduct::$weight_str); ?>"
               min="0"
               step="0.01"
               style="width:80px;"
               value="<?php echo esc_attr($weight); ?>" />
        <select id="<?php echo esc_attr(MeprProduct::$weight_unit_str); ?>"
                name="<?php echo esc_attr(MeprProduct::$weight_unit_str); ?>">
          <option value="lbs"<?php selected($weight_unit, 'lbs'); ?>><?php esc_html_e('lbs', 'memberpress'); ?></option>
          <option value="kg"<?php selected($weight_unit, 'kg'); ?>><?php esc_html_e('kg', 'memberpress'); ?></option>
          <option value="oz"<?php selected($weight_unit, 'oz'); ?>><?php esc_html_e('oz', 'memberpress'); ?></option>
          <option value="g"<?php selected($weight_unit, 'g'); ?>><?php esc_html_e('g', 'memberpress'); ?></option>
        </select>
      </td>
    </tr>

    <tr>
      <th scope="row">
        <label for="<?php echo esc_attr(MeprProduct::$shop_visibility_str); ?>">
          <?php esc_html_e('Shop Page Visibility', 'memberpress'); ?>
        </label>
        <?php MeprAppHelper::info_tooltip(
            'mepr-product-shop-visibility',
            __('Shop Page Visibility', 'memberpress'),
            __('Whether this product is listed on the Shop page. Hidden products are not listed but can still be reached by direct link.', 'memberpress'),
            'right'
        ); ?>
      </th>
      <td>
        <select id="<?php echo esc_attr(MeprProduct::$shop_visibility_str); ?>"
                name="<?php echo esc_attr(MeprProduct::$shop_visibility_str); ?>">
          <option value="visible"<?php selected($shop_visibility, 'visible'); ?>><?php esc_html_e('Visible', 'memberpress'); ?></option>
          <option value="hidden"<?php selected($shop_visibility, 'hidden'); ?>><?php esc_html_e('Hidden', 'memberpress'); ?></option>
        </select>
      </td>
    </tr>

    <tr data-show-for-types="digital,physical">
      <th scope="row">
        <label for="<?php echo esc_attr(MeprProduct::$max_quantity_str); ?>">
          <?php esc_html_e('Max Quantity Per Cart', 'memberpress'); ?>
        </label>
        <?php MeprAppHelper::info_tooltip(
            'mepr-product-max-quantity',
            __('Max Quantity Per Cart', 'memberpress'),
            __('Limit how many of this product a customer can buy in a single order. Membership products are always limited to 1.', 'memberpress'),
            'right'
        ); ?>
      </th>
      <td>
        <input type="number"
               id="<?php echo esc_attr(MeprProduct::$max_quantity_str); ?>"
               name="<?php echo esc_attr(MeprProduct::$max_quantity_str); ?>"
               min="1"
               max="<?php echo esc_attr(MeprCartSessionService::MAX_ITEM_QTY); ?>"
               value="<?php echo esc_attr($max_quantity); ?>" />
      </td>
    </tr>

    <tr data-show-for-types="physical">
      <th scope="row">
        <label for="<?php echo esc_attr(MeprProduct::$requires_shipping_str); ?>">
          <?php esc_html_e('Requires Shipping', 'memberpress'); ?>
        </label>
      </th>
      <td>
        <input type="checkbox"
               id="<?php echo esc_attr(MeprProduct::$requires_shipping_str); ?>"
               name="<?php echo esc_attr(MeprProduct::$requires_shipping_str); ?>"
               <?php checked($requires_shipping); ?> />
        <label for="<?php echo esc_attr(MeprProduct::$requires_shipping_str); ?>">
          <?php esc_html_e('This product requires shipping', 'memberpress'); ?>
        </label>
      </td>
    </tr>

    <tr data-show-for-types="physical" id="mepr-cart-shipping-cost-row">
      <th scope="row">
        <label for="<?php echo esc_attr(MeprProduct::$shipping_cost_str); ?>">
          <?php esc_html_e('Flat-Rate Shipping Cost', 'memberpress'); ?>
        </label>
      </th>
      <td>
        <input type="text"
               id="<?php echo esc_attr(MeprProduct::$shipping_cost_str); ?>"
               name="<?php echo esc_attr(MeprProduct::$shipping_cost_str); ?>"
               value="<?php echo esc_attr($shipping_cost); ?>" />
      </td>
    </tr>

  </table>

</div>
