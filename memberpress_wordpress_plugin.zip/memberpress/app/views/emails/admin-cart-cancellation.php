<?php if (!defined('ABSPATH')) {
    die('You are not allowed to call this page directly.');
} ?>
<div id="header" style="width: 680px; padding: 0px; margin: 0 auto; text-align: left;">
  <h1 style="font-size: 30px; margin-bottom: 0;"><?php echo esc_html_x('Cart Order Cancelled', 'email', 'memberpress'); ?></h1>
  <h2 style="margin-top: 0; color: #999; font-weight: normal;"><?php echo esc_html_x('Order #{$order_id}', 'email', 'memberpress'); ?></h2>
</div>
<div id="body" style="width: 600px; background: white; padding: 40px; margin: 0 auto; text-align: left;">

  <p><?php echo esc_html_x('Order #{$order_id} ({$user_email}) has been cancelled.', 'email', 'memberpress'); ?></p>

  {$order_items}

  <table style="clear: both; width: 100%;" class="transaction">
    <tr><th style="text-align: left;"><?php echo esc_html_x('Cancellation Date:', 'email', 'memberpress'); ?></th><td>{$cancellation_date}</td></tr>
    <tr><th style="text-align: left;"><?php echo esc_html_x('Customer:', 'email', 'memberpress'); ?></th><td>{$user_first_name} {$user_last_name} ({$user_email})</td></tr>
    <tr><th style="text-align: left;"><?php echo esc_html_x('Reason:', 'email', 'memberpress'); ?></th><td>{$cancellation_reason}</td></tr>
    <tr><th style="text-align: left;"><?php echo esc_html_x('Refunded:', 'email', 'memberpress'); ?></th><td>{$refunded_amount}</td></tr>
  </table>

</div>
