<?php // phpcs:ignore WordPress.Files.FileName.InvalidClassFileName
/**
 * LoginPress email verification service.
 *
 * Reusable token-based email confirmation for social login and future addons.
 *
 * @package LoginPress Pro
 * @since 6.2.4
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'LoginPress_Email_Verification' ) ) :

	/**
	 * Core email verification handler.
	 *
	 * @since 6.2.4
	 */
	class LoginPress_Email_Verification {

		/**
		 * Singleton instance.
		 *
		 * @since 6.2.4
		 * @var LoginPress_Email_Verification|null
		 */
		private static $instance = null;

		/**
		 * Transient prefix for verification tokens.
		 *
		 * @since 6.2.4
		 * @var string
		 */
		const TRANSIENT_PREFIX = 'loginpress_ev_';

		/**
		 * Transient prefix for pending request lookups.
		 *
		 * @since 6.2.4
		 * @var string
		 */
		const PENDING_PREFIX = 'loginpress_ev_pending_';

		/**
		 * Query argument for verification links.
		 *
		 * @since 6.2.4
		 * @var string
		 */
		const QUERY_ARG = 'loginpress_verify_email';

		/**
		 * Get singleton instance.
		 *
		 * @since 6.2.4
		 * @return LoginPress_Email_Verification
		 */
		public static function instance() {
			if ( null === self::$instance ) {
				self::$instance = new self();
			}
			return self::$instance;
		}

		/**
		 * Constructor.
		 *
		 * @since 6.2.4
		 */
		public function __construct() {
			add_action( 'init', array( $this, 'loginpress_handle_email_verification_request' ), 5 );
		}

		/**
		 * Create a verification request and send the email.
		 *
		 * @since 6.2.4
		 * @param array $args Request arguments.
		 * @return string|WP_Error Token on success.
		 */
		public function loginpress_email_verification_create_and_send( $args ) {
			$token = $this->loginpress_email_verification_create_request( $args );
			if ( is_wp_error( $token ) ) {
				return $token;
			}

			$sent = $this->loginpress_email_verification_send_email( $token, $args );
			if ( ! $sent ) {
				return new WP_Error( 'loginpress_ev_mail_failed', __( 'Unable to send verification email.', 'loginpress-pro' ) );
			}

			return $token;
		}

		/**
		 * Create a verification request transient.
		 *
		 * @since 6.2.4
		 * @param array $args Request arguments.
		 * @return string|WP_Error Token on success.
		 */
		public function loginpress_email_verification_create_request( $args ) {
			$email    = isset( $args['email'] ) ? sanitize_email( $args['email'] ) : '';
			$type     = isset( $args['type'] ) ? sanitize_key( $args['type'] ) : '';
			$provider = isset( $args['provider'] ) ? sanitize_key( $args['provider'] ) : '';

			if ( empty( $email ) || ! is_email( $email ) ) {
				return new WP_Error( 'loginpress_ev_invalid_email', __( 'Invalid email address.', 'loginpress-pro' ) );
			}

			if ( empty( $type ) || empty( $provider ) ) {
				return new WP_Error( 'loginpress_ev_missing_args', __( 'Missing verification arguments.', 'loginpress-pro' ) );
			}

			$expiry       = (int) apply_filters( 'loginpress_email_verification_expiry', DAY_IN_SECONDS, $args );
			$pending_key  = self::PENDING_PREFIX . md5( $email . '|' . $provider . '|' . $type );
			$existing     = get_transient( $pending_key );
			$request_data = array(
				'type'     => $type,
				'email'    => $email,
				'user_id'  => isset( $args['user_id'] ) ? absint( $args['user_id'] ) : 0,
				'provider' => $provider,
				'payload'  => isset( $args['payload'] ) && is_array( $args['payload'] ) ? $args['payload'] : array(),
			);

			if ( is_string( $existing ) && ! empty( $existing ) ) {
				$token = $existing;
				set_transient( self::TRANSIENT_PREFIX . $token, $request_data, $expiry );
				set_transient( $pending_key, $token, $expiry );
				do_action( 'loginpress_email_verification_created', $token, $request_data );
				return $token;
			}

			$token = wp_generate_password( 32, false );
			set_transient( self::TRANSIENT_PREFIX . $token, $request_data, $expiry );
			set_transient( $pending_key, $token, $expiry );

			do_action( 'loginpress_email_verification_created', $token, $request_data );

			return $token;
		}

		/**
		 * Send verification email for a token.
		 *
		 * @since 6.2.4
		 * @param string $token Verification token.
		 * @param array  $args  Request arguments.
		 * @return bool
		 */
		public function loginpress_email_verification_send_email( $token, $args ) {
			$email = isset( $args['email'] ) ? sanitize_email( $args['email'] ) : '';
			if ( empty( $email ) || ! is_email( $email ) ) {
				return false;
			}

			$verify_url = $this->loginpress_get_email_verification_url( $token );
			$blog_name  = wp_specialchars_decode( get_option( 'blogname' ), ENT_QUOTES );
			$type       = isset( $args['type'] ) ? $args['type'] : '';
			$provider   = isset( $args['provider'] ) ? ucfirst( $args['provider'] ) : '';

			if ( 'social_link' === $type ) {
				/* translators: 1: Site name, 2: Provider name. */
				$subject = sprintf( __( '[%1$s] Confirm linking your %2$s account', 'loginpress-pro' ), $blog_name, $provider );
				$message = sprintf(
					/* translators: 1: Provider name, 2: Site name, 3: Verification URL. */
					__( 'Someone requested to link a %1$s account to your account on %2$s. If this was you, click the link below to confirm:%3$s%3$s%4$s%3$s%3$sIf you did not request this, you can ignore this email.', 'loginpress-pro' ),
					$provider,
					$blog_name,
					"\n\n",
					$verify_url
				);
			} else {
				/* translators: %s: Site name. */
				$subject = sprintf( __( '[%s] Confirm your email address', 'loginpress-pro' ), $blog_name );
				$message = sprintf(
					/* translators: 1: Provider name, 2: Site name, 3: Line breaks, 4: Verification URL. */
					__( 'Please confirm your email to complete your %1$s registration on %2$s.%3$s%3$s%4$s%3$s%3$sIf you did not request this, you can ignore this email.', 'loginpress-pro' ),
					$provider,
					$blog_name,
					"\n\n",
					$verify_url
				);
			}

			$subject = apply_filters( 'loginpress_email_verification_subject', $subject, $args, $verify_url );
			$message = apply_filters( 'loginpress_email_verification_message', $message, $args, $verify_url );

			$headers = array( 'Content-Type: text/plain; charset=UTF-8' );

			return (bool) wp_mail( $email, $subject, $message, $headers );
		}

		/**
		 * Build the verification URL for a token.
		 *
		 * @since 6.2.4
		 * @param string $token Verification token.
		 * @return string
		 */
		public function loginpress_get_email_verification_url( $token ) {
			return add_query_arg(
				self::QUERY_ARG,
				rawurlencode( $token ),
				home_url( '/' )
			);
		}

		/**
		 * Handle incoming verification link requests.
		 *
		 * @since 6.2.4
		 * @return void
		 */
		public function loginpress_handle_email_verification_request() {
			// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Public verification link.
			if ( ! isset( $_GET[ self::QUERY_ARG ] ) ) {
				return;
			}

			// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Public verification link.
			$token = sanitize_text_field( wp_unslash( $_GET[ self::QUERY_ARG ] ) );
			if ( empty( $token ) ) {
				$this->loginpress_redirect_email_verification_failed();
			}

			$request = get_transient( self::TRANSIENT_PREFIX . $token );
			if ( false === $request || ! is_array( $request ) ) {
				$this->loginpress_redirect_email_verification_failed();
			}

			delete_transient( self::TRANSIENT_PREFIX . $token );

			$pending_key = self::PENDING_PREFIX . md5(
				$request['email'] . '|' . $request['provider'] . '|' . $request['type']
			);
			delete_transient( $pending_key );

			$type = isset( $request['type'] ) ? sanitize_key( $request['type'] ) : '';
			if ( empty( $type ) ) {
				$this->loginpress_redirect_email_verification_failed();
			}

			/**
			 * Fires when an email verification link is confirmed.
			 *
			 * @since 6.2.4
			 * @param array  $request Request data.
			 * @param string $token   Used token.
			 */
			do_action( 'loginpress_ev_confirmed_' . $type, $request, $token );
		}

		/**
		 * Redirect when verification fails.
		 *
		 * @since 6.2.4
		 * @return void
		 */
		private function loginpress_redirect_email_verification_failed() {
			wp_safe_redirect(
				add_query_arg(
					array(
						'lp_social_error' => 'spotify_verify_expired',
					),
					wp_login_url()
				)
			);
			exit;
		}
	}

endif;

LoginPress_Email_Verification::instance();
