<?php

namespace MasterStudy\Lms\Pro\addons\google_classrooms\Admin\Http\Controllers;

use MasterStudy\Lms\Http\WpResponseFactory;
use WP_REST_Response;

final class GetGoogleClassroomsSettingsFragmentController {
	public function __invoke(): WP_REST_Response {
		return WpResponseFactory::ok_with_data(
			\STM_LMS_Google_Classroom::getInstance()->get_settings_fragment_payload()
		);
	}
}
