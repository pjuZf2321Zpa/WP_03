<?php

namespace FluentBookingPro\App\Modules\MCP;

use FluentBooking\App\Models\Booking;
use FluentBooking\App\Models\BookingActivity;
use FluentBooking\App\Modules\MCP\Support\BookingWriter;
use FluentBooking\App\Modules\MCP\Support\MCPHelper;
use FluentBooking\App\Modules\MCP\Support\PermissionGate;
use FluentBooking\App\Modules\MCP\Support\WriteGuard;
use FluentBooking\Framework\Support\Arr;
use FluentBookingPro\App\Services\BookingNoteService;

defined('ABSPATH') || exit;

/**
 * Host notes on a booking. One tool for create, update and delete so the
 * core toolset pays for a single schema. Reading is an include on get-booking,
 * not a second tool.
 *
 * Every action is destructive: update replaces the previous text with no
 * history, and delete removes the row. Create goes through the same preview
 * because a destructive ability has to treat dry_run as non-mutating for
 * every action it exposes.
 */
class BookingNoteTools
{
    const TOOL = 'fluent-booking/manage-booking-note';

    const ACTIONS = ['create', 'update', 'delete'];

    /**
     * Pro-only. The free registrar asks for this class only because we push
     * it onto the core toolset.
     */
    public static function register()
    {
        add_filter('fluent_booking/mcp_tool_classes', [self::class, 'addToolClass']);
    }

    /**
     * @param array $classes
     * @return array
     */
    public static function addToolClass($classes)
    {
        $classes[PermissionGate::TOOLSET_CORE][] = self::class;

        return $classes;
    }

    /**
     * @return array
     */
    public static function definitions()
    {
        return [
            self::TOOL => [
                'label'               => __('Manage booking note', 'fluent-booking-pro'),
                'description'         => __('Add, edit or delete a host note on a booking. Notes are private to hosts. On a group event every guest shares one set, stored on the earliest booking in the group. title is optional; a blank title is stored as "Note added by" the host. Call with dry_run first, then pass the returned confirm_token. Read notes with get-booking include notes.', 'fluent-booking-pro'),
                'input_schema'        => [
                    'type'       => 'object',
                    'properties' => [
                        'booking_id'      => [
                            'type'        => 'integer',
                            'description' => __('The booking to attach the note to. Any guest in a group event addresses the shared set. Required.', 'fluent-booking-pro'),
                        ],
                        'action'          => [
                            'type'        => 'string',
                            'description' => __('create needs note. update and delete need note_id; update also needs note. Required.', 'fluent-booking-pro'),
                            'enum'        => self::ACTIONS,
                        ],
                        'note_id'         => [
                            'type'        => 'integer',
                            'description' => __('update and delete only. The note id from get-booking include notes.', 'fluent-booking-pro'),
                        ],
                        'note'            => [
                            'type'        => 'string',
                            'description' => __('create and update only. Plain text. Line breaks are kept. Maximum 20000 characters.', 'fluent-booking-pro'),
                            'maxLength'   => BookingNoteService::MAX_LENGTH,
                        ],
                        'title'           => [
                            'type'        => 'string',
                            'description' => __('create and update only. Optional single-line title, maximum 192 characters. Omit it on update to leave the title unchanged. A blank title is stored as "Note added by" the host.', 'fluent-booking-pro'),
                            'maxLength'   => BookingNoteService::MAX_TITLE_LENGTH,
                        ],
                        'timezone'        => [
                            'type'        => 'string',
                            'description' => __('IANA timezone for the *_local times in the response.', 'fluent-booking-pro'),
                        ],
                        'dry_run'         => [
                            'type'        => 'boolean',
                            'description' => __('Preview the change and get a confirm_token without applying it.', 'fluent-booking-pro'),
                        ],
                        'confirm_token'   => [
                            'type'        => 'string',
                            'description' => __('The token from the dry run. Required to execute.', 'fluent-booking-pro'),
                        ],
                        'idempotency_key' => [
                            'type'        => 'string',
                            'description' => __('Pass a unique key so a retry after a timeout returns the first result instead of acting twice.', 'fluent-booking-pro'),
                        ],
                    ],
                    'required'   => ['booking_id', 'action'],
                ],
                'annotations'         => [
                    'title'       => __('Manage booking note', 'fluent-booking-pro'),
                    'readonly'    => false,
                    'destructive' => true,
                    'idempotent'  => false,
                ],
                'permission_callback' => [PermissionGate::class, 'bookingWriteGate'],
                'execute_callback'    => [self::class, 'manage'],
            ],
        ];
    }

    /**
     * @param array $params
     * @return array|\WP_Error
     */
    public static function manage($params = [])
    {
        $action = sanitize_text_field(Arr::get($params, 'action', ''));

        if (!in_array($action, self::ACTIONS, true)) {
            return MCPHelper::error('missing_action', __('action must be create, update or delete.', 'fluent-booking-pro'));
        }

        $bookingId = absint(Arr::get($params, 'booking_id'));

        if (!$bookingId) {
            return MCPHelper::error('missing_booking_id', __('booking_id is required. Call list-bookings to find one.', 'fluent-booking-pro'));
        }

        $booking = Booking::with(['calendar_event'])->find($bookingId);

        if (!$booking) {
            return MCPHelper::error('booking_not_found', __('No booking with that id.', 'fluent-booking-pro'));
        }

        if (!BookingWriter::canWriteBooking($booking)) {
            return MCPHelper::error(
                'permission_denied',
                __('You do not have permission to change this booking.', 'fluent-booking-pro'),
                ['booking_id' => $bookingId]
            );
        }

        $noteId    = absint(Arr::get($params, 'note_id'));
        $activity  = null;
        $timezone  = MCPHelper::resolveTimezone(Arr::get($params, 'timezone', ''));
        $anchorId  = BookingNoteService::anchorId($booking);
        $entityKey = 'note:' . $anchorId . ':' . $action . ':' . $noteId;
        $digest    = WriteGuard::paramsDigest($params);

        if ($action !== 'create') {
            $activity = BookingNoteService::find($booking, $noteId);

            if (is_wp_error($activity)) {
                return MCPHelper::error('not_found', $activity->get_error_message(), ['note_id' => $noteId]);
            }
        }

        if (Arr::isTrue($params, 'dry_run')) {
            $preview = self::preview($booking, $action, $activity, $params);

            if (is_wp_error($preview)) {
                return $preview;
            }

            return MCPHelper::success(
                WriteGuard::preview(self::TOOL, $entityKey, self::fingerprint($booking, $activity), $preview, $digest),
                ['timezone' => $timezone],
                WriteGuard::CONFIRM_NEXT_STEP
            );
        }

        return WriteGuard::idempotent(self::TOOL, $entityKey, Arr::get($params, 'idempotency_key', ''), function () use ($booking, $action, $activity, $params, $timezone, $entityKey, $digest) {
            $confirmed = WriteGuard::confirm(
                self::TOOL,
                $entityKey,
                self::fingerprint($booking, $activity),
                Arr::get($params, 'confirm_token', ''),
                $digest
            );

            if (is_wp_error($confirmed)) {
                return $confirmed;
            }

            return self::execute($booking, $action, $activity, $params, $timezone);
        }, $digest, function ($ref) use ($timezone) {
            return self::replay($ref, $timezone);
        });
    }

    /**
     * @param Booking $booking
     * @param BookingActivity|null $activity
     * @return string
     */
    private static function fingerprint(Booking $booking, $activity)
    {
        $parts = [WriteGuard::bookingFingerprint($booking)];

        if ($activity) {
            $updated = $activity->updated_at instanceof \DateTimeInterface
                ? $activity->updated_at->format('Y-m-d H:i:s')
                : (string) $activity->updated_at;

            $parts[] = (int) $activity->id . '|' . $updated . '|' . md5((string) $activity->title . '|' . (string) $activity->description);
        }

        return implode('|', $parts);
    }

    /**
     * @param Booking $booking
     * @param string $action
     * @param BookingActivity|null $activity
     * @param array $params
     * @return array|\WP_Error
     */
    private static function preview(Booking $booking, $action, $activity, $params)
    {
        $anchorId = BookingNoteService::anchorId($booking);

        if ($action === 'delete') {
            return [
                'action'     => 'delete',
                'booking_id' => $anchorId,
                'note_id'    => (int) $activity->id,
                'title'      => MCPHelper::untrusted($activity->title, BookingNoteService::MAX_TITLE_LENGTH),
                'body'       => MCPHelper::untrusted($activity->description, BookingNoteService::MAX_LENGTH),
            ];
        }

        $body = BookingNoteService::normalizeBody(Arr::get($params, 'note', ''));

        if (is_wp_error($body)) {
            return MCPHelper::error($body->get_error_code(), $body->get_error_message());
        }

        $title = self::incomingTitle($params, $activity, $action);

        if (is_wp_error($title)) {
            return MCPHelper::error($title->get_error_code(), $title->get_error_message());
        }

        $preview = [
            'action'     => $action,
            'booking_id' => $anchorId,
            'title'      => MCPHelper::untrusted($title, BookingNoteService::MAX_TITLE_LENGTH),
            'body'       => MCPHelper::untrusted($body, BookingNoteService::MAX_LENGTH),
        ];

        if ($action === 'update') {
            $preview['note_id']       = (int) $activity->id;
            $preview['current_title'] = MCPHelper::untrusted($activity->title, BookingNoteService::MAX_TITLE_LENGTH);
            $preview['current_body']  = MCPHelper::untrusted($activity->description, BookingNoteService::MAX_LENGTH);
        }

        return $preview;
    }

    /**
     * Title the write will store. Update without a title parameter keeps the current one.
     *
     * @param array $params
     * @param BookingActivity|null $activity
     * @param string $action
     * @return string|\WP_Error
     */
    private static function incomingTitle($params, $activity, $action)
    {
        if (!array_key_exists('title', (array) $params)) {
            if ($action === 'update' && $activity) {
                return (string) $activity->title;
            }

            return BookingNoteService::storedTitle('', BookingNoteService::titleAuthorName());
        }

        $note = $action === 'update' ? $activity : null;

        return BookingNoteService::storedTitle(Arr::get($params, 'title', ''), BookingNoteService::titleAuthorName($note));
    }

    /**
     * @param Booking $booking
     * @param string $action
     * @param BookingActivity|null $activity
     * @param array $params
     * @param string $timezone
     * @return array|\WP_Error
     */
    private static function execute(Booking $booking, $action, $activity, $params, $timezone)
    {
        if ($action === 'delete') {
            $noteId = (int) $activity->id;
            $deleted = BookingNoteService::delete($booking, $activity);

            if (is_wp_error($deleted)) {
                return MCPHelper::error('not_found', $deleted->get_error_message());
            }

            return MCPHelper::success([
                'action'  => 'delete',
                'id'      => $noteId,
                'deleted' => true,
                'booking' => ['id' => BookingNoteService::anchorId($booking)],
            ], ['timezone' => $timezone]);
        }

        $body = Arr::get($params, 'note', '');
        $title = array_key_exists('title', (array) $params) ? Arr::get($params, 'title', '') : null;

        if ($action === 'update') {
            $note = BookingNoteService::update($booking, $activity, $body, $title);
        } else {
            $note = BookingNoteService::add($booking, $body, $title === null ? '' : $title);
        }

        if (is_wp_error($note)) {
            return MCPHelper::error($note->get_error_code(), $note->get_error_message());
        }

        return MCPHelper::success([
            'action'  => $action,
            'id'      => (int) $note->id,
            'booking' => ['id' => (int) $note->booking_id],
            'note'    => self::project($note, $timezone),
        ], ['timezone' => $timezone]);
    }

    /**
     * Rebuild a write's response from the ids the idempotency record kept.
     *
     * @param array $ref
     * @param string $timezone
     * @return array
     */
    private static function replay($ref, $timezone)
    {
        $action = sanitize_text_field(Arr::get($ref, 'action', ''));
        $noteId = (int) Arr::get($ref, 'id');
        $activity = $noteId ? BookingActivity::find($noteId) : null;

        if ($action === 'delete' || !$activity || $activity->type !== BookingActivity::TYPE_NOTE) {
            return MCPHelper::success([
                'action'  => $action ?: 'delete',
                'id'      => $noteId,
                'deleted' => true,
            ], ['timezone' => $timezone]);
        }

        return MCPHelper::success([
            'action' => $action,
            'id'     => (int) $activity->id,
            'note'   => self::project($activity, $timezone),
        ], ['timezone' => $timezone]);
    }

    /**
     * Every note on the booking's anchor, oldest first, for get-booking.
     *
     * @param Booking $booking
     * @param string $timezone
     * @return array
     */
    public static function projectAll(Booking $booking, $timezone)
    {
        $notes = [];

        $records = BookingActivity::where('booking_id', BookingNoteService::anchorId($booking))
            ->notes()
            ->orderBy('id', 'ASC')
            ->get();

        foreach ($records as $activity) {
            $notes[] = self::project($activity, $timezone);
        }

        return $notes;
    }

    /**
     * One note for an agent. The body is host-written and still untrusted,
     * because operators paste attendee mail into these.
     *
     * @param BookingActivity $activity
     * @param string $timezone
     * @return array
     */
    public static function project(BookingActivity $activity, $timezone)
    {
        return array_merge(
            [
                'id'         => (int) $activity->id,
                'title'      => MCPHelper::untrusted($activity->title, BookingNoteService::MAX_TITLE_LENGTH),
                'body'       => MCPHelper::untrusted($activity->description, BookingNoteService::MAX_LENGTH),
                'created_by' => $activity->created_by ? (int) $activity->created_by : null,
            ],
            MCPHelper::timePair($activity->created_at, $timezone, 'created'),
            MCPHelper::timePair($activity->updated_at, $timezone, 'updated')
        );
    }
}
