<?php

namespace BitApps\IntegrationsPro\Actions\MicrosoftExcel;

final class MicrosoftExcelService
{
    private const APPLY_TO = ['All', 'Contents', 'Formats'];

    public static function addWorksheetRow($response, $fieldData, $apiClient, $settings)
    {
        $excel = new MicrosoftExcelHelper($apiClient, $fieldData, $settings);
        $error = $excel->missing(['workbook_id', 'worksheet_id']);

        if ($error !== null) {
            return $error;
        }

        $cells = $excel->cells();

        if (empty($cells)) {
            return MicrosoftExcelHelper::failure(__('None of the mapped columns has a value', 'bit-integrations-pro'));
        }

        return $excel->appendRow($excel->value('worksheet_id'), $cells);
    }

    public static function updateWorksheetRow($response, $fieldData, $apiClient, $settings)
    {
        $excel = new MicrosoftExcelHelper($apiClient, $fieldData, $settings);
        $error = $excel->missing(['workbook_id', 'worksheet_id', 'row_number']);

        if ($error !== null) {
            return $error;
        }

        $row = self::rowNumber($excel->value('row_number'));

        if ($row === null) {
            // translators: %d: highest row number a worksheet can hold
            return MicrosoftExcelHelper::failure(wp_sprintf(__('Row Number must be a whole number from 1 to %d', 'bit-integrations-pro'), MicrosoftExcelHelper::MAX_ROW));
        }

        $cells = $excel->cells();

        if (empty($cells)) {
            return MicrosoftExcelHelper::failure(__('None of the mapped columns has a value', 'bit-integrations-pro'));
        }

        return $excel->writeRow($excel->value('worksheet_id'), $row, $cells);
    }

    public static function clearWorksheet($response, $fieldData, $apiClient, $settings)
    {
        $excel = new MicrosoftExcelHelper($apiClient, $fieldData, $settings);
        $error = $excel->missing(['workbook_id', 'worksheet']) ?? $excel->mappedButEmpty('range');

        if ($error !== null) {
            return $error;
        }

        $applyTo = \in_array($excel->value('apply_to'), self::APPLY_TO, true) ? $excel->value('apply_to') : 'All';

        return $excel->clear($excel->value('worksheet'), $excel->value('range'), $applyTo);
    }

    public static function addWorksheet($response, $fieldData, $apiClient, $settings)
    {
        $excel = new MicrosoftExcelHelper($apiClient, $fieldData, $settings);
        $error = $excel->missing(['workbook_id']) ?? $excel->mappedButEmpty('name');

        if ($error !== null) {
            return $error;
        }

        return $excel->addWorksheet($excel->value('name'));
    }

    public static function deleteWorksheet($response, $fieldData, $apiClient, $settings)
    {
        $excel = new MicrosoftExcelHelper($apiClient, $fieldData, $settings);
        $error = $excel->missing(['workbook_id', 'worksheet']);

        if ($error !== null) {
            return $error;
        }

        return $excel->deleteWorksheet($excel->value('worksheet'));
    }

    public static function createTable($response, $fieldData, $apiClient, $settings)
    {
        $excel = new MicrosoftExcelHelper($apiClient, $fieldData, $settings);
        $error = $excel->missing(['workbook_id', 'worksheet_id']) ?? $excel->mappedButEmpty('range');

        if ($error !== null) {
            return $error;
        }

        return $excel->createTable($excel->value('worksheet_id'), $excel->value('range'), $excel->value('has_headers') !== 'false');
    }

    public static function deleteTable($response, $fieldData, $apiClient, $settings)
    {
        $excel = new MicrosoftExcelHelper($apiClient, $fieldData, $settings);
        $error = $excel->missing(['workbook_id', 'table']);

        if ($error !== null) {
            return $error;
        }

        return $excel->deleteTable($excel->value('table'));
    }

    private static function rowNumber(string $value): ?int
    {
        if (!is_numeric($value)) {
            return null;
        }

        $number = (float) $value;

        if ($number !== floor($number) || $number < 1 || $number > MicrosoftExcelHelper::MAX_ROW) {
            return null;
        }

        return (int) $number;
    }
}
