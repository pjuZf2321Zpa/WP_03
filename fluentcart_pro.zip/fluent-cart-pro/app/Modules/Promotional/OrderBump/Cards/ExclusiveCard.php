<?php

namespace FluentCartPro\App\Modules\Promotional\OrderBump\Cards;

class ExclusiveCard extends AbstractCard
{
    public static function key(): string
    {
        return 'exclusive';
    }

    public static function title(): string
    {
        return __('Exclusive Card', 'fluent-cart-pro');
    }

    public static function description(): string
    {
        return __('A green card with the checkbox at the bottom.', 'fluent-cart-pro');
    }

    public static function content(): string
    {
        $checkbox = '<!-- wp:fluent-cart/order-bump-checkbox ' . wp_json_encode(['label' => sprintf(__('Grab it for %s', 'fluent-cart-pro'), '{{bump.price}}')]) . ' /-->';

        $prices = self::group(
            'fct_bump_exclusive_prices',
            self::element('original-price', 'fct_bump_exclusive_original')
            . "\n\n" . self::element('price', 'fct_bump_exclusive_price')
            . "\n\n" . self::element('savings', 'fct_bump_exclusive_savings')
        );

        $details = self::element('title', 'fct_bump_exclusive_badge') . "\n\n"
            . self::element('product-title', 'fct_bump_exclusive_product') . "\n\n"
            . self::element('variation-title', 'fct_bump_exclusive_variation') . "\n\n"
            . $prices;

        $bottomPrices = self::group(
            'fct_bump_exclusive_total',
            self::element('original-price', 'fct_bump_exclusive_original') . "\n\n" . self::element('price', 'fct_bump_exclusive_price')
        );

        return self::group(
            'fct_bump_exclusive',
            self::group(
                'fct_bump_exclusive_top',
                self::element('image', 'fct_bump_exclusive_icon') . "\n\n" . self::group('fct_bump_exclusive_details', $details)
            ) . "\n\n" . self::group('fct_bump_exclusive_bottom', $checkbox . "\n\n" . $bottomPrices)
        );
    }

    public static function css(): string
    {
        return <<<'CSS'
.fct_bump_exclusive {
    --fct-bx-green: #1f7a50;
    --fct-bx-line: #a6e0c0;
    --fct-bx-box: #2f9467;
    --fct-bx-box-hover: #1f6e4a;
    box-sizing: border-box;
    border: 1px dashed var(--fct-bx-line);
    border-radius: 8px;
    background: #effcf5;
    overflow: hidden;
}
.fct_bump_exclusive p,
.fct_bump_exclusive figure {
    margin: 0;
}
.fct_bump_exclusive_top {
    display: flex;
    align-items: center;
    column-gap: 12px;
    padding: 18px 12px;
    border-bottom: 1px dashed var(--fct-bx-line);
}
.fct_bump_exclusive_icon {
    flex: 0 0 auto;
    width: 60px;
    height: 60px;
    border-radius: 8px;
    overflow: hidden;
    background: #f3f4f6;
}
.fct_bump_exclusive_icon img {
    display: block;
    width: 100%;
    height: 100%;
    object-fit: cover;
}
.fct_bump_exclusive_details {
    flex: 1;
    min-width: 0;
    line-height: 1.35;
}
.fct_bump_exclusive_badge {
    font-size: 12px;
    color: var(--fct-bx-green);
}
.fct_bump_exclusive_product {
    font-size: 15px;
    font-weight: 600;
    color: var(--fct-primary-text-color, #111827);
}
.fct_bump_exclusive_variation {
    font-size: 13px;
    color: var(--fct-secondary-text-color, #6b7280);
}
.fct_bump_exclusive_badge:empty,
.fct_bump_exclusive_variation:empty,
.fct_bump_exclusive_original:empty,
.fct_bump_exclusive_savings:empty {
    display: none;
}
.fct_bump_exclusive_prices,
.fct_bump_exclusive_total {
    display: flex;
    flex-wrap: wrap;
    align-items: baseline;
    column-gap: 8px;
}
.fct_bump_exclusive_prices {
    font-size: 14px;
}
.fct_bump_exclusive_original {
    text-decoration: line-through;
    color: var(--fct-secondary-text-color, #6b7280);
}
.fct_bump_exclusive_price {
    font-weight: 600;
    color: var(--fct-primary-text-color, #111827);
}
.fct_bump_exclusive_savings {
    color: #c0392b;
}
.fct_bump_exclusive_bottom {
    position: relative;
    display: flex;
    align-items: center;
    justify-content: space-between;
    column-gap: 12px;
    padding: 10px 12px;
    color: var(--fct-bx-green);
}
.fct_bump_exclusive .fct_bump_exclusive_bottom label.fct_order_promotion_toggle {
    display: flex;
    flex: 1;
    align-items: center;
    column-gap: 8px;
    margin: 0;
    padding: 0;
    font-size: 14px;
    font-weight: 600;
    color: var(--fct-bx-green);
    cursor: pointer;
}
/* Stretches the label over the row so the prices are clickable too. */
.fct_bump_exclusive_bottom label.fct_order_promotion_toggle::after {
    content: "";
    position: absolute;
    inset: 0;
}
.fct_bump_exclusive_total {
    font-size: 14px;
}
.fct_bump_exclusive_total .fct_bump_exclusive_original {
    color: #7fbf9f;
}
.fct_bump_exclusive_total .fct_bump_exclusive_price {
    color: var(--fct-bx-green);
}
/* Doubled class: the drawer and cart page checkbox rules load after this stylesheet. */
.fct_bump_exclusive.fct_bump_exclusive input.fct_order_promotion_input {
    appearance: none;
    -webkit-appearance: none;
    position: relative;
    display: block;
    flex: none;
    box-sizing: border-box;
    width: 16px;
    height: 16px;
    min-width: 16px;
    margin: 0;
    padding: 0;
    background: #fff;
    border: 1px solid var(--fct-bx-box);
    border-radius: 3px;
    cursor: pointer;
}
.fct_bump_exclusive.fct_bump_exclusive input.fct_order_promotion_input:hover,
.fct_bump_exclusive.fct_bump_exclusive .fct_bump_exclusive_bottom:hover input.fct_order_promotion_input {
    border-color: var(--fct-bx-box-hover);
}
.fct_bump_exclusive.fct_bump_exclusive input.fct_order_promotion_input::before {
    content: "";
    position: absolute;
    top: 1px;
    left: 4px;
    box-sizing: border-box;
    width: 5px;
    height: 9px;
    border: solid #fff;
    border-width: 0 1.5px 1.5px 0;
    transform: rotate(45deg);
    opacity: 0;
}
.fct_bump_exclusive.fct_bump_exclusive input.fct_order_promotion_input:checked {
    background: var(--fct-bx-box);
    border-color: var(--fct-bx-box);
}
.fct_bump_exclusive.fct_bump_exclusive input.fct_order_promotion_input:checked:hover,
.fct_bump_exclusive.fct_bump_exclusive .fct_bump_exclusive_bottom:hover input.fct_order_promotion_input:checked {
    background: var(--fct-bx-box-hover);
    border-color: var(--fct-bx-box-hover);
}
.fct_bump_exclusive.fct_bump_exclusive input.fct_order_promotion_input:checked::before {
    opacity: 1;
}
.fct_bump_exclusive.fct_bump_exclusive input.fct_order_promotion_input:focus-visible {
    outline: 2px solid var(--fct-bx-box-hover);
    outline-offset: 2px;
}
CSS;
    }
}
