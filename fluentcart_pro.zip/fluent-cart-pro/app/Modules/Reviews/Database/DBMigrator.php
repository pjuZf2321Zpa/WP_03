<?php

namespace FluentCartPro\App\Modules\Reviews\Database;

require_once(ABSPATH . 'wp-admin/includes/upgrade.php');

class DBMigrator
{
    public function run($networkWide = false)
    {
        $this->migrate();
    }

    public function migrate()
    {
        Migrations\ReviewInteractionsMigrator::migrate();
    }

    public function dropTable()
    {
        Migrations\ReviewInteractionsMigrator::dropTable();
    }
}
