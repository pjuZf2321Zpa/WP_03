<?php

namespace FluentCartPro\App\Modules\Promotional\OrderBump;

/**
 * One card design is active for the checkout, the cart drawer and the cart page.
 * It is kept like the other settings pages keep theirs: fluent_cart_update_option, in fct_meta.
 */
class OrderBumpSettings
{
    const OPTION_KEY = 'order_bump_settings';

    const TEMPLATES = ['classic', 'compact', 'highlight', 'exclusive', 'callout', 'toggle'];

    const DEFAULT_TEMPLATE = 'classic';

    const LOCK = 'fct_order_bump_settings';

    /**
     * @return string[] The built-in cards and the custom cards an admin added.
     */
    public static function allKeys(bool $fresh = false): array
    {
        return array_merge(self::TEMPLATES, array_keys(OrderBumpTemplateService::customTitles($fresh)));
    }

    public static function get(bool $fresh = false): array
    {
        $stored = fluent_cart_get_option(self::OPTION_KEY, [], !$fresh);

        return is_array($stored) ? $stored : [];
    }

    public static function activeTemplate(): string
    {
        $settings = self::get();
        $template = isset($settings['template']) ? $settings['template'] : '';

        // A built-in card needs no look at the list of custom cards, which keeps the usual shop request as it was.
        if (in_array($template, self::TEMPLATES, true)) {
            return $template;
        }

        return in_array($template, self::allKeys(), true) ? $template : self::DEFAULT_TEMPLATE;
    }

    /**
     * @param mixed $template
     * @return array|\WP_Error The saved settings, a 422 error for an unknown template, or a 409 when busy.
     */
    public static function save($template)
    {
        $invalid = new \WP_Error('invalid_template', __('Please choose a valid card.', 'fluent-cart-pro'), ['status' => 422]);
        if (!is_string($template)) {
            return $invalid;
        }

        try {
            return NamedLock::run(self::LOCK, function () use ($template, $invalid) {
                // Read again under the lock: a card may have been deleted since this request started.
                if (!in_array($template, self::allKeys(true), true)) {
                    return $invalid;
                }

                $settings = self::get(true);
                $settings['template'] = $template;
                fluent_cart_update_option(self::OPTION_KEY, $settings);

                return ['template' => $template];
            });
        } catch (RegistryBusyException $e) {
            return new \WP_Error('busy', __('Another change is being saved. Please try again.', 'fluent-cart-pro'), ['status' => 409]);
        }
    }

    /**
     * Puts the default card back, but only if the stored choice is still $key.
     * A card another admin chose in the meantime stays.
     *
     * @throws RegistryBusyException When another request holds the lock.
     */
    public static function resetIfActive(string $key): void
    {
        NamedLock::run(self::LOCK, function () use ($key) {
            $settings = self::get(true);
            if (($settings['template'] ?? '') === $key) {
                $settings['template'] = self::DEFAULT_TEMPLATE;
                fluent_cart_update_option(self::OPTION_KEY, $settings);
            }
        });
    }
}
