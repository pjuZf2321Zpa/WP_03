<?php

(new \FluentCartPro\App\Modules\Reviews\Hooks\Handlers\ReviewMediaHandler())->register();
(new \FluentCartPro\App\Modules\Reviews\Hooks\Handlers\ReviewVoteHandler())->register();
(new \FluentCartPro\App\Modules\Reviews\Hooks\Handlers\ReviewAssetHandler())->register();
(new \FluentCartPro\App\Modules\Reviews\Hooks\Handlers\AdminReviewMediaHandler())->register();
