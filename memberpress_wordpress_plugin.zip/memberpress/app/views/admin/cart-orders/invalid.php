<?php
if (!defined('ABSPATH')) {
    die('You are not allowed to call this page directly.');
}
?>
<div class="wrap">
    <h1><?php esc_html_e('Cart Orders', 'memberpress'); ?></h1>
    <div class="notice notice-error">
        <p><?php esc_html_e('Invalid order.', 'memberpress'); ?></p>
    </div>
    <p>
        <a href="<?php echo esc_url(admin_url('admin.php?page=memberpress-orders')); ?>">
            &larr; <?php esc_html_e('Back to Orders', 'memberpress'); ?>
        </a>
    </p>
</div>
