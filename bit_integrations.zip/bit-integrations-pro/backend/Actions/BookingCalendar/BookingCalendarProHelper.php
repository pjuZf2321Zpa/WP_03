<?php

namespace BitApps\IntegrationsPro\Actions\BookingCalendar;

final class BookingCalendarProHelper
{
    public static function createBooking($defaultResponse, $fieldData, $utilities = [], $integrationDetails = null)
    {
        if (!self::isPluginInstalled()) {
            return self::errorResponse(__('Booking Calendar is not installed or activated', 'bit-integrations-pro'));
        }

        if (!\function_exists('wpbc_api_booking_add_new')) {
            return self::errorResponse(__('Required Booking Calendar function wpbc_api_booking_add_new is not available', 'bit-integrations-pro'));
        }

        $dates = self::normalizeBookingDates($fieldData['dates'] ?? '');

        if (empty($dates)) {
            return self::errorResponse(__('At least one booking date is required', 'bit-integrations-pro'));
        }

        $invalidDates = self::getInvalidBookingDates($dates);

        if (!empty($invalidDates)) {
            return self::errorResponse(wp_sprintf(__('Invalid booking date: %s', 'bit-integrations-pro'), reset($invalidDates)));
        }

        $resourceId = self::getIntegrationInt($integrationDetails, 'resourceId', $fieldData['resource_id'] ?? 1);
        $bookingId = wpbc_api_booking_add_new(
            $dates,
            self::normalizeBookingData($fieldData),
            $resourceId > 0 ? $resourceId : 1,
            self::buildBookingParams($fieldData, $utilities)
        );

        if (is_wp_error($bookingId)) {
            return self::errorResponse($bookingId->get_error_message());
        }

        $booking = self::getBookingData((int) $bookingId);

        if (empty($booking)) {
            return self::errorResponse(__('Booking not found in Booking Calendar', 'bit-integrations-pro'));
        }

        return self::successResponse(__('Booking created successfully', 'bit-integrations-pro'), [
            'booking_id' => (int) $bookingId,
            'booking'    => $booking,
        ]);
    }

    public static function updateBooking($defaultResponse, $fieldData, $utilities = [], $integrationDetails = null)
    {
        if (!self::isPluginInstalled()) {
            return self::errorResponse(__('Booking Calendar is not installed or activated', 'bit-integrations-pro'));
        }

        if (!\function_exists('wpbc_api_booking_add_new')) {
            return self::errorResponse(__('Required Booking Calendar function wpbc_api_booking_add_new is not available', 'bit-integrations-pro'));
        }

        $bookingId = self::getIntegrationInt($integrationDetails, 'bookingId', $fieldData['booking_id'] ?? 0);

        if ($bookingId <= 0) {
            return self::errorResponse(__('Booking ID is required', 'bit-integrations-pro'));
        }

        $booking = self::getBookingData($bookingId);

        if (empty($booking)) {
            return self::errorResponse(__('Booking not found in Booking Calendar', 'bit-integrations-pro'));
        }

        $dates = self::normalizeBookingDates($fieldData['dates'] ?? '');

        if (empty($dates)) {
            return self::errorResponse(__('At least one booking date is required', 'bit-integrations-pro'));
        }

        $invalidDates = self::getInvalidBookingDates($dates);

        if (!empty($invalidDates)) {
            return self::errorResponse(wp_sprintf(__('Invalid booking date: %s', 'bit-integrations-pro'), reset($invalidDates)));
        }

        $resourceId = self::getIntegrationInt(
            $integrationDetails,
            'resourceId',
            !empty($booking['booking_type']) ? (int) $booking['booking_type'] : 1
        );
        $params = self::buildBookingParams($fieldData, $utilities);
        $params['is_edit_booking'] = [
            'booking_id'   => $bookingId,
            'booking_type' => $resourceId > 0 ? $resourceId : 1,
        ];

        $updatedBookingId = wpbc_api_booking_add_new(
            $dates,
            self::normalizeBookingData($fieldData),
            $resourceId > 0 ? $resourceId : 1,
            $params
        );

        if (is_wp_error($updatedBookingId)) {
            return self::errorResponse($updatedBookingId->get_error_message());
        }

        $booking = self::getBookingData($bookingId);

        if (empty($booking)) {
            return self::errorResponse(__('Booking not found in Booking Calendar', 'bit-integrations-pro'));
        }

        return self::successResponse(__('Booking updated successfully', 'bit-integrations-pro'), [
            'booking_id' => $bookingId,
            'booking'    => $booking,
        ]);
    }

    private static function isPluginInstalled()
    {
        return \defined('WP_BK_VERSION_NUM') || \defined('WPBC_FILE') || \function_exists('wpbc_api_booking_add_new');
    }

    private static function getIntegrationInt($integrationDetails, $property, $fallback = 0)
    {
        if (\is_object($integrationDetails) && isset($integrationDetails->{$property}) && $integrationDetails->{$property} !== '') {
            return (int) $integrationDetails->{$property};
        }

        return (int) $fallback;
    }

    private static function normalizeBookingDates($value)
    {
        if (empty($value)) {
            return [];
        }

        $dates = self::decodeArray($value);

        if (empty($dates) && !\is_array($value) && trim((string) $value) !== '[]') {
            $dates = preg_split('/[\r\n,]+/', (string) $value);
        }

        $normalized = [];

        foreach ((array) $dates as $date) {
            $date = trim((string) $date);

            if ($date !== '') {
                $normalized[] = $date;
            }
        }

        return $normalized;
    }

    private static function getInvalidBookingDates(array $dates)
    {
        $invalidDates = [];

        foreach ($dates as $date) {
            if (!self::isParsableBookingDate($date)) {
                $invalidDates[] = $date;
            }
        }

        return $invalidDates;
    }

    private static function isParsableBookingDate($date)
    {
        $date = trim((string) $date);

        if ($date === '' || strtotime($date) === false) {
            return false;
        }

        if (preg_match('/^(\d{4})-(\d{2})-(\d{2})/', $date, $matches)) {
            return checkdate((int) $matches[2], (int) $matches[3], (int) $matches[1]);
        }

        if (preg_match('/^(\d{1,2})\.(\d{1,2})\.(\d{4})/', $date, $matches)) {
            return checkdate((int) $matches[2], (int) $matches[1], (int) $matches[3]);
        }

        return true;
    }

    private static function normalizeBookingData(array $fieldData)
    {
        $bookingData = [];

        foreach (['name', 'secondname', 'phone'] as $field) {
            if (!empty($fieldData[$field])) {
                $bookingData[$field] = (string) $fieldData[$field];
            }
        }

        if (!empty($fieldData['email'])) {
            $bookingData['email'] = [
                'type'  => 'email',
                'value' => (string) $fieldData['email'],
            ];
        }

        if (!empty($fieldData['details'])) {
            $bookingData['details'] = [
                'type'  => 'textarea',
                'value' => wp_kses_post((string) $fieldData['details']),
            ];
        }

        if (!empty($fieldData['rangetime'])) {
            $bookingData['rangetime'] = [
                'type'  => 'selectbox-one',
                'value' => (string) $fieldData['rangetime'],
            ];
        }

        $extraFields = self::decodeArray($fieldData['booking_data_json'] ?? []);

        foreach ($extraFields as $field => $value) {
            $field = (string) $field;

            if ($field === '') {
                continue;
            }

            if (\is_array($value) && \array_key_exists('value', $value)) {
                $bookingData[$field] = [
                    'type'  => (string) ($value['type'] ?? 'text'),
                    'value' => self::normalizeScalar($value['value']),
                ];

                continue;
            }

            $bookingData[$field] = self::normalizeScalar($value);
        }

        return $bookingData;
    }

    private static function buildBookingParams(array $fieldData, $utilities = [])
    {
        return [
            'is_send_emeils'                   => self::getBooleanParam($fieldData, $utilities, 'is_send_emails'),
            'booking_form_type'                => (string) ($fieldData['booking_form_type'] ?? ''),
            'wpdev_active_locale'              => (string) ($fieldData['locale'] ?? get_locale()),
            'is_show_payment_form'             => self::getBooleanParam($fieldData, $utilities, 'is_show_payment_form'),
            'is_approve_booking'               => self::getBooleanParam($fieldData, $utilities, 'is_approve_booking'),
            'save_booking_even_if_unavailable' => self::getBooleanParam($fieldData, $utilities, 'save_booking_even_if_unavailable'),
            'is_use_booking_recurrent_time'    => self::getBooleanParam($fieldData, $utilities, 'is_use_booking_recurrent_time'),
        ];
    }

    private static function getBooleanParam(array $fieldData, $utilities, $key)
    {
        $value = self::getUtilityValue($utilities, $key, $fieldData[$key] ?? 0);

        if (\is_bool($value)) {
            return $value ? 1 : 0;
        }

        if (\is_numeric($value)) {
            return (int) $value > 0 ? 1 : 0;
        }

        if (\is_array($value) || \is_object($value)) {
            return 0;
        }

        return \in_array(\strtolower(trim((string) $value)), ['1', 'true', 'yes', 'on'], true) ? 1 : 0;
    }

    private static function getUtilityValue($utilities, $key, $fallback = null)
    {
        if (\is_array($utilities) && \array_key_exists($key, $utilities)) {
            return $utilities[$key];
        }

        if (\is_object($utilities) && \property_exists($utilities, $key)) {
            return $utilities->{$key};
        }

        return $fallback;
    }

    private static function getBookingData($bookingId)
    {
        global $wpdb;

        $bookingId = (int) $bookingId;

        if ($bookingId <= 0) {
            return [];
        }

        $table = self::resolveTable('booking');

        if (empty($table)) {
            return [];
        }

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $booking = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table} WHERE booking_id = %d", $bookingId), ARRAY_A);

        if (empty($booking)) {
            return [];
        }

        $booking['booking_id'] = (int) $booking['booking_id'];
        $booking['booking_type'] = (int) $booking['booking_type'];
        $booking['is_new'] = (int) $booking['is_new'];
        $booking['trash'] = (int) $booking['trash'];
        $booking['dates'] = self::getBookingDates($bookingId);
        $booking['form_fields'] = self::parseBookingForm((string) ($booking['form'] ?? ''));
        $booking['booking_options_array'] = maybe_unserialize($booking['booking_options'] ?? '');

        return $booking;
    }

    private static function getBookingDates($bookingId)
    {
        global $wpdb;

        $table = self::resolveTable('bookingdates');

        if (empty($table)) {
            return [];
        }

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $rows = $wpdb->get_results($wpdb->prepare("SELECT * FROM {$table} WHERE booking_id = %d ORDER BY booking_date ASC", (int) $bookingId), ARRAY_A);

        if (empty($rows) || !\is_array($rows)) {
            return [];
        }

        foreach ($rows as &$row) {
            $row['booking_dates_id'] = (int) $row['booking_dates_id'];
            $row['booking_id'] = (int) $row['booking_id'];
            $row['approved'] = (int) $row['approved'];
        }

        return $rows;
    }

    private static function parseBookingForm($formData)
    {
        $fields = [];

        foreach (explode('~', (string) $formData) as $field) {
            if ($field === '') {
                continue;
            }

            $parts = explode('^', $field, 3);

            if (\count($parts) < 3) {
                continue;
            }

            $fields[] = [
                'type'  => (string) $parts[0],
                'name'  => (string) $parts[1],
                'value' => (string) $parts[2],
            ];
        }

        return $fields;
    }

    private static function decodeArray($value)
    {
        if (\is_array($value)) {
            return $value;
        }

        if (empty($value)) {
            return [];
        }

        $decoded = json_decode((string) $value, true);

        return \is_array($decoded) ? $decoded : [];
    }

    private static function normalizeScalar($value)
    {
        if (\is_bool($value) || \is_int($value) || \is_float($value) || $value === null) {
            return $value;
        }

        if (\is_array($value) || \is_object($value)) {
            return wp_json_encode($value);
        }

        return (string) $value;
    }

    private static function resolveTable($suffix)
    {
        global $wpdb;

        $tables = [
            'booking'      => 'booking',
            'bookingdates' => 'bookingdates',
        ];

        if (!isset($tables[(string) $suffix])) {
            return;
        }

        $table = $wpdb->prefix . $tables[(string) $suffix];

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $found = $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $wpdb->esc_like($table)));

        if ($found !== $table) {
            return;
        }

        return $table;
    }

    private static function successResponse($message, $data = [])
    {
        return [
            'success' => true,
            'message' => $message,
            'data'    => $data
        ];
    }

    private static function errorResponse($message)
    {
        return [
            'success' => false,
            'message' => $message
        ];
    }
}
