<?php

namespace FluentCartPro\App\Hooks\Handlers\BlockEditors\PdfBlocks;

use FluentCart\App\Hooks\Handlers\BlockEditors\BlockEditor;

class ReceiptMetaBlockEditor extends BlockEditor
{
    use \FluentCartPro\App\Contracts\CanEnqueue;

    protected static string $editorName = 'receipt-meta';

    private const DEFAULT_ROWS = [
        ['label' => 'Order Number', 'value' => '{{order.invoice_no}}'],
        ['label' => 'Order Date', 'value' => '{{order.created_at}}'],
        ['label' => 'Payment Method', 'value' => '{{order.payment_method_title}}'],
        ['label' => 'Payment Status', 'value' => '{{order.payment_status}}'],
    ];

    public function getScripts(): array
    {
        return [
            [
                'source'       => 'admin/BlockEditor/PdfBlocks/ReceiptMetaBlockEditor.jsx',
                'dependencies' => ['wp-blocks', 'wp-components', 'wp-block-editor']
            ]
        ];
    }

    public function getStyles(): array
    {
        return [];
    }

    public function localizeData(): array
    {
        return [
            $this->getLocalizationKey() => [
                'slug'        => $this->slugPrefix,
                'name'        => static::getEditorName(),
                'title'       => __('Receipt Meta', 'fluent-cart-pro'),
                'description' => __('Order metadata table (order number, date, payment method) for PDF receipts.', 'fluent-cart-pro'),
            ],
            'fluent_cart_block_translation' => \FluentCart\App\Services\Translations\TransStrings::blockStrings(),
        ];
    }

    public function blockAttributes(): array
    {
        return [
            'labelColor'    => ['type' => 'string', 'default' => '#525866'],
            'valueColor'    => ['type' => 'string', 'default' => '#0E121B'],
            'labelFontSize' => ['type' => 'number', 'default' => 11],
            'valueFontSize' => ['type' => 'number', 'default' => 12],
            'rows'          => [
                'type'    => 'array',
                'default' => self::DEFAULT_ROWS,
                'items'   => ['type' => 'object'],
            ],
        ];
    }

    public function supports(): array
    {
        return [
            'html'    => false,
            'align'   => false,
            'spacing' => ['margin' => true, 'padding' => true],
        ];
    }

    public function render(array $attrs, $block = null, $content = ''): string
    {
        $labelColor = esc_attr($attrs['labelColor'] ?? '#525866');
        $valueColor = esc_attr($attrs['valueColor'] ?? '#0E121B');
        $labelFs    = (int)($attrs['labelFontSize'] ?? 11);
        $valueFs    = (int)($attrs['valueFontSize'] ?? 12);
        $rows       = $this->resolveRows($attrs, $content);

        $border     = '1px solid #DDDDDD';
        $labelStyle = "padding:7px 0;font-size:{$labelFs}px;color:{$labelColor};border-bottom:{$border};";
        $valueStyle = "padding:7px 0;font-size:{$valueFs}px;color:{$valueColor};text-align:right;border-bottom:{$border};";

        $html = '<table width="100%" cellspacing="0" cellpadding="0" border="0"'
              . ' style="margin-bottom:24px;border-collapse:collapse;border-top:' . $border . ';">';
        foreach ($rows as $row) {
            $label = wp_kses_post($row['label'] ?? '');
            $value = wp_kses_post($row['value'] ?? '');
            // The class lets the PDF service drop a row whose value parses to empty.
            $html .= '<tr class="fct-receipt-meta-row">'
                   . '<td style="' . $labelStyle . '">' . $label . '</td>'
                   . '<td style="' . $valueStyle . '">' . $value . '</td>'
                   . '</tr>';
        }
        $html .= '</table>';

        return $html;
    }

    private function resolveRows(array $attrs, string $content): array
    {
        $rows = $this->extractRowsFromTableMarkup($content);

        if ($rows) {
            return $rows;
        }

        return $attrs['rows'] ?? self::DEFAULT_ROWS;
    }

    private function extractRowsFromTableMarkup(string $content): array
    {
        if (!$content || !preg_match('/<table[^>]*>(.*?)<\/table>/is', $content, $tableMatches)) {
            return [];
        }

        if (!preg_match_all('/<tr[^>]*>(.*?)<\/tr>/is', $tableMatches[1], $rowMatches)) {
            return [];
        }

        $rows = [];

        foreach ($rowMatches[1] as $rowMarkup) {
            if (!preg_match_all('/<(td|th)\b[^>]*>(.*?)<\/\1>/is', $rowMarkup, $cellMatches)) {
                continue;
            }

            if (count($cellMatches[2]) < 2) {
                continue;
            }

            $rows[] = [
                'label' => $cellMatches[2][0] ?? '',
                'value' => $cellMatches[2][1] ?? '',
            ];
        }

        return $rows;
    }
}
