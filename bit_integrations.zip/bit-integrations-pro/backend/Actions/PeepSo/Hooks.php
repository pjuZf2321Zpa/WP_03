<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Actions\PeepSo\PeepSoProHelper;
use BitApps\IntegrationsPro\Config;
use BitApps\IntegrationsPro\Core\Util\Hooks;

Hooks::filter(Config::withFreePrefix('peepso_add_post_activity_stream'), [PeepSoProHelper::class, 'addPostActivityStream'], 10, 2);
Hooks::filter(Config::withFreePrefix('peepso_change_user_role'), [PeepSoProHelper::class, 'changeUserRole'], 10, 2);
Hooks::filter(Config::withFreePrefix('peepso_follow_user'), [PeepSoProHelper::class, 'followUser'], 10, 2);
