<?php

declare(strict_types=1);

namespace FluentCartPro\App\Services\Invoice\Profile;

if (!defined('ABSPATH')) {
    exit;
}

use FluentCartPro\App\Services\Invoice\Domain\CalculatedTotals;
use FluentCartPro\App\Services\Invoice\Domain\En16931Invoice;

/**
 * EN 16931 profile: BR-Z-02, BR-CO-09, BR-CO-26, required fields.
 */
final class ZugferdEn16931Profile implements InvoiceProfileInterface
{
    public function getProfileId(): string
    {
        return 'urn:cen.eu:en16931:2017';
    }

    public function getSyntax(): string
    {
        return 'CII';
    }

    public function validate(En16931Invoice $invoice, CalculatedTotals $totals): void
    {
        // BT-1: Invoice number is mandatory
        if ($invoice->invoiceNumber === '') {
            throw new \InvalidArgumentException(__('Invoice number is required for EN 16931.', 'fluent-cart-pro'));
        }

        // BT-2: Issue date is mandatory
        if ($invoice->issueDate === null || $invoice->issueDate === '') {
            throw new \InvalidArgumentException(__('Invoice issue date is required for EN 16931.', 'fluent-cart-pro'));
        }

        // BT-5: Currency is mandatory
        if ($invoice->currency === '') {
            throw new \InvalidArgumentException(__('Invoice currency is required for EN 16931.', 'fluent-cart-pro'));
        }

        // BT-27: Seller name is mandatory
        if ($invoice->seller->name === '') {
            throw new \InvalidArgumentException(__('Seller name is required for EN 16931.', 'fluent-cart-pro'));
        }

        // BT-40: Seller country code is mandatory
        if ($invoice->seller->country_code === '') {
            throw new \InvalidArgumentException(__('Seller country is required for EN 16931. Please set the store country in Settings → Store Settings.', 'fluent-cart-pro'));
        }

        // BT-44: Buyer name is mandatory
        if ($invoice->buyer->company_name === '' && $invoice->buyer->customer_name === '') {
            throw new \InvalidArgumentException(__('Buyer name (company or customer) is required for EN 16931.', 'fluent-cart-pro'));
        }

        // At least one invoice line is required
        if (empty($invoice->lines)) {
            throw new \InvalidArgumentException(__('At least one invoice line is required for EN 16931.', 'fluent-cart-pro'));
        }

        foreach ($invoice->lines as $line) {
            if ($line->netUnitPrice->getAmountInCents() < 0) {
                throw new \InvalidArgumentException(__('E-invoice cannot contain a negative item net price.', 'fluent-cart-pro'));
            }
        }

        // BR-E-10: A VAT breakdown group with category Exempt (E) must carry an exemption reason
        // (text and/or code).
        foreach ($totals->taxSummaries as $summary) {
            if ($summary->taxCategory === 'E'
                && $summary->exemptionReasonText === ''
                && $summary->exemptionReasonCode === '') {
                throw new \InvalidArgumentException(
                    __('A VAT exemption reason is required for EN 16931 when the invoice contains VAT-exempt (category E) amounts.', 'fluent-cart-pro')
                );
            }
        }

        // BR-AE-*: Reverse charge (category AE) requires the seller VAT identifier (or legal
        // registration), the buyer VAT identifier, and a VAT exemption reason. Enforced only
        // when an AE group is present, so standard/zero/exempt invoices are unaffected.
        $aeReasonPresent = false;
        $hasAe           = false;
        foreach ($totals->taxSummaries as $summary) {
            if ($summary->taxCategory !== 'AE') {
                continue;
            }
            $hasAe = true;
            if ($summary->exemptionReasonText !== '' || $summary->exemptionReasonCode !== '') {
                $aeReasonPresent = true;
            }
        }
        if ($hasAe) {
            $hasSellerVat = $invoice->seller->vat_id !== null && $invoice->seller->vat_id !== '';
            $hasLegalReg  = $invoice->seller->legal_registration_id !== '';
            if (!$hasSellerVat && !$hasLegalReg) {
                throw new \InvalidArgumentException(
                    __('Seller VAT identifier is required for EN 16931 reverse-charge (category AE) invoices. Please set the Seller VAT ID in Settings → PDF Templates → Settings.', 'fluent-cart-pro')
                );
            }
            if ($invoice->buyer->buyer_vat_id === '') {
                throw new \InvalidArgumentException(
                    __('Buyer VAT identifier is required for EN 16931 reverse-charge (category AE) invoices.', 'fluent-cart-pro')
                );
            }
            if (!$aeReasonPresent) {
                throw new \InvalidArgumentException(
                    __('A VAT exemption reason is required for EN 16931 reverse-charge (category AE) invoices.', 'fluent-cart-pro')
                );
            }
        }

        // BR-S-02: When any line has standard-rate VAT, seller must have VAT ID or legal registration ID.
        if ($invoice->hasStandardRateVat()) {
            $hasSellerVat = $invoice->seller->vat_id !== null && $invoice->seller->vat_id !== '';
            $hasLegalReg  = $invoice->seller->legal_registration_id !== '';
            if (!$hasSellerVat && !$hasLegalReg) {
                throw new \InvalidArgumentException(
                    __('Seller VAT identifier is required for EN 16931 when the invoice contains standard-rated (VAT) lines. Please set the Seller VAT ID in Settings → PDF Templates → Settings.', 'fluent-cart-pro')
                );
            }
        }
    }
}
