<?php

namespace FluentCartPro\App\Modules\MultiCurrency;

use FluentCart\App\Modules\MultiCurrency\Services\CurrencyContext;
use FluentCartPro\App\Services\Translations\Translations;
use FluentCartPro\App\Utils\Enqueuer\Vite;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Adds the Switcher Settings panel to core's Currency Switcher block.
 * Core keeps the block and its attributes; without Pro it shows the Pro gate.
 */
class CurrencySwitcherEditor
{
    public function register(): void
    {
        // Needs core with multi-currency
        if (!class_exists(CurrencyContext::class)) {
            return;
        }

        add_action('enqueue_block_editor_assets', [$this, 'enqueue']);
    }

    public function enqueue(): void
    {
        // Core's block script is not a dependency: editor.BlockEdit runs at render time
        Vite::enqueueScript(
            'fct-pro-currency-switcher-editor',
            'admin/BlockEditor/CurrencySwitcher/currency-switcher-editor.jsx',
            [
                'wp-hooks',
                'wp-compose',
                'wp-block-editor',
                'wp-components',
                'wp-element',
            ],
            FLUENTCART_PRO_PLUGIN_VERSION,
            true
        )->with([
            'fluent_cart_pro_block_translation' => Translations::blockStrings(),
        ]);
    }
}
