<?php

class MeowPro_MWSEO_Core
{
  private $core = null;
  private $item = 'SEO Engine Pro';
  public $magic_fix = null;
  public $search_console = null;
  public $ai_visibility = null;

  function __construct($core)
  {
    $this->core = $core;
    add_action( 'init', array( $this, 'init' ) );

    // Initialize Magic Fix (premium feature)
    require_once( MWSEO_PATH . '/premium/magicfix.php' );
    $this->magic_fix = new MeowPro_MWSEO_MagicFix( $core );

    // Initialize Search Console (premium feature)
    require_once( MWSEO_PATH . '/premium/searchconsole.php' );
    $this->search_console = new MeowPro_MWSEO_SearchConsole( $core );

    // Initialize AI Visibility (premium feature)
    require_once( MWSEO_PATH . '/premium/aivisibility.php' );
    $this->ai_visibility = new MeowPro_MWSEO_Aivisibility( $core );
  }

  function init()
  {
    new MeowKitPro_MWSEO_Licenser( MWSEO_PREFIX, MWSEO_ENTRY,
      MWSEO_DOMAIN, $this->item, MWSEO_VERSION );
  }
}
