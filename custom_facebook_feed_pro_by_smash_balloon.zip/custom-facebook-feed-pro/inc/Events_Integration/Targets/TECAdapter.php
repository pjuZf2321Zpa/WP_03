<?php
/**
 * The Events Calendar target adapter: writes events exclusively through
 * TEC's public API; venues are created from the Facebook place data and
 * reused via an option map.
 *
 * @package CustomFacebookFeed\Events_Integration
 * @since 4.11
 */

namespace CustomFacebookFeed\Events_Integration\Targets;

use CustomFacebookFeed\Events_Integration\Config;
use CustomFacebookFeed\Events_Integration\NormalizedEvent;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class TECAdapter implements TargetAdapterInterface {

	/**
	 * Option: {facebook place fingerprint: TEC venue post ID}.
	 */
	const OPTION_VENUE_MAP = 'cff_events_sync_tec_venues';

	/**
	 * @inheritDoc
	 */
	public function id() {
		return Config::TARGET_TEC;
	}

	/**
	 * @inheritDoc
	 */
	public function label() {
		return __( 'The Events Calendar', 'custom-facebook-feed' );
	}

	/**
	 * @inheritDoc
	 */
	public function is_available() {
		return class_exists( 'Tribe__Events__Main' )
			&& function_exists( 'tribe_create_event' )
			&& function_exists( 'tribe_update_event' );
	}

	/**
	 * @inheritDoc
	 */
	public function post_type() {
		return class_exists( 'Tribe__Events__Main' ) ? \Tribe__Events__Main::POSTTYPE : 'tribe_events';
	}

	/**
	 * @inheritDoc
	 */
	public function create( NormalizedEvent $event ) {
		$post_id = tribe_create_event( $this->event_data( $event ) );

		if ( empty( $post_id ) ) {
			return new \WP_Error( 'cff_events_sync_tec_create', __( 'The Events Calendar did not accept the event.', 'custom-facebook-feed' ) );
		}

		return (int) $post_id;
	}

	/**
	 * @inheritDoc
	 */
	public function update( $post_id, NormalizedEvent $event ) {
		$result = tribe_update_event( $post_id, $this->event_data( $event ) );

		if ( empty( $result ) ) {
			return new \WP_Error( 'cff_events_sync_tec_update', __( 'The Events Calendar did not accept the update.', 'custom-facebook-feed' ) );
		}

		return true;
	}

	/**
	 * @inheritDoc
	 */
	public function delete( $post_id ) {
		if ( function_exists( 'tribe_delete_event' ) ) {
			return (bool) tribe_delete_event( $post_id, true );
		}

		return (bool) wp_delete_post( $post_id, true );
	}

	/**
	 * Map a NormalizedEvent to the tribe_create_event()/tribe_update_event()
	 * args shape.
	 *
	 * @param NormalizedEvent $event Normalized event.
	 * @return array
	 */
	private function event_data( NormalizedEvent $event ) {
		$settings = Config::get_settings();

		// TEC parses EventStartDate/EventEndDate in the site's datepicker
		// format, not a fixed one.
		$date_format = 'Y-m-d';
		if ( class_exists( '\Tribe__Date_Utils' ) && function_exists( 'tribe_get_option' ) ) {
			$formats     = \Tribe__Date_Utils::datepicker_formats();
			$format_key  = tribe_get_option( 'datepickerFormat', 0 );
			$date_format = isset( $formats[ $format_key ] ) ? $formats[ $format_key ] : 'Y-m-d';
		}

		$data = array(
			'post_title'           => $event->title,
			'post_content'         => $event->description,
			'post_status'          => $settings['tec_default_status'],
			'EventStartDate'       => $event->start ? $event->start->format( $date_format ) : '',
			'EventStartHour'       => $event->start ? $event->start->format( 'H' ) : '00',
			'EventStartMinute'     => $event->start ? $event->start->format( 'i' ) : '00',
			'EventEndDate'         => $event->end ? $event->end->format( $date_format ) : '',
			'EventEndHour'         => $event->end ? $event->end->format( 'H' ) : '00',
			'EventEndMinute'       => $event->end ? $event->end->format( 'i' ) : '00',
			'EventTimezone'        => $event->timezone,
			'EventAllDay'          => $event->all_day,
			'EventURL'             => '' !== $event->ticket_uri ? $event->ticket_uri : $event->permalink(),
		);

		$venue_id = $this->venue_id( $event );
		if ( $venue_id > 0 ) {
			$data['EventVenueID'] = $venue_id;
		}

		return $data;
	}

	/**
	 * Find or create the TEC venue for the event's Facebook place.
	 *
	 * @param NormalizedEvent $event Normalized event.
	 * @return int Venue post ID, 0 when the event has no location.
	 */
	private function venue_id( NormalizedEvent $event ) {
		if ( '' === $event->location['name'] || ! function_exists( 'tribe_create_venue' ) ) {
			return 0;
		}

		$fingerprint = md5( wp_json_encode( $event->location ) );
		$map         = get_option( self::OPTION_VENUE_MAP, array() );
		$map         = is_array( $map ) ? $map : array();

		if ( isset( $map[ $fingerprint ] ) && get_post( (int) $map[ $fingerprint ] ) ) {
			return (int) $map[ $fingerprint ];
		}

		$venue_id = tribe_create_venue(
			array(
				'Venue'   => $event->location['name'],
				'Address' => $event->location['street'],
				'City'    => $event->location['city'],
				'State'   => $event->location['state'],
				'Zip'     => $event->location['zip'],
				'Country' => $event->location['country'],
			)
		);

		if ( empty( $venue_id ) ) {
			return 0;
		}

		$map[ $fingerprint ] = (int) $venue_id;
		update_option( self::OPTION_VENUE_MAP, $map, false );

		return (int) $venue_id;
	}
}
