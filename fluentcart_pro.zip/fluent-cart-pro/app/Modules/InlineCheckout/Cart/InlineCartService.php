<?php

namespace FluentCartPro\App\Modules\InlineCheckout\Cart;

use FluentCart\App\Helpers\CartHelper;
use FluentCart\App\Models\Cart;
use FluentCart\App\Models\ProductVariation;
use FluentCart\App\Services\RateLimiter;
use FluentCartPro\App\Modules\InlineCheckout\Config\InlineCheckoutConfig;
use FluentCart\Framework\Support\Arr;

/**
 * The inline checkout's cart lifecycle: render with nothing, write once.
 *
 * An inline checkout lives on ordinary content pages — landing pages, sales
 * pages, course pages — which are crawled and cached orders of magnitude more
 * often than a checkout page. `fct_carts` has no PRIMARY KEY, exactly one index
 * (UNIQUE KEY cart_hash) and no garbage collection beyond a 30-day sweep whose
 * own WHERE is a full table scan. A cart row per render would therefore not
 * merely be wasteful, it would degrade the store within weeks.
 *
 * So the render path and the write path are different methods on purpose:
 *
 *   buildTransientCart()  → an UNSAVED Cart, for drawing the form. Zero writes.
 *   materialize()         → the one row this device gets, written on intent.
 *
 * The device is identified by the `fct_inpage_cart` cookie, deliberately
 * distinct from `fct_cart_hash` so a shopper's real cart is never touched by an
 * inline checkout, and vice versa.
 *
 * MANAGED VS FOREIGN LINES
 *
 * This service was originally written for a standalone checkout that OWNED its
 * cart, so replacing `cart_data` wholesale was harmless. The selector now lives
 * on the real checkout page, where a shopper can arrive with items they added
 * from the shop. So every write path partitions the cart:
 *
 *   managed lines — `object_id` ∈ $config['variant_ids']. These are the options
 *                   the block offers; the selector owns them and may add,
 *                   remove or replace them freely.
 *   foreign lines — everything else. Preserved byte-for-byte through every
 *                   path: add, remove, single-mode switch, and a refused
 *                   selection. Wholesale replacement here would silently delete
 *                   items the shopper put in the cart themselves, which is data
 *                   loss with no undo and no notification.
 *
 * "Single" mode therefore clears the other *managed* lines only. It is a radio
 * group over the block's own options, never over the whole cart.
 *
 * @package FluentCartPro\App\Modules\InlineCheckout\Cart
 */
class InlineCartService
{
    /**
     * `cart_group` value that separates inline carts from `global` (the site
     * cart) and `instant` (buy-now / modal checkout).
     */
    const CART_GROUP = 'inpage';

    /**
     * Cookie holding this device's inline `cart_hash`.
     */
    const COOKIE_KEY = 'fct_inpage_cart';

    /**
     * Cookie holding this device's `pageId => cart_hash` map.
     *
     * One cart per PAGE, not per device. A device cart shared across pages
     * meant two landing pages selling different products accumulated into one
     * basket: selecting on page A then page B billed for both, because page A's
     * line was preserved as a foreign line on page B.
     *
     * A map rather than a cookie per page: browsers cap cookies per domain and
     * send every one of them on every request, so a store with many landing
     * pages would pay for it on every hit.
     */
    const PAGE_COOKIE_KEY = 'fct_inpage_carts';

    /**
     * How long the page map survives. Deliberately shorter than the 30-day
     * cart sweep — this only remembers which row belongs to which page.
     */
    const PAGE_COOKIE_LIFETIME = DAY_IN_SECONDS;

    /**
     * Entries kept in the map, oldest dropped first.
     *
     * A cookie is sent on every request to this domain, so it cannot be allowed
     * to grow with the number of landing pages a shopper visits.
     */
    const MAX_PAGE_ENTRIES = 20;

    /**
     * Per-request memo. null = not looked up yet, false = looked up and none
     * exists, Cart = resolved. Without it, a request that renders and then
     * materializes would query twice and — worse — could miss the row it just
     * created, since setcookie() does not populate $_COOKIE.
     *
     * @var Cart|false|null
     */
    private static $deviceCart = null;

    /**
     * Per-request memo of the decoded page map, keyed by page id.
     *
     * @var array<int,string>|null
     */
    private static $pageCartMap = null;

    /**
     * Hashes of carts rendered with retired lines pruned in memory only.
     *
     * @var array<string,bool>
     */
    private static $unsyncedCarts = [];

    /**
     * Drop the per-request memos.
     *
     * Both caches above are scoped to one request, which holds in production
     * because the process ends with the response. A test process does not: it
     * dispatches many requests in a row, and without this the first one's
     * resolved cart and decoded cookie map answer for all the rest — including
     * requests made as a different user, which is precisely what the ownership
     * guard exists to separate.
     *
     * Additive seam, no behaviour change. Same shape as core's
     * CustomerResource::resetCurrentCustomerRuntimeCache().
     *
     * @return void
     */
    public static function resetRuntimeCache(): void
    {
        self::$deviceCart = null;
        self::$pageCartMap = null;
        self::$unsyncedCarts = [];
    }

    /**
     * Whether the stored row behind this cart still holds lines the render dropped.
     *
     * @param Cart|null $cart
     * @return bool
     */
    public static function needsResync($cart): bool
    {
        return $cart && $cart->cart_hash && !empty(self::$unsyncedCarts[$cart->cart_hash]);
    }

    /**
     * Build an in-memory Cart for rendering. NEVER writes.
     *
     * No save(), no CartResource::get(['create' => true]), no cookie. The
     * returned model has no row behind it and is thrown away at the end of the
     * request. This is the whole zero-rows-on-render invariant, in one method.
     *
     * @param ProductVariation[] $variations
     * @param array              $config Output of InlineCheckoutConfig::normalize()
     * @return Cart
     */
    public static function buildTransientCart(array $variations, array $config): Cart
    {
        $cart = new Cart();

        // Reads the logged-in user's identity onto the model for field
        // prefill. Assignment only — addCommonCartData() issues no write, so
        // the transient cart renders exactly like the materialized one will.
        $cart = CartHelper::addCommonCartData($cart);

        $cart->cart_group = self::CART_GROUP;
        $cart->stage = 'draft';
        $cart->cart_data = self::buildCartData(
            self::applyDefaultSelection($variations),
            $config
        );

        // Stamp the offered options in memory too, not just on materialize.
        // configFromCart() reads them back when a later request has to rebuild
        // the option list without block attributes in scope — an AJAX coupon or
        // address refresh, where the block is not rendering at all.
        $cart->checkout_data = self::withInlineConfig($cart->checkout_data, $config);

        return $cart;
    }

    /**
     * Whether this cart is a selector cart.
     *
     * Structural, not contextual: `inpage` is a group only this module ever
     * creates — materialize() gives every row it touches that group, and the
     * shopper's own basket is `global`. So the group alone is a sound answer.
     *
     * This deliberately does NOT infer from the cart's stored `inline_config`.
     * An earlier design did, and it billed people incorrectly: the config was
     * persisted onto the shopper's own global cart, so once anyone had used a
     * selector, the ordinary checkout page rendered as a selector for them
     * forever — showing only the offered options while their other items
     * stayed in the cart, invisible but still charged. The group cannot drift
     * that way.
     *
     * @param \FluentCart\App\Models\Cart|null $cart
     * @return bool
     */
    public static function isSelectorCart($cart): bool
    {
        return $cart && $cart->cart_group === self::CART_GROUP;
    }


    /**
     * Narrow offered options down to what starts out selected.
     *
     * The first option only, in BOTH single and multiple modes. A shopper
     * landing on a page has not agreed to buy anything yet, so pre-ticking
     * every row would commit them to the full basket before they interact —
     * and quietly inflate the total they first see.
     *
     * @param ProductVariation[] $variations
     * @return ProductVariation[]
     */
    protected static function applyDefaultSelection(array $variations): array
    {
        return array_slice($variations, 0, 1);
    }

    /**
     * The cart to render this page with.
     *
     * Prefers the device's already-materialized cart over a transient one, and
     * that preference is load-bearing rather than an optimization.
     *
     * The checkout JS re-resolves the cart server-side on its own — on load it
     * refetches `get_checkout_summary_view`, and every gateway asks the server
     * to prepare a payment intent. Those requests carry only `fct_cart_hash`.
     * If the page renders from a transient cart there is no hash to send, the
     * server resolves nothing, and the returned fragments blank the summary the
     * block just rendered while the gateway is quoted a zero total.
     *
     * So when a real cart already exists for this device, render from it: the
     * hash is localized from the first byte and every subsequent request lands
     * on the same row.
     *
     * Reuse requires the persisted contents to already match the configured
     * selection. A mismatch falls back to a transient cart rather than writing
     * the correction here, because this runs on render and render must never
     * write — materialize() re-syncs on the next purchase intent.
     *
     * @param array $variations
     * @param array $config
     * @return Cart
     */
    public static function resolveForRender(array $variations, array $config): Cart
    {
        $deviceCart = self::findForDevice(Arr::get($config, 'page_id', 0));

        if ($deviceCart) {
            // Drop retired options BEFORE matchesSelection() judges the cart, so
            // a cart holding only a retired line is correctly seen as empty and
            // falls through to a freshly seeded one. In-memory only — render
            // must not write; materialize() persists the same pruning.
            $storedLineCount = count((array)$deviceCart->cart_data);
            $deviceCart->cart_data = self::withoutRetiredOffers($deviceCart, $config);

            // The row behind the hash still bills the dropped lines, so the
            // page must re-materialize before that hash is published.
            if (count($deviceCart->cart_data) < $storedLineCount) {
                self::$unsyncedCarts[$deviceCart->cart_hash] = true;
            }

            if (!$deviceCart->cart_data) {
                $deviceCart = null;
            }
        }

        if ($deviceCart && self::matchesSelection($deviceCart, $variations, $config)) {
            // Re-stamp with the CURRENT page's config before handing it back.
            //
            // A device cart is reused across pages, so it still carries the
            // settings of wherever it was minted. Every render-side consumer
            // reads the config back off the cart via configFromCart(), so a
            // cart made on a single-select checkout would draw radio buttons on
            // a multi-select one — and vice versa. In-memory only; render must
            // not write.
            $deviceCart->checkout_data = self::withInlineConfig($deviceCart->checkout_data, $config);

            return $deviceCart;
        }

        return self::buildTransientCart($variations, $config);
    }

    /**
     * The cart a checkout in selector mode should render and act on.
     *
     * Precedence, highest first:
     *
     *   1. this page's own inline cart, when it still matches the offer.
     *   2. a transient cart seeded with the default selection.
     *
     * The shopper's `global` / `instant` cart is deliberately NOT consulted. A
     * selector is a standalone offer, not a view onto the shop basket: it shows
     * only what it sells, bills only for that, and leaves the shop cart exactly
     * as it found it. The order is placed against this row by hash, so nothing
     * is stranded.
     *
     * MUST NOT write. Every branch is a read: CartHelper::getCart() is called
     * without `create`, findForDevice() never creates, and buildTransientCart()
     * returns an unsaved model. This runs on every page view of a cacheable
     * page — a write here is the bug the whole service is shaped around.
     *
     * @param ProductVariation[] $variations
     * @param array              $config Output of InlineCheckoutConfig::normalize()
     * @return Cart
     */
    public static function resolveForCheckout(array $variations, array $config): Cart
    {
        // A selector checkout is STANDALONE. It renders and bills from its own
        // per-page `inpage` row and never adopts the shopper's shop cart.
        //
        // Preferring the real cart here is what made the two baskets bleed into
        // each other: a shopper with a Vase in their shop cart opened an offer
        // page and saw "Also in your cart — Vase $69.00" added to the offer's
        // $100, and ticking an option wrote that option INTO the shop cart, so
        // it turned up in the site cart drawer too. Two independent things were
        // sharing one row.
        //
        // Nothing is lost by ignoring the shop cart: it is untouched, still
        // there, and still what the ordinary checkout page bills from. The order
        // placed from here resolves this row instead, by hash —
        // CartResource::get() matches ['instant','inpage'] and the client sends
        // `fct_cart_hash` on every checkout request.
        return self::resolveForRender($variations, $config);
    }


    /**
     * Whether a persisted cart is still a valid selection of what this block
     * offers.
     *
     * Judges the MANAGED lines only — the ones whose variation this block
     * offers — and ignores everything else in the cart.
     *
     * That distinction is the whole point. buildCartData() deliberately
     * preserves foreign lines (an accepted order bump, anything the cart picked
     * up elsewhere), so a healthy selector cart routinely holds lines this
     * block never offered. Judging every line against the offer list rejected
     * exactly those carts: render fell back to a transient default-selection
     * cart while the PERSISTED row — the one the hash resolves and place_order
     * bills — still held the foreign line and the shopper's real choice. The
     * page showed one basket and charged for another.
     *
     * A SUBSET test, not an equality test. The cart holds the shopper's
     * selection while `$variations` holds the options, and since the default
     * selection is the first option only, the two are almost never equal.
     * Requiring equality would reject a good cart on every render and drop the
     * hash the gateway and coupon paths depend on.
     *
     * Rejected when: nothing offered, no managed line at all (the shopper's
     * selection is gone, so there is nothing to reuse), or a single-select page
     * holding more than one managed line — a device cart is reused across pages,
     * so one filled on a multi-select checkout can arrive at a single-select one
     * holding three lines, and the page would draw radio buttons with one ticked
     * while the total billed for all three.
     *
     * @param Cart $cart
     * @param array $variations
     * @param array $config
     * @return bool
     */
    protected static function matchesSelection(Cart $cart, array $variations, array $config = []): bool
    {
        $offeredIds = [];
        foreach ($variations as $variation) {
            $offeredIds[] = (int)$variation->id;
        }

        if (!$offeredIds) {
            return false;
        }

        $managedIds = [];
        foreach ($cart->cart_data as $cartItem) {
            if (!is_array($cartItem)) {
                continue;
            }

            $objectId = (int)Arr::get($cartItem, 'object_id', 0);

            if ($objectId > 0 && in_array($objectId, $offeredIds, true)) {
                $managedIds[] = $objectId;
            }
        }

        // Nothing of ours left in it — every option the shopper had chosen has
        // since been retired from the block, so there is no selection to reuse.
        if (!$managedIds) {
            return false;
        }

        if (Arr::get($config, 'selection_mode', 'single') === 'single' && count($managedIds) > 1) {
            return false;
        }

        return true;
    }

    /**
     * This device's inline cart, or null. Never creates one.
     *
     * The cookie holds `cart_hash`, which is the table's primary key and its
     * only index, so this is a single-row primary-key lookup — not the
     * JSON_EXTRACT full scan the `instant` cart resolves itself with.
     *
     * @return Cart|null
     */
    public static function findForDevice($pageId = 0)
    {
        if (self::$deviceCart !== null) {
            return self::$deviceCart ?: null;
        }

        $pageId = absint($pageId);

        // The page map is authoritative. The legacy single-hash cookie is read
        // only when this render has no page to key on (an AJAX request that did
        // not send one), so carts minted before per-page identity are not
        // stranded mid-checkout.
        $cartHash = $pageId ? Arr::get(self::readPageMap(), $pageId, '') : self::readCookie();

        if (!$cartHash) {
            self::$deviceCart = false;
            return null;
        }

        // `cart_group` inline rather than through a model scope: the scope
        // would have to live on core's Cart model, and this module owns the
        // group, not core.
        $query = Cart::query()
            ->where('cart_hash', $cartHash)
            ->where('cart_group', self::CART_GROUP)
            ->stageNotCompleted();

        // Ownership guard. The page map is client-controlled, so without this a
        // forged entry would let anyone act on any cart whose hash they hold —
        // and hashes travel in `fct_cart_hash` query strings, so they reach
        // browser history, referrer headers, server logs and analytics. Guessing
        // is impractical; leaking is not.
        //
        // Both directions are constrained:
        //
        //  - A signed-in shopper reaches their own rows, plus guest rows. The
        //    guest allowance is what carries a cart through login: a cart
        //    started logged-out has a NULL user_id and must survive the shopper
        //    signing in halfway through.
        //
        //  - An ANONYMOUS visitor reaches guest rows ONLY. Leaving this branch
        //    unconstrained meant a logged-out request carrying a signed-in
        //    shopper's hash could read and rewrite that shopper's cart —
        //    verified, before this guard: an anonymous select changed an owned
        //    cart's contents and was handed the owner's hash back.
        $userId = get_current_user_id();

        if ($userId) {
            $query->where(function ($q) use ($userId) {
                $q->where('user_id', $userId)->orWhereNull('user_id');
            });
        } else {
            $query->whereNull('user_id');
        }

        $cart = $query->first();

        self::$deviceCart = $cart ?: false;

        return $cart;
    }

    /**
     * Find-or-create this device's inline cart and write the current selection.
     *
     * Called on purchase intent only — first billing-field blur, selection
     * change or submit — never on render.
     *
     * An existing row is UPDATED in place. Its `cart_hash` is never rotated:
     * the hash is the primary key and it is what every outstanding checkout URL
     * and the device cookie point at, so re-minting it silently orphans them.
     *
     * Only the managed lines are rewritten. Whatever else the row holds — items
     * added from the shop, an order bump, anything a future surface writes — is
     * read back off the row and carried into the new cart_data unchanged.
     *
     * @param ProductVariation[] $variations the complete managed selection
     * @param array              $config Output of InlineCheckoutConfig::normalize()
     * @return Cart|\WP_Error WP_Error when a new row is over the creation rate limit
     */
    public static function materialize(array $variations, array $config)
    {
        // Always this page's own inline row — never the shopper's shop cart.
        // Writing the selection into a `global` row put the offer into the site
        // cart drawer and billed the shop's items alongside it.
        //
        // findForDevice() is scoped to CART_GROUP, and a row created below is
        // given that group, so every cart this method touches is an `inpage`
        // one. That is what lets everything downstream recognise a selector
        // cart from its group alone, without a request-scoped flag.
        $cart = self::findForDevice(Arr::get($config, 'page_id', 0));
        $isNewCart = false;

        if (!$cart) {
            // A client that drops the cookie lands here on every request, so new
            // rows are rate limited per IP/user, as core's instant-checkout cart is.
            // Filterable: behind a non-Cloudflare proxy every guest shares one IP.
            $createLimit = max(1, (int) apply_filters('fluent_cart/inline_checkout/cart_create_limit', 10, [
                'config' => $config,
            ]));

            if (RateLimiter::isSpamming('inline_cart_create', $createLimit, 60)) {
                return new \WP_Error(
                    'too_many_requests',
                    __('Too many requests. Please try again after some time.', 'fluent-cart-pro')
                );
            }

            $cart = new Cart();
            $cart = CartHelper::addCommonCartData($cart);
            $cart->cart_group = self::CART_GROUP;
            $isNewCart = true;
        } elseif (!$cart->user_id && is_user_logged_in()) {
            // Claim a cart that was started logged out.
            //
            // findForDevice() lets a signed-in shopper resume an unowned cart,
            // which is what carries a basket through login. But without writing
            // the owner down the row stays user_id = NULL for good, and the
            // guard's anonymous branch resolves exactly `user_id IS NULL` — so a
            // leaked hash could still be replayed against the cart of a shopper
            // who is signed in and midway through checkout. Resuming it is the
            // moment it stops being anonymous, so that is where it gets an owner.
            $cart = CartHelper::addCommonCartData($cart);
        }

        // Read the existing contents BEFORE the assignment below overwrites
        // them — this is what keeps the shopper's own lines alive.
        $existingCartData = $isNewCart ? [] : self::withoutRetiredOffers($cart, $config);

        $cart->stage = 'draft';
        $cart->cart_data = self::buildCartData($variations, $config, $existingCartData);
        $cart->checkout_data = self::withInlineConfig($cart->checkout_data, $config);

        $cart->save();
        unset(self::$unsyncedCarts[$cart->cart_hash]);

        // cart_data is assigned wholesale rather than going through addItem() /
        // removeItem(), so their reValidateCoupons() call never fires. Without
        // this an applied coupon survives in the UI but recomputes to a zero
        // discount the moment the selection changes — the shopper still sees
        // "ten · Remove" while being charged the full amount.
        $cart->reValidateCoupons();

        // Same wholesale assignment skips this event too, so shipping and tax
        // kept quoting the previous selection.
        do_action('fluent_cart/cart/cart_data_items_updated', [
            'cart'       => $cart,
            'scope'      => 'items_replaced',
            'scope_data' => array_map(function ($variation) {
                return (int)$variation->id;
            }, $variations)
        ]);

        self::$deviceCart = $cart;
        self::rememberDevice($cart, Arr::get($config, 'page_id', 0));

        if ($isNewCart) {
            // Two args by codebase convention (tag + payload); the ticket's
            // table describes the same two values as positional params.
            do_action('fluent_cart/inline_checkout/cart_materialized', [
                'cart'   => $cart,
                'config' => $config,
            ]);
        }

        return $cart;
    }

    /**
     * Replace this device's selection with exactly the given variation ids.
     *
     * Called on a shopper gesture, so materializing here is correct — this IS
     * purchase intent.
     *
     * Takes the WHOLE selection rather than a toggle delta, and that is a
     * correctness requirement, not a style choice. A shopper unticking two rows
     * quickly fires two overlapping requests; with delta semantics each one
     * reads the cart before the other has saved, so they compute from the same
     * stale base and the second silently undoes the first — leaving a cart that
     * disagrees with the checkboxes on screen (three items billed, one ticked).
     *
     * Absolute semantics make every request idempotent and order-independent:
     * whichever arrives last wins, and it wins with the state the shopper can
     * actually see.
     *
     * `single` mode is enforced here too, since Cart::addByVariation(['replace'
     * => true]) only replaces the *same* variation and would leave a previously
     * chosen option in the cart, charging for both. That replacement is scoped
     * to the block's own options: switching from option A to option B clears A,
     * never a product the shopper added from the shop.
     *
     * "The complete desired selection" means the complete MANAGED selection.
     * Foreign lines are not addressable from here at all — they survive a
     * selection change, and they survive a refusal, because every refusal
     * returns before anything is written.
     *
     * @param int[] $variationIds the complete desired managed selection
     * @param array $config
     * @return Cart|\WP_Error
     */
    public static function setSelection(array $variationIds, array $config)
    {
        $mode = Arr::get($config, 'selection_mode', 'single');

        $selectedIds = [];
        foreach ($variationIds as $rawId) {
            $variationId = (int) $rawId;
            if ($variationId > 0 && !in_array($variationId, $selectedIds, true)) {
                $selectedIds[] = $variationId;
            }
        }

        if ($mode === 'single') {
            $selectedIds = array_slice($selectedIds, 0, 1);
        }

        $maxItems = (int) Arr::get($config, 'max_items', 5);
        // Refuse rather than trim: the client treats an accepted response as the
        // ids it sent, so a dropped tick would later be restored as selected.
        if ($maxItems > 0 && count($selectedIds) > $maxItems) {
            return new \WP_Error(
                'max_items_exceeded',
                sprintf(
                    /* translators: %d: maximum number of items a shopper may select */
                    _n('You can select up to %d item.', 'You can select up to %d items.', $maxItems, 'fluent-cart-pro'),
                    $maxItems
                )
            );
        }

        if (!$selectedIds) {
            // Unticking every offered option is only an error when it would
            // leave the shopper with nothing to buy. If the cart still holds
            // lines this block does not own, clearing the managed ones is a
            // legitimate outcome — refusing it would strand the checkout
            // showing options the shopper has already unticked.
            // Check the cart this selection will actually be written to. Using
            // findForDevice() unconditionally meant a shopper whose foreign
            // items sit in their own global cart could never untick their last
            // offered option — the foreign check looked at an inline cart that
            // did not exist, so clearing the managed lines was refused.
            if (self::hasForeignItems(self::findForDevice(Arr::get($config, 'page_id', 0)), $config)) {
                return self::materialize([], $config);
            }

            // A subscription can't share the cart, so emptying the selection is
            // how a multi-select shopper switches between it and one-time items.
            // Place order still refuses an empty cart.
            if ($mode !== 'single') {
                return self::materialize([], $config);
            }

            return new \WP_Error(
                'no_selection',
                __('Please select at least one item to continue.', 'fluent-cart')
            );
        }

        // Re-resolve through the config so every selected id passes the same
        // published / purchasable / RenderGate checks the block applied at
        // render time. A client cannot select its way past catalog mode.
        $selectionConfig = array_merge($config, ['variant_ids' => $selectedIds]);
        $variations = InlineCheckoutConfig::resolveVariations($selectionConfig);

        if (!$variations) {
            return new \WP_Error(
                'not_purchasable',
                __('That item is not available for purchase.', 'fluent-cart')
            );
        }

        $validation = self::validateCombination($variations);
        if (is_wp_error($validation)) {
            return $validation;
        }

        return self::materialize($variations, $config);
    }

    /**
     * The selection a freshly rendered block starts with, as variation ids.
     *
     * Mirrors what buildCartData() puts in a new cart, so the server's idea of
     * "currently selected" matches what the shopper can see before any cart
     * exists. Keep the two in step.
     *
     * @param array $config
     * @return int[]
     */
    public static function defaultSelectionIds(array $config): array
    {
        $ids = array_values(array_filter(array_map('intval', Arr::get($config, 'variant_ids', []))));

        // First option only, in both modes — mirrors applyDefaultSelection().
        return array_slice($ids, 0, 1);
    }

    /**
     * Reject selections the checkout would refuse later.
     *
     * Selection is rebuilt wholesale rather than routed through
     * Cart::addByVariation(), so that method's validation does not run and has
     * to be reproduced here. Catching this now matters: without it a shopper
     * can assemble an invalid basket, fill in every field, and only be refused
     * at payment time by CheckoutApi::validateData().
     *
     * @param ProductVariation[] $variations
     * @return true|\WP_Error
     */
    protected static function validateCombination(array $variations)
    {
        $hasSubscription = false;

        foreach ($variations as $variation) {
            $canPurchase = $variation->canPurchase(1);
            if (is_wp_error($canPurchase)) {
                return $canPurchase;
            }

            if ($variation->payment_type === 'subscription') {
                $hasSubscription = true;
            }
        }

        if ($hasSubscription && count($variations) > 1) {
            return new \WP_Error(
                'subscription_items_can_not_combined',
                __("Subscription items can't be combined with other products in the cart.", 'fluent-cart')
            );
        }

        return true;
    }

    /**
     * Persist the block's offered options onto the cart.
     *
     * The cart holds the shopper's *selection*; this holds the *options* they
     * chose from. Both are needed, and only the cart survives the request.
     *
     * Every later fragment refresh — a coupon, an address change, a selection
     * toggle — re-renders the item list server-side from an AJAX request that
     * carries only `fct_cart_hash`. It has no access to the block's attributes,
     * because the block is not being rendered on those requests. Without this,
     * the refreshed list would collapse to just the selected rows and the
     * shopper would lose the options they had not picked.
     *
     * Stored under a single namespaced key so it cannot collide with the
     * checkout_data keys the core checkout owns.
     *
     * @param mixed $checkoutData existing checkout_data (array once decoded)
     * @param array $config
     * @return array
     */
    protected static function withInlineConfig($checkoutData, array $config): array
    {
        if (!is_array($checkoutData)) {
            $checkoutData = [];
        }

        $checkoutData['inline_config'] = [
            'variant_ids'    => Arr::get($config, 'variant_ids', []),
            'selection_mode' => Arr::get($config, 'selection_mode', 'single'),
            'max_items'      => Arr::get($config, 'max_items', 5),
            'button_text'    => Arr::get($config, 'button_text', ''),
            // Persisted for the same reason as button_text and empty_text: the
            // block is not rendering on an AJAX request, so every refresh path
            // rebuilds the config from this array via configFromCart(). Leaving
            // the heading out made a configured selector label revert to
            // "Order summary" on the first coupon, address change or selection.
            'selector_label' => Arr::get($config, 'selector_label', ''),
            'empty_text'     => Arr::get($config, 'empty_text', ''),
        ];

        return $checkoutData;
    }

    /**
     * Lines this page USED to offer and no longer does.
     *
     * When an author edits the block's products, the cart keyed to that page
     * still holds whatever the shopper picked from the previous offer. That line
     * is not theirs in any meaningful sense — they chose it from a list this
     * page no longer sells — and leaving it in charged them for a product the
     * page does not even show. It surfaced as "Also in your cart".
     *
     * Deliberately narrower than "not currently offered": an order bump the
     * shopper accepted is also not in `variant_ids`, and deleting that WOULD be
     * taking away something they chose. The stored `inline_config.variant_ids`
     * is what separates the two — a retired option was in the old offer, a bump
     * never was.
     *
     * Read the STORED config, so call this before withInlineConfig() re-stamps
     * the cart with the current one.
     *
     * @param Cart  $cart
     * @param array $config Current, normalized config.
     * @return array cart_data minus the retired lines.
     */
    protected static function withoutRetiredOffers(Cart $cart, array $config): array
    {
        $items = $cart->cart_data;

        if (!is_array($items) || !$items) {
            return is_array($items) ? $items : [];
        }

        $storedOffer = array_map('absint', (array) Arr::get($cart->checkout_data, 'inline_config.variant_ids', []));

        if (!$storedOffer) {
            return $items;
        }

        $currentOffer = array_map('absint', (array) Arr::get($config, 'variant_ids', []));
        $retired = array_diff($storedOffer, $currentOffer);

        if (!$retired) {
            return $items;
        }

        $kept = [];

        foreach ($items as $item) {
            if (is_array($item) && in_array((int) Arr::get($item, 'object_id', 0), $retired, true)) {
                continue;
            }

            $kept[] = $item;
        }

        return $kept;
    }

    /**
     * The block config a materialized cart was created with, re-normalized.
     *
     * Used by AJAX handlers, which know the cart but not the block.
     *
     * @param Cart $cart
     * @return array
     */
    public static function configFromCart(Cart $cart): array
    {
        $stored = Arr::get($cart->checkout_data, 'inline_config', []);

        if (!is_array($stored)) {
            $stored = [];
        }

        return InlineCheckoutConfig::normalize($stored, 'ajax');
    }

    /**
     * Cart items for the given variations.
     *
     * `single` selection mode is radio behaviour, so the cart holds exactly one
     * line even when several variations are offered — the caller passes the
     * options, not the selection, and taking the first is what makes an
     * accidental multi-line cart impossible in that mode.
     *
     * Foreign lines — anything already in `$existingCartData` that this block
     * does not offer — are carried across untouched and kept ahead of the
     * managed lines, so a shopper who arrived with a cart from the shop keeps
     * every one of those rows through the whole selection cycle.
     *
     * @param ProductVariation[] $variations
     * @param array              $config
     * @param mixed              $existingCartData the cart_data being replaced
     * @return array
     */
    protected static function buildCartData(array $variations, array $config, $existingCartData = []): array
    {
        // No slicing here. This builds exactly the variations it is handed, so
        // that setSelection() — which passes the shopper's explicit choice —
        // cannot have a multi-item selection silently truncated. Narrowing to a
        // default belongs to the callers that actually mean "default", namely
        // buildTransientCart() and defaultSelectionIds().
        $items = self::foreignItems($existingCartData, $config);

        foreach ($variations as $variation) {
            if (!$variation instanceof ProductVariation) {
                continue;
            }

            $items[] = CartHelper::generateCartItemFromVariation($variation, 1);
        }

        return $items;
    }

    /**
     * The ids this block offers, i.e. the lines the selector is allowed to own.
     *
     * Read from the configured options rather than from the current selection:
     * an option the shopper has just unticked is still managed, otherwise
     * unticking it would promote it to a foreign line and make it permanent.
     *
     * @param array $config Output of InlineCheckoutConfig::normalize()
     * @return int[]
     */
    protected static function managedIds(array $config): array
    {
        $variantIds = Arr::get($config, 'variant_ids', []);

        if (!is_array($variantIds)) {
            return [];
        }

        return array_values(array_filter(array_map('intval', $variantIds)));
    }

    /**
     * Everything in a cart that this block does NOT offer, in its original
     * order and with every key untouched.
     *
     * Deliberately conservative: an entry is treated as managed only when it is
     * an array whose `object_id` is one of the offered ids. Anything else —
     * including a malformed entry this service does not understand — falls
     * through to the foreign side and survives. Discarding what we cannot parse
     * would be the same data loss the partition exists to prevent.
     *
     * @param mixed $cartData
     * @param array $config
     * @return array
     */
    protected static function foreignItems($cartData, array $config): array
    {
        if (!is_array($cartData) || !$cartData) {
            return [];
        }

        $managedIds = self::managedIds($config);

        if (!$managedIds) {
            // Nothing is offered, so nothing is managed. The caller has no
            // business rewriting this cart at all — hand it all back.
            return array_values($cartData);
        }

        $foreign = [];

        foreach ($cartData as $cartItem) {
            if (is_array($cartItem)) {
                $objectId = (int) Arr::get($cartItem, 'object_id', 0);
                if ($objectId > 0 && in_array($objectId, $managedIds, true)) {
                    continue;
                }
            }

            $foreign[] = $cartItem;
        }

        return $foreign;
    }

    /**
     * Whether a cart holds anything the selector does not own.
     *
     * Used to tell "the shopper emptied the whole cart" (refuse) apart from
     * "the shopper unticked our options but still has their own items" (allow).
     *
     * @param Cart|null $cart
     * @param array     $config
     * @return bool
     */
    protected static function hasForeignItems($cart, array $config): bool
    {
        if (!$cart instanceof Cart) {
            return false;
        }

        return (bool) self::foreignItems($cart->cart_data, $config);
    }

    /**
     * Point this device's cookie at the given cart.
     *
     * Mirrors Api\Cookie\Cookie::setCartHash()'s path / domain / secure /
     * samesite handling so an inline cart survives exactly as long, and on
     * exactly the same hosts, as the site cart.
     *
     * @param Cart $cart
     * @return void
     */
    protected static function rememberDevice(Cart $cart, $pageId = 0): void
    {
        $cartHash = (string)$cart->cart_hash;

        // Record the page association first: that is what makes the next render
        // of THIS page resolve this row, and it is independent of the legacy
        // single-hash cookie below.
        self::writePageMap(absint($pageId), $cartHash);

        if (!$cartHash || self::readCookie() === $cartHash) {
            return;
        }

        // $_COOKIE is not populated by setcookie(), so seed it here: anything
        // later in this same request that calls findForDevice() must see the
        // row we just wrote rather than create a second one.
        $_COOKIE[self::COOKIE_KEY] = $cartHash;

        if (headers_sent()) {
            return;
        }

        $expireTime = apply_filters('fluent_cart/cart_cookie_minutes', time() + 24 * 60 * 30);

        setcookie(self::COOKIE_KEY, $cartHash, [
            'expires'  => $expireTime,
            'path'     => COOKIEPATH,
            'domain'   => COOKIE_DOMAIN,
            'secure'   => is_ssl(),
            'httponly' => false,
            'samesite' => 'Lax',
        ]);
    }

    /**
     * @return string
     */
    protected static function readCookie(): string
    {
        $cartHash = \FluentCart\Framework\Http\Cookie::get(self::COOKIE_KEY, '');

        if (!is_string($cartHash)) {
            return '';
        }

        // Cookie values are client-controlled: sanitize before it reaches a
        // WHERE clause, and cap at the column width so an oversized cookie
        // cannot be used to push work onto the database.
        return substr(sanitize_text_field(wp_unslash($cartHash)), 0, 192);
    }

    /**
     * This device's `pageId => cart_hash` map, decoded and sanitized.
     *
     * Every value is client-controlled, so nothing here is trusted beyond its
     * shape: ids are cast, hashes are sanitized and length-capped before they
     * can reach a WHERE clause, and the caller still re-queries with the group,
     * stage and ownership guards applied.
     *
     * @return array<int,string>
     */
    protected static function readPageMap(): array
    {
        if (self::$pageCartMap !== null) {
            return self::$pageCartMap;
        }

        $raw = \FluentCart\Framework\Http\Cookie::get(self::PAGE_COOKIE_KEY, '');
        self::$pageCartMap = [];

        if (!is_string($raw) || $raw === '') {
            return self::$pageCartMap;
        }

        $decoded = json_decode(wp_unslash($raw), true);

        if (!is_array($decoded)) {
            return self::$pageCartMap;
        }

        $map = [];

        foreach ($decoded as $pageId => $cartHash) {
            $pageId = absint($pageId);

            if (!$pageId || !is_string($cartHash)) {
                continue;
            }

            $cartHash = substr(sanitize_text_field($cartHash), 0, 192);

            if ($cartHash !== '') {
                $map[$pageId] = $cartHash;
            }
        }

        self::$pageCartMap = $map;

        return self::$pageCartMap;
    }

    /**
     * Point this page's entry at the given cart and re-issue the cookie.
     *
     * @param int    $pageId
     * @param string $cartHash
     * @return void
     */
    protected static function writePageMap(int $pageId, string $cartHash): void
    {
        if (!$pageId || $cartHash === '') {
            return;
        }

        $map = self::readPageMap();

        if (isset($map[$pageId]) && $map[$pageId] === $cartHash) {
            return;
        }

        // Re-inserting at the end makes the array insertion-ordered by recency,
        // so trimming from the front drops the least recently used page.
        unset($map[$pageId]);
        $map[$pageId] = $cartHash;

        if (count($map) > self::MAX_PAGE_ENTRIES) {
            $map = array_slice($map, -self::MAX_PAGE_ENTRIES, null, true);
        }

        // Seed the memo and $_COOKIE together: setcookie() does not populate
        // $_COOKIE, and anything later in THIS request that resolves the cart
        // must see the row we just wrote rather than create a second one.
        self::$pageCartMap = $map;
        $encoded = wp_json_encode($map);
        $_COOKIE[self::PAGE_COOKIE_KEY] = $encoded;

        if (headers_sent()) {
            return;
        }

        setcookie(self::PAGE_COOKIE_KEY, $encoded, [
            'expires'  => time() + self::PAGE_COOKIE_LIFETIME,
            'path'     => COOKIEPATH,
            'domain'   => COOKIE_DOMAIN,
            'secure'   => is_ssl(),
            'httponly' => false,
            'samesite' => 'Lax',
        ]);
    }
}
