<?php

declare(strict_types=1);

namespace FluentCartPro\App\Services\Invoice\Serializer;

if (!defined('ABSPATH')) {
    exit;
}

use FluentCartPro\App\Services\Invoice\Domain\CalculatedTotals;
use FluentCartPro\App\Services\Invoice\Domain\En16931Invoice;
use FluentCartPro\App\Services\Invoice\Profile\InvoiceProfileInterface;

interface InvoiceSerializerInterface
{
    /**
     * Serialize invoice and totals to XML string. No calculations; structure and values only.
     */
    public function serialize(En16931Invoice $invoice, CalculatedTotals $totals, InvoiceProfileInterface $profile): string;
}
