<?php

namespace TheLion\UseyourDrive\Integrations;

use TheLion\UseyourDrive\API;
use TheLion\UseyourDrive\App;
use TheLion\UseyourDrive\Client;
use TheLion\UseyourDrive\Helpers;
use TheLion\UseyourDrive\Placeholders;
use TheLion\UseyourDrive\Processor;
use TheLion\UseyourDrive\Settings;
use TheLion\UseyourDrive\ShortcodeBuilder;
use TheLion\UseyourDrive\Shortcodes;

class WooCommerce_Uploads
{
    public function __construct()
    {
        // Add Tabs & Content to Product Edit Page
        add_action('admin_enqueue_scripts', [$this, 'add_scripts']);
        add_filter('product_type_options', [$this, 'add_uploadable_product_option']);
        add_filter('woocommerce_product_data_tabs', [$this, 'add_product_data_tab']);
        add_action('woocommerce_product_data_panels', [$this, 'add_product_data_tab_content']);
        add_action('woocommerce_process_product_meta_simple', [$this, 'save_product_data_fields']);
        add_action('woocommerce_process_product_meta_variable', [$this, 'save_product_data_fields']);
        add_action('woocommerce_ajax_save_product_variations', [$this, 'save_product_data_fields']);
        add_action('woocommerce_process_product_meta_composite', [$this, 'save_product_data_fields']);
        add_action('woocommerce_process_product_meta_booking', [$this, 'save_product_data_fields']);
        add_action('woocommerce_process_product_meta', [$this, 'save_product_data_fields']);

        // Add Upload button to my Order Table
        add_filter('woocommerce_my_account_my_orders_actions', [$this, 'add_orders_column_actions'], 10, 2);

        // Add Upload Box where needed
        add_action('woocommerce_before_add_to_cart_button', [$this, 'render_on_product_page']);
        add_action('woocommerce_after_cart_item_name', [$this, 'render_on_cart_page']);
        add_action(Settings::get('woocommerce_checkout_section', 'woocommerce_after_order_notes'), [$this, 'render_on_checkout_page']);
        add_action('woocommerce_order_item_meta_end', [$this, 'render_on_order_page'], 10, 4);

        // Move temporarily stored uploads to the correct location after checkout
        add_filter('useyourdrive_upload_post_process_data', [$this, 'save_temporary_uploads'], 10, 1);
        add_action('woocommerce_checkout_update_order_meta', [$this, 'move_session_uploads'], 99, 2);

        // Remove temporarily stored uploads from the WC session when they are
        // deleted via the Upload Box (pre-checkout).
        add_action('useyourdrive_api_after_delete', [$this, 'remove_temporary_uploads'], 10, 2);

        // Keep the temp upload store in sync with the cart
        add_action('woocommerce_cart_item_removed', [$this, 'on_cart_item_removed'], 10, 2);
        add_action('woocommerce_cart_item_restored', [$this, 'on_cart_item_restored'], 10, 2);
        add_action('woocommerce_cart_emptied', [$this, 'on_cart_emptied'], 10);

        // Add Upload Box to Admin Order Page
        add_action('woocommerce_admin_order_item_headers', [$this, 'admin_order_item_headers'], 10, 1);
        add_action('woocommerce_admin_order_item_values', [$this, 'admin_order_item_values'], 10, 3);

        // Add link to upload box in the Thank You text
        add_filter('woocommerce_thankyou_order_received_text', [$this, 'change_order_received_text'], 10, 2);

        // Add Order note when uploading files
        add_action('useyourdrive_upload_post_process', [$this, 'add_order_note'], 10, 1);

        // AJAX calls to load the list of uploaded files
        add_action('useyourdrive_start_process', [$this, 'get_item_details'], 10, 2);

        // Remove the userfoldernametemplate field for WooCommerce as it has its own
        add_action('useyourdrive_before_shortcode_builder', [$this, 'modify_shortcode_builder'], 10, 4);
    }

    /**
     * Add an order note when files are uploaded.
     *
     * @param array $_uploaded_entries
     */
    public function add_order_note($_uploaded_entries)
    {
        // Grab the Order/Product data from the shortcode
        $order_id = Processor::instance()->get_shortcode_option('wc_order_id');
        $product_id = Processor::instance()->get_shortcode_option('wc_product_id');

        if (empty($order_id) || empty($product_id)) {
            return;
        }

        $order = new \WC_Order($order_id);

        if (empty($order)) {
            return;
        }

        $product = wc_get_product($product_id);

        // Make sure that we are working with an array
        $uploaded_entries = [];
        if (!is_array($_uploaded_entries)) {
            $uploaded_entries[] = $_uploaded_entries;
        } else {
            $uploaded_entries = $_uploaded_entries;
        }

        // Build the Order note
        $order_note = sprintf(esc_html__('%d file(s) uploaded for product', 'wpcloudplugins'), count((array) $uploaded_entries)).' <strong>'.$product->get_title().'</strong>:';
        $order_note .= '<br/><br/><ul>';

        foreach ($uploaded_entries as $cachedentry) {
            $link = urlencode($cachedentry->get_entry()->get_preview_link());
            $name = $cachedentry->get_entry()->get_name();
            $size = Helpers::bytes_to_size_1024($cachedentry->get_entry()->get_size());

            $order_note .= '<li><a href="'.urldecode($link).'">'.$name.'</a> ('.$size.')</li>';
        }

        $order_note .= '</ul>';

        // Add the note
        $note = [
            'note' => $order_note,
            'is_customer_note' => false,
            'added_by_user' => false,
        ];

        $note = apply_filters('useyourdrive_woocommerce_add_order_note', $note, $uploaded_entries, $order, $product, $this);
        $order->add_order_note($note['note'], $note['is_customer_note'], $note['added_by_user']);

        // Save the data
        $order->save();
    }

    /**
     * Add link to upload box in the Thank You text.
     *
     * @param string    $thank_you_text
     * @param \WC_Order $order
     *
     * @return string
     */
    public function change_order_received_text($thank_you_text, $order)
    {
        if (false === $this->requires_order_uploads($order) || false === $this->is_upload_location_active('order', true)) {
            return $thank_you_text;
        }

        $order_url = $order->get_view_order_url().'#wpcp-uploads';
        $custom_text = ' '.esc_html__('You can now start uploading documents for the products you have ordered.', 'wpcloudplugins');
        $thank_you_text .= apply_filters('useyourdrive_woocommerce_thank_you_text', $custom_text, $order, $this);

        return $thank_you_text;
    }

    /**
     * Add new Product Type to the Product Data Meta Box.
     *
     * @param array $product_type_options
     *
     * @return array
     */
    public function add_uploadable_product_option($product_type_options)
    {
        $product_type_options['uploadable'] = [
            'id' => '_uploadable',
            'wrapper_class' => 'show_if_simple show_if_variable show_if_booking show_if_woosb',
            'label' => esc_html__('Uploads', 'wpcloudplugins'),
            'description' => esc_html__('Allows your customers to upload files when ordering this product.', 'wpcloudplugins'),
            'default' => 'no',
        ];

        return $product_type_options;
    }

    /**
     * Add new Data Tab to the Product Data Meta Box.
     *
     * @param array $product_data_tabs
     *
     * @return array
     */
    public function add_product_data_tab($product_data_tabs)
    {
        $product_data_tabs['cloud-uploads-drive'] = [
            'label' => sprintf(esc_html__('Upload to %s', 'wpcloudplugins'), 'Google Drive'),
            'target' => 'cloud_uploads_data_drive',
            'class' => ['show_if_uploadable'],
        ];

        return $product_data_tabs;
    }

    /**
     * Add the content of the new Data Tab.
     */
    public function add_product_data_tab_content()
    {
        global $post;

        $default_shortcode = '[useyourdrive mode="files" viewrole="all" userfolders="auto" downloadrole="all" upload="1" uploadrole="all" rename="1" renamefilesrole="all" renamefoldersrole="all" editdescription="1" editdescriptionrole="all" delete="1" deletefilesrole="all" deletefoldersrole="all" viewuserfoldersrole="none" search="0" showbreadcrumb="0"]';
        $shortcode = get_post_meta($post->ID, 'useyourdrive_upload_box_shortcode', true); ?>
<div id='cloud_uploads_data_drive' class='panel woocommerce_options_panel' style="display:none">
    <div class="cloud_uploads_data_panel options_group">
        <?php
            woocommerce_wp_checkbox(
                [
                    'id' => 'useyourdrive_upload_box',
                    'label' => sprintf(esc_html__('Upload to %s', 'wpcloudplugins'), 'Google Drive'),
                ]
            ); ?>
        <div class="show_if_useyourdrive_upload_box">
            <h4><?php echo 'Google Drive '.esc_html__('Upload Box Settings', 'wpcloudplugins'); ?></h4>
            <?php $default_box_description = '';
        $box_description = get_post_meta($post->ID, 'useyourdrive_upload_box_description', true);

        woocommerce_wp_textarea_input(
            [
                'id' => 'useyourdrive_upload_box_description',
                'label' => esc_html__('Description Upload Box', 'wpcloudplugins'),
                'placeholder' => $default_box_description,
                'desc_tip' => true,
                'description' => esc_html__('Enter a short description of what the customer needs to upload', 'wpcloudplugins').'. '.sprintf(esc_html__('See %s for available placeholders', 'wpcloudplugins'), '<strong><u>'.esc_html__('Upload Folder Name', 'wpcloudplugins').'</u></strong>').'. '.esc_html__('Shortcodes are supported', 'wpcloudplugins').'.',
                'value' => empty($box_description) ? $default_box_description : $box_description,
            ]
        );

        $default_box_button_text = esc_html__('Upload documents', 'wpcloudplugins');
        $box_button_text = get_post_meta($post->ID, 'useyourdrive_upload_box_button_text', true);

        woocommerce_wp_text_input(
            [
                'id' => 'useyourdrive_upload_box_button_text',
                'label' => esc_html__('Upload Button Text', 'wpcloudplugins'),
                'placeholder' => $default_box_button_text,
                'desc_tip' => true,
                'description' => esc_html__('Enter the text for the upload button.', 'wpcloudplugins').' '.sprintf(esc_html__('See %s for available placeholders', 'wpcloudplugins'), '<strong><u>'.esc_html__('Upload Folder Name', 'wpcloudplugins').'</u></strong>').'. '.esc_html__('Shortcodes are supported', 'wpcloudplugins').'.',
                'value' => empty($box_button_text) ? $default_box_button_text : $box_button_text,
            ]
        );
        ?>

            <p class="form-field useyourdrive_upload_folder ">
                <label for="useyourdrive_upload_folder"><?php esc_html_e('Upload Configuration', 'wpcloudplugins'); ?></label>
                <button type="button" class="button wpcp-insert-google-shortcode button-primary" style="float:none"><?php esc_html_e('Configure', 'wpcloudplugins'); ?></button>
                <button type="button" class="button" style="float:none" onclick="jQuery('#useyourdrive_upload_box_shortcode').fadeToggle()"><?php esc_html_e('Edit manually', 'wpcloudplugins'); ?></button>
                <textarea class="long" style="display:none; margin:10px 0px;" name="useyourdrive_upload_box_shortcode" id="useyourdrive_upload_box_shortcode" placeholder="<?php echo esc_attr($default_shortcode); ?>" rows="5" cols="20"><?php echo esc_textarea((empty($shortcode)) ? $default_shortcode : $shortcode); ?></textarea>
            </p>

            <?php
                      $default_folder_template = '%wc_order_id% (%user_email%)/%wc_product_name%';
        $folder_template = get_post_meta($post->ID, 'useyourdrive_upload_box_folder_template', true);

        woocommerce_wp_text_input(
            [
                'id' => 'useyourdrive_upload_box_folder_template',
                'label' => esc_html__('Upload Folder Name', 'wpcloudplugins'),
                'description' => esc_html__('Unique folder name where the uploads should be stored. Make sure that Personal Folder feature is enabled in the shortcode', 'wpcloudplugins').'. '.sprintf(esc_html__('Available placeholders: %s', 'wpcloudplugins'), '<code>%wc_order_id%</code>, <code>%wc_order_date_created%</code>, <code>%wc_order_quantity%</code>, <code>%wc_product_id%</code>, <code>%wc_product_sku%</code>, <code>%wc_product_quantity%</code>, <code>%wc_product_name%</code>, <code>%wc_item_id%</code>, <code>%wc_item_quantity%</code>, <code>%user_login%</code>, <code>%user_email%</code>, <code>%display_name%</code>, <code>%ID%</code>, <code>%user_role%</code>, <code>%usermeta_first_name%</code>, <code>%usermeta_last_name%</code>, <code>%usermeta_{key}%</code>, <code>%date_{date_format}%</code>, <code>%date_i18n_{date_format}%</code>, <code>%yyyy-mm-dd%</code>, <code>%directory_separator%</code>'),
                'desc_tip' => false,
                'placeholder' => $default_folder_template,
                'value' => empty($folder_template) ? $default_folder_template : $folder_template,
            ]
        );

        $upload_locations = [
            'product' => ['title' => esc_html__('Product Page', 'wpcloudplugins')],
            'cart' => ['title' => esc_html__('Cart', 'wpcloudplugins')],
            'checkout' => ['title' => esc_html__('Checkout', 'wpcloudplugins')],
            'order' => ['title' => esc_html__('Order Details', 'wpcloudplugins')],
        ];
        ?>

            <fieldset class="form-field useyourdrive_upload_location ">
                <legend><?php esc_html_e('Upload Box Locations', 'wpcloudplugins'); ?></legend>
                <ul class="wc-radios">
                    <?php foreach ($upload_locations as $upload_location_key => $upload_location) {
                        $checked = $this->is_upload_location_active($upload_location_key) ? 'checked="checked"' : ''; ?>
                    <li>
                        <label>
                            <input type="checkbox" class="select short" disabled="disabled" <?php echo $checked; ?> />
                            <?php echo $upload_location['title']; ?>
                        </label>
                    </li>
                    <?php } ?>
                </ul>
                <?php echo wc_help_tip(esc_html__('You can control this setting from the main plugin options page (Integrations > WooCommerce).', 'wpcloudplugins')); ?>
            </fieldset>
            <?php

        $useyourdrive_upload_box_active_on_status = get_post_meta($post->ID, 'useyourdrive_upload_box_active_on_status', true);
        if (empty($useyourdrive_upload_box_active_on_status) || !is_array($useyourdrive_upload_box_active_on_status)) {
            $useyourdrive_upload_box_active_on_status = ['wc-pending', 'wc-processing'];
        }

        $this->woocommerce_wp_multi_checkbox([
            'id' => 'useyourdrive_upload_box_active_on_status',
            'name' => 'useyourdrive_upload_box_active_on_status[]',
            'label' => esc_html__(''
                    .'Show when Order is', 'woocommerce'),
            'options' => wc_get_order_statuses(),
            'value' => $useyourdrive_upload_box_active_on_status,
        ]); ?>


        </div>
    </div>
</div><?php
    }

    /**
     * New Multi Checkbox field for woocommerce backend.
     *
     * @param mixed $field
     */
    public function woocommerce_wp_multi_checkbox($field)
    {
        global $thepostid, $post;

        $thepostid = empty($thepostid) ? $post->ID : $thepostid;
        $field['class'] = $field['class'] ?? 'select short';
        $field['style'] = $field['style'] ?? '';
        $field['wrapper_class'] = $field['wrapper_class'] ?? '';
        $field['value'] = $field['value'] ?? get_post_meta($thepostid, $field['id'], true);
        $field['cbvalue'] = $field['cbvalue'] ?? 'yes';
        $field['name'] = $field['name'] ?? $field['id'];
        $field['desc_tip'] = $field['desc_tip'] ?? false;

        echo '<fieldset class="form-field '.esc_attr($field['id']).'_field '.esc_attr($field['wrapper_class']).'">
    <legend>'.wp_kses_post($field['label']).'</legend>';

        if (!empty($field['description']) && false !== $field['desc_tip']) {
            echo wc_help_tip($field['description']);
        }

        echo '<ul class="wc-radios">';

        foreach ($field['options'] as $key => $value) {
            echo '<li><label><input type="checkbox" class="'.esc_attr($field['class']).'" style="'.esc_attr($field['style']).'" name="'.esc_attr($field['name']).'" value="'.esc_attr($key).'" '.(in_array($key, $field['value']) ? 'checked="checked"' : '').' /> '.esc_html($value).'</label></li>';
        }
        echo '</ul>';

        if (!empty($field['description']) && false === $field['desc_tip']) {
            echo '<span class="description">'.wp_kses_post($field['description']).'</span>';
        }

        echo '</fieldset>';
    }

    /**
     * Add the scripts and styles required for the new Data Tab.
     */
    public function add_scripts()
    {
        $current_screen = get_current_screen();

        if (!in_array($current_screen->id, ['product', 'shop_order'])) {
            return;
        }

        wp_register_style('useyourdrive-woocommerce', plugins_url('backend.css', __FILE__), USEYOURDRIVE_VERSION);
        wp_register_script('useyourdrive-woocommerce', plugins_url('backend.js', __FILE__), ['jquery', 'WPCloudPlugins.Bridge'], USEYOURDRIVE_VERSION);

        $translation_array = [
            'choose_from' => sprintf(esc_html__('Add File', 'wpcloudplugins'), 'Google Drive'),
            'download_url' => 'https://drive.google.com/open?action=useyourdrive-wc-direct-download&id=',
            'file_browser_url' => USEYOURDRIVE_ADMIN_URL.'?action=useyourdrive-getwoocommercepopup',
            'wcpd_url' => USEYOURDRIVE_ADMIN_URL.'?action=useyourdrive-wcpd-direct-download&id=',
        ];

        wp_localize_script('useyourdrive-woocommerce', 'useyourdrive_woocommerce_translation', $translation_array);
    }

    /**
     * Save the new added input fields properly.
     *
     * @param int $post_id
     */
    public function save_product_data_fields($post_id)
    {
        // Only save when the request comes from the WooCommerce product edit form.
        // Other plugins (imports, syncs, vendor dashboards) can trigger this hook without
        // the fields in the request, which would otherwise reset the upload settings.
        if (!isset($_POST['woocommerce_meta_nonce']) || !wp_verify_nonce(wp_unslash($_POST['woocommerce_meta_nonce']), 'woocommerce_save_data')) {
            return;
        }

        $is_uploadable = isset($_POST['_uploadable']) ? 'yes' : 'no';
        update_post_meta($post_id, '_uploadable', $is_uploadable);

        $useyourdrive_upload_box = isset($_POST['useyourdrive_upload_box']) ? 'yes' : 'no';
        update_post_meta($post_id, 'useyourdrive_upload_box', $useyourdrive_upload_box);

        if (isset($_POST['useyourdrive_upload_box_description']) && is_string($_POST['useyourdrive_upload_box_description'])) {
            update_post_meta($post_id, 'useyourdrive_upload_box_description', wp_kses_post(wp_unslash($_POST['useyourdrive_upload_box_description'])));
        }

        if (isset($_POST['useyourdrive_upload_box_button_text']) && is_string($_POST['useyourdrive_upload_box_button_text'])) {
            update_post_meta($post_id, 'useyourdrive_upload_box_button_text', sanitize_text_field(wp_unslash($_POST['useyourdrive_upload_box_button_text'])));
        }

        if (isset($_POST['useyourdrive_upload_box_shortcode']) && is_string($_POST['useyourdrive_upload_box_shortcode'])) {
            update_post_meta($post_id, 'useyourdrive_upload_box_shortcode', sanitize_textarea_field(wp_unslash($_POST['useyourdrive_upload_box_shortcode'])));
        }

        if (isset($_POST['useyourdrive_upload_box_folder_template']) && is_string($_POST['useyourdrive_upload_box_folder_template'])) {
            update_post_meta($post_id, 'useyourdrive_upload_box_folder_template', sanitize_text_field(wp_unslash($_POST['useyourdrive_upload_box_folder_template'])));
        }

        if (isset($_POST['useyourdrive_upload_box_active_on_status'])) {
            $post_data = $_POST['useyourdrive_upload_box_active_on_status'];
            // Data sanitization
            $sanitize_data = [];
            if (is_array($post_data) && sizeof($post_data) > 0) {
                foreach ($post_data as $value) {
                    $sanitize_data[] = esc_attr($value);
                }
            }
            update_post_meta($post_id, 'useyourdrive_upload_box_active_on_status', $sanitize_data);
        } else {
            update_post_meta($post_id, 'useyourdrive_upload_box_active_on_status', ['wc-pending', 'wc-processing']);
        }
    }

    /**
     * Add an 'Upload' Action to the Order Table.
     *
     * @param array $actions
     *
     * @return array
     */
    public function add_orders_column_actions($actions, \WC_Order $order)
    {
        if (false === $this->is_upload_location_active('order', true)) {
            return $actions;
        }

        $box_button_text = esc_html__('Upload documents', 'wpcloudplugins');

        if ($this->requires_order_uploads($order)) {
            foreach ($order->get_items() as $order_item) {
                $product = $this->get_product($order_item);

                $requires_upload = $this->requires_product_uploads($product, $order);

                if ($requires_upload) {
                    if ($this->is_product_variation($product)) {
                        $product = wc_get_product($product->get_parent_id());
                    }

                    $box_button_text = get_post_meta($product->get_id(), 'useyourdrive_upload_box_button_text', true);

                    break;
                }
            }

            $actions['upload'] = [
                'url' => $order->get_view_order_url().'#wpcp-uploads',
                'name' => $box_button_text,
            ];
        }

        return $actions;
    }

    /**
     * Add a custom column on the Admin Order Page.
     *
     * @param mixed $order
     */
    public function admin_order_item_headers($order)
    {
        if (false === $this->requires_order_uploads($order)) {
            return false;
        }

        // set the column name
        $column_name = esc_html__('Uploaded documents', 'wpcloudplugins');

        // display the column name
        echo '<th>'.$column_name.'</th>';
    }

    /**
     * Add the value for the custom column on the Admin Order Page.
     *
     * @param mixed      $_product
     * @param mixed      $item
     * @param null|mixed $item_id
     */
    public function admin_order_item_values($_product, $item, $item_id = null)
    {
        if (false === $this->requires_order_uploads($item->get_order())) {
            return false;
        }

        if (false === $this->requires_product_uploads($_product, $item->get_order())) {
            echo '<td></td>';

            return;
        }

        echo '<td>';
        $this->render_upload_field($item->get_id(), $item, $item->get_order(), null);
        echo '</td>';
    }

    /**
     * Check if the upload box should be rendered on a location.
     *
     * @param string $location
     * @param bool   $default
     */
    public function is_upload_location_active($location, $default = false)
    {
        $upload_locations = Settings::get('woocommerce_upload_locations');

        if (empty($upload_locations[$location])) {
            return $default;
        }

        if ('No' === $upload_locations[$location]) {
            return false;
        }

        return true;
    }

    /**
     * Render the Upload Box on the Product Page.
     */
    public function render_on_product_page()
    {
        if (false === $this->is_upload_location_active('product')) {
            return;
        }

        global $product;

        $this->render_upload_field_temporarily_location($product);
    }

    /**
     * @param mixed $cart_item
     */
    public function render_on_cart_page($cart_item)
    {
        if (false === $this->is_upload_location_active('cart')) {
            return;
        }

        $product_id = (int) $cart_item['product_id'];
        $variation_id = (int) ($cart_item['variation_id'] ?? 0);
        $product = wc_get_product($variation_id > 0 ? $variation_id : $product_id);

        $this->render_upload_field_temporarily_location($product, $variation_id);
    }

    public function render_on_checkout_page()
    {
        if (false === $this->is_upload_location_active('checkout')) {
            return;
        }

        $cart_items = WC()->cart->get_cart();

        if (empty($cart_items)) {
            return;
        }

        // Render the upload box for each product in the cart
        ob_start();
        foreach ($cart_items as $cart_item_key => $cart_item) {
            $product_id = (int) $cart_item['product_id'];
            $variation_id = (int) ($cart_item['variation_id'] ?? 0);
            $product = wc_get_product($variation_id > 0 ? $variation_id : $product_id);

            // Check if product requires uploads
            if (false === $this->requires_product_uploads($product, null)) {
                continue;
            }

            $product_name = $product->get_name();
            $product_permalink = get_permalink($product_id);

            echo '<strong>'.esc_html__('Product', 'wpcloudplugins').':</strong> <a href="'.esc_url($product_permalink).'" target="_blank">'.esc_html($product_name).'</a><br>';
            $this->render_upload_field_temporarily_location($product, $variation_id);
        }
        $uploads_html = ob_get_clean();

        if (!empty($uploads_html)) {
            echo '<h3>'.__('Uploads', 'wpcloudplugins').'</h3>';

            echo $uploads_html;
        }
    }

    /**
     * Render the Upload Box on the Order View.
     *
     * @param mixed $item_id
     * @param mixed $item
     * @param mixed $order
     * @param bool  $plain_text
     */
    public function render_on_order_page($item_id, $item, $order, $plain_text = false)
    {
        if ($this->is_upload_location_active('order', true)) {
            $this->render_upload_field($item_id, $item, $order, $plain_text);
        }
    }

    /**
     * Render a simplified Upload Box before order is placed.
     *
     * @param mixed $originial_product product or variation displayed in the cart-line
     * @param int   $variation_id      variation ID of the cart-line (0 for simple products)
     */
    public function render_upload_field_temporarily_location($originial_product, $variation_id = 0)
    {
        // Check if product requires uploads
        if (false === $this->requires_product_uploads($originial_product, null)) {
            return;
        }

        // Check if there is a temporarily upload location set
        $temporarily_upload_folder_data = Settings::get('woocommerce_temporary_upload_folder');
        if (empty($temporarily_upload_folder_data['account']) || empty($temporarily_upload_folder_data['id'])) {
            Helpers::log_error('A temporary folder location has not been selected, so upload cannot be enabled before checkout.', 'WooCommerce', null, __LINE__);

            return;
        }

        // Make sure that we have a WC Session with cookie and unique customer ID
        if (WC()->session && !WC()->session->has_session()) {
            WC()->session->set_customer_session_cookie(true);
        }

        wp_register_style('useyourdrive-woocommerce-frontend-css', plugins_url('frontend.css', __FILE__), ['Eva-Icons'], USEYOURDRIVE_VERSION);
        wp_enqueue_style('useyourdrive-woocommerce-frontend-css');

        /** Select the product that contains the information * */
        $meta_product = $originial_product;
        if ($this->is_product_variation($originial_product)) {
            $meta_product = wc_get_product($originial_product->get_parent_id());
        }

        // Cart-line is uniquely identified by the parent product + variation ID.
        $variation_id = (int) $variation_id;
        $product_id = (int) $meta_product->get_id();

        // Initialise or retrieve the temp upload state for this cart-line.
        // The folder_key persisted here keeps the cloud folder path stable
        // across requests and days.
        $state = WC_Temp_Upload_Store::get($product_id, $variation_id);
        if (empty($state)) {
            $state = WC_Temp_Upload_Store::init($product_id, $variation_id, [
                'account_id' => $temporarily_upload_folder_data['account'],
                'folder_id' => $temporarily_upload_folder_data['id'],
                'listtoken' => Processor::instance()->get_listtoken(),
            ]);
        }
        $folder_key = isset($state[WC_Temp_Upload_Store::FOLDER_KEY]) ? (string) $state[WC_Temp_Upload_Store::FOLDER_KEY] : '';

        $shortcode = get_post_meta($meta_product->get_id(), 'useyourdrive_upload_box_shortcode', true);
        $shortcode_params = Shortcodes::parse_attributes($shortcode, true);
        $shortcode_params['wc_product_id'] = $product_id;
        $shortcode_params['wc_variation_id'] = $variation_id;
        $shortcode_params['post_id'] = $originial_product->get_id();
        $shortcode_params['maxheight'] = '40vh';
        $shortcode_params['mode'] = 'upload';
        $shortcode_params['downloadrole'] = 'none';
        $shortcode_params['upload'] = '1';
        $shortcode_params['delete'] = '1';
        $shortcode_params['editdescription'] = '1';
        $shortcode_params['popup'] = 'wpcp_wc_temporarily_upload';
        // Stable cloud folder path: customer_id/folder_key. The folder_key is
        // generated once per cart-line so the target stays the same for the
        // entire upload cycle (no daily rotation).
        $shortcode_params['userfoldernametemplate'] = date_i18n('Y').'/'.date_i18n('m').'/'.WC()->session->get_customer_id().'/'.$folder_key;
        $shortcode_params['account'] = $temporarily_upload_folder_data['account'];
        $shortcode_params['dir'] = $temporarily_upload_folder_data['id'];
        $shortcode_params['userfolders'] = 'auto';
        $shortcode_params['viewuserfoldersrole'] = 'none';

        $show_box = apply_filters('useyourdrive_woocommerce_show_upload_field', true, null, $originial_product, $this);

        if (!$show_box) {
            return;
        }

        if (empty($shortcode_params['dir'])) {
            echo "<button class='woocommerce-button button' disabled='disabled'><i class='eva eva-alert-triangle-outline eva-lg'></i> ".esc_html__('Upload not available.', 'wpcloudplugins').'</button>';
            echo '<br/><em>'.((Helpers::check_user_role(['administrator'])) ? esc_html__('Please configure the upload location for this product.', 'wpcloudplugins') : esc_html__('Please get in touch with us to resolve this issue.', 'wpcloudplugins')).'</em>';

            return;
        }

        // Persist the resolved folder_template so move_session_uploads() can
        // later locate the temp folder on Drive even after customer/session
        // identifiers rotate.
        if (empty($state['folder_template'])) {
            $state['folder_template'] = $shortcode_params['userfoldernametemplate'];
            WC_Temp_Upload_Store::set($product_id, $variation_id, $state);
        }

        // Determine button label, description and current upload count
        $box_button_text = get_post_meta($meta_product->get_id(), 'useyourdrive_upload_box_button_text', true);
        if (empty($box_button_text)) {
            $box_button_text = esc_html__('Upload documents', 'wpcloudplugins');
        }
        $box_description = get_post_meta($meta_product->get_id(), 'useyourdrive_upload_box_description', true);

        $upload_count = count(WC_Temp_Upload_Store::get_uploads($product_id, $variation_id));

        // Pre-checkout: optional/required indicator (no enforcement, hookable)
        $is_required = (bool) apply_filters('useyourdrive_woocommerce_upload_is_required', false, $originial_product, $this);

        // Enqueue the frontend behaviour (button click -> modal)
        wp_register_script('useyourdrive-woocommerce-frontend', plugins_url('frontend.js', __FILE__), ['jquery'], USEYOURDRIVE_VERSION);
        wp_enqueue_script('useyourdrive-woocommerce-frontend');

        do_action('useyourdrive_woocommerce_before_render_upload_field', null, $originial_product, $this);

        // Pre-fill the shortcode with previously uploaded files so they show
        // again inside the modal after a refresh/navigation.
        $this->prefill_temporarily_uploads($product_id, $variation_id);

        $instance_key = 'product-'.$product_id.($variation_id > 0 ? '-'.$variation_id : '');
        $data_attr = "data-product-id='".esc_attr($product_id)."' data-variation-id='".esc_attr($variation_id)."'";

        $this->open_compact_trigger([
            'instance_key' => $instance_key,
            'data_attr' => $data_attr,
            'product_name' => $meta_product->get_name(),
            'is_required' => $is_required,
            'button_text' => $box_button_text,
            'upload_count' => $upload_count,
            'title' => $box_button_text,
        ]);

        echo Shortcodes::do_shortcode($shortcode_params);

        // Store the freshly-generated listtoken for the next render. The token
        // is only available after Shortcodes::do_shortcode() has initialised
        // the Processor for this shortcode.
        WC_Temp_Upload_Store::set_listtoken($product_id, $variation_id, Processor::instance()->get_listtoken());

        // Description Box (shown inside the modal)
        if (!empty($box_description)) {
            echo '<div class="wpcp-modal-badge"><i class="eva eva-menu-outline eva-lg"></i> '.esc_html__('Description', 'wpcloudplugins').'</div>';
            echo do_shortcode('<p>'.wp_kses_post($this->set_placeholders($box_description, null, null, $originial_product)).'</p>');
        }

        $this->close_compact_trigger();

        do_action('useyourdrive_woocommerce_after_render_upload_field', null, $originial_product, $this);
    }

    /**
     * Render the Upload Box.
     *
     * @param mixed $item_id
     * @param mixed $item
     * @param mixed $order
     * @param bool  $plain_text
     */
    public function render_upload_field($item_id, $item, $order, $plain_text = false)
    {
        $originial_product = $this->get_product($item);

        if (false === $this->requires_product_uploads($originial_product, $order)) {
            return;
        }

        wp_register_style('useyourdrive-woocommerce-frontend-css', plugins_url('frontend.css', __FILE__), ['Eva-Icons'], USEYOURDRIVE_VERSION);
        wp_enqueue_style('useyourdrive-woocommerce-frontend-css');

        /** Select the product that contains the information * */
        $meta_product = $originial_product;
        if ($this->is_product_variation($originial_product)) {
            $meta_product = wc_get_product($originial_product->get_parent_id());
        }

        $box_description = get_post_meta($meta_product->get_id(), 'useyourdrive_upload_box_description', true);
        $box_button_text = get_post_meta($meta_product->get_id(), 'useyourdrive_upload_box_button_text', true);
        $shortcode = get_post_meta($meta_product->get_id(), 'useyourdrive_upload_box_shortcode', true);
        $folder_template = get_post_meta($meta_product->get_id(), 'useyourdrive_upload_box_folder_template', true);
        $upload_active_on = get_post_meta($meta_product->get_id(), 'useyourdrive_upload_box_active_on_status', true);
        if (empty($upload_active_on) || !is_array($upload_active_on)) {
            $upload_active_on = ['wc-pending', 'wc-processing'];
        }
        $upload_active = in_array('wc-'.$order->get_status(), $upload_active_on);

        if (empty($box_button_text)) {
            $box_button_text = esc_html__('Upload documents', 'wpcloudplugins');
        }

        // Don't include upload box in email notifications
        $is_sending_mail = doing_action('woocommerce_email_order_details');

        if ($is_sending_mail || (!is_wc_endpoint_url() && !is_admin())) {
            $order_url = $order->get_view_order_url()."#wpcp-useyourdrive-uploads-{$item_id}";

            if ($upload_active) {
                $email_upload_message = '<br/><small>'.sprintf(esc_html__('You can upload your documents on the %sorder page%s', 'wpcloudplugins'), '<a href="'.$order_url.'">', '</a>').'.</small>';
                echo apply_filters('useyourdrive_woocommerce_email_upload_message', $email_upload_message, $order, $item, $this);
            }

            return;
        }

        $shortcode_params = Shortcodes::parse_attributes($shortcode, true);
        $shortcode_params['userfoldernametemplate'] = $this->set_placeholders($folder_template, $item, $order, $originial_product);
        $shortcode_params['wc_order_id'] = $order->get_id();
        $shortcode_params['wc_product_id'] = $originial_product->get_id();
        $shortcode_params['wc_item_id'] = $item->get_id();
        $shortcode_params['maxheight'] = '40vh';

        // When Upload box isn't active, change it to a view only file browser
        if (false === $upload_active) {
            $shortcode_params['mode'] = 'files';
            $shortcode_params['upload'] = '0';
            $shortcode_params['delete'] = '0';
            $shortcode_params['rename'] = '0';
            $shortcode_params['candownloadzip'] = '1';
            $shortcode_params['editdescription'] = '0';
        }

        $show_box = apply_filters('useyourdrive_woocommerce_show_upload_field', true, $order, $originial_product, $this);

        $is_admin_page = is_admin();
        if ($is_admin_page) {
            // Always show the File Browser mode in the Dashboard

            $shortcode_params['showbreadcrumb'] = '1';
            $shortcode_params['mode'] = 'files';
            $shortcode_params['candownloadzip'] = '1';
            $shortcode_params['viewuserfoldersrole'] = 'none';

            // Meta Box is located inside Form tag, so force the plugin to start the update
            $shortcode_params['class'] = (isset($shortcode_params['class']) ? $shortcode_params['class'].' auto_upload' : 'auto_upload');

            $show_box = true;
        }

        if ($show_box) {
            $module_incomplete_configuration = empty($shortcode_params['dir']) && (!empty($shortcode_params['userfolders']) && 'auto' === $shortcode_params['userfolders']);

            // Don't show the upload box when there isn't a root folder selected
            if ($module_incomplete_configuration) {
                echo "<div id='wpcp-useyourdrive-uploads-{$item_id}' class='wpcp-useyourdrive wpcp-upload-container ".($is_admin_page ? 'wpcp-uploads-container-admin' : '')."' data-item-id='{$item_id}'>";
                echo "<button class='woocommerce-button button' disabled='disabled'><i class='eva eva-alert-triangle-outline eva-lg'></i> ".esc_html__('Upload not available.', 'wpcloudplugins').'</button>';
                echo '<br/><em>'.(($is_admin_page) ? esc_html__('Please configure the upload location for this product.', 'wpcloudplugins') : esc_html__('Please get in touch with us to resolve this issue.', 'wpcloudplugins')).'</em>';
                echo '</div>';
            } else {
                wp_register_script('useyourdrive-woocommerce-frontend', plugins_url('frontend.js', __FILE__), ['jquery'], USEYOURDRIVE_VERSION);
                wp_enqueue_script('useyourdrive-woocommerce-frontend');

                $modal_title = ($is_admin_page) ? esc_html__('View documents', 'wpcloudplugins') : $box_button_text;

                $this->open_compact_trigger([
                    'instance_key' => (string) $item_id,
                    'data_attr' => "data-item-id='".esc_attr($item_id)."'",
                    'product_name' => $meta_product->get_name(),
                    'is_required' => null, // post-checkout: hide indicator
                    'button_text' => $modal_title,
                    'upload_count' => 0,
                    'is_admin' => $is_admin_page,
                    'order_text' => esc_html__('Order #', 'woocommerce').$order->get_order_number(),
                    'title' => $modal_title,
                ]);

                do_action('useyourdrive_woocommerce_before_render_upload_field', $order, $originial_product, $this);

                echo Shortcodes::do_shortcode($shortcode_params);

                do_action('useyourdrive_woocommerce_after_render_upload_field', $order, $originial_product, $this);

                // Description Box (shown inside the modal)
                if (!empty($box_description)) {
                    echo '<div class="wpcp-modal-badge"><i class="eva eva-menu-outline eva-lg"></i> '.esc_html__('Description', 'wpcloudplugins').'</div>';
                    echo do_shortcode('<p>'.wp_kses_post($this->set_placeholders($box_description, $item, $order, $originial_product)).'</p>');
                }

                $this->close_compact_trigger();
            }
        }
    }

    /**
     * Return the temp upload state for a cart-line (back-compat wrapper).
     *
     * @param int $product_id   parent product ID
     * @param int $variation_id variation ID (0 for simple products)
     *
     * @return null|array
     */
    public function get_temporary_session($product_id, $variation_id = 0)
    {
        return WC_Temp_Upload_Store::get((int) $product_id, (int) $variation_id);
    }

    /**
     * Inject the previously uploaded files into the upload shortcode input
     * field so the Upload Box re-renders them on the next request.
     *
     * @param int $product_id   parent product ID
     * @param int $variation_id variation ID (0 for simple products)
     */
    public function prefill_temporarily_uploads($product_id, $variation_id = 0)
    {
        $upload_session = WC_Temp_Upload_Store::get((int) $product_id, (int) $variation_id);

        if (empty($upload_session) || empty($upload_session['uploads']) || empty($upload_session['listtoken'])) {
            return;
        }

        $prefill = [];

        foreach ($upload_session['uploads'] as $entry_id => $data) {
            $prefill[$entry_id] = [
                'hash' => $entry_id,
                'account_id' => $data['account_id'],
                'name' => $data['name'],
                'description' => $data['description'],
                'type' => $data['type'],
                'path' => $data['relative_path'],
                'absolute_path' => $data['absolute_path'],
                'size' => $data['filesize'],
                'preview_url' => $data['preview_url'],
                'shared_url' => $data['shared_url'],
                'folder_absolute_path' => $data['folder_absolute_path'],
                'folder_relative_path' => $data['folder_relative_path'],
                'folder_preview_url' => $data['folder_preview_url'],
                'folder_shared_url' => $data['folder_shared_url'],
            ];
        }

        $_REQUEST['fileupload-filelist_'.$upload_session['listtoken']] = json_encode($prefill);
    }

    /**
     * Persist freshly uploaded files into the pre-checkout temp store.
     *
     * Hooked on `useyourdrive_upload_post_process_data`.
     *
     * @param array $files map of entry_id => upload metadata
     *
     * @return array pass-through value for the filter chain
     */
    public function save_temporary_uploads($files)
    {
        if (
            'upload' === Processor::instance()->get_shortcode_option('mode')
             && 'wpcp_wc_temporarily_upload' === Processor::instance()->get_shortcode_option('popup')
        ) {
            $product_id = (int) Processor::instance()->get_shortcode_option('wc_product_id');
            $variation_id = (int) Processor::instance()->get_shortcode_option('wc_variation_id');

            if ($product_id > 0) {
                WC_Temp_Upload_Store::add_uploads(
                    $product_id,
                    $variation_id,
                    $files,
                    Processor::instance()->get_listtoken()
                );
            }
        }

        return $files;
    }

    /**
     * Remove deleted entries from the WC temporary upload state.
     *
     * Fires on the `useyourdrive_api_after_delete` hook. When the current
     * request originates from a pre-checkout Upload Box (mode `upload` with
     * popup `wpcp_wc_temporarily_upload`) the deleted entry IDs are pruned
     * from the per-cart-line state so the badge and file list stay in sync
     * with the actual Drive contents.
     *
     * @param array $deleted_entries map of entry_id => CacheNode of deleted entries
     * @param array $params          extra parameters passed by API::delete()
     */
    public function remove_temporary_uploads($deleted_entries, $params = [])
    {
        if (empty($deleted_entries)) {
            return;
        }

        if (
            'upload' !== Processor::instance()->get_shortcode_option('mode')
            || 'wpcp_wc_temporarily_upload' !== Processor::instance()->get_shortcode_option('popup')
        ) {
            return;
        }

        $product_id = (int) Processor::instance()->get_shortcode_option('wc_product_id');
        $variation_id = (int) Processor::instance()->get_shortcode_option('wc_variation_id');

        if ($product_id <= 0) {
            return;
        }

        WC_Temp_Upload_Store::remove_uploads($product_id, $variation_id, array_keys($deleted_entries));
    }

    /**
     * Clear the temp upload state when a cart line is removed.
     *
     * The file contents stay on Drive (orphaned in the configured temp folder)
     * so administrators can recover them if needed; only the session pointer
     * is dropped. A future cleanup job can prune the orphans by `last_activity`.
     *
     * @param string   $cart_item_key key of the removed cart item
     * @param \WC_Cart $cart          the WooCommerce cart instance
     */
    public function on_cart_item_removed($cart_item_key, $cart)
    {
        if (!is_object($cart) || empty($cart->removed_cart_contents[$cart_item_key])) {
            return;
        }

        $removed = $cart->removed_cart_contents[$cart_item_key];
        $product_id = (int) ($removed['product_id'] ?? 0);
        $variation_id = (int) ($removed['variation_id'] ?? 0);

        if ($product_id <= 0) {
            return;
        }

        WC_Temp_Upload_Store::remove($product_id, $variation_id);
    }

    /**
     * Restore the temp upload state when a removed cart line is undone.
     *
     * WooCommerce stores the removed cart contents until the customer clicks
     * Undo, so the session entry can simply remain present. This method exists
     * to make the lifecycle explicit and to bump the activity timestamp.
     *
     * @param string   $cart_item_key key of the restored cart item
     * @param \WC_Cart $cart          the WooCommerce cart instance
     */
    public function on_cart_item_restored($cart_item_key, $cart)
    {
        if (!is_object($cart) || empty($cart->cart_contents[$cart_item_key])) {
            return;
        }

        $restored = $cart->cart_contents[$cart_item_key];
        $product_id = (int) ($restored['product_id'] ?? 0);
        $variation_id = (int) ($restored['variation_id'] ?? 0);

        if ($product_id <= 0) {
            return;
        }

        $state = WC_Temp_Upload_Store::get($product_id, $variation_id);
        if (!empty($state)) {
            WC_Temp_Upload_Store::set($product_id, $variation_id, $state);
        }
    }

    /**
     * Drop every temp upload session entry when the cart is emptied.
     */
    public function on_cart_emptied()
    {
        WC_Temp_Upload_Store::clear_all();
    }

    /**
     * Move the uploaded files to the correct location.
     *
     * @param mixed $order_id
     * @param mixed $posted_data
     */
    public function move_session_uploads($order_id, $posted_data)
    {
        $order = wc_get_order($order_id);

        if (false === ($order instanceof \WC_Order)) {
            return false;
        }

        foreach ($order->get_items() as $item_id => $order_item) {
            $originial_product = $this->get_product($order_item);

            $requires_upload = $this->requires_product_uploads($originial_product, $order);

            if (!$requires_upload) {
                continue;
            }

            /** Select the product that contains the information * */
            $meta_product = $originial_product;
            if ($this->is_product_variation($originial_product)) {
                $meta_product = wc_get_product($originial_product->get_parent_id());
            }

            // Cart-line is identified by (parent product, variation)
            $product_id = (int) $meta_product->get_id();
            $variation_id = (int) (method_exists($order_item, 'get_variation_id') ? $order_item->get_variation_id() : 0);

            // Get the upload data from the session
            $upload_data = WC_Temp_Upload_Store::get($product_id, $variation_id);

            if (empty($upload_data)) {
                continue;
            }

            // Get the location of the temporarily folder
            App::set_current_account_by_id($upload_data['account_id']);
            $temporarily_folder = API::get_sub_folder_by_path($upload_data['folder_id'], $upload_data['folder_template']);

            // Move the files to the correct location
            if (!empty($temporarily_folder)) {
                $shortcode = get_post_meta($meta_product->get_id(), 'useyourdrive_upload_box_shortcode', true);
                $folder_template = get_post_meta($meta_product->get_id(), 'useyourdrive_upload_box_folder_template', true);

                $shortcode_params = Shortcodes::parse_attributes($shortcode, true);
                $folder_template = $this->set_placeholders($folder_template, $order_item, $order, $originial_product);

                App::set_current_account_by_id($shortcode_params['account']);
                $order_folder = API::get_sub_folder_by_path($shortcode_params['dir'], $folder_template, true);
                API::move_folder_content($temporarily_folder->get_id(), $order_folder->get_id());

                // Delete the temp folder
                API::delete([$temporarily_folder->get_id()], false);
            }

            // Clear the session entry for this cart-line
            WC_Temp_Upload_Store::remove($product_id, $variation_id);
        }

        // Final safety net: any cart-line state that lingered (e.g. product was
        // removed from the cart before checkout) is dropped so the next visit
        // starts with a clean slate.
        WC_Temp_Upload_Store::clear_all();
    }

    /**
     * Checks if the order uses this upload functionality.
     *
     * @param \WC_Order $order
     *
     * @return bool
     */
    public function requires_order_uploads($order)
    {
        if (false === ($order instanceof \WC_Order)) {
            return false;
        }

        foreach ($order->get_items() as $order_item) {
            $product = $this->get_product($order_item);
            $requires_upload = $this->requires_product_uploads($product, $order);

            if ($requires_upload) {
                return true;
            }
        }

        return false;
    }

    /**
     * Checks if the product uses this upload functionality.
     *
     * @param null|mixed $order
     * @param null|mixed $product
     *
     * @return bool
     */
    public function requires_product_uploads($product = null, $order = null)
    {
        if (empty($product) || !($product instanceof \WC_Product)) {
            return false;
        }

        if ($this->is_product_variation($product)) {
            $product = wc_get_product($product->get_parent_id());
        }

        $_uploadable = get_post_meta($product->get_id(), '_uploadable', true);

        if ('yes' !== $_uploadable) {
            return false;
        }

        $_useyourdrive_upload_box = get_post_meta($product->get_id(), 'useyourdrive_upload_box', true);

        if ('yes' !== $_useyourdrive_upload_box) {
            return false;
        }

        if (!empty($order)) {
            $upload_active_on = get_post_meta($product->get_id(), 'useyourdrive_upload_box_active_on_status', true);
            if (empty($upload_active_on) || !is_array($upload_active_on)) {
                $upload_active_on = ['wc-pending', 'wc-processing'];
            }

            $upload_active = in_array('wc-'.$order->get_status(), $upload_active_on);
        } else {
            $upload_active = true;
        }

        if (\is_admin()) {
            $current_screen = \get_current_screen();
            if (!empty($current_screen) && in_array($current_screen->post_type, ['shop_order'])) {
                $upload_active = true;
            } elseif (!isset($_REQUEST['type']) || 'wc-item-details' !== $_REQUEST['type'] || \current_user_can('edit_shop_orders')) {
                $upload_active = true;
            }
        }

        $show_upload_box = apply_filters('useyourdrive_woocommerce_show_upload_field', $upload_active, $order, $product, $this);

        if ($show_upload_box) {
            return true;
        }

        return false;
    }

    /**
     * Loads the product or its parent product in case of a variation.
     *
     * @param type $order_item
     *
     * @return \WC_Product
     */
    public function get_product($order_item)
    {
        $product = $order_item->get_product();

        if (empty($product) || !($product instanceof \WC_Product)) {
            return false;
        }

        return $product;
    }

    /**
     * Check if product is a variation
     * Upload meta data is currently only stored on the parent product.
     *
     * @param mixed $product
     *
     * @return bool
     */
    public function is_product_variation($product)
    {
        $product_type = $product->get_type();

        return 'variation' === $product_type;
    }

    /**
     * Fill the placeholders with the User/Product/Order information.
     *
     * @param string $template
     *
     * @return string
     */
    public function set_placeholders($template, ?\WC_Order_Item_Product $item, ?\WC_Order $order, \WC_Product $product)
    {
        $user = !empty($order) ? $order->get_user() : null;

        $placeholders_extra = [
            'user_data' => $user,
            'wc_order' => $order,
            'wc_product' => $product,
            'wc_item' => $item,
        ];

        // Guest User
        if (empty($user) && !empty($order)) {
            $user_id = $order->get_order_key();
            $guest_user = new \stdClass();
            $guest_user->user_login = $order->get_billing_first_name().' '.$order->get_billing_last_name();
            $guest_user->display_name = $order->get_billing_first_name().' '.$order->get_billing_last_name();
            $guest_user->user_email = $order->get_billing_email();
            $guest_user->ID = $user_id;
            $guest_user->user_role = esc_html__('Anonymous user', 'wpcloudplugins');

            $placeholders_extra['user_data'] = $guest_user;
            $placeholders_extra['custom_user_metadata'] = [
                'first_name' => $order->get_billing_first_name(),
                'last_name' => $order->get_billing_last_name(),
            ];
        }

        // Apply placeholders
        $output = Placeholders::apply(
            $template,
            Processor::instance(),
            $placeholders_extra
        );

        return apply_filters('useyourdrive_woocommerce_set_placeholders', $output, $template, $order, $product, $item);
    }

    public function modify_shortcode_builder($standalone, $uploadbox_only, $for, $callback)
    {
        if ('woocommerce' !== $for) {
            return;
        }

        add_filter('useyourdrive_shortcodebuilder_fields', function ($fields) {
            unset($fields['personal_folders']['smartclient_panel']['fields']['personal_folder_auto_panel']['fields']['userfoldernametemplate']);

            return $fields;
        }, 10, 1);
        ShortcodeBuilder::instance()->reset();
    }

    public function get_item_details($action, $processor)
    {
        if ('useyourdrive-get-filelist' !== $action || !isset($_REQUEST['type'])) {
            return;
        }

        $request_type = $_REQUEST['type'];

        // Pre-checkout: list files straight from the WC session (no API call)
        if ('wc-product-temp' === $request_type) {
            $this->get_product_temp_details();

            return;
        }

        if ('wc-item-details' !== $request_type) {
            return;
        }

        // Check if item indeed requires uploads
        if (!isset($_REQUEST['item_id'])) {
            echo json_encode([]);

            exit;
        }

        $order_item_id = \sanitize_key($_REQUEST['item_id']);

        // The requested item has to be the item this module was rendered for.
        // The listtoken is already scoped to a single order item, so this makes
        // sure the authorisation checks below are done on the same item as the
        // folder that is listed further down. Guest orders are supported, as
        // they use the same listtoken.
        $module_item_id = Processor::instance()->get_shortcode_option('wc_item_id');

        if (!empty($module_item_id)) {
            if ((int) $module_item_id !== (int) $order_item_id) {
                echo json_encode([]);

                exit;
            }
        } elseif (false === \current_user_can('edit_shop_orders')) {
            echo json_encode([]);

            exit;
        }

        $item = new \WC_Order_Item_Product($order_item_id);

        if (false === $this->requires_order_uploads($item->get_order())) {
            echo json_encode([]);

            exit;
        }

        if (false === $this->requires_product_uploads($item->get_product(), $item->get_order())) {
            echo json_encode([]);

            exit;
        }

        // List the uploads
        $data = [];

        try {
            $folder = Client::instance()->get_folder();
            $entries = Client::instance()->get_entries_in_subfolders($folder['folder']);

            foreach ($entries as $entry_id => $node) {
                if ($node->is_dir()) {
                    continue;
                }
                $data[$entry_id] = [
                    'name' => $node->get_name(),
                    'icon' => $node->get_entry()->get_icon(),
                    'url' => USEYOURDRIVE_ADMIN_URL.'?action=useyourdrive-download&dl=1&id='.$node->get_id().'&account_id='.App::get_current_account()->get_uuid().'&listtoken='.Processor::instance()->get_listtoken(),
                ];
            }
        } catch (\Exception $ex) {
        }

        $data = \apply_filters('useyourdrive_woocommerce_uploaded_filelist', $data, $entries, $item);

        header('Content-Type: application/json; charset=utf-8');

        echo \json_encode($data);

        exit;
    }

    /**
     * Output the opening markup for the compact upload trigger.
     *
     * Renders an outer container, optional product label and required/optional
     * indicator, the trigger button (with a count badge), the AJAX uploads-list
     * placeholder, and opens the hidden `.woocommerce-order-upload-box` element
     * that the modal lifts into the dialog when the trigger is clicked.
     *
     * The caller is responsible for echoing the actual shortcode (and optional
     * description block) inside the upload-box, then calling
     * `close_compact_trigger()` to close both the upload-box and outer container.
     *
     * @param array $args {
     *
     * @var string    $instance_key unique DOM-id suffix
     * @var string    $data_attr    pre-built `data-item-id` or `data-product-id` attribute
     * @var string    $product_name product label shown before the button
     * @var null|bool $is_required null hides the indicator, true = required, false = optional
     * @var string    $button_text  visible label on the trigger button
     * @var int       $upload_count current upload count (0 hides the badge)
     * @var string    $title        Modal title (used by frontend.js).
     * @var string    $order_text   optional order # badge text (post-checkout only)
     * @var bool      $is_admin     Whether to add the admin container class.
     *                }
     */
    protected function open_compact_trigger(array $args)
    {
        $instance_key = (string) ($args['instance_key'] ?? '');
        $data_attr = (string) ($args['data_attr'] ?? '');
        $product_name = (string) ($args['product_name'] ?? '');
        $is_required = array_key_exists('is_required', $args) ? $args['is_required'] : null;
        $button_text = (string) ($args['button_text'] ?? esc_html__('Upload documents', 'wpcloudplugins'));
        $upload_count = (int) ($args['upload_count'] ?? 0);
        $title = (string) ($args['title'] ?? $button_text);
        $order_text = (string) ($args['order_text'] ?? '');
        $is_admin = !empty($args['is_admin']);

        $admin_class = $is_admin ? ' wpcp-uploads-container-admin' : '';

        echo "<div id='wpcp-useyourdrive-uploads-".esc_attr($instance_key)."' class='wpcp-useyourdrive wpcp-upload-container".$admin_class."' ".$data_attr.'>';

        // Product label (gives context in cart/checkout/order-details)
        if ('' !== $product_name) {
            echo '<span class="wpcp-wc-upload-product-name">'.esc_html($product_name).'</span> ';
        }

        // Required/Optional indicator (pre-checkout only)
        if (null !== $is_required) {
            $indicator_class = $is_required ? 'wpcp-wc-upload-required' : 'wpcp-wc-upload-optional';
            $indicator_label = $is_required ? esc_html__('Required', 'wpcloudplugins') : esc_html__('Optional', 'wpcloudplugins');
            echo '<span class="'.$indicator_class.'">'.$indicator_label.'</span> ';
        }

        // Trigger button with count badge
        $badge_hidden = $upload_count > 0 ? '' : ' hidden';
        $badge_value = $upload_count > 0 ? esc_html((string) $upload_count) : '';

        echo "<a class='woocommerce-button button wpcp-wc-open-box'>"
            ."<i class='eva eva-attach eva-lg'></i> ".esc_html($button_text)
            ." <span class='wpcp-uploads-badge'".$badge_hidden.'>'.$badge_value.'</span>'
            .'</a>';

        // Placeholder for the AJAX-loaded list of uploaded files
        echo '<ul class="wpcp-uploads-list"><div class="loading initialize"><svg class="loader-spinner" viewBox="25 25 50 50"><circle class="path" cx="50" cy="50" r="20" fill="none" stroke-width="3" stroke-miterlimit="10"></circle></svg></div></ul>';

        // Open the hidden upload-box wrapper (lifted into the modal on click)
        echo "<div class='woocommerce-order-upload-box' style='display:none;'";
        if ('' !== $order_text) {
            echo " data-order='".esc_attr($order_text)."'";
        }
        echo " data-product-name='".esc_attr($product_name)."'";
        echo " data-title='".esc_attr($title)."'>";
    }

    /**
     * Close the markup opened by `open_compact_trigger()`.
     *
     * Closes the hidden upload-box wrapper and the outer container in one call.
     */
    protected function close_compact_trigger()
    {
        echo '</div></div>';
    }

    /**
     * Return uploaded files for a pre-checkout product context.
     *
     * Reads the temporary upload data straight from the WooCommerce session
     * (populated by `save_temporary_uploads()`), so the badge and file list
     * reflect the current modal state without hitting the cloud API.
     */
    protected function get_product_temp_details()
    {
        $product_id = isset($_REQUEST['product_id']) ? (int) $_REQUEST['product_id'] : 0;
        $variation_id = isset($_REQUEST['variation_id']) ? (int) $_REQUEST['variation_id'] : 0;
        $data = [];

        if ($product_id > 0 && WC()->session) {
            $uploads = WC_Temp_Upload_Store::get_uploads($product_id, $variation_id);

            foreach ($uploads as $entry_id => $upload) {
                $url = !empty($upload['preview_url'])
                    ? $upload['preview_url']
                    : (!empty($upload['shared_url']) ? $upload['shared_url'] : '#');

                $data[$entry_id] = [
                    'name' => isset($upload['name']) ? $upload['name'] : '',
                    'icon' => isset($upload['icon']) ? $upload['icon'] : '',
                    'url' => $url,
                ];
            }
        }

        $data = \apply_filters('useyourdrive_woocommerce_uploaded_temp_filelist', $data, $product_id, $variation_id);

        header('Content-Type: application/json; charset=utf-8');

        echo \json_encode($data);

        exit;
    }
}

new WooCommerce_Uploads();
