<?php

namespace WPAICG\Lib\AIForms;

use WPAICG\Lib\Utils\AIPKit_Pdf_Parser;
use WP_Error;

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

/** Paid AI Form uploads and stream image processing, called by shared request adapters. */
final class Processor
{
    public static function upload_and_parse_file(): void
    {
        if (!class_exists('\\WPAICG\\aipkit_dashboard') || !\WPAICG\aipkit_dashboard::is_pro_plan()) {
            wp_send_json_error(['message' => __('This is a Pro feature.', 'gpt3-ai-content-generator')], 403);
            return;
        }

        // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Reason: The shared AJAX adapter verifies the upload nonce before delegation.
        if (!isset($_FILES['file'])) {
            wp_send_json_error(['message' => __('No file received.', 'gpt3-ai-content-generator')], 400);
            return;
        }

        // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized, WordPress.Security.NonceVerification.Missing -- Reason: The shared AJAX adapter verifies the nonce; AIPKit_Upload_Utils::validate_upload_file validates $_FILES below.
        $file_data = $_FILES['file'];

        if (!class_exists('\\WPAICG\\Includes\\AIPKit_Upload_Utils')) {
            wp_send_json_error(['message' => __('File validation component is missing.', 'gpt3-ai-content-generator')], 500);
            return;
        }

        // Using the same validation logic as vector store uploads (checks size and MIME)
        $allowed_mime_types = \WPAICG\Includes\AIPKit_Upload_Utils::get_vector_upload_allowed_mime_types();
        $validation_result = \WPAICG\Includes\AIPKit_Upload_Utils::validate_upload_file($file_data, $allowed_mime_types);

        if (is_wp_error($validation_result)) {
            wp_send_json_error(['message' => $validation_result->get_error_message()], 400);
            return;
        }

        $parse_result = \WPAICG\Lib\AIForms\AIPKit_AI_Form_File_Parser::parse_file($file_data);

        if (is_wp_error($parse_result)) {
            wp_send_json_error(['message' => $parse_result->get_error_message()], 500);
            return;
        }

        wp_send_json_success(['text' => $parse_result]);
    }

    /**
     * Checks whether the saved AI Form contains at least one image-upload element.
     *
     * @param mixed $form_structure
     * @return bool
     */
    public static function has_image_upload_field($form_structure): bool
    {
        if (!is_array($form_structure)) {
            return false;
        }

        foreach ($form_structure as $row) {
            if (!is_array($row) || empty($row['columns']) || !is_array($row['columns'])) {
                continue;
            }

            foreach ($row['columns'] as $column) {
                if (!is_array($column) || empty($column['elements']) || !is_array($column['elements'])) {
                    continue;
                }

                foreach ($column['elements'] as $element) {
                    if (is_array($element) && ($element['type'] ?? '') === 'image-upload') {
                        return true;
                    }
                }
            }
        }

        return false;
    }

    /**
     * Validates provider image capability after form and quota validation.
     *
     * @return mixed|WP_Error Filter result, including a provider validation error.
     */
    public static function validate_stream_images(array $image_inputs, string $provider, string $model, array $form_config)
    {
        $providers_with_image_inputs = ['OpenAI', 'Google', 'Claude', 'OpenRouter', 'xAI', 'Ollama', 'AIPufferCloud'];
        if (!in_array($provider, $providers_with_image_inputs, true)) {
            return new WP_Error(
                'provider_no_image_input_ai_forms_logic',
                sprintf(
                    /* translators: %s: provider name */
                    __('%s does not support image analysis in AI Forms.', 'gpt3-ai-content-generator'),
                    $provider
                ),
                ['status' => 400]
            );
        }

        /**
         * Allow provider-specific image capability validation for AI Forms stream requests.
         *
         * @param mixed $validation_error Existing validation error.
         * @param array $image_inputs Normalized image input payload.
         * @param string $provider Selected provider.
         * @param string $model Selected model.
         * @param array $form_config AI Form settings.
         * @param string $flow Request flow identifier.
         */
        $image_validation_error = apply_filters(
            'aipkit_chat_image_input_validation_error',
            null,
            $image_inputs,
            $provider,
            $model,
            $form_config,
            'ai_forms_stream'
        );
        return $image_validation_error;
    }

    /** Attaches normalized images to the provider request or the payload being sanitized for logging. */
    public static function add_image_inputs(array $payload, array $image_inputs): array
    {
        $payload['image_inputs'] = $image_inputs;
        return $payload;
    }

    /** Adds safe image metadata to an AI Form event without exposing image contents. */
    public static function add_image_event_metadata(array $event_meta, $image_inputs): array
    {
        if (!is_array($image_inputs)) {
            return $event_meta;
        }

        $summary = [];
        foreach ($image_inputs as $image_input) {
            if (!is_array($image_input)) {
                continue;
            }

            $summary[] = array_filter([
                'field_id' => isset($image_input['field_id']) ? sanitize_key((string) $image_input['field_id']) : '',
                'filename' => isset($image_input['filename']) ? sanitize_file_name((string) $image_input['filename']) : '',
                'mime_type' => isset($image_input['type']) ? sanitize_text_field((string) $image_input['type']) : '',
                'size' => isset($image_input['size']) ? absint($image_input['size']) : 0,
            ], static fn($value) => $value !== '' && $value !== 0);
        }


        if (!empty($summary)) {
            $event_meta['media_inputs'] = [
                'image_count' => count($summary),
                'images' => $summary,
            ];
        }

        return $event_meta;
    }
}

/**
 * AIPKit_AI_Form_File_Parser
 *
 * Pro-only service to parse uploaded files from AI Forms and extract text content.
 */
class AIPKit_AI_Form_File_Parser
{
    /**
     * Parses the content of an uploaded file.
     *
     * @param array $file_data An item from the $_FILES superglobal array.
     * @return string|WP_Error The extracted text content or a WP_Error on failure.
     */
    public static function parse_file(array $file_data)
    {
        if (empty($file_data['tmp_name']) || !is_readable($file_data['tmp_name'])) {
            return new WP_Error('file_unreadable', __('Uploaded file is not readable or missing.', 'gpt3-ai-content-generator'));
        }

        // Determine MIME type reliably if possible
        $file_mime_type = '';
        if (function_exists('mime_content_type') && is_readable($file_data['tmp_name'])) {
            $file_mime_type = mime_content_type($file_data['tmp_name']);
        } elseif (isset($file_data['type'])) {
            $file_mime_type = $file_data['type']; // Fallback to browser-sent type
        }

        if (empty($file_mime_type)) {
            return new WP_Error('unknown_mime_type', __('Could not determine the file type.', 'gpt3-ai-content-generator'));
        }

        switch ($file_mime_type) {
            case 'text/plain':
                $content = file_get_contents($file_data['tmp_name']);
                if ($content === false) {
                    return new WP_Error('read_error_txt', __('Failed to read the plain text file.', 'gpt3-ai-content-generator'));
                }
                return $content;

            case 'application/pdf':
                if (!class_exists(AIPKit_Pdf_Parser::class)) {
                    $pdf_parser_path = WPAICG_LIB_DIR . 'knowledge-base/pdf-parser.php';
                    if (file_exists($pdf_parser_path)) {
                        require_once $pdf_parser_path;
                    } else {
                        return new WP_Error('pdf_parser_missing', __('PDF parsing library is unavailable.', 'gpt3-ai-content-generator'));
                    }
                }
                $pdf_parser = new AIPKit_Pdf_Parser();
                $extracted_text_or_error = $pdf_parser->extract_text($file_data['tmp_name']);
                if (is_wp_error($extracted_text_or_error)) {
                    return $extracted_text_or_error;
                }
                return $extracted_text_or_error;

            default:
                /* translators: %s is the MIME type */
                return new WP_Error('unsupported_file_type', sprintf(__('The file type "%s" is not supported for content extraction.', 'gpt3-ai-content-generator'), esc_html($file_mime_type)));
        }
    }
}
