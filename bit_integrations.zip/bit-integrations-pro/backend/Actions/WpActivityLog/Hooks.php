<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Actions\WpActivityLog\WpActivityLogProHelper;
use BitApps\IntegrationsPro\Config;
use BitApps\IntegrationsPro\Core\Util\Hooks;

Hooks::filter(Config::withFreePrefix('wp_activity_log_log_event'), [WpActivityLogProHelper::class, 'logEvent'], 10, 4);
Hooks::filter(Config::withFreePrefix('wp_activity_log_delete_event'), [WpActivityLogProHelper::class, 'deleteEvent'], 10, 2);
Hooks::filter(Config::withFreePrefix('wp_activity_log_delete_events'), [WpActivityLogProHelper::class, 'deleteEvents'], 10, 3);
Hooks::filter(Config::withFreePrefix('wp_activity_log_delete_events_older_than'), [WpActivityLogProHelper::class, 'deleteEventsOlderThan'], 10, 3);
Hooks::filter(Config::withFreePrefix('wp_activity_log_enable_event'), [WpActivityLogProHelper::class, 'enableEvent'], 10, 2);
Hooks::filter(Config::withFreePrefix('wp_activity_log_disable_event'), [WpActivityLogProHelper::class, 'disableEvent'], 10, 2);
Hooks::filter(Config::withFreePrefix('wp_activity_log_exclude_user'), [WpActivityLogProHelper::class, 'excludeUser'], 10, 2);
Hooks::filter(Config::withFreePrefix('wp_activity_log_remove_user_exclusion'), [WpActivityLogProHelper::class, 'removeUserExclusion'], 10, 2);
Hooks::filter(Config::withFreePrefix('wp_activity_log_exclude_role'), [WpActivityLogProHelper::class, 'excludeRole'], 10, 2);
Hooks::filter(Config::withFreePrefix('wp_activity_log_remove_role_exclusion'), [WpActivityLogProHelper::class, 'removeRoleExclusion'], 10, 2);
Hooks::filter(Config::withFreePrefix('wp_activity_log_exclude_ip_address'), [WpActivityLogProHelper::class, 'excludeIpAddress'], 10, 2);
Hooks::filter(Config::withFreePrefix('wp_activity_log_remove_ip_address_exclusion'), [WpActivityLogProHelper::class, 'removeIpAddressExclusion'], 10, 2);
Hooks::filter(Config::withFreePrefix('wp_activity_log_exclude_post_type'), [WpActivityLogProHelper::class, 'excludePostType'], 10, 2);
Hooks::filter(Config::withFreePrefix('wp_activity_log_remove_post_type_exclusion'), [WpActivityLogProHelper::class, 'removePostTypeExclusion'], 10, 2);
Hooks::filter(Config::withFreePrefix('wp_activity_log_exclude_post_status'), [WpActivityLogProHelper::class, 'excludePostStatus'], 10, 2);
Hooks::filter(Config::withFreePrefix('wp_activity_log_remove_post_status_exclusion'), [WpActivityLogProHelper::class, 'removePostStatusExclusion'], 10, 2);
Hooks::filter(Config::withFreePrefix('wp_activity_log_exclude_post_meta_field'), [WpActivityLogProHelper::class, 'excludePostMetaField'], 10, 2);
Hooks::filter(Config::withFreePrefix('wp_activity_log_remove_post_meta_field_exclusion'), [WpActivityLogProHelper::class, 'removePostMetaFieldExclusion'], 10, 2);
Hooks::filter(Config::withFreePrefix('wp_activity_log_exclude_user_meta_field'), [WpActivityLogProHelper::class, 'excludeUserMetaField'], 10, 2);
Hooks::filter(Config::withFreePrefix('wp_activity_log_remove_user_meta_field_exclusion'), [WpActivityLogProHelper::class, 'removeUserMetaFieldExclusion'], 10, 2);
