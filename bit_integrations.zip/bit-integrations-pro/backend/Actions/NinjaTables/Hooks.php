<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Actions\NinjaTables\NinjaTablesProHelper;
use BitApps\IntegrationsPro\Config;
use BitApps\IntegrationsPro\Core\Util\Hooks;

Hooks::filter(Config::withFreePrefix('ninjatables_add_row'), [NinjaTablesProHelper::class, 'addRowInTable'], 10, 2);
Hooks::filter(Config::withFreePrefix('ninjatables_update_row'), [NinjaTablesProHelper::class, 'updateRowInTable'], 10, 2);
