<?php

namespace FluentCartPro\App\Modules\Reports\Services;

use FluentCart\App\App;
use FluentCart\App\CPT\FluentProducts;
use FluentCart\App\Helpers\Status;
use FluentCart\App\Modules\MultiCurrency\Services\ReportCurrency;
use FluentCart\App\Services\DateTime\DateTime;
use FluentCart\App\Services\Report\CustomerReportService;
use FluentCart\App\Services\Report\ReportHelper;
use FluentCart\Framework\Support\Arr;

/**
 * The Pro sections of Reports → Customers: repeat purchases, RFM segments and customer value.
 * Extends core's service for the shared buyer history and order filters.
 */
class CustomerInsightsService extends CustomerReportService
{
    /** Days to the second purchase, grouped */
    public const SECOND_PURCHASE_BUCKETS = ['0-7' => [0, 7], '8-30' => [8, 30], '31-90' => [31, 90], '91-180' => [91, 180], '181-365' => [181, 365], '365+' => [366, null]];

    /**
     * The Customers repeat section: purchases per customer (and orders, renewals included) for the customers who
     * paid in the range, and the time to the second purchase for customers gained in the 12 months ending with the
     * range's last month
     */
    public function getRepeat(array $params): array
    {
        // Purchases start at 0: a customer who paid only renewals in the report currency (after a free trial)
        $distribution = function (string $column, array $keys) use ($params) {
            $bucket = "(CASE WHEN h.{$column} >= 5 THEN '5+' ELSE CAST(h.{$column} AS CHAR) END)";
            $rows = App::db()->query()->fromSub($this->buyerHistory($params), 'h')
                ->selectRaw("{$bucket} AS bucket, COUNT(*) AS customers")
                ->groupByRaw($bucket)
                ->pluck('customers', 'bucket')
                ->toArray();
            $out = [];
            foreach ($keys as $key) {
                $out[] = ['bucket' => $key, 'customers' => (int) ($rows[$key] ?? 0)];
            }

            return $out;
        };

        return [
            'purchases'       => $distribution('purchases', ['0', '1', '2', '3', '4', '5+']),
            'orders'          => $distribution('orders', ['1', '2', '3', '4', '5+']),
            'second_purchase' => $this->secondPurchase($params),
        ];
    }

    private function secondPurchase(array $params): array
    {
        $timezone = wp_timezone();
        $endMonth = ReportHelper::local($params['endDate'])->format('Y-m');
        $from = ReportHelper::toGmt((new DateTime($endMonth . '-01 00:00:00', $timezone))->modify('-11 months'))->format('Y-m-d H:i:s');
        $until = ReportHelper::toGmt((new DateTime($endMonth . '-01 00:00:00', $timezone))->modify('first day of next month'))->format('Y-m-d H:i:s');

        $gained = $this->gainedCustomers($params, $from, $until);
        $customers = (int) (clone $gained)->count();

        $later = $this->customerOrders($params)
            ->where('o.type', '<>', Status::ORDER_TYPE_RENEWAL)
            ->select(['o.customer_id', 'o.created_at']);
        $days = $gained->select(['fp.customer_id', 'fp.first_at'])
            ->joinSub($later, 'n', function ($join) {
                $join->on('n.customer_id', '=', 'fp.customer_id')->on('n.created_at', '>', 'fp.first_at');
            })
            ->selectRaw('TIMESTAMPDIFF(DAY, fp.first_at, MIN(n.created_at)) AS days')
            ->groupBy('fp.customer_id', 'fp.first_at')
            ->pluck('days')
            ->toArray();
        $days = array_map('intval', $days);
        sort($days);

        $buckets = [];
        foreach (self::SECOND_PURCHASE_BUCKETS as $key => [$low, $high]) {
            $buckets[] = ['bucket' => $key, 'customers' => count(array_filter($days, function ($value) use ($low, $high) {
                return $value >= $low && ($high === null || $value <= $high);
            }))];
        }
        $repeaters = count($days);
        $median = null;
        if ($repeaters) {
            $middle = intdiv($repeaters, 2);
            $median = $repeaters % 2 ? $days[$middle] : (int) round(($days[$middle - 1] + $days[$middle]) / 2);
        }

        return [
            'customers'   => $customers,
            'repeaters'   => $repeaters,
            'repeat_rate' => $customers ? round($repeaters / $customers * 100, 1) : 0.0,
            'median_days' => $median,
            'buckets'     => $buckets,
        ];
    }

    /** RFM segments in display order */
    public const SEGMENTS = ['champions', 'loyal', 'new', 'promising', 'at_risk', 'cant_lose', 'hibernating'];

    /** Quintile cut points are read from at most this many customers */
    public const SEGMENT_SAMPLE = 20000;

    /**
     * RFM segments as of today, in the report currency, over every customer with a paid order there. Recency (days
     * since the last order) and money (lifetime net) score 1-5 by the store's own quintiles; frequency (orders) by
     * fixed steps, as most customers order once. Each customer falls in one segment. Amounts in cents.
     */
    public function getSegments(array $params): array
    {
        $asOf = DateTime::gmtNow()->format('Y-m-d H:i:s');
        $cuts = $this->segmentCuts($params, $asOf);
        $scored = $this->scoredCustomers($params, $cuts, $asOf);
        $rows = App::db()->query()->fromSub($scored, 'sc')
            ->selectRaw('sc.segment, COUNT(*) AS customers, SUM(sc.net) AS net, AVG(sc.orders) AS average_orders,
                AVG(sc.days) AS average_days, AVG(sc.net) AS average_net')
            ->groupBy('sc.segment')
            ->get()
            ->keyBy('segment');

        $customers = 0;
        $total = 0;
        foreach ($rows as $row) {
            $customers += (int) $row->customers;
            $total += (int) $row->net;
        }

        $segments = [];
        foreach (self::SEGMENTS as $key) {
            $row = $rows->get($key);
            $segments[] = [
                'key'            => $key,
                'customers'      => $row ? (int) $row->customers : 0,
                'net'            => $row ? (int) $row->net : 0,
                'share'          => $row && $total > 0 ? round((int) $row->net / $total * 100, 1) : 0.0,
                'average_orders' => $row ? round((float) $row->average_orders, 1) : 0.0,
                'average_days'   => $row ? (int) round((float) $row->average_days) : 0,
                'average_net'    => $row ? (int) round((float) $row->average_net) : 0,
            ];
        }

        // The export pages reuse these, so each page reads the same segments
        return ['customers' => $customers, 'net' => $total, 'segments' => $segments, 'cuts' => $cuts, 'as_of' => $asOf];
    }

    /**
     * One segment's customers for the CSV export, highest lifetime net first
     */
    public function getSegmentCustomers(array $params, string $segment, int $page, int $perPage, $cuts = null, $asOf = null): array
    {
        if (!in_array($segment, self::SEGMENTS, true)) {
            return ['total' => 0, 'data' => []];
        }
        $perPage = max(1, min(1000, $perPage));
        $page = max(1, $page);
        $asOf = is_string($asOf) && preg_match('/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/', $asOf) ? $asOf : DateTime::gmtNow()->format('Y-m-d H:i:s');
        $cuts = self::validCuts($cuts) ?: $this->segmentCuts($params, $asOf);

        $inSegment = App::db()->query()->fromSub($this->scoredCustomers($params, $cuts, $asOf), 'sc')->where('sc.segment', $segment);
        $total = (int) (clone $inSegment)->count();
        $data = $inSegment
            ->leftJoin('fct_customers as c', 'c.id', '=', 'sc.customer_id')
            ->select(['sc.customer_id', 'sc.orders', 'sc.net', 'sc.last_at', 'c.first_name', 'c.last_name', 'c.email'])
            ->orderBy('sc.net', 'desc')
            ->orderBy('sc.customer_id')
            ->offset(($page - 1) * $perPage)
            ->limit($perPage)
            ->get()
            ->map(function ($row) {
                return [
                    'customer_id' => (int) $row->customer_id,
                    'name'        => trim($row->first_name . ' ' . $row->last_name),
                    'email'       => (string) $row->email,
                    'orders'      => (int) $row->orders,
                    'net'         => (int) $row->net,
                    'last_order'  => (string) $row->last_at,
                ];
            })
            ->all();

        return ['total' => $total, 'data' => $data];
    }

    private function segmentAggregates(array $params, string $asOf)
    {
        return $this->customerOrders($params)
            ->where('o.created_at', '<=', $asOf)
            ->selectRaw("o.customer_id, COUNT(*) AS orders, SUM(" . $this->netSql($params) . ") AS net,
                MAX(o.created_at) AS last_at, TIMESTAMPDIFF(DAY, MAX(o.created_at), '{$asOf}') AS days")
            ->groupBy('o.customer_id');
    }

    /**
     * Quintile cut points of days since the last order and of lifetime net, from an even spread of at most
     * SEGMENT_SAMPLE customers (a hash of the id, so ids stepped by the host still sample)
     *
     * @return array{days: int[], net: int[]}
     */
    private function segmentCuts(array $params, string $asOf): array
    {
        $count = (int) App::db()->query()->fromSub($this->segmentAggregates($params, $asOf), 'pc')->count();
        $step = max(1, (int) ceil($count / self::SEGMENT_SAMPLE));
        $sample = App::db()->query()->fromSub($this->segmentAggregates($params, $asOf), 'pc')
            ->when($step > 1, fn($q) => $q->whereRaw('MOD(CRC32(pc.customer_id), ' . $step . ') = 0'))
            ->select(['pc.days', 'pc.net'])
            ->get();
        $cut = function (array $values) {
            sort($values);
            $n = count($values);
            $out = [];
            foreach ([0.2, 0.4, 0.6, 0.8] as $p) {
                $out[] = $n ? (int) $values[max(0, (int) ceil($n * $p) - 1)] : 0;
            }

            return $out;
        };

        return [
            'days' => $cut(array_map(fn($row) => (int) $row->days, $sample->all())),
            'net'  => $cut(array_map(fn($row) => (int) $row->net, $sample->all())),
        ];
    }

    /**
     * Cut points as the export sends them back: four integers each, or null
     */
    public static function validCuts($cuts)
    {
        if (!is_array($cuts)) {
            return null;
        }
        $out = [];
        foreach (['days', 'net'] as $key) {
            $values = array_values((array) ($cuts[$key] ?? []));
            if (count($values) !== 4) {
                return null;
            }
            $out[$key] = array_map('intval', $values);
        }

        return $out;
    }

    /**
     * Every customer with a paid order in the report currency up to the as-of time: orders, lifetime net, days
     * since the last order, and their segment by the given cut points
     */
    private function scoredCustomers(array $params, array $cuts, string $asOf)
    {
        [$d1, $d2, $d3, $d4] = array_map('intval', $cuts['days']);
        [$m1, $m2, $m3, $m4] = array_map('intval', $cuts['net']);

        // Fewer days since the last order score higher; more money scores higher
        $recency = "(CASE WHEN pc.days > {$d4} THEN 1 WHEN pc.days > {$d3} THEN 2 WHEN pc.days > {$d2} THEN 3 WHEN pc.days > {$d1} THEN 4 ELSE 5 END)";
        $money = "(CASE WHEN pc.net > {$m4} THEN 5 WHEN pc.net > {$m3} THEN 4 WHEN pc.net > {$m2} THEN 3 WHEN pc.net > {$m1} THEN 2 ELSE 1 END)";
        $frequency = '(CASE WHEN pc.orders >= 6 THEN 5 WHEN pc.orders >= 4 THEN 4 WHEN pc.orders = 3 THEN 3 WHEN pc.orders = 2 THEN 2 ELSE 1 END)';
        $fm = "(({$frequency} + {$money}) / 2)";
        // Segments that mean "buys often" need two orders at least, however big one order was
        $segment = "(CASE
            WHEN {$recency} <= 2 AND pc.orders >= 2 AND {$fm} >= 4.5 THEN 'cant_lose'
            WHEN {$recency} <= 2 AND pc.orders >= 2 AND {$fm} >= 3 THEN 'at_risk'
            WHEN {$recency} <= 2 THEN 'hibernating'
            WHEN {$recency} >= 4 AND pc.orders >= 2 AND {$fm} >= 4 THEN 'champions'
            WHEN pc.orders >= 2 AND {$fm} >= 3 THEN 'loyal'
            WHEN pc.orders = 1 AND {$recency} = 5 THEN 'new'
            ELSE 'promising'
        END)";

        return App::db()->query()->fromSub($this->segmentAggregates($params, $asOf), 'pc')
            ->selectRaw("pc.customer_id, pc.orders, pc.net, pc.last_at, pc.days, {$segment} AS segment");
    }

    /** Revenue concentration: the share of revenue from the top N percent of customers */
    public const CONCENTRATION_TIERS = [1, 5, 10, 20, 50];

    /** Lifetime value curves follow a cohort this many months at most */
    public const VALUE_MONTHS = 24;

    /**
     * The Customers value section, in the report currency (a customer's first purchase and spend there):
     * lifetime value by first-purchase month for the 12 months ending with the range's last month, value by first
     * product for the customers gained in the range, and revenue concentration for the range and over all time.
     * Amounts in cents, order-level net.
     */
    public function getValue(array $params, bool $withLifetime = false): array
    {
        return [
            'cohorts'        => $this->valueCohorts($params),
            'first_products' => $this->valueByFirstProduct($params),
            'concentration'  => [
                'period'   => $this->concentration($params, true),
                // Over every customer the store has had: read only when asked for
                'lifetime' => $withLifetime ? $this->concentration($params, false) : null,
            ],
        ];
    }

    /**
     * Revenue concentration over all time, for the value section's "All time" switch
     */
    public function getLifetimeConcentration(array $params): array
    {
        return $this->concentration($params, false);
    }

    /**
     * Paid orders with a customer in the report currency and statuses, any date
     */
    private function customerOrders(array $params)
    {
        $orders = ReportCurrency::ordersTable($params);
        if (method_exists(ReportHelper::class, 'netSalesSql')) {
            ReportHelper::joinShippingRefund($orders);
        }

        return $orders
            ->where('o.total_paid', '>', 0)
            ->whereNotNull('o.customer_id')
            ->when(!empty($params['paymentStatus']), fn($q) => $q->whereIn('o.payment_status', $params['paymentStatus']))
            ->when(!empty($params['orderStatus']), fn($q) => $q->whereNotIn('o.status', $params['orderStatus']))
            ->when(!empty($params['currency']) && $params['currency'] !== ReportCurrency::ALL, fn($q) => $q->where('o.currency', $params['currency']));
    }

    /**
     * One order's net sales, as the Revenue report counts them; a core older than the shared net sales keeps its
     * order-level net (paid less refunds and kept tax)
     */
    private function netSql(array $params): string
    {
        return method_exists(ReportHelper::class, 'netSalesSql') ? ReportHelper::netSalesSql($params) : ReportHelper::netRevenueSql();
    }

    /**
     * Each customer's first purchase in the report currency (a renewal is never one)
     */
    private function firstPurchases(array $params, $from, $until)
    {
        // Only customers who bought in the window, so a store's whole history is not grouped
        $buyers = $this->customerOrders($params)
            ->where('o.type', '<>', Status::ORDER_TYPE_RENEWAL)
            ->where('o.created_at', '>=', $from)
            ->where('o.created_at', '<', $until)
            ->select('o.customer_id');

        return $this->customerOrders($params)
            ->where('o.type', '<>', Status::ORDER_TYPE_RENEWAL)
            ->whereIn('o.customer_id', $buyers)
            ->selectRaw('o.customer_id, MIN(o.created_at) AS first_at')
            ->groupBy('o.customer_id');
    }

    /**
     * Gained in [from, until): first purchase in the report currency there, and no earlier purchase in any currency
     * (the overview's new-customer rule)
     */
    private function gainedCustomers(array $params, string $from, string $until)
    {
        global $wpdb;
        $statuses = array_map(function ($status) {
            return "'" . esc_sql((string) $status) . "'";
        }, (array) Arr::get($params, 'paymentStatus', []));
        $paid = $statuses ? ' AND e.payment_status IN (' . implode(', ', $statuses) . ')' : '';

        return App::db()->query()->fromSub($this->firstPurchases($params, $from, $until), 'fp')
            ->where('fp.first_at', '>=', $from)
            ->where('fp.first_at', '<', $until)
            ->whereRaw("NOT EXISTS (SELECT 1 FROM {$wpdb->prefix}fct_orders e WHERE e.customer_id = fp.customer_id AND e.total_paid > 0
                AND e.type <> '" . Status::ORDER_TYPE_RENEWAL . "'{$paid} AND e.created_at < fp.first_at)");
    }

    private function valueCohorts(array $params): array
    {
        $timezone = wp_timezone();
        $endMonth = ReportHelper::local($params['endDate'])->format('Y-m');
        $first = new DateTime($endMonth . '-01 00:00:00', $timezone);
        $first->modify('-11 months');
        $from = ReportHelper::toGmt($first);
        $until = ReportHelper::toGmt((new DateTime($endMonth . '-01 00:00:00', $timezone))->modify('first day of next month'));
        $now = DateTime::gmtNow();

        $firstMonth = 'DATE_FORMAT(' . ReportHelper::storeTimeSql('fp.first_at', $from, $now) . ", '%Y-%m')";
        $orderMonth = 'DATE_FORMAT(' . ReportHelper::storeTimeSql('o.created_at', $from, $now) . ", '%Y%m')";
        $firstPeriod = 'DATE_FORMAT(' . ReportHelper::storeTimeSql('fp.first_at', $from, $now) . ", '%Y%m')";
        $offset = "PERIOD_DIFF({$orderMonth}, {$firstPeriod})";

        $cohortBuyers = $this->gainedCustomers($params, $from->format('Y-m-d H:i:s'), $until->format('Y-m-d H:i:s'));

        $sizes = (clone $cohortBuyers)->selectRaw("{$firstMonth} AS cohort, COUNT(*) AS customers")->groupByRaw($firstMonth)->get()->keyBy('cohort');

        $spend = $this->customerOrders($params)
            ->joinSub($cohortBuyers->select(['fp.customer_id', 'fp.first_at']), 'fp', 'fp.customer_id', '=', 'o.customer_id')
            ->selectRaw("{$firstMonth} AS cohort, {$offset} AS month_offset, SUM(" . $this->netSql($params) . ') AS net')
            ->groupByRaw("{$firstMonth}, {$offset}")
            ->get();
        $byCohort = [];
        foreach ($spend as $row) {
            $byCohort[(string) $row->cohort][(int) $row->month_offset] = (int) $row->net;
        }

        $nowMonth = ReportHelper::local($now)->format('Y-m');
        $cohorts = [];
        $cursor = clone $first;
        for ($index = 0; $index < 12; $index++) {
            $key = $cursor->format('Y-m');
            $customers = $sizes->has($key) ? (int) $sizes->get($key)->customers : 0;
            // Months it has lived through so far, at most VALUE_MONTHS
            $lived = $key > $nowMonth ? 0 : min(self::VALUE_MONTHS, ((int) substr($nowMonth, 0, 4) - (int) substr($key, 0, 4)) * 12
                + (int) substr($nowMonth, 5, 2) - (int) substr($key, 5, 2) + 1);
            $values = [];
            $running = 0;
            for ($month = 0; $month < $lived && $customers; $month++) {
                $running += $byCohort[$key][$month] ?? 0;
                $values[] = (int) round($running / $customers);
            }
            $cohorts[] = ['cohort' => $key, 'customers' => $customers, 'values' => $values];
            $cursor->modify('first day of next month');
        }

        return $cohorts;
    }

    /**
     * Customers whose first purchase is in the range, by the products in that first order (an order with two
     * products counts the customer for each): how many, what they have spent since on average, and the share who
     * made another purchase (renewals are not purchases)
     */
    private function valueByFirstProduct(array $params): array
    {
        $gained = $this->gainedCustomers($params, $params['startDate']->format('Y-m-d H:i:s'),
            date('Y-m-d H:i:s', $params['endDate']->getTimestamp() + 1));

        $stats = [];
        foreach ($this->customerOrders($params)
            ->joinSub((clone $gained)->select('fp.customer_id'), 'g', 'g.customer_id', '=', 'o.customer_id')
            ->selectRaw("o.customer_id, SUM(" . $this->netSql($params) . ") AS lifetime_net,
                SUM(o.type <> '" . Status::ORDER_TYPE_RENEWAL . "') AS purchases")
            ->groupBy('o.customer_id')
            ->get() as $row) {
            $stats[(int) $row->customer_id] = [(int) $row->lifetime_net, (int) $row->purchases];
        }

        $pairs = $this->customerOrders($params)
            ->joinSub((clone $gained)->select(['fp.customer_id', 'fp.first_at']), 'fp', function ($join) {
                $join->on('fp.customer_id', '=', 'o.customer_id')->on('fp.first_at', '=', 'o.created_at');
            })
            ->join('fct_order_items as fi', 'fi.order_id', '=', 'o.id')
            ->where('o.type', '<>', Status::ORDER_TYPE_RENEWAL)
            ->where('fi.post_id', '>', 0)
            ->selectRaw('fi.post_id AS product_id, o.customer_id, MAX(fi.post_title) AS product_title')
            ->groupBy('fi.post_id', 'o.customer_id')
            ->get();

        $products = [];
        foreach ($pairs as $row) {
            $id = (int) $row->product_id;
            [$net, $purchases] = $stats[(int) $row->customer_id] ?? [0, 0];
            if (!isset($products[$id])) {
                $products[$id] = ['product_id' => $id, 'product_title' => (string) $row->product_title, 'customers' => 0, 'value' => 0, 'repeaters' => 0];
            }
            $products[$id]['customers']++;
            $products[$id]['value'] += $net;
            $products[$id]['repeaters'] += $purchases >= 2 ? 1 : 0;
        }

        $titles = $products ? App::db()->table('posts')->whereIn('ID', array_keys($products))->where('post_type', FluentProducts::CPT_NAME)
            ->pluck('post_title', 'ID')->toArray() : [];
        $result = [];
        foreach ($products as $id => $product) {
            $result[] = [
                'product_id'    => $id,
                'product_title' => (string) ($titles[$id] ?? $product['product_title']),
                'customers'     => $product['customers'],
                'average_value' => (int) round($product['value'] / $product['customers']),
                'repeat_rate'   => round($product['repeaters'] / $product['customers'] * 100, 1),
            ];
        }
        usort($result, function ($a, $b) {
            return $b['customers'] <=> $a['customers'] ?: $a['product_id'] <=> $b['product_id'];
        });

        return $result;
    }

    /**
     * The share of revenue from the top 1, 5, 10, 20 and 50 percent of customers (at least one each), in the range
     * or over all time
     */
    private function concentration(array $params, bool $inRange): array
    {
        // Summed in SQL: a large store has too many customers to hold in PHP
        $perCustomer = function () use ($params, $inRange) {
            return $this->customerOrders($params)
                ->when($inRange, fn($q) => $q->whereBetween('o.created_at', [$params['startDate'], $params['endDate']]))
                ->selectRaw('o.customer_id, SUM(' . $this->netSql($params) . ') AS net')
                ->groupBy('o.customer_id')
                // A customer refunded in full kept nothing: no customer in the shares
                ->havingRaw('net > 0');
        };

        $totals = App::db()->query()->fromSub($perCustomer(), 'pc')->selectRaw('COUNT(*) AS customers, SUM(pc.net) AS net')->first();
        $count = $totals ? (int) $totals->customers : 0;
        $total = $totals ? (int) $totals->net : 0;

        $tiers = [];
        foreach (self::CONCENTRATION_TIERS as $top) {
            $customers = $count ? max(1, (int) ceil($count * $top / 100)) : 0;
            $share = 0;
            if ($customers && $total > 0) {
                $topNet = (int) App::db()->query()
                    ->fromSub($perCustomer()->orderByRaw('net DESC')->orderBy('o.customer_id')->limit($customers), 't')
                    ->sum('t.net');
                // Two reads: an order landing between them must not push a share past the whole
                $share = min(100, $topNet / $total * 100);
            }
            $tiers[] = ['top' => $top, 'customers' => $customers, 'share' => round($share, 1)];
        }

        return $tiers;
    }
}
