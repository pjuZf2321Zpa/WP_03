<?php
/**
 * Sideloads Facebook event covers as featured images. Change detection
 * hashes the URL path only (FB CDN query strings rotate).
 *
 * @package CustomFacebookFeed\Events_Integration
 * @since 4.11
 */

namespace CustomFacebookFeed\Events_Integration\Sync;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class ImageSideloader {

	/**
	 * Import the cover as the post thumbnail unless unchanged. Failures are
	 * non-fatal: the event still syncs without an image.
	 *
	 * @param int    $post_id   Calendar post ID.
	 * @param string $cover_url Facebook cover image URL (may be empty).
	 * @return bool Whether a new image was imported.
	 */
	public function maybe_sideload( $post_id, $cover_url ) {
		if ( empty( $cover_url ) ) {
			return false;
		}

		$hash = $this->hash( $cover_url );
		if ( get_post_meta( $post_id, SyncState::META_COVER_HASH, true ) === $hash && has_post_thumbnail( $post_id ) ) {
			return false;
		}

		if ( ! function_exists( 'media_sideload_image' ) ) {
			require_once ABSPATH . 'wp-admin/includes/media.php';
			require_once ABSPATH . 'wp-admin/includes/file.php';
			require_once ABSPATH . 'wp-admin/includes/image.php';
		}

		$attachment_id = media_sideload_image( $cover_url, $post_id, null, 'id' );
		if ( is_wp_error( $attachment_id ) ) {
			return false;
		}

		// Remove the previously imported cover so replacements don't pile up.
		$previous_id = (int) get_post_thumbnail_id( $post_id );
		if ( $previous_id && $previous_id !== (int) $attachment_id && (int) get_post_field( 'post_parent', $previous_id ) === (int) $post_id ) {
			wp_delete_attachment( $previous_id, true );
		}

		set_post_thumbnail( $post_id, $attachment_id );
		update_post_meta( $post_id, SyncState::META_COVER_HASH, $hash );

		return true;
	}

	/**
	 * Hash the stable part of a Facebook CDN URL (host + path, no query).
	 *
	 * @param string $url Cover URL.
	 * @return string
	 */
	private function hash( $url ) {
		$parts = wp_parse_url( $url );
		$base  = ( isset( $parts['host'] ) ? $parts['host'] : '' ) . ( isset( $parts['path'] ) ? $parts['path'] : $url );

		return md5( $base );
	}
}
