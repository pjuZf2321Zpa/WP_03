<?php

namespace FluentCartPro\App\Modules\AdvancedInventory\Models;

use FluentCart\App\Models\Model;
use FluentCart\App\Models\Product;
use FluentCart\App\Models\ProductVariation;

/**
 * StockAdjustment Model - DB Model for Stock Adjustments table
 *
 * Database Model
 *
 * @package FluentCartPro\App\Modules\AdvancedInventory\Models
 *
 * @version 1.0.0
 */
class StockAdjustment extends Model
{
    protected $table = 'fct_stock_adjustments';

    protected $primaryKey = 'id';

    protected $guarded = ['id'];

    protected $fillable = [
        'variant_id',
        'post_id',
        'old_stock',
        'new_stock',
        'reason',
        'custom_reason',
        'user_id',
        'created_at',
        'updated_at',
    ];

    public function variant()
    {
        return $this->belongsTo(ProductVariation::class, 'variant_id', 'id');
    }

    public function product()
    {
        return $this->belongsTo(Product::class, 'post_id', 'ID');
    }
}
