<?php

namespace WPAICG\Lib\VectorStores\GoogleFileSearch;

use WPAICG\Dashboard\Ajax\BaseDashboardAjaxHandler;
use WPAICG\Includes\AIPKit_Upload_Utils;
use WPAICG\Vector\AIPKit_Vector_Store_Registry;
use WPAICG\Vector\GoogleFileSearch\GoogleFileSearchIngestionService;
use WP_Error;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Pro-only direct document ingestion for Google File Search.
 */
final class AIPKit_Google_File_Search_Upload_Ajax_Handler extends BaseDashboardAjaxHandler
{
    private const NONCE_ACTION = 'aipkit_google_file_search_nonce';

    /** @var array<string, string> */
    private const ALLOWED_EXTENSIONS = [
        'pdf' => 'application/pdf',
        'docx' => 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        'txt' => 'text/plain',
        'md' => 'text/markdown',
        'csv' => 'text/csv',
        'json' => 'application/json',
    ];

    public function handle(): void
    {
        $permission = $this->check_any_module_access_permissions(['sources', 'chatbot'], self::NONCE_ACTION);
        if (is_wp_error($permission)) {
            $this->send_wp_error($permission);
            return;
        }
        if (!function_exists('aipkit_pro_plan_active') || !aipkit_pro_plan_active()) {
            $this->send_wp_error(new WP_Error('google_file_search_upload_requires_pro', __('Google File Search document upload is a Pro feature.', 'gpt3-ai-content-generator'), ['status' => 403]));
            return;
        }

        // phpcs:ignore WordPress.Security.NonceVerification.Missing -- The provider nonce is verified above.
        $post_data = is_array($_POST) ? wp_unslash($_POST) : [];
        // phpcs:ignore WordPress.Security.NonceVerification.Missing, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- The uploaded file is validated below.
        $files_data = is_array($_FILES) ? $_FILES : [];
        $store_name = isset($post_data['target_store_id']) ? sanitize_text_field((string) $post_data['target_store_id']) : '';
        $source_type = isset($post_data['source_type']) ? sanitize_key((string) $post_data['source_type']) : 'file_upload_global_form';
        if ($store_name === '' || !isset($files_data['aipkit_google_file_search_file'])) {
            $this->send_wp_error(new WP_Error('google_file_search_upload_missing', __('Select a store and a file to upload.', 'gpt3-ai-content-generator'), ['status' => 400]));
            return;
        }

        $file = $files_data['aipkit_google_file_search_file'];
        if (!is_array($file)) {
            $this->send_wp_error(new WP_Error('google_file_search_upload_invalid', __('The uploaded file is invalid.', 'gpt3-ai-content-generator'), ['status' => 400]));
            return;
        }
        $validation = $this->validate_file($file);
        if (is_wp_error($validation)) {
            $this->send_wp_error($validation);
            return;
        }

        $contents = $this->read_uploaded_file((string) $file['tmp_name']);
        if (is_wp_error($contents)) {
            $this->send_wp_error($contents);
            return;
        }
        if (strpos($contents, "\0") !== false && in_array($validation['extension'], ['txt', 'md', 'csv', 'json'], true)) {
            $this->send_wp_error(new WP_Error('google_file_search_text_file_invalid', __('The selected text file contains binary data.', 'gpt3-ai-content-generator'), ['status' => 400]));
            return;
        }

        $service = new GoogleFileSearchIngestionService();
        $safe_name = sanitize_file_name((string) $file['name']);
        $result = $service->start(
            $store_name,
            $this->resolve_store_display_name($store_name),
            $contents,
            $safe_name,
            $validation['mime_type'],
            [
                'source_type' => $source_type,
                'post_title' => $safe_name,
                'indexed_content' => sprintf(
                    /* translators: %1$s: MIME type. %2$s: file name. */
                    __('Document content (%1$s) is stored in Google File Search. Filename: %2$s', 'gpt3-ai-content-generator'),
                    $validation['mime_type'],
                    $safe_name
                ),
                'message' => sprintf(
                    /* translators: %s: file name. */
                    __('File content submitted for indexing. Original Filename: %s', 'gpt3-ai-content-generator'),
                    $safe_name
                ),
            ],
            ['custom_metadata' => ['source' => $source_type, 'file_name' => $safe_name]]
        );
        unset($contents);
        if (is_wp_error($result)) {
            $this->send_wp_error($result);
            return;
        }

        wp_send_json_success(array_merge($result, [
            'message' => __('File submitted to Google File Search.', 'gpt3-ai-content-generator'),
        ]));
    }

    /**
     * @param array<string, mixed> $file
     * @return array{extension:string,mime_type:string}|WP_Error
     */
    private function validate_file(array $file)
    {
        if ((int) ($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
            return new WP_Error('google_file_search_upload_error', __('The file upload did not complete.', 'gpt3-ai-content-generator'), ['status' => 400]);
        }
        $tmp_name = isset($file['tmp_name']) ? (string) $file['tmp_name'] : '';
        if ($tmp_name === '' || !is_readable($tmp_name) || !is_uploaded_file($tmp_name)) {
            return new WP_Error('google_file_search_upload_source_invalid', __('The uploaded file source is invalid.', 'gpt3-ai-content-generator'), ['status' => 400]);
        }
        $extension = strtolower(pathinfo((string) ($file['name'] ?? ''), PATHINFO_EXTENSION));
        if (!isset(self::ALLOWED_EXTENSIONS[$extension])) {
            return new WP_Error('google_file_search_upload_type_invalid', __('Google File Search accepts PDF, DOCX, TXT, MD, CSV, or JSON files here.', 'gpt3-ai-content-generator'), ['status' => 400]);
        }

        $size = (int) ($file['size'] ?? 0);
        $max_size = min(
            $this->server_upload_limit(),
            \WPAICG\Core\Providers\Google\FileSearch\GoogleFileSearchClient::MAX_DOCUMENT_BYTES,
            $this->safe_memory_upload_limit()
        );
        if ($size < 1 || $size > $max_size) {
            return new WP_Error(
                'google_file_search_upload_size_invalid',
                sprintf(
                    /* translators: %s: effective upload limit. */
                    __('The file is empty or exceeds this server\'s %s upload limit.', 'gpt3-ai-content-generator'),
                    size_format($max_size)
                ),
                ['status' => 400]
            );
        }

        $detected_mime = function_exists('mime_content_type') ? (string) mime_content_type($tmp_name) : '';
        if (!$this->mime_matches_extension($extension, strtolower($detected_mime), $tmp_name, (string) $file['name'])) {
            return new WP_Error('google_file_search_upload_content_mismatch', __('The file content does not match its extension.', 'gpt3-ai-content-generator'), ['status' => 400]);
        }

        return [
            'extension' => $extension,
            'mime_type' => self::ALLOWED_EXTENSIONS[$extension],
        ];
    }

    private function mime_matches_extension(
        string $extension,
        string $detected_mime,
        string $tmp_name,
        string $original_name
    ): bool
    {
        $allowed_detected = [
            'pdf' => ['application/pdf', 'application/x-pdf'],
            'docx' => ['application/zip', 'application/octet-stream', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'],
            'txt' => ['text/plain'],
            'md' => ['text/plain', 'text/markdown'],
            'csv' => ['text/plain', 'text/csv', 'application/csv', 'application/vnd.ms-excel'],
            'json' => ['text/plain', 'application/json', 'text/json'],
        ];
        if ($detected_mime !== '' && in_array($detected_mime, $allowed_detected[$extension], true)) {
            return true;
        }

        if (function_exists('wp_check_filetype_and_ext')) {
            $wordpress_type = wp_check_filetype_and_ext($tmp_name, $original_name);
            $wordpress_mime = strtolower((string) ($wordpress_type['type'] ?? ''));
            $wordpress_extension = strtolower((string) ($wordpress_type['ext'] ?? ''));
            return $wordpress_extension === $extension
                && in_array($wordpress_mime, $allowed_detected[$extension], true);
        }

        return false;
    }

    /**
     * @return string|WP_Error
     */
    private function read_uploaded_file(string $tmp_name)
    {
        if (!class_exists('WP_Filesystem_Direct')) {
            require_once ABSPATH . 'wp-admin/includes/class-wp-filesystem-base.php';
            require_once ABSPATH . 'wp-admin/includes/class-wp-filesystem-direct.php';
        }
        $filesystem = new \WP_Filesystem_Direct(null);
        if (is_wp_error($filesystem->errors) && $filesystem->errors->has_errors()) {
            return new WP_Error('google_file_search_filesystem_unavailable', __('WordPress could not read the uploaded file.', 'gpt3-ai-content-generator'), ['status' => 500]);
        }
        $contents = $filesystem->get_contents($tmp_name);
        if (!is_string($contents) || $contents === '') {
            return new WP_Error('google_file_search_file_read_failed', __('WordPress could not read the uploaded file.', 'gpt3-ai-content-generator'), ['status' => 500]);
        }
        return $contents;
    }

    private function server_upload_limit(): int
    {
        if (class_exists(AIPKit_Upload_Utils::class)) {
            $limits = AIPKit_Upload_Utils::get_effective_upload_limit_summary();
            return max(1, (int) ($limits['limit_bytes'] ?? wp_max_upload_size()));
        }
        return max(1, (int) wp_max_upload_size());
    }

    private function safe_memory_upload_limit(): int
    {
        $memory_limit = wp_convert_hr_to_bytes((string) ini_get('memory_limit'));
        if ($memory_limit <= 0) {
            return \WPAICG\Core\Providers\Google\FileSearch\GoogleFileSearchClient::MAX_DOCUMENT_BYTES;
        }
        $available = $memory_limit - memory_get_usage(true) - (16 * MB_IN_BYTES);
        return max(1, (int) floor($available / 3));
    }

    private function resolve_store_display_name(string $store_name): string
    {
        foreach (AIPKit_Vector_Store_Registry::get_registered_stores_by_provider('Google') as $store) {
            if (is_array($store) && (string) ($store['id'] ?? '') === $store_name) {
                return (string) ($store['name'] ?? $store_name);
            }
        }
        return $store_name;
    }
}
