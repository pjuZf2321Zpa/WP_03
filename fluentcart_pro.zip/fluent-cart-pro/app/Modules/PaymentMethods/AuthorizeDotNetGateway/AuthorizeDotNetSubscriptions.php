<?php

namespace FluentCartPro\App\Modules\PaymentMethods\AuthorizeDotNetGateway;

use FluentCart\App\Helpers\Status;
use FluentCart\App\Helpers\StatusHelper;
use FluentCart\App\Models\Cart;
use FluentCart\App\Models\Order;
use FluentCart\App\Models\OrderTransaction;
use FluentCart\App\Models\Subscription;
use FluentCart\App\Models\SubscriptionMeta;
use FluentCart\App\Modules\PaymentMethods\Core\AbstractSubscriptionModule;
use FluentCart\App\Modules\Subscriptions\Services\SubscriptionService;
use FluentCart\App\Events\Subscription\SubscriptionActivated;
use FluentCart\App\Events\Subscription\SubscriptionReactivated;
use FluentCart\App\Events\Subscription\SubscriptionRenewalFailed;
use FluentCart\App\Services\Payments\PaymentHelper;
use FluentCart\App\Services\DateTime\DateTime;
use FluentCart\Framework\Support\Arr;
use FluentCartPro\App\Modules\PaymentMethods\AuthorizeDotNetGateway\API\AuthorizeDotNetAPI;
use FluentCartPro\App\Modules\PaymentMethods\AuthorizeDotNetGateway\AuthorizeDotNetHelper;
use FluentCartPro\App\Modules\PaymentMethods\AuthorizeDotNetGateway\AuthorizeDotNetSettings;

class AuthorizeDotNetSubscriptions extends AbstractSubscriptionModule
{
    // Meta keys keep the original "ARB retry" naming so rows written by older versions
    // still match; the deferSubscriptionCreation() / retry*() methods below own them.
    const ARB_RETRY_META_KEY = 'authorize_arb_retry';
    const ARB_RETRY_MARKED_AT_META_KEY = 'authorize_arb_retry_marked_at';

    const ARB_RETRY_MAX_ATTEMPTS = 12;

    const ARB_RETRY_MIN_DELAY_SECONDS = 90;
    const ARB_PENDING_DATA_META_KEY = 'authorize_arb_pending_data';

    protected AuthorizeDotNetAPI $api;
    protected AuthorizeDotNetSettings $settings;

    public function __construct(AuthorizeDotNetSettings $settings)
    {
        $this->settings = $settings;
        $this->api = new AuthorizeDotNetAPI();
    }

    public function cancel($vendorSubscriptionId, $args = [])
    {
        $subscriptionModel = Subscription::query()->find((int) Arr::get($args, 'subscription_id'));

        $mode = Arr::get($args, 'mode') ?: $this->resolveCancelMode($vendorSubscriptionId, $args);
        if (is_wp_error($mode)) {
            return $mode;
        }

        $data = [
            'merchantAuthentication' => $this->api->getMerchantAuthentication($mode),
            'subscriptionId'         => $vendorSubscriptionId,
        ];

        // check if subscription is already canceled
        $response = $this->api->getAuthorizeNetObject('ARBGetSubscriptionRequest', $data, $mode);
        if (is_wp_error($response)) {
            $this->logCancel($subscriptionModel, sprintf(
                /* translators: 1: ARB subscription id, 2: error message */
                __('Could not read ARB subscription %1$s before cancelling: %2$s', 'fluent-cart-pro'),
                $vendorSubscriptionId,
                $response->get_error_message()
            ), 'error');
            return $response;
        }

        $status = Arr::get($response, 'subscription.status');
        $subscriptionStatus = AuthorizeDotNetHelper::translateToFluentCartStatus($status);

        if ($subscriptionStatus === Status::SUBSCRIPTION_CANCELED) {
            $this->logCancel($subscriptionModel, sprintf(
                /* translators: 1: ARB subscription id, 2: gateway status */
                __('ARB subscription %1$s is already %2$s at Authorize.Net, no cancel request sent.', 'fluent-cart-pro'),
                $vendorSubscriptionId,
                $status
            ));
            return [
                'status' => Status::SUBSCRIPTION_CANCELED,
            ];
        }

        $response = $this->api->createAuthorizeNetObject('ARBCancelSubscriptionRequest', $data, $mode);

        if (is_wp_error($response)) {
            $this->logCancel($subscriptionModel, sprintf(
                /* translators: 1: ARB subscription id, 2: error message */
                __('ARBCancelSubscriptionRequest for %1$s failed: %2$s', 'fluent-cart-pro'),
                $vendorSubscriptionId,
                $response->get_error_message()
            ), 'error');
            return $response;
        }

        if (!AuthorizeDotNetAPI::isSuccessResponse($response)) {
            $message = AuthorizeDotNetAPI::extractErrorMessage($response, __('Failed to cancel subscription.', 'fluent-cart-pro'));
            $this->logCancel($subscriptionModel, sprintf(
                /* translators: 1: ARB subscription id, 2: error message */
                __('ARBCancelSubscriptionRequest for %1$s failed: %2$s', 'fluent-cart-pro'),
                $vendorSubscriptionId,
                $message
            ), 'error');
            return new \WP_Error('cancel_failed', $message);
        }

        $this->logCancel($subscriptionModel, sprintf(
            /* translators: %s: ARB subscription id */
            __('ARB subscription %s cancelled at Authorize.Net.', 'fluent-cart-pro'),
            $vendorSubscriptionId
        ));

        return [
            'status' => Status::SUBSCRIPTION_CANCELED,
            'canceled_at' => DateTime::now()->format('Y-m-d H:i:s')
        ];
    }

    protected function logCancel(?Subscription $subscriptionModel, string $message, string $type = 'info'): void
    {
        if ($subscriptionModel) {
            $subscriptionModel->addLog(__('Authorize.Net Subscription', 'fluent-cart-pro'), $message, $type);
        }
    }

    public function reSyncSubscriptionFromRemote(Subscription $subscriptionModel)
    {
        if ($subscriptionModel->current_payment_method !== 'authorize_dot_net') {
            return new \WP_Error(
                'invalid_payment_method',
                __('This subscription is not using Authorize.Net as payment method.', 'fluent-cart-pro')
            );
        }

        $order = $subscriptionModel->order;
        $vendorSubscriptionId = $subscriptionModel->vendor_subscription_id;

        if (!$vendorSubscriptionId) {
            return new \WP_Error(
                'invalid_subscription',
                __('Invalid vendor subscription ID.', 'fluent-cart-pro')
            );
        }

        $mode = $this->modeOf($subscriptionModel);

        // Get subscription details with transactions
        $data = [
            'merchantAuthentication' => $this->api->getMerchantAuthentication($mode),
            'subscriptionId'         => $vendorSubscriptionId,
            'includeTransactions'    => true,
        ];

        $response = $this->api->getAuthorizeNetObject('ARBGetSubscriptionRequest', $data, $mode);

        if (is_wp_error($response)) {
            return $response;
        }

        if (!AuthorizeDotNetAPI::isSuccessResponse($response)) {
            return new \WP_Error(
                'sync_failed',
                AuthorizeDotNetAPI::extractErrorMessage($response, __('Failed to sync subscription.', 'fluent-cart-pro'))
            );
        }

        $subscriptionData = Arr::get($response, 'subscription', []);
        $subscriptionUpdateData = $this->getSubscriptionUpdateData($subscriptionData, $subscriptionModel);

        // Get transactions from subscription
        $arbTransactions = Arr::get($subscriptionData, 'arbTransactions', []);

        $newPayment = false;

        // Process each transaction
        foreach ($arbTransactions as $arbTransaction) {
            $transactionId = Arr::get($arbTransaction, 'transId');
            $paymentNumber = Arr::get($arbTransaction, 'payNum');
            // ARB transaction list returns text description in 'response', not a numeric code
            $responseText = (string) Arr::get($arbTransaction, 'response', '');

            if (!$transactionId) {
                continue;
            }

            // Scoped to this subscription: transIds are unique per environment only,
            // so a test and a live subscription can carry the same id.
            $transaction = OrderTransaction::query()
                ->where('subscription_id', $subscriptionModel->id)
                ->where('vendor_charge_id', $transactionId)
                ->first();

            $transactionStatus = $this->getTransactionStatusFromResponseText($responseText);

            // submitTimeUTC is when Authorize.net accepted the charge; that is
            // the settlement moment, not this resync's run time. Only a
            // succeeded charge has settled.
            $submitTime = Arr::get($arbTransaction, 'submitTimeUTC');
            $settledAt = ($submitTime && $transactionStatus === Status::TRANSACTION_SUCCEEDED)
                ? DateTime::anyTimeToGmt($submitTime)->format('Y-m-d H:i:s')
                : null;

            if (!$transaction) {
                $transaction = OrderTransaction::query()
                    ->where('subscription_id', $subscriptionModel->id)
                    ->where('vendor_charge_id', '')
                    ->where('transaction_type', Status::TRANSACTION_TYPE_CHARGE)
                    ->first();

                if ($transaction) {
                    $amount = $this->getChargedAmountInCents($transactionId, $order->currency, $mode);
                    if ($amount === null) {
                        continue;
                    }

                    $meta = array_merge($transaction->meta ?? [], [
                        'authnet_transaction' => $arbTransaction,
                        'payment_number'      => $paymentNumber,
                    ]);
                    if ($settledAt && empty($meta['settled_at'])) {
                        $meta['settled_at'] = $settledAt;
                    }

                    $transaction->update([
                        'vendor_charge_id' => $transactionId,
                        'status'           => $transactionStatus,
                        'total'            => $amount,
                        'meta'              => $meta,
                    ]);

                    (new StatusHelper($transaction->order))->syncOrderStatuses($transaction);

                    if ($transactionStatus !== Status::TRANSACTION_SUCCEEDED) {
                        $this->handleUnpaidArbTransaction($subscriptionModel, $transaction->order ?: $order, $arbTransaction, $transactionStatus);
                    }
                    continue;
                }

                // recordRenewalPayment() is the successful-renewal workflow: it pays an open
                // renewal invoice and dispatches SubscriptionRenewed whatever status it is
                // handed. A declined or held attempt has nothing to renew.
                if ($transactionStatus !== Status::TRANSACTION_SUCCEEDED) {
                    $this->handleUnpaidArbTransaction($subscriptionModel, $order, $arbTransaction, $transactionStatus);
                    continue;
                }

                $amount = $this->getChargedAmountInCents($transactionId, $order->currency, $mode);
                if ($amount === null) {
                    continue;
                }

                $transactionData = [
                    'order_id'         => $order->id,
                    'subscription_id'  => $subscriptionModel->id,
                    'vendor_charge_id' => $transactionId,
                    'status'           => $transactionStatus,
                    'total'            => $amount,
                    'currency'         => $order->currency,
                    'payment_method'   => 'authorize_dot_net',
                    'transaction_type' => Status::TRANSACTION_TYPE_CHARGE,
                    'created_at'       => Arr::get($arbTransaction, 'submitTimeUTC')
                        ? DateTime::anyTimeToGmt(Arr::get($arbTransaction, 'submitTimeUTC'))->format('Y-m-d H:i:s')
                        : DateTime::now()->format('Y-m-d H:i:s'),
                    'meta'             => array_merge([
                        'authnet_transaction' => $arbTransaction,
                        'payment_number'      => $paymentNumber,
                    ], $settledAt ? ['settled_at' => $settledAt] : []),
                ];

                $newPayment = true;
                SubscriptionService::recordRenewalPayment($transactionData, $subscriptionModel, $subscriptionUpdateData);
            } elseif ($transaction->status !== Status::TRANSACTION_SUCCEEDED) {
                if ($settledAt && empty($transaction->meta['settled_at'])) {
                    $transaction->meta = array_merge($transaction->meta ?? [], [
                        'settled_at' => $settledAt
                    ]);
                }

                // Update existing transaction if status has changed
                $transaction->update([
                    'status' => $transactionStatus,
                ]);

                (new StatusHelper($transaction->order))->syncOrderStatuses($transaction);
            }
        }

        // Update subscription data
        if (!$newPayment) {
            $subscriptionModel = SubscriptionService::syncSubscriptionStates($subscriptionModel, $subscriptionUpdateData);
        } else {
            $subscriptionModel = Subscription::query()->find($subscriptionModel->id);
        }

        return $subscriptionModel;
    }

    /**
     * An ARB charge the merchant has approved after a fraud hold, not yet known
     * locally by its transaction id. The ARB list only says what the charge answered
     * when it was submitted, so the fraud-approved webhook records it from the
     * transaction record instead of a resync.
     *
     * A local charge transaction with no vendor id yet (the trial checkout
     * transaction, or a reactivation's renewal order) is that charge's own row, the
     * same match resync makes, so the approval settles it in place instead of opening
     * a renewal order.
     *
     * @param array $transactionDetails getTransactionDetailsRequest `transaction` node
     * @return OrderTransaction|\WP_Error|null null when the charge is not approved
     */
    public function recordApprovedRenewalTransaction(Subscription $subscriptionModel, array $transactionDetails)
    {
        $order = $subscriptionModel->order;
        $transactionId = (string) Arr::get($transactionDetails, 'transId', '');
        $remoteStatus = (string) Arr::get($transactionDetails, 'transactionStatus', '');

        if (!$order || !$transactionId) {
            return null;
        }

        if (!in_array($remoteStatus, ['approvedReview', 'capturedPendingSettlement', 'pendingSettlement', 'pendingFinalSettlement', 'updatingSettlement', 'settledSuccessfully'], true)) {
            return null;
        }

        $submitTime = Arr::get($transactionDetails, 'submitTimeUTC');
        $settledAt = $submitTime ? DateTime::anyTimeToGmt($submitTime)->format('Y-m-d H:i:s') : null;
        $amount = Arr::get($transactionDetails, 'settleAmount') ?: Arr::get($transactionDetails, 'authAmount', 0);
        $total = $this->convertAmountToCents($amount, $order->currency);

        $placeholder = OrderTransaction::query()
            ->where('subscription_id', $subscriptionModel->id)
            ->where('vendor_charge_id', '')
            ->where('transaction_type', Status::TRANSACTION_TYPE_CHARGE)
            ->first();

        if ($placeholder) {
            $meta = array_merge($placeholder->meta ?? [], [
                'authnet_transaction' => $transactionDetails,
                'payment_number'      => Arr::get($transactionDetails, 'subscription.payNum'),
            ]);
            if ($settledAt && empty($meta['settled_at'])) {
                $meta['settled_at'] = $settledAt;
            }

            $placeholder->update([
                'vendor_charge_id' => $transactionId,
                'status'           => Status::TRANSACTION_SUCCEEDED,
                'total'            => $total,
                'meta'             => $meta,
            ]);

            (new StatusHelper($placeholder->order))->syncOrderStatuses($placeholder);

            return $placeholder;
        }

        return SubscriptionService::recordRenewalPayment([
            'order_id'         => $order->id,
            'subscription_id'  => $subscriptionModel->id,
            'vendor_charge_id' => $transactionId,
            'status'           => Status::TRANSACTION_SUCCEEDED,
            'total'            => $total,
            'currency'         => $order->currency,
            'payment_method'   => 'authorize_dot_net',
            'transaction_type' => Status::TRANSACTION_TYPE_CHARGE,
            'created_at'       => $settledAt ?: DateTime::now()->format('Y-m-d H:i:s'),
            'meta'             => array_merge([
                'authnet_transaction' => $transactionDetails,
                'payment_number'      => Arr::get($transactionDetails, 'subscription.payNum'),
            ], $settledAt ? ['settled_at' => $settledAt] : []),
        ], $subscriptionModel, []);
    }

    /**
     * A remote renewal attempt that did not collect payment. Held attempts are only
     * logged; the fraud-approved webhook settles them if the review approves them,
     * either on the local placeholder it was matched to or, when there is none, by
     * recording the renewal from the transaction record. Declined attempts also
     * raise SubscriptionRenewalFailed, once per Authorize.Net transaction, since ARB
     * does not retry a declined charge.
     *
     * @param Order|null $order the order the attempt belongs to
     */
    protected function handleUnpaidArbTransaction(Subscription $subscriptionModel, $order, array $arbTransaction, string $transactionStatus): void
    {
        $transactionId = (string) Arr::get($arbTransaction, 'transId');
        $paymentNumber = Arr::get($arbTransaction, 'payNum');
        $responseText = (string) Arr::get($arbTransaction, 'response', '');

        if ($transactionStatus === Status::TRANSACTION_PENDING) {
            $subscriptionModel->addLog(
                __('Authorize.Net Renewal Held', 'fluent-cart-pro'),
                sprintf(__('Renewal payment #%1$s is held for review. Transaction ID: %2$s', 'fluent-cart-pro'), $paymentNumber, $transactionId)
            );
            return;
        }

        $subscriptionModel->addLog(
            __('Authorize.Net Renewal Failed', 'fluent-cart-pro'),
            sprintf(__('Renewal payment #%1$s was not approved (%2$s). Transaction ID: %3$s', 'fluent-cart-pro'), $paymentNumber, $responseText, $transactionId),
            'error'
        );

        if (!$order || !preg_match('/^[a-zA-Z0-9_-]+$/', $transactionId)) {
            return;
        }

        // Every resync caller walks the same ARB list, so the same declined attempt
        // comes back on each webhook and admin resync. The stored value must stay
        // constant: add_option()'s pre-check is not atomic, so the claim leans on
        // MySQL reporting zero affected rows for an unchanged ON DUPLICATE KEY UPDATE.
        $claimKey = 'fct_sub_renewal_failed_' . $subscriptionModel->id . '_' . $transactionId;
        if (!add_option($claimKey, '1', '', false)) {
            return;
        }

        $error = $responseText ?: __('Authorize.Net reported a failed renewal payment attempt.', 'fluent-cart-pro');

        try {
            (new SubscriptionRenewalFailed($subscriptionModel, $order, $order->customer, $error))->dispatch();
        } catch (\Throwable $e) {
            // The claim is permanent, so a half-finished dispatch would suppress this
            // renewal forever. Release it so the next resync reruns the dispatch.
            delete_option($claimKey);
            throw $e;
        }
    }

    protected function getSubscriptionUpdateData($subscriptionData, $subscriptionModel)
    {
        $status = Arr::get($subscriptionData, 'status');
        $fctStatus = AuthorizeDotNetHelper::translateToFluentCartStatus($status);

        $subscriptionUpdateData = array_filter([
            'current_payment_method' => 'authorize_dot_net',
            'status'                 => $fctStatus,
        ]);

        // Handle cancellation
        if ($fctStatus === Status::SUBSCRIPTION_CANCELED) {
            if (!$subscriptionModel->canceled_at) {
                $subscriptionUpdateData['canceled_at'] = DateTime::now()->format('Y-m-d H:i:s');
            }
        }

        $nextBillingDate = $this->deriveNextBillingDate($subscriptionData);

        if ($nextBillingDate) {
            $subscriptionUpdateData['next_billing_date'] = $nextBillingDate;
        }

        return $subscriptionUpdateData;
    }

    /**
     * ARB publishes no next-payment field. The next charge is one interval after the
     * latest approved ARB payment, anchored on that payment's submitTimeUTC; before any
     * ARB payment it is the schedule's startDate (the checkout charge is taken outside
     * ARB). A declined cycle is never retried and stays due, so it does not move the date.
     *
     * @param array $subscriptionData ARBGetSubscriptionRequest `subscription` node
     * @return string|null GMT datetime, null when the schedule is incomplete or exhausted
     */
    protected function deriveNextBillingDate(array $subscriptionData): ?string
    {
        $startDate = Arr::get($subscriptionData, 'paymentSchedule.startDate');
        $length    = (int) Arr::get($subscriptionData, 'paymentSchedule.interval.length');
        $unit      = Arr::get($subscriptionData, 'paymentSchedule.interval.unit');

        if (!$startDate || $length < 1 || !in_array($unit, ['days', 'months'], true)) {
            return null;
        }

        $paidCycles     = 0;
        $latestPaidTime = null;
        foreach (Arr::get($subscriptionData, 'arbTransactions', []) as $arbTransaction) {
            $responseText = (string) Arr::get($arbTransaction, 'response', '');
            if ($this->getTransactionStatusFromResponseText($responseText) !== Status::TRANSACTION_SUCCEEDED) {
                continue;
            }
            $payNum = (int) Arr::get($arbTransaction, 'payNum');
            if ($payNum > $paidCycles) {
                $paidCycles     = $payNum;
                $latestPaidTime = Arr::get($arbTransaction, 'submitTimeUTC');
            }
        }

        $totalOccurrences = (int) Arr::get($subscriptionData, 'paymentSchedule.totalOccurrences');
        if ($totalOccurrences > 0 && $paidCycles >= $totalOccurrences) {
            return null;
        }

        if (!$latestPaidTime) {
            return DateTime::anyTimeToGmt($startDate)->format('Y-m-d H:i:s');
        }

        $anchorTs = DateTime::anyTimeToGmt($latestPaidTime)->getTimestamp();

        if ($unit === 'days') {
            return gmdate('Y-m-d H:i:s', $anchorTs + $length * DAY_IN_SECONDS);
        }

        // ARB bills the last day of shorter months when the day falls on the 29th-31st.
        $year  = (int) gmdate('Y', $anchorTs);
        $month = (int) gmdate('n', $anchorTs) + $length;
        $day   = min((int) gmdate('j', $anchorTs), (int) gmdate('t', gmmktime(0, 0, 0, $month, 1, $year)));

        return gmdate('Y-m-d H:i:s', gmmktime(
            (int) gmdate('H', $anchorTs),
            (int) gmdate('i', $anchorTs),
            (int) gmdate('s', $anchorTs),
            $month,
            $day,
            $year
        ));
    }

    /**
     * Requests for an existing subscription go to the environment that created it,
     * not to whichever mode the store is switched to now.
     */
    protected function modeOf(?Subscription $subscriptionModel): string
    {
        $order = $subscriptionModel ? $subscriptionModel->order : null;

        return ($order && $order->mode) ? $order->mode : 'current';
    }

    /**
     * ARB subscription ids are unique within one environment only, so the vendor id
     * on its own cannot pick the mode when the store holds a test and a live
     * subscription with the same id. Prefer the local ids the caller passes; refuse
     * when the vendor id alone is ambiguous.
     *
     * @return string|\WP_Error
     */
    protected function resolveCancelMode($vendorSubscriptionId, array $args)
    {
        if ($subscriptionId = Arr::get($args, 'subscription_id')) {
            return $this->modeOf(Subscription::query()->find($subscriptionId));
        }

        if ($parentOrderId = Arr::get($args, 'parent_order_id')) {
            $order = Order::query()->find($parentOrderId);

            return ($order && $order->mode) ? $order->mode : 'current';
        }

        // Vendor ids are gateway-local: another gateway's subscription may carry the same id.
        $modes = [];
        $subscriptions = Subscription::query()
            ->where('vendor_subscription_id', $vendorSubscriptionId)
            ->where('current_payment_method', 'authorize_dot_net')
            ->get();
        foreach ($subscriptions as $subscriptionModel) {
            $modes[$this->modeOf($subscriptionModel)] = true;
        }

        if (count($modes) > 1) {
            return new \WP_Error(
                'ambiguous_subscription_mode',
                __('This Authorize.Net subscription id exists in both the test and live environments. Cancel it from the subscription itself.', 'fluent-cart-pro')
            );
        }

        return $modes ? array_key_first($modes) : 'current';
    }

    /**
     * The ARB transaction list carries no amount, and the schedule's current amount
     * is not what an earlier cycle was charged (price change, trial cycle). Null when
     * the transaction record cannot be read; the charge is left for the next resync
     * rather than recorded at a guessed amount.
     */
    protected function getChargedAmountInCents(string $transactionId, string $currency, string $mode): ?int
    {
        $details = $this->api->getTransactionDetails($transactionId, $mode);
        $amount = Arr::get($details, 'settleAmount') ?: Arr::get($details, 'authAmount');

        if ($amount === null || $amount === '') {
            fluent_cart_error_log('Authorize.Net Subscription', 'Could not read the charged amount of transaction ' . $transactionId . '; it will be recorded on the next sync.', [
                'transaction_id' => $transactionId,
            ]);
            return null;
        }

        return $this->convertAmountToCents($amount, $currency);
    }

    protected function convertAmountToCents($amount, $currency)
    {
        return (int) round(floatval($amount) * 100);
    }

    protected function getTransactionStatusFromResponseCode($responseCode)
    {
        // Response codes: 1 = Approved, 2 = Declined, 3 = Error, 4 = Held for Review
        $responseCode = (string) $responseCode;

        if ($responseCode === '1') {
            return Status::TRANSACTION_SUCCEEDED;
        } elseif ($responseCode === '4') {
            return Status::TRANSACTION_PENDING;
        } else {
            return Status::TRANSACTION_FAILED;
        }
    }

    // ARBGetSubscriptionRequest arbTransactions return text descriptions, not numeric codes
    protected function getTransactionStatusFromResponseText(string $responseText): string
    {
        if (stripos($responseText, 'approved') !== false) {
            return Status::TRANSACTION_SUCCEEDED;
        } elseif (stripos($responseText, 'held') !== false || stripos($responseText, 'review') !== false) {
            return Status::TRANSACTION_PENDING;
        } else {
            return Status::TRANSACTION_FAILED;
        }
    }

    public function reactivateSubscription($data, $subscriptionId)
    {
        $subscription = Subscription::query()->find($subscriptionId);
        
        if (!$subscription || $subscription->current_payment_method !== 'authorize_dot_net') {
            return new \WP_Error(
                'invalid_subscription',
                __('Invalid subscription or payment method.', 'fluent-cart-pro')
            );
        }

        $vendorSubscriptionId = $subscription->vendor_subscription_id;
        
        if (!$vendorSubscriptionId) {
            return new \WP_Error(
                'invalid_subscription',
                __('Invalid vendor subscription ID.', 'fluent-cart-pro')
            );
        }

        $mode = $this->modeOf($subscription);

        // Authorize.Net doesn't have a direct reactivate API
        // We need to update the subscription status
        $data = [
            'merchantAuthentication' => $this->api->getMerchantAuthentication($mode),
            'subscriptionId'         => $vendorSubscriptionId,
            'subscription'           => [
                'status' => 'active',
            ],
        ];

        $response = $this->api->createAuthorizeNetObject('ARBUpdateSubscriptionRequest', $data, $mode);

        if (is_wp_error($response)) {
            return $response;
        }

        if (!AuthorizeDotNetAPI::isSuccessResponse($response)) {
            return new \WP_Error(
                'reactivate_failed',
                AuthorizeDotNetAPI::extractErrorMessage($response, __('Failed to reactivate subscription.', 'fluent-cart-pro'))
            );
        }

        return true;
    }

    /**
     * Formerly createAndActivateSubscriptionOnTransactionApprove().
     */
    public function activateSubscriptionAfterPayment($subscriptionModel, $transactionModel)
    {
        // The paid order decides the schedule: a reactivation's renewal order carries the
        // reactivation amount and remaining cycles, the subscription's own order does not.
        $order = $transactionModel->order ?: $subscriptionModel->order;
        $mode = $order->mode ?: 'current';

        // Checkout already built this payload once (interval/trial/startDate/profile
        // resolved) before hitting E00040 — reuse it instead of recomputing from scratch.
        $cachedPayload = $subscriptionModel->getMeta(self::ARB_PENDING_DATA_META_KEY);

        if ($cachedPayload) {
            $profile = Arr::get($cachedPayload, 'profile', []);
            $subscriptionData = $cachedPayload;

            $refId = substr($subscriptionModel->uuid, 0, 20);

            $data = [
                'merchantAuthentication' => $this->api->getMerchantAuthentication($mode),
                'refId'                  => $refId,
                'subscription'           => $subscriptionData,
            ];

            $subscriptionModel->addLog(
                __('Authorize.Net Subscription', 'fluent-cart-pro'),
                __('Reusing subscription payload captured at checkout — interval, trial and start date are not recomputed.', 'fluent-cart-pro')
            );
        } else {
            $profile = null;

            // The payment profile that paid this transaction wins — the customer profile
            // may hold several cards and the first one is not necessarily the one entered.
            $paidWithProfileId        = (string) Arr::get($transactionModel->meta ?? [], 'authnet_customer_profile_id');
            $paidWithPaymentProfileId = (string) Arr::get($transactionModel->meta ?? [], 'authnet_payment_profile_id');
            if ($paidWithProfileId && $paidWithPaymentProfileId) {
                $profile = [
                    'customerProfileId'        => $paidWithProfileId,
                    'customerPaymentProfileId' => $paidWithPaymentProfileId,
                ];
                $subscriptionModel->addLog(
                    __('Authorize.Net Customer Profile', 'fluent-cart-pro'),
                    sprintf(
                        /* translators: 1: customer profile id, 2: payment profile id */
                        __('Using the payment profile recorded at checkout — profileId: %1$s, paymentProfileId: %2$s', 'fluent-cart-pro'),
                        $paidWithProfileId,
                        $paidWithPaymentProfileId
                    )
                );
            }

            // Checkout hit E00039 (existing profile) but could not attach the paid card.
            // Retry that exact attach; a stored card or a freshly minted profile would
            // bill something other than what the customer entered.
            if (!$profile && $paidWithProfileId) {
                $attached = $this->attachPaidCardToProfile((string) $transactionModel->vendor_charge_id, $paidWithProfileId, $mode);

                if (is_wp_error($attached)) {
                    $subscriptionModel->addLog(
                        __('Authorize.Net Customer Profile', 'fluent-cart-pro'),
                        sprintf(
                            /* translators: 1: vendor transaction id, 2: customer profile id, 3: error message */
                            __('Could not attach the paid card (transId: %1$s) to customer profile %2$s, will retry: %3$s', 'fluent-cart-pro'),
                            $transactionModel->vendor_charge_id,
                            $paidWithProfileId,
                            $attached->get_error_message()
                        ),
                        'error'
                    );
                    return false;
                }

                $profile = $attached;
                $this->pinProfileOnTransaction($transactionModel, $profile['customerProfileId'], $profile['customerPaymentProfileId']);

                $subscriptionModel->addLog(
                    __('Authorize.Net Customer Profile', 'fluent-cart-pro'),
                    sprintf(
                        /* translators: 1: vendor transaction id, 2: customer profile id, 3: payment profile id */
                        __('Attached the paid card (transId: %1$s) to existing customer profile — profileId: %2$s, paymentProfileId: %3$s', 'fluent-cart-pro'),
                        $transactionModel->vendor_charge_id,
                        $profile['customerProfileId'],
                        $profile['customerPaymentProfileId']
                    )
                );
            }

            if (!$profile) {
                $profile = $this->createProfileFromTransaction($subscriptionModel, $transactionModel, $order, $order->customer, $mode);
            }

            if (!$profile) {
                return false;
            }

            $interval = $subscriptionModel->billing_interval;
            $intervalMap = [
                'daily'   => 'days',
                'weekly'  => 'days',
                'monthly' => 'months',
                'yearly'  => 'months',
                'quarterly' => 'months',
                'half_yearly' => 'months',
            ];

            $intervalCount = 1;

            if ($interval === 'weekly') {
                $intervalCount = 7;
            } elseif ($interval === 'yearly') {
                $intervalCount = 12;
            } elseif ($interval === 'quarterly') {
                $intervalCount = 3;
            } elseif ($interval === 'half_yearly') {
                $intervalCount = 6;
            }

            $intervalInDays = PaymentHelper::getIntervalDays($interval);

            $intervalUnit = $intervalMap[$interval] ?? 'months';

            // first payment done, subscription start date(first billing date) will be from second billing date or after default trial days

            if ($order->type == 'renewal') {

                $amount = AuthorizeDotNetHelper::formatAmount($subscriptionModel->getCurrentRenewalAmount(), $transactionModel->currency);
                $trialDays = $subscriptionModel->getReactivationTrialDays();
                $totalOccurrences = self::reactivationOccurrences($subscriptionModel, $transactionModel);

                // This payment was the last installment: no new ARB, core marks it completed.
                // null while the payment is unconfirmed: the webhook that confirms it runs this again
                if (!$totalOccurrences) {
                    $paidTransaction = OrderTransaction::query()->find($transactionModel->id);
                    if (!$paidTransaction || $paidTransaction->status !== Status::TRANSACTION_SUCCEEDED) {
                        return null;
                    }

                    SubscriptionService::syncSubscriptionStates($subscriptionModel, []);
                    return true;
                }

                if (empty($trialDays)) {
                    $trialDays = $intervalInDays;
                }

                $startDate = DateTime::parse(DateTime::anyTimeToGmt($transactionModel->created_at))->addDays($trialDays);
                $startDateStr = $startDate->format('Y-m-d');

                $billingPeriod = apply_filters('fluent_cart/subscription_billing_period', [
                        'interval_frequency' => $intervalCount,
                        'interval_unit'   => $intervalUnit,
                    ],
                    [
                        'subscription_interval' => $subscriptionModel->billing_interval,
                        'payment_method' => 'authorize_dot_net',
                    ]
                );

                // check minimum 7 days
                if (Arr::get($billingPeriod, 'interval_frequency') < 7 && Arr::get($billingPeriod, 'interval_unit') === 'days') {
                    fluent_cart_error_log('Authorize.Net Subscription', 'Minimum 7 days is required for subscription. Please change the subscription interval to at weekly or greater', [
                        'module_name' => 'order',
                        'module_id'   => $order->id,
                        'error'       => 'Minimum 7 days is required for subscription. Please change the subscription interval to at weekly or greater',
                    ]);
                    return false;
                }

                $subscriptionData = [
                    'name' => mb_substr($subscriptionModel->item_name, 0, 50) ?: 'Subscription',
                    'paymentSchedule' => [
                        'interval' => [
                            'length' => (string) Arr::get($billingPeriod, 'interval_frequency'),
                            'unit'   => Arr::get($billingPeriod, 'interval_unit'),
                        ],
                        'startDate'        => $startDateStr,
                        'totalOccurrences' => (string) $totalOccurrences,
                    ],
                    'amount'  => $amount,
                    'profile' => $profile,
                ];

                $refId = substr($subscriptionModel->uuid, 0, 20);

                $data = [
                    'merchantAuthentication' => $this->api->getMerchantAuthentication($mode),
                    'refId'                  => $refId,
                    'subscription'           => $subscriptionData,
                ];

            } else {

                // Calculate total occurrences — simulated-trial first installment was
                // already collected outside the ARB cycles (same math as Processor)
                $totalOccurrences = 9999; // Unlimited by default

                $initialBillTimes = $subscriptionModel->getInitialRemoteBillTimes();
                if ($initialBillTimes) {
                    $totalOccurrences = $initialBillTimes;
                }

                // startDate = next billing date after the manual first payment
                $trialDays = $subscriptionModel->trial_days ?: $intervalInDays;

                $startDate = DateTime::parse(DateTime::anyTimeToGmt($transactionModel->created_at))->addDays($trialDays);
                $startDateStr = $startDate->format('Y-m-d');

                // Format recurring amount
                $amount = AuthorizeDotNetHelper::formatAmount($subscriptionModel->recurring_total, $transactionModel->currency);

                $billingPeriod = apply_filters('fluent_cart/subscription_billing_period', [
                        'interval_frequency' => $intervalCount,
                        'interval_unit'   => $intervalUnit,
                    ],
                    [
                        'subscription_interval' => $subscriptionModel->billing_interval,
                        'payment_method' => 'authorize_dot_net',
                    ]
                );

                // check minimum 7 days
                if (Arr::get($billingPeriod, 'interval_frequency') < 7 && Arr::get($billingPeriod, 'interval_unit') === 'days') {
                    fluent_cart_error_log('Authorize.Net Subscription', 'Minimum 7 days is required for subscription. Please change the subscription interval to at weekly or greater', [
                        'module_name' => 'order',
                        'module_id'   => $order->id,
                        'error'       => 'Minimum 7 days is required for subscription. Please change the subscription interval to at weekly or greater',
                    ]);
                    return false;
                }

                $subscriptionData = [
                    'name' => mb_substr($subscriptionModel->item_name, 0, 50) ?: 'Subscription',
                    'paymentSchedule' => [
                        'interval' => [
                            'length' => (string) Arr::get($billingPeriod, 'interval_frequency'),
                            'unit'   => Arr::get($billingPeriod, 'interval_unit'),
                        ],
                        'startDate'        => $startDateStr,
                        'totalOccurrences' => (string) $totalOccurrences,
                    ],
                    'amount'  => $amount,
                    'profile' => $profile,
                ];

                $refId = substr($subscriptionModel->uuid, 0, 20);

                $data = [
                    'merchantAuthentication' => $this->api->getMerchantAuthentication($mode),
                    'refId'                  => $refId,
                    'subscription'           => $subscriptionData,
                ];

            }
        }

        // startDate lives inside $data regardless of which branch built it (cached or fresh).
        $startDateStr = Arr::get($data, 'subscription.paymentSchedule.startDate');

        fluent_cart_add_log(
            'Authorize.Net Subscription',
            sprintf(
                'ARBCreateSubscriptionRequest — profileId: %s, paymentProfileId: %s, startDate: %s, amount: %s',
                Arr::get($data, 'subscription.profile.customerProfileId', 'NULL'),
                Arr::get($data, 'subscription.profile.customerPaymentProfileId', 'NULL'),
                Arr::get($data, 'subscription.paymentSchedule.startDate', 'NULL'),
                Arr::get($data, 'subscription.amount', 'NULL')
            ),
            'info',
            [
                'module_name' => 'subscription',
                'module_id'   => $subscriptionModel->id,
            ]
        );

        $response = $this->api->createAuthorizeNetObject('ARBCreateSubscriptionRequest', $data, $mode);

        if (is_wp_error($response) || !AuthorizeDotNetAPI::isSuccessResponse($response)) {
            $errorMessage = is_wp_error($response)
                ? $response->get_error_message()
                : AuthorizeDotNetAPI::extractErrorMessage($response, __('Unknown Authorize.Net error.', 'fluent-cart-pro'));

            fluent_cart_error_log('Authorize.Net Subscription', 'Failed to create subscription. Error: ' . $errorMessage, [
                'module_name' => 'order',
                'module_id'   => $order->id,
                'error'       => $errorMessage,
            ]);

            $subscriptionModel->addLog(
                __('Authorize.Net Subscription', 'fluent-cart-pro'),
                sprintf(
                    /* translators: 1: error message, 2: customer profile id, 3: payment profile id */
                    __('Subscription creation failed: %1$s (profileId: %2$s, paymentProfileId: %3$s)', 'fluent-cart-pro'),
                    $errorMessage,
                    Arr::get($profile, 'customerProfileId', 'NULL'),
                    Arr::get($profile, 'customerPaymentProfileId', 'NULL')
                ),
                'error'
            );
            return false;
        }

        $vendorSubscriptionId = Arr::get($response, 'subscriptionId');
        $vendorCustomerId = Arr::get($response, 'profile.customerProfileId');

        if (!$vendorSubscriptionId) {
            fluent_cart_error_log('Authorize.Net Subscription', 'No subscription ID returned by Authorize.Net.', [
                'module_name' => 'order',
                'module_id'   => $order->id,
                'error'       => 'authnet_missing_subscription_id',
            ]);

            $subscriptionModel->addLog(
                __('Authorize.Net Subscription', 'fluent-cart-pro'),
                __('Unable to process subscription. No subscription ID returned by Authorize.Net.', 'fluent-cart-pro'),
                'error'
            );
            return false;
        }
    
        $updateData = [
            'vendor_subscription_id' => $vendorSubscriptionId,
            'vendor_customer_id'    => $vendorCustomerId,
            'status'                => Status::SUBSCRIPTION_ACTIVE,
            'current_payment_method' => 'authorize_dot_net',
            'next_billing_date'      => DateTime::anyTimeToGmt($startDateStr)->format('Y-m-d H:i:s'),
            'vendor_response'        => json_encode($response),
        ];

        $subscriptionModel->update($updateData);
        SubscriptionService::syncSubscriptionStates($subscriptionModel, []);

        // update 'active_payment_method' meta
        $subscriptionModel->updateMeta('active_payment_method', [
            'type' => Arr::get($transactionModel, 'payment_method_type'),
            'last_four' => Arr::get($transactionModel, 'card_last_4'),
            'brand' => Arr::get($transactionModel, 'card_brand'),
            'customer_profile_id' => Arr::get($profile, 'customerProfileId'),
            'payment_profile_id' => Arr::get($profile, 'customerPaymentProfileId'),
            'details' => [
                'type' => Arr::get($transactionModel, 'payment_method_type'),
                'last_4' => Arr::get($transactionModel, 'card_last_4'),
                'brand' => Arr::get($transactionModel, 'card_brand'),
            ],
        ]);


        (new SubscriptionActivated($subscriptionModel, $order, $order->customer))->dispatch();

        return true;
    }

    /**
     * Recover the payment profile from the successful transaction, never a saved card.
     * Returns the profile array or null on failure.
     */
    protected function createProfileFromTransaction($subscriptionModel, $transactionModel, $order, $customer, string $mode): ?array
    {
        $vendorChargeId = $transactionModel->vendor_charge_id;
        if (!$vendorChargeId) {
            $subscriptionModel->addLog(
                __('Authorize.Net Subscription Recovery Failed', 'fluent-cart-pro'),
                __('Cannot recover a payment profile without a gateway transaction ID.', 'fluent-cart-pro'),
                'error'
            );

            return null;
        }

        // Authorize.Net validates that this is an eligible successful transaction.
        // A capture webhook may arrive before the local status is updated.
        $customerProfileData = [
            'merchantAuthentication' => $this->api->getMerchantAuthentication($mode),
            'transId' => $vendorChargeId,
        ];

        $customerProfile = $this->api->createAuthorizeNetObject('createCustomerProfileFromTransactionRequest', $customerProfileData, $mode);

        if (is_wp_error($customerProfile)) {
            // E00039: profile already exists — extract existing profileId and fetch it
            $errorData         = (array) $customerProfile->get_error_data();
            $existingProfileId = Arr::get($errorData, 'customerProfileId')
                ?: AuthorizeDotNetHelper::extractDuplicateProfileIdFromError($customerProfile->get_error_message());

            if (!$existingProfileId) {
                fluent_cart_error_log('Authorize.Net Subscription', 'Failed to create customer profile from transaction. Error: ' . $customerProfile->get_error_message(), [
                    'module_name' => 'order',
                    'module_id'   => $order->id,
                ]);
                $subscriptionModel->addLog(
                    __('Authorize.Net Customer Profile', 'fluent-cart-pro'),
                    sprintf(
                        /* translators: 1: vendor transaction id, 2: error message */
                        __('Failed to create customer profile from transaction (transId: %1$s): %2$s', 'fluent-cart-pro'),
                        $vendorChargeId,
                        $customerProfile->get_error_message()
                    ),
                    'error'
                );
                return null;
            }

            // The profile exists but may hold other cards — attach the one that paid
            // rather than taking whichever card the profile stored first. Pin the
            // profile first so a retry after a failed attach targets the same one.
            $customer->updateMeta('authorize_dot_net_profile_id', $existingProfileId);
            $this->pinProfileOnTransaction($transactionModel, (string) $existingProfileId);

            $attached = $this->attachPaidCardToProfile((string) $vendorChargeId, (string) $existingProfileId, $mode);

            if (is_wp_error($attached)) {
                fluent_cart_error_log('Authorize.Net Subscription', 'Failed to attach the paid card to the existing customer profile. Error: ' . $attached->get_error_message(), [
                    'module_name' => 'order',
                    'module_id'   => $order->id,
                ]);
                $subscriptionModel->addLog(
                    __('Authorize.Net Customer Profile', 'fluent-cart-pro'),
                    sprintf(
                        /* translators: 1: vendor transaction id, 2: customer profile id, 3: error message */
                        __('Could not attach the paid card (transId: %1$s) to customer profile %2$s, will retry: %3$s', 'fluent-cart-pro'),
                        $vendorChargeId,
                        $existingProfileId,
                        $attached->get_error_message()
                    ),
                    'error'
                );
                return null;
            }

            $this->pinProfileOnTransaction($transactionModel, $attached['customerProfileId'], $attached['customerPaymentProfileId']);

            $subscriptionModel->addLog(
                __('Authorize.Net Customer Profile', 'fluent-cart-pro'),
                sprintf(
                    /* translators: 1: vendor transaction id, 2: customer profile id, 3: payment profile id */
                    __('Attached the paid card (transId: %1$s) to existing customer profile — profileId: %2$s, paymentProfileId: %3$s', 'fluent-cart-pro'),
                    $vendorChargeId,
                    $attached['customerProfileId'],
                    $attached['customerPaymentProfileId']
                )
            );

            return $attached;
        }

        $profileId        = (string) Arr::get($customerProfile, 'customerProfileId');
        $paymentProfileId = static::firstPaymentProfileId($customerProfile);
        if (!$profileId || !$paymentProfileId) {
            $subscriptionModel->addLog(
                __('Authorize.Net Subscription Recovery Failed', 'fluent-cart-pro'),
                __('Authorize.Net did not return both profile IDs for the paid transaction.', 'fluent-cart-pro'),
                'error'
            );

            return null;
        }


        $customer->updateMeta('authorize_dot_net_profile_id', $profileId);
        $this->pinProfileOnTransaction($transactionModel, $profileId, $paymentProfileId);

        $subscriptionModel->addLog(
            __('Authorize.Net Customer Profile', 'fluent-cart-pro'),
            sprintf(
                /* translators: 1: vendor transaction id, 2: customer profile id, 3: payment profile id */
                __('Customer profile created from transaction (transId: %1$s) — profileId: %2$s, paymentProfileId: %3$s', 'fluent-cart-pro'),
                $vendorChargeId,
                $profileId,
                $paymentProfileId ?: 'NULL'
            )
        );

        return [
            'customerProfileId'        => $profileId,
            'customerPaymentProfileId' => $paymentProfileId,
        ];
    }

    /**
     * Attach the card that paid $transId to an existing customer profile as a new
     * payment profile. createCustomerProfileFromTransactionRequest with a
     * customerProfileId does exactly that; without one Auth.Net mints a second
     * customer profile. A card already stored on the profile answers E00039; that is
     * the same card, so the payment profile id the error carries is reused. The
     * response contract is createCustomerProfileResponse, whose id field is the
     * list-shaped customerPaymentProfileIdList — the singular customerPaymentProfileId
     * is read too in case the duplicate error mirrors createCustomerPaymentProfileResponse.
     *
     * @param string $mode environment of the order the card paid; checkout leaves it at 'current'
     * @return array{customerProfileId: string, customerPaymentProfileId: string}|\WP_Error
     */
    public function attachPaidCardToProfile(string $transId, string $customerProfileId, string $mode = 'current')
    {
        $response = $this->api->createAuthorizeNetObject('createCustomerProfileFromTransactionRequest', [
            'merchantAuthentication' => $this->api->getMerchantAuthentication($mode),
            'transId'                => $transId,
            'customerProfileId'      => $customerProfileId,
        ], $mode);

        if (is_wp_error($response)) {
            $existingPaymentProfileId = static::firstPaymentProfileId((array) $response->get_error_data());

            if ($existingPaymentProfileId && stripos($response->get_error_message(), 'duplicate') !== false) {
                return [
                    'customerProfileId'        => $customerProfileId,
                    'customerPaymentProfileId' => $existingPaymentProfileId,
                ];
            }

            return $response;
        }

        $paymentProfileId = static::firstPaymentProfileId($response);

        if (!$paymentProfileId) {
            return new \WP_Error('authnet_no_payment_profile', __('Authorize.Net did not return a payment profile for the paid card.', 'fluent-cart-pro'));
        }

        return [
            'customerProfileId'        => $customerProfileId,
            'customerPaymentProfileId' => $paymentProfileId,
        ];
    }

    /**
     * Record on the transaction which profile (and, once known, which payment profile)
     * the paid card belongs to. A later activation attempt — after an ARB failure or a
     * failed attach — reads this first and never substitutes another card or profile.
     */
    protected function pinProfileOnTransaction($transactionModel, string $customerProfileId, string $paymentProfileId = ''): void
    {
        $transactionModel->meta = array_merge($transactionModel->meta ?? [], [
            'authnet_customer_profile_id' => $customerProfileId,
            'authnet_payment_profile_id'  => $paymentProfileId,
        ]);
        $transactionModel->save();
    }

    /**
     * Payment profile id from a createCustomerProfileResponse-shaped body. The list
     * arrives as a plain array, or as {numericString: [...]} when only one id is present.
     */
    protected static function firstPaymentProfileId(array $response): string
    {
        $paymentIdList = Arr::get($response, 'customerPaymentProfileIdList', []);
        if (isset($paymentIdList['numericString'])) {
            $paymentIdList = (array) $paymentIdList['numericString'];
        }

        return (string) (Arr::first((array) $paymentIdList) ?: Arr::get($response, 'customerPaymentProfileId', ''));
    }

    /**
     * A freshly-checked-out subscription with no ARB schedule yet. Requires an empty
     * vendor_subscription_id — the two write sites that set it always bundle it with
     * status -> ACTIVE in the same update, so a pending subscription should never carry
     * one, but this keeps that invariant explicit instead of relying on write-site behavior.
     *
     * Store-billed (manual/system) subscriptions are never eligible: their first payment
     * is a one-time charge and the renewal engine owns every later cycle, so an ARB
     * schedule on top of that would bill the card in parallel with the invoices.
     *
     * Formerly isNewSubscriptionPending().
     */
    public static function isAwaitingFirstActivation(Subscription $subscriptionModel): bool
    {
        return !$subscriptionModel->usesRenewalEngine()
            && empty($subscriptionModel->vendor_subscription_id)
            && in_array($subscriptionModel->status, [Status::SUBSCRIPTION_PENDING, Status::SUBSCRIPTION_INTENDED]);
    }

    /**
     * ARB occurrences a reactivation must still bill after its own payment: 9999 for an
     * unlimited plan, 0 when that payment was the last installment.
     */
    public static function reactivationOccurrences(Subscription $subscriptionModel, OrderTransaction $transaction): int
    {
        $billTimes = (int) $subscriptionModel->bill_times;
        if ($billTimes <= 0) {
            return 9999;
        }

        $billsCount = $subscriptionModel->calculateBillCount();

        // Read after counting: still pending means the count missed this payment;
        // succeeded means a concurrent confirmation may have landed mid-count, so count again
        $paidTransaction = OrderTransaction::query()->find($transaction->id);
        if ($paidTransaction && $paidTransaction->status === Status::TRANSACTION_SUCCEEDED) {
            $billsCount = $subscriptionModel->calculateBillCount();
        } elseif ($paidTransaction && $paidTransaction->total > 0) {
            $billsCount++;
        }

        return max(0, $billTimes - $billsCount);
    }

    /**
     * A renewal order reusing an existing (now canceled/expired) local subscription row —
     * eligible for ARB activation once its old vendor subscription id is known. Same
     * store-billed exclusion as isAwaitingFirstActivation().
     *
     * Formerly isRenewalSubscriptionPending().
     */
    public static function isAwaitingReactivation(Subscription $subscriptionModel, $order): bool
    {
        $oldVendorSubscriptionId = Arr::get($order->config ?? [], 'old_vendor_subscription_id', '');

        return !$subscriptionModel->usesRenewalEngine()
            && $order->type == 'renewal'
            && in_array($subscriptionModel->status, [Status::SUBSCRIPTION_CANCELED, Status::SUBSCRIPTION_EXPIRED])
            && $oldVendorSubscriptionId
            && $subscriptionModel->vendor_subscription_id === $oldVendorSubscriptionId;
    }

    /**
     * Cancels the old ARB subscription, dispatches the reactivation event and syncs any
     * price change — shared between the IPN activation path and the background ARB retry
     * sweep so a renewal that activates on retry gets the same housekeeping as one that
     * activates immediately.
     *
     * Formerly finalizeRenewalReactivation().
     */
    public function completeReactivation(Subscription $subscriptionModel, $order): void
    {
        $oldVendorSubscriptionId = Arr::get($order->config ?? [], 'old_vendor_subscription_id', '');

        if ($oldVendorSubscriptionId) {
            $this->cancel($oldVendorSubscriptionId, [
                'subscription_id' => $subscriptionModel->id,
                'mode'            => $order->mode,
                'effective_from'  => 'immediately',
            ]);
        }

        $subscriptionModel = Subscription::query()->find($subscriptionModel->id);
        (new SubscriptionReactivated($subscriptionModel, $order, $order->customer))->dispatch();

        $cart = Cart::query()->where('order_id', $order->id)->first();
        if (!$cart) {
            return;
        }

        $newRecurringAmount = (int) Arr::get($cart->checkout_data, 'renew_data.new_recurring_amount', 0);
        $oldRecurringAmount = (int) Arr::get($cart->checkout_data, 'renew_data.old_recurring_amount', 0);

        if ($newRecurringAmount <= 0 || $newRecurringAmount == $oldRecurringAmount) {
            return;
        }

        $newRecurringTotal = $newRecurringAmount;
        if ($order->tax_behavior != 2) {
            $newRecurringTotal += (int) Arr::get($cart->checkout_data, 'tax_data.tax_total', 0);
        }
        $subscriptionModel->recurring_amount = $newRecurringAmount;
        $subscriptionModel->recurring_total  = $newRecurringTotal;
        $subscriptionModel->save();
    }

    /**
     * Flag a subscription for background ARB creation. Auth.Net's ARB service reads
     * replicated CIM data, and the replication lag has been observed to run from a few
     * seconds up to over an hour. The core scheduler retries every 5 minutes, waiting
     * at least ARB_RETRY_MIN_DELAY_SECONDS before the first attempt, up to
     * ARB_RETRY_MAX_ATTEMPTS attempts, then manual action required.
     *
     * $subscriptionPayload, when given, is the already-built ARB `subscription` array
     * from the checkout attempt (interval/trial/startDate/profile already resolved) —
     * cached so the retry doesn't have to recompute it from scratch.
     *
     * Formerly markForArbRetry().
     */
    public static function deferSubscriptionCreation(Subscription $subscriptionModel, ?array $subscriptionPayload = null): void
    {
        if ($subscriptionPayload && $subscriptionModel->getMeta(self::ARB_PENDING_DATA_META_KEY) === null) {
            $subscriptionModel->updateMeta(self::ARB_PENDING_DATA_META_KEY, $subscriptionPayload);
        }

        if ($subscriptionModel->getMeta(self::ARB_RETRY_META_KEY) !== null) {
            return;
        }

        $subscriptionModel->updateMeta(self::ARB_RETRY_META_KEY, 0);
        $subscriptionModel->updateMeta(self::ARB_RETRY_MARKED_AT_META_KEY, DateTime::now()->format('Y-m-d H:i:s'));
    }

    /**
     * Runs on fluent_cart/scheduler/five_minutes_tasks. Sweeps subscriptions marked
     * for ARB creation retry and attempts to create their Authorize.Net schedules.
     *
     * Formerly processPendingArbCreations().
     */
    public function retryDeferredSubscriptionCreations(): void
    {
        $markers = SubscriptionMeta::query()
            ->where('meta_key', self::ARB_RETRY_META_KEY)
            ->limit(20)
            ->get();

        foreach ($markers as $marker) {
            $this->retrySubscriptionCreation($marker);
        }
    }

    /**
     * Formerly processArbRetryMarker().
     */
    protected function retrySubscriptionCreation(SubscriptionMeta $marker): void
    {
        $subscriptionModel = Subscription::query()->find($marker->subscription_id);

        // The order that was paid, same as the webhook path: a reactivation pays through a
        // renewal order while the subscription row still points at its original order.
        $transactionModel = $subscriptionModel ? $this->latestPaidCharge($subscriptionModel) : null;
        $order = $transactionModel ? $transactionModel->order : null;
        if (!$order && $subscriptionModel) {
            $order = $subscriptionModel->order;
        }

        $isNewSubPending  = $subscriptionModel && self::isAwaitingFirstActivation($subscriptionModel);
        $isRenewalPending = $subscriptionModel && $order && self::isAwaitingReactivation($subscriptionModel, $order);

        if (!$subscriptionModel || !$order || (!$isNewSubPending && !$isRenewalPending)) {
            if ($subscriptionModel) {
                $subscriptionModel->deleteMeta(self::ARB_PENDING_DATA_META_KEY);
            }
            $marker->delete();
            return;
        }

        // Give Auth.Net's CIM->ARB replication a head start before the first attempt —
        // checking immediately after the first payment almost always still hits E00040.
        $markedAt = $subscriptionModel->getMeta(self::ARB_RETRY_MARKED_AT_META_KEY);
        if ($markedAt && DateTime::now()->diffInSeconds(DateTime::parse($markedAt)) < self::ARB_RETRY_MIN_DELAY_SECONDS) {
            return;
        }

        // Same lock the IPN activation path uses — sweep and webhook must not race.
        // Locked means a webhook is on it right now; check again next tick.
        $lockKey = 'authnet_activation_lock_' . $subscriptionModel->id;
        if (get_transient($lockKey)) {
            return;
        }
        set_transient($lockKey, 1, 60);

        try {
            $activated = $transactionModel
                ? $this->activateSubscriptionAfterPayment($subscriptionModel, $transactionModel)
                : false;
        } finally {
            delete_transient($lockKey);
        }

        if ($activated === true) {
            $subscriptionModel->deleteMeta(self::ARB_PENDING_DATA_META_KEY);
            $marker->delete();

            if ($isRenewalPending) {
                $this->completeReactivation($subscriptionModel, $order);
            }
            return;
        }

        $attempts = (int) $marker->meta_value + 1;

        if ($attempts < self::ARB_RETRY_MAX_ATTEMPTS) {
            $marker->meta_value = $attempts;
            $marker->save();

            $subscriptionModel->addLog(
                __('Authorize.Net Subscription', 'fluent-cart-pro'),
                sprintf(
                    /* translators: %d: attempt number */
                    __('Subscription creation attempt %d failed — next automatic retry scheduled.', 'fluent-cart-pro'),
                    $attempts
                ),
                'warning'
            );
        } else {
            $subscriptionModel->deleteMeta(self::ARB_PENDING_DATA_META_KEY);
            $marker->delete();

            $subscriptionModel->addLog(
                __('Authorize.Net Manual Action Required', 'fluent-cart-pro'),
                __('Automatic subscription creation retries are exhausted. Please review the order in the Authorize.Net dashboard — the first payment is captured but no ARB subscription exists.', 'fluent-cart-pro'),
                'warning'
            );
        }
    }

    protected function latestPaidCharge(Subscription $subscriptionModel): ?OrderTransaction
    {
        return OrderTransaction::query()
            ->where('subscription_id', $subscriptionModel->id)
            ->where('transaction_type', Status::TRANSACTION_TYPE_CHARGE)
            ->where('status', Status::TRANSACTION_SUCCEEDED)
            ->orderBy('id', 'desc')
            ->first();
    }

    /*
     * Deprecated names, kept so code written against 1.6.4 and earlier keeps working.
     * Each forwards to the method that replaced it.
     */

    /** @deprecated 1.6.5 Use activateSubscriptionAfterPayment(). */
    public function createAndActivateSubscriptionOnTransactionApprove($subscriptionModel, $transactionModel)
    {
        _deprecated_function(__METHOD__, '1.6.5', __CLASS__ . '::activateSubscriptionAfterPayment()');
        return $this->activateSubscriptionAfterPayment($subscriptionModel, $transactionModel);
    }

    /** @deprecated 1.6.5 Use isAwaitingFirstActivation(). */
    public static function isNewSubscriptionPending(Subscription $subscriptionModel): bool
    {
        _deprecated_function(__METHOD__, '1.6.5', __CLASS__ . '::isAwaitingFirstActivation()');
        return self::isAwaitingFirstActivation($subscriptionModel);
    }

    /** @deprecated 1.6.5 Use isAwaitingReactivation(). */
    public static function isRenewalSubscriptionPending(Subscription $subscriptionModel, $order): bool
    {
        _deprecated_function(__METHOD__, '1.6.5', __CLASS__ . '::isAwaitingReactivation()');
        return self::isAwaitingReactivation($subscriptionModel, $order);
    }

    /** @deprecated 1.6.5 Use completeReactivation(). */
    public function finalizeRenewalReactivation(Subscription $subscriptionModel, $order): void
    {
        _deprecated_function(__METHOD__, '1.6.5', __CLASS__ . '::completeReactivation()');
        $this->completeReactivation($subscriptionModel, $order);
    }

    /** @deprecated 1.6.5 Use deferSubscriptionCreation(). */
    public static function markForArbRetry(Subscription $subscriptionModel, ?array $subscriptionPayload = null): void
    {
        _deprecated_function(__METHOD__, '1.6.5', __CLASS__ . '::deferSubscriptionCreation()');
        self::deferSubscriptionCreation($subscriptionModel, $subscriptionPayload);
    }

    /** @deprecated 1.6.5 Use retryDeferredSubscriptionCreations(). */
    public function processPendingArbCreations(): void
    {
        _deprecated_function(__METHOD__, '1.6.5', __CLASS__ . '::retryDeferredSubscriptionCreations()');
        $this->retryDeferredSubscriptionCreations();
    }

    /** @deprecated 1.6.5 Use retrySubscriptionCreation(). */
    protected function processArbRetryMarker(SubscriptionMeta $marker): void
    {
        _deprecated_function(__METHOD__, '1.6.5', __CLASS__ . '::retrySubscriptionCreation()');
        $this->retrySubscriptionCreation($marker);
    }
}
