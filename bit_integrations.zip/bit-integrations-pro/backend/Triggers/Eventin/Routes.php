<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Core\Util\Route;
use BitApps\IntegrationsPro\Triggers\Eventin\EventinController;

Route::get('eventin/get', [EventinController::class, 'getAll']);
Route::post('eventin/get/form', [EventinController::class, 'get_a_form']);
