<?php

namespace BitApps\IntegrationsPro\Actions\ACPT;

use WP_Error;

class ACPTProHelper
{
    public static function update($default, $apiUrl, $apiKey, $data)
    {
        $httpHelperClass = self::getHttpHelperClass();
        if ($httpHelperClass instanceof WP_Error) {
            return $httpHelperClass;
        }

        return $httpHelperClass::request($apiUrl, 'PUT', $data, self::setHeaders($apiKey));
    }

    public static function delete($default, $apiUrl, $apiKey)
    {
        $httpHelperClass = self::getHttpHelperClass();
        if ($httpHelperClass instanceof WP_Error) {
            return $httpHelperClass;
        }

        return $httpHelperClass::request($apiUrl, 'DELETE', [], self::setHeaders($apiKey));
    }

    public static function createTaxonomyOrOptionPage($default, $apiUrl, $apiKey, $data)
    {
        $httpHelperClass = self::getHttpHelperClass();
        if ($httpHelperClass instanceof WP_Error) {
            return $httpHelperClass;
        }

        return $httpHelperClass::post($apiUrl, $data, self::setHeaders($apiKey));
    }

    public static function associateTaxonomyToCPT($default, $apiUrl, $apiKey)
    {
        $httpHelperClass = self::getHttpHelperClass();
        if ($httpHelperClass instanceof WP_Error) {
            return $httpHelperClass;
        }

        return $httpHelperClass::post($apiUrl, [], self::setHeaders($apiKey));
    }

    private static function getHttpHelperClass()
    {
        $httpHelperClass = bit_integrations_get_class('Core\\Util\\HttpHelper');
        if (!$httpHelperClass) {
            return new WP_Error('class_not_found', 'HttpHelper class not found');
        }

        return $httpHelperClass;
    }

    private static function setHeaders($apiKey)
    {
        return [
            'acpt-api-key' => $apiKey,
            'Content-Type' => 'application/json',
            'accept'       => 'application/json',
        ];
    }
}
