<?php

namespace FluentCartPro\App\Hooks\Handlers\BlockEditors\OrderBumpBlocks;

/**
 * The checkbox row of the checkout card. It prints the same markup the checkout script
 * already listens to.
 */
class OrderBumpCheckboxBlockEditor extends OrderBumpBlockEditor
{
    protected static string $editorName = 'order-bump-checkbox';

    public function getScripts(): array
    {
        return [
            [
                'source'       => 'admin/BlockEditor/OrderBumpBlocks/OrderBumpCheckboxBlockEditor.jsx',
                'dependencies' => ['wp-blocks', 'wp-components', 'wp-block-editor']
            ]
        ];
    }

    public function localizeData(): array
    {
        return [
            $this->getLocalizationKey() => [
                'slug'        => $this->slugPrefix,
                'name'        => static::getEditorName(),
                'title'       => __('Order Bump Checkbox', 'fluent-cart-pro'),
                'description' => __('The checkbox that adds the offer to the order.', 'fluent-cart-pro'),
            ],
            'fluent_cart_block_translation' => \FluentCart\App\Services\Translations\TransStrings::blockStrings(),
        ];
    }

    public function blockAttributes(): array
    {
        return [
            'label' => ['type' => 'string', 'default' => 'Grab it for {{bump.price}}'],
        ];
    }

    public function render(array $attrs, $block = null, $content = ''): string
    {
        $bump = $this->bump($block);
        if (!$bump) {
            return '';
        }

        $id = (int) $bump['id'];
        $label = !empty($attrs['label']) ? $attrs['label'] : sprintf(__('Grab it for %s', 'fluent-cart-pro'), '{{bump.price}}');

        // The wrapper attributes carry the block's colour, typography and spacing settings.
        $wrapper = get_block_wrapper_attributes(['class' => 'fct_order_promotion_toggle']);

        return sprintf(
            '<label %1$s><input type="checkbox" class="fct_order_promotion_input" data-fct_order_bump %2$s data-fct_bump_id="%3$d">'
            . '<span>%4$s</span></label>',
            $wrapper,
            !empty($bump['is_added']) ? 'checked' : '',
            $id,
            esc_html($label)
        );
    }
}
