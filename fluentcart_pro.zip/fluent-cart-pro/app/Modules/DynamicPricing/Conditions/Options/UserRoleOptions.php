<?php

namespace FluentCartPro\App\Modules\DynamicPricing\Conditions\Options;

use FluentCart\App\Services\Permission\PermissionManager;
use FluentCart\Framework\Support\Arr;

/**
 * User roles for the condition builder's remote select.
 *
 * Picked by slug, so searching, limiting and keeping the chosen roles visible
 * come from SlugOptionSource.
 *
 * @package FluentCartPro\App\Modules\DynamicPricing
 *
 * @version 1.0.0
 */
class UserRoleOptions extends SlugOptionSource
{
    /**
     * The `data_key` a condition attribute names to reach this list.
     *
     * @var string
     */
    protected $key = 'dynamic_pricing_user_roles';

    /**
     * Every role registered on the site, flattened to `slug => label`.
     *
     * WordPress hands back each role with its full capability map attached,
     * which is far more than a dropdown needs:
     *
     *   get_editable_roles()   [
     *                            'subscriber' => [
     *                                'name'         => 'Subscriber',
     *                                'capabilities' => ['read' => true, ...],
     *                            ],
     *                            'shop_manager' => [...],
     *                          ]
     *
     *   roles()                ['subscriber' => 'Subscriber', 'shop_manager' => 'Shop Manager']
     *
     * The slug is what a condition stores, the name is what the admin reads.
     * A role registered without a name falls back to its own slug, so a
     * third-party role still appears rather than rendering as a blank line.
     *
     * The list is whatever the site has: WordPress ships five, and plugins add
     * their own, so it is read live rather than hardcoded.
     *
     * Public because it is also the whitelist a saved condition is held against
     * — a role that cannot be picked here must not be storable either.
     *
     * Administrator is deliberately kept. WPUserConnect drops it from its own
     * list because that feature *assigns* a role and must not hand out admin;
     * this one only matches a role someone already has, and a rule that treats
     * administrators differently is a legitimate thing to want.
     *
     * @return array
     */
    public function roles(): array
    {
        // Only loaded on admin screens, and this runs for an API request too.
        if (!function_exists('get_editable_roles')) {
            require_once ABSPATH . 'wp-admin/includes/user.php';
        }

        $roles = [];

        foreach (get_editable_roles() as $slug => $role) {
            $roles[$slug] = Arr::get($role, 'name', $slug);
        }

        return $roles;
    }

    /**
     * @return array
     */
    public function available(): array
    {
        return $this->roles();
    }

    /**
     * Both bars, not either: the data describes people, and the reason this key
     * exists at all is the pricing rule editor.
     *
     * @param bool $hasPermission
     * @return bool
     */
    public function canRead($hasPermission)
    {
        return PermissionManager::hasPermission('customers/view')
            && PermissionManager::hasPermission('dynamic_pricing/view');
    }
}
