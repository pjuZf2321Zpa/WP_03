<?php

namespace MasterStudy\Lms\Pro\AddonsPlus\AiLab\Services\OpenAi;

use DateTimeInterface;
use MasterStudy\Lms\Pro\AddonsPlus\AiLab\Utility\ArrayHelper;

class Client {
	private string $api_key;
	private string $provider;
	private string $base_url;
	private string $image_provider;
	private string $image_api_key;
	private string $image_base_url;
	private string $openai_api_key;

	public function __construct( $api_key, array $config = array() ) {
		$this->api_key        = (string) $api_key;
		$this->provider       = $config['provider'] ?? Model::PROVIDER_OPENAI;
		$this->base_url       = untrailingslashit( $config['base_url'] ?? Model::get_provider_base_url( $this->provider ) );
		$this->image_provider = $config['image_provider'] ?? Model::PROVIDER_OPENAI;
		$this->image_api_key  = (string) ( $config['image_api_key'] ?? '' );
		$this->image_base_url = untrailingslashit( $config['image_base_url'] ?? Model::get_provider_base_url( $this->image_provider ) );
		$this->openai_api_key = (string) ( $config['openai_api_key'] ?? '' );
	}

	public function get_files() {
		return $this->request(
			'GET',
			'/files',
			null,
			Model::PROVIDER_OPENAI,
			$this->get_openai_api_key(),
			Model::get_provider_base_url( Model::PROVIDER_OPENAI )
		);
	}

	public function get_file( $file_id ) {
		return $this->request(
			'GET',
			"/files/$file_id",
			null,
			Model::PROVIDER_OPENAI,
			$this->get_openai_api_key(),
			Model::get_provider_base_url( Model::PROVIDER_OPENAI )
		);
	}

	public function get_models() {
		return $this->request(
			'GET',
			'/models',
			null,
			$this->provider,
			$this->api_key,
			$this->base_url
		);
	}

	public function get_model( $model_id ) {
		return $this->request(
			'GET',
			"/models/$model_id",
			null,
			$this->provider,
			$this->api_key,
			$this->base_url
		);
	}

	public function upload_file( UploadFile $file, string $purpose ) {
		return $this->request(
			'POST',
			'/files',
			array(
				'purpose' => $purpose,
				'file'    => $file,
			),
			Model::PROVIDER_OPENAI,
			$this->get_openai_api_key(),
			Model::get_provider_base_url( Model::PROVIDER_OPENAI )
		);
	}

	public function delete_file( $file_id ) {
		return $this->request(
			'DELETE',
			"/files/$file_id",
			null,
			Model::PROVIDER_OPENAI,
			$this->get_openai_api_key(),
			Model::get_provider_base_url( Model::PROVIDER_OPENAI )
		);
	}

	public function get_file_content( $file_id ) {
		return $this->request(
			'GET',
			"/files/$file_id/content",
			null,
			Model::PROVIDER_OPENAI,
			$this->get_openai_api_key(),
			Model::get_provider_base_url( Model::PROVIDER_OPENAI )
		);
	}

	/**
	 * @return array<string>
	 */
	public function prepare_upload( array $data ) {
		$boundary = wp_generate_password( 12, false );

		$body = '';
		foreach ( $data as $name => $value ) {
			$body .= "--$boundary\r\n";
			$body .= "Content-Disposition: form-data; name=\"$name\"";
			if ( $value instanceof UploadFile ) {
				$body .= "; filename=\"{$value->filename}\"\r\n";
				$body .= "Content-Type: application/json\r\n\r\n";
				$body .= $value->content . "\r\n";
			} else {
				$body .= "\r\n\r\n$value\r\n";
			}
		}
		$body .= "--$boundary--\r\n";

		return array( $boundary, $body );
	}

	public function request( $method, $endpoint, $body = null, ?string $provider = null, ?string $api_key = null, ?string $base_url = null ) {
		$provider = $provider ?? $this->provider;
		$api_key  = $api_key ?? $this->api_key;
		$base_url = untrailingslashit( $base_url ?? $this->base_url );

		if ( empty( $api_key ) ) {
			throw new Exception( esc_html__( 'API key is missing. Please update AI Lab settings.', 'masterstudy-lms-learning-management-system-pro' ) );
		}

		$headers = $this->build_headers( $provider, $api_key );

		if ( is_array( $body ) ) {
			$has_file = null !== ArrayHelper::first(
				$body,
				function ( $value ) {
					return $value instanceof UploadFile;
				}
			);

			if ( $has_file ) {
				list( $boundary, $body ) = $this->prepare_upload( $body );
				$headers['Content-Type'] = 'multipart/form-data; boundary=' . $boundary;
			} else {
				$headers['Content-Type'] = 'application/json';
				$body                    = wp_json_encode( $body );
			}
		}

		$options = array(
			'headers'   => $headers,
			'method'    => $method,
			'timeout'   => 300,
			'body'      => $body,
			'sslverify' => false,
		);

		try {
			$response = wp_remote_request( $base_url . $endpoint, $options );
			if ( is_wp_error( $response ) ) {
				throw new Exception( $response->get_error_message() );
			}

			$response_body = wp_remote_retrieve_body( $response );
			$data          = json_decode( $response_body, true );
			$status_code   = (int) wp_remote_retrieve_response_code( $response );

			if ( $status_code >= 400 && ! isset( $data['error'] ) ) {
				if ( ! empty( $data['message'] ) ) {
					$error_message = $data['message'];
				} elseif ( ! empty( $response['response']['message'] ) ) {
					$error_message = $response['response']['message'];
				} elseif ( ! empty( $response_body ) ) {
					$error_message = $response_body;
				} else {
					$error_message = esc_html__( 'Unknown error.', 'masterstudy-lms-learning-management-system-pro' );
				}

				throw new Exception( $error_message );
			}

			if ( isset( $data['error'] ) ) {
				if ( is_array( $data['error'] ) && ! empty( $data['error']['message'] ) ) {
					$error_message = str_replace( $api_key, str_repeat( '*', 6 ), $data['error']['message'] );
				} elseif ( is_string( $data['error'] ) ) {
					$error_message = $data['error'];
				} elseif ( ! empty( $response['response']['message'] ) ) {
					$error_message = 'Bad Request' === $response['response']['message']
						? esc_html__( 'Sorry, your request cannot be processed. To maintain a safe and respectful environment, we restrict content related to certain sensitive topics.', 'masterstudy-lms-learning-management-system-pro' )
						: $response['response']['message'];
				} else {
					$error_message = esc_html__( 'Unknown error.', 'masterstudy-lms-learning-management-system-pro' );
				}

				throw new Exception( $error_message );
			}

			if ( is_array( $data ) ) {
				return $data;
			}

			return $response_body;
		} catch ( Exception $e ) {
			throw new Exception( ucfirst( $provider ) . ' API Error: ' . $e->getMessage() );
		}
	}

	/**
	 * @throws Exception
	 * @return array<array{"title": string, "description": string, "date": string}>
	 */
	public function get_incidents( DateTimeInterface $after ): array {
		$url      = 'https://status.openai.com/history.rss';
		$response = wp_remote_get( $url, array( 'sslverify' => false ) );

		if ( is_wp_error( $response ) ) {
			throw new Exception( $response->get_error_message() );
		}

		$xml       = simplexml_load_string( wp_remote_retrieve_body( $response ) );
		$incidents = array();

		foreach ( $xml->channel->item as $item ) {
			$incident_time = strtotime( $item->pubDate ); // phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase

			// assume that it ordered by date
			if ( $after->getTimestamp() > $incident_time ) {
				break;
			}

			$incidents[] = array(
				'title'       => (string) $item->title,
				'description' => (string) $item->description,
				'date'        => $incident_time,
			);
		}

		return $incidents;
	}

	public function create_completions( array $data ) {
		if ( Model::PROVIDER_CLAUDE === $this->provider ) {
			$response = $this->request(
				'POST',
				'/messages',
				$this->prepare_claude_request( $data ),
				$this->provider,
				$this->api_key,
				$this->base_url
			);

			return $this->normalize_claude_response( $response );
		}

		if ( Model::PROVIDER_GEMINI === $this->provider ) {
			$data = $this->prepare_gemini_request( $data );
		}

		return $this->request(
			'POST',
			'/chat/completions',
			$data,
			$this->provider,
			$this->api_key,
			$this->base_url
		);
	}

	public function create_images( array $data ) {
		if ( ! Model::provider_supports_image_generation( $this->image_provider ) ) {
			throw new Exception(
				esc_html__( 'Selected text provider does not support direct image generation in AI Lab. Please choose a fallback image provider in AI Lab settings.', 'masterstudy-lms-learning-management-system-pro' )
			);
		}

		$response = $this->request(
			'POST',
			'/images/generations',
			$data,
			$this->image_provider,
			$this->get_image_api_key(),
			$this->image_base_url
		);

		return $this->normalize_image_response( $response );
	}

	private function build_headers( string $provider, string $api_key ): array {
		if ( Model::PROVIDER_CLAUDE === $provider ) {
			return array(
				'x-api-key'         => $api_key,
				'anthropic-version' => '2023-06-01',
			);
		}

		$headers = array(
			'Authorization' => 'Bearer ' . $api_key,
		);

		return $headers;
	}

	private function prepare_gemini_request( array $data ): array {
		// Gemini OpenAI-compatible endpoint is strict with null/extra fields.
		if ( array_key_exists( 'stop', $data ) && empty( $data['stop'] ) ) {
			unset( $data['stop'] );
		}

		// Keep payload minimal; Gemini does not need explicit n when it's 1.
		if ( isset( $data['n'] ) && 1 === (int) $data['n'] ) {
			unset( $data['n'] );
		}

		return $data;
	}

	private function prepare_claude_request( array $data ): array {
		$messages = $data['messages'] ?? array();
		$system   = array();
		$chat     = array();

		foreach ( $messages as $message ) {
			$role    = $message['role'] ?? 'user';
			$content = isset( $message['content'] ) ? (string) $message['content'] : '';

			if ( 'system' === $role ) {
				$system[] = $content;
				continue;
			}

			$chat[] = array(
				'role'    => $role,
				'content' => $content,
			);
		}

		$body = array(
			'model'      => $data['model'] ?? Model::get_default_text_model_by_provider( Model::PROVIDER_CLAUDE ),
			'messages'   => $chat,
			'max_tokens' => (int) ( $data['max_completion_tokens'] ?? $data['max_tokens'] ?? 1024 ),
		);

		if ( ! empty( $system ) ) {
			$body['system'] = implode( "\n\n", $system );
		}

		if ( ! empty( $data['stop'] ) ) {
			$body['stop_sequences'] = is_array( $data['stop'] ) ? $data['stop'] : array( $data['stop'] );
		}

		return $body;
	}

	private function normalize_claude_response( $data ): array {
		if ( ! is_array( $data ) ) {
			return array(
				'choices' => array(
					array(
						'index'   => 0,
						'message' => array(
							'content' => (string) $data,
						),
					),
				),
				'usage'   => array(
					'prompt_tokens'     => 0,
					'completion_tokens' => 0,
					'total_tokens'      => 0,
				),
			);
		}

		$content_blocks = $data['content'] ?? array();
		$content        = '';

		foreach ( $content_blocks as $block ) {
			if ( isset( $block['text'] ) ) {
				$content .= $block['text'];
			}
		}

		$prompt_tokens     = (int) ( $data['usage']['input_tokens'] ?? 0 );
		$completion_tokens = (int) ( $data['usage']['output_tokens'] ?? 0 );

		return array(
			'choices' => array(
				array(
					'index'   => 0,
					'message' => array(
						'content' => $content,
					),
				),
			),
			'usage'   => array(
				'prompt_tokens'     => $prompt_tokens,
				'completion_tokens' => $completion_tokens,
				'total_tokens'      => $prompt_tokens + $completion_tokens,
			),
		);
	}

	private function normalize_image_response( $data ) {
		if ( ! is_array( $data ) || empty( $data['data'] ) || ! is_array( $data['data'] ) ) {
			return $data;
		}

		foreach ( $data['data'] as &$item ) {
			if ( empty( $item['url'] ) && ! empty( $item['b64_json'] ) ) {
				$item['mime_type'] = $item['mime_type'] ?? 'image/png';
			}
		}
		unset( $item );

		return $data;
	}

	private function get_image_api_key(): string {
		if ( ! empty( $this->image_api_key ) ) {
			return $this->image_api_key;
		}

		if ( $this->provider === $this->image_provider ) {
			return $this->api_key;
		}

		throw new Exception( esc_html__( 'Image provider API key is missing. Please update AI Lab settings.', 'masterstudy-lms-learning-management-system-pro' ) );
	}

	private function get_openai_api_key(): string {
		if ( ! empty( $this->openai_api_key ) ) {
			return $this->openai_api_key;
		}

		throw new Exception( esc_html__( 'OpenAI API key is missing. It is required for file management endpoints.', 'masterstudy-lms-learning-management-system-pro' ) );
	}
}
