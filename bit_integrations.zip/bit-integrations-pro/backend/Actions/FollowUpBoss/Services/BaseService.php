<?php

namespace BitApps\IntegrationsPro\Actions\FollowUpBoss\Services;

abstract class BaseService
{
    private $fields;

    private $apiClient;

    public function __construct($apiClient, $fieldData = [], $settings = [])
    {
        $this->apiClient = $apiClient;
        $this->fields = array_merge((array) $settings, (array) $fieldData);
    }

    protected function dispatch(string $method, string $path, ?array $body = null, array $query = []): array
    {
        if (!empty($query)) {
            $path .= '?' . http_build_query($this->formatQuery($query));
        }

        $headers = [];
        $payload = null;

        if ($body !== null) {
            $headers['Content-Type'] = 'application/json';
            $payload = wp_json_encode((object) $body);
        }

        $response = $this->apiClient->request($method, $path, $payload, $headers);
        $statusCode = (int) $response->getStatus();
        $responseBody = $this->decodeBody($response->getBody());

        if (!$response->success()) {
            return [
                'success' => false,
                'message' => $this->extractErrorMessage($response->getError(), $responseBody),
                'code'    => $statusCode >= 400 ? $statusCode : 400,
                'data'    => $responseBody,
            ];
        }

        return [
            'success' => true,
            'message' => __('Follow Up Boss completed the request.', 'bit-integrations-pro'),
            'code'    => $statusCode,
            'data'    => $this->isEmptyBody($responseBody) ? ['success' => true, 'request' => $body ?? $query] : $responseBody,
        ];
    }

    protected function getMissingCurrentValues(string $path, array $payload, array $keys): array
    {
        $missingKeys = array_diff($keys, array_keys($payload));

        if ($missingKeys === []) {
            return [];
        }

        $current = $this->dispatch('GET', $path);

        if (!$current['success']) {
            return $current;
        }

        return array_intersect_key((array) $current['data'], array_flip($missingKeys));
    }

    protected function validateFields(array $validationRules, array $labels, array $selectKeys = []): ?array
    {
        $missingFields = [];
        $missingSelections = [];
        $invalidNumbers = [];
        $invalidDecimals = [];
        $invalidValues = [];

        foreach ($validationRules as $key => $rules) {
            $value = $this->getString($key);

            $label = $labels[$key] ?? $key;

            if ($value === '' && $this->getList($key) === []) {
                if (\in_array('required', $rules, true) && \in_array($key, $selectKeys, true)) {
                    $missingSelections[] = $label;
                } elseif (\in_array('required', $rules, true)) {
                    $missingFields[] = $label;
                }

                continue;
            }

            if (\in_array('integer', $rules, true) && !preg_match('/^-?\d+$/', $value)) {
                $invalidNumbers[] = $label;
            } elseif (\in_array('numeric', $rules, true) && !is_numeric($value)) {
                $invalidDecimals[] = $label;
            } elseif (\in_array('email', $rules, true) && !is_email($value)) {
                $invalidValues[] = $label;
            } elseif (\in_array('boolean', $rules, true) && !\in_array(strtolower($value), ['true', 'false', '1', '0'], true)) {
                $invalidValues[] = $label;
            }
        }

        if ($missingFields !== []) {
            return $this->errorResponse(
                wp_sprintf(
                    // translators: %s: comma separated list of field names
                    _n('%s is required. Map a value to it.', '%s are required. Map a value to each of them.', \count($missingFields), 'bit-integrations-pro'),
                    implode(', ', $missingFields)
                )
            );
        }

        if ($missingSelections !== []) {
            return $this->errorResponse(
                wp_sprintf(
                    // translators: %s: comma separated list of field names
                    _n('%s is required. Select a value.', '%s are required. Select a value for each of them.', \count($missingSelections), 'bit-integrations-pro'),
                    implode(', ', $missingSelections)
                )
            );
        }

        if ($invalidNumbers !== []) {
            return $this->errorResponse(
                wp_sprintf(
                    // translators: %s: comma separated list of field names
                    __('%s must be a whole number. Remove the decimal part and any separators.', 'bit-integrations-pro'),
                    implode(', ', $invalidNumbers)
                )
            );
        }

        if ($invalidDecimals !== []) {
            return $this->errorResponse(
                wp_sprintf(
                    // translators: %s: comma separated list of field names
                    __('%s must be a number. Remove any separators.', 'bit-integrations-pro'),
                    implode(', ', $invalidDecimals)
                )
            );
        }

        if ($invalidValues !== []) {
            return $this->errorResponse(
                wp_sprintf(
                    // translators: %s: comma separated list of field names
                    __('%s has a value that is not valid. Check the mapped value.', 'bit-integrations-pro'),
                    implode(', ', $invalidValues)
                )
            );
        }

        return null;
    }

    protected function errorResponse(string $message, int $code = 400): array
    {
        return [
            'success' => false,
            'message' => $message,
            'code'    => $code,
        ];
    }

    protected function removeEmptyValues(array $data): array
    {
        return array_filter(
            $data,
            static function ($value) {
                if (\is_bool($value) || is_numeric($value)) {
                    return true;
                }

                return !empty($value);
            }
        );
    }

    protected function getValue(string $key)
    {
        return $this->fields[$key] ?? null;
    }

    protected function getString(string $key): string
    {
        $value = $this->getValue($key);

        if (\is_array($value) && \count($value) === 1) {
            $value = reset($value);
        }

        return \is_scalar($value) ? trim((string) $value) : '';
    }

    protected function getInteger(string $key): ?int
    {
        $value = $this->getString($key);

        return preg_match('/^-?\d+$/', $value) ? (int) $value : null;
    }

    protected function getNumber(string $key): ?float
    {
        $value = $this->getString($key);

        return is_numeric($value) ? (float) $value : null;
    }

    protected function getBoolean(string $key): ?bool
    {
        $value = $this->getValue($key);

        if (\is_bool($value)) {
            return $value;
        }

        if (!\is_scalar($value) || trim((string) $value) === '') {
            return null;
        }

        return filter_var($value, FILTER_VALIDATE_BOOLEAN, FILTER_NULL_ON_FAILURE);
    }

    protected function getList(string $key): array
    {
        $value = $this->getValue($key);

        if (\is_string($value) && strpos(ltrim($value), '[') === 0) {
            $decoded = json_decode($value, true);
            $value = \is_array($decoded) ? $decoded : $value;
        }

        $items = \is_array($value) ? $value : explode(',', (string) (\is_scalar($value) ? $value : ''));

        return array_values(
            array_filter(
                array_map(
                    static function ($item) {
                        return \is_scalar($item) ? trim((string) $item) : '';
                    },
                    $items
                ),
                static function ($item) {
                    return $item !== '';
                }
            )
        );
    }

    protected function getIntegerList(string $key): array
    {
        return array_map(
            'intval',
            array_values(
                array_filter(
                    $this->getList($key),
                    static function ($item) {
                        return (bool) preg_match('/^\d+$/', $item);
                    }
                )
            )
        );
    }

    protected function getEmails(string $key): array
    {
        return array_map(
            static function ($email) {
                return ['value' => $email];
            },
            $this->getList($key)
        );
    }

    protected function getPhones(string $key): array
    {
        return array_map(
            static function ($phone) {
                return ['value' => $phone];
            },
            $this->getList($key)
        );
    }

    protected function getAddresses(): array
    {
        $address = $this->removeEmptyValues(
            [
                'street'  => $this->getString('street'),
                'city'    => $this->getString('city'),
                'state'   => $this->getString('state'),
                'code'    => $this->getString('code'),
                'country' => $this->getString('country'),
            ]
        );

        return empty($address) ? [] : [$address];
    }

    protected function getCustomFieldValues(): array
    {
        $values = [];

        foreach ($this->fields as $key => $value) {
            if (preg_match('/^custom[A-Z0-9]/', (string) $key) && \is_scalar($value) && trim((string) $value) !== '') {
                $values[$key] = trim((string) $value);
            }
        }

        return $values;
    }

    private function formatQuery(array $query): array
    {
        return array_map(
            static function ($value) {
                if (\is_bool($value)) {
                    return $value ? 'true' : 'false';
                }

                return \is_array($value) ? implode(',', $value) : $value;
            },
            $query
        );
    }

    private function decodeBody($body)
    {
        if (\is_string($body)) {
            $decoded = json_decode($body, true);

            return json_last_error() === JSON_ERROR_NONE ? $decoded : $body;
        }

        return json_decode((string) wp_json_encode($body), true);
    }

    private function isEmptyBody($body): bool
    {
        if (\is_string($body)) {
            return \in_array(trim($body), ['', '[]', '{}'], true);
        }

        return $body === null || $body === [];
    }

    private function extractErrorMessage(?string $transportError, $responseBody): string
    {
        if (\is_array($responseBody) && \is_string($responseBody['errorMessage'] ?? null) && $responseBody['errorMessage'] !== '') {
            return $responseBody['errorMessage'];
        }

        if (\is_string($transportError) && $transportError !== '') {
            return $transportError;
        }

        return __('Follow Up Boss did not complete the request. Check the field values and try again.', 'bit-integrations-pro');
    }
}
