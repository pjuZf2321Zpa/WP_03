<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Actions\FluentCart\FluentCartProHelper;
use BitApps\IntegrationsPro\Config;
use BitApps\IntegrationsPro\Core\Util\Hooks;

// Deprecated since v2.7.8 - use bit_integrations_fluentcart_* hooks instead
if (bit_integrations_version_below('2.7.8')) {
    Hooks::filter('btcbi_fluentcart_create_order', [FluentCartProHelper::class, 'createOrder'], 10, 4);
    Hooks::filter('btcbi_fluentcart_delete_order', [FluentCartProHelper::class, 'deleteOrder'], 10, 2);
    Hooks::filter('btcbi_fluentcart_update_order_status', [FluentCartProHelper::class, 'updateOrderStatus'], 10, 2);
    Hooks::filter('btcbi_fluentcart_update_payment_status', [FluentCartProHelper::class, 'updatePaymentStatus'], 10, 2);
    Hooks::filter('btcbi_fluentcart_update_shipping_status', [FluentCartProHelper::class, 'updateShippingStatus'], 10, 2);
    Hooks::filter('btcbi_fluentcart_create_customer', [FluentCartProHelper::class, 'createCustomer'], 10, 2);
    Hooks::filter('btcbi_fluentcart_update_customer', [FluentCartProHelper::class, 'updateCustomer'], 10, 2);
    Hooks::filter('btcbi_fluentcart_delete_customer', [FluentCartProHelper::class, 'deleteCustomer'], 10, 2);
    Hooks::filter('btcbi_fluentcart_create_product', [FluentCartProHelper::class, 'createProduct'], 10, 4);
    Hooks::filter('btcbi_fluentcart_delete_product', [FluentCartProHelper::class, 'deleteProduct'], 10, 2);
    Hooks::filter('btcbi_fluentcart_create_coupon', [FluentCartProHelper::class, 'createCoupon'], 10, 3);
    Hooks::filter('btcbi_fluentcart_delete_coupon', [FluentCartProHelper::class, 'deleteCoupon'], 10, 2);
}

// New hooks since v2.7.8
Hooks::filter(Config::withFreePrefix('fluentcart_create_order'), [FluentCartProHelper::class, 'createOrder'], 10, 4);
Hooks::filter(Config::withFreePrefix('fluentcart_delete_order'), [FluentCartProHelper::class, 'deleteOrder'], 10, 2);
Hooks::filter(Config::withFreePrefix('fluentcart_update_order_status'), [FluentCartProHelper::class, 'updateOrderStatus'], 10, 2);
Hooks::filter(Config::withFreePrefix('fluentcart_update_payment_status'), [FluentCartProHelper::class, 'updatePaymentStatus'], 10, 2);
Hooks::filter(Config::withFreePrefix('fluentcart_update_shipping_status'), [FluentCartProHelper::class, 'updateShippingStatus'], 10, 2);
Hooks::filter(Config::withFreePrefix('fluentcart_create_customer'), [FluentCartProHelper::class, 'createCustomer'], 10, 2);
Hooks::filter(Config::withFreePrefix('fluentcart_update_customer'), [FluentCartProHelper::class, 'updateCustomer'], 10, 2);
Hooks::filter(Config::withFreePrefix('fluentcart_delete_customer'), [FluentCartProHelper::class, 'deleteCustomer'], 10, 2);
Hooks::filter(Config::withFreePrefix('fluentcart_create_product'), [FluentCartProHelper::class, 'createProduct'], 10, 4);
Hooks::filter(Config::withFreePrefix('fluentcart_delete_product'), [FluentCartProHelper::class, 'deleteProduct'], 10, 2);
Hooks::filter(Config::withFreePrefix('fluentcart_create_coupon'), [FluentCartProHelper::class, 'createCoupon'], 10, 3);
Hooks::filter(Config::withFreePrefix('fluentcart_delete_coupon'), [FluentCartProHelper::class, 'deleteCoupon'], 10, 2);
