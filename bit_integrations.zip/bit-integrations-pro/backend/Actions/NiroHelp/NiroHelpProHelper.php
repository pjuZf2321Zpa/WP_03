<?php

namespace BitApps\IntegrationsPro\Actions\NiroHelp;

use BitApps\IntegrationsPro\Actions\NiroHelp\Services\AgentService;
use BitApps\IntegrationsPro\Actions\NiroHelp\Services\CustomerService;
use BitApps\IntegrationsPro\Actions\NiroHelp\Services\DocService;
use BitApps\IntegrationsPro\Actions\NiroHelp\Services\FollowUpService;
use BitApps\IntegrationsPro\Actions\NiroHelp\Services\ReplyService;
use BitApps\IntegrationsPro\Actions\NiroHelp\Services\TaxonomyService;
use BitApps\IntegrationsPro\Actions\NiroHelp\Services\TicketService;

if (!\defined('ABSPATH')) {
    exit;
}

final class NiroHelpProHelper
{
    public static function createTicket($response, $fieldData, $settings = [])
    {
        return self::runService(TicketService::class, 'createTicket', $fieldData, $settings);
    }

    public static function updateTicket($response, $fieldData, $settings = [])
    {
        return self::runService(TicketService::class, 'updateTicket', $fieldData, $settings);
    }

    public static function changeTicketStatus($response, $fieldData, $settings = [])
    {
        return self::runService(TicketService::class, 'changeTicketStatus', $fieldData, $settings);
    }

    public static function assignAgent($response, $fieldData, $settings = [])
    {
        return self::runService(TicketService::class, 'assignAgent', $fieldData, $settings);
    }

    public static function setSentiment($response, $fieldData, $settings = [])
    {
        return self::runService(TicketService::class, 'setSentiment', $fieldData, $settings);
    }

    public static function deleteTicket($response, $fieldData)
    {
        return self::runService(TicketService::class, 'deleteTicket', $fieldData);
    }

    public static function addReply($response, $fieldData, $settings = [])
    {
        return self::runService(ReplyService::class, 'addReply', $fieldData, $settings);
    }

    public static function addPrivateNote($response, $fieldData, $settings = [])
    {
        return self::runService(ReplyService::class, 'addPrivateNote', $fieldData, $settings);
    }

    public static function setFollowUp($response, $fieldData, $settings = [])
    {
        return self::runService(FollowUpService::class, 'setFollowUp', $fieldData, $settings);
    }

    public static function clearFollowUp($response, $fieldData)
    {
        return self::runService(FollowUpService::class, 'clearFollowUp', $fieldData);
    }

    public static function createDoc($response, $fieldData, $settings = [])
    {
        return self::runService(DocService::class, 'createDoc', $fieldData, $settings);
    }

    public static function updateDoc($response, $fieldData, $settings = [])
    {
        return self::runService(DocService::class, 'updateDoc', $fieldData, $settings);
    }

    public static function trashDoc($response, $fieldData)
    {
        return self::runService(DocService::class, 'trashDoc', $fieldData);
    }

    public static function deleteDoc($response, $fieldData)
    {
        return self::runService(DocService::class, 'deleteDoc', $fieldData);
    }

    public static function createProduct($response, $fieldData)
    {
        return self::runService(TaxonomyService::class, 'createProduct', $fieldData);
    }

    public static function createReason($response, $fieldData)
    {
        return self::runService(TaxonomyService::class, 'createReason', $fieldData);
    }

    public static function createTopic($response, $fieldData, $settings = [])
    {
        return self::runService(TaxonomyService::class, 'createTopic', $fieldData, $settings);
    }

    public static function createCustomer($response, $fieldData)
    {
        return self::runService(CustomerService::class, 'createCustomer', $fieldData);
    }

    public static function addAgent($response, $fieldData)
    {
        return self::runService(AgentService::class, 'addAgent', $fieldData);
    }

    private static function runService(string $serviceClass, string $method, $fieldData, $settings = [])
    {
        if (!NiroHelpHelper::isPluginActive()) {
            return self::pluginInactiveResponse();
        }

        $service = new $serviceClass($fieldData, $settings);

        return $service->validateIntegerFields() ?? $service->{$method}();
    }

    private static function pluginInactiveResponse()
    {
        return [
            'success' => false,
            'message' => __('NiroHelp is not active. Activate the NiroHelp plugin.', 'bit-integrations-pro'),
        ];
    }
}
