<?php
/**
 * V2 RSVP Controller for Event Tickets Plus.
 *
 * @since 6.11.0
 *
 * @package TEC\Tickets_Plus\RSVP\V2
 */

namespace TEC\Tickets_Plus\RSVP\V2;

use TEC\Common\Contracts\Provider\Controller as Controller_Contract;
use TEC\Tickets_Plus\RSVP\V2\REST\Ticket_Meta_Endpoint;
use Tribe\Tickets\Plus\Attendee_Registration\IAC;

/**
 * Class Controller
 *
 * Handles Event Tickets Plus specific RSVP V2 functionality.
 * Extends the base Tickets Commerce infrastructure used by V2 RSVP.
 *
 * @since 6.11.0
 *
 * @package TEC\Tickets_Plus\RSVP\V2
 */
class Controller extends Controller_Contract {
	/**
	 * The action that will be fired after the successful registration of this controller.
	 *
	 * @since 6.11.0
	 *
	 * @var string
	 */
	public static string $registration_action = 'tec_tickets_plus_rsvp_v2_registered';

	/**
	 * Register the controller.
	 *
	 * @since 6.11.0
	 *
	 * @return void
	 */
	protected function do_register(): void {
		// Register singletons.
		$this->container->singleton( Template::class );
		$this->container->singleton( Assets::class );
		$this->container->singleton( Metabox::class );
		$this->container->singleton( Meta_Fields::class );
		$this->container->singleton( REST_Properties::class );
		$this->container->singleton( Frontend::class );
		$this->container->singleton( Attendees_List::class );
		$this->container->singleton( REST\Ticket_Meta_Endpoint::class );

		// Register assets.
		$this->container->get( Assets::class )->register();

		// REST API.
		add_action( 'rest_api_init', $this->container->callback( Ticket_Meta_Endpoint::class, 'register' ) );

		// Admin Metabox.
		add_action(
			'tribe_template_before_include:tickets/admin-views/editor/rsvp/metabox',
			$this->container->callback( Metabox::class, 'print_dialog_append_target' )
		);
		add_action(
			'tec_event_tickets_rsvp_metabox_edit_main',
			$this->container->callback( Metabox::class, 'add_iac' ),
			10,
			2
		);
		add_action(
			'tec_event_tickets_rsvp_post_options',
			$this->container->callback( Metabox::class, 'add_show_attendees' ),
			15,
			2
		);
		add_action(
			'tec_event_tickets_rsvp_post_options',
			$this->container->callback( Metabox::class, 'add_waitlist_options' ),
			20,
			2
		);

		// Meta Fields.
		add_action(
			'tec_tickets_rsvp_after_meta_update',
			$this->container->callback( Meta_Fields::class, 'save_meta_only_fields' ),
			10,
			3
		);
		add_filter(
			'tribe_tickets_has_meta_enabled',
			$this->container->callback( Meta_Fields::class, 'filter_has_meta_enabled' ),
			10,
			2
		);

		// RSVP Fields persistence.
		add_action(
			'tec_tickets_ticket_upserted',
			$this->container->callback( Meta_Fields::class, 'save_rsvp_fields' ),
			10,
			4
		);

		// RSVP Fields cleanup on ticket removal.
		add_action(
			'tec_tickets_commerce_ticket_deleted',
			$this->container->callback( Meta_Fields::class, 'cleanup_rsvp_fields_on_commerce_ticket_deleted' ),
			10,
			3
		);
		add_action(
			'wp_trash_post',
			$this->container->callback( Meta_Fields::class, 'cleanup_rsvp_fields_on_ticket_trash' )
		);
		add_action(
			'before_delete_post',
			$this->container->callback( Meta_Fields::class, 'cleanup_rsvp_fields_on_ticket_delete' )
		);

		// REST API field documentation and parameter forwarding.
		add_filter(
			'tec_tickets_build_ticket_properties',
			$this->container->callback( REST_Properties::class, 'add_iac_to_properties' ),
			10,
			2
		);
		add_filter(
			'tec_tickets_build_ticket_properties',
			$this->container->callback( REST_Properties::class, 'add_show_attendees_to_properties' ),
			10,
			2
		);
		add_filter(
			'tec_rest_ticket_properties_to_add',
			$this->container->callback( REST_Properties::class, 'add_show_attendees_to_rest_properties' )
		);
		add_filter(
			'tec_rest_swagger_ticket_request_body_definition',
			$this->container->callback( REST_Properties::class, 'add_fields_to_request_body_docs' )
		);
		add_filter(
			'tec_tickets_rest_ticket_upsert_params',
			$this->container->callback( REST_Properties::class, 'add_fields_to_upsert_params' ),
			10,
			2
		);
		add_filter(
			'tec_tickets_rsvp_v2_classic_save_data',
			$this->container->callback( REST_Properties::class, 'add_fields_to_classic_save_data' ),
			10,
			3
		);

		// Frontend: entry point for main guest ARF fields.
		add_action(
			'tribe_template_entry_point:tickets/v2/commerce/rsvp/ari/form/fields/meta:rsvp_attendee_fields',
			$this->container->callback( Frontend::class, 'render_main_guest_fields' ),
			10,
			3
		);

		// Frontend: entry point for clone template ARF fields.
		add_action(
			'tribe_template_entry_point:tickets/v2/commerce/rsvp/ari/form/template/fields:rsvp_attendee_fields_template',
			$this->container->callback( Frontend::class, 'render_clone_template_fields' ),
			10,
			3
		);

		// Frontend: step args filter.
		add_filter(
			'tec_tickets_rsvp_v2_render_step_template_args_pre_process',
			$this->container->callback( Frontend::class, 'filter_step_args' ),
			10,
			2
		);

		// Frontend: per-attendee data injection into cart.
		add_filter(
			'tec_tickets_rsvp_v2_cart_upsert_item_args',
			$this->container->callback( Frontend::class, 'filter_cart_upsert_item_args' ),
			10,
			5
		);

		// Attendees List.
		add_filter(
			'tec_tickets_rsvp_v2_show_attendees_list_optout',
			$this->container->callback( Attendees_List::class, 'filter_show_optout' ),
			10,
			3
		);
		add_filter(
			'tribe_tickets_plus_hide_attendees_list',
			$this->container->callback( Attendees_List::class, 'filter_visibility' ),
			10,
			2
		);
		// Gates the "Your RSVPs" list and public opt-in toggle on the RSVP V2 success view.
		add_filter(
			'tec_tickets_rsvp_show_attendees_list',
			$this->container->callback( Attendees_List::class, 'filter_show_optout' ),
			10,
			3
		);

		// Inject attendee info fields into the server-preloaded initial ticket.
		add_filter(
			'tec_tickets_rsvp_v2_initial_ticket',
			[ $this, 'add_attendee_info_to_initial_ticket' ],
			10,
			3
		);
		// Block editor: inject IAC options into the attendee registration iframe page.
		add_action(
			'tec_tickets_attendee_registration_before_meta_form_fields',
			$this->container->callback( Metabox::class, 'render_iac_in_attendee_registration' ),
			10,
			2
		);
		add_action(
			'tec_tickets_attendee_registration_after_save',
			$this->container->callback( Metabox::class, 'save_iac_from_attendee_registration' ),
			10,
			3
		);
	}

	/**
	 * Unregisters the controller.
	 *
	 * @since 6.11.0
	 *
	 * @return void
	 */
	public function unregister(): void {
		// REST API.
		remove_action( 'rest_api_init', $this->container->callback( Ticket_Meta_Endpoint::class, 'register' ) );

		// Admin Metabox.
		remove_action(
			'tribe_template_before_include:tickets/admin-views/editor/rsvp/metabox',
			$this->container->callback( Metabox::class, 'print_dialog_append_target' )
		);
		remove_action(
			'tec_event_tickets_rsvp_metabox_edit_main',
			$this->container->callback( Metabox::class, 'add_iac' ),
			10
		);
		remove_action(
			'tec_event_tickets_rsvp_post_options',
			$this->container->callback( Metabox::class, 'add_show_attendees' ),
			15
		);
		remove_action(
			'tec_event_tickets_rsvp_post_options',
			$this->container->callback( Metabox::class, 'add_waitlist_options' ),
			20
		);

		// Meta Fields.
		remove_action(
			'tec_tickets_rsvp_after_meta_update',
			$this->container->callback( Meta_Fields::class, 'save_meta_only_fields' ),
			10
		);
		remove_filter(
			'tribe_tickets_has_meta_enabled',
			$this->container->callback( Meta_Fields::class, 'filter_has_meta_enabled' ),
			10
		);

		// RSVP Fields persistence.
		remove_action(
			'tec_tickets_ticket_upserted',
			$this->container->callback( Meta_Fields::class, 'save_rsvp_fields' ),
			10
		);

		// RSVP Fields cleanup on ticket removal.
		remove_action(
			'tec_tickets_commerce_ticket_deleted',
			$this->container->callback( Meta_Fields::class, 'cleanup_rsvp_fields_on_commerce_ticket_deleted' ),
			10
		);
		remove_action(
			'wp_trash_post',
			$this->container->callback( Meta_Fields::class, 'cleanup_rsvp_fields_on_ticket_trash' )
		);
		remove_action(
			'before_delete_post',
			$this->container->callback( Meta_Fields::class, 'cleanup_rsvp_fields_on_ticket_delete' )
		);

		// REST API field documentation and parameter forwarding.
		remove_filter(
			'tec_tickets_build_ticket_properties',
			$this->container->callback( REST_Properties::class, 'add_iac_to_properties' ),
			10
		);
		remove_filter(
			'tec_tickets_build_ticket_properties',
			$this->container->callback( REST_Properties::class, 'add_show_attendees_to_properties' ),
			10
		);
		remove_filter(
			'tec_rest_ticket_properties_to_add',
			$this->container->callback( REST_Properties::class, 'add_show_attendees_to_rest_properties' )
		);
		remove_filter(
			'tec_rest_swagger_ticket_request_body_definition',
			$this->container->callback( REST_Properties::class, 'add_fields_to_request_body_docs' )
		);
		remove_filter(
			'tec_tickets_rest_ticket_upsert_params',
			$this->container->callback( REST_Properties::class, 'add_fields_to_upsert_params' ),
			10
		);
		remove_filter(
			'tec_tickets_rsvp_v2_classic_save_data',
			$this->container->callback( REST_Properties::class, 'add_fields_to_classic_save_data' ),
			10
		);

		// Frontend.
		remove_action(
			'tribe_template_entry_point:tickets/v2/commerce/rsvp/ari/form/fields/meta:rsvp_attendee_fields',
			$this->container->callback( Frontend::class, 'render_main_guest_fields' ),
			10
		);
		remove_action(
			'tribe_template_entry_point:tickets/v2/commerce/rsvp/ari/form/template/fields:rsvp_attendee_fields_template',
			$this->container->callback( Frontend::class, 'render_clone_template_fields' ),
			10
		);
		remove_filter(
			'tec_tickets_rsvp_v2_render_step_template_args_pre_process',
			$this->container->callback( Frontend::class, 'filter_step_args' ),
			10
		);
		remove_filter(
			'tec_tickets_rsvp_v2_cart_upsert_item_args',
			$this->container->callback( Frontend::class, 'filter_cart_upsert_item_args' ),
			10
		);

		// Attendees List.
		remove_filter(
			'tec_tickets_rsvp_v2_show_attendees_list_optout',
			$this->container->callback( Attendees_List::class, 'filter_show_optout' ),
			10
		);
		remove_filter(
			'tribe_tickets_plus_hide_attendees_list',
			$this->container->callback( Attendees_List::class, 'filter_visibility' ),
			10
		);
		remove_filter(
			'tec_tickets_rsvp_show_attendees_list',
			$this->container->callback( Attendees_List::class, 'filter_show_optout' ),
			10
		);

		// Inject attendee info fields into the server-preloaded initial ticket.
		remove_filter(
			'tec_tickets_rsvp_v2_initial_ticket',
			[ $this, 'add_attendee_info_to_initial_ticket' ],
			10
		);

		// Block editor: IAC options in attendee registration iframe.
		remove_action(
			'tec_tickets_attendee_registration_before_meta_form_fields',
			$this->container->callback( Metabox::class, 'render_iac_in_attendee_registration' ),
			10
		);
		remove_action(
			'tec_tickets_attendee_registration_after_save',
			$this->container->callback( Metabox::class, 'save_iac_from_attendee_registration' ),
			10
		);
	}

	/**
	 * Adds attendee information fields to the server-preloaded initial ticket data.
	 *
	 * Ensures the RSVP block shows the correct "Fields configured" status and field
	 * labels on first paint without waiting for an async REST call.
	 *
	 * @since 6.11.0
	 *
	 * @param array<string,mixed> $initial_ticket The formatted ticket entity.
	 * @param int                 $post_id        The current post ID.
	 * @param int                 $ticket_id      The ticket post ID.
	 *
	 * @return array<string,mixed> The modified ticket entity.
	 */
	public function add_attendee_info_to_initial_ticket( array $initial_ticket, int $post_id, int $ticket_id ): array {
		if ( ! $ticket_id ) {
			return $initial_ticket;
		}

		/** @var IAC $iac */
		$iac         = tribe( 'tickets-plus.attendee-registration.iac' );
		$iac_setting = $iac->get_iac_setting_for_ticket( $ticket_id );

		/** @var \Tribe__Tickets_Plus__Meta $meta */
		$meta        = tribe( 'tickets-plus.meta' );
		$meta_fields = $meta->get_meta_fields_by_ticket( $ticket_id );
		$iac_active  = IAC::NONE_KEY !== $iac_setting;

		$initial_ticket['has_attendee_info_fields'] = $iac_active || ! empty( $meta_fields );
		$labels                                     = [];

		if ( $iac_active ) {
			$labels[]                       = __( 'Name', 'event-tickets-plus' );
			$labels[]                       = __( 'Email', 'event-tickets-plus' );
			$initial_ticket['field_labels'] = $labels;
		}

		if ( empty( $meta_fields ) ) {
			return $initial_ticket;
		}

		if ( ! empty( $meta_fields ) ) {
			foreach ( $meta_fields as $field ) {
				if ( ! empty( $field->label ) ) {
					$labels[] = $field->label;
				}
			}
		}

			$initial_ticket['field_labels'] = $labels;

			return $initial_ticket;
	}
}
