<?php

namespace FluentBookingPro\App\Services\Captcha;

use FluentBooking\Framework\Support\Arr;

class CaptchaManager
{
    const OPTION_KEY = 'fluent_booking_spam_protection';

    /**
     * Holds the last setup error (a refused secret key) for the admin notice.
     */
    const ERROR_OPTION_KEY = 'fluent_booking_captcha_setup_error';

    const UNREACHABLE_LOG_KEY = 'fluent_booking_captcha_unreachable_logged';

    private static $providers = null;

    /**
     * @return AbstractCaptchaProvider[]
     */
    public static function getProviders()
    {
        if (self::$providers !== null) {
            return self::$providers;
        }

        /**
         * The captcha providers the settings page offers.
         *
         * @param array $providers
         */
        $registered = apply_filters('fluent_booking/captcha_providers', [
            'recaptcha' => new RecaptchaProvider(),
            'turnstile' => new TurnstileProvider(),
        ]);

        $providers = [];

        foreach ($registered as $provider) {
            if ($provider instanceof AbstractCaptchaProvider) {
                $providers[$provider->getKey()] = $provider;
            }
        }

        return self::$providers = $providers;
    }

    /**
     * @param string $key
     * @return AbstractCaptchaProvider|null
     */
    public static function getProvider($key)
    {
        $providers = self::getProviders();

        return isset($providers[$key]) ? $providers[$key] : null;
    }

    /**
     * @return array
     */
    public static function getSettings()
    {
        $stored = get_option(self::OPTION_KEY, []);

        if (!is_array($stored)) {
            $stored = [];
        }

        $providerSettings = [];

        foreach (self::getProviders() as $key => $provider) {
            $providerSettings[$key] = wp_parse_args(
                (array)Arr::get($stored, 'providers.' . $key, []),
                $provider->getDefaults()
            );
        }

        return [
            'enabled'        => Arr::get($stored, 'enabled') === 'yes' ? 'yes' : 'no',
            'provider'       => self::resolveProviderKey(Arr::get($stored, 'provider')),
            'skip_logged_in' => Arr::get($stored, 'skip_logged_in') === 'yes' ? 'yes' : 'no',
            'providers'      => $providerSettings,
        ];
    }

    /**
     * The settings as the admin UI may see them: no secret ever leaves the server.
     *
     * @return array
     */
    public static function getDisplaySettings()
    {
        $settings  = self::getSettings();
        $providers = self::getProviders();

        foreach ((array)Arr::get($settings, 'providers', []) as $key => $providerSettings) {
            if (isset($providers[$key])) {
                $settings['providers'][$key] = $providers[$key]->maskSecrets($providerSettings);
            }
        }

        return $settings;
    }

    /**
     * @param array $input
     * @return array
     */
    public static function save($input)
    {
        if (!is_array($input)) {
            $input = [];
        }

        $cleanProviders = [];

        foreach (self::getProviders() as $key => $provider) {
            $cleanProviders[$key] = $provider->sanitize(
                (array)Arr::get($input, 'providers.' . $key, []),
                self::storedProviderSettings($key)
            );
        }

        // A payload that leaves a key out keeps what is stored, so a partial
        // save cannot switch the feature off or lose a provider block.
        $stored = self::getSettings();

        $clean = [
            'enabled'        => self::resolveFlag(Arr::get($input, 'enabled'), $stored['enabled']),
            'provider'       => self::resolveProviderKey(Arr::get($input, 'provider', $stored['provider'])),
            'skip_logged_in' => self::resolveFlag(Arr::get($input, 'skip_logged_in'), $stored['skip_logged_in']),
            'providers'      => $cleanProviders,
        ];

        update_option(self::OPTION_KEY, $clean, false);

        // The keys may have been corrected, so drop a stale setup error.
        delete_option(self::ERROR_OPTION_KEY);

        return self::getDisplaySettings();
    }

    /**
     * On when the feature is enabled and the selected provider has its keys.
     *
     * @return bool
     */
    public static function isEnabled()
    {
        $settings = self::getSettings();

        if (Arr::get($settings, 'enabled') !== 'yes') {
            return false;
        }

        $provider = self::getProvider($settings['provider']);

        return $provider && $provider->isConfigured(self::activeSettings($settings));
    }

    /**
     * What the public booking app needs to render the widget.
     *
     * @return array
     */
    public static function publicVars()
    {
        if (!self::isEnabled()) {
            return [];
        }

        $settings = self::getSettings();
        $provider = self::getProvider($settings['provider']);

        if (self::skipsCurrentUser()) {
            return [];
        }

        return array_merge($provider->publicVars(self::activeSettings($settings)), [
            'enabled' => true,
        ]);
    }

    /**
     * True when the current request does not need a captcha.
     *
     * @param mixed $calendarEvent
     * @param array $postedData
     * @return bool
     */
    public static function skipsCurrentUser($calendarEvent = null, $postedData = [])
    {
        $settings = self::getSettings();

        $skip = Arr::get($settings, 'skip_logged_in') === 'yes' && is_user_logged_in();

        /**
         * Whether to skip the captcha check for this request.
         *
         * @param bool  $skip
         * @param mixed $calendarEvent
         * @param array $postedData
         */
        return (bool)apply_filters('fluent_booking/skip_captcha', $skip, $calendarEvent, $postedData);
    }

    /**
     * Verify the token in a public booking request.
     *
     * @param array $postedData
     * @param mixed $calendarEvent
     * @return \WP_Error|null A WP_Error rejects the request; null lets it through.
     */
    public static function verifyRequest($postedData, $calendarEvent = null)
    {
        if (!self::isEnabled() || self::skipsCurrentUser($calendarEvent, $postedData)) {
            return null;
        }

        $settings = self::getSettings();
        $provider = self::getProvider($settings['provider']);

        $tokenField = Arr::get($provider->publicVars(self::activeSettings($settings)), 'token_field');
        $token      = sanitize_text_field(Arr::get($postedData, $tokenField, ''));

        // A bot can leave the token out, but a bot cannot make our own call to
        // the provider fail. A missing token is a rejection, never an outage.
        if (!$token) {
            return new \WP_Error(
                'captcha_missing',
                __('The security check did not load. Refresh the page, or turn off your ad blocker, and try again.', 'fluent-booking-pro')
            );
        }

        $result = $provider->verify(self::activeSettings($settings), $token);
        $status = Arr::get($result, 'status');

        if ($status === 'valid') {
            return null;
        }

        if ($status === 'unreachable') {
            self::handleUnreachable($result, $provider);

            // Fail open: an outage or a wrong key must not block every booking.
            return null;
        }

        if (Arr::get($result, 'code') === 'captcha_expired') {
            return new \WP_Error(
                'captcha_expired',
                __('The security check expired. Please try again.', 'fluent-booking-pro')
            );
        }

        return new \WP_Error(
            'captcha_failed',
            __('The security check failed. Please try again.', 'fluent-booking-pro')
        );
    }

    /**
     * @param string $providerKey
     * @param array  $input
     * @param string $token
     * @return array
     */
    public static function validateCredentials($providerKey, $input, $token)
    {
        $provider = self::getProvider($providerKey);

        if (!$provider) {
            return [
                'valid'   => false,
                'message' => __('Unknown captcha provider.', 'fluent-booking-pro'),
            ];
        }

        $settings = $provider->sanitize((array)$input, self::storedProviderSettings($providerKey));

        return $provider->validateCredentials($settings, $token);
    }

    /**
     * The setup error the admin notice shows, if any.
     *
     * @return array
     */
    public static function getSetupError()
    {
        $error = get_option(self::ERROR_OPTION_KEY, []);

        return is_array($error) ? $error : [];
    }

    public static function clearSetupError()
    {
        delete_option(self::ERROR_OPTION_KEY);
    }

    /**
     * @param array                   $result
     * @param AbstractCaptchaProvider $provider
     */
    private static function handleUnreachable($result, $provider)
    {
        $reason = (string)Arr::get($result, 'reason', '');

        if (Arr::get($result, 'code') === 'invalid_secret') {
            update_option(self::ERROR_OPTION_KEY, [
                'provider' => $provider->getTitle(),
                'message'  => $reason,
                'time'     => gmdate('Y-m-d H:i:s'),
            ], false);
        }

        // One entry per outage window, not one per booking attempt: a bot
        // storm must not fill the log.
        if (get_transient(self::UNREACHABLE_LOG_KEY)) {
            return;
        }

        set_transient(self::UNREACHABLE_LOG_KEY, 1, 10 * MINUTE_IN_SECONDS);

        error_log(sprintf( // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- one entry per 10-minute outage window
            'FluentBooking spam protection: %s could not verify a booking (%s). Bookings are accepted until it answers again.',
            $provider->getTitle(),
            $reason
        ));
    }

    /**
     * @param array $settings
     * @return array
     */
    private static function activeSettings($settings)
    {
        return (array)Arr::get($settings, 'providers.' . Arr::get($settings, 'provider'), []);
    }

    /**
     * @param string $key
     * @return array
     */
    private static function storedProviderSettings($key)
    {
        $stored = get_option(self::OPTION_KEY, []);

        return (array)Arr::get(is_array($stored) ? $stored : [], 'providers.' . $key, []);
    }

    /**
     * @param mixed  $value
     * @param string $stored
     * @return string
     */
    private static function resolveFlag($value, $stored)
    {
        if ($value === null) {
            return $stored === 'yes' ? 'yes' : 'no';
        }

        return $value === 'yes' ? 'yes' : 'no';
    }

    /**
     * @param string $key
     * @return string
     */
    private static function resolveProviderKey($key)
    {
        $providers = self::getProviders();

        if (isset($providers[$key])) {
            return $key;
        }

        $keys = array_keys($providers);

        return $keys ? $keys[0] : 'recaptcha';
    }
}
