<?php

namespace FluentCartPro\App\Hooks\Handlers\BlockEditors\PdfBlocks;

use FluentCart\App\Helpers\Helper;
use FluentCart\App\Hooks\Handlers\BlockEditors\BlockEditor;

class ReceiptItemTableBlockEditor extends BlockEditor
{
    use \FluentCartPro\App\Contracts\CanEnqueue;

    protected static string $editorName = 'receipt-item-table';

    /** FIFO queue of per-render attribute sets, drained by the resolver in document order. */
    private static array $pendingRenders = [];

    /** Single-firing flag so the smartcode_fallback filter is registered once per request. */
    private static bool $filterRegistered = false;

    public function getScripts(): array
    {
        return [
            [
                'source'       => 'admin/BlockEditor/PdfBlocks/ReceiptItemTableBlockEditor.jsx',
                'dependencies' => ['wp-blocks', 'wp-components', 'wp-block-editor']
            ]
        ];
    }

    public function getStyles(): array
    {
        return [];
    }

    public function localizeData(): array
    {
        return [
            $this->getLocalizationKey() => [
                'slug'        => $this->slugPrefix,
                'name'        => static::getEditorName(),
                'title'       => __('Receipt Item Table', 'fluent-cart-pro'),
                'description' => __('Order items table for PDF receipts.', 'fluent-cart-pro'),
            ],
            'fluent_cart_block_translation' => \FluentCart\App\Services\Translations\TransStrings::blockStrings(),
        ];
    }

    public function blockAttributes(): array
    {
        return [
            'headerBg'    => ['type' => 'string', 'default' => '#375DFB'],
            'headerColor' => ['type' => 'string', 'default' => '#FFFFFF'],
            'bodyColor'   => ['type' => 'string', 'default' => '#0E121B'],
            'borderColor' => ['type' => 'string', 'default' => '#E1E4EA'],
            'fontSize'    => ['type' => 'number', 'default' => 11],
            'itemLabel'   => ['type' => 'string', 'default' => 'Item'],
            'qtyLabel'    => ['type' => 'string', 'default' => 'Qty'],
            'totalLabel'  => ['type' => 'string', 'default' => 'Total'],
        ];
    }

    public function supports(): array
    {
        return [
            'html'    => false,
            'align'   => false,
            'spacing' => ['margin' => true, 'padding' => true],
        ];
    }

    public function render(array $attrs, $block = null, $content = ''): string
    {
        // Queue this block's attributes for the resolver. Each render() pushes
        // one entry; resolveItemTablePlaceholder() shifts one entry per
        // {{order.pdf_items_table}} occurrence. parseBlocksToHtml() and
        // ShortcodeTemplateBuilder::make() both walk the document linearly,
        // so FIFO order = document order = correct attribute mapping.
        self::$pendingRenders[] = [
            'headerBg'    => esc_attr($attrs['headerBg']    ?? '#375DFB'),
            'headerColor' => esc_attr($attrs['headerColor'] ?? '#FFFFFF'),
            'bodyColor'   => esc_attr($attrs['bodyColor']   ?? '#0E121B'),
            'borderColor' => esc_attr($attrs['borderColor'] ?? '#E1E4EA'),
            'fontSize'    => (int)  ($attrs['fontSize']     ?? 11),
            'itemLabel'   => esc_html($attrs['itemLabel']   ?? 'Item'),
            'qtyLabel'    => esc_html($attrs['qtyLabel']    ?? 'Qty'),
            'totalLabel'  => esc_html($attrs['totalLabel']  ?? 'Total'),
        ];

        if (!self::$filterRegistered) {
            add_filter('fluent_cart/smartcode_fallback', [self::class, 'resolveItemTablePlaceholder'], 10, 2);
            self::$filterRegistered = true;
        }

        return '{{order.pdf_items_table}}';
    }

    /**
     * Resolves {{order.pdf_items_table}} by consuming the next queued attribute
     * set. Single named callback registered once per request — no anonymous
     * closures accumulating across block instances.
     *
     * @param string $code Smartcode being resolved (or value passed by an upstream filter).
     * @param array  $data Smartcode data array containing the order under 'order'.
     * @return string Rendered table HTML, or the input $code unchanged when not ours.
     */
    public static function resolveItemTablePlaceholder($code, $data)
    {
        if ($code !== 'order.pdf_items_table') {
            return $code;
        }

        $attrs = array_shift(self::$pendingRenders);
        if ($attrs === null) {
            return '';
        }

        $order = $data['order'] ?? null;
        if (!$order) {
            return '';
        }

        return self::buildPdfItemsTable(
            $order,
            $attrs['headerBg'],
            $attrs['headerColor'],
            $attrs['bodyColor'],
            $attrs['borderColor'],
            $attrs['fontSize'],
            $attrs['itemLabel'],
            $attrs['qtyLabel'],
            $attrs['totalLabel']
        );
    }

    private static function buildPdfItemsTable(
        $order,
        string $headerBg,
        string $headerColor,
        string $bodyColor,
        string $borderColor,
        int    $fontSize,
        string $itemLabel,
        string $qtyLabel,
        string $totalLabel
    ): string {
        $nameSize    = $fontSize + 1;
        $variantSize = max(9, $fontSize - 1);

        $thStyle = 'padding:10px 12px;font-size:' . $fontSize . 'px;'
                 . 'background:' . $headerBg . ';color:' . $headerColor . ';'
                 . 'font-weight:600;text-transform:uppercase;letter-spacing:0.05em;'
                 . 'border-bottom:2px solid ' . $borderColor . ';';

        $tdStyle = 'padding:12px;font-size:' . $fontSize . 'px;'
                 . 'color:' . $bodyColor . ';border-bottom:1px solid ' . $borderColor . ';'
                 . 'vertical-align:middle;';

        $html = '<table width="100%" cellspacing="0" cellpadding="0" border="0"'
              . ' style="margin:8px 0 16px;border-collapse:collapse;">'
              . '<thead><tr>'
              . '<th style="' . $thStyle . 'text-align:left;width:60%;">' . $itemLabel . '</th>'
              . '<th style="' . $thStyle . 'text-align:center;width:15%;">' . $qtyLabel . '</th>'
              . '<th style="' . $thStyle . 'text-align:right;width:25%;">' . $totalLabel . '</th>'
              . '</tr></thead>'
              . '<tbody>';

        $items    = $order->order_items ?? [];
        $currency = (string) ($order->currency ?? '');
        $isReversed = method_exists($order, 'isReverseChargeTaxOrder') && $order->isReverseChargeTaxOrder();
        $rcMode     = method_exists($order, 'getOrderRcMode') ? $order->getOrderRcMode() : 'fixed';

        $rows = [];
        foreach ($items as $item) {
            if (($item->payment_type ?? '') === 'fee') {
                continue;
            }
            $rows[] = $item;
        }
        $lastIndex = count($rows) - 1;

        foreach ($rows as $index => $item) {
            $name         = esc_html((string) ($item->post_title ?? ''));
            // Prefer the labeled attribute combination ("Color: Red | Size: XS")
            // resolved from the frozen item_attributes snapshot; fall back to the
            // raw variation title for custom/simple items.
            $variantText  = ($item->variation_display_title ?? '') !== '' ? $item->variation_display_title : ($item->title ?? '');
            $variant      = esc_html((string) $variantText);
            $qty          = (int) ($item->quantity ?? 1);

            $lineTotal = (int) ($item->subtotal ?? 0);
            if ($currency !== '' && class_exists(\FluentCart\Api\CurrencySettings::class)) {
                $total = \FluentCart\Api\CurrencySettings::getPriceHtml($lineTotal, $currency);
            } else {
                $total = esc_html((string) ($item->formatted_total ?? ''));
            }

            $taxAmount = (int) ($item->tax_amount ?? 0);
            $itemRates = \FluentCart\App\Services\Renderer\Receipt\TaxSummaryHelper::getItemTaxRates($item->toArray());
            $hasTax    = !empty($itemRates) || $taxAmount > 0;
            $isLast    = ($index === $lastIndex);

            // Strip the border-bottom from item cells when a tax row follows; restore it only on the true last row with no tax.
            $noBorderStyle = str_replace('border-bottom:1px solid ' . $borderColor . ';', 'border-bottom:0;', $tdStyle);
            $rowStyle = ($hasTax || $isLast) ? $noBorderStyle : $tdStyle;

            $attrHtml = $variant ? '<div style="font-size:' . $variantSize . 'px;line-height:1.4;margin-top:2px;opacity:0.7;">' . $variant . '</div>' : '';

            $html .= '<tr>'
                   . '<td style="' . $rowStyle . 'vertical-align:top;">'
                   .   '<div style="font-size:' . $nameSize . 'px;font-weight:600;line-height:1.4;">' . $name . '</div>'
                   .   $attrHtml
                   . '</td>'
                   . '<td style="' . $rowStyle . 'text-align:center;">' . $qty . '</td>'
                   . '<td style="' . $rowStyle . 'text-align:right;font-weight:600;">' . $total . '</td>'
                   . '</tr>';

            // Tax row: full-width sibling spanning all columns, badge left / amount right.
            if (!empty($itemRates)) {
                $taxCellStyle = 'padding:2px 12px 8px;' . ($isLast ? '' : 'border-bottom:1px solid ' . $borderColor . ';');
                $html .= '<tr><td colspan="3" style="' . $taxCellStyle . '">'
                       . '<table width="100%" cellspacing="0" cellpadding="0" border="0" style="border-collapse:collapse;">';
                foreach ($itemRates as $rate) {
                    $rateTaxAmount = (int) $rate['tax_amount'];
                    if ($currency !== '' && class_exists(\FluentCart\Api\CurrencySettings::class)) {
                        $rateFormatted = \FluentCart\Api\CurrencySettings::getPriceHtml($rateTaxAmount, $currency);
                    } else {
                        $rateFormatted = esc_html(\FluentCart\App\Helpers\Helper::toDecimal($rateTaxAmount));
                    }
                    $isInclusive = $rate['inclusive'];
                    $badgeBg     = $isInclusive ? '#EAF3DE' : '#FAEEDA';
                    $badgeColor  = $isInclusive ? '#3B6D11' : '#854F0B';
                    $badgeLabel  = esc_html($rate['label']) . ' (' . esc_html(Helper::formatTaxRatePercent((float) $rate['rate_percent'])) . '%)';
                    $amountText  = ($isInclusive ? esc_html__('incl.', 'fluent-cart-pro') : '+') . ' ' . $rateFormatted;
                    $shouldStrike = $isReversed && (!$isInclusive || $rcMode === 'dynamic');
                    $strikeStyle  = $shouldStrike ? 'text-decoration:line-through;opacity:0.6;' : '';
                    $html .= '<tr>'
                           . '<td style="padding:2px 0;">'
                           .   '<span style="display:inline-block;font-size:11px;padding:2px 7px;border-radius:4px;background-color:' . $badgeBg . ';color:' . $badgeColor . ';">' . $badgeLabel . '</span>'
                           . '</td>'
                           . '<td style="text-align:right;padding:2px 0;font-size:11px;font-weight:500;color:' . $badgeColor . ';white-space:nowrap;' . $strikeStyle . '">' . $amountText . '</td>'
                           . '</tr>';
                }
                $html .= '</table></td></tr>';
            } elseif ($taxAmount > 0) {
                if ($currency !== '' && class_exists(\FluentCart\Api\CurrencySettings::class)) {
                    $taxFormatted = \FluentCart\Api\CurrencySettings::getPriceHtml($taxAmount, $currency);
                } else {
                    $taxFormatted = esc_html(\FluentCart\App\Helpers\Helper::toDecimal($taxAmount));
                }
                $isInclusive   = ((int) $order->tax_behavior === 2);
                $badgeBg       = $isInclusive ? '#EAF3DE' : '#FAEEDA';
                $badgeColor    = $isInclusive ? '#3B6D11' : '#854F0B';
                $amountText    = ($isInclusive ? esc_html__('incl.', 'fluent-cart-pro') : '+') . ' ' . $taxFormatted;
                $shouldStrike = $isReversed && (!$isInclusive || $rcMode === 'dynamic');
                $strikeStyle  = $shouldStrike ? 'text-decoration:line-through;opacity:0.6;' : '';
                $taxCellStyle = 'padding:2px 12px 8px;' . ($isLast ? '' : 'border-bottom:1px solid ' . $borderColor . ';');
                $html .= '<tr><td colspan="3" style="' . $taxCellStyle . '">'
                       . '<table width="100%" cellspacing="0" cellpadding="0" border="0" style="border-collapse:collapse;">'
                       . '<tr>'
                       . '<td style="padding:2px 0;">'
                       .   '<span style="display:inline-block;font-size:11px;padding:2px 7px;border-radius:4px;background-color:' . $badgeBg . ';color:' . $badgeColor . ';">' . esc_html__('Tax', 'fluent-cart-pro') . '</span>'
                       . '</td>'
                       . '<td style="text-align:right;padding:2px 0;font-size:11px;font-weight:500;color:' . $badgeColor . ';white-space:nowrap;' . $strikeStyle . '">' . $amountText . '</td>'
                       . '</tr>'
                       . '</table></td></tr>';
            }
        }

        $html .= '</tbody></table>';

        return $html;
    }
}
