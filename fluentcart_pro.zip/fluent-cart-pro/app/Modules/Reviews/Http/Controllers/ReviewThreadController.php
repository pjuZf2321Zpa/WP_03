<?php

namespace FluentCartPro\App\Modules\Reviews\Http\Controllers;

use FluentCart\Api\Resource\ProductReviewResource;
use FluentCart\App\Models\Product;
use FluentCart\App\Models\ProductReview;
use FluentCart\App\Services\Renderer\ReviewModalRenderer;
use FluentCart\App\Services\ProductReviewService;
use FluentCartPro\App\Modules\Reviews\Http\Controllers\Concerns\RateLimitsTrait;
use FluentCartPro\App\Modules\Reviews\Services\ReviewModalFooterRenderer;
use FluentCartPro\App\Modules\Reviews\Services\ReviewService;
use FluentCart\Framework\Http\Controller;
use FluentCart\Framework\Http\Request\Request;

/**
 * Threaded replies — the reviewer answering on their own review thread.
 * Free ships the single-store-reply model only; this whole surface is
 * the Pro capability behind the fluent_cart/review/allow_threaded_replies
 * filter (off by default, third parties opt in with add_filter).
 */
class ReviewThreadController extends Controller
{
    use RateLimitsTrait;

    public function submitReply(Request $request, $postId, $reviewId)
    {
        // CSRF protection — verify WordPress REST nonce
        if (!wp_verify_nonce($request->get_header('X-WP-Nonce'), 'wp_rest')) {
            return $this->sendError([
                'message' => __('Session expired. Please refresh and try again.', 'fluent-cart-pro'),
            ], 403);
        }

        // Reviewer (customer) replies are part of threaded replies — the Pro
        // capability this module owns, off by default (see
        // ReviewService::isThreadedRepliesEnabled()).
        if (!ReviewService::isThreadedRepliesEnabled()) {
            return $this->sendError([
                'message' => __('Replies are not enabled.', 'fluent-cart-pro'),
            ], 403);
        }

        $postId = intval($postId);
        $reviewId = intval($reviewId);
        $userId = get_current_user_id();

        if (!$userId) {
            return $this->sendError([
                'message' => __('You must be logged in to reply', 'fluent-cart-pro'),
            ], 403);
        }

        // Only allow replying on published products (matches public read endpoints)
        if (!Product::query()->where('post_status', 'publish')->find($postId)) {
            return $this->sendError([
                'message' => __('Product not found', 'fluent-cart-pro'),
            ], 404);
        }

        // Find the parent review and verify ownership + approval
        $review = ProductReview::query()
            ->where('id', $reviewId)
            ->where('post_id', $postId)
            // Spelled out rather than the topLevel() scope — model scopes
            // resolve through Builder::__call(), invisible to static analysis.
            ->whereNull('parent_id')
            ->first();

        if (!$review) {
            return $this->sendError([
                'message' => __('Review not found', 'fluent-cart-pro'),
            ], 404);
        }

        if ((int) $review->user_id !== $userId) {
            return $this->sendError([
                'message' => __('You can only reply to your own review', 'fluent-cart-pro'),
            ], 403);
        }

        if ($review->status !== 'approved') {
            return $this->sendError([
                'message' => __('Replies are only allowed on approved reviews', 'fluent-cart-pro'),
            ], 403);
        }

        $content = trim(sanitize_textarea_field((string) $request->get('content', '')));
        $content = mb_substr($content, 0, ReviewModalFooterRenderer::MAX_LENGTH, 'UTF-8');

        if (empty($content)) {
            return $this->sendError([
                'message' => __('Reply content is required', 'fluent-cart-pro'),
            ], 422);
        }

        // Account-scoped across products and IP changes. The shared review
        // limiter also persists via transients without an external cache.
        if ($this->atomicIncrement('fct_review_reply_user_' . $userId, HOUR_IN_SECONDS) > 10) {
            return $this->sendError([
                'message' => __('Too many replies. Please try again later.', 'fluent-cart-pro'),
            ], 429);
        }

        $user = get_userdata($userId);
        $settings = ProductReviewService::getReviewSettings();

        $replyData = [
            'parent_id'      => $reviewId,
            'post_id'        => $postId,
            'rating'         => 0,
            'title'          => '',
            'content'        => $content,
            // Replies follow the same moderation setting as reviews. Hardcoding
            // 'approved' let one approved review become a standing licence to publish
            // unmoderated follow-up content on a public product page.
            'status'         => $settings['auto_approve_reviews'] === 'yes' ? 'approved' : 'pending',
            // Mirror the parent's verified-purchase state so a verified buyer's reply
            // does not render as unverified next to their own verified review.
            'is_verified'    => (int) $review->is_verified,
            'is_admin_reply' => 0,
            'user_id'        => $userId,
            'customer_id'    => $review->customer_id,
            'order_id'       => $review->order_id,
            'reviewer_name'  => $user ? $user->display_name : '',
            'reviewer_email' => $user ? $user->user_email : '',
        ];

        $reply = ProductReviewResource::create($replyData);

        if (is_wp_error($reply)) {
            return $reply;
        }

        do_action('fluent_cart/review/reviewer_reply_submitted', $reply, $review, $request);

        if ($reply && method_exists($reply, 'makeHidden')) {
            $reply->makeHidden(['reviewer_email', 'user_id', 'customer_id', 'order_id', 'meta']);
        }

        $message = $replyData['status'] === 'approved'
            ? __('Your reply has been posted!', 'fluent-cart-pro')
            : __('Your reply has been submitted and is pending approval.', 'fluent-cart-pro');

        return $this->sendSuccess([
            'message' => $message,
            'reply'   => $reply,
            // Rendered by the same renderer that draws the thread, so an
            // appended reply cannot drift from the server-rendered ones.
            'reply_html' => $replyData['status'] === 'approved'
                ? ReviewModalRenderer::replyHtml($reply)
                : '',
        ]);
    }
}
