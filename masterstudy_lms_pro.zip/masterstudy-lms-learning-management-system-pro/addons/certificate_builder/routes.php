<?php

use MasterStudy\Lms\Routing\Router;

/** @var Router $router */

$router->get(
	'/certificates',
	\MasterStudy\Lms\Pro\addons\certificate_builder\Http\Controllers\Frontend\GetCertificatesController::class,
	\MasterStudy\Lms\Pro\addons\certificate_builder\Routing\Swagger\GetCertificates::class
);

$router->delete(
	'/certificates/{certificate_id}',
	\MasterStudy\Lms\Pro\addons\certificate_builder\Http\Controllers\Frontend\DeleteCertificateController::class,
	\MasterStudy\Lms\Pro\addons\certificate_builder\Routing\Swagger\DeleteCertificate::class
);

$router->group(
	array(
		'middleware' => array(
			\MasterStudy\Lms\Routing\Middleware\Authentication::class,
			\MasterStudy\Lms\Pro\addons\certificate_builder\Routing\Middleware\CertificateAdmin::class,
		),
	),
	function ( Router $router ) {
		$router->get(
			'/admin-certificates',
			\MasterStudy\Lms\Pro\addons\certificate_builder\Http\Controllers\Admin\GetCertificatesController::class,
			\MasterStudy\Lms\Pro\addons\certificate_builder\Routing\Swagger\GetAdminCertificates::class
		);

		$router->post(
			'/admin-certificates/bulk-delete',
			\MasterStudy\Lms\Pro\addons\certificate_builder\Http\Controllers\Admin\BulkDeleteCertificatesController::class,
			\MasterStudy\Lms\Pro\addons\certificate_builder\Routing\Swagger\BulkDeleteAdminCertificates::class
		);
	}
);
