<?php

namespace BitApps\IntegrationsPro\Triggers\AdvancedAds;

class AdvancedAdsHelper
{
    public static function formatAdsData($postId, $ad, $newStatus = null, $oldStatus = null)
    {
        $postClass = bit_integrations_get_class('Core\\Util\\Post');
        $helperClass = bit_integrations_get_class('Core\\Util\\Helper');

        if (!static::isPluginInstalled()) {
            return;
        }

        $data = $postClass::get($postId);
        $data['ad_id'] = $postId;

        if (!empty($newStatus) && !empty($oldStatus)) {
            $data['ad_old_status'] = $newStatus;
            $data['ad_new_status'] = $oldStatus;
        } elseif (property_exists($ad, 'status')) {
            $data['ad_status'] = $ad->status;
        }

        return $helperClass::prepareFetchFormatFields($data);
    }

    public static function isPluginInstalled()
    {
        return class_exists('Advanced_Ads');
    }
}
