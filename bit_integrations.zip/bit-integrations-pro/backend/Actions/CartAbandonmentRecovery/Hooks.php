<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Actions\CartAbandonmentRecovery\CartAbandonmentRecoveryProHelper;
use BitApps\IntegrationsPro\Config;
use BitApps\IntegrationsPro\Core\Util\Hooks;

Hooks::filter(Config::withFreePrefix('cart_abandonment_recovery_delete_abandoned_cart'), [CartAbandonmentRecoveryProHelper::class, 'deleteAbandonedCart'], 10, 3);
Hooks::filter(Config::withFreePrefix('cart_abandonment_recovery_reschedule_recovery_emails'), [CartAbandonmentRecoveryProHelper::class, 'rescheduleRecoveryEmails'], 10, 3);
Hooks::filter(Config::withFreePrefix('cart_abandonment_recovery_update_cart_status'), [CartAbandonmentRecoveryProHelper::class, 'updateCartStatus'], 10, 3);
