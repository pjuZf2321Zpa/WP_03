<?php

namespace WPAICG\AutoGPT\Cron\EventProcessor\Processor\ContentEnhancement;

use WPAICG\Core\AIPKit_AI_Caller;
use WPAICG\Core\AIPKit_OpenAI_Reasoning;
use WPAICG\Core\AIPKit_OpenRouter_Reasoning;
use WPAICG\ContentWriter\AIPKit_Content_Writer_Output_Cleaner;
use WPAICG\SEO\AIPKit_SEO_Helper;
use WPAICG\AutoGPT\Helpers;
use WPAICG\Vector\AIPKit_Vector_Store_Manager;
use WPAICG\Core\Stream\Vector as VectorContextBuilder;

if (!defined('ABSPATH')) {
    exit;
}

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound, WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- This file only uses local helper/template variables and intentionally uses core WordPress hook names where needed.

require_once WPAICG_PLUGIN_DIR . 'classes/automations/task-access.php';

if (!class_exists(AIPKit_Content_Writer_Output_Cleaner::class)) {
    $aipkit_output_cleaner_path = WPAICG_PLUGIN_DIR . 'classes/content-writer/output.php';
    if (file_exists($aipkit_output_cleaner_path)) {
        require_once $aipkit_output_cleaner_path;
    }
}

$vector_logic_path = WPAICG_PLUGIN_DIR . 'classes/knowledge-base/retrieval-context.php';
if (file_exists($vector_logic_path)) {
    require_once $vector_logic_path;
}

/**
 * Processes a single "enhance_existing_content" queue item.
 *
 * @param array $item The queue item from the database.
 * @param array $item_config The decoded item_config from the queue item.
 * @return array ['status' => 'success'|'error', 'message' => '...']
 */
function process_enhancement_item_logic(array $item, array $item_config): array
{
    if (!Helpers\is_pro_plan_active()) {
        return ['status' => 'error', 'message' => __('This is a Pro feature.', 'gpt3-ai-content-generator')];
    }

    $post_id = absint($item['target_identifier']);
    $post = get_post($post_id);

    if (!$post || !in_array($post->post_status, $item_config['post_statuses'] ?? ['publish'])) {
        $log_message = "Skipped post #{$post_id}: Post not found or does not match status criteria.";
        return ['status' => 'success', 'message' => $log_message];
    }

    $ai_caller = new AIPKit_AI_Caller(true);
    $ai_params = ['temperature' => floatval($item_config['ai_temperature'] ?? 1.0)];
    if (($item_config['ai_provider'] ?? '') === 'OpenAI') {
        $reasoning_effort = AIPKit_OpenAI_Reasoning::normalize_effort_for_model(
            (string) ($item_config['ai_model'] ?? ''),
            $item_config['reasoning_effort'] ?? ''
        );
        if ($reasoning_effort !== '') {
            $ai_params['reasoning'] = ['effort' => $reasoning_effort];
        }
    } elseif (($item_config['ai_provider'] ?? '') === 'AIPufferCloud') {
        $reasoning_effort = \WPAICG\Cloud\Connection::reasoning_effort((string) ($item_config['ai_model'] ?? ''), $item_config['reasoning_effort'] ?? '');
        if ($reasoning_effort !== '') {
            $ai_params['reasoning'] = ['effort' => $reasoning_effort];
        }
    } elseif (($item_config['ai_provider'] ?? '') === 'OpenRouter') {
        $reasoning_effort = AIPKit_OpenRouter_Reasoning::normalize_effort_for_model(
            (string) ($item_config['ai_model'] ?? ''),
            $item_config['reasoning_effort'] ?? ''
        );
        if ($reasoning_effort !== '') {
            $ai_params['reasoning'] = ['effort' => $reasoning_effort];
        }
    }
    $user_max_tokens = absint($item_config['content_max_tokens'] ?? 4000);
    $system_instruction = 'You are an expert SEO copywriter and editor. You follow instructions precisely. Your response must contain ONLY the generated text, with no introductory phrases, labels, or quotation marks.';
    $changes_made = [];
    $with_partial_changes = static function (array $result) use (&$changes_made, $post_id): array {
        if ($changes_made) {
            $result['message'] .= ' ' . sprintf(
                /* translators: 1: post ID, 2: fields already updated. */
                __('Post #%1$d was partially updated: %2$s.', 'gpt3-ai-content-generator'),
                $post_id, implode(', ', $changes_made)
            );
        }
        return $result;
    };


    $original_meta = get_post_meta($post->ID, '_yoast_wpseo_metadesc', true) ?: (get_post_meta($post->ID, '_aioseo_description', true) ?: '');
    if (empty($original_meta)) {
        $original_meta = $post->post_excerpt;
    }
    $original_focus_keyword = AIPKit_SEO_Helper::get_focus_keyword($post->ID);
    $original_tags = AIPKit_SEO_Helper::get_tags_as_string($post->ID);
    $categories = AIPKit_SEO_Helper::get_categories_as_string($post->ID);
    $placeholders = [
        '{original_title}' => $post->post_title,
        '{original_content}' => wp_strip_all_tags(strip_shortcodes(apply_filters('the_content', $post->post_content))),
        '{original_excerpt}' => $post->post_excerpt,
        '{original_meta_description}' => $original_meta,
        '{original_focus_keyword}' => $original_focus_keyword ?: '',
        '{original_tags}' => $original_tags,
        '{categories}' => $categories,
    ];
    if ($post->post_type === 'product' && class_exists('WooCommerce')) {
        $product = wc_get_product($post->ID);
        if ($product) {
            $placeholders['{price}'] = $product->get_price();
            $placeholders['{regular_price}'] = $product->get_regular_price();
            $placeholders['{sale_price}'] = $product->get_sale_price();
            $placeholders['{sku}'] = $product->get_sku();
            $placeholders['{stock_quantity}'] = $product->get_stock_quantity() ?? 'N/A';
            $placeholders['{stock_status}'] = $product->get_stock_status();
            $placeholders['{weight}'] = $product->get_weight();
            $placeholders['{length}'] = $product->get_length();
            $placeholders['{width}'] = $product->get_width();
            $placeholders['{height}'] = $product->get_height();
            $placeholders['{short_description}'] = wp_strip_all_tags($product->get_short_description());
            $placeholders['{purchase_note}'] = $product->get_purchase_note();
            $placeholders['{total_sales}'] = $product->get_total_sales();
            $category_terms = get_the_terms($post->ID, 'product_cat');
            if (!is_wp_error($category_terms) && !empty($category_terms)) {
                $category_names = wp_list_pluck($category_terms, 'name');
                $placeholders['{product_categories}'] = implode(', ', $category_names);
            } else {
                $placeholders['{product_categories}'] = '';
            }

            $attributes = $product->get_attributes();
            $attribute_string = '';
            foreach ($attributes as $attribute) {
                if ($attribute->is_taxonomy()) {
                    $terms = wp_get_post_terms($product->get_id(), $attribute->get_name(), ['fields' => 'names']);
                    if (!is_wp_error($terms) && !empty($terms)) {
                        $attribute_string .= wc_attribute_label($attribute->get_name()) . ': ' . implode(', ', $terms) . '; ';
                    }
                } else {
                    $attribute_string .= wc_attribute_label($attribute->get_name()) . ': ' . implode(', ', $attribute->get_options()) . '; ';
                }
            }
            $placeholders['{attributes}'] = rtrim($attribute_string, '; ');
        }
    }

    if (($item_config['enable_vector_store'] ?? '0') === '1') {
        $prepared = VectorContextBuilder\prepare_vector_standard_call(
            $ai_caller,
            new AIPKit_Vector_Store_Manager(),
            $post->post_title,
            $item_config,
            $item_config['ai_provider'],
            $system_instruction,
            $ai_params
        );
        if (is_wp_error($prepared)) {
            return Helpers\provider_error_result($prepared);
        }
        $system_instruction = $prepared['system_instruction'];
        $ai_params = $prepared['ai_params'];
    }

    $fields_to_enhance = [];
    if (!empty($item_config['update_title']) && $item_config['update_title'] === '1') {
        $fields_to_enhance[] = 'title';
    }
    if (!empty($item_config['update_excerpt']) && $item_config['update_excerpt'] === '1') {
        $fields_to_enhance[] = 'excerpt';
    }
    if (!empty($item_config['update_content']) && $item_config['update_content'] === '1') {
        $fields_to_enhance[] = 'content';
    }
    if (!empty($item_config['update_meta']) && $item_config['update_meta'] === '1') {
        $fields_to_enhance[] = 'meta';
    }

    foreach ($fields_to_enhance as $field) {
        $prompt_key = $field . '_prompt';
        if (empty($item_config[$prompt_key])) {
            continue;
        }

        $prompt = str_replace(array_keys($placeholders), array_values($placeholders), $item_config[$prompt_key]);
        $current_ai_params = $ai_params;
        if ($field === 'title') {
            $current_ai_params['max_completion_tokens'] = 4000;
        }
        if ($field === 'excerpt') {
            $current_ai_params['max_completion_tokens'] = 4000;
        }
        if ($field === 'meta') {
            $current_ai_params['max_completion_tokens'] = 4000;
        }
        if ($field === 'content') {
            $current_ai_params['max_completion_tokens'] = $user_max_tokens;
        }

        $ai_result = $ai_caller->make_standard_call($item_config['ai_provider'], $item_config['ai_model'], [['role' => 'user', 'content' => $prompt]], $current_ai_params, $system_instruction);

        if (is_wp_error($ai_result)) {
            return $with_partial_changes(Helpers\provider_error_result($ai_result));
        }
        if (empty($ai_result['content'])) {
            return $with_partial_changes(['status' => 'error', 'message' => __('The provider returned no content for the requested update.', 'gpt3-ai-content-generator')]);
        }

        $new_value = $field === 'content' ? trim($ai_result['content']) : trim(str_replace('"', '', $ai_result['content']));
        $saved = true;
        switch ($field) {
            case 'title':
                $saved = wp_update_post(wp_slash(['ID' => $post->ID, 'post_title' => sanitize_text_field($new_value)]), true);
                break;
            case 'excerpt':
                $saved = wp_update_post(wp_slash(['ID' => $post->ID, 'post_excerpt' => wp_kses_post($new_value)]), true);
                break;
            case 'content':
                $html_content = AIPKit_Content_Writer_Output_Cleaner::prepare_rewritten_content($new_value, $item_config['post_content_format'] ?? 'html');
                $saved = wp_update_post(wp_slash(['ID' => $post->ID, 'post_content' => $html_content]), true);
                break;
            case 'meta':
                $value = sanitize_text_field($new_value);
                $saved = AIPKit_SEO_Helper::get_meta_description($post->ID) === $value || AIPKit_SEO_Helper::update_meta_description($post->ID, $value);
                break;
        }
        if (is_wp_error($saved) || !$saved) {
            return $with_partial_changes(['status' => 'error', 'message' => sprintf(
                /* translators: 1: field name, 2: post ID. */
                __('WordPress could not save %1$s for post #%2$d.', 'gpt3-ai-content-generator'), $field, $post_id
            )]);
        }
        $changes_made[] = $field === 'meta' ? 'meta description' : $field;
    }

    if (empty($changes_made)) {
        $log_message = "No valid enhancements were processed for post #{$post_id}. This could be due to empty prompts or AI errors.";
        return ['status' => 'error', 'message' => $log_message];
    }

    $log_message = "Post #{$post_id} enhanced. Updated: " . implode(', ', $changes_made) . ".";
    return ['status' => 'success', 'message' => $log_message];
}
