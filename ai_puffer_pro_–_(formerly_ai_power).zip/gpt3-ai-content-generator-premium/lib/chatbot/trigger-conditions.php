<?php

namespace WPAICG\Lib\Chat\Triggers;

use WP_Error;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Resolves context values and evaluates all conditions for a chatbot trigger.
 */
class AIPKit_Trigger_Condition_Evaluator
{
    /**
     * All conditions must match; an empty set succeeds.
     *
     * @param array $conditions_array Saved condition definitions.
     * @param array $context_data     Context supplied by the trigger event.
     * @return bool Whether every condition is met.
     */
    public function are_conditions_met(array $conditions_array, array $context_data): bool {
        if (empty($conditions_array)) {
            return true; // No conditions means conditions are met by default.
        }

        foreach ($conditions_array as $condition) {
            $condition_type = $condition['type'] ?? null;
            $field          = $condition['field'] ?? null;
            $operator       = $condition['operator'] ?? null;
            $expected_value = $condition['value'] ?? null;

            if (!$condition_type || !$field || !$operator) {
                return false; // Invalid condition structure means it fails
            }

            $actual_value = $this->get_context_value($condition_type, $field, $context_data);

            if (is_wp_error($actual_value)) {
                return false; // Could not resolve value, condition fails
            }

            if (!$this->compare_values($actual_value, $operator, $expected_value, $condition_type, $field)) {
                return false; // If any condition fails, the whole set fails.
            }
        }
        return true; // All conditions passed.
    }

    /**
     * @return mixed|WP_Error Resolved value, or an unsupported type/field error.
     */
    private function get_context_value(string $condition_type, string $field, array $context_data) {
        switch ($condition_type) {
            case 'user_context':
                if ($field === 'is_logged_in') {
                    return isset($context_data['user_id']) && (int)$context_data['user_id'] > 0;
                } elseif ($field === 'user_role') {
                    return $context_data['user_roles'] ?? ['guest'];
                } elseif ($field === 'user_message_text') {
                    return $context_data['user_message_text'] ?? '';
                }
                break;
            case 'text_content':
                if ($field === 'user_message_text') {
                    return $context_data['user_message_text'] ?? '';
                }
                break;
            case 'conversation_state':
                if ($field === 'message_count') {
                    if (isset($context_data['message_count']) && is_numeric($context_data['message_count'])) {
                        return (int) $context_data['message_count'];
                    }
                    $history = $context_data['current_history'] ?? [];
                    $user_message_text = $context_data['user_message_text'] ?? null;
                    $history_for_counting = $history;
                    if ($user_message_text !== null && !empty($history_for_counting)) {
                        $last_message = end($history_for_counting);
                        if (($last_message['role'] ?? '') === 'user' && ($last_message['content'] ?? '') === $user_message_text) {
                            array_pop($history_for_counting);
                        }
                    }
                    $user_message_count = 0;
                    foreach ($history_for_counting as $msg) {
                        if (isset($msg['role']) && $msg['role'] === 'user') {
                            $user_message_count++;
                        }
                    }
                    return $user_message_count;
                }
                break;
            case 'ai_model_context':
                if ($field === 'current_provider') {
                    return $context_data['current_provider'] ?? null;
                } elseif ($field === 'current_model_id') {
                    return $context_data['current_model_id'] ?? null;
                }
                break;
            case 'http_context':
                if ($field === 'http_referer') {
                    return $context_data['http_referer'] ?? '';
                } elseif ($field === 'user_agent') {
                    return $context_data['user_agent'] ?? '';
                }
                break;
            case 'post_context':
                if ($field === 'post_id') {
                    return isset($context_data['post_id']) ? (int) $context_data['post_id'] : 0;
                } elseif ($field === 'post_title') {
                    $post_id = isset($context_data['post_id']) ? (int) $context_data['post_id'] : 0;
                    return $post_id > 0 ? (string) get_the_title($post_id) : '';
                } elseif ($field === 'post_tags_contain') {
                    $post_id = isset($context_data['post_id']) ? (int) $context_data['post_id'] : 0;
                    if ($post_id <= 0) {
                        return '';
                    }
                    $tag_names = wp_get_post_tags($post_id, ['fields' => 'names']);
                    if (is_wp_error($tag_names) || empty($tag_names)) {
                        return '';
                    }
                    return implode(', ', $tag_names);
                }
                break;
            case 'error_context':
                if ($field === 'error_code') {
                    return $context_data['error_code'] ?? '';
                } elseif ($field === 'error_message') {
                    return $context_data['error_message'] ?? '';
                } elseif ($field === 'failed_provider') {
                    return $context_data['failed_provider'] ?? '';
                } elseif ($field === 'failed_model') {
                    return $context_data['failed_model'] ?? '';
                } elseif ($field === 'status_code') {
                    return $context_data['status_code'] ?? null;
                } elseif ($field === 'operation') {
                    return $context_data['operation'] ?? '';
                } elseif ($field === 'module') {
                    return $context_data['module'] ?? '';
                }
                break;
            default:
                return new WP_Error('unknown_condition_type', "Unknown condition type: {$condition_type}");
        }
        return new WP_Error('unknown_condition_field', "Unknown field '{$field}' for condition type '{$condition_type}'");
    }

    /**
     * Compare resolved values without coercing string or boolean operators.
     */
    private function compare_values($actual_value, string $operator, $expected_value, string $condition_type, string $field): bool {
        switch ($operator) {
            // Boolean
            case 'is_true': return $actual_value === true;
            case 'is_false': return $actual_value === false;

            // String specific
            case 'equals':
                return is_string($actual_value) && is_string($expected_value) && $actual_value === $expected_value;
            case 'equals_ignore_case':
                return is_string($actual_value) && is_string($expected_value) && strtolower($actual_value) === strtolower($expected_value);
            case 'not_equals':
                return is_string($actual_value) && is_string($expected_value) && $actual_value !== $expected_value;
            case 'contains':
            case 'not_contains':
                $contains = $operator === 'contains';
                if (is_array($actual_value)) {
                    if (is_string($expected_value) && $expected_value !== '') {
                        return in_array($expected_value, $actual_value, true) === $contains;
                    }
                    if (is_array($expected_value) && !empty($expected_value)) {
                        return !empty(array_intersect($actual_value, $expected_value)) === $contains;
                    }
                    return false;
                }
                if ($condition_type === 'text_content' && $field === 'user_message_text' && is_string($actual_value)) {
                    if (is_array($expected_value)) {
                        if (empty($expected_value)) {
                            return false;
                        }
                        foreach ($expected_value as $keyword) {
                            if (is_string($keyword) && $keyword !== '' && stripos($actual_value, $keyword) !== false) {
                                return $contains;
                            }
                        }
                        return !$contains;
                    } elseif (is_string($expected_value) && $expected_value !== '') {
                        return (stripos($actual_value, $expected_value) !== false) === $contains;
                    }
                } elseif (is_string($actual_value) && is_string($expected_value) && $expected_value !== '') {
                    return (strpos($actual_value, $expected_value) !== false) === $contains;
                }
                // Invalid operands fail for both operators, including not_contains.
                return false;
            case 'starts_with':
                return is_string($actual_value) && is_string($expected_value) && strpos($actual_value, $expected_value) === 0;
            case 'ends_with':
                return is_string($actual_value) && is_string($expected_value) && (string) substr($actual_value, -strlen($expected_value)) === $expected_value;
            case 'matches_regex':
                return is_string($actual_value) && is_string($expected_value) && @preg_match($expected_value, $actual_value) === 1;
            case 'is_empty':
                return is_string($actual_value) && trim($actual_value) === '';
            case 'is_not_empty':
                return is_string($actual_value) && trim($actual_value) !== '';

            // String/Array (where actual_value is a string or array, expected_value is an array of strings)
            case 'is_one_of':
                if (is_string($actual_value) && is_array($expected_value)) {
                    return in_array($actual_value, $expected_value, true);
                }
                elseif (is_array($actual_value) && is_array($expected_value)) { // Actual value is an array (e.g. user roles)
                    return !empty(array_intersect($actual_value, $expected_value));
                }
                return false;
            case 'is_not_one_of':
                if (is_string($actual_value) && is_array($expected_value)) {
                    return !in_array($actual_value, $expected_value, true);
                }
                elseif (is_array($actual_value) && is_array($expected_value)) { // Actual value is an array (e.g. user roles)
                    return empty(array_intersect($actual_value, $expected_value));
                }
                return false;


            // Numeric
            case 'equals_numeric':
                return is_numeric($actual_value) && is_numeric($expected_value) && (float)$actual_value == (float)$expected_value;
            case 'not_equals_numeric':
                return is_numeric($actual_value) && is_numeric($expected_value) && (float)$actual_value != (float)$expected_value;
            case 'greater_than':
                return is_numeric($actual_value) && is_numeric($expected_value) && (float)$actual_value > (float)$expected_value;
            case 'less_than':
                return is_numeric($actual_value) && is_numeric($expected_value) && (float)$actual_value < (float)$expected_value;
            case 'greater_than_or_equals':
                return is_numeric($actual_value) && is_numeric($expected_value) && (float)$actual_value >= (float)$expected_value;
            case 'less_than_or_equals':
                return is_numeric($actual_value) && is_numeric($expected_value) && (float)$actual_value <= (float)$expected_value;

            default:
                return false;
        }
    }
}
