<?php

namespace MasterStudy\Lms\Pro\addons\enterprise_courses\Admin\Controllers;

use MasterStudy\Lms\Http\WpResponseFactory;
use MasterStudy\Lms\Pro\addons\enterprise_courses\Admin\Repositories\EnterpriseGroupsRepository;
use WP_REST_Request;
use WP_REST_Response;

final class AddEnterpriseGroupMemberCourseController {
	public function __invoke( WP_REST_Request $request ): WP_REST_Response {
		$result = ( new EnterpriseGroupsRepository() )->add_member_course(
			(int) $request->get_param( 'group_id' ),
			(int) $request->get_param( 'user_id' ),
			(int) $request->get_param( 'course_id' )
		);

		if ( is_wp_error( $result ) ) {
			return WpResponseFactory::error( $result->get_error_message() );
		}

		return new WP_REST_Response( array( 'success' => true ) );
	}
}
