<?php
/**
 * Dashboard "My Listings" search form.
 *
 * The form submits with GET so the search term stays in the page url. WordPress builds the
 * pagination links with get_pagenum_link(), which keeps the current query string, so the active
 * search survives when the owner moves to page 2 and beyond.
 */

// resolve the dashboard permalink once, it is both the form action and the source of the hidden fields below
$wpestate_dash_link = wpestate_get_template_link('user_dashboard.php');

// a GET form replaces the whole query string of its action url, so any argument already in that url
// (sites without pretty permalinks get ?page_id=N) has to be sent again as a hidden field
$wpestate_dash_args  = array();
$wpestate_dash_query = wp_parse_url( $wpestate_dash_link, PHP_URL_QUERY );
if ( ! empty( $wpestate_dash_query ) ) {
    wp_parse_str( $wpestate_dash_query, $wpestate_dash_args );
}

// keep the term that is currently filtering the list so the input still shows it after a search
$wpestate_dash_search_value = '';
if ( isset( $_GET['wpestate_prop_title'] ) ) {
    $wpestate_dash_search_value = sanitize_text_field( wp_unslash( $_GET['wpestate_prop_title'] ) );
}
?>

        <div class="search_dashborad_header">
            <form method="get" action="<?php echo esc_url( $wpestate_dash_link );?>">
            <?php
            wp_nonce_field( 'wpestate_dash_search', 'wpestate_dash_search_nonce', false );

            foreach ( $wpestate_dash_args as $wpestate_dash_arg_key => $wpestate_dash_arg_value ) {
                print '<input type="hidden" name="'.esc_attr( $wpestate_dash_arg_key ).'" value="'.esc_attr( $wpestate_dash_arg_value ).'" />';
            }
            ?>
            <div class="col-md-4">
                <input type="text" id="title" class="form-control" value="<?php echo esc_attr( $wpestate_dash_search_value );?>" size="20" name="wpestate_prop_title" placeholder="<?php esc_html_e('Search by listing name.','wprentals');?>">
            </div>
            <div class="col-md-6">
                <input type="submit" class="wpb_btn-info wpb_btn-small wpestate_vc_button  vc_button" value="<?php esc_html_e('Search','wprentals');?>">
            </div>
            </form>
        </div>
