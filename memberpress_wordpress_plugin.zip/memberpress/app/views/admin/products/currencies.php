<?php
/**
 * View admin/products/currencies
 *
 * Per-currency pricing tab in the Product Options meta box.
 *
 * @var MeprProduct $product
 */

if (!defined('ABSPATH')) {
    die('You are not allowed to call this page directly.');
}

$mepr_options     = MeprOptions::fetch();
$mepr_enabled_all = MeprCurrencyService::get_enabled_currencies();
$mepr_primary_cur = $mepr_options->currency_code;
$mepr_secondary   = array_filter($mepr_enabled_all, function ($c) use ($mepr_primary_cur) {
    return $c !== $mepr_primary_cur;
});

if (empty($mepr_secondary)) :
    ?>
  <p><?php esc_html_e('No secondary currencies enabled. Enable additional currencies in Settings > General.', 'memberpress'); ?></p>
<?php else :
    $mepr_has_trial = (bool) get_post_meta($product->ID, MeprProduct::$trial_str, true);
    $mepr_reg_meta_raw = get_post_meta($product->ID, MeprProduct::$enable_registration_page_str, true);
    $mepr_is_new_product = ('' === $mepr_reg_meta_raw && get_post_status($product->ID) === 'auto-draft');
    $mepr_reg_enabled = $mepr_is_new_product ? false : $product->get_enable_registration_page();
    ?>
  <div class="notice notice-info inline" style="margin: 0 0 12px;">
    <p>
      <?php
        echo esc_html__(
            'Multi-currency pricing applies to Shopping Cart checkout only. Standalone registration pages always charge in the site primary currency.',
            'memberpress'
        );
        ?>
    </p>
  </div>
  <div id="mepr-currency-reg-notice" class="notice notice-warning inline" style="margin: 0 0 12px;<?php echo $mepr_reg_enabled ? '' : ' display:none;'; ?>">
    <p>
      <?php
        echo esc_html__(
            'Standalone registration is enabled for this product. Multi-currency pricing is available for cart/shop checkout only. Disable the registration page under Cart & Shop to edit secondary currency prices.',
            'memberpress'
        );
        ?>
    </p>
  </div>
  <div id="mepr-currency-prices-ui" class="mepr-currency-prices-ui<?php echo $mepr_reg_enabled ? ' is-disabled' : ''; ?>">
  <p class="description" style="margin-bottom: 12px;">
    <?php
    printf(
        // Translators: %s: primary currency code.
        esc_html__('Set prices in secondary currencies for cart checkout. Auto-filled prices are calculated from %s using current exchange rates. Override any price by typing a value — it will be marked as Manual and preserved during rate refreshes.', 'memberpress'),
        esc_html($mepr_primary_cur)
    );
    ?>
  </p>
  <table class="mepr-currency-prices-table">
    <thead>
      <tr>
        <th><?php esc_html_e('Currency', 'memberpress'); ?></th>
        <th><?php esc_html_e('Price', 'memberpress'); ?></th>
        <th class="mepr-trial-col" <?php echo $mepr_has_trial ? '' : 'style="display:none;"'; ?>><?php esc_html_e('Trial Amount', 'memberpress'); ?></th>
        <th><?php esc_html_e('Source', 'memberpress'); ?></th>
        <th></th>
      </tr>
    </thead>
    <tbody>
    <?php foreach ($mepr_secondary as $mepr_cur_code) :
        $mepr_price_key    = MeprProduct::$price_str . '_' . $mepr_cur_code;
        $mepr_trial_key    = '_mepr_product_trial_amount_' . $mepr_cur_code;
        $mepr_price_val    = get_post_meta($product->ID, $mepr_price_key, true);
        $mepr_trial_val    = get_post_meta($product->ID, $mepr_trial_key, true);
        $mepr_price_source = get_post_meta($product->ID, $mepr_price_key . '_source', true) ?: 'auto';
        $mepr_trial_source = get_post_meta($product->ID, $mepr_trial_key . '_source', true) ?: 'auto';
        ?>
      <tr class="mepr-currency-price-row" data-currency="<?php echo esc_attr($mepr_cur_code); ?>">
        <td><span class="mepr-currency-price-row__code"><?php echo esc_html($mepr_cur_code); ?></span></td>
        <td>
          <input type="number" min="0.01" step="0.01" name="mepr_product_price_<?php echo esc_attr($mepr_cur_code); ?>" value="<?php echo esc_attr($mepr_price_val); ?>" class="mepr-currency-price-input" data-field="price" data-currency="<?php echo esc_attr($mepr_cur_code); ?>" <?php disabled($mepr_reg_enabled); ?>>
          <input type="hidden" name="mepr_product_price_<?php echo esc_attr($mepr_cur_code); ?>_source" value="<?php echo esc_attr($mepr_price_source); ?>" class="mepr-currency-source-input" data-field="price" data-currency="<?php echo esc_attr($mepr_cur_code); ?>">
        </td>
        <td class="mepr-trial-col" <?php echo $mepr_has_trial ? '' : 'style="display:none;"'; ?>>
          <input type="number" min="0.01" step="0.01" name="mepr_product_trial_amount_<?php echo esc_attr($mepr_cur_code); ?>" value="<?php echo esc_attr($mepr_trial_val); ?>" class="mepr-currency-price-input" data-field="trial" data-currency="<?php echo esc_attr($mepr_cur_code); ?>" <?php disabled($mepr_reg_enabled); ?>>
          <input type="hidden" name="mepr_product_trial_amount_<?php echo esc_attr($mepr_cur_code); ?>_source" value="<?php echo esc_attr($mepr_trial_source); ?>" class="mepr-currency-source-input" data-field="trial" data-currency="<?php echo esc_attr($mepr_cur_code); ?>">
        </td>
        <td>
          <span class="mepr-currency-price-row__source mepr-currency-price-row__source--<?php echo esc_attr($mepr_price_source); ?>">
            <?php echo $mepr_price_source === 'auto' ? '<span class="mepr-auto-badge">Auto</span>' : '<span class="mepr-manual-label">Manual</span>'; ?>
          </span>
        </td>
        <td>
          <?php if ($mepr_price_source === 'manual') : ?>
            <a href="#" class="mepr-reset-to-auto" data-currency="<?php echo esc_attr($mepr_cur_code); ?>"><?php esc_html_e('Reset to auto', 'memberpress'); ?></a>
          <?php endif; ?>
        </td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
  </div>
<?php endif; ?>
