<?php

namespace BitApps\IntegrationsPro\Actions\NiroHelp\Services;

if (!\defined('ABSPATH')) {
    exit;
}

final class CustomerService extends BaseService
{
    public function createCustomer(): array
    {
        $error = $this->validateRequiredFields(['email' => __('Email', 'bit-integrations-pro')]);

        if ($error !== null) {
            return $error;
        }

        $email = $this->getString('email');

        if (!is_email($email)) {
            return $this->errorResponse(__('The email is not valid. Map a valid email address.', 'bit-integrations-pro'));
        }

        $isNew = !get_user_by('email', $email);
        $customerId = $this->findOrCreateCustomer($email, $this->getString('name'));

        if (is_wp_error($customerId)) {
            return $this->errorResponse($customerId->get_error_message());
        }

        $customer = get_userdata($customerId);

        return $this->successResponse(
            $isNew ? __('The customer is created.', 'bit-integrations-pro') : __('A customer with this email already exists.', 'bit-integrations-pro'),
            [
                'id'     => (int) $customerId,
                'name'   => $customer ? (string) $customer->display_name : '',
                'email'  => $email,
                'is_new' => $isNew,
            ]
        );
    }
}
