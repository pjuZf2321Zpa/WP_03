<?php

namespace BitApps\IntegrationsPro\Triggers\BookingPress;

final class BookingPressHelper
{
    public static function tasks()
    {
        return [
            [
                'form_name'           => __('Appointment Booked', 'bit-integrations-pro'),
                'triggered_entity_id' => 'bookingpress_after_insert_appointment',
                'skipPrimaryKey'      => true,
            ],
            [
                'form_name'           => __('Appointment Cancelled', 'bit-integrations-pro'),
                'triggered_entity_id' => 'bookingpress_after_cancel_appointment',
                'skipPrimaryKey'      => true,
            ],
            [
                'form_name'           => __('Appointment Status Changed', 'bit-integrations-pro'),
                'triggered_entity_id' => 'bookingpress_after_change_appointment_status',
                'skipPrimaryKey'      => true,
            ],
            [
                'form_name'           => __('Appointment Rescheduled', 'bit-integrations-pro'),
                'triggered_entity_id' => 'bookingpress_after_rescheduled_appointment',
                'skipPrimaryKey'      => true,
            ],
            [
                'form_name'           => __('Appointment Updated', 'bit-integrations-pro'),
                'triggered_entity_id' => 'bookingpress_after_update_appointment',
                'skipPrimaryKey'      => true,
            ],
            [
                'form_name'           => __('Customer Created', 'bit-integrations-pro'),
                'triggered_entity_id' => 'bookingpress_customer_created',
                'skipPrimaryKey'      => true,
            ],
            [
                'form_name'           => __('Customer Updated', 'bit-integrations-pro'),
                'triggered_entity_id' => 'bookingpress_after_update_customer',
                'skipPrimaryKey'      => true,
            ],
        ];
    }

    public static function getAppointmentData($appointmentId)
    {
        return self::getRecordById(self::getAppointmentTableName(), $appointmentId, 'bookingpress_appointment_booking_id');
    }

    public static function getCustomerData($customerId)
    {
        return self::getRecordById(self::getCustomerTableName(), $customerId, 'bookingpress_customer_id');
    }

    private static function getRecordById($tableName, $id, $idColumn)
    {
        if (empty($tableName)) {
            return [];
        }

        global $wpdb;
        $record = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT * FROM {$tableName} WHERE {$idColumn} = %d", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
                $id
            ),
            ARRAY_A
        );

        return $record ?: [];
    }

    private static function getAppointmentTableName()
    {
        global $tbl_bookingpress_appointment_bookings; // phpcs:ignore WordPress.DB.GlobalVariables
        if (!empty($tbl_bookingpress_appointment_bookings)) {
            return $tbl_bookingpress_appointment_bookings;
        }

        global $wpdb;

        return $wpdb->prefix . 'bookingpress_appointment_bookings';
    }

    private static function getCustomerTableName()
    {
        global $tbl_bookingpress_customers; // phpcs:ignore WordPress.DB.GlobalVariables
        if (!empty($tbl_bookingpress_customers)) {
            return $tbl_bookingpress_customers;
        }

        global $wpdb;

        return $wpdb->prefix . 'bookingpress_customers';
    }
}
