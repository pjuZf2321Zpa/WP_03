<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Core\Util\Hooks;
use BitApps\IntegrationsPro\Triggers\BookingCalendar\BookingCalendarController;

Hooks::add('wpbc_track_new_booking', [BookingCalendarController::class, 'handleBookingCreated'], 20, 1);
Hooks::add('wpbc_track_edit_booking', [BookingCalendarController::class, 'handleBookingUpdated'], 20, 1);
