<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Core\Util\Route;
use BitApps\IntegrationsPro\Triggers\ClickWhale\ClickWhaleController;

Route::get('clickwhale/get', [ClickWhaleController::class, 'getAllTasks']);
