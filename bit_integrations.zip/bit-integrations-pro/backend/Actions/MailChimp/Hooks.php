<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Actions\MailChimp\MailChimpRecordHelper;
use BitApps\IntegrationsPro\Config;
use BitApps\IntegrationsPro\Core\Util\Hooks;

// Deprecated since v2.7.8 - use bit_integrations_mailchimp_* hooks instead
if (bit_integrations_version_below('2.7.8')) {
    Hooks::filter('btcbi_mailchimp_add_remove_tag', [MailChimpRecordHelper::class, 'addRemoveTag'], 10, 4);
    Hooks::filter('btcbi_mailchimp_map_language', [MailChimpRecordHelper::class, 'mapLanguageField'], 10, 2);
    Hooks::add('btcbi_mailchimp_store_gdpr_permission', [MailChimpRecordHelper::class, 'updateGDPRPermissions'], 10, 6);
}

// New hooks since v2.7.8
Hooks::filter(Config::withFreePrefix('mailchimp_add_remove_tag'), [MailChimpRecordHelper::class, 'addRemoveTag'], 10, 4);
Hooks::filter(Config::withFreePrefix('mailchimp_map_language'), [MailChimpRecordHelper::class, 'mapLanguageField'], 10, 2);
Hooks::add(Config::withFreePrefix('mailchimp_store_gdpr_permission'), [MailChimpRecordHelper::class, 'updateGDPRPermissions'], 10, 6);
