<?php

namespace BitApps\IntegrationsPro\Actions\Booknetic;

use BitApps\IntegrationsPro\Actions\Booknetic\Services\AppointmentService;
use BitApps\IntegrationsPro\Actions\Booknetic\Services\CustomerCategoryService;
use BitApps\IntegrationsPro\Actions\Booknetic\Services\CustomerService;
use BitApps\IntegrationsPro\Actions\Booknetic\Services\LocationCategoryService;
use BitApps\IntegrationsPro\Actions\Booknetic\Services\LocationService;
use BitApps\IntegrationsPro\Actions\Booknetic\Services\NotificationService;
use BitApps\IntegrationsPro\Actions\Booknetic\Services\PaymentService;
use BitApps\IntegrationsPro\Actions\Booknetic\Services\ServiceCategoryService;
use BitApps\IntegrationsPro\Actions\Booknetic\Services\ServiceExtraService;
use BitApps\IntegrationsPro\Actions\Booknetic\Services\ServiceService;
use BitApps\IntegrationsPro\Actions\Booknetic\Services\StaffService;

final class BookneticService
{
    public static function createAppointment($response, $fieldData, $utilities = null, $integrationDetails = null)
    {
        $settings = self::settings($integrationDetails, [
            'selectedLocation' => 'location_id',
            'selectedService'  => 'service_id',
            'selectedStaff'    => 'staff_id',
            'selectedCustomer' => 'customer_id',
            'selectedStatus'   => 'status',
        ]) + self::settings($utilities, [
            'selected_payment_method' => 'payment_method',
            'selected_payment_status' => 'payment_status',
        ]);

        return (new AppointmentService($fieldData, $settings))->createAppointment();
    }

    public static function updateAppointment($response, $fieldData, $utilities = null)
    {
        $settings = self::settings($utilities, [
            'selected_location' => 'location_id',
            'selected_service'  => 'service_id',
            'selected_staff'    => 'staff_id',
            'selected_customer' => 'customer_id',
            'selected_status'   => 'status',
        ]);

        return (new AppointmentService($fieldData, $settings))->updateAppointment();
    }

    public static function deleteAppointment($response, $fieldData)
    {
        return (new AppointmentService($fieldData))->deleteAppointment();
    }

    public static function rescheduleAppointment($response, $fieldData, $utilities = null)
    {
        $settings = self::settings($utilities, [
            'selected_staff'        => 'staff_id',
            'selected_reset_status' => 'reset_status',
        ]);

        return (new AppointmentService($fieldData, $settings))->rescheduleAppointment();
    }

    public static function changeAppointmentStatus($response, $fieldData, $integrationDetails = null)
    {
        $settings = self::settings($integrationDetails, [
            'selectedStatus' => 'status',
        ]);

        return (new AppointmentService($fieldData, $settings))->changeAppointmentStatus();
    }

    public static function updatePayment($response, $fieldData, $integrationDetails = null)
    {
        $settings = self::settings($integrationDetails, [
            'selectedPaymentStatus' => 'payment_status',
        ]);

        return (new PaymentService($fieldData, $settings))->updatePayment();
    }

    public static function completePayment($response, $fieldData)
    {
        return (new PaymentService($fieldData))->completePayment();
    }

    public static function createCustomer($response, $fieldData, $utilities = null)
    {
        $settings = self::settings($utilities, [
            'selected_gender'            => 'gender',
            'selected_customer_category' => 'category_id',
            'selected_user'              => 'user_id',
        ]);

        return (new CustomerService($fieldData, $settings))->createCustomer();
    }

    public static function updateCustomer($response, $fieldData, $utilities = null)
    {
        $settings = self::settings($utilities, [
            'selected_gender'            => 'gender',
            'selected_customer_category' => 'category_id',
            'selected_user'              => 'user_id',
        ]);

        return (new CustomerService($fieldData, $settings))->updateCustomer();
    }

    public static function deleteCustomer($response, $fieldData)
    {
        return (new CustomerService($fieldData))->deleteCustomer();
    }

    public static function assignCustomerCategory($response, $fieldData, $integrationDetails = null)
    {
        $settings = self::settings($integrationDetails, [
            'selectedCustomerCategory' => 'category_id',
        ]);

        return (new CustomerService($fieldData, $settings))->assignCustomerCategory();
    }

    public static function createStaff($response, $fieldData, $utilities = null, $integrationDetails = null)
    {
        $settings = self::settings($integrationDetails, [
            'selectedLocations' => 'location_ids',
        ]) + self::settings($utilities, [
            'selected_services' => 'service_ids',
            'selected_user'     => 'user_id',
        ]);

        return (new StaffService($fieldData, $settings))->createStaff();
    }

    public static function updateStaff($response, $fieldData, $utilities = null)
    {
        $settings = self::settings($utilities, [
            'selected_locations' => 'location_ids',
            'selected_services'  => 'service_ids',
            'selected_user'      => 'user_id',
        ]);

        return (new StaffService($fieldData, $settings))->updateStaff();
    }

    public static function deleteStaff($response, $fieldData)
    {
        return (new StaffService($fieldData))->deleteStaff();
    }

    public static function duplicateStaff($response, $fieldData)
    {
        return (new StaffService($fieldData))->duplicateStaff();
    }

    public static function setStaffStatus($response, $fieldData, $integrationDetails = null)
    {
        $settings = self::settings($integrationDetails, [
            'selectedActiveStatus' => 'is_active',
        ]);

        return (new StaffService($fieldData, $settings))->setStaffStatus();
    }

    public static function createLocation($response, $fieldData, $utilities = null)
    {
        $settings = self::settings($utilities, [
            'selected_location_category' => 'category_id',
        ]);

        return (new LocationService($fieldData, $settings))->createLocation();
    }

    public static function updateLocation($response, $fieldData, $utilities = null)
    {
        $settings = self::settings($utilities, [
            'selected_location_category' => 'category_id',
        ]);

        return (new LocationService($fieldData, $settings))->updateLocation();
    }

    public static function deleteLocation($response, $fieldData)
    {
        return (new LocationService($fieldData))->deleteLocation();
    }

    public static function duplicateLocation($response, $fieldData)
    {
        return (new LocationService($fieldData))->duplicateLocation();
    }

    public static function setLocationStatus($response, $fieldData, $integrationDetails = null)
    {
        $settings = self::settings($integrationDetails, [
            'selectedActiveStatus' => 'is_active',
        ]);

        return (new LocationService($fieldData, $settings))->setLocationStatus();
    }

    public static function createService($response, $fieldData, $utilities = null, $integrationDetails = null)
    {
        $settings = self::settings($integrationDetails, [
            'selectedServiceCategory' => 'category_id',
        ]) + self::settings($utilities, [
            'selected_staff_members' => 'staff_ids',
            'selected_deposit_type'  => 'deposit_type',
        ]);

        return (new ServiceService($fieldData, $settings))->createService();
    }

    public static function updateService($response, $fieldData, $utilities = null)
    {
        $settings = self::settings($utilities, [
            'selected_service_category' => 'category_id',
            'selected_deposit_type'     => 'deposit_type',
        ]);

        return (new ServiceService($fieldData, $settings))->updateService();
    }

    public static function deleteService($response, $fieldData)
    {
        return (new ServiceService($fieldData))->deleteService();
    }

    public static function duplicateService($response, $fieldData)
    {
        return (new ServiceService($fieldData))->duplicateService();
    }

    public static function setServiceStatus($response, $fieldData, $integrationDetails = null)
    {
        $settings = self::settings($integrationDetails, [
            'selectedActiveStatus' => 'is_active',
        ]);

        return (new ServiceService($fieldData, $settings))->setServiceStatus();
    }

    public static function createServiceExtra($response, $fieldData, $utilities = null)
    {
        $settings = self::settings($utilities, [
            'selected_service'        => 'service_id',
            'selected_extra_category' => 'category_id',
        ]);

        return (new ServiceExtraService($fieldData, $settings))->createServiceExtra();
    }

    public static function updateServiceExtra($response, $fieldData, $utilities = null)
    {
        $settings = self::settings($utilities, [
            'selected_service'        => 'service_id',
            'selected_extra_category' => 'category_id',
            'selected_active_status'  => 'is_active',
        ]);

        return (new ServiceExtraService($fieldData, $settings))->updateServiceExtra();
    }

    public static function deleteServiceExtra($response, $fieldData)
    {
        return (new ServiceExtraService($fieldData))->deleteServiceExtra();
    }

    public static function duplicateServiceExtra($response, $fieldData, $utilities = null)
    {
        $settings = self::settings($utilities, [
            'selected_service' => 'service_id',
        ]);

        return (new ServiceExtraService($fieldData, $settings))->duplicateServiceExtra();
    }

    public static function createCustomerCategory($response, $fieldData, $utilities = null)
    {
        $settings = self::settings($utilities, [
            'selected_is_default' => 'is_default',
        ]);

        return (new CustomerCategoryService($fieldData, $settings))->createCustomerCategory();
    }

    public static function updateCustomerCategory($response, $fieldData, $utilities = null)
    {
        $settings = self::settings($utilities, [
            'selected_is_default' => 'is_default',
        ]);

        return (new CustomerCategoryService($fieldData, $settings))->updateCustomerCategory();
    }

    public static function deleteCustomerCategory($response, $fieldData)
    {
        return (new CustomerCategoryService($fieldData))->deleteCustomerCategory();
    }

    public static function createLocationCategory($response, $fieldData)
    {
        return (new LocationCategoryService($fieldData))->createLocationCategory();
    }

    public static function updateLocationCategory($response, $fieldData)
    {
        return (new LocationCategoryService($fieldData))->updateLocationCategory();
    }

    public static function deleteLocationCategory($response, $fieldData)
    {
        return (new LocationCategoryService($fieldData))->deleteLocationCategory();
    }

    public static function createServiceCategory($response, $fieldData, $utilities = null)
    {
        $settings = self::settings($utilities, [
            'selected_parent_category' => 'parent_id',
        ]);

        return (new ServiceCategoryService($fieldData, $settings))->createServiceCategory();
    }

    public static function updateServiceCategory($response, $fieldData, $utilities = null)
    {
        $settings = self::settings($utilities, [
            'selected_parent_category' => 'parent_id',
        ]);

        return (new ServiceCategoryService($fieldData, $settings))->updateServiceCategory();
    }

    public static function deleteServiceCategory($response, $fieldData)
    {
        return (new ServiceCategoryService($fieldData))->deleteServiceCategory();
    }

    public static function createInAppNotification($response, $fieldData, $integrationDetails = null)
    {
        $settings = self::settings($integrationDetails, [
            'selectedUser' => 'user_id',
        ]);

        return (new NotificationService($fieldData, $settings))->createInAppNotification();
    }

    private static function settings($source, array $keys): array
    {
        $source = (array) $source;
        $settings = [];

        foreach ($keys as $sourceKey => $fieldKey) {
            $value = $source[$sourceKey] ?? '';

            if ($value !== '' && $value !== null) {
                $settings[$fieldKey] = $value;
            }
        }

        return $settings;
    }
}
