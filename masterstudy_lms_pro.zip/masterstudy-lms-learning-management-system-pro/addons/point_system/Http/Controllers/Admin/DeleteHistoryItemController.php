<?php

namespace MasterStudy\Lms\Pro\addons\point_system\Http\Controllers\Admin;

use MasterStudy\Lms\Http\WpResponseFactory;
use MasterStudy\Lms\Pro\addons\point_system\Repositories\PointStatisticsAdminAccess;
use MasterStudy\Lms\Pro\addons\point_system\Repositories\PointStatisticsRepository;
use MasterStudy\Lms\Validation\Validator;
use RuntimeException;
use WP_REST_Request;
use WP_REST_Response;

final class DeleteHistoryItemController {
	public function __invoke( WP_REST_Request $request ): WP_REST_Response {
		if ( ! PointStatisticsAdminAccess::can_access() ) {
			return WpResponseFactory::forbidden();
		}

		$validator = new Validator(
			$request->get_params(),
			array(
				'user_points_id' => 'required|integer',
			)
		);

		if ( $validator->fails() ) {
			return WpResponseFactory::validation_failed( $validator->get_errors_array() );
		}

		$params = $validator->get_validated();

		try {
			$data = ( new PointStatisticsRepository() )->delete_history_item(
				absint( $params['user_points_id'] ?? 0 )
			);
		} catch ( RuntimeException $e ) {
			if ( 404 === $e->getCode() ) {
				return WpResponseFactory::not_found();
			}

			return WpResponseFactory::error( $e->getMessage() );
		}

		return WpResponseFactory::ok_with_data(
			array(
				'status' => 'ok',
				'total'  => (int) $data['total'],
			)
		);
	}
}
