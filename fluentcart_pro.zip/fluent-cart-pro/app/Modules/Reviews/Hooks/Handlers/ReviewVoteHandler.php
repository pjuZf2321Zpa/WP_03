<?php

namespace FluentCartPro\App\Modules\Reviews\Hooks\Handlers;

use FluentCart\App\Services\ProductReviewService;
use FluentCartPro\App\Modules\Reviews\Models\ReviewInteraction;

class ReviewVoteHandler
{
    public function register()
    {
        add_filter('fluent_cart/review/sort_options', [$this, 'addSortOptions']);
        add_filter('fluent_cart/review/sort_query', [$this, 'handleHelpfulSort'], 10, 3);
        add_action('fluent_cart/review/before_delete', [$this, 'cleanupVotes']);
    }

    public function addSortOptions($options)
    {
        $settings = ProductReviewService::getReviewSettings();

        if (!empty($settings['enable_helpful_votes']) && $settings['enable_helpful_votes'] === 'yes') {
            $options['helpful-DESC'] = __('Most Helpful', 'fluent-cart-pro');
        }

        return $options;
    }

    public function handleHelpfulSort($query, $sortBy, $sortOrder)
    {
        $sortOrder = strtoupper($sortOrder) === 'ASC' ? 'ASC' : 'DESC';

        // The votes relation ships in the free plugin — skip the sort when
        // the two plugins are on mismatched versions.
        if ($sortBy === 'helpful' && ReviewInteraction::isVotesRelationAvailable()) {
            $query->withCount([
                'votes as helpful_sort_count' => function ($voteQuery) {
                    $voteQuery->helpful();
                },
            ])
                ->orderBy('helpful_sort_count', $sortOrder)
                ->orderBy('id', 'DESC');
        }

        return $query;
    }

    public function cleanupVotes($review)
    {
        // Delete ALL interactions (votes and reports) for the removed review
        ReviewInteraction::where('review_id', $review->id)->delete();
    }
}
