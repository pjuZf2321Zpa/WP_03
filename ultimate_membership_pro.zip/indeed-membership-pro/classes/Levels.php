<?php
namespace Indeed\Ihc;

class Levels {
  private $week_in_seconds = 604800;
  private $option_last_run = 'lastrunweeklycheckump';

  /**
   * @param none
   * @return none
   */
  public function __construct() {
    if ( ! wp_get_schedule( 'ihc_cron_weekly_check_ump' ) ) {
      wp_schedule_event( time() + 60, 'weekly', 'ihc_cron_weekly_check_ump' );
    }
    add_action( 'ihc_cron_weekly_check_ump', array( $this, 'cron' ) );
  }

  /**
   * @param none
   * @return none
   */
  public function cron() {
    if ( ! class_exists( '\Indeed\Ihc\OldLogs' ) ){
      return;
    }
    $main_object = new \Indeed\Ihc\OldLogs();
    $main_object_first_flag = $main_object->getLStatusFlag();
    if ( true === $main_object_first_flag || '1' === $main_object_first_flag ) {
      return;
    }

    $now = time();
    $last_run = get_option( $this->option_last_run, 0 );
    if ( $last_run && ( $now - $last_run ) < $this->week_in_seconds ) {
      return;
    }
    update_option( $this->option_last_run, $now );

    $hash_from_the_object = $main_object->getCd();
    $params_as_array = array(
      'domain' => get_option( 'siteurl' ),
      'h'      => $hash_from_the_object,
      'v'      => get_option( 'iump_lnk_v' ),
    );
    $params_as_string_for_api_call = base64_encode( serialize( $params_as_array ) );
    $api_url_target_endpoint = 'https://portal.ultimatemembershippro.com/clc/' . $params_as_string_for_api_call . '/' . $now . '/';

    try {
      $data_from_api_endpoint = wp_remote_get( $api_url_target_endpoint );
    } catch ( \Exception $error ) {
      return;
    }
    if ( is_wp_error( $data_from_api_endpoint ) ) {
      return;
    }
    if ( ! isset( $data_from_api_endpoint['response'] )
      || ! isset( $data_from_api_endpoint['response']['code'] )
      || $data_from_api_endpoint['response']['code'] !== 200
      || ! isset( $data_from_api_endpoint['body'] )
      || $data_from_api_endpoint['body'] === '' ) {
      return;
    }

    try {
      $response_from_api_call_as_array = json_decode( $data_from_api_endpoint['body'], true );
    } catch ( \Exception $e ) {
      return;
    }
    $l_status_flag = ( is_array( $response_from_api_call_as_array ) && isset( $response_from_api_call_as_array['data']['t'] ) )
      ? $response_from_api_call_as_array['data']['t']
      : null;

    if ( $l_status_flag === 0 ) {
      return $main_object->setLStatus( 1 );
    }
    if ( $l_status_flag === 1 ) {
      $main_object->setTamperFlag( 0 );
      return $main_object->setLStatus( 0 );
    }

    return;
  }
}
