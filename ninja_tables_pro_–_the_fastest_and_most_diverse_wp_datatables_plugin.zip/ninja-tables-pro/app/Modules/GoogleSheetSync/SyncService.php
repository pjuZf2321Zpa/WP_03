<?php

namespace NinjaTablesPro\App\Modules\GoogleSheetSync;

defined('ABSPATH') || exit;

use NinjaTables\App\Modules\DataTables\Database\DynamicTableManager;
use NinjaTables\App\Modules\DataTables\Models\DynamicRow;
use NinjaTables\Framework\Support\Arr;

class SyncService
{
    private static $tmpDir    = 'ninja-tables-tmp';
    const JOB_PREFIX   = 'ninja_gsheet_sync_job_';

    /**
     * Initialize a chunked sync: download CSV, scan it, create job transient.
     * Returns token + total_rows for the frontend to drive chunk processing.
     */
    public static function initChunkedSync(int $tableId): array
    {
        $url = get_post_meta($tableId, '_ninja_tables_data_provider_url', true);

        if (!$url) {
            return ['status' => 'error', 'message' => __('No source URL configured.', 'ninja-tables-pro')];
        }

        // Check for existing active job
        $existingJob = self::getActiveJob($tableId);
        if ($existingJob) {
            return [
                'status'         => 'resuming',
                'token'          => Arr::get($existingJob, 'token'),
                'total_rows'     => (int) Arr::get($existingJob, 'total_rows', 0),
                'processed_rows' => (int) Arr::get($existingJob, 'processed_rows', 0),
            ];
        }

        $tempFile = self::downloadToTempFile($url);

        if (is_wp_error($tempFile)) {
            self::updateSyncState($tableId, [
                'last_status' => 'error',
                'last_error'  => $tempFile->get_error_message(),
            ]);

            return ['status' => 'error', 'message' => $tempFile->get_error_message()];
        }

        // Scan CSV
        $handle = fopen($tempFile, 'r'); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fopen -- chunked CSV read needs fseek/fgetcsv
        if (!$handle) {
            wp_delete_file($tempFile);
            return ['status' => 'error', 'message' => __('Unable to open downloaded CSV.', 'ninja-tables-pro')];
        }

        $header = fgetcsv($handle);
        if (!is_array($header) || empty($header)) {
            fclose($handle); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose -- chunked CSV read needs fseek/fgetcsv
            wp_delete_file($tempFile);
            return ['status' => 'error', 'message' => __('Unable to read CSV header.', 'ninja-tables-pro')];
        }

        $cursorAfterHeader = ftell($handle);
        fclose($handle); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose -- chunked CSV read needs fseek/fgetcsv

        // Deliberately no full row-count pass and no md5_file() here: both walk
        // the entire file, and on a large sheet that, on top of the download,
        // can blow the request timeout before any chunk is processed. The row
        // total is estimated incrementally from bytes consumed as chunks run
        // (see processChunk), and the content hash is computed once at
        // finalizeSync from the file we've already streamed. The background cron
        // path (handleCronSync) drives this same chunk job across ticks and does
        // its own cheap md5 "unchanged" check before starting.
        return self::buildChunkJob($tableId, $tempFile, $header, (int) $cursorAfterHeader, '', false);
    }

    /**
     * Prepare the dynamic table and create a chunk-sync job for an already
     * downloaded CSV. Shared by the frontend (initChunkedSync) and the
     * background cron (startCronSync) paths. Deletes $tempFile and returns an
     * error array if columns/headers don't line up.
     */
    private static function buildChunkJob(int $tableId, string $tempFile, array $header, int $cursorAfterHeader, string $fileHash, bool $cron): array
    {
        $columns = get_post_meta($tableId, '_ninja_table_columns', true);
        if (!is_array($columns) || empty($columns)) {
            wp_delete_file($tempFile);
            return ['status' => 'error', 'message' => __('Table columns are not configured.', 'ninja-tables-pro')];
        }

        $headerMap = self::buildHeaderMap($header, $columns);
        if (empty($headerMap)) {
            wp_delete_file($tempFile);
            return ['status' => 'error', 'message' => __('CSV headers do not match configured columns.', 'ninja-tables-pro')];
        }

        $tableManager = new DynamicTableManager($tableId);
        if (!$tableManager->tableExists()) {
            $tableManager->createTable();
        }
        $tableManager->syncColumns($columns);

        // Note: truncation is deferred to the first processChunk() call
        // to avoid data loss if the sync is interrupted before any rows are inserted.

        // Create job. total_rows starts unknown (0) and is estimated as chunks
        // run; file_hash is either supplied (cron pre-hash) or computed at
        // finalizeSync. file_size/header_bytes let processChunk estimate
        // progress without a pre-count pass. 'cron' marks jobs the scheduler
        // owns so handleCronSync only advances its own.
        $token = wp_generate_password(32, false, false);
        $job   = [
            'token'          => $token,
            'table_id'       => $tableId,
            'file_path'      => $tempFile,
            'file_hash'      => $fileHash,
            'file_size'      => (int) filesize($tempFile),
            'header_bytes'   => $cursorAfterHeader,
            'header_map'     => $headerMap,
            'total_rows'     => 0,
            'processed_rows' => 0,
            'cursor'         => $cursorAfterHeader,
            'created_at'     => time(),
            'truncated'      => false,
            'cron'           => $cron,
        ];

        set_transient(self::JOB_PREFIX . $token, $job, 2 * HOUR_IN_SECONDS);

        // Store token in sync state so we can resume on reload
        self::updateSyncState($tableId, [
            'last_status'    => 'syncing',
            'last_error'     => '',
            'active_token'   => $token,
            'last_checked_at' => time(),
        ]);

        return [
            'status'         => 'started',
            'token'          => $token,
            'total_rows'     => 0,
            'processed_rows' => 0,
        ];
    }

    /**
     * Process one chunk of the sync job.
     */
    public static function processChunk(string $token, int $chunkSize = 20000, int $expectedTableId = 0): array
    {
        $job = get_transient(self::JOB_PREFIX . $token);

        if (!$job || !is_array($job)) {
            return ['status' => 'error', 'message' => __('Sync session expired. Please start again.', 'ninja-tables-pro')];
        }

        $tableId = (int) Arr::get($job, 'table_id');

        if ($expectedTableId && $tableId !== $expectedTableId) {
            return ['status' => 'error', 'message' => __('Token does not belong to this table.', 'ninja-tables-pro')];
        }
        // Serialize chunk processing per table: the browser-driven loop and a
        // background cron tick must never advance the same job at once, or they
        // would read the same cursor and insert overlapping rows. A contended
        // caller just reports current progress and retries on its next pass.
        $procLock = '_ninja_gsheet_proc_lock_' . $tableId;
        if (get_transient($procLock)) {
            $processed = (int) Arr::get($job, 'processed_rows', 0);
            return [
                'status'         => 'processing',
                'processed_rows' => $processed,
                'total_rows'     => (int) Arr::get($job, 'total_rows', $processed),
                'completed'      => false,
                // Signals another worker holds the lock, so a cron budget loop can
                // yield instead of busy-spinning until its time budget expires.
                'contended'      => true,
            ];
        }
        set_transient($procLock, time(), 2 * MINUTE_IN_SECONDS);

        try {
            // Re-read under the lock in case another caller advanced the job
            // between the read above and acquiring the lock.
            $job = get_transient(self::JOB_PREFIX . $token);
            if (!is_array($job)) {
                return ['status' => 'error', 'message' => __('Sync session expired. Please start again.', 'ninja-tables-pro')];
            }

            $filePath      = Arr::get($job, 'file_path');
            $headerMap     = Arr::get($job, 'header_map', []);
            $processedRows = (int) Arr::get($job, 'processed_rows', 0);
            $cursor        = (int) Arr::get($job, 'cursor', 0);
            $fileSize      = (int) Arr::get($job, 'file_size', 0);
            $headerBytes   = (int) Arr::get($job, 'header_bytes', 0);

            if (!file_exists($filePath)) {
                delete_transient(self::JOB_PREFIX . $token);
                return ['status' => 'error', 'message' => __('CSV file is no longer available. Please start again.', 'ninja-tables-pro')];
            }

            // Already at end of file (nothing left to read) — finalize.
            if ($fileSize > 0 && $cursor >= $fileSize) {
                return self::finalizeSync($token, $job);
            }

            $handle = fopen($filePath, 'r'); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fopen -- chunked CSV read needs fseek/fgetcsv
            if (!$handle) {
                return ['status' => 'error', 'message' => __('Unable to open CSV file.', 'ninja-tables-pro')];
            }

            fseek($handle, $cursor);

            $batch    = [];
            $rowsRead = 0;
            // Also cap the raw lines scanned per call: empty rows don't count
            // toward $chunkSize, so a long run of them could otherwise make one
            // call walk the whole file and blow the per-chunk bound.
            $maxScan = $chunkSize * 5;
            $scanned = 0;
            // Flush to the DB in small sub-batches so peak memory stays bounded
            // regardless of $chunkSize — a whole chunk's rows are never all held
            // in memory at once.
            $flushSize  = max(500, (int) apply_filters('ninja_tables_gsheet_insert_batch', 2000));
            $dynamicRow = new DynamicRow($tableId);
            $insertBase = $processedRows;
            $truncated  = (bool) Arr::get($job, 'truncated');

            while ($rowsRead < $chunkSize && $scanned < $maxScan && ($row = fgetcsv($handle)) !== false) {
                $scanned++;
                if (self::isCsvRowEmpty($row)) {
                    continue;
                }

                $rowData = [];
                foreach ($headerMap as $csvIndex => $colKey) {
                    $rowData[$colKey] = isset($row[$csvIndex]) ? $row[$csvIndex] : '';
                }

                $batch[] = ninja_tables_sanitize_array($rowData);
                $rowsRead++;

                if (count($batch) >= $flushSize) {
                    // Truncate old data only when about to write the first batch,
                    // so an interrupted sync doesn't lose data before any arrives.
                    if (!$truncated) {
                        (new DynamicTableManager($tableId))->truncateTable();
                        $truncated = true;
                    }
                    $dynamicRow->batchInsert($batch, $insertBase);
                    $insertBase += count($batch);
                    $batch = [];
                }
            }

            $eof        = feof($handle);
            $nextCursor = ftell($handle);
            fclose($handle); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose -- chunked CSV read needs fseek/fgetcsv

            if (!empty($batch)) {
                if (!$truncated) {
                    (new DynamicTableManager($tableId))->truncateTable();
                    $truncated = true;
                }
                $dynamicRow->batchInsert($batch, $insertBase);
                $batch = [];
            }

            $job['truncated'] = $truncated;
            $processedRows += $rowsRead;

            // Completion is driven by end-of-file, not by a pre-computed total:
            // the guard on no rows AND a non-advancing cursor stops a stuck job.
            $completed = $eof || ($rowsRead === 0 && $nextCursor <= $cursor);

            // Estimate the row total from bytes consumed so far so the progress
            // bar can advance without a pre-count pass; it resolves to the exact
            // count once we reach the end.
            $totalRows = $processedRows;
            if (!$completed && $processedRows > 0 && $fileSize > $headerBytes) {
                $avgRowBytes = max(1, ($nextCursor - $headerBytes) / $processedRows);
                $totalRows   = max($processedRows, (int) round(($fileSize - $headerBytes) / $avgRowBytes));
            }

            // Update job
            $job['processed_rows'] = $processedRows;
            $job['cursor']         = $nextCursor;
            $job['total_rows']     = $totalRows;
            set_transient(self::JOB_PREFIX . $token, $job, 2 * HOUR_IN_SECONDS);

            if ($completed) {
                return self::finalizeSync($token, $job);
            }

            return [
                'status'         => 'processing',
                'processed_rows' => $processedRows,
                'total_rows'     => $totalRows,
                'completed'      => false,
            ];
        } finally {
            delete_transient($procLock);
        }
    }

    private static function finalizeSync(string $token, array $job): array
    {
        $tableId       = (int) Arr::get($job, 'table_id');
        $processedRows = (int) Arr::get($job, 'processed_rows', 0);
        $totalRows     = (int) Arr::get($job, 'total_rows', 0);
        $fileHash      = Arr::get($job, 'file_hash', '');
        $createdAt     = (int) Arr::get($job, 'created_at', time());
        $filePath      = Arr::get($job, 'file_path', '');

        $duration = round(time() - $createdAt, 1);

        // Hash is computed here (one pass, at the end) rather than up front, so
        // the background cron path can still short-circuit an unchanged sheet.
        if ($fileHash === '' && $filePath && file_exists($filePath)) {
            $fileHash = (string) md5_file($filePath);
        }

        self::updateSyncState($tableId, [
            'last_synced_at'  => time(),
            'last_checked_at' => time(),
            'last_hash'       => $fileHash,
            'last_row_count'  => $processedRows,
            'last_status'     => 'success',
            'last_error'      => '',
            'sync_duration'   => $duration,
            'active_token'    => '',
        ]);

        ninjaTablesClearTableDataCache($tableId);

        // Cleanup
        delete_transient(self::JOB_PREFIX . $token);
        if ($filePath && file_exists($filePath)) {
            wp_delete_file($filePath);
        }

        // Arm the next interval so auto-sync keeps running on schedule without
        // needing the table to be rendered again.
        self::scheduleNextSync($tableId);

        return [
            'status'         => 'success',
            'completed'      => true,
            'processed_rows' => $processedRows,
            'total_rows'     => $totalRows,
            'duration'       => $duration,
        ];
    }

    /**
     * Check for an active (resumable) sync job for this table.
     */
    public static function getActiveJob(int $tableId): ?array
    {
        $state = self::getSyncState($tableId);
        $token = Arr::get($state, 'active_token', '');

        if (!$token) {
            return null;
        }

        $job = get_transient(self::JOB_PREFIX . $token);

        if (!$job || !is_array($job)) {
            self::updateSyncState($tableId, ['active_token' => '', 'last_status' => 'error', 'last_error' => 'Sync session expired.']);
            return null;
        }

        if (!file_exists(Arr::get($job, 'file_path', ''))) {
            delete_transient(self::JOB_PREFIX . $token);
            self::updateSyncState($tableId, ['active_token' => '', 'last_status' => 'error', 'last_error' => 'CSV file expired.']);
            return null;
        }

        return $job;
    }

    /**
     * Start a background sync job: download once, skip cheaply if the sheet is
     * unchanged, otherwise create a cron-owned chunk job that later cron ticks
     * advance. Returns the job token, or '' when nothing was started (no URL,
     * download/parse error, or data unchanged). The heavy row import is NOT done
     * here — it is spread across processChunk() calls by runCronChunks().
     */
    private static function startCronSync(int $tableId): string
    {
        $url = get_post_meta($tableId, '_ninja_tables_data_provider_url', true);
        if (!$url) {
            self::updateSyncState($tableId, ['last_status' => 'error', 'last_error' => 'No source URL configured.', 'last_checked_at' => time()]);
            return '';
        }

        $tempFile = self::downloadToTempFile($url);
        if (is_wp_error($tempFile)) {
            self::updateSyncState($tableId, ['last_status' => 'error', 'last_error' => $tempFile->get_error_message(), 'last_checked_at' => time()]);
            return '';
        }

        // Cheap "unchanged" short-circuit (one C-level pass) before importing.
        $newHash = (string) md5_file($tempFile);
        if ($newHash !== '' && $newHash === Arr::get(self::getSyncState($tableId), 'last_hash', '')) {
            wp_delete_file($tempFile);
            self::updateSyncState($tableId, ['last_checked_at' => time(), 'last_status' => 'success', 'last_error' => '']);
            // Unchanged, but still re-arm the next interval.
            self::scheduleNextSync($tableId);
            return '';
        }

        $handle = fopen($tempFile, 'r'); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fopen -- chunked CSV read needs fseek/fgetcsv
        if (!$handle) {
            wp_delete_file($tempFile);
            self::updateSyncState($tableId, ['last_status' => 'error', 'last_error' => 'Unable to open downloaded CSV.', 'last_checked_at' => time()]);
            return '';
        }
        $header = fgetcsv($handle);
        if (!is_array($header) || empty($header)) {
            fclose($handle); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose -- chunked CSV read needs fseek/fgetcsv
            wp_delete_file($tempFile);
            self::updateSyncState($tableId, ['last_status' => 'error', 'last_error' => 'Unable to read CSV header.', 'last_checked_at' => time()]);
            return '';
        }
        $cursorAfterHeader = ftell($handle);
        fclose($handle); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose -- chunked CSV read needs fseek/fgetcsv

        $result = self::buildChunkJob($tableId, $tempFile, $header, (int) $cursorAfterHeader, $newHash, true);

        if (Arr::get($result, 'status') !== 'started') {
            self::updateSyncState($tableId, ['last_status' => 'error', 'last_error' => (string) Arr::get($result, 'message', 'Sync could not start.'), 'last_checked_at' => time()]);
            return '';
        }

        return (string) Arr::get($result, 'token', '');
    }

    /**
     * Advance a cron-owned chunk job under a per-invocation row/time budget, then
     * either finish or reschedule the next tick. The budget keeps each cron
     * request well inside host limits; the short lock (comfortably longer than
     * the budget) stops overlapping cron spawns from double-processing the job.
     */
    private static function runCronChunks(string $token, int $tableId): void
    {
        $timeBudget = max(5, (int) apply_filters('ninja_tables_gsheet_cron_time_budget', 20));
        $rowBudget  = max(1000, (int) apply_filters('ninja_tables_gsheet_cron_row_budget', 40000));
        // Process the cron job in small units rather than 20k at a time, so the
        // time budget below is re-checked frequently and can actually bound each
        // step's wall-clock — a single huge chunk would otherwise run to the end
        // regardless of the budget.
        $chunkRows  = max(500, (int) apply_filters('ninja_tables_gsheet_cron_chunk_rows', 5000));

        $lockKey = '_ninja_gsheet_cron_lock_' . $tableId;
        if (get_transient($lockKey)) {
            return;
        }
        set_transient($lockKey, time(), $timeBudget * 3);

        $start       = time();
        $rowsThisRun = 0;
        $done        = false;

        try {
            while (true) {
                $current = get_transient(self::JOB_PREFIX . $token);
                $before  = is_array($current) ? (int) Arr::get($current, 'processed_rows', 0) : 0;

                $result = self::processChunk($token, $chunkRows, $tableId);

                if (Arr::get($result, 'status') !== 'processing') {
                    // 'success' (finalized) or 'error' — the job is over either way.
                    $done = true;
                    break;
                }

                if (!empty($result['contended'])) {
                    // Another worker (a browser-driven chunk loop) holds the lock.
                    // Yield instead of busy-spinning; the reschedule below picks
                    // the job back up shortly.
                    break;
                }

                $rowsThisRun += (int) Arr::get($result, 'processed_rows', $before) - $before;

                if ($rowsThisRun >= $rowBudget || (time() - $start) >= $timeBudget) {
                    break; // budget spent — resume on the next tick
                }
            }
        } finally {
            delete_transient($lockKey);
        }

        if (!$done && !wp_next_scheduled('ninja_tables_gsheet_sync', [$tableId])) {
            wp_schedule_single_event(time() + MINUTE_IN_SECONDS, 'ninja_tables_gsheet_sync', [$tableId]);
            if (function_exists('spawn_cron')) {
                spawn_cron();
            }
        }
    }

    /**
     * Arm the next per-table interval event so background sync runs on schedule
     * without depending on the table being rendered. Called when the sync config
     * changes (reconcile) and after every completed or unchanged run. A disabled
     * table has any pending event cleared. With $reconcile a queued future event
     * is replaced (the interval may have changed); otherwise an existing one is
     * kept.
     */
    public static function scheduleNextSync(int $tableId, bool $reconcile = false): void
    {
        $config = get_post_meta($tableId, '_ninja_gsheet_sync_config', true);

        if (!is_array($config) || empty($config['enabled'])) {
            wp_clear_scheduled_hook('ninja_tables_gsheet_sync', [$tableId]);
            return;
        }

        // Only a live CRON job is left alone — it reschedules its own hook and a
        // stray interval event would race it. A frontend-driven job never touches
        // the cron hook, so we still arm the interval alongside it: that way an
        // abandoned browser sync can't leave the chain with nothing scheduled.
        $job = self::getActiveJob($tableId);
        if (is_array($job) && !empty($job['cron'])) {
            return;
        }

        $existing = wp_next_scheduled('ninja_tables_gsheet_sync', [$tableId]);
        if ($existing && !$reconcile) {
            return;
        }
        if ($existing) {
            wp_clear_scheduled_hook('ninja_tables_gsheet_sync', [$tableId]);
        }

        $interval = max(60, (int) Arr::get($config, 'sync_interval', 3600));
        wp_schedule_single_event(time() + $interval, 'ninja_tables_gsheet_sync', [$tableId]);
    }

    /**
     * Recovery only: if the interval event went missing (a table that was never
     * rendered before, a dropped cron event) and the table is overdue, arm one
     * now. The normal schedule is kept alive by scheduleNextSync() at config
     * change and after each run, so this rarely fires.
     */
    public static function maybeScheduleSync(int $tableId): void
    {
        $config = get_post_meta($tableId, '_ninja_gsheet_sync_config', true);

        if (!is_array($config) || empty($config['enabled'])) {
            return;
        }

        // Already armed (the common case) — nothing to recover.
        if (wp_next_scheduled('ninja_tables_gsheet_sync', [$tableId])) {
            return;
        }

        // A genuinely active sync arms its own continuation. Validate the token,
        // though: getActiveJob() drops a stale active_token (abandoned browser
        // sync or an expired job) so a dead token can't block auto-sync forever.
        if (self::getActiveJob($tableId)) {
            return;
        }

        $interval    = max(60, (int) Arr::get($config, 'sync_interval', 3600));
        $lastChecked = (int) Arr::get(self::getSyncState($tableId), 'last_checked_at', 0);

        if ((time() - $lastChecked) < $interval) {
            return;
        }

        self::updateSyncState($tableId, ['last_checked_at' => time()]);
        wp_schedule_single_event(time(), 'ninja_tables_gsheet_sync', [$tableId]);

        if (function_exists('spawn_cron')) {
            spawn_cron();
        }
    }

    public static function handleCronSync(int $tableId): void
    {
        $post = get_post($tableId);
        if (!$post || $post->post_type !== 'ninja-table') {
            return;
        }

        // getActiveJob() clears a stale active_token so a dead job never blocks
        // future syncs. If a job is already running, continue it only when this
        // cron chain owns it — a frontend-driven chunk sync is advanced by the
        // browser, never here.
        $job = self::getActiveJob($tableId);
        if (is_array($job)) {
            if (!empty($job['cron'])) {
                self::runCronChunks((string) Arr::get($job, 'token'), $tableId);
            } else {
                // A frontend-driven sync owns the file; leave it, but keep the
                // recurring chain alive so the interval survives the collision
                // (scheduleNextSync no-ops while that job is active and is armed
                // again by its finalize).
                self::scheduleNextSync($tableId);
            }
            return;
        }

        // Starting a job downloads and hashes the whole file; do the row import
        // on the following tick so no single cron request carries the download,
        // the hash pass, and thousands of row transforms together.
        $token = self::startCronSync($tableId);
        if ($token) {
            if (!wp_next_scheduled('ninja_tables_gsheet_sync', [$tableId])) {
                wp_schedule_single_event(time() + 1, 'ninja_tables_gsheet_sync', [$tableId]);
                if (function_exists('spawn_cron')) {
                    spawn_cron();
                }
            }
        } else {
            // startCronSync returned no token: either data was unchanged (it
            // re-armed the interval itself) or the download/parse failed. Re-arm
            // the next interval so a transient failure never ends auto-sync.
            self::scheduleNextSync($tableId);
        }
    }

    public static function downloadToTempFile(string $url)
    {
        $uploadsDir = wp_upload_dir();
        $baseDir    = Arr::get($uploadsDir, 'basedir', '');

        if (!$baseDir) {
            return new \WP_Error('upload_dir_missing', __('WordPress uploads directory not available.', 'ninja-tables-pro'));
        }

        $tmpDir = $baseDir . '/' . self::$tmpDir;

        if (!file_exists($tmpDir)) {
            wp_mkdir_p($tmpDir);

            // Apache protection
            $htaccess = $tmpDir . '/.htaccess';
            if (!file_exists($htaccess)) {
                file_put_contents($htaccess, "Deny from all\n"); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
            }

            // Prevent directory listing + silence
            $indexFile = $tmpDir . '/index.php';
            if (!file_exists($indexFile)) {
                file_put_contents($indexFile, "<?php\n// Silence is golden."); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
            }
        }

        $tempFile = $tmpDir . '/gsheet_' . wp_generate_password(16, false, false) . '.csv';

        // Enforce the size cap up front where we can: a HEAD that advertises a
        // Content-Length lets us reject an oversized file before streaming it to
        // disk. Servers that omit Content-Length (Google's CSV export sometimes
        // does) fall through to the post-download check below as a backstop.
        $maxSize = (int) apply_filters('ninja_tables_gsheet_max_csv_size', 100 * 1024 * 1024); // 100 MB

        $head = wp_safe_remote_head($url, ['timeout' => 15, 'redirection' => 5]);
        if (!is_wp_error($head)) {
            $advertised = (int) wp_remote_retrieve_header($head, 'content-length');
            if ($advertised > $maxSize) {
                return new \WP_Error('file_too_large', __('CSV file exceeds the maximum allowed size.', 'ninja-tables-pro'));
            }
        }

        $response = wp_safe_remote_get($url, [
            'timeout'  => 120,
            'stream'   => true,
            'filename' => $tempFile,
        ]);

        if (is_wp_error($response)) {
            if (file_exists($tempFile)) {
                wp_delete_file($tempFile);
            }
            return $response;
        }

        $code = wp_remote_retrieve_response_code($response);
        if ($code !== 200) {
            if (file_exists($tempFile)) {
                wp_delete_file($tempFile);
            }
            /* translators: %d: HTTP status code */
            return new \WP_Error('download_failed', sprintf(__('HTTP %d from source URL.', 'ninja-tables-pro'), $code));
        }

        if (!file_exists($tempFile) || filesize($tempFile) === 0) {
            if (file_exists($tempFile)) {
                wp_delete_file($tempFile);
            }
            return new \WP_Error('empty_download', __('Downloaded file is empty.', 'ninja-tables-pro'));
        }

        // Restrict file permissions to owner-only read/write
        chmod($tempFile, 0600); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_chmod -- owner-only permissions on the temp file

        // Backstop for servers that didn't advertise Content-Length in the HEAD.
        if (filesize($tempFile) > $maxSize) {
            wp_delete_file($tempFile);
            return new \WP_Error('file_too_large', __('CSV file exceeds the maximum allowed size.', 'ninja-tables-pro'));
        }

        return $tempFile;
    }

    /**
     * Strip UTF-8 BOM from a string. Google Sheets CSV exports often include a BOM.
     */
    private static function stripBom(string $str): string
    {
        if (substr($str, 0, 3) === "\xEF\xBB\xBF") {
            return substr($str, 3);
        }
        return $str;
    }

    private static function buildHeaderMap(array $csvHeader, array $columns): array
    {
        // Strip BOM from first header field
        if (!empty($csvHeader[0])) {
            $csvHeader[0] = self::stripBom($csvHeader[0]);
        }

        $map = [];
        foreach ($columns as $column) {
            $key          = Arr::get($column, 'key', '');
            $originalName = Arr::get($column, 'original_name', Arr::get($column, 'name', ''));

            foreach ($csvHeader as $csvIndex => $csvColName) {
                $csvColName = trim($csvColName);
                if ($csvColName === $originalName || $csvColName === $key || $csvColName === Arr::get($column, 'name', '')) {
                    $map[$csvIndex] = $key;
                    break;
                }
            }
        }
        return $map;
    }

    public static function getSyncState(int $tableId): array
    {
        $state = get_post_meta($tableId, '_ninja_gsheet_sync_state', true);
        return is_array($state) ? $state : [];
    }

    public static function updateSyncState(int $tableId, array $updates): void
    {
        $state = self::getSyncState($tableId);
        $state = array_merge($state, $updates);
        update_post_meta($tableId, '_ninja_gsheet_sync_state', $state);
    }

    public static function cleanupTempFiles(): void
    {
        $uploadsDir = wp_upload_dir();
        $tmpDir     = Arr::get($uploadsDir, 'basedir', '') . '/' . self::$tmpDir;

        if (!is_dir($tmpDir)) {
            return;
        }

        $files = glob($tmpDir . '/gsheet_*.csv');

        if (!$files) {
            return;
        }

        $twoHoursAgo = time() - (2 * HOUR_IN_SECONDS);

        foreach ($files as $file) {
            if (filemtime($file) < $twoHoursAgo) {
                wp_delete_file($file);
            }
        }
    }

    private static function isCsvRowEmpty($row): bool
    {
        if (!is_array($row) || $row === []) {
            return true;
        }
        foreach ($row as $value) {
            if ($value !== null && trim((string) $value) !== '') {
                return false;
            }
        }
        return true;
    }
}
