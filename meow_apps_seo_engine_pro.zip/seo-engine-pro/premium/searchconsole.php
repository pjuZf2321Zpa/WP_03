<?php

class MeowPro_MWSEO_SearchConsole
{
	private $core = null;
	private $client_id = null;
	private $client_secret = null;
	private $property = null;
	private $tracked_properties = [];
	private $use_cache = false;

	private $current_access_token = null;
	private $current_refresh_token = null;
	private $current_expires_at = null;
	private $last_api_error = null;

	const TOKEN_URL = 'https://www.googleapis.com/oauth2/v4/token';
	const AUTH_URL = 'https://accounts.google.com/o/oauth2/v2/auth';
	const SCOPE_URL = 'https://www.googleapis.com/auth/webmasters.readonly';
	const STATE_PARAM = 'mwseo_gsc';

	const SITES_URL = 'https://searchconsole.googleapis.com/webmasters/v3/sites';
	const SEARCH_ANALYTICS_URL = 'https://searchconsole.googleapis.com/webmasters/v3/sites/%s/searchAnalytics/query';

	// Tokens live in an option, not a transient: an external object cache (Redis, Memcache)
	// or any cache-flushing plugin wipes transients, which silently disconnected Google.
	const OPTION_TOKEN_INFO = 'mwseo_google_search_console_token_info';
	const TRANSIENT_REPORT_PREFIX = 'mwseo_gsc_report_';

	// Approximate CTR curve by position (Google search desktop, 2024 industry averages).
	// Used to estimate traffic lift for opportunities — rough but useful for "if you moved from X to Y".
	private static $ctr_curve = [
		1  => 0.30, 2  => 0.16, 3  => 0.10, 4  => 0.07, 5  => 0.05,
		6  => 0.04, 7  => 0.03, 8  => 0.025, 9  => 0.02, 10 => 0.018,
		11 => 0.014, 12 => 0.011, 13 => 0.009, 14 => 0.008, 15 => 0.007,
	];

	public function __construct( $core ) {
		$this->core = $core;
		$this->init();
		$this->handle_authentication();
	}

	#region Authentication

	public function init() {
		// Reuse the GA OAuth credentials — a single GCP OAuth client supports
		// multiple Google APIs, so the user only sets up Google Cloud once.
		$this->client_id = $this->core->get_option( 'google_analytics_client_id', '' );
		$this->client_secret = $this->core->get_option( 'google_analytics_client_secret', '' );
		$this->property = $this->core->get_option( 'google_search_console_property', '' );
		$tracked = $this->core->get_option( 'google_search_console_properties', [] );
		$this->tracked_properties = is_array( $tracked ) ? array_values( array_filter( $tracked ) ) : [];
		$this->use_cache = $this->core->get_option( 'analytics_cache', false );

		if ( empty( $this->client_id ) || empty( $this->client_secret ) ) {
			return;
		}

		$token_info = $this->get_token_info();
		if ( is_array( $token_info ) ) {
			$this->current_access_token = $token_info['access_token'] ?? null;
			$this->current_refresh_token = $token_info['refresh_token'] ?? null;
			$this->current_expires_at = $token_info['expires_at'] ?? null;
		}
	}

	/**
	 * Read the stored token info, migrating it out of the legacy transient on the way.
	 */
	private function get_token_info() {
		$token_info = get_option( self::OPTION_TOKEN_INFO );

		if ( empty( $token_info ) ) {
			$legacy = get_transient( self::OPTION_TOKEN_INFO );
			if ( is_array( $legacy ) ) {
				$token_info = $legacy;
				$this->set_token_info( $legacy );
			}
			delete_transient( self::OPTION_TOKEN_INFO );
		}

		return is_array( $token_info ) ? $token_info : null;
	}

	private function set_token_info( $token_info ) {
		update_option( self::OPTION_TOKEN_INFO, $token_info, false );
	}

	public function get_redirect_url() {
		return admin_url( 'admin.php?page=mwseo_settings&nekoTab=settings' );
	}

	public function get_auth_url() {
		if ( empty( $this->client_id ) ) {
			return null;
		}
		$params = [
			'response_type' => 'code',
			'client_id' => $this->client_id,
			'redirect_uri' => $this->get_redirect_url(),
			'scope' => self::SCOPE_URL,
			'access_type' => 'offline',
			'prompt' => 'consent',
			'state' => self::STATE_PARAM,
		];
		return self::AUTH_URL . '?' . http_build_query( $params );
	}

	public function is_authenticated() {
		if ( empty( $this->client_id ) || empty( $this->client_secret ) ) {
			return false;
		}
		if ( !$this->current_access_token || !$this->current_refresh_token || !$this->current_expires_at ) {
			return false;
		}
		if ( time() >= $this->current_expires_at ) {
			if ( !$this->refresh_access_token() ) {
				return false;
			}
		}
		return true;
	}

	public function unlink() {
		$this->core->log( "🔗 Unlinking Google Search Console." );
		delete_option( self::OPTION_TOKEN_INFO );
		delete_transient( self::OPTION_TOKEN_INFO );
		$this->current_access_token = null;
		$this->current_refresh_token = null;
		$this->current_expires_at = null;
		return true;
	}

	public function handle_authentication() {
		// Only act on OAuth callbacks intended for this module.
		if ( !isset( $_GET['code'] ) || empty( $_GET['state'] ) || $_GET['state'] !== self::STATE_PARAM ) {
			return false;
		}
		$code = sanitize_text_field( $_GET['code'] );
		if ( empty( $code ) ) {
			return false;
		}
		return $this->exchange_code( $code );
	}

	private function exchange_code( $code ) {
		$result = wp_remote_post( self::TOKEN_URL, [
			'body' => [
				'code' => $code,
				'client_id' => $this->client_id,
				'client_secret' => $this->client_secret,
				'redirect_uri' => $this->get_redirect_url(),
				'grant_type' => 'authorization_code',
			],
		] );

		if ( is_wp_error( $result ) ) {
			$this->core->log( "⚠️ GSC token exchange failed: " . $result->get_error_message() );
			return false;
		}

		$json = json_decode( wp_remote_retrieve_body( $result ) );
		if ( !$json || isset( $json->error ) ) {
			$err = isset( $json->error ) ? $json->error : 'unknown';
			$this->core->log( "⚠️ GSC token exchange error: " . $err );
			return false;
		}

		$expires_in = $json->expires_in ?? 3600;
		$token_info = [
			'expires_in' => $expires_in,
			'expires_at' => time() + $expires_in,
			'access_token' => $json->access_token ?? null,
			'refresh_token' => $json->refresh_token ?? null,
		];
		$this->set_token_info( $token_info );

		$this->current_access_token = $token_info['access_token'];
		$this->current_refresh_token = $token_info['refresh_token'];
		$this->current_expires_at = $token_info['expires_at'];

		$this->core->log( "✅ Google Search Console connected." );
		return true;
	}

	private function refresh_access_token() {
		$result = wp_remote_post( self::TOKEN_URL, [
			'body' => [
				'client_id' => $this->client_id,
				'client_secret' => $this->client_secret,
				'refresh_token' => $this->current_refresh_token,
				'grant_type' => 'refresh_token',
			],
		] );

		if ( is_wp_error( $result ) ) {
			$this->core->log( "⚠️ GSC token refresh failed: " . $result->get_error_message() );
			return false;
		}

		$json = json_decode( wp_remote_retrieve_body( $result ) );
		if ( !$json || isset( $json->error ) ) {
			$this->core->log( "⚠️ GSC token refresh error." );
			return false;
		}

		$expires_in = $json->expires_in ?? 3600;
		$token_info = [
			'expires_in' => $expires_in,
			'expires_at' => time() + $expires_in,
			'access_token' => $json->access_token ?? null,
			'refresh_token' => $this->current_refresh_token,
		];
		$this->set_token_info( $token_info );

		$this->current_access_token = $token_info['access_token'];
		$this->current_expires_at = $token_info['expires_at'];

		return true;
	}

	#endregion

	#region API plumbing

	public function get_last_error() {
		return $this->last_api_error;
	}

	public function get_property() {
		return $this->property;
	}

	public function set_property( $property ) {
		$this->property = $property;
		$this->core->update_option( 'google_search_console_property', $property );
		// The default is implicitly tracked.
		if ( $property && !in_array( $property, $this->tracked_properties, true ) ) {
			$this->tracked_properties[] = $property;
			$this->core->update_option( 'google_search_console_properties', $this->tracked_properties );
		}
		return true;
	}

	public function get_tracked_properties() {
		// Always include the active default in the effective tracked set.
		$tracked = $this->tracked_properties;
		if ( $this->property && !in_array( $this->property, $tracked, true ) ) {
			$tracked[] = $this->property;
		}
		return $tracked;
	}

	public function set_tracked_properties( $properties ) {
		$properties = is_array( $properties ) ? array_values( array_unique( array_filter( $properties ) ) ) : [];
		$this->tracked_properties = $properties;
		$this->core->update_option( 'google_search_console_properties', $properties );
		return true;
	}

	public function toggle_tracked_property( $property, $tracked ) {
		if ( empty( $property ) ) return false;
		$current = $this->tracked_properties;
		$is_in = in_array( $property, $current, true );
		if ( $tracked && !$is_in ) {
			$current[] = $property;
		} else if ( !$tracked && $is_in ) {
			$current = array_values( array_diff( $current, [ $property ] ) );
			// Don't allow un-tracking the active default — it must stay queryable.
			if ( $property === $this->property ) {
				return false;
			}
		}
		return $this->set_tracked_properties( $current );
	}

	/**
	 * Given a page URL (typically a post permalink), pick the best-matching tracked
	 * property. This is what makes multi-domain Polylang/WPML "just work" — a French
	 * post on japonsecret.fr gets queried against the japonsecret.fr property, even
	 * if the default property is offbeatjapan.com.
	 *
	 * Match preference:
	 *   1. Exact URL-prefix match (the longest prefix wins)
	 *   2. Domain property whose host equals the URL host
	 *   3. Domain property whose host is a parent of the URL host (covers subdomains)
	 *   4. Fall back to the configured default.
	 */
	public function resolve_property_for_url( $url ) {
		if ( empty( $url ) ) return $this->property;

		$parsed = wp_parse_url( $url );
		$url_host = isset( $parsed['host'] ) ? strtolower( $parsed['host'] ) : '';
		if ( $url_host === '' ) return $this->property;

		$tracked = $this->get_tracked_properties();

		// 1. URL-prefix match — find longest matching prefix
		$best_prefix = null;
		$best_prefix_len = 0;
		foreach ( $tracked as $prop ) {
			if ( strpos( $prop, 'sc-domain:' ) === 0 ) continue;
			if ( strpos( $url, $prop ) === 0 && strlen( $prop ) > $best_prefix_len ) {
				$best_prefix = $prop;
				$best_prefix_len = strlen( $prop );
			}
		}
		if ( $best_prefix !== null ) return $best_prefix;

		// 2 & 3. Domain property match (exact host, then parent host for subdomains)
		$domain_exact = null;
		$domain_parent = null;
		foreach ( $tracked as $prop ) {
			if ( strpos( $prop, 'sc-domain:' ) !== 0 ) continue;
			$prop_host = strtolower( substr( $prop, strlen( 'sc-domain:' ) ) );
			if ( $url_host === $prop_host ) {
				$domain_exact = $prop;
				break;
			}
			if ( substr( $url_host, -strlen( '.' . $prop_host ) ) === '.' . $prop_host ) {
				if ( $domain_parent === null
					|| strlen( $prop_host ) > strlen( substr( $domain_parent, strlen( 'sc-domain:' ) ) ) ) {
					$domain_parent = $prop;
				}
			}
		}
		if ( $domain_exact !== null ) return $domain_exact;
		if ( $domain_parent !== null ) return $domain_parent;

		// 4. Fallback
		return $this->property;
	}

	public function list_properties() {
		$this->last_api_error = null;

		if ( !$this->is_authenticated() ) {
			$this->last_api_error = 'Not authenticated.';
			return false;
		}

		$response = wp_remote_get( self::SITES_URL, [
			'headers' => [ 'Authorization' => 'Bearer ' . $this->current_access_token ],
			'timeout' => 30,
		] );

		if ( is_wp_error( $response ) ) {
			$this->last_api_error = $response->get_error_message();
			return false;
		}

		$code = wp_remote_retrieve_response_code( $response );
		$raw_body = wp_remote_retrieve_body( $response );
		$body = json_decode( $raw_body, true );

		if ( $code !== 200 ) {
			$this->last_api_error = isset( $body['error']['message'] )
				? sprintf( 'Google API error (%d): %s', $code, $body['error']['message'] )
				: sprintf( 'Google API returned HTTP %d', $code );
			$this->core->log( "❌ GSC list_properties: " . $this->last_api_error );
			return false;
		}

		if ( !is_array( $body ) || !isset( $body['siteEntry'] ) ) {
			$this->last_api_error = 'Google returned an unexpected response shape (no siteEntry).';
			return [];
		}

		$all = $body['siteEntry'];
		// Surface ALL properties — including unverified — so the user can see what's there,
		// but mark verification level. Only verified/owned can be queried for Search Analytics.
		$out = array_map( function( $entry ) {
			$level = $entry['permissionLevel'] ?? '';
			return [
				'site_url' => $entry['siteUrl'] ?? '',
				'permission' => $level,
				'verified' => ( $level !== 'siteUnverifiedUser' ),
			];
		}, $all );

		if ( empty( $out ) ) {
			$this->last_api_error = 'Your Google account has no Search Console properties. Add a verified site at https://search.google.com/search-console first.';
		}

		return $out;
	}

	private function query_search_analytics( $body, $property_override = null ) {
		if ( !$this->is_authenticated() ) {
			$this->last_api_error = 'Not authenticated.';
			return false;
		}
		$property = $property_override !== null && $property_override !== ''
			? $property_override : $this->property;
		if ( empty( $property ) ) {
			$this->last_api_error = 'No Search Console property selected. Set one in Settings → Google → Search Console, or pass a property argument.';
			return false;
		}

		$url = sprintf( self::SEARCH_ANALYTICS_URL, rawurlencode( $property ) );

		$response = wp_remote_post( $url, [
			'headers' => [
				'Authorization' => 'Bearer ' . $this->current_access_token,
				'Content-Type' => 'application/json',
			],
			'body' => wp_json_encode( $body ),
			'timeout' => 60,
		] );

		if ( is_wp_error( $response ) ) {
			$this->last_api_error = $response->get_error_message();
			return false;
		}

		$code = wp_remote_retrieve_response_code( $response );
		$decoded = json_decode( wp_remote_retrieve_body( $response ), true );

		if ( $code !== 200 ) {
			$this->last_api_error = $decoded['error']['message'] ?? "HTTP $code";
			$this->core->log( "❌ GSC API error: " . $this->last_api_error );
			return false;
		}

		return $decoded;
	}

	private function cached_query( $cache_key, $body, $property_override = null, $fresh = false, $cached_only = false ) {
		$property = $property_override !== null && $property_override !== ''
			? $property_override : $this->property;
		$transient = self::TRANSIENT_REPORT_PREFIX . md5( $property . '|' . $cache_key );

		if ( !$fresh ) {
			$cached = get_transient( $transient );
			if ( $cached !== false ) {
				return $cached;
			}
		}

		// Cached-only callers (the posts list enriches its rows on every load) must never
		// block on a live GSC round trip; they take whatever the cache has, or nothing.
		if ( $cached_only ) {
			return false;
		}

		$result = $this->query_search_analytics( $body, $property_override );
		// GSC data only refreshes daily on Google's side, so a 6h cache is
		// generous in both directions: agents and the UI feel snappy, the
		// API quota isn't drained, and stale data is bounded.
		if ( $result !== false && !empty( $result['rows'] ) ) {
			set_transient( $transient, $result, 6 * HOUR_IN_SECONDS );
		}
		return $result;
	}

	#endregion

	#region Public reporting helpers

	/**
	 * Resolve a URL on any of this WP install's domains (Polylang multi-domain)
	 * back to a local post_id. url_to_postid() alone fails when the URL host
	 * differs from home_url(), which is exactly the Polylang multi-domain case
	 * (FR posts on japonsecret.fr, EN on offbeatjapan.com). Falls back to a
	 * slug-based DB lookup, language-filtered when Polylang is active.
	 */
	public function resolve_local_post_id( $url ) {
		if ( empty( $url ) ) return 0;

		$id = url_to_postid( $url );
		if ( $id ) return (int) $id;

		$path = wp_parse_url( $url, PHP_URL_PATH );
		$url_host = strtolower( (string) wp_parse_url( $url, PHP_URL_HOST ) );
		if ( !$path || !$url_host ) return 0;

		$slug = basename( trim( $path, '/' ) );
		if ( $slug === '' ) return 0;

		// Polylang multi-domain: identify which language this URL host belongs to.
		$target_lang = null;
		if ( function_exists( 'pll_languages_list' ) ) {
			$pll_options = get_option( 'polylang' );
			if ( !empty( $pll_options['domains'] ) && is_array( $pll_options['domains'] ) ) {
				foreach ( $pll_options['domains'] as $lang_slug => $lang_url ) {
					$lang_host = strtolower( (string) wp_parse_url( $lang_url, PHP_URL_HOST ) );
					if ( $lang_host === $url_host ) {
						$target_lang = $lang_slug;
						break;
					}
				}
			}
		}

		if ( $target_lang ) {
			$matches = get_posts( [
				'name' => $slug,
				'post_type' => [ 'post', 'page' ],
				'posts_per_page' => 1,
				'post_status' => 'publish',
				'lang' => $target_lang,
				'suppress_filters' => false,
			] );
			if ( !empty( $matches ) ) return (int) $matches[0]->ID;
		}

		// Last-resort: slug lookup without language filter (best-effort).
		global $wpdb;
		$id = (int) $wpdb->get_var( $wpdb->prepare(
			"SELECT ID FROM {$wpdb->posts}
			 WHERE post_name = %s AND post_status = 'publish'
			 AND post_type IN ('post','page')
			 ORDER BY post_date DESC LIMIT 1",
			$slug
		) );
		return $id ?: 0;
	}

	private function date_range( $days ) {
		// GSC has ~2-3 day reporting lag; end_date is "today - 2 days" so we don't
		// pull empty trailing days. Inclusive range — N days means N rows.
		return [
			'start' => date( 'Y-m-d', strtotime( "-" . ( $days + 1 ) . " days" ) ),
			'end' => date( 'Y-m-d', strtotime( '-2 days' ) ),
		];
	}

	/**
	 * Site-wide summary: total clicks/impressions/avg position for the period,
	 * with deltas vs. the prior equivalent period. Used by the dashboard tab.
	 */
	public function get_summary( $args = [] ) {
		$days = isset( $args['days'] ) ? max( 7, min( 90, (int) $args['days'] ) ) : 28;
		$property = !empty( $args['property'] ) ? (string) $args['property'] : null;
		$fresh = !empty( $args['fresh'] );

		$range = $this->date_range( $days );
		$prior_end = date( 'Y-m-d', strtotime( $range['start'] . ' -1 day' ) );
		$prior_start = date( 'Y-m-d', strtotime( $prior_end . ' -' . ( $days - 1 ) . ' days' ) );

		$current = $this->query_summary_for_period( $range['start'], $range['end'], $property, $fresh );
		$prior = $this->query_summary_for_period( $prior_start, $prior_end, $property, $fresh );

		$trends = [
			'clicks' => $this->build_trend( $current['clicks'], $prior['clicks'], false ),
			'impressions' => $this->build_trend( $current['impressions'], $prior['impressions'], false ),
			'position' => $this->build_trend( $current['position'], $prior['position'], true ),
		];

		return [
			'period_days' => $days,
			'property_used' => $property ?: $this->property,
			'current' => $current,
			'prior' => $prior,
			'trends' => $trends,
		];
	}

	// Daily clicks/impressions over the window, for the dashboard chart. One date-grouped
	// call (6h cached); days are zero-filled so the chart always renders a full axis.
	public function get_timeseries( $args = [] ) {
		$days = isset( $args['days'] ) ? max( 7, min( 90, (int) $args['days'] ) ) : 28;
		$property = !empty( $args['property'] ) ? (string) $args['property'] : null;
		$fresh = !empty( $args['fresh'] );

		$range = $this->date_range( $days );
		$body = [
			'startDate'  => $range['start'],
			'endDate'    => $range['end'],
			'dimensions' => [ 'date' ],
			'rowLimit'   => $days,
		];
		$response = $this->cached_query( 'timeseries_' . md5( serialize( $body ) ), $body, $property, $fresh );

		$by_date = [];
		if ( $response !== false && !empty( $response['rows'] ) ) {
			foreach ( $response['rows'] as $row ) {
				$d = $row['keys'][0] ?? '';
				if ( $d === '' ) continue;
				$by_date[ $d ] = [
					'clicks' => (int) ( $row['clicks'] ?? 0 ),
					'impressions' => (int) ( $row['impressions'] ?? 0 ),
					'position' => round( $row['position'] ?? 0, 1 ),
				];
			}
		}

		$points = [];
		for ( $i = 0; $i < $days; $i++ ) {
			$d = date( 'Y-m-d', strtotime( $range['start'] . " +$i days" ) );
			$points[] = [
				'date' => $d,
				'clicks' => isset( $by_date[ $d ] ) ? $by_date[ $d ]['clicks'] : 0,
				'impressions' => isset( $by_date[ $d ] ) ? $by_date[ $d ]['impressions'] : 0,
			];
		}
		return [ 'period_days' => $days, 'points' => $points ];
	}

	private function query_summary_for_period( $start, $end, $property_override = null, $fresh = false ) {
		$body = [
			'startDate' => $start,
			'endDate' => $end,
			'rowLimit' => 1,
		];
		$response = $this->cached_query( 'summary_' . md5( $start . $end ), $body, $property_override, $fresh );
		if ( $response === false || empty( $response['rows'][0] ) ) {
			return [ 'clicks' => 0, 'impressions' => 0, 'ctr_pct' => 0, 'position' => 0 ];
		}
		$row = $response['rows'][0];
		return [
			'clicks' => (int) ( $row['clicks'] ?? 0 ),
			'impressions' => (int) ( $row['impressions'] ?? 0 ),
			'ctr_pct' => round( ( $row['ctr'] ?? 0 ) * 100, 2 ),
			'position' => round( $row['position'] ?? 0, 1 ),
		];
	}

	/**
	 * Get top queries — optionally scoped to a single page URL.
	 * Pass `property` in $args to query a non-active property (multi-domain sites).
	 */
	public function get_top_queries( $args = [] ) {
		$days = isset( $args['days'] ) ? max( 1, min( 365, (int) $args['days'] ) ) : 28;
		$limit = isset( $args['limit'] ) ? max( 1, min( 1000, (int) $args['limit'] ) ) : 25;
		$page_url = !empty( $args['page_url'] ) ? (string) $args['page_url'] : null;
		$country = !empty( $args['country'] ) ? strtolower( substr( $args['country'], 0, 3 ) ) : null;
		$property = !empty( $args['property'] ) ? (string) $args['property'] : null;
		$fresh = !empty( $args['fresh'] );

		// Auto-resolve property from page URL (multi-domain WP installs) if not overridden.
		if ( $property === null && $page_url ) {
			$property = $this->resolve_property_for_url( $page_url );
		}

		$range = $this->date_range( $days );
		$body = [
			'startDate' => $range['start'],
			'endDate' => $range['end'],
			'dimensions' => [ 'query' ],
			'rowLimit' => $limit,
			'orderBy' => [ [ 'fieldName' => 'clicks', 'sortOrder' => 'DESCENDING' ] ],
		];

		$filters = [];
		if ( $page_url ) {
			$filters[] = [ 'dimension' => 'page', 'operator' => 'equals', 'expression' => $page_url ];
		}
		if ( $country ) {
			$filters[] = [ 'dimension' => 'country', 'operator' => 'equals', 'expression' => $country ];
		}
		if ( !empty( $filters ) ) {
			$body['dimensionFilterGroups'] = [ [ 'filters' => $filters ] ];
		}

		$response = $this->cached_query( 'queries_' . md5( serialize( $body ) ), $body, $property, $fresh );
		if ( $response === false || empty( $response['rows'] ) ) {
			return [];
		}

		return array_map( function( $row ) {
			return [
				'query' => $row['keys'][0] ?? '',
				'clicks' => (int) ( $row['clicks'] ?? 0 ),
				'impressions' => (int) ( $row['impressions'] ?? 0 ),
				'ctr_pct' => round( ( $row['ctr'] ?? 0 ) * 100, 2 ),
				'position' => round( $row['position'] ?? 0, 1 ),
			];
		}, $response['rows'] );
	}

	/**
	 * Get top pages by clicks. Returns enriched with WP post info where matchable.
	 * Pass `property` in $args to query a non-active property.
	 */
	public function get_top_pages( $args = [] ) {
		$days = isset( $args['days'] ) ? max( 1, min( 365, (int) $args['days'] ) ) : 28;
		$limit = isset( $args['limit'] ) ? max( 1, min( 1000, (int) $args['limit'] ) ) : 25;
		$property = !empty( $args['property'] ) ? (string) $args['property'] : null;
		$fresh = !empty( $args['fresh'] );
		$cached_only = !empty( $args['cached_only'] );

		$range = $this->date_range( $days );
		$body = [
			'startDate' => $range['start'],
			'endDate' => $range['end'],
			'dimensions' => [ 'page' ],
			'rowLimit' => $limit,
			'orderBy' => [ [ 'fieldName' => 'clicks', 'sortOrder' => 'DESCENDING' ] ],
		];

		$response = $this->cached_query( 'pages_' . md5( serialize( $body ) ), $body, $property, $fresh, $cached_only );
		if ( $response === false || empty( $response['rows'] ) ) {
			return [];
		}

		$self = $this;
		return array_map( function( $row ) use ( $self ) {
			$url = $row['keys'][0] ?? '';
			$post_id = $self->resolve_local_post_id( $url );
			return [
				'url' => $url,
				'post_id' => $post_id ?: null,
				'post_title' => $post_id ? get_the_title( $post_id ) : null,
				'clicks' => (int) ( $row['clicks'] ?? 0 ),
				'impressions' => (int) ( $row['impressions'] ?? 0 ),
				'ctr_pct' => round( ( $row['ctr'] ?? 0 ) * 100, 2 ),
				'position' => round( $row['position'] ?? 0, 1 ),
			];
		}, $response['rows'] );
	}

	// Rising and falling pages: current window vs the equivalent prior window, the "content
	// decay" check SEOs run weekly in Search Console. Two cached page-grouped calls, diffed
	// by URL. Pages with too few clicks in both windows are noise and get skipped.
	public function get_page_movers( $args = [] ) {
		$days = isset( $args['days'] ) ? max( 7, min( 90, (int) $args['days'] ) ) : 28;
		$limit = isset( $args['limit'] ) ? max( 1, min( 10, (int) $args['limit'] ) ) : 4;
		$property = !empty( $args['property'] ) ? (string) $args['property'] : null;
		$fresh = !empty( $args['fresh'] );

		$range = $this->date_range( $days );
		$prior_end = date( 'Y-m-d', strtotime( $range['start'] . ' -1 day' ) );
		$prior_start = date( 'Y-m-d', strtotime( $prior_end . ' -' . ( $days - 1 ) . ' days' ) );

		$fetch = function( $start, $end ) use ( $property, $fresh ) {
			$body = [
				'startDate' => $start,
				'endDate' => $end,
				'dimensions' => [ 'page' ],
				'rowLimit' => 1000,
				'orderBy' => [ [ 'fieldName' => 'clicks', 'sortOrder' => 'DESCENDING' ] ],
			];
			$response = $this->cached_query( 'pages_' . md5( serialize( $body ) ), $body, $property, $fresh );
			$map = [];
			if ( $response !== false && !empty( $response['rows'] ) ) {
				foreach ( $response['rows'] as $row ) {
					$url = $row['keys'][0] ?? '';
					if ( $url === '' ) continue;
					$map[ $url ] = [
						'clicks' => (int) ( $row['clicks'] ?? 0 ),
						'impressions' => (int) ( $row['impressions'] ?? 0 ),
						'position' => round( $row['position'] ?? 0, 1 ),
					];
				}
			}
			return $map;
		};

		$current = $fetch( $range['start'], $range['end'] );
		$prior = $fetch( $prior_start, $prior_end );

		$movers = [];
		foreach ( array_unique( array_merge( array_keys( $current ), array_keys( $prior ) ) ) as $url ) {
			$now = $current[ $url ]['clicks'] ?? 0;
			$before = $prior[ $url ]['clicks'] ?? 0;
			// Both windows quiet: not a mover, just noise.
			if ( max( $now, $before ) < 5 ) continue;
			$delta = $now - $before;
			if ( $delta === 0 ) continue;
			$movers[] = [
				'url' => $url,
				'clicks' => $now,
				'prior_clicks' => $before,
				'delta' => $delta,
				'delta_pct' => $before > 0 ? round( ( $delta / $before ) * 100 ) : null,
				'position' => $current[ $url ]['position'] ?? null,
				'impressions' => $current[ $url ]['impressions'] ?? 0,
			];
		}

		usort( $movers, function( $a, $b ) { return $b['delta'] - $a['delta']; } );
		$risers = array_slice( array_values( array_filter( $movers, function( $m ) { return $m['delta'] > 0; } ) ), 0, $limit );
		$fallers = array_reverse( array_slice( array_values( array_filter( $movers, function( $m ) { return $m['delta'] < 0; } ) ), -$limit ) );

		$enrich = function( $m ) {
			$post_id = $this->resolve_local_post_id( $m['url'] );
			$m['post_id'] = $post_id ?: null;
			$m['title'] = $post_id ? html_entity_decode( get_the_title( $post_id ), ENT_QUOTES ) : null;
			return $m;
		};

		return [
			'period_days' => $days,
			'risers' => array_map( $enrich, $risers ),
			'fallers' => array_map( $enrich, $fallers ),
		];
	}

	/**
	 * Bulk page metrics keyed by local post ID, for the Content SEO list. One page-grouped
	 * API call (6h cached) covers every post, so we never query GSC per-row. Top queries are
	 * intentionally left out here (that would cost one call per page) and live in get_post_pulse.
	 */
	public function get_post_metrics_map( $args = [] ) {
		$days = isset( $args['days'] ) ? max( 1, min( 365, (int) $args['days'] ) ) : 28;
		$rows = $this->get_top_pages( [
			'days'        => $days,
			'limit'       => 1000,
			'fresh'       => !empty( $args['fresh'] ),
			'cached_only' => !empty( $args['cached_only'] ),
		] );

		$map = [];
		foreach ( $rows as $row ) {
			if ( empty( $row['post_id'] ) ) continue;
			// First (clicks-sorted) row wins if a post resolves from more than one URL variant.
			if ( isset( $map[ $row['post_id'] ] ) ) continue;
			$map[ $row['post_id'] ] = [
				'clicks'      => $row['clicks'],
				'impressions' => $row['impressions'],
				'ctr_pct'     => $row['ctr_pct'],
				'position'    => $row['position'],
			];
		}
		return $map;
	}

	/**
	 * Query<->page breakdown from a single ['query','page'] report. From one cached call we
	 * derive both "top queries and the page they lead to" and "top pages and their top query",
	 * so the Search Console tab can answer "what brings traffic, and where does it land".
	 */
	public function get_search_breakdown( $args = [] ) {
		$days     = isset( $args['days'] ) ? max( 1, min( 365, (int) $args['days'] ) ) : 28;
		$limit    = isset( $args['limit'] ) ? max( 1, min( 50, (int) $args['limit'] ) ) : 12;
		$property = !empty( $args['property'] ) ? (string) $args['property'] : null;
		$fresh    = !empty( $args['fresh'] );

		$range = $this->date_range( $days );
		$body = [
			'startDate'  => $range['start'],
			'endDate'    => $range['end'],
			'dimensions' => [ 'query', 'page' ],
			'rowLimit'   => 1000,
			'orderBy'    => [ [ 'fieldName' => 'clicks', 'sortOrder' => 'DESCENDING' ] ],
		];
		$response = $this->cached_query( 'breakdown_' . md5( serialize( $body ) ), $body, $property, $fresh );
		if ( $response === false || empty( $response['rows'] ) ) {
			return [ 'top_queries' => [], 'top_pages' => [] ];
		}

		$by_query = [];
		$by_page  = [];
		foreach ( $response['rows'] as $row ) {
			$q      = $row['keys'][0] ?? '';
			$p      = $row['keys'][1] ?? '';
			$clicks = (int) ( $row['clicks'] ?? 0 );
			$impr   = (int) ( $row['impressions'] ?? 0 );
			$pos    = (float) ( $row['position'] ?? 0 );

			if ( $q !== '' ) {
				// Merge accent/case variants ("que faire a kyoto" == "que faire à kyoto") under one
				// normalized key. Rows arrive clicks-desc, so the first variant seen is the dominant
				// spelling and becomes the display label. Word-order variants normalize differently
				// and correctly stay separate.
				$qkey = remove_accents( function_exists( 'mb_strtolower' ) ? mb_strtolower( $q, 'UTF-8' ) : strtolower( $q ) );
				if ( !isset( $by_query[ $qkey ] ) ) {
					$by_query[ $qkey ] = [ 'query' => $q, 'clicks' => 0, 'impressions' => 0, 'pos_weight' => 0.0, 'page' => $p, 'page_clicks' => -1 ];
				}
				$by_query[ $qkey ]['clicks']      += $clicks;
				$by_query[ $qkey ]['impressions'] += $impr;
				$by_query[ $qkey ]['pos_weight']  += $pos * max( 1, $impr );
				if ( $clicks > $by_query[ $qkey ]['page_clicks'] ) { $by_query[ $qkey ]['page'] = $p; $by_query[ $qkey ]['page_clicks'] = $clicks; }
			}
			if ( $p !== '' ) {
				if ( !isset( $by_page[ $p ] ) ) {
					$by_page[ $p ] = [ 'url' => $p, 'clicks' => 0, 'impressions' => 0, 'pos_weight' => 0.0, 'top_query' => $q, 'query_clicks' => -1 ];
				}
				$by_page[ $p ]['clicks']      += $clicks;
				$by_page[ $p ]['impressions'] += $impr;
				$by_page[ $p ]['pos_weight']  += $pos * max( 1, $impr );
				if ( $clicks > $by_page[ $p ]['query_clicks'] ) { $by_page[ $p ]['top_query'] = $q; $by_page[ $p ]['query_clicks'] = $clicks; }
			}
		}

		$by_clicks = function( $a, $b ) { return $b['clicks'] - $a['clicks']; };
		usort( $by_query, $by_clicks );
		usort( $by_page, $by_clicks );

		$finalize_metrics = function( $agg ) {
			$impr = max( 1, $agg['impressions'] );
			return [
				'clicks'      => $agg['clicks'],
				'impressions' => $agg['impressions'],
				'ctr_pct'     => $agg['impressions'] > 0 ? round( $agg['clicks'] / $agg['impressions'] * 100, 2 ) : 0,
				'position'    => round( $agg['pos_weight'] / $impr, 1 ),
			];
		};

		$title_of = function( $pid ) { return $pid ? html_entity_decode( get_the_title( $pid ), ENT_QUOTES, 'UTF-8' ) : null; };

		$top_queries = [];
		foreach ( array_slice( $by_query, 0, $limit ) as $q ) {
			$pid = $this->resolve_local_post_id( $q['page'] );
			$top_queries[] = array_merge( [ 'query' => $q['query'] ], $finalize_metrics( $q ), [
				'page'       => $q['page'],
				'post_id'    => $pid ?: null,
				'post_title' => $title_of( $pid ),
			] );
		}

		$top_pages = [];
		foreach ( array_slice( $by_page, 0, $limit ) as $p ) {
			$pid = $this->resolve_local_post_id( $p['url'] );
			$top_pages[] = array_merge( [ 'url' => $p['url'] ], $finalize_metrics( $p ), [
				'post_id'    => $pid ?: null,
				'post_title' => $title_of( $pid ),
				'top_query'  => $p['top_query'],
			] );
		}

		return [ 'top_queries' => $top_queries, 'top_pages' => $top_pages ];
	}

	/**
	 * The actionable cross: pages that get real Google traffic AND have a weak SEO score or open
	 * issues, sorted by clicks. This is the unique signal we own (GSC traffic + our analysis), so
	 * the user knows exactly which high-traffic pages are worth fixing first.
	 */
	public function get_pages_with_issues( $args = [] ) {
		$days     = isset( $args['days'] ) ? max( 1, min( 365, (int) $args['days'] ) ) : 28;
		$limit    = isset( $args['limit'] ) ? max( 1, min( 50, (int) $args['limit'] ) ) : 12;
		$property = !empty( $args['property'] ) ? (string) $args['property'] : null;

		// Pull a generous slice of top pages so we still surface enough issue pages after filtering.
		$pages = $this->get_top_pages( [ 'days' => $days, 'limit' => 200, 'property' => $property, 'fresh' => !empty( $args['fresh'] ) ] );

		$out = [];
		foreach ( $pages as $pg ) {
			if ( empty( $pg['post_id'] ) ) continue;
			$analysis = get_post_meta( $pg['post_id'], '_mwseo_analysis', true );
			if ( !is_array( $analysis ) ) continue;

			$score = isset( $analysis['overall'] ) ? (int) $analysis['overall'] : null;
			$issues = [];
			if ( !empty( $analysis['penalties'] ) && is_array( $analysis['penalties'] ) ) {
				foreach ( $analysis['penalties'] as $test => $pen ) { if ( (float) $pen > 0 ) $issues[ $test ] = (float) $pen; }
			}

			// Only surface pages that actually need work: open issues, or a sub-"good" score.
			if ( empty( $issues ) && ( $score === null || $score >= 80 ) ) continue;

			arsort( $issues );
			$out[] = [
				'url'         => $pg['url'],
				'post_id'     => $pg['post_id'],
				'post_title'  => html_entity_decode( (string) $pg['post_title'], ENT_QUOTES, 'UTF-8' ),
				'clicks'      => $pg['clicks'],
				'impressions' => $pg['impressions'],
				'ctr_pct'     => $pg['ctr_pct'],
				'position'    => $pg['position'],
				'score'       => $score,
				'top_issue'   => !empty( $issues ) ? (string) array_key_first( $issues ) : null,
				'issue_count' => count( $issues ),
			];
			if ( count( $out ) >= $limit ) break;
		}
		return $out;
	}

	/**
	 * Per-post pulse: top queries, trends vs previous period, one-line headline.
	 * Designed to be HYPER satisfying — the user opens this and immediately knows the story.
	 */
	public function get_post_pulse( $post_id, $days = 28, $property_override = null, $debug = false ) {
		$post = get_post( $post_id );
		if ( !$post ) {
			$this->last_api_error = 'Post not found.';
			return false;
		}

		$page_url = get_permalink( $post );

		// Auto-resolve: in a multi-domain Polylang/WPML setup, the right property
		// for a French post on japonsecret.fr is the japonsecret.fr property, not
		// the user's default. Resolution looks up the post URL host against the
		// tracked properties. The caller can override with $property_override.
		$resolved_property = !empty( $property_override )
			? $property_override
			: $this->resolve_property_for_url( $page_url );

		// Current period
		$range = $this->date_range( $days );
		$current = $this->query_period_for_url( $page_url, $range['start'], $range['end'], $resolved_property );

		// Prior period (immediately before current)
		$prior_end = date( 'Y-m-d', strtotime( $range['start'] . ' -1 day' ) );
		$prior_start = date( 'Y-m-d', strtotime( $prior_end . ' -' . ( $days - 1 ) . ' days' ) );
		$prior = $this->query_period_for_url( $page_url, $prior_start, $prior_end, $resolved_property );

		// Top queries (clicks-sorted) for the current period, scoped to this URL
		$top_queries = $this->get_top_queries( [
			'days' => $days,
			'page_url' => $page_url,
			'limit' => 10,
			'property' => $resolved_property,
		] );

		$trends = [
			'clicks' => $this->build_trend( $current['clicks'] ?? 0, $prior['clicks'] ?? 0, false ),
			'impressions' => $this->build_trend( $current['impressions'] ?? 0, $prior['impressions'] ?? 0, false ),
			'position' => $this->build_trend( $current['position'] ?? 0, $prior['position'] ?? 0, true ),
		];

		$headline = $this->build_post_headline( $post->post_title, $current, $trends, $top_queries );

		$out = [
			'post_id' => $post->ID,
			'post_title' => $post->post_title,
			'permalink' => $page_url,
			'period_days' => $days,
			'property_used' => $resolved_property,
			'auto_resolved' => empty( $property_override ),
			'headline' => $headline,
			'current' => $current,
			'trends' => $trends,
			'top_queries' => $top_queries,
		];
		if ( $debug ) {
			// Bump this string in each searchconsole.php change so deployments
			// can be verified on the wire instead of guessing about OPcache.
			$out['_debug'] = [
				'code_version' => 'gsc-pulse-2026-05-15-contains-fallback',
				'current_period' => [ 'start' => $range['start'], 'end' => $range['end'] ],
				'prior_period' => [ 'start' => $prior_start, 'end' => $prior_end ],
			];
		}
		return $out;
	}

	private function query_period_for_url( $page_url, $start, $end, $property_override = null ) {
		// Try exact match first — fastest and most accurate.
		$body = [
			'startDate' => $start,
			'endDate' => $end,
			'dimensionFilterGroups' => [ [
				'filters' => [ [ 'dimension' => 'page', 'operator' => 'equals', 'expression' => $page_url ] ]
			] ],
			'rowLimit' => 1,
		];
		// Skip the cache layer for period queries — empty results were getting
		// pinned for 6 hours, blanking out trends. The query is cheap (one aggregate row).
		$response = $this->query_search_analytics( $body, $property_override );

		// If exact match returned nothing, retry with `contains` against the URL
		// path. GSC stores whatever Google's crawler last indexed — trailing slash
		// differences, http→https, www variants, or post slug changes can all
		// cause `equals` to miss historical data even when the post is the same.
		if ( $response === false || empty( $response['rows'][0] ) ) {
			$path = wp_parse_url( $page_url, PHP_URL_PATH );
			if ( $path && strlen( trim( $path, '/' ) ) > 0 ) {
				$contains_body = [
					'startDate' => $start,
					'endDate' => $end,
					'dimensionFilterGroups' => [ [
						'filters' => [ [ 'dimension' => 'page', 'operator' => 'contains', 'expression' => trim( $path, '/' ) ] ]
					] ],
					'rowLimit' => 1,
				];
				$contains_response = $this->query_search_analytics( $contains_body, $property_override );
				if ( $contains_response !== false && !empty( $contains_response['rows'][0] ) ) {
					$response = $contains_response;
				}
			}
		}

		// Persistent empty result — log enough info to debug. Useful when a post
		// has data in the current period but not in the prior one, suggesting
		// the URL changed or GSC stored it under a different format.
		if ( $response === false || empty( $response['rows'][0] ) ) {
			$this->core->log( sprintf(
				"⚠️ GSC empty period query: %s [%s → %s] property=%s",
				$page_url, $start, $end, $property_override ?: $this->property
			) );
		}
		if ( $response === false || empty( $response['rows'][0] ) ) {
			return [ 'clicks' => 0, 'impressions' => 0, 'ctr_pct' => 0, 'position' => 0 ];
		}
		$row = $response['rows'][0];
		return [
			'clicks' => (int) ( $row['clicks'] ?? 0 ),
			'impressions' => (int) ( $row['impressions'] ?? 0 ),
			'ctr_pct' => round( ( $row['ctr'] ?? 0 ) * 100, 2 ),
			'position' => round( $row['position'] ?? 0, 1 ),
		];
	}

	private function build_trend( $current, $previous, $lower_is_better ) {
		if ( $previous == 0 && $current == 0 ) {
			return [ 'current' => $current, 'previous' => $previous, 'delta_pct' => 0, 'emoji' => '➖' ];
		}
		if ( $previous == 0 ) {
			return [ 'current' => $current, 'previous' => 0, 'delta_pct' => null, 'emoji' => '🆕', 'note' => 'No data in previous period' ];
		}
		$delta = round( ( ( $current - $previous ) / $previous ) * 100, 1 );
		$improved = $lower_is_better ? ( $delta < 0 ) : ( $delta > 0 );
		if ( abs( $delta ) < 2 ) {
			$emoji = '➖';
		} else {
			$emoji = $improved ? '📈' : '📉';
		}
		return [
			'current' => $current,
			'previous' => $previous,
			'delta_pct' => $delta,
			'emoji' => $emoji,
		];
	}

	private function build_post_headline( $title, $current, $trends, $top_queries ) {
		if ( ( $current['impressions'] ?? 0 ) === 0 ) {
			return "This post has no Google Search visibility in the period. New posts often take 1 to 2 weeks to appear; for older posts, check indexability (canonical, robots, sitemap inclusion) and that inbound internal links exist.";
		}

		$top = !empty( $top_queries[0] ) ? $top_queries[0] : null;
		$pos = $current['position'] ?? 0;
		$clicks = $current['clicks'] ?? 0;
		$impr = $current['impressions'] ?? 0;

		$pos_text = $pos > 0 ? sprintf( "ranking #%.1f on average", $pos ) : "";
		$query_text = $top ? sprintf( ' for "%s"', $top['query'] ) : '';
		$click_trend = $trends['clicks']['emoji'] ?? '';
		$delta = $trends['clicks']['delta_pct'] ?? null;
		$trend_text = '';
		if ( is_numeric( $delta ) && abs( $delta ) >= 2 ) {
			$dir = $delta > 0 ? 'up' : 'down';
			$trend_text = sprintf( ' Clicks %s %s%% vs. previous period %s.', $dir, abs( $delta ), $click_trend );
		}

		return sprintf(
			"%s: %s impressions, %s clicks, %s%s.%s",
			$title,
			number_format( $impr ),
			number_format( $clicks ),
			$pos_text,
			$query_text,
			$trend_text
		);
	}

	/**
	 * THE star tool. Returns categorized, actionable opportunities with payoff estimates.
	 * Each opportunity is "one button away from satisfaction".
	 */
	public function get_quick_wins( $args = [] ) {
		$days = isset( $args['days'] ) ? max( 7, min( 90, (int) $args['days'] ) ) : 28;
		$min_impressions = isset( $args['min_impressions'] ) ? max( 10, (int) $args['min_impressions'] ) : 50;
		$per_category = isset( $args['limit_per_category'] ) ? max( 1, min( 50, (int) $args['limit_per_category'] ) ) : 5;
		$property = !empty( $args['property'] ) ? (string) $args['property'] : null;
		$fresh = !empty( $args['fresh'] );

		$range = $this->date_range( $days );

		// Pull page+query rows — gives us enough granularity to find page-level AND query-level wins.
		$body = [
			'startDate' => $range['start'],
			'endDate' => $range['end'],
			'dimensions' => [ 'page', 'query' ],
			'rowLimit' => 5000,
			'orderBy' => [ [ 'fieldName' => 'impressions', 'sortOrder' => 'DESCENDING' ] ],
		];

		$response = $this->cached_query( 'quickwins_' . md5( serialize( $body ) ), $body, $property, $fresh );
		if ( $response === false ) {
			return [
				'success' => false,
				'error' => $this->last_api_error,
			];
		}
		$rows = $response['rows'] ?? [];

		$close_to_first = [];
		$ctr_opps = [];
		$ai_overview_suspects = [];
		$hidden_gems = [];

		foreach ( $rows as $row ) {
			$page = $row['keys'][0] ?? '';
			$query = $row['keys'][1] ?? '';
			$clicks = (int) ( $row['clicks'] ?? 0 );
			$impressions = (int) ( $row['impressions'] ?? 0 );
			$ctr = (float) ( $row['ctr'] ?? 0 );
			$position = (float) ( $row['position'] ?? 0 );

			if ( $impressions < $min_impressions ) continue;

			// 🎯 Close to first page: position 5-15, decent traffic
			if ( $position >= 5 && $position <= 15 ) {
				$target = $position <= 10 ? 3 : 5;
				$lift_clicks = $this->estimate_lift( $impressions, $position, $target );
				if ( $lift_clicks >= 5 ) {
					$close_to_first[] = [
						'page' => $page, 'query' => $query, 'position' => round( $position, 1 ),
						'impressions' => $impressions, 'clicks' => $clicks,
						'ctr_pct' => round( $ctr * 100, 2 ),
						'estimated_lift_clicks' => $lift_clicks,
						'target_position' => $target,
						'_sort' => $lift_clicks,
					];
				}
			}

			// 🤖 AI Overview suspect: ranks in the top 5 but CTR is severely below expected
			// (< 35% of the curve). Independent studies (Ahrefs ~60% drop, Pew ~47% drop)
			// show this is the signature pattern when Google summarizes the answer above
			// your result.
			$matched_ai_suspect = false;
			if ( $position >= 1 && $position <= 5 ) {
				$expected_ctr = $this->expected_ctr( $position );
				if ( $expected_ctr > 0 && $ctr < ( $expected_ctr * 0.35 ) && $impressions >= max( $min_impressions, 200 ) ) {
					$lost_clicks = (int) round( ( $expected_ctr - $ctr ) * $impressions );
					if ( $lost_clicks >= 10 ) {
						$ai_overview_suspects[] = [
							'page' => $page, 'query' => $query, 'position' => round( $position, 1 ),
							'impressions' => $impressions, 'clicks' => $clicks,
							'ctr_pct' => round( $ctr * 100, 2 ),
							'expected_ctr_pct' => round( $expected_ctr * 100, 2 ),
							'estimated_lost_clicks' => $lost_clicks,
							'hypothesis' => 'AI Overview likely cannibalizing clicks',
							'_sort' => $lost_clicks,
						];
						$matched_ai_suspect = true;
					}
				}
			}

			// 💡 Title/meta opportunity: in top 10, but CTR is below half of expected for that position.
			// Skip if we already flagged it as an AI Overview suspect — that's a different problem.
			if ( !$matched_ai_suspect && $position <= 10 && $position >= 1 ) {
				$expected_ctr = $this->expected_ctr( $position );
				if ( $expected_ctr > 0 && $ctr < ( $expected_ctr * 0.5 ) && $impressions >= max( $min_impressions, 100 ) ) {
					$lift_clicks = (int) round( ( $expected_ctr - $ctr ) * $impressions );
					if ( $lift_clicks >= 5 ) {
						$ctr_opps[] = [
							'page' => $page, 'query' => $query, 'position' => round( $position, 1 ),
							'impressions' => $impressions, 'clicks' => $clicks,
							'ctr_pct' => round( $ctr * 100, 2 ),
							'expected_ctr_pct' => round( $expected_ctr * 100, 2 ),
							'estimated_lift_clicks' => $lift_clicks,
							'_sort' => $lift_clicks,
						];
					}
				}
			}

			// 💎 Hidden gem: great CTR but few impressions — visibility is the lever
			if ( $ctr >= 0.05 && $impressions < 500 && $impressions >= $min_impressions ) {
				$hidden_gems[] = [
					'page' => $page, 'query' => $query, 'position' => round( $position, 1 ),
					'impressions' => $impressions, 'clicks' => $clicks,
					'ctr_pct' => round( $ctr * 100, 2 ),
					'_sort' => $ctr * 1000 + $clicks,
				];
			}
		}

		usort( $close_to_first, fn( $a, $b ) => $b['_sort'] <=> $a['_sort'] );
		usort( $ctr_opps, fn( $a, $b ) => $b['_sort'] <=> $a['_sort'] );
		usort( $ai_overview_suspects, fn( $a, $b ) => $b['_sort'] <=> $a['_sort'] );
		usort( $hidden_gems, fn( $a, $b ) => $b['_sort'] <=> $a['_sort'] );

		$close_to_first = array_slice( $close_to_first, 0, $per_category );
		$ctr_opps = array_slice( $ctr_opps, 0, $per_category );
		$ai_overview_suspects = array_slice( $ai_overview_suspects, 0, $per_category );
		$hidden_gems = array_slice( $hidden_gems, 0, $per_category );

		// Enrich with post info + actions
		$close_to_first = array_map( [ $this, 'enrich_close_to_first' ], $close_to_first );
		$ctr_opps = array_map( [ $this, 'enrich_ctr_opp' ], $ctr_opps );
		$ai_overview_suspects = array_map( [ $this, 'enrich_ai_overview' ], $ai_overview_suspects );
		$hidden_gems = array_map( [ $this, 'enrich_hidden_gem' ], $hidden_gems );

		// Build a one-line summary that names the biggest opportunity
		$total = count( $close_to_first ) + count( $ctr_opps ) + count( $ai_overview_suspects ) + count( $hidden_gems );
		$top_lift = 0;
		$top_label = '';
		foreach ( [ 'Close to First Page' => $close_to_first, 'CTR Opportunities' => $ctr_opps ] as $name => $list ) {
			foreach ( $list as $item ) {
				if ( ( $item['estimated_lift_clicks'] ?? 0 ) > $top_lift ) {
					$top_lift = $item['estimated_lift_clicks'];
					$top_label = $name;
				}
			}
		}
		$summary = $total === 0
			? "No quick wins found in the last {$days} days. Your top pages may already be well-optimized, or impressions are below threshold."
			: sprintf( "Found %d quick wins. Biggest opportunity: ~%d more clicks/period from the '%s' category.", $total, $top_lift, $top_label );

		return [
			'success' => true,
			'summary' => $summary,
			'period' => [ 'start' => $range['start'], 'end' => $range['end'], 'days' => $days ],
			'categories' => [
				[
					'key' => 'close_to_first',
					'name' => '🎯 Close to First Page',
					'description' => 'Posts ranking #5-15 with strong impressions. A small lift = big traffic gain.',
					'opportunities' => $close_to_first,
				],
				[
					'key' => 'ctr_opps',
					'name' => '💡 Title & Meta Opportunities',
					'description' => 'High impressions, low CTR. Your title or description isn\'t compelling clicks.',
					'opportunities' => $ctr_opps,
				],
				[
					'key' => 'ai_overview',
					'name' => '🤖 AI Overview Suspects',
					'description' => 'Queries where you rank in the top 5 but click-through is unusually low — often a sign Google is summarizing the answer above your result. There is no fix that "beats" AI Overviews; the play is to ensure your content is what gets cited, and to diversify traffic. Independent studies measure AI Overviews dropping CTR 47% (Pew) to 60% (Ahrefs).',
					'opportunities' => $ai_overview_suspects,
				],
				[
					'key' => 'hidden_gems',
					'name' => '💎 Hidden Gems',
					'description' => 'Great CTR but few impressions. These posts perform when seen. Add internal links to boost visibility.',
					'opportunities' => $hidden_gems,
				],
			],
		];
	}

	/**
	 * Standalone AI Overview Suspects accessor — runs get_quick_wins() and returns
	 * just the suspects category. Useful as a focused MCP tool surface.
	 *
	 * NOTE (2026-06): this is a HEURISTIC. Google's new "Search Generative AI" reports
	 * (AI Overviews / AI Mode impressions) are UI-only so far; the Search Analytics API
	 * `type` enum is still web/image/video/news/discover/googleNews (no AI surface) and
	 * `searchAppearance` has no AI value. When Google exposes an AI type/searchAppearance,
	 * replace this heuristic with a real query. Re-check the API periodically.
	 */
	public function get_ai_overview_suspects( $args = [] ) {
		$wins = $this->get_quick_wins( $args );
		if ( empty( $wins['success'] ) ) {
			return $wins;
		}
		$suspects = [];
		foreach ( $wins['categories'] ?? [] as $cat ) {
			if ( strpos( $cat['name'] ?? '', 'AI Overview' ) !== false ) {
				$suspects = $cat['opportunities'] ?? [];
				break;
			}
		}
		return [
			'success' => true,
			'period' => $wins['period'] ?? null,
			'count' => count( $suspects ),
			'note' => 'Independent studies measure AI Overviews dropping CTR 47% (Pew) to 60% (Ahrefs) on impacted queries. There is no direct fix — focus on being the source AI Overviews cite, and diversify traffic channels.',
			'suspects' => $suspects,
		];
	}

	/**
	 * Weekly digest: one-call snapshot of a property's state. Site totals with
	 * period-over-period deltas, the top opportunity in each Quick Wins category,
	 * the pages that moved the most in clicks, and queries that entered the data
	 * this period. Entry point for a /pulse agent workflow.
	 */
	public function get_weekly_digest( $args = [] ) {
		$days = isset( $args['days'] ) ? max( 7, min( 90, (int) $args['days'] ) ) : 7;
		$property = !empty( $args['property'] ) ? (string) $args['property'] : null;
		$fresh = !empty( $args['fresh'] );

		$summary = $this->get_summary( [ 'days' => $days, 'property' => $property, 'fresh' => $fresh ] );

		$qw = $this->get_quick_wins( [
			'days' => $days, 'property' => $property,
			'limit_per_category' => 1, 'fresh' => $fresh,
		] );
		$top_wins = [];
		if ( !empty( $qw['categories'] ) ) {
			foreach ( $qw['categories'] as $cat ) {
				if ( empty( $cat['opportunities'] ) ) continue;
				$o = $cat['opportunities'][0];
				$top_wins[] = [
					'category' => $cat['name'],
					'post_id' => $o['post_id'] ?? null,
					'post_title' => $o['post_title'] ?? null,
					'page' => $o['page'] ?? null,
					'query' => $o['query'] ?? null,
					'position' => $o['position'] ?? null,
					'estimated_lift_clicks' => $o['estimated_lift_clicks'] ?? 0,
					'estimated_lost_clicks' => $o['estimated_lost_clicks'] ?? 0,
					'action' => $o['action'] ?? null,
					'next_step' => $o['next_step'] ?? null,
				];
			}
		}

		$movers = $this->compute_biggest_movers( $days, $property, $fresh );
		$new_queries = $this->compute_new_queries( $days, $property, $fresh );

		$headline = $this->build_digest_headline( $summary, $movers, $new_queries, $top_wins );

		return [
			'success' => true,
			'period_days' => $days,
			'property_used' => $property ?: $this->property,
			'headline' => $headline,
			'site' => [
				'current' => $summary['current'] ?? null,
				'prior' => $summary['prior'] ?? null,
				'trends' => $summary['trends'] ?? null,
			],
			'top_wins' => $top_wins,
			'biggest_movers' => $movers,
			'new_queries' => $new_queries,
		];
	}

	private function compute_biggest_movers( $days, $property, $fresh ) {
		$range = $this->date_range( $days );
		$prior_end = date( 'Y-m-d', strtotime( $range['start'] . ' -1 day' ) );
		$prior_start = date( 'Y-m-d', strtotime( $prior_end . ' -' . ( $days - 1 ) . ' days' ) );

		$cur_body = [
			'startDate' => $range['start'], 'endDate' => $range['end'],
			'dimensions' => [ 'page' ], 'rowLimit' => 100,
			'orderBy' => [ [ 'fieldName' => 'clicks', 'sortOrder' => 'DESCENDING' ] ],
		];
		$current = $this->cached_query( 'movers_cur_' . md5( serialize( $cur_body ) ), $cur_body, $property, $fresh );

		$prior_body = $cur_body;
		$prior_body['startDate'] = $prior_start;
		$prior_body['endDate'] = $prior_end;
		$prior = $this->cached_query( 'movers_prior_' . md5( serialize( $prior_body ) ), $prior_body, $property, $fresh );

		$cur_map = [];
		foreach ( ( $current['rows'] ?? [] ) as $row ) {
			$cur_map[ $row['keys'][0] ?? '' ] = [
				'clicks' => (int) ( $row['clicks'] ?? 0 ),
				'position' => (float) ( $row['position'] ?? 0 ),
			];
		}
		$prior_map = [];
		foreach ( ( $prior['rows'] ?? [] ) as $row ) {
			$prior_map[ $row['keys'][0] ?? '' ] = [
				'clicks' => (int) ( $row['clicks'] ?? 0 ),
				'position' => (float) ( $row['position'] ?? 0 ),
			];
		}

		$all_urls = array_unique( array_merge( array_keys( $cur_map ), array_keys( $prior_map ) ) );
		$movers = [];
		foreach ( $all_urls as $url ) {
			if ( $url === '' ) continue;
			$c = $cur_map[ $url ] ?? [ 'clicks' => 0, 'position' => 0 ];
			$p = $prior_map[ $url ] ?? [ 'clicks' => 0, 'position' => 0 ];
			$delta = $c['clicks'] - $p['clicks'];
			// Noise filter: ignore moves smaller than 5 clicks
			if ( abs( $delta ) < 5 ) continue;
			$post_id = $this->resolve_local_post_id( $url ) ?: null;
			$movers[] = [
				'url' => $url,
				'post_id' => $post_id,
				'post_title' => $post_id ? get_the_title( $post_id ) : null,
				'clicks_current' => $c['clicks'],
				'clicks_prior' => $p['clicks'],
				'clicks_delta' => $delta,
				'position_current' => round( $c['position'], 1 ),
				'position_prior' => round( $p['position'], 1 ),
			];
		}

		usort( $movers, function( $a, $b ) { return abs( $b['clicks_delta'] ) - abs( $a['clicks_delta'] ); } );
		return array_slice( $movers, 0, 5 );
	}

	private function compute_new_queries( $days, $property, $fresh ) {
		$range = $this->date_range( $days );
		$prior_end = date( 'Y-m-d', strtotime( $range['start'] . ' -1 day' ) );
		$prior_start = date( 'Y-m-d', strtotime( $prior_end . ' -' . ( $days - 1 ) . ' days' ) );

		$cur_body = [
			'startDate' => $range['start'], 'endDate' => $range['end'],
			'dimensions' => [ 'query' ], 'rowLimit' => 200,
			'orderBy' => [ [ 'fieldName' => 'impressions', 'sortOrder' => 'DESCENDING' ] ],
		];
		$current = $this->cached_query( 'newq_cur_' . md5( serialize( $cur_body ) ), $cur_body, $property, $fresh );

		$prior_body = $cur_body;
		$prior_body['startDate'] = $prior_start;
		$prior_body['endDate'] = $prior_end;
		$prior = $this->cached_query( 'newq_prior_' . md5( serialize( $prior_body ) ), $prior_body, $property, $fresh );

		$prior_set = [];
		foreach ( ( $prior['rows'] ?? [] ) as $row ) {
			$q = $row['keys'][0] ?? '';
			if ( $q !== '' ) $prior_set[ $q ] = true;
		}

		$new = [];
		foreach ( ( $current['rows'] ?? [] ) as $row ) {
			$q = $row['keys'][0] ?? '';
			if ( $q === '' || isset( $prior_set[ $q ] ) ) continue;
			$impr = (int) ( $row['impressions'] ?? 0 );
			if ( $impr < 10 ) continue;
			$new[] = [
				'query' => $q,
				'impressions' => $impr,
				'clicks' => (int) ( $row['clicks'] ?? 0 ),
				'position' => round( (float) ( $row['position'] ?? 0 ), 1 ),
				'ctr_pct' => round( ( $row['ctr'] ?? 0 ) * 100, 2 ),
			];
			if ( count( $new ) >= 10 ) break;
		}
		return $new;
	}

	private function build_digest_headline( $summary, $movers, $new_queries, $top_wins ) {
		$clicks = $summary['current']['clicks'] ?? 0;
		$delta = $summary['trends']['clicks']['delta_pct'] ?? null;
		$dir = ( is_numeric( $delta ) && abs( $delta ) >= 2 )
			? ( $delta > 0 ? sprintf( ' (up %s%%)', $delta ) : sprintf( ' (down %s%%)', abs( $delta ) ) )
			: '';
		$bits = [ sprintf( '%s clicks%s', number_format( $clicks ), $dir ) ];
		if ( !empty( $movers ) ) {
			$top_mover = $movers[0];
			$label = $top_mover['post_title'] ?: $top_mover['url'];
			$bits[] = sprintf( '%s %s by %d clicks',
				$top_mover['clicks_delta'] > 0 ? 'top grower' : 'biggest drop',
				$label,
				abs( $top_mover['clicks_delta'] )
			);
		}
		if ( !empty( $new_queries ) ) {
			$bits[] = sprintf( '%d new queries', count( $new_queries ) );
		}
		if ( !empty( $top_wins ) ) {
			$bits[] = sprintf( '%d quick wins ready', count( $top_wins ) );
		}
		return implode( '; ', $bits ) . '.';
	}

	private function expected_ctr( $position ) {
		$pos = (int) round( $position );
		if ( $pos < 1 ) return 0;
		if ( isset( self::$ctr_curve[ $pos ] ) ) return self::$ctr_curve[ $pos ];
		// Beyond position 15: very small, decay slowly
		return max( 0.003, 0.007 * pow( 0.9, $pos - 15 ) );
	}

	private function estimate_lift( $impressions, $current_position, $target_position ) {
		$current_expected = $this->expected_ctr( $current_position );
		$target_expected = $this->expected_ctr( $target_position );
		$lift_ctr = max( 0, $target_expected - $current_expected );
		return (int) round( $lift_ctr * $impressions );
	}

	// Public potential estimate for one page in the quick-wins band, using the same CTR curve
	// and target logic as get_quick_wins (top 3 when already top 10, page-1 entry otherwise).
	public function estimate_quick_win_potential( $impressions, $position ) {
		$target = $position <= 10 ? 3 : 5;
		return $this->estimate_lift( (int) $impressions, (float) $position, $target );
	}

	private function round_lift( $n ) {
		// Round to 2 significant figures so "462" reads as "~460" — these are
		// CTR-curve approximations, not measurements.
		$n = (int) $n;
		if ( $n < 100 ) return $n;
		$mag = (int) pow( 10, floor( log10( $n ) ) - 1 );
		return $mag > 0 ? (int) round( $n / $mag ) * $mag : $n;
	}

	private function enrich_with_post( $opp ) {
		$post_id = $opp['page'] ? $this->resolve_local_post_id( $opp['page'] ) : 0;
		$opp['post_id'] = $post_id ?: null;
		$opp['post_title'] = null;
		$opp['current_seo_title'] = null;
		$opp['current_seo_excerpt'] = null;
		$opp['seo_title_is_custom'] = false;
		$opp['seo_excerpt_is_custom'] = false;
		if ( $post_id ) {
			$post = get_post( $post_id );
			if ( $post ) {
				$opp['post_title'] = $post->post_title;
				// Use the EFFECTIVE title/excerpt — what Google actually sees —
				// rather than raw post meta. Most posts use auto-generated SEO
				// content; an agent overwriting "null" would clobber the fallback.
				$custom_title = get_post_meta( $post_id, $this->core->meta_key_seo_title, true );
				$custom_excerpt = get_post_meta( $post_id, $this->core->meta_key_seo_excerpt, true );
				$opp['seo_title_is_custom'] = !empty( $custom_title );
				$opp['seo_excerpt_is_custom'] = !empty( $custom_excerpt );
				$opp['current_seo_title'] = $this->core->get_seo_title( $post );
				$opp['current_seo_excerpt'] = $this->core->get_seo_excerpt( $post );
			}
		}
		return $opp;
	}

	private function enrich_close_to_first( $opp ) {
		unset( $opp['_sort'] );
		$opp = $this->enrich_with_post( $opp );
		$lift = $this->round_lift( $opp['estimated_lift_clicks'] );
		$opp['estimated_lift_clicks'] = $lift;
		$opp['action'] = sprintf(
			'You\'re ranking #%.1f for "%s". Strengthen this post: add internal links from related content, improve depth around the keyword.',
			$opp['position'], $opp['query']
		);
		$opp['estimated_lift'] = sprintf( '~%s more clicks over the period if moved to #%d (rough estimate from CTR curve).', number_format( $lift ), $opp['target_position'] );
		if ( $opp['post_id'] ) {
			$opp['next_step'] = sprintf( 'Run mwseo_suggest_internal_links with post_id=%d to surface candidate posts; then mwseo_generate_internal_link_placements for the best one.', $opp['post_id'] );
		}
		return $opp;
	}

	private function enrich_ctr_opp( $opp ) {
		unset( $opp['_sort'] );
		$opp = $this->enrich_with_post( $opp );
		$lift = $this->round_lift( $opp['estimated_lift_clicks'] );
		$opp['estimated_lift_clicks'] = $lift;
		$opp['action'] = sprintf(
			'#%.1f for "%s" with only %.1f%% CTR (expected ~%.1f%%). Rewrite the SEO title and meta description to be more compelling.',
			$opp['position'], $opp['query'], $opp['ctr_pct'], $opp['expected_ctr_pct']
		);
		$opp['estimated_lift'] = sprintf( '~%s more clicks over the period at expected CTR (rough estimate).', number_format( $lift ) );
		if ( $opp['post_id'] ) {
			$opp['next_step'] = sprintf( 'Run mwseo_suggest_seo_title with post_id=%d and target_query="%s" to get AI title candidates, then mwseo_set_seo_title to apply.', $opp['post_id'], addslashes( $opp['query'] ) );
		}
		return $opp;
	}

	private function enrich_ai_overview( $opp ) {
		unset( $opp['_sort'] );
		$opp = $this->enrich_with_post( $opp );
		$lost = $this->round_lift( $opp['estimated_lost_clicks'] );
		$opp['estimated_lost_clicks'] = $lost;
		$opp['action'] = sprintf(
			'#%.1f for "%s" with only %.1f%% CTR (expected ~%.1f%%). Google likely answers this query above your result. Make this post the source it cites: a direct, quotable answer near the top, clear headings, and up-to-date facts.',
			$opp['position'], $opp['query'], $opp['ctr_pct'], $opp['expected_ctr_pct']
		);
		$opp['estimated_lost'] = sprintf( '~%s clicks lost over the period versus expected CTR (rough estimate).', number_format( $lost ) );
		return $opp;
	}

	private function enrich_hidden_gem( $opp ) {
		unset( $opp['_sort'] );
		$opp = $this->enrich_with_post( $opp );
		$opp['action'] = sprintf(
			'%.1f%% CTR on "%s" is excellent. This post converts when seen. The lever is visibility: add inbound internal links from related popular posts.',
			$opp['ctr_pct'], $opp['query']
		);
		if ( $opp['post_id'] ) {
			$opp['next_step'] = sprintf( 'Run mwseo_suggest_internal_links with post_id=%d to find posts that should link in.', $opp['post_id'] );
		}
		return $opp;
	}

	#endregion
}
