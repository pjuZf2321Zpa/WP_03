<?php

namespace Breakdance\Data;

use function Breakdance\BreakdanceOxygen\Strings\__bdox;
use function Breakdance\Util\WP\performant_get_posts;

add_action('breakdance_loaded', function () {
    \Breakdance\AJAX\register_handler(
        'breakdance_regenerate_post_cache',
        '\Breakdance\Data\regenerate_post_cache',
        'edit',
        true
    );
});

function regenerate_post_cache()
{
    $id = intval($_POST['id'] ?? null);
    \Breakdance\Util\Timing\withoutTiming(fn() => \Breakdance\Render\generateCacheForPost($id));
}

add_action('breakdance_loaded', function () {
    \Breakdance\AJAX\register_handler(
        'breakdance_regenerate_global_settings_cache',
        '\Breakdance\Data\regenerate_global_settings_cache',
        'edit',
        true
    );
});

function regenerate_global_settings_cache()
{
    // generateCacheForGlobalSettings() rebuilds oxy variables CSS from scratch,
    // but oxy selector CSS is reused from the per-selector cache store whenever
    // a selector's hash matches — which keeps stale CSS around when something
    // the hash doesn't cover changed (breakpoints, variable renames, template).
    // Empty the store first so every selector regenerates.
    \Breakdance\BreakdanceOxygen\Selectors\saveSelectorsCacheStore([]);

    \Breakdance\Render\generateCacheForGlobalSettings();
}

add_action('breakdance_loaded', function () {
    \Breakdance\AJAX\register_handler(
        'breakdance_get_paginated_breakdance_post_ids',
        '\Breakdance\Data\get_paginated_breakdance_post_ids',
        'edit',
        true,
        [
            'args' => [
                'page' => FILTER_VALIDATE_INT
            ]
        ]
    );
});

/**
 * How many posts one page of the cache regeneration covers. Shared by the
 * settings tab's regenerate-cache UI and the run-site-tool MCP tool, which
 * both walk the site a page at a time rather than in one request.
 */
const BREAKDANCE_REGENERATE_CACHE_PAGE_SIZE = 50;

/**
 * Query args selecting every post that holds builder content, whatever post
 * type it is. The definition of "has builder content" (the post types the
 * builder is switched on for, plus its own, filtered by the data meta key)
 * lives here so the pager below, the progress count and any other caller
 * cannot drift apart on it.
 *
 * @param array<string, mixed> $overrides Merged over the base args.
 * @return array<string, mixed>
 */
function built_post_query_args($overrides = [])
{
    /** @var string[] $BREAKDANCE_ALL_EDITABLE_POST_TYPES */
    $BREAKDANCE_ALL_EDITABLE_POST_TYPES = BREAKDANCE_ALL_EDITABLE_POST_TYPES;

    $postTypesWithoutBreakdancePostTypes = \Breakdance\Settings\get_allowed_post_types(false);

    return array_merge(
        [
            'post_type'  => array_merge($postTypesWithoutBreakdancePostTypes, $BREAKDANCE_ALL_EDITABLE_POST_TYPES),
            'fields'     => 'ids',
            'meta_query' => [
                [
                    'key'     => __bdox('_meta_prefix') . 'data',
                    'compare' => 'EXISTS',
                ],
            ],
        ],
        $overrides
    );
}

/**
 * @param int $currentPage
 * @return array{postIds: array<array-key, \WP_Post>}
 */
function get_paginated_breakdance_post_ids($currentPage)
{
    $postsPerPage = BREAKDANCE_REGENERATE_CACHE_PAGE_SIZE;

    $allBreakdancePostIds = performant_get_posts(
        built_post_query_args([
            'posts_per_page' => $postsPerPage,
            'offset' => $postsPerPage * $currentPage,
        ])
    );

    return ['postIds' => $allBreakdancePostIds];
}
