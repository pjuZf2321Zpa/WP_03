<?php

namespace MasterStudy\Lms\Pro\addons\enterprise_courses\Admin\Controllers;

use MasterStudy\Lms\Http\WpResponseFactory;
use MasterStudy\Lms\Pro\addons\enterprise_courses\Admin\Repositories\EnterpriseGroupsRepository;
use MasterStudy\Lms\Validation\Validator;
use WP_REST_Request;
use WP_REST_Response;

final class GetEnterpriseGroupMembersController {
	public function __invoke( WP_REST_Request $request ): WP_REST_Response {
		$group_id  = (int) $request->get_param( 'group_id' );
		$validator = new Validator(
			$request->get_query_params(),
			array(
				'page'     => 'nullable|integer',
				'per_page' => 'nullable|integer',
			)
		);

		if ( $validator->fails() ) {
			return WpResponseFactory::validation_failed( $validator->get_errors_array() );
		}

		$repo = new EnterpriseGroupsRepository();

		if ( ! $repo->get_group( $group_id ) ) {
			return WpResponseFactory::bad_request( esc_html__( 'Enterprise group not found.', 'masterstudy-lms-learning-management-system-pro' ) );
		}

		$result = $repo->get_members(
			$group_id,
			max( 1, (int) ( $validator->get_validated()['page'] ?? 1 ) ),
			max( 1, (int) ( $validator->get_validated()['per_page'] ?? 10 ) )
		);

		return new WP_REST_Response( $result );
	}
}
