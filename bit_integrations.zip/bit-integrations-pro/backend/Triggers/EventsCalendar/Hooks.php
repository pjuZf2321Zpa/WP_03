<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Core\Util\Hooks;
use BitApps\IntegrationsPro\Triggers\EventsCalendar\EventsCalendarController;
use BitApps\IntegrationsPro\Triggers\EventsCalendar\EventsCalendarRecordController;

// Hooks for task one - User Attends Event
Hooks::add('event_tickets_checkin', [EventsCalendarController::class, 'handleAttendsEvent'], 10, 2);
Hooks::add('eddtickets_checkin', [EventsCalendarController::class, 'handleAttendsEvent'], 10, 2);
Hooks::add('rsvp_checkin', [EventsCalendarController::class, 'handleAttendsEvent'], 10, 2);
Hooks::add('wootickets_checkin', [EventsCalendarController::class, 'handleAttendsEvent'], 10, 2);

// Hooks for task one - User Attends Event
Hooks::add('event_tickets_rsvp_attendee_created', [EventsCalendarController::class, 'handleAttendeeRegistered'], 10, 5);
Hooks::add('event_ticket_woo_attendee_created', [EventsCalendarController::class, 'handleAttendeeRegistered'], 10, 5);
Hooks::add('event_ticket_edd_attendee_created', [EventsCalendarController::class, 'handleAttendeeRegistered'], 10, 5);
Hooks::add('event_tickets_tpp_attendee_created', [EventsCalendarController::class, 'handleAttendeeRegistered'], 10, 5);
Hooks::add('event_tickets_tpp_attendee_updated', [EventsCalendarController::class, 'handleAttendeeRegistered'], 10, 5);
Hooks::add('tec_tickets_commerce_attendee_after_create', [EventsCalendarController::class, 'handleAttendeeRegistered'], 10, 5);

Hooks::add('event_tickets_rsvp_tickets_generated_for_product', [EventsCalendarController::class, 'handleNewAttendee'], 10, 2);
Hooks::add('event_tickets_woocommerce_tickets_generated_for_product', [EventsCalendarController::class, 'handleNewAttendee'], 10, 2);
Hooks::add('event_tickets_tpp_tickets_generated_for_product', [EventsCalendarController::class, 'handleNewAttendee'], 10, 2);

// Hooks for task four - Attendee Registered with WooCommerce
Hooks::add('tribe_tickets_attendee_repository_create_attendee_for_ticket_after_create', [EventsCalendarController::class, 'handleAttendeeRegisteredWC'], 10, 4);

Hooks::add('transition_post_status', [EventsCalendarRecordController::class, 'handleStatusTransition'], 10, 3);
Hooks::add('wp_after_insert_post', [EventsCalendarRecordController::class, 'handleAfterInsertPost'], 10, 4);
Hooks::add('tribe_events_venue_created', [EventsCalendarRecordController::class, 'handleVenueSaved'], 10, 1);
Hooks::add('tribe_events_venue_updated', [EventsCalendarRecordController::class, 'handleVenueSaved'], 10, 1);
Hooks::add('tribe_events_organizer_created', [EventsCalendarRecordController::class, 'handleOrganizerSaved'], 10, 1);
Hooks::add('tribe_events_organizer_updated', [EventsCalendarRecordController::class, 'handleOrganizerSaved'], 10, 1);
Hooks::add('shutdown', [EventsCalendarRecordController::class, 'handleShutdown'], 100, 0);
Hooks::add('pre_post_update', [EventsCalendarRecordController::class, 'handlePrePostUpdate'], 10, 1);
Hooks::add('tec_events_custom_tables_v1_after_update_event', [EventsCalendarRecordController::class, 'handleEventDatesSaved'], 10, 1);
Hooks::filter('update_post_metadata', [EventsCalendarRecordController::class, 'handleStatusMetaUpdate'], 10, 3);
Hooks::add('trashed_post', [EventsCalendarRecordController::class, 'handleTrashedPost'], 10, 1);
Hooks::add('before_delete_post', [EventsCalendarRecordController::class, 'handleBeforeDeletePost'], 10, 1);
Hooks::add('tec_events_pro_custom_tables_v1_after_duplicate_event', [EventsCalendarRecordController::class, 'handleEventDuplicated'], 10, 2);
Hooks::add('tec_events_pro_custom_tables_v1_event_relationship_updated', [EventsCalendarRecordController::class, 'handleEventSeriesUpdated'], 10, 1);
Hooks::add('tec_events_pro_custom_tables_v1_series_relationships_updated', [EventsCalendarRecordController::class, 'handleSeriesEventsUpdated'], 10, 2);
