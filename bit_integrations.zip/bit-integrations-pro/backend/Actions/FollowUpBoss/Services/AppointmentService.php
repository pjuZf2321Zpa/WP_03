<?php

namespace BitApps\IntegrationsPro\Actions\FollowUpBoss\Services;

final class AppointmentService extends BaseService
{
    public function createAppointment(): array
    {
        $validationRules = [
            'title' => ['required'],
            'start' => ['required'],
            'end'   => ['required'],
        ];
        $error = $this->validateFields(
            $validationRules,
            [
                'title' => __('Title', 'bit-integrations-pro'),
                'start' => __('Start', 'bit-integrations-pro'),
                'end'   => __('End', 'bit-integrations-pro'),
            ]
        );

        if ($error !== null) {
            return $error;
        }

        $payload = $this->removeEmptyValues(
            [
                'title'       => $this->getString('title'),
                'start'       => $this->getString('start'),
                'end'         => $this->getString('end'),
                'allDay'      => $this->getBoolean('all_day'),
                'description' => $this->getString('description'),
                'location'    => $this->getString('location'),
                'typeId'      => $this->getInteger('type_id'),
                'outcomeId'   => $this->getInteger('outcome_id'),
                'createdById' => $this->getInteger('created_by_id'),
                'invitees'    => $this->getInvitees(),
            ]
        );

        $query = $this->removeEmptyValues(
            [
                'sendInvitation' => $this->getBoolean('send_invitation'),
            ]
        );

        return $this->dispatch('POST', '/appointments', $payload, $query);
    }

    public function updateAppointment(): array
    {
        $validationRules = ['appointment_id' => ['required', 'integer']];
        $error = $this->validateFields(
            $validationRules,
            [
                'appointment_id' => __('Appointment ID', 'bit-integrations-pro'),
            ]
        );

        if ($error !== null) {
            return $error;
        }

        $payload = $this->removeEmptyValues(
            [
                'title'       => $this->getString('title'),
                'start'       => $this->getString('start'),
                'end'         => $this->getString('end'),
                'allDay'      => $this->getBoolean('all_day'),
                'description' => $this->getString('description'),
                'location'    => $this->getString('location'),
                'typeId'      => $this->getInteger('type_id'),
                'outcomeId'   => $this->getInteger('outcome_id'),
                'createdById' => $this->getInteger('created_by_id'),
                'invitees'    => $this->getInvitees(),
            ]
        );

        $query = $this->removeEmptyValues(
            [
                'sendInvitation' => $this->getBoolean('send_invitation'),
            ]
        );

        $currentValues = $this->getMissingCurrentValues('/appointments/' . rawurlencode($this->getString('appointment_id')), $payload, ['title', 'start', 'end', 'allDay']);

        if (isset($currentValues['success'])) {
            return $currentValues;
        }

        $payload += $currentValues;

        return $this->dispatch('PUT', '/appointments/' . rawurlencode($this->getString('appointment_id')), $payload, $query);
    }

    public function deleteAppointment(): array
    {
        $validationRules = ['appointment_id' => ['required', 'integer']];
        $error = $this->validateFields(
            $validationRules,
            [
                'appointment_id' => __('Appointment ID', 'bit-integrations-pro'),
            ]
        );

        if ($error !== null) {
            return $error;
        }

        return $this->dispatch('DELETE', '/appointments/' . rawurlencode($this->getString('appointment_id')));
    }

    private function getInvitees(): array
    {
        $invitees = [];

        foreach ($this->getIntegerList('invited_user_ids') as $userId) {
            $invitees[] = ['userId' => $userId];
        }

        foreach ($this->getIntegerList('invited_person_ids') as $personId) {
            $invitees[] = ['personId' => $personId];
        }

        return $invitees;
    }
}
