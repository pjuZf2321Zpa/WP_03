<?php

namespace FluentCartPro\App\Modules\DynamicPricing\Conditions;

use FluentCart\App\Models\Cart;
use FluentCart\App\Services\Renderer\CheckoutFieldsSchema;
use FluentCart\Framework\Support\Arr;

/**
 * Conditions on the fields a shopper fills in at checkout.
 *
 * Every field of the checkout field settings is offered, grouped as the
 * settings screen groups them, whether or not the store has it switched on —
 * a field the shopper never filled is simply unknown, and the row fails.
 * Store switches (B2B only mode, agree to terms) are not fields and are left
 * out.
 *
 * Values are read from the checkout form the page saves onto the cart as the
 * shopper types, and that place-order overwrites with the submitted form
 * before anything prices the order — all but the address parts tax is worked
 * out from, which stay as the summary priced them.
 *
 * @package FluentCartPro\App\Modules\DynamicPricing
 *
 * @version 1.0.0
 */
class CheckoutFieldConditions
{
    /**
     * The Checkout Fields group for the registry, holding one group per
     * settings section.
     *
     * @return array
     */
    public static function group(): array
    {
        $sections = static::sections();
        $groups = [];

        foreach (static::fields() as $key => $field) {
            $group = 'checkout_' . $field['section'];

            if (!isset($groups[$group])) {
                $groups[$group] = [
                    'label'    => $sections[$field['section']]['label'],
                    'value'    => $group,
                    'children' => [],
                ];
            }

            $groups[$group]['children'][] = [
                'label'      => $field['label'],
                'value'      => $key,
                'input_type' => 'text',
                'operators'  => ConditionRegistry::textOperators(),
            ];
        }

        return [
            'label'    => __('Checkout Fields', 'fluent-cart-pro'),
            'value'    => 'checkout_fields',
            'children' => array_values($groups),
        ];
    }

    /**
     * Whether the key is one of the checkout settings fields. Any other key,
     * an add-on's own `checkout_*` attribute included, answers through the
     * resolver it registered.
     *
     * @param string $key
     * @return bool
     */
    public static function handles(string $key): bool
    {
        return isset(static::fields()[$key]);
    }

    /**
     * The field's value on this checkout, or null when there is no cart (a
     * renewal) or the shopper left it empty.
     *
     * @param string $key
     * @param Cart|null $cart
     * @return array|null
     */
    public static function value(string $key, $cart)
    {
        $field = Arr::get(static::fields(), $key);

        if (!$field || !$cart instanceof Cart) {
            return null;
        }

        $name = $field['name'];
        $checkoutData = (array)$cart->checkout_data;
        $form = (array)Arr::get($checkoutData, 'form_data', []);

        if ($field['section'] === 'shipping_address') {
            // Not shipping somewhere else: the order ships to the billing address.
            if (Arr::get($form, 'ship_to_different') === 'yes') {
                return static::filled(Arr::get($form, 'shipping_' . $name));
            }

            return $name === 'full_name'
                ? static::filled(static::fullName($cart, $form))
                : static::filled(Arr::get($form, 'billing_' . $name));
        }

        if ($field['section'] === 'business_details') {
            // The order carries business details only for a business purchase.
            if (Arr::get($form, 'is_business') !== 'yes' && !CheckoutFieldsSchema::isB2BOnlyMode()) {
                return null;
            }

            return $name === 'vat_number'
                ? static::filled(static::vatNumber($checkoutData))
                : static::filled(Arr::get($form, 'billing_' . $name));
        }

        switch ($name) {
            case 'full_name':
                return static::filled(static::fullName($cart, $form));

            case 'first_name':
                return static::filled(static::names($cart, $form)[0]);

            case 'last_name':
                return static::filled(static::names($cart, $form)[1]);
        }

        return static::filled(Arr::get($form, 'billing_' . $name));
    }

    /**
     * Every field of the checkout field settings, keyed by its condition key.
     *
     * @return array
     */
    protected static function fields(): array
    {
        $config = CheckoutFieldsSchema::getFieldsSchemaConfig();
        $fields = [];

        foreach (static::sections() as $section => $group) {
            foreach ((array)Arr::get($config, $section, []) as $name => $definition) {
                if (!is_array($definition) || Arr::get($definition, 'type') === 'checkbox') {
                    continue;
                }

                $fields[$group['prefix'] . $name] = [
                    'section' => $section,
                    'name'    => $name,
                    'label'   => (string)Arr::get($definition, 'label', $name),
                ];
            }
        }

        return $fields;
    }

    /**
     * Settings section => its group label and condition key prefix.
     *
     * @return array
     */
    protected static function sections(): array
    {
        return [
            'basic_info'       => ['label' => __('Basic Info', 'fluent-cart-pro'), 'prefix' => 'checkout_'],
            'business_details' => ['label' => __('Business Details', 'fluent-cart-pro'), 'prefix' => 'checkout_'],
            'billing_address'  => ['label' => __('Billing Address', 'fluent-cart-pro'), 'prefix' => 'checkout_billing_'],
            'shipping_address' => ['label' => __('Shipping Address', 'fluent-cart-pro'), 'prefix' => 'checkout_shipping_'],
        ];
    }

    /**
     * The buyer's full name: as typed, else built from first and last name.
     *
     * @param Cart $cart
     * @param array $form
     * @return string
     */
    protected static function fullName(Cart $cart, array $form): string
    {
        $fullName = trim((string)Arr::get($form, 'billing_full_name'));

        return $fullName !== '' ? $fullName : trim(implode(' ', static::names($cart, $form)));
    }

    /**
     * The buyer's first and last name: as typed into split name fields, else
     * the full name split the way the checkout splits it, else the cart's.
     *
     * @param Cart $cart
     * @param array $form
     * @return array
     */
    protected static function names(Cart $cart, array $form): array
    {
        $first = (string)Arr::get($form, 'billing_first_name');
        $last = (string)Arr::get($form, 'billing_last_name');

        if (trim($first . $last) !== '') {
            return [$first, $last];
        }

        $fullName = trim((string)Arr::get($form, 'billing_full_name'));

        if ($fullName !== '') {
            $parts = explode(' ', $fullName, 2);

            return [$parts[0], $parts[1] ?? ''];
        }

        return [(string)$cart->first_name, (string)$cart->last_name];
    }

    /**
     * The VAT number with its country prefix. The EU check stores the number
     * without it and the country beside it, so a validated number reads the
     * same as the one typed.
     *
     * @param array $checkoutData
     * @return string
     */
    protected static function vatNumber(array $checkoutData): string
    {
        $number = trim((string)Arr::get($checkoutData, 'tax_data.vat_number'));
        $country = strtoupper(trim((string)Arr::get($checkoutData, 'tax_data.country')));

        if ($number === '' || $country === '' || stripos($number, $country) === 0) {
            return $number;
        }

        return $country . $number;
    }

    /**
     * @param mixed $value
     * @return array|null
     */
    protected static function filled($value)
    {
        $value = is_scalar($value) ? trim((string)$value) : '';

        return $value === '' ? null : [$value];
    }
}
