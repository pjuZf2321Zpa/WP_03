<?php
if (!defined('ABSPATH')) {
    die('You are not allowed to call this page directly.');
}

$mepr_search             = isset($_GET['search']) ? sanitize_text_field(wp_unslash($_GET['search'])) : '';
$mepr_status             = isset($_GET['status']) ? sanitize_key(wp_unslash($_GET['status'])) : '';
$primary_code            = MeprOptions::fetch()->currency_code;
$current_currency_filter = isset($_GET['currency']) ? sanitize_text_field(wp_unslash($_GET['currency'])) : 'all';
$enabled_currencies      = MeprCurrencyService::get_enabled_currencies();
$show_currency_filter    = count($enabled_currencies) > 1;
?>
<p class="mepr-search-box mepr-cart-orders-search-box">
    <?php if (!empty($mepr_status)) : ?>
        <input type="hidden" name="status" value="<?php echo esc_attr($mepr_status); ?>" />
    <?php endif; ?>

    <?php if ($show_currency_filter) : ?>
    <span class="mepr-filter-by">
        <label for="mepr-currency-filter"><?php esc_html_e('Filter by', 'memberpress'); ?></label>
        <select name="currency" id="mepr-currency-filter" class="mepr_filter_field mepr-currency-filter-select">
            <option value="all" <?php selected($current_currency_filter, 'all'); ?>><?php
                // Translators: %s: primary currency code.
                printf(esc_html__('All (shown in %s)', 'memberpress'), esc_html($primary_code));
            ?></option>
            <?php foreach ($enabled_currencies as $code) : ?>
                <option value="<?php echo esc_attr($code); ?>" <?php selected($current_currency_filter, $code); ?>><?php echo esc_html($code); ?></option>
            <?php endforeach; ?>
        </select>
        <input type="submit" class="button" value="<?php esc_attr_e('Go', 'memberpress'); ?>" />
    </span>
    <?php elseif ($current_currency_filter !== 'all' && $current_currency_filter !== '') : ?>
        <input type="hidden" name="currency" value="<?php echo esc_attr($current_currency_filter); ?>" />
    <?php endif; ?>

    <span class="mepr-search-fields">
        <label class="screen-reader-text" for="mepr-cart-orders-search-input">
            <?php esc_html_e('Search Orders', 'memberpress'); ?>
        </label>
        <input
            type="search"
            id="mepr-cart-orders-search-input"
            name="search"
            value="<?php echo esc_attr($mepr_search); ?>"
            placeholder="<?php esc_attr_e('Search by order # or customer email&hellip;', 'memberpress'); ?>"
        />
        <?php submit_button(__('Search Orders', 'memberpress'), '', false, false, ['id' => 'search-submit']); ?>
    </span>
</p>
