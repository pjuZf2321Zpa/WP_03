<?php

namespace FluentBookingPro\App\Services;

/**
 * Who this install treats as its team, for the routes that act on a person by id.
 *
 * Zoom accounts and per-host integration settings belong to a WordPress user, not
 * to a calendar, so no calendar scope reaches them. A single site answers null to
 * fluent_booking/team_member_user_ids - everyone - and nothing here changes
 * anything. A host serving several accounts from one install answers with the
 * members of the bound account, and these routes then refuse anyone else.
 */
class TeamMembers
{
    /**
     * @return int[]|null null for everyone
     */
    public static function ids()
    {
        $userIds = apply_filters('fluent_booking/team_member_user_ids', null);

        return is_array($userIds) ? array_values(array_map('intval', $userIds)) : null;
    }

    /**
     * @param int $userId
     * @return bool true when the install limits its team and $userId is not in it
     */
    public static function excludes($userId)
    {
        $ids = self::ids();

        return $ids !== null && !in_array((int) $userId, $ids, true);
    }
}
