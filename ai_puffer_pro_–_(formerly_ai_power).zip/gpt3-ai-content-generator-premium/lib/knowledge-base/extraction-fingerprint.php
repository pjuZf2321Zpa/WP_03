<?php

namespace WPAICG\Lib\KnowledgeBase;

use WP_Post;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Creates deterministic, value-free fingerprints for knowledge extraction rules.
 */
final class AIPKit_Knowledge_Extraction_Fingerprint
{
    private const CONTRACT_VERSION = 4;

    private static $registered = false;

    public static function register_hooks(): void
    {
        if (self::$registered) {
            return;
        }

        add_filter('aipkit_knowledge_base_extraction_fingerprint', [self::class, 'filter_fingerprint'], 10, 2);
        self::$registered = true;
    }

    public static function filter_fingerprint(string $fingerprint, WP_Post $post): string
    {
        return self::for_post_type((string) $post->post_type);
    }

    public static function for_post_type(string $post_type): string
    {
        $payload = self::payload_for_post_type($post_type);
        $encoded = wp_json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);

        return hash('sha256', is_string($encoded) ? $encoded : serialize($payload));
    }

    /**
     * Returns the normalized configuration used to calculate a fingerprint.
     * No post content or metadata values are included.
     *
     * @return array<string,mixed>
     */
    public static function payload_for_post_type(string $post_type): array
    {
        $post_type = sanitize_key($post_type);
        $legacy_settings = get_option('aipkit_indexing_field_settings', []);
        $legacy_for_type = is_array($legacy_settings) && isset($legacy_settings[$post_type])
            && is_array($legacy_settings[$post_type])
            ? $legacy_settings[$post_type]
            : [];

        $payload = [
            'contract_version' => self::CONTRACT_VERSION,
            'post_type' => $post_type,
            'extraction_strategy' => 'automatic',
            'legacy_rules' => self::normalize_legacy_rules($post_type, $legacy_for_type),
        ];

        /**
         * Filters the value-free extraction configuration before hashing.
         *
         * Extensions may add parser or adapter versions, but must not add post
         * content, metadata values, credentials, or other private data.
         *
         * @param array  $payload   Normalized extraction configuration.
         * @param string $post_type WordPress post type.
         */
        $filtered = apply_filters(
            'aipkit_knowledge_extraction_fingerprint_payload',
            $payload,
            $post_type
        );

        return self::canonicalize(is_array($filtered) ? $filtered : $payload);
    }

    /**
     * @param array<mixed> $rules Raw legacy rules for one post type.
     * @return array<string,mixed>
     */
    private static function normalize_legacy_rules(string $post_type, array $rules): array
    {
        $normalized = [
            'basic_labels' => [
                'source_url' => self::label($rules['basic_labels']['source_url'] ?? '', 'Source URL'),
                'title' => self::label($rules['basic_labels']['title'] ?? '', 'Title'),
                'excerpt' => self::label($rules['basic_labels']['excerpt'] ?? '', 'Excerpt'),
                'content' => self::label($rules['basic_labels']['content'] ?? '', 'Content'),
            ],
            'fields' => self::normalize_enabled_items($rules['fields'] ?? []),
            'taxonomies' => self::normalize_enabled_items($rules['taxonomies'] ?? []),
            'woo_attributes' => self::normalize_enabled_items($rules['woo_attributes'] ?? []),
        ];

        if (
            $post_type === 'product'
            && isset($normalized['woo_attributes']['dimensions'])
        ) {
            $normalized['woocommerce_units'] = [
                'dimension' => sanitize_text_field((string) get_option('woocommerce_dimension_unit', '')),
                'weight' => sanitize_text_field((string) get_option('woocommerce_weight_unit', '')),
            ];
        }

        return $normalized;
    }

    /**
     * @param mixed $items Raw field/taxonomy/attribute rules.
     * @return array<string,array{label:string}>
     */
    private static function normalize_enabled_items($items): array
    {
        if (!is_array($items)) {
            return [];
        }

        $normalized = [];
        foreach ($items as $key => $config) {
            if (!is_array($config) || empty($config['enabled'])) {
                continue;
            }

            $key = is_scalar($key) ? trim((string) $key) : '';
            if ($key === '') {
                continue;
            }

            $default_label = ucwords(trim(str_replace(['_', '-', '.'], ' ', $key)));
            $normalized[$key] = [
                'label' => self::label($config['label'] ?? '', $default_label),
            ];
        }

        return $normalized;
    }

    private static function label($value, string $fallback): string
    {
        $value = is_scalar($value) ? sanitize_text_field((string) $value) : '';

        return $value !== '' ? $value : $fallback;
    }

    /**
     * Recursively sorts associative keys while preserving meaningful list order.
     *
     * @param mixed $value
     * @return mixed
     */
    private static function canonicalize($value)
    {
        if (!is_array($value)) {
            return $value;
        }

        if (!self::is_list($value)) {
            ksort($value, SORT_STRING);
        }

        foreach ($value as $key => $item) {
            $value[$key] = self::canonicalize($item);
        }

        return $value;
    }

    /** @param array<mixed> $value */
    private static function is_list(array $value): bool
    {
        if ($value === []) {
            return true;
        }

        return array_keys($value) === range(0, count($value) - 1);
    }
}
