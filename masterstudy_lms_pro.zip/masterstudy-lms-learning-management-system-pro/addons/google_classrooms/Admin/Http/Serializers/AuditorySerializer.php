<?php

namespace MasterStudy\Lms\Pro\addons\google_classrooms\Admin\Http\Serializers;

use MasterStudy\Lms\Http\Serializers\AbstractSerializer;

final class AuditorySerializer extends AbstractSerializer {

	/**
	 * @param \WP_Post $post
	 */
	public function toArray( $post ): array {
		return array(
			'id'             => (int) $post->ID,
			'title'          => get_the_title( $post->ID ),
			'date'           => (string) $post->post_date,
			'date_formatted' => \STM_LMS_Helpers::format_date( $post->post_date ),
			'status'         => (string) $post->post_status,
		);
	}
}
