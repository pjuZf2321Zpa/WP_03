<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

function masterstudy_lms_notifications_table_name( $wpdb ) {
	return $wpdb->prefix . 'masterstudy_notifications';
}

function masterstudy_lms_notification_recipients_table_name( $wpdb ) {
	return $wpdb->prefix . 'masterstudy_notification_recipients';
}

function masterstudy_lms_notification_push_subscriptions_table_name( $wpdb ) {
	return $wpdb->prefix . 'masterstudy_notification_push_subscriptions';
}

function masterstudy_lms_notification_push_queue_table_name( $wpdb ) {
	return $wpdb->prefix . 'masterstudy_notification_push_queue';
}

function masterstudy_lms_notification_dispatch_queue_table_name( $wpdb ) {
	return $wpdb->prefix . 'masterstudy_notification_dispatch_queue';
}

function masterstudy_lms_notifications_tables() {
	masterstudy_lms_notifications_table_query();
	masterstudy_lms_notification_recipients_table_query();
	masterstudy_lms_notification_push_subscriptions_table_query();
	masterstudy_lms_notification_push_queue_table_query();
	masterstudy_lms_notification_dispatch_queue_table_query();
}
