<?php

namespace WPAICG\Lib\Utils;

use WP_Error;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Handles sanitizing and processing Google Service Account credentials.
 */
class AIPKit_Google_Credentials_Handler
{
    /**
     * Processes raw Google Sheets credentials from user input into a consistent array format.
     * It handles cases where input is a full JSON string, just the private key, or already an array.
     *
     * @param mixed $creds The raw credentials input from a form.
     * @return array|null The processed credentials as an associative array, or null if input is invalid.
     */
    public static function process_credentials($creds): ?array
    {
        if (empty($creds)) {
            return null;
        }

        if (is_string($creds)) {
            $decoded_creds = json_decode($creds, true);
            if (json_last_error() === JSON_ERROR_NONE && is_array($decoded_creds)) {
                // It was a valid JSON string, return the decoded array
                return self::normalize_credentials_array($decoded_creds);
            } elseif (strpos($creds, '-----BEGIN PRIVATE KEY-----') !== false) {
                // This case is unlikely to be valid as it's missing other critical fields
                // like client_email, but we can reconstruct a partial object to preserve the key.
                return self::normalize_credentials_array([
                    'type' => 'service_account',
                    'project_id' => '',
                    'private_key_id' => '',
                    'private_key' => $creds,
                    'client_email' => '',
                    'client_id' => '',
                    'auth_uri' => 'https://accounts.google.com/o/oauth2/auth',
                    'token_uri' => 'https://oauth2.googleapis.com/token',
                    'auth_provider_x509_cert_url' => 'https://www.googleapis.com/oauth2/v1/certs',
                    'client_x509_cert_url' => ''
                ]);
            } else {
                // Invalid string format
                return null;
            }
        } elseif (is_array($creds)) {
            // Already an array, return it
            return self::normalize_credentials_array($creds);
        }

        return null;
    }

    /**
     * @param array<string, mixed> $credentials
     * @return array<string, mixed>
     */
    private static function normalize_credentials_array(array $credentials): array
    {
        if (empty($credentials['token_uri']) || !is_string($credentials['token_uri'])) {
            $credentials['token_uri'] = 'https://oauth2.googleapis.com/token';
        }

        if (!empty($credentials['private_key']) && is_string($credentials['private_key'])) {
            $credentials['private_key'] = self::normalize_private_key($credentials['private_key']);
        }

        return $credentials;
    }

    private static function normalize_private_key(string $private_key): string
    {
        $normalized_key = str_replace(["\r\n", "\r"], "\n", $private_key);

        if (strpos($normalized_key, '\\n') !== false) {
            $normalized_key = str_replace('\\n', "\n", $normalized_key);
        }

        $normalized_key = trim($normalized_key);

        if ($normalized_key !== '' && strpos($normalized_key, '-----BEGIN ') === 0) {
            $normalized_key .= "\n";
        }

        return $normalized_key;
    }
}

/**
 * Handles Google service-account OAuth token exchange for direct REST calls.
 */
class AIPKit_Google_Service_Account_Token_Service
{
    private const DEFAULT_SCOPE = 'https://www.googleapis.com/auth/spreadsheets';
    private const DEFAULT_TOKEN_URI = 'https://oauth2.googleapis.com/token';
    private const CACHE_PREFIX = 'aipkit_google_token_';
    private const CLOCK_SKEW_SECONDS = 60;
    private const REQUEST_TIMEOUT = 20;

    /**
     * Per-request in-memory cache to avoid repeated transient reads.
     *
     * @var array<string, array{access_token: string, expires_at: int}>
     */
    private static array $memory_cache = [];

    /**
     * @var array<string, mixed>
     */
    private array $credentials;

    private string $scope;
    private string $cache_key;

    /**
     * @param array<string, mixed> $credentials
     */
    public function __construct(array $credentials, string $scope = self::DEFAULT_SCOPE)
    {
        $normalized_credentials = AIPKit_Google_Credentials_Handler::process_credentials($credentials);

        $this->credentials = is_array($normalized_credentials) ? $normalized_credentials : $credentials;
        $this->scope = !empty($scope) ? $scope : self::DEFAULT_SCOPE;
        $this->cache_key = $this->build_cache_key();
    }

    /**
     * Returns a valid Google OAuth access token for the configured service account.
     *
     * @return string|WP_Error
     */
    public function get_access_token()
    {
        $credentials_validation = $this->validate_credentials();
        if (is_wp_error($credentials_validation)) {
            return $credentials_validation;
        }

        $cached_token = $this->get_cached_token();
        if (is_string($cached_token) && $cached_token !== '') {
            return $cached_token;
        }

        $signed_jwt = $this->build_signed_jwt();
        if (is_wp_error($signed_jwt)) {
            return $signed_jwt;
        }

        return $this->exchange_jwt_for_access_token($signed_jwt);
    }

    public function clear_cached_token(): void
    {
        unset(self::$memory_cache[$this->cache_key]);
        delete_transient($this->cache_key);
    }

    /**
     * @return true|WP_Error
     */
    private function validate_credentials()
    {
        if (empty($this->credentials['client_email']) || !is_string($this->credentials['client_email'])) {
            return new WP_Error(
                'google_service_account_missing_client_email',
                __('Google service account credentials are missing the client email.', 'gpt3-ai-content-generator')
            );
        }

        if (empty($this->credentials['private_key']) || !is_string($this->credentials['private_key'])) {
            return new WP_Error(
                'google_service_account_missing_private_key',
                __('Google service account credentials are missing the private key.', 'gpt3-ai-content-generator')
            );
        }

        $token_uri = $this->get_token_uri();
        if ($token_uri === '') {
            return new WP_Error(
                'google_service_account_missing_token_uri',
                __('Google service account credentials are missing the token URI.', 'gpt3-ai-content-generator')
            );
        }

        return true;
    }

    /**
     * @return string|false
     */
    private function get_cached_token()
    {
        $cached_token = self::$memory_cache[$this->cache_key] ?? null;
        if ($this->is_cached_token_valid($cached_token)) {
            return $cached_token['access_token'];
        }

        $transient_value = get_transient($this->cache_key);
        if ($this->is_cached_token_valid($transient_value)) {
            self::$memory_cache[$this->cache_key] = $transient_value;
            return $transient_value['access_token'];
        }

        if ($transient_value !== false) {
            delete_transient($this->cache_key);
        }

        return false;
    }

    /**
     * @return string|WP_Error
     */
    private function build_signed_jwt()
    {
        $jwt_header = wp_json_encode([
            'alg' => 'RS256',
            'typ' => 'JWT',
        ]);

        $issued_at = time();
        $jwt_claims = wp_json_encode([
            'iss' => $this->credentials['client_email'],
            'scope' => $this->scope,
            'aud' => $this->get_token_uri(),
            'iat' => $issued_at,
            'exp' => $issued_at + HOUR_IN_SECONDS,
        ]);

        if (!is_string($jwt_header) || !is_string($jwt_claims)) {
            return new WP_Error(
                'google_service_account_jwt_encode_failed',
                __('Failed to encode the Google service account JWT payload.', 'gpt3-ai-content-generator')
            );
        }

        $signing_input = self::base64_url_encode($jwt_header) . '.' . self::base64_url_encode($jwt_claims);
        $private_key_resource = openssl_pkey_get_private($this->credentials['private_key']);

        if ($private_key_resource === false) {
            return new WP_Error(
                'google_service_account_invalid_private_key',
                __('The Google service account private key is invalid.', 'gpt3-ai-content-generator')
            );
        }

        $signature = '';
        $sign_result = openssl_sign($signing_input, $signature, $private_key_resource, OPENSSL_ALGO_SHA256);

        if (is_resource($private_key_resource)) {
            openssl_free_key($private_key_resource);
        }

        if ($sign_result !== true) {
            return new WP_Error(
                'google_service_account_sign_failed',
                __('Failed to sign the Google service account JWT.', 'gpt3-ai-content-generator')
            );
        }

        return $signing_input . '.' . self::base64_url_encode($signature);
    }

    /**
     * @return string|WP_Error
     */
    private function exchange_jwt_for_access_token(string $signed_jwt)
    {
        $response = wp_remote_post(
            $this->get_token_uri(),
            [
                'timeout' => self::REQUEST_TIMEOUT,
                'headers' => [
                    'Content-Type' => 'application/x-www-form-urlencoded',
                ],
                'body' => [
                    'grant_type' => 'urn:ietf:params:oauth:grant-type:jwt-bearer',
                    'assertion' => $signed_jwt,
                ],
            ]
        );

        if (is_wp_error($response)) {
            return new WP_Error(
                'google_service_account_token_request_failed',
                sprintf(
                    /* translators: %s: Network error message from WordPress HTTP API. */
                    __('Failed to request a Google access token: %s', 'gpt3-ai-content-generator'),
                    $response->get_error_message()
                )
            );
        }

        $status_code = wp_remote_retrieve_response_code($response);
        $response_body = wp_remote_retrieve_body($response);
        $decoded_body = json_decode($response_body, true);

        if ($status_code < 200 || $status_code >= 300) {
            $error_message = $this->extract_error_message($decoded_body, $response_body);

            return new WP_Error(
                'google_service_account_token_http_error',
                sprintf(
                    /* translators: 1: HTTP status code, 2: Google token endpoint error message. */
                    __('Google token exchange failed (%1$d): %2$s', 'gpt3-ai-content-generator'),
                    $status_code,
                    $error_message
                ),
                ['status' => $status_code]
            );
        }

        if (!is_array($decoded_body)) {
            return new WP_Error(
                'google_service_account_token_response_invalid_json',
                __('The Google token response was not valid JSON.', 'gpt3-ai-content-generator')
            );
        }

        $access_token = isset($decoded_body['access_token']) && is_string($decoded_body['access_token'])
            ? trim($decoded_body['access_token'])
            : '';
        $token_type = isset($decoded_body['token_type']) && is_string($decoded_body['token_type'])
            ? trim($decoded_body['token_type'])
            : '';
        $expires_in = isset($decoded_body['expires_in']) ? (int) $decoded_body['expires_in'] : 0;

        if ($access_token === '' || $token_type === '' || strcasecmp($token_type, 'Bearer') !== 0 || $expires_in <= 0) {
            return new WP_Error(
                'google_service_account_token_response_invalid',
                __('The Google token response was missing required fields.', 'gpt3-ai-content-generator')
            );
        }

        $cache_ttl = max(0, $expires_in - self::CLOCK_SKEW_SECONDS);
        $expires_at = time() + $cache_ttl;
        $cache_payload = [
            'access_token' => $access_token,
            'expires_at' => $expires_at,
        ];

        self::$memory_cache[$this->cache_key] = $cache_payload;

        if ($cache_ttl > 0) {
            set_transient($this->cache_key, $cache_payload, $cache_ttl);
        }

        return $access_token;
    }

    /**
     * @param mixed $cache_value
     */
    private function is_cached_token_valid($cache_value): bool
    {
        return is_array($cache_value)
            && !empty($cache_value['access_token'])
            && is_string($cache_value['access_token'])
            && !empty($cache_value['expires_at'])
            && is_numeric($cache_value['expires_at'])
            && (int) $cache_value['expires_at'] > time();
    }

    private function build_cache_key(): string
    {
        $cache_source = wp_json_encode([
            'client_email' => (string) ($this->credentials['client_email'] ?? ''),
            'private_key_id' => (string) ($this->credentials['private_key_id'] ?? ''),
            'scope' => $this->scope,
        ]);

        if (!is_string($cache_source) || $cache_source === '') {
            $cache_source = implode('|', [
                (string) ($this->credentials['client_email'] ?? ''),
                (string) ($this->credentials['private_key_id'] ?? ''),
                $this->scope,
            ]);
        }

        return self::CACHE_PREFIX . hash('sha256', $cache_source);
    }

    private function get_token_uri(): string
    {
        $token_uri = $this->credentials['token_uri'] ?? self::DEFAULT_TOKEN_URI;

        return esc_url_raw(is_string($token_uri) ? $token_uri : self::DEFAULT_TOKEN_URI);
    }

    /**
     * @param mixed $decoded_body
     */
    private function extract_error_message($decoded_body, string $response_body): string
    {
        if (is_array($decoded_body)) {
            if (!empty($decoded_body['error_description']) && is_string($decoded_body['error_description'])) {
                return $decoded_body['error_description'];
            }

            if (!empty($decoded_body['error']['message']) && is_string($decoded_body['error']['message'])) {
                return $decoded_body['error']['message'];
            }

            if (!empty($decoded_body['error']) && is_string($decoded_body['error'])) {
                return $decoded_body['error'];
            }
        }

        $trimmed_body = trim($response_body);

        return $trimmed_body !== ''
            ? $trimmed_body
            : __('Unknown Google token service error.', 'gpt3-ai-content-generator');
    }

    private static function base64_url_encode(string $value): string
    {
        return rtrim(strtr(base64_encode($value), '+/', '-_'), '=');
    }
}
