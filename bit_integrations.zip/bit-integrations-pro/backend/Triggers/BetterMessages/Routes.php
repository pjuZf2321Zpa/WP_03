<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Core\Util\Route;
use BitApps\IntegrationsPro\Triggers\BetterMessages\BetterMessagesController;

Route::get('better_messages/get', [BetterMessagesController::class, 'getAllTasks']);
