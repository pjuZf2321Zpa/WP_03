<?php
use MasterStudy\Lms\Pro\addons\CourseBundle\Repository\CourseBundleSettings;
use MasterStudy\Lms\Plugin\PostType;

function masterstudy_lms_course_bundle_register_post_type( $post_types ) {
	$post_types[] = PostType::COURSE_BUNDLES;

	return $post_types;
}
add_filter( 'stm_lms_post_types', 'masterstudy_lms_course_bundle_register_post_type', 5, 1 );
add_action( 'masterstudy_woo_post_types', 'masterstudy_lms_course_bundle_register_post_type' );

function masterstudy_lms_course_bundle_post_type( $posts ) {
	$posts[ PostType::COURSE_BUNDLES ] = array(
		'single' => esc_html__( 'Course Bundles', 'masterstudy-lms-learning-management-system-pro' ),
		'plural' => esc_html__( 'Course Bundles', 'masterstudy-lms-learning-management-system-pro' ),
		'args'   => array(
			'public'              => true,
			'exclude_from_search' => false,
			'publicly_queryable'  => true,
			'show_in_menu'        => false,
			'supports'            => array( 'title', 'editor', 'thumbnail', 'revisions', 'author' ),
		),
	);

	return $posts;
}
add_filter( 'stm_lms_post_types_array', 'masterstudy_lms_course_bundle_post_type', 10, 1 );

function masterstudy_lms_course_bundle_menu_item( $menus ) {
	if ( STM_LMS_Instructor::is_instructor() ) {
		$current_slug = masterstudy_get_current_account_slug();

		$menus[] = array(
			'order'        => 50,
			'id'           => 'bundles',
			'slug'         => 'bundles',
			'lms_template' => 'stm-lms-user-bundles',
			'menu_title'   => esc_html__( 'Bundles', 'masterstudy-lms-learning-management-system-pro' ),
			'menu_icon'    => 'stmlms-menu-bundles',
			'menu_url'     => ms_plugin_user_account_url( 'bundles' ),
			'is_active'    => 'bundles' === $current_slug,
			'menu_place'   => 'main',
			'section'      => 'main',
		);
	}

	return $menus;
}
add_filter( 'stm_lms_menu_items', 'masterstudy_lms_course_bundle_menu_item' );

function masterstudy_lms_course_bundle_can_access_admin_page() {
	return is_ms_lms_addon_enabled( 'course_bundle' ) && current_user_can( 'manage_options' );
}

function masterstudy_lms_course_bundle_admin_submenu_items( $items ) {
	if ( ! is_ms_lms_addon_enabled( 'course_bundle' ) ) {
		return $items;
	}

	$items['manage_bundles'] = array(
		'aliases'         => array( 'edit.php?post_type=stm-bundles' ),
		'order'           => 91,
		'register'        => true,
		'page_title'      => esc_html__( 'Bundles', 'masterstudy-lms-learning-management-system-pro' ),
		'menu_title'      => esc_html__( 'Bundles', 'masterstudy-lms-learning-management-system-pro' ),
		'capability'      => 'manage_options',
		'callback'        => 'masterstudy_lms_render_admin_react_page',
		'access_callback' => 'masterstudy_lms_course_bundle_can_access_admin_page',
	);

	return $items;
}
add_filter( 'masterstudy_lms_admin_submenu_items', 'masterstudy_lms_course_bundle_admin_submenu_items' );

function masterstudy_lms_course_bundle_instructor_react_menu_items( $items ) {
	if ( ! is_ms_lms_addon_enabled( 'course_bundle' ) ) {
		return $items;
	}

	$items['manage_bundles'] = array(
		'page_title' => esc_html__( 'Course Bundles', 'masterstudy-lms-learning-management-system-pro' ),
		'menu_title' => esc_html__( 'Course Bundles', 'masterstudy-lms-learning-management-system-pro' ),
		'capability' => 'stm_lms_instructor',
		'menu_slug'  => 'manage_bundles',
		'icon_url'   => 'dashicons-admin-post',
		'position'   => 32,
		'app_slug'   => 'react_bundles',
	);

	return $items;
}
add_filter( 'masterstudy_lms_instructor_react_menu_items', 'masterstudy_lms_course_bundle_instructor_react_menu_items' );

function masterstudy_lms_course_bundle_settings_sections() {
	return apply_filters(
		'stm_lms_course_bundle_settings',
		array(
			'credentials' => array(
				'name'   => esc_html__( 'Credentials', 'masterstudy-lms-learning-management-system-pro' ),
				'fields' => array(
					'bundle_limit'         => array(
						'type'        => 'text',
						'label'       => esc_html__( 'Bundles quantity limit', 'masterstudy-lms-learning-management-system-pro' ),
						'description' => esc_html__( 'Set the maximum number of bundles that can be created', 'masterstudy-lms-learning-management-system-pro' ),
					),
					'bundle_courses_limit' => array(
						'type'  => 'text',
						'label' => esc_html__(
							'Courses in bundle quantity limit',
							'masterstudy-lms-learning-management-system-pro'
						),
						'hint'  => esc_html__(
							'By default, the limit is 5 courses per bundle',
							'masterstudy-lms-learning-management-system-pro'
						),
					),
				),
			),
		)
	);
}

function masterstudy_lms_course_bundle_settings_fields() {
	$sections = masterstudy_lms_course_bundle_settings_sections();
	$fields   = array();

	foreach ( $sections as $section ) {
		if ( ! empty( $section['fields'] ) && is_array( $section['fields'] ) ) {
			$fields = array_merge( $fields, $section['fields'] );
		}
	}

	return $fields;
}

function masterstudy_lms_course_bundle_setting_keys() {
	return array_keys( masterstudy_lms_course_bundle_settings_fields() );
}

function masterstudy_lms_course_bundle_add_to_main_settings( $fields ) {
	$fields['section_course_bundle'] = array(
		'name'   => esc_html__( 'Course Bundle', 'masterstudy-lms-learning-management-system-pro' ),
		'label'  => esc_html__( 'Course Bundle Settings', 'masterstudy-lms-learning-management-system-pro' ),
		'icon'   => 'stmlms-bundles-stats',
		'fields' => masterstudy_lms_course_bundle_settings_fields(),
	);

	return $fields;
}
add_filter( 'stm_lms_main_settings_fields', 'masterstudy_lms_course_bundle_add_to_main_settings', 16 );

function masterstudy_lms_course_bundle_sync_with_main( $id, $settings ) {
	if ( 'stm_lms_settings' !== $id || ! is_array( $settings ) ) {
		return;
	}

	$legacy_settings = get_option( CourseBundleSettings::OPTION_NAME, array() );
	if ( ! is_array( $legacy_settings ) ) {
		$legacy_settings = array();
	}

	foreach ( masterstudy_lms_course_bundle_setting_keys() as $key ) {
		if ( array_key_exists( $key, $settings ) ) {
			$legacy_settings[ $key ] = $settings[ $key ];
		}
	}

	update_option( CourseBundleSettings::OPTION_NAME, $legacy_settings );
}
add_action( 'wpcfto_after_settings_saved', 'masterstudy_lms_course_bundle_sync_with_main', 10, 2 );

function masterstudy_lms_course_bundle_migrate_to_main_settings() {
	$legacy_settings = get_option( CourseBundleSettings::OPTION_NAME, array() );
	$main_settings   = get_option( 'stm_lms_settings', array() );

	if ( ! is_array( $legacy_settings ) || empty( $legacy_settings ) ) {
		return;
	}

	if ( ! is_array( $main_settings ) ) {
		$main_settings = array();
	}

	$changed = false;
	foreach ( masterstudy_lms_course_bundle_setting_keys() as $key ) {
		if (
			( ! array_key_exists( $key, $main_settings ) || '' === $main_settings[ $key ] )
			&& array_key_exists( $key, $legacy_settings )
			&& '' !== $legacy_settings[ $key ]
		) {
			$main_settings[ $key ] = $legacy_settings[ $key ];
			$changed               = true;
		}
	}

	if ( $changed ) {
		update_option( 'stm_lms_settings', $main_settings );
	}
}
add_action( 'admin_init', 'masterstudy_lms_course_bundle_migrate_to_main_settings' );

function masterstudy_lms_course_bundle_redirect_legacy_page() {
	if ( ! is_admin() ) {
		return;
	}

	$page = isset( $_GET['page'] ) ? sanitize_text_field( wp_unslash( $_GET['page'] ) ) : '';
	if ( 'course_bundle_settings' !== $page ) {
		return;
	}

	wp_safe_redirect( admin_url( 'admin.php?page=stm-lms-settings&submenu=course-bundles#section_2' ) );
	exit;
}
add_action( 'admin_init', 'masterstudy_lms_course_bundle_redirect_legacy_page' );

add_filter( 'stm_lms_accept_order', '__return_false' );

function masterstudy_lms_course_budle_after_single_item_cart_title( $item ) {
	if ( ! empty( $item['bundle'] ) ) {
		echo '<span class="enterprise-course-added"><label>' . esc_html__( 'Bundle', 'masterstudy-lms-learning-management-system-pro' ) . '</label></span>';
	}
}
add_filter( 'stm_lms_after_single_item_cart_title', 'masterstudy_lms_course_budle_after_single_item_cart_title' );

function masterstudy_lms_course_budle_cart_items_fields( $fields ) {
	$fields[] = 'bundle';

	return $fields;
}
add_filter( 'stm_lms_cart_items_fields', 'masterstudy_lms_course_budle_cart_items_fields' );
