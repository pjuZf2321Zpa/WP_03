<?php

namespace BitApps\IntegrationsPro\Triggers\EssentialBlocks;

use BitApps\IntegrationsPro\Config;

class EssentialBlocksController
{
    public static function info()
    {
        return [
            'name'              => 'Essential Blocks',
            'type'              => 'custom_form_submission',
            'is_active'         => static::isPluginInstalled(),
            'documentation_url' => 'https://bit-integrations.com/wp-docs/trigger/essential-blocks-integrations/',
            'tutorial_url'      => '#',
            'tasks'             => [
                'action' => 'essential_blocks/get',
                'method' => 'get',
            ],
            'fetch' => [
                'action' => 'trigger/test',
                'method' => 'post',
            ],
            'fetch_remove' => [
                'action' => 'trigger/test/remove',
                'method' => 'post',
            ],
            'isPro' => true
        ];
    }

    public function getAllTasks()
    {
        if (!static::isPluginInstalled()) {
            wp_send_json_error(\sprintf(__('%s is not installed or activated', 'bit-integrations-pro'), 'Essential Blocks'));
        }

        wp_send_json_success([
            ['form_name' => __('Form Submission', 'bit-integrations-pro'), 'triggered_entity_id' => 'eb_form_submit_before_email', 'skipPrimaryKey' => false],
        ]);
    }

    public static function handleFormSubmitted($formId, $fields, $notification)
    {
        $helperClass = bit_integrations_get_class('Core\\Util\\Helper');
        $flowClass = bit_integrations_get_class('Flow\\Flow');

        if (empty($formId)) {
            return;
        }

        $fields['form_id'] = $formId;
        $fields['notification'] = $notification;

        $entity = 'EssentialBlocks';
        $entityId = 'eb_form_submit_before_email';
        $fieldsData = $helperClass::prepareFetchFormatFields($fields);

        $helperClass::setTestData(Config::withFreePrefix("{$entityId}_test"), $fieldsData, 'form_id.value', $formId);

        $flows = $flowClass::exists($entity, $entityId);

        if (empty($flows)) {
            return;
        }

        $data = array_column($fieldsData, 'value', 'name');

        foreach ($flows as $flow) {
            $flowDetails = $helperClass::parseFlowDetails($flow->flow_details);

            if (isset($flowDetails->primaryKey) && $helperClass::isPrimaryKeysMatch($fieldsData, $flowDetails->primaryKey)) {
                $flowClass::execute($entity, $entityId, $data, [$flow]);
            }
        }

        return ['type' => 'success'];
    }

    private static function isPluginInstalled()
    {
        return class_exists('\EssentialBlocks\Plugin');
    }
}
