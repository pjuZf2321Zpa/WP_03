<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Actions\WordPress\WordPressProHelper;
use BitApps\IntegrationsPro\Config;
use BitApps\IntegrationsPro\Core\Util\Hooks;

Hooks::filter(Config::withFreePrefix('wordpress_registerPostType'), [WordPressProHelper::class, 'registerPostType'], 10, 3);
Hooks::filter(Config::withFreePrefix('wordpress_unregisterPostType'), [WordPressProHelper::class, 'unregisterPostType'], 10, 3);
Hooks::filter(Config::withFreePrefix('wordpress_addPostTypeFeatures'), [WordPressProHelper::class, 'addPostTypeFeatures'], 10, 3);

Hooks::filter(Config::withFreePrefix('wordpress_createPostTag'), [WordPressProHelper::class, 'createPostTag'], 10, 3);
Hooks::filter(Config::withFreePrefix('wordpress_updatePostTag'), [WordPressProHelper::class, 'updatePostTag'], 10, 3);
Hooks::filter(Config::withFreePrefix('wordpress_deletePostTag'), [WordPressProHelper::class, 'deletePostTag'], 10, 3);
Hooks::filter(Config::withFreePrefix('wordpress_addTaxonomyToPost'), [WordPressProHelper::class, 'addTaxonomyToPost'], 10, 3);
Hooks::filter(Config::withFreePrefix('wordpress_removeTaxonomyFromPost'), [WordPressProHelper::class, 'removeTaxonomyFromPost'], 10, 3);
Hooks::filter(Config::withFreePrefix('wordpress_addTagsToPost'), [WordPressProHelper::class, 'addTagsToPost'], 10, 3);
Hooks::filter(Config::withFreePrefix('wordpress_removeTagsFromPost'), [WordPressProHelper::class, 'removeTagsFromPost'], 10, 3);

Hooks::filter(Config::withFreePrefix('wordpress_addNewImage'), [WordPressProHelper::class, 'addNewImage'], 10, 3);
Hooks::filter(Config::withFreePrefix('wordpress_deleteMedia'), [WordPressProHelper::class, 'deleteMedia'], 10, 3);
Hooks::filter(Config::withFreePrefix('wordpress_renameMedia'), [WordPressProHelper::class, 'renameMedia'], 10, 3);

Hooks::filter(Config::withFreePrefix('wordpress_registerTaxonomy'), [WordPressProHelper::class, 'registerTaxonomy'], 10, 3);
Hooks::filter(Config::withFreePrefix('wordpress_unregisterTaxonomy'), [WordPressProHelper::class, 'unregisterTaxonomy'], 10, 3);

Hooks::filter(Config::withFreePrefix('wordpress_createNewTerm'), [WordPressProHelper::class, 'createNewTerm'], 10, 3);
Hooks::filter(Config::withFreePrefix('wordpress_updateTerm'), [WordPressProHelper::class, 'updateTerm'], 10, 3);
Hooks::filter(Config::withFreePrefix('wordpress_termDelete'), [WordPressProHelper::class, 'termDelete'], 10, 3);

Hooks::filter(Config::withFreePrefix('wordpress_createCategory'), [WordPressProHelper::class, 'createCategory'], 10, 3);
Hooks::filter(Config::withFreePrefix('wordpress_updateCategory'), [WordPressProHelper::class, 'updateCategory'], 10, 3);
Hooks::filter(Config::withFreePrefix('wordpress_deleteCategory'), [WordPressProHelper::class, 'deleteCategory'], 10, 3);
Hooks::filter(Config::withFreePrefix('wordpress_addCategoryToPost'), [WordPressProHelper::class, 'addCategoryToPost'], 10, 3);

// === Product Tags (WooCommerce) ===
Hooks::filter(Config::withFreePrefix('wordpress_createProductTag'), [WordPressProHelper::class, 'createProductTag'], 10, 3);
Hooks::filter(Config::withFreePrefix('wordpress_updateProductTag'), [WordPressProHelper::class, 'updateProductTag'], 10, 3);
Hooks::filter(Config::withFreePrefix('wordpress_deleteProductTag'), [WordPressProHelper::class, 'deleteProductTag'], 10, 3);

// === Product Categories (WooCommerce) ===
Hooks::filter(Config::withFreePrefix('wordpress_createProductCategory'), [WordPressProHelper::class, 'createProductCategory'], 10, 3);
Hooks::filter(Config::withFreePrefix('wordpress_updateProductCategory'), [WordPressProHelper::class, 'updateProductCategory'], 10, 3);
Hooks::filter(Config::withFreePrefix('wordpress_deleteProductCategory'), [WordPressProHelper::class, 'deleteProductCategory'], 10, 3);

// === Product Types (WooCommerce) ===
Hooks::filter(Config::withFreePrefix('wordpress_createProductType'), [WordPressProHelper::class, 'createProductType'], 10, 3);
Hooks::filter(Config::withFreePrefix('wordpress_updateProductType'), [WordPressProHelper::class, 'updateProductType'], 10, 3);
Hooks::filter(Config::withFreePrefix('wordpress_deleteProductType'), [WordPressProHelper::class, 'deleteProductType'], 10, 3);

Hooks::filter(Config::withFreePrefix('wordpress_checkPluginActivationStatus'), [WordPressProHelper::class, 'checkPluginActivationStatus'], 10, 3);
Hooks::filter(Config::withFreePrefix('wordpress_activatePlugin'), [WordPressProHelper::class, 'activatePlugin'], 10, 3);
