<?php

namespace BitApps\IntegrationsPro\Actions\AsgarosForum;

use AsgarosForum;

class AsgarosForumProHelper
{
    public static function createTopic($defaultResponse, $payload)
    {
        $forum = self::getForumInstance();
        if (!$forum) {
            return self::errorResponse(__('Asgaros Forum is not installed or activated.', 'bit-integrations-pro'));
        }

        if (!isset($payload['forum_id']) || $payload['forum_id'] <= 0) {
            return self::errorResponse(__('Forum ID is required and must be a positive integer.', 'bit-integrations-pro'));
        }

        $topicName = self::getRequiredString($payload, 'topic_name', __('Topic name is required.', 'bit-integrations-pro'));
        if (\is_array($topicName)) {
            return $topicName;
        }

        $topicContent = self::getRequiredString($payload, 'topic_content', __('Topic content is required.', 'bit-integrations-pro'));
        if (\is_array($topicContent)) {
            return $topicContent;
        }

        if (empty($forum->content->get_forum($payload['forum_id']))) {
            return self::errorResponse(__('Selected forum is invalid.', 'bit-integrations-pro'));
        }

        $authorId = self::getOptionalId($payload, 'author_id', get_current_user_id());
        if ($authorId <= 0) {
            return self::errorResponse(__('No author ID provided and no user is logged in.', 'bit-integrations-pro'));
        }

        $createdTopic = $forum->content->insert_topic(
            $payload['forum_id'],
            $topicName,
            wp_kses_post($topicContent),
            $authorId
        );

        if (empty($createdTopic)) {
            return self::errorResponse(__('Failed to create topic.', 'bit-integrations-pro'));
        }

        return self::successResponse(
            __('Topic created successfully.', 'bit-integrations-pro'),
            [
                'topic'     => $createdTopic,
                'forum_id'  => $payload['forum_id'],
                'author_id' => $authorId,
            ]
        );
    }

    public static function createForum($defaultResponse, $payload)
    {
        $forum = self::getForumInstance();
        if (!$forum) {
            return self::errorResponse(__('Asgaros Forum is not installed or activated.', 'bit-integrations-pro'));
        }

        $forumName = self::getRequiredString($payload, 'forum_name', __('Forum name is required.', 'bit-integrations-pro'));
        if (\is_array($forumName)) {
            return $forumName;
        }

        if (isset($payload['parent_id']) && $forum->get_category_name(absint($payload['parent_id'])) === false) {
            return self::errorResponse(__('Selected parent forum is invalid.', 'bit-integrations-pro'));
        }

        $forumId = $forum->content->insert_forum(
            $payload['parent_id'] ?? 0,
            $forumName,
            sanitize_text_field((string) ($payload['forum_description'] ?? '')),
            0,
            sanitize_text_field((string) ($payload['forum_icon'] ?? '')),
            1,
            'normal'
        );

        if (!$forumId) {
            return self::errorResponse(__('Failed to create forum.', 'bit-integrations-pro'));
        }

        return self::successResponse(
            __('Forum created successfully.', 'bit-integrations-pro'),
            [
                'forum_id' => (int) $payload['forum_id'],
                'forum'    => $forum->content->get_forum($payload['forum_id']),
            ]
        );
    }

    public static function postReplyInTopic($defaultResponse, $payload)
    {
        $forum = self::getForumInstance();
        if (!$forum) {
            return self::errorResponse(__('Asgaros Forum is not installed or activated.', 'bit-integrations-pro'));
        }

        if (!isset($payload['topic_id']) || $payload['topic_id'] <= 0) {
            return self::errorResponse(__('Topic ID is required and must be a positive integer.', 'bit-integrations-pro'));
        }

        $replyContent = self::getRequiredString($payload, 'reply_content', __('Reply content is required.', 'bit-integrations-pro'));
        if (\is_array($replyContent)) {
            return $replyContent;
        }

        $authorId = self::getOptionalId($payload, 'author_id', get_current_user_id());
        if ($authorId <= 0) {
            return self::errorResponse(__('No author ID provided and no user is logged in.', 'bit-integrations-pro'));
        }

        $topic = $forum->content->get_topic($payload['topic_id']);
        if (empty($topic)) {
            return self::errorResponse(__('Topic not found.', 'bit-integrations-pro'));
        }

        if (!empty($topic->closed)) {
            return self::errorResponse(__('Cannot reply to a closed topic.', 'bit-integrations-pro'));
        }

        $postId = $forum->content->insert_post(
            $payload['topic_id'],
            (int) ($topic->parent_id ?? 0),
            wp_kses_post($replyContent),
            $authorId
        );

        if (!$postId) {
            return self::errorResponse(__('Failed to post reply.', 'bit-integrations-pro'));
        }

        return self::successResponse(
            __('Reply posted successfully.', 'bit-integrations-pro'),
            [
                'post_id'   => (int) $postId,
                'topic_id'  => $payload['topic_id'],
                'author_id' => $authorId,
            ]
        );
    }

    public static function subscribeUserInForum($defaultResponse, $payload)
    {
        $forum = self::getForumInstance();
        if (!$forum) {
            return self::errorResponse(__('Asgaros Forum is not installed or activated.', 'bit-integrations-pro'));
        }

        $userId = $payload['user_id'] ?? 0;
        $forumId = $payload['forum_id'] ?? 0;
        if (!isset($userId) || $userId <= 0) {
            return self::errorResponse(__('User ID is required and must be a positive integer.', 'bit-integrations-pro'));
        }

        if (!isset($forumId) || $forumId <= 0) {
            return self::errorResponse(__('Forum ID is required and must be a positive integer.', 'bit-integrations-pro'));
        }

        if (!get_user_by('ID', $userId)) {
            return self::errorResponse(__('Selected user is invalid.', 'bit-integrations-pro'));
        }

        if (empty($forum->content->get_forum($forumId))) {
            return self::errorResponse(__('Selected forum is invalid.', 'bit-integrations-pro'));
        }

        $status = get_user_meta(get_current_user_id(), 'asgarosforum_subscription_forum');

        if ($status && \in_array($forumId, $status)) {
            return self::errorResponse(__('User is already subscribed to this forum.', 'bit-integrations-pro'));
        }

        add_user_meta($userId, 'asgarosforum_subscription_forum', $forumId);

        return self::successResponse(
            __('User subscribed to forum successfully.', 'bit-integrations-pro'),
            [
                'user_id'    => $userId,
                'forum_id'   => $forumId,
                'subscribed' => true,
            ]
        );
    }

    private static function getForumInstance()
    {
        global $asgarosforum;

        if (isset($asgarosforum) && \is_object($asgarosforum)) {
            return $asgarosforum;
        }

        if (class_exists('AsgarosForum')) {
            return new AsgarosForum();
        }
    }

    private static function getOptionalId($payload, $key, $default = 0)
    {
        if (!isset($payload[$key]) || $payload[$key] === '') {
            return absint($default);
        }

        return absint($payload[$key]);
    }

    private static function getRequiredString($payload, $key, $message)
    {
        $value = trim((string) ($payload[$key] ?? ''));
        if ($value === '') {
            return self::errorResponse($message);
        }

        return $value;
    }

    private static function successResponse($message, $data = [])
    {
        return [
            'success' => true,
            'message' => $message,
            'data'    => $data,
        ];
    }

    private static function errorResponse($message, $data = [])
    {
        return [
            'success' => false,
            'message' => $message,
            'data'    => $data,
        ];
    }
}
