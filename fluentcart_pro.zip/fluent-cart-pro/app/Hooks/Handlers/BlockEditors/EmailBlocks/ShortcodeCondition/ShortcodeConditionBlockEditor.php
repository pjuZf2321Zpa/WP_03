<?php

namespace FluentCartPro\App\Hooks\Handlers\BlockEditors\EmailBlocks\ShortcodeCondition;

use FluentCart\App\Hooks\Handlers\BlockEditors\BlockEditor;

class ShortcodeConditionBlockEditor extends BlockEditor
{
    use \FluentCartPro\App\Contracts\CanEnqueue;
    protected static string $editorName = 'shortcode-condition';

    public function getScripts(): array
    {
        return [
            [
                'source'       => 'admin/BlockEditor/EmailBlocks/ShortcodeCondition/ShortcodeConditionBlockEditor.jsx',
                'dependencies' => ['wp-blocks', 'wp-components', 'wp-block-editor']
            ]
        ];
    }

    public function getStyles(): array
    {
        return [
            'admin/BlockEditor/EmailBlocks/ShortcodeCondition/style/shortcode-condition-block-editor.scss'
        ];
    }

    public function localizeData(): array
    {
        return [
            $this->getLocalizationKey() => [
                'slug'        => $this->slugPrefix,
                'name'        => static::getEditorName(),
                'title'       => __('Conditional Block', 'fluent-cart-pro'),
                'description' => __('Show or hide content based on whether a shortcode resolves to a value.', 'fluent-cart-pro'),
            ],
            'fluent_cart_pro_block_translation' => \FluentCartPro\App\Services\Translations\Translations::blockStrings(),
        ];
    }

    public function blockAttributes(): array
    {
        return [
            'preset' => [
                'type'    => 'string',
                'default' => '',
            ],
            'shortcode' => [
                'type'    => 'string',
                'default' => '',
            ],
            'condition' => [
                'type'    => 'string',
                'default' => 'not_empty',
            ],
            'compareValue' => [
                'type'    => 'string',
                'default' => '',
            ],
        ];
    }

    public function supports(): array
    {
        return [
            'html'  => false,
            'align' => false,
        ];
    }

    public function render(array $attrs, $block = null, $content = ''): string
    {
        return $content;
    }
}
