<?php

namespace FluentCartPro\App\Modules\SavedPaymentMethods;

use FluentCart\Api\StoreSettings;
use FluentCart\App\Modules\PaymentMethods\StripeGateway\StripeSettingsBase;
use FluentCart\App\Services\TemplateService;
use FluentCart\Framework\Support\Arr;
use FluentCart\Framework\Support\Str;
use FluentCartPro\App\Utils\Enqueuer\Vite;

/**
 * Registers Saved Payment Methods as a section of the customer-portal Profile
 * page, via core's `fluent_cart/customer_portal/profile_sections` filter.
 *
 * Replaces the standalone "Payment Methods" dashboard endpoint this module used
 * to register. That endpoint was server-rendered PHP markup driven by a vanilla
 * JS widget, because core's portal SPA has a static route table an add-on
 * cannot extend. The section filter is the way in: this class hands core the
 * UNCOMPILED `VueTemplates/PaymentMethodsSection.vue` as a string plus its
 * payload, and core compiles it in the browser. Dropping the endpoint also
 * removes the menu tab, since that tab was a side effect of registering it.
 */
class ProfileSection
{
    const KEY = 'saved_payment_methods';

    /**
     * The dashboard endpoint slug this feature used to own. Kept only so links
     * already in the wild (emails, bookmarks) land somewhere useful.
     */
    const LEGACY_SLUG = 'payment-methods';

    public function register(): void
    {
        add_action('template_redirect', [$this, 'redirectLegacyEndpoint']);

        // The section template uses fct-* components; an older FluentCart shows no section until it is updated.
        if (!\FluentCartPro\App\Services\CoreCompat::hasFctComponents()) {
            return;
        }

        add_filter('fluent_cart/customer_portal/profile_sections', [$this, 'addSection'], 10, 2);
        add_filter('fluent_cart/customer_profile_translations', [$this, 'addTranslations']);
        add_action('fluent_cart/customer_dashboard/enqueue_assets', [$this, 'enqueueAssets']);
    }

    /**
     * The section's own JS and CSS.
     *
     * Both belong here rather than in core: the component string is compiled in
     * the browser, so core's build never sees it — a `<style>` block inside it
     * is ignored and its markup is invisible to core's Tailwind scan. The
     * script registers the Stripe Elements capability the section needs, since
     * the runtime parser shadows the browser globals it would otherwise use.
     *
     * `fluent_cart/customer_dashboard/enqueue_assets` fires only from
     * AssetLoader::loadCustomerDashboardAssets(), i.e. while the dashboard app
     * is actually rendering — no URL gate needed here. The previous
     * isDashboardPage() check compared the page's pretty slug against
     * $wp->request, which under plain permalinks is "?page_id=N" vs a path —
     * never equal, so the assets were never enqueued at all.
     */
    public function enqueueAssets(): void
    {
        // Styles load unconditionally: the section renders (and can list saved
        // PayPal methods) even when Stripe is not configured.
        Vite::enqueueStyle(
            'fct-saved-payment-methods',
            'public/customer-profile/saved-payment-methods.scss'
        );

        // Stripe.js and the Elements facade only exist to power the add-card
        // form, which isConfigured() disables without a publishable key — so a
        // store without Stripe skips both scripts entirely.
        if (!(new StripeSettingsBase())->getPublicKey()) {
            return;
        }

        // WordPress owns the Stripe.js tag: registered under the same handle
        // this module used before, so it dedupes against any other enqueue of
        // it, and declared as a dependency below so it has executed before the
        // facade runs. Nothing on the JS side loads a script.
        wp_enqueue_script('stripe-js', 'https://js.stripe.com/v3/', [], null, true);

        // Footer, matching the dependency: a head-group script would make
        // WordPress hoist Stripe.js into <head> to satisfy it, turning a
        // third-party request into a render-blocking one.
        Vite::enqueueScript(
            'fct-saved-payment-methods',
            'public/customer-profile/stripe-elements.js',
            ['stripe-js'],
            null,
            true
        );
    }

    /**
     * @param array $sections
     * @param array $args ['customer' => Customer|null]
     * @return array
     */
    public function addSection($sections, $args = [])
    {
        $customer = Arr::get($args, 'customer');

        if (!$customer) {
            return $sections;
        }

        $template = $this->template();

        if (!$template) {
            return $sections;
        }

        $sections[] = [
            'key'       => self::KEY,
            'type'      => 'vue-template',
            'component' => $template,
            'payload'   => [
                'cards'      => (new SavedPaymentMethodRepository())->list($customer),
                // Relative on purpose: the portal calls this through core's
                // Rest helper, which prefixes the REST namespace itself.
                'rest_base'  => 'saved-payment-methods',
                'stripe_key' => (new StripeSettingsBase())->getPublicKey(),
            ],
        ];

        return $sections;
    }

    /**
     * The section is compiled in the browser, so its strings cannot go through
     * the usual JS build-time extraction — they resolve against the portal's
     * translation map instead, which this filter contributes to.
     *
     * @param array $translations
     * @return array
     */
    public function addTranslations($translations)
    {
        if (!is_array($translations)) {
            return $translations;
        }

        return array_merge($translations, [
            'Payment Methods'                     => __('Payment Methods', 'fluent-cart-pro'),
            'Your card details are never stored on this site. Your payment provider keeps them and gives us a secure token, which is only charged when you place an order or a subscription renews.'
                                                  => __('Your card details are never stored on this site. Your payment provider keeps them and gives us a secure token, which is only charged when you place an order or a subscription renews.', 'fluent-cart-pro'),
            'Add payment method'                  => __('Add payment method', 'fluent-cart-pro'),
            'No saved cards yet'                  => __('No saved cards yet', 'fluent-cart-pro'),
            'Add a card for one-tap checkout on your next purchase.'
                                                  => __('Add a card for one-tap checkout on your next purchase.', 'fluent-cart-pro'),
            'On a subscription'                   => __('On a subscription', 'fluent-cart-pro'),
            'In use by a subscription'            => __('In use by a subscription', 'fluent-cart-pro'),
            'Set as default'                      => __('Set as default', 'fluent-cart-pro'),
            'Remove'                              => __('Remove', 'fluent-cart-pro'),
            // The section is compiled in the browser, so an unmapped string stays
            // English in every locale. Cancel and Default were both missing —
            // Default is the badge on the customer's default card.
            'Cancel'                              => __('Cancel', 'fluent-cart-pro'),
            'Default'                             => __('Default', 'fluent-cart-pro'),
            'Remove card'                         => __('Remove card', 'fluent-cart-pro'),
            'Remove this saved payment method? Once removed, it cannot be used for future payments in this store.'
                                                  => __('Remove this saved payment method? Once removed, it cannot be used for future payments in this store.', 'fluent-cart-pro'),
            'Add a payment method'                => __('Add a payment method', 'fluent-cart-pro'),
            'Cardholder name'                     => __('Cardholder name', 'fluent-cart-pro'),
            'Card number'                         => __('Card number', 'fluent-cart-pro'),
            'Expiry'                              => __('Expiry', 'fluent-cart-pro'),
            'CVC'                                 => __('CVC', 'fluent-cart-pro'),
            'Set as default payment method'       => __('Set as default payment method', 'fluent-cart-pro'),
            'Add card'                            => __('Add card', 'fluent-cart-pro'),
            'Card'                                => __('Card', 'fluent-cart-pro'),
            'PayPal account'                      => __('PayPal account', 'fluent-cart-pro'),
            'Card saved'                          => __('Card saved', 'fluent-cart-pro'),
            'Card removed'                        => __('Card removed', 'fluent-cart-pro'),
            'Default payment method updated'      => __('Default payment method updated', 'fluent-cart-pro'),
            'Something went wrong. Please try again.'
                                                  => __('Something went wrong. Please try again.', 'fluent-cart-pro'),
            /* translators: %1$s: card brand (e.g. Visa), %2$s: last 4 digits */
            '%1$s ending %2$s'                    => __('%1$s ending %2$s', 'fluent-cart-pro'),
            /* translators: %1$s: card expiry in MM/YYYY format */
            'Expires %1$s'                        => __('Expires %1$s', 'fluent-cart-pro'),
            /* translators: %1$s: number of remaining card verification attempts */
            '%1$s verification attempts left today.'
                                                  => __('%1$s verification attempts left today.', 'fluent-cart-pro'),
        ]);
    }

    /**
     * Send the retired `/payment-methods` portal URL to the Profile page that
     * now hosts the section. Without this the path falls through to the SPA,
     * whose router has no matching route and renders nothing.
     */
    public function redirectLegacyEndpoint(): void
    {
        if (is_admin() || wp_doing_ajax() || !is_user_logged_in()) {
            return;
        }

        if ($this->requestedEndpoint() !== self::LEGACY_SLUG) {
            return;
        }

        // 302, not 301: a permanently cached redirect would survive any later
        // decision to give this feature its own page again.
        wp_safe_redirect(TemplateService::getCustomerProfileUrl('profile'), 302);
        exit;
    }

    /**
     * First path segment below the customer dashboard page, or '' when the
     * current request is not a dashboard sub-page.
     */
    private function requestedEndpoint(): string
    {
        global $wp;

        $requestedPath = isset($wp->request) ? $wp->request : '';
        $dashboardSlug = (new StoreSettings())->getCustomerDashboardPageSlug();

        if (!$requestedPath || !$dashboardSlug || !Str::startsWith($requestedPath, $dashboardSlug)) {
            return '';
        }

        $requestedPath = trim(Str::replaceFirst($dashboardSlug, '', $requestedPath), '/');

        if (!$requestedPath) {
            return '';
        }

        $segments = explode('/', $requestedPath);

        return (string)array_shift($segments);
    }

    /**
     * @return string the raw contents of the section's .vue file
     */
    private function template(): string
    {
        $templatePath = FLUENTCART_PRO_PLUGIN_DIR . 'app/Modules/SavedPaymentMethods/VueTemplates/PaymentMethodsSection.vue';

        if (!file_exists($templatePath)) {
            return '';
        }

        $template = file_get_contents($templatePath);

        return $template ? $template : '';
    }
}
