<?php

/**
 * Brilliant Directories Record Api.
 */

namespace BitApps\IntegrationsPro\Actions\BrilliantDirectories;

/**
 * Every Brilliant Directories action runs here — the free plugin only fires the hook.
 */
class BrilliantDirectoriesHelperPro
{
    /**
     * No BD write endpoint accepts an email as a selector — `user/update` even treats
     * `email` as a value to write rather than a member to find, so a mapped email is
     * resolved into the real id first.
     *
     * [idKey, lookupKey, listPath, filterColumn, label]
     */
    private const IDENTIFIER_LOOKUPS = [
        'lead'   => ['lead_id', 'lookup_lead_email', 'leads/get', 'lead_email', 'Lead Email'],
        'member' => ['user_id', 'lookup_email', 'user/get', 'email', 'Member Email'],
    ];

    public static function createMember($response, $fieldData, $apiClient, $settings)
    {
        return self::dispatch($apiClient, 'POST', 'user/create', array_merge(
            $fieldData,
            [
                'profession_id'   => $settings['profession_id'] ?? '',
                'subscription_id' => $settings['subscription_id'] ?? '',
            ]
        ), __('Member created successfully', 'bit-integrations-pro'));
    }

    public static function updateMember($response, $fieldData, $apiClient, $settings)
    {
        $resolved = self::resolveIdentifier($fieldData, $apiClient, 'member');
        if (isset($resolved['error'])) {
            return $resolved['error'];
        }

        return self::dispatch($apiClient, 'PUT', 'user/update', $resolved['data'], __('Member updated successfully', 'bit-integrations-pro'));
    }

    public static function deleteMember($response, $fieldData, $apiClient, $settings)
    {
        $resolved = self::resolveIdentifier($fieldData, $apiClient, 'member');
        if (isset($resolved['error'])) {
            return $resolved['error'];
        }

        return self::dispatch($apiClient, 'DELETE', 'user/delete', ['user_id' => $resolved['data']['user_id']], __('Member deleted successfully', 'bit-integrations-pro'));
    }

    public static function createLead($response, $fieldData, $apiClient, $settings)
    {
        return self::dispatch($apiClient, 'POST', 'leads/create', array_merge(
            $fieldData,
            ['top_id' => $settings['top_category_id'] ?? '']
        ), __('Lead created successfully', 'bit-integrations-pro'));
    }

    public static function updateLead($response, $fieldData, $apiClient, $settings)
    {
        $resolved = self::resolveIdentifier($fieldData, $apiClient, 'lead');
        if (isset($resolved['error'])) {
            return $resolved['error'];
        }

        return self::dispatch($apiClient, 'PUT', 'leads/update', $resolved['data'], __('Lead updated successfully', 'bit-integrations-pro'));
    }

    public static function matchLead($response, $fieldData, $apiClient, $settings)
    {
        $resolved = self::resolveIdentifier($fieldData, $apiClient, 'lead');
        if (isset($resolved['error'])) {
            return $resolved['error'];
        }

        return self::dispatch($apiClient, 'POST', 'leads/match', ['lead_id' => $resolved['data']['lead_id']], __('Lead matched successfully', 'bit-integrations-pro'));
    }

    public static function deleteLead($response, $fieldData, $apiClient, $settings)
    {
        $resolved = self::resolveIdentifier($fieldData, $apiClient, 'lead');
        if (isset($resolved['error'])) {
            return $resolved['error'];
        }

        return self::dispatch($apiClient, 'DELETE', 'leads/delete', ['lead_id' => $resolved['data']['lead_id']], __('Lead deleted successfully', 'bit-integrations-pro'));
    }

    public static function createMemberPost($response, $fieldData, $apiClient, $settings)
    {
        $resolved = self::resolveIdentifier($fieldData, $apiClient, 'member');
        if (isset($resolved['error'])) {
            return $resolved['error'];
        }

        [$dataId, $dataType] = array_pad(explode(':', (string) ($settings['post_type_id'] ?? '')), 2, '');

        if ($dataId === '' || $dataType === '') {
            return self::error(__('Select a Post Type for this action', 'bit-integrations-pro'));
        }

        return self::dispatch($apiClient, 'POST', 'data_posts/create', array_merge(
            $resolved['data'],
            [
                'data_id'   => $dataId,
                'data_type' => $dataType,
            ]
        ), __('Post created successfully', 'bit-integrations-pro'));
    }

    public static function createReview($response, $fieldData, $apiClient, $settings)
    {
        $resolved = self::resolveIdentifier($fieldData, $apiClient, 'member');
        if (isset($resolved['error'])) {
            return $resolved['error'];
        }

        return self::dispatch($apiClient, 'POST', 'users_reviews/create', array_merge(
            $resolved['data'],
            self::reviewStatus($settings)
        ), __('Review created successfully', 'bit-integrations-pro'));
    }

    public static function updateReview($response, $fieldData, $apiClient, $settings)
    {
        return self::dispatch($apiClient, 'PUT', 'users_reviews/update', array_merge(
            $fieldData,
            self::reviewStatus($settings)
        ), __('Review updated successfully', 'bit-integrations-pro'));
    }

    public static function deleteReview($response, $fieldData, $apiClient, $settings)
    {
        if (empty($fieldData['review_id'])) {
            return self::error(__('Review ID is required', 'bit-integrations-pro'));
        }

        return self::dispatch($apiClient, 'DELETE', 'users_reviews/delete', ['review_id' => $fieldData['review_id']], __('Review deleted successfully', 'bit-integrations-pro'));
    }

    private static function resolveIdentifier(array $data, $apiClient, $recordType)
    {
        [$idKey, $lookupKey, $path, $column, $emailLabel] = self::IDENTIFIER_LOOKUPS[$recordType];

        $lookupEmail = $data[$lookupKey] ?? '';
        unset($data[$lookupKey]);

        if (empty($lookupEmail)) {
            // translators: %s is the email field label.
            return ['error' => self::error(wp_sprintf(__('%s is required', 'bit-integrations-pro'), $emailLabel))];
        }

        $lookup = $apiClient->get($path, [
            'limit'          => 1,
            'property'       => $column,
            'property_value' => $lookupEmail,
        ]);

        if (self::failureReason($lookup) !== null) {
            return ['error' => self::error(self::failureReason($lookup), 400)];
        }

        // Rows live in `message` on every list endpoint, never in `data`.
        $rows = $lookup->getBodyValue('message');
        $resolvedId = \is_array($rows) && isset($rows[0]) ? $lookup::getValue($rows[0], $idKey) : null;

        if (empty($resolvedId)) {
            return ['error' => self::error(
                // translators: 1: email field label, 2: the email address searched for.
                wp_sprintf(__('No Brilliant Directories record found for %1$s %2$s', 'bit-integrations-pro'), $emailLabel, $lookupEmail),
                404
            )];
        }

        $data[$idKey] = $resolvedId;

        return ['data' => $data];
    }

    private static function dispatch($apiClient, $method, $path, array $payload, $successMessage)
    {
        // BD reads an empty value as "blank this column", so unmapped fields go.
        $payload = array_filter(
            $payload,
            static function ($value) {
                return $value !== null && $value !== '';
            }
        );

        $response = $apiClient->request($method, $path, $payload);
        $failure = self::failureReason($response);

        if ($failure !== null) {
            return self::error($failure, $apiClient->getResponseCode() ?: 400);
        }

        return [
            'success'  => true,
            'message'  => $successMessage,
            'code'     => $response->getStatus(),
            'response' => $response->getBody(),
        ];
    }

    /**
     * BD answers HTTP 200 with `{"status":"error"}` on validation failures, so a 2xx
     * alone does not mean the call did anything. Null when the response is good.
     *
     * @param mixed $response
     */
    private static function failureReason($response): ?string
    {
        if (!$response->success()) {
            // ApiClient leaves the error null on a non-2xx, so the reason BD sent in the
            // body is the only one there is.
            return $response->getError()
                ?: self::bodyMessage($response)
                ?: __('Could not reach Brilliant Directories', 'bit-integrations-pro');
        }

        if ($response->getBodyValue('status') !== 'error') {
            return null;
        }

        return self::bodyMessage($response) ?: __('Brilliant Directories rejected the request', 'bit-integrations-pro');
    }

    /**
     * `message` carries the rows on a good list call and the reason on a bad one, so
     * only a string is a reason.
     *
     * @param mixed $response
     */
    private static function bodyMessage($response): ?string
    {
        $message = $response->getBodyValue('message');

        return \is_string($message) && $message !== '' ? $message : null;
    }

    private static function reviewStatus($settings)
    {
        $status = $settings['selected_review_status'] ?? '';

        return $status === '' ? [] : ['review_status' => $status];
    }

    private static function error($message, $code = 400)
    {
        return ['success' => false, 'message' => $message, 'code' => $code];
    }
}
