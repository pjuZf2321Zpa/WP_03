<?php

namespace BitApps\IntegrationsPro\Actions\Wsms;

if (!\defined('ABSPATH')) {
    exit;
}

class WsmsProHelper
{
    /**
     * Send an SMS (or MMS) through the active WSMS gateway.
     *
     * Field-map: to, message, sender_id, is_flash, media_urls.
     *
     * @param mixed $defaultResponse
     * @param array $fieldData
     * @param mixed $utilities
     * @param mixed $integrationDetails
     *
     * @return array
     */
    public static function sendSms($defaultResponse, $fieldData)
    {
        if (!\function_exists('wp_sms_send')) {
            return self::errorResponse(__('Required WSMS function is missing.', 'bit-integrations-pro'));
        }

        $to = isset($fieldData['to']) ? $fieldData['to'] : '';
        $message = isset($fieldData['message']) ? $fieldData['message'] : '';

        if (empty($to) || $message === '' || $message === null) {
            return self::errorResponse(__('Recipient number and message are required.', 'bit-integrations-pro'));
        }

        $recipients = self::splitList($to);

        if (empty($recipients)) {
            return self::errorResponse(__('At least one valid recipient number is required.', 'bit-integrations-pro'));
        }

        $isFlash = self::toBool($fieldData['is_flash'] ?? false);
        $from = !empty($fieldData['sender_id']) ? $fieldData['sender_id'] : null;
        $mediaUrls = [];

        if (!empty($fieldData['media_urls'])) {
            $mediaUrls = array_values(array_filter(array_map('esc_url_raw', self::splitList($fieldData['media_urls']))));
        }

        $response = wp_sms_send(
            $recipients,
            $message,
            $isFlash,
            $from,
            $mediaUrls
        );

        if (is_wp_error($response)) {
            return self::errorResponse($response->get_error_message());
        }

        // Not every gateway returns a WP_Error on failure — some return false or
        // an empty payload. Treat a falsy/empty response as a failed send.
        if ($response === false || $response === null) {
            return self::errorResponse(__('The SMS gateway did not confirm delivery.', 'bit-integrations-pro'));
        }

        return self::successResponse(__('SMS sent successfully.', 'bit-integrations-pro'), ['response' => self::extractObjectAttributes($response)]);
    }

    /**
     * Add a newsletter subscriber.
     *
     * Field-map: name, mobile. Dropdown ids from $integrationDetails: groupId, status.
     *
     * @param mixed $defaultResponse
     * @param array $fieldData
     * @param mixed $utilities
     * @param mixed $integrationDetails
     *
     * @return array
     */
    public static function addSubscriber($defaultResponse, $fieldData, $integrationDetails = null)
    {
        if (!self::isNewsletterAvailable()) {
            return self::errorResponse(__('Required WSMS Newsletter class is missing.', 'bit-integrations-pro'));
        }

        $name = isset($fieldData['name']) ? $fieldData['name'] : '';
        $mobile = isset($fieldData['mobile']) ? $fieldData['mobile'] : '';

        if (empty($name) || empty($mobile)) {
            return self::errorResponse(__('Name and mobile are required.', 'bit-integrations-pro'));
        }

        $groupId = self::resolveGroupId($integrationDetails);
        $status = self::resolveStatus($integrationDetails);

        $result = \WP_SMS\Newsletter::addSubscriber($name, $mobile, $groupId, $status);

        return self::normalizePluginResult($result, __('Failed to add subscriber.', 'bit-integrations-pro'));
    }

    /**
     * Update an existing newsletter subscriber, identified by mobile number.
     *
     * Field-map: mobile (identifier), name. Optional dropdown ids from
     * $integrationDetails: groupId, status (preserved when unset).
     *
     * @param mixed $defaultResponse
     * @param array $fieldData
     * @param mixed $utilities
     * @param mixed $integrationDetails
     *
     * @return array
     */
    public static function updateSubscriber($defaultResponse, $fieldData, $integrationDetails = null)
    {
        if (!self::isNewsletterAvailable()) {
            return self::errorResponse(__('Required WSMS Newsletter class is missing.', 'bit-integrations-pro'));
        }

        $name = isset($fieldData['name']) ? $fieldData['name'] : '';
        $mobile = isset($fieldData['mobile']) ? $fieldData['mobile'] : '';

        if (empty($name) || empty($mobile)) {
            return self::errorResponse(__('Name and mobile are required.', 'bit-integrations-pro'));
        }

        // Identify the subscriber by mobile number (field-map), like delete subscriber.
        $existing = \WP_SMS\Newsletter::getSubscriberByMobile($mobile, true);

        if (!$existing) {
            return self::errorResponse(__('Subscriber not found for the given mobile number.', 'bit-integrations-pro'));
        }

        $subscriberId = (int) $existing->ID;

        // Preserve the subscriber's current group/status when those optional
        // dropdowns are left unset — otherwise the plugin overwrites them
        // (blanking the group, forcing the status to Active).
        $groupId = is_object($integrationDetails) && isset($integrationDetails->groupId) && $integrationDetails->groupId !== '' && $integrationDetails->groupId !== null
            ? (int) $integrationDetails->groupId
            : ($existing->group_ID ?? '');

        $status = is_object($integrationDetails) && isset($integrationDetails->status) && $integrationDetails->status !== '' && $integrationDetails->status !== null
            ? $integrationDetails->status
            : ($existing->status ?? '1');

        // The plugin returns a no-op error ('No change has been occurred.') when
        // nothing actually changes; detect that up front so it reports success
        // (mobile is the identifier, so it is unchanged by definition).
        if ((string) ($existing->name ?? '') === (string) $name
            && (string) ($existing->group_ID ?? '') === (string) $groupId
            && (string) ($existing->status ?? '') === (string) $status) {
            return self::successResponse(
                __('No change — the subscriber is already up to date.', 'bit-integrations-pro'),
                ['subscriber_id' => $subscriberId, 'changed' => false]
            );
        }

        $result = \WP_SMS\Newsletter::updateSubscriber(
            $subscriberId,
            $name,
            $mobile,
            $groupId,
            $status
        );

        return self::normalizePluginResult($result, __('Failed to update subscriber.', 'bit-integrations-pro'));
    }

    /**
     * Delete a subscriber by mobile number.
     *
     * Field-map: mobile. Optional dropdown id from $integrationDetails: groupId.
     *
     * @param mixed $defaultResponse
     * @param array $fieldData
     * @param mixed $utilities
     * @param mixed $integrationDetails
     *
     * @return array
     */
    public static function deleteSubscriber($defaultResponse, $fieldData, $integrationDetails = null)
    {
        if (!self::isNewsletterAvailable()) {
            return self::errorResponse(__('Required WSMS Newsletter class is missing.', 'bit-integrations-pro'));
        }

        $mobile = isset($fieldData['mobile']) ? $fieldData['mobile'] : '';

        if (empty($mobile)) {
            return self::errorResponse(__('Mobile is required.', 'bit-integrations-pro'));
        }

        // Subscribers are stored E.164-normalized; deleteSubscriberByNumber matches
        // the mobile exactly, so normalize first or the delete would never match.
        $mobile = self::normalizeMobile($mobile);

        // deleteSubscriberByNumber() routes the group id through processGroupId(),
        // which json_decode()s it and requires an array — a plain int yields a
        // WP_Error. Pass the JSON-array shape the plugin expects.
        $groupId = is_object($integrationDetails) && !empty($integrationDetails->groupId)
            ? wp_json_encode([(int) $integrationDetails->groupId])
            : null;

        $result = \WP_SMS\Newsletter::deleteSubscriberByNumber($mobile, $groupId);

        return self::normalizePluginResult($result, __('Failed to delete subscriber.', 'bit-integrations-pro'));
    }

    /**
     * Add a subscriber group.
     *
     * Field-map: name.
     *
     * @param mixed $defaultResponse
     * @param array $fieldData
     * @param mixed $utilities
     * @param mixed $integrationDetails
     *
     * @return array
     */
    public static function addGroup($defaultResponse, $fieldData)
    {
        if (!self::isNewsletterAvailable()) {
            return self::errorResponse(__('Required WSMS Newsletter class is missing.', 'bit-integrations-pro'));
        }

        $name = isset($fieldData['name']) ? $fieldData['name'] : '';

        if (empty($name)) {
            return self::errorResponse(__('Group name is required.', 'bit-integrations-pro'));
        }

        $result = \WP_SMS\Newsletter::addGroup($name);

        return self::normalizePluginResult($result, __('Failed to add group.', 'bit-integrations-pro'));
    }

    /**
     * Update a subscriber group.
     *
     * Field-map: group_id (identifier), name.
     *
     * @param mixed $defaultResponse
     * @param array $fieldData
     * @param mixed $utilities
     * @param mixed $integrationDetails
     *
     * @return array
     */
    public static function updateGroup($defaultResponse, $fieldData)
    {
        if (!self::isNewsletterAvailable()) {
            return self::errorResponse(__('Required WSMS Newsletter class is missing.', 'bit-integrations-pro'));
        }

        $groupId = isset($fieldData['group_id']) ? (int) $fieldData['group_id'] : 0;
        $name = isset($fieldData['name']) ? $fieldData['name'] : '';

        if (empty($groupId)) {
            return self::errorResponse(__('Group ID is required.', 'bit-integrations-pro'));
        }

        if (empty($name)) {
            return self::errorResponse(__('Group name is required.', 'bit-integrations-pro'));
        }

        // The plugin's updateGroup returns a "name exists" error on a no-op rename
        // (0 rows changed). Detect "name already set" up front and report success.
        $existing = \WP_SMS\Newsletter::getGroup($groupId);

        if (!$existing) {
            return self::errorResponse(__('Group not found.', 'bit-integrations-pro'));
        }

        if (isset($existing->name) && (string) $existing->name === (string) $name) {
            return self::successResponse(
                __('No change — the group name is already set.', 'bit-integrations-pro'),
                ['group_id' => $groupId, 'changed' => false]
            );
        }

        $result = \WP_SMS\Newsletter::updateGroup($groupId, $name);

        return self::normalizePluginResult($result, __('Failed to update group.', 'bit-integrations-pro'));
    }

    /**
     * Delete a subscriber group.
     *
     * Field-map: group_id (identifier).
     *
     * @param mixed $defaultResponse
     * @param array $fieldData
     * @param mixed $utilities
     * @param mixed $integrationDetails
     *
     * @return array
     */
    public static function deleteGroup($defaultResponse, $fieldData)
    {
        if (!self::isNewsletterAvailable()) {
            return self::errorResponse(__('Required WSMS Newsletter class is missing.', 'bit-integrations-pro'));
        }

        $groupId = isset($fieldData['group_id']) ? (int) $fieldData['group_id'] : 0;

        if (empty($groupId)) {
            return self::errorResponse(__('Group ID is required.', 'bit-integrations-pro'));
        }

        $result = \WP_SMS\Newsletter::deleteGroup($groupId);

        if (empty($result)) {
            return self::errorResponse(__('Failed to delete group, or the group does not exist.', 'bit-integrations-pro'));
        }

        return self::successResponse(__('Group deleted successfully.', 'bit-integrations-pro'), ['group_id' => $groupId]);
    }

    private static function isNewsletterAvailable()
    {
        return \defined('WP_SMS_VERSION') && class_exists('\WP_SMS\Newsletter');
    }

    /**
     * WSMS Newsletter methods return ['result' => 'success'|'error', 'message' => ...].
     *
     * @param mixed  $result
     * @param string $fallbackMessage
     *
     * @return array
     */
    private static function normalizePluginResult($result, $fallbackMessage)
    {
        if (\is_array($result) && 'success' === ($result['result'] ?? '')) {
            $message = !empty($result['message']) ? $result['message'] : __('Action completed successfully.', 'bit-integrations-pro');

            return self::successResponse($message, ['result' => $result]);
        }

        $message = \is_array($result) && !empty($result['message']) ? $result['message'] : $fallbackMessage;

        return self::errorResponse($message);
    }

    private static function resolveGroupId($integrationDetails)
    {
        return is_object($integrationDetails) && !empty($integrationDetails->groupId) ? (int) $integrationDetails->groupId : '';
    }

    private static function resolveStatus($integrationDetails)
    {
        return is_object($integrationDetails) && isset($integrationDetails->status) && $integrationDetails->status !== '' && $integrationDetails->status !== null
            ? $integrationDetails->status
            : '1';
    }

    private static function toBool($value)
    {
        return \in_array($value, ['1', 1, true, 'true', 'yes'], true);
    }

    private static function normalizeMobile($mobile)
    {
        if (class_exists('\WP_SMS\Helper') && method_exists('\WP_SMS\Helper', 'normalizeToE164')) {
            return \WP_SMS\Helper::normalizeToE164($mobile);
        }

        return $mobile;
    }

    /**
     * Split a comma / newline separated string into trimmed values. Splits only
     * on commas and line breaks — NOT on internal whitespace — so a single number
     * formatted with spaces (e.g. "+1 555 123 4567") stays one recipient.
     *
     * @param mixed $value
     *
     * @return array
     */
    private static function splitList($value)
    {
        if (\is_array($value)) {
            return array_values(array_filter(array_map('trim', $value)));
        }

        $parts = preg_split('/[,\r\n]+/', (string) $value);

        return array_values(array_filter(array_map('trim', $parts ?: [])));
    }

    private static function extractObjectAttributes($object)
    {
        if (!\is_object($object)) {
            return $object;
        }

        if (method_exists($object, 'getAttributes')) {
            return $object->getAttributes();
        }

        if (method_exists($object, 'toArray')) {
            return $object->toArray();
        }

        return get_object_vars($object);
    }

    private static function successResponse($message, $data = [])
    {
        return [
            'success' => true,
            'message' => $message,
            'data'    => $data
        ];
    }

    private static function errorResponse($message)
    {
        return [
            'success' => false,
            'message' => $message
        ];
    }
}
