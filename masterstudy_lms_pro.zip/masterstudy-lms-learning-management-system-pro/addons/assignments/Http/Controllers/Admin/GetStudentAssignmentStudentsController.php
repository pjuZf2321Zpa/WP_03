<?php

namespace MasterStudy\Lms\Pro\addons\assignments\Http\Controllers\Admin;

use MasterStudy\Lms\Http\WpResponseFactory;
use MasterStudy\Lms\Pro\addons\assignments\Repositories\AssignmentStudentAdminRepository;
use WP_REST_Response;

final class GetStudentAssignmentStudentsController {
	public function __invoke(): WP_REST_Response {
		return WpResponseFactory::ok_with_data(
			array(
				'items' => ( new AssignmentStudentAdminRepository() )->get_student_options(),
			)
		);
	}
}
