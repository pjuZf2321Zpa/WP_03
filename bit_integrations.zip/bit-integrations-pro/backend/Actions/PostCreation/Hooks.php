<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Actions\PostCreation\PostCreationHelperPro;
use BitApps\IntegrationsPro\Config;
use BitApps\IntegrationsPro\Core\Util\Hooks;

// Deprecated since v2.7.8 - use bit_integrations_* hooks instead
if (bit_integrations_version_below('2.7.8')) {
    Hooks::add('btcbi_add_post_tag', [PostCreationHelperPro::class, 'addPostTags'], 10, 2);
}

// New hooks since v2.7.8
Hooks::add(Config::withFreePrefix('add_post_tag'), [PostCreationHelperPro::class, 'addPostTags'], 10, 2);

Hooks::filter(Config::withFreePrefix('updateExistingPost'), [PostCreationHelperPro::class, 'updateExistingPost'], 10, 2);
Hooks::filter(Config::withFreePrefix('updatePostStatus'), [PostCreationHelperPro::class, 'updatePostStatus'], 10, 2);
Hooks::filter(Config::withFreePrefix('deleteExistingPost'), [PostCreationHelperPro::class, 'deleteExistingPost'], 10, 2);

Hooks::filter(Config::withFreePrefix('createNewComment'), [PostCreationHelperPro::class, 'createNewComment'], 10, 2);
Hooks::filter(Config::withFreePrefix('replyToComment'), [PostCreationHelperPro::class, 'replyToComment'], 10, 2);
Hooks::filter(Config::withFreePrefix('deleteExistingComment'), [PostCreationHelperPro::class, 'deleteExistingComment'], 10, 2);
