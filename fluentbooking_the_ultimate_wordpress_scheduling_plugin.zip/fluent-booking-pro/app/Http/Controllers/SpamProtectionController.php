<?php

namespace FluentBookingPro\App\Http\Controllers;

use FluentBooking\App\Http\Controllers\Controller;
use FluentBooking\Framework\Http\Request\Request;
use FluentBooking\Framework\Support\Arr;
use FluentBookingPro\App\Services\Captcha\CaptchaManager;

class SpamProtectionController extends Controller
{
    public function getSettings(Request $request)
    {
        return [
            'settings'  => CaptchaManager::getDisplaySettings(),
            'providers' => $this->providerList(),
        ];
    }

    public function saveSettings(Request $request)
    {
        $input = $request->get('settings', []);

        if (!is_array($input)) {
            $input = [];
        }

        $provider = sanitize_text_field(Arr::get($input, 'provider', ''));

        if (Arr::get($input, 'enabled') === 'yes') {
            $providerObject = CaptchaManager::getProvider($provider);

            if (!$providerObject) {
                return $this->sendError([
                    'message' => __('Select a captcha provider first.', 'fluent-booking-pro'),
                ], 422);
            }

            // The incoming keys are not stored yet, so check the sanitized pair
            // the save would write.
            $candidate = $providerObject->sanitize(
                (array)Arr::get($input, 'providers.' . $provider, []),
                (array)Arr::get(CaptchaManager::getSettings(), 'providers.' . $provider, [])
            );

            if (!$providerObject->isConfigured($candidate)) {
                return $this->sendError([
                    'message' => __('Add the Site Key and the Secret Key before you turn spam protection on.', 'fluent-booking-pro'),
                ], 422);
            }
        }

        $settings = CaptchaManager::save($input);

        return [
            'message'  => __('Settings saved.', 'fluent-booking-pro'),
            'settings' => $settings,
        ];
    }

    public function verifyKeys(Request $request)
    {
        $provider = sanitize_text_field($request->get('provider', ''));
        $input    = $request->get('settings', []);
        $token    = sanitize_text_field($request->get('token', ''));

        $result = CaptchaManager::validateCredentials($provider, is_array($input) ? $input : [], $token);

        if (empty($result['valid'])) {
            return $this->sendError([
                'message' => Arr::get($result, 'message', __('The keys could not be verified.', 'fluent-booking-pro')),
            ], 422);
        }

        CaptchaManager::clearSetupError();

        return [
            'message' => Arr::get($result, 'message', ''),
        ];
    }

    /**
     * @return array
     */
    private function providerList()
    {
        $list = [];

        foreach (CaptchaManager::getProviders() as $key => $provider) {
            $list[] = [
                'key'   => $key,
                'title' => $provider->getTitle(),
            ];
        }

        return $list;
    }
}
