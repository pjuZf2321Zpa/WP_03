<?php

namespace Breakdance\DesignLibrary;

/**
 * Provider-site references inside a copied tree.
 *
 * A design copied from another site carries two kinds of references that
 * must be rewritten to work here: post ids of the reusable blocks/components
 * it embeds, and links to the provider site's own pages. Both the full-site
 * importer (rest.php) and the MCP tools (mcp/tools/design-library.php) go
 * through these helpers so the rules are stated once.
 *
 * Plain PHP with no WordPress dependency, so it loads standalone under the
 * unit-test bootstrap.
 */

/**
 * Property names whose integer value is a post id pointing at a reusable
 * block/component.
 *
 * @return list<string>
 */
function blockReferencePatterns()
{
    return [
        'block',
        'global_block',
        'componentId', // Oxygen
        'when_empty', // Loop Builders
        'after_title_bar', // WooCommerce
        'after_footer' // WooCommerce
    ];
}

/**
 * Regex matching one reference, capturing the property name and the id.
 * `(?!\d)` keeps a shorter id from matching the prefix of a longer one.
 *
 * @return string
 */
function blockReferenceRegex()
{
    $patterns = array_map('preg_quote', blockReferencePatterns());

    return '/"(' . implode('|', $patterns) . ')":\s*(\d+)(?!\d)/';
}

/**
 * The block ids `$json` references, in order of first appearance.
 *
 * @param string $json
 * @return list<int>
 */
function referencedBlockIds($json)
{
    if (!preg_match_all(blockReferenceRegex(), $json, $matches)) {
        return [];
    }

    /**
     * The regex always has two capture groups, so `$matches[2]` is set.
     * @psalm-suppress PossiblyUndefinedIntArrayOffset
     * @psalm-suppress MixedArgument
     */
    $ids = array_map('intval', $matches[2]);

    return array_values(array_unique($ids));
}

/**
 * Rewrite every reference in `$json` whose id appears in `$map`.
 *
 * Done in a single pass with an exact-id match. Replacing per map entry
 * would rewrite the prefix of a longer id ("block":123 while mapping 12),
 * and could remap an id twice when one block's new id equals another's old
 * id (49 => 1012 followed by 1012 => 2000).
 *
 * @param string $json
 * @param array<int, int> $map Old id => new id.
 * @return string
 */
function mapBlockIdsInJson($json, array $map)
{
    if ($map === []) {
        return $json;
    }

    $replaced = preg_replace_callback(
        blockReferenceRegex(),
        /**
         * @param array<int, string> $matches
         * @return string
         */
        function ($matches) use ($map) {
            /** @psalm-suppress PossiblyUndefinedIntArrayOffset */
            $id = (int) $matches[2];

            /** @psalm-suppress PossiblyUndefinedIntArrayOffset */
            return '"' . $matches[1] . '":' . (isset($map[$id]) ? (int) $map[$id] : $matches[2]);
        },
        $json
    );

    return is_string($replaced) ? $replaced : $json;
}


/**
 * Rewrite links to the provider site's pages into links to `$site_url`.
 * Media URLs (anything under /wp-content/) intentionally keep pointing at
 * the provider - media is not imported. The provider URL's query string and
 * fragment (e.g. a stored access password) are ignored for matching.
 *
 * @param string $json
 * @param string $provider_url
 * @param string $site_url
 * @return string
 */
function rewriteProviderUrlsInJson($json, $provider_url, $site_url)
{
    $parts = parse_url($provider_url);
    if (is_array($parts) && !empty($parts['host'])) {
        $scheme       = isset($parts['scheme']) ? $parts['scheme'] . '://' : '';
        $provider_url = $scheme . $parts['host'] . (isset($parts['port']) ? ':' . $parts['port'] : '') . ($parts['path'] ?? '');
    }
    $old_url = rtrim($provider_url, '/');

    // Match all URLs that don't include /wp-content/ to avoid replacing image URLs
    $regex    = '/"((' . preg_quote($old_url, '/') . ')((?!\/wp-content\/)[^"]+))"/';
    $replaced = preg_replace($regex, '"' . $site_url . '${3}"', $json);

    return is_string($replaced) ? $replaced : $json;
}
