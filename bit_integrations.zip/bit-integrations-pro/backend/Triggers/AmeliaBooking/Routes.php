<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Core\Util\Route;
use BitApps\IntegrationsPro\Triggers\AmeliaBooking\AmeliaBookingController;

Route::get('amelia/get', [AmeliaBookingController::class, 'getAllTasks']);
