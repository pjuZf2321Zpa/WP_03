<?php

namespace FluentCartPro\App\Modules\DynamicPricing\Pricing;

use FluentCart\App\Helpers\Helper;
use FluentCart\Api\CurrencySettings;
use FluentCart\App\Models\Cart;
use FluentCart\App\Modules\MultiCurrency\Services\CartCurrency;
use FluentCart\App\Services\Money;
use FluentCart\Framework\Support\Arr;
use FluentCartPro\App\Modules\DynamicPricing\Conditions\ConditionResolver;

/**
 * Puts what the rules produce onto the cart.
 *
 * Fees and discounts take different routes because core treats them
 * differently: a fee is its own line and must be positive, while a discount
 * comes off the items it applies to.
 *
 * @package FluentCartPro\App\Modules\DynamicPricing
 *
 * @version 1.0.0
 */
class CartAdjustmentApplier
{
    /**
     * Marks these fees as ours, so core can tell them from a merchant's own and
     * replace them cleanly when the cart recalculates.
     */
    const FEE_SOURCE = 'dynamic-pricing';

    /**
     * @var DynamicPricingService
     */
    protected $service;

    /**
     * What the rules took on the most recent run, by rule.
     *
     * `addDiscounts()` works this out on its way to the answer, but a filter
     * returns one value and that value has to be the cart items. Rather than
     * lose it, the run leaves it here for `last_applied_rules` to report.
     *
     * @var array
     */
    protected $lastApplied = [];

    /**
     * What the shipping rules took on the most recent order charge, by rule.
     *
     * Held here rather than on the cart: place-order keeps more than one
     * instance of that row and overwrites checkout_data between the moment
     * this runs and the moment the order is recorded, so a note left there
     * does not survive the journey.
     *
     * @var array
     */
    protected $lastShippingApplied = [];

    public function __construct(?DynamicPricingService $service = null)
    {
        $this->service = $service ?: new DynamicPricingService();
    }

    /**
     * @return void
     */
    public function register()
    {
        add_filter('fluent_cart/cart/fees', [$this, 'addFees'], 10, 2);
        add_filter('fluent_cart/cart/item_dynamic_discount', [$this, 'addDiscounts'], 10, 2);
        add_action('fluent_cart/checkout/before_summary_coupon', [$this, 'renderDiscountLines']);
        add_filter('fluent_cart/cart/estimated_total', [$this, 'discountShipping'], 10, 2);
        add_filter('fluent_cart/checkout/order_shipping_charge', [$this, 'discountOrderShipping'], 10, 2);
        add_filter('fluent_cart/dynamic_pricing/last_applied_rules', [$this, 'lastAppliedRules']);
        add_filter('fluent_cart/dynamic_pricing/last_shipping_rules', [$this, 'lastShippingRules']);
    }

    /**
     * Add a fee line for every fee-producing rule.
     *
     * @param array $fees Fees gathered so far — stored ones, plus anything an
     *                    earlier callback added.
     * @param array $context
     * @return array
     */
    public function addFees($fees, $context)
    {
       
        // Core swaps in the stored fees when this returns a non-array, so a
        // malformed input is handed back rather than built on.
        if (!is_array($fees)) {
            return $fees;
        }

        // Core saves this filter's output on the cart and hands it back next
        // time. Drop our own lines first, so a rule turned off since is gone.
        $fees = array_values(array_filter($fees, function ($fee) {
            return Arr::get($fee, 'source') !== static::FEE_SOURCE;
        }));

        $pricingContext = [
            'cart'  => [
                'subtotal'       => (int)Arr::get($context, 'cart_subtotal', 0),
                'shipping_total' => (int)Arr::get($context, 'shipping_total', 0),
                'items'          => Arr::get($context, 'cart_items', []),
            ],
            'customer'      => $this->customerDetails(Arr::get($context, 'cart')),
            'purchase'      => $this->purchaseDetails(Arr::get($context, 'cart')),
            'checkout_cart' => Arr::get($context, 'cart'),
        ];

        // One resolver for both passes, so a condition's database lookup runs once.
        $conditions = new ConditionResolver($pricingContext);

        $discountedItems = $this->discountedItemAmounts(
            (array)Arr::get($context, 'cart_items', []),
            (array)Arr::get($context, 'checkout_data', []),
            Arr::get($context, 'cart'),
            $conditions
        );

        $pricingContext['cart']['discounted_subtotal'] = array_sum($discountedItems);
        $pricingContext['cart']['discounted_items'] = $discountedItems;

        $adjustments = $this->service->calculate($pricingContext, 'fee', $conditions);

        

        foreach ($this->combineFeesByRule($adjustments) as $fee) {
            $fees[] = [
                // Keyed by rule so a recalculation replaces the line rather than
                // adding a second one — core dedupes on `source:key`.
                'key'     => 'rule_' . $fee['rule_id'],
                'label'   => $fee['rule_name'],
                'amount'  => $fee['amount'],
                'taxable' => $fee['taxable'],
                'source'  => static::FEE_SOURCE,
                'meta'    => ['rule_type' => $fee['rule_type']],
            ];
        }

        return $fees;
    }

    /**
     * What each item costs after coupons and rule discounts, for percentage fees.
     *
     * Place-order saves the rule discounts into the items while the checkout
     * page does not, so any saved ones are taken back and the rules applied
     * fresh — the fee then matches on both.
     *
     * @param array $items
     * @param array $checkoutData
     * @param mixed $cart
     * @param ConditionResolver|null $conditions
     * @return array Item keys mapped to cents.
     */
    protected function discountedItemAmounts(array $items, array $checkoutData, $cart = null, ?ConditionResolver $conditions = null): array
    {
        $ownDiscounts = (array)Arr::get($checkoutData, DynamicDiscountPersister::BOOKKEEPING_KEY, []);

        foreach ($ownDiscounts as $key => $cents) {
            if (!isset($items[$key])) {
                continue;
            }

            $item = (array)$items[$key];
            $subtotal = (int)Arr::get($item, 'subtotal', 0);
            $manual = max(0, (int)Arr::get($item, 'manual_discount', 0) - (int)$cents);
            $total = min($manual + (int)Arr::get($item, 'coupon_discount', 0), $subtotal);

            $item['manual_discount'] = $manual;
            $item['discount_total'] = $total;
            $item['line_total'] = $subtotal - $total;

            $items[$key] = $item;
        }

        if ($items) {
            $items = $this->applyDiscounts($items, 0, $cart, $conditions)['cart'];
        }

        $amounts = [];

        foreach ($items as $key => $item) {
            $item = (array)$item;
            $subtotal = (int)Arr::get($item, 'subtotal', 0);

            $amounts[$key] = max(0, $subtotal - (int)Arr::get($item, 'discount_total', 0));
        }

        return $amounts;
    }


    /**
     * Combine each rule's fee adjustments into the single line core will show.
     *
     * A line-item rule produces one adjustment per line, but the merchant
     * configured one rule and expects one line. For fees this is required
     * rather than merely tidy: every line would carry the same `source:key`,
     * and core keeps only the last of those — a 10% fee across 100.00 and 40.00
     * would charge 4.00 rather than 14.00.
     *
     * @param array $adjustments
     * @return array One entry per fee-producing rule.
     */
    protected function combineFeesByRule(array $adjustments): array
    {
        $combined = [];

        foreach ($adjustments as $adjustment) {
            if ($adjustment['adjustment_type'] !== 'fee') {
                continue;
            }

            $ruleId = $adjustment['rule_id'];

            $combined[$ruleId] = [
                'rule_id'   => $ruleId,
                'rule_type' => $adjustment['rule_type'],
                'rule_name' => $adjustment['rule_name'],
                'amount'    => Arr::get($combined, $ruleId . '.amount', 0) + $adjustment['adjustment_amount'],
                'taxable'   => (bool)Arr::get($adjustment, 'taxable', true),
            ];
        }

        return $combined;
    }

    /**
     * Show each discount rule as its own line on the checkout summary.
     *
     * A fee gets a line for free — core renders whatever `fluent_cart/cart/fees`
     * returns. A discount has no such list: it comes off the cart items, or off
     * the total in shipping's case, so it moves the total with nothing on screen
     * to say why. This prints the missing line.
     *
     * Echoed from an action rather than returned through
     * `fluent_cart/checkout/summary_extra_lines`, because that filter renders a
     * bare <li> with the amount exactly as given — no class to style, no key for
     * the DOM, and no `-` in front, which every discount in core (manual,
     * upgrade, prorate) is written with. The Tax module echoes its own line from
     * an action for the same reason.
     *
     * Shows what each rule took, not what it asked for. On a cart with little
     * room left the two differ, and the figure the customer reads has to be the
     * one in the total.
     *
     * @param array $data
     * @return void
     */
    public function renderDiscountLines($data)
    {
        $applied = $this->appliedFor(Arr::get($data, 'cart'));

        if (!$applied) {
            return;
        }


        foreach ($applied['accepted'] as $discount) {
            $key = 'rule_' . $discount['rule_id'];
            $amount = Helper::toDecimal($discount['amount']);
            ?>
                <li
                    class="fct_dynamic_pricing_discount_row"
                    data-fluent-cart-checkout-dynamic-pricing-discount="<?php echo esc_attr($key); ?>"
                >
                    <span class="fct_summary_label">
                        <?php echo esc_html($discount['rule_name']); ?>
                    </span>

                    <span
                        class="fct_summary_value"
                        data-fluent-cart-checkout-dynamic-pricing-discount-amount="<?php echo esc_attr($key); ?>"
                    >
                        -<?php echo esc_html($amount); ?>
                    </span>
                </li>
            <?php
        }

        $this->renderShippingAfterDiscount($applied);
    }

    /**
     * Show what the postage costs once the rules have had their share.
     *
     * The Shipping line above still reads the full charge, because that is what
     * the carrier is owed and the discount is its own row. Between the two, the
     * customer is left working out the new price themselves. This says it.
     *
     * Nothing is printed when no rule touched shipping — a row reading the same
     * figure as the Shipping line above it explains nothing.
     *
     * @param array $applied
     * @return void
     */
    protected function renderShippingAfterDiscount(array $applied)
    {
        if ($applied['shipping_taken'] <= 0) {
            return;
        }

        $amount = Helper::toDecimal($applied['shipping_total'] - $applied['shipping_taken']);
        ?>
            <li class="fct_dynamic_pricing_shipping_row">
                <span class="fct_summary_label">
                    <?php echo esc_html__('Shipping after discount', 'fluent-cart-pro'); ?>
                </span>

                <span
                    class="fct_summary_value"
                    data-fluent-cart-checkout-dynamic-pricing-shipping-amount
                >
                    <?php echo esc_html($amount); ?>
                </span>
            </li>
        <?php
    }

    /**
     * Take the shipping rules' discounts off the cart total.
     *
     * Shipping is the one target with nowhere to record a discount: an item
     * discount sits on its line, but core keeps shipping as a single charge, and
     * writing a rule's reduction into it would hide the rule and change what the
     * gateway is told to collect for postage.
     *
     * So the shipping line keeps its real price, the rule gets its own row on
     * the summary, and the money comes off here — the same shape core already
     * uses for its upgrade discount and prorate credit.
     *
     * @param int $total
     * @param array $data
     * @return int
     */
    public function discountShipping($total, $data)
    {
        $applied = $this->appliedFor(Arr::get($data, 'cart'));

        if (!$applied || $applied['shipping_taken'] <= 0) {
            return $total;
        }

        return max(0, (int)$total - $applied['shipping_taken']);
    }

    /**
     * Take the shipping rules off the charge the order is about to store.
     *
     * Same rules, other doorway: discountShipping() above serves the display
     * and reads the shipping amount off the cart. At place-order time the cart
     * still says zero shipping, so this one measures against the real charge
     * placeOrder computed and handed through the filter.
     *
     * @param int $charge The order's shipping charge, in cents.
     * @param array $data ['cart' => Cart]
     * @return int
     */
    public function discountOrderShipping($charge, $data)
    {
        $charge = max(0, (int)$charge);
        $cart = Arr::get((array)$data, 'cart');

        if (!$charge || !$cart) {
            return $charge;
        }

        $cartData = (array)$cart->cart_data;

        if (!$cartData) {
            return $charge;
        }

        $applied = $this->applyDiscounts($cartData, $charge, $cart);

        $this->lastShippingApplied = $applied['shipping_rules'];

        return max(0, $charge - $applied['shipping_taken']);
    }

    /**
     * Which shipping rules took money from the order's postage.
     *
     * Answers `fluent_cart/dynamic_pricing/last_shipping_rules`, so the order
     * can record them once it exists — which is long after this ran.
     *
     * @param array $rules
     * @return array
     */
    public function lastShippingRules($rules)
    {
        return $this->lastShippingApplied;
    }

    /**
     * What the discount rules do to this cart, shipping included.
     *
     * The one place that reads the shipping charge, so the row on the summary
     * and the money off the total are always the same figure.
     *
     * @param mixed $cart
     * @return array|null Null when there is no cart to read.
     */
    protected function appliedFor($cart)
    {
        if (!$cart) {
            return null;
        }

        $cartData = (array)$cart->cart_data;

        if (!$cartData) {
            return null;
        }

        // Safe inside the estimated_total filter: getShippingTotal() reads the
        // stored charge and does not come back through the total calculation.
        return $this->applyDiscounts($cartData, (int)$cart->getShippingTotal(), $cart);
    }

    /**
     * Who the customer is, as far as the cart knows: their id when they are
     * signed in, the email typed at checkout when they are not.
     *
     * @param mixed $cart
     * @return array
     */
    protected function customerDetails($cart): array
    {
        if (!$cart) {
            return [];
        }

        return [
            'customer_id' => (int)$cart->customer_id,
            'email'       => (string)$cart->email,
        ];
    }

    /**
     * What kind of purchase this is, as far as the cart knows.
     *
     * A plan change is the instant cart UpgradeHandler builds to move a
     * subscription to another plan, and `upgrade_data` is the one thing that
     * names it.
     *
     * @param mixed $cart
     * @return array ['is_upgrade' => bool]
     */
    protected function purchaseDetails($cart): array
    {
        if (!$cart) {
            return [];
        }

        return [
            'is_upgrade' => (bool)Arr::get((array)$cart->checkout_data, 'upgrade_data'),
        ];
    }

    /**
     * Take discounts off the cart items they apply to.
     *
     * A whole-cart discount is spread across the items, because the only place
     * core carries a discount is on the line. Shipping is passed as zero here:
     * this filter is handed items and nothing else, so a shipping rule measures
     * against nothing and produces no adjustment to spread.
     *
     * @param array $cartData
     * @param array $context
     * @return array
     */
    public function addDiscounts($cartData, $context)
    {
        if (!is_array($cartData) || !$cartData) {
            return $cartData;
        }

        $cart = Arr::get((array)$context, 'cart');

        $applied = $this->applyDiscounts($cartData, 0, $cart);

        $this->lastApplied = $applied['accepted'];

        return $applied['cart'];
    }

    /**
     * Which rules took what on the run that just happened.
     *
     * Answers `fluent_cart/dynamic_pricing/last_applied_rules`, so a caller that
     * has just applied the discounts can find out which rules produced them
     * without running the rules again.
     *
     * @param array $rules
     * @return array Keyed by rule id, each with rule_type, rule_name and a
     *               positive amount.
     */
    public function lastAppliedRules($rules)
    {
        return $this->lastApplied;
    }


    /**
     * Send each discount to the handler for what it applies to, and tally up
     * what every rule actually took.
     *
     * @param array $cartData
     * @param int $shippingTotal What shipping costs, so a shipping rule has
     *                           something to measure against. Zero where the
     *                           caller holds items and nothing else.
     * @param mixed $cart The cart being priced, when the caller has one.
     * @param ConditionResolver|null $conditions Shared with a fee pass on the same cart.
     * @return array Updated cart, accepted amounts by rule, and the part of it
     *               that came off shipping rather than the items.
     */
    protected function applyDiscounts(array $cartData, int $shippingTotal = 0, $cart = null, ?ConditionResolver $conditions = null): array
    {
        $accepted = [];
        $currency = $cart instanceof Cart && class_exists(CartCurrency::class)
            ? CartCurrency::targetQuote($cart)['currency']
            : null;

        // Which rules took the shipping money, kept apart from the rest: it
        // leaves the order by its own route, so the order records it separately
        // from the item discounts.
        $shippingRules = [];

        // Shipping is one charge rather than a set of lines, so what is left of
        // it is counted here — a handler sees one rule and cannot know what the
        // rules before it already took.
        $shippingLeft = $shippingTotal;

        foreach ($this->adjustmentsFor($cartData, $shippingTotal, $cart, $conditions) as $adjustment) {
            if ($adjustment['adjustment_type'] !== 'discount') {
                continue;
            }

            switch ($adjustment['applies_to']) {
                case 'line_item':
                    $result = $this->applyLineItemDiscount($cartData, $adjustment);
                    break;

                case 'checkout':
                    $result = $this->applyCheckoutDiscount($cartData, $adjustment, $currency);
                    break;

                case 'shipping':
                    $result = $this->applyShippingDiscount($cartData, $adjustment, $shippingLeft);
                    $shippingLeft -= $result['taken'];
                    $shippingRules += $result['accepted'];
                    break;

                default:
                    continue 2;
            }

            $cartData = $result['cart'];

            foreach ($result['accepted'] as $ruleId => $acceptedDiscount) {
                $accepted[$ruleId] = [
                    'rule_id'   => $acceptedDiscount['rule_id'],
                    'rule_type' => $acceptedDiscount['rule_type'],
                    'rule_name' => $acceptedDiscount['rule_name'],
                    'amount'    => Arr::get($accepted, $ruleId . '.amount', 0)
                        + $acceptedDiscount['amount'],
                ];
            }
        }

        return [
            'cart'              => $cartData,
            'accepted'          => $accepted,
            'shipping_rules'    => $shippingRules,
            'shipping_total'    => $shippingTotal,
            'shipping_taken'    => $shippingTotal - $shippingLeft,
        ];
    }


    /**
     * Take a rule's discount off the one line it names.
     *
     * @param array $cartData
     * @param array $adjustment
     * @return array
     */
    protected function applyLineItemDiscount(
        array $cartData,
        array $adjustment
    ): array {
        $key = $adjustment['item_key'];

        if ($key === null || !isset($cartData[$key])) {
            return [
                'cart'     => $cartData,
                'accepted' => [],
            ];
        }

        $discount = abs($adjustment['adjustment_amount']);

        $before = (int)Arr::get((array)$cartData[$key], 'discount_total', 0);

        $cartData[$key] = $this->discountItem(
            $cartData[$key],
            $discount
        );

        $taken = (int)Arr::get((array)$cartData[$key], 'discount_total', 0) - $before;

        if ($taken <= 0) {
            return [
                'cart'     => $cartData,
                'accepted' => [],
            ];
        }

        return [
            'cart' => $cartData,
            'accepted' => [
                $adjustment['rule_id'] => [
                    'rule_id'   => $adjustment['rule_id'],
                    'rule_type' => $adjustment['rule_type'],
                    'rule_name' => $adjustment['rule_name'],
                    'amount'    => $taken,
                ],
            ],
        ];
    }

    /**
     * Spread a whole-cart discount over the items and take it off each of them.
     *
     * @param array $cartData
     * @param array $adjustment
     * @return array
     */
    protected function applyCheckoutDiscount(
        array $cartData,
        array $adjustment,
        ?string $currency = null
    ): array {
        $discounts = $this->distributeDiscount(
            abs($adjustment['adjustment_amount']),
            $cartData,
            $currency
        );

        $taken = 0;

        foreach ($discounts as $itemKey => $discount) {
            $before = (int)Arr::get((array)$cartData[$itemKey], 'discount_total', 0);

            $cartData[$itemKey] = $this->discountItem(
                $cartData[$itemKey],
                $discount
            );

            $taken += (int)Arr::get($cartData[$itemKey], 'discount_total', 0) - $before;
        }

        if ($taken <= 0) {
            return [
                'cart'     => $cartData,
                'accepted' => [],
            ];
        }

        return [
            'cart' => $cartData,
            'accepted' => [
                $adjustment['rule_id'] => [
                    'rule_id'   => $adjustment['rule_id'],
                    'rule_type' => $adjustment['rule_type'],
                    'rule_name' => $adjustment['rule_name'],
                    'amount'    => $taken,
                ],
            ],
        ];
    }

    /**
     * Take a rule's discount off the postage.
     *
     * The cart is handed back untouched: this money comes off the shipping
     * charge, and putting it on a product line would discount the wrong thing.
     * The caller takes it off the total instead, so the shipping line keeps the
     * real price and the rule shows as its own row.
     *
     * Capped at what is left of the postage. Every shipping rule is measured
     * against the full charge, so two of them can ask for more than the postage
     * costs between them.
     *
     * @param array $cartData
     * @param array $adjustment
     * @param int $shippingLeft What is left of the postage, in cents.
     * @return array
     */
    protected function applyShippingDiscount(
        array $cartData,
        array $adjustment,
        int $shippingLeft
    ): array {
        $taken = min(abs($adjustment['adjustment_amount']), $shippingLeft);

        if ($taken <= 0) {
            return [
                'cart'     => $cartData,
                'accepted' => [],
                'taken'    => 0,
            ];
        }

        return [
            'cart'     => $cartData,
            'accepted' => [
                $adjustment['rule_id'] => [
                    'rule_id'   => $adjustment['rule_id'],
                    'rule_type' => $adjustment['rule_type'],
                    'rule_name' => $adjustment['rule_name'],
                    'amount'    => $taken,
                ],
            ],
            'taken'    => $taken,
        ];
    }


    /**
     * What the rules make of these cart items.
     *
     * Shared by the discount that is applied and the line that reports it, so
     * the summary can never name a figure the cart did not actually take.
     *
     * Shipping defaults to zero: a cart item list carries no shipping total, so
     * a caller holding only items measures a shipping rule against nothing and
     * it adjusts nothing. Callers that know what shipping costs pass it.
     *
     * The cart itself rides along as `checkout_cart`, so a condition reads
     * whatever it needs from it rather than each one being copied in here.
     *
     * @param array $cartData
     * @param int $shippingTotal
     * @param mixed $cart
     * @param ConditionResolver|null $conditions
     * @return array
     */
    protected function adjustmentsFor(array $cartData, int $shippingTotal = 0, $cart = null, ?ConditionResolver $conditions = null): array
    {
        // Discount rules only: the caller keeps nothing else, so fee rules
        // would be priced (and their filters run) for nothing.
        return $this->service->calculate([
            'cart'  => [
                'subtotal'       => $this->subtotalOf($cartData),
                'shipping_total' => $shippingTotal,
                'items'          => $cartData,
            ],
            'customer'      => $this->customerDetails($cart),
            'purchase'      => $this->purchaseDetails($cart),
            'checkout_cart' => $cart,
        ], 'discount', $conditions);
    }

    /**
     * Distribute a whole-cart discount across all cart items based on how much
     * discount each item can still accept.
     *
     * First, it finds each item's remaining discountable amount. Then it distributes
     * the requested discount proportionally across those amounts and finally fixes
     * any rounding difference so the distributed amounts equal the original discount.
     *
     * Example:
     * Cart:
     *   item_1 = $50 subtotal, $48 already discounted → $2 still discountable
     *   item_2 = $30 subtotal, $0 already discounted  → $30 still discountable
     *
     * A $10 checkout discount is distributed using the $2 and $30 remaining amounts,
     * rather than the original $50 and $30 subtotals.
     *
     * Returns:
     * [
     *     'item_1' => 62,  // about $0.62
     *     'item_2' => 938, // about $9.38
     * ]
     *
     * Total distributed discount = $10.
     *
     * @param int $discount Total discount to distribute, in cents.
     * @param array $cartData Cart items.
     * @return array Item keys mapped to their discount amounts in cents.
     */
    protected function distributeDiscount(int $discount, array $cartData, ?string $currency = null): array
    {
        $discountable = $this->remainingDiscountableAmounts($cartData);
        $total = array_sum($discountable);

        if ($discount <= 0 || $total <= 0) {
            return [];
        }

        $discounts = $this->calculateItemDiscounts($discount, $discountable, $total, $currency);

        return $this->adjustDiscountRemainder($discounts, $discount, $discountable);
    }


    /**
     * Find how much additional discount each cart item can still receive.
     *
     * The available amount is calculated as:
     *
     *     subtotal - discount_total
     *
     * This is important because an item may already have a coupon discount or
     * another discount applied. Only the remaining amount can receive another
     * discount.
     *
     * Example:
     *   item_1: subtotal = $50, discount_total = $48 → $2 remaining
     *   item_2: subtotal = $30, discount_total = $0  → $30 remaining
     *
     * Returns:
     * [
     *     'item_1' => 200,  // $2
     *     'item_2' => 3000, // $30
     * ]
     *
     * Items with no remaining discountable amount are excluded.
     *
     * @param array $cartData Cart items.
     * @return array Item keys mapped to their remaining discountable amounts in cents.
     */
    protected function remainingDiscountableAmounts(array $cartData): array
    {
        $discountable = [];

        foreach ($cartData as $key => $item) {
            $item = (array)$item;

            $remaining = (int)Arr::get($item, 'subtotal', 0) - (int)Arr::get($item, 'discount_total', 0);

            if ($remaining > 0) {
                $discountable[$key] = $remaining;
            }
        }

        return $discountable;
    }


    /**
     * Calculate how much of the total discount each item should receive.
     *
     * Each item's share is based on its remaining discountable amount compared
     * with the total remaining discountable amount across the cart.
     *
     * Formula:
     *
     *     item discount = total discount × (item remaining / total remaining)
     *
     * Example:
     *   item_1 has $2 remaining
     *   item_2 has $30 remaining
     *   total remaining = $32
     *   total discount = $10
     *
     *   item_1 = $10 × (2 / 32)  ≈ $0.62
     *   item_2 = $10 × (30 / 32) ≈ $9.38
     *
     * Returns:
     * [
     *     'item_1' => 62,
     *     'item_2' => 938,
     * ]
     *
     * The result may differ from the original discount by a few cents because
     * each item's amount is rounded. adjustDiscountRemainder() fixes that difference.
     *
     * @param int $discount Total discount to distribute, in cents.
     * @param array $discountable Item keys mapped to their remaining discountable amounts.
     * @param int $total Total remaining discountable amount across the cart, in cents.
     * @return array Item keys mapped to their calculated discount amounts in cents.
     */
    protected function calculateItemDiscounts(
        int $discount,
        array $discountable,
        int $total,
        ?string $currency = null
    ): array {
        $discounts = [];
        $currency = $currency ?? (string) CurrencySettings::get('currency');
        $zeroDecimal = class_exists(Money::class) && Money::getDecimals($currency) === 0;

        foreach ($discountable as $key => $remaining) {
            // Never more than the line can hold, so rounding up cannot hand a
            // line a share that would only be clipped later.
            $share = $discount * ($remaining / $total);
            if ($zeroDecimal) {
                $share = floor($share / 100) * 100;
            }
            $discounts[$key] = min($remaining, (int) round($share));
        }

        return $discounts;
    }


    /**
     * Correct any rounding difference so the item discounts add up exactly
     * to the original discount amount.
     *
     * Because each item's share is rounded independently, the calculated
     * discounts may be slightly higher or lower than the requested discount.
     *
     * Example:
     *   Requested discount = $10
     *
     *   Calculated:
     *     item_1 = $3.33
     *     item_2 = $3.33
     *     item_3 = $3.33
     *     ----------------
     *     Total    = $9.99
     *
     *   The missing $0.01 is added to an item that still has room:
     *
     *     item_1 = $3.33
     *     item_2 = $3.33
     *     item_3 = $3.34
     *     ----------------
     *     Total    = $10.00
     *
     * The method also handles the opposite case where rounding produces more
     * than the requested discount by taking the excess back.
     *
     * It always respects each item's remaining discountable amount, so it will
     * not add more discount to an item than that item can actually accept.
     *
     * @param array $discounts Item keys mapped to their calculated discounts in cents.
     * @param int $discount Original total discount in cents.
     * @param array $discountable Item keys mapped to their remaining discountable amounts.
     * @return array Corrected item discounts in cents.
     */
    protected function adjustDiscountRemainder(array $discounts, int $discount, array $discountable): array
    {
        $remainder = $discount - array_sum($discounts);

        foreach ($discounts as $key => $amount) {
            if ($remainder === 0) {
                break;
            }

            if ($remainder > 0) {
                // The item can take more discount, so add as much of the remainder as it can accept.
                $spare = Arr::get($discountable, $key, 0) - $amount;

                // If the item cannot take any more discount, skip it and move on to the next one.
                if ($spare <= 0) {
                    continue;
                }

                // Add the smaller of the remaining discount or the item's spare capacity.
                $add = min($spare, $remainder);

                $discounts[$key] = $amount + $add;
                $remainder -= $add;

                continue;
            }

            $take = min($amount, -$remainder);

            $discounts[$key] = $amount - $take;
            $remainder += $take;
        }

        return $discounts;
    }


    /**
     * @param array $cartData
     * @return int
     */
    protected function subtotalOf($cartData): int
    {
        $subtotal = 0;

        foreach ($cartData as $item) {
            $subtotal += (int)Arr::get((array)$item, 'subtotal', 0);
        }

        return $subtotal;
    }

    /**
     * Record a discount against one cart item.
     *
     * Added to `manual_discount` rather than replacing it, so a rule and a
     * coupon on the same line do not overwrite one another.
     *
     * @param mixed $item
     * @param int $amount Positive cents.
     * @return array
     */
    protected function discountItem($item, int $amount): array
    {
        $item = (array)$item;

        $subtotal = (int)Arr::get($item, 'subtotal', 0);
        $manual = (int)Arr::get($item, 'manual_discount', 0);
        $coupon = (int)Arr::get($item, 'coupon_discount', 0);

        // Capped at what is left on the line: the order charges subtotal minus
        // manual_discount and coupon_discount, so an uncapped manual_discount goes negative.
        $manual += min($amount, max(0, $subtotal - $manual - $coupon));

        $total = min($manual + $coupon, $subtotal);

        $item['manual_discount'] = $manual;
        $item['discount_total'] = $total;
        $item['line_total'] = $subtotal - $total;

        return $item;
    }
}
