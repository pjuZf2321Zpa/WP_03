<?php

namespace FluentBookingPro\App\Services\Captcha;

use FluentBooking\Framework\Support\Arr;

class TurnstileProvider extends AbstractCaptchaProvider
{
    const VERIFY_URL = 'https://challenges.cloudflare.com/turnstile/v0/siteverify';

    const TOKEN_FIELD = 'cf-turnstile-response';

    public function getKey()
    {
        return 'turnstile';
    }

    public function getTitle()
    {
        return __('Cloudflare Turnstile', 'fluent-booking-pro');
    }

    public function getDefaults()
    {
        return [
            'site_key'   => '',
            'secret_key' => '',
        ];
    }

    public function secretFields()
    {
        return ['secret_key'];
    }

    public function sanitize($input, $prev = [])
    {
        if (!is_array($input)) {
            $input = [];
        }

        return [
            'site_key'   => sanitize_text_field(Arr::get($input, 'site_key', '')),
            'secret_key' => $this->resolveSecret(Arr::get($input, 'secret_key', ''), Arr::get($prev, 'secret_key', '')),
        ];
    }

    public function isConfigured($settings)
    {
        return (bool)(Arr::get($settings, 'site_key') && Arr::get($settings, 'secret_key'));
    }

    public function publicVars($settings)
    {
        return [
            'provider'    => $this->getKey(),
            'version'     => '',
            'site_key'    => (string)Arr::get($settings, 'site_key', ''),
            'token_field' => self::TOKEN_FIELD,
            'action'      => '',
        ];
    }

    public function verify($settings, $token)
    {
        $secret = $this->decryptSecret(Arr::get($settings, 'secret_key', ''));

        if (!$secret) {
            return [
                'status' => 'unreachable',
                'code'   => 'invalid_secret',
                'reason' => 'The stored Turnstile secret key is missing or cannot be read.',
            ];
        }

        // Cloudflare's documented way to retry siteverify without spending the token twice.
        $body = [
            'secret'          => $secret,
            'response'        => $token,
            'idempotency_key' => wp_generate_uuid4(),
        ];

        /**
         * The IP is optional to Cloudflare. An operator can return an empty
         * string to keep it out of the call.
         *
         * @param string $ip
         * @param array  $settings
         */
        $remoteIp = apply_filters('fluent_booking/turnstile_remoteip', $this->getIpAddress(), $settings);

        if ($remoteIp) {
            $body['remoteip'] = $remoteIp;
        }

        $response = $this->remoteVerify(self::VERIFY_URL, $body);

        if ($response['unreachable']) {
            return [
                'status' => 'unreachable',
                'code'   => 'provider_unreachable',
                'reason' => $response['reason'],
            ];
        }

        if (!empty($response['result']['success'])) {
            return [
                'status' => 'valid',
                'code'   => '',
            ];
        }

        return $this->resultFromErrorCodes($response['result']);
    }

    public function validateCredentials($settings, $token)
    {
        $secret = $this->decryptSecret(Arr::get($settings, 'secret_key', ''));

        if (!$secret) {
            return [
                'valid'   => false,
                'message' => __('Add a Secret Key first.', 'fluent-booking-pro'),
            ];
        }

        if (!Arr::get($settings, 'site_key')) {
            return [
                'valid'   => false,
                'message' => __('Add a Site Key first.', 'fluent-booking-pro'),
            ];
        }

        // Cloudflare checks the token before the secret, so a test without a
        // real token proves nothing about the keys.
        if (!$token) {
            return [
                'valid'   => false,
                'message' => __('FluentBooking could not get a token from Cloudflare. Check the Site Key, and make sure this domain is on the key.', 'fluent-booking-pro'),
            ];
        }

        $response = $this->remoteVerify(self::VERIFY_URL, [
            'secret'   => $secret,
            'response' => $token,
        ], 1);

        if ($response['unreachable']) {
            return [
                'valid'   => false,
                'message' => __('FluentBooking cannot connect to Cloudflare. Try again in a minute.', 'fluent-booking-pro'),
            ];
        }

        $result = $response['result'];

        if (!empty($result['success'])) {
            return [
                'valid'   => true,
                'message' => __('Cloudflare accepted both keys.', 'fluent-booking-pro'),
            ];
        }

        $codes = array_map('strval', (array)Arr::get($result, 'error-codes', []));

        if (in_array('invalid-input-secret', $codes, true) || in_array('missing-input-secret', $codes, true)) {
            return [
                'valid'   => false,
                'message' => __('Cloudflare refused this Secret Key. Check the key in your Cloudflare dashboard.', 'fluent-booking-pro'),
            ];
        }

        if (in_array('invalid-input-response', $codes, true) || in_array('timeout-or-duplicate', $codes, true)) {
            return [
                'valid'   => false,
                'message' => __('Cloudflare refused the token. The Site Key and the Secret Key must come from the same Turnstile widget.', 'fluent-booking-pro'),
            ];
        }

        return [
            'valid'   => false,
            'message' => __('Cloudflare refused these keys. Check both keys and try again.', 'fluent-booking-pro'),
        ];
    }
}
