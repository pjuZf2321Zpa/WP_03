<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Actions\GoogleSheet\GoogleSheetProHelper;
use BitApps\IntegrationsPro\Config;
use BitApps\IntegrationsPro\Core\Util\Hooks;

Hooks::filter(Config::withFreePrefix('google_sheet_create_spreadsheet'), [GoogleSheetProHelper::class, 'createSpreadsheet'], 10, 3);
Hooks::filter(Config::withFreePrefix('google_sheet_delete_spreadsheet'), [GoogleSheetProHelper::class, 'deleteSpreadsheet'], 10, 3);
Hooks::filter(Config::withFreePrefix('google_sheet_create_sheet'), [GoogleSheetProHelper::class, 'createSheet'], 10, 3);
Hooks::filter(Config::withFreePrefix('google_sheet_copy_sheet'), [GoogleSheetProHelper::class, 'copySheet'], 10, 3);
Hooks::filter(Config::withFreePrefix('google_sheet_delete_sheet'), [GoogleSheetProHelper::class, 'deleteSheet'], 10, 3);
Hooks::filter(Config::withFreePrefix('google_sheet_append_or_update_row'), [GoogleSheetProHelper::class, 'appendOrUpdateRow'], 10, 3);
Hooks::filter(Config::withFreePrefix('google_sheet_update_row'), [GoogleSheetProHelper::class, 'updateRow'], 10, 3);
Hooks::filter(Config::withFreePrefix('google_sheet_delete_row'), [GoogleSheetProHelper::class, 'deleteRow'], 10, 3);
Hooks::filter(Config::withFreePrefix('google_sheet_create_column'), [GoogleSheetProHelper::class, 'createColumn'], 10, 3);
