<?php

namespace FluentCartPro\App\Modules\Reports\Http\Controllers;

use FluentCart\App\Http\Controllers\Controller;
use FluentCart\App\Services\Report\InstallmentReportService;
use FluentCart\App\Services\Report\ReportHelper;
use FluentCart\Framework\Http\Request\Request;
use FluentCart\Framework\Support\Arr;
use FluentCartPro\App\Modules\Reports\Services\SubscriptionInsightsService;

class SubscriptionInsightsController extends Controller
{
    public function rebuys(Request $request): array
    {
        // One currency: prices compare only within it
        $params = ReportHelper::processParams($request->get('params'), ['windowDays', 'billingInterval']);

        return SubscriptionInsightsService::make()->getRebuys($params);
    }

    // Core keeps the per-variation totals: its installment report and MCP tool share them
    public function installmentVariations(Request $request)
    {
        $raw = (array) $request->get('params', []);
        $params = ReportHelper::processParams($raw, [], true);

        return InstallmentReportService::make()->getByVariation([
            'currency'     => $params['currency'],
            'variationIds' => $params['variationIds'],
            'startedFrom'  => Arr::get($raw, 'started_from'),
            'startedTo'    => Arr::get($raw, 'started_to'),
        ]);
    }
}
