<?php

use MasterStudy\Lms\Plugin\Addons;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function masterstudy_lms_calendar_addon_key(): string {
	return defined( Addons::class . '::CALENDAR' )
		? Addons::CALENDAR
		: 'calendar';
}

function masterstudy_lms_calendar_available(): bool {
	return function_exists( 'is_ms_lms_addon_enabled' )
		&& is_ms_lms_addon_enabled( masterstudy_lms_calendar_addon_key() )
		&& class_exists( 'STM_LMS_Helpers' )
		&& STM_LMS_Helpers::is_pro_plus();
}

function masterstudy_lms_calendar_menu_entry(): array {
	$current_slug = masterstudy_get_current_account_slug();

	return array(
		'order'        => 177,
		'id'           => 'calendar',
		'slug'         => 'calendar',
		'lms_template' => 'account/calendar',
		'menu_title'   => esc_html__( 'Calendar', 'masterstudy-lms-learning-management-system-pro' ),
		'menu_icon'    => 'stmlms-calendar',
		'menu_url'     => ms_plugin_user_account_url( 'calendar' ),
		'menu_place'   => 'learning',
		'is_active'    => 'calendar' === $current_slug,
		'section'      => 'progress',
	);
}

function masterstudy_lms_calendar_menu_item( $menus ) {
	if ( ! masterstudy_lms_calendar_available() ) {
		return $menus;
	}

	$menus[] = masterstudy_lms_calendar_menu_entry();

	return $menus;
}
add_filter( 'stm_lms_menu_items', 'masterstudy_lms_calendar_menu_item' );

function masterstudy_lms_calendar_exists_in_sortable_menu( string $menu_name ): bool {
	$settings = get_option( 'stm_lms_settings', array() );

	if ( empty( $settings[ $menu_name ] ) || ! is_array( $settings[ $menu_name ] ) ) {
		return false;
	}

	foreach ( $settings[ $menu_name ] as $menu ) {
		$options = $menu['options'] ?? array();

		if ( is_array( $options ) && in_array( 'calendar', array_column( $options, 'id' ), true ) ) {
			return true;
		}
	}

	return false;
}

function masterstudy_lms_calendar_sorted_menu_item( $menus, $menu_name ) {
	if (
		! masterstudy_lms_calendar_available()
		|| ! in_array( $menu_name, array( 'sorting_the_menu', 'sorting_the_menu_student', 'sorting_float_menu_learning', 'sorting_full_float_menu' ), true )
		|| in_array( 'calendar', array_column( $menus, 'id' ), true )
		|| masterstudy_lms_calendar_exists_in_sortable_menu( $menu_name )
	) {
		return $menus;
	}

	$menus[] = masterstudy_lms_calendar_menu_entry();

	array_multisort( array_column( $menus, 'order' ), SORT_ASC, $menus );

	return $menus;
}
add_filter( 'stm_lms_sorted_menu', 'masterstudy_lms_calendar_sorted_menu_item', 20, 2 );

function masterstudy_lms_calendar_account_route( $routes ) {
	if ( ! masterstudy_lms_calendar_available() ) {
		return $routes;
	}

	$routes['user_url']['sub_pages']['calendar'] = array(
		'title'     => esc_html__( 'Calendar', 'masterstudy-lms-learning-management-system-pro' ),
		'template'  => 'account/calendar',
		'protected' => true,
		'url'       => 'calendar',
	);

	return $routes;
}
add_filter( 'stm_lms_custom_routes_config', 'masterstudy_lms_calendar_account_route' );
