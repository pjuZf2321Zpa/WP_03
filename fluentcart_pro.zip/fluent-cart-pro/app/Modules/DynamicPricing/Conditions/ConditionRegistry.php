<?php

namespace FluentCartPro\App\Modules\DynamicPricing\Conditions;

use FluentCart\Framework\Support\Arr;
use FluentCartPro\App\Modules\DynamicPricing\Conditions\Options\CouponOptions;
use FluentCartPro\App\Modules\DynamicPricing\Conditions\Options\CustomerOptions;
use FluentCartPro\App\Modules\DynamicPricing\Conditions\Options\PaymentMethodOptions;
use FluentCartPro\App\Modules\DynamicPricing\Conditions\Options\ProductOptions;
use FluentCartPro\App\Modules\DynamicPricing\Conditions\Options\UserRoleOptions;

/**
 * Registry of the attributes a pricing rule condition can be built from.
 *
 * This is the single source of truth for both sides of the feature: the admin
 * UI renders its dropdowns from it, and saved conditions are validated against
 * it. Add-ons extend it through the `fluent_cart/dynamic_pricing_condition_attributes`
 * filter, which means a registered attribute becomes selectable and accepted
 * on save without touching this file.
 *
 * @package FluentCartPro\App\Modules\DynamicPricing
 *
 * @version 1.0.0
 */
class ConditionRegistry
{
    // Maximum number of values allowed for a select condition.
    const MAX_SELECT_VALUES = 100;

    /**
     * Operators are decided by the attribute's data type, not by the attribute
     * itself — number attributes get magnitude comparisons, text attributes get
     * substring matching. A new attribute reuses whichever set matches its type.
     *
     * @return array
     */
    public static function numberOperators(): array
    {
        return [
            'is'           => __('is', 'fluent-cart-pro'),
            'is_not'       => __('is not', 'fluent-cart-pro'),
            'is_more_than' => __('is more than', 'fluent-cart-pro'),
            'is_less_than' => __('is less than', 'fluent-cart-pro'),
            'is_at_least'  => __('is at least', 'fluent-cart-pro'),
            'is_at_most'   => __('is at most', 'fluent-cart-pro'),
        ];
    }

    /**
     * @return array
     */
    public static function textOperators(): array
    {
        return [
            'is'           => __('is', 'fluent-cart-pro'),
            'is_not'       => __('is not', 'fluent-cart-pro'),
            'contains'     => __('contains', 'fluent-cart-pro'),
            'not_contains' => __('not contains', 'fluent-cart-pro'),
            'starts_with'  => __('starts with', 'fluent-cart-pro'),
            'ends_with'    => __('ends with', 'fluent-cart-pro'),
        ];
    }

    /**
     * For attributes whose value is picked from a list rather than typed. The
     * comparisons the other sets carry are meaningless against an id.
     *
     * @return array
     */
    public static function selectOperators(): array
    {
        return [
            'is'     => __('is', 'fluent-cart-pro'),
            'is_not' => __('is not', 'fluent-cart-pro'),
        ];
    }

    /**
     * All registered condition attributes, grouped by provider.
     *
     * Shaped like the table filter registry (`provider => [label, value,
     * children]`) so the admin UI can drive the picker and add-on authors
     * register the way they already do for filter options. A child that has
     * children of its own is a group nested in the group, as Checkout Fields
     * holds the checkout settings' groups.
     *
     * @return array
     */
    public static function all(): array
    {
        $groups = [
            'cart'    => [
                'label'    => __('Cart', 'fluent-cart-pro'),
                'value'    => 'cart',
                'children' => [
                    [
                        'label'      => __('Quantity', 'fluent-cart-pro'),
                        'value'      => 'quantity',
                        'input_type' => 'number',
                        'operators'  => static::numberOperators(),
                    ],
                    [
                        'label'      => __('Subtotal', 'fluent-cart-pro'),
                        'value'      => 'cart_subtotal',
                        'input_type' => 'currency',
                        'operators'  => static::numberOperators(),
                    ],
                ],
            ],
            'coupon'  => [
                'label'    => __('Coupon', 'fluent-cart-pro'),
                'value'    => 'coupon',
                'children' => [
                    [
                        'label'      => __('Coupon Name', 'fluent-cart-pro'),
                        'value'      => 'coupon_name',
                        'input_type' => 'text',
                        'operators'  => static::textOperators(),
                    ],
                    [
                        'label'      => __('Coupon', 'fluent-cart-pro'),
                        'value'      => 'coupon',
                        'input_type' => 'select',
                        'data_key'   => (new CouponOptions())->key(),
                        'multiple'   => true,
                        'operators'  => static::selectOperators(),
                    ],
                ],
            ],
            'customer' => [
                'label'    => __('Customer', 'fluent-cart-pro'),
                'value'    => 'customer',
                'children' => [
                    [
                        'label'      => __('Purchase Count', 'fluent-cart-pro'),
                        'value'      => 'customer_purchase_count',
                        'input_type' => 'number',
                        'operators'  => static::numberOperators(),
                    ],
                    [
                        'label'      => __('Customer', 'fluent-cart-pro'),
                        'value'      => 'customer',
                        'input_type' => 'select',
                        'data_key'   => (new CustomerOptions())->key(),
                        'multiple'   => true,
                        'operators'  => static::selectOperators(),
                    ],
                ],
            ],
            'product' => [
                'label'    => __('Product', 'fluent-cart-pro'),
                'value'    => 'product',
                'children' => [
                    [
                        'label'      => __('Product Name', 'fluent-cart-pro'),
                        'value'      => 'product_name',
                        'input_type' => 'text',
                        'operators'  => static::textOperators(),
                    ],
                    [
                        'label'      => __('SKU', 'fluent-cart-pro'),
                        'value'      => 'product_sku',
                        'input_type' => 'text',
                        'operators'  => static::textOperators(),
                    ],
                    [
                        'label'      => __('Product', 'fluent-cart-pro'),
                        'value'      => 'product',
                        'input_type' => 'select',
                        'data_key'   => (new ProductOptions())->key(),
                        'multiple'   => true,
                        'operators'  => static::selectOperators(),
                    ],
                ],
            ],
            'user'    => [
                'label'    => __('User', 'fluent-cart-pro'),
                'value'    => 'user',
                'children' => [
                    [
                        'label'      => __('Role', 'fluent-cart-pro'),
                        'value'      => 'wp_user_role',
                        'input_type' => 'select',
                        'data_key'   => (new UserRoleOptions())->key(),
                        'multiple'   => true,
                        'operators'  => static::selectOperators(),
                    ],
                ],
            ],
            'payment' => [
                'label'    => __('Payment', 'fluent-cart-pro'),
                'value'    => 'payment',
                'children' => [
                    [
                        'label'      => __('Payment Method', 'fluent-cart-pro'),
                        'value'      => 'payment_method',
                        'input_type' => 'select',
                        'data_key'   => (new PaymentMethodOptions())->key(),
                        'multiple'   => true,
                        'operators'  => static::selectOperators(),
                    ],
                ],
            ],
            // Checkout fields, grouped inside as the checkout field settings group them.
            'checkout_fields' => CheckoutFieldConditions::group(),
        ];

        $groups = apply_filters('fluent_cart/dynamic_pricing_condition_attributes', $groups);


        // This runs on every admin page load, and a filter that forgets to
        // return would otherwise fatal on the `array` return type — taking the
        // whole admin down over one add-on's mistake.
        return is_array($groups) ? $groups : [];
    }

    /**
     * Every attribute from every group, re-indexed by its own key.
     *
     * A saved condition only stores `{key, operator, value}` — it never records
     * which group the attribute came from. Grouping exists for the picker, so
     * looking an attribute up in the nested registry would mean searching every
     * group's children. This turns that search into a direct lookup:
     *
     *   all()          cart    => children => [ ['value' => 'quantity',    ...] ]
     *                  coupon  => children => [ ['value' => 'coupon_name', ...] ]
     *
     *   flattened()    'quantity'    => [...]
     *                  'coupon_name' => [...]
     *
     * Same attributes, indexed by the key the stored condition actually holds.
     *
     * @return array
     */
    public static function flattened(): array
    {
        $attributes = [];

        // Walk every group and lift its children up to the top level.
        foreach (static::all() as $group) {
            static::collect(Arr::get(is_array($group) ? $group : [], 'children', []), $attributes);
        }

        return $attributes;
    }

    /**
     * Lift the attributes among a group's children into $attributes, walking
     * into any group nested in it.
     *
     * @param mixed $children
     * @param array $attributes
     * @return void
     */
    protected static function collect($children, array &$attributes)
    {
        if (!is_array($children)) {
            return;
        }

        foreach ($children as $attribute) {
            if (!is_array($attribute)) {
                continue;
            }

            // A nested group: its attributes, not the group itself.
            if (isset($attribute['children'])) {
                static::collect($attribute['children'], $attributes);
                continue;
            }

            // The attribute's own `value` becomes its key, so
            // $attributes['quantity'] resolves without a search.
            $key = Arr::get($attribute, 'value');

            // First registration wins if two groups declare the same key.
            if ($key && !isset($attributes[$key])) {
                $attributes[$key] = $attribute;
            }
        }
    }

    /**
     * The registry as the admin app receives it: same groups, same nesting,
     * fewer fields.
     *
     * Three things happen on the way out.
     *
     * Fields are whitelisted, so a resolver callback or anything else an
     * add-on hung on a definition stays on the server. A closure encodes to
     * `{}` instead of failing, so without this it would reach the page and
     * nobody would notice.
     *
     * Keys registered twice are published once, matching the registration
     * that validation resolves. Publishing both would let the picker offer
     * operators the save then rejects.
     *
     * Groups come back as a list rather than keyed by name, because a keyed
     * array encodes to a JSON object and the picker iterates an array.
     *
     * @return array
     */
    public static function onlySupportedKeys(): array
    {
        $published = [];
        $groups = [];

        foreach (static::all() as $group) {
            if (!is_array($group)) {
                continue;
            }

            $groups[] = array_intersect_key($group, array_flip(['label', 'value'])) + [
                    'children' => static::publishChildren(Arr::get($group, 'children', []), $published),
                ];
        }

        return $groups;
    }

    /**
     * A group's children as the admin app receives them, walking into any
     * group nested in it. $published holds the keys already published.
     *
     * @param mixed $children
     * @param array $published
     * @return array
     */
    protected static function publishChildren($children, array &$published): array
    {
        // data_key is on the list because a select attribute is unusable
        // without it — the picker would render a dropdown with nothing to ask
        // the server for.
        $publishableAttribute = ['label', 'value', 'input_type', 'operators', 'data_key', 'multiple'];
        $publishedChildren = [];

        if (!is_array($children)) {
            return $publishedChildren;
        }

        foreach ($children as $attribute) {
            if (!is_array($attribute)) {
                continue;
            }

            // A nested group goes out as a group, holding what it publishes.
            if (isset($attribute['children'])) {
                $nested = static::publishChildren($attribute['children'], $published);

                if ($nested) {
                    $publishedChildren[] = array_intersect_key($attribute, array_flip(['label', 'value'])) + [
                            'children' => $nested,
                        ];
                }

                continue;
            }

            $key = Arr::get($attribute, 'value');

            // Same first-registration-wins rule flattened() applies, and
            // in the same order — otherwise the picker could offer a
            // duplicate's operators that validation then rejects.
            if (!$key || isset($published[$key])) {
                continue;
            }

            $published[$key] = true;
            $publishedChildren[] = array_intersect_key($attribute, array_flip($publishableAttribute));
        }

        return $publishedChildren;
    }

    /**
     * A single attribute definition, or null when it is not registered.
     *
     * @param string $key
     * @return array|null
     */
    public static function get($key)
    {
        $attribute = Arr::get(static::flattened(), $key);

        return is_array($attribute) ? $attribute : null;
    }

    /**
     * @param string $key
     * @return bool
     */
    public static function has($key): bool
    {
        return static::get($key) !== null;
    }

    /**
     * Whether the operator is valid for that specific attribute. An operator
     * that is valid elsewhere is still rejected here — a text operator on a
     * number attribute is not a condition anyone can satisfy.
     *
     * @param string $key
     * @param string $operator
     * @return bool
     */
    public static function hasOperator($key, $operator): bool
    {
        $attribute = static::get($key);

        if (!$attribute) {
            return false;
        }

        $operators = Arr::get($attribute, 'operators', []);

        return is_array($operators) && array_key_exists($operator, $operators);
    }

    /**
     * The input type the admin UI should render for an attribute's value.
     *
     * @param string $key
     * @return string
     */
    public static function inputType($key): string
    {
        $attribute = static::get($key);

        return $attribute ? Arr::get($attribute, 'input_type', 'text') : 'text';
    }

    /**
     * Whether this attribute holds several values.
     *
     * Decides the stored shape as well as the picker's: a multiple attribute
     * saves a list, a single one saves the bare value. Storing a one-element
     * list either way would leave a single-value picker holding an array it
     * cannot match against its options, and the field would render empty.
     *
     * @param string $key
     * @return bool
     */
    public static function isMultiple($key): bool
    {
        $attribute = static::get($key);

        return $attribute ? Arr::get($attribute, 'multiple') === true : false;
    }
}
