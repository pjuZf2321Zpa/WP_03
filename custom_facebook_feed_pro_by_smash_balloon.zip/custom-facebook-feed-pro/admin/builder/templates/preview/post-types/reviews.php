<?php

if (! defined('ABSPATH')) {
	exit; // Exit if accessed directly.
}
?>
<script type="text/x-template" id="cff-post-reviewsposts-component">
	<cff-post-author-component :single-post="singlePost" :customizer-feed-data="customizerFeedData"></cff-post-author-component>
</script>
<cff-post-reviewsposts-component :customizer-feed-data="customizerFeedData"></cff-post-reviewsposts-component>