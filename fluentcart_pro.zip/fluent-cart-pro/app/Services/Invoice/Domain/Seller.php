<?php

declare(strict_types=1);

namespace FluentCartPro\App\Services\Invoice\Domain;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Seller DTO (Store settings + seller_details). Immutable.
 */
final class Seller
{
    public string $name;

    public string $address_line_1;

    public string $address_line_2;

    public string $city;

    public string $state;

    public string $zip;

    public string $country_code;

    /** Normalized VAT ID (country prefix + number) or null. */
    public ?string $vat_id;

    public string $legal_registration_id;

    public string $legal_registration_scheme;

    public ?string $electronic_address;

    /**
     * @param array<string, string> $data
     */
    public function __construct(array $data = [])
    {
        $this->name                      = (string) ($data['name'] ?? '');
        $this->address_line_1            = (string) ($data['address_line_1'] ?? '');
        $this->address_line_2            = (string) ($data['address_line_2'] ?? '');
        $this->city                      = (string) ($data['city'] ?? '');
        $this->state                     = (string) ($data['state'] ?? '');
        $this->zip                       = (string) ($data['zip'] ?? '');
        $this->country_code              = (string) ($data['country_code'] ?? '');
        $this->vat_id                    = isset($data['vat_id']) && $data['vat_id'] !== '' ? (string) $data['vat_id'] : null;
        $this->legal_registration_id     = (string) ($data['legal_registration_id'] ?? '');
        $this->legal_registration_scheme = (string) ($data['legal_registration_scheme'] ?? '');
        $this->electronic_address        = isset($data['electronic_address']) && $data['electronic_address'] !== '' ? (string) $data['electronic_address'] : null;
    }
}
