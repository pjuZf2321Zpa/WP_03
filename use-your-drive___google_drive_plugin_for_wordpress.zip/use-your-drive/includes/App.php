<?php
/**
 * @author WP Cloud Plugins
 * @copyright Copyright (c) 2023, WP Cloud Plugins
 *
 * @since       2.0
 * @see https://www.wpcloudplugins.com
 */

namespace TheLion\UseyourDrive;

defined('ABSPATH') || exit;

class App
{
    /**
     * The single instance of the class.
     *
     * @var App
     */
    protected static $_instance;

    /**
     * @var bool
     */
    private $_own_app = false;

    /**
     * @var string
     */
    private $_app_key;

    /**
     * @var string
     */
    private $_app_secret;

    /**
     * @var string
     */
    private $_app_token;

    /**
     * @var string
     */
    private $_authorization_state;

    /**
     * @var \UYDGoogle_Service_Oauth2
     */
    private $_user_info_service;

    /**
     * @var \UYDGoogle_Service_Drive
     */
    private $_google_drive_service;

    /**
     * @var \UYDGoogle_Client
     */
    private static $_sdk_client;

    /**
     * @var Account
     */
    private static $_current_account;

    /**
     * We don't save your data or share it.
     * It is used for an easy and one-click authorization process that will always work!
     *
     * @var string
     */
    private $_auth_url = 'https://www.wpcloudplugins.com/use-your-drive/index.php';

    public function __construct()
    {
        // Call back for refresh token function in SDK client
        add_action('use-your-drive-refresh-token', [$this, 'refresh_token'], 10, 1);

        if (!function_exists('useyourdrive_api_php_client_autoload')) {
            require_once USEYOURDRIVE_ROOTDIR.'/vendors/Google-sdk/src/Google/autoload.php';
        }

        if (!class_exists('UYDGoogle_Client') || (!method_exists('UYDGoogle_Client', 'getLibraryVersion'))) {
            $reflector = new \ReflectionClass('UYDGoogle_Client');
            $error = 'Conflict with other Google Library: '.$reflector->getFileName();

            throw new \Exception($error);
        }
    }

    /**
     * App Instance.
     *
     * Ensures only one instance is loaded or can be loaded.
     *
     * @return App - App instance
     *
     * @static
     */
    public static function instance()
    {
        if (is_null(self::$_instance)) {
            $app = new self();
        } else {
            $app = self::$_instance;
        }

        if (empty($app::$_sdk_client)) {
            try {
                $app->start_sdk_client(App::get_current_account());
            } catch (\Exception $ex) {
                self::$_instance = $app;

                return self::$_instance;
            }
        }

        self::$_instance = $app;

        if (null !== App::get_current_account()) {
            $app->get_sdk_client(App::get_current_account());
        }

        return self::$_instance;
    }

    public function process_authorization()
    {
        if (!empty($_GET['ver']) && isset($_GET['code'])) {
            Processor::reset_complete_cache();
            $this->create_access_token();
        }

        // Close oAuth popup and refresh plugin settings page. Only possible with inline javascript.
        echo '<script type="text/javascript">localStorage.setItem("wpcp_refreshParent", "true"); window.close();</script>';

        exit;
    }

    public function has_plugin_own_app()
    {
        return $this->_own_app;
    }

    public function get_auth_url()
    {
        $sdk_client = self::get_sdk_client();
        if (empty($this->_authorization_state)) {
            Helpers::log_error('Cannot create authorization URL without state data.', 'App', null, __LINE__);

            return false;
        }

        // Keep each pending authorization attempt isolated for the current user.
        $token = wp_generate_password(16, false, false);
        set_transient('useyourdrive_authorization_'.get_current_user_id().'_'.$token, true, 15 * MINUTE_IN_SECONDS);
        // Use a compact state parameter to avoid overly long authorization URLs.
        $sdk_client->setState(strtr(base64_encode($this->_authorization_state.'&t='.$token), '+/=', '-_~'));

        return $sdk_client->createAuthUrl();
    }

    /**
     * @return \UYDGoogle_Client
     */
    public function start_sdk_client(?Account $account = null)
    {
        try {
            self::$_sdk_client = new \UYDGoogle_Client();
            self::$_sdk_client->getLibraryVersion();
        } catch (\Exception $ex) {
            Helpers::log_error('Cannot start client', 'App', null, __LINE__, $ex);

            return $ex;
        }

        self::$_sdk_client->setApplicationName('WordPress Use-your-Drive '.USEYOURDRIVE_VERSION);
        self::$_sdk_client->setClientId($this->get_app_key());
        self::$_sdk_client->setClientSecret($this->get_app_secret());
        self::$_sdk_client->setRedirectUri($this->_auth_url);
        self::$_sdk_client->setApprovalPrompt('force');
        self::$_sdk_client->setAccessType('offline');
        self::$_sdk_client->setIncludeGrantedScopes(true);

        if (!empty($account)) {
            self::$_sdk_client->setLoginHint($account->get_email());
        }

        if (Core::is_network_authorized() || is_network_admin()) {
            $state = network_admin_url('admin.php?page=UseyourDrive_network_settings&action=useyourdrive_authorization');
        } else {
            $state = admin_url('admin.php?page=UseyourDrive_settings&action=useyourdrive_authorization');
        }

        $state .= '&license='.(string) License::get();
        $state .= '&siteurl='.License::get_home_url();

        $this->_authorization_state = $state;
        self::$_sdk_client->setState(strtr(base64_encode($state), '+/=', '-_~'));

        $this->set_logger();

        if (null === $account) {
            return self::$_sdk_client;
        }

        self::set_current_account($account);

        $authorization = $account->get_authorization();

        if (false === $authorization->has_access_token()) {
            return self::$_sdk_client;
        }

        $access_token = $authorization->get_access_token();

        if (empty($access_token)) {
            return self::$_sdk_client;
        }

        self::$_sdk_client->setAccessToken($access_token);

        // Check if the AccessToken is still valid
        if (false === self::$_sdk_client->isAccessTokenExpired()) {
            return self::$_sdk_client;
        }

        // If we end up here, we have to refresh the token
        return $this->refresh_token($account);
    }

    public function refresh_token(?Account $account = null)
    {
        if (null === $account) {
            Helpers::log_error('Cannot renew the Authorization Token without an account.', 'App', null, __LINE__);

            return false;
        }

        $authorization = $account->get_authorization();

        // Always release the lock, also when a PHP Error is thrown (e.g. in a long running WP-CLI process)
        try {
            return $this->renew_token($account, $authorization);
        } finally {
            $authorization->unlock_token_file();
        }
    }

    /**
     * @return false|\UYDGoogle_Client
     */
    private function renew_token(Account $account, Authorization $authorization)
    {
        // Pause renewing after a temporary error. Errors of the API apply to all sites in the network sharing the token,
        // connection errors can be caused by the server of a single site
        $backoff_transient = 'useyourdrive_refresh_backoff_'.$account->get_id();

        // Wait for an exclusive lock. The token file can be shared by multiple processes and sites in the network.
        // The lock of a process that dies is released automatically. Don't wait long, so PHP workers aren't blocked.
        $has_lock = $authorization->try_lock(2);

        if (false === $has_lock) {
            // Another process is renewing the token. Keep using the current token as long as it is actually valid
            $access_token = $authorization->read_access_token();

            if (!empty($access_token) && false !== strpos($access_token, 'access_token')) {
                self::$_sdk_client->setAccessToken($access_token);

                if (false === self::$_sdk_client->isAccessTokenExpired(10)) {
                    return self::$_sdk_client;
                }
            }

            // The token has expired. Wait longer for the other process, e.g. when the API responds slowly
            if (false === $authorization->try_lock(13)) {
                Helpers::log('Cannot get the lock to renew the Authorization Token, it is being renewed by another process.', 'App', ['account_id' => $account->get_id()], __LINE__);

                throw new \UYDGoogle_Auth_Exception('The Authorization Token is being renewed by another process.');
            }
        }

        // Another process may have renewed the token while this process was waiting for the lock.
        // Only the token file is used, never the token in memory as that can belong to another account.
        $access_token = $authorization->read_access_token();

        // A missing token file can be a short hiccup of the (network) file system. Check again before the authorization is marked as lost
        if (empty($access_token) && false === $authorization->has_token_file()) {
            usleep(200000);
            $access_token = $authorization->read_access_token();
        }

        if (empty($access_token) || false === strpos($access_token, 'access_token')) {
            // A token file that cannot be decrypted can be caused by a temporary problem, e.g. when the encryption key cannot be read
            if ($authorization->has_token_file()) {
                throw new \UYDGoogle_Auth_Exception('The Authorization Token cannot be read at the moment.');
            }

            Helpers::log_error('Cannot renew the Authorization Token as the token file is empty or missing.', 'App', ['account_id' => $account->get_id()], __LINE__);
            $this->set_authorization_lost($account, $this->get_lost_authorization_marker(''));

            return false;
        }

        self::$_sdk_client->setAccessToken($access_token);

        if (false === self::$_sdk_client->isAccessTokenExpired()) {
            Helpers::log('The Authorization Token has already been renewed by another process.', 'App', ['account_id' => $account->get_id()], __LINE__);

            return self::$_sdk_client;
        }

        // Without App credentials the token can't be renewed. This isn't a problem of the authorization itself.
        // The credentials are set per site, so this must not pause the renewal for the other sites in the network
        if (empty($this->get_app_key()) || empty($this->get_app_secret())) {
            Helpers::log_error('Cannot renew the Authorization Token as the App credentials are missing. Please sync the license via the plugin settings.', 'App', null, __LINE__);

            throw new \UYDGoogle_Auth_Exception('Cannot renew the Authorization Token as the App credentials are missing. Please sync the license via the plugin settings.');
        }

        // Stop if we need to get a new AccessToken but somehow ended up without a refreshtoken
        $refresh_token = self::$_sdk_client->getRefreshToken();

        if (empty($refresh_token)) {
            Helpers::log_error('No Refresh Token found during the renewing of the current token. The account needs to be authorized again.', 'App', ['account_id' => $account->get_id()], __LINE__);
            $this->set_authorization_lost($account, $this->get_lost_authorization_marker(''));

            return false;
        }

        // After a permanent error, don't try to renew with the same refresh token and App credentials on every request.
        // A new authorization (on any site in the network) or other App credentials will be tried again
        $lost_marker = $this->get_lost_authorization_marker($refresh_token);

        if ($lost_marker === get_transient('useyourdrive_authorization_lost_'.$account->get_id())) {
            throw new \UYDGoogle_Auth_Exception('The authorization is no longer valid. The account needs to be authorized again.', 401);
        }

        // Don't try to renew the token on every request after a temporary error
        if (false !== get_site_transient($backoff_transient) || false !== get_transient($backoff_transient)) {
            throw new \UYDGoogle_Auth_Exception('Renewing the Authorization Token is paused for a moment after a temporary error.');
        }

        // Refresh token
        try {
            Helpers::log('Renewing the Authorization Token.', 'App', ['account_id' => $account->get_id()], __LINE__);

            self::$_sdk_client->refreshToken($refresh_token);
            $new_accestoken = self::$_sdk_client->getAccessToken();

            // Don't overwrite a new authorization that has been stored while renewing, e.g. when locking doesn't work between servers
            $stored_access_token = $authorization->read_access_token();
            $stored_token = json_decode((string) $stored_access_token, true);

            if (is_array($stored_token) && !empty($stored_token['refresh_token']) && $stored_token['refresh_token'] !== $refresh_token) {
                Helpers::log_error('A new authorization has been stored while renewing the Authorization Token. The new authorization is used.', 'App', ['account_id' => $account->get_id()], __LINE__);
                self::$_sdk_client->setAccessToken($stored_access_token);
            } elseif (false === $authorization->set_access_token($new_accestoken)) {
                Helpers::log_error('The renewed Authorization Token cannot be stored. It is only used for the current request.', 'App', ['account_id' => $account->get_id()], __LINE__);
            } else {
                $new_token = json_decode((string) $new_accestoken, true);
                Helpers::log('Authorization Token renewed and stored.', 'App', [
                    'account_id' => $account->get_id(),
                    'expires_in' => $new_token['expires_in'] ?? null,
                    'refresh_token_rotated' => !empty($new_token['refresh_token']) && $new_token['refresh_token'] !== $refresh_token,
                ], __LINE__);
            }

            delete_transient('useyourdrive_authorization_lost_'.$account->get_id());

            if (false !== ($timestamp = wp_next_scheduled('useyourdrive_lost_authorisation_notification', ['account_id' => $account->get_id()]))) {
                wp_unschedule_event($timestamp, 'useyourdrive_lost_authorisation_notification', ['account_id' => $account->get_id()]);
                Helpers::log('Lost authorization notification unscheduled, as the Authorization Token has been renewed.', 'App', ['account_id' => $account->get_id()], __LINE__);
            }
        } catch (\Exception $ex) {
            // Temporary problems (timeouts, rate limits, server errors) don't mean that the authorization is lost
            if (false === self::is_authorization_error($ex)) {
                if ($ex instanceof \UYDGoogle_IO_Exception) {
                    set_transient($backoff_transient, true, MINUTE_IN_SECONDS);
                } else {
                    set_site_transient($backoff_transient, true, MINUTE_IN_SECONDS);
                }
                Helpers::log_error('Cannot refresh Authorization Token due to a temporary error. The authorization is kept.', 'App', null, __LINE__, $ex);

                throw $ex;
            }

            Helpers::log_error('Cannot refresh Authorization Token.', 'App', null, __LINE__, $ex);
            $this->set_authorization_lost($account, $lost_marker);

            throw $ex;
        }

        return self::$_sdk_client;
    }

    /**
     * The marker identifies the refresh token and App credentials that can no longer be used.
     * Only hashes are stored.
     *
     * @param string $refresh_token
     *
     * @return array
     */
    private function get_lost_authorization_marker($refresh_token)
    {
        return [
            'refresh_token' => empty($refresh_token) ? '' : hash('sha256', $refresh_token),
            'app' => hash('sha256', $this->get_app_key().'|'.$this->get_app_secret()),
        ];
    }

    /**
     * Mark the authorization of an account as lost and notify the administrators.
     *
     * @param array $lost_marker see get_lost_authorization_marker()
     */
    private function set_authorization_lost(Account $account, array $lost_marker)
    {
        $account->get_authorization()->set_is_valid(false);

        // Stored per site, as the App credentials can differ per site
        set_transient('useyourdrive_authorization_lost_'.$account->get_id(), $lost_marker, MONTH_IN_SECONDS);

        Helpers::log('Authorization marked as lost.', 'App', ['account_id' => $account->get_id(), 'has_refresh_token' => !empty($lost_marker['refresh_token'])], __LINE__);

        // Only when the authorization has just been lost. The cache folder is shared by all sites in the network
        if (!wp_next_scheduled('useyourdrive_lost_authorisation_notification', ['account_id' => $account->get_id()])) {
            $is_scheduled = wp_schedule_event(time(), 'daily', 'useyourdrive_lost_authorisation_notification', ['account_id' => $account->get_id()]);

            if (false !== $is_scheduled && !is_wp_error($is_scheduled)) {
                Helpers::log('Lost authorization notification scheduled (daily).', 'App', ['account_id' => $account->get_id()], __LINE__);
            } else {
                Helpers::log_error('Cannot schedule the lost authorization notification.', 'App', ['account_id' => $account->get_id()], __LINE__);
            }

            Processor::reset_complete_cache();
        }
    }

    /**
     * Check if an exception means that the authorization itself is no longer valid,
     * e.g. a revoked or expired refresh token, or invalid app credentials.
     *
     * @return bool
     */
    public static function is_authorization_error(\Exception $ex)
    {
        if ($ex instanceof \UYDGoogle_Auth_Exception) {
            // 401 is used for invalid App credentials, and when the token can no longer be renewed (see UYDGoogle_Auth_OAuth2::sign())
            if (401 === (int) $ex->getCode()) {
                return true;
            }

            // 400 is also used for malformed requests, so check for the errors that mean the grant is gone
            return 400 === (int) $ex->getCode()
                && 1 === preg_match('/invalid_grant|invalid_client|unauthorized_client|deleted_client/', $ex->getMessage());
        }

        if ($ex instanceof \UYDGoogle_Service_Exception) {
            if (401 === (int) $ex->getCode()) {
                return true;
            }

            // 403 is also used for rate limits and missing file permissions. Only these reasons require an action of the administrator:
            // the Drive API isn't enabled for the App, or the authorization misses the required scopes
            if (403 === (int) $ex->getCode()) {
                foreach ((array) $ex->getErrors() as $error) {
                    if (in_array($error['reason'] ?? '', ['accessNotConfigured', 'insufficientPermissions'], true)) {
                        return true;
                    }
                }
            }
        }

        return false;
    }

    /**
     * Check if the authorization of an account has been restored after a failed renewal.
     * A failed renewal never writes the token file, so a token that isn't expired
     * has been renewed by another process or site, or the account has been authorized again.
     *
     * @return bool
     */
    public static function is_authorization_restored(Account $account)
    {
        $access_token = $account->get_authorization()->get_access_token();

        if (empty($access_token)) {
            return false;
        }

        $token = json_decode($access_token, true);

        if (!is_array($token) || empty($token['access_token']) || !isset($token['created'], $token['expires_in'])) {
            return false;
        }

        // Use the same margin as UYDGoogle_Auth_OAuth2::isAccessTokenExpired()
        if (($token['created'] + $token['expires_in'] - 120) > time()) {
            return true;
        }

        // A new authorization (e.g. on another site in the network) has stored another refresh token after the authorization was lost on this site
        $lost_marker = get_transient('useyourdrive_authorization_lost_'.$account->get_id());

        return is_array($lost_marker)
            && !empty($token['refresh_token'])
            && hash('sha256', $token['refresh_token']) !== ($lost_marker['refresh_token'] ?? '');
    }

    public function set_logger()
    {
        $log_file = USEYOURDRIVE_CACHEDIR.'/api.log';
        if ('Yes' === Settings::get('api_log')) {
            // Logger
            self::get_sdk_client()->setClassConfig('UYDGoogle_Logger_File', [
                'file' => $log_file,
                'mode' => 0640,
                'lock' => true, ]);

            self::get_sdk_client()->setClassConfig('UYDGoogle_Logger_Abstract', [
                'level' => 'debug', // 'warning' or 'debug'
                'log_format' => "[%datetime%] %level%: %message% %context%\n",
                'date_format' => 'd/M/Y:H:i:s O',
                'allow_newlines' => true, ]);

            self::get_sdk_client()->setLogger(new \UYDGoogle_Logger_File(self::get_sdk_client()));

            // Delete log file if it exceeds 100MB or is older than 1 week
            if (\file_exists($log_file)) {
                $file_size = \filesize($log_file);
                $file_age = time() - filemtime($log_file);

                if ($file_size > 100 * 1024 * 1024 || $file_age > 7 * 24 * 60 * 60) {
                    unlink($log_file);
                }
            }
        }
    }

    public static function download_api_log()
    {
        if (!file_exists(USEYOURDRIVE_CACHEDIR.'/api.log')) {
            exit;
        }

        $filename = date('Y-m-d-h-i').' - Google Drive API.log';

        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; '.sprintf('filename="%s"; ', rawurlencode($filename)).sprintf("filename*=utf-8''%s", rawurlencode($filename)));

        readfile(USEYOURDRIVE_CACHEDIR.'/api.log');

        exit;
    }

    public function create_access_token()
    {
        try {
            $code = sanitize_text_field($_REQUEST['code']);
            $scopes = sanitize_text_field($_REQUEST['scope']);

            $scopes = array_filter(explode(' ', $scopes), function ($url) {
                return filter_var($url, FILTER_VALIDATE_URL);
            });

            Helpers::log('Authorization code received. Requesting Access Token.', 'App', ['scopes' => array_values($scopes)], __LINE__);

            // Fetch the Access Token
            $access_token = self::get_sdk_client()->authenticate($code);

            // Get & Update User Information
            $account_data = $this->get_user()->userinfo->get();
            $account = new Account($account_data->getId(), $account_data->getName(), $account_data->getEmail(), $account_data->getPicture());
            $account->set_scopes($scopes);
            if (false === $account->get_authorization()->set_access_token($access_token)) {
                throw new \Exception('The authorization cannot be stored. Please check if the cache folder is writable.');
            }
            $account->get_authorization()->unlock_token_file();

            $token = json_decode((string) $access_token, true);
            Helpers::log('Access Token received and stored for account.', 'App', [
                'account_id' => $account->get_id(),
                'has_refresh_token' => !empty($token['refresh_token']),
                'expires_in' => $token['expires_in'] ?? null,
            ], __LINE__);

            Accounts::instance()->add_account($account);

            delete_transient('useyourdrive_'.$account->get_id().'_is_authorized');
            delete_site_transient('useyourdrive_refresh_backoff_'.$account->get_id());
            delete_transient('useyourdrive_refresh_backoff_'.$account->get_id());
            delete_transient('useyourdrive_authorization_lost_'.$account->get_id());
        } catch (\Exception $ex) {
            Helpers::log_error('Cannot generate Access Token.', 'App', null, __LINE__, $ex);

            return new \WP_Error('broke', esc_html__('Error communicating with API:', 'wpcloudplugins').$ex->getMessage());
        }

        Processor::reset_complete_cache();

        return true;
    }

    /**
     * @param null|bool $is_used_by_other_sites set to true when the authorization isn't revoked at Google, because other sites in the network still use the account
     *
     * @return bool
     */
    public function revoke_token(Account $account, &$is_used_by_other_sites = null)
    {
        Helpers::log_error('Authorization for account revoked.', 'App', ['account_id' => $account->get_id(), 'account_email' => $account->get_email()], __LINE__);

        // Reset Personal Folders Back-End if the account it is pointing to is deleted
        $personal_folders_data = Settings::get('userfolder_backend_auto_root', []);
        if (is_array($personal_folders_data) && isset($personal_folders_data['account']) && $personal_folders_data['account'] === $account->get_id()) {
            Settings::save('userfolder_backend_auto_root', []);
        }

        Processor::reset_complete_cache();

        if (false !== ($timestamp = wp_next_scheduled('useyourdrive_lost_authorisation_notification', ['account_id' => $account->get_id()]))) {
            wp_unschedule_event($timestamp, 'useyourdrive_lost_authorisation_notification', ['account_id' => $account->get_id()]);
            Helpers::log('Lost authorization notification unscheduled, as the account is removed.', 'App', ['account_id' => $account->get_id()], __LINE__);
        }

        Core::instance()->send_lost_authorisation_notification($account->get_id(), true);

        // Revoking the token at Google would disconnect all other sites in the network using this account
        $is_used_by_other_sites = Accounts::is_account_used_by_other_sites($account->get_id());

        if ($is_used_by_other_sites) {
            Helpers::log_error('Authorization is not revoked at Google as the account is still used by other sites in the network. The account is only removed from this site.', 'App', ['account_id' => $account->get_id(), 'account_email' => $account->get_email()], __LINE__);
        } else {
            // Revoke the token of this account itself. The client can still contain the token of another account
            $token = json_decode((string) $account->get_authorization()->get_access_token(), true);
            $token_to_revoke = $token['refresh_token'] ?? ($token['access_token'] ?? null);

            if (empty($token_to_revoke)) {
                Helpers::log_error('Authorization for account cannot be revoked at Google as the token file is empty or cannot be read. Revoke the access via the Google Account if needed.', 'App', ['account_id' => $account->get_id(), 'account_email' => $account->get_email()], __LINE__);
            } else {
                try {
                    if (false === self::get_sdk_client()->revokeToken($token_to_revoke)) {
                        Helpers::log_error('Authorization for account cannot be revoked at Google. Revoke the access via the Google Account if needed.', 'App', ['account_id' => $account->get_id(), 'account_email' => $account->get_email()], __LINE__);
                    }
                } catch (\Exception $ex) {
                    Helpers::log_error('Authorization for account cannot be revoked.', 'App', ['account_id' => $account->get_id(), 'account_email' => $account->get_email()], __LINE__, $ex);
                }
            }
        }

        Accounts::instance()->remove_account($account->get_id(), $is_used_by_other_sites);

        delete_transient('useyourdrive_'.$account->get_id().'_is_authorized');

        return true;
    }

    public function get_app_key()
    {
        if (empty($this->_app_key)) {
            $license = License::get_stored_license_data();
            $this->_app_key = $license['appdata']['key'] ?? null;
            $this->_app_token = $license['appdata']['token'] ?? null;

            if (!empty($own_key = Settings::get('googledrive_app_client_id'))) {
                $this->_app_key = $own_key;
                $this->_own_app = true;
            }
        }

        return $this->_app_key;
    }

    public function get_app_secret()
    {
        if (empty($this->_app_secret)) {
            $license = License::get_stored_license_data();
            $this->_app_secret = $license['appdata']['secret'] ?? null;

            if (!empty($own_secret = Settings::get('googledrive_app_client_secret'))) {
                $this->_app_secret = $own_secret;
                $this->_own_app = true;
            }
        }

        return $this->_app_secret;
    }

    /**
     * @param null|Account $account
     *
     * @return \UYDGoogle_Client
     */
    public static function get_sdk_client($account = null)
    {
        if (empty(self::$_sdk_client)) {
            self::$_sdk_client = self::instance()->start_sdk_client();
        }

        if (!empty($account)) {
            self::set_current_account($account);
        }

        return self::$_sdk_client;
    }

    /**
     * @return \UYDGoogle_Service_Oauth2
     */
    public function get_user()
    {
        if (empty($this->_user_info_service)) {
            $client = self::get_sdk_client();
            $this->_user_info_service = new \UYDGoogle_Service_Oauth2($client);
        }

        return $this->_user_info_service;
    }

    /**
     * @return \UYDGoogle_Service_Drive
     */
    public function get_drive()
    {
        if (empty($this->_google_drive_service)) {
            $client = self::get_sdk_client();
            $this->_google_drive_service = new \UYDGoogle_Service_Drive($client);
        }

        return $this->_google_drive_service;
    }

    /**
     * @return Account
     */
    public static function get_current_account()
    {
        if (empty(self::$_current_account) && null !== Processor::instance()->get_shortcode()) {
            $account = Accounts::instance()->get_account_by_id(Processor::instance()->get_shortcode_option('account'));
            if (!empty($account)) {
                self::set_current_account($account);
            }
        }

        return self::$_current_account;
    }

    public static function set_current_account(Account $account)
    {
        if (self::$_current_account !== $account) {
            self::$_current_account = $account;
            Cache::instance_unload();

            if (empty(self::$_sdk_client)) {
                self::instance();
            }

            $scopes = $account->get_scopes();
            self::$_sdk_client->setScopes($scopes);

            if ($account->get_authorization()->has_access_token()) {
                self::$_sdk_client->setAccessToken($account->get_authorization()->get_access_token());
            } else {
                // Never keep using the token of the previous account
                self::$_sdk_client->clearAccessToken();
            }
        }

        return self::$_current_account;
    }

    public static function set_current_account_by_id(string $account_id)
    {
        $account = Accounts::instance()->get_account_by_id($account_id);

        if (empty($account)) {
            Helpers::log_error('Cannot use the requested account as it is not linked with the plugin. Plugin falls back to primary account.', 'App', ['account_id' => $account_id], __LINE__);

            $account = Accounts::instance()->get_primary_account();

            if (empty($account)) {
                self::$_current_account = null;

                // Never keep using the token of the previous account
                if (!empty(self::$_sdk_client)) {
                    self::$_sdk_client->clearAccessToken();
                }

                return self::$_current_account;
            }
        }

        return self::set_current_account($account);
    }

    public static function clear_current_account()
    {
        self::$_current_account = null;
        Cache::instance_unload();
    }

    public function get_auth_uri()
    {
        return $this->_auth_url;
    }
}
