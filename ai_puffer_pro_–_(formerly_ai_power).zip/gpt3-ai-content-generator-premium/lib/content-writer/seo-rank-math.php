<?php

namespace WPAICG\ContentWriter\SEO;

if (!defined('ABSPATH')) {
    exit;
}

/** Shared rule checks and focus-keyphrase context for Rank Math title and content policies. */
trait AIPKit_Content_Writer_SEO_Rank_Math_Context_Trait
{
    private static function rule_enabled(array $context, string $rule_id): bool
    {
        return !class_exists(AIPKit_Content_Writer_SEO_Config::class)
            || AIPKit_Content_Writer_SEO_Config::is_rule_enabled($context, $rule_id);
    }

    private static function focus_keyphrase(array $draft): string
    {
        $focus_keyphrase = trim((string) ($draft['focus_keyword'] ?? ''));
        if ($focus_keyphrase === '') {
            return '';
        }

        $parts = array_map('trim', explode(',', $focus_keyphrase));
        return sanitize_text_field((string) ($parts[0] ?? $focus_keyphrase));
    }

    private static function normalized_text(string $text): string
    {
        $text = function_exists('remove_accents') ? remove_accents($text) : $text;
        $text = function_exists('mb_strtolower') ? mb_strtolower($text, 'UTF-8') : strtolower($text);
        return preg_replace('/\s+/u', ' ', trim((string) $text));
    }
}

/**
 * Keeps SEO-plugin-sensitive title/keyphrase checks deterministic.
 */
class AIPKit_Content_Writer_Smart_SEO_Title_Helper
{
    use AIPKit_Content_Writer_SEO_Rank_Math_Context_Trait;

    public static function maybe_align_title(array $draft, array $context = []): array
    {
        if (sanitize_key((string) ($context['profile'] ?? '')) !== 'rank_math') {
            return $draft;
        }

        $title_start_enabled = self::rule_enabled($context, 'rank_math_title_start_with_keyword');
        $title_contains_enabled = self::rule_enabled($context, 'focus_keyword_in_title');
        if (!$title_start_enabled && !$title_contains_enabled) {
            return $draft;
        }

        $title = isset($draft['title']) ? sanitize_text_field((string) $draft['title']) : '';
        $focus_keyphrase = self::focus_keyphrase($draft);
        if ($title === '' || $focus_keyphrase === '') {
            return $draft;
        }

        if (self::starts_with_exact_phrase($title, $focus_keyphrase)) {
            $deduped_title = self::dedupe_exact_started_title($title, $focus_keyphrase);
            if ($deduped_title !== '' && self::normalized_text($deduped_title) !== self::normalized_text($title)) {
                $draft['title'] = $deduped_title;
            }
            return $draft;
        }

        if (!$title_start_enabled) {
            if (!self::contains_exact_phrase($title, $focus_keyphrase)) {
                $included_title = self::build_including_title($title, $focus_keyphrase);
                if ($included_title !== '' && self::normalized_text($included_title) !== self::normalized_text($title)) {
                    $draft['title'] = $included_title;
                }
            }
            return $draft;
        }

        $aligned_title = self::build_aligned_title($title, $focus_keyphrase);
        if ($aligned_title === '' || self::normalized_text($aligned_title) === self::normalized_text($title)) {
            return $draft;
        }

        $draft['title'] = $aligned_title;
        return $draft;
    }

    private static function build_including_title(string $title, string $focus_keyphrase): string
    {
        $title = self::normalize_title($title);
        $focus_keyphrase = self::normalize_title($focus_keyphrase);
        if ($focus_keyphrase === '') {
            return $title;
        }
        if ($title === '') {
            return $focus_keyphrase;
        }

        return self::normalize_title($title . ': ' . $focus_keyphrase);
    }

    private static function build_aligned_title(string $title, string $focus_keyphrase): string
    {
        $suffix = self::suffix_after_interleaved_keyphrase($title, $focus_keyphrase);
        if ($suffix === null) {
            $suffix = self::suffix_after_shared_leading_prefix($title, $focus_keyphrase);
        }
        if ($suffix === null) {
            $suffix = self::title_without_exact_phrase($title, $focus_keyphrase);
        }

        $suffix = trim((string) $suffix);
        if ($suffix === '') {
            return self::normalize_title($focus_keyphrase);
        }

        $suffix = preg_replace('/^\s*[-|,;]\s*/u', '', $suffix);
        $suffix = trim((string) $suffix);
        if ($suffix === '') {
            return self::normalize_title($focus_keyphrase);
        }

        if (preg_match('/^[:?!]/u', $suffix)) {
            return self::normalize_title($focus_keyphrase . $suffix);
        }

        return self::normalize_title($focus_keyphrase . ': ' . $suffix);
    }

    private static function dedupe_exact_started_title(string $title, string $focus_keyphrase): string
    {
        $suffix = self::title_without_exact_phrase($title, $focus_keyphrase);
        $suffix = preg_replace('/^\s*[-|,;:]\s*/u', '', $suffix);
        $suffix = trim((string) $suffix);
        if ($suffix === '' || self::suffix_after_shared_leading_prefix($suffix, $focus_keyphrase) === null) {
            return $title;
        }

        return self::build_aligned_title($suffix, $focus_keyphrase);
    }

    private static function suffix_after_interleaved_keyphrase(string $title, string $focus_keyphrase): ?string
    {
        $title_words = self::words_with_offsets($title);
        $keyword_words = self::word_values($focus_keyphrase);
        if (empty($title_words) || empty($keyword_words)) {
            return null;
        }

        $keyword_index = 0;
        $last_match = null;
        foreach ($title_words as $position => $word) {
            if ($position > 10 || $keyword_index >= count($keyword_words)) {
                break;
            }

            if (self::normalized_text((string) ($word['word'] ?? '')) !== $keyword_words[$keyword_index]) {
                continue;
            }

            $last_match = $word;
            $keyword_index++;
        }

        if ($keyword_index < count($keyword_words) || !is_array($last_match)) {
            return null;
        }

        $first_title_word = self::normalized_text((string) ($title_words[0]['word'] ?? ''));
        if ($first_title_word !== $keyword_words[0]) {
            return null;
        }

        $end = (int) ($last_match['offset'] ?? 0) + strlen((string) ($last_match['word'] ?? ''));
        return (string) substr($title, $end);
    }

    private static function suffix_after_shared_leading_prefix(string $title, string $focus_keyphrase): ?string
    {
        $title_words = self::words_with_offsets($title);
        $keyword_words = self::word_values($focus_keyphrase);
        if (count($title_words) < 2 || count($keyword_words) < 2) {
            return null;
        }

        $shared_count = 0;
        foreach ($title_words as $index => $word) {
            if ($index >= count($keyword_words)) {
                break;
            }

            if (self::normalized_text((string) ($word['word'] ?? '')) !== $keyword_words[$index]) {
                break;
            }

            $shared_count++;
        }

        if ($shared_count < 2) {
            return null;
        }

        $last_shared_word = $title_words[$shared_count - 1] ?? null;
        if (!is_array($last_shared_word)) {
            return null;
        }

        $end = (int) ($last_shared_word['offset'] ?? 0) + strlen((string) ($last_shared_word['word'] ?? ''));
        return (string) substr($title, $end);
    }

    private static function title_without_exact_phrase(string $title, string $focus_keyphrase): string
    {
        $without_phrase = preg_replace('/' . preg_quote($focus_keyphrase, '/') . '/iu', ' ', $title, 1);
        if (!is_string($without_phrase) || self::normalized_text($without_phrase) === self::normalized_text($title)) {
            return $title;
        }

        return $without_phrase;
    }

    private static function contains_exact_phrase(string $title, string $focus_keyphrase): bool
    {
        $title = self::normalized_text(wp_strip_all_tags($title));
        $focus_keyphrase = self::normalized_text($focus_keyphrase);
        if ($title === '' || $focus_keyphrase === '') {
            return false;
        }

        return preg_match('/(?<![\p{L}\p{N}])' . preg_quote($focus_keyphrase, '/') . '(?![\p{L}\p{N}])/u', $title) === 1;
    }

    private static function starts_with_exact_phrase(string $title, string $focus_keyphrase): bool
    {
        $title = ltrim(self::normalized_text(wp_strip_all_tags($title)), " \t\n\r\0\x0B\"'“”‘’([{");
        $focus_keyphrase = self::normalized_text($focus_keyphrase);
        if ($title === '' || $focus_keyphrase === '') {
            return false;
        }

        return $title === $focus_keyphrase
            || preg_match('/^' . preg_quote($focus_keyphrase, '/') . '(?=$|[^\p{L}\p{N}])/u', $title) === 1;
    }

    /**
     * @return array<int, array{word:string,offset:int}>
     */
    private static function words_with_offsets(string $text): array
    {
        if (!preg_match_all('/[\p{L}\p{N}][\p{L}\p{N}\'’-]*/u', $text, $matches, PREG_OFFSET_CAPTURE)) {
            return [];
        }

        $words = [];
        foreach ($matches[0] as $match) {
            $words[] = [
                'word' => (string) ($match[0] ?? ''),
                'offset' => (int) ($match[1] ?? 0),
            ];
        }

        return $words;
    }

    /**
     * @return array<int, string>
     */
    private static function word_values(string $text): array
    {
        $words = self::words_with_offsets($text);
        return array_values(array_filter(array_map(
            static fn(array $word): string => self::normalized_text((string) ($word['word'] ?? '')),
            $words
        )));
    }

    private static function normalize_title(string $title): string
    {
        $title = html_entity_decode(wp_strip_all_tags($title), ENT_QUOTES | ENT_HTML5, get_bloginfo('charset') ?: 'UTF-8');
        $title = preg_replace('/\s+/u', ' ', (string) $title);
        $title = preg_replace('/\s+([:?!])/u', '$1', (string) $title);
        $title = preg_replace('/([:?!])(?=\S)/u', '$1 ', (string) $title);

        return sanitize_text_field(trim((string) $title));
    }

}

/**
 * Keeps Rank Math keyphrase checks aligned when Smart SEO resolves a new keyphrase.
 */
class AIPKit_Content_Writer_Smart_SEO_Keyphrase_Content_Helper
{
    use AIPKit_Content_Writer_SEO_Rank_Math_Context_Trait;

    private const RANK_MATH_MAX_PERMALINK_LENGTH = 75;

    public static function maybe_align_draft(array $draft, array $context = []): array
    {
        if (sanitize_key((string) ($context['profile'] ?? '')) !== 'rank_math') {
            return $draft;
        }

        $focus_keyphrase = self::focus_keyphrase($draft);
        if ($focus_keyphrase === '') {
            return $draft;
        }

        $content_rules_enabled = self::any_rule_enabled($context, [
            'focus_keyword_in_introduction',
            'focus_keyword_in_heading',
            'rank_math_keyword_density',
        ]);
        $meta_rules_enabled = self::rule_enabled($context, 'focus_keyword_in_meta_description');
        $slug_rules_enabled = self::any_rule_enabled($context, [
            'focus_keyword_in_slug',
            'rank_math_permalink_length',
        ]);
        $focus_slug_enabled = self::rule_enabled($context, 'focus_keyword_in_slug');
        $permalink_length_enabled = self::rule_enabled($context, 'rank_math_permalink_length');

        $display_keyphrase = self::display_keyphrase($focus_keyphrase, (string) ($draft['title'] ?? ''));
        $content = isset($draft['content_html']) && trim((string) $draft['content_html']) !== ''
            ? (string) $draft['content_html']
            : (string) ($draft['content'] ?? '');
        if ($content !== '' && $content_rules_enabled) {
            $content = self::align_content_keyphrase($content, $focus_keyphrase, $display_keyphrase);
            $draft['content_html'] = $content;
            $draft['content'] = $content;
        }

        if ($meta_rules_enabled && !self::contains_phrase((string) ($draft['meta_description'] ?? ''), $focus_keyphrase)) {
            $draft['meta_description'] = self::align_short_text((string) ($draft['meta_description'] ?? ''), $focus_keyphrase, $display_keyphrase, 160);
        }

        if ($slug_rules_enabled) {
            $slug = isset($draft['slug']) ? sanitize_title((string) $draft['slug']) : '';
            $focus_slug = sanitize_title($focus_keyphrase);
            if ($focus_slug_enabled && $focus_slug !== '' && ($slug === '' || strpos($slug, $focus_slug) === false)) {
                $slug = $focus_slug;
            }
            $draft['slug'] = $permalink_length_enabled
                ? self::build_rank_math_slug($slug, $focus_slug_enabled ? $focus_keyphrase : '', (string) ($draft['title'] ?? ''))
                : $slug;
        }

        return $draft;
    }

    private static function any_rule_enabled(array $context, array $rule_ids): bool
    {
        foreach ($rule_ids as $rule_id) {
            if (self::rule_enabled($context, (string) $rule_id)) {
                return true;
            }
        }

        return false;
    }

    public static function build_rank_math_slug(string $slug = '', string $focus_keyphrase = '', string $title = ''): string
    {
        $slug = sanitize_title($slug);
        $focus_slug = sanitize_title($focus_keyphrase);
        $title_slug = sanitize_title($title);

        if ($slug === '') {
            $slug = $focus_slug !== '' ? $focus_slug : $title_slug;
        }
        if ($slug === '') {
            return '';
        }

        if (self::permalink_length($slug) <= self::RANK_MATH_MAX_PERMALINK_LENGTH) {
            return $slug;
        }

        if ($focus_slug !== '' && self::permalink_length($focus_slug) <= self::RANK_MATH_MAX_PERMALINK_LENGTH) {
            return $focus_slug;
        }

        $source_slug = $focus_slug !== '' ? $focus_slug : $slug;
        $short_slug = self::trim_slug_to_permalink_budget($source_slug);
        if ($short_slug !== '') {
            return $short_slug;
        }

        return self::trim_slug_to_permalink_budget($slug);
    }

    private static function align_content_keyphrase(string $content, string $focus_keyphrase, string $display_keyphrase): string
    {
        if (!self::contains_phrase($content, $focus_keyphrase)) {
            $shared_prefix = self::longest_existing_keyphrase_prefix($content, $focus_keyphrase);
            if ($shared_prefix !== '') {
                $word_count = max(1, self::word_count($content));
                $target_replacements = max(2, min(5, (int) ceil($word_count / 180)));
                $content = self::replace_phrase_outside_links($content, $shared_prefix, $focus_keyphrase, $target_replacements);
            }
        }

        return self::fix_visible_keyphrase_start_casing($content, $focus_keyphrase, $display_keyphrase);
    }

    private static function align_short_text(string $text, string $focus_keyphrase, string $display_keyphrase, int $max_length): string
    {
        $text = trim((string) preg_replace('/\s+/u', ' ', wp_strip_all_tags($text)));
        if ($text === '') {
            return $text;
        }

        $shared_prefix = self::longest_existing_keyphrase_prefix($text, $focus_keyphrase);
        if ($shared_prefix === '') {
            return $text;
        }

        $aligned = self::replace_phrase_outside_links($text, $shared_prefix, $focus_keyphrase, 1);
        $aligned = self::fix_plain_text_keyphrase_start_casing($aligned, $focus_keyphrase, $display_keyphrase);
        $aligned = trim((string) preg_replace('/\s+/u', ' ', wp_strip_all_tags($aligned)));
        if (self::text_length($aligned) > $max_length) {
            $aligned = self::trim_to_length($aligned, $max_length);
        }

        return $aligned;
    }

    private static function replace_phrase_outside_links(string $text, string $search_phrase, string $replacement_phrase, int $limit): string
    {
        if ($limit <= 0 || $search_phrase === '' || $replacement_phrase === '') {
            return $text;
        }

        $protected = [];
        $placeholder_prefix = '%%AIPKIT_SMART_SEO_PROTECTED_';
        $protected_text = preg_replace_callback('/<a\b[^>]*>.*?<\/a>|<img\b[^>]*>/is', static function (array $match) use (&$protected, $placeholder_prefix): string {
            $placeholder = $placeholder_prefix . count($protected) . '%%';
            $protected[$placeholder] = (string) ($match[0] ?? '');
            return $placeholder;
        }, $text);
        $protected_text = is_string($protected_text) ? $protected_text : $text;

        $pattern = self::phrase_pattern($search_phrase);
        if ($pattern === '') {
            return $text;
        }

        $replaced = preg_replace($pattern, $replacement_phrase, $protected_text, $limit);
        $replaced = is_string($replaced) ? $replaced : $protected_text;

        if (!empty($protected)) {
            $replaced = strtr($replaced, $protected);
        }

        return $replaced;
    }

    private static function fix_visible_keyphrase_start_casing(string $content, string $focus_keyphrase, string $display_keyphrase): string
    {
        if ($focus_keyphrase === '' || $display_keyphrase === '' || trim($focus_keyphrase) === trim($display_keyphrase)) {
            return $content;
        }

        $phrase_body = self::phrase_pattern_body($focus_keyphrase);
        if ($phrase_body === '') {
            return $content;
        }

        $block_pattern = '/(<(?:p|h[1-6]|li|td|th|blockquote)\b[^>]*>\s*(?:<(?!\/(?:p|h[1-6]|li|td|th|blockquote)\b)[^>]+>\s*)*)' . $phrase_body . '/iu';
        $content = preg_replace_callback($block_pattern, static function (array $match) use ($display_keyphrase): string {
            return (string) ($match[1] ?? '') . $display_keyphrase;
        }, $content);
        $content = is_string($content) ? $content : '';

        if (!preg_match('/<\s*(p|h[1-6]|li|td|th|blockquote)\b/i', $content)) {
            return self::fix_plain_text_keyphrase_start_casing($content, $focus_keyphrase, $display_keyphrase);
        }

        return $content;
    }

    private static function fix_plain_text_keyphrase_start_casing(string $text, string $focus_keyphrase, string $display_keyphrase): string
    {
        if ($focus_keyphrase === '' || $display_keyphrase === '' || trim($focus_keyphrase) === trim($display_keyphrase)) {
            return $text;
        }

        $phrase_body = self::phrase_pattern_body($focus_keyphrase);
        if ($phrase_body === '') {
            return $text;
        }

        $text = preg_replace_callback('/(^\s*)' . $phrase_body . '/iu', static function (array $match) use ($display_keyphrase): string {
            return (string) ($match[1] ?? '') . $display_keyphrase;
        }, $text, 1);
        return is_string($text) ? $text : '';
    }

    private static function longest_existing_keyphrase_prefix(string $text, string $focus_keyphrase): string
    {
        $words = self::words($focus_keyphrase);
        if (count($words) < 2) {
            return '';
        }

        for ($length = min(count($words) - 1, 4); $length >= 2; $length--) {
            $candidate = implode(' ', array_slice($words, 0, $length));
            if (self::contains_phrase($text, $candidate)) {
                return $candidate;
            }
        }

        return '';
    }

    private static function display_keyphrase(string $focus_keyphrase, string $title): string
    {
        $focus_words = self::words($focus_keyphrase);
        if (!empty($focus_words) && $title !== '') {
            $title_words = self::words($title);
            $candidate = implode(' ', array_slice($title_words, 0, count($focus_words)));
            if (self::normalized_text($candidate) === self::normalized_text($focus_keyphrase)) {
                return $candidate;
            }
        }

        return self::uppercase_first_letter($focus_keyphrase);
    }

    private static function contains_phrase(string $text, string $phrase): bool
    {
        $pattern = self::phrase_pattern($phrase);
        if ($pattern === '') {
            return false;
        }

        return preg_match($pattern, wp_strip_all_tags($text)) === 1;
    }

    private static function phrase_pattern(string $phrase): string
    {
        $phrase = trim((string) preg_replace('/\s+/u', ' ', wp_strip_all_tags($phrase)));
        if ($phrase === '') {
            return '';
        }

        $parts = preg_split('/\s+/u', $phrase, -1, PREG_SPLIT_NO_EMPTY);
        $parts = is_array($parts) ? $parts : [];
        $quoted_parts = array_map(static fn(string $part): string => preg_quote($part, '/'), $parts);
        $quoted = implode('\s+', $quoted_parts);
        return $quoted !== '' ? '/(?<![\p{L}\p{N}])' . $quoted . '(?![\p{L}\p{N}])/iu' : '';
    }

    private static function phrase_pattern_body(string $phrase): string
    {
        $pattern = self::phrase_pattern($phrase);
        if ($pattern === '') {
            return '';
        }

        return (string) substr($pattern, 1, -3);
    }

    private static function uppercase_first_letter(string $text): string
    {
        return preg_replace_callback('/^\s*[\p{L}]/u', static function (array $match): string {
            $letter = (string) ($match[0] ?? '');
            return function_exists('mb_strtoupper') ? mb_strtoupper($letter, 'UTF-8') : strtoupper($letter);
        }, $text, 1) ?: $text;
    }

    /**
     * @return array<int, string>
     */
    private static function words(string $text): array
    {
        if (!preg_match_all('/[\p{L}\p{N}][\p{L}\p{N}\'’-]*/u', $text, $matches)) {
            return [];
        }

        return array_values(array_map(static fn($word): string => (string) $word, $matches[0] ?? []));
    }

    private static function word_count(string $text): int
    {
        $plain_text = trim(wp_strip_all_tags($text));
        if ($plain_text === '') {
            return 0;
        }

        if (!preg_match_all('/[\p{L}\p{N}][\p{L}\p{N}\'’-]*/u', $plain_text, $matches)) {
            return 0;
        }

        return count($matches[0]);
    }

    private static function text_length(string $text): int
    {
        return function_exists('mb_strlen') ? mb_strlen($text, 'UTF-8') : strlen($text);
    }

    private static function trim_to_length(string $text, int $max_length): string
    {
        if (self::text_length($text) <= $max_length) {
            return $text;
        }

        $trimmed = function_exists('mb_substr') ? mb_substr($text, 0, max(0, $max_length - 1), 'UTF-8') : (string) substr($text, 0, max(0, $max_length - 1));
        $trimmed = preg_replace('/\s+\S*$/u', '', (string) $trimmed);
        return rtrim((string) $trimmed, " \t\n\r\0\x0B.,;:") . '.';
    }

    private static function trim_slug_to_permalink_budget(string $slug): string
    {
        $slug = sanitize_title($slug);
        if ($slug === '') {
            return '';
        }

        $max_slug_length = self::max_slug_length_for_permalink();
        $parts = preg_split('/-+/', $slug, -1, PREG_SPLIT_NO_EMPTY);
        $parts = is_array($parts) ? $parts : [];
        $short_parts = [];
        foreach ($parts as $part) {
            $candidate_parts = array_merge($short_parts, [$part]);
            $candidate = implode('-', $candidate_parts);
            if (self::text_length($candidate) > $max_slug_length) {
                break;
            }
            $short_parts = $candidate_parts;
        }

        $short_slug = implode('-', $short_parts);
        if ($short_slug !== '') {
            return $short_slug;
        }

        $trimmed = function_exists('mb_substr') ? mb_substr($slug, 0, $max_slug_length, 'UTF-8') : (string) substr($slug, 0, $max_slug_length);
        return trim((string) preg_replace('/-[^-]*$/', '', (string) $trimmed), '-');
    }

    private static function permalink_length(string $slug): int
    {
        $slug = trim(sanitize_title($slug), '/');
        if ($slug === '') {
            return 0;
        }

        $base = function_exists('home_url') ? (string) home_url('/') : '';
        $permalink = $base !== ''
            ? rtrim($base, '/') . '/' . $slug . '/'
            : $slug;

        return self::text_length($permalink);
    }

    private static function max_slug_length_for_permalink(): int
    {
        $base = function_exists('home_url') ? (string) home_url('/') : '';
        if ($base === '') {
            return self::RANK_MATH_MAX_PERMALINK_LENGTH;
        }

        $overhead = self::text_length(rtrim($base, '/') . '//');
        return max(1, self::RANK_MATH_MAX_PERMALINK_LENGTH - $overhead);
    }
}
