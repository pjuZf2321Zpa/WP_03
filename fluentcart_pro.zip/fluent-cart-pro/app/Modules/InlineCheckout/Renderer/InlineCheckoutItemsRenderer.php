<?php

namespace FluentCartPro\App\Modules\InlineCheckout\Renderer;

use FluentCart\App\Helpers\Helper;
use FluentCart\App\Models\Cart;
use FluentCart\App\Models\ProductVariation;
use FluentCart\App\Services\Renderer\CartSummaryRender;
// Core's Vite, deliberately: the placeholder image is a free-plugin asset.
// FluentCartPro\App\Utils\Enqueuer\Vite shares the short name and would
// resolve to a valid-but-wrong URL inside pro's own assets directory.
use FluentCart\App\Vite;
use FluentCart\Framework\Support\Arr;

/**
 * The selectable item list of the inline (in-page) checkout.
 *
 * The dedicated checkout page shows what the shopper already put in the cart:
 * CartSummaryRender::renderItemsLists() walks `cart_data` and prints a passive
 * read-only line per item. On a content page that is the wrong shape. A landing
 * page offers a *set of options* — "T-Shirt / Medium", "Mug / Large", "Sticker
 * Pack" — and the shopper picks from it without leaving the page.
 *
 * So this renderer inverts the relationship:
 *
 *   the cart holds the SELECTION — which options are currently chosen
 *   this list holds the OPTIONS   — every variation the store owner configured
 *
 * Every configured variation renders as a row whether or not it is in the cart;
 * the ones that are in the cart render `checked`. One configured variation is
 * still one row — the list is never conditional on count.
 *
 * The list and the totals below it describe the same thing, because a selector
 * cart is standalone: it holds only what this block sells. The shop cart is
 * never adopted, and an option the author retires is pruned from the cart by
 * InlineCartService rather than shown as somebody else's item — so there is no
 * second list of "other" rows, and no subtotal made of things the page cannot
 * show.
 *
 * Everything below the list is unchanged and NOT reimplemented here. The
 * section heading and the whole Subtotal / coupon / Total block are delegated
 * to CartSummaryRender (`renderOrderSummarySectionHeading()` and
 * `renderItemsFooter()`, both public), constructed on the same Cart, so the
 * inline surface cannot drift away from the checkout page it mirrors.
 *
 * The AJAX contract:
 *
 *  - `data-fluent-cart-checkout-page-cart-items-wrapper` on the outer wrapper is
 *    the fragment target the coupon / address / selection round-trips replace
 *    wholesale. Rename it and live updates silently stop patching.
 *  - `data-fct-inline-items` marks the list; `data-fct-inline-item-input` and
 *    `data-fct-variation-id` mark each control, so the delegated `change`
 *    listener can read which variation was toggled. Because the wrapper is
 *    replaced on every update, listeners for these MUST be delegated from a
 *    stable ancestor — nothing bound to a row survives one swap.
 *
 * This class NEVER writes: the cart handed to it may be an unsaved, transient
 * Cart built purely for rendering, and a content page must not mint a cart row
 * for a visitor who merely scrolled past the block.
 *
 * @package FluentCartPro\App\Modules\InlineCheckout\Renderer
 */
class InlineCheckoutItemsRenderer
{
    /**
     * Ids emitted by CartSummaryRender::renderOrderSummarySectionHeading(),
     * which hardcodes `aria-controls="order_summary_panel"` on the toggle and
     * `id="order_summary_label"` on the visible heading. The panel we wrap the
     * list in must therefore carry exactly these, or the toggle's aria-controls
     * points at nothing and the region loses its accessible name.
     */
    const PANEL_ID = 'order_summary_panel';

    const HEADING_ID = 'order_summary_label';

    /**
     * Disambiguates input ids/names when more than one list is rendered in a
     * single request — the editor preview and the AJAX fragment path can both
     * build a renderer inside one PHP process.
     *
     * @var int
     */
    protected static $instanceCount = 0;

    /**
     * @var Cart|null Possibly UNSAVED. Read-only here.
     */
    protected $cart;

    /**
     * Normalized config from InlineCheckoutConfig::normalize().
     *
     * @var array
     */
    protected $config = [];

    /**
     * @var ProductVariation[] In the order the store owner arranged them.
     */
    protected $variations = [];

    /**
     * @var CartSummaryRender|null
     */
    protected $summaryRenderer;

    /**
     * Variation ids currently in the cart, i.e. the shopper's selection.
     *
     * @var int[]
     */
    protected $selectedIds = [];

    /**
     * The subset of $selectedIds actually rendered as checked.
     *
     * @var int[]
     */
    protected $checkedIds = [];

    /**
     * @var int
     */
    protected $instanceId = 1;

    /**
     * @param Cart  $cart       May be UNSAVED (transient). Never written to.
     * @param array $config     Normalized InlineCheckoutConfig array.
     * @param array $variations ProductVariation models, in author order.
     */
    public function __construct($cart, array $config, array $variations)
    {
        $this->cart   = ($cart instanceof Cart) ? $cart : null;
        $this->config = $config;

        // Defensive: a filter on `fluent_cart/inline_checkout/resolved_variations`
        // can hand back anything. Only real variations may become a buy option.
        $this->variations = array_values(array_filter($variations, function ($variation) {
            return $variation instanceof ProductVariation;
        }));

        $this->summaryRenderer = $this->cart ? new CartSummaryRender($this->cart) : null;
        $this->selectedIds     = $this->resolveSelectedIds();
        $this->checkedIds      = $this->resolveCheckedIds();
        $this->instanceId      = ++static::$instanceCount;
    }

    /**
     * Echo the item list plus the totals below it.
     *
     * @param bool $withWrapper Emit the fragment-target wrapper. False when the
     *                          caller is replacing the wrapper's inner HTML.
     * @return void
     */
    public function render($withWrapper = true): void
    {
        $this->output((bool)$withWrapper);
    }

    /**
     * The same markup render() echoes, returned as a string — the shape the
     * AJAX fragment payload needs.
     *
     * @param bool $withWrapper
     * @return string
     */
    public function getHtml($withWrapper = true): string
    {
        ob_start();
        $this->output((bool)$withWrapper);

        return (string)ob_get_clean();
    }

    /**
     * Only the option list, without the heading or the totals footer.
     *
     * The `items` context is asked for by a caller that already draws its own
     * heading and footer around the list — the checkout block's order-summary
     * inner block and the page-builder checkouts. Returning the whole section
     * there renders the heading and totals twice.
     *
     * @return string
     */
    public function getItemsHtml(): string
    {
        ob_start();
        $this->renderItemOptions();

        return (string)ob_get_clean();
    }

    /**
     * @param bool $withWrapper
     * @return void
     */
    protected function output(bool $withWrapper): void
    {
        ?>
        <?php if ($withWrapper): ?>
        <div class="fct_summary_box fct-inline-items-box" data-fluent-cart-checkout-page-cart-items-wrapper>
    <?php endif; ?>
        <div class="fct_checkout_form_section">
            <?php $this->renderHeading(); ?>

            <div
                class="fct_form_section_body"
                id="<?php echo esc_attr(static::PANEL_ID); ?>"
                role="region"
                aria-labelledby="<?php echo esc_attr(static::HEADING_ID); ?>"
            >
                <div class="fct_form_section_body_inner">
                    <?php $this->renderItemOptions(); ?>
                    <?php $this->renderFooter(); ?>
                </div>
            </div><!-- .fct_form_section_body -->
        </div>
        <?php if ($withWrapper): ?>
        </div>
    <?php endif; ?>
        <?php
    }

    /**
     * Section heading + the collapsed-state estimated total, straight from
     * CartSummaryRender so the toggle behaves identically to the checkout page.
     *
     * The only thing this surface overrides is the heading TEXT. "Order
     * summary" describes a passive recap of a cart; this section is a control
     * the shopper picks from, and the author already gets to name it
     * (`selector_label`). Everything else — the toggle, its aria-controls, the
     * estimated-total span the checkout JS patches — stays delegated, because
     * copying that markup here is how the two surfaces drift apart.
     *
     * @return void
     */
    protected function renderHeading(): void
    {
        if (!$this->summaryRenderer) {
            return;
        }

        $this->summaryRenderer->renderOrderSummarySectionHeading($this->selectorLabel());
    }

    /**
     * The author's name for this selector, or '' when they did not set one.
     *
     * Empty is not a fallback value here — it is the signal to keep today's
     * behaviour untouched, so a checkout that never configured a label renders
     * byte-for-byte what it rendered before.
     *
     * @return string
     */
    protected function selectorLabel(): string
    {
        $label = Arr::get($this->config, 'selector_label', '');

        return is_string($label) ? trim($label) : '';
    }

    /**
     * Subtotal, shipping, fees, "Have a Coupon?", Total — untouched, delegated.
     *
     * @return void
     */
    protected function renderFooter(): void
    {
        if (!$this->summaryRenderer) {
            return;
        }

        $this->summaryRenderer->renderItemsFooter();
    }

    /**
     * The list itself.
     *
     * @return void
     */
    protected function renderItemOptions(): void
    {
        if (!$this->variations) {
            $this->renderEmptyState();

            return;
        }

        $isSingle = $this->isSingleSelect();

        // A radiogroup announces "1 of 3" as the shopper arrows through the
        // options; a plain group is right for checkboxes, where each control
        // carries its own checked state.
        $groupRole = $isSingle ? 'radiogroup' : 'group';

        // The author's heading is the group's accessible name when they set
        // one. Otherwise a screen reader would hear "Choose your license" as
        // the section heading and then "Choose an option" as the group inside
        // it — two different names for one control. The generic strings stay
        // as the fallback for an unlabelled selector, where they are the only
        // description of what the group is for.
        $groupName = $this->selectorLabel();

        if ($groupName === '') {
            $groupName = $isSingle
                ? __('Choose an option', 'fluent-cart')
                : __('Choose one or more options', 'fluent-cart');
        }

        ?>
        <div
            data-fct-inline-items
            class="fct-inline-items<?php echo $isSingle ? ' fct-inline-items-single' : ' fct-inline-items-multiple'; ?>"
            role="<?php echo esc_attr($groupRole); ?>"
            aria-label="<?php echo esc_attr($groupName); ?>"
        >
            <?php foreach ($this->variations as $variation) {
                echo $this->getRowHtml($variation); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped in renderRow()
            } ?>
        </div>
        <?php
    }

    /**
     * Nothing to offer. A `role="status"` box so a shopper on a screen reader
     * hears why the checkout has no options, rather than meeting an empty div.
     *
     * @return void
     */
    protected function renderEmptyState(): void
    {
        $emptyText = trim((string)Arr::get($this->config, 'empty_text', ''));

        if ($emptyText === '') {
            $emptyText = __('No products are available to buy right now.', 'fluent-cart');
        }

        ?>
        <div class="fct-inline-items-empty" role="status">
            <?php echo esc_html($emptyText); ?>
        </div>
        <?php
    }




    /**
     * One option row, after the per-row filter.
     *
     * @param ProductVariation $variation
     * @return string
     */
    protected function getRowHtml(ProductVariation $variation): string
    {
        ob_start();
        $this->renderRow($variation);
        $html = (string)ob_get_clean();

        /**
         * Filter one inline-checkout option row.
         *
         * @param string $html    Fully escaped row markup.
         * @param array  $context ['variation' => ProductVariation, 'cart' => Cart|null, 'config' => array]
         */
        $filtered = apply_filters('fluent_cart/inline_checkout/item_row', $html, [
            'variation' => $variation,
            'cart'      => $this->cart,
            'config'    => $this->config,
        ]);

        return is_string($filtered) ? $filtered : $html;
    }

    /**
     * A real <input> inside a real <label>: the row is keyboard-operable, the
     * native control conveys checked state without relying on colour, and the
     * label's own text — product, variant, commitment, price — becomes the
     * accessible name, so the price is announced as part of the option rather
     * than as a bare number floating next to it. Which is also why everything
     * renderCommitmentInfo() adds is phrasing content inside that same label:
     * a subscription's cadence has to be part of what the shopper agrees to
     * when they tick the row, not a caption sitting outside it.
     *
     * @param ProductVariation $variation
     * @return void
     */
    protected function renderRow(ProductVariation $variation): void
    {
        $variationId = (int)$variation->id;

        if (!$variationId) {
            return;
        }

        $isSingle  = $this->isSingleSelect();
        $isChecked = in_array($variationId, $this->checkedIds, true);

        $titles   = $this->resolveTitles($variation);
        $mainName = $titles['title'];
        $subName  = $titles['subtitle'];

        $inputId = 'fct_inline_item_' . $this->instanceId . '_' . $variationId;

        // Radios must share one name to be mutually exclusive. Checkboxes must
        // NOT, or the browser submits only the last checked one.
        $inputName = $isSingle ? 'fct_inline_item' : 'fct_inline_item_' . $variationId;

        $rowClasses = ['fct-inline-item'];
        if ($isChecked) {
            $rowClasses[] = 'is-selected';
        }

        ?>
        <label
            class="<?php echo esc_attr(implode(' ', $rowClasses)); ?>"
            for="<?php echo esc_attr($inputId); ?>"
            data-fct-inline-item="<?php echo esc_attr($variationId); ?>"
        >
            <input
                class="fct-inline-item-input"
                type="<?php echo $isSingle ? 'radio' : 'checkbox'; ?>"
                id="<?php echo esc_attr($inputId); ?>"
                name="<?php echo esc_attr($inputName); ?>"
                value="<?php echo esc_attr($variationId); ?>"
                data-fct-inline-item-input
                data-fct-variation-id="<?php echo esc_attr($variationId); ?>"
                <?php echo $isChecked ? 'checked' : ''; ?>
            />

            <?php $this->renderRowImage($variation, $mainName); ?>

            <span class="fct-inline-item-content">
                <span class="fct-inline-item-title"><?php echo esc_html($mainName); ?></span>
                <?php if ($subName !== ''): ?>
                    <span class="fct-inline-item-variant"><?php echo esc_html($subName); ?></span>
                <?php endif; ?>
                <?php $this->renderCommitmentInfo($variation); ?>
            </span>

            <span class="fct-inline-item-price">
                <?php echo esc_html(Helper::toDecimal($this->resolvePrice($variation))); ?>
            </span>
        </label>
        <?php
    }

    /**
     * What ticking this row actually commits the shopper to.
     *
     * A bare "$100.00" on a "$100 yearly until canceled, plus a $10
     * Installation charge" plan is not a price, it is a third of one — and the
     * missing two thirds were still being added to the total below. So the row
     * discloses the cadence, the trial and the named setup fee, in that order.
     *
     * None of the wording is invented here. `generateSubscriptionInfo()`,
     * `generateTrialInfo()` and `generateSetupFeeInfo()` are the same three
     * helpers CartItemRenderer::maybeRenderPaymentTypeInfo() and
     * ::renderSetupFeeInfo() call for the ordinary checkout's line item, fed
     * the same `other_info` array: CartHelper::generateCartItemFromVariation()
     * copies it straight off `$variation->toArray()`, so the option row and the
     * cart line it produces are reading one source. If they ever word the same
     * plan differently, the divergence is in the helper, not in two renderers.
     *
     * A one-time product returns before emitting anything — its price is the
     * whole story, and an empty wrapper would only add chrome to the row.
     *
     * @param ProductVariation $variation
     * @return void
     */
    protected function renderCommitmentInfo(ProductVariation $variation): void
    {
        $otherInfo = $variation->other_info;

        if (!is_array($otherInfo)) {
            $otherInfo = [];
        }

        // Read the payment type off `other_info`, exactly as CartItemRenderer
        // does, falling back to the column. The two normally agree — the
        // model's accessor forces `other_info.payment_type` for subscriptions —
        // but the cart line carries the `other_info` copy, so that is the value
        // that decides what the checkout page will say about this item.
        $paymentType = (string)Arr::get($otherInfo, 'payment_type', $variation->payment_type);

        if ($paymentType !== 'subscription') {
            return;
        }

        // Cents, like the `unit_price` CartItemRenderer passes: the helper
        // formats the amount itself. Routing through resolvePrice() rather than
        // reading `item_price` keeps the cadence line agreeing with the price
        // this same row prints after `fluent_cart/cart/item_price` has run.
        $subscriptionInfo = Helper::generateSubscriptionInfo($otherInfo, $this->resolvePrice($variation));
        $trialInfo        = Helper::generateTrialInfo($otherInfo);

        // Array form for the name/amount split CartItemRenderer renders; it
        // returns '' when the variation has no setup fee, or when the author
        // left `manage_setup_fee` off.
        //
        // `setup_fee_per_item` is not consulted because it cannot matter here:
        // InlineCartService::buildCartData() adds exactly one unit per selected
        // option, and per-item × 1 is the flat fee. Should the selector ever
        // gain a quantity control, this is the line that has to multiply —
        // CartRenderer::renderItemTotal() shows the arithmetic.
        $setupFee = Helper::generateSetupFeeInfo($otherInfo, true);

        // The muted 13px treatment `.fct-inline-item-variant` already carries
        // is exactly what these secondary lines need. They carry their own
        // classes too, so the stylesheet can give them a dedicated rule later
        // without touching this file.
        ?>
        <?php if ($subscriptionInfo): ?>
            <span class="fct-inline-item-variant fct-inline-item-payment-info">
                <?php echo wp_kses($subscriptionInfo, ['del' => []]); ?>
            </span>
        <?php endif; ?>

        <?php if ($trialInfo): ?>
            <span class="fct-inline-item-variant fct-inline-item-trial-info">
                <?php echo esc_html($trialInfo); ?>
            </span>
        <?php endif; ?>

        <?php if (is_array($setupFee)): ?>
            <span class="fct-inline-item-variant fct-inline-item-setup-fee">
                <span class="setup-fee"><?php echo esc_html(Arr::get($setupFee, 'signup_fee_name', '')); ?></span>
                <span class="setup-fee-amount"><?php echo esc_html(Arr::get($setupFee, 'signup_fee_formatted', '')); ?></span>
            </span>
        <?php endif; ?>
        <?php
    }

    /**
     * The thumbnail is decorative here: the option's name sits beside it in the
     * same label, so an alt text would only make screen readers say it twice.
     *
     * @param ProductVariation $variation
     * @param string           $mainName
     * @return void
     */
    protected function renderRowImage(ProductVariation $variation, string $mainName): void
    {
        $image = (string)$variation->thumbnail;

        if ($image === '' && $variation->product) {
            $image = (string)$variation->product->thumbnail;
        }

        if ($image === '') {
            $image = (string)Vite::getAssetUrl('images/placeholder.svg');
        }

        if ($image === '') {
            return;
        }

        ?>
        <span class="fct-inline-item-media" aria-hidden="true">
            <img src="<?php echo esc_url($image); ?>" alt="" loading="lazy"/>
        </span>
        <?php
    }

    /**
     * Same resolution CartItemRenderer::renderTitle() uses, read off the model
     * instead of off a frozen cart line: the product post title is the row's
     * name, and the labeled attribute combination ("Color: Red | Size: XS") is
     * the sub-line — suppressed when it merely repeats the product name, which
     * is what a simple product's single variation produces.
     *
     * @param ProductVariation $variation
     * @return array{title: string, subtitle: string}
     */
    protected function resolveTitles(ProductVariation $variation): array
    {
        $product   = $variation->product;
        $mainTitle = $product ? (string)$product->post_title : '';
        $subtitle  = (string)$variation->getVariationLabel();

        if ($mainTitle === '') {
            // No product row (deleted/filtered): the variant label is all we have.
            $mainTitle = $subtitle;
            $subtitle  = '';
        }

        if ($subtitle === $mainTitle) {
            $subtitle = '';
        }

        return [
            'title'    => $mainTitle,
            'subtitle' => $subtitle,
        ];
    }

    /**
     * Unit price in cents.
     *
     * Runs the same `fluent_cart/cart/item_price` filter that
     * CartHelper::generateCartItemFromVariation() applies when the variation
     * actually enters the cart, so the price on the option row and the price on
     * the resulting cart line cannot disagree.
     *
     * @param ProductVariation $variation
     * @return int
     */
    protected function resolvePrice(ProductVariation $variation): int
    {
        $price = apply_filters('fluent_cart/cart/item_price', $variation->item_price, [
            'variation' => $variation,
            'quantity'  => 1,
        ]);

        return max(0, Helper::roundCent($price));
    }

    /**
     * @return bool
     */
    protected function isSingleSelect(): bool
    {
        return Arr::get($this->config, 'selection_mode', 'single') !== 'multiple';
    }

    /**
     * Which options are currently chosen — cart items are matched by
     * `object_id`, the variation id CartHelper stamps on every generated line.
     *
     * @return int[]
     */
    /**
     * The ids rendered as checked.
     *
     * Single-select mode can still be handed a cart holding more than one line.
     * Marking all of them checked emitted several checked radios sharing one
     * name, and the browser silently keeps only the last — the earlier rows read
     * as unselected while their lines were still in the total. Exactly one row
     * may be checked here.
     *
     * Only an id this checkout actually offers can be the checked one, or the
     * selection would point at a row that is not on the page.
     *
     * @return int[]
     */
    protected function resolveCheckedIds(): array
    {
        // Only an id with an actual rendered row can be checked: a variation the
        // author configured but the resolver dropped (unpublished, out of stock)
        // owns no row on this page, so a cart line for it must not be shown as
        // the current selection.
        $renderedIds = [];

        foreach ($this->variations as $variation) {
            $renderedIds[] = (int)$variation->id;
        }

        $checked = array_values(array_intersect($this->selectedIds, $renderedIds));

        if (!$this->isSingleSelect()) {
            return $checked;
        }

        // A radio group can only express one choice, and the browser keeps the
        // last of several checked radios sharing a name — the earlier rows read
        // as unselected while their lines stayed in the total.
        return $checked ? [$checked[0]] : [];
    }

    protected function resolveSelectedIds(): array
    {
        if (!$this->cart) {
            return [];
        }

        $items = $this->cart->cart_data;

        if (!is_array($items)) {
            return [];
        }

        $ids = [];

        foreach ($items as $item) {
            if (!is_array($item) || Arr::get($item, 'is_custom')) {
                // Custom/manual lines carry an object_id that is not a variation
                // id — a coincidental match would tick the wrong row.
                continue;
            }

            $objectId = absint(Arr::get($item, 'object_id', 0));

            if ($objectId && !in_array($objectId, $ids, true)) {
                $ids[] = $objectId;
            }
        }

        return $ids;
    }
}
