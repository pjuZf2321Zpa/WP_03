<?php


namespace WPAICG\Lib\Chat\Frontend\Ajax\Handlers;

use WPAICG\Chat\Admin\Ajax\BaseAjaxHandler;
use WPAICG\Chat\Storage\BotStorage;
use WPAICG\AIPKit_Providers;
use WP_Error;
use WPAICG\Chat\Storage\LogStorage;
use WPAICG\Core\TokenManager\AIPKit_Token_Manager;
use WPAICG\Core\Moderation\AIPKit_BannedIP_Checker;
use WPAICG\Core\Moderation\AIPKit_Global_Security_Settings;
use WPAICG\Core\Models\AIPKit_Model_Catalog;

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

require_once WPAICG_PLUGIN_DIR . 'classes/chatbot/pricing-context.php';

class AIPKit_Realtime_Session_Ajax_Handler extends BaseAjaxHandler
{
    private $bot_storage;
    private $log_storage;
    private $token_manager;

    public function __construct()
    {
        if (class_exists(BotStorage::class)) {
            $this->bot_storage = new BotStorage();
        }
        if (class_exists(LogStorage::class)) {
            $this->log_storage = new LogStorage();
        }
        if (class_exists(AIPKit_Token_Manager::class)) {
            $this->token_manager = new AIPKit_Token_Manager();
        }
    }

    /**
     * AJAX handler for creating an OpenAI Realtime API session.
     * This mints an ephemeral key for client-side use.
     */
    public function ajax_create_session(): void
    {
        // Security check
        $permission_check = $this->check_frontend_permissions();
        if (is_wp_error($permission_check)) {
            $this->send_wp_error($permission_check);
            return;
        }

        if (!$this->bot_storage) {
            $this->send_wp_error(new WP_Error('dependency_missing', __('Bot storage component is not available.', 'gpt3-ai-content-generator'), ['status' => 500]));
            return;
        }

        // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Frontend nonce is checked in check_frontend_permissions().
        $post_data = wp_unslash($_POST);
        // Get bot_id from POST
        $bot_id = isset($post_data['bot_id']) ? absint($post_data['bot_id']) : 0;
        if (empty($bot_id)) {
            $this->send_wp_error(new WP_Error('missing_bot_id', __('Bot ID is required to create a session.', 'gpt3-ai-content-generator'), ['status' => 400]));
            return;
        }

        // Get bot settings
        $bot_settings = $this->bot_storage->get_chatbot_settings($bot_id);
        if (empty($bot_settings)) {
            $this->send_wp_error(new WP_Error('bot_not_found', __('Could not load chatbot configuration.', 'gpt3-ai-content-generator'), ['status' => 404]));
            return;
        }

        // Check if the feature is enabled for this bot
        if (!isset($bot_settings['enable_realtime_voice']) || $bot_settings['enable_realtime_voice'] !== '1') {
            $this->send_wp_error(new WP_Error('feature_disabled', __('Realtime voice is not enabled for this chatbot.', 'gpt3-ai-content-generator'), ['status' => 403]));
            return;
        }

        $rate_check = \WPAICG\Core\TokenManager\AIPKit_Token_Manager::check_public_request_rate();
        if (is_wp_error($rate_check)) { $this->send_wp_error($rate_check); return; }

        $client_ip = isset($_SERVER['REMOTE_ADDR']) ? sanitize_text_field(wp_unslash($_SERVER['REMOTE_ADDR'])) : null;
        if (class_exists(AIPKit_Global_Security_Settings::class) && class_exists(AIPKit_BannedIP_Checker::class)) {
            $global_blocklists = AIPKit_Global_Security_Settings::get_blocklists_for_module('chat');
            $banned_ip_result = AIPKit_BannedIP_Checker::check(
                $client_ip,
                isset($global_blocklists['banned_ips_settings']) && is_array($global_blocklists['banned_ips_settings'])
                    ? $global_blocklists['banned_ips_settings']
                    : ['ips' => '', 'message' => '']
            );
            if (is_wp_error($banned_ip_result)) {
                $this->send_wp_error($banned_ip_result);
                return;
            }
        }

        // Check token limits before creating session
        if (!$this->token_manager) {
            $this->send_wp_error(new WP_Error('dependency_missing_token_manager', __('Token management service is not available.', 'gpt3-ai-content-generator'), ['status' => 500]));
            return;
        }

        $user_id = get_current_user_id();
        $is_guest = !$user_id;
        
        // Get session ID for guests
        $session_id = null;
        if ($is_guest) {
            $session_id = isset($post_data['session_id']) ? sanitize_text_field((string) $post_data['session_id']) : null;
            if (empty($session_id) && class_exists('\WPAICG\Chat\Frontend\Shortcode\Configurator')) {
                $session_id = \WPAICG\Chat\Frontend\Shortcode\Configurator::get_guest_uuid();
            }
        }

        $usage_context = \WPAICG\Chat\Core\Pricing\build_chat_pricing_check_context_logic(
            $bot_id,
            $bot_settings,
            '',
            null,
            sanitize_text_field((string) (($bot_settings['voice_engine'] ?? 'realtime') === 'live'
                ? ($bot_settings['live_backend_model'] ?? 'gpt-5.6-terra')
                : ($bot_settings['realtime_model'] ?? AIPKit_Model_Catalog::get_default_id('OpenAIRealtime'))))
        );
        // Realtime sessions always use the main OpenAI connection, regardless
        // of the provider configured for the chatbot's text responses.
        $usage_context['provider'] = 'OpenAI';
        $token_check_result = $this->token_manager->check_and_reset_tokens($user_id ?: null, $session_id, $bot_id, 'chat', $usage_context);
        if (is_wp_error($token_check_result)) {
            $this->send_wp_error($token_check_result);
            return;
        }

        $voice_engine = $bot_settings['voice_engine'] ?? 'realtime';
        if (($post_data['voice_engine'] ?? 'realtime') !== $voice_engine) {
            $this->send_wp_error(new WP_Error('voice_engine_changed', __('Voice settings changed. Reload the page before starting a session.', 'gpt3-ai-content-generator'), ['status' => 409]));
            return;
        }
        if ($voice_engine === 'live') {
            $result = \WPAICG\Lib\Chat\LiveSessions::create($bot_id, $bot_settings, $post_data, $this->token_manager);
            if (is_wp_error($result)) {
                $this->send_wp_error($result);
                return;
            }
            wp_send_json_success($result);
            return;
        }

        $format_config = static function (string $format): array {
            if ($format === 'g711_ulaw') {
                return ['type' => 'audio/pcmu'];
            }
            if ($format === 'g711_alaw') {
                return ['type' => 'audio/pcma'];
            }
            return ['type' => 'audio/pcm', 'rate' => 24000];
        };

        $turn_detection_setting = $bot_settings['turn_detection'] ?? 'server_vad';
        if ($turn_detection_setting === 'semantic_vad') {
            $turn_detection = [
                'type' => 'semantic_vad',
                'create_response' => true,
                'interrupt_response' => true,
            ];
        } else {
            $turn_detection = [
                'type' => 'server_vad',
                'threshold' => 0.5,
                'prefix_padding_ms' => 300,
                'silence_duration_ms' => 500,
                'create_response' => true,
                'interrupt_response' => true,
            ];
        }

        $realtime_model = $bot_settings['realtime_model'] ?? AIPKit_Model_Catalog::get_default_id('OpenAIRealtime');
        $realtime_voice = $bot_settings['realtime_voice'] ?? AIPKit_Model_Catalog::get_default_id('OpenAIRealtimeVoices');
        $request_body = [
            'session' => [
                'type' => 'realtime',
                'model' => $realtime_model,
                'instructions' => $bot_settings['instructions'] ?? 'You are a helpful assistant.',
                'output_modalities' => ['audio'],
                'audio' => [
                    'input' => [
                        'format' => $format_config((string) ($bot_settings['input_audio_format'] ?? 'pcm16')),
                        'noise_reduction' => (($bot_settings['input_audio_noise_reduction'] ?? '1') === '1')
                            ? ['type' => 'near_field']
                            : null,
                        'transcription' => [
                            'model' => AIPKit_Model_Catalog::get_model_id_by_role('realtime_transcription'),
                        ],
                        'turn_detection' => $turn_detection,
                    ],
                    'output' => [
                        'format' => $format_config((string) ($bot_settings['output_audio_format'] ?? 'pcm16')),
                        'voice' => $realtime_voice,
                        'speed' => isset($bot_settings['speed']) ? max(0.25, min(1.5, floatval($bot_settings['speed']))) : 1.0,
                    ],
                ],
            ],
        ];

        // Get main OpenAI API key from settings
        $openai_data = AIPKit_Providers::get_provider_data('OpenAI');
        $main_api_key = $openai_data['api_key'] ?? null;
        if (empty($main_api_key)) {
            $this->send_wp_error(new WP_Error('missing_api_key', __('OpenAI API key is not configured in main settings.', 'gpt3-ai-content-generator'), ['status' => 500]));
            return;
        }

        $headers = [
            'Authorization' => 'Bearer ' . $main_api_key,
            'Content-Type'  => 'application/json',
        ];
        $safety_subject = $user_id ? 'user:' . $user_id : 'guest:' . ($session_id ?: $client_ip);
        if ($safety_subject !== 'guest:') {
            $headers['OpenAI-Safety-Identifier'] = hash_hmac('sha256', $safety_subject, wp_salt('auth'));
        }

        // Mint a short-lived client secret for the browser connection.
        // phpcs:ignore PluginCheck.CodeAnalysis.AIProvider.DirectIntegration -- Provider-specific realtime transport.
        $response = wp_remote_post('https://api.openai.com/v1/realtime/client_secrets', [
            'method'  => 'POST',
            'timeout' => 20,
            'headers' => $headers,
            'body'    => wp_json_encode($request_body),
        ]);

        if (is_wp_error($response)) {
            $this->send_wp_error(new WP_Error('http_request_failed', $response->get_error_message(), ['status' => 500]));
            return;
        }

        $status_code = wp_remote_retrieve_response_code($response);
        $body = wp_remote_retrieve_body($response);
        $decoded_body = json_decode($body, true);
        if (!is_array($decoded_body)) {
            $decoded_body = [];
        }

        if ($status_code < 200 || $status_code >= 300) {
            $error_message = $decoded_body['error']['message'] ?? __('Failed to create a session.', 'gpt3-ai-content-generator');
            $error_status = ($status_code >= 400 && $status_code < 600) ? $status_code : 502;
            $this->send_wp_error(new WP_Error('api_error', $error_message, ['status' => $error_status]));
            return;
        }

        $client_secret_value = $decoded_body['value'] ?? ($decoded_body['client_secret']['value'] ?? '');
        if ($client_secret_value === '') {
            $this->send_wp_error(new WP_Error('invalid_response', __('Invalid response from OpenAI: client secret missing.', 'gpt3-ai-content-generator'), ['status' => 500]));
            return;
        }

        wp_send_json_success([
            'client_secret' => [
                'value' => $client_secret_value,
                'expires_at' => $decoded_body['expires_at'] ?? null,
            ],
        ]);
    }

    /**
     * AJAX handler for logging a completed Realtime API session turn.
     * This receives data from the client after a 'response.done' event.
     */
    public function ajax_log_session_turn(): void
    {
        $permission_check = $this->check_frontend_permissions();
        if (is_wp_error($permission_check)) {
            $this->send_wp_error($permission_check);
            return;
        }

        if (!$this->bot_storage || !$this->log_storage || !$this->token_manager) {
            $this->send_wp_error(new WP_Error('dependency_missing_log_turn', __('Logging service is not available.', 'gpt3-ai-content-generator'), ['status' => 500]));
            return;
        }

        // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Frontend nonce is checked in check_frontend_permissions().
        $post_data = wp_unslash($_POST);
        $bot_id = isset($post_data['bot_id']) ? absint($post_data['bot_id']) : 0;
        $session_id = isset($post_data['session_id']) ? sanitize_text_field($post_data['session_id']) : null;
        $conversation_uuid = isset($post_data['conversation_uuid']) ? sanitize_key($post_data['conversation_uuid']) : '';
        $user_transcript = isset($post_data['user_transcript']) ? sanitize_textarea_field($post_data['user_transcript']) : '';
        $bot_transcript = isset($post_data['bot_transcript']) ? sanitize_textarea_field($post_data['bot_transcript']) : '';
        $usage_data_json = isset($post_data['usage_data']) ? $post_data['usage_data'] : null;
        $usage_data = $usage_data_json ? json_decode($usage_data_json, true) : null;
        $usage_data = is_array($usage_data) ? $usage_data : [];

        if (empty($bot_id) || empty($conversation_uuid) || (empty($user_transcript) && empty($bot_transcript))) {
            $this->send_wp_error(new WP_Error('missing_params_log_turn', __('Missing required parameters for logging.', 'gpt3-ai-content-generator'), ['status' => 400]));
            return;
        }

        $user_id = get_current_user_id();
        $is_guest = !$user_id;

        $bot_settings = $this->bot_storage->get_chatbot_settings($bot_id);
        if (empty($bot_settings) || ($bot_settings['enable_realtime_voice'] ?? '0') !== '1') {
            $this->send_wp_error(new WP_Error('invalid_bot_log_turn', __('Could not load chatbot configuration.', 'gpt3-ai-content-generator'), ['status' => 404]));
            return;
        }

        $base_log_data = [
            'bot_id'            => $bot_id,
            'user_id'           => $user_id ?: null,
            'session_id'        => $is_guest ? $session_id : null,
            'conversation_uuid' => $conversation_uuid,
            'module'            => 'chat',
            'is_guest'          => $is_guest,
            'role'              => $is_guest ? null : implode(', ', wp_get_current_user()->roles),
            'ip_address'        => isset($_SERVER['REMOTE_ADDR']) ? sanitize_text_field(wp_unslash($_SERVER['REMOTE_ADDR'])) : null,
        ];
        
        // Log user turn
        if (!empty(trim($user_transcript))) {
            $this->log_storage->log_message(array_merge($base_log_data, [
                'message_role'    => 'user',
                'message_content' => $user_transcript,
                'timestamp'       => time(),
                'ai_provider'     => 'OpenAIRealtime',
                'ai_model'        => $bot_settings['realtime_model'] ?? 'unknown',
            ]));
        }

        // Log bot turn
        if (!empty(trim($bot_transcript))) {
            $this->log_storage->log_message(array_merge($base_log_data, [
                'message_role'    => 'bot',
                'message_content' => $bot_transcript,
                'timestamp'       => time(),
                'ai_provider'     => 'OpenAIRealtime',
                'ai_model'        => $bot_settings['realtime_model'] ?? 'unknown',
                'usage'           => $usage_data,
            ]));
        }

        // Record token usage
        $tokens_consumed = absint($usage_data['total_tokens'] ?? 0);
        if ($tokens_consumed > 0) {
            $usage_context = [
                'provider' => 'OpenAI',
                'model' => sanitize_text_field((string) ($bot_settings['realtime_model'] ?? AIPKit_Model_Catalog::get_default_id('OpenAIRealtime'))),
                'operation' => 'chat',
                'usage_data' => is_array($usage_data) ? $usage_data : [],
            ];

            $this->token_manager->record_token_usage(
                $user_id ?: null,
                $session_id,
                $bot_id,
                $tokens_consumed,
                'chat',
                $usage_context
            );
        }

        wp_send_json_success(['message' => 'Session turn logged successfully.']);
    }

    public function ajax_sync_live_session(): void
    {
        $permission_check = $this->check_frontend_permissions();
        if (is_wp_error($permission_check)) {
            $this->send_wp_error($permission_check);
            return;
        }
        if (!$this->log_storage || !$this->token_manager) {
            $this->send_wp_error(new WP_Error('dependency_missing', __('Voice usage services are not available.', 'gpt3-ai-content-generator'), ['status' => 503]));
            return;
        }
        // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Frontend nonce and CORS checked above.
        $result = \WPAICG\Lib\Chat\LiveSessions::sync(wp_unslash($_POST), $this->log_storage, $this->token_manager);
        if (is_wp_error($result)) {
            $this->send_wp_error($result);
            return;
        }
        wp_send_json_success($result);
    }
}
