<?php

/**
 * FluentCRM    Record Api
 */

namespace BitApps\IntegrationsPro\Actions\FluentCRM;

class FluentCRMProHelper
{
    public static function assignCompany($fieldData, $actions)
    {
        if (empty($actions['company_id'])) {
            return $fieldData;
        }

        $fieldData['company_id'] = $actions['company_id'];

        return $fieldData;
    }
}
