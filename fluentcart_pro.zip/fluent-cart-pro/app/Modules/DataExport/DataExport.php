<?php

namespace FluentCartPro\App\Modules\DataExport;

class DataExport
{
    public function register( $app ): void
    {
        $app->router->group( function ( $router ) {
            require_once __DIR__ . '/Http/routes.php';
        } );
    }
}
