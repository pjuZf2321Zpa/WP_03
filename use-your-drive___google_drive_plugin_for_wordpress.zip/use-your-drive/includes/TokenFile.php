<?php
/**
 * @author WP Cloud Plugins
 * @copyright Copyright (c) 2023, WP Cloud Plugins
 *
 * @since       3.10.5
 * @see https://www.wpcloudplugins.com
 */

namespace TheLion\UseyourDrive;

defined('ABSPATH') || exit;

/**
 * Storage of the (encrypted) authorization data of an account in a file.
 *
 * The file can be shared by multiple processes, by all sites in a multisite network and by
 * multiple servers using the same (network) storage. This class only reads and writes the raw data
 * and doesn't know the token format.
 *
 * - Writing replaces the file atomically (temporary file + rename), so readers never see an empty or partially written file.
 * - Reading doesn't require a lock.
 * - Locking is done on a separate .lock file, as a lock on a replaced file would no longer block other processes.
 */
class TokenFile
{
    /**
     * Path to the token file.
     *
     * @var string
     */
    private $_path;

    /**
     * File handle of the lock file.
     *
     * @var null|resource
     */
    private $_lock_handle;

    /**
     * Log a lock file problem only once per request.
     *
     * @var bool
     */
    private static $_lock_error_logged = false;

    /**
     * @param string $path path to the token file
     */
    public function __construct($path)
    {
        $this->_path = $path;
    }

    public function __destruct()
    {
        $this->unlock();
    }

    /**
     * @return string
     */
    public function get_path()
    {
        return $this->_path;
    }

    /**
     * The lock file is never removed. Removing it while another process holds the lock would split the lock.
     *
     * @return string
     */
    public function get_lock_path()
    {
        return $this->_path.'.lock';
    }

    /**
     * Read the raw data from the token file.
     *
     * @return null|string null when there is no data or it cannot be read
     */
    public function read()
    {
        // Retry shortly when the file is being written, e.g. by the in-place fallback of write()
        for ($attempt = 0; $attempt < 3; ++$attempt) {
            clearstatcache(true, $this->_path);

            if (!file_exists($this->_path)) {
                return null;
            }

            // false = the file cannot be read at the moment (e.g. locked on Windows)
            $data = @file_get_contents($this->_path);

            // An empty file that has just been modified can be truncated by a writer. An older empty file has no data
            if ('' === $data && @filemtime($this->_path) < time() - 5) {
                return null;
            }

            if (!empty($data)) {
                return $data;
            }

            usleep(50000);
        }

        return null;
    }

    /**
     * Check if the token file contains data, even if it cannot be read or decrypted.
     *
     * @return bool
     */
    public function has_data()
    {
        clearstatcache(true, $this->_path);

        return file_exists($this->_path) && filesize($this->_path) > 0;
    }

    /**
     * Replace the token file atomically, so other processes never read an empty or partially written file.
     * The data must already be encrypted. The temporary file is created in the same (protected) folder.
     *
     * @param string $data
     *
     * @return bool true when the data is stored
     */
    public function write($data)
    {
        clearstatcache(true, $this->_path);
        $file_exists = file_exists($this->_path);

        // rename() replaces the file with a file owned by the current user. Keep the owner of an existing token file,
        // e.g. when WP-CLI or a system cron runs as another user than the web server, by writing it in place instead
        $is_same_owner = !$file_exists || !function_exists('posix_geteuid') || fileowner($this->_path) === posix_geteuid();

        // Never replace the file of another owner, as that user (e.g. the web server) may not be able to read the new file
        if (false === $is_same_owner) {
            if ($this->write_in_place($data)) {
                return true;
            }

            Helpers::log_error('Token file is owned by another user and is not writable.', 'Authorization', ['file' => \basename($this->_path)], __LINE__);

            return false;
        }

        // Replace the file atomically. This only requires write permissions on the folder.
        // New files get the default permissions (umask). The content is encrypted
        $permissions = $file_exists ? (fileperms($this->_path) & 0777) : (0666 & ~umask());
        $tmp_file = $this->_path.'.'.bin2hex(random_bytes(8)).'.tmp';

        // Mode 'x' only creates a new file and fails if the path already exists (including symlinks)
        $handle = @fopen($tmp_file, 'x');

        if (false !== $handle) {
            @chmod($tmp_file, $permissions);
            $written = fwrite($handle, $data);
            fflush($handle);
            fclose($handle);

            if (strlen($data) === $written) {
                // On Windows rename() fails while another process has the token file opened
                for ($attempt = 0; $attempt < 5; ++$attempt) {
                    if (@rename($tmp_file, $this->_path)) {
                        clearstatcache(true, $this->_path);

                        return true;
                    }

                    usleep(50000);
                }
            }

            @unlink($tmp_file);
        }

        // Fallback: write the token file in place
        if ($this->write_in_place($data)) {
            return true;
        }

        Helpers::log_error('Token file is not writable.', 'Authorization', ['file' => \basename($this->_path)], __LINE__);

        return false;
    }

    /**
     * Remove the token file. The lock file is kept.
     */
    public function remove()
    {
        @unlink($this->_path);
        clearstatcache(true, $this->_path);
    }

    /**
     * Lock the token, e.g. for renewing. The lock of a process that dies is released automatically.
     *
     * @param int $type LOCK_EX or LOCK_SH
     *
     * @return bool
     */
    public function lock($type = LOCK_EX)
    {
        $handle = $this->get_lock_handle();

        // Continue without lock if the lock file cannot be opened
        if (null === $handle) {
            return true;
        }

        return flock($handle, $type);
    }

    /**
     * Try to get an exclusive lock, but don't wait longer than the timeout.
     * This prevents that all PHP workers keep waiting when renewing the token takes long.
     *
     * @param float|int $timeout in seconds
     *
     * @return bool
     */
    public function try_lock($timeout = 10)
    {
        $handle = $this->get_lock_handle();

        // Continue without lock if the lock file cannot be opened
        if (null === $handle) {
            return true;
        }

        $end_time = microtime(true) + $timeout;

        do {
            if (flock($handle, LOCK_EX | LOCK_NB)) {
                return true;
            }

            usleep(100000);
        } while (microtime(true) < $end_time);

        return false;
    }

    /**
     * Check if the lock file can be used. Without lock file, lock() and try_lock() always succeed.
     *
     * @return bool
     */
    public function can_lock()
    {
        return null !== $this->get_lock_handle();
    }

    public function unlock()
    {
        if (!empty($this->_lock_handle)) {
            flock($this->_lock_handle, LOCK_UN);
            fclose($this->_lock_handle);
            $this->_lock_handle = null;
        }

        return true;
    }

    /**
     * @param string $data
     *
     * @return bool
     */
    private function write_in_place($data)
    {
        $is_written = strlen($data) === @file_put_contents($this->_path, $data, LOCK_EX);
        clearstatcache(true, $this->_path);

        return $is_written;
    }

    /**
     * @return null|resource
     */
    private function get_lock_handle()
    {
        if (empty($this->_lock_handle)) {
            $lock_path = $this->get_lock_path();
            $is_new = !file_exists($lock_path);
            $handle = @fopen($lock_path, 'c');

            // flock() also works on a read-only handle, e.g. when the lock file is created by WP-CLI running as another user
            if (!is_resource($handle)) {
                $handle = @fopen($lock_path, 'r');
            }

            if (!is_resource($handle)) {
                if (empty(self::$_lock_error_logged)) {
                    self::$_lock_error_logged = true;
                    Helpers::log_error('Token lock file cannot be opened. The token is used without lock.', 'Authorization', ['file' => \basename($lock_path)], __LINE__);
                }

                return null;
            }

            // The lock file is always empty. It must be readable for all users that run the plugin (web server, WP-CLI, cron)
            if ($is_new) {
                @chmod($lock_path, 0644);
            }

            $this->_lock_handle = $handle;
        }

        return $this->_lock_handle;
    }
}
