<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\Assist\Config as FreeConfig;
use BitApps\Assist\Widget;
use BitApps\AssistPro\Config as ProConfig;

/**
 * Multi-domain widget lookup.
 *
 * When the requested domain is not the current WordPress site, this hook
 * allows the pro plugin to look up a widget assigned to an external domain.
 *
 * @param Widget|null $default null (passed by free plugin as the "no match" default)
 * @param string      $domain  The requesting domain URL
 * @param Widget      $widget  Widget query builder pre-filtered by status = 1
 *
 * @return Widget|null Widget builder with domain condition, or null if no match
 */
add_filter(FreeConfig::withPrefix('resolve_external_widget'), function ($default, $domain, $widget) {
    if (!ProConfig::isPro()) {
        return $default;
    }

    $domainExceptWWW = $domain;
    if (stristr($domainExceptWWW, 'www.')) {
        $domainExceptWWW = str_replace('www.', '', $domainExceptWWW);
    }

    $parsed = wp_parse_url($domainExceptWWW);
    if (empty($parsed['host'])) {
        return $default;
    }

    $widget->where('domains', 'LIKE', '%' . $parsed['host'] . '%');

    return $widget;
}, 10, 3);

/**
 * Extra widget API columns for the public iframe API.
 *
 * Adds pro-only fields (custom_css, business_hours, exclude_pages)
 * to the column list fetched for the widget iframe.
 *
 * @param array $columns Base column list from free plugin
 *
 * @return array
 */
add_filter(FreeConfig::withPrefix('widget_api_columns'), function ($columns) {
    if (!ProConfig::isPro()) {
        return $columns;
    }

    return array_merge($columns, ['custom_css', 'business_hours', 'exclude_pages']);
});

/**
 * Widget channel config before save.
 *
 * The free plugin fires this filter without stripping anything.
 * This hook is the place to manage pro-only config fields.
 *
 * When pro is active (this filter is registered), pro fields such as
 * hide_after_office_hours and webhook_url are preserved as-is.
 * When pro is not active, this filter never runs and the free plugin
 * saves the data untouched — no stripping on either side.
 *
 * @param array $validated Sanitized channel config from the request
 *
 * @return array
 */
add_filter(FreeConfig::withPrefix('widget_channel_config_before_save'), function ($validated) {
    if (ProConfig::isPro()) {
        return $validated;
    }

    if (!empty($validated['config']['hide_after_office_hours'])) {
        unset($validated['config']['hide_after_office_hours']);
    }
    if (isset($validated['channel_name']) && $validated['channel_name'] === 'Custom-Form'
        && !empty($validated['config']['card_config']['webhook_url'])) {
        unset($validated['config']['card_config']['webhook_url']);
    }

    return $validated;
});

/**
 * Webhook dispatch after a Custom Form response is submitted.
 *
 * Fires after the free plugin stores a form response. Sends form data
 * to the configured webhook URL (if any) via HTTP POST.
 *
 * @param array    $formData Sanitized form field values
 * @param stdClass $config   Channel config object
 */
add_action(FreeConfig::withPrefix('after_form_response'), function ($formData, $config) {
    if (!ProConfig::isPro()) {
        return;
    }

    if (empty($config->card_config->webhook_url)) {
        return;
    }

    $webhook = new \BitApps\AssistPro\Deps\BitApps\WPKit\Http\Client\HttpClient();
    $webhook->request($config->card_config->webhook_url, 'POST', $formData);
}, 10, 2);
