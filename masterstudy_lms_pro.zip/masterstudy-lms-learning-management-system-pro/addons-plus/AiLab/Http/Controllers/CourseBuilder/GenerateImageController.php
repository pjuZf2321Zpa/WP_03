<?php

namespace MasterStudy\Lms\Pro\AddonsPlus\AiLab\Http\Controllers\CourseBuilder;

use MasterStudy\Lms\Pro\AddonsPlus\AiLab\Http\Controllers\Controller;
use MasterStudy\Lms\Http\WpResponseFactory;
use MasterStudy\Lms\Pro\AddonsPlus\AiLab\Services\OpenAi\Model;
use MasterStudy\Lms\Pro\AddonsPlus\AiLab\Services\OpenAi\Queries\QueryFactory;
use MasterStudy\Lms\Pro\AddonsPlus\AiLab\Utility\ImageUploader;
use MasterStudy\Lms\Validation\Validator;

class GenerateImageController extends Controller {
	public function __invoke( \WP_REST_Request $request ) {
		$validator = new Validator(
			$request->get_params(),
			array(
				'prompt' => 'required|string',
				'style'  => 'required|string',
			)
		);

		if ( $validator->fails() ) {
			return WpResponseFactory::validation_failed( $validator->get_errors_array() );
		}

		$validated_data = $validator->get_validated();
		$prompt         = 'None' === $validated_data['style']
			? $validated_data['prompt']
			: sprintf(
				$this->options->get( 'generator.image.prompt', '%s %s' ),
				$validated_data['prompt'],
				$validated_data['style']
			);

		try {
			$response = $this->ai->exec(
				QueryFactory::image(
					$prompt,
					array(
						'max_results' => 1,
						'model'       => $this->options->get( 'image_model' ),
						'provider'    => $this->options->get( 'image_provider', Model::PROVIDER_OPENAI ),
						'size'        => $this->options->get( 'generator.image.size' ),
					)
				)
			);

			$generated_image = $response->results[0] ?? '';
			unset( $response );

			if ( is_array( $generated_image ) && ! empty( $generated_image['b64_json'] ) ) {
				$attachment = ImageUploader::create_attachment_from_base64(
					$generated_image['b64_json'],
					$generated_image['mime_type'] ?? 'image/png'
				);

				if ( isset( $attachment['error'] ) ) {
					throw new \Exception( $attachment['error'] );
				}

				$generated_image = $attachment['url'];
			}

			if ( ! is_string( $generated_image ) || '' === $generated_image ) {
				throw new \Exception(
					esc_html__( 'AI returned empty image data.', 'masterstudy-lms-learning-management-system-pro' )
				);
			}

			if ( ImageUploader::is_data_image( $generated_image ) ) {
				$attachment = ImageUploader::create_attachment( $generated_image );

				if ( isset( $attachment['error'] ) ) {
					throw new \Exception( $attachment['error'] );
				}

				$generated_image = $attachment['url'];
			}

			return new \WP_REST_Response( $generated_image );
		} catch ( \Exception $e ) {
			return WpResponseFactory::error( $e->getMessage() );
		}
	}
}
