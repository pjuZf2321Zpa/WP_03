<?php

if (!defined('ABSPATH')) {
    die('You are not allowed to call this page directly.');
}

/**
 * Wordfence Login Security integration.
 *
 * Wordfence checks 2FA codes and reCAPTCHA tokens in the `authenticate` filter, which our
 * login form already runs through wp_signon(). The only missing piece is the browser side:
 * Wordfence's login script, which asks for the 2FA code and adds the reCAPTCHA token to the
 * form. That script finds any form with `log`/`pwd` fields, so we load it on our login form
 * the same way Wordfence loads it on the WooCommerce login form.
 *
 * Known limits:
 * - Only the login form is covered. Wordfence has no CAPTCHA on lost password; its
 *   `lostpassword_post` check is brute-force lockout, which our Forgot Password handler doesn't run.
 * - Only the first login form on a page gets Wordfence: its script attaches to the first
 *   `log` field, so a 2FA user who submits a second form gets "code required" with no code box.
 * - Passkeys (Wordfence 8.2+): the script adds a "Log In with a Passkey" button to our form.
 *   That login runs through Wordfence's own AJAX request, not our login handler, so we record
 *   the `login` event on `wp_login` ourselves. Per-membership and expired-subscription login
 *   redirects don't apply to passkey logins (Wordfence has no filter for its redirect).
 */
class MeprWordfenceIntegration
{
    /**
     * Whether the scripts were already loaded on this request.
     *
     * @var boolean
     */
    private $enqueued = false;

    /**
     * Constructor.
     *
     * @return void
     */
    public function __construct()
    {
        add_action('mepr_before_login_form', [$this, 'enqueue_login_scripts']);
        add_action('wp_login', [$this, 'record_passkey_login'], 10, 2);
    }

    /**
     * Record the MemberPress login event for Wordfence passkey logins.
     *
     * Password logins record it in MeprProductsCtrl's login redirect handling, which passkey
     * logins never reach.
     *
     * @param string  $user_login The username.
     * @param WP_User $user       The user who logged in.
     *
     * @return void
     */
    public function record_passkey_login($user_login, $user)
    {
        if (
            !doing_action('wp_ajax_nopriv_wordfence_ls_finish_passkey_login') &&
            !doing_action('wp_ajax_wordfence_ls_finish_passkey_login')
        ) {
            return;
        }

        if (!($user instanceof WP_User)) {
            return;
        }

        MeprEvent::record('login', new MeprUser($user->ID));
    }

    /**
     * Load Wordfence's login scripts on the MemberPress login form.
     *
     * This runs in the page body, after wp_head, so WordPress prints the scripts and styles
     * in the footer.
     *
     * @return void
     */
    public function enqueue_login_scripts()
    {
        if (
            $this->enqueued ||
            MeprUtils::is_user_logged_in() ||
            !class_exists(\WordfenceLS\Controller_WordfenceLS::class) ||
            !is_callable([\WordfenceLS\Controller_WordfenceLS::class, 'shared'])
        ) {
            return;
        }

        $controller = \WordfenceLS\Controller_WordfenceLS::shared();

        if (!is_object($controller) || !is_callable([$controller, '_login_enqueue_scripts'])) {
            return;
        }

        $this->enqueued = true;

        // Used by the help icon next to the 2FA code field.
        wp_enqueue_style('dashicons');

        $controller->_login_enqueue_scripts();
    }
}

new MeprWordfenceIntegration();
