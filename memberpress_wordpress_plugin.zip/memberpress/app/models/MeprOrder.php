<?php

defined('ABSPATH') || exit;

/**
 * Represents an order in the system.
 *
 * @property int $id
 * @property int|null $user_id
 * @property int $primary_transaction_id
 * @property string $trans_num
 * @property string $status
 * @property string $gateway
 * @property string $created_at
 * @property string $order_type
 * @property string $currency
 * @property float $subtotal
 * @property float $discount_total
 * @property float $tax_total
 * @property float $shipping_total
 * @property float $total
 * @property float $amount_paid
 * @property float $amount_refunded
 * @property int|null $coupon_id
 * @property string|null $coupon_code
 * @property string|null $gateway_order_id
 * @property int|null $payment_method_id
 * @property string|null $ip_address
 * @property string|null $updated_at
 * @property string|null $paid_at
 * @property string|null $completed_at
 * @property string|null $customer_note
 */
class MeprOrder extends MeprBaseMetaModel
{
    /**
     * Status string for pending orders.
     *
     * @var string
     */
    public static $pending_str = 'pending';

    /**
     * Status string for failed orders.
     *
     * @var string
     */
    public static $failed_str = 'failed';

    /**
     * Status string for complete orders.
     *
     * @var string
     */
    public static $complete_str = 'complete';

    /**
     * Status string for refunded orders.
     *
     * @var string
     */
    public static $refunded_str = 'refunded';

    /**
     * Status string for cancelled orders.
     *
     * @var string
     */
    public static $cancelled_str = 'cancelled';

    /**
     * Order type string for order bumps (legacy default).
     *
     * @var string
     */
    public static $order_bumps_type_str = 'order_bumps';

    /**
     * Order type string for cart orders.
     *
     * @var string
     */
    public static $cart_type_str = 'cart';

    /**
     * Meta key used to store order notes (multiple allowed via add_meta).
     *
     * @var string
     */
    public static $order_note_key = '_mepr_order_note';

    /**
     * Prefix of a locally generated order transaction number.
     *
     * An order is given one of these on construction, and a gateway replaces
     * it with the number of the charge that paid the order's rows. An order
     * still holding this prefix was paid by no charge, so its number is ours
     * rather than a processor's.
     *
     * @var string
     */
    public static $local_trans_num_prefix = 'mp-ord-';

    /**
     * Constructor for the MeprOrder class.
     *
     * @param mixed $obj Optional. The object to initialize the order with.
     */
    public function __construct($obj = null)
    {
        parent::__construct($obj);

        $this->initialize(
            [
                'id'                     => 0,
                'user_id'                => null,
                'primary_transaction_id' => 0,
                'trans_num'              => MeprOrder::generate_trans_num(),
                'status'                 => self::$pending_str,
                'gateway'                => null,
                'created_at'             => null,
                'order_type'             => self::$order_bumps_type_str,
                'currency'               => 'USD',
                'subtotal'               => 0.00,
                'discount_total'         => 0.00,
                'tax_total'              => 0.00,
                'shipping_total'         => 0.00,
                'total'                  => 0.00,
                'amount_paid'            => 0.00,
                'amount_refunded'        => 0.00,
                'coupon_id'              => null,
                'coupon_code'            => null,
                'gateway_order_id'       => null,
                'payment_method_id'      => null,
                'ip_address'             => null,
                'updated_at'             => null,
                'paid_at'                => null,
                'completed_at'           => null,
                'customer_note'          => null,
            ],
            $obj
        );
    }

    /**
     * Create a new order record in the database.
     *
     * @param MeprOrder $order The order object to create.
     *
     * @return integer The ID of the created order.
     */
    public static function create(MeprOrder $order)
    {
        $mepr_db = new MeprDb();

        if (is_null($order->created_at) || empty($order->created_at)) {
            $order->created_at = MeprUtils::ts_to_mysql_date(time());
        }

        $args = (array) $order->get_values();

        return MeprHooks::apply_filters('mepr_create_order', $mepr_db->create_record($mepr_db->orders, $args, false), $args, $order->user_id);
    }

    /**
     * Update an existing order record in the database.
     *
     * @param MeprOrder $order The order object to update.
     *
     * @return integer The ID of the updated order.
     */
    public static function update(MeprOrder $order)
    {
        $mepr_db = new MeprDb();
        $args    = (array) $order->get_values();

        return MeprHooks::apply_filters('mepr_update_order', $mepr_db->update_record($mepr_db->orders, $order->id, $args), $args, $order->user_id);
    }

    /**
     * Store the order in the database, creating or updating as necessary.
     *
     * @return integer The ID of the stored order.
     */
    public function store()
    {
        $old_order = new self($this->id);

        if (isset($this->id) && !is_null($this->id) && (int) $this->id > 0) {
            $this->id = self::update($this);
        } else {
            $this->id = self::create($this);
        }

        MeprHooks::do_action('mepr_order_transition_status', $old_order->status, $this->status, $this);

        // Auto-add a system note when the status actually transitions on an existing order.
        if ((int) $old_order->id > 0 && $old_order->status !== $this->status) {
            $this->add_status_change_note($old_order->status, $this->status);
        }

        MeprHooks::do_action('mepr_order_store', $this, $old_order);
        MeprHooks::do_action('mepr_order_status_' . $this->status, $this);

        return $this->id;
    }

    /**
     * Delete the order from the database.
     *
     * @return boolean True if the order was successfully deleted, false otherwise.
     */
    public function destroy()
    {
        $mepr_db = new MeprDb();
        $id      = $this->id;
        $args    = compact('id');

        MeprHooks::do_action('mepr_order_destroy', $this);
        MeprHooks::do_action('mepr_pre_delete_order', $this);
        $result = MeprHooks::apply_filters('mepr_delete_order', $mepr_db->delete_records($mepr_db->orders, $args), $args);
        MeprHooks::do_action('mepr_post_delete_order', $this);

        return $result;
    }

    /**
     * Generates a unique transaction number for the order.
     *
     * @return string The generated transaction number.
     */
    public static function generate_trans_num()
    {
        return uniqid(self::$local_trans_num_prefix);
    }

    /**
     * Whether a gateway issued the given order transaction number.
     *
     * An order is constructed with a locally generated number and keeps it
     * until a gateway stores the number of the charge that paid its rows. So a
     * false answer means no processor ever issued this number, and nothing may
     * present it as one.
     *
     * @param  string $trans_num The order's transaction number.
     * @return boolean
     */
    public static function has_gateway_trans_num(string $trans_num): bool
    {
        return $trans_num !== '' && strpos($trans_num, self::$local_trans_num_prefix) !== 0;
    }

    /**
     * Get an order by ID
     *
     * @param  integer $id          The order ID.
     * @param  string  $return_type Optional. The required return type. One of OBJECT, ARRAY_A, or ARRAY_N, which
     *                             correspond to an stdClass object, an associative array, or a numeric array,
     *                             respectively. Default OBJECT.
     * @return array|object|null Database query result in format specified by $return_type or null on failure.
     */
    public static function get_one($id, $return_type = OBJECT)
    {
        $mepr_db = new MeprDb();
        $args    = compact('id');

        return $mepr_db->get_one_record($mepr_db->orders, $args, $return_type);
    }

    /**
     * Whether any order records the given gateway transaction number.
     *
     * An order carries the number the gateway gave its settling charge, while
     * its transaction rows carry synthetic numbers, so this answers whether a
     * gateway transaction is one this site captured at checkout.
     *
     * @param  string $trans_num The gateway transaction number.
     * @return boolean
     */
    public static function trans_num_exists(string $trans_num): bool
    {
        if ($trans_num === '') {
            return false;
        }

        $mepr_db = new MeprDb();

        return $mepr_db->get_count($mepr_db->orders, compact('trans_num')) > 0;
    }

    /**
     * Get all transactions associated with the order.
     *
     * @return array An array of transaction records.
     */
    public function get_transactions()
    {
        global $wpdb;
        $transaction_table = $wpdb->prefix . 'mepr_transactions';
        $mepr_db           = new MeprDb();

        return $mepr_db->get_records($transaction_table, ['order_id' => $this->id]);
    }

    /**
     * Whether to show tax for this order: tax was enabled at order time (recorded flag) or any
     * line carries tax — independent of the current global setting.
     *
     * @param  array|null $transactions The order's transactions; fetched if not supplied.
     * @return boolean
     */
    public function should_display_tax(?array $transactions = null): bool
    {
        if ((string) $this->get_meta('_mepr_tax_enabled', true) === '1') {
            return true;
        }

        $transactions = $transactions ?? $this->get_transactions();
        foreach ((array) $transactions as $txn) {
            // Include reverse-charge lines (tax_amount = 0 but rate / reversal identity stored).
            if (
                (float) $txn->tax_amount > 0
                || (float) $txn->tax_rate > 0
                || (float) $txn->tax_reversal_amount > 0
            ) {
                return true;
            }
        }

        return false;
    }

    /**
     * Whether prices on this order were entered inclusive of tax (frozen at create).
     * Falls back to the current site setting for pre-freeze orders.
     */
    public function is_tax_inclusive()
    {
        $frozen = $this->get_meta('_mepr_tax_inclusive', true);
        if ($frozen === '1' || $frozen === '0' || $frozen === 1 || $frozen === 0) {
            return (string) $frozen === '1';
        }

        return class_exists('MeprCartTaxService') && MeprCartTaxService::is_inclusive();
    }

    // -------------------------------------------------------------------------
    // Order notes
    // -------------------------------------------------------------------------

    /**
     * Add a note to this order.
     *
     * Stores a JSON-encoded note as order meta with key `_mepr_order_note`.
     * Multiple notes are allowed (add_meta uses $unique=false by default).
     *
     * @param  string       $message The note message text.
     * @param  string       $type    Note type: 'system', 'admin', or 'customer'.
     * @param  integer|null $user_id Optional WordPress user ID of the note author.
     * @return integer The meta ID of the newly inserted note, or 0 on failure.
     */
    public function add_note(string $message, string $type = 'system', ?int $user_id = null): int
    {
        $note = [
            'message'    => $message,
            'type'       => $type,
            'user_id'    => $user_id,
            'created_at' => current_time('mysql', true), // UTC timestamp.
        ];

        // The wp_slash() helper pre-slashes so add_metadata's wp_unslash() preserves JSON escape sequences (e.g. \n → \\n → \n).
        $meta_id = $this->add_meta(self::$order_note_key, wp_slash(wp_json_encode($note)));

        return $meta_id ? (int) $meta_id : 0;
    }

    /**
     * Get all notes for this order, sorted newest first.
     *
     * Retrieves all meta entries stored under the `_mepr_order_note` key,
     * JSON-decodes each value, and returns them sorted by `created_at` descending.
     *
     * @return array[] Array of note arrays: [{message, type, user_id, created_at}, ...].
     */
    public function get_notes(): array
    {
        $raw_values = $this->get_meta(self::$order_note_key, false);

        if (empty($raw_values) || !is_array($raw_values)) {
            return [];
        }

        $notes = [];

        foreach ($raw_values as $value) {
            $decoded = is_string($value) ? json_decode($value, true) : $value;

            if (is_array($decoded)) {
                $notes[] = $decoded;
            }
        }

        // Sort newest first.
        usort($notes, static function (array $a, array $b): int {
            return strcmp($b['created_at'] ?? '', $a['created_at'] ?? '');
        });

        return $notes;
    }

    /**
     * Add an automatic status-change note.
     *
     * @param  string       $old_status Previous order status.
     * @param  string       $new_status New order status.
     * @param  integer|null $user_id    Optional user ID (admin who changed the status).
     * @return void
     */
    public function add_status_change_note(string $old_status, string $new_status, ?int $user_id = null): void
    {
        $message = sprintf(
            // Translators: 1: old status, 2: new status.
            __('Status changed from %1$s to %2$s', 'memberpress'),
            $old_status,
            $new_status
        );

        if ($user_id) {
            $user = get_userdata($user_id);
            if ($user) {
                $message .= ' ' . sprintf(
                    // Translators: %s: display name.
                    __('by %s', 'memberpress'),
                    $user->display_name
                );
            }
        }

        $this->add_note($message, 'system', $user_id);
    }

    /**
     * Add a refund note to the order.
     *
     * For a per-line-item refund, pass the line's product title and transaction number so the audit
     * note records which line was refunded (frozen at refund time). Order-level refunds omit them.
     *
     * @param  float        $amount        The refunded amount.
     * @param  string       $reason        Optional reason for the refund.
     * @param  integer|null $user_id       Optional user ID of the admin who issued the refund.
     * @param  string       $product_title Optional product title of the refunded line.
     * @param  string       $trans_num     Optional transaction number of the refunded line.
     * @return void
     */
    public function add_refund_note(float $amount, string $reason = '', ?int $user_id = null, string $product_title = '', string $trans_num = ''): void
    {
        $message = sprintf(
            // Translators: %s: formatted currency amount.
            __('Refunded $%s', 'memberpress'),
            number_format($amount, 2)
        );

        if ('' !== $product_title) {
            $message .= ' — ' . $product_title;
            if ('' !== $trans_num) {
                $message .= sprintf(
                    // Translators: %s: transaction number.
                    ' (' . __('Txn %s', 'memberpress') . ')',
                    $trans_num
                );
            }
        }

        if (!empty($reason)) {
            $message .= ': ' . $reason;
        }

        $this->add_note($message, 'system', $user_id);
    }

    /**
     * Add a cancellation note to the order.
     *
     * For a per-line-item cancel, pass the line's product title and transaction number so the audit
     * note records which line was cancelled (frozen at cancel time). Order-level cancels omit them
     * and keep the "Order cancelled" wording.
     *
     * @param  string       $reason          Optional reason for the cancellation.
     * @param  integer|null $user_id         Optional user ID of the admin who cancelled.
     * @param  float        $refunded_amount Optional refund amount (order-level cancel with refund).
     * @param  string       $product_title   Optional product title of the cancelled line.
     * @param  string       $trans_num       Optional transaction number of the cancelled line.
     * @return void
     */
    public function add_cancellation_note(string $reason = '', ?int $user_id = null, float $refunded_amount = 0.0, string $product_title = '', string $trans_num = ''): void
    {
        if ('' !== $product_title) {
            // Per-line cancel — mirror add_refund_note style (product + Txn ref).
            $message = __('Cancelled', 'memberpress');
            $message .= ' — ' . $product_title;
            if ('' !== $trans_num) {
                $message .= sprintf(
                    // Translators: %s: transaction number.
                    ' (' . __('Txn %s', 'memberpress') . ')',
                    $trans_num
                );
            }
        } else {
            $message = __('Order cancelled', 'memberpress');

            if ($refunded_amount > 0) {
                $message .= ' — ' . sprintf(
                    // Translators: %s: formatted currency amount.
                    __('refund of %s processed', 'memberpress'),
                    MeprAppHelper::format_currency($refunded_amount, true, false)
                );
            }
        }

        if (!empty($reason)) {
            $message .= ': ' . $reason;
        }

        $this->add_note($message, 'system', $user_id);
    }

    /**
     * Checks if the order is complete.
     *
     * @return boolean True if the order is complete, false otherwise.
     */
    public function is_complete()
    {
        return $this->status === MeprOrder::$complete_str;
    }

    /**
     * Checks if the order is processing.
     *
     * @return boolean True if the order is processing, false otherwise.
     */
    public function is_processing()
    {
        return $this->get_meta('processing', true) === '1';
    }
}
