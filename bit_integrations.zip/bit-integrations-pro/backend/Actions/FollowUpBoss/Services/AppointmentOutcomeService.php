<?php

namespace BitApps\IntegrationsPro\Actions\FollowUpBoss\Services;

final class AppointmentOutcomeService extends BaseService
{
    public function createAppointmentOutcome(): array
    {
        $validationRules = [
            'name'         => ['required'],
            'order_weight' => ['nullable', 'integer'],
        ];
        $error = $this->validateFields(
            $validationRules,
            [
                'name'         => __('Name', 'bit-integrations-pro'),
                'order_weight' => __('Sort Order', 'bit-integrations-pro'),
            ]
        );

        if ($error !== null) {
            return $error;
        }

        $payload = $this->removeEmptyValues(
            [
                'name'        => $this->getString('name'),
                'orderWeight' => $this->getInteger('order_weight'),
            ]
        );

        return $this->dispatch('POST', '/appointmentOutcomes', $payload);
    }

    public function updateAppointmentOutcome(): array
    {
        $validationRules = [
            'outcome_id'   => ['required', 'integer'],
            'order_weight' => ['nullable', 'integer'],
        ];
        $error = $this->validateFields(
            $validationRules,
            [
                'outcome_id'   => __('Appointment Outcome ID', 'bit-integrations-pro'),
                'order_weight' => __('Sort Order', 'bit-integrations-pro'),
            ]
        );

        if ($error !== null) {
            return $error;
        }

        $payload = $this->removeEmptyValues(
            [
                'name'        => $this->getString('name'),
                'orderWeight' => $this->getInteger('order_weight'),
            ]
        );

        return $this->dispatch('PUT', '/appointmentOutcomes/' . rawurlencode($this->getString('outcome_id')), $payload);
    }

    public function deleteAppointmentOutcome(): array
    {
        $validationRules = [
            'outcome_id'        => ['required', 'integer'],
            'assign_outcome_id' => ['required', 'integer'],
        ];
        $error = $this->validateFields(
            $validationRules,
            [
                'outcome_id'        => __('Appointment Outcome ID', 'bit-integrations-pro'),
                'assign_outcome_id' => __('Move Appointments To', 'bit-integrations-pro'),
            ],
            ['assign_outcome_id']
        );

        if ($error !== null) {
            return $error;
        }

        $query = $this->removeEmptyValues(
            [
                'assignOutcomeId' => $this->getInteger('assign_outcome_id'),
            ]
        );

        return $this->dispatch('DELETE', '/appointmentOutcomes/' . rawurlencode($this->getString('outcome_id')), null, $query);
    }
}
