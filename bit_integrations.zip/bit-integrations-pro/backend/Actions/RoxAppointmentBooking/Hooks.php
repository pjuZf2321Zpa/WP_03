<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Actions\RoxAppointmentBooking\RoxAppointmentBookingProHelper;
use BitApps\IntegrationsPro\Config;
use BitApps\IntegrationsPro\Core\Util\Hooks;

Hooks::filter(Config::withFreePrefix('rox_appointment_booking_create_customer'), [RoxAppointmentBookingProHelper::class, 'createCustomer'], 10, 2);
Hooks::filter(Config::withFreePrefix('rox_appointment_booking_update_customer'), [RoxAppointmentBookingProHelper::class, 'updateCustomer'], 10, 2);
Hooks::filter(Config::withFreePrefix('rox_appointment_booking_delete_customer'), [RoxAppointmentBookingProHelper::class, 'deleteCustomer'], 10, 2);
Hooks::filter(Config::withFreePrefix('rox_appointment_booking_update_agent'), [RoxAppointmentBookingProHelper::class, 'updateAgent'], 10, 2);
Hooks::filter(Config::withFreePrefix('rox_appointment_booking_delete_agent'), [RoxAppointmentBookingProHelper::class, 'deleteAgent'], 10, 2);
Hooks::filter(Config::withFreePrefix('rox_appointment_booking_update_service'), [RoxAppointmentBookingProHelper::class, 'updateService'], 10, 2);
Hooks::filter(Config::withFreePrefix('rox_appointment_booking_delete_service'), [RoxAppointmentBookingProHelper::class, 'deleteService'], 10, 2);
Hooks::filter(Config::withFreePrefix('rox_appointment_booking_create_category'), [RoxAppointmentBookingProHelper::class, 'createCategory'], 10, 2);
Hooks::filter(Config::withFreePrefix('rox_appointment_booking_update_category'), [RoxAppointmentBookingProHelper::class, 'updateCategory'], 10, 2);
Hooks::filter(Config::withFreePrefix('rox_appointment_booking_delete_category'), [RoxAppointmentBookingProHelper::class, 'deleteCategory'], 10, 2);
Hooks::filter(Config::withFreePrefix('rox_appointment_booking_update_appointment'), [RoxAppointmentBookingProHelper::class, 'updateAppointment'], 10, 3);
Hooks::filter(Config::withFreePrefix('rox_appointment_booking_delete_appointment'), [RoxAppointmentBookingProHelper::class, 'deleteAppointment'], 10, 2);
Hooks::filter(Config::withFreePrefix('rox_appointment_booking_update_order'), [RoxAppointmentBookingProHelper::class, 'updateOrder'], 10, 2);
Hooks::filter(Config::withFreePrefix('rox_appointment_booking_refund_order'), [RoxAppointmentBookingProHelper::class, 'refundOrder'], 10, 2);
Hooks::filter(Config::withFreePrefix('rox_appointment_booking_delete_order'), [RoxAppointmentBookingProHelper::class, 'deleteOrder'], 10, 2);
Hooks::filter(Config::withFreePrefix('rox_appointment_booking_create_agent'), [RoxAppointmentBookingProHelper::class, 'createAgent'], 10, 4);
Hooks::filter(Config::withFreePrefix('rox_appointment_booking_create_service'), [RoxAppointmentBookingProHelper::class, 'createService'], 10, 3);
Hooks::filter(Config::withFreePrefix('rox_appointment_booking_create_appointment'), [RoxAppointmentBookingProHelper::class, 'createAppointment'], 10, 4);
Hooks::filter(Config::withFreePrefix('rox_appointment_booking_create_order'), [RoxAppointmentBookingProHelper::class, 'createOrder'], 10, 3);
Hooks::filter(Config::withFreePrefix('rox_appointment_booking_create_payment'), [RoxAppointmentBookingProHelper::class, 'createPayment'], 10, 3);
Hooks::filter(Config::withFreePrefix('rox_appointment_booking_create_notification'), [RoxAppointmentBookingProHelper::class, 'createNotification'], 10, 3);
Hooks::filter(Config::withFreePrefix('rox_appointment_booking_update_service_status'), [RoxAppointmentBookingProHelper::class, 'updateServiceStatus'], 10, 3);
Hooks::filter(Config::withFreePrefix('rox_appointment_booking_update_appointment_status'), [RoxAppointmentBookingProHelper::class, 'updateAppointmentStatus'], 10, 3);
Hooks::filter(Config::withFreePrefix('rox_appointment_booking_update_order_status'), [RoxAppointmentBookingProHelper::class, 'updateOrderStatus'], 10, 3);
Hooks::filter(Config::withFreePrefix('rox_appointment_booking_update_payment_status'), [RoxAppointmentBookingProHelper::class, 'updatePaymentStatus'], 10, 3);
