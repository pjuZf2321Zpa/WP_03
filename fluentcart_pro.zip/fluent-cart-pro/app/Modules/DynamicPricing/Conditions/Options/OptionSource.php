<?php

namespace FluentCartPro\App\Modules\DynamicPricing\Conditions\Options;

/**
 * Defines a reusable source for options used by the condition builder.
 *
 * Each source provides a unique data key, the options available for that key,
 * and the permission check required to access them. The shared registration
 * and option-limit handling live here so individual sources only need to
 * provide their own data and access rules.
 *
 * A condition attribute references a source through its `data_key`. The
 * condition picker then uses that key to request the corresponding options
 * from the shared advanced-filter endpoint.
 *
 * To add a new option source, create a subclass and register it in
 * DynamicPricingInit.
 *
 * @package FluentCartPro\App\Modules\DynamicPricing
 *
 * @version 1.0.0
 */
abstract class OptionSource
{
    /**
     * Maximum number of options a source can return in a single request.
     *
     * Sources with larger or more expensive rows can override this value
     * when necessary.
     */
    const MAX_OPTION_LIMIT = 100;

    /**
     * Default number of options returned when no limit is provided.
     */
    const DEFAULT_OPTION_LIMIT = 20;

    /**
     * Unique key used to identify this option source.
     *
     * Condition attributes use this value as their `data_key`, allowing the
     * picker to request options from the correct source.
     *
     * @var string
     */
    protected $key = '';

    /**
     * Return the available options for this source.
     *
     * Options should be returned as flat `{value, label}` pairs so they can
     * be consumed directly by the condition picker.
     *
     * @param array $options
     * @param array $args
     * @return array
     */
    abstract public function options($options, $args);

    /**
     * Determine whether the current user can access this source.
     *
     * @param bool $hasPermission
     * @return bool
     */
    abstract public function canRead($hasPermission);

    /**
     * Get the unique key assigned to this option source.
     *
     * This allows condition attributes to reference the source through
     * `data_key` without duplicating the key value elsewhere.
     *
     * @return string
     */
    public function key(): string
    {
        return $this->key;
    }

    /**
     * Register this source with the advanced-filter option system.
     *
     * The source's key is used to register both the option provider and its
     * permission check with the corresponding filter hooks.
     *
     * A source without a key cannot be requested by the condition picker,
     * so registration is skipped.
     *
     * @return void
     */
    public function register()
    {
        if (!$this->key) {
            return;
        }

        add_filter('fluent_cart/advanced_filter_options_' . $this->key, [$this, 'options'], 10, 2);
        add_filter('fluent_cart/advanced_filter_options_permission_' . $this->key, [$this, 'canRead']);
    }

    /**
     * Normalize and constrain the requested option limit.
     *
     * A missing or invalid limit falls back to the default page size, while
     * larger values are capped at the maximum allowed limit. This prevents
     * an option request from loading an unnecessarily large number of rows.
     *
     * @param mixed $limit
     * @return int
     */
    protected function boundedLimit($limit): int
    {
        $limit = intval($limit);

        if ($limit < 1) {
            return static::DEFAULT_OPTION_LIMIT;
        }

        return min($limit, static::MAX_OPTION_LIMIT);
    }
}