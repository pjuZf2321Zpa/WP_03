<?php
/**
 * "Blog Subscriptions" settings tab content: the current user's subscribed
 * blog categories with an Unsubscribe control.
 *
 * @package BuddyBossPro
 *
 * @since 3.1.0
 */

defined( 'ABSPATH' ) || exit;

$bb_blog_subs = function_exists( 'bb_get_subscriptions' )
	? bb_get_subscriptions(
		array(
			'type'     => 'blog_category',
			'user_id'  => get_current_user_id(),
			'fields'   => 'all',
			'count'    => false,
			'per_page' => -1,
		),
		true
	)
	: array( 'subscriptions' => array() );

$bb_blog_sub_rows = ! empty( $bb_blog_subs['subscriptions'] ) ? $bb_blog_subs['subscriptions'] : array();
?>
<?php bp_get_template_part( 'members/single/parts/notification-subnav' ); ?>
<div class="bb-blog-subscriptions-list">
	<?php
	if ( empty( $bb_blog_sub_rows ) ) {
		echo '<p class="bb-blog-subscriptions-empty"><i class="bb-icons-rl-info"></i>' . esc_html__( 'You are not subscribed to any blog categories yet.', 'buddyboss-pro' ) . '</p>';
	} else {
		foreach ( $bb_blog_sub_rows as $bb_blog_sub ) {
			$bb_term = get_term( (int) $bb_blog_sub->item_id, 'category' );

			if ( empty( $bb_term ) || is_wp_error( $bb_term ) ) {
				continue;
			}
			?>
			<div class="bb-blog-subscription-item">
				<span class="bb-blog-subscription-item__icon"><i class="bb-icons-rl-push-pin" aria-hidden="true"></i></span>
				<span class="bb-blog-subscription-item__meta">
					<span class="bb-blog-subscription-item__name"><?php echo esc_html( $bb_term->name ); ?></span>
					<span class="bb-blog-subscription-item__count">
						<?php
						/* translators: %d: number of posts. */
						printf( esc_html( _n( '%d Post on this topic', '%d Posts on this topic', (int) $bb_term->count, 'buddyboss-pro' ) ), (int) $bb_term->count );
						?>
					</span>
				</span>
				<button type="button"
					class="bb-blog-subscribe is-subscribed"
					data-term-id="<?php echo esc_attr( $bb_term->term_id ); ?>"
					data-subscription-id="<?php echo esc_attr( $bb_blog_sub->id ); ?>"
					data-bb-remove-on-unsub="1"
					aria-pressed="true">
					<span class="bb-blog-subscribe__label"><?php esc_html_e( 'Unsubscribe', 'buddyboss-pro' ); ?></span>
				</button>
			</div>
			<?php
		}
	}
	?>
</div>
