<?php

namespace MasterStudy\Lms\Pro\addons\certificate_builder\Routing\Swagger;

use MasterStudy\Lms\Routing\Swagger\RequestInterface;
use MasterStudy\Lms\Routing\Swagger\ResponseInterface;
use MasterStudy\Lms\Routing\Swagger\Route;

class BulkDeleteAdminCertificates extends Route implements RequestInterface, ResponseInterface {
	public function request(): array {
		return array(
			'certificates' => array(
				'type'        => 'array',
				'description' => 'Array of certificates or certificate IDs to delete.',
				'required'    => true,
			),
		);
	}

	public function response(): array {
		return array(
			'success' => array(
				'type' => 'boolean',
			),
		);
	}

	public function get_summary(): string {
		return 'Bulk Delete Admin Certificates';
	}

	public function get_description(): string {
		return 'Deletes certificates for the React admin certificates page.';
	}
}
