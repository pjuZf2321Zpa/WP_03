<template>
  <div class="fct-form-container fct-saved-payment-methods-section">
    <div class="form-left">
      <h3 class="form-heading">{{ translate('Payment Methods') }}</h3>
      <p class="form-desc">
        {{ translate('Your card details are never stored on this site. Your payment provider keeps them and gives us a secure token, which is only charged when you place an order or a subscription renews.') }}
      </p>

      <fct-button
          v-if="stripeReady"
          size="small"
          @click="showAddDialog"
      >
        {{ translate('Add payment method') }}
      </fct-button>
    </div>

    <div class="form-right">
      <div
          v-if="cards.length"
          class="fct-payment-methods-list"
          role="list"
          :aria-label="translate('Payment Methods')"
      >
        <div v-for="card in cards" :key="card.id" class="fct-payment-method" role="listitem">
          <span class="fct-payment-method-brand">{{ brandTag(card) }}</span>

          <div class="fct-payment-method-info">
            <div class="fct-payment-method-title">
              {{ cardTitle(card) }}

              <Badge v-if="card.is_default" size="small" hide-icon high-contrast>
                {{ translate('Default') }}
              </Badge>

              <Badge v-if="card.in_use_by_subscription" size="small" hide-icon>
                {{ translate('On a subscription') }}
              </Badge>
            </div>

            <div v-if="cardExpiry(card)" class="fct-payment-method-meta">
              {{ cardExpiry(card) }}
            </div>
          </div>

          <div class="fct-payment-method-actions">
            <fct-button
                v-if="!card.is_default"
                size="small"
                :loading="busyId === card.id"
                :disabled="isRowLocked(card)"
                @click="makeDefault(card)"
            >
              {{ translate('Set as default') }}
            </fct-button>

            <fct-popover confirm
                v-if="!card.in_use_by_subscription"
                :title="translate('Remove this saved payment method? Once removed, it cannot be used for future payments in this store.')"
                :confirm-button-text="translate('Remove card')"
                :cancel-button-text="translate('Cancel')"
                width="260"
                @confirm="removeCard(card)"
                popper-class="fluent-cart-customer-profile-app"
            >
              <template #reference>
                <fct-button
                    size="small"
                    :loading="busyId === card.id"
                    :disabled="isRowLocked(card)"
                >
                  {{ translate('Remove') }}
                </fct-button>
              </template>
            </fct-popover>

            <fct-button
                v-else
                size="small"
                disabled
                :title="translate('In use by a subscription')"
            >
              {{ translate('Remove') }}
            </fct-button>
          </div>
        </div>
      </div>

      <div v-else class="fct-payment-methods-empty">
        <p class="fct-payment-methods-empty-title">{{ translate('No saved cards yet') }}</p>
        <p class="fct-payment-methods-empty-text">
          {{ translate('Add a card for one-tap checkout on your next purchase.') }}
        </p>
      </div>
    </div>

    <fct-dialog
        v-model="dialogVisible"
        :title="translate('Add a payment method')"
        :close-on-click-modal="!saving"
        :close-on-press-escape="!saving"
        :show-close="!saving"
        :before-close="handleBeforeClose"
        width="460px"
        append-to-body
        @opened="mountCardFields"
        @closed="teardownCardFields"
        class="fluent-cart-customer-profile-app"
    >
      <div class="fct-payment-method-field">
        <label for="fct-pm-cardholder">{{ translate('Cardholder name') }}</label>
        <fct-input id="fct-pm-cardholder" v-model="cardholderName" autocomplete="cc-name"/>
      </div>

      <div class="fct-payment-method-field">
        <label>{{ translate('Card number') }}</label>
        <div ref="cardNumber" class="fct-payment-method-element"></div>
      </div>

      <div class="fct-payment-method-field-row">
        <div class="fct-payment-method-field">
          <label>{{ translate('Expiry') }}</label>
          <div ref="cardExpiry" class="fct-payment-method-element"></div>
        </div>

        <div class="fct-payment-method-field">
          <label>{{ translate('CVC') }}</label>
          <div ref="cardCvc" class="fct-payment-method-element"></div>
        </div>
      </div>

      <fct-choice v-model="setAsDefault">
        {{ translate('Set as default payment method') }}
      </fct-choice>

      <!-- Announced on change: both appear after the customer has moved focus
           into the card fields, so a silent update would be missed. -->
      <p v-if="attemptsNotice" class="fct-payment-method-notice" role="status" aria-live="polite">
        {{ attemptsNotice }}
      </p>
      <p v-if="errorMessage" class="fct-payment-method-error" role="alert">
        {{ errorMessage }}
      </p>

      <template #footer>
        <fct-button :disabled="saving" @click="dialogVisible = false">
          {{ translate('Cancel') }}
        </fct-button>
        <fct-button
            type="primary"
            :loading="saving"
            :disabled="!cardFields"
            @click="submitCard"
        >
          {{ translate('Add card') }}
        </fct-button>
      </template>
    </fct-dialog>
  </div>
</template>

<script>
/**
 * Saved Payment Methods — customer-portal section.
 *
 * Shipped UNCOMPILED: core reads this file as a string and compiles it in the
 * browser (see DynamicTemplateParser in fluent-cart). Consequences:
 *
 *   - Options API only — there is no build step to compile `<script setup>`.
 *   - A `<style>` block here is IGNORED, and Tailwind's JIT never scans this
 *     file, so use only the semantic classes core defines in
 *     `customer-profile/style/scss/portal-sections.scss`.
 *   - Browser globals — the page object, the DOM entry point, network calls,
 *     timers — are shadowed AND rejected on sight, INCLUDING when they appear
 *     inside a comment, because the scanner reads the raw script text. Card
 *     entry therefore goes through the injected `StripeElements` facade, which
 *     takes `$refs` nodes rather than CSS selectors.
 *   - Several innocuous-looking bare words are rejected too, so aliasing the
 *     component instance the traditional way will not compile — use arrow
 *     functions and keep `this`. Check BLOCKED_SCRIPT_PATTERNS in the parser
 *     before reaching for any global-sounding identifier.
 *
 * Injected by the host: Rest, Notify, translate, StripeElements, Badge, Vue.
 */
export default {
  components: {
    Badge
  },

  props: {
    payload: {
      type: Object,
      required: true
    }
  },

  data: function () {
    return {
      cards: this.payload.cards || [],
      dialogVisible: false,
      cardholderName: '',
      setAsDefault: true,
      saving: false,
      busyId: '',
      errorMessage: '',
      remainingAttempts: null,
      // The mounted Stripe controller. Frozen by the facade, so Vue leaves it
      // unproxied and the Stripe internals never end up behind a reactive
      // proxy.
      cardFields: null
    };
  },

  computed: {
    /**
     * `typeof` guard, not a truthiness check: when the capability script has
     * not loaded, the identifier is undeclared rather than undefined, and a
     * bare reference would throw during render and take the whole section
     * down. Degrade to a read-only card list instead.
     */
    stripeReady: function () {
      return typeof StripeElements !== 'undefined'
          && StripeElements.isConfigured(this.payload.stripe_key);
    },

    attemptsNotice: function () {
      if (this.remainingAttempts === null || this.remainingAttempts > 2) {
        return '';
      }

      /* translators: %1$s: number of remaining card verification attempts */
      return translate('%1$s verification attempts left today.', this.remainingAttempts);
    }
  },

  beforeUnmount: function () {
    this.teardownCardFields();
  },

  methods: {
    translate: translate,

    isPayPal: function (card) {
      return card.gateway === 'paypal';
    },

    brandTag: function (card) {
      if (this.isPayPal(card)) {
        return 'PYPL';
      }

      var brand = card.brand ? String(card.brand) : 'card';

      return brand.substring(0, 4).toUpperCase();
    },

    cardTitle: function (card) {
      // A PayPal entry is an account, identified by the payer email — it has no
      // brand or last4, so the card formatting below would render "Card ••••".
      if (this.isPayPal(card)) {
        return card.email ? card.email : translate('PayPal account');
      }

      var brand = card.brand
          ? String(card.brand).charAt(0).toUpperCase() + String(card.brand).slice(1)
          : translate('Card');

      /* translators: %1$s: card brand (e.g. Visa), %2$s: last 4 digits */
      return brand + ' ' + (card.last4 ? card.last4 : '••••');
    },

    cardExpiry: function (card) {
      // PayPal accounts do not expire; the row's v-if hides the line entirely.
      if (this.isPayPal(card)) {
        return '';
      }

      if (!card.exp_month || !card.exp_year) {
        return '';
      }

      var month = String(card.exp_month).length < 2 ? '0' + card.exp_month : String(card.exp_month);

      /* translators: %1$s: card expiry in MM/YYYY format */
      return translate('Expires %1$s', month + '/' + card.exp_year);
    },

    /**
     * Never let a second mutation start while one is in flight.
     */
    isRowLocked: function (card) {
      return this.busyId !== '' && this.busyId !== card.id;
    },

    readError: function (error) {
      // An Error from the Stripe facade carries `.message`; a rejected Rest
      // call carries the parsed body under `.data`.
      if (error && error.message) {
        return error.message;
      }

      if (error && error.data && error.data.message) {
        return error.data.message;
      }

      return translate('Something went wrong. Please try again.');
    },

    showAddDialog: function () {
      this.errorMessage = '';
      this.cardholderName = '';
      this.setAsDefault = true;
      this.dialogVisible = true;
      this.loadAttempts();
    },

    /**
     * Backstop for every close path (icon, Escape, overlay click): while a
     * submission is in flight, `saving` may lag behind the closing request
     * from an already-registered listener, so refusing here (instead of only
     * hiding the icon/disabling Escape) guarantees `teardownCardFields` never
     * runs out from under an active createPaymentMethod/confirmCardSetup call.
     */
    handleBeforeClose: function (done) {
      if (this.saving) {
        return;
      }

      done();
    },

    /**
     * Bound to the dialog's `opened` event rather than nextTick: the dialog
     * renders its body lazily, so the ref nodes only exist once the open
     * transition has finished.
     */
    mountCardFields: function () {
      if (this.cardFields) {
        return;
      }

      StripeElements.mountCard({
        publishableKey: this.payload.stripe_key,
        numberEl: this.$refs.cardNumber,
        expiryEl: this.$refs.cardExpiry,
        cvcEl: this.$refs.cardCvc
      }).then((controller) => {
        this.cardFields = controller;
      }).catch((error) => {
        this.errorMessage = this.readError(error);
      });
    },

    teardownCardFields: function () {
      if (this.cardFields) {
        this.cardFields.destroy();
        this.cardFields = null;
      }
    },

    loadAttempts: function () {
      Rest.get(this.payload.rest_base + '/setup-intent-attempts').then((response) => {
        this.remainingAttempts = response && typeof response.remaining !== 'undefined'
            ? response.remaining
            : null;
      }).catch(() => {
        // Only drives an advisory notice — never block the form over it.
        this.remainingAttempts = null;
      });
    },

    submitCard: function () {
      if (this.saving || !this.cardFields) {
        return;
      }

      this.saving = true;
      this.errorMessage = '';

      var billingDetails = this.cardholderName ? {name: this.cardholderName} : {};

      this.cardFields.createPaymentMethod(billingDetails)
          .then((paymentMethod) => this.finalizeCard({
            payment_method_id: paymentMethod.id,
            set_default: this.setAsDefault ? 'yes' : 'no'
          }, paymentMethod.id))
          .catch((error) => {
            // Dialog stays open so the customer can correct and retry.
            this.errorMessage = this.readError(error);
          })
          .finally(() => {
            this.saving = false;
          });
    },

    /**
     * Post the card, and re-enter once through the SCA / 3DS branch: the
     * endpoint answers `requires_action` with a client secret, the customer
     * authenticates, then the same call is repeated with the setup intent id.
     */
    finalizeCard: function (body, paymentMethodId) {
      return Rest.post(this.payload.rest_base, body).then((response) => {
        if (response.status === 'requires_action') {
          return this.cardFields
              .confirmCardSetup(response.client_secret, paymentMethodId)
              .then(() => this.finalizeCard({
                setup_intent_id: response.setup_intent_id,
                set_default: body.set_default
              }, paymentMethodId));
        }

        // Success only — the list, the dialog and the toast must not move on
        // a failed attempt.
        this.cards = response.data || [];
        this.dialogVisible = false;
        Notify.success(response.message || translate('Card saved'));
      });
    },

    makeDefault: function (card) {
      if (this.busyId) {
        return;
      }

      this.busyId = card.id;

      Rest.post(this.payload.rest_base + '/' + card.id + '/default')
          .then((response) => {
            this.cards = response.data || this.cards;
            Notify.success(translate('Default payment method updated'));
          })
          .catch((error) => {
            Notify.error(this.readError(error));
          })
          .finally(() => {
            this.busyId = '';
          });
    },

    removeCard: function (card) {
      if (this.busyId) {
        return;
      }

      this.busyId = card.id;

      Rest.delete(this.payload.rest_base + '/' + card.id)
          .then((response) => {
            this.cards = response.data || [];
            Notify.success(translate('Card removed'));
          })
          .catch((error) => {
            Notify.error(this.readError(error));
          })
          .finally(() => {
            this.busyId = '';
          });
    }
  }
};
</script>
