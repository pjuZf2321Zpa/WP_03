<?php
/**
 * Plugin information for the WordPress Plugins screen.
 *
 * Loaded unconditionally from the main plugin file rather than from
 * BB_Platform_Pro::includes(), because the plugin-information modal is rendered
 * by WordPress for any installed plugin whether or not this one boots - and
 * this one declines to boot whenever BuddyBoss Platform is absent, inactive or
 * older than 1.3.4, which is precisely when someone opens "View details" to
 * find out why. Registered from includes/bb-pro-core-actions.php, the handler
 * disappeared in exactly those cases and the modal fell through to
 * WordPress.org, which answers "Plugin not found."
 *
 * The handler's helpers moved with it. Moving the add_filter() alone would have
 * pointed it at functions that bb-pro-core-functions.php never defines on the
 * requests this file exists to serve.
 *
 * Mirrors buddyboss-learndash/includes/bb-learndash-plugin-information.php and
 * buddyboss-offload-media/includes/bb-om-plugin-information.php.
 *
 * @package BuddyBossPro
 *
 * @since 3.3.2
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

/**
 * Get the BuddyBoss Platform admin object, when there is one to talk to.
 *
 * The release-notes helpers this plugin borrows live on it. Platform can be
 * absent, inactive, or older than those helpers, so every call site probes the
 * method it wants before using it and falls back to a local implementation.
 *
 * The probe is is_callable() and never method_exists(). method_exists()
 * answers true for a protected method, so a Platform that carries one of
 * these helpers without having exposed it would pass the guard and then fatal
 * with "Call to protected method ... from global scope" - turning the graceful
 * degrade this whole file is built on into an uncaught Error. That is not
 * hypothetical: five of the helpers probed below shipped protected before they
 * shipped public. The blast radius is not only the plugin-information modal -
 * plugins.php calls WP_Plugin_Dependencies::initialize() before it builds the
 * list table, and that reaches plugins_api() for every slug named in any
 * installed plugin's "Requires Plugins" header, so a throw there takes the
 * whole Plugins screen down and, because the fatal precedes the transient
 * write that would short-circuit it, does so on every subsequent load.
 * is_callable() is evaluated from this scope, so it answers false for anything
 * this file could not legally call, and the local fallback runs instead.
 *
 * @since 3.3.2
 *
 * @return object|null Platform admin object, or null when unavailable.
 */
function bb_pro_get_platform_admin() {
	if ( ! function_exists( 'buddypress' ) ) {
		return null;
	}

	$bp = buddypress();

	return ! empty( $bp->admin ) && is_object( $bp->admin ) ? $bp->admin : null;
}

/**
 * This plugin's basename, as WordPress keys it.
 *
 * Derived from the plugin directory rather than read off bb_platform_pro(),
 * whose 'basename' is plugin_basename( __FILE__ ) evaluated inside
 * class-bb-platform-pro.php and therefore names that class file, not the plugin.
 * dirname() of it still answers 'buddyboss-platform-pro', which is why the slug
 * comparison worked, but it can never match a key in the 'update_plugins'
 * transient - core keys that by the plugin's main file - so the pending-update
 * lookup silently found nothing and the modal reported the installed version
 * for a "View version x.x.x details" link about a newer one.
 *
 * @since 3.3.2
 *
 * @return string Plugin basename, e.g. 'buddyboss-platform-pro/buddyboss-platform-pro.php'.
 */
function bb_pro_get_plugin_file() {
	/*
	 * The constant is defined in BB_Platform_Pro::constants(), which does not
	 * run when this plugin declines to boot - which is one of the cases this
	 * file is loaded for. dirname( __DIR__ ) is this plugin's directory whatever
	 * it has been renamed to, so the fallback resolves correctly there too,
	 * where a hardcoded 'buddyboss-platform-pro/...' would not.
	 */
	$dir = defined( 'BB_PLATFORM_PRO_PLUGIN_DIR' )
		? BB_PLATFORM_PRO_PLUGIN_DIR
		: trailingslashit( dirname( __DIR__ ) );

	return plugin_basename( $dir . 'buddyboss-platform-pro.php' );
}

/**
 * Read this plugin's entry from the 'update_plugins' site transient.
 *
 * The container is normalized rather than indexed where it is found. 'response'
 * is an array as core writes it, but a plugin that round-trips this transient
 * through JSON - which caching, staging-sync and update manager plugins do
 * routinely - hands back a stdClass, and indexing an object with [] is an
 * uncaught Error on PHP 8 rather than a notice. isset() is no protection here:
 * the dimension fetch is evaluated before the existence test, so it throws from
 * inside isset() itself, and it throws whether or not the property is present.
 * Casting to array restores the JSON shape to what core wrote, and disarms every
 * other object as well - the cast reads the property table and never calls
 * offsetExists(), so an ArrayAccess implementation whose offsetExists() throws
 * cannot reach out of here either. A container that is not an object at all
 * never gets indexed in the first place.
 *
 * @since 3.3.2
 *
 * @param string $plugin_file Plugin basename.
 *
 * @return object|null Update entry for the plugin, or null when there is none to read.
 */
function bb_pro_get_plugin_update_entry( $plugin_file ) {
	$update_data = get_site_transient( 'update_plugins' );

	$response = ( is_object( $update_data ) && isset( $update_data->response ) )
		? (array) $update_data->response
		: array();

	$update = isset( $response[ $plugin_file ] ) ? $response[ $plugin_file ] : null;

	// Third-party update managers are known to rewrite this transient with array
	// entries; reading a property off one warns under WP_DEBUG.
	return is_object( $update ) ? $update : null;
}

/**
 * Reduce a version number to a printable version, keeping a pre-release suffix.
 *
 * For the 'version' key of the plugin-information object, which core prints
 * through a short kses allowlist and then hands to version_compare() against
 * the installed header in install_plugin_install_status(). A pre-release header
 * such as 1.2.3-beta1 must therefore keep its suffix: the normalized 1.2.3 would
 * compare greater than the installed copy, and core answers that by deleting
 * the update_plugins transient and running a blocking update check on every
 * modal open. The normalizer is for URLs and lookups; this is for printing and
 * comparing. Mirrors BP_Admin::bb_sanitize_plugin_version().
 *
 * @since 3.3.2
 *
 * @param mixed $version Version from a plugin header or update feed.
 *
 * @return string Version safe to print and to compare, or an empty string.
 */
function bb_pro_sanitize_plugin_version( $version ) {
	if ( ! is_scalar( $version ) ) {
		return '';
	}

	$version = substr( trim( (string) $version ), 0, 128 );
	$version = (string) preg_replace( '/^[vV](?=[0-9])/', '', $version );

	// Anchored, so the result is a version and nothing else: digits and dots,
	// then an optional pre-release or build suffix introduced by '-' or '+'.
	// Anything after a character a version cannot contain is dropped, not
	// squeezed together: "9.9 <img>" is "9.9" and "3,4,4" is nothing at all.
	if ( ! preg_match( '/^[0-9]+(?:\.[0-9]+)+(?:[-+][0-9A-Za-z.+_-]*)?/', $version, $matches ) ) {
		return '';
	}

	return $matches[0];
}

/**
 * Reduce a version from the update feed to digits and dots.
 *
 * Core puts 'version' through install_plugin_information()'s own short
 * wp_kses() allowlist and then echoes it unescaped, and that allowlist still
 * passes links, images and class attributes - so an update feed is one
 * compromise away from putting markup in wp-admin through this key. The same
 * value also becomes a URL path segment and link text.
 *
 * @since 3.3.2
 *
 * @param string $version Version number from the update feed.
 *
 * @return string Normalized version number, or an empty string when unusable.
 */
function bb_pro_normalize_release_version( $version ) {
	$bp_admin = bb_pro_get_platform_admin();

	if ( $bp_admin && is_callable( array( $bp_admin, 'bb_normalize_release_version' ) ) ) {
		return (string) $bp_admin->bb_normalize_release_version( $version );
	}

	// Nothing scalar to read: an array or object cannot be a version.
	if ( ! is_scalar( $version ) ) {
		return '';
	}

	// Bound the input before any pattern runs against it, and trim first - the
	// extraction below is anchored, so a single leading space would otherwise
	// yield an empty string.
	$version = substr( trim( (string) $version ), 0, 128 );

	// A feed that files its releases as 'v2.0' is naming 2.0.
	$version = (string) preg_replace( '/^[vV]/', '', $version );

	preg_match( '/^[0-9.]+/', $version, $matches );

	$version = isset( $matches[0] ) ? $matches[0] : '';

	// Collapse runs of dots ('3..4') and drop leading/trailing ones.
	$version = trim( (string) preg_replace( '/\.{2,}/', '.', $version ), '.' );

	return preg_match( '/^[0-9]+(?:\.[0-9]+)+$/', $version ) ? $version : '';
}

/**
 * Resolve the 'download_link' for locally served plugin information.
 *
 * The value on hand is a licensed package URL, and plugins_api() is a public
 * filter callable from any context, so it is only ever assembled for someone who
 * could install or update with it anyway. The pair is core's own:
 * install_plugin_information() gates the modal's footer button on
 * 'install_plugins' OR 'update_plugins', so testing only the first would
 * withhold the value from a user core would have offered "Update Now" to.
 *
 * @since 3.3.2
 *
 * @param string $package Package URL from the update transient, if any.
 *
 * @return string Package URL, or empty string.
 */
function bb_pro_get_plugin_download_link( $package ) {
	$bp_admin = bb_pro_get_platform_admin();

	if ( $bp_admin && is_callable( array( $bp_admin, 'bb_get_plugin_download_link' ) ) ) {
		return (string) $bp_admin->bb_get_plugin_download_link( $package );
	}

	if (
		empty( $package ) ||
		( ! current_user_can( 'install_plugins' ) && ! current_user_can( 'update_plugins' ) )
	) {
		return '';
	}

	return (string) $package;
}

/**
 * Resolve a "last updated" date for locally served plugin information.
 *
 * WP_Plugin_Dependencies::get_dependency_api_data() caches plugin API data for
 * every "Requires Plugins" slug, but only keeps a cached entry that carries a
 * non-empty 'last_updated'. Answering with an empty string makes core re-call
 * plugins_api() on every plugins.php and plugin-install.php load.
 *
 * @since 3.3.2
 *
 * @param string      $plugin_file Plugin basename.
 * @param object|null $update      Optional. Update transient entry for the plugin.
 *
 * @return string Last updated date in GMT 'Y-m-d H:i:s' format.
 */
function bb_pro_get_plugin_last_updated( $plugin_file, $update = null ) {
	$bp_admin = bb_pro_get_platform_admin();

	if ( $bp_admin && is_callable( array( $bp_admin, 'bb_get_plugin_last_updated' ) ) ) {
		return (string) $bp_admin->bb_get_plugin_last_updated( $plugin_file, $update );
	}

	if ( is_object( $update ) && ! empty( $update->last_updated ) ) {
		return (string) $update->last_updated;
	}

	$path  = WP_PLUGIN_DIR . '/' . $plugin_file;
	$mtime = file_exists( $path ) ? filemtime( $path ) : false;

	return gmdate( 'Y-m-d H:i:s', false !== $mtime ? $mtime : time() );
}

/**
 * Whether this plugins_api() call should fetch release notes.
 *
 * Only the plugin-information iframe renders a changelog. The wp.org 'fields'
 * contract is opt-out, so an absent 'sections' key means the caller wants them -
 * testing ! empty( $fields['sections'] ) reads that as "not wanted", which is the
 * inverse. IFRAME_REQUEST is what keeps the fetch off ordinary page renders:
 * WP_Plugin_Install_List_Table's dependency notice calls plugins_api() with a
 * bare slug and no fields at all, on a normal Add Plugins load.
 *
 * @since 3.3.2
 *
 * @param object $args Plugin API arguments.
 *
 * @return bool True when release notes should be fetched.
 */
function bb_pro_should_fetch_release_notes( $args ) {
	$bp_admin = bb_pro_get_platform_admin();

	if ( $bp_admin && is_callable( array( $bp_admin, 'bb_should_fetch_release_notes' ) ) ) {
		return (bool) $bp_admin->bb_should_fetch_release_notes( $args );
	}

	$fields = isset( $args->fields ) ? (array) $args->fields : array();

	$wants_sections = ! isset( $fields['sections'] ) || $fields['sections'];

	return $wants_sections && defined( 'IFRAME_REQUEST' ) && IFRAME_REQUEST;
}

/**
 * Build the release notes page URL for a version.
 *
 * @since 3.3.2
 *
 * @param string $version   Normalized version number, or empty for the archive.
 * @param string $page_base Release notes archive base URL.
 *
 * @return string Release notes page URL.
 */
function bb_pro_get_release_notes_page_url( $version, $page_base ) {
	$bp_admin = bb_pro_get_platform_admin();

	if ( $bp_admin && is_callable( array( $bp_admin, 'bb_get_release_notes_page_url' ) ) ) {
		return (string) $bp_admin->bb_get_release_notes_page_url( $version, $page_base );
	}

	$url     = trailingslashit( $page_base );
	$version = bb_pro_normalize_release_version( $version );

	return '' !== $version ? $url . str_replace( '.', '-', $version ) . '/' : $url;
}

/**
 * This plugin's own version, with the singleton not necessarily booted.
 *
 * The singleton accessor bb_platform_pro() is only safe to call once
 * class-bb-platform-pro.php has been required, which
 * bb_platform_pro_init() only does when BuddyBoss Platform is active, and this file now
 * runs on requests where it has not. The plugin header is the same number the
 * Plugins screen prints in the row behind the modal, so it is the right answer
 * rather than a consolation one - and reading it is what lets the modal name a
 * version at all when the plugin has stood down.
 *
 * @since 3.3.2
 *
 * @param string $plugin_file Plugin basename.
 *
 * @return string Installed version, or an empty string.
 */
function bb_pro_get_installed_version( $plugin_file ) {
	if ( function_exists( 'bb_platform_pro' ) ) {
		$pro = bb_platform_pro();

		if ( ! empty( $pro->version ) ) {
			return (string) $pro->version;
		}
	}

	if ( ! function_exists( 'get_plugin_data' ) ) {
		return '';
	}

	// No markup, no translation: this is a version number being read, not shown.
	$data = get_plugin_data( WP_PLUGIN_DIR . '/' . $plugin_file, false, false );

	return ! empty( $data['Version'] ) ? (string) $data['Version'] : '';
}

/**
 * Build the changelog section for the plugin-information modal.
 *
 * Mirrors Platform's bb_build_changelog_section() rather than approximating it.
 * The local branch is not a rare path: no released Platform carries this helper,
 * so on every site running a shipped Platform it is what renders. Emitting the
 * trailing link alone - which is what this did before - dropped two things.
 *
 * The state sentence: without it a failed fetch is indistinguishable from a
 * release that genuinely has no notes, and the modal simply says nothing at all
 * about why the changelog is empty.
 *
 * The screen-reader announcement: links_add_target() forces target="_blank" on
 * every link in this section whatever is written here, so the new tab is a
 * certainty rather than a choice and has to be announced. 'screen-reader-text'
 * is styled inside the iframe - iframe_header() enqueues 'colors', which depends
 * on 'wp-admin', which bundles common.css - and span[class] survives the
 * wp_kses() allowlist install_plugin_information() runs over this section.
 *
 * @since 3.3.2
 *
 * @param string $notes     Release notes HTML, or empty string when there are none.
 * @param string $url       Release notes page URL.
 * @param string $link_text Plain, unescaped link text; escaped here, matching the
 *                          Platform helper's convention. Do not pass esc_html()
 *                          output - both helpers escape their own link text, and
 *                          pre-escaping now double-escapes.
 * @param string $state     Why there are no notes: 'empty', 'locked', 'skipped' or 'failed'.
 *
 * @return string Changelog section HTML.
 */
function bb_pro_build_changelog_section( $notes, $url, $link_text, $state = 'failed' ) {
	$bp_admin = bb_pro_get_platform_admin();

	if ( $bp_admin && is_callable( array( $bp_admin, 'bb_build_changelog_section' ) ) ) {
		return (string) $bp_admin->bb_build_changelog_section( $notes, $url, $link_text, $state );
	}

	$section = '';

	if ( '' !== $notes ) {
		$section .= $notes;
	} else {
		$notice = '';

		switch ( (string) $state ) {
			case 'empty':
				$notice = esc_html__( 'No release notes have been published for this version yet.', 'buddyboss-pro' );
				break;
			case 'locked':
				$notice = esc_html__( 'The release notes are still loading. Reload this window in a moment to see them.', 'buddyboss-pro' );
				break;
			// Nothing was asked of the remote, so there is nothing to report
			// about it; the link stands on its own.
			case 'skipped':
				break;
			default:
				$notice = esc_html__( 'The release notes for this version could not be loaded right now.', 'buddyboss-pro' );
				break;
		}

		if ( '' !== $notice ) {
			$section .= '<p>' . $notice . '</p>';
		}
	}

	$section .= sprintf(
		'<p><a href="%1$s" target="_blank" rel="noopener noreferrer">%2$s<span class="screen-reader-text"> %3$s</span></a></p>',
		esc_url( $url ),
		esc_html( (string) $link_text ),
		esc_html__( '(opens in a new tab)', 'buddyboss-pro' )
	);

	return $section;
}

/**
 * Serve plugin information for BuddyBoss Platform Pro locally.
 *
 * Handles the plugin-information modal opened by the plugin row's
 * "View details" link and the update notice's "View version x.x.x
 * details" link, which otherwise query WordPress.org and return
 * "Plugin not found." because Platform Pro is distributed from
 * BuddyBoss's own servers. The changelog is fetched through Platform's
 * release-notes helper when available and always links to the full
 * release notes page.
 *
 * @since 3.3.2
 *
 * @param false|object|array $result The result object or array. Default false.
 * @param string             $action The type of information being requested from the Plugin Installation API.
 * @param object             $args   Plugin API arguments.
 *
 * @return false|object Plugin information for BuddyBoss Platform Pro, or the original result.
 */
function bb_pro_plugins_api_information( $result, $action, $args ) {
	/*
	 * install_plugin_information() passes $_REQUEST['plugin'] through wp_unslash()
	 * and nothing else, so the slug arrives with whatever type the request gave
	 * it - ?plugin[]=x makes it an array. Refuse anything that is not a string
	 * rather than relying on the strict comparison below to reject it.
	 */
	if (
		'plugin_information' !== $action ||
		empty( $args->slug ) ||
		! is_string( $args->slug ) ||
		false !== $result
	) {
		return $result;
	}

	$plugin_file = bb_pro_get_plugin_file();

	if ( dirname( $plugin_file ) !== $args->slug ) {
		return $result;
	}

	$new_version = bb_pro_get_installed_version( $plugin_file );
	$package     = '';
	$update      = bb_pro_get_plugin_update_entry( $plugin_file );

	if ( is_object( $update ) && ! empty( $update->new_version ) ) {
		$new_version = $update->new_version;
		$package     = ! empty( $update->package ) && is_string( $update->package ) ? $update->package : '';
	}

	$version   = bb_pro_normalize_release_version( $new_version );
	$page_base = 'https://www.buddyboss.com/resources/buddyboss-platform-pro-releases/';
	$bp_admin  = bb_pro_get_platform_admin();
	$state     = 'skipped';
	$notes     = '';

	/*
	 * Platform Pro files its releases in a post type of its own rather than in
	 * the shared add-on taxonomy, so this uses the post-type helper rather than
	 * bb_get_addon_changelog_section(). $state is written by reference, so the
	 * call has to be made on the object - never through call_user_func().
	 */
	if (
		'' !== $version &&
		bb_pro_should_fetch_release_notes( $args ) &&
		$bp_admin && is_callable( array( $bp_admin, 'bb_get_release_notes_html' ) )
	) {
		$notes = (string) $bp_admin->bb_get_release_notes_html( $version, 'releases-platformpro', $state );
	}

	/*
	 * Link text names the version the URL actually resolves to, not the one the
	 * update feed reported: the page URL reduces 3.4.4-beta1 to the 3.4.4 release
	 * page, and a link reading "version 3.4.4-beta1" that opens /3-4-4/ misstates
	 * where it goes.
	 *
	 * With no notes to show, there is no evidence a page for this version exists -
	 * the fetch that would have found one is what just came back empty - so the
	 * link falls back to the releases archive, which always does, rather than
	 * sending the user to a likely 404.
	 */
	if ( '' !== $notes && '' !== $version ) {
		$release_url  = bb_pro_get_release_notes_page_url( $version, $page_base );
		$release_text = sprintf(
			/* translators: %s: version number. */
			__( 'View the full release notes for version %s on buddyboss.com', 'buddyboss-pro' ),
			$version
		);
	} else {
		$release_url  = $page_base;
		$release_text = __( 'View all release notes on buddyboss.com', 'buddyboss-pro' );
	}

	// Plain, unescaped text. Both Platform helpers escape their own link text,
	// and the local mirror below does the same, so pre-escaping here would
	// render "&amp;" wherever the string contains an ampersand.
	$changelog = bb_pro_build_changelog_section( $notes, $release_url, $release_text, $state );

	$information = array(
		// Not translated, and no markup. install_plugin_information() echoes
		// $api->name straight into the modal's <h2> without escaping it, and
		// unlike 'version' and the other keys it is not in the wp_kses()
		// allowlist that runs first - so a translation file is the whole of
		// what stands between a .mo and script in wp-admin. It is a product
		// name, so there is nothing to translate.
		'name'          => 'BuddyBoss Platform Pro',
		'slug'          => $args->slug,
		// Normalized, not raw; see bb_pro_normalize_release_version().
		'version'       => bb_pro_sanitize_plugin_version( $new_version ),
		'author'        => '<a href="https://www.buddyboss.com/" target="_blank" rel="noopener noreferrer">BuddyBoss</a>',
		'homepage'      => 'https://www.buddyboss.com/',
		'last_updated'  => bb_pro_get_plugin_last_updated( $plugin_file, $update ),
		'sections'      => array(
			'description' => '<p>' . esc_html__( 'Adds premium features to BuddyBoss Platform.', 'buddyboss-pro' ) . '</p>',
			'changelog'   => $changelog,
		),
		'download_link' => bb_pro_get_plugin_download_link( $package ),
	);

	/**
	 * Filters the locally served plugin information for BuddyBoss Platform Pro.
	 *
	 * @since 3.3.2
	 *
	 * @param array  $information Plugin information served to the plugin-information modal.
	 * @param string $version     Normalized version number the information describes.
	 * @param object $args        Plugin API arguments.
	 */
	$information = apply_filters( 'bb_pro_plugins_api_information', $information, $version, $args );

	return (object) $information;
}

// Serve the plugin-information modal locally (View details / View version x.x.x details).
add_filter( 'plugins_api', 'bb_pro_plugins_api_information', 10, 3 );
