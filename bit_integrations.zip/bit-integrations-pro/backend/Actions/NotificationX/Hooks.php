<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Actions\NotificationX\NotificationXProHelper;
use BitApps\IntegrationsPro\Config;
use BitApps\IntegrationsPro\Core\Util\Hooks;

Hooks::filter(Config::withFreePrefix('notificationx_add_sales_notification'), [NotificationXProHelper::class, 'addSalesNotification'], 10, 2);
Hooks::filter(Config::withFreePrefix('notificationx_add_reviews'), [NotificationXProHelper::class, 'addReviews'], 10, 2);
Hooks::filter(Config::withFreePrefix('notificationx_add_email_subscription'), [NotificationXProHelper::class, 'addEmailSubscription'], 10, 2);
Hooks::filter(Config::withFreePrefix('notificationx_delete_notification'), [NotificationXProHelper::class, 'deleteNotification'], 10, 2);
Hooks::filter(Config::withFreePrefix('notificationx_enable_notification'), [NotificationXProHelper::class, 'enableNotification'], 10, 2);
Hooks::filter(Config::withFreePrefix('notificationx_disable_notification'), [NotificationXProHelper::class, 'disableNotification'], 10, 2);
Hooks::filter(Config::withFreePrefix('notificationx_add_notification_entry'), [NotificationXProHelper::class, 'addNotificationEntry'], 10, 2);
