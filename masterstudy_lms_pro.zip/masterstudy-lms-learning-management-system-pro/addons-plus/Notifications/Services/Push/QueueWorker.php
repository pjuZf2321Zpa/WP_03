<?php

namespace MasterStudy\Lms\Pro\AddonsPlus\Notifications\Services\Push;

use MasterStudy\Lms\Pro\AddonsPlus\Notifications\Repositories\NotificationRepository;
use MasterStudy\Lms\Pro\AddonsPlus\Notifications\Repositories\PushQueueRepository;
use MasterStudy\Lms\Pro\AddonsPlus\Notifications\Repositories\PushSubscriptionRepository;
use Minishlink\WebPush\Subscription;
use Minishlink\WebPush\WebPush;

final class QueueWorker {
	private PushQueueRepository $queue;
	private NotificationRepository $notifications;
	private PushSubscriptionRepository $subscriptions;

	public function __construct() {
		$this->queue         = new PushQueueRepository();
		$this->notifications = new NotificationRepository();
		$this->subscriptions = new PushSubscriptionRepository();
	}

	public static function process(): void {
		try {
			( new self() )->process_batch();
		} catch ( \Throwable $error ) {
			return;
		}
	}

	public function process_batch( int $limit = 50 ): void {
		if ( ! $this->is_available() ) {
			return;
		}

		$missing_message = PushRequirements::missing_message();

		if ( '' !== $missing_message ) {
			$this->fail_claimed_rows( $limit, $missing_message, false );
			return;
		}

		$keys = ( new VapidKeys() )->get();

		if ( empty( $keys['publicKey'] ) || empty( $keys['privateKey'] ) ) {
			$this->fail_claimed_rows( $limit, 'Unable to generate VAPID keys.', false );
			return;
		}

		try {
			$rows = $this->queue->claim_available( $limit );
		} catch ( \Throwable $error ) {
			return;
		}

		if ( empty( $rows ) ) {
			return;
		}

		$batch_context = $this->prepare_batch_context( $rows );

		foreach ( $rows as $row ) {
			try {
				$this->send_queue_row( $row, $keys, $batch_context );
			} catch ( \Throwable $error ) {
				$this->queue->mark_failed(
					(int) $row['id'],
					(int) $row['attempts'] + 1,
					$this->safe_error_message( $error )
				);
			}
		}

		try {
			$has_pending = $this->queue->has_pending();
		} catch ( \Throwable $error ) {
			return;
		}

		if ( $has_pending && ! wp_next_scheduled( 'masterstudy_notifications_process_push_queue' ) ) {
			wp_schedule_single_event( time() + 15, 'masterstudy_notifications_process_push_queue' );
		}
	}

	private function send_queue_row( array $row, array $keys, array $batch_context ): void {
		$notification_id = (int) $row['notification_id'];
		$user_id         = (int) $row['recipient_user_id'];
		$notification    = $batch_context['notifications'][ $notification_id ] ?? null;

		if ( empty( $notification ) ) {
			$this->queue->mark_failed( (int) $row['id'], (int) $row['attempts'] + 1, 'Notification not found.', false );
			return;
		}

		if ( ! $this->is_trigger_available( (string) ( $notification['trigger_key'] ?? '' ) ) ) {
			$this->queue->mark_skipped( (int) $row['id'], 'Notification trigger is unavailable.' );
			return;
		}

		$read_state = $batch_context['read_states'][ $notification_id ][ $user_id ] ?? null;

		if ( is_array( $read_state ) && ! empty( $read_state['read_at_gmt'] ) ) {
			$this->queue->mark_skipped( (int) $row['id'], 'Notification was read before push delivery.' );
			return;
		}

		$subscriptions = $batch_context['subscriptions'][ $user_id ] ?? array();

		if ( empty( $subscriptions ) ) {
			$this->queue->mark_skipped( (int) $row['id'], 'No active push subscriptions for recipient.' );
			return;
		}

		$auth    = array(
			'VAPID' => array(
				'subject'    => ( new VapidKeys() )->subject(),
				'publicKey'  => $keys['publicKey'],
				'privateKey' => $keys['privateKey'],
			),
		);
		$webpush = new WebPush( $auth );
		$payload = array(
			'title'           => $this->prepare_notification_text( (string) $notification['title'] ),
			'body'            => $this->prepare_notification_text( (string) $notification['message'] ),
			'url'             => $notification['click_url'],
			'notification_id' => (int) $notification['id'],
			'user_id'         => $user_id,
		);
		$icon    = $this->push_icon_url();
		$badge   = $this->push_badge_url();

		if ( '' !== $icon ) {
			$payload['icon'] = $icon;
		}

		if ( '' !== $badge ) {
			$payload['badge'] = $badge;
		}

		foreach ( $subscriptions as $subscription ) {
			$payload['browser_key'] = (string) $subscription['browser_key'];

			$webpush->queueNotification(
				Subscription::create(
					array(
						'endpoint'        => $subscription['endpoint'],
						'keys'            => array(
							'p256dh' => $subscription['public_key'],
							'auth'   => $subscription['auth_token'],
						),
						'contentEncoding' => ! empty( $subscription['content_encoding'] ) ? $subscription['content_encoding'] : 'aes128gcm',
					)
				),
				wp_json_encode( $payload ),
				array(
					'topic'   => 'mslms-' . (int) $notification['id'],
					'urgency' => 'normal',
				)
			);
		}

		$has_retryable_error = false;
		$error               = '';

		foreach ( $webpush->flush() as $report ) {
			if ( $report->isSuccess() ) {
				continue;
			}

			if ( $report->isSubscriptionExpired() ) {
				$this->subscriptions->deactivate_by_endpoint( $report->getEndpoint() );
				continue;
			}

			$reason = sanitize_textarea_field( (string) $report->getReason() );

			if ( $this->is_bad_jwt_token_error( $reason ) ) {
				$this->subscriptions->deactivate_by_endpoint( $report->getEndpoint() );
			}

			$has_retryable_error = true;
			$error               = $reason;
		}

		if ( $has_retryable_error ) {
			$this->queue->mark_failed( (int) $row['id'], (int) $row['attempts'] + 1, '' !== $error ? $error : 'Push delivery failed.' );
			return;
		}

		$this->queue->mark_sent( (int) $row['id'] );
	}

	private function prepare_batch_context( array $rows ): array {
		$notification_ids = array();
		$user_ids         = array();

		foreach ( $rows as $row ) {
			$notification_ids[] = absint( $row['notification_id'] ?? 0 );
			$user_ids[]         = absint( $row['recipient_user_id'] ?? 0 );
		}

		$notification_ids = $this->sanitize_ids( $notification_ids );
		$user_ids         = $this->sanitize_ids( $user_ids );

		return array(
			'notifications' => $this->notifications->get_notifications( $notification_ids ),
			'read_states'   => $this->notifications->get_recipient_read_states( $notification_ids, $user_ids ),
			'subscriptions' => $this->subscriptions->active_for_users( $user_ids ),
		);
	}

	private function fail_claimed_rows( int $limit, string $message, bool $retry = false ): void {
		try {
			$rows = $this->queue->claim_available( $limit );
		} catch ( \Throwable $error ) {
			return;
		}

		foreach ( $rows as $row ) {
			try {
				$this->queue->mark_failed( (int) $row['id'], (int) $row['attempts'] + 1, $message, $retry );
			} catch ( \Throwable $error ) {
				continue;
			}
		}
	}

	private function is_available(): bool {
		return function_exists( 'masterstudy_lms_is_notifications_push_frontend_available' )
			&& masterstudy_lms_is_notifications_push_frontend_available();
	}

	private function is_trigger_available( string $trigger_key ): bool {
		if ( function_exists( 'masterstudy_lms_notifications_is_trigger_available' ) ) {
			return masterstudy_lms_notifications_is_trigger_available( $trigger_key );
		}

		return function_exists( 'masterstudy_lms_is_notifications_addon_available' )
			&& masterstudy_lms_is_notifications_addon_available();
	}

	private function prepare_notification_text( string $text ): string {
		$text = html_entity_decode( $text, ENT_QUOTES | ENT_HTML5, 'UTF-8' );
		$text = preg_replace( '/\s+/u', ' ', $text );

		return trim( is_string( $text ) ? $text : '' );
	}

	private function push_icon_url(): string {
		$url = function_exists( 'get_site_icon_url' ) ? (string) get_site_icon_url( 192 ) : '';

		if ( '' === $url && function_exists( 'ms_plugin_favicon_url' ) ) {
			$url = (string) ms_plugin_favicon_url();
		}

		return $this->filter_push_asset_url( 'masterstudy_notifications_push_icon_url', $url );
	}

	private function push_badge_url(): string {
		$url = function_exists( 'get_site_icon_url' ) ? (string) get_site_icon_url( 96 ) : '';

		if ( '' === $url && function_exists( 'ms_plugin_favicon_url' ) ) {
			$url = (string) ms_plugin_favicon_url();
		}

		return $this->filter_push_asset_url( 'masterstudy_notifications_push_badge_url', $url );
	}

	private function filter_push_asset_url( string $filter_name, string $url ): string {
		$url = apply_filters( $filter_name, $url );

		if ( ! is_string( $url ) || '' === $url ) {
			return '';
		}

		return esc_url_raw( $url );
	}

	private function is_bad_jwt_token_error( string $error ): bool {
		return false !== strpos( strtolower( $error ), 'badjwttoken' );
	}

	private function sanitize_ids( array $ids ): array {
		return array_values( array_unique( array_filter( array_map( 'absint', $ids ) ) ) );
	}

	private function safe_error_message( \Throwable $error ): string {
		$message = sanitize_textarea_field( $error->getMessage() );

		return '' !== $message ? $message : 'Push delivery failed.';
	}
}
