<?php

namespace FluentCartPro\App\Modules\Licensing\Database;

use FluentCartPro\App\Database\DBMigrator as BaseDBMigrator;
use FluentCartPro\App\Modules\Licensing\Database\Migrations\LicenseActivationsMigrator;
use FluentCartPro\App\Modules\Licensing\Database\Migrations\LicenseMetaMigrator;
use FluentCartPro\App\Modules\Licensing\Database\Migrations\LicenseSitesMigrator;
use FluentCartPro\App\Modules\Licensing\Database\Migrations\LicensesMigrator;

class DBMigrator extends BaseDBMigrator
{
    public function migrate()
    {
        LicensesMigrator::migrate();
        LicenseSitesMigrator::migrate();
        LicenseActivationsMigrator::migrate();
        LicenseMetaMigrator::migrate();
    }

    public function dropTable()
    {
        LicensesMigrator::dropTable();
        LicenseSitesMigrator::dropTable();
        LicenseActivationsMigrator::dropTable();
        LicenseMetaMigrator::dropTable();
    }
}