<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Core\Util\Route;
use BitApps\IntegrationsPro\Triggers\B2BKing\B2BKingController;

Route::get('b2bking/get', [B2BKingController::class, 'getAllTasks']);
