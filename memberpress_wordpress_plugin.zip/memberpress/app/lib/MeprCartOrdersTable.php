<?php

if (!defined('ABSPATH')) {
    die('You are not allowed to call this page directly.');
}

if (!class_exists('WP_List_Table')) {
    require_once(ABSPATH . 'wp-admin/includes/class-wp-list-table.php');
}

class MeprCartOrdersTable extends WP_List_Table
{
    /**
     * The screen object for this table.
     *
     * @var WP_Screen
     */
    public $_screen;

    /**
     * The columns to display in the table.
     *
     * @var array
     */
    public $_columns;

    /**
     * The total number of items.
     *
     * @var integer
     */
    public $totalitems;

    /**
     * Constructor.
     *
     * @param WP_Screen|string $screen  The screen to display the table on.
     * @param array            $columns The columns to display.
     *
     * @return void
     */
    public function __construct($screen, $columns = [])
    {
        if (is_string($screen)) {
            $screen = convert_to_screen($screen);
        }

        $this->_screen = $screen;

        if (!empty($columns)) {
            $this->_columns = $columns;
        }

        parent::__construct([
            'singular' => 'wp_list_mepr_cart_order',
            'plural'   => 'wp_list_mepr_cart_orders',
            'ajax'     => false,
        ]);
    }

    /**
     * Get the column info.
     *
     * @return array The column info.
     */
    public function get_column_info()
    {
        $columns = get_column_headers($this->_screen);
        $hidden  = get_hidden_columns($this->_screen);
        // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHookname
        $sortable = apply_filters("manage_{$this->_screen->id}_sortable_columns", $this->get_sortable_columns());
        $primary  = 'col_trans_num';
        return [$columns, $hidden, $sortable, $primary];
    }

    /**
     * Get the columns.
     *
     * @return array The columns.
     */
    public function get_columns()
    {
        return $this->_columns;
    }

    /**
     * Get the sortable columns.
     *
     * @return array The sortable columns.
     */
    public function get_sortable_columns()
    {
        return [
            'col_trans_num'  => ['trans_num', false],
            'col_total'      => ['total', false],
            'col_status'     => ['status', false],
            'col_created_at' => ['created_at', true],
        ];
    }

    /**
     * Get the status filter views.
     *
     * @return array The views array for status filter tabs.
     */
    public function get_views()
    {
        global $wpdb;

        $current    = isset($_REQUEST['status']) ? sanitize_key(wp_unslash($_REQUEST['status'])) : '';
        $base_url   = admin_url('admin.php?page=memberpress-orders');
        $orders_tbl = $wpdb->prefix . 'mepr_orders';
        $order_type = MeprOrder::$cart_type_str;

        // Count by status.
        // phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
        $counts_raw = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT status, COUNT(*) AS cnt FROM {$orders_tbl} WHERE order_type = %s GROUP BY status",
                $order_type
            ),
            OBJECT_K
        );
        // phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching

        $total = 0;
        foreach ($counts_raw as $row) {
            $total += (int) $row->cnt;
        }

        $statuses = [
            ''         => __('All', 'memberpress'),
            'pending'  => __('Pending', 'memberpress'),
            'complete' => __('Complete', 'memberpress'),
            'refunded' => __('Refunded', 'memberpress'),
            'failed'   => __('Failed', 'memberpress'),
        ];

        $views = [];

        foreach ($statuses as $slug => $label) {
            $count = 0;
            if ($slug === '') {
                $count = $total;
            } elseif (isset($counts_raw[$slug])) {
                $count = (int) $counts_raw[$slug]->cnt;
            }

            $url        = $slug === '' ? $base_url : add_query_arg('status', $slug, $base_url);
            $is_current = ($current === $slug);
            $class      = $is_current ? 'current' : '';

            $views[$slug === '' ? 'all' : $slug] = sprintf(
                '<a href="%s" class="%s">%s <span class="count">(%s)</span></a>',
                esc_url($url),
                esc_attr($class),
                esc_html($label),
                number_format_i18n($count)
            );
        }

        return $views;
    }

    /**
     * Prepare items for the table.
     *
     * @return void
     */
    public function prepare_items()
    {
        global $wpdb;

        $user_id = get_current_user_id();
        $screen  = get_current_screen();

        if (isset($screen) && is_object($screen)) {
            $option  = $screen->get_option('per_page', 'option');
            $perpage = !empty($option) ? get_user_meta($user_id, $option, true) : 20;
            $perpage = (!empty($perpage) && !is_array($perpage)) ? (int) $perpage : 20;
        } else {
            $perpage = !empty($_GET['perpage']) ? (int) wp_unslash($_GET['perpage']) : 20;
        }

        $orderby         = !empty($_GET['orderby']) ? sanitize_key(wp_unslash($_GET['orderby'])) : 'created_at';
        $order           = !empty($_GET['order'])   ? sanitize_key(wp_unslash($_GET['order']))   : 'DESC';
        $paged           = !empty($_GET['paged'])   ? max(1, (int) wp_unslash($_GET['paged']))   : 1;
        $search          = !empty($_GET['search'])  ? sanitize_text_field(wp_unslash($_GET['search']))  : '';
        $status          = !empty($_GET['status'])  ? sanitize_key(wp_unslash($_GET['status']))  : '';
        $currency_filter = isset($_GET['currency']) ? sanitize_text_field(wp_unslash($_GET['currency'])) : 'all';

        // Allowed orderby columns to prevent SQL injection.
        $allowed_orderby = ['trans_num', 'total', 'status', 'created_at'];
        if (!in_array($orderby, $allowed_orderby, true)) {
            $orderby = 'created_at';
        }
        $order = strtoupper($order) === 'ASC' ? 'ASC' : 'DESC';

        $orders_tbl = $wpdb->prefix . 'mepr_orders';
        $txn_tbl    = $wpdb->prefix . 'mepr_transactions';
        $users_tbl  = $wpdb->users;
        $order_type = MeprOrder::$cart_type_str;

        $where_clauses = [$wpdb->prepare('o.order_type = %s', $order_type)];
        $where_args    = [];

        if (!empty($status)) {
            $where_clauses[] = $wpdb->prepare('o.status = %s', $status);
        }

        if (!empty($search)) {
            $like            = '%' . $wpdb->esc_like($search) . '%';
            $where_clauses[] = $wpdb->prepare('(o.trans_num LIKE %s OR u.user_email LIKE %s)', $like, $like);
        }

        // Currency filter: when a specific currency is selected, only show orders with transactions in that currency.
        if ($currency_filter !== 'all' && !empty($currency_filter)) {
            $where_clauses[] = $wpdb->prepare('t.currency = %s', $currency_filter);
        }

        $where_sql = 'WHERE ' . implode(' AND ', $where_clauses);

        $offset = ($paged - 1) * $perpage;

        // Table names, prepared WHERE clauses, and whitelisted ORDER BY only.
        // phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
        $count = (int) $wpdb->get_var(
            "SELECT COUNT(DISTINCT o.id)
             FROM {$orders_tbl} o
             LEFT JOIN {$users_tbl} u ON o.user_id = u.ID
             {$where_sql}"
        );

        $results = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT o.*,
                        u.display_name AS customer_name,
                        u.user_email   AS customer_email,
                        (COUNT(DISTINCT CASE WHEN t.subscription_id > 0 THEN t.subscription_id END)
                          + SUM(CASE WHEN t.id IS NOT NULL AND (t.subscription_id IS NULL OR t.subscription_id = 0) THEN 1 ELSE 0 END)) AS item_count,
                        MAX(t.currency) AS currency,
                        SUM(t.amount_primary) AS total_primary
                 FROM {$orders_tbl} o
                 LEFT JOIN {$users_tbl} u ON o.user_id = u.ID
                 LEFT JOIN {$txn_tbl} t  ON t.order_id = o.id
                 {$where_sql}
                 GROUP BY o.id
                 ORDER BY o.{$orderby} {$order}
                 LIMIT %d OFFSET %d",
                $perpage,
                $offset
            )
        );
        // phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching

        $this->totalitems = $count;
        $totalpages       = ceil($count / $perpage);

        $this->set_pagination_args([
            'total_items' => $count,
            'total_pages' => $totalpages,
            'per_page'    => $perpage,
        ]);

        if (isset($screen) && is_object($screen)) {
            $this->_column_headers = $this->get_column_info();
        } else {
            $this->_column_headers = [
                $this->get_columns(),
                [],
                $this->get_sortable_columns(),
            ];
        }

        $this->items = $results ?: [];
    }

    /**
     * Render column content for each row.
     *
     * @param object $item        The current row item.
     * @param string $column_name The current column name.
     *
     * @return string The column output.
     */
    public function column_default($item, $column_name)
    {
        switch ($column_name) {
            case 'col_trans_num':
                $detail_url = admin_url('admin.php?page=memberpress-orders&action=detail&id=' . (int) $item->id);
                return '<a href="' . esc_url($detail_url) . '"><strong>' . esc_html($item->trans_num) . '</strong></a>';

            case 'col_customer':
                if (empty($item->user_id)) {
                    return esc_html__('Guest', 'memberpress');
                }
                $profile_url = admin_url('admin.php?page=memberpress-members&action=edit&id=' . (int) $item->user_id);
                $name        = !empty($item->customer_name) ? $item->customer_name : $item->customer_email;
                $output      = '<a href="' . esc_url($profile_url) . '">' . esc_html($name) . '</a>';
                if (!empty($item->customer_email)) {
                    $output .= '<br><span class="description">' . esc_html($item->customer_email) . '</span>';
                }
                return $output;

            case 'col_items':
                $count = (int) $item->item_count;
                return sprintf(
                    // Translators: %d: number of items.
                    _n('%d item', '%d items', $count, 'memberpress'),
                    $count
                );

            case 'col_total':
                $primary_code   = MeprOptions::fetch()->currency_code;
                $order_currency = !empty($item->currency) ? $item->currency : $primary_code;
                $formatted      = MeprAppHelper::format_currency((float) $item->total, true, true, false, $order_currency);
                $output         = '<span class="mepr-txn-currency">';
                $output        .= '<span class="mepr-txn-currency__amount">' . esc_html($formatted) . '</span>';
                if ($order_currency !== $primary_code) {
                    $output .= ' <span class="mepr-txn-currency__code">' . esc_html($order_currency) . '</span>';
                }
                $output .= '</span>';
                return $output;

            case 'col_status':
                $status = esc_attr($item->status);
                $label  = ucfirst($item->status);
                return '<span class="mepr-order-status mepr-order-status-' . $status . '">' . esc_html($label) . '</span>';

            case 'col_gateway':
                if (empty($item->gateway)) {
                    return '&mdash;';
                }
                // The gateway column stores the payment method ID (e.g. "Tbji0y-11m").
                // Resolve it to a human-readable gateway name via MeprOptions.
                $pm = MeprOptions::fetch()->payment_method($item->gateway);
                if ($pm instanceof \MeprBaseGateway) {
                    return esc_html($pm->label ?: ucwords(str_replace('_', ' ', $pm->name)));
                }
                // Fallback: if PM no longer exists, show the raw value cleaned up.
                return esc_html(ucwords(str_replace('_', ' ', $item->gateway)));

            case 'col_created_at':
                if (empty($item->created_at)) {
                    return '&mdash;';
                }
                $ts = strtotime($item->created_at);
                return esc_html(date_i18n(get_option('date_format') . ' ' . get_option('time_format'), $ts));

            default:
                return '';
        }
    }

    /**
     * Display the table rows.
     *
     * @return void
     */
    public function display_rows()
    {
        foreach ($this->items as $item) {
            echo '<tr>';
            list($columns, $hidden) = $this->get_column_info();
            foreach ($columns as $column_name => $column_display_name) {
                $class = 'column-' . $column_name;
                if (in_array($column_name, $hidden, true)) {
                    $class .= ' hidden';
                }
                echo '<td class="' . esc_attr($class) . '">';
                echo $this->column_default($item, $column_name); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
                echo '</td>';
            }
            echo '</tr>';
        }
    }

    /**
     * Message when no items are found.
     *
     * @return void
     */
    public function no_items()
    {
        esc_html_e('No cart orders found.', 'memberpress');
    }
}
