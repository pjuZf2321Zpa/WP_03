<?php

namespace BitApps\IntegrationsPro\Triggers\EventsCalendar;

use BitApps\IntegrationsPro\Actions\TheEventsCalendar\TheEventsCalendarHelper;
use WP_Post;

if (!\defined('ABSPATH')) {
    exit;
}

final class EventsCalendarRecordController
{
    // The attendee triggers (tasks 1-4) keep the event list they had before the record triggers were added.
    public const EVENT_FILTER_TASKS = [
        'events_calendar-7',
        'events_calendar-8',
        'events_calendar-9',
        'events_calendar-10',
        'events_calendar-11',
        'events_calendar-12',
        'events_calendar-13',
    ];

    private const SAVED_POST_TASKS = [
        TheEventsCalendarHelper::EVENT_POST_TYPE => [
            'created'   => 'events_calendar-5',
            'published' => 'events_calendar-6',
            'updated'   => 'events_calendar-7',
        ],
        TheEventsCalendarHelper::VENUE_POST_TYPE => [
            'published' => 'events_calendar-14',
            'updated'   => 'events_calendar-15',
        ],
        TheEventsCalendarHelper::ORGANIZER_POST_TYPE => [
            'published' => 'events_calendar-17',
            'updated'   => 'events_calendar-18',
        ],
    ];

    private const DELETED_POST_TASKS = [
        TheEventsCalendarHelper::EVENT_POST_TYPE     => 'events_calendar-12',
        TheEventsCalendarHelper::VENUE_POST_TYPE     => 'events_calendar-16',
        TheEventsCalendarHelper::ORGANIZER_POST_TYPE => 'events_calendar-19',
    ];

    private const MAX_SHUTDOWN_ROUNDS = 10;

    private const EVENT_STATUS_TASKS = [
        'canceled'  => 'events_calendar-9',
        'postponed' => 'events_calendar-10',
    ];

    private static $createdPostIds = [];

    private static $publishedPostIds = [];

    private static $pendingPostTypes = [];

    private static $handledTriggerKeys = [];

    private static $previousEventStatuses = [];

    private static $previousSchedules = [];

    private static $previousEventSeriesIds = [];

    private static $previousSeriesEventIds = [];

    private static $pendingStatusEventIds = [];

    private static $flowsByTask;

    private static $deferredExecutions = [];

    public static function handleStatusTransition($newStatus, $oldStatus, $post)
    {
        if (!$post instanceof WP_Post || !isset(self::SAVED_POST_TASKS[$post->post_type])) {
            return;
        }

        // A classic-editor autosave moves a new event to draft before TEC saves its dates, so an undated event is still new.
        $isFirstSave = \in_array($oldStatus, ['new', 'auto-draft'], true)
            || ($post->post_type === TheEventsCalendarHelper::EVENT_POST_TYPE && empty(get_post_meta($post->ID, '_EventStartDate', true)));

        if ($isFirstSave && $newStatus !== 'auto-draft') {
            self::$createdPostIds[$post->ID] = true;
        }

        if ($newStatus === 'publish' && $oldStatus !== 'publish') {
            self::$publishedPostIds[$post->ID] = true;
        }
    }

    public static function handleAfterInsertPost($postId, $post = null, $update = false, $postBefore = null)
    {
        if (!$post instanceof WP_Post) {
            return;
        }

        if ($post->post_type === TheEventsCalendarHelper::SERIES_POST_TYPE) {
            self::executeSeriesCreated($post, $postBefore);

            return;
        }

        // TEC saves meta, the series link and the recurrence after wp_insert_post() in some paths, so the save triggers wait for shutdown.
        if (
            isset(self::SAVED_POST_TASKS[$post->post_type])
            && !self::isMetaBoxLoaderRequest()
            && self::hasFlows(...array_values(self::SAVED_POST_TASKS[$post->post_type]))
        ) {
            self::$pendingPostTypes[$post->ID] = $post->post_type;
        }
    }

    public static function handleVenueSaved($venueId)
    {
        self::executeSavedPostTriggers((int) $venueId, TheEventsCalendarHelper::VENUE_POST_TYPE);
    }

    public static function handleOrganizerSaved($organizerId)
    {
        self::executeSavedPostTriggers((int) $organizerId, TheEventsCalendarHelper::ORGANIZER_POST_TYPE);
    }

    public static function handleShutdown()
    {
        // Flows that run here can save more records; the round cap stops a flow that feeds its own trigger.
        for ($round = 0; $round < self::MAX_SHUTDOWN_ROUNDS && self::hasPendingWork(); $round++) {
            foreach (self::$pendingPostTypes as $postId => $postType) {
                self::executeSavedPostTriggers($postId, $postType);
            }

            foreach (array_keys(self::$pendingStatusEventIds) as $eventId) {
                self::executeEventStatusTrigger($eventId);
            }

            $executions = self::$deferredExecutions;
            self::$deferredExecutions = [];

            foreach ($executions as $execution) {
                self::execute(...$execution);
            }
        }
    }

    public static function handlePrePostUpdate($postId)
    {
        $postId = (int) $postId;

        if (TheEventsCalendarHelper::isPostOfType($postId, TheEventsCalendarHelper::EVENT_POST_TYPE)) {
            if (self::hasFlows('events_calendar-8')) {
                self::$previousSchedules[$postId] = self::$previousSchedules[$postId] ?? TheEventsCalendarHelper::getEventSchedule($postId);
            }

            if (self::hasFlows('events_calendar-20') && !\array_key_exists($postId, self::$previousEventSeriesIds)) {
                self::$previousEventSeriesIds[$postId] = TheEventsCalendarHelper::getEventSeriesId($postId);
            }
        } elseif (self::hasFlows('events_calendar-20') && TheEventsCalendarHelper::isPostOfType($postId, TheEventsCalendarHelper::SERIES_POST_TYPE)) {
            self::$previousSeriesEventIds[$postId] = self::$previousSeriesEventIds[$postId] ?? TheEventsCalendarHelper::getSeriesEventIds($postId);
        }
    }

    public static function handleEventDatesSaved($eventId)
    {
        $eventId = (int) $eventId;
        $taskId = 'events_calendar-8';

        // TEC also runs this hook when a save leaves the dates as they were, for example to sync a series.
        $isScheduleUnchanged = isset(self::$previousSchedules[$eventId])
            && self::$previousSchedules[$eventId] === TheEventsCalendarHelper::getEventSchedule($eventId);

        if (
            !TheEventsCalendarHelper::isPostOfType($eventId, TheEventsCalendarHelper::EVENT_POST_TYPE)
            || $isScheduleUnchanged
            || isset(self::$createdPostIds[$eventId])
            || get_post_status($eventId) !== 'publish'
            || !self::isFirstRun($taskId, $eventId)
        ) {
            return;
        }

        self::executeLater($taskId, self::postDataBuilder(TheEventsCalendarHelper::EVENT_POST_TYPE, $eventId), $eventId);
    }

    // The event editor, the block editor and the Update Event Status action all write this meta, but only the editor runs TEC's status hooks.
    public static function handleStatusMetaUpdate($check, $objectId, $metaKey)
    {
        $eventId = (int) $objectId;

        if (
            $metaKey === TheEventsCalendarHelper::EVENT_STATUS_META_KEY
            && !isset(self::$pendingStatusEventIds[$eventId])
            && self::hasFlows(...array_values(self::EVENT_STATUS_TASKS))
            && TheEventsCalendarHelper::isPostOfType($eventId, TheEventsCalendarHelper::EVENT_POST_TYPE)
        ) {
            self::$previousEventStatuses[$eventId] = TheEventsCalendarHelper::getEventStatus($eventId);
            self::$pendingStatusEventIds[$eventId] = true;
        }

        return $check;
    }

    public static function handleTrashedPost($postId)
    {
        $postId = (int) $postId;

        if (TheEventsCalendarHelper::isPostOfType($postId, TheEventsCalendarHelper::EVENT_POST_TYPE)) {
            self::executeRemovedPostTrigger('events_calendar-11', TheEventsCalendarHelper::EVENT_POST_TYPE, $postId);
        }
    }

    public static function handleBeforeDeletePost($postId)
    {
        $postId = (int) $postId;
        $postType = get_post_type($postId);

        if (isset(self::DELETED_POST_TASKS[$postType])) {
            self::executeRemovedPostTrigger(self::DELETED_POST_TASKS[$postType], $postType, $postId);
        }
    }

    public static function handleEventDuplicated($duplicatedEvent, $originalEvent)
    {
        if (!$duplicatedEvent instanceof WP_Post || !$originalEvent instanceof WP_Post) {
            return;
        }

        $buildData = function () use ($duplicatedEvent, $originalEvent) {
            $data = TheEventsCalendarHelper::getEventData($duplicatedEvent->ID);

            return empty($data) ? [] : $data + ['original_event_id' => $originalEvent->ID, 'original_event_title' => $originalEvent->post_title];
        };

        self::executeLater('events_calendar-13', $buildData, $originalEvent->ID);
    }

    public static function handleEventSeriesUpdated($eventId)
    {
        $eventId = (int) $eventId;
        $seriesId = TheEventsCalendarHelper::getEventSeriesId($eventId);

        // Pro runs this hook on every save that posts the series field, also when the series stays the same.
        $isSameSeries = \array_key_exists($eventId, self::$previousEventSeriesIds) && self::$previousEventSeriesIds[$eventId] === $seriesId;

        self::executeAddedToSeries($seriesId, $isSameSeries ? [] : [$eventId]);
    }

    public static function handleSeriesEventsUpdated($seriesId, $eventIds = [])
    {
        $seriesId = (int) $seriesId;
        $addedEventIds = array_intersect(
            array_diff(array_map('intval', (array) $eventIds), self::$previousSeriesEventIds[$seriesId] ?? []),
            TheEventsCalendarHelper::getSeriesEventIds($seriesId)
        );

        self::executeAddedToSeries($seriesId, $addedEventIds);
    }

    private static function executeSavedPostTriggers($postId, $postType)
    {
        unset(self::$pendingPostTypes[$postId]);

        // The legacy TEC API inserts the post first and saves the dates after it.
        if (
            !TheEventsCalendarHelper::isPostOfType($postId, $postType)
            || ($postType === TheEventsCalendarHelper::EVENT_POST_TYPE && empty(get_post_meta($postId, '_EventStartDate', true)))
        ) {
            return;
        }

        foreach (self::SAVED_POST_TASKS[$postType] as $change => $taskId) {
            if (!self::isSavedPostChange($change, $postId) || !self::isFirstRun($taskId, $postId)) {
                continue;
            }

            $filterValue = $taskId === 'events_calendar-7' ? $postId : null;

            self::execute($taskId, self::postDataBuilder($postType, $postId), $filterValue);
        }
    }

    private static function executeEventStatusTrigger($eventId)
    {
        unset(self::$pendingStatusEventIds[$eventId]);

        $eventStatus = TheEventsCalendarHelper::getEventStatus($eventId);
        $previousStatus = self::$previousEventStatuses[$eventId] ?? $eventStatus;
        $taskId = self::EVENT_STATUS_TASKS[$eventStatus] ?? null;

        // A new or duplicated event gets its status meta on its first save, which is not a status change.
        if (
            $taskId === null
            || $previousStatus === $eventStatus
            || isset(self::$createdPostIds[$eventId])
            || self::isFirstEditorSave($eventId)
            || get_post_status($eventId) !== 'publish'
            || !self::isFirstRun($taskId, $eventId)
        ) {
            return;
        }

        $buildData = function () use ($eventId, $previousStatus) {
            $data = TheEventsCalendarHelper::getEventData($eventId);

            return empty($data) ? [] : $data + ['previous_event_status' => $previousStatus];
        };

        self::execute($taskId, $buildData, $eventId);
    }

    private static function hasPendingWork()
    {
        return !empty(self::$pendingPostTypes) || !empty(self::$pendingStatusEventIds) || !empty(self::$deferredExecutions);
    }

    private static function isFirstEditorSave($eventId)
    {
        // The block editor saves the status meta box in a second request, where the new event is no longer marked as created.
        $event = get_post($eventId);

        return self::isMetaBoxLoaderRequest() && $event && $event->post_date_gmt === $event->post_modified_gmt;
    }

    private static function isSavedPostChange($change, $postId)
    {
        $postStatus = get_post_status($postId);
        $isCreated = isset(self::$createdPostIds[$postId]);
        $isPublished = isset(self::$publishedPostIds[$postId]);

        switch ($change) {
            case 'created':
                return $isCreated && $postStatus !== 'auto-draft';

            case 'published':
                return $isPublished && $postStatus === 'publish';

            default:
                return !$isCreated && !$isPublished && $postStatus === 'publish';
        }
    }

    private static function isMetaBoxLoaderRequest()
    {
        // The block editor saves the classic meta boxes in a second request after the REST save.
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended
        return is_admin() && isset($_GET['meta-box-loader']);
    }

    private static function executeRemovedPostTrigger($taskId, $postType, $postId)
    {
        if (get_post_status($postId) === 'auto-draft' || !self::isFirstRun($taskId, $postId)) {
            return;
        }

        $filterValue = $postType === TheEventsCalendarHelper::EVENT_POST_TYPE ? $postId : null;

        self::execute($taskId, self::postDataBuilder($postType, $postId), $filterValue);
    }

    private static function executeSeriesCreated(WP_Post $series, $seriesBefore)
    {
        $taskId = 'events_calendar-21';

        if (
            $series->post_status !== 'publish'
            || ($seriesBefore instanceof WP_Post && $seriesBefore->post_status === 'publish')
            || !self::isFirstRun($taskId, $series->ID)
        ) {
            return;
        }

        self::executeLater(
            $taskId,
            function () use ($series) {
                return TheEventsCalendarHelper::getSeriesData($series->ID);
            }
        );
    }

    private static function executeAddedToSeries($seriesId, array $eventIds)
    {
        $taskId = 'events_calendar-20';

        if (!TheEventsCalendarHelper::isPostOfType($seriesId, TheEventsCalendarHelper::SERIES_POST_TYPE)) {
            return;
        }

        foreach ($eventIds as $eventId) {
            if (!self::isFirstRun($taskId, $seriesId . '-' . $eventId)) {
                continue;
            }

            $buildData = function () use ($eventId, $seriesId) {
                $data = TheEventsCalendarHelper::getEventData($eventId);

                return empty($data) ? [] : array_merge($data, self::getSeriesFields($seriesId));
            };

            self::executeLater($taskId, $buildData, $seriesId, 'selectedSeries');
        }
    }

    private static function getSeriesFields($seriesId)
    {
        $seriesFields = [];

        foreach (TheEventsCalendarHelper::getSeriesData($seriesId) as $key => $value) {
            $seriesFields[strpos($key, 'series_') === 0 ? $key : 'series_' . $key] = $value;
        }

        return $seriesFields;
    }

    private static function postDataBuilder($postType, $postId)
    {
        return function () use ($postType, $postId) {
            switch ($postType) {
                case TheEventsCalendarHelper::EVENT_POST_TYPE:
                    return TheEventsCalendarHelper::getEventData($postId);

                case TheEventsCalendarHelper::VENUE_POST_TYPE:
                    return TheEventsCalendarHelper::getVenueData($postId);

                default:
                    return TheEventsCalendarHelper::getOrganizerData($postId);
            }
        };
    }

    private static function isFirstRun($taskId, $recordKey)
    {
        $handledKey = $taskId . ':' . $recordKey;

        if (isset(self::$handledTriggerKeys[$handledKey])) {
            return false;
        }

        self::$handledTriggerKeys[$handledKey] = true;

        return true;
    }

    private static function getFlows($taskId)
    {
        if (self::$flowsByTask === null) {
            $flowClass = bit_integrations_get_class('Flow\\Flow');
            self::$flowsByTask = [];

            foreach ($flowClass::exists('EventsCalendar') ?: [] as $flow) {
                self::$flowsByTask[$flow->triggered_entity_id][] = $flow;
            }
        }

        return self::$flowsByTask[$taskId] ?? [];
    }

    private static function hasFlows(...$taskIds)
    {
        foreach ($taskIds as $taskId) {
            if (!empty(self::getFlows($taskId))) {
                return true;
            }
        }

        return false;
    }

    // TEC turns PHP notices into exceptions while its ORM saves, so flows that start inside a save run at shutdown.
    private static function executeLater($taskId, callable $buildData, $filterValue = null, $filterKey = 'selectedEvent')
    {
        if (self::hasFlows($taskId)) {
            self::$deferredExecutions[] = [$taskId, $buildData, $filterValue, $filterKey];
        }
    }

    private static function execute($taskId, callable $buildData, $filterValue = null, $filterKey = 'selectedEvent')
    {
        $flows = self::getFlows($taskId);

        if ($filterValue !== null) {
            $flows = EventsCalendarHelper::flowFilter($flows, $filterKey, $filterValue);
        }

        if (empty($flows)) {
            return;
        }

        $data = $buildData();

        if (!empty($data)) {
            $flowClass = bit_integrations_get_class('Flow\\Flow');
            $flowClass::execute('EventsCalendar', $taskId, $data, $flows);
        }
    }
}
