<?php

namespace BitApps\IntegrationsPro\Actions\Booknetic\Services;

use BitApps\IntegrationsPro\Triggers\Booknetic\BookneticHelper;
use BookneticApp\Backend\Payments\DTOs\SavePaymentRequest;
use BookneticApp\Backend\Payments\Repositories\PaymentRepository;
use BookneticApp\Backend\Payments\Services\PaymentService as BookneticPaymentService;
use BookneticApp\Models\Appointment;
use BookneticApp\Models\AppointmentPrice;

final class PaymentService extends BaseService
{
    public function updatePayment(): array
    {
        $error = $this->validate([
            'appointment_id' => [__('Appointment ID', 'bit-integrations-pro'), 'integer'],
            'payment_status' => [__('Payment Status', 'bit-integrations-pro')],
        ]);

        if ($error !== null) {
            return $error;
        }

        $appointmentId = $this->int('appointment_id');

        if (empty(Appointment::query()->get($appointmentId))) {
            return $this->error(__('The appointment does not exist. Select a different appointment.', 'bit-integrations-pro'));
        }

        $status = $this->string('payment_status');

        if (!\in_array($status, AppointmentService::PAYMENT_STATUSES, true)) {
            return $this->error(__('The payment status is not valid. Use pending, paid, canceled or not_paid.', 'bit-integrations-pro'));
        }

        $prices = [];

        if ($this->has('service_price')) {
            $servicePrice = $this->string('service_price');

            if (!is_numeric($servicePrice) || (float) $servicePrice < 0) {
                return $this->error(__('The service price is not valid. Enter 0 or a larger number.', 'bit-integrations-pro'));
            }

            $prices = self::currentPrices($appointmentId);

            if (!isset($prices['service_price'])) {
                return $this->error(__('The appointment has no service price to change.', 'bit-integrations-pro'));
            }

            $prices['service_price'] = (float) $servicePrice;
        }

        $paidAmount = $this->string('paid_amount');

        if ($paidAmount !== '' && (!is_numeric($paidAmount) || (float) $paidAmount < 0)) {
            return $this->error(__('The paid amount is not valid. Enter 0 or a larger number.', 'bit-integrations-pro'));
        }

        $request = (new SavePaymentRequest())
            ->setAppointmentId($appointmentId)
            ->setPrices($prices)
            ->setStatus($status);

        if ($paidAmount !== '') {
            $request->setPaidAmount((float) $paidAmount);
        }

        (new BookneticPaymentService(new PaymentRepository()))->savePayment($request);

        if ($paidAmount !== '' && (float) $paidAmount === 0.0) {
            Appointment::query()->where('id', $appointmentId)->update(['paid_amount' => 0]);
        }

        return $this->success(BookneticHelper::getAppointmentData($appointmentId));
    }

    public function completePayment(): array
    {
        $error = $this->validate(['appointment_id' => [__('Appointment ID', 'bit-integrations-pro'), 'integer']]);

        if ($error !== null) {
            return $error;
        }

        $appointmentId = $this->int('appointment_id');

        if (empty(Appointment::query()->get($appointmentId))) {
            return $this->error(__('The appointment does not exist. Select a different appointment.', 'bit-integrations-pro'));
        }

        (new BookneticPaymentService(new PaymentRepository()))->completePayment($appointmentId);

        return $this->success(BookneticHelper::getAppointmentData($appointmentId));
    }

    private static function currentPrices(int $appointmentId): array
    {
        $prices = [];

        foreach (AppointmentPrice::query()->where('appointment_id', $appointmentId)->fetchAll() as $price) {
            $prices[$price->unique_key] = (float) $price->price;
        }

        return $prices;
    }
}
