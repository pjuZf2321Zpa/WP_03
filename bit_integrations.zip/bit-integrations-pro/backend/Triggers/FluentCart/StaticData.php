<?php

namespace BitApps\IntegrationsPro\Triggers\FluentCart;

class StaticData
{
    public static function tasks()
    {
        return [
            [
                'form_name'           => __('Product Purchased', 'bit-integrations-pro'),
                'triggered_entity_id' => 'fluent_cart/checkout/prepare_other_data',
                'skipPrimaryKey'      => true,
            ],
            [
                'form_name'           => __('Product Updated', 'bit-integrations-pro'),
                'triggered_entity_id' => 'fluent_cart/product_updated',
                'skipPrimaryKey'      => true,
            ],
            [
                'form_name'           => __('Product Stock Updated', 'bit-integrations-pro'),
                'triggered_entity_id' => 'fluent_cart/product_stock_changed',
                'skipPrimaryKey'      => true,
            ],
            [
                'form_name'           => __('Coupon Created', 'bit-integrations-pro'),
                'triggered_entity_id' => 'fluent_cart/coupon_created',
                'skipPrimaryKey'      => true,
            ],
            [
                'form_name'           => __('Coupon Updated', 'bit-integrations-pro'),
                'triggered_entity_id' => 'fluent_cart/coupon_updated',
                'skipPrimaryKey'      => true,
            ],
            [
                'form_name'           => __('Cart Item Added', 'bit-integrations-pro'),
                'triggered_entity_id' => 'fluent_cart/cart/item_added',
                'skipPrimaryKey'      => true,
            ],
            [
                'form_name'           => __('Cart Item Removed', 'bit-integrations-pro'),
                'triggered_entity_id' => 'fluent_cart/cart/item_removed',
                'skipPrimaryKey'      => true,
            ],
            [
                'form_name'           => __('Cart Items Updated', 'bit-integrations-pro'),
                'triggered_entity_id' => 'fluent_cart/cart/cart_data_items_updated',
                'skipPrimaryKey'      => true,
            ],
            [
                'form_name'           => __('Cart Updated', 'bit-integrations-pro'),
                'triggered_entity_id' => 'fluent_cart/checkout/cart_amount_updated',
                'skipPrimaryKey'      => true,
            ],
            [
                'form_name'           => __('Cart Completed', 'bit-integrations-pro'),
                'triggered_entity_id' => 'fluent_cart/cart_completed',
                'skipPrimaryKey'      => true,
            ],
            [
                'form_name'           => __('Order Receipt Rendered', 'bit-integrations-pro'),
                'triggered_entity_id' => 'fluent_cart/after_receipt',
                'skipPrimaryKey'      => true,
            ],
            [
                'form_name'           => __('Order Created', 'bit-integrations-pro'),
                'triggered_entity_id' => 'fluent_cart/order_created',
                'skipPrimaryKey'      => true,
            ],
            [
                'form_name'           => __('Order Updated', 'bit-integrations-pro'),
                'triggered_entity_id' => 'fluent_cart/order_updated',
                'skipPrimaryKey'      => true,
            ],
            [
                'form_name'           => __('Order Deleted', 'bit-integrations-pro'),
                'triggered_entity_id' => 'fluent_cart/order_deleted',
                'skipPrimaryKey'      => true,
            ],
            [
                'form_name'           => __('Order Refunded (Full or Partial)', 'bit-integrations-pro'),
                'triggered_entity_id' => 'fluent_cart/order_refunded',
                'skipPrimaryKey'      => true,
            ],
            [
                'form_name'           => __('Order Refunded (Partial)', 'bit-integrations-pro'),
                'triggered_entity_id' => 'fluent_cart/order_partially_refunded',
                'skipPrimaryKey'      => true,
            ],
            [
                'form_name'           => __('Order Refunded (Full)', 'bit-integrations-pro'),
                'triggered_entity_id' => 'fluent_cart/order_fully_refunded',
                'skipPrimaryKey'      => true,
            ],
            [
                'form_name'           => __('Order Cancelled', 'bit-integrations-pro'),
                'triggered_entity_id' => 'fluent_cart/order_status_changed_to_canceled',
                'skipPrimaryKey'      => true,
            ],
            [
                'form_name'           => __('Order Status Changed', 'bit-integrations-pro'),
                'triggered_entity_id' => 'fluent_cart/order_status_changed',
                'skipPrimaryKey'      => true,
            ],
            [
                'form_name'           => __('Order Status Updated To Processing', 'bit-integrations-pro'),
                'triggered_entity_id' => 'fluent_cart/order_status_changed_to_processing',
                'skipPrimaryKey'      => true,
            ],
            [
                'form_name'           => __('Order Status Updated To Completed', 'bit-integrations-pro'),
                'triggered_entity_id' => 'fluent_cart/order_status_changed_to_completed',
                'skipPrimaryKey'      => true,
            ],
            [
                'form_name'           => __('Order Status Updated To On-Hold', 'bit-integrations-pro'),
                'triggered_entity_id' => 'fluent_cart/order_status_changed_to_on-hold',
                'skipPrimaryKey'      => true,
            ],
            [
                'form_name'           => __('Order Shipping Status Changed', 'bit-integrations-pro'),
                'triggered_entity_id' => 'fluent_cart/shipping_status_changed',
                'skipPrimaryKey'      => true,
            ],
            [
                'form_name'           => __('Order Shipped', 'bit-integrations-pro'),
                'triggered_entity_id' => 'fluent_cart/shipping_status_changed_to_shipped',
                'skipPrimaryKey'      => true,
            ],
            [
                'form_name'           => __('Order Unshipped', 'bit-integrations-pro'),
                'triggered_entity_id' => 'fluent_cart/shipping_status_changed_to_unshipped',
                'skipPrimaryKey'      => true,
            ],
            [
                'form_name'           => __('Order Unshippable', 'bit-integrations-pro'),
                'triggered_entity_id' => 'fluent_cart/shipping_status_changed_to_unshippable',
                'skipPrimaryKey'      => true,
            ],
            [
                'form_name'           => __('Order Delivered', 'bit-integrations-pro'),
                'triggered_entity_id' => 'fluent_cart/shipping_status_changed_to_delivered',
                'skipPrimaryKey'      => true,
            ],
            [
                'form_name'           => __('Order Marked As Paid', 'bit-integrations-pro'),
                'triggered_entity_id' => 'fluent_cart/order_paid_done',
                'skipPrimaryKey'      => true,
            ],
            [
                'form_name'           => __('Order Customer Changed', 'bit-integrations-pro'),
                'triggered_entity_id' => 'fluent_cart/order_customer_changed',
                'skipPrimaryKey'      => true,
            ],
            [
                'form_name'           => __('Customer Created', 'bit-integrations-pro'),
                'triggered_entity_id' => 'fluent_cart/user/after_register',
                'skipPrimaryKey'      => true,
            ],
        ];
    }
}
