<?php

namespace FluentCartPro\App\Modules\Promotional\OrderBump\Cards;

class ToggleCard extends AbstractCard
{
    public static function key(): string
    {
        return 'toggle';
    }

    public static function title(): string
    {
        return __('Toggle Card', 'fluent-cart-pro');
    }

    public static function description(): string
    {
        return __('A peach card with a switch.', 'fluent-cart-pro');
    }

    public static function content(): string
    {
        $checkbox = '<!-- wp:fluent-cart/order-bump-checkbox ' . wp_json_encode(['label' => sprintf(__('Grab it for %s', 'fluent-cart-pro'), '{{bump.price}}')]) . ' /-->';

        $prices = self::group(
            'fct_bump_toggle_prices',
            self::element('original-price', 'fct_bump_toggle_original') . "\n\n"
            . self::element('price', 'fct_bump_toggle_price') . "\n\n"
            . self::element('savings', 'fct_bump_toggle_savings')
        );

        $details = self::element('product-title', 'fct_bump_toggle_product') . "\n\n"
            . self::element('variation-title', 'fct_bump_toggle_variation') . "\n\n"
            . $prices;

        return self::group(
            'fct_bump_toggle',
            self::element('image', 'fct_bump_toggle_icon') . "\n\n"
            . self::group('fct_bump_toggle_details', $details) . "\n\n"
            . $checkbox
        );
    }

    public static function css(): string
    {
        // The switch rules are long on purpose: they must beat the checkbox look of the checkout, drawer and cart page.
        return <<<'CSS'
.fct_bump_toggle {
    --fct-bump-toggle-border: #f6d6b4;
    position: relative;
    display: flex;
    align-items: center;
    column-gap: 14px;
    box-sizing: border-box;
    padding: 16px;
    border: 1px dashed var(--fct-bump-toggle-border);
    border-radius: 12px;
    background: #fdf6ec;
    cursor: pointer;
    transition: border-color .15s ease;
}
.fct_bump_toggle:hover {
    --fct-bump-toggle-border: #e3a566;
}
.fct_bump_toggle .wp-block {
    margin: 0;
}
.fct_bump_toggle .fct_bump_toggle_icon {
    flex: none;
    width: 60px;
    height: 60px;
    border-radius: 8px;
    overflow: hidden;
    background: #f3f4f6;
}
.fct_bump_toggle .fct_bump_toggle_icon img {
    display: block;
    width: 100%;
    height: 100%;
    object-fit: cover;
}
.fct_bump_toggle .fct_bump_toggle_icon img[src=""] {
    display: none;
}
.fct_bump_toggle .fct_bump_toggle_details {
    flex: 1;
    min-width: 0;
}
.fct_bump_toggle p {
    margin: 0;
}
.fct_bump_toggle .fct_bump_toggle_product {
    font-size: 15px;
    font-weight: 600;
    line-height: 1.3;
    color: var(--fct-primary-text-color, #111827);
}
.fct_bump_toggle .fct_bump_toggle_variation {
    margin-top: 2px;
    font-size: 13px;
    line-height: 1.4;
    color: var(--fct-secondary-text-color, #6b7280);
}
.fct_bump_toggle .fct_bump_toggle_prices {
    display: flex;
    flex-wrap: wrap;
    align-items: baseline;
    column-gap: 8px;
    margin-top: 4px;
}
.fct_bump_toggle .fct_bump_toggle_original {
    font-size: 15px;
    text-decoration: line-through;
    color: var(--fct-secondary-text-color, #6b7280);
}
.fct_bump_toggle .fct_bump_toggle_price {
    font-size: 15px;
    font-weight: 600;
    color: var(--fct-primary-text-color, #111827);
}
.fct_bump_toggle .fct_bump_toggle_savings {
    font-size: 13px;
    color: #c0392b;
}
.fct_bump_toggle .fct_bump_toggle_variation:empty,
.fct_bump_toggle .fct_bump_toggle_original:empty,
.fct_bump_toggle .fct_bump_toggle_savings:empty {
    display: none;
}
.fct_bump_toggle label.fct_order_promotion_toggle {
    flex: none;
    margin: 0;
    padding: 0;
}
/* The label stretches over the card, so a click anywhere toggles the switch. */
.fct_bump_toggle label.fct_order_promotion_toggle::after {
    content: "";
    position: absolute;
    inset: 0;
    border-radius: inherit;
}
.editor-styles-wrapper .fct_bump_toggle label.fct_order_promotion_toggle::after,
.block-editor-block-list__layout .fct_bump_toggle label.fct_order_promotion_toggle::after {
    content: none;
}
.fct_bump_toggle label.fct_order_promotion_toggle > span {
    position: absolute;
    width: 1px;
    height: 1px;
    margin: -1px;
    padding: 0;
    overflow: hidden;
    clip: rect(0, 0, 0, 0);
    white-space: nowrap;
    border: 0;
}
.fct_bump_toggle label.fct_order_promotion_toggle input.fct_order_promotion_input[type="checkbox"] {
    appearance: none;
    -webkit-appearance: none;
    position: relative;
    display: block;
    flex: none;
    box-sizing: border-box;
    width: 52px;
    height: 26px;
    min-height: 0;
    margin: 0;
    padding: 0 !important;
    border: 0;
    border-radius: 999px;
    background: #d9dce1;
    cursor: pointer;
    transition: background-color .2s ease;
}
.fct_bump_toggle label.fct_order_promotion_toggle input.fct_order_promotion_input[type="checkbox"]::before {
    content: "";
    position: absolute;
    top: 3px;
    inset-inline-start: 3px;
    box-sizing: border-box;
    width: 20px;
    height: 20px;
    margin: 0;
    border: 0;
    border-radius: 50%;
    background: #fff;
    box-shadow: 0 1px 2px rgba(0, 0, 0, .25);
    opacity: 1;
    transform: none;
    transition: transform .2s ease;
}
.fct_bump_toggle label.fct_order_promotion_toggle input.fct_order_promotion_input[type="checkbox"]:checked,
.fct_bump_toggle label.fct_order_promotion_toggle input.fct_order_promotion_input[type="checkbox"]:hover:checked {
    background: var(--fct-primary-bg-color, #253241);
    border-color: transparent;
}
.fct_bump_toggle label.fct_order_promotion_toggle input.fct_order_promotion_input[type="checkbox"]:checked::before {
    opacity: 1;
    transform: translateX(26px);
}
[dir="rtl"] .fct_bump_toggle label.fct_order_promotion_toggle input.fct_order_promotion_input[type="checkbox"]:checked::before {
    transform: translateX(-26px);
}
.fct_bump_toggle label.fct_order_promotion_toggle input.fct_order_promotion_input[type="checkbox"]:focus-visible {
    outline: 2px solid var(--fct-primary-bg-color, #253241);
    outline-offset: 2px;
}
@media (prefers-reduced-motion: reduce) {
    .fct_bump_toggle,
    .fct_bump_toggle label.fct_order_promotion_toggle input.fct_order_promotion_input[type="checkbox"],
    .fct_bump_toggle label.fct_order_promotion_toggle input.fct_order_promotion_input[type="checkbox"]::before {
        transition: none;
    }
}
CSS;
    }
}
