<?php

namespace BitApps\IntegrationsPro\Actions\NextCrm;

final class NextCrmProHelper
{
    /**
     * Contact columns writable through the field map.
     */
    private const CONTACT_COLUMNS = ['email_address', 'first_name', 'last_name', 'photo', 'rating'];

    /**
     * Field-map keys stored inside the contact's `additional` JSON column.
     */
    private const ADDITIONAL_KEYS = ['mobile', 'source', 'date_of_birth', 'gender', 'address', 'city', 'state', 'zip', 'country'];

    /**
     * Tags and lists are the same shape in NextCRM, only the table and writer differ.
     */
    private const TAXONOMIES = [
        'tags' => ['writer' => 'action_tag_to_contact', 'reader' => 'get_tags', 'conf' => 'selectedTag'],
        'list' => ['writer' => 'action_list_to_contact', 'reader' => 'get_lists', 'conf' => 'selectedList'],
    ];

    public static function createContact($response, $fieldData, $utilities = null)
    {
        if (($error = self::guard(['email_address' => $fieldData['email_address'] ?? ''])) !== null) {
            return $error;
        }

        return self::saveContact(0, $fieldData, $utilities);
    }

    public static function updateContact($response, $fieldData, $utilities = null)
    {
        $contact = self::contactByEmail($fieldData['contact_email'] ?? '');

        // `insert_contact()` treats id 0 as create, so an unresolved email would add a contact.
        if (empty($contact)) {
            return self::error(__('No contact found for the given email.', 'bit-integrations-pro'));
        }

        return self::saveContact((int) ($contact['id'] ?? 0), $fieldData, $utilities);
    }

    public static function deleteContact($response, $fieldData)
    {
        $contact = self::contactByEmail($fieldData['contact_email'] ?? '');
        $contactId = (int) ($contact['id'] ?? 0);

        if (empty($contact)) {
            return self::error(__('No contact found for the given email.', 'bit-integrations-pro'));
        }

        global $wpdb;

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- plugin table has no WP API
        // `contact_delete()` answers with `wp_send_json_*()`, which ends the request.
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- plugin table has no WP API
        $deleted = $wpdb->delete(nextcrm_manager()->contact->_table('contact'), ['id' => $contactId], ['%d']);

        if ($deleted === false) {
            return self::error(__('Failed to delete the contact.', 'bit-integrations-pro'));
        }

        nextcrm_manager()->contact->delete_activities_by_contact($contactId);

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- plugin table has no WP API
        $wpdb->delete(nextcrm_manager()->contact->_table('contact_meta'), ['contact_id' => $contactId], ['%d']);

        do_action('nextcrm/contact/delete', $contactId);

        return self::success(__('Contact deleted successfully.', 'bit-integrations-pro'), ['contact_id' => $contactId]);
    }

    public static function changeContactStatus($response, $fieldData, $integrationDetails = null)
    {
        $contactId = self::resolveContactId($fieldData);
        $status = $integrationDetails->selectedStatus ?? '';

        if ($contactId <= 0 || empty($status)) {
            return self::error(__('A known contact email and a status are required.', 'bit-integrations-pro'));
        }

        $result = nextcrm_manager()->crm->insert_contact($contactId, ['status' => $status], 'Bit Integrations');

        if (empty($result['status'])) {
            return self::error($result['message'] ?? __('Failed to update the contact status.', 'bit-integrations-pro'));
        }

        return self::success(__('Contact status updated successfully.', 'bit-integrations-pro'), ['contact_id' => $contactId]);
    }

    public static function updateContactField($response, $fieldData, $integrationDetails = null)
    {
        $contactId = self::resolveContactId($fieldData);
        $field = $integrationDetails->selectedField ?? '';

        if ($contactId <= 0 || empty($field)) {
            return self::error(__('A known contact email and a field are required.', 'bit-integrations-pro'));
        }

        $updated = nextcrm_manager()->contact->update_contact_field($field, $fieldData['value'] ?? '', $contactId);

        if (!$updated) {
            return self::error(__('Failed to update the contact field. Check the contact and the field name.', 'bit-integrations-pro'));
        }

        return self::success(__('Contact field updated successfully.', 'bit-integrations-pro'), ['contact_id' => $contactId]);
    }

    public static function addContactActivity($response, $fieldData, $utilities = null)
    {
        $contactId = self::resolveContactId($fieldData);
        $title = $fieldData['title'] ?? '';

        if ($contactId <= 0 || empty($title)) {
            return self::error(__('A known contact email and a title are required.', 'bit-integrations-pro'));
        }

        $activity = [
            'contact_id'  => $contactId,
            'title'       => $title,
            'description' => $fieldData['description'] ?? '',
            'status'      => self::utility($utilities, 'selected_activity_status') ?: 'active',
            'created_at'  => current_time('mysql'),
        ];

        global $wpdb;

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- plugin table has no WP API
        // `add_activity()` switches to an AJAX response whenever `$_POST['contact_id']` exists.
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- plugin table has no WP API
        $inserted = $wpdb->insert(nextcrm_manager()->contact->_table('activity'), $activity, ['%d', '%s', '%s', '%s', '%s']);

        if (!$inserted) {
            return self::error(__('Failed to add the contact activity.', 'bit-integrations-pro'));
        }

        $activity['id'] = (int) $wpdb->insert_id;

        return self::success(__('Contact activity added successfully.', 'bit-integrations-pro'), $activity);
    }

    public static function createTag($response, $fieldData)
    {
        return self::createTaxonomy('tags', $fieldData, __('Failed to create the tag.', 'bit-integrations-pro'));
    }

    public static function createList($response, $fieldData)
    {
        return self::createTaxonomy('list', $fieldData, __('Failed to create the list.', 'bit-integrations-pro'));
    }

    public static function addTagToContact($response, $fieldData, $integrationDetails = null)
    {
        return self::applyTaxonomy('tags', 'add', $fieldData, $integrationDetails, __('Tag not found for the given contact.', 'bit-integrations-pro'));
    }

    public static function removeTagFromContact($response, $fieldData, $integrationDetails = null)
    {
        return self::applyTaxonomy('tags', 'remove', $fieldData, $integrationDetails, __('Tag not found for the given contact.', 'bit-integrations-pro'));
    }

    public static function addContactToList($response, $fieldData, $integrationDetails = null)
    {
        return self::applyTaxonomy('list', 'add', $fieldData, $integrationDetails, __('List not found for the given contact.', 'bit-integrations-pro'));
    }

    public static function removeContactFromList($response, $fieldData, $integrationDetails = null)
    {
        return self::applyTaxonomy('list', 'remove', $fieldData, $integrationDetails, __('List not found for the given contact.', 'bit-integrations-pro'));
    }

    public static function sendCampaignEmail($response, $fieldData, $utilities = null, $integrationDetails = null)
    {
        $contact = self::contactByEmail($fieldData['contact_email'] ?? '');
        $contactId = (int) ($contact['id'] ?? 0);
        $campaignId = (int) ($integrationDetails->selectedCampaign ?? 0);
        $body = $fieldData['body'] ?? '';

        // The queue processor falls back to the campaign subject, but fails an empty body.
        if ($contactId <= 0 || $campaignId <= 0 || empty($body)) {
            return self::error(__('A known contact email, a campaign and an email body are required.', 'bit-integrations-pro'));
        }

        if (empty(nextcrm_manager()->campaign->get_campaign_by_id($campaignId))) {
            return self::error(__('Campaign not found.', 'bit-integrations-pro'));
        }

        $queued = nextcrm_manager()->campaign->add_to_queue(
            [
                'id'            => $contactId,
                'email_address' => $contact['email_address'] ?? '',
                'name'          => trim(($contact['first_name'] ?? '') . ' ' . ($contact['last_name'] ?? '')),
            ],
            $campaignId,
            $body,
            $fieldData['subject'] ?? '',
            self::utility($utilities, 'selected_skip_already_sent') ?: 'no'
        );

        if (!$queued) {
            return self::error(__('NextCRM refused the email. The contact address is invalid or already blocked.', 'bit-integrations-pro'));
        }

        return self::success(__('Campaign email queued successfully.', 'bit-integrations-pro'), ['campaign_id' => $campaignId, 'contact_id' => $contactId]);
    }

    /**
     * Create or update a contact through NextCRM's own writer so every
     * `nextcrm/contact/*` hook still fires.
     *
     * @param int   $contactId 0 creates, > 0 updates
     * @param array $fieldData
     * @param mixed $utilities
     *
     * @return array
     */
    private static function saveContact($contactId, $fieldData, $utilities)
    {
        $payload = [];

        foreach (self::CONTACT_COLUMNS as $column) {
            if (isset($fieldData[$column]) && $fieldData[$column] !== '') {
                $payload[$column] = $fieldData[$column];
            }
        }

        if (isset($fieldData['new_email_address']) && $fieldData['new_email_address'] !== '') {
            $payload['email_address'] = $fieldData['new_email_address'];
        }

        $additional = [];

        foreach (self::ADDITIONAL_KEYS as $key) {
            if (isset($fieldData[$key]) && $fieldData[$key] !== '') {
                $additional[$key] = $fieldData[$key];
            }
        }

        if (!empty($additional)) {
            $payload['additional'] = wp_json_encode($additional);
        }

        foreach (['contact_type' => 'selected_contact_type', 'status' => 'selected_status'] as $column => $utilityKey) {
            $value = self::utility($utilities, $utilityKey);

            if (!empty($value)) {
                $payload[$column] = $value;
            }
        }

        foreach (['list' => 'selected_lists', 'tags' => 'selected_tags'] as $column => $utilityKey) {
            // A cleared multi-select can arrive as [''], which would store an empty entry.
            $value = array_values(array_filter((array) self::utility($utilities, $utilityKey), 'strlen'));

            if (!empty($value)) {
                $payload[$column] = wp_json_encode($value);
            }
        }

        if (empty($payload)) {
            return self::error(__('No contact field was mapped.', 'bit-integrations-pro'));
        }

        $result = nextcrm_manager()->crm->insert_contact($contactId, $payload, 'Bit Integrations');

        if (empty($result['status'])) {
            return self::error($result['message'] ?? __('Failed to save the contact.', 'bit-integrations-pro'));
        }

        return self::success($result['message'] ?? __('Contact saved successfully.', 'bit-integrations-pro'), ['contact_id' => $result['id'] ?? $contactId]);
    }

    private static function createTaxonomy($type, $fieldData, $failureMessage)
    {
        $title = $fieldData['title'] ?? '';

        if (empty($title)) {
            return self::error(__('A title is required.', 'bit-integrations-pro'));
        }

        $name = $fieldData['name'] ?? '';
        $slug = $name !== '' ? $name : strtolower(str_replace(' ', '_', (string) $title));
        $existing = self::findTaxonomyRowByName($type, $slug);

        // `add_update_list()` skips the insert when the slug is taken, so resolve it up front.
        if (!empty($existing)) {
            return self::success(__('Already exists.', 'bit-integrations-pro'), array_merge($existing, ['created' => false]));
        }

        nextcrm_manager()->crm->add_update_list(
            $type,
            [
                'title'       => $title,
                'name'        => $slug,
                'description' => $fieldData['description'] ?? '',
            ]
        );

        $created = self::findTaxonomyRowByName($type, $slug);

        if (empty($created)) {
            return self::error($failureMessage);
        }

        return self::success(__('Created successfully.', 'bit-integrations-pro'), array_merge($created, ['created' => true]));
    }

    private static function applyTaxonomy($type, $action, $fieldData, $integrationDetails, $notFoundMessage)
    {
        $taxonomy = self::TAXONOMIES[$type];
        $contact = self::contactByEmail($fieldData['contact_email'] ?? '');
        $contactId = (int) ($contact['id'] ?? 0);
        $selected = $integrationDetails->{$taxonomy['conf']} ?? '';

        if ($contactId <= 0 || empty($selected)) {
            return self::error(__('A known contact email and a selection are required.', 'bit-integrations-pro'));
        }

        self::normalizeContactJsonColumn($contactId, $type, $contact);

        $applied = nextcrm_manager()->contact->{$taxonomy['writer']}($selected, $contactId, $action);

        if (!$applied) {
            return self::error($notFoundMessage);
        }

        return self::success(__('Contact updated successfully.', 'bit-integrations-pro'), ['contact_id' => $contactId]);
    }

    /**
     * `add_update_list()` answers with a duplicate count instead of an id, so the
     * stored row is read back by slug through the plugin's own list readers.
     *
     * @param string $type
     * @param string $name
     *
     * @return array
     */
    private static function findTaxonomyRowByName($type, $name)
    {
        $reader = self::TAXONOMIES[$type]['reader'];

        foreach ((array) nextcrm_manager()->contact->{$reader}('array') as $row) {
            $row = (array) $row;

            if (($row['name'] ?? '') === $name) {
                return $row;
            }
        }

        return [];
    }

    /**
     * `action_tag_to_contact()`/`action_list_to_contact()` hand an empty column's `[]`
     * fallback to `json_decode()` — a TypeError on PHP 8.
     *
     * @param int    $contactId
     * @param string $column
     * @param array  $contact
     *
     * @return void
     */
    private static function normalizeContactJsonColumn($contactId, $column, $contact)
    {
        if (\is_array(json_decode($contact[$column] ?? '', true))) {
            return;
        }

        global $wpdb;

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- plugin table has no WP API
        $wpdb->update(
            nextcrm_manager()->contact->_table('contact'),
            [$column => wp_json_encode([])],
            ['id' => (int) $contactId],
            ['%s'],
            ['%d']
        );
    }

    /**
     * Actions identify their target by email, because that is what trigger data carries.
     *
     * @param array $fieldData
     *
     * @return int
     */
    private static function resolveContactId($fieldData)
    {
        $contact = self::contactByEmail($fieldData['contact_email'] ?? '');

        return (int) ($contact['id'] ?? 0);
    }

    private static function contactByEmail($email)
    {
        if (empty($email)) {
            return [];
        }

        return (array) nextcrm_manager()->contact->get_contact_by_email($email);
    }

    private static function utility($utilities, $key)
    {
        if (\is_object($utilities)) {
            return $utilities->{$key} ?? '';
        }

        return \is_array($utilities) ? ($utilities[$key] ?? '') : '';
    }

    private static function guard($required)
    {
        foreach ($required as $key => $value) {
            if (empty($value)) {
                // translators: %s: field name
                return self::error(wp_sprintf(__('%s is required.', 'bit-integrations-pro'), $key));
            }
        }

        return null;
    }

    private static function success($message, $data = [])
    {
        return ['success' => true, 'message' => $message, 'data' => $data];
    }

    private static function error($message)
    {
        return ['success' => false, 'message' => $message];
    }
}
