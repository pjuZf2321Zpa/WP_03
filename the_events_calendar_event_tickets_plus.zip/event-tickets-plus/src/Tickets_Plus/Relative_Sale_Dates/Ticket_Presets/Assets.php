<?php
/**
 * The assets of the relative sales dates of ticket presets.
 *
 * @since 6.12.0
 *
 * @package TEC\Tickets_Plus\Relative_Sale_Dates\Ticket_Presets
 */

namespace TEC\Tickets_Plus\Relative_Sale_Dates\Ticket_Presets;

use TEC\Common\Contracts\Provider\Controller as Controller_Contract;
use TEC\Common\StellarWP\Assets\Assets as Asset_Registry;
use TEC\Tickets_Plus\Ticket_Presets\Assets as Ticket_Presets_Assets;
use Tribe__Tickets_Plus__Main as ET_Plus;

/**
 * Registers the script and the styles of a preset's sales window, and the block editor script that gives a ticket the
 * rule of the preset it is filled in from.
 *
 * @since 6.12.0
 *
 * @package TEC\Tickets_Plus\Relative_Sale_Dates\Ticket_Presets
 */
final class Assets extends Controller_Contract {
	/**
	 * The group the assets are added to.
	 *
	 * @since 6.12.0
	 *
	 * @var string
	 */
	private const GROUP = 'tec-tickets-plus-relative-sale-dates';

	/**
	 * The slug of the script of a preset's sales window.
	 *
	 * @since 6.12.0
	 *
	 * @var string
	 */
	private const SALES_WINDOW_SCRIPT = 'tec-tickets-plus-relative-sale-dates-ticket-presets-js';

	/**
	 * The slug of the styles of a preset's sales window.
	 *
	 * @since 6.12.0
	 *
	 * @var string
	 */
	private const SALES_WINDOW_STYLE = 'tec-tickets-plus-relative-sale-dates-ticket-presets-css';

	/**
	 * The slug of the block editor script.
	 *
	 * @since 6.12.0
	 *
	 * @var string
	 */
	private const BLOCK_EDITOR_SCRIPT = 'tec-tickets-plus-relative-sale-dates-ticket-presets-block-editor';

	/**
	 * Unregisters the controller.
	 *
	 * @since 6.12.0
	 *
	 * @return void
	 */
	public function unregister(): void {
		Asset_Registry::init()->remove( self::SALES_WINDOW_SCRIPT );
		Asset_Registry::init()->remove( self::SALES_WINDOW_STYLE );
		Asset_Registry::init()->remove( self::BLOCK_EDITOR_SCRIPT );
	}

	/**
	 * Registers the controller.
	 *
	 * @since 6.12.0
	 *
	 * @return void
	 */
	protected function do_register(): void {
		tec_asset(
			ET_Plus::instance(),
			self::SALES_WINDOW_SCRIPT,
			'relative-sale-dates/ticket-presets.js',
			[ 'jquery', 'tribe-dependency' ],
			'admin_enqueue_scripts',
			[
				'groups'       => self::GROUP,
				'conditionals' => fn(): bool => $this->is_on_sales_window_page(),
			]
		);

		tec_asset(
			ET_Plus::instance(),
			self::SALES_WINDOW_STYLE,
			'relative-sale-dates/ticket-presets.css',
			[],
			'admin_enqueue_scripts',
			[
				'groups'       => self::GROUP,
				'conditionals' => fn(): bool => $this->is_on_sales_window_page(),
			]
		);

		tec_asset(
			ET_Plus::instance(),
			self::BLOCK_EDITOR_SCRIPT,
			'Relative_Sale_Dates/ticketPresets.js',
			[],
			'enqueue_block_editor_assets',
			[
				'group_path' => ET_Plus::class . '-packages',
				'groups'     => self::GROUP,
			]
		);
	}

	/**
	 * Returns whether the page shows a preset's sales window: the preset form, or the classic editor, whose ticket
	 * panel holds the *Save as preset* modal.
	 *
	 * @since 6.12.0
	 *
	 * @return bool Whether the page shows a preset's sales window.
	 */
	private function is_on_sales_window_page(): bool {
		$presets_assets = $this->container->get( Ticket_Presets_Assets::class );

		return $presets_assets->tec_tickets_plus_preset_form_page() || $presets_assets->is_editing_post();
	}
}
