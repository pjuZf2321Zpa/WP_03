<?php

namespace FluentCartPro\App\Hooks\Handlers\BlockEditors\PdfBlocks;

use FluentCart\App\Hooks\Handlers\BlockEditors\BlockEditor;

class ReceiptFooterBlockEditor extends BlockEditor
{
    use \FluentCartPro\App\Contracts\CanEnqueue;

    protected static string $editorName = 'receipt-footer';

    public function getScripts(): array
    {
        return [
            [
                'source'       => 'admin/BlockEditor/PdfBlocks/ReceiptFooterBlockEditor.jsx',
                'dependencies' => ['wp-blocks', 'wp-components', 'wp-block-editor']
            ]
        ];
    }

    public function getStyles(): array
    {
        return [];
    }

    public function localizeData(): array
    {
        return [
            $this->getLocalizationKey() => [
                'slug'        => $this->slugPrefix,
                'name'        => static::getEditorName(),
                'title'       => __('Receipt Footer', 'fluent-cart-pro'),
                'description' => __('Footer note for PDF receipts.', 'fluent-cart-pro'),
            ],
            'fluent_cart_block_translation' => \FluentCart\App\Services\Translations\TransStrings::blockStrings(),
        ];
    }

    public function blockAttributes(): array
    {
        return [
            'text'      => ['type' => 'string',  'default' => 'Thank you for your purchase!'],
            'textColor' => ['type' => 'string',  'default' => '#666666'],
            'fontSize'  => ['type' => 'number',  'default' => 10],
        ];
    }

    public function supports(): array
    {
        return [
            'html'    => false,
            'align'   => false,
            'spacing' => ['margin' => true, 'padding' => true],
        ];
    }

    public function render(array $attrs, $block = null, $content = ''): string
    {
        $text      = esc_html($attrs['text']      ?? 'Thank you for your purchase!');
        $textColor = esc_attr($attrs['textColor'] ?? '#666666');
        $fontSize  = (int)($attrs['fontSize']     ?? 10);

        return '<p style="margin-top:32px;padding-top:12px;border-top:1px solid #DDDDDD;'
             . 'font-size:' . $fontSize . 'px;color:' . $textColor . ';text-align:center;">'
             . $text
             . '</p>';
    }
}
