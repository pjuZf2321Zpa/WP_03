<?php

namespace WPAICG\Lib\Integrations\Logs;

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

class AIPKit_Recipe_Delivery_Log_Maintenance
{
    private const CLEANUP_HOOK = 'aipkit_native_app_recipe_log_cleanup';

    public static function register_hooks(): void
    {
        add_action('init', [__CLASS__, 'bootstrap']);
        add_action(self::CLEANUP_HOOK, [__CLASS__, 'cleanup']);
    }

    public static function bootstrap(): void
    {
        if (!self::should_bootstrap()) {
            return;
        }

        AIPKit_Recipe_Delivery_Log_Store::ensure_table();

        if (!wp_next_scheduled(self::CLEANUP_HOOK)) {
            wp_schedule_event(time() + HOUR_IN_SECONDS, 'daily', self::CLEANUP_HOOK);
        }
    }

    public static function cleanup(): void
    {
        AIPKit_Recipe_Delivery_Log_Store::cleanup_expired_logs();
    }

    public static function unschedule_cleanup(): void
    {
        $timestamp = wp_next_scheduled(self::CLEANUP_HOOK);
        if ($timestamp) {
            wp_unschedule_event($timestamp, self::CLEANUP_HOOK);
        }

        wp_clear_scheduled_hook(self::CLEANUP_HOOK);
    }

    private static function should_bootstrap(): bool
    {
        if (is_admin() || wp_doing_cron()) {
            return true;
        }

        return defined('WP_CLI') && WP_CLI;
    }
}
