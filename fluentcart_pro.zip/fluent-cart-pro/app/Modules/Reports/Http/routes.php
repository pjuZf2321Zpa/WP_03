<?php

use FluentCart\Framework\Http\Router;
use FluentCartPro\App\Modules\Reports\Http\Controllers\ChannelRulesController;
use FluentCartPro\App\Modules\Reports\Http\Controllers\CustomerInsightsController;
use FluentCartPro\App\Modules\Reports\Http\Controllers\OrderPatternsController;
use FluentCartPro\App\Modules\Reports\Http\Controllers\PaymentInsightsController;
use FluentCartPro\App\Modules\Reports\Http\Controllers\ProductInsightsController;
use FluentCartPro\App\Modules\Reports\Http\Controllers\SubscriptionInsightsController;

/**
 * Same paths and policy as core's report routes; core 2+ no longer registers these
 *
 * @var Router $router
 */
$router->prefix('reports')
    ->withPolicy('FluentCart\App\Http\Policies\ReportPolicy')
    ->group(function (Router $router) {
        $router->get('order-value-distribution', [OrderPatternsController::class, 'orderValueDistribution']);
        $router->get('fetch-report-by-day-and-hour', [OrderPatternsController::class, 'byDayAndHour']);
        $router->get('item-count-distribution', [OrderPatternsController::class, 'itemCountDistribution']);
        $router->get('order-completion-time', [OrderPatternsController::class, 'completionTime']);
        $router->get('weeks-between-refund', [OrderPatternsController::class, 'weeksBetweenRefund']);
        $router->get('payment-methods/disputes', [PaymentInsightsController::class, 'disputes']);
        $router->get('payment-methods/methods', [PaymentInsightsController::class, 'methods']);
        $router->get('customer-value', [CustomerInsightsController::class, 'value']);
        $router->get('customer-repeat', [CustomerInsightsController::class, 'repeat']);
        $router->get('customer-segments', [CustomerInsightsController::class, 'segments']);
        $router->get('customer-segment-customers', [CustomerInsightsController::class, 'segmentCustomers']);
        $router->get('product-detail', [ProductInsightsController::class, 'detail']);
        $router->get('product-comparison', [ProductInsightsController::class, 'comparison']);
        $router->get('product-comparison-subscriptions', [ProductInsightsController::class, 'comparisonSubscriptions']);
        $router->get('product-comparison-overlap', [ProductInsightsController::class, 'comparisonOverlap']);
        $router->get('product-comparison-launch', [ProductInsightsController::class, 'comparisonLaunch']);
        $router->get('subscription-rebuys', [SubscriptionInsightsController::class, 'rebuys']);
        $router->get('installments/variations', [SubscriptionInsightsController::class, 'installmentVariations']);
        $router->get('channel-rules', [ChannelRulesController::class, 'get']);
        // Saving also needs store/settings, checked in the controller
        $router->post('channel-rules', [ChannelRulesController::class, 'save']);
    });
