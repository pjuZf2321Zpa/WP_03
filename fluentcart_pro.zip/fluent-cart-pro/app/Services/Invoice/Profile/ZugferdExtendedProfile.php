<?php

declare(strict_types=1);

namespace FluentCartPro\App\Services\Invoice\Profile;

if (!defined('ABSPATH')) {
    exit;
}

use FluentCartPro\App\Services\Invoice\Domain\CalculatedTotals;
use FluentCartPro\App\Services\Invoice\Domain\En16931Invoice;

/**
 * ZUGFeRD Extended profile. Stub: delegates to EN 16931 until Extended rules are implemented.
 */
final class ZugferdExtendedProfile implements InvoiceProfileInterface
{
    private ZugferdEn16931Profile $en16931;

    public function __construct()
    {
        $this->en16931 = new ZugferdEn16931Profile();
    }

    public function getProfileId(): string
    {
        return 'urn:cen.eu:en16931:2017';
    }

    public function getSyntax(): string
    {
        return 'CII';
    }

    public function validate(En16931Invoice $invoice, CalculatedTotals $totals): void
    {
        $this->en16931->validate($invoice, $totals);
    }
}
