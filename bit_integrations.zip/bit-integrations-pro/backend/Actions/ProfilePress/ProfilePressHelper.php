<?php

namespace BitApps\IntegrationsPro\Actions\ProfilePress;

/**
 * Shared helpers for the ProfilePress action handlers.
 *
 * Ported from bit-pi's ProfilePressHelper, with the bit-pi status_code envelope
 * replaced by the success/message envelope Bit Integrations logs.
 */
final class ProfilePressHelper
{
    public static function isPluginActive()
    {
        return \defined('PPRESS_VERSION_NUMBER');
    }

    /**
     * Return the first missing class or function, so the caller can name it.
     *
     * ProfilePress splits membership features across its free and paid tiers, so an
     * action can be reachable while the API it needs is absent.
     *
     * @param array $classes
     * @param array $functions
     *
     * @return null|array{type:string,name:string}
     */
    public static function getMissingDependency(array $classes = [], array $functions = [])
    {
        foreach ($classes as $class) {
            if (!class_exists($class)) {
                return ['type' => 'class', 'name' => $class];
            }
        }

        foreach ($functions as $function) {
            if (!\function_exists($function)) {
                return ['type' => 'function', 'name' => $function];
            }
        }
    }

    /**
     * Error envelope naming the missing dependency.
     *
     * @param array{type:string,name:string} $missingDependency
     *
     * @return array
     */
    public static function missingDependencyResponse($missingDependency)
    {
        return self::errorResponse(
            wp_sprintf(
                // translators: 1: dependency type (class or function), 2: dependency name
                __('Required ProfilePress %1$s %2$s does not exist.', 'bit-integrations-pro'),
                $missingDependency['type'],
                $missingDependency['name']
            )
        );
    }

    /**
     * Verify every required key is present and non-empty.
     *
     * @param array $fieldData
     * @param array $required
     *
     * @return null|array Error envelope listing the missing keys, null when satisfied
     */
    public static function requireFields($fieldData, array $required)
    {
        $missing = [];

        foreach ($required as $key) {
            if (!isset($fieldData[$key]) || $fieldData[$key] === '' || $fieldData[$key] === null) {
                $missing[] = $key;
            }
        }

        if (!empty($missing)) {
            return self::errorResponse(
                // translators: %s: comma separated field names
                wp_sprintf(__('Missing required field(s): %s', 'bit-integrations-pro'), implode(', ', $missing))
            );
        }
    }

    /**
     * Create a WP user from the mapped fields, or update the one already matching
     * the given email or login.
     *
     * @param array $fieldData
     *
     * @return int|WP_Error
     */
    public static function createOrUpdateCustomer($fieldData)
    {
        $userdata = [
            'user_email' => $fieldData['user_email'] ?? '',
            'first_name' => $fieldData['first_name'] ?? '',
            'last_name'  => $fieldData['last_name'] ?? '',
        ];

        $password = $fieldData['password'] ?? '';

        $user = get_user_by('email', $fieldData['user_email'] ?? '');

        if (!$user) {
            $user = get_user_by('login', $fieldData['user_name'] ?? '');
        }

        if ($user) {
            $userdata['ID'] = $user->ID;

            // Only send what was supplied, so blank inputs do not wipe existing values.
            // Filtered on '' rather than falsiness, so a name of literally "0" is kept.
            $userdata = array_filter(
                $userdata,
                function ($value) {
                    return $value !== null && $value !== '';
                }
            );

            // Set the password only when the flow actually mapped one. bit-pi defaulted
            // it to wp_generate_password(), which array_filter then kept, so every update
            // silently reset the customer's password and locked them out.
            if ($password !== '') {
                $userdata['user_pass'] = $password;
            }

            // user_login is omitted entirely — wp_update_user ignores it, so including
            // it only suggests renaming is supported when it is not.
            return wp_update_user(wp_slash($userdata));
        }

        $userdata['user_login'] = $fieldData['user_name'] ?? '';
        $userdata['user_pass'] = $password !== '' ? $password : wp_generate_password();

        return wp_insert_user(wp_slash($userdata));
    }

    /**
     * Persist the ppress_billing_* user meta the checkout form uses.
     *
     * @param array $fieldData
     * @param int   $userId
     *
     * @return void
     */
    public static function updateCustomerMetaData($fieldData, $userId)
    {
        $billingKeys = [
            'ppress_billing_address',
            'ppress_billing_city',
            'ppress_billing_country',
            'ppress_billing_state',
            'ppress_billing_postcode',
            'ppress_billing_phone',
        ];

        foreach ($billingKeys as $billingKey) {
            // Unlike bit-pi, an unmapped key is skipped rather than written as an
            // empty string, so a partial update does not clear stored billing data.
            if (!isset($fieldData[$billingKey]) || $fieldData[$billingKey] === '') {
                continue;
            }

            update_user_meta($userId, $billingKey, $fieldData[$billingKey]);
        }
    }

    /**
     * True when the value is one of this class's error envelopes rather than a model.
     *
     * @param mixed $response
     *
     * @return bool
     */
    public static function isError($response)
    {
        return \is_array($response) && isset($response['success']) && $response['success'] === false;
    }

    public static function errorResponse($message)
    {
        return [
            'success' => false,
            'message' => $message
        ];
    }

    public static function successResponse($message, $data = [])
    {
        return [
            'success' => true,
            'message' => $message,
            'data'    => $data
        ];
    }
}
