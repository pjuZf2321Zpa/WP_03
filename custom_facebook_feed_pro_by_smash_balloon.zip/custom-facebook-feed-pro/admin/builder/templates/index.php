<?php
//Silence is golden.