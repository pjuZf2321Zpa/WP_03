<?php

namespace FluentCartPro\App\Modules\AdvancedFilters;

use FluentCartPro\App\Modules\AdvancedFilters\Operators\NamedOperators;
use FluentCartPro\App\Modules\AdvancedFilters\Reports\SourceReportFilterService;

/**
 * Advanced filtering — the Pro half of FluentCart's filter builder.
 *
 * Core owns the UI, the condition vocabulary and the engine; it gates the whole
 * feature on Pro (BaseFilter::applyAdvancedFilter() returns early without it) and
 * exposes seams for the parts it deliberately does not decide. This module fills
 * them in:
 *
 *   fluent_cart/filter/supported_operators    resolve operator names core's own
 *                                             options advertise but never mapped
 *   fluent_cart/report/sanitize_params_rules  sanitize a report payload whose
 *                                             shape only the consumer knows
 *   fluent_cart/report/sources_query          narrow the Order Sources aggregate
 *
 * The operator mapping is not report-specific: it applies wherever the filter
 * engine runs, the Orders table included.
 */
class AdvancedFilters
{
    public function register($app)
    {
        // 10, 2 — the hook's third argument is a read-only context array carrying
        // 'filter_name'; a listener registered for one argument never sees it.
        add_filter(
            'fluent_cart/filter/supported_operators',
            [NamedOperators::class, 'extend'],
            10,
            2
        );

        // Core carries `advanced_filters` through the report params but ships no
        // sanitization rule for it — see SourceReportFilterService::sanitizeParam().
        add_filter('fluent_cart/report/sanitize_params_rules', function ($rules) {
            // A Closure, not [Class, 'method']: Sanitizer::sanitize() treats an
            // array rule as a LIST of callbacks, so a callable array would be
            // split into its class and method strings and each run separately.
            $rules['advanced_filters'] = function ($value) {
                return SourceReportFilterService::sanitizeParam($value);
            };

            return $rules;
        });

        add_filter('fluent_cart/report/sources_query', function ($query, $params) {
            return (new SourceReportFilterService())->apply($query, $params);
        }, 10, 2);
    }
}
