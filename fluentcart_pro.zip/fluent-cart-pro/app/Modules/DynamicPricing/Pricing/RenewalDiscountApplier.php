<?php

namespace FluentCartPro\App\Modules\DynamicPricing\Pricing;

use FluentCart\App\Models\Order;
use FluentCart\App\Services\Money;
use FluentCart\Framework\Support\Arr;

/**
 * Discounts a store-managed renewal invoice as it is issued.
 *
 * The invoice is priced once, when the store creates it, so the system charge
 * and the pay-now checkout bill the same figure. Only a rule set to renewals
 * is asked, and only its discounts are taken — a bill is not a place to add
 * a fee.
 *
 * @package FluentCartPro\App\Modules\DynamicPricing
 *
 * @version 1.0.0
 */
class RenewalDiscountApplier
{
    /**
     * @var DynamicPricingService
     */
    protected $service;

    /**
     * @var AppliedRuleRecorder
     */
    protected $recorder;

    public function __construct(?DynamicPricingService $service = null, ?AppliedRuleRecorder $recorder = null)
    {
        $this->service = $service ?: new DynamicPricingService();
        $this->recorder = $recorder ?: new AppliedRuleRecorder();
    }

    public function register()
    {
        add_filter('fluent_cart/renewal/before_create_order', [$this, 'discountRenewalOrder'], 10, 2);
        add_action('fluent_cart/renewal/before_commit_order', [$this, 'recordRenewalDiscount']);
    }

    /**
     * Take what the renewals rules allow off the invoice figures.
     *
     * @param array $pricing ['subtotal', 'tax_total', 'total', 'discount_total', 'applied_rules']
     * @param array $context ['subscription' => Subscription, ...]
     * @return array
     */
    public function discountRenewalOrder($pricing, $context)
    {
        if (!is_array($pricing)) {
            return $pricing;
        }

        $subtotal = (int)Arr::get($pricing, 'subtotal', 0);
        $subscription = Arr::get((array)$context, 'subscription');

        if ($subtotal <= 0 || !$subscription) {
            return $pricing;
        }

        $adjustments = $this->service->calculate([
            'subscription' => $subscription,
            'cart'     => [
                'subtotal'       => $subtotal,
                'shipping_total' => 0,
                'items'          => [
                    [
                        'subtotal' => $subtotal, 
                        'quantity' => (int)$subscription->quantity, 
                        'unit_price' => $subtotal
                    ],
                ],
            ],
            'customer' => ['customer_id' => (int)$subscription->customer_id],
            'purchase' => ['is_renewal_order' => true],
        ]);

        $taken = 0;
        $applied = [];

        foreach ($adjustments as $adjustment) {
            if ($adjustment['adjustment_type'] !== 'discount') {
                continue;
            }

            $amount = min(abs((int)$adjustment['adjustment_amount']), $subtotal - $taken);

            if ($amount <= 0) {
                continue;
            }

            $taken += $amount;
            $applied[] = [
                'rule_id'           => $adjustment['rule_id'],
                'rule_type'         => $adjustment['rule_type'],
                'rule_name'         => $adjustment['rule_name'],
                'adjustment_type'   => 'discount',
                'adjustment_amount' => $amount,
            ];
        }

        if (!$taken) {
            return $pricing;
        }

        // The tax is a snapshot, so it moves with the money actually charged.
        $taxTotal = (int)Arr::get($pricing, 'tax_total', 0);
        $scaledTax = $taxTotal * ($subtotal - $taken) / $subtotal;
        if (class_exists(Money::class) && method_exists(Money::class, 'roundIfZeroDecimal')) {
            $scaledTax = Money::roundIfZeroDecimal($scaledTax, $subscription->currency);
        }
        $scaledTax = (int) round($scaledTax);

        $pricing['discount_total'] = $taken;
        $pricing['tax_total']      = $scaledTax;
        $pricing['total']          = max(0, $subtotal - $taken + $scaledTax);
        $pricing['applied_rules']  = $applied;

        return $pricing;
    }

    /**
     * Record what was taken, now that the invoice exists.
     *
     * @param array $data ['order' => Order, 'pricing' => array]
     * @return void
     */
    public function recordRenewalDiscount($data)
    {
        $order = Arr::get((array)$data, 'order');
        $rows = (array)Arr::get((array)$data, 'pricing.applied_rules', []);

        if (!$order instanceof Order) {
            return;
        }

        // Called even with no rules, so a repriced order's old rows are
        // cleared and its history matches the pricing that stands.
        $this->recorder->recordFor((int)$order->id, $rows);
    }
}
