<?php

namespace BitApps\IntegrationsPro\Triggers\AmeliaBooking;

use Exception;

class AmeliaBookingHelper
{
    public static function formatNewAppointmentData($appointment, $service, $paymentData)
    {
        $helperClass = bit_integrations_get_class('Core\\Util\\Helper');

        $booking = static::formatAppointmentData($appointment);

        unset(
            $appointment['bookings'],
            $service['settings'],
            $service['timeBefore'],
            $service['timeAfter'],
            $service['translations'],
            $service['minSelectedExtras'],
            $service['mandatoryExtra'],
            $service['customPricing'],
            $service['maxExtraPeople'],
            $service['limitPerCustomer'],
            $booking['customerId'],
        );

        $bookingData = array_merge($booking, [
            'bookingStart'       => $appointment['bookingStart'],
            'notifyParticipants' => $appointment['notifyParticipants'],
            'internalNotes'      => $appointment['internalNotes'],
            'recurring'          => $appointment['recurring'],
            'utc'                => $appointment['utc'],
            'timeZone'           => $appointment['timeZone'],
            'payment'            => $paymentData,
            'service'            => $service,
        ]);

        return $helperClass::prepareFetchFormatFields($bookingData);
    }

    public static function formatAppointmentStatusUpdateData($appointment, $requestedStatus)
    {
        $helperClass = bit_integrations_get_class('Core\\Util\\Helper');

        $bookingData = static::formatAppointmentData($appointment);
        $bookingData['requested_status'] = $requestedStatus;

        return $helperClass::prepareFetchFormatFields($bookingData);
    }

    public static function formatBookingCancelledData($booking)
    {
        $helperClass = bit_integrations_get_class('Core\\Util\\Helper');

        $appointment = $booking['appointment'];
        $appointment['bookings'] = [$booking['booking']];
        $bookingData = static::formatAppointmentData($appointment);

        return $helperClass::prepareFetchFormatFields($bookingData);
    }

    public static function formatEventData($event)
    {
        $helperClass = bit_integrations_get_class('Core\\Util\\Helper');

        $provider = $event['providers'][0] ?? [];
        $event['periods'] = wp_json_encode($event['periods']);
        $event['tags'] = wp_json_encode($event['tags']);

        unset(
            $event['bookingOpensRec'],
            $event['bookingClosesRec'],
            $event['gallery'],
            $event['settings'],
            $event['closeAfterMinBookings'],
            $event['providers'],
            $provider['translations'],
            $provider['appleCalendarId'],
            $provider['weekDayList'],
            $provider['serviceList'],
            $provider['dayOffList'],
            $provider['specialDayList'],
            $provider['description'],
        );

        $event['provider'] = $provider;

        return $helperClass::prepareFetchFormatFields($event);
    }

    public static function formatEventBookingData($booking, $reservation)
    {
        $helperClass = bit_integrations_get_class('Core\\Util\\Helper');

        $customer = $booking['customer'] ?? [];
        $provider = $reservation['providers'][0] ?? [];
        $reservation['tags'] = wp_json_encode($reservation['tags']);
        $reservation['periods'] = $reservation['periods'] ?? [];

        unset(
            $booking['customerId'],
            $booking['info'],
            $customer['externalId'],
            $customer['translations'],
            $reservation['settings'],
            $reservation['bookings'],
            $reservation['periods'],
            $reservation['providers'],
            $reservation['bookingOpensRec'],
            $reservation['bookingClosesRec'],
            $reservation['translations']
        );

        $reservation['provider'] = $provider;
        $booking['customer'] = $customer;
        $booking['event'] = $reservation;

        return $helperClass::prepareFetchFormatFields($booking);
    }

    public static function formatAppointmentData($appointment)
    {
        $booking = $appointment['bookings'][0];

        if (!empty($booking['payments'])) {
            $payment = $booking['payments'][0];

            $booking['payment'] = [
                'amount'        => $payment['amount'] ?? null,
                'gateway'       => $payment['gateway'] ?? null,
                'status'        => $payment['status'] ?? null,
                'dateTime'      => $payment['dateTime'] ?? null,
                'invoiceNumber' => $payment['invoiceNumber'] ?? null
            ];
        }

        unset(
            $appointment['bookings'],
            $booking['utcOffset'],
            $booking['isChangedStatus'],
            $booking['isLastBooking'],
            $booking['packageCustomerService'],
            $booking['actionsCompleted'],
            $booking['isUpdated'],
            $booking['info'],
            $booking['payments'],
        );

        if (!empty($appointment['locationId'])) {
            $appointment['location'] = self::getLocationById($appointment['locationId']);
        }

        return array_merge($booking, $appointment);
    }

    public static function getLocationById($locationId)
    {
        if (!self::isPluginInstalled() || !\defined('AMELIA_PATH')) {
            return [];
        }

        try {
            $container = require AMELIA_PATH . '/src/Infrastructure/ContainerConfig/container.php';

            $locationRepository = $container->get('domain.locations.repository');
            $location = $locationRepository->getById((int) $locationId);

            return $location->toArray();
        } catch (Exception $e) {
            return [];
        }
    }

    public static function isPluginInstalled()
    {
        return class_exists('\AmeliaBooking\Plugin');
    }
}
