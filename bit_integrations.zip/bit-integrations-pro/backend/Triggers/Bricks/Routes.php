<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Core\Util\Route;
use BitApps\IntegrationsPro\Triggers\Bricks\BricksController;

Route::get('bricks/get', [BricksController::class, 'getAllTasks']);
