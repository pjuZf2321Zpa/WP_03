<?php

namespace WPAICG\Lib\Utils;

use DOMDocument;
use DOMElement;
use DOMNode;
use DOMXPath;
use WP_Error;

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

/**
 * Extracts readable article content and source metadata from web pages.
 */
class AIPKit_Url_Scraper
{
    private const MAX_CONTENT_LENGTH = 15000;

    /**
     * Scrape clean textual content for generation callers.
     *
     * @param string $url The URL to scrape.
     * @return string|WP_Error Clean article text, or an error on failure.
     */
    public function scrape(string $url)
    {
        $result = $this->scrape_with_metadata($url);

        return is_wp_error($result) ? $result : $result['text'];
    }

    /**
     * Scrape clean article text plus source metadata for previews.
     *
     * @param string $url The URL to scrape.
     * @return array|WP_Error Structured scrape result, or an error on failure.
     */
    public function scrape_with_metadata(string $url)
    {
        if (!filter_var($url, FILTER_VALIDATE_URL)) {
            return new WP_Error('invalid_url', __('The provided URL is not valid.', 'gpt3-ai-content-generator'));
        }

        $response = wp_safe_remote_get($url, [
            'timeout' => 20,
            'reject_unsafe_urls' => true,
            'user-agent' => 'Mozilla/5.0 (compatible; AIPKitBot/1.0; +https://aipower.org/bot)',
        ]);

        if (is_wp_error($response)) {
            return new WP_Error('fetch_failed', __('Failed to fetch URL: ', 'gpt3-ai-content-generator') . $response->get_error_message());
        }

        $body = wp_remote_retrieve_body($response);
        if (empty($body)) {
            return new WP_Error('empty_body', __('The URL returned an empty response body.', 'gpt3-ai-content-generator'));
        }

        $previous_libxml_state = libxml_use_internal_errors(true);
        $document = new DOMDocument();
        $loaded = $document->loadHTML('<?xml encoding="utf-8" ?>' . $body, LIBXML_NONET | LIBXML_NOERROR | LIBXML_NOWARNING);
        libxml_clear_errors();
        libxml_use_internal_errors($previous_libxml_state);

        if (!$loaded) {
            return new WP_Error('invalid_html', __('The page returned HTML that could not be read.', 'gpt3-ai-content-generator'));
        }

        $xpath = new DOMXPath($document);
        $content_node = $this->find_primary_content_node($xpath);
        if (!$content_node) {
            return new WP_Error('no_content_found', __('Could not identify the main content area of the page.', 'gpt3-ai-content-generator'));
        }

        $metadata = $this->extract_metadata($xpath, $content_node);
        $this->remove_unwanted_elements($xpath, $content_node);
        $blocks = $this->extract_content_blocks($xpath, $content_node, $metadata);
        $text = $this->limit_content(implode("\n\n", $blocks));

        if ($text === '') {
            return new WP_Error('no_text_extracted', __('Could not extract any meaningful text from the main content area.', 'gpt3-ai-content-generator'));
        }

        return [
            'text' => $text,
            'metadata' => $metadata,
        ];
    }

    /**
     * Prefer a real article body over a broader main container.
     *
     * @param DOMXPath $xpath Parsed document XPath instance.
     * @return DOMNode|null Best content node.
     */
    private function find_primary_content_node(DOMXPath $xpath)
    {
        $candidate_queries = [
            '//*[@itemprop="articleBody"]',
            '//article',
            '//main | //*[@role="main"]',
            '//body',
        ];

        foreach ($candidate_queries as $query) {
            $nodes = $xpath->query($query);
            if (!$nodes || $nodes->length === 0) {
                continue;
            }

            $best_node = null;
            $best_score = 0;
            foreach ($nodes as $node) {
                $score = $this->score_content_node($xpath, $node);
                if ($score > $best_score) {
                    $best_score = $score;
                    $best_node = $node;
                }
            }

            if ($best_node) {
                return $best_node;
            }
        }

        return null;
    }

    /**
     * Score a candidate by useful prose rather than raw descendant text.
     */
    private function score_content_node(DOMXPath $xpath, DOMNode $node): int
    {
        $blocks = $xpath->query('.//p | .//h1 | .//h2 | .//h3 | .//blockquote', $node);
        if (!$blocks || $blocks->length === 0) {
            return mb_strlen($this->normalize_text($node->textContent));
        }

        $score = 0;
        foreach ($blocks as $block) {
            $text = $this->normalize_text($block->textContent);
            if (mb_strlen($text) >= 40) {
                $score += mb_strlen($text);
            }
        }

        return $score;
    }

    /**
     * Extract source information before removing bylines, timestamps, and figures.
     */
    private function extract_metadata(DOMXPath $xpath, DOMNode $content_node): array
    {
        $metadata = [
            'headline' => '',
            'author' => '',
            'published_at' => '',
            'published_label' => '',
            'credit' => '',
        ];

        $this->merge_json_ld_metadata($xpath, $metadata);

        if ($metadata['headline'] === '') {
            $metadata['headline'] = $this->find_meta_content($xpath, ['og:title', 'twitter:title']);
        }
        if ($metadata['headline'] === '') {
            $headings = $xpath->query('.//h1', $content_node);
            if ($headings && $headings->length > 0) {
                $metadata['headline'] = $this->normalize_text($headings->item(0)->textContent);
            }
        }

        if ($metadata['author'] === '') {
            $metadata['author'] = $this->find_meta_content($xpath, ['author', 'article:author']);
        }
        if ($metadata['author'] === '') {
            $author_nodes = $xpath->query('.//*[@rel="author"] | .//*[contains(translate(@class, "ABCDEFGHIJKLMNOPQRSTUVWXYZ", "abcdefghijklmnopqrstuvwxyz"), "byline")]', $content_node);
            if ($author_nodes && $author_nodes->length > 0) {
                $metadata['author'] = preg_replace('/^\s*by\s+/i', '', $this->normalize_text($author_nodes->item(0)->textContent));
            }
        }

        if ($metadata['published_at'] === '') {
            $metadata['published_at'] = $this->find_meta_content($xpath, ['article:published_time', 'datepublished', 'date']);
        }

        $time_nodes = $xpath->query('.//time[@datetime] | .//time', $content_node);
        if ($time_nodes && $time_nodes->length > 0) {
            $time_node = $time_nodes->item(0);
            $metadata['published_label'] = $this->normalize_text($time_node->textContent);
            if ($metadata['published_at'] === '' && $time_node instanceof DOMElement) {
                $metadata['published_at'] = trim($time_node->getAttribute('datetime'));
            }
        }

        $credit_nodes = $xpath->query(
            './/figcaption | .//*[contains(translate(@class, "ABCDEFGHIJKLMNOPQRSTUVWXYZ", "abcdefghijklmnopqrstuvwxyz"), "credit")] | .//*[contains(translate(@id, "ABCDEFGHIJKLMNOPQRSTUVWXYZ", "abcdefghijklmnopqrstuvwxyz"), "credit")]',
            $content_node
        );
        if ($credit_nodes) {
            foreach ($credit_nodes as $credit_node) {
                $credit = $this->normalize_text($credit_node->textContent);
                if ($credit !== '' && mb_strlen($credit) <= 220) {
                    $metadata['credit'] = $credit;
                    break;
                }
            }
        }

        return array_map('trim', $metadata);
    }

    /**
     * Read the first Article-like JSON-LD object found on the page.
     */
    private function merge_json_ld_metadata(DOMXPath $xpath, array &$metadata): void
    {
        $scripts = $xpath->query('//script[contains(translate(@type, "ABCDEFGHIJKLMNOPQRSTUVWXYZ", "abcdefghijklmnopqrstuvwxyz"), "ld+json")]');
        if (!$scripts) {
            return;
        }

        foreach ($scripts as $script) {
            $decoded = json_decode(html_entity_decode(trim($script->textContent), ENT_QUOTES | ENT_HTML5, 'UTF-8'), true);
            if (!is_array($decoded)) {
                continue;
            }

            $article = $this->find_article_schema($decoded);
            if (!$article) {
                continue;
            }

            $metadata['headline'] = $this->normalize_text((string) ($article['headline'] ?? $article['name'] ?? ''));
            $metadata['author'] = $this->extract_author_names($article['author'] ?? []);
            $metadata['published_at'] = trim((string) ($article['datePublished'] ?? ''));
            return;
        }
    }

    /**
     * Recursively locate an Article, NewsArticle, or BlogPosting schema.
     */
    private function find_article_schema(array $value): array
    {
        $types = $value['@type'] ?? [];
        $types = is_array($types) ? $types : [$types];
        foreach ($types as $type) {
            if (in_array(strtolower((string) $type), ['article', 'newsarticle', 'blogposting'], true)) {
                return $value;
            }
        }

        foreach ($value as $child) {
            if (!is_array($child)) {
                continue;
            }
            $match = $this->find_article_schema($child);
            if ($match) {
                return $match;
            }
        }

        return [];
    }

    /**
     * Normalize JSON-LD author variants into a single readable string.
     */
    private function extract_author_names($author): string
    {
        if (is_string($author)) {
            return $this->normalize_text($author);
        }
        if (!is_array($author)) {
            return '';
        }
        if (isset($author['name'])) {
            return $this->normalize_text((string) $author['name']);
        }

        $names = [];
        foreach ($author as $entry) {
            $name = $this->extract_author_names($entry);
            if ($name !== '') {
                $names[] = $name;
            }
        }

        return implode(', ', array_values(array_unique($names)));
    }

    /**
     * Read matching meta name/property values.
     */
    private function find_meta_content(DOMXPath $xpath, array $keys): string
    {
        $meta_nodes = $xpath->query('//meta[@content]');
        if (!$meta_nodes) {
            return '';
        }

        $keys = array_map('strtolower', $keys);
        foreach ($meta_nodes as $meta_node) {
            if (!$meta_node instanceof DOMElement) {
                continue;
            }
            $key = strtolower(trim($meta_node->getAttribute('property') ?: $meta_node->getAttribute('name')));
            if (in_array($key, $keys, true)) {
                return $this->normalize_text($meta_node->getAttribute('content'));
            }
        }

        return '';
    }

    /**
     * Remove page chrome and metadata nodes from the selected article container.
     */
    private function remove_unwanted_elements(DOMXPath $xpath, DOMNode $content_node): void
    {
        $nodes = $xpath->query('.//*', $content_node);
        if (!$nodes) {
            return;
        }

        $to_remove = [];
        foreach ($nodes as $node) {
            if ($node instanceof DOMElement && $this->is_unwanted_element($node)) {
                $to_remove[] = $node;
            }
        }

        for ($index = count($to_remove) - 1; $index >= 0; $index--) {
            $node = $to_remove[$index];
            if ($node->parentNode) {
                $node->parentNode->removeChild($node);
            }
        }
    }

    /**
     * Decide whether an element is navigation, controls, metadata, or other chrome.
     */
    private function is_unwanted_element(DOMElement $element): bool
    {
        $tag = strtolower($element->tagName);
        if (in_array($tag, [
            'nav', 'header', 'footer', 'aside', 'script', 'style', 'form', 'button',
            'input', 'select', 'textarea', 'svg', 'canvas', 'iframe', 'noscript',
            'template', 'dialog', 'figure',
        ], true)) {
            return true;
        }

        $role = strtolower($element->getAttribute('role'));
        if (in_array($role, ['navigation', 'complementary', 'contentinfo', 'banner', 'toolbar'], true)) {
            return true;
        }

        $identity = strtolower(implode(' ', [
            $element->getAttribute('class'),
            $element->getAttribute('id'),
            $element->getAttribute('aria-label'),
            $element->getAttribute('data-component'),
        ]));

        return (bool) preg_match(
            '/(?:^|[\s_-])(nav(?:igation)?|share|sharing|social|toolbar|actions?|related|recommend(?:ed|ation)?|promo|advert(?:isement)?|ads?|cookie|consent|newsletter|subscription|comments?|footer|breadcrumb|byline|author|timestamp|published|caption|credit)(?:$|[\s_-])/i',
            $identity
        );
    }

    /**
     * Extract readable semantic blocks while preserving paragraph boundaries.
     */
    private function extract_content_blocks(DOMXPath $xpath, DOMNode $content_node, array $metadata): array
    {
        $blocks = [];
        $seen = [];

        if (!empty($metadata['headline'])) {
            $headline = $this->normalize_text($metadata['headline']);
            $blocks[] = $headline;
            $seen[mb_strtolower($headline)] = true;
        }
        $metadata_block_count = count($blocks);

        $nodes = $xpath->query('.//h1 | .//h2 | .//h3 | .//h4 | .//p | .//blockquote | .//li', $content_node);
        if ($nodes) {
            foreach ($nodes as $node) {
                $text = $this->normalize_text($node->textContent);
                $key = mb_strtolower($text);
                if ($text === '' || isset($seen[$key]) || $this->is_boilerplate_text($text, $metadata)) {
                    continue;
                }
                $blocks[] = $text;
                $seen[$key] = true;
            }
        }

        // Some valid pages use only div-based prose. Preserve a cleaned fallback
        // rather than returning a headline without any reference content.
        if (count($blocks) === $metadata_block_count) {
            $fallback = $this->normalize_text($content_node->textContent);
            $fallback_key = mb_strtolower($fallback);
            if ($fallback !== '' && !isset($seen[$fallback_key]) && !$this->is_boilerplate_text($fallback, $metadata)) {
                $blocks[] = $fallback;
            }
        }

        return $blocks;
    }

    /**
     * Filter common control labels and metadata that survive imperfect markup.
     */
    private function is_boilerplate_text(string $text, array $metadata): bool
    {
        if (preg_match('/^(share|save|print|copy link|listen|read more|related|advertisement)( this article)?$/i', $text)) {
            return true;
        }
        if (preg_match('/^add as preferred(?: on google)?$/i', $text)) {
            return true;
        }
        if (preg_match('/^\d+\s+(second|minute|hour|day|week|month|year)s? ago$/i', $text)) {
            return true;
        }
        if (preg_match('/^(image|photo|picture|video)\s+(source|credit)\s*:/i', $text)) {
            return true;
        }

        foreach (['author', 'published_label', 'credit'] as $metadata_key) {
            $metadata_value = $this->normalize_text((string) ($metadata[$metadata_key] ?? ''));
            if ($metadata_value === '') {
                continue;
            }
            if (strcasecmp($text, $metadata_value) === 0 || strcasecmp($text, 'By ' . $metadata_value) === 0) {
                return true;
            }
        }

        return false;
    }

    /**
     * Normalize inline whitespace without destroying block separation.
     */
    private function normalize_text(string $text): string
    {
        $text = html_entity_decode($text, ENT_QUOTES | ENT_HTML5, 'UTF-8');
        $text = str_replace("\xc2\xa0", ' ', $text);
        $text = preg_replace('/[\s\x{200B}\x{FEFF}]+/u', ' ', $text);

        return trim((string) $text);
    }

    /**
     * Keep context within the existing generation limit and truncate at a block boundary.
     */
    private function limit_content(string $text): string
    {
        $text = trim($text);
        if (mb_strlen($text) <= self::MAX_CONTENT_LENGTH) {
            return $text;
        }

        $truncated = mb_substr($text, 0, self::MAX_CONTENT_LENGTH);
        $last_break = mb_strrpos($truncated, "\n\n");
        if ($last_break !== false && $last_break > (int) (self::MAX_CONTENT_LENGTH * 0.7)) {
            $truncated = mb_substr($truncated, 0, $last_break);
        }

        return rtrim($truncated) . '... [content truncated]';
    }
}
