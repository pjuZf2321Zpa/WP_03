<?php

namespace FluentCartPro\App\Modules\PaymentMethods\MollieGateway;

use FluentCart\App\Helpers\Status;
use FluentCart\App\Helpers\StatusHelper;
use FluentCart\App\Models\OrderTransaction;
use FluentCart\App\Models\Cart;
use FluentCart\App\Models\Subscription;
use FluentCart\App\Events\Subscription\SubscriptionActivated;
use FluentCart\App\Modules\Subscriptions\Services\SubscriptionService;
use FluentCart\Framework\Support\Arr;
use FluentCart\App\Services\DateTime\DateTime;
use FluentCartPro\App\Modules\PaymentMethods\MollieGateway\API\MollieAPI;

class Confirmations
{
    public function init(){
        
        add_action('fluent_cart/before_render_redirect_page', [$this, 'maybeConfirmPayment'], 10, 1);

    }

    /**
     * Browser return from the Mollie hosted page, dispatched by core WebRoutes
     * via the fluent_cart_action_fct_mollie_return action. Confirms the
     * payment first, then redirects the buyer to the filterable success URL —
     * so a fluent_cart/payment/success_url filter only ever changes the
     * destination, never the confirmation.
     */
    public function handleHostedReturn($requestData = [])
    {
        $transactionHash = sanitize_text_field(Arr::get($requestData, 'trx_hash', ''));

        $transaction = OrderTransaction::query()
            ->where('uuid', $transactionHash)
            ->where('payment_method', 'mollie')
            ->first();

        if (!$transaction) {
            wp_redirect(home_url());
            exit;
        }

        $this->maybeConfirmPayment([
            'is_receipt' => false,
            'method'     => 'mollie',
            'trx_hash'   => $transactionHash,
        ]);

        // maybeConfirmPayment() updates the row through its own model instance;
        // re-query so the success-url filter sees the post-confirmation status.
        $transaction = OrderTransaction::query()->find($transaction->id);

        if (!$transaction) {
            wp_redirect(home_url());
            exit;
        }

        $redirectUrl = method_exists($transaction, 'getSuccessUrl')
            ? $transaction->getSuccessUrl()
            : $transaction->getReceiptPageUrl();

        wp_redirect($redirectUrl);
        exit;
    }

    /**
     * If the transaction is already succeeded but its subscription never got
     * a vendor_subscription_id (creation failed after the transaction was
     * marked succeeded), retry creation here. handleSubscriptionCreation()
     * is idempotent (local vendor_subscription_id guard + DB mutex), so this
     * is safe to call on every already-succeeded hit — it no-ops once the
     * subscription is created.
     */
    public function maybeRecoverMissingSubscription(OrderTransaction $transaction, $charge)
    {
        if (!$transaction->subscription_id) {
            return;
        }

        $subscription = Subscription::query()->where('id', $transaction->subscription_id)->first();
        if (!$subscription || $subscription->collection_method !== 'automatic') {
            return;
        }

        if (MollieHelper::currentVendorSubscriptionId($subscription, $transaction)) {
            $this->recordReactivationOnce($transaction, []);
            return;
        }

        $mandateId = Arr::get($charge, 'mandateId');
        if (!$mandateId) {
            return;
        }

        $billingInfo = [
            'method' => Arr::get($charge, 'method'),
            'brand' => Arr::get($charge, 'details.cardLabel'),
            'last4' => Arr::get($charge, 'details.cardNumber'),
            'token' => Arr::get($charge, 'details.cardToken'),
            'mandate_id' => $mandateId
        ];

        $subscriptionData = $this->handleSubscriptionCreation($transaction, [
            'mandate_id' => $mandateId,
            'billingInfo' => $billingInfo
        ]);

        // A reactivation whose first confirmation could not start the Mollie subscription left its renewal order unrecorded.
        $this->recordReactivationOnce($transaction, $subscriptionData, $billingInfo);
    }

    /**
     * Records a paid reactivation's renewal order once. The webhook and the
     * browser return both confirm, and only one of them gets the creation
     * result, so whichever finds the reactivation ready records it.
     *
     * @return Subscription|\FluentCart\App\Models\Order|null null when the order is not a reactivation
     */
    private function recordReactivationOnce(OrderTransaction $transaction, $subscriptionData, $billingInfo = [])
    {
        $order = $transaction->order;
        if (!$order || $order->type !== Status::ORDER_TYPE_RENEWAL || !array_key_exists('old_vendor_subscription_id', (array) $order->config)) {
            return null;
        }

        $subscription = Subscription::query()->find($transaction->subscription_id);
        if (!$subscription) {
            return null;
        }

        // Nothing created yet: the webhook retry completes it
        if (!$subscriptionData && !MollieHelper::currentVendorSubscriptionId($subscription, $transaction)) {
            return $order;
        }

        $claimKey = 'fc_mollie_reactivation_recorded_' . $transaction->id;
        if (!add_option($claimKey, '1', '', false)) {
            return $subscription;
        }

        try {
            return SubscriptionService::recordManualRenewal($subscription, $transaction, [
                'billing_info'      => $billingInfo,
                'subscription_args' => is_array($subscriptionData) ? $subscriptionData : []
            ]);
        } catch (\Throwable $e) {
            delete_option($claimKey);
            throw $e;
        }
    }

    public function maybeConfirmPayment($data)
    {
        $isReceipt = Arr::get($data, 'is_receipt', false);
        $method = Arr::get($data, 'method', '');

        if ($isReceipt || $method !== 'mollie') {
            return;
        }

        $transactionHash = Arr::get($data, 'trx_hash', '');

        $transactionModel = OrderTransaction::query()->where('uuid', $transactionHash)
            ->where('payment_method', 'mollie')
            ->first();

        if (!$transactionModel) {
            return;
        }

        if ($transactionModel->status === Status::TRANSACTION_SUCCEEDED) {
            $subscription = null;
            if ($transactionModel->subscription_id) {
                $subscription = Subscription::query()->where('id', $transactionModel->subscription_id)->first();
            }

            if ($subscription && !MollieHelper::currentVendorSubscriptionId($subscription, $transactionModel) && $subscription->collection_method === 'automatic' && $transactionModel->vendor_charge_id) {
                $molliePayment = (new MollieAPI())->getMollieObject('payments/' . $transactionModel->vendor_charge_id);
                if (!is_wp_error($molliePayment)) {
                    $this->maybeRecoverMissingSubscription($transactionModel, $molliePayment);
                    $subscription = Subscription::query()->where('id', $transactionModel->subscription_id)->first();
                }
            }

            if ($subscription && MollieHelper::currentVendorSubscriptionId($subscription, $transactionModel)) {
                $this->recordReactivationOnce($transactionModel, []);
                $subscription->reSyncFromRemote();
            }

            (new StatusHelper($transactionModel->order))->syncOrderStatuses($transactionModel);
            return;
        }

        $order = $transactionModel->order;

        if (!$order) {
            return;
        }

        // Local binding validation
        if (!$this->isLocalBindingValid($transactionModel, $order, $transactionHash)) {
            return;
        }

        if (empty($transactionModel->vendor_charge_id)) {
            return;
        }

        // get payment from mollie and confirm payment status
        $molliePayment = (new MollieAPI())->getMollieObject('payments/' . $transactionModel->vendor_charge_id);

        if (is_wp_error($molliePayment)) {
            return;
        }

        $molliePaymentStatus = Arr::get($molliePayment, 'status');

        if ($molliePaymentStatus === 'authorized' && $transactionModel->status === Status::TRANSACTION_AUTHORIZED) {
            return;
        }

        // Checked before a mandate can start a Mollie subscription
        if (in_array($molliePaymentStatus, ['paid', 'authorized'], true) && !$this->chargeMatchesTransaction($transactionModel, $order, $molliePayment, $transactionModel->vendor_charge_id)) {
            return;
        }

        $mandateId = Arr::get($molliePayment, 'mandateId');

        $billingInfo = [
            'method' => Arr::get($molliePayment, 'method'),
            'brand' => Arr::get($molliePayment, 'details.cardLabel'),
            'last4' => Arr::get($molliePayment, 'details.cardNumber'),
            'token' => Arr::get($molliePayment, 'details.cardToken'),
            'mandate_id' => $mandateId,
            'details' => [
                'method' => Arr::get($molliePayment, 'method'),
                'brand' => Arr::get($molliePayment, 'details.cardLabel'),
                'last_4' => Arr::get($molliePayment, 'details.cardNumber'),
                'token' => Arr::get($molliePayment, 'details.cardToken'),
            ]
        ];

        $subscriptionData = [];
        if ($mandateId) {
              $subscriptionData = $this->handleSubscriptionCreation($transactionModel, [
                'mandate_id' => $mandateId,
                'billingInfo' => $billingInfo
              ]);
        }

        if ($molliePaymentStatus === 'paid') {
            $this->confirmPaymentSuccessByCharge($transactionModel, [
                'charge' => $molliePayment,
                'vendor_charge_id' => $transactionModel->vendor_charge_id,
                'subscription_data' => $subscriptionData
            ]);
        } elseif ($molliePaymentStatus === 'authorized') {
            $this->authorizePaymentByCharge($transactionModel, [
                'charge' => $molliePayment,
                'vendor_charge_id' => $transactionModel->vendor_charge_id,
                'subscription_data' => $subscriptionData
            ]);
        }
    }

    public function confirmPaymentSuccessByCharge(OrderTransaction $transaction, $args = [])
    {
        $charge = Arr::get($args, 'charge', []);
        $vendorChargeId = Arr::get($args, 'vendor_charge_id');
        $subscriptionData = Arr::get($args, 'subscription_data', []);

        $order = $transaction->order;

        // in race conditions between webhook and AJAX confirmation
        $transaction = OrderTransaction::query()->where('id', $transaction->id)->first();
        if ($order == null) {
            return;
        }

        if ($transaction->status === Status::TRANSACTION_SUCCEEDED) {
            $subscription = null;
            if ($transaction->subscription_id) {
                $subscription = Subscription::query()->where('id', $transaction->subscription_id)->first();
            }

            if ($subscription) {
                $this->maybeRecoverMissingSubscription($transaction, $charge);
                $this->recordReactivationOnce($transaction, []);
                $subscription = Subscription::query()->where('id', $transaction->subscription_id)->first();
            }

            if ($subscription && MollieHelper::currentVendorSubscriptionId($subscription, $transaction)) {
                $subscription->reSyncFromRemote();
            }

            (new StatusHelper($transaction->order))->syncOrderStatuses($transaction);
            return;
        }

        $mandateId = Arr::get($charge, 'mandateId');

        $billingInfo = [
            'method' => Arr::get($charge, 'method'),
            'brand' => Arr::get($charge, 'details.cardLabel'),
            'last4' => Arr::get($charge, 'details.cardNumber'),
            'token' => Arr::get($charge, 'details.cardToken'),
            'mandate_id' => $mandateId,
            'details' => [
                'method' => Arr::get($charge, 'method'),
                'brand' => Arr::get($charge, 'details.cardLabel'),
                'last_4' => Arr::get($charge, 'details.cardNumber'),
                'token' => Arr::get($charge, 'details.cardToken'),
            ]
        ];
        
        // if we consider authorized as success state, then it success related actions already is handled
        // currently not handled , just implemented for later use
        if ($transaction->status === Status::TRANSACTION_AUTHORIZED && (new MollieSettingsBase())->get('is_authorize_a_success_state') == 'yes') {
            // Mollie's paidAt is when the money actually moved; it beats the
            // model hook's fallback now() stamp, which for a delayed webhook
            // would be the (later) processing time.
            $paidAt = Arr::get($charge, 'paidAt');
            if ($paidAt && empty($transaction->meta['settled_at'])) {
                $transaction->meta = array_merge($transaction->meta ?? [], [
                    'settled_at' => DateTime::anyTimeToGmt($paidAt)->format('Y-m-d H:i:s')
                ]);
            }

            $transaction->status = Status::TRANSACTION_SUCCEEDED;
            $transaction->save();

            fluent_cart_add_log(__('Mollie Payment Confirmation', 'fluent-cart-pro'), __('Payment confirmation received from Mollie for previously authorized payment. Transaction ID: ', 'fluent-cart-pro')  . $vendorChargeId, 'info', [
                'module_name' => 'order',
                'module_id'   => $order->id,
            ]);

            if ($transaction->subscription_id) {
                $subscription = Subscription::query()->find($transaction->subscription_id);
                if ($subscription) {
                    $subscription->addLog(__('Mollie Payment Confirmation', 'fluent-cart-pro'), __('Payment confirmation received from Mollie for previously authorized payment. Transaction ID: ', 'fluent-cart-pro') . $vendorChargeId);
                }
            }

            return $order;
        }

        if (!$this->chargeMatchesTransaction($transaction, $order, $charge, $vendorChargeId)) {
            return $order;
        }

        $amount = Arr::get($charge, 'amount.value');
        $currency = Arr::get($charge, 'amount.currency');
        $amountInCents = MollieHelper::convertToCents($amount, $currency);

        $details = Arr::get($charge, 'details', []);

        // Mollie's paidAt is when the money actually moved. When this
        // confirmation is the first path to mark the transaction succeeded, it
        // beats the model hook's fallback now() stamp — which for a delayed
        // webhook would be the (later) processing time, not the charge time.
        $paidAt = Arr::get($charge, 'paidAt');
        if ($paidAt && empty($transaction->meta['settled_at'])) {
            $transaction->meta = array_merge($transaction->meta ?? [], [
                'settled_at' => DateTime::anyTimeToGmt($paidAt)->format('Y-m-d H:i:s')
            ]);
        }

        $transactionUpdateData = array_filter([
            'order_id'            => $order->id,
            'total'               => $amountInCents,
            'currency'            => $currency,
            'status'              => Status::TRANSACTION_SUCCEEDED,
            'payment_method'      => 'mollie',
            'card_last_4'         => Arr::get($details, 'cardNumber', ''),
            'card_brand'          => Arr::get($details, 'cardLabel', ''),
            'payment_method_type' => Arr::get($charge, 'method', ''),
            'vendor_charge_id'    => $vendorChargeId,
            'payment_mode'        => $order->mode,
            'meta'                => array_merge($transaction->meta ?? [], $billingInfo)
        ]);

        $transaction->fill($transactionUpdateData);
        $transaction->save();

        if ($order->type == status::ORDER_TYPE_RENEWAL) {
            $subscriptionModel = Subscription::query()->where('id', $transaction->subscription_id)->first();

            if (!$subscriptionModel) {
                return $order; // No subscription found for this renewal order. Something is wrong.
            }

            if (!$subscriptionData) {
                // Store-billed (manual/system) renewals are charged as plain oneoff
                // payments — no mandate, so nothing vendor-side to record. syncOrderStatuses
                // fires fluent_cart/renewal_paid, whose listeners own next_billing_date and
                // bill_count. For automatic subscriptions an empty result means vendor
                // subscription creation failed — leave the order untouched so the
                // webhook/retry path can complete it.
                if (in_array($subscriptionModel->collection_method, ['manual', 'system'], true)) {
                    return (new StatusHelper($order))->syncOrderStatuses($transaction);
                }
            }

            $reactivation = $this->recordReactivationOnce($transaction, $subscriptionData, $billingInfo);
            if ($reactivation) {
                return $reactivation;
            }

            if (!$subscriptionData) {
                return $order;
            }

            return SubscriptionService::recordManualRenewal($subscriptionModel, $transaction, [
                'billing_info'      => $billingInfo,
                'subscription_args' => $subscriptionData
            ]);
        }

        fluent_cart_add_log(__('Mollie Payment Confirmation', 'fluent-cart-pro'), __('Payment confirmation received from Mollie. Transaction ID: ', 'fluent-cart-pro')  . $vendorChargeId, 'info', [
            'module_name' => 'order',
            'module_id'   => $order->id,
        ]);

        if ($transaction->subscription_id) {
            $subscription = Subscription::query()->find($transaction->subscription_id);
            if ($subscription) {
                $subscription->addLog(__('Mollie Payment Confirmation', 'fluent-cart-pro'), __('Payment confirmation received from Mollie. Transaction ID: ', 'fluent-cart-pro') . $vendorChargeId);
            }
        }

        return (new StatusHelper($order))->syncOrderStatuses($transaction);

    }

    public function authorizePaymentByCharge(OrderTransaction $transaction, $args = [])
    {
        $charge = Arr::get($args, 'charge', []);
        $vendorChargeId = Arr::get($args, 'vendor_charge_id');
        $subscriptionData = Arr::get($args, 'subscription_data', []);

        $order = $transaction->order;

        if ($order == null){
            return null;
        }

        if ($transaction->status === Status::TRANSACTION_SUCCEEDED) {
            $subscription = null;
            if ($transaction->subscription_id) {
                $subscription = Subscription::query()->where('id', $transaction->subscription_id)->first();
            }

            if ($subscription) {
                $this->maybeRecoverMissingSubscription($transaction, $charge);
                $this->recordReactivationOnce($transaction, []);
                $subscription = Subscription::query()->where('id', $transaction->subscription_id)->first();
            }

            if ($subscription && MollieHelper::currentVendorSubscriptionId($subscription, $transaction)) {
                $subscription->reSyncFromRemote();
            }
            return (new StatusHelper($order))->syncOrderStatuses($transaction);
        }

        $mandateId = Arr::get($charge, 'mandateId');

        $billingInfo = [
            'method' => Arr::get($charge, 'method'),
            'brand' => Arr::get($charge, 'details.cardLabel'),
            'last4' => Arr::get($charge, 'details.cardNumber'),
            'token' => Arr::get($charge, 'details.cardToken'),
            'mandate_id' => $mandateId,
            'details' => [
                'method' => Arr::get($charge, 'method'),
                'brand' => Arr::get($charge, 'details.cardLabel'),
                'last_4' => Arr::get($charge, 'details.cardNumber'),
                'token' => Arr::get($charge, 'details.cardToken'),
            ]
        ];

        if (!$this->chargeMatchesTransaction($transaction, $order, $charge, $vendorChargeId)) {
            return $order;
        }

        $amount = Arr::get($charge, 'amount.value');
        $currency = Arr::get($charge, 'amount.currency');
        $amountInCents = MollieHelper::convertToCents($amount, $currency);

        $details = Arr::get($charge, 'details', []);

        $transactionUpdateData = array_filter([
            'order_id'            => $order->id,
            'total'               => $amountInCents,
            'currency'            => $currency,
            'status'              => Status::TRANSACTION_AUTHORIZED,
            'payment_method'      => 'mollie',
            'card_last_4'         => Arr::get($details, 'cardNumber', ''),
            'card_brand'          => Arr::get($details, 'cardLabel', ''),
            'payment_method_type' => Arr::get($charge, 'method', ''),
            'vendor_charge_id'    => $vendorChargeId,
            'payment_mode'        => $order->mode,
            'meta'                => array_merge($transaction->meta ?? [], $billingInfo)
        ]);

        $transaction->fill($transactionUpdateData);
        $transaction->save();

        fluent_cart_add_log(__('Mollie Payment Authorized', 'fluent-cart-pro'), __('Payment Authorized in Mollie. Transaction ID: ', 'fluent-cart-pro')  . $vendorChargeId, 'info', [
            'module_name' => 'order',
            'module_id'   => $order->id,
        ]);

        if ($transaction->subscription_id) {
            fluent_cart_add_log(__('Mollie Payment Authorized', 'fluent-cart-pro'), __('Payment Authorized in Mollie. Transaction ID: ', 'fluent-cart-pro')  . $vendorChargeId, 'info', [
                'module_name' => 'subscription',
                'module_id'   => $transaction->subscription_id,
            ]);
        }

        if ($order->type == status::ORDER_TYPE_RENEWAL) {
            $subscriptionModel = Subscription::query()->where('id', $transaction->subscription_id)->first();

            if (!$subscriptionModel) {
                return $order; // No subscription found for this renewal order. Something is wrong.
            }

            if (!$subscriptionData) {
                // Store-billed (manual/system) renewals are charged as plain oneoff
                // payments — no mandate, so nothing vendor-side to record. syncOrderStatuses
                // fires fluent_cart/renewal_paid, whose listeners own next_billing_date and
                // bill_count. For automatic subscriptions an empty result means vendor
                // subscription creation failed — leave the order untouched so the
                // webhook/retry path can complete it.
                if (in_array($subscriptionModel->collection_method, ['manual', 'system'], true)) {
                    return (new StatusHelper($order))->syncOrderStatuses($transaction);
                }
            }

            $reactivation = $this->recordReactivationOnce($transaction, $subscriptionData, $billingInfo);
            if ($reactivation) {
                return $reactivation;
            }

            if (!$subscriptionData) {
                return $order;
            }

            return SubscriptionService::recordManualRenewal($subscriptionModel, $transaction, [
                'billing_info'      => $billingInfo,
                'subscription_args' => $subscriptionData
            ]);
        }

        $isAuthorizedASuccessState = (new MollieSettingsBase())->get('is_authorize_a_success_state') == 'yes';

        if ($isAuthorizedASuccessState) {
            return (new StatusHelper($order))->syncOrderStatuses($transaction);
        } else {
            $relatedCart = Cart::query()->where('order_id', $order->id)
                ->where('stage', '!=', 'completed')
                ->first();

            if ($relatedCart) {
                $relatedCart->stage = 'completed';
                $relatedCart->completed_at = DateTime::now()->format('Y-m-d H:i:s');
                $relatedCart->save();

                do_action('fluent_cart/cart_completed', [
                    'cart'  => $relatedCart,
                    'order' => $order,
                ]);

                $onSuccessActions = Arr::get($relatedCart->checkout_data, '__on_success_actions__', []);

                if ($onSuccessActions) {
                    foreach ($onSuccessActions as $onSuccessAction) {
                        $onSuccessAction = (string)$onSuccessAction;
                        if (has_action($onSuccessAction)) {
                            do_action($onSuccessAction, [
                                'cart'        => $relatedCart,
                                'order'       => $order,
                                'transaction' => $transaction
                            ]);
                        }
                    }
                }
            }
        }
        
        return $order;

    }


    public function handleSubscriptionCreation(OrderTransaction $transaction, $args = [])
    {
        $subscriptionModel = Subscription::query()
            ->where('id', $transaction->subscription_id)
            ->first();
        
        if (!$subscriptionModel || MollieHelper::currentVendorSubscriptionId($subscriptionModel, $transaction)) {
            return null;
        }

        // Store-billed subscriptions (manual/system) must never gain a vendor
        // schedule — creation runs on confirmation/webhook, after the charge-time
        // shouldChargeSubscriptionAsOneTime guard, so re-check the subscription here.
        $mandateId = Arr::get($args, 'mandate_id');
        if (!$mandateId || $subscriptionModel->collection_method !== 'automatic') {
            return null;
        }

        // Mutex: serialize webhook and redirect workers at the DB layer.
        // GET_LOCK is shared across MySQL connections — atomic regardless of object cache backend.
        // Timeout 0 = non-blocking; auto-releases if PHP dies mid-execution.
        global $wpdb;
        $lockName = 'fc_mollie_sub_' . $subscriptionModel->id;
        $lockAcquired = (bool) $wpdb->get_var(
            $wpdb->prepare("SELECT GET_LOCK(%s, 0)", $lockName)
        );

        if (!$lockAcquired) {
            // Another process holds the lock; re-read to see if it completed.
            $subscriptionModel = Subscription::query()->find($subscriptionModel->id);
            if (MollieHelper::currentVendorSubscriptionId($subscriptionModel, $transaction)) {
                return [
                    'vendor_subscription_id' => $subscriptionModel->vendor_subscription_id,
                    'status'                 => $subscriptionModel->status,
                ];
            }
            return null;
        }

        // Re-read after acquiring lock — the other concurrent call may have just
        // finished, or the subscription may have been switched to store billing.
        $subscriptionModel = Subscription::query()->find($subscriptionModel->id);
        if (MollieHelper::currentVendorSubscriptionId($subscriptionModel, $transaction)
            || $subscriptionModel->collection_method !== 'automatic') {
            $wpdb->get_var($wpdb->prepare("SELECT RELEASE_LOCK(%s)", $lockName));
            return null;
        }

        $mandate = (new MollieAPI())->getMollieObject('customers/' . $subscriptionModel->vendor_customer_id . '/mandates/' . $mandateId);

        if (is_wp_error($mandate)) {
            fluent_cart_error_log('Mollie Subscription Creation', 'Failed to fetch mandate: ' . $mandate->get_error_message(), [
                'module_name' => 'subscription',
                'module_id'   => $subscriptionModel->id,
            ]);
            $wpdb->get_var($wpdb->prepare("SELECT RELEASE_LOCK(%s)", $lockName));
            return null;
        }

        if (!in_array(Arr::get($mandate, 'status'), ['valid', 'pending'])) {
            fluent_cart_error_log('Mollie Subscription Creation', 'Mandate status is ' . Arr::get($mandate, 'status') . ', expected valid or pending', [
                'module_name' => 'subscription',
                'module_id'   => $subscriptionModel->id,
            ]);
            $wpdb->get_var($wpdb->prepare("SELECT RELEASE_LOCK(%s)", $lockName));
            return null;
        }

        $order = $transaction->order;

        if (!$order) {
            fluent_cart_error_log('Mollie Subscription Creation', 'Order not found for transaction ' . $transaction->id, [
                'module_name' => 'subscription',
                'module_id'   => $subscriptionModel->id,
            ]);
            $wpdb->get_var($wpdb->prepare("SELECT RELEASE_LOCK(%s)", $lockName));
            return null;
        }

        $intervalMap = [
            'daily'       => '1 day',
            'weekly'      => '1 week',
            'monthly'     => '1 month',
            'quarterly'   => '3 months',
            'half_yearly' => '6 months',
            'yearly'      => '12 months',
        ];

        $billingPeriod = [
            'interval_unit' => Arr::get($intervalMap, $subscriptionModel->billing_interval, '1 month')
        ];

        $billingPeriod = apply_filters('fluent_cart/subscription_billing_period', $billingPeriod, [
            'subscription_interval' => $subscriptionModel->billing_interval,
            'payment_method' => 'mollie',
        ]);

        $billsCount = $subscriptionModel->calculateBillCount();

        // Read after counting: still pending means the count missed this payment;
        // succeeded means a concurrent confirmation may have landed mid-count, so count again
        $paidTransaction = OrderTransaction::query()->find($transaction->id);
        if ($paidTransaction && $paidTransaction->status === Status::TRANSACTION_SUCCEEDED) {
            $billsCount = $subscriptionModel->calculateBillCount();
        } elseif ($paidTransaction && $paidTransaction->total > 0) {
            $billsCount++;
        }


        $description = MollieHelper::generateSubscriptionDescription($subscriptionModel, $order->currency, $order->type);
        $startDate = MollieHelper::calculateSubscriptionStartDate($subscriptionModel, $order);


        // now create the subscription in mollie, remember first payment is already done
        $mollieSubscriptionData = [
            'amount' => [
                'value' => (new MollieProcessor())->formatAmount($subscriptionModel->getCurrentRenewalAmount(), $transaction->currency),
                'currency' => $transaction->currency
            ],
            'interval' => Arr::get($billingPeriod, 'interval_unit'),
            'description' =>  $description,
            'webhookUrl' => (new MollieProcessor())->getWebhookUrl(),
            'mandateId' => $mandateId,
            'startDate' => $startDate,
            'metadata' => [
                'subscription_hash' => $subscriptionModel->uuid,
                'order_hash' => $transaction->order->uuid
            ]
        ];
       

        if ($subscriptionModel->bill_times > 0) {
            $times = $subscriptionModel->bill_times - $billsCount;
            if ($times < 1) {
                // no need to create subscription as all bills are already paid
                $wpdb->get_var($wpdb->prepare("SELECT RELEASE_LOCK(%s)", $lockName));
                // A reactivation paid the last installment: the stored id is the replaced one,
                // so recording the renewal completes the subscription locally
                if ($order->type === Status::ORDER_TYPE_RENEWAL) {
                    return ['bill_count' => $billsCount];
                }
                return $subscriptionModel->reSyncFromRemote();
            }
            $mollieSubscriptionData['times'] = $times;
        }

        // Check existing Mollie subscriptions for this customer
        $mollieSubscription = null;
        $descriptionStillTaken = false;
        $existingSubscriptions = (new MollieAPI())->getMollieObject('customers/' . $subscriptionModel->vendor_customer_id . '/subscriptions');

        if (!is_wp_error($existingSubscriptions) && !empty($existingSubscriptions['_embedded']['subscriptions'])) {
            foreach ($existingSubscriptions['_embedded']['subscriptions'] as $existingSub) {
                if (!in_array(Arr::get($existingSub, 'status'), ['active', 'pending'])) {
                    continue;
                }

                // Reuse if same local subscription — handles webhook/redirect race condition
                if (Arr::get($existingSub, 'metadata.subscription_hash') === $subscriptionModel->uuid) {
                    $mollieSubscription = $existingSub;
                    break;
                }

                // Candidate orphan: active Mollie subscription with same description but different hash.
                // A matching description alone does not prove abandonment — two legitimate
                // subscriptions for the same product/price/interval share it. Only cancel when
                // the hash resolves to no local subscription, or to one that is no longer live.
                if (Arr::get($existingSub, 'description') === $description) {
                    $orphanId = Arr::get($existingSub, 'id');
                    $ownerHash = Arr::get($existingSub, 'metadata.subscription_hash');
                    $ownerSubscription = $ownerHash ? Subscription::query()->where('uuid', $ownerHash)->first() : null;

                    if ($ownerSubscription && in_array($ownerSubscription->status, [
                        Status::SUBSCRIPTION_ACTIVE,
                        Status::SUBSCRIPTION_PENDING,
                        Status::SUBSCRIPTION_TRIALING,
                        Status::SUBSCRIPTION_PAST_DUE,
                    ], true)) {
                        // Owned by a still-live local subscription — not an orphan, leave it alone.
                        // Mollie still requires a unique description per customer across active
                        // subscriptions, so the new subscription below can't reuse this one verbatim.
                        $descriptionStillTaken = true;
                        continue;
                    }

                    $deleteResult = (new MollieAPI())->deleteMollieObject(
                        'customers/' . $subscriptionModel->vendor_customer_id . '/subscriptions/' . $orphanId,
                        []
                    );

                    if (is_wp_error($deleteResult)) {
                        $descriptionStillTaken = true;
                        fluent_cart_add_log(
                            __('Mollie Orphan Subscription Cancel Failed', 'fluent-cart-pro'),
                            sprintf(__('Failed to cancel orphan Mollie subscription %s (duplicate description, different hash) before creating new subscription for local ID %d: %s', 'fluent-cart-pro'), $orphanId, $subscriptionModel->id, $deleteResult->get_error_message()),
                            'error',
                            ['module_name' => 'subscription', 'module_id' => $subscriptionModel->id]
                        );
                        continue;
                    }

                    fluent_cart_add_log(
                        __('Mollie Orphan Subscription Cancelled', 'fluent-cart-pro'),
                        sprintf(__('Cancelled orphan Mollie subscription %s (duplicate description, different hash) before creating new subscription for local ID %d.', 'fluent-cart-pro'), $orphanId, $subscriptionModel->id),
                        'info',
                        ['module_name' => 'subscription', 'module_id' => $subscriptionModel->id]
                    );
                }
            }
        }

        if (!$mollieSubscription && $descriptionStillTaken) {
            $mollieSubscriptionData['description'] .= ' #' . $subscriptionModel->id;
        }

        if (!$mollieSubscription) {
            $mollieSubscription = (new MollieAPI())->createMollieObject('customers/' . $subscriptionModel->vendor_customer_id . '/subscriptions', $mollieSubscriptionData);
        }

        if (is_wp_error($mollieSubscription)) {

            // log the error message
            fluent_cart_add_log(__('Mollie Subscription Creation Failed', 'fluent-cart-pro'), __('Failed to create subscription in Mollie. Error: ', 'fluent-cart-pro')  . $mollieSubscription->get_error_message(), 'error', [
                'module_name' => 'order',
                'module_id'   => $order->id,
            ]);

            if ($subscriptionModel) {
                $subscriptionModel->addLog(__('Mollie Subscription Creation Failed', 'fluent-cart-pro'), __('Failed to create subscription in Mollie. Error: ', 'fluent-cart-pro') . $mollieSubscription->get_error_message(), 'error');
            }

            $wpdb->get_var($wpdb->prepare("SELECT RELEASE_LOCK(%s)", $lockName));
            return null;
        }
        
        $oldStatus = $subscriptionModel->status;

        $updateData = [
            'vendor_subscription_id' => Arr::get($mollieSubscription, 'id'),
            'current_payment_method' => 'mollie',
            'status' => MollieHelper::transformSubscriptionStatus($mollieSubscription, $subscriptionModel),
            'bill_count' => $billsCount,
            'vendor_response' => json_encode($mollieSubscription)
        ];

        if (Arr::get($mollieSubscription, 'nextPaymentDate')) {
            $updateData['next_billing_date'] = Arr::get($mollieSubscription, 'nextPaymentDate');
        } else {
            $updateData['next_billing_date'] = $subscriptionModel->guessNextBillingDate();
        }


        $subscriptionModel->fill($updateData);
        $subscriptionModel->save();

        $subscriptionModel->updateMeta('active_payment_method', Arr::get($args, 'billingInfo', []));

        if ($oldStatus != status::SUBSCRIPTION_ACTIVE && Arr::get($mollieSubscription, 'status') === Status::SUBSCRIPTION_ACTIVE) {
            (new SubscriptionActivated($subscriptionModel, $order, $order->customer))->dispatch();
        }

        $wpdb->get_var($wpdb->prepare("SELECT RELEASE_LOCK(%s)", $lockName));
        return $updateData;

    }

    /**
     * A retry can move the transaction to another currency or total, so a
     * stale payment from an earlier attempt must not confirm it.
     */
    public function chargeMatchesTransaction(OrderTransaction $transaction, $order, $charge, $vendorChargeId): bool
    {
        $paidCurrency = strtoupper((string) Arr::get($charge, 'amount.currency', ''));
        $expectedCurrency = strtoupper((string) $transaction->currency);
        $paidAmount = MollieHelper::convertToCents(Arr::get($charge, 'amount.value', 0), $paidCurrency);
        // Renewal first payments store the amount sent (zero with reactivation trial days)
        $expectedTotal = (int) Arr::get($transaction->meta, 'mollie_first_payment_amount', $transaction->total);
        // What was sent to Mollie: zero-decimal currencies go out in whole units
        $expectedAmount = MollieHelper::convertToCents(MollieHelper::formatAmountForMollie($expectedTotal, $expectedCurrency), $expectedCurrency);

        $matches = $paidCurrency === $expectedCurrency && $paidAmount >= $expectedAmount;
        if ($matches) {
            return true;
        }

        fluent_cart_add_log(__('Mollie Payment Mismatch', 'fluent-cart-pro'), sprintf(
            /* translators: 1: Mollie payment ID, 2: paid amount, 3: paid currency, 4: expected amount, 5: expected currency */
            __('Mollie payment %1$s paid %2$s %3$s, but the transaction expects %4$s %5$s. The order was not confirmed.', 'fluent-cart-pro'),
            $vendorChargeId,
            Arr::get($charge, 'amount.value', ''),
            $paidCurrency,
            MollieHelper::formatAmountForMollie($expectedTotal, $expectedCurrency),
            $expectedCurrency
        ), 'error', [
            'module_name' => 'order',
            'module_id'   => $order->id,
        ]);

        return false;
    }

    /**
     * Validate local data binding consistency
     */
    private function isLocalBindingValid(OrderTransaction $transaction, $order, $transactionHash)
    {
        if (!$transaction || !$order) {
            return false;
        }

        if ($transactionHash && $transaction->uuid !== $transactionHash) {
            return false;
        }

        return true;
    }
}
