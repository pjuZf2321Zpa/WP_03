<?php

/** Premium theme workspace. Native WordPress preview is visual isolation, not a PHP execution sandbox. */

namespace WPAICG\Lib\Mcp;

use WPAICG\Mcp\{Abilities, Identity, Journal, Operations};

if (!defined('ABSPATH')) {
    exit;
}

final class Themes
{
    private const PREFIX = 'ai-puffer/theme-';
    private const OPTION = 'aipkit_mcp_theme_workspace';
    private const LIMIT = 16777216;
    private const EDIT_LIMIT = 60000;
    private const ACTIONS = ['status', 'create-draft', 'list-files', 'file-outline', 'read-file', 'read-backup-file', 'search-files', 'write-file', 'delete-file', 'undo-file', 'preview', 'publish', 'rollback', 'archive', 'resume'];
    private static $locked = false;
    private static $preview_version = null;
    private static $preview_id = null;

    public static function register(): void
    {
        add_action('setup_theme', [self::class, 'begin_preview']);
        add_action('template_redirect', [self::class, 'capture_preview'], PHP_INT_MAX);
        add_action('wp_footer', [self::class, 'finish_preview'], PHP_INT_MAX);
        add_action('wp_abilities_api_init', [self::class, 'abilities']);
        add_filter('aipkit_mcp_ability_offered', [self::class, 'offered'], 10, 2);
        add_filter('aipkit_mcp_ability_content_error', [self::class, 'content_error'], 10, 3);
        add_filter('aipkit_mcp_ability_result', [self::class, 'dispatch'], 10, 4);
    }

    public static function begin_preview(): void
    {
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- No query means no preview or workspace lookup.
        if (!isset($_GET['wp_theme_preview'])) {
            return;
        }
        $w = self::workspace();
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Core preview additionally requires the authenticated user's switch_themes capability; no mutation from this parameter.
        $requested = isset($_GET['wp_theme_preview']) ? sanitize_text_field(wp_unslash($_GET['wp_theme_preview'])) : '';
        if ($w && $w['state'] === 'draft' && $w['owner'] === get_current_user_id() && $requested === $w['slug'] && self::can('preview')) {
            self::$preview_id = $w['id'];
            $parent = wp_get_theme($w['slug'])->get_template();
            add_filter('pre_option_stylesheet', static function () use ($w) {
                return $w['slug'];
            });
            add_filter('pre_option_template', static function () use ($parent) {
                return $parent;
            });
        }
    }

    public static function capture_preview(): void
    {
        if (self::$preview_id === null) {
            return;
        }
        $w = self::workspace();
        if ($w && $w['id'] === self::$preview_id && $w['state'] === 'draft') {
            self::$preview_version = self::version($w);
        }
    }

    public static function finish_preview(): void
    {
        if (self::$preview_version === null || http_response_code() >= 400) {
            return;
        }
        try {
            self::lock();
            wp_cache_delete(self::OPTION, 'options');
            $w = self::workspace();
            if (!$w || $w['id'] !== self::$preview_id || $w['state'] !== 'draft' || $w['owner'] !== get_current_user_id() || self::version($w) !== self::$preview_version) {
                return;
            }
            $w['preview_version'] = self::$preview_version;
            $w['previewed_at'] = time();
            self::store($w);
        } catch (\Throwable$error) {
            // No confirmed receipt: publish refuses. Do not break the frontend or claim that this preview completed.
            return;
        } finally {
            self::unlock();
        }
    }

    private static function paid(): bool
    {
        return function_exists('aipkit_pro_plan_active') && aipkit_pro_plan_active();
    }

    private static function handles(string $name): bool
    {
        return strpos($name, self::PREFIX) === 0 && in_array(substr($name, strlen(self::PREFIX)), self::ACTIONS, true);
    }

    public static function offered(bool $offered, \WP_Ability $ability): bool
    {
        return self::handles($ability->get_name()) ? self::paid() : $offered;
    }

    public static function content_error($error, string $name, $input)
    {
        // This typed Premium operation intentionally accepts theme source text. It never opens arbitrary paths.
        return self::paid() && $name === self::PREFIX . 'write-file' ? null : $error;
    }

    public static function dispatch($result, string $name, $input, bool $preview)
    {
        return self::handles($name) ? self::execute(substr($name, strlen(self::PREFIX)), (array) $input, $preview) : $result;
    }

    public static function abilities(): void
    {
        if (!self::paid() || !function_exists('wp_register_ability')) {
            return;
        }
        $hash = ['type' => 'string','pattern' => '^[a-f0-9]{64}$'];
        $path = ['type' => 'string','minLength' => 1,'maxLength' => 200];
        $defs = [
            'status' => [true,'Read current theme workspace, active theme and draft version. Premium theme tools operate on a separate draft; source/live files are not edited.',[],[]],
            'create-draft' => [false,'Create a separate draft: mode clone copies the active theme; mode classic creates a small native PHP theme. Live visitors keep their theme. A workspace already in progress is never overwritten.',['mode' => ['type' => 'string','enum' => ['clone','classic']],'title' => ['type' => 'string','maxLength' => 120]],['mode']],
            'list-files' => [true,'List draft-theme files and SHA256 versions. Page size50. No plugin, uploads, config or server files.',['page' => ['type' => 'integer','minimum' => 1]],[]],
            'file-outline' => [true,'Read PHP declarations and WordPress hook registrations in one draft-theme PHP file, with line numbers and its hash. Read-only, maximum60000 bytes/200 entries; no code execution. Other file types return an explicit unsupported-format result.',['path' => $path],['path']],
            'read-file' => [true,'Read one draft theme text file and its version. Maximum60000 bytes.',['path' => $path],['path']],
            'read-backup-file' => [true,'Read one original theme text file from the verified private backup, for recovery without overwriting later original-theme edits.',['path' => $path],['path']],
            'search-files' => [true,'Search literal text in draft theme source; returns line numbers and bounded snippets. No regular expressions.',['query' => ['type' => 'string','minLength' => 1,'maxLength' => 100],'page' => ['type' => 'integer','minimum' => 1]],['query']],
            'write-file' => [false,'Create/edit ONE draft theme PHP/CSS/JS/JSON/HTML/text file. Supply exact expected_hash from read-file; use new only for a new file. PHP is parsed without execution. Changes stay in the draft until publish. Use content as literal source text, not base64. Returns journal-backed undo.',['path' => $path,'expected_hash' => ['type' => 'string','pattern' => '^(new|[a-f0-9]{64})$'],'content' => ['type' => 'string','maxLength' => 60000]],['path','expected_hash','content']],
            'delete-file' => [false,'Remove ONE draft-theme text file with its exact expected_hash. Core style.css/index.php/templates/index.html cannot be removed. Undo evidence is retained.',['path' => $path,'expected_hash' => $hash],['path','expected_hash']],
            'undo-file' => [false,'Restore a successful workspace file change using its operation_id, only if that exact change is still current. Refuses later edits and published workspaces.',['operation_id' => ['type' => 'string','pattern' => '^[a-f0-9-]{36}$']],['operation_id']],
            'preview' => [true,'Get the native WordPress preview URL for this exact draft version. Requires a logged-in WordPress user with switch_themes. Other visitors stay on the live theme. PHP preview runs inside WordPress, not an isolated process.',[],[]],
            'publish' => [false,'Activate the draft as a NEW theme, preserving the original theme directory. Requires fresh workspace version, switch_themes, PHP validation and a verified private database backup. Preview and review the exact version first.',['version' => $hash],['version']],
            'archive' => [false,'Park an unpublished or rolled-back workspace without deleting its files or backup. Frees the workspace slot; resume later using its archive_id.',[],[]],
            'resume' => [false,'Resume an archived workspace owned by this WordPress user. Requires an empty workspace slot and existing unchanged files.',['archive_id' => ['type' => 'string','pattern' => '^[a-f0-9-]{36}$']],['archive_id']],
            'rollback' => [false,'Restore the original theme after this workspace was published. Requires current live workspace version; refuses intervening theme switches or changed original files. The private backup is retained for recovery.',['version' => $hash],['version']],
        ];
        foreach ($defs as $name => [$read,$description,$properties,$required]) {
            $schema = ['type' => 'object','additionalProperties' => false];
            if ($properties) {
                $schema['properties'] = $properties;
            }
            if ($required) {
                $schema['required'] = $required;
            }
            wp_register_ability(self::PREFIX . $name, [
                'label' => 'Theme: ' . str_replace('-', ' ', $name),'description' => $description,'category' => Abilities::CATEGORY,
                'input_schema' => $schema,'meta' => ['public' => true,'annotations' => ['readonly' => $read,'destructive' => $name === 'delete-file']],
                'permission_callback' => static function () use ($name): bool {
                    return self::can($name);
                },
                'execute_callback' => static function ($input = []) use ($name) {
                    $r = self::execute($name, (array)$input, false);
                    return $r['state'] === 'succeeded' ? json_decode($r['result']['data_json'], true) : new \WP_Error($r['error']['code'], $r['error']['message']);
                },
            ]);
        }
    }

    private static function can(string $action): bool
    {
        return self::paid() && current_user_can('edit_themes') && wp_is_file_mod_allowed('aipkit_mcp_theme')
            && (!in_array($action, ['preview','publish','rollback'], true) || current_user_can('switch_themes'));
    }

    private static function fail(string $message): void
    {
        throw new \RuntimeException(esc_html($message));
    }
    private static function json($data): string
    {
        return (string) wp_json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    }
    private static function workspace(): array
    {
        $w = get_option(self::OPTION, []);
        return is_array($w) ? $w : [];
    }
    private static function store(array $state): void
    {
        update_option(self::OPTION, $state, false);
        if (get_option(self::OPTION) !== $state) {
            self::fail('The workspace record could not be saved. No further change was attempted.');
        }
    }
    private static function slug(string $slug): string
    {
        if (!preg_match('/^[a-zA-Z0-9][a-zA-Z0-9_-]{0,100}$/D', $slug)) {
            self::fail('Unsupported theme directory name.');
        }
        return $slug;
    }
    private static function root(string $slug): string
    {
        self::slug($slug);
        $base = realpath(get_theme_root($slug));
        if (!$base || is_link($base . '/' . $slug) || !is_dir($base . '/' . $slug)) {
            self::fail('The theme directory is missing or is a symbolic link.');
        }
        $root = realpath($base . '/' . $slug);
        if (!$root || dirname($root) !== $base) {
            self::fail('Invalid theme directory.');
        }
        return $root;
    }
    /** Walk only regular files. Never follow symlinks, hidden files or unbounded theme trees. */
    private static function files(string $root): array
    {
        $files = [];
        $bytes = 0;
        $iterator = new \RecursiveIteratorIterator(new \RecursiveDirectoryIterator($root, \FilesystemIterator::SKIP_DOTS));
        foreach ($iterator as $file) {
            $relative = str_replace(DIRECTORY_SEPARATOR, '/', substr($file->getPathname(), strlen($root) + 1));
            if ($file->isLink()) {
                self::fail('A theme symlink must be resolved outside this workflow.');
            }
            if ($file->isDir()) {
                continue;
            }
            if (!$file->isFile() || preg_match('#(^|/)\.#', $relative) || strlen($relative) > 200 || substr_count($relative, '/') > 12) {
                self::fail('Unsupported theme file.');
            }
            $size = $file->getSize();
            $bytes += $size;
            if (count($files) >= 2000 || $size > 4194304 || $bytes > self::LIMIT) {
                self::fail('This theme exceeds the supported16MiB/2000-file workspace.');
            }
            $hash = hash_file('sha256', $file->getPathname());
            if (!$hash) {
                self::fail('A theme file could not be read.');
            }
            $files[$relative] = ['hash' => $hash,'bytes' => $size];
        }
        ksort($files);
        return$files;
    }
    private static function version(array $w): string
    {
        return hash('sha256', self::json([$w['id'],$w['state'],self::files(self::root($w['slug'])),self::parent_files($w['slug']),self::records($w['slug']),self::mods($w['slug'])]));
    }
    private static function mods(string $slug): array
    {
        $mods = (array)get_option('theme_mods_' . $slug, []);
        // This is a lazily initialized lookup cache, not a design change. CSS content is versioned in records().
        unset($mods['custom_css_post_id']);
        // WordPress refreshes this timestamp when switching themes; the actual widget layout remains versioned.
        if (isset($mods['sidebars_widgets']) && is_array($mods['sidebars_widgets'])) {
            unset($mods['sidebars_widgets']['time']);
        }
        return $mods;
    }
    private static function parent_files(string $slug): array
    {
        $parent = wp_get_theme($slug)->get_template();
        return $parent !== $slug ? self::files(self::root($parent)) : [];
    }
    /** Core Site Editor data is theme-specific too; a file-only clone would silently lose it. */
    private static function records(string $slug): array
    {
        $posts = get_posts(['post_type' => ['wp_template','wp_template_part','wp_global_styles'],'post_status' => ['publish','draft','private'],
            // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query -- Native wp_theme taxonomy is required to preserve this theme's Site Editor records; capped at 101.
            'posts_per_page' => 101,'orderby' => 'ID','order' => 'ASC','tax_query' => [['taxonomy' => 'wp_theme','field' => 'name','terms' => $slug]]]);
        $posts = array_merge($posts, get_posts(['post_type' => 'custom_css','name' => sanitize_title($slug),'post_status' => 'any','posts_per_page' => 1]));
        if (count($posts) > 100) {
            self::fail('This theme has too many saved Site Editor customizations for one workspace.');
        }
        $out = [];
        foreach ($posts as $post) {
            $meta = get_post_meta($post->ID);
            unset($meta['_edit_lock'], $meta['_edit_last']);
            $areas = wp_get_object_terms($post->ID, 'wp_template_part_area', ['fields' => 'ids']);
            $out[] = ['id' => $post->ID,'type' => $post->post_type,'name' => $post->post_name,'title' => $post->post_title,'content' => $post->post_content,
                'status' => $post->post_status,'excerpt' => $post->post_excerpt,'meta' => $meta,'areas' => is_wp_error($areas) ? [] : $areas];
        }
        if (strlen(self::json($out)) > 2097152) {
            self::fail('Saved Site Editor data exceeds the supported workspace size.');
        }
        return$out;
    }
    private static function copy_records(array $records, string $source, string $target): void
    {
        foreach ($records as $record) {
            $content = $record['content'];
            if ($record['type'] === 'custom_css') {
                $css = wp_update_custom_css_post($content, ['stylesheet' => $target]);
                if (is_wp_error($css) || $css->post_content !== $content) {
                    self::fail('Custom CSS could not be copied.');
                }
                continue;
            }
            if ($record['type'] !== 'wp_global_styles') {
                $blocks = parse_blocks($content);
                $rewrite = static function (array &$items) use (&$rewrite, $source, $target): void {
                    foreach ($items as &$block) {
                        if (($block['attrs']['theme'] ?? '') === $source) {
                            $block['attrs']['theme'] = $target;
                        }
                        if (!empty($block['innerBlocks'])) {
                            $rewrite($block['innerBlocks']);
                        }
                    }
                };
                $rewrite($blocks);
                $content = serialize_blocks($blocks);
            }
            $name = $record['type'] === 'wp_global_styles' ? 'wp-global-styles-' . $target : $record['name'];
            $id = wp_insert_post(wp_slash(['post_type' => $record['type'],'post_status' => $record['status'],'post_name' => $name,
                'post_title' => $record['title'],'post_content' => $content,'post_excerpt' => $record['excerpt'],'post_author' => get_current_user_id()]), true);
            if (is_wp_error($id)) {
                self::fail('A Site Editor customization could not be copied.');
            }
            $term = wp_set_object_terms($id, $target, 'wp_theme');
            if (is_wp_error($term)) {
                self::fail('The draft Site Editor theme could not be assigned.');
            }
            // Core initially chooses uniqueness against the active theme; repeat after assigning the target theme.
            $saved = wp_update_post(['ID' => $id,'post_name' => $name], true);
            if (is_wp_error($saved) || get_post($id)->post_name !== $name) {
                self::fail('A copied template slug could not be preserved.');
            }
            foreach ($record['meta'] as $key => $values) {
                foreach ($values as $value) {
                    add_post_meta($id, $key, wp_slash(maybe_unserialize($value)));
                }
            }
            if ($record['areas']) {
                wp_set_object_terms($id, array_map('intval', $record['areas']), 'wp_template_part_area');
            }
            if (get_post($id)->post_content !== $content) {
                self::fail('Copied Site Editor data could not be verified.');
            }
        }
    }
    private static function draft(): array
    {
        $w = self::workspace();
        if (($w['state'] ?? '') !== 'draft' || ($w['owner'] ?? 0) !== get_current_user_id()) {
            self::fail('Create or resume your unpublished theme workspace first.');
        }
        if (get_stylesheet() === $w['slug']) {
            self::fail('This draft was activated outside the workspace. File edits are paused.');
        }
        self::root($w['slug']);
        return$w;
    }
    private static function path(array $w, string $path, bool $new = false): string
    {
        if (
            $path === '' || strlen($path) > 200 || preg_match('#(^|/)(?:\.|\.\.)(?:/|$)|[\\\\\x00-\x1f:%]#', $path) || $path[0] === '/' || preg_match('#(^|/)\.#', $path)
            || !preg_match('/\.(php|css|js|json|html|txt)$/iD', $path)
        ) {
            self::fail('Use a relative draft theme text-file path, without traversal, hidden files or links.');
        }
        $root = self::root($w['slug']);
        $parts = explode('/', $path);
        $check = $root;
        foreach ($parts as $part) {
            $check .= '/' . $part;
            if (is_link($check)) {
                self::fail('Symbolic-link paths are not editable.');
            }
        }
        $parent = dirname($check);
        while (!file_exists($parent)) {
            $parent = dirname($parent);
        }
        $real = realpath($parent);
        if (!$real || ($real !== $root && strpos($real, $root . DIRECTORY_SEPARATOR) !== 0) || (!$new && !is_file($check))) {
            self::fail('The draft file does not exist or is outside this workspace.');
        }
        return$check;
    }
    private static function text(string $path): string
    {
        $size = filesize($path);
        if ($size === false || $size > self::EDIT_LIMIT) {
            self::fail('This file is too large for one source edit.');
        }
        $text = file_get_contents($path);
        if ($text === false || strpos($text, "\0") !== false || !preg_match('//u', $text)) {
            self::fail('Only UTF-8 text files can be read or edited.');
        }
        return$text;
    }
    private static function validate(string $path, string $text): void
    {
        if (strlen($text) > self::EDIT_LIMIT || strpos($text, "\0") !== false || !preg_match('//u', $text)) {
            self::fail('Use UTF-8 source text up to60000 bytes.');
        }
        $ext = strtolower(pathinfo($path, PATHINFO_EXTENSION));
        if ($ext === 'php') {
            try {
                token_get_all($text, TOKEN_PARSE);
            } catch (\ParseError$error) {
                self::fail('PHP syntax error: ' . $error->getMessage());
            }
        }
        if ($ext === 'json') {
            json_decode($text, true);
            if (json_last_error() !== JSON_ERROR_NONE) {
                self::fail('Invalid JSON: ' . json_last_error_msg());
            }
        }
        if ($path === 'style.css' && !preg_match('/^[ \t*]*Theme Name:\s*[^\r\n]+/m', $text)) {
            self::fail('style.css must retain its Theme Name header.');
        }
        if ($path === 'style.css' && preg_match('/^[ \t*]*Template:\s*([^\r\n]+)/m', $text, $m)) {
            $parent = trim($m[1]);
            self::slug($parent);
            if (!wp_get_theme($parent)->exists()) {
                self::fail('The parent theme must already be installed.');
            }
        }
    }
    private static function atomic(string $path, string $text): void
    {
        if (!wp_mkdir_p(dirname($path))) {
            self::fail('The host does not allow creating this directory.');
        }
        $temp = dirname($path) . '/.aipkit-' . wp_generate_uuid4() . '.tmp';
        try {
            if (file_put_contents($temp, $text, LOCK_EX) !== strlen($text)) {
                self::fail('Could not write the complete draft file.');
            }
            // phpcs:ignore WordPress.WP.AlternativeFunctions.rename_rename -- Same-directory native rename preserves atomic file replacement; remote/copy-then-delete transports would not.
            if (!rename($temp, $path)) {
                self::fail('Could not install the draft file.');
            }
            clearstatcache(true, $path);
            if (hash_file('sha256', $path) !== hash('sha256', $text)) {
                self::fail('The saved file could not be verified.');
            }
            if (function_exists('opcache_invalidate')) {
                opcache_invalidate($path, true);
            }
        } finally {
            if (is_file($temp)) {
                wp_delete_file($temp);
            }
        }
        wp_clean_themes_cache();
    }
    private static function copy(string $source, string $dest, array $manifest): void
    {
        foreach ($manifest as $path => $info) {
            if (!wp_mkdir_p(dirname($dest . '/' . $path)) || !copy($source . '/' . $path, $dest . '/' . $path) || hash_file('sha256', $dest . '/' . $path) !== $info['hash']) {
                self::fail('The theme copy could not be verified. The source was not changed.');
            }
        }
        if (self::files($source) !== $manifest) {
            self::fail('The source theme changed while copying.');
        }
    }
    private static function native_url(array $w): string
    {
        return add_query_arg('wp_theme_preview', $w['slug'], home_url('/'));
    }
    private static function status(): array
    {
        $w = self::workspace();
        $out = ['active_theme' => get_stylesheet(),'workspace' => $w ? ['id' => $w['id'],'state' => $w['state'],'theme' => $w['slug'],'owner' => $w['owner']] : null];
        if ($w) {
            $out['version'] = self::version($w);
            $out['preview_url'] = self::native_url($w);
        }
        return$out;
    }
    private static function starter(string $title): array
    {
        return [
            'style.css' => "/*\nTheme Name: " . sanitize_text_field($title) . "\nVersion: 1.0.0\nUpdate URI: false\n*/\nbody{margin:0;font:18px/1.65 system-ui,sans-serif;color:#1e293b;background:#f8fafc}header,main,footer{max-width:1100px;margin:auto;padding:32px}a{color:#2563eb}article{margin:32px 0}img{max-width:100%;height:auto}\n",
            'functions.php' => "<?php\ndefined('ABSPATH') || exit;\nadd_action('after_setup_theme', static function(){add_theme_support('title-tag');add_theme_support('post-thumbnails');add_theme_support('automatic-feed-links');});\nadd_action('wp_enqueue_scripts', static function(){wp_enqueue_style('aipkit-theme',get_stylesheet_uri(),[],wp_get_theme()->get('Version'));});\n",
            'header.php' => '<!doctype html><html <?php language_attributes(); ?>><head><meta charset="<?php bloginfo("charset"); ?>"><meta name="viewport" content="width=device-width,initial-scale=1"><?php wp_head(); ?></head><body <?php body_class(); ?>><?php wp_body_open(); ?><header><a href="<?php echo esc_url(home_url("/")); ?>"><?php bloginfo("name"); ?></a></header><main>',
            'footer.php' => '</main><footer><p><?php bloginfo("name"); ?></p></footer><?php wp_footer(); ?></body></html>',
            'index.php' => '<?php defined("ABSPATH") || exit; get_header(); if(have_posts()): while(have_posts()): the_post(); ?><article><h1><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h1><?php the_content(); ?></article><?php endwhile; the_posts_navigation(); else: ?><p>No content yet.</p><?php endif; get_footer(); ?>',
        ];
    }
    private static function backup(array $w): array
    {
        $active = get_stylesheet();
        $root = self::root($active);
        $manifest = self::files($root);
        $contents = [];
        foreach ($manifest as $path => $info) {
            $bytes = file_get_contents($root . '/' . $path);
            if ($bytes === false || hash('sha256', $bytes) !== $info['hash']) {
                self::fail('The live theme changed while backing up.');
            }$contents[$path] = base64_encode($bytes);
        }
        $backup = ['theme' => $active,'template' => get_template(),'manifest' => $manifest,'files' => $contents,'mods' => get_theme_mods(),'records' => self::records($active)];
        $packed = base64_encode(gzencode(self::json($backup), 6));
        $key = 'aipkit_mcp_theme_backup_' . $w['id'];
        update_option($key, $packed, false);
        if (get_option($key) !== $packed) {
            self::fail('The private theme backup could not be verified.');
        }
        return ['key' => $key,'hash' => hash('sha256', $packed),'theme' => $active,'manifest' => $manifest,'template' => get_template(),'parent_manifest' => self::parent_files($active),'mods_hash' => hash('sha256', self::json(self::mods(get_stylesheet()))), 'records_hash' => hash('sha256', self::json(self::records($active)))];
    }
    /** Tokenization inspects source without including it. No regex parser or new dependency. */
    private static function outline(string $path, string $text): array
    {
        $result = ['path' => $path, 'hash' => hash('sha256', $text), 'supported' => false, 'items' => [], 'truncated' => false];
        if (strtolower(pathinfo($path, PATHINFO_EXTENSION)) !== 'php') {
            return $result + ['message' => 'Structural outlines currently support PHP only. Use theme-read-file or theme-search-files for this file.'];
        }
        $result['supported'] = true;
        $tokens = token_get_all($text);
        $types = [T_FUNCTION => 'function', T_CLASS => 'class', T_INTERFACE => 'interface', T_TRAIT => 'trait', T_NAMESPACE => 'namespace'];
        if (defined('T_ENUM')) { $types[constant('T_ENUM')] = 'enum'; }
        foreach ($tokens as $i => $token) {
            if (!is_array($token)) { continue; }
            $item = null;
            if (isset($types[$token[0]])) {
                $previous = $i - 1;
                while ($previous >= 0 && is_array($tokens[$previous]) && in_array($tokens[$previous][0], [T_WHITESPACE,T_COMMENT,T_DOC_COMMENT], true)) { --$previous; }
                if ($token[0] === T_CLASS && ($tokens[$previous] ?? null) !== null && is_array($tokens[$previous]) && $tokens[$previous][0] === T_DOUBLE_COLON) { continue; }
                $name = '';
                for ($j = $i + 1; $j < count($tokens); ++$j) {
                    $part = $tokens[$j];
                    if (is_array($part) && in_array($part[0], [T_WHITESPACE,T_COMMENT,T_DOC_COMMENT], true)) { continue; }
                    if ($part === '&' || (is_array($part) && $part[1] === '&')) { continue; }
                    if (is_array($part) && ($part[0] === T_STRING || (defined('T_NAME_QUALIFIED') && $part[0] === constant('T_NAME_QUALIFIED')) || $part[0] === T_NS_SEPARATOR)) { $name .= $part[1]; continue; }
                    break;
                }
                if ($name !== '') { $item = ['kind' => $types[$token[0]], 'name' => $name, 'line' => $token[2]]; }
            } elseif ($token[0] === T_STRING && in_array(strtolower($token[1]), ['add_action','add_filter'], true)) {
                $previous = $i - 1;
                while ($previous >= 0 && is_array($tokens[$previous]) && in_array($tokens[$previous][0], [T_WHITESPACE,T_COMMENT,T_DOC_COMMENT], true)) { --$previous; }
                $before = $tokens[$previous] ?? null;
                if (is_array($before) && (in_array($before[0], [T_OBJECT_OPERATOR,T_DOUBLE_COLON,T_FUNCTION], true)
                    || (defined('T_NULLSAFE_OBJECT_OPERATOR') && $before[0] === constant('T_NULLSAFE_OBJECT_OPERATOR')))) { continue; }
                $j = $i + 1;
                while (isset($tokens[$j]) && is_array($tokens[$j]) && in_array($tokens[$j][0], [T_WHITESPACE,T_COMMENT,T_DOC_COMMENT], true)) { ++$j; }
                if (($tokens[$j] ?? null) !== '(') { continue; }
                ++$j;
                while (isset($tokens[$j]) && is_array($tokens[$j]) && $tokens[$j][0] === T_WHITESPACE) { ++$j; }
                $name = $tokens[$j] ?? null;
                if (is_array($name) && $name[0] === T_CONSTANT_ENCAPSED_STRING) {
                    $item = ['kind' => strtolower($token[1]), 'name' => substr($name[1], 1, -1), 'line' => $token[2]];
                }
            }
            if ($item !== null) {
                if (count($result['items']) === 200) { $result['truncated'] = true; break; }
                $item['name'] = mb_substr($item['name'], 0, 200);
                $result['items'][] = $item;
            }
        }
        return $result;
    }

    private static function lock(): void
    {
        global $wpdb;
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Uncached prepared advisory lock serializes workspace operations.
        if ((string)$wpdb->get_var($wpdb->prepare('SELECT GET_LOCK(%s,%d)', 'aipkit_theme_' . substr(hash('sha256', DB_NAME . $wpdb->prefix), 0, 32), 5)) !== '1') {
            self::fail('Another theme operation is running. Try again shortly.');
        }
        self::$locked = true;
    }
    private static function unlock(): void
    {
        if (!self::$locked) {
            return;
        }self::$locked = false;
        global $wpdb;
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Release the same prepared connection lock.
        $wpdb->get_var($wpdb->prepare('SELECT RELEASE_LOCK(%s)', 'aipkit_theme_' . substr(hash('sha256', DB_NAME . $wpdb->prefix), 0, 32)));
    }
    public static function execute(string $action, array $input, bool $preview = false): array
    {
        Operations::$mutation_started = false;
        try {
            if (!self::can($action)) {
                self::fail('Premium theme access and WordPress theme-editing permission are required. Host file-edit restrictions are respected.');
            }
            $read = in_array($action, ['status','list-files','file-outline','read-file','read-backup-file','search-files','preview'], true);
            if (!$read) {
                self::lock();
            }
            $w = self::workspace();
            $result = [];
            if ($action === 'status') {
                $result = self::status();
                $history = get_option('aipkit_mcp_theme_archives', []);
                $result['archives'] = array_slice($history, -20, null, true);
                $result['archive_count'] = count($history);
            } elseif ($action === 'archive') {
                if (!$w || $w['owner'] !== get_current_user_id() || in_array($w['state'], ['live','publishing','rolling_back'], true) || get_stylesheet() === $w['slug'] || get_template() === $w['slug']) {
                    self::fail('Only your inactive draft or completed rollback can be archived.');
                }
                if (!$preview) {
                    $archive = $w;
                    $archive['archived_state'] = $w['state'];
                    $archive['state'] = 'archived';
                    $archive['file_version'] = is_dir(get_theme_root() . '/' . $w['slug']) ? self::files(self::root($w['slug'])) : null;
                    $key = 'aipkit_mcp_theme_archive_' . $w['id'];
                    Operations::$mutation_started = true;
                    update_option($key, $archive, false);
                    if (get_option($key) !== $archive) {
                        self::fail('The archive record could not be verified.');
                    }
                    $history = get_option('aipkit_mcp_theme_archives', []);
                    $history[$w['id']] = ['id' => $w['id'],'theme' => $w['slug'],'owner' => $w['owner']];
                    update_option('aipkit_mcp_theme_archives', $history, false);
                    delete_option(self::OPTION);
                    if (get_option(self::OPTION, false) !== false) {
                        self::fail('The workspace could not be closed; the archive is retained.');
                    }
                    $result = ['archive_id' => $w['id'],'files_deleted' => false,'backup_retained' => isset($w['backup'])];
                }
            } elseif ($action === 'resume') {
                if ($w) {
                    self::fail('Archive your current workspace before resuming another.');
                }
                $archive = get_option('aipkit_mcp_theme_archive_' . $input['archive_id'], []);
                if (!$archive || $archive['owner'] !== get_current_user_id() || $archive['file_version'] === null || self::files(self::root($archive['slug'])) !== $archive['file_version']) {
                    self::fail('The archived files are missing or changed. Nothing was overwritten.');
                }
                if (!$preview) {
                    $archive['state'] = 'draft';
                    unset($archive['file_version'], $archive['archived_state']);
                    Operations::$mutation_started = true;
                    self::store($archive);
                    // The verified workspace now owns this draft and its backup; retire its archive entry.
                    $history = get_option('aipkit_mcp_theme_archives', []);
                    unset($history[$archive['id']]);
                    update_option('aipkit_mcp_theme_archives', $history, false);
                    if (get_option('aipkit_mcp_theme_archives', []) !== $history) {
                        self::fail('The draft resumed, but clearing its archive index could not be confirmed.');
                    }
                    $key = 'aipkit_mcp_theme_archive_' . $archive['id'];
                    delete_option($key);
                    if (get_option($key, false) !== false) {
                        self::fail('The draft resumed, but its old archive record could not be removed.');
                    }
                    $result = self::status();
                }
            } elseif ($action === 'read-backup-file') {
                if (!$w || $w['owner'] !== get_current_user_id() || empty($w['backup'])) {
                    self::fail('This workspace has no theme backup.');
                }
                $packed = get_option($w['backup']['key']);
                if (!is_string($packed) || hash('sha256', $packed) !== $w['backup']['hash']) {
                    self::fail('The backup could not be verified.');
                }
                $backup = json_decode(gzdecode(base64_decode($packed, true)), true);
                $path = $input['path'];
                if (!isset($backup['files'][$path]) || !preg_match('/\.(php|css|js|json|html|txt)$/iD', $path)) {
                    self::fail('Choose a theme text file present in this backup.');
                }
                $content = base64_decode($backup['files'][$path], true);
                if ($content === false || strlen($content) > self::EDIT_LIMIT || !preg_match('//u', $content) || hash('sha256', $content) !== $backup['manifest'][$path]['hash']) {
                    self::fail('This backup file is binary, too large or unverifiable.');
                }
                $result = ['path' => $path,'content' => $content,'hash' => hash('sha256', $content),'source_theme' => $backup['theme'],'live_unchanged' => true];
            } elseif ($action === 'create-draft') {
                if ($w) {
                    self::fail('A workspace already exists. Resume it; creating a draft never replaces unfinished work.');
                }
                if (!current_user_can('install_themes')) {
                    self::fail('WordPress theme installation permission is required.');
                }
                $source = get_stylesheet();
                $source_root = self::root($source);
                $manifest = self::files($source_root);
                $source_records = self::records($source);
                $id = wp_generate_uuid4();
                $slug = 'aipkit-draft-' . substr(str_replace('-', '', $id), 0, 16);
                $base = realpath(get_theme_root());
                // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_is_writable -- Managed local theme workspaces require a writable real path; remote filesystem transports cannot provide atomic replacement.
                if (!$base || !is_writable($base) || file_exists($base . '/' . $slug) || is_link($base . '/' . $slug)) {
                    self::fail('The theme directory is not writable or the draft path already exists.');
                }
                if (!$preview) {
                    $w = ['id' => $id,'slug' => $slug,'state' => 'preparing','owner' => get_current_user_id(),'source' => $source,'source_manifest' => $manifest,'source_parent' => self::parent_files($source),'source_mods_hash' => hash('sha256', self::json(self::mods(get_stylesheet()))), 'source_records_hash' => hash('sha256', self::json($source_records)),'mode' => $input['mode']];
                    self::store($w);
                    Operations::$mutation_started = true;
                    if (!wp_mkdir_p($base . '/' . $slug)) {
                        self::fail('The draft directory could not be created.');
                    }
                    if ($input['mode'] === 'clone') {
                        self::copy($source_root, $base . '/' . $slug, $manifest);
                        self::copy_records($source_records, $source, $slug);
                        if (hash('sha256', self::json(self::records($source))) !== $w['source_records_hash']) {
                            self::fail('The source Site Editor data changed while cloning.');
                        }
                    } else {
                        foreach (self::starter($input['title'] ?? 'My AI Puffer Theme') as $path => $content) {
                            self::atomic($base . '/' . $slug . '/' . $path, $content);
                        }
                    }
                    if ($input['mode'] === 'clone') {
                        $style = file_get_contents($base . '/' . $slug . '/style.css');
                        $style = preg_replace('/^[ \t*]*Theme Name:.*$/m', 'Theme Name: ' . sanitize_text_field($input['title'] ?? 'AI Puffer Draft'), $style);
                        $style = preg_replace('/^[ \t*]*Update URI:.*$/m', 'Update URI: false', $style);
                        if (strpos($style, 'Update URI: false') === false) {
                            $style = "/* Update URI: false */\n" . $style;
                        }
                        self::atomic($base . '/' . $slug . '/style.css', $style);
                    }
                    $mods = $input['mode'] === 'clone' ? get_theme_mods() : [];
                    // A clone must not keep the source theme's custom-CSS post ID.
                    $css = wp_get_custom_css_post($slug);
                    $mods['custom_css_post_id'] = $css ? $css->ID : -1;
                    update_option('theme_mods_' . $slug, $mods, false);
                    $w['state'] = 'draft';
                    self::store($w);
                    wp_clean_themes_cache();
                    if (wp_get_theme($slug)->errors()) {
                        self::fail('WordPress did not recognize the created theme. The incomplete workspace is retained for review.');
                    }
                    $result = self::status();
                }
            } elseif (in_array($action, ['publish','rollback'], true)) {
                if (!$w || $w['owner'] !== get_current_user_id() || !hash_equals(self::version($w), $input['version'])) {
                    self::fail('The workspace changed. Read its status again.');
                }
                if ($action === 'publish') {
                    $w = self::draft();
                    if (($w['preview_version'] ?? '') !== $input['version'] || ($w['previewed_at'] ?? 0) < time() - DAY_IN_SECONDS) {
                        self::fail('Open the preview of this exact draft version before activating it.');
                    }
                    if (get_stylesheet() !== $w['source'] || self::files(self::root($w['source'])) !== $w['source_manifest'] || self::parent_files($w['source']) !== $w['source_parent'] || hash('sha256', self::json(self::mods(get_stylesheet()))) !== $w['source_mods_hash'] || hash('sha256', self::json(self::records($w['source']))) !== $w['source_records_hash']) {
                        self::fail('The original live theme changed. Review the draft against it before publishing.');
                    }
                    foreach (self::files(self::root($w['slug'])) as $path => $info) {
                        if (strtolower(pathinfo($path, PATHINFO_EXTENSION)) === 'php') {
                            try {
                                token_get_all(file_get_contents(self::root($w['slug']) . '/' . $path), TOKEN_PARSE);
                            } catch (\ParseError$error) {
                                self::fail('Invalid PHP in ' . $path . ': ' . $error->getMessage());
                            }
                        }
                    }
                    if (wp_get_theme($w['slug'])->errors()) {
                        self::fail('WordPress considers this theme invalid.');
                    }
                    if (!$preview) {
                        $w['backup'] = self::backup($w);
                        $w['state'] = 'publishing';
                        self::store($w);
                        Operations::$mutation_started = true;
                        switch_theme($w['slug']);
                        if (get_stylesheet() !== $w['slug']) {
                            self::fail('Theme activation could not be confirmed.');
                        }$w['backup']['mods_hash'] = hash('sha256', self::json(self::mods($w['backup']['theme'])));
                        $w['state'] = 'live';
                        self::store($w);
                        $result = self::status();
                    }
                } else {
                    if ($w['state'] !== 'live' || get_stylesheet() !== $w['slug']) {
                        self::fail('Another theme is active. Rollback will not replace that later choice.');
                    }
                    $b = $w['backup'];
                    $packed = get_option($b['key']);
                    if (!is_string($packed) || hash('sha256', $packed) !== $b['hash'] || self::files(self::root($b['theme'])) !== $b['manifest'] || self::parent_files($b['theme']) !== $b['parent_manifest'] || hash('sha256', self::json(self::mods($b['theme']))) !== $b['mods_hash'] || hash('sha256', self::json(self::records($b['theme']))) !== $b['records_hash']) {
                        self::fail('The original theme or backup changed. The backup is retained; automatic rollback will not overwrite later work.');
                    }
                    if (!$preview) {
                        $w['state'] = 'rolling_back';
                        self::store($w);
                        Operations::$mutation_started = true;
                        switch_theme($b['theme']);
                        if (get_stylesheet() !== $b['theme']) {
                            self::fail('Rollback could not be confirmed.');
                        }
                        // Core updates widget bookkeeping during our own switch. Record that completed rollback's
                        // exact source state so a resumed draft remains usable; later user edits still conflict.
                        $w['source_mods_hash'] = hash('sha256', self::json(self::mods($w['source'])));
                        $w['state'] = 'rolled_back';
                        self::store($w);
                        $result = self::status();
                    }
                }
            } else {
                $w = self::draft();
                $root = self::root($w['slug']);
                $files = $action === 'file-outline' ? [] : self::files($root);
                if ($action === 'list-files') {
                    $page = $input['page'] ?? 1;
                    $result = ['files' => array_slice($files, ($page - 1) * 50, 50, true),'page' => $page,'has_more' => count($files) > $page * 50,'version' => self::version($w)];
                } elseif ($action === 'preview') {
                    $result = ['url' => self::native_url($w),'version' => self::version($w),'live_theme' => get_stylesheet(),'draft_theme' => $w['slug'],'scope' => 'Only the logged-in WordPress preview; not a separate PHP process.'];
                } elseif ($action === 'search-files') {
                    $matches = [];
                    $count = 0;
                    $offset = (($input['page'] ?? 1) - 1) * 30;
                    foreach ($files as $path => $info) {
                        if (!preg_match('/\.(php|css|js|json|html|txt)$/iD', $path) || $info['bytes'] > self::EDIT_LIMIT) {
                            continue;
                        }$text = file_get_contents($root . '/' . $path);
                        foreach (explode("\n", $text) as $line => $value) {
                            if (strpos($value, $input['query']) !== false) {
                                if ($count++ >= $offset && count($matches) < 30) {
                                                    $matches[] = ['path' => $path,'line' => $line + 1,'text' => mb_substr($value, 0, 300)];
                                }
                            }
                        }
                    }
                    $result = ['matches' => $matches,'has_more' => $count > $offset + 30];
                } elseif ($action === 'file-outline') {
                    $path = self::path($w, $input['path']);
                    $text = self::text($path);
                    $result = self::outline($input['path'], $text);
                } elseif ($action === 'read-file') {
                    $path = self::path($w, $input['path']);
                    $result = ['path' => $input['path'],'hash' => hash_file('sha256', $path),'content' => self::text($path)];
                } else {
                    $undo = null;
                    $path = $input['path'] ?? '';
                    $expected = $input['expected_hash'] ?? '';
                    $content = $input['content'] ?? null;
                    if ($action === 'undo-file') {
                        $row = Journal::get($input['operation_id']);
                        $args = json_decode($row['args'] ?? '{}', true);
                        $answer = json_decode($row['response'] ?? '{}', true);
                        $data = json_decode($answer['result']['data_json'] ?? '{}', true);
                        if (!$row || $row['state'] !== 'succeeded' || $row['instance_id'] !== (Identity::registration()['instance_id'] ?? '') || ((int)$row['acting_user'] !== get_current_user_id()) || !in_array($args['name'] ?? '', [self::PREFIX . 'write-file',self::PREFIX . 'delete-file'], true) || ($data['workspace'] ?? '') !== $w['id']) {
                                    self::fail('Choose a successful file operation from this workspace and WordPress user.');
                        }
                        $undo = $data['undo'];
                        $path = $data['path'];
                        $expected = $data['hash'];
                        $content = $undo['content'];
                    }
                    $target = self::path($w, $path, true);
                    $exists = is_file($target);
                    $before = $exists ? self::text($target) : null;
                    $actual = $exists ? hash('sha256', $before) : 'new';
                    if ($actual !== $expected) {
                        self::fail('The file changed. Read its current version before editing.');
                    }
                    $delete = $action === 'delete-file' || ($action === 'undo-file' && !$undo['existed']);
                    if ($delete && in_array($path, ['style.css','index.php','templates/index.html'], true)) {
                        self::fail('This theme entry file must remain.');
                    }
                    if (!$delete) {
                        self::validate($path, $content);
                    }
                    if (!$preview) {
                        Operations::$mutation_started = true;
                        if ($delete) {
                            wp_delete_file($target);
                            clearstatcache(true, $target);
                            if (file_exists($target)) {
                                    self::fail('Deletion could not be confirmed.');
                            }wp_clean_themes_cache();
                        } else {
                            self::atomic($target, $content);
                        }
                        $result = ['workspace' => $w['id'],'path' => $path,'hash' => $delete ? 'new' : hash('sha256', $content),'undo' => ['existed' => $exists,'content' => $before],'version' => self::version($w),'live_unchanged' => true];
                    }
                }
            }
            if ($preview && !$read) {
                return['state' => 'pending_approval','actions_used' => 0,'preview' => ['kind' => 'ability','title' => 'Theme workspace change','name' => self::PREFIX . $action,'description' => 'Changes an AI Puffer draft, or activates/restores a theme when explicitly requested.','risk' => 'publish','input' => self::json($input)]];
            }
            return['state' => 'succeeded','actions_used' => 1,'result' => ['data_json' => self::json($result)]];
        } catch (\Throwable$error) {
            return['state' => Operations::$mutation_started ? 'unknown' : 'failed','actions_used' => 0,'error' => ['code' => Operations::$mutation_started ? 'theme_change_unconfirmed' : 'theme_conflict','message' => $error->getMessage()]];
        } finally {
            self::unlock();
        }
    }
}
