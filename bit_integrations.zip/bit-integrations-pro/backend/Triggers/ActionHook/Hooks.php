<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Config;
use BitApps\IntegrationsPro\Core\Util\Hooks;
use BitApps\IntegrationsPro\Triggers\ActionHook\ActionHookController;

$hooks = Config::getOption('action_hook_test_data');

if (!empty($hooks)) {
    foreach ($hooks as $key => $value) {
        Hooks::add($key, [ActionHookController::class, 'actionHookHandler'], 10, PHP_INT_MAX);
    }
}

$storeInCacheClass = bit_integrations_get_class('Core\\Util\\StoreInCache');

if ($storeInCacheClass && bit_integrations_class_and_method_exists('Core\\Util\\StoreInCache', 'getActionHookFlows')) {
    $flows = $storeInCacheClass::getActionHookFlows() ?? [];
} else {
    $flows = [];
}

foreach ($flows as $flow) {
    if (isset($flow->triggered_entity_id)) {
        Hooks::add($flow->triggered_entity_id, [ActionHookController::class, 'handle'], 10, PHP_INT_MAX);
    }
}
