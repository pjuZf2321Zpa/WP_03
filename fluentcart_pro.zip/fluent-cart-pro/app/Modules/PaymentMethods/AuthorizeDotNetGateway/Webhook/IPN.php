<?php

namespace FluentCartPro\App\Modules\PaymentMethods\AuthorizeDotNetGateway\Webhook;

use FluentCartPro\App\Modules\PaymentMethods\AuthorizeDotNetGateway\API\AuthorizeDotNetAPI;
use FluentCartPro\App\Modules\PaymentMethods\AuthorizeDotNetGateway\AuthorizeDotNetHelper;
use FluentCartPro\App\Modules\PaymentMethods\AuthorizeDotNetGateway\AuthorizeDotNetSettings;
use FluentCart\App\Helpers\Status;
use FluentCart\App\Models\OrderTransaction;
use FluentCart\App\Models\Subscription;
use FluentCart\App\Helpers\StatusHelper;
use FluentCart\Framework\Support\Arr;
use FluentCartPro\App\Modules\PaymentMethods\AuthorizeDotNetGateway\AuthorizeDotNetSubscriptions;
use FluentCart\App\Services\Payments\Refund;

class IPN
{
    protected AuthorizeDotNetSettings $settings;
    protected AuthorizeDotNetAPI $api;

    public function __construct(?AuthorizeDotNetSettings $settings = null)
    {
        $this->settings = $settings ?: new AuthorizeDotNetSettings();
        $this->api = new AuthorizeDotNetAPI();
    }

    public function init(): void
    {
        $this->verifyAndProcess();

    }

    public function verifyAndProcess(): void
    {
        if (!isset($_SERVER['REQUEST_METHOD']) || $_SERVER['REQUEST_METHOD'] !== 'POST') {
            return;
        }

        $payload = file_get_contents('php://input');
        if (!$payload) {
            return;
        }

        $reqSignatureKey = $this->getAnetSignatureHeader();
        if (!$reqSignatureKey) {
            return;
        }

        // Remove the 'sha512=' prefix if present
        if (strpos($reqSignatureKey, 'sha512=') === 0) {
            $reqSignatureKey = substr($reqSignatureKey, strlen('sha512='));
        }

        if (!$this->api->validateWebhookSignature($payload, $reqSignatureKey)) {
            $this->sendResponse(400, __('Invalid webhook signature.', 'fluent-cart-pro'));
        }

        $data = json_decode($payload, true);
        if (json_last_error() !== JSON_ERROR_NONE || !is_array($data)) {
            $this->sendResponse(400, __('Invalid webhook payload.', 'fluent-cart-pro'));
        }

        $eventType = Arr::get($data, 'eventType');
        $entity = strtolower((string) Arr::get($data, 'payload.entityName'));

        // Handle subscription events
        if ($entity === 'subscription') {
            $result = $this->handleSubscriptionEvent($data);

            // Authorize.Net redelivers only on a non-2xx. A lifecycle event that could
            // not be reconciled with the remote subscription must not be acknowledged.
            if (is_wp_error($result)) {
                $this->sendResponse(500, __('Webhook processing failed: ', 'fluent-cart-pro') . $result->get_error_message());
            }

            $this->sendResponse(200, __('Webhook processed.', 'fluent-cart-pro'));
            return;
        }

        // Handle transaction events
        if ($entity !== 'transaction') {
            $this->sendResponse(200, __('Webhook ignored. Entity not supported.', 'fluent-cart-pro'));
        }

        switch ($eventType) {
            case 'net.authorize.payment.authcapture.created':
            case 'net.authorize.payment.priorAuthCapture.created':
            case 'net.authorize.payment.capture.created':
                $this->handlePaymentCaptured($data);
                break;
            case 'net.authorize.payment.fraud.approved':
                $this->handleFraudApproved($data);
                break;
            case 'net.authorize.payment.fraud.declined':
            case 'net.authorize.payment.void.created':
                $this->handlePaymentFailed($data, __('Authorize.Net marked the payment as declined/void.', 'fluent-cart-pro'));
                break;
            case 'net.authorize.payment.refund.created':
                $this->handleRefundCreated($data);
                break;
            default:
                // Unhandled event but acknowledged.
                break;
        }

        $this->sendResponse(200, __('Webhook processed.', 'fluent-cart-pro'));
    }

    protected function handlePaymentCaptured(array $payload): void
    {
        $transactionId = Arr::get($payload, 'payload.id');
        if (!$transactionId) {
            return;
        }

        $transactionDetails = $this->getTransactionDetails($transactionId);
        if ($transactionDetails && Arr::get($transactionDetails, 'subscription')) {
            $this->handleSubscriptionPayment($payload, Arr::get($transactionDetails, 'subscription'));
            return;
        }

        // Regular one-time payment
        $transactionModel = OrderTransaction::query()->where('vendor_charge_id', $transactionId)->first()
            ?: $this->adoptChargeAwaitingResponse($transactionDetails, $transactionId);
        if (!$transactionModel) {
            return;
        }

        $alreadySucceeded = $transactionModel->status === Status::TRANSACTION_SUCCEEDED;

        // resolve linked subscription up front so orphan recovery runs even when tx already SUCCEEDED
        $subscriptionModel = $transactionModel->subscription_id
            ? Subscription::query()->where('id', $transactionModel->subscription_id)->first()
            : null;

        if ($transactionModel->subscription_id && !$subscriptionModel) {
            fluent_cart_add_log(
                __('Authorize.Net Payment Captured', 'fluent-cart-pro'),
                sprintf(__('Subscription not found for transaction. Transaction ID: %s', 'fluent-cart-pro'), $transactionId),
                'error',
                [
                    'module_name' => 'order',
                    'module_id'   => $transactionModel->order_id,
                ]
            );
        }

        $order = $transactionModel->order;

        $awaitingPayment = $subscriptionModel && $order
            && $this->maybeActivateSubscription($subscriptionModel, $transactionModel, $order);

        fluent_cart_add_log(
            __('Authorize.Net Payment Captured', 'fluent-cart-pro'),
            sprintf(__('Payment captured via webhook. Transaction ID: %s', 'fluent-cart-pro'), $transactionId),
            'info',
            [
                'module_name' => 'order',
                'module_id'   => $transactionModel->order_id,
            ]
        );

        if (!empty($subscriptionModel)) {
            $subscriptionModel->addLog(
                __('Authorize.Net Payment Captured', 'fluent-cart-pro'),
                sprintf(__('Payment captured via webhook. Transaction ID: %s', 'fluent-cart-pro'), $transactionId)
            );
        }

        if ($alreadySucceeded) {
            // tx already SUCCEEDED locally — only sync order aggregates, skip re-fill/re-dispatch
            (new StatusHelper($transactionModel->order))->syncOrderStatuses($transactionModel);
            return;
        }

        // The webhook payload node carries no submitTimeUTC; the transaction
        // details (already fetched above) do — pass it along so the settlement
        // stamp records the charge time, not this webhook's processing time.
        $successPayload = Arr::get($payload, 'payload', []);
        if ($transactionDetails && Arr::get($transactionDetails, 'submitTimeUTC')) {
            $successPayload['submitTimeUTC'] = Arr::get($transactionDetails, 'submitTimeUTC');
        }

        AuthorizeDotNetHelper::markTransactionSucceeded($transactionModel, $successPayload);

        if ($awaitingPayment) {
            $this->maybeActivateSubscription($subscriptionModel, $transactionModel, $order);
        }
    }

    protected function handleFraudApproved(array $payload): void
    {
        $transactionId = Arr::get($payload, 'payload.id');
        if (!$transactionId) {
            return;
        }

        $transaction = OrderTransaction::query()->where('vendor_charge_id', $transactionId)->first();
        if (!$transaction) {
            $transactionDetails = $this->getTransactionDetails($transactionId);
            $transaction = $this->adoptChargeAwaitingResponse($transactionDetails, $transactionId);
            if (!$transaction) {
                // A held ARB renewal is not recorded until its review concludes, so the
                // approval is the first we hear of it locally.
                $this->recordApprovedRenewal($transactionId, $transactionDetails);
                return;
            }
        }

        fluent_cart_add_log(
            __('Authorize.Net Fraud Approved', 'fluent-cart-pro'),
            sprintf(__('Fraud approved via webhook. Transaction ID: %s', 'fluent-cart-pro'), $transactionId),
            'info',
            [
                'module_name' => 'order',
                'module_id'   => $transaction->order_id,
            ]
        );

        $subscription = $transaction->subscription_id
            ? Subscription::query()->find($transaction->subscription_id)
            : null;

        if ($subscription) {
            $subscription->addLog(
                __('Authorize.Net Fraud Approved', 'fluent-cart-pro'),
                sprintf(__('Fraud approved via webhook. Transaction ID: %s', 'fluent-cart-pro'), $transactionId)
            );

            $order = $transaction->order;
            $awaitingPayment = $order && $this->maybeActivateSubscription($subscription, $transaction, $order);
        }

        AuthorizeDotNetHelper::markTransactionSucceeded($transaction, Arr::get($payload, 'payload', []));

        if (!empty($awaitingPayment)) {
            $this->maybeActivateSubscription($subscription, $transaction, $order);
        }
    }

    protected function handlePaymentFailed(array $payload, string $reason): void
    {
        $transactionId = Arr::get($payload, 'payload.id');
        if (!$transactionId) {
            return;
        }

        $transaction = OrderTransaction::query()->where('vendor_charge_id', $transactionId)->first();
        if (!$transaction) {
            return;
        }

        fluent_cart_add_log(
            __('Authorize.Net Payment Failed', 'fluent-cart-pro'),
            sprintf(__('Payment failed via webhook. Transaction ID: %s', 'fluent-cart-pro'), $transactionId),
            'info',
            [
                'module_name' => 'order',
                'module_id'   => $transaction->order_id,
            ]
        );

        if ($transaction->subscription_id) {
            $subscription = Subscription::query()->find($transaction->subscription_id);
            if ($subscription) {
                $subscription->addLog(
                    __('Authorize.Net Payment Failed', 'fluent-cart-pro'),
                    sprintf(__('Payment failed via webhook. Transaction ID: %s', 'fluent-cart-pro'), $transactionId)
                );
            }
        }

        AuthorizeDotNetHelper::markTransactionFailed($transaction, $reason, Arr::get($payload, 'payload', []));
    }

    protected function handleRefundCreated(array $payload): void
    {
        $vendorChargeId = Arr::get($payload, 'payload.id');
        if (!$vendorChargeId) {
            return;
        }

        // The refund.created payload usually carries no refTransId; the transaction details name the parent charge.
        $refTransId = Arr::get($payload, 'payload.refTransId');
        if (!$refTransId) {
            $transactionDetails = $this->fetchTransactionDetails($vendorChargeId);
            if (is_wp_error($transactionDetails)) {
                if ($this->isRetryableLookupError($transactionDetails)) {
                    $this->sendResponse(503, __('Could not fetch the refund details from Authorize.Net.', 'fluent-cart-pro'));
                    return;
                }

                $alreadyRecorded = OrderTransaction::query()
                    ->where('vendor_charge_id', $vendorChargeId)
                    ->where('transaction_type', Status::TRANSACTION_TYPE_REFUND)
                    ->exists();
                if ($alreadyRecorded) {
                    return;
                }

                // A refusal (e.g. Transaction Details API disabled) repeats on every redelivery, so log it and acknowledge.
                fluent_cart_add_log(
                    __('Authorize.Net Refund Not Recorded', 'fluent-cart-pro'),
                    sprintf(
                        __('Refund %1$s could not be looked up: %2$s', 'fluent-cart-pro'),
                        $vendorChargeId,
                        $transactionDetails->get_error_message()
                    ),
                    'error'
                );
                return;
            }
            $refTransId = Arr::get($transactionDetails, 'refTransId');
        }

        // An unlinked credit has no parent charge to record against.
        if (!$refTransId) {
            return;
        }

        // Get parent transaction
        $parentTransaction = OrderTransaction::query()
            ->where('vendor_charge_id', $refTransId)
            ->where('transaction_type', Status::TRANSACTION_TYPE_CHARGE)
            ->where('status', Status::TRANSACTION_SUCCEEDED)
            ->first();

        if (!$parentTransaction) {
            return;
        }

        $order = $parentTransaction->order;
        if (!$order) {
            return;
        }

        $amount = (float) Arr::get($payload, 'payload.authAmount', 0);
        $amountInMinor = (int) round($amount * 100);

        // Prepare refund data matching FluentCart pattern
        $refundData = [
            'order_id'           => $order->id,
            'transaction_type'   => Status::TRANSACTION_TYPE_REFUND,
            'status'             => Status::TRANSACTION_REFUNDED,
            'payment_method'     => 'authorize_dot_net',
            'payment_mode'       => $parentTransaction->payment_mode,
            'vendor_charge_id'   => $vendorChargeId,
            'total'              => $amountInMinor,
            'currency'           => $parentTransaction->currency,
            'meta'               => [
                'parent_id'      => $parentTransaction->id,
                'authnet'        => Arr::get($payload, 'payload', []),
                'refund_source'  => 'webhook'
            ]
        ];

        $recordedRefund = Refund::createOrRecordRefund($refundData, $parentTransaction);

        if (is_wp_error($recordedRefund) && $recordedRefund->get_error_code() === 'refund_lock_timeout') {
            $this->sendResponse(503, $recordedRefund->get_error_message());
        }
    }

    /**
     * @return \WP_Error|null WP_Error when the remote subscription could not be pulled
     */
    protected function handleSubscriptionEvent(array $payload)
    {
        $eventType = Arr::get($payload, 'eventType');
        $subscriptionId = Arr::get($payload, 'payload.id');

        if (!$subscriptionId) {
            return null;
        }

        $subscription = Subscription::query()
            ->where('vendor_subscription_id', $subscriptionId)
            ->where('current_payment_method', 'authorize_dot_net')
            ->first();

        if (!$subscription) {
            return null;
        }

        switch ($eventType) {
            case 'net.authorize.customer.subscription.cancelled':
                $this->handleSubscriptionCancelled($subscription, $payload);
                return null;
            case 'net.authorize.customer.subscription.terminated':
                // Authorize.Net ends a subscription it suspended and the merchant never
                // repaired. Nothing will be billed again, so treat it as a cancellation,
                // then pull the final declined attempt. The cancellation is idempotent,
                // so a redelivery after a failed pull is safe.
                $this->handleSubscriptionCancelled($subscription, $payload, __('Terminated by Authorize.Net after a suspended payment was not resolved.', 'fluent-cart-pro'));
                return $this->resyncFromSubscriptionEvent($subscription, $payload, __('Authorize.Net Subscription Terminated', 'fluent-cart-pro'));
            case 'net.authorize.customer.subscription.expired':
                return $this->resyncFromSubscriptionEvent($subscription, $payload, __('Authorize.Net Subscription Expired', 'fluent-cart-pro'));
            case 'net.authorize.customer.subscription.expiring':
                return $this->resyncFromSubscriptionEvent($subscription, $payload, __('Authorize.Net Subscription Expiring', 'fluent-cart-pro'));
            case 'net.authorize.customer.subscription.suspended':
                return $this->resyncFromSubscriptionEvent($subscription, $payload, __('Authorize.Net Subscription Suspended', 'fluent-cart-pro'));
            case 'net.authorize.customer.subscription.failed':
                return $this->resyncFromSubscriptionEvent($subscription, $payload, __('Authorize.Net Subscription Payment Failed', 'fluent-cart-pro'));
            case 'net.authorize.customer.subscription.updated':
                return $this->resyncFromSubscriptionEvent($subscription, $payload, __('Authorize.Net Subscription Updated', 'fluent-cart-pro'));
            default:
                return null;
        }
    }

    /**
     * Every subscription lifecycle event carries only the ARB id and its new status;
     * the remote subscription, with its transaction list, is the source of truth.
     *
     * @return \WP_Error|null WP_Error when the pull failed and the event must be redelivered
     */
    protected function resyncFromSubscriptionEvent(Subscription $subscription, array $payload, string $title)
    {
        $orderId = $subscription->parent_order_id;
        if (!$orderId) {
            return null;
        }

        $message = sprintf(
            __('%1$s via webhook. Subscription ID: %2$s', 'fluent-cart-pro'),
            Arr::get($payload, 'eventType'),
            Arr::get($payload, 'payload.id')
        );

        fluent_cart_add_log($title, $message, 'info', [
            'module_name' => 'order',
            'module_id'   => $orderId,
        ]);

        $subscription->addLog($title, $message);

        $result = (new AuthorizeDotNetSubscriptions($this->settings))->reSyncSubscriptionFromRemote($subscription);

        if (is_wp_error($result)) {
            fluent_cart_add_log($title, sprintf(
                __('Could not pull the subscription from Authorize.Net: %s', 'fluent-cart-pro'),
                $result->get_error_message()
            ), 'error', [
                'module_name' => 'order',
                'module_id'   => $orderId,
            ]);

            return $result;
        }

        return null;
    }

    protected function recordApprovedRenewal(string $transactionId, ?array $transactionDetails): void
    {
        $vendorSubscriptionId = $transactionDetails ? Arr::get($transactionDetails, 'subscription.id') : null;

        if (!$vendorSubscriptionId) {
            return;
        }

        $subscription = Subscription::query()
            ->where('vendor_subscription_id', $vendorSubscriptionId)
            ->where('current_payment_method', 'authorize_dot_net')
            ->first();

        if (!$subscription) {
            return;
        }

        $subscription->addLog(
            __('Authorize.Net Fraud Approved', 'fluent-cart-pro'),
            sprintf(__('Held renewal payment approved via webhook. Transaction ID: %s', 'fluent-cart-pro'), $transactionId)
        );

        (new AuthorizeDotNetSubscriptions($this->settings))->recordApprovedRenewalTransaction($subscription, $transactionDetails);
    }

    protected function handleSubscriptionPayment(array $payload, $authSubscriptionData): void
    {
        $vendorSubscriptionId = Arr::get($authSubscriptionData, 'id');

        if (!$vendorSubscriptionId) {
            return;
        }

        $subscription = Subscription::query()
            ->where('vendor_subscription_id', $vendorSubscriptionId)
            ->where('current_payment_method', 'authorize_dot_net')
            ->first();

        if (!$subscription) {
            return;
        }

        $orderId = $subscription->parent_order_id;

        fluent_cart_add_log(
            __('Authorize.Net Subscription Payment', 'fluent-cart-pro'),
            sprintf(__('Subscription payment via webhook. Subscription ID: %s', 'fluent-cart-pro'), Arr::get($payload, 'payload.id')),
            'info',
            [
                'module_name' => 'order',
                'module_id'   => $orderId,
            ]
        );

        $subscription->addLog(
            __('Authorize.Net Subscription Payment', 'fluent-cart-pro'),
            sprintf(__('Subscription payment via webhook. Subscription ID: %s', 'fluent-cart-pro'), Arr::get($payload, 'payload.id'))
        );

        (new AuthorizeDotNetSubscriptions($this->settings))->reSyncSubscriptionFromRemote($subscription);

    }

    protected function getTransactionDetails(string $transactionId): ?array
    {
        return $this->api->getTransactionDetails($transactionId);
    }

    /**
     * @return array|\WP_Error
     */
    protected function fetchTransactionDetails(string $transactionId)
    {
        return $this->api->fetchTransactionDetails($transactionId);
    }

    // E00001 (try again) and E00104 (maintenance) come back as errors on HTTP 200.
    private function isRetryableLookupError(\WP_Error $error): bool
    {
        if ($error->get_error_code() !== 'authnet_error') {
            return true;
        }

        $response = (array) $error->get_error_data();
        if (!Arr::get($response, 'messages.resultCode')) {
            return true;
        }

        return in_array(Arr::get($response, 'messages.message.0.code'), ['E00001', 'E00104'], true);
    }

    /**
     * A charge whose createTransaction response never reached us has no vendor id, so
     * the id lookup misses. Match it back through the PO number stamped on the request.
     * A second succeeded charge on the same order means the customer paid twice; that is
     * flagged for review rather than recorded as a payment.
     */
    protected function adoptChargeAwaitingResponse(?array $details, string $transactionId): ?OrderTransaction
    {
        if (!$details) {
            return null;
        }

        $transaction = $this->findChargeAwaitingResponse($details);
        if (!$transaction) {
            return null;
        }

        $conflicting = OrderTransaction::query()
            ->where('order_id', $transaction->order_id)
            ->where('transaction_type', Status::TRANSACTION_TYPE_CHARGE)
            ->where('status', Status::TRANSACTION_SUCCEEDED)
            ->where('id', '!=', $transaction->id)
            ->first();

        if ($conflicting) {
            $this->flagConflictingCharge($transaction, $transactionId, (string) $conflicting->vendor_charge_id);
            return null;
        }

        // Claim the row before anything downstream runs. Two deliveries (a retry, or
        // capture and fraud.approved together) can both select this transaction; the
        // conditional update lets exactly one of them own it.
        $claimed = OrderTransaction::query()
            ->where('id', $transaction->id)
            ->where('vendor_charge_id', '')
            ->update(['vendor_charge_id' => $transactionId]);

        if ($claimed !== 1) {
            $transaction = OrderTransaction::query()->find($transaction->id);
            if ($transaction && $transaction->vendor_charge_id !== $transactionId) {
                $this->flagConflictingCharge($transaction, $transactionId, $transaction->vendor_charge_id);
            }
            return null;
        }

        $transaction = OrderTransaction::query()->find($transaction->id);

        // Subscription activation binds the ARB schedule to the profile that paid.
        $profile = Arr::get($details, 'profile', []);
        if (Arr::get($profile, 'customerProfileId') && Arr::get($profile, 'customerPaymentProfileId')) {
            $transaction->fill([
                'meta' => array_merge($transaction->meta ?? [], [
                    'authnet_customer_profile_id' => (string) Arr::get($profile, 'customerProfileId'),
                    'authnet_payment_profile_id'  => (string) Arr::get($profile, 'customerPaymentProfileId'),
                ]),
            ]);
            $transaction->save();
        }

        fluent_cart_add_log(
            __('Authorize.Net Payment Captured', 'fluent-cart-pro'),
            sprintf(__('Matched transaction %s to a charge whose response was lost.', 'fluent-cart-pro'), $transactionId),
            'info',
            [
                'module_name' => 'order',
                'module_id'   => $transaction->order_id,
            ]
        );

        return $transaction;
    }

    protected function findChargeAwaitingResponse(array $details): ?OrderTransaction
    {
        return AuthorizeDotNetHelper::findChargeAwaitingResponse($details);
    }

    protected function flagConflictingCharge(OrderTransaction $transaction, string $transactionId, string $paidBy): void
    {
        $transaction->fill([
            'meta' => array_merge($transaction->meta ?? [], [
                'authnet_conflicting_charge_id' => $transactionId,
            ]),
        ]);
        $transaction->save();

        fluent_cart_add_log(
            __('Authorize.Net Duplicate Charge', 'fluent-cart-pro'),
            sprintf(
                __('Authorize.Net transaction %1$s matches this order, but it was already paid by transaction %2$s. Review and refund the extra charge.', 'fluent-cart-pro'),
                $transactionId,
                $paidBy
            ),
            'error',
            [
                'module_name' => 'order',
                'module_id'   => $transaction->order_id,
            ]
        );
    }

    protected function handleSubscriptionCancelled(Subscription $subscription, array $payload, string $reason = ''): void
    {
        // Skip if already canceled/completed/expired
        if ($subscription->status === Status::SUBSCRIPTION_CANCELED || $subscription->status === Status::SUBSCRIPTION_EXPIRED || $subscription->status === Status::SUBSCRIPTION_COMPLETED) {
            return;
        }

        fluent_cart_add_log(
            __('Authorize.Net Subscription Cancelled', 'fluent-cart-pro'),
            sprintf(__('Subscription cancelled via webhook. Subscription ID: %s', 'fluent-cart-pro'), Arr::get($payload, 'payload.id')),
            'info',
            [
                'module_name' => 'order',
                'module_id'   => $subscription->parent_order_id,
            ]
        );

        $subscription->addLog(
            __('Authorize.Net Subscription Cancelled', 'fluent-cart-pro'),
            sprintf(__('Subscription cancelled via webhook. Subscription ID: %s', 'fluent-cart-pro'), Arr::get($payload, 'payload.id'))
        );

        // Update subscription status directly
        $subscription->status = Status::SUBSCRIPTION_CANCELED;
        $subscription->canceled_at = gmdate('Y-m-d H:i:s');
        $subscription->save();

        // Fire subscription_canceled event
        (new \FluentCart\App\Events\Subscription\SubscriptionCanceled(
            $subscription,
            $subscription->order,
            $subscription->customer,
            $reason ?: __('Canceled via Authorize.Net webhook', 'fluent-cart-pro')
        ))->dispatch();
    }


    /**
     * @return bool true when activation waits for this payment to be marked paid
     */
    protected function maybeActivateSubscription(Subscription $subscriptionModel, OrderTransaction $transactionModel, $order): bool
    {
        $isNewSubPending  = AuthorizeDotNetSubscriptions::isAwaitingFirstActivation($subscriptionModel);
        $isRenewalPending = AuthorizeDotNetSubscriptions::isAwaitingReactivation($subscriptionModel, $order);

        if (!$isNewSubPending && !$isRenewalPending) {
            return false;
        }

        // Transient lock — prevents duplicate ARB creation if webhooks arrive concurrently.
        // Auth.Net itself also deduplicates ARB requests, but this avoids the extra API round-trip.
        $lockKey = 'authnet_activation_lock_' . $subscriptionModel->id;
        if (get_transient($lockKey)) {
            return false;
        }
        set_transient($lockKey, 1, 60);

        try {
            $activated = (new AuthorizeDotNetSubscriptions($this->settings))
                ->activateSubscriptionAfterPayment($subscriptionModel, $transactionModel);

            if ($activated === null) {
                return true;
            }

            if (!$activated) {
                // Likely E00040 replication lag — flag for the five-minute sweep to retry
                AuthorizeDotNetSubscriptions::deferSubscriptionCreation($subscriptionModel);
                return false;
            }

            if (!$isRenewalPending) {
                return false;
            }

            // Cancel old ARB subscription, dispatch reactivation event, sync price change —
            // shared with the background ARB retry sweep so a renewal activated later gets
            // the same housekeeping as one activated immediately.
            (new AuthorizeDotNetSubscriptions($this->settings))->completeReactivation($subscriptionModel, $order);
            return false;
        } finally {
            delete_transient($lockKey);
        }
    }

    protected function getAnetSignatureHeader(): ?string
    {
        if (function_exists('getallheaders')) {
            $headers = array_change_key_case(getallheaders(), CASE_LOWER);
            return $headers['x-anet-signature'] ?? null;
        }

        if (isset($_SERVER['HTTP_X_ANET_SIGNATURE'])) {
            return $_SERVER['HTTP_X_ANET_SIGNATURE'];
        }

        return null;
    }

    protected function sendResponse(int $code, string $message): void
    {
        status_header($code);
        echo wp_json_encode(['message' => $message]);
        exit;
    }
}
