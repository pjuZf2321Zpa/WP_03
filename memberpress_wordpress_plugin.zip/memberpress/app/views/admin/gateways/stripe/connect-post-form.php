<?php
/**
 * Auto-submitting form that posts the Stripe Connect JWT in the request body.
 *
 * @var string $action_url The service connect endpoint.
 * @var string $jwt        The signed connect token.
 */

if (!defined('ABSPATH')) {
    die('You are not allowed to call this page directly.');
}
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="noindex, nofollow">
    <title><?php esc_html_e('Connecting to Stripe…', 'memberpress'); ?></title>
</head>
<body>
    <form id="mepr-stripe-connect-form" method="post" action="<?php echo esc_url($action_url); ?>">
        <input type="hidden" name="jwt" value="<?php echo esc_attr($jwt); ?>">
        <noscript>
            <p><?php esc_html_e('Click the button below to finish connecting your Stripe account.', 'memberpress'); ?></p>
            <button type="submit"><?php esc_html_e('Continue to Stripe', 'memberpress'); ?></button>
        </noscript>
    </form>
    <script>document.getElementById('mepr-stripe-connect-form').submit();</script>
</body>
</html>
