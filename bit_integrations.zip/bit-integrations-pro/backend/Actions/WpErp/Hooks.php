<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Actions\WpErp\WpErpProHelper;
use BitApps\IntegrationsPro\Config;
use BitApps\IntegrationsPro\Core\Util\Hooks;

Hooks::filter(Config::withFreePrefix('wperp_create_contact'), [WpErpProHelper::class, 'createContact'], 10, 3);
Hooks::filter(Config::withFreePrefix('wperp_update_contact'), [WpErpProHelper::class, 'updateContact'], 10, 3);
Hooks::filter(Config::withFreePrefix('wperp_create_company'), [WpErpProHelper::class, 'createCompany'], 10, 2);
Hooks::filter(Config::withFreePrefix('wperp_update_company'), [WpErpProHelper::class, 'updateCompany'], 10, 3);
Hooks::filter(Config::withFreePrefix('wperp_create_contact_group'), [WpErpProHelper::class, 'createContactGroup'], 10, 2);
Hooks::filter(Config::withFreePrefix('wperp_add_contact_to_group'), [WpErpProHelper::class, 'addContactToGroup'], 10, 3);
Hooks::filter(Config::withFreePrefix('wperp_remove_contact_from_group'), [WpErpProHelper::class, 'removeContactFromGroup'], 10, 3);
Hooks::filter(Config::withFreePrefix('wperp_add_note'), [WpErpProHelper::class, 'addNote'], 10, 2);
Hooks::filter(Config::withFreePrefix('wperp_create_task'), [WpErpProHelper::class, 'createTask'], 10, 3);
Hooks::filter(Config::withFreePrefix('wperp_create_department'), [WpErpProHelper::class, 'createDepartment'], 10, 2);
Hooks::filter(Config::withFreePrefix('wperp_create_designation'), [WpErpProHelper::class, 'createDesignation'], 10, 2);
Hooks::filter(Config::withFreePrefix('wperp_create_holiday'), [WpErpProHelper::class, 'createHoliday'], 10, 3);
Hooks::filter(Config::withFreePrefix('wperp_create_expense'), [WpErpProHelper::class, 'createExpense'], 10, 3);
Hooks::filter(Config::withFreePrefix('wperp_create_payment'), [WpErpProHelper::class, 'createPayment'], 10, 2);
