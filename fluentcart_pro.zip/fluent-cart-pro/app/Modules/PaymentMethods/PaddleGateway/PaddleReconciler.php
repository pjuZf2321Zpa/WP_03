<?php

namespace FluentCartPro\App\Modules\PaymentMethods\PaddleGateway;

use FluentCart\App\Helpers\CurrenciesHelper;
use FluentCart\App\Helpers\Status;
use FluentCart\App\Models\Order;
use FluentCart\App\Models\OrderTransaction;
use FluentCart\Framework\Support\Arr;
use FluentCartPro\App\Modules\PaymentMethods\PaddleGateway\API\API;

/**
 * Unified Merchant-of-Record payment reconciliation.
 *
 * A MoR gateway (Paddle) owns tax and currency end-to-end. FluentCart's tax module
 * is OFF for Paddle, so an order is created with total_amount = catalog price in the
 * order currency and tax_total = 0. The amount the gateway actually captures can then
 * diverge from the order, and StatusHelper::syncOrderStatuses (paid iff
 * order.total_amount <= Σ succeeded transactions) mis-judges the order — leaving it
 * on-hold/pending with no fulfillment even though the buyer paid.
 *
 * reconcile() is the single entry point. It splits on currency FIRST, because that
 * decides whether a divergence is even interpretable:
 *
 *   - Same currency: a divergence is explainable. captured > order is tax-excluded
 *     (gateway added tax on top); captured < order is reverse charge (gateway removed
 *     VAT for a validated B2B buyer). Each is VERIFIED against the charge's tax fields.
 *     Tax-excluded RAISES order.total_amount (atomically, WHERE-guarded) — the extra is
 *     absorbed into tax_total, a separate column, so subtotal/tax/total stay consistent.
 *     Reverse charge does NOT lower order.total_amount — there is no separate column to
 *     absorb the difference into (tax_total is already 0), so lowering total_amount alone
 *     would desync it from order.subtotal/items with nothing to explain the gap on the
 *     receipt. Instead it's a pure cover: txn.total stays = order.total_amount, the real
 *     captured net lives in meta.paddle_captured, and the removed VAT + reverse-charge
 *     flag are written to business_info for display (see recordValidatedBuyerVatNumber
 *     and TaxSummaryHelper's business_info fallback for the no-orderTaxRate-row case).
 *   - Cross currency: amounts are not comparable (no order->buyer FX rate exists on the
 *     transaction), so the order is recorded as covered in its own currency and the
 *     captured/FX figures are preserved in meta. Never adjusted, either direction.
 *
 * Reporting note: order.total_amount tracks the real captured amount only for
 * same-currency tax-excluded orders (raised); reverse-charge and cross-currency orders
 * keep catalog price in the order currency. Authoritative captured/removed-VAT/FX
 * figures always live on the transaction meta + business_info + in Paddle.
 *
 * The reconciler does NOT write the transaction row — it returns the amount/currency
 * to persist and the meta to merge, leaving the caller's single transaction save as
 * the only writer of that row.
 *
 * @see CapturedCharge for the gateway-agnostic struct the core reasons against.
 */
class PaddleReconciler
{
    /**
     * Rounding tolerance (minor units) when verifying internal totals identities.
     */
    const VERIFY_TOLERANCE = 2;

    /**
     * @param OrderTransaction $transaction The local charge transaction (pending, or already succeeded on re-entry).
     * @param array            $charge      Paddle transaction object (API/webhook shape).
     * @param Order            $order       The order being paid.
     *
     * @return array{status:string, amount:int, currency:string, changed:bool, meta:array}
     */
    public static function reconcile(OrderTransaction $transaction, $charge, Order $order): array
    {
        $captured      = CapturedCharge::fromPaddle($charge);
        $orderCurrency = strtoupper((string) $order->currency);

        // An absent charged currency cannot prove an FX localization, so it is treated
        // as same-currency: the same-currency route still verifies tax fields before
        // mutating anything, so a malformed charge cannot silently move money.
        if (!$captured->currency || $captured->currency === $orderCurrency) {
            return self::sameCurrencyReconcile($transaction, $captured, $charge, $order);
        }

        return self::crossCurrencyReconcile($transaction, $captured, $charge, $order);
    }

    /**
     * Convenience entry for paths that have a succeeded transaction but no live charge
     * (admin self-heal, already-succeeded webhook). Rebuilds a minimal charge from the
     * stored meta (paddle_totals / paddle_payout_totals) and reconciles. Idempotent.
     */
    public static function reconcileFromTransaction(OrderTransaction $transaction, ?Order $order = null): array
    {
        if (!$order) {
            $order = $transaction->order;
        }

        $meta         = (array) ($transaction->meta ?? []);
        $paddleTotals = (array) Arr::get($meta, 'paddle_totals', []);

        $charge = [
            'currency_code' => Arr::get($paddleTotals, 'currency_code', ''),
            'details'       => [
                'totals'        => $paddleTotals,
                'payout_totals' => (array) Arr::get($meta, 'paddle_payout_totals', []),
            ],
        ];

        return self::reconcile($transaction, $charge, $order);
    }

    /**
     * Same-currency route: divergence is interpretable.
     */
    protected static function sameCurrencyReconcile(OrderTransaction $transaction, CapturedCharge $captured, $charge, Order $order): array
    {
        $orderTotal = (int) $order->total_amount;
        $currency   = $captured->currency ?: strtoupper((string) $order->currency);

        // A non-positive captured total is not proof of payment — never act on it.
        if ($captured->total <= 0) {
            return self::result('skipped', $orderTotal, strtoupper((string) $order->currency), false);
        }

        if ($captured->total === $orderTotal) {
            return self::result('match', $captured->total, $currency, false, ['mor_covered' => true]);
        }

        if ($captured->total > $orderTotal) {
            return self::applyTaxExcluded($transaction, $captured, $order);
        }

        return self::coverReverseCharge($transaction, $captured, $charge, $order);
    }

    /**
     * Over-pay: candidate tax-excluded account (Paddle added tax on top of the price).
     * Verified currency-independently: the extra paid must equal the charge's tax, and
     * the charge's own totals identity (subtotal - discount + tax == total) must hold.
     *
     * Cover approach: order.total_amount and tax_total are raised by the tax amount so
     * that txn.total = order.total_amount (cover invariant). This keeps total_paid ==
     * total_amount in StatusHelper with no filter, and sets the correct refund ceiling:
     * min(paddle_captured, order.total_amount) = captured (admin can refund full amount
     * including tax). Atomic WHERE-guard prevents double-raise on concurrent entries.
     */
    protected static function applyTaxExcluded(OrderTransaction $transaction, CapturedCharge $captured, Order $order): array
    {
        $orderTotal = (int) $order->total_amount;
        $tax        = (int) $captured->tax;
        $currency   = $captured->currency ?: strtoupper((string) $order->currency);
        $extra      = $captured->total - $orderTotal;

        $verified = $tax > 0
            && abs($extra - $tax) <= self::VERIFY_TOLERANCE
            && abs(($captured->subtotal - $captured->discount + $captured->tax) - $captured->total) <= self::VERIFY_TOLERANCE;

        if (!$verified) {
            if (self::isFresh($transaction)) {
                fluent_cart_add_log(
                    __('Paddle reconciliation anomaly (unexplained over-payment)', 'fluent-cart-pro'),
                    sprintf(
                        /* translators: %1$s: captured total, %2$s: order total, %3$s: currency */
                        __('Paddle captured %1$s %3$s against an order total of %2$s %3$s, but the extra amount does not match the charge tax. Recorded as captured for review; the order total was not changed.', 'fluent-cart-pro'),
                        self::logAmount($captured->total, $currency),
                        self::logAmount($orderTotal, $currency),
                        $currency
                    ),
                    'error',
                    ['module_name' => 'order', 'module_id' => $order->id]
                );
            }
            return self::result('overpay_unverified', $captured->total, $currency, false, self::capturedMeta($captured));
        }

        // Raise order atomically — WHERE total_amount = $orderTotal ensures only one
        // concurrent request applies the tax (the other will see order already raised
        // and take the match path on re-entry).
        $raised = $orderTotal + $tax;
        Order::query()
            ->where('id', $order->id)
            ->where('total_amount', $orderTotal)
            ->update(['total_amount' => $raised, 'tax_total' => $tax]);
        $order->total_amount = $raised;
        $order->tax_total    = $tax;

        if (self::isFresh($transaction)) {
            fluent_cart_add_log(
                __('Paddle tax-excluded payment', 'fluent-cart-pro'),
                sprintf(
                    /* translators: %1$s: tax amount, %2$s: captured total, %3$s: order total, %4$s: currency */
                    __('Paddle (Merchant of Record) added %1$s %4$s tax on top of the %3$s %4$s price and captured %2$s %4$s. The order total has been raised to match the captured amount.', 'fluent-cart-pro'),
                    self::logAmount($tax, $currency),
                    self::logAmount($captured->total, $currency),
                    self::logAmount($orderTotal, $currency),
                    $currency
                ),
                'info',
                ['module_name' => 'order', 'module_id' => $order->id]
            );
        }

        return self::result('tax_excluded', $raised, $currency, true,
            array_merge(self::capturedMeta($captured), ['mor_covered' => true]));
    }

    /**
     * Under-pay: candidate EU reverse charge (Paddle removed VAT for a validated B2B
     * buyer). Verified by identity, not by the shortfall's shape: the charge must
     * carry no tax and no non-zero applied rate, AND match the checkout identity
     * (see chargeMatchesExpectedItems / chargeDiscountMatchesExpected).
     *
     * Representation = cover, same as every other verified path: order.total_amount is
     * NEVER lowered (would desync from order.subtotal/items with no tax/discount line
     * to explain the gap — order.tax_total is already 0 here, there is nothing to absorb
     * it into). txn.total stays = order.total_amount; the real captured net lives in
     * meta.paddle_captured. The removed VAT and validated business identity are written
     * to business_info (reverse_charge_applied, mor_vat_removed) so display layers that have
     * no orderTaxRate row to read (no MoR gateway runs the tax module) can still show the
     * reverse-charge total via a business_info fallback — see TaxSummaryHelper.
     */
    protected static function coverReverseCharge(OrderTransaction $transaction, CapturedCharge $captured, $charge, Order $order): array
    {
        $orderTotal    = (int) $order->total_amount;
        $orderCurrency = strtoupper((string) $order->currency);

        $isReverseCharge = $captured->tax === 0 && self::taxRatesAreZeroOrEmpty($captured->taxRatesUsed);

        // A charge with no live line items (rebuilt from stored totals on re-entry)
        // is trusted only when this reconciler previously verified it — i.e. the
        // transaction already carries the reverse_charge meta flag.
        $identityVerified = (self::chargeMatchesExpectedItems($charge, $transaction)
                && self::chargeDiscountMatchesExpected($charge, $transaction))
            || !empty(Arr::get((array) ($transaction->meta ?? []), 'reverse_charge'));

        $structurallyVerified = $isReverseCharge
            && $identityVerified
            && (self::isFresh($transaction) ? self::chargeCoversOrder($charge, $order) : true);

        if (!$structurallyVerified) {
            if (self::isFresh($transaction)) {
                fluent_cart_add_log(
                    __('Paddle reconciliation skipped (unexplained under-payment)', 'fluent-cart-pro'),
                    sprintf(
                        /* translators: %1$s: captured total, %2$s: order total, %3$s: currency */
                        __('Paddle captured %1$s %3$s against an order total of %2$s %3$s, but the shortfall is not a verified reverse charge or the charge did not match this order. Please verify the order against the Paddle transaction.', 'fluent-cart-pro'),
                        self::logAmount($captured->total, $orderCurrency),
                        self::logAmount($orderTotal, $orderCurrency),
                        $orderCurrency
                    ),
                    'error',
                    ['module_name' => 'order', 'module_id' => $order->id]
                );
            }
            return self::result('underpay_unverified', $captured->total, $orderCurrency, false, self::capturedMeta($captured));
        }

        $vatRemoved = $orderTotal - $captured->total;

        $meta = array_merge(self::capturedMeta($captured), [
            'mor_covered'    => true,
            'reverse_charge' => true,
            'mor_vat_removed' => $vatRemoved,
        ]);

        if ($captured->businessId !== '') {
            $meta['paddle_business_id'] = $captured->businessId;
        }

        self::recordValidatedBuyerVatNumber($transaction, $order, $captured, $vatRemoved);

        if (self::isFresh($transaction)) {
            fluent_cart_add_log(
                __('Paddle tax reconciled (reverse charge)', 'fluent-cart-pro'),
                sprintf(
                    /* translators: %1$s: removed VAT, %2$s: order total, %3$s: captured net, %4$s: currency */
                    __('Paddle (Merchant of Record) applied EU reverse charge and removed %1$s %4$s VAT, capturing %3$s %4$s net of the %2$s %4$s priced order. Order total is kept at the priced amount (%2$s %4$s); the captured net and removed VAT are recorded for display and refunds.', 'fluent-cart-pro'),
                    self::logAmount($vatRemoved, $orderCurrency),
                    self::logAmount($orderTotal, $orderCurrency),
                    self::logAmount($captured->total, $orderCurrency),
                    $orderCurrency
                ),
                'info',
                ['module_name' => 'order', 'module_id' => $order->id]
            );
        }

        return self::result('reverse_charge', $orderTotal, $orderCurrency, true, $meta);
    }

    /**
     * Cross-currency route: Paddle localized checkout to the buyer's currency, so the
     * captured amount is not comparable to the order (no order->buyer rate is present
     * on the transaction, and re-deriving one would cause false declines). Identity is
     * therefore the only defense and is required before covering: a verified charge
     * covers the order in the order currency, an unverified one contributes 0 toward
     * payment and leaves the order unpaid; captured + FX stay in meta either way. The
     * tax sub-case is detected (for visibility) but does not change the order.
     */
    protected static function crossCurrencyReconcile(OrderTransaction $transaction, CapturedCharge $captured, $charge, Order $order): array
    {
        $orderTotal    = (int) $order->total_amount;
        $orderCurrency = strtoupper((string) $order->currency);

        // A non-positive captured total is not proof of payment — never act on it.
        if ($captured->total <= 0) {
            return self::result('skipped', $orderTotal, $orderCurrency, false);
        }

        if (!self::isFresh($transaction)
            && (int) Arr::get((array)($transaction->meta ?? []), 'paddle_captured', -1) === $captured->total) {
            return self::result('cross_currency', $orderTotal, $orderCurrency, false, ['mor_covered' => true]);
        }

        // A charge with no live line items (rebuilt from stored totals on re-entry)
        // is trusted only when this reconciler previously verified it — the
        // transaction already carries the cross_currency meta flag.
        $identityVerified = (self::chargeMatchesExpectedItems($charge, $transaction)
                && self::chargeDiscountMatchesExpected($charge, $transaction))
            || !empty(Arr::get((array) ($transaction->meta ?? []), 'cross_currency'));

        if (!$identityVerified) {
            if (self::isFresh($transaction)) {
                fluent_cart_add_log(
                    __('Paddle reconciliation skipped (cross-currency identity mismatch)', 'fluent-cart-pro'),
                    sprintf(
                        /* translators: %1$s: charged amount, %2$s: charged currency, %3$s: order total, %4$s: order currency */
                        __('A cross-currency Paddle charge (%1$s %2$s) was reported as paid against an order priced %3$s %4$s, but it does not match what this store sent to checkout. The charge is recorded in the transaction meta but not counted toward payment, and the order is left unpaid — please verify the order against the Paddle transaction.', 'fluent-cart-pro'),
                        self::logAmount($captured->total, $captured->currency),
                        $captured->currency,
                        self::logAmount($orderTotal, $orderCurrency),
                        $orderCurrency
                    ),
                    'error',
                    ['module_name' => 'order', 'module_id' => $order->id]
                );
            }
            // Amount 0, order currency — NEVER the captured foreign amount. Callers
            // persist the reconcile amount on the transaction and StatusHelper compares
            // raw minor-unit sums with no currency awareness, so a foreign figure that
            // happens to be numerically >= the order total (e.g. 100 JPY vs 100 USD,
            // both 10000 minor units) would mark the order paid. The captured truth
            // stays in meta.paddle_captured / meta.paddle_captured_currency.
            return self::result('cross_currency_unverified', 0, $orderCurrency, false, self::capturedMeta($captured));
        }

        $taxCase = self::detectTaxCase($captured);

        if (self::isFresh($transaction)) {
            // Same structural gate as the same-currency path (coverReverseCharge): only a
            // charge that structurally matches this order's line items is treated as
            // affirmative reverse-charge evidence. A shortfall/mismatch still covers the
            // order (MoR already collected payment) but must not write an unverified
            // reverse-charge classification into business_info.
            $structurallyVerified = self::chargeCoversOrder($charge, $order);

            if ($taxCase === 'reverse_charge' && $structurallyVerified) {
                // No order->buyer FX rate exists, so vat_removed cannot be expressed in
                // order currency here — record the flag, leave the amount to
                // meta.paddle_totals (charged-currency figures) for cross-currency orders.
                self::recordValidatedBuyerVatNumber($transaction, $order, $captured, null);
            }

            if (!$structurallyVerified) {
                fluent_cart_add_log(
                    __('Paddle cross-currency payment — integrity check failed', 'fluent-cart-pro'),
                    sprintf(
                        /* translators: %1$s: charged amount, %2$s: charged currency */
                        __('A cross-currency Paddle charge (%1$s %2$s) was reported as paid but its line items/totals do not structurally match this order. Recorded as paid because the Merchant of Record already collected payment; please verify the order against the Paddle transaction.', 'fluent-cart-pro'),
                        self::logAmount($captured->total, $captured->currency),
                        $captured->currency
                    ),
                    'error',
                    ['module_name' => 'order', 'module_id' => $order->id]
                );
            }

            fluent_cart_add_log(
                __('Paddle cross-currency payment normalized', 'fluent-cart-pro'),
                sprintf(
                    /* translators: %1$s: charged amount, %2$s: charged currency, %3$s: order amount, %4$s: order currency */
                    __('Paddle charged %1$s %2$s in the buyer currency. The transaction is recorded in the order currency (%4$s %3$s); the actual captured amount is stored in the transaction meta.', 'fluent-cart-pro'),
                    self::logAmount($captured->total, $captured->currency),
                    $captured->currency,
                    self::logAmount($orderTotal, $orderCurrency),
                    $orderCurrency
                ),
                'info',
                ['module_name' => 'order', 'module_id' => $order->id]
            );
        }

        $meta = array_merge(self::capturedMeta($captured), [
            'mor_covered'    => true,
            'cross_currency' => true,
            'tax_case'       => $taxCase,
            'reverse_charge' => $taxCase === 'reverse_charge',
        ]);

        // Cover: txn.total = order.total_amount in order currency. Actual foreign captured
        // amount lives in meta.paddle_captured / meta.paddle_captured_currency.
        // StatusHelper marks paid naturally; no filter required.
        return self::result('cross_currency', $orderTotal, $orderCurrency, true, $meta);
    }

    /**
     * Classify the tax decision baked into a charge, independent of currency.
     * Used for cross-currency visibility (the order is not altered either way).
     *
     * @return string 'reverse_charge' | 'tax_excluded' | 'plain'
     */
    protected static function detectTaxCase(CapturedCharge $captured): string
    {
        if ($captured->tax === 0 && self::taxRatesAreZeroOrEmpty($captured->taxRatesUsed)) {
            return 'reverse_charge';
        }

        if ($captured->tax > 0
            && abs(($captured->subtotal - $captured->discount + $captured->tax) - $captured->total) <= self::VERIFY_TOLERANCE) {
            return 'tax_excluded';
        }

        return 'plain';
    }

    /**
     * Structural sanity check before a charge is treated as covering the order.
     *
     * Intentionally NOT an amount comparison: the order->buyer rate is not on the
     * transaction, so any amount check would false-decline. Instead it confirms Paddle
     * itemised and charged real money for this order's goods (positive subtotal + total,
     * and at least one line item mapped to an order item).
     */
    protected static function chargeCoversOrder($charge, Order $order): bool
    {
        $totals = (array) Arr::get($charge, 'details.totals', []);

        if ((int) Arr::get($totals, 'subtotal', 0) <= 0 || (int) Arr::get($totals, 'total', 0) <= 0) {
            return false;
        }

        $meta = PaddleHelper::getTransactionMeta($charge, $order);

        return !empty(Arr::get($meta, 'mapped_paddle_item_ids', []));
    }

    /**
     * Identity binding: the charge's line items must be exactly the Paddle prices
     * this store sent to checkout — same price_id multiset, same quantities —
     * against the paddle_expected_items meta persisted by Processor before the
     * browser sees any price_id. Gateway-billed renewals never pass checkout, so
     * their expected identity is the subscription's vendor_plan_id instead.
     * Fail-closed: no expected identity resolvable, or no live line items, means
     * NOT verified.
     */
    protected static function chargeMatchesExpectedItems($charge, OrderTransaction $transaction): bool
    {
        $lineItems = (array) Arr::get($charge, 'details.line_items', []);
        if (empty($lineItems)) {
            return false;
        }

        $expected = Arr::get((array) ($transaction->meta ?? []), 'paddle_expected_items', []);

        if (empty($expected) || !is_array($expected)) {
            return self::lineItemsMatchSubscriptionPlan($lineItems, $transaction);
        }

        $expectedCounts = [];
        foreach ($expected as $item) {
            $priceId = (string) Arr::get((array) $item, 'price_id', '');
            if ($priceId === '') {
                return false;
            }
            $expectedCounts[$priceId] = ($expectedCounts[$priceId] ?? 0) + max(1, (int) Arr::get((array) $item, 'quantity', 1));
        }

        $chargedCounts = [];
        foreach ($lineItems as $line) {
            $priceId = (string) Arr::get((array) $line, 'price_id', '');
            if ($priceId === '') {
                return false;
            }
            $chargedCounts[$priceId] = ($chargedCounts[$priceId] ?? 0) + max(1, (int) Arr::get((array) $line, 'quantity', 1));
        }

        ksort($expectedCounts);
        ksort($chargedCounts);

        return $expectedCounts === $chargedCounts;
    }

    /**
     * Discount identity: store-created Paddle discounts are checkout-enabled and
     * reusable by id, so the charge's discount must be exactly the persisted
     * paddle_expected_discount_id (none expected → none allowed). Only enforced
     * when expected-items meta is present — renewals and legacy transactions have
     * no checkout overlay to tamper with and skip it.
     */
    protected static function chargeDiscountMatchesExpected($charge, OrderTransaction $transaction): bool
    {
        $meta = (array) ($transaction->meta ?? []);

        if (empty(Arr::get($meta, 'paddle_expected_items'))) {
            return true;
        }

        $expectedDiscountId = (string) Arr::get($meta, 'paddle_expected_discount_id', '');
        $chargeDiscountId   = (string) Arr::get($charge, 'discount_id', '');
        $chargeDiscount     = (int) Arr::get($charge, 'details.totals.discount', 0);

        if ($expectedDiscountId === '') {
            return $chargeDiscountId === '' && $chargeDiscount === 0;
        }

        return $chargeDiscountId === $expectedDiscountId;
    }

    /**
     * Renewal identity fallback: a subscription-billed charge carries exactly the
     * subscription's recurring price. Requires the local transaction to belong to a
     * subscription with a recorded vendor_plan_id.
     */
    protected static function lineItemsMatchSubscriptionPlan(array $lineItems, OrderTransaction $transaction): bool
    {
        if (!$transaction->subscription_id) {
            return false;
        }

        $subscription = $transaction->subscription;
        $planId       = $subscription ? (string) $subscription->vendor_plan_id : '';
        if ($planId === '') {
            return false;
        }

        foreach ($lineItems as $line) {
            if ((string) Arr::get((array) $line, 'price_id', '') !== $planId) {
                return false;
            }
        }

        return true;
    }

    /**
     * True when no applied tax rate is non-zero (empty list or all 0% rates).
     */
    protected static function taxRatesAreZeroOrEmpty($taxRatesUsed): bool
    {
        if (empty($taxRatesUsed)) {
            return true;
        }

        foreach ($taxRatesUsed as $rate) {
            if ((float) Arr::get($rate, 'tax_rate', 0) > 0) {
                return false;
            }
        }

        return true;
    }

    /**
     * Authoritative captured figures for the transaction meta.
     */
    protected static function capturedMeta(CapturedCharge $captured): array
    {
        return [
            'paddle_captured'          => $captured->total,
            'paddle_captured_currency' => $captured->currency,
        ];
    }

    /**
     * A confirmed reverse charge means Paddle already validated a real business VAT
     * number for this buyer — pull it and fold it into the order's existing
     * `business_info` meta so the receipt/PDF/email tax display (which already reads
     * Order::isReverseChargeTaxOrder() / getCustomerTaxNumber()) picks it up for free.
     * order.total_amount is never touched here — only the buyer's tax identity.
     *
     * Also stamps `reverse_charge_applied` + `mor_vat_removed` (when the caller has an
     * order-currency figure — same-currency only, cross-currency passes null) into
     * business_info unconditionally, since no MoR gateway leaves an orderTaxRate row
     * behind for TaxSummaryHelper to read reverse-charge figures from. This write does
     * NOT depend on the Business API call below succeeding — the reverse-charge fact is
     * already established by the caller (zero-tax capture), independent of whether the
     * validated tax number can be fetched.
     *
     * Business API lookup is best-effort: a Paddle API failure or missing business_id
     * must never block fulfillment, so any error just leaves the tax-number fields as
     * they were.
     *
     * @param int|null $vatRemoved Order-currency VAT amount removed, or null when not
     *                             expressible (cross-currency — no order->buyer FX rate).
     */
    protected static function recordValidatedBuyerVatNumber(OrderTransaction $transaction, Order $order, CapturedCharge $captured, ?int $vatRemoved = null): void
    {
        $existing = $order->getBusinessInfo();

        $flags = ['reverse_charge_applied' => true];
        if ($vatRemoved !== null) {
            $flags['mor_vat_removed'] = $vatRemoved;
        }
        $order->updateMeta('business_info', array_merge($existing, $flags));

        // Runs on every reconcile entry (backfill), so the remote lookup below must not
        // repeat once the tax number is already recorded.
        if (!empty(Arr::get($existing, 'tax_number_validated'))) {
            return;
        }

        if (!$captured->businessId || !$captured->customerId) {
            return;
        }

        $response = API::getPaddleObject(
            "customers/{$captured->customerId}/businesses/{$captured->businessId}",
            [],
            $transaction->payment_mode
        );

        if (is_wp_error($response)) {
            return;
        }

        $taxNumber = (string) Arr::get($response, 'data.tax_identifier', '');
        if (!$taxNumber) {
            return;
        }

        $businessName = (string) Arr::get($response, 'data.name', '');
        $existing     = $order->getBusinessInfo();

        $order->updateMeta('business_info', array_merge(
            ['company_name' => $businessName],
            $existing,
            [
                'tax_number'           => $taxNumber,
                'tax_number_validated' => true,
                'tax_number_name'      => Arr::get($existing, 'tax_number_name', __('VAT', 'fluent-cart-pro')),
            ]
        ));
    }

    /**
     * Logs and non-idempotent order mutations only run on the first (pre-success)
     * reconciliation. Re-entries (already-succeeded webhook, admin self-heal) stay quiet;
     * idempotent writes (business_info stamp, txn meta merge) run on every entry so
     * rows reconciled by versions that lacked a key get backfilled.
     */
    protected static function isFresh(OrderTransaction $transaction): bool
    {
        return $transaction->status !== Status::TRANSACTION_SUCCEEDED;
    }

    /**
     * Format an FC-unit amount for log messages (all amounts ×100, including zero-decimal).
     */
    private static function logAmount(int $amount, string $currency): string
    {
        return (string) ($amount / 100);
    }

    /**
     * @return array{status:string, amount:int, currency:string, changed:bool, meta:array}
     */
    protected static function result(string $status, int $amount, string $currency, bool $changed, array $meta = []): array
    {
        return [
            'status'   => $status,
            'amount'   => $amount,
            'currency' => $currency,
            'changed'  => $changed,
            'meta'     => $meta,
        ];
    }
}
