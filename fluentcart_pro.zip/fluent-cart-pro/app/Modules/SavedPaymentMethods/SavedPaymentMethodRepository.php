<?php

namespace FluentCartPro\App\Modules\SavedPaymentMethods;

use FluentCart\App\Models\Customer;
use FluentCart\App\Models\CustomerMeta;
use FluentCart\App\Models\Subscription;
use FluentCart\App\Models\SubscriptionMeta;
use FluentCart\Framework\Support\Arr;

/**
 * Reads and normalizes the per-customer saved-card record stored in
 * fct_customer_meta under the key `saved_payment_method`.
 *
 * The stored shape is inconsistent by design (see Confirmations.php:303-394):
 *   { <gateway>: { customer_id, payment_methods: [...] } }
 * where `payment_methods` is a PLAIN INDEXED ARRAY when no gateway default is
 * set, but an OBJECT with a "default" key when one is. This repository is the
 * single place that tolerates both shapes and flattens them into one
 * browser-safe list — the raw gateway token (pm_/vault id) is never exposed;
 * the browser only sees an opaque id that resolve() maps back server-side.
 */
class SavedPaymentMethodRepository
{
    const META_KEY = 'saved_payment_method';

    /**
     * Live subscription statuses whose card counts as "in use".
     */
    const LIVE_SUBSCRIPTION_STATUSES = ['active', 'trialing', 'paused', 'past_due', 'expiring'];

    /**
     * The customer's saved cards as a flat, browser-safe list.
     *
     * @return array<int, array>
     */
    public function list(Customer $customer): array
    {
        $meta = $this->readMeta($customer);
        if (empty($meta)) {
            return [];
        }

        $inUseTokens = $this->getSubscriptionTokenIds($customer);

        $cards = [];
        foreach ($meta as $gateway => $gatewayData) {
            $normalized = $this->normalizeMethods(Arr::get($gatewayData, 'payment_methods', []));

            $gatewayCards = [];
            foreach ($normalized as $entry) {
                $pm = $entry['pm'];
                $tokenId = Arr::get($pm, 'id');
                if (!$tokenId) {
                    continue;
                }

                // A PayPal entry is an account, not a card: no brand, last4 or
                // expiry exists for it. Those keys stay present but null so the
                // response shape is stable, and `email` identifies the entry
                // instead — the UI switches on `type`.
                $gatewayCards[] = [
                    'id'                     => $this->opaqueId($gateway, $tokenId),
                    'gateway'                => $gateway,
                    'type'                   => Arr::get($pm, 'type', 'card'),
                    'brand'                  => Arr::get($pm, 'brand'),
                    'last4'                  => Arr::get($pm, 'last4'),
                    'exp_month'              => Arr::get($pm, 'exp_month'),
                    'exp_year'               => Arr::get($pm, 'exp_year'),
                    'email'                  => Arr::get($pm, 'email'),
                    'is_default'             => $entry['is_default'],
                    'in_use_by_subscription' => in_array($tokenId, $inUseTokens, true),
                ];
            }

            $cards = array_merge($cards, $gatewayCards);
        }

        // Storage may carry no explicit default (plain-array shape) — mark the
        // first card default so the UI always shows one. Across the WHOLE list,
        // not per gateway: a per-gateway synthesis puts two "Default" badges on
        // a Stripe + PayPal customer (and hides both "Set as default" buttons).
        if ($cards && !$this->hasDefault($cards)) {
            $cards[0]['is_default'] = true;
        }

        return $cards;
    }

    /**
     * Resolve a browser-supplied opaque id back to the real stored card
     * (including the raw gateway token) for THIS customer only.
     *
     * @return array|null ['gateway'=>string, 'customer_id'=>string|null, 'pm'=>array]
     */
    public function resolve(Customer $customer, string $opaqueId)
    {
        foreach ($this->readMeta($customer) as $gateway => $gatewayData) {
            foreach ($this->normalizeMethods(Arr::get($gatewayData, 'payment_methods', [])) as $entry) {
                $tokenId = Arr::get($entry['pm'], 'id');
                if ($tokenId && hash_equals($this->opaqueId($gateway, $tokenId), $opaqueId)) {
                    return [
                        'gateway'     => $gateway,
                        'customer_id' => Arr::get($gatewayData, 'customer_id'),
                        'pm'          => $entry['pm'],
                    ];
                }
            }
        }

        return null;
    }

    /**
     * Remove the card behind an opaque id from the stored meta (gateway-agnostic
     * — no gateway API call). Returns true if a card was removed. A gateway with
     * no cards left is dropped entirely.
     *
     * The explicit "default" slot is preserved: deleting a NON-default card
     * keeps the surviving default under its "default" key (so the customer's
     * chosen default isn't silently reassigned to the first remaining card).
     * Deleting the default itself clears the slot — the reader then treats the
     * gateway as having no explicit default.
     */
    public function forget(Customer $customer, string $opaqueId): bool
    {
        $meta = $this->readMeta($customer);
        $changed = false;
        $newMeta = [];

        foreach ($meta as $gateway => $gatewayData) {
            $methods = Arr::get($gatewayData, 'payment_methods', []);
            if (!is_array($methods)) {
                $newMeta[$gateway] = $gatewayData;
                continue;
            }

            $kept = [];
            $defaultPm = null;
            $removedHere = false;
            foreach ($this->normalizeMethods($methods) as $entry) {
                $tokenId = Arr::get($entry['pm'], 'id');
                if ($tokenId && hash_equals($this->opaqueId($gateway, $tokenId), $opaqueId)) {
                    $changed = true;
                    $removedHere = true;
                    continue;
                }
                if (!empty($entry['is_default'])) {
                    $defaultPm = $entry['pm'];
                } else {
                    $kept[] = $entry['pm'];
                }
            }

            // A gateway this delete never touched is preserved verbatim — even
            // with an empty payment_methods list it still carries the vendor
            // customer_id link, which a rebuild here would silently lose.
            if (!$removedHere) {
                $newMeta[$gateway] = $gatewayData;
                continue;
            }

            if ($defaultPm !== null) {
                // Rebuild the object-with-"default" shape: default slot + rest.
                $gatewayData['payment_methods'] = ['default' => $defaultPm] + $kept;
                $newMeta[$gateway] = $gatewayData;
            } elseif (!empty($kept)) {
                $gatewayData['payment_methods'] = $kept;
                $newMeta[$gateway] = $gatewayData;
            }
            // else: gateway emptied by the removal — drop it
        }

        if ($changed) {
            if (empty($newMeta)) {
                // Never persist an empty array: the CustomerMeta accessor decodes
                // stored "[]" back to the STRING "[]" (json_decode([]) ?: $value),
                // and core's writer (Confirmations::savePaymentMethodToCustomerMeta)
                // then does $meta['stripe'] = ... on that string and fatals
                // ("Cannot access offset of type string on string"). Drop the row
                // instead so a later save sees an absent (null) meta.
                CustomerMeta::query()
                    ->where('customer_id', $customer->id)
                    ->where('meta_key', self::META_KEY)
                    ->delete();
            } else {
                $customer->updateMeta(self::META_KEY, $newMeta);
            }
        }

        return $changed;
    }

    /**
     * @return array the decoded `saved_payment_method` meta (always an array)
     */
    private function readMeta(Customer $customer): array
    {
        $meta = $customer->getMeta(self::META_KEY);
        return is_array($meta) ? $meta : [];
    }

    /**
     * Flatten a stored `payment_methods` value (plain array OR object with a
     * "default" key) into: [ ['pm'=>[...], 'is_default'=>bool], ... ].
     */
    private function normalizeMethods($methods): array
    {
        if (!is_array($methods)) {
            return [];
        }

        $out = [];
        foreach ($methods as $key => $pm) {
            if (!is_array($pm)) {
                continue;
            }
            $out[] = [
                'pm'         => $pm,
                'is_default' => ($key === 'default'),
            ];
        }

        return $out;
    }

    private function hasDefault(array $cards): bool
    {
        foreach ($cards as $card) {
            if (!empty($card['is_default'])) {
                return true;
            }
        }

        return false;
    }

    private function opaqueId(string $gateway, string $tokenId): string
    {
        return substr(hash('sha256', $gateway . '|' . $tokenId), 0, 20);
    }

    /**
     * Payment-method token ids currently backing the customer's live
     * subscriptions. The active_payment_method meta has several historical
     * shapes across gateways — accept all so an actively-billed card is never
     * treated as unused:
     *   - vendor_method_id            (Stripe: Confirmations / recordManualRenewal)
     *   - details.payment_method_id   (Stripe: SwitchCustomerMethod / parsePaymentMethodDetails)
     *   - payment_profile_id          (Authorize.Net: AuthorizeDotNet subscriptions)
     *
     * @return array<int, string>
     */
    private function getSubscriptionTokenIds(Customer $customer): array
    {
        // Two bounded queries — no per-subscription meta lookups (N+1):
        // 1) the live subscription ids (id column only)
        $subscriptions = Subscription::query()
            ->where('customer_id', $customer->id)
            ->whereIn('status', self::LIVE_SUBSCRIPTION_STATUSES)
            ->get(['id']);

        $subscriptionIds = [];
        foreach ($subscriptions as $subscription) {
            $subscriptionIds[] = $subscription->id;
        }

        if (empty($subscriptionIds)) {
            return [];
        }

        // 2) only the active_payment_method meta rows for those subscriptions,
        //    batched in a single query (meta_value auto-decodes to an array).
        $metaRows = SubscriptionMeta::query()
            ->whereIn('subscription_id', $subscriptionIds)
            ->where('meta_key', 'active_payment_method')
            ->get(['meta_value']);

        $tokens = [];
        foreach ($metaRows as $row) {
            $active = $row->meta_value;
            if (!is_array($active)) {
                continue;
            }

            $tokenId = Arr::get($active, 'vendor_method_id');
            if (!$tokenId) {
                $tokenId = Arr::get($active, 'details.payment_method_id');
            }
            if (!$tokenId) {
                // Authorize.Net stores the active payment profile here.
                $tokenId = Arr::get($active, 'payment_profile_id');
            }

            if ($tokenId) {
                $tokens[] = $tokenId;
            }
        }

        return $tokens;
    }
}
