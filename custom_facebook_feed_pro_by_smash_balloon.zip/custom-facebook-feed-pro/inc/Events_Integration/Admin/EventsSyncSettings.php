<?php
/**
 * Admin settings for the events sync: the "Events Sync" tab on the global
 * settings page and its AJAX endpoints (save, Sync Now, cleanup).
 *
 * @package CustomFacebookFeed\Events_Integration
 * @since 4.11
 */

namespace CustomFacebookFeed\Events_Integration\Admin;

use CustomFacebookFeed\CFF_Response;
use CustomFacebookFeed\Events_Integration\Config;
use CustomFacebookFeed\Events_Integration\Provider\EventsProvider;
use CustomFacebookFeed\Events_Integration\Sync\Scheduler;
use CustomFacebookFeed\Events_Integration\Sync\SyncEngine;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class EventsSyncSettings {

	/**
	 * @var SyncEngine
	 */
	private $engine;

	/**
	 * @var Scheduler
	 */
	private $scheduler;

	/**
	 * @param SyncEngine $engine    Sync engine.
	 * @param Scheduler  $scheduler Cron scheduler.
	 */
	public function __construct( SyncEngine $engine, Scheduler $scheduler ) {
		$this->engine    = $engine;
		$this->scheduler = $scheduler;
	}

	/**
	 * Register admin hooks.
	 */
	public function register_hooks() {
		if ( ! is_admin() ) {
			return;
		}
		add_action( 'wp_ajax_cff_events_sync_save', array( $this, 'ajax_save' ) );
		add_action( 'wp_ajax_cff_events_sync_now', array( $this, 'ajax_sync_now' ) );
		add_action( 'wp_ajax_cff_events_sync_cleanup', array( $this, 'ajax_cleanup' ) );
		add_action( 'wp_ajax_cff_events_sync_clear_log', array( $this, 'ajax_clear_log' ) );
	}

	/**
	 * Data localized into the settings page Vue app (cff_settings.eventsSync).
	 *
	 * @return array
	 */
	public static function localized_data() {
		$provider  = new EventsProvider();
		$scheduler = new Scheduler();
		$sources   = array();
		foreach ( $provider->get_sources() as $source ) {
			$sources[] = array(
				'account_id' => $source['account_id'],
				'username'   => isset( $source['username'] ) ? $source['username'] : $source['account_id'],
			);
		}

		$logos = array(
			Config::TARGET_SUGAR_CALENDAR => CFF_PLUGIN_URL . 'admin/assets/img/sugar-calendar-logo.png',
			Config::TARGET_TEC            => CFF_PLUGIN_URL . 'admin/assets/img/the-events-calendar-logo.png',
		);

		$targets = array();
		foreach ( \CustomFacebookFeed\Events_Integration\EventsIntegration::adapters() as $target_id => $adapter ) {
			$targets[ $target_id ] = array(
				'label'     => $adapter->label(),
				'available' => $adapter->is_available(),
				'logo'      => isset( $logos[ $target_id ] ) ? $logos[ $target_id ] : '',
			);
		}

		// Vue 2 only tracks keys that exist up front; seed one per adapter.
		$model = Config::get_settings();
		foreach ( array_keys( $targets ) as $target_id ) {
			if ( ! isset( $model['targets'][ $target_id ] ) ) {
				$model['targets'][ $target_id ] = false;
			}
		}

		return array(
			'model'         => $model,
			'targets'       => $targets,
			'sources'       => $sources,
			'suggestUrl'    => 'https://sugarcalendar.com/?utm_campaign=facebook-pro&utm_source=events-sync&utm_medium=settings',
			// Free Sugar Calendar (Lite) zip for the one-click install flow.
			'suggestInstallUrl' => 'https://downloads.wordpress.org/plugin/sugar-calendar-lite.zip',
			'canInstall'        => current_user_can( 'install_plugins' ),
			'suggestLogo'   => $logos[ Config::TARGET_SUGAR_CALENDAR ],
			'licenseAllows' => Config::license_allows(),
			'nextRun'       => $scheduler->next_run(),
			'log'           => array_reverse( (array) get_option( Config::OPTION_LOG, array() ) ),
			'genericText'   => array(
				'title'            => __( 'Events Sync', 'custom-facebook-feed' ),
				'description'      => __( 'Automatically sync your Facebook events into your WordPress calendar plugin.', 'custom-facebook-feed' ),
				'enable'           => __( 'Enable events sync', 'custom-facebook-feed' ),
				'targetsTitle'     => __( 'Calendar integrations', 'custom-facebook-feed' ),
				'notInstalled'     => __( 'Not detected. Install and activate the plugin to enable this integration.', 'custom-facebook-feed' ),
				'installed'        => __( 'Detected', 'custom-facebook-feed' ),
				'sourcesTitle'     => __( 'Facebook event sources', 'custom-facebook-feed' ),
				'sourcesEmpty'     => __( 'You have no event source connected. Connect an events source in the Feed Builder first.', 'custom-facebook-feed' ),
				'sourcesAll'       => __( 'Select the sources whose events should be synced. Nothing is synced until at least one source is selected.', 'custom-facebook-feed' ),
				'suggestTitle'     => __( 'No calendar plugin detected', 'custom-facebook-feed' ),
				'suggestText'      => __( 'Events Sync needs a calendar plugin to push your Facebook events into. We recommend Sugar Calendar, a lightweight, powerful events calendar for WordPress.', 'custom-facebook-feed' ),
				'suggestCta'       => __( 'Install Sugar Calendar', 'custom-facebook-feed' ),
				'installing'       => __( 'Installing...', 'custom-facebook-feed' ),
				'installFailed'    => __( 'The plugin could not be installed. Please install it manually from the Plugins page.', 'custom-facebook-feed' ),
				'cronTitle'        => __( 'Sync schedule', 'custom-facebook-feed' ),
				'cronHourly'       => __( 'Every hour', 'custom-facebook-feed' ),
				'cronTwiceDaily'   => __( 'Twice daily', 'custom-facebook-feed' ),
				'cronDaily'        => __( 'Daily', 'custom-facebook-feed' ),
				'nextRun'          => __( 'Next scheduled sync:', 'custom-facebook-feed' ),
				'sideloadImages'   => __( 'Import event cover images', 'custom-facebook-feed' ),
				'syncNow'          => __( 'Sync Now', 'custom-facebook-feed' ),
				'syncing'          => __( 'Syncing...', 'custom-facebook-feed' ),
				'syncSuccess'      => __( 'Sync completed. Your Facebook events are now in your calendar.', 'custom-facebook-feed' ),
				'cleanup'          => __( 'Remove imported events', 'custom-facebook-feed' ),
				'cleanupDone'      => __( 'All imported events have been removed.', 'custom-facebook-feed' ),
				'mirrorNotice'     => __( 'Imported events are managed by the sync: changes on Facebook update the calendar event, and events deleted or canceled on Facebook are removed from the calendar.', 'custom-facebook-feed' ),
				'logTitle'         => __( 'Recent syncs', 'custom-facebook-feed' ),
				'clearLog'         => __( 'Clear log', 'custom-facebook-feed' ),
				'logEmpty'         => __( 'No syncs have run yet.', 'custom-facebook-feed' ),
				'syncFailed'       => __( 'The sync could not be completed.', 'custom-facebook-feed' ),
				'syncScheduled'    => __( 'First source synced. The remaining sources will sync in the background over the next few minutes.', 'custom-facebook-feed' ),
				'cleanupFailed'    => __( 'The imported events could not be removed.', 'custom-facebook-feed' ),
				'saveFailed'       => __( 'The settings could not be saved.', 'custom-facebook-feed' ),
				'logTime'          => __( 'Time', 'custom-facebook-feed' ),
				'logSource'        => __( 'Source', 'custom-facebook-feed' ),
				'logCreated'       => __( 'Created', 'custom-facebook-feed' ),
				'logUpdated'       => __( 'Updated', 'custom-facebook-feed' ),
				'logDeleted'       => __( 'Deleted', 'custom-facebook-feed' ),
				'logErrors'        => __( 'Errors', 'custom-facebook-feed' ),
				'upgradeNotice'    => __( 'Events Sync is available on the Elite plan.', 'custom-facebook-feed' ),
			),
		);
	}

	/**
	 * AJAX: save the events sync settings.
	 */
	public function ajax_save() {
		$this->verify_request();

		$model = isset( $_POST['model'] ) ? json_decode( stripslashes( $_POST['model'] ), true ) : null; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput -- decoded and sanitized field-by-field below.
		if ( ! is_array( $model ) ) {
			wp_send_json_error();
		}

		$defaults = Config::get_settings();
		// Whitelist against registered adapters so filter-added targets work.
		$targets = array();
		foreach ( array_keys( \CustomFacebookFeed\Events_Integration\EventsIntegration::adapters() ) as $target_id ) {
			$targets[ $target_id ] = ! empty( $model['targets'][ $target_id ] );
		}

		$cron_interval = isset( $model['cron_interval'] ) ? sanitize_key( $model['cron_interval'] ) : $defaults['cron_interval'];
		if ( ! in_array( $cron_interval, array( 'hourly', 'twicedaily', 'daily' ), true ) ) {
			$cron_interval = 'twicedaily';
		}

		$settings = array(
			'enabled'            => ! empty( $model['enabled'] ),
			'targets'            => $targets,
			'sources'            => isset( $model['sources'] ) ? array_map( 'sanitize_text_field', (array) $model['sources'] ) : array(),
			'cron_interval'      => $cron_interval,
			'sideload_images'    => ! empty( $model['sideload_images'] ),
			'sc_calendar_term'   => isset( $model['sc_calendar_term'] ) ? (int) $model['sc_calendar_term'] : 0,
			'tec_default_status' => isset( $model['tec_default_status'] ) && 'draft' === $model['tec_default_status'] ? 'draft' : 'publish',
		);

		Config::update_settings( $settings );
		$this->scheduler->reschedule();

		$response = new CFF_Response(
			true,
			array(
				'nextRun' => $this->scheduler->next_run(),
			)
		);
		$response->send();
	}

	/**
	 * AJAX: run a sync pass immediately and return its summary.
	 */
	public function ajax_sync_now() {
		$this->verify_request();

		if ( ! Config::is_enabled() ) {
			wp_send_json_error( array( 'message' => __( 'Enable and save the events sync settings first.', 'custom-facebook-feed' ) ) );
		}

		// Sync Now uses the same chunked flow as cron: the first source runs
		// in this request, the rest are scheduled as background batches, so
		// multi-source runs with image sideloading can't hit PHP time limits.
		$summary = $this->engine->run();
		$payload = array(
			'summary' => $summary,
			'log'     => array_reverse( (array) get_option( Config::OPTION_LOG, array() ) ),
		);

		// A pass with errors must not read as success in the UI.
		if ( ! empty( $summary['errors'] ) ) {
			wp_send_json_error( $payload );
		}

		$response = new CFF_Response( true, $payload );
		$response->send();
	}

	/**
	 * AJAX: delete all imported events for one target.
	 */
	public function ajax_cleanup() {
		$this->verify_request();

		$target_id = isset( $_POST['target'] ) ? sanitize_key( $_POST['target'] ) : '';
		$result    = $this->engine->cleanup( $target_id );

		if ( is_wp_error( $result ) ) {
			wp_send_json_error( array( 'message' => $result->get_error_message() ) );
		}
		if ( ! empty( $result['failed'] ) ) {
			wp_send_json_error( $result );
		}

		$response = new CFF_Response( true, $result );
		$response->send();
	}

	/**
	 * AJAX: clear the recent syncs log.
	 */
	public function ajax_clear_log() {
		$this->verify_request();

		delete_option( Config::OPTION_LOG );

		$response = new CFF_Response( true, array() );
		$response->send();
	}

	/**
	 * Nonce + capability checks shared by all endpoints.
	 */
	private function verify_request() {
		check_ajax_referer( 'cff-admin', 'nonce' );

		$cap = current_user_can( 'manage_custom_facebook_feed_options' ) ? 'manage_custom_facebook_feed_options' : 'manage_options';
		$cap = apply_filters( 'cff_settings_pages_capability', $cap );
		if ( ! current_user_can( $cap ) ) {
			wp_send_json_error();
		}

		// Enforce the UI's tier gate server-side too.
		if ( ! Config::license_allows() ) {
			wp_send_json_error();
		}
	}
}
