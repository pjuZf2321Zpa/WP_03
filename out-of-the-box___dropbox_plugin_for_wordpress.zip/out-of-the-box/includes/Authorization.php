<?php

/**
 * @author WP Cloud Plugins
 * @copyright Copyright (c) 2023, WP Cloud Plugins
 *
 * @since       2.0
 * @see https://www.wpcloudplugins.com
 */

namespace TheLion\OutoftheBox;

use TheLion\OutoftheBox\API\Dropbox\Models\AccessToken;

defined('ABSPATH') || exit;

class Authorization
{
    /**
     * Contains the location to the token file.
     *
     * @var string
     */
    private $_token_name;

    /**
     * Storage of the token file. See TokenFile for the handling of the file itself (atomic writes and locking).
     *
     * @var null|TokenFile
     */
    private $_token_file;

    /**
     * Does this instance hold the lock of the token file (e.g. while renewing the token).
     *
     * @var bool
     */
    private $_has_lock = false;

    /**
     * The account id linked to this authorization.
     *
     * @var string
     */
    private $_account_id;

    /**
     * Is the current authorization still valid or can it no longer be used.
     *
     * @var bool
     */
    private $_is_valid;

    public function __construct(Account $_account)
    {
        // Required for loading the Access Token class
        require_once OUTOFTHEBOX_ROOTDIR.'/vendors/dropbox-sdk/vendor/autoload.php';

        $this->_account_id = $_account->get_id();
        $this->_token_name = Helpers::filter_filename($_account->get_email().'_'.str_replace(':', '', $_account->get_id()), false).'.access_token';
    }

    public function set_token_name($token_name)
    {
        return $this->_token_name = $token_name;
    }

    public function get_token_location()
    {
        return OUTOFTHEBOX_CACHEDIR.$this->_token_name;
    }

    /**
     * @return TokenFile
     */
    public function get_token_file()
    {
        if (null === $this->_token_file || $this->_token_file->get_path() !== $this->get_token_location()) {
            $this->unlock_token_file();
            $this->_token_file = new TokenFile($this->get_token_location());
        }

        return $this->_token_file;
    }

    /**
     * Reading doesn't require a lock, as the token file is always replaced atomically.
     *
     * @return null|AccessToken
     */
    public function get_access_token()
    {
        return $this->read_access_token();
    }

    /**
     * Read the access token from the token file.
     *
     * @return null|AccessToken
     */
    public function read_access_token()
    {
        $token = $this->get_token_file()->read();

        if (empty($token)) {
            return null;
        }

        // Update function to encrypt tokens
        $updated_token = $this->update_from_single_token($token);
        if (empty($updated_token)) {
            return null;
        }

        // Update token to new Class
        return $this->update_from_old_class($updated_token);
    }

    /**
     * Check if the token file contains data, even if it cannot be read or decrypted.
     *
     * @return bool
     */
    public function has_token_file()
    {
        return $this->get_token_file()->has_data();
    }

    /**
     * @param AccessToken $_access_token
     *
     * @return bool true when the token is stored
     */
    public function set_access_token($_access_token)
    {
        $access_token = $this->encrypt(serialize($_access_token));
        if (null === $access_token) {
            // Preserve the existing token file when secure storage is unavailable.
            Helpers::log_error('Cannot encrypt authorization data.', 'Authorization', null, __LINE__);

            return false;
        }

        // Don't release a lock that is held for renewing the token, e.g. when an outdated token format is converted while renewing
        $has_lock = $this->_has_lock;

        if (false === $has_lock) {
            $this->get_lock(LOCK_EX);
        }

        $is_stored = $this->get_token_file()->write($access_token);

        if (false === $has_lock) {
            $this->unlock_token_file();
        }

        if (false === $is_stored) {
            Helpers::log_error('Cannot write the Authorization Token to the token file.', 'Authorization', ['account_id' => $this->_account_id], __LINE__);

            // Keep the Lost Authorisation message, as no new token is stored
            return false;
        }

        Helpers::log('Authorization Token stored.', 'Authorization', array_merge([
            'account_id' => $this->_account_id,
            'file' => \basename($this->get_token_location()),
        ], Helpers::get_encryption_diagnostics($access_token)), __LINE__);

        // Remove Lost Authorisation message
        if (false !== ($timestamp = wp_next_scheduled('outofthebox_lost_authorisation_notification', ['account_id' => $this->_account_id]))) {
            wp_unschedule_event($timestamp, 'outofthebox_lost_authorisation_notification', ['account_id' => $this->_account_id]);
            Helpers::log('Lost authorization notification unscheduled, as a new Authorization Token is stored.', 'Authorization', ['account_id' => $this->_account_id], __LINE__);
        }

        return $is_stored;
    }

    public function is_valid()
    {
        if (empty($this->_is_valid)) {
            $this->has_access_token();
        }

        return $this->_is_valid;
    }

    public function set_is_valid($valid = true)
    {
        $this->_is_valid = $valid;
    }

    public function has_access_token()
    {
        if (null !== $this->_is_valid) {
            return $this->_is_valid;
        }

        $access_token = $this->get_access_token();

        $this->set_is_valid(!empty($access_token));

        return $this->_is_valid;
    }

    /**
     * Why the authorization cannot be used, for diagnostics.
     *
     * @return string
     */
    public function get_invalid_reason()
    {
        $location = $this->get_token_location();
        clearstatcache(true, $location);

        if (!file_exists($location)) {
            return 'token_file_missing';
        }

        if (0 === (int) @filesize($location)) {
            return 'token_file_empty';
        }

        if (!is_readable($location) || null === $this->get_token_file()->read()) {
            return 'token_file_unreadable';
        }

        // The token cannot be decrypted (see 'Cannot decrypt token data from token file.') or is marked as invalid in this request, e.g. when renewing failed
        return 'token_invalid';
    }

    /**
     * @return string
     */
    public function get_lock_location()
    {
        return $this->get_token_file()->get_lock_path();
    }

    /**
     * Lock the token for renewing. The lock of a process that dies is released automatically.
     *
     * @param int $type
     *
     * @return bool
     */
    public function get_lock($type = LOCK_EX)
    {
        $this->_has_lock = $this->get_token_file()->lock($type);

        return $this->_has_lock;
    }

    /**
     * Try to get an exclusive lock, but don't wait longer than the timeout.
     *
     * @param float|int $timeout in seconds
     *
     * @return bool
     */
    public function try_lock($timeout = 10)
    {
        $this->_has_lock = $this->get_token_file()->try_lock($timeout);

        return $this->_has_lock;
    }

    /**
     * Check if the token file can actually be locked. Without lock file, get_lock() and try_lock() always succeed.
     *
     * @return bool
     */
    public function can_lock()
    {
        return $this->get_token_file()->can_lock();
    }

    public function unlock_token_file()
    {
        if (null !== $this->_token_file) {
            $this->_token_file->unlock();
        }

        $this->_has_lock = false;

        return true;
    }

    public function set_account_id($account_id)
    {
        $this->_account_id = $account_id;
    }

    public function get_account_id()
    {
        return $this->_account_id;
    }

    public function remove_token()
    {
        Helpers::log('Authorization Token removed.', 'Authorization', ['account_id' => $this->_account_id], __LINE__);

        $this->get_token_file()->remove();
    }

    public function update_from_single_token($token)
    {
        $decrypted_token = $this->decrypt($token);
        if (null === $decrypted_token) {
            Helpers::log_error('Cannot decrypt token data from token file.', 'Authorization', array_merge([
                'file' => \basename($this->get_token_location()),
                'stored_value_length' => strlen($token),
                'decrypt_error' => Helpers::$last_decrypt_error ?? 'unexpected_content',
                'token_modified' => gmdate('Y-m-d H:i:s', (int) @filemtime($this->get_token_location())).' UTC',
            ], Helpers::get_encryption_diagnostics($token)), __LINE__);

            return null;
        }

        $token_object = unserialize($decrypted_token);

        // Return if token is already encrypted and converted
        if (false !== $decrypted_token) {
            return $token_object;
        }

        // If token is not yet encrypted
        if (false !== $token_object) {
            return $this->set_access_token($token_object);
        }

        // Else convert & encrypt outdated token
        $data = [
            'access_token' => $token,
        ];

        $token_object = new AccessToken($data);

        // Store the new token format
        $this->set_access_token($token_object);

        return $token_object;
    }

    public function update_from_old_class($token_object)
    {
        if (false === is_a($token_object, '\TheLion\OutoftheBox\API\Dropbox\Models\AccessToken')) {
            $received_data = (array) $this->fix_object($token_object);

            $received_data['access_token'] = $received_data['token'] ?? '';
            $received_data['refresh_token'] = $received_data['refreshToken'] ?? '';
            $received_data['expires_in'] = $received_data['expiresIn'] ?? '';

            $token_object = new AccessToken($received_data);

            // Store the new token format
            $this->set_access_token($token_object);
        }

        return $token_object;
    }

    /**
     * Takes an __PHP_Incomplete_Class and casts it to a stdClass object.
     * All properties will be made public in this step.
     *
     * @param object $object __PHP_Incomplete_Class
     *
     * @return object
     */
    public function fix_object($object)
    {
        // 1. Serialize the object to a string.
        $dump = serialize($object);

        // 2. Change class-type to 'stdClass'.
        $dump = preg_replace('/^O:\d+:"[^"]++"/', 'O:8:"stdClass"', $dump);

        // 3. Make private and protected properties public.
        $dump = preg_replace_callback('/:\d+:"\0.*?\0([^"]+)"/', [$this, 'calc_key_length'], $dump);

        // 4. Unserialize the modified object again.
        try {
            return unserialize($dump);
        } catch (\Exception $e) {
            return [];
        }
    }

    public function calc_key_length($matches)
    {
        return ':'.strlen($matches[1]).':"'.$matches[1].'"';
    }

    public function encrypt($data, $method = 'aes-256-gcm')
    {
        return Helpers::encrypt($data, $method);
    }

    public function decrypt($input, $method = 'aes-256-gcm')
    {
        return Helpers::decrypt($input, $method);
    }
}
