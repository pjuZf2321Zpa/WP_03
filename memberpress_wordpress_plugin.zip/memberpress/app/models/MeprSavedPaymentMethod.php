<?php

if (!defined('ABSPATH')) {
    die('You are not allowed to call this page directly.');
}

/**
 * Represents a saved payment method in the system.
 *
 * @property int $id
 * @property int|null $user_id
 * @property string|null $gateway
 * @property string $token
 * @property string $type
 * @property string|null $brand
 * @property string|null $last4
 * @property string|null $exp_month
 * @property string|null $exp_year
 * @property int $is_default
 * @property string|null $created_at
 */
#[AllowDynamicProperties]
class MeprSavedPaymentMethod extends MeprBaseModel
{
    /**
     * Constructor for the MeprSavedPaymentMethod class.
     *
     * @param mixed $obj Optional. The object to initialize the saved payment method with.
     */
    public function __construct($obj = null)
    {
        $this->initialize(
            [
                'id'         => 0,
                'user_id'    => null,
                'gateway'    => null,
                'token'      => '',
                'type'       => 'card',
                'brand'      => null,
                'last4'      => null,
                'exp_month'  => null,
                'exp_year'   => null,
                'is_default' => 0,
                'created_at' => null,
            ],
            $obj
        );
    }

    /**
     * Store the object in the database (create or update).
     *
     * @return integer|boolean The record ID on success, false on failure.
     */
    public function store()
    {
        if (isset($this->id) && !is_null($this->id) && (int) $this->id > 0) {
            $mepr_db = new MeprDb();
            $args    = (array) $this->get_values();
            return $mepr_db->update_record($mepr_db->saved_payment_methods, $args);
        }

        $this->id = self::create($this);
        return $this->id;
    }

    /**
     * Create a new saved payment method record in the database.
     *
     * @param MeprSavedPaymentMethod $method The saved payment method object to create.
     *
     * @return integer The ID of the created saved payment method.
     */
    public static function create(MeprSavedPaymentMethod $method)
    {
        $mepr_db = new MeprDb();

        if (is_null($method->created_at) || empty($method->created_at)) {
            $method->created_at = MeprUtils::ts_to_mysql_date(time());
        }

        $args = (array) $method->get_values();

        return $mepr_db->create_record($mepr_db->saved_payment_methods, $args, false);
    }

    /**
     * Get all saved payment methods for a given user.
     *
     * @param  integer $user_id  The user ID.
     * @param  string  $order_by Optional. ORDER BY clause.
     * @param  string  $limit    Optional. LIMIT clause.
     * @return array
     */
    public static function get_by_user($user_id, $order_by = '', $limit = '')
    {
        $mepr_db = new MeprDb();

        return $mepr_db->get_records($mepr_db->saved_payment_methods, ['user_id' => $user_id], $order_by, $limit);
    }

    /**
     * Get the default saved payment method for a given user.
     *
     * @param  integer $user_id     The user ID.
     * @param  string  $return_type Optional. The return type. Default OBJECT.
     * @return object|array|null The default saved payment method or null if not found.
     */
    public static function get_default_for_user($user_id, $return_type = OBJECT)
    {
        $mepr_db = new MeprDb();

        return $mepr_db->get_one_record(
            $mepr_db->saved_payment_methods,
            [
                'user_id'    => $user_id,
                'is_default' => 1,
            ],
            $return_type
        );
    }

    /**
     * Delete the saved payment method from the database.
     *
     * @return boolean|integer False on failure, number of rows deleted on success.
     */
    public function destroy()
    {
        $mepr_db = new MeprDb();
        $id      = $this->id;
        $args    = compact('id');

        return $mepr_db->delete_records($mepr_db->saved_payment_methods, $args);
    }

    /**
     * Find a saved payment method by user ID and Stripe payment method token.
     *
     * Used to prevent duplicate saved methods when the same card is used multiple times.
     *
     * @param  integer $user_id The user ID.
     * @param  string  $token   The Stripe payment method ID (pm_xxx).
     * @return self|null The saved payment method or null if not found.
     */
    public static function find_by_token(int $user_id, string $token): ?self
    {
        $mepr_db = new MeprDb();
        $row     = $mepr_db->get_one_record(
            $mepr_db->saved_payment_methods,
            [
                'user_id' => $user_id,
                'token'   => $token,
            ]
        );

        return $row ? new self((array) $row) : null;
    }

    /**
     * Set a saved payment method as the default for the user.
     *
     * Unsets all existing defaults for the user, then marks the specified method
     * as the new default.
     *
     * @param  integer $user_id   The user ID.
     * @param  integer $method_id The ID of the saved payment method to set as default.
     * @return void
     */
    public static function set_default(int $user_id, int $method_id): void
    {
        global $wpdb;

        $mepr_db = new MeprDb();
        $table   = $mepr_db->saved_payment_methods;

        // Unset all defaults for this user.
        // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        $wpdb->query($wpdb->prepare("UPDATE {$table} SET `is_default`=0 WHERE `user_id`=%d", $user_id));

        // Set the specified method as default.
        // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        $wpdb->query($wpdb->prepare("UPDATE {$table} SET `is_default`=1 WHERE `id`=%d", $method_id));
    }

    /**
     * Create a new saved payment method from a Stripe PaymentIntent response.
     *
     * Extracts card details from the completed PaymentIntent's latest charge and
     * persists a new saved payment method record. If the same token is already saved
     * for this user, returns the existing record without creating a duplicate.
     *
     * Called after a successful cart checkout when save_card=true or when the cart
     * contains recurring (subscription) products.
     *
     * @param  integer $user_id        The ID of the logged-in user.
     * @param  string  $gateway        The gateway identifier (e.g., 'stripe').
     * @param  object  $payment_intent The Stripe PaymentIntent object (with latest_charge expanded).
     * @return self|null The saved payment method record, or null if the card could not be saved.
     */
    public static function save_from_payment_intent(int $user_id, string $gateway, object $payment_intent): ?self
    {
        // Extract the reusable Stripe payment method ID (requires setup_future_usage to have been set).
        $pm_id = $payment_intent->payment_method ?? null;
        if (!$pm_id) {
            return null;
        }

        // Idempotency: if this token is already saved for this user, return the existing record.
        $existing = self::find_by_token($user_id, $pm_id);
        if ($existing) {
            return $existing;
        }

        // Extract card details from the charge's payment_method_details.
        $charge = $payment_intent->latest_charge ?? null;
        $card   = $charge->payment_method_details->card ?? null;
        if (!$card) {
            return null;
        }

        // First card for this user becomes the default.
        $existing_methods = self::get_by_user($user_id);
        $is_default       = empty($existing_methods) ? 1 : 0;

        // Build and populate the model object.
        $method             = new self();
        $method->user_id    = $user_id;
        $method->gateway    = $gateway;
        $method->token      = $pm_id;
        $method->type       = 'card';
        $method->brand      = $card->brand ?? '';
        $method->last4      = $card->last4 ?? '';
        $method->exp_month  = $card->exp_month ?? 0;
        $method->exp_year   = $card->exp_year ?? 0;
        $method->is_default = $is_default;
        $method->created_at = current_time('mysql', true);

        $inserted_id = self::create($method);

        if (!$inserted_id) {
            return null;
        }

        $method->id = $inserted_id;

        return $method;
    }
}
