<?php

namespace FluentCartPro\App\Modules\SavedPaymentMethods;

use FluentCart\App\Models\Customer;
use FluentCart\App\Modules\PaymentMethods\StripeGateway\API\API;
use FluentCart\App\Modules\PaymentMethods\StripeGateway\Confirmations;
use FluentCart\Framework\Support\Arr;
use FluentCartPro\App\Modules\SavedPaymentMethods\PayPal\PayPalTokenRevoker;

/**
 * Set-default and delete for saved cards (SPM-05).
 *
 * Browser ids resolve through the customer-scoped repository. Setting the
 * default re-syncs Stripe metadata; removal drops the saved reference.
 */
class ManageCardService
{
    /**
     * Set a saved card as the customer's default. Propagates to the Stripe
     * customer's invoice_settings.default_payment_method so future renewals
     * draw on it.
     *
     * @return array ['code' => int, 'body' => array]
     */
    public function setDefault(Customer $customer, $opaqueId)
    {
        $repo = new SavedPaymentMethodRepository();
        $resolved = $repo->resolve($customer, $opaqueId);
        if (!$resolved) {
            return $this->fail(__('Card not found.', 'fluent-cart-pro'), 404);
        }

        $gateway = Arr::get($resolved, 'gateway');
        $vendorCustomerId = Arr::get($resolved, 'customer_id') ?: $customer->getMeta('stripe_customer_id');
        $paymentMethodId = Arr::get($resolved, 'pm.id');

        if (!$vendorCustomerId || !$paymentMethodId) {
            return $this->fail(__('Card not found.', 'fluent-cart-pro'), 404);
        }

        // Stripe only for now: setting the default writes through to the Stripe
        // customer's invoice_settings.default_payment_method, and there is no
        // agreed cross-gateway semantic for "account default" yet (PRD Q3). A
        // PayPal entry is still listed, chargeable and removable — just not
        // settable as the account-wide default.
        if ($gateway !== 'stripe') {
            return $this->fail(__('This payment method cannot be set as the default yet.', 'fluent-cart-pro'), 422);
        }

        $result = (new API())->createStripeObject('customers/' . $vendorCustomerId, [
            'invoice_settings' => ['default_payment_method' => $paymentMethodId],
        ]);
        if (is_wp_error($result)) {
            return $this->fail($result->get_error_message());
        }

        $this->reSyncMeta($customer, $vendorCustomerId, $paymentMethodId);

        return $this->ok($repo->list($customer));
    }

    /**
     * Remove a saved card unless it backs a live subscription. Stripe detach
     * failures do not prevent removing the local reference.
     *
     * @return array ['code' => int, 'body' => array]
     */
    public function delete(Customer $customer, $opaqueId)
    {
        $repo = new SavedPaymentMethodRepository();

        // Read the normalized card so we can honour the in-use flag.
        $card = null;
        foreach ($repo->list($customer) as $entry) {
            if ($entry['id'] === $opaqueId) {
                $card = $entry;
                break;
            }
        }
        if (!$card) {
            return $this->fail(__('Card not found.', 'fluent-cart-pro'), 404);
        }

        if (!empty($card['in_use_by_subscription'])) {
            return $this->fail(
                __('This card is the active payment method for a subscription. Update that subscription to a different card before removing it.', 'fluent-cart-pro'),
                422
            );
        }

        $resolved = $repo->resolve($customer, $opaqueId);
        $gateway = Arr::get($resolved, 'gateway');
        $paymentMethodId = Arr::get($resolved, 'pm.id');
        if (!$paymentMethodId) {
            return $this->fail(__('Card not found.', 'fluent-cart-pro'), 404);
        }

        if ($gateway === 'paypal') {
            $result = (new PayPalTokenRevoker())->revoke($paymentMethodId);
            if (is_wp_error($result)) {
                return $this->fail($result->get_error_message());
            }
        }

        // Report success only when the local reference was removed.
        if (!$repo->forget($customer, $opaqueId)) {
            return $this->fail(__('Card not found.', 'fluent-cart-pro'), 404);
        }

        if ($gateway === 'stripe') {
            $result = (new API())->createStripeObject('payment_methods/' . $paymentMethodId . '/detach', []);
            if (is_wp_error($result)) {
                $customer->addLog(
                    __('Saved card removed locally; Stripe detach failed', 'fluent-cart-pro'),
                    $result->get_error_message(),
                    'warning'
                );
            }
        }

        return $this->ok($repo->list($customer));
    }

    /**
     * Rewrite the saved_payment_method meta from Stripe's authoritative PM list.
     * Reuses core's writer; the $paymentMethodId is just the redisplay target
     * (a since-detached id is harmless — that call's result is not consumed).
     */
    private function reSyncMeta(Customer $customer, $vendorCustomerId, $paymentMethodId): void
    {
        $orderContext = (object) ['customer_id' => $customer->id];
        (new Confirmations())->savePaymentMethodToCustomerMeta($vendorCustomerId, $paymentMethodId, $orderContext);
    }

    private function ok(array $cards): array
    {
        return [
            'code' => 200,
            'body' => ['status' => 'success', 'data' => $cards],
        ];
    }

    private function fail($message, $code = 423): array
    {
        return [
            'code' => $code,
            'body' => ['status' => 'failed', 'message' => $message],
        ];
    }
}
