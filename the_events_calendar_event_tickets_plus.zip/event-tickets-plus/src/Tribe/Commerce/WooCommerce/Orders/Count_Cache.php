<?php
/**
 * WooCommerce cancelled/refunded ticket count cache.
 *
 * @since 6.10.2
 */

// phpcs:disable StellarWP.Classes.ValidClassName.NotSnakeCase -- Matches the legacy Tribe__ autoloader class-naming convention used by the sibling Orders classes.

/**
 * Persistent cache for WooCommerce cancelled/refunded ticket counts.
 *
 * The cancelled and refunded counts are produced by a SUM query that scans the
 * WooCommerce order tables per ticket. On large stores that query is expensive,
 * and it is re-run for every ticket on each admin list load. This cache stores
 * the resolved counts in a transient per ticket so the query only runs on a
 * cache miss, and is dropped whenever the underlying orders change.
 *
 * @since 6.10.2
 */
class Tribe__Tickets_Plus__Commerce__WooCommerce__Orders__Count_Cache {

	/**
	 * Transient key prefix; the ticket ID is appended.
	 *
	 * @since 6.10.2
	 *
	 * @var string
	 */
	const CACHE_KEY_PREFIX = 'tec_tickets_plus_woo_order_counts_';

	/**
	 * Cancelled-count array key.
	 *
	 * @since 6.10.2
	 *
	 * @var string
	 */
	const STATUS_CANCELLED = 'cancelled';

	/**
	 * Refunded-count array key.
	 *
	 * @since 6.10.2
	 *
	 * @var string
	 */
	const STATUS_REFUNDED = 'refunded';

	/**
	 * Default cache lifetime. Invalidation is event-driven, so this is only a
	 * safety net that bounds how long a count can stay stale when an order change
	 * races the query populating the cache and re-caches the pre-change value.
	 *
	 * @since 6.10.2
	 *
	 * @var int
	 */
	const EXPIRATION = HOUR_IN_SECONDS;

	/**
	 * Whether the count cache is enabled.
	 *
	 * @since 6.10.2
	 *
	 * @return bool Whether the count cache should be read from and written to.
	 */
	public function is_enabled(): bool {
		/**
		 * Filters whether the WooCommerce cancelled/refunded count cache is enabled.
		 *
		 * @since 6.10.2
		 *
		 * @param bool $enabled Whether the count cache is enabled. Default true.
		 */
		return tribe_is_truthy( apply_filters( 'tec_tickets_plus_woo_count_cache_enabled', true ) );
	}

	/**
	 * Get a cached count for a ticket and status.
	 *
	 * @since 6.10.2
	 *
	 * @param int    $ticket_id The ticket (product) ID.
	 * @param string $status    One of the STATUS_* constants.
	 *
	 * @return int|null The cached count, or null when disabled or not cached.
	 */
	public function get( int $ticket_id, string $status ): ?int {
		if ( ! $this->is_enabled() ) {
			return null;
		}

		$counts = get_transient( $this->cache_key( $ticket_id ) );

		if ( ! is_array( $counts ) || ! isset( $counts[ $status ] ) ) {
			return null;
		}

		return absint( $counts[ $status ] );
	}

	/**
	 * Store a count for a ticket and status.
	 *
	 * @since 6.10.2
	 *
	 * @param int    $ticket_id The ticket (product) ID.
	 * @param string $status    One of the STATUS_* constants.
	 * @param int    $count     The count to cache.
	 *
	 * @return void
	 */
	public function set( int $ticket_id, string $status, int $count ): void {
		if ( ! $this->is_enabled() ) {
			return;
		}

		$key    = $this->cache_key( $ticket_id );
		$counts = get_transient( $key );

		if ( ! is_array( $counts ) ) {
			$counts = [];
		}

		$counts[ $status ] = $count;

		set_transient( $key, $counts, $this->get_expiration() );
	}

	/**
	 * Drop every cached count for a ticket.
	 *
	 * @since 6.10.2
	 *
	 * @param int $ticket_id The ticket (product) ID.
	 *
	 * @return void
	 */
	public function delete_all_for_ticket( int $ticket_id ): void {
		delete_transient( $this->cache_key( $ticket_id ) );
	}

	/**
	 * The cache lifetime in seconds.
	 *
	 * @since 6.10.2
	 *
	 * @return int The number of seconds a cached count is kept.
	 */
	protected function get_expiration(): int {
		/**
		 * Filters the lifetime, in seconds, of a cached WooCommerce ticket count.
		 *
		 * @since 6.10.2
		 *
		 * @param int $expiration The cache lifetime in seconds. Default one hour.
		 */
		return absint( apply_filters( 'tec_tickets_plus_woo_count_cache_expiration', self::EXPIRATION ) );
	}

	/**
	 * Build the transient key for a ticket.
	 *
	 * @since 6.10.2
	 *
	 * @param int $ticket_id The ticket (product) ID.
	 *
	 * @return string The transient key.
	 */
	protected function cache_key( int $ticket_id ): string {
		return self::CACHE_KEY_PREFIX . $ticket_id;
	}
}
