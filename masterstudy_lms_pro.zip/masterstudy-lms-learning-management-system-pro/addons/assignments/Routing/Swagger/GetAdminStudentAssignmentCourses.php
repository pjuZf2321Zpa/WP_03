<?php

namespace MasterStudy\Lms\Pro\addons\assignments\Routing\Swagger;

use MasterStudy\Lms\Routing\Swagger\ResponseInterface;
use MasterStudy\Lms\Routing\Swagger\Route;

class GetAdminStudentAssignmentCourses extends Route implements ResponseInterface {
	public function response(): array {
		return array(
			'items' => array(
				'type' => 'array',
			),
		);
	}

	public function get_summary(): string {
		return 'Get Admin Student Assignment Courses';
	}

	public function get_description(): string {
		return 'Returns course filter options for the React student assignments admin page.';
	}
}
