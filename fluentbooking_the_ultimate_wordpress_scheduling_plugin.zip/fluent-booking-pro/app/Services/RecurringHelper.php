<?php

namespace FluentBookingPro\App\Services;

use FluentBooking\App\Services\Libs\RRule\RRule;
use FluentBooking\App\Services\Libs\RRule\RSet;
use FluentBooking\App\Services\DateTimeHelper;
use FluentBooking\App\Services\Helper;
use FluentBooking\Framework\Support\Arr;

class RecurringHelper
{
    public static function generateRRuleString($recurrenceConfig)
    {
        $frequency = strtoupper($recurrenceConfig['frequency']);
        $validFrequencies = ['DAILY', 'WEEKLY', 'MONTHLY', 'YEARLY'];
        if (!in_array($frequency, $validFrequencies)) {
            return null;
        }

        $rruleParts = [
            'FREQ'     => $frequency,
            'INTERVAL' => $recurrenceConfig['interval']
        ];

        // Handle end condition
        if (!empty($recurrenceConfig['count'])) {
            $rruleParts['COUNT'] = $recurrenceConfig['count'];
        } else if (!empty($recurrenceConfig['until'])) {
            $until = new \DateTime($recurrenceConfig['until'], new \DateTimeZone('UTC'));
            $rruleParts['UNTIL'] = $until->format('Ymd\THis\Z');
        }

        // Handle BYDAY for weekly/monthly
        if ($frequency === 'WEEKLY' && !empty($recurrenceConfig['byday'])) {
            $rruleParts['BYDAY'] = implode(',', $recurrenceConfig['byday']);
        } else if ($frequency === 'MONTHLY' && !empty($recurrenceConfig['bymonthday'])) {
            $rruleParts['BYMONTHDAY'] = $recurrenceConfig['bymonthday'];
        } else if ($frequency === 'MONTHLY' && !empty($recurrenceConfig['byday'])) {
            $rruleParts['BYDAY'] = $recurrenceConfig['byday'];
        }

        // Build RRule string
        $rruleString = 'RRULE:';
        $parts = [];
        foreach ($rruleParts as $key => $value) {
            $parts[] = $key . '=' . $value;
        }
        $rruleString .= implode(';', $parts);

        return $rruleString;
    }

    public static function addRecurrenceToGoogleUrl($url, $rruleString, $firstBooking, $timezone)
    {
        parse_str((string) wp_parse_url($url, PHP_URL_QUERY), $params);

        $params['dates'] = gmdate('Ymd\THis\Z', strtotime($firstBooking->start_time)) . '/' . gmdate('Ymd\THis\Z', strtotime($firstBooking->end_time));
        $params['recur'] = $rruleString;
        // Occurrences follow the guest's wall clock, so Google repeats in that zone.
        $params['ctz'] = $timezone;

        return strtok($url, '?') . '?' . http_build_query($params, '', '&', PHP_QUERY_RFC3986);
    }

    public static function getOccurrences($rruleString, $bookingData)
    {
        $duration = $bookingData['slot_minutes'];
        $timezone = DateTimeHelper::getValidatedTimeZone(Arr::get($bookingData, 'person_time_zone') ?: 'UTC');

        // The rule describes the booker's wall clock - "every Wednesday at 16:15"
        // - so it has to be anchored in their timezone. Anchored in UTC it holds
        // the UTC time fixed and walks the local one an hour at each DST change.
        $localStart = DateTimeHelper::convertToTimeZone($bookingData['start_time'], 'UTC', $timezone);
        $dtstart    = new \DateTime($localStart, new \DateTimeZone($timezone));

        try {
            $rset = new RSet();
            $rrule = new RRule($rruleString, $dtstart);

            $rset->addRRule($rrule);
            $occurrences = $rset->getOccurrences();

            return array_map(function($occurrence) use ($duration, $timezone) {
                $startTime = DateTimeHelper::convertToTimeZone($occurrence->format('Y-m-d H:i:s'), $timezone, 'UTC');

                return [
                    'start_time' => $startTime,
                    'end_time'   => gmdate('Y-m-d H:i:s', strtotime($startTime) + ($duration * 60))
                ];
            }, $occurrences);
        } catch (\Exception $e) {
            Helper::debugLog([
                'message' => $e->getMessage(),
                'method' => __METHOD__,
                'rrule' => $rruleString
            ]);
            return [];
        }
    }
}