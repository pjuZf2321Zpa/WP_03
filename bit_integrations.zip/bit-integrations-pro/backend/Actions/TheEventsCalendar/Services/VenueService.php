<?php

namespace BitApps\IntegrationsPro\Actions\TheEventsCalendar\Services;

use BitApps\IntegrationsPro\Actions\TheEventsCalendar\TheEventsCalendarHelper;

if (!\defined('ABSPATH')) {
    exit;
}

final class VenueService extends BaseService
{
    private const US_COUNTRY_NAMES = ['us', 'usa', 'united states', 'united states of america'];

    public function createVenue(): array
    {
        $error = $this->validateRequiredFields(['name' => __('Venue Name', 'bit-integrations-pro')]);

        if ($error !== null) {
            return $error;
        }

        $venueData = $this->getVenueArgs('publish');
        $venueData['ShowMap'] = $this->getShowMapValue($this->getBoolean('show_map') ?? true);
        $venueData['ShowMapLink'] = $this->getShowMapValue($this->getBoolean('show_map_link') ?? true);

        $venueId = tribe_create_venue($venueData);

        if (empty($venueId) || is_wp_error($venueId)) {
            return $this->errorResponse(__('Failed to create the venue. Check the field values and try again.', 'bit-integrations-pro'));
        }

        return $this->successResponse(__('The venue is created.', 'bit-integrations-pro'), TheEventsCalendarHelper::getVenueData($venueId));
    }

    public function updateVenue(): array
    {
        $error = $this->validateRequiredFields(['venue_id' => __('Venue ID', 'bit-integrations-pro')]);

        if ($error !== null) {
            return $error;
        }

        $venueId = (int) $this->getInteger('venue_id');

        if (!TheEventsCalendarHelper::isPostOfType($venueId, TheEventsCalendarHelper::VENUE_POST_TYPE)) {
            return $this->venueNotFound();
        }

        $venueData = $this->getVenueArgs(null, (string) get_post_meta($venueId, '_VenueCountry', true));
        $showMap = $this->getBoolean('show_map');
        $showMapLink = $this->getBoolean('show_map_link');

        if (empty($venueData) && $showMap === null && $showMapLink === null) {
            return $this->errorResponse(__('No venue field has a value. Map at least one field to update.', 'bit-integrations-pro'));
        }

        // TEC resets the map flags and the state to defaults when an update leaves them out.
        $venueData['ShowMap'] = $this->getShowMapValue($showMap ?? tribe_is_truthy(get_post_meta($venueId, '_VenueShowMap', true)));
        $venueData['ShowMapLink'] = $this->getShowMapValue($showMapLink ?? tribe_is_truthy(get_post_meta($venueId, '_VenueShowMapLink', true)));
        $venueData['StateProvince'] = $venueData['StateProvince'] ?? get_post_meta($venueId, '_VenueStateProvince', true);

        tribe_update_venue($venueId, $venueData);

        return $this->successResponse(__('The venue is updated.', 'bit-integrations-pro'), TheEventsCalendarHelper::getVenueData($venueId));
    }

    public function deleteVenue(): array
    {
        $error = $this->validateRequiredFields(['venue_id' => __('Venue ID', 'bit-integrations-pro')]);

        if ($error !== null) {
            return $error;
        }

        $venueId = (int) $this->getInteger('venue_id');
        $venueData = TheEventsCalendarHelper::getVenueData($venueId);

        if (empty($venueData)) {
            return $this->venueNotFound();
        }

        $isPermanent = (bool) $this->getBoolean('delete_permanently');

        if (!$this->removePost($venueId, $isPermanent)) {
            return $this->errorResponse(__('Failed to delete the venue. Check that the venue exists and try again.', 'bit-integrations-pro'));
        }

        $venueData['deleted_permanently'] = $isPermanent;

        return $this->successResponse(__('The venue is deleted.', 'bit-integrations-pro'), $venueData);
    }

    private function getShowMapValue(bool $value): string
    {
        return $value ? 'true' : 'false';
    }

    private function getVenueArgs(?string $defaultStatus = null, string $currentCountry = ''): array
    {
        $state = $this->getString('state');
        $country = strtolower($this->hasValue('country') ? $this->getString('country') : trim($currentCountry));
        $isUnitedStates = \in_array($country, self::US_COUNTRY_NAMES, true);

        $venueArgs = [
            'Venue'         => $this->getString('name'),
            'Description'   => $this->getString('description'),
            'Address'       => $this->getString('address'),
            'City'          => $this->getString('city'),
            'Country'       => $this->getString('country'),
            'StateProvince' => $state,
            'State'         => $isUnitedStates ? $state : '',
            'Province'      => $isUnitedStates ? '' : $state,
            'Zip'           => $this->getString('zip'),
            'Phone'         => $this->getString('phone'),
            'URL'           => $this->getString('website'),
            'post_status'   => (string) $this->getPostStatus($defaultStatus),
        ];

        return array_filter($venueArgs, 'strlen');
    }

    private function venueNotFound(): array
    {
        return $this->errorResponse(__('Venue not found. Map the ID of an existing venue.', 'bit-integrations-pro'));
    }
}
