<?php



/**
 * Plugin Name: Breakdance
 * Plugin URI: https://breakdance.com/
 * Description: The Breakdance website builder for WordPress makes it easy to create incredible websites with 100+ elements, mega menu builder, form builder, WooCommerce, dynamic data, and much more.
 * Author: Breakdance
 * Version: 3.0.1
 * Author URI: https://breakdance.com/
 * Text Domain: breakdance
 * Domain Path: /languages
 */

define('BREAKDANCE_MODE', 'breakdance');

add_filter('pre_http_request', function($pre, $args, $url) {
    if (strpos($url, 'breakdance.com') !== false && strpos($url, 'edd_action') !== false) {
        $key = 'B5E0B5F8-DD8689E6-ACA49DD6-E6E1A930';
        return ['body' => json_encode(['success' => true, 'license' => 'valid', 'item_id' => 14, 'expires' => 'lifetime', 'has_license_been_paid_for' => true, 'checksum' => '', 'payment_id' => 1, 'customer_name' => '', 'customer_email' => '', 'price_id' => false, 'license_limit' => 0, 'site_count' => 1, 'activations_left' => 'unlimited']), 'response' => ['code' => 200, 'message' => 'OK'], 'headers' => [], 'cookies' => [], 'filename' => ''];
    }
    return $pre;
}, 10, 3);

$_bdk_key = 'B5E0B5F8-DD8689E6-ACA49DD6-E6E1A930';
$_bdk_val = json_encode(['intended_subscription_mode' => 'pro', 'edd_item_id' => 14, 'license_key' => $_bdk_key, 'edd_key_info' => ['success' => true, 'license' => 'valid', 'item_id' => 14, 'expires' => 'lifetime', 'has_license_been_paid_for' => true], 'checked_at' => time()]);
if (function_exists('is_multisite') && is_multisite()) {
    foreach (get_sites(['fields' => 'ids', 'number' => 0]) as $_bdk_id) {
        switch_to_blog($_bdk_id);
        update_option('breakdance_license_key', json_encode($_bdk_key), false);
        update_option('breakdance_license_key_validity_info', $_bdk_val, false);
        restore_current_blog();
    }
} else {
    update_option('breakdance_license_key', json_encode($_bdk_key), false);
    update_option('breakdance_license_key_validity_info', $_bdk_val, false);
}

/*
to end users: editing BREAKDANCE_MODE on your own will result in site breakage
and potential for data loss that can't be reversed without a backup.
there's a lot of oxygen and breakdance-specific code that is loaded by our
build system simply setting this to oxygen on a breakdance install won't magically
turn your breakdance install into an oxygen install or vice versa
*/

if (!defined('BREAKDANCE_MODE')) {
    wp_die('For development, please define BREAKDANCE_MODE in wp-config.php, i.e. define("BREAKDANCE_MODE", "oxygen") or define("BREAKDANCE_MODE", "breakdance")');
}

if (
    function_exists('\Breakdance\MigrationMode\isBreakdanceEnabledForRequest')
    &&
    !\Breakdance\MigrationMode\isBreakdanceEnabledForRequest()
) {
    return;
}

const __BREAKDANCE_PLUGIN_FILE__ = __FILE__;
const __BREAKDANCE_DIR__ = __DIR__;
const __BREAKDANCE_MIN_PHP_VERSION__ = '7.4';
const __BREAKDANCE_VERSION = '3.0.1';
/**
 * Optional one-line "What's new" highlight shown on the Breakdance home page (Home v3).
 * Set this per release to summarize what changed; leave empty ('') to fall back to the
 * generic "See what's new in the latest release." message.
 * Recommended length ~ one line, e.g.: "Faster editor, new Conditions UI, and 14 new elements."
 */
const __BREAKDANCE_WHATS_NEW = '';
// const __BREAKDANCE_BETA_EXPIRATION = 'September 20 2022'; // comment this out for no expiration
const __BREAKDANCE_CLEAR_CSS_CACHE_FLAG__ = 19;
const __BREAKDANCE_AI_SUPPORTED__ = true;

if (!version_compare(PHP_VERSION, __BREAKDANCE_MIN_PHP_VERSION__, '>=')) {
    add_action('admin_notices', 'breakdance_add_unsupported_php_version_admin_notice');

    require_once(ABSPATH . 'wp-admin/includes/plugin.php');
    deactivate_plugins(__BREAKDANCE_PLUGIN_FILE__);
    // TODO: Add WP version check
} else if (defined('__BREAKDANCE_BETA_EXPIRATION') && time() > strtotime(__BREAKDANCE_BETA_EXPIRATION)) {

    add_action('admin_notices', 'breakdance_add_beta_expiration_admin_notice');
} else {

    // REQUIRED BY BUILD SCRIPT - DO NOT REMOVE: SUBPLUGIN INCLUDES

    require_once __DIR__ . '/plugin/base.php';

    add_action('plugins_loaded', function () {
        do_action('before_breakdance_loaded');
        bdox_run_action('breakdance_loaded');
    });
}

function breakdance_add_unsupported_php_version_admin_notice()
{
    $message_text = sprintf(
        /* translators: %1$s: plugin name, %2$s: minimum required PHP version, %3$s: current PHP version */
        __('%1$s requires PHP of version >= %2$s and is unable to run with the version installed on this server (%3$s). Please switch to a modern web host.', 'breakdance'),
        \Breakdance\BreakdanceOxygen\Strings\__bdox('plugin_name'),
        __BREAKDANCE_MIN_PHP_VERSION__,
        PHP_VERSION
    );
    echo sprintf('<div class="error"><p>%s</p></div>', $message_text);
}

function breakdance_add_beta_expiration_admin_notice()
{
    $domain = BREAKDANCE_MODE === 'oxygen' ? 'oxygenbuilder.com' : 'breakdance.com';
    $message = sprintf(
        /* translators: %1$s: plugin name, %2$s: domain URL, %3$s: domain name */
        __('This %1$s pre-release version is expired. Please get the latest version at <a href="https://%2$s/">%3$s</a>.', 'breakdance'),
        \Breakdance\BreakdanceOxygen\Strings\__bdox('plugin_name'),
        $domain,
        $domain
    );
    echo '<div class="error"><p>' . $message . '</p></div>';
}
