<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Core\Util\Hooks;
use BitApps\IntegrationsPro\Triggers\ContactFormEmail\ContactFormEmailController;

Hooks::add('cfte_process_data', [ContactFormEmailController::class, 'handleFormSubmitted'], 99);
