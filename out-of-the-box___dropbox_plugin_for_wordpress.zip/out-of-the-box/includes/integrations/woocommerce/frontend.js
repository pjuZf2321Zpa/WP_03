jQuery(document).ready(function ($) {
    'use strict';
    $.widget('cp.OutoftheBoxWC', {
        options: {},

        _create: function () {
            /* Ignite! */
            this._initiate();
        },

        _destroy: function () {
            return this._super();
        },

        _setOption: function (key, value) {
            this._super(key, value);
        },

        _initiate: function () {
            let self = this;
            self._initButtons();
            self._initDetails();
        },

        _initButtons: function () {
            let self = this;

            $('.wpcp-outofthebox .wpcp-wc-open-box').on('click', function (e) {
                self.openUploadBox($(this));
            });
        },

        _initDetails: function () {
            let self = this;

            $('.wpcp-outofthebox.wpcp-upload-container').each(function () {
                let $container = $(this);
                let item_id = $container.data('item-id');
                let product_id = $container.data('product-id');
                let variation_id = $container.data('variation-id') || 0;
                let listtoken = $container.find('.OutoftheBox').data('token');

                if (item_id) {
                    self._loadDetails({ item_id: item_id, listtoken: listtoken, $container: $container });
                } else if (product_id) {
                    self._loadDetails({
                        product_id: product_id,
                        variation_id: variation_id,
                        listtoken: listtoken,
                        $container: $container,
                    });
                }
            });
        },

        _loadDetails: function (ctx) {
            let self = this;
            let $container = ctx.$container;
            let $upload_list = $container.find('.wpcp-uploads-list');
            let $badge = $container.find('.wpcp-wc-open-box .wpcp-uploads-badge');

            let payload = {
                action: 'outofthebox-get-filelist',
                listtoken: ctx.listtoken,
                _ajax_nonce: self.options.refresh_nonce,
            };

            if (ctx.item_id) {
                payload.type = 'wc-item-details';
                payload.item_id = ctx.item_id;
            } else if (ctx.product_id) {
                payload.type = 'wc-product-temp';
                payload.product_id = ctx.product_id;
                payload.variation_id = ctx.variation_id || 0;
            } else {
                return;
            }

            $.ajax({
                type: 'POST',
                url: self.options.ajax_url,
                data: payload,
                dataType: 'json',
                complete: function () {
                    $upload_list.addClass('wpcp-uploads-received');
                },
                success: function (response) {
                    $upload_list.html('');

                    if ($.isPlainObject(response) === false || $.isEmptyObject(response)) {
                        $upload_list.addClass('no-uploads-found');
                        $badge.attr('hidden', 'hidden').text('');
                        return;
                    }

                    $upload_list.removeClass('no-uploads-found');

                    let count = 0;
                    $.each(response, function (id, entry) {
                        if (entry === '' || !entry) {
                            return;
                        }
                        count++;
                        let icon = entry.icon ? `<img class="wpcp-uploads-list-item-icon" src="${entry.icon}"/>` : '';
                        $upload_list.append(
                            `<li>${icon}<div class="wpcp-uploads-list-item-name">${entry.name}</div><div class="wpcp-uploads-list-item-download"><a href="${entry.url}" download="${entry.name}"><i class="eva eva-download eva-lg"></i></a></div></li>`,
                        );
                    });

                    if (count > 0) {
                        $badge.text(count).removeAttr('hidden');
                    } else {
                        $badge.attr('hidden', 'hidden').text('');
                    }
                },
            });
        },

        openUploadBox: function (button) {
            let self = this;

            let $trigger = $(button);
            let $container = $trigger.closest('.wpcp-upload-container');
            var upload_box = $container.find('.woocommerce-order-upload-box');
            var item_id = $container.data('item-id');
            var product_id = $container.data('product-id');
            var variation_id = $container.data('variation-id') || 0;
            var listtoken = upload_box.find('[data-token]').data('token');

            /* Close any open modal windows */
            $('#wpcp-modal-upload-action').remove();

            /* Build the Upload Dialog */
            let modalbuttons = `<button class="button wpcp-modal-cancel-btn" data-action="cancel" type="button" onclick="modal_upload_action.close();" title="${self.options.str_close_title}">${self.options.str_close_title}</button>`;

            let order_badge = upload_box.attr('data-order')
                ? `<div class="wpcp-modal-badge"><i class="eva eva-cube-outline eva-lg"></i> ${upload_box.attr('data-order')}</div>`
                : '';

            let modalheader = $(
                `<div class="wpcp-modal-header" tabindex="0">
                    <h2 id="uploads"><i class="eva eva-attach"></i> ${upload_box.attr('data-title')}</h2>
                    <div class="wpcp-modal-badges-group">
                        ${order_badge}
                        <div class="wpcp-modal-badge"><i class="eva eva-pricetags-outline eva-lg"></i> ${upload_box.attr(
                            'data-product-name',
                        )}</div>
                    </div>
                    <a tabindex="0" class="close-button" title="${
                        self.options.str_close_title
                    }" onclick="modal_upload_action.close();"><i class="eva eva-close eva-lg" aria-hidden="true"></i></a>
                </div>`,
            );
            let modalbody = $('<div class="wpcp-modal-body" tabindex="0"></div>');
            let modalfooter = $(
                `<div class="wpcp-modal-footer"><div class="wpcp-modal-buttons">${modalbuttons}</div></div>`,
            );

            let modaldialog = $(
                `<div id="wpcp-modal-upload-action" class="OutoftheBox wpcp wpcp-modal wpcp-woocommerce-upload-container ${self.options.content_skin}"><div class="modal-dialog"><div class="modal-content"></div></div></div>`,
            );

            $('body').append(modaldialog);
            $('#wpcp-modal-upload-action .modal-content').append(modalheader, modalbody, modalfooter);

            /* Move the upload box into the modal */
            $('.wpcp-modal-body').append(upload_box);
            upload_box.show();

            /* Set the button actions */
            $('#wpcp-modal-upload-action .wpcp-modal-confirm-btn').on('click', function (e) {
                modal_action.close();
            });

            /* Open the dialog */
            let modal_action = new RModal(document.getElementById('wpcp-modal-upload-action'), {
                bodyClass: 'rmodal-open',
                dialogOpenClass: 'animated slideInDown',
                dialogCloseClass: 'animated slideOutUp',
                escapeClose: true,
                afterClose() {
                    upload_box.hide();
                    $trigger.after(upload_box);

                    if (item_id) {
                        self._loadDetails({
                            item_id: item_id,
                            listtoken: listtoken,
                            $container: $container,
                        });
                    } else if (product_id) {
                        self._loadDetails({
                            product_id: product_id,
                            variation_id: variation_id,
                            listtoken: listtoken,
                            $container: $container,
                        });
                    }
                },
            });

            document.addEventListener(
                'keydown',
                function (ev) {
                    modal_action.keydown(ev);
                },
                false,
            );
            modal_action.open();
            window.modal_upload_action = modal_action;
            return false;
        },
    });
});

// Initiate the Module!
jQuery(document).ready(function ($) {
    $(document).OutoftheBoxWC(OutoftheBox_vars);
});
