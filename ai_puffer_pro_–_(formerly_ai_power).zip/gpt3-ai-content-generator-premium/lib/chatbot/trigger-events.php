<?php

namespace WPAICG\Lib\Chat\Triggers\Manager;

use WPAICG\Lib\Chat\Triggers\AIPKit_Trigger_Storage;
use WPAICG\Lib\Chat\Triggers\AIPKit_Trigger_Condition_Evaluator;
use WPAICG\Lib\Chat\Triggers\AIPKit_Trigger_Action_Executor;
use WPAICG\Chat\Storage\LogStorage;

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

if (!class_exists(AIPKit_Trigger_Fetcher::class)) {
    /**
     * AIPKit_Trigger_Fetcher
     *
     * Responsible for fetching and filtering active triggers for a specific event.
     */
    class AIPKit_Trigger_Fetcher {

        private $trigger_storage;

        public function __construct(AIPKit_Trigger_Storage $trigger_storage) {
            $this->trigger_storage = $trigger_storage;
        }

        /**
         * Retrieves all active triggers for a given bot and event, sorted by priority.
         *
         * @param int $bot_id The ID of the chatbot CPT.
         * @param string $event_name The name of the event to retrieve triggers for (e.g., "user_message_received").
         * @return array An array of active trigger objects, sorted by priority (ascending). Returns empty array on failure or if no triggers found.
         */
        public function get_active_triggers_for_event(int $bot_id, string $event_name): array {
            if (empty($bot_id) || empty($event_name)) {
                return [];
            }

            $all_triggers_for_bot = $this->trigger_storage->get_triggers($bot_id);

            if (empty($all_triggers_for_bot)) {
                return [];
            }

            $active_event_triggers = [];
            foreach ($all_triggers_for_bot as $trigger) {
                if (!is_array($trigger) ||
                    !isset($trigger['is_active']) ||
                    !isset($trigger['event_name']) ||
                    !isset($trigger['priority'])) {
                    continue;
                }

                $is_active = ($trigger['is_active'] === true || $trigger['is_active'] === 1 || $trigger['is_active'] === '1');
                if ($is_active && $trigger['event_name'] === $event_name) {
                    $active_event_triggers[] = $trigger;
                }
            }

            usort($active_event_triggers, function ($a, $b) {
                $priority_a = $a['priority'] ?? 10;
                $priority_b = $b['priority'] ?? 10;
                return $priority_a <=> $priority_b;
            });

            return $active_event_triggers;
        }
    }
}

if (!class_exists(AIPKit_Trigger_Context_Updater::class)) {
    /**
     * AIPKit_Trigger_Context_Updater
     *
     * Handles modifying the context data based on executed trigger actions.
     */
    class AIPKit_Trigger_Context_Updater {

        public function __construct() {
            // Preserve the public no-argument constructor.
        }

        /**
         * Updates the context data based on the result of an executed action.
         *
         * @param array $current_context_data The current context data.
         * @param array $action_result The result array from an executed action.
         * @return array The potentially modified context data.
         */
        public function update_context_from_action(array $current_context_data, array $action_result): array {
            $modified_context = $current_context_data;
            $action_type = $action_result['type'] ?? null;

            switch ($action_type) {
                case 'inject_context':
                    $placement = $action_result['placement'] ?? null;
                    $content_to_inject = $action_result['content'] ?? ''; // Content is already processed by placeholder processor

                    if ($placement === 'system_instruction_prepend') {
                        $modified_context['system_instruction'] =
                            $content_to_inject . "\n" . ($modified_context['system_instruction'] ?? '');
                    } elseif ($placement === 'system_instruction_append') {
                        $modified_context['system_instruction'] =
                            ($modified_context['system_instruction'] ?? '') . "\n" . $content_to_inject;
                    } elseif ($placement === 'history_prepend' && isset($modified_context['current_history'])) {
                        // Assuming content_to_inject is a simple string to be added as a user message
                        // This structure should match the history format used by the AI_Service
                        array_unshift($modified_context['current_history'], ['role' => 'user', 'content' => $content_to_inject]);
                    }
                    break;

                case 'set_variable':
                    $scope = $action_result['scope'] ?? null;
                    $key   = $action_result['key'] ?? null;
                    $value = $action_result['value'] ?? null; // Value is already processed by placeholder processor

                    if ($scope === 'bot_context' && $key !== null) {
                        $modified_context[$key] = $value;
                    }
                    // 'user_meta' scope is handled directly by the AIPKit_Action_Set_Variable class,
                    // so it does not directly modify the $modified_context array here.
                    break;

                // Other action types might not modify the context in this way
            }

            return $modified_context;
        }
    }
}

if (!class_exists(AIPKit_Trigger_Event_Processor::class)) {
    /**
     * AIPKit_Trigger_Event_Processor
     *
     * Processes trigger events and records action results using the injected services.
     */
    class AIPKit_Trigger_Event_Processor
    {
        private $fetcher;
        private $condition_evaluator;
        private $action_executor;
        private $context_updater;
        private $log_storage;

        /**
         * Constructor.
         *
         * @param AIPKit_Trigger_Fetcher $fetcher
         * @param AIPKit_Trigger_Condition_Evaluator $condition_evaluator
         * @param AIPKit_Trigger_Action_Executor $action_executor
         * @param AIPKit_Trigger_Context_Updater $context_updater
         * @param LogStorage|null $log_storage
         */
        public function __construct(
            AIPKit_Trigger_Fetcher $fetcher,
            AIPKit_Trigger_Condition_Evaluator $condition_evaluator,
            AIPKit_Trigger_Action_Executor $action_executor,
            AIPKit_Trigger_Context_Updater $context_updater,
            ?LogStorage $log_storage = null
        ) {
            $this->fetcher = $fetcher;
            $this->condition_evaluator = $condition_evaluator;
            $this->action_executor = $action_executor;
            $this->context_updater = $context_updater;
            $this->log_storage = $log_storage;
        }

        public function get_fetcher(): AIPKit_Trigger_Fetcher
        {
            return $this->fetcher;
        }
        public function get_condition_evaluator(): AIPKit_Trigger_Condition_Evaluator
        {
            return $this->condition_evaluator;
        }
        public function get_action_executor(): AIPKit_Trigger_Action_Executor
        {
            return $this->action_executor;
        }
        public function get_context_updater(): AIPKit_Trigger_Context_Updater
        {
            return $this->context_updater;
        }
        public function get_log_storage(): ?LogStorage
        {
            return $this->log_storage;
        }

        /** Processes active triggers in priority order and returns their accumulated effects. */
        public function process(int $bot_id, string $event_name, array $context_data): array
        {
            $result_accumulator = [
                'status'                   => 'processed',
                'message_to_user'          => null,
                'actions_executed'         => [],
                'modified_context_data'    => $context_data,
                'block_further_triggers'   => false,
                'stop_ai_processing'       => false,
                'display_form_event_data'  => null,
                'message_id'               => null,
            ];

            // Get dependencies from the processor instance
            $fetcher = $this->get_fetcher();
            $condition_evaluator = $this->get_condition_evaluator();
            $action_executor = $this->get_action_executor();
            $context_updater = $this->get_context_updater();
            $log_storage = $this->get_log_storage();

            // --- Fetch active triggers FIRST ---
            $active_triggers = $fetcher->get_active_triggers_for_event($bot_id, $event_name);
            if (empty($active_triggers)) {
                // If no active triggers for this event, don't log "start" and return immediately
                return $result_accumulator;
            }

            // Prioritize direct context values, fallback to base_log_data sub-array if context is nested (e.g., from chat AJAX)
            // For system_error_occurred, conversation_uuid and module should come directly from $context_data.
            $base_log_data_for_processing = [
                'conversation_uuid' => $context_data['conversation_uuid'] ?? ($context_data['base_log_data']['conversation_uuid'] ?? null),
                'module'            => $context_data['module'] ?? ($context_data['base_log_data']['module'] ?? 'chat_trigger_system_unknown_origin'), // More descriptive default
                'bot_id'            => $context_data['bot_id'] ?? ($context_data['base_log_data']['bot_id'] ?? $bot_id), // Use passed $bot_id if available
                'user_id'           => $context_data['user_id'] ?? ($context_data['base_log_data']['user_id'] ?? null),
                'session_id'        => $context_data['session_id'] ?? ($context_data['base_log_data']['session_id'] ?? null),
                'is_guest'          => $context_data['is_guest'] ?? ($context_data['base_log_data']['is_guest'] ?? (!(isset($context_data['user_id']) && $context_data['user_id'] > 0))),
                'ip_address'        => $context_data['client_ip'] ?? ($context_data['ip_address'] ?? ($context_data['base_log_data']['ip_address'] ?? null)),
                'role'              => $context_data['user_wp_role'] ?? ($context_data['role'] ?? ((isset($context_data['user_roles']) && is_array($context_data['user_roles'])) ? implode(', ', $context_data['user_roles']) : ($context_data['base_log_data']['role'] ?? null))),
            ];

            $filtered_triggers = [];
            foreach ($active_triggers as $trigger) {
                $event_params = $trigger['event_params'] ?? [];
                if (!is_array($event_params) || empty($event_params)) {
                    $filtered_triggers[] = $trigger;
                    continue;
                }

                $params_match = true;
                if ($event_name === 'form_submitted' && !empty($event_params['form_id_is'])) {
                    $form_id = isset($context_data['form_id']) ? (string) $context_data['form_id'] : '';
                    $expected_form_id = (string) $event_params['form_id_is'];
                    if ($form_id === '' || $form_id !== $expected_form_id) {
                        $params_match = false;
                    }
                }

                if ($params_match) {
                    $filtered_triggers[] = $trigger;
                } else {
                    $this->log_trigger_event(
                        $log_storage,
                        $base_log_data_for_processing,
                        'trigger_skipped',
                        sprintf("Trigger '%s' (ID: %s) skipped: Event parameters did not match.", $trigger['name'] ?? 'Unnamed Trigger', $trigger['id'] ?? 'unknown_trigger_id'),
                        [
                            'trigger_id' => $trigger['id'] ?? 'unknown_trigger_id',
                            'trigger_name' => $trigger['name'] ?? 'Unnamed Trigger',
                            'event_name_processed' => $event_name,
                            'reason' => 'Event parameters did not match',
                        ]
                    );
                }
            }

            $active_triggers = $filtered_triggers;
            if (empty($active_triggers)) {
                return $result_accumulator;
            }

            // --- Log start of processing only if there are active triggers ---
            $this->log_trigger_event(
                $log_storage,
                $base_log_data_for_processing,
                'trigger_processing_start',
                sprintf("Trigger processing started for event: %s", $event_name),
                [
                    'trigger_id' => 'N/A',
                    'trigger_name' => 'N/A',
                    'event_name_processed' => $event_name,
                ]
            );

            foreach ($active_triggers as $trigger) {
                $conditions = $trigger['conditions'] ?? [];
                $action_config = $trigger['action'] ?? null;
                $trigger_id = $trigger['id'] ?? 'unknown_trigger_id';
                $trigger_name = $trigger['name'] ?? 'Unnamed Trigger';

                if (empty($action_config)) {
                    $this->log_trigger_event(
                        $log_storage,
                        $base_log_data_for_processing,
                        'trigger_skipped',
                        sprintf("Trigger '%s' (ID: %s) skipped: No action configured.", $trigger_name, $trigger_id),
                        [
                            'trigger_id' => $trigger_id,
                            'trigger_name' => $trigger_name,
                            'event_name_processed' => $event_name,
                            'reason' => 'No action configured',
                        ]
                    );
                    continue;
                }

                $conditions_met = $condition_evaluator->are_conditions_met($conditions, $result_accumulator['modified_context_data']);

                if ($conditions_met) {
                    $action_type_to_execute = $action_config['type'] ?? 'unknown';
                    $action_payload_for_log = $action_config['payload'] ?? [];
                    if ($action_type_to_execute === 'set_variable' && isset($action_config['value'])) {
                        $action_payload_for_log['value'] = $action_config['value'];
                    }

                    $this->log_trigger_event(
                        $log_storage,
                        $base_log_data_for_processing,
                        'action_execution_start',
                        sprintf("Trigger '%s': Action '%s' started.", $trigger_name, $action_type_to_execute),
                        [
                            'trigger_id' => $trigger_id,
                            'trigger_name' => $trigger_name,
                            'event_name_processed' => $event_name,
                            'action_type' => $action_type_to_execute,
                            'action_payload_summary' => $this->summarize_payload_for_log($action_type_to_execute, $action_payload_for_log)
                        ]
                    );

                    $context_for_action = $result_accumulator['modified_context_data'];
                    $context_for_action['current_trigger_id'] = $trigger_id;
                    $context_for_action['current_trigger_name'] = $trigger_name;
                    $context_for_action['event_type'] = $event_name;

                    $action_result = $action_executor->execute_action($action_config, $context_for_action, $bot_id);

                    $action_status = 'success';
                    $action_result_summary = "Action completed.";
                    $action_error_details = null;

                    if (is_wp_error($action_result)) {
                        $action_status = 'error';
                        $action_result_summary = "Error: " . $action_result->get_error_message();
                        $action_error_details = $action_result->get_error_code();
                        $result_accumulator['status'] = 'error';
                        $result_accumulator['message_to_user'] = $action_result->get_error_message();
                        $result_accumulator['block_further_triggers'] = true;
                    } else if (is_array($action_result)) {
                        $executed_action_type = $action_result['type'] ?? $action_type_to_execute;
                        $action_result_summary = "Action '{$executed_action_type}' completed.";

                        if ($executed_action_type === 'bot_reply') {
                            $action_result_summary .= " Reply Snippet: '" . esc_html(mb_substr($action_result['message'] ?? '', 0, 50)) . "...'. Stop AI: " . (($action_result['stop_ai'] ?? false) ? 'Yes' : 'No') . ".";
                        } elseif ($executed_action_type === 'block_message') {
                            $action_result_summary .= " Reason: '" . esc_html($action_result['reason'] ?? 'N/A') . "'.";
                        } elseif ($executed_action_type === 'call_webhook' || $executed_action_type === 'webhook_sent') {
                            $action_result_summary .= " Status: " . esc_html($action_result['status'] ?? 'unknown') . ". HTTP: " . esc_html($action_result['http_code'] ?? 'N/A') . ".";
                            if (isset($action_result['response_body_snippet'])) {
                                $action_result_summary .= " Response Snippet: '" . esc_html(mb_substr($action_result['response_body_snippet'], 0, 30)) . "...'.";
                            }
                            if (($action_result['status'] ?? '') === 'failed') {
                                $action_status = 'error';
                            }
                        } elseif ($executed_action_type === 'display_form') {
                            $form_id_display = isset($action_result['form_definition']['form_id']) ? $action_result['form_definition']['form_id'] : 'N/A';
                            $action_result_summary .= " Form ID: '" . esc_html($form_id_display) . "'.";
                        } elseif ($executed_action_type === 'form_data_logged_to_chat'){
                            $action_result_summary .= " Form ID: '" . esc_html($action_result['form_id'] ?? 'N/A') . "' logged to message ID: " . esc_html($action_result['message_id'] ?? 'N/A') . ".";
                        } elseif ($executed_action_type === 'inject_context') {
                             $action_result_summary .= " Placement: " . esc_html($action_result['placement'] ?? 'unknown') . ". Content Snippet: '" . esc_html(mb_substr($action_result['content'] ?? '', 0, 30)) . "...'.";
                        } elseif ($executed_action_type === 'set_variable') {
                            $action_result_summary .= " Scope: " . esc_html($action_config['payload']['scope'] ?? 'N/A') . ", Key: '" . esc_html($action_config['payload']['key'] ?? 'N/A') . "'.";
                        }
                    }

                    $this->log_trigger_event(
                        $log_storage,
                        $base_log_data_for_processing,
                        'action_execution_result',
                        sprintf("Trigger '%s': Action '%s' completed. Status: %s.", $trigger_name, $action_type_to_execute, $action_status),
                        [
                            'trigger_id' => $trigger_id,
                            'trigger_name' => $trigger_name,
                            'event_name_processed' => $event_name,
                            'action_type' => $action_type_to_execute,
                            'status' => $action_status,
                            'result_summary' => $action_result_summary,
                            'error_details' => $action_error_details
                        ]
                    );

                    if (is_wp_error($action_result)) {
                        break;
                    }
                    if (is_array($action_result)) {
                        $result_accumulator['actions_executed'][] = $action_result;
                        $result_accumulator['modified_context_data'] = $context_updater->update_context_from_action(
                            $result_accumulator['modified_context_data'],
                            $action_result
                        );

                        $action_type_executed = $action_result['type'] ?? '';
                        switch ($action_type_executed) {
                            case 'bot_reply':
                                $result_accumulator['message_to_user'] = $action_result['message'] ?? null;
                                $result_accumulator['message_id'] = $action_result['message_id'] ?? ('trigger-reply-' . uniqid());
                                if ($action_result['stop_ai'] ?? false) {
                                    $result_accumulator['stop_ai_processing'] = true;
                                }
                                break;
                            case 'block_message':
                                $result_accumulator['status'] = 'blocked';
                                $result_accumulator['message_to_user'] = $action_result['reason'] ?? __('Your message could not be processed at this time.', 'gpt3-ai-content-generator');
                                $result_accumulator['message_id'] = $action_result['message_id'] ?? ('trigger-block-' . uniqid());
                                $result_accumulator['stop_ai_processing'] = $action_result['stop_ai'] ?? true;
                                $result_accumulator['block_further_triggers'] = $action_result['block_further_triggers'] ?? true;
                                break;
                            case 'display_form':
                                $result_accumulator['display_form_event_data'] = $action_result;
                                $result_accumulator['stop_ai_processing'] = true;
                                $result_accumulator['block_further_triggers'] = $action_result['block_further_triggers'] ?? true;
                                break;
                        }
                    }

                    if ($result_accumulator['block_further_triggers']) {
                        break;
                    }
                } // End if ($conditions_met)
            } // End foreach ($active_triggers as $trigger)

            if ($result_accumulator['status'] === 'processed' && $result_accumulator['stop_ai_processing']) {
                if ($result_accumulator['display_form_event_data']) {
                    // Status remains 'processed', but 'stop_ai_processing' is true.
                } elseif ($result_accumulator['message_to_user']) {
                    $result_accumulator['status'] = 'ai_stopped';
                }
            }
            return $result_accumulator;
        }

        private function log_trigger_event(?LogStorage $log_storage, array $base_log_data, string $log_subtype, string $content, array $details): void
        {
            if (!$log_storage) {
                return;
            }

            // Ensure essential base log data is present for ConversationLogger
            $required_base_keys = ['bot_id', 'user_id', 'session_id', 'conversation_uuid', 'module', 'is_guest', 'ip_address', 'role'];
            foreach ($required_base_keys as $key) {
                if (!array_key_exists($key, $base_log_data)) {
                    // Provide a default or null if a key is missing to prevent PHP notices
                    $base_log_data[$key] = ($key === 'is_guest') ? 1 : null;
                }
            }

            $log_entry = array_merge($base_log_data, [
                'message_role'   => 'system',
                'event_sub_type' => 'trigger_log',
                'message_content'=> $content, // Human-readable summary
                'timestamp'      => time(),
                'trigger_log_details' => array_merge(['log_subtype' => $log_subtype], $details)
            ]);

            $log_storage->log_message($log_entry);
        }

        private function summarize_payload_for_log(string $action_type, array $payload): array
        {
            $summary = [];
            switch ($action_type) {
                case 'bot_reply':
                    $summary['message_snippet'] = mb_substr($payload['message'] ?? '', 0, 30) . '...';
                    $summary['stop_ai'] = $payload['stop_processing_ai'] ?? false;
                    break;
                case 'inject_context':
                    $summary['placement'] = $payload['placement'] ?? 'unknown';
                    $summary['content_snippet'] = mb_substr($payload['content'] ?? '', 0, 30) . '...';
                    break;
                case 'block_message':
                    $summary['reason_snippet'] = mb_substr($payload['reason'] ?? '', 0, 30) . '...';
                    break;
                case 'call_webhook':
                    $summary['endpoint_url'] = filter_var($payload['endpoint_url'] ?? '', FILTER_VALIDATE_URL) ? $payload['endpoint_url'] : 'Invalid URL';
                    $summary['http_method'] = $payload['http_method'] ?? 'POST';
                    $summary['has_headers'] = !empty($payload['headers']);
                    $summary['has_body_template'] = !empty($payload['body_template']);
                    break;
                case 'set_variable':
                    $summary['scope'] = $payload['scope'] ?? 'unknown';
                    $summary['key'] = $payload['key'] ?? 'unknown';
                    // Preserve the existing bounded value snippet.
                     $summary['value_snippet'] = mb_substr($payload['value'] ?? '', 0, 30) . ((mb_strlen($payload['value'] ?? '') > 30) ? '...' : '');
                    break;
                case 'display_form':
                     $summary['form_id'] = $payload['form_id'] ?? 'unknown';
                     $summary['title_snippet'] = mb_substr($payload['title'] ?? '', 0, 30) . '...';
                     $summary['element_count'] = count($payload['elements'] ?? []);
                     break;
                default:
                    $summary['details'] = 'Payload summary not available for this action type.';
                    break;
            }
            return $summary;
        }
    }
}
