<?php

namespace FluentCartPro\App\Modules\SavedPaymentMethods\PayPal;

use FluentCart\Framework\Support\Arr;

/**
 * Tracks whether this store's PayPal account can actually vault.
 *
 * PayPal vaulting requires merchant-account approval. Without it a consented
 * save does nothing: the buyer ticks the box, no token comes back, and nobody is
 * told. This records the condition so the saving UI stops being offered and the
 * merchant sees why.
 *
 * Detection is LAZY — inferred from real checkouts rather than probed. A probe
 * would mean an extra PayPal round trip on checkout renders (or a background job
 * and its own staleness), to answer a question the next real order answers for
 * free. Two signals mark it unavailable:
 *
 *  1. PayPal rejects an order carrying vault attributes — core retries without
 *     them and fires fluent_cart/payments/paypal_vault_rejected.
 *  2. The order succeeds but comes back with no vault block, i.e. the save was
 *     silently ignored (PayPalSavedMethodWriter reports this).
 *
 * Availability is assumed until proven otherwise, so a correctly configured
 * store never pays a detection cost.
 */
class PayPalVaultCapability
{
    const OPTION = 'fluent_cart_pro_paypal_vault_unavailable';

    /**
     * Re-check after this long. An account approved for vaulting after the fact
     * would otherwise stay switched off forever with no way back short of
     * clearing the option by hand.
     */
    const RETRY_AFTER = DAY_IN_SECONDS;

    public function isAvailable(): bool
    {
        $state = get_option(self::OPTION);

        if (!is_array($state) || empty($state['at'])) {
            return true;
        }

        // Cool-off expired: assume capable again and let the next order re-prove
        // it either way.
        if ((time() - (int) $state['at']) > self::RETRY_AFTER) {
            return true;
        }

        return false;
    }

    /**
     * @param string $reason Merchant-facing explanation from PayPal, if any.
     */
    public function markUnavailable($reason = ''): void
    {
        update_option(self::OPTION, [
            'at'     => time(),
            'reason' => sanitize_text_field((string) $reason),
        ], false);
    }

    public function markAvailable(): void
    {
        delete_option(self::OPTION);
    }

    /**
     * @return string '' when vaulting is available
     */
    public function reason(): string
    {
        if ($this->isAvailable()) {
            return '';
        }

        $state = get_option(self::OPTION);

        return (string) Arr::get(is_array($state) ? $state : [], 'reason', '');
    }
}
