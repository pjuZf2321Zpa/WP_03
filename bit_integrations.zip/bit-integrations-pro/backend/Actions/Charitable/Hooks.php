<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Actions\Charitable\CharitableProHelper;
use BitApps\IntegrationsPro\Config;
use BitApps\IntegrationsPro\Core\Util\Hooks;

Hooks::filter(Config::withFreePrefix('charitable_create_donation'), [CharitableProHelper::class, 'createDonation'], 10, 4);
Hooks::filter(Config::withFreePrefix('charitable_update_donation_status'), [CharitableProHelper::class, 'updateDonationStatus'], 10, 3);
Hooks::filter(Config::withFreePrefix('charitable_add_donation_note'), [CharitableProHelper::class, 'addDonationNote'], 10, 2);
Hooks::filter(Config::withFreePrefix('charitable_delete_donation'), [CharitableProHelper::class, 'deleteDonation'], 10, 3);
Hooks::filter(Config::withFreePrefix('charitable_create_campaign'), [CharitableProHelper::class, 'createCampaign'], 10, 3);
Hooks::filter(Config::withFreePrefix('charitable_update_campaign'), [CharitableProHelper::class, 'updateCampaign'], 10, 3);
Hooks::filter(Config::withFreePrefix('charitable_delete_campaign'), [CharitableProHelper::class, 'deleteCampaign'], 10, 3);
Hooks::filter(Config::withFreePrefix('charitable_create_donor'), [CharitableProHelper::class, 'createDonor'], 10, 3);
Hooks::filter(Config::withFreePrefix('charitable_update_donor'), [CharitableProHelper::class, 'updateDonor'], 10, 3);
Hooks::filter(Config::withFreePrefix('charitable_create_user_profile'), [CharitableProHelper::class, 'createUserProfile'], 10, 3);
Hooks::filter(Config::withFreePrefix('charitable_update_user_profile'), [CharitableProHelper::class, 'updateUserProfile'], 10, 3);
Hooks::filter(Config::withFreePrefix('charitable_mark_user_verified'), [CharitableProHelper::class, 'markUserVerified'], 10, 3);
