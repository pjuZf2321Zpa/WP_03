<?php

namespace WPAICG\Lib\Integrations\Apps;

use WP_Error;

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

class AIPKit_App_Connection_Diagnostics
{
    /**
     * @param array<string, mixed> $connection
     */
    public static function get_effective_connection_status(array $connection): string
    {
        $fallback_status = sanitize_key((string) ($connection['status'] ?? 'draft'));
        if (!in_array($fallback_status, ['draft', 'active', 'inactive', 'error', 'reauth_required'], true)) {
            $fallback_status = 'draft';
        }

        $ui_state = self::get_connection_ui_state($connection);
        $status_key = sanitize_key((string) ($ui_state['status_key'] ?? $fallback_status));

        return in_array($status_key, ['draft', 'active', 'inactive', 'error', 'reauth_required'], true)
            ? $status_key
            : $fallback_status;
    }

    /**
     * @return array<string, array<int, string>>
     */
    public static function get_testable_auth_types_by_app(): array
    {
        return [
            'slack' => ['token'],
            'hubspot' => ['token'],
            'notion' => ['token'],
            'pipedrive' => ['api_key'],
        ];
    }

    /**
     * @param array<string, mixed> $connection
     */
    private static function is_connection_testable(array $connection): bool
    {
        $app_slug = sanitize_key((string) ($connection['app_slug'] ?? ''));
        $auth_type = sanitize_key((string) ($connection['auth_type'] ?? ''));
        $testable_auth_types = self::get_testable_auth_types_by_app();
        $app_auth_types = $testable_auth_types[$app_slug] ?? [];

        return in_array($auth_type, $app_auth_types, true);
    }

    /**
     * @param array<string, mixed> $connection
     * @return array<string, mixed>
     */
    public static function get_connection_ui_state(array $connection): array
    {
        $meta = isset($connection['meta']) && is_array($connection['meta']) ? $connection['meta'] : [];
        $last_test_status = sanitize_key((string) ($meta['last_test_status'] ?? ''));
        $last_test_message = sanitize_text_field((string) ($meta['last_test_message'] ?? ''));
        $last_tested_at = sanitize_text_field((string) ($meta['last_tested_at'] ?? ''));
        $is_testable = self::is_connection_testable($connection);
        $readiness = self::validate_connection_for_test($connection);
        $saved_readiness = self::validate_connection_for_usage($connection);

        $status_key = 'draft';
        $status_label = __('Ready to test', 'gpt3-ai-content-generator');
        $summary = __('Credentials saved. Run a live connection test.', 'gpt3-ai-content-generator');
        $can_test = $is_testable && !is_wp_error($readiness);

        if (!$is_testable) {
            $auth_type = sanitize_key((string) ($connection['auth_type'] ?? ''));
            if (is_wp_error($saved_readiness)) {
                $status_label = __('Incomplete', 'gpt3-ai-content-generator');
                $summary = $saved_readiness->get_error_message();
            } elseif (($meta['last_runtime_status'] ?? '') === 'success') {
                $status_key = 'active';
                $status_label = __('Connected', 'gpt3-ai-content-generator');
                $summary = sanitize_text_field((string) ($meta['last_runtime_message'] ?? ''))
                    ?: __('Delivery verified successfully.', 'gpt3-ai-content-generator');
            } elseif (in_array($meta['last_runtime_status'] ?? '', ['error', 'reauth_required'], true)) {
                $status_key = sanitize_key((string) $meta['last_runtime_status']);
                $status_label = __('Connection error', 'gpt3-ai-content-generator');
                $summary = sanitize_text_field((string) ($meta['last_runtime_message'] ?? ''))
                    ?: __('The last delivery failed.', 'gpt3-ai-content-generator');
            } else {
                $status_label = __('Saved', 'gpt3-ai-content-generator');
                $summary = $auth_type === 'webhook'
                    ? __('Webhook connection is ready. Delivery is verified at runtime.', 'gpt3-ai-content-generator')
                    : __('This app uses runtime delivery without a live auth test.', 'gpt3-ai-content-generator');
            }
            $can_test = false;
        } elseif (is_wp_error($readiness)) {
            $status_label = __('Incomplete', 'gpt3-ai-content-generator');
            $summary = $readiness->get_error_message();
            $can_test = false;
        } elseif ($last_test_status === 'success') {
            $status_key = 'active';
            $status_label = __('Connected', 'gpt3-ai-content-generator');
            $summary = $last_test_message !== ''
                ? $last_test_message
                : __('Connection verified successfully.', 'gpt3-ai-content-generator');

            if ($last_tested_at !== '') {
                $summary .= ' ' . sprintf(
                    /* translators: %s: Date/time string */
                    __('Last tested %s.', 'gpt3-ai-content-generator'),
                    $last_tested_at
                );
            }
        } elseif ($last_test_status === 'reauth_required') {
            $status_key = 'reauth_required';
            $status_label = __('Reauth required', 'gpt3-ai-content-generator');
            $summary = $last_test_message !== ''
                ? $last_test_message
                : __('Reconnect or refresh this app connection.', 'gpt3-ai-content-generator');
        } elseif ($last_test_status === 'error') {
            $status_key = 'error';
            $status_label = __('Connection error', 'gpt3-ai-content-generator');
            $summary = $last_test_message !== ''
                ? $last_test_message
                : __('The last connection test failed.', 'gpt3-ai-content-generator');
        }

        return [
            'status_key' => $status_key,
            'status_label' => $status_label,
            'summary' => $summary,
            'is_testable' => $is_testable,
            'can_test' => $can_test,
            'button_label' => $last_test_status === 'success'
                ? __('Retest Connection', 'gpt3-ai-content-generator')
                : __('Test connection', 'gpt3-ai-content-generator'),
        ];
    }

    /**
     * @param array<string, mixed> $connection
     * @return bool|WP_Error
     */
    public static function validate_connection_for_usage(array $connection)
    {
        $app_slug = sanitize_key((string) ($connection['app_slug'] ?? ''));
        $auth_type = sanitize_key((string) ($connection['auth_type'] ?? ''));
        $credentials = isset($connection['credentials']) && is_array($connection['credentials']) ? $connection['credentials'] : [];
        $workspace = isset($connection['workspace']) && is_array($connection['workspace']) ? $connection['workspace'] : [];

        switch ($app_slug) {
            case 'slack':
                if ($auth_type === 'webhook') {
                    if (sanitize_text_field((string) ($credentials['webhook_url'] ?? '')) === '') {
                        return new WP_Error(
                            'aipkit_missing_slack_webhook',
                            __('Add a Slack webhook URL before using this connection.', 'gpt3-ai-content-generator')
                        );
                    }
                    return true;
                }

                if (sanitize_text_field((string) ($credentials['bot_token'] ?? '')) === '') {
                    return new WP_Error(
                        'aipkit_missing_slack_bot_token',
                        __('Add a Slack bot token before using this connection.', 'gpt3-ai-content-generator')
                    );
                }
                if (sanitize_text_field((string) ($workspace['default_channel'] ?? '')) === '') {
                    return new WP_Error(
                        'aipkit_missing_slack_default_channel',
                        __('Add a Slack default channel before using this connection.', 'gpt3-ai-content-generator')
                    );
                }
                return true;

            case 'zapier':
                if (sanitize_text_field((string) ($credentials['webhook_url'] ?? '')) === '') {
                    return new WP_Error(
                        'aipkit_missing_zapier_webhook',
                        __('Add a Zapier webhook URL before using this connection.', 'gpt3-ai-content-generator')
                    );
                }
                return true;

            case 'make':
                if (sanitize_text_field((string) ($credentials['webhook_url'] ?? '')) === '') {
                    return new WP_Error(
                        'aipkit_missing_make_webhook',
                        __('Add a Make webhook URL before using this connection.', 'gpt3-ai-content-generator')
                    );
                }
                return true;

            case 'n8n':
                if (sanitize_text_field((string) ($credentials['webhook_url'] ?? '')) === '') {
                    return new WP_Error(
                        'aipkit_missing_n8n_webhook',
                        __('Add an n8n webhook URL before using this connection.', 'gpt3-ai-content-generator')
                    );
                }
                return true;

            default:
                return true;
        }
    }

    /**
     * @return array<string, mixed>|WP_Error
     */
    public static function test_connection_by_id(string $connection_id, int $current_user_id = 0)
    {
        $connection = AIPKit_App_Connections::get_connection_by_id($connection_id);
        if (!is_array($connection)) {
            return new WP_Error(
                'aipkit_connection_not_found',
                __('App connection not found.', 'gpt3-ai-content-generator')
            );
        }

        $readiness = self::validate_connection_for_test($connection);
        if (is_wp_error($readiness)) {
            $ui_state = self::get_connection_ui_state($connection);

            return [
                'connection_id' => sanitize_text_field((string) ($connection['id'] ?? '')),
                'status' => sanitize_key((string) ($connection['status'] ?? 'draft')),
                'ui_state' => $ui_state,
                'message' => (string) $ui_state['summary'],
            ];
        }

        $test_result = self::run_live_test($connection);
        $runtime_updates = [
            'status' => 'error',
            'meta' => [
                'last_tested_at' => current_time('mysql'),
                'last_test_http_code' => 0,
                'last_test_details' => [],
            ],
        ];

        if (is_wp_error($test_result)) {
            $error_data = $test_result->get_error_data();
            $error_http_code = is_array($error_data) ? (int) ($error_data['http_code'] ?? 0) : 0;
            $error_status = is_array($error_data)
                ? sanitize_key((string) ($error_data['status'] ?? 'error'))
                : 'error';
            $error_details = is_array($error_data) && isset($error_data['details']) && is_array($error_data['details'])
                ? $error_data['details']
                : [];

            $runtime_updates['status'] = in_array($error_status, ['reauth_required', 'error'], true)
                ? $error_status
                : 'error';
            $runtime_updates['meta']['last_test_status'] = $runtime_updates['status'] === 'reauth_required'
                ? 'reauth_required'
                : 'error';
            $runtime_updates['meta']['last_test_message'] = $test_result->get_error_message();
            $runtime_updates['meta']['last_test_http_code'] = $error_http_code;
            $runtime_updates['meta']['last_test_details'] = $error_details;
        } else {
            $runtime_updates['status'] = 'active';
            $runtime_updates['meta']['last_test_status'] = 'success';
            $runtime_updates['meta']['last_test_message'] = sanitize_text_field((string) ($test_result['message'] ?? ''));
            $runtime_updates['meta']['last_test_http_code'] = max(0, (int) ($test_result['http_code'] ?? 0));
            $runtime_updates['meta']['last_test_details'] = isset($test_result['details']) && is_array($test_result['details'])
                ? $test_result['details']
                : [];
        }

        AIPKit_App_Connections::update_connection_runtime_state(
            sanitize_text_field((string) ($connection['id'] ?? '')),
            $runtime_updates,
            $current_user_id
        );

        $updated_connection = AIPKit_App_Connections::get_connection_by_id((string) ($connection['id'] ?? ''));
        if (!is_array($updated_connection)) {
            $updated_connection = $connection;
        }

        $ui_state = self::get_connection_ui_state($updated_connection);

        return [
            'connection_id' => sanitize_text_field((string) ($updated_connection['id'] ?? '')),
            'status' => sanitize_key((string) ($updated_connection['status'] ?? 'draft')),
            'ui_state' => $ui_state,
            'message' => (string) $ui_state['summary'],
        ];
    }

    /**
     * @param array<string, mixed> $connection
     * @return bool|WP_Error
     */
    public static function validate_connection_for_test(array $connection)
    {
        $app_slug = sanitize_key((string) ($connection['app_slug'] ?? ''));
        $auth_type = sanitize_key((string) ($connection['auth_type'] ?? ''));
        $credentials = isset($connection['credentials']) && is_array($connection['credentials']) ? $connection['credentials'] : [];
        $workspace = isset($connection['workspace']) && is_array($connection['workspace']) ? $connection['workspace'] : [];

        switch ($app_slug) {
            case 'slack':
                if ($auth_type === 'webhook') {
                    if (sanitize_text_field((string) ($credentials['webhook_url'] ?? '')) === '') {
                        return new WP_Error(
                            'aipkit_missing_slack_webhook',
                            __('Add a Slack webhook URL before using this connection.', 'gpt3-ai-content-generator')
                        );
                    }

                    return new WP_Error(
                        'aipkit_slack_webhook_not_testable',
                        __('Slack webhook connections do not support live auth testing.', 'gpt3-ai-content-generator')
                    );
                }

                if (sanitize_text_field((string) ($credentials['bot_token'] ?? '')) === '') {
                    return new WP_Error(
                        'aipkit_missing_slack_bot_token',
                        __('Add a Slack bot token to run a live connection test.', 'gpt3-ai-content-generator')
                    );
                }
                if (sanitize_text_field((string) ($workspace['default_channel'] ?? '')) === '') {
                    return new WP_Error(
                        'aipkit_missing_slack_default_channel',
                        __('Add a Slack default channel to run a live connection test.', 'gpt3-ai-content-generator')
                    );
                }
                return true;

            case 'hubspot':
                if (sanitize_text_field((string) ($credentials['private_app_token'] ?? '')) === '') {
                    return new WP_Error(
                        'aipkit_missing_hubspot_token',
                        __('Add a HubSpot private app token to test this connection.', 'gpt3-ai-content-generator')
                    );
                }
                return true;

            case 'notion':
                if (sanitize_text_field((string) ($credentials['integration_token'] ?? '')) === '') {
                    return new WP_Error(
                        'aipkit_missing_notion_token',
                        __('Add a Notion integration token to test this connection.', 'gpt3-ai-content-generator')
                    );
                }
                return true;

            case 'pipedrive':
                if (sanitize_text_field((string) ($credentials['api_token'] ?? '')) === '') {
                    return new WP_Error(
                        'aipkit_missing_pipedrive_token',
                        __('Add a Pipedrive API token to test this connection.', 'gpt3-ai-content-generator')
                    );
                }
                if (sanitize_text_field((string) ($workspace['company_domain'] ?? '')) === '') {
                    return new WP_Error(
                        'aipkit_missing_pipedrive_domain',
                        __('Add a Pipedrive company domain to test this connection.', 'gpt3-ai-content-generator')
                    );
                }
                return true;
        }

        return new WP_Error(
            'aipkit_app_test_not_supported',
            __('This app does not support live auth testing yet.', 'gpt3-ai-content-generator')
        );
    }

    /**
     * @param array<string, mixed> $connection
     * @return array<string, mixed>|WP_Error
     */
    private static function run_live_test(array $connection)
    {
        $app_slug = sanitize_key((string) ($connection['app_slug'] ?? ''));

        switch ($app_slug) {
            case 'slack':
                return self::test_slack_connection($connection);
            case 'hubspot':
                return self::test_hubspot_connection($connection);
            case 'notion':
                return self::test_notion_connection($connection);
            case 'pipedrive':
                return self::test_pipedrive_connection($connection);
        }

        return new WP_Error(
            'aipkit_app_test_not_supported',
            __('This app does not support live auth testing yet.', 'gpt3-ai-content-generator')
        );
    }

    /**
     * @param array<string, mixed> $connection
     * @return array<string, mixed>|WP_Error
     */
    private static function test_slack_connection(array $connection)
    {
        $credentials = isset($connection['credentials']) && is_array($connection['credentials']) ? $connection['credentials'] : [];
        $workspace = isset($connection['workspace']) && is_array($connection['workspace']) ? $connection['workspace'] : [];
        $bot_token = sanitize_text_field((string) ($credentials['bot_token'] ?? ''));
        $default_channel = sanitize_text_field((string) ($workspace['default_channel'] ?? ''));

        $response = wp_remote_post('https://slack.com/api/auth.test', [
            'timeout' => 15,
            'headers' => [
                'Authorization' => 'Bearer ' . $bot_token,
                'Content-Type' => 'application/x-www-form-urlencoded; charset=utf-8',
            ],
            'body' => [],
        ]);

        if (is_wp_error($response)) {
            return new WP_Error(
                'aipkit_slack_request_failed',
                __('Slack connection test failed to reach the API.', 'gpt3-ai-content-generator'),
                [
                    'status' => 'error',
                    'details' => ['error' => $response->get_error_message()],
                ]
            );
        }

        $http_code = wp_remote_retrieve_response_code($response);
        $body = json_decode((string) wp_remote_retrieve_body($response), true);
        if (!is_array($body)) {
            $body = [];
        }

        if ($http_code >= 200 && $http_code < 300 && !empty($body['ok'])) {
            $team_name = sanitize_text_field((string) ($body['team'] ?? 'Slack'));
            $user_name = sanitize_text_field((string) ($body['user'] ?? ''));
            $channel_validation = self::validate_slack_channel_delivery($bot_token, $default_channel);
            if (is_wp_error($channel_validation)) {
                return $channel_validation;
            }

            $verified_channel = is_array($channel_validation)
                ? sanitize_text_field((string) ($channel_validation['channel'] ?? $default_channel))
                : $default_channel;

            return [
                'http_code' => $http_code,
                'message' => $user_name !== ''
                    ? sprintf(
                        /* translators: 1: Slack workspace name, 2: connected user name, 3: verified channel name. */
                        __('Connected to %1$s as %2$s. Verified channel %3$s.', 'gpt3-ai-content-generator'),
                        $team_name,
                        $user_name,
                        $verified_channel
                    )
                    : sprintf(
                        /* translators: 1: Slack workspace name, 2: verified channel name. */
                        __('Connected to %1$s. Verified channel %2$s.', 'gpt3-ai-content-generator'),
                        $team_name,
                        $verified_channel
                    ),
                'details' => [
                    'team' => $team_name,
                    'user' => $user_name,
                    'channel' => $verified_channel,
                ],
            ];
        }

        $error_code = sanitize_key((string) ($body['error'] ?? 'unknown_error'));
        return new WP_Error(
            'aipkit_slack_connection_failed',
            sprintf(
                /* translators: %s: Slack API error code. */
                __('Slack connection test failed: %s.', 'gpt3-ai-content-generator'),
                $error_code
            ),
            [
                'status' => in_array($error_code, ['invalid_auth', 'token_revoked', 'not_authed'], true) ? 'reauth_required' : 'error',
                'http_code' => $http_code,
                'details' => $body,
            ]
        );
    }

    /**
     * @return array<string, mixed>|WP_Error
     */
    private static function validate_slack_channel_delivery(string $bot_token, string $channel)
    {
        $test_text = __('AIPKit Slack connection test. This message will be removed automatically.', 'gpt3-ai-content-generator');

        $post_response = self::run_json_post_request(
            'https://slack.com/api/chat.postMessage',
            [
                'Authorization' => 'Bearer ' . $bot_token,
                'Accept' => 'application/json',
            ],
            [
                'channel' => $channel,
                'text' => $test_text,
                'unfurl_links' => false,
                'unfurl_media' => false,
            ],
            static function (int $http_code, array $body) use ($channel) {
                if ($http_code >= 200 && $http_code < 300 && !empty($body['ok'])) {
                    return [
                        'http_code' => $http_code,
                        'channel' => sanitize_text_field((string) ($body['channel'] ?? $channel)),
                        'message_ts' => sanitize_text_field((string) ($body['ts'] ?? '')),
                        'details' => $body,
                    ];
                }

                $error_code = sanitize_key((string) ($body['error'] ?? 'unknown_error'));
                return new WP_Error(
                    'aipkit_slack_channel_validation_failed',
                    sprintf(
                        /* translators: %s: Slack API error code. */
                        __('Slack channel test failed: %s.', 'gpt3-ai-content-generator'),
                        $error_code
                    ),
                    [
                        'status' => in_array($error_code, ['invalid_auth', 'token_revoked', 'not_authed'], true) ? 'reauth_required' : 'error',
                        'http_code' => $http_code,
                        'details' => $body,
                    ]
                );
            }
        );

        if (is_wp_error($post_response)) {
            return $post_response;
        }

        $posted_channel = sanitize_text_field((string) ($post_response['channel'] ?? $channel));
        $message_ts = sanitize_text_field((string) ($post_response['message_ts'] ?? ''));

        if ($posted_channel !== '' && $message_ts !== '') {
            self::run_json_post_request(
                'https://slack.com/api/chat.delete',
                [
                    'Authorization' => 'Bearer ' . $bot_token,
                    'Accept' => 'application/json',
                ],
                [
                    'channel' => $posted_channel,
                    'ts' => $message_ts,
                ],
                static function (int $http_code, array $body) {
                    if ($http_code >= 200 && $http_code < 300 && !empty($body['ok'])) {
                        return [
                            'http_code' => $http_code,
                        ];
                    }

                    return new WP_Error(
                        'aipkit_slack_test_cleanup_failed',
                        __('Slack channel was verified, but the temporary test message could not be removed automatically.', 'gpt3-ai-content-generator'),
                        [
                            'status' => 'error',
                            'http_code' => $http_code,
                            'details' => $body,
                        ]
                    );
                }
            );
        }

        return [
            'channel' => $posted_channel !== '' ? $posted_channel : $channel,
            'message_ts' => $message_ts,
        ];
    }

    /**
     * @param array<string, mixed> $connection
     * @return array<string, mixed>|WP_Error
     */
    private static function test_hubspot_connection(array $connection)
    {
        $credentials = isset($connection['credentials']) && is_array($connection['credentials']) ? $connection['credentials'] : [];
        $token = sanitize_text_field((string) ($credentials['private_app_token'] ?? ''));

        return self::run_json_get_request(
            'https://api.hubapi.com/integrations/v1/me',
            [
                'Authorization' => 'Bearer ' . $token,
                'Accept' => 'application/json',
            ],
            static function (int $http_code, array $body) {
                if ($http_code >= 200 && $http_code < 300) {
                    $portal_id = sanitize_text_field((string) ($body['portalId'] ?? ''));
                    $user_name = sanitize_text_field((string) ($body['user'] ?? ''));

                    return [
                        'http_code' => $http_code,
                        'message' => $portal_id !== ''
                            ? sprintf(
                                /* translators: %s: HubSpot portal ID. */
                                __('Connected to HubSpot portal %s.', 'gpt3-ai-content-generator'),
                                $portal_id
                            )
                            : __('Connected to HubSpot.', 'gpt3-ai-content-generator'),
                        'details' => [
                            'portal_id' => $portal_id,
                            'user' => $user_name,
                        ],
                    ];
                }

                return new WP_Error(
                    'aipkit_hubspot_connection_failed',
                    __('HubSpot connection test failed.', 'gpt3-ai-content-generator'),
                    [
                        'status' => in_array($http_code, [401, 403], true) ? 'reauth_required' : 'error',
                        'http_code' => $http_code,
                        'details' => $body,
                    ]
                );
            }
        );
    }

    /**
     * @param array<string, mixed> $connection
     * @return array<string, mixed>|WP_Error
     */
    private static function test_notion_connection(array $connection)
    {
        $credentials = isset($connection['credentials']) && is_array($connection['credentials']) ? $connection['credentials'] : [];
        $token = sanitize_text_field((string) ($credentials['integration_token'] ?? ''));

        return self::run_json_get_request(
            'https://api.notion.com/v1/users/me',
            [
                'Authorization' => 'Bearer ' . $token,
                'Accept' => 'application/json',
                'Notion-Version' => '2022-06-28',
            ],
            static function (int $http_code, array $body) {
                if ($http_code >= 200 && $http_code < 300) {
                    $user_name = sanitize_text_field((string) ($body['name'] ?? ''));

                    return [
                        'http_code' => $http_code,
                        'message' => $user_name !== ''
                            ? sprintf(
                                /* translators: %s: connected Notion user name. */
                                __('Connected to Notion as %s.', 'gpt3-ai-content-generator'),
                                $user_name
                            )
                            : __('Connected to Notion.', 'gpt3-ai-content-generator'),
                        'details' => [
                            'name' => $user_name,
                        ],
                    ];
                }

                return new WP_Error(
                    'aipkit_notion_connection_failed',
                    __('Notion connection test failed.', 'gpt3-ai-content-generator'),
                    [
                        'status' => in_array($http_code, [401, 403], true) ? 'reauth_required' : 'error',
                        'http_code' => $http_code,
                        'details' => $body,
                    ]
                );
            }
        );
    }

    /**
     * @param array<string, mixed> $connection
     * @return array<string, mixed>|WP_Error
     */
    private static function test_pipedrive_connection(array $connection)
    {
        $credentials = isset($connection['credentials']) && is_array($connection['credentials']) ? $connection['credentials'] : [];
        $workspace = isset($connection['workspace']) && is_array($connection['workspace']) ? $connection['workspace'] : [];
        $api_token = sanitize_text_field((string) ($credentials['api_token'] ?? ''));
        $company_domain = self::normalize_pipedrive_domain((string) ($workspace['company_domain'] ?? ''));
        if ($company_domain === '') {
            return new WP_Error(
                'aipkit_invalid_pipedrive_domain',
                __('Enter a valid Pipedrive company domain.', 'gpt3-ai-content-generator'),
                ['status' => 'error']
            );
        }

        $endpoint = sprintf(
            'https://%1$s.pipedrive.com/api/v1/users/me?api_token=%2$s',
            rawurlencode($company_domain),
            rawurlencode($api_token)
        );

        return self::run_json_get_request(
            $endpoint,
            [
                'Accept' => 'application/json',
            ],
            static function (int $http_code, array $body) {
                $is_success = !empty($body['success']);
                if ($http_code >= 200 && $http_code < 300 && $is_success) {
                    $user_data = isset($body['data']) && is_array($body['data']) ? $body['data'] : [];
                    $user_name = sanitize_text_field((string) ($user_data['name'] ?? ''));

                    return [
                        'http_code' => $http_code,
                        'message' => $user_name !== ''
                            ? sprintf(
                                /* translators: %s: connected Pipedrive user name. */
                                __('Connected to Pipedrive as %s.', 'gpt3-ai-content-generator'),
                                $user_name
                            )
                            : __('Connected to Pipedrive.', 'gpt3-ai-content-generator'),
                        'details' => [
                            'name' => $user_name,
                        ],
                    ];
                }

                return new WP_Error(
                    'aipkit_pipedrive_connection_failed',
                    __('Pipedrive connection test failed.', 'gpt3-ai-content-generator'),
                    [
                        'status' => in_array($http_code, [401, 403], true) ? 'reauth_required' : 'error',
                        'http_code' => $http_code,
                        'details' => $body,
                    ]
                );
            }
        );
    }

    /**
     * @param array<string, string> $headers
     * @param callable $response_handler
     * @return array<string, mixed>|WP_Error
     */
    private static function run_json_get_request(string $url, array $headers, callable $response_handler)
    {
        $response = wp_remote_get($url, [
            'timeout' => 15,
            'headers' => $headers,
        ]);

        return self::handle_json_response($response, $response_handler);
    }

    /**
     * @param array<string, string> $headers
     * @param array<string, mixed> $body
     * @param callable $response_handler
     * @return array<string, mixed>|WP_Error
     */
    private static function run_json_post_request(string $url, array $headers, array $body, callable $response_handler)
    {
        $response = wp_remote_post($url, [
            'timeout' => 15,
            'headers' => array_merge([
                'Content-Type' => 'application/json; charset=utf-8',
            ], $headers),
            'body' => wp_json_encode($body),
        ]);

        return self::handle_json_response($response, $response_handler);
    }

    /**
     * @param array|WP_Error $response
     * @return array<string, mixed>|WP_Error
     */
    private static function handle_json_response($response, callable $response_handler)
    {
        if (is_wp_error($response)) {
            return new WP_Error(
                'aipkit_connection_request_failed',
                __('Connection test failed to reach the remote app API.', 'gpt3-ai-content-generator'),
                [
                    'status' => 'error',
                    'details' => ['error' => $response->get_error_message()],
                ]
            );
        }

        $http_code = wp_remote_retrieve_response_code($response);
        $body = json_decode((string) wp_remote_retrieve_body($response), true);
        if (!is_array($body)) {
            $body = [];
        }

        return $response_handler($http_code, $body);
    }

    private static function normalize_pipedrive_domain(string $domain): string
    {
        $value = trim($domain);
        if ($value === '') {
            return '';
        }

        $value = preg_replace('#^https?://#i', '', $value);
        $value = preg_replace('#/.*$#', '', $value);
        $value = preg_replace('#\.pipedrive\.com$#i', '', $value);

        return sanitize_title($value);
    }
}
