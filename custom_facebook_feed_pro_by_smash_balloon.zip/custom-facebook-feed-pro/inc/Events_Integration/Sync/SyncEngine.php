<?php
/**
 * Push engine: mirrors normalized Facebook events into the enabled calendar
 * targets (create, update in place, delete when gone or canceled).
 *
 * @package CustomFacebookFeed\Events_Integration
 * @since 4.11
 */

namespace CustomFacebookFeed\Events_Integration\Sync;

use CustomFacebookFeed\Events_Integration\Config;
use CustomFacebookFeed\Events_Integration\NormalizedEvent;
use CustomFacebookFeed\Events_Integration\Provider\EventsProvider;
use CustomFacebookFeed\Events_Integration\Targets\TargetAdapterInterface;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class SyncEngine {

	/**
	 * Graph error codes indicating rate limiting: abort and retry later.
	 */
	const RATE_LIMIT_CODES = array( 4, 17, 32 );

	/**
	 * Delay before a batch continuation or rate-limit retry.
	 */
	const BATCH_DELAY_SECONDS  = 120;
	const RETRY_DELAY_SECONDS  = 30 * MINUTE_IN_SECONDS;

	/**
	 * @var EventsProvider
	 */
	private $provider;

	/**
	 * @var SyncState
	 */
	private $state;

	/**
	 * @var ImageSideloader
	 */
	private $sideloader;

	/**
	 * Callable returning all registered adapters. Resolved lazily at run
	 * time (not at plugin load) so adapters added via the
	 * cff_events_sync_adapters filter on plugins_loaded/init are seen.
	 *
	 * @var callable
	 */
	private $adapters_provider;

	/**
	 * @var array<string, TargetAdapterInterface>|null
	 */
	private $adapters_cache = null;

	/**
	 * @param EventsProvider  $provider          Events provider.
	 * @param SyncState       $state             Sync-state store.
	 * @param ImageSideloader $sideloader        Cover image importer.
	 * @param callable        $adapters_provider Returns all registered adapters, keyed by target ID.
	 */
	public function __construct( EventsProvider $provider, SyncState $state, ImageSideloader $sideloader, callable $adapters_provider ) {
		$this->provider          = $provider;
		$this->state             = $state;
		$this->sideloader        = $sideloader;
		$this->adapters_provider = $adapters_provider;
	}

	/**
	 * Adapters that are enabled in settings and whose target plugin is active.
	 *
	 * @return array<string, TargetAdapterInterface>
	 */
	public function active_adapters() {
		$adapters = $this->adapters();
		$active   = array();
		foreach ( Config::enabled_targets() as $target_id ) {
			if ( isset( $adapters[ $target_id ] ) && $adapters[ $target_id ]->is_available() ) {
				$active[ $target_id ] = $adapters[ $target_id ];
			}
		}

		return $active;
	}

	/**
	 * All registered adapters, resolved once per request.
	 *
	 * @return array<string, TargetAdapterInterface>
	 */
	public function adapters() {
		if ( null === $this->adapters_cache ) {
			$this->adapters_cache = (array) call_user_func( $this->adapters_provider );
		}

		return $this->adapters_cache;
	}

	/**
	 * Run one sync pass: the source at the cursor position, then schedule a
	 * continuation for the remaining sources.
	 *
	 * @param array $cursor Optional {offset: int} from the previous pass.
	 * @return array Run summary for this pass.
	 */
	public function run( array $cursor = array() ) {
		$summary = array(
			'time'    => time(),
			'source'  => '',
			'created' => 0,
			'updated' => 0,
			'deleted' => 0,
			'skipped' => 0,
			'errors'  => array(),
		);

		$adapters = $this->active_adapters();
		if ( empty( $adapters ) ) {
			$summary['errors'][] = __( 'No enabled calendar integration is available.', 'custom-facebook-feed' );
			$this->log( $summary );
			return $summary;
		}

		$sources = $this->selected_sources();
		if ( empty( $sources ) ) {
			$settings            = Config::get_settings();
			$summary['errors'][] = empty( $settings['sources'] )
				? __( 'No event sources are selected for syncing.', 'custom-facebook-feed' )
				: __( 'No connected events sources found.', 'custom-facebook-feed' );
			$this->log( $summary );
			return $summary;
		}

		$offset = isset( $cursor['offset'] ) ? max( 0, (int) $cursor['offset'] ) : 0;
		if ( $offset >= count( $sources ) ) {
			delete_option( Config::OPTION_CURSOR );
			return $summary;
		}

		$source            = array_values( $sources )[ $offset ];
		$summary['source'] = isset( $source['username'] ) && '' !== $source['username'] ? $source['username'] : $source['account_id'];

		$this->process_source( $source, $adapters, $summary );

		// Rate limited: a retry is already scheduled; don't also continue.
		if ( ! empty( $summary['rate_limited'] ) ) {
			$this->log( $summary );
			return $summary;
		}

		if ( $offset + 1 < count( $sources ) ) {
			$next = array( 'offset' => $offset + 1 );
			update_option( Config::OPTION_CURSOR, $next, false );
			wp_schedule_single_event( time() + self::BATCH_DELAY_SECONDS, Config::BATCH_HOOK, array( $next ) );
			$summary['scheduled_more'] = true;
		} else {
			delete_option( Config::OPTION_CURSOR );
		}

		$this->log( $summary );
		$this->state->flush();

		return $summary;
	}

	/**
	 * Sync every event of one source into every active adapter, then run the
	 * deletion-detection pass for that source.
	 *
	 * @param array $source   Source row.
	 * @param array $adapters Active adapters.
	 * @param array $summary  Run summary (by reference).
	 */
	private function process_source( array $source, array $adapters, array &$summary ) {
		$events = $this->provider->get_events( $source );

		if ( is_wp_error( $events ) ) {
			$this->handle_fetch_error( $events, $source, $summary );
			return;
		}

		$fresh_keys = array();
		foreach ( $events as $event ) {
			$fresh_keys[] = $event->sync_key();
			foreach ( $adapters as $target_id => $adapter ) {
				$this->upsert( $event, $target_id, $adapter, $summary );
			}
		}

		foreach ( $adapters as $target_id => $adapter ) {
			$this->deletion_pass( $source, $target_id, $adapter, $fresh_keys, $summary );
		}

		$this->state->flush();
	}

	/**
	 * Create or update one event in one target.
	 *
	 * @param NormalizedEvent        $event     Normalized event.
	 * @param string                 $target_id Target ID.
	 * @param TargetAdapterInterface $adapter   Target adapter.
	 * @param array                  $summary   Run summary (by reference).
	 */
	private function upsert( NormalizedEvent $event, $target_id, TargetAdapterInterface $adapter, array &$summary ) {
		$sync_key = $event->sync_key();

		// Canceled events stay in the /events response; mirror as deletion.
		if ( $event->is_canceled ) {
			$post_id = $this->state->lookup( $target_id, $sync_key );
			if ( null !== $post_id && $adapter->delete( $post_id ) ) {
				$this->state->forget( $target_id, $sync_key );
				$summary['deleted']++;
			}
			return;
		}

		// lookup() writes the tombstone that must suppress the re-create.
		$post_id = $this->state->lookup( $target_id, $sync_key );

		if ( null === $post_id ) {
			if ( $this->state->is_tombstoned( $target_id, $sync_key ) ) {
				$summary['skipped']++;
				return;
			}
			$post_id = $adapter->create( $event );
			if ( is_wp_error( $post_id ) ) {
				/* translators: 1: calendar plugin name, 2: event title, 3: error message. */
				$summary['errors'][] = sprintf( __( '%1$s: could not create "%2$s" (%3$s)', 'custom-facebook-feed' ), $adapter->label(), $event->title, $post_id->get_error_message() );
				return;
			}
			$this->state->record( $event, $target_id, $post_id );
			// Persist the mapping now: if the pass dies during sideloading,
			// the registry must already know this post exists.
			$this->state->flush();
			$this->maybe_sideload( $post_id, $event );
			$summary['created']++;
			return;
		}

		// Update only on a newer change; unknown updated_time always updates.
		$stored = $this->state->stored_updated_time( $post_id );
		if ( $event->updated_time > 0 && $stored > 0 && $event->updated_time <= $stored ) {
			// Cover import may have been enabled after this event synced;
			// the sideloader itself no-ops when the image is unchanged.
			$this->maybe_sideload( $post_id, $event );
			$summary['skipped']++;
			return;
		}

		$result = $adapter->update( $post_id, $event );
		if ( is_wp_error( $result ) ) {
			/* translators: 1: calendar plugin name, 2: event title, 3: error message. */
			$summary['errors'][] = sprintf( __( '%1$s: could not update "%2$s" (%3$s)', 'custom-facebook-feed' ), $adapter->label(), $event->title, $result->get_error_message() );
			return;
		}
		$this->state->record( $event, $target_id, $post_id );
		$this->maybe_sideload( $post_id, $event );
		$summary['updated']++;
	}

	/**
	 * Deletion pass: every candidate is confirmed with a single-event Graph
	 * fetch before anything is deleted; ambiguous results always abstain.
	 *
	 * @param array                  $source     Source row.
	 * @param string                 $target_id  Target ID.
	 * @param TargetAdapterInterface $adapter    Target adapter.
	 * @param string[]               $fresh_keys Sync keys in the fresh fetch.
	 * @param array                  $summary    Run summary (by reference).
	 */
	private function deletion_pass( array $source, $target_id, TargetAdapterInterface $adapter, array $fresh_keys, array &$summary ) {
		$candidates = $this->state->stale_future_candidates( $target_id, (string) $source['account_id'], $fresh_keys );
		if ( empty( $candidates ) ) {
			return;
		}

		$confirms = 0;
		foreach ( $candidates as $event_id => $entries ) {
			if ( $confirms >= Config::MAX_DELETE_CONFIRMS_PER_PASS ) {
				break;
			}
			$confirms++;

			$check = $this->provider->fetch_single( $event_id, $source['access_token'] );

			if ( 'error' === $check['status'] ) {
				$this->state->mark_confirmed( $entries );
				continue;
			}

			if ( 'gone' === $check['status'] || $check['is_canceled'] ) {
				foreach ( $entries as $entry ) {
					if ( $adapter->delete( $entry['post_id'] ) ) {
						$this->state->forget( $target_id, $entry['sync_key'] );
						$summary['deleted']++;
					}
				}
				continue;
			}

			$this->state->mark_confirmed( $entries );

			// An incomplete occurrence list must not drive deletions.
			if ( ! empty( $check['event_times_truncated'] ) ) {
				continue;
			}

			// Event still live: delete only occurrences that vanished from
			// its event_times list.
			$live_keys = array();
			foreach ( $this->provider->normalizer()->normalize( $check['event'], (string) $source['account_id'] ) as $live_event ) {
				$live_keys[] = $live_event->sync_key();
			}
			foreach ( $entries as $entry ) {
				if ( ! in_array( $entry['sync_key'], $live_keys, true ) && false !== strpos( $entry['sync_key'], '_' ) ) {
					if ( $adapter->delete( $entry['post_id'] ) ) {
						$this->state->forget( $target_id, $entry['sync_key'] );
						$summary['deleted']++;
					}
				}
			}
		}
	}

	/**
	 * Remove all events imported into a target (manual cleanup action).
	 *
	 * @param string $target_id Target adapter ID.
	 * @return array|\WP_Error {deleted: int, failed: int}, or an error when
	 *                         the target is unknown or its plugin inactive.
	 */
	public function cleanup( $target_id ) {
		$adapters = $this->adapters();

		// The target plugin may have been deactivated since importing.
		if ( ! isset( $adapters[ $target_id ] ) || ! $adapters[ $target_id ]->is_available() ) {
			return new \WP_Error(
				'cff_events_sync_cleanup_unavailable',
				__( 'The calendar plugin for this integration is not active, so its imported events cannot be removed.', 'custom-facebook-feed' )
			);
		}
		$adapter = $adapters[ $target_id ];
		$deleted = 0;
		$failed  = 0;

		foreach ( $this->state->all_synced_posts( $target_id ) as $post_id ) {
			$sync_key = (string) get_post_meta( $post_id, SyncState::META_SYNC_KEY, true );
			if ( $adapter->delete( $post_id ) ) {
				$this->state->forget( $target_id, $sync_key );
				$deleted++;
			} else {
				$failed++;
			}
		}

		// A full cleanup is a fresh start: forget user deletions too. With
		// leftovers, keep the tombstones so they aren't resurrected.
		if ( 0 === $failed ) {
			$this->state->clear_tombstones( $target_id );
		}
		$this->state->flush();

		return array(
			'deleted' => $deleted,
			'failed'  => $failed,
		);
	}

	/**
	 * Record a failed source fetch and schedule a retry when rate limited.
	 *
	 * @param \WP_Error $error   Fetch error.
	 * @param array     $source  Source row.
	 * @param array     $summary Run summary (by reference).
	 */
	private function handle_fetch_error( \WP_Error $error, array $source, array &$summary ) {
		$code = EventsProvider::error_code( $error );

		// Sources that fall back to an iCal feed for display have a token
		// that cannot read the Graph events edge; explain that instead of
		// surfacing a cryptic API error.
		if ( class_exists( '\CustomFacebookFeed\CFF_Events_Parser' ) && \CustomFacebookFeed\CFF_Events_Parser::check_ical_url_exists( $source['account_id'] ) ) {
			/* translators: %s: Facebook page ID. */
			$summary['errors'][] = sprintf( __( 'Source %s uses an iCal feed; its access token cannot read events from the Facebook API, so it cannot be synced.', 'custom-facebook-feed' ), $source['account_id'] );
			return;
		}

		/* translators: 1: Facebook page ID, 2: error message. */
		$summary['errors'][] = sprintf( __( 'Fetch failed for %1$s: %2$s', 'custom-facebook-feed' ), $source['account_id'], $error->get_error_message() );

		if ( in_array( $code, self::RATE_LIMIT_CODES, true ) ) {
			$cursor = get_option( Config::OPTION_CURSOR, array() );
			wp_schedule_single_event( time() + self::RETRY_DELAY_SECONDS, Config::BATCH_HOOK, array( is_array( $cursor ) ? $cursor : array() ) );
			$summary['errors'][]     = __( 'Rate limited by the Facebook API, retrying in 30 minutes.', 'custom-facebook-feed' );
			$summary['rate_limited'] = true;
		}
	}

	/**
	 * Import the cover image when configured.
	 *
	 * @param int             $post_id Calendar post ID.
	 * @param NormalizedEvent $event   Normalized event.
	 */
	private function maybe_sideload( $post_id, NormalizedEvent $event ) {
		$settings = Config::get_settings();
		if ( ! empty( $settings['sideload_images'] ) ) {
			$this->sideloader->maybe_sideload( $post_id, $event->cover_url );
		}
	}

	/**
	 * Append a run summary to the rolling log option.
	 *
	 * @param array $summary Run summary.
	 */
	private function log( array $summary ) {
		$log   = get_option( Config::OPTION_LOG, array() );
		$log   = is_array( $log ) ? $log : array();
		$log[] = $summary;

		update_option( Config::OPTION_LOG, array_slice( $log, - Config::LOG_MAX_ENTRIES ), false );
	}

	/**
	 * Connected events sources restricted to the configured selection.
	 *
	 * @return array[]
	 */
	private function selected_sources() {
		$sources  = $this->provider->get_sources();
		$settings = Config::get_settings();
		$selected = array_map( 'strval', (array) $settings['sources'] );

		// Strict opt-in: nothing selected means nothing is synced.
		if ( empty( $selected ) ) {
			return array();
		}

		return array_values(
			array_filter(
				$sources,
				static function ( $source ) use ( $selected ) {
					return in_array( (string) $source['account_id'], $selected, true );
				}
			)
		);
	}
}
