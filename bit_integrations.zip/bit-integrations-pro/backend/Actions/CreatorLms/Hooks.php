<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Actions\CreatorLms\CreatorLmsProHelper;
use BitApps\IntegrationsPro\Config;
use BitApps\IntegrationsPro\Core\Util\Hooks;

Hooks::filter(Config::withFreePrefix('creator_lms_create_student'), [CreatorLmsProHelper::class, 'createStudent'], 10, 2);
Hooks::filter(Config::withFreePrefix('creator_lms_update_student_data'), [CreatorLmsProHelper::class, 'updateStudentData'], 10, 2);
Hooks::filter(Config::withFreePrefix('creator_lms_enroll_user_in_course'), [CreatorLmsProHelper::class, 'enrollUserInCourse'], 10, 2);
Hooks::filter(Config::withFreePrefix('creator_lms_create_course'), [CreatorLmsProHelper::class, 'createCourse'], 10, 3);
Hooks::filter(Config::withFreePrefix('creator_lms_mark_lesson_completed'), [CreatorLmsProHelper::class, 'markLessonCompleted'], 10, 2);
