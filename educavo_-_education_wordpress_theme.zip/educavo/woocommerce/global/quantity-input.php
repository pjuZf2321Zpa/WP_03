<?php
/**
 * Product quantity inputs
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/global/quantity-input.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see     https://woocommerce.com/document/template-structure/
 * @package WooCommerce\Templates
 * @version 10.1.0
 *
 * @var bool   $readonly If the input should be set to readonly mode.
 * @var string $type     The input type attribute.
 */

defined( 'ABSPATH' ) || exit;

if ( $max_value && $min_value === $max_value ) {
	?>
	<div class="quantity hidden">
		<input type="hidden" id="<?php echo esc_attr( $input_id ); ?>" class="qty" name="<?php echo esc_attr( $input_name ); ?>" value="<?php echo esc_attr( $min_value ); ?>" />
	</div>
	<?php
} else {

	$labelledby = ! empty( $args['product_name'] ) ? sprintf( __( '%s quantity', 'educavo' ), wp_kses( $args['product_name'], array() ) ) : '';
	?>
	<div class="quantity">
	    <label class="screen-reader-text" for="<?php echo esc_attr( $input_id ); ?>"><?php esc_html_e( 'Quantity', 'educavo' ); ?></label>
	    <input type="button" value="-" class="qty_button minus" />
	    <input
	        type="number"
	        id="<?php echo esc_attr( $input_id ); ?>"
	        class="input-text qty text"
	        step="<?php echo esc_attr( $step ); ?>"
	        placeholder="<?php esc_attr_e( '0', 'educavo' ) ?>"
	        min="<?php echo esc_attr( 0 < $max_value ? $max_value : '' ); ?>"	        
	        max="<?php echo esc_attr( 0 < $max_value ? $max_value : '' ); ?>"
	        name="<?php echo esc_attr( $input_name ); ?>"
	        value="<?php echo esc_attr( $input_value ); ?>"
	        title="<?php echo esc_attr_x( 'Qty', 'Product quantity input tooltip', 'educavo' ); ?>"
	        size="4"
	        pattern="<?php echo esc_attr( $pattern ); ?>"
	        inputmode="<?php echo esc_attr( $inputmode ); ?>"
	        aria-labelledby="<?php echo esc_attr( $labelledby ); ?>" />
	    <input type="button" value="+" class="qty_button plus" />
	</div>
	<?php
}
