<?php

namespace BitApps\AssistPro\HTTP\Middleware;

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\AssistPro\Config;
use BitApps\AssistPro\Deps\BitApps\WPKit\Http\Response;

final class IsProCheckerMiddleware
{
    public function handle()
    {
        if (!Config::isPro()) {
            return Response::error(__('Please active with valid license.', 'bit-assist'))->httpStatus(403);
        }

        return true;
    }
}
