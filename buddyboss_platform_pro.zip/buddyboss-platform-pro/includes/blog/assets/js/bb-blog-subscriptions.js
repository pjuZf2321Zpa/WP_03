/**
 * BuddyBoss Pro Blog Subscriptions — category archive subscribe toggle.
 *
 * ES5, no dependencies. Talks to the Platform's generic subscriptions REST
 * endpoint directly (`POST /subscriptions` to subscribe, `DELETE
 * /subscriptions/{id}` to unsubscribe) instead of admin-ajax.
 *
 * @since [BBVERSION]
 */
( function () {
	'use strict';

	/**
	 * Icon class from the localized map, falling back to the ReadyLaunch glyph.
	 *
	 * @since [BBVERSION]
	 *
	 * @param {string} key      Icon key.
	 * @param {string} fallback Class to use when the map is unavailable.
	 * @return {string} Icon class.
	 */
	function subIcon( key, fallback ) {
		var conf = window.bbBlogProSubs;
		return ( conf && conf.icons && conf.icons[ key ] ) ? conf.icons[ key ] : fallback;
	}

	/**
	 * Swap one icon class set for another.
	 *
	 * An icon class may be two classes ("bb-icon-l bb-icon-bell-plus"), and
	 * classList.add()/remove() reject a string containing spaces, so split first.
	 *
	 * @since [BBVERSION]
	 *
	 * @param {Element} el      Icon element.
	 * @param {string}  remove  Class(es) to remove.
	 * @param {string}  add     Class(es) to add.
	 * @return {void}
	 */
	function swapIconClass( el, remove, add ) {
		var i;
		var out = String( remove ).split( ' ' );
		var inn = String( add ).split( ' ' );

		for ( i = 0; i < out.length; i++ ) {
			if ( out[ i ] && inn.indexOf( out[ i ] ) === -1 ) {
				el.classList.remove( out[ i ] );
			}
		}

		for ( i = 0; i < inn.length; i++ ) {
			if ( inn[ i ] ) {
				el.classList.add( inn[ i ] );
			}
		}
	}

	function bbBlogProToggleSubscription( button ) {
		if ( ! window.bbBlogProSubs || button.getAttribute( 'data-bb-blog-busy' ) ) {
			return;
		}

		var termId = button.getAttribute( 'data-term-id' );

		if ( ! termId ) {
			return;
		}

		var isSubscribed   = button.classList.contains( 'is-subscribed' );
		var subscriptionId = button.getAttribute( 'data-subscription-id' );
		var restUrl        = window.bbBlogProSubs.restUrl;
		var requestUrl      = restUrl;
		var requestMethod   = 'POST';
		var requestBody     = null;
		var requestHeaders  = {
			'X-WP-Nonce': window.bbBlogProSubs.nonce
		};

		if ( isSubscribed && subscriptionId && '0' !== subscriptionId ) {
			requestUrl    = restUrl.replace( /\/$/, '' ) + '/' + subscriptionId;
			requestMethod = 'DELETE';
		} else {
			requestHeaders[ 'Content-Type' ] = 'application/json';
			requestBody = JSON.stringify( {
				type: 'blog_category',
				item_id: parseInt( termId, 10 )
			} );
		}

		button.setAttribute( 'data-bb-blog-busy', '1' );
		button.disabled = true;

		window
			.fetch( requestUrl, {
				method: requestMethod,
				credentials: 'same-origin',
				headers: requestHeaders,
				body: requestBody
			} )
			.then( function ( response ) {
				if ( ! response.ok && 204 !== response.status ) {
					return response.json().then( function () {
						return null;
					} );
				}

				if ( 204 === response.status ) {
					return {};
				}

				return response.json();
			} )
			.then( function ( response ) {
				if ( null === response ) {
					return;
				}

				if ( isSubscribed ) {
					bbBlogProUpdateButton( button, false, 0 );
				} else if ( response && response.id ) {
					bbBlogProUpdateButton( button, true, response.id );
				}
			} )
			['catch']( function () {
				// Network/parse error -- leave button state unchanged.
			} )
			.then( function () {
				button.removeAttribute( 'data-bb-blog-busy' );
				button.disabled = false;
			} );
	}

	function bbBlogProUpdateButton( button, subscribed, subscriptionId ) {
		var labelEl = button.querySelector( '.bb-blog-subscribe__label' );
		var iconEl  = button.querySelector( '.bb-blog-subscribe__icon' );
		var labels  = window.bbBlogProSubs.labels || {};

		button.setAttribute( 'data-subscription-id', subscriptionId );

		if ( subscribed ) {
			button.classList.add( 'is-subscribed' );
			button.setAttribute( 'aria-pressed', 'true' );

			if ( labelEl && labels.subscribed ) {
				labelEl.textContent = labels.subscribed;
			}

			if ( iconEl ) {
				swapIconClass( iconEl, subIcon( 'bell', 'bb-icons-rl-bell' ), subIcon( 'bellSlash', 'bb-icons-rl-bell-slash' ) );
			}
		} else {
			button.classList.remove( 'is-subscribed' );
			button.setAttribute( 'aria-pressed', 'false' );

			if ( labelEl && labels.subscribe ) {
				labelEl.textContent = labels.subscribe;
			}

			if ( iconEl ) {
				swapIconClass( iconEl, subIcon( 'bellSlash', 'bb-icons-rl-bell-slash' ), subIcon( 'bell', 'bb-icons-rl-bell' ) );
			}
		}
	}

	document.addEventListener( 'click', function ( event ) {
		var button = event.target.closest ? event.target.closest( '.bb-blog-subscribe' ) : null;

		if ( ! button ) {
			return;
		}

		event.preventDefault();
		bbBlogProToggleSubscription( button );
	} );
} )();
