<?php

function masterstudy_lms_coming_soon_setting_keys() {
	return array(
		'lms_coming_soon_instructor_allow_status',
		'lms_coming_soon_pre_ordering_status',
		'lms_coming_soon_course_bundle_status',
	);
}

function masterstudy_lms_coming_soon_fields() {
	return array(
		'lms_coming_soon_instructor_allow_status' => array(
			'type'        => 'checkbox',
			'label'       => esc_html__( 'Allow instructors to enable Upcoming course status', 'masterstudy-lms-learning-management-system-pro' ),
			'description' => esc_html__( 'Instructors can create a course that it will be available in the future', 'masterstudy-lms-learning-management-system-pro' ),
		),
		'lms_coming_soon_pre_ordering_status'     => array(
			'type'        => 'checkbox',
			'label'       => esc_html__( 'Course preordering', 'masterstudy-lms-learning-management-system-pro' ),
			'description' => esc_html__( 'Your students can buy the course but can’t start until the specified course launch date', 'masterstudy-lms-learning-management-system-pro' ),
		),
		'lms_coming_soon_course_bundle_status'    => array(
			'type'        => 'checkbox',
			'label'       => esc_html__( 'Allow upcoming courses to be added to the Course bundles', 'masterstudy-lms-learning-management-system-pro' ),
			'description' => esc_html__( 'Enable this option to allow upcoming courses to be included in course bundles', 'masterstudy-lms-learning-management-system-pro' ),
		),
	);
}

/**
 * Inject Coming Soon settings into main LMS settings page.
 */
function masterstudy_lms_coming_soon_add_to_main_settings( $fields ) {
	$fields['section_coming_soon'] = array(
		'name'   => esc_html__( 'Upcoming Courses', 'masterstudy-lms-learning-management-system-pro' ),
		'label'  => esc_html__( 'Upcoming Courses', 'masterstudy-lms-learning-management-system-pro' ),
		'icon'   => 'stmlms-clock',
		'fields' => masterstudy_lms_coming_soon_fields(),
	);

	return $fields;
}
add_filter( 'stm_lms_main_settings_fields', 'masterstudy_lms_coming_soon_add_to_main_settings', 15 );

/**
 * Keep legacy option synced for backward compatibility.
 */
function masterstudy_lms_coming_soon_sync_with_main( $id, $settings ) {
	if ( 'stm_lms_settings' !== $id || ! is_array( $settings ) ) {
		return;
	}

	$legacy_settings = get_option( 'masterstudy_lms_coming_soon_settings', array() );

	if ( ! is_array( $legacy_settings ) ) {
		$legacy_settings = array();
	}

	foreach ( masterstudy_lms_coming_soon_setting_keys() as $key ) {
		if ( array_key_exists( $key, $settings ) ) {
			$legacy_settings[ $key ] = $settings[ $key ];
		}
	}

	update_option( 'masterstudy_lms_coming_soon_settings', $legacy_settings );
}
add_action( 'wpcfto_after_settings_saved', 'masterstudy_lms_coming_soon_sync_with_main', 10, 2 );

/**
 * Migrate old Coming Soon settings to main LMS settings.
 */
function masterstudy_lms_coming_soon_migrate_to_main_settings() {
	$legacy_settings = get_option( 'masterstudy_lms_coming_soon_settings', array() );
	$main_settings   = get_option( 'stm_lms_settings', array() );

	if ( ! is_array( $legacy_settings ) || empty( $legacy_settings ) ) {
		return;
	}

	if ( ! is_array( $main_settings ) ) {
		$main_settings = array();
	}

	$changed = false;

	foreach ( masterstudy_lms_coming_soon_setting_keys() as $key ) {
		if (
			( ! array_key_exists( $key, $main_settings ) || '' === $main_settings[ $key ] )
			&& array_key_exists( $key, $legacy_settings )
			&& '' !== $legacy_settings[ $key ]
		) {
			$main_settings[ $key ] = $legacy_settings[ $key ];
			$changed               = true;
		}
	}

	if ( $changed ) {
		update_option( 'stm_lms_settings', $main_settings );
	}
}
add_action( 'admin_init', 'masterstudy_lms_coming_soon_migrate_to_main_settings' );

/**
 * Redirect old Coming Soon settings page to LMS settings section.
 */
function masterstudy_lms_coming_soon_redirect_legacy_page() {
	if ( ! is_admin() ) {
		return;
	}

	$page = isset( $_GET['page'] ) ? sanitize_text_field( wp_unslash( $_GET['page'] ) ) : '';
	if ( 'upcoming-course-status' !== $page ) {
		return;
	}

	wp_safe_redirect( admin_url( 'admin.php?page=stm-lms-settings&submenu=upcoming_courses#section_2' ) );
	exit;
}
add_action( 'admin_init', 'masterstudy_lms_coming_soon_redirect_legacy_page' );
