<?php

namespace BitApps\IntegrationsPro\Actions\FollowUpBoss\Services;

final class ActionPlanService extends BaseService
{
    public function applyActionPlan(): array
    {
        $validationRules = [
            'person_id'      => ['required', 'integer'],
            'action_plan_id' => ['required', 'integer'],
        ];
        $error = $this->validateFields(
            $validationRules,
            [
                'person_id'      => __('Person ID', 'bit-integrations-pro'),
                'action_plan_id' => __('Action Plan', 'bit-integrations-pro'),
            ],
            ['action_plan_id']
        );

        if ($error !== null) {
            return $error;
        }

        $payload = $this->removeEmptyValues(
            [
                'personId'     => $this->getInteger('person_id'),
                'actionPlanId' => $this->getInteger('action_plan_id'),
            ]
        );

        return $this->dispatch('POST', '/actionPlansPeople', $payload);
    }

    public function updateActionPlanStatus(): array
    {
        $validationRules = [
            'action_plan_person_id' => ['required', 'integer'],
            'plan_status'           => ['required'],
        ];
        $error = $this->validateFields(
            $validationRules,
            [
                'action_plan_person_id' => __('Applied Action Plan ID', 'bit-integrations-pro'),
                'plan_status'           => __('Status', 'bit-integrations-pro'),
            ],
            ['plan_status']
        );

        if ($error !== null) {
            return $error;
        }

        $payload = $this->removeEmptyValues(
            [
                'status' => $this->getString('plan_status'),
            ]
        );

        return $this->dispatch('PUT', '/actionPlansPeople/' . rawurlencode($this->getString('action_plan_person_id')), $payload);
    }
}
