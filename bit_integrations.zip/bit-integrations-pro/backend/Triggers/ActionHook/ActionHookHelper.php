<?php

namespace BitApps\IntegrationsPro\Triggers\ActionHook;

class ActionHookHelper
{
    public static function convertToSimpleArray($value)
    {
        if (\is_object($value) && class_exists(\get_class($value))) {
            $value = json_decode(wp_json_encode($value), true);
        }

        if (\is_array($value)) {
            foreach ($value as $key => $subValue) {
                $value[$key] = static::convertToSimpleArray($subValue);
            }
        }

        return $value;
    }
    // private static function convertObjectToArray($object)
    // {
    //     $reflection = new ReflectionClass($object);
    //     $properties = $reflection->getProperties(ReflectionProperty::IS_PUBLIC | ReflectionProperty::IS_PROTECTED);
    //         $name = preg_replace('/^\x00(?:\*\x00|\w+\x00)/', '', $name);
}
