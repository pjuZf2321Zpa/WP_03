<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Actions\Bento\BentoProHelper;
use BitApps\IntegrationsPro\Config;
use BitApps\IntegrationsPro\Core\Util\Hooks;

// Deprecated since v2.7.8 - use bit_integrations_bento_* hooks instead
if (bit_integrations_version_below('2.7.8')) {
    Hooks::filter('btcbi_bento_get_user_fields', [BentoProHelper::class, 'getUserFields'], 10, 2);
    Hooks::filter('btcbi_bento_get_event_fields', [BentoProHelper::class, 'getEventFields'], 10, 1);
    Hooks::filter('btcbi_bento_get_all_tags', [BentoProHelper::class, 'getAllTags'], 10, 2);
    Hooks::filter('btcbi_bento_store_event', [BentoProHelper::class, 'storeEvent'], 10, 3);
    Hooks::add('btcbi_bento_update_user_data', [BentoProHelper::class, 'updateUserData'], 10, 5);
}

// New hooks since v2.7.8
Hooks::filter(Config::withFreePrefix('bento_get_user_fields'), [BentoProHelper::class, 'getUserFields'], 10, 2);
Hooks::filter(Config::withFreePrefix('bento_get_event_fields'), [BentoProHelper::class, 'getEventFields'], 10, 1);
Hooks::filter(Config::withFreePrefix('bento_get_all_tags'), [BentoProHelper::class, 'getAllTags'], 10, 2);
Hooks::filter(Config::withFreePrefix('bento_store_event'), [BentoProHelper::class, 'storeEvent'], 10, 3);
Hooks::add(Config::withFreePrefix('bento_update_user_data'), [BentoProHelper::class, 'updateUserData'], 10, 5);
