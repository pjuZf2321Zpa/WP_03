<?php

namespace WPAICG\Lib\Settings;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Native app settings supplied by the Pro composition root.
 * Integration services retain their existing availability and persistence rules.
 */
final class SettingsFeatures
{
    /**
     * Save connection and recipe drafts in their existing order.
     */
    public static function save_native_app_settings(array $post_data): void
    {
        $raw_settings = $post_data['native_app_recipes'] ?? null;
        if (!is_array($raw_settings)) {
            return;
        }

        foreach ([
            'connections' => ['\\WPAICG\\Lib\\Integrations\\Apps\\AIPKit_App_Connections', 'save_connections'],
            'recipes' => ['\\WPAICG\\Lib\\Integrations\\Recipes\\AIPKit_Stored_Recipes', 'save_recipes'],
        ] as $key => [$class, $method]) {
            if (!class_exists($class) || !method_exists($class, $method)) {
                continue;
            }
            $values = $raw_settings[$key] ?? [];
            $class::$method(is_array($values) ? $values : [], get_current_user_id());
        }
    }

    /**
     * Return only allowlisted password fields from stored app connections.
     */
    public static function get_app_connection_secret(string $connection_id, string $field_path): string
    {
        $connections_class = '\\WPAICG\\Lib\\Integrations\\Apps\\AIPKit_App_Connections';
        if (!class_exists($connections_class)
            || !method_exists($connections_class, 'get_connection_by_id')
            || !method_exists($connections_class, 'get_app_field_definitions')) {
            return '';
        }

        $path_parts = explode('.', $field_path, 2);
        if (count($path_parts) !== 2) {
            return '';
        }
        $group = sanitize_key($path_parts[0]);
        $field_key = sanitize_key($path_parts[1]);
        if ($group !== 'credentials' || $field_key === '') {
            return '';
        }

        $connection = $connections_class::get_connection_by_id($connection_id);
        if (!is_array($connection)) {
            return '';
        }
        $app_slug = sanitize_key((string) ($connection['app_slug'] ?? ''));
        $definitions = $connections_class::get_app_field_definitions();
        $allowed = false;
        foreach ((array) ($definitions[$app_slug] ?? []) as $definition) {
            if (!is_array($definition)) {
                continue;
            }
            if (sanitize_key((string) ($definition['group'] ?? '')) === $group
                && sanitize_key((string) ($definition['key'] ?? '')) === $field_key
                && sanitize_key((string) ($definition['type'] ?? '')) === 'password') {
                $allowed = true;
                break;
            }
        }
        if (!$allowed) {
            return '';
        }

        $stored_group = isset($connection[$group]) && is_array($connection[$group])
            ? $connection[$group]
            : [];
        return sanitize_text_field((string) ($stored_group[$field_key] ?? ''));
    }
}
