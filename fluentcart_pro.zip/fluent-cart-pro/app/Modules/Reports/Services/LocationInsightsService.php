<?php

namespace FluentCartPro\App\Modules\Reports\Services;

use FluentCart\App\Services\Report\LocationReportService;

/**
 * The Pro Locations report: states and cities, lifetime value and repeat rate per place, and the biggest movers.
 */
class LocationInsightsService extends LocationReportService
{
    public function getDetails(array $params): array
    {
        return $this->report($params, true);
    }
}
