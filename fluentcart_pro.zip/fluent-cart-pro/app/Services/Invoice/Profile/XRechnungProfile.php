<?php

declare(strict_types=1);

namespace FluentCartPro\App\Services\Invoice\Profile;

if (!defined('ABSPATH')) {
    exit;
}

use FluentCartPro\App\Services\Invoice\Domain\CalculatedTotals;
use FluentCartPro\App\Services\Invoice\Domain\En16931Invoice;

/**
 * XRechnung (CIUS) profile. Delegates to EN 16931 plus future XRechnung-specific rules.
 */
final class XRechnungProfile implements InvoiceProfileInterface
{
    private ZugferdEn16931Profile $en16931;

    public function __construct()
    {
        $this->en16931 = new ZugferdEn16931Profile();
    }

    public function getProfileId(): string
    {
        return 'urn:cen.eu:en16931:2017#compliant#urn:xoev-de:kosit:standard:xrechnung_2.3';
    }

    public function getSyntax(): string
    {
        return 'CII';
    }

    public function validate(En16931Invoice $invoice, CalculatedTotals $totals): void
    {
        $this->en16931->validate($invoice, $totals);
    }
}
