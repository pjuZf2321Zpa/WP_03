<?php

namespace MasterStudy\Lms\Pro\AddonsPlus\Notifications\Http\Controllers;

use MasterStudy\Lms\Http\WpResponseFactory;
use MasterStudy\Lms\Pro\AddonsPlus\Notifications\Repositories\PushSubscriptionRepository;
use MasterStudy\Lms\Pro\AddonsPlus\Notifications\Services\Push\PushRequirements;
use MasterStudy\Lms\Validation\Validator;
use WP_REST_Request;
use WP_REST_Response;

final class SubscribePushController {
	public function __invoke( WP_REST_Request $request ): WP_REST_Response {
		try {
			if ( ! function_exists( 'masterstudy_lms_is_notifications_push_frontend_available' ) || ! masterstudy_lms_is_notifications_push_frontend_available() ) {
				return WpResponseFactory::forbidden();
			}

			$missing_message = PushRequirements::missing_message();

			if ( '' !== $missing_message ) {
				return WpResponseFactory::error( esc_html__( 'Push notifications are not available on this server.', 'masterstudy-lms-learning-management-system-pro' ) );
			}

			$params = $request->get_json_params();

			if ( empty( $params ) ) {
				$params = $request->get_params();
			}

			$allowed_encodings     = implode( ';', PushSubscriptionRepository::ALLOWED_ENCODINGS );
			$content_encoding_rule = sprintf(
				'nullable|string|max,%d|contains_list,%s',
				PushSubscriptionRepository::CONTENT_ENCODING_MAX_LENGTH,
				$allowed_encodings
			);
			$validator             = new Validator(
				$params,
				array(
					'browser_key'                  => 'required|string|max,' . PushSubscriptionRepository::BROWSER_KEY_MAX_LENGTH,
					'subscription'                 => 'required|array',
					'subscription.endpoint'        => 'required|string|max,' . PushSubscriptionRepository::ENDPOINT_MAX_LENGTH,
					'subscription.keys'            => 'required|array',
					'subscription.keys.p256dh'     => 'required|string|max,' . PushSubscriptionRepository::PUBLIC_KEY_MAX_LENGTH,
					'subscription.keys.auth'       => 'required|string|max,' . PushSubscriptionRepository::AUTH_TOKEN_MAX_LENGTH,
					'subscription.contentEncoding' => $content_encoding_rule,
				)
			);

			if ( $validator->fails() ) {
				return WpResponseFactory::validation_failed( $validator->get_errors_array() );
			}

			$validated    = $validator->get_validated();
			$subscription = $params['subscription'];
			$encoded      = wp_json_encode( $subscription );

			if ( false === $encoded || strlen( $encoded ) > PushSubscriptionRepository::SUBSCRIPTION_JSON_MAX_LENGTH ) {
				return WpResponseFactory::bad_request( esc_html__( 'Push subscription payload is too large.', 'masterstudy-lms-learning-management-system-pro' ) );
			}

			$browser_key = sanitize_text_field( (string) $validated['browser_key'] );
			$user_agent  = isset( $_SERVER['HTTP_USER_AGENT'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_USER_AGENT'] ) ) : '';
			$updated     = ( new PushSubscriptionRepository() )->upsert( get_current_user_id(), $browser_key, $subscription, $user_agent );

			if ( ! $updated ) {
				return WpResponseFactory::bad_request( esc_html__( 'Unable to save push subscription.', 'masterstudy-lms-learning-management-system-pro' ) );
			}

			return WpResponseFactory::ok();
		} catch ( \Throwable $error ) {
			return WpResponseFactory::error( esc_html__( 'Unable to save push subscription.', 'masterstudy-lms-learning-management-system-pro' ) );
		}
	}
}
