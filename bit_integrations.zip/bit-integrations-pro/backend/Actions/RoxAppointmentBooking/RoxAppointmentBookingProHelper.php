<?php

namespace BitApps\IntegrationsPro\Actions\RoxAppointmentBooking;

use RoxAppointmentBooking\Modules\Agent\Data\AgentModel;
use RoxAppointmentBooking\Modules\Agent\Services\AgentService;
use RoxAppointmentBooking\Modules\Appointment\Data\AppointmentModel;
use RoxAppointmentBooking\Modules\Category\Data\CategoryModel;
use RoxAppointmentBooking\Modules\Category\Services\CategoryService;
use RoxAppointmentBooking\Modules\Customer\Data\CustomerModel;
use RoxAppointmentBooking\Modules\Customer\Services\CustomerService;
use RoxAppointmentBooking\Modules\Notification\Services\NotificationService;
use RoxAppointmentBooking\Modules\Order\Data\OrderModel;
use RoxAppointmentBooking\Modules\Order\Services\OrderService;
use RoxAppointmentBooking\Modules\Payment\Data\PaymentModel;
use RoxAppointmentBooking\Modules\Payment\Services\PaymentStatusSyncService;
use RoxAppointmentBooking\Modules\Service\Data\ServiceModel;
use RoxAppointmentBooking\Modules\Service\Services\ServiceService;
use Throwable;

final class RoxAppointmentBookingProHelper
{
    private const CUSTOMER_COLUMNS = ['first_name', 'last_name', 'email', 'phone', 'gender', 'dob', 'allow_to_login', 'wp_user_id', 'send_notifications', 'internal_notes'];

    private const AGENT_COLUMNS = ['first_name', 'last_name', 'title', 'email', 'phone', 'allow_to_login', 'wp_user_id', 'location_id', 'experience_years', 'certifications', 'bio', 'status', 'internal_notes'];

    private const SERVICE_COLUMNS = ['title', 'description', 'duration', 'price', 'capacity', 'max_capacity', 'deposit', 'deposit_type', 'deposit_amount', 'color', 'sort_order', 'status', 'internal_notes'];

    private const CATEGORY_COLUMNS = ['title', 'slug', 'description', 'sort_order', 'internal_notes'];

    private const APPOINTMENT_COLUMNS = ['location_id', 'category_id', 'service_id', 'agent_id', 'customer_id', 'date', 'start_time', 'end_time', 'coupon_id', 'status', 'payment_status', 'total_attendees', 'send_notification', 'reminder_notification', 'internal_notes'];

    private const ORDER_COLUMNS = ['customer_id', 'subtotal', 'discount_amount', 'tax_amount', 'total_amount', 'currency', 'coupon_id', 'coupon_code', 'payment_method', 'payment_status', 'payment_transaction_id', 'order_status', 'order_date', 'internal_notes'];

    private const PAYMENT_COLUMNS = ['customer_id', 'order_id', 'booking_id', 'amount', 'status', 'payment_method', 'transaction_id', 'payment_time', 'internal_notes'];

    private const NOTIFICATION_COLUMNS = ['user_id', 'title', 'description', 'type', 'notification_time'];

    public static function createCustomer($response, $fieldData)
    {
        if (!RoxAppointmentBookingHelper::isPluginActive() || !class_exists(CustomerService::class)) {
            return RoxAppointmentBookingHelper::inactive();
        }

        list($fieldData, $resolveError) = RoxAppointmentBookingHelper::resolveIds($fieldData);

        if ($resolveError) {
            return $resolveError;
        }

        $missing = RoxAppointmentBookingHelper::missingRequired($fieldData, ['first_name', 'last_name', 'email']);

        if ($missing) {
            return RoxAppointmentBookingHelper::requiredError($missing);
        }

        try {
            $customer = (new CustomerService())->saveCustomer(RoxAppointmentBookingHelper::payload($fieldData, self::CUSTOMER_COLUMNS));
        } catch (Throwable $e) {
            return RoxAppointmentBookingHelper::error($e->getMessage());
        }

        return RoxAppointmentBookingHelper::success(__('Customer created successfully', 'bit-integrations-pro'), RoxAppointmentBookingHelper::attributes($customer));
    }

    public static function updateCustomer($response, $fieldData)
    {
        if (!RoxAppointmentBookingHelper::isPluginActive() || !class_exists(CustomerService::class)) {
            return RoxAppointmentBookingHelper::inactive();
        }

        list($fieldData, $resolveError) = RoxAppointmentBookingHelper::resolveIds($fieldData);

        if ($resolveError) {
            return $resolveError;
        }

        $missing = RoxAppointmentBookingHelper::missingRequired($fieldData, [['customer_id', 'find_by_customer_email']]);

        if ($missing) {
            return RoxAppointmentBookingHelper::requiredError($missing);
        }

        $customerId = (int) $fieldData['customer_id'];
        $existing = CustomerModel::find($customerId);

        if (!$existing) {
            return RoxAppointmentBookingHelper::error(__('Customer not found', 'bit-integrations-pro'));
        }

        $payload = array_merge(
            ['first_name' => $existing->first_name, 'last_name' => $existing->last_name, 'email' => $existing->email],
            RoxAppointmentBookingHelper::payload($fieldData, self::CUSTOMER_COLUMNS)
        );

        try {
            $customer = (new CustomerService())->saveCustomer($payload, $customerId);
        } catch (Throwable $e) {
            return RoxAppointmentBookingHelper::error($e->getMessage());
        }

        return RoxAppointmentBookingHelper::success(__('Customer updated successfully', 'bit-integrations-pro'), RoxAppointmentBookingHelper::attributes($customer));
    }

    public static function deleteCustomer($response, $fieldData)
    {
        return self::deleteRecord($fieldData, 'customer_id', CustomerModel::class, __('Customer', 'bit-integrations-pro'), ['find_by_customer_email']);
    }

    public static function createAgent($response, $fieldData, $utilities = null, $integrationDetails = null)
    {
        if (!RoxAppointmentBookingHelper::isPluginActive() || !class_exists(AgentService::class)) {
            return RoxAppointmentBookingHelper::inactive();
        }

        list($fieldData, $resolveError) = RoxAppointmentBookingHelper::resolveIds($fieldData);

        if ($resolveError) {
            return $resolveError;
        }

        $missing = RoxAppointmentBookingHelper::missingRequired($fieldData, ['first_name', 'last_name', 'email']);

        if ($missing) {
            return RoxAppointmentBookingHelper::requiredError($missing);
        }

        $payload = RoxAppointmentBookingHelper::payload($fieldData, self::AGENT_COLUMNS);

        $status = RoxAppointmentBookingHelper::utility($utilities, 'selected_agent_status');

        if ($status) {
            $payload['status'] = $status;
        }

        $payload = self::applyCatalogSelects($payload, $integrationDetails, ['selectedLocation' => 'location_id']);

        try {
            $agent = (new AgentService())->saveAgent(self::withFullName($payload));
        } catch (Throwable $e) {
            return RoxAppointmentBookingHelper::error($e->getMessage());
        }

        return RoxAppointmentBookingHelper::success(__('Agent created successfully', 'bit-integrations-pro'), RoxAppointmentBookingHelper::attributes($agent));
    }

    public static function updateAgent($response, $fieldData)
    {
        if (!RoxAppointmentBookingHelper::isPluginActive() || !class_exists(AgentService::class)) {
            return RoxAppointmentBookingHelper::inactive();
        }

        list($fieldData, $resolveError) = RoxAppointmentBookingHelper::resolveIds($fieldData);

        if ($resolveError) {
            return $resolveError;
        }

        $missing = RoxAppointmentBookingHelper::missingRequired($fieldData, [['agent_id', 'find_by_agent_email']]);

        if ($missing) {
            return RoxAppointmentBookingHelper::requiredError($missing);
        }

        $agentId = (int) $fieldData['agent_id'];
        $existing = AgentModel::find($agentId);

        if (!$existing) {
            return RoxAppointmentBookingHelper::error(__('Agent not found', 'bit-integrations-pro'));
        }

        $payload = array_merge(
            ['first_name' => $existing->first_name, 'last_name' => $existing->last_name, 'email' => $existing->email],
            RoxAppointmentBookingHelper::payload($fieldData, self::AGENT_COLUMNS)
        );

        try {
            $agent = (new AgentService())->saveAgent(self::withFullName($payload), $agentId);
        } catch (Throwable $e) {
            return RoxAppointmentBookingHelper::error($e->getMessage());
        }

        return RoxAppointmentBookingHelper::success(__('Agent updated successfully', 'bit-integrations-pro'), RoxAppointmentBookingHelper::attributes($agent));
    }

    public static function deleteAgent($response, $fieldData)
    {
        return self::deleteRecord($fieldData, 'agent_id', AgentModel::class, __('Agent', 'bit-integrations-pro'), ['find_by_agent_email']);
    }

    public static function createService($response, $fieldData, $utilities = null)
    {
        if (!RoxAppointmentBookingHelper::isPluginActive() || !class_exists(ServiceService::class)) {
            return RoxAppointmentBookingHelper::inactive();
        }

        list($fieldData, $resolveError) = RoxAppointmentBookingHelper::resolveIds($fieldData);

        if ($resolveError) {
            return $resolveError;
        }

        $missing = RoxAppointmentBookingHelper::missingRequired($fieldData, ['title', 'duration', 'price']);

        if ($missing) {
            return RoxAppointmentBookingHelper::requiredError($missing);
        }

        $payload = RoxAppointmentBookingHelper::payload($fieldData, self::SERVICE_COLUMNS);

        $status = RoxAppointmentBookingHelper::utility($utilities, 'selected_service_status');

        if ($status) {
            $payload['status'] = $status;
        }

        try {
            $service = (new ServiceService())->saveService($payload);
        } catch (Throwable $e) {
            return RoxAppointmentBookingHelper::error($e->getMessage());
        }

        return RoxAppointmentBookingHelper::success(__('Service created successfully', 'bit-integrations-pro'), RoxAppointmentBookingHelper::attributes($service));
    }

    public static function updateService($response, $fieldData)
    {
        if (!RoxAppointmentBookingHelper::isPluginActive() || !class_exists(ServiceService::class)) {
            return RoxAppointmentBookingHelper::inactive();
        }

        list($fieldData, $resolveError) = RoxAppointmentBookingHelper::resolveIds($fieldData);

        if ($resolveError) {
            return $resolveError;
        }

        $missing = RoxAppointmentBookingHelper::missingRequired($fieldData, [['service_id', 'find_by_service_title']]);

        if ($missing) {
            return RoxAppointmentBookingHelper::requiredError($missing);
        }

        $serviceId = (int) $fieldData['service_id'];
        $existing = ServiceModel::find($serviceId);

        if (!$existing) {
            return RoxAppointmentBookingHelper::error(__('Service not found', 'bit-integrations-pro'));
        }

        $payload = array_merge(
            ['title' => $existing->title, 'duration' => $existing->duration, 'price' => $existing->price],
            RoxAppointmentBookingHelper::payload($fieldData, self::SERVICE_COLUMNS)
        );

        try {
            $service = (new ServiceService())->saveService($payload, $serviceId);
        } catch (Throwable $e) {
            return RoxAppointmentBookingHelper::error($e->getMessage());
        }

        return RoxAppointmentBookingHelper::success(__('Service updated successfully', 'bit-integrations-pro'), RoxAppointmentBookingHelper::attributes($service));
    }

    public static function updateServiceStatus($response, $fieldData, $integrationDetails = null)
    {
        if (!RoxAppointmentBookingHelper::isPluginActive() || !class_exists(ServiceService::class)) {
            return RoxAppointmentBookingHelper::inactive();
        }

        list($fieldData, $resolveError) = RoxAppointmentBookingHelper::resolveIds($fieldData);

        if ($resolveError) {
            return $resolveError;
        }

        $missing = RoxAppointmentBookingHelper::missingRequired($fieldData, [['service_id', 'find_by_service_title']]);

        if ($missing) {
            return RoxAppointmentBookingHelper::requiredError($missing);
        }

        $status = RoxAppointmentBookingHelper::config($integrationDetails, 'selectedServiceStatus');

        if (empty($status)) {
            return RoxAppointmentBookingHelper::error(__('Status is required', 'bit-integrations-pro'));
        }

        $serviceId = (int) $fieldData['service_id'];

        if (!ServiceModel::find($serviceId)) {
            return RoxAppointmentBookingHelper::error(__('Service not found', 'bit-integrations-pro'));
        }

        try {
            $updated = (new ServiceService())->bulkUpdateStatus([$serviceId], $status);
        } catch (Throwable $e) {
            return RoxAppointmentBookingHelper::error($e->getMessage());
        }

        if (!$updated) {
            return RoxAppointmentBookingHelper::error(__('Failed to update the service status', 'bit-integrations-pro'));
        }

        return RoxAppointmentBookingHelper::success(__('Service status updated successfully', 'bit-integrations-pro'), ['id' => $serviceId, 'status' => $status]);
    }

    public static function deleteService($response, $fieldData)
    {
        return self::deleteRecord($fieldData, 'service_id', ServiceModel::class, __('Service', 'bit-integrations-pro'), ['find_by_service_title']);
    }

    public static function createCategory($response, $fieldData)
    {
        if (!RoxAppointmentBookingHelper::isPluginActive() || !class_exists(CategoryService::class)) {
            return RoxAppointmentBookingHelper::inactive();
        }

        list($fieldData, $resolveError) = RoxAppointmentBookingHelper::resolveIds($fieldData);

        if ($resolveError) {
            return $resolveError;
        }

        $missing = RoxAppointmentBookingHelper::missingRequired($fieldData, ['title']);

        if ($missing) {
            return RoxAppointmentBookingHelper::requiredError($missing);
        }

        $category = CategoryService::createCategory(RoxAppointmentBookingHelper::payload($fieldData, self::CATEGORY_COLUMNS));

        if (!$category) {
            return RoxAppointmentBookingHelper::error(__('Failed to create the category', 'bit-integrations-pro'));
        }

        return RoxAppointmentBookingHelper::success(__('Category created successfully', 'bit-integrations-pro'), RoxAppointmentBookingHelper::attributes($category));
    }

    public static function updateCategory($response, $fieldData)
    {
        if (!RoxAppointmentBookingHelper::isPluginActive() || !class_exists(CategoryService::class)) {
            return RoxAppointmentBookingHelper::inactive();
        }

        list($fieldData, $resolveError) = RoxAppointmentBookingHelper::resolveIds($fieldData);

        if ($resolveError) {
            return $resolveError;
        }

        $missing = RoxAppointmentBookingHelper::missingRequired($fieldData, [['category_id', 'find_by_category_slug', 'find_by_category_title']]);

        if ($missing) {
            return RoxAppointmentBookingHelper::requiredError($missing);
        }

        $categoryId = (int) $fieldData['category_id'];

        if (!CategoryModel::find($categoryId)) {
            return RoxAppointmentBookingHelper::error(__('Category not found', 'bit-integrations-pro'));
        }

        if (!CategoryService::updateCategory($categoryId, RoxAppointmentBookingHelper::payload($fieldData, self::CATEGORY_COLUMNS))) {
            return RoxAppointmentBookingHelper::error(__('Failed to update the category', 'bit-integrations-pro'));
        }

        return RoxAppointmentBookingHelper::success(__('Category updated successfully', 'bit-integrations-pro'), ['id' => $categoryId]);
    }

    public static function deleteCategory($response, $fieldData)
    {
        return self::deleteRecord($fieldData, 'category_id', CategoryModel::class, __('Category', 'bit-integrations-pro'), ['find_by_category_slug', 'find_by_category_title']);
    }

    public static function createAppointment($response, $fieldData, $utilities = null, $integrationDetails = null)
    {
        if (!RoxAppointmentBookingHelper::isPluginActive() || !class_exists(AppointmentModel::class)) {
            return RoxAppointmentBookingHelper::inactive();
        }

        list($fieldData, $resolveError) = RoxAppointmentBookingHelper::resolveIds($fieldData);

        if ($resolveError) {
            return $resolveError;
        }

        $missing = RoxAppointmentBookingHelper::missingRequired($fieldData, [['customer_id', 'find_by_customer_email'], 'date', 'start_time']);

        if ($missing) {
            return RoxAppointmentBookingHelper::requiredError($missing);
        }

        $payload = RoxAppointmentBookingHelper::payload($fieldData, self::APPOINTMENT_COLUMNS);

        $status = RoxAppointmentBookingHelper::utility($utilities, 'selected_appointment_status');
        $paymentStatus = RoxAppointmentBookingHelper::utility($utilities, 'selected_payment_status');

        if ($status) {
            $payload['status'] = $status;
        }

        if ($paymentStatus) {
            $payload['payment_status'] = $paymentStatus;
        }

        $payload = self::applyCatalogSelects($payload, $integrationDetails, [
            'selectedService'  => 'service_id',
            'selectedAgent'    => 'agent_id',
            'selectedCategory' => 'category_id',
            'selectedLocation' => 'location_id',
        ]);

        if (empty($payload['service_id'])) {
            return RoxAppointmentBookingHelper::error(__('A service must be selected', 'bit-integrations-pro'));
        }

        $notFound = self::missingReference($payload, self::appointmentReferences());

        if ($notFound) {
            return $notFound;
        }

        $appointment = AppointmentModel::create($payload);

        if (!$appointment || !$appointment->getID()) {
            return RoxAppointmentBookingHelper::error(__('Failed to create the appointment', 'bit-integrations-pro'));
        }

        return RoxAppointmentBookingHelper::success(__('Appointment created successfully', 'bit-integrations-pro'), RoxAppointmentBookingHelper::attributes($appointment));
    }

    public static function updateAppointment($response, $fieldData, $integrationDetails = null)
    {
        if (!RoxAppointmentBookingHelper::isPluginActive() || !class_exists(AppointmentModel::class)) {
            return RoxAppointmentBookingHelper::inactive();
        }

        list($fieldData, $resolveError) = RoxAppointmentBookingHelper::resolveIds($fieldData);

        if ($resolveError) {
            return $resolveError;
        }

        $missing = RoxAppointmentBookingHelper::missingRequired($fieldData, ['appointment_id']);

        if ($missing) {
            return RoxAppointmentBookingHelper::requiredError($missing);
        }

        $appointmentId = (int) $fieldData['appointment_id'];
        $appointment = AppointmentModel::find($appointmentId);

        if (!$appointment) {
            return RoxAppointmentBookingHelper::error(__('Appointment not found', 'bit-integrations-pro'));
        }

        $payload = self::applyCatalogSelects(
            RoxAppointmentBookingHelper::payload($fieldData, self::APPOINTMENT_COLUMNS),
            $integrationDetails,
            ['selectedAgent' => 'agent_id']
        );

        $notFound = self::missingReference($payload, self::appointmentReferences());

        if ($notFound) {
            return $notFound;
        }

        if (empty($payload) || !$appointment->update($payload)) {
            return RoxAppointmentBookingHelper::error(__('Failed to update the appointment', 'bit-integrations-pro'));
        }

        return RoxAppointmentBookingHelper::success(__('Appointment updated successfully', 'bit-integrations-pro'), ['id' => $appointmentId]);
    }

    public static function updateAppointmentStatus($response, $fieldData, $integrationDetails = null)
    {
        if (!RoxAppointmentBookingHelper::isPluginActive() || !class_exists(AppointmentModel::class)) {
            return RoxAppointmentBookingHelper::inactive();
        }

        list($fieldData, $resolveError) = RoxAppointmentBookingHelper::resolveIds($fieldData);

        if ($resolveError) {
            return $resolveError;
        }

        $missing = RoxAppointmentBookingHelper::missingRequired($fieldData, ['appointment_id']);

        if ($missing) {
            return RoxAppointmentBookingHelper::requiredError($missing);
        }

        $status = RoxAppointmentBookingHelper::config($integrationDetails, 'selectedAppointmentStatus');

        if (empty($status)) {
            return RoxAppointmentBookingHelper::error(__('Status is required', 'bit-integrations-pro'));
        }

        $allowed = RoxAppointmentBookingHelper::allowedStatuses('rox_appointment_booking_appointment_statuses');

        if (RoxAppointmentBookingHelper::invalidStatus($status, $allowed)) {
            return RoxAppointmentBookingHelper::invalidStatusError($allowed);
        }

        $appointmentId = (int) $fieldData['appointment_id'];
        $appointment = AppointmentModel::find($appointmentId);

        if (!$appointment) {
            return RoxAppointmentBookingHelper::error(__('Appointment not found', 'bit-integrations-pro'));
        }

        if (!$appointment->update(['status' => $status])) {
            return RoxAppointmentBookingHelper::error(__('Failed to update the appointment status', 'bit-integrations-pro'));
        }

        return RoxAppointmentBookingHelper::success(__('Appointment status updated successfully', 'bit-integrations-pro'), ['id' => $appointmentId, 'status' => $status]);
    }

    public static function deleteAppointment($response, $fieldData)
    {
        return self::deleteRecord($fieldData, 'appointment_id', AppointmentModel::class, __('Appointment', 'bit-integrations-pro'));
    }

    public static function createOrder($response, $fieldData, $utilities = null)
    {
        if (!RoxAppointmentBookingHelper::isPluginActive() || !class_exists(OrderService::class)) {
            return RoxAppointmentBookingHelper::inactive();
        }

        list($fieldData, $resolveError) = RoxAppointmentBookingHelper::resolveIds($fieldData);

        if ($resolveError) {
            return $resolveError;
        }

        $missing = RoxAppointmentBookingHelper::missingRequired($fieldData, [['customer_id', 'find_by_customer_email'], 'total_amount']);

        if ($missing) {
            return RoxAppointmentBookingHelper::requiredError($missing);
        }

        if (!CustomerModel::find((int) $fieldData['customer_id'])) {
            return RoxAppointmentBookingHelper::error(__('Customer not found', 'bit-integrations-pro'));
        }

        $payload = RoxAppointmentBookingHelper::payload($fieldData, self::ORDER_COLUMNS);

        foreach (['selected_order_status' => 'order_status', 'selected_order_payment_status' => 'payment_status', 'selected_order_payment_method' => 'payment_method'] as $utilityKey => $column) {
            $value = RoxAppointmentBookingHelper::utility($utilities, $utilityKey);

            if ($value) {
                $payload[$column] = $value;
            }
        }

        try {
            $order = (new OrderService())->saveOrder($payload);
        } catch (Throwable $e) {
            return RoxAppointmentBookingHelper::error($e->getMessage());
        }

        return RoxAppointmentBookingHelper::success(__('Order created successfully', 'bit-integrations-pro'), RoxAppointmentBookingHelper::attributes($order));
    }

    public static function updateOrder($response, $fieldData)
    {
        if (!RoxAppointmentBookingHelper::isPluginActive() || !class_exists(OrderService::class)) {
            return RoxAppointmentBookingHelper::inactive();
        }

        list($fieldData, $resolveError) = RoxAppointmentBookingHelper::resolveIds($fieldData);

        if ($resolveError) {
            return $resolveError;
        }

        $missing = RoxAppointmentBookingHelper::missingRequired($fieldData, [['order_id', 'find_by_order_number']]);

        if ($missing) {
            return RoxAppointmentBookingHelper::requiredError($missing);
        }

        $orderId = (int) $fieldData['order_id'];

        if (!OrderModel::find($orderId)) {
            return RoxAppointmentBookingHelper::error(__('Order not found', 'bit-integrations-pro'));
        }

        $payload = RoxAppointmentBookingHelper::payload($fieldData, self::ORDER_COLUMNS);

        $notFound = self::missingReference($payload, ['customer_id' => [CustomerModel::class, __('Customer', 'bit-integrations-pro')]]);

        if ($notFound) {
            return $notFound;
        }

        try {
            $order = (new OrderService())->saveOrder($payload, $orderId);
        } catch (Throwable $e) {
            return RoxAppointmentBookingHelper::error($e->getMessage());
        }

        return RoxAppointmentBookingHelper::success(__('Order updated successfully', 'bit-integrations-pro'), RoxAppointmentBookingHelper::attributes($order));
    }

    public static function updateOrderStatus($response, $fieldData, $integrationDetails = null)
    {
        if (!RoxAppointmentBookingHelper::isPluginActive() || !class_exists(OrderService::class)) {
            return RoxAppointmentBookingHelper::inactive();
        }

        list($fieldData, $resolveError) = RoxAppointmentBookingHelper::resolveIds($fieldData);

        if ($resolveError) {
            return $resolveError;
        }

        $missing = RoxAppointmentBookingHelper::missingRequired($fieldData, [['order_id', 'find_by_order_number']]);

        if ($missing) {
            return RoxAppointmentBookingHelper::requiredError($missing);
        }

        $status = RoxAppointmentBookingHelper::config($integrationDetails, 'selectedOrderStatus');

        if (empty($status)) {
            return RoxAppointmentBookingHelper::error(__('Order status is required', 'bit-integrations-pro'));
        }

        $allowed = RoxAppointmentBookingHelper::allowedStatuses('rox_appointment_booking_order_statuses');

        if (RoxAppointmentBookingHelper::invalidStatus($status, $allowed)) {
            return RoxAppointmentBookingHelper::invalidStatusError($allowed);
        }

        $orderId = (int) $fieldData['order_id'];

        if (!OrderModel::find($orderId)) {
            return RoxAppointmentBookingHelper::error(__('Order not found', 'bit-integrations-pro'));
        }

        try {
            $order = (new OrderService())->updateOrderStatus($orderId, $status);
        } catch (Throwable $e) {
            return RoxAppointmentBookingHelper::error($e->getMessage());
        }

        return RoxAppointmentBookingHelper::success(__('Order status updated successfully', 'bit-integrations-pro'), RoxAppointmentBookingHelper::attributes($order));
    }

    public static function refundOrder($response, $fieldData)
    {
        if (!RoxAppointmentBookingHelper::isPluginActive() || !class_exists(OrderService::class)) {
            return RoxAppointmentBookingHelper::inactive();
        }

        list($fieldData, $resolveError) = RoxAppointmentBookingHelper::resolveIds($fieldData);

        if ($resolveError) {
            return $resolveError;
        }

        $missing = RoxAppointmentBookingHelper::missingRequired($fieldData, [['order_id', 'find_by_order_number'], 'refund_amount']);

        if ($missing) {
            return RoxAppointmentBookingHelper::requiredError($missing);
        }

        $orderId = (int) $fieldData['order_id'];
        $existing = OrderModel::find($orderId);

        if (!$existing) {
            return RoxAppointmentBookingHelper::error(__('Order not found', 'bit-integrations-pro'));
        }

        $refundAmount = (float) $fieldData['refund_amount'];

        if ($refundAmount <= 0) {
            return RoxAppointmentBookingHelper::error(__('Refund amount must be greater than 0', 'bit-integrations-pro'));
        }

        if ($refundAmount > (float) $existing->total_amount) {
            return RoxAppointmentBookingHelper::error(__('Refund amount cannot exceed the order total', 'bit-integrations-pro'));
        }

        try {
            $order = (new OrderService())->processRefund($orderId, $refundAmount, (string) ($fieldData['refund_reason'] ?? ''));
        } catch (Throwable $e) {
            return RoxAppointmentBookingHelper::error($e->getMessage());
        }

        return RoxAppointmentBookingHelper::success(__('Order refunded successfully', 'bit-integrations-pro'), RoxAppointmentBookingHelper::attributes($order));
    }

    public static function deleteOrder($response, $fieldData)
    {
        return self::deleteRecord($fieldData, 'order_id', OrderModel::class, __('Order', 'bit-integrations-pro'), ['find_by_order_number']);
    }

    public static function createPayment($response, $fieldData, $utilities = null)
    {
        if (!RoxAppointmentBookingHelper::isPluginActive() || !class_exists(PaymentModel::class)) {
            return RoxAppointmentBookingHelper::inactive();
        }

        list($fieldData, $resolveError) = RoxAppointmentBookingHelper::resolveIds($fieldData);

        if ($resolveError) {
            return $resolveError;
        }

        $missing = RoxAppointmentBookingHelper::missingRequired($fieldData, [['customer_id', 'find_by_customer_email'], 'amount']);

        if ($missing) {
            return RoxAppointmentBookingHelper::requiredError($missing);
        }

        $notFound = self::missingReference($fieldData, [
            'customer_id' => [CustomerModel::class, __('Customer', 'bit-integrations-pro')],
            'order_id'    => [OrderModel::class, __('Order', 'bit-integrations-pro')],
            'booking_id'  => [AppointmentModel::class, __('Appointment', 'bit-integrations-pro')],
        ]);

        if ($notFound) {
            return $notFound;
        }

        $payload = RoxAppointmentBookingHelper::payload($fieldData, self::PAYMENT_COLUMNS);

        foreach (['selected_payment_record_status' => 'status', 'selected_payment_record_method' => 'payment_method'] as $utilityKey => $column) {
            $value = RoxAppointmentBookingHelper::utility($utilities, $utilityKey);

            if ($value) {
                $payload[$column] = $value;
            }
        }

        if (empty($payload['payment_time'])) {
            $payload['payment_time'] = current_time('mysql');
        }

        $payment = PaymentModel::create($payload);

        if (!$payment || !$payment->getID()) {
            return RoxAppointmentBookingHelper::error(__('Failed to create the payment', 'bit-integrations-pro'));
        }

        return RoxAppointmentBookingHelper::success(__('Payment created successfully', 'bit-integrations-pro'), RoxAppointmentBookingHelper::attributes($payment));
    }

    public static function updatePaymentStatus($response, $fieldData, $integrationDetails = null)
    {
        if (!RoxAppointmentBookingHelper::isPluginActive() || !class_exists(PaymentModel::class)) {
            return RoxAppointmentBookingHelper::inactive();
        }

        list($fieldData, $resolveError) = RoxAppointmentBookingHelper::resolveIds($fieldData);

        if ($resolveError) {
            return $resolveError;
        }

        $missing = RoxAppointmentBookingHelper::missingRequired($fieldData, [['payment_id', 'find_by_payment_transaction_id']]);

        if ($missing) {
            return RoxAppointmentBookingHelper::requiredError($missing);
        }

        $status = RoxAppointmentBookingHelper::config($integrationDetails, 'selectedPaymentStatus');

        if (empty($status)) {
            return RoxAppointmentBookingHelper::error(__('Payment status is required', 'bit-integrations-pro'));
        }

        $paymentId = (int) $fieldData['payment_id'];
        $payment = PaymentModel::find($paymentId);

        if (!$payment) {
            return RoxAppointmentBookingHelper::error(__('Payment not found', 'bit-integrations-pro'));
        }

        $previousStatus = $payment->status;

        if (!$payment->update(['status' => $status])) {
            return RoxAppointmentBookingHelper::error(__('Failed to update the payment status', 'bit-integrations-pro'));
        }

        if ($previousStatus !== $status && class_exists(PaymentStatusSyncService::class)) {
            PaymentStatusSyncService::notifyStatusChange(
                (int) $payment->customer_id,
                (int) $payment->order_id,
                $status,
                [
                    'amount'         => $payment->amount,
                    'transaction_id' => $payment->transaction_id,
                    'payment_method' => $payment->payment_method,
                ]
            );
        }

        return RoxAppointmentBookingHelper::success(__('Payment status updated successfully', 'bit-integrations-pro'), ['id' => $paymentId, 'status' => $status]);
    }

    public static function createNotification($response, $fieldData, $utilities = null)
    {
        if (!RoxAppointmentBookingHelper::isPluginActive() || !class_exists(NotificationService::class)) {
            return RoxAppointmentBookingHelper::inactive();
        }

        list($fieldData, $resolveError) = RoxAppointmentBookingHelper::resolveIds($fieldData);

        if ($resolveError) {
            return $resolveError;
        }

        $missing = RoxAppointmentBookingHelper::missingRequired($fieldData, ['title']);

        if ($missing) {
            return RoxAppointmentBookingHelper::requiredError($missing);
        }

        $payload = RoxAppointmentBookingHelper::payload($fieldData, self::NOTIFICATION_COLUMNS);

        $type = RoxAppointmentBookingHelper::utility($utilities, 'selected_notification_type');

        if ($type) {
            $payload['type'] = $type;
        }

        try {
            $notification = NotificationService::create($payload);
        } catch (Throwable $e) {
            return RoxAppointmentBookingHelper::error($e->getMessage());
        }

        if (!$notification) {
            return RoxAppointmentBookingHelper::error(__('Failed to create the notification', 'bit-integrations-pro'));
        }

        return RoxAppointmentBookingHelper::success(__('Notification created successfully', 'bit-integrations-pro'), RoxAppointmentBookingHelper::attributes($notification));
    }

    private static function applyCatalogSelects($payload, $integrationDetails, array $map)
    {
        foreach ($map as $confKey => $column) {
            $value = RoxAppointmentBookingHelper::config($integrationDetails, $confKey);

            if (!empty($value)) {
                $payload[$column] = (int) $value;
            }
        }

        return $payload;
    }

    private static function appointmentReferences()
    {
        return [
            'customer_id' => [CustomerModel::class, __('Customer', 'bit-integrations-pro')],
            'service_id'  => [ServiceModel::class, __('Service', 'bit-integrations-pro')],
            'agent_id'    => [AgentModel::class, __('Agent', 'bit-integrations-pro')],
            'category_id' => [CategoryModel::class, __('Category', 'bit-integrations-pro')],
        ];
    }

    private static function missingReference($data, array $references)
    {
        foreach ($references as $idField => $reference) {
            list($modelClass, $label) = $reference;

            if (empty($data[$idField]) || $modelClass::find((int) $data[$idField])) {
                continue;
            }

            // translators: %s is the record type, e.g. Customer.
            return RoxAppointmentBookingHelper::error(\sprintf(__('%s not found', 'bit-integrations-pro'), $label));
        }

        return null;
    }

    private static function withFullName(array $payload)
    {
        $payload['full_name'] = trim(($payload['first_name'] ?? '') . ' ' . ($payload['last_name'] ?? ''));

        return $payload;
    }

    private static function deleteRecord($fieldData, $idField, $modelClass, $label, $alternates = [])
    {
        if (!RoxAppointmentBookingHelper::isPluginActive() || !class_exists($modelClass)) {
            return RoxAppointmentBookingHelper::inactive();
        }

        list($fieldData, $resolveError) = RoxAppointmentBookingHelper::resolveIds($fieldData);

        if ($resolveError) {
            return $resolveError;
        }

        $missing = RoxAppointmentBookingHelper::missingRequired($fieldData, [array_merge([$idField], $alternates)]);

        if ($missing) {
            return RoxAppointmentBookingHelper::requiredError($missing);
        }

        $id = (int) $fieldData[$idField];
        $record = $modelClass::find($id);

        if (!$record) {
            // translators: %s is the record type, e.g. Customer.
            return RoxAppointmentBookingHelper::error(\sprintf(__('%s not found', 'bit-integrations-pro'), $label));
        }

        if (!$record->delete()) {
            // translators: %s is the record type, e.g. Customer.
            return RoxAppointmentBookingHelper::error(\sprintf(__('Failed to delete the %s', 'bit-integrations-pro'), $label));
        }

        // translators: %s is the record type, e.g. Customer.
        return RoxAppointmentBookingHelper::success(\sprintf(__('%s deleted successfully', 'bit-integrations-pro'), $label), ['id' => $id, 'deleted' => true]);
    }
}
