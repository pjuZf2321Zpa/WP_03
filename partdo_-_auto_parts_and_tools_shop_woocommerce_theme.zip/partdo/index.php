<?php
/**
 * index.php
 * @package WordPress
 * @subpackage Partdo
 * @since Partdo 1.0
 * 
 */
 ?>

<?php get_header(); ?>
 
<?php if ( ! function_exists( 'elementor_theme_do_location' ) || ! elementor_theme_do_location( 'archive' ) ) { ?>

	<div class="klb-blog container page-container">
	
			<?php if( get_theme_mod( 'partdo_blog_layout' ) == 'left-sidebar') { ?>
				<div class="row content-wrapper sidebar-left">
					<div id="sidebar" class="col col-12 col-lg-3 sidebar-column blog-sidebar sticky">
						<?php if ( is_active_sidebar( 'blog-sidebar' ) ) { ?>
							<?php dynamic_sidebar( 'blog-sidebar' ); ?>
						<?php } ?>
					</div>
					<div class="col col-12 col-md-9 col-lg-9 primary-column">
						<div class="blog-posts">
							<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
	
								<?php  get_template_part( 'post-format/content', get_post_format() ); ?>
	
							<?php endwhile; ?>
						
								<?php get_template_part( 'post-format/pagination' ); ?>
								
							<?php else : ?>
	
								<h2><?php esc_html_e('No Posts Found', 'partdo') ?></h2>
	
							<?php endif; ?>
						</div>
					</div>
				</div>
			<?php } elseif( get_theme_mod( 'partdo_blog_layout' ) == 'full-width') { ?>
				<div class="row content-wrapper">
					<div class="col col-12 col-lg-10 offset-lg-1 primary-column">
						<div class="blog-posts">
							<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
	
								<?php  get_template_part( 'post-format/content', get_post_format() ); ?>
	
							<?php endwhile; ?>
						
								<?php get_template_part( 'post-format/pagination' ); ?>
								
							<?php else : ?>
	
								<h2><?php esc_html_e('No Posts Found', 'partdo') ?></h2>
	
							<?php endif; ?>
						</div>
					</div>
				</div>
			<?php } elseif( get_theme_mod( 'partdo_blog_layout' ) == 'grid') { ?>
					<div class="row content-wrapper sidebar-right">
						<div class="col col-12 col-lg-9 primary-column">
							<div class="klbth-module klbth-module-grid grid-<?php echo esc_attr( get_theme_mod( 'partdo_blog_grid_layout_column' ) ); ?>">
								<div class="blog-posts">
									<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
	
										<?php  get_template_part( 'post-format/content', get_post_format() ); ?>
	
									<?php endwhile; ?>
								
										<?php get_template_part( 'post-format/pagination' ); ?>
										
									<?php else : ?>
	
										<h2><?php esc_html_e('No Posts Found', 'partdo') ?></h2>
	
									<?php endif; ?>
								</div>
							</div>
						</div>
						<div id="sidebar" class="col col-12 col-lg-3 sidebar-column blog-sidebar sticky">
							<?php if ( is_active_sidebar( 'blog-sidebar' ) ) { ?>
								<?php dynamic_sidebar( 'blog-sidebar' ); ?>
							<?php } ?>
						</div>
					</div>
				<?php } else { ?>
				<?php if ( is_active_sidebar( 'blog-sidebar' ) ) { ?>
					<div class="row content-wrapper sidebar-right">
						<div class="col col-12 col-lg-9 primary-column">
							<div class="blog-posts">
								<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
	
									<?php  get_template_part( 'post-format/content', get_post_format() ); ?>
	
								<?php endwhile; ?>
							
									<?php get_template_part( 'post-format/pagination' ); ?>
									
								<?php else : ?>
	
									<h2><?php esc_html_e('No Posts Found', 'partdo') ?></h2>
	
								<?php endif; ?>
							</div>
						</div>
						<div id="sidebar" class="col col-12 col-lg-3 sidebar-column blog-sidebar sticky">
							<?php if ( is_active_sidebar( 'blog-sidebar' ) ) { ?>
								<?php dynamic_sidebar( 'blog-sidebar' ); ?>
							<?php } ?>
						</div>
					</div>
				<?php } else { ?>
					<div class="row content-wrapper">
						<div class="col col-12 col-lg-10 offset-lg-1 primary-column">
							<div class="blog-posts">
								<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
	
									<?php  get_template_part( 'post-format/content', get_post_format() ); ?>
	
								<?php endwhile; ?>
							
									<?php get_template_part( 'post-format/pagination' ); ?>
									
								<?php else : ?>
	
									<h2><?php esc_html_e('No Posts Found', 'partdo') ?></h2>
	
								<?php endif; ?>
							</div>
						</div>
					</div>
				<?php } ?>
			<?php } ?>
			
	</div>
<?php } ?>
<?php get_footer(); ?>          



