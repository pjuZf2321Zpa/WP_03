<?php

namespace NinjaTablesPro\App\Http\Controllers;

use NinjaTables\Framework\Request\Request;
use NinjaTablesPro\app\Traits\CustomFilter;

class CustomFilterController extends Controller
{
    use CustomFilter;

    /**
     * Defense in depth: the route policy is the primary gate, but this
     * controller reads and writes post meta for any table_id, so it re-checks
     * the capability itself and never relies on routing alone.
     */
    private function verifyPermission()
    {
        if (!current_user_can(ninja_table_admin_role())) {
            wp_send_json_error(array(
                'message' => __('Sorry, you are not allowed to do this.', 'ninja-tables-pro')
            ), 403);
        }
    }

    public function index(Request $request)
    {
        $this->verifyPermission();

        $tableId          = intval($request->get('table_id'));
        $table_filters    = $this->getCustomFilters($tableId, array());
        $formattedFilters = array();

        foreach ($table_filters as $key => $table_filter) {
            $table_filter['name'] = $key;
            $formattedFilters[]   = $table_filter;
        }

        $filterStyling = get_post_meta($tableId, '_ninja_custom_filter_styling', true);

        if (!$filterStyling) {
            $filterStyling = array();
        }

        $defaultStyling = array(
            'filter_display_type' => 'inline',
            'filter_columns'      => 'columns_2',
            'filter_column_label' => 'new_line',
            'progressive'         => 'no'
        );

        $filterStyling = wp_parse_args($filterStyling, $defaultStyling);

        wp_send_json_success(array(
            'table_filters'  => $formattedFilters,
            'filter_styling' => $filterStyling
        ));
    }

    public function store(Request $request)
    {
        $this->verifyPermission();

        $tableId = intval($request->get('table_id'));
        $filters = wp_unslash($this->sanitizeCustomFilterData($request->get('ninja_filters', [])));
        $this->updateFilters($tableId, $filters);

        if ($request->has('filter_styling')) {
            $filterAppearance = wp_unslash(ninja_tables_sanitize_array($request->get('filter_styling')));
            update_post_meta($tableId, '_ninja_custom_filter_styling', $filterAppearance);
        }

        if ($request->has('table_buttons')) {
            $tableButtons = wp_unslash(ninja_tables_sanitize_array($request->get('table_buttons')));
            update_post_meta($tableId, '_ninja_custom_table_buttons', $tableButtons);
        }

        wp_send_json_success(array(
            'message' => __('Filters successfully updated', 'ninja-tables-pro')
        ));
    }

    private function sanitizeCustomFilterData($array)
    {
        foreach ($array as $key => $value) {
            if (is_array($value)) {
                $array[$key] = $this->sanitizeCustomFilterData($value);
            } else {
                $array[$key] = sanitize_text_field($value);
            }
        }

        return $array;
    }
}
