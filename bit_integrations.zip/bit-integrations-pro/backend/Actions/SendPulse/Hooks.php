<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Actions\SendPulse\SendPulseHelperPro;
use BitApps\IntegrationsPro\Config;
use BitApps\IntegrationsPro\Core\Util\Hooks;

// Deprecated since v2.7.8 - use bit_integrations_sendPulse_* hooks instead
if (bit_integrations_version_below('2.7.8')) {
    Hooks::add('btcbi_sendPulse_refresh_fields', [SendPulseHelperPro::class, 'refreshFields'], 10, 3);
}

// New hooks since v2.7.8
Hooks::add(Config::withFreePrefix('sendPulse_refresh_fields'), [SendPulseHelperPro::class, 'refreshFields'], 10, 3);
