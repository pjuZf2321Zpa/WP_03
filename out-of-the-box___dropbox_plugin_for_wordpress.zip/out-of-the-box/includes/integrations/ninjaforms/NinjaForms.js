(function ($) {
    var unsubscribeBridge = null;

    /* Module Configurator Popup */
    $('#nf-builder').on('click', '.outofthebox.open-shortcode-builder', function () {
        var input_field = $('#wpcp_outofthebox_shortcode');
        var shortcode = input_field.val();

        openShortcodeBuilder(shortcode);

        $('.wpcp_data_input').removeClass('wpcp_data_input');
        input_field.addClass('wpcp_data_input');
    });

    function callback_handler(data) {
        if (!data || typeof data.shortcode !== 'string') {
            return;
        }

        // 3. Additional validation on the shortcode content (e.g., length, format)
        var shortcode_value = data.shortcode;
        if (shortcode_value.length > 3000 || !/^\[outofthebox(\s[^\]]*)?\]$/.test(shortcode_value)) {
            return;
        }

        // 4. If all checks pass, process the shortcode
        $('.wpcp_data_input').val(shortcode_value);

        // 5. Clean up the modal and event listener
        window.modal_action.close();
        $('#wpcp-modal-action.OutoftheBox').remove();

        $('.wpcp_data_input').trigger('change');
        unsubscribeBridge();
        unsubscribeBridge = null;
    }

    function openShortcodeBuilder(shortcode) {
        if ($('#wpcp-modal-action.OutoftheBox').length > 0) {
            window.modal_action.close();
            $('#wpcp-modal-action.OutoftheBox').remove();
        }

        /* Build the  Dialog */
        let modalbuttons = '';
        let modalheader = $(
            `<div class="wpcp-modal-header" tabindex="0">                          
                    <a tabindex="0" class="close-button"  onclick="window.modal_action.close();"><i class="eva eva-close eva-lg" aria-hidden="true"></i></a>
                </div>`
        );
        let modalbody = $('<div class="wpcp-modal-body" tabindex="0" style="display:none;padding:0!important;"></div>');
        let modaldialog = $(
            '<div id="wpcp-modal-action" class="OutoftheBox wpcp wpcp-modal wpcp-modal80 wpcp-modal-minimal light"><div class="modal-dialog"><div class="modal-content"><div class="loading"><div class="loader-beat"></div></div></div></div></div>'
        );

        $('body').append(modaldialog);

        var query = 'shortcode=' + WPCP_shortcodeEncode(shortcode);
        var instanceId = window.WPCP_Bridge.createInstanceId();
        unsubscribeBridge = window.WPCP_Bridge.subscribe('out-of-the-box', 'wpcp-shortcode', instanceId, callback_handler);

        var $iframe_template = $(
            "<iframe src='" +
                window.ajaxurl +
                '?action=outofthebox-getpopup&type=modules&foruploadfield=1&callback=uses_listener&' +
                    query +
                    '&wpcp_instance_id=' + encodeURIComponent(instanceId) +
                    
                    "' width='100%' height='600' tabindex='-1' style='border:none' title=''></iframe>"
        );
        var $iframe = $iframe_template.appendTo(modalbody);

        $('#wpcp-modal-action.OutoftheBox .modal-content').append(modalheader, modalbody);

        $iframe.on('load', function () {
            $('.wpcp-modal-body').fadeIn();
            $('.wpcp-modal-footer').fadeIn();
            $('.modal-content .loading:first').fadeOut();
        });

        /* Open the Dialog */
        let modal_action = new RModal(document.getElementById('wpcp-modal-action'), {
            bodyClass: 'rmodal-open',
            dialogOpenClass: 'animated slideInDown',
            dialogCloseClass: 'animated slideOutUp',
            escapeClose: true,
            afterClose() {
                if (unsubscribeBridge) {
                    unsubscribeBridge();
                    unsubscribeBridge = null;
                }
            },
        });
        document.addEventListener(
            'keydown',
            function (ev) {
                modal_action.keydown(ev);
            },
            false
        );
        modal_action.open();
        window.modal_action = modal_action;
    }
})(jQuery);
