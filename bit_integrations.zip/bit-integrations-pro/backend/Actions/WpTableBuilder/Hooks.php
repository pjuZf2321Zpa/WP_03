<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Actions\WpTableBuilder\WpTableBuilderProHelper;
use BitApps\IntegrationsPro\Config;
use BitApps\IntegrationsPro\Core\Util\Hooks;

Hooks::filter(Config::withFreePrefix('wptablebuilder_create_table'), [WpTableBuilderProHelper::class, 'createTable'], 10, 2);
Hooks::filter(Config::withFreePrefix('wptablebuilder_update_table'), [WpTableBuilderProHelper::class, 'updateTable'], 10, 2);
Hooks::filter(Config::withFreePrefix('wptablebuilder_delete_table'), [WpTableBuilderProHelper::class, 'deleteTable'], 10, 3);
Hooks::filter(Config::withFreePrefix('wptablebuilder_add_row'), [WpTableBuilderProHelper::class, 'addRow'], 10, 3);
