<?php

namespace MasterStudy\Lms\Pro\addons\assignments\Routing\Swagger;

use MasterStudy\Lms\Routing\Swagger\RequestInterface;
use MasterStudy\Lms\Routing\Swagger\ResponseInterface;
use MasterStudy\Lms\Routing\Swagger\Route;

class BulkUpdateAdminAssignments extends Route implements RequestInterface, ResponseInterface {
	public function request(): array {
		return array(
			'action'      => array(
				'type'        => 'string',
				'description' => 'Status action to apply.',
				'required'    => true,
				'enum'        => array( 'publish', 'draft' ),
			),
			'assignments' => array(
				'type'        => 'array',
				'description' => 'Assignment items selected for bulk status update.',
				'required'    => true,
				'items'       => array(
					'type'       => 'object',
					'properties' => array(
						'id' => array(
							'type' => 'integer',
						),
					),
				),
			),
		);
	}

	public function response(): array {
		return array(
			'success' => array(
				'type' => 'boolean',
			),
		);
	}

	public function get_summary(): string {
		return 'Bulk Update Assignments';
	}

	public function get_description(): string {
		return 'Updates assignment statuses to published or draft.';
	}
}
