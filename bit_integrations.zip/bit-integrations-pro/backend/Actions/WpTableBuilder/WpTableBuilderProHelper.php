<?php

namespace BitApps\IntegrationsPro\Actions\WpTableBuilder;

/**
 * WP Table Builder table write actions.
 *
 * Ported from bit-pi's WpTableBuilderService. Tables are a custom post type, so the
 * writes go through the WordPress post API rather than any plugin API.
 */
class WpTableBuilderProHelper
{
    /**
     * Append a row to an existing table.
     *
     * The target table comes from the integration config rather than the field map:
     * its column list has to be known while the flow is being built, which only a fixed
     * table can supply.
     *
     * @param array       $defaultResponse
     * @param array       $fieldData
     * @param null|object $integrationDetails
     *
     * @return array
     */
    public static function addRow($defaultResponse, $fieldData, $integrationDetails = null)
    {
        if (!WpTableBuilderHelper::isPluginActive()) {
            return WpTableBuilderHelper::errorResponse(__('WP Table Builder is not installed or activated', 'bit-integrations-pro'));
        }

        $tableId = isset($integrationDetails->selectedTable) ? (int) $integrationDetails->selectedTable : 0;

        if (!$tableId) {
            return WpTableBuilderHelper::errorResponse(__('No table selected for this action.', 'bit-integrations-pro'));
        }

        if (!WpTableBuilderHelper::findTable($tableId)) {
            return WpTableBuilderHelper::errorResponse(__('Table not found.', 'bit-integrations-pro'));
        }

        $content = get_post_meta($tableId, WpTableBuilderHelper::CONTENT_META_KEY, true);
        $columnCount = WpTableBuilderRowHelper::columnCount($content);

        if (!$columnCount) {
            return WpTableBuilderHelper::errorResponse(__('The selected table has no rows to copy the layout from.', 'bit-integrations-pro'));
        }

        // Field-map order is not guaranteed, so cells are placed by their column index.
        $values = [];

        for ($index = 0; $index < $columnCount; $index++) {
            $key = 'cell_' . $index;
            $values[$index] = isset($fieldData[$key]) ? $fieldData[$key] : '';
        }

        $updated = WpTableBuilderRowHelper::appendRow($content, $values);

        if ($updated === null) {
            return WpTableBuilderHelper::errorResponse(__('Failed to build the new row from the table layout.', 'bit-integrations-pro'));
        }

        // Values are inserted as text nodes, so the row itself cannot carry markup; the
        // sanitizer still runs because the surrounding table is being rewritten.
        update_post_meta($tableId, WpTableBuilderHelper::CONTENT_META_KEY, WpTableBuilderHelper::sanitizeTableContent($updated));

        return WpTableBuilderHelper::successResponse(
            __('Row added successfully', 'bit-integrations-pro'),
            ['table_id' => $tableId, 'columns' => $columnCount, 'values' => $values]
        );
    }

    public static function createTable($defaultResponse, $fieldData)
    {
        if (!WpTableBuilderHelper::isPluginActive()) {
            return WpTableBuilderHelper::errorResponse(__('WP Table Builder is not installed or activated', 'bit-integrations-pro'));
        }

        if ($invalid = WpTableBuilderHelper::requireFields($fieldData, ['title', 'content'])) {
            return $invalid;
        }

        $tableId = WpTableBuilderHelper::guardedWrite(
            function () use ($fieldData) {
                return wp_insert_post(
                    [
                        'post_title'  => sanitize_text_field($fieldData['title']),
                        'post_type'   => WpTableBuilderHelper::POST_TYPE,
                        'post_status' => 'draft',
                    ]
                );
            }
        );

        if (is_wp_error($tableId)) {
            return WpTableBuilderHelper::errorResponse($tableId->get_error_message());
        }

        if (empty($tableId)) {
            return WpTableBuilderHelper::errorResponse(__('Failed to create table.', 'bit-integrations-pro'));
        }

        update_post_meta($tableId, WpTableBuilderHelper::CONTENT_META_KEY, WpTableBuilderHelper::sanitizeTableContent($fieldData['content']));

        return WpTableBuilderHelper::successResponse(
            __('Table created successfully', 'bit-integrations-pro'),
            WpTableBuilderHelper::summariseTable(get_post($tableId))
        );
    }

    public static function updateTable($defaultResponse, $fieldData)
    {
        if (!WpTableBuilderHelper::isPluginActive()) {
            return WpTableBuilderHelper::errorResponse(__('WP Table Builder is not installed or activated', 'bit-integrations-pro'));
        }

        if ($invalid = WpTableBuilderHelper::requireFields($fieldData, ['table_id'])) {
            return $invalid;
        }

        $hasTitle = isset($fieldData['title']) && $fieldData['title'] !== '';
        $hasContent = isset($fieldData['content']) && $fieldData['content'] !== '';

        if (!$hasTitle && !$hasContent) {
            return WpTableBuilderHelper::errorResponse(
                __('Nothing to update — map at least Title or Content.', 'bit-integrations-pro')
            );
        }

        $tableId = (int) $fieldData['table_id'];

        if (!WpTableBuilderHelper::findTable($tableId)) {
            return WpTableBuilderHelper::errorResponse(__('Table not found.', 'bit-integrations-pro'));
        }

        if ($hasTitle) {
            $result = WpTableBuilderHelper::guardedWrite(
                function () use ($tableId, $fieldData) {
                    return wp_update_post(
                        [
                            'ID'         => $tableId,
                            'post_title' => sanitize_text_field($fieldData['title']),
                        ]
                    );
                }
            );

            if (is_wp_error($result)) {
                return WpTableBuilderHelper::errorResponse($result->get_error_message());
            }
        }

        if ($hasContent) {
            update_post_meta($tableId, WpTableBuilderHelper::CONTENT_META_KEY, WpTableBuilderHelper::sanitizeTableContent($fieldData['content']));
        }

        return WpTableBuilderHelper::successResponse(
            __('Table updated successfully', 'bit-integrations-pro'),
            WpTableBuilderHelper::summariseTable(get_post($tableId))
        );
    }

    public static function deleteTable($defaultResponse, $fieldData, $utilities = null)
    {
        if (!WpTableBuilderHelper::isPluginActive()) {
            return WpTableBuilderHelper::errorResponse(__('WP Table Builder is not installed or activated', 'bit-integrations-pro'));
        }

        if ($invalid = WpTableBuilderHelper::requireFields($fieldData, ['table_id'])) {
            return $invalid;
        }

        $tableId = (int) $fieldData['table_id'];

        if (!WpTableBuilderHelper::findTable($tableId)) {
            return WpTableBuilderHelper::errorResponse(__('Table not found.', 'bit-integrations-pro'));
        }

        // Trash by default so a mis-mapped table id is recoverable; permanent deletion
        // is opt-in through Utilities.
        $forceDelete = !empty($utilities->forceDelete);

        $deleted = WpTableBuilderHelper::guardedWrite(
            function () use ($tableId, $forceDelete) {
                return $forceDelete ? wp_delete_post($tableId, true) : wp_trash_post($tableId);
            }
        );

        if (empty($deleted)) {
            return WpTableBuilderHelper::errorResponse(__('Failed to delete table.', 'bit-integrations-pro'));
        }

        return WpTableBuilderHelper::successResponse(
            $forceDelete
                ? __('Table permanently deleted', 'bit-integrations-pro')
                : __('Table moved to trash', 'bit-integrations-pro'),
            ['table_id' => $tableId, 'permanently_deleted' => $forceDelete]
        );
    }
}
