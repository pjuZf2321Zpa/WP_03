<?php
/**
 * The Event Tickets Plus ORM/Repository decorator for RSVP tickets.
 *
 * @since 6.11.0
 */

namespace Tribe\Tickets\Plus\Repositories\Ticket;

use Tribe__Repository__Decorator;

/**
 * The Event Tickets Plus ORM/Repository decorator for RSVP tickets.
 *
 * @since 6.11.0
 *
 * @property \Tribe__Tickets__Repositories__Ticket__RSVP $decorated
 */
class RSVP extends Tribe__Repository__Decorator {

	/**
	 * RSVP constructor.
	 *
	 * Gets the current ET RSVP ticket repository instance to extend.
	 *
	 * @since 6.11.0
	 */
	public function __construct() {
		$this->decorated = tribe( 'tickets.ticket-repository.rsvp' );

		// Set up the update field aliases for ET+-specific meta.
		$update_fields_aliases = $this->get_ticket_update_fields_aliases();

		foreach ( $update_fields_aliases as $alias => $field_name ) {
			$this->decorated->add_update_field_alias( $alias, $field_name );
		}
	}

	/**
	 * Get the list of Ticket-specific update fields aliases.
	 *
	 * @since 6.11.0
	 *
	 * @return array List of Ticket-specific update fields aliases.
	 */
	public function get_ticket_update_fields_aliases() {
		$update_fields_aliases = [];

		// Meta fields configuration.
		$update_fields_aliases['meta_fields_config'] = \Tribe__Tickets_Plus__Meta::META_KEY;

		// Meta enabled flag.
		$update_fields_aliases['meta_enabled'] = \Tribe__Tickets_Plus__Meta::ENABLE_META_KEY;

		return $update_fields_aliases;
	}
}
