<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Actions\FluentSupport\FluentSupportHelperPro;
use BitApps\IntegrationsPro\Config;
use BitApps\IntegrationsPro\Core\Util\Hooks;

// Deprecated since v2.7.8 - use bit_integrations_fluent_support_* hooks instead
if (bit_integrations_version_below('2.7.8')) {
    Hooks::add('btcbi_fluent_support_upload_ticket_attachments', [FluentSupportHelperPro::class, 'uploadTicketAttachments'], 10, 5);
}

// New hooks since v2.7.8
Hooks::add(Config::withFreePrefix('fluent_support_upload_ticket_attachments'), [FluentSupportHelperPro::class, 'uploadTicketAttachments'], 10, 5);
