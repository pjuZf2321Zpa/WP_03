<?php

namespace FluentCartPro\App\Modules\InlineCheckout\Checkout;

use FluentCart\App\Models\Cart;
use FluentCart\App\Services\Renderer\CheckoutRenderer;
use FluentCart\Framework\Support\Arr;
use FluentCartPro\App\Modules\InlineCheckout\Cart\InlineCartService;
use FluentCartPro\App\Modules\InlineCheckout\Config\InlineCheckoutConfig;

/**
 * Turns a checkout into a product selector when its author configured one.
 *
 * Both surfaces — the `fluent-cart/checkout` block and the
 * `[fluent_cart_checkout]` shortcode — arrive through the same core action, so
 * there is one implementation rather than one per surface. Core fires it only
 * for a checkout whose attributes name variations; every other checkout keeps
 * rendering the shopper's own cart.
 */
class CheckoutSurface
{
    /**
     * Unavailable-offer renders this module answered, keyed by renderKey(), with their text.
     *
     * @var array<string,string>
     */
    private $unavailableRenders = [];

    /**
     * @return void
     */
    public function register(): void
    {
        add_action('fluent_cart/checkout/render_custom_product_checkout', [$this, 'render'], 10, 1);
        add_filter('fluent_cart/checkout/empty_message', [$this, 'emptyMessage'], 10, 2);
        add_filter('fluent_cart/checkout/localize_data', [InlineCheckoutAssets::class, 'localize'], 10, 2);
    }

    /**
     * Render a checkout configured with its own products. Core hands these
     * checkouts only to this action, so without Pro they render nothing.
     *
     * @param array $context ['surface' => string, 'attributes' => array, 'block' => \WP_Block|null]
     * @return void
     */
    public function render($context): void
    {
        $cart = $this->resolveCart(null, $context);

        if (!$cart) {
            return;
        }

        CheckoutRenderer::renderCustomProductCart($cart, $context);
    }

    /**
     * @param \FluentCart\App\Models\Cart|null $cart
     * @param array $context ['surface' => string, 'attributes' => array, 'block' => \WP_Block|null]
     * @return \FluentCart\App\Models\Cart|null
     */
    public function resolveCart($cart, $context)
    {
        // Someone else already answered. Two add-ons both claiming the checkout
        // cart is their conflict to resolve, not ours to win by running later.
        if ($cart) {
            return $cart;
        }

        $config = InlineCheckoutConfig::normalize(
            (array)Arr::get($context, 'attributes', []),
            Arr::get($context, 'surface', 'checkout-block')
        );

        // The feature is inert without variations. This is the branch every
        // ordinary checkout in every store takes.
        if (empty($config['variant_ids'])) {
            return null;
        }

        $variations = InlineCheckoutConfig::resolveVariations($config);

        // Every offered option is unpurchasable (unpublished, out of stock,
        // gated away). An empty, unsaved cart makes core show the empty state,
        // worded by emptyMessage(), instead of billing the shopper's shop basket.
        if (!$variations) {
            $unavailable = new Cart();
            $unavailable->cart_data = [];

            $this->unavailableRenders[$this->renderKey($context)] = $config['empty_text'];

            return $unavailable;
        }

        $selectorCart = InlineCartService::resolveForCheckout($variations, $config);

        // Enqueued from inside the filter on purpose: core calls its own asset
        // loader immediately after this returns, and that is what fires the
        // localize filter our vars ride on. Anything later has missed it —
        // localizeCheckoutData() runs once per request.
        InlineCheckoutAssets::load($selectorCart, $config);

        return $selectorCart;
    }

    /**
     * Word the empty checkout when this selector's products are all unavailable.
     *
     * @param string|null $message
     * @param array $context ['surface' => string, 'attributes' => array]
     * @return string|null
     */
    public function emptyMessage($message, $context)
    {
        $key = $this->renderKey($context);

        // Only word an empty checkout this module supplied; another provider's
        // empty cart keeps its own message.
        if ($message !== null || !isset($this->unavailableRenders[$key])) {
            return $message;
        }

        $text = $this->unavailableRenders[$key];
        unset($this->unavailableRenders[$key]);

        return $text;
    }

    /**
     * Identifies one checkout render; core passes the same context to both filters.
     *
     * @param array $context
     * @return string
     */
    private function renderKey($context): string
    {
        return md5((string)wp_json_encode([
            Arr::get($context, 'surface', ''),
            (array)Arr::get($context, 'attributes', []),
        ]));
    }
}
