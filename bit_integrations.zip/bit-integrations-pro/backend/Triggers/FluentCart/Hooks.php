<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Core\Util\Hooks;
use BitApps\IntegrationsPro\Triggers\FluentCart\FluentCartController;

Hooks::add('fluent_cart/checkout/prepare_other_data', [FluentCartController::class, 'productPurchased']);
Hooks::add('fluent_cart/product_updated', [FluentCartController::class, 'productUpdated']);
Hooks::add('fluent_cart/product_stock_changed', [FluentCartController::class, 'productStockUpdated']);
Hooks::add('fluent_cart/coupon_created', [FluentCartController::class, 'couponCreated']);
Hooks::add('fluent_cart/coupon_updated', [FluentCartController::class, 'couponUpdated']);
Hooks::add('fluent_cart/cart/item_added', [FluentCartController::class, 'cartItemAdded']);
Hooks::add('fluent_cart/cart/item_removed', [FluentCartController::class, 'cartItemRemoved']);
Hooks::add('fluent_cart/cart/cart_data_items_updated', [FluentCartController::class, 'cartItemsUpdated']);
Hooks::add('fluent_cart/checkout/cart_amount_updated', [FluentCartController::class, 'cartUpdated']);
Hooks::add('fluent_cart/cart_completed', [FluentCartController::class, 'cartCompleted']);
Hooks::add('fluent_cart/after_receipt', [FluentCartController::class, 'orderReceiptRendered']);
Hooks::add('fluent_cart/order_created', [FluentCartController::class, 'orderCreated']);
Hooks::add('fluent_cart/order_updated', [FluentCartController::class, 'orderUpdated']);
Hooks::add('fluent_cart/order_deleted', [FluentCartController::class, 'orderDeleted']);
Hooks::add('fluent_cart/order_refunded', [FluentCartController::class, 'orderRefunded']);
Hooks::add('fluent_cart/order_partially_refunded', [FluentCartController::class, 'orderPartiallyRefunded']);
Hooks::add('fluent_cart/order_fully_refunded', [FluentCartController::class, 'orderFullyRefunded']);
Hooks::add('fluent_cart/order_status_changed', [FluentCartController::class, 'orderStatusChanged']);
Hooks::add('fluent_cart/order_status_changed_to_canceled', [FluentCartController::class, 'orderCancelled']);
Hooks::add('fluent_cart/order_status_changed_to_processing', [FluentCartController::class, 'orderStatusUpdatedToProcessing']);
Hooks::add('fluent_cart/order_status_changed_to_completed', [FluentCartController::class, 'orderStatusUpdatedToCompleted']);
Hooks::add('fluent_cart/order_status_changed_to_on-hold', [FluentCartController::class, 'orderStatusUpdatedToOnHold']);
Hooks::add('fluent_cart/shipping_status_changed', [FluentCartController::class, 'orderShippingStatusChanged']);
Hooks::add('fluent_cart/shipping_status_changed_to_shipped', [FluentCartController::class, 'orderShipped']);
Hooks::add('fluent_cart/shipping_status_changed_to_unshipped', [FluentCartController::class, 'orderUnshipped']);
Hooks::add('fluent_cart/shipping_status_changed_to_unshippable', [FluentCartController::class, 'orderUnshippable']);
Hooks::add('fluent_cart/shipping_status_changed_to_delivered', [FluentCartController::class, 'orderDelivered']);
Hooks::add('fluent_cart/order_paid_done', [FluentCartController::class, 'orderMarkedAsPaid']);
Hooks::add('fluent_cart/order_customer_changed', [FluentCartController::class, 'orderCustomerChanged']);
Hooks::add('fluent_cart/user/after_register', [FluentCartController::class, 'customerCreated']);
