<?php

namespace MasterStudy\Lms\Pro\addons\assignments\Repositories;

use MasterStudy\Lms\Plugin\PostType;
use MasterStudy\Lms\Repositories\CurriculumRepository;
use MasterStudy\Lms\Pro\addons\assignments\Repositories\AssignmentStudentRepository;

final class AssignmentTeacherRepository {

	public static function get_assignments( $params = array() ) {
		$page       = max( 1, intval( $params['page'] ?? 1 ) );
		$per_page   = max( 1, intval( $params['per_page'] ?? 10 ) );
		$sort_by    = self::sanitize_sort_by( $params['sortby'] ?? '' );
		$sort_order = self::sanitize_sort_order( $params['sort_order'] ?? '' );

		$assignments_args = array(
			'fields'         => 'ids',
			'post_type'      => PostType::ASSIGNMENT,
			'author'         => get_current_user_id(),
			'paged'          => $page,
			'posts_per_page' => $per_page,
		);

		if ( ! empty( $params['s'] ) ) {
			$assignments_args['s'] = sanitize_text_field( $params['s'] );
		}

		if ( ! empty( $params['status'] ) || ! empty( $params['course_id'] ) ) {
			$user_assignment_args = array(
				'post_type'      => PostType::USER_ASSIGNMENT,
				'fields'         => 'ids',
				'posts_per_page' => -1,
			);

			$meta_query = array( 'relation' => 'AND' );

			if ( ! empty( $params['course_id'] ) ) {
				$meta_query[] = array(
					'key'     => 'course_id',
					'value'   => (string) $params['course_id'],
					'compare' => '=',
				);
			}

			if ( ! empty( $params['status'] ) ) {
				$assignment_status = sanitize_text_field( $params['status'] );

				if ( 'pending' === $assignment_status ) {
					$user_assignment_args['post_status'] = array( 'pending' );
				} else {
					$meta_query[] = array(
						'key'     => 'status',
						'value'   => $assignment_status,
						'compare' => '=',
					);
				}
			} else {
				// When filtering only by course, include all visible user assignment post statuses.
				$user_assignment_args['post_status'] = array( 'pending', 'publish' );
			}

			if ( count( $meta_query ) > 1 ) {
				$user_assignment_args['meta_query'] = $meta_query;
			}

			$filtered_assignments = array( 0 );
			$user_assignment_ids  = get_posts( $user_assignment_args );

			if ( ! empty( $user_assignment_ids ) ) {
				foreach ( $user_assignment_ids as $user_assignment_id ) {
					$assignment_id = get_post_meta( $user_assignment_id, 'assignment_id', true );
					if ( $assignment_id > 0 ) {
						$filtered_assignments[] = intval( $assignment_id );
					}
				}
			}

			$assignments_args['post__in'] = array_unique( $filtered_assignments );
		}

		if ( 'title' === $sort_by && ! empty( $sort_order ) ) {
			$assignments_args['orderby'] = 'title';
			$assignments_args['order']   = $sort_order;
		}

		if ( in_array( $sort_by, array( 'total', 'passed', 'not_passed', 'pending' ), true ) && ! empty( $sort_order ) ) {
			$all_assignments_args                   = $assignments_args;
			$all_assignments_args['posts_per_page'] = -1;
			$all_assignments_args['paged']          = 1;
			$assignment_ids                         = get_posts( $all_assignments_args );
			$counts                                 = self::user_assignments_counts( $assignment_ids );
			$initial_order                          = array_flip( $assignment_ids );

			usort(
				$assignment_ids,
				function ( $first_id, $second_id ) use ( $counts, $initial_order, $sort_by, $sort_order ) {
					$first_value  = intval( $counts[ $first_id ][ $sort_by ] ?? 0 );
					$second_value = intval( $counts[ $second_id ][ $sort_by ] ?? 0 );

					if ( $first_value === $second_value ) {
						return ( $initial_order[ $first_id ] ?? 0 ) <=> ( $initial_order[ $second_id ] ?? 0 );
					}

					return 'DESC' === $sort_order ? $second_value <=> $first_value : $first_value <=> $second_value;
				}
			);

			$found_posts = count( $assignment_ids );
			$max_pages   = (int) ceil( $found_posts / $per_page );
			$page_ids    = array_slice( $assignment_ids, ( $page - 1 ) * $per_page, $per_page );

			return self::build_assignments_response( $page_ids, $page, $per_page, $found_posts, $max_pages, $counts );
		}

		$query = new \WP_Query( $assignments_args );

		return self::build_assignments_response( $query->posts, $page, $per_page, $query->found_posts, $query->max_num_pages );
	}

	private static function build_assignments_response( array $assignment_ids, int $page, int $per_page, int $found_posts, int $max_pages, array $counts = array() ): array {
		$counts      = ! empty( $counts ) ? $counts : self::user_assignments_counts( $assignment_ids );
		$assignments = array(
			'assignments' => array(),
			'page'        => $page,
			'found_posts' => $found_posts,
			'per_page'    => $per_page,
			'max_pages'   => $max_pages,
		);

		foreach ( $assignment_ids as $assignment_id ) {
			$assignment_id                = intval( $assignment_id );
			$assignment_counts            = $counts[ $assignment_id ] ?? self::empty_counts();
			$assignments['assignments'][] = array(
				'id'         => $assignment_id,
				'title'      => get_the_title( $assignment_id ),
				'courses'    => self::related_posts( $assignment_id ),
				'total'      => $assignment_counts['total'],
				'passed'     => $assignment_counts[ AssignmentStudentRepository::STATUS_PASSED ],
				'not_passed' => $assignment_counts[ AssignmentStudentRepository::STATUS_NOT_PASSED ],
				'pending'    => $assignment_counts[ AssignmentStudentRepository::STATUS_PENDING ],
				'more_link'  => ms_plugin_user_account_url( "assignments/{$assignment_id}" ),
			);
		}

		return $assignments;
	}

	private static function sanitize_sort_by( string $sort_by ): string {
		$sort_by = sanitize_key( $sort_by );

		return in_array( $sort_by, array( 'title', 'total', 'passed', 'not_passed', 'pending' ), true ) ? $sort_by : '';
	}

	private static function sanitize_sort_order( string $sort_order ): string {
		$sort_order = strtoupper( sanitize_key( $sort_order ) );

		return in_array( $sort_order, array( 'ASC', 'DESC' ), true ) ? $sort_order : '';
	}

	private static function empty_counts(): array {
		return array(
			'total'                                        => 0,
			AssignmentStudentRepository::STATUS_PASSED     => 0,
			AssignmentStudentRepository::STATUS_NOT_PASSED => 0,
			AssignmentStudentRepository::STATUS_PENDING    => 0,
		);
	}

	private static function user_assignments_counts( array $assignment_ids ): array {
		global $wpdb;

		$assignment_ids = array_values( array_filter( array_map( 'intval', $assignment_ids ) ) );

		if ( empty( $assignment_ids ) ) {
			return array();
		}

		$counts       = array_fill_keys( $assignment_ids, self::empty_counts() );
		$placeholders = implode( ',', array_fill( 0, count( $assignment_ids ), '%d' ) );
		$table_name   = stm_lms_user_assignments_name( $wpdb );
		$results      = $wpdb->get_results(
			$wpdb->prepare(
				// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				"SELECT assignment_id, status, COUNT(*) AS assignments_count FROM {$table_name} WHERE assignment_id IN ({$placeholders}) AND status != %s GROUP BY assignment_id, status",
				array_merge( $assignment_ids, array( 'trash' ) )
			),
			ARRAY_A
		);

		foreach ( $results as $result ) {
			$assignment_id = intval( $result['assignment_id'] ?? 0 );
			$status        = $result['status'] ?? '';
			$count         = intval( $result['assignments_count'] ?? 0 );

			if ( ! isset( $counts[ $assignment_id ] ) ) {
				continue;
			}

			$counts[ $assignment_id ]['total'] += $count;

			if ( isset( $counts[ $assignment_id ][ $status ] ) ) {
				$counts[ $assignment_id ][ $status ] = $count;
			}
		}

		return $counts;
	}

	public static function related_posts( $assignment_id ) {
		$course_ids = ( new CurriculumRepository() )->get_lesson_course_ids( $assignment_id );
		$courses    = array();

		if ( ! empty( $course_ids ) ) {
			foreach ( $course_ids as $course_id ) {
				$courses[] = array(
					'id'    => $course_id,
					'title' => get_the_title( $course_id ),
					'link'  => get_the_permalink( $course_id ),
				);
			}
		}

		return $courses;
	}

	public static function user_assignments_count( int $assignment_id, string $assigment_status = '' ): ?int {
		global $wpdb;

		$status_clause = ! empty( $assigment_status ) ? $wpdb->prepare( 'AND status = %s', $assigment_status ) : "AND status != 'trash'";

		return $wpdb->get_var(
			$wpdb->prepare(
				// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				"SELECT COUNT(*) FROM {$wpdb->prefix}stm_lms_user_assignments WHERE assignment_id = %d {$status_clause}",
				$assignment_id
			)
		);
	}

	public static function total_pending_assignments( int $user_id ): ?int {
		$assignment_ids = get_posts(
			array(
				'fields'         => 'ids',
				'author'         => $user_id,
				'post_type'      => PostType::ASSIGNMENT,
				'posts_per_page' => -1,
			)
		);

		if ( empty( $assignment_ids ) ) {
			return 0;
		}

		$args = array(
			'post_type'      => PostType::USER_ASSIGNMENT,
			'posts_per_page' => 1,
			'post_status'    => array( 'pending' ),
			'meta_query'     => array(
				array(
					'key'     => 'assignment_id',
					'value'   => $assignment_ids,
					'compare' => 'IN',
				),
			),
		);

		$user_assignments = new \WP_Query( $args );

		return $user_assignments->found_posts;
	}
}
