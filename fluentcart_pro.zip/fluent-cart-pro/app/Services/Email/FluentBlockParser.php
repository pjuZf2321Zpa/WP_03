<?php

namespace FluentCartPro\App\Services\Email;

use FluentCart\App\App;
use FluentCartPro\App\Services\Email\Blocks\ButtonBlock;
use FluentCartPro\App\Services\Email\Blocks\ButtonsBlock;
use FluentCartPro\App\Services\Email\Blocks\CodeBlock;
use FluentCartPro\App\Services\Email\Blocks\ColumnBlock;
use FluentCartPro\App\Services\Email\Blocks\ColumnsBlock;
use FluentCartPro\App\Services\Email\Blocks\CoverBlock;
use FluentCartPro\App\Services\Email\Blocks\GroupBlock;
use FluentCartPro\App\Services\Email\Blocks\HeadingBlock;
use FluentCartPro\App\Services\Email\Blocks\ImageBlock;
use FluentCartPro\App\Services\Email\Blocks\ListBlock;
use FluentCartPro\App\Services\Email\Blocks\ListItemBlock;
use FluentCartPro\App\Services\Email\Blocks\MediaTextBlock;
use FluentCartPro\App\Services\Email\Blocks\ParagraphBlock;
use FluentCartPro\App\Services\Email\Blocks\PreformattedBlock;
use FluentCartPro\App\Services\Email\Blocks\PullquoteBlock;
use FluentCartPro\App\Services\Email\Blocks\QuoteBlock;
use FluentCartPro\App\Services\Email\Blocks\SeparatorBlock;
use FluentCartPro\App\Services\Email\Blocks\SocialLinksBlock;
use FluentCartPro\App\Services\Email\Blocks\SpacerBlock;
use FluentCartPro\App\Services\Email\Blocks\TableBlock;
use FluentCartPro\App\Services\Email\Blocks\VerseBlock;
use FluentCartPro\App\Services\Email\Blocks\EmailRowBlock;
use FluentCartPro\App\Services\Email\Blocks\OrderItemsLoopBlock;
use FluentCartPro\App\Services\Email\Blocks\LicenseDetailsLoopBlock;
use FluentCartPro\App\Services\Email\Blocks\DownloadDetailsLoopBlock;
use FluentCartPro\App\Services\Email\Blocks\SubscriptionDetailsLoopBlock;
use FluentCartPro\App\Services\Email\Blocks\ShortcodeConditionBlock;
use FluentCartPro\App\Services\Email\Blocks\ConditionContentBlock;
use FluentCartPro\App\Services\Email\Blocks\ConditionFallbackBlock;
use FluentCart\App\Helpers\Helper;
use FluentCartPro\App\Hooks\Handlers\FluentCartBlockEditorHandler;
use FluentCart\App\Services\Email\BlockEditorHelper;
use FluentCart\App\Services\TemplateService;
use FluentCart\Framework\Support\Arr;

/**
 * Gutenberg Block Parser for Email
 * Converts Gutenberg blocks to email-compatible HTML
 */
class FluentBlockParser
{

    private $data = [];

    public function __construct($data = [])
    {
        $this->data = $data;
    }

    private function isEmailEditorBlock($blockName)
    {
        foreach (FluentCartBlockEditorHandler::getEmailEditorBlocks() as $blockClass) {
            if ($blockName === 'fluent-cart/' . $blockClass::getEditorName()) {
                return true;
            }
        }
        return false;
    }

    /**
     * Parse Gutenberg blocks and convert to email HTML
     *
     * @param string $content The post content with Gutenberg blocks
     * @return string Email-compatible HTML
     */
    public function parse($content)
    {
        $blocks = parse_blocks($content);

        $css = $this->getCommonStyles();

        $content = $this->renderBlocks($blocks, false, true);

        $content = $this->replaceCssVars($content);

        return $css . $content;
    }

    /**
     * Public proxy for renderBlocks — allows block renderers to
     * render nested inner blocks without using reflection.
     *
     * @param array $blocks
     * @return string
     */
    public function renderNestedBlocks(array $blocks): string
    {
        return $this->renderBlocks($blocks, true);
    }

    /**
     * Public proxy for renderBlock — allows block renderers to
     * render a single nested block without using reflection.
     *
     * @param array $block
     * @return string
     */
    public function renderNestedBlock(array $block): string
    {
        return $this->renderBlock($block);
    }

    /**
     * Render blocks to email HTML
     */
    private function renderBlocks($blocks, $nested = false, $isRoot = false)
    {
        $html = '';

        foreach ($blocks as $block) {
            if (empty($block['blockName'])) {
                // Classic content or unrecognized block
                if (!empty($block['innerHTML'])) {
                    $html .= $this->wrapInTable($block['innerHTML']);
                }
                continue;
            }

            $html .= $this->renderBlock($block, $isRoot);
        }

        return $html;
    }

    /**
     * Render individual block
     */
    private function renderBlock($block, $isRoot = false)
    {
        $blockName = $block['blockName'];
        $attrs = $block['attrs'] ?? [];
        $innerHTML = $block['innerHTML'] ?? '';
        $innerBlocks = $block['innerBlocks'] ?? [];

        // For blocks with innerContent array, reconstruct innerHTML
        if (empty($innerHTML) && !empty($block['innerContent'])) {
            $innerHTML = implode('', array_filter($block['innerContent'], 'is_string'));
        }

        // Handle different block types
        switch ($blockName) {
            case 'core/paragraph':
                return (new ParagraphBlock($attrs, $innerHTML, $innerBlocks, $this))->render();

            case 'core/heading':
                return (new HeadingBlock($attrs, $innerHTML, $innerBlocks, $this))->render();

            case 'core/image':
                return (new ImageBlock($attrs, $innerHTML, $innerBlocks, $this))->render();

            case 'core/list':
                return (new ListBlock($attrs, $innerHTML, $innerBlocks, $this))->render();

            case 'core/list-item':
                return (new ListItemBlock($attrs, $innerHTML, $innerBlocks, $this))->render();

            case 'core/quote':
                return (new QuoteBlock($attrs, $innerHTML, $innerBlocks, $this))->render();

            case 'core/button':
                return (new ButtonBlock($attrs, $innerHTML, $innerBlocks, $this))->render();

            case 'core/buttons':
                return (new ButtonsBlock($attrs, $innerHTML, $innerBlocks, $this, $block))->render();

            case 'core/columns':
                return (new ColumnsBlock($attrs, $innerHTML, $innerBlocks, $this))->render();

            case 'core/column':
                return (new ColumnBlock($attrs, $innerHTML, $innerBlocks, $this))->render();

            case 'core/separator':
                return (new SeparatorBlock($attrs, $innerHTML, $innerBlocks, $this))->render();

            case 'core/spacer':
                return (new SpacerBlock($attrs, $innerHTML, $innerBlocks, $this))->render();

            case 'core/group':
                return (new GroupBlock($attrs, $innerHTML, $innerBlocks, $this))->setIsRoot($isRoot)->render();

            case 'core/cover':
                return (new CoverBlock($attrs, $innerHTML, $innerBlocks, $this))->render();

            case 'core/media-text':
                return (new MediaTextBlock($attrs, $innerHTML, $innerBlocks, $this))->render();

            case 'core/table':
                return (new TableBlock($attrs, $innerHTML, $innerBlocks, $this))->render();

            case 'core/social-links':
                return (new SocialLinksBlock($attrs, $innerHTML, $innerBlocks, $this))->render();

            case 'core/social-link':
                return ''; // Handled by parent social-links

            case 'core/freeform':
            case 'core/html':
                // Classic editor content - render as-is with email-safe wrapper
                return $this->wrapInTable($innerHTML);

            case 'core/preformatted':
                return (new PreformattedBlock($attrs, $innerHTML, $innerBlocks, $this))->render();

            case 'core/code':
                return (new CodeBlock($attrs, $innerHTML, $innerBlocks, $this))->render();

            case 'core/pullquote':
                return (new PullquoteBlock($attrs, $innerHTML, $innerBlocks, $this))->render();

            case 'core/verse':
                return (new VerseBlock($attrs, $innerHTML, $innerBlocks, $this))->render();
            case 'fluent-cart/order-wrapper':
                return $this->renderOrderWrapper($innerBlocks, $attrs, $innerHTML);
            case 'fluent-cart/order-items':
                return $this->renderOrderItemsTable($innerHTML, $attrs);
            case 'fluent-cart/email-order-items':
                return (new OrderItemsLoopBlock($attrs, $innerHTML, $innerBlocks, $this))
                    ->setParserData($this->data)->render();
            case 'fluent-cart/email-subscription-details':
                return (new SubscriptionDetailsLoopBlock($attrs, $innerHTML, $innerBlocks, $this))
                    ->setParserData($this->data)->render();
            case 'fluent-cart/subscription-details':
                return $this->renderOrderSubscriptionsDetails($innerHTML, $attrs);
            case 'fluent-cart/email-license-details':
                return (new LicenseDetailsLoopBlock($attrs, $innerHTML, $innerBlocks, $this))
                    ->setParserData($this->data)->render();
            case 'fluent-cart/email-download-details':
                return (new DownloadDetailsLoopBlock($attrs, $innerHTML, $innerBlocks, $this))
                    ->setParserData($this->data)->render();
            case 'fluent-cart/license-details':
                return $this->renderOrderLicenseDetails($innerHTML, $attrs);
            case 'fluent-cart/download-details':
                return $this->renderOrderDownloadsDetails($innerHTML, $attrs);
            case 'fluent-cart/order-addresses':
                return $this->renderOrderAddressesDetails($innerHTML, $attrs);
            case 'fluent-cart/email-row-header':
                return (new EmailRowBlock($attrs, $innerHTML, $innerBlocks, $this))
                    ->setRowType('header')->render();
            case 'fluent-cart/email-row-body':
                return (new EmailRowBlock($attrs, $innerHTML, $innerBlocks, $this))
                    ->setRowType('body')->render();
            case 'fluent-cart/email-row-footer':
                return (new EmailRowBlock($attrs, $innerHTML, $innerBlocks, $this))
                    ->setRowType('footer')->render();
            case 'fluent-cart/email-order-addresses':
                return (new \FluentCartPro\App\Services\Email\Blocks\OrderAddressesBlock($attrs, $innerHTML, $innerBlocks, $this))
                    ->setParserData($this->data)->render();
            case 'fluent-cart/email-address-container':
                return (new \FluentCartPro\App\Services\Email\Blocks\AddressContainerBlock($attrs, $innerHTML, $innerBlocks, $this))
                    ->setParserData($this->data)->render();
            case 'fluent-cart/email-billing-address':
            case 'fluent-cart/email-shipping-address':
                return $this->renderBlocks($innerBlocks, true);
            case 'fluent-cart/email-header':
            case 'fluent-cart/email-order-summary':
            case 'fluent-cart/email-order-totals':
                return $this->renderEmailWrapperBlock($innerBlocks, $attrs);
            case 'fluent-cart/shortcode-condition':
                return (new ShortcodeConditionBlock($attrs, $innerHTML, $innerBlocks, $this))
                    ->setParserData($this->data)->render();
            case 'fluent-cart/condition-content':
                return (new ConditionContentBlock($attrs, $innerHTML, $innerBlocks, $this))->render();
            case 'fluent-cart/condition-fallback':
                return (new ConditionFallbackBlock($attrs, $innerHTML, $innerBlocks, $this))->render();
            case 'fluent-cart/celebration':
                return $this->renderCelebration($attrs);
            default:
                if ($this->isEmailEditorBlock($blockName)) {
                    return render_block($block);
                }

                // Allow third-party blocks to render via action hook
                ob_start();
                do_action('fluent_cart/block_editor/render_block', [
                    'block'=> $block, 
                    'block_name'=>$blockName, 
                    'attributes'=>$attrs
                ]);
                $thirdPartyContent = ob_get_clean();
                if (!empty($thirdPartyContent)) {
                    return $thirdPartyContent;
                }

                // Fallback for unrecognized blocks
                if (!empty($innerHTML)) {
                    return $this->wrapInTable($innerHTML);
                } elseif (!empty($innerBlocks)) {
                    return $this->renderBlocks($innerBlocks, true);
                }
                return '';
        }
    }

    public function renderOrderWrapper($innerBlocks, $attrs, $innerHTML)
    {
        $style = $attrs['style'] ?? [];
        $layout = $attrs['layout'] ?? [];
        $backgroundColor = '';

        if (!empty($style['color']['background'])) {
            $backgroundColor = "background-color: {$style['color']['background']};";
        }

        $groupStyles = "padding: 20px; {$backgroundColor}";

        // Check if it's a flex layout
        $isFlex = isset($layout['type']) && $layout['type'] === 'flex';

        if ($isFlex) {
            $groupStyles .= " display: flex; flex-wrap: wrap; gap: 10px;";
            $justifyContent = $layout['justifyContent'] ?? 'flex-start';
            $groupStyles .= " justify-content: {$justifyContent};";
        }

        $content = '';
        if (!empty($innerBlocks)) {
            $content = $this->renderBlocks($innerBlocks, true);
        } elseif (!empty($innerHTML)) {
            $content = $innerHTML;
        }

        if (empty(trim($content))) {
            return '';
        }

        return "<table class=\"fct_order_wrapper\" role=\"presentation\" width=\"100%\" cellspacing=\"0\" cellpadding=\"0\" border=\"0\">
    <tr>
        <td style=\"padding: 0;\">
            {$content}
        </td>
    </tr>
</table>";
    }

    public function renderOrderItemsTable($innerHTML, $attrs)
    {
        return '{{order.items_table}}';
    }


    public function renderOrderSubscriptionsDetails($innerHTML, $attrs)
    {
        return '{{order.subscriptions_details}}';
    }

    public function renderOrderLicenseDetails($innerHTML, $attrs)
    {
        return '{{order.license_details}}';
    }

    public function renderOrderDownloadsDetails($innerHTML, $attrs)
    {
        return '{{order.download_details}}';
    }

    public function renderOrderAddressesDetails($innerHTML, $attrs)
    {
        return '{{order.address_details}}';
    }

    public function renderEmailHeader($innerHTML, $attrs)
    {
        return App::make('view')->make('emails.parts.order_header', $this->data);
    }

    /**
     * Render an email wrapper block (email-header, email-order-summary, etc.)
     * with its own style attributes (background, border, padding) applied.
     */
    private function renderEmailWrapperBlock($innerBlocks, $attrs)
    {
        $content = $this->renderBlocks($innerBlocks, true);

        if (empty(trim($content))) {
            return '';
        }

        // Build inline styles from the wrapper block's own attributes
        $style = Arr::get($attrs, 'style', []);
        $tdStyles = '';

        // Background color (preset or inline)
        if (!empty($attrs['backgroundColor'])) {
            $tdStyles .= 'background-color: ' . $this->getColorFromSlug($attrs['backgroundColor']) . ';';
        } elseif (!empty($style['color']['background'])) {
            $tdStyles .= 'background-color: ' . $this->getColorFromSlug($style['color']['background']) . ';';
        }

        // Gradient
        if (!empty($style['color']['gradient'])) {
            $tdStyles .= ' background: ' . $style['color']['gradient'] . ';';
        }

        // Detect if wrapper has visual styling (background/border/gradient)
        $hasBackground = !empty($attrs['backgroundColor'])
            || !empty($style['color']['background'])
            || !empty($style['color']['gradient']);
        $hasBorder = !empty($style['border']) || !empty($attrs['borderColor']);

        // Padding
        $padding = Arr::get($style, 'spacing.padding', []);
        if (!empty($padding)) {
            if (is_string($padding)) {
                $tdStyles .= " padding: {$this->resolveSpacingValue($padding)};";
            } elseif (is_array($padding)) {
                foreach (['top', 'right', 'bottom', 'left'] as $side) {
                    if (isset($padding[$side])) {
                        $tdStyles .= " padding-{$side}: {$this->resolveSpacingValue($padding[$side])};";
                    }
                }
            }
        } elseif ($hasBackground || $hasBorder) {
            // Add default padding so background/border is visible around inner content
            $tdStyles .= ' padding: 8px;';
        }

        // Margin
        $margin = Arr::get($style, 'spacing.margin', []);
        if (!empty($margin)) {
            if (is_string($margin)) {
                $tdStyles .= " margin: {$this->resolveSpacingValue($margin)};";
            } elseif (is_array($margin)) {
                foreach (['top', 'right', 'bottom', 'left'] as $side) {
                    if (isset($margin[$side])) {
                        $tdStyles .= " margin-{$side}: {$this->resolveSpacingValue($margin[$side])};";
                    }
                }
            }
        }

        // Border
        $border = Arr::get($style, 'border', []);
        if (!empty($border) || !empty($attrs['borderColor'])) {
            $hasShorthand = isset($border['width']) || isset($border['color']) || !empty($attrs['borderColor']);
            if ($hasShorthand) {
                $tdStyles .= ' border-width: ' . ($border['width'] ?? '1px') . ';';
                $tdStyles .= ' border-style: ' . ($border['style'] ?? 'solid') . ';';
                if (isset($border['color'])) {
                    $tdStyles .= ' border-color: ' . $this->getColorFromSlug($border['color']) . ';';
                }
                if (isset($attrs['borderColor'])) {
                    $tdStyles .= ' border-color: ' . $this->getColorFromSlug($attrs['borderColor']) . ';';
                }
            } elseif (isset($border['style'])) {
                $tdStyles .= " border-style: {$border['style']};";
            }

            // Border radius
            if (isset($border['radius'])) {
                $radius = $border['radius'];
                if (is_string($radius)) {
                    $tdStyles .= " border-radius: {$radius};";
                } elseif (is_array($radius)) {
                    $map = ['topLeft' => 'top-left', 'topRight' => 'top-right', 'bottomLeft' => 'bottom-left', 'bottomRight' => 'bottom-right'];
                    foreach ($map as $key => $css) {
                        if (isset($radius[$key])) {
                            $tdStyles .= " border-{$css}-radius: {$radius[$key]};";
                        }
                    }
                }
            }

            // Per-side borders
            foreach (['top', 'right', 'bottom', 'left'] as $side) {
                if (isset($border[$side])) {
                    $s = $border[$side];
                    $w = $s['width'] ?? '1px';
                    $bs = $s['style'] ?? 'solid';
                    $c = isset($s['color']) ? $this->getColorFromSlug($s['color']) : '#000';
                    $tdStyles .= " border-{$side}: {$w} {$bs} {$c};";
                }
            }
        }

        // If no styles were applied, return content directly
        if (empty(trim($tdStyles))) {
            return $content;
        }

        return "<div style=\"{$tdStyles}\">{$content}</div>";
    }

    /**
     * Render celebration block directly for email (avoids render_block CSS bloat).
     */
    private function renderCelebration($attrs)
    {
        $celebrationType = Arr::get($attrs, 'celebration_type', 'order');
        if (!in_array($celebrationType, ['order', 'renewal'], true)) {
            $celebrationType = 'order';
        }

        $text = TemplateService::getCelebration($celebrationType);

        if (empty($text)) {
            return '';
        }

        return App::make('view')->make('emails.parts.celebration', [
            'text' => $text
        ]);
    }

    /**
     * Parse CSS variable format and extract the slug
     * Handles formats like:
     * - var:preset|color|accent-4
     * - var(--wp--preset--color--accent-4)
     * - accent-4 (plain slug)
     */
    private function parseColorSlug($value)
    {
        if (empty($value)) {
            return '';
        }

        // If it's already a hex color, return as is
        if (preg_match('/^#[a-f0-9]{3,8}$/i', $value)) {
            return $value;
        }

        // If it's an rgb/rgba color, return as is
        if (preg_match('/^rgba?\(/i', $value)) {
            return $value;
        }

        // Handle var:preset|color|slug-name format
        if (strpos($value, 'var:preset|color|') === 0) {
            return substr($value, strlen('var:preset|color|'));
        }

        // Handle var(--wp--preset--color--slug-name) format
        if (preg_match('/^var\(--wp--preset--color--([^)]+)\)$/', $value, $matches)) {
            return $matches[1];
        }

        // Return as is (plain slug or other format)
        return $value;
    }

    /**
     *  Get color from WordPress color slug
     * */
    public function getColorFromSlug($slug)
    {
        // Parse the slug to handle CSS variable formats
        $parsedSlug = $this->parseColorSlug($slug);

        // If it's already a valid color value (hex, rgb), return it
        if (preg_match('/^#[a-f0-9]{3,8}$/i', $parsedSlug) || preg_match('/^rgba?\(/i', $parsedSlug)) {
            return $parsedSlug;
        }

        // First, try to get from FluentCart Helper (which reads theme.json and editor-color-palette)
        static $colorMap = null;

        if ($colorMap === null) {
            $colorMap = [];

            $themeColors = $this->getThemeColorPalette();
            if (!empty($themeColors)) {
                foreach ($themeColors as $colorData) {
                    if (isset($colorData['slug']) && isset($colorData['color'])) {
                        $colorMap[$colorData['slug']] = $colorData['color'];
                    }
                }
            }

            // Also get theme preferences
            $themePref = $this->getThemePrefScheme();
            if (!empty($themePref['colors'])) {
                foreach ($themePref['colors'] as $colorData) {
                    if (isset($colorData['slug']) && isset($colorData['color'])) {
                        $colorMap[$colorData['slug']] = $colorData['color'];
                    }
                }
            }
        }

        // Check our color map first
        if (isset($colorMap[$parsedSlug])) {
            return $colorMap[$parsedSlug];
        }

        // Try to get theme color from WordPress theme.json or global settings
        if (function_exists('wp_get_global_settings')) {
            $settings = wp_get_global_settings();
            if (!empty($settings['color']['palette']['theme'])) {
                foreach ($settings['color']['palette']['theme'] as $color) {
                    if (isset($color['slug']) && $color['slug'] === $parsedSlug && !empty($color['color'])) {
                        return $color['color'];
                    }
                }
            }
        }

        // Try WP_Theme_JSON for block themes
        if (class_exists('WP_Theme_JSON_Resolver')) {
            $theme_json = \WP_Theme_JSON_Resolver::get_merged_data();
            if ($theme_json) {
                $settings = $theme_json->get_settings();
                if (!empty($settings['color']['palette'])) {
                    foreach ($settings['color']['palette'] as $palette) {
                        if (isset($palette['slug']) && $palette['slug'] === $parsedSlug && !empty($palette['color'])) {
                            return $palette['color'];
                        }
                    }
                }
            }
        }

        // Fallback: Common WordPress and popular theme colors
        $colors = [
            // Theme palette colors (adjust these based on your active theme)
            // Twenty Twenty-Three defaults
            'theme-palette-color-1' => '#000000', // Base/Black
            'theme-palette-color-2' => '#6f42c1', // Purple
            'theme-palette-color-3' => '#007cba', // Blue
            'theme-palette-color-4' => '#16a085', // Teal
            'theme-palette-color-5' => '#e74c3c', // Red
            'theme-palette-color-6' => '#f39c12', // Orange
            'theme-palette-color-7' => '#ffffff', // White
            'theme-palette-color-8' => '#f5f5f5', // Light Gray
            'theme-palette-color-9' => '#cccccc', // Gray

            // Standard WordPress colors
            'black'                 => '#000000',
            'white'                 => '#ffffff',
            'primary'               => '#0073aa',
            'secondary'             => '#23282d',
            'tertiary'              => '#F0F0F1',

            // Common named colors
            'red'                   => '#e74c3c',
            'blue'                  => '#3498db',
            'green'                 => '#2ecc71',
            'yellow'                => '#f1c40f',
            'orange'                => '#e67e22',
            'purple'                => '#9b59b6',
            'cyan'                  => '#1abc9c',
            'vivid-red'             => '#cf2e2e',
            'vivid-orange'          => '#ff6900',
            'vivid-cyan-blue'       => '#0693e3',
            'vivid-green-cyan'      => '#00d084',
            'vivid-purple'          => '#9b51e0',
            'luminous-vivid-amber'  => '#fcb900',
            'luminous-vivid-orange' => '#ff6900',
            'light-green-cyan'      => '#7bdcb5',
            'pale-pink'             => '#f78da7',
            'pale-cyan-blue'        => '#8ed1fc',
        ];

        return $colors[$parsedSlug] ?? '#0073aa';
    }

    public function getThemeColorPalette()
    {
        $color_palette = current((array)get_theme_support('editor-color-palette'));
        $theme_json_path = get_theme_file_path('theme.json');

        if (file_exists($theme_json_path)) {
            $theme_json = json_decode(file_get_contents($theme_json_path), true);

            if (isset($theme_json['settings']['color']['palette'])) {
                $color_palette = $theme_json['settings']['color']['palette'];
            }
        }
        if (!$color_palette) {
            $color_palette = [];
        }

        return (array)$color_palette;
    }

    public function getThemePrefScheme()
    {
        static $pref;
        if (!$pref) {

            $color_palette = BlockEditorHelper::getDefaultPreset('color');

            $font_sizes = BlockEditorHelper::getDefaultPreset('font-size');

            /**
             * Filter the theme preferences for FluentCart.
             *
             * This filter allows modification of the theme preferences, including colors and font sizes.
             *
             * @param array {
             *     The theme preferences.
             *
             * @type array $colors The color palette.
             * @type array $font_sizes The font sizes.
             * }
             * @since 2.6.51
             *
             */
            $pref = apply_filters('fluent_cart/theme_pref', [
                'colors'     => (array)$color_palette,
                'font_sizes' => (array)$font_sizes
            ]);
        }

        return $pref;

    }

    public function getFontSizeFromSlug($slug) {
        $font_sizes = [
            'small'   => '14px',
            'medium'  => '18px',
            'large'   => '24px',
            'larger'  => '32px',
            'xxlarge' => '42px',
        ];

        // Get font sizes from theme defined
        $theme_font_sizes = $this->getThemeFontSizes();
        if (!empty($theme_font_sizes)) {
            foreach ($theme_font_sizes as $size) {
                if (isset($size['slug']) && $size['slug'] === $slug && !empty($size['size'])) {
                    return $size['size'];
                }
            }
        }

        return $font_sizes[$slug] ?? '16px';
    }

    public static function getThemeFontSizes()
    {
        $font_sizes = current((array)get_theme_support('editor-font-sizes'));
        $theme_json_path = get_theme_file_path('theme.json');

        if (file_exists($theme_json_path)) {
            $theme_json = json_decode(file_get_contents($theme_json_path), true);

            if (isset($theme_json['settings']['typography']['fontSizes'])) {
                $font_sizes = $theme_json['settings']['typography']['fontSizes'];
            }
        }

        return $font_sizes;
    }

    /**
     * Wrap content in email-safe table structure
     */
    private function wrapInTable($content)
    {
        if (empty(trim($content))) {
            return '';
        }

        return "<table role=\"presentation\" width=\"100%\" cellspacing=\"0\" cellpadding=\"0\" border=\"0\">
    <tr>
        <td style=\"padding: 0;\">
            {$content}
        </td>
    </tr>
</table>";
    }

    /**
     * Generate complete email HTML with wrapper
     */
    public function generateEmailHtml($content, $title = '')
    {
        $parsedContent = $this->parse($content);

        return "<!DOCTYPE html>
<html lang=\"en\">
<head>
    <meta charset=\"UTF-8\">
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">
    <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">
    <title>{$title}</title>
    <style type=\"text/css\">
        body {
            margin: 0;
            padding: 0;
            font-family: Arial, Helvetica, sans-serif;
            font-size: 16px;
            line-height: 1.6;
            color: #333333;
            background-color: #f4f4f4;
        }
        table {
            border-collapse: collapse;
        }
        img {
            border: 0;
            outline: none;
            text-decoration: none;
            -ms-interpolation-mode: bicubic;
        }
        a {
            color: #0073aa;
        }
        @media only screen and (max-width: 600px) {
            .email-container {
                width: 100% !important;
            }
        }
    </style>
</head>
<body style=\"margin: 0; padding: 0; font-family: Arial, Helvetica, sans-serif; background-color: #f4f4f4;\">
    <table role=\"presentation\" width=\"100%\" cellspacing=\"0\" cellpadding=\"0\" border=\"0\">
        <tr>
            <td align=\"center\" style=\"padding: 20px 0;\">
                <table role=\"presentation\" class=\"email-container\" width=\"600\" cellspacing=\"0\" cellpadding=\"0\" border=\"0\" style=\"max-width: 600px; background-color: #ffffff;\">
                    <tr>
                        <td style=\"padding: 40px 30px;\">
                            {$parsedContent}
                        </td>
                    </tr>
                </table>
            </td>
        </tr>
    </table>
</body>
</html>";
    }


    public function getCommonStyles()
    {

        $color_palette = [
            [
                "name"  => __("Black", "fluent-cart-pro"),
                "slug"  => "black",
                "color" => "#000000"
            ],
            [
                "name"  => __("Cyan bluish gray", "fluent-cart-pro"),
                "slug"  => "cyan-bluish-gray",
                "color" => "#abb8c3"
            ],
            [
                "name"  => __("White", "fluent-cart-pro"),
                "slug"  => "white",
                "color" => "#ffffff"
            ],
            [
                "name"  => __("Pale pink", "fluent-cart-pro"),
                "slug"  => "pale-pink",
                "color" => "#f78da7"
            ],
            [
                "name"  => __("Luminous vivid orange", "fluent-cart-pro"),
                "slug"  => "luminous-vivid-orange",
                "color" => "#ff6900"
            ],
            [
                "name"  => __("Luminous vivid amber", "fluent-cart-pro"),
                "slug"  => "luminous-vivid-amber",
                "color" => "#fcb900"
            ],
            [
                "name"  => __("Light green cyan", "fluent-cart-pro"),
                "slug"  => "light-green-cyan",
                "color" => "#7bdcb5"
            ],
            [
                "name"  => __("Vivid green cyan", "fluent-cart-pro"),
                "slug"  => "vivid-green-cyan",
                "color" => "#00d084"
            ],
            [
                "name"  => __("Pale cyan blue", "fluent-cart-pro"),
                "slug"  => "pale-cyan-blue",
                "color" => "#8ed1fc"
            ],
            [
                "name"  => __("Vivid cyan blue", "fluent-cart-pro"),
                "slug"  => "vivid-cyan-blue",
                "color" => "#0693e3"
            ],
            [
                "name"  => __("Vivid purple", "fluent-cart-pro"),
                "slug"  => "vivid-purple",
                "color" => "#9b51e0"
            ]
        ];

        ob_start();
        ?>
        <style>
            .has-fluent-x-small-font-size {
                font-size: 14px;
            }

            .has-fluent-normal-font-size {
                font-size: 16px;
            }

            .has-fluent-medium-font-size {
                font-size: 18px;
            }

            .has-fluent-large-font-size {
                font-size: 20px;
            }

            .has-fluent-x-large-font-size {
                font-size: 26px;
            }

            .has-border-color {
                border-style: solid;
            }

            .has-text-align-left {
                text-align: left;
            }

            .has-text-align-center {
                text-align: center;
            }

            .has-text-align-right {
                text-align: right;
            }

            .fluent-paragraph {
                line-height: 1.4;
            }

            .wp-block-button__link {
                display: inline-block;
                padding: 12px 24px;
                text-decoration: none;
                font-weight: bold;
                border-radius: 9999px;
                text-align: center;
                color: #ffffff;
                background-color: #0073aa;
            }

            <?php foreach ($color_palette as $item): ?>
            .has-<?php echo esc_attr($item['slug']); ?>-color {
                color: <?php echo esc_html($item['color']); ?>;
            }

            .has-<?php echo esc_attr($item['slug']); ?>-background-color {
                background-color: <?php echo esc_html($item['color']); ?>;
            }

            .has-<?php echo esc_attr($item['slug']); ?>-border-color {
                border-color: <?php echo esc_html($item['color']); ?>;
            }

            <?php endforeach; ?>
        </style>
        <?php

        return ob_get_clean();
    }

    public function replaceCssVars($content = '')
    {
        $replaces = [
            'var(--wp--preset--spacing--fluent-20)' => '20px',
            'var(--wp--preset--spacing--fluent-30)' => '30px',
            'var(--wp--preset--spacing--fluent-40)' => '40px',
            'var(--wp--preset--spacing--fluent-50)' => '50px',
            'var(--wp--preset--spacing--fluent-60)' => '60px',
            'var(--wp--preset--spacing--fluent-70)' => '70px',
            'var(--wp--preset--spacing--fluent-80)' => '80px'
        ];

        return str_replace(array_keys($replaces), array_values($replaces), $content);
    }

    /**
     * Resolve a spacing value that might be a CSS variable reference
     *
     * @param string $value The spacing value
     * @return string Resolved pixel value
     */
    public function resolveSpacingValue($value)
    {
        if (strpos($value, 'var:preset|spacing|') === 0) {
            $slug = substr($value, strlen('var:preset|spacing|'));
            return $this->getSpacingFromSlug($slug);
        }

        if (preg_match('/^var\(--wp--preset--spacing--(.+)\)$/', $value, $m)) {
            return $this->getSpacingFromSlug($m[1]);
        }

        return $value;
    }

    private function getSpacingFromSlug($slug)
    {
        if (function_exists('wp_get_global_settings')) {
            $settings = wp_get_global_settings();
            $presets = $settings['spacing']['spacingSizes']['default'] ?? ($settings['spacing']['spacingSizes'] ?? []);
            foreach ($presets as $preset) {
                if (isset($preset['slug']) && $preset['slug'] === $slug && !empty($preset['size'])) {
                    return $preset['size'];
                }
            }
        }

        $defaults = [
            '20' => '20px', '30' => '30px', '40' => '40px',
            '50' => '50px', '60' => '60px', '70' => '70px', '80' => '80px',
            'fluent-20' => '20px', 'fluent-30' => '30px', 'fluent-40' => '40px',
            'fluent-50' => '50px', 'fluent-60' => '60px', 'fluent-70' => '70px', 'fluent-80' => '80px',
        ];

        return isset($defaults[$slug]) ? $defaults[$slug] : '20px';
    }

    /**
     * Get shadow value from slug or preset
     */
    public function getShadowFromSlug($slug)
    {
        // Parse preset format: var:preset|shadow|slug-name
        if (strpos($slug, 'var:preset|shadow|') === 0) {
            $slug = substr($slug, strlen('var:preset|shadow|'));
        }

        // If it's already a valid box-shadow value, return it
        if (preg_match('/^\d+px\s+\d+px/', $slug)) {
            return $slug;
        }

        // Try to get from WordPress theme settings
        if (function_exists('wp_get_global_settings')) {
            $settings = wp_get_global_settings();
            if (!empty($settings['shadow']['presets'])) {
                foreach ($settings['shadow']['presets'] as $shadow) {
                    if (isset($shadow['slug']) && $shadow['slug'] === $slug && !empty($shadow['shadow'])) {
                        return $shadow['shadow'];
                    }
                }
            }
        }

        // Try WP_Theme_JSON for block themes
        if (class_exists('WP_Theme_JSON_Resolver')) {
            $theme_json = \WP_Theme_JSON_Resolver::get_merged_data();
            if ($theme_json) {
                $settings = $theme_json->get_settings();
                if (!empty($settings['shadow']['presets'])) {
                    foreach ($settings['shadow']['presets'] as $shadow) {
                        if (isset($shadow['slug']) && $shadow['slug'] === $slug && !empty($shadow['shadow'])) {
                            return $shadow['shadow'];
                        }
                    }
                }
            }
        }

        // Fallback shadow presets (common WordPress shadows)
        $shadows = [
                'natural'   => '6px 6px 9px rgba(0, 0, 0, 0.2)',
                'deep'      => '12px 12px 50px rgba(0, 0, 0, 0.4)',
                'sharp'     => '6px 6px 0px rgba(0, 0, 0, 0.2)',
                'outlined'  => '6px 6px 0px -3px rgba(255, 255, 255, 1), 6px 6px rgba(0, 0, 0, 1)',
                'crisp'     => '6px 6px 0px rgba(0, 0, 0, 1)',
        ];

        return $shadows[$slug] ?? 'none';
    }

}

// Usage Example:
/*
$parser = new GutenbergEmailParser();

// Option 1: Parse blocks only (returns HTML fragment)
$post_content = get_post_field('post_content', $post_id);
$emailHtml = $parser->parse($post_content);

// Option 2: Generate complete email HTML with wrapper
$completeEmail = $parser->generateEmailHtml($post_content, 'Email Title');

// Send email
wp_mail($to, $subject, $completeEmail, ['Content-Type: text/html; charset=UTF-8']);
*/
