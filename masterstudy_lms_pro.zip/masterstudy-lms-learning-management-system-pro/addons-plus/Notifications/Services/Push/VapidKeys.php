<?php

namespace MasterStudy\Lms\Pro\AddonsPlus\Notifications\Services\Push;

use Minishlink\WebPush\VAPID;

final class VapidKeys {
	public const OPTION_KEY = 'masterstudy_notifications_vapid_keys';

	public function get(): array {
		$keys = get_option( self::OPTION_KEY, array() );

		if ( is_array( $keys ) && ! empty( $keys['publicKey'] ) && ! empty( $keys['privateKey'] ) ) {
			return $keys;
		}

		if ( ! PushRequirements::is_met() ) {
			return array();
		}

		try {
			$keys = VAPID::createVapidKeys();
		} catch ( \Throwable $error ) {
			return array();
		}

		if ( ! add_option( self::OPTION_KEY, $keys, '', false ) ) {
			$stored_keys = get_option( self::OPTION_KEY, array() );

			if ( is_array( $stored_keys ) && ! empty( $stored_keys['publicKey'] ) && ! empty( $stored_keys['privateKey'] ) ) {
				return $stored_keys;
			}

			update_option( self::OPTION_KEY, $keys, false );
		}

		return $keys;
	}

	public function public_key(): string {
		$keys = $this->get();

		return isset( $keys['publicKey'] ) ? (string) $keys['publicKey'] : '';
	}

	public function subject(): string {
		$email   = sanitize_email( (string) get_option( 'admin_email' ) );
		$subject = $this->is_valid_email_subject( $email ) ? 'mailto:' . $email : '';

		if ( '' === $subject ) {
			$home_url = home_url( '/' );
			$subject  = 0 === strpos( $home_url, 'https://' ) ? esc_url_raw( $home_url ) : '';
		}

		$subject = apply_filters( 'masterstudy_notifications_vapid_subject', $subject );

		if ( ! is_string( $subject ) || ! $this->is_valid_subject( $subject ) ) {
			return 'mailto:admin@example.com';
		}

		return sanitize_text_field( $subject );
	}

	private function is_valid_subject( string $subject ): bool {
		if ( 0 === strpos( $subject, 'mailto:' ) ) {
			return $this->is_valid_email_subject( substr( $subject, 7 ) );
		}

		if ( 0 !== strpos( $subject, 'https://' ) || false === wp_http_validate_url( $subject ) ) {
			return false;
		}

		$host = wp_parse_url( $subject, PHP_URL_HOST );

		return is_string( $host ) && $this->is_public_host( $host );
	}

	private function is_valid_email_subject( string $email ): bool {
		if ( false !== strpos( $email, '<' ) || false !== strpos( $email, '>' ) ) {
			return false;
		}

		if ( ! is_email( $email ) ) {
			return false;
		}

		$domain = substr( strrchr( $email, '@' ), 1 );

		return is_string( $domain ) && $this->is_public_host( $domain );
	}

	private function is_public_host( string $host ): bool {
		$host = strtolower( trim( $host, " \t\n\r\0\x0B." ) );

		if ( '' === $host || false === strpos( $host, '.' ) || false !== filter_var( $host, FILTER_VALIDATE_IP ) ) {
			return false;
		}

		if ( in_array( $host, array( 'localhost', 'localhost.localdomain' ), true ) ) {
			return false;
		}

		foreach ( array( '.local', '.localhost', '.test', '.invalid' ) as $suffix ) {
			if ( substr( $host, -strlen( $suffix ) ) === $suffix ) {
				return false;
			}
		}

		return true;
	}
}
