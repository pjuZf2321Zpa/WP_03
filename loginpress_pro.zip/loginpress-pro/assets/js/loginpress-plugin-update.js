/**
 * Disable LoginPress Pro on Dashboard > Updates when its package is blocked.
 *
 * @package LoginPress-pro
 */
( function () {
	'use strict';

	var config = window.loginpressProUpdateBulk || {};
	var proBasename = config.proBasename;

	if ( ! proBasename ) {
		return;
	}

	function escapeAttr( value ) {
		if ( window.CSS && typeof window.CSS.escape === 'function' ) {
			return window.CSS.escape( value );
		}

		return String( value ).replace( /["\\]/g, '\\$&' );
	}

	function disableProBulk() {
		var selector = 'input[name="checked[]"][value="' + escapeAttr( proBasename ) + '"]';

		document.querySelectorAll( selector ).forEach( function ( input ) {
			input.disabled = true;
			input.checked = false;
			input.setAttribute( 'aria-disabled', 'true' );

			if ( ! input.id ) {
				return;
			}

			var label = document.querySelector( 'label[for="' + escapeAttr( input.id ) + '"]' );

			if ( label ) {
				label.setAttribute( 'aria-disabled', 'true' );
				label.classList.add( 'disabled' );
			}
		} );
	}

	if ( document.readyState === 'loading' ) {
		document.addEventListener( 'DOMContentLoaded', disableProBulk );
	} else {
		disableProBulk();
	}
}() );
