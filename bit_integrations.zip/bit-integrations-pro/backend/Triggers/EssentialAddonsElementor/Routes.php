<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Core\Util\Route;
use BitApps\IntegrationsPro\Triggers\EssentialAddonsElementor\EssentialAddonsElementorController;

Route::get('essential-addons-elementor/get', [EssentialAddonsElementorController::class, 'getAllTasks']);
