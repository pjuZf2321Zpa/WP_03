<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Actions\BookingPress\BookingPressProHelper;
use BitApps\IntegrationsPro\Config;
use BitApps\IntegrationsPro\Core\Util\Hooks;

Hooks::filter(Config::withFreePrefix('bookingpress_cancel_appointment'), [BookingPressProHelper::class, 'cancelAppointment'], 10, 2);
Hooks::filter(Config::withFreePrefix('bookingpress_update_appointment_status'), [BookingPressProHelper::class, 'updateAppointmentStatus'], 10, 2);
Hooks::filter(Config::withFreePrefix('bookingpress_create_customer'), [BookingPressProHelper::class, 'createCustomer'], 10, 2);
Hooks::filter(Config::withFreePrefix('bookingpress_update_customer'), [BookingPressProHelper::class, 'updateCustomer'], 10, 2);
Hooks::filter(Config::withFreePrefix('bookingpress_delete_appointment'), [BookingPressProHelper::class, 'deleteAppointment'], 10, 2);
Hooks::filter(Config::withFreePrefix('bookingpress_delete_customer'), [BookingPressProHelper::class, 'deleteCustomer'], 10, 2);
