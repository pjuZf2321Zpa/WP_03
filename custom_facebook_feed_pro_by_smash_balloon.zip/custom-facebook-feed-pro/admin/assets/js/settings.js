var cffSettings;

// Tab index → template id. Advanced keeps 'app-4' so the existing
// v-if="selected === 'app-4'" in tab/advanced.php keeps matching; the new
// Debug tab is inserted before Advanced and gets 'app-5'.
var CFF_TAB_ID_MAP = { 0: 'app-1', 1: 'app-2', 2: 'app-3', 3: 'app-5', 4: 'app-4', 5: 'app-6' };

// Declaring as global variable for quick prototyping
var settings_data = {
    adminUrl: cff_settings.admin_url,
    nonce: cff_settings.nonce,
    ajaxHandler: cff_settings.ajax_handler,
    iCalURLs 	: cff_settings.iCalURLs,
    model: cff_settings.model,
    feeds: cff_settings.feeds,
    links: cff_settings.links,
    tooltipName: null,
    sourcesList : cff_settings.sources,
    dialogBoxPopupScreen   : cff_settings.dialogBoxPopupScreen,
    selectSourceScreen      : cff_settings.selectSourceScreen,
    licenseBtnClicked : false,
    socialWallActivated: cff_settings.socialWallActivated,
    socialWallLinks: cff_settings.socialWallLinks,
    exportFeed: 'none',
    locales: cff_settings.locales,
    timezones: cff_settings.timezones,
    genericText: cff_settings.genericText,
    generalTab: cff_settings.generalTab,
    feedsTab: cff_settings.feedsTab,
    translationTab: cff_settings.translationTab,
    advancedTab: cff_settings.advancedTab,
    debugTab: cff_settings.debugTab,
    eventsSync: cff_settings.eventsSync,
    eventsSyncNowStatus: null,
    eventsSyncCleanupStatus: null,
    eventsSyncCleanupTarget: null,
    eventsSyncInstallStatus: null,
    eventsSyncClearLogStatus: null,
    upgradeUrl: cff_settings.upgradeUrl,
    supportPageUrl: cff_settings.supportPageUrl,
    licenseKey: cff_settings.licenseKey,
    pluginItemName: cff_settings.pluginItemName,
    licenseType: 'pro',
    licenseStatus: cff_settings.licenseStatus,
    licenseErrorMsg: cff_settings.licenseErrorMsg,
    extensionsLicense: cff_settings.extensionsLicense,
    extensionsLicenseKey: cff_settings.extensionsLicenseKey,
    extensionFieldHasError: false,
    cronNextCheck: cff_settings.nextCheck,
    currentView: null,
    selected: null,
    current: 0,
    sections: ["General", "Feeds", "Translation", "Data Sharing", "Advanced", "Events"],
    indicator_width: 0,
    indicator_pos: 0,
    forwards: true,
    currentTab: null,
    import_file: null,
    gdprInfoTooltip: null,
    loaderSVG: cff_settings.loaderSVG,
    checkmarkSVG: cff_settings.checkmarkSVG,
    uploadSVG: cff_settings.uploadSVG,
    exportSVG: cff_settings.exportSVG,
    reloadSVG: cff_settings.reloadSVG,
    tooltipHelpSvg: cff_settings.tooltipHelpSvg,
    tooltip : {
        text : '',
        hover : false
    },

    cogSVG: cff_settings.cogSVG,
    deleteSVG: cff_settings.deleteSVG,
    svgIcons : cff_svgs,

    testConnectionStatus: null,
    recheckLicenseStatus: null,
    btnStatus: null,
    uploadStatus: null,
    clearCacheStatus: null,
    optimizeCacheStatus: null,
    clearErrorLogStatus: null,
    dpaResetStatus: null,
    wpvibeInstallStatus: null, // null | 'loading' | 'failed'
    pressedBtnName: null,
    loading: false,
    hasError: cff_settings.hasError,
    dialogBox : {
        active : false,
        type : null,
        heading : null,
        description : null
    },
    sourceToDelete : {},
    viewsActive : {
        sourcePopup : false,
        sourcePopupScreen : 'redirect_1',
        sourcePopupType : 'creation',
        instanceSourceActive : null,
        whyRenewLicense : false,
        licenseLearnMore : false,
        iCalUrlPopup : false,
    },
    cffLicenseNoticeActive: (cff_settings.cffLicenseNoticeActive === '1'),
    cffLicenseInactiveState: (cff_settings.cffLicenseInactiveState === '1'),
    //Add New Source
    newSourceData        : cff_settings.newSourceData ? cff_settings.newSourceData : null,
    sourceConnectionURLs : cff_settings.sourceConnectionURLs,
    returnedApiSourcesList : [],
    addNewSource : {
        typeSelected        : 'page',
        manualSourceID      : null,
        manualSourceToken   : null
    },
    selectedFeed : 'none',
    // Add Source split button: whether the source-kind menu is open.
    sourceKindMenuOpen : false,
    licenseTierFeatures : cff_settings.licenseTierFeatures || [],
    expandedFeedID : null,
    notificationElement : {
        type : 'success', // success, error, warning, message
        text : '',
        shown : null
    },
    selectedSourcesToConnect : [],

    //Loading Bar
    fullScreenLoader : false,
    appLoaded : false,
    previewLoaded : false,
    loadingBar : true,
    addIcalUrl : {
        reconnectPage : false,
		pageToken : null,
		url : null,
		source_id : null,
		loadingAjax : false,
		success: false,
		isError : false,
		errorMessage : ''
    },
    upgradeNewVersion : false,
    upgradeNewVersionUrl : false,
    upgradeRemoteVersion : '',
    isLicenseUpgraded : cff_settings.isLicenseUpgraded,
    licenseUpgradedInfo : cff_settings.licenseUpgradedInfo,
    licenseUpgradedInfoTierName : null
};

// The tab component
Vue.component("tab", {
    props: ["section", "index"],
    template: `
        <button type="button" class="tab" :id="'cff-settings-tab-' + section.toLowerCase().trim().split(' ').join('-')" role="tab" :aria-selected="section === $parent.currentTab ? 'true' : 'false'" :aria-controls="'cff-panel-' + section.toLowerCase().trim().split(' ').join('-')" :tabindex="section === $parent.currentTab ? 0 : -1" @click="emitWidth($el);changeComponent(index);activeTab(section)" @keydown="onTabKeydown">{{section}}</button>
    `,
    created: () => {
        let urlParams = new URLSearchParams(window.location.search);
        let view = urlParams.get('view');
        if ( view === null ) {
            view = 'general';
        }
        settings_data.currentView = view;
        settings_data.currentTab = settings_data.sections[0];
        settings_data.selected = "app-1";
    },
    methods: {
        emitWidth: function(el) {
            settings_data.indicator_width = jQuery(el).outerWidth();
            settings_data.indicator_pos = jQuery(el).position().left;
        },
        changeComponent: function(index) {
            var prev = settings_data.current;
            if (prev < index) {
                settings_data.forwards = false;
            } else if (prev > index) {
                settings_data.forwards = true;
            }
            settings_data.selected = CFF_TAB_ID_MAP[index] || 'app-1';
            settings_data.current = index;
        },
        activeTab: function(section) {
            this.setView(section.toLowerCase().trim().split(' ').join('-'));
            settings_data.currentTab = section;
        },
        setView: function(section) {
            history.replaceState({}, null, settings_data.adminUrl + 'admin.php?page=cff-settings&view=' + section);
        },
        // WAI-ARIA Authoring Practices tablist keyboard interaction.
        // Ported from instagram-feed-pro settings.js.
        onTabKeydown: function (e) {
            var tabs = Array.prototype.slice.call(
                document.querySelectorAll('#sb-tabs-container [role="tablist"] [role="tab"]')
            );
            var idx = tabs.indexOf(e.currentTarget);
            if (idx === -1) return;
            var next = null;
            if (e.key === 'ArrowRight' || e.keyCode === 39) {
                next = tabs[(idx + 1) % tabs.length];
            } else if (e.key === 'ArrowLeft' || e.keyCode === 37) {
                next = tabs[(idx - 1 + tabs.length) % tabs.length];
            } else if (e.key === 'Home' || e.keyCode === 36) {
                next = tabs[0];
            } else if (e.key === 'End' || e.keyCode === 35) {
                next = tabs[tabs.length - 1];
            }
            if (!next) return;
            e.preventDefault();
            next.focus();
            next.click();
        }
    }
});

var cffSettings = new Vue({
    el: "#cff-settings",
    http: {
        emulateJSON: true,
        emulateHTTP: true
    },
    data: settings_data,
    watch: {
        // Invariant: when data-sharing consent is on, in-plugin notifications
        // must also be on. The Debug tab template disables the notifications
        // checkbox while DSC is true; this enforces the model side so a stale
        // DSC=true/notif=false combination can't persist on save.
        'model.debug.sbc_data_sharing_consent': {
            immediate: true,
            handler: function (newVal) {
                if (newVal && this.model && this.model.debug) {
                    this.model.debug.sbc_in_plugin_notifications = true;
                }
            }
        }
    },
    created: function() {
        this.$nextTick(function() {
            let tabEl = document.querySelector('.tab');
            settings_data.indicator_width = tabEl.offsetWidth;
        });
        setTimeout(function(){
            settings_data.appLoaded = true;
        },350);
    },
    mounted: function(){
        var self = this;
        // set the current view page on page load
        let viewIndex = settings_data.sections.findIndex(function (s) { return s.toLowerCase().trim().split(' ').join('-') === settings_data.currentView; });
        // Fall back to the first tab when the ?view= URL param is unknown — e.g. a
        // legacy ?view=debug bookmark after the tab was renamed to "data-controls".
        // Without this guard querySelector() returns null and reading offsetWidth
        // throws a TypeError that blanks the entire settings page.
        if (viewIndex < 0) {
            viewIndex = 0;
            settings_data.currentView = settings_data.sections[0].toLowerCase().trim().split(' ').join('-');
        }
        let activeEl = document.querySelector('button.tab#cff-settings-tab-' + settings_data.currentView);
        if (activeEl) {
            settings_data.indicator_width = activeEl.offsetWidth;
            settings_data.indicator_pos = activeEl.offsetLeft;
        }

        // On a hard refresh, the measurement above can run before the tab web
        // font swaps in, leaving the underline indicator narrower/offset (worst
        // on later tabs). Re-measure the active tab once fonts/layout settle and
        // on resize. Keyed off currentTab so it stays correct after navigation.
        var sbReindicateTab = function () {
            var active = settings_data.currentTab;
            if (!active) { return; }
            var el = document.querySelector('button.tab#cff-settings-tab-' + active.toLowerCase().trim().split(' ').join('-'));
            if (el) {
                settings_data.indicator_width = el.offsetWidth;
                settings_data.indicator_pos = el.offsetLeft;
            }
        };
        if (document.fonts && document.fonts.ready && typeof document.fonts.ready.then === 'function') {
            document.fonts.ready.then(function () { sbReindicateTab(); });
        }
        window.addEventListener('load', sbReindicateTab);
        window.addEventListener('resize', sbReindicateTab);
        settings_data.selected = CFF_TAB_ID_MAP[viewIndex] || 'app-1';
        settings_data.current = viewIndex;
        settings_data.currentTab = settings_data.sections[viewIndex];

        setTimeout(function(){
            settings_data.appLoaded = true;
        },350);

        if( this.licenseUpgradedInfo ){
            this.getUpgradedProTier()
        }

        var connectParams = new URLSearchParams(window.location.search);
        if (connectParams.get('connect_source') === '1') {
            setTimeout(function() {
                self.activateView('sourcePopup', 'creationRedirect');
            }, 500);
        }

    },
    computed: {
        getStyle: function() {
            return {
                position: "absolute",
                bottom: "0px",
                left: settings_data.indicator_pos + "px",
                width: settings_data.indicator_width + "px",
                height: "2px"
            };
        },
        chooseDirection: function() {
            return "slide-fade";
        }
    },
    methods:  {
        activateLicense: function() {
            this.hasError = false;
            this.loading = true;
            this.pressedBtnName = 'cff';
            this.licenseBtnClicked = true;

            let data = new FormData();
            data.append( 'action', 'cff_activate_license' );
            data.append( 'license_key', this.licenseKey );
            data.append( 'nonce', this.nonce );
            fetch(this.ajaxHandler, {
                method: "POST",
                credentials: 'same-origin',
                body: data
            })
            .then(response => response.json())
            .then(data => {
                this.licenseBtnClicked = false;
                if ( data.success == false ) {
					this.processNotification("licenseError");
                    this.licenseStatus = 'inactive';
                    this.hasError = true;
                    this.loading = false;
                    // Show why it failed (e.g. no activations left) under the field.
                    if ( data.data && data.data.licenseData && data.data.licenseData.errorMsg ) {
                        this.licenseErrorMsg = data.data.licenseData.errorMsg;
                    }
                    return;
                }
                if ( data.success == true ) {
                    let licenseData = data.data.licenseData;
                    this.licenseStatus = data.data.licenseStatus;
                    this.loading = false;
                    this.pressedBtnName = null;
					this.processNotification("licenseActivated");

                    // Remove the license notices
                    jQuery('#sby-license-inactive-agp').remove();
                    this.viewsActive.licenseLearnMore = false;

					jQuery('.cff_get_pro_highlight, .cff_get_sbr, .cff_get_sbi, .cff_get_yt, .cff_get_ctf').closest('li').remove();

                    if (
                        data.data.licenseStatus == 'inactive' ||
                        data.data.licenseStatus == 'invalid' ||
                        data.data.licenseStatus == 'expired'
                    ) {
                        this.hasError = true;
                        if( licenseData.error ) {
                            this.licenseErrorMsg = licenseData.errorMsg
                        }
                    }
                }
                return;
            });
        },
        deactivateLicense: function() {
            this.loading = true;
            this.pressedBtnName = 'cff';
            let data = new FormData();
            data.append( 'action', 'cff_deactivate_license' );
            data.append( 'nonce', this.nonce );
            fetch(this.ajaxHandler, {
                method: "POST",
                credentials: 'same-origin',
                body: data
            })
            .then(response => response.json())
            .then(data => {
                if ( data.success == true ) {
                    this.licenseStatus = data.data.licenseStatus ;
                    this.loading = false;
                    this.pressedBtnName = null;
                }
                return;
            });
        },

        /**
         * Activate Extensions License
         *
         * @since 4.0
         *
         * @param {object} extension
         */
        activateExtensionLicense: function( extension ) {
            let licenseKey = this.extensionsLicenseKey[extension.name];
            this.extensionFieldHasError = false;
            this.loading = true;
            this.pressedBtnName = extension.name;
            if ( ! licenseKey ) {
                this.loading = false;
                this.extensionFieldHasError = true;
                return;
            }
            let data = new FormData();
            data.append( 'action', 'cff_activate_extension_license' );
            data.append( 'license_key', licenseKey );
            data.append( 'extension_name', extension.name );
            data.append( 'extension_item_name', extension.itemName );
            data.append( 'nonce', this.nonce );
            fetch(this.ajaxHandler, {
                method: "POST",
                credentials: 'same-origin',
                body: data
            })
            .then(response => response.json())
            .then(data => {
                this.loading = false;
                if ( data.success == true ) {
                    this.extensionFieldHasError = false;
                    this.pressedBtnName = null;
                    if ( data.data.licenseStatus == 'invalid' ) {
                        this.extensionFieldHasError = true;
                        this.notificationElement =  {
                            type : 'error',
                            text : this.genericText.invalidLicenseKey,
                            shown : "shown"
                        };
                    }
                    if ( data.data.licenseStatus == 'valid' ) {
                        this.notificationElement =  {
                            type : 'success',
                            text : this.genericText.licenseActivated,
                            shown : "shown"
                        };
                    }
                    extension.licenseStatus = data.data.licenseStatus;
                    extension.licenseKey = licenseKey;

                    setTimeout(function(){
                        this.notificationElement.shown =  "hidden";
                    }.bind(this), 3000);
                }
                return;
            });
        },

        /**
         * Deactivate Extensions License
         *
         * @since 4.0
         *
         * @param {object} extension
         */
        deactivateExtensionLicense: function( extension ) {
            let licenseKey = this.extensionsLicenseKey[extension.name];
            this.extensionFieldHasError = false;
            this.loading = true;
            this.pressedBtnName = extension.name;
            let data = new FormData();
            data.append( 'action', 'cff_deactivate_extension_license' );
            data.append( 'extension_name', extension.name );
            data.append( 'extension_item_name', extension.itemName );
            data.append( 'nonce', this.nonce );
            fetch(this.ajaxHandler, {
                method: "POST",
                credentials: 'same-origin',
                body: data
            })
            .then(response => response.json())
            .then(data => {
                this.loading = false;
                if ( data.success == true ) {
                    this.extensionFieldHasError = false;
                    this.pressedBtnName = null;
                    if ( data.data.licenseStatus == 'deactivated' ) {
                        this.notificationElement =  {
                            type : 'success',
                            text : this.genericText.licenseDeactivated,
                            shown : "shown"
                        };
                    }
                    extension.licenseStatus = data.data.licenseStatus;
                    extension.licenseKey = licenseKey;

                    setTimeout(function(){
                        this.notificationElement.shown =  "hidden";
                    }.bind(this), 3000);
                }
                return;
            });
        },
        testConnection: function() {
            this.testConnectionStatus = 'loading';
            let data = new FormData();
            data.append( 'action', 'cff_test_connection' );
            data.append( 'nonce', this.nonce );
            fetch(this.ajaxHandler, {
                method: "POST",
                credentials: 'same-origin',
                body: data
            })
            .then(response => response.json())
            .then(data => {
                if ( data.success == false ) {
                    this.testConnectionStatus = 'error';
                }
                if ( data.success == true ) {
                    this.testConnectionStatus = 'success';

                    setTimeout(function() {
                        this.testConnectionStatus = null;
                    }.bind(this), 3000);
                }
                return;
            });
        },
        recheckLicense: function( licenseKey, itemName, optionName = null ) {
            this.recheckLicenseStatus = 'loading';
            this.pressedBtnName = optionName;
            let data = new FormData();
            data.append( 'action', 'cff_recheck_connection' );
            data.append( 'license_key', licenseKey );
            data.append( 'item_name', itemName );
            data.append( 'option_name', optionName );
            data.append( 'nonce', this.nonce );
            fetch(this.ajaxHandler, {
                method: "POST",
                credentials: 'same-origin',
                body: data
            })
            .then(response => response.json())
            .then(data => {
                if ( data.success == true ) {
                    if ( data.data.license == 'valid' ) {
                        this.recheckLicenseStatus = 'success';
                    }
                    if ( data.data.license == 'expired' ) {
                        this.recheckLicenseStatus = 'error';
                    }
                    if ( data.data.isLicenseUpgraded !== undefined && data.data.isLicenseUpgraded !== false ) {
                        this.isLicenseUpgraded = true;
                        this.licenseUpgradedInfo = data.data.licenseUpgradedInfo;
                        this.getUpgradedProTier()
                    }

                    // if the api license status has changed from old stored license status
                    // then reload the page to show proper error message and notices
                    // or hide error messages and notices
                    if ( data.data.licenseChanged == true ) {
                        location.reload();
                    }

                    setTimeout(function() {
                        this.pressedBtnName = null;
                        this.recheckLicenseStatus = null;
                    }.bind(this), 3000);
                }
                return;
            });
        },
        recheckLicenseIcon: function() {
            if ( this.recheckLicenseStatus == null ) {
                return this.generalTab.licenseBox.recheckLicense;
            } else if ( this.recheckLicenseStatus == 'loading' ) {
                return this.loaderSVG;
            } else if ( this.recheckLicenseStatus == 'success' ) {
                return '<i class="fa fa-check-circle"></i> ' + this.generalTab.licenseBox.licenseValid;
            } else if ( this.recheckLicenseStatus == 'error' ) {
                return '<i class="fa fa-times-circle"></i> ' + this.generalTab.licenseBox.licenseExpired;
            }
        },
        recheckBtnText: function( btnName ) {
            if ( this.recheckLicenseStatus == null || this.pressedBtnName != btnName ) {
                return this.generalTab.licenseBox.recheckLicense;
            } else if ( this.recheckLicenseStatus == 'loading' && this.pressedBtnName == btnName  ) {
                return this.loaderSVG;
            } else if ( this.recheckLicenseStatus == 'success' ) {
                return '<i class="fa fa-check-circle"></i> ' + this.generalTab.licenseBox.licenseValid;
            } else if ( this.recheckLicenseStatus == 'error' ) {
                return '<i class="fa fa-times-circle"></i> ' + this.generalTab.licenseBox.licenseExpired;
            }
        },
        testConnectionIcon: function() {
            if ( this.testConnectionStatus == 'loading' ) {
                return this.loaderSVG;
            } else if ( this.testConnectionStatus == 'success' ) {
                return '<i class="fa fa-check-circle"></i> ' + this.generalTab.licenseBox.connectionSuccessful;
            } else if ( this.testConnectionStatus == 'error' ) {
                return `<i class="fa fa-times-circle"></i> ${this.generalTab.licenseBox.connectionFailed} <a href="#">${this.generalTab.licenseBox.viewError}</a>`;
            }
        },
        importFile: function() {
            document.getElementById("import_file").click();
        },
        uploadFile: function( event ) {
            this.uploadStatus = 'loading';
            let file = this.$refs.file.files[0];
            let data = new FormData();
            data.append( 'action', 'cff_import_settings_json' );
            data.append( 'file', file );
            data.append( 'nonce', this.nonce );
            fetch(this.ajaxHandler, {
                method: "POST",
                credentials: 'same-origin',
                body: data
            })
            .then(response => response.json())
            .then(data => {
                this.uploadStatus = null;
                this.$refs.file.files[0] = null;
                if ( data.success == false ) {
                    this.notificationElement =  {
                        type : 'error',
                        text : this.genericText.failedToImportFeed,
                        shown : "shown"
                    };
                }
                if ( data.success == true ) {
                    this.feeds = data.data.feeds;
                    this.notificationElement =  {
                        type : 'success',
                        text : this.genericText.feedImported,
                        shown : "shown"
                    };
                }
                setTimeout(function(){
                    this.notificationElement.shown =  "hidden";
                }.bind(this), 3000);
            });
        },
        exportFeedSettings: function() {
            // return if no feed is selected
            if ( this.exportFeed === 'none' ) {
                return;
            }

            let url = this.ajaxHandler + '?action=cff_export_settings_json&feed_id=' + this.exportFeed + '&nonce=' + this.nonce;
            window.location = url;
        },
        eventsSyncAnyCalendar: function() {
            var targets = this.eventsSync.targets;
            return Object.keys( targets ).some( function( id ) {
                return targets[ id ].available;
            } );
        },
        eventsSyncHasTarget: function() {
            var targets = this.eventsSync.targets;
            var model = this.eventsSync.model.targets;
            return Object.keys( targets ).some( function( id ) {
                return targets[ id ].available && model[ id ];
            } );
        },
        eventsSyncToggleTarget: function( targetId ) {
            if ( ! this.eventsSync.targets[ targetId ] || ! this.eventsSync.targets[ targetId ].available ) {
                return;
            }
            this.eventsSync.model.targets[ targetId ] = ! this.eventsSync.model.targets[ targetId ];
        },
        eventsSyncSourceSelected: function( accountId ) {
            return this.eventsSync.model.sources.indexOf( accountId ) !== -1;
        },
        eventsSyncToggleSource: function( accountId ) {
            // Strict opt-in: only explicitly selected sources sync.
            var selection = this.eventsSync.model.sources;
            var index = selection.indexOf( accountId );
            if ( index !== -1 ) {
                selection.splice( index, 1 );
            } else {
                selection.push( accountId );
            }
        },
        // The notification element renders via v-html; escape remote strings.
        escapeHtml: function( text ) {
            var el = document.createElement( 'span' );
            el.textContent = String( text );
            return el.innerHTML;
        },
        saveEventsSyncSettings: function() {
            let data = new FormData();
            data.append( 'action', 'cff_events_sync_save' );
            data.append( 'model', JSON.stringify( this.eventsSync.model ) );
            data.append( 'nonce', this.nonce );
            return fetch(this.ajaxHandler, {
                method: "POST",
                credentials: 'same-origin',
                body: data
            })
            .then(response => response.json())
            .then(data => {
                // An expired nonce dies with "-1"; only success:true counts.
                if ( ! ( data && data.success === true ) ) {
                    throw new Error( 'events sync settings save failed' );
                }
                if ( data.data && data.data.nextRun ) {
                    this.eventsSync.nextRun = data.data.nextRun;
                }
            });
        },
        eventsSyncShowErrors: function( data ) {
            var errors = data && data.data && data.data.summary && data.data.summary.errors ? data.data.summary.errors : [];
            var message = data && data.data && data.data.message ? data.data.message : errors.join(' — ');
            this.notificationElement = {
                type: 'error',
                text: this.escapeHtml( message || this.eventsSync.genericText.syncFailed ),
                shown: 'shown'
            };
        },
        eventsSyncInstallSuggested: function() {
            if ( this.eventsSyncInstallStatus === 'loading' ) {
                return;
            }
            this.eventsSyncInstallStatus = 'loading';
            const data = new FormData();
            data.append( 'action', 'cff_install_addon' );
            data.append( 'nonce', this.nonce );
            data.append( 'plugin', this.eventsSync.suggestInstallUrl );
            data.append( 'type', 'plugin' );
            fetch(this.ajaxHandler, {
                method: "POST",
                credentials: 'same-origin',
                body: data
            })
            .then(response => response.json())
            .then(data => {
                if ( data?.success === true ) {
                    // The plugin was installed and activated in this request;
                    // flip the target availability so the cards render.
                    if ( this.eventsSync.targets.sugar_calendar ) {
                        this.eventsSync.targets.sugar_calendar.available = true;
                    }
                    this.eventsSyncInstallStatus = null;
                } else {
                    throw new Error( 'install failed' );
                }
            })
            .catch(() => {
                this.eventsSyncInstallStatus = null;
                this.notificationElement = {
                    type: 'error',
                    text: this.eventsSync.genericText.installFailed,
                    shown: 'shown'
                };
                setTimeout(function() {
                    this.notificationElement.shown = 'hidden';
                }.bind(this), 4000);
            });
        },
        eventsSyncNow: function() {
            this.eventsSyncNowStatus = 'loading';
            // Persist the current settings first so the run uses them.
            this.saveEventsSyncSettings().then(() => {
                let data = new FormData();
                data.append( 'action', 'cff_events_sync_now' );
                data.append( 'nonce', this.nonce );
                return fetch(this.ajaxHandler, {
                    method: "POST",
                    credentials: 'same-origin',
                    body: data
                });
            })
            .then(response => response.json())
            .then(data => {
                if ( data && data.data && data.data.log ) {
                    this.eventsSync.log = data.data.log;
                }
                if ( data && data.success === true ) {
                    this.eventsSyncNowStatus = 'success';
                    this.notificationElement = {
                        type: 'success',
                        text: data?.data?.summary?.scheduled_more
                            ? this.eventsSync.genericText.syncScheduled
                            : this.eventsSync.genericText.syncSuccess,
                        shown: 'shown'
                    };
                } else {
                    this.eventsSyncNowStatus = 'error';
                    this.eventsSyncShowErrors( data );
                }
            })
            .catch(() => {
                this.eventsSyncNowStatus = 'error';
                this.eventsSyncShowErrors( null );
            })
            .then(() => {
                setTimeout(function() {
                    this.eventsSyncNowStatus = null;
                    this.notificationElement.shown = 'hidden';
                }.bind(this), 4000);
            });
        },
        eventsSyncClearLog: function() {
            this.eventsSyncClearLogStatus = 'loading';
            let data = new FormData();
            data.append( 'action', 'cff_events_sync_clear_log' );
            data.append( 'nonce', this.nonce );
            fetch(this.ajaxHandler, {
                method: "POST",
                credentials: 'same-origin',
                body: data
            })
            .then(response => response.json())
            .then(data => {
                if ( data && data.success === true ) {
                    this.eventsSync.log = [];
                }
            })
            .catch(() => {})
            .then(() => {
                this.eventsSyncClearLogStatus = null;
            });
        },
        eventsSyncCleanup: function( targetId ) {
            this.eventsSyncCleanupTarget = targetId;
            var label = this.eventsSync.targets[ targetId ] ? this.eventsSync.targets[ targetId ].label : targetId;
            this.openDialogBox( 'eventsSyncCleanup', { label: label } );
        },
        eventsSyncDoCleanup: function() {
            var targetId = this.eventsSyncCleanupTarget;
            if ( ! targetId ) {
                return;
            }
            this.eventsSyncCleanupStatus = targetId;
            let data = new FormData();
            data.append( 'action', 'cff_events_sync_cleanup' );
            data.append( 'target', targetId );
            data.append( 'nonce', this.nonce );
            fetch(this.ajaxHandler, {
                method: "POST",
                credentials: 'same-origin',
                body: data
            })
            .then(response => response.json())
            .then(data => {
                if ( data && data.success === true ) {
                    this.notificationElement = {
                        type: 'success',
                        text: this.eventsSync.genericText.cleanupDone,
                        shown: 'shown'
                    };
                } else {
                    const message = data?.data?.message || this.eventsSync.genericText.cleanupFailed;
                    this.notificationElement = {
                        type: 'error',
                        text: this.escapeHtml( message ),
                        shown: 'shown'
                    };
                }
            })
            .catch(() => {
                this.notificationElement = {
                    type: 'error',
                    text: this.eventsSync.genericText.cleanupFailed,
                    shown: 'shown'
                };
            })
            .then(() => {
                this.eventsSyncCleanupStatus = null;
                this.eventsSyncCleanupTarget = null;
                setTimeout(function() {
                    this.notificationElement.shown = 'hidden';
                }.bind(this), 4000);
            });
        },
        saveSettings: function() {
            this.btnStatus = 'loading';
            this.pressedBtnName = 'saveChanges';

            var requests = [];

            // The events-sync endpoint rejects tiers below its license gate.
            if ( this.eventsSync && this.eventsSync.licenseAllows ) {
                requests.push( this.saveEventsSyncSettings() );
            }

            let data = new FormData();
            data.append( 'action', 'cff_save_settings' );
            data.append( 'model', JSON.stringify( this.model ) );
            data.append( 'cff_license_key', this.licenseKey );
            data.append( 'extensions_license_key', JSON.stringify( this.extensionsLicenseKey ) );
            data.append( 'nonce', this.nonce );
            requests.push(
                fetch(this.ajaxHandler, {
                    method: "POST",
                    credentials: 'same-origin',
                    body: data
                })
                .then(response => response.json())
                .then(data => {
                    if ( ! ( data && data.success === true ) ) {
                        throw new Error( 'settings save failed' );
                    }
                    this.cronNextCheck = data.data.cronNextCheck;
                })
            );

            // Report once after both saves finish; always re-enable the button.
            Promise.all( requests )
            .then(() => {
                this.btnStatus = 'success';
            })
            .catch(() => {
                this.btnStatus = 'error';
                if ( this.eventsSync ) {
                    this.notificationElement = {
                        type: 'error',
                        text: this.eventsSync.genericText.saveFailed,
                        shown: 'shown'
                    };
                }
            })
            .then(() => {
                setTimeout(function() {
                    this.btnStatus = null;
                    this.pressedBtnName = null;
                    this.notificationElement.shown = 'hidden';
                }.bind(this), 3000);
            });
        },
        clearCache: function() {
            this.clearCacheStatus = 'loading';
            let data = new FormData();
            data.append( 'action', 'cff_clear_cache' );
            data.append( 'model', JSON.stringify( this.model ) );
            data.append( 'nonce', this.nonce );
            fetch(this.ajaxHandler, {
                method: "POST",
                credentials: 'same-origin',
                body: data
            })
            .then(response => response.json())
            .then(data => {
                if ( data.success == false ) {
                    this.clearCacheStatus = 'error';
                    return;
                }

                this.cronNextCheck = data.data.cronNextCheck;
                this.clearCacheStatus = 'success';
                setTimeout(function() {
                    this.clearCacheStatus = null;
                }.bind(this), 3000);
            });
        },
        showTooltip: function( tooltipName ) {
            this.tooltipName = tooltipName;
        },
        hideTooltip: function() {
            this.tooltipName = null;
        },
        gdprOptions: function() {
            this.gdprInfoTooltip = null;
        },
        gdprLimited: function() {
            this.gdprInfoTooltip = this.gdprInfoTooltip == null ? true : null;
        },
        clearImageResizeCache: function() {
            this.optimizeCacheStatus = 'loading';
            let data = new FormData();
            data.append( 'action', 'cff_clear_image_resize_cache' );
            data.append( 'nonce', this.nonce );
            fetch(this.ajaxHandler, {
                method: "POST",
                credentials: 'same-origin',
                body: data
            })
            .then(response => response.json())
            .then(data => {
                if ( data.success == false ) {
                    this.optimizeCacheStatus = 'error';
                    return;
                }
                this.optimizeCacheStatus = 'success';
                setTimeout(function() {
                    this.optimizeCacheStatus = null;
                }.bind(this), 3000);
            });
        },
        resetErrorLog: function() {
            this.clearErrorLogStatus = 'loading';
            let data = new FormData();
            data.append( 'action', 'cff_clear_error_log' );
            data.append( 'nonce', this.nonce );
            fetch(this.ajaxHandler, {
                method: "POST",
                credentials: 'same-origin',
                body: data
            })
            .then(response => response.json())
            .then(data => {
                if ( ! data.success ) {
                    this.clearErrorLogStatus = 'error';
                    return;
                }
                this.clearErrorLogStatus = 'success';
                setTimeout(function() {
                    this.clearErrorLogStatus = null;
                }.bind(this), 3000);
            });
        },
        dpaReset: function() {
            this.dpaResetStatus = 'loading';
            let data = new FormData();
            data.append( 'action', 'cff_dpa_reset' );
            data.append( 'nonce', this.nonce );
            fetch(this.ajaxHandler, {
                method: "POST",
                credentials: 'same-origin',
                body: data
            })
                .then(response => response.json())
                .then(data => {
                    if ( data.success == false ) {
                        this.dpaResetStatus = 'error';
                        return;
                    }
                    this.dpaResetStatus = 'success';
                    setTimeout(function() {
                        this.dpaResetStatus = null;
                    }.bind(this), 3000);
                });
        },
         dpaResetStatusIcon: function() {
            if ( this.dpaResetStatus === null ) {
                return;
            }
            if ( this.dpaResetStatus == 'loading' ) {
                return this.loaderSVG;
            } else if ( this.dpaResetStatus == 'success' ) {
                return this.checkmarkSVG;
            } else if ( this.dpaResetStatus == 'error' ) {
                return `<i class="fa fa-times-circle"></i>`;
            }
        },
        saveChangesIcon: function() {
            if ( this.btnStatus == 'loading' ) {
                return this.loaderSVG;
            } else if ( this.btnStatus == 'success' ) {
                return this.checkmarkSVG;
            } else if ( this.btnStatus == 'error' ) {
                return `<i class="fa fa-times-circle"></i>`;
            }
        },
        importBtnIcon: function() {
            if ( this.uploadStatus === null ) {
                return this.uploadSVG;
            }
            if ( this.uploadStatus == 'loading' ) {
                return this.loaderSVG;
            } else if ( this.uploadStatus == 'success' ) {
                return this.checkmarkSVG;
            } else if ( this.uploadStatus == 'error' ) {
                return `<i class="fa fa-times-circle"></i>`;
            }
        },
        clearCacheIcon: function() {
            if ( this.clearCacheStatus === null ) {
                return this.reloadSVG;
            }
            if ( this.clearCacheStatus == 'loading' ) {
                return this.loaderSVG;
            } else if ( this.clearCacheStatus == 'success' ) {
                return this.checkmarkSVG;
            } else if ( this.clearCacheStatus == 'error' ) {
                return `<i class="fa fa-times-circle"></i>`;
            }
        },
        clearImageResizeCacheIcon: function() {
            if ( this.optimizeCacheStatus === null ) {
                return;
            }
            if ( this.optimizeCacheStatus == 'loading' ) {
                return this.loaderSVG;
            } else if ( this.optimizeCacheStatus == 'success' ) {
                return this.checkmarkSVG;
            } else if ( this.optimizeCacheStatus == 'error' ) {
                return `<i class="fa fa-times-circle"></i>`;
            }
        },
        resetErrorLogIcon: function() {
            if ( this.clearErrorLogStatus === null ) {
                return;
            }
            if ( this.clearErrorLogStatus == 'loading' ) {
                return this.loaderSVG;
            } else if ( this.clearErrorLogStatus == 'success' ) {
                return this.checkmarkSVG;
            } else if ( this.clearErrorLogStatus == 'error' ) {
                return `<i class="fa fa-times-circle"></i>`;
            }
        },

        printUsedInText: function( usedInNumber ){
            if(usedInNumber == 0){
                return this.genericText.sourceNotUsedYet;
            }
            return this.genericText.usedIn + ' ' + usedInNumber + ' ' +(usedInNumber == 1 ? this.genericText.feed : this.genericText.feeds);
        },

        /**
         * Delete Source Ajax
         *
         * @since 4.0
        */
        deleteSource : function(sourceToDelete){
            var self = this;
             let data = new FormData();
            data.append( 'action', 'cff_feed_saver_manager_delete_source' );
            data.append( 'source_id', sourceToDelete.id);
            data.append( 'nonce', this.nonce );
            fetch(self.ajaxHandler, {
                method: "POST",
                credentials: 'same-origin',
                body: data
            })
            .then(response => response.json())
            .then(data => {
                self.sourcesList = data;
            });
        },

        /**
         * Check if Value is Empty
         *
         * @since 4.0
         *
         * @return boolean
         */
        checkNotEmpty : function(value){
            return value != null && value.replace(/ /gi,'') != '';
        },

        /**
         * Activate View
         *
         * @since 4.0
        */
        activateView : function(viewName, sourcePopupType = 'creation', ajaxAction = false){
            var self = this;
            self.viewsActive[viewName] = (self.viewsActive[viewName] == false ) ? true : false;
             if(viewName == 'sourcePopup' && sourcePopupType == 'creationRedirect'){
                self.viewsActive.sourcePopupScreen = 'redirect_1';
                setTimeout(function(){
                    self.$refs.addSourceRef.processFBConnect()
                },3500);
            }
        },

        /**
         * Whether the current license tier includes events feeds
         *
         * @since 4.0
         *
         * @return boolean
         */
        hasEventsAccess : function(){
            return this.licenseTierFeatures.includes('events_feeds');
        },

        /**
         * Toggle The Add Source Kind Menu
         *
         * @since 4.0
         */
        toggleSourceKindMenu : function(){
            if( !this.hasEventsAccess() ){
                this.sourceKindMenuOpen = false;
                return;
            }
            this.sourceKindMenuOpen = !this.sourceKindMenuOpen;
        },

        /**
         * Close The Add Source Kind Menu And Restore Focus To Its Trigger
         *
         * a11y(2.4.3): the menu items are removed from the DOM when the menu
         * closes (v-if), so dismissing it while one of them holds focus would
         * drop focus to <body>. Send focus back to the caret that opened it.
         *
         * @since 4.0
         */
        closeSourceKindMenu : function(event){
            if( !this.sourceKindMenuOpen ){
                return;
            }
            this.sourceKindMenuOpen = false;

            var wrapper = event && event.currentTarget ? event.currentTarget : null,
                caret = wrapper ? wrapper.querySelector('.sb-srcs-new-caret') : null;
            if( caret ){
                this.$nextTick(function(){
                    caret.focus();
                });
            }
        },

        /**
         * Open The Add Source Popup For A Given Source Kind
         *
         * 'standard' keeps the one-click Facebook redirect the button has always
         * done. 'events' opens the app-credentials screen instead, since events
         * sources can only be connected through the user's own Facebook app.
         *
         * @since 4.0
         */
        openAddSource : function(kind){
            var self = this;
            self.sourceKindMenuOpen = false;

            var addNewSource = self.$refs.addSourceRef.addNewSource;
            addNewSource.kind = kind;
            addNewSource.typeSelected = 'page';

            if(kind != 'events'){
                self.activateView('sourcePopup', 'creationRedirect');
                return;
            }

            self.viewsActive.sourcePopupType = 'creation';
            self.viewsActive.sourcePopupScreen = 'step_1_event';
            self.viewsActive.sourcePopup = true;
        },

        /**
         * Switch & Change Feed Screens
         *
         * @since 4.0
         */
        switchScreen: function(screenType, screenName){
            this.viewsActive[screenType] = screenName;
        },

        /**
         * Parse JSON
         *
         * @since 4.0
         *
         * @return jsonObject / Boolean
         */
        jsonParse : function(jsonString){
            try {
                return JSON.parse(jsonString);
            } catch(e) {
                return false;
            }
        },


        /**
         * Ajax Post Action
         *
         * @since 4.0
         */
        ajaxPost : function(data, callback){
            var self = this;
            data['nonce'] = self.nonce;
            self.$http.post(self.ajaxHandler,data).then(callback);
        },

        /**
         * Check if Object has Nested Property
         *
         * @since 4.0
         *
         * @return boolean
         */
        hasOwnNestedProperty : function(obj,propertyPath) {
          if (!propertyPath){return false;}var properties = propertyPath.split('.');
          for (var i = 0; i < properties.length; i++) {
            var prop = properties[i];
            if (!obj || !obj.hasOwnProperty(prop)) {
              return false;
            } else {
              obj = obj[prop];
            }
          }
          return true;
        },

        /**
         * Show Tooltip on Hover
         *
         * @since 4.0
         */
        toggleElementTooltip : function(tooltipText, type, align = 'center'){
            var self = this,
                target = window.event.currentTarget,
                tooltip = (target != undefined && target != null) ? document.querySelector('.sb-control-elem-tltp-content') : null;
            if(tooltip != null && type == 'show'){
                self.tooltip.text = tooltipText;
                var position = target.getBoundingClientRect(),
                    left = position.left + 10,
                    top = position.top - 10;
                tooltip.style.left = left + 'px';
                tooltip.style.top = top + 'px';
                tooltip.style.textAlign = align;
                self.tooltip.hover = true;
            }
            if(type == 'hide'){
                self.tooltip.hover = false;
            }
        },

        /**
         * Hover Tooltip
         *
         * @since 4.0
         */
        hoverTooltip : function(type){
            this.tooltip.hover = type;
        },

        /**
         * Open Dialog Box
         *
         * @since 4.0
        */
        openDialogBox : function(type, args = []){
            var self = this,
                heading = self.dialogBoxPopupScreen[type].heading,
                description = self.dialogBoxPopupScreen[type].description;

            switch (type) {
                case "deleteSource":
                    self.sourceToDelete = args;
                    heading = heading.replace("#", self.sourceToDelete.username);
                break;
                case "eventsSyncCleanup":
                    heading = heading.replace("#", args.label);
                break;
            }
            self.dialogBox = {
                active : true,
                type : type,
                heading : heading,
                description : description
            };
        },


        /**
         * Confirm Dialog Box Actions
         *
         * @since 4.0
         */
        confirmDialogAction : function(){
            var self = this;
            switch (self.dialogBox.type) {
                case 'deleteSource':
                    self.deleteSource(self.sourceToDelete);
                    break;
                case 'eventsSyncCleanup':
                    self.dialogBox.active = false;
                    self.eventsSyncDoCleanup();
                    break;
            }
        },

        /**
         * Display Feed Sources Settings
         *
         * @since 4.0
         *
         * @param {object} source
         * @param {int} sourceIndex
         */
        displayFeedSettings: function(source, sourceIndex) {
            this.expandedFeedID = sourceIndex + 1;
        },

        /**
         * Hide Feed Sources Settings
         *
         * @since 4.0
         *
         * @param {object} source
         * @param {int} sourceIndex
         */
        hideFeedSettings: function() {
            this.expandedFeedID = null;
        },

		/**
		 * Copy text to clipboard
		 *
		 * @since 4.0
		 */
         copyToClipBoard : function(value){
			var self = this;
			const el = document.createElement('textarea');
			el.className = 'cff-fb-cp-clpboard';
			el.value = value;
			document.body.appendChild(el);
			el.select();
			document.execCommand('copy');
			document.body.removeChild(el);
			self.notificationElement =  {
				type : 'success',
				text : this.genericText.copiedClipboard,
				shown : "shown"
			};
			setTimeout(function(){
				self.notificationElement.shown =  "hidden";
			}, 3000);
		},

		/**
		 * Loading Bar & Notification
		 *
		 * @since 4.0
		 */
         processNotification : function( notificationType ){
			var self = this,
				notification = self.genericText.notification[ notificationType ];
			self.loadingBar = false;
			self.notificationElement =  {
				type : notification.type,
				text : notification.text,
				shown : "shown"
			};
			setTimeout(function(){
				self.notificationElement.shown =  "hidden";
			}, 5000);
		},

        /**
         * View Source Instances
         *
         * @since 4.0
         */
        viewSourceInstances : function(source){
            var self = this;
            self.viewsActive.instanceSourceActive = source;
            //self.movePopUp();
        },

        checkSourceiCalUrl : function( source ) {
			return true;
		},

        chooseAccountId : function( source_account_id, is_connect_page = false ) {
            let self = this;
			self.addIcalUrl.source_id = source_account_id;
			self.addIcalUrl.reconnectPage = is_connect_page;
			self.addIcalUrl.url = self.iCalURLs[source_account_id] !== undefined ? self.iCalURLs[source_account_id] : ''
            this.activateView('iCalUrlPopup')
            cffSettings.$forceUpdate();
		},

        connectEventiCalUrl : function() {
			let self = this;

			if( self.checkNotEmpty(self.addIcalUrl.url) && self.checkNotEmpty(self.addIcalUrl.source_id) ) {
				self.addIcalUrl.loadingAjax = true;
				self.addIcalUrl.isError = false;
				self.addIcalUrl.success = false;
                self.addIcalUrl.errorMessage = '';

                let data = new FormData();
                data.append( 'action', 'cff_feed_saver_manager_add_events_ical_url' );
                data.append( 'nonce', this.nonce );
                data.append( 'ical_url', self.addIcalUrl.url );
                data.append( 'source_id', self.addIcalUrl.source_id );

                if( self.addIcalUrl.reconnectPage === true && self.checkNotEmpty(self.addIcalUrl.pageToken) ){
                    data.append( 'reconnect_page', true );
                    data.append( 'access_token', self.addIcalUrl.pageToken );
                }


                fetch(this.ajaxHandler, {
                    method: "POST",
                    credentials: 'same-origin',
                    body: data
                })
                .then(response => response.json())
                .then(data => {
    				self.addIcalUrl.loadingAjax = false;
                    self.iCalURLs = data.data.ical_urls;

                    if(data?.data?.sourcesList){
                        self.sourcesList  = data.data.sourcesList;
                    }

                    if ( data.success === false ) {
                        self.addIcalUrl.isError = true;
                        self.addIcalUrl.errorMessage = data.data.message;
        				self.addIcalUrl.success = false;
                    }else{
                        self.addIcalUrl.errorMessage = '';
                        self.addIcalUrl.isError = false;
        				self.addIcalUrl.success = true;
                        setTimeout(function() {
                            self.addIcalUrl.errorMessage = '';
                            self.activateView('iCalUrlPopup')
                            self.addIcalUrl.isError = false;
        				    self.addIcalUrl.success = false;
                        }, 3000);
                    }
                    return;
                });

			}

		},

        /**
		 * Upgrade Pro/Pro License
		 *
		 * @since 6.2.0
		 */
        upgradeProProLicense : function(){
            var self = this;

            self.hasError = false;
            self.loading = true;
            self.pressedBtnName = 'cff-upgrade';
            self.licenseBtnClicked = true;
            self.upgradeNewVersion = false;
            self.upgradeNewVersionUrl = false;

            let data = new FormData();
            data.append( 'action', 'cff_maybe_upgrade_redirect' );
            data.append( 'license_key', self.licenseKey );
            data.append( 'nonce', self.nonce );
            fetch(self.ajaxHandler, {
                method: "POST",
                credentials: 'same-origin',
                body: data
            })
            .then(response => response.json())
            .then(data => {
                console.log(data)
                self.pressedBtnName = '';
                self.loading = false;
                self.licenseBtnClicked = false;

                if (data.success === false) {
                    self.licenseStatus = 'invalid';
                    self.hasError = true;

                    if (typeof data.data !== 'undefined') {
                        this.licenseErrorMsg = data.data.message
                    }
                    return;
                }
                if (data.success === true) {
                    if( data.data.same_version === true ){
                        window.location.href = data.data.url
                    }else{
                        self.upgradeNewVersion = true;
                        self.upgradeNewVersionUrl = data.data.url;
                        self.upgradeRemoteVersion  = data.data.remote_version;
                    }
                }
                return;
            });

        },

        cancelUpgrade : function(){
            this.upgradeNewVersion = false;
        },

        getUpgradedProTier : function(){
            if( this.licenseUpgradedInfo == undefined || this.licenseUpgradedInfo['item_name'] === undefined ){
                return false;
            }
            let licenseType = this.licenseUpgradedInfo['item_name'].toLowerCase(),
                removeString = [
                    'custom',
                    'facebook',
                    'plugin',
                    'wordpress',
                    'feeds',
                    'feed',
                    'pro',
                    ' '
                ];
                removeString.forEach(str => {
                    licenseType = licenseType.replace(str, '')
                });
            this.licenseUpgradedInfoTierName = licenseType;
        },

        /**
         * The AI Agents card's current display state.
         *
         * Mirrors the WPVibe install/activation status from PHP, except a
         * failed install/activate attempt takes over the display until the
         * user retries.
         *
         * @since 4.12
         *
         * @return string 'not_installed' | 'inactive' | 'active' | 'installFailed'
         */
        aiAgentsState: function () {
            if (this.wpvibeInstallStatus === 'failed') {
                return 'installFailed';
            }
            return this.generalTab.aiAgents.status;
        },

        /**
         * Open WPVibe's own admin page.
         *
         * @since 4.12
         */
        openWPVibe: function () {
            window.location.href = this.generalTab.aiAgents.adminUrl;
        },

        /**
         * Install or activate WPVibe for the AI Agents card.
         *
         * Reuses the existing cff_install_addon / cff_activate_addon AJAX
         * actions -- no new installer, capability, or nonce is introduced.
         *
         * @since 4.12
         */
        installOrActivateWPVibe: function () {
            let self = this,
                aiAgents = self.generalTab.aiAgents,
                isInstalled = aiAgents.status !== 'not_installed',
                action = isInstalled ? 'cff_activate_addon' : 'cff_install_addon',
                pluginParam = isInstalled ? aiAgents.basename : aiAgents.installDownloadUrl;

            self.wpvibeInstallStatus = 'loading';

            let data = new FormData();
            data.append('action', action);
            data.append('nonce', self.nonce);
            data.append('type', 'plugin');
            data.append('plugin', pluginParam);
            fetch(self.ajaxHandler, {
                method: "POST",
                credentials: 'same-origin',
                body: data
            })
                .then(response => response.json())
                .then(function (response) {
                    if (response.success !== true) {
                        self.wpvibeInstallStatus = 'failed';
                        return;
                    }

                    self.wpvibeInstallStatus = null;

                    if (action === 'cff_install_addon') {
                        if (response.data && response.data.basename) {
                            aiAgents.basename = response.data.basename;
                        }
                        aiAgents.status = (response.data && response.data.is_activated) ? 'active' : 'inactive';
                        return;
                    }

                    aiAgents.status = 'active';
                })
                .catch(function () {
                    self.wpvibeInstallStatus = 'failed';
                });
        },

    }
});

