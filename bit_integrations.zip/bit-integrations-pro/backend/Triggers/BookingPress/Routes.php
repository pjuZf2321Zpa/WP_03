<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Core\Util\Route;
use BitApps\IntegrationsPro\Triggers\BookingPress\BookingPressController;

Route::get('booking_press/get', [BookingPressController::class, 'getAllTasks']);
