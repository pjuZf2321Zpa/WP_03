<?php

defined('ABSPATH') || exit;

/**
 * Resolves the per-signup application-fee percent from the stripe-connect /fee
 * endpoint with a 24-hour transient cache and fail-open behavior.
 *
 * Sole entry point for plugin-side fee lookups during checkout. The service
 * issues a JWT-authed POST to MEPR_STRIPE_SERVICE_URL./api/memberpress/fee on a
 * cache miss, caches the resulting fee set in a per-gateway WordPress
 * transient for DAY_IN_SECONDS, and returns 0.0 on any non-200 / malformed /
 * transport-error path. The merchant is identified server-side by the
 * site_uuid alone; the license key, site domain, and the build's edition/version
 * diagnostics travel in the body and are never policy input.
 *
 * Before the call, a gateway that is not Stripe Connect (application fees
 * only exist on Connect requests) or a connected account in an excluded
 * market (see UNSUPPORTED_COUNTRIES) short-circuits to 0.0 with no HTTP
 * request.
 *
 * A successful 200 with a zero percent shares the 24-hour TTL with positive
 * responses: zero is the legitimate steady-state for unlicensed and lapsed
 * sites, and short-caching it would hammer /fee on every checkout for those
 * sites. The accepted trade-off is that a spurious upstream zero (e.g. a stale
 * read during a deploy) pins zero for up to a day before the next fetch.
 *
 * License-state changes do not wait out the TTL: the DRM license handlers
 * call clear_cache(), so the long TTL only delays inputs the plugin cannot
 * observe locally (server-side overrides and connector-chain license state).
 *
 * Fail-open paths cache 0.0 for a short window (2 minutes) on transient errors
 * (transport, 5xx, malformed body) so a service hiccup does not produce a
 * checkout-by-checkout hammer. A 4xx response indicates a persistent config
 * error that won't self-heal, so the cache is extended (15 minutes) to avoid
 * burning the endpoint with the same broken request until the config is fixed.
 *
 * Staging, development and local sites ask /fee like any other site. The
 * body carries the gateway's payment mode as `livemode`, false only when the
 * gateway is in Stripe test mode, so the server can tell test-mode lookups
 * from live ones.
 *
 * The /fee response also carries a `metadata` set describing how the server
 * evaluated the fee. The plugin only relays it, whatever keys it holds: nothing
 * is derived locally, it shares the percent's transient and TTL, and a
 * missing or malformed set never affects the percent. fetch_fee() returns
 * both so the gateway can merge the set into each Stripe object that carries
 * a fee.
 */
class MeprStripeFeeService
{
    /**
     * ISO 3166-1 alpha-2 codes for the markets excluded from the application-fee program.
     *
     * Connected accounts in these countries are zeroed plugin-side before the
     * /fee call is issued. The list is a product decision, not a calculator
     * detail, and is intentionally hardcoded here rather than fetched.
     *
     * @var string[]
     */
    private const UNSUPPORTED_COUNTRIES = ['BR', 'IN', 'MX', 'MY', 'SG', 'TH'];

    /**
     * Transient key prefix for the cached fee set; the gateway id is appended.
     *
     * The key is scoped per payment method because the server's answer is per
     * (site, connected account): two Connect gateways on one site can point at
     * different Stripe accounts with different license states, so a shared
     * value would stamp one account's percent on the other's checkouts. The
     * 24-hour TTL alone governs freshness.
     *
     * The cached value is a {percent, metadata} set, kept apart from
     * LEGACY_CACHE_KEY_PREFIX, where builds that cache a bare percent read
     * their value as a number: PHP casts an array to 1.0, so such a build
     * reading this set would take a 1% fee.
     *
     * @var string
     */
    private const CACHE_KEY_PREFIX = 'mepr_stripe_fee_v2_';

    /**
     * The transient key prefix used by builds that cache a bare percent;
     * cleared with the current prefix so a license change reaches those
     * entries too.
     *
     * @var string
     */
    private const LEGACY_CACHE_KEY_PREFIX = 'mepr_stripe_fee_';

    /**
     * Stripe's maximum length for a metadata key.
     *
     * @var integer
     */
    private const METADATA_KEY_MAX_LENGTH = 40;

    /**
     * Stripe's maximum length for a metadata value.
     *
     * @var integer
     */
    private const METADATA_VALUE_MAX_LENGTH = 500;

    /**
     * Resolves the application-fee percent for a connected Stripe payment method.
     *
     * Returns the cached percent on hit, performs a JIT POST to /fee on miss,
     * and returns 0.0 on any failure (transport error, non-200, malformed or
     * out-of-range body, missing site_uuid / gateway_id, a gateway that is
     * not Stripe Connect, or an unsupported-market account). The percent is
     * rounded to 2 decimal places before caching and returning. Callers can
     * then stamp it directly on Stripe's `application_fee_percent` field,
     * which accepts at most 2dp, and the one-time `application_fee_amount`
     * math stays symmetric with the subscription path.
     *
     * @param string $gateway_id The plugin-side gateway integration ID (site_payment_method_id on the server's Connection row).
     *
     * @return float The fee percent rounded to 2 decimal places (0.0 on any failure or short-circuit).
     */
    public function fetch_percent(string $gateway_id): float
    {
        return $this->fetch_fee($gateway_id)['percent'];
    }

    /**
     * Resolves the application-fee percent and its relayed fee metadata.
     *
     * Follows the same cache, short-circuit and fail-open rules as
     * fetch_percent(). The metadata is the server's evaluation record, with
     * whatever keys the server chose, and is empty whenever the percent was
     * not resolved by a successful /fee response carrying a valid set.
     *
     * @param string $gateway_id The plugin-side gateway integration ID (site_payment_method_id on the server's Connection row).
     *
     * @return array{percent: float, metadata: array<string, string>}
     */
    public function fetch_fee(string $gateway_id): array
    {
        $site_uuid = (string) get_option('mepr_authenticator_site_uuid');

        // The site_uuid is the server's sole identification handle (carried in
        // the JWT payload), and gateway_id drives the connected-account country
        // pre-check below; both are required. The mothership license key is not
        // a gate — identification is by site_uuid, so an unlicensed but
        // identifiable site still resolves a fee.
        if ('' === $site_uuid || '' === $gateway_id) {
            return self::fee_result(0.0);
        }

        // Application fees only exist on Stripe Connect requests: stamping
        // application_fee_* on a gateway that authenticates with its own API
        // keys makes Stripe reject the request outright, blocking the
        // checkout. The guard sits before the cache read so a gateway that is
        // no longer connected can never serve a percent cached while it was.
        if ('connected' !== MeprStripeGateway::stripe_connect_status($gateway_id)) {
            return self::fee_result(0.0);
        }

        $key    = self::CACHE_KEY_PREFIX . $gateway_id;
        $cached = get_transient($key);
        if (false !== $cached) {
            return self::cached_fee_result($cached);
        }

        // The fee program excludes connected accounts in certain markets, so
        // the plugin short-circuits here before issuing the call. The check
        // runs only on a cache miss: a Stripe account's country is immutable,
        // so a cached percent was already vetted at fetch time, and skipping
        // the check on hits avoids a live Stripe account lookup on every
        // checkout when the country is not stored locally. The result is not
        // cached here because nothing was fetched.
        if ($this->is_unsupported_country($gateway_id)) {
            return self::fee_result(0.0);
        }

        $mepr_options = MeprOptions::fetch();
        $license_key  = $mepr_options->mothership_license;
        $site_domain  = MeprUtils::site_domain();
        $gateway      = $mepr_options->payment_method($gateway_id);

        // The server counts only a JSON false as test mode. The test-mode
        // filter may return any value, which the logical operators reduce to
        // a strict boolean by its truthiness, and a gateway that cannot be
        // built is reported as live.
        $livemode = !($gateway instanceof MeprStripeGateway && $gateway->is_test_mode());

        $jwt = MeprAuthenticatorCtrl::generate_jwt(['site_uuid' => $site_uuid]);

        // The gateway_id is the connected payment method; it travels in the URL path so the service
        // resolves the specific connection (scoped to the JWT site_uuid). The body is diagnostic, except
        // livemode, which decides whether the server records the decision for the support sheet.
        $url = MEPR_STRIPE_SERVICE_URL . '/api/memberpress/fee/' . rawurlencode($gateway_id);

        $response = wp_remote_post($url, [
            'timeout' => 5,
            'headers' => MeprUtils::jwt_header($jwt, MEPR_STRIPE_SERVICE_DOMAIN),
            'body'    => wp_json_encode([
                'license_key'    => $license_key,
                'site_domain'    => $site_domain,
                'plugin_edition' => MEPR_EDITION,
                'plugin_version' => MEPR_VERSION,
                'wp_version'     => get_bloginfo('version'),
                'livemode'       => $livemode,
            ]),
        ]);

        if (is_wp_error($response)) {
            MeprUtils::debug_log('mepr_stripe_fee: HTTP transport error: ' . $response->get_error_message());
            $this->cache_failure($key);
            return self::fee_result(0.0);
        }

        $code = (int) wp_remote_retrieve_response_code($response);
        if (200 !== $code) {
            if ($code >= 400 && $code < 500) {
                MeprUtils::debug_log('mepr_stripe_fee: config error (HTTP ' . $code . ').');
            } else {
                MeprUtils::debug_log('mepr_stripe_fee: non-200 response (' . $code . ').');
            }
            $this->cache_failure($key, $code);
            return self::fee_result(0.0);
        }

        $body = json_decode(wp_remote_retrieve_body($response), true);
        if (!is_array($body) || !isset($body['percent']) || !is_numeric($body['percent'])) {
            MeprUtils::debug_log('mepr_stripe_fee: malformed response body.');
            $this->cache_failure($key);
            return self::fee_result(0.0);
        }

        $percent = round((float) $body['percent'], 2);

        // Stripe rejects application_fee_percent outside [0, 100], so an
        // out-of-range value (a server-side config typo) would hard-block
        // every checkout if stamped. Treat it as malformed and fail open.
        if ($percent < 0.0 || $percent > 100.0) {
            MeprUtils::debug_log('mepr_stripe_fee: out-of-range percent (' . $percent . ').');
            $this->cache_failure($key);
            return self::fee_result(0.0);
        }

        $fee = self::fee_result($percent, self::sanitize_metadata($body['metadata'] ?? null));

        set_transient($key, $fee, DAY_IN_SECONDS);

        return $fee;
    }

    /**
     * Deletes every per-gateway cached fee percent.
     *
     * Called when the license state changes: the server resolves the percent
     * from the license, so a value cached under the previous state — e.g. the
     * unlicensed rate after the customer just activated a license — must not
     * be served for up to another day. The next checkout re-fetches.
     *
     * @return void
     */
    public static function clear_cache(): void
    {
        $mepr_options = MeprOptions::fetch();

        foreach ((array) $mepr_options->integrations as $gateway_id => $integration) {
            if ('MeprStripeGateway' === ($integration['gateway'] ?? '')) {
                delete_transient(self::CACHE_KEY_PREFIX . $gateway_id);
                delete_transient(self::LEGACY_CACHE_KEY_PREFIX . $gateway_id);
            }
        }
    }

    /**
     * Caches the fail-open 0.0 result so a service outage does not produce a
     * checkout-by-checkout hammer.
     *
     * On a 4xx the cache is extended to 15 minutes because the failure is a
     * persistent config error (wrong site_uuid, missing connection, host
     * mismatch, etc.) that retrying at the 2-minute transient cadence would
     * just hammer with the same broken request. Other failures (transport,
     * 5xx, malformed body) stay at 2 minutes since they're typically transient.
     *
     * @param string  $key  The transient key.
     * @param integer $code The HTTP status from the upstream response, or 0
     *                      for non-HTTP failures (transport, malformed body).
     *
     * @return void
     */
    private function cache_failure(string $key, int $code = 0): void
    {
        $ttl = ($code >= 400 && $code < 500) ? 15 * MINUTE_IN_SECONDS : 2 * MINUTE_IN_SECONDS;
        set_transient($key, self::fee_result(0.0), $ttl);
    }

    /**
     * Builds the fee result shape returned by fetch_fee() and stored in the cache.
     *
     * @param float                 $percent  The fee percent.
     * @param array<string, string> $metadata The relayed fee metadata.
     *
     * @return array{percent: float, metadata: array<string, string>}
     */
    private static function fee_result(float $percent, array $metadata = []): array
    {
        return [
            'percent'  => $percent,
            'metadata' => $metadata,
        ];
    }

    /**
     * Rebuilds a fee result from a cached transient value.
     *
     * A value that is not a set with a numeric percent, or whose percent
     * falls outside [0, 100] once rounded to two places, fails open to 0.0,
     * as a fetched percent does. The cached metadata is filtered again as it
     * is read.
     *
     * @param mixed $cached The cached transient value.
     *
     * @return array{percent: float, metadata: array<string, string>}
     */
    private static function cached_fee_result($cached): array
    {
        if (!is_array($cached) || !isset($cached['percent']) || !is_numeric($cached['percent'])) {
            return self::fee_result(0.0);
        }

        $percent = round((float) $cached['percent'], 2);

        if ($percent < 0.0 || $percent > 100.0) {
            return self::fee_result(0.0);
        }

        return self::fee_result($percent, self::sanitize_metadata($cached['metadata'] ?? null));
    }

    /**
     * Filters a raw fee metadata set down to the entries Stripe accepts.
     *
     * The server names the keys; the plugin keeps every one Stripe would
     * accept. An entry is omitted whole, rather than truncated, when its key
     * is empty, longer than Stripe allows, contains a square bracket, or is
     * numeric (PHP turns a numeric key into an integer), or when its value
     * is empty, not a string or number, or longer than Stripe accepts. So a
     * malformed entry can never block the Stripe request or be written
     * partially. Lengths are counted in bytes, which is never fewer than
     * Stripe's count of characters.
     *
     * @param mixed $raw The metadata set from the /fee response or the cache.
     *
     * @return array<string, string>
     */
    private static function sanitize_metadata($raw): array
    {
        if (!is_array($raw)) {
            return [];
        }

        $metadata = [];

        foreach ($raw as $meta_key => $value) {
            if (
                !is_string($meta_key)
                || '' === $meta_key
                || strlen($meta_key) > self::METADATA_KEY_MAX_LENGTH
                || strpbrk($meta_key, '[]') !== false
            ) {
                continue;
            }

            if (!is_string($value) && !is_int($value) && !is_float($value)) {
                continue;
            }

            $value = (string) $value;

            if ('' === $value || strlen($value) > self::METADATA_VALUE_MAX_LENGTH) {
                continue;
            }

            $metadata[$meta_key] = $value;
        }

        return $metadata;
    }

    /**
     * Returns true when the connected account's country is excluded from the fee program.
     *
     * The country is resolved from the connected Stripe account behind the
     * gateway and matched (case-insensitively) against the excluded-market list.
     * The check is fail-open: an unknown or unresolved country proceeds to the
     * fee call rather than zeroing a potentially valid merchant.
     *
     * @param string $gateway_id The plugin-side gateway integration ID.
     *
     * @return boolean
     */
    private function is_unsupported_country(string $gateway_id): bool
    {
        $country = MeprStripeGateway::get_account_country($gateway_id);

        if (!is_string($country) || '' === $country) {
            return false;
        }

        return in_array(strtoupper($country), self::UNSUPPORTED_COUNTRIES, true);
    }
}
