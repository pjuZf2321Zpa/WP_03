<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Core\Util\Route;
use BitApps\IntegrationsPro\Triggers\CalculatedFieldsForm\CalculatedFieldsFormController;

Route::get('cpcff/get', [CalculatedFieldsFormController::class, 'getAllTasks']);
