<?php

namespace BitApps\IntegrationsPro\Triggers\Booknetic;

use BitApps\IntegrationsPro\Config;

final class BookneticController
{
    private const STATUS_CHANGED = 'booknetic_appointment_status_changed';

    private const RESCHEDULED = 'booknetic_appointment_rescheduled';

    private const SCHEDULE_FIELDS = ['starts_at', 'location_id', 'service_id', 'staff_id'];

    private static $appointmentsBeforeMutation = [];

    private static $customersBeingEdited = [];

    private static $createdStaffIds = [];

    private static $runningEntities = [];

    public static function info()
    {
        return [
            'name'              => 'Booknetic',
            'title'             => __('Booknetic', 'bit-integrations-pro'),
            'type'              => 'custom_form_submission',
            'is_active'         => BookneticHelper::isPluginInstalled(),
            'tutorial_url'      => '#',
            'tasks'             => [
                'action' => 'booknetic/get',
                'method' => 'get',
            ],
            'fetch' => [
                'action' => 'trigger/test',
                'method' => 'post',
            ],
            'fetch_remove' => [
                'action' => 'trigger/test/remove',
                'method' => 'post',
            ],
            'isPro' => true
        ];
    }

    public function getAllTasks()
    {
        if (!BookneticHelper::isPluginInstalled()) {
            // translators: %s: plugin name
            wp_send_json_error(\sprintf(__('%s is not installed or activated', 'bit-integrations-pro'), 'Booknetic'));
        }

        wp_send_json_success([
            ['form_name' => __('Appointment Created', 'bit-integrations-pro'), 'triggered_entity_id' => 'bkntc_appointment_created', 'skipPrimaryKey' => true, 'note' => __('Runs when a new appointment is created.', 'bit-integrations-pro')],
            ['form_name' => __('Appointment Updated', 'bit-integrations-pro'), 'triggered_entity_id' => 'bkntc_appointment_after_edit', 'skipPrimaryKey' => true, 'note' => __('Runs when an admin edits an appointment.', 'bit-integrations-pro')],
            ['form_name' => __('Appointment Deleted', 'bit-integrations-pro'), 'triggered_entity_id' => 'bkntc_appointment_deleted', 'skipPrimaryKey' => true, 'note' => __('Runs when an appointment is deleted.', 'bit-integrations-pro')],
            ['form_name' => __('Appointment Status Changed', 'bit-integrations-pro'), 'triggered_entity_id' => self::STATUS_CHANGED, 'skipPrimaryKey' => true, 'note' => __('Runs when the status of an appointment changes.', 'bit-integrations-pro')],
            ['form_name' => __('Appointment Rescheduled', 'bit-integrations-pro'), 'triggered_entity_id' => self::RESCHEDULED, 'skipPrimaryKey' => true, 'note' => __('Runs when the time, location, service or staff of an appointment changes.', 'bit-integrations-pro')],
            ['form_name' => __('Customer Created', 'bit-integrations-pro'), 'triggered_entity_id' => 'bkntc_customer_created', 'skipPrimaryKey' => true, 'note' => __('Runs when a new customer is created.', 'bit-integrations-pro')],
            ['form_name' => __('Customer Updated', 'bit-integrations-pro'), 'triggered_entity_id' => 'bkntc_customer_saved', 'skipPrimaryKey' => true, 'note' => __('Runs when an existing customer is edited.', 'bit-integrations-pro')],
            ['form_name' => __('Customer Deleted', 'bit-integrations-pro'), 'triggered_entity_id' => 'bkntc_customer_deleted', 'skipPrimaryKey' => true, 'note' => __('Runs when a customer is deleted.', 'bit-integrations-pro')],
            ['form_name' => __('Staff Created', 'bit-integrations-pro'), 'triggered_entity_id' => 'bkntc_staff_created', 'skipPrimaryKey' => true, 'note' => __('Runs when a new staff member is created.', 'bit-integrations-pro')],
            ['form_name' => __('Staff Updated', 'bit-integrations-pro'), 'triggered_entity_id' => 'bkntc_after_request_staff_save_staff', 'skipPrimaryKey' => true, 'note' => __('Runs when an admin edits a staff member.', 'bit-integrations-pro')],
        ]);
    }

    public static function handleAppointmentCreated($appointment)
    {
        return static::flowExecute('bkntc_appointment_created', BookneticHelper::getAppointmentData($appointment));
    }

    public static function handleAppointmentUpdated($appointment)
    {
        return static::flowExecute('bkntc_appointment_after_edit', BookneticHelper::getAppointmentData($appointment));
    }

    public static function handleAppointmentDeleted($appointmentId)
    {
        return static::flowExecute('bkntc_appointment_deleted', BookneticHelper::getAppointmentData($appointmentId));
    }

    public static function captureAppointmentBeforeMutation($appointmentId)
    {
        $appointmentId = (int) $appointmentId;

        if ($appointmentId > 0) {
            self::$appointmentsBeforeMutation[$appointmentId] = BookneticHelper::getAppointmentData($appointmentId);
        }
    }

    public static function handleAppointmentMutation($appointmentId)
    {
        $appointmentId = (int) $appointmentId;

        if ($appointmentId <= 0) {
            self::$appointmentsBeforeMutation = [];

            return;
        }

        if (empty(self::$appointmentsBeforeMutation[$appointmentId])) {
            return;
        }

        $before = self::$appointmentsBeforeMutation[$appointmentId];
        unset(self::$appointmentsBeforeMutation[$appointmentId]);

        $after = BookneticHelper::getAppointmentData($appointmentId);

        if (empty($after)) {
            return;
        }

        if (($before['status'] ?? null) !== ($after['status'] ?? null)) {
            static::flowExecute(
                self::STATUS_CHANGED,
                [
                    'appointment'     => $after,
                    'previous_status' => $before['status'] ?? null,
                    'current_status'  => $after['status'] ?? null,
                ]
            );
        }

        foreach (self::SCHEDULE_FIELDS as $field) {
            if (($before[$field] ?? null) !== ($after[$field] ?? null)) {
                static::flowExecute(
                    self::RESCHEDULED,
                    [
                        'appointment'          => $after,
                        'previous_appointment' => $before,
                    ]
                );

                break;
            }
        }
    }

    public static function handleCustomerCreated($customerId)
    {
        return static::flowExecute('bkntc_customer_created', BookneticHelper::getCustomerData($customerId));
    }

    public static function captureCustomerBeforeEdit($customerId)
    {
        $customerId = (int) $customerId;

        if ($customerId > 0) {
            self::$customersBeingEdited[$customerId] = true;
        }
    }

    public static function handleCustomerSaved($customerId)
    {
        $customerId = (int) $customerId;

        if (empty(self::$customersBeingEdited[$customerId])) {
            return;
        }

        unset(self::$customersBeingEdited[$customerId]);

        return static::flowExecute('bkntc_customer_saved', BookneticHelper::getCustomerData($customerId));
    }

    public static function handleCustomerDeleted($customerId)
    {
        return static::flowExecute('bkntc_customer_deleted', BookneticHelper::getCustomerData($customerId));
    }

    public static function handleStaffCreated($staffId)
    {
        self::$createdStaffIds[(int) $staffId] = true;

        return static::flowExecute('bkntc_staff_created', BookneticHelper::getStaffData($staffId));
    }

    public static function handleStaffUpdated($data)
    {
        if (!\is_array($data) || empty($data['is_edit']) || empty($data['staff_id'])) {
            return;
        }

        // Booknetic computes is_edit after the insert sets the new id, so a create also reports is_edit true.
        if (isset(self::$createdStaffIds[(int) $data['staff_id']])) {
            return;
        }

        return static::flowExecute('bkntc_after_request_staff_save_staff', BookneticHelper::getStaffData($data['staff_id']));
    }

    private static function flowExecute($triggered_entity_id, $data)
    {
        if (empty($data) || !\is_array($data)) {
            return;
        }

        $helperClass = bit_integrations_get_class('Core\\Util\\Helper');
        $flowClass = bit_integrations_get_class('Flow\\Flow');

        $formData = $helperClass::prepareFetchFormatFields($data);

        if (empty($formData) || !\is_array($formData)) {
            return;
        }

        $helperClass::setTestData(Config::withFreePrefix("{$triggered_entity_id}_test"), array_values($formData));

        if (isset(self::$runningEntities[$triggered_entity_id])) {
            return;
        }

        $flows = $flowClass::exists('Booknetic', $triggered_entity_id);

        if (empty($flows)) {
            return;
        }

        self::$runningEntities[$triggered_entity_id] = true;

        try {
            $flowClass::execute('Booknetic', $triggered_entity_id, array_column($formData, 'value', 'name'), $flows);
        } finally {
            unset(self::$runningEntities[$triggered_entity_id]);
        }

        return ['type' => 'success'];
    }
}
