<?php

namespace WPAICG\Lib\Chat\Frontend\Ajax\Utils;

use WPAICG\Vector\AIPKit_Vector_Store_Manager;
use WPAICG\Vector\AIPKit_Vector_Store_Registry;
use WPAICG\AIPKit_Providers;
use WPAICG\Utils\AIPKit_Identifier_Utils;
use WPAICG\Vector\AIPKit_Vector_Provider_Strategy_Factory;
use WPAICG\Includes\AIPKit_Upload_Utils;
use WP_Error;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * ChatUploadConfigLoader
 *
 * Ensures necessary global dependencies are loaded and provides access to them.
 */
class ChatUploadConfigLoader
{
    private $vector_store_manager;
    private $providers_helper;
    private $wpdb;
    private $data_source_table_name;

    public function __construct()
    {
        global $wpdb;
        $this->wpdb = $wpdb;
        $this->data_source_table_name = $wpdb->prefix . 'aipkit_vector_data_source';

        // Ensure dependencies are loaded (these should typically be loaded by the main plugin)
        $dependencies = [
            AIPKit_Vector_Store_Manager::class => WPAICG_PLUGIN_DIR . 'classes/knowledge-base/manager.php',
            AIPKit_Vector_Store_Registry::class => WPAICG_PLUGIN_DIR . 'classes/knowledge-base/stores.php',
            AIPKit_Providers::class => WPAICG_PLUGIN_DIR . 'classes/ai/settings.php',
            AIPKit_Identifier_Utils::class => WPAICG_LIB_DIR . 'knowledge-base/upload-context.php',
            AIPKit_Vector_Provider_Strategy_Factory::class => WPAICG_PLUGIN_DIR . 'classes/knowledge-base/provider-contracts.php',
        ];

        foreach ($dependencies as $class => $path) {
            if (!class_exists($class) && file_exists($path)) {
                require_once $path;
            }
        }

        if (class_exists(AIPKit_Vector_Store_Manager::class)) {
            $this->vector_store_manager = new AIPKit_Vector_Store_Manager();
        }
        if (class_exists(AIPKit_Providers::class)) {
            $this->providers_helper = new AIPKit_Providers();
        } // Instance not strictly needed for static methods
    }

    public function get_vector_store_manager(): ?AIPKit_Vector_Store_Manager
    {
        return $this->vector_store_manager;
    }
    public function get_providers_helper(): ?AIPKit_Providers
    {
        return $this->providers_helper;
    } // Returns instance, but static methods are used
    public function get_wpdb(): \wpdb
    {
        return $this->wpdb;
    }
    public function get_data_source_table_name(): string
    {
        return $this->data_source_table_name;
    }
}

/**
 * ChatUploadLogger
 *
 * Handles logging file upload events to the aipkit_vector_data_source table.
 */
class ChatUploadLogger
{
    private $wpdb;
    private $data_source_table_name;

    public function __construct(\wpdb $wpdb, string $data_source_table_name)
    {
        $this->wpdb = $wpdb;
        $this->data_source_table_name = $data_source_table_name;
    }

    /**
     * Logs an entry for vector store related events.
     *
     * @param array $log_data Data for the log entry.
     *                        Expected keys: 'provider', 'vector_store_id', 'status', 'message'.
     *                        Optional: 'user_id', 'vector_store_name', 'file_id', 'source_type_for_log', etc.
     */
    public function log_event(array $log_data): void
    {
        $defaults = [
            'user_id'             => get_current_user_id(),
            'timestamp'           => current_time('mysql', 1),
            'provider'            => 'UnknownProvider',
            'vector_store_id'     => 'unknown_store',
            'vector_store_name'   => null,
            'post_id'             => null,
            'post_title'          => null,
            'status'              => 'info',
            'message'             => '',
            'indexed_content'     => null,
            'file_id'             => null,
            'batch_id'            => null,
            'embedding_provider'  => null,
            'embedding_model'     => null,
            'source_type_for_log' => 'chat_file_upload', // Default for this logger
        ];
        $data_to_insert = wp_parse_args($log_data, $defaults);

        $source_type = $data_to_insert['source_type_for_log'] ?? 'chat_file_upload';
        $should_truncate = !in_array($source_type, ['chat_file_upload_pinecone_chunk', 'chat_file_upload_qdrant_chunk', 'chat_file_upload_chroma_chunk', 'chat_file_upload_local_chunk'], true);

        if ($should_truncate && is_string($data_to_insert['indexed_content']) && mb_strlen($data_to_insert['indexed_content']) > 1000) {
            $data_to_insert['indexed_content'] = mb_substr($data_to_insert['indexed_content'], 0, 997) . '...';
        }
        unset($data_to_insert['source_type_for_log']);

        $this->wpdb->insert($this->data_source_table_name, $data_to_insert);
    }
}

/**
 * ChatUploadValidator
 *
 * Wraps file validation logic for chat uploads.
 */
class ChatUploadValidator
{
    public function __construct()
    {
        // Ensure AIPKit_Upload_Utils is loaded (should be by main plugin loader)
        if (!class_exists(AIPKit_Upload_Utils::class)) {
            $path = WPAICG_PLUGIN_DIR . 'classes/security/uploads.php';
            if (file_exists($path)) {
                require_once $path;
            }
        }
    }

    /**
     * Validates an uploaded file against allowed MIME types and max size for chat uploads.
     *
     * @param array $file_data $_FILES entry for the uploaded file.
     * @return true|WP_Error True if valid, WP_Error otherwise.
     */
    public function validate_file(array $file_data)
    {
        if (!class_exists(AIPKit_Upload_Utils::class)) {
            return new WP_Error('upload_utils_missing_validator', __('File validation component is missing.', 'gpt3-ai-content-generator'), ['status' => 500]);
        }
        // Define allowed MIME types for chat file uploads
        $allowed_mime_types = apply_filters('aipkit_chat_upload_allowed_mime_types', [
            'text/plain',
            'application/pdf',
            // Potentially add more types specifically for chat in the future
        ]);
        return AIPKit_Upload_Utils::validate_upload_file($file_data, $allowed_mime_types);
    }
}

namespace WPAICG\Lib\Chat\Frontend\Ajax\Handlers;

use WPAICG\Chat\Core\AIPKit_Chat_File_Upload_Provider_Resolver;
use WPAICG\Chat\Admin\AdminSetup;
use WPAICG\Chat\Storage\BotStorage;
use WPAICG\Lib\Chat\Frontend\Ajax\Utils\ChatUploadValidator;
use WPAICG\Lib\Chat\Frontend\Ajax\Utils\ChatUploadLogger;
use WPAICG\Lib\Chat\Frontend\Ajax\Utils\ChatUploadConfigLoader;
use WPAICG\aipkit_dashboard;
use WPAICG\Utils\AIPKit_Identifier_Utils;
use WPAICG\Core\TokenManager\AIPKit_Token_Manager;
use WP_Error;

/**
 * ChatFileUploadHandler
 *
 * Orchestrates the file upload process: validates, routes to provider-specific handlers,
 * and manages logging.
 */
class ChatFileUploadHandler
{
    private $validator;
    private $logger;
    private $config_loader;

    public function __construct(ChatUploadConfigLoader $config_loader)
    {
        $this->config_loader = $config_loader;
        $this->validator = new ChatUploadValidator();
        $this->logger = new ChatUploadLogger($config_loader->get_wpdb(), $config_loader->get_data_source_table_name());
    }

    /**
     * Handles the validated file upload request and routes to the correct provider.
     *
     * @param array $post_data The sanitized $_POST data.
     * @param array $files_data The $_FILES superglobal.
     * @return array|WP_Error Success data or WP_Error.
     */
    public function handle_upload(array $post_data, array $files_data)
    {
        if (!class_exists(aipkit_dashboard::class) || !aipkit_dashboard::is_pro_plan()) {
            return new WP_Error('pro_feature_required', __('File upload for chat requires a Pro plan.', 'gpt3-ai-content-generator'), ['status' => 403]);
        }

        $user_id = get_current_user_id();
        $session_id = isset($post_data['session_id']) ? sanitize_text_field(wp_unslash($post_data['session_id'])) : null;
        $bot_id = isset($post_data['bot_id']) ? absint($post_data['bot_id']) : 0;
        $conversation_uuid = isset($post_data['conversation_uuid'])
            ? sanitize_key(wp_unslash((string) $post_data['conversation_uuid']))
            : '';

        $binding = ['user_id' => $user_id, 'session_id' => $session_id ?: '', 'bot_id' => $bot_id, 'conversation_uuid' => $conversation_uuid];
        if ($conversation_uuid === '' || (!$user_id && empty($session_id))) {
            return new WP_Error('chat_upload_identity_missing', __('Reload the chatbot before uploading a file.', 'gpt3-ai-content-generator'), ['status' => 400]);
        }
        $rate_check = AIPKit_Token_Manager::check_public_request_rate();
        if (is_wp_error($rate_check)) { return $rate_check; }

        if ($bot_id <= 0) {
            return new WP_Error('invalid_chatbot_upload', __('Chatbot settings are unavailable for file upload.', 'gpt3-ai-content-generator'), ['status' => 400]);
        }

        // A signed file context may still need cleanup after an administrator
        // changes, disables, or deletes the chatbot. Cleanup never selects a
        // provider from untrusted client input.
        if (!empty($post_data['delete_file_context']) && ($post_data['file_context_provider'] ?? 'Google') !== 'Google') {
            $context = AIPKit_Identifier_Utils::verify_upload_token((string) ($post_data['file_context_token'] ?? ''), $binding, 'file');
            if (is_wp_error($context)) { return $context; }
            return $this->delete_vector_context($context);
        }
        if (!empty($post_data['delete_file_context'])) {
            $provider_handler = $this->get_provider_handler('google');
            if (is_wp_error($provider_handler)) {
                return $provider_handler;
            }
            $provider_config = $provider_handler->get_provider_api_config();
            if (is_wp_error($provider_config)) {
                return $provider_config;
            }
            $binding = [
                'user_id' => $user_id,
                'session_id' => $session_id ?: '',
                'bot_id' => $bot_id,
                'conversation_uuid' => $conversation_uuid,
            ];
            $context_token = isset($post_data['file_context_token'])
                ? sanitize_text_field(wp_unslash((string) $post_data['file_context_token']))
                : '';
            return $provider_handler->delete_file_context($context_token, $provider_config, $binding);
        }

        if (
            !class_exists(AdminSetup::class)
            || !class_exists(BotStorage::class)
            || get_post_type($bot_id) !== AdminSetup::POST_TYPE
            || get_post_status($bot_id) !== 'publish'
        ) {
            return new WP_Error('invalid_chatbot_upload', __('Chatbot settings are unavailable for file upload.', 'gpt3-ai-content-generator'), ['status' => 400]);
        }
        $bot_settings = (new BotStorage())->get_chatbot_settings($bot_id);
        if (empty($bot_settings)) {
            return new WP_Error('invalid_chatbot_upload', __('Chatbot settings are unavailable for file upload.', 'gpt3-ai-content-generator'), ['status' => 400]);
        }

        if (($bot_settings['enable_file_upload'] ?? '0') !== '1') {
            return new WP_Error('chat_file_upload_disabled', __('File upload is not enabled for this chatbot.', 'gpt3-ai-content-generator'), ['status' => 403]);
        }
        if (!class_exists(AIPKit_Chat_File_Upload_Provider_Resolver::class)) {
            return new WP_Error('upload_provider_resolver_missing', __('File upload routing is unavailable.', 'gpt3-ai-content-generator'), ['status' => 500]);
        }
        $provider_slug = AIPKit_Chat_File_Upload_Provider_Resolver::resolve($bot_settings);
        if ($provider_slug === '') {
            return new WP_Error(
                'chat_file_upload_route_missing',
                __('Enable Knowledge and select a supported knowledge provider before enabling file upload for this chatbot provider.', 'gpt3-ai-content-generator'),
                ['status' => 400]
            );
        }

        $allowance = (new AIPKit_Token_Manager())->check_and_reset_tokens($user_id ?: null, $session_id, $bot_id, 'chat');
        if (is_wp_error($allowance)) { return $allowance; }
        $scope = $this->upload_scope($bot_settings);
        if (!empty($post_data['job_id']) && $provider_slug !== 'google') {
            $job = AIPKit_Identifier_Utils::verify_upload_token((string) $post_data['job_id'], $binding, 'job');
            if (is_wp_error($job)) { return $job; }
            if (($job['provider'] ?? '') !== $provider_slug || ($job['scope'] ?? '') !== $scope) {
                return new WP_Error('chat_upload_configuration_changed', __('The chatbot upload settings changed. Please upload the file again.', 'gpt3-ai-content-generator'), ['status' => 409, 'stop_batch' => true]);
            }
            $post_data['job_id'] = $job['job_id'];
        }

        if ($provider_slug === 'google' && !empty($post_data['job_id'])) {
            $provider_handler = $this->get_provider_handler('google');
            if (is_wp_error($provider_handler)) {
                return $provider_handler;
            }
            $provider_config = $provider_handler->get_provider_api_config();
            if (is_wp_error($provider_config)) {
                return $provider_config;
            }
            $binding = [
                'user_id' => $user_id,
                'session_id' => $session_id ?: '',
                'bot_id' => $bot_id,
                'conversation_uuid' => $conversation_uuid,
            ];
            $job_id = sanitize_text_field(wp_unslash((string) $post_data['job_id']));
            return $provider_handler->continue_upload_job($job_id, $provider_config, $binding);
        }

        if (!empty($post_data['job_id']) && in_array($provider_slug, ['openai', 'pinecone', 'qdrant', 'chroma', 'local'], true)) {
            $job_id = sanitize_text_field(wp_unslash((string) $post_data['job_id']));
            $provider_handler = $this->get_provider_handler($provider_slug);
            if (is_wp_error($provider_handler)) {
                return $provider_handler;
            }
            $provider_config = $provider_handler->get_provider_api_config();
            if (is_wp_error($provider_config)) {
                return $provider_config;
            }
            if (!method_exists($provider_handler, 'continue_upload_job')) {
                return new WP_Error('handler_error', __('File processing handler for the selected provider is not available.', 'gpt3-ai-content-generator'), ['status' => 500]);
            }
            return $this->signed_result($provider_handler->continue_upload_job($job_id, $provider_config, $binding), $provider_slug, $binding, $scope);
        }

        if (!isset($files_data['file_to_upload']) || empty($files_data['file_to_upload']['tmp_name'])) {
            return new WP_Error('no_file', __('No file provided.', 'gpt3-ai-content-generator'), ['status' => 400]);
        }
        $file_data = $files_data['file_to_upload'];

        $validation_result = $this->validator->validate_file($file_data);
        if (is_wp_error($validation_result)) {
            return $validation_result;
        }

        $provider_handler = $this->get_provider_handler($provider_slug);
        if (is_wp_error($provider_handler)) {
            return $provider_handler;
        }
        $provider_config = $provider_handler->get_provider_api_config();

        if (is_wp_error($provider_config)) {
            return $provider_config; // API key or URL might be missing
        }

        if (!$provider_handler || !method_exists($provider_handler, 'process_upload')) {
            return new WP_Error('handler_error', __('File processing handler for the selected provider is not available.', 'gpt3-ai-content-generator'), ['status' => 500]);
        }

        if ($provider_slug === 'google') {
            return $provider_handler->process_upload(
                $file_data,
                $user_id,
                $session_id,
                $provider_config,
                $bot_id,
                $conversation_uuid
            );
        }

        return $this->signed_result($provider_handler->process_upload($file_data, $user_id, $session_id, $provider_config, $bot_id, $conversation_uuid), $provider_slug, $binding, $scope);
    }
    private function upload_scope(array $settings): string
    {
        $keys = ['provider', 'vector_store_provider', 'enable_vector_store', 'vector_embedding_provider', 'vector_embedding_model', 'pinecone_index_name', 'qdrant_collection_name', 'qdrant_collection_names', 'chroma_collection_name', 'chroma_collection_names', 'local_store_id', 'local_store_ids'];
        return hash('sha256', wp_json_encode(array_intersect_key($settings, array_flip($keys))));
    }

    private function signed_result($result, string $provider, array $binding, string $scope)
    {
        if (is_wp_error($result)) { return $result; }
        $job_id = (string) ($result['job_id'] ?? '');
        if ($job_id !== '') {
            $result['job_id'] = AIPKit_Identifier_Utils::sign_upload_token(['provider' => $provider, 'scope' => $scope, 'job_id' => $job_id], $binding, 'job');
        }
        if (isset($result['file_context'])) {
            $result['file_context']['context_token'] = AIPKit_Identifier_Utils::sign_upload_token($result['file_context'] + ['job_id' => $job_id], $binding, 'file');
        }
        return $result;
    }

    /** Delete only the private document named by a verified context, never the shared store. */
    private function delete_vector_context(array $context)
    {
        $provider = (string) ($context['provider'] ?? '');
        if (!in_array($provider, ['Pinecone', 'Qdrant', 'Chroma', 'Local'], true)) {
            return new WP_Error('chat_upload_cleanup_unsupported', __('This file cannot be removed here.', 'gpt3-ai-content-generator'), ['status' => 400]);
        }
        $target = (string) ($context['index_name'] ?? $context['collection_name'] ?? '');
        $context_id = (string) ($context['namespace'] ?? $context['file_upload_context_id'] ?? '');
        if ($target === '' || $context_id === '') { return new WP_Error('chat_upload_context_invalid', __('Invalid file context.', 'gpt3-ai-content-generator'), ['status' => 400]); }
        $config = $provider === 'Local' ? [] : \WPAICG\AIPKit_Providers::get_provider_data($provider);
        $selector = ['filter' => ['must' => [['key' => 'file_upload_context_id', 'match' => ['value' => $context_id]]]]];
        if ($provider === 'Chroma') { $selector = ['where' => ['file_upload_context_id' => $context_id]]; }
        if ($provider === 'Pinecone') { $selector = ['deleteAll' => true, 'namespace' => $context_id]; }
        $result = $this->config_loader->get_vector_store_manager()->delete_vectors($provider, $target, $selector, $config);
        if (is_wp_error($result)) { return $result; }
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Remove source records only for the verified visitor file.
        $this->config_loader->get_wpdb()->delete($this->config_loader->get_data_source_table_name(), [
            'provider' => $provider, 'vector_store_id' => $target, 'batch_id' => $context_id,
        ]);
        if (!empty($context['job_id'])) { \WPAICG\Lib\VectorStores\FileUpload\AIPKit_Vector_File_Ingestion_Job::delete_job($context['job_id']); }
        return ['deleted' => true];
    }

    /** Select the same provider implementation for new files, continuations and cleanup. */
    private function get_provider_handler(string $provider_slug)
    {
        switch ($provider_slug) {
            case 'openai':
                return new ChatFileUploadOpenAIHandler($this->config_loader, $this->logger);
            case 'pinecone':
                return new ChatFileUploadPineconeHandler($this->config_loader, $this->logger);
            case 'qdrant':
                if (!class_exists(ChatFileUploadQdrantHandler::class)) {
                    // This should not happen if files are loaded correctly by wpaicg__premium_only.php
                    return new WP_Error('handler_class_missing', __('Qdrant file processing component is missing.', 'gpt3-ai-content-generator'), ['status' => 500]);
                }
                return new ChatFileUploadQdrantHandler($this->config_loader, $this->logger);
            case 'local':
                return new ChatFileUploadLocalHandler($this->config_loader, $this->logger);
            case 'chroma':
                if (!class_exists(ChatFileUploadChromaHandler::class)) {
                    return new WP_Error('handler_class_missing', __('Chroma file processing component is missing.', 'gpt3-ai-content-generator'), ['status' => 500]);
                }
                return new ChatFileUploadChromaHandler($this->config_loader, $this->logger);
            case 'claude_files':
                if (!class_exists(ChatFileUploadClaudeHandler::class)) {
                    return new WP_Error('handler_class_missing', __('Claude file processing component is missing.', 'gpt3-ai-content-generator'), ['status' => 500]);
                }
                return new ChatFileUploadClaudeHandler($this->config_loader, $this->logger);
            case 'google':
                if (!class_exists(ChatFileUploadGoogleHandler::class)) {
                    return new WP_Error('handler_class_missing', __('Google file processing component is missing.', 'gpt3-ai-content-generator'), ['status' => 500]);
                }
                return new ChatFileUploadGoogleHandler($this->config_loader, $this->logger);
            default:
                return new WP_Error('unsupported_provider', __('Unsupported provider for file upload.', 'gpt3-ai-content-generator'), ['status' => 400]);
        }
    }
}

namespace WPAICG\Lib\Chat\Frontend\Ajax;

use WPAICG\Chat\Admin\Ajax\Traits\Trait_CheckFrontendPermissions;
use WPAICG\Chat\Admin\Ajax\Traits\Trait_SendWPError;
use WPAICG\Lib\Chat\Frontend\Ajax\Handlers\ChatFileUploadHandler;
use WPAICG\Lib\Chat\Frontend\Ajax\Utils\ChatUploadConfigLoader;

/**
 * ChatFileUploadAjaxDispatcher
 *
 * Acts as the main entry point for the frontend file upload AJAX action.
 * It verifies permissions and then delegates the core processing to the ChatFileUploadHandler.
 */
class ChatFileUploadAjaxDispatcher
{
    use Trait_CheckFrontendPermissions;
    use Trait_SendWPError;

    private $file_upload_handler;

    public function __construct()
    {
        // The config loader will ensure dependencies for the handler are available
        // or throw an error if critical ones are missing.
        $config_loader = new ChatUploadConfigLoader();

        // Pass the config loader to the main handler.
        // The handler will then use it to get its necessary dependencies.
        $this->file_upload_handler = new ChatFileUploadHandler($config_loader);
    }

    /**
     * AJAX handler for frontend file uploads.
     * Hooked to 'wp_ajax_aipkit_frontend_chat_upload_file' and 'wp_ajax_nopriv_aipkit_frontend_chat_upload_file'.
     */
    public function ajax_handle_frontend_file_upload(): void
    {
        $permission_check = $this->check_frontend_permissions(); // Uses Trait
        if (is_wp_error($permission_check)) {
            $this->send_wp_error($permission_check); // Uses Trait
            return;
        }

        // Delegate to the main handler, passing the $_POST and $_FILES superglobals
        // The handler will be responsible for further validation and processing.
        // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce is checked by check_frontend_permissions() above.
        $result = $this->file_upload_handler->handle_upload($_POST, $_FILES);

        if (is_wp_error($result)) {
            $this->send_wp_error($result);
        } else {
            wp_send_json_success($result);
        }
    }
}
