<?php

namespace BitApps\IntegrationsPro\Actions\TheEventsCalendar\Services;

use BitApps\IntegrationsPro\Actions\TheEventsCalendar\TheEventsCalendarHelper;
use BitApps\IntegrationsPro\Core\Util\Hooks;
use TEC\Events_Pro\Custom_Tables\V1\Duplicate\Duplicate;
use TEC\Events_Pro\Custom_Tables\V1\Events\Converter\From_Event_Recurrence_Converter;
use TEC\Events_Pro\Custom_Tables\V1\Events\Occurrences\Occurrences_Generator;
use TEC\Events_Pro\Custom_Tables\V1\Events\Recurrence;
use TEC\Events_Pro\Custom_Tables\V1\Events\Rules\Date_Rule;
use TEC\Events_Pro\Custom_Tables\V1\RRule\RfcParser;
use TEC\Events_Pro\Custom_Tables\V1\RRule\RSet_Wrapper;
use TEC\Events_Pro\Custom_Tables\V1\Series\Relationship;
use TEC\Events_Pro\Custom_Tables\V1\WP_Query\Provider as OccurrenceQueryProvider;
use Tribe\Events\Event_Status\Classic_Editor;
use WP_Post;

if (!\defined('ABSPATH')) {
    exit;
}

final class EventService extends BaseService
{
    private const OCCURRENCE_FIELDS_FILTER = 'tec_events_custom_tables_v1_occurrence_select_fields';

    private const EVENT_STATUSES = ['scheduled', 'canceled', 'postponed'];

    private const RECURRENCE_FREQUENCIES = ['daily', 'weekly', 'monthly', 'yearly'];

    private const RECURRENCE_END_TYPES = ['never', 'count', 'until'];

    private const WEEKDAYS = ['MO', 'TU', 'WE', 'TH', 'FR', 'SA', 'SU'];

    private const CUSTOM_FIELD_KEY_PATTERN = '/^_ecp_custom_\d+$/';

    private const REMOVABLE_FLAG_META_KEYS = [
        'all_day'            => '_EventAllDay',
        'hide_from_upcoming' => '_EventHideFromUpcoming',
    ];

    private const RECURRENCE_CLASSES = [
        Occurrences_Generator::class,
        Relationship::class,
        Recurrence::class,
        RSet_Wrapper::class,
        From_Event_Recurrence_Converter::class,
        RfcParser::class,
        Date_Rule::class,
    ];

    public function createEvent(): array
    {
        $error = $this->validateRequiredFields([
            'title'      => __('Event Title', 'bit-integrations-pro'),
            'start_date' => __('Start Date', 'bit-integrations-pro'),
            'end_date'   => __('End Date', 'bit-integrations-pro'),
        ]) ?? $this->validateEventFields();

        if ($error !== null) {
            return $error;
        }

        return $this->insertEvent($this->getEventArgs('publish'), __('The event is created.', 'bit-integrations-pro'));
    }

    public function updateEvent(): array
    {
        $error = $this->validateRequiredFields(['event_id' => __('Event ID', 'bit-integrations-pro')]);

        if ($error !== null) {
            return $error;
        }

        $eventId = (int) $this->getInteger('event_id');

        if (!TheEventsCalendarHelper::isPostOfType($eventId, TheEventsCalendarHelper::EVENT_POST_TYPE)) {
            return $this->eventNotFound();
        }

        $error = $this->validateEventFields($eventId);

        if ($error !== null) {
            return $error;
        }

        $eventArgs = $this->getEventArgs();
        $hasFeaturedImage = $this->hasValue('featured_image');
        $hasTerms = $this->hasValue('category_ids') || $this->hasValue('tags');
        $hasCustomFields = !empty($this->getCustomFieldValues());

        if (empty($eventArgs) && !$hasFeaturedImage && !$hasTerms && !$hasCustomFields && $this->getBoolean('featured') === null) {
            return $this->errorResponse(__('No event field has a value. Map at least one field to update.', 'bit-integrations-pro'));
        }

        if (!empty($eventArgs) || $hasFeaturedImage) {
            $savedEvents = $this->saveEvent($eventId, $this->withCurrentSchedule($eventId, $eventArgs));

            if (!\in_array(true, (array) $savedEvents, true)) {
                return $this->errorResponse(__('Failed to update the event. Check the field values and try again.', 'bit-integrations-pro'));
            }
        }

        $this->setEventTerms($eventId);
        $this->setFeatured($eventId);
        $this->setCustomFields($eventId);

        // The ORM drops these flags when they are false instead of deleting the stored meta.
        foreach (self::REMOVABLE_FLAG_META_KEYS as $flagKey => $metaKey) {
            if ($this->getBoolean($flagKey) === false) {
                delete_post_meta($eventId, $metaKey);
            }
        }

        return $this->successResponse(__('The event is updated.', 'bit-integrations-pro'), TheEventsCalendarHelper::getEventData($eventId));
    }

    public function deleteEvent(): array
    {
        $error = $this->validateRequiredFields(['event_id' => __('Event ID', 'bit-integrations-pro')]);

        if ($error !== null) {
            return $error;
        }

        $eventId = (int) $this->getInteger('event_id');
        $eventData = TheEventsCalendarHelper::getEventData($eventId);

        if (empty($eventData)) {
            return $this->eventNotFound();
        }

        $isPermanent = (bool) $this->getBoolean('delete_permanently');

        if (!$this->removePost($eventId, $isPermanent)) {
            return $this->errorResponse(__('Failed to delete the event. Check that the event exists and try again.', 'bit-integrations-pro'));
        }

        $eventData['deleted_permanently'] = $isPermanent;

        return $this->successResponse(__('The event is deleted.', 'bit-integrations-pro'), $eventData);
    }

    public function updateEventStatus(): array
    {
        $error = $this->validateRequiredFields([
            'event_id'     => __('Event ID', 'bit-integrations-pro'),
            'event_status' => __('Event Status', 'bit-integrations-pro'),
        ]);

        if ($error !== null) {
            return $error;
        }

        $eventId = (int) $this->getInteger('event_id');
        $eventStatus = strtolower($this->getString('event_status'));

        if (!\in_array($eventStatus, self::EVENT_STATUSES, true)) {
            return $this->errorResponse(__('The event status is not valid. Use scheduled, canceled, or postponed.', 'bit-integrations-pro'));
        }

        if (!TheEventsCalendarHelper::isPostOfType($eventId, TheEventsCalendarHelper::EVENT_POST_TYPE)) {
            return $this->eventNotFound();
        }

        if (!class_exists(Classic_Editor::class)) {
            return $this->errorResponse(__('This version of The Events Calendar does not support event status. Update the plugin and try again.', 'bit-integrations-pro'));
        }

        $statusEditor = tribe(Classic_Editor::class);

        if ($eventStatus === 'scheduled') {
            $statusEditor->delete_fields($eventId, []);
        } else {
            $statusEditor->update_fields($eventId, ['status' => $eventStatus, 'status-reason' => $this->getString('status_reason')]);
        }

        return $this->successResponse(__('The event status is updated.', 'bit-integrations-pro'), TheEventsCalendarHelper::getEventData($eventId));
    }

    public function duplicateEvent(): array
    {
        $error = $this->validateRequiredFields(['event_id' => __('Event ID', 'bit-integrations-pro')]);

        if ($error !== null) {
            return $error;
        }

        if (!TheEventsCalendarHelper::isProActive()) {
            return $this->proRequired();
        }

        $eventId = (int) $this->getInteger('event_id');

        if (!TheEventsCalendarHelper::isPostOfType($eventId, TheEventsCalendarHelper::EVENT_POST_TYPE)) {
            return $this->eventNotFound();
        }

        $overrides = array_filter([
            'post_title'  => $this->getString('title'),
            'post_status' => (string) $this->getPostStatus(),
        ]);

        $duplicatedEvent = tribe(Duplicate::class)->duplicate_event(get_post($eventId), $overrides);

        if (!$duplicatedEvent instanceof WP_Post) {
            return $this->errorResponse(__('Failed to duplicate the event. Check that the event has a start date and an end date.', 'bit-integrations-pro'));
        }

        $eventData = TheEventsCalendarHelper::getEventData($duplicatedEvent->ID);
        $eventData['original_event_id'] = $eventId;

        return $this->successResponse(__('The event is duplicated.', 'bit-integrations-pro'), $eventData);
    }

    public function createRecurringEvent(): array
    {
        $error = $this->validateRequiredFields([
            'title'      => __('Event Title', 'bit-integrations-pro'),
            'start_date' => __('First Start Date', 'bit-integrations-pro'),
            'end_date'   => __('First End Date', 'bit-integrations-pro'),
            'frequency'  => __('Repeat', 'bit-integrations-pro'),
        ]);

        if ($error !== null) {
            return $error;
        }

        if (!TheEventsCalendarHelper::isProActive()) {
            return $this->proRequired();
        }

        $error = $this->getRecurrenceError() ?? $this->validateEventFields();

        if ($error !== null) {
            return $error;
        }

        $eventArgs = $this->getEventArgs('publish');
        $eventArgs['recurrence'] = $this->getRecurrenceRule();

        // The Pro ORM turns any PHP notice into an exception while it saves a recurrence, and these classes
        // raise PHP 8.4 deprecations when they load, so load them before the save.
        foreach (self::RECURRENCE_CLASSES as $recurrenceClass) {
            class_exists($recurrenceClass);
        }

        return $this->insertEvent($eventArgs, __('The recurring event is created.', 'bit-integrations-pro'));
    }

    private function validateEventFields(?int $eventId = null): ?array
    {
        $error = $this->validateDates([
            'start_date'          => __('Start Date', 'bit-integrations-pro'),
            'end_date'            => __('End Date', 'bit-integrations-pro'),
            'recurrence_end_date' => __('Last Date', 'bit-integrations-pro'),
        ]);

        if ($error !== null) {
            return $error;
        }

        $startDate = $this->hasValue('start_date') ? $this->getString('start_date') : ($eventId ? get_post_meta($eventId, '_EventStartDate', true) : '');
        $endDate = $this->hasValue('end_date') ? $this->getString('end_date') : ($eventId ? get_post_meta($eventId, '_EventEndDate', true) : '');

        if (!empty($startDate) && !empty($endDate) && strtotime($endDate) < strtotime($startDate)) {
            return $this->errorResponse(__('The end date is before the start date. Enter an end date after the start date.', 'bit-integrations-pro'));
        }

        if ($this->hasValue('venue_id') && !TheEventsCalendarHelper::isPostOfType($this->getInteger('venue_id'), TheEventsCalendarHelper::VENUE_POST_TYPE)) {
            return $this->errorResponse(__('Venue not found. Select an existing venue.', 'bit-integrations-pro'));
        }

        foreach ($this->getIdList('organizer_ids') as $organizerId) {
            if (!TheEventsCalendarHelper::isPostOfType($organizerId, TheEventsCalendarHelper::ORGANIZER_POST_TYPE)) {
                return $this->errorResponse(__('Organizer not found. Select existing organizers.', 'bit-integrations-pro'));
            }
        }

        foreach ($this->getIdList('category_ids') as $categoryId) {
            if (!term_exists($categoryId, TheEventsCalendarHelper::CATEGORY_TAXONOMY)) {
                return $this->errorResponse(__('Event category not found. Select existing categories.', 'bit-integrations-pro'));
            }
        }

        return $this->validateCustomFields();
    }

    private function validateCustomFields(): ?array
    {
        $customFieldValues = $this->getCustomFieldValues();

        if (empty($customFieldValues)) {
            return null;
        }

        if (!TheEventsCalendarHelper::isProActive()) {
            return $this->errorResponse(__('The Events Calendar Pro is not active. Activate Pro to use custom fields.', 'bit-integrations-pro'));
        }

        $customFields = TheEventsCalendarHelper::getCustomFields();

        foreach (array_keys($customFieldValues) as $fieldName) {
            if (!isset($customFields[$fieldName])) {
                return $this->errorResponse(__('Custom field not found. Map an existing custom field.', 'bit-integrations-pro'));
            }
        }

        return null;
    }

    private function getCustomFieldValues(): array
    {
        $customFieldValues = [];

        foreach (array_keys($this->fields) as $key) {
            if (preg_match(self::CUSTOM_FIELD_KEY_PATTERN, (string) $key) && $this->hasValue($key)) {
                $customFieldValues[$key] = $this->getString($key);
            }
        }

        return $customFieldValues;
    }

    private function setCustomFields(int $eventId): void
    {
        $customFieldValues = $this->getCustomFieldValues();

        if (!empty($customFieldValues)) {
            TheEventsCalendarHelper::saveEventCustomFields($eventId, $customFieldValues);
        }
    }

    private function insertEvent(array $eventArgs, string $successMessage): array
    {
        $repository = tribe_events()->set_args($eventArgs);

        if ($this->hasValue('featured_image')) {
            $repository->set_featured_image($this->getString('featured_image'));
        }

        $event = $repository->create();

        if (!$event instanceof WP_Post) {
            return $this->errorResponse(__('Failed to create the event. Check the field values and try again.', 'bit-integrations-pro'));
        }

        $this->setEventTerms($event->ID);
        $this->setFeatured($event->ID);
        $this->setCustomFields($event->ID);

        return $this->successResponse($successMessage, TheEventsCalendarHelper::getEventData($event->ID));
    }

    private function getEventArgs(?string $defaultStatus = null): array
    {
        $eventArgs = [
            'title'              => $this->getString('title'),
            'content'            => $this->getString('description'),
            'excerpt'            => $this->getString('excerpt'),
            'status'             => (string) $this->getPostStatus($defaultStatus),
            'start_date'         => $this->getString('start_date'),
            'end_date'           => $this->getString('end_date'),
            'timezone'           => $this->getString('timezone'),
            'all_day'            => $this->getBoolean('all_day'),
            'venue'              => $this->getInteger('venue_id'),
            'organizer'          => $this->getIdList('organizer_ids'),
            'cost'               => $this->getString('cost'),
            'currency_symbol'    => $this->getString('currency_symbol'),
            'currency_position'  => $this->getCurrencyPosition(),
            'url'                => $this->getString('event_website'),
            'show_map'           => $this->getBoolean('show_map'),
            'show_map_link'      => $this->getBoolean('show_map_link'),
            'hide_from_upcoming' => $this->getBoolean('hide_from_upcoming'),
        ];

        return array_filter(
            $eventArgs,
            static function ($value) {
                return \is_bool($value) || is_numeric($value) || !empty($value);
            }
        );
    }

    private function saveEvent(int $eventId, array $eventArgs)
    {
        // With Pro, the ORM resolves events to occurrence IDs and skips post fields; TEC's Update_Entity_Response also removes this filter.
        $isOccurrenceFilterActive = tribe()->isBound(OccurrenceQueryProvider::class)
            && has_filter(self::OCCURRENCE_FIELDS_FILTER, [tribe(OccurrenceQueryProvider::class), 'filter_occurrence_fields']);

        if ($isOccurrenceFilterActive) {
            Hooks::remove(self::OCCURRENCE_FIELDS_FILTER, [tribe(OccurrenceQueryProvider::class), 'filter_occurrence_fields']);
        }

        $repository = tribe_events()->by_args(['id' => $eventId, 'status' => 'any'])->set_args($eventArgs);

        if ($this->hasValue('featured_image')) {
            $repository->set_featured_image($this->getString('featured_image'));
        }

        $savedEvents = $repository->save();

        if ($isOccurrenceFilterActive) {
            Hooks::filter(self::OCCURRENCE_FIELDS_FILTER, [tribe(OccurrenceQueryProvider::class), 'filter_occurrence_fields']);
        }

        return $savedEvents;
    }

    private function getCurrencyPosition(): ?string
    {
        if (!$this->hasValue('currency_position')) {
            return null;
        }

        // TEC stores "postfix" and turns any other value, such as "suffix", into "prefix".
        return \in_array($this->getString('currency_position'), ['postfix', 'suffix', 'after'], true) ? 'postfix' : 'prefix';
    }

    private function setFeatured(int $eventId): void
    {
        $isFeatured = $this->getBoolean('featured');

        if ($isFeatured === true) {
            tribe('tec.featured_events')->feature($eventId);
        } elseif ($isFeatured === false) {
            tribe('tec.featured_events')->unfeature($eventId);
        }
    }

    private function withCurrentSchedule(int $eventId, array $eventArgs): array
    {
        if (!isset($eventArgs['start_date']) && !isset($eventArgs['end_date'])) {
            return $eventArgs;
        }

        // The ORM moves the end date to the start date when an update sets only one of them.
        $eventArgs['start_date'] = $eventArgs['start_date'] ?? get_post_meta($eventId, '_EventStartDate', true);
        $eventArgs['end_date'] = $eventArgs['end_date'] ?? get_post_meta($eventId, '_EventEndDate', true);
        $eventArgs['timezone'] = $eventArgs['timezone'] ?? get_post_meta($eventId, '_EventTimezone', true);

        return $eventArgs;
    }

    private function setEventTerms(int $eventId): void
    {
        // wp_insert_post() drops tax_input when no user can assign terms, as in background flow runs.
        $categoryIds = $this->getIdList('category_ids');
        $tags = $this->getList('tags');

        if (!empty($categoryIds)) {
            wp_set_object_terms($eventId, $categoryIds, TheEventsCalendarHelper::CATEGORY_TAXONOMY);
        }

        if (!empty($tags)) {
            wp_set_object_terms($eventId, $tags, 'post_tag');
        }
    }

    private function getRecurrenceError(): ?array
    {
        $endType = $this->hasValue('recurrence_end') ? $this->getString('recurrence_end') : 'never';

        if (!\in_array(strtolower($this->getString('frequency')), self::RECURRENCE_FREQUENCIES, true)) {
            return $this->errorResponse(__('The frequency is not valid. Use daily, weekly, monthly, or yearly.', 'bit-integrations-pro'));
        }

        if (!\in_array($endType, self::RECURRENCE_END_TYPES, true)) {
            return $this->errorResponse(__('The recurrence end is not valid. Use never, count, or until.', 'bit-integrations-pro'));
        }

        if ($endType === 'count' && (int) $this->getInteger('occurrence_count') < 1) {
            return $this->errorResponse(__('The number of occurrences is required. Enter a number greater than 0.', 'bit-integrations-pro'));
        }

        if ($endType === 'until' && !$this->hasValue('recurrence_end_date')) {
            return $this->errorResponse(__('The recurrence end date is required. Enter the date of the last occurrence.', 'bit-integrations-pro'));
        }

        return null;
    }

    private function getRecurrenceRule(): string
    {
        $frequency = strtolower($this->getString('frequency'));
        $ruleParts = [
            'FREQ=' . strtoupper($frequency),
            'INTERVAL=' . max(1, (int) $this->getInteger('interval')),
        ];

        $weekdays = array_values(array_intersect(array_map('strtoupper', $this->getList('weekdays')), self::WEEKDAYS));

        if ($frequency === 'weekly' && !empty($weekdays)) {
            $ruleParts[] = 'BYDAY=' . implode(',', $weekdays);
        }

        $endType = $this->hasValue('recurrence_end') ? $this->getString('recurrence_end') : 'never';

        if ($endType === 'count') {
            $ruleParts[] = 'COUNT=' . (int) $this->getInteger('occurrence_count');
        } elseif ($endType === 'until') {
            $ruleParts[] = 'UNTIL=' . gmdate('Ymd', strtotime($this->getString('recurrence_end_date'))) . 'T235959';
        }

        return 'RRULE:' . implode(';', $ruleParts);
    }

    private function eventNotFound(): array
    {
        return $this->errorResponse(__('Event not found. Map the ID of an existing event.', 'bit-integrations-pro'));
    }

    private function proRequired(): array
    {
        return $this->errorResponse(__('The Events Calendar Pro is not active. Activate Pro to use this action.', 'bit-integrations-pro'));
    }
}
