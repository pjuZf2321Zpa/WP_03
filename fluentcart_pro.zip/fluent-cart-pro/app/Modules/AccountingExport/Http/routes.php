<?php

use FluentCart\Framework\Http\Router;
use FluentCartPro\App\Modules\AccountingExport\Http\Controllers\AccountingExportController;

/**
 * @var Router $router
 */
$router->prefix('data-export/accounting')
    ->withPolicy('FluentCartPro\App\Http\Policies\AccountingExportPolicy')
    ->group(function (Router $router) {
        $router->get('/schema', [AccountingExportController::class, 'schema'])->meta([
            'permissions' => 'reports/export',
        ]);
        $router->post('/batch', [AccountingExportController::class, 'batch'])->meta([
            'permissions' => 'reports/export',
        ]);
    });
