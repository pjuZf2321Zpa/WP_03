<?php

/**
 * Namespace Compatibility Layer for Bit Integrations
 *
 * This file creates class aliases between BitCode\FI\* and BitApps\Integrations\* namespaces
 * to ensure compatibility across different versions of the Bit Integrations Free plugin.
 *
 * @since 2.6.9
 */
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Check if a class exists in either BitCode\FI\* or BitApps\Integrations\* namespace
 *
 * This is the recommended way to check for class existence instead of class_exists()
 *
 * @param string $relativeClass Class name without namespace prefix (e.g., 'Config', 'Flow\Flow')
 *
 * @return bool True if class exists in either namespace
 */
if (!function_exists('bit_integrations_class_exists')) {
    function bit_integrations_class_exists($relativeClass)
    {
        $relativeClass = ltrim($relativeClass, '\\');

        // Check new namespace first (current version)
        $newClass = 'BitApps\\Integrations\\' . $relativeClass;
        if (class_exists($newClass)) {
            return true;
        }

        // Check old namespace (legacy version)
        $oldClass = 'BitCode\\FI\\' . $relativeClass;

        return (bool) (class_exists($oldClass));
    }
}

if (!function_exists('bit_integrations_get_class')) {
    function bit_integrations_get_class($relativeClass)
    {
        $relativeClass = ltrim($relativeClass, '\\');

        $newClass = 'BitApps\\Integrations\\' . $relativeClass;
        if (class_exists($newClass)) {
            return $newClass;
        }

        $oldClass = 'BitCode\\FI\\' . $relativeClass;
        if (class_exists($oldClass)) {
            return $oldClass;
        }
    }
}

if (!function_exists('bit_integrations_get_constant')) {
    function bit_integrations_get_constant($relativeClass, $constantName)
    {
        $class = bit_integrations_get_class($relativeClass);
        if ($class === null || !defined("{$class}::{$constantName}")) {
            return;
        }

        return constant("{$class}::{$constantName}");
    }
}

/**
 * Call a static method from either namespace
 *
 * @param string $relativeClass Class name without namespace prefix
 * @param string $method        Method name
 * @param array  $args          Method arguments
 *
 * @return mixed|null Method result or null if not found
 */
if (!function_exists('bit_integrations_call_static')) {
    function bit_integrations_call_static($relativeClass, $method, array $args = [])
    {
        $class = bit_integrations_get_class($relativeClass);
        if ($class === null || !method_exists($class, $method)) {
            return;
        }

        return call_user_func_array([$class, $method], $args);
    }
}

if (!function_exists('bit_integrations_class_and_method_exists')) {
    function bit_integrations_class_and_method_exists($relativeClass, $method)
    {
        $class = bit_integrations_get_class($relativeClass);

        return $class === null ? false : method_exists($class, $method);
    }
}

if (!function_exists('bit_integrations_get_version')) {
    function bit_integrations_get_version()
    {
        return bit_integrations_get_constant('Config', 'VERSION');
    }
}

if (!function_exists('bit_integrations_version_below')) {
    function bit_integrations_version_below($minimumVersion)
    {
        $version = bit_integrations_get_version();
        if ($version === null) {
            return false;
        }

        return version_compare($version, $minimumVersion, '<');
    }
}
