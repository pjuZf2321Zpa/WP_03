<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Core\Util\Route;
use BitApps\IntegrationsPro\Triggers\ContactFormEmail\ContactFormEmailController;

Route::get('contact-form-email/get', [ContactFormEmailController::class, 'getAllTasks']);
