<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Actions\WishlistMember\WishlistMemberHelperPro;
use BitApps\IntegrationsPro\Config;
use BitApps\IntegrationsPro\Core\Util\Hooks;

// Deprecated since v2.7.8 - use bit_integrations_wishlist_* hooks instead
if (bit_integrations_version_below('2.7.8')) {
    Hooks::filter('btcbi_wishlist_update_level', [WishlistMemberHelperPro::class, 'updateLevel'], 10, 2);
    Hooks::filter('btcbi_wishlist_delete_level', [WishlistMemberHelperPro::class, 'deleteLevel'], 10, 2);
    Hooks::filter('btcbi_wishlist_create_member', [WishlistMemberHelperPro::class, 'createMember'], 10, 4);
    Hooks::filter('btcbi_wishlist_update_member', [WishlistMemberHelperPro::class, 'updateMember'], 10, 2);
    Hooks::filter('btcbi_wishlist_delete_member', [WishlistMemberHelperPro::class, 'deleteMember'], 10, 2);
    Hooks::filter('btcbi_wishlist_add_member_to_level', [WishlistMemberHelperPro::class, 'addMemberToLevel'], 10, 3);
    Hooks::filter('btcbi_wishlist_remove_member_from_level', [WishlistMemberHelperPro::class, 'removeMemberFromLevel'], 10, 3);
}

// New hooks since v2.7.8
Hooks::filter(Config::withFreePrefix('wishlist_update_level'), [WishlistMemberHelperPro::class, 'updateLevel'], 10, 2);
Hooks::filter(Config::withFreePrefix('wishlist_delete_level'), [WishlistMemberHelperPro::class, 'deleteLevel'], 10, 2);
Hooks::filter(Config::withFreePrefix('wishlist_create_member'), [WishlistMemberHelperPro::class, 'createMember'], 10, 4);
Hooks::filter(Config::withFreePrefix('wishlist_update_member'), [WishlistMemberHelperPro::class, 'updateMember'], 10, 2);
Hooks::filter(Config::withFreePrefix('wishlist_delete_member'), [WishlistMemberHelperPro::class, 'deleteMember'], 10, 2);
Hooks::filter(Config::withFreePrefix('wishlist_add_member_to_level'), [WishlistMemberHelperPro::class, 'addMemberToLevel'], 10, 3);
Hooks::filter(Config::withFreePrefix('wishlist_remove_member_from_level'), [WishlistMemberHelperPro::class, 'removeMemberFromLevel'], 10, 3);
