<?php
/**
 * View shared/math_captcha.
 *
 * @var int    $num1 The first number in the math captcha.
 * @var int    $num2 The second number in the math captcha.
 * @var string $data The encrypted answer to the math captcha.
 */

defined('ABSPATH') || exit;

$random_id = uniqid();
$label_id  = "mepr_math_captcha-{$random_id}";

// Translators: %s is a placeholder for the math question.
$label_encoded = base64_encode(sprintf(__('%s equals?', 'memberpress'), "{$num1} + {$num2}"));
?>

<div class="mp-form-row mepr_math_captcha">
    <div class="mp-form-label">
        <label for="mepr_math_quiz">
            <span id="<?php echo esc_attr($label_id); ?>" data-mepr-captcha-label="<?php echo esc_attr($label_encoded); ?>"></span> <span class="mepr-required" aria-hidden="true">*</span>
        </label>
    </div>

    <input type="text" name="mepr_math_quiz" id="mepr_math_quiz" value="" class="mepr-form-input" />
    <input type="hidden" name="mepr_math_data" value="<?php echo esc_attr($data); ?>" />

</div>
