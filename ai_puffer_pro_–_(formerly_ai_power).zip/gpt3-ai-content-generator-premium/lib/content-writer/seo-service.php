<?php

namespace WPAICG\ContentWriter\SEO;

use WPAICG\Core\AIPKit_AI_Caller;
use WPAICG\SEO\Audit\AIPKit_SEO_Audit_Engine;
use WP_Error;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Runs the paid Smart SEO audit/improvement loop for non-interactive generation flows.
 */
class AIPKit_Content_Writer_Smart_SEO_Service
{
    use AIPKit_Content_Writer_SEO_Image_Context_Trait;

    use AIPKit_Content_Writer_Smart_SEO_Prompt_Guidance_Trait;
    use AIPKit_Content_Writer_SEO_Audit_Context_Trait;
    use AIPKit_Content_Writer_SEO_Revision_Context_Trait;

    /**
     * @return mixed[]|\WP_Error
     */
    public function run(array $draft, array $config, AIPKit_AI_Caller $ai_caller, array $runtime_context = [])
    {
        if (!class_exists(AIPKit_Content_Writer_SEO_Config::class)) {
            return new WP_Error(
                'missing_smart_seo_config',
                __('Smart SEO configuration is unavailable.', 'gpt3-ai-content-generator')
            );
        }

        $requested_enabled = AIPKit_Content_Writer_SEO_Config::is_enabled($config);
        $config = AIPKit_Content_Writer_SEO_Config::normalize($config, false, true);
        if (!$requested_enabled) {
            return $this->build_skipped_result($draft, $config, 'disabled');
        }

        if (!AIPKit_Content_Writer_SEO_Config::is_pro_plan()) {
            return $this->build_skipped_result($draft, $config, 'pro_required');
        }

        $config = AIPKit_Content_Writer_SEO_Config::normalize($config, true, true);

        if (!class_exists(AIPKit_SEO_Audit_Engine::class)) {
            return new WP_Error(
                'missing_seo_audit_engine',
                __('Smart SEO audit engine is unavailable.', 'gpt3-ai-content-generator')
            );
        }

        $provider = $this->normalize_provider((string) ($runtime_context['ai_provider'] ?? $config['ai_provider'] ?? ''));
        $model = sanitize_text_field((string) ($runtime_context['ai_model'] ?? $config['ai_model'] ?? ''));
        if ($provider === '' || $model === '') {
            return new WP_Error(
                'missing_smart_seo_ai_model',
                __('AI provider and model are required for Smart SEO improvement.', 'gpt3-ai-content-generator')
            );
        }

        $target = 100;
        $max_passes = 3;
        $profile = $this->resolve_profile((string) ($config[AIPKit_Content_Writer_SEO_Config::KEY_PROFILE] ?? 'auto'));
        $working_draft = $this->normalize_draft($draft, $config, $runtime_context);
        $exclude_post_id = $this->resolve_excluded_post_id($config, $runtime_context);
        $disabled_rule_ids = AIPKit_Content_Writer_SEO_Config::disabled_rule_ids($config);

        if ($working_draft['title'] === '' && $working_draft['content'] === '') {
            return new WP_Error(
                'missing_smart_seo_draft',
                __('Generated title or content is required for Smart SEO.', 'gpt3-ai-content-generator')
            );
        }

        $passes = 0;
        $changed = false;
        $warnings = [];
        $change_summaries = [];
        $usage = $this->empty_usage();
        $smart_seo_model = null;
        $smart_seo_model_fallbacks = [];
        if (
            $working_draft['focus_keyword'] === ''
            && !empty($profile['supports_focus_keyword'])
            && AIPKit_Content_Writer_SEO_Config::is_rule_enabled($config, 'focus_keyword_exists')
        ) {
            $missing_keyword_result = $this->generate_missing_focus_keyword(
                $working_draft,
                $config,
                $runtime_context,
                $provider,
                $model,
                $ai_caller
            );

            if (is_wp_error($missing_keyword_result)) {
                $warnings[] = $missing_keyword_result->get_error_message();
            } elseif (!empty($missing_keyword_result['keyword'])) {
                $working_draft['focus_keyword'] = (string) $missing_keyword_result['keyword'];
                $changed = true;
                $change_summaries[] = sprintf(
                    /* translators: %s: generated focus keyphrase */
                    __('Added the Smart SEO focus keyphrase "%s".', 'gpt3-ai-content-generator'),
                    $working_draft['focus_keyword']
                );
                $this->add_usage($usage, $missing_keyword_result['usage'] ?? null);
                if (!empty($missing_keyword_result['warning'])) {
                    $warnings[] = (string) $missing_keyword_result['warning'];
                }
                if (!empty($missing_keyword_result['smart_seo_model']) && is_array($missing_keyword_result['smart_seo_model'])) {
                    $smart_seo_model = $missing_keyword_result['smart_seo_model'];
                }
                if (!empty($missing_keyword_result['smart_seo_model_fallbacks']) && is_array($missing_keyword_result['smart_seo_model_fallbacks'])) {
                    $smart_seo_model_fallbacks = array_merge($smart_seo_model_fallbacks, $missing_keyword_result['smart_seo_model_fallbacks']);
                }
            }
        }
        if ($working_draft['focus_keyword'] !== '' && class_exists(AIPKit_Content_Writer_Smart_SEO_Keyword_Resolver::class)) {
            $keyword_resolver = new AIPKit_Content_Writer_Smart_SEO_Keyword_Resolver();
            $keyword_resolution = $keyword_resolver->maybe_resolve_keyword(
                $working_draft['focus_keyword'],
                $config,
                $ai_caller,
                [
                    'ai_provider' => $provider,
                    'ai_model' => $model,
                    'topic' => (string) ($runtime_context['topic'] ?? $config['content_title'] ?? ''),
                    'title' => $working_draft['title'],
                    'content_summary' => wp_trim_words(wp_strip_all_tags($working_draft['content_html']), 80, ''),
                    'exclude_post_id' => $exclude_post_id,
                    'disabled_rule_ids' => $disabled_rule_ids,
                ]
            );

            if (!empty($keyword_resolution['changed'])) {
                $working_draft['focus_keyword'] = (string) $keyword_resolution['keyword'];
                $changed = true;
                $resolution_reason = isset($keyword_resolution['reason']) ? sanitize_key((string) $keyword_resolution['reason']) : '';
                switch ($resolution_reason) {
                    case 'length':
                        $change_summaries[] = sprintf(
                            /* translators: %s: resolved focus keyphrase. */
                            __('Shortened the focus keyphrase to "%s".', 'gpt3-ai-content-generator'),
                            $working_draft['focus_keyword']
                        );
                        break;
                    case 'locale':
                        $change_summaries[] = sprintf(
                            /* translators: %s: resolved focus keyphrase. */
                            __('Adjusted the focus keyphrase for SEO plugin matching to "%s".', 'gpt3-ai-content-generator'),
                            $working_draft['focus_keyword']
                        );
                        break;
                    default:
                        $change_summaries[] = sprintf(
                            /* translators: %s: resolved focus keyphrase. */
                            __('Changed duplicate focus keyphrase to "%s".', 'gpt3-ai-content-generator'),
                            $working_draft['focus_keyword']
                        );
                        break;
                }
                $this->add_usage($usage, $keyword_resolution['usage'] ?? null);
            } elseif (!empty($keyword_resolution['warning'])) {
                $warnings[] = (string) $keyword_resolution['warning'];
            }
            if (!empty($keyword_resolution['smart_seo_model']) && is_array($keyword_resolution['smart_seo_model'])) {
                $smart_seo_model = $keyword_resolution['smart_seo_model'];
            }
            if (!empty($keyword_resolution['smart_seo_model_fallbacks']) && is_array($keyword_resolution['smart_seo_model_fallbacks'])) {
                $smart_seo_model_fallbacks = array_merge($smart_seo_model_fallbacks, $keyword_resolution['smart_seo_model_fallbacks']);
            }
        }

        if (class_exists(AIPKit_Content_Writer_Smart_SEO_AIOSEO_Headline_Helper::class)) {
            $headline_adjusted_draft = AIPKit_Content_Writer_Smart_SEO_AIOSEO_Headline_Helper::maybe_improve_title($working_draft, [
                'profile' => $profile['profile'],
                'topic' => (string) ($runtime_context['topic'] ?? $config['content_title'] ?? ''),
                'keywords' => (string) ($runtime_context['keywords'] ?? $config['content_keywords'] ?? ''),
                'disabled_rule_ids' => $disabled_rule_ids,
            ]);
            if ($headline_adjusted_draft !== $working_draft) {
                $working_draft = $headline_adjusted_draft;
                $changed = true;
                $change_summaries[] = __('Improved the AIOSEO Headline Score title.', 'gpt3-ai-content-generator');
            }
        }
        if (class_exists(AIPKit_Content_Writer_Smart_SEO_AIOSEO_Content_Helper::class)) {
            $content_adjusted_draft = AIPKit_Content_Writer_Smart_SEO_AIOSEO_Content_Helper::maybe_improve_content($working_draft, [
                'profile' => $profile['profile'],
                'disabled_rule_ids' => $disabled_rule_ids,
            ]);
            if ($content_adjusted_draft !== $working_draft) {
                $working_draft = $content_adjusted_draft;
                $changed = true;
                $change_summaries[] = __('Moved the focus keyphrase into the AIOSEO introduction paragraph.', 'gpt3-ai-content-generator');
            }
        }
        if (class_exists(AIPKit_Content_Writer_Smart_SEO_Yoast_Content_Helper::class)) {
            $yoast_adjusted_draft = AIPKit_Content_Writer_Smart_SEO_Yoast_Content_Helper::maybe_improve_draft($working_draft, [
                'profile' => $profile['profile'],
                'disabled_rule_ids' => $disabled_rule_ids,
            ]);
            if ($yoast_adjusted_draft !== $working_draft) {
                $working_draft = $yoast_adjusted_draft;
                $changed = true;
                $change_summaries[] = __('Aligned the Yoast focus keyphrase across the introduction, meta description, and subheadings.', 'gpt3-ai-content-generator');
            }
        }
        if (class_exists(AIPKit_Content_Writer_Smart_SEO_Keyphrase_Content_Helper::class)) {
            $keyphrase_adjusted_draft = AIPKit_Content_Writer_Smart_SEO_Keyphrase_Content_Helper::maybe_align_draft($working_draft, [
                'profile' => $profile['profile'],
                'disabled_rule_ids' => $disabled_rule_ids,
            ]);
            if ($keyphrase_adjusted_draft !== $working_draft) {
                $working_draft = $keyphrase_adjusted_draft;
                $changed = true;
                $change_summaries[] = __('Aligned the Rank Math focus keyphrase across the article body and SEO fields.', 'gpt3-ai-content-generator');
            }
        }
        if (class_exists(AIPKit_Content_Writer_Smart_SEO_Title_Helper::class)) {
            $title_adjusted_draft = AIPKit_Content_Writer_Smart_SEO_Title_Helper::maybe_align_title($working_draft, [
                'profile' => $profile['profile'],
                'disabled_rule_ids' => $disabled_rule_ids,
            ]);
            if ($title_adjusted_draft !== $working_draft) {
                $working_draft = $title_adjusted_draft;
                $changed = true;
                $change_summaries[] = __('Aligned the Rank Math SEO title with the focus keyphrase.', 'gpt3-ai-content-generator');
            }
        }

        $audit = $this->audit_draft($working_draft, $config, $profile, $target, $passes, $exclude_post_id);
        $best_draft = $working_draft;
        $best_audit = $audit;
        $best_score = (int) ($audit['score'] ?? 0);

        while (
            (int) ($audit['score'] ?? 0) < $target
            && $passes < $max_passes
            && $this->has_fixable_issue($audit['checks'] ?? [])
        ) {
            $checks = $this->extract_fixable_checks($audit['checks'] ?? []);
            if (empty($checks)) {
                break;
            }

            $passes++;
            $previous_draft = $working_draft;
            $improve_result = $this->improve_draft(
                $working_draft,
                $checks,
                [
                    'target' => $target,
                    'profile' => $profile['profile'],
                    'profile_label' => $profile['label'],
                    'pass' => $passes,
                    'current_score' => (int) ($audit['score'] ?? 0),
                    'topic' => (string) ($runtime_context['topic'] ?? $config['content_title'] ?? ''),
                    'keywords' => (string) ($runtime_context['keywords'] ?? $config['content_keywords'] ?? ''),
                    'source_url' => (string) ($runtime_context['source_url'] ?? $config['source_url'] ?? ''),
                    'home_url' => home_url(),
                    'site_url' => site_url(),
                    'disabled_rule_ids' => $disabled_rule_ids,
                ],
                $provider,
                $model,
                $ai_caller
            );

            if (is_wp_error($improve_result)) {
                $error_data = $improve_result->get_error_data();
                if (is_array($error_data) && !empty($error_data['smart_seo_model_fallbacks']) && is_array($error_data['smart_seo_model_fallbacks'])) {
                    $smart_seo_model_fallbacks = array_merge($smart_seo_model_fallbacks, $error_data['smart_seo_model_fallbacks']);
                }
                $warnings[] = $improve_result->get_error_message();
                break;
            }

            $working_draft = $improve_result['draft'];
            $this->add_usage($usage, $improve_result['usage'] ?? null);
            if (!empty($improve_result['changes'])) {
                $change_summaries[] = (string) $improve_result['changes'];
            }
            if (!empty($improve_result['smart_seo_model']) && is_array($improve_result['smart_seo_model'])) {
                $smart_seo_model = $improve_result['smart_seo_model'];
            }
            if (!empty($improve_result['smart_seo_model_fallbacks']) && is_array($improve_result['smart_seo_model_fallbacks'])) {
                $smart_seo_model_fallbacks = array_merge($smart_seo_model_fallbacks, $improve_result['smart_seo_model_fallbacks']);
            }

            if ($working_draft === $previous_draft) {
                $warnings[] = __('Smart SEO improvement returned no further changes.', 'gpt3-ai-content-generator');
                break;
            }

            $changed = true;
            $audit = $this->audit_draft($working_draft, $config, $profile, $target, $passes, $exclude_post_id);
            $next_score = (int) ($audit['score'] ?? 0);
            if ($next_score > $best_score) {
                $best_score = $next_score;
                $best_draft = $working_draft;
                $best_audit = $audit;
            } else {
                $working_draft = $best_draft;
                $audit = $best_audit;
                $warnings[] = __('Discarded a lower-scoring Smart SEO revision and kept the best draft.', 'gpt3-ai-content-generator');
            }
        }

        $working_draft = $best_draft;
        $audit = $best_audit;
        $audit['passes'] = $passes;
        $audit['max_passes'] = $max_passes;
        $audit['can_improve'] = $this->has_fixable_issue($audit['checks'] ?? []);
        $audit['status'] = !empty($audit['reached_target']) ? 'target_reached' : 'needs_review';

        return [
            'enabled' => true,
            'skipped' => false,
            'draft' => $working_draft,
            'audit' => $audit,
            'score' => (int) ($audit['score'] ?? 0),
            'target' => $target,
            'profile' => (string) ($audit['profile'] ?? $profile['profile']),
            'profile_label' => $profile['label'],
            'profile_logo_url' => $profile['logo_url'] ?? '',
            'profile_logo_initials' => $profile['logo_initials'] ?? '',
            'passes' => $passes,
            'max_passes' => $max_passes,
            'reached_target' => !empty($audit['reached_target']),
            'can_improve' => !empty($audit['can_improve']),
            'changed' => $changed,
            'changes' => array_values(array_filter($change_summaries)),
            'warnings' => array_values(array_filter($warnings)),
            'usage' => $usage['total_tokens'] > 0 ? $usage : null,
            'smart_seo_model' => is_array($smart_seo_model) ? $smart_seo_model : null,
            'smart_seo_model_fallbacks' => self::unique_model_fallbacks($smart_seo_model_fallbacks),
            'disabled_rule_ids' => $disabled_rule_ids,
        ];
    }

    public static function prepare_content_html(string $content, string $format = ''): string
    {
        if (class_exists(\WPAICG\ContentWriter\AIPKit_Content_Writer_Output_Cleaner::class)) {
            $content = \WPAICG\ContentWriter\AIPKit_Content_Writer_Output_Cleaner::clean_article_content($content);
        }

        $normalized_format = sanitize_key($format);
        if ($normalized_format === 'html' || self::looks_like_html($content)) {
            $html = wp_kses_post($content);
            return self::ensure_block_html($html);
        }

        $html = \WPAICG\ContentWriter\AIPKit_Content_Writer_Output_Cleaner::convert_basic_markdown_to_html($content);

        return wp_kses_post(wpautop((string) $html));
    }

    public static function save_audit_meta(int $post_id, array $result): void
    {
        if ($post_id <= 0 || empty($result) || !empty($result['skipped'])) {
            return;
        }

        $audit = isset($result['audit']) && is_array($result['audit']) ? $result['audit'] : [];
        $checks = isset($audit['checks']) && is_array($audit['checks']) ? $audit['checks'] : [];
        $issues = array_values(array_filter($checks, static function ($check): bool {
            return is_array($check) && isset($check['status']) && (string) $check['status'] !== 'pass';
        }));

        update_post_meta($post_id, '_aipkit_smart_seo_score', (int) ($result['score'] ?? $audit['score'] ?? 0));
        update_post_meta($post_id, '_aipkit_smart_seo_target', (int) ($result['target'] ?? $audit['target'] ?? 100));
        update_post_meta($post_id, '_aipkit_smart_seo_profile', sanitize_key((string) ($result['profile'] ?? $audit['profile'] ?? 'aipkit')));
        update_post_meta($post_id, '_aipkit_smart_seo_profile_label', sanitize_text_field((string) ($result['profile_label'] ?? $audit['profile_label'] ?? '')));
        update_post_meta($post_id, '_aipkit_smart_seo_profile_logo_url', esc_url_raw((string) ($result['profile_logo_url'] ?? $audit['profile_logo_url'] ?? '')));
        update_post_meta($post_id, '_aipkit_smart_seo_profile_logo_initials', sanitize_text_field((string) ($result['profile_logo_initials'] ?? $audit['profile_logo_initials'] ?? '')));
        update_post_meta($post_id, '_aipkit_smart_seo_reached_target', !empty($result['reached_target']) ? '1' : '0');
        update_post_meta($post_id, '_aipkit_smart_seo_passes', (int) ($result['passes'] ?? 0));
        update_post_meta($post_id, '_aipkit_smart_seo_max_passes', (int) ($result['max_passes'] ?? 3));
        update_post_meta($post_id, '_aipkit_smart_seo_checks', $checks);
        update_post_meta($post_id, '_aipkit_smart_seo_issues', $issues);
        update_post_meta($post_id, '_aipkit_smart_seo_last_run', current_time('mysql'));
        $smart_seo_model = isset($result['smart_seo_model']) && is_array($result['smart_seo_model']) ? $result['smart_seo_model'] : [];
        if (!empty($smart_seo_model)) {
            update_post_meta($post_id, '_aipkit_smart_seo_ai_provider', sanitize_text_field((string) ($smart_seo_model['provider'] ?? '')));
            update_post_meta($post_id, '_aipkit_smart_seo_ai_model', sanitize_text_field((string) ($smart_seo_model['model'] ?? '')));
        } else {
            delete_post_meta($post_id, '_aipkit_smart_seo_ai_provider');
            delete_post_meta($post_id, '_aipkit_smart_seo_ai_model');
        }
        if (!empty($result['smart_seo_model_fallbacks']) && is_array($result['smart_seo_model_fallbacks'])) {
            update_post_meta($post_id, '_aipkit_smart_seo_model_fallbacks', self::unique_model_fallbacks($result['smart_seo_model_fallbacks']));
        } else {
            delete_post_meta($post_id, '_aipkit_smart_seo_model_fallbacks');
        }
    }

    private static function looks_like_html(string $content): bool
    {
        return (bool) preg_match('/<\s*(p|h[1-6]|ul|ol|li|blockquote|table|figure|img|a|strong|em)\b/i', $content);
    }

    private static function ensure_block_html(string $html): string
    {
        if (trim(wp_strip_all_tags($html)) === '') {
            return '';
        }

        if (preg_match('/<\s*(p|h[1-6]|ul|ol|blockquote|table|figure|img)\b/i', $html)) {
            return $html;
        }

        return wp_kses_post(wpautop($html));
    }

    private function normalize_draft(array $draft, array $config, array $runtime_context): array
    {
        $content = isset($draft['content']) ? (string) $draft['content'] : '';
        $format = isset($draft['content_format']) ? (string) $draft['content_format'] : (string) ($runtime_context['content_format'] ?? '');
        $content_html = isset($draft['content_html']) && trim((string) $draft['content_html']) !== ''
            ? self::prepare_content_html((string) $draft['content_html'], 'html')
            : self::prepare_content_html($content, $format);

        $title = isset($draft['title']) ? sanitize_text_field((string) $draft['title']) : '';
        $focus_keyword = isset($draft['focus_keyword']) ? sanitize_text_field((string) $draft['focus_keyword']) : '';
        $slug = isset($draft['slug']) ? sanitize_title((string) $draft['slug']) : '';

        if ($slug === '' && isset($config['generate_seo_slug']) && (string) $config['generate_seo_slug'] === '1') {
            $slug_source = trim($focus_keyword) !== '' ? $focus_keyword : $title;
            $slug = sanitize_title($slug_source);
        }

        $normalized = [
            'title' => $title,
            'content' => $content_html,
            'content_html' => $content_html,
            'meta_description' => isset($draft['meta_description']) ? sanitize_textarea_field((string) $draft['meta_description']) : '',
            'focus_keyword' => $focus_keyword,
            'excerpt' => isset($draft['excerpt']) ? sanitize_textarea_field((string) $draft['excerpt']) : '',
            'tags' => isset($draft['tags']) ? sanitize_text_field((string) $draft['tags']) : '',
            'slug' => $slug,
            'post_type' => isset($draft['post_type']) ? sanitize_key((string) $draft['post_type']) : sanitize_key((string) ($config['post_type'] ?? 'post')),
            'images' => $this->extract_images($draft['image_data'] ?? $runtime_context['image_data'] ?? []),
            'featured_image_alt' => $this->extract_featured_image_alt($draft['image_data'] ?? $runtime_context['image_data'] ?? []),
        ];

        return class_exists(AIPKit_Content_Writer_Smart_SEO_Image_Tag_Guard::class)
            ? AIPKit_Content_Writer_Smart_SEO_Image_Tag_Guard::sanitize_draft($normalized)
            : $normalized;
    }

    private function audit_draft(array $draft, array $config, array $profile, int $target, int $passes, int $exclude_post_id = 0): array
    {
        $internal_link_candidates = class_exists(AIPKit_Content_Writer_Smart_SEO_Internal_Link_Helper::class)
            ? AIPKit_Content_Writer_Smart_SEO_Internal_Link_Helper::get_candidates($draft, [
                'topic' => (string) ($config['content_title'] ?? ''),
                'keywords' => (string) ($config['content_keywords'] ?? ''),
                'profile' => $profile['profile'],
                'home_url' => home_url(),
                'site_url' => site_url(),
            ])
            : [];
        $context = [
            'target' => $target,
            'profile' => $profile['profile'],
            'profile_label' => $profile['label'],
            'supports_focus_keyword' => $profile['supports_focus_keyword'],
            'generate_seo_slug' => isset($config['generate_seo_slug']) && (string) $config['generate_seo_slug'] === '1' ? '1' : '0',
            'generate_toc' => isset($config['generate_toc']) && (string) $config['generate_toc'] === '1' ? '1' : '0',
            'min_words' => $this->minimum_words_for_length(isset($config['content_length']) ? sanitize_key((string) $config['content_length']) : 'medium'),
            'home_url' => home_url(),
            'site_url' => site_url(),
            'used_focus_keyword_count' => $this->count_used_focus_keyword((string) ($draft['focus_keyword'] ?? ''), $exclude_post_id),
            'disabled_rule_ids' => AIPKit_Content_Writer_SEO_Config::disabled_rule_ids($config),
            'approved_internal_urls' => class_exists(AIPKit_Content_Writer_Smart_SEO_Internal_Link_Helper::class)
                ? AIPKit_Content_Writer_Smart_SEO_Internal_Link_Helper::get_candidate_urls($internal_link_candidates)
                : [],
        ];

        $engine = new AIPKit_SEO_Audit_Engine();
        $result = $engine->audit($draft, $context)->to_array();
        $result['profile_label'] = $profile['label'];
        $result['profile_logo_url'] = $profile['logo_url'] ?? '';
        $result['profile_logo_initials'] = $profile['logo_initials'] ?? '';
        $result['status'] = !empty($result['reached_target']) ? 'target_reached' : 'needs_review';
        $result['passes'] = $passes;
        $result['max_passes'] = 3;
        $result['can_improve'] = $this->has_fixable_issue($result['checks'] ?? []);

        return $result;
    }

    /**
     * @return mixed[]|\WP_Error
     */
    private function improve_draft(array $draft, array $checks, array $context, string $provider, string $model, AIPKit_AI_Caller $ai_caller)
    {
        $internal_link_candidates = class_exists(AIPKit_Content_Writer_Smart_SEO_Internal_Link_Helper::class)
            ? AIPKit_Content_Writer_Smart_SEO_Internal_Link_Helper::get_candidates($draft, $context)
            : [];
        $context['internal_link_candidates'] = $internal_link_candidates;
        $prompt = $this->build_prompt($draft, $checks, $context);
        $system_instruction = implode(' ', [
            'You are an expert SEO editor for WordPress content.',
            'Rewrite only what is needed to satisfy the supplied audit checks.',
            'Return a single valid JSON object and no surrounding prose.',
        ]);

        $ai_params = $this->revision_ai_params($context);
        $result = class_exists(AIPKit_Content_Writer_Smart_SEO_Model_Policy::class)
            ? AIPKit_Content_Writer_Smart_SEO_Model_Policy::make_standard_call(
                $ai_caller,
                $provider,
                $model,
                [['role' => 'user', 'content' => $prompt]],
                $ai_params,
                $system_instruction,
                []
            )
            : $ai_caller->make_standard_call(
                $provider,
                $model,
                [['role' => 'user', 'content' => $prompt]],
                $ai_params,
                $system_instruction,
                []
            );

        if (is_wp_error($result)) {
            return $result;
        }

        $decoded = $this->decode_json_response((string) ($result['content'] ?? ''));
        if (is_wp_error($decoded)) {
            $retry_instruction = $system_instruction . ' Your previous response was not valid JSON. Return only the JSON object requested by the prompt.';
            $retry_prompt = $prompt . "\n\nThe previous Smart SEO response could not be parsed as JSON. Retry now with one complete valid JSON object only. Do not use markdown fences, comments, explanations, or trailing text.";
            $retry_params = $this->revision_ai_params($context, true);
            $retry_result = class_exists(AIPKit_Content_Writer_Smart_SEO_Model_Policy::class)
                ? AIPKit_Content_Writer_Smart_SEO_Model_Policy::make_standard_call(
                    $ai_caller,
                    $provider,
                    $model,
                    [['role' => 'user', 'content' => $retry_prompt]],
                    $retry_params,
                    $retry_instruction,
                    []
                )
                : $ai_caller->make_standard_call(
                    $provider,
                    $model,
                    [['role' => 'user', 'content' => $retry_prompt]],
                    $retry_params,
                    $retry_instruction,
                    []
                );

            if (is_wp_error($retry_result)) {
                return $retry_result;
            }

            $retry_decoded = $this->decode_json_response((string) ($retry_result['content'] ?? ''));
            if (is_wp_error($retry_decoded)) {
                return $decoded;
            }

            $result = $retry_result;
            $decoded = $retry_decoded;
        }

        $improved_draft = $this->normalize_improved_draft($decoded, $draft);
        if (class_exists(AIPKit_Content_Writer_Smart_SEO_Internal_Link_Helper::class)) {
            $improved_draft['content_html'] = AIPKit_Content_Writer_Smart_SEO_Internal_Link_Helper::clean_invalid_internal_links(
                (string) ($improved_draft['content_html'] ?? ''),
                $internal_link_candidates,
                $context
            );
            $improved_draft['content'] = $improved_draft['content_html'];
        }
        if (class_exists(AIPKit_Content_Writer_Smart_SEO_External_Link_Helper::class)) {
            $improved_draft['content_html'] = AIPKit_Content_Writer_Smart_SEO_External_Link_Helper::clean_outbound_links(
                (string) ($improved_draft['content_html'] ?? ''),
                $context
            );
            $improved_draft['content'] = $improved_draft['content_html'];
        }
        if (class_exists(AIPKit_Content_Writer_Smart_SEO_AIOSEO_Headline_Helper::class)) {
            $improved_draft = AIPKit_Content_Writer_Smart_SEO_AIOSEO_Headline_Helper::maybe_improve_title($improved_draft, $context);
        }
        if (class_exists(AIPKit_Content_Writer_Smart_SEO_AIOSEO_Content_Helper::class)) {
            $improved_draft = AIPKit_Content_Writer_Smart_SEO_AIOSEO_Content_Helper::maybe_improve_content($improved_draft, $context);
        }
        if (class_exists(AIPKit_Content_Writer_Smart_SEO_Yoast_Content_Helper::class)) {
            $improved_draft = AIPKit_Content_Writer_Smart_SEO_Yoast_Content_Helper::maybe_improve_draft($improved_draft, $context);
        }
        if (class_exists(AIPKit_Content_Writer_Smart_SEO_Keyphrase_Content_Helper::class)) {
            $improved_draft = AIPKit_Content_Writer_Smart_SEO_Keyphrase_Content_Helper::maybe_align_draft($improved_draft, $context);
        }
        if (class_exists(AIPKit_Content_Writer_Smart_SEO_Image_Tag_Guard::class)) {
            $improved_draft = AIPKit_Content_Writer_Smart_SEO_Image_Tag_Guard::sanitize_draft($improved_draft);
        }
        if (!$this->can_change_focus_keyword($checks)) {
            $improved_draft['focus_keyword'] = $draft['focus_keyword'];
        }
        if (class_exists(AIPKit_Content_Writer_Smart_SEO_Title_Helper::class)) {
            $improved_draft = AIPKit_Content_Writer_Smart_SEO_Title_Helper::maybe_align_title($improved_draft, $context);
        }
        if (
            class_exists(AIPKit_Content_Writer_Smart_SEO_Naturalness_Guard::class)
            && AIPKit_Content_Writer_Smart_SEO_Naturalness_Guard::should_keep_previous($improved_draft, $draft)
        ) {
            return [
                'draft' => $draft,
                'changes' => __('Skipped an SEO rewrite that forced awkward exact-keyphrase phrasing.', 'gpt3-ai-content-generator'),
                'usage' => $result['usage'] ?? null,
                'smart_seo_model' => $result['smart_seo_model'] ?? null,
                'smart_seo_model_fallbacks' => $result['smart_seo_model_fallbacks'] ?? [],
            ];
        }

        return [
            'draft' => $improved_draft,
            'changes' => isset($decoded['change_summary']) ? sanitize_text_field((string) $decoded['change_summary']) : '',
            'usage' => $result['usage'] ?? null,
            'smart_seo_model' => $result['smart_seo_model'] ?? null,
            'smart_seo_model_fallbacks' => $result['smart_seo_model_fallbacks'] ?? [],
        ];
    }

    /**
     * @return mixed[]|\WP_Error
     */
    private function generate_missing_focus_keyword(array $draft, array $config, array $runtime_context, string $provider, string $model, AIPKit_AI_Caller $ai_caller)
    {
        $summary = wp_trim_words(wp_strip_all_tags((string) ($draft['content_html'] ?? $draft['content'] ?? '')), 90, '');
        $topic = sanitize_text_field((string) ($runtime_context['topic'] ?? $config['content_title'] ?? ''));
        $prompt = implode("\n\n", array_filter([
            'Choose the best SEO focus keyphrase for this generated WordPress draft.',
            !empty($draft['title']) ? sprintf('Article title: %s', (string) $draft['title']) : '',
            $topic !== '' ? sprintf('Original topic: %s', $topic) : '',
            $summary !== '' ? sprintf('Article summary: %s', $summary) : '',
            'Rules:',
            '- Return only one plain-text keyphrase.',
            '- Use 2 to 4 words when possible.',
            '- Prefer wording that already appears naturally in the title, article, or summary.',
            '- Preserve the article language and search intent.',
            '- Do not include quotes, punctuation, commas, hashtags, labels, or explanations.',
        ]));

        $result = class_exists(AIPKit_Content_Writer_Smart_SEO_Model_Policy::class)
            ? AIPKit_Content_Writer_Smart_SEO_Model_Policy::make_standard_call(
                $ai_caller,
                $provider,
                $model,
                [['role' => 'user', 'content' => $prompt]],
                ['temperature' => 0.2, 'top_p' => null],
                'You are an SEO strategist. Return one focus keyphrase only.',
                []
            )
            : $ai_caller->make_standard_call(
                $provider,
                $model,
                [['role' => 'user', 'content' => $prompt]],
                ['temperature' => 0.2, 'top_p' => null],
                'You are an SEO strategist. Return one focus keyphrase only.',
                []
            );

        if (is_wp_error($result)) {
            $fallback_keyword = $this->derive_focus_keyword_from_draft($draft, $config, $runtime_context);
            if ($fallback_keyword === '') {
                return $result;
            }

            return [
                'keyword' => $fallback_keyword,
                'usage' => null,
                'warning' => __('Smart SEO used a title-based focus keyphrase fallback because keyword generation failed.', 'gpt3-ai-content-generator'),
                'smart_seo_model_fallbacks' => $this->extract_model_fallbacks_from_error($result),
            ];
        }

        $keyword = $this->normalize_focus_keyword((string) ($result['content'] ?? ''));
        $warning = '';
        if ($keyword === '') {
            $keyword = $this->derive_focus_keyword_from_draft($draft, $config, $runtime_context);
            if ($keyword !== '') {
                $warning = __('Smart SEO used a title-based focus keyphrase fallback because keyword generation returned no usable keyphrase.', 'gpt3-ai-content-generator');
            }
        }

        if ($keyword === '') {
            return new WP_Error(
                'missing_smart_seo_focus_keyword',
                __('Smart SEO could not determine a focus keyphrase for this draft.', 'gpt3-ai-content-generator')
            );
        }

        return [
            'keyword' => $keyword,
            'usage' => $result['usage'] ?? null,
            'warning' => $warning,
            'smart_seo_model' => $result['smart_seo_model'] ?? null,
            'smart_seo_model_fallbacks' => $result['smart_seo_model_fallbacks'] ?? [],
        ];
    }

    private function derive_focus_keyword_from_draft(array $draft, array $config, array $runtime_context): string
    {
        $sources = [
            (string) ($draft['title'] ?? ''),
            (string) ($runtime_context['topic'] ?? ''),
            (string) ($config['content_title'] ?? ''),
            wp_trim_words(wp_strip_all_tags((string) ($draft['content_html'] ?? $draft['content'] ?? '')), 18, ''),
        ];

        $first_candidate = '';
        foreach ($sources as $source) {
            $source = html_entity_decode(wp_strip_all_tags($source), ENT_QUOTES, get_bloginfo('charset') ?: 'UTF-8');
            $source = preg_replace('/\s+/u', ' ', $source);
            $source = trim(is_string($source) ? $source : '');
            if ($source === '') {
                continue;
            }

            $parts = preg_split('/\s+[–—-]\s+|[?!|:;]+/u', $source);
            $parts = is_array($parts) ? $parts : [$source];
            foreach ($parts as $part) {
                $candidate = $this->normalize_focus_keyword((string) $part);
                if ($candidate === '') {
                    continue;
                }
                if ($first_candidate === '') {
                    $first_candidate = $candidate;
                }
                if ($this->count_words($candidate) >= 2) {
                    return $candidate;
                }
            }
        }

        return $first_candidate;
    }

    private function normalize_focus_keyword(string $keyword): string
    {
        $keyword = html_entity_decode(wp_strip_all_tags($keyword), ENT_QUOTES, get_bloginfo('charset') ?: 'UTF-8');
        $keyword_parts = preg_split('/[\r\n,]+/u', $keyword);
        $keyword = is_array($keyword_parts) ? ($keyword_parts[0] ?? '') : '';
        $keyword = preg_replace('/^\s*\d+[\).\-\s]+/u', '', (string) $keyword);
        $keyword = preg_replace('/^\s*(focus\s+(keyword|keyphrase)|keyword|keyphrase)\s*[:\-]\s*/iu', '', (string) $keyword);
        $keyword = trim((string) $keyword, " \t\n\r\0\x0B\"'“”‘’.,;:!?");
        $keyword = preg_replace('/\s+/u', ' ', $keyword);
        $keyword = trim(is_string($keyword) ? $keyword : '');
        if ($keyword === '') {
            return '';
        }

        $words = preg_split('/\s+/u', $keyword, -1, PREG_SPLIT_NO_EMPTY);
        if (is_array($words) && count($words) > 4) {
            $keyword = implode(' ', array_slice($words, 0, 4));
        }

        return sanitize_text_field($keyword);
    }

    private function count_words(string $text): int
    {
        $words = preg_split('/\s+/u', trim($text), -1, PREG_SPLIT_NO_EMPTY);
        return is_array($words) ? count($words) : 0;
    }

    private function extract_model_fallbacks_from_error(WP_Error $error): array
    {
        $data = $error->get_error_data();
        return is_array($data) && !empty($data['smart_seo_model_fallbacks']) && is_array($data['smart_seo_model_fallbacks'])
            ? $data['smart_seo_model_fallbacks']
            : [];
    }

    private function build_prompt(array $draft, array $checks, array $context): string
    {
        return $this->build_smart_seo_revision_prompt($draft, $checks, $context, [
            'include_source_url' => true,
        ]);
    }

    /**
     * @return mixed[]|\WP_Error
     */
    private function decode_json_response(string $content)
    {
        $clean = trim($content);
        $clean = preg_replace('/^```(?:json)?\s*/i', '', $clean);
        $clean = preg_replace('/\s*```$/', '', (string) $clean);

        $decoded = json_decode((string) $clean, true);
        if (is_array($decoded)) {
            return $decoded;
        }

        if (preg_match('/\{.*\}/s', (string) $clean, $match)) {
            $decoded = json_decode($match[0], true);
            if (is_array($decoded)) {
                return $decoded;
            }
        }

        return new WP_Error(
            'smart_seo_invalid_json',
            __('Smart SEO improvement did not return a valid draft update.', 'gpt3-ai-content-generator')
        );
    }

    private function normalize_improved_draft(array $decoded, array $fallback): array
    {
        $content_html = isset($decoded['content_html']) ? self::prepare_content_html((string) $decoded['content_html'], 'html') : $fallback['content_html'];
        if (trim(wp_strip_all_tags($content_html)) === '') {
            $content_html = $fallback['content_html'];
        }

        $normalized = [
            'title' => isset($decoded['title']) && trim((string) $decoded['title']) !== ''
                ? sanitize_text_field((string) $decoded['title'])
                : $fallback['title'],
            'content' => $content_html,
            'content_html' => $content_html,
            'meta_description' => isset($decoded['meta_description'])
                ? sanitize_textarea_field((string) $decoded['meta_description'])
                : $fallback['meta_description'],
            'focus_keyword' => isset($decoded['focus_keyword'])
                ? sanitize_text_field((string) $decoded['focus_keyword'])
                : $fallback['focus_keyword'],
            'excerpt' => isset($decoded['excerpt'])
                ? sanitize_textarea_field((string) $decoded['excerpt'])
                : $fallback['excerpt'],
            'tags' => isset($decoded['tags'])
                ? sanitize_text_field((string) $decoded['tags'])
                : $fallback['tags'],
            'slug' => isset($decoded['slug']) && trim((string) $decoded['slug']) !== ''
                ? sanitize_title((string) $decoded['slug'])
                : $fallback['slug'],
            'post_type' => $fallback['post_type'],
            'images' => isset($fallback['images']) && is_array($fallback['images']) ? $fallback['images'] : [],
            'featured_image_alt' => isset($fallback['featured_image_alt']) ? (string) $fallback['featured_image_alt'] : '',
        ];

        if (class_exists(\WPAICG\ContentWriter\AIPKit_Content_Writer_Output_Cleaner::class)) {
            $normalized['title'] = \WPAICG\ContentWriter\AIPKit_Content_Writer_Output_Cleaner::clean_title(
                (string) $normalized['title'],
                (string) $normalized['focus_keyword']
            );
            $normalized['meta_description'] = \WPAICG\ContentWriter\AIPKit_Content_Writer_Output_Cleaner::clean_meta_description(
                (string) $normalized['meta_description']
            );
            $normalized['content_html'] = \WPAICG\ContentWriter\AIPKit_Content_Writer_Output_Cleaner::clean_article_content(
                (string) $normalized['content_html'],
                (string) $normalized['focus_keyword']
            );
            $normalized['content'] = $normalized['content_html'];
        }

        return class_exists(AIPKit_Content_Writer_Smart_SEO_Image_Tag_Guard::class)
            ? AIPKit_Content_Writer_Smart_SEO_Image_Tag_Guard::sanitize_draft($normalized)
            : $normalized;
    }

    private function extract_fixable_checks(array $raw_checks): array
    {
        $checks = [];
        foreach ($raw_checks as $check) {
            if (!is_array($check)) {
                continue;
            }
            $status = isset($check['status']) ? sanitize_key((string) $check['status']) : '';
            if ($status === 'pass' || empty($check['fixable'])) {
                continue;
            }

            $message = isset($check['message']) ? trim(wp_strip_all_tags((string) $check['message'])) : '';
            $label = isset($check['label']) ? trim(wp_strip_all_tags((string) $check['label'])) : '';
            if ($message === '' && $label === '') {
                continue;
            }

            $checks[] = [
                'id' => isset($check['id']) ? sanitize_key((string) $check['id']) : '',
                'label' => $label,
                'message' => $message,
                'field' => isset($check['field']) ? sanitize_key((string) $check['field']) : '',
                'severity' => isset($check['severity']) ? sanitize_key((string) $check['severity']) : 'medium',
            ];

            if (count($checks) >= 10) {
                break;
            }
        }

        return $checks;
    }

    private function can_change_focus_keyword(array $checks): bool
    {
        foreach ($checks as $check) {
            if (!is_array($check)) {
                continue;
            }

            $id = isset($check['id']) ? sanitize_key((string) $check['id']) : '';
            if ($id === 'previously_used_keyphrase' || $id === 'focus_keyword_length' || $id === 'focus_keyword_exists') {
                return true;
            }

            $label = isset($check['label']) ? strtolower((string) $check['label']) : '';
            $message = isset($check['message']) ? strtolower((string) $check['message']) : '';
            $text = $label . ' ' . $message;
            if (
                strpos($text, 'previously used') !== false
                || strpos($text, 'used this keyphrase') !== false
                || strpos($text, 'keyphrase length') !== false
                || strpos($text, 'focus keyword length') !== false
                || strpos($text, 'focus keyword exists') !== false
                || strpos($text, 'add a focus keyword') !== false
            ) {
                return true;
            }
        }

        return false;
    }

    private function resolve_excluded_post_id(array $config, array $runtime_context): int
    {
        foreach (['exclude_post_id', 'post_id', 'current_post_id', 'draft_post_id', 'object_id', 'objectID'] as $key) {
            $post_id = isset($runtime_context[$key]) ? absint($runtime_context[$key]) : 0;
            if ($post_id > 0) {
                return $post_id;
            }
        }

        foreach (['exclude_post_id', 'post_id', 'current_post_id', 'draft_post_id', 'object_id', 'objectID'] as $key) {
            $post_id = isset($config[$key]) ? absint($config[$key]) : 0;
            if ($post_id > 0) {
                return $post_id;
            }
        }

        return 0;
    }

    /**
     * @param mixed $image_data
     */
    private function extract_images($image_data): array
    {
        if (is_string($image_data)) {
            $decoded = json_decode(trim($image_data), true);
            if (!is_array($decoded)) {
                $decoded = json_decode(stripslashes(trim($image_data)), true);
            }
            $image_data = is_array($decoded) ? $decoded : [];
        }

        if (!is_array($image_data)) {
            return [];
        }

        $images = [];
        foreach ($image_data['in_content_images'] ?? [] as $image) {
            if (!is_array($image)) {
                continue;
            }
            $images[] = $this->normalize_image($image);
        }

        return array_values(array_filter($images, static function (array $image): bool {
            return ($image['src'] ?? '') !== '' || ($image['alt'] ?? '') !== '';
        }));
    }

    /**
     * @param mixed $image_data
     */
    private function extract_featured_image_alt($image_data): string
    {
        if (is_string($image_data)) {
            $decoded = json_decode(trim($image_data), true);
            if (!is_array($decoded)) {
                $decoded = json_decode(stripslashes(trim($image_data)), true);
            }
            $image_data = is_array($decoded) ? $decoded : [];
        }

        if (!is_array($image_data)) {
            return '';
        }

        foreach (['featured_image_alt', 'featured_alt', 'featured_alt_text'] as $key) {
            if (!empty($image_data[$key]) && is_scalar($image_data[$key])) {
                return sanitize_text_field((string) $image_data[$key]);
            }
        }

        $attachment_id = isset($image_data['featured_image_id']) ? absint($image_data['featured_image_id']) : 0;
        if ($attachment_id > 0) {
            $stored_alt = get_post_meta($attachment_id, '_wp_attachment_image_alt', true);
            return is_string($stored_alt) ? sanitize_text_field($stored_alt) : '';
        }

        return '';
    }

    private function empty_usage(): array
    {
        return [
            'input_tokens' => 0,
            'output_tokens' => 0,
            'total_tokens' => 0,
            'provider_raw' => [],
        ];
    }

    /**
     * @param mixed $usage
     */
    private function add_usage(array &$aggregate, $usage): void
    {
        if (!is_array($usage)) {
            return;
        }

        $aggregate['input_tokens'] += (int) ($usage['input_tokens'] ?? 0);
        $aggregate['output_tokens'] += (int) ($usage['output_tokens'] ?? 0);
        $aggregate['total_tokens'] += (int) ($usage['total_tokens'] ?? 0);
        if (isset($usage['provider_raw'])) {
            $aggregate['provider_raw'][] = $usage['provider_raw'];
        }
    }

    private function build_skipped_result(array $draft, array $config, string $reason): array
    {
        return [
            'enabled' => false,
            'skipped' => true,
            'skip_reason' => sanitize_key($reason),
            'draft' => $draft,
            'audit' => null,
            'score' => null,
            'target' => (int) ($config[AIPKit_Content_Writer_SEO_Config::KEY_TARGET] ?? 100),
            'passes' => 0,
            'max_passes' => (int) ($config[AIPKit_Content_Writer_SEO_Config::KEY_MAX_PASSES] ?? 3),
            'reached_target' => false,
            'changed' => false,
            'usage' => null,
            'disabled_rule_ids' => AIPKit_Content_Writer_SEO_Config::disabled_rule_ids($config),
        ];
    }
}
