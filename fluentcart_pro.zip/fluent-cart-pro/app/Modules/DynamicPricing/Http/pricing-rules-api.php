<?php

use FluentCart\Framework\Http\Router;
use FluentCartPro\App\Modules\DynamicPricing\Http\Controllers\PricingRuleController;

/**
 * @var $router Router
 */

$router->prefix('pricing_rules')->withPolicy('DynamicPricingPolicy')->group(function ($router) {
    $router->get('/', [PricingRuleController::class, 'index'])->meta([
        'permissions' => 'dynamic_pricing/view'
    ]);

    $router->post('/', [PricingRuleController::class, 'store'])->meta([
        'permissions' => 'dynamic_pricing/manage'
    ]);

    $router->get('/{id}', [PricingRuleController::class, 'show'])->meta([
        'permissions' => 'dynamic_pricing/view'
    ])->int('id');

    $router->put('/{id}', [PricingRuleController::class, 'update'])->meta([
        'permissions' => 'dynamic_pricing/manage'
    ])->int('id');

    $router->put('/{id}/status', [PricingRuleController::class, 'updateStatus'])->meta([
        'permissions' => 'dynamic_pricing/manage'
    ])->int('id');

    $router->delete('/{id}', [PricingRuleController::class, 'delete'])->meta([
        'permissions' => 'dynamic_pricing/manage'
    ])->int('id');
});
