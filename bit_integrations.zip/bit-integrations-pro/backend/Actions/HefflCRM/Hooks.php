<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Actions\HefflCRM\HefflCRMRecordHelper;
use BitApps\IntegrationsPro\Config;
use BitApps\IntegrationsPro\Core\Util\Hooks;

Hooks::filter(Config::withFreePrefix('heffl_crm_create_lead'), [HefflCRMRecordHelper::class, 'createLead'], 10, 4);
Hooks::filter(Config::withFreePrefix('heffl_crm_create_client'), [HefflCRMRecordHelper::class, 'createClient'], 10, 4);
Hooks::filter(Config::withFreePrefix('heffl_crm_create_deal'), [HefflCRMRecordHelper::class, 'createDeal'], 10, 4);
