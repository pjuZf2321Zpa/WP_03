<?php
/**
 * Dashboard "My Reservations" search form.
 *
 * The form submits with GET so the search term stays in the page url. WordPress builds the
 * pagination links with get_pagenum_link(), which keeps the current query string, so the active
 * search survives when the user moves to page 2 and beyond.
 */

// resolve the page permalink once, it is both the form action and the source of the hidden fields below
$wpestate_rez_search_link = wpestate_get_template_link('user_dashboard_my_reservations.php');

// a GET form replaces the whole query string of its action url, so any argument already in that url
// (sites without pretty permalinks get ?page_id=N) has to be sent again as a hidden field
$wpestate_rez_search_args  = array();
$wpestate_rez_search_query = wp_parse_url( $wpestate_rez_search_link, PHP_URL_QUERY );
if ( ! empty( $wpestate_rez_search_query ) ) {
    wp_parse_str( $wpestate_rez_search_query, $wpestate_rez_search_args );
}

// keep the term that is currently filtering the list so the input still shows it after a search
$wpestate_rez_search_value = '';
if ( isset( $_GET['wpestate_prop_title'] ) ) {
    $wpestate_rez_search_value = sanitize_text_field( wp_unslash( $_GET['wpestate_prop_title'] ) );
}
?>
<div class="search_dashborad_header">
    <form method="get" action="<?php echo esc_url( $wpestate_rez_search_link );?>">
    <?php
    wp_nonce_field( 'wpestate_dash_rez_search', 'wpestate_dash_rez_search_nonce', false );

    foreach ( $wpestate_rez_search_args as $wpestate_rez_search_key => $wpestate_rez_search_arg ) {
        print '<input type="hidden" name="'.esc_attr( $wpestate_rez_search_key ).'" value="'.esc_attr( $wpestate_rez_search_arg ).'" />';
    }
    ?>
    <div class="col-md-4">
        <input type="text" id="title" class="form-control" value="<?php echo esc_attr( $wpestate_rez_search_value );?>" size="20" name="wpestate_prop_title" placeholder="<?php esc_html_e('Search by listing name.','wprentals');?>">
    </div>
    <div class="col-md-6">
        <input type="submit" class="wpb_btn-info wpb_btn-small wpestate_vc_button  vc_button" value="<?php esc_html_e('Search','wprentals');?>">
    </div>
    </form>
</div>
