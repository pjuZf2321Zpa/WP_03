<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Actions\BookingsAndAppointmentsForWoocommerce\BookingsAndAppointmentsForWoocommerceProHelper;
use BitApps\IntegrationsPro\Config;
use BitApps\IntegrationsPro\Core\Util\Hooks;

Hooks::filter(Config::withFreePrefix('bookings_and_appointments_for_woocommerce_create_booking'), [BookingsAndAppointmentsForWoocommerceProHelper::class, 'createBooking'], 10, 3);
Hooks::filter(Config::withFreePrefix('bookings_and_appointments_for_woocommerce_update_booking_status'), [BookingsAndAppointmentsForWoocommerceProHelper::class, 'updateBookingStatus'], 10, 3);
Hooks::filter(Config::withFreePrefix('bookings_and_appointments_for_woocommerce_confirm_booking'), [BookingsAndAppointmentsForWoocommerceProHelper::class, 'confirmBooking'], 10, 2);
Hooks::filter(Config::withFreePrefix('bookings_and_appointments_for_woocommerce_cancel_booking'), [BookingsAndAppointmentsForWoocommerceProHelper::class, 'cancelBooking'], 10, 2);
Hooks::filter(Config::withFreePrefix('bookings_and_appointments_for_woocommerce_delete_booking'), [BookingsAndAppointmentsForWoocommerceProHelper::class, 'deleteBooking'], 10, 2);
Hooks::filter(Config::withFreePrefix('bookings_and_appointments_for_woocommerce_reschedule_booking'), [BookingsAndAppointmentsForWoocommerceProHelper::class, 'rescheduleBooking'], 10, 2);
Hooks::filter(Config::withFreePrefix('bookings_and_appointments_for_woocommerce_update_booking_notes'), [BookingsAndAppointmentsForWoocommerceProHelper::class, 'updateBookingNotes'], 10, 2);
Hooks::filter(Config::withFreePrefix('bookings_and_appointments_for_woocommerce_update_booking_asset'), [BookingsAndAppointmentsForWoocommerceProHelper::class, 'updateBookingAsset'], 10, 3);
Hooks::filter(Config::withFreePrefix('bookings_and_appointments_for_woocommerce_update_booking_participants'), [BookingsAndAppointmentsForWoocommerceProHelper::class, 'updateBookingParticipants'], 10, 2);
Hooks::filter(Config::withFreePrefix('bookings_and_appointments_for_woocommerce_send_booking_confirmation_email'), [BookingsAndAppointmentsForWoocommerceProHelper::class, 'sendBookingConfirmationEmail'], 10, 2);
Hooks::filter(Config::withFreePrefix('bookings_and_appointments_for_woocommerce_send_booking_cancelled_email'), [BookingsAndAppointmentsForWoocommerceProHelper::class, 'sendBookingCancelledEmail'], 10, 2);
Hooks::filter(Config::withFreePrefix('bookings_and_appointments_for_woocommerce_send_booking_requires_confirmation_email'), [BookingsAndAppointmentsForWoocommerceProHelper::class, 'sendBookingRequiresConfirmationEmail'], 10, 2);
Hooks::filter(Config::withFreePrefix('bookings_and_appointments_for_woocommerce_send_booking_updated_email'), [BookingsAndAppointmentsForWoocommerceProHelper::class, 'sendBookingUpdatedEmail'], 10, 3);
Hooks::filter(Config::withFreePrefix('bookings_and_appointments_for_woocommerce_send_booking_payment_email'), [BookingsAndAppointmentsForWoocommerceProHelper::class, 'sendBookingPaymentEmail'], 10, 2);
