<?php

namespace BitApps\IntegrationsPro\Actions\Flodesk;

class FlodeskHelperPro
{
    private const STANDARD_SUBSCRIBER_KEYS = ['email', 'first_name', 'last_name'];

    public static function createOrUpdateSubscriber($response, $fieldData, $apiClient, $settings)
    {
        $payload = self::buildSubscriberPayload($fieldData);

        if (empty($payload['email'])) {
            return self::error(__('Email is required to create or update a subscriber', 'bit-integrations-pro'));
        }

        $segmentIds = self::toIdList($settings['selected_segment_ids'] ?? []);

        if ($segmentIds !== []) {
            $payload['segment_ids'] = $segmentIds;
        }

        if (!empty($settings['selected_double_optin'])) {
            $payload['double_optin'] = true;
        }

        return self::dispatch($apiClient, 'POST', 'subscribers', $payload, __('Subscriber created or updated successfully', 'bit-integrations-pro'));
    }

    public static function unsubscribeSubscriber($response, $fieldData, $apiClient, $settings)
    {
        $identifier = self::identifier($fieldData);

        if ($identifier === null) {
            return self::error(__('A subscriber id or email is required', 'bit-integrations-pro'));
        }

        return self::dispatch(
            $apiClient,
            'POST',
            'subscribers/' . $identifier . '/unsubscribe',
            null,
            __('Subscriber unsubscribed successfully', 'bit-integrations-pro')
        );
    }

    public static function addSubscriberToSegments($response, $fieldData, $apiClient, $settings)
    {
        return self::changeSegments($fieldData, $apiClient, $settings, 'POST', __('Subscriber added to segments successfully', 'bit-integrations-pro'));
    }

    public static function removeSubscriberFromSegments($response, $fieldData, $apiClient, $settings)
    {
        return self::changeSegments($fieldData, $apiClient, $settings, 'DELETE', __('Subscriber removed from segments successfully', 'bit-integrations-pro'));
    }

    public static function createSegment($response, $fieldData, $apiClient, $settings)
    {
        $name = $fieldData['name'] ?? '';
        $color = $settings['color_code'] ?? '';

        if ($name === '') {
            return self::error(__('A segment name is required', 'bit-integrations-pro'));
        }

        if ($color === '') {
            return self::error(__('A segment colour is required', 'bit-integrations-pro'));
        }

        return self::dispatch(
            $apiClient,
            'POST',
            'segments',
            ['name' => $name, 'color' => $color],
            __('Segment created successfully', 'bit-integrations-pro')
        );
    }

    public static function createCustomField($response, $fieldData, $apiClient, $settings)
    {
        $label = $fieldData['label'] ?? '';

        if ($label === '') {
            return self::error(__('A custom field label is required', 'bit-integrations-pro'));
        }

        return self::dispatch(
            $apiClient,
            'POST',
            'custom-fields',
            ['label' => $label],
            __('Custom field created successfully', 'bit-integrations-pro')
        );
    }

    public static function addSubscriberToWorkflow($response, $fieldData, $apiClient, $settings)
    {
        $identifier = self::identifier($fieldData);
        $workflowId = $settings['workflow_id'] ?? '';

        if ($identifier === null || $workflowId === '') {
            return self::error(__('A workflow and a subscriber id or email are required', 'bit-integrations-pro'));
        }

        $body = strpos($identifier, '@') !== false ? ['email' => $identifier] : ['id' => $identifier];

        return self::dispatch(
            $apiClient,
            'POST',
            'workflows/' . rawurlencode($workflowId) . '/subscribers',
            $body,
            __('Subscriber added to workflow successfully', 'bit-integrations-pro')
        );
    }

    public static function removeSubscriberFromWorkflow($response, $fieldData, $apiClient, $settings)
    {
        $identifier = self::identifier($fieldData);
        $workflowId = $settings['workflow_id'] ?? '';

        if ($identifier === null || $workflowId === '') {
            return self::error(__('A workflow and a subscriber id or email are required', 'bit-integrations-pro'));
        }

        return self::dispatch(
            $apiClient,
            'DELETE',
            'workflows/' . rawurlencode($workflowId) . '/subscribers/' . $identifier,
            null,
            __('Subscriber removed from workflow successfully', 'bit-integrations-pro')
        );
    }

    private static function changeSegments($fieldData, $apiClient, $settings, $method, $successMessage)
    {
        $identifier = self::identifier($fieldData);
        $segmentIds = self::toIdList($settings['segment_ids'] ?? []);

        if ($identifier === null) {
            return self::error(__('A subscriber id or email is required', 'bit-integrations-pro'));
        }

        if ($segmentIds === []) {
            return self::error(__('At least one segment is required', 'bit-integrations-pro'));
        }

        return self::dispatch(
            $apiClient,
            $method,
            'subscribers/' . $identifier . '/segments',
            ['segment_ids' => $segmentIds],
            $successMessage
        );
    }

    private static function buildSubscriberPayload($fieldData)
    {
        $payload = [];
        $customFields = [];

        foreach ((array) $fieldData as $key => $value) {
            if ($value === '' || $value === null) {
                continue;
            }

            if (\in_array($key, self::STANDARD_SUBSCRIBER_KEYS, true)) {
                $payload[$key] = $value;

                continue;
            }

            $customFields[$key] = $value;
        }

        if ($customFields !== []) {
            $payload['custom_fields'] = (object) $customFields;
        }

        return $payload;
    }

    private static function identifier($fieldData): ?string
    {
        $identifier = $fieldData['subscriber_id'] ?? $fieldData['email'] ?? '';

        if (!\is_scalar($identifier) || (string) $identifier === '') {
            return null;
        }

        return str_replace('%40', '@', rawurlencode((string) $identifier));
    }

    private static function toIdList($ids): array
    {
        if (\is_string($ids)) {
            $ids = explode(',', $ids);
        }

        if (!\is_array($ids)) {
            return [];
        }

        return array_values(array_filter(array_map('strval', $ids), static fn ($id) => trim($id) !== ''));
    }

    private static function dispatch($apiClient, $method, $path, $payload, $successMessage)
    {
        $response = $apiClient->request($method, $path, $payload === null ? null : wp_json_encode($payload));

        if (!$response->success()) {
            $message = $response->getError();

            if (!\is_string($message) || $message === '') {
                $bodyMessage = $response->getBodyValue('message');
                $message = \is_string($bodyMessage) && $bodyMessage !== ''
                    ? $bodyMessage
                    : __('Flodesk rejected the request', 'bit-integrations-pro');
            }

            return self::error($message);
        }

        return [
            'success' => true,
            'message' => $successMessage,
            'code'    => 200,
            'data'    => $response->getBody(),
        ];
    }

    private static function error($message)
    {
        return ['success' => false, 'message' => $message, 'code' => 400];
    }
}
