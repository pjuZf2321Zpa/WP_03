<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Actions\NextCrm\NextCrmProHelper;
use BitApps\IntegrationsPro\Config;
use BitApps\IntegrationsPro\Core\Util\Hooks;

Hooks::filter(Config::withFreePrefix('next_crm_create_contact'), [NextCrmProHelper::class, 'createContact'], 10, 3);
Hooks::filter(Config::withFreePrefix('next_crm_update_contact'), [NextCrmProHelper::class, 'updateContact'], 10, 3);
Hooks::filter(Config::withFreePrefix('next_crm_add_contact_activity'), [NextCrmProHelper::class, 'addContactActivity'], 10, 3);
Hooks::filter(Config::withFreePrefix('next_crm_delete_contact'), [NextCrmProHelper::class, 'deleteContact'], 10, 2);
Hooks::filter(Config::withFreePrefix('next_crm_create_tag'), [NextCrmProHelper::class, 'createTag'], 10, 2);
Hooks::filter(Config::withFreePrefix('next_crm_create_list'), [NextCrmProHelper::class, 'createList'], 10, 2);
Hooks::filter(Config::withFreePrefix('next_crm_change_contact_status'), [NextCrmProHelper::class, 'changeContactStatus'], 10, 3);
Hooks::filter(Config::withFreePrefix('next_crm_update_contact_field'), [NextCrmProHelper::class, 'updateContactField'], 10, 3);
Hooks::filter(Config::withFreePrefix('next_crm_add_tag_to_contact'), [NextCrmProHelper::class, 'addTagToContact'], 10, 3);
Hooks::filter(Config::withFreePrefix('next_crm_remove_tag_from_contact'), [NextCrmProHelper::class, 'removeTagFromContact'], 10, 3);
Hooks::filter(Config::withFreePrefix('next_crm_add_contact_to_list'), [NextCrmProHelper::class, 'addContactToList'], 10, 3);
Hooks::filter(Config::withFreePrefix('next_crm_remove_contact_from_list'), [NextCrmProHelper::class, 'removeContactFromList'], 10, 3);
Hooks::filter(Config::withFreePrefix('next_crm_send_campaign_email'), [NextCrmProHelper::class, 'sendCampaignEmail'], 10, 4);
