<?php

if (!defined('ABSPATH')) {
    die('You are not allowed to call this page directly.');
}

use MemberPress\GroundLevel\Support\Time;

#[AllowDynamicProperties]
class MeprStripeGateway extends MeprBaseRealAjaxGateway
{
    /**
     * The pinned Stripe API version, sent on every request this class makes.
     *
     * The invoice tax readers are tied to this version's field names: an
     * invoice carries `total_tax_amounts` and an invoice line carries
     * `tax_amounts`, which later API versions rename to `total_taxes` and
     * `taxes`. Every reader must move in the same change as a version bump,
     * or the tax rows silently read as empty: the invoice level in
     * MeprStripeTaxIntegration (`parse_invoice_tax_lines()` and its
     * `total_tax_amounts.tax_rate` expand), and the line level in
     * MeprOrderQuoteBuilder (the `lines.data.tax_amounts.tax_rate` and
     * `data.tax_amounts.tax_rate` expands) plus `invoice_line_amount_breakdowns()`
     * here. Checkout sessions are a different shape and use `taxes`.
     *
     * This pin does NOT govern webhook payloads. A connected account's
     * webhook endpoint is registered by the stripe-connect service with its
     * own API version, so `$event->data['object']` arrives in whatever shape
     * that version produces. Tax is never read from that payload: the
     * invoice handlers re-fetch the invoice through this class first, which
     * is what brings it under this pin.
     */
    const STRIPE_API_VERSION = '2022-11-15';

    /**
     * Stripe's maximum number of metadata keys on one object.
     *
     * @var integer
     */
    public const STRIPE_METADATA_MAX_KEYS = 50;

    /**
     * The number of seconds a subscription stays locked for a resume, pause or
     * cancel when the request holding the lock never releases it.
     */
    private const SUBSCRIPTION_LOCK_TTL = 300;

    /**
     * The number of seconds a payment webhook or a cancel waits for a
     * subscription that another request is changing. A webhook that still
     * cannot get the lock fails, and Stripe retries it.
     */
    private const SUBSCRIPTION_LOCK_WAIT = 10;

    /**
     * The metadata key that marks a Stripe subscription as created by a
     * resume, holding the MemberPress subscription id.
     */
    private const RESUMED_SUBSCRIPTION_METADATA_KEY = 'memberpress_resumed_subscription_id';

    /**
     * Used in the view to identify the gateway
     */
    public function __construct()
    {
        $this->name = 'Stripe';
        $this->icon = MEPR_IMAGES_URL . '/checkout/cards.png';
        $this->desc = __('Pay with your credit card via Stripe', 'memberpress');
        $this->key  = 'stripe';
        $this->set_defaults();
        $this->has_spc_form = true;

        $this->capabilities = [
            'process-credit-cards',
            'process-payments',
            'process-refunds',
            'create-subscriptions',
            'cancel-subscriptions',
            'update-subscriptions',
            'suspend-subscriptions',
            'resume-subscriptions',
            'send-cc-expirations',
            'subscription-trial-payment',
            'order-bumps',
            'multiple-subscriptions',
        ];

        // Setup the notification actions for this gateway.
        $this->notifiers = [
            'whk'                 => 'listener',
            'stripe-service-whk'  => 'service_listener',
            'update-billing.html' => 'churn_buster',
            'return'              => 'return_handler',
        ];
    }

    /**
     * Load gateway settings
     *
     * @param  array $settings Gateway settings array.
     * @return void
     */
    public function load($settings)
    {
        $this->settings = (object)$settings;
        $this->set_defaults();
    }

    /**
     * Set default gateway settings
     *
     * Initializes default settings for the Stripe gateway including API keys,
     * payment methods, and connection status
     *
     * @return void
     */
    protected function set_defaults()
    {
        if (!isset($this->settings)) {
            $this->settings = [];
        }

        $this->settings = (object)array_merge(
            [
                'gateway'                 => 'MeprStripeGateway',
                'id'                      => $this->generate_id(),
                'label'                   => '',
                'use_label'               => true,
                'use_icon'                => true,
                'use_desc'                => true,
                'enable_for_cart'         => false,
                'email'                   => '',
                'sandbox'                 => false,
                'force_ssl'               => false,
                'debug'                   => false,
                'test_mode'               => false,
                'stripe_checkout_enabled' => false,
                'churn_buster_enabled'    => false,
                'churn_buster_uuid'       => '',
                'api_keys'                => [
                    'test' => [
                        'public' => '',
                        'secret' => '',
                    ],
                    'live' => [
                        'public' => '',
                        'secret' => '',
                    ],
                ],
                'connect_status'          => false,
                'service_account_id'      => '',
                'service_account_name'    => '',
                'country'                 => '',
                'payment_methods'         => $this->get_default_payment_methods(),
            ],
            (array)$this->settings
        );

        $this->id                   = $this->settings->id;
        $this->label                = $this->settings->label;
        $this->use_label            = $this->settings->use_label;
        $this->use_icon             = $this->settings->use_icon;
        $this->use_desc             = $this->settings->use_desc;
        $this->connect_status       = $this->settings->connect_status;
        $this->service_account_id   = $this->settings->service_account_id;
        $this->service_account_name = $this->settings->service_account_name;
        // $this->recurrence_type = $this->settings->recurrence_type;
        if ($this->is_test_mode()) {
            $this->settings->public_key = trim($this->settings->api_keys['test']['public']);
            $this->settings->secret_key = trim($this->settings->api_keys['test']['secret']);
        } else {
            $this->settings->public_key = trim($this->settings->api_keys['live']['public']);
            $this->settings->secret_key = trim($this->settings->api_keys['live']['secret']);
        }
    }

    /**
     * Determines whether the update link for a subscription should be hidden.
     *
     * @param  MeprSubscription $subscription The subscription object.
     * @return boolean Returns true if the subscription status is suspended, otherwise false.
     */
    protected function hide_update_link($subscription)
    {
        if ($subscription->status === MeprSubscription::$suspended_str) {
            return true;
        }

        return false;
    }

    /**
     * Retrieves the Stripe tax rate ID for a given product.
     *
     * @param string      $name      The name of the tax.
     * @param integer     $rate      The tax rate.
     * @param MeprProduct $product   The product object.
     * @param boolean     $inclusive Whether the tax is inclusive.
     *
     * @return object The Stripe tax rate ID.
     * @throws MeprHttpException When HTTP request to Stripe API fails.
     * @throws MeprRemoteException When Stripe API returns an error response.
     */
    public function get_stripe_tax_rate_id($name, $rate, $product, $inclusive = false)
    {
        $tax_request = [
            'inclusive'  => 'false',
            'percentage' => MeprUtils::format_float((float) $rate, 3),
        ];

        if (empty($name)) {
            $tax_request['display_name'] = 'Tax';
        } else {
            $tax_request['display_name'] = $name;
        }

        if ($inclusive) {
            $tax_request['inclusive'] = 'true';
        }

        $meta_key = '_mepr_stripe_tax_id_' . $this->get_meta_gateway_id() . '_' . md5(serialize($tax_request));

        $tax_id = get_post_meta($product->ID, $meta_key, true);

        if (!empty($tax_id)) {
            return $tax_id;
        }

        $stripe_tax = (object) $this->send_stripe_request('tax_rates', $tax_request);

        update_post_meta($product->ID, $meta_key, $stripe_tax->id);

        return $stripe_tax->id;
    }

    // phpcs:disable Squiz.Commenting.FunctionCommentThrowTag.WrongNumber
    /**
     * Create a Checkout session and redirect the user to Stripe.
     *
     * @param  MeprTransaction       $txn     The transaction.
     * @param  MeprProduct           $product The product.
     * @param  MeprUser              $usr     The user.
     * @param  MeprSubscription|null $sub     The subscription (null for one-time payments).
     * @throws MeprGatewayException           If a recurring product arrives without its subscription.
     * @throws MeprHttpException              If there was an HTTP error connecting to Stripe.
     * @throws MeprRemoteException            If there was an invalid or error response from Stripe.
     */
    public function create_checkout_session(
        $txn,
        $product,
        $usr,
        $sub = null
    ) {
        $mepr_options    = MeprOptions::fetch();
        $current_user    = MeprUtils::get_currentuserinfo();
        $calculate_taxes = (bool) get_option('mepr_calculate_taxes');

        if ($mepr_options->attr('tax_calc_type') === 'inclusive' && $calculate_taxes && $txn->tax_rate > 0) {
            $tax_inclusive = true;
        } else {
            $tax_inclusive = false;
        }

        $thankyou_page_args = [
            'membership'     => sanitize_title($product->post_title),
            'transaction_id' => $txn->id,
            'membership_id'  => $product->ID,
        ];

        if ($sub instanceof MeprSubscription) {
            $thankyou_page_args = array_merge($thankyou_page_args, ['subscription_id' => $sub->id]);
        }

        $success_url = add_query_arg(
            [
                'txn_id'      => $txn->id,
                'redirect_to' => urlencode($mepr_options->thankyou_page_url($thankyou_page_args)),
            ],
            $this->notify_url('return')
        );

        $currency          = $mepr_options->currency_code;
        $customer_id       = $this->get_customer_id($usr);
        $base_price        = MeprHooks::apply_filters('mepr_stripe_product_base_price', $product->adjusted_price(), $product, $usr, $sub);
        $base_price        = MeprUtils::maybe_round_to_minimum_amount($base_price);
        $price_id          = $this->get_stripe_price_id((float) $base_price, $product, $sub);
        $stripe_product_id = $this->get_product_id($product);

        /*
         * Coupon objects in this gateway only arrive from module-owned
         * accessors and filters that return false in stripped builds;
         * every use sits behind instanceof checks or type hints, which
         * never autoload. mepr:coupon-surface
         */
        $coupon = $txn->coupon();

        if ($coupon instanceof MeprCoupon) {
            $discount_amount = $this->get_coupon_discount_amount($coupon, $product);
            $discount_mode   = $coupon->get_discount_mode($product);

            if ($discount_amount > 0 && $discount_mode !== 'first-payment') {
                if ($tax_inclusive) {
                    if ($coupon->get_discount_type($product) !== 'percent') {
                        $stripe_coupon_id = $this->get_coupon_id($coupon, (string) $this->to_zero_decimal_amount($coupon->get_discount_amount($product), $currency), false, $product);
                    } else {
                        $stripe_coupon_id = $this->get_coupon_id($coupon, $coupon->get_discount_amount($product), false, $product);
                    }
                } else {
                    $stripe_coupon_id = $this->get_coupon_id($coupon, $discount_amount, false, $product);
                }
            }

            if ($product->is_one_time_payment() && $discount_mode === 'first-payment' && $coupon->get_first_payment_discount_amount($product) > 0) {
                if ($coupon->get_first_payment_discount_type($product) !== 'percent') {
                    $stripe_coupon_id = $this->get_coupon_id($coupon, (string) $this->to_zero_decimal_amount($coupon->get_first_payment_discount_amount($product), $currency), true, $product);
                } else {
                    $stripe_coupon_id = $this->get_coupon_id($coupon, $coupon->get_first_payment_discount_amount($product), true, $product);
                }
            }

            if (
                !$product->is_one_time_payment() &&
                (
                ($discount_mode === 'first-payment' && $coupon->get_first_payment_discount_amount($product) > 0) ||
                ($discount_mode === 'trial-override' && $coupon->get_discount_amount($product) > 0)
                )
            ) {
                $tmp_sub          = new MeprSubscription();
                $tmp_sub->id      = 0;
                $tmp_sub->user_id = (isset($current_user->ID)) ? $current_user->ID : 0;
                $tmp_sub->load_product_vars($product, null, true);
                $tmp_sub->maybe_prorate();
                $sub->trial_amount = $tmp_sub->price;

                if ($coupon->get_discount_amount($product) > 0) {
                    $tmp_coupon                  = new MeprCoupon();
                    $tmp_coupon->discount_amount = $coupon->get_discount_amount($product);
                    $tmp_coupon->discount_type   = $coupon->get_discount_type($product);
                    $price                       = $tmp_coupon->apply_discount($product->price, false, $product);
                    $price                       = MeprHooks::apply_filters('mepr_stripe_product_base_price', $price, $product, $usr, $sub);
                    $price                       = MeprUtils::maybe_round_to_minimum_amount($price);
                    $price_id                    = $this->get_stripe_price_id((float) $price, $product, $sub);
                }
            } else {
                $discounted_amount = $coupon->apply_discount($base_price, $product->is_one_time_payment(), $product);
                $minimum_amount    = MeprUtils::get_minimum_amount();

                // If the coupon brings the amount below the minimum charge amount, set the amount to the minimum charge amount
                // and don't use a Stripe coupon.
                if ($minimum_amount && $discounted_amount < $minimum_amount) {
                    $price_id         = $this->get_stripe_price_id((float) $minimum_amount, $product, $sub);
                    $stripe_coupon_id = null;
                }
            }
        }

        if (!self::use_automatic_tax() && $calculate_taxes && $txn->tax_rate > 0 && $txn->tax_amount > 0) {
            $tax_rate_id = $this->get_stripe_tax_rate_id($txn->tax_desc, $txn->tax_rate, $product, $tax_inclusive);
        }

        $metadata = array_filter([
            'platform'                  => 'MemberPress Connect acct_1FIIDhKEEWtO8ZWC',
            'site_url'                  => get_site_url(),
            'ip_address'                => MeprAntiCardTestingCtrl::get_ip(),
            'transaction_id'            => $txn->id,
            'memberpress_transaction_id' => $txn->id,
            'memberpress_product'        => $product->post_title,
            'memberpress_product_id'     => $product->ID,
        ]);

        if (!$product->is_one_time_payment()) {
            if (!($sub instanceof MeprSubscription)) {
                throw new MeprGatewayException(esc_html__('Subscription not found', 'memberpress'));
            }

            $metadata = array_filter(array_merge($metadata, [
                'memberpress_subscription_id' => $sub->id,
            ]));

            list($min_payment, $max_payment) = $this->payment_amount_range((float) $txn->total, (float) $sub->total);

            $checkout_session = [
                'customer'             => $customer_id,
                'payment_method_types' => $this->get_subscription_payment_method_types($min_payment, $max_payment),
                'line_items'           => [
                    [
                        'price'    => $price_id,
                        'quantity' => 1,
                    ],
                ],
                'mode'                 => 'subscription',
                'success_url'          => $success_url,
                'cancel_url'           => MeprUtils::get_current_url(),
                'metadata'             => $metadata,
                'subscription_data'    => [
                    'metadata' => $metadata,
                ],
            ];

            if (!empty($product->post_title)) {
                $checkout_session['subscription_data']['description'] = $product->post_title;
            }

            // Site A — subscription path. application_fee_percent on the Stripe
            // subscription drives the cycle-1 fee; cycle-2+ is set fresh by the
            // invoice.created webhook regardless. A free trial has a $0 cycle-1
            // invoice, so a fetch + stamp here would be wasted.
            $is_free_trial = ($sub instanceof MeprSubscription)
                && $sub->trial
                && $sub->trial_days > 0
                && (float) $sub->trial_total <= 0.00;

            if (!$is_free_trial) {
                $fee         = $this->fee_service()->fetch_fee($this->id);
                $fee_percent = $fee['percent'];
                if ($fee_percent > 0) {
                    $checkout_session['subscription_data']['application_fee_percent'] = $fee_percent;
                    $checkout_session = self::merge_fee_metadata(
                        $checkout_session,
                        $fee['metadata'],
                        'subscription_data'
                    );
                }
            }
        } else {
            $store_payment_method            = MeprHooks::apply_filters('mepr_stripe_payment_intent_store_payment_method', false, $txn, $product);
            $setup_future_usage              = $store_payment_method ? 'off_session' : null;
            list($min_payment, $max_payment) = $this->payment_amount_range((float) $txn->total);
            $payment_method_types            = $this->get_payment_intent_payment_method_types($setup_future_usage, $min_payment, $max_payment);
            $payment_method_options          = [];

            if (in_array('wechat_pay', $payment_method_types, true)) {
                $payment_method_options = array_merge($payment_method_options, [
                    'wechat_pay' => [
                        'client' => 'web',
                    ],
                ]);
            }

            $checkout_session = [
                'payment_method_options' => $payment_method_options,
                'customer'               => $customer_id,
                'line_items'             => [
                    [
                        'price'    => $price_id,
                        'quantity' => 1,
                    ],
                ],
                'mode'                   => 'payment',
                'metadata'               => $metadata,
                'success_url'            => $success_url,
                'cancel_url'             => MeprUtils::get_current_url(),
                'payment_intent_data'    => [
                    'metadata' => $metadata,
                ],
            ];

            if (!empty($product->post_title)) {
                $checkout_session['payment_intent_data']['description'] = $product->post_title;
            }

            if ($store_payment_method) {
                $checkout_session['payment_intent_data']['setup_future_usage'] = 'off_session';
            }

            $index = array_search('afterpay_clearpay', $payment_method_types, true);
            if ($index !== false) {
                $full_name = $usr->get_full_name();

                $address = [
                    'line1'       => get_user_meta($usr->ID, 'mepr-address-one', true),
                    'line2'       => get_user_meta($usr->ID, 'mepr-address-two', true),
                    'city'        => get_user_meta($usr->ID, 'mepr-address-city', true),
                    'state'       => get_user_meta($usr->ID, 'mepr-address-state', true),
                    'country'     => get_user_meta($usr->ID, 'mepr-address-country', true),
                    'postal_code' => get_user_meta($usr->ID, 'mepr-address-zip', true),
                ];

                foreach ($address as $key => $value) {
                    if (empty($value) || !is_string($value)) {
                        unset($address[$key]);
                    }
                }

                if (!empty($full_name) && !empty($address) && !empty($address['line1'])) {
                    $checkout_session['payment_intent_data']['shipping'] = [
                        'name'    => $full_name,
                        'address' => $address,
                    ];
                } else {
                    // Name and Address fields are required to use Afterpay/Clearpay.
                    array_splice($payment_method_types, $index, 1);
                }
            }

            $checkout_session['payment_method_types'] = $payment_method_types;

            // Site B — one-time payment path. The fee base is $txn->total — the
            // amount the customer is actually charged in both tax modes (with
            // exclusive tax, Stripe adds the tax on top of the pre-tax line
            // items) — matching how Stripe applies application_fee_percent to
            // the tax-inclusive invoice on the subscription paths. Stripe
            // expects application_fee_amount in the currency's zero-decimal
            // form. The fee rounds to the nearest unit with a half rounding
            // up, the way Stripe rounds the fee it computes from
            // application_fee_percent, and the round(…, 6) clears float
            // representation error before rounding so it cannot decide a
            // half: 375 cents at 9.2% is 34.5, held as 34.499999999999993.
            // The fee metadata is relayed only with a fee, so a fee that
            // rounds to zero carries none.
            $fee                 = $this->fee_service()->fetch_fee($this->id);
            $fee_percent         = $fee['percent'];
            $zero_decimal_amount = (int) $this->to_zero_decimal_amount((float) $txn->total, $currency);
            $application_fee     = (int) round(round($zero_decimal_amount * $fee_percent / 100, 6));
            if ($application_fee > 0) {
                $checkout_session['payment_intent_data']['application_fee_amount'] = $application_fee;
                $checkout_session = self::merge_fee_metadata(
                    $checkout_session,
                    $fee['metadata'],
                    'payment_intent_data'
                );
            }
        }

        if ($sub instanceof MeprSubscription && $sub->trial && $sub->trial_days > 0) {
            $checkout_session['subscription_data']['trial_period_days'] = $sub->trial_days;

            // The section below sets the recurring price amount to the coupon discounted amount.
            // Since a Stripe coupon will also discount the trial amount, we can't use a Stripe coupon if there is a paid trial.
            if ($coupon instanceof MeprCoupon && $coupon->get_discount_amount($product) > 0 && $sub->trial_total > 0) {
                $tmp_coupon                                 = new MeprCoupon();
                $tmp_coupon->discount_amount                = $coupon->get_discount_amount($product);
                $tmp_coupon->discount_type                  = $coupon->get_discount_type($product);
                $price                                      = $tmp_coupon->apply_discount($product->price, false, $product);
                $price                                      = MeprHooks::apply_filters('mepr_stripe_product_base_price', $price, $product, $usr, $sub);
                $price                                      = MeprUtils::maybe_round_to_minimum_amount($price);
                $checkout_session['line_items'][0]['price'] = $this->get_stripe_price_id((float) $price, $product, $sub);
            }

            if ($tax_inclusive) {
                $trial_amount = $sub->trial_total;
            } else {
                $trial_amount = $sub->trial_total - $sub->trial_tax_amount;
            }

            $trial_amount = $this->to_zero_decimal_amount($trial_amount, $currency);
            $trial_plan   = [
                'quantity'   => 1,
                'price_data' => [
                    'currency'    => $currency,
                    'product'     => $this->get_product_id($product, true),
                    'unit_amount' => $trial_amount,
                ],
            ];

            if (self::use_automatic_tax()) {
                // The behavior is explicit, so the trial charge never
                // depends on the Stripe account's default behavior
                // agreeing with the site's tax mode.
                $trial_plan['price_data']['tax_behavior'] = $mepr_options->attr('tax_calc_type') === 'inclusive' ? 'inclusive' : 'exclusive';
            } elseif (isset($tax_rate_id)) {
                $trial_plan['tax_rates'] = [$tax_rate_id];
            }

            $checkout_session['line_items'][] = $trial_plan;
        }

        if (self::use_automatic_tax()) {
            $checkout_session['automatic_tax'] = ['enabled' => 'true'];
            if (!empty($customer_id)) {
                $checkout_session['customer_update'] = ['address' => 'auto'];
            }
        } else {
            if (isset($tax_rate_id)) {
                $checkout_session['line_items'][0]['tax_rates'] = [$tax_rate_id];
            }
        }

        if (isset($stripe_coupon_id)) {
            if (!$sub instanceof MeprSubscription || !$sub->trial || (float) $sub->trial_total === 0.00) {
                $checkout_session['discounts'] = [
                    ['coupon' => $stripe_coupon_id],
                ];
            }

            if (
                !$product->is_one_time_payment() &&
                (
                ($discount_mode === 'first-payment' && $coupon->get_first_payment_discount_amount($product) > 0) ||
                ($discount_mode === 'trial-override' && $coupon->get_discount_amount($product) > 0)
                )
            ) {
                unset($checkout_session['discounts']);
            }
        }

        // Active product to use in Stripe checkout.
        $this->send_stripe_request('products/' . $stripe_product_id, ['active' => 'true']);

        $checkout_session = MeprHooks::apply_filters('mepr_stripe_checkout_session_args', $checkout_session, $txn, $sub);

        $checkout_session = (object) $this->send_stripe_request('checkout/sessions', $checkout_session, 'post');

        $txn->trans_num = $checkout_session->id;
        $txn->store();

        MeprUtils::wp_redirect($checkout_session->url, 303);
    }
    // phpcs:enable Squiz.Commenting.FunctionCommentThrowTag.WrongNumber

    // phpcs:disable Squiz.Commenting.FunctionCommentThrowTag.WrongNumber
    /**
     * Create a Checkout session for purchases with order bumps, and redirect the user to Stripe.
     *
     * @param  MeprTransaction   $txn         The transaction.
     * @param  MeprProduct       $prd         The product.
     * @param  MeprUser          $usr         The user.
     * @param  string            $coupon_code The coupon code.
     * @param  MeprTransaction[] $order_bumps The array of order bump transactions in the checkout.
     * @throws MeprGatewayException           If there was an error processing the transaction.
     * @throws MeprHttpException              If there was an HTTP error connecting to Stripe.
     * @throws MeprRemoteException            If there was an invalid or error response from Stripe.
     * @throws Exception                      If pricing the order fails (the attempt aborts).
     */
    public function create_multi_item_checkout_session(MeprTransaction $txn, MeprProduct $prd, MeprUser $usr, $coupon_code = '', array $order_bumps = [])
    {
        $mepr_options    = MeprOptions::fetch();
        $calculate_taxes = (bool) get_option('mepr_calculate_taxes');
        $tax_inclusive   = $mepr_options->attr('tax_calc_type') === 'inclusive';
        $line_items      = [];

        $thankyou_page_args = [
            'membership'     => sanitize_title($prd->post_title),
            'transaction_id' => $txn->id,
            'membership_id'  => $prd->ID,
        ];

        // $amount feeds the Stripe line items, so with exclusive tax it must be
        // the pre-tax figure (Stripe adds the tax on top via the line item's tax
        // rate). $charge tracks what the customer is actually charged — the
        // tax-inclusive total in both modes — and is accumulated separately as
        // the application-fee base.
        $sub = null;

        if ($prd->is_one_time_payment() || !$prd->is_payment_required($coupon_code)) {
            if ($prd->is_payment_required($coupon_code)) {
                $amount = $calculate_taxes && !$tax_inclusive && $txn->tax_rate > 0 ? (float) $txn->amount : (float) $txn->total;
                $charge = (float) $txn->total;
            } else {
                $amount = 0.00;
                $charge = 0.00;
            }

            $line_items[] = $this->build_line_item($this->get_stripe_price_id($amount, $prd, null, true), $txn, $prd);
        } else {
            $sub = $txn->subscription();

            if (!($sub instanceof MeprSubscription)) {
                throw new MeprGatewayException(esc_html__('Subscription not found', 'memberpress'));
            }

            $amount             = $calculate_taxes && !$tax_inclusive && $txn->tax_rate > 0 ? (float) $sub->price : (float) $sub->total;
            $charge             = (float) $sub->total;
            $line_items[]       = $this->build_line_item($this->get_stripe_price_id($amount, $prd, $sub), $txn, $prd);
            $thankyou_page_args = array_merge($thankyou_page_args, ['subscription_id' => $sub->id]);
        }

        $total                       = $amount;
        $charge_total                = $charge;
        $has_subscription_order_bump = false;
        $bump_subscriptions          = [];

        foreach ($order_bumps as $transaction) {
            $product = $transaction->product();

            if (empty($product->ID)) {
                throw new MeprGatewayException(esc_html__('Product not found', 'memberpress'));
            }

            if (!$transaction->is_payment_required()) {
                $amount = 0.00;
                $charge = 0.00;
            } elseif ($transaction->is_one_time_payment()) {
                $amount = $calculate_taxes && !$tax_inclusive && $transaction->tax_rate > 0 ? (float) $transaction->amount : (float) $transaction->total;
                $charge = (float) $transaction->total;
            } else {
                $subscription = $transaction->subscription();

                if (!($subscription instanceof MeprSubscription)) {
                    throw new MeprGatewayException(esc_html__('Subscription not found', 'memberpress'));
                }

                if ($subscription->trial && $subscription->trial_days > 0) {
                    $amount = $calculate_taxes && !$tax_inclusive && $transaction->tax_rate > 0 ? (float) $subscription->trial_amount : (float) $subscription->trial_total;
                    $charge = (float) $subscription->trial_total;
                } else {
                    $amount = $calculate_taxes && !$tax_inclusive && $transaction->tax_rate > 0 ? (float) $subscription->price : (float) $subscription->total;
                    $charge = (float) $subscription->total;
                }

                $has_subscription_order_bump = true;
                $bump_subscriptions[]        = $subscription;
            }

            $line_items[]  = $this->build_line_item($this->get_stripe_price_id($amount, $product, null, true), $transaction, $product);
            $total        += $amount;
            $charge_total += $charge;
        }

        // The submit quote prices the same rows Stripe's page charges in
        // the unchanged-address case: its total is the application-fee
        // base, and its lines commit to the stored rows, so the pending
        // window renders the priced allocation. The webhook copy and the
        // return-time sync still verify against the actual charge and
        // correct any divergence (an address changed on the hosted page).
        // Pricing fails closed, the one policy across all submit surfaces.
        $quote = (new MeprOrderQuoteBuilder())->price_order($txn, $sub, $order_bumps);

        if ($quote instanceof MeprOrderQuote) {
            $charge_total = (float) $quote->totals['total'];
        }

        // Every payment this order produces: the charge taken now, plus every
        // renewal the order commits to.
        $renewals = $this->get_renewal_amounts($sub, $bump_subscriptions);

        list($min_payment, $max_payment) = $this->payment_amount_range($charge_total, ...$renewals);

        $metadata = array_filter([
            'platform'                  => 'MemberPress Connect acct_1FIIDhKEEWtO8ZWC',
            'site_url'                  => get_site_url(),
            'ip_address'                => MeprAntiCardTestingCtrl::get_ip(),
            'transaction_id'            => $txn->id,
            'memberpress_transaction_id' => $txn->id,
            'memberpress_product'        => $prd->post_title,
            'memberpress_product_id'     => $prd->ID,
        ]);

        if ($prd->is_one_time_payment() || !$prd->is_payment_required($coupon_code)) {
            if ($total > 0.00) {
                $store_payment_method   = MeprHooks::apply_filters('mepr_stripe_payment_intent_store_payment_method', $has_subscription_order_bump, $txn, $prd);
                $setup_future_usage     = $store_payment_method ? 'off_session' : null;
                $payment_method_types   = $this->get_payment_intent_payment_method_types(
                    $setup_future_usage,
                    $min_payment,
                    $max_payment
                );
                $payment_method_options = [];

                if (in_array('wechat_pay', $payment_method_types, true)) {
                    $payment_method_options = array_merge($payment_method_options, [
                        'wechat_pay' => [
                            'client' => 'web',
                        ],
                    ]);
                }

                $args = [
                    'mode'                   => 'payment',
                    'customer'               => $this->get_customer_id($usr),
                    'payment_method_options' => $payment_method_options,
                    'line_items'             => $line_items,
                    'metadata'               => $metadata,
                    'payment_intent_data'    => [
                        'metadata' => $metadata,
                    ],
                ];

                if ($store_payment_method) {
                    $args['payment_intent_data']['setup_future_usage'] = 'off_session';
                }

                if (!empty($prd->post_title)) {
                    $args['payment_intent_data']['description'] = $prd->post_title;
                }

                $index = array_search('afterpay_clearpay', $payment_method_types, true);
                if ($index !== false) {
                    $full_name = $usr->get_full_name();

                    $address = [
                        'line1'       => get_user_meta($usr->ID, 'mepr-address-one', true),
                        'line2'       => get_user_meta($usr->ID, 'mepr-address-two', true),
                        'city'        => get_user_meta($usr->ID, 'mepr-address-city', true),
                        'state'       => get_user_meta($usr->ID, 'mepr-address-state', true),
                        'country'     => get_user_meta($usr->ID, 'mepr-address-country', true),
                        'postal_code' => get_user_meta($usr->ID, 'mepr-address-zip', true),
                    ];

                    foreach ($address as $key => $value) {
                        if (empty($value) || !is_string($value)) {
                            unset($address[$key]);
                        }
                    }

                    if (!empty($full_name) && !empty($address) && !empty($address['line1'])) {
                        $args['payment_intent_data']['shipping'] = [
                            'name'    => $full_name,
                            'address' => $address,
                        ];
                    } else {
                        // Name and Address fields are required to use Afterpay/Clearpay.
                        array_splice($payment_method_types, $index, 1);
                    }
                }

                $args['payment_method_types'] = $payment_method_types;

                // Site F — multi-item payment-mode path. Stamp application_fee_amount
                // computed from $charge_total — the customer-charged, tax-inclusive
                // sum ($total is pre-tax with exclusive tax) — in the currency's
                // zero-decimal form, rounded to the nearest unit with a half
                // rounding up as Stripe rounds a percent fee. The round(…, 6)
                // clears float representation error before rounding. The fee
                // metadata is relayed only with a fee, so a fee that rounds to
                // zero carries none.
                $fee                 = $this->fee_service()->fetch_fee($this->id);
                $fee_percent         = $fee['percent'];
                $zero_decimal_amount = (int) $this->to_zero_decimal_amount($charge_total, $mepr_options->currency_code);
                $application_fee     = (int) round(round($zero_decimal_amount * $fee_percent / 100, 6));
                if ($application_fee > 0) {
                    $args['payment_intent_data']['application_fee_amount'] = $application_fee;
                    $args = self::merge_fee_metadata($args, $fee['metadata'], 'payment_intent_data');
                }
            } else {
                $args = [
                    'mode'                 => 'setup',
                    'customer'             => $this->get_customer_id($usr),
                    'payment_method_types' => $this->get_setup_intent_payment_method_types($min_payment, $max_payment),
                    'metadata'             => $metadata,
                    'setup_intent_data'    => [
                        'metadata' => $metadata,
                    ],
                ];

                if (!empty($prd->post_title)) {
                    $args['setup_intent_data']['description'] = $prd->post_title;
                }
            }
        } else {
            $sub = $txn->subscription();

            if (!($sub instanceof MeprSubscription)) {
                throw new MeprGatewayException(esc_html__('Subscription not found', 'memberpress'));
            }

            $metadata = array_filter(array_merge($metadata, [
                'memberpress_subscription_id' => $sub->id,
            ]));

            $args = [
                'mode'                 => 'subscription',
                'customer'             => $this->get_customer_id($usr),
                'payment_method_types' => $this->get_subscription_payment_method_types($min_payment, $max_payment),
                'metadata'             => $metadata,
                'subscription_data'    => [
                    'metadata' => $metadata,
                ],
            ];

            if (!empty($prd->post_title)) {
                $args['subscription_data']['description'] = $prd->post_title;
            }

            if ($sub->trial && $sub->trial_days > 0) {
                $amount    = $calculate_taxes && !$tax_inclusive && $txn->tax_rate > 0 ? (float) $sub->trial_amount : (float) $sub->trial_total;
                $line_item = $this->build_line_item($this->get_stripe_price_id($amount, $prd, null, true), $txn, $prd);
                array_unshift($line_items, $line_item);

                $args['subscription_data']['trial_period_days'] = $sub->trial_days;
            }

            $args = array_merge($args, [
                'line_items' => $line_items,
            ]);

            // Site G — multi-item subscription-mode path. Stamp application_fee_percent.
            // Applies to the initial invoice (which folds in any paid-trial or
            // order-bump line_items) and to recurring invoices until the
            // invoice.created webhook clears it on cycle 2+.
            $fee         = $this->fee_service()->fetch_fee($this->id);
            $fee_percent = $fee['percent'];
            if ($fee_percent > 0) {
                $args['subscription_data']['application_fee_percent'] = $fee_percent;
                $args = self::merge_fee_metadata($args, $fee['metadata'], 'subscription_data');
            }
        }

        $success_url = add_query_arg(
            [
                'txn_id'      => $txn->id,
                'redirect_to' => urlencode($mepr_options->thankyou_page_url($thankyou_page_args)),
            ],
            $this->notify_url('return')
        );

        $args = array_merge($args, [
            'success_url' => $success_url,
            'cancel_url'  => MeprUtils::get_current_url(),
        ]);

        // Under automatic tax the line items carry the pre-tax amounts, so the
        // session must compute tax itself; customer_update lets Stripe read the
        // customer's address for the calculation. The legacy path keeps its
        // per-line tax_rates from build_line_item() instead. Setup mode charges
        // nothing now, so it carries no tax — and Stripe rejects automatic_tax
        // there; the recurring bumps' own subscriptions tax their charges.
        if (self::use_automatic_tax() && ($args['mode'] ?? '') !== 'setup') {
            $args['automatic_tax'] = ['enabled' => 'true'];

            if (!empty($args['customer'])) {
                $args['customer_update'] = ['address' => 'auto'];
            }
        }

        $args = MeprHooks::apply_filters('mepr_stripe_checkout_session_args', $args, $txn);

        $checkout_session = (object) $this->send_stripe_request('checkout/sessions', $args, 'post');

        $txn->trans_num = $checkout_session->id;
        $txn->store();

        MeprUtils::wp_redirect($checkout_session->url, 303);
    }
    // phpcs:enable Squiz.Commenting.FunctionCommentThrowTag.WrongNumber

    /**
     * Convert the given amount to a zero-decimal Stripe amount
     *
     * The rounding runs through format_float(), so the digits match the
     * historical string form byte-for-byte wherever a legacy meta-key hash
     * needs them — those call sites cast the result back to string.
     *
     * Always name the currency the amount is charged in. Omitting it is
     * deprecated: it assumes the site primary currency, which is wrong for
     * any amount charged in a secondary one.
     *
     * @param  float       $amount   The amount to convert.
     * @param  string|null $currency ISO 4217 currency code. Null assumes the site primary.
     * @return integer The zero-decimal amount
     */
    public function to_zero_decimal_amount($amount, ?string $currency = null): int
    {
        if ($currency === null) {
            _doing_it_wrong(
                __METHOD__,
                'Pass the currency the amount is charged in; omitting it assumes the site primary currency.',
                '1.12.18'
            );

            $currency = MeprOptions::fetch()->currency_code;
        }

        return (int) (MeprCurrencyService::is_zero_decimal($currency)
            ? MeprUtils::format_float($amount, 0)
            : MeprUtils::format_float(($amount * 100), 0));
    }

    /**
     * Charge currency for payment-method filtering.
     * Explicit currency wins; omit → site primary (legacy). Cart must pass the charge currency.
     *
     * @param  string|null $currency ISO 4217 code.
     * @return string
     */
    private function resolve_payment_method_currency($currency = null)
    {
        if (!empty($currency)) {
            return strtoupper((string) $currency);
        }

        return strtoupper(MeprOptions::fetch()->currency_code ?: 'USD');
    }

    /**
     * Get the payment method types for SetupIntents (free trials)
     *
     * @param  float|null  $min_amount The smallest payment the order requires.
     * @param  float|null  $max_amount The largest payment the order requires.
     * @param  string|null $currency   Charge currency (null = primary).
     * @return array The filtered payment method types
     */
    public function get_setup_intent_payment_method_types(?float $min_amount = null, ?float $max_amount = null, ?string $currency = null)
    {
        $types           = ['card'];
        $payment_methods = $this->settings->payment_methods;
        $currency        = $this->resolve_payment_method_currency($currency);

        if (is_array($payment_methods) && count($payment_methods)) {
            foreach ($this->get_available_payment_methods($currency) as $payment_method) {
                if (in_array($payment_method['key'], $payment_methods, true) && in_array('setup_intents', $payment_method['capabilities'], true)) {
                    $types[] = $payment_method['key'];
                }
            }
        }

        $types = MeprHooks::apply_filters('mepr_stripe_setup_intent_payment_method_types', $types, $currency);

        return $this->filter_incompatible_payment_method_types(array_unique($types), $min_amount, $max_amount, $currency);
    }

    /**
     * Get the payment method types for PaymentIntents (one-time payments)
     *
     * @param  string|null $setup_future_usage The setup future usage value.
     * @param  float|null  $min_amount         The smallest payment the order requires.
     * @param  float|null  $max_amount         The largest payment the order requires.
     * @param  string|null $currency           Charge currency (null = primary).
     * @return array The filtered payment method types
     */
    public function get_payment_intent_payment_method_types($setup_future_usage = null, ?float $min_amount = null, ?float $max_amount = null, ?string $currency = null)
    {
        $types           = ['card'];
        $payment_methods = $this->settings->payment_methods;
        $currency        = $this->resolve_payment_method_currency($currency);

        if (is_array($payment_methods) && count($payment_methods)) {
            foreach ($this->get_available_payment_methods($currency) as $payment_method) {
                if (in_array($payment_method['key'], $payment_methods, true) && in_array('payment_intents', $payment_method['capabilities'], true)) {
                    if (is_null($setup_future_usage)) {
                        $types[] = $payment_method['key'];
                    } elseif (in_array('setup_future_usage', $payment_method['capabilities'], true)) {
                        $types[] = $payment_method['key'];
                    }
                }
            }
        }

        $types = MeprHooks::apply_filters('mepr_stripe_payment_intent_payment_method_types', $types, $currency);

        return $this->filter_incompatible_payment_method_types(array_unique($types), $min_amount, $max_amount, $currency);
    }

    /**
     * Get the payment method types for Subscriptions (paid trials, recurring subscriptions)
     *
     * @param  float|null  $min_amount The smallest payment the order requires.
     * @param  float|null  $max_amount The largest payment the order requires.
     * @param  string|null $currency   Charge currency (null = primary).
     * @return array The filtered payment method types
     */
    public function get_subscription_payment_method_types(?float $min_amount = null, ?float $max_amount = null, ?string $currency = null)
    {
        $types           = ['card'];
        $payment_methods = $this->settings->payment_methods;
        $currency        = $this->resolve_payment_method_currency($currency);

        if (is_array($payment_methods) && count($payment_methods)) {
            foreach ($this->get_available_payment_methods($currency) as $payment_method) {
                if (in_array($payment_method['key'], $payment_methods, true) && in_array('subscriptions', $payment_method['capabilities'], true)) {
                    $types[] = $payment_method['key'];
                }
            }
        }

        $types = MeprHooks::apply_filters('mepr_stripe_subscription_payment_method_types', $types, $currency);

        return $this->filter_incompatible_payment_method_types(array_unique($types), $min_amount, $max_amount, $currency);
    }

    /**
     * Get the payment method types for the SetupIntent when updating a subscription's payment method
     *
     * @param  float|null  $min_amount The smallest payment the order requires.
     * @param  float|null  $max_amount The largest payment the order requires.
     * @param  string|null $currency   Charge currency (null = primary).
     * @return array The filtered payment method types
     */
    public function get_update_setup_intent_payment_method_types(?float $min_amount = null, ?float $max_amount = null, ?string $currency = null)
    {
        $types           = ['card'];
        $payment_methods = $this->settings->payment_methods;
        $currency        = $this->resolve_payment_method_currency($currency);

        if (is_array($payment_methods) && count($payment_methods)) {
            foreach ($this->get_available_payment_methods($currency) as $payment_method) {
                if (in_array($payment_method['key'], $payment_methods, true) && in_array('setup_intents', $payment_method['capabilities'], true)) {
                    $types[] = $payment_method['key'];
                }
            }
        }

        $types = MeprHooks::apply_filters('mepr_stripe_update_setup_intent_payment_method_types', $types, $currency);

        return $this->filter_incompatible_payment_method_types(array_unique($types), $min_amount, $max_amount, $currency);
    }

    /**
     * Get the smallest and largest payment an order will require.
     *
     * A zero is not a payment, so it takes no part in the range: an order that
     * charges nothing at checkout is constrained only by its renewals, and an
     * order with no payments at all constrains nothing.
     *
     * @param  float ...$amounts Every payment the order produces, in any order.
     * @return array{0: float|null, 1: float|null} The smallest and the largest, both null when there are none
     */
    public function payment_amount_range(float ...$amounts): array
    {
        $payments = array_filter($amounts, static function (float $amount): bool {
            return $amount > 0.00;
        });

        return count($payments) ? [min($payments), max($payments)] : [null, null];
    }

    /**
     * Get every renewal payment an order commits to: one for the main
     * subscription and one for each subscription order bump.
     *
     * @param  MeprSubscription|null $sub                The order's main subscription (null when it has none).
     * @param  MeprSubscription[]    $bump_subscriptions The subscriptions created by the order bumps.
     * @return float[] The amount each subscription renews at.
     */
    private function get_renewal_amounts(?MeprSubscription $sub, array $bump_subscriptions): array
    {
        $renewals = [];

        if ($sub instanceof MeprSubscription) {
            $renewals[] = (float) $sub->total;
        }

        foreach ($bump_subscriptions as $subscription) {
            $renewals[] = (float) $subscription->total;
        }

        return $renewals;
    }

    /**
     * The currency a subscription bills in.
     *
     * A subscription carries its own currency and legacy rows carry none, so
     * the store primary is the fallback. Both the account page's mount and the
     * SetupIntent it creates read this, so they cannot disagree about which
     * methods the subscription's renewals allow.
     *
     * @param  MeprSubscription $sub The subscription.
     * @return string
     */
    public function subscription_currency(MeprSubscription $sub): string
    {
        return !empty($sub->currency)
            ? (string) $sub->currency
            : MeprOptions::fetch()->currency_code;
    }

    /**
     * Whether an order's payment range falls outside a payment method's own limits.
     *
     * Judges the smallest payment against the method's floor and the largest against
     * its ceiling. A null bound is unconstrained, so it clears that end. Both ends are
     * always considered, because a method excluded for only one of them is the mistake
     * this range model exists to prevent.
     *
     * @param  float|null $min_amount The smallest payment the order requires.
     * @param  float|null $max_amount The largest payment the order requires.
     * @param  float|null $floor      The method's minimum supported payment, or null for none.
     * @param  float|null $ceiling    The method's maximum supported payment, or null for none.
     * @return boolean
     */
    private function payment_range_outside_limits(?float $min_amount, ?float $max_amount, ?float $floor, ?float $ceiling): bool
    {
        if (!is_null($floor) && !is_null($min_amount) && $min_amount < $floor) {
            return true;
        }

        return !is_null($ceiling) && !is_null($max_amount) && $max_amount > $ceiling;
    }

    /**
     * Filter out payment methods that are incompatible with the current setup or payment amount
     *
     * An order produces a range of payments: the charge taken at checkout and
     * every renewal it commits to. A method has to be able to take all of them,
     * so its lower bound is judged against the smallest and its upper bound
     * against the largest. Judging either bound against the wrong end lets
     * through a method that fails on one of the payments.
     *
     * Both null means the order takes no payment at all, which is no constraint:
     * there is nothing for a method to be incompatible with.
     *
     * @param  array       $types      The payment method types to filter.
     * @param  float|null  $min_amount The smallest payment the order requires.
     * @param  float|null  $max_amount The largest payment the order requires.
     * @param  string|null $currency   Charge currency (null = primary).
     * @return array
     */
    private function filter_incompatible_payment_method_types(array $types, ?float $min_amount = null, ?float $max_amount = null, ?string $currency = null)
    {
        $mepr_options = MeprOptions::fetch();
        $currency     = $this->resolve_payment_method_currency($currency);

        // A zero is no payment, so a falsy bound means unconstrained. A caller
        // with one amount to give passes it as the min alone, and the max
        // falling back to it judges both of a method's bounds against that
        // single amount.
        $min_amount = $min_amount ?: null;
        $max_amount = $max_amount ?: $min_amount;

        // Each limit below is denominated in one currency. The list reaching
        // this point is already filtered to methods that settle in the charge
        // currency (get_available_payment_methods), so a single-currency
        // method meets its limit only when that limit's currency is the
        // charge currency. Afterpay is the one method offered across several
        // currencies, so its ceiling reads $currency directly. A new
        // multi-currency method with an amount limit needs the same
        // treatment, as does anything the
        // mepr_stripe_*_payment_method_types filters add, since those run
        // after the currency filter and before this one.
        $key = array_search('affirm', $types, true);
        if ($key !== false) {
            if ($this->payment_range_outside_limits($min_amount, $max_amount, 50, null)) {
                // Affirm does not support a payment amount less than 50 USD.
                array_splice($types, $key, 1);
            } elseif ($mepr_options->show_address_fields) {
                $country = $this->get_address_country();

                if (!empty($country) && $country !== 'US') {
                    // The address country must be either not set, or set to 'US' when using Affirm.
                    array_splice($types, $key, 1);
                }
            }
        }

        $key = array_search('afterpay_clearpay', $types, true);
        if ($key !== false) {
            if (!$mepr_options->show_fname_lname || !$mepr_options->require_fname_lname || !$mepr_options->show_address_fields || !$mepr_options->require_address_fields) {
                // Name and Address fields are required to use Afterpay/Clearpay.
                array_splice($types, $key, 1);
            } else {
                // Check if outside transaction limits: https://stripe.com/docs/payments/afterpay-clearpay#collection-schedule.
                if (
                    (!is_null($min_amount) && $min_amount < 1) ||
                    (!is_null($max_amount) && (
                        (in_array($currency, ['AUD', 'CAD', 'NZD'], true) && $max_amount > 2000) ||
                        (in_array($currency, ['GBP', 'EUR'], true) && $max_amount > 1000) ||
                        ($currency === 'USD' && $max_amount > 4000)
                    ))
                ) {
                    array_splice($types, $key, 1);
                }
            }
        }

        $key = array_search('cashapp', $types, true);
        if ($key !== false) {
            if ($mepr_options->show_address_fields) {
                $country = $this->get_address_country();

                if (!empty($country) && $country !== 'US') {
                    // The address country must be either not set, or set to 'US' when using CashApp.
                    array_splice($types, $key, 1);
                }
            }
        }

        $key = array_search('konbini', $types, true);
        if ($key !== false) {
            if ($this->payment_range_outside_limits($min_amount, $max_amount, 120, 300000)) {
                // Konbini does not support a payment amount less than 120 or greater than 300000 JPY.
                array_splice($types, $key, 1);
            }
        }

        $key = array_search('boleto', $types, true);
        if ($key !== false) {
            if ($this->payment_range_outside_limits($min_amount, $max_amount, 5, 49999.99)) {
                // Boleto does not support a payment amount less than 5 or greater than 49999.99 BRL.
                array_splice($types, $key, 1);
            }
        }

        $key = array_search('oxxo', $types, true);
        if ($key !== false) {
            if ($this->payment_range_outside_limits($min_amount, $max_amount, 10, 10000)) {
                // OXXO does not support a payment amount less than 10 or greater than 10000 MXN.
                array_splice($types, $key, 1);
            }
        }

        $key = array_search('twint', $types, true);
        if ($key !== false) {
            if ($this->payment_range_outside_limits($min_amount, $max_amount, null, 5000)) {
                // TWINT does not support a payment amount greater than 5000 CHF.
                array_splice($types, $key, 1);
            }
        }

        $key = array_search('pay_by_bank', $types, true);
        if ($key !== false) {
            if ($this->payment_range_outside_limits($min_amount, $max_amount, 0.50, 10000)) {
                // Pay by Bank does not support a payment amount less than 0.50 or greater than 10000 GBP by default.
                array_splice($types, $key, 1);
            }
        }

        return $types;
    }

    /**
     * Get the customer's address country from the post data or saved user data
     *
     * @return string
     */
    private function get_address_country()
    {
        $country = isset($_POST['mepr-address-country']) ? sanitize_text_field(wp_unslash($_POST['mepr-address-country'])) : '';

        if (empty($country) && is_user_logged_in()) {
            $country = get_user_meta(get_current_user_id(), 'mepr-address-country', true);
        }

        return $country;
    }

    /**
     * Create a PaymentIntent via the Stripe API
     *
     * @param  float               $amount             The payment amount.
     * @param  string              $customer_id        The Stripe Customer ID.
     * @param  MeprTransaction     $txn                The MemberPress transaction.
     * @param  MeprProduct         $prd                The MemberPress product.
     * @param  string|null         $setup_future_usage Set the setup_future_usage parameter.
     * @param  MeprOrderQuote|null $quote              The submit quote that priced the order.
     * @param  float|null          $min_payment        The smallest payment the order requires, defaulting to this charge.
     * @param  float|null          $max_payment        The largest payment the order requires, defaulting to this charge.
     * @param  string|null         $currency           Charge currency (null = primary).
     * @return stdClass                                The Stripe PaymentIntent data
     * @throws MeprHttpException                       If there was an HTTP error connecting to Stripe.
     * @throws MeprRemoteException                     If there was an invalid or error response from Stripe.
     */
    public function create_payment_intent($amount, $customer_id, MeprTransaction $txn, MeprProduct $prd, $setup_future_usage = null, ?MeprOrderQuote $quote = null, ?float $min_payment = null, ?float $max_payment = null, $currency = null)
    {
        $mepr_options    = MeprOptions::fetch();
        $charge_currency = !empty($currency)
            ? strtoupper((string) $currency)
            : strtoupper($mepr_options->currency_code ?: 'USD');
        $min_payment     = $min_payment ?? (float) $amount;
        $max_payment     = $max_payment ?? (float) $amount;

        $args = [
            'amount'               => $this->to_zero_decimal_amount($amount, $charge_currency),
            'currency'             => $charge_currency,
            'customer'             => $customer_id,
            'payment_method_types' => $this->get_payment_intent_payment_method_types($setup_future_usage, $min_payment, $max_payment, $charge_currency),
            'description'          => $prd->post_title,
            'metadata'             => [
                'platform'              => 'MemberPress Connect acct_1FIIDhKEEWtO8ZWC',
                'transaction_id'        => $txn->id,
                'site_url'              => get_site_url(),
                'ip_address'            => MeprAntiCardTestingCtrl::get_ip(),
                'memberpress_product'    => $prd->post_title,
                'memberpress_product_id' => $prd->ID,
            ],
        ];

        if (!is_null($setup_future_usage)) {
            $args['setup_future_usage'] = $setup_future_usage;
        }

        $args = MeprHooks::apply_filters('mepr_stripe_payment_intent_args', $args, $txn);

        // Site C — PaymentIntent path. `$args['amount']` is already in the currency's zero-decimal
        // form from to_zero_decimal_amount a few lines above, so the math is direct. The fee
        // rounds to the nearest unit with a half rounding up as Stripe rounds a percent fee,
        // and the round(…, 6) clears float representation error before rounding. The fee
        // metadata is relayed only with a fee, so a fee that rounds to zero carries none.
        $fee         = $this->fee_service()->fetch_fee($this->id);
        $fee_percent = $fee['percent'];
        if ($fee_percent > 0) {
            $application_fee = (int) round(round((int) $args['amount'] * $fee_percent / 100, 6));
            if ($application_fee > 0) {
                $args['application_fee_amount'] = $application_fee;
                $args                           = self::merge_fee_metadata($args, $fee['metadata']);
            }
        }

        if ($quote instanceof MeprOrderQuote) {
            $args = $this->add_payment_intent_tax_calculation($args, $quote);
            $args = $this->add_payment_intent_line_items($args, $txn, $quote, $charge_currency);
        }

        $payment_intent = (object) $this->send_stripe_request('payment_intents', $args, 'post');

        return $payment_intent;
    }

    /**
     * Attach the submit quote's tax calculation to the PaymentIntent args.
     *
     * Under automatic tax, a one-time payment charged as a bare PaymentIntent
     * carries its tax calculation via hooks[inputs][tax][calculation]
     * (Stripe's simplified PaymentIntents integration): Stripe records the
     * tax transaction itself when the PaymentIntent succeeds and reverses it
     * when the payment is refunded, so Stripe-gateway transactions never
     * record manually; see MeprStripeTaxIntegration::create_tax_transaction().
     *
     * The attached calculation is the one the submit quote priced the order
     * with: the PaymentIntent amount is that quote's total, so the filed
     * amounts and the charged amount are one number by construction. A
     * rate-based quote (automatic tax off, or a state Stripe cannot price)
     * carries no calculation and attaches nothing.
     *
     * @param  array          $args  The PaymentIntent creation args.
     * @param  MeprOrderQuote $quote The submit quote that priced the order.
     * @return array
     */
    private function add_payment_intent_tax_calculation(array $args, MeprOrderQuote $quote): array
    {
        if (
            !isset($args['amount'])
            || $quote->engine !== MeprOrderQuote::ENGINE_STRIPE_AUTOMATIC
            || $quote->calculation_id === ''
        ) {
            return $args;
        }

        $args['hooks'] = [
            'inputs' => [
                'tax' => [
                    'calculation' => $quote->calculation_id,
                ],
            ],
        ];

        return $args;
    }

    /**
     * Apply a charged amount breakdown to a transaction unless the stored
     * row already carries it.
     *
     * With the allocation persisted at submission, the webhook copy is a
     * verifier: the stored row normally equals the charged breakdown and
     * nothing is rewritten. A divergence (a hosted address change on
     * Stripe's page, a failed-open persistence step) is copied
     * over the stored row and logged, so the recorded amount always
     * equals the charged reality.
     *
     * @param  MeprTransaction $transaction The stored transaction.
     * @param  array           $breakdown   The charged breakdown.
     * @return boolean Whether the breakdown was copied (false: already equal).
     */
    private function verify_amount_breakdown(MeprTransaction $transaction, array $breakdown): bool
    {
        $matches = round((float) $transaction->tax_rate, 3) === round((float) ($breakdown['tax_rate'] ?? 0), 3)
            && (string) $transaction->tax_desc === (string) ($breakdown['tax_desc'] ?? '')
            && (string) $transaction->tax_class === (string) ($breakdown['tax_class'] ?? '');

        foreach (['amount', 'total', 'tax_amount', 'tax_reversal_amount'] as $field) {
            if (round((float) $transaction->$field, 2) !== round((float) ($breakdown[$field] ?? 0), 2)) {
                $matches = false;
                break;
            }
        }

        if ($matches) {
            return false;
        }

        MeprUtils::debug_log(sprintf(
            'stripe-tax-divergence: txn %d stored %s + %s tax = %s differs from charged %s + %s tax = %s; copying the charged figures',
            $transaction->id,
            $transaction->amount,
            $transaction->tax_amount,
            $transaction->total,
            $breakdown['amount'],
            $breakdown['tax_amount'],
            $breakdown['total']
        ));

        $transaction->apply_amount_breakdown($breakdown);

        return true;
    }

    /**
     * Sync a pending hosted order's tax rows from its Checkout session at
     * return time.
     *
     * A hosted customer can change their billing address on Stripe's page,
     * so the charged tax can differ from the preview persisted at
     * submission. The webhook copy corrects that within seconds, but the
     * customer can reach the thank-you page first. When the order is
     * still pending at return time, the session's charged split is
     * verified onto the stored rows, so the first render already shows
     * the charged reality.
     * Value writes go through verify_amount_breakdown(), so racing the
     * webhook is harmless: both writers derive from the same session, and
     * the later one finds equal rows and does nothing. Completion stays
     * with the webhook, guaranteed by the persistence shape: corrections
     * land as a conditional tax-field update that fires only while the
     * stored row is still pending, so a webhook completing the order
     * mid-sync is never overwritten (storing the whole row would knock it
     * back to pending under the session trans_num, with nothing left to
     * re-complete it). Fail-open: any failure is logged and leaves the
     * rows for the webhook copy.
     *
     * @param  MeprTransaction $txn The main transaction of the return.
     * @return void
     */
    private function sync_pending_session_taxes(MeprTransaction $txn): void
    {
        if (
            !self::use_automatic_tax()
            || strpos((string) $txn->trans_num, 'cs_') !== 0
            || $txn->status !== MeprTransaction::$pending_str
        ) {
            return;
        }

        try {
            $checkout_session = (object) $this->send_stripe_request("checkout/sessions/$txn->trans_num", [
                'expand' => [
                    'line_items.data.taxes',
                    'total_details.breakdown',
                    'subscription.latest_invoice.total_tax_amounts.tax_rate',
                ],
            ], 'get');

            $order                   = $txn->order();
            $order_bump_transactions = $order instanceof MeprOrder ? MeprTransaction::get_all_by_order_id($order->id, $txn->id) : [];

            if (count($order_bump_transactions)) {
                $transactions = array_merge([$txn], $order_bump_transactions);
                $breakdowns   = $this->session_line_amount_breakdowns($checkout_session, $transactions);

                foreach ($transactions as $transaction) {
                    if (isset($breakdowns[(int) $transaction->id]) && $this->verify_amount_breakdown($transaction, $breakdowns[(int) $transaction->id])) {
                        $this->store_pending_tax_fields($transaction);
                    }
                }
            } elseif ($txn->is_one_time_payment()) {
                $breakdown = $this->session_amount_breakdown($checkout_session);

                if (is_array($breakdown) && $this->verify_amount_breakdown($txn, $breakdown)) {
                    $this->store_pending_tax_fields($txn);
                }
            } else {
                // A single-subscription session charges through its first
                // invoice; the invoice's charged split verifies onto the
                // pending row. Renewals never reach here: their rows are
                // webhook-born, never pending at a return.
                $invoice = (array) ($checkout_session->subscription['latest_invoice'] ?? []);

                if (!empty($invoice)) {
                    $breakdown = $this->invoice_amount_breakdown((object) $invoice);

                    if (is_array($breakdown) && $this->verify_amount_breakdown($txn, $breakdown)) {
                        $this->store_pending_tax_fields($txn);
                    }
                }
            }
        } catch (Exception $e) {
            MeprUtils::debug_log(sprintf('stripe-tax-return-sync-failed: txn %d: %s', $txn->id, $e->getMessage()));
        }
    }

    /**
     * Persist a tax-field correction as a conditional update.
     *
     * One statement updates the tax fields alone, and only while the
     * stored row is still pending, so a writer completing the order
     * mid-correction keeps its completion and its charge trans_num.
     * The webhook copy and the return-time sync both derive their
     * figures from the same session, so whichever writes second finds
     * equal rows and nothing is lost by writing nothing; the in-memory
     * instance keeps the applied figures for the render either way.
     *
     * @param  MeprTransaction $transaction The corrected transaction.
     * @return void
     */
    private function store_pending_tax_fields(MeprTransaction $transaction): void
    {
        global $wpdb;

        $mepr_db = new MeprDb();

        $wpdb->update(
            $mepr_db->transactions,
            [
                'amount'              => (string) $transaction->amount,
                'total'               => (string) $transaction->total,
                'tax_amount'          => (string) $transaction->tax_amount,
                'tax_rate'            => (string) $transaction->tax_rate,
                'tax_desc'            => (string) $transaction->tax_desc,
                'tax_class'           => (string) $transaction->tax_class,
                'tax_reversal_amount' => (string) $transaction->tax_reversal_amount,
            ],
            [
                'id'     => $transaction->id,
                'status' => MeprTransaction::$pending_str,
            ]
        );
    }

    /**
     * Reconcile a subscription's first-period rows to its charged invoice.
     *
     * Stripe computes the first invoice's tax with automatic_tax on its own
     * side, independent of the submit quote, so a degraded quote (a transient
     * pricing failure, or Stripe Tax enabled with no designated tax payment
     * method) can stamp rate-based figures that the charged invoice overrides.
     * The charged order total is checked first; only a divergence there
     * re-derives per line from the invoice's line items, so the line read
     * fires rarely. A divergent row is copied over and logged through
     * verify_amount_breakdown(). Called from the subscription_create webhook
     * and from the return handler, so the thank-you page reconciles before the
     * webhook lands; whichever writer runs second finds equal rows and does
     * nothing. A mixed order whose lines cannot be attributed leaves the
     * stamps and logs.
     *
     * The main's subscription rides in as the caller's LIVE instance: both
     * callers hold it and store it later, so a trial-trio correction must
     * land on that instance, never on a re-fetched copy the later store
     * would clobber.
     *
     * @param  MeprTransaction       $txn       The pending main subscription transaction.
     * @param  MeprSubscription|null $sub       The main's live subscription instance.
     * @param  MeprTransaction[]     $bump_txns The order's other pending transactions.
     * @param  stdClass              $invoice   The charged first invoice, total_tax_amounts.tax_rate expanded.
     * @return void
     */
    private function reconcile_subscription_invoice_taxes(MeprTransaction $txn, ?MeprSubscription $sub, array $bump_txns, stdClass $invoice): void
    {
        if (!self::use_automatic_tax()) {
            return;
        }

        $order_breakdown = $this->invoice_amount_breakdown($invoice);

        if (!is_array($order_breakdown)) {
            return;
        }

        $transactions  = array_merge([$txn], $bump_txns);
        $stamped_total = 0.0;
        $charging      = [];

        foreach ($transactions as $transaction) {
            $stamped_total += (float) $transaction->total;

            if ($this->charges_at_purchase($transaction)) {
                $charging[] = $transaction;
            }
        }

        // The charged order total agrees with the stamps: they carry Stripe's
        // own allocation and nothing is re-derived.
        if (round($stamped_total, 2) === round((float) $order_breakdown['total'], 2)) {
            return;
        }

        // When one component charges at purchase, the whole order total is
        // that row's own split, so copy the order-level breakdown onto it
        // directly. This is the lone subscription and the single-charge shape
        // whose only other bumps are free or free-trial (charging nothing
        // now), where the charging row can be a recurring subscription line
        // the invoice does not tag per transaction. Only a genuinely
        // multi-charge order needs the per-line re-derivation.
        if (count($charging) <= 1) {
            $target = $charging[0] ?? $txn;

            if ($this->verify_amount_breakdown($target, $order_breakdown)) {
                $target->store();

                // A corrected bump's subscription is not held by any
                // caller here, so a fresh load cannot be clobbered.
                $target_sub = $target === $txn ? $sub : ($target->subscription() ?: null);

                if ($target_sub instanceof MeprSubscription && $target_sub->trial && $target_sub->trial_days > 0) {
                    $this->reconcile_trial_figures($target_sub, $order_breakdown);
                }
            }

            return;
        }

        // A multi-charge order re-derives each line from the invoice, verify-only.
        $breakdowns = $this->invoice_line_amount_breakdowns($invoice, $transactions);

        if (empty($breakdowns)) {
            MeprUtils::debug_log(sprintf(
                'stripe-tax-divergence: order %d first invoice %s total %s diverges from the stamped rows, but its lines could not be attributed; the stamps stand',
                (int) $txn->order_id,
                $invoice->id,
                $order_breakdown['total']
            ));

            return;
        }

        foreach ($transactions as $transaction) {
            if (isset($breakdowns[(int) $transaction->id]) && $this->verify_amount_breakdown($transaction, $breakdowns[(int) $transaction->id])) {
                $transaction->store();

                $subscription = $transaction === $txn ? $sub : ($transaction->subscription() ?: null);

                if ($subscription instanceof MeprSubscription && $subscription->trial && $subscription->trial_days > 0) {
                    $this->reconcile_trial_figures($subscription, $breakdowns[(int) $transaction->id]);
                }
            }
        }
    }

    /**
     * Copy a corrected first-period breakdown onto a trialing
     * subscription's trial figures.
     *
     * The trial figures are the first period's display authority:
     * activate_subscription() restamps the confirmation row from
     * first_period_breakdown(), so a correction that reached only the
     * transaction row would be reverted at activation.
     *
     * @param  MeprSubscription $sub       The trialing subscription.
     * @param  array            $breakdown The charged breakdown.
     * @return void
     */
    private function reconcile_trial_figures(MeprSubscription $sub, array $breakdown): void
    {
        $sub->trial_amount              = $breakdown['amount'];
        $sub->trial_tax_amount          = $breakdown['tax_amount'];
        $sub->trial_total               = $breakdown['total'];
        $sub->trial_tax_reversal_amount = $breakdown['tax_reversal_amount'];
        $sub->store();
    }

    /**
     * Add L2/L3 card data to the PaymentIntent args.
     *
     * One line per charged component with the net unit cost and its tax from
     * MemberPress's own transaction fields, plus order and customer
     * references, so eligible commercial cards qualify for L2/L3 interchange
     * rates. Independent of any tax engine — zero-tax lines are valid.
     *
     * Arithmetic validation is disabled so a totals mismatch (a third-party
     * filter changing the amount, zero-decimal-currency rounding) can never
     * block the sale: Stripe creates the PaymentIntent, surfaces the
     * mismatch in amount_details.error, and withholds the data from card
     * networks for that charge.
     *
     * @param  array           $args     The PaymentIntent creation args.
     * @param  MeprTransaction $txn      The main transaction the PaymentIntent charges.
     * @param  MeprOrderQuote  $quote    The submit quote that priced the order.
     * @param  string          $currency The currency the PaymentIntent charges in.
     * @return array
     */
    private function add_payment_intent_line_items(
        array $args,
        MeprTransaction $txn,
        MeprOrderQuote $quote,
        string $currency
    ): array {
        /**
         * Filter whether the PaymentIntent carries L2/L3 payment line items.
         *
         * The line items send product names and order/customer references to
         * card networks (and Klarna displays them to the customer), so a
         * merchant can disable them site-wide or per purchase.
         *
         * @param boolean         $enabled Whether to send the line items.
         * @param MeprTransaction $txn     The main transaction the PaymentIntent charges.
         */
        if (!MeprHooks::apply_filters('mepr_stripe_payment_intent_line_items', true, $txn)) {
            return $args;
        }

        $line_items = [];

        foreach ($quote->lines as $line) {
            $line_items[] = [
                'product_name'    => (new MeprProduct($line->product_id))->display_name(),
                'product_code'    => (string) $line->product_id,
                'unit_cost'       => $this->to_zero_decimal_amount($line->amount, $currency),
                'quantity'        => 1,
                'unit_of_measure' => 'each',
                'tax'             => ['total_tax_amount' => $this->to_zero_decimal_amount($line->tax_amount, $currency)],
            ];
        }

        if (empty($line_items)) {
            return $args;
        }

        $order = $txn->order();

        $args['payment_details'] = [
            'customer_reference' => (string) $txn->user_id,
            'order_reference'    => $order instanceof MeprOrder ? "ord_$order->id" : "txn_$txn->id",
        ];

        $args['amount_details'] = [
            'enforce_arithmetic_validation' => 'false',
            'line_items'                    => $line_items,
        ];

        return $args;
    }

    // phpcs:disable Squiz.Commenting.FunctionCommentThrowTag.WrongNumber
    /**
     * Create a Checkout session and redirect to Stripe.
     *
     * @param  MeprTransaction $txn                    The transaction for the main product.
     * @param  array           $order_bump_product_ids The array of order bump product IDs.
     * @throws MeprGatewayException                    If there was an error processing the transaction.
     * @throws MeprHttpException                       If there was an HTTP error connecting to Stripe.
     * @throws MeprRemoteException                     If there was an invalid or error response from Stripe.
     * @throws Exception                               If there was an error processing order bumps.
     */
    protected function checkout_redirect(MeprTransaction $txn, array $order_bump_product_ids)
    {
        $order_bump_products = MeprCheckoutCtrl::get_order_bump_products($txn->product_id, $order_bump_product_ids);
        $order_bumps         = $this->process_order($txn, $order_bump_products);
        $prd                 = $txn->product();
        $usr                 = $txn->user();
        $cpn                 = $txn->coupon();
        $coupon_code         = $cpn instanceof MeprCoupon ? $cpn->post_title : '';
        $sub                 = $txn->subscription();
        $sub                 = $sub instanceof MeprSubscription ? $sub : null;

        if (!$prd->ID) {
            throw new MeprGatewayException(esc_html__('Product not found', 'memberpress'));
        }

        if (!$usr->ID) {
            throw new MeprGatewayException(esc_html__('User not found', 'memberpress'));
        }

        MeprHooks::do_action('mepr_stripe_checkout_pending', $txn, $usr);

        if (count($order_bumps)) {
            $this->create_multi_item_checkout_session($txn, $prd, $usr, $coupon_code, $order_bumps);
        } else {
            $this->create_checkout_session($txn, $prd, $usr, $sub);
        }
    }
    // phpcs:enable Squiz.Commenting.FunctionCommentThrowTag.WrongNumber

    /**
     * Process payment form submission
     *
     * @param  MeprTransaction $txn The transaction to process.
     * @throws MeprGatewayException When payment processing fails.
     * @return void
     */
    public function process_payment_form($txn)
    {
        if (isset($_REQUEST['mepr_payment_methods_hidden'])) {
            $order_bump_product_ids = isset($_POST['mepr_order_bumps']) && is_array($_POST['mepr_order_bumps']) ? array_map('intval', $_POST['mepr_order_bumps']) : [];
            $order_bump_products    = MeprCheckoutCtrl::get_order_bump_products($txn->product_id, $order_bump_product_ids);
            $this->process_order($txn, $order_bump_products);
        } elseif ($this->settings->stripe_checkout_enabled === 'on') {
            $order_bump_product_ids = isset($_POST['mepr_order_bumps']) && is_array($_POST['mepr_order_bumps']) ? array_map('intval', $_POST['mepr_order_bumps']) : [];
            $this->checkout_redirect($txn, $order_bump_product_ids);
        }

        throw new MeprGatewayException(esc_html__('Payment was unsuccessful, please check your payment details and try again.', 'memberpress'));
    }

    /**
     * Used to send data to a given payment gateway. In gateways which redirect
     * before this step is necessary this method should just be left blank.
     *
     * @param MeprTransaction $transaction The transaction object.
     *
     * @return void
     */
    public function process_payment($transaction)
    {
        // Not used.
    }

    /**
     * Used to record a successful recurring payment by the given gateway. It
     * should have the ability to record a successful payment or a failure. It is
     * this method that should be used when receiving an IPN from PayPal or a
     * Silent Post from Authorize.net.
     */
    public function record_subscription_payment()
    {
        // Not used.
    }

    /**
     * Handle a free invoice payment for a subscription
     *
     * This can happen if the customer has a credit balance in Stripe that covers the full recurring payment amount.
     *
     * @param MeprSubscription $sub       The subscription object.
     * @param float            $amount    The payment amount.
     * @param string           $trans_num The transaction number.
     *
     * @return void
     */
    public function record_free_sub_payment(MeprSubscription $sub, $amount, $trans_num)
    {
        if (MeprTransaction::txn_exists($trans_num)) {
            return;
        }

        $txn                  = new MeprTransaction();
        $txn->user_id         = $sub->user_id;
        $txn->product_id      = $sub->product_id;
        $txn->status          = MeprTransaction::$complete_str;
        $txn->txn_type        = MeprTransaction::$payment_str;
        $txn->trans_num       = $trans_num;
        $txn->gateway         = $this->id;
        $txn->subscription_id = $sub->id;
        $txn->set_gross($amount);
        $txn->store();
    }

    /**
     * Handle the Stripe `invoice.payment_succeeded` webhook
     *
     * @param  stdClass $invoice The Stripe Invoice data.
     * @throws MeprHttpException            If there was an HTTP error connecting to Stripe.
     * @throws MeprRemoteException          If there was an invalid or error response from Stripe.
     * @throws MeprGatewayException         When another request is still changing the subscription after the wait.
     */
    public function handle_invoice_payment_succeeded_webhook($invoice)
    {
        if (empty($invoice->subscription) || empty($invoice->customer)) {
            return;
        }

        // We don't do anything here for $0 invoices that are also the first subscription payment, or the first subscription
        // payment for Stripe Checkout, which the Checkout completion records. A subscription created by a resume is not a
        // Checkout subscription, so its first payment is recorded here on every site. Return early to avoid unnecessary
        // Stripe requests (to prevent rate limit errors).
        if (
            $invoice->billing_reason === 'subscription_create' &&
            (
                !isset($invoice->charge) ||
                ($this->settings->stripe_checkout_enabled === 'on' && !$this->is_resume_invoice($invoice))
            )
        ) {
            return;
        }

        // Fetch expanded invoice data from Stripe. This re-fetch is what puts
        // the invoice under this class's pinned API version, because the
        // webhook payload arrives in whatever shape the connected account's
        // endpoint version produces.
        //
        // `total_tax_amounts.tax_rate` is load-bearing for tax recording, and
        // for BOTH levels of it. Unexpanded, each `tax_rate` is a bare `txr_`
        // id string, which reshape_invoice_tax_rows() reads as a 0 percentage,
        // so charged_amount_breakdown() returns null and the allocation is
        // lost. invoice_line_amount_breakdowns() then resolves each line's
        // `tax_amounts` rate id through the map it builds from these expanded
        // rows, so this one expand serves the per-line reader as well and no
        // `lines.data.tax_amounts.tax_rate` expand is needed.
        $invoice = (object) $this->send_stripe_request("invoices/$invoice->id", [
            'expand' => [
                'charge',
                'customer',
                'payment_intent',
                'payment_intent.payment_method',
                'total_tax_amounts.tax_rate',
            ],
        ], 'get');

        $customer       = isset($invoice->customer) ? (object) $invoice->customer : null;
        $payment_method = isset($invoice->payment_intent['payment_method']) ? (object) $invoice->payment_intent['payment_method'] : null;

        $sub = MeprSubscription::get_one_by_subscr_id($invoice->subscription);

        if (!($sub instanceof MeprSubscription)) {
            if ($customer) {
                // Look for an old cus_xxx subscription.
                $sub = MeprSubscription::get_one_by_subscr_id($customer->id);
            }

            if (!($sub instanceof MeprSubscription)) {
                return;
            }
        }

        // If this isn't for us, bail.
        if ($sub->gateway !== $this->id) {
            return;
        }

        // A resume, pause or cancel of this subscription can be running at the
        // same moment, so the payment is recorded under the subscription's lock.
        $this->with_subscription_lock(
            $sub->id,
            fn(int $id) => $this->record_invoice_payment_succeeded(
                $invoice,
                new MeprSubscription($id),
                $customer,
                $payment_method
            ),
            self::SUBSCRIPTION_LOCK_WAIT
        );
    }

    /**
     * Whether the invoice belongs to a Stripe subscription created by a resume.
     *
     * @param  object $invoice The Stripe invoice.
     * @return boolean
     */
    private function is_resume_invoice(object $invoice): bool
    {
        return !empty($invoice->subscription_details['metadata'][self::RESUMED_SUBSCRIPTION_METADATA_KEY]);
    }

    /**
     * Record a paid subscription invoice from the payment webhook, while
     * holding the subscription's lock.
     *
     * @param  object           $invoice        The re-fetched Stripe invoice.
     * @param  MeprSubscription $sub            The subscription the invoice belongs to.
     * @param  object|null      $customer       The Stripe customer.
     * @param  object|null      $payment_method The Stripe payment method.
     * @return void
     */
    private function record_invoice_payment_succeeded(
        object $invoice,
        MeprSubscription $sub,
        ?object $customer,
        ?object $payment_method
    ): void {
        // The first-period allocation stamped on the pending row at
        // submission, read back when the first subscription charge is
        // recorded. A subscription created outside the pending-row flow,
        // and every renewal, leave this null and derive from the charged
        // invoice.
        $stamped_breakdown = null;

        if ($invoice->billing_reason === 'subscription_create') {
            $txn_res = MeprTransaction::get_one_by_trans_num($invoice->id);

            if (!empty($txn_res) && isset($txn_res->id)) {
                $txn = new MeprTransaction($txn_res->id);

                if (!empty($txn->id) && $txn->gateway === $this->id && (int) $txn->subscription_id === (int) $sub->id) {
                    $order                   = $txn->order();
                    $order_bump_transactions = $order instanceof MeprOrder ? MeprTransaction::get_all_by_order_id($order->id, $txn->id) : [];

                    $this->reconcile_subscription_invoice_taxes($txn, $sub, $order_bump_transactions, $invoice);

                    $stamped_breakdown = $txn->amount_breakdown();

                    if ($order instanceof MeprOrder && count($order_bump_transactions)) {
                        if (!$order->is_complete() && !$order->is_processing()) {
                              $order->update_meta('processing', true);

                              $this->record_cc_vars($sub, $payment_method);
                              $this->record_create_sub($sub);

                            if ($sub->trial && $sub->trial_days > 0) {
                                $amount                  = (float) $sub->trial_total;
                                $txn_expires_at_override = MeprUtils::ts_to_mysql_date(time() + MeprUtils::days($sub->trial_days), 'Y-m-d 23:59:59');
                            } else {
                                $amount                  = (float) $sub->total;
                                $txn_expires_at_override = null;
                            }

                            if ($amount > 0) {
                                $this->record_sub_payment($sub, $amount, sprintf('mi_%d_%s', $order->id, uniqid()), $this->get_card($payment_method), $txn_expires_at_override, $order->id, $txn->amount_breakdown());
                            }

                            foreach ($order_bump_transactions as $transaction) {
                                $trans_num = sprintf('mi_%d_%s', $order->id, uniqid());

                                if (!$transaction->is_payment_required()) {
                                    MeprTransaction::create_free_transaction($transaction, false, $trans_num);
                                    continue;
                                }

                                if ($transaction->is_one_time_payment()) {
                                    $this->record_one_time_payment($transaction, $trans_num);
                                } else {
                                    if ($customer && $payment_method) {
                                        try {
                                            $this->create_sub($transaction, $customer->id, $payment_method, $trans_num, $order->id, $transaction->amount_breakdown());
                                        } catch (Exception $e) {
                                            MeprUtils::debug_log(sprintf('stripe-order-bump-create-sub-failed: txn %d: %s', $transaction->id, $e->getMessage()));
                                            continue;
                                        }
                                    }
                                }
                            }

                            if (isset($invoice->charge['id'])) {
                                $order->trans_num = $invoice->charge['id'];
                            }

                            $order->status = MeprOrder::$complete_str;
                            $order->store();
                            $order->delete_meta('processing');
                        }

                        if ($payment_method && isset($customer->invoice_settings) && is_array($customer->invoice_settings)) {
                            $default_payment_method = isset($customer->invoice_settings['default_payment_method']) ? $customer->invoice_settings['default_payment_method'] : null;

                            if (empty($default_payment_method)) {
                                $this->set_customer_default_payment_method($customer->id, $payment_method->id);
                            }
                        }

                        return;
                    }
                }
            } else {
                // Check that this transaction hasn't been processed before.
                $txn_res = MeprTransaction::get_one_by_trans_num($invoice->subscription);

                if (isset($txn_res->id) && $txn_res->id > 0) {
                    return;
                }

                // A resume that charged immediately has already recorded this
                // charge and set the subscription's status.
                if (isset($invoice->charge['id']) && MeprTransaction::txn_exists($invoice->charge['id'])) {
                    return;
                }
            }

            $this->record_cc_vars($sub, $payment_method);
            $this->record_create_sub($sub);

            if ($payment_method && isset($customer->invoice_settings) && is_array($customer->invoice_settings)) {
                $default_payment_method = isset($customer->invoice_settings['default_payment_method']) ? $customer->invoice_settings['default_payment_method'] : null;

                if (empty($default_payment_method)) {
                    $this->set_customer_default_payment_method($customer->id, $payment_method->id);
                }
            }
        }

        if (isset($invoice->charge)) {
            $amount                  = (float) $invoice->charge['amount'];
            $txn_expires_at_override = null;

            // Detect zero-decimal from the invoice currency, not the site primary
            // (no active session on a webhook, so the default would be wrong).
            $invoice_currency = strtoupper($invoice->currency ?? '') ?: MeprOptions::fetch()->currency_code;
            if (!self::is_zero_decimal_currency($invoice_currency)) {
                $amount = $amount / 100;
            }

            if ($invoice->billing_reason === 'subscription_create' && $sub->trial && $sub->trial_days > 0) {
                $txn_expires_at_override = MeprUtils::ts_to_mysql_date(time() + MeprUtils::days($sub->trial_days), 'Y-m-d 23:59:59');
            }

            // A first subscription payment records the allocation stamped
            // at submission, the figures every surface displayed; a renewal
            // (and a subscription created outside the pending-row flow)
            // derives from the charged invoice.
            $breakdown = $invoice->billing_reason === 'subscription_create' && is_array($stamped_breakdown)
                ? $stamped_breakdown
                : $this->invoice_amount_breakdown($invoice);

            $this->record_sub_payment($sub, $amount, $invoice->charge['id'], $this->get_card($payment_method), $txn_expires_at_override, 0, $breakdown);
        } elseif ($invoice->billing_reason !== 'subscription_create') {
            $invoice_currency = strtoupper($invoice->currency ?? '') ?: MeprOptions::fetch()->currency_code;
            $amount           = self::is_zero_decimal_currency($invoice_currency) ? $invoice->total : $invoice->total / 100;

            $this->record_free_sub_payment($sub, $amount, $invoice->id);
        }
    }

    /**
     * Handle the invoice.payment_failed webhook
     *
     * Sends an email to the customer to pay the outstanding invoice.
     *
     * @param stdClass $invoice The Stripe Invoice object.
     */
    public function handle_invoice_payment_failed_webhook($invoice)
    {
        try {
            $email = MeprEmailFactory::fetch('MeprUserStripeInvoiceEmail');

            if ($email->enabled() && $invoice->hosted_invoice_url) {
                $sub = MeprSubscription::get_one_by_subscr_id($invoice->subscription);

                if (!($sub instanceof MeprSubscription)) {
                    // Look for an old cus_xxx subscription.
                    $sub = MeprSubscription::get_one_by_subscr_id($invoice->customer);
                }

                if (
                    $sub instanceof MeprSubscription &&
                    $sub->id > 0 &&
                    MeprHooks::apply_filters('mepr_send_invoice_payment_failed_email', $sub->txn_count > 1, $invoice, $sub)
                ) {
                    if ($sub->gateway !== $this->id) {
                        return;
                    }

                    $usr = $sub->user();

                    if ($usr->ID > 0) {
                        $email->to = $usr->formatted_email();

                        $params = array_merge(
                            MeprSubscriptionsHelper::get_email_params($sub),
                            ['stripe_invoice_url' => $invoice->hosted_invoice_url]
                        );

                        $email->send($params);
                    }
                }
            }
        } catch (Exception $e) {
            // Fail silently.
        }
    }

    /**
     * Handle the invoice.finalization_failed webhook.
     *
     * Stripe Tax with automatic_tax may fail to finalize an invoice when the
     * customer's billing address cannot be validated. We notify the member so
     * they can update their billing address and keep the subscription active.
     *
     * @param stdClass $invoice The Stripe Invoice object.
     */
    public function handle_invoice_finalization_failed_webhook($invoice)
    {
        try {
            $sub = MeprSubscription::get_one_by_subscr_id($invoice->subscription ?? '');

            if (!($sub instanceof MeprSubscription) || $sub->id <= 0) {
                // Look for an old cus_xxx subscription, mirroring payment_failed behavior.
                $sub = isset($invoice->customer) ? MeprSubscription::get_one_by_subscr_id($invoice->customer) : false;
            }

            if (!($sub instanceof MeprSubscription) || $sub->id <= 0) {
                return;
            }

            if ($sub->gateway !== $this->id) {
                // A different gateway instance will pick it up.
                return;
            }

            // Stripe retries finalization of the same invoice automatically,
            // so the member is notified once per invoice; a new billing
            // period fails on a new invoice and notifies afresh.
            $invoice_id = (string) ($invoice->id ?? '');

            if ($invoice_id !== '' && $sub->get_meta('stripe_finalization_failed_notice', true) === $invoice_id) {
                return;
            }

            $email = MeprEmailFactory::fetch('MeprUserStripeAddressInvalidEmail');

            if (!$email->enabled()) {
                return;
            }

            $usr = $sub->user();

            if ($usr->ID > 0) {
                $email->to = $usr->formatted_email();

                $params = MeprSubscriptionsHelper::get_email_params($sub);

                $email->send($params);

                if ($invoice_id !== '') {
                    $sub->update_meta('stripe_finalization_failed_notice', $invoice_id);
                }
            }
        } catch (Exception $e) {
            MeprUtils::debug_log(sprintf(
                'invoice_finalization_failed handling failed: %s',
                wp_json_encode([
                    'gateway_id' => $this->id,
                    'invoice_id' => $invoice->id ?? '',
                    'message'    => $e->getMessage(),
                ])
            ));
        }
    }

    /**
     * Handle the payment_intent.succeeded webhook
     *
     * Processes a successful PaymentIntent, creating subscriptions if necessary.
     *
     * @param stdClass $payment_intent The PaymentIntent object.
     *
     * @return void
     */
    public function handle_payment_intent_succeeded_webhook($payment_intent)
    {
        if (
            empty($payment_intent->id) ||
            empty($payment_intent->payment_method) ||
            empty($payment_intent->customer)
        ) {
            return;
        }

        $charge_id = $this->get_payment_intent_charge_id($payment_intent);
        if (empty($charge_id)) {
            return;
        }

        // --- Cart order branch ---
        // Look up a cart order by the PaymentIntent ID stored in order meta. Checked BEFORE
        // the transaction-based lookup so cart orders are handled atomically. A lookup failure
        // must never abort the legacy path, so swallow it and fall through.
        try {
            $cart_order = $this->find_cart_order_by_payment_intent($payment_intent->id);
        } catch (Exception $e) {
            MeprUtils::debug_log('Cart order PI lookup failed, falling back to legacy: ' . $e->getMessage());
            $cart_order = null;
        }
        if ($cart_order instanceof MeprOrder && $cart_order->order_type === MeprOrder::$cart_type_str) {
            $this->handle_cart_order_payment_intent_succeeded($cart_order, $payment_intent, $charge_id);
            return;
        }
        // --- End cart order branch ---
        $txn_res = MeprTransaction::get_one_by_trans_num($payment_intent->id);

        if (empty($txn_res) || !isset($txn_res->id)) {
            return;
        }

        $txn = new MeprTransaction($txn_res->id);

        if (empty($txn->id) || $txn->gateway !== $this->id) {
            return;
        }

        try {
            $payment_intent = (object) $this->send_stripe_request("payment_intents/$payment_intent->id", [
                'expand' => [
                    'payment_method',
                    'customer',
                ],
            ], 'get');

            $customer                = (object) $payment_intent->customer;
            $payment_method          = (object) $payment_intent->payment_method;
            $order                   = $txn->order();
            $order_bump_transactions = $order instanceof MeprOrder ? MeprTransaction::get_all_by_order_id($order->id, $txn->id) : [];

            if ($order instanceof MeprOrder && count($order_bump_transactions)) {
                if (!$order->is_complete() && !$order->is_processing()) {
                    $order->update_meta('processing', true);

                    foreach (array_merge([$txn], $order_bump_transactions) as $transaction) {
                        $trans_num = sprintf('mi_%d_%s', $order->id, uniqid());

                        if (!$transaction->is_payment_required()) {
                            MeprTransaction::create_free_transaction($transaction, false, $trans_num);
                            continue;
                        }

                        if ($transaction->is_one_time_payment()) {
                            $this->record_one_time_payment($transaction, $trans_num);
                        } else {
                            try {
                                $this->create_sub($transaction, $customer->id, $payment_method, $trans_num, $order->id, $transaction->amount_breakdown());
                            } catch (Exception $e) {
                                continue;
                            }
                        }
                    }

                    $order->trans_num = $charge_id;
                    $order->status    = MeprOrder::$complete_str;
                    $order->store();
                    $order->delete_meta('processing');
                }
            } else {
                $this->record_one_time_payment($txn, $charge_id);
            }

            if ($payment_method && isset($customer->invoice_settings) && is_array($customer->invoice_settings)) {
                $default_payment_method = isset($customer->invoice_settings['default_payment_method']) ? $customer->invoice_settings['default_payment_method'] : null;

                if (empty($default_payment_method) && isset($payment_intent->setup_future_usage)) {
                    $this->set_customer_default_payment_method($customer->id, $payment_method->id);
                }
            }
        } catch (Exception $e) {
            http_response_code(500);
            wp_die(esc_html($e->getMessage()));
        }
    }

    /**
     * Handle a succeeded PaymentIntent for a cart order: complete it, or backfill subscriptions.
     *
     * @param MeprOrder $cart_order     The cart order tied to the PaymentIntent.
     * @param object    $payment_intent The Stripe PaymentIntent from the webhook event.
     * @param string    $charge_id      The Stripe charge ID.
     */
    private function handle_cart_order_payment_intent_succeeded(MeprOrder $cart_order, $payment_intent, $charge_id)
    {
        // The place_order() method holds the processing lock (and upgrades cancel the old Stripe sub inside
        // that window). Returning 200 here would drop Stripe retries and leave mp-sub- placeholders.
        if ($cart_order->is_processing()) {
            http_response_code(500);
            wp_die(esc_html__('Cart order is still processing.', 'memberpress'));
        }

        try {
            // Expand the PI for the customer + payment method needed to create Stripe subscriptions.
            $pi_expanded = (object) $this->send_stripe_request("payment_intents/{$payment_intent->id}", [
                'expand' => ['payment_method', 'customer'],
            ], 'get');

            $customer       = (object) $pi_expanded->customer;
            $payment_method = (object) $pi_expanded->payment_method;

            if ($cart_order->is_complete()) {
                // The place_order() method beat us — only backfill any missing Stripe subscriptions.
                $this->create_missing_cart_subscriptions($cart_order, $customer, $payment_method);
            } else {
                $this->complete_cart_order_from_webhook($cart_order, $charge_id, $customer, $payment_method);
            }

            $this->maybe_set_cart_customer_default_payment_method($customer, $payment_method);
        } catch (Exception $e) {
            // Log for diagnosis, then 500 so Stripe retries the event (cart guards keep retries safe).
            MeprUtils::debug_log('Cart order webhook error for order ' . $cart_order->id . ': ' . $e->getMessage());
            http_response_code(500);
            wp_die(esc_html($e->getMessage()));
        }
    }

    /**
     * Complete a pending cart order from the webhook via the shared cart path
     * (address sync, txn completion, transaction-completed / tax reporting),
     * then create any missing Stripe subscriptions.
     *
     * Callers must only invoke this when the order is not already complete;
     * if place_order() won the race, they call create_missing_cart_subscriptions() only.
     *
     * @param MeprOrder $cart_order     The pending cart order to complete.
     * @param string    $charge_id      The Stripe charge ID.
     * @param object    $customer       The expanded Stripe customer.
     * @param object    $payment_method The expanded Stripe payment method.
     */
    private function complete_cart_order_from_webhook(MeprOrder $cart_order, $charge_id, $customer, $payment_method)
    {
        // Shared completion: syncs billing → mepr-address-*, fires signup /
        // transaction-completed hooks, activates MP subs.
        MeprCartCheckoutService::complete_cart_order($cart_order, (string) $charge_id);

        // Stripe gateway subscriptions (idempotent; cart already recorded first payment).
        $this->create_missing_cart_subscriptions($cart_order, $customer, $payment_method);

        MeprHooks::do_action('mepr_cart_order_completed_webhook', $cart_order, $charge_id);
    }

    /**
     * Ensure Stripe subscriptions exist for recurring cart lines (idempotent).
     *
     * Used by the synchronous place_order path so upgrades (which cancel the old Stripe sub inside
     * complete_cart_order and widen the webhook race) still get a real `sub_` even when the
     * payment_intent.succeeded webhook arrives during the processing lock. Webhooks also call this
     * via create_missing_cart_subscriptions().
     *
     * Resolves customer + payment method from the order's PaymentIntent / SetupIntent meta when
     * callers do not already have them.
     *
     * @param  MeprOrder   $cart_order     The cart order.
     * @param  object|null $customer       Optional Stripe Customer object (needs ->id).
     * @param  object|null $payment_method Optional Stripe PaymentMethod object (needs ->id).
     * @return void
     */
    public function ensure_cart_stripe_subscriptions(MeprOrder $cart_order, $customer = null, $payment_method = null)
    {
        $customer_id = (is_object($customer) && !empty($customer->id)) ? (string) $customer->id : '';
        $pm_id       = (is_object($payment_method) && !empty($payment_method->id)) ? (string) $payment_method->id : '';

        if ($customer_id === '' || $pm_id === '') {
            $resolved = $this->resolve_cart_customer_and_payment_method($cart_order);
            if ($resolved === null) {
                MeprUtils::debug_log(
                    'Cart Stripe subscription ensure skipped for order ' . $cart_order->id
                    . ': could not resolve customer/payment method from intent meta.'
                );
                return;
            }
            $customer       = $resolved['customer'];
            $payment_method = $resolved['payment_method'];
        }

        $this->create_missing_cart_subscriptions($cart_order, $customer, $payment_method);
        $this->maybe_set_cart_customer_default_payment_method($customer, $payment_method);
    }

    /**
     * Load Stripe customer + payment method from the cart order's PI or SI meta.
     *
     * @param  MeprOrder $cart_order The cart order.
     * @return array{customer:object,payment_method:object}|null
     */
    private function resolve_cart_customer_and_payment_method(MeprOrder $cart_order)
    {
        $pi_id = (string) $cart_order->get_meta('_mepr_cart_payment_intent_id', true);
        if ($pi_id !== '') {
            $expanded = (object) $this->send_stripe_request("payment_intents/{$pi_id}", [
                'expand' => ['payment_method', 'customer'],
            ], 'get');
            if (!empty($expanded->customer) && !empty($expanded->payment_method)) {
                return [
                    'customer'       => (object) $expanded->customer,
                    'payment_method' => (object) $expanded->payment_method,
                ];
            }
        }

        $si_id = (string) $cart_order->get_meta('_mepr_cart_setup_intent_id', true);
        if ($si_id !== '') {
            $expanded = (object) $this->send_stripe_request("setup_intents/{$si_id}", [
                'expand' => ['payment_method', 'customer'],
            ], 'get');
            if (!empty($expanded->customer) && !empty($expanded->payment_method)) {
                return [
                    'customer'       => (object) $expanded->customer,
                    'payment_method' => (object) $expanded->payment_method,
                ];
            }
        }

        return null;
    }

    /**
     * Backfill Stripe subscriptions for recurring transactions that don't have one yet (idempotent).
     *
     * @param MeprOrder $cart_order     The cart order whose lines are checked.
     * @param object    $customer       The expanded Stripe customer.
     * @param object    $payment_method The expanded Stripe payment method.
     */
    private function create_missing_cart_subscriptions(MeprOrder $cart_order, $customer, $payment_method)
    {
        foreach (MeprTransaction::get_all_by_order_id($cart_order->id) as $transaction) {
            if ($transaction->is_one_time_payment() || !$transaction->is_payment_required()) {
                continue;
            }

            $sub = $transaction->subscription();

            // Skip only when a REAL Stripe subscription already exists. The subscription model seeds
            // a `mp-sub-` placeholder id at creation, so !empty() would treat every cart sub as
            // already built and never create the gateway subscription.
            if (!($sub instanceof MeprSubscription) || strpos((string) $sub->subscr_id, 'sub_') === 0) {
                continue;
            }

            try {
                $this->create_cart_stripe_subscription($transaction, $customer->id, $payment_method);
            } catch (Exception $e) {
                // Do not swallow silently — currency/plan/coupon mismatches otherwise leave mp-sub- placeholders forever.
                MeprUtils::debug_log(
                    'Cart Stripe subscription create failed for txn ' . $transaction->id . ': ' . $e->getMessage()
                );
                continue;
            }
        }
    }

    /**
     * Create ONLY the Stripe subscription object for a cart recurring line. The cart already
     * activated the subscription and recorded the first payment synchronously at completion, so this
     * deliberately reuses create_subscription() but NOT create_sub()/record_create_sub() — the
     * latter routes through activate_subscription(), which rewrites the sub's first transaction into
     * a zero-amount confirmation txn and would wipe out the cart's recorded payment. It also skips
     * record_sub_payment() to avoid a duplicate payment record. Idempotent on a real `sub_` id.
     *
     * @param  MeprTransaction $txn            The cart recurring transaction.
     * @param  string          $customer_id    The Stripe Customer ID.
     * @param  object          $payment_method The Stripe PaymentMethod.
     * @return void
     */
    private function create_cart_stripe_subscription(MeprTransaction $txn, $customer_id, $payment_method)
    {
        $sub = $txn->subscription();
        if (!($sub instanceof MeprSubscription)) {
            return;
        }

        // Idempotent: a real Stripe subscription already exists (e.g. a webhook retry).
        if (strpos((string) $sub->subscr_id, 'sub_') === 0) {
            return;
        }

        if ($sub->trial && $sub->trial_days > 0) {
            $trial_days = (int) $sub->trial_days;
        } else {
            // The first period was already paid at checkout — trial the subscription one period so
            // Stripe's first charge is the next renewal, not an immediate duplicate charge.
            $now        = new DateTimeImmutable('now');
            $end        = $now->modify(sprintf('+%d %s', $sub->period, $sub->period_type));
            $trial_days = (int) $end->diff($now)->format('%a');
        }

        // The cart charges this line at checkout and the subscription bills every
        // renewal after it, so both figures are payments the order produces and
        // both bound which methods the subscription may carry.
        list($min_payment, $max_payment) = $this->payment_amount_range((float) $txn->total, (float) $sub->total);

        // Checkout and the webhook can both POST /v1/subscriptions before WP
        // stores sub_. Same key → Stripe returns one object. The first cycle
        // is a trial, so the subscription's first invoice charges nothing.
        $subscription = $this->create_subscription(
            $txn,
            $sub,
            $txn->product(),
            $customer_id,
            $payment_method->id,
            false,
            $trial_days,
            $min_payment,
            $max_payment,
            'mepr-cart-sub-' . (int) $sub->id,
            false
        );

        $sub->subscr_id = $subscription->id;

        if (isset($payment_method->card) && is_array($payment_method->card)) {
            $sub->cc_last4     = $payment_method->card['last4'];
            $sub->cc_exp_month = $payment_method->card['exp_month'];
            $sub->cc_exp_year  = $payment_method->card['exp_year'];
        }

        $sub->store();
    }

    /**
     * Set the customer's default payment method when they don't already have one.
     *
     * @param object $customer       The expanded Stripe customer.
     * @param object $payment_method The expanded Stripe payment method.
     */
    private function maybe_set_cart_customer_default_payment_method($customer, $payment_method)
    {
        if (!$payment_method || !isset($customer->invoice_settings) || !is_array($customer->invoice_settings)) {
            return;
        }

        $default_pm = isset($customer->invoice_settings['default_payment_method']) ? $customer->invoice_settings['default_payment_method'] : null;
        if (empty($default_pm)) {
            $this->set_customer_default_payment_method($customer->id, $payment_method->id);
        }
    }

    /**
     * Find a cart MeprOrder by its PaymentIntent ID stored in order meta.
     *
     * Queries the mepr_order_meta table for a row where
     * meta_key = '_mepr_cart_payment_intent_id' and meta_value = $pi_id,
     * then loads and returns the corresponding MeprOrder (or null).
     *
     * @param  string $pi_id The Stripe PaymentIntent ID.
     * @return MeprOrder|null The cart order, or null if not found.
     */
    protected function find_cart_order_by_payment_intent($pi_id)
    {
        if (empty($pi_id)) {
            return null;
        }

        global $wpdb;
        MeprDb::define_tables();

        // phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        $order_meta_table = $wpdb->prefix . 'mepr_order_meta';
        $row              = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT order_id FROM {$order_meta_table} WHERE meta_key = '_mepr_cart_payment_intent_id' AND meta_value = %s LIMIT 1",
                $pi_id
            )
        );
        // phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared

        if (empty($row) || empty($row->order_id)) {
            return null;
        }

        $order = new MeprOrder((int) $row->order_id);
        if (empty($order->id)) {
            return null;
        }

        return $order;
    }

    /**
     * Handle the setup_intent.succeeded webhook
     *
     * Processes a successful SetupIntent, creating subscriptions if necessary.
     *
     * @param stdClass $setup_intent The SetupIntent object.
     *
     * @return void
     */
    public function handle_setup_intent_succeeded_webhook($setup_intent)
    {
        if (empty($setup_intent->id) || empty($setup_intent->payment_method) || empty($setup_intent->customer)) {
            return;
        }

        // Cart order branch (mirror of the PaymentIntent webhook); legacy orders fall through below.
        // A lookup failure must never abort the legacy path, so swallow it and fall through.
        try {
            $cart_order = $this->find_cart_order_by_setup_intent($setup_intent->id);
        } catch (Exception $e) {
            MeprUtils::debug_log('Cart order SI lookup failed, falling back to legacy: ' . $e->getMessage());
            $cart_order = null;
        }
        if ($cart_order instanceof MeprOrder && $cart_order->order_type === MeprOrder::$cart_type_str) {
            $this->handle_cart_order_setup_intent_succeeded($cart_order, $setup_intent);
            return;
        }
        // --- End cart order branch ---
        $txn_res = MeprTransaction::get_one_by_trans_num($setup_intent->id);

        if (empty($txn_res) || !isset($txn_res->id)) {
            return;
        }

        $txn = new MeprTransaction($txn_res->id);

        if (empty($txn->id) || $txn->gateway !== $this->id) {
            return;
        }

        // This only handles free trials or 100% off coupons.
        if ($txn->is_payment_required()) {
            $sub = $txn->subscription();

            if (!($sub instanceof MeprSubscription) || $sub->status === MeprSubscription::$active_str || $sub->gateway !== $this->id) {
                return;
            }

            if (!($sub->trial && $sub->trial_days > 0 && (float) $sub->trial_amount <= 0.00)) {
                return;
            }
        }

        try {
            $setup_intent = (object) $this->send_stripe_request("setup_intents/$setup_intent->id", [
                'expand' => [
                    'payment_method',
                    'customer',
                ],
            ], 'get');

            $customer                = (object) $setup_intent->customer;
            $payment_method          = (object) $setup_intent->payment_method;
            $order                   = $txn->order();
            $order_bump_transactions = $order instanceof MeprOrder ? MeprTransaction::get_all_by_order_id($order->id, $txn->id) : [];

            if ($order instanceof MeprOrder && count($order_bump_transactions)) {
                if (!$order->is_complete() && !$order->is_processing()) {
                    $order->update_meta('processing', true);

                    foreach (array_merge([$txn], $order_bump_transactions) as $transaction) {
                        $trans_num = sprintf('mi_%d_%s', $order->id, uniqid());

                        if (!$transaction->is_payment_required()) {
                            MeprTransaction::create_free_transaction($transaction, false, $trans_num);
                            continue;
                        }

                        // We only need to handle free trials here, not one-time payments.
                        if (!$transaction->is_one_time_payment()) {
                            try {
                                $this->create_sub($transaction, $customer->id, $payment_method, $trans_num, $order->id);
                            } catch (Exception $e) {
                                continue;
                            }
                        }
                    }

                    $order->trans_num = $setup_intent->id;
                    $order->status    = MeprOrder::$complete_str;
                    $order->store();
                    $order->delete_meta('processing');
                }
            } else {
                $this->create_sub($txn, $customer->id, $payment_method, $setup_intent->id);
            }

            if ($payment_method && isset($customer->invoice_settings) && is_array($customer->invoice_settings)) {
                $default_payment_method = isset($customer->invoice_settings['default_payment_method']) ? $customer->invoice_settings['default_payment_method'] : null;

                if (empty($default_payment_method)) {
                    $this->set_customer_default_payment_method($customer->id, $payment_method->id);
                }
            }
        } catch (Exception $e) {
            http_response_code(500);
            wp_die(esc_html($e->getMessage()));
        }
    }

    /**
     * Look up a cart order by the SetupIntent ID stored in order meta (mirror of find_cart_order_by_payment_intent).
     *
     * @param  string $si_id The SetupIntent ID.
     * @return MeprOrder|null
     */
    protected function find_cart_order_by_setup_intent($si_id)
    {
        if (empty($si_id)) {
            return null;
        }

        global $wpdb;

        // phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        $order_meta_table = $wpdb->prefix . 'mepr_order_meta';
        $row              = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT order_id FROM {$order_meta_table} WHERE meta_key = '_mepr_cart_setup_intent_id' AND meta_value = %s LIMIT 1",
                $si_id
            )
        );
        // phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared

        if (empty($row) || empty($row->order_id)) {
            return null;
        }

        $order = new MeprOrder((int) $row->order_id);

        return empty($order->id) ? null : $order;
    }

    /**
     * Handle a succeeded SetupIntent for a cart order (mirror of the PaymentIntent version).
     *
     * @param  MeprOrder $cart_order   The cart order.
     * @param  object    $setup_intent The Stripe SetupIntent object.
     * @return void
     */
    private function handle_cart_order_setup_intent_succeeded(MeprOrder $cart_order, $setup_intent)
    {
        // Same race as PaymentIntent: 500 so Stripe retries after place_order releases the lock.
        if ($cart_order->is_processing()) {
            http_response_code(500);
            wp_die(esc_html__('Cart order is still processing.', 'memberpress'));
        }

        try {
            // Expand the SetupIntent for the customer + payment method needed to create Stripe subscriptions.
            $si_expanded = (object) $this->send_stripe_request("setup_intents/{$setup_intent->id}", [
                'expand' => ['payment_method', 'customer'],
            ], 'get');

            $customer       = (object) $si_expanded->customer;
            $payment_method = (object) $si_expanded->payment_method;

            if ($cart_order->is_complete()) {
                // The place_order() method beat us — only backfill any missing Stripe subscriptions.
                $this->create_missing_cart_subscriptions($cart_order, $customer, $payment_method);
            } else {
                $this->complete_cart_order_from_webhook($cart_order, $setup_intent->id, $customer, $payment_method);
            }

            $this->maybe_set_cart_customer_default_payment_method($customer, $payment_method);
        } catch (Exception $e) {
            // Log for diagnosis, then 500 so Stripe retries the event (cart guards keep retries safe).
            MeprUtils::debug_log('Cart order setup-intent webhook error for order ' . $cart_order->id . ': ' . $e->getMessage());
            http_response_code(500);
            wp_die(esc_html($e->getMessage()));
        }
    }

    /**
     * Used to record a declined payment.
     */
    public function record_payment_failure()
    {
        if (isset($_REQUEST['data'])) {
            // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized,WordPress.Security.ValidatedSanitizedInput.MissingUnslash
            $charge  = (object) $_REQUEST['data'];
            $txn_res = MeprTransaction::get_one_by_trans_num($charge->id);

            if (is_object($txn_res) and isset($txn_res->id)) {
                $txn         = new MeprTransaction($txn_res->id);
                $txn->status = MeprTransaction::$failed_str;
                $txn->store();
            } else {
                // Fetch expanded charge data from Stripe.
                $args = [
                    'expand' => [
                        'invoice',
                    ],
                ];

                $charge = (object) $this->send_stripe_request("charges/{$charge->id}", $args, 'get');

                $sub = isset($charge->invoice['subscription']) ? MeprSubscription::get_one_by_subscr_id($charge->invoice['subscription']) : null;

                if (!($sub instanceof MeprSubscription)) {
                    // Look for an old cus_xxx subscription.
                    $sub = isset($charge->customer) ? MeprSubscription::get_one_by_subscr_id($charge->customer) : null;
                }

                if ($sub instanceof MeprSubscription) {
                    if ($sub->gateway !== $this->id) {
                        return false;
                    }

                    $first_txn = $sub->first_txn();

                    if (!($first_txn instanceof MeprTransaction)) {
                        $coupon_id = $sub->coupon_id;
                    } else {
                        $coupon_id = $first_txn->coupon_id;
                    }

                    $txn                  = new MeprTransaction();
                    $txn->user_id         = $sub->user_id;
                    $txn->product_id      = $sub->product_id;
                    $txn->coupon_id       = $coupon_id;
                    $txn->txn_type        = MeprTransaction::$payment_str;
                    $txn->status          = MeprTransaction::$failed_str;
                    $txn->subscription_id = $sub->id;
                    $txn->trans_num       = $charge->id;
                    $txn->gateway         = $this->id;

                    // The charge is the authority: the store currency picks the wrong decimals when they differ.
                    $txn->currency = strtoupper($charge->currency ?? '') ?: MeprCurrencyService::get_primary_currency();

                    if (self::is_zero_decimal_currency($txn->currency)) {
                        $txn->set_gross((float)$charge->amount);
                    } else {
                        $txn->set_gross((float)$charge->amount / 100);
                    }

                    $txn->store();

                    // Reload the subscription in case it was modified while storing the transaction.
                    $sub = new MeprSubscription($sub->id);

                    // If first payment fails, Stripe will not set up the subscription, so we need to mark it as cancelled.
                    if ((int) $sub->txn_count === 0 && !($sub->trial && (float) $sub->trial_amount === 0.00)) {
                        $sub->status = MeprSubscription::$cancelled_str;
                    }

                    $sub->expire_txns(); // Expire associated transactions for the old subscription.
                    $sub->store();
                } else {
                    return false; // Nothing we can do here ... so we outta here.
                }
            }

            MeprUtils::send_failed_txn_notices($txn);

            return $txn;
        }

        return false;
    }

    /**
     * Used to record a successful payment by the given gateway. It should have
     * the ability to record a successful payment or a failure. It is this method
     * that should be used when receiving an IPN from PayPal or a Silent Post
     * from Authorize.net.
     */
    public function record_payment()
    {
        // Not used.
    }

    /**
     * This method should be used by the class to record a successful refund from
     * the gateway. This method should also be used by any IPN requests or Silent Posts.
     *
     * @param MeprTransaction $txn The transaction object.
     *
     * @return integer|void
     */
    public function process_refund(MeprTransaction $txn)
    {
        $args   = MeprHooks::apply_filters('mepr_stripe_refund_args', [], $txn);
        $refund = (object)$this->send_stripe_request("charges/{$txn->trans_num}/refund", $args);
        $this->email_status('Stripe Refund: ' . MeprUtils::object_to_string($refund), $this->settings->debug);
        $_REQUEST['data'] = $refund;
        return $this->record_refund();
    }

    /**
     * This method should be used by the class to record a successful refund from
     * the gateway. This method should also be used by any IPN requests or Silent Posts.
     *
     * @return integer|false The transaction ID or false if not found.
     * @throws MeprHttpException   If there was an HTTP error connecting to Stripe.
     * @throws MeprRemoteException If there was an invalid or error response from Stripe.
     */
    public function record_refund()
    {
        if (isset($_REQUEST['data'])) {
            // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized,WordPress.Security.ValidatedSanitizedInput.MissingUnslash
            $charge = (object)$_REQUEST['data'];
            $obj    = MeprTransaction::get_one_by_trans_num($charge->id);

            if (!is_null($obj) && (int)$obj->id > 0) {
                $txn = new MeprTransaction($obj->id);

                if ($txn->gateway !== $this->id) {
                    return false;
                }

                // Seriously ... if txn was already refunded what are we doing here?
                if ($txn->status === MeprTransaction::$refunded_str) {
                    return $txn->id;
                }

                // The refund data is not always included with the charge data depending
                // on the API version. Re-fetch with refunds expanded for the hook below.
                $charge = (object) $this->send_stripe_request("charges/$charge->id", ['expand' => ['refunds']], 'get');

                $txn->status      = MeprTransaction::$refunded_str;
                $txn->refunded_at = MeprUtils::db_now();
                $txn->store();

                MeprUtils::send_refunded_txn_notices(
                    $txn,
                    MeprHooks::apply_filters('mepr_stripe_transaction_refunded_event_args', '', $txn, $charge)
                );

                return $txn->id;
            }
        }

        return false;
    }

    /**
     * Process a trial payment
     *
     * @param  MeprTransaction $txn The transaction to process.
     * @throws MeprGatewayException When trial payment processing fails.
     * @return void
     */
    public function process_trial_payment($txn)
    {
        // Not used.
    }

    /**
     * Record a trial payment
     *
     * @param  MeprTransaction $txn The transaction to record.
     * @throws MeprGatewayException When recording the trial payment fails.
     * @return void
     */
    public function record_trial_payment($txn)
    {
        // Not used.
    }

    /**
     * Process a completed Stripe Checkout session
     *
     * @param  object $checkout_session The Stripe Checkout session object.
     * @throws MeprGatewayException When session processing fails.
     * @return void
     */
    public function process_stripe_checkout_session_completed($checkout_session)
    {
        if (empty($checkout_session->id) || empty($checkout_session->customer)) {
            return;
        }

        $txn_res = MeprTransaction::get_one_by_trans_num($checkout_session->id);

        if (empty($txn_res) || !isset($txn_res->id)) {
            return;
        }

        $txn = new MeprTransaction($txn_res->id);

        if (empty($txn->id) || $txn->gateway !== $this->id) {
            return;
        }

        try {
            $checkout_session = (object) $this->send_stripe_request("checkout/sessions/$checkout_session->id", [
                'expand' => [
                    'customer',
                    'line_items.data.taxes',
                    'payment_intent.payment_method',
                    'setup_intent.payment_method',
                    'subscription.default_payment_method',
                    'subscription.latest_invoice.charge',
                    'subscription.latest_invoice.payment_intent.payment_method',
                    'subscription.latest_invoice.total_tax_amounts.tax_rate',
                    'total_details.breakdown',
                ],
            ], 'get');

            $customer       = isset($checkout_session->customer) ? (object) $checkout_session->customer : null;
            $payment_method = null;
            $charge_id      = null;

            if ($checkout_session->mode === 'subscription') {
                if (isset($checkout_session->subscription['default_payment_method'])) {
                    $payment_method = (object) $checkout_session->subscription['default_payment_method'];
                }

                if (isset($checkout_session->subscription['latest_invoice']['payment_intent'])) {
                    $payment_intent = (object) $checkout_session->subscription['latest_invoice']['payment_intent'];

                    if ($payment_intent) {
                        if ($checkout_session->payment_status === 'unpaid' && $this->is_async_payment_method($payment_intent->payment_method['type'])) {
                            return; // Async payment method, wait for the checkout.session.async_payment_succeeded webhook.
                        }

                        $charge_id = $this->get_payment_intent_charge_id($payment_intent);
                    }
                }
            } elseif ($checkout_session->mode === 'payment') {
                if (isset($checkout_session->payment_intent['payment_method'])) {
                    $payment_method = (object) $checkout_session->payment_intent['payment_method'];
                }

                if (isset($checkout_session->payment_intent)) {
                    $payment_intent = (object) $checkout_session->payment_intent;

                    if ($payment_intent) {
                        if ($checkout_session->payment_status === 'unpaid' && $this->is_async_payment_method($payment_intent->payment_method['type'])) {
                            return; // Async payment method, wait for the checkout.session.async_payment_succeeded webhook.
                        }

                        $charge_id = $this->get_payment_intent_charge_id($payment_intent);
                    }
                }
            } elseif ($checkout_session->mode === 'setup') {
                if (isset($checkout_session->setup_intent['payment_method'])) {
                    $payment_method = (object) $checkout_session->setup_intent['payment_method'];
                }

                if (isset($checkout_session->setup_intent['id'])) {
                    $charge_id = $checkout_session->setup_intent['id'];
                }
            }

            $order                   = $txn->order();
            $order_bump_transactions = $order instanceof MeprOrder ? MeprTransaction::get_all_by_order_id($order->id, $txn->id) : [];

            if ($order instanceof MeprOrder && count($order_bump_transactions)) {
                if (!$order->is_complete() && !$order->is_processing()) {
                    $order->update_meta('processing', true);
                    $trans_num = sprintf('mi_%d_%s', $order->id, uniqid());

                    $line_breakdowns = $this->session_line_amount_breakdowns($checkout_session, array_merge([$txn], $order_bump_transactions));

                    // Correct every row's tax fields before completing any
                    // row, so a render or the return-time sync never
                    // observes a half-corrected order (a completed main
                    // beside a bump still holding its stamped figures).
                    foreach (array_merge([$txn], $order_bump_transactions) as $transaction) {
                        if (isset($line_breakdowns[$transaction->id]) && $this->verify_amount_breakdown($transaction, $line_breakdowns[$transaction->id])) {
                            $this->store_pending_tax_fields($transaction);
                        }
                    }

                    if (!$txn->is_payment_required()) {
                        MeprTransaction::create_free_transaction($txn, false, $trans_num);
                    } elseif ($txn->is_one_time_payment()) {
                        if (isset($line_breakdowns[$txn->id])) {
                            $this->verify_amount_breakdown($txn, $line_breakdowns[$txn->id]);
                        }

                        $this->record_one_time_payment($txn, $trans_num);
                    } else {
                        $sub = $txn->subscription();

                        if ($sub instanceof MeprSubscription) {
                            if (isset($checkout_session->subscription['id'])) {
                                $sub->subscr_id = $checkout_session->subscription['id'];
                            }

                            $this->record_cc_vars($sub, $payment_method);
                            $this->record_create_sub($sub);

                            if ($sub->trial && $sub->trial_days > 0) {
                                $amount                  = (float) $sub->trial_total;
                                $txn_expires_at_override = MeprUtils::ts_to_mysql_date(time() + MeprUtils::days($sub->trial_days), 'Y-m-d 23:59:59');
                            } else {
                                $amount                  = (float) $sub->total;
                                $txn_expires_at_override = null;
                            }

                            if ($amount > 0) {
                                $this->record_sub_payment($sub, $amount, sprintf('mi_%d_%s', $order->id, uniqid()), $this->get_card($payment_method), $txn_expires_at_override, $order->id, $line_breakdowns[$txn->id] ?? null);
                            }
                        }
                    }

                    foreach ($order_bump_transactions as $transaction) {
                        $trans_num = sprintf('mi_%d_%s', $order->id, uniqid());

                        if (!$transaction->is_payment_required()) {
                            MeprTransaction::create_free_transaction($transaction, false, $trans_num);
                            continue;
                        }

                        if ($transaction->is_one_time_payment()) {
                            if (isset($line_breakdowns[$transaction->id])) {
                                $this->verify_amount_breakdown($transaction, $line_breakdowns[$transaction->id]);
                            }

                            $this->record_one_time_payment($transaction, $trans_num);
                        } else {
                            if ($customer && $payment_method) {
                                try {
                                    $this->create_sub($transaction, $customer->id, $payment_method, $trans_num, $order->id, $line_breakdowns[$transaction->id] ?? null);
                                } catch (Exception $e) {
                                    MeprUtils::debug_log(sprintf('stripe-order-bump-create-sub-failed: txn %d: %s', $transaction->id, $e->getMessage()));
                                    continue;
                                }
                            }
                        }
                    }

                    if ($charge_id) {
                        $order->trans_num = $charge_id;
                    }

                    $order->status = MeprOrder::$complete_str;
                    $order->store();
                    $order->delete_meta('processing');
                }
            } else {
                if ($txn->is_one_time_payment()) {
                    $trans_num = $charge_id ?: $txn->trans_num;

                    $breakdown = $this->session_amount_breakdown($checkout_session);

                    if (is_array($breakdown)) {
                        $this->verify_amount_breakdown($txn, $breakdown);
                    }

                    $this->record_one_time_payment($txn, $trans_num);
                } else {
                    $sub = $txn->subscription();

                    if ($sub instanceof MeprSubscription) {
                        if (isset($checkout_session->subscription['id'])) {
                            $sub->subscr_id = $checkout_session->subscription['id'];
                        }

                        $this->record_cc_vars($sub, $payment_method);
                        $this->record_create_sub($sub);

                        if (isset($checkout_session->subscription['latest_invoice']['charge'])) {
                            $charge                  = (object) $checkout_session->subscription['latest_invoice']['charge'];
                            $amount                  = (float) $charge->amount;
                            $txn_expires_at_override = null;

                            if (!self::is_zero_decimal_currency(MeprOptions::fetch()->currency_code)) {
                                $amount = $amount / 100;
                            }

                            if ($sub->trial && $sub->trial_days > 0) {
                                $txn_expires_at_override = MeprUtils::ts_to_mysql_date(time() + MeprUtils::days($sub->trial_days), 'Y-m-d 23:59:59');
                            }

                            $this->record_sub_payment($sub, $amount, $charge->id, $this->get_card($payment_method), $txn_expires_at_override, 0, $this->invoice_amount_breakdown((object) $checkout_session->subscription['latest_invoice']));
                        }
                    }
                }
            }

            if ($payment_method && isset($customer->invoice_settings) && is_array($customer->invoice_settings)) {
                $default_payment_method = isset($customer->invoice_settings['default_payment_method']) ? $customer->invoice_settings['default_payment_method'] : null;

                if (empty($default_payment_method) && (!isset($payment_intent) || isset($payment_intent->setup_future_usage))) {
                    $this->set_customer_default_payment_method($customer->id, $payment_method->id);
                }
            }
        } catch (Exception $e) {
            http_response_code(500);
            wp_die(esc_html($e->getMessage()));
        }
    }

    /**
     * Process a failed async payment from Stripe Checkout
     *
     * @param  object $checkout_session The Stripe Checkout session object.
     * @throws MeprGatewayException When payment fails.
     * @return void
     */
    public function process_checkout_session_async_payment_failed($checkout_session)
    {
        if (empty($checkout_session->id) || empty($checkout_session->customer)) {
            return;
        }

        $txn_res = MeprTransaction::get_one_by_trans_num($checkout_session->id);

        if (empty($txn_res) || !isset($txn_res->id)) {
            return;
        }

        $txn = new MeprTransaction($txn_res->id);

        if (empty($txn->id) || $txn->gateway !== $this->id) {
            return;
        }

        try {
            // Only one-time payments need to be handled here, failed payments for subscriptions will be recorded on the
            // charge.failed event.
            if ($checkout_session->mode === 'payment') {
                $checkout_session = (object) $this->send_stripe_request("checkout/sessions/$checkout_session->id", [
                    'expand' => [
                        'payment_intent',
                    ],
                ], 'get');

                $charge_id = $this->get_payment_intent_charge_id((object) $checkout_session->payment_intent);

                if ($charge_id) {
                      $txn->trans_num = $charge_id;
                      $txn->store();

                      $_REQUEST['data'] = (object) ['id' => $charge_id];

                      $this->record_payment_failure();
                }
            }
        } catch (Exception $e) {
            http_response_code(500);
            wp_die(esc_html($e->getMessage()));
        }
    }

    /**
     * Used to send subscription data to a given payment gateway. In gateways
     * which redirect before this step is necessary this method should just be
     * left blank.
     *
     * @param MeprTransaction $txn The transaction object.
     *
     * @return void
     */
    public function process_create_subscription($txn)
    {
        // Not used.
    }

    /**
     * Used to record a successful subscription by the given gateway. It should have
     * the ability to record a successful subscription or a failure. It is this method
     * that should be used when receiving an IPN from PayPal or a Silent Post
     * from Authorize.net.
     */
    public function record_create_subscription()
    {
        // Not used.
    }

    /**
     * Create a new Stripe subscription and records the first payment as complete.
     *
     * @param  MeprTransaction $txn              The MemberPress transaction.
     * @param  string          $customer_id      The Stripe Customer ID.
     * @param  stdClass        $payment_method   The Stripe PaymentMethod data.
     * @param  string          $trans_num        The transaction number for the payment.
     * @param  integer         $order_id         The order ID for the payment transaction.
     * @param  array|null      $amount_breakdown Optional pre-resolved amount/tax fields for the
     *                                           recorded payment, from the charging invoice's own
     *                                           records.
     * @throws MeprHttpException               If there was an HTTP error connecting to Stripe.
     * @throws MeprRemoteException             If there was an invalid or error response from Stripe.
     */
    public function create_sub(MeprTransaction $txn, $customer_id, $payment_method, $trans_num, $order_id = 0, ?array $amount_breakdown = null)
    {
        $sub = $txn->subscription();

        if (!($sub instanceof MeprSubscription)) {
            return;
        }

        if ($sub->status === MeprSubscription::$active_str) {
            return;
        }

        if ($sub->trial && $sub->trial_days > 0) {
            $amount                  = (float) $sub->trial_total;
            $trial_days              = $sub->trial_days;
            $txn_expires_at_override = MeprUtils::ts_to_mysql_date(time() + MeprUtils::days($sub->trial_days), 'Y-m-d 23:59:59');
        } else {
            $amount                  = (float) $sub->total;
            $txn_expires_at_override = null;

            // If the sub doesn't have a trial, we want to create a subscription with the trial days set to cover one period
            // since the initial period was already paid for.
            $trial_days = MeprUtils::days_in_period((int) $sub->period, (string) $sub->period_type, Time::now());
        }

        // The first cycle is a trial, so the subscription's first invoice charges nothing.
        list($min_payment, $max_payment) = $this->payment_amount_range((float) $txn->total, (float) $sub->total);
        $subscription                    = $this->create_subscription(
            $txn,
            $sub,
            $txn->product(),
            $customer_id,
            $payment_method->id,
            false,
            $trial_days,
            $min_payment,
            $max_payment,
            false,
            false
        );

        $sub->subscr_id = $subscription->id;

        if (isset($payment_method->card) && is_array($payment_method->card)) {
            $sub->cc_last4     = $payment_method->card['last4'];
            $sub->cc_exp_month = $payment_method->card['exp_month'];
            $sub->cc_exp_year  = $payment_method->card['exp_year'];
        }

        $sub->store();

        $this->record_create_sub($sub);

        if ($amount > 0) {
            $this->record_sub_payment($sub, $amount, $trans_num, $this->get_card($payment_method), $txn_expires_at_override, $order_id, $amount_breakdown);
        }
    }

    /**
     * Record the creation of a new subscription
     *
     * @param MeprSubscription $sub The subscription object.
     *
     * @return void
     */
    public function record_create_sub(MeprSubscription $sub)
    {
        $txn = $sub->first_txn();

        if (!($txn instanceof MeprTransaction)) {
            $txn                  = new MeprTransaction();
            $txn->user_id         = $sub->user_id;
            $txn->product_id      = $sub->product_id;
            $txn->gateway         = $this->id;
            $txn->subscription_id = $sub->id;
            $txn->order_id        = $sub->order_id;
        }

        $this->activate_subscription($txn, $sub, true, $sub->txn_count < 1);

        // This will only work before maybe_cancel_old_sub is run.
        $upgrade   = $sub->is_upgrade();
        $downgrade = $sub->is_downgrade();

        $event_txn = $sub->maybe_cancel_old_sub();

        if ($upgrade) {
            $this->upgraded_sub($sub, $event_txn);
        } elseif ($downgrade) {
            $this->downgraded_sub($sub, $event_txn);
        } else {
            $this->new_sub($sub, true);
        }

        MeprUtils::send_signup_notices($txn);

        MeprHooks::do_action('mepr_stripe_subscription_created', $txn, $sub);
    }

    /**
     * Process subscription updates
     *
     * @param  string $sub_id The subscription ID to update.
     * @throws MeprGatewayException When subscription update fails.
     * @return void
     */
    public function process_update_subscription($sub_id)
    {
        // This is handled via Ajax.
    }

    /**
     * Create a SetupIntent
     *
     * @param  string          $customer_id The Stripe Customer ID.
     * @param  MeprTransaction $txn         The MemberPress transaction.
     * @param  MeprProduct     $prd         The MemberPress product.
     * @param  float|null      $min_payment The smallest payment the order requires.
     * @param  float|null      $max_payment The largest payment the order requires.
     * @param  string|null     $currency    Charge currency (null = primary).
     * @return stdClass                         The Stripe SetupIntent object
     * @throws MeprHttpException                If there was an HTTP error connecting to Stripe.
     * @throws MeprRemoteException              If there was an invalid or error response from Stripe.
     */
    public function create_setup_intent($customer_id, MeprTransaction $txn, MeprProduct $prd, ?float $min_payment = null, ?float $max_payment = null, ?string $currency = null)
    {
        $args = MeprHooks::apply_filters('mepr_stripe_setup_intent_args', [
            'customer'             => $customer_id,
            'payment_method_types' => $this->get_setup_intent_payment_method_types($min_payment, $max_payment, $currency),
            'description'          => $prd->post_title,
            'metadata'             => [
                'platform'              => 'MemberPress Connect acct_1FIIDhKEEWtO8ZWC',
                'transaction_id'        => $txn->id,
                'site_url'              => get_site_url(),
                'ip_address'            => MeprAntiCardTestingCtrl::get_ip(),
                'memberpress_product'    => $prd->post_title,
                'memberpress_product_id' => $prd->ID,
            ],
        ], $txn);

        $setup_intent = (object) $this->send_stripe_request('setup_intents', $args);

        return $setup_intent;
    }

    /**
     * Create a SetupIntent for updating a subscription's payment method
     *
     * @param  string      $customer_id The Stripe Customer ID.
     * @param  float|null  $min_payment The smallest payment the subscription requires.
     * @param  float|null  $max_payment The largest payment the subscription requires.
     * @param  string|null $currency    The subscription's billing currency (null = primary).
     * @return stdClass                         The Stripe SetupIntent object
     * @throws MeprHttpException                If there was an HTTP error connecting to Stripe.
     * @throws MeprRemoteException              If there was an invalid or error response from Stripe.
     */
    public function create_update_setup_intent($customer_id, ?float $min_payment = null, ?float $max_payment = null, ?string $currency = null)
    {
        $args = MeprHooks::apply_filters('mepr_stripe_update_setup_intent_args', [
            'customer'             => $customer_id,
            'payment_method_types' => $this->get_update_setup_intent_payment_method_types($min_payment, $max_payment, $currency),
            'metadata'             => [
                'platform'   => 'MemberPress Connect acct_1FIIDhKEEWtO8ZWC',
                'site_url'   => get_site_url(),
                'ip_address' => MeprAntiCardTestingCtrl::get_ip(),
            ],
        ]);

        $setup_intent = (object) $this->send_stripe_request('setup_intents', $args);

        return $setup_intent;
    }

    /**
     * Update a payment method for a subscription
     *
     * @param  MeprSubscription $sub            The MemberPress subscription.
     * @param  MeprUser         $usr            The MemberPress user.
     * @param  stdClass         $payment_method The Stripe PaymentMethod data, must be attached to the customer.
     * @return stdClass                               The Stripe Subscription data
     * @throws MeprHttpException                      If there was an HTTP error connecting to Stripe.
     * @throws MeprRemoteException                    If there was an invalid or error response from Stripe.
     */
    public function update_subscription_payment_method(MeprSubscription $sub, MeprUser $usr, $payment_method)
    {
        // Attach the payment method to the customer and set this as the default payment method for the subscription.
        if (strpos($sub->subscr_id, 'sub_') === 0) {
            $subscription = $this->retrieve_subscription($sub->subscr_id);
            $customer_id  = $usr->get_stripe_customer_id($this->get_meta_gateway_id());

            if (!is_string($customer_id) || strpos($customer_id, 'cus_') !== 0) {
                // If the Stripe customer ID isn't saved locally for this user, let's save it. This can happen if sub_
                // subscriptions are imported and the cus_ IDs aren't imported for users.
                $usr->set_stripe_customer_id($this->get_meta_gateway_id(), $subscription->customer);
            }
        } else {
            $subscription = $this->get_customer_subscription($sub->subscr_id);
        }

        $args = ['default_payment_method' => $payment_method->id];

        if (!empty($payment_method->type)) {
            // Ensure that this payment method type is allowed on the subscription.
            $payment_method_types = $subscription->payment_settings['payment_method_types'];

            if (is_array($payment_method_types) && !in_array($payment_method->type, $payment_method_types, true)) {
                $args = array_merge($args, [
                    'payment_settings' => [
                        'payment_method_types' => array_merge($payment_method_types, [$payment_method->type]),
                    ],
                ]);
            }
        }

        $this->send_stripe_request("subscriptions/{$subscription->id}", $args);

        if (MeprHooks::apply_filters('mepr_stripe_update_set_as_default', true)) {
            $this->send_stripe_request("customers/{$subscription->customer}", [
                'invoice_settings' => [
                    'default_payment_method' => $payment_method->id,
                ],
            ]);
        }

        // Save the card details.
        if (isset($payment_method->card) && is_array($payment_method->card)) {
            $sub->cc_last4     = $payment_method->card['last4'];
            $sub->cc_exp_month = $payment_method->card['exp_month'];
            $sub->cc_exp_year  = $payment_method->card['exp_year'];
        } else {
            $sub->cc_last4     = '';
            $sub->cc_exp_month = '';
            $sub->cc_exp_year  = '';
        }

        $sub->store();

        return $subscription;
    }

    /**
     * Get the Stripe subscription for the given customer ID
     *
     * @param  string $customer_id The Stripe customer ID.
     * @return object                           The Stripe subscription object
     * @throws MeprHttpException                If there was an HTTP error connecting to Stripe.
     * @throws MeprRemoteException              If there was an invalid or error response from Stripe.
     */
    public function get_customer_subscription($customer_id)
    {
        $args = [
            'expand' => [
                'latest_invoice',
                'default_payment_method',
            ],
        ];

        $subscription = (object) $this->send_stripe_request("customers/{$customer_id}/subscription", $args, 'get');

        return $subscription;
    }

    /**
     * Retry the payment for the given invoice ID
     *
     * @param  string $invoice_id The Stripe invoice ID.
     * @throws MeprHttpException               If there was an HTTP error connecting to Stripe.
     * @throws MeprRemoteException             If there was an invalid or error response from Stripe.
     */
    public function retry_invoice_payment($invoice_id)
    {
        $this->send_stripe_request("invoices/{$invoice_id}/pay", [], 'post');
    }

    /**
     * This method should be used by the class to record a successful cancellation
     * from the gateway. This method should also be used by any IPN requests or
     * Silent Posts.
     */
    public function record_update_subscription()
    {
        // No need for this one with stripe.
    }

    /**
     * Run a change to a subscription while holding its lock, so overlapping
     * requests cannot change the same subscription at the same time.
     *
     * @param  integer|string $sub_id   The subscription ID.
     * @param  callable       $callback The change to run, called with the subscription ID as an integer.
     * @param  integer        $wait     The number of seconds to wait for another request's change to finish.
     * @return mixed The callback's return value.
     * @throws MeprGatewayException When another request is changing the subscription.
     */
    private function with_subscription_lock($sub_id, callable $callback, int $wait = 0)
    {
        $sub_id = (int) $sub_id;
        $lock   = "subscription_$sub_id";

        // A change made while this request already holds the lock runs straight
        // through, e.g. a resume payment that reaches the cycle limit and cancels.
        if (MeprLock::holds($lock)) {
            return $callback($sub_id);
        }

        $token = MeprLock::acquire($lock, self::SUBSCRIPTION_LOCK_TTL, $wait);

        if ($token === null) {
            throw new MeprGatewayException(
                // phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped
                __('This subscription is already being updated. Please check back in a moment.', 'memberpress')
            );
        }

        try {
            return $callback($sub_id);
        } finally {
            MeprLock::release($lock, $token);
        }
    }

    /**
     * Used to suspend a subscription by the given gateway.
     *
     * @param integer|string $sub_id The subscription ID.
     *
     * @return MeprSubscription|false
     * @throws MeprGatewayException When the subscription has already been paused, is in a free trial, or is being changed by another request.
     * @throws MeprHttpException If there was an HTTP error connecting to Stripe.
     * @throws MeprRemoteException If there was an invalid or error response from Stripe.
     */
    public function process_suspend_subscription($sub_id)
    {
        return $this->with_subscription_lock($sub_id, fn(int $id) => $this->suspend_subscription($id));
    }

    /**
     * Suspend the subscription at Stripe and record the suspension, while
     * holding the subscription's lock.
     *
     * @param integer $sub_id The subscription ID.
     *
     * @return MeprSubscription|false
     * @throws MeprGatewayException When the subscription has already been paused or is in a free trial.
     * @throws MeprHttpException If there was an HTTP error connecting to Stripe.
     * @throws MeprRemoteException If there was an invalid or error response from Stripe.
     *
     * phpcs:ignore Squiz.Commenting.FunctionCommentThrowTag.WrongNumber -- send_stripe_request() propagates the HTTP and remote exceptions.
     */
    private function suspend_subscription(int $sub_id)
    {
        $sub = new MeprSubscription($sub_id);

        if ($sub->status === MeprSubscription::$suspended_str) {
            throw new MeprGatewayException(esc_html__('This subscription has already been paused.', 'memberpress'));
        }

        if (!MeprUtils::is_mepr_admin() && $sub->in_free_trial()) {
            throw new MeprGatewayException(esc_html__('Sorry, subscriptions cannot be paused during a free trial.', 'memberpress'));
        }

        $args = MeprHooks::apply_filters('mepr_stripe_suspend_subscription_args', [], $sub);

        if (strpos($sub->subscr_id, 'sub_') === 0) {
            $res = $this->send_stripe_request("subscriptions/{$sub->subscr_id}", $args, 'delete');
        } else {
            try {
                $customer = $this->retrieve_customer($sub->subscr_id);
            } catch (Exception $e) {
                // If there's not already a customer then we're done here.
                return false;
            }

            // Yeah ... we're cancelling here bro ... with stripe we should be able to restart again.
            $res = $this->send_stripe_request("customers/{$customer->id}/subscription", $args, 'delete');
        }

        $_REQUEST['data'] = $res;

        return $this->record_suspend_subscription();
    }

    /**
     * This method should be used by the class to record a successful suspension
     * from the gateway.
     *
     * @return MeprSubscription|false The subscription object or false if the subscription was not found
     */
    public function record_suspend_subscription()
    {
        if (isset($_REQUEST['data'])) {
            // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized,WordPress.Security.ValidatedSanitizedInput.MissingUnslash
            $subscription = (object) $_REQUEST['data'];

            $sub = MeprSubscription::get_one_by_subscr_id($subscription->id);

            if (!($sub instanceof MeprSubscription)) {
                // Look for an old cus_xxx subscription.
                $sub = MeprSubscription::get_one_by_subscr_id($subscription->customer);
            }

            if ($sub instanceof MeprSubscription) {
                // Seriously ... if sub was already cancelled what are we doing here?
                if ($sub->status === MeprSubscription::$suspended_str) {
                    return $sub;
                }

                $sub->status = MeprSubscription::$suspended_str;
                $sub->store();

                MeprUtils::send_suspended_sub_notices($sub);

                return $sub;
            }
        }

        return false;
    }

    /**
     * Used to resume a subscription by the given gateway.
     *
     * @param integer|string $sub_id The subscription ID.
     *
     * @return void
     * @throws MeprGatewayException When the subscription has already been resumed, currency is different, or it is being changed by another request.
     * @throws MeprGatewayRequiresActionException When manual payment action is required.
     * @throws MeprHttpException If there was an HTTP error connecting to Stripe.
     * @throws MeprRemoteException If there was an invalid or error response from Stripe.
     */
    public function process_resume_subscription($sub_id)
    {
        $this->with_subscription_lock($sub_id, fn(int $id) => $this->resume_subscription($id));
    }

    /**
     * Create the Stripe subscription that resumes a paused subscription, while
     * holding the subscription's lock.
     *
     * The subscription is loaded after the lock is taken, so the status guard
     * sees the result of any change that held the lock before.
     *
     * @param integer $sub_id The subscription ID.
     *
     * @return void
     * @throws MeprGatewayException When the subscription has already been resumed or currency is different.
     * @throws MeprGatewayRequiresActionException When manual payment action is required.
     * @throws MeprHttpException If there was an HTTP error connecting to Stripe.
     * @throws MeprRemoteException If there was an invalid or error response from Stripe.
     *
     * phpcs:ignore Squiz.Commenting.FunctionCommentThrowTag.WrongNumber -- send_stripe_request() propagates the HTTP and remote exceptions.
     */
    private function resume_subscription(int $sub_id): void
    {
        $mepr_options = MeprOptions::fetch();
        MeprHooks::do_action('mepr_pre_stripe_resume_subscription', $sub_id); // Allow users to change the subscription programatically before resuming it.
        $sub = new MeprSubscription($sub_id);

        if ($sub->status === MeprSubscription::$active_str) {
            throw new MeprGatewayException(esc_html__('This subscription has already been resumed.', 'memberpress'));
        }

        $orig_trial        = $sub->trial;
        $orig_trial_days   = $sub->trial_days;
        $orig_trial_amount = $sub->trial_amount;
        $tax_inclusive     = $mepr_options->attr('tax_calc_type') === 'inclusive';

        if ($sub->is_expired() and !$sub->is_lifetime()) {
            $expiring_txn = $sub->expiring_txn();

            // If it's already expired with a real transaction
            // then we want to resume immediately.
            if (
                $expiring_txn instanceof MeprTransaction &&
                $expiring_txn->status !== MeprTransaction::$confirmed_str
            ) {
                $sub->trial                     = false;
                $sub->trial_days                = 0;
                $sub->trial_amount              = 0.00;
                $sub->trial_tax_amount          = 0.00;
                $sub->trial_total               = 0.00;
                $sub->trial_tax_reversal_amount = 0.00;
                $sub->store();
            }
        } else {
            $sub->trial                     = true;
            $sub->trial_days                = MeprUtils::tsdays(strtotime($sub->expires_at) - Time::now());
            $sub->trial_amount              = 0.00;
            $sub->trial_tax_amount          = 0.00;
            $sub->trial_total               = 0.00;
            $sub->trial_tax_reversal_amount = 0.00;
            $sub->store();
        }

        $usr = $sub->user();
        $prd = $sub->product();

        $customer_id       = $usr->get_stripe_customer_id($this->get_meta_gateway_id());
        $customer_id_valid = is_string($customer_id) && strpos($customer_id, 'cus_') === 0;
        $save_customer_id  = false;

        if (!$customer_id_valid) {
            // The user does not have a saved customer ID.
            if (strpos($sub->subscr_id, 'cus_') === 0) {
                // For cus_ subscriptions, save the subscription ID as their customer ID.
                $customer_id       = $sub->subscr_id;
                $customer_id_valid = true;
                $save_customer_id  = true;
            } else {
                // For sub_ subscriptions, look up the old subscription to find the customer ID.
                $old_subscription = $this->retrieve_subscription($sub->subscr_id);

                if (!empty($old_subscription->customer) && is_string($old_subscription->customer)) {
                    $customer_id       = $old_subscription->customer;
                    $customer_id_valid = true;
                    $save_customer_id  = true;
                }
            }
        }

        if ($customer_id_valid) {
            $customer = $this->retrieve_customer($customer_id);

            // Compare against the subscription's own currency, not the site primary,
            // or a non-primary-currency subscription could never resume.
            $sub_first_txn     = $sub->first_txn();
            $sub_currency      = ($sub_first_txn instanceof MeprTransaction && !empty($sub_first_txn->currency))
                ? strtolower($sub_first_txn->currency)
                : strtolower($mepr_options->currency_code);

            if ($customer->currency && strtolower($customer->currency) !== $sub_currency) {
                throw new MeprGatewayException(esc_html__('The subscription is locked to a different currency. Please contact us to resume your subscription.', 'memberpress'));
            }
        } else {
            throw new MeprGatewayException(esc_html__('Customer not found', 'memberpress'));
        }

        // This needs to be after the currency check above.
        if ($save_customer_id) {
            $usr->set_stripe_customer_id($this->get_meta_gateway_id(), $customer_id);
        }

        $payment_method_id = !empty($customer->invoice_settings['default_payment_method']['id']) ? $customer->invoice_settings['default_payment_method']['id'] : null;

        if (empty($payment_method_id)) {
            $payment_method_id = $this->set_customer_default_payment_method($customer->id);
        }

        $price_id    = $this->get_stripe_price_id($tax_inclusive ? (float) $sub->total : (float) $sub->price, $prd, $sub);
        $tax_rate_id = null;

        if (!self::use_automatic_tax() && $sub->tax_rate > 0 && $sub->tax_amount > 0) {
            $tax_rate_id = $this->get_stripe_tax_rate_id($sub->tax_desc, $sub->tax_rate, $prd, $tax_inclusive);
        }

        $item = ['price' => $price_id];

        if ($tax_rate_id) {
            $item['tax_rates'] = [$tax_rate_id];
        }

        $args = MeprHooks::apply_filters('mepr_stripe_resume_subscription_args', [
            'customer'    => $customer->id,
            'items'       => [$item],
            'expand'      => [
                'latest_invoice',
                'latest_invoice.charge',
                'latest_invoice.payment_intent',
                'latest_invoice.payment_intent.payment_method',
                'latest_invoice.total_tax_amounts.tax_rate',
            ],
            'metadata'    => [
                'platform'                              => 'MemberPress Connect acct_1FIIDhKEEWtO8ZWC',
                'site_url'                              => get_site_url(),
                'ip_address'                            => MeprAntiCardTestingCtrl::get_ip(),
                self::RESUMED_SUBSCRIPTION_METADATA_KEY => (string) $sub->id,
            ],
            'off_session' => 'true',
        ], $sub);

        // Specifically set a default_payment_method on the subscription.
        if (!empty($payment_method_id)) {
            $args = array_merge(['default_payment_method' => $payment_method_id], $args);
        }

        $event_args = '';

        if ($sub->trial && $sub->trial_days > 0) {
            $args       = array_merge(['trial_period_days' => $sub->trial_days], $args);
            $event_args = ['days_until_renewal' => $sub->trial_days];
        } else {
            // Site D — resume path. application_fee_percent drives the cycle-1 fee on the
            // invoice generated immediately when the subscription is created. A "trial" at
            // resume is remaining paid time during which Stripe generates no invoice, so
            // there is no fee opportunity to stamp; cycle-2+ is set fresh by the webhook.
            $fee         = $this->fee_service()->fetch_fee($this->id);
            $fee_percent = $fee['percent'];
            if ($fee_percent > 0) {
                $args['application_fee_percent'] = $fee_percent;
                $args                            = self::merge_fee_metadata($args, $fee['metadata']);
            }
        }

        if (self::use_automatic_tax()) {
            $args['automatic_tax'] = ['enabled' => 'true'];
        }

        $subscription = (object) $this->send_stripe_request(
            'subscriptions',
            $args,
            'post',
            'https://api.stripe.com/v1/',
            true,
            $this->resume_idempotency_key($sub, $args)
        );

        $sub->subscr_id    = $subscription->id;
        $sub->trial        = $orig_trial;
        $sub->trial_days   = $orig_trial_days;
        $sub->trial_amount = $orig_trial_amount;
        $sub->store();

        $this->email_status("process_resume_subscription: \n" . MeprUtils::object_to_string($sub) . "\n", $this->settings->debug);

        $invoice = (object) $subscription->latest_invoice;

        if ($invoice->status === 'open') {
            throw new MeprGatewayRequiresActionException(
                sprintf(
                    // Translators: %1$s: open link tag, %2$s: close link tag.
                    esc_html__('The subscription could not be resumed automatically, %1$sclick here%2$s to complete the payment.', 'memberpress'),
                    sprintf('<a href="%s" target="_blank">', esc_url($invoice->hosted_invoice_url)),
                    '</a>'
                )
            );
        }

        $sub->status = MeprSubscription::$active_str;
        $sub->store();

        if (isset($invoice->charge)) {
            $amount = (float) $invoice->charge['amount'];

            if (!self::is_zero_decimal_currency(MeprOptions::fetch()->currency_code)) {
                $amount = $amount / 100;
            }

            $payment_method = isset($invoice->payment_intent['payment_method']) ? (object) $invoice->payment_intent['payment_method'] : null;

            $this->record_sub_payment($sub, $amount, $invoice->charge['id'], $this->get_card($payment_method), null, 0, $this->invoice_amount_breakdown($invoice));
        }

        MeprUtils::send_resumed_sub_notices($sub, $event_args);
    }

    /**
     * The idempotency key for the Stripe subscription a resume creates.
     *
     * The key covers the subscription, the paused Stripe subscription it
     * replaces, the current UTC hour, and the request payload. Repeating the
     * same resume within the hour sends the same key, so Stripe returns the
     * subscription it already created instead of creating a second one. A
     * resume after a later pause replaces a different Stripe subscription, so
     * it sends a new key. The hour bounds how long Stripe replays a stored
     * error for an unchanged resume.
     *
     * @param  MeprSubscription $sub  The subscription being resumed.
     * @param  array            $args The subscription create payload.
     * @return string
     */
    private function resume_idempotency_key(MeprSubscription $sub, array $args): string
    {
        return "mepr-resume-$sub->id-" . hash(
            'sha256',
            $sub->subscr_id . '|' . gmdate('YmdH', Time::now()) . '|' . wp_json_encode($args)
        );
    }

    /**
     * Set a default payment method on a customer
     *
     * If the $payment_method_id param is null, the first card attached to the customer will be set as the default.
     *
     * @param  string      $customer_id       The Stripe Customer ID.
     * @param  string|null $payment_method_id The Stripe PaymentMethod ID to set as the default.
     * @return string|null                     The Stripe PaymentMethod ID that was set as the default
     */
    public function set_customer_default_payment_method($customer_id, $payment_method_id = null)
    {
        try {
            if (empty($payment_method_id)) {
                $payment_methods = (object) $this->send_stripe_request("customers/$customer_id/payment_methods", [
                    'type'  => 'card',
                    'limit' => '1',
                ], 'get');

                if (isset($payment_methods->data[0]['id'])) {
                      $payment_method_id = $payment_methods->data[0]['id'];
                } else {
                    return null;
                }
            }

            $this->send_stripe_request("customers/$customer_id", [
                'invoice_settings' => [
                    'default_payment_method' => $payment_method_id,
                ],
            ]);

            return $payment_method_id;
        } catch (Exception $e) {
            // Ignore, not critical enough to cause an error.
        }

        return null;
    }

    /**
     * This method should be used by the class to record a successful resuming of
     * as subscription from the gateway.
     */
    public function record_resume_subscription()
    {
        // Not used.
    }

    /**
     * Used to cancel a subscription by the given gateway. This method should be used
     * by the class to record a successful cancellation from the gateway. This method
     * should also be used by any IPN requests or Silent Posts.
     *
     * @param integer|string $sub_id The subscription ID.
     *
     * @return boolean|MeprSubscription The subscription object or false if the subscription was not found
     * @throws MeprGatewayException When the subscription has already been cancelled or is being changed by another request.
     * @throws MeprHttpException If there was an HTTP error connecting to Stripe.
     * @throws MeprRemoteException If there was an invalid or error response from Stripe.
     */
    public function process_cancel_subscription($sub_id)
    {
        return $this->with_subscription_lock(
            $sub_id,
            fn(int $id) => $this->cancel_subscription($id),
            self::SUBSCRIPTION_LOCK_WAIT
        );
    }

    /**
     * Cancel the subscription at Stripe and record the cancellation, while
     * holding the subscription's lock.
     *
     * @param integer $sub_id The subscription ID.
     *
     * @return boolean|MeprSubscription The subscription object or false if the subscription was not found
     * @throws MeprGatewayException When the subscription has already been cancelled.
     * @throws MeprHttpException If there was an HTTP error connecting to Stripe.
     * @throws MeprRemoteException If there was an invalid or error response from Stripe.
     *
     * phpcs:ignore Squiz.Commenting.FunctionCommentThrowTag.WrongNumber -- send_stripe_request() propagates the HTTP and remote exceptions.
     */
    private function cancel_subscription(int $sub_id)
    {
        $sub = new MeprSubscription($sub_id);

        if ($sub->status === MeprSubscription::$cancelled_str || $sub->status === MeprSubscription::$suspended_str) {
            throw new MeprGatewayException(esc_html__('This subscription has already been cancelled.', 'memberpress'));
        }

        if (strpos($sub->subscr_id, 'sub_') === 0) {
            $endpoint = "subscriptions/{$sub->subscr_id}";
        } else {
            try {
                $customer = $this->retrieve_customer($sub->subscr_id);
            } catch (MeprRemoteException $e) {
                // Use __() not esc_html__() — exception messages are escaped at display.
                // esc_html__ here double-encodes apostrophes (gateway&#039;s) in admin modals.
                throw new MeprGatewayException(__('The Subscription could not be cancelled here. Please login to your gateway\'s virtual terminal to cancel it.', 'memberpress')); // phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped
            } catch (Exception $e) {
                // If there's not already a customer then we're done here.
                return false;
            }

            $endpoint = "customers/{$customer->id}/subscription";
        }

        $args = MeprHooks::apply_filters('mepr_stripe_cancel_subscription_args', [], $sub);

        $subscription = $this->send_stripe_request($endpoint, $args, 'delete');

        $_REQUEST['data'] = $subscription;

        return $this->record_cancel_subscription();
    }

    /**
     * This method should be used by the class to record a successful cancellation
     * from the gateway. This method should also be used by any IPN requests or
     * Silent Posts.
     */
    public function record_cancel_subscription()
    {
        if (isset($_REQUEST['data'])) {
            // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized,WordPress.Security.ValidatedSanitizedInput.MissingUnslash
            $subscription = (object) $_REQUEST['data'];
            $sub          = MeprSubscription::get_one_by_subscr_id($subscription->id);

            if (!($sub instanceof MeprSubscription)) {
                // Look for an old cus_xxx subscription.
                $sub = MeprSubscription::get_one_by_subscr_id($subscription->customer);
            }

            if ($sub instanceof MeprSubscription) {
                // Seriously ... if sub was already cancelled what are we doing here?
                // Also, for stripe, since a suspension is only slightly different
                // than a cancellation, we kick it into high gear and check for that too.
                if ($sub->status === MeprSubscription::$cancelled_str || $sub->status === MeprSubscription::$suspended_str) {
                    return $sub;
                }

                $sub->status = MeprSubscription::$cancelled_str;
                $sub->store();

                if (isset($_REQUEST['expire'])) {
                    $sub->limit_reached_actions();
                }

                if (!isset($_REQUEST['silent']) || (bool) $_REQUEST['silent'] === false) {
                    MeprUtils::send_cancelled_sub_notices($sub);
                }
            }
        }

        return false;
    }

    /**
     * This gets called on the 'init' hook when the signup form is processed ...
     * this is in place so that payment solutions like paypal can redirect
     * before any content is rendered.
     *
     * @param MeprTransaction $txn The transaction object.
     *
     * @return void
     */
    public function process_signup_form($txn)
    {
        // Not used.
    }

    /**
     * Display the payment page
     *
     * @param  MeprTransaction $txn The transaction object.
     * @return string|void The payment page HTML
     */
    public function display_payment_page($txn)
    {
        if ($this->settings->stripe_checkout_enabled === 'on') {
            $order_bump_product_ids = isset($_GET['obs']) && is_array($_GET['obs']) ? array_map('intval', $_GET['obs']) : [];
            $this->checkout_redirect($txn, $order_bump_product_ids);
        }
    }

    /**
     * This gets called on wp_enqueue_script and enqueues a set of
     * scripts for use on the page containing the payment form
     */
    public function enqueue_payment_form_scripts()
    {
        if (wp_script_is('mepr-stripe-form', 'enqueued')) {
            return;
        }

        $mepr_options = MeprOptions::fetch();

        wp_enqueue_script('stripe-js', 'https://js.stripe.com/v3/', [], MEPR_VERSION);
        wp_enqueue_script('mepr-stripe-form', MEPR_GATEWAYS_URL . '/stripe/form.js', ['stripe-js', 'mepr-checkout-js', 'jquery.payment'], MEPR_VERSION);

        $l10n = [
            'api_version'            => self::STRIPE_API_VERSION,
            'currency'               => strtolower($mepr_options->currency_code),
            'elements_appearance'    => $this->get_elements_appearance(),
            'payment_element_terms'  => $this->get_payment_element_terms(),
            'ajax_url'               => admin_url('admin-ajax.php'),
            'ajax_error'             => __('An error occurred, please DO NOT submit the form again as you may be double charged. Please contact us for further assistance instead.', 'memberpress'),
            'invalid_response_error' => __('The response from the server was invalid', 'memberpress'),
            'error_please_try_again' => __('An error occurred, please try again', 'memberpress'),
            'checkout_state_changed' => __('Your order details have changed. Please review the updated total and try again.', 'memberpress'),
            'top_error'              => sprintf(
            // Translators: %1$s: open strong tag, %2$s: close strong tag, %3$s: error message.
                esc_html__('%1$sERROR%2$s: %3$s', 'memberpress'),
                '<strong>',
                '</strong>',
                '%s'
            ),
        ];

        wp_localize_script(
            'mepr-stripe-form',
            'MeprStripeGateway',
            ['l10n_print_after' => 'MeprStripeGateway = ' . wp_json_encode($l10n)]
        );
    }

    /**
     * Get the appearance data for Stripe Elements
     *
     * @return array|stdClass
     */
    private function get_elements_appearance()
    {
        $appearance = [];

        $appearance = MeprHooks::apply_filters('mepr_stripe_elements_appearance', $appearance);

        if (empty($appearance)) {
            return new stdClass(); // {} in JSON
        }

        return $appearance;
    }

    /**
     * Get the terms options for the payment element.
     *
     * Suppresses Stripe's own mandate/terms text for every method type, because the checkout
     * renders its own consent copy. Static and public so the cart checkout can localize the
     * same value without building a gateway; it reads no instance state.
     *
     * @return array|stdClass
     */
    public static function get_payment_element_terms()
    {
        $terms = [
            'applePay'      => 'never',
            'auBecsDebit'   => 'never',
            'bancontact'    => 'never',
            'card'          => 'never',
            'cashapp'       => 'never',
            'googlePay'     => 'never',
            'ideal'         => 'never',
            'paypal'        => 'never',
            'sepaDebit'     => 'never',
            'usBankAccount' => 'never',
        ];

        $terms = MeprHooks::apply_filters('mepr_stripe_payment_element_terms', $terms);

        if (empty($terms)) {
            return new stdClass(); // {} in JSON
        }

        return $terms;
    }

    /**
     * Returns the payment form and required fields for the gateway
     *
     * @param MeprProduct|null $product The product to get the payment fields for.
     *
     * @return string The payment form HTML
     */
    public function spc_payment_fields($product = null)
    {
        $mepr_options        = MeprOptions::fetch();
        $payment_method      = $this;
        $payment_form_action = 'mepr-stripe-payment-form';
        $user                = MeprUtils::is_user_logged_in() ? MeprUtils::get_currentuserinfo() : null;

        if ($product instanceof MeprProduct && $this->settings->stripe_checkout_enabled !== 'on') {
            try {
                $coupon_code = $product->get_applicable_coupon_code();
                $cpn         = $coupon_code !== ''
                    ? MeprHooks::apply_filters('mepr_coupon_from_code', false, $coupon_code)
                    : false;
                $coupon_code = $cpn !== false ? $cpn->post_title : '';

                list($txn, $sub) = MeprCheckoutCtrl::prepare_transaction(
                    $product,
                    0,
                    $user instanceof MeprUser ? $user->ID : 0,
                    $this->id,
                    $cpn,
                    false
                );

                $elements_options = $this->get_elements_options(
                    $product,
                    $txn,
                    $sub,
                    $coupon_code,
                    MeprCheckoutCtrl::get_required_order_bump_products($product, $coupon_code)
                );
            } catch (Exception $e) {
                $txn = new MeprTransaction();
            }
        } else {
            $txn = new MeprTransaction();
        }

        return MeprView::get_string('/checkout/MeprStripeGateway/payment_form', get_defined_vars());
    }

    /**
     * Display the payment form
     * This gets called on the_content and just renders the payment form
     *
     * @param float    $amount         The payment amount.
     * @param MeprUser $user           The user making the payment.
     * @param integer  $product_id     The product being purchased.
     * @param string   $transaction_id The transaction ID.
     *
     * @return void
     */
    public function display_payment_form($amount, $user, $product_id, $transaction_id)
    {
        $txn         = new MeprTransaction($transaction_id);
        $order_bumps = $this->get_order_bumps((int) $txn->product_id);

        if (count($order_bumps)) {
            echo MeprTransactionsHelper::get_invoice_order_bumps($txn, '', $order_bumps); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
        } else {
            echo MeprTransactionsHelper::get_invoice($txn); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
        }
        ?>
        <div class="mp_wrapper mp_payment_form_wrapper">
            <?php
                $this->display_on_site_form($txn);
            ?>
        </div>
        <?php
    }

    /**
     * Displays the on-site payment form for the given transaction.
     *
     * @param MeprTransaction $txn The transaction object.
     */
    public function display_on_site_form($txn)
    {
        $mepr_options = MeprOptions::fetch();
        $prd          = $txn->product();
        $user         = $txn->user();

        if (!$prd->is_one_time_payment()) {
            $sub = $txn->subscription();
        }

        try {
            $cpn                    = $txn->coupon();
            $coupon_code            = $cpn instanceof MeprCoupon ? $cpn->post_title : '';
            $order_bump_product_ids = isset($_GET['obs']) && is_array($_GET['obs']) ? array_map('intval', $_GET['obs']) : [];
            $order_bump_products    = MeprCheckoutCtrl::get_order_bump_products($prd->ID, $order_bump_product_ids);

            $elements_options = $this->get_elements_options(
                $prd,
                $txn,
                isset($sub) && $sub instanceof MeprSubscription ? $sub : null,
                $coupon_code,
                $order_bump_products
            );
        } catch (Exception $e) {
            // Ignore.
        }
        ?>
      <form action="" method="post" id="mepr-stripe-payment-form">
        <input type="hidden" name="mepr_process_payment_form" value="Y" />
        <input type="hidden" name="mepr_transaction_id" value="<?php echo esc_attr($txn->id); ?>" />
        <?php MeprTransactionsHelper::checkout_token_field($txn); ?>
        <input type="hidden" name="address_required" value="<?php echo $mepr_options->show_address_fields && $mepr_options->require_address_fields ? 1 : 0 ?>" />

        <?php
        if ($user instanceof MeprUser) {
            MeprView::render('/checkout/MeprStripeGateway/payment_gateway_fields', get_defined_vars());
        }
        ?>
        <?php MeprHooks::do_action('mepr_stripe_payment_form_before_payment_element', $txn); ?>
        <?php if ($this->settings->stripe_checkout_enabled === 'on') : ?>
            <?php MeprHooks::do_action('mepr_stripe_payment_form_before_name_field', $txn); ?>
            <?php if ($this->settings->use_desc) : ?>
        <div class="mepr-stripe-gateway-description"><?php esc_html_e('Pay with your Credit Card via Stripe Checkout', 'memberpress'); ?></div>
            <?php endif; ?>
        <?php else : ?>
      <div class="mepr-stripe-elements">
        <div class="mepr-stripe-card-element" data-stripe-public-key="<?php echo esc_attr($this->get_public_key()); ?>" data-payment-method-id="<?php echo esc_attr($this->settings->id); ?>" data-locale-code="<?php echo esc_attr(self::get_locale_code()); ?>" data-elements-options="<?php echo isset($elements_options) ? esc_attr(wp_json_encode($elements_options)) : ''; ?>" data-user-email="<?php echo esc_attr($user->user_email); ?>"></div>
        <div role="alert" class="mepr-stripe-card-errors"></div>
      </div>
            <?php MeprHooks::do_action('mepr_stripe_payment_form', $txn); ?>
        <?php endif; ?>
        <?php MeprHooks::do_action('mepr_render_order_bump_hidden_fields'); ?>
      <div class="mepr_spacer">&nbsp;</div>
      <input type="submit" class="mepr-submit" value="<?php echo esc_attr(_x('Submit', 'ui', 'memberpress')); ?>" />
      <img src="<?php echo esc_url(admin_url('images/loading.gif')); ?>" alt="<?php esc_attr_e('Loading...', 'memberpress'); ?>" style="display: none;" class="mepr-loading-gif" />

      <noscript><p class="mepr_nojs"><?php esc_html_e('JavaScript is disabled in your browser. You will not be able to complete your purchase until you either enable JavaScript in your browser, or switch to a browser that supports it.', 'memberpress'); ?></p></noscript>
    </form>
        <?php
    }

    /**
     * Validates the payment form before a payment is processed
     *
     * @param  array $errors The errors array.
     * @return array|void The errors array
     */
    public function validate_payment_form($errors)
    {
        // This is done in the javascript with Stripe.
    }

    /**
     * Displays the form for the given payment gateway on the MemberPress Options page
     */
    public function display_options_form()
    {
        $mepr_options = MeprOptions::fetch();

        $id                 = $this->id;
        $integrations       = $mepr_options->integrations;
        $whk_url            = $this->notify_url('whk');
        $update_billing_url = $this->notify_url('update-billing.html', true);

        $test_secret_key         = trim($this->settings->api_keys['test']['secret']);
        $test_public_key         = trim($this->settings->api_keys['test']['public']);
        $live_secret_key         = trim($this->settings->api_keys['live']['secret']);
        $live_public_key         = trim($this->settings->api_keys['live']['public']);
        $force_ssl               = ($this->settings->force_ssl === 'on' or $this->settings->force_ssl === true);
        $debug                   = ($this->settings->debug === 'on' or $this->settings->debug === true);
        $test_mode               = $this->is_test_mode();
        $connect_status          = trim($this->settings->connect_status);
        $service_account_id      = trim($this->settings->service_account_id);
        $service_account_name    = stripslashes(trim($this->settings->service_account_name));
        $country                 = stripslashes(trim($this->settings->country));
        $churn_buster_enabled    = ($this->settings->churn_buster_enabled === 'on' or $this->settings->churn_buster_enabled === true);
        $stripe_checkout_enabled = $this->settings->stripe_checkout_enabled === 'on' || $this->settings->stripe_checkout_enabled === true;
        $payment_methods         = $this->get_available_payment_methods($mepr_options->currency_code);
        $enabled_payment_methods = is_array($this->settings->payment_methods) ? $this->settings->payment_methods : [];

        $churn_buster_uuid = trim($this->settings->churn_buster_uuid);

        $test_secret_key_str         = "{$mepr_options->integrations_str}[{$this->id}][api_keys][test][secret]";
        $test_public_key_str         = "{$mepr_options->integrations_str}[{$this->id}][api_keys][test][public]";
        $live_secret_key_str         = "{$mepr_options->integrations_str}[{$this->id}][api_keys][live][secret]";
        $live_public_key_str         = "{$mepr_options->integrations_str}[{$this->id}][api_keys][live][public]";
        $force_ssl_str               = "{$mepr_options->integrations_str}[{$this->id}][force_ssl]";
        $debug_str                   = "{$mepr_options->integrations_str}[{$this->id}][debug]";
        $test_mode_str               = "{$mepr_options->integrations_str}[{$this->id}][test_mode]";
        $connect_status_string       = "{$mepr_options->integrations_str}[{$this->id}][connect_status]";
        $service_account_id_string   = "{$mepr_options->integrations_str}[{$this->id}][service_account_id]";
        $service_account_name_string = "{$mepr_options->integrations_str}[{$this->id}][service_account_name]";
        $country_string              = "{$mepr_options->integrations_str}[{$this->id}][country]";
        $churn_buster_enabled_str    = "{$mepr_options->integrations_str}[{$this->id}][churn_buster_enabled]";
        $stripe_checkout_enabled_str = "{$mepr_options->integrations_str}[{$this->id}][stripe_checkout_enabled]";
        $churn_buster_uuid_str       = "{$mepr_options->integrations_str}[{$this->id}][churn_buster_uuid]";
        $payment_methods_str         = "{$mepr_options->integrations_str}[{$this->id}][payment_methods]";

        $account_email = get_option('mepr_authenticator_account_email');
        $secret        = get_option('mepr_authenticator_secret_token');
        $site_uuid     = get_option('mepr_authenticator_site_uuid');

        // $stripe_connect_url = 'https://connect.stripe.com/express/oauth/authorize?response_type=code&amp;client_id=ca_32D88BD1qLklliziD7gYQvctJIhWBSQ7&amp;scope=read_write';
        // If we're logged in then let's present a stripe url otherwise an authenticator url
        if ($account_email && $secret && $site_uuid) {
            $stripe_connect_url = self::get_stripe_connect_url($this->id);
        } else {
            $stripe_connect_url = MeprAuthenticatorCtrl::get_auth_connect_url(true, $this->id);
        }

        if (! defined('MEPR_DISABLE_STRIPE_CONNECT')) {
            MeprView::render('/admin/gateways/stripe/connect-migrate-prompt', get_defined_vars());
        }
        MeprView::render('/admin/gateways/stripe/keys', get_defined_vars());
        MeprView::render('/admin/gateways/stripe/checkboxes', get_defined_vars());
    }

    /**
     * Validates the form for the given payment gateway on the MemberPress Options page
     *
     * @param array $errors The errors array.
     *
     * @return array The errors array
     */
    public function validate_options_form($errors)
    {
        $mepr_options = MeprOptions::fetch();

        $testmode    = isset($_REQUEST[$mepr_options->integrations_str][$this->id]['test_mode']);
        $testmodestr = $testmode ? 'test' : 'live';

        // Bail if connecting to a Stripe Connect account, since the keys won't be set at this time
        // Also, bail if the payment method is not currently connected.
        if (isset($_REQUEST['stripe_connect_account_number']) || self::stripe_connect_status($this->id) === 'not-connected') {
            return $errors;
        }

        if (
            !isset($_REQUEST[$mepr_options->integrations_str][$this->id]['api_keys'][$testmodestr]['secret']) or
            empty($_REQUEST[$mepr_options->integrations_str][$this->id]['api_keys'][$testmodestr]['secret']) or
            !isset($_REQUEST[$mepr_options->integrations_str][$this->id]['api_keys'][$testmodestr]['public']) or
            empty($_REQUEST[$mepr_options->integrations_str][$this->id]['api_keys'][$testmodestr]['public'])
        ) {
            $errors[] = __('All Stripe keys must be filled in.', 'memberpress');
        }

        return $errors;
    }

    /**
     * This gets called on wp_enqueue_script and enqueues a set of
     * scripts for use on the front end user account page.
     */
    public function enqueue_user_account_scripts()
    {
        $sub = (isset($_GET['action']) && $_GET['action'] === 'update' && isset($_GET['sub'])) ? new MeprSubscription((int)$_GET['sub']) : false;
        if ($sub !== false && $sub->gateway === $this->id) {
            $sub_currency = $this->subscription_currency($sub);

            wp_enqueue_script('stripe-js', 'https://js.stripe.com/v3/', [], MEPR_VERSION . time());
            wp_enqueue_script('stripe-account-create-token', MEPR_GATEWAYS_URL . '/stripe/account_create_token.js', ['jquery', 'stripe-js'], MEPR_VERSION);

            $return_url = add_query_arg([
                'action'          => 'mepr_stripe_update_payment_method',
                'subscription_id' => $sub->id,
                'nonce'           => wp_create_nonce('mepr_process_update_account_form'),
            ], admin_url('admin-ajax.php'));

            wp_localize_script('stripe-account-create-token', 'MeprStripeAccountForm', [
                'api_version'           => self::STRIPE_API_VERSION,
                'public_key'            => $this->get_public_key(),
                'currency'              => strtolower($sub_currency),
                'payment_method_types'  => $this->get_update_setup_intent_payment_method_types((float) $sub->total, (float) $sub->total, $sub_currency),
                'elements_appearance'   => $this->get_elements_appearance(),
                'payment_element_terms' => $this->get_payment_element_terms(),
                'ajax_url'              => admin_url('admin-ajax.php'),
                'return_url'            => $return_url,
            ]);
        }
    }

    /**
     * Displays the update account form on the subscription account page
     *
     * @param integer $sub_id  The subscription ID.
     * @param array   $errors  The errors array.
     * @param string  $message The message to display.
     *
     * @return void
     */
    public function display_update_account_form($sub_id, $errors = [], $message = '')
    {
        $mepr_options         = MeprOptions::fetch();
        $sub                  = new MeprSubscription($sub_id);
        $user                 = $sub->user();
        $subscribed_with_link = false;

        if (empty($message) && isset($_GET['message'])) {
            $message = sanitize_text_field(wp_unslash($_GET['message']));
        }

        try {
            if (strpos($sub->subscr_id, 'sub_') === 0) {
                $subscription         = $this->retrieve_subscription($sub->subscr_id);
                $subscribed_with_link = isset($subscription->default_payment_method['type']) && $subscription->default_payment_method['type'] === 'link';
            }
        } catch (Exception $e) {
            // Ignore.
        }
        ?>
      <div class="mp_wrapper">
        <form action="" method="post" id="mepr-stripe-payment-form" data-sub-id="<?php echo esc_attr($sub->id); ?>">
          <input type="hidden" name="_mepr_nonce" value="<?php echo esc_attr(wp_create_nonce('mepr_process_update_account_form')); ?>" />
          <input type="hidden" name="address_required" value="<?php echo $mepr_options->show_address_fields && $mepr_options->require_address_fields ? 1 : 0 ?>" />
          <?php MeprView::render('/shared/errors', get_defined_vars()); ?>
          <?php
            if ($user instanceof MeprUser) {
                MeprView::render('/checkout/MeprStripeGateway/payment_gateway_fields', get_defined_vars());
            }
            ?>
          <div class="mepr_update_account_table">
            <?php if ($subscribed_with_link) : ?>
              <div><strong><?php echo wp_kses(__('Link is set up as the payment method for this subscription. You can change the default payment method by logging in to <a href="https://link.co">Link.co</a>.', 'memberpress'), ['a' => ['href' => []]]); ?></strong></div>
              <div><strong><?php esc_html_e('Or', 'memberpress'); ?></strong></div>
              <div><strong><?php esc_html_e('If you do not wish to use Link for this subscription, you can enter the details for a different payment method below.', 'memberpress'); ?></strong></div><br/>
            <?php else : ?>
              <div><strong><?php esc_html_e('Update your payment information below', 'memberpress'); ?></strong></div><br/>
            <?php endif; ?>
            <div class="mepr-stripe-elements">
              <div id="card-element" class="mepr-stripe-card-element" data-locale-code="<?php echo esc_attr(self::get_locale_code()); ?>" data-user-email="<?php echo $user instanceof MeprUser ? esc_attr($user->user_email) : ''; ?>"></div>
              <div id="card-errors" role="alert" class="mepr-stripe-card-errors"></div>
            </div>
            <div class="mepr_spacer">&nbsp;</div>
            <input type="submit" class="mepr-submit" value="<?php echo esc_attr_x('Submit', 'ui', 'memberpress'); ?>" />
            <img src="<?php echo esc_url(admin_url('images/loading.gif')); ?>" alt="<?php esc_attr_e('Loading...', 'memberpress'); ?>" style="display: none;" class="mepr-loading-gif" />

            <noscript><p class="mepr_nojs"><?php esc_html_e('JavaScript is disabled in your browser. You will not be able to complete your purchase until you either enable JavaScript in your browser, or switch to a browser that supports it.', 'memberpress'); ?></p></noscript>
          </div>
        </form>
      </div>
        <?php
    }

    /**
     * Validates the payment form before a payment is processed
     *
     * @param array $errors The errors array.
     *
     * @return array The errors array
     */
    public function validate_update_account_form($errors = [])
    {
        return $errors;
    }

    /**
     * Used to update the credit card information on a subscription by the given gateway.
     * This method should be used by the class to record a successful cancellation from
     * the gateway. This method should also be used by any IPN requests or Silent Posts.
     *
     * @param integer $sub_id The subscription ID.
     *
     * @return void
     */
    public function process_update_account_form($sub_id)
    {
        // Not used.
    }

    /**
     * No longer in use, but overridden templates might still call this
     *
     * @return false
     */
    public function is_stripe_link_enabled()
    {
        return false;
    }

    /**
     * Get available payment methods for a charge currency
     *
     * @param  string|null $currency Charge currency (null = primary).
     * @return array List of available payment methods
     */
    public function get_available_payment_methods($currency = null)
    {
        $currency            = $this->resolve_payment_method_currency($currency);
        $all_payment_methods = require MEPR_DATA_PATH . '/stripe_payment_methods.php';
        $payment_methods     = [];

        foreach ($all_payment_methods as $payment_method) {
            if (is_string($payment_method['currencies']) && $payment_method['currencies'] === 'all') {
                $payment_methods[] = $payment_method;
            } elseif (is_array($payment_method['currencies']) && in_array($currency, $payment_method['currencies'], true)) {
                $payment_methods[] = $payment_method;
            }
        }

        return $payment_methods;
    }

    /**
     * Whether we should be sending in test mode or not
     *
     * @return boolean
     */
    public function is_test_mode()
    {
        if (defined('MEMBERPRESS_STRIPE_TESTING') && MEMBERPRESS_STRIPE_TESTING) {
            $test_mode = true;
        } else {
            $test_mode = isset($this->settings->test_mode) && $this->settings->test_mode;
        }

        return MeprHooks::apply_filters('mepr_stripe_is_test_mode', $test_mode, $this);
    }

    /**
     * Build the Stripe dashboard URL for an object, routed by id type (SetupIntents live under
     * /setup_intents, PaymentIntents/charges under /payments) and the gateway's test/live mode.
     *
     * @param  string $object_id The Stripe object id (e.g. pi_…, seti_…).
     * @return string
     */
    public function dashboard_url($object_id)
    {
        $base = $this->is_test_mode() ? 'https://dashboard.stripe.com/test' : 'https://dashboard.stripe.com';
        $id   = (string) $object_id;

        if (strpos($id, 'seti_') === 0) {
            $path = '/setup_intents/';
        } elseif (strpos($id, 'sub_') === 0) {
            $path = '/subscriptions/';
        } else {
            $path = '/payments/';
        }

        return $base . $path . $id;
    }

    /**
     * Get the Stripe publishable key
     *
     * @return string
     */
    public function get_public_key()
    {
        if ($this->is_test_mode()) {
            return trim($this->settings->api_keys['test']['public']);
        }

        return trim($this->settings->api_keys['live']['public']);
    }

    /**
     * Get the Stripe secret key
     *
     * @return string
     */
    public function get_secret_key()
    {
        if ($this->is_test_mode()) {
            return trim($this->settings->api_keys['test']['secret']);
        }

        return trim($this->settings->api_keys['live']['secret']);
    }

    /**
     * Force SSL for payment processing
     *
     * @return boolean True if SSL should be forced
     */
    public function force_ssl()
    {
        return (isset($this->settings->force_ssl) and ($this->settings->force_ssl === 'on' or $this->settings->force_ssl === true));
    }

    /**
     * Get the renewal base date for a given subscription. This is the date MemberPress will use to calculate expiration dates.
     * Of course this method is meant to be overridden when a gateway requires it.
     *
     * @param MeprSubscription $sub The MemberPress subscription.
     *
     * @return string The renewal base date
     */
    public function get_renewal_base_date(MeprSubscription $sub)
    {
        global $wpdb;

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery
        $event = $wpdb->get_row(
            $wpdb->prepare(
                "
                SELECT e.created_at, e.args
                FROM {$wpdb->mepr_events} AS e
                WHERE e.event = 'subscription-resumed'
                AND e.evt_id_type = 'subscriptions'
                AND e.evt_id = %d
                ORDER BY e.created_at DESC LIMIT 1
                ",
                $sub->id
            )
        );

        if (!empty($event)) {
            $renewal_base_date = $event->created_at;

            // If the subscription was still active when it was resumed, a trial period is added. We need to account
            // for this trial period to get the correct renewal date.
            if (!empty($event->args)) {
                $args = json_decode($event->args, true);

                if (is_array($args) && isset($args['days_until_renewal']) && is_numeric($args['days_until_renewal'])) {
                    $date = date_create($event->created_at, new DateTimeZone('UTC'));

                    if ($date instanceof DateTime) {
                        $date->modify("+{$args['days_until_renewal']} days");
                        $renewal_base_date = $date->format('Y-m-d H:i:s');
                    }
                }
            }

            return $renewal_base_date;
        }

        return $sub->created_at;
    }

    /**
     * Process an incoming webhook from the Stripe Connect service
     *
     * @return void
     */
    public function service_listener()
    {

        $mepr_options = MeprOptions::fetch();

        // Retrieve the request's body and parse it as JSON.
        $body = @file_get_contents('php://input');

        MeprUtils::debug_log('********* WEBHOOK CONTENTS: ' . $body);
        $header_signature = MeprUtils::get_http_header('Signature');

        if (empty($header_signature)) {
            MeprUtils::debug_log('*** Exiting with no signature');
            MeprUtils::exit_with_status(403, __('No Webhook Signature', 'memberpress'));
        }

        $secret    = get_option('mepr_authenticator_secret_token');
        $signature = hash_hmac('sha256', $body, $secret);

        MeprUtils::debug_log('********* WEBHOOK SECRETS -- SERVICE: [' . $header_signature . '] LOCAL: [' . $signature . ']');

        if ($header_signature !== $signature) {
            MeprUtils::debug_log('*** Exiting with incorrect signature');
            MeprUtils::exit_with_status(403, __('Incorrect Webhook Signature', 'memberpress'));
        }

        $body = json_decode($body, true);

        if (!isset($body['event']) || empty($body['event'])) {
            MeprUtils::exit_with_status(403, __('No `event` set', 'memberpress'));
        }

        $event = sanitize_text_field($body['event']);

        $auth_site_uuid = get_option('mepr_authenticator_site_uuid');

        if ($event === 'update-credentials') {
            $site_uuid = sanitize_text_field($body['data']['site_uuid']);
            if ($auth_site_uuid !== $site_uuid) {
                MeprUtils::exit_with_status(404, __('Request was sent to the wrong site?', 'memberpress'));
            }

            $method_id = sanitize_text_field($body['data']['payment_method']);
            $pm        = $mepr_options->payment_method($method_id);
            if (empty($pm)) {
                MeprUtils::exit_with_status(404, __('No payment method like that exists on this site', 'memberpress'));
            }

            if (false === $pm->update_connect_credentials()) {
                MeprUtils::exit_with_status(502, __('Could not fetch the Connect credentials', 'memberpress'));
            }

            MeprUtils::debug_log(
                "MeprStripeGateway::service_listener stored payment methods [{$method_id}]: ",
                [$mepr_options->integrations[$method_id]['api_keys']['test']['secret']]
            );

            wp_send_json(['credentials' => 'saved']);
        }

        MeprUtils::exit_with_status(404, __('Webhook not supported', 'memberpress'));
    }

    /**
     * STRIPE SPECIFIC METHODS
     **/
    public function listener()
    {
        // Retrieve the request's body and parse it as JSON.
        $body       = @file_get_contents('php://input');
        $event_json = (object)json_decode($body, true);

        if (!isset($event_json->id)) {
            return;
        }

        if (MeprHooks::apply_filters('mepr_stripe_webhook_livemode_detection', false) && isset($event_json->livemode) && is_bool($event_json->livemode)) {
            if ($event_json->livemode) {
                add_filter('mepr_stripe_is_test_mode', '__return_false');
            } else {
                add_filter('mepr_stripe_is_test_mode', '__return_true');
            }
        }

        // Use the id to pull the event directly from the API (purely a security measure).
        try {
            $event = (object)$this->send_stripe_request("events/{$event_json->id}", [], 'get');
        } catch (Exception $e) {
            http_response_code(202); // Throw a 202 here so stripe doesn't send out a billion webhook broken emails.
            wp_die(esc_html($e->getMessage())); // Do nothing.
        }

        try {
            $_REQUEST['data'] = $obj = (object) $event->data['object'];

            if ($event->type === 'charge.succeeded') {
                // For one time payment with stripe checkout session.
            } elseif ($event->type === 'charge.failed') {
                $this->record_payment_failure();
            } elseif ($event->type === 'charge.refunded') {
                $this->record_refund();
            } elseif ($event->type === 'charge.disputed') {
                // Not worried about this right now.
            } elseif ($event->type === 'customer.subscription.created') {
                // $this->record_create_subscription(); // done on page
            } elseif ($event->type === 'checkout.session.completed' || $event->type === 'checkout.session.async_payment_succeeded') {
                $this->process_stripe_checkout_session_completed($obj);
            } elseif ($event->type === 'checkout.session.async_payment_failed') {
                $this->process_checkout_session_async_payment_failed($obj);
            } elseif ($event->type === 'customer.subscription.updated') {
                // $this->record_update_subscription(); // done on page
            } elseif ($event->type === 'customer.subscription.deleted') {
                $this->record_cancel_subscription();
            } elseif ($event->type === 'customer.subscription.trial_will_end') {
                // We may want to implement this feature at some point.
            } elseif ($event->type === 'invoice.payment_succeeded') {
                $this->handle_invoice_payment_succeeded_webhook($obj);
            } elseif ($event->type === 'invoice.payment_failed') {
                $this->handle_invoice_payment_failed_webhook($obj);
            } elseif ($event->type === 'invoice.finalization_failed') {
                $this->handle_invoice_finalization_failed_webhook($obj);
            } elseif ($event->type === 'customer.deleted') {
                MeprUser::delete_stripe_customer_id($this->get_meta_gateway_id(), $obj->id);
            } elseif ($event->type === 'product.deleted') {
                $this->delete_stored_product_id($obj->id);
            } elseif ($event->type === 'payment_intent.succeeded') {
                $this->handle_payment_intent_succeeded_webhook($obj);
            } elseif ($event->type === 'setup_intent.succeeded') {
                $this->handle_setup_intent_succeeded_webhook($obj);
            } elseif ($event->type === 'plan.deleted' || $event->type === 'price.deleted') {
                $this->delete_stored_price_id($obj->id);
            } elseif ($event->type === 'coupon.deleted') {
                // A deleted Stripe coupon can never be charged against again,
                // so the stored reference is dropped in every build, with or
                // without the coupons module. The module owns whatever else
                // the feature needs, so it still gets the event.
                $this->delete_stored_coupon_id($obj->id);

                MeprHooks::do_action("mepr_stripe_event_{$event->type}", $obj, $this);
            } elseif ($event->type === 'payment_intent.payment_failed') {
                $this->handle_payment_intent_payment_failed_webhook($obj);
            } elseif ($event->type === 'setup_intent.setup_failed') {
                $this->handle_setup_intent_setup_failed_webhook($obj);
            } elseif ($event->type === 'payment_method.automatically_updated') {
                if (isset($event->data['previous_attributes'])) {
                    $this->handle_payment_method_automatically_updated_event(
                        $obj,
                        (object) $event->data['previous_attributes']
                    );
                }
            } else {
                /**
                 * Handles Stripe webhook events owned by modules (e.g. the
                 * coupons module handles coupon.deleted). Fires for events the
                 * gateway does not fully own; where the gateway clears its own
                 * stored references first, it fires the action itself.
                 *
                 * @param object            $obj     The Stripe event object.
                 * @param MeprStripeGateway $gateway The gateway instance.
                 */
                MeprHooks::do_action("mepr_stripe_event_{$event->type}", $obj, $this);
            }
        } catch (Exception $e) {
            http_response_code(500);
            wp_die(esc_html($e->getMessage()));
        }
    }

    /**
     * Renders a custom page where a credit card can be updated
     */
    public function churn_buster()
    {
        $churn_buster_enabled = ($this->settings->churn_buster_enabled === 'on' || $this->settings->churn_buster_enabled === true);
        $uuid                 = trim($this->settings->churn_buster_uuid);

        if ($churn_buster_enabled && !empty($uuid)) {
            $mepr_options = MeprOptions::fetch();
            $company      = $mepr_options->attr('biz_name');

            if (empty($company)) {
                $company = MeprUtils::blogname();
            }

            MeprView::render('account/churn_buster', compact('uuid', 'company'));
        } else {
            MeprUtils::exit_with_status(404);
        }
    }

    /**
     * The return handler activates the grace period for subscriptions whose PaymentIntent has succeeded or is still processing
     */
    public function return_handler()
    {
        $txn_id = isset($_GET['txn_id']) ? (int) sanitize_text_field(wp_unslash($_GET['txn_id'])) : 0;
        $txn    = new MeprTransaction($txn_id);

        if ($txn->id > 0) {
            try {
                $this->sync_pending_session_taxes($txn);

                if ($txn->is_one_time_payment()) {
                    $payment_intent_id = isset($_GET['payment_intent']) ? sanitize_text_field(wp_unslash($_GET['payment_intent'])) : '';

                    if (!empty($payment_intent_id)) {
                        $payment_intent = (object) $this->send_stripe_request('payment_intents/' . $payment_intent_id, [], 'get');

                        if (isset($payment_intent->status) && $payment_intent->status === 'requires_payment_method') {
                            $product     = $txn->product();
                            $product_url = MeprUtils::get_permalink($product->ID);
                            $product_url = !empty($product_url) ? $product_url : home_url();

                            MeprUtils::wp_redirect(esc_url_raw(add_query_arg([
                                'errors' => __('Payment was unsuccessful, please check your payment details and try again.', 'memberpress'),
                            ], $product_url)));
                        }
                    }
                } else {
                    $sub = $txn->subscription();

                    if ($sub instanceof MeprSubscription && $sub->status !== MeprSubscription::$active_str && $sub->gateway === $this->id) {
                        $payment_intent_id = isset($_GET['payment_intent']) ? sanitize_text_field(wp_unslash($_GET['payment_intent'])) : '';

                        if (!empty($payment_intent_id)) {
                                $payment_intent = (object) $this->send_stripe_request('payment_intents/' . $payment_intent_id, ['expand' => ['invoice.total_tax_amounts.tax_rate']], 'get');

                            if (isset($payment_intent->status) && in_array($payment_intent->status, ['succeeded', 'processing'], true)) {
                                if (isset($payment_intent->created) && $payment_intent->created > (time() - MeprUtils::hours(24))) {
                                    if (isset($payment_intent->invoice['subscription']) && $sub->subscr_id === $payment_intent->invoice['subscription']) {
                                        $order     = $txn->order();
                                        $bump_txns = $order instanceof MeprOrder ? MeprTransaction::get_all_by_order_id($order->id, $txn->id) : [];

                                        // Reconcile the pending rows to the charged invoice before
                                        // activation, so the thank-you page shows the charged reality
                                        // ahead of the webhook.
                                        $this->reconcile_subscription_invoice_taxes($txn, $sub, $bump_txns, (object) $payment_intent->invoice);

                                        $this->activate_subscription($txn, $sub, false);
                                    }
                                }
                            }
                        }

                        if (strpos($txn->trans_num, 'cs_') === 0) {
                            $checkout_session = (object) $this->send_stripe_request('checkout/sessions/' . $txn->trans_num, [], 'get');

                            if (isset($checkout_session->created) && $checkout_session->created > (time() - MeprUtils::hours(24))) {
                                $this->activate_subscription($txn, $sub, false);
                            }
                        }
                    }
                }
            } catch (Exception $e) {
                // Ignore.
            }
        }

        if (isset($_GET['redirect_to']) && !empty($_GET['redirect_to'])) {
            $redirect_to = esc_url_raw(wp_unslash($_GET['redirect_to']));
            $redirect_to = wp_validate_redirect($redirect_to, home_url());
        } else {
            $redirect_to = home_url();
        }

        MeprUtils::wp_redirect($redirect_to);
    }

    /**
     * Fetches the latest invoice object.
     *
     * @param  MeprSubscription $sub The MemberPress subscription.
     * @throws MeprGatewayException If the customer could not be found.
     * @return object The latest invoice object
     */
    public function get_latest_invoice(MeprSubscription $sub)
    {
        if (strpos($sub->subscr_id, 'sub_') === 0) {
            $endpoint = "subscriptions/{$sub->subscr_id}";
        } else {
            try {
                $customer = $this->retrieve_customer($sub->subscr_id);
            } catch (Exception $e) {
                throw new MeprGatewayException(esc_html__('Customer not found', 'memberpress'));
            }

            $endpoint = "customers/{$customer->id}/subscription";
        }

        $args = MeprHooks::apply_filters('mepr_stripe_get_latest_invoice_args', [
            'expand' => [
                'latest_invoice',
            ],
        ], $sub);

        $subscr = (object) $this->send_stripe_request($endpoint, $args, 'get');

        return (object) $subscr->latest_invoice;
    }

    /**
     * Sends an email to the customer with a link to confirm the payment for a subscription invoice
     *
     * @param  MeprSubscription $sub The MemberPress subscription.
     * @throws MeprGatewayException If the customer could not be found or the invoice does not require action.
     * @uses   MeprStripeGateway::get_latest_invoice() to retrieve the latest invoice data
     */
    public function send_latest_invoice_payment_email(MeprSubscription $sub)
    {
        $user = $sub->user();

        if (!$user->ID) {
            throw new MeprGatewayException(esc_html__('User not found', 'memberpress'));
        }

        $invoice = $this->get_latest_invoice($sub);

        if ($invoice->status === 'open') {
            // Translators: In this string, %s is the Blog Name/Title.
            $subject = sprintf(__('[%s] Confirm Subscription Payment', 'memberpress'), MeprUtils::blogname());

            $body = MeprView::get_string('/emails/user_confirm_payment', [
                'blogname'           => MeprUtils::blogname(),
                'subscr_num'         => $sub->subscr_id,
                'hosted_invoice_url' => $invoice->hosted_invoice_url,
            ]);

            $message = MeprView::get_string('/emails/template', compact('body'));

            MeprUtils::wp_mail($user->formatted_email(), $subject, $message, ['Content-Type: text/html']);
        } else {
            throw new MeprGatewayException(esc_html__('The invoice does not require action from the customer.', 'memberpress'));
        }
    }

    /**
     * Sanitize the statement descriptor
     *
     * Removes invalid chars and limits the length.
     *
     * @param  string $statement_descriptor The statement descriptor to sanitize.
     * @return string
     */
    private function sanitize_statement_descriptor($statement_descriptor)
    {
        if (!is_string($statement_descriptor)) {
            return '';
        }

        $statement_descriptor = preg_replace('/[^a-zA-Z0-9.\-_ ]/', '', $statement_descriptor);
        $statement_descriptor = trim(substr($statement_descriptor, 0, 22));

        return $statement_descriptor;
    }

    /**
     * Send request to Stripe API
     *
     * @param  string       $endpoint        The API endpoint.
     * @param  array        $args            Request arguments.
     * @param  string       $method          HTTP method (post, get, etc).
     * @param  string       $domain          API domain.
     * @param  boolean      $blocking        Whether to wait for response.
     * @param  string|false $idempotency_key Idempotency key for the request.
     * @throws MeprHttpException When HTTP request fails.
     * @throws MeprRemoteException When API returns error.
     * @return array|object Response from Stripe API
     */
    public function send_stripe_request(
        $endpoint,
        $args = [],
        $method = 'post',
        $domain = 'https://api.stripe.com/v1/',
        $blocking = true,
        $idempotency_key = false
    ) {
        $mepr_options = MeprOptions::fetch();
        $uri          = "{$domain}{$endpoint}";

        $args = MeprHooks::apply_filters('mepr_stripe_request_args', $args);

        $arg_array = [
            'method'    => strtoupper($method),
            'body'      => $args,
            'timeout'   => 15,
            'blocking'  => $blocking,
            'sslverify' => $mepr_options->sslverify,
            'headers'   => $this->get_headers(),
        ];

        if (false !== $idempotency_key) {
            $arg_array['headers']['Idempotency-Key'] = $idempotency_key;
        }

        $arg_array = MeprHooks::apply_filters('mepr_stripe_request', $arg_array);

        $uid = uniqid();
        // $this->email_status("###{$uid} Stripe Call to {$uri} API Key: {$this->settings->secret_key}\n" . MeprUtils::object_to_string($arg_array, true) . "\n", $this->settings->debug);
        $resp = wp_remote_request($uri, $arg_array);

        // If we're not blocking then the response is irrelevant
        // So we'll just return true.
        if ($blocking === false) {
            return true;
        }

        if (is_wp_error($resp)) {
            throw new MeprHttpException(sprintf(
                // Translators: %s: gateway name.
                esc_html__('You had an HTTP error connecting to %s', 'memberpress'),
                esc_html($this->name)
            ));
        } else {
            $json_res = json_decode($resp['body'], true);
            if (null !== $json_res) {
                // $this->email_status("###{$uid} Stripe Response from {$uri}\n" . MeprUtils::object_to_string($json_res, true) . "\n", $this->settings->debug);
                if (isset($json_res['error'])) {
                    throw new MeprRemoteException(
                        sprintf(
                            '%1$s (%2$s)',
                            $json_res['error']['message'], // phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped
                            $json_res['error']['type'] // phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped
                        ),
                        (string) ($json_res['error']['code'] ?? '') // phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped
                    );
                } else {
                    return $json_res;
                }
            } else { // Un-decipherable message.
                throw new MeprRemoteException(sprintf(esc_html__('There was an issue with the credit card processor. Try again later.', 'memberpress'), esc_html($this->name)));
            }
        }

        return false;
    }

    /**
     * Get card information from a payment method.
     *
     * @param stdClass $payment_method The Stripe payment method object.
     *
     * @return array|null The card data array, or null a non-card payment method was used.
     */
    public function get_card($payment_method)
    {
        if ($payment_method && isset($payment_method->card) && is_array($payment_method->card)) {
            return [
                'last4'     => $payment_method->card['last4'],
                'exp_month' => $payment_method->card['exp_month'],
                'exp_year'  => $payment_method->card['exp_year'],
            ];
        }

        return null;
    }

    /**
     * Generates the user agent we use to pass to API request so
     * Stripe can identify our application.
     */
    public function get_user_agent()
    {
        $app_info = [
            'name'       => 'MemberPress Connect acct_1FIIDhKEEWtO8ZWC',
            'version'    => MEPR_VERSION,
            'url'        => rtrim(MeprUtils::get_link_url('home'), '/'),
            'partner_id' => 'pp_partner_EbxCWHE5ve1yUk',
        ];

        return [
            'lang'         => 'php',
            'lang_version' => phpversion(),
            'publisher'    => 'memberpress',
            'uname'        => (function_exists('php_uname')) ? php_uname() : '',
            'application'  => $app_info,
        ];
    }

    /**
     * Generates the headers to pass to API request.
     *
     * @return array
     */
    public function get_headers()
    {
        $user_agent = $this->get_user_agent();
        $app_info   = $user_agent['application'];

        return MeprHooks::apply_filters(
            'mepr_stripe_request_headers',
            [
                'Authorization'              => 'Basic ' . base64_encode("{$this->get_secret_key()}:"),
                'Stripe-Version'             => self::STRIPE_API_VERSION,
                'User-Agent'                 => $app_info['name'] . '/' . $app_info['version'] . ' (' . $app_info['url'] . ')',
                'X-Stripe-Client-User-Agent' => json_encode($user_agent),
            ]
        );
    }

    /**
     * Assembles the URL for redirecting to Stripe Connect
     *
     * @param  string  $method_id  The payment method ID.
     * @param  boolean $onboarding True if we are onboarding.
     * @return string
     */
    public static function get_stripe_connect_url($method_id, $onboarding = false)
    {
        $site_uuid = get_option('mepr_authenticator_site_uuid');

        if (empty($site_uuid) || empty(get_option('mepr_authenticator_secret_token'))) {
            return false;
        }

        // Carries no JWT: the launcher mints it and posts it to the service in the
        // request body, so the token never lands in a URL or the service log.
        $args = [
            'action'    => 'mepr_stripe_connect_launch',
            'method_id' => $method_id,
            '_wpnonce'  => wp_create_nonce('mepr-stripe-connect-launch'),
        ];

        if ($onboarding) {
            $args['onboarding'] = 'true';
        }

        return add_query_arg($args, admin_url('admin-ajax.php'));
    }

    /**
     * Builds the JWT payload for a Stripe Connect handshake.
     *
     * @param string  $method_id  The payment method id.
     * @param boolean $onboarding Whether this is an onboarding connect.
     *
     * @return array|false The payload, or false when the site is not connected.
     */
    public static function get_stripe_connect_payload($method_id, $onboarding = false)
    {
        $site_uuid = get_option('mepr_authenticator_site_uuid');

        if (empty($site_uuid) || empty(get_option('mepr_authenticator_secret_token'))) {
            return false;
        }

        $args = [
            'action'   => 'mepr_stripe_connect_update_creds',
            '_wpnonce' => wp_create_nonce('stripe-update-creds'),
        ];

        if ($onboarding) {
            $args['onboarding'] = 'true';
        }

        $base_return_url = add_query_arg($args, admin_url('admin-ajax.php'));
        $error_url       = add_query_arg(['mepr-action' => 'error'], $base_return_url);

        $pm = new MeprStripeGateway();
        $pm->load(['id' => $method_id]);

        return [
            'method_id'           => $pm->id,
            'site_uuid'           => $site_uuid,
            'edition'             => MEPR_EDITION,
            'user_uuid'           => get_option('mepr_authenticator_user_uuid'),
            'return_url'          => $base_return_url,
            'error_url'           => $error_url,
            'webhook_url'         => $pm->notify_url('whk'),
            'service_webhook_url' => $pm->notify_url('stripe-service-whk'),
            'mp_version'          => MEPR_VERSION,
        ];
    }

    /**
     * Get the Stripe Connect button URL
     *
     * @param  string $method_id The payment method ID.
     * @return void
     */
    public static function get_stripe_connect_button_url($method_id)
    {
        MeprAuthenticatorCtrl::get_auth_connect_url(true, $method_id);
    }

    /**
     * Check if API keys are set for a payment method
     *
     * @param  string $method_id Payment method ID.
     * @return boolean True if keys are set
     */
    public static function keys_are_set($method_id)
    {
        $mepr_options = MeprOptions::fetch();

        if (!isset($mepr_options->integrations[$method_id])) {
            return false;
        }

        $integ = $mepr_options->integrations[$method_id];

        return (
        ( isset($integ['api_keys']['test']['public']) && !empty($integ['api_keys']['test']['public']) ) ||
        ( isset($integ['api_keys']['test']['secret']) && !empty($integ['api_keys']['test']['secret']) ) ||
        ( isset($integ['api_keys']['live']['public']) && !empty($integ['api_keys']['live']['public']) ) ||
        ( isset($integ['api_keys']['live']['secret']) && !empty($integ['api_keys']['live']['secret']) )
        );
    }

    /**
     * Check if payment method uses Stripe Connect
     *
     * @param  string $method_id Payment method ID.
     * @return boolean True if using Stripe Connect
     */
    public static function is_stripe_connect($method_id)
    {
        $connect_status = self::stripe_connect_status($method_id);
        return ($connect_status !== 'not-connected');
    }

    /**
     * Get Stripe Connect status for payment method
     *
     * @param  string $method_id Payment method ID.
     * @return string Connect status ('connected', 'not-connected', etc)
     */
    public static function stripe_connect_status($method_id)
    {
        $mepr_options = MeprOptions::fetch();

        if (!isset($mepr_options->integrations[$method_id])) {
            return 'not-connected';
        }

        $integ = $mepr_options->integrations[$method_id];

        return ( !isset($integ['connect_status']) || empty($integ['connect_status']) ) ? 'not-connected' : $integ['connect_status'];
    }

    /**
     * Checks whether the user has a Stripe payment method that uses Stripe Connect
     *
     * @param string  $status    The connect status to check for.
     * @param boolean $return_id Whether to return the payment method ID or just true.
     *
     * @return string|boolean The payment method ID if $return_id is true, otherwise true or false.
     */
    public static function has_method_with_connect_status($status = 'connected', $return_id = false)
    {
        $mepr_options = MeprOptions::fetch();
        foreach ($mepr_options->integrations as $integration) {
            // Only check Stripe payment methods.
            if ('MeprStripeGateway' !== $integration['gateway']) {
                continue;
            }

            if ($status === self::stripe_connect_status($integration['id'])) {
                return $return_id ? $integration['id'] : true;
            }
        }

        return false;
    }

    /**
     * Fetches the credentials from the Stripe Connect service and updates them in the payment method.
     *
     * Leaves the stored keys untouched when the service response is unusable.
     *
     * @return null|false False when the response was rejected, null once stored.
     */
    public function update_connect_credentials()
    {
        $mepr_options = MeprOptions::fetch();

        $site_uuid = get_option('mepr_authenticator_site_uuid');

        $payload = [
            'site_uuid' => $site_uuid,
        ];

        $jwt = MeprAuthenticatorCtrl::generate_jwt($payload);

        // Make sure the request came from the Connect service.
        $response = wp_remote_get(MEPR_STRIPE_SERVICE_URL . "/api/credentials/{$this->id}", [
            'headers' => MeprUtils::jwt_header($jwt, MEPR_STRIPE_SERVICE_DOMAIN),
        ]);

        $creds = self::parse_connect_credentials($response);

        if (null === $creds) {
            MeprUtils::debug_log(
                "*** MeprStripeGateway::update_connect_credentials rejected the response for method_id = [{$this->id}]",
                [wp_remote_retrieve_response_code($response)]
            );

            return false;
        }

        MeprUtils::debug_log("*** MeprStripeGateway::update_connect_credentials updating creds for method_id = [{$this->id}]");

        // Store the credentials.
        foreach ($mepr_options->integrations as $method_id => $integ) {
            // Update ALL of the payment methods connected to this account.
            if (
                $method_id === $this->id || (
                isset($mepr_options->integrations[$method_id]['service_account_id']) &&
                $mepr_options->integrations[$method_id]['service_account_id'] === $creds['service_account_id'] )
            ) {
                MeprUtils::debug_log(
                    'MeprStripeGateway::update_connect_credentials updating payment method with this data: ',
                    [$creds]
                );

                $integ['api_keys']['test']['public'] = sanitize_text_field($creds['test_publishable_key']);
                $integ['api_keys']['test']['secret'] = sanitize_text_field($creds['test_secret_key']);
                $integ['api_keys']['live']['public'] = sanitize_text_field($creds['live_publishable_key']);
                $integ['api_keys']['live']['secret'] = sanitize_text_field($creds['live_secret_key']);
                $integ['service_account_id']         = sanitize_text_field($creds['service_account_id']);
                $integ['service_account_name']       = sanitize_text_field($creds['service_account_name']);
                $integ['connect_status']             = 'connected';

                $mepr_options->integrations[$method_id] = $integ;
            }
        }
        $store_result = $mepr_options->store(false);

        /**
         * Fires when the Stripe Connect credentials are updated.
         *
         * @param string $method_id The ID of the payment method.
         */
        MeprHooks::do_action('mepr_stripe_connect_credentials_updated', $this->id);

        return $store_result;
    }

    /**
     * Extracts the credentials from a Stripe Connect service response.
     *
     * @param  array|WP_Error $response The `/api/credentials` response.
     * @return array|null The credentials, or null unless the response is a 200 carrying every key.
     */
    public static function parse_connect_credentials($response)
    {
        if (200 !== (int) wp_remote_retrieve_response_code($response)) {
            return null;
        }

        $creds = json_decode(wp_remote_retrieve_body($response), true);

        if (!is_array($creds)) {
            return null;
        }

        $required = [
            'test_publishable_key',
            'test_secret_key',
            'live_publishable_key',
            'live_secret_key',
            'service_account_id',
        ];

        foreach ($required as $key) {
            if (empty($creds[$key]) || !is_string($creds[$key])) {
                return null;
            }
        }

        // Stripe accounts may have no display name, so only the key is required.
        if (!array_key_exists('service_account_name', $creds)) {
            return null;
        }

        return $creds;
    }

    /**
     * Is this payment method connected to Stripe?
     *
     * @return boolean
     */
    public function is_connected()
    {
        if (!empty($this->settings->connect_status) && $this->settings->connect_status !== 'not-connected') {
            return true;
        }

        return (
        !empty($this->settings->api_keys['test']['public']) ||
        !empty($this->settings->api_keys['test']['secret']) ||
        !empty($this->settings->api_keys['live']['public']) ||
        !empty($this->settings->api_keys['live']['secret'])
        );
    }

    /**
     * Get the Stripe Customer ID
     *
     * If the Stripe Customer does not exist for the given user, one will be created.
     *
     * @param  MeprUser $usr The MemberPress user.
     * @return string                   The Stripe Customer ID
     * @throws MeprHttpException        If there was an HTTP error connecting to Stripe.
     * @throws MeprRemoteException      If there was an invalid or error response from Stripe.
     */
    public function get_customer_id(MeprUser $usr)
    {
        $active_currency = MeprCurrencyService::get_active_currency();
        $customer_id     = $usr->get_stripe_customer_id($this->get_meta_gateway_id(), $active_currency);

        if (!is_string($customer_id) || strpos($customer_id, 'cus_') !== 0) {
            $customer = $this->create_customer($usr);
            $usr->set_stripe_customer_id($this->get_meta_gateway_id(), $customer->id, $active_currency);
            $customer_id = $customer->id;
        }

        return $customer_id;
    }

    /**
     * Create a Stripe Customer
     *
     * @param  MeprUser $usr The MemberPress user.
     * @return stdClass                 The Stripe Customer data
     * @throws MeprHttpException        If there was an HTTP error connecting to Stripe.
     * @throws MeprRemoteException      If there was an invalid or error response from Stripe.
     */
    public function create_customer(MeprUser $usr)
    {
        $args = $this->get_customer_args($usr);

        // A tax ID can be set inline only at creation, via tax_id_data.
        $tax_id = $this->get_customer_tax_id_data($usr);
        if ($tax_id !== null) {
            $args['tax_id_data'] = [$tax_id];
        }

        $args = MeprHooks::apply_filters('mepr_stripe_create_customer_args', $args, $usr);

        try {
            $customer = (object) $this->send_stripe_request('customers', $args, 'post');
        } catch (MeprRemoteException $e) {
            throw $this->member_facing_customer_write_exception($e); // phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped
        }

        return $customer;
    }

    /**
     * Update the Stripe Customer with the latest user data
     *
     * @param  string   $customer_id The Stripe Customer ID.
     * @param  MeprUser $usr         The MemberPress User.
     * @throws MeprHttpException                If there was an HTTP error connecting to Stripe.
     * @throws MeprRemoteException              If there was an invalid or error response from Stripe.
     */
    public function update_customer($customer_id, MeprUser $usr)
    {
        $args = MeprHooks::apply_filters('mepr_stripe_update_customer_args', $this->get_customer_args($usr), $usr);

        try {
            $this->send_stripe_request("customers/$customer_id", $args, 'post');
        } catch (MeprRemoteException $e) {
            throw $this->member_facing_customer_write_exception($e); // phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped
        }

        // A customer's tax IDs cannot be set on the update call; reconcile them
        // through the dedicated sub-resource. Customer tax IDs are managed only
        // under automatic tax; when it is off they are left exactly as Stripe
        // holds them.
        if (self::use_automatic_tax()) {
            $this->reconcile_customer_tax_ids($customer_id, $this->get_customer_tax_id_data($usr));
        }
    }

    /**
     * Translate an unpriceable-tax-location rejection on a customer write
     * into the member-facing error, preserving the machine code. Any other
     * exception is returned unchanged.
     *
     * @param  MeprRemoteException $e The Stripe request exception.
     * @return MeprRemoteException The exception for the caller to throw.
     */
    private function member_facing_customer_write_exception(MeprRemoteException $e): MeprRemoteException
    {
        if ($e->get_error_code() !== 'customer_tax_location_invalid') {
            return $e;
        }

        return new MeprRemoteException(
            __('We could not verify your billing address for tax calculation. Please check your billing address and try again.', 'memberpress'),
            $e->get_error_code()
        );
    }

    /**
     * Get the args for creating or updating a Stripe customer
     *
     * @param  MeprUser $usr The MemberPress user.
     * @return array
     */
    private function get_customer_args(MeprUser $usr)
    {
        $mepr_options = MeprOptions::fetch();

        $args = [
            'email' => $usr->user_email,
        ];

        $full_name = $usr->get_full_name();
        if ($full_name) {
            $args['name'] = $full_name;
        }

        if (
            MeprHooks::apply_filters(
                'mepr_stripe_populate_customer_address',
                $mepr_options->show_address_fields || $mepr_options->show_address_on_account
            )
        ) {
            $address = [
                'line1'       => get_user_meta($usr->ID, 'mepr-address-one', true),
                'line2'       => get_user_meta($usr->ID, 'mepr-address-two', true),
                'city'        => get_user_meta($usr->ID, 'mepr-address-city', true),
                'state'       => get_user_meta($usr->ID, 'mepr-address-state', true),
                'country'     => get_user_meta($usr->ID, 'mepr-address-country', true),
                'postal_code' => get_user_meta($usr->ID, 'mepr-address-zip', true),
            ];

            foreach ($address as $key => $value) {
                if (empty($value) || !is_string($value)) {
                    unset($address[$key]);
                }
            }

            // Stripe replaces a customer's address as a whole, so a partial
            // address would blank a complete one already on the customer.
            if (!empty($address['line1']) && !empty($address['city']) && !empty($address['country'])) {
                $args['address'] = $address;

                if (MeprHooks::apply_filters('mepr_stripe_populate_customer_shipping_address', false) && !empty($full_name)) {
                    $args['shipping'] = [
                        'name'    => $full_name,
                        'address' => $address,
                    ];
                }
            }
        }

        if (self::use_automatic_tax()) {
            $args['tax'] = ['validate_location' => 'immediately'];
        }

        return $args;
    }

    /**
     * Resolve the member's VAT tax ID for Stripe, or null when none applies.
     *
     * Returns a Stripe tax-ID descriptor (type + value) only when Stripe
     * automatic tax is on, VAT is enabled, businesses are not being taxed, the
     * member is a business, and a VAT number is present. GB numbers use gb_vat;
     * all others eu_vat. Handled separately from get_customer_args() because
     * Stripe accepts a tax ID under tax_id_data on customer creation and only
     * through the customers/{id}/tax_ids sub-resource on an existing customer.
     *
     * A merchant who taxes businesses charges them like consumers, so no tax
     * ID is resolved for them — otherwise a preview or calculation would
     * reverse-charge to 0% while the invoice collects VAT. Public so
     * MeprStripeTaxIntegration builds previews and recorded calculations from
     * the same VAT gating the charge uses.
     *
     * @param  MeprUser $usr The member.
     * @return array{type:string,value:string}|null
     */
    public function get_customer_tax_id_data(MeprUser $usr): ?array
    {
        if (!self::use_automatic_tax()) {
            return null;
        }

        if (
            !get_option('mepr_vat_enabled') ||
            get_option('mepr_vat_tax_businesses') ||
            MeprVatTaxCtrl::get_customer_type($usr) !== 'business'
        ) {
            return null;
        }

        // The stored value is normalized the way core validation reads it
        // (separators stripped, case-insensitive), so the descriptor sends
        // the canonical form of what validation accepted.
        $vat_number = strtoupper(trim(preg_replace('/[-.●]/', '', MeprVatTaxCtrl::get_vat_number($usr))));

        if ($vat_number === '') {
            return null;
        }

        // Core validation accepts a prefix-less number, but Stripe cannot
        // label one (eu_vat requires the country prefix), and a mislabeled
        // tax ID rejects the whole write that carries it, so the member is
        // treated as having no usable VAT ID. A wrong two-letter prefix
        // goes out verbatim; Stripe's own validation owns that rejection.
        if (!preg_match('/^[A-Z][A-Z]/', $vat_number)) {
            return null;
        }

        return [
            'type'  => substr($vat_number, 0, 2) === 'GB' ? 'gb_vat' : 'eu_vat',
            'value' => $vat_number,
        ];
    }

    /**
     * Reconcile a Stripe Customer's tax IDs to the single desired VAT ID.
     *
     * Stripe's customer update endpoint cannot set tax IDs inline, so tax IDs on
     * an existing customer are managed through the customers/{id}/tax_ids
     * sub-resource. Only the types this integration writes (eu_vat, gb_vat) are
     * managed: a merchant-attached tax ID of any other type is invisible to the
     * reconcile. This removes any managed tax ID that does not match $desired
     * and adds $desired when it is absent. A null $desired removes every managed
     * tax ID (e.g. the member is no longer a taxable business).
     *
     * @param  string                               $customer_id The Stripe Customer ID.
     * @param  array{type:string,value:string}|null $desired     The VAT ID to keep, or null.
     * @return void
     * @throws MeprHttpException   If there was an HTTP error connecting to Stripe.
     * @throws MeprRemoteException If there was an invalid or error response from Stripe.
     */
    private function reconcile_customer_tax_ids(string $customer_id, ?array $desired): void
    {
        $response = (object) $this->send_stripe_request("customers/$customer_id/tax_ids", [], 'get');
        $rows     = isset($response->data) && is_array($response->data) ? $response->data : [];

        $already_present = false;

        foreach ($rows as $row) {
            $row       = (object) $row;
            $row_id    = $row->id ?? '';
            $row_type  = $row->type ?? '';
            $row_value = $row->value ?? '';

            if (!in_array($row_type, ['eu_vat', 'gb_vat'], true)) {
                continue;
            }

            if ($desired !== null && $row_type === $desired['type'] && $row_value === $desired['value']) {
                $already_present = true;
                continue;
            }

            if ($row_id !== '') {
                $this->send_stripe_request("customers/$customer_id/tax_ids/$row_id", [], 'delete');
            }
        }

        if ($desired !== null && !$already_present) {
            $this->send_stripe_request("customers/$customer_id/tax_ids", $desired);
        }
    }

    /**
     * Get the Stripe Product ID
     *
     * If the Stripe Product does not exist for the given product, one will be created.
     *
     * @param MeprProduct $prd             The MemberPress product.
     * @param boolean     $initial_payment Whether the product is for an initial payment.
     *
     * @return string The Stripe Product ID
     * @throws MeprHttpException If there was an HTTP error connecting to Stripe.
     * @throws MeprRemoteException If there was an invalid or error response from Stripe.
     */
    public function get_product_id(MeprProduct $prd, $initial_payment = false)
    {
        // (1) Try the per-post-id meta key.
        $product_id = $this->get_stored_product_id($prd, $initial_payment);

        if (is_string($product_id) && strpos($product_id, 'prod_') === 0) {
            return $product_id;
        }

        // (2) With automatic tax off, migrate a row written under the pre-post-id
        // key shape. With automatic tax on, the key encodes tax_behavior and
        // tax_code, so a missing key must create a fresh Product rather than
        // reuse one whose tax inputs are unknown.
        if (!self::use_automatic_tax()) {
            $legacy_key = $this->legacy_product_meta_key($initial_payment);
            $product_id = get_post_meta($prd->ID, $legacy_key, true);

            if (is_string($product_id) && strpos($product_id, 'prod_') === 0) {
                // Write the new key FIRST (transactional safety), then remove the legacy row.
                $this->set_stored_product_id($prd, $product_id, $initial_payment);
                delete_post_meta($prd->ID, $legacy_key);
                return $product_id;
            }
        }

        // (3) Neither key exists — create a fresh Stripe Product.
        $product = $this->create_product($prd, $initial_payment);
        $this->set_stored_product_id($prd, $product->id, $initial_payment);

        return $product->id;
    }

    /**
     * Create a Stripe Product
     *
     * @param MeprProduct $prd             The MemberPress product.
     * @param boolean     $initial_payment Whether the product is for an initial payment.
     *
     * @return stdClass                 The Stripe Product data
     * @throws MeprHttpException        If there was an HTTP error connecting to Stripe.
     * @throws MeprRemoteException      If there was an invalid or error response from Stripe.
     */
    public function create_product(MeprProduct $prd, $initial_payment = false)
    {
        $product_name = $prd->display_name();

        if ($initial_payment) {
            // Translators: %s: the product name.
            $product_name = sprintf(__('%s - Initial Payment', 'memberpress'), $product_name);
        }

        $base_args = [
            'name' => $product_name,
            'type' => 'service',
        ];

        if (self::use_automatic_tax()) {
            $tax_code = MeprStripeTaxIntegration::get_product_tax_code($prd->ID);
            if ($tax_code !== '') {
                $base_args['tax_code'] = $tax_code;
            }
        }

        $args = MeprHooks::apply_filters('mepr_stripe_create_product_args', $base_args, $prd);

        // Stripe requires a Product name, so a filter that empties or
        // unsets it would abort the creation and the checkout riding it.
        if (empty($args['name'])) {
            $args['name'] = $product_name;
        }

        if (!array_key_exists('statement_descriptor', $args)) {
            $statement_descriptor = $this->get_statement_descriptor($prd);

            if (strlen($statement_descriptor) > 1) {
                $args['statement_descriptor'] = $statement_descriptor;
            }
        }

        $product = (object) $this->send_stripe_request('products', $args, 'post');

        return $product;
    }

    /**
     * Get the Stripe Price ID for a product's current payment terms.
     *
     * The single resolver for recurring and one-time products. Resolution
     * is lazy on use: the current price key is read first; with automatic
     * tax off, the released legacy keys (the recurring plan key and the
     * one-time price key) are fixed up in place — the value is re-indexed
     * under the current key and the legacy row deleted. Under automatic
     * tax the legacy fix-up is skipped: the terms hash carries
     * tax_behavior, so that namespace regenerates prices with explicit
     * behavior instead of riding grandfathered objects, and legacy rows
     * stay untouched for a return to legacy mode. When nothing resolves, a
     * modern Price is created and stored under the current key.
     *
     * @param  float                 $amount         The payment amount (excluding tax).
     * @param  MeprProduct           $prd            The MemberPress product.
     * @param  MeprSubscription|null $sub            The subscription (null for one-time payments).
     * @param  boolean               $force_one_time Force a one-time price for the amount even on a
     *                                               recurring product (an order bump's first period).
     * @return string The Stripe Price ID (grandfathered plan_ IDs included).
     * @throws MeprGatewayException When the billing period type is unsupported.
     * @throws MeprHttpException If there was an HTTP error connecting to Stripe.
     * @throws MeprRemoteException If there was an invalid or error response from Stripe.
     */
    public function get_stripe_price_id(float $amount, MeprProduct $prd, ?MeprSubscription $sub = null, bool $force_one_time = false): string
    {
        // Bill and key the price in the subscription's own currency; no subscription, or one
        // without a currency, resolves to the site primary and keys exactly as released.
        $primary_currency = strtoupper(MeprOptions::fetch()->currency_code);
        $currency  = $sub instanceof MeprSubscription && !empty($sub->currency)
            ? strtoupper($sub->currency)
            : $primary_currency;
        $converted = $this->to_zero_decimal_amount($amount, $currency);
        $price_id  = $this->get_stored_price_id($prd, $converted, $force_one_time, $currency);

        if ($price_id !== null) {
            return $price_id;
        }

        if (!self::use_automatic_tax()) {
            $legacy = $this->find_legacy_price_id($amount, $prd, $force_one_time, $currency);

            if ($legacy !== null) {
                list($legacy_key, $price_id) = $legacy;

                // Write the current key first — never lose the id.
                $this->set_stored_price_id($prd, $converted, $price_id, $force_one_time, $currency);
                delete_post_meta($prd->ID, $legacy_key);

                return $price_id;
            }
        }

        $price = $this->create_price($amount, $prd, $sub, $force_one_time);
        $this->set_stored_price_id($prd, $converted, $price->id, $force_one_time, $currency);

        return $price->id;
    }

    /**
     * Find a released legacy meta row holding a usable Stripe id for the
     * given terms.
     *
     * Legacy hashes are byte-sensitive, so each key is checked with the
     * exact data types its released writer hashed: the recurring plan key
     * always hashed the zero-decimal amount string, while the one-time key
     * hashed the raw amount as passed — a float at the casting call sites,
     * the format_float STRING the base-price filter chain emitted for
     * adjusted amounts (coupon-discounted, VAT-removed), or the product's
     * raw price value on the session main-product path.
     *
     * @param  float       $amount         The payment amount (excluding tax).
     * @param  MeprProduct $prd            The MemberPress product.
     * @param  boolean     $force_one_time Whether to resolve the one-time legacy key
     *                                     regardless of the product's own terms.
     * @param  string|null $currency       ISO 4217 currency for the price (null = site primary).
     * @return array|null The matched meta key and id pair, or null.
     */
    private function find_legacy_price_id(
        float $amount,
        MeprProduct $prd,
        bool $force_one_time = false,
        ?string $currency = null
    ): ?array {
        $keys = [];

        if ($force_one_time || $prd->is_one_time_payment()) {
            $forms   = [$amount];
            $forms[] = MeprUtils::format_float($amount);

            if (is_numeric($prd->price) && (float) $prd->price === $amount && !in_array($prd->price, $forms, true)) {
                $forms[] = $prd->price;
            }

            foreach ($forms as $form) {
                $keys[] = '_mepr_stripe_onetime_price_id_' . md5(serialize([
                    'currency'       => $this->hashed_currency($currency),
                    'amount'         => $form,
                    'payment_method' => $this->get_meta_gateway_id(),
                ]));
            }
        } else {
            $keys[] = $this->legacy_plan_id_meta_key($prd, (string) $this->to_zero_decimal_amount($amount, $currency), $currency);
        }

        foreach ($keys as $key) {
            $value = get_post_meta($prd->ID, $key, true);

            if ($this->is_stripe_price_id($value)) {
                return [$key, $value];
            }
        }

        return null;
    }

    /**
     * Create a Stripe Price for a product's payment terms.
     *
     * Recurring terms carry the full recurring block (interval and
     * interval_count). Under automatic tax the price is created with an
     * explicit tax_behavior matching the mepr calc type — applied after
     * the filters, which never see it. Recurring creations first pass the
     * deprecated mepr_stripe_create_plan_args filter through a
     * plans-shaped projection so legacy listeners keep their exact
     * semantics.
     *
     * @param  float                 $amount         The payment amount (excluding tax).
     * @param  MeprProduct           $prd            The MemberPress product.
     * @param  MeprSubscription|null $sub            The subscription (null for one-time payments).
     * @param  boolean               $force_one_time Force a one-time price (no recurring block) even
     *                                               on a recurring product.
     * @return stdClass The Stripe Price data.
     * @throws MeprGatewayException When the billing period type is unsupported.
     * @throws MeprHttpException If there was an HTTP error connecting to Stripe.
     * @throws MeprRemoteException If there was an invalid or error response from Stripe.
     *
     * phpcs:ignore Squiz.Commenting.FunctionCommentThrowTag.WrongNumber -- send_stripe_request() propagates the HTTP and remote exceptions.
     */
    private function create_price(float $amount, MeprProduct $prd, ?MeprSubscription $sub, bool $force_one_time = false): stdClass
    {
        $mepr_options = MeprOptions::fetch();
        $product_id   = $this->get_product_id($prd);

        $currency = $sub instanceof MeprSubscription && !empty($sub->currency)
            ? strtolower($sub->currency)
            : strtolower($mepr_options->currency_code);

        $args = [
            'product'     => $product_id,
            'unit_amount' => $this->to_zero_decimal_amount($amount, $currency),
            'currency'    => $currency,
        ];

        if (!$force_one_time && !$prd->is_one_time_payment()) {
            $terms = $sub instanceof MeprSubscription ? $sub : $prd;

            if ($terms->period_type === 'months') {
                $interval = 'month';
            } elseif ($terms->period_type === 'years') {
                $interval = 'year';
            } elseif ($terms->period_type === 'weeks') {
                $interval = 'week';
            } else {
                // Translators: %s: the product's billing period type.
                throw new MeprGatewayException(sprintf(__('Unsupported billing period type: %s', 'memberpress'), $terms->period_type)); // phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped
            }

            $args['recurring'] = [
                'interval'       => $interval,
                'interval_count' => (int) $terms->period,
            ];

            $args = $this->apply_deprecated_create_plan_args($args, $sub);
        }

        $args = MeprHooks::apply_filters('mepr_stripe_create_price_args', $args, $prd, $amount, $sub);

        // Prevent a Stripe error if the 'product' value is modified by hook.
        if (!isset($args['product']) || is_array($args['product'])) {
            $args['product'] = $product_id;
        }

        if (self::use_automatic_tax()) {
            $args['tax_behavior'] = $mepr_options->attr('tax_calc_type') === 'inclusive' ? 'inclusive' : 'exclusive';
        }

        return (object) $this->send_stripe_request('prices', $args, 'post');
    }

    /**
     * Pass a price-creation request through the deprecated
     * mepr_stripe_create_plan_args filter.
     *
     * Legacy listeners receive the plans-shaped projection they always did
     * (amount, interval, interval_count) and their edits are translated
     * back onto the prices shape; unknown keys pass through unchanged.
     * The exceptions: statement_descriptor, which the plans path always
     * stripped, and the plans-only parameters with no prices equivalent
     * (a custom id, trial_period_days), which /prices would reject as
     * unknown. Trials live on the subscription, never the price.
     *
     * @param  array                 $args The prices-shaped creation args.
     * @param  MeprSubscription|null $sub  The subscription.
     * @return array
     */
    private function apply_deprecated_create_plan_args(array $args, ?MeprSubscription $sub): array
    {
        if (!has_filter('mepr_stripe_create_plan_args')) {
            return $args;
        }

        $plans_args = [
            'amount'         => $args['unit_amount'],
            'interval'       => $args['recurring']['interval'],
            'interval_count' => $args['recurring']['interval_count'],
            'currency'       => $args['currency'],
            'product'        => $args['product'],
        ];

        $plans_args = apply_filters_deprecated(
            'mepr_stripe_create_plan_args',
            [$plans_args, $sub],
            '1.12.18',
            'mepr_stripe_create_price_args'
        );

        if (!is_array($plans_args)) {
            return $args;
        }

        unset($plans_args['statement_descriptor'], $plans_args['id'], $plans_args['trial_period_days']);

        $args['unit_amount']                 = $plans_args['amount'] ?? $args['unit_amount'];
        $args['currency']                    = $plans_args['currency'] ?? $args['currency'];
        $args['product']                     = $plans_args['product'] ?? $args['product'];
        $args['recurring']['interval']       = $plans_args['interval'] ?? $args['recurring']['interval'];
        $args['recurring']['interval_count'] = $plans_args['interval_count'] ?? $args['recurring']['interval_count'];

        unset($plans_args['amount'], $plans_args['interval'], $plans_args['interval_count'], $plans_args['currency'], $plans_args['product']);

        return array_merge($args, $plans_args);
    }

    /**
     * Whether a stored value is a usable Stripe price identifier.
     *
     * Both id families are accepted — plans and prices are one Stripe
     * object exposed under two prefixes. Anything else is treated as
     * missing, so malformed rows never reach Stripe.
     *
     * @param  mixed $value The stored value.
     * @return boolean
     */
    private function is_stripe_price_id($value): bool
    {
        return is_string($value) && (strpos($value, 'price_') === 0 || strpos($value, 'plan_') === 0);
    }

    /**
     * Create a Stripe Coupon
     *
     * @param  MeprCoupon       $cpn             The MemberPress coupon.
     * @param  string           $discount_amount The coupon discount amount.
     * @param  boolean          $onetime         Whether the coupon is for a one-time payment.
     * @param  MeprProduct|null $product         The product the coupon is for.
     * @param  string|null      $currency        ISO 4217 currency for amount_off (null = primary / legacy).
     * @return stdClass The Stripe Coupon data
     * @throws MeprHttpException If there was an HTTP error connecting to Stripe.
     * @throws MeprRemoteException If there was an invalid or error response from Stripe.
     */
    public function create_coupon(MeprCoupon $cpn, $discount_amount, $onetime, $product = null, $currency = null)
    {
        $args = MeprHooks::apply_filters('mepr_stripe_create_coupon_args', [
            'name'     => substr($cpn->post_title, 0, 40),
            'duration' => 'forever',
        ], $cpn);

        $mepr_options = MeprOptions::fetch();
        // The amount_off value must match the plan currency (lowercase ISO); percent_off is currency-agnostic.
        $coupon_currency = !empty($currency)
            ? strtolower($currency)
            : strtolower($mepr_options->currency_code ?: 'usd');

        if ($onetime) {
            $args['duration'] = 'once';

            if ($cpn->get_first_payment_discount_type($product) === 'percent') {
                $args = array_merge([
                    'percent_off' => $discount_amount,
                ], $args);
            } else {
                $args = array_merge([
                    'amount_off' => $discount_amount,
                    'currency'   => $coupon_currency,
                ], $args);
            }
        } else {
            if ($cpn->get_discount_type($product) === 'percent') {
                $args = array_merge([
                    'percent_off' => $discount_amount,
                ], $args);
            } else {
                $args = array_merge([
                    'amount_off' => $discount_amount,
                    'currency'   => $coupon_currency,
                ], $args);
            }
        }

        $coupon = (object) $this->send_stripe_request('coupons', $args, 'post');

        return $coupon;
    }

    /**
     * Get the Stripe Coupon ID
     *
     * @param  MeprCoupon       $cpn             The MemberPress coupon.
     * @param  string           $discount_amount The coupon discount amount.
     * @param  boolean          $onetime         Whether the coupon is for a one-time payment.
     * @param  MeprProduct|null $product         The product the coupon is for.
     * @param  string|null      $currency        ISO 4217 currency for amount_off (null = primary / legacy).
     * @return string The Stripe Coupon ID
     * @throws MeprHttpException If there was an HTTP error connecting to Stripe.
     * @throws MeprRemoteException If there was an invalid or error response from Stripe.
     */
    public function get_coupon_id(MeprCoupon $cpn, $discount_amount, $onetime = false, $product = null, $currency = null)
    {
        $coupon_id = $cpn->get_stripe_coupon_id($this->get_meta_gateway_id(), $discount_amount, $onetime, $product, $currency);

        if (!is_string($coupon_id) || $coupon_id === '') {
            $coupon = $this->create_coupon($cpn, $discount_amount, $onetime, $product, $currency);
            $cpn->set_stripe_coupon_id($this->get_meta_gateway_id(), $discount_amount, $coupon->id, $onetime, $product, $currency);
            $coupon_id = $coupon->id;
        }

        return $coupon_id;
    }

    /**
     * Get the statement descriptor
     *
     * @param  MeprProduct $product The MemberPress product.
     * @return string               The statement descriptor
     */
    private function get_statement_descriptor(MeprProduct $product)
    {
        $descriptor = MeprUtils::blogname();

        if (empty($descriptor)) {
            $descriptor = wp_parse_url(get_option('siteurl'), PHP_URL_HOST);
        }

        $descriptor = MeprHooks::apply_filters('mepr_stripe_statement_descriptor', $descriptor, $product);

        return $this->sanitize_statement_descriptor($descriptor);
    }

    /**
     * Create a Stripe Subscription.
     *
     * @param MeprTransaction  $txn                   The MemberPress transaction.
     * @param MeprSubscription $sub                   The MemberPress subscription.
     * @param MeprProduct      $prd                   The MemberPress product.
     * @param string           $customer_id           The Stripe Customer ID.
     * @param string           $payment_method_id     The Stripe PaymentMethod ID to use for payment or setup.
     * @param boolean          $default_incomplete    Whether the subscription should default to incomplete status.
     * @param integer          $trial_days            The number of trial days to set on the subscription.
     * @param float|null       $min_payment           The smallest payment the order requires, order bumps included.
     * @param float|null       $max_payment           The largest payment the order requires, order bumps included.
     * @param string|false     $idempotency_key       Stripe Idempotency-Key for the subscriptions POST, or false to omit.
     * @param boolean          $first_invoice_charges Whether the subscription's first invoice charges money, true by
     *                                                default. The fee percent and the fee metadata are stamped only
     *                                                when it does.
     *
     * @return stdClass The Stripe Subscription data.
     * @throws MeprGatewayException When the billing period type is unsupported.
     * @throws MeprHttpException If there was an HTTP error connecting to Stripe.
     * @throws MeprRemoteException If there was an invalid or error response from Stripe.
     */
    public function create_subscription(
        MeprTransaction $txn,
        MeprSubscription $sub,
        MeprProduct $prd,
        $customer_id,
        $payment_method_id = null,
        $default_incomplete = true,
        $trial_days = 0,
        ?float $min_payment = null,
        ?float $max_payment = null,
        $idempotency_key = false,
        bool $first_invoice_charges = true
    ) {
        $mepr_options = MeprOptions::fetch();

        // Bill the plan in the subscription's own currency (the cart records it; empty = primary, so
        // legacy subscriptions are unchanged). Per-currency price = the configured override or an
        // auto-conversion of the base price, via the same resolver the cart uses everywhere.
        $primary_currency = strtoupper($mepr_options->currency_code ?: 'USD');
        $sub_currency     = !empty($sub->currency) ? strtoupper($sub->currency) : $primary_currency;
        $base_price       = $sub_currency !== $primary_currency
            ? MeprCurrencyService::get_product_price($prd->ID, $sub_currency)
            : $prd->price;

        $price = MeprHooks::apply_filters('mepr_stripe_product_base_price', $base_price, $prd, $txn->user(), $sub);
        $price = MeprUtils::maybe_round_to_minimum_amount($price);

        $coupon = $sub->coupon();

        if ($coupon instanceof MeprCoupon) {
            // Fixed-amount coupons are stored in primary; apply in primary then convert back so we
            // don't subtract USD dollars from an AED price (same idea as compute_line_discount).
            if ($coupon->get_discount_type($prd) !== 'percent' && $sub_currency !== $primary_currency) {
                $primary_price     = MeprExchangeRateService::convert($price, $sub_currency, $primary_currency);
                $discounted_amount = MeprExchangeRateService::convert(
                    (float) $coupon->apply_discount($primary_price, false, $prd),
                    $primary_currency,
                    $sub_currency
                );
            } else {
                $discounted_amount = $coupon->apply_discount($price, false, $prd);
            }

            $minimum_amount = MeprUtils::get_minimum_amount();

            // If the coupon brings the subscription amount below the minimum charge amount, set the subscription amount to
            // the minimum charge amount and don't use a Stripe coupon.
            if ($minimum_amount && $discounted_amount < $minimum_amount) {
                $price  = $minimum_amount;
                $coupon = null;
            }
        }

        $item = ['price' => $this->get_stripe_price_id((float) $price, $prd, $sub)];

        if (!self::use_automatic_tax() && get_option('mepr_calculate_taxes') && $txn->tax_rate > 0 && $txn->tax_amount > 0) {
            $item = array_merge($item, [
                'tax_rates' => [$this->get_stripe_tax_rate_id($txn->tax_desc, $txn->tax_rate, $prd, $mepr_options->attr('tax_calc_type') === 'inclusive')],
            ]);
        }

        $args = [
            'customer'         => $customer_id,
            'items'            => [$item],
            'payment_settings' => [
                'payment_method_types'        => $this->get_subscription_payment_method_types($min_payment, $max_payment, $sub_currency),
                'save_default_payment_method' => 'on_subscription',
            ],
            'expand'           => [
                'latest_invoice.payment_intent',
            ],
            'metadata'         => [
                'platform'              => 'MemberPress Connect acct_1FIIDhKEEWtO8ZWC',
                'transaction_id'        => $txn->id,
                'site_url'              => get_site_url(),
                'ip_address'            => MeprAntiCardTestingCtrl::get_ip(),
                'memberpress_product'    => $prd->post_title,
                'memberpress_product_id' => $prd->ID,
            ],
        ];

        if (!empty($prd->post_title)) {
            $args['description'] = $prd->post_title;
        }

        if ($payment_method_id) {
            $args = array_merge($args, ['default_payment_method' => $payment_method_id]);
        }

        if ($default_incomplete) {
            $args = array_merge($args, [
                'payment_behavior' => 'default_incomplete',
            ]);
        }

        if ($trial_days > 0) {
            $args = array_merge($args, ['trial_period_days' => $trial_days]);
        }

        if ($coupon instanceof MeprCoupon) {
            // Pass plan currency only when the sub recorded one (cart); legacy empty → primary cache keys.
            $coupon_currency = !empty($sub->currency) ? $sub_currency : null;
            $discount_amount = $this->get_coupon_discount_amount($coupon, $prd, $coupon_currency);

            if ($discount_amount > 0) {
                $args = array_merge(['coupon' => $this->get_coupon_id($coupon, $discount_amount, false, $prd, $coupon_currency)], $args);
            }
        }

        if (self::use_automatic_tax()) {
            $args['automatic_tax'] = ['enabled' => 'true'];
        }

        $args = MeprHooks::apply_filters('mepr_stripe_subscription_args', $args, $txn, $sub);

        // Site E — on-site subscription path. application_fee_percent drives the
        // cycle-1 fee; cycle-2+ is set fresh by the invoice.created webhook
        // regardless. The caller states whether cycle 1 charges: the Elements
        // registration page queues pending invoice_items (paid-trial
        // trial_total, order-bump charges, or the first period when bumps
        // exist) that fold into the first invoice and make it positive even
        // on a "free trial." The cart and create_sub() run the first cycle as
        // a Stripe trial: the membership's own trial (a pure free trial
        // among them, which the SetupIntent webhook hands to create_sub())
        // or a first period already paid separately. Their first invoice is
        // $0, so fetching and stamping a fee there would be wasted.
        if ($first_invoice_charges) {
            $fee         = $this->fee_service()->fetch_fee($this->id);
            $fee_percent = $fee['percent'];
            if ($fee_percent > 0) {
                $args['application_fee_percent'] = $fee_percent;
                $args                            = self::merge_fee_metadata($args, $fee['metadata']);
            }
        }

        $this->email_status("create_subscription: \n" . MeprUtils::object_to_string($txn) . "\n", $this->settings->debug);

        $subscription = (object) $this->send_stripe_request(
            'subscriptions',
            $args,
            'post',
            'https://api.stripe.com/v1/',
            true,
            $idempotency_key
        );

        return $subscription;
    }

    /**
     * Get the discount amount for the given coupon
     *
     * @param  MeprCoupon  $coupon   The coupon being used.
     * @param  MeprProduct $product  The membership being purchased.
     * @param  string|null $currency ISO 4217 plan currency for fixed amount_off (null = primary / legacy).
     * @return string|integer           The formatted discount amount or 0 if no discount
     */
    public function get_coupon_discount_amount(MeprCoupon $coupon, MeprProduct $product, $currency = null)
    {
        $mepr_options     = MeprOptions::fetch();
        $primary_currency = strtoupper($mepr_options->currency_code ?: 'USD');
        $plan_currency    = !empty($currency) ? strtoupper($currency) : $primary_currency;
        $discount_amount  = $coupon->get_discount_amount($product);

        if ($discount_amount > 0) {
            if ($coupon->get_discount_type($product) === 'percent') {
                $discount_amount = MeprUtils::format_float($discount_amount);
            } else {
                // Fixed amounts are stored in primary; convert before zero-decimal for the plan currency.
                if ($plan_currency !== $primary_currency) {
                    $discount_amount = MeprExchangeRateService::convert(
                        (float) $discount_amount,
                        $primary_currency,
                        $plan_currency
                    );
                }

                // The coupon meta-key hash is byte-sensitive to the historical string form.
                $discount_amount = (string) $this->to_zero_decimal_amount($discount_amount, $plan_currency);
            }

            if ($discount_amount > 0) {
                return $discount_amount;
            }
        }

        return 0;
    }

    /**
     * Retrieve a Stripe Subscription
     *
     * @param  string $subscription_id The Stripe Subscription ID.
     * @return stdClass                             The Stripe Subscription data
     * @throws MeprHttpException                    If there was an HTTP error connecting to Stripe.
     * @throws MeprRemoteException                  If there was an invalid or error response from Stripe.
     */
    public function retrieve_subscription($subscription_id)
    {
        $args = MeprHooks::apply_filters('mepr_stripe_retrieve_subscription_args', [
            'expand' => [
                'latest_invoice',
                'default_payment_method',
            ],
        ]);

        return (object) $this->send_stripe_request('subscriptions/' . $subscription_id, $args, 'get');
    }

    /**
     * Retrieve a Stripe SetupIntent
     *
     * @param  string $setup_intent_id The Stripe SetupIntent ID.
     * @return stdClass                             The Stripe SetupIntent data
     * @throws MeprHttpException                    If there was an HTTP error connecting to Stripe.
     * @throws MeprRemoteException                  If there was an invalid or error response from Stripe.
     */
    public function retrieve_setup_intent($setup_intent_id)
    {
        return (object) $this->send_stripe_request("setup_intents/{$setup_intent_id}", ['expand' => ['payment_method']], 'get');
    }

    /**
     * Retrieve a Stripe PaymentIntent
     *
     * @param  string $payment_intent_id The Stripe PaymentIntent ID.
     * @return stdClass                               The Stripe PaymentIntent data
     * @throws MeprHttpException                      If there was an HTTP error connecting to Stripe.
     * @throws MeprRemoteException                    If there was an invalid or error response from Stripe.
     */
    public function retrieve_payment_intent($payment_intent_id)
    {
        return (object) $this->send_stripe_request('payment_intents/' . $payment_intent_id, [], 'get');
    }

    /**
     * Retrieve a Stripe Invoice
     *
     * @param  string $invoice_id The Stripe Invoice ID.
     * @return stdClass                        The Stripe Invoice data
     * @throws MeprHttpException               If there was an HTTP error connecting to Stripe.
     * @throws MeprRemoteException             If there was an invalid or error response from Stripe.
     */
    public function retrieve_invoice($invoice_id)
    {
        return (object) $this->send_stripe_request('invoices/' . $invoice_id, ['expand' => ['payment_intent']], 'get');
    }

    /**
     * Retrieve a Stripe Customer
     *
     * @param  string $customer_id The Stripe Customer ID.
     * @return stdClass                         The Stripe Customer data
     * @throws MeprHttpException                If there was an HTTP error connecting to Stripe.
     * @throws MeprRemoteException              If there was an invalid or error response from Stripe.
     */
    public function retrieve_customer($customer_id)
    {
        return (object) $this->send_stripe_request('customers/' . $customer_id, ['expand' => ['invoice_settings.default_payment_method']], 'get');
    }

    /**
     * Get the gateway ID for storing Stripe object IDs
     *
     * Object IDs in test mode do not exist in live mode, so we need to differentiate.
     *
     * @return string
     */
    public function get_meta_gateway_id()
    {
        $key = $this->id;

        if ($this->is_test_mode()) {
            $key .= '_test';
        }

        return $key;
    }

    /**
     * Is the currency a zero-decimal currency?
     *
     * Delegates to MeprCurrencyService::is_zero_decimal() which has the authoritative
     * Stripe-aligned list (HUF excluded -- treated as 2-decimal since 2024).
     *
     * @param  string|null $currency ISO 4217 currency code. Null assumes the site primary.
     * @return boolean
     */
    public static function is_zero_decimal_currency(?string $currency = null): bool
    {
        if ($currency === null) {
            _doing_it_wrong(
                __METHOD__,
                'Pass the currency being tested; omitting it assumes the site primary currency.',
                '1.12.18'
            );

            $currency = MeprOptions::fetch()->currency_code;
        }

        return MeprCurrencyService::is_zero_decimal($currency);
    }

    /**
     * Get the locale code
     *
     * Converts the configured MP language code into a Stripe-compatible locale code
     *
     * @see    https://stripe.com/docs/js/appendix/supported_locales
     * @return string
     */
    public static function get_locale_code()
    {
        $mepr_options = MeprOptions::fetch();
        $locale_code  = 'auto';

        $locales = [
            'US' => 'en',
            'AE' => 'ar',
            'AR' => 'es-419',
            'AU' => 'en',
            'BG' => 'bg',
            'BR' => 'pt-BR',
            'CH' => 'auto',
            'CN' => 'zh',
            'CO' => 'es-419',
            'CZ' => 'cs',
            'DE' => 'de',
            'DK' => 'da',
            'EN' => 'en',
            'ES' => 'es',
            'FI' => 'fi',
            'FR' => 'fr',
            'GB' => 'en-GB',
            'HE' => 'he',
            'HR' => 'hr',
            'HU' => 'hu',
            'ID' => 'id',
            'IS' => 'auto',
            'IT' => 'it',
            'JP' => 'ja',
            'KR' => 'ko',
            'MS' => 'en',
            'MX' => 'es-419',
            'NL' => 'nl',
            'NO' => 'nb',
            'PE' => 'es-419',
            'PH' => 'fil',
            'PL' => 'pl',
            'PT' => 'pt',
            'RO' => 'ro',
            'RU' => 'ru',
            'SE' => 'sv',
            'SK' => 'sk',
            'SR' => 'nl',
            'SW' => 'auto',
            'TH' => 'th',
            'TN' => 'ar',
            'TR' => 'tr',
            'TW' => 'zh-TW',
            'VI' => 'vi',
            'ZA' => 'auto',
        ];

        if (isset($locales[$mepr_options->language_code])) {
            $locale_code = $locales[$mepr_options->language_code];
        }

        return MeprHooks::apply_filters('mepr_stripe_locale_code', $locale_code);
    }

    /**
     * Returns the lazily-instantiated MeprStripeFeeService.
     *
     * The service is the single source of truth for the per-signup application
     * fee percent. It holds no per-call state and the underlying transient
     * cache is shared across instances, so a single static instance is fine.
     *
     * @return MeprStripeFeeService
     */
    protected function fee_service(): MeprStripeFeeService
    {
        static $service = null;

        if (null === $service) {
            $service = new MeprStripeFeeService();
        }

        return $service;
    }

    /**
     * Merges the fee metadata relayed from /fee into a Stripe request's metadata.
     *
     * The set is written on the object the fee is taken from: the top-level
     * metadata of a PaymentIntent or Subscription request, or the named
     * subscription_data / payment_intent_data branch of a Checkout Session.
     * It only extends a metadata array that already exists and never creates
     * one. A key the gateway already wrote keeps its value, and entries are
     * added only while the object stays within Stripe's 50-key limit.
     *
     * @param array                 $args         The Stripe request body.
     * @param array<string, string> $fee_metadata The relayed fee metadata.
     * @param string|null           $branch       The nested branch holding the metadata, or null for the top level.
     *
     * @return array
     */
    private static function merge_fee_metadata(array $args, array $fee_metadata, ?string $branch = null): array
    {
        if (empty($fee_metadata)) {
            return $args;
        }

        if (null === $branch) {
            if (is_array($args['metadata'] ?? null)) {
                $args['metadata'] = self::add_fee_metadata($args['metadata'], $fee_metadata);
            }
        } elseif (is_array($args[$branch]['metadata'] ?? null)) {
            $args[$branch]['metadata'] = self::add_fee_metadata($args[$branch]['metadata'], $fee_metadata);
        }

        return $args;
    }

    /**
     * Adds relayed fee metadata to a Stripe metadata array.
     *
     * Keys already present keep their values, and entries are added in the
     * server's order until the array holds STRIPE_METADATA_MAX_KEYS keys.
     *
     * @param array                 $metadata     The existing Stripe metadata.
     * @param array<string, string> $fee_metadata The relayed fee metadata.
     *
     * @return array
     */
    private static function add_fee_metadata(array $metadata, array $fee_metadata): array
    {
        foreach ($fee_metadata as $key => $value) {
            if (count($metadata) >= self::STRIPE_METADATA_MAX_KEYS) {
                break;
            }

            if (!array_key_exists($key, $metadata)) {
                $metadata[$key] = $value;
            }
        }

        return $metadata;
    }

    /**
     * Build an invoice item
     *
     * The transaction ID in the metadata keys the resulting invoice line back
     * to its component transaction when the webhook records the payment from
     * the invoice's own per-line amounts.
     *
     * @param  float           $amount      The amount to build the invoice item for.
     * @param  MeprTransaction $txn         The transaction object.
     * @param  MeprProduct     $prd         The product object.
     * @param  string          $customer_id The customer ID.
     * @return array
     * @throws MeprHttpException When HTTP request to Stripe API fails.
     * @throws MeprRemoteException When Stripe API returns an error response.
     */
    public function build_invoice_item($amount, MeprTransaction $txn, MeprProduct $prd, $customer_id)
    {
        $mepr_options = MeprOptions::fetch();

        $args = [
            'customer'     => $customer_id,
            'description'  => $prd->display_name(),
            'metadata'     => [
                'platform'       => 'MemberPress Connect acct_1FIIDhKEEWtO8ZWC',
                'site_url'       => get_site_url(),
                'ip_address'     => MeprAntiCardTestingCtrl::get_ip(),
                'transaction_id' => $txn->id,
            ],
            'discountable' => 'false',
        ];

        if (self::use_automatic_tax()) {
            // The line bills through the tax-coded Stripe Product with an
            // explicit behavior, so the charged line shares the tax inputs
            // the invoice-preview quote priced with; a bare amount would
            // tax under the account's dashboard defaults instead.
            $args['price_data'] = [
                'currency'     => $mepr_options->currency_code,
                'product'      => $this->get_product_id($prd),
                'unit_amount'  => $this->to_zero_decimal_amount($amount, $mepr_options->currency_code),
                'tax_behavior' => $mepr_options->attr('tax_calc_type') === 'inclusive' ? 'inclusive' : 'exclusive',
            ];
        } else {
            $args['amount']   = $this->to_zero_decimal_amount($amount, $mepr_options->currency_code);
            $args['currency'] = $mepr_options->currency_code;

            if (get_option('mepr_calculate_taxes') && $txn->tax_rate > 0 && $txn->tax_amount > 0) {
                $args['tax_rates'] = [$this->get_stripe_tax_rate_id($txn->tax_desc, $txn->tax_rate, $prd, $mepr_options->attr('tax_calc_type') === 'inclusive')];
            }
        }

        return $args;
    }

    /**
     * Build a line item for a checkout session
     *
     * @param string          $price The Stripe price ID.
     * @param MeprTransaction $txn   The transaction object.
     * @param MeprProduct     $prd   The product object.
     *
     * @return array
     * @throws MeprHttpException When HTTP request to Stripe API fails.
     * @throws MeprRemoteException When Stripe API returns an error response.
     */
    private function build_line_item($price, MeprTransaction $txn, MeprProduct $prd)
    {
        $mepr_options    = MeprOptions::fetch();
        $calculate_taxes = (bool) get_option('mepr_calculate_taxes');
        $tax_inclusive   = $mepr_options->attr('tax_calc_type') === 'inclusive';

        // The per-line tax recording maps each session line back to its
        // transaction by this id; without it the line can't be attributed and
        // copying falls back to a local derivation.
        $line_item = [
            'price'    => $price,
            'quantity' => 1,
            'metadata' => ['transaction_id' => (string) $txn->id],
        ];

        if (!self::use_automatic_tax() && $calculate_taxes && $txn->tax_rate > 0 && $txn->tax_amount > 0) {
            $line_item = array_merge($line_item, [
                'tax_rates' => [$this->get_stripe_tax_rate_id($txn->tax_desc, $txn->tax_rate, $prd, $tax_inclusive)],
            ]);
        }

        return $line_item;
    }

    /**
     * Handle the `payment_intent.payment_failed` webhook event
     *
     * For one-time payments, get the IP address from the PaymentIntent metadata, for subscriptions get it from the
     * Subscription metadata, then fire the hook for the card testing protection.
     *
     * @param stdClass $payment_intent The Stripe PaymentIntent data.
     *
     * @return void
     */
    public function handle_payment_intent_payment_failed_webhook($payment_intent)
    {
        $ip = isset($payment_intent->metadata['ip_address']) ? $payment_intent->metadata['ip_address'] : '';

        if (!empty($ip)) {
            MeprHooks::do_action('mepr_stripe_payment_failed', $ip);
        } else {
            try {
                $payment_intent = (object) $this->send_stripe_request("payment_intents/$payment_intent->id", [
                    'expand' => [
                        'invoice.subscription',
                    ],
                ], 'get');

                $subscription = isset($payment_intent->invoice['subscription']) ? (object) $payment_intent->invoice['subscription'] : null;

                if ($subscription) {
                      $ip = isset($subscription->metadata['ip_address']) ? $subscription->metadata['ip_address'] : '';

                    if (!empty($ip)) {
                        MeprHooks::do_action('mepr_stripe_payment_failed', $ip);
                    }
                }
            } catch (Exception $e) {
                // Ignore.
            }
        }
    }

    /**
     * Handle the `setup_intent.setup_failed` webhook event
     *
     * Get the IP address from the SetupIntent metadata, then fire the hook for the card testing protection.
     *
     * @param stdClass $setup_intent The Stripe SetupIntent data.
     *
     * @return void
     */
    public function handle_setup_intent_setup_failed_webhook($setup_intent)
    {
        $ip = isset($setup_intent->metadata['ip_address']) ? $setup_intent->metadata['ip_address'] : '';

        if (!empty($ip)) {
            MeprHooks::do_action('mepr_stripe_payment_failed', $ip);
        }
    }

    /**
     * Derive a subscription payment's transaction tax fields from the
     * invoice that charged it.
     *
     * The invoice records what Stripe actually charged, so the transaction
     * copies it instead of re-deriving the split from a fresh rate lookup —
     * which costs a webhook-time API call and can disagree with the invoice
     * after an address or rate change, a lookup failure, or a deactivated
     * integration. A reverse-charged invoice carries the would-be rate on
     * its zero-amount tax lines (tax_rate expanded), so the B2B
     * reverse-charge bookkeeping derives from the same lines the pricing
     * preview reads.
     *
     * Returns null when automatic tax is off — legacy tax rates are pinned
     * by MemberPress itself, so the derived fields already match the invoice;
     * only automatic tax charges amounts MemberPress didn't compute — or when
     * a taxed invoice lacks the expanded rate data needed for full fidelity,
     * leaving set_gross() to derive the fields instead.
     *
     * @param  stdClass $invoice The invoice with total_tax_amounts.tax_rate expanded.
     * @return array|null
     */
    private function invoice_amount_breakdown(stdClass $invoice): ?array
    {
        if (!self::use_automatic_tax() || !isset($invoice->total)) {
            return null;
        }

        $divisor = self::is_zero_decimal_currency(MeprOptions::fetch()->currency_code) ? 1 : 100;

        return $this->charged_amount_breakdown(
            (float) $invoice->total / $divisor,
            (float) ($invoice->tax ?? 0) / $divisor,
            is_array($invoice->total_tax_amounts ?? null) ? $invoice->total_tax_amounts : []
        );
    }

    /**
     * Derive a transaction's tax fields from a charged total, its tax, and
     * the tax lines that produced it.
     *
     * The shared derivation behind invoice- and Checkout-session-backed
     * recording: a taxed charge splits into net + tax with the rate and
     * labels from the parsed lines; a reverse-charged one books the would-be
     * rate, with the stripped VAT in the tax_reversal_amount fields only
     * under net-price removal; an untaxed one zeroes the tax fields.
     * Returns null when a taxed charge has no parseable rate, leaving
     * set_gross() to derive the fields instead.
     *
     * @param  float $total     The charged total.
     * @param  float $tax       The charged tax.
     * @param  array $tax_lines The tax lines in invoice `total_tax_amounts` shape.
     * @return array|null
     */
    private function charged_amount_breakdown(float $total, float $tax, array $tax_lines): ?array
    {
        $fields = MeprStripeTaxIntegration::line_tax_fields(
            MeprStripeTaxIntegration::reshape_invoice_tax_rows($tax_lines),
            $total
        );

        if ($tax > 0 && (float) $fields['rate'] === 0.0) {
            return null;
        }

        return [
            'amount'              => round($total - $tax, 2),
            'total'               => $total,
            'tax_amount'          => $tax,
            'tax_rate'            => $fields['rate'],
            'tax_desc'            => $fields['desc'],
            'tax_class'           => $fields['class'],
            'tax_reversal_amount' => $fields['removal'],
        ];
    }

    /**
     * Derive a transaction's tax fields from the Checkout session that
     * charged it.
     *
     * Under automatic tax the hosted page computes tax from the billing
     * address the customer enters THERE, so the charged totals can differ
     * from the preview-time fields on the transaction — the session is the
     * record of what was actually charged. Returns null when automatic tax
     * is off or the session lacks the totals.
     *
     * @param  stdClass $checkout_session The session with total_details.breakdown expanded.
     * @return array|null
     */
    private function session_amount_breakdown(stdClass $checkout_session): ?array
    {
        if (!self::use_automatic_tax() || !isset($checkout_session->amount_total)) {
            return null;
        }

        $divisor   = self::is_zero_decimal_currency(MeprOptions::fetch()->currency_code) ? 1 : 100;
        $tax_lines = [];

        foreach ((array) ($checkout_session->total_details['breakdown']['taxes'] ?? []) as $row) {
            $tax_lines[] = [
                'amount'            => $row['amount'] ?? 0,
                'taxability_reason' => $row['taxability_reason'] ?? '',
                'tax_rate'          => $row['rate'] ?? [],
            ];
        }

        return $this->charged_amount_breakdown(
            (float) $checkout_session->amount_total / $divisor,
            (float) ($checkout_session->total_details['amount_tax'] ?? 0) / $divisor,
            $tax_lines
        );
    }

    /**
     * Derive per-transaction tax fields from a Checkout session's line items.
     *
     * Each line carries the component transaction's ID in its metadata (see
     * build_line_item()). A line's charged totals map back to its
     * transaction by that ID, for every line type (recurring main, recurring
     * bump, one-time, free) and both payment and subscription mode.
     *
     * Each line's own per-line tax detail (line_items.data.taxes) labels its
     * rate, so an exempt or reverse-charged line reads its own rate, not the
     * order's blend. A line without expanded per-line taxes falls back to the
     * session's order-level breakdown.
     *
     * Returns an empty map (no copying) when automatic tax is off, when a
     * line can't be attributed to one of the order's transactions, or when
     * any line can't be derived at full fidelity, leaving set_gross() to
     * derive the fields.
     *
     * @param  stdClass          $checkout_session The session with line_items and total_details.breakdown expanded.
     * @param  MeprTransaction[] $transactions     The order's transactions.
     * @return array<int,array> Breakdowns keyed by transaction ID.
     */
    private function session_line_amount_breakdowns(stdClass $checkout_session, array $transactions): array
    {
        if (!self::use_automatic_tax()) {
            return [];
        }

        $lines = $checkout_session->line_items['data'] ?? null;

        if (!is_array($lines)) {
            return [];
        }

        $tax_lines = [];

        foreach ((array) ($checkout_session->total_details['breakdown']['taxes'] ?? []) as $row) {
            $tax_lines[] = [
                'amount'            => $row['amount'] ?? 0,
                'taxability_reason' => $row['taxability_reason'] ?? '',
                'tax_rate'          => $row['rate'] ?? [],
            ];
        }

        $txn_ids = array_map(static fn($transaction) => (int) $transaction->id, $transactions);
        $divisor = self::is_zero_decimal_currency(MeprOptions::fetch()->currency_code) ? 1 : 100;
        $groups  = [];

        // Group by transaction: one transaction can span several lines (a
        // trialing product's first-period charge line plus its $0 recurring
        // line), so sum them rather than letting one line overwrite another.
        foreach ($lines as $line) {
            $line   = (array) $line;
            $txn_id = (int) ($line['metadata']['transaction_id'] ?? 0);

            if (!in_array($txn_id, $txn_ids, true)) {
                return [];
            }

            if (!isset($groups[$txn_id])) {
                $groups[$txn_id] = [
                    'total'     => 0,
                    'tax'       => 0,
                    'tax_lines' => [],
                ];
            }

            $groups[$txn_id]['total'] += (int) ($line['amount_total'] ?? 0);
            $groups[$txn_id]['tax']   += (int) ($line['amount_tax'] ?? 0);

            // Label each line from its OWN per-line tax detail, so an exempt
            // or reverse-charged line reads its own rate rather than the
            // order's blended rate. A line without expanded taxes falls back
            // to the order-level rows below.
            foreach ((array) ($line['taxes'] ?? []) as $tax) {
                $tax                            = (array) $tax;
                $groups[$txn_id]['tax_lines'][] = [
                    'amount'            => (int) ($tax['amount'] ?? 0),
                    'taxability_reason' => (string) ($tax['taxability_reason'] ?? ''),
                    'tax_rate'          => $tax['rate'] ?? [],
                ];
            }
        }

        $breakdowns = [];

        foreach ($groups as $txn_id => $group) {
            $breakdown = $this->charged_amount_breakdown(
                (float) $group['total'] / $divisor,
                (float) $group['tax'] / $divisor,
                empty($group['tax_lines']) ? $tax_lines : $group['tax_lines']
            );

            if (!is_array($breakdown)) {
                return [];
            }

            $breakdowns[$txn_id] = $breakdown;
        }

        // Copy is all-or-nothing: if any transaction that charges at
        // purchase has no line to copy, disable copying for the whole
        // order so no line is derived locally while the rest are copied.
        // A free-trial subscription charges nothing at purchase, so its
        // missing line is legitimate.
        foreach ($transactions as $transaction) {
            if ($this->charges_at_purchase($transaction) && !isset($breakdowns[(int) $transaction->id])) {
                return [];
            }
        }

        return $breakdowns;
    }

    /**
     * Derive per-transaction tax fields from a subscription_create invoice's
     * lines.
     *
     * Checkout bills a mixed order's paid components as invoice items on the
     * subscription's first invoice, stamping each item with the component
     * transaction's ID in metadata. Grouping the lines by that ID keys each
     * line's charged amounts back to its transaction; a trialing
     * subscription's zero-amount line contributes nothing to its group. Line
     * tax rows reference their rates by ID, so the rate detail resolves from
     * the invoice's expanded total_tax_amounts. The lines are fetched from the
     * /lines endpoint when they are not already on the invoice, and a list
     * beyond one full page disables copying. Returns an empty map (no copying)
     * when automatic tax is off, any line lacks a known transaction ID, or any
     * group cannot be derived at full fidelity.
     *
     * This assumes an invoice-items-only first invoice, where every charged
     * line is an invoice item carrying its transaction_id. The Elements
     * builder guarantees this for a multi-charge order: a paid bump forces the
     * main into a trial and bills it as an invoice item too. A single-charge
     * order (a lone sub, or a sub whose only bumps are free) is reconciled
     * from the order-level split before this is reached, so a recurring line
     * the invoice does not tag per transaction never arrives here.
     *
     * @param  stdClass          $invoice      The invoice with total_tax_amounts.tax_rate expanded.
     * @param  MeprTransaction[] $transactions The order's transactions.
     * @return array<int,array> Breakdowns keyed by transaction ID.
     */
    private function invoice_line_amount_breakdowns(stdClass $invoice, array $transactions): array
    {
        if (!self::use_automatic_tax()) {
            return [];
        }

        $lines = is_array($invoice->lines ?? null) ? $invoice->lines : [];

        if (empty($lines['data']) || !empty($lines['has_more'])) {
            try {
                $lines = (array) $this->send_stripe_request("invoices/$invoice->id/lines", ['limit' => 100], 'get');
            } catch (MeprHttpException | MeprRemoteException $e) {
                return [];
            }
        }

        if (!empty($lines['has_more']) || !is_array($lines['data'] ?? null)) {
            return [];
        }

        // The expanded rate detail keyed by rate ID — the per-line tax rows
        // reference the same rates by ID string.
        $rates = [];

        foreach ((array) ($invoice->total_tax_amounts ?? []) as $total_row) {
            $rate = $total_row['tax_rate'] ?? null;

            if (is_array($rate) && isset($rate['id'])) {
                $rates[$rate['id']] = $rate;
            }
        }

        $txn_ids = array_map(static fn($transaction) => (int) $transaction->id, $transactions);
        $groups  = [];

        foreach ($lines['data'] as $line) {
            $line   = (array) $line;
            $txn_id = (int) ($line['metadata']['transaction_id'] ?? 0);

            if (!in_array($txn_id, $txn_ids, true)) {
                return [];
            }

            if (!isset($groups[$txn_id])) {
                $groups[$txn_id] = [
                    'total'     => 0,
                    'tax'       => 0,
                    'tax_lines' => [],
                ];
            }

            $total = (int) ($line['amount'] ?? 0);

            foreach ((array) ($line['discount_amounts'] ?? []) as $discount) {
                $total -= (int) ($discount['amount'] ?? 0);
            }

            foreach ((array) ($line['tax_amounts'] ?? []) as $row) {
                $amount   = (int) ($row['amount'] ?? 0);
                $rate_ref = is_array($row['tax_rate'] ?? null) ? ($row['tax_rate']['id'] ?? '') : (string) ($row['tax_rate'] ?? '');

                if (empty($row['inclusive'])) {
                    $total += $amount;
                }

                $groups[$txn_id]['tax']        += $amount;
                $groups[$txn_id]['tax_lines'][] = [
                    'amount'            => $amount,
                    'taxability_reason' => $row['taxability_reason'] ?? '',
                    'tax_rate'          => $rates[$rate_ref] ?? [],
                ];
            }

            $groups[$txn_id]['total'] += $total;
        }

        $divisor    = self::is_zero_decimal_currency(MeprOptions::fetch()->currency_code) ? 1 : 100;
        $breakdowns = [];

        foreach ($groups as $txn_id => $group) {
            $breakdown = $this->charged_amount_breakdown(
                (float) $group['total'] / $divisor,
                (float) $group['tax'] / $divisor,
                $group['tax_lines']
            );

            if (!is_array($breakdown)) {
                return [];
            }

            $breakdowns[$txn_id] = $breakdown;
        }

        return $breakdowns;
    }

    /**
     * Whether a transaction charges anything at purchase time.
     *
     * The all-or-nothing copy guards use this to decide which
     * transactions must have a charged line to copy. A paid product
     * whose subscription free-trials is payment-required (its renewals
     * charge), yet it charges nothing at purchase, so the first
     * invoice, session, or calculation legitimately carries no line
     * for it, and its absence must not disable copying for the rest of
     * the order.
     *
     * @param  MeprTransaction $transaction The order transaction.
     * @return boolean
     */
    private function charges_at_purchase(MeprTransaction $transaction): bool
    {
        if (!$transaction->is_payment_required()) {
            return false;
        }

        if ($transaction->is_one_time_payment()) {
            return true;
        }

        $subscription = $transaction->subscription();

        return !(
            $subscription instanceof MeprSubscription
            && $subscription->trial
            && $subscription->trial_days > 0
            && (float) $subscription->trial_total <= 0.00
        );
    }

    /**
     * Get the underlying charge ID from a PaymentIntent
     *
     * Since Stripe API version 2022-11-15 the property moved from 'charges' to 'latest_charge'.
     *
     * @param  stdClass $payment_intent The Stripe PaymentIntent data.
     * @return string|null
     */
    private function get_payment_intent_charge_id($payment_intent)
    {
        if (isset($payment_intent->latest_charge)) {
            return $payment_intent->latest_charge;
        }

        if (isset($payment_intent->charges['data'][0]['id'])) {
            return $payment_intent->charges['data'][0]['id'];
        }

        return null;
    }

    /**
     * Get the options to set on the Stripe Elements instance, depending on the product type
     *
     * @param  MeprProduct           $prd                 The product object.
     * @param  MeprTransaction       $txn                 The transaction object.
     * @param  MeprSubscription|null $sub                 The subscription object.
     * @param  string                $coupon_code         The coupon code.
     * @param  MeprProduct[]         $order_bump_products The order bump products.
     * @return array
     * @throws Exception When payment intent creation fails.
     */
    public function get_elements_options(MeprProduct $prd, MeprTransaction $txn, ?MeprSubscription $sub = null, $coupon_code = '', array $order_bump_products = [])
    {
        $currency      = MeprOptions::fetch()->currency_code;
        $quote_builder = new MeprOrderQuoteBuilder();

        if ($prd->is_one_time_payment() || !$prd->is_payment_required($coupon_code)) {
            $order_bumps        = MeprCheckoutCtrl::prepare_order_bumps($order_bump_products, $this->id, (int) $txn->user_id);
            $bump_subscriptions = array_filter(array_column($order_bumps, 1));
            $has_subscription   = !empty($bump_subscriptions);

            // A pricing filter can zero the adjusted price while a recurring
            // subscription exists, so any main subscription passed in has its
            // renewals counted here too.
            $renewals = $this->get_renewal_amounts($sub, $bump_subscriptions);

            // The Payment Element mounts with the quote's total: the
            // number the invoice renders and the PaymentIntent charges.
            $quote  = $quote_builder->build_preview_quote($txn, null, $order_bumps);
            $amount = $quote instanceof MeprOrderQuote ? (float) $quote->totals['total'] : 0.00;

            if ($amount > 0.00) {
                $store_payment_method            = MeprHooks::apply_filters('mepr_stripe_payment_intent_store_payment_method', $has_subscription, $txn, $prd);
                $setup_future_usage              = $store_payment_method ? 'off_session' : null;
                list($min_payment, $max_payment) = $this->payment_amount_range($amount, ...$renewals);

                $options = [
                    'mode'               => 'payment',
                    'amount'             => $this->to_zero_decimal_amount($amount, $currency),
                    'paymentMethodTypes' => $this->get_payment_intent_payment_method_types($setup_future_usage, $min_payment, $max_payment),
                    'setupFutureUsage'   => $setup_future_usage,
                ];
            } else {
                list($min_payment, $max_payment) = $this->payment_amount_range(...$renewals);

                $options = [
                    'mode'               => 'setup',
                    'paymentMethodTypes' => $this->get_setup_intent_payment_method_types($min_payment, $max_payment),
                ];
            }
        } else {
            if (!isset($sub) || !($sub instanceof MeprSubscription)) {
                throw new Exception(esc_html__('Subscription not found', 'memberpress'));
            }

            $order_bumps                 = MeprCheckoutCtrl::prepare_order_bumps($order_bump_products, $this->id, (int) $txn->user_id);
            $bump_subscriptions          = array_filter(array_column($order_bumps, 1));
            $has_subscription_order_bump = !empty($bump_subscriptions);

            // The Payment Element mounts with the quote's total: the
            // number the invoice renders and the order's first invoice
            // charges.
            $quote  = $quote_builder->build_preview_quote($txn, $sub, $order_bumps);
            $amount = $quote instanceof MeprOrderQuote ? (float) $quote->totals['total'] : 0.00;

            // Only include the Apple Pay MPAN config when the order has a single subscription.
            // Multiple subscriptions can't be represented in a single recurringPaymentRequest.
            $apple_pay_config = !$has_subscription_order_bump
                ? ['recurringPaymentRequest' => MeprApplePayHelper::get_recurring_payment_request($prd, $sub, $this->to_zero_decimal_amount((float) $sub->total, $currency))]
                : null;

            $renewals = $this->get_renewal_amounts($sub, $bump_subscriptions);

            if ($sub->trial && $sub->trial_days > 0 && (float) $sub->trial_total <= 0.00 && $amount <= 0.00) {
                list($min_payment, $max_payment) = $this->payment_amount_range(...$renewals);

                $options = [
                    'mode'               => 'setup',
                    'paymentMethodTypes' => $this->get_setup_intent_payment_method_types($min_payment, $max_payment),
                ];
            } else {
                list($min_payment, $max_payment) = $this->payment_amount_range($amount, ...$renewals);

                $options = [
                    'mode'               => 'subscription',
                    'amount'             => $this->to_zero_decimal_amount($amount, $currency),
                    'paymentMethodTypes' => $this->get_subscription_payment_method_types($min_payment, $max_payment),
                ];
            }

            if ($apple_pay_config) {
                $options['applePay'] = $apple_pay_config;
            }
        }

        return $options;
    }

    /**
     * Reject the checkout when the client's Payment Element state disagrees with the
     * intent the server is about to create.
     *
     * The Payment Element is configured from the render-time checkout state, and the
     * intent type is derived from the submit-time state. When they diverge (for example,
     * a free trial that no longer applies to the member), Stripe rejects the
     * confirmation with an obscure error, so instead reject the submission early;
     * the form then refreshes its checkout state, and the member re-confirms the
     * payment with the correct terms.
     *
     * The form reports the exact Elements options it last applied, and the whole
     * shape is compared (mode, amount, payment method types, setup_future_usage).
     * The `applePay` config is excluded: the client mutates it for the wallet sheet,
     * and Stripe does not validate it against the intent.
     *
     * @param MeprProduct           $prd         The product.
     * @param MeprTransaction       $txn         The transaction.
     * @param MeprSubscription|null $sub         The subscription.
     * @param string                $coupon_code The coupon code.
     */
    private function reject_stale_elements_context(MeprProduct $prd, MeprTransaction $txn, ?MeprSubscription $sub, string $coupon_code): void
    {
        // phpcs:disable WordPress.Security.NonceVerification.Missing

        /*
         * Not sanitized on purpose. The decoded value is only ever compared,
         * with ===, against a server-built array of ints and booleans, and is
         * never stored or output. Filtering it would cast every scalar to a
         * string and make that comparison always fail.
         */
        // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
        $client_context = isset($_POST['mepr_stripe_elements_context']) && is_string($_POST['mepr_stripe_elements_context']) ? json_decode(wp_unslash($_POST['mepr_stripe_elements_context']), true) : null;

        if (!is_array($client_context)) {
            // The form did not report its Elements configuration. Single page
            // checkout forms always report one, so note the likely stale bundle.
            if (isset($_POST['action']) && $_POST['action'] === 'mepr_process_signup_form') {
                MeprUtils::debug_log('[Stripe] No Elements context reported with the signup; skipping the staleness check.');
            }

            return;
        }

        try {
            $order_bump_product_ids = isset($_POST['mepr_order_bumps']) && is_array($_POST['mepr_order_bumps']) ? array_map('intval', $_POST['mepr_order_bumps']) : [];
            $order_bump_products    = MeprCheckoutCtrl::get_order_bump_products($prd->ID, $order_bump_product_ids);
            $server_context         = $this->get_elements_options($prd, $txn, $sub, $coupon_code, $order_bump_products);
        } catch (Exception $e) {
            // Invalid checkout state is reported by the payment processing itself.
            return;
        }
        // phpcs:enable WordPress.Security.NonceVerification.Missing

        unset($server_context['applePay']);

        // Neutralize key order, which can differ after the client-side JSON round trip,
        // and the payment method type order, which is display-only and can legitimately
        // vary when filters run in different request contexts.
        ksort($client_context);
        ksort($server_context);

        if (isset($client_context['paymentMethodTypes']) && is_array($client_context['paymentMethodTypes'])) {
            sort($client_context['paymentMethodTypes']);
        }

        if (isset($server_context['paymentMethodTypes']) && is_array($server_context['paymentMethodTypes'])) {
            sort($server_context['paymentMethodTypes']);
        }

        if ($client_context !== $server_context) {
            MeprUtils::debug_log(sprintf(
                '[Stripe] Rejected a stale Elements context. Client: %s. Server: %s.',
                wp_json_encode($client_context),
                wp_json_encode($server_context)
            ));

            wp_send_json_error(['checkout_state_changed' => true]);
        }
    }

    /**
     * Reject a submission whose mounted Elements amount no longer
     * matches the submit quote's total.
     *
     * The Payment Element mounts with the render quote's total, and the
     * submit quote prices the same state fresh. A mismatch therefore
     * means the pricing changed inside the preview window: a price, tax,
     * or product change the cached render quote cannot see. The
     * submission is rejected so the form refreshes its checkout state,
     * and the member re-confirms with the correct terms. The cached render
     * quote is dropped on the way out, so that refresh prices fresh and
     * mounts the total the next submission charges. An absent or
     * unparseable context passes through.
     *
     * @param MeprOrderQuote $quote The submit quote.
     */
    private function reject_stale_mounted_amount(MeprOrderQuote $quote): void
    {
        // phpcs:disable WordPress.Security.NonceVerification.Missing

        /*
         * Not sanitized on purpose. The decoded value is only ever compared,
         * with ===, against a server-built array of ints and booleans, and is
         * never stored or output. Filtering it would cast every scalar to a
         * string and make that comparison always fail.
         */
        // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
        $client_context = isset($_POST['mepr_stripe_elements_context']) && is_string($_POST['mepr_stripe_elements_context']) ? json_decode(wp_unslash($_POST['mepr_stripe_elements_context']), true) : null;
        // phpcs:enable WordPress.Security.NonceVerification.Missing

        if (!is_array($client_context) || !isset($client_context['amount'])) {
            return;
        }

        $total = $this->to_zero_decimal_amount((float) $quote->totals['total'], MeprOptions::fetch()->currency_code);

        if ((int) $client_context['amount'] !== $total) {
            MeprUtils::debug_log(sprintf(
                '[Stripe] Rejected a stale mounted amount. Mounted: %d. Submit quote: %d.',
                (int) $client_context['amount'],
                $total
            ));

            (new MeprOrderQuoteBuilder())->forget_preview_quote($quote);

            wp_send_json_error(['checkout_state_changed' => true]);
        }
    }

    /**
     * Is the given payment method type async?
     *
     * @param  string $type The payment method type.
     * @return boolean
     */
    private function is_async_payment_method($type)
    {
        $payment_methods = require MEPR_DATA_PATH . '/stripe_payment_methods.php';

        foreach ($payment_methods as $payment_method) {
            if ($payment_method['key'] === $type) {
                return isset($payment_method['async']) && $payment_method['async'];
            }
        }

        return false;
    }

    /**
     * For backwards compatibility, enable any payment methods by default that were previously enabled using old options or hooks
     *
     * @return string[]
     */
    private function get_default_payment_methods()
    {
        $mepr_options            = MeprOptions::fetch();
        $default_payment_methods = [];

        // If Link was enabled using the old option, add it by default.
        if (
            isset($this->settings->stripe_link_enabled) &&
            ($this->settings->stripe_link_enabled === 'on' || $this->settings->stripe_link_enabled === true) &&
            in_array($mepr_options->currency_code, ['EUR', 'BGN', 'HRK', 'CZK', 'DKK', 'GIP', 'HUF', 'NOK', 'PLN', 'RON', 'SEK', 'CHF', 'GBP', 'USD'], true)
        ) {
            $default_payment_methods = ['link'];
        }

        // Add payment methods from the old Stripe Checkout defaults and hooks.
        if (isset($this->settings->stripe_checkout_enabled) && $this->settings->stripe_checkout_enabled === 'on') {
            $default_checkout_recurring = $mepr_options->currency_code === 'EUR' ? ['sepa_debit'] : [];
            $default_checkout_recurring = MeprHooks::apply_filters('mepr_stripe_checkout_methods_for_recurring_payment', $default_checkout_recurring);
            $default_payment_methods    = array_merge($default_payment_methods, $default_checkout_recurring);

            $default_checkout_one_time = $mepr_options->currency_code === 'EUR' ? ['sepa_debit', 'ideal', 'bancontact', 'giropay'] : [];

            if ($mepr_options->currency_code === 'EUR' || $mepr_options->currency_code === 'PLN') {
                $default_checkout_one_time[] = 'p24';
            }

            $default_checkout_one_time = MeprHooks::apply_filters('mepr_stripe_checkout_methods_for_onetime_payment', $default_checkout_one_time);
            $default_payment_methods   = array_merge($default_payment_methods, $default_checkout_one_time);
        }

        return array_unique($default_payment_methods);
    }

    /**
     * Create an incomplete test payment to ensure that the given payment method types work
     *
     * @param  array $payment_method_types The payment method types to create a test payment for.
     * @return void
     * @throws MeprHttpException The HTTP exception.
     * @throws MeprRemoteException The remote exception.
     */
    public function create_test_payment_intent(array $payment_method_types)
    {
        $mepr_options   = MeprOptions::fetch();
        $minimum_amount = MeprUtils::get_minimum_amount();
        $amount         = $minimum_amount ? 2 * $minimum_amount : 10;

        array_unshift($payment_method_types, 'card');

        if ($mepr_options->currency_code === 'USD' && in_array('affirm', $payment_method_types, true)) {
            $amount = 50; // 50 USD is the minimum charge amount for Affirm
        }

        if ($mepr_options->currency_code === 'JPY' && in_array('konbini', $payment_method_types, true)) {
            $amount = 120; // 120 JPY is the minimum charge amount for Konbini
        }

        if ($mepr_options->currency_code === 'BRL' && in_array('boleto', $payment_method_types, true)) {
            $amount = 5; // 5 BRL is the minimum charge amount for Boleto
        }

        $amount = MeprHooks::apply_filters('mepr_stripe_test_payment_amount', $amount, $payment_method_types, $this);

        $args = [
            'amount'               => $this->to_zero_decimal_amount($amount, $mepr_options->currency_code),
            'currency'             => $mepr_options->currency_code,
            'payment_method_types' => $payment_method_types,
            'description'          => __('MemberPress Test Payment', 'memberpress'),
        ];

        $this->send_stripe_request('payment_intents', $args);
    }

    /**
     * Records CC Variables.
     *
     * @param object $sub            The subscription object.
     * @param mixed  $payment_method The payment method object.
     *
     * @return void
     */
    private function record_cc_vars($sub, $payment_method)
    {
        if ($sub instanceof MeprSubscription && isset($payment_method) && is_object($payment_method) && isset($payment_method->card) && is_array($payment_method->card)) {
            $sub->cc_last4     = $payment_method->card['last4'];
            $sub->cc_exp_month = $payment_method->card['exp_month'];
            $sub->cc_exp_year  = $payment_method->card['exp_year'];
        }
    }

    /**
     * Is the given ID a Charge object ID?
     *
     * A Charge object ID starts with either ch_ or py_.
     *
     * @param  string $id The ID to check.
     * @return boolean
     */
    private static function is_charge_object_id($id)
    {
        return strpos($id, 'ch_') === 0 || strpos($id, 'py_') === 0;
    }

    /**
     * Handle the `payment_method.automatically_updated` event.
     *
     * @param stdClass $payment_method The payment method object.
     * @param stdClass $previous       The previous payment method object.
     *
     * @return void
     */
    private function handle_payment_method_automatically_updated_event(stdClass $payment_method, stdClass $previous)
    {
        try {
            if (
                !empty($payment_method->customer) &&
                !empty($payment_method->card['last4']) &&
                !empty($previous->card['last4'])
            ) {
                global $wpdb;

                $list = (object) $this->send_stripe_request(
                    'subscriptions',
                    ['customer' => $payment_method->customer],
                    'get'
                );

                if (isset($list->data) && is_array($list->data)) {
                    $subscr_ids = array_column($list->data, 'id');
                } else {
                    return;
                }

                // For backwards compatibility, look for a cus_ subscription also.
                $subscr_ids[] = $payment_method->customer;
                $placeholders = array_fill(0, count($subscr_ids), '%s');
                $values       = array_merge(
                    $subscr_ids,
                    [
                        $this->id,
                        $previous->card['last4'],
                    ]
                );

                // phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber
                $sub_ids = $wpdb->get_col( // phpcs:ignore WordPress.DB.DirectDatabaseQuery
                    $wpdb->prepare(
                        "SELECT id FROM $wpdb->mepr_subscriptions WHERE subscr_id IN ("
                        . join(', ', $placeholders)
                        . ')
                        AND gateway = %s
                        AND cc_last4 = %s',
                        $values
                    )
                );
                // phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber

                foreach ($sub_ids as $sub_id) {
                    $sub = new MeprSubscription($sub_id);

                    if ($sub->id > 0) {
                        $this->record_cc_vars($sub, $payment_method);
                        $sub->store();
                    }
                }
            }
        } catch (Exception $e) {
            // Do nothing.
        }
    }

    // phpcs:disable Squiz.Commenting.FunctionCommentThrowTag.Missing
    /**
     * Process a payment via Ajax.
     *
     * @param MeprProduct           $prd The product.
     * @param MeprUser              $usr The user.
     * @param MeprTransaction       $txn The transaction.
     * @param MeprSubscription|null $sub The subscription (null for one-time payments).
     * @param MeprCoupon|null       $cpn The coupon (null if no coupon).
     */
    public function process_payment_ajax(
        MeprProduct $prd,
        MeprUser $usr,
        MeprTransaction $txn,
        ?MeprSubscription $sub = null,
        ?MeprCoupon $cpn = null
    ) {
        try {
            if ($this->settings->stripe_checkout_enabled === 'on') {
                wp_send_json_error(__('Bad request', 'memberpress'));
            }

            $mepr_options = MeprOptions::fetch();
            $coupon_code  = $cpn instanceof MeprCoupon ? $cpn->post_title : '';

            $this->reject_stale_elements_context($prd, $txn, $sub, $coupon_code);

            list($ob_transactions, $bump_charges, $has_subscription_order_bump, $bump_subscriptions) = $this->process_order_bumps($prd, $usr, $txn, $sub);

            // The charge taken now joins the renewals per branch below.
            $renewals = $this->get_renewal_amounts($sub, $bump_subscriptions);

            $customer_id = $usr->get_stripe_customer_id($this->get_meta_gateway_id());

            if (!is_string($customer_id) || strpos($customer_id, 'cus_') !== 0) {
                $customer_id = $this->get_customer_id($usr);
            } else {
                $this->update_customer($customer_id, $usr);
            }

            $action = 'confirmPayment';

            $thank_you_page_args = [
                'membership'     => sanitize_title($prd->post_title),
                'membership_id'  => $prd->ID,
                'transaction_id' => $txn->id,
            ];

            $quote_builder = new MeprOrderQuoteBuilder();

            if ($prd->is_one_time_payment() || !$prd->is_payment_required($coupon_code)) {
                // One fresh submit-stage quote prices the whole order: its
                // total is the charge, its calculation is the attachment
                // and filing source, and its lines land on the stored rows.
                // The builder prices through the transaction's own gateway,
                // so the calculation id belongs to the charging account.
                $quote = $quote_builder->price_order($txn, $sub, $ob_transactions);

                if ($quote instanceof MeprOrderQuote) {
                    $this->reject_stale_mounted_amount($quote);
                }

                $total = $quote instanceof MeprOrderQuote ? (float) $quote->totals['total'] : 0.00;

                if ($total > 0.00) {
                    $store_payment_method            = MeprHooks::apply_filters('mepr_stripe_payment_intent_store_payment_method', $has_subscription_order_bump, $txn, $prd);
                    $setup_future_usage              = $store_payment_method ? 'off_session' : null;
                    list($min_payment, $max_payment) = $this->payment_amount_range($total, ...$renewals);
                    $payment_intent                  = $this->create_payment_intent($total, $customer_id, $txn, $prd, $setup_future_usage, $quote, $min_payment, $max_payment);

                    $client_secret = $payment_intent->client_secret;

                    $txn->trans_num = $payment_intent->id;
                    $txn->store();
                } else {
                    list($min_payment, $max_payment) = $this->payment_amount_range(...$renewals);
                    $setup_intent                    = $this->create_setup_intent($customer_id, $txn, $prd, $min_payment, $max_payment);

                    $client_secret = $setup_intent->client_secret;

                    $txn->trans_num = $setup_intent->id;
                    $txn->store();

                    $action = 'confirmSetup';
                }
            } else {
                if (!$sub instanceof MeprSubscription) {
                    wp_send_json_error(__('Subscription not found', 'memberpress'));
                }

                $thank_you_page_args['subscription_id'] = $sub->id;

                $calculate_taxes = (bool) get_option('mepr_calculate_taxes');
                $tax_inclusive   = $mepr_options->attr('tax_calc_type') === 'inclusive';
                $invoice_items   = [];

                foreach ($ob_transactions as $transaction) {
                    $product = $transaction->product();

                    if (empty($product->ID)) {
                        wp_send_json_error(__('Product not found', 'memberpress'));
                    }

                    if (!$transaction->is_payment_required()) {
                        continue;
                    } elseif ($transaction->is_one_time_payment()) {
                        if ((float) $transaction->total > 0) {
                            $amount          = $calculate_taxes && !$tax_inclusive && $transaction->tax_rate > 0 ? (float) $transaction->amount : (float) $transaction->total;
                            $invoice_items[] = $this->build_invoice_item($amount, $transaction, $product, $customer_id);
                        }
                    } else {
                        $subscription = $transaction->subscription();

                        if (!($subscription instanceof MeprSubscription)) {
                            wp_send_json_error(__('Subscription not found', 'memberpress'));
                        }

                        if ($subscription->trial && $subscription->trial_days > 0) {
                            if ((float) $subscription->trial_total > 0) {
                                $amount          = $calculate_taxes && !$tax_inclusive && $transaction->tax_rate > 0 ? (float) $subscription->trial_amount : (float) $subscription->trial_total;
                                $invoice_items[] = $this->build_invoice_item($amount, $transaction, $product, $customer_id);
                            }
                        } else {
                            $amount          = $calculate_taxes && !$tax_inclusive && $transaction->tax_rate > 0 ? (float) $subscription->price : (float) $subscription->total;
                            $invoice_items[] = $this->build_invoice_item($amount, $transaction, $product, $customer_id);
                        }
                    }
                }

                // Use a SetupIntent for free trials, and create the subscription via webhook later.
                if ($sub->trial && $sub->trial_days > 0 && (float) $sub->trial_total <= 0.00 && empty($invoice_items)) {
                    list($min_payment, $max_payment) = $this->payment_amount_range(...$renewals);
                    $setup_intent                    = $this->create_setup_intent($customer_id, $txn, $prd, $min_payment, $max_payment);

                    $client_secret = $setup_intent->client_secret;

                    $txn->trans_num = $setup_intent->id;
                    $txn->store();

                    $action = 'confirmSetup';
                } else {
                    $trial_days = 0;

                    if ($sub->trial && $sub->trial_days > 0) {
                        $trial_days = $sub->trial_days;

                        if ((float) $sub->trial_total > 0.00) {
                            $amount = $calculate_taxes && !$tax_inclusive && $txn->tax_rate > 0 ? (float) $sub->trial_amount : (float) $sub->trial_total;
                            array_unshift($invoice_items, $this->build_invoice_item($amount, $txn, $prd, $customer_id));
                        }
                    } elseif (count($invoice_items)) {
                        // If there is no trial period and there is an order bump, set the trial days to cover one payment cycle and
                        // add the first subscription payment to the trial amount.
                        $trial_days = MeprUtils::days_in_period((int) $sub->period, (string) $sub->period_type, Time::now());

                        $amount = $calculate_taxes && !$tax_inclusive && $txn->tax_rate > 0 ? (float) $sub->price : (float) $sub->total;

                        array_unshift($invoice_items, $this->build_invoice_item($amount, $txn, $prd, $customer_id));
                    }

                    $invoice_item_ids = [];

                    foreach ($invoice_items as $invoice_item) {
                        $invoice_item       = (object) $this->send_stripe_request('invoiceitems', $invoice_item, 'post');
                        $invoice_item_ids[] = $invoice_item->id;
                    }

                    try {
                        // A free trial with nothing queued took the SetupIntent
                        // branch above, so the first invoice charges either the
                        // first period or the queued invoice items.
                        $first_invoice                   = (float) $txn->total + $bump_charges;
                        list($min_payment, $max_payment) = $this->payment_amount_range($first_invoice, ...$renewals);
                        $subscription                    = $this->create_subscription($txn, $sub, $prd, $customer_id, null, true, $trial_days, $min_payment, $max_payment);

                        if (empty($subscription->latest_invoice['payment_intent']['client_secret'])) {
                            throw new MeprGatewayException(__('PaymentIntent not found', 'memberpress'));
                        }

                        $client_secret = $subscription->latest_invoice['payment_intent']['client_secret'];

                        $sub->subscr_id = $subscription->id;
                        $sub->store();

                        $txn->trans_num = $subscription->latest_invoice['id'];
                        $txn->store();

                        // The submit quote's lines land on the stored rows,
                        // so the first period's figures are booked from
                        // birth and the recording reads them back from the
                        // stamp. The subscription and its first invoice
                        // already exist here, so a pricing failure logs and
                        // leaves the prepared figures on the rows rather
                        // than aborting the created subscription; recording
                        // then books those prepared figures, uncorrected.
                        try {
                            $quote_builder->price_order($txn, $sub, $ob_transactions);
                        } catch (Exception $quote_error) {
                            MeprUtils::debug_log('stripe-tax-quote-failed: first-invoice rows keep their prepared figures: ' . $quote_error->getMessage());
                        }
                    } catch (Exception $e) {
                        // Delete any created invoice items if the subscription failed to be created.
                        foreach ($invoice_item_ids as $invoice_item_id) {
                            try {
                                $this->send_stripe_request("invoiceitems/$invoice_item_id", [], 'delete');
                            } catch (Exception $f) {
                                // Ignore any exception here, throw the original.
                            }
                        }

                        throw $e;
                    }
                }
            }

            MeprHooks::do_action('mepr_stripe_payment_pending', $txn, $usr);

            $return_url = add_query_arg(
                [
                    'txn_id'      => $txn->id,
                    'redirect_to' => urlencode($mepr_options->thankyou_page_url($thank_you_page_args)),
                ],
                $this->notify_url('return')
            );

            wp_send_json_success([
                'action'        => $action,
                'client_secret' => $client_secret,
                'return_url'    => $return_url,
            ]);
        } catch (Exception $e) {
            wp_send_json_error($e->getMessage());
        }
    }
    // phpcs:enable Squiz.Commenting.FunctionCommentThrowTag.Missing

    /**
     * Is this gateway configured to support Ajax processing?
     *
     * @return boolean
     */
    public function validate_ajax_gateway(): bool
    {
        return $this->settings->stripe_checkout_enabled !== 'on';
    }

    /**
     * Updates the metadata for a charge using the provided transaction object.
     *
     * This method performs the update asynchronously by enqueuing a job to update
     * the charge metadata in the Stripe gateway.
     *
     * @param MeprTransaction $txn The transaction object containing the details
     * of the transaction, including the charge ID.
     *
     * @return void
     */
    public function update_charge_metadata(MeprTransaction $txn)
    {
        if (self::is_charge_object_id($txn->trans_num)) {
            // Update Stripe Metadata Asynchronously.
            $job                   = new MeprUpdateStripeMetadataJob();
            $job->gateway_settings = $this->settings;
            $job->transaction_id   = $txn->id;
            $job->enqueue();
        }
    }

    /**
     * Get the account country for the given payment method ID
     *
     * @param  string  $pm_id        The payment method ID.
     * @param  boolean $bypass_cache Whether to bypass cached country and fetch fresh data.
     * @return string|false  The account country or false if not found
     */
    public static function get_account_country($pm_id, $bypass_cache = false)
    {
        if (false === $pm_id) {
            return false;
        }

        // Force refresh options and payment methods when bypassing cache to ensure we have latest credentials.
        $mepr_options = MeprOptions::fetch($bypass_cache);
        $pm           = $mepr_options->payment_method($pm_id, true, $bypass_cache);

        if (false === $pm) {
            return false;
        }

        // Check if country is already stored unless bypassing cache.
        if (!$bypass_cache && isset($pm->settings->country) && !empty($pm->settings->country)) {
            return $pm->settings->country;
        }

        // Make API call to fetch current country data.
        $account_country = false;
        try {
            $account_details = $pm->send_stripe_request('account', [], 'get');
            $account_country = $account_details['country'] ?? false;

            // Store the country for future use.
            if ($account_country !== false) {
                $mepr_options->integrations[$pm_id]['country'] = $account_country;
                $mepr_options->store(false);
            }
        } catch (Exception $e) {
            // Do nothing.
        }

        return $account_country;
    }

    /**
     * Create and confirm a Stripe PaymentIntent off-session using a stored payment method.
     * Used for upsell/downsell charges after checkout.
     *
     * @param  integer             $amount_cents  Amount to charge in smallest currency unit.
     * @param  string              $pm_token      Stripe payment_method ID (pm_xxx) from MeprSavedPaymentMethod.
     * @param  string              $customer_id   Stripe customer ID (cus_xxx).
     * @param  string              $description   Charge description (product name).
     * @param  array               $metadata      Additional Stripe metadata key-value pairs.
     * @param  string              $currency_code Currency code for the charge, or empty for the site default.
     * @param  MeprOrderQuote|null $quote         Optional submit quote (tax calc attach + L2/L3).
     * @return object  PaymentIntent object with at minimum: id, status, client_secret.
     * @throws Exception On Stripe API error.
     */
    public function charge_off_session(
        int $amount_cents,
        string $pm_token,
        string $customer_id,
        string $description,
        array $metadata = [],
        string $currency_code = '',
        $quote = null
    ): object {
        $options  = MeprOptions::fetch();
        $currency = !empty($currency_code) ? strtolower($currency_code) : strtolower($options->currency_code ?? 'usd');

        $args = [
            'amount'                   => $amount_cents,
            'currency'                 => $currency,
            'customer'                 => $customer_id,
            'payment_method'           => $pm_token,
            'confirm'                  => 'true',
            'off_session'              => 'true',
            'description'              => $description,
            'metadata'                 => $metadata,
            'error_on_requires_action' => 'false', // Let requires_action status bubble up (not throw).
        ];

        if ($quote instanceof MeprOrderQuote) {
            $args     = $this->add_payment_intent_tax_calculation($args, $quote);
            $line_txn = new MeprTransaction();
            $line_txn->user_id  = isset($metadata['user_id']) ? (int) $metadata['user_id'] : 0;
            $line_txn->order_id = isset($metadata['order_id']) ? (int) $metadata['order_id'] : 0;
            $args               = $this->add_payment_intent_line_items($args, $line_txn, $quote, strtoupper($currency));
        }

        $result = $this->send_stripe_request('payment_intents', $args, 'post');
        return json_decode(wp_json_encode($result));
    }

    /**
     * Get the meta key for a Stripe Price ID.
     *
     * @param  MeprProduct $prd            The MemberPress product.
     * @param  integer     $amount         The zero-decimal payment amount (excluding tax).
     * @param  boolean     $force_one_time Whether to key a one-time price for the amount.
     * @param  string|null $currency       ISO 4217 currency for the price (null = site primary).
     * @return string
     */
    private function price_id_meta_key(
        MeprProduct $prd,
        int $amount,
        bool $force_one_time = false,
        ?string $currency = null
    ): string {
        return '_mepr_stripe_price_id_' . $this->get_meta_gateway_id()
            . '_' . $this->terms_hash($prd, $amount, $force_one_time, $currency);
    }

    /**
     * Get the legacy meta key for a Stripe Plan ID.
     *
     * Reproduces the released key shape — terms_hash() without product_id
     * or tax_behavior — so the lazy fix-up in get_stripe_price_id() can
     * still locate post_meta rows written under it.
     *
     * @param  MeprProduct $prd      The MemberPress product.
     * @param  string      $amount   The zero-decimal payment amount (excluding tax).
     * @param  string|null $currency ISO 4217 currency for the price (null = site primary).
     * @return string
     */
    private function legacy_plan_id_meta_key(MeprProduct $prd, string $amount, ?string $currency = null): string
    {
        return '_mepr_stripe_plan_id_' . $this->get_meta_gateway_id()
            . '_' . $this->legacy_terms_hash($prd, $amount, $currency);
    }

    /**
     * Get the meta key for a Stripe Product ID.
     *
     * Includes the post ID so that duplicating a membership post results in a
     * distinct meta key, preventing two memberships from sharing a Stripe Product.
     *
     * When automatic tax is on the Stripe Product carries a tax_behavior and a
     * tax_code, so both are folded into the key (`_{inclusive|exclusive}` and,
     * when set, `_{tax_code}`). Changing either resolves a new key and therefore
     * a new Stripe Product, leaving the Product that existing subscriptions
     * depend on untouched. With automatic tax off the key is unchanged.
     *
     * @param  MeprProduct $prd             The MemberPress product.
     * @param  boolean     $initial_payment Whether the product is for an initial payment.
     * @return string
     */
    private function product_meta_key(MeprProduct $prd, bool $initial_payment): string
    {
        if ($initial_payment) {
            $key = '_mepr_stripe_initial_payment_product_id_' . $this->get_meta_gateway_id() . '_' . $prd->ID;
        } else {
            $key = '_mepr_stripe_product_id_' . $this->get_meta_gateway_id() . '_' . $prd->ID;
        }

        if (self::use_automatic_tax()) {
            $behavior = MeprOptions::fetch()->attr('tax_calc_type') === 'inclusive' ? 'inclusive' : 'exclusive';
            $key     .= '_' . $behavior;

            $tax_code = MeprStripeTaxIntegration::get_product_tax_code($prd->ID);
            if ($tax_code !== '') {
                $key .= '_' . $tax_code;
            }
        }

        return $key;
    }

    /**
     * Get the legacy meta key for a Stripe Product ID (without post-ID suffix).
     *
     * Used by the lazy-migration path in get_product_id() to locate and
     * re-index post_meta rows written under the pre-post-id key shape.
     *
     * @param  boolean $initial_payment Whether the product is for an initial payment.
     * @return string
     */
    private function legacy_product_meta_key(bool $initial_payment): string
    {
        if ($initial_payment) {
            return '_mepr_stripe_initial_payment_product_id_' . $this->get_meta_gateway_id();
        }

        return '_mepr_stripe_product_id_' . $this->get_meta_gateway_id();
    }

    /**
     * The currency a price key hashes under.
     *
     * A null or primary currency answers the primary code verbatim, so keys
     * written before per-currency pricing stay byte-identical; anything else
     * answers the upper-cased code and keys a price of its own.
     *
     * @param  string|null $currency ISO 4217 currency, or null for the site primary.
     * @return string
     */
    private function hashed_currency(?string $currency): string
    {
        $primary_currency = MeprOptions::fetch()->currency_code;

        return ($currency === null || strtoupper($currency) === strtoupper($primary_currency))
            ? $primary_currency
            : strtoupper($currency);
    }

    /**
     * Get the hash of the payment terms for a product.
     *
     * Always includes `product_id` so hashes are scoped per-product and always
     * differ from the legacy hash. When Stripe Automatic Tax is enabled,
     * `tax_behavior` (normalized to 'inclusive' or 'exclusive' from the
     * `mepr_tax_calc_type` option) and the product's resolved tax code are
     * also folded in, mirroring {@see self::product_meta_key()}, so a
     * tax-type flip or a tax-code change forces a new Stripe Price on the
     * matching Stripe Product. A code-less product hashes without the key,
     * keeping its existing stored Price valid.
     *
     * {@see self::legacy_terms_hash()} remains intact for the lazy fix-up
     * path in `get_stripe_price_id()`.
     *
     * @param  MeprProduct $prd            The MemberPress product.
     * @param  integer     $amount         The zero-decimal payment amount.
     * @param  boolean     $force_one_time Whether to key a one-time price for the amount,
     *                                     distinct from the product's recurring terms.
     * @param  string|null $currency       ISO 4217 currency for the price (null = site primary).
     * @return string
     */
    private function terms_hash(
        MeprProduct $prd,
        int $amount,
        bool $force_one_time = false,
        ?string $currency = null
    ): string {
        $mepr_options = MeprOptions::fetch();

        $terms = [
            'currency'    => $this->hashed_currency($currency),
            'amount'      => $amount,
            'period'      => $prd->period,
            'period_type' => $prd->period_type,
            'product_id'  => $prd->ID,
        ];

        // Only a recurring product needs the marker to carve a one-time key
        // distinct from its recurring one; a genuine one-time product already
        // keys the same with or without the force, so it stays shareable.
        if ($force_one_time && !$prd->is_one_time_payment()) {
            $terms['one_time'] = true;
        }

        if (self::use_automatic_tax()) {
            $terms['tax_behavior'] = $mepr_options->attr('tax_calc_type') === 'inclusive' ? 'inclusive' : 'exclusive';

            $tax_code = MeprStripeTaxIntegration::get_product_tax_code($prd->ID);
            if ($tax_code !== '') {
                $terms['tax_code'] = $tax_code;
            }
        }

        return md5(serialize($terms));
    }

    /**
     * Compute the legacy hash of the payment terms for a product.
     *
     * The serialize order (currency, amount, period, period_type) is locked.
     * It must reproduce byte-for-byte the hash computed from currency, amount,
     * period, and period_type alone — without product_id or tax_behavior — so
     * the lazy-migration path can still locate post_meta rows written under the
     * legacy meta-key shape.
     *
     * @param  MeprProduct $prd      The MemberPress product.
     * @param  string      $amount   The zero-decimal payment amount.
     * @param  string|null $currency ISO 4217 currency for the price (null = site primary).
     * @return string
     */
    private function legacy_terms_hash(MeprProduct $prd, string $amount, ?string $currency = null): string
    {
        $terms = [
            'currency'    => $this->hashed_currency($currency),
            'amount'      => $amount,
            'period'      => $prd->period,
            'period_type' => $prd->period_type,
        ];

        return md5(serialize($terms));
    }

    /**
     * Determine whether Stripe should compute tax automatically for this gateway.
     *
     * New Stripe subscriptions, checkouts, and invoices use Stripe's native
     * automatic_tax whenever tax calculations and site-level Stripe Tax are
     * both enabled. There is no per-gateway opt-out.
     *
     * @return boolean
     */
    public static function use_automatic_tax(): bool
    {
        return get_option('mepr_calculate_taxes') && get_option('mepr_tax_stripe_enabled');
    }

    /**
     * Get the stored Stripe Price ID for a product's current payment terms.
     *
     * The deprecated mepr_product_get_stripe_plan_id filter still runs over
     * the stored value (no replacement hook exists). Values without a
     * price_/plan_ prefix are treated as missing.
     *
     * @param  MeprProduct $prd            The MemberPress product.
     * @param  integer     $amount         The zero-decimal payment amount (excluding tax).
     * @param  boolean     $force_one_time Whether to read the one-time price key for the amount.
     * @param  string|null $currency       ISO 4217 currency for the price (null = site primary).
     * @return string|null
     */
    public function get_stored_price_id(
        MeprProduct $prd,
        int $amount,
        bool $force_one_time = false,
        ?string $currency = null
    ): ?string {
        $price_id = get_post_meta($prd->ID, $this->price_id_meta_key($prd, $amount, $force_one_time, $currency), true);
        $price_id = apply_filters_deprecated(
            'mepr_product_get_stripe_plan_id',
            [$price_id, $prd, $this->get_meta_gateway_id(), (string) $amount],
            '1.12.18'
        );

        return $this->is_stripe_price_id($price_id) ? $price_id : null;
    }

    /**
     * Store the Stripe Price ID for a product's current payment terms.
     *
     * @param MeprProduct $prd            The MemberPress product.
     * @param integer     $amount         The zero-decimal payment amount (excluding tax).
     * @param string      $price_id       The Stripe Price ID.
     * @param boolean     $force_one_time Whether to store under the one-time price key.
     * @param string|null $currency       ISO 4217 currency for the price (null = site primary).
     */
    public function set_stored_price_id(
        MeprProduct $prd,
        int $amount,
        string $price_id,
        bool $force_one_time = false,
        ?string $currency = null
    ): void {
        update_post_meta($prd->ID, $this->price_id_meta_key($prd, $amount, $force_one_time, $currency), $price_id);
    }

    /**
     * Get the stored Stripe Product ID for a product.
     *
     * @param  MeprProduct $prd             The MemberPress product.
     * @param  boolean     $initial_payment Whether the product is for an initial payment.
     * @return string|false
     */
    public function get_stored_product_id(MeprProduct $prd, bool $initial_payment = false)
    {
        return get_post_meta($prd->ID, $this->product_meta_key($prd, $initial_payment), true);
    }

    /**
     * Store the Stripe Product ID for a product.
     *
     * @param MeprProduct $prd             The MemberPress product.
     * @param string      $product_id      The Stripe Product ID.
     * @param boolean     $initial_payment Whether the product is for an initial payment.
     */
    public function set_stored_product_id(MeprProduct $prd, $product_id, bool $initial_payment = false): void
    {
        update_post_meta($prd->ID, $this->product_meta_key($prd, $initial_payment), $product_id);
    }

    /**
     * Delete all stored Stripe Product ID entries matching the given product ID.
     *
     * @param string $product_id The Stripe Product ID.
     */
    public function delete_stored_product_id($product_id): void
    {
        if (!is_string($product_id) || $product_id === '') {
            return;
        }

        global $wpdb;

        // Product IDs are stored under per-post suffixed keys for both the regular
        // and initial-payment products, so match the value across both prefixes.
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery
        $meta_ids = $wpdb->get_col($wpdb->prepare(
            "SELECT meta_id FROM {$wpdb->postmeta} WHERE meta_value = %s AND (meta_key LIKE %s OR meta_key LIKE %s)",
            $product_id,
            $wpdb->esc_like('_mepr_stripe_product_id_' . $this->get_meta_gateway_id()) . '%',
            $wpdb->esc_like('_mepr_stripe_initial_payment_product_id_' . $this->get_meta_gateway_id()) . '%'
        ));

        if (is_array($meta_ids) && count($meta_ids)) {
            foreach ($meta_ids as $meta_id) {
                delete_metadata_by_mid('post', $meta_id);
            }
        }
    }

    /**
     * Delete every stored coupon reference pointing at the given Stripe ID.
     *
     * Covers both key shapes, the recurring coupon key and the one-time
     * coupon key. Matching is by value, so only rows referencing the deleted
     * Stripe object are removed.
     *
     * The gateway owns this cleanup because it must happen in every build. A
     * deleted Stripe coupon can never be charged against again, so a stored
     * reference to it makes the next checkout that resolves the coupon fail
     * against Stripe; the coupons module's own webhook listener is part of
     * the strip manifest, so in a stripped build nothing else clears it. This
     * touches only post meta and never the coupon model, so it survives the
     * aggressive strip tier as well.
     *
     * @param string $coupon_id The Stripe Coupon ID.
     */
    public function delete_stored_coupon_id($coupon_id): void
    {
        if (!is_string($coupon_id) || $coupon_id === '') {
            return;
        }

        global $wpdb;

        $prefixes = [
            '_mepr_stripe_coupon_id_' . $this->get_meta_gateway_id(),
            '_mepr_stripe_onetime_coupon_id_' . $this->get_meta_gateway_id(),
        ];

        foreach ($prefixes as $prefix) {
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery
            $meta_ids = $wpdb->get_col($wpdb->prepare(
                "SELECT meta_id FROM {$wpdb->postmeta} WHERE meta_key LIKE %s AND meta_value = %s",
                $wpdb->esc_like($prefix) . '%',
                $coupon_id
            ));

            if (is_array($meta_ids) && count($meta_ids)) {
                foreach ($meta_ids as $meta_id) {
                    delete_metadata_by_mid('post', $meta_id);
                }
            }
        }
    }

    /**
     * Delete every stored price reference pointing at the given Stripe ID.
     *
     * Covers the current price key plus both released legacy shapes (the
     * recurring plan key and the one-time price key). Matching is by
     * value, so only rows referencing the deleted Stripe object are
     * removed.
     *
     * @param string $price_id The Stripe Price (or legacy Plan) ID.
     */
    public function delete_stored_price_id($price_id): void
    {
        if (!is_string($price_id) || $price_id === '') {
            return;
        }

        global $wpdb;

        $prefixes = [
            '_mepr_stripe_price_id_' . $this->get_meta_gateway_id(),
            '_mepr_stripe_plan_id_' . $this->get_meta_gateway_id(),
            '_mepr_stripe_onetime_price_id_',
        ];

        foreach ($prefixes as $prefix) {
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery
            $meta_ids = $wpdb->get_col($wpdb->prepare(
                "SELECT meta_id FROM {$wpdb->postmeta} WHERE meta_key LIKE %s AND meta_value = %s",
                $wpdb->esc_like($prefix) . '%',
                $price_id
            ));

            if (is_array($meta_ids) && count($meta_ids)) {
                foreach ($meta_ids as $meta_id) {
                    delete_metadata_by_mid('post', $meta_id);
                }
            }
        }
    }
}
