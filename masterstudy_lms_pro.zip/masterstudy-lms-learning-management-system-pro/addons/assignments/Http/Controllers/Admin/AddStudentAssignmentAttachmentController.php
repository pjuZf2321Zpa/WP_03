<?php

namespace MasterStudy\Lms\Pro\addons\assignments\Http\Controllers\Admin;

use MasterStudy\Lms\Http\WpResponseFactory;
use MasterStudy\Lms\Plugin\PostType;
use MasterStudy\Lms\Pro\addons\assignments\Repositories\AssignmentAttachmentRepository;
use MasterStudy\Lms\Validation\Validator;
use WP_REST_Request;
use WP_REST_Response;

final class AddStudentAssignmentAttachmentController {
	public function __invoke( int $student_assignment_id, WP_REST_Request $request ): WP_REST_Response {
		if ( $student_assignment_id <= 0 || PostType::USER_ASSIGNMENT !== get_post_type( $student_assignment_id ) ) {
			return WpResponseFactory::not_found();
		}

		$validator = new Validator(
			$request->get_params(),
			array(
				'attachment_id' => 'required|integer',
				'is_created'    => 'nullable|boolean',
			)
		);

		if ( $validator->fails() ) {
			return WpResponseFactory::validation_failed( $validator->get_errors_array() );
		}

		$data       = $validator->get_validated();
		$repository = new AssignmentAttachmentRepository();

		$result = $repository->add_instructor_attachment(
			$student_assignment_id,
			absint( $data['attachment_id'] ),
			rest_sanitize_boolean( $data['is_created'] ?? false )
		);

		if ( is_wp_error( $result ) ) {
			return WpResponseFactory::bad_request( $result->get_error_message() );
		}

		return WpResponseFactory::ok_with_data( $result );
	}
}
