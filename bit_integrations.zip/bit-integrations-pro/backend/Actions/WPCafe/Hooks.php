<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Actions\WPCafe\WPCafeProHelper;
use BitApps\IntegrationsPro\Config;
use BitApps\IntegrationsPro\Core\Util\Hooks;

// Deprecated since v2.7.8 - use bit_integrations_wpcafe_* hooks instead
if (bit_integrations_version_below('2.7.8')) {
    Hooks::filter('btcbi_wpcafe_create_reservation', [WPCafeProHelper::class, 'createReservation'], 10, 2);
    Hooks::filter('btcbi_wpcafe_update_reservation', [WPCafeProHelper::class, 'updateReservation'], 10, 2);
    Hooks::filter('btcbi_wpcafe_delete_reservation', [WPCafeProHelper::class, 'deleteReservation'], 10, 2);
}

// New hooks since v2.7.8
Hooks::filter(Config::withFreePrefix('wpcafe_create_reservation'), [WPCafeProHelper::class, 'createReservation'], 10, 2);
Hooks::filter(Config::withFreePrefix('wpcafe_update_reservation'), [WPCafeProHelper::class, 'updateReservation'], 10, 2);
Hooks::filter(Config::withFreePrefix('wpcafe_delete_reservation'), [WPCafeProHelper::class, 'deleteReservation'], 10, 2);
