<?php

/**
 * Admin order notes partial — used inside #mepr-order-notes postbox.
 *
 * Variables available:
 *   $notes (array)      — array of note arrays [{message, type, user_id, created_at}]
 *   $order (MeprOrder)  — the order being viewed
 */

if (!defined('ABSPATH')) {
    die('You are not allowed to call this page directly.');
}
?>

<h2 class="hndle"><span><?php esc_html_e('Order Notes', 'memberpress'); ?></span></h2>
<div class="inside">

    <?php // ——— Add note form ———. ?>
    <div class="mepr-notes-add-form">
        <textarea
            id="mepr-note-message"
            class="mepr-note-textarea"
            rows="3"
            placeholder="<?php esc_attr_e('Add a note…', 'memberpress'); ?>"
        ></textarea>
        <div class="mepr-notes-add-row">
            <select id="mepr-note-type" class="mepr-note-type-select">
                <option value="admin"><?php esc_html_e('Admin Note', 'memberpress'); ?></option>
                <option value="customer"><?php esc_html_e('Customer Note', 'memberpress'); ?></option>
            </select>
            <button
                type="button"
                id="mepr-add-note-btn"
                class="button button-primary"
                data-order-id="<?php echo esc_attr($order->id); ?>"
            >
                <?php esc_html_e('Add Note', 'memberpress'); ?>
            </button>
        </div>
    </div>

    <?php // ——— Notes timeline ———. ?>
    <div class="mepr-notes-timeline" id="mepr-notes-timeline">
        <?php if (empty($notes)) : ?>
            <p class="mepr-notes-empty" id="mepr-notes-empty">
                <?php esc_html_e('No notes yet.', 'memberpress'); ?>
            </p>
        <?php else : ?>
            <?php foreach ($notes as $note) : ?>
                <?php MeprView::render('/admin/cart-orders/order-note-item', compact('note')); ?>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>

</div>
