<?php

namespace FluentBookingPro\App\Http\Controllers;

use FluentBooking\App\Http\Controllers\Controller;
use FluentBooking\App\Models\Calendar;
use FluentBooking\App\Models\Meta;
use FluentBooking\App\Services\Helper;
use FluentBookingPro\App\Services\Integrations\ZoomMeeting\Client;
use FluentBookingPro\App\Services\Integrations\ZoomMeeting\ZoomHelper;
use FluentBooking\App\Services\PermissionManager;
use FluentBooking\Framework\Http\Request\Request;
use FluentBooking\Framework\Support\Arr;
use FluentBookingPro\App\Services\TeamMembers;

class ZoomController extends Controller
{
    public function get(Request $request)
    {
        $metaQuery = Meta::where('object_type', 'user_meta')
            ->where('key', 'zoom_credentials');

        $teamIds = TeamMembers::ids();
        if ($teamIds !== null) {
            $metaQuery->whereIn('object_id', $teamIds ?: [0]);
        }

        $metaItems = $metaQuery->get();

        // Batch-load users for this page in one query
        $userIds = $metaItems->pluck('object_id')->filter()->unique()->toArray();
        $usersMap = [];
        if ($userIds) {
            foreach (get_users(['include' => $userIds, 'number' => count($userIds)]) as $user) {
                $usersMap[$user->ID] = $user;
            }
        }

        $formattedItems = [];
        foreach ($metaItems as $metaItem) {
            $user = $usersMap[$metaItem->object_id] ?? null;
            if ($user) {
                $userData = [
                    'user_id'    => $user->ID,
                    'name'       => Helper::getDisplayNameFromUser($user),
                    'user_email' => $user->user_email,
                    'avatar'     => Helper::fluentBookingUserAvatar($user->user_email, $user),
                ];
            } else {
                $userData = [
                    'user_id'    => $metaItem->object_id,
                    'name'       => __('Deleted user', 'fluent-booking-pro'),
                    'user_email' => '',
                ];
            }

            $formattedItems[] = [
                'id'              => $metaItem->id,
                'owner'           => $userData,
                'zoom_email'      => Arr::get($metaItem->value, 'origin_email'),
                'created_at'      => $metaItem->created_at,
                'zoom_account_id' => Arr::get($metaItem->value, 'account_id'),
            ];
        }

        return [
            'zoom_users'                 => $formattedItems,
            'is_current_user_configured' => ZoomHelper::isZoomConfigured(get_current_user_id()),
            'form_fields'                => ZoomHelper::getZoomConnectionFields(),
        ];
    }

    public function save(Request $request, $forcedUserId = 0)
    {
        $info = $request->get('zoom_credentials');

        $userId = (int) $forcedUserId
            ?: (int) $request->get('user_id')
            ?: get_current_user_id();

        if (TeamMembers::excludes($userId)) {
            return $this->sendError([
                'message' => __('That user is not part of this team', 'fluent-booking-pro'),
            ], 403);
        }

        $exist = Meta::where('object_type', 'user_meta')
            ->where('key', 'zoom_credentials')
            ->where('object_id', $userId)
            ->first();

        if ($exist) {
            return $this->sendError([
                'message' => __('Zoom credentials already exist for this user', 'fluent-booking-pro'),
            ]);
        }

        $credentials = $this->validate($info, [
            'account_id'    => 'required',
            'client_id'     => 'required',
            'client_secret' => 'required',
        ]);

        // Validate the account ID
        $client = new Client(
            $credentials['client_id'],
            $credentials['client_secret'],
            $credentials['account_id']
        );

        $accessToken = $client->generateAccessToken();

        if (is_wp_error($accessToken)) {
            return $this->sendError([
                'message' => $accessToken->get_error_message()
            ]);
        }

        $credentials['access_token'] = $accessToken['access_token'];
        $credentials['expires_at'] = $accessToken['expires_in'] + time();

        $client = $client->setAccessToken($accessToken['access_token']);

        $me = $client->me();

        if (is_wp_error($me)) {
            return $this->sendError([
                'message' => $me->get_error_message()
            ]);
        }

        if (empty($me['email'])) {
            return $this->sendError([
                'message' => __('Zoom account email is empty', 'fluent-booking-pro')
            ]);
        }

        $credentials['origin_email'] = $me['email'];
        $credentials['origin_display_name'] = $me['display_name'];

        ZoomHelper::updateZoomCredentials($userId, $credentials);

        return $this->sendSuccess([
            'message' => __('Zoom credentials has been validated and saved securely', 'fluent-booking-pro')
        ]);
    }

    public function addConnectionByCalendarId(Request $request, $calendarId)
    {
        $calendar = Calendar::findOrFail($calendarId);

        return $this->save($request, (int) $calendar->user_id);
    }

    public function disconnectByCalendarId(Request $request, $calendarId)
    {
        $calendar = Calendar::findOrFail($calendarId);

        $connectionInfo = $this->getUserInfo($request, (int) $calendar->user_id);

        if (!$connectionInfo || empty($connectionInfo['id'])) {
            return $this->sendError([
                'message' => __('Zoom credentials not found', 'fluent-booking-pro')
            ]);
        }

        return $this->disconnectByConnectId($request, (int) $connectionInfo['id']);
    }

    public function disconnectByConnectId(Request $request, $forcedConnectedId = 0)
    {
        $connectedId = (int) $forcedConnectedId ?: (int) $request->get('connected_id');
        $metaItem = Meta::where('object_type', 'user_meta')
            ->where('key', 'zoom_credentials')
            ->where('id', $connectedId)
            ->first();

        // Someone outside the team reads exactly like a connection that is not there.
        if (!$metaItem || TeamMembers::excludes($metaItem->object_id)) {
            return $this->sendError([
                'message' => __('Zoom credentials not found', 'fluent-booking-pro')
            ]);
        }

        $client = ZoomHelper::getZoomClient($metaItem->object_id);

        if(!is_wp_error($client)) {
            $response = $client->revokeConnection();
        } else {
            $response = $client;
        }

        $metaItem->delete();

        return [
            'message'  => __('Zoom credentials has been disconnected & deleted', 'fluent-booking-pro'),
            'response' => $response
        ];
    }

    public function getZoomConnectionByCalendarId(Request $request, $calendarId)
    {
        if (!PermissionManager::canWriteCalendar($calendarId)) {
            return $this->sendError([
                'message' => __('You do not have permission to view this calendar\'s connected accounts', 'fluent-booking-pro')
            ], 403);
        }

        $calendar = Calendar::findOrFail($calendarId);
        $userId = $calendar->user_id;
        $userInfo = $this->getUserInfo($request, $userId);

        if ($userInfo) {
            return [
                'connection' => $userInfo
            ];
        }

        return [
            'connection'  => $userInfo,
            'form_fields' => ZoomHelper::getZoomConnectionFields()
        ];
    }

    public function me(Request $request)
    {
        return $this->getUserInfo($request, 0);
    }

    public function getUserInfo(Request $request, $userId = 0)
    {
        if (!$userId) {
            $userId = get_current_user_id();
        } else if (!PermissionManager::hasAllCalendarAccess()) {
            $currentUserId = get_current_user_id();
            if ($currentUserId != $userId) {
                return $this->sendError([
                    'message' => __('You do not have permission to access this user\'s Zoom credentials', 'fluent-booking-pro'),
                    'type'    => 'no_permission'
                ], 403);
            }
        }

        $metaItem = Meta::where('object_type', 'user_meta')
            ->where('key', 'zoom_credentials')
            ->where('object_id', $userId)
            ->first();

        if (!$metaItem) {
            return null;
        }

        $user = get_user_by('ID', $metaItem->object_id);

        if (!$user) {
            return null;
        }

        $name = trim($user->first_name . ' ' . $user->last_name);
        if (!$name) {
            $name = $user->display_name;
        }

        return [
            'id'              => $metaItem->id,
            'owner'           => [
                'user_id'    => $user->ID,
                'name'       => $name,
                'user_email' => $user->user_email,
                'avatar'     => get_avatar_url($user->user_email)
            ],
            'zoom_email'      => Arr::get($metaItem->value, 'origin_email'),
            'created_at'      => $metaItem->created_at,
            'zoom_account_id' => Arr::get($metaItem->value, 'account_id'),
        ];
    }
}
