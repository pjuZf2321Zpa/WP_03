<?php

defined('ABSPATH') || exit;

class MeprStripeTaxIntegration
{
    /**
     * Same-request basket results. Not stored across requests and not used for filing.
     *
     * @var array
     */
    private static $basket_memo = [];

    /**
     * Constructor for the MeprStripeTaxIntegration class.
     */
    public function __construct()
    {
        add_action('mepr_tax_rate_options', [$this, 'options']);
        add_action('mepr_process_options', [$this, 'store_options']);
        add_action('admin_notices', [$this, 'new_feature_admin_notice']);
        add_action('admin_notices', [$this, 'deactivated_admin_notice']);
        add_action('wp_ajax_mepr_dismiss_stripe_tax_notice', [$this, 'dismiss_stripe_tax_notice']);
        add_action('wp_ajax_mepr_enable_stripe_tax', [$this, 'enable_stripe_tax']);
        add_action('wp_ajax_mepr_validate_stripe_tax', [$this, 'validate_stripe_tax']);
        add_action('wp_ajax_mepr_validate_stripe_tax_all_gateways', [$this, 'validate_stripe_tax_all_gateways']);

        $calculate_taxes    = (bool) get_option('mepr_calculate_taxes');
        $tax_stripe_enabled = (bool) get_option('mepr_tax_stripe_enabled');

        if ($calculate_taxes && $tax_stripe_enabled) {
            add_filter('mepr_find_tax_rate', [$this, 'find_rate'], 30, 8);
            add_action('mepr_product_advanced_metabox', [$this, 'display_membership_options'], 15);
            add_action('mepr_membership_save_meta', [$this, 'save_membership_options']);
            add_action('mepr_event_transaction_completed', [$this, 'create_tax_transaction']);
            add_action('mepr_order_transition_status', [$this, 'create_order_tax_transaction'], 10, 3);
            add_action('mepr_event_transaction_refunded', [$this, 'refund_tax_transaction']);
            // Cart partial refunds (per-line / order-level) — full refunds stay on transaction-refunded.
            add_action('mepr_cart_order_refunded', [$this, 'refund_cart_order_tax'], 10, 4);
            add_filter('site_status_tests', [$this, 'add_site_health_test']);
            add_action('wp_ajax_health-check-mepr-stripe-tax-test', [$this, 'ajax_site_health_test']);
            add_action('admin_notices', [$this, 'admin_notice']);

            // Stripe Tax prices from the customer's address against the
            // merchant's registrations; a merchant-address calculation
            // location has no meaning there. Force both location options at
            // the options-read layer so every consumer — pricing, recording,
            // views — sees the same values regardless of what is stored, and
            // the stored configuration resurfaces untouched when Stripe Tax
            // is turned off.
            add_filter('mepr_options_get_dynamic_attribute_tax_calc_location', [$this, 'force_customer_tax_calc_location']);
            add_filter('mepr_options_get_dynamic_attribute_tax_default_address', [$this, 'force_no_default_tax_address']);
        }
    }

    /**
     * Render the options for Stripe Tax on the settings page.
     */
    public function options(): void
    {
        $mepr_options            = MeprOptions::fetch();
        $tax_stripe_enabled      = isset($_POST['mepr_tax_stripe_enabled']) || get_option('mepr_tax_stripe_enabled');
        $selected_payment_method = (string) get_option('mepr_tax_stripe_payment_method', '');
        $stripe_payment_methods  = [];

        foreach ($mepr_options->payment_methods(false) as $payment_method) {
            if ($payment_method instanceof MeprStripeGateway && $payment_method->is_connected()) {
                $stripe_payment_methods[$payment_method->id] = empty($payment_method->label) ? $payment_method->id : $payment_method->label;
            }
        }

        MeprView::render('/admin/taxes/stripe_tax_options', get_defined_vars());
    }

    /**
     * Save the Stripe Tax settings to the database.
     */
    public function store_options(): void
    {
        update_option('mepr_tax_stripe_enabled', isset($_POST['mepr_tax_stripe_enabled']));
        update_option('mepr_tax_stripe_payment_method', isset($_POST['mepr_tax_stripe_payment_method']) ? sanitize_text_field(wp_unslash($_POST['mepr_tax_stripe_payment_method'])) : '');
        delete_option('mepr_tax_stripe_deactivated');
    }

    /**
     * Determine the tax rate for the customer.
     *
     * @param  object        $tax_rate The current tax rate object.
     * @param  string        $country  The customer's country.
     * @param  string        $state    The customer's state.
     * @param  string        $postcode The customer's postal code.
     * @param  string        $city     The customer's city.
     * @param  string        $street   The customer's street address.
     * @param  MeprUser|null $user     The user object.
     * @param  integer|null  $prd_id   The product ID.
     * @return object
     */
    public function find_rate($tax_rate, $country, $state, $postcode, $city, $street, $user = null, $prd_id = null)
    {
        $address = self::stripe_address([
            'line1'       => $street,
            'postal_code' => $postcode,
            'city'        => $city,
            'state'       => $state,
            'country'     => $country,
        ]);

        // Incomplete is unpriceable, not an API failure. Signup tax_address()
        // is already null until address_is_set(); cart must not bill
        // tax/calculations on country-only keystrokes.
        if (!self::tax_address_is_complete($address)) {
            return $tax_rate;
        }

        $pm = $this->get_payment_method();

        if (!$pm instanceof MeprStripeGateway) {
            return $tax_rate;
        }

        $minimum_amount = MeprUtils::get_minimum_amount();
        $amount         = $minimum_amount ? 20 * $minimum_amount : 25;
        $tax_id         = $user instanceof MeprUser ? $pm->get_customer_tax_id_data($user) : null;
        $tax_ids        = $tax_id === null ? null : [$tax_id];
        $prd            = empty($prd_id) ? null : new MeprProduct((int) $prd_id);
        $currency       = MeprOptions::fetch()->currency_code;

        // Subscription products preview through an invoice preview — Stripe's
        // documented surface for subscriptions, and free (previews are not
        // billable Calculation API calls). One-time products and product-less
        // lookups (a preview needs a product) stay on tax/calculations.
        if ($prd instanceof MeprProduct && !empty($prd->ID) && !$prd->is_one_time_payment()) {
            $preview = $this->invoice_preview($pm, $address, $amount, $prd, $tax_ids);

            if ($preview && isset($preview->total_tax_amounts) && is_array($preview->total_tax_amounts)) {
                $parsed = self::parse_invoice_tax_lines($preview->total_tax_amounts);

                // A reverse-charge supply collects no tax,
                // so surface the would-be rate for display and flag it
                // reverse_charge. When the merchant charges business
                // customers the net price, it is also a VAT removal, so
                // vat_removal drives the legacy removal machinery
                // (calculate_tax, maybe_apply_vat_removal) to strip the VAT
                // portion from the price.
                if ((float) $parsed['percentage'] === 0.0 && $parsed['reverse_charge_percentage'] > 0) {
                    $tax_rate->tax_rate       = $parsed['reverse_charge_percentage'];
                    $tax_rate->components     = $parsed['reverse_charge_components'];
                    $tax_rate->tax_desc       = join(' + ', array_unique($parsed['reverse_charge_description']));
                    $tax_rate->tax_class      = join(',', array_unique($parsed['reverse_charge_classes']));
                    $tax_rate->customer_type  = 'business';
                    $tax_rate->reverse_charge = true;
                    $tax_rate->vat_removal    = MeprTransactionsHelper::is_charging_business_net_price();

                    return $tax_rate;
                }

                $tax_rate->tax_rate   = $parsed['percentage'];
                $tax_rate->components = $parsed['components'];
                $tax_rate->tax_desc   = join(' + ', array_unique($parsed['description']));
                $tax_rate->tax_class  = empty($parsed['tax_classes']) ? 'standard' : join(',', array_unique($parsed['tax_classes']));
            }

            return $tax_rate;
        }

        $reference = is_null($prd_id) ? 'L1' : (string) $prd_id;
        $tax_code  = is_null($prd_id) ? '' : self::get_product_tax_code($prd_id);

        $tax_calculation = $this->tax_calculation($pm, $address, $amount, $currency, $reference, $tax_code, $tax_ids);

        if ($tax_calculation && isset($tax_calculation->tax_breakdown) && is_array($tax_calculation->tax_breakdown)) {
            $parsed = $this->parse_calculation_breakdown($tax_calculation->tax_breakdown);

            // A reverse-charge calculation collects no tax,
            // so surface the would-be rate for display and flag it
            // reverse_charge. The calculation hides the rate on
            // reverse-charge lines, so learn it from a consumer-shaped
            // calculation (the same purchase without tax IDs). When the
            // merchant charges business customers the net price it is also a
            // VAT removal, so vat_removal drives the legacy removal machinery
            // (calculate_tax, maybe_apply_vat_removal) to strip the VAT.
            if ((float) $parsed['percentage'] === 0.0 && $parsed['reverse_charge'] && !empty($tax_ids)) {
                $consumer_calculation = $this->tax_calculation($pm, $address, $amount, $currency, $reference, $tax_code);

                if ($consumer_calculation && isset($consumer_calculation->tax_breakdown) && is_array($consumer_calculation->tax_breakdown)) {
                    $consumer = $this->parse_calculation_breakdown($consumer_calculation->tax_breakdown);

                    if ($consumer['percentage'] > 0) {
                        $tax_rate->tax_rate       = $consumer['percentage'];
                        $tax_rate->components     = $consumer['components'];
                        $tax_rate->tax_desc       = join(' + ', array_unique($consumer['description']));
                        $tax_rate->tax_class      = join(',', array_unique($consumer['tax_classes']));
                        $tax_rate->customer_type  = 'business';
                        $tax_rate->reverse_charge = true;
                        $tax_rate->vat_removal    = MeprTransactionsHelper::is_charging_business_net_price();

                        return $tax_rate;
                    }
                }
            }

            $tax_rate->tax_rate   = $parsed['percentage'];
            $tax_rate->components = $parsed['components'];
            $tax_rate->tax_desc   = join(' + ', array_unique($parsed['description']));
            $tax_rate->tax_class  = empty($parsed['tax_classes']) ? 'standard' : join(',', array_unique($parsed['tax_classes']));
        }

        return $tax_rate;
    }

    /**
     * Sum the taxed lines of a tax/calculations breakdown.
     *
     * Only lines with a positive amount and rate contribute to the
     * percentage. The reverse_charge flag reports whether any line was
     * reverse-charged — those lines carry no usable rate (Stripe reports
     * percentage_decimal 0.0 on them).
     *
     * @param  array $tax_breakdown The calculation's tax_breakdown rows.
     * @return array{percentage:float,components:MeprTaxRateComponent[],description:array,tax_classes:array,reverse_charge:boolean}
     */
    private function parse_calculation_breakdown(array $tax_breakdown): array
    {
        $components     = [];
        $reverse_charge = false;

        foreach ($tax_breakdown as $rate) {
            $rate_amount        = $rate['amount'] ?? 0;
            $percentage_decimal = $rate['tax_rate_details']['percentage_decimal'] ?? '0.0';
            $tax_type           = $rate['tax_rate_details']['tax_type'] ?? '';

            if ($rate_amount > 0 && $percentage_decimal > 0) {
                $components[] = new MeprTaxRateComponent((float) $percentage_decimal, (string) $tax_type, self::get_tax_description($tax_type));
            } elseif (($rate['taxability_reason'] ?? '') === 'reverse_charge') {
                $reverse_charge = true;
            }
        }

        return self::summarize_components($components) + compact('components', 'reverse_charge');
    }

    /**
     * Derive the blended summary of a component list: the summed percentage
     * and the per-component description and tax-class lists.
     *
     * @param  MeprTaxRateComponent[] $components The components.
     * @return array{percentage:float,description:array,tax_classes:array}
     */
    private static function summarize_components(array $components): array
    {
        return [
            'percentage'  => array_sum(array_map(static fn(MeprTaxRateComponent $component) => $component->percentage, $components)),
            'description' => array_map(static fn(MeprTaxRateComponent $component) => $component->description, $components),
            'tax_classes' => array_map(static fn(MeprTaxRateComponent $component) => $component->tax_class(), $components),
        ];
    }

    /**
     * Sum the taxed and reverse-charged lines of an invoice's tax amounts.
     *
     * Works on the `total_tax_amounts` of an invoice or invoice preview with
     * `tax_rate` expanded: taxed lines (positive amount and rate) accumulate
     * into the percentage, and reverse-charged lines — which carry the
     * would-be rate at a zero amount — accumulate separately under the
     * reverse_charge_* keys (Stripe's taxability vocabulary; tax-type
     * agnostic) so consumers can price VAT removal or label the line's
     * would-be rate. Public static so MeprStripeGateway derives renewal
     * transaction fields from the same lines the pricing preview reads.
     *
     * @param  array $total_tax_amounts The invoice's total_tax_amounts rows.
     * @return array{percentage:float,components:MeprTaxRateComponent[],description:array,tax_classes:array,reverse_charge_percentage:float,reverse_charge_components:MeprTaxRateComponent[],reverse_charge_description:array,reverse_charge_classes:array}
     */
    public static function parse_invoice_tax_lines(array $total_tax_amounts): array
    {
        $components                = [];
        $reverse_charge_components = [];

        foreach ($total_tax_amounts as $tax_amount) {
            $line_amount = $tax_amount['amount'] ?? 0;
            $line_rate   = (array) ($tax_amount['tax_rate'] ?? []);
            $line_pct    = $line_rate['percentage'] ?? 0;
            $tax_type    = $line_rate['tax_type'] ?? '';

            if ($line_amount > 0 && $line_pct > 0) {
                $components[] = new MeprTaxRateComponent((float) $line_pct, (string) $tax_type, self::get_tax_description($tax_type));
            } elseif (($tax_amount['taxability_reason'] ?? '') === 'reverse_charge' && $line_pct > 0) {
                $reverse_charge_components[] = new MeprTaxRateComponent((float) $line_pct, (string) $tax_type, self::get_tax_description($tax_type));
            }
        }

        $summary = self::summarize_components($components);
        $reverse = self::summarize_components($reverse_charge_components);

        return [
            'percentage'                 => $summary['percentage'],
            'components'                 => $components,
            'description'                => $summary['description'],
            'tax_classes'                => $summary['tax_classes'],
            'reverse_charge_percentage'  => $reverse['percentage'],
            'reverse_charge_components'  => $reverse_charge_components,
            'reverse_charge_description' => $reverse['description'],
            'reverse_charge_classes'     => $reverse['tax_classes'],
        ];
    }

    /**
     * Derive a priced line's bookable tax fields from its tax rows
     * (calculation tax_breakdown shape).
     *
     * The single derivation behind quote lines and charged copies: a
     * taxed line books its blended rate and labels; a reverse-charged
     * line books the would-be rate and labels; an untaxed line zeroes
     * the set. The removal figure feeds tax_reversal_amount (a misnamed
     * column: it records only VAT removed from the price) and books
     * solely under net-price removal, where the charged line total is
     * the net and the component tax on it is exactly the removed VAT.
     * Without removal the customer paid the full price and the removal
     * is 0.00. The reverse_charge taxability reason is the one
     * load-bearing value; every other zero-tax row books as untaxed,
     * exactly as parse_invoice_tax_lines() reads it.
     *
     * @param  array<int,array<string,mixed>> $tax_rows   The tax rows.
     * @param  float                          $line_total The line's gross total.
     * @return array{rate:float,desc:string,class:string,removal:float}
     */
    public static function line_tax_fields(array $tax_rows, float $line_total): array
    {
        $tax_lines = [];

        foreach ($tax_rows as $row) {
            $details = (array) ($row['tax_rate_details'] ?? []);

            $tax_lines[] = [
                'amount'            => (int) ($row['amount'] ?? 0),
                'taxability_reason' => (string) ($row['taxability_reason'] ?? ''),
                'tax_rate'          => [
                    'percentage' => (float) ($details['percentage_decimal'] ?? 0),
                    'tax_type'   => $details['tax_type'] ?? '',
                ],
            ];
        }

        $parsed = self::parse_invoice_tax_lines($tax_lines);

        if ((float) $parsed['percentage'] > 0) {
            return [
                'rate'    => (float) $parsed['percentage'],
                'desc'    => join(' + ', array_unique($parsed['description'])),
                'class'   => join(',', array_unique($parsed['tax_classes'])),
                'removal' => 0.00,
            ];
        }

        if ($parsed['reverse_charge_percentage'] > 0) {
            // Net-price removal charges the net, so the removed VAT is
            // the component tax on the charged line total; without
            // removal nothing was removed from the price.
            $removal = MeprTransactionsHelper::is_charging_business_net_price()
                ? MeprTaxRate::component_tax($line_total, $parsed['reverse_charge_components'])
                : 0.00;

            return [
                'rate'    => (float) $parsed['reverse_charge_percentage'],
                'desc'    => join(' + ', array_unique($parsed['reverse_charge_description'])),
                'class'   => join(',', array_unique($parsed['reverse_charge_classes'])),
                'removal' => $removal,
            ];
        }

        return [
            'rate'    => 0.00,
            'desc'    => '',
            'class'   => 'standard',
            'removal' => 0.00,
        ];
    }

    /**
     * Reshape invoice tax rows (total_tax_amounts shape with tax_rate
     * expanded) into the calculation-shaped rows the label derivation
     * reads.
     *
     * The single owner of the invoice-to-calculation field mapping:
     * the quote builder and the charged copies both consume it, so the
     * two response shapes cannot drift apart.
     *
     * @param  array<int,array<string,mixed>> $tax_rows The invoice tax rows.
     * @return array<int,array<string,mixed>>
     */
    public static function reshape_invoice_tax_rows(array $tax_rows): array
    {
        $rows = [];

        foreach ($tax_rows as $row) {
            $rate = (array) ($row['tax_rate'] ?? []);

            $rows[] = [
                'amount'            => $row['amount'] ?? 0,
                'taxability_reason' => $row['taxability_reason'] ?? '',
                'tax_rate_details'  => [
                    'percentage_decimal' => (string) ($rate['percentage'] ?? 0),
                    'tax_type'           => $rate['tax_type'] ?? '',
                ],
            ];
        }

        return $rows;
    }

    /**
     * Deactivate Stripe Tax when Stripe reports it is not activated on the
     * account.
     *
     * The single owner of the deactivation policy: flipping
     * mepr_tax_stripe_enabled disables this integration's hooks AND
     * MeprStripeGateway::use_automatic_tax() on the next request, so
     * previews, recording, automatic-tax args, and PaymentIntent
     * calculations all stop coherently, and the deactivated admin notice
     * appears. Public static so the gateway's charge-time calculation
     * failure path triggers the same policy.
     *
     * @param  Exception $e The Stripe request exception.
     * @return void
     */
    public static function deactivate_on_inactive_account(Exception $e): void
    {
        $code_matches = $e instanceof MeprRemoteException && $e->get_error_code() === 'stripe_tax_inactive';

        if (!$code_matches && strpos($e->getMessage(), 'Stripe Tax has not been activated on your account') === false) {
            return;
        }

        update_option('mepr_tax_stripe_enabled', false);
        update_option('mepr_tax_stripe_payment_method', '');
        update_option('mepr_tax_stripe_deactivated', true);
    }

    /**
     * Force the tax calculation location to the customer's address.
     *
     * @return string
     */
    public function force_customer_tax_calc_location(): string
    {
        return 'customer';
    }

    /**
     * Force the default tax address to none, so a member without an address
     * is priced without tax rather than against the business address.
     *
     * @return string
     */
    public function force_no_default_tax_address(): string
    {
        return 'none';
    }

    /**
     * Get the tax code for the given product.
     *
     * Public static so MeprStripeGateway can resolve a tax code without
     * duplicating the meta lookup logic.
     *
     * @param  integer $product_id The product ID.
     * @return string
     */
    public static function get_product_tax_code(int $product_id): string
    {
        $product = new MeprProduct($product_id);

        if ($product->is_tax_exempt()) {
            $tax_code = 'txcd_00000000';
        } else {
            $stored        = get_post_meta($product_id, '_mepr_tax_stripe_tax_code', true);
            $stored_custom = get_post_meta($product_id, '_mepr_tax_stripe_tax_code_custom', true);
            $tax_code      = $stored ? ($stored === 'custom' ? $stored_custom : $stored) : '';
        }

        /**
         * Filter the resolved Stripe tax code for a membership.
         *
         * The returned value is part of the Stripe Product identity, so changing
         * it through this filter regenerates the Product like any other tax-input
         * change (existing subscriptions are unaffected).
         *
         * @param string  $tax_code   The resolved Stripe tax code, or '' for the account default.
         * @param integer $product_id The membership (product) ID.
         */
        return (string) MeprHooks::apply_filters('mepr_stripe_product_tax_code', $tax_code, $product_id);
    }

    /**
     * Get the description for the given tax type.
     *
     * @param  string $tax_type The tax type.
     * @return string
     */
    private static function get_tax_description(string $tax_type): string
    {
        switch ($tax_type) {
            case 'sales_tax':
                $description = __('Sales Tax', 'memberpress');
                break;
            case 'vat':
            case 'gst':
            case 'hst':
            case 'pst':
            case 'qst':
            case 'rst':
            case 'jct':
            case 'igst':
                $description = strtoupper($tax_type);
                break;
            case 'lease_tax':
                $description = __('Chicago Lease Tax', 'memberpress');
                break;
            default:
                $description = __('Tax', 'memberpress');
                break;
        }

        return $description;
    }

    /**
     * Build a cached Stripe Tax Calculation for discovery.
     *
     * Used by `find_rate()` (discovery — extracts the percentage from the
     * returned `tax_breakdown`). The caller passes the gateway so
     * calculations record on the intended Stripe account (calc IDs are
     * account-scoped). Cache transient prefix is `mepr_stripe_tax_calc_*`
     * with the gateway ID folded into the key to keep per-account
     * calculations isolated; positive entries persist for `DAY_IN_SECONDS`
     * and a failed calculation sets a one-minute cooldown key to avoid
     * immediately re-hitting Stripe with an identical request. Filing never
     * reads this cache: a calculation backs exactly one tax transaction, so
     * `create_tax_transaction()` composes {@see self::tax_calculation_args()}
     * with {@see self::request_tax_calculation()} directly.
     *
     * @param  MeprStripeGateway $pm        The Stripe gateway whose account records the calculation.
     * @param  array             $address   The address array in the format expected by Stripe.
     * @param  integer|float     $amount    The subtotal amount.
     * @param  string            $currency  The currency the amount is charged in.
     * @param  string            $reference Per-line-item identifier required by `tax/calculations`.
     * @param  string|null       $tax_code  Optional Stripe tax code, or null to use the Stripe account default.
     * @param  array|null        $tax_ids   Optional tax IDs array in the format expected by Stripe.
     * @return stdClass|null
     */
    private function tax_calculation(
        MeprStripeGateway $pm,
        array $address,
        float $amount,
        string $currency,
        string $reference,
        ?string $tax_code = null,
        ?array $tax_ids = null
    ): ?stdClass {
        $args = self::tax_calculation_args(
            $address,
            [self::tax_line_item($pm, $amount, $currency, $reference, (string) $tax_code)],
            $currency,
            $tax_ids
        );

        $transient_key = sprintf('mepr_stripe_tax_calc_%s_%s', $pm->id, md5(wp_json_encode($args)));

        $cached = get_transient($transient_key);
        if ($cached instanceof stdClass) {
            return $cached;
        }

        $tax_calculation = self::request_tax_calculation($pm, $args);

        if ($tax_calculation instanceof stdClass) {
            set_transient($transient_key, $tax_calculation, DAY_IN_SECONDS);
        }

        return $tax_calculation;
    }

    /**
     * The request body for a `tax/calculations` call.
     *
     * @param  array      $address    The address array in the format expected by Stripe.
     * @param  array[]    $line_items Line items built by {@see self::tax_line_item()}.
     * @param  string     $currency   The currency the lines are charged in.
     * @param  array|null $tax_ids    Optional tax IDs array in the format expected by Stripe.
     * @return array
     */
    private static function tax_calculation_args(
        array $address,
        array $line_items,
        string $currency,
        ?array $tax_ids = null
    ): array {
        $customer_details = [
            'address'        => $address,
            'address_source' => 'billing',
        ];

        if (!empty($tax_ids)) {
            $customer_details['tax_ids'] = $tax_ids;
        }

        return [
            'currency'         => strtolower($currency),
            'customer_details' => $customer_details,
            'line_items'       => $line_items,
        ];
    }

    /**
     * One `tax/calculations` line item.
     *
     * @param  MeprStripeGateway $pm        The Stripe gateway whose account records the calculation.
     * @param  float             $amount    The line amount (gross under inclusive pricing, net under exclusive).
     * @param  string            $currency  The currency the amount is charged in.
     * @param  string            $reference Per-line-item identifier required by `tax/calculations`.
     * @param  string            $tax_code  Stripe tax code, or empty for the account default.
     * @return array
     */
    private static function tax_line_item(
        MeprStripeGateway $pm,
        float $amount,
        string $currency,
        string $reference,
        string $tax_code = ''
    ): array {
        $line_item = [
            'amount'       => $pm->to_zero_decimal_amount($amount, $currency),
            'reference'    => $reference,
            'tax_behavior' => MeprOptions::fetch()->attr('tax_calc_type') === 'inclusive' ? 'inclusive' : 'exclusive',
        ];

        if ($tax_code !== '') {
            $line_item['tax_code'] = $tax_code;
        }

        return $line_item;
    }

    /**
     * Post a `tax/calculations` request, cooled down after a failure, and
     * answer null when no calculation is available.
     *
     * The response itself is never cached here: a calculation backs
     * exactly one tax transaction, so a filing must always receive a
     * fresh one. A failure trips the inactive-account deactivation
     * policy, logs the request identity, and sets a one-minute cooldown
     * key so an identical request does not re-hit Stripe immediately.
     *
     * @param  MeprStripeGateway $pm             The Stripe gateway whose account records the calculation.
     * @param  array             $args           The request body from {@see self::tax_calculation_args()}.
     * @param  boolean           $throw_on_error Pay Now / charge: rethrow after logging. Display stays fail-open.
     * @return stdClass|null
     * @throws Exception When $throw_on_error is true and the Stripe request fails.
     */
    private static function request_tax_calculation(MeprStripeGateway $pm, array $args, $throw_on_error = false)
    {
        $cooldown_key = sprintf('mepr_stripe_tax_calc_cooldown_%s_%s', $pm->id, md5(wp_json_encode($args)));

        // Display skips a failing account for a minute. Charge always tries — the
        // attached id is the filing source (same as quote-builder STAGE_SUBMIT).
        if (!$throw_on_error && get_transient($cooldown_key)) {
            return null;
        }

        try {
            return (object) $pm->send_stripe_request('tax/calculations', $args);
        } catch (Exception $e) {
            self::deactivate_on_inactive_account($e);

            set_transient($cooldown_key, true, MINUTE_IN_SECONDS);

            MeprUtils::debug_log(sprintf(
                'Stripe Tax calculation failed: %s',
                wp_json_encode([
                    'endpoint'   => 'tax/calculations',
                    'reason'     => 'stripe-tax-calc-failed',
                    'gateway_id' => $pm->id,
                    'currency'   => $args['currency'] ?? '',
                    'country'    => $args['customer_details']['address']['country'] ?? '',
                    'has_vat_id' => !empty($args['customer_details']['tax_ids']),
                    'message'    => $e->getMessage(),
                ])
            ));

            if ($throw_on_error) {
                throw $e; // phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped
            }
        }

        return null;
    }

    /**
     * The Stripe-shaped address for a tax request built from loose parts.
     *
     * Every key is present. Line, city, state and postal code are trimmed so
     * padding does not fork a cache key. Country is uppercased, not trimmed.
     *
     * @param  array $parts Any subset of line1, line2, postal_code, city, state, country.
     * @return array{line1:string,line2:string,postal_code:string,city:string,state:string,country:string}
     */
    public static function stripe_address($parts)
    {
        $parts = is_array($parts) ? $parts : [];

        return [
            'line1'       => trim((string) ($parts['line1'] ?? '')),
            'line2'       => trim((string) ($parts['line2'] ?? '')),
            'postal_code' => trim((string) ($parts['postal_code'] ?? '')),
            'city'        => trim((string) ($parts['city'] ?? '')),
            'state'       => trim((string) ($parts['state'] ?? '')),
            'country'     => strtoupper((string) ($parts['country'] ?? '')),
        ];
    }

    /**
     * The address an order was charged under, from its own billing meta.
     *
     * Filing must not resolve the address again from user meta:
     * sync_billing_to_user_meta() skips empty values, so a field submitted blank
     * keeps its old value and the filing can carry a country and a state that do
     * not belong together. Country decides; line1 falls back to city the way the
     * sync's own fallback does, because require_address_fields off leaves the
     * street empty. Null when the order carries no billing (any pre-cart order),
     * so callers keep MeprUser::tax_address().
     *
     * @param  MeprOrder $order The order being filed.
     * @return array|null
     */
    public static function order_tax_address(MeprOrder $order)
    {
        $country = trim((string) $order->get_meta('_mepr_billing_country', true));

        if ($country === '') {
            return null;
        }

        $line1 = trim((string) $order->get_meta('_mepr_billing_address_1', true));
        $city  = trim((string) $order->get_meta('_mepr_billing_city', true));

        return self::stripe_address([
            'line1'       => $line1 === '' ? $city : $line1,
            'city'        => $city,
            'state'       => $order->get_meta('_mepr_billing_state', true),
            'postal_code' => $order->get_meta('_mepr_billing_zip', true),
            'country'     => $country,
        ]);
    }

    /**
     * Whether a Stripe Tax request address is complete enough to price.
     *
     * Same rule as MeprUser::address_is_set(): two-letter country, street
     * (line1), city, postal_code, and state unless the country is in
     * MeprUtils::get_countries_without_states(). Does not fall back to the
     * business address — Stripe Tax already forces tax_default_address=none.
     *
     * @param  array $address Stripe-shaped address (line1, city, state, postal_code, country).
     * @return boolean
     */
    public static function tax_address_is_complete($address)
    {
        if (!is_array($address)) {
            return false;
        }

        $country = (string) ($address['country'] ?? '');
        if (!preg_match('/^[A-Z][A-Z]$/', $country)) {
            return false;
        }

        $line1    = (string) ($address['line1'] ?? '');
        $city     = (string) ($address['city'] ?? '');
        $postcode = (string) ($address['postal_code'] ?? '');
        $state    = (string) ($address['state'] ?? '');

        $state_required = !in_array($country, MeprUtils::get_countries_without_states(), true);

        return (!empty($line1) && !empty($city) && !empty($postcode) && (!$state_required || !empty($state)));
    }

    /**
     * Price a multi-line basket through one tax/calculations request.
     *
     * Display ($fresh = false) reuses a same-request static, then a
     * DAY_IN_SECONDS transient keyed
     * `mepr_stripe_tax_basket_v1_<pm_id>_<locale>_<md5(args)>`. Bump v1 when
     * the cached row shape changes. Locale is in the key because `desc` is
     * translated. The cached calculation_id is display-only: nothing attaches
     * or files it. If a display id ever becomes attachable, this cache must
     * go — a calculation backs exactly one tax transaction.
     *
     * Pay Now / filing must pass $fresh so they skip both caches and
     * fail-closed on API throw.
     *
     * A caller that owns a charged or booked figure but still wants today's
     * degrade passes $skip_cache instead: it reads and writes neither cache,
     * so the charge is never priced from a cached basket while
     * charge_quote() files a live one.
     *
     * @param  array                  $address    Stripe address (line1, city, state, postal_code, country).
     * @param  array                  $lines      Each: amount (major units), reference, optional tax_code.
     * @param  string                 $currency   Charge currency.
     * @param  MeprUser|null          $user       Buyer (VAT tax IDs). POST VAT still applies when this is null.
     * @param  boolean                $fresh      Skip memo and transient; fail-closed on API throw (Pay Now).
     * @param  MeprStripeGateway|null $pm         Charging gateway. Default: designated tax method.
     * @param  boolean                $skip_cache Skip memo and transient, but degrade on API failure (submit totals).
     * @return array|null                         calculation_id plus lines keyed by reference, or null on failure.
     * @throws Exception When $fresh is true and tax/calculations throws.
     */
    public static function calculate_basket($address, $lines, $currency, $user = null, $fresh = false, $pm = null, $skip_cache = false)
    {
        if (!is_array($address) || !is_array($lines) || $lines === [] || $currency === '') {
            return null;
        }

        // Incomplete is unpriceable, not an API failure — even Pay Now ($fresh)
        // must not throw or mint a billable calculation on a partial address.
        if (!self::tax_address_is_complete($address)) {
            return null;
        }

        if (!$pm instanceof MeprStripeGateway) {
            $payment_method_id = (string) get_option('mepr_tax_stripe_payment_method', '');
            if ($payment_method_id === '') {
                return null;
            }

            $pm = MeprOptions::fetch()->payment_method($payment_method_id);
            if (!$pm instanceof MeprStripeGateway) {
                return null;
            }
        }

        // Guest checkout still has VAT on $_POST; get_customer_tax_id_data reads that first.
        if (!$user instanceof MeprUser) {
            $user = new MeprUser(get_current_user_id());
        }

        $tax_id  = $pm->get_customer_tax_id_data($user);
        $tax_ids = $tax_id === null ? null : [$tax_id];

        $line_items = [];
        foreach ($lines as $line) {
            $amount = (float) ($line['amount'] ?? 0);
            $ref    = (string) ($line['reference'] ?? '');
            if ($ref === '' || $amount <= 0) {
                continue;
            }

            $line_items[] = self::tax_line_item(
                $pm,
                $amount,
                $currency,
                $ref,
                (string) ($line['tax_code'] ?? '')
            );
        }

        if ($line_items === []) {
            return null;
        }

        $args           = self::tax_calculation_args($address, $line_items, $currency, $tax_ids);
        $args['expand'] = ['line_items.data.tax_breakdown'];

        $args_hash     = md5((string) wp_json_encode($args));
        $locale        = determine_locale();
        $memo_key      = $pm->id . '_' . $locale . '_' . $args_hash;
        $transient_key = sprintf(
            'mepr_stripe_tax_basket_v1_%s_%s_%s',
            $pm->id,
            $locale,
            $args_hash
        );
        // Previews cache. $fresh (attach / file) and $skip_cache (submit totals) both
        // price live; only $fresh turns an API failure into a throw.
        $use_cache = !$fresh && !$skip_cache;

        if ($use_cache && array_key_exists($memo_key, self::$basket_memo)) {
            return self::$basket_memo[$memo_key];
        }

        if ($use_cache) {
            $cached = get_transient($transient_key);
            if (
                is_array($cached)
                && !empty($cached['calculation_id'])
                && !empty($cached['lines'])
                && is_array($cached['lines'])
            ) {
                self::$basket_memo[$memo_key] = $cached;

                return $cached;
            }
        }

        $calculation = self::request_tax_calculation($pm, $args, $fresh);
        if (!$calculation instanceof stdClass) {
            if ($use_cache) {
                self::$basket_memo[$memo_key] = null;
            }

            return null;
        }

        $calc_lines = self::embedded_calculation_lines($pm, $calculation);
        if ($calc_lines === []) {
            // A calculation was minted but its lines could not be read (pagination
            // error / malformed embed). Pay Now is fail-closed: charging without the
            // lines would create a PaymentIntent with no attachable tax data.
            if ($fresh) {
                throw new Exception(
                    esc_html__('Tax calculation lines could not be retrieved. Please try again.', 'memberpress')
                );
            }

            if ($use_cache) {
                self::$basket_memo[$memo_key] = null;
            }

            return null;
        }

        $order_rows = isset($calculation->tax_breakdown) && is_array($calculation->tax_breakdown)
            ? $calculation->tax_breakdown
            : [];

        $twin_by_ref = [];
        if ($tax_ids !== null && self::breakdown_has_reverse_charge($order_rows)) {
            unset($args['customer_details']['tax_ids']);
            $twin = self::request_tax_calculation($pm, $args);
            if ($twin instanceof stdClass) {
                foreach (self::embedded_calculation_lines($pm, $twin) as $twin_line) {
                    $twin_by_ref[(string) ($twin_line['reference'] ?? '')] = $twin_line;
                }
            }
        }

        $inclusive = MeprOptions::fetch()->attr('tax_calc_type') === 'inclusive';
        $divisor   = MeprStripeGateway::is_zero_decimal_currency($currency) ? 1 : 100;
        $out_lines = [];

        foreach ($calc_lines as $calc_line) {
            $ref = (string) ($calc_line['reference'] ?? '');
            if ($ref === '') {
                continue;
            }

            $amount_cents = (int) ($calc_line['amount'] ?? 0);
            $tax_cents    = (int) ($calc_line['amount_tax'] ?? 0);
            $breakdown    = isset($calc_line['tax_breakdown']) && is_array($calc_line['tax_breakdown'])
                ? $calc_line['tax_breakdown']
                : [];
            $is_rc        = self::breakdown_has_reverse_charge($breakdown);

            if ($is_rc && isset($twin_by_ref[$ref]['tax_breakdown']) && is_array($twin_by_ref[$ref]['tax_breakdown'])) {
                $breakdown = $twin_by_ref[$ref]['tax_breakdown'];
            }

            $gross  = ($inclusive ? $amount_cents : $amount_cents + $tax_cents) / $divisor;
            $fields = self::line_tax_fields($breakdown, $gross);
            $net    = $inclusive
                ? ($amount_cents - $tax_cents) / $divisor
                : $amount_cents / $divisor;

            $out_lines[$ref] = [
                'amount'         => (float) $net,
                'tax_amount'     => $is_rc ? 0.0 : ($tax_cents / $divisor),
                'rate'           => (float) ($fields['rate'] ?? 0),
                'desc'           => (string) ($fields['desc'] ?? ''),
                'class'          => (string) ($fields['class'] ?? 'standard'),
                'reverse_charge' => $is_rc,
            ];
        }

        $calc_id = (string) ($calculation->id ?? '');
        if ($out_lines === [] || $calc_id === '') {
            if ($use_cache) {
                self::$basket_memo[$memo_key] = null;
            }

            return null;
        }

        $result = [
            'calculation_id' => $calc_id,
            'lines'          => $out_lines,
        ];

        if ($use_cache) {
            self::$basket_memo[$memo_key] = $result;
            set_transient($transient_key, $result, DAY_IN_SECONDS);
        }

        return $result;
    }

    /**
     * Complete line list from a tax.calculation, paged like the quote builder.
     *
     * Stripe's create response only embeds 10 lines. Empty / unpageable lists
     * fail open (display) rather than throwing.
     *
     * @param  MeprStripeGateway $pm          Designated Stripe gateway.
     * @param  stdClass          $calculation Calculation response.
     * @return array
     */
    private static function embedded_calculation_lines($pm, $calculation)
    {
        $embedded = $calculation->line_items ?? null;
        if (is_object($embedded)) {
            $embedded = (array) $embedded;
        }

        if (!is_array($embedded) || empty($embedded['data']) || !is_array($embedded['data'])) {
            return [];
        }

        $data = [];
        foreach ($embedded['data'] as $line) {
            $data[] = (array) $line;
        }

        $has_more = !empty($embedded['has_more']);
        $calc_id  = (string) ($calculation->id ?? '');

        while ($has_more) {
            if ($calc_id === '' || $data === []) {
                return [];
            }

            $last = end($data);

            try {
                $page = (array) $pm->send_stripe_request(
                    'tax/calculations/' . $calc_id . '/line_items',
                    [
                        'limit'          => 100,
                        'starting_after' => (string) ($last['id'] ?? ''),
                        'expand'         => ['data.tax_breakdown'],
                    ],
                    'get'
                );
            } catch (Exception $e) {
                return [];
            }

            if (!is_array($page['data'] ?? null)) {
                return [];
            }

            foreach ($page['data'] as $line) {
                $data[] = (array) $line;
            }

            $has_more = !empty($page['has_more']);
        }

        return $data;
    }

    /**
     * Whether any tax row is reverse-charged.
     *
     * @param  array $rows Calculation or line tax_breakdown rows.
     * @return boolean
     */
    private static function breakdown_has_reverse_charge($rows)
    {
        if (!is_array($rows)) {
            return false;
        }

        foreach ($rows as $row) {
            $row = (array) $row;
            if (($row['taxability_reason'] ?? '') === 'reverse_charge') {
                return true;
            }
        }

        return false;
    }

    /**
     * Build a Stripe invoice preview by calling the `invoices/create_preview` endpoint.
     *
     * Used by `find_rate()` for subscription products (discovery — extracts
     * the percentage from the returned `total_tax_amounts`). The line item
     * references the membership's real Stripe Product, so the product-level
     * tax_code applies, and carries the product's real billing interval with
     * the same probe amount as `tax_calculation()`. Cache transient prefix is
     * `mepr_stripe_tax_preview_*` with the gateway ID folded into the key;
     * positive entries persist for `DAY_IN_SECONDS` and a failed preview sets
     * a one-minute cooldown key to avoid immediately re-hitting Stripe with
     * an identical request. The cache key hashes the local product ID rather
     * than the resolved Stripe product ID, so cache hits skip the product
     * lookup (which is itself a Stripe request and can throw).
     *
     * A billing period Stripe has no interval for is unpriceable, so it
     * answers null before any request: fabricating an interval would return
     * a plausible rate for terms the customer is not being billed on.
     *
     * @param  MeprStripeGateway $pm      The Stripe gateway whose account computes the preview.
     * @param  array             $address The address array in the format expected by Stripe.
     * @param  float             $amount  The subtotal amount.
     * @param  MeprProduct       $prd     The subscription product being previewed.
     * @param  array|null        $tax_ids Optional tax IDs array in the format expected by Stripe.
     * @return stdClass|null
     */
    private function invoice_preview(MeprStripeGateway $pm, array $address, float $amount, MeprProduct $prd, ?array $tax_ids = null): ?stdClass
    {
        $mepr_options = MeprOptions::fetch();

        $customer_details = ['address' => $address];

        if (!empty($tax_ids)) {
            $customer_details['tax_ids'] = $tax_ids;
        }

        $intervals = [
            'days'   => 'day',
            'weeks'  => 'week',
            'months' => 'month',
            'years'  => 'year',
        ];

        if (!isset($intervals[$prd->period_type])) {
            return null;
        }

        $price_data = [
            'currency'     => strtolower($mepr_options->currency_code),
            'recurring'    => [
                'interval'       => $intervals[$prd->period_type],
                'interval_count' => max(1, (int) $prd->period),
            ],
            'unit_amount'  => $pm->to_zero_decimal_amount($amount, $mepr_options->currency_code),
            'tax_behavior' => $mepr_options->attr('tax_calc_type') === 'inclusive' ? 'inclusive' : 'exclusive',
        ];

        $preview_hash  = md5(wp_json_encode([$customer_details, $price_data, $prd->ID]));
        $transient_key = sprintf('mepr_stripe_tax_preview_%s_%s', $pm->id, $preview_hash);
        $cooldown_key  = sprintf('mepr_stripe_tax_preview_cooldown_%s_%s', $pm->id, $preview_hash);

        $cached = get_transient($transient_key);
        if ($cached instanceof stdClass) {
            return $cached;
        }

        // A recent failure sets a short cooldown, so an identical request does
        // not re-hit Stripe until the cooldown expires.
        if (get_transient($cooldown_key)) {
            return null;
        }

        try {
            $price_data['product'] = $pm->get_product_id($prd);

            $preview = (object) $pm->send_stripe_request('invoices/create_preview', [
                'automatic_tax'        => ['enabled' => 'true'],
                'customer_details'     => $customer_details,
                'subscription_details' => [
                    'items' => [
                        [
                            'quantity'   => 1,
                            'price_data' => $price_data,
                        ],
                    ],
                ],
                'expand'               => ['total_tax_amounts.tax_rate'],
            ]);

            set_transient($transient_key, $preview, DAY_IN_SECONDS);

            return $preview;
        } catch (Exception $e) {
            self::deactivate_on_inactive_account($e);

            // Start a brief cooldown so an identical request does not re-hit
            // Stripe for a minute after a failure.
            set_transient($cooldown_key, true, MINUTE_IN_SECONDS);

            MeprUtils::debug_log(sprintf(
                'Stripe Tax invoice preview failed: %s',
                wp_json_encode([
                    'endpoint'   => 'invoices/create_preview',
                    'reason'     => 'stripe-tax-preview-failed',
                    'gateway_id' => $pm->id,
                    'currency'   => strtolower($mepr_options->currency_code),
                    'country'    => $address['country'] ?? '',
                    'product_id' => $prd->ID,
                    'has_vat_id' => !empty($tax_ids),
                    'message'    => $e->getMessage(),
                ])
            ));
        }

        return null;
    }

    /**
     * Get the Stripe payment method to use for Stripe Tax.
     *
     * @return MeprStripeGateway|null
     */
    private function get_payment_method(): ?MeprStripeGateway
    {
        $mepr_options      = MeprOptions::fetch();
        $payment_method_id = (string) get_option('mepr_tax_stripe_payment_method', '');

        if (!empty($payment_method_id)) {
            $payment_method = $mepr_options->payment_method($payment_method_id);

            if ($payment_method instanceof MeprStripeGateway) {
                return $payment_method;
            }
        }

        return null;
    }

    /**
     * Resolve which Stripe gateway recorded tax for the given transaction.
     *
     * Used by `refund_tax_transaction()` so reversals post to the same
     * account that holds the original tax/transaction record (tax
     * transaction ids are account-scoped). A row filed by this recorder
     * carries the filing account as stripe_tax_gateway_id, which wins; a
     * row carrying a stripe_tax_transaction_id without a gateway stamp was
     * filed by an earlier recorder that always filed on the designated
     * account, whatever the row's own gateway, so the designated gateway is
     * the fallback for those rows and for stamps whose gateway was deleted
     * since filing.
     *
     * @param  MeprTransaction $txn The transaction whose tax-recording gateway to resolve.
     * @return MeprStripeGateway|null
     */
    private function resolve_recording_gateway(MeprTransaction $txn): ?MeprStripeGateway
    {
        $filing_gateway_id = $txn->get_meta('stripe_tax_gateway_id', true);

        if (!empty($filing_gateway_id)) {
            $filing_gateway = MeprOptions::fetch()->payment_method((string) $filing_gateway_id);

            if ($filing_gateway instanceof MeprStripeGateway) {
                return $filing_gateway;
            }
        }

        return $this->get_payment_method();
    }

    /**
     * Get the ID of the first Stripe payment method that is connected to Stripe.
     *
     * @return string|null
     */
    private function get_first_stripe_payment_method_id(): ?string
    {
        $mepr_options = MeprOptions::fetch();

        foreach ($mepr_options->payment_methods(false) as $payment_method) {
            if ($payment_method instanceof MeprStripeGateway && $payment_method->is_connected()) {
                return $payment_method->id;
            }
        }

        return null;
    }

    /**
     * Create a tax transaction.
     *
     * @param MeprEvent $event The event object containing transaction data.
     */
    public function create_tax_transaction(MeprEvent $event): void
    {
        $txn = $event->get_data();

        // Only positive payment rows are filed: a confirmation row (which can
        // now carry the first period's figures) is not a payment and must not
        // be filed on top of the payment row's own filing.
        if (!$txn instanceof MeprTransaction || $txn->amount <= 0 || $txn->txn_type !== MeprTransaction::$payment_str) {
            return;
        }

        // A best-effort skip for the common case: a re-fired completion event
        // (a webhook retry) finds this meta set and avoids a redundant filing
        // call. It is not the idempotency guarantee. Stripe enforces a unique
        // `reference` on create_from_calculation below, so a concurrent event
        // that races past this check is rejected there and never
        // double-recorded.
        if (!empty($txn->get_meta('stripe_tax_transaction_id', true))) {
            return;
        }

        // A Stripe-gateway transaction's tax is recorded by Stripe itself —
        // subscriptions and Checkout sessions run with automatic_tax, and a
        // bare PaymentIntent carries an attached tax calculation (see
        // MeprStripeGateway::add_payment_intent_tax_calculation()) — so posting a manual
        // tax/transaction on top would double-report. Manual recording
        // serves non-Stripe gateways (PayPal, Authorize.net, etc.), which
        // record through the globally-selected Stripe Tax payment method.
        if ($txn->payment_method() instanceof MeprStripeGateway) {
            return;
        }

        // Order rows file together through the order machinery, never
        // singly: while the order is open, the completion transition files
        // them; on an already-complete order (a row completed by hand after
        // the order filed), the sweep files the stragglers as a
        // supplemental order-level filing with the same per-line stamps. A
        // row whose order record no longer exists falls through to the
        // per-transaction path, so collected money always files.
        if ($txn->order_id > 0) {
            $order = $txn->order();

            if ($order instanceof MeprOrder) {
                if ($order->is_complete()) {
                    $this->file_order_rows($order);
                }

                return;
            }
        }

        $pm = $this->get_payment_method();

        if (!$pm instanceof MeprStripeGateway) {
            return;
        }

        $usr = $txn->user();

        // The same address resolution the pricing used, so the recorded
        // calculation sees the inputs the customer was charged under.
        $address = $usr->tax_address();

        if ($address === null || !preg_match('/^[A-Z][A-Z]$/', (string) $address['country'])) {
            return;
        }

        $mepr_options = MeprOptions::fetch();
        $tax_id       = $pm->get_customer_tax_id_data($usr);

        // One filing per transaction: this path serves rows that belong to
        // no order (renewals, single-item checkouts, admin-created rows),
        // which are priced solo, so a solo calculation matches their books.
        // The calculation is priced fresh, never from the discovery cache: a
        // calculation backs exactly one filing, and Stripe rejects a second
        // create_from_calculation from the same one.
        $tax_calculation = self::request_tax_calculation(
            $pm,
            self::tax_calculation_args(
                $address,
                [
                    self::tax_line_item(
                        $pm,
                        $mepr_options->attr('tax_calc_type') === 'inclusive' ? (float) $txn->total : (float) $txn->amount,
                        (string) $txn->currency,
                        (string) $txn->product_id,
                        self::get_product_tax_code((int) $txn->product_id)
                    ),
                ],
                (string) $txn->currency,
                $tax_id === null ? null : [$tax_id]
            )
        );

        if ($tax_calculation) {
            try {
                $tax_transaction = (object) $pm->send_stripe_request('tax/transactions/create_from_calculation', [
                    'calculation' => $tax_calculation->id,
                    'reference'   => $txn->trans_num,
                ]);

                $txn->update_meta('stripe_tax_transaction_id', $tax_transaction->id);
                $txn->update_meta('stripe_tax_gateway_id', $pm->id);
            } catch (Exception $e) {
                MeprUtils::debug_log('stripe-tax-filing-failed: ' . $e->getMessage());
            }
        }
    }

    /**
     * File one multi-line tax transaction for a completed order.
     *
     * Hooked to the order status transition, which every completion site
     * funnels through, so the filing fires exactly once however an order
     * completes.
     *
     * @param string    $old_status The order's status before the store.
     * @param string    $new_status The order's status after the store.
     * @param MeprOrder $order      The stored order.
     */
    public function create_order_tax_transaction($old_status, $new_status, MeprOrder $order): void
    {
        if ($new_status !== MeprOrder::$complete_str || $old_status === MeprOrder::$complete_str) {
            return;
        }

        $this->file_order_rows($order);
    }

    /**
     * File the order's completed, chargeable, not-yet-filed rows as one
     * multi-line tax transaction.
     *
     * The single filing owner for order rows: the completion transition
     * files the whole basket, and a straggler completing on an
     * already-filed order sweeps through here again as a supplemental
     * filing (referenced by the straggler's own trans_num, since the
     * order's reference is spent). Every filed row is stamped with the
     * filing id and its own line id, which is what routes its refund to
     * the per-line reversal. Filed figures never correct the books; a
     * per-line divergence from the booked tax is logged.
     *
     * $calculation_id is additive and unused by develop callers. Cart offline
     * complete mints a fresh unused calculation and passes that id so
     * create_from_calculation files the same basket that was charged. Empty
     * falls back to minting here (stragglers / admin-complete with no cart mint).
     *
     * @param  MeprOrder $order          The order whose rows to file.
     * @param  string    $calculation_id Optional unused taxcalc_ id from cart offline complete.
     * @return void
     */
    private function file_order_rows(MeprOrder $order, $calculation_id = ''): void
    {
        // A Stripe-gateway order's tax is recorded by Stripe itself.
        if (MeprOptions::fetch()->payment_method($order->gateway) instanceof MeprStripeGateway) {
            return;
        }

        $pm = $this->get_payment_method();

        if (!$pm instanceof MeprStripeGateway) {
            return;
        }

        $rows = array_values(array_filter(
            MeprTransaction::get_all_by_order_id($order->id),
            static function (MeprTransaction $row): bool {
                return $row->txn_type === MeprTransaction::$payment_str
                    && $row->status === MeprTransaction::$complete_str
                    && $row->amount > 0
                    && empty($row->get_meta('stripe_tax_transaction_id', true));
            }
        ));

        if (empty($rows)) {
            return;
        }

        // First filing vs straggler must be known before we pick a calculation
        // id: a consumed offline calc backs exactly one create_from_calculation.
        $first_filing = empty($order->get_meta('stripe_tax_transaction_id', true));

        $calculation_id    = is_string($calculation_id) ? $calculation_id : '';
        $from_offline_meta = false;

        if ($calculation_id === '' && $first_filing) {
            $calculation_id    = (string) $order->get_meta('_mepr_stripe_tax_offline_calculation_id', true);
            $from_offline_meta = ($calculation_id !== '');
        }

        if ($calculation_id === '') {
            $usr = new MeprUser((int) $order->user_id);

            // The address this order was charged under, so the filing matches the
            // jurisdiction the buyer paid for. Orders without billing meta keep the
            // profile resolution.
            $address = self::order_tax_address($order) ?? $usr->tax_address();

            if ($address === null || !preg_match('/^[A-Z][A-Z]$/', (string) $address['country'])) {
                return;
            }

            $mepr_options = MeprOptions::fetch();
            $inclusive    = $mepr_options->attr('tax_calc_type') === 'inclusive';
            $tax_id       = $pm->get_customer_tax_id_data($usr);
            $line_items   = [];

            foreach ($rows as $row) {
                $line_items[] = self::tax_line_item(
                    $pm,
                    $inclusive ? (float) $row->total : (float) $row->amount,
                    (string) $order->currency,
                    $row->trans_num,
                    self::get_product_tax_code((int) $row->product_id)
                );
            }

            $tax_calculation = self::request_tax_calculation(
                $pm,
                self::tax_calculation_args($address, $line_items, (string) $order->currency, $tax_id === null ? null : [$tax_id])
            );

            if (!$tax_calculation instanceof stdClass) {
                return;
            }

            $calculation_id = (string) $tax_calculation->id;
        }

        if ($calculation_id === '') {
            return;
        }

        // The first filing carries the order's own charge reference; a
        // supplemental straggler filing needs its own unique reference, and
        // the row's trans_num is globally unique. Stripe's unique-reference
        // enforcement remains the idempotency backstop against a race that
        // passes the unstamped-rows filter twice.
        $reference = $first_filing ? $order->trans_num : $rows[0]->trans_num;

        try {
            $tax_transaction = (object) $pm->send_stripe_request('tax/transactions/create_from_calculation', [
                'calculation' => $calculation_id,
                'reference'   => $reference,
                'expand'      => ['line_items'],
            ]);
        } catch (Exception $e) {
            MeprUtils::debug_log('stripe-tax-filing-failed: ' . $e->getMessage());

            // A consumed id must not block the mint fallback forever.
            if ($from_offline_meta) {
                $order->delete_meta('_mepr_stripe_tax_offline_calculation_id');
            }

            return;
        }

        $order->delete_meta('_mepr_stripe_tax_offline_calculation_id');

        if ($first_filing) {
            $order->update_meta('stripe_tax_transaction_id', $tax_transaction->id);
            $order->update_meta('stripe_tax_gateway_id', $pm->id);
        }

        // Every row is filed the moment Stripe accepts the filing, so every
        // row is stamped with it here, before a single line is read back. A
        // filed row that carries no filing id looks unfiled to the straggler
        // sweep and is filed again, and a supplemental filing carries its own
        // reference, so Stripe's uniqueness check cannot catch that duplicate.
        // Stamping first means an interrupted run can only ever lose the line
        // detail below, never the fact of the filing.
        foreach ($rows as $row) {
            $row->update_meta('stripe_tax_transaction_id', $tax_transaction->id);
            $row->update_meta('stripe_tax_gateway_id', $pm->id);
        }

        // The pagination follows has_more to the end so each filed line can be
        // matched to the row it belongs to, and a page failure is logged
        // loudly rather than swallowed.
        $filed_lines = [];
        $page        = (array) ($tax_transaction->line_items ?? []);

        while (true) {
            foreach ((array) ($page['data'] ?? []) as $line) {
                $filed_lines[(string) ($line['reference'] ?? '')] = $line;
            }

            if (empty($page['has_more']) || empty($page['data'])) {
                break;
            }

            $last = end($page['data']);

            try {
                $page = (array) $pm->send_stripe_request(
                    "tax/transactions/$tax_transaction->id/line_items",
                    [
                        'starting_after' => (string) ($last['id'] ?? ''),
                        'limit'          => 100,
                    ],
                    'get'
                );
            } catch (Exception $e) {
                MeprUtils::debug_log(sprintf(
                    'stripe-tax-filing-failed: line stamping incomplete for order %d: %s',
                    $order->id,
                    $e->getMessage()
                ));

                break;
            }
        }

        foreach ($rows as $row) {
            $line = $filed_lines[$row->trans_num] ?? null;

            if ($line === null) {
                // The row already carries the filing id, so it cannot re-file.
                // Its line stamps stay empty, which the refund path reads as
                // "no line of the shared filing to reverse".
                MeprUtils::debug_log(sprintf(
                    'stripe-tax-filing-failed: filed transaction %s carries no line for row %d (order %d)',
                    $tax_transaction->id,
                    $row->id,
                    $order->id
                ));

                continue;
            }

            $row->update_meta('stripe_tax_line_item_id', (string) $line['id']);
            $row->update_meta('stripe_tax_line_amount', (string) $line['amount']);
            $row->update_meta('stripe_tax_line_tax_amount', (string) $line['amount_tax']);

            if ((int) $line['amount_tax'] !== $pm->to_zero_decimal_amount((float) $row->tax_amount, (string) $order->currency)) {
                MeprUtils::debug_log('stripe-tax-order-filing-divergence: ' . wp_json_encode([
                    'order_id'   => $order->id,
                    'txn_id'     => $row->id,
                    'booked_tax' => $pm->to_zero_decimal_amount((float) $row->tax_amount, (string) $order->currency),
                    'filed_tax'  => (int) $line['amount_tax'],
                ]));
            }
        }
    }

    /**
     * Refund a tax transaction.
     *
     * @param MeprEvent $event The event object containing transaction data.
     */
    public function refund_tax_transaction(MeprEvent $event): void
    {
        $txn = $event->get_data();

        if (!$txn instanceof MeprTransaction) {
            return;
        }

        $tax_transaction_id = $txn->get_meta('stripe_tax_transaction_id', true);

        if (empty($tax_transaction_id)) {
            return;
        }

        // Reversals must post to the same Stripe account that recorded the
        // original transaction, so resolve the account that filed the row.
        $pm = $this->resolve_recording_gateway($txn);

        if (!$pm instanceof MeprStripeGateway) {
            return;
        }

        try {
            $line_item_id = (string) $txn->get_meta('stripe_tax_line_item_id', true);

            if ($line_item_id !== '') {
                $line_amount     = (int) $txn->get_meta('stripe_tax_line_amount', true);
                $line_tax_amount = (int) $txn->get_meta('stripe_tax_line_tax_amount', true);

                $this->reverse_filed_line($pm, $txn, $line_amount, $line_tax_amount);

                return;
            }

            // An order row shares one filing with the order's other rows, so
            // reversing it in full would reverse their tax too. Only a row
            // that owns its filing may take the full-mode reversal.
            if ($txn->order_id > 0) {
                MeprUtils::debug_log(sprintf(
                    'stripe-tax-refund-failed: order row %d has no filed line to reverse',
                    $txn->id
                ));

                return;
            }

            $pm->send_stripe_request('tax/transactions/create_reversal', [
                'mode'                 => 'full',
                'original_transaction' => $tax_transaction_id,
                'reference'            => $txn->trans_num . '-refund',
            ]);
        } catch (Exception $e) {
            MeprUtils::debug_log('stripe-tax-refund-failed: ' . $e->getMessage());
        }
    }

    /**
     * Reverse one filed tax line by an amount/tax pair (smallest currency unit).
     *
     * Caps to remaining stamps so a remainder after a partial cannot reverse the
     * same cents twice. Develop's full-line refund passes the stamped figures;
     * cart offline partials pass a share of those stamps.
     *
     * @param MeprStripeGateway $pm           Account that filed the row.
     * @param MeprTransaction   $txn          Filed payment row.
     * @param integer           $amount_cents Line amount to reverse (positive).
     * @param integer           $tax_cents    Line tax to reverse (positive).
     */
    private function reverse_filed_line($pm, $txn, $amount_cents, $tax_cents)
    {
        if (!$pm instanceof MeprStripeGateway || !$txn instanceof MeprTransaction) {
            return;
        }

        $tax_transaction_id = $txn->get_meta('stripe_tax_transaction_id', true);
        $line_item_id       = (string) $txn->get_meta('stripe_tax_line_item_id', true);

        if (empty($tax_transaction_id) || $line_item_id === '') {
            return;
        }

        $filed_amount = (int) $txn->get_meta('stripe_tax_line_amount', true);
        $filed_tax    = (int) $txn->get_meta('stripe_tax_line_tax_amount', true);

        // A filed line always carries a positive amount, so a missing amount
        // stamp is a broken record: posting it would send a zero reversal
        // Stripe rejects.
        if ($filed_amount <= 0) {
            MeprUtils::debug_log(sprintf(
                'stripe-tax-refund-failed: row %d carries line %s without amount stamps',
                $txn->id,
                $line_item_id
            ));

            return;
        }

        $already_amount = (int) $txn->get_meta('stripe_tax_line_reversed_amount', true);
        $already_tax    = (int) $txn->get_meta('stripe_tax_line_reversed_tax_amount', true);
        $remain_amount  = max(0, $filed_amount - $already_amount);
        $remain_tax     = max(0, $filed_tax - $already_tax);

        $use_amount = min(abs((int) $amount_cents), $remain_amount);
        $use_tax    = min(abs((int) $tax_cents), $remain_tax);

        if ($use_amount <= 0) {
            return;
        }

        $rev_count     = (int) $txn->get_meta('stripe_tax_line_reversal_count', true);
        $suffix        = $rev_count > 0 ? '-' . ($rev_count + 1) : '';
        $reference     = $txn->trans_num . '-refund' . $suffix;
        $line_reference = $txn->trans_num . '-refund-line' . $suffix;

        $pm->send_stripe_request('tax/transactions/create_reversal', [
            'mode'                 => 'partial',
            'original_transaction' => $tax_transaction_id,
            'reference'            => $reference,
            'line_items'           => [
                [
                    'original_line_item' => $line_item_id,
                    'reference'          => $line_reference,
                    'amount'             => -$use_amount,
                    'amount_tax'         => -$use_tax,
                ],
            ],
        ]);

        $txn->update_meta('stripe_tax_line_reversed_amount', (string) ($already_amount + $use_amount));
        $txn->update_meta('stripe_tax_line_reversed_tax_amount', (string) ($already_tax + $use_tax));
        $txn->update_meta('stripe_tax_line_reversal_count', (string) ($rev_count + 1));
    }

    /**
     * Partial cart refund → Stripe Tax partial reversal(s).
     *
     * Full refunds already fire transaction-refunded (handled above). This covers
     * per-line and order-level partials via mepr_cart_order_refunded.
     *
     * Stripe-gateway orders return immediately (Stripe reverses the PI itself).
     * Offline partials reverse a share of `stripe_tax_line_*` stamps.
     *
     * @param MeprOrder         $order         The cart order.
     * @param float             $refund_amount Refund total (incl. tax), charge currency.
     * @param float             $refund_tax    Tax portion of the refund.
     * @param MeprTransaction[] $refunded_txns Affected line txn(s); empty = order-level lump.
     */
    public function refund_cart_order_tax($order, $refund_amount, $refund_tax = 0.0, $refunded_txns = [])
    {
        if (!($order instanceof MeprOrder)) {
            return;
        }

        // Stripe-gateway cart money is filed and reversed by Stripe on the PI.
        if (MeprOptions::fetch()->payment_method($order->gateway) instanceof MeprStripeGateway) {
            return;
        }

        $refund_amount = (float) $refund_amount;
        if ($refund_amount <= 0.0) {
            return;
        }

        $txns = (is_array($refunded_txns) && !empty($refunded_txns))
            ? $refunded_txns
            : MeprTransaction::get_all_by_order_id($order->id);

        $eligible = [];
        foreach ($txns as $txn) {
            if (!$txn instanceof MeprTransaction) {
                continue;
            }
            if ((string) $txn->get_meta('stripe_tax_transaction_id', true) === '') {
                continue;
            }
            if ((string) $txn->get_meta('stripe_tax_line_item_id', true) === '') {
                continue;
            }
            if ((float) $txn->total <= 0.0) {
                continue;
            }
            $eligible[] = $txn;
        }

        if ($eligible === []) {
            return;
        }

        $is_per_line = is_array($refunded_txns) && !empty($refunded_txns);
        $share_base  = $is_per_line
            ? (float) $eligible[0]->total
            : (float) $order->total;

        if ($share_base <= 0.0) {
            return;
        }

        $share = $refund_amount / $share_base;

        foreach ($eligible as $txn) {
            $pm = $this->resolve_recording_gateway($txn);
            if (!$pm instanceof MeprStripeGateway) {
                continue;
            }

            $filed_amount = (int) $txn->get_meta('stripe_tax_line_amount', true);
            $filed_tax    = (int) $txn->get_meta('stripe_tax_line_tax_amount', true);
            $amount_cents = (int) round($filed_amount * $share);
            $tax_cents    = (int) round($filed_tax * $share);

            try {
                $this->reverse_filed_line($pm, $txn, $amount_cents, $tax_cents);
            } catch (Exception $e) {
                MeprUtils::debug_log('stripe-tax-refund-failed: ' . $e->getMessage());
            }
        }
    }

    /**
     * Add options to set a tax code on the Advanced tab of the Membership options.
     *
     * @param MeprProduct $product The product object.
     */
    public function display_membership_options(MeprProduct $product): void
    {
        $tax_code        = get_post_meta($product->ID, '_mepr_tax_stripe_tax_code', true);
        $tax_code_custom = get_post_meta($product->ID, '_mepr_tax_stripe_tax_code_custom', true);

        MeprView::render('/admin/products/stripe_tax', get_defined_vars());
    }

    /**
     * Save the per-membership tax code options.
     *
     * @param MeprProduct $product The product object.
     */
    public function save_membership_options(MeprProduct $product): void
    {
        $tax_code        = isset($_POST['_mepr_tax_stripe_tax_code']) ? sanitize_text_field(wp_unslash($_POST['_mepr_tax_stripe_tax_code'])) : '';
        $tax_code_custom = isset($_POST['_mepr_tax_stripe_tax_code_custom']) ? sanitize_text_field(wp_unslash($_POST['_mepr_tax_stripe_tax_code_custom'])) : '';

        update_post_meta($product->ID, '_mepr_tax_stripe_tax_code', $tax_code);
        update_post_meta($product->ID, '_mepr_tax_stripe_tax_code_custom', $tax_code_custom);
    }

    /**
     * Add a site health test for Stripe Tax.
     *
     * The test registers async: the runner makes one Stripe request per
     * connected gateway, so it runs through the Site Health AJAX queue
     * rather than inline during the page load. Core builds the AJAX
     * action as 'health-check-' plus the identifier with only its FIRST
     * underscore replaced, so the identifier ships pre-hyphenated.
     *
     * @param  array $tests The array of site health tests.
     * @return array
     */
    public function add_site_health_test(array $tests): array
    {
        $tests['async']['mepr_stripe_tax_test'] = [
            'label' => __('MemberPress - Stripe Tax Payment Method', 'memberpress'),
            'test'  => 'mepr-stripe-tax-test',
        ];

        return $tests;
    }

    /**
     * Serve the async site health test over the Site Health AJAX queue.
     */
    public function ajax_site_health_test(): void
    {
        check_ajax_referer('health-check-site-status');

        if (!current_user_can('view_site_health_checks')) {
            wp_send_json_error();
        }

        wp_send_json_success($this->run_site_health_test());
    }

    /**
     * Run the check to make sure that the Stripe tax payment method is set properly.
     *
     * @return array
     */
    public function run_site_health_test(): array
    {
        $result = [
            'label'       => __('MemberPress is correctly configured to use Stripe Tax', 'memberpress'),
            'status'      => 'good',
            'badge'       => [
                'label' => __('MemberPress', 'memberpress'),
                'color' => 'blue',
            ],
            'description' => sprintf(
                '<p>%s</p>',
                __('The connection between MemberPress and Stripe Tax is correctly configured.', 'memberpress')
            ),
            'test'        => 'mepr-stripe-tax-test',
            'actions'     => '',
        ];

        $pm = $this->get_payment_method();

        if (!$pm instanceof MeprStripeGateway) {
            $result['label']          = __('MemberPress is not correctly configured to use Stripe Tax', 'memberpress');
            $result['status']         = 'critical';
            $result['badge']['color'] = 'orange';

            $result['description'] = sprintf(
                '<p>%s</p>',
                __('The connection between MemberPress and Stripe Tax is not correctly configured. In the MemberPress settings, select a Stripe payment method to use for Stripe Tax.', 'memberpress')
            );

            $result['actions'] = sprintf(
                '<p><a href="%s">%s</a></p>',
                esc_url(admin_url('admin.php?page=memberpress-options#mepr-taxes')),
                __('Configure MemberPress Taxes', 'memberpress')
            );

            return $result;
        }

        // Stripe Tax must be active on EVERY connected Stripe account. use_automatic_tax()
        // is site-wide, so every connected Stripe gateway issues automatic_tax invoices; an
        // account whose Stripe Tax has lapsed finalization-fails its invoices. Surface any
        // inactive account here before renewals break.
        $mepr_options    = MeprOptions::fetch();
        $payment_methods = array_filter(
            $mepr_options->payment_methods(false),
            function ($pm) {
                return $pm instanceof MeprStripeGateway && $pm->is_connected();
            }
        );

        $inactive_labels = [];

        foreach ($payment_methods as $pm) {
            try {
                $tax_settings = (object) $pm->send_stripe_request('tax/settings', [], 'get');
                $status       = $tax_settings->status ?? 'error';
            } catch (Exception $e) {
                $status = 'error';
            }

            if ($status !== 'active') {
                $inactive_labels[] = $pm->label !== '' ? $pm->label : $pm->id;
            }
        }

        if (!empty($inactive_labels)) {
            $result['label']          = __('Stripe Tax is not active on every connected Stripe account', 'memberpress');
            $result['status']         = 'critical';
            $result['badge']['color'] = 'orange';

            $result['description'] = sprintf(
                '<p>%s</p>',
                sprintf(
                    // Translators: %s is a comma-separated list of Stripe gateway labels.
                    __('MemberPress is configured to use Stripe Tax, but Stripe Tax is not active on these connected Stripe accounts: %s. New checkouts through those payment methods fail with a Stripe error until Stripe Tax is activated.', 'memberpress'),
                    implode(', ', array_map('esc_html', $inactive_labels))
                )
            );

            $result['actions'] = sprintf(
                '<p><a href="%s" target="_blank" rel="noopener noreferrer">%s</a></p>',
                'https://dashboard.stripe.com/settings/tax',
                __('Enable Stripe Tax', 'memberpress')
            );
        }

        return $result;
    }

    /**
     * Display an admin notice if the Stripe Tax connection is not configured correctly.
     */
    public function admin_notice(): void
    {
        if (!MeprUtils::is_memberpress_admin_page() || !MeprUtils::is_logged_in_and_an_admin() || !empty($_POST['mepr_tax_stripe_payment_method'])) {
            return;
        }

        $pm = $this->get_payment_method();

        if ($pm instanceof MeprStripeGateway) {
            return;
        }

        ?>
    <div class="notice notice-warning mepr-notice-dismiss-daily is-dismissible" data-notice="stripe_tax">
      <p>
        <?php
          printf(
            // Translators: %1$s open link tag, %2$s: close link tag.
              esc_html__('The connection between MemberPress and Stripe Tax is not correctly configured. To fix this issue, %1$sclick here%2$s to visit the MemberPress Tax settings, where you can select a Stripe payment method to use for Stripe Tax.', 'memberpress'),
              '<a href="' . esc_url(admin_url('admin.php?page=memberpress-options#mepr-taxes')) . '">',
              '</a>'
          );
        ?>
      </p>
    </div>
        <?php
    }

    /**
     * Display a new feature admin notice for Stripe Tax.
     */
    public function new_feature_admin_notice(): void
    {
        if (
            !MeprUtils::is_memberpress_admin_page() ||
            !MeprUtils::is_logged_in_and_an_admin() ||
            get_option('mepr_tax_stripe_enabled') ||
            get_option('mepr_stripe_tax_notice_dismissed') ||
            get_transient('mepr_dismiss_notice_enable_stripe_tax')
        ) {
            return;
        }

        if (isset($_GET['page']) && $_GET['page'] === 'memberpress-options') {
            return;
        }

        $payment_method_id = $this->get_first_stripe_payment_method_id();

        if (empty($payment_method_id)) {
            return;
        }
        ?>
    <div class="notice notice-info is-dismissible mepr-stripe-tax-notice mepr-notice-dismiss-weekly" data-notice="enable_stripe_tax">
      <div>
        <img src="<?php echo esc_url(MEPR_IMAGES_URL . '/info-icon.jpg'); ?>" alt="" style="width: 30px; height: 30px;">
        <div>
          <p class="mepr-stripe-tax-notice-heading"><?php esc_html_e('MemberPress makes taxes fast and easy! Enable automatic tax rate calculation with the Stripe Tax API.', 'memberpress'); ?></p>
          <p class="mepr-stripe-tax-fine-print">
            <?php
              printf(
                // Translators: %1$s: open link tag, %2$s: close link tag.
                  esc_html__('Stripe Tax API pricing starts at 0.50 USD for each transaction calculated within your registered tax location (includes 10 calculation API calls per transaction; 0.05 USD per additional call). To learn more visit the %1$sStripe Tax pricing page%2$s.', 'memberpress'),
                  '<a href="https://stripe.com/tax#pricing" target="_blank">',
                  '</a>'
              );
            ?>
          </p>
          <p class="mepr-stripe-tax-notice-button-row">
            <button type="button" id="mepr-enable-stripe-tax" class="button button-primary" data-gateway-id="<?php echo esc_attr($payment_method_id); ?>"><?php esc_html_e('Activate Automatic Tax Calculations with Stripe', 'memberpress'); ?></button>
            <a href="#" id="mepr-enable-stripe-tax-no"><?php esc_html_e('I don\'t need to collect taxes', 'memberpress'); ?></a>
          </p>
        </div>
      </div>
    </div>
    <div id="mepr-stripe-tax-no-popup" class="mepr-shared-popup mepr-dialog-hidden">
      <p class="mepr-text-align-center"><?php esc_html_e('Great, if this ever changes you can easily enable this in Settings &rarr; Taxes.', 'memberpress'); ?></p>
    </div>
    <div id="mepr-stripe-tax-enabled-popup" class="mepr-shared-popup mepr-dialog-hidden">
      <h2 class="mepr-text-align-center"><?php esc_html_e('Stripe Tax is now enabled', 'memberpress'); ?></h2>
      <p class="mepr-text-align-center">
          <?php
            printf(
            // Translators: %1$s: open link tag, %2$s: close link tag.
                esc_html__('In the Stripe dashboard, please ensure that a %1$sRegistration is added%2$s for each location where tax should be collected.', 'memberpress'),
                '<a href="https://dashboard.stripe.com/tax/registrations" target="_blank">',
                '</a>'
            );
            ?>
      </p>
    </div>
    <div id="mepr-stripe-tax-inactive-popup" class="mepr-shared-popup mepr-dialog-hidden">
      <h2 class="mepr-text-align-center"><?php esc_html_e('Stripe Tax could not be enabled', 'memberpress'); ?></h2>
      <p class="mepr-text-align-center">
        <?php
          printf(
            // Translators: %1$s: open link tag, %2$s: close link tag, %3$s: open link tag, %4$s: close link tag.
              esc_html__('In the Stripe dashboard, please ensure that %1$sStripe Tax is enabled%2$s and that a %3$sRegistration is added%4$s for each location where tax should be collected.', 'memberpress'),
              '<a href="https://dashboard.stripe.com/tax" target="_blank">',
              '</a>',
              '<a href="https://dashboard.stripe.com/tax/registrations" target="_blank">',
              '</a>'
          );
        ?>
      </p>
      <p class="mepr-text-align-center">
        <?php esc_html_e('If you have more than one Stripe payment method, you can configure which payment method to use for Stripe Tax at MemberPress &rarr; Settings &rarr; Taxes.', 'memberpress'); ?>
      </p>
    </div>
        <?php
    }

    /**
     * Display an admin notice if Stripe Tax was deactivated.
     */
    public function deactivated_admin_notice(): void
    {
        if (
            !MeprUtils::is_memberpress_admin_page() ||
            !MeprUtils::is_logged_in_and_an_admin() ||
            !get_option('mepr_tax_stripe_deactivated') ||
            get_user_meta(get_current_user_id(), 'mepr_dismiss_notice_deactivated_stripe_tax', true) ||
            (isset($_GET['page']) && $_GET['page'] === 'memberpress-options')
        ) {
            return;
        }
        ?>
    <div class="notice notice-warning is-dismissible mepr-notice-dismiss-permanently" data-notice="deactivated_stripe_tax">
      <p>
        <?php
          printf(
            // Translators: %1$s open link tag, %2$s: close link tag, %3$s open link tag, %4$s: close link tag.
              esc_html__('Stripe Tax was deactivated because it is not enabled in the Stripe dashboard. Please ensure that %1$sStripe Tax is enabled%2$s at Stripe, then go to %3$sMemberPress &rarr; Settings &rarr; Taxes%4$s to reactivate Stripe Tax.', 'memberpress'),
              '<a href="https://dashboard.stripe.com/tax" target="_blank">',
              '</a>',
              sprintf('<a href="%s">', esc_url(admin_url('admin.php?page=memberpress-options#mepr-taxes'))),
              '</a>'
          );
        ?>
      </p>
    </div>
        <?php
    }

    /**
     * Dismiss the Stripe Tax notice.
     */
    public function dismiss_stripe_tax_notice(): void
    {
        if (
            !MeprUtils::is_logged_in_and_an_admin() ||
            !check_ajax_referer('mepr_dismiss_notice', false, false)
        ) {
            wp_send_json_error();
        }

        update_option('mepr_stripe_tax_notice_dismissed', true);

        wp_send_json_success();
    }

    /**
     * Enable Stripe Tax.
     */
    public function enable_stripe_tax(): void
    {
        if (
            !MeprUtils::is_logged_in_and_an_admin() ||
            !check_ajax_referer('mepr_enable_stripe_tax', false, false)
        ) {
            wp_send_json_error(__('Security check failed.', 'memberpress'));
        }

        $gateway_id = isset($_POST['gateway_id']) ? sanitize_text_field(wp_unslash($_POST['gateway_id'])) : '';

        if (empty($gateway_id)) {
            wp_send_json_error(__('Bad request.', 'memberpress'));
        }

        $mepr_options = MeprOptions::fetch();

        $pm = $mepr_options->payment_method($gateway_id);

        if (!$pm instanceof MeprStripeGateway || !$pm->is_connected()) {
            wp_send_json_error(__('Bad request.', 'memberpress'));
        }

        try {
            $tax_settings = (object) $pm->send_stripe_request('tax/settings', [], 'get');

            if ($tax_settings->status !== 'active') {
                wp_send_json_error(false);
            }

            update_option('mepr_calculate_taxes', true);
            update_option('mepr_tax_stripe_enabled', true);
            update_option('mepr_tax_calc_location', 'customer');
            update_option('mepr_tax_default_address', 'none');
            update_option('mepr_tax_stripe_payment_method', $pm->id);
            update_option('mepr_stripe_tax_notice_dismissed', true);
            update_option('mepr_tax_avalara_enabled', false);
            update_option('mepr_tax_quaderno_enabled', false);
            update_option('mepr_tax_taxjar_enabled', false);
            delete_option('mepr_tax_stripe_deactivated');

            wp_send_json_success();
        } catch (Exception $e) {
            wp_send_json_error($e->getMessage());
        }
    }

    /**
     * Validate that Stripe Tax is active on the supplied Stripe gateway.
     *
     * Used by the per-gateway opt-in checkbox and by the global picker change
     * handler in legacy mode. Non-legacy enable validation goes through
     * `validate_stripe_tax_all_gateways()` below.
     */
    public function validate_stripe_tax(): void
    {
        if (
            !MeprUtils::is_logged_in_and_an_admin() ||
            !check_ajax_referer('mepr_validate_stripe_tax', false, false)
        ) {
            wp_send_json_error(__('Security check failed.', 'memberpress'));
        }

        $gateway_id = isset($_POST['gateway_id']) ? sanitize_text_field(wp_unslash($_POST['gateway_id'])) : '';

        if (empty($gateway_id)) {
            wp_send_json_error(__('Bad request.', 'memberpress'));
        }

        $mepr_options = MeprOptions::fetch();

        $pm = $mepr_options->payment_method($gateway_id);

        if (!$pm instanceof MeprStripeGateway || !$pm->is_connected()) {
            wp_send_json_error(__('Bad request.', 'memberpress'));
        }

        try {
            $tax_settings = (object) $pm->send_stripe_request('tax/settings', [], 'get');

            wp_send_json_success($tax_settings->status === 'active');
        } catch (Exception $e) {
            wp_send_json_error($e->getMessage());
        }
    }

    /**
     * Validate that Stripe Tax is active on every connected Stripe gateway.
     *
     * Used in non-legacy mode when the merchant ticks "Enable Stripe Tax",
     * because that single switch forces automatic_tax on for every Stripe
     * gateway site-wide. Returns success(false) on the first inactive
     * account; success(true) only when every account passes.
     */
    public function validate_stripe_tax_all_gateways(): void
    {
        if (
            !MeprUtils::is_logged_in_and_an_admin() ||
            !check_ajax_referer('mepr_validate_stripe_tax_all_gateways', false, false)
        ) {
            wp_send_json_error(__('Security check failed.', 'memberpress'));
        }

        $mepr_options    = MeprOptions::fetch();
        $payment_methods = array_filter(
            $mepr_options->payment_methods(false),
            function ($pm) {
                return $pm instanceof MeprStripeGateway && $pm->is_connected();
            }
        );

        if (empty($payment_methods)) {
            wp_send_json_error(__('No connected Stripe gateways.', 'memberpress'));
        }

        try {
            foreach ($payment_methods as $pm) {
                $tax_settings = (object) $pm->send_stripe_request('tax/settings', [], 'get');

                if ($tax_settings->status !== 'active') {
                    wp_send_json_success(false);
                }
            }

            wp_send_json_success(true);
        } catch (Exception $e) {
            wp_send_json_error($e->getMessage());
        }
    }
}

new MeprStripeTaxIntegration();
