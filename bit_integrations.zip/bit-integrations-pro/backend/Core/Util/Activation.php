<?php

namespace BitApps\IntegrationsPro\Core\Util;

use BitApps\IntegrationsPro\Config;
use BitApps\IntegrationsPro\Core\Database\DB;
use WP_Site;

/**
 * Class handling plugin activation.
 *
 * @since 1.0.0
 */
final class Activation
{
    public function activate()
    {
        add_action('bit_integrations_pro_activation', [$this, 'install']);
    }

    public function install($network_wide)
    {
        if ($network_wide && \function_exists('is_multisite') && is_multisite()) {
            $sites = Multisite::all_blog_ids();
            foreach ($sites as $site) {
                switch_to_blog($site);
                $this->installAsSingleSite();
                if ($network_wide) {
                    activate_plugin(plugin_basename(Config::get('MAIN_FILE')));
                }
                restore_current_blog();
            }
        } else {
            $this->installAsSingleSite();
        }
    }

    public function installAsSingleSite()
    {
        $installed = Config::getOption('installed');
        if ($installed) {
            $oldVersion = Config::getOption('version');
        }
        if (!$installed || version_compare($oldVersion, Config::VERSION, '!=')) {
            DB::migrate();
            Config::updateOption('installed', time());
        }
        Config::updateOption('version', Config::VERSION);
        update_option('btcbi_action_hook_test_data', []);
    }

    public static function handle_new_site(WP_Site $new_site)
    {
        switch_to_blog($new_site->blog_id);
        $plugin = plugin_basename(Config::get('MAIN_FILE'));
        if (is_plugin_active_for_network($plugin)) {
            activate_plugin($plugin);
        } else {
            do_action('bit_integrations_pro_activation');
        }
        restore_current_blog();
    }
}
