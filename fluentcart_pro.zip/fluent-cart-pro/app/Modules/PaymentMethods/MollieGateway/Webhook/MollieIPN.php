<?php

namespace FluentCartPro\App\Modules\PaymentMethods\MollieGateway\Webhook;

use FluentCart\App\Events\Subscription\SubscriptionRenewalFailed;
use FluentCart\App\Services\Payments\Refund;
use FluentCart\App\Helpers\Status;
use FluentCart\App\Models\Order;
use FluentCart\App\Models\OrderTransaction;
use FluentCart\App\Models\Subscription;
use FluentCart\App\Helpers\StatusHelper;
use FluentCart\Framework\Support\Arr;
use FluentCartPro\App\Modules\PaymentMethods\MollieGateway\API\MollieAPI;
use FluentCartPro\App\Modules\PaymentMethods\MollieGateway\Confirmations;
use FluentCartPro\App\Modules\PaymentMethods\MollieGateway\MollieSettingsBase;
use FluentCartPro\App\Modules\PaymentMethods\MollieGateway\MollieHelper;

class MollieIPN
{
    public function init(): void
    {
        // Primary payment webhook handlers
        add_action('fluent_cart/payments/mollie/webhook_payment_authorized', [$this, 'handlePaymentAuthorized'], 10, 1);
        add_action('fluent_cart/payments/mollie/webhook_payment_paid', [$this, 'handlePaymentPaid'], 10, 1);
        add_action('fluent_cart/payments/mollie/webhook_payment_failed', [$this, 'handlePaymentFailed'], 10, 1);
        add_action('fluent_cart/payments/mollie/webhook_payment_canceled', [$this, 'handlePaymentCanceled'], 10, 1);
        add_action('fluent_cart/payments/mollie/webhook_payment_expired', [$this, 'handlePaymentExpired'], 10, 1);
        add_action('fluent_cart/payments/mollie/webhook_payment_refunded', [$this, 'handlePaymentRefunded'], 10, 1);

        // Subscription related webhook handlers
        add_action('fluent_cart/payments/mollie/webhook_subscription_payment_paid', [$this, 'handleSubscriptionPaymentPaid'], 10, 1);
        add_action('fluent_cart/payments/mollie/webhook_subscription_payment_failed', [$this, 'handleSubscriptionPaymentFailed'], 10, 1);
        add_action('fluent_cart/payments/mollie/webhook_subscription_payment_expired', [$this, 'handleSubscriptionPaymentFailed'], 10, 1);
        add_action('fluent_cart/payments/mollie/webhook_subscription_payment_canceled', [$this, 'handleSubscriptionPaymentFailed'], 10, 1);

    }

    public function verifyAndProcess()
    {
        // Get webhook data
        $webhookData = (new MollieAPI())->verifyIPN();
        
        if (is_wp_error($webhookData)) {
            $this->sendResponse(400, $webhookData->get_error_message());
        }

        $paymentId = $webhookData->id ?? '';

        if (!$paymentId) {
            $this->sendResponse(400, 'Invalid payment ID');
        }

        $molliePayment = (new MollieAPI())->getMollieObject('payments/' . $paymentId, ['embed' => 'refunds']);

        if (is_wp_error($molliePayment)) {
            $this->sendResponse(400, 'Unable to fetch payment from Mollie');
        }

        // Get order from metadata
        $orderHash = Arr::get($molliePayment, 'metadata.order_hash');

        $order = Order::query()->where('uuid', $orderHash)->first();

        if (!$order) {
            $this->sendResponse(404, 'Order not found');
        }

        $status = Arr::get($molliePayment, 'status');

        // Check for refunds when fetching the payment
        $refunds = Arr::get($molliePayment, '_embedded.refunds', []);

        if (!empty($refunds)) {
            return $this->handlePaymentRefunded([
                'mollie_payment' => $molliePayment,
                'order'   => $order,
            ]);
        }

        $subscriptionId = Arr::get($molliePayment, 'subscriptionId');
        if ($subscriptionId) {
            $eventName = 'webhook_subscription_payment_' . $status;
            if (has_action('fluent_cart/payments/mollie/' . $eventName)) {
                do_action('fluent_cart/payments/mollie/' . $eventName, [
                    'mollie_payment' => $molliePayment,
                    'order'   => $order,
                ]);
                $this->sendResponse(200, 'Webhook processed successfully');
            }
            $this->sendResponse(200, 'Webhook received but no handler found for subscription payment ' . $status);
        }

        // Process based on status
        $eventName = 'webhook_payment_' . $status;
        
        if (has_action('fluent_cart/payments/mollie/' . $eventName)) {
            do_action('fluent_cart/payments/mollie/' . $eventName, [
                'mollie_payment' => $molliePayment,
                'order'   => $order,
            ]);

            $this->sendResponse(200, 'Webhook processed successfully');
        }

        // Log unhandled webhook status
        fluent_cart_add_log(
            'Mollie webhook unhandled status',
            sprintf('Status: %s for Payment ID: %s', $status, $paymentId),
            'info',
            [
                'log_type' => 'webhook',
                'module_type' => 'FluentCartPro\App\Modules\PaymentMethods\MollieGateway',
                'module_name' => 'Mollie',
                'payment_id' => $paymentId
            ]
        );

        $this->sendResponse(200, 'Webhook received but no handler found for status: ' . $status);
    }

    public function handlePaymentPaid($data)
    {
        $molliePayment = Arr::get($data, 'mollie_payment');
        $order = Arr::get($data, 'order');

        if (!$order) {
            return false;
        }

        $paymentId = Arr::get($molliePayment, 'id');

        $transactionHash = Arr::get($molliePayment, 'metadata.transaction_hash');

        $query = OrderTransaction::query()
            ->where('vendor_charge_id', $paymentId);
            
        if (!empty($transactionHash)) {
            $query->orWhere('uuid', $transactionHash);
        }
        
        $transactionModel = $query->first();

        if (!$transactionModel) {
           $subscriptionId = Arr::get($molliePayment, 'subscriptionId');

           if ($subscriptionId) {
               return $this->handleSubscriptionPaymentPaid($data);
           }
           return false;
        }

        if ($transactionModel->status === Status::TRANSACTION_SUCCEEDED) {
            // A different paid Mollie payment id landing here is a second, separate
            // charge for this transaction — must not be silently dropped.
            if ($transactionModel->vendor_charge_id && $transactionModel->vendor_charge_id !== $paymentId) {
                self::flagDuplicateSuccessfulPayment($transactionModel, $molliePayment);
            }

            if ($transactionModel->subscription_id) {
                (new Confirmations())->maybeRecoverMissingSubscription($transactionModel, $molliePayment);
            }
            (new StatusHelper($transactionModel->order))->syncOrderStatuses($transactionModel);
            return true;
        }

        // Checked before a mandate can start a Mollie subscription
        if (!(new Confirmations())->chargeMatchesTransaction($transactionModel, $order, $molliePayment, $paymentId)) {
            return false;
        }

        $mandateId = Arr::get($molliePayment, 'mandateId');

        $subscriptionData = [];
        if ($mandateId && $transactionModel->subscription_id) {
            $subscriptionModel = Subscription::query()->where('id', $transactionModel->subscription_id)->first();
            if ($subscriptionModel && !MollieHelper::currentVendorSubscriptionId($subscriptionModel, $transactionModel)) {
                $billingInfo = [
                    'method' => Arr::get($molliePayment, 'method'),
                    'brand' => Arr::get($molliePayment, 'details.cardLabel'),
                    'last4' => Arr::get($molliePayment, 'details.cardNumber'),
                    'token' => Arr::get($molliePayment, 'details.cardToken'),
                    'mandate_id' => $mandateId
                ];
        
                $subscriptionData = (new Confirmations())->handleSubscriptionCreation($transactionModel, [
                    'mandate_id' => $mandateId,
                    'billingInfo' => $billingInfo
                ]);
                
            }
        }

        (new Confirmations())->confirmPaymentSuccessByCharge($transactionModel, [
            'vendor_charge_id' => $paymentId,
            'charge' => $molliePayment,
            'subscription_data' => $subscriptionData
        ]);

        return true;
    }

    public function handleSubscriptionPaymentPaid($data)
    {
        $molliePayment = Arr::get($data, 'mollie_payment');
        $order = Arr::get($data, 'order');

        if (!$order) {
            return false;
        }

        $mollieSubscriptionId = Arr::get($molliePayment, 'subscriptionId');

        if (!$mollieSubscriptionId) {
            return false;
        }

        $subscriptionModel = Subscription::query()->where('vendor_subscription_id', $mollieSubscriptionId)->first();

        if (!$subscriptionModel) {
            $subscriptionModel = Subscription::query()->where('parent_order_id', $order->id)->first();
        }

        if (!$subscriptionModel) {
            return false;
        }

        $subscriptionModel->reSyncFromRemote();

        return true;
    }

    public function handleSubscriptionPaymentFailed($data)
    {
        $molliePayment = Arr::get($data, 'mollie_payment');
        $order = Arr::get($data, 'order');

        if (!$order) {
            return false;
        }

        $mollieSubscriptionId = Arr::get($molliePayment, 'subscriptionId');

        if (!$mollieSubscriptionId) {
            return false;
        }

        $subscriptionModel = Subscription::query()->where('vendor_subscription_id', $mollieSubscriptionId)->first();

        if (!$subscriptionModel) {
            $subscriptionModel = Subscription::query()->where('parent_order_id', $order->id)->first();
        }

        if (!$subscriptionModel) {
            return false;
        }

        $paymentStatus = Arr::get($molliePayment, 'status', 'failed');

        $subscriptionModel->addLog(
            __('Subscription Payment Failed', 'fluent-cart-pro'),
            sprintf(__('Recurring payment %s via Mollie (Payment ID: %s)', 'fluent-cart-pro'), $paymentStatus, Arr::get($molliePayment, 'id')),
            'error'
        );

        fluent_cart_error_log(
            'Mollie Subscription Payment Failed',
            sprintf('Subscription %s payment %s. Payment ID: %s', $subscriptionModel->id, $paymentStatus, Arr::get($molliePayment, 'id')),
            [
                'module_name' => 'subscription',
                'module_id'   => $subscriptionModel->id,
                'log_type'    => 'webhook',
            ]
        );

        if ($paymentStatus !== 'canceled' && $subscriptionModel->current_payment_method === 'mollie') {
            $this->notifyRenewalFailed($subscriptionModel, $order, $molliePayment);
        }

        $subscriptionModel->reSyncFromRemote();

        return true;
    }

    private function notifyRenewalFailed(Subscription $subscriptionModel, Order $order, array $molliePayment): void
    {
        $paymentId = (string) Arr::get($molliePayment, 'id', '');

        if (!preg_match('/^tr_[a-zA-Z0-9]+$/', $paymentId)) {
            return;
        }

        // Mollie redelivers the same payment until it gets a 2xx; notify once per payment.
        $claimKey = 'fct_sub_renewal_failed_' . $subscriptionModel->id . '_' . $paymentId;
        if (!add_option($claimKey, '1', '', false)) {
            return;
        }

        // Card payments report failureMessage; SEPA Direct Debit reports bankReason.
        $error = (string) (Arr::get($molliePayment, 'details.failureMessage') ?: Arr::get($molliePayment, 'details.bankReason', ''));
        if (!$error) {
            /* translators: %1$s is the Mollie payment ID */
            $error = sprintf(__('Mollie reported a failed renewal payment (Payment ID: %1$s).', 'fluent-cart-pro'), $paymentId);
        }

        $currency = strtoupper((string) Arr::get($molliePayment, 'amount.currency', ''));
        $renewalPayment = [
            'amount'   => MollieHelper::convertToCents(Arr::get($molliePayment, 'amount.value', 0), $currency),
            'currency' => $currency,
        ];

        try {
            (new SubscriptionRenewalFailed($subscriptionModel, $order, $order->customer, $error, $renewalPayment))->dispatch();
        } catch (\Throwable $e) {
            delete_option($claimKey);
            throw $e;
        }
    }

    public function handlePaymentCanceled($data)
    {
        return $this->handlePaymentFailed($data, 'canceled');
    }

    public function handlePaymentExpired($data)
    {
        return $this->handlePaymentFailed($data, 'expired');
    }

    public function handlePaymentAuthorized($data)
    {
        $molliePayment = Arr::get($data, 'mollie_payment');
        $order = Arr::get($data, 'order');

        if (!$order) {
            return false;
        }

        $paymentId = Arr::get($molliePayment, 'id');
        
        // Get metadata for transaction lookup
        $transactionHash = Arr::get($molliePayment, 'metadata.transaction_hash');

        // Find transaction by payment ID
        $query = OrderTransaction::query()
            ->where('vendor_charge_id', $paymentId);
            
        if (!empty($transactionHash)) {
            $query->orWhere('uuid',  $transactionHash);
        }
        
        $transactionModel = $query->first();

        if (!$transactionModel) {
            return false;
        }

        if ($transactionModel->status === Status::TRANSACTION_SUCCEEDED || $transactionModel->status === Status::TRANSACTION_AUTHORIZED) {
            if ($transactionModel->vendor_charge_id && $transactionModel->vendor_charge_id !== $paymentId) {
                self::flagDuplicateSuccessfulPayment($transactionModel, $molliePayment);
            }
            (new StatusHelper($transactionModel->order))->syncOrderStatuses($transactionModel);
            return false;
        }

        if (!(new Confirmations())->chargeMatchesTransaction($transactionModel, $order, $molliePayment, $paymentId)) {
            return false;
        }

        $mandateId = Arr::get($molliePayment, 'mandateId');

        $subscriptionData = [];
        if ($mandateId && $transactionModel->subscription_id) {
            $subscriptionModel = Subscription::query()->where('id', $transactionModel->subscription_id)->first();
            if ($subscriptionModel && !MollieHelper::currentVendorSubscriptionId($subscriptionModel, $transactionModel)) {
                $billingInfo = [
                    'method' => Arr::get($molliePayment, 'method'),
                    'brand' => Arr::get($molliePayment, 'details.cardLabel'),
                    'last4' => Arr::get($molliePayment, 'details.cardNumber'),
                    'token' => Arr::get($molliePayment, 'details.cardToken'),
                    'mandate_id' => $mandateId
                ];
                $subscriptionData = (new Confirmations())->handleSubscriptionCreation($transactionModel, [
                    'mandate_id' => $mandateId,
                    'billingInfo' => $billingInfo
                ]);
            }
        }

        return (new Confirmations())->authorizePaymentByCharge($transactionModel, [
            'vendor_charge_id' => $paymentId,
            'charge' => $molliePayment,
            'subscription_data' => $subscriptionData
        ]);
    }

    public function handlePaymentFailed($data, $reason = 'failed')
    {
        $molliePayment = Arr::get($data, 'mollie_payment');
        $order = Arr::get($data, 'order');

        if (!$order) {
            return false;
        }

        $transactionHash = Arr::get($molliePayment, 'metadata.transaction_hash');

        $paymentId = Arr::get($molliePayment, 'id');

        $query = OrderTransaction::query()
            ->where('vendor_charge_id', $paymentId)
            ->with('order');

        if (!empty($transactionHash)) {
            $query->orWhere('uuid', $transactionHash);
        }

        $transactionModel = $query->first();

        if (!$transactionModel) {
            return false;
        }

        $order = $transactionModel->order;

        if (!$order) {
            return false;
        }

        $oldStatus = $order->payment_status;

        if (!in_array($transactionModel->status, [Status::TRANSACTION_AUTHORIZED, Status::TRANSACTION_PENDING])) {
            return false;
        }

        $transactionData = [
            'status' => Status::TRANSACTION_FAILED,
            'meta'   => array_merge($transactionModel->meta ?? [], [
                'failure_reason' => $reason,
                'mollie_status'  => $reason
            ])
        ];

        $transactionModel->fill($transactionData);
        $transactionModel->save();

        $order->update([
            'payment_status' => Status::PAYMENT_FAILED,
            'status'         => Status::ORDER_FAILED
        ]);

        /* translators: 1: Mollie payment status, e.g. failed, expired, canceled */
        $viaMollieMessage = sprintf(__('Payment %1$s via Mollie', 'fluent-cart-pro'), $reason);

        fluent_cart_error_log(
            'Payment ' . $reason,
            $viaMollieMessage,
            [
                'module_name' => 'order',
                'module_id'   => $order->id,
                'log_type'    => 'payment'
            ]
        );

        if ($transactionModel->subscription_id) {
            $subscription = Subscription::query()->find($transactionModel->subscription_id);
            if ($subscription) {
                /* translators: 1: Mollie payment status, e.g. failed, expired, canceled */
                $subscription->addLog(sprintf(__('Payment %1$s', 'fluent-cart-pro'), $reason), $viaMollieMessage, 'error');
            }
        }

        do_action('fluent_cart/payment_failed', [
            'order'   => $order,
            'transaction' => $transactionModel,
            'old_payment_status' => $oldStatus,
            'new_payment_status' => Status::PAYMENT_FAILED,
            'reason' => $reason
        ]);

        return true;
    }

    public function handlePaymentRefunded($data)
    {
        $molliePayment = Arr::get($data, 'mollie_payment');

        $paymentId = Arr::get($molliePayment, 'id');

        // Get parent transaction
        $parentTransaction = OrderTransaction::query()
            ->where('vendor_charge_id', $paymentId)
            ->where('status', Status::TRANSACTION_SUCCEEDED)
            ->with('order')
            ->first();

        if (!$parentTransaction) {
            return false;
        }

        $order = $parentTransaction->order;

        if (!$order) {
            return false;
        }

        // Get refunds from payment
        $refunds = Arr::get($molliePayment, '_embedded.refunds', []);

        if (empty($refunds)) {
            return false;
        }

        foreach ($refunds as $refund) {
            $refundId = Arr::get($refund, 'id');
            $refundAmount = Arr::get($refund, 'amount.value');
            $refundCurrency = Arr::get($refund, 'amount.currency');
            $refundStatus = Arr::get($refund, 'status');
            $amountInCents = MollieHelper::convertToCents($refundAmount, $refundCurrency);

            // Mirror flagDuplicateSuccessfulPayment: map the real refund status instead
            // of assuming 'refunded', a redelivery carries a still-pending one forward.
            $refundData = [
                'order_id'           => $order->id,
                'transaction_type'   => Status::TRANSACTION_TYPE_REFUND,
                'status'             => MollieHelper::getCorrectTransactionStatus($refundStatus),
                'payment_method'     => 'mollie',
                'payment_mode'       => $parentTransaction->payment_mode,
                'vendor_charge_id'   => $refundId,
                'total'              => $amountInCents,
                'currency'           => $refundCurrency,
                'meta'               => [
                    'parent_id'          => $parentTransaction->id,
                    'refund_description' => Arr::get($refund, 'description', ''),
                    'refund_source'      => 'webhook'
                ]
            ];

            $recordedRefund = Refund::createOrRecordRefund($refundData, $parentTransaction);

            if (is_wp_error($recordedRefund) && $recordedRefund->get_error_code() === 'refund_lock_timeout') {
                $this->sendResponse(503, $recordedRefund->get_error_message());
            }
        }

        return true;
    }

    /**
     * A second Mollie payment reported paid/authorized for a transaction that already
     * settled under a different payment id. Flags it for manual admin review instead of
     * auto-refunding/canceling at Mollie — rare edge case, not worth the remote-call
     * complexity. `duplicate_mollie_payments` meta dedupes so a webhook redelivery
     * doesn't log the same duplicate twice.
     */
    private static function flagDuplicateSuccessfulPayment($transactionModel, $duplicateMolliePayment)
    {
        $duplicatePaymentId = Arr::get($duplicateMolliePayment, 'id');
        $duplicateStatus = Arr::get($duplicateMolliePayment, 'status');

        $handledDuplicates = Arr::get($transactionModel->meta ?: [], 'duplicate_mollie_payments', []);

        if (Arr::get($handledDuplicates, $duplicatePaymentId . '.status')) {
            return;
        }

        fluent_cart_error_log(
            'Mollie duplicate successful payment detected — needs manual refund/cancellation',
            sprintf(
                'Transaction %s already settled by payment %s. Payment %s also reports %s for the same transaction — review and refund/cancel it manually in the Mollie dashboard.',
                $transactionModel->uuid,
                $transactionModel->vendor_charge_id,
                $duplicatePaymentId,
                $duplicateStatus
            ),
            [
                'module_name' => 'order',
                'module_id'   => $transactionModel->order_id,
                'log_type'    => 'payment'
            ]
        );

        $handledDuplicates[$duplicatePaymentId] = ['status' => 'flagged_for_manual_review'];

        $transactionModel->update([
            'meta' => array_merge($transactionModel->meta ?? [], [
                'duplicate_mollie_payments' => $handledDuplicates
            ])
        ]);
    }

    protected function sendResponse($statusCode = 200, $message = 'Success')
    {
        http_response_code($statusCode);
        echo json_encode([
            'message' => $message,
        ]);

        exit;
    }
}

