<?php

if (! defined('ABSPATH')) {
	exit; // Exit if accessed directly.
}
?>
<div class="sb-customizer-preview" :data-preview-device="customizerScreens.previewScreen">
	<?php

		/**
		 * CFF Admin Notices
		 *
		 * @since 4.0
		 */

		do_action('cff_admin_notices');
	?>
	<div class="sb-preview-ctn sb-tr-2">
		<?php include_once CFF_BUILDER_DIR . 'templates/preview/events-notice.php'; ?>
		<div class="sb-preview-top-chooser cff-fb-fs">
			<strong>{{genericText.preview}}</strong>
			<div class="sb-preview-chooser" role="group" aria-label="<?php esc_attr_e( 'Preview device', 'custom-facebook-feed' ); ?>">
				<button class="sb-preview-chooser-btn" v-for="device in previewScreens" v-bind:class="'sb-' + device" v-html="svgIcons[device]" @click.prevent.default="switchCustomizerPreviewDevice(device)" :aria-label="device" :aria-pressed="customizerScreens.previewScreen == device ? 'true' : 'false'" :data-active="customizerScreens.previewScreen == device"></button>
			</div>
		</div>

		<div class="cff-preview-ctn cff-fb-fs" :class="(customizerFeedData.settings.feedtheme ? 'cff-' + customizerFeedData.settings.feedtheme : ' cff-default_theme')" :class="( !valueIsEnabled(customizerFeedData.settings.headeroutside) && !valueIsEnabled(customizerFeedData.settings.likeboxoutside) ) ? 'cff-feed-height' : ''" :data-preview-colorscheme="customizerFeedData.settings.colorpalette">
			<?php
			include_once CFF_BUILDER_DIR . 'templates/preview/error.php';
			include_once CFF_BUILDER_DIR . 'templates/preview/header.php';
			?>
			<div class="cff-fb-fs" :class="( valueIsEnabled(customizerFeedData.settings.headeroutside) && !valueIsEnabled(customizerFeedData.settings.likeboxoutside) ) ? 'cff-feed-height' : ''" >
				<cff-post-likebox-component v-if="customizerFeedData.settings.likeboxpos == 'top'" :customizer-feed-data="customizerFeedData"  :translated-text="translatedText"></cff-post-likebox-component>

				<div class="cff-fb-fs" :class="( valueIsEnabled(customizerFeedData.settings.headeroutside) && valueIsEnabled(customizerFeedData.settings.likeboxoutside) ) ? 'cff-feed-height' : ''" >
					<?php
						include_once CFF_BUILDER_DIR . 'templates/preview/timeline.php';

						include_once CFF_BUILDER_DIR . 'templates/preview/post-types/photos.php';
						include_once CFF_BUILDER_DIR . 'templates/preview/post-types/albums.php';
						include_once CFF_BUILDER_DIR . 'templates/preview/post-types/videos.php';
						include_once CFF_BUILDER_DIR . 'templates/preview/post-types/reviews.php';
						include_once CFF_BUILDER_DIR . 'templates/preview/post-types/events.php';
						include_once CFF_BUILDER_DIR . 'templates/preview/post-types/single-holder.php';

						include_once CFF_BUILDER_DIR . 'templates/preview/load-more.php';
					?>
				</div>

				<cff-post-likebox-component v-if="customizerFeedData.settings.likeboxpos == 'bottom'" v-if="" :customizer-feed-data="customizerFeedData"  :translated-text="translatedText"></cff-post-likebox-component>



			</div>

			<?php
				include_once CFF_BUILDER_DIR . 'templates/preview/like-box.php';
				include_once CFF_BUILDER_DIR . 'templates/preview/preview-components.php';
				include_once CFF_BUILDER_DIR . 'templates/preview/light-box.php';
			?>
		</div>
	</div>
	<cff-post-lightbox-component :single-post="lightBox.post" :light-box="lightBox" :customizer-feed-data="customizerFeedData"  :translated-text="translatedText"></cff-post-lightbox-component>
	<cff-post-dummy-lightbox-component :dummy-light-box-data="dummyLightBoxData" :light-box="lightBox" :customizer-feed-data="customizerFeedData"  :translated-text="translatedText"></cff-post-dummy-lightbox-component>
</div>
