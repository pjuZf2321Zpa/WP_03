<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Actions\ModernCart\ModernCartProHelper;
use BitApps\IntegrationsPro\Config;
use BitApps\IntegrationsPro\Core\Util\Hooks;

Hooks::filter(Config::withFreePrefix('modern_cart_add_product_to_cart'), [ModernCartProHelper::class, 'addProductToCart'], 10, 3);
Hooks::filter(Config::withFreePrefix('modern_cart_update_cart_quantity'), [ModernCartProHelper::class, 'updateCartQuantity'], 10, 3);
Hooks::filter(Config::withFreePrefix('modern_cart_remove_product_from_cart'), [ModernCartProHelper::class, 'removeProductFromCart'], 10, 3);
