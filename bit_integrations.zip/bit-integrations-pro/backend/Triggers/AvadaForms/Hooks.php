<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Core\Util\Hooks;
use BitApps\IntegrationsPro\Triggers\AvadaForms\AvadaFormsController;

Hooks::add('fusion_form_submission_data', [AvadaFormsController::class, 'handleFormSubmission'], 10, 2);
