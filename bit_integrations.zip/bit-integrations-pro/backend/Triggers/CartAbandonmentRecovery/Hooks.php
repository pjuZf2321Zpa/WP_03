<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Core\Util\Hooks;
use BitApps\IntegrationsPro\Triggers\CartAbandonmentRecovery\CartAbandonmentRecoveryController;

Hooks::add('wcf_ca_after_save_abandonment_data', [CartAbandonmentRecoveryController::class, 'cartAbandonmentDataCaptured'], 20, 2);
Hooks::add('wcf_ca_process_abandoned_order', [CartAbandonmentRecoveryController::class, 'cartMarkedAsAbandoned'], 20, 1);
Hooks::add('wcf_ca_after_email_sent', [CartAbandonmentRecoveryController::class, 'recoveryEmailSent'], 20, 2);
Hooks::add('wcf_ca_after_coupon_created', [CartAbandonmentRecoveryController::class, 'recoveryCouponCreated'], 20, 2);
Hooks::add('wcar_after_unsubscribe_cart_abandonment_emails', [CartAbandonmentRecoveryController::class, 'unsubscribedFromRecoveryEmails'], 20, 1);
