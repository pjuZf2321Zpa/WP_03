<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Actions\B2BKing\B2BKingRecordHelper;
use BitApps\IntegrationsPro\Config;
use BitApps\IntegrationsPro\Core\Util\Hooks;

Hooks::filter(Config::withFreePrefix('b2bking_update_customer_group'), [B2BKingRecordHelper::class, 'updateCustomerGroup'], 10, 3);
Hooks::filter(Config::withFreePrefix('b2bking_approve_customer'), [B2BKingRecordHelper::class, 'approveCustomer'], 10, 2);
Hooks::filter(Config::withFreePrefix('b2bking_enable_b2b_for_user'), [B2BKingRecordHelper::class, 'enableB2BForUser'], 10, 2);
