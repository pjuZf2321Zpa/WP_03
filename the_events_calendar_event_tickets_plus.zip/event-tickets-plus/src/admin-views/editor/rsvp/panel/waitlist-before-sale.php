<?php
/**
 * RSVP V2 Waitlist Before Sale toggle template.
 *
 * @since 6.11.0
 *
 * @version 6.11.0
 *
 * @var Tribe__Tickets_Plus__Admin__Views $this                  [Global] Template object.
 * @var int                               $post_id               The post ID.
 * @var int                               $rsvp_id               The RSVP ticket ID.
 * @var string                            $waitlist_before_sale  Whether waitlist is enabled before sale.
 */

defined( 'ABSPATH' ) || exit;

/** @var Tribe__Tickets__Admin__Views $admin_views */
$admin_views = tribe( 'tickets.admin.views' );

$admin_views->template(
	[ 'components', 'switch-field' ],
	[
		'id'          => 'rsvp_waitlist_before_sale',
		'name'        => 'rsvp_waitlist_before_sale',
		'label'       => esc_html__( 'Enable waitlist before RSVP opens', 'event-tickets-plus' ),
		'description' => esc_html__( 'Allow users to join a waitlist before the RSVP period starts.', 'event-tickets-plus' ),
		'tooltip'     => '',
		'value'       => tribe_is_truthy( $waitlist_before_sale ),
	]
);
