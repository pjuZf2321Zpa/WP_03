<?php

namespace FluentCartPro\App\Modules\MultiCurrency;

use FluentCart\App\Modules\MultiCurrency\Services\MultiCurrencySettings;

/**
 * Admin REST API behind core's Settings → Multi-Currency screen.
 */
class MultiCurrencyApi
{
    public function register($app): void
    {
        // Needs core with multi-currency; Pro can be updated before core
        if (!class_exists(MultiCurrencySettings::class)) {
            return;
        }

        // Older core still registers these routes itself
        if (class_exists('FluentCart\App\Http\Controllers\MultiCurrencyController')) {
            return;
        }

        $app->router->group(function ($router) {
            require_once __DIR__ . '/Http/routes.php';
        });
    }
}
