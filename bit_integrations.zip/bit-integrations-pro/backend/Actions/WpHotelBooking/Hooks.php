<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Actions\WpHotelBooking\WpHotelBookingProHelper;
use BitApps\IntegrationsPro\Config;
use BitApps\IntegrationsPro\Core\Util\Hooks;

Hooks::filter(Config::withFreePrefix('wp_hotel_booking_create_booking'), [WpHotelBookingProHelper::class, 'createBooking'], 10, 4);
Hooks::filter(Config::withFreePrefix('wp_hotel_booking_update_booking_status'), [WpHotelBookingProHelper::class, 'updateBookingStatus'], 10, 3);
Hooks::filter(Config::withFreePrefix('wp_hotel_booking_update_booking_customer'), [WpHotelBookingProHelper::class, 'updateBookingCustomer'], 10, 3);
Hooks::filter(Config::withFreePrefix('wp_hotel_booking_update_booking_note'), [WpHotelBookingProHelper::class, 'updateBookingNote'], 10, 2);
Hooks::filter(Config::withFreePrefix('wp_hotel_booking_mark_payment_complete'), [WpHotelBookingProHelper::class, 'markPaymentComplete'], 10, 2);
Hooks::filter(Config::withFreePrefix('wp_hotel_booking_delete_booking'), [WpHotelBookingProHelper::class, 'deleteBooking'], 10, 3);
Hooks::filter(Config::withFreePrefix('wp_hotel_booking_add_room_to_booking'), [WpHotelBookingProHelper::class, 'addRoomToBooking'], 10, 3);
Hooks::filter(Config::withFreePrefix('wp_hotel_booking_remove_booking_item'), [WpHotelBookingProHelper::class, 'removeBookingItem'], 10, 2);
Hooks::filter(Config::withFreePrefix('wp_hotel_booking_create_coupon'), [WpHotelBookingProHelper::class, 'createCoupon'], 10, 3);
Hooks::filter(Config::withFreePrefix('wp_hotel_booking_update_coupon'), [WpHotelBookingProHelper::class, 'updateCoupon'], 10, 3);
Hooks::filter(Config::withFreePrefix('wp_hotel_booking_delete_coupon'), [WpHotelBookingProHelper::class, 'deleteCoupon'], 10, 3);
Hooks::filter(Config::withFreePrefix('wp_hotel_booking_apply_coupon_to_booking'), [WpHotelBookingProHelper::class, 'applyCouponToBooking'], 10, 3);
Hooks::filter(Config::withFreePrefix('wp_hotel_booking_remove_coupon_from_booking'), [WpHotelBookingProHelper::class, 'removeCouponFromBooking'], 10, 2);
Hooks::filter(Config::withFreePrefix('wp_hotel_booking_create_room'), [WpHotelBookingProHelper::class, 'createRoom'], 10, 3);
Hooks::filter(Config::withFreePrefix('wp_hotel_booking_update_room'), [WpHotelBookingProHelper::class, 'updateRoom'], 10, 3);
Hooks::filter(Config::withFreePrefix('wp_hotel_booking_delete_room'), [WpHotelBookingProHelper::class, 'deleteRoom'], 10, 3);
Hooks::filter(Config::withFreePrefix('wp_hotel_booking_set_room_regular_price'), [WpHotelBookingProHelper::class, 'setRoomRegularPrice'], 10, 2);
Hooks::filter(Config::withFreePrefix('wp_hotel_booking_add_seasonal_pricing_plan'), [WpHotelBookingProHelper::class, 'addSeasonalPricingPlan'], 10, 2);
Hooks::filter(Config::withFreePrefix('wp_hotel_booking_create_room_type'), [WpHotelBookingProHelper::class, 'createRoomType'], 10, 3);
Hooks::filter(Config::withFreePrefix('wp_hotel_booking_create_extra'), [WpHotelBookingProHelper::class, 'createExtra'], 10, 3);
Hooks::filter(Config::withFreePrefix('wp_hotel_booking_update_extra'), [WpHotelBookingProHelper::class, 'updateExtra'], 10, 3);
Hooks::filter(Config::withFreePrefix('wp_hotel_booking_delete_extra'), [WpHotelBookingProHelper::class, 'deleteExtra'], 10, 3);
Hooks::filter(Config::withFreePrefix('wp_hotel_booking_assign_extras_to_room'), [WpHotelBookingProHelper::class, 'assignExtrasToRoom'], 10, 4);
Hooks::filter(Config::withFreePrefix('wp_hotel_booking_add_room_review'), [WpHotelBookingProHelper::class, 'addRoomReview'], 10, 3);
