<?php

namespace Breakdance\Admin\SettingsPage\PostTypesTab;

use function Breakdance\Settings\get_enabled_post_types;
use function Breakdance\Settings\set_enabled_post_types;
use function Breakdance\Util\get_public_and_allowed_post_types;
use function Breakdance\Util\is_post_request;
use function Breakdance\BreakdanceOxygen\Strings\__bdox;

add_action('breakdance_register_admin_settings_page_register_tabs', '\Breakdance\Admin\SettingsPage\PostTypesTab\register');

function register()
{
    \Breakdance\Admin\SettingsPage\addTab(esc_html__('Post Types', 'breakdance'), 'post_types', '\Breakdance\Admin\SettingsPage\PostTypesTab\tab', 1199);
}

function tab()
{
    $nonce_action = 'breakdance_admin_post-types_tab';
    if (is_post_request() && check_admin_referer($nonce_action)) {
        if (array_key_exists('all', $_POST)) {
            $selectedPostTypes = get_public_and_allowed_post_types();
        } else {
            /** @var mixed $posted */
            $posted = filter_input(INPUT_POST, 'post_types', FILTER_SANITIZE_SPECIAL_CHARS, FILTER_REQUIRE_ARRAY);

            // A scalar post_types (not post_types[]) comes back as false, not
            // null, and means nothing was ticked.
            $selectedPostTypes = is_array($posted) ? array_values(array_map('strval', $posted)) : [];
        }

        set_enabled_post_types($selectedPostTypes);
    }

    // load data for use in form. A site that has never saved the setting reads
    // back as null, which get_allowed_post_types() expands to every public and
    // allowed post type; here it just means nothing is ticked yet.
    $selectedPostTypes = get_enabled_post_types() ?? [];

?>

    <h2><?php esc_html_e('Post Types', 'breakdance'); ?></h2>

    <form id="post_type_form" action="" method="post">
        <?php wp_nonce_field($nonce_action); ?>

        <table class="form-table" role="presentation">
            <tbody>
                <tr>
                    <th scope="row">
                        <?php esc_html_e('Post Types', 'breakdance'); ?>
                    </th>
                    <td>
                        <fieldset>
                            <label for="post_types_all">
                                <input type="checkbox" name="all" value="all" id="post_types_all"> <?php esc_html_e('All Public & Allowed Post Types', 'breakdance'); ?>
                            </label><br />
                            <?php

                            echo implode(
                                '', array_map(
                                    function ($postType) use ($selectedPostTypes) {

                                        $checked = in_array($postType, $selectedPostTypes) ? "checked" : "";
                                        $postTypeObject = get_post_type_object($postType);
                                        /** @var string $label */
                                        $label = $postTypeObject ? $postTypeObject->labels->singular_name : $postType;

                                        return <<<HTML
                                <label for="post_types_{$postType}">
                                    <input type="checkbox" name="post_types[]" value="{$postType}" {$checked} id="post_types_{$postType}"> {$label}
                                </label><br />
                                HTML;
                                    },
                                    get_public_and_allowed_post_types()
                                )
                            );

                            ?>

                        </fieldset>

                        <p class="description"><?php
                            /* translators: %s: Plugin name */
                            printf(esc_html__('Editing with %s will only be enabled for the above post types.', 'breakdance'), esc_html(__bdox('plugin_name')));
                        ?></p>
                    </td>
                </tr>
            </tbody>
        </table>

        <p class="submit">
            <input type="submit" name="submit" id="submit" class="button button-primary" value="<?php esc_attr_e('Save Changes', 'breakdance'); ?>">
        </p>

    </form>

    <script>
        jQuery(function($) {
            const postTypeForm = $('#post_type_form');
            const allTypesInput = $('#post_types_all');
            const postTypeInputs = $('input[name="post_types[]"]');

            allTypesInput.on('change', function(event) {
                // stop the propagation as we don't want this
                // to bubble up and trigger the postTypeForm change handler
                event.stopPropagation();

                if (event.target.checked) {
                    postTypeInputs.prop('checked', true).prop('disabled', true);
                } else {
                    postTypeInputs.prop('disabled', false);
                }
            });

            postTypeForm.on('change', function() {
                const selectedInputs = $('input[name="post_types[]"]:checked');

                if (selectedInputs.length === postTypeInputs.length) {
                    allTypesInput.prop('checked', true).trigger('change');
                }
            });

            // trigger change on pageload to correctly
            // set the initial state of the 'all' input
            postTypeForm.trigger('change');
        });
    </script>
<?php
}
