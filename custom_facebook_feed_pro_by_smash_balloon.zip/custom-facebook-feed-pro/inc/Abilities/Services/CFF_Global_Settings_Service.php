<?php

namespace CustomFacebookFeed\Abilities\Services;

if (!defined('ABSPATH')) {
	exit;
}

/**
 * Reads/writes plugin-wide settings for the Abilities API, restricted to the
 * CFF_Settings_Schema::global_settings() allowlist.
 *
 * CFF has no single settings blob: values are spread across cff_style_settings
 * (an array option) and several standalone options (cff_locale,
 * cff_caching_type, cff_cache_cron_*, cff_ajax, cff_preserve_settings). This
 * service reads/writes each option directly rather than assuming one shape.
 *
 * @since 4.13
 */
class CFF_Global_Settings_Service
{
	/**
	 * @return array<string, mixed>
	 */
	public function get()
	{
		$style_settings = get_option('cff_style_settings', array());
		$style_settings = is_array($style_settings) ? $style_settings : array();
		$style_defaults = $this->style_defaults();

		$raw = array(
			'cff_caching_type'        => get_option('cff_caching_type', 'background'),
			'cff_cache_cron_interval' => get_option('cff_cache_cron_interval', '12hours'),
			'cff_cache_cron_time'     => get_option('cff_cache_cron_time', '1'),
			'cff_cache_cron_am_pm'    => get_option('cff_cache_cron_am_pm', 'am'),
			'gdpr'                    => isset($style_settings['gdpr']) ? $style_settings['gdpr'] : null,
			'cff_locale'              => get_option('cff_locale', 'en_US'),
			'cff_preserve_settings'   => get_option('cff_preserve_settings', null),
			'cff_show_credit'         => isset($style_settings['cff_show_credit']) ? $style_settings['cff_show_credit'] : null,
			'cff_format_issue'        => isset($style_settings['cff_format_issue']) ? $style_settings['cff_format_issue'] : null,
			'enable_js_image_loading' => isset($style_settings['enable_js_image_loading']) ? $style_settings['enable_js_image_loading'] : null,
			'cff_ajax'                => get_option('cff_ajax', null),
			'cff_disable_resize'      => isset($style_settings['cff_disable_resize']) ? $style_settings['cff_disable_resize'] : null,
			'disable_admin_notice'    => isset($style_settings['disable_admin_notice']) ? $style_settings['disable_admin_notice'] : null,
		);

		$schema   = CFF_Settings_Schema::global_settings();
		$out      = array();
		foreach ($schema as $key => $def) {
			$default = isset($style_defaults[$key]) ? $style_defaults[$key] : null;
			$out[$key] = CFF_Settings_Schema::cast_out($def, isset($raw[$key]) ? $raw[$key] : null, $default);
		}
		return $out;
	}

	/**
	 * Apply a partial update to the plugin-wide settings.
	 *
	 * Writes each option the same way CFF_Global_Settings::cff_save_settings()
	 * does for the same keys, then restarts the background cron the way the
	 * Settings page does when cron keys change (replicating its switch
	 * statement rather than calling the AJAX handler).
	 *
	 * @param array $partial key => value, already schema-validated by core.
	 * @return array{updated: string[], ignored: object}|\WP_Error
	 */
	public function update(array $partial)
	{
		$schema   = CFF_Settings_Schema::global_settings();
		$writable = CFF_Settings_Schema::writable($schema);
		$updated  = array();
		$ignored  = array();
		$clean    = array();

		foreach ($partial as $key => $value) {
			if (!isset($schema[$key])) {
				$ignored[$key] = 'unknown_setting';
				continue;
			}
			if (!isset($writable[$key])) {
				$ignored[$key] = 'read_only';
				continue;
			}
			$v = CFF_Settings_Schema::validate_in($schema[$key], $value, $key);
			if (is_wp_error($v)) {
				return $v;
			}
			$clean[$key] = $v;
		}

		if (empty($clean)) {
			return array('updated' => array(), 'ignored' => (object) $ignored, 'warnings' => array());
		}

		$warnings = array();

		$style_settings = get_option('cff_style_settings', array());
		$style_settings = is_array($style_settings) ? $style_settings : array();
		$style_touched  = false;

		$style_keys = array(
			'cff_show_credit', 'cff_format_issue', 'enable_js_image_loading', 'cff_disable_resize',
		);

		foreach ($clean as $key => $v) {
			$def = $schema[$key];
			switch ($key) {
				case 'cff_cache_cron_interval':
				case 'cff_cache_cron_time':
				case 'cff_cache_cron_am_pm':
				case 'cff_locale':
					update_option($key, $v);
					break;
				case 'cff_preserve_settings':
					update_option('cff_preserve_settings', CFF_Settings_Schema::encode_bool($v, $def));
					break;
				case 'cff_ajax':
					update_option('cff_ajax', CFF_Settings_Schema::encode_bool($v, $def));
					break;
				case 'gdpr':
					// Same key and value the Settings page writes (cff_style_settings['gdpr']).
					$style_settings['gdpr'] = $v;
					$style_touched          = true;
					break;
				default:
					if (in_array($key, $style_keys, true)) {
						$style_settings[$key] = CFF_Settings_Schema::encode_bool($v, $def);
						$style_touched         = true;
					}
			}
			$updated[] = $key;
		}

		if ($style_touched) {
			$warnings = array_merge($warnings, $this->enforce_resize_interlock($style_settings, $clean));
			update_option('cff_style_settings', $style_settings);
		}

		if (in_array('gdpr', $updated, true) && $clean['gdpr'] === 'no') {
			$warnings[] = __(
				'GDPR mode is now "no": feeds load Facebook images and scripts before '
				. 'visitors consent. Tell the site owner, since this can affect legal compliance.',
				'custom-facebook-feed'
			);
		}

		// Same side effect as the Settings page save.
		$this->clear_stored_caches();

		$cron_keys = array('cff_cache_cron_interval', 'cff_cache_cron_time', 'cff_cache_cron_am_pm');
		if (array_intersect($cron_keys, $updated)) {
			$this->reschedule_cron();
		}

		/**
		 * Fires after an AI agent updated global settings through the Abilities API.
		 *
		 * @param string[] $updated Keys that were written.
		 */
		do_action('cff_abilities_global_settings_updated', $updated);

		return array('updated' => $updated, 'ignored' => (object) $ignored, 'warnings' => $warnings);
	}

	/**
	 * Force the same GDPR/resize interaction the Settings page enforces: image
	 * resizing can only stay disabled while GDPR mode is "no". Mutates
	 * $style_settings in place and returns any warning this override produced.
	 *
	 * The `cff_disable_resize` key lands in $updated (the caller's foreach
	 * already added it) whenever it was requested this call, but this override
	 * silently discards a requested `true` — without a warning that is a false
	 * success (C3): the agent sees "updated" and has no way to know the value
	 * never landed. A requested `false` is not a no-op (interlock and request
	 * agree), so it doesn't warrant a warning.
	 *
	 * @param array $style_settings The cff_style_settings option, by reference.
	 * @param array $clean          Keys validated for THIS write.
	 * @return string[] Zero or one warning message.
	 */
	private function enforce_resize_interlock(array &$style_settings, array $clean)
	{
		if (($style_settings['gdpr'] ?? 'auto') === 'no') {
			return array();
		}

		$style_settings['cff_disable_resize'] = false;

		if (empty($clean['cff_disable_resize'])) {
			return array();
		}

		return array(
			__(
				'cff_disable_resize was written but immediately overridden back to false: '
				. 'GDPR mode must be "no" for image resizing to stay disabled.',
				'custom-facebook-feed'
			),
		);
	}

	/**
	 * Replicates CFF_Global_Settings::clear_stored_caches()'s SQL exactly
	 * (inc/Admin/CFF_Global_Settings.php:736-776) — never calls the AJAX
	 * handler directly (it starts with check_ajax_referer(), same constraint
	 * as the cron switch below). The plugin's own semantics are narrower than
	 * a blanket TRUNCATE: it blanks the 'posts' cache row and purges the
	 * specific transients it tracks, rather than dropping every cache_key and
	 * every row. TRUNCATE also needs the MySQL DROP privilege some managed
	 * hosts withhold, where UPDATE/DELETE succeed.
	 */
	private function clear_stored_caches()
	{
		global $wpdb;

		$cache_table = $wpdb->prefix . 'cff_feed_caches';
		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- table name is $wpdb->prefix + constant.
		$wpdb->query("UPDATE {$cache_table} SET cache_value = '' WHERE cache_key = 'posts'");

		$options_table = $wpdb->prefix . 'options';
		$like_patterns = array(
			'%\_transient\_cff\_%',
			'%\_transient\_cff\_ej\_%',
			'%\_transient\_cff\_tle\_%',
			'%\_transient\_cff\_album\_%',
			'%\_transient\_timeout\_cff\_%',
			'%\cff\_album\_%',
		);
		foreach ($like_patterns as $pattern) {
			$wpdb->query(
				$wpdb->prepare(
					// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- table name is $wpdb->prefix + constant.
					"DELETE FROM {$options_table} WHERE `option_name` LIKE %s",
					$pattern
				)
			);
		}
	}

	/**
	 * Replicates CFF_Global_Settings::cff_save_settings()'s cron-reschedule
	 * switch — never calls the AJAX handler directly.
	 */
	private function reschedule_cron()
	{
		wp_clear_scheduled_hook('cff_cache_cron');

		$interval = get_option('cff_cache_cron_interval', '12hours');
		switch ($interval) {
			case '30mins':
				$schedule = '30mins';
				break;
			case '1hour':
				$schedule = 'hourly';
				break;
			case '12hours':
				$schedule = 'twicedaily';
				break;
			default:
				$schedule = 'daily';
		}

		$time    = get_option('cff_cache_cron_time', '1');
		$am_pm   = get_option('cff_cache_cron_am_pm', 'am');
		$style   = get_option('cff_style_settings', array());
		$tz      = is_array($style) && !empty($style['cff_timezone']) ? $style['cff_timezone'] : 'America/Chicago';
		$time_ts = strtotime($time . $am_pm . ' ' . $tz);
		if (in_array($interval, array('30mins', '1hour'), true)) {
			$time_ts = time();
		}

		if (class_exists('\CustomFacebookFeed\CFF_Group_Posts')) {
			\CustomFacebookFeed\CFF_Group_Posts::group_reschedule_event($time_ts, $schedule);
		}
		wp_schedule_event($time_ts, $schedule, 'cff_cache_cron');
	}

	/**
	 * Plugin defaults for the cff_style_settings-backed keys, used as the
	 * cast_out() fallback for legacy/missing values.
	 *
	 * @return array<string, mixed>
	 */
	private function style_defaults()
	{
		return array(
			'gdpr'                    => 'auto',
			'cff_preserve_settings'   => false,
			'cff_show_credit'         => false,
			'cff_format_issue'        => false,
			'enable_js_image_loading' => false,
			'cff_disable_resize'      => false,
			'disable_admin_notice'    => false,
			'cff_ajax'                => false,
		);
	}
}
