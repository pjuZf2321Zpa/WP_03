<?php

namespace FluentCartPro\App\Hooks\Handlers\BlockEditors\EmailBlocks\LicenseDetails;

use FluentCart\App\Hooks\Handlers\BlockEditors\BlockEditor;

class LicenseDetailsBlockEditor extends BlockEditor
{
    use \FluentCartPro\App\Contracts\CanEnqueue;
    protected static string $editorName = 'email-license-details';

    public function getScripts(): array
    {
        return [
            [
                'source'       => 'admin/BlockEditor/EmailBlocks/LicenseDetails/LicenseDetailsBlockEditor.jsx',
                'dependencies' => ['wp-blocks', 'wp-components', 'wp-block-editor']
            ]
        ];
    }

    public function getStyles(): array
    {
        return [
            'admin/BlockEditor/EmailBlocks/LicenseDetails/style/license-details-block-editor.scss'
        ];
    }

    public function localizeData(): array
    {
        return [
            $this->getLocalizationKey() => [
                'slug'        => $this->slugPrefix,
                'name'        => static::getEditorName(),
                'title'       => __('License Details', 'fluent-cart-pro'),
                'description' => __('Loops over order licenses with a customizable template using {{license.*}} shortcodes.', 'fluent-cart-pro'),
            ],
            'fluent_cart_pro_block_translation' => \FluentCartPro\App\Services\Translations\Translations::blockStrings(),
        ];
    }

    public function blockAttributes(): array
    {
        return [
            'loopType' => [
                'type'    => 'string',
                'default' => 'licenseDetails',
            ],
            'showSeparator' => [
                'type'    => 'boolean',
                'default' => true,
            ],
            'separatorColor' => [
                'type'    => 'string',
                'default' => '#e5e7eb',
            ],
        ];
    }

    public function provideContext()
    {
        return [
            'fluent-cart/loopType' => 'loopType',
        ];
    }

    public function supports(): array
    {
        return [
            'html'       => false,
            'align'      => false,
            'color'      => [
                'text'       => true,
                'background' => true,
            ],
            'spacing'    => [
                'margin'  => true,
                'padding' => true,
            ],
            '__experimentalBorder' => [
                'color'  => true,
                'radius' => true,
                'style'  => true,
                'width'  => true,
            ],
        ];
    }

    public function render(array $attrs, $block = null, $content = ''): string
    {
        return $content;
    }
}
