<?php

namespace BitApps\IntegrationsPro\Actions\WpSimpleBookingCalendar;

use BitApps\IntegrationsPro\Triggers\WpSimpleBookingCalendar\WpSimpleBookingCalendarHelper as Helper;

if (!\defined('ABSPATH')) {
    exit;
}

/**
 * WP Simple Booking Calendar write actions (Pro). Free fires the hooks, the logic lives here.
 */
final class WpSimpleBookingCalendarProHelper
{
    public static function createCalendar($response, $fieldData, $integrationDetails = null)
    {
        if ($error = self::guard()) {
            return $error;
        }

        if (empty($fieldData['name'])) {
            return self::errorResponse(__('Calendar name is required', 'bit-integrations-pro'));
        }

        $calendarId = wpsbc_insert_calendar(
            [
                'name'          => sanitize_text_field($fieldData['name']),
                'date_created'  => current_time('mysql'),
                'date_modified' => current_time('mysql'),
                'status'        => 'active',
                'ical_hash'     => wpsbc_generate_ical_hash(),
            ]
        );

        if (!$calendarId) {
            return self::errorResponse(__('Failed to create calendar', 'bit-integrations-pro'));
        }

        foreach (wpsbc_get_default_legend_items_data() as $legendItemData) {
            $translations = $legendItemData['translations'] ?? [];
            unset($legendItemData['translations']);

            $legendItemData['calendar_id'] = $calendarId;
            $legendItemId = wpsbc_insert_legend_item($legendItemData);

            foreach ($translations as $languageCode => $translation) {
                wpsbc_add_legend_item_meta($legendItemId, 'translation_' . $languageCode, $translation);
            }
        }

        $copyCalendarId = (int) self::detail($integrationDetails, 'selectedCopyCalendar');

        if ($copyCalendarId > 0) {
            self::copyLegendItems($copyCalendarId, $calendarId);
        }

        return self::successResponse(__('Calendar created successfully', 'bit-integrations-pro'), Helper::getCalendarData($calendarId));
    }

    public static function updateCalendar($response, $fieldData)
    {
        if ($error = self::guard()) {
            return $error;
        }

        $calendarId = self::resolveCalendarId($fieldData);

        if (\is_array($calendarId)) {
            return $calendarId;
        }

        if (empty($fieldData['name'])) {
            return self::errorResponse(__('Calendar name is required', 'bit-integrations-pro'));
        }

        return self::updateCalendarRecord(
            $calendarId,
            ['name' => sanitize_text_field($fieldData['name']), 'date_modified' => current_time('mysql')],
            __('Calendar updated successfully', 'bit-integrations-pro')
        );
    }

    public static function trashCalendar($response, $fieldData)
    {
        return self::changeCalendarStatus($fieldData, 'trash', __('Calendar moved to trash', 'bit-integrations-pro'));
    }

    public static function restoreCalendar($response, $fieldData)
    {
        return self::changeCalendarStatus($fieldData, 'active', __('Calendar restored', 'bit-integrations-pro'));
    }

    public static function deleteCalendar($response, $fieldData)
    {
        if ($error = self::guard()) {
            return $error;
        }

        $calendarId = self::resolveCalendarId($fieldData);

        if (\is_array($calendarId)) {
            return $calendarId;
        }

        $calendarData = Helper::getCalendarData($calendarId);

        if (!wpsbc_delete_calendar($calendarId)) {
            return self::errorResponse(__('Failed to delete calendar', 'bit-integrations-pro'));
        }

        foreach (self::getLegendItemIdsByCalendar($calendarId) as $legendItemId) {
            wpsbc_delete_legend_item($legendItemId);
            self::deleteAllMeta('wpsbc_get_legend_item_meta', 'wpsbc_delete_legend_item_meta', $legendItemId);
        }

        foreach ((array) wpsbc_get_events(['calendar_id' => $calendarId]) as $event) {
            $eventId = (int) $event->get('id');
            wpsbc_delete_event($eventId);
            self::deleteAllMeta('wpsbc_get_event_meta', 'wpsbc_delete_event_meta', $eventId);
        }

        self::deleteAllMeta('wpsbc_get_calendar_meta', 'wpsbc_delete_calendar_meta', $calendarId);

        return self::successResponse(__('Calendar deleted successfully', 'bit-integrations-pro'), $calendarData);
    }

    public static function createEvent($response, $fieldData, $integrationDetails = null)
    {
        if ($error = self::guard()) {
            return $error;
        }

        $target = self::resolveCalendarAndLegendItem($integrationDetails);

        if (isset($target['success'])) {
            return $target;
        }

        if (empty($fieldData['date'])) {
            return self::errorResponse(__('Date is required', 'bit-integrations-pro'));
        }

        $date = Helper::parseDate($fieldData['date']);

        if (!$date) {
            return self::invalidDateResponse(__('Date', 'bit-integrations-pro'));
        }

        $eventId = self::upsertEvent($target['calendar_id'], $target['legend_item_id'], $date, $fieldData);

        if (!$eventId) {
            return self::errorResponse(__('Failed to create event', 'bit-integrations-pro'));
        }

        return self::successResponse(__('Event created successfully', 'bit-integrations-pro'), Helper::getEventData($eventId));
    }

    public static function bookDateRange($response, $fieldData, $integrationDetails = null)
    {
        if ($error = self::guard()) {
            return $error;
        }

        $target = self::resolveCalendarAndLegendItem($integrationDetails);

        if (isset($target['success'])) {
            return $target;
        }

        if (empty($fieldData['start_date']) || empty($fieldData['end_date'])) {
            return self::errorResponse(__('Start Date and End Date are required', 'bit-integrations-pro'));
        }

        $startDate = Helper::parseDate($fieldData['start_date']);
        $endDate = Helper::parseDate($fieldData['end_date']);

        if (!$startDate) {
            return self::invalidDateResponse(__('Start Date', 'bit-integrations-pro'));
        }

        if (!$endDate) {
            return self::invalidDateResponse(__('End Date', 'bit-integrations-pro'));
        }

        $current = date_create(Helper::formatDate($startDate['year'], $startDate['month'], $startDate['day']), wp_timezone());
        $end = date_create(Helper::formatDate($endDate['year'], $endDate['month'], $endDate['day']), wp_timezone());

        if ($current > $end) {
            return self::errorResponse(__('Start Date must be before or equal to End Date', 'bit-integrations-pro'));
        }

        $events = [];

        while ($current <= $end) {
            $date = [
                'year'  => (int) $current->format('Y'),
                'month' => (int) $current->format('n'),
                'day'   => (int) $current->format('j'),
            ];

            $eventId = self::upsertEvent($target['calendar_id'], $target['legend_item_id'], $date, $fieldData);

            if ($eventId) {
                $events[] = Helper::getEventData($eventId);
            }

            $current->modify('+1 day');
        }

        return self::successResponse(
            __('Date range booked successfully', 'bit-integrations-pro'),
            ['calendar_id' => $target['calendar_id'], 'events_count' => \count($events), 'events' => $events]
        );
    }

    public static function updateEvent($response, $fieldData, $integrationDetails = null)
    {
        if ($error = self::guard()) {
            return $error;
        }

        $eventId = self::resolveEventId($fieldData);

        if (\is_array($eventId)) {
            return $eventId;
        }

        $eventData = [];
        $legendItemId = (int) self::detail($integrationDetails, 'selectedLegendItem');

        if ($legendItemId > 0) {
            if (!\is_object(wpsbc_get_legend_item($legendItemId))) {
                return self::errorResponse(__('Legend item not found', 'bit-integrations-pro'));
            }

            $eventData['legend_item_id'] = $legendItemId;
        }

        if (isset($fieldData['description'])) {
            $eventData['description'] = sanitize_textarea_field($fieldData['description']);
        }

        if (isset($fieldData['tooltip'])) {
            $eventData['tooltip'] = sanitize_textarea_field($fieldData['tooltip']);
        }

        if (empty($eventData)) {
            return self::errorResponse(__('No fields provided to update', 'bit-integrations-pro'));
        }

        if (!wpsbc_update_event($eventId, $eventData)) {
            return self::errorResponse(__('Failed to update event', 'bit-integrations-pro'));
        }

        return self::successResponse(__('Event updated successfully', 'bit-integrations-pro'), Helper::getEventData($eventId));
    }

    public static function deleteEvent($response, $fieldData)
    {
        if ($error = self::guard()) {
            return $error;
        }

        $eventId = self::resolveEventId($fieldData);

        if (\is_array($eventId)) {
            return $eventId;
        }

        return self::deleteEventRecord(wpsbc_get_event($eventId));
    }

    public static function deleteEventByDate($response, $fieldData)
    {
        if ($error = self::guard()) {
            return $error;
        }

        $calendarId = self::resolveCalendarId($fieldData);

        if (\is_array($calendarId)) {
            return $calendarId;
        }

        if (empty($fieldData['date'])) {
            return self::errorResponse(__('Date is required', 'bit-integrations-pro'));
        }

        $date = Helper::parseDate($fieldData['date']);

        if (!$date) {
            return self::invalidDateResponse(__('Date', 'bit-integrations-pro'));
        }

        $event = self::findEventByDate($calendarId, $date);

        if (!\is_object($event)) {
            return self::errorResponse(__('No event found on the given date', 'bit-integrations-pro'));
        }

        return self::deleteEventRecord($event);
    }

    public static function createLegendItem($response, $fieldData, $integrationDetails = null)
    {
        if ($error = self::guard()) {
            return $error;
        }

        $calendarId = (int) self::detail($integrationDetails, 'selectedCalendar');

        if ($calendarId <= 0 || !\is_object(wpsbc_get_calendar($calendarId))) {
            return self::errorResponse(__('Please select a valid calendar', 'bit-integrations-pro'));
        }

        if (empty($fieldData['name']) || empty($fieldData['color'])) {
            return self::errorResponse(__('Name and Color are required', 'bit-integrations-pro'));
        }

        $existingLegendItems = wpsbc_get_legend_items(['calendar_id' => $calendarId, 'number' => 1]);
        $isDefaultChoice = self::detail($integrationDetails, 'selectedIsDefault');
        $isDefault = $isDefaultChoice !== '' ? (int) $isDefaultChoice : (empty($existingLegendItems) ? 1 : 0);
        $isVisibleChoice = self::detail($integrationDetails, 'selectedVisibility');

        $legendItemId = wpsbc_insert_legend_item(
            [
                'name'        => sanitize_text_field($fieldData['name']),
                'type'        => 'single',
                'color'       => [sanitize_text_field(trim($fieldData['color']))],
                'color_text'  => sanitize_text_field($fieldData['color_text'] ?? ''),
                'is_visible'  => $isVisibleChoice !== '' ? (int) $isVisibleChoice : 1,
                'is_default'  => $isDefault,
                'calendar_id' => $calendarId,
            ]
        );

        if (!$legendItemId) {
            return self::errorResponse(__('Failed to create legend item', 'bit-integrations-pro'));
        }

        if ($isDefault) {
            self::clearOtherDefaults($calendarId, $legendItemId);
        }

        return self::successResponse(__('Legend item created successfully', 'bit-integrations-pro'), Helper::getLegendItemData($legendItemId));
    }

    public static function updateLegendItem($response, $fieldData)
    {
        if ($error = self::guard()) {
            return $error;
        }

        $legendItemId = self::resolveLegendItemId($fieldData);

        if (\is_array($legendItemId)) {
            return $legendItemId;
        }

        $legendItemData = [];

        foreach (['name', 'color_text'] as $field) {
            if (isset($fieldData[$field]) && $fieldData[$field] !== '') {
                $legendItemData[$field] = sanitize_text_field($fieldData[$field]);
            }
        }

        if (!empty($fieldData['color'])) {
            $legendItemData['color'] = [sanitize_text_field(trim($fieldData['color']))];
        }

        if (empty($legendItemData)) {
            return self::errorResponse(__('No fields provided to update', 'bit-integrations-pro'));
        }

        return self::updateLegendItemRecord($legendItemId, $legendItemData, __('Legend item updated successfully', 'bit-integrations-pro'));
    }

    public static function deleteLegendItem($response, $fieldData)
    {
        if ($error = self::guard()) {
            return $error;
        }

        $legendItemId = self::resolveLegendItemId($fieldData);

        if (\is_array($legendItemId)) {
            return $legendItemId;
        }

        $legendItemData = Helper::getLegendItemData($legendItemId);

        if (!wpsbc_delete_legend_item($legendItemId)) {
            return self::errorResponse(__('Failed to delete legend item', 'bit-integrations-pro'));
        }

        self::deleteAllMeta('wpsbc_get_legend_item_meta', 'wpsbc_delete_legend_item_meta', $legendItemId);

        return self::successResponse(__('Legend item deleted successfully', 'bit-integrations-pro'), $legendItemData);
    }

    public static function setDefaultLegendItem($response, $fieldData)
    {
        if ($error = self::guard()) {
            return $error;
        }

        $legendItemId = self::resolveLegendItemId($fieldData);

        if (\is_array($legendItemId)) {
            return $legendItemId;
        }

        $legendItem = wpsbc_get_legend_item($legendItemId);

        self::clearOtherDefaults((int) $legendItem->get('calendar_id'), $legendItemId);

        return self::updateLegendItemRecord($legendItemId, ['is_default' => 1], __('Legend item set as default', 'bit-integrations-pro'));
    }

    public static function setLegendItemVisibility($response, $fieldData, $integrationDetails = null)
    {
        if ($error = self::guard()) {
            return $error;
        }

        $legendItemId = self::resolveLegendItemId($fieldData);

        if (\is_array($legendItemId)) {
            return $legendItemId;
        }

        $visibility = self::detail($integrationDetails, 'selectedVisibility');

        if ($visibility === '') {
            return self::errorResponse(__('Please select the visibility', 'bit-integrations-pro'));
        }

        return self::updateLegendItemRecord($legendItemId, ['is_visible' => (int) $visibility], __('Legend item visibility updated', 'bit-integrations-pro'));
    }

    public static function updateCalendarMeta($response, $fieldData)
    {
        if ($error = self::guard()) {
            return $error;
        }

        $calendarId = self::resolveCalendarId($fieldData);

        if (\is_array($calendarId)) {
            return $calendarId;
        }

        return self::updateMeta('calendar_id', $calendarId, $fieldData, 'wpsbc_update_calendar_meta', 'wpsbc_get_calendar_meta');
    }

    public static function updateEventMeta($response, $fieldData)
    {
        if ($error = self::guard()) {
            return $error;
        }

        $eventId = self::resolveEventId($fieldData);

        if (\is_array($eventId)) {
            return $eventId;
        }

        return self::updateMeta('event_id', $eventId, $fieldData, 'wpsbc_update_event_meta', 'wpsbc_get_event_meta');
    }

    public static function updateLegendItemMeta($response, $fieldData)
    {
        if ($error = self::guard()) {
            return $error;
        }

        $legendItemId = self::resolveLegendItemId($fieldData);

        if (\is_array($legendItemId)) {
            return $legendItemId;
        }

        return self::updateMeta('legend_item_id', $legendItemId, $fieldData, 'wpsbc_update_legend_item_meta', 'wpsbc_get_legend_item_meta');
    }

    private static function changeCalendarStatus($fieldData, $status, $message)
    {
        if ($error = self::guard()) {
            return $error;
        }

        $calendarId = self::resolveCalendarId($fieldData);

        if (\is_array($calendarId)) {
            return $calendarId;
        }

        return self::updateCalendarRecord($calendarId, ['status' => $status, 'date_modified' => current_time('mysql')], $message);
    }

    private static function updateCalendarRecord($calendarId, $calendarData, $message)
    {
        if (!wpsbc_update_calendar($calendarId, $calendarData)) {
            return self::errorResponse(__('Failed to update calendar', 'bit-integrations-pro'));
        }

        return self::successResponse($message, Helper::getCalendarData($calendarId));
    }

    private static function updateLegendItemRecord($legendItemId, $legendItemData, $message)
    {
        if (!wpsbc_update_legend_item($legendItemId, $legendItemData)) {
            return self::errorResponse(__('Failed to update legend item', 'bit-integrations-pro'));
        }

        return self::successResponse($message, Helper::getLegendItemData($legendItemId));
    }

    private static function updateMeta($idKey, $objectId, $fieldData, $updateFunction, $getFunction)
    {
        if (empty($fieldData['meta_key'])) {
            return self::errorResponse(__('Meta key is required', 'bit-integrations-pro'));
        }

        $metaKey = sanitize_text_field($fieldData['meta_key']);

        $updateFunction($objectId, $metaKey, $fieldData['meta_value'] ?? '');

        return self::successResponse(
            __('Meta updated successfully', 'bit-integrations-pro'),
            [$idKey => $objectId, 'meta_key' => $metaKey, 'meta' => Helper::flattenMeta($getFunction($objectId))]
        );
    }

    private static function resolveCalendarAndLegendItem($integrationDetails)
    {
        $calendarId = (int) self::detail($integrationDetails, 'selectedCalendar');
        $legendItemId = (int) self::detail($integrationDetails, 'selectedLegendItem');

        if ($calendarId <= 0 || !\is_object(wpsbc_get_calendar($calendarId))) {
            return self::errorResponse(__('Please select a valid calendar', 'bit-integrations-pro'));
        }

        $legendItem = $legendItemId > 0 ? wpsbc_get_legend_item($legendItemId) : null;

        if (!\is_object($legendItem)) {
            return self::errorResponse(__('Please select a valid legend item', 'bit-integrations-pro'));
        }

        if ((int) $legendItem->get('calendar_id') !== $calendarId) {
            return self::errorResponse(__('Legend item does not belong to the selected calendar', 'bit-integrations-pro'));
        }

        return ['calendar_id' => $calendarId, 'legend_item_id' => $legendItemId];
    }

    private static function resolveCalendarId($fieldData)
    {
        $calendarId = isset($fieldData['calendar_id']) ? absint($fieldData['calendar_id']) : 0;

        if ($calendarId <= 0 || !\is_object(wpsbc_get_calendar($calendarId))) {
            return self::errorResponse(__('Calendar not found', 'bit-integrations-pro'));
        }

        return $calendarId;
    }

    private static function resolveEventId($fieldData)
    {
        $eventId = isset($fieldData['event_id']) ? absint($fieldData['event_id']) : 0;

        if ($eventId <= 0 || !\is_object(wpsbc_get_event($eventId))) {
            return self::errorResponse(__('Event not found', 'bit-integrations-pro'));
        }

        return $eventId;
    }

    private static function resolveLegendItemId($fieldData)
    {
        $legendItemId = isset($fieldData['legend_item_id']) ? absint($fieldData['legend_item_id']) : 0;

        if ($legendItemId <= 0 || !\is_object(wpsbc_get_legend_item($legendItemId))) {
            return self::errorResponse(__('Legend item not found', 'bit-integrations-pro'));
        }

        return $legendItemId;
    }

    private static function findEventByDate($calendarId, $date)
    {
        $events = wpsbc_get_events(
            [
                'calendar_id' => $calendarId,
                'date_year'   => $date['year'],
                'date_month'  => $date['month'],
                'date_day'    => $date['day'],
                'number'      => 1,
            ]
        );

        return !empty($events) && \is_array($events) ? $events[0] : null;
    }

    /**
     * The editor keeps one event per day, so a second write to the same day updates it.
     *
     * @param mixed $calendarId
     * @param mixed $legendItemId
     * @param mixed $date
     * @param mixed $fieldData
     */
    private static function upsertEvent($calendarId, $legendItemId, $date, $fieldData)
    {
        $eventData = [
            'legend_item_id' => $legendItemId,
            'description'    => sanitize_textarea_field($fieldData['description'] ?? ''),
            'tooltip'        => sanitize_textarea_field($fieldData['tooltip'] ?? ''),
        ];

        $existingEvent = self::findEventByDate($calendarId, $date);

        if (\is_object($existingEvent)) {
            return wpsbc_update_event($existingEvent->get('id'), $eventData) ? (int) $existingEvent->get('id') : false;
        }

        $eventData['calendar_id'] = $calendarId;
        $eventData['date_year'] = $date['year'];
        $eventData['date_month'] = $date['month'];
        $eventData['date_day'] = $date['day'];

        return wpsbc_insert_event($eventData);
    }

    private static function deleteEventRecord($event)
    {
        $eventId = (int) $event->get('id');
        $eventData = Helper::getEventData($event);

        if (!wpsbc_delete_event($eventId)) {
            return self::errorResponse(__('Failed to delete event', 'bit-integrations-pro'));
        }

        self::deleteAllMeta('wpsbc_get_event_meta', 'wpsbc_delete_event_meta', $eventId);

        return self::successResponse(__('Event deleted successfully', 'bit-integrations-pro'), $eventData);
    }

    private static function copyLegendItems($sourceCalendarId, $targetCalendarId)
    {
        foreach ((array) wpsbc_get_legend_items(['calendar_id' => $sourceCalendarId]) as $legendItem) {
            $legendItemData = $legendItem->to_array();
            $legendItemData['calendar_id'] = $targetCalendarId;
            unset($legendItemData['id']);

            $legendItemId = wpsbc_insert_legend_item($legendItemData);

            if (!$legendItemId) {
                continue;
            }

            foreach ((array) wpsbc_get_legend_item_meta($legendItem->get('id')) as $metaKey => $metaValues) {
                foreach ((array) $metaValues as $metaValue) {
                    wpsbc_add_legend_item_meta($legendItemId, $metaKey, maybe_unserialize($metaValue));
                }
            }
        }
    }

    private static function clearOtherDefaults($calendarId, $keepLegendItemId)
    {
        foreach ((array) wpsbc_get_legend_items(['calendar_id' => $calendarId, 'is_default' => 1]) as $legendItem) {
            if ((int) $legendItem->get('id') !== (int) $keepLegendItemId) {
                wpsbc_update_legend_item($legendItem->get('id'), ['is_default' => 0]);
            }
        }
    }

    /**
     * The plugin's list helper hides split-type rows, so cascade by id instead.
     *
     * @param mixed $calendarId
     */
    private static function getLegendItemIdsByCalendar($calendarId)
    {
        global $wpdb;

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- cascade delete lookup on the plugin's own table
        return array_map('intval', $wpdb->get_col($wpdb->prepare("SELECT id FROM {$wpdb->prefix}wpsbc_legend_items WHERE calendar_id = %d", (int) $calendarId)));
    }

    private static function deleteAllMeta($getFunction, $deleteFunction, $objectId)
    {
        foreach (array_keys((array) $getFunction($objectId)) as $metaKey) {
            $deleteFunction($objectId, $metaKey);
        }
    }

    private static function invalidDateResponse($fieldLabel)
    {
        // translators: %s is the date field label.
        return self::errorResponse(\sprintf(__('%s is not a valid date. Use the YYYY-MM-DD format.', 'bit-integrations-pro'), $fieldLabel));
    }

    private static function guard()
    {
        if (!Helper::isPluginActive()) {
            return self::errorResponse(__('WP Simple Booking Calendar is not installed or activated', 'bit-integrations-pro'));
        }
    }

    private static function detail($integrationDetails, $key)
    {
        if (\is_object($integrationDetails)) {
            return $integrationDetails->{$key} ?? '';
        }

        if (\is_array($integrationDetails)) {
            return $integrationDetails[$key] ?? '';
        }

        return '';
    }

    private static function successResponse($message, $data = [])
    {
        return [
            'success' => true,
            'message' => $message,
            'data'    => $data
        ];
    }

    private static function errorResponse($message)
    {
        return [
            'success' => false,
            'message' => $message
        ];
    }
}
