<?php

namespace FluentCartPro\App\Modules\Licensing\Http\Controllers;

use FluentCart\App\Models\Customer;
use FluentCart\App\Models\Order;
use FluentCart\Framework\Http\Controller;
use FluentCart\Framework\Http\Request\Request;
use FluentCart\App\Services\Filter\LicenseSiteFilter;
use FluentCartPro\App\Modules\Licensing\Models\LicenseActivation;
use FluentCartPro\App\Modules\Licensing\Models\LicenseSite;

class LicenseSiteController extends Controller
{
    public function index(Request $request): array
    {
        $sites = LicenseSiteFilter::fromRequest($request)->paginate();

        $siteIds = $sites->pluck('id')->toArray();

        // Batch-load activations with license+product+customer for all sites in this page
        $activations = LicenseActivation::with([
            'license.product:ID,post_title',
            'license.productVariant:id,variation_title',
            'license.customer:id,first_name,last_name,email',
        ])
            ->whereIn('site_id', $siteIds)
            ->get()
            ->groupBy('site_id');

        foreach ($sites as $site) {
            $siteActivations = isset($activations[$site->id]) ? $activations[$site->id] : collect([]);

            // Unique product names
            $products = [];
            $customers = [];
            $latestUpdate = null;
            $isLocal = false;

            foreach ($siteActivations as $activation) {
                if ($activation->is_local && $activation->is_local !== '0') {
                    $isLocal = true;
                }

                if ($activation->last_update_date && (!$latestUpdate || $activation->last_update_date > $latestUpdate)) {
                    $latestUpdate = $activation->last_update_date;
                }

                $license = $activation->license;
                if ($license && $license->product) {
                    $key = $license->product->ID . '_' . $license->variation_id;
                    if (!isset($products[$key])) {
                        $products[$key] = [
                            'name'      => $license->product->post_title,
                            'variation' => $license->productVariant ? $license->productVariant->variation_title : '',
                        ];
                    }
                }
                if ($license && $license->customer) {
                    $customers[$license->customer->id] = $license->customer->full_name;
                }
            }

            $site->products = array_values($products);
            $site->customers = array_values($customers);
            $site->is_local = $isLocal;
            $site->last_activity = $latestUpdate;
        }

        return [
            'sites' => $sites
        ];
    }

    public function getSite(Request $request, $id): array
    {
        $site = LicenseSite::findOrFail($id);

        $perPage = intval($request->get('per_page', 15));
        $perPage = min(max($perPage, 1), 100);

        $activations = LicenseActivation::with([
            'license.product',
            'license.productVariant',
            'license.customer',
            'license.order',
        ])
            ->where('site_id', $site->id)
            ->orderBy('id', 'DESC')
            ->paginate($perPage);

        $customerIds = [];
        $orderIds = [];

        $formattedActivations = $activations->map(function ($activation) use (&$customerIds, &$orderIds) {
            $license = $activation->license;

            if ($license && $license->customer_id) {
                $customerIds[$license->customer_id] = true;
            }
            if ($license && $license->order_id) {
                $orderIds[$license->order_id] = true;
            }

            return [
                'id'                  => $activation->id,
                'license_id'          => $activation->license_id,
                'license_key'         => $license ? $license->license_key : '',
                'product_id'          => $license ? $license->product_id : null,
                'product_name'        => $license && $license->product ? $license->product->post_title : __('Unknown Product', 'fluent-cart-pro'),
                'variation_title'     => $license && $license->productVariant ? $license->productVariant->variation_title : '',
                'license_status'      => $license ? $license->status : '',
                'activation_status'   => $activation->status,
                'is_local'            => $activation->is_local,
                'last_update_version' => $activation->last_update_version,
                'last_update_date'    => $activation->last_update_date,
                'customer'            => $license && $license->customer ? [
                    'id'        => $license->customer->id,
                    'full_name' => $license->customer->full_name,
                    'email'     => $license->customer->email,
                ] : null,
                'order_id'            => $license ? $license->order_id : null,
                'expiration_date'     => $license ? $license->expiration_date : null,
                'activation_limit'    => $license ? $license->limit : null,
                'activation_count'    => $license ? $license->activation_count : null,
                'created_at'          => $activation->created_at,
            ];
        });

        // Related customers
        $customers = [];
        if ($customerIds) {
            $customers = Customer::whereIn('id', array_keys($customerIds))->get();
        }

        // Related orders
        $orders = [];
        if ($orderIds) {
            $orders = Order::whereIn('id', array_keys($orderIds))
                ->orderBy('id', 'DESC')
                ->get();
        }

        return [
            'site'        => $site,
            'activations' => [
                'data'         => $formattedActivations,
                'total'        => $activations->total(),
                'per_page'     => $activations->perPage(),
                'current_page' => $activations->currentPage(),
                'last_page'    => $activations->lastPage(),
            ],
            'customers'   => $customers,
            'orders'      => $orders,
        ];
    }
}
