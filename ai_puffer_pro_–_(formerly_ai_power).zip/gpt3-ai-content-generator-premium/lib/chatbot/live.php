<?php
/** GPT Live transport, bound session ownership and best-effort server cleanup. */
namespace WPAICG\Lib\Chat;

use WPAICG\AIPKit_Providers;
use WP_Error;

if (!defined('ABSPATH')) {
    exit;
}

final class LiveSessions
{
    private const PREFIX = '_aipkit_live_session_';
    private const EXPIRY_HOOK = 'aipkit_expire_live_session';

    public static function register(): void
    {
        // Cleanup must remain available when the paid entitlement expires.
        add_action(self::EXPIRY_HOOK, [self::class, 'expire']);
        add_action('aipkit_deactivate_background_workers', [self::class, 'deactivate']);
    }

    private static function error(string $message, int $status = 400): WP_Error
    {
        return new WP_Error('live_session_error', $message, ['status' => $status]);
    }

    private static function owner(): string
    {
        $user_id = get_current_user_id();
        // An anonymous visitor cannot bypass the concurrent-session lock by changing a guest UUID.
        $ip = isset($_SERVER['REMOTE_ADDR']) ? sanitize_text_field(wp_unslash($_SERVER['REMOTE_ADDR'])) : '';
        $subject = $user_id ? 'user:' . $user_id : 'ip:' . $ip;
        return hash_hmac('sha256', $subject, wp_salt('auth'));
    }

    private static function request(string $path, array $body = [])
    {
        $key = AIPKit_Providers::get_provider_data('OpenAI')['api_key'] ?? '';
        if (!$key) {
            return self::error(__('OpenAI API key is not configured in main settings.', 'gpt3-ai-content-generator'), 503);
        }
        // phpcs:ignore PluginCheck.CodeAnalysis.AIProvider.DirectIntegration -- Paid provider-specific Live transport.
        $response = wp_remote_post('https://api.openai.com/v1/live/sessions' . $path, [
            'timeout' => 20,
            'headers' => ['Authorization' => 'Bearer ' . $key, 'Content-Type' => 'application/json'],
            'body' => wp_json_encode($body ?: (object) []),
        ]);
        if (is_wp_error($response)) {
            return self::error(__('Could not reach OpenAI. The session may have started; wait before trying again.', 'gpt3-ai-content-generator'), 502);
        }
        return $response;
    }

    public static function create(int $bot_id, array $settings, array $post, $tokens)
    {
        $sdp = $post['sdp'] ?? '';
        $conversation = $post['conversation_uuid'] ?? '';
        $guest = $post['session_id'] ?? '';
        if (!is_string($sdp) || strlen($sdp) > 65536 || strpos($sdp, 'v=0') !== 0 || strpos($sdp, 'm=audio ') === false) {
            return self::error(__('A valid WebRTC audio offer is required.', 'gpt3-ai-content-generator'));
        }
        if (!is_string($conversation) || !preg_match('/^[a-zA-Z0-9_-]{1,100}$/D', $conversation)
            || !is_string($guest) || strlen($guest) > 100 || (!get_current_user_id() && $guest === '')) {
            return self::error(__('A conversation and visitor session are required.', 'gpt3-ai-content-generator'));
        }
        $settings = array_merge($settings, LiveSettings::sanitize($settings));
        $voice_context = LiveUsage::voice_context($bot_id, 15);
        $voice_rule = $tokens->estimate_usage_charge(0, 'chat', $voice_context)['resolved_rule'];
        $voice_context['pricing_rule_snapshot'] = $voice_rule;
        $quota = $tokens->check_and_reset_tokens(get_current_user_id() ?: null, $guest, $bot_id, 'chat', $voice_context);
        if (is_wp_error($quota)) {
            return $quota;
        }
        $owner = self::owner();
        $lock_key = '_aipkit_live_owner_' . $owner;
        $lock = get_option($lock_key);
        if (is_array($lock) && ($lock['until'] ?? 0) < time()) {
            delete_option($lock_key);
        }
        $token = wp_generate_uuid4();
        $deadline = time() + (int) $settings['live_max_seconds'];
        if (!add_option($lock_key, ['token' => $token, 'until' => $deadline + 60], '', false)) {
            return self::error(__('A Live voice session is already running for this visitor. End it before starting another.', 'gpt3-ai-content-generator'), 429);
        }
        $record = [
            'id' => '', 'owner' => $owner, 'bot_id' => $bot_id, 'conversation_uuid' => $conversation,
            'user_id' => get_current_user_id(), 'session_id' => $guest,
            'created' => time(), 'deadline' => $deadline, 'model' => $settings['live_backend_model'],
            'sequence' => 0, 'seconds' => 0, 'responses' => [], 'closed' => false, 'retries' => 0,
            'voice_pricing_rule' => $voice_rule,
        ];
        $stored = add_option(self::PREFIX . $token, $record, '', false);
        $scheduled = wp_schedule_single_event($deadline, self::EXPIRY_HOOK, [$token], true);
        if (!$stored || is_wp_error($scheduled) || !$scheduled) {
            delete_option(self::PREFIX . $token);
            delete_option($lock_key);
            wp_clear_scheduled_hook(self::EXPIRY_HOOK, [$token]);
            return self::error(__('Could not schedule Live session cleanup.', 'gpt3-ai-content-generator'), 503);
        }
        $backend = [
            'model' => $settings['live_backend_model'],
            'instructions' => (string) ($settings['instructions'] ?? 'You are a helpful assistant.'),
            'max_output_tokens' => max(16, min(128000, (int) ($settings['max_completion_tokens'] ?? 2048))),
        ];
        $web_setting = [
            'OpenAI' => 'openai_web_search_enabled', 'Claude' => 'claude_web_search_enabled',
            'OpenRouter' => 'openrouter_web_search_enabled', 'xAI' => 'xai_web_search_enabled',
            'Google' => 'google_search_grounding_enabled',
        ][$settings['provider'] ?? 'OpenAI'] ?? '';
        if (($settings[$web_setting] ?? '0') === '1' && ($post['frontend_web_search_active'] ?? '') === 'true') {
            $backend['tools'] = [['type' => 'web_search']];
        }
        $instructions = $backend['instructions'] . "\n\nFor this voice session, delegate questions and tasks requiring reasoning, factual or business information to the backend. Use its results in your spoken replies.";
        $response = self::request('', [
            'session' => [
                'model' => 'gpt-live-1',
                'instructions' => $instructions,
                'audio' => ['output' => ['voice' => $settings['live_voice']]],
                'delegation' => ['type' => 'responses', 'responses' => $backend],
                'store' => false,
                'client' => ['data_channel' => [
                    'allowed_client_events' => ['session.close', 'session.instructions.append'],
                    'allowed_server_events' => 'all',
                ]],
            ],
            'transport' => ['type' => 'webrtc', 'sdp' => $sdp],
        ]);
        if (is_wp_error($response)) {
            // Uncertain creations are not retried automatically. Keep the short-lived visitor lock.
            return $response;
        }
        $status = wp_remote_retrieve_response_code($response);
        $body = json_decode(wp_remote_retrieve_body($response), true);
        if ($status < 200 || $status >= 300) {
            self::expire($token);
            return self::error(sanitize_text_field($body['error']['message'] ?? __('OpenAI could not start GPT Live.', 'gpt3-ai-content-generator')), $status >= 400 && $status < 600 ? $status : 502);
        }
        $id = $body['session']['id'] ?? '';
        if (!is_string($id) || !preg_match('/^[a-zA-Z0-9_-]{1,200}$/D', $id)) {
            return self::error(__('OpenAI returned an invalid Live session. Wait before trying again.', 'gpt3-ai-content-generator'), 502);
        }
        $record['id'] = $id;
        update_option(self::PREFIX . $token, $record, false);
        // Successful WebRTC initialization is billable even if the browser never connects.
        $record = LiveUsage::record_voice($record, 15, $tokens, 'session_creation');
        update_option(self::PREFIX . $token, $record, false);
        $answer = $body['transport']['sdp'] ?? '';
        if (!is_string($answer) || strpos($answer, 'v=0') !== 0) {
            self::expire($token);
            return self::error(__('Could not prepare Live session cleanup or connect its audio. Please try again later.', 'gpt3-ai-content-generator'), 503);
        }
        return ['live_token' => $token, 'sdp' => $answer, 'max_seconds' => max(1, $deadline - time())];
    }

    /** AJAX nonce/CORS are checked by the existing paid voice handler. */
    public static function sync(array $post, $logs, $tokens)
    {
        $token = $post['live_token'] ?? '';
        if (!is_string($token) || !preg_match('/^[a-f0-9-]{36}$/D', $token)) {
            return self::error(__('Invalid Live session.', 'gpt3-ai-content-generator'), 403);
        }
        $record = get_option(self::PREFIX . $token);
        if (!is_array($record) || !hash_equals($record['owner'], self::owner())
            || (int) ($post['bot_id'] ?? 0) !== $record['bot_id']
            || ($post['conversation_uuid'] ?? '') !== $record['conversation_uuid']
            || (!$record['user_id'] && ($post['session_id'] ?? '') !== $record['session_id'])) {
            return self::error(__('This Live session belongs to another conversation or visitor.', 'gpt3-ai-content-generator'), 403);
        }
        // A stop request must still hang up if its usage batch is invalid or another save is in progress.
        if (!empty($post['close']) && !$record['closed']) {
            self::expire($token);
        }
        $lock_key = '_aipkit_live_sync_' . $token;
        $previous_lock = get_option($lock_key);
        if ($previous_lock && (int) $previous_lock < time() - 90) {
            delete_option($lock_key);
        }
        if (!add_option($lock_key, time(), '', false)) {
            return self::error(__('Live usage is still being saved. Please retry.', 'gpt3-ai-content-generator'), 409);
        }
        try {
            // Re-read under the lock so concurrent duplicate batches cannot charge twice.
            $record = get_option(self::PREFIX . $token);
            $batch_json = $post['batch'] ?? '';
            if (!is_string($batch_json) || strlen($batch_json) > 60000) {
                return self::error(__('Live usage report is too large.', 'gpt3-ai-content-generator'), 413);
            }
            $batch = json_decode($batch_json, true);
            if (!is_array($batch) || !isset($batch['sequence']) || !is_int($batch['sequence'])) {
                return self::error(__('Invalid Live usage report.', 'gpt3-ai-content-generator'));
            }
            if ($batch['sequence'] > $record['sequence'] + 1) {
                return self::error(__('Live usage reports must arrive in order.', 'gpt3-ai-content-generator'), 409);
            }
            $closing = !empty($post['close']) || $record['deadline'] <= time() || $record['closed'];
            if ($batch['sequence'] === $record['sequence'] + 1) {
                $result = LiveUsage::record($record, $batch, $logs, $tokens);
                if (is_wp_error($result)) {
                    return $result;
                }
                $record = $result;
                $current = get_option(self::PREFIX . $token);
                $record['closed'] = !empty($current['closed']);
                update_option(self::PREFIX . $token, $record, false);
            }
            $quota = $tokens->check_and_reset_tokens($record['user_id'] ?: null, $record['session_id'], $record['bot_id'], 'chat', [
                'provider' => 'OpenAI', 'model' => $record['model'], 'operation' => 'chat',
            ]);
            if (!is_wp_error($quota)) {
                $billed_seconds = (int) ($record['billed_seconds'] ?? 0);
                $voice_context = LiveUsage::voice_context($record['bot_id'], max(15, $billed_seconds + 5), $billed_seconds);
                $voice_context['pricing_rule_snapshot'] = $record['voice_pricing_rule'] ?? null;
                $quota = $tokens->check_and_reset_tokens($record['user_id'] ?: null, $record['session_id'], $record['bot_id'], 'chat', $voice_context);
            }
            $closing = $closing || is_wp_error($quota);
            if ($closing && !$record['closed']) {
                self::expire($token);
            }
            return ['sequence' => $record['sequence'], 'stop' => $closing, 'message' => is_wp_error($quota) ? $quota->get_error_message() : ''];
        } finally {
            delete_option($lock_key);
        }
    }

    /** End provider sessions even if the browser vanishes; WP-Cron timing is best effort. */
    public static function expire(string $token): void
    {
        $key = self::PREFIX . $token;
        $record = get_option($key);
        if (!is_array($record)) {
            return;
        }
        wp_clear_scheduled_hook(self::EXPIRY_HOOK, [$token]);
        if ($record['closed'] || $record['id'] === '') {
            $lock_key = '_aipkit_live_owner_' . $record['owner'];
            $lock = get_option($lock_key);
            if (is_array($lock) && $lock['token'] === $token) {
                delete_option($lock_key);
            }
            delete_option($key);
            delete_option('_aipkit_live_sync_' . $token);
            return;
        }
        $response = self::request('/' . rawurlencode($record['id']) . '/hangup');
        $status = is_wp_error($response) ? 0 : wp_remote_retrieve_response_code($response);
        if (($status >= 200 && $status < 300) || $status === 404) {
            // Keep deduplication state briefly for a late final browser report.
            $record = get_option($key);
            $record['closed'] = true;
            update_option($key, $record, false);
            $lock_key = '_aipkit_live_owner_' . $record['owner'];
            $lock = get_option($lock_key);
            if (is_array($lock) && $lock['token'] === $token) {
                delete_option($lock_key);
            }
            wp_schedule_single_event(time() + HOUR_IN_SECONDS, self::EXPIRY_HOOK, [$token]);
        } else {
            $record = get_option($key);
            $record['retries']++;
            update_option($key, $record, false);
            wp_schedule_single_event(time() + min(HOUR_IN_SECONDS, 60 * $record['retries']), self::EXPIRY_HOOK, [$token]);
        }
    }

    public static function deactivate(): void
    {
        global $wpdb;
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Enumerate only this feature's non-autoloaded session records during deactivation.
        $keys = $wpdb->get_col($wpdb->prepare("SELECT option_name FROM {$wpdb->options} WHERE option_name LIKE %s", $wpdb->esc_like(self::PREFIX) . '%'));
        foreach ($keys as $key) {
            self::expire(substr($key, strlen(self::PREFIX)));
        }
    }
}
