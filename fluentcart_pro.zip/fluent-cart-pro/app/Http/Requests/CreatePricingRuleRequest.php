<?php

namespace FluentCartPro\App\Http\Requests;

class CreatePricingRuleRequest extends PricingRuleRequest
{
    /**
     * @return bool
     */
    protected function requiresConfig()
    {
        return true;
    }

    /**
     * @return string
     */
    protected function presenceRule()
    {
        return 'required';
    }
}
