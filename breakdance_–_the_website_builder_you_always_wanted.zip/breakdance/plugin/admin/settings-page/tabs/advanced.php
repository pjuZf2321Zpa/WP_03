<?php

namespace Breakdance\Admin\SettingsPage\AdvancedTab;

use function Breakdance\Settings\get_bool_setting;
use function Breakdance\Settings\get_int_setting;
use function Breakdance\Settings\get_string_setting;
use function Breakdance\Settings\save_tab_from_post;
use function Breakdance\Util\is_post_request;
use function Breakdance\BreakdanceOxygen\Strings\__bdox;

add_action('breakdance_register_admin_settings_page_register_tabs', '\Breakdance\Admin\SettingsPage\AdvancedTab\register');

function register()
{
    \Breakdance\Admin\SettingsPage\addTab(esc_html__('Advanced', 'breakdance'), 'advanced', '\Breakdance\Admin\SettingsPage\AdvancedTab\tab', 1200);
}

function tab()
{
    $nonce_action = 'breakdance_admin_advanced_tab';
    if (is_post_request() && check_admin_referer($nonce_action)) {
        // Every field is named after the option it saves; see save_tab_from_post().
        save_tab_from_post('advanced');
    }

    $enable_skip_link = get_bool_setting('enable_skip_link');
    $skip_link_text = get_string_setting('skip_link_text');

    $enable_modern_normalize = get_bool_setting('modern_normalize_enabled');

    // load data for use in form
    $enable_simulate_the_content = get_bool_setting('breakdance_settings_enable_simulate_the_content');

    $allow_unfiltered_html = get_bool_setting('breakdance_settings_allow_unfiltered_html');

    $enable_svg_uploads = get_bool_setting('breakdance_settings_enable_svg_uploads');

    $enable_render_performance_debug = get_bool_setting('enable_render_performance_debug');

    $enable_revision_limit = get_bool_setting('breakdance_settings_enable_revision_limit');

    $revision_limit = (string) get_int_setting('breakdance_settings_revision_limit');

    $bdoroxy = __bdox('plugin_name');

    $docs_link_security = __bdox('docs_link_security');

?>

    <h2><?php esc_html_e('Advanced', 'breakdance'); ?></h2>

    <form action="" method="post">
        <?php wp_nonce_field($nonce_action); ?>
        <table class="form-table" role="presentation">
            <tbody>
                <tr>
                    <th scope="row">
                        <?php esc_html_e('Allow SVG Uploads In The WP Media Library', 'breakdance'); ?>
                    </th>
                    <td>
                        <fieldset>
                            <label for="enable_svg_uploads">
                                <input type="checkbox" <?php echo $enable_svg_uploads ? 'checked' : ''; ?> name="breakdance_settings_enable_svg_uploads" value="yes" id="enable_svg_uploads"> <?php esc_html_e('Enable', 'breakdance'); ?>
                            </label>
                        </fieldset>

                        <p class="description"><?php
                            /* translators: 1: Opening <a> tag for security docs, 2: Closing </a> tag, 3: Opening <a> tag for Safe SVG plugin, 4: Closing </a> tag */
                            printf(esc_html__('Allowing SVG uploads can be dangerous, and you should understand the %1$spotential security implications%2$s. If in doubt, use a plugin like %3$sSafe SVG%4$s instead of this option.', 'breakdance'), '<a href="' . esc_url($docs_link_security) . '" target="_blank">', '</a>', '<a href="https://wordpress.org/plugins/safe-svg/" target="_blank">', '</a>');
                        ?></p>
                    </td>
                </tr>
                <tr>
                  <th scope="row">
                    Accessibility: Skip Link
                  </th>
                  <td>
                    <fieldset>
                      <label for="enable_skip_link">
                        <input type="checkbox" <?php echo $enable_skip_link ? 'checked' : ''; ?> name="enable_skip_link" value="yes" id="enable_skip_link"> Enable
                      </label>
                    </fieldset>

                    <fieldset>
                      <label for="skip_link_text">
                        <input type="text" name="skip_link_text" value="<?php echo esc_attr($skip_link_text); ?>" placeholder="Skip Link Text" id="skip_link_text" class="regular-text">
                      </label>
                    </fieldset>

                    <p class="description">Enables a skip link and wraps the content in a <code>&lt;main&gt;</code> tag to allow users to skip the header and go straight to the main content. This is useful for screen readers and keyboard navigation.</p>
                  </td>
                </tr>
                <tr>
                    <th scope="row">
                        <?php esc_html_e('Modern Normalize', 'breakdance'); ?>
                    </th>
                    <td>
                        <fieldset>
                            <label for="enable_modern_normalize">
                                <input type="checkbox" <?php echo $enable_modern_normalize ? 'checked' : ''; ?> name="modern_normalize_enabled" value="yes" id="enable_modern_normalize"> <?php esc_html_e('Enable', 'breakdance'); ?>
                            </label>
                        </fieldset>

                        <p class="description"><?php
                            /* translators: 1: Plugin name, 2: Opening <a> tag for modern-normalize, 3: Closing </a> tag */
                            printf(esc_html__('Replace %1$s\'s default normalize stylesheet with %2$smodern-normalize%3$s plus a Tailwind-Preflight-style reset that removes the browser\'s default margins and padding from every element at zero specificity, so any margin or padding your CSS sets still applies. Note that enabling this on an existing site changes how content that relies on the browser defaults renders.', 'breakdance'), esc_html($bdoroxy), '<a href="https://github.com/sindresorhus/modern-normalize" target="_blank">', '</a>');
                        ?></p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <?php
                            /* translators: 1: Filter name in <code> tags, 2: Plugin name */
                            printf(esc_html__('Apply %1$s filter to %2$s content', 'breakdance'), '<code>the_content</code>', esc_html($bdoroxy));
                        ?>
                    </th>
                    <td>
                        <fieldset>
                            <label for="enable_simulate_the_content">
                                <input type="checkbox" <?php echo $enable_simulate_the_content ? 'checked' : ''; ?> name="breakdance_settings_enable_simulate_the_content" value="yes" id="enable_simulate_the_content"> <?php esc_html_e('Enable', 'breakdance'); ?>
                            </label>
                        </fieldset>

                        <p class="description"><?php
                            /* translators: 1: Plugin name (used multiple times), 2: Filter name in <code> tags, 3: Function call in <code> tags, 4: Opening <a> tag for security docs, 5: Closing </a> tag */
                            printf(esc_html__('By default, %1$s does not apply %2$s filter to %1$s-designed content. You can enable this option to make %1$s run %3$s on singular content created with %1$s, but you should understand the %4$spotential security implications%5$s.', 'breakdance'), esc_html($bdoroxy), '<code>the_content</code>', '<code>apply_filters(\'the_content\', ...)</code>', '<a href="' . esc_url($docs_link_security) . '">', '</a>');
                        ?></p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <?php esc_html_e('Allow unfiltered HTML in all dynamic data output', 'breakdance'); ?>
                    </th>
                    <td>
                        <fieldset>
                            <label for="allow_unfiltered_html">
                                <input type="checkbox" <?php echo $allow_unfiltered_html ? 'checked' : ''; ?> name="breakdance_settings_allow_unfiltered_html" value="yes" id="allow_unfiltered_html"> <?php esc_html_e('Allow', 'breakdance'); ?>
                            </label>
                        </fieldset>

                        <p class="description"><?php
                            /* translators: 1: Plugin name, 2: Function name in <code> tags, 3: Capability name in <code> tags, 4: Opening <a> tag for security docs, 5: Closing </a> tag */
                            printf(esc_html__('By default, %1$s applies %2$s to fields on posts with an author that lacks the %3$s capability. You can disable this if you understand the %4$spotential security implications%5$s.', 'breakdance'), esc_html($bdoroxy), '<code>wp_kses_post</code>', '<code>unfiltered_html</code>', '<a href="' . esc_url($docs_link_security) . '">', '</a>');
                        ?></p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <?php esc_html_e('Enable rendering performance debugger', 'breakdance'); ?>
                    </th>
                    <td>
                        <fieldset>
                            <label for="enable_render_performance_debug">
                                <input type="checkbox" <?php echo $enable_render_performance_debug ? 'checked' : ''; ?> name="enable_render_performance_debug" value="yes" id="enable_render_performance_debug">
                                <?php esc_html_e('Enable', 'breakdance'); ?>
                            </label>
                        </fieldset>

                        <p class="description"><?php
                            /* translators: 1: Opening <a> tag, 2: Closing </a> tag */
                            printf(esc_html__('Use %1$sServer Timing API%2$s to audit rendering performance. This option is intended for debugging only. It is recommended to enable it while troubleshooting and disable it afterward to avoid unnecessary overhead.', 'breakdance'), '<a href="https://developer.mozilla.org/en-US/docs/Web/API/Performance_API/Server_timing" target="_blank">', '</a>');
                        ?></p>
                    </td>
                </tr>
            </tbody>
        </table>
        <h3><?php esc_html_e('Revisions', 'breakdance'); ?></h3>
        <table class="form-table" role="presentation">
            <tbody>
                <tr>
                    <th scope="row">
                        <?php esc_html_e('Limit Revisions', 'breakdance'); ?>
                    </th>
                    <td>
                        <fieldset>
                            <label for="enable_revision_limit">
                                <input type="checkbox" <?php echo $enable_revision_limit ? 'checked' : ''; ?> name="breakdance_settings_enable_revision_limit" value="yes" id="enable_revision_limit"> <?php esc_html_e('Enable', 'breakdance'); ?>
                            </label>
                        </fieldset>

                        <p class="description"><?php
                            /* translators: 1: Plugin name, 2: Setting name in <code> tags */
                            printf(esc_html__('For each page, on save, if the quantity of stored revisions of %1$s content is higher than the %2$s setting, the oldest revisions will be removed your database.', 'breakdance'), esc_html($bdoroxy), '<code>' . esc_html__('Max Revisions', 'breakdance') . '</code>');
                        ?></p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <?php esc_html_e('Max Revisions', 'breakdance'); ?>
                    </th>
                    <td>
                        <fieldset>
                            <label for="revision_limit">
                                <input type="number" value="<?php echo (string) $revision_limit; ?>" name="breakdance_settings_revision_limit" id="revision_limit">
                            </label>
                        </fieldset>

                        <p class="description"><?php
                            /* translators: 1: Setting name in <code> tags, 2: Plugin name */
                            printf(esc_html__('If %1$s is enabled, this is the max number of revisions of %2$s content that will be kept for each page.', 'breakdance'), '<code>' . esc_html__('Limit Revisions', 'breakdance') . '</code>', esc_html($bdoroxy));
                        ?></p>
                    </td>
                </tr>
            </tbody>
        </table>

        <p class="submit">
            <input type="submit" name="submit" id="submit" class="button button-primary" value="<?php esc_attr_e('Save Changes', 'breakdance'); ?>">
        </p>

    </form>
<?php
}
