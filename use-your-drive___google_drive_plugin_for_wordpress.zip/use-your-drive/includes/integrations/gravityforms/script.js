(function ($) {
    'use strict';
    var unsubscribeBridge = null;

    /* binding to the load field settings event to initialize */
    $(document).on('gform_load_field_settings', function (event, field, form) {
        jQuery('#field_wpcp_useyourdrive').val(field.defaultValue);
        if (field['UseyourdriveShortcode'] !== undefined && field['UseyourdriveShortcode'] !== '') {
            jQuery('#field_wpcp_useyourdrive').val(field['UseyourdriveShortcode']);
        }
    });

    /* Shortcode Generator Popup */
    $('.wpcp-shortcodegenerator.useyourdrive').on('click', function (e) {
        var raw_content = jQuery('#field_wpcp_useyourdrive').val();
        var shortcode = raw_content.replace('</p>', '').replace('<p>', '');
        var query = 'shortcode=' + WPCP_shortcodeEncode(shortcode);
        var instanceId = window.WPCP_Bridge.createInstanceId();
        unsubscribeBridge = window.WPCP_Bridge.subscribe(
            'use-your-drive',
            'wpcp-shortcode',
            instanceId,
            function (data) {
                if (!data || typeof data.shortcode !== 'string') {
                    return;
                }

                $('#field_wpcp_useyourdrive').val(data.shortcode);
                SetFieldProperty('UseyourdriveShortcode', data.shortcode);
                unsubscribeBridge();
                unsubscribeBridge = null;
                tb_remove();
            }
        );
        tb_show(
            'Upload Configuration',
            ajaxurl +
                '?action=useyourdrive-getpopup&' +
                query +
                '&type=modules&foruploadfield=1&callback=uses_listener&wpcp_instance_id=' + encodeURIComponent(instanceId) + '&TB_iframe=true&height=768&width=1024'
        );
    });
})(jQuery);
