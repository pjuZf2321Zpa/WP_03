<?php

namespace WPAICG\ContentWriter\SEO;

use WPAICG\AIPKit_Providers;
use WPAICG\Core\AIPKit_AI_Caller;
use WPAICG\SEO\AIPKit_SEO_Helper;
use WP_Error;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Resolves Smart SEO focus keyphrases before dependent generation steps.
 */
class AIPKit_Content_Writer_Smart_SEO_Keyword_Resolver
{
    public function maybe_resolve_keywords(string $keywords, array $config, AIPKit_AI_Caller $ai_caller, array $context = []): array
    {
        $parts = array_map('trim', explode(',', $keywords));
        $first_keyword = isset($parts[0]) ? $this->normalize_keyword($parts[0]) : '';
        $result = $this->maybe_resolve_keyword($first_keyword, $config, $ai_caller, $context);

        if (!empty($result['changed'])) {
            $parts[0] = (string) $result['keyword'];
            $result['keywords'] = implode(', ', array_values(array_filter($parts)));
        } else {
            $result['keywords'] = $keywords;
        }

        return $result;
    }

    public function maybe_resolve_keyword(string $keyword, array $config, AIPKit_AI_Caller $ai_caller, array $context = []): array
    {
        $keyword = $this->normalize_keyword($keyword);
        $result = [
            'keyword' => $keyword,
            'keywords' => $keyword,
            'original_keyword' => $keyword,
            'changed' => false,
            'used_count' => 0,
            'usage' => null,
            'reason' => '',
            'warning' => '',
            'skipped' => false,
            'skip_reason' => '',
            'smart_seo_model' => null,
            'smart_seo_model_fallbacks' => [],
        ];

        if ($keyword === '') {
            $result['skipped'] = true;
            $result['skip_reason'] = 'empty_keyword';
            return $result;
        }

        if (!$this->should_resolve($config)) {
            $result['skipped'] = true;
            $result['skip_reason'] = 'not_applicable';
            return $result;
        }

        $profile = $this->active_profile();
        $profile_key = isset($profile['profile']) ? sanitize_key((string) $profile['profile']) : '';
        $rule_context = array_merge($config, $context);
        $length_rule_enabled = $this->rule_enabled($rule_context, 'focus_keyword_length');
        $duplicate_rule_enabled = $this->rule_enabled($rule_context, 'previously_used_keyphrase');
        $needs_concise_keyphrase = $length_rule_enabled && $this->needs_concise_keyphrase($keyword, $profile_key);
        $needs_locale_safe_keyphrase = $length_rule_enabled && $this->needs_locale_safe_keyphrase($keyword, $profile_key);
        $exclude_post_id = $this->resolve_excluded_post_id($context, $config);
        $used_count = $duplicate_rule_enabled ? $this->count_used_focus_keyword($keyword, $exclude_post_id) : 0;
        $result['used_count'] = $used_count;
        if ($used_count === 0 && !$needs_concise_keyphrase && !$needs_locale_safe_keyphrase) {
            return $result;
        }

        if ($used_count > 0) {
            $reason = 'duplicate';
        } elseif ($needs_concise_keyphrase) {
            $reason = 'length';
        } else {
            $reason = 'locale';
        }

        if ($reason === 'duplicate') {
            $deterministic_candidate = $this->deterministic_duplicate_candidate($keyword, $context, $profile_key, $exclude_post_id);
            if ($deterministic_candidate !== '') {
                $result['keyword'] = $deterministic_candidate;
                $result['keywords'] = $deterministic_candidate;
                $result['changed'] = true;
                $result['reason'] = $reason;
                return $result;
            }
        }

        $provider = $this->normalize_provider((string) ($context['ai_provider'] ?? $config['ai_provider'] ?? $config['provider'] ?? ''));
        $model = sanitize_text_field((string) ($context['ai_model'] ?? $config['ai_model'] ?? $config['model'] ?? ''));
        if ($provider === '' || $model === '') {
            switch ($reason) {
                case 'length':
                    $result['warning'] = __('Smart SEO could not shorten the focus keyphrase because the AI model is missing.', 'gpt3-ai-content-generator');
                    break;
                case 'locale':
                    $result['warning'] = __('Smart SEO could not adapt the focus keyphrase for SEO plugin matching because the AI model is missing.', 'gpt3-ai-content-generator');
                    break;
                default:
                    $result['warning'] = __('Smart SEO could not resolve a duplicate focus keyphrase because the AI model is missing.', 'gpt3-ai-content-generator');
                    break;
            }
            return $result;
        }

        $seen = [$this->keyword_key($keyword) => true];
        $usage = $this->empty_usage();
        for ($attempt = 1; $attempt <= 2; $attempt++) {
            $candidate_result = $this->generate_candidate($keyword, $config, $context, $provider, $model, $ai_caller, $attempt, $reason, $profile_key);
            if (is_wp_error($candidate_result)) {
                $error_data = $candidate_result->get_error_data();
                if (is_array($error_data) && !empty($error_data['smart_seo_model_fallbacks']) && is_array($error_data['smart_seo_model_fallbacks'])) {
                    $result['smart_seo_model_fallbacks'] = array_merge($result['smart_seo_model_fallbacks'], $error_data['smart_seo_model_fallbacks']);
                }
                $result['warning'] = $candidate_result->get_error_message();
                break;
            }

            if (!empty($candidate_result['smart_seo_model']) && is_array($candidate_result['smart_seo_model'])) {
                $result['smart_seo_model'] = $candidate_result['smart_seo_model'];
            }
            if (!empty($candidate_result['smart_seo_model_fallbacks']) && is_array($candidate_result['smart_seo_model_fallbacks'])) {
                $result['smart_seo_model_fallbacks'] = array_merge($result['smart_seo_model_fallbacks'], $candidate_result['smart_seo_model_fallbacks']);
            }
            $this->add_usage($usage, $candidate_result['usage'] ?? null);
            $candidate = $this->normalize_keyword((string) ($candidate_result['keyword'] ?? ''));
            $candidate_key = $this->keyword_key($candidate);
            if ($candidate === '' || isset($seen[$candidate_key])) {
                continue;
            }
            if (!$this->is_acceptable_for_profile($candidate, $profile_key)) {
                continue;
            }
            $seen[$candidate_key] = true;

            $candidate_count = $this->count_used_focus_keyword($candidate, $exclude_post_id);
            if ($candidate_count === 0) {
                $result['keyword'] = $candidate;
                $result['keywords'] = $candidate;
                $result['changed'] = true;
                $result['reason'] = $reason;
                $result['usage'] = $usage['total_tokens'] > 0 ? $usage : null;
                return $result;
            }
        }

        if ($result['warning'] === '') {
            switch ($reason) {
                case 'length':
                    $result['warning'] = __('Smart SEO could not find a concise focus keyphrase variant.', 'gpt3-ai-content-generator');
                    break;
                case 'locale':
                    $result['warning'] = __('Smart SEO could not find an SEO plugin compatible focus keyphrase variant.', 'gpt3-ai-content-generator');
                    break;
                default:
                    $result['warning'] = __('Smart SEO could not find a unique focus keyphrase variant.', 'gpt3-ai-content-generator');
                    break;
            }
        }
        $result['usage'] = $usage['total_tokens'] > 0 ? $usage : null;

        return $result;
    }

    public function count_used_focus_keyword(string $focus_keyword, int $exclude_post_id = 0): int
    {
        if (!class_exists(AIPKit_Content_Writer_Smart_SEO_Keyphrase_Usage::class) && defined('WPAICG_LIB_DIR')) {
            $usage_path = WPAICG_LIB_DIR . 'content-writer/seo-keyphrase-usage.php';
            if (file_exists($usage_path)) {
                require_once $usage_path;
            }
        }

        if (!class_exists(AIPKit_Content_Writer_Smart_SEO_Keyphrase_Usage::class)) {
            return 0;
        }

        return AIPKit_Content_Writer_Smart_SEO_Keyphrase_Usage::count_used_focus_keyword($focus_keyword, $exclude_post_id);
    }

    private function should_resolve(array $config): bool
    {
        if (!class_exists(AIPKit_Content_Writer_SEO_Config::class) || !AIPKit_Content_Writer_SEO_Config::is_enabled($config)) {
            return false;
        }

        if (!AIPKit_Content_Writer_SEO_Config::is_pro_plan()) {
            return false;
        }

        if (!class_exists(AIPKit_SEO_Helper::class)) {
            return false;
        }

        $profile = AIPKit_SEO_Helper::get_active_plugin_profile();
        return isset($profile['profile']) && in_array(sanitize_key((string) $profile['profile']), ['yoast', 'rank_math'], true);
    }

    private function rule_enabled(array $context, string $rule_id): bool
    {
        return !class_exists(AIPKit_Content_Writer_SEO_Config::class)
            || AIPKit_Content_Writer_SEO_Config::is_rule_enabled($context, $rule_id);
    }

    /**
     * @return mixed[]|\WP_Error
     */
    private function generate_candidate(string $original_keyword, array $config, array $context, string $provider, string $model, AIPKit_AI_Caller $ai_caller, int $attempt, string $reason, string $profile_key)
    {
        $topic = sanitize_text_field((string) ($context['topic'] ?? $config['content_title'] ?? ''));
        $title = sanitize_text_field((string) ($context['title'] ?? $topic));
        $summary = trim(wp_strip_all_tags((string) ($context['content_summary'] ?? '')));
        $keywords = sanitize_text_field((string) ($context['keywords'] ?? $config['content_keywords'] ?? ''));
        $max_words = $profile_key === 'yoast' ? 4 : 6;
        switch ($reason) {
            case 'length':
                $intro = 'Create one concise SEO focus keyphrase for this WordPress article.';
                break;
            case 'locale':
                $intro = 'Create one SEO plugin compatible focus keyphrase variant for this WordPress article.';
                break;
            default:
                $intro = 'Create one unique SEO focus keyphrase variant for this WordPress article.';
                break;
        }
        switch ($reason) {
            case 'length':
                $current_line = sprintf('Current focus keyphrase is too long for the active SEO plugin: %s', $original_keyword);
                break;
            case 'locale':
                $current_line = sprintf('Current focus keyphrase may not be recognized by the active SEO plugin in this site locale: %s', $original_keyword);
                break;
            default:
                $current_line = sprintf('Current focus keyphrase already used: %s', $original_keyword);
                break;
        }

        $prompt = implode("\n\n", array_filter([
            $intro,
            $current_line,
            $title !== '' ? sprintf('Article title: %s', $title) : '',
            $topic !== '' ? sprintf('Article topic: %s', $topic) : '',
            $keywords !== '' ? sprintf('Original keyword context: %s', $keywords) : '',
            $summary !== '' ? sprintf('Article summary: %s', $summary) : '',
            sprintf('Attempt: %d', max(1, $attempt)),
            'Rules:',
            '- Return only one plain-text keyphrase.',
            '- Preserve the same search intent.',
            '- Prefer wording that already appears naturally in the article content or summary.',
            '- Do not return the exact current focus keyphrase.',
            $reason === 'locale' ? '- Prefer a natural phrase that avoids locale-sensitive character matching issues. Do not awkwardly transliterate proper nouns.' : '',
            sprintf('- Use 2 to %d words.', $max_words),
            '- Do not include quotes, punctuation, commas, hashtags, or explanations.',
        ]));

        $result = class_exists(AIPKit_Content_Writer_Smart_SEO_Model_Policy::class)
            ? AIPKit_Content_Writer_Smart_SEO_Model_Policy::make_standard_call(
                $ai_caller,
                $provider,
                $model,
                [['role' => 'user', 'content' => $prompt]],
                ['temperature' => 0.35, 'top_p' => null],
                'You are an SEO strategist. Return one unique focus keyphrase only.',
                []
            )
            : $ai_caller->make_standard_call(
                $provider,
                $model,
                [['role' => 'user', 'content' => $prompt]],
                ['temperature' => 0.35, 'top_p' => null],
                'You are an SEO strategist. Return one unique focus keyphrase only.',
                []
            );

        if (is_wp_error($result)) {
            return $result;
        }

        return [
            'keyword' => isset($result['content']) ? (string) $result['content'] : '',
            'usage' => $result['usage'] ?? null,
            'smart_seo_model' => $result['smart_seo_model'] ?? null,
            'smart_seo_model_fallbacks' => $result['smart_seo_model_fallbacks'] ?? [],
        ];
    }

    private function normalize_keyword(string $keyword): string
    {
        $keyword = trim(wp_strip_all_tags($keyword));
        $keyword = preg_replace('/^[\'"`“”‘’\s]+|[\'"`“”‘’\s]+$/u', '', (string) $keyword);
        $keyword = preg_replace('/[.,;:!?]+$/', '', (string) $keyword);
        $keyword = preg_replace('/\s+/u', ' ', (string) $keyword);
        return trim((string) $keyword);
    }

    private function active_profile(): array
    {
        if (!class_exists(AIPKit_SEO_Helper::class)) {
            return [];
        }

        $profile = AIPKit_SEO_Helper::get_active_plugin_profile();
        return is_array($profile) ? $profile : [];
    }

    private function needs_concise_keyphrase(string $keyword, string $profile_key): bool
    {
        return $profile_key === 'yoast' && $this->keyword_word_count($keyword) > 4;
    }

    private function needs_locale_safe_keyphrase(string $keyword, string $profile_key): bool
    {
        if ($profile_key !== 'yoast') {
            return false;
        }

        $locale = function_exists('get_locale') ? (string) get_locale() : '';
        if (strncmp(strtolower($locale), 'tr', strlen('tr')) === 0) {
            return false;
        }

        return preg_match('/[İıŞşĞğÜüÖöÇç]/u', $keyword) === 1;
    }

    private function is_acceptable_for_profile(string $keyword, string $profile_key): bool
    {
        return !$this->needs_concise_keyphrase($keyword, $profile_key)
            && !$this->needs_locale_safe_keyphrase($keyword, $profile_key);
    }

    private function deterministic_duplicate_candidate(string $keyword, array $context, string $profile_key, int $exclude_post_id): string
    {
        if ($this->keyword_word_count($keyword) !== 1) {
            return '';
        }

        $topic = $this->normalize_keyword((string) ($context['topic'] ?? $context['title'] ?? ''));
        if ($topic === '') {
            return '';
        }

        $max_words = $profile_key === 'yoast' ? 4 : 6;
        $keyword_key = $this->keyword_key($keyword);
        $topic_words = $this->significant_topic_words($topic, max(1, $max_words - 1));
        if (empty($topic_words)) {
            return '';
        }

        $topic_key = $this->keyword_key(implode(' ', $topic_words));
        $candidate = strpos(' ' . $topic_key . ' ', ' ' . $keyword_key . ' ') !== false
            ? implode(' ', $topic_words)
            : implode(' ', array_merge($topic_words, [$keyword]));
        $candidate = $this->normalize_keyword($candidate);
        if ($candidate === '' || $this->keyword_key($candidate) === $keyword_key) {
            return '';
        }

        if (!$this->is_acceptable_for_profile($candidate, $profile_key)) {
            return '';
        }

        return $this->count_used_focus_keyword($candidate, $exclude_post_id) === 0 ? $candidate : '';
    }

    /**
     * @return string[]
     */
    private function significant_topic_words(string $topic, int $limit): array
    {
        $topic = preg_replace('/\|.*$/', '', $topic);
        $topic = preg_replace('/[^\p{L}\p{N}\s\'’-]+/u', ' ', (string) $topic);
        $words = preg_split('/\s+/u', trim((string) $topic)) ?: [];
        $stop_words = array_fill_keys([
            'a', 'an', 'and', 'are', 'as', 'at', 'best', 'buy', 'for', 'from',
            'guide', 'how', 'in', 'into', 'of', 'on', 'or', 'the', 'to', 'with',
        ], true);
        $significant = [];
        foreach ($words as $word) {
            $word = trim((string) $word);
            if ($word === '' || isset($stop_words[strtolower($word)])) {
                continue;
            }
            $significant[] = $word;
            if (count($significant) >= $limit) {
                break;
            }
        }

        return $significant;
    }

    private function keyword_word_count(string $keyword): int
    {
        if (!preg_match_all('/[\p{L}\p{N}][\p{L}\p{N}\'’-]*/u', $keyword, $matches)) {
            return 0;
        }

        return count($matches[0]);
    }

    private function keyword_key(string $keyword): string
    {
        $keyword = function_exists('remove_accents') ? remove_accents($keyword) : $keyword;
        $keyword = function_exists('mb_strtolower') ? mb_strtolower($keyword, 'UTF-8') : strtolower($keyword);
        return preg_replace('/\s+/u', ' ', trim((string) $keyword));
    }

    private function resolve_excluded_post_id(array $context, array $config): int
    {
        foreach (['exclude_post_id', 'post_id', 'current_post_id', 'draft_post_id', 'object_id', 'objectID'] as $key) {
            $post_id = isset($context[$key]) ? absint($context[$key]) : 0;
            if ($post_id > 0) {
                return $post_id;
            }
        }

        foreach (['exclude_post_id', 'post_id', 'current_post_id', 'draft_post_id', 'object_id', 'objectID'] as $key) {
            $post_id = isset($config[$key]) ? absint($config[$key]) : 0;
            if ($post_id > 0) {
                return $post_id;
            }
        }

        return 0;
    }

    private function normalize_provider(string $provider): string
    {
        return AIPKit_Providers::normalize_provider_label($provider);
    }

    private function empty_usage(): array
    {
        return [
            'input_tokens' => 0,
            'output_tokens' => 0,
            'total_tokens' => 0,
            'provider_raw' => [],
        ];
    }

    /**
     * @param mixed $usage
     */
    private function add_usage(array &$aggregate, $usage): void
    {
        if (!is_array($usage)) {
            return;
        }

        $aggregate['input_tokens'] += (int) ($usage['input_tokens'] ?? 0);
        $aggregate['output_tokens'] += (int) ($usage['output_tokens'] ?? 0);
        $aggregate['total_tokens'] += (int) ($usage['total_tokens'] ?? 0);
        if (isset($usage['provider_raw'])) {
            $aggregate['provider_raw'][] = $usage['provider_raw'];
        }
    }
}
