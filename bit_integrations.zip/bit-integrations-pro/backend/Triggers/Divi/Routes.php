<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Core\Util\Route;
use BitApps\IntegrationsPro\Triggers\Divi\DiviController;

Route::get('divi/get', [DiviController::class, 'getAllTasks']);
