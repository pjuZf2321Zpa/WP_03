<?php if ( ! defined( 'ABSPATH' ) ) {
	die( 'No direct access allowed' );} ?>
<?php
if ( ! class_exists( 'WooCommerce' ) ) {
	echo "<div class='notice'>" . esc_html__( 'Warning: Woocommerce is not activated', 'woocommerce-currency-switcher' ) . '</div>';
	return;
}
global $WOOCS;
$currencies = $WOOCS->get_currencies();
// ***
if ( isset( $exclude ) ) {
	$exclude_string = $exclude;
	$exclude        = explode( ',', $exclude );
} else {
	$exclude_string = '';
	$exclude        = array();
}
// ***
if ( ! isset( $current_currency ) ) {
	$current_currency = $WOOCS->current_currency;
}

// ***

if ( ! isset( $precision ) ) {
	$precision = 2;
}
?>

<div class="woocs_rates_shortcode">

	<?php if ( ! empty( $currencies ) ) : ?>
		<select class="woocs_rates_current_currency" data-precision="<?php echo intval( $precision ); ?>" data-exclude="<?php echo esc_attr( $exclude_string ); ?>">
			<?php
			if ( ! empty( $currencies ) ) {
				foreach ( $currencies as $key => $c ) {

					if ( isset( $c['hide_on_front'] ) and $c['hide_on_front'] ) {
						continue;
					}

					if ( in_array( $key, $exclude ) ) {
						continue;
					}
					?>
					<option <?php selected( $current_currency, $key ); ?> value="<?php echo esc_attr( $key ); ?>">
					<?php
					// translators: %s is a currency code or value.
					printf( esc_html__( '1 %s is', 'woocommerce-currency-switcher' ), esc_html( $c['name'] ) )
					?>
					</option>
					<?php
				}
			}
			?>
		</select><br />

		<div class="woocs-data-table" id="woocs-currencies-options">

			<div class="scrollbar-external_wrapper">
				<div class="scrollbar-external">
					<table>
						<thead>
							<tr>
								<th><?php echo esc_html__( 'Flag', 'woocommerce-currency-switcher' ); ?></th>
								<th><?php echo esc_html__( 'Currency', 'woocommerce-currency-switcher' ); ?></th>
								<th><?php echo esc_html__( 'Rate', 'woocommerce-currency-switcher' ); ?></th>

							</tr>
						</thead>
						<tfoot>
							<tr>
								<th><?php echo esc_html__( 'Flag', 'woocommerce-currency-switcher' ); ?></th>
								<th><?php echo esc_html__( 'Currency', 'woocommerce-currency-switcher' ); ?></th>
								<th><?php echo esc_html__( 'Rate', 'woocommerce-currency-switcher' ); ?></th>

							</tr>
						</tfoot>
						<tbody id="woocs_list">
							<?php foreach ( $currencies as $key => $c ) : ?>
								<?php
								if ( isset( $c['hide_on_front'] ) and $c['hide_on_front'] ) {
									continue;
								}
								if ( $key == $current_currency or in_array( $key, $exclude ) ) {
									continue;
								}
								?>
																<tr>
									<td>                    
										<?php if ( ! empty( $c['flag'] ) ) : ?>
											<img class="woocs_currency_rate_flag" src="<?php echo esc_attr( $c['flag'] ); ?>" alt="<?php echo esc_attr( $c['name'] ); ?>" />
										<?php endif; ?>
									</td>
									<td>
										<strong><?php echo esc_html( $key ); ?></strong>
									</td>
									<td>
										<?php
										$rate = $currencies[ $current_currency ]['rate'];
										if ( ! $rate or $rate == 0 ) {
											$rate = 1;
										}
										$v = $c['rate'] / $rate;
										echo number_format( $v, intval( $precision ), $this->decimal_sep, '' );
										?>
																			</td>
								</tr>
							<?php endforeach; ?>
						</tbody>
					</table>
				</div>
			</div>


			<div class="external-scroll_wrapper">
				<div class="external-scroll_x">
					<div class="scroll-element_outer">
						<div class="scroll-element_size"></div>
						<div class="scroll-element_track"></div>
						<div class="scroll-bar"></div>
					</div>
				</div>
			</div>



		</div>       






	<?php endif; ?>

</div>

