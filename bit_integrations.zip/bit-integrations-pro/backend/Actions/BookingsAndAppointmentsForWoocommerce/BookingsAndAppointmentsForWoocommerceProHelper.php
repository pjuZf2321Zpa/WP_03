<?php

namespace BitApps\IntegrationsPro\Actions\BookingsAndAppointmentsForWoocommerce;

use Ph_Booking_Manage_Availability_Data;
use Ph_Bookings_General_Functions_Class;
use Throwable;
use WC_Order;
use WC_Order_Factory;
use WC_Order_Item_Product;
use WC_Product_phive_booking;
use WP_User;

final class BookingsAndAppointmentsForWoocommerceProHelper
{
    private const DATE_FORMATS = [
        'minute' => 'Y-m-d H:i',
        'hour'   => 'Y-m-d H:i',
        'day'    => 'Y-m-d',
        'month'  => 'Y-m',
    ];

    public static function createBooking($response, $fieldData, $integrationDetails = null)
    {
        $productId = (int) ($integrationDetails->selectedProduct ?? 0);
        $product = $productId ? wc_get_product($productId) : null;

        if (!$product instanceof WC_Product_phive_booking) {
            return ['success' => false, 'message' => __('Select a bookable product.', 'bit-integrations-pro')];
        }

        if (empty($fieldData['from']) || empty($fieldData['to'])) {
            return ['success' => false, 'message' => __('From and To dates are required.', 'bit-integrations-pro')];
        }

        $dates = static::normalizeBookingDates($productId, $fieldData['from'], $fieldData['to']);

        if (!$dates) {
            return ['success' => false, 'message' => __('Invalid booking dates. Use a date like 2026-06-10 14:30 and make sure To is not before From.', 'bit-integrations-pro')];
        }

        $customerId = (int) ($integrationDetails->selectedCustomer ?? 0);
        $customer = $customerId ? get_user_by('id', $customerId) : null;

        if ($customerId && !$customer) {
            return ['success' => false, 'message' => __('The selected customer no longer exists.', 'bit-integrations-pro')];
        }

        $assetId = $integrationDetails->selectedAsset ?? '';
        $asset = empty($assetId) ? null : static::findAsset($assetId);

        if (!empty($assetId) && !$asset) {
            return ['success' => false, 'message' => __('Asset not found. Create it under Bookings > Settings > Global Assets.', 'bit-integrations-pro')];
        }

        $order = wc_create_order();

        if (!$order instanceof WC_Order) {
            return ['success' => false, 'message' => __('Failed to create the WooCommerce order.', 'bit-integrations-pro')];
        }

        if ($customer) {
            static::assignCustomer($order, $customer);
        }

        $itemId = $order->add_product($product, 1);

        if (!$itemId) {
            return ['success' => false, 'message' => __('Failed to add the booking line item to the order.', 'bit-integrations-pro')];
        }

        static::saveBookingDates($itemId, $productId, $dates);
        wc_update_order_item_meta($itemId, 'booking_status', ['un-paid']);

        if (\function_exists('ph_map_booking_status_to_name')) {
            wc_update_order_item_meta($itemId, 'Booking Status', ph_map_booking_status_to_name('un-paid'));
        }

        if (!empty($fieldData['number_of_persons'])) {
            wc_update_order_item_meta($itemId, 'Number of persons', (int) $fieldData['number_of_persons']);
            wc_update_order_item_meta($itemId, 'Total Number of Participants', (int) $fieldData['number_of_persons']);
        }

        if ($asset) {
            static::saveAsset($itemId, $productId, $asset);
        }

        $order->calculate_totals();
        $order->save();

        if (class_exists('Ph_Booking_Manage_Availability_Data')) {
            try {
                (new Ph_Booking_Manage_Availability_Data())->ph_bookings_insert_data_in_availability_table_when_order_created($order);
            } catch (Throwable $e) {
                return ['success' => true, 'message' => __('Booking created, but the availability table could not be updated.', 'bit-integrations-pro'), 'item_id' => $itemId, 'order_id' => $order->get_id()];
            }
        }

        return ['success' => true, 'message' => __('Booking created.', 'bit-integrations-pro'), 'item_id' => $itemId, 'order_id' => $order->get_id()];
    }

    public static function updateBookingStatus($response, $fieldData, $integrationDetails = null)
    {
        $item = static::findOrderItem($fieldData['item_id'] ?? 0);

        if (!$item) {
            return ['success' => false, 'message' => __('Booking not found.', 'bit-integrations-pro')];
        }

        $status = $integrationDetails->selectedStatus ?? '';

        if (empty($status)) {
            return ['success' => false, 'message' => __('Select a status.', 'bit-integrations-pro')];
        }

        $itemId = (int) $fieldData['item_id'];
        $orderId = (int) $item->get_order_id();
        $order = wc_get_order($orderId);

        wc_update_order_item_meta($itemId, 'booking_status', [$status]);

        if (\function_exists('ph_map_booking_status_to_name')) {
            wc_update_order_item_meta($itemId, 'Booking Status', ph_map_booking_status_to_name($status));
        }

        // The plugin stores "canceled" but its own listeners expect "cancelled" on this hook.
        do_action('ph_booking_status_changed', $status === 'canceled' ? 'cancelled' : $status, $itemId, $orderId, $order);

        return ['success' => true, 'message' => __('Booking status updated.', 'bit-integrations-pro')];
    }

    public static function confirmBooking($response, $fieldData)
    {
        $item = static::findOrderItem($fieldData['item_id'] ?? 0);

        if (!$item) {
            return ['success' => false, 'message' => __('Booking not found.', 'bit-integrations-pro')];
        }

        $itemId = (int) $fieldData['item_id'];
        $orderId = (int) $item->get_order_id();
        $order = wc_get_order($orderId);

        wc_update_order_item_meta($itemId, 'confirmed', 'yes');

        $stored = 'un-paid';

        if ($order instanceof WC_Order) {
            $orderTotal = $order->get_total();
            $wcStatus = $order->get_status();

            if ($orderTotal <= 0 || \in_array($wcStatus, ['processing', 'completed'], true)) {
                $stored = 'paid';
            }
        }

        wc_update_order_item_meta($itemId, 'booking_status', [$stored]);

        if (\function_exists('ph_map_booking_status_to_name')) {
            wc_update_order_item_meta($itemId, 'Booking Status', ph_map_booking_status_to_name($stored));
        }

        do_action('ph_booking_status_changed', 'confirmed', $itemId, $orderId);

        return ['success' => true, 'message' => __('Booking confirmed.', 'bit-integrations-pro')];
    }

    public static function cancelBooking($response, $fieldData)
    {
        $item = static::findOrderItem($fieldData['item_id'] ?? 0);

        if (!$item) {
            return ['success' => false, 'message' => __('Booking not found.', 'bit-integrations-pro')];
        }

        $itemId = (int) $fieldData['item_id'];
        $orderId = (int) $item->get_order_id();
        $order = wc_get_order($orderId);

        wc_update_order_item_meta($itemId, 'canceled', 'yes');
        wc_update_order_item_meta($itemId, 'booking_status', ['canceled']);
        wc_update_order_item_meta($itemId, 'Booking Status', 'cancelled');

        do_action('ph_zoom_update_meeting_status_as_deleted', $itemId);
        do_action('ph_booking_status_changed', 'cancelled', $itemId, $orderId, $order);

        if ($order instanceof WC_Order && static::allItemsCancelled($order)) {
            $order->update_status('wc-cancelled');
        }

        return ['success' => true, 'message' => __('Booking cancelled.', 'bit-integrations-pro')];
    }

    public static function deleteBooking($response, $fieldData)
    {
        $item = static::findOrderItem($fieldData['item_id'] ?? 0);

        if (!$item) {
            return ['success' => false, 'message' => __('Booking not found.', 'bit-integrations-pro')];
        }

        $itemId = (int) $fieldData['item_id'];
        $orderId = (int) $item->get_order_id();
        $bufferBeforeId = wc_get_order_item_meta($itemId, 'buffer_before_id', true);
        $bufferAfterId = wc_get_order_item_meta($itemId, 'buffer_after_id', true);

        do_action('ph_booking_status_changed', 'deleted', $itemId, $orderId);

        wc_delete_order_item($itemId);

        if (!empty($bufferBeforeId)) {
            wp_delete_post(\is_array($bufferBeforeId) ? $bufferBeforeId[0] : $bufferBeforeId);
        }

        if (!empty($bufferAfterId)) {
            wp_delete_post(\is_array($bufferAfterId) ? $bufferAfterId[0] : $bufferAfterId);
        }

        return ['success' => true, 'message' => __('Booking deleted.', 'bit-integrations-pro')];
    }

    public static function rescheduleBooking($response, $fieldData)
    {
        $item = static::findOrderItem($fieldData['item_id'] ?? 0);

        if (!$item) {
            return ['success' => false, 'message' => __('Booking not found.', 'bit-integrations-pro')];
        }

        if (empty($fieldData['from']) || empty($fieldData['to'])) {
            return ['success' => false, 'message' => __('From and To dates are required.', 'bit-integrations-pro')];
        }

        $itemId = (int) $fieldData['item_id'];
        $productId = ($item instanceof WC_Order_Item_Product) ? $item->get_product_id() : 0;
        $dates = static::normalizeBookingDates($productId, $fieldData['from'], $fieldData['to']);

        if (!$dates) {
            return ['success' => false, 'message' => __('Invalid booking dates. Use a date like 2026-06-10 14:30 and make sure To is not before From.', 'bit-integrations-pro')];
        }

        static::saveBookingDates($itemId, $productId, $dates);
        static::syncAvailability($itemId, (int) $item->get_order_id());

        return ['success' => true, 'message' => __('Booking rescheduled.', 'bit-integrations-pro')];
    }

    public static function updateBookingNotes($response, $fieldData)
    {
        $item = static::findOrderItem($fieldData['item_id'] ?? 0);

        if (!$item) {
            return ['success' => false, 'message' => __('Booking not found.', 'bit-integrations-pro')];
        }

        $itemId = (int) $fieldData['item_id'];
        $productId = ($item instanceof WC_Order_Item_Product) ? $item->get_product_id() : 0;
        $notesLabel = get_post_meta($productId, '_phive_additional_notes_label', true) ?: __('Notes', 'bit-integrations-pro');

        wc_update_order_item_meta($itemId, $notesLabel, $fieldData['notes'] ?? '');

        return ['success' => true, 'message' => __('Booking notes updated.', 'bit-integrations-pro')];
    }

    public static function updateBookingAsset($response, $fieldData, $integrationDetails = null)
    {
        $item = static::findOrderItem($fieldData['item_id'] ?? 0);

        if (!$item) {
            return ['success' => false, 'message' => __('Booking not found.', 'bit-integrations-pro')];
        }

        $assetId = $integrationDetails->selectedAsset ?? '';

        if (empty($assetId)) {
            return ['success' => false, 'message' => __('Select an asset.', 'bit-integrations-pro')];
        }

        $asset = static::findAsset($assetId);

        if (!$asset) {
            return ['success' => false, 'message' => __('Asset not found. Create it under Bookings > Settings > Global Assets.', 'bit-integrations-pro')];
        }

        $itemId = (int) $fieldData['item_id'];

        static::saveAsset($itemId, ($item instanceof WC_Order_Item_Product) ? $item->get_product_id() : 0, $asset);
        static::syncAvailability($itemId, (int) $item->get_order_id());

        return ['success' => true, 'message' => __('Booking asset updated.', 'bit-integrations-pro')];
    }

    public static function updateBookingParticipants($response, $fieldData)
    {
        $item = static::findOrderItem($fieldData['item_id'] ?? 0);

        if (!$item) {
            return ['success' => false, 'message' => __('Booking not found.', 'bit-integrations-pro')];
        }

        $participants = static::parseParticipants($fieldData['participants'] ?? '');
        $participantError = static::validateParticipants(
            $participants,
            static::getParticipantTypes(($item instanceof WC_Order_Item_Product) ? $item->get_product_id() : 0)
        );

        if ($participantError) {
            return ['success' => false, 'message' => $participantError];
        }

        $itemId = (int) $fieldData['item_id'];

        static::saveParticipants($itemId, array_map('intval', $participants));
        static::syncAvailability($itemId, (int) $item->get_order_id());

        return ['success' => true, 'message' => __('Booking participants updated.', 'bit-integrations-pro')];
    }

    public static function sendBookingConfirmationEmail($response, $fieldData)
    {
        return static::sendStatusEmail($fieldData, 'Ph_WC_Email_Booking_Confirmation', 'confirmed');
    }

    public static function sendBookingCancelledEmail($response, $fieldData)
    {
        return static::sendStatusEmail($fieldData, 'Ph_WC_Email_Booking_Cancelled', 'cancelled');
    }

    public static function sendBookingRequiresConfirmationEmail($response, $fieldData)
    {
        return static::sendStatusEmail($fieldData, 'Ph_WC_Email_Booking_Requires_Confirmation', 'pending_payment');
    }

    public static function sendBookingUpdatedEmail($response, $fieldData, $integrationDetails = null)
    {
        $item = static::findOrderItem($fieldData['item_id'] ?? 0);

        if (!$item) {
            return ['success' => false, 'message' => __('Booking not found.', 'bit-integrations-pro')];
        }

        $itemId = (int) $fieldData['item_id'];
        $orderId = (int) $item->get_order_id();
        $order = wc_get_order($orderId);
        $notifyMode = $integrationDetails->selectedNotifyMode ?? 'details_and_payment';

        $email = static::resolveEmailInstance('Ph_WC_Email_Booking_Updated');

        if (!$email) {
            return ['success' => false, 'message' => __('Ph_WC_Email_Booking_Updated email class not found.', 'bit-integrations-pro')];
        }

        if (!$email->is_enabled()) {
            return static::disabledEmailResponse($email);
        }

        $email->trigger($orderId, $itemId, $order, $notifyMode);

        return ['success' => true, 'message' => __('Booking updated email sent.', 'bit-integrations-pro')];
    }

    public static function sendBookingPaymentEmail($response, $fieldData)
    {
        $item = static::findOrderItem($fieldData['item_id'] ?? 0);

        if (!$item) {
            return ['success' => false, 'message' => __('Booking not found.', 'bit-integrations-pro')];
        }

        $orderId = (int) $item->get_order_id();
        $order = wc_get_order($orderId);
        $toEmail = trim((string) ($fieldData['to_email'] ?? '')) ?: ($order instanceof WC_Order ? $order->get_billing_email() : '');

        if (!is_email($toEmail)) {
            return ['success' => false, 'message' => __('No valid recipient email. Map one to "Send To (Email)" or add a billing email to the booking order.', 'bit-integrations-pro')];
        }

        $email = static::resolveEmailInstance('Ph_WC_Email_Booking_Payment');

        if (!$email) {
            return ['success' => false, 'message' => __('Ph_WC_Email_Booking_Payment email class not found.', 'bit-integrations-pro')];
        }

        if (!$email->is_enabled()) {
            return static::disabledEmailResponse($email);
        }

        // The plugin's payment email ignores this argument; it always sends "pending_payment".
        $email->trigger($orderId, $toEmail, 'pending_payment', $order);

        return ['success' => true, 'message' => __('Booking payment email sent.', 'bit-integrations-pro')];
    }

    private static function sendStatusEmail($fieldData, $class, $status)
    {
        $item = static::findOrderItem($fieldData['item_id'] ?? 0);

        if (!$item) {
            return ['success' => false, 'message' => __('Booking not found.', 'bit-integrations-pro')];
        }

        $itemId = (int) $fieldData['item_id'];
        $orderId = (int) $item->get_order_id();
        $order = wc_get_order($orderId);

        $email = static::resolveEmailInstance($class);

        if (!$email) {
            // translators: %s is the WooCommerce email class name that could not be resolved.
            return ['success' => false, 'message' => \sprintf(__('%s email class not found.', 'bit-integrations-pro'), $class)];
        }

        if (!$email->is_enabled()) {
            return static::disabledEmailResponse($email);
        }

        $email->trigger($orderId, $status, $itemId, $order);

        return ['success' => true, 'message' => __('Booking status email sent.', 'bit-integrations-pro')];
    }

    private static function disabledEmailResponse($email)
    {
        return [
            'success' => false,
            // translators: %s is the WooCommerce email title, e.g. "Booking Payment".
            'message' => \sprintf(__('The "%s" email is disabled. Enable it in WooCommerce > Settings > Emails.', 'bit-integrations-pro'), $email->get_title()),
        ];
    }

    private static function resolveEmailInstance($class)
    {
        if (!\function_exists('WC') || !WC()->mailer()) {
            return;
        }

        foreach (WC()->mailer()->get_emails() as $registeredEmail) {
            if ($registeredEmail instanceof $class) {
                return $registeredEmail;
            }
        }

        return class_exists($class) ? new $class() : null;
    }

    private static function findOrderItem($itemId)
    {
        return WC_Order_Factory::get_order_item((int) $itemId) ?: null;
    }

    private static function allItemsCancelled($order)
    {
        foreach ($order->get_items() as $item) {
            if ($item->get_meta('canceled') !== 'yes') {
                return false;
            }
        }

        return true;
    }

    private static function assignCustomer(WC_Order $order, WP_User $user)
    {
        $order->set_customer_id($user->ID);
        $order->set_billing_email(get_user_meta($user->ID, 'billing_email', true) ?: $user->user_email);
        $order->set_billing_first_name(get_user_meta($user->ID, 'billing_first_name', true) ?: $user->first_name);
        $order->set_billing_last_name(get_user_meta($user->ID, 'billing_last_name', true) ?: $user->last_name);
    }

    // For hour/minute products the plugin stores the start of the last slot in `To`, so the given end time moves back one interval.
    private static function normalizeBookingDates($productId, $from, $to)
    {
        $fromTime = strtotime((string) $from);
        $toTime = strtotime((string) $to);

        if (!$fromTime || !$toTime || $toTime < $fromTime) {
            return;
        }

        $settings = static::getProductSettings($productId);
        $period = $settings['interval_period'] ?? 'day';
        $format = self::DATE_FORMATS[$period] ?? 'Y-m-d H:i';

        if (!\in_array($period, ['hour', 'minute'], true)) {
            return [
                'from'      => gmdate($format, $fromTime),
                'to'        => gmdate($format, $toTime),
                'booked_to' => gmdate($format, $toTime),
            ];
        }

        $interval = max(1, (int) ($settings['interval'] ?? 1));
        $lastSlotStart = max($fromTime, strtotime("-{$interval} {$period}", $toTime));

        return [
            'from'      => gmdate($format, $fromTime),
            'to'        => gmdate($format, $lastSlotStart),
            'booked_to' => gmdate($format, strtotime("+{$interval} {$period}", $lastSlotStart)),
        ];
    }

    private static function saveBookingDates($itemId, $productId, array $dates)
    {
        $settings = static::getProductSettings($productId);
        $displaySettings = get_option('ph_bookings_display_settigns', []);
        $labels = \is_array($displaySettings) ? ($displaySettings['text_customisation'] ?? []) : [];

        wc_update_order_item_meta($itemId, 'From', [$dates['from']]);
        wc_update_order_item_meta($itemId, 'To', [$dates['to']]);
        wc_update_order_item_meta($itemId, empty($labels['booked_from_text']) ? 'Booked From' : $labels['booked_from_text'], static::formatDisplayDate($dates['from']));
        wc_update_order_item_meta($itemId, empty($labels['booked_to_text']) ? 'Booked To' : $labels['booked_to_text'], static::formatDisplayDate($dates['booked_to']));
        wc_update_order_item_meta(
            $itemId,
            '_phive_booking_product_interval_details',
            ['interval' => $settings['interval'] ?? '', 'interval_format' => $settings['interval_period'] ?? '']
        );
    }

    private static function findAsset($assetIdOrName)
    {
        $assetIdOrName = trim((string) $assetIdOrName);
        $assetSettings = get_option('ph_booking_settings_assets', []);
        $assets = \is_array($assetSettings) ? (array) ($assetSettings['_phive_booking_assets'] ?? []) : [];

        if (isset($assets[$assetIdOrName])) {
            return $assets[$assetIdOrName] + ['ph_booking_asset_id' => $assetIdOrName];
        }

        foreach ($assets as $assetId => $asset) {
            if (strcasecmp($asset['ph_booking_asset_name'] ?? '', $assetIdOrName) === 0) {
                return $asset + ['ph_booking_asset_id' => $assetId];
            }
        }
    }

    private static function saveAsset($itemId, $productId, array $asset)
    {
        $assetLabel = get_post_meta($productId, '_phive_booking_assets_label', true) ?: 'Asset';

        wc_update_order_item_meta($itemId, 'Assets', [$asset['ph_booking_asset_id']]);
        wc_update_order_item_meta($itemId, $assetLabel, $asset['ph_booking_asset_name'] ?? $asset['ph_booking_asset_id']);
    }

    private static function getParticipantTypes($productId)
    {
        $rules = get_post_meta($productId, '_phive_booking_persons_pricing_rules', true);

        if (!\is_array($rules)) {
            return [];
        }

        $types = array_map(
            static fn ($rule) => \is_array($rule) ? trim((string) ($rule['ph_booking_persons_rule_type'] ?? '')) : '',
            $rules
        );

        return array_values(array_filter($types, 'strlen'));
    }

    private static function validateParticipants(array $participants, array $allowedTypes)
    {
        if (empty($participants)) {
            return __('Participants are required in the format Type:Count, e.g. Adult:2, Child:1.', 'bit-integrations-pro');
        }

        foreach ($participants as $label => $count) {
            if (!is_numeric($count) || (int) $count < 0) {
                // translators: %s is the participant type label whose count is invalid.
                return \sprintf(__('Count for "%s" must be a whole number of 0 or more.', 'bit-integrations-pro'), $label);
            }
        }

        $unknownTypes = $allowedTypes ? array_diff(array_keys($participants), $allowedTypes) : [];

        if (!empty($unknownTypes)) {
            return \sprintf(
                // translators: 1: participant labels not configured on the product, 2: the product's participant types.
                __('Unknown participant type: %1$s. This product accepts: %2$s.', 'bit-integrations-pro'),
                implode(', ', $unknownTypes),
                implode(', ', $allowedTypes)
            );
        }
    }

    private static function saveParticipants($itemId, array $participants)
    {
        $total = array_sum($participants);

        foreach ($participants as $type => $count) {
            wc_update_order_item_meta($itemId, $type, $count);
        }

        wc_update_order_item_meta($itemId, 'Number of persons', $total);
        wc_update_order_item_meta($itemId, 'Total Number of Participants', $total);
        wc_update_order_item_meta(
            $itemId,
            'ph_bookings_participant_booking_data',
            array_map(
                static fn ($type, $count) => ['participant_label' => $type, 'participant_count' => $count],
                array_keys($participants),
                $participants
            )
        );
    }

    private static function parseParticipants($raw)
    {
        $participants = [];

        foreach (explode(',', (string) $raw) as $pair) {
            if (strpos($pair, ':') === false) {
                continue;
            }

            [$label, $count] = explode(':', $pair, 2);
            $label = trim($label);

            if ($label !== '') {
                $participants[$label] = trim($count);
            }
        }

        return $participants;
    }

    private static function syncAvailability($itemId, $orderId)
    {
        do_action('ph_booking_order_items_modified', [$itemId => []], $orderId, []);
    }

    private static function getProductSettings($productId)
    {
        if (!class_exists('Ph_Booking_Manage_Availability_Data')) {
            return [];
        }

        return (array) Ph_Booking_Manage_Availability_Data::ph_get_product_settings((int) $productId);
    }

    private static function formatDisplayDate($date)
    {
        if (!class_exists('Ph_Bookings_General_Functions_Class')) {
            return $date;
        }

        return Ph_Bookings_General_Functions_Class::phive_get_date_in_wp_format($date) ?: $date;
    }
}
