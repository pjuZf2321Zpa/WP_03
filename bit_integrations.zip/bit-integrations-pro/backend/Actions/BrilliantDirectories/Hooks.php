<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Actions\BrilliantDirectories\BrilliantDirectoriesHelperPro;
use BitApps\IntegrationsPro\Config;
use BitApps\IntegrationsPro\Core\Util\Hooks;

Hooks::filter(Config::withFreePrefix('brilliant_directories_create_member'), [BrilliantDirectoriesHelperPro::class, 'createMember'], 10, 4);
Hooks::filter(Config::withFreePrefix('brilliant_directories_update_member'), [BrilliantDirectoriesHelperPro::class, 'updateMember'], 10, 4);
Hooks::filter(Config::withFreePrefix('brilliant_directories_delete_member'), [BrilliantDirectoriesHelperPro::class, 'deleteMember'], 10, 4);
Hooks::filter(Config::withFreePrefix('brilliant_directories_create_lead'), [BrilliantDirectoriesHelperPro::class, 'createLead'], 10, 4);
Hooks::filter(Config::withFreePrefix('brilliant_directories_update_lead'), [BrilliantDirectoriesHelperPro::class, 'updateLead'], 10, 4);
Hooks::filter(Config::withFreePrefix('brilliant_directories_match_lead'), [BrilliantDirectoriesHelperPro::class, 'matchLead'], 10, 4);
Hooks::filter(Config::withFreePrefix('brilliant_directories_delete_lead'), [BrilliantDirectoriesHelperPro::class, 'deleteLead'], 10, 4);
Hooks::filter(Config::withFreePrefix('brilliant_directories_create_member_post'), [BrilliantDirectoriesHelperPro::class, 'createMemberPost'], 10, 4);
Hooks::filter(Config::withFreePrefix('brilliant_directories_create_review'), [BrilliantDirectoriesHelperPro::class, 'createReview'], 10, 4);
Hooks::filter(Config::withFreePrefix('brilliant_directories_update_review'), [BrilliantDirectoriesHelperPro::class, 'updateReview'], 10, 4);
Hooks::filter(Config::withFreePrefix('brilliant_directories_delete_review'), [BrilliantDirectoriesHelperPro::class, 'deleteReview'], 10, 4);
