<?php

namespace Breakdance\ActionsFilters;

/* Must execute last, since we need to buffer the output */

use function Breakdance\Data\get_global_option;
use function Breakdance\Render\getWordPressHtmlOutput;
use function Breakdance\Render\registerAssetPlaceholdersInHeaderAndFooter;

add_filter('template_include', 'Breakdance\ActionsFilters\template_include', 1000000);

/**
 * @return string|void
 */
function getAdminTemplate()
{

    $breakdance_or_oxygen = BREAKDANCE_MODE === 'oxygen' ? 'oxygen' : 'breakdance';

    /** @var string|false $adminTemplate */
    $adminTemplate = $_GET[$breakdance_or_oxygen] ?? false;

    $templates = [
        'builder' => '../loader/loader.php',
        'templates' => '../themeless/manage-templates-spa/iframe.php',
        'design_library' => '../design-library/app/iframe.php',
        'regenerate-cache' => '../setup/iframe-regenerate-cache.php',
        'onboarding-app' => '../onboarding/iframe.php',
    ];

    $isValidTemplate = in_array($adminTemplate, array_keys($templates));

    if (!$isValidTemplate) return;

    return plugin_dir_path(__FILE__) . $templates[$adminTemplate];
}

/**
 * @param string $file_to_include
 * @return string|null
 */
function template_include($file_to_include)
{
    // WP checks if it's robots or favicon in "template-loader.php" but it doesn't catch it when the permalinks are in "plain", for some reason.
    // Details and explanation: https://github.com/soflyy/breakdance/pull/3982
    if (isset($_REQUEST['q']) && ($_REQUEST['q'] === 'robots.txt' || $_REQUEST['q'] === 'favicon.ico')) {
        return null;
    }

    $adminTemplate = getAdminTemplate();
    if ($adminTemplate) return $adminTemplate;

    bdox_run_action('breakdance_register_template_types_and_conditions');

    $didAjaxFire = \Breakdance\AJAX\see_if_this_is_an_ajax_at_any_url_request_and_if_so_fire_it();
    if ($didAjaxFire) return null;

    registerAssetPlaceholdersInHeaderAndFooter();

    $templatePath = \Breakdance\Themeless\maybe_override_the_theme_with_a_breakdance_template($file_to_include);
    $html = \Breakdance\Render\replaceAssetPlaceholders(getWordPressHtmlOutput($templatePath));

    \Breakdance\Render\PreRenderedContent::set($html);
    return plugin_dir_path(__FILE__) . '../render/relay-template.php';
}
