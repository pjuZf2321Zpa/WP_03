<?php

namespace FluentCartPro\App\Modules\AdvancedFilters\Reports;

use FluentCart\App\Models\Order;
use FluentCart\App\Services\Filter\OrderFilter;
use FluentCart\Framework\Database\Query\Builder as QueryBuilder;
use FluentCart\Framework\Support\Arr;
use Throwable;

/**
 * Applies the Pro-only advanced filters to the Order Sources report query.
 *
 * A Sources row is a bucket of orders, so the filter vocabulary is the Orders
 * one: this class does NOT parse conditions itself. It hands the (pruned)
 * payload to \FluentCart\App\Services\Filter\OrderFilter — the exact engine the
 * Orders table uses — and constrains the report aggregate with a
 * `whereIn('o.id', <order id subquery>)` built from that filter's own query.
 *
 * Two consequences worth stating out loud:
 *
 * 1. Only conditions the ORDERS filter understands are honoured. Metric-level
 *    conditions (orders count, gross sales, AOV) are aggregates of a whole
 *    Sources row and could only be expressed with HAVING, so they are dropped
 *    rather than mis-applied per order. Anything not present in
 *    OrderFilter::getAdvanceFilterOptions() is dropped the same way.
 * 2. `filter_type`, `relation` and `column` are taken from the SERVER-side
 *    option definition, never from the request. BaseFilter::handleAdvanceFilter()
 *    routes on the request's own `filter_type` and uses `property` as a literal
 *    column/relation name, so trusting it would let a crafted payload aim at a
 *    column or relation that does not exist.
 *
 * Any malformed payload leaves the report query untouched — a broken filter must
 * never fatal the report.
 */
class SourceReportFilterService
{
    /**
     * Provider => property => option definition, memoised for the request.
     *
     * The Sources controller calls getSourceReportData() twice (current period +
     * comparison period), so this map would otherwise be rebuilt on both passes.
     *
     * @var array|null
     */
    protected static $allowedProperties = null;

    /**
     * Sanitization rule for the `advanced_filters` report param, pushed into
     * core's rule map via 'fluent_cart/report/sanitize_params_rules'.
     *
     * Core has no rule of its own for this key — it cannot sanitize a payload
     * whose shape it does not know, and scrubbing the JSON blob would mangle
     * legitimate values. Sanitizing it is this class's job, and it does that by
     * rebuilding every condition from its own option definitions (see
     * normalizeItem()) rather than by scrubbing text. So all this rule does is
     * hold the value to the contract apply() expects: a JSON string.
     *
     * A caller that already holds the decoded array — a PHP caller, or a client
     * sending advanced_filters[] — is encoded rather than dropped.
     *
     * @param mixed $value
     * @return string
     */
    public static function sanitizeParam($value): string
    {
        if (is_array($value)) {
            $encoded = wp_json_encode($value);

            return is_string($encoded) ? $encoded : '';
        }

        return is_string($value) ? $value : '';
    }

    /**
     * Filter callback for 'fluent_cart/report/sources_query'.
     *
     * Deliberately untyped: a filter must hand back whatever shape it received,
     * including when this class declines to touch it.
     *
     * @param mixed $query \FluentCart\Framework\Database\Query\Builder over `fct_orders as o`
     * @param mixed $params Processed report params
     * @return mixed The same query, constrained when the payload is usable
     */
    public function apply($query, $params)
    {
        if (!$query instanceof QueryBuilder || !is_array($params)) {
            return $query;
        }

        if (Arr::get($params, 'filter_type') !== 'advanced') {
            return $query;
        }

        try {
            $groups = $this->supportedGroups(Arr::get($params, 'advanced_filters'));

            if (empty($groups)) {
                return $query;
            }

            $idQuery = $this->buildOrderIdQuery($groups);

            if (!$idQuery) {
                return $query;
            }

            return $query->whereIn('o.id', $idQuery);
        } catch (Throwable $e) {
            // A filter payload the Orders engine chokes on (an unknown relation,
            // a value of the wrong shape) must degrade to "no advanced filter",
            // not to a 500 on the whole report.
            return $query;
        }
    }

    /**
     * Decode the payload and keep only the conditions the Orders filter can serve.
     *
     * Free holds the param to a JSON string but deliberately does not inspect it
     * — validating a filter payload needs the option definitions, which live
     * here. So this is the first and only place the payload is understood, and it
     * has to assume nothing about its contents. The value is null or '' when the
     * client sent no filters.
     *
     * @param mixed $json
     * @return array Groups in the shape BaseFilter::parseSearchGroups() expects
     */
    protected function supportedGroups($json): array
    {
        if (!is_string($json) || $json === '') {
            return [];
        }

        $groups = json_decode($json, true);

        if (!is_array($groups) || empty($groups)) {
            return [];
        }

        $allowed = $this->allowedProperties();

        if (empty($allowed)) {
            return [];
        }

        $supported = [];

        foreach ($groups as $group) {
            if (!is_array($group)) {
                continue;
            }

            $items = [];

            foreach ($group as $item) {
                $normalized = $this->normalizeItem($item, $allowed);

                if ($normalized) {
                    $items[] = $normalized;
                }
            }

            if ($items) {
                $supported[] = $items;
            }
        }

        return $supported;
    }

    /**
     * Rebuild one condition from the server-side option definition.
     *
     * Only `operator` and `value` survive from the request; everything that
     * decides WHICH column or relation is touched comes from the option.
     *
     * @param mixed $item
     * @param array $allowed
     * @return array|null Null when the condition is unknown or unusable
     */
    protected function normalizeItem($item, array $allowed): ?array
    {
        if (!is_array($item)) {
            return null;
        }

        $source = Arr::get($item, 'source');
        $operator = Arr::get($item, 'operator');

        if (!is_array($source) || count($source) !== 2) {
            return null;
        }

        if (!is_string($operator) || $operator === '') {
            return null;
        }

        $provider = Arr::get($source, 0);
        $property = Arr::get($source, 1);

        if (!is_string($provider) || $provider === '' || !is_string($property) || $property === '') {
            return null;
        }

        if (!isset($allowed[$provider][$property])) {
            return null;
        }

        $option = $allowed[$provider][$property];

        if (!in_array($operator, $this->supportedOperators($option), true)) {
            return null;
        }

        $normalized = [
            'source'   => [$provider, $property],
            'operator' => $operator,
            'value'    => Arr::get($item, 'value'),
        ];

        $filterType = Arr::get($option, 'filter_type');

        if (is_string($filterType) && $filterType !== '') {
            $normalized['filter_type'] = $filterType;
        }

        if ($filterType === 'relation') {
            // parseSearchGroups() reads these two off the raw item, so they have
            // to travel with it — from the option, not from the request.
            $normalized['relation'] = Arr::get($option, 'relation', $property);
            $normalized['column'] = Arr::get($option, 'column', 'id');
        }

        return $normalized;
    }

    /**
     * Operators accepted for one condition.
     *
     * The general vocabulary is whatever the engine says it resolves —
     * BaseFilter::supportedOperators(), including anything a listener has taught
     * it. Reading it from there rather than restating it here means a new core
     * operator does not silently go missing from this report.
     *
     * An option that declares its own `operators` map owns its vocabulary
     * instead: those are `filter_type: custom` fields whose callback interprets
     * the operator itself (payer_email's starts_with/ends_with), which the engine
     * list would wrongly reject.
     *
     * Anything outside both lists must be dropped, not passed on — see
     * BaseFilter::supportedOperators() for what an unvetted operator does to a
     * query.
     *
     * @param array $option
     * @return array
     */
    protected function supportedOperators(array $option): array
    {
        $declared = Arr::get($option, 'operators');

        if (is_array($declared) && !empty($declared)) {
            return array_map('strval', array_keys($declared));
        }

        return array_map('strval', array_keys(OrderFilter::supportedOperators()));
    }

    /**
     * The condition vocabulary of the Orders table, keyed for lookup.
     *
     * Same source the Orders advanced-filter UI is built from — including
     * whatever 'fluent_cart/orders_filter_options' listeners contribute — so a
     * condition the user can build on Orders is a condition this report accepts.
     *
     * @return array<string, array<string, array>>
     */
    protected function allowedProperties(): array
    {
        if (static::$allowedProperties !== null) {
            return static::$allowedProperties;
        }

        $map = [];
        $options = OrderFilter::getAdvanceFilterOptions();

        if (is_array($options)) {
            foreach ($options as $provider) {
                $providerKey = Arr::get($provider, 'value');

                if (!is_string($providerKey) || $providerKey === '') {
                    continue;
                }

                foreach (Arr::wrap(Arr::get($provider, 'children', [])) as $child) {
                    $childKey = Arr::get($child, 'value');

                    if (!is_array($child) || !is_string($childKey) || $childKey === '') {
                        continue;
                    }

                    $map[$providerKey][$childKey] = $child;
                }
            }
        }

        return static::$allowedProperties = $map;
    }

    /**
     * Build the order-id subquery the report aggregate is constrained on.
     *
     * OrderFilter is Eloquent-bound; the report query is a raw Query\Builder. The
     * bridge is Orm\Builder::toBase(), which applies the model's global scopes and
     * hands back a Query\Builder — the exact type Query\Builder::whereIn() accepts
     * as a subquery (see isQueryable()/parseSub() in the framework's Query\Builder).
     *
     * Stripped from the built query:
     *  - the ordering BaseFilter::applySort() always appends (`id desc`) —
     *    meaningless inside an IN subquery;
     *  - the `*` column default, narrowed to the primary key.
     *
     * Nothing security-relevant is stripped: `with`, `scopes`, `select` and
     * `include_ids` are never passed in, so the permission-gated allow-list
     * callbacks in OrderFilter::allowedWiths() have nothing to resolve, and the
     * eager loads they gate never reach the subquery anyway.
     *
     * @param array $groups
     * @return QueryBuilder|null
     */
    protected function buildOrderIdQuery(array $groups): ?QueryBuilder
    {
        $encoded = wp_json_encode($groups);

        if (!is_string($encoded)) {
            return null;
        }

        $filter = OrderFilter::make([
            'filter_type'      => 'advanced',
            'advanced_filters' => $encoded,
        ]);

        $idQuery = $filter->buildQuery()->toBase();

        $idQuery->reorder();
        $idQuery->select((new Order())->getQualifiedKeyName());

        // A payload that survived pruning can still produce no condition at all
        // (an item parseSearchGroups() drops for its own reasons). Constraining
        // the report on "every order id" is a full scan for no benefit — and it
        // would read as "the filter matched everything", which is the same answer.
        if (empty($idQuery->wheres)) {
            return null;
        }

        return $idQuery;
    }
}
