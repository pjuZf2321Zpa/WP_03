<?php
/**
 * Paid Knowledge Base indexing panels: chunking, batches and content rules.
 */
if (!defined('ABSPATH')) {
    exit;
}

return static function (string $section, array $kb_general_settings = []): void {
    if (!class_exists('\WPAICG\aipkit_dashboard') || !\WPAICG\aipkit_dashboard::is_pro_plan()) {
        return;
    }

    if ($section === 'chunking') {
        $kb_chunk_avg_chars = min(4, max(2, (int) ($kb_general_settings['chunk_avg_chars_per_token'] ?? 4)));
        $kb_chunk_max_tokens = min(6000, max(256, (int) ($kb_general_settings['chunk_max_tokens_per_chunk'] ?? 3000)));
        $kb_chunk_overlap_tokens = min(
            1000,
            max(0, (int) ($kb_general_settings['chunk_overlap_tokens'] ?? 150)),
            max(0, $kb_chunk_max_tokens - 1)
        );
        $kb_openai_chunking_mode = sanitize_key((string) ($kb_general_settings['openai_file_search_chunking_mode'] ?? 'auto'));
        if (!in_array($kb_openai_chunking_mode, ['auto', 'custom'], true)) {
            $kb_openai_chunking_mode = 'auto';
        }
        $kb_openai_chunk_max = min(4096, max(100, (int) ($kb_general_settings['openai_file_search_max_chunk_size_tokens'] ?? 800)));
        $kb_openai_chunk_overlap = min(
            (int) floor($kb_openai_chunk_max / 2),
            max(0, (int) ($kb_general_settings['openai_file_search_chunk_overlap_tokens'] ?? 400))
        );
        $kb_openai_custom_hidden = $kb_openai_chunking_mode !== 'custom' ? ' hidden' : '';
        ?>
        <div class="aipkit_settings_kb_card aipkit_settings_kb_card--chunking">
            <div class="aipkit_settings_kb_section_intro">
                <h2><?php esc_html_e('Chunking', 'gpt3-ai-content-generator'); ?></h2>
                <p><?php esc_html_e('Control how content is split and indexed across providers.', 'gpt3-ai-content-generator'); ?></p>
            </div>
            <div class="aipkit_settings_kb_rows aipkit_settings_kb_rows--chunking">
                <div class="aipkit_form-group aipkit_settings_simple_row">
                    <label class="aipkit_form-label" for="aipkit_chunk_avg_chars_per_token">
                        <span><?php esc_html_e('Avg chars per token', 'gpt3-ai-content-generator'); ?></span>
                        <span class="aipkit_form-label-helper"><?php esc_html_e('Applies to Pinecone, Qdrant, and Chroma.', 'gpt3-ai-content-generator'); ?></span>
                    </label>
                    <input type="number" min="2" max="4" step="1" id="aipkit_chunk_avg_chars_per_token" name="chunk_avg_chars_per_token" class="aipkit_form-input" value="<?php echo esc_attr($kb_chunk_avg_chars); ?>">
                </div>
                <div class="aipkit_form-group aipkit_settings_simple_row">
                    <label class="aipkit_form-label" for="aipkit_chunk_max_tokens_per_chunk">
                        <span><?php esc_html_e('Max tokens per chunk', 'gpt3-ai-content-generator'); ?></span>
                        <span class="aipkit_form-label-helper"><?php esc_html_e('Applies to Pinecone, Qdrant, and Chroma.', 'gpt3-ai-content-generator'); ?></span>
                    </label>
                    <input type="number" min="256" max="6000" step="1" id="aipkit_chunk_max_tokens_per_chunk" name="chunk_max_tokens_per_chunk" class="aipkit_form-input" value="<?php echo esc_attr($kb_chunk_max_tokens); ?>">
                </div>
                <div class="aipkit_form-group aipkit_settings_simple_row">
                    <label class="aipkit_form-label" for="aipkit_chunk_overlap_tokens">
                        <span><?php esc_html_e('Overlap tokens', 'gpt3-ai-content-generator'); ?></span>
                        <span class="aipkit_form-label-helper"><?php esc_html_e('Applies to Pinecone, Qdrant, and Chroma.', 'gpt3-ai-content-generator'); ?></span>
                    </label>
                    <input type="number" min="0" max="1000" step="1" id="aipkit_chunk_overlap_tokens" name="chunk_overlap_tokens" class="aipkit_form-input" value="<?php echo esc_attr($kb_chunk_overlap_tokens); ?>">
                </div>
                <div class="aipkit_form-group aipkit_settings_simple_row aipkit_settings_kb_indexing_strategy_row">
                    <label class="aipkit_form-label" for="aipkit_openai_file_search_chunking_mode">
                        <span><?php esc_html_e('Indexing strategy', 'gpt3-ai-content-generator'); ?></span>
                        <span class="aipkit_form-label-helper"><?php esc_html_e('Applies to OpenAI only.', 'gpt3-ai-content-generator'); ?></span>
                    </label>
                    <select id="aipkit_openai_file_search_chunking_mode" name="openai_file_search_chunking_mode" class="aipkit_form-input">
                        <option value="auto" <?php selected($kb_openai_chunking_mode, 'auto'); ?>><?php esc_html_e('Auto', 'gpt3-ai-content-generator'); ?></option>
                        <option value="custom" <?php selected($kb_openai_chunking_mode, 'custom'); ?>><?php esc_html_e('Custom', 'gpt3-ai-content-generator'); ?></option>
                    </select>
                </div>
                <div class="aipkit_form-group aipkit_settings_simple_row" data-aipkit-openai-chunking-custom-row<?php echo $kb_openai_custom_hidden; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Fixed hidden attribute. ?>>
                    <label class="aipkit_form-label" for="aipkit_openai_file_search_max_chunk_size_tokens">
                        <span><?php esc_html_e('Max tokens per chunk', 'gpt3-ai-content-generator'); ?></span>
                        <span class="aipkit_form-label-helper"><?php esc_html_e('Applies to OpenAI only.', 'gpt3-ai-content-generator'); ?></span>
                    </label>
                    <input type="number" min="100" max="4096" step="1" id="aipkit_openai_file_search_max_chunk_size_tokens" name="openai_file_search_max_chunk_size_tokens" class="aipkit_form-input" value="<?php echo esc_attr($kb_openai_chunk_max); ?>">
                </div>
                <div class="aipkit_form-group aipkit_settings_simple_row" data-aipkit-openai-chunking-custom-row<?php echo $kb_openai_custom_hidden; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Fixed hidden attribute. ?>>
                    <label class="aipkit_form-label" for="aipkit_openai_file_search_chunk_overlap_tokens">
                        <span><?php esc_html_e('Overlap tokens', 'gpt3-ai-content-generator'); ?></span>
                        <span class="aipkit_form-label-helper"><?php esc_html_e('Applies to OpenAI only.', 'gpt3-ai-content-generator'); ?></span>
                    </label>
                    <input type="number" min="0" max="<?php echo esc_attr((int) floor($kb_openai_chunk_max / 2)); ?>" step="1" id="aipkit_openai_file_search_chunk_overlap_tokens" name="openai_file_search_chunk_overlap_tokens" class="aipkit_form-input" value="<?php echo esc_attr($kb_openai_chunk_overlap); ?>">
                </div>
            </div>
        </div>
        <?php
    } elseif ($section === 'batches') {
        $aipkit_batch_settings_class = '\\WPAICG\\Lib\\VectorStores\\FileUpload\\AIPKit_Vector_File_Ingestion_Batch_Settings';
        $aipkit_batch_settings_path = defined('WPAICG_LIB_DIR')
            ? WPAICG_LIB_DIR . 'knowledge-base/ingestion-settings.php'
            : '';
        if (!class_exists($aipkit_batch_settings_class) && $aipkit_batch_settings_path && file_exists($aipkit_batch_settings_path)) {
            require_once $aipkit_batch_settings_path;
        }

        if (!class_exists($aipkit_batch_settings_class)) {
            return;
        }
        $aipkit_batch_configs = $aipkit_batch_settings_class::provider_configs();
        ?>
        <div class="aipkit_settings_kb_card aipkit_settings_kb_card--batches">
            <div class="aipkit_settings_kb_section_intro">
                <h2><?php esc_html_e('Embedding batches', 'gpt3-ai-content-generator'); ?></h2>
                <p><?php esc_html_e('Control how many items are embedded per request, per provider.', 'gpt3-ai-content-generator'); ?></p>
            </div>
            <div class="aipkit_settings_kb_rows aipkit_settings_kb_rows--batches aipkit_settings_kb_batch_rows">
                <div class="aipkit_settings_kb_batch_fields">
                <?php foreach ($aipkit_batch_configs as $aipkit_batch_provider => $aipkit_batch_config) : ?>
                    <?php
                    $aipkit_batch_value = $aipkit_batch_settings_class::get_provider_batch_size((string) $aipkit_batch_provider);
                    $aipkit_batch_key = (string) $aipkit_batch_config['key'];
                    $aipkit_batch_id = 'aipkit_' . $aipkit_batch_key;
                    ?>
                    <div class="aipkit_form-group aipkit_settings_simple_row">
                        <label class="aipkit_form-label" for="<?php echo esc_attr($aipkit_batch_id); ?>">
                            <span><?php echo esc_html($aipkit_batch_config['label']); ?></span>
                            <span class="aipkit_form-label-helper">
                                <?php
                                echo esc_html(
                                    sprintf(
                                        /* translators: 1: Default batch size, 2: Maximum batch size. */
                                        __('Default %1$d, max %2$d.', 'gpt3-ai-content-generator'),
                                        (int) $aipkit_batch_config['default'],
                                        (int) $aipkit_batch_config['max']
                                    )
                                );
                                ?>
                            </span>
                        </label>
                        <input
                            type="number"
                            min="<?php echo esc_attr($aipkit_batch_settings_class::min_batch_size()); ?>"
                            max="<?php echo esc_attr((int) $aipkit_batch_config['max']); ?>"
                            step="1"
                            id="<?php echo esc_attr($aipkit_batch_id); ?>"
                            name="<?php echo esc_attr($aipkit_batch_key); ?>"
                            class="aipkit_form-input"
                            value="<?php echo esc_attr($aipkit_batch_value); ?>"
                            data-aipkit-embedding-batch-provider="<?php echo esc_attr((string) $aipkit_batch_provider); ?>"
                        />
                    </div>
                <?php endforeach; ?>
                </div>
            </div>
        </div>
        <?php
    } elseif ($section === 'content-rules') {
        ?>
        <div class="aipkit_settings_kb_card aipkit_settings_kb_card--content-rules">
            <div class="aipkit_settings_kb_section_intro">
                <h2><?php esc_html_e('Content rules', 'gpt3-ai-content-generator'); ?></h2>
                <p><?php esc_html_e('AI Puffer automatically extracts readable WordPress and page-builder content. Open a content type only when you want to change its standard fields or labels.', 'gpt3-ai-content-generator'); ?></p>
            </div>
            <div id="indexing-settings-tab-content" data-initialized="false">
                <label class="aipkit_settings_kb_content_type_search" for="aipkit_settings_kb_content_type_search">
                    <span class="dashicons dashicons-search" aria-hidden="true"></span>
                    <span class="screen-reader-text"><?php esc_html_e('Search content types', 'gpt3-ai-content-generator'); ?></span>
                    <input
                        type="search"
                        id="aipkit_settings_kb_content_type_search"
                        class="aipkit_form-input"
                        placeholder="<?php esc_attr_e('Search content types', 'gpt3-ai-content-generator'); ?>"
                        autocomplete="off"
                        aria-controls="aipkit_indexing_settings_form_container"
                    >
                </label>
                <form id="aipkit_indexing_settings_form" onsubmit="return false;">
                    <div id="aipkit_indexing_settings_form_container"></div>
                </form>
                <p class="aipkit_settings_kb_content_type_count" id="aipkit_settings_kb_content_type_count" aria-live="polite"></p>
            </div>
        </div>
        <?php
    }
};
