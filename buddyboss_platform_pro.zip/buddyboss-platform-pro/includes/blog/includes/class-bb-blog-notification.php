<?php
/**
 * BuddyBoss Pro Blog Notification.
 *
 * Registers the `blog` notification group, the `bb_blog_new_post`
 * notification/email type, and the `blog_category` subscription type that
 * lets members subscribe to a blog category and get notified/emailed when a
 * new post publishes in it. Modeled on `BP_Forums_Notification`
 * (`class-bp-forums-notification.php`).
 *
 * @package BuddyBossPro
 *
 * @since 3.1.0
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

/**
 * Set up the BB_Blog_Notification class.
 *
 * @since 3.1.0
 */
class BB_Blog_Notification extends BP_Core_Notification_Abstract {

	/**
	 * Instance of this class.
	 *
	 * @since 3.1.0
	 *
	 * @var BB_Blog_Notification
	 */
	private static $instance = null;

	/**
	 * Get the instance of this class.
	 *
	 * @since 3.1.0
	 *
	 * @return BB_Blog_Notification
	 */
	public static function instance() {
		if ( is_null( self::$instance ) ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Constructor method.
	 *
	 * Registers the notification type/email regardless of the Pro
	 * subscriptions gate (license/feature) so the type shows up in the
	 * Notifications admin/user settings even while inactive -- actual
	 * availability of the `blog_category` subscription type is enforced at
	 * runtime by the `bb_is_enabled_subscription` filter and by
	 * `validate_subscription_request()`, mirroring how forum subscriptions
	 * stay registered while gated on `bbp_is_subscriptions_active()`.
	 *
	 * @since 3.1.0
	 */
	public function __construct() {
		add_action( 'bp_init', array( $this, 'start' ), 5 );

		// Mark the subscriber's "new post" notification read when they visit the
		// post on the front end — the target that notification links to.
		add_action( 'template_redirect', array( $this, 'mark_read_on_post_visit' ) );
	}

	/**
	 * Mark the current user's blog subscription notification read when they
	 * visit the post the notification links to.
	 *
	 * The `bb_blog_new_post` notification links to the post permalink, but
	 * nothing marked it read on visit. Scoped to the current user, so only the
	 * recipient's own notification for this post is cleared.
	 *
	 * @since 3.1.0
	 *
	 * @return void
	 */
	public function mark_read_on_post_visit() {
		if ( ! function_exists( 'bp_notifications_mark_notifications_by_item_id' ) ) {
			return;
		}

		if ( ! is_singular( 'post' ) ) {
			return;
		}

		$user_id = get_current_user_id();
		$post_id = get_queried_object_id();

		if ( empty( $user_id ) || empty( $post_id ) ) {
			return;
		}

		bp_notifications_mark_notifications_by_item_id( $user_id, $post_id, 'blog', 'bb_blog_new_post' );
	}

	/**
	 * Initialize all methods inside it.
	 *
	 * @since 3.1.0
	 *
	 * @return void
	 */
	public function load() {
		$this->register_notification_group(
			'blog',
			esc_html__( 'Blog', 'buddyboss-pro' ),
			esc_html__( 'Blog', 'buddyboss-pro' ),
			70
		);

		$this->register_notification_for_new_post();
	}

	/**
	 * Pick the notification icon class for the active template pack.
	 *
	 * The bell notification list renders the stored icon class as-is, but the
	 * two icon fonts are mode-specific: ReadyLaunch loads `bb-icons-rl-*` while
	 * the legacy (bp-nouveau) UI loads `bb-icon-*`. A ReadyLaunch class shows a
	 * blank glyph in legacy mode, so return the set matching the site-wide
	 * ReadyLaunch toggle -- mirroring how BuddyBoss core registers `bb-icon-*`.
	 *
	 * @since 3.1.0
	 *
	 * @param string $rl_icon     ReadyLaunch icon class (e.g. `bb-icons-rl-article`).
	 * @param string $legacy_icon Legacy bp-nouveau icon class (e.g. `bb-icon-f bb-icon-article`).
	 *
	 * @return string The icon class for the active template pack.
	 */
	protected function notification_icon( $rl_icon, $legacy_icon ) {
		$is_rl = function_exists( 'bb_is_readylaunch_enabled' ) && bb_is_readylaunch_enabled();

		return $is_rl ? $rl_icon : $legacy_icon;
	}

	/**
	 * Register notification/email/subscription type for new posts in a
	 * subscribed blog category.
	 *
	 * @since 3.1.0
	 */
	public function register_notification_for_new_post() {
		$this->register_notification_type(
			'bb_blog_new_post',
			__( 'New blog post in a blog category you\'re subscribed to', 'buddyboss-pro' ),
			esc_html__( 'A new blog post in a blog category a member is subscribed to', 'buddyboss-pro' ),
			'blog',
			true,
			false,
			''
		);

		$this->register_email_type(
			'blog-new-post',
			array(
				/* translators: do not remove {} brackets or translate its contents. */
				'email_title'         => __( '[{{{site.name}}}] New blog post: {{post.title}}', 'buddyboss-pro' ),
				/* translators: do not remove {} brackets or translate its contents. */
				'email_content'       => __( '{{poster.name}} published a new blog post <a href="{{post.url}}">{{post.title}}</a> in the category {{category.name}}.', 'buddyboss-pro' ),
				/* translators: do not remove {} brackets or translate its contents. */
				'email_plain_content' => __( "{{poster.name}} published a new blog post {{post.title}} in the category {{category.name}}.\n\nBlog Post Link: {{post.url}}", 'buddyboss-pro' ),
				'situation_label'     => __( 'A new blog post in a blog category a member is subscribed to', 'buddyboss-pro' ),
				'unsubscribe_text'    => __( 'You will no longer receive emails when a new blog post is published in a blog category you are subscribed to.', 'buddyboss-pro' ),
			),
			'bb_blog_new_post'
		);

		$this->register_notification(
			'blog',
			'bb_blog_new_post',
			'bb_blog_new_post',
			$this->notification_icon( 'bb-icons-rl-article', 'bb-icon-f bb-icon-article' )
		);

		$this->bb_register_subscription_type(
			array(
				'label'              => array(
					'singular' => __( 'Blog category', 'buddyboss-pro' ),
					'plural'   => __( 'Blog categories', 'buddyboss-pro' ),
				),
				'subscription_type'  => 'blog_category',
				'items_callback'     => array( $this, 'render_subscribed_categories' ),
				'send_callback'      => array( $this, 'send_new_post_notifications' ),
				'validate_callback'  => array( $this, 'validate_subscription_request' ),
				'notification_type'  => 'bb_blog_new_post',
				'notification_group' => 'blog',
			)
		);
	}

	/**
	 * Format the notification content for the `blog` component.
	 *
	 * @since 3.1.0
	 *
	 * @param string $content               Notification content.
	 * @param int    $item_id               Notification item ID (post ID).
	 * @param int    $secondary_item_id     Notification secondary item ID (author ID).
	 * @param int    $total_items           Number of notifications with the same action.
	 * @param string $component_action_name Canonical notification action.
	 * @param string $component_name        Notification component ID.
	 * @param int    $notification_id       Notification ID.
	 * @param string $screen                Notification Screen type.
	 *
	 * @return array|string
	 */
	public function format_notification( $content, $item_id, $secondary_item_id, $total_items, $component_action_name, $component_name, $notification_id, $screen ) {

		if ( 'blog' === $component_name && 'bb_blog_new_post' === $component_action_name ) {
			$notification = bp_notifications_get_notification( $notification_id );
			$post_title   = get_the_title( $item_id );
			$post_link    = get_permalink( $item_id );

			if ( (int) $total_items > 1 ) {
				$text = sprintf(
					/* translators: number of new posts. */
					_n( 'You have %d new blog post', 'You have %d new blog posts', (int) $total_items, 'buddyboss-pro' ),
					(int) $total_items
				);
			} elseif ( ! empty( $secondary_item_id ) ) {
				$text = sprintf(
					/* translators: 1: Member display name. 2: post title. */
					esc_html__( '%1$s published a new blog post: %2$s', 'buddyboss-pro' ),
					esc_html( bp_core_get_user_displayname( $secondary_item_id ) ),
					esc_html( $post_title )
				);
			} else {
				$text = sprintf(
					/* translators: post title. */
					esc_html__( 'A new blog post was published: %s', 'buddyboss-pro' ),
					esc_html( $post_title )
				);
			}

			$content = array(
				'text'  => $text,
				'link'  => $post_link,
				'title' => bp_get_site_name(),
				'image' => function_exists( 'bb_notification_avatar_url' ) ? bb_notification_avatar_url( $notification ) : '',
			);
		}

		return $content;
	}

	/**
	 * Validate a `blog_category` subscription request.
	 *
	 * @since 3.1.0
	 *
	 * @param array $args {
	 *     Used to validate the subscription request.
	 *
	 *     @type string $type              The subscription type.
	 *     @type int    $blog_id           Site ID.
	 *     @type int    $item_id           Category term ID.
	 *     @type int    $secondary_item_id Unused for this type.
	 * }
	 *
	 * @return true|WP_Error
	 */
	public function validate_subscription_request( $args ) {
		$r = bp_parse_args(
			$args,
			array(
				'type'              => '',
				'blog_id'           => get_current_blog_id(),
				'item_id'           => 0,
				'secondary_item_id' => 0,
			)
		);

		if ( ! is_user_logged_in() ) {
			return new WP_Error(
				'bb_blog_pro_subscription_not_logged_in',
				__( 'You must be logged in to subscribe.', 'buddyboss-pro' ),
				array( 'status' => 401 )
			);
		}

		if ( ! function_exists( 'bb_blog_pro_is_subscriptions_enabled' ) || ! bb_blog_pro_is_subscriptions_enabled() ) {
			return new WP_Error(
				'bb_blog_pro_subscription_disabled',
				__( 'Blog category subscriptions are not enabled.', 'buddyboss-pro' ),
				array( 'status' => 400 )
			);
		}

		if ( empty( $r['item_id'] ) ) {
			return new WP_Error(
				'bb_subscription_required_item_id',
				__( 'The item ID is required.', 'buddyboss-pro' ),
				array( 'status' => 400 )
			);
		}

		$term = get_term( (int) $r['item_id'], 'category' );

		if ( empty( $term ) || is_wp_error( $term ) ) {
			return new WP_Error(
				'bb_blog_pro_subscription_invalid_category',
				__( 'The category does not exist.', 'buddyboss-pro' ),
				array( 'status' => 400 )
			);
		}

		return true;
	}

	/**
	 * Enrich `blog_category` subscription items for display (title/link).
	 *
	 * @since 3.1.0
	 *
	 * @param array $items Array of subscription list.
	 *
	 * @return array
	 */
	public function render_subscribed_categories( $items ) {
		static $cached_items = array();

		if ( empty( $items ) ) {
			return $items;
		}

		foreach ( $items as $item_key => $item ) {
			$subscription = bp_parse_args(
				$item,
				array(
					'id'      => 0,
					'item_id' => 0,
				)
			);

			if ( empty( $subscription['id'] ) || empty( $subscription['item_id'] ) ) {
				continue;
			}

			if ( ! empty( $cached_items[ $subscription['id'] ] ) ) {
				$items[ $item_key ] = $cached_items[ $subscription['id'] ];
				continue;
			}

			$term = get_term( (int) $subscription['item_id'], 'category' );
			$data = array();

			if ( empty( $term ) || is_wp_error( $term ) ) {
				$data['title'] = __( 'Deleted category', 'buddyboss-pro' );
				$data['link']  = '';
			} else {
				$data['title'] = esc_html( $term->name );
				$data['link']  = get_category_link( $term );
			}

			$data = bp_parse_args(
				$data,
				array(
					'title'            => '',
					'description_html' => '',
					'parent_html'      => '',
					'icon'             => array(),
					'link'             => '',
				)
			);

			$items[ $item_key ]                  = (object) array_merge( (array) $item, $data );
			$cached_items[ $subscription['id'] ] = $items[ $item_key ];
		}

		return $items;
	}

	/**
	 * Send callback for the `blog_category` subscription type.
	 *
	 * Called either synchronously or from a background-updater chunk (see
	 * `bb_blog_pro_notify_subscribers_on_publish()` in
	 * `bb-blog-subscriptions.php`) with an already deduped, author-excluded
	 * list of user IDs for a single post.
	 *
	 * @since 3.1.0
	 * @since 3.3.3 Claims the chunk before sending (concurrent re-run guard, refreshed per recipient, released on bail and completed at the end) and returns false on completion so the background queue row is removed instead of re-queued.
	 *
	 * @param array $args {
	 *     Array of arguments.
	 *
	 *     @type string $type              Subscription type (`blog_category`).
	 *     @type int    $item_id           Post ID.
	 *     @type array  $data              Extra data: `author_id`, `category_names`.
	 *     @type string $notification_type Notification type (`bb_blog_new_post`).
	 *     @type array  $user_ids          Recipient user IDs.
	 * }
	 *
	 * @return false|void
	 */
	public function send_new_post_notifications( $args ) {
		$r = bp_parse_args(
			$args,
			array(
				'type'              => '',
				'item_id'           => '',
				'data'              => array(),
				'notification_type' => '',
				'user_ids'          => array(),
			)
		);

		if ( empty( $r['user_ids'] ) || empty( $r['type'] ) || ! bb_is_enabled_subscription( $r['type'] ) ) {
			return;
		}

		// Derive the claim key from the pristine payload once: the author is
		// removed from user_ids below, and the claim, its refreshes, its release
		// and its completion marker must all hash the same shape. Guarded: the
		// helpers ship with Platform's subscription fan-out hardening; on an
		// older Platform the pre-existing behavior stands. The existence checks
		// are hoisted out of the per-recipient loop below.
		$can_touch_claim   = function_exists( 'bb_subscriptions_touch_notification_chunk_claim' );
		$can_release_claim = function_exists( 'bb_subscriptions_release_notification_chunk_claim' );
		$chunk_key         = function_exists( 'bb_subscriptions_get_notification_chunk_key' )
			? bb_subscriptions_get_notification_chunk_key( $r )
			: '';

		// A queue row re-run by a concurrently dispatched worker must not send
		// this chunk a second time.
		if ( function_exists( 'bb_subscriptions_claim_notification_chunk' ) && ! bb_subscriptions_claim_notification_chunk( $r, $chunk_key ) ) {
			return false;
		}

		$post_id = (int) $r['item_id'];
		$post    = get_post( $post_id );

		if ( empty( $post ) ) {
			if ( $can_release_claim ) {
				bb_subscriptions_release_notification_chunk_claim( $r, $chunk_key );
			}

			return;
		}

		$author_id = ! empty( $r['data']['author_id'] ) ? (int) $r['data']['author_id'] : (int) $post->post_author;

		// Belt-and-suspenders: the trigger already excludes the author, but
		// keep this safe when the send callback is invoked directly.
		if ( ! empty( $author_id ) ) {
			$unset_key = array_search( $author_id, $r['user_ids'], true );
			if ( false !== $unset_key ) {
				unset( $r['user_ids'][ $unset_key ] );
			}
		}

		if ( empty( $r['user_ids'] ) ) {
			if ( $can_release_claim ) {
				bb_subscriptions_release_notification_chunk_claim( $r, $chunk_key );
			}

			return;
		}

		$post_title  = get_the_title( $post_id );
		$post_url    = get_permalink( $post_id );
		$poster_name = bp_core_get_user_displayname( $author_id );

		foreach ( $r['user_ids'] as $user_id ) {
			// Keep the chunk claim alive while this (possibly slow) chunk is still sending.
			if ( $can_touch_claim ) {
				bb_subscriptions_touch_notification_chunk_claim( $r, $chunk_key );
			}

			$user_id = (int) $user_id;

			if ( empty( $user_id ) ) {
				continue;
			}

			// Per-recipient category list: only the post's categories THIS user
			// subscribed to (the intersection), falling back to all of the post's
			// categories when the map is unavailable (e.g. a direct/legacy call).
			// Each category name is wrapped in quotes, comma-separated.
			$user_category_names = ! empty( $r['data']['user_category_map'][ $user_id ] )
				? (array) $r['data']['user_category_map'][ $user_id ]
				: wp_list_pluck( get_the_category( $post_id ), 'name' );

			$user_categories = implode(
				', ',
				array_map(
					static function ( $name ) {
						return '"' . esc_html( $name ) . '"';
					},
					$user_category_names
				)
			);

			$send_mail         = bb_is_notification_enabled( $user_id, $r['notification_type'] );
			$send_notification = true;

			$filter_args = array(
				'type'              => $r['notification_type'],
				'component_type'    => 'blog',
				'post_id'           => $post_id,
				'recipient_user_id' => $user_id,
				'sender_id'         => $author_id,
			);

			$send_mail         = (bool) apply_filters( 'bb_blog_pro_send_new_post_email_notification', $send_mail, $filter_args );
			$send_notification = (bool) apply_filters( 'bb_blog_pro_send_new_post_notification', $send_notification, $filter_args );

			if ( true === $send_mail ) {
				$unsubscribe_args = array(
					'user_id'           => $user_id,
					'notification_type' => 'blog-new-post',
				);

				$tokens = array(
					'poster.name'      => esc_html( $poster_name ),
					'post.title'       => esc_html( $post_title ),
					'post.url'         => esc_url( $post_url ),
					'category.name'    => $user_categories,
					'unsubscribe'      => esc_url( bp_email_get_unsubscribe_link( $unsubscribe_args ) ),
					'receiver-user.id' => $user_id,
				);

				bp_send_email( 'blog-new-post', $user_id, array( 'tokens' => $tokens ) );
			}

			if ( true === $send_notification && bp_is_active( 'notifications' ) ) {
				bp_notifications_add_notification(
					array(
						'user_id'           => $user_id,
						'item_id'           => $post_id,
						'secondary_item_id' => $author_id,
						'component_name'    => 'blog',
						'component_action'  => 'bb_blog_new_post',
						'date_notified'     => bp_core_current_time(),
						'is_new'            => 1,
					)
				);
			}
		}

		// Every recipient is handled: mark the chunk done so a late duplicate
		// queue row is refused, then release the claim.
		if ( function_exists( 'bb_subscriptions_complete_notification_chunk' ) ) {
			bb_subscriptions_complete_notification_chunk( $r, $chunk_key );
		}

		// The chunk is fully processed; false removes the queue row. A truthy
		// return would make BB_Background_Updater::task() re-run the row with
		// the updater object as its only argument, a pass that only no-ops at
		// the guards above.
		return false;
	}
}

// NOTE: This class is intentionally NOT instantiated at file scope. The Pro
// autoloader maps `BB_Blog_Notification` to this path, so a bare
// `class_exists( 'BB_Blog_Notification' )` (autoload defaults to true) would
// otherwise load AND bootstrap it — hooking start() to bp_init and registering
// the notification/email/subscription types — regardless of the
// `bb_blog_enable_subscriptions` option. Instantiation is done by
// BB_Blog::includes() right after this file is required, which only happens
// while that option is on. See BB_Blog::includes().
