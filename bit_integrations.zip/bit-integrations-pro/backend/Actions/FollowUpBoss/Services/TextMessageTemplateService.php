<?php

namespace BitApps\IntegrationsPro\Actions\FollowUpBoss\Services;

final class TextMessageTemplateService extends BaseService
{
    public function createTextMessageTemplate(): array
    {
        $validationRules = [
            'name'    => ['required'],
            'message' => ['required'],
        ];
        $error = $this->validateFields(
            $validationRules,
            [
                'name'    => __('Template Name', 'bit-integrations-pro'),
                'message' => __('Message', 'bit-integrations-pro'),
            ]
        );

        if ($error !== null) {
            return $error;
        }

        $payload = $this->removeEmptyValues(
            [
                'name'     => $this->getString('name'),
                'message'  => $this->getString('message'),
                'isShared' => $this->getBoolean('is_shared'),
            ]
        );

        return $this->dispatch('POST', '/textMessageTemplates', $payload);
    }

    public function updateTextMessageTemplate(): array
    {
        $validationRules = ['template_id' => ['required', 'integer']];
        $error = $this->validateFields(
            $validationRules,
            [
                'template_id' => __('Text Message Template ID', 'bit-integrations-pro'),
            ]
        );

        if ($error !== null) {
            return $error;
        }

        $payload = $this->removeEmptyValues(
            [
                'name'     => $this->getString('name'),
                'message'  => $this->getString('message'),
                'isShared' => $this->getBoolean('is_shared'),
            ]
        );

        $currentValues = $this->getMissingCurrentValues('/textMessageTemplates/' . rawurlencode($this->getString('template_id')), $payload, ['name', 'message']);

        if (isset($currentValues['success'])) {
            return $currentValues;
        }

        $payload += $currentValues;

        return $this->dispatch('PUT', '/textMessageTemplates/' . rawurlencode($this->getString('template_id')), $payload);
    }

    public function deleteTextMessageTemplate(): array
    {
        $validationRules = ['template_id' => ['required', 'integer']];
        $error = $this->validateFields(
            $validationRules,
            [
                'template_id' => __('Text Message Template ID', 'bit-integrations-pro'),
            ]
        );

        if ($error !== null) {
            return $error;
        }

        return $this->dispatch('DELETE', '/textMessageTemplates/' . rawurlencode($this->getString('template_id')));
    }
}
