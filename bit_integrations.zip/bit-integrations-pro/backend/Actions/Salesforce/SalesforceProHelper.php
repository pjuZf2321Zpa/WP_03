<?php

namespace BitApps\IntegrationsPro\Actions\Salesforce;

class SalesforceProHelper
{
    public static function getLeadUtilities($default, $params, $key)
    {
        $httpHelperClass = bit_integrations_get_class('Core\\Util\\HttpHelper');
        $salesforceControllerClass = bit_integrations_get_class('Actions\\Salesforce\\SalesforceController');

        if (
            empty($params->tokenDetails)
            || empty($params->actionName)
            || empty($params->clientId)
            || empty($params->clientSecret)
        ) {
            return ['response' => __('Requested parameter is empty', 'bit-integrations-pro'), 'code' => 400];
        }

        $response = $salesforceControllerClass::refreshTokenDetails($params);
        $action = ($salesforceControllerClass && isset($salesforceControllerClass::$actions[$params->actionName]))
            ? $salesforceControllerClass::$actions[$params->actionName]
            : $params->actionName;
        $tokenDetails = $response['tokenDetails'];

        $apiEndpoint = "{$tokenDetails->instance_url}/services/data/v37.0/sobjects/{$action}/describe";

        $apiResponse = $httpHelperClass::get($apiEndpoint, null, $salesforceControllerClass::setHeaders($tokenDetails->access_token));

        if (!property_exists((object) $apiResponse, 'fields')) {
            return ['response' => $apiResponse, 'code' => 400];
        }

        $field = current(array_filter($apiResponse->fields, function ($field) use ($key) {
            return $field->name === $key;
        }));

        if (!empty($tokenDetails)) {
            $salesforceControllerClass::saveRefreshedToken($params->flowID, $tokenDetails, $response['organizations']);
        }

        return ['response' => $field->picklistValues ?? [], 'code' => 200];
    }

    public static function addLeadUtilities($data, $actions)
    {
        if (!empty($actions->selectedLeadSource)) {
            $data['LeadSource'] = $actions->selectedLeadSource;
        }
        if (!empty($actions->selectedLeadStatus)) {
            $data['Status'] = $actions->selectedLeadStatus;
        }
        if (!empty($actions->selectedLeadRating)) {
            $data['Rating'] = $actions->selectedLeadRating;
        }
        if (!empty($actions->selectedLeadIndustry)) {
            $data['Industry'] = $actions->selectedLeadIndustry;
        }

        return $data;
    }

    public static function updateRecord($response, $endpoint, $data, $headers)
    {
        $httpHelperClass = bit_integrations_get_class('Core\\Util\\HttpHelper');

        $response = (array) $response;
        $duplicateRecordId = isset($response[0]->duplicateResult->matchResults[0]->matchRecords[0]->record->Id)
            ? $response[0]->duplicateResult->matchResults[0]->matchRecords[0]->record->Id
            : null;

        if (\is_null($duplicateRecordId)) {
            return $response;
        }

        $endpoint = $endpoint . '/' . $duplicateRecordId;

        return $httpHelperClass::request($endpoint, 'PATCH', wp_json_encode($data), $headers);
    }
}
