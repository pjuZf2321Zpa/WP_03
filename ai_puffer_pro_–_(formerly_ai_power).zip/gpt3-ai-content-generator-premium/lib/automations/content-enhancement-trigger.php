<?php

namespace WPAICG\AutoGPT\Cron\EventProcessor\Trigger;

use WP_Query;
use WPAICG\AutoGPT\Helpers;

if (!defined('ABSPATH')) {
    exit;
}

require_once WPAICG_PLUGIN_DIR . 'classes/automations/task-access.php';

/**
 * Queues existing content for enhancement based on task configuration.
 *
 * @param int $task_id The ID of the task.
 * @param array $task_config The configuration of the task.
 * @param string|null $last_run_time The last time the task was run.
 * @return void
 */
function trigger_content_enhancement_task_logic(int $task_id, array $task_config, ?string $last_run_time = null): void
{
    if (!Helpers\is_pro_plan_active()) {
        return;
    }

    global $wpdb;
    $queue_table_name = $wpdb->prefix . 'aipkit_automated_task_queue';

    $post_types = $task_config['post_types'] ?? ['post'];
    if (empty($post_types)) {
        return;
    }

    $args = [
        'post_type'      => $post_types,
        'post_status'    => $task_config['post_statuses'] ?? ['publish'],
        'posts_per_page' => -1,
        'fields'         => 'ids',
        'orderby'        => 'ID',
        'order'          => 'ASC',
    ];

    if ($last_run_time) {
        $args['date_query'] = [
            [
                'column' => 'post_modified_gmt',
                'after'  => $last_run_time,
                'inclusive' => false,
            ],
        ];
    }

    $tax_queries = [];
    if (!empty($task_config['post_categories'])) {
        $tax_queries[] = [
            'taxonomy' => 'category',
            'field'    => 'term_id',
            'terms'    => $task_config['post_categories'],
            'operator' => 'IN',
        ];
    }
    if (!empty($tax_queries)) {
        if (count($tax_queries) > 1) {
            $tax_queries['relation'] = 'AND';
        }
        // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query -- Reason: The meta/tax query is essential for the feature's functionality. Its performance impact is acceptable in admin/cron context.
        $args['tax_query'] = $tax_queries;
    }

    if (!empty($task_config['post_authors'])) {
        $args['author__in'] = $task_config['post_authors'];
    }

    $query = new WP_Query($args);

    if ($query->have_posts()) {
        foreach ($query->posts as $post_id) {
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter -- Reason: Direct query to a custom table. Caches will be invalidated.
            $existing_item = $wpdb->get_var($wpdb->prepare("SELECT id FROM {$queue_table_name} WHERE task_id = %d AND target_identifier = %s",
                $task_id,
                $post_id
            ));

            if ($existing_item) {
                continue;
            }

            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- Reason: Direct insert to a custom table.
            $wpdb->insert(
                $queue_table_name,
                [
                    'task_id'           => $task_id,
                    'target_identifier' => $post_id,
                    'task_type'         => 'enhance_existing_content',
                    'item_config'       => wp_json_encode($task_config),
                    'status'            => 'pending',
                    'added_at'          => current_time('mysql', 1),
                ],
                ['%d', '%d', '%s', '%s', '%s', '%s']
            );
        }
    }
}
