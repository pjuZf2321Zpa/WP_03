<?php

/**
 * GetResponse    Record Api
 */

namespace BitApps\IntegrationsPro\Actions\GetResponse;

class GetResponseHelperPro
{
    public static function autoResponderDay($requestParams, $dayOfCycle)
    {
        $requestParams['dayOfCycle'] = $dayOfCycle;

        return $requestParams;
    }
}
