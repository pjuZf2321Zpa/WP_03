<?php

namespace MasterStudy\Lms\Pro\AddonsPlus\Calendar\Http\Controllers;

use WP_REST_Request;
use WP_REST_Response;

final class EventsController extends Controller {
	public function __invoke( WP_REST_Request $request ): WP_REST_Response {
		$validated_data = $this->validate(
			$request,
			array_merge(
				$this->month_rules(),
				$this->pagination_rules( 50 ),
				$this->event_type_rules(),
				array(
					'search' => 'nullable|max,100',
					'status' => 'nullable|calendar_event_status',
				)
			)
		);

		if ( $validated_data instanceof WP_REST_Response ) {
			return $validated_data;
		}

		return new WP_REST_Response(
			( new \MasterStudy\Lms\Pro\AddonsPlus\Calendar\Http\Serializers\PaginatedEventsSerializer() )->toArray(
				$this->provider()->get_month_events(
					absint( $validated_data['year'] ),
					absint( $validated_data['month'] ),
					$this->get_page( $validated_data ),
					$this->get_per_page( $validated_data, 20, 50 ),
					$this->get_search( $validated_data ),
					$this->get_status( $validated_data ),
					$this->get_event_type( $validated_data )
				)
			)
		);
	}
}
