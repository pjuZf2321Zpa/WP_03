<?php

namespace FluentCartPro\App\Modules\DynamicPricing\Conditions\Options;

use FluentCart\App\Models\Product;
use FluentCart\App\Services\Filter\ProductFilter;
use FluentCart\App\Services\Permission\PermissionManager;
use FluentCart\Framework\Support\Arr;
use FluentCartPro\App\Modules\DynamicPricing\Conditions\ConditionRegistry;

/**
 * Provides products for the Dynamic Pricing condition builder's remote select.
 *
 * Products are exposed through a dedicated `data_key` so the condition
 * builder can load and search them independently from the regular product
 * filters used elsewhere in the admin.
 *
 * Each additional resource can provide its own OptionSource implementation
 * and register it through DynamicPricingInit without changing the shared
 * option-loading flow.
 *
 * @package FluentCartPro\App\Modules\DynamicPricing
 *
 * @version 1.0.0
 */
class ProductOptions extends OptionSource
{
    /**
     * Unique `data_key` used by condition attributes to load product options.
     *
     * @var string
     */
    protected $key = 'dynamic_pricing_products';

    /**
     * Build the product options returned to the condition picker.
     *
     * The product filter handles searching and querying the catalogue, while
     * this method normalizes the request, applies safe limits, and converts
     * products into the `{value, label}` format expected by the picker.
     *
     * @param array $options
     * @param array $args
     * @return array
     */
    public function options($options, $args)
    {
        $includeIds = array_filter(array_map('intval', (array)Arr::get($args, 'include_ids', [])));

        /*
         * Remove duplicate IDs and cap the list to the maximum number of
         * values allowed for a select condition. This keeps the request
         * bounded even when the IDs come from user input.
         */
        $includeIds = array_slice(array_unique($includeIds), 0, ConditionRegistry::MAX_SELECT_VALUES);

        /*
         * Always pass a normalized array to the product filter. This prevents
         * a missing or empty `include_ids` value from being interpreted as an
         * actual filter value.
         */
        $args['include_ids'] = $includeIds;

        /*
         * Keep the requested page size within the allowed range. This prevents
         * an invalid or excessively large limit from loading the entire
         * catalogue for a dropdown.
         */
        $args['limit'] = $this->boundedLimit(Arr::get($args, 'limit'));

        $products = ProductFilter::make($args)->get()->map(function ($product) {
            return [
                'value' => (int)$product->ID,
                'label' => $product->post_title,
            ];
        })->toArray();

        return $this->withPinned($products, $includeIds);
    }

    /**
     * Determine whether the current user can access product options.
     *
     * Access requires both product-view permission and permission to view
     * Dynamic Pricing, ensuring this source does not expose product data to
     * users who cannot use the pricing rule editor.
     *
     * @param bool $hasPermission
     * @return bool
     */
    public function canRead($hasPermission)
    {
        return PermissionManager::hasPermission('products/view')
            && PermissionManager::hasPermission('dynamic_pricing/view');
    }

    /**
     * Ensure already-selected products are included in the result.
     *
     * Search results are normally limited to a page-sized set, so a previously
     * selected product may fall outside the current result set. Those products
     * are loaded separately and placed at the beginning of the list so the
     * picker can display their labels and keep the saved selection intact.
     *
     * @param array $products
     * @param array $includeIds
     * @return array
     */
    protected function withPinned($products, $includeIds)
    {
        if (!$includeIds) {
            return $products;
        }

        $missing = array_diff($includeIds, array_column($products, 'value'));

        if (!$missing) {
            return $products;
        }

        $pinned = Product::query()->whereIn('ID', $missing)->get()->map(function ($product) {
            return [
                'value' => (int)$product->ID,
                'label' => $product->post_title,
            ];
        })->toArray();

        // Keep previously selected products visible at the top of the list.
        return array_merge($pinned, $products);
    }
}