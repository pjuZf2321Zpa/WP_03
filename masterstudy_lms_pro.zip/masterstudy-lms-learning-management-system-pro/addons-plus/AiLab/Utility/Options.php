<?php

namespace MasterStudy\Lms\Pro\AddonsPlus\AiLab\Utility;

use MasterStudy\Lms\Pro\AddonsPlus\AiLab\Services\OpenAi\Model;

final class Options {
	private array $options = array();

	public function __construct() {
		$this->options = $this->get_options();

		$text_provider             = $this->get_active_text_provider();
		$image_provider            = $this->get_active_image_provider( $text_provider );
		$text_model_option_key     = $this->get_text_model_option_key( $text_provider );
		$image_model_option_key    = $this->get_image_model_option_key( $image_provider );
		$text_model_default        = Model::get_default_text_model_by_provider( $text_provider );
		$image_model_default       = Model::get_default_image_model_by_provider( $image_provider );
		$text_models               = Model::get_text_models_by_provider( $text_provider );
		$image_models              = Model::get_image_models_by_provider( $image_provider );
		$text_api_key_option_name  = Model::get_api_option_name_by_provider( $text_provider );
		$image_api_key_option_name = Model::get_api_option_name_by_provider( $image_provider );
		$is_text_only_provider     = in_array(
			$text_provider,
			array(
				Model::PROVIDER_CLAUDE,
				Model::PROVIDER_MISTRAL,
			),
			true
		);

		$this->options['text_provider'] = $text_provider;
		$this->options['image_provider'] = $image_provider;
		$this->options['api_key']       = trim( (string) \STM_LMS_Options::get_option( $text_api_key_option_name ) );
		$this->options['image_api_key'] = $is_text_only_provider
			? trim( (string) \STM_LMS_Options::get_option( 'ai_fallback_image_api_key', \STM_LMS_Options::get_option( $image_api_key_option_name ) ) )
			: $this->options['api_key'];
		$this->options['openai_api_key'] = trim( (string) \STM_LMS_Options::get_option( 'openai_api_key' ) );
		$this->options['base_url']      = $this->get_provider_base_url( $text_provider );
		$this->options['image_base_url'] = $this->get_provider_base_url( $image_provider );
		$saved_text_model  = (string) \STM_LMS_Options::get_option( $text_model_option_key, $text_model_default );
		$saved_image_model = (string) \STM_LMS_Options::get_option( $image_model_option_key, $image_model_default );

		$this->options['text_model']  = array_key_exists( $saved_text_model, $text_models ) ? $saved_text_model : $text_model_default;
		$this->options['image_model'] = array_key_exists( $saved_image_model, $image_models ) ? $saved_image_model : $image_model_default;

		$this->options['results']       = array(
			'text'  => \STM_LMS_Options::get_option( 'openai_text_suggestions', 4 ),
			'image' => 1,
		);
		$this->options['generator']['image']['model'] = $this->options['image_model'];
	}

	public function get( $name, $default = null ) {
		return ArrayHelper::get( $this->options, $name, $default );
	}

	private function get_options(): array {
		return array(
			'modules'   => array(
				'title'   => true,
				'text'    => true,
				'content' => true,
				'image'   => true,
			),
			'generator' => array(
				'title'   => array(
					'prompt' => "Create a short SEO-friendly title for this prompt: %s.\n No URLs, no apostrophes. ",
					'tokens' => 100,
				),
				'text'    => array(
					'prompt' => "Create a SEO-friendly text for this prompt: %s.\n Respond with HTML format for TinyMCE without comments. No URLs, no apostrophes, no titles. ",
					'tokens' => 500,
				),
				'content' => array(
					'prompt' => "Create a SEO-friendly content for this prompt: %s.\n Respond with HTML format for TinyMCE without comments. No URLs, no apostrophes. ",
					'tokens' => 1500,
					'tones'  => array(
						'Formal'         => 'Formal',
						'Casual'         => 'Casual',
						'Engaging'       => 'Engaging',
						'Professional'   => 'Professional',
						'Conversational' => 'Conversational',
					),
				),
				'quiz'    => array(
					'tokens' => 3000,
				),
				'image'   => array(
					'prompt' => '%s, in style %s',
					'tokens' => 320,
					'model'  => Model::GPT_IMAGE_2,
					'size'   => '1024x1024',
					'styles' => array(
						'Abstract'               => 'Abstract',
						'Abstract Expressionism' => 'Abstract Expressionism',
						'Action painting'        => 'Action painting',
						'Art Brut'               => 'Art Brut',
						'Art Deco'               => 'Art Deco',
						'Art Nouveau'            => 'Art Nouveau',
						'Baroque'                => 'Baroque',
						'Byzantine'              => 'Byzantine',
						'Caricature'             => 'Caricature',
						'Cartoon'                => 'Cartoon',
						'Classical'              => 'Classical',
						'Color Field'            => 'Color Field',
						'Conceptual'             => 'Conceptual',
						'Cubism'                 => 'Cubism',
						'Dada'                   => 'Dada',
						'Expressionism'          => 'Expressionism',
						'Fauvism'                => 'Fauvism',
						'Figurative'             => 'Figurative',
						'Futurism'               => 'Futurism',
						'Gothic'                 => 'Gothic',
						'Hard-edge painting'     => 'Hard-edge painting',
						'Hyperrealism'           => 'Hyperrealism',
						'Illustration'           => 'Illustration',
						'Impressionism'          => 'Impressionism',
						'Japonisme'              => 'Japonisme',
						'Luminism'               => 'Luminism',
						'Lyrical Abstraction'    => 'Lyrical Abstraction',
						'Mannerism'              => 'Mannerism',
						'Minimalism'             => 'Minimalism',
						'Naive Art'              => 'Naive Art',
						'New Realism'            => 'New Realism',
						'Neo-expressionism'      => 'Neo-expressionism',
						'Neo-pop'                => 'Neo-pop',
						'Op Art'                 => 'Op Art',
						'Opus Anglicanum'        => 'Opus Anglicanum',
						'Outsider Art'           => 'Outsider Art',
						'Pop Art'                => 'Pop Art',
						'Photorealism'           => 'Photorealism',
						'Pointillism'            => 'Pointillism',
						'Post-Impressionism'     => 'Post-Impressionism',
						'Realistic'              => 'Realistic',
						'Renaissance'            => 'Renaissance',
						'Rococo'                 => 'Rococo',
						'Romanticism'            => 'Romanticism',
						'Street Art'             => 'Street Art',
						'Studio Ghibli'          => 'Studio Ghibli',
						'Superflat'              => 'Superflat',
						'Surrealism'             => 'Surrealism',
						'Symbolism'              => 'Symbolism',
						'Tenebrism'              => 'Tenebrism',
						'Ukiyo-e'                => 'Ukiyo-e',
						'Western Art'            => 'Western Art',
						'YBA'                    => 'YBA',
						'None'                   => 'None',
					),
				),
			),
		);
	}

	private function get_active_image_provider( string $text_provider ): string {
		if ( Model::provider_supports_image_generation( $text_provider ) ) {
			return $text_provider;
		}

		$image_provider = \STM_LMS_Options::get_option( 'ai_fallback_image_provider', Model::PROVIDER_OPENAI );

		if ( ! Model::provider_supports_image_generation( $image_provider ) ) {
			return Model::PROVIDER_OPENAI;
		}

		return $image_provider;
	}

	private function get_active_text_provider(): string {
		$text_provider  = (string) \STM_LMS_Options::get_option( 'ai_text_provider', Model::PROVIDER_OPENAI );
		$text_providers = Model::get_text_providers();

		if ( ! array_key_exists( $text_provider, $text_providers ) ) {
			return Model::PROVIDER_OPENAI;
		}

		return $text_provider;
	}

	private function get_text_model_option_key( string $provider ): string {
		return Model::PROVIDER_OPENAI === $provider ? 'openai_text_model' : "{$provider}_text_model";
	}

	private function get_image_model_option_key( string $provider ): string {
		return Model::PROVIDER_OPENAI === $provider ? 'openai_image_model' : "{$provider}_image_model";
	}

	private function get_provider_base_url( string $provider ): string {
		return untrailingslashit( Model::get_provider_base_url( $provider ) );
	}
}
