<?php
/**
 * The sales window of the preset form and of the *Save as preset* modal.
 *
 * @since 6.12.0
 *
 * @package TEC\Tickets_Plus\Relative_Sale_Dates\Ticket_Presets
 */

namespace TEC\Tickets_Plus\Relative_Sale_Dates\Ticket_Presets;

use TEC\Tickets\Relative_Sale_Dates\Editor;
use TEC\Tickets_Plus\Relative_Sale_Dates\Template;
use Tribe__Template;
use Tribe__Tickets__Admin__Views as Admin_Views;

/**
 * Renders Event Tickets' sales window options in place of a preset's sale period fields.
 *
 * @since 6.12.0
 *
 * @package TEC\Tickets_Plus\Relative_Sale_Dates\Ticket_Presets
 */
final class Preset_Form {
	/**
	 * The hook that renders the sale period fields of the preset form and of the modal before their template does.
	 *
	 * @since 6.12.0
	 *
	 * @var string
	 */
	public const SALE_PERIOD_PRE_HTML_HOOK = 'tribe_template_pre_html:tickets-plus/Tickets_Plus/Ticket_Presets/Admin/preset-form/sale-period';

	/**
	 * The prefix of the ids of the window's options, by where the window renders.
	 *
	 * The modal sits next to the ticket form, whose sales window options use the `ticket_sales` ids.
	 *
	 * @since 6.12.0
	 *
	 * @var array<string,string>
	 */
	private const FIELD_PREFIXES = [
		'form'  => 'tec_tickets_preset_sales',
		'modal' => 'tec_tickets_preset_modal_sales',
	];

	/**
	 * The sales window of a preset.
	 *
	 * @since 6.12.0
	 *
	 * @var Sales_Window
	 */
	private Sales_Window $sales_window;

	/**
	 * Event Tickets' relative sale dates editor.
	 *
	 * @since 6.12.0
	 *
	 * @var Editor
	 */
	private Editor $editor;

	/**
	 * The template that renders the window.
	 *
	 * @since 6.12.0
	 *
	 * @var Template
	 */
	private Template $template;

	/**
	 * The Event Tickets template that renders the window's options.
	 *
	 * @since 6.12.0
	 *
	 * @var Admin_Views
	 */
	private Admin_Views $sales_window_template;

	/**
	 * Preset_Form constructor.
	 *
	 * @since 6.12.0
	 *
	 * @param Sales_Window $sales_window          The sales window of a preset.
	 * @param Editor       $editor                Event Tickets' relative sale dates editor.
	 * @param Template     $template              The template that renders the window.
	 * @param Admin_Views  $sales_window_template The Event Tickets template that renders the window's options. Not the
	 *                                            shared one, which carries each render's context into the next, and
	 *                                            renders the ticket form on the screen where a preset can be saved.
	 */
	public function __construct( Sales_Window $sales_window, Editor $editor, Template $template, Admin_Views $sales_window_template ) {
		$this->sales_window          = $sales_window;
		$this->editor                = $editor;
		$this->template              = $template;
		$this->sales_window_template = $sales_window_template;
	}

	/**
	 * Renders the preset's sales window, with the ticket form's options but no specific date, in place of the sale
	 * period fields.
	 *
	 * @since 6.12.0
	 *
	 * @param string|null                                                 $html     The HTML an earlier callback rendered, or `null`.
	 * @param string                                                      $file     The path of the sale period template.
	 * @param array<string>                                               $name     The name of the template, in parts.
	 * @param Tribe__Template                                             $template The template rendering the sale period fields.
	 * @param array{preset_data?: array<string,mixed>, location?: string} $context The context the template renders
	 *                                                                     with: the `preset_data` of the preset form, or
	 *                                                                     the `location` of the modal.
	 *
	 * @return string|null The HTML of the window, or the one an earlier callback rendered.
	 */
	public function render_sale_period( $html, $file, $name, $template, $context = [] ) {
		if ( null !== $html ) {
			return $html;
		}

		$location     = 'modal' === ( $context['location'] ?? null ) ? 'modal' : 'form';
		$preset_data  = 'form' === $location && is_array( $context['preset_data'] ?? null ) ? $context['preset_data'] : [];
		$form_rule    = $this->sales_window->get_form_rule( $preset_data );
		$field_prefix = self::FIELD_PREFIXES[ $location ];

		return $this->template->template(
			'ticket-presets/sale-period',
			[
				'field_prefix'           => $field_prefix,
				'form_rule'              => $form_rule,
				'sales_window_template'  => $this->sales_window_template,
				'sales_window_context'   => $this->editor->get_preset_sales_window_context( $form_rule, $field_prefix ),
				'has_unsupported_option' => $this->sales_window->has_unsupported_stored_option( $preset_data ),
				'rule_field_name'        => 'preset[' . Sales_Window::DATA_KEY . ']',
			],
			false
		);
	}
}
