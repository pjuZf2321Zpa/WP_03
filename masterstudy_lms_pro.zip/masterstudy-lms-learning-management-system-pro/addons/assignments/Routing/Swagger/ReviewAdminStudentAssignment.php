<?php

namespace MasterStudy\Lms\Pro\addons\assignments\Routing\Swagger;

use MasterStudy\Lms\Routing\Swagger\RequestInterface;
use MasterStudy\Lms\Routing\Swagger\ResponseInterface;
use MasterStudy\Lms\Routing\Swagger\Route;

class ReviewAdminStudentAssignment extends Route implements RequestInterface, ResponseInterface {
	public function request(): array {
		return array(
			'review'     => array(
				'type' => 'string',
			),
			'status'     => array(
				'type' => 'string',
				'enum' => array( 'passed', 'not_passed' ),
			),
			'grade_type' => array(
				'type' => 'string',
				'enum' => array( 'grade', 'point', 'percent' ),
			),
			'grade'      => array(
				'type' => 'string',
			),
			'point'      => array(
				'type' => 'string',
			),
			'percent'    => array(
				'type' => 'integer',
			),
		);
	}

	public function response(): array {
		return array(
			'success' => array(
				'type' => 'boolean',
			),
			'status'  => array(
				'type' => 'string',
			),
			'grade'   => array(
				'type' => 'integer',
			),
		);
	}

	public function get_summary(): string {
		return 'Review Admin Student Assignment';
	}

	public function get_description(): string {
		return 'Saves the review data for a student assignment attempt from the React admin drawer.';
	}
}
