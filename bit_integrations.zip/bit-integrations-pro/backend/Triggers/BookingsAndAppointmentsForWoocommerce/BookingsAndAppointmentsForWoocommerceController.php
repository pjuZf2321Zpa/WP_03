<?php

namespace BitApps\IntegrationsPro\Triggers\BookingsAndAppointmentsForWoocommerce;

use BitApps\IntegrationsPro\Config;
use WC_Order;
use WC_Order_Factory;
use WC_Order_Item_Product;

final class BookingsAndAppointmentsForWoocommerceController
{
    public static function info()
    {
        return [
            'name'              => 'Bookings And Appointments For Woocommerce',
            'type'              => 'custom_form_submission',
            'is_active'         => static::isPluginInstalled(),
            'tutorial_url'      => '#',
            'tasks'             => [
                'action' => 'bookings_and_appointments_for_woocommerce/get',
                'method' => 'get',
            ],
            'fetch' => [
                'action' => 'trigger/test',
                'method' => 'post',
            ],
            'fetch_remove' => [
                'action' => 'trigger/test/remove',
                'method' => 'post',
            ],
            'isPro' => true,
        ];
    }

    public function getAllTasks()
    {
        if (!static::isPluginInstalled()) {
            wp_send_json_error(\sprintf(__('%s is not installed or activated', 'bit-integrations-pro'), 'Bookings and Appointments for WooCommerce'));
        }

        wp_send_json_success([
            ['form_name' => __('Booking Status Changed (Any)', 'bit-integrations-pro'), 'triggered_entity_id' => 'ph_booking_status_changed', 'skipPrimaryKey' => true, 'note' => __('Runs whenever a booking\'s status changes.', 'bit-integrations-pro')],
            ['form_name' => __('Booking Confirmed', 'bit-integrations-pro'), 'triggered_entity_id' => 'ph_booking_status_changed_confirmed', 'skipPrimaryKey' => true, 'note' => __('Runs when a booking is confirmed.', 'bit-integrations-pro')],
            ['form_name' => __('Booking Paid', 'bit-integrations-pro'), 'triggered_entity_id' => 'ph_booking_status_changed_paid', 'skipPrimaryKey' => true, 'note' => __('Runs when a booking is marked paid.', 'bit-integrations-pro')],
            ['form_name' => __('Booking Unpaid', 'bit-integrations-pro'), 'triggered_entity_id' => 'ph_booking_status_changed_unpaid', 'skipPrimaryKey' => true, 'note' => __('Runs when a booking is marked un-paid.', 'bit-integrations-pro')],
            ['form_name' => __('Booking Cancelled', 'bit-integrations-pro'), 'triggered_entity_id' => 'ph_booking_status_changed_cancelled', 'skipPrimaryKey' => true, 'note' => __('Runs when a booking is cancelled.', 'bit-integrations-pro')],
            ['form_name' => __('Booking Deleted', 'bit-integrations-pro'), 'triggered_entity_id' => 'ph_booking_status_changed_deleted', 'skipPrimaryKey' => true, 'note' => __('Runs when a booking is deleted.', 'bit-integrations-pro')],
            ['form_name' => __('Booking Details Updated', 'bit-integrations-pro'), 'triggered_entity_id' => 'ph_booking_details_updated', 'skipPrimaryKey' => true, 'note' => __('Runs when booking details (dates/participants/etc.) are updated.', 'bit-integrations-pro')],
            ['form_name' => __('Booking Items Modified', 'bit-integrations-pro'), 'triggered_entity_id' => 'ph_booking_order_items_modified', 'skipPrimaryKey' => true, 'note' => __('Runs when a booking order item is edited.', 'bit-integrations-pro')],
            ['form_name' => __('Booking Created', 'bit-integrations-pro'), 'triggered_entity_id' => 'ph_bookings_reminder_schedule_for_item', 'skipPrimaryKey' => true, 'note' => __('Runs when a new booking is placed.', 'bit-integrations-pro')],
            ['form_name' => __('Bulk Action Processed', 'bit-integrations-pro'), 'triggered_entity_id' => 'ph_bookings_process_bulk_action', 'skipPrimaryKey' => true, 'note' => __('Runs when the admin runs a bulk action on bookings.', 'bit-integrations-pro')],
            ['form_name' => __('Bulk iCalendar Downloaded', 'bit-integrations-pro'), 'triggered_entity_id' => 'ph_bookings_bulk_icalendar_download', 'skipPrimaryKey' => true, 'note' => __('Runs when bookings are downloaded as iCalendar files.', 'bit-integrations-pro')],
            ['form_name' => __('Booking Payment Processed', 'bit-integrations-pro'), 'triggered_entity_id' => 'ph_booking_payment_processed', 'skipPrimaryKey' => true, 'note' => __('Runs when a booking payment is processed at checkout.', 'bit-integrations-pro')],
            ['form_name' => __('Booking Payment Audit Logged', 'bit-integrations-pro'), 'triggered_entity_id' => 'ph_booking_payment_audit', 'skipPrimaryKey' => true, 'note' => __('Runs when a financial event is logged for a booking.', 'bit-integrations-pro')],
            ['form_name' => __('Booking Order Failed', 'bit-integrations-pro'), 'triggered_entity_id' => 'ph_woocommerce_order_status_failed', 'skipPrimaryKey' => true, 'note' => __('Runs when a booking order fails.', 'bit-integrations-pro')],
            ['form_name' => __('Paid Booking Ready for Meeting', 'bit-integrations-pro'), 'triggered_entity_id' => 'ph_zoom_create_meeting_for_paid_order', 'skipPrimaryKey' => true, 'note' => __('Runs when a paid booking order is ready for a Zoom meeting.', 'bit-integrations-pro')],
            ['form_name' => __('Booking Calendar Resynced', 'bit-integrations-pro'), 'triggered_entity_id' => 'ph_booking_item_calender_resynced', 'skipPrimaryKey' => true, 'note' => __('Runs when a booking is resynced to Google Calendar.', 'bit-integrations-pro')],
            ['form_name' => __('Booking Created From Google Calendar', 'bit-integrations-pro'), 'triggered_entity_id' => 'ph_bookings_order_created_from_google_calendar', 'skipPrimaryKey' => true, 'note' => __('Runs when a booking order is created from a Google Calendar event.', 'bit-integrations-pro')],
            ['form_name' => __('Admin Booking Google Calendar Synced', 'bit-integrations-pro'), 'triggered_entity_id' => 'ph_booking_google_calender_sync_for_admin_bookings', 'skipPrimaryKey' => true, 'note' => __('Runs when an admin-created booking is synced to Google Calendar.', 'bit-integrations-pro')],
            ['form_name' => __('Booking Added to Cart', 'bit-integrations-pro'), 'triggered_entity_id' => 'ph_bookings_insert_data_in_availability_table_from_cart', 'skipPrimaryKey' => true, 'note' => __('Runs when a booking is added to the WooCommerce cart.', 'bit-integrations-pro')],
        ]);
    }

    public static function handleStatusChanged($status, $itemId, $orderId)
    {
        $data = static::bookingPayload($itemId, $orderId);

        if (empty($data)) {
            return;
        }

        $data['status'] = $status;

        static::flowExecute('ph_booking_status_changed', $data);

        $statusEntityIds = [
            'confirmed' => 'ph_booking_status_changed_confirmed',
            'paid'      => 'ph_booking_status_changed_paid',
            'un-paid'   => 'ph_booking_status_changed_unpaid',
            'cancelled' => 'ph_booking_status_changed_cancelled',
            'canceled'  => 'ph_booking_status_changed_cancelled',
            'deleted'   => 'ph_booking_status_changed_deleted',
        ];

        if (isset($statusEntityIds[$status])) {
            static::flowExecute($statusEntityIds[$status], $data);
        }
    }

    public static function handleDetailsUpdated($orderId, $itemId, $order = '', $notifyMode = '')
    {
        $data = static::bookingPayload($itemId, $orderId);

        if (empty($data)) {
            return;
        }

        $data['notify_mode'] = $notifyMode;

        static::flowExecute('ph_booking_details_updated', $data);
    }

    public static function handleItemsModified($editItems, $orderId)
    {
        if (!\is_array($editItems) || empty($editItems)) {
            return;
        }

        foreach (array_keys($editItems) as $itemId) {
            $data = static::bookingPayload($itemId, $orderId);

            if (!empty($data)) {
                static::flowExecute('ph_booking_order_items_modified', $data);
            }
        }
    }

    public static function handleBookingCreated($itemId, $orderId)
    {
        $data = static::bookingPayload($itemId, $orderId);

        if (empty($data)) {
            return;
        }

        static::flowExecute('ph_bookings_reminder_schedule_for_item', $data);
    }

    public static function handleBulkActionProcessed($selectedBookingIds, $action)
    {
        if (!\is_array($selectedBookingIds) || empty($selectedBookingIds)) {
            return;
        }

        static::flowExecute('ph_bookings_process_bulk_action', [
            'action'      => sanitize_text_field((string) $action),
            'booking_ids' => implode(',', array_map('absint', $selectedBookingIds)),
        ]);
    }

    public static function handleBulkNoticeTransient($transient, $notice)
    {
        if (strpos((string) $transient, 'ph_bookings_bulk_notice_') !== 0) {
            return;
        }

        // phpcs:ignore WordPress.Security.NonceVerification.Recommended, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized, WordPress.Security.ValidatedSanitizedInput.MissingUnslash -- read-only; the plugin verified the bulk-action request and ids are absint-ed.
        $selectedBookingIds = $_REQUEST['ph_selected_bookings'] ?? [];

        static::handleBulkActionProcessed($selectedBookingIds, \is_array($notice) ? ($notice['action'] ?? '') : '');
    }

    public static function handleBulkIcalendarDownloaded($orderIds)
    {
        static::flowExecute('ph_bookings_bulk_icalendar_download', [
            'order_ids' => \is_array($orderIds) ? implode(',', array_map('absint', $orderIds)) : (string) $orderIds,
        ]);
    }

    public static function handlePaymentProcessed($orderId)
    {
        static::flowExecute('ph_booking_payment_processed', static::orderPayload($orderId));
    }

    public static function handlePaymentAudit($eventType, $order, $data = [])
    {
        if (!$order instanceof WC_Order) {
            return;
        }

        static::flowExecute('ph_booking_payment_audit', array_merge(
            ['event_type' => $eventType, 'order_id' => $order->get_id()],
            array_map(static fn ($value) => \is_scalar($value) ? $value : '', (array) $data)
        ));
    }

    public static function handleOrderFailed($orderId)
    {
        static::flowExecute('ph_woocommerce_order_status_failed', static::orderPayload($orderId));
    }

    public static function handlePaidBookingReadyForMeeting($orderId, $order = '', $bookingStatus = '')
    {
        $data = static::orderPayload($orderId);
        $data['booking_status'] = $bookingStatus;

        static::flowExecute('ph_zoom_create_meeting_for_paid_order', $data);
    }

    public static function handleCalendarResynced($action, $itemId, $orderId)
    {
        $data = static::bookingPayload($itemId, $orderId);

        if (empty($data)) {
            return;
        }

        $data['resync_action'] = $action;

        static::flowExecute('ph_booking_item_calender_resynced', $data);
    }

    public static function handleCreatedFromGoogleCalendar($itemId, $orderId)
    {
        $data = static::bookingPayload($itemId, $orderId);

        if (empty($data)) {
            return;
        }

        static::flowExecute('ph_bookings_order_created_from_google_calendar', $data);
    }

    public static function handleAdminGoogleCalendarSynced($orderId)
    {
        static::flowExecute('ph_booking_google_calender_sync_for_admin_bookings', static::orderPayload($orderId));
    }

    public static function handleAddedToCart($cartItemData)
    {
        if (!\is_array($cartItemData)) {
            return;
        }

        static::flowExecute('ph_bookings_insert_data_in_availability_table_from_cart', [
            'product_id' => $cartItemData['product_id'] ?? 0,
            'from'       => $cartItemData['phive_book_from_date'] ?? '',
            'to'         => $cartItemData['phive_book_to_date'] ?? '',
            'price'      => $cartItemData['phive_booked_price'] ?? '',
        ]);
    }

    private static function bookingPayload($itemId, $orderId)
    {
        $itemId = (int) $itemId;

        if ($itemId <= 0) {
            return [];
        }

        $item = WC_Order_Factory::get_order_item($itemId);

        if (!$item) {
            return [];
        }

        $orderId = $orderId ?: (int) $item->get_order_id();
        $order = wc_get_order($orderId);

        $productId = ($item instanceof WC_Order_Item_Product) ? (int) $item->get_product_id() : 0;
        $statusRaw = wc_get_order_item_meta($itemId, 'booking_status', true);
        $status = \is_array($statusRaw) ? ($statusRaw[0] ?? '') : $statusRaw;

        $data = [
            'item_id'           => $itemId,
            'order_id'          => $orderId,
            'product_id'        => $productId,
            'product_name'      => $item->get_name(),
            'from'              => static::flattenMetaValue(wc_get_order_item_meta($itemId, 'From', true)),
            'to'                => static::flattenMetaValue(wc_get_order_item_meta($itemId, 'To', true)),
            'booking_status'    => $status,
            'number_of_persons' => static::flattenMetaValue(wc_get_order_item_meta($itemId, 'Number of persons', true)),
            'assets'            => static::flattenMetaValue(wc_get_order_item_meta($itemId, 'Assets', true)),
        ];

        if ($order instanceof WC_Order) {
            $data['order_status'] = $order->get_status();
            $data['order_total'] = $order->get_total();
            $data['customer_id'] = $order->get_customer_id();
            $data['billing_email'] = $order->get_billing_email();
        }

        return $data;
    }

    private static function orderPayload($orderId)
    {
        $order = wc_get_order((int) $orderId);

        if (!$order instanceof WC_Order) {
            return ['order_id' => (int) $orderId];
        }

        return [
            'order_id'      => $order->get_id(),
            'order_status'  => $order->get_status(),
            'order_total'   => $order->get_total(),
            'customer_id'   => $order->get_customer_id(),
            'billing_email' => $order->get_billing_email(),
        ];
    }

    private static function flattenMetaValue($value)
    {
        return \is_array($value) ? ($value[0] ?? '') : $value;
    }

    private static function flowExecute($triggered_entity_id, $formData)
    {
        $helperClass = bit_integrations_get_class('Core\\Util\\Helper');
        $flowClass = bit_integrations_get_class('Flow\\Flow');

        $formData = $helperClass::prepareFetchFormatFields($formData);

        if (empty($formData) || !\is_array($formData)) {
            return;
        }

        $helperClass::setTestData(Config::withFreePrefix("{$triggered_entity_id}_test"), array_values($formData));

        $flows = $flowClass::exists('BookingsAndAppointmentsForWoocommerce', $triggered_entity_id);

        if (empty($flows)) {
            return;
        }

        $flowClass::execute('BookingsAndAppointmentsForWoocommerce', $triggered_entity_id, array_column($formData, 'value', 'name'), $flows);

        return ['type' => 'success'];
    }

    private static function isPluginInstalled()
    {
        return \defined('PH_BOOKINGS_PLUGIN_FILE');
    }
}
