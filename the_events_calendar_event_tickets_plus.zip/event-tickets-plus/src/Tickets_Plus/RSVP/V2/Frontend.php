<?php
/**
 * Frontend handler for RSVP V2.
 *
 * @since 6.11.0
 *
 * @package TEC\Tickets_Plus\RSVP\V2
 */

namespace TEC\Tickets_Plus\RSVP\V2;

use TEC\Tickets\RSVP\V2\Constants as RSVP_Constants;
use Tribe\Tickets\Plus\Attendee_Registration\Fields;
use Tribe\Tickets\Plus\Attendee_Registration\IAC;
use Tribe__Template as Base_Template;
use Tribe__Tickets__Ticket_Object as Ticket_Object;
use Tribe__Tickets_Plus__Meta as Meta;
use WP_REST_Request;

/**
 * Class Frontend
 *
 * Renders attendee registration forms and handles form step routing for RSVP V2.
 *
 * @since 6.11.0
 *
 * @package TEC\Tickets_Plus\RSVP\V2
 */
class Frontend {
	/**
	 * The template instance for rendering RSVP views.
	 *
	 * @since 6.11.0
	 *
	 * @var Template
	 */
	private Template $template;

	/**
	 * Frontend constructor.
	 *
	 * @since 6.11.0
	 *
	 * @param Template $template The template instance.
	 */
	public function __construct( Template $template ) {
		$this->template = $template;
	}

	/**
	 * Filter RSVP render step template args to ensure 'ari' step when attendee fields exist.
	 *
	 * @since 6.11.0
	 *
	 * @param array $args The template arguments array.
	 *
	 * @return array Modified template arguments.
	 */
	public function filter_step_args( array $args ): array {
		if ( ! isset( $args['rsvp_id'] ) ) {
			return $args;
		}

		if ( ! ( isset( $args['step'] ) && $args['step'] === 'going' ) ) {
			return $args;
		}

		if ( ! (
			isset( $args['rsvp'] )
			&& $args['rsvp'] instanceof Ticket_Object
			&& RSVP_Constants::TC_RSVP_TYPE === $args['rsvp']->type()
		) ) {
			return $args;
		}

		/** @var Meta $meta */
		$meta        = tribe( 'tickets-plus.meta' );
		$meta_fields = $meta->get_meta_fields_by_ticket( $args['rsvp_id'] );

		/** @var IAC $iac */
		$iac         = tribe( 'tickets-plus.attendee-registration.iac' );
		$iac_setting = $iac->get_iac_setting_for_ticket( $args['rsvp_id'] );

		if ( ! empty( $meta_fields ) || IAC::NONE_KEY !== $iac_setting ) {
			$args['step'] = 'ari';
		}

		return $args;
	}

	/**
	 * Render ARF fields for the main guest in the ARI form.
	 *
	 * Hooked to the `rsvp_attendee_fields` entry point in the main guest form.
	 * Uses attendee_id=0 to align with the base RSVP form's name/email at index [0].
	 *
	 * @since 6.11.0
	 *
	 * @param string        $hook_name        The template hook name.
	 * @param string        $entry_point_name The entry point name.
	 * @param Base_Template $template         The template instance.
	 */
	public function render_main_guest_fields( string $hook_name, string $entry_point_name, Base_Template $template ): void {
		$this->render_entry_point_fields( $hook_name, $entry_point_name, $template, 0 );
	}

	/**
	 * Render ARF fields for the clone template in the ARI form.
	 *
	 * Hooked to the `rsvp_attendee_fields_template` entry point for additional guests.
	 * Uses a JS placeholder for attendee_id since cloned guests get dynamic IDs.
	 * The placeholder `{{data.attendee_id}}` is 0-based, matching the base form's indexing.
	 *
	 * @since 6.11.0
	 *
	 * @param string        $hook_name        The template hook name.
	 * @param string        $entry_point_name The entry point name.
	 * @param Base_Template $template         The template instance.
	 */
	public function render_clone_template_fields( string $hook_name, string $entry_point_name, Base_Template $template ): void {
		$this->render_entry_point_fields( $hook_name, $entry_point_name, $template, '{{data.attendee_id}}' );
	}

	/**
	 * Core rendering logic for ARF fields in the ARI form entry points.
	 *
	 * For clone template guests (when $attendee_id is a string placeholder),
	 * also renders IAC name/email fields if IAC is enabled on the ticket.
	 * The main guest's name/email come from the base RSVP form.
	 *
	 * @since 6.11.0
	 *
	 * @param string        $hook_name        The template hook name.
	 * @param string        $entry_point_name The entry point name.
	 * @param Base_Template $template         The template instance.
	 * @param int|string    $attendee_id      The attendee ID or JS placeholder string.
	 */
	public function render_entry_point_fields( string $hook_name, string $entry_point_name, Base_Template $template, $attendee_id ): void {
		$rsvp    = $template->get( 'rsvp' );
		$post_id = $template->get( 'post_id' );

		if ( ! $rsvp instanceof Ticket_Object ) {
			return;
		}

		if ( RSVP_Constants::TC_RSVP_TYPE !== $rsvp->type ) {
			return;
		}

		// For clone template guests, render IAC name/email fields before ARF fields.
		// The main guest already has name/email from the base RSVP form.
		if ( is_string( $attendee_id ) ) {
			$this->render_iac_fields( $rsvp, $attendee_id );
		}

		/** @var Fields $fields */
		$fields = tribe( 'tickets-plus.attendee-registration.fields' );

		$fields->render( $rsvp, $post_id, $attendee_id );
	}

	/**
	 * Render IAC name/email input fields for a clone template guest.
	 *
	 * Only outputs fields when IAC is enabled (allowed or required) on the ticket.
	 * The inputs use the same naming convention as the base RSVP form so the backend
	 * filter_cart_upsert_item_args can extract them consistently.
	 *
	 * @since 6.11.0
	 *
	 * @param Ticket_Object $rsvp        The RSVP ticket object.
	 * @param string        $attendee_id The JS placeholder for attendee index.
	 */
	protected function render_iac_fields( Ticket_Object $rsvp, string $attendee_id ): void {
		/** @var IAC $iac */
		$iac         = tribe( 'tickets-plus.attendee-registration.iac' );
		$iac_setting = $iac->get_iac_setting_for_ticket( $rsvp->ID );

		if ( IAC::NONE_KEY === $iac_setting ) {
			return;
		}

		$required = IAC::REQUIRED_KEY === $iac_setting;

		$this->template->template(
			'iac-fields',
			[
				'ticket_id'   => $rsvp->ID,
				'attendee_id' => $attendee_id,
				'required'    => $required,
			]
		);
	}

	/**
	 * Filter the cart upsert item extra args to inject per-attendee meta data.
	 *
	 * Parses attendee data from the REST request and injects it into the extra_args
	 * with 1-based keys matching the Generate_Attendees expectation.
	 *
	 * @since 6.11.0
	 *
	 * @param array           $extra_args      The extra arguments for the cart item.
	 * @param int             $ticket_id       The ticket ID.
	 * @param int             $quantity        The quantity of tickets.
	 * @param array           $first_attendee  The parsed attendee details.
	 * @param WP_REST_Request $request         The REST API request object.
	 *
	 * @return array Modified extra arguments with attendees data.
	 */
	public function filter_cart_upsert_item_args( array $extra_args, int $ticket_id, int $quantity, array $first_attendee, WP_REST_Request $request ): array {
		$tribe_tickets = $request->get_param( 'tribe_tickets' );

		if ( empty( $tribe_tickets[ $ticket_id ]['attendees'] ) || ! is_array( $tribe_tickets[ $ticket_id ]['attendees'] ) ) {
			return $extra_args;
		}

		/** @var IAC $iac */
		$iac         = tribe( 'tickets-plus.attendee-registration.iac' );
		$iac_setting = $iac->get_iac_setting_for_ticket( $ticket_id );
		$is_iac      = IAC::NONE_KEY !== $iac_setting;

		$raw_attendees = $tribe_tickets[ $ticket_id ]['attendees'];
		$attendees     = [];

		foreach ( $raw_attendees as $raw_attendee ) {
			if ( ! is_array( $raw_attendee ) ) {
				continue;
			}

			$attendee = [];

			if ( isset( $raw_attendee['meta'] ) && is_array( $raw_attendee['meta'] ) ) {
				$attendee['meta'] = array_map( 'sanitize_text_field', $raw_attendee['meta'] );
			}

			// When IAC is enabled, inject per-attendee name/email into meta using
			// IAC field slugs so the Generate_Attendees pipeline can extract them.
			if ( $is_iac ) {
				if ( isset( $raw_attendee['full_name'] ) ) {
					$attendee['meta'][ $iac->get_iac_ticket_field_slug_for_name() ] = sanitize_text_field( $raw_attendee['full_name'] );
				}

				if ( isset( $raw_attendee['email'] ) ) {
					$attendee['meta'][ $iac->get_iac_ticket_field_slug_for_email() ] = sanitize_email( $raw_attendee['email'] );
				}
			}

			$attendees[] = $attendee;
		}

		if ( ! empty( $attendees ) ) {
			// Re-index to 1-based keys to match Generate_Attendees expectation.
			$one_based = [];
			foreach ( $attendees as $index => $attendee ) {
				$one_based[ $index + 1 ] = $attendee;
			}
			$extra_args['attendees'] = $one_based;
		}

		return $extra_args;
	}
}
