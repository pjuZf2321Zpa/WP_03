<?php

namespace WPAICG\Lib\Utils;

if (!defined('ABSPATH')) {
    exit;
}

class AIPKit_OpenAI_File_Search_Chunking
{
    public static function register_hooks(): void
    {
        add_filter('aipkit_openai_file_search_chunking_strategy', [self::class, 'filter_chunking_strategy'], 10, 2);
    }

    /**
     * @param mixed $strategy
     * @param array<string, mixed> $context
     * @return array<string, mixed>|null
     */
    public static function filter_chunking_strategy($strategy, array $context = []): ?array
    {
        unset($context);

        if (is_array($strategy)) {
            return $strategy;
        }

        if (!class_exists('\\WPAICG\\aipkit_dashboard') || !\WPAICG\aipkit_dashboard::is_pro_plan()) {
            return null;
        }

        $settings = get_option('aipkit_training_general_settings', []);
        $settings = is_array($settings) ? $settings : [];
        $mode = isset($settings['openai_file_search_chunking_mode'])
            ? sanitize_key((string) $settings['openai_file_search_chunking_mode'])
            : 'auto';

        if ($mode !== 'custom') {
            return null;
        }

        $max_tokens = isset($settings['openai_file_search_max_chunk_size_tokens'])
            ? (int) $settings['openai_file_search_max_chunk_size_tokens']
            : 800;
        $max_tokens = min(4096, max(100, $max_tokens));

        $overlap_tokens = isset($settings['openai_file_search_chunk_overlap_tokens'])
            ? (int) $settings['openai_file_search_chunk_overlap_tokens']
            : 400;
        $overlap_tokens = min((int) floor($max_tokens / 2), max(0, $overlap_tokens));

        return [
            'type' => 'static',
            'static' => [
                'max_chunk_size_tokens' => $max_tokens,
                'chunk_overlap_tokens' => $overlap_tokens,
            ],
        ];
    }
}
