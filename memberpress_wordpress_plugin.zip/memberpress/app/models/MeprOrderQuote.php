<?php

defined('ABSPATH') || exit;

/**
 * The priced basket for one checkout state.
 *
 * A quote is computed once, through the engine that will charge it.
 * Every pre-charge surface reads it: the invoice lines and total, the
 * Payment Element amount, the PayPal and Square amounts, and the hidden
 * transaction-amount field. At submission its lines persist onto the
 * order's stored transactions, so the books carry the charged truth
 * from birth. Its lines always sum to its totals; the constructor
 * enforces that, because a quote whose parts disagree with its whole is
 * a construction bug, never valid data.
 *
 * A plain immutable value object: it carries no persistence, and its
 * only behavior is the array snapshot pair the preview cache stores
 * and rehydrates.
 */
final class MeprOrderQuote
{
    /**
     * The Stripe automatic-tax engine: every figure copies a Stripe
     * pricing surface's response (a tax calculation or an invoice
     * preview).
     *
     * @var string
     */
    const ENGINE_STRIPE_AUTOMATIC = 'stripe-automatic';

    /**
     * The rate-based engine: the blended math every non-Stripe tax
     * provider uses, wrapped into the quote shape byte-identically.
     *
     * @var string
     */
    const ENGINE_RATE_BASED = 'rate-based';

    /**
     * The preview stage: the quote prices a checkout state that has no
     * stored transactions yet (product-positional line references).
     *
     * @var string
     */
    const STAGE_PREVIEW = 'preview';

    /**
     * The submit stage: the quote prices the submitted order with
     * persistent line references. The stage governs the reference
     * scheme and the pricing policy (fresh, fail-closed), not write
     * permission: a quote's lines store whatever saved rows they are
     * applied to, at either stage.
     *
     * @var string
     */
    const STAGE_SUBMIT = 'submit';

    /**
     * The engine that priced the quote, one of the ENGINE_* constants.
     *
     * @var string
     */
    public string $engine;

    /**
     * The quote stage, one of the STAGE_* constants.
     *
     * @var string
     */
    public string $stage;

    /**
     * The Stripe calculation id behind the quote (stripe-automatic
     * engine on the calculations surface only; empty otherwise, and for
     * invoice-preview quotes, whose previews carry no durable id).
     *
     * @var string
     */
    public string $calculation_id;

    /**
     * The basket fingerprint (line references, nets, coupon, tax mode);
     * a cache key, kept for verification.
     *
     * @var string
     */
    public string $basket_fingerprint;

    /**
     * The customer fingerprint (the pricing address and the VAT tax ID,
     * the inputs that make one customer's tax situation differ from
     * another's); a cache key, kept for verification.
     *
     * @var string
     */
    public string $customer_fingerprint;

    /**
     * The priced lines, keyed by line reference in insertion order.
     *
     * @var array<string,MeprOrderQuoteLine>
     */
    public array $lines;

    /**
     * The quote totals: net, tax, and total.
     *
     * @var array{net:float,tax:float,total:float}
     */
    public array $totals;

    /**
     * Constructor for the MeprOrderQuote class.
     *
     * @param  string               $engine               The engine, one of the ENGINE_* constants.
     * @param  string               $stage                The stage, one of the STAGE_* constants.
     * @param  string               $calculation_id       The Stripe calculation id ('' when none).
     * @param  string               $basket_fingerprint   The basket fingerprint.
     * @param  string               $customer_fingerprint The customer fingerprint.
     * @param  MeprOrderQuoteLine[] $lines                The priced lines.
     * @param  array                $totals               The totals (net, tax, total).
     * @throws InvalidArgumentException When the engine or stage is unknown, or the lines do not sum to the totals.
     */
    public function __construct(
        string $engine,
        string $stage,
        string $calculation_id,
        string $basket_fingerprint,
        string $customer_fingerprint,
        array $lines,
        array $totals
    ) {
        if (!in_array($engine, [self::ENGINE_STRIPE_AUTOMATIC, self::ENGINE_RATE_BASED], true)) {
            throw new InvalidArgumentException("Unknown quote engine: $engine"); // phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped -- internal identifier, not rendered output.
        }

        if (!in_array($stage, [self::STAGE_PREVIEW, self::STAGE_SUBMIT], true)) {
            throw new InvalidArgumentException("Unknown quote stage: $stage"); // phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped -- internal identifier, not rendered output.
        }

        $net   = 0.00;
        $tax   = 0.00;
        $keyed = [];

        foreach ($lines as $line) {
            if (isset($keyed[$line->reference])) {
                throw new InvalidArgumentException("The quote has a duplicate line reference: $line->reference"); // phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped -- internal identifier, not rendered output.
            }

            $keyed[$line->reference] = $line;

            $net += $line->amount;
            $tax += $line->tax_amount;
        }

        if (
            round($net, 2) !== round((float) $totals['net'], 2)
            || round($tax, 2) !== round((float) $totals['tax'], 2)
            || round($net + $tax, 2) !== round((float) $totals['total'], 2)
        ) {
            throw new InvalidArgumentException('The quote lines do not sum to its totals.');
        }

        $this->engine               = $engine;
        $this->stage                = $stage;
        $this->calculation_id       = $calculation_id;
        $this->basket_fingerprint   = $basket_fingerprint;
        $this->customer_fingerprint = $customer_fingerprint;
        $this->lines                = $keyed;
        $this->totals               = $totals;
    }

    /**
     * The quote as a plain array snapshot (the cached form).
     *
     * @return array<string,mixed>
     */
    public function to_array(): array
    {
        $lines = [];

        foreach ($this->lines as $line) {
            $lines[] = $line->to_array();
        }

        return [
            'engine'               => $this->engine,
            'stage'                => $this->stage,
            'calculation_id'       => $this->calculation_id,
            'basket_fingerprint'   => $this->basket_fingerprint,
            'customer_fingerprint' => $this->customer_fingerprint,
            'lines'                => $lines,
            'totals'               => $this->totals,
        ];
    }

    /**
     * Rebuild a quote from an array snapshot, or null when the payload
     * does not match the expected shape.
     *
     * Every malformed payload is a null (the caller treats it as a
     * cache miss), never a fatal: the shape checks run before
     * construction, and the constructor's own invariants (engine,
     * stage, sums, duplicates) run on rehydration, so a snapshot that
     * cannot satisfy them cannot become a quote.
     *
     * @param  array<string,mixed> $data The snapshot.
     * @return self|null
     */
    public static function from_array(array $data): ?self
    {
        foreach (['engine', 'stage', 'calculation_id', 'basket_fingerprint', 'customer_fingerprint'] as $key) {
            if (!is_string($data[$key] ?? null)) {
                return null;
            }
        }

        if (!is_array($data['lines'] ?? null) || !is_array($data['totals'] ?? null)) {
            return null;
        }

        $totals = $data['totals'];

        foreach (['net', 'tax', 'total'] as $key) {
            if (!is_float($totals[$key] ?? null) && !is_int($totals[$key] ?? null)) {
                return null;
            }
        }

        $lines = [];

        foreach ($data['lines'] as $line_data) {
            $line = is_array($line_data) ? MeprOrderQuoteLine::from_array($line_data) : null;

            if (!$line instanceof MeprOrderQuoteLine) {
                return null;
            }

            $lines[] = $line;
        }

        try {
            return new self(
                $data['engine'],
                $data['stage'],
                $data['calculation_id'],
                $data['basket_fingerprint'],
                $data['customer_fingerprint'],
                $lines,
                $totals
            );
        } catch (InvalidArgumentException $e) {
            return null;
        }
    }
}
