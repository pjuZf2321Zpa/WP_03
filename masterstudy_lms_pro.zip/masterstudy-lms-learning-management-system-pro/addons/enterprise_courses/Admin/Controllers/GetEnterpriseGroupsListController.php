<?php

namespace MasterStudy\Lms\Pro\addons\enterprise_courses\Admin\Controllers;

use MasterStudy\Lms\Http\WpResponseFactory;
use MasterStudy\Lms\Pro\addons\enterprise_courses\Admin\Repositories\EnterpriseGroupsRepository;
use MasterStudy\Lms\Validation\Validator;
use WP_REST_Request;
use WP_REST_Response;

final class GetEnterpriseGroupsListController {
	public function __invoke( WP_REST_Request $request ): WP_REST_Response {
		$validator = new Validator(
			$request->get_query_params(),
			array(
				'page'     => 'nullable|integer',
				'per_page' => 'nullable|integer',
				'search'   => 'nullable|string',
			)
		);

		if ( $validator->fails() ) {
			return WpResponseFactory::validation_failed( $validator->get_errors_array() );
		}

		$result = ( new EnterpriseGroupsRepository() )->get_list( $validator->get_validated() );

		return new WP_REST_Response(
			array(
				'groups' => $result['items'],
				'total'  => $result['total'],
				'pages'  => $result['pages'],
			)
		);
	}
}
