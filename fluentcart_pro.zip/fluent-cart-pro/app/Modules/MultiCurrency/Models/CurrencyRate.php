<?php

namespace FluentCartPro\App\Modules\MultiCurrency\Models;

use FluentCart\App\Models\Model;

/**
 * One exchange rate: units of `quote` per 1 unit of `base`, from `source`,
 * active from `effective_at`. Rows are never updated — a new rate is a new
 * row (fluent-cart dev-docs/multi-currency/08-exchange-rates.md, "Meaning and storage").
 */
class CurrencyRate extends Model
{
    protected $table = 'fct_currency_rates';

    protected $fillable = [
        'base',
        'quote',
        'rate',
        'source',
        'effective_at',
        'created_by',
    ];

    protected $casts = [
        'created_by' => 'integer',
    ];
}
