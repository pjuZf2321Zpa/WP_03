<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Core\Util\Route;
use BitApps\IntegrationsPro\Triggers\BbPress\BbPressController;

Route::get('bb_press/get', [BbPressController::class, 'getAllTasks']);
