<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Core\Util\Route;
use BitApps\IntegrationsPro\Triggers\BookingsAndAppointmentsForWoocommerce\BookingsAndAppointmentsForWoocommerceController;

Route::get('bookings_and_appointments_for_woocommerce/get', [BookingsAndAppointmentsForWoocommerceController::class, 'getAllTasks']);
