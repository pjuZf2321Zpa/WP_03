<?php
/** Paid controls for the AI Form editor, shared by its panels. */
if (!defined('ABSPATH')) {
    exit;
}

function aipkit_render_paid_ai_form_editor_panel(string $aipkit_panel, string $connected_apps_manage_url = ''): void
{
    if (!class_exists('\\WPAICG\\aipkit_dashboard') || !\WPAICG\aipkit_dashboard::is_pro_plan()) {
        return;
    }

    switch ($aipkit_panel) {
        case 'upload-elements':
            ?>
                                        <div class="aipkit_form_element_item" data-element-type="file-upload" draggable="true">
                                            <span class="dashicons dashicons-media-default"></span>
                                            <?php esc_html_e('File Upload', 'gpt3-ai-content-generator'); ?>
                                        </div>
                                        <div class="aipkit_form_element_item" data-element-type="image-upload" draggable="true">
                                            <span class="dashicons dashicons-format-image"></span>
                                            <?php esc_html_e('Image Upload', 'gpt3-ai-content-generator'); ?>
                                        </div>
                                    <?php
            break;
        case 'conversation':
            ?>
        <div class="aipkit_popover_option_row">
            <div class="aipkit_popover_option_main">
                <span class="aipkit_popover_option_label">
                    <?php esc_html_e('Enable Multi-Step', 'gpt3-ai-content-generator'); ?>
                </span>
                <div class="aipkit_popover_option_actions">
                    <label class="aipkit_switch">
                        <input
                            type="checkbox"
                            id="aipkit_ai_form_conversation_enabled"
                            class="aipkit_ai_form_conversation_enabled_toggle"
                            value="1"
                        >
                        <span class="aipkit_switch_slider"></span>
                    </label>
                </div>
            </div>
        </div>
        <div class="aipkit_ai_form_conversation_ui_settings">
            <div class="aipkit_popover_option_row">
                <div class="aipkit_popover_option_main aipkit_popover_option_main--stacked">
                    <p class="aipkit_form-help"><?php esc_html_e('Use the chat action in each layout toolbar to configure its step.', 'gpt3-ai-content-generator'); ?></p>
                </div>
            </div>
            <div class="aipkit_popover_option_row">
                <div class="aipkit_popover_option_main aipkit_popover_option_main--stacked">
                    <label class="aipkit_popover_option_label" for="aipkit_ai_form_conversation_ui_preset"><?php esc_html_e('Display Progress', 'gpt3-ai-content-generator'); ?></label>
                    <select id="aipkit_ai_form_conversation_ui_preset" name="conversation_ui_preset" class="aipkit_popover_option_select">
                        <option value="full"><?php esc_html_e('Full', 'gpt3-ai-content-generator'); ?></option>
                        <option value="compact"><?php esc_html_e('Compact', 'gpt3-ai-content-generator'); ?></option>
                        <option value="minimal"><?php esc_html_e('Minimal', 'gpt3-ai-content-generator'); ?></option>
                        <option value="none"><?php esc_html_e('None', 'gpt3-ai-content-generator'); ?></option>
                    </select>
                    <p class="aipkit_form-help"><?php esc_html_e('Choose how much step info to show.', 'gpt3-ai-content-generator'); ?></p>
                </div>
            </div>
        </div>
    <?php
            break;
        case 'labels':
            ?>
        <section
            class="aipkit_ai_form_labels_group aipkit_ai_form_labels_group--multistep"
            data-aipkit-ai-form-labels-group="multistep"
            aria-labelledby="aipkit_ai_form_labels_multistep_title"
            hidden
        >
            <h6 class="aipkit_ai_form_labels_group_title" id="aipkit_ai_form_labels_multistep_title">
                <?php esc_html_e('Multi-Step navigation', 'gpt3-ai-content-generator'); ?>
            </h6>
            <div class="aipkit_ai_form_labels_group_fields">
                <div class="aipkit_popover_option_row aipkit_ai_form_label_field aipkit_ai_form_label_field--inline">
                    <div class="aipkit_popover_option_main">
                        <label class="aipkit_popover_option_label" for="aif_label_conversation_back_button"><?php esc_html_e('Back', 'gpt3-ai-content-generator'); ?></label>
                        <input type="text" id="aif_label_conversation_back_button" name="labels[conversation_back_button]" class="aipkit_popover_option_input" placeholder="<?php esc_attr_e('Back', 'gpt3-ai-content-generator'); ?>">
                    </div>
                </div>
                <div class="aipkit_popover_option_row aipkit_ai_form_label_field aipkit_ai_form_label_field--inline">
                    <div class="aipkit_popover_option_main">
                        <label class="aipkit_popover_option_label" for="aif_label_conversation_next_button"><?php esc_html_e('Next', 'gpt3-ai-content-generator'); ?></label>
                        <input type="text" id="aif_label_conversation_next_button" name="labels[conversation_next_button]" class="aipkit_popover_option_input" placeholder="<?php esc_attr_e('Next', 'gpt3-ai-content-generator'); ?>">
                    </div>
                </div>
                <div class="aipkit_popover_option_row aipkit_ai_form_label_field aipkit_ai_form_label_field--stacked">
                    <div class="aipkit_popover_option_main">
                        <label class="aipkit_popover_option_label" for="aif_label_conversation_step_title"><?php esc_html_e('Step title', 'gpt3-ai-content-generator'); ?></label>
                        <input type="text" id="aif_label_conversation_step_title" name="labels[conversation_step_title]" class="aipkit_popover_option_input aipkit_ai_form_label_input--token" placeholder="<?php esc_attr_e('Step {number}', 'gpt3-ai-content-generator'); ?>">
                    </div>
                </div>
                <div class="aipkit_popover_option_row aipkit_ai_form_label_field aipkit_ai_form_label_field--stacked">
                    <div class="aipkit_popover_option_main">
                        <label class="aipkit_popover_option_label" for="aif_label_conversation_step_progress"><?php esc_html_e('Step progress', 'gpt3-ai-content-generator'); ?></label>
                        <input type="text" id="aif_label_conversation_step_progress" name="labels[conversation_step_progress]" class="aipkit_popover_option_input aipkit_ai_form_label_input--token" placeholder="<?php esc_attr_e('Step {current} of {total}', 'gpt3-ai-content-generator'); ?>">
                    </div>
                </div>
            </div>
        </section>
    

        <section class="aipkit_ai_form_labels_group" aria-labelledby="aipkit_ai_form_labels_messages_title">
            <h6 class="aipkit_ai_form_labels_group_title" id="aipkit_ai_form_labels_messages_title">
                <?php esc_html_e('Messages', 'gpt3-ai-content-generator'); ?>
            </h6>
            <div class="aipkit_ai_form_labels_group_fields">
                <div class="aipkit_popover_option_row aipkit_ai_form_label_field aipkit_ai_form_label_field--stacked">
                    <div class="aipkit_popover_option_main">
                        <label class="aipkit_popover_option_label" for="aif_label_conversation_validation_message"><?php esc_html_e('Validation msg', 'gpt3-ai-content-generator'); ?></label>
                        <input type="text" id="aif_label_conversation_validation_message" name="labels[conversation_validation_message]" class="aipkit_popover_option_input" placeholder="<?php esc_attr_e('Please complete this step before continuing.', 'gpt3-ai-content-generator'); ?>">
                    </div>
                </div>
            </div>
        </section>
    <?php
            break;
        case 'connected-apps-summary':
            ?>
                    <span
                        class="aipkit_ai_form_connected_apps_summary"
                        data-aipkit-ai-form-connected-apps-summary
                        data-default-summary=""
                    ></span>
                <?php
            break;
        case 'connected-apps':
            ?>
                <div class="aipkit_chatbot_connected_apps_actions aipkit_ai_form_connected_apps_actions">
                    <a
                        href="<?php echo esc_url($connected_apps_manage_url); ?>"
                        class="aipkit_btn"
                        data-aipkit-ai-form-connected-apps-manage
                    >
                        <?php esc_html_e('Manage', 'gpt3-ai-content-generator'); ?>
                    </a>
                </div>
                <details class="aipkit_ai_form_inline_details aipkit_ai_form_connected_apps_details">
                    <summary class="aipkit_ai_form_inline_details_summary">
                        <span><?php esc_html_e('Recipes', 'gpt3-ai-content-generator'); ?></span>
                        <span class="dashicons dashicons-arrow-down-alt2" aria-hidden="true"></span>
                    </summary>
                    <div class="aipkit_ai_form_inline_details_body">
                        <div class="aipkit_chatbot_connected_apps_list" data-aipkit-ai-form-connected-apps-list>
                            
                        </div>
                        <p class="aipkit_chatbot_connected_apps_empty" data-aipkit-ai-form-connected-apps-empty>
                            <?php esc_html_e('Save this form to connect apps.', 'gpt3-ai-content-generator'); ?>
                        </p>
                    </div>
                </details>
            <?php
            break;
    }
}
