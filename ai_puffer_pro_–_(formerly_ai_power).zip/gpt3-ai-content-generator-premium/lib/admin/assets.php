<?php

namespace WPAICG\Lib\Admin\Assets;

use WPAICG\Admin\Assets\DashboardAssets;
use WPAICG\Includes\AIPKit_Shared_Assets_Manager;

if (! defined('ABSPATH')) {
    exit;
}

abstract class AIPKit_Lib_Admin_Asset_Base
{
    protected $version;

    public function register_hooks(): void
    {
        add_action('admin_enqueue_scripts', [$this, 'enqueue_assets']);
    }

    public function __construct()
    {
        $this->version = defined('WPAICG_VERSION') ? (string) WPAICG_VERSION : '1.0.0';
    }

    protected function is_aipkit_page($screen = null, bool $include_toplevel = false): bool
    {
        $screen = $screen ?: get_current_screen();

        if (! $screen || empty($screen->id)) {
            return false;
        }

        if (strpos($screen->id, 'page_wpaicg') !== false) {
            return true;
        }

        return $include_toplevel && strpos($screen->id, 'toplevel_page_wpaicg') !== false;
    }

    protected function asset_version(string $relative_path): string
    {
        $full_path = WPAICG_PLUGIN_DIR . ltrim($relative_path, '/');
        $mtime = file_exists($full_path) ? filemtime($full_path) : false;

        return $mtime ? (string) $mtime : $this->version;
    }

    protected function ensure_vendor_assets(): void
    {
        if (class_exists(AIPKit_Shared_Assets_Manager::class)) {
            AIPKit_Shared_Assets_Manager::register($this->version);
        }
    }

    protected function register_admin_main_style(): void
    {
        if (! wp_style_is('aipkit-admin-main-css', 'registered')) {
            wp_register_style(
                'aipkit-admin-main-css',
                WPAICG_PLUGIN_URL . 'dist/css/admin-main.bundle.css',
                ['dashicons', 'aipkit-shared-model-selector'],
                $this->asset_version('dist/css/admin-main.bundle.css')
            );
        }
    }

    protected function enqueue_admin_main_style(): void
    {
        $this->register_admin_main_style();

        if (! wp_style_is('aipkit-admin-main-css', 'enqueued')) {
            wp_enqueue_style('aipkit-admin-main-css');
        }
    }

    protected function register_admin_main_script(): void
    {
        $this->ensure_vendor_assets();

        if (! wp_script_is('aipkit-admin-main', 'registered')) {
            wp_register_script(
                'aipkit-admin-main',
                WPAICG_PLUGIN_URL . 'dist/js/admin-main.bundle.js',
                ['wp-i18n', 'aipkit_markdown-it', 'aipkit-shared-model-selector'],
                $this->asset_version('dist/js/admin-main.bundle.js'),
                true
            );
        }
    }

    protected function enqueue_admin_main_script(): void
    {
        $this->register_admin_main_script();

        if (! wp_script_is('aipkit-admin-main', 'enqueued')) {
            wp_enqueue_script('aipkit-admin-main');
            wp_set_script_translations('aipkit-admin-main', 'gpt3-ai-content-generator', WPAICG_PLUGIN_DIR . 'languages');
        }
    }

    protected function ensure_dashboard_core_data(): void
    {
        if (class_exists(DashboardAssets::class) && method_exists(DashboardAssets::class, 'localize_core_data')) {
            DashboardAssets::localize_core_data($this->version);
        }
    }

    protected function register_lib_main_script(): void
    {
        $this->ensure_vendor_assets();
        $this->register_admin_main_script();

        if (! wp_script_is('aipkit-lib-main', 'registered')) {
            wp_register_script(
                'aipkit-lib-main',
                WPAICG_PLUGIN_URL . 'dist/js/lib-main.bundle.js',
                ['wp-i18n', 'aipkit-admin-main', 'aipkit_markdown-it'],
                $this->asset_version('dist/js/lib-main.bundle.js'),
                true
            );
        }
    }

    protected function enqueue_lib_main_script(): void
    {
        $this->enqueue_admin_main_script();
        $this->ensure_dashboard_core_data();
        $this->register_lib_main_script();

        if (! wp_script_is('aipkit-lib-main', 'enqueued')) {
            wp_enqueue_script('aipkit-lib-main');
            wp_set_script_translations('aipkit-lib-main', 'gpt3-ai-content-generator', WPAICG_PLUGIN_DIR . 'languages');
        }
    }

    protected function register_style_bundle(string $handle, string $file, array $deps = []): void
    {
        if (! wp_style_is($handle, 'registered')) {
            wp_register_style(
                $handle,
                WPAICG_PLUGIN_URL . 'dist/css/' . ltrim($file, '/'),
                $deps,
                $this->asset_version('dist/css/' . ltrim($file, '/'))
            );
        }
    }

    protected function is_script_localized(string $handle, string $object_name): bool
    {
        $data = wp_scripts()->get_data($handle, 'data');

        return is_string($data) && strpos($data, "var {$object_name} =") !== false;
    }
}

class AIPKit_Content_Writer_Pro_Assets extends AIPKit_Lib_Admin_Asset_Base
{
    public function register_hooks(): void
    {
        parent::register_hooks();
        // Shared module styles register at priority 10. Resolve their order afterward.
        add_action('admin_enqueue_scripts', [$this, 'enqueue_smart_seo_styles'], 20);
    }

    public function enqueue_smart_seo_styles($hook_suffix): void
    {
        if (!$this->is_aipkit_page(null, true)) {
            return;
        }

        $this->enqueue_admin_main_style();
        $deps = ['aipkit-admin-main-css'];
        if (wp_style_is('aipkit-admin-autogpt-css', 'registered')) {
            $deps[] = 'aipkit-admin-autogpt-css';
        }
        $this->register_style_bundle(
            'aipkit-lib-smart-seo-admin-css',
            'lib-smart-seo-admin.bundle.css',
            $deps
        );
        if (!wp_style_is('aipkit-lib-smart-seo-admin-css', 'enqueued')) {
            wp_enqueue_style('aipkit-lib-smart-seo-admin-css');
        }
    }

    public function enqueue_assets($hook_suffix): void
    {
        $screen = get_current_screen();

        if (! $this->is_aipkit_page($screen, true)) {
            return;
        }

        $this->enqueue_lib_main_script();

        if ($this->is_script_localized('aipkit-lib-main', 'aipkit_cw_pro_config')) {
            return;
        }

        wp_localize_script('aipkit-lib-main', 'aipkit_cw_pro_config', [
            'gsheets_text' => [
                'verifying' => __('Verifying...', 'gpt3-ai-content-generator'),
                'accessible' => __('Accessible', 'gpt3-ai-content-generator'),
                'error_prefix' => __('Error:', 'gpt3-ai-content-generator'),
                'invalid_creds' => __('Invalid credentials or sheet not shared.', 'gpt3-ai-content-generator'),
            ],
        ]);
    }
}

class AIPKit_Trigger_Builder_Assets extends AIPKit_Lib_Admin_Asset_Base
{
    public function enqueue_assets($hook_suffix): void
    {
        $screen = get_current_screen();

        if (! $this->is_aipkit_page($screen)) {
            return;
        }

        $this->enqueue_trigger_builder_styles();
        $this->enqueue_lib_main_script();
    }

    private function enqueue_trigger_builder_styles(): void
    {
        $this->enqueue_admin_main_style();
        $this->register_style_bundle(
            'aipkit-lib-triggers-admin-css',
            'lib-triggers-admin.bundle.css',
            ['aipkit-admin-main-css']
        );

        if (! wp_style_is('aipkit-lib-triggers-admin-css', 'enqueued')) {
            wp_enqueue_style('aipkit-lib-triggers-admin-css');
        }
    }
}

class AIPKit_AI_Forms_Pro_Assets extends AIPKit_Lib_Admin_Asset_Base
{
    private function enqueue_admin_styles(): void
    {
        $handle = 'aipkit-lib-ai-forms-admin-css';
        $bundle_file = 'lib-ai-forms-admin.bundle.css';
        $bundle_relative_path = 'dist/css/' . $bundle_file;
        $bundle_full_path = WPAICG_PLUGIN_DIR . $bundle_relative_path;

        if (file_exists($bundle_full_path)) {
            $this->register_style_bundle(
                $handle,
                $bundle_file,
                ['aipkit-admin-main-css']
            );
        } else {
            $relative_path = 'lib/admin/css/ai-forms/base.css';
            $full_path = WPAICG_PLUGIN_DIR . $relative_path;

            if (!file_exists($full_path)) {
                return;
            }

            if (!wp_style_is($handle, 'registered')) {
                wp_register_style(
                    $handle,
                    WPAICG_PLUGIN_URL . $relative_path,
                    ['aipkit-admin-main-css'],
                    $this->asset_version($relative_path)
                );
            }
        }

        if (!wp_style_is($handle, 'enqueued')) {
            wp_enqueue_style($handle);
        }
    }

    public function enqueue_assets($hook_suffix): void
    {
        $screen = get_current_screen();

        if (! $this->is_aipkit_page($screen)) {
            return;
        }

        $this->enqueue_admin_main_style();
        $this->enqueue_admin_styles();
        $this->enqueue_lib_main_script();
    }
}

class AIPKit_Knowledge_Reindex_Assets extends AIPKit_Lib_Admin_Asset_Base
{
    public function register_hooks(): void
    {
        // Apply paid Knowledge Base controls after the shared admin defaults.
        add_action('admin_enqueue_scripts', [$this, 'enqueue_assets'], 20);
    }

    public function enqueue_assets($hook_suffix): void
    {
        $screen = get_current_screen();
        if (!$this->is_aipkit_page($screen, true)) {
            return;
        }

        $this->enqueue_admin_main_style();
        $this->enqueue_lib_main_script();
        $this->enqueue_reindex_styles();

        if ($this->is_script_localized('aipkit-lib-main', 'aipkit_knowledge_reindex_config')) {
            return;
        }

        wp_localize_script(
            'aipkit-lib-main',
            'aipkit_knowledge_reindex_config',
            [
                'nonce' => wp_create_nonce('aipkit_knowledge_reindex_nonce'),
                'reindexAction' => 'aipkit_manage_knowledge_reindex_queue',
            ]
        );
    }

    private function enqueue_reindex_styles(): void
    {
        $handle = 'aipkit-lib-knowledge-base-admin-css';
        $bundle_file = 'lib-knowledge-base-admin.bundle.css';
        $bundle_path = 'dist/css/' . $bundle_file;

        if (file_exists(WPAICG_PLUGIN_DIR . $bundle_path)) {
            $this->register_style_bundle($handle, $bundle_file, ['aipkit-admin-main-css']);
        } else {
            $source_path = 'lib/admin/css/knowledge-base/base.css';
            if (!file_exists(WPAICG_PLUGIN_DIR . $source_path)) {
                return;
            }
            wp_register_style(
                $handle,
                WPAICG_PLUGIN_URL . $source_path,
                ['aipkit-admin-main-css'],
                $this->asset_version($source_path)
            );
        }

        if (!wp_style_is($handle, 'enqueued')) {
            wp_enqueue_style($handle);
        }
    }
}

class AIPKit_Usage_Pro_Assets extends AIPKit_Lib_Admin_Asset_Base
{
    public function enqueue_assets($hook_suffix): void
    {
        if (!$this->is_aipkit_page(null, true)) {
            return;
        }

        $this->enqueue_admin_main_style();
        $this->enqueue_lib_main_script();
    }
}
