<?php

/**
 * Sender (sender.net) Pro action handlers.
 *
 * Free fires bit_integrations_sender_* filters; the real REST calls happen here.
 */

namespace BitApps\IntegrationsPro\Actions\Sender;

final class SenderProHelper
{
    public const BASE_URL = 'https://api.sender.net/v2';

    private const DEFAULT_SUBSCRIBER_FIELDS = ['email', 'firstname', 'lastname', 'phone'];

    public static function createOrUpdateSubscriber($default, $fieldData, $integrationDetails)
    {
        $email = $fieldData['email'] ?? '';
        if (empty($email)) {
            return self::error(__('Email is required', 'bit-integrations-pro'));
        }

        if (!is_email($email)) {
            return self::error(__('A valid email address is required', 'bit-integrations-pro'));
        }

        $payload = self::filterEmpty([
            'email'     => $email,
            'firstname' => $fieldData['firstname'] ?? '',
            'lastname'  => $fieldData['lastname'] ?? '',
            'phone'     => $fieldData['phone'] ?? '',
        ]);

        $payload = self::attachGroupsAndFields($payload, $fieldData, $integrationDetails, self::DEFAULT_SUBSCRIBER_FIELDS);
        $payload['trigger_automation'] = self::triggerAutomation($integrationDetails);

        return self::request('POST', '/subscribers', $payload, $integrationDetails, __('Subscriber created or updated successfully', 'bit-integrations-pro'));
    }

    public static function updateSubscriber($default, $fieldData, $integrationDetails)
    {
        $subscriberId = $fieldData['subscriber_id'] ?? '';
        if (empty($subscriberId)) {
            return self::error(__('Subscriber ID is required', 'bit-integrations-pro'));
        }

        $reserved = array_merge(
            ['subscriber_id', 'firstname', 'lastname', 'phone', 'subscriber_status', 'sms_status', 'transactional_email_status'],
            self::DEFAULT_SUBSCRIBER_FIELDS
        );

        $payload = self::filterEmpty([
            'firstname'                  => $fieldData['firstname'] ?? '',
            'lastname'                   => $fieldData['lastname'] ?? '',
            'phone'                      => $fieldData['phone'] ?? '',
            'subscriber_status'          => $fieldData['subscriber_status'] ?? '',
            'sms_status'                 => $fieldData['sms_status'] ?? '',
            'transactional_email_status' => $fieldData['transactional_email_status'] ?? '',
        ]);

        $payload = self::attachGroupsAndFields($payload, $fieldData, $integrationDetails, $reserved);
        $payload['trigger_automation'] = self::triggerAutomation($integrationDetails);

        return self::request('PATCH', '/subscribers/' . rawurlencode($subscriberId), $payload, $integrationDetails, __('Subscriber updated successfully', 'bit-integrations-pro'));
    }

    public static function deleteSubscriber($default, $fieldData, $integrationDetails)
    {
        $emails = self::splitList($fieldData['emails'] ?? '');
        if (empty($emails)) {
            return self::error(__('At least one email is required', 'bit-integrations-pro'));
        }

        return self::request('DELETE', '/subscribers', ['subscribers' => $emails], $integrationDetails, __('Subscriber(s) deleted successfully', 'bit-integrations-pro'));
    }

    public static function removePhoneFromSubscriber($default, $fieldData, $integrationDetails)
    {
        $subscriberId = $fieldData['subscriber_id'] ?? '';
        if (empty($subscriberId)) {
            return self::error(__('Subscriber ID is required', 'bit-integrations-pro'));
        }

        return self::request('DELETE', '/subscribers/' . rawurlencode($subscriberId) . '/remove_phone', null, $integrationDetails, __('Phone removed successfully', 'bit-integrations-pro'));
    }

    public static function addSubscriberToGroup($default, $fieldData, $integrationDetails)
    {
        $groupId = self::groupId($integrationDetails);
        if (empty($groupId)) {
            return self::error(__('Group is required', 'bit-integrations-pro'));
        }

        $emails = self::splitList($fieldData['emails'] ?? '');
        if (empty($emails)) {
            return self::error(__('At least one email is required', 'bit-integrations-pro'));
        }

        $payload = [
            'subscribers'        => $emails,
            'trigger_automation' => self::triggerAutomation($integrationDetails),
        ];

        return self::request('POST', '/subscribers/groups/' . rawurlencode($groupId), $payload, $integrationDetails, __('Subscriber(s) added to group successfully', 'bit-integrations-pro'));
    }

    public static function removeSubscriberFromGroup($default, $fieldData, $integrationDetails)
    {
        $groupId = self::groupId($integrationDetails);
        if (empty($groupId)) {
            return self::error(__('Group is required', 'bit-integrations-pro'));
        }

        $emails = self::splitList($fieldData['emails'] ?? '');
        if (empty($emails)) {
            return self::error(__('At least one email is required', 'bit-integrations-pro'));
        }

        return self::request('DELETE', '/subscribers/groups/' . rawurlencode($groupId), ['subscribers' => $emails], $integrationDetails, __('Subscriber(s) removed from group successfully', 'bit-integrations-pro'));
    }

    public static function createGroup($default, $fieldData, $integrationDetails)
    {
        $title = $fieldData['title'] ?? '';
        if (!\is_string($title) || $title === '') {
            return self::error(__('Group title is required', 'bit-integrations-pro'));
        }

        return self::request('POST', '/groups', ['title' => $title], $integrationDetails, __('Group created successfully', 'bit-integrations-pro'));
    }

    public static function updateGroup($default, $fieldData, $integrationDetails)
    {
        $groupId = self::groupId($integrationDetails);
        if (empty($groupId)) {
            return self::error(__('Group is required', 'bit-integrations-pro'));
        }

        $title = $fieldData['title'] ?? '';
        if (!\is_string($title) || $title === '') {
            return self::error(__('Group title is required', 'bit-integrations-pro'));
        }

        return self::request('PATCH', '/groups/' . rawurlencode($groupId), ['title' => $title], $integrationDetails, __('Group updated successfully', 'bit-integrations-pro'));
    }

    public static function deleteGroup($default, $fieldData, $integrationDetails)
    {
        $groupId = self::groupId($integrationDetails);
        if (empty($groupId)) {
            return self::error(__('Group is required', 'bit-integrations-pro'));
        }

        return self::request('DELETE', '/groups/' . rawurlencode($groupId), null, $integrationDetails, __('Group deleted successfully', 'bit-integrations-pro'));
    }

    private static function request($method, $path, $body, $integrationDetails, $successMessage)
    {
        $token = $integrationDetails->api_token ?? '';
        if (empty($token)) {
            return self::error(__('Sender API token is required', 'bit-integrations-pro'));
        }

        $httpHelper = bit_integrations_get_class('Core\\Util\\HttpHelper');

        $headers = [
            'Authorization' => 'Bearer ' . $token,
            'Accept'        => 'application/json',
            'Content-Type'  => 'application/json',
        ];

        $response = $httpHelper::request(
            self::BASE_URL . $path,
            $method,
            $body === null ? null : wp_json_encode($body),
            $headers
        );

        if (is_wp_error($response)) {
            return [
                'success' => false,
                'message' => $response->get_error_message(),
                'data'    => $response,
            ];
        }

        $code = $httpHelper::$responseCode;

        if ($code >= 200 && $code < 300) {
            return [
                'success' => true,
                'message' => $successMessage,
                'data'    => $response,
            ];
        }

        $apiMessage = '';
        if (\is_object($response) && isset($response->message) && \is_string($response->message)) {
            $apiMessage = $response->message;
        } elseif (\is_string($response) && $response !== '') {
            $apiMessage = $response;
        }

        return [
            'success' => false,
            // translators: %d: HTTP status code returned by the Sender API
            'message' => $apiMessage !== '' ? $apiMessage : wp_sprintf(__('Sender request failed (HTTP %d)', 'bit-integrations-pro'), (int) $code),
            'data'    => $response,
        ];
    }

    private static function attachGroupsAndFields(array $payload, $fieldData, $integrationDetails, array $reserved)
    {
        $groups = self::groupIds($integrationDetails);
        if (!empty($groups)) {
            $payload['groups'] = $groups;
        }

        $fields = self::customFields($fieldData, $reserved);
        if (!empty($fields)) {
            $payload['fields'] = $fields;
        }

        return $payload;
    }

    private static function customFields($fieldData, array $reserved)
    {
        $custom = [];
        foreach ($fieldData as $key => $value) {
            if ($value === '' || $value === null || \in_array($key, $reserved, true)) {
                continue;
            }

            // Custom-field keys are personalization tokens ({$email}); strip token punctuation
            // before matching the default subscriber fields, which are sent top-level not inside `fields`.
            $slug = strtolower(preg_replace('/[{}$\s]/', '', (string) $key));
            if (\in_array($slug, self::DEFAULT_SUBSCRIBER_FIELDS, true)) {
                continue;
            }

            $custom[$key] = $value;
        }

        return $custom;
    }

    private static function groupIds($integrationDetails)
    {
        $groups = $integrationDetails->groups ?? [];

        if (\is_string($groups)) {
            $groups = explode(',', $groups);
        }

        return array_values(array_filter(array_map('trim', (array) $groups), static function ($value) {
            return $value !== '';
        }));
    }

    private static function groupId($integrationDetails)
    {
        $groupId = $integrationDetails->groupId ?? '';

        return \is_array($groupId) ? reset($groupId) : trim((string) $groupId);
    }

    private static function triggerAutomation($integrationDetails)
    {
        // New location: utilities live under conf.actions; fall back to the legacy top-level flag for already-saved flows.
        if (isset($integrationDetails->actions) && !empty($integrationDetails->actions->trigger_automation)) {
            return true;
        }

        return !empty($integrationDetails->trigger_automation);
    }

    private static function splitList($value)
    {
        if (\is_array($value)) {
            $items = $value;
        } else {
            $items = explode(',', (string) $value);
        }

        return array_values(array_filter(array_map('trim', $items), static function ($item) {
            return $item !== '';
        }));
    }

    private static function filterEmpty(array $payload)
    {
        return array_filter($payload, static function ($value) {
            if (\is_bool($value) || is_numeric($value)) {
                return true;
            }

            return !empty($value);
        });
    }

    private static function error($message)
    {
        return [
            'success' => false,
            'message' => $message,
        ];
    }
}
