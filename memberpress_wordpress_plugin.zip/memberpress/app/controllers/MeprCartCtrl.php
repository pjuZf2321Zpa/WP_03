<?php

if (!defined('ABSPATH')) {
    die('You are not allowed to call this page directly.');
}

/**
 * Controller for cart AJAX endpoints, shortcodes, guest-merge-on-login, and cron cleanup.
 *
 * All business logic is delegated to MeprCartSessionService.
 * Response format for every success: { cart_count, cart_subtotal, ... }
 * so the mini-cart JS can update itself from any endpoint.
 */
class MeprCartCtrl extends MeprBaseCartCtrl
{
    /**
     * Register hooks for AJAX endpoints, login merge, cron cleanup, and shortcodes.
     *
     * @return void
     */
    public function load_hooks()
    {
        // Cart add.
        add_action('wp_ajax_mepr_cart_add', [$this, 'add_to_cart']);
        add_action('wp_ajax_nopriv_mepr_cart_add', [$this, 'add_to_cart']);

        // Cart remove.
        add_action('wp_ajax_mepr_cart_remove', [$this, 'remove_from_cart']);
        add_action('wp_ajax_nopriv_mepr_cart_remove', [$this, 'remove_from_cart']);

        // Cart update quantity.
        add_action('wp_ajax_mepr_cart_update_qty', [$this, 'update_qty']);
        add_action('wp_ajax_nopriv_mepr_cart_update_qty', [$this, 'update_qty']);

        // Cart get state.
        add_action('wp_ajax_mepr_cart_get_state', [$this, 'get_state']);
        add_action('wp_ajax_nopriv_mepr_cart_get_state', [$this, 'get_state']);

        // Cart undo remove.
        add_action('wp_ajax_mepr_cart_undo_remove', [$this, 'undo_remove']);
        add_action('wp_ajax_nopriv_mepr_cart_undo_remove', [$this, 'undo_remove']);

        // Merge guest cart into user account on login.
        add_action('wp_login', [$this, 'merge_guest_cart_on_login'], 10, 2);

        // Cron cleanup of expired sessions.
        add_action('mepr_cart_session_cleanup', [$this, 'cleanup_expired_sessions']);

        // Schedule daily cleanup cron if not already scheduled.
        MeprUtils::schedule_event_on_init(time(), 'daily', 'mepr_cart_session_cleanup');

        // Shortcodes.
        MeprHooks::add_shortcode('mepr_cart', [$this, 'cart_shortcode']);
        MeprHooks::add_shortcode('mepr_cart_icon', [$this, 'cart_icon_shortcode']);

        // Nav menu integration: auto-append cart icon to the configured nav location.
        add_filter('wp_nav_menu_items', [$this, 'add_cart_icon_to_nav'], 10, 2);

        // Customer account — Orders tab.
        add_action('mepr_account_nav', [$this, 'account_orders_nav']);
        add_action('mepr_account_nav_content', [$this, 'account_orders_content'], 10, 2);
        add_filter('mepr_custom_account_nav_title', [$this, 'account_orders_title'], 10, 2);

        // Register (never enqueue) the cart design-system stylesheets (tokens + shared
        // components) early on both front-end and admin, so any cart stylesheet can
        // declare them as dependencies. Single registration point for the cart surface.
        add_action('wp_enqueue_scripts', ['MeprBaseCartCtrl', 'register_cart_design_styles'], 0);
        add_action('admin_enqueue_scripts', ['MeprBaseCartCtrl', 'register_cart_design_styles'], 0);

        // Enqueue cart CSS/JS on the cart page regardless of ReadyLaunch template setting.
        add_action('wp_enqueue_scripts', [$this, 'enqueue_cart_scripts']);

        // Enqueue account-orders CSS on the account page.
        add_action('wp_enqueue_scripts', [$this, 'enqueue_account_orders_scripts']);

        // AJAX: customer subscription cancellation.
        add_action('wp_ajax_mepr_cancel_cart_subscription', [$this, 'cancel_cart_subscription']);

        // AJAX: customer payment method management.
        add_action('wp_ajax_mepr_delete_payment_method', [$this, 'delete_payment_method']);
        add_action('wp_ajax_mepr_set_default_payment_method', [$this, 'set_default_payment_method']);
    }

    /**
     * AJAX: Add a product to the cart.
     *
     * Expects POST: product_id (int), qty (int, optional, default 1), nonce.
     *
     * @return void Sends JSON response and exits.
     */
    public function add_to_cart()
    {
        if (!check_ajax_referer('mepr_cart_nonce', 'nonce', false)) {
            wp_send_json_error(['message' => __('Security check failed.', 'memberpress')], 403);
        }

        $product_id = absint($_POST['product_id'] ?? 0);
        $qty        = absint($_POST['qty'] ?? 1);

        if ($qty < 1) {
            $qty = 1;
        }

        if ($product_id < 1) {
            wp_send_json_error(['message' => __('Invalid product.', 'memberpress')], 400);
        }

        $mepr_product = MeprProduct::get_one($product_id);
        if (!$mepr_product || !$mepr_product->is_available()) {
            wp_send_json_error(['message' => __('Invalid product.', 'memberpress')], 400);
        }

        $session = MeprCartSessionService::current_session();

        if (!$session) {
            wp_send_json_error(['message' => __('Could not initialize cart session.', 'memberpress')], 500);
        }

        // HOOK: add-ons inject their own item meta from POST.
        $item_meta = (array) MeprHooks::apply_filters('mepr_cart_add_item_meta', [], $_POST);
        $user_id   = is_user_logged_in() ? get_current_user_id() : null;
        $result    = MeprCartSessionService::add_item($session, $product_id, $qty, $user_id, $item_meta);

        if (!$result['success']) {
            wp_send_json_error([
                'message'       => $result['message'],
                'cart_count'    => MeprCartSessionService::item_count($session),
                'cart_subtotal' => MeprCartSessionService::subtotal($session),
            ]);
        }

        $subtotal = MeprCartSessionService::subtotal($session);
        $response = [
            'action'                  => $result['action'] ?? 'added',
            'message'                 => $result['message'] ?? __('Item added to cart.', 'memberpress'),
            'cart_count'              => MeprCartSessionService::item_count($session),
            'cart_subtotal'           => $subtotal,
            'cart_subtotal_formatted' => MeprAppHelper::format_currency_for_json($subtotal),
        ];

        if (!empty($result['replaced_product_id'])) {
            $response['replaced_product_id'] = (int) $result['replaced_product_id'];
        }

        if (!empty($result['replaced_product_name'])) {
            $response['replaced_product_name'] = $result['replaced_product_name'];
        }

        // HOOK: add-ons extend the JSON response.
        $response = (array) MeprHooks::apply_filters('mepr_cart_add_response', $response, $result, $session, $item_meta);

        wp_send_json_success($response);
    }

    /**
     * AJAX: Remove a product from the cart.
     *
     * Expects POST: product_id (int), nonce.
     *
     * @return void Sends JSON response and exits.
     */
    public function remove_from_cart()
    {
        if (!check_ajax_referer('mepr_cart_nonce', 'nonce', false)) {
            wp_send_json_error(['message' => __('Security check failed.', 'memberpress')], 403);
        }

        $product_id = absint($_POST['product_id'] ?? 0);

        if ($product_id < 1) {
            wp_send_json_error(['message' => __('Invalid product.', 'memberpress')], 400);
        }

        $session = MeprCartSessionService::current_session();

        if (!$session) {
            wp_send_json_error(['message' => __('Could not initialize cart session.', 'memberpress')], 500);
        }

        // Validate against the cart, not the product catalog: the item must be in this
        // session. Product availability is deliberately NOT checked — a deleted/trashed
        // product must still be removable (qa#180).
        if (!array_key_exists((string) $product_id, MeprCartSessionService::get_items($session))) {
            wp_send_json_error(['message' => __('This item is not in your cart.', 'memberpress')], 400);
        }

        $result = MeprCartSessionService::remove_item($session, $product_id);

        if (!empty($result['error'])) {
            wp_send_json_error([
                'message'       => $result['error'],
                'cart_count'    => MeprCartSessionService::item_count($session),
                'cart_subtotal' => MeprCartSessionService::subtotal($session),
            ]);
        }

        $subtotal = MeprCartSessionService::subtotal($session);
        $shipping = MeprCartSessionService::shipping_total($session);
        $items    = MeprCartSessionService::get_items($session);

        // Whether any remaining item blocks checkout — the cart JS re-enables the
        // checkout button once the last unavailable/unpurchasable item is removed.
        $has_unavailable = MeprCartSessionService::cart_blocks_checkout($items, $session);

        // Auto-detach an orphaned coupon so it can't linger in the session after cart-page remove.
        $coupon_removed = '';
        $checkout_data  = MeprCartCheckoutService::get_checkout_data($session);
        $coupon_code    = isset($checkout_data['coupon_code']) ? (string) $checkout_data['coupon_code'] : '';
        // Cold static lookup from a stored code — skipped when the coupons
        // feature is stripped; the code just stays inert. mepr:coupon-surface.
        if ($coupon_code !== '' && MeprFeatures::class_usable('MeprCoupon')) {
            $coupon = MeprCoupon::get_one_from_code($coupon_code);
            if ($coupon instanceof MeprCoupon && !MeprCartCheckoutService::coupon_applies_to_any_item($items, $coupon)) {
                $coupon_removed = (string) $coupon->post_title;
                unset($checkout_data['coupon_code']);
                MeprCartCheckoutService::save_checkout_data($session, $checkout_data);
                MeprHooks::do_action('mepr_cart_coupon_removed', $coupon_removed, $session);
            }
        }

        wp_send_json_success([
            'product_id'              => $result['product_id'] ?? $product_id,
            'name'                    => $result['name'] ?? '',
            'qty'                     => $result['qty'] ?? 0,
            'cart_count'              => MeprCartSessionService::item_count($session),
            'cart_subtotal'           => $subtotal,
            'cart_subtotal_formatted' => MeprAppHelper::format_currency_for_json($subtotal),
            'shipping_total'          => $shipping,
            'grand_total'             => $subtotal + $shipping,
            'grand_total_formatted'   => MeprAppHelper::format_currency_for_json($subtotal + $shipping),
            'has_unavailable'         => $has_unavailable,
            'checkout_url'            => MeprOptions::fetch()->checkout_page_url(),
            'coupon_removed'          => $coupon_removed,
        ]);
    }

    /**
     * AJAX: Update the quantity of a product in the cart.
     *
     * Expects POST: product_id (int), qty (int), nonce.
     *
     * @return void Sends JSON response and exits.
     */
    public function update_qty()
    {
        if (!check_ajax_referer('mepr_cart_nonce', 'nonce', false)) {
            wp_send_json_error(['message' => __('Security check failed.', 'memberpress')], 403);
        }

        $product_id = absint($_POST['product_id'] ?? 0);
        $qty        = absint($_POST['qty'] ?? 0);

        if ($product_id < 1) {
            wp_send_json_error(['message' => __('Invalid product.', 'memberpress')], 400);
        }

        $mepr_product = MeprProduct::get_one($product_id);
        if (!$mepr_product || !$mepr_product->is_available()) {
            wp_send_json_error(['message' => __('Invalid product.', 'memberpress')], 400);
        }

        $session = MeprCartSessionService::current_session();

        if (!$session) {
            wp_send_json_error(['message' => __('Could not initialize cart session.', 'memberpress')], 500);
        }

        $result = MeprCartSessionService::update_quantity($session, $product_id, $qty);

        if (!empty($result['error'])) {
            wp_send_json_error([
                'message'       => $result['error'],
                'cart_count'    => MeprCartSessionService::item_count($session),
                'cart_subtotal' => MeprCartSessionService::subtotal($session),
            ]);
        }

        $subtotal = MeprCartSessionService::subtotal($session);
        $shipping = MeprCartSessionService::shipping_total($session);

        wp_send_json_success([
            'line_total'              => $result['line_total'] ?? 0,
            // No Free label: cart/line-item.php renders the cell with $free_str = false, while
            // cart/totals.php keeps the default for the two totals below.
            'line_total_formatted'    => MeprAppHelper::format_currency_for_json($result['line_total'] ?? 0, true, false),
            'cart_count'              => MeprCartSessionService::item_count($session),
            'cart_subtotal'           => $subtotal,
            'cart_subtotal_formatted' => MeprAppHelper::format_currency_for_json($subtotal),
            'shipping_total'          => $shipping,
            'grand_total'             => $subtotal + $shipping,
            'grand_total_formatted'   => MeprAppHelper::format_currency_for_json($subtotal + $shipping),
        ]);
    }

    /**
     * AJAX: Get the full current cart state.
     *
     * No POST params required beyond nonce.
     *
     * @return void Sends JSON response and exits.
     */
    public function get_state()
    {
        if (!check_ajax_referer('mepr_cart_nonce', 'nonce', false)) {
            wp_send_json_error(['message' => __('Security check failed.', 'memberpress')], 403);
        }

        $session = MeprCartSessionService::current_session();

        if (!$session) {
            wp_send_json_success([
                'items'          => [],
                'cart_count'     => 0,
                'subtotal'       => 0,
                'shipping_total' => 0,
            ]);
        }

        $items = MeprCartSessionService::get_items($session);

        // Enrich items with display data.
        $enriched = [];
        foreach ($items as $item) {
            $product    = new MeprProduct(intval($item['product_id']));
            $enriched[] = [
                'product_id' => intval($item['product_id']),
                'name'       => $product->post_title ?? '',
                'qty'        => intval($item['qty'] ?? 1),
                'price'      => floatval($item['price'] ?? 0),
                'line_total' => floatval($item['price'] ?? 0) * intval($item['qty'] ?? 1),
                'type'       => $item['type'] ?? '',
            ];
        }

        wp_send_json_success([
            'items'          => $enriched,
            'cart_count'     => MeprCartSessionService::item_count($session),
            'subtotal'       => MeprCartSessionService::subtotal($session),
            'shipping_total' => MeprCartSessionService::shipping_total($session),
        ]);
    }

    /**
     * AJAX: Re-add a previously removed item (undo remove toast action).
     *
     * Expects POST: product_id (int), qty (int), nonce.
     *
     * @return void Sends JSON response and exits.
     */
    public function undo_remove()
    {
        if (!check_ajax_referer('mepr_cart_nonce', 'nonce', false)) {
            wp_send_json_error(['message' => __('Security check failed.', 'memberpress')], 403);
        }

        $product_id = absint($_POST['product_id'] ?? 0);
        $qty        = absint($_POST['qty'] ?? 1);

        if ($qty < 1) {
            $qty = 1;
        }

        if ($product_id < 1) {
            wp_send_json_error(['message' => __('Invalid product.', 'memberpress')], 400);
        }

        $session = MeprCartSessionService::current_session();

        if (!$session) {
            wp_send_json_error(['message' => __('Could not initialize cart session.', 'memberpress')], 500);
        }

        $user_id = is_user_logged_in() ? get_current_user_id() : null;
        $result  = MeprCartSessionService::add_item($session, $product_id, $qty, $user_id);

        if (!$result['success']) {
            wp_send_json_error([
                'message'       => $result['message'],
                'cart_count'    => MeprCartSessionService::item_count($session),
                'cart_subtotal' => MeprCartSessionService::subtotal($session),
            ]);
        }

        wp_send_json_success([
            'cart_count'    => MeprCartSessionService::item_count($session),
            'cart_subtotal' => MeprCartSessionService::subtotal($session),
        ]);
    }

    /**
     * On user login: merge any pending guest cart into the user's account.
     *
     * Reads the mepr_cart cookie; if a valid guest session is found, merges it
     * into the newly-logged-in user's session and clears the guest cookie.
     *
     * @param  string  $user_login The user's login name.
     * @param  WP_User $user       The WP_User object.
     * @return void
     */
    public function merge_guest_cart_on_login($user_login, $user)
    {
        $cookie_key = isset($_COOKIE['mepr_cart']) ? sanitize_text_field(wp_unslash($_COOKIE['mepr_cart'])) : '';

        if (empty($cookie_key)) {
            return;
        }

        $row = MeprCartSession::find_by_key($cookie_key);

        if (!$row) {
            return;
        }

        $guest_session = new MeprCartSession((array) $row);

        MeprCartSessionService::merge_guest_into_user($guest_session, $user->ID);

        // Reset the static cache so the user's merged session is loaded next request.
        MeprCartSessionService::reset_session_cache();

        // Clear the guest cookie.
        setcookie('mepr_cart', '', time() - HOUR_IN_SECONDS, '/', '', is_ssl(), true);
    }

    /**
     * Cron callback: clean up expired cart sessions from the database.
     *
     * @return void
     */
    public function cleanup_expired_sessions()
    {
        MeprCartSessionService::cleanup_expired();
    }

    /**
     * Shortcode [mepr_cart]: Render the cart page template.
     *
     * Loads the current cart session, builds the product map, calculates totals,
     * and delegates rendering to the readylaunch/cart/page.php view.
     *
     * @param  array $atts Shortcode attributes.
     * @return string
     */
    public function cart_shortcode($atts = [])
    {
        $session = MeprCartSessionService::current_session();
        $items   = $session ? MeprCartSessionService::get_items($session) : [];

        // Build a keyed map of MeprProduct objects for the template.
        $products = [];
        foreach ($items as $product_id => $item) {
            $products[ $product_id ] = new MeprProduct(intval($product_id));
        }

        // Calculate totals.
        $subtotal       = $session ? MeprCartSessionService::subtotal($session) : 0.0;
        $shipping_total = $session ? MeprCartSessionService::shipping_total($session) : 0.0;
        $tax_total      = 0.0; // Tax is calculated at checkout (Phase 3+).
        $grand_total    = $subtotal + $shipping_total;

        // Fetch page URLs from MeprOptions.
        $mepr_options = MeprOptions::fetch();
        $shop_url     = $mepr_options->shop_page_url();
        $checkout_url = $mepr_options->checkout_page_url();

        return MeprView::get_string('/readylaunch/cart/page', compact(
            'session',
            'items',
            'products',
            'subtotal',
            'shipping_total',
            'tax_total',
            'grand_total',
            'shop_url',
            'checkout_url'
        ));
    }

    /**
     * Shortcode [mepr_cart_icon]: Render the mini-cart icon with badge and dropdown.
     *
     * @param  array $atts Shortcode attributes (unused; reserved for future extension).
     * @return string
     */
    public function cart_icon_shortcode($atts = [])
    {
        return MeprView::get_string('/readylaunch/layout/cart-icon');
    }

    /**
     * The wp_nav_menu_items filter: append cart icon to the configured nav menu location.
     *
     * HOOK-02: The target location is filterable via `mepr_cart_icon_nav_location`.
     * Default: 'primary'. Themes can move the icon to any registered nav location.
     *
     * @param  string   $items HTML list items for the nav menu.
     * @param  stdClass $args  Nav menu arguments object.
     * @return string
     */
    public function add_cart_icon_to_nav($items, $args)
    {
        // HOOK-02: Allow themes to customize which nav location gets the cart icon.
        $target_location = MeprHooks::apply_filters('mepr_cart_icon_nav_location', 'primary');

        if (isset($args->theme_location) && $args->theme_location === $target_location) {
            $cart_icon = MeprView::get_string('/readylaunch/layout/cart-icon');
            $items    .= '<li class="menu-item mepr-nav-cart-icon">' . $cart_icon . '</li>';
        }

        return $items;
    }

    // =========================================================================
    /**
     * Enqueue cart JS on the cart page.
     *
     * Fires on wp_enqueue_scripts regardless of whether the ReadyLaunch full-page
     * template is enabled, so the [mepr_cart] shortcode renders correctly in both modes.
     * cart.css is content styling (not RL chrome) so it loads always; when RL is active,
     * add_template_scripts('cart') also fires but WordPress deduplicates by handle.
     *
     * @return void
     */
    public function enqueue_cart_scripts()
    {
        $options = MeprOptions::fetch();
        if (empty($options->cart_page_id) || !is_page($options->cart_page_id)) {
            return;
        }

        wp_enqueue_style('mp-pro-cart', MEPR_CSS_URL . '/cart.css', ['mepr-cart-tokens', 'mepr-ds-components'], MEPR_VERSION);
        wp_enqueue_script('mepr-cartjs', MEPR_JS_URL . '/readylaunch/cart.js', ['jquery'], MEPR_VERSION, true);
        wp_localize_script('mepr-cartjs', 'MeprCart', [
            'ajax_url'     => admin_url('admin-ajax.php'),
            'nonce'        => wp_create_nonce('mepr_cart_nonce'),
            'shop_url'     => $options->shop_page_url(),
            'checkout_url' => $options->checkout_page_url(),
            'i18n'         => [
                'removed'             => __('removed.', 'memberpress'),
                'undo'                => __('Undo?', 'memberpress'),
                'updating'            => __('Updating...', 'memberpress'),
                // Translators: %d: cart item count.
                'item_count_one'      => __('%d item', 'memberpress'),
                // Translators: %d: cart item count.
                'item_count_many'     => __('%d items', 'memberpress'),
                // Translators: %s: coupon code.
                'coupon_auto_removed' => __('Coupon "%s" was removed because it no longer applies to your cart.', 'memberpress'),
                'dismiss'             => __('Dismiss', 'memberpress'),
            ],
        ]);
    }

    // Customer account — Orders tab
    // =========================================================================.

    /**
     * Enqueue account-orders CSS (and payment-methods JS) on the account page.
     *
     * @return void
     */
    public function enqueue_account_orders_scripts()
    {
        global $post;

        if (!MeprUser::is_account_page($post)) {
            return;
        }

        $action = isset($_REQUEST['action']) ? sanitize_text_field(wp_unslash($_REQUEST['action'])) : '';

        if ($action !== 'orders' && $action !== 'payment-methods') {
            return;
        }

        wp_enqueue_style(
            'mepr-account-orders',
            MEPR_CSS_URL . '/readylaunch/cart/account-orders.css',
            ['mepr-cart-tokens', 'mepr-ds-components'],
            MEPR_VERSION
        );

        // Peer: shop.js / admin cart-orders.js — external JS + wp_localize_script.
        if ($action === 'payment-methods') {
            wp_enqueue_script(
                'mepr-account-payment-methods',
                MEPR_JS_URL . '/readylaunch/cart/account-payment-methods.js',
                ['jquery'],
                MEPR_VERSION,
                true
            );
            wp_localize_script('mepr-account-payment-methods', 'MeprAccountPaymentMethods', [
                'ajaxUrl' => admin_url('admin-ajax.php'),
                'i18n'    => [
                    'delete_title'             => __('Delete payment method', 'memberpress'),
                    // Translators: %s: payment method label, e.g. "Visa ending in 4242".
                    'confirm_delete'           => __('Are you sure you want to remove %s?', 'memberpress'),
                    'confirm_delete_fallback'  => __('Are you sure you want to remove this payment method?', 'memberpress'),
                    'cancel'                   => __('Cancel', 'memberpress'),
                    'confirm'                  => __('Confirm', 'memberpress'),
                    'close'                    => __('Close', 'memberpress'),
                    'removing'                 => __('Removing...', 'memberpress'),
                    'delete'                   => __('Delete', 'memberpress'),
                    'saving'                   => __('Saving...', 'memberpress'),
                    'set_default'              => __('Set Default', 'memberpress'),
                    'error'                    => __('An error occurred.', 'memberpress'),
                ],
            ]);
        }
    }

    /**
     * The mepr_account_nav action: output the Orders nav item.
     *
     * @param  WP_User $user The current user.
     * @return void
     */
    public function account_orders_nav($user)
    {
        $mepr_options = MeprOptions::fetch();
        $account_url  = $mepr_options->account_page_url();
        $delim        = MeprAppCtrl::get_param_delimiter_char($account_url);
        $label        = MeprHooks::apply_filters('mepr_account_nav_orders_label', _x('Orders', 'ui', 'memberpress'));
        $pm_label     = MeprHooks::apply_filters('mepr_account_nav_payment_methods_label', _x('Payment Methods', 'ui', 'memberpress'));
        ?>
        <li class="mepr-nav-item <?php MeprAccountHelper::active_nav('orders'); ?>">
          <a href="<?php echo esc_url($account_url . $delim . 'action=orders'); ?>">
            <?php echo esc_html($label); ?>
          </a>
        </li>
        <li class="mepr-nav-item <?php MeprAccountHelper::active_nav('payment-methods'); ?>">
          <a href="<?php echo esc_url($account_url . $delim . 'action=payment-methods'); ?>">
            <?php echo esc_html($pm_label); ?>
          </a>
        </li>
        <?php
    }

    /**
     * The mepr_account_nav_content action: render Orders tab content.
     *
     * @param  string $action The current account action.
     * @param  array  $atts   Shortcode attributes passed through.
     * @return void
     */
    public function account_orders_content($action, $atts)
    {
        if ($action === 'payment-methods') {
            $this->render_payment_methods();
            return;
        }

        if ($action !== 'orders') {
            return;
        }

        $user_id      = get_current_user_id();
        $mepr_options = MeprOptions::fetch();
        $account_url  = $mepr_options->account_page_url();
        $delim        = MeprAppCtrl::get_param_delimiter_char($account_url);
        $shop_url     = $mepr_options->shop_page_url();

        $order_id = absint($_REQUEST['order_id'] ?? 0);

        if ($order_id > 0) {
            $this->render_order_detail($order_id, $user_id, $account_url, $delim);
        } else {
            $this->render_orders_list($user_id, $account_url, $delim, $shop_url);
        }
    }

    /**
     * The mepr_custom_account_nav_title filter: set page title for the Orders tab.
     *
     * @param  string $title  Current custom title.
     * @param  string $action The current account action.
     * @return string
     */
    public function account_orders_title($title, $action)
    {
        if ($action === 'payment-methods') {
            return MeprHooks::apply_filters('mepr_account_payment_methods_title', _x('Payment Methods', 'ui', 'memberpress'));
        }

        if ($action !== 'orders') {
            return $title;
        }

        return MeprHooks::apply_filters('mepr_account_orders_title', _x('Orders', 'ui', 'memberpress'));
    }

    /**
     * Render the customer orders list.
     *
     * @param  integer $user_id     The current user ID.
     * @param  string  $account_url Base account page URL.
     * @param  string  $delim       URL parameter delimiter.
     * @param  string  $shop_url    Shop page URL.
     * @return void
     */
    private function render_orders_list($user_id, $account_url, $delim, $shop_url)
    {
        global $wpdb;

        $perpage   = MeprHooks::apply_filters('mepr_account_orders_per_page', 10);
        $curr_page = (isset($_GET['currpage']) && is_numeric($_GET['currpage'])) ? max(1, intval(wp_unslash($_GET['currpage']))) : 1;
        $offset    = ($curr_page - 1) * $perpage;

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery
        $orders = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT * FROM {$wpdb->mepr_orders}
                 WHERE user_id = %d AND order_type = %s
                 ORDER BY created_at DESC
                 LIMIT %d OFFSET %d",
                $user_id,
                MeprOrder::$cart_type_str,
                $perpage,
                $offset
            )
        );

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery
        $total_count = (int) $wpdb->get_var(
            $wpdb->prepare(
                "SELECT COUNT(*) FROM {$wpdb->mepr_orders} WHERE user_id = %d AND order_type = %s",
                $user_id,
                MeprOrder::$cart_type_str
            )
        );

        $total_pages = (int) ceil($total_count / max(1, (int) $perpage));
        $next_page   = ($curr_page < $total_pages) ? $curr_page + 1 : false;
        $prev_page   = ($curr_page > 1) ? $curr_page - 1 : false;

        // One cart-owned view in every template mode (classic CL, RL off, FSE) — the scoped
        // account-orders.css loads on the account page regardless of mode.
        MeprView::render('/readylaunch/cart/account-orders', compact(
            'orders',
            'curr_page',
            'prev_page',
            'next_page',
            'total_pages',
            'account_url',
            'delim',
            'shop_url'
        ));
    }

    /**
     * Render a single order detail view.
     *
     * Verifies the order belongs to the current user before rendering.
     *
     * @param  integer $order_id    The order ID to display.
     * @param  integer $user_id     The current user ID.
     * @param  string  $account_url Base account page URL.
     * @param  string  $delim       URL parameter delimiter.
     * @return void
     */
    private function render_order_detail($order_id, $user_id, $account_url, $delim)
    {
        $order_row = MeprOrder::get_one($order_id);

        if (!$order_row || (int) $order_row->user_id !== $user_id) {
            echo '<p>' . esc_html__('Order not found.', 'memberpress') . '</p>';
            return;
        }

        $order        = new MeprOrder((array) $order_row);
        $transactions = MeprTransaction::get_all_by_order_id_for_display($order->id);

        $customer_notes = array_filter(
            $order->get_notes(),
            fn($note) => ($note['type'] ?? '') === 'customer'
        );

        $show_tax = $order->should_display_tax($transactions);

        // One cart-owned view in every template mode (classic CL, RL off, FSE).
        MeprView::render('/readylaunch/cart/order-detail', compact(
            'order',
            'transactions',
            'account_url',
            'delim',
            'customer_notes',
            'show_tax'
        ));
    }

    // =========================================================================
    // Customer account — Payment Methods tab
    // =========================================================================

    /**
     * Render the saved payment methods management tab.
     *
     * @return void
     */
    private function render_payment_methods()
    {
        $user_id = get_current_user_id();
        $rows    = MeprSavedPaymentMethod::get_by_user($user_id, 'is_default DESC, created_at DESC');

        $methods = [];
        foreach ($rows as $row) {
            $methods[] = new MeprSavedPaymentMethod((array) $row);
        }

        $nonce = wp_create_nonce('mepr_payment_methods_nonce');

        // One cart-owned view in every template mode (classic CL, RL off, FSE).
        MeprView::render('/readylaunch/cart/account-payment-methods', compact(
            'methods',
            'user_id',
            'nonce'
        ));
    }

    /**
     * AJAX: Delete a saved payment method.
     *
     * Expects POST: method_id (int), nonce.
     *
     * @return void Sends JSON response and exits.
     */
    public function delete_payment_method()
    {
        if (!check_ajax_referer('mepr_payment_methods_nonce', 'nonce', false)) {
            wp_send_json_error(['message' => __('Security check failed.', 'memberpress')], 403);
        }

        if (!is_user_logged_in()) {
            wp_send_json_error(['message' => __('You must be logged in.', 'memberpress')], 403);
        }

        $method_id = absint($_POST['method_id'] ?? 0);

        if ($method_id < 1) {
            wp_send_json_error(['message' => __('Invalid payment method.', 'memberpress')], 400);
        }

        $row = (new MeprDb())->get_one_record((new MeprDb())->saved_payment_methods, ['id' => $method_id]);

        if (!$row) {
            wp_send_json_error(['message' => __('Payment method not found.', 'memberpress')], 404);
        }

        $method = new MeprSavedPaymentMethod((array) $row);

        if ((int) $method->user_id !== get_current_user_id()) {
            wp_send_json_error(['message' => __('You do not have permission to delete this payment method.', 'memberpress')], 403);
        }

        $can_delete = MeprCartCheckoutService::can_delete_payment_method(get_current_user_id(), $method);

        if (is_string($can_delete)) {
            wp_send_json_error(['message' => $can_delete]);
        }

        $method->destroy();

        wp_send_json_success(['message' => __('Payment method removed.', 'memberpress')]);
    }

    /**
     * AJAX: Set a saved payment method as the default.
     *
     * Expects POST: method_id (int), nonce.
     *
     * @return void Sends JSON response and exits.
     */
    public function set_default_payment_method()
    {
        if (!check_ajax_referer('mepr_payment_methods_nonce', 'nonce', false)) {
            wp_send_json_error(['message' => __('Security check failed.', 'memberpress')], 403);
        }

        if (!is_user_logged_in()) {
            wp_send_json_error(['message' => __('You must be logged in.', 'memberpress')], 403);
        }

        $method_id = absint($_POST['method_id'] ?? 0);

        if ($method_id < 1) {
            wp_send_json_error(['message' => __('Invalid payment method.', 'memberpress')], 400);
        }

        $row = (new MeprDb())->get_one_record((new MeprDb())->saved_payment_methods, ['id' => $method_id]);

        if (!$row) {
            wp_send_json_error(['message' => __('Payment method not found.', 'memberpress')], 404);
        }

        $method = new MeprSavedPaymentMethod((array) $row);

        if ((int) $method->user_id !== get_current_user_id()) {
            wp_send_json_error(['message' => __('You do not have permission to update this payment method.', 'memberpress')], 403);
        }

        MeprSavedPaymentMethod::set_default(get_current_user_id(), $method_id);

        wp_send_json_success(['message' => __('Default payment method updated.', 'memberpress')]);
    }

    // =========================================================================
    // AJAX: Customer subscription cancellation
    // =========================================================================

    /**
     * The customer-facing subscription cancellation reasons, keyed by slug.
     *
     * @return array<string, string>
     */
    public static function subscription_cancel_reasons(): array
    {
        return MeprHooks::apply_filters('mepr_subscription_cancel_reasons', [
            'too_expensive'     => __('Too expensive', 'memberpress'),
            'not_using_enough'  => __('Not using enough', 'memberpress'),
            'found_alternative' => __('Found an alternative', 'memberpress'),
            'missing_features'  => __('Missing features', 'memberpress'),
            'other'             => __('Other', 'memberpress'),
        ]);
    }

    /**
     * AJAX: Cancel a cart subscription from the account Orders page (legacy account-cancel parity).
     *
     * Expects POST: sub_id (int), nonce, reason (string), reason_text (string).
     *
     * Cancels through the subscription's gateway — renewals stop, access rides on the last
     * paid transaction until it expires.
     *
     * @return void Sends JSON response and exits.
     */
    public function cancel_cart_subscription()
    {
        // Use HTTP 200 for errors so the order-detail jQuery success handler can read
        // data.message. Non-2xx statuses only hit .fail() and previously always showed
        // the generic "An error occurred" alert (caseproof/qa#276).
        if (!check_ajax_referer('mepr_cancel_cart_subscription', 'nonce', false)) {
            wp_send_json_error(['message' => __('Security check failed.', 'memberpress')]);
        }

        if (!is_user_logged_in()) {
            wp_send_json_error(['message' => __('You must be logged in.', 'memberpress')]);
        }

        $sub_id      = absint($_POST['sub_id'] ?? 0);
        $reason      = sanitize_text_field(wp_unslash($_POST['reason'] ?? ''));
        $reason_text = sanitize_textarea_field(wp_unslash($_POST['reason_text'] ?? ''));

        if ($sub_id < 1) {
            wp_send_json_error(['message' => __('Invalid subscription.', 'memberpress')]);
        }

        $sub = new MeprSubscription($sub_id);

        if (!($sub->id > 0)) {
            wp_send_json_error(['message' => __('Subscription not found.', 'memberpress')]);
        }

        if ((int) $sub->user_id !== get_current_user_id()) {
            wp_send_json_error(['message' => __('You do not have permission to cancel this subscription.', 'memberpress')]);
        }

        if ($sub->status !== MeprSubscription::$active_str) {
            wp_send_json_error(['message' => __('This subscription is not active.', 'memberpress')]);
        }

        // Determine the access-end date from the expiring transaction — cancellation stops
        // renewals; access rides on the last paid transaction until it expires (legacy model).
        $access_until = '';

        $exp_txn = $sub->expiring_txn();
        if ($exp_txn && !empty($exp_txn->expires_at)) {
            $access_until = MeprAppHelper::format_date($exp_txn->expires_at);
        } else {
            // Fallback: calculate from subscription period.
            $access_until = MeprAppHelper::format_date(MeprUtils::ts_to_mysql_date($sub->get_expires_at(time())));
        }

        $sub->update_meta('_mepr_cancellation_reason', $reason);

        if (!empty($reason_text)) {
            $sub->update_meta('_mepr_cancellation_reason_text', $reason_text);
        }

        // Parity with MeprAccountCtrl::cancel() — payment_method + process_cancel_subscription.
        // No local status invent / provisional mp-sub-* fallbacks.
        $pm = $sub->payment_method();

        if (!is_object($pm) || !method_exists($pm, 'can') || !$pm->can('cancel-subscriptions')) {
            wp_send_json_error([
                'message' => __('This subscription cannot be cancelled here. Please contact support.', 'memberpress'),
            ]);
        }

        try {
            $pm->process_cancel_subscription($sub->id);
        } catch (Exception $e) {
            // Legacy subscriptions page can surface $e->getMessage(); AJAX alerts must not
            // expose raw gateway exception text to the browser.
            wp_send_json_error([
                'message' => __('Your subscription could not be cancelled. Please try again or contact support.', 'memberpress'),
            ]);
        }

        // Best-effort order timeline note (cart-only affordance; must not fail the cancel).
        try {
            $first_txn = MeprTransaction::get_one_by_subscription_id($sub->id);
            if ($first_txn && (int) $first_txn->order_id > 0) {
                $order = new MeprOrder((int) $first_txn->order_id);
                if ((int) $order->id > 0) {
                    $product = $sub->product();
                    $message = sprintf(
                        // Translators: 1: product name, 2: subscription id.
                        __('Customer cancelled their %1$s subscription (#%2$d).', 'memberpress'),
                        $product ? $product->post_title : __('(Unknown Product)', 'memberpress'),
                        $sub->id
                    );
                    if (!empty($reason)) {
                        $reason_label = self::subscription_cancel_reasons()[$reason] ?? $reason;
                        $message     .= ' ' . sprintf(
                            // Translators: %s: cancellation reason.
                            __('Reason: %s.', 'memberpress'),
                            trim($reason_label . ($reason_text !== '' ? ' — ' . $reason_text : ''))
                        );
                    }
                    $order->add_note($message, 'customer', get_current_user_id());
                }
            }
        } catch (Exception $e) {
            // Note is best-effort; subscription cancel already succeeded.
        }

        MeprHooks::do_action('mepr_cart_subscription_cancelled_from_account', $sub, $reason, $reason_text);

        wp_send_json_success([
            'message'      => __('Your subscription was successfully cancelled.', 'memberpress'),
            'access_until' => $access_until,
        ]);
    }
}

if (!function_exists('mepr_cart_icon')) {
    /**
     * Global template function: render the MemberPress mini-cart icon.
     *
     * Theme developers can call <?php mepr_cart_icon(); ?> directly in custom templates.
     *
     * @return void
     */
    function mepr_cart_icon()
    {
        echo MeprView::get_string('/readylaunch/layout/cart-icon'); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    }
}
