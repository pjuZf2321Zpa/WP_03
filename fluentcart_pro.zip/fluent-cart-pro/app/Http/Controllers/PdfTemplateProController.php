<?php

namespace FluentCartPro\App\Http\Controllers;

use FluentCart\Api\StoreSettings;
use FluentCart\App\Models\Order;
use FluentCartPro\App\Services\PDF\OrderReceiptPdfService;
use FluentCart\App\Services\PDF\ReceiptPdfTemplateService;
use FluentCartPro\App\Services\PDF\SellerDetailsService;
use FluentCartPro\App\Services\PDF\LegacyPdfTemplateMigrator;
use FluentCart\Framework\Http\Request\Request;
use FluentCart\Framework\Support\Arr;

class PdfTemplateProController extends Controller
{
    /**
     * Check if Fluent PDF is active and fonts are installed.
     */
    private function getPdfStatus(): array
    {
        $hasFluentPdf = defined('FLUENT_PDF');

        $addonInfo = null;
        if (!$hasFluentPdf) {
            $pluginSlug = 'fluentforms-pdf';
            $pluginFile = 'fluentforms-pdf/fluentforms-pdf.php';
            $addonManager = new \FluentCart\App\Services\PluginInstaller\AddonManager();
            $status = $addonManager->getAddonStatus($pluginSlug, $pluginFile);

            $addonInfo = [
                'plugin_slug'  => $pluginSlug,
                'plugin_file'  => $pluginFile,
                'source_type'  => 'wordpress',
                'is_installed' => $status['is_installed'],
                'is_active'    => $status['is_active'],
            ];
        }

        return [
            'has_fluent_pdf' => $hasFluentPdf,
            'addon_info'     => $addonInfo,
        ];
    }

    /**
     * Get PDF feature status and templates overview.
     */
    public function getStatus(): \WP_REST_Response
    {
        return $this->sendSuccess($this->getPdfStatus());
    }

    /**
     * Get all receipt PDF templates.
     */
    public function getTemplates(): \WP_REST_Response
    {
        $service   = new ReceiptPdfTemplateService();
        $templates = $service->getTemplates();
        $templates = LegacyPdfTemplateMigrator::migrateTemplates( $service, $templates );

        return $this->sendSuccess(array_merge(
            ['templates' => $templates],
            $this->getPdfStatus()
        ));
    }

    /**
     * Get a single template with its PDF structure.
     */
    public function getTemplate(Request $request, $templateId): \WP_REST_Response
    {
        $service   = new ReceiptPdfTemplateService();
        $templates = $service->getTemplates();
        $templates = LegacyPdfTemplateMigrator::migrateTemplates( $service, $templates );

        $templateId = sanitize_text_field($templateId);

        if (!isset($templates[$templateId])) {
            return $this->sendError([
                'message' => __('Template not found', 'fluent-cart-pro'),
            ]);
        }

        return $this->sendSuccess([
            'template' => $templates[$templateId],
        ]);
    }

    /**
     * Save the PDF template structure.
     */
    public function saveTemplate(Request $request, $templateId): \WP_REST_Response
    {
        $templateId = sanitize_text_field($templateId);
        $pdfStructure = Arr::get($request->all(), 'pdf_structure', []);

        if (empty($pdfStructure)) {
            return $this->sendError([
                'message' => __('No template data provided', 'fluent-cart-pro'),
            ]);
        }

        $service = new ReceiptPdfTemplateService();
        $saved = $service->setTemplateProperties($pdfStructure, $templateId);

        if ($saved) {
            return $this->sendSuccess([
                'message' => __('Template saved successfully', 'fluent-cart-pro'),
            ]);
        }

        return $this->sendError([
            'message' => __('Failed to save template', 'fluent-cart-pro'),
        ]);
    }

    /**
     * Create a new custom template.
     */
    public function createTemplate(Request $request): \WP_REST_Response
    {
        $title = sanitize_text_field(Arr::get($request->all(), 'title', ''));

        if (empty($title)) {
            return $this->sendError([
                'message' => __('Template title is required', 'fluent-cart-pro'),
            ]);
        }

        $service = new ReceiptPdfTemplateService();
        $slug = $service->createTemplate($title);
        $templates = $service->getTemplates();

        return $this->sendSuccess([
            'message'  => __('Template created successfully', 'fluent-cart-pro'),
            'slug'     => $slug,
            'template' => $templates[$slug] ?? null,
        ]);
    }

    /**
     * Delete a custom template.
     */
    public function deleteTemplate(Request $request, $templateId): \WP_REST_Response
    {
        $templateId = sanitize_text_field($templateId);
        $service = new ReceiptPdfTemplateService();
        $templates = $service->getTemplates();

        if (!isset($templates[$templateId])) {
            return $this->sendError([
                'message' => __('Template not found', 'fluent-cart-pro'),
            ]);
        }

        if (!empty($templates[$templateId]['is_default'])) {
            return $this->sendError([
                'message' => __('Default templates cannot be deleted', 'fluent-cart-pro'),
            ]);
        }

        $deleted = $service->deleteTemplate($templateId);

        if ($deleted) {
            return $this->sendSuccess([
                'message' => __('Template deleted successfully', 'fluent-cart-pro'),
            ]);
        }

        return $this->sendError([
            'message' => __('Failed to delete template', 'fluent-cart-pro'),
        ]);
    }

    /**
     * Get the factory default templates (pristine, ignoring saved changes).
     */
    public function getFactoryDefault(): \WP_REST_Response
    {
        $service = new ReceiptPdfTemplateService();

        return $this->sendSuccess([
            'templates' => $service->getFactoryDefault(),
        ]);
    }

    /**
     * Get the currently saved templates (or defaults if none saved).
     */
    public function getSavedTemplate(): \WP_REST_Response
    {
        $service   = new ReceiptPdfTemplateService();
        $templates = $service->getTemplates();
        $templates = LegacyPdfTemplateMigrator::migrateTemplates( $service, $templates );

        return $this->sendSuccess([
            'templates' => $templates,
        ]);
    }

    /**
     * Get E-Invoice seller details.
     */
    public function getSellerDetails(): \WP_REST_Response
    {
        $storeSettings = new StoreSettings();
        $storeCountry  = (string) $storeSettings->get('store_country', '');

        // E-invoices ride on PDF receipts, so the screen warns when Fluent PDF is missing.
        return $this->sendSuccess(array_merge([
            'seller_details'    => SellerDetailsService::getSellerDetails(),
            'store_country_set' => $storeCountry !== '',
            'store_settings_url' => admin_url('admin.php?page=fluent-cart#/settings/store-settings#business_details'),
        ], $this->getPdfStatus()));
    }

    /**
     * Save E-Invoice seller details with validation.
     */
    public function saveSellerDetails(Request $request): \WP_REST_Response
    {
        $data = $request->all();
        $sanitized = SellerDetailsService::sanitizeSellerDetails($data);

        $errors = [];

        // Validate when ZUGFeRD is being enabled
        if ($sanitized['zugferd_enabled'] === '1') {
            $storeSettings  = new StoreSettings();
            $storeVatId     = (string) $storeSettings->get('seller_vat_id', '');
            $storeLegalRegId = (string) $storeSettings->get('legal_registration_id', '');

            if (empty($storeVatId) && empty($storeLegalRegId)) {
                $errors['seller_vat_id'] = [
                    __('Seller VAT ID or Legal Registration ID is required when ZUGFeRD is enabled. Please add it in Settings → Store Settings.', 'fluent-cart-pro'),
                ];
            }

            // BT-40: Seller country code is mandatory in EN 16931 — it comes from Store Settings, not E-Invoice settings.
            $storeCountry = (string) $storeSettings->get('store_country', '');
            if (empty($storeCountry)) {
                $errors['store_country'] = [
                    __('Store country is required for ZUGFeRD. Please set it in Settings → Store Settings before enabling E-Invoice.', 'fluent-cart-pro'),
                ];
            }
        }

        // Validate legal registration scheme (must be a valid ISO 6523 ICD code)
        if (!empty($sanitized['seller_legal_registration_scheme'])
            && !array_key_exists($sanitized['seller_legal_registration_scheme'], SellerDetailsService::ISO_6523_ICD_CODES)
        ) {
            $errors['seller_legal_registration_scheme'] = [
                __('Please select a valid registration scheme from the list.', 'fluent-cart-pro'),
            ];
        }

        // Validate email format if provided
        if (!empty($sanitized['seller_contact_email']) && !is_email($sanitized['seller_contact_email'])) {
            $errors['seller_contact_email'] = [
                __('Please provide a valid email address.', 'fluent-cart-pro'),
            ];
        }

        // Validate IBAN format if provided (basic: 2 letters + 2 digits + up to 30 alphanumeric)
        if (!empty($sanitized['seller_bank_iban'])) {
            $iban = preg_replace('/\s+/', '', $sanitized['seller_bank_iban']);
            if (!preg_match('/^[A-Z]{2}\d{2}[A-Z0-9]{4,30}$/i', $iban)) {
                $errors['seller_bank_iban'] = [
                    __('Please provide a valid IBAN.', 'fluent-cart-pro'),
                ];
            }
        }

        if (!empty($errors)) {
            return $this->sendError([
                'message' => __('Validation failed. Please correct the errors below.', 'fluent-cart-pro'),
                'data'    => $errors,
            ], 422);
        }

        SellerDetailsService::setSellerDetails($sanitized);

        return $this->sendSuccess([
            'message'        => __('Settings saved successfully', 'fluent-cart-pro'),
            'seller_details' => SellerDetailsService::getSellerDetails(),
        ]);
    }

    /**
     * Generate a test PDF and return it as base64 for preview/download.
     */
    public function downloadPdf(Request $request): \WP_REST_Response
    {
        if (!defined('FLUENT_PDF')) {
            return $this->sendError([
                'message' => __('Fluent PDF plugin is not active', 'fluent-cart-pro'),
            ]);
        }

        $templateId = sanitize_text_field(Arr::get($request->all(), 'template_id', 'order_receipt'));

        $service = new ReceiptPdfTemplateService();
        $templates = $service->getTemplates();
        if (!isset($templates[$templateId])) {
            return $this->sendError([
                'message' => __('Template not found', 'fluent-cart-pro'),
            ]);
        }

        // Prefer a paid order with an invoice number so the test PDF reflects a real receipt.
        // Fall back to the most recent order if none is found.
        $order = Order::query()
            ->with(['customer', 'order_items', 'billing_address', 'shipping_address', 'transactions', 'orderTaxRates.tax_rate'])
            ->whereNotNull('invoice_no')
            ->latest()
            ->first();

        if (!$order) {
            $order = Order::query()
                ->with(['customer', 'order_items', 'billing_address', 'shipping_address', 'transactions', 'orderTaxRates.tax_rate'])
                ->latest()
                ->first();
        }

        if (!$order) {
            return $this->sendError([
                'message' => __('No orders found to generate test PDF', 'fluent-cart-pro'),
            ]);
        }

        try {
            $pdfService = new OrderReceiptPdfService();
            $pdfPath = $pdfService->generateReceiptPdf($order, $templateId);

            if (!$pdfPath || !file_exists($pdfPath)) {
                return $this->sendError([
                    'message' => __('Failed to generate PDF', 'fluent-cart-pro'),
                ]);
            }

            $pdfContent = file_get_contents($pdfPath);
            @unlink($pdfPath);

            return $this->sendSuccess([
                'pdf_base64' => base64_encode($pdfContent),
                'filename'   => $templateId . '-' . $order->invoice_no . '.pdf',
            ]);
        } catch (\Exception $e) {
            fluent_cart_add_log('PDF Generation Error', $e->getMessage(), 'error');

            return $this->sendError([
                'message' => __('Failed to generate PDF. Please check the activity log for details.', 'fluent-cart-pro'),
            ]);
        }
    }
}
