<?php

namespace FluentCartPro\App\Modules\DynamicPricing\Conditions\Options;

use FluentCart\Api\PaymentMethods;
use FluentCart\App\Services\Permission\PermissionManager;

/**
 * The store's active payment methods for the condition builder's remote select.
 *
 * Picked by slug — the gateway's route, such as `stripe` or `paypal` — which is
 * the same value checkout saves when the shopper chooses how to pay.
 *
 * @package FluentCartPro\App\Modules\DynamicPricing
 *
 * @version 1.0.0
 */
class PaymentMethodOptions extends SlugOptionSource
{
    /**
     * The `data_key` a condition attribute names to reach this list.
     *
     * @var string
     */
    protected $key = 'dynamic_pricing_payment_methods';

    /**
     * Every active payment method, as `route => title`.
     *
     * The title is the one the shopper sees at checkout, so the store's own
     * checkout label wins over the gateway's name. Read live, so a method
     * switched off stops being offered and stops being storable.
     *
     * @return array
     */
    public function available(): array
    {
        $methods = [];

        foreach (PaymentMethods::getActiveMethodInstance() as $method) {
            $route = (string)$method->getMeta('route');

            if ($route !== '') {
                $methods[$route] = (string)$method->getMeta('title') ?: $route;
            }
        }

        return $methods;
    }

    /**
     * The pricing rule permission alone: payment method names are shown to
     * every shopper at checkout, so they need no further bar.
     *
     * @param bool $hasPermission
     * @return bool
     */
    public function canRead($hasPermission)
    {
        return PermissionManager::hasPermission('dynamic_pricing/view');
    }
}
