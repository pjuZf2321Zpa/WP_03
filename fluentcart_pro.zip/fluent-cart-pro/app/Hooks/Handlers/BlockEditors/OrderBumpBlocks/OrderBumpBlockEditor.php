<?php

namespace FluentCartPro\App\Hooks\Handlers\BlockEditors\OrderBumpBlocks;

use FluentCart\App\Hooks\Handlers\BlockEditors\BlockEditor;

/**
 * Base for the blocks that only make sense inside an order bump card template.
 * The card renderer hands each block its offer through the "fluent-cart/bump" context:
 * ['id' => int, 'is_added' => bool, 'product_title' => string].
 */
abstract class OrderBumpBlockEditor extends BlockEditor
{
    use \FluentCartPro\App\Contracts\CanEnqueue;

    const CONTEXT_KEY = 'fluent-cart/bump';

    /**
     * Every block type this class registers; most classes register one.
     *
     * @return string[]
     */
    public static function blockNames(): array
    {
        return ['fluent-cart/' . static::getEditorName()];
    }

    // Core's version of this method does not pass uses_context, so the card blocks register themselves.
    public function registerBlockType(): void
    {
        $args = [
            'api_version'     => 3,
            'category'        => 'fluent-cart',
            'render_callback' => [$this, 'render_block'],
            'uses_context'    => $this->useContext(),
            'supports'        => $this->supports(),
        ];

        $attributes = $this->blockAttributes();
        if (!empty($attributes)) {
            $args['attributes'] = $attributes;
        }

        register_block_type($this->slugPrefix . '/' . static::getEditorName(), $args);
    }

    public function useContext()
    {
        return [self::CONTEXT_KEY];
    }

    public function supports(): array
    {
        return [
            'html'       => false,
            'align'      => false,
            'color'      => ['text' => true, 'background' => true],
            'typography' => ['fontSize' => true, 'lineHeight' => true, '__experimentalFontWeight' => true, '__experimentalTextDecoration' => true],
            'spacing'    => ['margin' => true, 'padding' => true],
        ];
    }

    public function getStyles(): array
    {
        return [];
    }

    // The base adds a block-support stylesheet before the first block; a card on the shop needs none.
    public function render_block($attributes, $content, $block)
    {
        return $this->render((array) $attributes, $block, $content);
    }

    /**
     * @return array|null The offer, or null when the block is drawn outside a card.
     */
    protected function bump($block)
    {
        $bump = isset($block->context[self::CONTEXT_KEY]) ? $block->context[self::CONTEXT_KEY] : null;

        return is_array($bump) && !empty($bump['id']) ? $bump : null;
    }
}
