<?php

namespace BitApps\IntegrationsPro\Triggers\ElementsKit;

use BitApps\IntegrationsPro\Config;
use WP_Post;

final class ElementsKitController
{
    private const TEMPLATE_POST_TYPE = 'elementskit_template';

    private const WIDGET_POST_TYPE = 'elementskit_widget';

    private const CONTENT_POST_TYPE = 'elementskit_content';

    public static function info()
    {
        return [
            'name'              => 'ElementsKit',
            'title'             => __('The most advanced addons for Elementor', 'bit-integrations-pro'),
            'type'              => 'custom_form_submission',
            'is_active'         => static::isPluginInstalled(),
            'documentation_url' => '#',
            'tutorial_url'      => '#',
            'tasks'             => [
                'action' => 'elements-kit/get',
                'method' => 'get',
            ],
            'fetch' => [
                'action' => 'trigger/test',
                'method' => 'post',
            ],
            'fetch_remove' => [
                'action' => 'trigger/test/remove',
                'method' => 'post',
            ],
            'isPro' => true
        ];
    }

    public function getAllTasks()
    {
        if (!static::isPluginInstalled()) {
            wp_send_json_error(\sprintf(__('%s is not installed or activated', 'bit-integrations-pro'), 'ElementsKit'));
        }

        wp_send_json_success([
            ['form_name' => __('Template Created', 'bit-integrations-pro'), 'triggered_entity_id' => 'elements_kit_template_created', 'skipPrimaryKey' => true, 'note' => 'When a new ElementsKit header, footer or section template is created.'],
            ['form_name' => __('Template Updated', 'bit-integrations-pro'), 'triggered_entity_id' => 'elements_kit_template_updated', 'skipPrimaryKey' => true, 'note' => 'When an existing ElementsKit template is saved.'],
            ['form_name' => __('Template Status Changed', 'bit-integrations-pro'), 'triggered_entity_id' => 'elements_kit_template_status_changed', 'skipPrimaryKey' => true, 'note' => 'When an ElementsKit template moves between post statuses, for example draft to publish.'],
            ['form_name' => __('Template Trashed', 'bit-integrations-pro'), 'triggered_entity_id' => 'elements_kit_template_trashed', 'skipPrimaryKey' => true, 'note' => 'When an ElementsKit template is moved to the trash.'],
            ['form_name' => __('Template Deleted', 'bit-integrations-pro'), 'triggered_entity_id' => 'elements_kit_template_deleted', 'skipPrimaryKey' => true, 'note' => 'When an ElementsKit template is permanently deleted.'],
            ['form_name' => __('Widget Created', 'bit-integrations-pro'), 'triggered_entity_id' => 'elements_kit_widget_created', 'skipPrimaryKey' => true, 'note' => 'When a new ElementsKit Widget Builder widget is created.'],
            ['form_name' => __('Widget Updated', 'bit-integrations-pro'), 'triggered_entity_id' => 'elements_kit_widget_updated', 'skipPrimaryKey' => true, 'note' => 'When an existing ElementsKit widget is saved.'],
            ['form_name' => __('Widget Trashed', 'bit-integrations-pro'), 'triggered_entity_id' => 'elements_kit_widget_trashed', 'skipPrimaryKey' => true, 'note' => 'When an ElementsKit widget is moved to the trash.'],
            ['form_name' => __('Widget Deleted', 'bit-integrations-pro'), 'triggered_entity_id' => 'elements_kit_widget_deleted', 'skipPrimaryKey' => true, 'note' => 'When an ElementsKit widget is permanently deleted.'],
            ['form_name' => __('Dynamic Content Created', 'bit-integrations-pro'), 'triggered_entity_id' => 'elements_kit_content_created', 'skipPrimaryKey' => true, 'note' => 'When a new ElementsKit dynamic content item is created.'],
            ['form_name' => __('Dynamic Content Updated', 'bit-integrations-pro'), 'triggered_entity_id' => 'elements_kit_content_updated', 'skipPrimaryKey' => true, 'note' => 'When an existing ElementsKit dynamic content item is saved.'],
            ['form_name' => __('Dynamic Content Trashed', 'bit-integrations-pro'), 'triggered_entity_id' => 'elements_kit_content_trashed', 'skipPrimaryKey' => true, 'note' => 'When an ElementsKit dynamic content item is moved to the trash.'],
            ['form_name' => __('Dynamic Content Deleted', 'bit-integrations-pro'), 'triggered_entity_id' => 'elements_kit_content_deleted', 'skipPrimaryKey' => true, 'note' => 'When an ElementsKit dynamic content item is permanently deleted.'],
        ]);
    }

    public static function handleTemplateCreated($postId, $post, $update)
    {
        if ($update || !static::isSavableEvent($post, self::TEMPLATE_POST_TYPE)) {
            return;
        }

        return static::flowExecute('elements_kit_template_created', static::postPayload($post));
    }

    public static function handleTemplateUpdated($postId, $post, $update)
    {
        if (!$update || !static::isSavableEvent($post, self::TEMPLATE_POST_TYPE)) {
            return;
        }

        return static::flowExecute('elements_kit_template_updated', static::postPayload($post));
    }

    public static function handleTemplateStatusChanged($newStatus, $oldStatus, $post)
    {
        if (
            $newStatus === $oldStatus
            || $newStatus === 'auto-draft'
            || $oldStatus === 'new'
            || !static::isPostOfType($post, self::TEMPLATE_POST_TYPE)
        ) {
            return;
        }

        $payload = array_merge(
            static::postPayload($post),
            ['old_status' => $oldStatus, 'new_status' => $newStatus]
        );

        return static::flowExecute('elements_kit_template_status_changed', $payload);
    }

    public static function handleTemplateTrashed($postId)
    {
        return static::executeForPost('elements_kit_template_trashed', $postId, self::TEMPLATE_POST_TYPE);
    }

    public static function handleTemplateDeleted($postId, $post = null)
    {
        return static::executeForPost('elements_kit_template_deleted', $postId, self::TEMPLATE_POST_TYPE, $post);
    }

    public static function handleWidgetCreated($postId, $post, $update)
    {
        if ($update || !static::isSavableEvent($post, self::WIDGET_POST_TYPE)) {
            return;
        }

        return static::flowExecute('elements_kit_widget_created', static::postPayload($post));
    }

    public static function handleWidgetUpdated($postId, $post, $update)
    {
        if (!$update || !static::isSavableEvent($post, self::WIDGET_POST_TYPE)) {
            return;
        }

        return static::flowExecute('elements_kit_widget_updated', static::postPayload($post));
    }

    public static function handleWidgetTrashed($postId)
    {
        return static::executeForPost('elements_kit_widget_trashed', $postId, self::WIDGET_POST_TYPE);
    }

    public static function handleWidgetDeleted($postId, $post = null)
    {
        return static::executeForPost('elements_kit_widget_deleted', $postId, self::WIDGET_POST_TYPE, $post);
    }

    public static function handleContentCreated($postId, $post, $update)
    {
        if ($update || !static::isSavableEvent($post, self::CONTENT_POST_TYPE)) {
            return;
        }

        return static::flowExecute('elements_kit_content_created', static::postPayload($post));
    }

    public static function handleContentUpdated($postId, $post, $update)
    {
        if (!$update || !static::isSavableEvent($post, self::CONTENT_POST_TYPE)) {
            return;
        }

        return static::flowExecute('elements_kit_content_updated', static::postPayload($post));
    }

    public static function handleContentTrashed($postId)
    {
        return static::executeForPost('elements_kit_content_trashed', $postId, self::CONTENT_POST_TYPE);
    }

    public static function handleContentDeleted($postId, $post = null)
    {
        return static::executeForPost('elements_kit_content_deleted', $postId, self::CONTENT_POST_TYPE, $post);
    }

    /**
     * Shared trash/delete path for all three ElementsKit CPTs — those hooks fire for
     * every post type, so the payload is only built once the type matches.
     */
    private static function executeForPost($triggered_entity_id, $postId, $postType, $post = null)
    {
        $post = $post instanceof WP_Post ? $post : get_post((int) $postId);

        if (!static::isPostOfType($post, $postType)) {
            return;
        }

        return static::flowExecute($triggered_entity_id, static::postPayload($post));
    }

    /**
     * `save_post_{type}` also fires for the empty `auto-draft` WordPress creates when
     * "Add New" is clicked, and during an autosave pass. Neither is a real authoring
     * event, so both are filtered out before a flow is dispatched.
     */
    private static function isSavableEvent($post, $postType)
    {
        if (!static::isPostOfType($post, $postType)) {
            return false;
        }

        if (\defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
            return false;
        }

        return $post->post_status !== 'auto-draft';
    }

    private static function isPostOfType($post, $postType)
    {
        return $post instanceof WP_Post && $post->post_type === $postType;
    }

    /**
     * Elementor keeps the whole serialized document in `_elementor_data` and friends,
     * which can run to hundreds of kilobytes. Those keys are left out so a flow payload
     * stays mappable; the curated keys below carry everything a flow actually uses.
     */
    private static function postPayload($post)
    {
        $excluded = ['_elementor_data', '_elementor_css', '_elementor_page_assets', '_elementor_controls_usage'];

        $payload = [
            'id'          => $post->ID,
            'title'       => $post->post_title,
            'slug'        => $post->post_name,
            'status'      => $post->post_status,
            'post_type'   => $post->post_type,
            'author_id'   => $post->post_author,
            'parent_id'   => $post->post_parent,
            'content'     => $post->post_content,
            'created_at'  => $post->post_date,
            'modified_at' => $post->post_modified,
            'edit_url'    => add_query_arg(['post' => $post->ID, 'action' => 'elementor'], admin_url('post.php')),
        ];

        foreach (get_post_meta($post->ID) as $key => $value) {
            if (\in_array($key, $excluded, true)) {
                continue;
            }

            $payload[$key] = \is_array($value) && \count($value) === 1 ? maybe_unserialize($value[0]) : $value;
        }

        return $payload;
    }

    private static function flowExecute($triggered_entity_id, $formData)
    {
        $helperClass = bit_integrations_get_class('Core\\Util\\Helper');
        $flowClass = bit_integrations_get_class('Flow\\Flow');

        $formData = $helperClass::prepareFetchFormatFields($formData);

        if (empty($formData) || !\is_array($formData)) {
            return;
        }

        $helperClass::setTestData(Config::withFreePrefix("{$triggered_entity_id}_test"), array_values($formData));

        $flows = $flowClass::exists('ElementsKit', $triggered_entity_id);

        if (empty($flows)) {
            return;
        }

        $flowClass::execute('ElementsKit', $triggered_entity_id, array_column($formData, 'value', 'name'), $flows);

        return ['type' => 'success'];
    }

    private static function isPluginInstalled()
    {
        return class_exists('ElementsKit_Lite');
    }
}
