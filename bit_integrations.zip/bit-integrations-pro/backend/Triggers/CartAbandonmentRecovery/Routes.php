<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Core\Util\Route;
use BitApps\IntegrationsPro\Triggers\CartAbandonmentRecovery\CartAbandonmentRecoveryController;

Route::get('cart-abandonment-recovery/get', [CartAbandonmentRecoveryController::class, 'getAllTasks']);
