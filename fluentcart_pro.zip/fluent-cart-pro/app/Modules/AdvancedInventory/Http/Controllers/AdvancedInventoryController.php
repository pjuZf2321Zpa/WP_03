<?php

namespace FluentCartPro\App\Modules\AdvancedInventory\Http\Controllers;

use FluentCartPro\App\Modules\AdvancedInventory\Services\Filter\AdvancedInventoryFilter;
use FluentCartPro\App\Modules\AdvancedInventory\Models\StockAdjustment;
use FluentCart\App\Models\ProductVariation;
use FluentCart\Framework\Http\Request\Request;
use FluentCart\App\Http\Controllers\Controller;
use WP_REST_Response;

class AdvancedInventoryController extends Controller
{
    private const ALLOWED_REASONS = ['received', 'damage', 'return', 'correction', 'transfer', 'other'];

    public function stats(): WP_REST_Response
    {
        $threshold = (int) apply_filters('fluent_cart/inventory_low_stock_threshold', 10);

        $row = ProductVariation::query()
            ->where('manage_stock', '1')
            ->selectRaw("
                COUNT(*) as total,
                SUM(CASE WHEN available <= 0 THEN 1 ELSE 0 END) as out_of_stock,
                SUM(CASE WHEN available > 0 AND available <= {$threshold} THEN 1 ELSE 0 END) as low_stock,
                SUM(CASE WHEN available > {$threshold} THEN 1 ELSE 0 END) as in_stock
            ")
            ->first();

        return $this->sendSuccess([
            'totalVariants' => (int) ($row->total ?? 0),
            'inStock'       => (int) ($row->in_stock ?? 0),
            'lowStock'      => (int) ($row->low_stock ?? 0),
            'outOfStock'    => (int) ($row->out_of_stock ?? 0),
        ]);
    }

    public function index(Request $request): WP_REST_Response
    {
        $products = AdvancedInventoryFilter::fromRequest($request)->paginate();

        $postIds = $products->getCollection()->pluck('ID')->all();

        $requestedWiths = (array) $request->get('with', []);

        // The `detail` row is only serialized for callers that explicitly ask
        // for it (`with[]=detail`, the public entry point) — the screen keys
        // load it solely to compute `thumbnail`.
        $includeDetail = in_array('detail', $requestedWiths, true);

        // Version gate: only the v2 screen key opts into the capped variant
        // list and the thumbnail-only appends. An OLD free frontend sending
        // the legacy key gets every variant (its parent rows sum the loaded
        // list) with formatted_total intact (its bulk modal renders it).
        $isCappedContract = in_array('admin_inventory_list_v2', $requestedWiths, true);

        // The eager load is capped per product, so parent-row stock totals and
        // the load-more state must come from SQL, not the loaded rows.
        $totalsByPostId = [];
        if ($postIds) {
            $totalRows = ProductVariation::query()
                ->selectRaw('post_id, COUNT(*) as variants_total, SUM(total_stock) as total_stock, SUM(available) as available, SUM(on_hold) as on_hold, SUM(committed) as committed')
                ->whereIn('post_id', $postIds)
                ->groupBy('post_id')
                ->get();
            foreach ($totalRows as $row) {
                $totalsByPostId[(int)$row->post_id] = $row;
            }
        }

        $products->setCollection(
            $products->getCollection()->map(function ($product) use ($totalsByPostId, $includeDetail, $isCappedContract) {
                return $this->transformProduct($product, $totalsByPostId[$product->ID] ?? null, $includeDetail, $isCappedContract);
            })
        );

        return $this->sendSuccess([
            'products' => $products,
        ]);
    }

    /**
     * Load-more source for a product's variant rows. Serves the pages the
     * capped eager load in AdvancedInventoryFilter::adminInventoryList() does
     * not include, with the same columns and the same id-ascending order, so
     * page N continues exactly where the first VARIANTS_PER_PRODUCT stopped.
     */
    public function variants(Request $request): WP_REST_Response
    {
        $postId = (int) $request->get('post_id');

        if (!$postId) {
            return $this->sendError([
                'message' => __('Product ID is required', 'fluent-cart-pro'),
            ], 400);
        }

        $perPage = (int) $request->get('per_page', AdvancedInventoryFilter::VARIANTS_PER_PRODUCT);
        $perPage = max(1, min($perPage, 100));
        $page    = max(1, (int) $request->get('page', 1));
        $afterId = (int) $request->get('after_id', 0);

        // Keyset mode (after_id): continue strictly past the last row the
        // client holds. Offset pages shift when a variant is deleted between
        // requests — ranks slide down, a row silently falls between pages,
        // and the client's dedupe can only hide duplicates, not gaps. The
        // response keeps the paginator's {data, total} read contract.
        if ($afterId > 0) {
            $baseQuery = ProductVariation::query()->where('post_id', $postId);

            $rows = (clone $baseQuery)
                ->select(AdvancedInventoryFilter::inventoryVariantColumns())
                ->with('media')
                ->where('id', '>', $afterId)
                ->orderBy('id', 'ASC')
                ->limit($perPage)
                ->get();

            return $this->sendSuccess([
                'variants' => [
                    'data'  => self::presentVariantRows($rows),
                    'total' => $baseQuery->count(),
                ],
            ]);
        }

        $variants = ProductVariation::query()
            ->where('post_id', $postId)
            ->select(AdvancedInventoryFilter::inventoryVariantColumns())
            ->with('media')
            ->orderBy('id', 'ASC')
            ->paginate($perPage, ['*'], 'page', $page);

        $variants->setCollection(
            self::presentVariantRows($variants->getCollection())
        );

        return $this->sendSuccess([
            'variants' => $variants,
        ]);
    }

    public function updateStock(Request $request): WP_REST_Response
    {
        $variantId   = (int) $request->get('variant_id');
        $postId      = (int) $request->get('post_id');
        $rawNewStock = $request->get('new_stock');
        $reason      = sanitize_text_field($request->get('reason'));
        $customReason = sanitize_textarea_field($request->get('customReason', ''));

        if (!$variantId || !$postId || $rawNewStock === null) {
            return $this->sendError([
                'message' => __('Required parameters are missing', 'fluent-cart-pro'),
            ], 400);
        }

        if (!in_array($reason, self::ALLOWED_REASONS, true)) {
            return $this->sendError([
                'message' => __('Invalid reason.', 'fluent-cart-pro'),
            ], 400);
        }

        if ($reason === 'other' && empty($customReason)) {
            return $this->sendError([
                'message' => __('Custom reason is required when reason is "other".', 'fluent-cart-pro'),
            ], 400);
        }

        $variant = ProductVariation::query()
            ->where('id', $variantId)
            ->where('post_id', $postId)
            ->first();

        if (!$variant) {
            return $this->sendError([
                'message' => __('Variant not found', 'fluent-cart-pro'),
            ], 404);
        }

        $oldStock     = $variant->total_stock;
        $newStock     = max(0, (int) $rawNewStock);
        $newAvailable = max(0, $newStock - ($variant->committed ?? 0) - ($variant->on_hold ?? 0));

        $variant->update([
            'total_stock' => $newStock,
            'available'   => $newAvailable,
        ]);

        StockAdjustment::create([
            'variant_id'    => $variantId,
            'post_id'       => $variant->post_id,
            'old_stock'     => $oldStock,
            'new_stock'     => $newStock,
            'reason'        => $reason,
            'custom_reason' => $reason === 'other' ? $customReason : null,
            'user_id'       => get_current_user_id(),
            'created_at'    => current_time('mysql'),
            'updated_at'    => current_time('mysql'),
        ]);

        return $this->sendSuccess([
            'message'    => __('Stock updated successfully', 'fluent-cart-pro'),
            'variant_id' => $variantId,
            'new_stock'  => $newStock,
            // Canonical values for the screen to write back verbatim: the
            // recomputed available (client copies can hold stale
            // committed/on_hold) and the product's fresh aggregates, so the
            // collapsed parent row updates without a refetch and reflects
            // concurrent edits by other admins too.
            'available'    => $newAvailable,
            'stock_totals' => $this->stockTotalsForProduct((int) $variant->post_id),
        ]);
    }

    /**
     * The same grouped aggregate index() serves per page, for one product —
     * the parent-row totals contract shared by both endpoints.
     */
    private function stockTotalsForProduct(int $postId): array
    {
        $row = ProductVariation::query()
            ->selectRaw('COUNT(*) as variants_total, SUM(total_stock) as total_stock, SUM(available) as available, SUM(on_hold) as on_hold, SUM(committed) as committed')
            ->where('post_id', $postId)
            ->first();

        return [
            'total_stock' => (int) ($row->total_stock ?? 0),
            'available'   => (int) ($row->available ?? 0),
            'on_hold'     => (int) ($row->on_hold ?? 0),
            'committed'   => (int) ($row->committed ?? 0),
        ];
    }

    public function bulkUpdate(Request $request): WP_REST_Response
    {
        $mode         = sanitize_text_field($request->get('mode'));
        $value        = (int) $request->get('value');
        $reason       = sanitize_text_field($request->get('reason'));
        $customReason = sanitize_textarea_field($request->get('customReason', ''));
        $items        = $request->get('items', []);

        if (!in_array($mode, ['add', 'set'], true)) {
            return $this->sendError([
                'message' => __('Invalid mode. Allowed: add, set', 'fluent-cart-pro'),
            ], 400);
        }

        if (!in_array($reason, self::ALLOWED_REASONS, true)) {
            return $this->sendError([
                'message' => __('Invalid reason.', 'fluent-cart-pro'),
            ], 400);
        }

        if ($reason === 'other' && empty($customReason)) {
            return $this->sendError([
                'message' => __('Custom reason is required when reason is "other".', 'fluent-cart-pro'),
            ], 400);
        }

        $variantIds = array_column($items, 'id');

        if (empty($variantIds)) {
            return $this->sendSuccess([
                'message' => __('No items to update', 'fluent-cart-pro'),
                'count'   => 0,
            ]);
        }

        $variants    = ProductVariation::query()->whereIn('id', $variantIds)->get()->keyBy('id');
        $updateCount = 0;
        $userId      = get_current_user_id();
        $adjustments = [];

        foreach ($items as $item) {
            $variantId = (int) ($item['id'] ?? 0);

            if (!$variantId || !isset($variants[$variantId])) {
                continue;
            }

            $variant  = $variants[$variantId];
            $oldStock = $variant->total_stock;

            $newStock     = $mode === 'add' ? $variant->total_stock + $value : $value;
            $newStock     = max(0, $newStock);
            $newAvailable = max(0, $newStock - ($variant->committed ?? 0) - ($variant->on_hold ?? 0));

            $variant->update([
                'total_stock' => $newStock,
                'available'   => $newAvailable,
            ]);

            $adjustments[] = [
                'variant_id'    => $variantId,
                'post_id'       => $variant->post_id,
                'old_stock'     => $oldStock,
                'new_stock'     => $newStock,
                'reason'        => $reason,
                'custom_reason' => $reason === 'other' ? $customReason : null,
                'user_id'       => $userId,
                'created_at'    => current_time('mysql'),
                'updated_at'    => current_time('mysql'),
            ];

            $updateCount++;
        }

        foreach ($adjustments as $adjustment) {
            StockAdjustment::create($adjustment);
        }

        return $this->sendSuccess([
            'message' => __('Stock updated successfully', 'fluent-cart-pro'),
            'count'   => $updateCount,
        ]);
    }

    public function adjustmentHistory(Request $request): WP_REST_Response
    {
        $variantId = $request->get('variant_id');

        if (!$variantId) {
            return $this->sendError([
                'message' => __('Variant ID is required', 'fluent-cart-pro'),
            ], 400);
        }

        $adjustments = StockAdjustment::query()
            ->where('variant_id', $variantId)
            ->orderBy('created_at', 'DESC')
            ->limit(100)
            ->get();

        if ($adjustments->isEmpty()) {
            return $this->sendSuccess([
                'adjustments' => [],
                'variant_id'  => $variantId,
            ]);
        }

        $reasonLabels = [
            'received'   => 'Received Stock',
            'damage'     => 'Damage/Loss',
            'return'     => 'Return/Refund',
            'correction' => 'Count Correction',
            'transfer'   => 'Inventory Transfer',
            'other'      => 'Other',
        ];

        $transformed = $adjustments->map(function ($adjustment) use ($reasonLabels) {
            $user = get_user_by('id', $adjustment->user_id);

            return [
                'id'            => $adjustment->id,
                'variant_id'    => $adjustment->variant_id,
                'post_id'       => $adjustment->post_id,
                'old_stock'     => (int) $adjustment->old_stock,
                'new_stock'     => (int) $adjustment->new_stock,
                'change'        => (int) $adjustment->new_stock - (int) $adjustment->old_stock,
                'reason'        => $adjustment->reason,
                'reason_label'  => $reasonLabels[$adjustment->reason] ?? $adjustment->reason,
                'custom_reason' => $adjustment->custom_reason ?? '',
                'user_id'       => $adjustment->user_id,
                'user_name'     => $user ? $user->display_name : 'System',
                'created_at'    => $adjustment->created_at ? $adjustment->created_at->format('Y-m-d H:i:s') : null,
                'updated_at'    => $adjustment->updated_at ? $adjustment->updated_at->format('Y-m-d H:i:s') : null,
            ];
        })->toArray();

        return $this->sendSuccess([
            'adjustments' => $transformed,
            'variant_id'  => $variantId,
        ]);
    }

    public function export(Request $request): WP_REST_Response
    {
        $scope          = sanitize_text_field($request->get('scope'));
        $inventoryState = sanitize_text_field($request->get('inventoryState'));
        $format         = sanitize_text_field($request->get('format', 'csv_spreadsheet'));
        $items          = $request->get('items', []);

        if (!in_array($scope, ['all', 'current_page', 'selected'], true)) {
            return $this->sendError([
                'message' => __('Invalid scope.', 'fluent-cart-pro'),
            ], 400);
        }

        if (!in_array($inventoryState, ['available', 'full'], true)) {
            return $this->sendError([
                'message' => __('Invalid inventoryState.', 'fluent-cart-pro'),
            ], 400);
        }

        $query = ProductVariation::query()->with('product')->where('manage_stock', '1');

        if ($scope === 'current_page') {
            $query->limit(1000);
        } elseif ($scope === 'selected') {
            $query->whereIn('id', array_column($items, 'id'));
        }

        $csvData  = $this->buildCsv($query, $format, $inventoryState);
        $filename = 'inventory-export-' . date('Y-m-d-H-i-s') . '.csv';

        return $this->sendSuccess([
            'message'  => __('Inventory exported successfully', 'fluent-cart-pro'),
            'filename' => $filename,
            'csvData'  => $csvData,
        ]);
    }

    /**
     * Only what the inventory screen renders: product identity + thumbnail,
     * the capped variant rows, and the SQL stock aggregates. The former
     * post_content/post_excerpt/post_status/view_url/gallery keys and the raw
     * `detail` row (with its gallery-image meta blob) were dead weight on
     * every page load; `detail` is still served when a caller explicitly
     * requests the public `detail` with-key.
     */
    public function transformProduct($product, $stockTotals = null, $includeDetail = false, $isCappedContract = true): array
    {
        $loadedVariants = $product->variants ?? [];

        // A product that fits inside the eager cap ships complete — no
        // load-more for one or two extra rows. Only a product that overflows
        // the cap is trimmed to the smaller visible count; its remainder
        // comes from GET inventory/variants (the id-ascending order matches,
        // and the frontend dedupes, so the first load-more click simply
        // fills 6..10 before later pages continue past the fetch cap).
        // Legacy callers are exempt: their UI has no Load More, so a trimmed
        // list would make variants invisible and parent sums wrong.
        $variantsTotal = $stockTotals ? (int) $stockTotals->variants_total : count($loadedVariants);
        if ($isCappedContract
            && $variantsTotal > AdvancedInventoryFilter::VARIANTS_PER_PRODUCT
            && count($loadedVariants) > AdvancedInventoryFilter::VARIANTS_VISIBLE_WHEN_CAPPED
        ) {
            $loadedVariants = is_array($loadedVariants)
                ? array_slice($loadedVariants, 0, AdvancedInventoryFilter::VARIANTS_VISIBLE_WHEN_CAPPED)
                : $loadedVariants->take(AdvancedInventoryFilter::VARIANTS_VISIBLE_WHEN_CAPPED)->values();
        }

        $data = [
            'ID'         => $product->ID,
            'post_title' => $product->post_title,
            'thumbnail'  => $product->thumbnail,
            'variants'   => $isCappedContract ? self::presentVariantRows($loadedVariants) : $loadedVariants,
            // SQL aggregates over ALL variants — the loaded list is capped, so
            // parent-row sums and the load-more state cannot come from it.
            'variants_total' => $variantsTotal,
            'stock_totals'   => [
                'total_stock' => $stockTotals ? (int) $stockTotals->total_stock : null,
                'available'   => $stockTotals ? (int) $stockTotals->available : null,
                'on_hold'     => $stockTotals ? (int) $stockTotals->on_hold : null,
                'committed'   => $stockTotals ? (int) $stockTotals->committed : null,
            ],
        ];

        if ($includeDetail) {
            $data['detail'] = $product->detail;
        }

        return $data;
    }

    /**
     * The eager-loaded `media` relation exists only to feed each variant's
     * `thumbnail` append; hiding it keeps the raw product-meta blob (ids,
     * meta_value arrays) out of the serialized rows. Hidden, not unset — the
     * append still reads the loaded relation, so no query comes back.
     *
     * `thumbnail` is also the ONLY append served: ProductVariation::booted()
     * attaches `formatted_total` to every retrieved row, but nothing on the
     * inventory screen renders price, and its backing `item_price` column is
     * no longer selected — left appended it would serialize as a bogus $0.00.
     */
    private static function presentVariantRows($variants)
    {
        if (is_array($variants)) {
            return $variants;
        }

        return $variants->map(function ($variant) {
            return $variant->makeHidden('media')->setAppends(['thumbnail']);
        });
    }

    private function buildCsv($query, string $format, string $inventoryState): string
    {
        $handle = fopen('php://temp', 'w');

        if ($inventoryState === 'available') {
            fputcsv($handle, ['ID', 'SKU', 'Product Title', 'Variation Title', 'Available']);
        } else {
            fputcsv($handle, ['ID', 'SKU', 'Product Title', 'Variation Title', 'Total Stock', 'Available', 'On Hold', 'Delivered']);
        }

        $query->chunk(1000, function ($variants) use ($handle, $inventoryState) {
            foreach ($variants as $variant) {
                if ($inventoryState === 'available') {
                    fputcsv($handle, [
                        $variant->id,
                        $variant->sku ?? '',
                        $variant->product->post_title ?? '',
                        $variant->variation_title ?? '',
                        $variant->available ?? 0,
                    ]);
                } else {
                    fputcsv($handle, [
                        $variant->id,
                        $variant->sku ?? '',
                        $variant->product->post_title ?? '',
                        $variant->variation_title ?? '',
                        $variant->total_stock ?? 0,
                        $variant->available ?? 0,
                        $variant->on_hold ?? 0,
                        $variant->committed ?? 0,
                    ]);
                }
            }
        });

        rewind($handle);
        $csv = stream_get_contents($handle);
        fclose($handle);

        if ($format === 'csv_spreadsheet') {
            $csv = "\xEF\xBB\xBF{$csv}";
        }

        return $csv;
    }
}
