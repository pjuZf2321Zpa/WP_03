<?php

namespace WPAICG\ContentWriter\SEO;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Prevents Smart SEO from accepting rewrites that force awkward exact-keyphrase phrasing.
 */
class AIPKit_Content_Writer_Smart_SEO_Naturalness_Guard
{
    public static function should_keep_previous(array $candidate, array $previous): bool
    {
        $focus_keyphrase = isset($candidate['focus_keyword'])
            ? sanitize_text_field((string) $candidate['focus_keyword'])
            : sanitize_text_field((string) ($previous['focus_keyword'] ?? ''));

        if (!self::is_guardable_keyphrase($focus_keyphrase)) {
            return false;
        }

        $candidate_content = (string) ($candidate['content_html'] ?? $candidate['content'] ?? '');
        $previous_content = (string) ($previous['content_html'] ?? $previous['content'] ?? '');
        $candidate_count = self::awkward_exact_subject_count($candidate_content, $focus_keyphrase);

        if ($candidate_count < 2) {
            return false;
        }

        return $candidate_count > self::awkward_exact_subject_count($previous_content, $focus_keyphrase);
    }

    public static function is_guardable_keyphrase(string $focus_keyphrase): bool
    {
        $words = self::words($focus_keyphrase);
        if (count($words) < 3) {
            return false;
        }

        $last_word = strtolower((string) end($words));
        return in_array($last_word, [
            'availability',
            'comparison',
            'cost',
            'costs',
            'deal',
            'deals',
            'discount',
            'discounts',
            'feature',
            'features',
            'guide',
            'offer',
            'offers',
            'plan',
            'plans',
            'price',
            'prices',
            'pricing',
            'review',
            'reviews',
            'spec',
            'specs',
        ], true);
    }

    private static function awkward_exact_subject_count(string $html, string $focus_keyphrase): int
    {
        $text = self::normalized_text(wp_strip_all_tags($html));
        $phrase = self::normalized_text($focus_keyphrase);
        if ($text === '' || $phrase === '') {
            return 0;
        }

        $phrase_pattern = preg_replace('/\s+/', '\\s+', preg_quote($phrase, '/'));
        if (!$phrase_pattern) {
            return 0;
        }

        $weak_predicates = '(?:is|are|was|were|looks?|seems?|feels?|should|must|needs?|can\s+be|could\s+be|may\s+be|might\s+be|will\s+be|would\s+be)';
        $pattern = '/(?<![\p{L}\p{N}])' . $phrase_pattern . '\s+' . $weak_predicates . '\b/u';

        if (!preg_match_all($pattern, $text, $matches)) {
            return 0;
        }

        return count($matches[0]);
    }

    private static function words(string $text): array
    {
        if (!preg_match_all('/[\p{L}\p{N}][\p{L}\p{N}\'-]*/u', $text, $matches)) {
            return [];
        }

        return array_values(array_filter(array_map('trim', $matches[0])));
    }

    private static function normalized_text(string $text): string
    {
        $text = function_exists('remove_accents') ? remove_accents($text) : $text;
        $text = function_exists('mb_strtolower') ? mb_strtolower($text, 'UTF-8') : strtolower($text);

        return preg_replace('/\s+/u', ' ', trim((string) $text));
    }
}
