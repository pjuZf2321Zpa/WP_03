<?php

namespace BitApps\IntegrationsPro\Actions\WpHotelBooking;

use BitApps\IntegrationsPro\Triggers\WpHotelBooking\WpHotelBookingHelper as Helper;
use HB_Room_Extra;
use WPHB_Booking;
use WPHB_Room;
use WPHB_Room_Booking_Available;

if (!\defined('ABSPATH')) {
    exit;
}

final class WpHotelBookingProHelper
{
    private const ROOM_STATUSES = ['publish', 'draft', 'pending', 'private'];

    private const DISCOUNT_TYPES = ['fixed_cart', 'percent_cart'];

    private const PAYABLE_STATUSES = ['pending', 'processing'];

    private const ROOM_META_FIELDS = [
        'num_of_rooms'         => '_hb_num_of_rooms',
        'max_adults'           => '_hb_room_capacity_adult',
        'max_children'         => '_hb_max_child_per_room',
        'beds'                 => '_hb_room_beds',
        'area'                 => '_hb_room_area',
        'external_link'        => '_hb_external_link',
        'addition_information' => '_hb_room_addition_information',
        'rules'                => '_hb_wphb_rule_room',
    ];

    public static function createBooking($response, $fieldData, $utilities = null, $integrationDetails = null)
    {
        if ($error = self::checkRequired($fieldData, ['check_in_date' => __('Check-in Date', 'bit-integrations-pro'), 'check_out_date' => __('Check-out Date', 'bit-integrations-pro'), 'customer_email' => __('Customer Email', 'bit-integrations-pro'), 'customer_first_name' => __('Customer First Name', 'bit-integrations-pro'), 'customer_last_name' => __('Customer Last Name', 'bit-integrations-pro')])) {
            return $error;
        }

        if (!is_email($fieldData['customer_email'])) {
            return self::error(__('Customer email is invalid. Map a valid email address.', 'bit-integrations-pro'));
        }

        $room = self::findBookableRoom($integrationDetails);

        if (\is_array($room)) {
            return $room;
        }

        $stayDates = self::parseStayDates($fieldData);

        if (isset($stayDates['success'])) {
            return $stayDates;
        }

        list($checkInDate, $checkOutDate) = $stayDates;

        if ($error = self::checkGuestCounts($fieldData)) {
            return $error;
        }

        $quantity = max(1, (int) ($fieldData['quantity'] ?? 1));
        $status = Helper::normalizeStatus(self::util($utilities, 'selected_booking_status')) ?: 'pending';

        if (!\in_array($status, Helper::getBookingStatuses(), true)) {
            return self::error(__('Booking status is invalid. Select a status from the list.', 'bit-integrations-pro'));
        }

        $gateway = null;
        $paymentMethod = self::util($utilities, 'selected_payment_method');

        if ($paymentMethod !== '') {
            $gateways = hb_get_payment_gateways();
            $gateway = $gateways[$paymentMethod] ?? null;

            if (!$gateway) {
                return self::error(__('Payment method is invalid. Select a payment method from the list.', 'bit-integrations-pro'));
            }
        }

        if ($error = self::checkAvailability($room->ID, $checkInDate, $checkOutDate, $quantity)) {
            return $error;
        }

        $note = $fieldData['note'] ?? '';

        $bookingId = wp_insert_post(
            [
                'post_type'             => Helper::BOOKING_POST_TYPE,
                'post_status'           => 'hb-pending',
                'post_title'            => __('Booking', 'bit-integrations-pro'),
                'post_content'          => $note,
                'post_excerpt'          => $note,
                'post_content_filtered' => $note,
            ],
            true
        );

        if (is_wp_error($bookingId)) {
            return self::error($bookingId->get_error_message());
        }

        $price = self::calculateRoomPrice($room->ID, $checkInDate, $checkOutDate, $quantity);
        $customer = get_user_by('email', $fieldData['customer_email']);

        $bookingInfo = [
            '_hb_tax'                     => $price['tax_total'],
            '_hb_advance_payment'         => $price['total'],
            '_hb_advance_payment_setting' => hb_settings()->get('advance_payment', 50),
            '_hb_currency'                => hb_get_currency(),
            '_hb_user_id'                 => $customer ? $customer->ID : 0,
            '_hb_method'                  => $gateway ? $gateway->slug : '',
            '_hb_method_title'            => $gateway ? $gateway->title : '',
            '_hb_method_id'               => $gateway ? $gateway->method_id : '',
            '_hb_booking_key'             => wp_generate_password(32, false),
            '_hb_customer_title'          => self::util($utilities, 'selected_customer_title'),
        ];

        foreach (Helper::CUSTOMER_FIELDS as $field) {
            if ($field !== 'title') {
                $bookingInfo['_hb_customer_' . $field] = $fieldData['customer_' . $field] ?? '';
            }
        }

        self::updatePostMetaValues($bookingId, $bookingInfo);

        $orderItems = [
            [
                'product_id'     => $room->ID,
                'qty'            => $quantity,
                'adult_qty'      => (int) ($fieldData['adults'] ?? 1),
                'child_qty'      => (int) ($fieldData['children'] ?? 0),
                'check_in_date'  => $checkInDate,
                'check_out_date' => $checkOutDate,
                'subtotal'       => $price['subtotal'],
                'total'          => $price['total'],
                'tax_total'      => $price['tax_total'],
            ],
        ];

        $booking = WPHB_Booking::instance($bookingId);
        $booking->add_order_items($orderItems);

        foreach (Helper::getBookingItemsData($bookingId) as $orderItem) {
            if ($orderItem['order_item_type'] === 'line_item') {
                self::addRequiredExtras($bookingId, $orderItem['order_item_id'], $room->ID, $checkInDate, $checkOutDate, $quantity);
            }
        }

        self::refreshBookingTotals($bookingId);
        $booking->update_room_booking($bookingId);

        do_action('hotel_booking_create_booking', $bookingId, $bookingInfo, $orderItems);

        if ($status !== 'pending') {
            $booking->update_status($status);
        }

        return self::success(__('Booking created successfully.', 'bit-integrations-pro'), Helper::getBookingData($bookingId));
    }

    public static function updateBookingStatus($response, $fieldData, $integrationDetails = null)
    {
        $booking = self::findBooking($fieldData);

        if (\is_array($booking)) {
            return $booking;
        }

        $status = Helper::normalizeStatus(self::conf($integrationDetails, 'selectedBookingStatus'));

        if (!\in_array($status, Helper::getBookingStatuses(), true)) {
            return self::error(__('Booking status is invalid. Select a status in the action settings.', 'bit-integrations-pro'));
        }

        if (Helper::normalizeStatus($booking->post_status) !== $status) {
            WPHB_Booking::instance($booking->ID)->update_status($status);
        }

        return self::success(__('Booking status updated successfully.', 'bit-integrations-pro'), Helper::getBookingData($booking->ID));
    }

    public static function updateBookingCustomer($response, $fieldData, $utilities = null)
    {
        $booking = self::findBooking($fieldData);

        if (\is_array($booking)) {
            return $booking;
        }

        $customerMeta = [];

        foreach (Helper::CUSTOMER_FIELDS as $field) {
            $value = $field === 'title' ? self::util($utilities, 'selected_customer_title') : ($fieldData['customer_' . $field] ?? '');

            if ($value !== '') {
                $customerMeta['_hb_customer_' . $field] = $value;
            }
        }

        if (empty($customerMeta)) {
            return self::error(__('Customer fields are empty. Map at least one customer field.', 'bit-integrations-pro'));
        }

        if (isset($customerMeta['_hb_customer_email'])) {
            if (!is_email($customerMeta['_hb_customer_email'])) {
                return self::error(__('Customer email is invalid. Map a valid email address.', 'bit-integrations-pro'));
            }

            $customer = get_user_by('email', $customerMeta['_hb_customer_email']);
            $customerMeta['_hb_user_id'] = $customer ? $customer->ID : 0;
        }

        self::updatePostMetaValues($booking->ID, $customerMeta);

        return self::success(__('Booking customer updated successfully.', 'bit-integrations-pro'), Helper::getBookingData($booking->ID));
    }

    public static function updateBookingNote($response, $fieldData)
    {
        if ($error = self::checkRequired($fieldData, ['note' => __('Booking Note', 'bit-integrations-pro')])) {
            return $error;
        }

        $booking = self::findBooking($fieldData);

        if (\is_array($booking)) {
            return $booking;
        }

        $updated = wp_update_post(
            [
                'ID'                    => $booking->ID,
                'post_content'          => $fieldData['note'],
                'post_excerpt'          => $fieldData['note'],
                'post_content_filtered' => $fieldData['note'],
            ],
            true
        );

        if (is_wp_error($updated)) {
            return self::error($updated->get_error_message());
        }

        return self::success(__('Booking note updated successfully.', 'bit-integrations-pro'), Helper::getBookingData($booking->ID));
    }

    public static function markPaymentComplete($response, $fieldData)
    {
        $booking = self::findBooking($fieldData);

        if (\is_array($booking)) {
            return $booking;
        }

        $bookingObject = WPHB_Booking::instance($booking->ID);

        if (!$bookingObject->has_status(self::PAYABLE_STATUSES)) {
            return self::error(
                // translators: %s: Current booking status
                \sprintf(__('Booking status is "%s". Select a pending or processing booking.', 'bit-integrations-pro'), $bookingObject->get_status())
            );
        }

        $allowPayableStatuses = static function () {
            return self::PAYABLE_STATUSES;
        };

        add_filter('hb_valid_order_statuses_for_payment_complete', $allowPayableStatuses);
        $bookingObject->payment_complete($fieldData['transaction_id'] ?? '');
        remove_filter('hb_valid_order_statuses_for_payment_complete', $allowPayableStatuses);

        return self::success(__('Booking payment marked as complete.', 'bit-integrations-pro'), Helper::getBookingData($booking->ID));
    }

    public static function deleteBooking($response, $fieldData, $utilities = null)
    {
        $booking = self::findBooking($fieldData, true);

        if (\is_array($booking)) {
            return $booking;
        }

        $bookingData = Helper::getBookingData($booking->ID);
        $forceDelete = self::isTrue(self::util($utilities, 'selected_force_delete'));

        if (!self::deletePost($booking->ID, $forceDelete)) {
            return self::error(__('Could not delete the booking. Try again.', 'bit-integrations-pro'));
        }

        if ($forceDelete) {
            hb_empty_booking_order_items($booking->ID);
        }

        return self::success(
            $forceDelete ? __('Booking deleted permanently.', 'bit-integrations-pro') : __('Booking moved to the trash.', 'bit-integrations-pro'),
            $bookingData
        );
    }

    public static function addRoomToBooking($response, $fieldData, $integrationDetails = null)
    {
        $booking = self::findBooking($fieldData);

        if (\is_array($booking)) {
            return $booking;
        }

        $room = self::findBookableRoom($integrationDetails);

        if (\is_array($room)) {
            return $room;
        }

        $stayDates = self::parseStayDates($fieldData);

        if (isset($stayDates['success'])) {
            return $stayDates;
        }

        list($checkInDate, $checkOutDate) = $stayDates;

        if ($error = self::checkGuestCounts($fieldData)) {
            return $error;
        }

        $quantity = max(1, (int) ($fieldData['quantity'] ?? 1));

        if ($error = self::checkAvailability($room->ID, $checkInDate, $checkOutDate, $quantity)) {
            return $error;
        }

        $orderItemId = hb_add_order_item($booking->ID, ['order_item_name' => $room->post_title, 'order_item_type' => 'line_item']);

        if (!$orderItemId) {
            return self::error(__('Could not add the room to the booking. Try again.', 'bit-integrations-pro'));
        }

        $itemMeta = array_merge(
            [
                'product_id'     => $room->ID,
                'check_in_date'  => $checkInDate,
                'check_out_date' => $checkOutDate,
                'qty'            => $quantity,
                'adult_qty'      => (int) ($fieldData['adults'] ?? 1),
                'child_qty'      => (int) ($fieldData['children'] ?? 0),
            ],
            self::calculateRoomPrice($room->ID, $checkInDate, $checkOutDate, $quantity, $orderItemId)
        );

        foreach ($itemMeta as $metaKey => $metaValue) {
            hb_update_order_item_meta($orderItemId, $metaKey, $metaValue);
        }

        self::addRequiredExtras($booking->ID, $orderItemId, $room->ID, $checkInDate, $checkOutDate, $quantity);

        do_action('hotel_booking_updated_order_item', $booking->ID, $orderItemId);

        self::refreshBookingTotals($booking->ID);
        WPHB_Booking::instance($booking->ID)->update_room_booking($booking->ID);
        self::recalculateRoomAvailability($room->ID);

        return self::success(
            __('Room added to the booking successfully.', 'bit-integrations-pro'),
            ['order_item' => Helper::findBookingItem($booking->ID, $orderItemId), 'booking' => Helper::getBookingData($booking->ID)]
        );
    }

    public static function removeBookingItem($response, $fieldData)
    {
        if ($error = self::checkRequired($fieldData, ['order_item_id' => __('Booking Item ID', 'bit-integrations-pro')])) {
            return $error;
        }

        $booking = self::findBooking($fieldData);

        if (\is_array($booking)) {
            return $booking;
        }

        $orderItem = Helper::findBookingItem($booking->ID, $fieldData['order_item_id']);

        if (empty($orderItem)) {
            return self::error(__('Booking item is not found in this booking. Map a valid booking item ID.', 'bit-integrations-pro'));
        }

        foreach ((array) hb_get_sub_item_order_item_id($orderItem['order_item_id']) as $subItemId) {
            hb_remove_order_item((int) $subItemId);
        }

        hb_remove_order_item($orderItem['order_item_id']);

        if ($orderItem['order_item_type'] === 'line_item' && get_post_type($orderItem['product_id']) === Helper::ROOM_POST_TYPE) {
            self::releaseRoomDates($booking->ID, $orderItem['product_id']);
        }

        self::refreshBookingTotals($booking->ID);

        return self::success(
            __('Booking item removed successfully.', 'bit-integrations-pro'),
            ['removed_item' => $orderItem, 'booking' => Helper::getBookingData($booking->ID)]
        );
    }

    public static function createCoupon($response, $fieldData, $integrationDetails = null)
    {
        if ($error = self::checkRequired($fieldData, ['code' => __('Coupon Code', 'bit-integrations-pro'), 'discount_value' => __('Discount Value', 'bit-integrations-pro'), 'date_from' => __('Valid From', 'bit-integrations-pro'), 'date_to' => __('Valid Until', 'bit-integrations-pro')])) {
            return $error;
        }

        if (self::findCouponIdByCode($fieldData['code'])) {
            return self::error(__('A coupon with this code already exists. Use a different code.', 'bit-integrations-pro'));
        }

        $couponMeta = self::prepareCouponMeta($fieldData, self::conf($integrationDetails, 'selectedDiscountType'));

        if (isset($couponMeta['success'])) {
            return $couponMeta;
        }

        $couponId = wp_insert_post(['post_type' => Helper::COUPON_POST_TYPE, 'post_title' => $fieldData['code'], 'post_status' => 'publish'], true);

        if (is_wp_error($couponId)) {
            return self::error($couponId->get_error_message());
        }

        self::updatePostMetaValues($couponId, $couponMeta);

        return self::success(__('Coupon created successfully.', 'bit-integrations-pro'), Helper::getCouponData($couponId));
    }

    public static function updateCoupon($response, $fieldData, $utilities = null)
    {
        $coupon = self::findPostByField($fieldData, 'coupon_id', Helper::COUPON_POST_TYPE, __('Coupon', 'bit-integrations-pro'));

        if (\is_array($coupon)) {
            return $coupon;
        }

        $couponMeta = self::prepareCouponMeta($fieldData, self::util($utilities, 'selected_discount_type'), $coupon->ID);

        if (isset($couponMeta['success'])) {
            return $couponMeta;
        }

        if (!empty($fieldData['code']) && $fieldData['code'] !== $coupon->post_title) {
            $existingCouponId = self::findCouponIdByCode($fieldData['code']);

            if ($existingCouponId && $existingCouponId !== $coupon->ID) {
                return self::error(__('A coupon with this code already exists. Use a different code.', 'bit-integrations-pro'));
            }

            $updated = wp_update_post(['ID' => $coupon->ID, 'post_title' => $fieldData['code']], true);

            if (is_wp_error($updated)) {
                return self::error($updated->get_error_message());
            }
        }

        self::updatePostMetaValues($coupon->ID, $couponMeta);

        return self::success(__('Coupon updated successfully.', 'bit-integrations-pro'), Helper::getCouponData($coupon->ID));
    }

    public static function deleteCoupon($response, $fieldData, $utilities = null)
    {
        $coupon = self::findPostByField($fieldData, 'coupon_id', Helper::COUPON_POST_TYPE, __('Coupon', 'bit-integrations-pro'), true);

        if (\is_array($coupon)) {
            return $coupon;
        }

        $couponData = Helper::getCouponData($coupon->ID);
        $forceDelete = self::isTrue(self::util($utilities, 'selected_force_delete'));

        if (!self::deletePost($coupon->ID, $forceDelete)) {
            return self::error(__('Could not delete the coupon. Try again.', 'bit-integrations-pro'));
        }

        return self::success(
            $forceDelete ? __('Coupon deleted permanently.', 'bit-integrations-pro') : __('Coupon moved to the trash.', 'bit-integrations-pro'),
            $couponData
        );
    }

    public static function applyCouponToBooking($response, $fieldData, $integrationDetails = null)
    {
        $booking = self::findBooking($fieldData);

        if (\is_array($booking)) {
            return $booking;
        }

        $coupon = self::findPost(self::conf($integrationDetails, 'selectedCoupon'), Helper::COUPON_POST_TYPE);

        if (!$coupon || $coupon->post_status !== 'publish') {
            return self::error(__('Coupon is not found or not published. Select a published coupon in the action settings.', 'bit-integrations-pro'));
        }

        $now = time();
        $validFrom = (int) get_post_meta($coupon->ID, '_hb_coupon_date_from_timestamp', true);
        $validUntil = (int) get_post_meta($coupon->ID, '_hb_coupon_date_to_timestamp', true);

        if (($validFrom && $now < $validFrom) || ($validUntil && $now > $validUntil)) {
            return self::error(__('The coupon is not valid today. Change the coupon dates or select another coupon.', 'bit-integrations-pro'));
        }

        if (\in_array((string) $coupon->ID, array_map('strval', get_post_meta($booking->ID, '_hb_coupon_id')), true)) {
            return self::error(__('This coupon is already applied to the booking. Select another coupon.', 'bit-integrations-pro'));
        }

        $bookingInstance = WPHB_Booking::instance($booking->ID);
        $subtotal = (float) $bookingInstance->sub_total(false);
        $minimumSpend = (float) get_post_meta($coupon->ID, '_hb_minimum_spend', true);
        $maximumSpend = (float) get_post_meta($coupon->ID, '_hb_maximum_spend', true);

        if (($minimumSpend > 0 && $subtotal < $minimumSpend) || ($maximumSpend > 0 && $subtotal > $maximumSpend)) {
            return self::error(__('The booking subtotal is outside the coupon spend limits. Select another coupon.', 'bit-integrations-pro'));
        }

        $usageLimit = (int) get_post_meta($coupon->ID, '_hb_limit_per_coupon', true);

        if ($usageLimit > 0 && (int) get_post_meta($coupon->ID, '_hb_usage_count', true) >= $usageLimit) {
            return self::error(__('The coupon usage limit is reached. Select another coupon.', 'bit-integrations-pro'));
        }

        $discountValue = (float) get_post_meta($coupon->ID, '_hb_coupon_discount_value', true);
        $discount = get_post_meta($coupon->ID, '_hb_coupon_discount_type', true) === 'percent_cart'
            ? $subtotal * $discountValue / 100
            : $discountValue;
        $discount = min($discount, max(0, (float) $bookingInstance->sub_total(true)));

        add_post_meta($booking->ID, '_hb_coupon_id', $coupon->ID);
        add_post_meta($booking->ID, '_hb_coupon_code', $coupon->post_title);
        add_post_meta($booking->ID, '_hb_coupon_value', $discount);
        self::refreshBookingTotals($booking->ID);

        return self::success(__('Coupon applied to the booking successfully.', 'bit-integrations-pro'), Helper::getBookingData($booking->ID));
    }

    public static function removeCouponFromBooking($response, $fieldData)
    {
        $booking = self::findBooking($fieldData);

        if (\is_array($booking)) {
            return $booking;
        }

        if (empty(get_post_meta($booking->ID, '_hb_coupon_id'))) {
            return self::error(__('The booking has no coupon. Map a booking that has a coupon.', 'bit-integrations-pro'));
        }

        delete_post_meta($booking->ID, '_hb_coupon_id');
        delete_post_meta($booking->ID, '_hb_coupon_code');
        delete_post_meta($booking->ID, '_hb_coupon_value');
        self::refreshBookingTotals($booking->ID);

        return self::success(__('Coupon removed from the booking successfully.', 'bit-integrations-pro'), Helper::getBookingData($booking->ID));
    }

    public static function createRoom($response, $fieldData, $utilities = null)
    {
        if ($error = self::checkRequired($fieldData, ['title' => __('Room Name', 'bit-integrations-pro'), 'num_of_rooms' => __('Number of Rooms', 'bit-integrations-pro'), 'max_adults' => __('Max Adults per Room', 'bit-integrations-pro')])) {
            return $error;
        }

        if ($error = self::checkRoomNumbers($fieldData)) {
            return $error;
        }

        $status = self::util($utilities, 'selected_room_status') ?: 'publish';

        if (!\in_array($status, self::ROOM_STATUSES, true)) {
            return self::error(__('Room status is invalid. Select a status from the list.', 'bit-integrations-pro'));
        }

        $roomId = wp_insert_post(
            ['post_type' => Helper::ROOM_POST_TYPE, 'post_title' => $fieldData['title'], 'post_content' => $fieldData['description'] ?? '', 'post_status' => $status],
            true
        );

        if (is_wp_error($roomId)) {
            return self::error($roomId->get_error_message());
        }

        $roomMeta = self::prepareRoomMeta($fieldData);
        $roomMeta['_hb_featured_list'] = self::isTrue(self::util($utilities, 'selected_featured')) ? '1' : '';

        self::updatePostMetaValues($roomId, $roomMeta);
        self::saveRoomTypesAndPrice($roomId, $fieldData, $utilities);

        return self::success(__('Room created successfully.', 'bit-integrations-pro'), Helper::getRoomData($roomId));
    }

    public static function updateRoom($response, $fieldData, $utilities = null)
    {
        $room = self::findPostByField($fieldData, 'room_id', Helper::ROOM_POST_TYPE, __('Room', 'bit-integrations-pro'));

        if (\is_array($room)) {
            return $room;
        }

        if ($error = self::checkRoomNumbers($fieldData)) {
            return $error;
        }

        $status = self::util($utilities, 'selected_room_status');

        if ($status !== '' && !\in_array($status, self::ROOM_STATUSES, true)) {
            return self::error(__('Room status is invalid. Select a status from the list.', 'bit-integrations-pro'));
        }

        $postData = array_filter(
            ['post_title' => $fieldData['title'] ?? '', 'post_content' => $fieldData['description'] ?? '', 'post_status' => $status],
            static function ($value) {
                return $value !== '';
            }
        );

        if (!empty($postData)) {
            $updated = wp_update_post(array_merge(['ID' => $room->ID], $postData), true);

            if (is_wp_error($updated)) {
                return self::error($updated->get_error_message());
            }
        }

        $roomMeta = array_filter(
            self::prepareRoomMeta($fieldData),
            static function ($value) {
                return $value !== '';
            }
        );

        $featured = self::util($utilities, 'selected_featured');

        if ($featured !== '') {
            $roomMeta['_hb_featured_list'] = self::isTrue($featured) ? '1' : '';
        }

        self::updatePostMetaValues($room->ID, $roomMeta);
        self::saveRoomTypesAndPrice($room->ID, $fieldData, $utilities);

        if (isset($roomMeta['_hb_num_of_rooms'])) {
            self::recalculateRoomAvailability($room->ID);
        }

        return self::success(__('Room updated successfully.', 'bit-integrations-pro'), Helper::getRoomData($room->ID));
    }

    public static function deleteRoom($response, $fieldData, $utilities = null)
    {
        $room = self::findPostByField($fieldData, 'room_id', Helper::ROOM_POST_TYPE, __('Room', 'bit-integrations-pro'), true);

        if (\is_array($room)) {
            return $room;
        }

        $roomData = Helper::getRoomData($room->ID);
        $forceDelete = self::isTrue(self::util($utilities, 'selected_force_delete'));

        if (!self::deletePost($room->ID, $forceDelete)) {
            return self::error(__('Could not delete the room. Try again.', 'bit-integrations-pro'));
        }

        if ($forceDelete) {
            foreach (Helper::getPricingPlanIds($room->ID) as $planId) {
                hb_room_remove_pricing($planId);
            }
        }

        return self::success(
            $forceDelete ? __('Room deleted permanently.', 'bit-integrations-pro') : __('Room moved to the trash.', 'bit-integrations-pro'),
            $roomData
        );
    }

    public static function setRoomRegularPrice($response, $fieldData)
    {
        $room = self::findPostByField($fieldData, 'room_id', Helper::ROOM_POST_TYPE, __('Room', 'bit-integrations-pro'));

        if (\is_array($room)) {
            return $room;
        }

        $prices = self::getWeekdayPrices($fieldData);

        if (isset($prices['success'])) {
            return $prices;
        }

        $planId = hb_room_set_pricing_plan(['room_id' => $room->ID, 'plan_id' => Helper::getRegularPlanId($room->ID) ?: null, 'pricing' => $prices]);

        return self::pricingPlanResponse($room->ID, $planId, __('Room regular price saved successfully.', 'bit-integrations-pro'));
    }

    public static function addSeasonalPricingPlan($response, $fieldData)
    {
        if ($error = self::checkRequired($fieldData, ['start_date' => __('Start Date', 'bit-integrations-pro'), 'end_date' => __('End Date', 'bit-integrations-pro')])) {
            return $error;
        }

        $room = self::findPostByField($fieldData, 'room_id', Helper::ROOM_POST_TYPE, __('Room', 'bit-integrations-pro'));

        if (\is_array($room)) {
            return $room;
        }

        $startDate = self::parseInputDate($fieldData['start_date']);
        $endDate = self::parseInputDate($fieldData['end_date']);

        if (!$startDate || !$endDate) {
            return self::error(__('Start date or end date is invalid. Use the YYYY-MM-DD format.', 'bit-integrations-pro'));
        }

        if ($endDate < $startDate) {
            return self::error(__('End date must be on or after the start date. Change the dates.', 'bit-integrations-pro'));
        }

        $prices = self::getWeekdayPrices($fieldData);

        if (isset($prices['success'])) {
            return $prices;
        }

        $planId = hb_room_set_pricing_plan(['room_id' => $room->ID, 'start_time' => $startDate, 'end_time' => $endDate, 'pricing' => $prices]);

        return self::pricingPlanResponse($room->ID, $planId, __('Seasonal pricing plan added successfully.', 'bit-integrations-pro'));
    }

    public static function createRoomType($response, $fieldData, $utilities = null)
    {
        if ($error = self::checkRequired($fieldData, ['name' => __('Name', 'bit-integrations-pro')])) {
            return $error;
        }

        $termArgs = array_filter(
            [
                'description' => $fieldData['description'] ?? '',
                'slug'        => $fieldData['slug'] ?? '',
                'parent'      => absint(self::util($utilities, 'selected_parent_room_type')),
            ]
        );

        $term = wp_insert_term($fieldData['name'], Helper::ROOM_TYPE_TAXONOMY, $termArgs);

        if (is_wp_error($term)) {
            return self::error($term->get_error_message());
        }

        $roomType = get_term($term['term_id'], Helper::ROOM_TYPE_TAXONOMY);
        $roomTypeUrl = get_term_link($roomType);

        return self::success(
            __('Room type created successfully.', 'bit-integrations-pro'),
            [
                'term_id'     => $roomType->term_id,
                'name'        => $roomType->name,
                'slug'        => $roomType->slug,
                'description' => $roomType->description,
                'parent_id'   => $roomType->parent,
                'url'         => is_wp_error($roomTypeUrl) ? '' : $roomTypeUrl,
            ]
        );
    }

    public static function createExtra($response, $fieldData, $utilities = null)
    {
        if ($error = self::checkRequired($fieldData, ['title' => __('Extra Name', 'bit-integrations-pro'), 'price' => __('Price', 'bit-integrations-pro')])) {
            return $error;
        }

        if ($error = self::checkNumeric($fieldData, ['price' => __('Price', 'bit-integrations-pro')], 0)) {
            return $error;
        }

        $type = self::util($utilities, 'selected_extra_type') ?: 'trip';

        if (!\array_key_exists($type, hb_extra_types())) {
            return self::error(__('Extra type is invalid. Select a type from the list.', 'bit-integrations-pro'));
        }

        $extraId = wp_insert_post(
            ['post_type' => Helper::EXTRA_POST_TYPE, 'post_title' => $fieldData['title'], 'post_content' => $fieldData['description'] ?? '', 'post_status' => 'publish'],
            true
        );

        if (is_wp_error($extraId)) {
            return self::error($extraId->get_error_message());
        }

        self::updatePostMetaValues(
            $extraId,
            [
                'tp_hb_extra_room_price'           => $fieldData['price'],
                'tp_hb_extra_room_respondent_name' => ($fieldData['unit'] ?? '') ?: __('Package', 'bit-integrations-pro'),
                'tp_hb_extra_room_respondent'      => $type,
                'tp_hb_extra_room_required'        => self::isTrue(self::util($utilities, 'selected_required')) ? '1' : '',
            ]
        );

        return self::success(__('Extra created successfully.', 'bit-integrations-pro'), Helper::getExtraData($extraId));
    }

    public static function updateExtra($response, $fieldData, $utilities = null)
    {
        $extra = self::findPostByField($fieldData, 'extra_id', Helper::EXTRA_POST_TYPE, __('Extra', 'bit-integrations-pro'));

        if (\is_array($extra)) {
            return $extra;
        }

        if ($error = self::checkNumeric($fieldData, ['price' => __('Price', 'bit-integrations-pro')], 0)) {
            return $error;
        }

        $type = self::util($utilities, 'selected_extra_type');

        if ($type !== '' && !\array_key_exists($type, hb_extra_types())) {
            return self::error(__('Extra type is invalid. Select a type from the list.', 'bit-integrations-pro'));
        }

        $postData = array_filter(
            ['post_title' => $fieldData['title'] ?? '', 'post_content' => $fieldData['description'] ?? ''],
            static function ($value) {
                return $value !== '';
            }
        );

        if (!empty($postData)) {
            $updated = wp_update_post(array_merge(['ID' => $extra->ID], $postData), true);

            if (is_wp_error($updated)) {
                return self::error($updated->get_error_message());
            }
        }

        $extraMeta = array_filter(
            [
                'tp_hb_extra_room_price'           => $fieldData['price'] ?? '',
                'tp_hb_extra_room_respondent_name' => $fieldData['unit'] ?? '',
                'tp_hb_extra_room_respondent'      => $type,
            ],
            static function ($value) {
                return $value !== '';
            }
        );

        $required = self::util($utilities, 'selected_required');

        if ($required !== '') {
            $extraMeta['tp_hb_extra_room_required'] = self::isTrue($required) ? '1' : '';
        }

        self::updatePostMetaValues($extra->ID, $extraMeta);

        return self::success(__('Extra updated successfully.', 'bit-integrations-pro'), Helper::getExtraData($extra->ID));
    }

    public static function deleteExtra($response, $fieldData, $utilities = null)
    {
        $extra = self::findPostByField($fieldData, 'extra_id', Helper::EXTRA_POST_TYPE, __('Extra', 'bit-integrations-pro'), true);

        if (\is_array($extra)) {
            return $extra;
        }

        $extraData = Helper::getExtraData($extra->ID);
        $forceDelete = self::isTrue(self::util($utilities, 'selected_force_delete'));

        if (!self::deletePost($extra->ID, $forceDelete)) {
            return self::error(__('Could not delete the extra. Try again.', 'bit-integrations-pro'));
        }

        return self::success(
            $forceDelete ? __('Extra deleted permanently.', 'bit-integrations-pro') : __('Extra moved to the trash.', 'bit-integrations-pro'),
            $extraData
        );
    }

    public static function assignExtrasToRoom($response, $fieldData, $utilities = null, $integrationDetails = null)
    {
        $room = self::findPostByField($fieldData, 'room_id', Helper::ROOM_POST_TYPE, __('Room', 'bit-integrations-pro'));

        if (\is_array($room)) {
            return $room;
        }

        $extraIds = self::toIdList(self::conf($integrationDetails, 'selectedExtras'));

        if (empty($extraIds)) {
            return self::error(__('Extras are not selected. Select at least one extra in the action settings.', 'bit-integrations-pro'));
        }

        foreach ($extraIds as $extraId) {
            if (get_post_type($extraId) !== Helper::EXTRA_POST_TYPE || get_post_status($extraId) !== 'publish') {
                // translators: %d: Extra ID
                return self::error(\sprintf(__('Extra #%d is not found or not published. Select the extras again.', 'bit-integrations-pro'), $extraId));
            }
        }

        if (!self::isTrue(self::util($utilities, 'selected_replace_extras'))) {
            $currentExtraIds = array_filter(array_map('intval', (array) get_post_meta($room->ID, '_hb_room_extra', true)));
            $extraIds = array_values(array_unique(array_merge($currentExtraIds, $extraIds)));
        }

        update_post_meta($room->ID, '_hb_room_extra', $extraIds);

        return self::success(__('Extras assigned to the room successfully.', 'bit-integrations-pro'), Helper::getRoomData($room->ID));
    }

    public static function addRoomReview($response, $fieldData, $utilities = null)
    {
        if ($error = self::checkRequired($fieldData, ['author_name' => __('Reviewer Name', 'bit-integrations-pro'), 'author_email' => __('Reviewer Email', 'bit-integrations-pro'), 'content' => __('Review Content', 'bit-integrations-pro')])) {
            return $error;
        }

        if (!is_email($fieldData['author_email'])) {
            return self::error(__('Reviewer email is invalid. Map a valid email address.', 'bit-integrations-pro'));
        }

        $room = self::findPostByField($fieldData, 'room_id', Helper::ROOM_POST_TYPE, __('Room', 'bit-integrations-pro'));

        if (\is_array($room)) {
            return $room;
        }

        $rating = (int) self::util($utilities, 'selected_rating');
        $isRatingRequired = (bool) hb_settings()->get('enable_review_rating');

        if ($rating < 0 || $rating > 5 || ($isRatingRequired && $rating === 0)) {
            return self::error(
                $isRatingRequired
                    ? __('Rating is required. Select a rating from 1 to 5 in the Utilities.', 'bit-integrations-pro')
                    : __('Rating is invalid. Select a rating from 1 to 5.', 'bit-integrations-pro')
            );
        }

        $author = get_user_by('email', $fieldData['author_email']);
        $isApproved = !self::isTrue(self::util($utilities, 'selected_hold_for_moderation'));

        $reviewId = wp_insert_comment(
            [
                'comment_post_ID'      => $room->ID,
                'comment_author'       => $fieldData['author_name'],
                'comment_author_email' => $fieldData['author_email'],
                'comment_content'      => $fieldData['content'],
                'comment_type'         => 'comment',
                'comment_parent'       => 0,
                'comment_approved'     => $isApproved ? 1 : 0,
                'comment_date'         => current_time('mysql'),
                'user_id'              => $author ? $author->ID : 0,
            ]
        );

        if (!$reviewId) {
            return self::error(__('Could not add the review. Check the review fields and try again.', 'bit-integrations-pro'));
        }

        if (!empty($fieldData['title'])) {
            update_comment_meta($reviewId, 'hb_room_review_title', $fieldData['title']);
        }

        if ($rating > 0) {
            update_comment_meta($reviewId, 'rating', $rating);
        }

        if ($rating > 0 && $isApproved && class_exists('WPHB_Room')) {
            update_post_meta($room->ID, 'arveger_rating', WPHB_Room::instance($room->ID)->average_rating());
            update_post_meta($room->ID, 'arveger_rating_last_modify', time());
        }

        return self::success(__('Review added successfully.', 'bit-integrations-pro'), Helper::getReviewData($reviewId));
    }

    private static function findBooking($fieldData, $allowTrash = false)
    {
        return self::findPostByField($fieldData, 'booking_id', Helper::BOOKING_POST_TYPE, __('Booking', 'bit-integrations-pro'), $allowTrash);
    }

    private static function findPostByField($fieldData, $key, $postType, $label, $allowTrash = false)
    {
        if (!Helper::isPluginActive()) {
            return self::error(__('WP Hotel Booking is not active. Install and activate WP Hotel Booking.', 'bit-integrations-pro'));
        }

        $postId = $fieldData[$key] ?? '';

        if ($postId === '' || $postId === null) {
            // translators: %s: Record name, for example Booking or Room
            return self::error(\sprintf(__('%s ID is required. Map a numeric ID.', 'bit-integrations-pro'), $label));
        }

        if (!is_numeric($postId) || (int) $postId <= 0) {
            // translators: %s: Record name, for example Booking or Room
            return self::error(\sprintf(__('%s ID is not valid. Map a numeric ID.', 'bit-integrations-pro'), $label));
        }

        $post = self::findPost($postId, $postType);

        if (!$post) {
            // translators: %s: Record name, for example Booking or Room
            return self::error(\sprintf(__('%s is not found. Map a valid ID.', 'bit-integrations-pro'), $label));
        }

        if (!$allowTrash && $post->post_status === 'trash') {
            // translators: %s: Record name, for example Booking or Room
            return self::error(\sprintf(__('%s is in the trash. Restore it or map another ID.', 'bit-integrations-pro'), $label));
        }

        return $post;
    }

    private static function findPost($postId, $postType)
    {
        $post = is_numeric($postId) ? get_post((int) $postId) : null;

        return $post && $post->post_type === $postType ? $post : null;
    }

    private static function checkRequired($fieldData, array $fields)
    {
        if (!Helper::isPluginActive()) {
            return self::error(__('WP Hotel Booking is not active. Install and activate WP Hotel Booking.', 'bit-integrations-pro'));
        }

        foreach ($fields as $key => $label) {
            if (!isset($fieldData[$key]) || !\is_scalar($fieldData[$key]) || trim((string) $fieldData[$key]) === '') {
                // translators: %s: Field label
                return self::error(\sprintf(__('%s is required. Map a value to this field.', 'bit-integrations-pro'), $label));
            }
        }
    }

    private static function checkNumeric($fieldData, array $fields, $minimum = null)
    {
        foreach ($fields as $key => $label) {
            if (!isset($fieldData[$key]) || $fieldData[$key] === '') {
                continue;
            }

            if (!is_numeric($fieldData[$key])) {
                // translators: %s: Field label
                return self::error(\sprintf(__('%s must be a number. Map a numeric value.', 'bit-integrations-pro'), $label));
            }

            if ($minimum !== null && (float) $fieldData[$key] < $minimum) {
                // translators: 1: Field label, 2: Smallest allowed number
                return self::error(\sprintf(__('%1$s must be %2$d or more. Map a larger value.', 'bit-integrations-pro'), $label, $minimum));
            }
        }
    }

    private static function checkGuestCounts($fieldData)
    {
        if ($error = self::checkNumeric($fieldData, ['quantity' => __('Room Quantity', 'bit-integrations-pro'), 'adults' => __('Adults', 'bit-integrations-pro')], 1)) {
            return $error;
        }

        return self::checkNumeric($fieldData, ['children' => __('Children', 'bit-integrations-pro')], 0);
    }

    private static function checkRoomNumbers($fieldData)
    {
        if ($error = self::checkNumeric($fieldData, ['num_of_rooms' => __('Number of Rooms', 'bit-integrations-pro'), 'max_adults' => __('Max Adults per Room', 'bit-integrations-pro')], 1)) {
            return $error;
        }

        return self::checkNumeric($fieldData, ['max_children' => __('Max Children per Room', 'bit-integrations-pro'), 'beds' => __('Beds', 'bit-integrations-pro'), 'price' => __('Regular Price per Night', 'bit-integrations-pro')], 0);
    }

    private static function findBookableRoom($integrationDetails)
    {
        $room = self::findPost(self::conf($integrationDetails, 'selectedRoom'), Helper::ROOM_POST_TYPE);

        if (!$room) {
            return self::error(__('Room is not found. Select a room in the action settings.', 'bit-integrations-pro'));
        }

        if ($room->post_status !== 'publish') {
            return self::error(__('The room is not published, so it has no price. Publish the room or select another room.', 'bit-integrations-pro'));
        }

        return $room;
    }

    private static function parseInputDate($date)
    {
        $date = \is_string($date) ? trim($date) : '';

        if (!preg_match('/^(\d{4})-(\d{2})-(\d{2})$/', $date, $parts) || !checkdate((int) $parts[2], (int) $parts[3], (int) $parts[1])) {
            return 0;
        }

        return strtotime($date) ?: 0;
    }

    private static function parseStayDates($fieldData)
    {
        $checkInDate = self::parseInputDate($fieldData['check_in_date'] ?? '');
        $checkOutDate = self::parseInputDate($fieldData['check_out_date'] ?? '');

        if (!$checkInDate || !$checkOutDate) {
            return self::error(__('Check-in date or check-out date is invalid. Use the YYYY-MM-DD format.', 'bit-integrations-pro'));
        }

        if ($checkOutDate <= $checkInDate) {
            return self::error(__('Check-out date must be after the check-in date. Change the dates.', 'bit-integrations-pro'));
        }

        return [$checkInDate, $checkOutDate];
    }

    private static function checkAvailability($roomId, $checkInDate, $checkOutDate, $quantity)
    {
        $availableQuantity = hotel_booking_get_room_available($roomId, ['check_in_date' => $checkInDate, 'check_out_date' => $checkOutDate]);

        if (is_wp_error($availableQuantity)) {
            return self::error($availableQuantity->get_error_message());
        }

        if ((int) $availableQuantity < $quantity) {
            // translators: %d: Number of rooms that are free
            return self::error(\sprintf(__('Only %d room(s) are available for these dates. Decrease the quantity.', 'bit-integrations-pro'), (int) $availableQuantity));
        }
    }

    private static function calculateRoomPrice($roomId, $checkInDate, $checkOutDate, $quantity, $orderItemId = null)
    {
        $params = ['check_in_date' => $checkInDate, 'check_out_date' => $checkOutDate, 'quantity' => $quantity];

        if ($orderItemId) {
            $params['order_item_id'] = $orderItemId;
        }

        $product = hotel_booking_get_product_class($roomId, $params);
        $subtotal = (float) $product->amount_exclude_tax();
        $total = (float) $product->amount_include_tax();

        return ['subtotal' => $subtotal, 'total' => $total, 'tax_total' => $total - $subtotal];
    }

    private static function recalculateRoomAvailability($roomId)
    {
        if (class_exists('WPHB_Room_Booking_Available')) {
            WPHB_Room_Booking_Available::instance()->calculate_dates_available((int) $roomId);
        }
    }

    private static function addRequiredExtras($bookingId, $orderItemId, $roomId, $checkInDate, $checkOutDate, $roomQuantity)
    {
        if (!class_exists('HB_Room_Extra')) {
            return;
        }

        foreach (HB_Room_Extra::instance($roomId)->get_extra() as $extraId => $extra) {
            if (empty($extra->required)) {
                continue;
            }

            $product = hotel_booking_get_product_class(
                $extraId,
                ['check_in_date' => $checkInDate, 'check_out_date' => $checkOutDate, 'room_quantity' => $roomQuantity, 'quantity' => 1]
            );

            $subItemId = hb_add_order_item(
                $bookingId,
                ['order_item_name' => get_the_title($extraId), 'order_item_type' => 'sub_item', 'order_item_parent' => $orderItemId]
            );

            if (!$subItemId) {
                continue;
            }

            $subItemMeta = [
                'product_id'     => $extraId,
                'qty'            => 1,
                'check_in_date'  => $checkInDate,
                'check_out_date' => $checkOutDate,
                'subtotal'       => (float) $product->price,
                'total'          => (float) $product->price_tax,
                'tax_total'      => (float) $product->price_tax - (float) $product->price,
            ];

            foreach ($subItemMeta as $metaKey => $metaValue) {
                hb_update_order_item_meta($subItemId, $metaKey, $metaValue);
            }
        }
    }

    private static function refreshBookingTotals($bookingId)
    {
        $booking = WPHB_Booking::instance($bookingId);

        self::updatePostMetaValues($bookingId, ['_hb_tax' => (float) $booking->tax_total(), '_hb_advance_payment' => (float) $booking->total()]);
    }

    private static function releaseRoomDates($bookingId, $roomId)
    {
        if (empty($roomId)) {
            return;
        }

        $remainingRoomIds = array_column(Helper::getBookingItemsData($bookingId), 'product_id');

        if (!\in_array((int) $roomId, $remainingRoomIds, true)) {
            $datesBooked = get_post_meta($roomId, '_hb_dates_booked', true);

            if (\is_array($datesBooked) && isset($datesBooked[$bookingId])) {
                unset($datesBooked[$bookingId]);
                update_post_meta($roomId, '_hb_dates_booked', $datesBooked);
            }
        }

        WPHB_Booking::instance($bookingId)->update_room_booking($bookingId);
        self::recalculateRoomAvailability($roomId);
    }

    private static function prepareCouponMeta($fieldData, $discountType, $couponId = 0)
    {
        $isNew = !$couponId;

        if ($discountType !== '' && !\in_array($discountType, self::DISCOUNT_TYPES, true)) {
            return self::error(__('Discount type is invalid. Select a discount type from the list.', 'bit-integrations-pro'));
        }

        if ($isNew && $discountType === '') {
            return self::error(__('Discount type is required. Select a discount type in the action settings.', 'bit-integrations-pro'));
        }

        if ($error = self::checkNumeric($fieldData, ['discount_value' => __('Discount Value', 'bit-integrations-pro'), 'minimum_spend' => __('Minimum Spend', 'bit-integrations-pro'), 'maximum_spend' => __('Maximum Spend', 'bit-integrations-pro'), 'usage_limit' => __('Usage Limit', 'bit-integrations-pro')], 0)) {
            return $error;
        }

        $effectiveDiscountType = $discountType ?: get_post_meta($couponId, '_hb_coupon_discount_type', true);

        if ($effectiveDiscountType === 'percent_cart' && (float) self::mergedCouponValue($fieldData, 'discount_value', $couponId, '_hb_coupon_discount_value') > 100) {
            return self::error(__('A percent discount must be 100 or less. Map a smaller discount value.', 'bit-integrations-pro'));
        }

        $minimumSpend = (float) self::mergedCouponValue($fieldData, 'minimum_spend', $couponId, '_hb_minimum_spend');
        $maximumSpend = (float) self::mergedCouponValue($fieldData, 'maximum_spend', $couponId, '_hb_maximum_spend');

        if ($minimumSpend > 0 && $maximumSpend > 0 && $minimumSpend > $maximumSpend) {
            return self::error(__('Minimum spend must not be more than maximum spend. Change the spend limits.', 'bit-integrations-pro'));
        }

        $dateFrom = self::parseCouponDate($fieldData['date_from'] ?? '', false);
        $dateTo = self::parseCouponDate($fieldData['date_to'] ?? '', true);

        if ($dateFrom === false || $dateTo === false) {
            return self::error(__('Coupon date is invalid. Use the YYYY-MM-DD format.', 'bit-integrations-pro'));
        }

        $effectiveDateFrom = $dateFrom ?: (int) get_post_meta($couponId, '_hb_coupon_date_from_timestamp', true);
        $effectiveDateTo = $dateTo ?: (int) get_post_meta($couponId, '_hb_coupon_date_to_timestamp', true);

        if ($effectiveDateFrom && $effectiveDateTo && $effectiveDateTo < $effectiveDateFrom) {
            return self::error(__('Valid Until must be on or after Valid From. Change the coupon dates.', 'bit-integrations-pro'));
        }

        $couponMeta = [
            '_hb_coupon_description'         => $fieldData['description'] ?? '',
            '_hb_coupon_discount_type'       => $discountType,
            '_hb_coupon_discount_value'      => $fieldData['discount_value'] ?? '',
            '_hb_coupon_date_from'           => $dateFrom,
            '_hb_coupon_date_from_timestamp' => $dateFrom,
            '_hb_coupon_date_to'             => $dateTo,
            '_hb_coupon_date_to_timestamp'   => $dateTo,
            '_hb_minimum_spend'              => $fieldData['minimum_spend'] ?? '',
            '_hb_maximum_spend'              => $fieldData['maximum_spend'] ?? '',
            '_hb_limit_per_coupon'           => $fieldData['usage_limit'] ?? '',
        ];

        if ($isNew) {
            return $couponMeta;
        }

        return array_filter(
            $couponMeta,
            static function ($value) {
                return $value !== '';
            }
        );
    }

    private static function mergedCouponValue($fieldData, $fieldKey, $couponId, $metaKey)
    {
        if (isset($fieldData[$fieldKey]) && $fieldData[$fieldKey] !== '') {
            return $fieldData[$fieldKey];
        }

        return $couponId ? get_post_meta($couponId, $metaKey, true) : '';
    }

    private static function parseCouponDate($date, $isEndDate)
    {
        if ($date === '' || $date === null) {
            return '';
        }

        $timestamp = self::parseInputDate($date);

        if (!$timestamp) {
            return false;
        }

        return $isEndDate ? $timestamp + DAY_IN_SECONDS - 1 : $timestamp;
    }

    private static function findCouponIdByCode($code)
    {
        $couponIds = get_posts(
            [
                'post_type'   => Helper::COUPON_POST_TYPE,
                'post_status' => ['publish', 'draft', 'pending', 'private'],
                'title'       => $code,
                'fields'      => 'ids',
                'numberposts' => 1,
            ]
        );

        return empty($couponIds) ? 0 : (int) $couponIds[0];
    }

    private static function prepareRoomMeta($fieldData)
    {
        $roomMeta = [];

        foreach (self::ROOM_META_FIELDS as $fieldKey => $metaKey) {
            $roomMeta[$metaKey] = $fieldData[$fieldKey] ?? '';
        }

        return $roomMeta;
    }

    private static function saveRoomTypesAndPrice($roomId, $fieldData, $utilities)
    {
        $roomTypeIds = self::toIdList(self::util($utilities, 'selected_room_types'));

        if (!empty($roomTypeIds)) {
            wp_set_object_terms($roomId, $roomTypeIds, Helper::ROOM_TYPE_TAXONOMY);
        }

        if (isset($fieldData['price']) && is_numeric($fieldData['price'])) {
            hb_room_set_pricing_plan(
                [
                    'room_id' => $roomId,
                    'plan_id' => Helper::getRegularPlanId($roomId) ?: null,
                    'pricing' => array_fill(0, \count(Helper::WEEKDAYS), (float) $fieldData['price']),
                ]
            );
        }
    }

    private static function getWeekdayPrices($fieldData)
    {
        if (!isset($fieldData['price']) || !is_numeric($fieldData['price'])) {
            return self::error(__('Base price is required and must be a number. Map a numeric price.', 'bit-integrations-pro'));
        }

        $priceLabels = [
            'price'           => __('Base Price per Night', 'bit-integrations-pro'),
            'sunday_price'    => __('Sunday Price', 'bit-integrations-pro'),
            'monday_price'    => __('Monday Price', 'bit-integrations-pro'),
            'tuesday_price'   => __('Tuesday Price', 'bit-integrations-pro'),
            'wednesday_price' => __('Wednesday Price', 'bit-integrations-pro'),
            'thursday_price'  => __('Thursday Price', 'bit-integrations-pro'),
            'friday_price'    => __('Friday Price', 'bit-integrations-pro'),
            'saturday_price'  => __('Saturday Price', 'bit-integrations-pro'),
        ];

        if ($error = self::checkNumeric($fieldData, $priceLabels, 0)) {
            return $error;
        }

        $prices = [];

        foreach (Helper::WEEKDAYS as $index => $weekday) {
            $weekdayPrice = $fieldData[$weekday . '_price'] ?? '';
            $prices[$index] = $weekdayPrice !== '' ? (float) $weekdayPrice : (float) $fieldData['price'];
        }

        return $prices;
    }

    private static function pricingPlanResponse($roomId, $planId, $message)
    {
        if (!$planId) {
            return self::error(__('Could not save the pricing plan. Check the room and the prices, then try again.', 'bit-integrations-pro'));
        }

        $pricingPlan = [];

        foreach (Helper::getPricingPlansData($roomId) as $plan) {
            if ($plan['plan_id'] === (int) $planId) {
                $pricingPlan = $plan;

                break;
            }
        }

        return self::success($message, ['pricing_plan' => $pricingPlan, 'room' => Helper::getRoomData($roomId)]);
    }

    private static function deletePost($postId, $forceDelete)
    {
        if ($forceDelete) {
            return wp_delete_post($postId, true);
        }

        return get_post_status($postId) === 'trash' || wp_trash_post($postId);
    }

    private static function updatePostMetaValues($postId, $metaValues)
    {
        foreach ($metaValues as $metaKey => $metaValue) {
            update_post_meta($postId, $metaKey, $metaValue);
        }
    }

    private static function toIdList($value)
    {
        if (!\is_array($value)) {
            $value = explode(',', (string) $value);
        }

        return array_values(array_unique(array_filter(array_map('intval', $value))));
    }

    private static function isTrue($value)
    {
        return \in_array(strtolower((string) $value), ['1', 'true', 'yes', 'on'], true);
    }

    private static function conf($integrationDetails, $key)
    {
        $value = \is_object($integrationDetails) ? ($integrationDetails->{$key} ?? '') : ($integrationDetails[$key] ?? '');

        return \is_scalar($value) ? (string) $value : '';
    }

    private static function util($utilities, $key)
    {
        $value = \is_object($utilities) ? ($utilities->{$key} ?? '') : (\is_array($utilities) ? ($utilities[$key] ?? '') : '');

        return \is_scalar($value) ? (string) $value : '';
    }

    private static function success($message, $data = [])
    {
        return ['success' => true, 'message' => $message, 'data' => $data];
    }

    private static function error($message)
    {
        return ['success' => false, 'message' => $message];
    }
}
