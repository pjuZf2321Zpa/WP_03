<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Actions\Moosend\MoosendProHelper;
use BitApps\IntegrationsPro\Config;
use BitApps\IntegrationsPro\Core\Util\Hooks;

// Deprecated since v2.7.8 - use bit_integrations_moosend_* hooks instead
if (bit_integrations_version_below('2.7.8')) {
    Hooks::filter('btcbi_moosend_map_custom_fields', [MoosendProHelper::class, 'mapCustomFields'], 10, 3);
}

// New hooks since v2.7.8
Hooks::filter(Config::withFreePrefix('moosend_map_custom_fields'), [MoosendProHelper::class, 'mapCustomFields'], 10, 3);
