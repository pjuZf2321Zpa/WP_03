<?php

namespace FluentCartPro\App\Modules\Reports\Http\Controllers;

use FluentCart\App\Http\Controllers\Controller;
use FluentCart\App\Services\Report\ReportHelper;
use FluentCart\Framework\Http\Request\Request;
use FluentCartPro\App\Modules\Reports\Services\ProductInsightsService;

class ProductInsightsController extends Controller
{
    protected $params = [
        'paymentStatus',
        'orderTypes',
    ];

    public function detail(Request $request)
    {
        $params = ReportHelper::processParams($request->get('params'), $this->params, true);

        return ProductInsightsService::make()->getProductDetail($params, absint($request->get('product_id')));
    }

    public function comparison(Request $request)
    {
        $params = ReportHelper::processParams($request->get('params'), $this->params, true);

        return ProductInsightsService::make()->getProductComparison($params, $this->comparisonKeys($request)) + [
            'compare_ranges' => ReportHelper::formatCompareRanges($params),
        ];
    }

    public function comparisonSubscriptions(Request $request)
    {
        $params = ReportHelper::processParams($request->get('params'), $this->params, true);

        return ProductInsightsService::make()->getProductComparisonSubscriptions($params, $this->comparisonKeys($request));
    }

    public function comparisonOverlap(Request $request)
    {
        $params = ReportHelper::processParams($request->get('params'), $this->params, true);

        return ProductInsightsService::make()->getProductComparisonOverlap($params, $this->comparisonKeys($request));
    }

    public function comparisonLaunch(Request $request)
    {
        $params = ReportHelper::processParams($request->get('params'), $this->params, true);

        return ProductInsightsService::make()->getProductComparisonLaunch($params, $this->comparisonKeys($request));
    }

    // Item keys "p:ID" (a whole product) or "v:ID" (one variation); the service drops anything else
    private function comparisonKeys(Request $request): array
    {
        return array_map('sanitize_text_field', array_map('strval', (array) $request->get('items', [])));
    }
}
