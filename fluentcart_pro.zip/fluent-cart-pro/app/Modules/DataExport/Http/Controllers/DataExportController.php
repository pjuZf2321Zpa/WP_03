<?php

namespace FluentCartPro\App\Modules\DataExport\Http\Controllers;

use FluentCart\App\Http\Controllers\Controller;
use FluentCart\Framework\Http\Request\Request;
use FluentCartPro\App\Modules\DataExport\Exceptions\ExportRecordTooLargeException;
use FluentCartPro\App\Modules\DataExport\Services\ExportSchema;
use FluentCartPro\App\Modules\DataExport\Services\ExportService;
use WP_REST_Response;

class DataExportController extends Controller
{
    public function ordersSchema(): WP_REST_Response
    {
        return $this->sendSuccess( [
            'export' => ExportSchema::get( ExportSchema::ORDERS ),
        ] );
    }

    public function customersSchema(): WP_REST_Response
    {
        return $this->sendSuccess( [
            'export' => ExportSchema::get( ExportSchema::CUSTOMERS ),
        ] );
    }

    public function subscriptionsSchema(): WP_REST_Response
    {
        return $this->sendSuccess( [
            'export' => ExportSchema::get( ExportSchema::SUBSCRIPTIONS ),
        ] );
    }

    public function licensesSchema(): WP_REST_Response
    {
        if ( !ExportSchema::isAvailable( ExportSchema::LICENSES ) ) {
            return $this->sendError( [
                'message' => __( 'License export is unavailable because the licensing module is not active.', 'fluent-cart-pro' ),
            ], 409 );
        }

        return $this->sendSuccess( [
            'export' => ExportSchema::get( ExportSchema::LICENSES ),
        ] );
    }

    public function ordersBatch( Request $request ): WP_REST_Response
    {
        return $this->batch( $request, ExportSchema::ORDERS );
    }

    public function customersBatch( Request $request ): WP_REST_Response
    {
        return $this->batch( $request, ExportSchema::CUSTOMERS );
    }

    public function subscriptionsBatch( Request $request ): WP_REST_Response
    {
        return $this->batch( $request, ExportSchema::SUBSCRIPTIONS );
    }

    public function licensesBatch( Request $request ): WP_REST_Response
    {
        return $this->batch( $request, ExportSchema::LICENSES );
    }

    private function batch( Request $request, string $entity ): WP_REST_Response
    {
        if ( !ExportSchema::isAvailable( $entity ) ) {
            return $this->sendError( [
                'message' => __( 'This export module is not active.', 'fluent-cart-pro' ),
            ], 409 );
        }

        $payload = $this->sanitizePayload( $request, $entity );

        if ( is_wp_error( $payload ) ) {
            return $this->sendError( [
                'message' => $payload->get_error_message(),
            ], 422 );
        }

        try {
            $result = (new ExportService)->batch( $entity, $payload );
        } catch ( ExportRecordTooLargeException $exception ) {
            return $this->sendError( [
                'message' => $exception->getMessage(),
            ], 413 );
        }

        return $this->sendSuccess( [
            'export' => $result,
        ] );
    }

    /**
     * @return array|\WP_Error
     */
    private function sanitizePayload( Request $request, string $entity )
    {
        $format = sanitize_key( (string) $request->get( 'format', 'csv' ) );
        $scope = sanitize_key( (string) $request->get( 'scope', 'all' ) );

        if ( !in_array( $format, ['csv', 'json'], true ) ) {
            return new \WP_Error( 'invalid_export_format', __( 'Invalid export format.', 'fluent-cart-pro' ) );
        }

        if ( !in_array( $scope, ['current_page', 'selected', 'search_results', 'all'], true ) ) {
            return new \WP_Error( 'invalid_export_scope', __( 'Invalid export scope.', 'fluent-cart-pro' ) );
        }

        $rawIds = array_slice(
            array_filter( (array) $request->get( 'ids', [] ), 'is_scalar' ),
            0,
            5000
        );
        $ids = array_values( array_unique( array_filter( array_map( 'absint', $rawIds ) ) ) );

        if ( in_array( $scope, ['current_page', 'selected'], true ) && !$ids ) {
            return new \WP_Error( 'missing_export_ids', __( 'Select at least one record to export.', 'fluent-cart-pro' ) );
        }

        $requestedColumns = $this->sanitizeKeys( (array) $request->get( 'columns', [] ) );
        $requestedModules = $this->sanitizeKeys( (array) $request->get( 'modules', [] ) );
        $filters = $this->sanitizeFilters( (array) $request->get( 'filters', [] ) );
        $columns = ExportSchema::selectedColumns( $entity, $requestedColumns );

        if ( $format === 'csv' && !$columns ) {
            return new \WP_Error( 'missing_export_columns', __( 'Select at least one CSV column.', 'fluent-cart-pro' ) );
        }

        return [
            'format'      => $format,
            'scope'       => $scope,
            'ids'         => $ids,
            'columns'     => $columns,
            'modules'     => ExportSchema::selectedModules( $entity, $requestedModules ),
            'filters'     => $scope === 'all' ? [] : $filters,
            'cursor'      => absint( $request->get( 'cursor', 0 ) ),
            'max_records' => min( 1000, max( 100, absint( $request->get( 'max_records', 500 ) ) ) ),
        ];
    }

    private function sanitizeFilters( array $filters ): array
    {
        $allowed = [
            'filter_type',
            'search',
            'active_view',
            'sort_by',
            'sort_type',
            'advanced_filters',
            'user_tz',
        ];
        $sanitized = [];

        foreach ( $allowed as $key ) {
            if ( !array_key_exists( $key, $filters ) || is_array( $filters[$key] ) || is_object( $filters[$key] ) ) {
                continue;
            }

            $value = (string) $filters[$key];
            if ( $key === 'advanced_filters' ) {
                $decoded = json_decode( substr( $value, 0, 100000 ), true );
                $sanitized[$key] = is_array( $decoded ) ? wp_json_encode( $decoded ) : '[]';
            } else {
                $sanitized[$key] = sanitize_text_field( $value );
            }
        }

        return $sanitized;
    }

    private function sanitizeKeys( array $values ): array
    {
        $values = array_slice( $values, 0, 100 );

        return array_values( array_filter( array_map(
            'sanitize_key',
            array_filter( $values, 'is_scalar' )
        ) ) );
    }
}
