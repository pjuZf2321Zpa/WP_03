<?php

namespace FluentCartPro\App\Modules\InlineCheckout\Http;

use FluentCart\App\App;
use FluentCart\App\Helpers\Helper;
use FluentCart\Framework\Support\Arr;
use FluentCart\App\Services\Renderer\CheckoutRenderer;
use FluentCartPro\App\Modules\InlineCheckout\Cart\InlineCartService;
use FluentCartPro\App\Modules\InlineCheckout\Config\InlineCheckoutConfig;
use FluentCartPro\App\Modules\InlineCheckout\Renderer\InlineCheckoutItemsRenderer;

/**
 * The selector's two AJAX verbs, served on core's checkout route.
 *
 * Riding `fluent_cart/checkout/route_response` rather than registering a
 * `wp_ajax_` pair of our own means one nonce policy, one WP_Error-to-422
 * mapping and one response envelope for the whole checkout — and it keeps the
 * fragments these verbs return identical in shape to the ones a coupon or an
 * address change returns, because they come back through the same pipe.
 */
class InlineCheckoutAjaxHandler
{
    /**
     * @return void
     */
    public function register(): void
    {
        add_filter('fluent_cart/checkout/route_response', [$this, 'serve'], 10, 2);
    }

    /**
     * @param array|\WP_Error|null $result
     * @param array $context ['action' => string] The requested fc_checkout_action.
     * @return array|\WP_Error|null
     */
    public function serve($result, $context)
    {
        $action = Arr::get((array)$context, 'action');

        if ($action === 'inline_materialize_cart') {
            return $this->materializeCart();
        }

        if ($action === 'inline_select_item') {
            return $this->selectItem();
        }

        return $result;
    }

    /**
     * Create the cart on the shopper's first sign of purchase intent.
     *
     * Rendering the page deliberately writes nothing — a selector sits on
     * ordinary content pages, which crawlers hit far harder than a checkout
     * page — so the row is minted here instead.
     *
     * @return array|\WP_Error
     */
    protected function materializeCart()
    {
        $variationIds = $this->intList(App::request()->get('variation_ids', []));

        if (!$variationIds) {
            return new \WP_Error(
                'no_items',
                __('No purchasable item was selected.', 'fluent-cart-pro')
            );
        }

        // selection_mode must come from the client. Defaulting it to 'single'
        // would make a multi-select checkout persist only its first item when
        // the shopper types into a field before touching the list — the cart
        // would then bill for one row while three sat ticked on screen.
        //
        // The display settings travel for the same reason the ids do: no
        // surface is rendering on this request, and whatever is normalized here
        // is what materialize() PERSISTS as the cart's inline_config. Leaving
        // them out stored an empty heading, and the next fragment refresh —
        // which rebuilds from the stored config — reverted a configured
        // selector label to "Order summary" on every page load.
        $config = InlineCheckoutConfig::normalize([
            'page_id'        => absint(App::request()->get('page_id', 0)),
            'selector_label' => (string)App::request()->get('selector_label', ''),
            'max_items'      => absint(App::request()->get('max_items', 0)),
            'variant_ids'    => $variationIds,
            'selection_mode' => App::request()->get('selection_mode', 'single'),
        ], 'ajax');

        // What is currently ticked, falling back to the surface's default when
        // the client did not say — the case for a plain field-blur intent.
        $selectedIds = $this->intList(App::request()->get('selected_ids', []));

        if (!$selectedIds) {
            $selectedIds = InlineCartService::defaultSelectionIds($config);
        }

        $cart = InlineCartService::setSelection($selectedIds, $config);

        if (is_wp_error($cart)) {
            return $cart;
        }

        return [
            'cart_hash'  => $this->resolvableCartHash($cart),
            'cart_ready' => 'yes',
        ];
    }

    /**
     * Replace the selection, and hand back the markup that changed.
     *
     * The fragments come back in THIS response rather than through a follow-up
     * request, which is how applying a coupon behaves. The order-bump handler
     * does the opposite — returns nothing and fires an event that triggers a
     * second round trip — and that would double the requests for something a
     * shopper may click repeatedly.
     *
     * @return array|\WP_Error
     */
    protected function selectItem()
    {
        // The client sends its COMPLETE selection, never a toggle delta. Two
        // rapid un-ticks otherwise overlap: each request reads the cart before
        // the other has saved, both compute from the same stale base, and the
        // second undoes the first — the totals then disagree with the boxes.
        $selectedIds = $this->intList(App::request()->get('selected_ids', []));

        $cart = InlineCartService::findForDevice(absint(App::request()->get('page_id', 0)));

        // Start from the config the cart was materialized with, so the author
        // settings that never travel with an AJAX request survive it: the
        // selection cap, the heading, the button and empty-state copy.
        $rawConfig = $cart ? InlineCartService::configFromCart($cart) : [];

        // The CURRENT page's offer list and selection mode win over the stored
        // ones. A device cart can be reused across pages, so a cart minted on a
        // single-select checkout must not collapse a multi-select page to one
        // item while that page is showing checkboxes.
        //
        // Trusting the client for these is safe: resolveVariations() re-resolves
        // and re-gates every id server-side, so a forged list buys nothing.
        $requestVariantIds = $this->intList(App::request()->get('variant_ids', []));

        if ($requestVariantIds) {
            $rawConfig['variant_ids'] = $requestVariantIds;
        }

        $rawConfig['selection_mode'] = App::request()->get('selection_mode', 'single');

        // No post is in scope on an AJAX request, so the page the selector
        // belongs to has to travel with it — it is what keys the cart row.
        $rawConfig['page_id'] = absint(App::request()->get('page_id', 0));

        // Presence decides, not truthiness. An empty label that was SENT means
        // "this page has no heading of its own" and must overwrite whatever the
        // cart stored; only a genuinely absent parameter falls back.
        $requestLabel = App::request()->get('selector_label', null);

        if ($requestLabel !== null) {
            $rawConfig['selector_label'] = (string)$requestLabel;
        }

        $requestMaxItems = absint(App::request()->get('max_items', 0));

        if ($requestMaxItems) {
            $rawConfig['max_items'] = $requestMaxItems;
        }

        $config = InlineCheckoutConfig::normalize($rawConfig, 'ajax');

        $result = InlineCartService::setSelection($selectedIds, $config);

        if (is_wp_error($result)) {
            return $result;
        }

        $cart = $result;

        return [
            'cart_hash'       => $this->resolvableCartHash($cart),
            'cart_ready'      => 'yes',
            'fragments'       => $this->fragments($cart, $config),
            'total'           => $cart->getEstimatedTotal(),
            'formatted_total' => Helper::toDecimal($cart->getEstimatedTotal()),
        ];
    }

    /**
     * @param \FluentCart\App\Models\Cart $cart
     * @param array $config
     * @return array
     */
    protected function fragments($cart, array $config): array
    {
        $variations = InlineCheckoutConfig::resolveVariations($config);
        $renderer = new InlineCheckoutItemsRenderer($cart, $config, $variations);
        $checkoutRenderer = new CheckoutRenderer($cart);

        return [
            [
                'selector' => '[data-fluent-cart-checkout-page-cart-items-wrapper]',
                'content'  => $renderer->getHtml(false),
                'type'     => 'replace',
            ],
            [
                'selector' => '[data-fluent-cart-checkout-payment-methods]',
                'content'  => $checkoutRenderer->getFragment('payment_methods'),
                'type'     => 'replace',
            ],
            // Shipping is patched rather than triggering a page reload the way
            // the order bump does: a selector can sit well below the fold, so a
            // reload would throw away the shopper's scroll position and any
            // fields they had already filled.
            [
                'selector' => '[data-fluent-cart-checkout-page-shipping-methods-wrapper]',
                'content'  => $checkoutRenderer->getFragment('shipping_methods'),
                'type'     => 'replace',
            ],
        ];
    }

    /**
     * The cart hash a client may safely echo back on later requests.
     *
     * Empty for anything core's hash branch cannot match. That branch returns
     * null early rather than falling through to the cookie path, so handing a
     * client a hash it cannot resolve gets that hash attached to every later
     * request and every one of them then resolves nothing: "No active cart
     * found" on a coupon, "Cart is empty" on place order.
     *
     * Empty is the correct answer rather than a fallback — those carts resolve
     * by cookie, the way the rest of the checkout resolves them.
     *
     * @param \FluentCart\App\Models\Cart|null $cart
     * @return string
     */
    protected function resolvableCartHash($cart): string
    {
        if (!$cart || !$cart->exists) {
            return '';
        }

        return InlineCartService::isSelectorCart($cart) ? $cart->cart_hash : '';
    }

    /**
     * Accepts either a repeated array parameter or a comma-separated string,
     * because both shapes reach this handler depending on how the request was
     * built.
     *
     * @param mixed $raw
     * @return int[]
     */
    protected function intList($raw): array
    {
        if (!is_array($raw)) {
            $raw = array_filter(array_map('trim', explode(',', (string)$raw)));
        }

        $ids = [];
        foreach ($raw as $value) {
            $id = (int)$value;
            if ($id > 0) {
                $ids[] = $id;
            }
        }

        return $ids;
    }
}
