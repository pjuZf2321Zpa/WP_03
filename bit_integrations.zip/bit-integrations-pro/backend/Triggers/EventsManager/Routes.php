<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Core\Util\Route;
use BitApps\IntegrationsPro\Triggers\EventsManager\EventsManagerController;

Route::get('eventsmanager/get', [EventsManagerController::class, 'getAllTasks']);
