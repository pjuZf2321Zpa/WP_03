<?php
/**
 * Paid realtime-voice configuration: the Live voice conversation card's settings in the Voice side panel.
 */
if (!defined('ABSPATH')) {
    exit;
}

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Included template variables are local to the Chatbot renderer.
if (!class_exists('\WPAICG\aipkit_dashboard') || !\WPAICG\aipkit_dashboard::is_pro_plan()) {
    return;
}
$live_settings = \WPAICG\Lib\Chat\LiveSettings::sanitize($active_bot_settings ?? []);
$is_live_engine = $live_settings['voice_engine'] === 'live';
$engine_display = static fn(string $engine): string => ($engine === 'live') === $is_live_engine ? '' : 'display: none;';

// Rows like the panel's other cards: a name and hint, then the choice.
$render_rt_copy = static function (string $title, string $hint = '', string $for = ''): void {
    ?>
    <span class="aipkit_answer_style_copy">
        <?php if ($for !== '') : ?>
            <label class="aipkit_answer_style_title" for="<?php echo esc_attr($for); ?>"><?php echo esc_html($title); ?></label>
        <?php else : ?>
            <span class="aipkit_answer_style_title"><?php echo esc_html($title); ?></span>
        <?php endif; ?>
        <?php if ($hint !== '') : ?>
            <span class="aipkit_answer_style_hint"><?php echo esc_html($hint); ?></span>
        <?php endif; ?>
    </span>
    <?php
};
$render_rt_switch = static function (string $name, string $title, string $hint, string $value, bool $disabled = false) use ($bot_id, $render_rt_copy, $rt_controls_disabled): void {
    $field_id = 'aipkit_bot_' . $bot_id . '_' . $name . '_sheet';
    ?>
    <label class="aipkit_answer_style_switch_label" for="<?php echo esc_attr($field_id); ?>">
        <?php $render_rt_copy($title, $hint); ?>
        <span class="aipkit_switch">
            <input type="checkbox" id="<?php echo esc_attr($field_id); ?>" name="<?php echo esc_attr($name); ?>" value="1" <?php checked($value, '1'); ?> <?php disabled($rt_controls_disabled || $disabled); ?> />
            <span class="aipkit_switch_slider" aria-hidden="true"></span>
        </span>
    </label>
    <?php
};
?>
<div
    class="aipkit_realtime_voice_settings_container aipkit_voice_rows"
    style="display: <?php echo $rt_force_visible ? 'block' : (($enable_realtime_voice === '1') ? 'block' : 'none'); ?>;"
    <?php echo $rt_force_visible ? 'data-force-visible="1"' : ''; ?>
>
    <div class="aipkit_voice_live_note">
        <span class="dashicons dashicons-info-outline" aria-hidden="true"></span>
        <span class="aipkit_voice_live_note_text"><?php esc_html_e('Uses your OpenAI key; usage is billed to your OpenAI account.', 'gpt3-ai-content-generator'); ?></span>
        <?php if (current_user_can('manage_options')) : ?>
            <button type="button" class="aipkit_panel_link" data-aipkit-realtime-connect <?php echo !empty($openai_api_key) ? 'hidden' : ''; ?>><span class="aipkit_panel_link_label"><?php esc_html_e('Connect OpenAI', 'gpt3-ai-content-generator'); ?></span></button>
        <?php else : ?>
            <span class="aipkit_voice_live_note_text" data-aipkit-realtime-admin-hint <?php echo !empty($openai_api_key) ? 'hidden' : ''; ?>><?php esc_html_e('Ask an administrator to connect OpenAI.', 'gpt3-ai-content-generator'); ?></span>
        <?php endif; ?>
    </div>
    <input type="hidden" name="voice_engine" value="<?php echo esc_attr($live_settings['voice_engine']); ?>">
    <select name="realtime_model" hidden>
        <?php foreach (array_unique(array_merge($realtime_models, [$realtime_model])) as $model_id): ?>
            <option value="<?php echo esc_attr($model_id); ?>" <?php selected($realtime_model, $model_id); ?>><?php echo esc_html($model_id); ?></option>
        <?php endforeach; ?>
    </select>

    <?php // The picker settles beside its select, so both sit directly in the row. ?>
    <div class="aipkit_answer_style_row aipkit_answer_style_row--inline aipkit_rt_dependent">
        <?php $render_rt_copy(__('Model', 'gpt3-ai-content-generator'), __('GPT Live thinks before it speaks; the others answer fastest.', 'gpt3-ai-content-generator'), 'aipkit_bot_' . $bot_id . '_voice_model_picker'); ?>
        <select id="aipkit_bot_<?php echo esc_attr($bot_id); ?>_voice_model_picker" class="aipkit_look_select" data-aipkit-voice-model-picker data-aipkit-universal-model-provider="OpenAI" data-aipkit-universal-model-capability="realtime" <?php disabled($rt_controls_disabled); ?>>
            <option value="gpt-live" <?php selected($is_live_engine); ?>>GPT Live</option>
            <?php foreach (array_unique(array_merge($realtime_models, [$realtime_model])) as $model_id): ?>
                <option value="<?php echo esc_attr($model_id); ?>" <?php selected(!$is_live_engine && $realtime_model === $model_id); ?>><?php echo esc_html($model_id); ?></option>
            <?php endforeach; ?>
        </select>
    </div>

    <?php
    // GPT Live: its voice, the model that thinks, and how long a conversation may run.
    $live_fields = [
        'live_voice' => [__('Voice', 'gpt3-ai-content-generator'), __('How it sounds.', 'gpt3-ai-content-generator'), array_combine(\WPAICG\Lib\Chat\LiveSettings::voices(), array_map('ucfirst', \WPAICG\Lib\Chat\LiveSettings::voices()))],
        'live_backend_model' => [__('Reasoning model', 'gpt3-ai-content-generator'), __('Does the thinking behind each reply.', 'gpt3-ai-content-generator'), ['gpt-5.6-terra' => 'GPT-5.6 Terra', 'gpt-5.6-luna' => 'GPT-5.6 Luna']],
        'live_max_seconds' => [__('Time limit', 'gpt3-ai-content-generator'), __('Each conversation ends after this.', 'gpt3-ai-content-generator'), ['60' => __('1 minute', 'gpt3-ai-content-generator'), '180' => __('3 minutes', 'gpt3-ai-content-generator'), '300' => __('5 minutes', 'gpt3-ai-content-generator'), '600' => __('10 minutes', 'gpt3-ai-content-generator'), '900' => __('15 minutes', 'gpt3-ai-content-generator')]],
    ];
    foreach ($live_fields as $field_name => [$field_label, $field_hint, $field_choices]):
        $field_id = 'aipkit_bot_' . $bot_id . '_' . $field_name . '_sheet';
        ?>
        <div class="aipkit_answer_style_row aipkit_answer_style_row--inline aipkit_rt_dependent" data-voice-engine="live" style="<?php echo esc_attr($engine_display('live')); ?>">
            <?php $render_rt_copy($field_label, $field_hint, $field_id); ?>
            <select id="<?php echo esc_attr($field_id); ?>" name="<?php echo esc_attr($field_name); ?>" <?php if ($field_name === 'live_backend_model'): ?>data-aipkit-universal-model-provider="OpenAI" data-aipkit-universal-model-capability="live"<?php endif; ?> class="aipkit_look_select" <?php disabled($rt_controls_disabled); ?>>
                <?php foreach ($field_choices as $choice_value => $choice_label): ?>
                    <option value="<?php echo esc_attr($choice_value); ?>" <?php selected($live_settings[$field_name], (string) $choice_value); ?>><?php echo esc_html($choice_label); ?></option>
                <?php endforeach; ?>
            </select>
        </div>
    <?php endforeach; ?>

    <?php // Realtime models: their voice, and when they answer. ?>
    <div class="aipkit_answer_style_row aipkit_answer_style_row--inline aipkit_rt_dependent" data-voice-engine="realtime" style="<?php echo esc_attr($engine_display('realtime')); ?>">
        <?php $render_rt_copy(__('Voice', 'gpt3-ai-content-generator'), __('How it sounds.', 'gpt3-ai-content-generator'), 'aipkit_bot_' . $bot_id . '_realtime_voice_sheet'); ?>
        <select id="aipkit_bot_<?php echo esc_attr($bot_id); ?>_realtime_voice_sheet" name="realtime_voice" class="aipkit_look_select" <?php disabled($rt_controls_disabled); ?>>
            <?php foreach ($realtime_voices as $voice_id): ?>
                <option value="<?php echo esc_attr($voice_id); ?>" <?php selected($realtime_voice, $voice_id); ?>><?php echo esc_html(ucfirst($voice_id)); ?></option>
            <?php endforeach; ?>
        </select>
    </div>
    <div class="aipkit_answer_style_row aipkit_answer_style_row--inline aipkit_rt_dependent" data-voice-engine="realtime" style="<?php echo esc_attr($engine_display('realtime')); ?>">
        <?php $render_rt_copy(__('When to respond', 'gpt3-ai-content-generator'), __('Smart waits until they finish a thought.', 'gpt3-ai-content-generator')); ?>
        <div class="aipkit_answer_style_control">
            <div class="aipkit_segmented" role="group" aria-label="<?php esc_attr_e('When to respond', 'gpt3-ai-content-generator'); ?>" data-aipkit-segmented-for="aipkit_bot_<?php echo esc_attr($bot_id); ?>_turn_detection_sheet">
                <?php foreach (['server_vad' => __('Automatic', 'gpt3-ai-content-generator'), 'semantic_vad' => __('Smart', 'gpt3-ai-content-generator')] as $turn_value => $turn_label) : ?>
                    <button type="button" class="aipkit_segmented_option" data-value="<?php echo esc_attr($turn_value); ?>" aria-pressed="<?php echo $turn_detection === $turn_value ? 'true' : 'false'; ?>" <?php disabled($rt_controls_disabled); ?>><?php echo esc_html($turn_label); ?></button>
                <?php endforeach; ?>
            </div>
            <select id="aipkit_bot_<?php echo esc_attr($bot_id); ?>_turn_detection_sheet" name="turn_detection" aria-hidden="true" tabindex="-1" hidden <?php disabled($rt_controls_disabled); ?>>
                <option value="server_vad" <?php selected($turn_detection, 'server_vad'); ?>><?php esc_html_e('Automatic', 'gpt3-ai-content-generator'); ?></option>
                <option value="semantic_vad" <?php selected($turn_detection, 'semantic_vad'); ?>><?php esc_html_e('Smart', 'gpt3-ai-content-generator'); ?></option>
            </select>
        </div>
    </div>

    <div class="aipkit_answer_style_row aipkit_answer_style_row--switch aipkit_rt_dependent">
        <?php $render_rt_switch('direct_voice_mode', __('Start with voice', 'gpt3-ai-content-generator'), __('The chat button opens ready to talk. For chat buttons only.', 'gpt3-ai-content-generator'), (string) $direct_voice_mode, (bool) $direct_voice_mode_disabled); ?>
    </div>

    <div class="aipkit_voice_live_note aipkit_voice_live_note--soft aipkit_rt_dependent" data-voice-engine="live" style="<?php echo esc_attr($engine_display('live')); ?>">
        <span class="dashicons dashicons-info-outline" aria-hidden="true"></span>
        <span class="aipkit_voice_live_note_text">
            <?php esc_html_e('GPT Live uses your instructions and Web search. Knowledge, uploads, chat history and actions are not available in Live yet.', 'gpt3-ai-content-generator'); ?>
            <?php esc_html_e('Voice time is charged at the GPT Live rate in Usage → Pricing, and thinking at chat prices; without a rate, time is only logged.', 'gpt3-ai-content-generator'); ?>
        </span>
    </div>

    <?php // Rarely changed: folded under More settings. ?>
    <details class="aipkit_voice_more aipkit_rt_dependent" data-voice-engine="realtime" style="<?php echo esc_attr($engine_display('realtime')); ?>">
        <summary class="aipkit_voice_more_summary">
            <span class="aipkit_answer_style_copy">
                <span class="aipkit_answer_style_title"><?php esc_html_e('More settings', 'gpt3-ai-content-generator'); ?></span>
                <span class="aipkit_answer_style_hint"><?php esc_html_e('Noise reduction, audio format and speed.', 'gpt3-ai-content-generator'); ?></span>
            </span>
            <span class="aipkit_voice_more_chevron dashicons dashicons-arrow-down-alt2" aria-hidden="true"></span>
        </summary>
        <div class="aipkit_answer_style_row aipkit_answer_style_row--switch">
            <?php $render_rt_switch('input_audio_noise_reduction', __('Noise reduction', 'gpt3-ai-content-generator'), __('Filters background noise from their microphone.', 'gpt3-ai-content-generator'), (string) $input_audio_noise_reduction); ?>
        </div>
        <div class="aipkit_answer_style_row aipkit_answer_style_row--inline aipkit_audio_format_field">
            <?php
            $render_rt_copy(__('Audio format', 'gpt3-ai-content-generator'), __('Change only for phone lines.', 'gpt3-ai-content-generator'), 'aipkit_bot_' . $bot_id . '_audio_format_combo_sheet');
            $audio_format_current_label = sprintf(
                /* translators: 1: input audio format, 2: output audio format */
                __('In: %1$s / Out: %2$s', 'gpt3-ai-content-generator'),
                $input_audio_format ?: 'pcm16',
                $output_audio_format ?: 'pcm16'
            );
            ?>
            <select id="aipkit_bot_<?php echo esc_attr($bot_id); ?>_audio_format_combo_sheet" class="aipkit_look_select aipkit_audio_format_combo_select" <?php disabled($rt_controls_disabled); ?>>
                <option value="current" selected><?php echo esc_html($audio_format_current_label); ?></option>
                <optgroup label="<?php esc_attr_e('Input', 'gpt3-ai-content-generator'); ?>">
                    <option value="in:pcm16">pcm16</option>
                    <option value="in:g711_ulaw">g711_ulaw</option>
                    <option value="in:g711_alaw">g711_alaw</option>
                </optgroup>
                <optgroup label="<?php esc_attr_e('Output', 'gpt3-ai-content-generator'); ?>">
                    <option value="out:pcm16">pcm16</option>
                    <option value="out:g711_ulaw">g711_ulaw</option>
                    <option value="out:g711_alaw">g711_alaw</option>
                </optgroup>
            </select>
            <select id="aipkit_bot_<?php echo esc_attr($bot_id); ?>_input_audio_format_sheet" name="input_audio_format" hidden <?php disabled($rt_controls_disabled); ?>>
                <option value="pcm16" <?php selected($input_audio_format, 'pcm16'); ?>>pcm16</option>
                <option value="g711_ulaw" <?php selected($input_audio_format, 'g711_ulaw'); ?>>g711_ulaw</option>
                <option value="g711_alaw" <?php selected($input_audio_format, 'g711_alaw'); ?>>g711_alaw</option>
            </select>
            <select id="aipkit_bot_<?php echo esc_attr($bot_id); ?>_output_audio_format_sheet" name="output_audio_format" hidden <?php disabled($rt_controls_disabled); ?>>
                <option value="pcm16" <?php selected($output_audio_format, 'pcm16'); ?>>pcm16</option>
                <option value="g711_ulaw" <?php selected($output_audio_format, 'g711_ulaw'); ?>>g711_ulaw</option>
                <option value="g711_alaw" <?php selected($output_audio_format, 'g711_alaw'); ?>>g711_alaw</option>
            </select>
        </div>
        <div class="aipkit_answer_style_row aipkit_answer_style_row--inline">
            <?php $render_rt_copy(__('Voice speed', 'gpt3-ai-content-generator'), __('1 is natural.', 'gpt3-ai-content-generator'), 'aipkit_bot_' . $bot_id . '_speed_sheet'); ?>
            <div class="aipkit_voice_speed">
                <input
                    type="range"
                    id="aipkit_bot_<?php echo esc_attr($bot_id); ?>_speed_sheet"
                    name="speed"
                    class="aipkit_form-input aipkit_range_slider aipkit_popover_slider"
                    min="0.25"
                    max="1.5"
                    step="0.05"
                    value="<?php echo esc_attr($speed); ?>"
                    <?php disabled($rt_controls_disabled); ?>
                />
                <span id="aipkit_bot_<?php echo esc_attr($bot_id); ?>_speed_sheet_value" class="aipkit_voice_speed_value"><?php echo esc_html(number_format($speed, 2)); ?></span>
            </div>
        </div>
    </details>
</div>
