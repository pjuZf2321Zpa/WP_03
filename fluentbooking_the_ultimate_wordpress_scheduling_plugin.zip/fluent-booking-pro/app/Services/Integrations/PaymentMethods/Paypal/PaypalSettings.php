<?php

namespace FluentBookingPro\App\Services\Integrations\PaymentMethods\Paypal;

use FluentBookingPro\App\Services\Integrations\PaymentMethods\PaymentHelper;

class PaypalSettings
{
    public $settings;

    protected $methodHandler = 'fluent_booking_payment_settings_paypal';

    public function __construct()
    {
        $settings = get_option($this->methodHandler, []);

        $settings = wp_parse_args($settings, static::getDefaults());

        $this->settings = $settings;
    }

    /**
     * @return array with default fields value
     */
    public static function getDefaults()
    {
        return [
            'is_active'                => 'no',
            'paypal_email'             => '',
            'payment_mode'             => 'test',
            'disable_ipn_verification' => 'no',
            'payment_label'            => __('Pay with PayPal', 'fluent-booking-pro')
        ];
    }

    public function get()
    {
        return $this->settings;
    }

    public function isActive()
    {
        return $this->settings['is_active'] == 'yes';
    }

    /**
     * Skipping the postback lets anyone forge a completed payment, so the switch is honoured in
     * sandbox only. `fluent_booking/paypal_allow_unverified_live_ipn` opts a live site back in.
     */
    public function isEnabledIPN()
    {
        if (!$this->isTest() && !apply_filters('fluent_booking/paypal_allow_unverified_live_ipn', false, $this->settings)) {
            return true;
        }

        return $this->settings['disable_ipn_verification'] != 'yes';
    }

    public function isTest()
    {
        return $this->getMode() == 'test';
    }

    public function getMode()
    {
        return $this->settings['payment_mode'];
    }

    public function getPaypalEmail()
    {
        return $this->settings['paypal_email'];
    }

    public static function getIpnUrl()
    {
        return (new PaymentHelper('paypal'))->listenerUrl();
    }
}
