<?php
/**
 * View admin/courses/ui.
 *
 * @var string  $main_file
 * @var string  $plugin
 * @var string  $name
 * @var boolean $is_installed
 * @var string  $redirect_url
 */

defined('ABSPATH') || exit;

$button_action = $is_installed ? 'activate' : 'install';
$button_label  = $is_installed ? __('Activate Courses Add-On', 'memberpress') : __('Install & Activate Courses Add-On', 'memberpress');
?>

<div class="wrap">

  <div class="mepr-sister-plugin mepr-sister-plugin-wp-mail-smtp">

    <div class="mepr-sister-plugin-image mp-courses-image">
      <img src="<?php echo esc_url(MEPR_BRAND_URL . '/images/courses-logo.svg'); ?>" width="800" height="216" alt="">
    </div>

    <div class="mepr-sister-plugin-title">
      <?php esc_html_e('Build & Sell Courses Quickly & Easily with MemberPress', 'memberpress'); ?>
    </div>

    <div class="mepr-sister-plugin-description">
      <?php esc_html_e('Get all the ease of use you expect from MemberPress combined with powerful LMS features designed to make building online courses super simple. This add-on boils it down to a basic, click-and-go process.', 'memberpress'); ?>
    </div>

    <div class="mepr-sister-plugin-info mepr-clearfix">
      <div class="mepr-sister-plugin-info-image">
        <div>
          <img src="<?php echo esc_url(MEPR_BRAND_URL . '/images/courses-screenshot.png'); ?>" alt="<?php esc_attr_e('MemberPress Courses curriculum builder', 'memberpress'); ?>">
        </div>
      </div>
      <div class="mepr-sister-plugin-info-features">
        <ul>
          <li style="margin-bottom: 5px; font-size: 13px;"><i class="mp-icon mp-icon-right-big"></i><?php esc_html_e('Powerful LMS features', 'memberpress'); ?></li>
          <li style="margin-bottom: 5px; font-size: 13px;"><i class="mp-icon mp-icon-right-big"></i><?php esc_html_e('Included with every MemberPress license', 'memberpress'); ?></li>
          <li style="margin-bottom: 5px; font-size: 13px;"><i class="mp-icon mp-icon-right-big"></i><?php esc_html_e('Create beautiful courses out of the box w/ Classroom Mode', 'memberpress'); ?></li>
          <li style="margin-bottom: 5px; font-size: 13px;"><i class="mp-icon mp-icon-right-big"></i><?php esc_html_e('Fully visual drag-and-drop curriculum builder', 'memberpress'); ?></li>
          <li style="margin-bottom: 5px; font-size: 13px;"><i class="mp-icon mp-icon-right-big"></i><?php esc_html_e('Protect content with MemberPress access rules', 'memberpress'); ?></li>
          <li style="margin-bottom: 5px; font-size: 13px;"><i class="mp-icon mp-icon-right-big"></i><?php esc_html_e('Track learners\' progress', 'memberpress'); ?></li>
        </ul>
      </div>
    </div>

    <div class="mepr-sister-plugin-step mepr-sister-plugin-step-no-number mepr-sister-plugin-step-current mepr-clearfix">
      <div class="mepr-sister-plugin-step-detail">
        <div class="mepr-sister-plugin-step-title">
          <?php if ($is_installed) : // Installed but not active. ?>
                <?php esc_html_e('Enable Courses', 'memberpress'); ?>
          <?php else : // Not installed. ?>
              <?php esc_html_e('Install and Activate MemberPress Courses', 'memberpress'); ?>
          <?php endif; ?>
        </div>
        <div class="mepr-sister-plugin-step-button">
          <button
            type="button"
            class="mepr-feature-plugin button button-primary button-hero"
            data-action="<?php echo esc_attr($button_action); ?>"
            data-slug="<?php echo esc_attr($plugin); ?>"
            data-plugin="<?php echo esc_attr($main_file); ?>"
            data-name="<?php echo esc_attr($name); ?>"
            data-redirect="<?php echo esc_url($redirect_url); ?>"
          >
            <?php echo esc_html($button_label); ?>
          </button>
        </div>
        <div class="mepr-feature-plugin-notice notice inline" style="display:none;"><p></p></div>
      </div>
    </div>

  </div>
</div>
