<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

class woocs_woo_stat {

	public $orders_table = '';

	public function __construct() {

		global $wpdb;
		$this->orders_table = $wpdb->prefix . 'wc_order_stats';
	}

	public function init() {
		add_action( 'woocommerce_analytics_update_order_stats', array( $this, 'recalculate_order_stats' ) );
		// add_action('woocommerce_order_status_changed', 'recalculate_order_stats', 10, 3);
	}

	public function recalculate_order_stats( $order_id ) {
		global $wpdb;
		global $WOOCS;
		// hpos
		// $_order_currency = get_post_meta($order_id, '_order_currency', true);
		// $order_rate = get_post_meta($order_id, '_woocs_order_rate', true);
		// $order_recalculated = get_post_meta($order_id, 'woocs_order_stat_recalculated', true);
		$order              = wc_get_order( $order_id );
		$_order_currency    = $order->get_currency();
		$order_rate         = $order->get_meta( '_woocs_order_rate', true );
		$order_recalculated = $order->get_meta( 'woocs_order_stat_recalculated', true );

		$currencies = $WOOCS->get_currencies();
		$decimals   = 2;
		if ( isset( $currencies[ $_order_currency ] ) && array_key_exists( 'decimals', $currencies[ $_order_currency ] ) ) {
			$decimals = intval( $currencies[ $_order_currency ]['decimals'] );
		}
		if ( ! $order_rate ) {
			if ( isset( $currencies[ $_order_currency ] ) ) {
				$order_rate = $currencies[ $_order_currency ]['rate'];
			} else {
				return false;
			}
		}
		if ( $_order_currency == $WOOCS->default_currency ) {
			return false;
		}
		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
		$order_data = $wpdb->get_row( $wpdb->prepare( "SELECT total_sales,tax_total,shipping_total,net_total FROM {$this->orders_table} WHERE order_id = %d", $order_id ), ARRAY_A );

		foreach ( $order_data as $key => $value ) {
			$order_data[ $key ] = $WOOCS->back_convert( $value, $order_rate, $decimals );
		}
		$format = array(
			'%f',
			'%f',
			'%f',
			'%f',
		);
		$wpdb->update(
			$this->orders_table,
			$order_data,
			array( 'order_id' => $order_id ),
			$format,
			array( '%d' )
		);
		$order->update_meta_data( 'woocs_order_stat_recalculated', true );
	}

	public function recalculate_all_stats() {
		global $wpdb;
		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
		$order_ids = $wpdb->get_col( "SELECT order_id FROM {$this->orders_table} WHERE 1 " );
		foreach ( $order_ids as $order_id ) {
			$this->recalculate_order_stats( $order_id );
		}
	}
}
