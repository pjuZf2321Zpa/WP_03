<?php

namespace BitApps\IntegrationsPro\Actions\FluentCart;

use Exception;
use FluentCart\App\Models\Coupon;
use FluentCart\App\Models\Customer;
use FluentCart\App\Models\Order;
use FluentCart\App\Models\OrderItem;
use FluentCart\App\Models\Product;

class FluentCartProHelper
{
    public static function createOrder($defaultResponse, $orderData, $utilities, $integrationDetails)
    {
        if (!self::isFluentCartActive()) {
            return self::errorResponse('FluentCart is not installed or activated');
        }

        if (empty($integrationDetails->selectedProduct)) {
            return self::errorResponse('At least one product is required to create an order');
        }

        $customerId = isset($integrationDetails->selectedCustomer) ? absint($integrationDetails->selectedCustomer) : 0;

        if (empty($customerId)) {
            return self::errorResponse('Customer ID is required');
        }

        $customer = Customer::find($customerId);
        if (!$customer) {
            return self::errorResponse('Customer not found');
        }

        try {
            $orderDetails = [
                'customer_id'           => $customerId,
                'status'                => isset($utilities->selected_order_status) ? $utilities->selected_order_status : 'pending',
                'payment_status'        => isset($utilities->selected_payment_status) ? $utilities->selected_payment_status : 'pending',
                'shipping_status'       => isset($utilities->selected_shipping_status) ? $utilities->selected_shipping_status : 'unshipped',
                'fulfillment_type'      => isset($utilities->selected_fulfillment_type) ? $utilities->selected_fulfillment_type : 'physical',
                'type'                  => $orderData['type'] ?? 'payment',
                'mode'                  => $orderData['mode'] ?? 'live',
                'currency'              => $orderData['currency'] ?? 'USD',
                'payment_method'        => $orderData['payment_method'] ?? '',
                'payment_method_title'  => $orderData['payment_method_title'] ?? '',
                'subtotal'              => isset($orderData['subtotal']) ? \floatval($orderData['subtotal']) : 0,
                'discount_tax'          => isset($orderData['discount_tax']) ? \floatval($orderData['discount_tax']) : 0,
                'manual_discount_total' => isset($orderData['manual_discount_total']) ? \floatval($orderData['manual_discount_total']) : 0,
                'coupon_discount_total' => isset($orderData['coupon_discount_total']) ? \floatval($orderData['coupon_discount_total']) : 0,
                'shipping_tax'          => isset($orderData['shipping_tax']) ? \floatval($orderData['shipping_tax']) : 0,
                'shipping_total'        => isset($orderData['shipping_total']) ? \floatval($orderData['shipping_total']) : 0,
                'tax_total'             => isset($orderData['tax_total']) ? \floatval($orderData['tax_total']) : 0,
                'total_amount'          => isset($orderData['total_amount']) ? \floatval($orderData['total_amount']) : 0,
                'rate'                  => isset($orderData['rate']) ? \floatval($orderData['rate']) : 1.0,
                'tax_behavior'          => isset($orderData['tax_behavior']) ? \intval($orderData['tax_behavior']) : 0,
                'note'                  => $orderData['note'] ?? '',
            ];

            $order = Order::create($orderDetails);

            if (!$order) {
                return self::errorResponse('Failed to create order');
            }

            $productIds = isset($integrationDetails->selectedProduct) && \is_string($integrationDetails->selectedProduct)
            ? explode(',', $integrationDetails->selectedProduct)
            : [];

            foreach ($productIds as $productId) {
                $product = Product::with('variants')->find($productId);

                if (!$product) {
                    continue;
                }

                $productTitle = isset($product->post_title) ? sanitize_text_field($product->post_title) : 'Product';
                $unitPrice = isset($product->variants[0]->item_price) ? \floatval($product->variants[0]->item_price) : 0;
                $quantity = isset($integrationDetails->productQuantity) ? absint($integrationDetails->productQuantity) : 1;
                $subtotal = $unitPrice * $quantity;

                OrderItem::create(
                    [
                        'order_id'   => $order->id,
                        'post_id'    => $productId,
                        'post_title' => $productTitle,
                        'title'      => $productTitle,
                        'quantity'   => $quantity,
                        'unit_price' => $unitPrice,
                        'subtotal'   => $subtotal,
                        'line_total' => $subtotal,
                    ]
                );
            }

            $subtotal = OrderItem::where('order_id', $order->id)->sum('line_total');

            // Calculate total_amount: subtotal + shipping + tax - discounts.
            $totalAmount = $subtotal
            + $order->shipping_total
            + $order->tax_total
            + $order->shipping_tax
            - $order->manual_discount_total
            - $order->coupon_discount_total;

            $order->update(
                [
                    'subtotal'     => $subtotal,
                    'total_amount' => $totalAmount,
                ]
            );

            return self::successResponse('Order created successfully', ['order' => $order->fresh()->toArray()]);
        } catch (Exception $e) {
            return self::errorResponse($e->getMessage());
        }
    }

    public static function deleteOrder($defaultResponse, $orderData)
    {
        if (!self::isFluentCartActive()) {
            return self::errorResponse('FluentCart is not installed or activated');
        }

        $orderId = isset($orderData['order_id']) ? sanitize_text_field($orderData['order_id']) : '';

        if (empty($orderId)) {
            return self::errorResponse('Order ID is required');
        }

        $order = Order::find((int) $orderId);
        if (!$order) {
            return self::errorResponse('Order not found with Order Id: ' . $orderId);
        }

        try {
            $deleted = $order->delete();

            if (!$deleted) {
                throw new Exception('Failed to delete order');
            }

            return self::successResponse('Order deleted successfully', ['order_id' => $orderId]);
        } catch (Exception $e) {
            return self::errorResponse($e->getMessage());
        }
    }

    public static function updateOrderStatus($defaultResponse, $orderData)
    {
        if (!self::isFluentCartActive()) {
            return self::errorResponse('FluentCart is not installed or activated');
        }

        $orderId = isset($orderData['order_id']) ? sanitize_text_field($orderData['order_id']) : '';
        $status = isset($orderData['status']) ? sanitize_text_field($orderData['status']) : '';

        if (empty($orderId) || empty($status)) {
            return self::errorResponse('Order id and status are required');
        }

        $order = Order::find((int) $orderId);
        if (!$order) {
            return self::errorResponse('Order not found with Order Id: ' . $orderId);
        }

        try {
            $order->updateStatus('status', $status);

            return self::successResponse('Order status updated successfully', ['order' => $order->toArray()]);
        } catch (Exception $e) {
            return self::errorResponse($e->getMessage());
        }
    }

    public static function updatePaymentStatus($defaultResponse, $orderData)
    {
        if (!self::isFluentCartActive()) {
            return self::errorResponse('FluentCart is not installed or activated');
        }

        $orderId = isset($orderData['order_id']) ? sanitize_text_field($orderData['order_id']) : '';
        $paymentStatus = isset($orderData['payment_status']) ? sanitize_text_field($orderData['payment_status']) : '';

        if (empty($orderId) || empty($paymentStatus)) {
            return self::errorResponse('Order Id and payment status are required');
        }

        $order = Order::find((int) $orderId);
        if (!$order) {
            return self::errorResponse('Order not found with Order Id: ' . $orderId);
        }

        try {
            $order->updateStatus('payment_status', $paymentStatus);

            return self::successResponse('Payment status updated successfully', ['order' => $order->toArray()]);
        } catch (Exception $e) {
            return self::errorResponse($e->getMessage());
        }
    }

    public static function updateShippingStatus($defaultResponse, $orderData)
    {
        if (!self::isFluentCartActive()) {
            return self::errorResponse('FluentCart is not installed or activated');
        }

        $orderId = isset($orderData['order_id']) ? sanitize_text_field($orderData['order_id']) : '';
        $shippingStatus = isset($orderData['shipping_status']) ? sanitize_text_field($orderData['shipping_status']) : '';

        if (empty($orderId) || empty($shippingStatus)) {
            return self::errorResponse('Order Id and shipping status are required');
        }

        $order = Order::find((int) $orderId);
        if (!$order) {
            return self::errorResponse('Order not found with Order Id: ' . $orderId);
        }

        try {
            $order->update(['shipping_status' => $shippingStatus]);

            return self::successResponse('Shipping status updated successfully', ['order' => $order->toArray()]);
        } catch (Exception $e) {
            return self::errorResponse($e->getMessage());
        }
    }

    public static function createCustomer($defaultResponse, $customerData)
    {
        if (!self::isFluentCartActive()) {
            return self::errorResponse('FluentCart is not installed or activated');
        }

        $email = isset($customerData['email']) ? sanitize_email($customerData['email']) : '';

        if (empty($email)) {
            return self::errorResponse('Email is required');
        }

        try {
            $existingCustomer = Customer::where('email', $email)->first();
            if ($existingCustomer) {
                return self::errorResponse('Customer with this email already exists');
            }

            $customerDetails = [
                'email'      => $email,
                'first_name' => $customerData['first_name'] ?? '',
                'last_name'  => $customerData['last_name'] ?? '',
                'country'    => $customerData['country'] ?? '',
                'city'       => $customerData['city'] ?? '',
                'state'      => $customerData['state'] ?? '',
                'postcode'   => $customerData['postcode'] ?? '',
                'notes'      => $customerData['notes'] ?? '',
            ];

            $customer = Customer::create($customerDetails);

            if (!$customer) {
                throw new Exception('Failed to create customer');
            }

            return self::successResponse('Customer created successfully', ['customer' => $customer->toArray()]);
        } catch (Exception $e) {
            return self::errorResponse($e->getMessage());
        }
    }

    public static function updateCustomer($defaultResponse, $customerData)
    {
        if (!self::isFluentCartActive()) {
            return self::errorResponse('FluentCart is not installed or activated');
        }

        $email = isset($customerData['email']) ? sanitize_email($customerData['email']) : '';

        if (empty($email)) {
            return self::errorResponse('Customer Email is required');
        }

        $customer = Customer::where('email', $email)->first();
        if (!$customer) {
            return self::errorResponse('Customer not found with email: ' . $email);
        }

        try {
            $updateData = [];
            if (isset($customerData['new_email']) && !empty($customerData['new_email'])) {
                $updateData['email'] = sanitize_email($customerData['new_email']);
            }
            if (isset($customerData['first_name'])) {
                $updateData['first_name'] = sanitize_text_field($customerData['first_name']);
            }
            if (isset($customerData['last_name'])) {
                $updateData['last_name'] = sanitize_text_field($customerData['last_name']);
            }
            if (isset($customerData['status'])) {
                $updateData['status'] = sanitize_text_field($customerData['status']);
            }
            if (isset($customerData['country'])) {
                $updateData['country'] = sanitize_text_field($customerData['country']);
            }
            if (isset($customerData['city'])) {
                $updateData['city'] = sanitize_text_field($customerData['city']);
            }
            if (isset($customerData['state'])) {
                $updateData['state'] = sanitize_text_field($customerData['state']);
            }
            if (isset($customerData['postcode'])) {
                $updateData['postcode'] = sanitize_text_field($customerData['postcode']);
            }
            if (isset($customerData['notes'])) {
                $updateData['notes'] = sanitize_textarea_field($customerData['notes']);
            }

            if (!empty($updateData)) {
                $customer->update($updateData);
            }

            return self::successResponse('Customer updated successfully', ['customer' => $customer->toArray()]);
        } catch (Exception $e) {
            return self::errorResponse($e->getMessage());
        }
    }

    public static function deleteCustomer($defaultResponse, $customerData)
    {
        if (!self::isFluentCartActive()) {
            return self::errorResponse('FluentCart is not installed or activated');
        }

        $email = isset($customerData['email']) ? sanitize_email($customerData['email']) : '';

        if (empty($email)) {
            return self::errorResponse('Customer Email is required');
        }

        $customer = Customer::where('email', $email)->first();
        if (!$customer) {
            return self::errorResponse('Customer not found with email: ' . $email);
        }

        try {
            $deleted = $customer->delete();

            if (!$deleted) {
                throw new Exception('Failed to delete customer');
            }

            return self::successResponse('Customer deleted successfully', ['email' => $email]);
        } catch (Exception $e) {
            return self::errorResponse($e->getMessage());
        }
    }

    public static function createProduct($defaultResponse, $productData, $utilities, $integrationDetails)
    {
        if (!self::isFluentCartActive()) {
            return self::errorResponse('FluentCart is not installed or activated');
        }

        $title = isset($productData['post_title']) ? sanitize_text_field($productData['post_title']) : '';

        if (empty($title)) {
            return self::errorResponse('Product title is required');
        }

        $productType = isset($integrationDetails->product_type) ? $integrationDetails->product_type : 'physical';

        try {
            $productDetails = [
                'post_title'     => $title,
                'product_type'   => $productType,
                'post_name'      => isset($productData['post_name']) ? sanitize_title($productData['post_name']) : sanitize_title($title),
                'post_excerpt'   => isset($productData['post_excerpt']) ? sanitize_textarea_field($productData['post_excerpt']) : '',
                'post_content'   => isset($productData['post_content']) ? wp_kses_post($productData['post_content']) : '',
                'post_status'    => isset($productData['product_status']) ? sanitize_text_field($productData['product_status']) : 'publish',
                'product_price'  => isset($productData['product_price']) ? \floatval($productData['product_price']) : 0,
                'stock_quantity' => isset($productData['stock_quantity']) ? \intval($productData['stock_quantity']) : 0,
                'compare_price'  => isset($productData['compare_price']) ? \floatval($productData['compare_price']) : 0,
                'stock_status'   => isset($productData['stock_status']) ? sanitize_text_field($productData['stock_status']) : 'in_stock',
            ];

            $product = Product::create($productDetails);

            if (!$product) {
                return self::errorResponse('Failed to create product');
            }

            self::processGalleryImages($productData['gallery_image_ids'] ?? [], $product->ID);

            if (isset($productData['featured_media_id'])) {
                set_post_thumbnail($product->ID, \intval($productData['featured_media_id']));
            }

            if (isset($utilities->selected_product_categories)) {
                $categories = explode(',', $utilities->selected_product_categories);

                wp_set_post_terms($product->ID, $categories, 'product-categories');
            }

            if (isset($utilities->selected_product_brands)) {
                $brands = explode(',', $utilities->selected_product_brands);

                wp_set_post_terms($product->ID, $brands, 'product-brands');
            }

            if (
                isset($productData['product_price'])
                && \floatval($productData['product_price']) > 0
                && class_exists('\FluentCart\App\Models\ProductDetail')
                && class_exists('\FluentCart\App\Models\ProductVariation')
            ) {
                $price = \floatval($productData['product_price']) * 100;
                $manageStock = isset($productData['stock_quantity']) && \intval($productData['stock_quantity']) > 0 ? 1 : 0;
                $fulfillmentType = $productType;
                $manageDownloadable = $fulfillmentType === 'digital' && isset($productData['manage_downloadable']) && $productData['manage_downloadable'] ? 1 : 0;

                $otherInfo = [];

                if (isset($utilities->selected_product_shipping_class)) {
                    $otherInfo['shipping_class'] = \intval($utilities->selected_product_shipping_class);
                }

                \FluentCart\App\Models\ProductDetail::create(
                    [
                        'post_id'             => $product->ID,
                        'min_price'           => $price,
                        'max_price'           => $price,
                        'manage_stock'        => $manageStock,
                        'fulfillment_type'    => $fulfillmentType,
                        'manage_downloadable' => $manageDownloadable,
                        'other_info'          => empty($otherInfo) ? null : $otherInfo,
                    ]
                );

                $comparePrice = isset($productData['compare_price'])
                    ? \floatval($productData['compare_price']) * 100
                    : 0;

                $variationData = [
                    'post_id'         => $product->ID,
                    'variation_title' => 'Default',
                    'item_price'      => $price,
                    'compare_price'   => $comparePrice,
                    'manage_stock'    => $manageStock,
                    'stock_status'    => $fulfillmentType !== 'digital' && isset($productData['stock_status']) ? $productData['stock_status'] : 'in-stock'
                ];

                if ($fulfillmentType !== 'digital') {
                    $variationData['total_stock'] = isset($productData['stock_quantity']) ? \intval($productData['stock_quantity']) : 0;
                    $variationData['available'] = isset($productData['stock_quantity']) ? \intval($productData['stock_quantity']) : 0;
                }

                \FluentCart\App\Models\ProductVariation::create($variationData);
            }

            return self::successResponse('Product created successfully', ['product' => $product->fresh()->toArray()]);
        } catch (Exception $e) {
            return self::errorResponse($e->getMessage());
        }
    }

    public static function deleteProduct($defaultResponse, $productData)
    {
        if (!self::isFluentCartActive()) {
            return self::errorResponse('FluentCart is not installed or activated');
        }

        $productSlug = isset($productData['product_slug']) ? sanitize_text_field($productData['product_slug']) : '';

        if (empty($productSlug)) {
            return self::errorResponse('Product Slug is required');
        }

        $product = Product::where('post_name', $productSlug)->first();

        if (!$product) {
            return self::errorResponse('Product not found with slug: ' . $productSlug);
        }

        try {
            $deleted = $product->delete();

            if (!$deleted) {
                throw new Exception('Failed to delete product');
            }

            return self::successResponse('Product deleted successfully', ['product_slug' => $productSlug]);
        } catch (Exception $e) {
            return self::errorResponse($e->getMessage());
        }
    }

    public static function createCoupon($defaultResponse, $couponData, $integrationDetails)
    {
        if (!self::isFluentCartActive()) {
            return self::errorResponse('FluentCart is not installed or activated');
        }

        $code = isset($couponData['code']) ? sanitize_text_field($couponData['code']) : '';

        if (\is_null($code) || $code === '') {
            return self::errorResponse('Coupon code is required');
        }

        if (!isset($integrationDetails->discountType)) {
            return self::errorResponse('Discount type is required in integration details');
        }

        try {
            $existingCoupon = Coupon::where('code', $code)->first();

            if ($existingCoupon) {
                return self::errorResponse('Coupon with this code already exists');
            }

            $couponDetails = [
                'code'   => $code,
                'title'  => $couponData['title'] ?? $code,
                'type'   => $integrationDetails->discountType ?? 'percentage',
                'amount' => isset($couponData['amount']) ? absint($couponData['amount']) : 0,
                'status' => $couponData['status'] ?? 'active',
            ];

            $coupon = Coupon::create($couponDetails);

            if (!$coupon) {
                throw new Exception('Failed to create coupon');
            }

            return self::successResponse('Coupon created successfully', ['coupon' => $coupon->toArray()]);
        } catch (Exception $e) {
            return self::errorResponse($e->getMessage());
        }
    }

    public static function deleteCoupon($defaultResponse, $couponData)
    {
        if (!self::isFluentCartActive()) {
            return self::errorResponse('FluentCart is not installed or activated');
        }

        $code = isset($couponData['code']) ? sanitize_text_field($couponData['code']) : '';

        if (empty($code)) {
            return self::errorResponse('Coupon Code is required');
        }

        $coupon = Coupon::where('code', $code)->first();
        if (!$coupon) {
            return self::errorResponse('Coupon not found with code: ' . $code);
        }

        try {
            $deleted = $coupon->delete();

            if (!$deleted) {
                throw new Exception('Failed to delete coupon');
            }

            return self::successResponse('Coupon deleted successfully', ['code' => $code]);
        } catch (Exception $e) {
            return self::errorResponse($e->getMessage());
        }
    }

    private static function isFluentCartActive()
    {
        return \defined('FLUENTCART_PLUGIN_PATH')
            && class_exists('\FluentCart\App\Models\Order')
            && class_exists('\FluentCart\App\Models\Customer')
            && class_exists('\FluentCart\App\Models\Product')
            && class_exists('\FluentCart\App\Models\Coupon');
    }

    private static function successResponse($message, $data = [])
    {
        return [
            'success' => true,
            'message' => __($message, 'bit-integrations-pro'),
            'data'    => $data
        ];
    }

    private static function errorResponse($message)
    {
        return [
            'success' => false,
            'message' => __($message, 'bit-integrations-pro')
        ];
    }

    private static function processGalleryImages($galleryImageIds, $productId): void
    {
        if (empty($galleryImageIds)) {
            return;
        }

        $galleryImageIds = \is_array($galleryImageIds)
            ? $galleryImageIds
            : explode(',', $galleryImageIds);

        $galleryImageIds = array_map('intval', array_map('trim', $galleryImageIds));

        $gallery = [];
        foreach ($galleryImageIds as $imageId) {
            if ($imageURL = wp_get_attachment_url($imageId)) {
                $gallery[] = [
                    'id'    => $imageId,
                    'title' => get_the_title($imageId) ?? '',
                    'url'   => $imageURL,
                ];
            }
        }

        if (\count($gallery)) {
            update_post_meta($productId, 'fluent-products-gallery-image', $gallery);
            set_post_thumbnail($productId, reset($gallery)['id']);
        }
    }
}
