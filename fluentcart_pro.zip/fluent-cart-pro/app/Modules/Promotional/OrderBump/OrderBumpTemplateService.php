<?php

namespace FluentCartPro\App\Modules\Promotional\OrderBump;

use FluentCartPro\App\Modules\Promotional\OrderBump\Cards\AbstractCard;

/**
 * The order bump card designs, kept as block markup like the PDF receipt templates.
 * The two built-in cards match the cards the shop draws today; an admin can edit them
 * and go back to the default. Placeholders such as {{bump.title}} are filled in per offer.
 */
class OrderBumpTemplateService
{
    // One row for each card: saving one card cannot rewrite the other, even when two saves overlap.
    const OPTION_PREFIX = 'order_bump_template_';

    // The cards an admin added: key => title. Each card's markup is still its own row.
    const CUSTOM_OPTION = 'order_bump_custom_templates';

    const MAX_CUSTOM = 20;

    public static function optionKey(string $key): string
    {
        return self::OPTION_PREFIX . $key;
    }

    /**
     * @return string[] The option rows the cards use: one per card, and the list of custom cards.
     */
    public static function optionKeys(): array
    {
        $keys = array_map([self::class, 'optionKey'], OrderBumpSettings::allKeys());
        $keys[] = self::CUSTOM_OPTION;

        return $keys;
    }

    /**
     * @return array<string,string> Custom card key => title.
     */
    public static function customTitles(bool $fresh = false): array
    {
        // $fresh reads the row again, past the copy this request already holds.
        $stored = fluent_cart_get_option(self::CUSTOM_OPTION, [], !$fresh);

        return is_array($stored) ? array_filter($stored, 'is_string') : [];
    }

    /**
     * @return string[] The classes of the cards that bring their own markup and stylesheet.
     */
    public static function cardClasses(): array
    {
        return [
            Cards\HighlightCard::class,
            Cards\ExclusiveCard::class,
            Cards\CalloutCard::class,
            Cards\ToggleCard::class,
        ];
    }

    public function getDefaultTemplates(): array
    {
        $templates = [
            'classic' => [
                'name'        => 'classic',
                'title'       => __('Classic Card', 'fluent-cart-pro'),
                'description' => __('A card with a checkbox below.', 'fluent-cart-pro'),
                'is_default'  => true,
                'content'     => $this->classicContent(),
            ],
            'compact' => [
                'name'        => 'compact',
                'title'       => __('Compact Card', 'fluent-cart-pro'),
                'description' => __('A slim row with an Add button.', 'fluent-cart-pro'),
                'is_default'  => true,
                'content'     => $this->compactContent(),
            ],
        ];

        foreach (self::cardClasses() as $card) {
            /** @var AbstractCard $card */
            $templates[$card::key()] = [
                'name'        => $card::key(),
                'title'       => $card::title(),
                'description' => $card::description(),
                'is_default'  => true,
                'content'     => $card::content(),
            ];
        }

        return $templates;
    }

    /**
     * Saved templates; a built-in one that was never saved comes from the defaults.
     */
    public function getTemplates(): array
    {
        $templates = [];
        foreach (array_keys($this->getDefaultTemplates()) as $key) {
            $templates[$key] = $this->getTemplate($key);
        }

        return $templates;
    }

    public function getTemplate(string $key): ?array
    {
        $defaults = $this->getDefaultTemplates();
        $custom = self::customTitles();
        if (!isset($defaults[$key]) && !isset($custom[$key])) {
            return null;
        }

        $saved = fluent_cart_get_option(self::optionKey($key), null);
        if (is_array($saved)) {
            return $saved;
        }

        return isset($defaults[$key]) ? $defaults[$key] : $this->customDefault($key, $custom[$key]);
    }

    /**
     * The content a card gets back on a reset: its own built-in design, or the classic design for a custom card.
     */
    public function defaultContent(string $key): string
    {
        $defaults = $this->getDefaultTemplates();

        return isset($defaults[$key]) ? $defaults[$key]['content'] : $defaults['classic']['content'];
    }

    // A custom card starts as the classic design.
    private function customDefault(string $key, string $title): array
    {
        return [
            'name'        => $key,
            'title'       => $title,
            'description' => '',
            'is_default'  => false,
            'is_custom'   => true,
            'content'     => $this->classicContent(),
        ];
    }

    /**
     * Adds a custom card that starts as the classic design.
     *
     * @return string The new card's key, or '' when the limit is reached.
     */
    public function createCustom(string $title): string
    {
        return $this->withRegistryLock(function () use ($title) {
            // Read again under the lock: another admin may have changed the list since this request started.
            $custom = self::customTitles(true);
            if (count($custom) >= self::MAX_CUSTOM) {
                return '';
            }

            // Two cards made in the same second must not share a key.
            do {
                $key = 'custom_' . time() . '_' . wp_rand(1000, 9999);
            } while (isset($custom[$key]));

            $custom[$key] = $title;
            fluent_cart_update_option(self::CUSTOM_OPTION, $custom);
            $this->store($key, $this->customDefault($key, $title));

            return $key;
        });
    }

    /**
     * Deletes a custom card. The shop goes back to the default card if it was using this one.
     *
     * @return bool False for a built-in or unknown card.
     * @throws RegistryBusyException When another request holds the lock of the list.
     */
    public function deleteCustom(string $key): bool
    {
        $deleted = $this->withRegistryLock(function () use ($key) {
            $custom = self::customTitles(true);
            if (!isset($custom[$key])) {
                return false;
            }

            unset($custom[$key]);
            fluent_cart_update_option(self::CUSTOM_OPTION, $custom);
            \FluentCart\App\Models\Meta::query()->where('meta_key', self::optionKey($key))->where('object_type', 'option')->delete();
            fluent_cart_get_option(self::optionKey($key), null, false); // the helper caches the last read

            return true;
        });

        if ($deleted) {
            // Only if the stored choice is still this card. A busy lock is safe: the shop shows Classic for a card that is gone.
            try {
                OrderBumpSettings::resetIfActive($key);
            } catch (RegistryBusyException $e) {
            }
        }

        return $deleted;
    }

    /**
     * Makes the changes to the list of custom cards one at a time, so two admins cannot write over each other.
     *
     * @return mixed What the callback returns.
     * @throws RegistryBusyException When another request holds the lock.
     */
    private function withRegistryLock(callable $change)
    {
        return NamedLock::run('fct_order_bump_custom_cards', $change);
    }

    /**
     * Cards whose saved markup differs from their default. A copy saved without a change is not one.
     *
     * @return string[]
     */
    public function customizedKeys(): array
    {
        $customized = [];
        $defaults = $this->getDefaultTemplates();
        // A custom card is compared with the classic design, which is what a reset gives it.
        $cards = array_map(function ($template) {
            return $template['content'];
        }, $defaults);
        foreach (array_keys(self::customTitles()) as $key) {
            $cards[$key] = $defaults['classic']['content'];
        }

        foreach ($cards as $key => $default) {
            $saved = fluent_cart_get_option(self::optionKey($key), null);
            if (is_array($saved) && $this->clean((string) ($saved['content'] ?? '')) !== $this->clean($default)) {
                $customized[] = $key;
            }
        }

        return $customized;
    }

    /**
     * @return bool False for an unknown template.
     */
    public function saveContent(string $key, string $content): bool
    {
        $template = $this->getTemplate($key);
        if (!$template) {
            return false;
        }

        $template['content'] = $this->clean($content);

        return $this->store($key, $template);
    }

    /**
     * The editor user may lack unfiltered_html, so the HTML of every block is cleaned like post content.
     * The block settings (the JSON in the comments) are left alone: kses would rewrite & and quotes in them.
     */
    public function clean(string $content): string
    {
        return serialize_blocks($this->cleanBlocks(parse_blocks($content)));
    }

    private function cleanBlocks(array $blocks): array
    {
        foreach ($blocks as $i => $block) {
            $blocks[$i]['innerHTML'] = wp_kses_post($block['innerHTML']);
            foreach ($block['innerContent'] as $j => $chunk) {
                $blocks[$i]['innerContent'][$j] = $chunk === null ? null : wp_kses_post($chunk);
            }
            $blocks[$i]['innerBlocks'] = $this->cleanBlocks($block['innerBlocks']);
        }

        return $blocks;
    }

    /**
     * @return bool False for an unknown template.
     */
    public function reset(string $key): bool
    {
        $defaults = $this->getDefaultTemplates();
        if (isset($defaults[$key])) {
            return $this->store($key, $defaults[$key]);
        }

        $custom = self::customTitles();

        return isset($custom[$key]) && $this->store($key, $this->customDefault($key, $custom[$key]));
    }

    private function store(string $key, array $template): bool
    {
        return (bool) fluent_cart_update_option(self::optionKey($key), $template);
    }

    // A card element block with the class the card's stylesheet already styles.
    private function element(string $name, string $class): string
    {
        return '<!-- wp:fluent-cart/order-bump-' . $name . ' ' . wp_json_encode(['className' => $class]) . ' /-->';
    }

    // A plain group block with the class the card's stylesheet already styles.
    private function group(string $class, string $inner): string
    {
        return '<!-- wp:group ' . wp_json_encode(['className' => $class]) . " -->\n"
            . '<div class="wp-block-group ' . $class . '">' . $inner . "</div>\n<!-- /wp:group -->";
    }

    private function priceRow(string $class): string
    {
        return $this->group(
            $class,
            $this->element('original-price', 'fct_order_promotion_original_price') . "\n\n"
            . $this->element('price', 'fct_order_promotion_discounted_price') . "\n\n"
            . $this->element('savings', 'fct_order_promotion_discount')
        );
    }

    // The checkout card: image, texts, then a checkbox row.
    private function classicContent(): string
    {
        $checkbox = '<!-- wp:fluent-cart/order-bump-checkbox ' . wp_json_encode(['label' => sprintf(__('Grab it for %s', 'fluent-cart-pro'), '{{bump.price}}')]) . ' /-->';

        $details = $this->element('title', 'fct_order_promotion_title') . "\n\n"
            . $this->element('product-title', 'fct_order_promotion_product_title') . "\n\n"
            . $this->element('variation-title', 'fct_order_promotion_variation_title') . "\n\n"
            . $this->group(
                'fct_order_promotion_price',
                $this->priceRow('fct_order_promotion_prices') . "\n\n" . $this->element('description', 'fct_order_promotion_description')
            );

        return $this->group(
            'fct_order_promotion',
            $this->group(
                'fct_order_promotion_body',
                $this->element('image', 'fct_order_promotion_icon') . "\n\n" . $this->group('fct_bump_details', $details)
            ) . "\n\n" . $this->group('fct_order_promotion_footer', $checkbox)
        );
    }

    // The cart card: a slim row with an Add button.
    private function compactContent(): string
    {
        $add = '<!-- wp:fluent-cart/order-bump-add-button ' . wp_json_encode(['label' => __('Add', 'fluent-cart-pro')]) . ' /-->';
        $added = '<!-- wp:fluent-cart/order-bump-added ' . wp_json_encode(['label' => __('Added', 'fluent-cart-pro')]) . ' /-->';
        $remove = '<!-- wp:fluent-cart/order-bump-remove-button ' . wp_json_encode(['label' => __('Remove', 'fluent-cart-pro')]) . ' /-->';

        $details = $this->element('title', 'fct_cart_bump_badge') . "\n\n"
            . $this->element('product-title', 'fct_cart_bump_product') . "\n\n"
            . $this->element('variation-title', 'fct_cart_bump_variation') . "\n\n"
            . $this->priceRow('fct_cart_bump_price');

        return $this->group(
            'fct_cart_bump',
            $this->element('image', 'fct_cart_bump_icon') . "\n\n"
            . $this->group('fct_cart_bump_details', $details) . "\n\n"
            . $this->group('fct_cart_bump_actions', $add . "\n\n" . $added . "\n\n" . $remove)
        );
    }
}
