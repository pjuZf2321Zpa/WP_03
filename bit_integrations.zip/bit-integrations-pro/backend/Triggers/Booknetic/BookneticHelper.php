<?php

namespace BitApps\IntegrationsPro\Triggers\Booknetic;

use BookneticApp\Models\Appointment;
use BookneticApp\Models\Customer;
use BookneticApp\Models\Location;
use BookneticApp\Models\Service;
use BookneticApp\Models\Staff;

final class BookneticHelper
{
    private const SENSITIVE_KEYS = [
        'access_token',
        'api_key',
        'authorization',
        'password',
        'purchase_code',
        'refresh_token',
        'secret',
        'token',
    ];

    public static function isPluginInstalled()
    {
        return class_exists('BookneticApp\Providers\Core\Bootstrap');
    }

    public static function normalizePayload($value)
    {
        $value = self::extractObjectAttributes($value);

        if (!\is_array($value)) {
            return $value;
        }

        $normalized = [];

        foreach ($value as $key => $item) {
            if (self::isSensitiveKey($key)) {
                continue;
            }

            $normalized[$key] = self::normalizePayload($item);
        }

        return $normalized;
    }

    public static function getAppointmentData($source)
    {
        $appointmentId = self::resolveRecordId($source, ['appointmentId', 'appointment_id', 'id']);

        if ($appointmentId <= 0 && \is_object($source) && isset($source->createdAppointments)) {
            $createdAppointments = (array) $source->createdAppointments;
            $appointmentId = (int) end($createdAppointments);
        }

        $appointment = self::getModelData(Appointment::class, $appointmentId);

        if (empty($appointment)) {
            $fallback = self::normalizePayload($source);

            if (\is_array($fallback)) {
                return $fallback;
            }

            return $appointmentId > 0 ? ['appointment_id' => $appointmentId] : [];
        }

        $appointment['customer'] = self::getModelData(Customer::class, (int) ($appointment['customer_id'] ?? 0));
        $appointment['location'] = self::getModelData(Location::class, (int) ($appointment['location_id'] ?? 0));
        $appointment['service'] = self::getModelData(Service::class, (int) ($appointment['service_id'] ?? 0));
        $appointment['staff'] = self::getModelData(Staff::class, (int) ($appointment['staff_id'] ?? 0));
        $appointment += self::readableDates($appointment);

        return self::normalizePayload($appointment);
    }

    public static function getCustomerData($customerId)
    {
        return self::getModelData(Customer::class, (int) $customerId);
    }

    public static function getStaffData($staffId)
    {
        return self::getModelData(Staff::class, (int) $staffId);
    }

    private static function readableDates(array $appointment)
    {
        $startsAt = (int) ($appointment['starts_at'] ?? 0);
        $endsAt = (int) ($appointment['ends_at'] ?? 0);

        if ($startsAt <= 0) {
            return [];
        }

        return [
            'start_date'     => wp_date('Y-m-d', $startsAt),
            'start_time'     => wp_date('H:i', $startsAt),
            'start_datetime' => wp_date('Y-m-d H:i', $startsAt),
            'end_datetime'   => $endsAt > 0 ? wp_date('Y-m-d H:i', $endsAt) : '',
        ];
    }

    private static function getModelData($modelClass, $recordId)
    {
        if ($recordId <= 0 || !class_exists($modelClass)) {
            return [];
        }

        $record = $modelClass::query()->get($recordId);

        return empty($record) ? [] : self::normalizePayload($record);
    }

    private static function extractObjectAttributes($object)
    {
        if (!\is_object($object)) {
            return $object;
        }

        if (method_exists($object, 'getAttributes')) {
            return $object->getAttributes();
        }

        if (method_exists($object, 'toArray')) {
            return $object->toArray();
        }

        return get_object_vars($object);
    }

    private static function resolveRecordId($source, array $keys)
    {
        if (is_numeric($source)) {
            return (int) $source;
        }

        $source = self::extractObjectAttributes($source);

        if (!\is_array($source)) {
            return 0;
        }

        foreach ($keys as $key) {
            if (!empty($source[$key])) {
                return (int) $source[$key];
            }
        }

        return 0;
    }

    private static function isSensitiveKey($key)
    {
        $key = strtolower((string) $key);

        foreach (self::SENSITIVE_KEYS as $sensitiveKey) {
            if (strpos($key, $sensitiveKey) !== false) {
                return true;
            }
        }

        return false;
    }
}
