<?php

namespace FluentCartPro\App\Modules\Reviews;

use FluentCart\Api\ModuleSettings;
use FluentCart\App\Services\Permission\PermissionManager;
use FluentCart\App\Services\ProductReviewService;
use FluentCart\Framework\Support\Arr;
use FluentCartPro\App\Modules\Reviews\Services\ReviewMediaService;

class ReviewsProInit
{
    public function register($app)
    {
        add_action('fluent_cart/module/activated/reviews', function ($newData, $oldData) {
            (new Database\DBMigrator())->migrate();
        }, 10, 2);

        $app->addFilter('fluent_cart/module_setting/default_values', function ($values, $args) {
            if (!isset($values['reviews'])) {
                $values['reviews'] = [];
            }

            $values['reviews'] = array_merge($values['reviews'], [
                'enable_photo_reviews'    => 'no',
                // Photo reviews stay in moderation even when plain reviews
                // auto-approve, unless the store opts them in with this.
                'auto_approve_photo_reviews' => 'no',
                'max_photos_per_review'   => 5,
                'max_photo_size_mb'       => 1,
                'allowed_photo_types'     => ['jpeg', 'png', 'gif', 'webp'],
                'enable_helpful_votes'    => 'yes',
            ]);

            return $values;
        }, 10, 2);

        if (!ModuleSettings::isActive('reviews')) {
            return;
        }

        // Interactions table schema is managed by the central ProDBMigrator pipeline
        // (FLUENTCART_PRO_DB_VERSION), not a module-specific version option:
        // activation → run_migrate(), plugin update → maybeMigrateDBChanges(),
        // free-plugin migrations → fluent_cart/after_migrate, and late module
        // activation → the fluent_cart/module/activated/reviews hook above.

        // Register routes
        $app->router->group(function ($router) {
            require_once __DIR__ . '/Http/reviews-api.php';
        });

        // Register hooks
        require_once __DIR__ . '/Hooks/review-actions.php';
        require_once __DIR__ . '/Hooks/review-filters.php';

        // Tell the free admin SPA that review attachments are available and
        // on what terms. Free owns the route, the modal and the uploader;
        // these limits are the only part it cannot work out for itself.
        // Absent = the modal keeps its locked placeholder, which is what a
        // store without Pro sees.
        add_filter('fluent_cart/admin_app_data', function ($data) {
            if (!PermissionManager::hasPermission(['reviews/manage'])) {
                return $data;
            }

            // Gated on enable_photo_reviews, the same switch the storefront
            // form, the upload endpoint and the public payload read. A store
            // that has turned photo reviews off has turned them off: offering
            // a moderator an upload zone whose files the handler then refuses
            // would be a control that does nothing.
            if (Arr::get(ProductReviewService::getReviewSettings(), 'enable_photo_reviews') !== 'yes') {
                return $data;
            }

            $data['review_media'] = [
                'enabled'       => true,
                'max_photos'    => ReviewMediaService::getMaxPhotosPerReview(),
                'max_size_mb'   => ReviewMediaService::getMaxPhotoSizeMb(),
                'accept'        => implode(',', ReviewMediaService::resolveAllowedMimeTypes(
                    ReviewMediaService::getAllowedPhotoTypes()
                )),
            ];

            return $data;
        });

    }
}
