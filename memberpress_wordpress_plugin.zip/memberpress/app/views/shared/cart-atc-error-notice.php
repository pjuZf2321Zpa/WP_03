<?php

/**
 * Cart ATC / product-page error toast (Figma toast-gift-error via mepr-ds-components).
 *
 * Variables:
 *   $message (string) — body HTML or plain text (anchors allowed).
 */

if (!defined('ABSPATH')) {
    die('You are not allowed to call this page directly.');
}

$message = (string) ($message ?? '');
if ($message === '') {
    return;
}
?>
<div class="mepr-shop-card__atc-message mepr-shop-card__atc-message--error" role="alert">
  <span class="mepr-shop-card__atc-message__icon" aria-hidden="true">
    <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" aria-hidden="true">
      <path d="M12 3.5L2.5 20h19L12 3.5z" stroke="currentColor" stroke-width="1.75" stroke-linejoin="round" fill="none"/>
      <path d="M12 10v4.5" stroke="currentColor" stroke-width="1.75" stroke-linecap="round"/>
      <circle cx="12" cy="17.5" r="1" fill="currentColor"/>
    </svg>
  </span>
  <span class="mepr-shop-card__atc-message__text"><?php echo wp_kses_post($message); ?></span>
</div>
