<?php

namespace BitApps\IntegrationsPro\Actions\FollowUpBoss\Services;

final class DealCustomFieldService extends BaseService
{
    public function createDealCustomField(): array
    {
        $validationRules = [
            'label'        => ['required'],
            'field_type'   => ['required'],
            'order_weight' => ['nullable', 'integer'],
        ];
        $error = $this->validateFields(
            $validationRules,
            [
                'label'        => __('Label', 'bit-integrations-pro'),
                'field_type'   => __('Field Type', 'bit-integrations-pro'),
                'order_weight' => __('Sort Order', 'bit-integrations-pro'),
            ],
            ['field_type']
        );

        if ($error !== null) {
            return $error;
        }

        $payload = $this->removeEmptyValues(
            [
                'label'       => $this->getString('label'),
                'type'        => $this->getString('field_type'),
                'choices'     => $this->getList('choices'),
                'isRecurring' => $this->getBoolean('is_recurring'),
                'hideIfEmpty' => $this->getBoolean('hide_if_empty'),
                'readOnly'    => $this->getBoolean('read_only'),
                'orderWeight' => $this->getInteger('order_weight'),
            ]
        );

        return $this->dispatch('POST', '/dealCustomFields', $payload);
    }

    public function updateDealCustomField(): array
    {
        $validationRules = [
            'custom_field_id' => ['required', 'integer'],
            'order_weight'    => ['nullable', 'integer'],
        ];
        $error = $this->validateFields(
            $validationRules,
            [
                'custom_field_id' => __('Custom Field ID', 'bit-integrations-pro'),
                'order_weight'    => __('Sort Order', 'bit-integrations-pro'),
            ]
        );

        if ($error !== null) {
            return $error;
        }

        $payload = $this->removeEmptyValues(
            [
                'label'       => $this->getString('label'),
                'type'        => $this->getString('field_type'),
                'choices'     => $this->getList('choices'),
                'isRecurring' => $this->getBoolean('is_recurring'),
                'hideIfEmpty' => $this->getBoolean('hide_if_empty'),
                'readOnly'    => $this->getBoolean('read_only'),
                'orderWeight' => $this->getInteger('order_weight'),
            ]
        );

        return $this->dispatch('PUT', '/dealCustomFields/' . rawurlencode($this->getString('custom_field_id')), $payload);
    }

    public function deleteDealCustomField(): array
    {
        $validationRules = ['custom_field_id' => ['required', 'integer']];
        $error = $this->validateFields(
            $validationRules,
            [
                'custom_field_id' => __('Custom Field ID', 'bit-integrations-pro'),
            ]
        );

        if ($error !== null) {
            return $error;
        }

        return $this->dispatch('DELETE', '/dealCustomFields/' . rawurlencode($this->getString('custom_field_id')));
    }
}
