<?php

namespace BitApps\IntegrationsPro\Actions\Charitable;

use Charitable_User;
use Exception;

class CharitableProHelper
{
    private const DONOR_FIELDS = ['email', 'first_name', 'last_name'];

    private const DONATION_USER_FIELDS = [
        'email', 'first_name', 'last_name', 'company', 'phone',
        'address', 'address_2', 'city', 'state', 'postcode', 'country',
    ];

    private const CAMPAIGN_TEXT_FIELDS = [
        'title', 'content', 'description', 'end_date',
    ];

    private const CAMPAIGN_NUMERIC_FIELDS = [
        'goal', 'minimum_donation_amount', 'suggested_donations_default',
    ];

    private const USER_CORE_FIELDS = [
        'user_email', 'user_login', 'user_pass', 'user_url',
        'display_name', 'nickname', 'first_name', 'last_name',
    ];

    private const USER_META_FIELDS = [
        'address', 'address_2', 'city', 'state', 'postcode',
        'country', 'phone', 'organisation', 'description',
    ];

    public static function createDonation($defaultResponse, $fieldData, $utilities = null, $integrationDetails = null)
    {
        if (!self::isCharitableActive() || !\function_exists('charitable_create_donation')) {
            return self::error(__('Charitable is not installed or activated', 'bit-integrations-pro'));
        }

        $campaignId = absint(self::conf($integrationDetails, 'selectedCampaign'));

        if (empty($campaignId)) {
            return self::error(__('A campaign is required to create a donation', 'bit-integrations-pro'));
        }

        if (get_post_type($campaignId) !== 'campaign') {
            return self::error(__('The selected campaign does not exist', 'bit-integrations-pro'));
        }

        if (empty($fieldData['amount'])) {
            return self::error(__('Donation amount is required', 'bit-integrations-pro'));
        }

        if (empty($fieldData['email']) || !is_email($fieldData['email'])) {
            return self::error(__('A valid donor email is required', 'bit-integrations-pro'));
        }

        try {
            $args = [
                'campaigns' => [
                    ['campaign_id' => $campaignId, 'amount' => (float) $fieldData['amount']],
                ],
                'user'   => self::pick($fieldData, self::DONATION_USER_FIELDS),
                'status' => self::util($utilities, 'selected_donation_status') ?: 'charitable-completed',
            ];

            foreach (['gateway', 'note'] as $key) {
                if (!empty($fieldData[$key])) {
                    $args[$key] = $fieldData[$key];
                }
            }

            $donorId = absint(self::util($utilities, 'selected_donor'));

            if (!empty($donorId)) {
                $args['donor_id'] = $donorId;
            }

            $userId = absint(self::util($utilities, 'selected_user'));

            if (!empty($userId)) {
                $args['user_id'] = $userId;
            }

            $donationId = (int) charitable_create_donation($args);

            if ($donationId <= 0) {
                return self::error(__('Failed to create the donation', 'bit-integrations-pro'));
            }

            return self::success(__('Donation created successfully', 'bit-integrations-pro'), ['donation_id' => $donationId]);
        } catch (Exception $e) {
            return self::error($e->getMessage());
        }
    }

    public static function updateDonationStatus($defaultResponse, $fieldData, $integrationDetails = null)
    {
        $donation = self::findDonation($fieldData);

        if (\is_array($donation)) {
            return $donation;
        }

        $status = self::conf($integrationDetails, 'selectedDonationStatus');

        if (empty($status)) {
            return self::error(__('A donation status is required', 'bit-integrations-pro'));
        }

        if (\function_exists('charitable_is_valid_donation_status') && !charitable_is_valid_donation_status($status)) {
            return self::error(__('The given status is not a valid Charitable donation status', 'bit-integrations-pro'));
        }

        $donation->update_status($status);

        return self::success(__('Donation status updated successfully', 'bit-integrations-pro'), [
            'donation_id' => absint($fieldData['donation_id']),
            'status'      => $status,
        ]);
    }

    public static function addDonationNote($defaultResponse, $fieldData)
    {
        $donation = self::findDonation($fieldData);

        if (\is_array($donation)) {
            return $donation;
        }

        if (empty($fieldData['note'])) {
            return self::error(__('A note is required', 'bit-integrations-pro'));
        }

        $donation->update_donation_log($fieldData['note']);

        return self::success(__('Donation note added successfully', 'bit-integrations-pro'), [
            'donation_id' => absint($fieldData['donation_id']),
        ]);
    }

    public static function deleteDonation($defaultResponse, $fieldData, $utilities = null)
    {
        if (!self::isCharitableActive()) {
            return self::error(__('Charitable is not installed or activated', 'bit-integrations-pro'));
        }

        $donationId = absint($fieldData['donation_id'] ?? 0);

        if (get_post_type($donationId) !== 'donation') {
            return self::error(__('Donation not found in Charitable', 'bit-integrations-pro'));
        }

        if (!wp_delete_post($donationId, self::isTrue(self::util($utilities, 'selected_force_delete')))) {
            return self::error(__('Failed to delete the donation', 'bit-integrations-pro'));
        }

        return self::success(__('Donation deleted successfully', 'bit-integrations-pro'), ['donation_id' => $donationId]);
    }

    public static function createCampaign($defaultResponse, $fieldData, $utilities = null)
    {
        if (!self::isCharitableActive() || !\function_exists('charitable_create_campaign')) {
            return self::error(__('Charitable is not installed or activated', 'bit-integrations-pro'));
        }

        if (empty($fieldData['title'])) {
            return self::error(__('Campaign title is required', 'bit-integrations-pro'));
        }

        return self::saveCampaign(self::buildCampaignArgs($fieldData, $utilities), __('Campaign created successfully', 'bit-integrations-pro'));
    }

    public static function updateCampaign($defaultResponse, $fieldData, $utilities = null)
    {
        if (!self::isCharitableActive() || !\function_exists('charitable_create_campaign')) {
            return self::error(__('Charitable is not installed or activated', 'bit-integrations-pro'));
        }

        $campaignId = absint($fieldData['campaign_id'] ?? 0);

        if (get_post_type($campaignId) !== 'campaign') {
            return self::error(__('Campaign not found in Charitable', 'bit-integrations-pro'));
        }

        $args = self::buildCampaignArgs($fieldData, $utilities);
        $args['ID'] = $campaignId;

        return self::saveCampaign($args, __('Campaign updated successfully', 'bit-integrations-pro'));
    }

    public static function deleteCampaign($defaultResponse, $fieldData, $utilities = null)
    {
        if (!self::isCharitableActive()) {
            return self::error(__('Charitable is not installed or activated', 'bit-integrations-pro'));
        }

        $campaignId = absint($fieldData['campaign_id'] ?? 0);

        if (get_post_type($campaignId) !== 'campaign') {
            return self::error(__('Campaign not found in Charitable', 'bit-integrations-pro'));
        }

        if (!wp_delete_post($campaignId, self::isTrue(self::util($utilities, 'selected_force_delete')))) {
            return self::error(__('Failed to delete the campaign', 'bit-integrations-pro'));
        }

        return self::success(__('Campaign deleted successfully', 'bit-integrations-pro'), ['campaign_id' => $campaignId]);
    }

    public static function createDonor($defaultResponse, $fieldData, $utilities = null)
    {
        if (!self::isCharitableActive() || !class_exists('Charitable_User')) {
            return self::error(__('Charitable is not installed or activated', 'bit-integrations-pro'));
        }

        if (empty($fieldData['email']) || !is_email($fieldData['email'])) {
            return self::error(__('A valid donor email is required', 'bit-integrations-pro'));
        }

        $existingDonorId = (int) charitable_get_table('donors')->get_donor_id_by_email($fieldData['email']);

        if ($existingDonorId > 0) {
            // translators: %d: existing donor id
            return self::error(\sprintf(__('A donor with this email address already exists (donor ID %d)', 'bit-integrations-pro'), $existingDonorId));
        }

        $user = new Charitable_User(absint(self::util($utilities, 'selected_user')));
        $donorId = (int) $user->add_donor(self::pick($fieldData, self::DONOR_FIELDS));

        if ($donorId <= 0) {
            return self::error(self::pullNoticeErrors() ?: __('Failed to create the donor', 'bit-integrations-pro'));
        }

        return self::success(__('Donor created successfully', 'bit-integrations-pro'), ['donor_id' => $donorId]);
    }

    public static function updateDonor($defaultResponse, $fieldData, $utilities = null)
    {
        if (!self::isCharitableActive() || !\function_exists('charitable_get_table')) {
            return self::error(__('Charitable is not installed or activated', 'bit-integrations-pro'));
        }

        $donorId = absint($fieldData['donor_id'] ?? 0);

        if (empty($donorId)) {
            return self::error(__('Donor id is required', 'bit-integrations-pro'));
        }

        $data = self::pick($fieldData, self::DONOR_FIELDS);

        $userId = absint(self::util($utilities, 'selected_user'));

        if (!empty($userId)) {
            $data['user_id'] = $userId;
        }

        $consent = self::util($utilities, 'selected_contact_consent');

        if ($consent !== null && $consent !== '') {
            $data['contact_consent'] = self::isTrue($consent) ? 1 : 0;
        }

        if (empty($data)) {
            return self::error(__('No fields provided to update', 'bit-integrations-pro'));
        }

        if (isset($data['email'])) {
            if (!is_email($data['email'])) {
                return self::error(__('A valid donor email is required', 'bit-integrations-pro'));
            }

            $emailOwnerId = (int) charitable_get_table('donors')->get_donor_id_by_email($data['email']);

            if ($emailOwnerId > 0 && $emailOwnerId !== $donorId) {
                // translators: %d: donor id that already uses the email address
                return self::error(\sprintf(__('This email address already belongs to another donor (donor ID %d)', 'bit-integrations-pro'), $emailOwnerId));
            }
        }

        if (!charitable_get_table('donors')->update($donorId, $data)) {
            return self::error(self::pullNoticeErrors() ?: __('Failed to update the donor', 'bit-integrations-pro'));
        }

        return self::success(__('Donor updated successfully', 'bit-integrations-pro'), ['donor_id' => $donorId]);
    }

    public static function createUserProfile($defaultResponse, $fieldData, $utilities = null)
    {
        if (!self::isCharitableActive() || !class_exists('Charitable_User')) {
            return self::error(__('Charitable is not installed or activated', 'bit-integrations-pro'));
        }

        if (empty($fieldData['user_email']) || !is_email($fieldData['user_email'])) {
            return self::error(__('A valid email address is required', 'bit-integrations-pro'));
        }

        if (email_exists($fieldData['user_email'])) {
            return self::error(__('A user with that email address already exists', 'bit-integrations-pro'));
        }

        $coreValues = self::pick($fieldData, self::USER_CORE_FIELDS);

        if (empty($coreValues['user_login'])) {
            $coreValues['user_login'] = $coreValues['user_email'];
        }

        if (empty($coreValues['user_pass'])) {
            $coreValues['user_pass'] = wp_generate_password(20, true, true);
        }

        $role = self::util($utilities, 'selected_role');

        if (!empty($role)) {
            if (!wp_roles()->is_role($role)) {
                return self::error(__('The selected role does not exist', 'bit-integrations-pro'));
            }

            $coreValues['role'] = $role;
        }

        $userId = wp_insert_user($coreValues);

        if (is_wp_error($userId)) {
            return self::error($userId->get_error_message());
        }

        $profileError = self::applyProfile((int) $userId, $fieldData);

        if ($profileError !== null) {
            return self::error($profileError);
        }

        return self::success(__('User profile created successfully', 'bit-integrations-pro'), ['user_id' => (int) $userId]);
    }

    public static function updateUserProfile($defaultResponse, $fieldData, $utilities = null)
    {
        if (!self::isCharitableActive() || !class_exists('Charitable_User')) {
            return self::error(__('Charitable is not installed or activated', 'bit-integrations-pro'));
        }

        $userId = absint($fieldData['user_id'] ?? 0);

        if (!get_userdata($userId)) {
            return self::error(__('User not found', 'bit-integrations-pro'));
        }

        if (!empty($fieldData['user_email'])) {
            if (!is_email($fieldData['user_email'])) {
                return self::error(__('A valid email address is required', 'bit-integrations-pro'));
            }

            $emailOwnerId = email_exists($fieldData['user_email']);

            if ($emailOwnerId && (int) $emailOwnerId !== $userId) {
                return self::error(__('This email address already belongs to another user', 'bit-integrations-pro'));
            }
        }

        $role = self::util($utilities, 'selected_role');

        if (!empty($role) && !wp_roles()->is_role($role)) {
            return self::error(__('The selected role does not exist', 'bit-integrations-pro'));
        }

        $profileError = self::applyProfile($userId, $fieldData);

        if ($profileError !== null) {
            return self::error($profileError);
        }

        if (!empty($role)) {
            get_userdata($userId)->set_role($role);
        }

        return self::success(__('User profile updated successfully', 'bit-integrations-pro'), ['user_id' => $userId]);
    }

    public static function markUserVerified($defaultResponse, $fieldData, $utilities = null)
    {
        if (!self::isCharitableActive() || !class_exists('Charitable_User')) {
            return self::error(__('Charitable is not installed or activated', 'bit-integrations-pro'));
        }

        $userId = absint($fieldData['user_id'] ?? 0);

        if (!get_userdata($userId)) {
            return self::error(__('User not found', 'bit-integrations-pro'));
        }

        $verified = self::util($utilities, 'selected_verified');
        $verified = $verified === null || $verified === '' ? true : self::isTrue($verified);

        $user = new Charitable_User($userId);
        $user->mark_as_verified($verified);

        return self::success(__('User verification updated successfully', 'bit-integrations-pro'), [
            'user_id'  => $userId,
            'verified' => $verified,
        ]);
    }

    private static function buildCampaignArgs($fieldData, $utilities)
    {
        $args = self::pick($fieldData, self::CAMPAIGN_TEXT_FIELDS);

        foreach (self::CAMPAIGN_NUMERIC_FIELDS as $key) {
            if (isset($fieldData[$key]) && $fieldData[$key] !== '') {
                $args[$key] = (float) $fieldData[$key];
            }
        }

        $status = self::util($utilities, 'selected_campaign_status');

        if (!empty($status)) {
            $args['status'] = $status;
        }

        $creator = absint(self::util($utilities, 'selected_creator'));

        if (!empty($creator)) {
            $args['creator'] = $creator;
        }

        $allowCustom = self::util($utilities, 'selected_allow_custom_donations');

        if ($allowCustom !== null && $allowCustom !== '') {
            $args['allow_custom_donations'] = self::isTrue($allowCustom) ? 1 : 0;
        }

        foreach (['categories' => 'selected_categories', 'tags' => 'selected_tags'] as $argKey => $utilKey) {
            $terms = self::toIdList(self::util($utilities, $utilKey));

            if (!empty($terms)) {
                $args[$argKey] = $terms;
            }
        }

        return $args;
    }

    private static function saveCampaign($args, $successMessage)
    {
        $campaignId = (int) charitable_create_campaign($args);

        if ($campaignId <= 0) {
            return self::error(__('Failed to save the campaign', 'bit-integrations-pro'));
        }

        return self::success($successMessage, ['campaign_id' => $campaignId]);
    }

    private static function applyProfile($userId, $fieldData)
    {
        $submitted = self::pick($fieldData, array_merge(self::USER_CORE_FIELDS, self::USER_META_FIELDS));

        unset($submitted['user_pass'], $submitted['user_login']);

        if (empty($submitted)) {
            return;
        }

        $keys = array_keys($submitted);
        $user = new Charitable_User($userId);

        if (array_intersect($keys, $user->get_core_keys()) && !$user->update_core_user($submitted)) {
            return self::pullNoticeErrors() ?: __('Failed to update the user profile', 'bit-integrations-pro');
        }

        $user->update_donor_record($submitted, $keys);
        $user->update_user_meta($submitted, $keys);
    }

    private static function pullNoticeErrors()
    {
        if (!\function_exists('charitable_get_notices')) {
            return '';
        }

        $notices = charitable_get_notices();
        $errors = array_map('wp_strip_all_tags', (array) $notices->get_errors());
        $notices->clear_notices_by_type('error');

        return implode(' ', array_filter($errors));
    }

    private static function findDonation($fieldData)
    {
        if (!self::isCharitableActive() || !\function_exists('charitable_get_donation')) {
            return self::error(__('Charitable is not installed or activated', 'bit-integrations-pro'));
        }

        $donationId = absint($fieldData['donation_id'] ?? 0);

        if (get_post_type($donationId) !== 'donation') {
            return self::error(__('Donation not found in Charitable', 'bit-integrations-pro'));
        }

        $donation = charitable_get_donation($donationId, true);

        if (!$donation) {
            return self::error(__('Donation not found in Charitable', 'bit-integrations-pro'));
        }

        return $donation;
    }

    private static function pick($fieldData, array $keys)
    {
        $picked = [];

        foreach ($keys as $key) {
            if (isset($fieldData[$key]) && $fieldData[$key] !== '') {
                $picked[$key] = $fieldData[$key];
            }
        }

        return $picked;
    }

    private static function conf($integrationDetails, $key)
    {
        if (\is_object($integrationDetails)) {
            return $integrationDetails->{$key} ?? null;
        }

        return \is_array($integrationDetails) ? ($integrationDetails[$key] ?? null) : null;
    }

    private static function util($utilities, $key)
    {
        return self::conf($utilities, $key);
    }

    private static function toIdList($value)
    {
        if (empty($value)) {
            return [];
        }

        $items = \is_array($value) ? $value : explode(',', (string) $value);

        return array_values(array_filter(array_map('absint', $items)));
    }

    private static function isTrue($value)
    {
        return filter_var($value, FILTER_VALIDATE_BOOLEAN);
    }

    private static function isCharitableActive()
    {
        return class_exists('Charitable') && \function_exists('charitable');
    }

    private static function success($message, $data = [])
    {
        return ['success' => true, 'message' => $message, 'data' => $data];
    }

    private static function error($message)
    {
        return ['success' => false, 'message' => $message];
    }
}
