<?php

namespace BitApps\IntegrationsPro\Actions\FollowUpBoss\Services;

final class TaskService extends BaseService
{
    public function createTask(): array
    {
        $validationRules = [
            'person_id'             => ['required', 'integer'],
            'remind_seconds_before' => ['nullable', 'integer'],
        ];
        $error = $this->validateFields(
            $validationRules,
            [
                'person_id'             => __('Person ID', 'bit-integrations-pro'),
                'remind_seconds_before' => __('Reminder', 'bit-integrations-pro'),
            ]
        );

        if ($error !== null) {
            return $error;
        }

        $payload = $this->removeEmptyValues(
            [
                'personId'            => $this->getInteger('person_id'),
                'name'                => $this->getString('name'),
                'type'                => $this->getString('task_type'),
                'assignedUserId'      => $this->getInteger('assigned_user_id'),
                'dueDate'             => $this->getString('due_date'),
                'dueDateTime'         => $this->getString('due_date_time'),
                'remindSecondsBefore' => $this->getInteger('remind_seconds_before'),
                'isCompleted'         => $this->getBoolean('is_completed'),
            ]
        );

        return $this->dispatch('POST', '/tasks', $payload);
    }

    public function updateTask(): array
    {
        $validationRules = [
            'task_id'               => ['required', 'integer'],
            'remind_seconds_before' => ['nullable', 'integer'],
        ];
        $error = $this->validateFields(
            $validationRules,
            [
                'task_id'               => __('Task ID', 'bit-integrations-pro'),
                'remind_seconds_before' => __('Reminder', 'bit-integrations-pro'),
            ]
        );

        if ($error !== null) {
            return $error;
        }

        $payload = $this->removeEmptyValues(
            [
                'personId'            => $this->getInteger('person_id'),
                'name'                => $this->getString('name'),
                'type'                => $this->getString('task_type'),
                'assignedUserId'      => $this->getInteger('assigned_user_id'),
                'dueDate'             => $this->getString('due_date'),
                'dueDateTime'         => $this->getString('due_date_time'),
                'remindSecondsBefore' => $this->getInteger('remind_seconds_before'),
                'isCompleted'         => $this->getBoolean('is_completed'),
            ]
        );

        return $this->dispatch('PUT', '/tasks/' . rawurlencode($this->getString('task_id')), $payload);
    }

    public function deleteTask(): array
    {
        $validationRules = ['task_id' => ['required', 'integer']];
        $error = $this->validateFields(
            $validationRules,
            [
                'task_id' => __('Task ID', 'bit-integrations-pro'),
            ]
        );

        if ($error !== null) {
            return $error;
        }

        return $this->dispatch('DELETE', '/tasks/' . rawurlencode($this->getString('task_id')));
    }
}
