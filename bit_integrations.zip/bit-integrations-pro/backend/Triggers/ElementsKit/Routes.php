<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Core\Util\Route;
use BitApps\IntegrationsPro\Triggers\ElementsKit\ElementsKitController;

Route::get('elements-kit/get', [ElementsKitController::class, 'getAllTasks']);
