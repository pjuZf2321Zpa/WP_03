<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Core\Util\Route;
use BitApps\IntegrationsPro\Triggers\Buddypress\BuddypressController;

Route::get('buddypress/get', [BuddypressController::class, 'getAllTasks']);
