<?php
/**
 * HTML Block Markup Class file.
 *
 * @package sureforms-pro
 */

namespace SRFM_Pro\Inc\Fields;

use SRFM_Pro\Inc\Helper as Pro_Helper;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * HTML Block Markup Class.
 */
class Html_Markup extends Base {
	/**
	 * Raw HTML content.
	 *
	 * @var string
	 */
	protected $html_content = '';

	/**
	 * Initialize class properties.
	 *
	 * @param array<mixed> $attributes Block attributes.
	 */
	public function __construct( $attributes ) {
		$this->set_properties( $attributes );
		$this->slug         = 'html';
		$this->html_content = $attributes['htmlContent'] ?? '';
	}

	/**
	 * Render markup for HTML block.
	 *
	 * @return string|bool
	 */
	public function markup() {
		$wrapper_class = "srfm-block srfm-html-{$this->block_id}-block srfm-html-block{$this->block_width} {$this->classname} srfm-slug-{$this->block_slug} {$this->conditional_class}";

		$data_config = $this->field_config;
		// Process shortcodes in HTML content. Their output can hold request data,
		// and the form renders inside the page's `the_content`, so brackets left
		// after this pass are encoded: they show the same but no shortcode gets a
		// second run.
		$processed_content = Pro_Helper::encode_shortcode_brackets( wp_kses_post( do_shortcode( $this->html_content ) ) );

		ob_start(); ?>
		<div data-block-id="<?php echo esc_attr( $this->block_id ); ?>" class="<?php echo esc_attr( $wrapper_class ); ?>" <?php echo $data_config ? "data-field-config='" . esc_attr( $data_config ) . "'" : ''; ?>>
			<?php echo $processed_content; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Deliberately not escaped to allow raw HTML and processed shortcodes. ?>
		</div>
		<?php
		$markup = ob_get_clean();

		return apply_filters(
			'srfm_block_field_markup',
			$markup,
			[
				'slug'       => $this->slug,
				'field_name' => '',
				'is_editing' => $this->is_editing,
				'attributes' => $this->attributes,
			]
		);
	}
}
