<?php
/**
 * RSVP V2 IAC Modal Button template.
 *
 * Renders the button that triggers the IAC modal dialog.
 *
 * @since 6.11.0
 *
 * @version 6.11.0
 *
 * @var Tribe__Tickets_Plus__Admin__Views $this          [Global] Template object.
 * @var string                            $modal_content The modal content HTML.
 * @var array                             $button_args   Arguments for the modal button.
 * @var bool                              $has_meta_fields Whether there are meta fields for this ticket or not.
 */

defined( 'ABSPATH' ) || exit;

use Tribe\Dialog\View as Dialog_View;

/** @var Dialog_View $dialog_view */
$dialog_view = tribe( 'dialog.view' );

$classes = [
	'tribe-common',
	'event-tickets',
	'tec-tickets-rsvp-iac-modal-wrapper',
];

if ( $has_meta_fields ) {
	// Append the class that will style the area like an options' section only when there are meta fields.
	$classes[] = 'tec-tickets-rsvp-form__options';
}
?>
<div <?php tec_classes( $classes ); ?>>
	<?php $dialog_view->render_modal( $modal_content, $button_args ); ?>
</div>
