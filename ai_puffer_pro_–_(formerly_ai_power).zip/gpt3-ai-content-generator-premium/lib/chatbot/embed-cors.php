<?php

namespace WPAICG\Lib\Chat;

use WP_Error;
use WPAICG\Chat\Storage\BotStorage;
use WPAICG\Utils\AIPKit_CORS_Manager;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Paid embedded-chatbot allowlists, response headers and AJAX routing.
 */
final class EmbedCors
{
    private const ACTIONS = [
        'aipkit_get_frontend_chat_nonce',
        'aipkit_get_conversations_list',
        'aipkit_get_conversation_history',
        'aipkit_store_feedback',
        'aipkit_generate_speech',
        'aipkit_transcribe_audio',
        'aipkit_delete_single_conversation',
        'aipkit_cache_sse_message',
        'aipkit_frontend_chat_stream',
        'aipkit_chat_generate_image',
    ];

    public static function is_available(): bool
    {
        return class_exists('\WPAICG\aipkit_dashboard') && \WPAICG\aipkit_dashboard::is_pro_plan();
    }

    public static function register(): void
    {
        if (self::is_available()) {
            add_action('admin_init', [AIPKit_CORS_Manager::class, 'handle_ajax_cors']);
        }
    }

    public static function request_bot_id(): int
    {
        // phpcs:disable WordPress.Security.NonceVerification.Missing, WordPress.Security.NonceVerification.Recommended -- This only scopes CORS checks before the target handler validates its nonce.
        if (isset($_POST['bot_id'])) {
            return absint(wp_unslash($_POST['bot_id']));
        }
        return isset($_GET['bot_id']) ? absint(wp_unslash($_GET['bot_id'])) : 0;
        // phpcs:enable WordPress.Security.NonceVerification.Missing, WordPress.Security.NonceVerification.Recommended
    }

    public static function handle_ajax_cors(): void
    {
        if (!wp_doing_ajax() || !self::is_available()) {
            return;
        }
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Non-mutating routing before the individual handler verifies its nonce.
        $action = isset($_REQUEST['action']) ? sanitize_text_field(wp_unslash($_REQUEST['action'])) : '';
        if (!in_array($action, self::ACTIONS, true)) {
            return;
        }

        AIPKit_CORS_Manager::handle_preflight_request();
        $bot_id = self::request_bot_id();
        if ($bot_id > 0) {
            if (!AIPKit_CORS_Manager::check_and_set_cors_headers($bot_id)) {
                self::set_cors_headers('null');
            }
        } else {
            self::set_cors_headers();
        }
    }

    public static function check_origin(int $bot_id, string $request_origin, ?BotStorage $bot_storage = null): bool
    {
        if (!self::is_available()) {
            return false;
        }
        $bot_storage = $bot_storage ?? new BotStorage();
        $bot_settings = $bot_storage->get_chatbot_settings($bot_id);
        if (empty($bot_settings)) {
            return false;
        }

        $allowed_domains = preg_split('/[\s,]+/', $bot_settings['embed_allowed_domains'] ?? '', -1, PREG_SPLIT_NO_EMPTY);
        if (empty($allowed_domains)) {
            self::set_cors_headers($request_origin);
            return true;
        }
        $normalized_origin = rtrim($request_origin, '/');
        foreach ($allowed_domains as $allowed_domain) {
            if ($normalized_origin === rtrim($allowed_domain, '/')) {
                self::set_cors_headers($request_origin);
                return true;
            }
        }
        return false;
    }

    public static function set_cors_headers(string $allowed_origin = '*'): void
    {
        header('Access-Control-Allow-Origin: ' . $allowed_origin);
        header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
        header('Access-Control-Allow-Headers: Content-Type, X-Requested-With, Authorization');
        header('Access-Control-Allow-Credentials: true');
    }
}

final class FrontendPermissions
{
    /**
     * Validate an embedded request before the shared nonce check.
     */
    public static function check_embed_origin(): ?WP_Error
    {
        $bot_id = EmbedCors::request_bot_id();
        if ($bot_id > 0 && EmbedCors::is_available()) {
            if (!AIPKit_CORS_Manager::check_and_set_cors_headers($bot_id)) {
                return new WP_Error('cors_denied', __('This domain is not permitted to access the chatbot.', 'gpt3-ai-content-generator'), ['status' => 403]);
            }
        }
        return null;
    }
}
