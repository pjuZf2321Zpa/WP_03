<?php

if (!defined('ABSPATH')) {
    die('You are not allowed to call this page directly.');
}

/**
 * Cart order cancellation notification email sent to the admin.
 *
 * Mirrors MeprUserCartCancellationEmail, addressed to the store admin.
 */
class MeprAdminCartCancellationEmail extends MeprBaseOptionsAdminEmail
{
    /**
     * Per-cancellation context (reason, refunded amount) set before send().
     *
     * @var array
     */
    protected $context = [];

    /**
     * Set the default enabled, title, subject & body.
     *
     * @param  array $args The args.
     * @return void
     */
    public function set_defaults($args = [])
    {
        $mepr_options = MeprOptions::fetch();
        $this->to     = $mepr_options->admin_email_addresses;

        $this->title       = __('<b>Cart Order Cancellation Notification</b> Notice', 'memberpress');
        $this->description = __('Sent to the admin when a cart order is cancelled.', 'memberpress');
        $this->ui_order    = 6;

        $enabled = $use_template = $this->show_form = true;
        $subject = __('Cart Order #{$order_id} Cancelled — {$user_email}', 'memberpress');
        $body    = $this->body_partial();

        $this->defaults  = compact('enabled', 'subject', 'body', 'use_template');
        $this->variables = MeprUserCartCancellationEmail::get_cart_cancellation_email_vars();
    }

    /**
     * Get the body partial for the email.
     *
     * @param  array $vars Optional variables to pass to the view.
     * @return string The body partial HTML.
     */
    public function body_partial($vars = [])
    {
        return MeprView::get_string('/emails/admin-cart-cancellation', $vars);
    }

    /**
     * Set the per-cancellation context before send().
     *
     * @param  array $context Context {reason, refunded_amount}.
     * @return void
     */
    public function set_context(array $context)
    {
        $this->context = $context;
    }

    /**
     * Send the cart cancellation admin notification for the given order.
     *
     * @param  MeprOrder    $order        The cancelled cart order.
     * @param  string|false $subject      Subject override, or false for the stored default.
     * @param  string|false $body         Body override, or false for the stored default.
     * @param  boolean|null $use_template Whether to wrap in the email template, or null for the default.
     * @param  string       $content_type The content type of the email.
     * @return void
     */
    public function send($order = [], $subject = false, $body = false, $use_template = null, $content_type = 'html')
    {
        if (!($order instanceof MeprOrder)) {
            parent::send($order, $subject, $body, $use_template, $content_type);
            return;
        }

        if (!$this->enabled()) {
            return;
        }

        $user = new MeprUser($order->user_id);
        $vars = MeprUserCartCancellationEmail::build_cart_cancellation_vars($order, $user, $this->context);

        $formatted_subject = MeprUtils::replace_vals($this->get_stored_field('subject'), $vars);
        $formatted_body    = MeprUtils::replace_vals($this->get_stored_field('body'), $vars);

        $send_params = MeprHooks::apply_filters('mepr_cart_cancellation_email_params', [], $order, $this);

        parent::send($send_params, $formatted_subject, $formatted_body, $use_template, $content_type);
    }
}
