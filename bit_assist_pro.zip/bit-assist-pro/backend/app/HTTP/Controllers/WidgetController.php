<?php

namespace BitApps\AssistPro\HTTP\Controllers;

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\Assist\Config;
use BitApps\AssistPro\Deps\BitApps\WPKit\Http\Request\Request;
use BitApps\AssistPro\Deps\BitApps\WPKit\Http\Response;
use BitApps\AssistPro\HTTP\Requests\WidgetUpdateRequest;
use BitApps\AssistPro\Model\Widget;

final class WidgetController
{
    public function update(WidgetUpdateRequest $request, Widget $widget)
    {
        $widget->update($request->validated());

        if ($widget->save()) {
            return Response::success(__('Widget updated', 'bit-assist'));
        }

        return  Response::error(__('Widget update failed', 'bit-assist'));
    }

    public function changeActive(Request $request, $widgetId)
    {
        $activeWidget = Widget::where('active', 1)->where('id', '!=', $widgetId)->first();

        if (isset($activeWidget->id)) {
            $activeWidget->update(['active' => 0])->save();
        }

        $widget = Widget::where('id', $widgetId)->first();

        $widget->update(['active' => $request->active]);

        if ($widget->save()) {
            Config::updateOption('widget_active', (($request->active && $widget->status) ? $widget->id : null));

            if ($request->active) {
                return Response::success(__('Widget activated', 'bit-assist'));
            }

            return Response::success(__('Widget deactivated', 'bit-assist'));
        }

        return Response::error(__('Something went wrong', 'bit-assist'));
    }
}
