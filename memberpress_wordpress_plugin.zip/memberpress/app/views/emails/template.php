<?php if (!defined('ABSPATH')) {
    die('You are not allowed to call this page directly.');
} ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN" "http://www.w3.org/TR/REC-html40/loose.dtd">
<html>
  <head>
    <meta http-equiv="Content-Type" content="text/html;UTF-8">
  </head>
  <body style="background: #efefef; font: 13px 'Lucida Grande', 'Lucida Sans Unicode', Tahoma, Verdana, sans-serif; padding: 5px 0 10px" bgcolor="#efefef">
    <?php
    $mepr_email_template_handle = wp_unique_id('mepr-email-template-');
    wp_register_style($mepr_email_template_handle, false, [], MEPR_VERSION);
    wp_add_inline_style(
        $mepr_email_template_handle,
        'body {
      font: 13px "Lucida Grande", "Lucida Sans Unicode", Tahoma, Verdana, sans-serif; background-color: #efefef; padding: 5px 0 10px 0;
    }'
    );
    wp_print_styles([$mepr_email_template_handle]);
    ?>

    <?php echo wp_kses_post($body); ?>
  </body>
</html>

