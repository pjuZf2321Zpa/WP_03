<?php if (!defined('ABSPATH')) {
    die('You are not allowed to call this page directly.');
} ?>

<html lang="en">
<head>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta http-equiv="Content-Type" content="<?php bloginfo('html_type'); ?>; charset=<?php echo esc_attr(get_option('blog_charset')); ?>" />
  <meta name="robots" content="noindex,nofollow" />
  <title><?php esc_html_e('MemberPress database upgrade error', 'memberpress'); ?></title>
  <?php
    wp_register_style('memberpress-bootstrap-css', MEPR_CSS_URL . '/vendor/bootstrap.min.css', [], MEPR_BOOTSTRAP_VERSION);

    wp_register_style(
        'memberpress-db-upgrade',
        MEPR_CSS_URL . '/db-upgrade.css',
        ['memberpress-bootstrap-css'],
        MEPR_VERSION
    );

    wp_print_styles(['memberpress-bootstrap-css', 'memberpress-db-upgrade']);
    ?>
</head>
<body>
  <div class="container">
    <div class="row">&nbsp;</div>
    <div class="row">
      <div class="col-md-10 offset-md-1">
        <div class="card border-primary">
          <div class="card-header bg-primary text-white"><h2><?php esc_html_e('MemberPress database upgrade error', 'memberpress'); ?></h2></div>
          <div class="card-body">
            <p>&nbsp;</p>
            <h3><?php esc_html_e('Oops, your MemberPress database upgrade triggered an error...', 'memberpress'); ?></h3>
            <p><?php esc_html_e('If this is a production website contact our support team.', 'memberpress'); ?></p>
            <p>&nbsp;</p>
            <?php if (!empty($error)) : ?>
              <div class="alert alert-danger" role="alert"><?php echo esc_html($error); ?></div>
              <p>&nbsp;</p>
            <?php endif; ?>
            <p>
              <a class="btn btn-primary" href="<?php echo esc_url(MeprUtils::get_link_url('support')); ?>" target="_blank"><?php esc_html_e('Contact Support', 'memberpress'); ?></a>
            </p>
            <p>&nbsp;</p>
          </div>
        </div>
      </div>
    </div>
  </div>
</body>
</html>
