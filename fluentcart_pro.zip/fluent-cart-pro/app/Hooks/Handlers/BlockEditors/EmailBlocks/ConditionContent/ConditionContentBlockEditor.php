<?php

namespace FluentCartPro\App\Hooks\Handlers\BlockEditors\EmailBlocks\ConditionContent;

use FluentCart\App\Hooks\Handlers\BlockEditors\BlockEditor;

class ConditionContentBlockEditor extends BlockEditor
{
    use \FluentCartPro\App\Contracts\CanEnqueue;
    protected static string $editorName = 'condition-content';

    public function getScripts(): array
    {
        return [
            [
                'source'       => 'admin/BlockEditor/EmailBlocks/ConditionContent/ConditionContentBlockEditor.jsx',
                'dependencies' => ['wp-blocks', 'wp-block-editor']
            ]
        ];
    }

    public function getStyles(): array
    {
        return [];
    }

    public function localizeData(): array
    {
        return [
            $this->getLocalizationKey() => [
                'slug'        => $this->slugPrefix,
                'name'        => static::getEditorName(),
                'title'       => __('Condition Content', 'fluent-cart-pro'),
                'description' => __('Content shown when the condition is true.', 'fluent-cart-pro'),
            ],
            'fluent_cart_pro_block_translation' => \FluentCartPro\App\Services\Translations\Translations::blockStrings(),
        ];
    }

    public function blockAttributes(): array
    {
        return [];
    }

    public function supports(): array
    {
        return [
            'html'  => false,
            'align' => false,
        ];
    }

    public function render(array $attrs, $block = null, $content = ''): string
    {
        return $content;
    }
}
