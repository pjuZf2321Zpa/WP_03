<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Actions\MainWP\MainWPRecordHelper;
use BitApps\IntegrationsPro\Config;
use BitApps\IntegrationsPro\Core\Util\Hooks;

Hooks::filter(Config::withFreePrefix('main_wp_sync_site'), [MainWPRecordHelper::class, 'syncSite'], 10, 5);
Hooks::filter(Config::withFreePrefix('main_wp_sync_all_sites'), [MainWPRecordHelper::class, 'syncAllSites'], 10, 5);
Hooks::filter(Config::withFreePrefix('main_wp_create_post'), [MainWPRecordHelper::class, 'createPost'], 10, 5);
Hooks::filter(Config::withFreePrefix('main_wp_update_post'), [MainWPRecordHelper::class, 'updatePost'], 10, 5);
Hooks::filter(Config::withFreePrefix('main_wp_delete_post'), [MainWPRecordHelper::class, 'deletePost'], 10, 5);
Hooks::filter(Config::withFreePrefix('main_wp_activate_plugin'), [MainWPRecordHelper::class, 'activatePlugin'], 10, 5);
Hooks::filter(Config::withFreePrefix('main_wp_deactivate_plugin'), [MainWPRecordHelper::class, 'deactivatePlugin'], 10, 5);
Hooks::filter(Config::withFreePrefix('main_wp_create_user'), [MainWPRecordHelper::class, 'createUser'], 10, 5);

Hooks::add(MainWPRecordHelper::SYNC_BATCH_HOOK, [MainWPRecordHelper::class, 'processSyncBatch'], 10, 1);
