<?php
/**
 * The sales window of a ticket preset, as Event Tickets' relative sales window rule.
 *
 * @since 6.12.0
 *
 * @package TEC\Tickets_Plus\Relative_Sale_Dates\Ticket_Presets
 */

namespace TEC\Tickets_Plus\Relative_Sale_Dates\Ticket_Presets;

use InvalidArgumentException;
use TEC\Tickets\Relative_Sale_Dates\Boundary;
use TEC\Tickets\Relative_Sale_Dates\Editor;
use TEC\Tickets\Relative_Sale_Dates\Rule;
use TEC\Tickets\Relative_Sale_Dates\Window_Kind;
use TEC\Tickets_Plus\Ticket_Presets\Admin\Controller as Admin_Controller;
use WP_Error;

/**
 * Reads, checks and stores the sales window of a ticket preset as Event Tickets' sales window rule.
 *
 * A preset has no event, so its window only starts *Now* or relative to the event and only ends when the event starts
 * or relative to it. A preset saved before it stored the rule keeps its `sale_start_logic` / `sale_end_logic`, read
 * here boundary by boundary; every preset still stores them, for the code that fills a ticket's fixed dates from them.
 *
 * @since 6.12.0
 *
 * @package TEC\Tickets_Plus\Relative_Sale_Dates\Ticket_Presets
 */
final class Sales_Window {
	/**
	 * The key of the rule in the preset data.
	 *
	 * @since 6.12.0
	 *
	 * @var string
	 */
	public const DATA_KEY = 'relative_sale_dates';

	/**
	 * The unit of each sale logic period the rule has, in seconds, from the shortest.
	 *
	 * @since 6.12.0
	 *
	 * @var array<string,int>
	 */
	private const PERIOD_UNITS = [
		'minute' => MINUTE_IN_SECONDS,
		'hour'   => HOUR_IN_SECONDS,
		'day'    => DAY_IN_SECONDS,
		'week'   => WEEK_IN_SECONDS,
	];

	/**
	 * The larger unit a sale logic length too long for the rule can be counted in exactly, whatever the event's
	 * timezone: a day before an event is not always 24 hours before it.
	 *
	 * @since 6.12.0
	 *
	 * @var array<int,int>
	 */
	private const LARGER_UNITS = [
		MINUTE_IN_SECONDS => HOUR_IN_SECONDS,
		DAY_IN_SECONDS    => WEEK_IN_SECONDS,
	];

	/**
	 * Stores the sales window a preset is saved with: the rule, and the sale logic it works out to.
	 *
	 * The preset form and the *Save as preset* modal post the rule; a request without it, as from a form drawn before
	 * presets stored the rule, keeps the sale logic it posts, with the rule read from it.
	 *
	 * @since 6.12.0
	 *
	 * @param array<string,mixed>|WP_Error $data    The preset data, or why an earlier callback refused it.
	 * @param array<string,mixed>          $request The preset fields as posted, not sanitized.
	 *
	 * @return array<string,mixed>|WP_Error The preset data, with its sales window, or why the preset cannot be saved.
	 */
	public function filter_save_data( $data, array $request ) {
		if ( ! is_array( $data ) ) {
			return $data;
		}

		if ( ! isset( $request[ self::DATA_KEY ] ) ) {
			return $this->add_rule_to_data( $data );
		}

		$rule = $this->parse( $request[ self::DATA_KEY ] );

		if ( $rule instanceof WP_Error ) {
			return $rule;
		}

		return array_merge( $data, $this->to_data( $rule ) );
	}

	/**
	 * Adds the sales window rule to the data of a preset sent to the ticket editors.
	 *
	 * @since 6.12.0
	 *
	 * @param mixed $data The preset data, an array; anything else is returned as it came.
	 *
	 * @return mixed The preset data, with its rule under `relative_sale_dates`.
	 */
	public function filter_editor_data( $data ) {
		return is_array( $data ) ? $this->add_rule_to_data( $data ) : $data;
	}

	/**
	 * Gets the sales window rule of a preset, boundary by boundary.
	 *
	 * The stored rule wins; a preset saved before it is read from its sale logic.
	 *
	 * @since 6.12.0
	 *
	 * @param array{relative_sale_dates?: array{start?: array<string,int|string>|null, end?: array<string,int|string>|null}, sale_start_logic?: array<string,int|string>, sale_end_logic?: array<string,int|string>} $data The preset data, whose other keys are left alone.
	 *
	 * @return array{start: array{mode: string, value?: int, unit?: int, anchor?: string}|null, end: array{mode: string, value?: int, unit?: int, anchor?: string}|null} Each boundary,
	 *                                                                                                                                                                     or `null` where the preset has none the form offers.
	 */
	public function get_rule( array $data ): array {
		$stored = $data[ self::DATA_KEY ] ?? null;
		$rule   = [];

		foreach ( [ 'start', 'end' ] as $end ) {
			$rule[ $end ] = is_array( $stored )
				? $this->read_boundary( $stored[ $end ] ?? null, $end )
				: $this->read_sale_logic( $data[ "sale_{$end}_logic" ] ?? null, $end );
		}

		return $rule;
	}

	/**
	 * Adds the sales window to the data of a preset applied to a ticket, as the rule `get_rule()` gives.
	 *
	 * @since 6.12.0
	 *
	 * @param array{relative_sale_dates?: array{start?: array<string,int|string>|null, end?: array<string,int|string>|null}, sale_start_logic?: array<string,int|string>, sale_end_logic?: array<string,int|string>} $data The preset data, whose other keys are left alone.
	 *
	 * @return array<string,mixed> The preset data, with its rule under `relative_sale_dates`: every key it came with, of
	 *                             any type the preset stores.
	 */
	public function add_rule_to_data( array $data ): array {
		return array_merge( $data, [ self::DATA_KEY => $this->get_rule( $data ) ] );
	}

	/**
	 * Gets the rule the preset form starts from: what the preset has, and the default where it has nothing the form
	 * offers.
	 *
	 * @since 6.12.0
	 *
	 * @param array{relative_sale_dates?: array{start?: array<string,int|string>|null, end?: array<string,int|string>|null}, sale_start_logic?: array<string,int|string>, sale_end_logic?: array<string,int|string>} $data The preset data, whose other keys are left alone.
	 *
	 * @return array{start: array{mode: string, value?: int, unit?: int, anchor?: string}, end: array{mode: string, value?: int, unit?: int, anchor?: string}} The rule.
	 */
	public function get_form_rule( array $data ): array {
		return array_map(
			static fn( ?array $boundary ): array => $boundary ?? [ 'mode' => Rule::MODE_DEFAULT ],
			$this->get_rule( $data )
		);
	}

	/**
	 * Returns whether the preset stores, for one end of its window, a sales date option the form no longer offers: the
	 * form shows the default there, and saving the preset replaces the stored option with it.
	 *
	 * @since 6.12.0
	 *
	 * @param array{relative_sale_dates?: array{start?: array<string,int|string>|null, end?: array<string,int|string>|null}, sale_start_logic?: array<string,int|string>, sale_end_logic?: array<string,int|string>} $data The preset data, whose other keys are left alone.
	 *
	 * @return bool Whether an end of the window has no equivalent among the form's options.
	 */
	public function has_unsupported_stored_option( array $data ): bool {
		foreach ( $this->get_rule( $data ) as $end => $boundary ) {
			if ( null === $boundary && ( isset( $data[ self::DATA_KEY ] ) || isset( $data[ "sale_{$end}_logic" ] ) ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Checks the rule a preset form posts.
	 *
	 * @since 6.12.0
	 *
	 * @param mixed $raw The rule as posted, as JSON.
	 *
	 * @return array{start: array{mode: string, value?: int, unit?: int, anchor?: string}, end: array{mode: string, value?: int, unit?: int, anchor?: string}}|WP_Error The rule, or why it cannot be saved.
	 */
	public function parse( $raw ) {
		$kind = Window_Kind::sales();
		$rule = is_string( $raw ) ? Rule::from_raw( wp_unslash( $raw ), $kind ) : null;

		if (
			! $rule
			|| ! in_array( $rule->get_start()->get_mode(), Editor::PRESET_MODES, true )
			|| ! in_array( $rule->get_end()->get_mode(), Editor::PRESET_MODES, true )
		) {
			return new WP_Error( 'tec_tickets_plus_preset_invalid_sales_window', __( 'The sales dates of the preset are not valid.', 'event-tickets-plus' ) );
		}

		if ( $rule->ends_before_start_for_every_event() ) {
			return $kind->get_error( 'endsBeforeStart' );
		}

		return $rule->to_array();
	}

	/**
	 * Gets the preset data that stores a sales window: the rule, and the sale logic it works out to.
	 *
	 * @since 6.12.0
	 *
	 * @param array{start: array{mode: string, value?: int, unit?: int, anchor?: string}, end: array{mode: string, value?: int, unit?: int, anchor?: string}} $rule A rule `parse()` returned.
	 *
	 * @return array{relative_sale_dates: array<string,array<string,int|string>>, sale_start_logic: array<string,int|string>, sale_end_logic: array<string,int|string>} The preset data.
	 */
	public function to_data( array $rule ): array {
		return [
			self::DATA_KEY     => $rule,
			'sale_start_logic' => $this->to_sale_logic( $rule['start'], 'start' ),
			'sale_end_logic'   => $this->to_sale_logic( $rule['end'], 'end' ),
		];
	}

	/**
	 * Reads one boundary of a stored rule.
	 *
	 * @since 6.12.0
	 *
	 * @param mixed  $data The boundary as stored.
	 * @param string $end  The end of the window, `start` or `end`.
	 *
	 * @return array{mode: string, value?: int, unit?: int, anchor?: string}|null The boundary, or `null` when it is not one the form offers.
	 */
	private function read_boundary( $data, string $end ): ?array {
		if ( ! is_array( $data ) || ! in_array( $data['mode'] ?? null, Editor::PRESET_MODES, true ) ) {
			return null;
		}

		try {
			return Boundary::from_array( $data, Window_Kind::sales(), $end )->to_array();
		} catch ( InvalidArgumentException $e ) {
			return null;
		}
	}

	/**
	 * Reads one end of the sale logic a preset saved before it stored the rule.
	 *
	 * Only an exact equivalent is read. A length the rule's range cannot hold is counted in the next unit up when it
	 * divides exactly; months, *after*, a length counted from *now* and anything else have no equivalent.
	 *
	 * @since 6.12.0
	 *
	 * @param mixed  $logic The sale logic, as stored.
	 * @param string $end   The end of the window, `start` or `end`.
	 *
	 * @return array{mode: string, value?: int, unit?: int, anchor?: string}|null The boundary, or `null` when it has no equivalent.
	 */
	private function read_sale_logic( $logic, string $end ): ?array {
		$type = is_array( $logic ) ? ( $logic['type'] ?? null ) : null;

		if ( Admin_Controller::DEFAULT_SALE_LOGIC[ "sale_{$end}_logic" ]['type'] === $type ) {
			return [ 'mode' => Rule::MODE_DEFAULT ];
		}

		if (
			'relative' !== $type
			|| 'before' !== ( $logic['direction'] ?? null )
			|| ! in_array( $logic['relative_to'] ?? null, [ Rule::ANCHOR_START, Rule::ANCHOR_END ], true )
			|| ! isset( self::PERIOD_UNITS[ $logic['period'] ?? '' ] )
			|| ! is_numeric( $logic['length'] ?? null )
		) {
			return null;
		}

		$unit  = self::PERIOD_UNITS[ $logic['period'] ];
		$value = absint( $logic['length'] );

		if ( $value > Boundary::MAX_VALUE && isset( self::LARGER_UNITS[ $unit ] ) && 0 === $value * $unit % self::LARGER_UNITS[ $unit ] ) {
			$value = $value * $unit / self::LARGER_UNITS[ $unit ];
			$unit  = self::LARGER_UNITS[ $unit ];
		}

		return $this->read_boundary(
			[
				'mode'   => Rule::MODE_RELATIVE,
				'value'  => $value,
				'unit'   => $unit,
				'anchor' => $logic['relative_to'],
			],
			$end
		);
	}

	/**
	 * Gets the sale logic one boundary of the rule works out to.
	 *
	 * @since 6.12.0
	 *
	 * @param array{mode: string, value?: int, unit?: int, anchor?: string} $boundary The boundary.
	 * @param string                                                        $end      The end of the window, `start` or `end`.
	 *
	 * @return array{type: string, relative_to?: string, direction?: string, period?: string, length?: int} The sale logic.
	 */
	private function to_sale_logic( array $boundary, string $end ): array {
		if ( Rule::MODE_RELATIVE !== $boundary['mode'] ) {
			return Admin_Controller::DEFAULT_SALE_LOGIC[ "sale_{$end}_logic" ];
		}

		return [
			'type'        => 'relative',
			'relative_to' => $boundary['anchor'],
			'direction'   => 'before',
			'period'      => array_search( $boundary['unit'], self::PERIOD_UNITS, true ),
			'length'      => $boundary['value'],
		];
	}
}
