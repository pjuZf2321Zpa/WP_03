<?php

// @psalm-ignore-file

namespace Breakdance\Admin\SettingsPage\AgentsAndMcpTab;

use function Breakdance\Util\is_post_request;
use function Breakdance\BreakdanceOxygen\Strings\__bdox;

const PLUGIN_BASENAME = 'agent-connector-for-wp/agent-connector-for-wp.php';
const PLUGIN_DOWNLOAD_URL = 'https://github.com/soflyy/agent-connector-for-wp/releases/latest/download/agent-connector-for-wp.zip';
const PLUGIN_INSTALL_DOCS_URL = 'https://wpagentconnector.com/docs/install-agent-connector/';

/**
 * Whether MCP access is enabled for the builder.
 *
 * Gates registration of the builder's MCP abilities and tools (see mcp/base.php).
 * On until the tab is first saved with it off (the setting's default).
 *
 * @return bool
 */
function isMcpEnabled()
{
    return \Breakdance\Settings\get_bool_setting('agents_and_mcp_enable_mcp_access');
}

/**
 * Whether the Design Library MCP tools are enabled.
 *
 * Gates registration of the design-library abilities and tools (see
 * mcp/tools/design-library.php). Unlike MCP access itself these default to
 * off.
 *
 * @return bool
 */
function areDesignLibraryToolsEnabled()
{
    return \Breakdance\Settings\get_bool_setting('agents_and_mcp_enable_design_library_tools');
}

add_action('breakdance_register_admin_settings_page_register_tabs', '\Breakdance\Admin\SettingsPage\AgentsAndMcpTab\register');

function register()
{
    \Breakdance\Admin\SettingsPage\addTab(
        esc_html__('Agents & MCP', 'breakdance'),
        'agents-and-mcp',
        '\Breakdance\Admin\SettingsPage\AgentsAndMcpTab\tab',
        9999
    );
}

/**
 * @return bool
 */
function isPluginInstalled()
{
    /** @psalm-suppress UndefinedConstant */
    return file_exists(WP_PLUGIN_DIR . '/' . PLUGIN_BASENAME);
}

/**
 * @return bool
 */
function isPluginActive()
{
    if (!function_exists('is_plugin_active')) {
        /**
         * @psalm-suppress UnresolvableInclude
         * @psalm-suppress UndefinedConstant
         */
        require_once ABSPATH . 'wp-admin/includes/plugin.php';
    }

    return is_plugin_active(PLUGIN_BASENAME);
}

/**
 * Download the official release zip and install the plugin in one click.
 * Activation is best-effort; install success does not depend on it.
 *
 * @return true|\WP_Error
 */
function installPlugin()
{
    if (!current_user_can('install_plugins')) {
        return new \WP_Error(
            'insufficient_permissions',
            esc_html__('You do not have permission to install plugins on this site.', 'breakdance')
        );
    }

    /**
     * @psalm-suppress UnresolvableInclude
     * @psalm-suppress UndefinedConstant
     */
    require_once ABSPATH . 'wp-admin/includes/file.php';
    /**
     * @psalm-suppress UnresolvableInclude
     * @psalm-suppress UndefinedConstant
     */
    require_once ABSPATH . 'wp-admin/includes/misc.php';
    /**
     * @psalm-suppress UnresolvableInclude
     * @psalm-suppress UndefinedConstant
     */
    require_once ABSPATH . 'wp-admin/includes/plugin.php';
    /**
     * @psalm-suppress UnresolvableInclude
     * @psalm-suppress UndefinedConstant
     */
    require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';

    // Already installed — nothing to download. Just make sure it is active.
    if (isPluginInstalled()) {
        if (!is_plugin_active(PLUGIN_BASENAME)) {
            activate_plugin(PLUGIN_BASENAME);
        }
        return true;
    }

    $skin = new \Automatic_Upgrader_Skin();
    $upgrader = new \Plugin_Upgrader($skin);

    /** @psalm-suppress MixedAssignment */
    $result = $upgrader->install(PLUGIN_DOWNLOAD_URL);

    if ($result instanceof \WP_Error) {
        return $result;
    }

    if ($result !== true) {
        return new \WP_Error(
            'install_failed',
            esc_html__('Could not install the plugin automatically. Please install it manually by following the installation guide.', 'breakdance')
        );
    }

    // Best-effort activation — the status row reflects active/inactive either way.
    if (!is_plugin_active(PLUGIN_BASENAME)) {
        activate_plugin(PLUGIN_BASENAME);
    }

    return true;
}

/**
 * Activate the already-installed plugin.
 *
 * @return true|\WP_Error
 */
function activatePlugin()
{
    if (!current_user_can('activate_plugins')) {
        return new \WP_Error(
            'insufficient_permissions',
            esc_html__('You do not have permission to activate plugins on this site.', 'breakdance')
        );
    }

    if (!function_exists('activate_plugin')) {
        /**
         * @psalm-suppress UnresolvableInclude
         * @psalm-suppress UndefinedConstant
         */
        require_once ABSPATH . 'wp-admin/includes/plugin.php';
    }

    $result = activate_plugin(PLUGIN_BASENAME);

    if ($result instanceof \WP_Error) {
        return $result;
    }

    return true;
}

function tab()
{
    $nonce_action = 'breakdance_admin_agents_and_mcp_tab';
    $install_error = null;
    $install_show_guide = false;
    $install_success = false;
    $activate_error = null;
    $activate_success = false;

    if (is_post_request() && check_admin_referer($nonce_action)) {
        $action = isset($_POST['agents_mcp_action'])
            ? sanitize_text_field((string) $_POST['agents_mcp_action'])
            : '';

        if ($action === 'install') {
            $result = installPlugin();

            if ($result instanceof \WP_Error) {
                $install_error = $result->get_error_message();
                // A manual install can't fix missing permissions; any other failure it can.
                $install_show_guide = $result->get_error_code() !== 'insufficient_permissions';
            } else {
                $install_success = true;
            }
        } elseif ($action === 'activate') {
            $result = activatePlugin();

            if ($result instanceof \WP_Error) {
                $activate_error = $result->get_error_message();
            } else {
                $activate_success = true;
            }
        } else {
            // Every field is named after the option it saves; see
            // \Breakdance\Settings\save_tab_from_post(). Read back through
            // isMcpEnabled() and areDesignLibraryToolsEnabled().
            \Breakdance\Settings\save_tab_from_post('agents_and_mcp');
        }
    }

    $installed = isPluginInstalled();
    $active = $installed && isPluginActive();

    // Checked until the tab is first saved with it off.
    $enable_mcp_checked = isMcpEnabled();

    // Unchecked until switched on.
    $design_library_tools_checked = areDesignLibraryToolsEnabled();
    ?>

    <h2><?php esc_html_e('Agents & MCP', 'breakdance'); ?></h2>

    <?php if ($install_success) : ?>
        <div class="notice notice-success padded-notice">
            <p><?php esc_html_e('Agent Connector was installed successfully.', 'breakdance'); ?></p>
        </div>
    <?php elseif ($install_error) : ?>
        <div class="notice notice-error padded-notice">
            <p><?php echo esc_html($install_error); ?></p>
            <?php if ($install_show_guide) : ?>
                <p>
                    <a href="<?php echo esc_url(PLUGIN_INSTALL_DOCS_URL); ?>" class="button" target="_blank" rel="noopener noreferrer">
                        <?php esc_html_e('View Installation Guide', 'breakdance'); ?>
                    </a>
                </p>
            <?php endif; ?>
        </div>
    <?php elseif ($activate_success) : ?>
        <div class="notice notice-success padded-notice">
            <p><?php esc_html_e('Agent Connector was activated.', 'breakdance'); ?></p>
        </div>
    <?php elseif ($activate_error) : ?>
        <div class="notice notice-error padded-notice">
            <p><?php echo esc_html($activate_error); ?></p>
        </div>
    <?php endif; ?>

    <table class="form-table" role="presentation">
        <tbody>
            <tr>
                <th scope="row"><?php esc_html_e('Agent Connector Plugin', 'breakdance'); ?></th>
                <td>
                    <?php if ($installed && $active) : ?>
                        <p style="margin-top: 0; font-size: 14px;">
                            <strong style="color: #008a20;">&#10003; <?php esc_html_e('Active', 'breakdance'); ?></strong>
                        </p>
                        <p class="description">
                            <?php
                            printf(
                                /* translators: 1: opening <a> tag to the Plugins screen, 2: closing </a> tag */
                                esc_html__('Agent Connector can be managed or deactivated from the %1$sPlugins page%2$s.', 'breakdance'),
                                '<a href="' . esc_url(admin_url('plugins.php')) . '">',
                                '</a>'
                            );
                            ?>
                        </p>
                        <p style="margin-top: 12px;">
                            <a href="<?php echo esc_url(admin_url('admin.php?page=agent-connector-for-wp')); ?>" class="button button-primary">
                                <?php esc_html_e('Connect', 'breakdance'); ?>
                            </a>
                        </p>
                    <?php elseif ($installed) : ?>
                        <p style="margin-top: 0; font-size: 14px;">
                            <strong style="color: #dba617;"><?php esc_html_e('Inactive', 'breakdance'); ?></strong>
                        </p>
                        <p class="description">
                            <?php esc_html_e('Agent Connector is installed, but not active.', 'breakdance'); ?>
                        </p>
                        <form action="" method="post" style="margin-top: 12px;">
                            <?php wp_nonce_field($nonce_action); ?>
                            <input type="hidden" name="agents_mcp_action" value="activate" />
                            <button type="submit" class="button button-primary">
                                <?php esc_html_e('Activate Agent Connector', 'breakdance'); ?>
                            </button>
                        </form>
                    <?php else : ?>
                        <form action="" method="post">
                            <?php wp_nonce_field($nonce_action); ?>
                            <input type="hidden" name="agents_mcp_action" value="install" />
                            <button type="submit" class="button button-primary button-hero">
                                <?php esc_html_e('Install Agent Connector', 'breakdance'); ?>
                            </button>
                            <p class="description">
                                <?php
                                /* translators: %s: plugin name (Oxygen or Breakdance) */
                                printf(esc_html__('Install the Agent Connector plugin in one click. This plugin is required to drive %s over MCP.', 'breakdance'), __bdox('plugin_name'));
                                ?>
                            </p>
                        </form>
                    <?php endif; ?>
                </td>
            </tr>
        </tbody>
    </table>

    <form action="" method="post">
        <?php wp_nonce_field($nonce_action); ?>
        <table class="form-table" role="presentation">
            <tbody>
                <tr>
                    <th scope="row"><?php esc_html_e('Enable MCP Access', 'breakdance'); ?></th>
                    <td>
                        <fieldset>
                            <label for="enable_mcp_access">
                                <input type="checkbox" id="enable_mcp_access" name="agents_and_mcp_enable_mcp_access" value="yes" <?php echo $enable_mcp_checked ? 'checked' : ''; ?> />
                                <?php esc_html_e('Allow agents to access this site over MCP', 'breakdance'); ?>
                            </label>
                        </fieldset>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><?php esc_html_e('Design Library Tools', 'breakdance'); ?></th>
                    <td>
                        <fieldset>
                            <label for="enable_design_library_tools">
                                <input type="checkbox" id="enable_design_library_tools" name="agents_and_mcp_enable_design_library_tools" value="yes" <?php echo $design_library_tools_checked ? 'checked' : ''; ?> />
                                <?php esc_html_e('Let agents browse the Design Library and insert its designs into pages', 'breakdance'); ?>
                            </label>
                            <p class="description">
                                <?php esc_html_e('Off by default. Adds MCP tools for listing design sets, browsing their items, and copying sections into posts on this site.', 'breakdance'); ?>
                            </p>
                        </fieldset>
                    </td>
                </tr>
            </tbody>
        </table>

        <p class="submit">
            <input type="submit" name="submit" id="submit" class="button button-primary" value="<?php esc_attr_e('Save Changes', 'breakdance'); ?>" />
        </p>
    </form>

    <?php
}
