<?php

namespace FluentCartPro\App\Modules\Reviews\Services;

use FluentCartPro\App\Modules\Reviews\Http\Controllers\Concerns\RateLimitsTrait;

class ReviewUploadLimiter
{
    use RateLimitsTrait;

    /** Reserve one shopper photo attempt before processing any image bytes. */
    public function claimSlot(): bool
    {
        $userId = get_current_user_id();
        $ip = $this->getClientIp();
        if ( !$userId && !$ip ) {
            return false;
        }

        $key = $userId ? 'fct_review_upload_user_' . $userId : 'fct_review_upload_' . md5( $ip );

        return $this->atomicIncrement( $key, HOUR_IN_SECONDS ) <= 20;
    }
}
