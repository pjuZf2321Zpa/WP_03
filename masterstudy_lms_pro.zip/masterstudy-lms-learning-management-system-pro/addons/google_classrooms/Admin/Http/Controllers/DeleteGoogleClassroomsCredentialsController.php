<?php

namespace MasterStudy\Lms\Pro\addons\google_classrooms\Admin\Http\Controllers;

use MasterStudy\Lms\Http\WpResponseFactory;
use MasterStudy\Lms\Pro\addons\google_classrooms\Admin\Repositories\GoogleClassroomsImportRepository;
use WP_REST_Response;

final class DeleteGoogleClassroomsCredentialsController {
	public function __invoke(): WP_REST_Response {
		return WpResponseFactory::ok_with_data(
			( new GoogleClassroomsImportRepository() )->delete_credentials()
		);
	}
}
