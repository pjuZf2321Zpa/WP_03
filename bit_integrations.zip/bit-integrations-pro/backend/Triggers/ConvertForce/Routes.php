<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Core\Util\Route;
use BitApps\IntegrationsPro\Triggers\ConvertForce\ConvertForceController;

Route::get('convert-force/get', [ConvertForceController::class, 'getAllTasks']);
