<?php

namespace FluentCartPro\App\Http\Policies;
use FluentCart\App\Http\Policies\Policy;
use FluentCart\Framework\Http\Request\Request;


class LicensePolicy extends Policy
{
    public function verifyRequest(Request $request)
    {
        return $this->hasRoutePermissions();
    }

    public function index(Request $request)
    {
        return $this->userCan('licenses/view');
    }

    public function store(Request $request)
    {
        return $this->userCan('licenses/manage');
    }

    public function update(Request $request)
    {
        return $this->userCan('licenses/manage');
    }

    public function delete(Request $request)
    {
        return $this->userCan('licenses/delete');
    }
}
