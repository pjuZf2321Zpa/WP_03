<?php
/** Paid Smart SEO controls for Automations. */
if (!defined('ABSPATH')) {
    exit;
}

function aipkit_render_paid_automation_seo_panel(string $aipkit_panel, array $aipkit_profile = []): void
{
    if (!class_exists('\\WPAICG\\aipkit_dashboard') || !\WPAICG\aipkit_dashboard::is_pro_plan()) {
        return;
    }
    if (!in_array($aipkit_panel, ['toggle', 'approach', 'popover'], true)) {
        return;
    }
    $aipkit_profile = array_merge([
        'key' => 'aipkit',
        'label' => __('AIPKit SEO', 'gpt3-ai-content-generator'),
        'logo_url' => '',
        'logo_initials' => 'AI',
        'has_plugin' => false,
    ], $aipkit_profile);
    if ($aipkit_panel === 'toggle') {
        ?>
    <div class="aipkit_cw_panel_label_wrap">

            <span class="aipkit_cw_panel_label aipkit_autogpt_question">
                <span class="aipkit_seo_settings_label">
                    <?php if ($aipkit_profile['has_plugin']) : ?>
                        <?php
                        printf(
                            wp_kses(
                                /* translators: %s: active SEO plugin name. */
                                __('You are using <strong>%s</strong>. Optimize each post for SEO?', 'gpt3-ai-content-generator'),
                                ['strong' => []]
                            ),
                            esc_html($aipkit_profile['label'])
                        );
                        ?>
                    <?php else : ?>
                        <?php esc_html_e('Optimize each post for SEO?', 'gpt3-ai-content-generator'); ?>
                    <?php endif; ?>
                </span>
            </span>

    </div>
    <div class="aipkit_cw_ai_control aipkit_cw_ai_control--compact">
        <div class="aipkit_cw_seo_inline_actions">

                <select
                    id="aipkit_task_cw_seo_score_improvement_enabled"
                    name="seo_score_improvement_enabled"
                    class="aipkit_autosave_trigger"
                    data-aipkit-task-smart-seo-control
                    data-aipkit-task-smart-seo-main-toggle
                    data-aipkit-segmented-select
                >
                    <option value="0"><?php esc_html_e('No', 'gpt3-ai-content-generator'); ?></option>
                    <option value="1" selected><?php esc_html_e('Yes', 'gpt3-ai-content-generator'); ?></option>
                </select>

        </div>
    </div>
        <?php
        return;
    }
    $aipkit_task_cw_seo_rules_class = '\\WPAICG\\ContentWriter\\SEO\\AIPKit_Content_Writer_Smart_SEO_Rules';
    if (!class_exists($aipkit_task_cw_seo_rules_class) && defined('WPAICG_LIB_DIR')) {
        $aipkit_task_cw_seo_rules_path = WPAICG_LIB_DIR . 'content-writer/seo-rules.php';
        if (file_exists($aipkit_task_cw_seo_rules_path)) {
            require_once $aipkit_task_cw_seo_rules_path;
        }
    }
    if (!class_exists($aipkit_task_cw_seo_rules_class) || empty($aipkit_task_cw_seo_rules_class::rule_catalog())) {
        return;
    }
    if ($aipkit_panel === 'approach') {
        ?>

    <div
        class="aipkit_cw_ai_row aipkit_autogpt_question_row aipkit_autogpt_seo_approach_row"
        data-aipkit-smart-seo-rules-action
        hidden
    >
        <div class="aipkit_cw_panel_label_wrap">
            <span
                class="aipkit_cw_panel_label aipkit_autogpt_question"
                id="aipkit_task_cw_smart_seo_approach_label"
            >
                <?php esc_html_e('SEO approach', 'gpt3-ai-content-generator'); ?>
            </span>
        </div>
        <div class="aipkit_cw_ai_control aipkit_cw_ai_control--compact">
            <button
                type="button"
                class="aipkit_autogpt_seo_approach_trigger"
                id="aipkit_task_cw_smart_seo_rules_trigger"
                data-aipkit-smart-seo-modal-trigger
                data-aipkit-smart-seo-modal-target="aipkit_task_cw_smart_seo_rules_popover"
                aria-controls="aipkit_task_cw_smart_seo_rules_popover"
                aria-expanded="false"
                aria-haspopup="dialog"
                aria-labelledby="aipkit_task_cw_smart_seo_approach_label aipkit_task_cw_smart_seo_approach_value"
            >
                <span id="aipkit_task_cw_smart_seo_approach_value" data-aipkit-smart-seo-trigger-value>
                    <?php esc_html_e('Balanced', 'gpt3-ai-content-generator'); ?>
                </span>
                <span class="aipkit_autogpt_seo_approach_chevron" aria-hidden="true"></span>
            </button>
        </div>
    </div>
        <?php
        return;
    }
    $aipkit_smart_seo_rules_popover_id = 'aipkit_task_cw_smart_seo_rules_popover';
    $aipkit_smart_seo_rules_profile_key = $aipkit_profile['key'];
    $aipkit_smart_seo_rules_profile_label = $aipkit_profile['label'];
    $aipkit_smart_seo_rules_profile_logo_url = $aipkit_profile['logo_url'];
    $aipkit_smart_seo_rules_profile_logo_initials = $aipkit_profile['logo_initials'];
    $aipkit_smart_seo_rules_popover_path = defined('WPAICG_LIB_DIR') ? WPAICG_LIB_DIR . 'views/shared/smart-seo-rules-popover.php' : '';
    if ($aipkit_smart_seo_rules_popover_path !== '' && file_exists($aipkit_smart_seo_rules_popover_path)) {
        include $aipkit_smart_seo_rules_popover_path;
    }
}
