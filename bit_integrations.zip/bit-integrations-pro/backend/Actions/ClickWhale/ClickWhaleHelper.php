<?php

namespace BitApps\IntegrationsPro\Actions\ClickWhale;

/**
 * Shared helpers for the ClickWhale action handlers.
 *
 * Ported from bit-pi's ClickWhale helper, with the bit-pi status_code envelope
 * replaced by the success/message envelope Bit Integrations logs.
 */
final class ClickWhaleHelper
{
    public static function isPluginActive()
    {
        return \defined('CLICKWHALE_VERSION');
    }

    /**
     * Resolve the links table, preferring ClickWhale's own accessor so a future
     * rename or re-prefix is picked up automatically.
     *
     * @return string
     */
    public static function getTableName()
    {
        global $wpdb;

        if (\is_callable(['\clickwhale\includes\helpers\Helper', 'get_db_table_name'])) {
            return \clickwhale\includes\helpers\Helper::get_db_table_name('links');
        }

        return $wpdb->prefix . 'clickwhale_links';
    }

    public static function getLinkRecord($linkId)
    {
        global $wpdb;

        $table = self::getTableName();

        // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery -- table name comes from ClickWhale's own accessor
        $row = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table} WHERE id = %d", (int) $linkId), ARRAY_A);

        return \is_array($row) ? $row : [];
    }

    /**
     * Verify every required key is present and non-empty.
     *
     * @param array $fieldData
     * @param array $required
     *
     * @return null|array Error envelope listing the missing keys, null when satisfied
     */
    public static function requireFields($fieldData, array $required)
    {
        $missing = [];

        foreach ($required as $key) {
            if (!isset($fieldData[$key]) || $fieldData[$key] === '' || $fieldData[$key] === null) {
                $missing[] = $key;
            }
        }

        if (!empty($missing)) {
            return self::errorResponse(
                // translators: %s: comma separated field names
                wp_sprintf(__('Missing required field(s): %s', 'bit-integrations-pro'), implode(', ', $missing))
            );
        }
    }

    /**
     * Map a Utilities yes/no choice onto the smallint the links table stores.
     *
     * @param null|object $utilities
     * @param string      $key
     *
     * @return null|int Null when unset, so the caller can leave the column alone
     */
    public static function flagValue($utilities, $key)
    {
        if (!isset($utilities->{$key}) || $utilities->{$key} === '') {
            return;
        }

        return $utilities->{$key} === 'yes' ? 1 : 0;
    }

    /**
     * Read an optional value set by a Utilities checkbox.
     *
     * @param null|object $utilities
     * @param string      $key
     * @param mixed       $default
     *
     * @return mixed
     */
    public static function utilityValue($utilities, $key, $default = '')
    {
        return isset($utilities->{$key}) && $utilities->{$key} !== ''
            ? $utilities->{$key}
            : $default;
    }

    public static function errorResponse($message)
    {
        return [
            'success' => false,
            'message' => $message
        ];
    }

    public static function successResponse($message, $data = [])
    {
        return [
            'success' => true,
            'message' => $message,
            'data'    => $data
        ];
    }
}
