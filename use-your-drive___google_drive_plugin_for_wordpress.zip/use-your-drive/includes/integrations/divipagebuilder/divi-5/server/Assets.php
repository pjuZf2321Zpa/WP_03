<?php
/**
 * Visual Builder asset registration.
 */

namespace TheLion\Integrations\Divi\D5;

use ET\Builder\VisualBuilder\Assets\PackageBuildManager;

defined('ABSPATH') || exit;

final class Assets
{
    /**
     * Package name. Divi derives the injected JS data object from it.
     */
    public const PACKAGE = 'wpcp-divi';

    /**
     * Script handle of the shared WP Cloud Plugins bridge runtime.
     */
    public const BRIDGE_HANDLE = 'WPCloudPlugins.Bridge';

    /**
     * Register the builder bundle. Hooked to
     * `divi_visual_builder_assets_before_enqueue_scripts`.
     */
    public static function enqueue(): void
    {
        if (!self::is_divi_5_builder() || !class_exists(PackageBuildManager::class)) {
            return;
        }

        PackageBuildManager::register_package_build(
            [
                'name' => self::PACKAGE,
                'version' => WPCP_DIVI_EXTENSION_VERSION,
                'script' => [
                    'src' => Bootstrap::url('visual-builder/build/wpcp-divi.js'),
                    'deps' => [
                        'react',
                        'jquery',
                        'divi-module-library',
                        'divi-vendor-wp-hooks',
                        'divi-data',
                        'divi-modal',
                        'divi-error-boundary',

                        // The popup reports its result over the bridge, so the runtime
                        // has to be present in the builder's app window.
                        self::BRIDGE_HANDLE,
                    ],
                    'data_app_window' => [
                        'config' => self::config(),
                    ],
                    'enqueue_top_window' => false,
                    'enqueue_app_window' => true,
                ],
                'style' => [
                    'src' => Bootstrap::url('visual-builder/build/wpcp-divi.css'),
                    'deps' => [],
                    'enqueue_top_window' => true,
                    'enqueue_app_window' => true,
                ],
            ]
        );
    }

    /**
     * Data handed to the builder bundle.
     *
     * @return array<string, mixed>
     */
    private static function config(): array
    {
        $products = [];

        foreach (Modules::active() as $slug => $product) {
            $products[$slug] = [
                'name' => $product['title'],
                'adminUrl' => constant($product['admin_url_constant']),
                'bridgeProduct' => $product['bridge_product'],
                'previewNonce' => wp_create_nonce($slug.'-module-preview'),
                'defaultShortcode' => $product['default_shortcode'],
            ];
        }

        return [
            'products' => $products,
            'origin' => untrailingslashit(site_url()),
            'i18n' => [
                'configure' => esc_html__('Configure module', 'wpcloudplugins'),
                'openBuilder' => esc_html__('Open Module Builder', 'wpcloudplugins'),
                'builderTitle' => esc_html__('Module Builder', 'wpcloudplugins'),
                'close' => esc_html__('Close', 'wpcloudplugins'),
                'loading' => esc_html__('Loading…', 'wpcloudplugins'),
                'emptyHint' => esc_html__('Open the Module Builder to configure this module.', 'wpcloudplugins'),
                'unavailable' => esc_html__('The Module Builder could not be opened. Reload the page and try again.', 'wpcloudplugins'),
                'previewTitle' => esc_html__('Module preview', 'wpcloudplugins'),
                'previewFailed' => esc_html__('The preview could not be loaded.', 'wpcloudplugins'),
            ],
        ];
    }

    /**
     * True when this request is the Divi 5 Visual Builder.
     */
    private static function is_divi_5_builder(): bool
    {
        if (!function_exists('et_builder_d5_enabled') || !et_builder_d5_enabled()) {
            return false;
        }

        return function_exists('et_core_is_fb_enabled') && et_core_is_fb_enabled();
    }
}
