<?php

if (!defined('ABSPATH')) {
    die('You are not allowed to call this page directly.');
}

/**
 * Cart order receipt email sent to the customer.
 *
 * Sends one consolidated receipt per cart order (not one per transaction).
 * Includes a full line-item table with product name, qty, price, and totals.
 */
class MeprUserCartReceiptEmail extends MeprBaseOptionsUserEmail
{
    /**
     * Set the default enabled, title, subject & body.
     *
     * @param  array $args The args.
     * @return void
     */
    public function set_defaults($args = [])
    {
        $this->title       = __('<b>Cart Order Receipt</b> Notice', 'memberpress');
        $this->description = __('Sent to a customer after completing a multi-item cart checkout.', 'memberpress');
        $this->ui_order    = 1;

        $enabled = $use_template = $this->show_form = true;
        $subject = __('Your Order Receipt — Order #{$order_id}', 'memberpress');
        $body    = $this->body_partial();

        $this->defaults  = compact('enabled', 'subject', 'body', 'use_template');
        $this->variables = self::get_cart_email_vars();
    }

    /**
     * Get the body partial for the email.
     *
     * @param  array $vars Variables passed to the body partial.
     * @return string The body partial HTML.
     */
    public function body_partial($vars = [])
    {
        return MeprView::get_string('/emails/user-cart-receipt', $vars);
    }

    /**
     * Send the cart receipt email for the given order.
     *
     * Overrides the base send() to accept a MeprOrder (not MeprTransaction).
     *
     * @param  MeprOrder    $order        The completed cart order.
     * @param  string|false $subject      Subject override, or false for the stored default.
     * @param  string|false $body         Body override, or false for the stored default.
     * @param  boolean|null $use_template Whether to wrap in the email template, or null for the default.
     * @param  string       $content_type The content type of the email.
     * @return void
     */
    public function send($order = [], $subject = false, $body = false, $use_template = null, $content_type = 'html')
    {
        if (!($order instanceof MeprOrder)) {
            parent::send($order, $subject, $body, $use_template, $content_type);
            return;
        }

        if (!$this->enabled()) {
            return;
        }

        $user         = new MeprUser($order->user_id);
        $transactions = MeprTransaction::get_all_by_order_id_for_display($order->id);

        $this->to = $user->user_email;

        $vars = $this->build_cart_vars($order, $user, $transactions);

        $formatted_subject = MeprUtils::replace_vals($this->get_stored_field('subject'), $vars);
        $formatted_body    = MeprUtils::replace_vals($this->get_stored_field('body'), $vars);

        // Let add-ons inject send params (e.g. pdf-invoice adds pdf_txn). Core stays agnostic.
        $send_params = MeprHooks::apply_filters('mepr_cart_receipt_email_params', [], $order, $this);

        parent::send($send_params, $formatted_subject, $formatted_body, $use_template, $content_type);
    }

    /**
     * Get the available email template variables.
     *
     * @return array Variable name => description map.
     */
    public static function get_cart_email_vars()
    {
        return [
            '{$user_first_name}' => __('User First Name', 'memberpress'),
            '{$user_last_name}'  => __('User Last Name', 'memberpress'),
            '{$user_email}'      => __('User Email', 'memberpress'),
            '{$order_id}'        => __('Order ID', 'memberpress'),
            '{$order_total}'     => __('Order Total', 'memberpress'),
            '{$order_items}'     => __('Order Items (HTML table)', 'memberpress'),
            '{$order_date}'      => __('Order Date', 'memberpress'),
            '{$payment_method}'  => __('Payment Method', 'memberpress'),
        ];
    }

    /**
     * Build the template variable replacement map for a cart order.
     *
     * @param  MeprOrder         $order        The cart order.
     * @param  MeprUser          $user         The purchasing user.
     * @param  MeprTransaction[] $transactions All transactions in the order.
     * @return array
     */
    private function build_cart_vars($order, $user, $transactions)
    {
        $items_html = $this->build_items_table($transactions, $order);

        $vars = [
            'user_first_name' => $user->first_name ?: '',
            'user_last_name'  => $user->last_name ?: '',
            'user_email'      => $user->user_email,
            'order_id'        => $order->id,
            'order_total'     => MeprAppHelper::format_currency($order->total, true, false, false, $order->currency),
            'order_items'     => $items_html,
            'order_date'      => MeprAppHelper::format_date($order->created_at, ''),
            'payment_method'  => MeprCartOrderDisplayHelper::payment_method_name($order),
        ];

        return self::escape_vars($vars);
    }

    /**
     * Escape "$" in cart email values so replace_vals' preg_replace doesn't eat "$30" as backreference (→ ".00").
     *
     * @param  array $vars The email variable map.
     * @return array
     */
    public static function escape_vars(array $vars)
    {
        return array_map(fn($v) => is_string($v) ? preg_replace('~\$~', '\\\$', $v) : $v, $vars);
    }

    /**
     * Build an HTML table of line items for the order — shared by the user and admin receipts.
     *
     * Same presentation as thank-you / checkout: gross snapshot-first lines (unit × qty)
     * summing to Subtotal, per-line billing byline, Discount (code), per-product tax rows.
     *
     * @param  MeprTransaction[] $transactions The transactions to display.
     * @param  MeprOrder         $order        The parent cart order (for totals).
     * @return string HTML table string.
     */
    public static function build_items_table($transactions, $order)
    {
        $currency = $order->currency;
        $fmt      = fn($n) => esc_html(MeprAppHelper::format_currency($n, true, false, false, $currency));

        // Defense in depth: callers should already use get_all_by_order_id_for_display().
        $transactions = MeprTransaction::exclude_subscription_confirmations($transactions);

        $rows = array_map(function ($txn) use ($fmt, $order) {
            $product = new MeprProduct($txn->product_id);
            $pricing = $txn->cart_line_pricing();

            // Gross line total; a prorated line shows its recorded charge (the order subtotal
            // mirrors charged amounts when proration is involved).
            $qty         = (int) $pricing['qty'];
            $list_unit   = (float) $pricing['unit_price'];
            $is_prorated = !empty($pricing['prorated']);
            $line_total  = $is_prorated
                ? (float) $txn->amount
                : $list_unit * $qty;
            // Price column matches charged unit when prorated (list price remains in byline / snap).
            $unit_price = ($is_prorated && $qty > 0)
                ? round($line_total / $qty, 2)
                : $list_unit;

            return [
                'name'       => esc_html($product->post_title),
                // Prefer byline frozen at complete; old orders fall back to live rebuild.
                'byline'     => esc_html(MeprCartCheckoutService::line_display_byline($txn, $order, $product)),
                'qty'        => $qty,
                'unit_price' => $fmt($unit_price),
                'total'      => $fmt($line_total),
            ];
        }, $transactions);

        if (!empty($order->coupon_code)) {
            // Translators: %s: coupon code.
            $discount_label = sprintf(_x('Discount (%s)', 'email', 'memberpress'), $order->coupon_code);
        } else {
            $discount_label = _x('Discount', 'email', 'memberpress');
        }

        // Per-product tax rows — same shape as thank-you / checkout (title when 2+ taxed lines).
        $tax_txns = array_values(array_filter($transactions, static function ($t) {
            return (float) $t->tax_amount > 0
                || (float) $t->tax_rate > 0
                || (float) $t->tax_reversal_amount > 0;
        }));
        $show_tax_product_title = count($tax_txns) > 1;
        $tax_rows               = [];
        foreach ($tax_txns as $tax_txn) {
            $tax_product = new MeprProduct($tax_txn->product_id);
            if ((float) $tax_txn->tax_reversal_amount > 0 && (float) $tax_txn->tax_amount <= 0) {
                $label = esc_html__('Reverse charge (0% VAT)', 'memberpress');
                if ((float) $tax_txn->tax_rate > 0 && !empty($tax_txn->tax_desc)) {
                    $label .= '<br><small>' . esc_html(
                        MeprUtils::format_tax_percent_for_display($tax_txn->tax_rate) . '% ' . $tax_txn->tax_desc
                    ) . '</small>';
                }
            } else {
                $label = esc_html(
                    MeprUtils::format_tax_percent_for_display($tax_txn->tax_rate) . '% ' . $tax_txn->tax_desc
                );
            }
            if ($show_tax_product_title) {
                $label .= '<br><small>' . esc_html($tax_product->post_title) . '</small>';
            }
            $tax_rows[] = [
                'label'  => $label,
                'amount' => $fmt((float) $tax_txn->tax_amount),
            ];
        }

        $subtotal   = (float) $order->subtotal > 0       ? $fmt($order->subtotal)       : null;
        $discount   = (float) $order->discount_total > 0 ? $fmt($order->discount_total) : null;
        $tax_fallback = (empty($tax_rows) && (float) $order->tax_total > 0) ? $fmt($order->tax_total) : null;
        $shipping   = (float) $order->shipping_total > 0 ? $fmt($order->shipping_total) : null;
        $total      = $fmt($order->total);

        return MeprView::get_string('/emails/partials/cart-receipt-items-table', get_defined_vars());
    }
}
