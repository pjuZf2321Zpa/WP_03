<?php

namespace BitApps\IntegrationsPro\Actions\MailerPress;

use Exception;
use MailerPress\Core\Enums\Tables;
use MailerPress\Core\Kernel;
use MailerPress\Models\Contacts;

class MailerPressProHelper
{
    public static function deleteContact($defaultResponse, $contactData)
    {
        $email = key_exists('email', $contactData) ? sanitize_email($contactData['email']) : null;

        if (\is_null($email)) {
            return [
                'success' => false,
                'message' => __('Email is required', 'bit-integrations')
            ];
        }

        if (
            !class_exists('\MailerPress\Core\Kernel')
            || !class_exists('\MailerPress\Models\Contacts')
            || !class_exists('\MailerPress\Core\Enums\Tables')
        ) {
            return [
                'success' => false,
                'message' => __('MailerPress is not installed or activated', 'bit-integrations')
            ];
        }

        $contact = self::getContactData($email);

        if (!\is_array($contact) || (!key_exists('contact_id', $contact) || !key_exists('id', $contact))) {
            return [
                'success' => false,
                'message' => __('Contact not found', 'bit-integrations')
            ];
        }

        $contactId = $contact['contact_id'] ?? $contact['id'];

        $contactTable = Tables::get(Tables::MAILERPRESS_CONTACT);
        $tagsTable = Tables::get(Tables::CONTACT_TAGS);
        $listsTable = Tables::get(Tables::MAILERPRESS_CONTACT_LIST);

        $params = [
            'contact_id' => $contactId,
        ];

        global $wpdb;
        $wpdb->query('START TRANSACTION');

        try {
            $wpdb->delete($tagsTable, $params);
            $wpdb->delete($listsTable, $params);

            $deleted = $wpdb->delete($contactTable, $params);

            if (!$deleted) {
                throw new Exception(__('Failed to delete contact', 'bit-integrations'));
            }

            $wpdb->query('COMMIT');

            do_action('mailerpress_contact_deleted', $contactId);

            return [
                'success' => true,
                'contact' => $contact,
                'message' => __('Contact deleted successfully', 'bit-integrations')
            ];
        } catch (Exception $e) {
            $wpdb->query('ROLLBACK');

            return [
                'success' => false,
                'message' => $e->getMessage() ?? __('Failed to delete contact', 'bit-integrations')
            ];
        }
    }

    public static function addTagsToContact($defaultResponse, $contactData, $tags)
    {
        $email = key_exists('email', $contactData) ? sanitize_email($contactData['email']) : null;

        if (\is_null($email)) {
            return [
                'success' => false,
                'message' => __('Email is required', 'bit-integrations')
            ];
        }

        if (empty($tags)) {
            return [
                'success' => false,
                'message' => __('At least one tag is required', 'bit-integrations')
            ];
        }

        $contact = self::getContactData($email);

        if (!\is_array($contact) || (!key_exists('contact_id', $contact) || !key_exists('id', $contact))) {
            return [
                'success' => false,
                'message' => __('Contact not found', 'bit-integrations')
            ];
        }

        $contactId = $contact['contact_id'] ?? $contact['id'];

        if (!class_exists('\MailerPress\Core\Enums\Tables')) {
            return [
                'success' => false,
                'message' => __('MailerPress is not installed or activated', 'bit-integrations')
            ];
        }

        global $wpdb;

        $tagsTable = Tables::get(Tables::CONTACT_TAGS);
        $addedTags = [];

        foreach ($tags as $tagId) {
            if ($tagId > 0) {
                $isAdded = $wpdb->replace(
                    $tagsTable,
                    [
                        'contact_id' => $contactId,
                        'tag_id'     => $tagId,
                    ]
                );

                if ($isAdded) {
                    do_action('mailerpress_contact_tag_added', $contactId, $tagId);
                    $addedTags[] = $tagId;
                }
            }
        }

        return [
            'success' => \count($addedTags) > 0 ? true : false,
            'id'      => $contactId,
            'tags'    => $addedTags,
            'message' => \sprintf(__('%d tag(s) added successfully', 'bit-integrations'), \count($addedTags))
        ];
    }

    public static function removeTagsFromContact($defaultResponse, $contactData, $tags)
    {
        $email = key_exists('email', $contactData) ? sanitize_email($contactData['email']) : null;

        if (\is_null($email)) {
            return [
                'success' => false,
                'message' => __('Email is required', 'bit-integrations')
            ];
        }

        if (empty($tags)) {
            return [
                'success' => false,
                'message' => __('At least one tag is required', 'bit-integrations')
            ];
        }

        $contact = self::getContactData($email);

        if (!\is_array($contact) || (!key_exists('contact_id', $contact) || !key_exists('id', $contact))) {
            return [
                'success' => false,
                'message' => __('Contact not found', 'bit-integrations')
            ];
        }

        $contactId = $contact['contact_id'] ?? $contact['id'];

        if (!class_exists('\MailerPress\Core\Enums\Tables')) {
            return [
                'success' => false,
                'message' => __('MailerPress is not installed or activated', 'bit-integrations')
            ];
        }

        $tagsTable = Tables::get(Tables::CONTACT_TAGS);
        $removedTags = [];

        global $wpdb;

        foreach ($tags as $tagId) {
            if ($tagId > 0) {
                $isDeleted = $wpdb->delete(
                    $tagsTable,
                    [
                        'contact_id' => $contactId,
                        'tag_id'     => $tagId,
                    ]
                );

                if ($isDeleted) {
                    do_action('mailerpress_contact_tag_removed', $contactId, $tagId);
                    $removedTags[] = $tagId;
                }
            }
        }

        return [
            'success' => \count($removedTags) > 0 ? true : false,
            'id'      => $contactId,
            'tags'    => $removedTags,
            'message' => \sprintf(__('%d tag(s) removed successfully', 'bit-integrations'), \count($removedTags))
        ];
    }

    public static function addContactToLists($defaultResponse, $contactData, $lists)
    {
        $email = key_exists('email', $contactData) ? sanitize_email($contactData['email']) : null;

        if (\is_null($email)) {
            return [
                'success' => false,
                'message' => __('Email is required', 'bit-integrations')
            ];
        }

        if (empty($lists)) {
            return [
                'success' => false,
                'message' => __('At least one list is required', 'bit-integrations')
            ];
        }

        global $wpdb;

        $contact = self::getContactData($email);

        if (!\is_array($contact) || (!key_exists('contact_id', $contact) || !key_exists('id', $contact))) {
            return [
                'success' => false,
                'message' => __('Contact not found', 'bit-integrations')
            ];
        }

        $contactId = $contact['contact_id'] ?? $contact['id'];

        if (!class_exists('\MailerPress\Core\Enums\Tables')) {
            return [
                'success' => false,
                'message' => __('MailerPress is not installed or activated', 'bit-integrations')
            ];
        }

        $listsTable = Tables::get(Tables::MAILERPRESS_CONTACT_LIST);
        $addedLists = [];

        global $wpdb;
        foreach ($lists as $listId) {
            if ($listId > 0) {
                $isAdded = $wpdb->replace(
                    $listsTable,
                    [
                        'contact_id' => $contactId,
                        'list_id'    => $listId,
                    ]
                );

                if ($isAdded) {
                    do_action('mailerpress_contact_list_added', $contactId, $listId);
                    $addedLists[] = $listId;
                }
            }
        }

        return [
            'success' => \count($addedLists) > 0 ? true : false,
            'id'      => $contactId,
            'lists'   => $addedLists,
            'message' => \sprintf(__('Added to %d list(s) successfully', 'bit-integrations'), \count($addedLists))
        ];
    }

    public static function removeContactFromLists($defaultResponse, $contactData, $lists)
    {
        $email = key_exists('email', $contactData) ? sanitize_email($contactData['email']) : null;

        if (\is_null($email)) {
            return [
                'success' => false,
                'message' => __('Email is required', 'bit-integrations')
            ];
        }

        if (empty($lists)) {
            return [
                'success' => false,
                'message' => __('At least one list is required', 'bit-integrations')
            ];
        }

        $contact = self::getContactData($email);

        if (!\is_array($contact) || (!key_exists('contact_id', $contact) || !key_exists('id', $contact))) {
            return [
                'success' => false,
                'message' => __('Contact not found', 'bit-integrations')
            ];
        }

        $contactId = $contact['contact_id'] ?? $contact['id'];

        if (!class_exists('\MailerPress\Core\Enums\Tables')) {
            return [
                'success' => false,
                'message' => __('MailerPress is not installed or activated', 'bit-integrations')
            ];
        }

        $listsTable = Tables::get(Tables::MAILERPRESS_CONTACT_LIST);
        $removedLists = [];

        global $wpdb;
        foreach ($lists as $listId) {
            if ($listId > 0) {
                $isDeleted = $wpdb->delete(
                    $listsTable,
                    [
                        'contact_id' => $contactId,
                        'list_id'    => $listId,
                    ],
                    ['%d', '%d']
                );

                if ($isDeleted) {
                    do_action('mailerpress_contact_list_removed', $contactId, $listId);
                    $removedLists[] = $listId;
                }
            }
        }

        return [
            'success' => \count($removedLists) > 0 ? true : false,
            'id'      => $contactId,
            'lists'   => $removedLists,
            'message' => \sprintf(__('Removed from %d list(s) successfully', 'bit-integrations'), \count($removedLists))
        ];
    }

    private static function getContactData($email)
    {
        $contactsModel = Kernel::getContainer()->get(Contacts::class);
        $contact = $contactsModel->getContactByEmail($email);

        return $contact ? (array) $contact : null;
    }
}
