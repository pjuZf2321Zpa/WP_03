<?php

namespace MasterStudy\Lms\Pro\AddonsPlus\GoogleMeet\Routing\Swagger;

use MasterStudy\Lms\Routing\Swagger\RequestInterface;
use MasterStudy\Lms\Routing\Swagger\ResponseInterface;
use MasterStudy\Lms\Routing\Swagger\Route;

class GetAdminGoogleMeets extends Route implements RequestInterface, ResponseInterface {
	public function request(): array {
		return array(
			'per_page'   => array(
				'type'        => 'integer',
				'description' => 'Meetings per page. Default is 10.',
			),
			'page'       => array(
				'type'        => 'integer',
				'description' => 'Current page. Default is 1.',
			),
			'search'     => array(
				'type'        => 'string',
				'description' => 'Search meetings by title.',
			),
			'status'     => array(
				'type'        => 'string',
				'description' => 'Filter by meeting status.',
				'enum'        => array( 'any', 'publish', 'pending', 'draft', 'trash', 'private' ),
			),
			'sort'       => array(
				'type'        => 'string',
				'description' => 'Sort field and direction (e.g. title_asc, meeting_date_desc).',
			),
			'date_range' => array(
				'type'        => 'string',
				'description' => 'Meeting start date range filter.',
			),
		);
	}

	public function response(): array {
		return array(
			'google_meets'       => array(
				'type'  => 'array',
				'items' => array(
					'type'       => 'object',
					'properties' => array(
						'id'                   => array(
							'type' => 'integer',
						),
						'title'                => array(
							'type' => 'string',
						),
						'status'               => array(
							'type' => 'string',
							'enum' => array( 'publish', 'pending', 'draft', 'trash', 'private' ),
						),
						'linked_courses_count' => array(
							'type' => 'integer',
						),
						'visibility'           => array(
							'type' => 'string',
						),
						'start_date'           => array(
							'type'     => 'integer',
							'nullable' => true,
						),
						'end_date'             => array(
							'type'     => 'integer',
							'nullable' => true,
						),
						'start_time'           => array(
							'type'     => 'string',
							'nullable' => true,
						),
						'end_time'             => array(
							'type'     => 'string',
							'nullable' => true,
						),
						'timezone'             => array(
							'type'     => 'string',
							'nullable' => true,
						),
						'meeting_date'         => array(
							'type'       => 'object',
							'nullable'   => true,
							'properties' => array(
								'date'     => array(
									'type' => 'string',
								),
								'time'     => array(
									'type' => 'string',
								),
								'timezone' => array(
									'type' => 'string',
								),
							),
						),
						'author'               => array(
							'type'       => 'object',
							'nullable'   => true,
							'properties' => array(
								'id'    => array(
									'type' => 'integer',
								),
								'label' => array(
									'type' => 'string',
								),
							),
						),
					),
				),
			),
			'pages'              => array(
				'type'        => 'integer',
				'description' => 'Total number of pages.',
			),
			'current_page'       => array(
				'type'        => 'integer',
				'description' => 'Current page number.',
			),
			'total_google_meets' => array(
				'type'        => 'integer',
				'description' => 'Total number of meetings.',
			),
		);
	}

	public function get_summary(): string {
		return 'Get Admin Google Meets';
	}

	public function get_description(): string {
		return 'Returns a paginated list of Google Meet meetings for the admin panel.';
	}
}
