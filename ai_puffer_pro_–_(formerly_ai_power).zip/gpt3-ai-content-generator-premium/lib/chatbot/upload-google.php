<?php

namespace WPAICG\Lib\Chat\Frontend\Ajax\Handlers;

use WPAICG\AIPKit_Providers;
use WPAICG\Chat\Core\AIPKit_Chat_File_Upload_Provider_Resolver;
use WPAICG\Chat\Storage\BotStorage;
use WPAICG\Core\Providers\Google\Files\GoogleFilesClient;
use WPAICG\Core\Providers\Google\Files\GoogleFilesContextToken;
use WPAICG\Lib\Chat\Frontend\Ajax\Utils\ChatUploadConfigLoader;
use WPAICG\Lib\Chat\Frontend\Ajax\Utils\ChatUploadLogger;
use WP_Error;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Paid chatbot transport for temporary Gemini Files API documents.
 */
final class ChatFileUploadGoogleHandler
{
    private const PROCESSING_TIMEOUT_SECONDS = 600;

    private ChatUploadLogger $logger;
    private ?BotStorage $bot_storage;
    private GoogleFilesClient $files_client;

    public function __construct(ChatUploadConfigLoader $config_loader, ChatUploadLogger $logger)
    {
        $this->logger = $logger;

        if (!class_exists(BotStorage::class)) {
            $bot_storage_path = WPAICG_PLUGIN_DIR . 'classes/chatbot/bots.php';
            if (file_exists($bot_storage_path)) {
                require_once $bot_storage_path;
            }
        }
        $this->bot_storage = class_exists(BotStorage::class) ? new BotStorage() : null;
        $this->files_client = new GoogleFilesClient();
    }

    /**
     * @return array<string, mixed>|WP_Error
     */
    public function get_provider_api_config()
    {
        if (!class_exists(AIPKit_Providers::class)) {
            return new WP_Error(
                'google_upload_provider_config_missing',
                __('Provider configuration is unavailable for Google uploads.', 'gpt3-ai-content-generator'),
                ['status' => 500]
            );
        }
        $google_data = AIPKit_Providers::get_provider_data('Google');
        if (empty($google_data['api_key'])) {
            return new WP_Error(
                'google_upload_missing_api_key',
                __('Google API Key is not configured.', 'gpt3-ai-content-generator'),
                ['status' => 400]
            );
        }
        return [
            'api_key' => (string) $google_data['api_key'],
            // phpcs:ignore PluginCheck.CodeAnalysis.AIProvider.DirectIntegration -- Provider-specific file transport.
            'base_url' => (string) ($google_data['base_url'] ?? 'https://generativelanguage.googleapis.com'),
            'timeout' => 120,
        ];
    }

    /**
     * @param array<string, mixed> $file_data
     * @param array<string, mixed> $google_config
     * @return array<string, mixed>|WP_Error
     */
    public function process_upload(
        array $file_data,
        ?int $user_id,
        ?string $session_id,
        array $google_config,
        int $bot_id,
        string $conversation_uuid
    ) {
        $settings_check = $this->validate_bot_mode($bot_id);
        if (is_wp_error($settings_check)) {
            return $settings_check;
        }

        $file_path = (string) ($file_data['tmp_name'] ?? '');
        $file_name = sanitize_file_name((string) ($file_data['name'] ?? 'document'));
        $extension = strtolower((string) pathinfo($file_name, PATHINFO_EXTENSION));
        $mime_types = [
            'pdf' => 'application/pdf',
            'txt' => 'text/plain',
        ];
        if (!isset($mime_types[$extension])) {
            return new WP_Error(
                'google_upload_unsupported_document_type',
                __('Google chatbot document input accepts PDF or TXT files.', 'gpt3-ai-content-generator'),
                ['status' => 400]
            );
        }

        $uploaded_file = $this->files_client->upload_path(
            $google_config,
            $file_path,
            $file_name,
            $mime_types[$extension]
        );
        if (is_wp_error($uploaded_file)) {
            return $uploaded_file;
        }
        if (($uploaded_file['state'] ?? '') === 'FAILED') {
            return new WP_Error(
                'google_upload_processing_failed',
                __('Google could not process this document.', 'gpt3-ai-content-generator'),
                ['status' => 422]
            );
        }

        $binding = $this->binding($user_id, $session_id, $bot_id, $conversation_uuid, $file_name);
        $token_result = GoogleFilesContextToken::issue($uploaded_file, $binding);
        if (is_wp_error($token_result)) {
            $this->files_client->delete($google_config, (string) ($uploaded_file['name'] ?? ''));
            return $token_result;
        }

        if (($uploaded_file['state'] ?? '') !== 'ACTIVE') {
            return [
                'status' => 'processing',
                'job_id' => $token_result['token'],
                'retry_after' => 2,
            ];
        }

        return $this->complete_upload($uploaded_file, $token_result, $binding);
    }

    /**
     * @param array<string, mixed> $google_config
     * @param array<string, mixed> $binding
     * @return array<string, mixed>|WP_Error
     */
    public function continue_upload_job(string $job_token, array $google_config, array $binding)
    {
        $settings_check = $this->validate_bot_mode((int) ($binding['bot_id'] ?? 0));
        if (is_wp_error($settings_check)) {
            return $settings_check;
        }
        $verified = GoogleFilesContextToken::verify($job_token, $binding);
        if (is_wp_error($verified)) {
            return $verified;
        }
        if (time() - (int) ($verified['issued_at'] ?? 0) > self::PROCESSING_TIMEOUT_SECONDS) {
            $this->files_client->delete($google_config, (string) $verified['file_name']);
            return new WP_Error(
                'google_upload_processing_timeout',
                __('Google took too long to process this document. Please try the upload again.', 'gpt3-ai-content-generator'),
                ['status' => 504]
            );
        }

        $uploaded_file = $this->files_client->get($google_config, (string) $verified['file_name']);
        if (is_wp_error($uploaded_file)) {
            return $uploaded_file;
        }
        if (($uploaded_file['state'] ?? '') === 'FAILED') {
            $this->files_client->delete($google_config, (string) $verified['file_name']);
            return new WP_Error(
                'google_upload_processing_failed',
                __('Google could not process this document.', 'gpt3-ai-content-generator'),
                ['status' => 422]
            );
        }
        if (($uploaded_file['state'] ?? '') !== 'ACTIVE') {
            return [
                'status' => 'processing',
                'job_id' => $job_token,
                'retry_after' => 2,
            ];
        }

        $binding['original_filename'] = (string) ($verified['original_filename'] ?? 'document');
        $token_result = GoogleFilesContextToken::issue($uploaded_file, $binding);
        if (is_wp_error($token_result)) {
            return $token_result;
        }
        return $this->complete_upload($uploaded_file, $token_result, $binding);
    }

    /**
     * @param array<string, mixed> $google_config
     * @param array<string, mixed> $binding
     * @return array<string, mixed>|WP_Error
     */
    public function delete_file_context(string $context_token, array $google_config, array $binding)
    {
        $verified = GoogleFilesContextToken::verify($context_token, $binding);
        if (is_wp_error($verified)) {
            return $verified;
        }
        $deleted = $this->files_client->delete($google_config, (string) $verified['file_name']);
        if (is_wp_error($deleted)) {
            return $deleted;
        }
        return ['deleted' => true];
    }

    /**
     * @return true|WP_Error
     */
    private function validate_bot_mode(int $bot_id)
    {
        if (!$this->bot_storage) {
            return new WP_Error(
                'google_upload_bot_storage_missing',
                __('Chatbot settings are unavailable for Google upload.', 'gpt3-ai-content-generator'),
                ['status' => 500]
            );
        }
        $bot_settings = $this->bot_storage->get_chatbot_settings($bot_id);
        if (strtolower((string) ($bot_settings['provider'] ?? '')) !== 'google') {
            return new WP_Error(
                'google_upload_provider_mismatch',
                __('Google document upload requires Google as the chatbot AI provider.', 'gpt3-ai-content-generator'),
                ['status' => 400]
            );
        }
        if (
            !class_exists(AIPKit_Chat_File_Upload_Provider_Resolver::class)
            || AIPKit_Chat_File_Upload_Provider_Resolver::resolve($bot_settings) !== 'google'
        ) {
            return new WP_Error(
                'google_upload_mode_not_enabled',
                __('This chatbot is not configured to use Google for temporary document uploads.', 'gpt3-ai-content-generator'),
                ['status' => 400]
            );
        }
        if (($bot_settings['enable_file_upload'] ?? '0') !== '1') {
            return new WP_Error(
                'google_upload_feature_not_enabled',
                __('File upload is not enabled for this chatbot.', 'gpt3-ai-content-generator'),
                ['status' => 403]
            );
        }
        return true;
    }

    /**
     * @param array<string, mixed> $uploaded_file
     * @param array{token:string,expires_at:int} $token_result
     * @param array<string, mixed> $binding
     * @return array<string, mixed>
     */
    private function complete_upload(array $uploaded_file, array $token_result, array $binding): array
    {
        $file_name = sanitize_file_name((string) ($binding['original_filename'] ?? 'document'));
        $this->logger->log_event([
            'user_id' => absint($binding['user_id'] ?? 0),
            'provider' => 'Google',
            'vector_store_id' => (string) $uploaded_file['name'],
            'vector_store_name' => 'Gemini Files API',
            'status' => 'success',
            'message' => sprintf(
                /* translators: %s: UTC expiration date and time. */
                __('Temporary chat document uploaded; expires by %s UTC.', 'gpt3-ai-content-generator'),
                gmdate('Y-m-d H:i:s', $token_result['expires_at'])
            ),
            'indexed_content' => $file_name,
            'file_id' => (string) $uploaded_file['name'],
            'source_type_for_log' => 'chat_file_upload_google',
            'batch_id' => (string) ($binding['conversation_uuid'] ?? ''),
        ]);

        return [
            'status' => 'completed',
            'message' => __('Document ready for Google chat.', 'gpt3-ai-content-generator'),
            'file_context' => [
                'provider' => 'Google',
                'context_token' => $token_result['token'],
                'expires_at' => $token_result['expires_at'],
                'original_filename' => $file_name,
            ],
        ];
    }

    /**
     * @return array<string, mixed>
     */
    private function binding(
        ?int $user_id,
        ?string $session_id,
        int $bot_id,
        string $conversation_uuid,
        string $original_filename
    ): array {
        return [
            'user_id' => $user_id ?: 0,
            'session_id' => $session_id ?: '',
            'bot_id' => $bot_id,
            'conversation_uuid' => sanitize_key($conversation_uuid),
            'original_filename' => $original_filename,
        ];
    }
}
