<?php

class Meow_MWSEO_Core
{
	public $admin = null;
	public $is_rest = false;
	public $site_url = null;
	public $pro = null; // Premium features

	// TODO: Migrate to _mwseo_title
	public $meta_key_seo_title = '_kiss_seo_title';
	// TODO: Migrate to _mwseo_excerpt
	public $meta_key_seo_excerpt = '_kiss_seo_excerpt';
	// TODO: Migrate to _mwseo_ignore
	public $meta_key_skip = '_kiss_seo_ignore';
	public $meta_key_seo_keywords = '_mwseo_keywords';

	private $old_option_name = 'seo_kiss_options';
	private $option_name = 'mwseo_options';

	private $sitemap_module = null;
	private $schema_module = null;
	private $insights_module = null;
	private $analytics_module = null;
	private $googleanalytics_module = null;
	private $plausibleanalytics_module = null;
	private $matomoanalytics_module = null;
	private $parsers = null;
	public $redirects_module = null;
	public $indexnow_module = null;
	public $breadcrumbs_module = null;

	public function __construct() {
		global $mwseo_core;
		$mwseo_core = $this;

		$this->site_url = get_site_url();
		$this->is_rest = MeowKit_MWSEO_Helpers::is_rest();

		add_action( 'plugins_loaded', array( $this, 'init' ) );

		$analyze_on_update = $this->get_option( 'analyze_on_update', 'quick' );
		if ( $analyze_on_update !== 'none' && $analyze_on_update !== false ) {
			add_action( 'save_post', array( $this, 'analyze_on_update' ), 10, 3 );
		}
		// Always registered so events scheduled before a settings change still run.
		add_action( 'mwseo_analyze_post_event', array( $this, 'run_scheduled_analysis' ), 10, 2 );
	}

	function init() {
		global $mwseo;

		$mwseo = new Meow_MWSEO_API( $this );

		// Part of the core, settings and stuff
		$this->admin = new Meow_MWSEO_Admin( $this );

		// Only for REST
		if ( $this->is_rest ) {
			new Meow_MWSEO_Rest( $this, $this->admin );
		}

		// Attachment URL redirection feature
		$redirect_attachments = $this->get_option( 'redirect_attachments', false );
		if ( $redirect_attachments ) {
			add_filter( 'attachment_link', array( $this, 'redirect_attachment_to_parent' ), 10, 2 );
			add_action( 'template_redirect', array( $this, 'handle_attachment_redirect' ) );
		}

		// WordPress serves its own sitemap whether or not the Sitemap module is on, and "hide from
		// search" adds posts to the excluded list, so the exclusions always apply.
		$this->register_sitemap_exclusions();

		// SEO Engine's card on the Meow Apps dashboard (common/).
		add_filter( MWSEO_PREFIX . '_meowapps_status', [ $this, 'get_meowapps_status' ] );

		// Dashboard
		$use_mwseo_sitemap = $this->get_option( 'sitemap', false );
		if ( $use_mwseo_sitemap ) {
			add_filter(
				'init',
				function() {
					$this->sitemap_module = new Meow_MWSEO_Sitemap( $this );
					wp_register_sitemap_provider( MWSEO_DOMAIN, $this->sitemap_module );
				}
			);

		}

		// Website
		//add_filter( 'wp_title', [ $this, 'render_title' ], 10, 2 );
		$use_content_seo = $this->get_option( 'content_seo', false );
		$use_technical_seo = $this->get_option( 'technical_seo', false );
		$use_seo_metadata = $this->get_option( 'use_seo_metadata', true );
		$auto_page_title = $this->get_option( 'auto_page_title', true );
		// When another SEO plugin (Yoast, Rank Math, AIOSEO, SEOPress) is handling the
		// frontend meta tags, SEO Engine steps back so the two don't emit duplicates.
		// It keeps doing everything else (analysis, scoring, AI, MCP) regardless.
		$render_frontend_meta = $this->should_render_frontend_meta();
		if ( ( $use_content_seo || $use_technical_seo ) && $auto_page_title && $render_frontend_meta ) {
			add_filter( 'pre_get_document_title', [ $this, 'render_title' ], 99, 1 );
			// Remove WordPress archive prefixes ("Archives: ", "Category: ", etc.) for cleaner SEO titles
			add_filter( 'get_the_archive_title_prefix', '__return_empty_string' );
		}
		if ( $use_content_seo && $use_seo_metadata && $render_frontend_meta ) {
			add_action( 'wp_head', [ $this, 'render_description' ], 99, 0 );
			add_action( 'wp_head', [ $this, 'render_canonical' ], 99, 0 );
		}

		add_action( 'init', [ $this, 'reject_gptbot_user_agent' ], 99, 0 );

		$this->maybe_schedule_daily_insight();

		// Live content: when enabled, the analyzed content is the actual rendered page
		// (handles all page builders) instead of the raw post_content.
		if ( $this->get_live_content_mode() !== 'disabled' ) {
			add_filter( 'mwseo_post_content', [ $this, 'filter_live_content' ], 10, 3 );
		} else {
			// If not using Live Content, rely on parsers instead
			$this->parsers = new Meow_MWSEO_Helpers_Parsers( $this );
		}

		// Advanced Core
		if ( class_exists( 'MeowPro_MWSEO_Core' ) ) {
			$this->pro = new MeowPro_MWSEO_Core( $this );
		}

		// Insights
		if ( class_exists( 'Meow_MWSEO_Modules_Insights' ) ) {
			$this->insights_module = new Meow_MWSEO_Modules_Insights( $this );
		}

		// Schema
		if ( class_exists( 'Meow_MWSEO_Modules_Schema' ) ) {
			$this->schema_module = new Meow_MWSEO_Modules_Schema( $this );
		}

		// Breadcrumbs (primary category, BreadcrumbList schema, shortcode)
		$this->breadcrumbs_module = new Meow_MWSEO_Modules_Breadcrumbs( $this );

		// SEO panel in the block editor (title, description, index status)
		new Meow_MWSEO_Modules_EditorPanel( $this );

		// Analytics
		if ( class_exists( 'Meow_MWSEO_Modules_Analytics' ) ) {
			$this->analytics_module = new Meow_MWSEO_Modules_Analytics( $this );
			
			// Track visits on frontend
			if ( !is_admin() && !$this->is_rest ) {
				add_action( 'wp', array( $this, 'track_current_visit' ) );
			}
		}

		// Google Analytics
		if ( class_exists( 'Meow_MWSEO_Modules_GoogleAnalytics' ) ) {
			$this->googleanalytics_module = new Meow_MWSEO_Modules_GoogleAnalytics( $this );
		}

		// Plausible Analytics
		if ( class_exists( 'Meow_MWSEO_Modules_PlausibleAnalytics' ) ) {
			$this->plausibleanalytics_module = new Meow_MWSEO_Modules_PlausibleAnalytics( $this );
		}

		// Matomo Analytics
		if ( class_exists( 'Meow_MWSEO_Modules_MatomoAnalytics' ) ) {
			$this->matomoanalytics_module = new Meow_MWSEO_Modules_MatomoAnalytics( $this );
		}

		// Redirects + 404 monitor
		if ( class_exists( 'Meow_MWSEO_Modules_Redirects' ) ) {
			$this->redirects_module = new Meow_MWSEO_Modules_Redirects( $this );
		}

		// IndexNow (instant indexing pings on publish/update)
		if ( class_exists( 'Meow_MWSEO_Modules_IndexNow' ) ) {
			$this->indexnow_module = new Meow_MWSEO_Modules_IndexNow( $this );
		}

		// MCP integration - check both class and global variable
		if ( class_exists( 'Meow_MWAI_Core' ) || isset( $GLOBALS['mwai'] ) ) {
			new Meow_MWSEO_MCP( $this );
		}

		// AI Engine integration: fills the SEO block in AI Engine's Modules tab.
		// The filter is harmless when AI Engine is absent, so no gating needed.
		new Meow_MWSEO_Modules_AIEngine( $this );

		
	}

	function get_logs() {
		$log_file_path = $this->get_logs_path();

		if ( !file_exists( $log_file_path ) ) {
			return "Empty log file.";
		}

		$content = file_get_contents( $log_file_path );
		// $lines = explode( "\n", $content );
		// $lines = array_filter( $lines );
		// $lines = array_reverse( $lines );
		// $content = implode( "\n", $lines );
		return $content;
	}

	function clear_logs() {
		$logPath = $this->get_logs_path();
		if ( file_exists( $logPath ) ) {
			unlink( $logPath );
		}

		$options = $this->get_all_options();
		$options['logs_path'] = null;
		$this->update_options( $options );
	}

	function get_logs_path() {
		$uploads_dir = wp_upload_dir();
		$uploads_dir_path = trailingslashit( $uploads_dir['basedir'] );

		$path = $this->get_option( 'logs_path' );

		if ( $path && file_exists( $path ) ) {
			// make sure the path is legal (within the uploads directory with the MWSEO_PREFIX and log extension)
			if ( strpos( $path, $uploads_dir_path ) !== 0 || strpos( $path, MWSEO_PREFIX ) === false || substr( $path, -4 ) !== '.log' ) {
				$path = null;
			} else {
				return $path;
			}
		}

		if ( !$path ) {
			$path = $uploads_dir_path . MWSEO_PREFIX . "_" . $this->random_ascii_chars() . ".log";
			if ( !file_exists( $path ) ) {
				touch( $path );
			}
			$options = $this->get_all_options();
			$options['logs_path'] = $path;
			$this->update_options( $options );
		}

		return $path;
	}

	private function random_ascii_chars( $length = 10 ) {
		$chars = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
		$chars_length = strlen( $chars );
		$random_string = '';
		for ( $i = 0; $i < $length; $i++ ) {
			$random_string .= $chars[ rand( 0, $chars_length - 1 ) ];
		}
		return $random_string;
	}

	function log( $data = null ) {
		$enabled = $this->get_option( 'logs', false );
		if ( !$enabled ) { return; }

		$log_file_path = $this->get_logs_path();

		// Check log file size and rotate if too large (1MB limit)
		if ( file_exists( $log_file_path ) ) {
			$file_size = filesize( $log_file_path );
			$max_size = apply_filters( 'mwseo_max_log_size', 1 * 1024 * 1024 ); // 1MB default

			if ( $file_size > $max_size ) {
				@unlink( $log_file_path );
				// Log the rotation event
				$fh = @fopen( $log_file_path, 'w' );
				if ( $fh ) {
					$date = date( "Y-m-d H:i:s" );
					fwrite( $fh, "$date: 🔄 Log file rotated (exceeded " . size_format( $max_size ) . ")\n\n" );
					fclose( $fh );
				}
			}
		}

		// Make sure the log file exists before opening it to avoid warnings
		if ( !file_exists( $log_file_path ) ) {
			@touch( $log_file_path );
		}

		$fh = @fopen( $log_file_path, 'a' );
		if ( !$fh ) { return false; }
		$date = date( "Y-m-d H:i:s" );
		if ( is_null( $data ) ) {
			fwrite( $fh, "\n" );
		}
		else {
			fwrite( $fh, "$date: {$data}\n" );
			//error_log( "[SEO ENGINE] $data" );
		}
		fclose( $fh );
		return true;
	}

	function get_funny_rejection_message() {
    $messages = [
			"🤖 Human detected! Pretending to be GPTBot? That’s a fun role-reversal!",
			"😂 Nice try, human! Even robots like GPTBot get a day off, courtesy of <a href='https://wordpress.org/plugins/seo-engine/'>SEO Engine</a>.",
			"🎭 Humans playing robots? What a twist! GPTBot access: Denied by <a href='https://wordpress.org/plugins/seo-engine/'>SEO Engine</a>!",
			"👀 Spotted! A human camouflaging as GPTBot. <a href='https://wordpress.org/plugins/seo-engine/'>SEO Engine</a> sees you!",
			"😜 A human mimicking GPTBot? That's some advanced <a href='https://wordpress.org/plugins/seo-engine/'>SEO Engine</a> wizardry!",
			"🤣 Oh, human, GPTBot impressions? You’re fun, but <a href='https://wordpress.org/plugins/seo-engine/'>SEO Engine</a> says no entry!",
			"🤠 Yeehaw! A wild human pretending to be GPTBot? Not on <a href='https://wordpress.org/plugins/seo-engine/'>SEO Engine</a>'s watch!",
			"🕵️‍♂️ Detective human, trying to sneak in as GPTBot? <a href='https://wordpress.org/plugins/seo-engine/'>SEO Engine</a> caught ya!",
			"🤪 Human, are you trying to robot? Denied access by the watchful <a href='https://wordpress.org/plugins/seo-engine/'>SEO Engine</a>!",
			"🚫 You must be a fun human to mimic GPTBot! But, <a href='https://wordpress.org/plugins/seo-engine/'>SEO Engine</a> keeps the door locked.",
			"😅 Humans doing robot things? Not under <a href='https://wordpress.org/plugins/seo-engine/'>SEO Engine</a>’s cyber-watch!",
			"🤨 A human in robot’s clothing! Nice try, but <a href='https://wordpress.org/plugins/seo-engine/'>SEO Engine</a> is not fooled.",
			"🤔 Hmm, human, your GPTBot disguise needs work. Spotted by <a href='https://wordpress.org/plugins/seo-engine/'>SEO Engine</a>!",
			"😆 The human is a robot? This plot twist brought to you by <a href='https://wordpress.org/plugins/seo-engine/'>SEO Engine</a>!",
			"🧐 An insightful human trying to GPTBot around! But, <a href='https://wordpress.org/plugins/seo-engine/'>SEO Engine</a> is on guard.",
			"🎉 Surprise! Human, you can’t sneak past <a href='https://wordpress.org/plugins/seo-engine/'>SEO Engine</a>, even dressed as GPTBot!",
			"🎲 Rolled the dice, human? GPTBot disguise didn’t work on <a href='https://wordpress.org/plugins/seo-engine/'>SEO Engine</a>.",
			"🤥 Human, pretending to be GPTBot? <a href='https://wordpress.org/plugins/seo-engine/'>SEO Engine</a> knows your secret!",
			"🧛‍♂️ Ah ah ah, human! Even as GPTBot, you can’t bypass the <a href='https://wordpress.org/plugins/seo-engine/'>SEO Engine</a> barrier!",
			"🤓 Nerdy human alert! GPTBot cosplay isn’t fooling <a href='https://wordpress.org/plugins/seo-engine/'>SEO Engine</a>!"
    ];
    return $messages[ array_rand( $messages ) ];
	}


	function reject_gptbot_user_agent()
	{
		$disallow_gpt_bot = $this->get_option( 'disallow_gpt_bot', false );

		if ( $disallow_gpt_bot && isset($_SERVER[ 'HTTP_USER_AGENT' ]) && strpos( $_SERVER[ 'HTTP_USER_AGENT' ], 'GPTBot' ) !== false ) {
			$this->log( '🤖 GPTBot has been detected and blocked.');
			header( 'HTTP/1.1 403 Forbidden' );
			exit( $this->get_funny_rejection_message() );
		}
	}

	function get_post_types() {
		// global $wpdb;
		// $post_types = $wpdb->get_col( "SELECT DISTINCT post_type FROM $wpdb->posts" );
		$post_types = get_post_types( array( 'public' => true ), 'names', 'and' );
		
		// Exclude post types that don't need SEO
		$excluded_types = array( 'revision', 'wp_global_styles', 'wp_navigation' );
		$post_types = array_diff( $post_types, $excluded_types );
		
		return array_values( $post_types );
	}

	function get_categories() {
		
		// Every public taxonomy (categories, tags, product categories, custom ones) can have its own SEO title and description.
		$taxonomy = apply_filters( 'mwseo_category_taxonomies', array_keys( $this->get_taxonomies() ) );

		$categories = get_categories( array(
			'taxonomy' => $taxonomy,
			'hide_empty' => false,
		) );

		return $categories;
	}

	// Make post type list as [ 'post_type_value' => 'post_type_label' ]
	function make_post_type_list( $post_types ) {
		$list = [];
		foreach ( $post_types as $post_type ) {
			$posttype_obj = get_post_type_object( $post_type );
			if ( empty( $posttype_obj ) ) {continue;}
			$label = get_post_type_object( $post_type )->label;
			if ( !$label ) {continue;}

			$list[$post_type] = $label;
		}
		return $list;
	}

	function make_category_list( $categories ) {
		$list = [];
		foreach ( $categories as $category ) {
			$taxonomy = get_taxonomy( $category->taxonomy );
			$list[$category->term_id] = (array) $category + [ 'taxonomy_label' => $taxonomy ? $taxonomy->labels->singular_name : $category->taxonomy ];
		}
		return array_values( $list );
	}

	function get_taxonomies() {
		$taxonomies = get_taxonomies( array( 'public' => true ), 'objects' );
		$taxonomies = array_filter( $taxonomies, function( $taxonomy ) {
			return !in_array( $taxonomy->name, [ 'nav_menu', 'link_category', 'post_format' ] );
		} );
		return $taxonomies;
	}

	function make_taxonomy_list( $taxonomies ) {
		$list = [];
		foreach ( $taxonomies as $taxonomy ) {
			$list[$taxonomy->name] = $taxonomy->label;
		}
		return $list;
	}	

	function check_title_duplicates($title, $id) {
		$duplicate_hashes = get_option( 'mwseo_title_hashes' );
		if ( empty( $duplicate_hashes ) ) {
			$duplicate_hashes = array();
		}
	
		$title_hash = md5( $title );
	
		if ( array_key_exists( $title_hash, $duplicate_hashes ) ) {
			if( $duplicate_hashes[ $title_hash ] == $id ) {
				return false;
			}
			else {
				//verify that the post still exists
				$post = get_post( $duplicate_hashes[ $title_hash ] );
				if( empty( $post ) || $post->post_status == 'trash') {
					unset( $duplicate_hashes[ $title_hash ] );
					update_option( 'mwseo_title_hashes', $duplicate_hashes );
					return false;
				}
				
				return true;
			}
		}
		else {
			$duplicate_hashes[ $title_hash ] = $id;
			update_option( 'mwseo_title_hashes', $duplicate_hashes );
			return false;
		}
	}

	// Keeps scores and issue counts fresh after edits: instead of analyzing inline (which
	// would slow every save, badly so in full mode with AI checks), schedule a one-off cron
	// event a few seconds later. Only re-analyzes posts that already have an analysis, so a
	// brand new draft is never surprise-scanned.
	function analyze_on_update( $post_id, $post, $update ) {
		if ( wp_is_post_revision( $post_id ) || wp_is_post_autosave( $post_id ) ) return;
		if ( !$post || $post->post_status !== 'publish' ) return;
		$public_types = get_post_types( array( 'public' => true ) );
		if ( !in_array( $post->post_type, $public_types, true ) ) return;
		if ( empty( get_post_meta( $post_id, '_mwseo_analysis', true ) ) ) return;

		$analyze_on_update = $this->get_option( 'analyze_on_update', 'quick' );
		$analysis_type = ( $analyze_on_update === 'full' ) ? 'full' : 'quick';
		if ( !wp_next_scheduled( 'mwseo_analyze_post_event', array( $post_id, $analysis_type ) ) ) {
			wp_schedule_single_event( time() + 10, 'mwseo_analyze_post_event', array( $post_id, $analysis_type ) );
		}
	}

	function run_scheduled_analysis( $post_id, $analysis_type = 'quick' ) {
		$post = get_post( $post_id );
		if ( !$post || $post->post_status !== 'publish' ) return;
		$this->calculate_seo_score( $post, $analysis_type === 'full' ? 'full' : 'quick' );
	}


	// Decides whether or not the post is SEO-friendly or not.
	function calculate_seo_score( $post, $analysis_type = 'full' ) {
		global $mwseo_score;
		if ( !$mwseo_score ) {
			return [ 'status' => 'error', 'message' => 'Score module not initialized.' ];
		}

		if ( get_post_meta( $post->ID, '_mwseo_status', true ) === 'skip' ) {
			$this->log( "🚫 Post (#{$post->ID}) was skipped." );
			return [ 'status' => 'skip', 'message' => 'Skipped.' ];
		}

		// Clear magic fix markers before re-analysis
		$this->clear_magic_fix_markers( $post->ID );

		// Calculate SEO score with analysis type ('quick' or 'full')
		$result = $mwseo_score->calculate( $post, $analysis_type );

		// Save results
		update_post_meta( $post->ID, '_mwseo_analysis', $result );

		// Also save denormalized meta for sorting/filtering
		update_post_meta( $post->ID, '_mwseo_overall', $result['overall'] );
		// Note: cq and tech are legacy pillar scores, removed in v3
		update_post_meta( $post->ID, '_mwseo_updated', time() );

		// Maintain backward compatibility with old meta keys
		$status = $this->get_status_from_score( $result );
		$message = $this->get_message_from_score( $result );
		$codes = $this->get_codes_from_score( $result );

		update_post_meta( $post->ID, '_mwseo_score', $result['overall'] );
		update_post_meta( $post->ID, '_mwseo_status', $status );
		update_post_meta( $post->ID, '_mwseo_message', $message );
		update_post_meta( $post->ID, '_mwseo_codes', $codes );

		return [
			'score' => $result['overall'],
			'status' => $status,
			'message' => $message,
			'errors' => [ 'codes' => $codes ],
			'data' => $result
		];
	}

	// Convert score results to legacy status
	private function get_status_from_score( $result ) {
		$overall = $result['overall'];

		if ( $overall >= 70 ) return 'ok';
		if ( $overall >= 40 ) return 'error'; // Could improve
		return 'error'; // Needs attention
	}

	// Convert score results to legacy message
	private function get_message_from_score( $result ) {
		$overall = $result['overall'];

		if ( $overall >= 70 ) {
			$emoji = '🟢';
			$label = __( 'Great', 'seo-engine' );
		} elseif ( $overall >= 40 ) {
			$emoji = '🟠';
			$label = __( 'Could improve', 'seo-engine' );
		} else {
			$emoji = '🔴';
			$label = __( 'Needs attention', 'seo-engine' );
		}

		$message = sprintf( '%s %s (%d%%)', $emoji, $label, $overall );

		if ( !empty( $result['ai']['summary'] ) ) {
			$message .= "\n" . sprintf( __( 'How AI reads this: "%s"', 'seo-engine' ), $result['ai']['summary'] );
		}

		return $message;
	}

	// Extract error codes from score tests
	private function get_codes_from_score( $result ) {
		$codes = [];

		foreach ( $result['tests'] as $test_name => $score ) {
			if ( $score === 'NA' ) continue;
			if ( $score < 70 ) {
				$codes[] = $test_name;
			}
		}

		return $codes;
	}

	function get_all_posts_with_seo_score() {

		// $show_unscored_posts = $this->get_option( 'show_unscored_chart', false );
		// $show_any_post_type  = $this->get_option( 'show_any_post_type',  false );

		$show_any_post_type  = false;
		$show_unscored_posts = true;

		$meta_query = $show_unscored_posts ? [] : [ 'key' => '_mwseo_score', 'compare' => 'EXISTS' ];
		$default_post_type = $this->get_option( 'default_post_type', 'post' );
		$post_type = $show_any_post_type ? 'any' : $default_post_type;

		// When 'any' is selected, use only the enabled post types from settings
		if ( $post_type === 'any' ) {
			$post_type = $this->get_option( 'select_post_types', ['post', 'page'] );
		}

		// PERFORMANCE FIX: Allow limiting posts for very large sites
		// Default to 10000 max to prevent memory issues
		$max_posts = apply_filters( 'seo_engine_max_chart_posts', 10000 );

		$args = array(
			'post_type' => $post_type,
			'posts_per_page' => $max_posts,
			'meta_query' => array(
				$meta_query,
			),
		);

		$posts = get_posts( $args );

		// PERFORMANCE FIX: Prime meta cache to avoid N+1 queries
		if (!empty($posts)) {
			$post_ids = wp_list_pluck($posts, 'ID');
			update_meta_cache('post', $post_ids);
		}

		$posts_with_seo_score = array();

		foreach ( $posts as $post ) {
			$seo_score = get_post_meta( $post->ID, '_mwseo_score', true );
			$seo_status = get_post_meta( $post->ID, '_mwseo_status', true );


			$posts_with_seo_score[] = array(
				'id' => $post->ID,
				'title' => $post->post_title,
				'score' => $seo_score,
				'status' => $seo_status,
				'category' => $this->get_seo_category( $seo_score ),
			);
		}

		return $posts_with_seo_score;
	}

	private function get_seo_category ( $score ) {

		if ( $score >= 0 && $score < 25 ) {
			return 'Terrible';
		}
		else if ( $score >= 25 && $score < 50 ) {
			return 'Poor';
		}
		else if ( $score >= 50 && $score < 75 ) {
			return 'Acceptable';
		}
		else if ( $score >= 75 && $score < 90 ) {
			return 'Great';
		}
		else if ( $score >= 90 && $score <= 100 ) {
			return 'Excellent';
		}
		else {
			return 'Unknown';
		}
	}

	function get_seo_engine_post_meta( $post ) {

		$post_id = $post->ID;

		$score = get_post_meta( $post_id, '_mwseo_score', true );
		$status = get_post_meta( $post_id, '_mwseo_status', true );
		$message = get_post_meta( $post_id, '_mwseo_message', true );
		$codes = get_post_meta( $post_id, '_mwseo_codes', true );

		if( !$status ) { $status = 'pending'; }
		if( !$message ) { $message = 'Start an analysis to get a score.'; }

		return [
			'score' => $score,
			'status' => $status,
			'message' => $message,
			'codes' => $codes,
		];
	}

	

	// Decode first, then strip: stripping first let an entity-encoded tag (&lt;script&gt;) through
	// and the decode turned it into a real one (stored XSS reported by Wordfence, Oct 2026).
	// The result is plain text: every output must still escape it for its context.
	function to_plain_text( $text ) {
		return trim( wp_strip_all_tags( html_entity_decode( (string) $text, ENT_QUOTES | ENT_HTML5, 'UTF-8' ) ) );
	}

	function build_excerpt( $post, $excerpt = "", $ignore_custom = false ) {
		if ( is_category() || is_tag() || is_tax() ) {
			$term = get_queried_object();
			$seo_description = $term instanceof WP_Term ? get_term_meta( $term->term_id, '_mwseo_description', true ) : '';
			$excerpt = !empty( $seo_description ) ? $seo_description : term_description();
		}
		else if ( is_author() ) {
			$excerpt = get_the_author_meta( 'description' );
		}
		else if ( is_search() ) {
			$excerpt = get_search_query();
		}
		else if ( is_404() ) {
			$excerpt = '404';
		}
		else if ( is_home() ) {
			$page_for_posts = (int) get_option( 'page_for_posts' );
			// Latest posts on the front page have no page of their own: get_the_excerpt( 0 ) returned the newest post's.
			if ( $page_for_posts ) {
				$seo_excerpt = $ignore_custom ? '' : get_post_meta( $page_for_posts, $this->meta_key_seo_excerpt, true );
				$excerpt = !empty( $seo_excerpt ) ? $seo_excerpt : get_the_excerpt( $page_for_posts );
			}
			else {
				$excerpt = get_bloginfo( 'description' );
			}
		}
		else if ( is_post_type_archive() ) {
			$seo_description = $this->get_archive_seo( 'description' );
			$excerpt = $seo_description !== '' ? $seo_description : get_the_archive_description();
		}
		else if ( is_archive() ) {
			$excerpt = get_the_archive_description();
		}
		else if ( !empty( $post ) ) {
			$seo_excerpt = $ignore_custom ? '' : get_post_meta( $post->ID, $this->meta_key_seo_excerpt, true );
			$excerpt = !empty( $seo_excerpt ) ? $seo_excerpt : get_the_excerpt( $post->ID );
		}
		return $this->to_plain_text( $excerpt );
	}

	// SEO title or description set for the current post type archive (like /projects/), in the archive_seo option.
	function get_archive_seo( $field ) {
		$post_type = get_query_var( 'post_type' );
		$post_type = is_array( $post_type ) ? reset( $post_type ) : $post_type;
		$archive_seo = (array) $this->get_option( 'archive_seo', [] );
		return trim( (string) ( $archive_seo[$post_type][$field] ?? '' ) );
	}

	function build_title( $post, $title = "", $ignore_custom = false ) {
		$override = false;
		if ( is_category() || is_tag() || is_tax() ) {
			$term = get_queried_object();
			$seo_title = $term instanceof WP_Term ? get_term_meta( $term->term_id, '_mwseo_title', true ) : '';
			if ( !empty( $seo_title ) ) {
				$override = true;
				$title = $seo_title;
			} else {
				$title = single_term_title( '', false );
			}
		}
		else if ( is_author() ) {
			$title = get_the_author();
		}
		else if ( is_search() ) {
			$title = get_search_query();
		}
		else if ( is_404() ) {
			$title = '404';
		}
		else if ( is_home() ) {
			$page_for_posts = (int) get_option( 'page_for_posts' );
			$seo_title = $page_for_posts && !$ignore_custom ? get_post_meta( $page_for_posts, $this->meta_key_seo_title, true ) : '';
			if ( !empty( $seo_title ) ) {
				$override = true;
				$title = $seo_title;
			}
			else if ( $page_for_posts ) {
				$title = get_the_title( $page_for_posts );
			}
			else {
				// Latest posts on the front page have no page of their own: get_the_title( 0 ) returned
				// the newest post's title. Site name and tagline instead, skipping whichever is empty.
				$override = true;
				$parts = array_filter( array( trim( get_bloginfo( 'name' ) ), trim( get_bloginfo( 'description' ) ) ), 'strlen' );
				$title = implode( ' ' . $this->get_title_separator() . ' ', $parts );
			}
		}
		else if ( is_post_type_archive() ) {
			$seo_title = $this->get_archive_seo( 'title' );
			if ( $seo_title !== '' ) {
				$override = true;
				$title = $seo_title;
			} else {
				$title = post_type_archive_title( '', false );
			}
		}
		else if ( is_archive() ) {
			$title = get_the_archive_title();
		}
		else if ( !empty( $post ) ) {
			$seo_title = $ignore_custom ? '' : get_post_meta( $post->ID, $this->meta_key_seo_title, true );
			if ( !empty( $seo_title ) ) {
				$override = true;
				$title = $seo_title;
			}
			else {
				$title = get_the_title( $post->ID );
			}
		}
		$title = trim( $title );
		$site = trim( get_bloginfo( 'name' ) );
		if ( !$override && $site !== '' ) {
			$title = $title . ' ' . $this->get_title_separator() . ' ' . $site;
		}
		return $this->to_plain_text( $title );
	}

	// Kept in sync with the detection surfaced to the admin UI in admin.php.
	function is_other_seo_plugin_active() {
		return class_exists( 'WPSEO_Frontend' )       // Yoast SEO
			|| class_exists( 'All_in_One_SEO_Pack' )  // All in One SEO
			|| class_exists( 'RankMath' )             // Rank Math
			|| defined( 'SEOPRESS_VERSION' );         // SEOPress
	}

	// Whether SEO Engine should output its own frontend meta tags (title, description,
	// canonical, Open Graph). In 'auto' it steps back when another SEO plugin is active
	// so the two don't emit duplicate tags; 'always' and 'never' force the behavior.
	// The analysis, scoring, AI and MCP features run regardless of this setting.
	/**
	 * Average SEO score and what needs doing, for the Meow Apps dashboard. Reads the scores
	 * stored at each analysis: the dashboard must open instantly, so never analyze from here.
	 */
	function get_meowapps_status() {
		global $wpdb;
		if ( !$this->get_option( 'content_seo', false ) ) {
			return null;
		}
		$post_types = array_values( array_filter( (array) $this->get_option( 'select_post_types', [ 'post', 'page' ] ), 'is_string' ) );
		if ( empty( $post_types ) ) {
			return null;
		}
		$in = implode( ',', array_fill( 0, count( $post_types ), '%s' ) );
		$scores = $wpdb->get_row( $wpdb->prepare(
			"SELECT COUNT(*) AS analyzed, AVG( CAST( pm.meta_value AS DECIMAL(5,2) ) ) AS average,
				SUM( CAST( pm.meta_value AS DECIMAL(5,2) ) < 50 ) AS poor
			FROM {$wpdb->posts} p
			JOIN {$wpdb->postmeta} pm ON pm.post_id = p.ID AND pm.meta_key = '_mwseo_score'
			WHERE p.post_status = 'publish' AND p.post_type IN ($in)",
			$post_types
		) );
		$not_analyzed = (int) $wpdb->get_var( $wpdb->prepare(
			"SELECT COUNT(*) FROM {$wpdb->posts} p
			LEFT JOIN {$wpdb->postmeta} pm ON pm.post_id = p.ID AND pm.meta_key = '_mwseo_score'
			LEFT JOIN {$wpdb->postmeta} skip ON skip.post_id = p.ID AND skip.meta_key = %s
			WHERE p.post_status = 'publish' AND p.post_type IN ($in) AND pm.post_id IS NULL AND skip.post_id IS NULL",
			array_merge( [ $this->meta_key_skip ], $post_types )
		) );
		$analyzed = $scores ? (int) $scores->analyzed : 0;
		if ( !$analyzed && !$not_analyzed ) {
			return null;
		}

		$url = admin_url( 'admin.php?page=mwseo_settings&nekoTab=' );
		$todos = [];
		$poor = $scores ? (int) $scores->poor : 0;
		if ( $poor ) {
			$todos[] = [
				'text' => sprintf( _n( '%s post with a poor SEO score', '%s posts with a poor SEO score', $poor, 'seo-engine' ), number_format_i18n( $poor ) ),
				'severity' => 'info',
				'action' => [ 'label' => __( 'Fix', 'seo-engine' ), 'url' => $url . 'bulk-seo' ],
			];
		}
		if ( $not_analyzed ) {
			$todos[] = [
				'text' => sprintf( _n( '%s post not analyzed yet', '%s posts not analyzed yet', $not_analyzed, 'seo-engine' ), number_format_i18n( $not_analyzed ) ),
				'severity' => 'info',
				'action' => [ 'label' => __( 'Analyze', 'seo-engine' ), 'url' => $url . 'content' ],
			];
		}
		return [
			'metric' => $analyzed ? [ 'value' => (string) round( (float) $scores->average ), 'label' => __( 'avg SEO score', 'seo-engine' ) ] : null,
			'todos' => $todos,
			'note' => sprintf( _n( '%s post analyzed', '%s posts analyzed', $analyzed, 'seo-engine' ), number_format_i18n( $analyzed ) ),
		];
	}

	function register_sitemap_exclusions() {
		$excluded_providers = array_filter( [
			$this->get_option( 'sitemap_exclude_users_provider', false ) ? 'users' : null,
			$this->get_option( 'sitemap_exclude_posts_provider', false ) ? 'posts' : null,
			$this->get_option( 'sitemap_exclude_taxonomies_provider', false ) ? 'taxonomies' : null,
		] );
		$excluded_post_types = (array) $this->get_option( 'sitemap_excluded_post_types', [] );
		$excluded_taxonomies = (array) $this->get_option( 'sitemap_excluded_taxonomies', [] );
		$excluded_posts = array_filter( array_map( 'intval', (array) $this->get_option( 'sitemap_excluded_post_ids', [] ) ) );

		if ( !empty( $excluded_providers ) ) {
			add_filter( 'wp_sitemaps_add_provider', function( $provider, $name ) use ( $excluded_providers ) {
				return in_array( $name, $excluded_providers, true ) ? false : $provider;
			}, 10, 2 );
		}
		if ( !empty( $excluded_post_types ) ) {
			add_filter( 'wp_sitemaps_post_types', function( $post_types ) use ( $excluded_post_types ) {
				return array_diff_key( $post_types, array_flip( $excluded_post_types ) );
			} );
		}
		if ( !empty( $excluded_taxonomies ) ) {
			add_filter( 'wp_sitemaps_taxonomies', function( $taxonomies ) use ( $excluded_taxonomies ) {
				return array_diff_key( $taxonomies, array_flip( $excluded_taxonomies ) );
			} );
		}
		if ( !empty( $excluded_posts ) ) {
			add_filter( 'wp_sitemaps_posts_query_args', function( $args ) use ( $excluded_posts ) {
				$args['post__not_in'] = array_merge( isset( $args['post__not_in'] ) ? (array) $args['post__not_in'] : [], $excluded_posts );
				return $args;
			} );
		}
	}

	function should_render_frontend_meta() {
		$mode = $this->get_option( 'frontend_meta_mode', 'auto' );
		if ( $mode === 'always' ) {
			return true;
		}
		if ( $mode === 'never' ) {
			return false;
		}
		return !$this->is_other_seo_plugin_active();
	}

	function render_title( $title ) {
		global $post;
		$title = $this->build_title( $post, $title );
		return esc_html( $title );
	}

	function render_description() {
		global $post;
		$excerpt = $this->build_excerpt( $post );
		$excerpt = trim( strip_tags( $excerpt ) );
		echo '<meta class="mwseo-meta" name="description" content="' . esc_html( $excerpt ) . '" />';
	}

	function render_canonical() {
		global $post;
		if ( ! $post instanceof WP_Post ) {
			return;
		}
		$canonical = get_post_meta( $post->ID, '_mwseo_canonical', true );
		if ( !empty( $canonical ) ) {
			echo '<link class="mwseo-canonical" rel="canonical" href="' . esc_url( $canonical ) . '" />';
		}
	}

	function get_images_from_content( $content ) {
		if (empty($content)) {
			return array();
		}

		$dom = new DOMDocument;
		$loadHTML = @$dom->loadHTML($content);

		if (!$loadHTML) {
			throw new Exception('Failed to load HTML content');
		}

		$images = array();

		$images_html = array();
		foreach ( $dom->getElementsByTagName( 'img' ) as $img ) {
			$src = $img->getAttribute( 'src' );
			$alt = $img->getAttribute( 'alt' );

			if ( $src && filter_var( $src, FILTER_VALIDATE_URL ) ) {
				$images_html[] = array(
					'src' => preg_replace( '~-[0-9]+x[0-9]+.~', '.', $src ),
					'alt' => $alt ? $alt : '',
				);
			}
		}

		$images_shortcode = array();
		$pattern = get_shortcode_regex();
		preg_match_all( '/'. $pattern .'/s', $content, $matches );
		if ( !empty( $matches[2] ) ) {
			foreach ( $matches[2] as $key => $shortcode ) {
				if ( $shortcode == 'gallery' || $shortcode == 'meow-gallery' ) {
					$atts = shortcode_parse_atts( $matches[3][$key] );
					if (isset($atts['ids'])) {
						$ids = explode( ',', $atts['ids'] );
						foreach ( $ids as $id ) {
							if (is_numeric($id)) {
								$src = wp_get_attachment_url( $id );
								$alt = get_post_meta( $id, '_wp_attachment_image_alt', true );
								if ($src && filter_var($src, FILTER_VALIDATE_URL)) {

									if( in_array( $src, array_column( $images_shortcode, 'src' ) ) ) {
										continue;
									}

									$images_shortcode[] = array(
										'src' => $src,
										'alt' => $alt ? $alt : '',
									);
								}
							}
						}
					}
				}
			}
		}

		$images = array_merge( $images_html, $images_shortcode );

		return $images;
	}

	function get_images_from_content_with_above_paragraph( $img_src_array, $content ) {
		$images = [];

		//Get all the text before the img src
		foreach ( $img_src_array as $img_src ) {

			$before_img = substr( $content, 0, strpos( $content, $img_src ) );
			$before_img = substr( $before_img, strrpos( $before_img, '<p>' ) + 3 );
			$before_img = strip_tags( $before_img );
			$before_img = preg_replace( '/\s+/', ' ', $before_img );
			$before_img = trim( $before_img );
			
			$images[] = array(
				'src' => $img_src,
				'alt' => $before_img,
				'text' => $before_img,
			);
		}
		

		return $images;
	}

	// Normalizes the live content mode option, accounting for legacy boolean values
	// ('disabled' = off, 'main' = extract main content, 'whole' = use the whole page).
	function get_live_content_mode() {
		$mode = $this->get_option( 'check_live_content', 'disabled' );
		if ( $mode === true || $mode === 1 || $mode === '1' ) {
			return 'main';
		}
		if ( in_array( $mode, [ 'main', 'whole' ], true ) ) {
			return $mode;
		}
		return 'disabled';
	}

	function filter_live_content( $content, $post, $strip_html = true ) {
		return $this->get_live_content( $post, $strip_html );
	}

	function get_live_content( $post, $strip_html = true ) {
		// Fetch the actual rendered page (handles all page builders)
		$post_url = get_permalink( $post->ID );
		if ( !$post_url ) {
			$this->log( "⚠️ Live Content: Could not find an URL to load for post {$post->ID}" );
			return $strip_html ? wp_strip_all_tags( $post->post_content ) : $post->post_content;
		}

		$response = wp_remote_get( $post_url, [
			'timeout' => 15,
			'user-agent' => 'Mozilla/5.0 (compatible; SEO Engine Content Analyzer; +' . home_url() . ')',
			'sslverify' => false, // Allow self-signed certs on local/staging
		] );

		if ( is_wp_error( $response ) ) {
			$this->log( "⚠️ Live Content: HTTP request failed for {$post_url}. Error: " . $response->get_error_message() );
			return $strip_html ? wp_strip_all_tags( $post->post_content ) : $post->post_content;
		}

		$status_code = wp_remote_retrieve_response_code( $response );
		if ( $status_code !== 200 ) {
			$this->log( "⚠️ Live Content: HTTP {$status_code} for {$post_url}" );
			return $strip_html ? wp_strip_all_tags( $post->post_content ) : $post->post_content;
		}

		$html = wp_remote_retrieve_body( $response );
		if ( empty( $html ) ) {
			$this->log( "⚠️ Live Content: Empty response body for {$post_url}" );
			return $strip_html ? wp_strip_all_tags( $post->post_content ) : $post->post_content;
		}

		// Extract main content area, unless the whole page should be analyzed.
		$content = $this->get_live_content_mode() === 'whole' ? $html : $this->extract_main_content( $html );
		$content_length = strlen( wp_strip_all_tags( $content ) );

		if ( $content_length < 50 ) {
			$this->log( "⚠️ Live Content: Extracted only {$content_length} chars from {$post_url}" );
		} else {
			$this->log( "✅ Live Content: Extracted {$content_length} chars from {$post_url}" );
		}

		if ( $strip_html ) {
			$content = wp_strip_all_tags( $content );
		}

		return preg_replace( '/\s+/', ' ', trim( $content ) );
	}

	/**
	 * Extract main content from rendered HTML page
	 */
	private function extract_main_content( $html ) {
		// Remove scripts, styles, comments
		$html = preg_replace( '/<script\b[^>]*>.*?<\/script>/is', '', $html );
		$html = preg_replace( '/<style\b[^>]*>.*?<\/style>/is', '', $html );
		$html = preg_replace( '/<!--.*?-->/s', '', $html );

		// Try common content selectors
		$selectors = [
			'/<article[^>]*>(.*?)<\/article>/is',
			'/<main[^>]*>(.*?)<\/main>/is',
			'/<div[^>]*class="[^"]*(?:entry-content|post-content|page-content|content-area)[^"]*"[^>]*>(.*?)<\/div>/is',
		];

		foreach ( $selectors as $pattern ) {
			if ( preg_match( $pattern, $html, $m ) && strlen( wp_strip_all_tags( $m[1] ) ) > 100 ) {
				return $m[1];
			}
		}

		// Fallback: body minus header/footer/nav
		if ( preg_match( '/<body[^>]*>(.*?)<\/body>/is', $html, $m ) ) {
			$body = $m[1];
			$body = preg_replace( '/<header[^>]*>.*?<\/header>/is', '', $body );
			$body = preg_replace( '/<footer[^>]*>.*?<\/footer>/is', '', $body );
			$body = preg_replace( '/<nav[^>]*>.*?<\/nav>/is', '', $body );
			$body = preg_replace( '/<aside[^>]*>.*?<\/aside>/is', '', $body );
			return $body;
		}

		return $html;
	}

	function check_images_alt_text( $post ) {

		$content = apply_filters( 'mwseo_post_content', $post->post_content, $post, false );

		$images = $this->get_images_from_content( $content );
		if ( !is_array( $images ) ) {
			return array();
		}

		$missing_alt_text = array();
		$image_meta_data = $this->get_all_image_meta_data($images);

		foreach ( $images as $image ) {
			if ( empty( $image[ 'alt' ] ) ) {
				$attachment_id = attachment_url_to_postid( $image[ 'src' ] );
				$meta_alt_text = $image_meta_data[$attachment_id];
				if ( !empty( $meta_alt_text ) ) {
					$this->log( sprintf( "🖼️ Image (src : %s) has alt text : %s", $image[ 'src' ], $meta_alt_text ) );
					continue;
				}
				$missing_alt_text[] = $image[ 'src' ];
			}
		}

		return $missing_alt_text;
	}

	function get_all_image_meta_data($images) {
		$meta_data = array();
		foreach ($images as $image) {
			$attachment_id = attachment_url_to_postid( $image[ 'src' ] );
			$meta_data[$attachment_id] = get_post_meta( $attachment_id, '_wp_attachment_image_alt', true );
		}
		return $meta_data;
	}


	function check_links( $content ){

		$links = array();
		$external_links = array();
		$internal_links = array();

		if ( preg_match_all( '/<a[^>]+>/i', $content, $matches ) ) {
			foreach ( $matches[0] as $link ) {
				if ( preg_match( '/href="http[s]?:\/\/([^"]+)"/i', $link, $href ) ) {
					$external_links[] = $href[ 1 ];
				}elseif ( preg_match( '/href="([^"]+)"/i', $link, $href ) ) {
					$internal_links[] = $href[ 1 ];
				}
			}
		}

		//TODO: Display the links somewhere, for now just the count

		$links[ 'external' ] = count( $external_links );
		$links[ 'internal' ] = count( $internal_links );
		$links[ 'total' ] = $links[ 'external' ] + $links[ 'internal' ];

		return $links;
	}


	/**
	 * Generate AI solution for a specific issue - Backward compatibility wrapper
	 *
	 * @deprecated Use $core->pro->magic_fix->generate_solution() instead
	 */
	public function magic_fix_generate_solution( $post, $issue_type ) {
		if ( $this->pro && $this->pro->magic_fix ) {
			return $this->pro->magic_fix->generate_solution( $post, $issue_type );
		}
		$this->log( '⚠️ Magic Fix is not available. This is a premium feature.' );
		return false;
	}

	/**
	 * Apply a generated solution to a post - Backward compatibility wrapper
	 *
	 * @deprecated Use $core->pro->magic_fix->apply_solution() instead
	 */
	public function magic_fix_apply_solution( $post, $issue_type, $solution ) {
		if ( $this->pro && $this->pro->magic_fix ) {
			return $this->pro->magic_fix->apply_solution( $post, $issue_type, $solution );
		}
		$this->log( '⚠️ Magic Fix is not available. This is a premium feature.' );
		return false;
	}

	/**
	 * Mark an issue as fixed by Magic Fix - Backward compatibility wrapper
	 *
	 * @deprecated Use $core->pro->magic_fix->mark_as_fixed() instead
	 */
	public function mark_issue_as_magic_fixed( $post_id, $issue_type ) {
		if ( $this->pro && $this->pro->magic_fix ) {
			return $this->pro->magic_fix->mark_as_fixed( $post_id, $issue_type );
		}
	}

	/**
	 * Check if an issue has been marked as fixed - Backward compatibility wrapper
	 *
	 * @deprecated Use $core->pro->magic_fix->is_fixed() instead
	 */
	public function is_issue_magic_fixed( $post_id, $issue_type ) {
		if ( $this->pro && $this->pro->magic_fix ) {
			return $this->pro->magic_fix->is_fixed( $post_id, $issue_type );
		}
		return false;
	}

	/**
	 * Clear all magic fix markers for a post - Backward compatibility wrapper
	 *
	 * @deprecated Use $core->pro->magic_fix->clear_markers() instead
	 */
	public function clear_magic_fix_markers( $post_id ) {
		if ( $this->pro && $this->pro->magic_fix ) {
			return $this->pro->magic_fix->clear_markers( $post_id );
		}
	}

	/**
	 * Migrate old meta keys to new mwseo prefixed keys
	 * This migration runs once per post when the post is accessed/analyzed
	 */
	public function migrate_post_meta_keys( $post_id ) {
		// Mapping of old keys to new keys
		$meta_keys_map = [
			'_seo_engine_data' => '_mwseo_analysis',
			'_seo_engine_ignored_tests' => '_mwseo_ignored_tests',
			'_seo_engine_overall' => '_mwseo_overall',
			'_seo_engine_updated' => '_mwseo_updated',
			'_seo_engine_ai_keywords' => '_mwseo_keywords',
			'_seo_title' => '_mwseo_title',
			'_seo_excerpt' => '_mwseo_excerpt',
			'_seo_robots' => '_mwseo_robots',
			'_seo_canonical' => '_mwseo_canonical',
			'_seo_status' => '_mwseo_status',
			'_seo_message' => '_mwseo_message',
			'_seo_score' => '_mwseo_score',
			'_seo_codes' => '_mwseo_codes',
		];

		foreach ( $meta_keys_map as $old_key => $new_key ) {
			$value = get_post_meta( $post_id, $old_key, true );
			if ( $value !== '' && $value !== false ) {
				// Copy to new key
				update_post_meta( $post_id, $new_key, $value );
				// Delete old key
				delete_post_meta( $post_id, $old_key );
			}
		}
	}

	/**
	 *
	 * Roles & Access Rights
	 *
	 */
	function can_access_settings() {
		return apply_filters( 'mwseo_allow_setup', current_user_can( 'manage_options' ) );
	}

	function can_access_features() {
		return apply_filters( 'mwseo_allow_usage', current_user_can( 'administrator' ) );
	}

	#region Options

	function get_option( $option, $default = null ) {
		$options = $this->get_all_options();
		return $options[$option] ?? $default;
	}

	function sanitized_options(){
		// This is a READ-ONLY method - it computes derived values but NEVER writes to the database
		$options = $this->get_all_options();

		$options['post_types'] = $this->make_post_type_list( $this->get_post_types() );
		$options['categories'] = $this->make_category_list( $this->get_categories() );
		$options['archive_post_types'] = $this->make_post_type_list( get_post_types( array( 'public' => true, 'has_archive' => true ) ) );

		if ( $options['language'] == 'auto' || empty( $options['language'] ) ) {
			$options['language'] = $this->get_language_name( get_locale() ) ?? 'English';
		}

		if ( empty( $options['readability_treshold'] ) ) {
			$options['readability_treshold'] = 50;
		}

		// Always force analyze_buffer to 1 - analyzing multiple posts at once causes performance issues
		$options['analyze_buffer'] = 1;

		// AI Engine - check status but DON'T modify stored options
		global $mwai;

		$options['mwai_has_ai'] = !empty( $mwai ) && $mwai->hasAI();
		$options['mwai_has_mcp'] = !empty( $mwai ) && $mwai->hasMCP();
		// Legacy
		$options['ai_engine_status'] = $options['mwai_has_ai'];

		// AI Features - Only disable in the returned array for UI purposes
		// DO NOT modify the stored user preferences
		if ( !$options['mwai_has_ai'] ) {
			$options['ai_magic_fix'] = false;
			$options['ai_auto_correct'] = false;
			$options['ai_magic_wand'] = false;
			$options['ai_keywords'] = false;
			$options['woocommerce_assistant'] = false;
		}

		// Module hierarchy - disable child features when parent module is disabled
		// Technical SEO children
		if ( empty( $options['technical_seo'] ) ) {
			$options['auto_schema_enabled'] = false;
			$options['redirect_attachments'] = false;
			$options['disallow_gpt_bot'] = false;
			$options['sitemap'] = false;
			$options['social_networks'] = false;
			$options['robot_editor'] = false;
			$options['llms_editor'] = false;
			$options['indexnow'] = false;
		}

		// Return sanitized options WITHOUT persisting to database
		return $options;
	}

	// TODO: Review which options are still in use after meta key refactoring - many may be obsolete
	function list_options() {
		return array(
			// Module Toggles
			'content_seo' => true,
			'technical_seo' => true,

			'speed_and_vitals' => false,
			'analytics' => true,
			
			// Content SEO
			'default_post_type' => 'post',
			'posts_limit' => 10,
			'posts_sort' => array( 'accessor' => 'score', 'by' => 'asc' ),
			'posts_filter' => 'all',
			'post_types' => $this->make_post_type_list( $this->get_post_types() ),
			
			'select_post_types' => ['post', 'page'],
			'readability_treshold' => 50,
			'language' => $this->get_language_name( get_locale() ) ?? 'English',
			// 'quick' keeps scores fresh after edits (non-AI baseline, scheduled off-request);
			// 'full' also re-runs the AI checks; 'none' lets counts go stale until a manual scan.
			'analyze_on_update' => 'quick',
			'analyze_buffer' => 1,
			'analyze_buffer_interval' => 0,
			
			// Technical SEO
			'indexnow' => true,
			'indexnow_key' => '',
			'sitemap' => false,
			'disable_wp_sitemap' => false,
			'sitemap_custom' => false,
			'sitemap_style' => 'default',
			'sitemap_path' => '',
			'sitemap_exclude_users_provider' => false,
			'sitemap_exclude_posts_provider' => false,
			'sitemap_exclude_taxonomies_provider' => false,
			'sitemap_excluded_post_types' => [],
			'sitemap_excluded_taxonomies' => [],
			'sitemap_excluded_post_ids' => [],
			'sitemap_max_urls' => 100,
			'sitemap_post_max_pages' => 100,
			'taxonomies' => $this->make_taxonomy_list( $this->get_taxonomies() ),
			'archive_seo' => [],
			'robot_editor' => false,
			'disallow_gpt_bot' => false,
			
			// Social Networks
			'social_networks' => false,
			'social_networks_twitter' => '',
			'social_networks_facebook_app_id' => '',
			
			// Google Cloud / API (shared: used by Speed & Vitals / PageSpeed Insights)
			'google_api_key' => '',

			// Analytics Configuration
			'analytics_method' => 'none', // 'none', 'private', 'google', 'plausible', 'matomo'
			
			// Analytics Options
			'bots_track' => true,
			'analytics_retention_days' => 365,
			'bots_instructions' => false,
			'bots_instructions_content' => '',
			// Private Analytics
			'general_analytics' => false,
			'analytics_track_logged_users' => false,
			'analytics_track_power_users' => false,
			'analytics_privacy' => false,
			
			// Google Analytics
			// The Settings toggle and the GA module both use 'analytics_cache'; this default
			// was named 'google_analytics_cache' for a while, so caching silently never engaged.
			'analytics_cache' => true,
			'google_analytics' => false,
			'google_analytics_property_ids' => [],
			'google_analytics_property_id' => '',
			'google_analytics_client_secret' => '',
			'google_analytics_client_id' => '',
			'google_analytics_tracking_ids' => [],
			'google_analytics_track_logged_users' => false,
			'google_analytics_track_power_users' => false,
			'google_analytics_tracking_disabled' => false,

			// Plausible Analytics
			'plausible_analytics' => false,
			'plausible_site_id' => '',
			'plausible_api_key' => '',
			'plausible_server_url' => 'https://plausible.io',
			'plausible_track_logged_users' => false,
			'plausible_track_power_users' => false,
			'plausible_analytics_tracking_disabled' => false,

			// Matomo Analytics
			'matomo_analytics' => false,
			'matomo_site_id' => '',
			'matomo_api_key' => '',
			'matomo_server_url' => '',
			'matomo_track_logged_users' => false,
			'matomo_track_power_users' => false,
			'matomo_analytics_tracking_disabled' => false,

			// Search Console module (Pro). When enabled, surfaces its own tab in
			// the admin with quick wins, top queries/pages, and post pulse — pulling
			// real Google search data. Reuses google_analytics_client_id/secret since
			// a single GCP OAuth client can grant tokens for multiple Google APIs.
			// `property` is the default for site-wide tools; `properties` is the set
			// of all GSC properties belonging to this WP install (Polylang/WPML
			// multi-domain). Per-post tools auto-pick from `properties` by URL match.
			'search_console' => false,
			'google_search_console_property' => '',
			'google_search_console_properties' => [],

			// AI Features
			'mwai_has_ai' => false,
			'mwai_has_mcp' => false,
			'ai_engine_status' => false,
			'ai_magic_fix' => false,
			'magic_fix_instructions' => '',
			'ai_auto_correct' => false,
			'ai_magic_wand' => false,
			'ai_keywords' => false,
			'ai_semantic_analysis' => true, // Enable AI semantic analysis (requires AI Engine)
			'full_analysis' => true, // Enable Full Analysis with Intelligence checks
			'daily_insights' => true,
			'woocommerce_assistant' => false,
			'woo_assistant_instructions' => '',
			'select_magic_fix' => [
				'readability_score',
			],

			// Scoring Preferences
			'pillar_weight_cq' => 50, // Content Quality weight (0-100)
			'pillar_weight_tech' => 50, // Technical weight (0-100)
			'quality_safeguards_enabled' => true,
			'use_seo_metadata' => true,
			// Frontend meta output: 'auto' defers to another active SEO plugin (Yoast,
			// Rank Math, AIOSEO, SEOPress), 'always' outputs regardless, 'never' stays silent.
			'frontend_meta_mode' => 'auto',
			'show_ai_summary' => true,
			'row_density' => 'cozy', // compact | cozy

			// Content Quality - Basic
			'use_excerpt_as_meta' => true,
			'aim_easy_reading' => true,
			'encourage_image_alt' => true,
			'ai_detect_intent' => true,
			'short_strong_mode' => true,

			// Content Quality - Advanced
			'readability_flesch_min' => 50,
			'readability_flesch_max' => 70,
			'readability_grade_min' => 7,
			'readability_grade_max' => 10,
			'short_strong_sensitivity' => 'normal', // normal | strict | off
			'show_author_visible' => true,
			'link_to_author_page' => true,
			'intent_schema_coherence' => true,

			// Technical - Basic
			'require_unique_title' => true,
			'encourage_short_slug' => true,
			'encourage_internal_links' => true,
			'check_internal_links' => true,
			'check_missing_alt_text' => true,
			'check_orphaned_content' => true,
			'auto_schema_enabled' => false,
			'breadcrumb_schema' => true,
			'title_separator' => '|',

			// Length Guidelines
			'title_length_min' => 30,
			'title_length_max' => 75,
			'excerpt_length_min' => 80,
			'excerpt_length_max' => 160,
			'content_length_min' => 300,
			'content_length_max' => 1600,

			// Technical - Advanced
			'slug_length_max' => 60,
			'slug_words_min' => 2,
			'slug_words_max' => 6,
			'smart_internal_links' => true,
			'check_external_links' => false,
			'check_live_content' => 'disabled',
			'schema_by_post_type' => [
				'post' => 'Article',
				'page' => 'WebPage',
				'product' => 'Product',
			],

			// Content Comfort Zones
			'comfort_zone_quick_min' => 150,
			'comfort_zone_quick_max' => 500,
			'comfort_zone_guide_min' => 700,
			'comfort_zone_guide_max' => 1600,
			'comfort_zone_product_min' => 300,
			'comfort_zone_product_max' => 900,

			// Legacy Score Factors (kept for compatibility)
			'score_check_title_exists' => true,
			'score_check_title_unique' => true,
			'score_check_title_length' => true,
			'score_check_excerpt_exists' => true,
			'score_check_excerpt_length' => true,
			'score_check_slug_length' => true,
			'score_check_slug_words' => true,
			'score_check_content_length' => true,
			'score_check_images_alt' => true,
			'score_check_links' => true,
			'score_check_readability' => true,
			
			// Redirections + 404
			'redirects_enabled' => false,
			'redirects_track_404' => true,
			'redirects_auto_slug' => false,
			'redirects_default_status' => 301,
			'redirects_404_retention_days' => 30,
			'redirects_404_exclude' => "/wp-admin/*\n/feed*\n/xmlrpc.php",
			'redirects_skip_bots' => true,

			// AI Visibility
			'ai_visibility' => false,
			'ai_visibility_surfaces' => [],

			// Maintenance & Others
			'logs' => false,
			'hide_dashboard_message' => false,
			'mcp_support' => false,
		);
	}

	// TODO: Delete after January 2026
	function migrate_option_names( $options ) {
		// Create a new array with migrated keys
		$migrated_options = array();
		
		foreach ( $options as $key => $value ) {
			// Check if the key starts with 'seo_engine_'
			if ( strpos( $key, 'seo_engine_' ) === 0 ) {
				// Remove 'seo_engine_' prefix
				$new_key = substr( $key, 11 );
				$migrated_options[$new_key] = $value;
			} else {
				// Keep the key as is if it doesn't have the prefix
				$migrated_options[$key] = $value;
			}
		}
		
		// Save the migrated options
		update_option( $this->option_name, $migrated_options, false );
		
		// Also migrate WordPress native options
		$this->migrate_native_options();
		
		return $migrated_options;
	}

	// TODO: Delete after January 2026
	function migrate_native_options() {
		// Migrate title hashes
		$old_title_hashes = get_option( 'seo_engine_title_hashes' );
		if ( $old_title_hashes !== false ) {
			update_option( 'mwseo_title_hashes', $old_title_hashes );
			delete_option( 'seo_engine_title_hashes' );
		}
		
		// Add any other native options that need migration here
	}

	function get_all_options() {

		// TODO: Delete after January 2026
		$old_options = get_option( $this->old_option_name, null );
		if ( $old_options ) {
			// Migrate old options to new option name
			update_option( $this->option_name, $old_options, false );
			delete_option( $this->old_option_name );

			$options = $old_options;
		} else {
			$options = get_option( $this->option_name, null );
		}
		
		// Check if we need to migrate from old option names
		if ( $options && isset( $options['default_post_type'] ) ) {
			$options = $this->migrate_option_names( $options );
		}
		
		// Make sure every option is set
		$options = wp_parse_args( $options, $this->list_options() );

		if( $this->parsers ) {
			$options = $this->parsers->refresh_parsers( $options );
		}
		
		return $options;
	}

	// Merges only the changed keys into a fresh read of what is stored, so the request stays
	// small and a change made elsewhere in the meantime is not overwritten with an older copy.
	function patch_options( array $changes ) {
		wp_cache_delete( $this->option_name, 'options' );
		$stored = get_option( $this->option_name, [] );
		$stored = is_array( $stored ) ? $stored : [];
		foreach ( $changes as $key => $value ) {
			$stored[ $key ] = $value;
		}
		$result = $this->update_options( $stored );
		return $result === false ? false : $this->sanitized_options();
	}

	function update_options( $options ) {
		// Computed lists for the UI, not settings.
		unset( $options['categories'], $options['archive_post_types'] );
		if ( $options == get_option( $this->option_name ) ) {
			return $options;
		}

		if ( !update_option( $this->option_name, $options, false ) ) {
			return false;
		}

		$options = $this->sanitized_options();

		return $options;
	}

	// "Hidden from search" lives in one place: the sitemap exclusion list (quick edit, Sitemap tab,
	// Bulk tab). A noindex in _mwseo_robots (imported from another SEO plugin) also counts.
	function is_post_noindexed( $post_id ) {
		$excluded = array_map( 'intval', (array) $this->get_option( 'sitemap_excluded_post_ids', [] ) );
		if ( in_array( (int) $post_id, $excluded, true ) ) return true;
		return strpos( (string) get_post_meta( $post_id, '_mwseo_robots', true ), 'noindex' ) !== false;
	}

	function set_posts_noindex( $post_ids, $noindex ) {
		$post_ids = array_map( 'intval', (array) $post_ids );
		$excluded = array_map( 'intval', (array) $this->get_option( 'sitemap_excluded_post_ids', [] ) );
		$excluded = $noindex ? array_merge( $excluded, $post_ids ) : array_diff( $excluded, $post_ids );
		$this->update_option( 'sitemap_excluded_post_ids', array_values( array_unique( $excluded ) ) );
		if ( !$noindex ) {
			foreach ( $post_ids as $pid ) {
				if ( strpos( (string) get_post_meta( $pid, '_mwseo_robots', true ), 'noindex' ) !== false ) {
					delete_post_meta( $pid, '_mwseo_robots' );
				}
			}
		}
	}

	function update_option( $option, $value ) {
		$options = $this->get_all_options();
		$options[$option] = $value;
		return $this->update_options( $options );
	}

	function reset_options() {
		return $this->update_options( $this->list_options() );
	}

	

	#endregion

	#region WooCommerce

	function generate_woocommerce_fields( $params )
	{
		global $mwai;

		if ( is_null( $mwai ) || !isset( $mwai ) ) {
			throw new Exception( 'AI Engine is not available.' );
		}

		$product_id = intval( $params['post_id'] ?? 0 );
		$product = get_post( $product_id );
		if ( !$product || $product->post_type !== 'product' ) {
			throw new Exception( 'Product not found.' );
		}

		// Which fields to generate. Defaults to all of them.
		$allowed_fields = [ 'seo_title', 'description', 'short_description', 'tags' ];
		$fields = !empty( $params['fields'] ) && is_array( $params['fields'] )
			? array_values( array_intersect( $allowed_fields, $params['fields'] ) )
			: $allowed_fields;
		if ( empty( $fields ) ) {
			throw new Exception( 'No fields requested.' );
		}

		// In bulk mode we only rely on the product title (and the image via Vision),
		// not on the existing descriptions/attributes.
		$title_only = !empty( $params['title_only'] );
		if ( $title_only ) {
			$product_data = [
				'id' => $product_id,
				'title' => $product->post_title,
			];
		}
		else {
			$wc_product = function_exists( 'wc_get_product' ) ? wc_get_product( $product_id ) : null;
			$product_data = [
				'id' => $product_id,
				'title' => $product->post_title,
				'description' => $product->post_content,
				'short_description' => $product->post_excerpt,
				'categories' => wp_get_post_terms( $product_id, 'product_cat', array( 'fields' => 'names' ) ),
				'tags' => wp_get_post_terms( $product_id, 'product_tag', array( 'fields' => 'names' ) ),
				'attributes' => $wc_product ? $wc_product->get_attributes() : [],
				'price' => $wc_product ? $wc_product->get_price() : null,
			];
		}

		// Use Vision if enabled
		$use_vision = !empty( $params['vision'] );
		$vision_result = null;
		if ( $use_vision ) {
			$product_image = get_post_meta( $product_id, '_thumbnail_id', true );
			if ( $product_image ) {

				$prompt = "Describe the main elements in the image, the colors, the style, the context, and any text that is visible. Write it in " . $params['language'] . ".";

				$intermediate = image_get_intermediate_size( $product_image, 'medium' );
				$path = $intermediate 
					? path_join( dirname( get_attached_file( $product_image ) ), $intermediate['file'] ) 
					: get_attached_file( $product_image );
				$url = $intermediate 
					? wp_get_attachment_image_url( $product_image, 'medium' ) 
					: wp_get_attachment_url( $product_image );

				if ( !file_exists( $path ) ) {
					$this->log( "⚠️ WooCommerce Assistant: Product image file not found at {$path}" );
				} else {
					// Cache vision results by file hash so the same image is only described once.
					$file_hash    = md5_file( $path );
					$transient_key = 'mwseo_vision_' . $file_hash;
					$cached        = get_transient( $transient_key );

					if ( $cached !== false ) {
						$this->log( "🔍 WooCommerce Assistant: Using cached vision result for image hash {$file_hash}." );
						$vision_result = $cached;
					} else {
						$vision_result = $mwai->simpleVisionQuery( $prompt, $url, $path, [ 'scope' => 'seo' ] );
						if ( $vision_result ) {
							set_transient( $transient_key, $vision_result, WEEK_IN_SECONDS );
						}
					}
				}

			}
		}

		$field_specs = [
			'description' => 'a description of this product (between 120 and 240 words)',
			'short_description' => 'a short description (between 20 and 49 words)',
			'seo_title' => 'a SEO-friendly title',
			'tags' => 'tags (separated by commas)',
		];
		$requested_specs = array_map( function( $field ) use ( $field_specs ) {
			return $field_specs[ $field ];
		}, $fields );

		$prompt  = "Based on the product, write " . implode( ', ', $requested_specs ) . ". SEO and sales focused. Write it in {LANGUAGE}.";

		if ( !empty( $params['product'] ) ) {
			$prompt .= "\n\nHere are the user provided details about the product: {PRODUCT}.";
		}

		// The custom instructions are persistent (Content SEO settings), so single-product
		// generation gets them too. The bulk modal sends its own value to override them for
		// that run (an explicit empty string means "none").
		$instructions = isset( $params['instructions'] )
			? trim( (string) $params['instructions'] )
			: trim( (string) $this->get_option( 'woo_assistant_instructions', '' ) );

		if ( !empty( $instructions ) ) {
			$prompt .= "\n\nHere are general instructions from the user: " . $instructions;
		}

		$prompt .= "\n\nHere are the details extracted from the product data: " . json_encode( $product_data );

		if ( $vision_result ) {
			$prompt .= "\n\nAlso, here is what is seen in the product image: " . $vision_result;
		}

		$prompt  = apply_filters( 'mwseo_woo_product_prompt', $prompt );
		$prompt .= "Your reply must be a formatted JSON only. Use these keys: " . implode( ', ', $fields ) . ".";

		$prompt = str_replace( '{PRODUCT}',  $params['product'] ?? '',  $prompt );
		$prompt = str_replace( '{LANGUAGE}', $params['language'], $prompt );

		$response = $mwai->simpleTextQuery( $prompt );

		// Remove any "```json" or "```" from the response
		$response = preg_replace( '/^```json\s*/', '', $response );
		$response = preg_replace( '/\s*```$/', '', $response );

		// Ensure the response is valid JSON
		$json = json_decode( $response, true );
		if ( json_last_error() !== JSON_ERROR_NONE ) {
			$this->log( '⚠️ WooCommerce Assistant: Invalid JSON response from AI: ' . json_last_error_msg() );
			$this->log( 'Response: ' .$response );
			return false;
		}

		// Only return the requested fields.
		return array_intersect_key( $json, array_flip( $fields ) );
	}

	function apply_woocommerce_fields( $params )
	{
		$product_id = intval( $params['post_id'] ?? 0 );
		$product = get_post( $product_id );
		if ( !$product || $product->post_type !== 'product' ) {
			throw new Exception( 'Product not found.' );
		}

		$update = [ 'ID' => $product_id ];
		if ( isset( $params['seo_title'] ) && trim( $params['seo_title'] ) !== '' ) {
			$update['post_title'] = sanitize_text_field( $params['seo_title'] );
		}
		if ( isset( $params['description'] ) && trim( $params['description'] ) !== '' ) {
			$update['post_content'] = wp_kses_post( $params['description'] );
		}
		if ( isset( $params['short_description'] ) && trim( $params['short_description'] ) !== '' ) {
			$update['post_excerpt'] = wp_kses_post( $params['short_description'] );
		}

		if ( count( $update ) > 1 ) {
			$result = wp_update_post( wp_slash( $update ), true );
			if ( is_wp_error( $result ) ) {
				throw new Exception( $result->get_error_message() );
			}
		}

		if ( !empty( $params['tags'] ) ) {
			$tags = is_array( $params['tags'] ) ? $params['tags'] : explode( ',', $params['tags'] );
			$tags = array_filter( array_map( function( $tag ) {
				return sanitize_text_field( trim( $tag ) );
			}, $tags ) );
			if ( !empty( $tags ) ) {
				// Append: existing tags are kept, already-present tags are not duplicated.
				$result = wp_set_object_terms( $product_id, $tags, 'product_tag', true );
				if ( is_wp_error( $result ) ) {
					throw new Exception( $result->get_error_message() );
				}
			}
		}

		return true;
	}

	#endregion

	#region Utilities

	function import_yoast() {
		// For all the selected post types, get the _yoast_wpseo_title & _yoast_wpseo_metadesc	and import them to _kiss_seo_title & _kiss_seo_excerpt
		// TODO: Migrate to _mwseo_title & _mwseo_excerpt
		$post_types = $this->get_option( 'select_post_types', array( 'post' ) );
		$posts = get_posts( array(
			'post_type' => $post_types,
			'posts_per_page' => -1,
			'meta_query' => array(
				'relation' => 'OR',
				array(
					'key' => '_yoast_wpseo_title',
					'compare' => 'EXISTS',
				),
				array(
					'key' => '_yoast_wpseo_metadesc',
					'compare' => 'EXISTS',
				),
			),
		) );

		foreach ( $posts as $post ) {
			$yoast_title = $this->yoast_replace_vars( get_post_meta( $post->ID, '_yoast_wpseo_title', true ), $post );
			$yoast_excerpt = $this->yoast_replace_vars( get_post_meta( $post->ID, '_yoast_wpseo_metadesc', true ), $post );
			$yoast_keywords = get_post_meta( $post->ID, '_yoast_wpseo_focuskw', true );

			if ( !empty( $yoast_title ) ) {
				update_post_meta( $post->ID, $this->meta_key_seo_title, $yoast_title );
			}
			if ( !empty( $yoast_excerpt ) ) {
				update_post_meta( $post->ID, $this->meta_key_seo_excerpt, $yoast_excerpt );
			}
			if ( !empty( $yoast_keywords ) ) {
				$keywords = explode( ',', $yoast_keywords );
				$keywords = array_slice( $keywords, 0, 5 );
				
				update_post_meta( $post->ID, $this->meta_key_seo_keywords, $keywords );
			}
		}

		return array(
			'posts' => count( $posts ),
			'redirects' => 0,
		);
	}

	/**
	 * Yoast stores titles/descriptions as templates ("%%title%% %%sep%% %%sitename%%").
	 * Resolve the common variables into plain text; unknown ones are dropped.
	 * ponytail: resolved once at import, so a later post rename won't update an imported title.
	 */
	function yoast_replace_vars( $text, $post, $sep = null, $extra = [] ) {
		$text = (string) $text;
		if ( strpos( $text, '%%' ) === false ) return $text;

		$seps = [ 'sc-dash' => '-', 'sc-ndash' => '–', 'sc-mdash' => '—', 'sc-colon' => ':', 'sc-middot' => '·',
			'sc-bull' => '•', 'sc-star' => '*', 'sc-smstar' => '⋆', 'sc-pipe' => '|', 'sc-tilde' => '~',
			'sc-laquo' => '«', 'sc-raquo' => '»', 'sc-lt' => '<', 'sc-gt' => '>' ];
		$yoast_titles = get_option( 'wpseo_titles', [] );
		$sep = $sep ?? ( $seps[ $yoast_titles['separator'] ?? 'sc-dash' ] ?? '-' );

		$primary_cat = '';
		$cat_id = (int) get_post_meta( $post->ID, '_yoast_wpseo_primary_category', true );
		$cats = get_the_category( $post->ID );
		if ( $cat_id && ( $term = get_term( $cat_id ) ) && !is_wp_error( $term ) ) $primary_cat = $term->name;
		else if ( !empty( $cats ) ) $primary_cat = $cats[0]->name;
		$excerpt = has_excerpt( $post ) ? $post->post_excerpt : wp_trim_words( wp_strip_all_tags( strip_shortcodes( $post->post_content ) ), 30, '' );

		$vars = [
			'title'            => $post->post_title,
			'sitename'         => get_bloginfo( 'name' ),
			'sitedesc'         => get_bloginfo( 'description' ),
			'sep'              => $sep,
			'excerpt'          => $excerpt,
			'excerpt_only'     => $post->post_excerpt,
			'primary_category' => $primary_cat,
			'category'         => implode( ', ', wp_list_pluck( $cats ?: [], 'name' ) ),
			'tag'              => implode( ', ', wp_list_pluck( get_the_tags( $post->ID ) ?: [], 'name' ) ),
			'date'             => get_the_date( '', $post ),
			'modified'         => get_the_modified_date( '', $post ),
			'name'             => get_the_author_meta( 'display_name', $post->post_author ),
			'id'               => $post->ID,
			'parent_title'     => $post->post_parent ? get_the_title( $post->post_parent ) : '',
			'focuskw'          => get_post_meta( $post->ID, '_yoast_wpseo_focuskw', true ),
			'currentyear'      => date_i18n( 'Y' ),
			'currentmonth'     => date_i18n( 'F' ),
			'currentday'       => date_i18n( 'j' ),
			'currentdate'      => date_i18n( get_option( 'date_format' ) ),
		] + $extra;
		$text = preg_replace_callback( '/%%([a-z0-9_]+)%%/i', function( $m ) use ( $vars ) {
			$key = strtolower( $m[1] );
			return isset( $vars[ $key ] ) ? (string) $vars[ $key ] : '';
		}, $text );

		// Tidy what dropped variables leave behind: repeated/edge separators and spaces.
		$q = preg_quote( $sep, '/' );
		$text = preg_replace( '/\s+/', ' ', $text );
		$text = preg_replace( '/(\s*' . $q . '\s*){2,}/u', ' ' . $sep . ' ', $text );
		$text = preg_replace( '/^(\s*' . $q . '\s*)+|(\s*' . $q . '\s*)+$/u', '', $text );
		return trim( $text );
	}

	function get_title_separator() {
		$separator = trim( mb_substr( wp_strip_all_tags( (string) $this->get_option( 'title_separator', '|' ) ), 0, 5 ) );
		return apply_filters( 'mwseo_title_separator', $separator !== '' ? $separator : '|' );
	}

	function get_seo_title( $post ) {
		$seo_title = get_post_meta( $post->ID, $this->meta_key_seo_title, true );
		if ( empty( $seo_title ) ) {
			$seo_title = $this->build_title( $post );
		}
		return $seo_title;
	}

	function set_seo_title( $post, $title ) {
		if ( empty( $title ) ) {
			return false;
		}
		$title = trim( strip_tags( $title ) );
		if ( empty( $title ) ) {
			return false;
		}
		update_post_meta( $post->ID, $this->meta_key_seo_title, $title );
		return true;
	}

	function get_seo_excerpt( $post ) {
		$seo_excerpt = get_post_meta( $post->ID, $this->meta_key_seo_excerpt, true );
		if ( empty( $seo_excerpt ) ) {
			$seo_excerpt = $this->build_excerpt( $post );
		}
		return $seo_excerpt;
	}

	function set_seo_excerpt( $post, $excerpt ) {
		if ( empty( $excerpt ) ) {
			return false;
		}
		$excerpt = trim( strip_tags( $excerpt ) );
		if ( empty( $excerpt ) ) {
			return false;
		}
		update_post_meta( $post->ID, $this->meta_key_seo_excerpt, $excerpt );
		return true;
	}

	/**
	 * Calculate effective display width of text for SERP.
	 * CJK characters (Chinese, Japanese, Korean) are roughly twice as wide as Latin characters
	 * in Google's search results, so they count as 2 units. This approximates the pixel-based
	 * measurement that Google actually uses for title/description truncation.
	 *
	 * @param string $text The text to measure
	 * @return int Display width in units (Latin chars = 1, CJK chars = 2)
	 */
	function get_display_width( $text ) {
		if ( empty( $text ) ) {
			return 0;
		}
		$width = 0;
		// Split into individual characters (UTF-8 safe)
		$chars = preg_split( '//u', $text, -1, PREG_SPLIT_NO_EMPTY );
		foreach ( $chars as $char ) {
			// CJK Unified Ideographs, Extension A, Hiragana, Katakana, Hangul Syllables
			if ( preg_match( '/[\x{4E00}-\x{9FFF}\x{3400}-\x{4DBF}\x{3040}-\x{309F}\x{30A0}-\x{30FF}\x{AC00}-\x{D7AF}]/u', $char ) ) {
				$width += 2;
			} else {
				$width += 1;
			}
		}
		return $width;
	}

	/**
	 * Check if text is predominantly CJK characters.
	 *
	 * @param string $text The text to check
	 * @param float $threshold Ratio threshold (default 0.5 = 50% CJK)
	 * @return bool True if text meets or exceeds CJK threshold
	 */
	function is_mostly_cjk( $text, $threshold = 0.5 ) {
		if ( empty( $text ) ) {
			return false;
		}
		$text_length = mb_strlen( $text, 'UTF-8' );
		if ( $text_length === 0 ) {
			return false;
		}
		// Count CJK characters
		preg_match_all( '/[\x{4E00}-\x{9FFF}\x{3400}-\x{4DBF}\x{3040}-\x{309F}\x{30A0}-\x{30FF}\x{AC00}-\x{D7AF}]/u', $text, $matches );
		$cjk_count = count( $matches[0] );
		return ( $cjk_count / $text_length ) >= $threshold;
	}

	function import_rank_math() {
		// For all the selected post types, get the _rank_math_title & _rank_math_description and import them to _kiss_seo_title & _kiss_seo_excerpt
		// TODO: Migrate to _mwseo_title & _mwseo_excerpt
		$post_types = $this->get_option( 'select_post_types', array( 'post ') );
		$posts = get_posts( array(
			'post_type' => $post_types,
			'posts_per_page' => -1,
			'meta_query' => array(
				array(
					'key' => 'rank_math_title',
					'compare' => 'EXISTS',
				),
				array(
					'key' => 'rank_math_description',
					'compare' => 'EXISTS',
				),
			),
		) );

		foreach ( $posts as $post ) {

			$rank_math_title = get_post_meta( $post->ID, 'rank_math_title', true );
			$rank_math_excerpt = get_post_meta( $post->ID, 'rank_math_description', true );
			$rank_math_keywords = get_post_meta( $post->ID, 'rank_math_focus_keyword', true );

			if ( !empty( $rank_math_title ) ) {
				update_post_meta( $post->ID, $this->meta_key_seo_title, $rank_math_title );
			}
			if ( !empty( $rank_math_excerpt ) ) {
				update_post_meta( $post->ID, $this->meta_key_seo_excerpt, $rank_math_excerpt );
			}
			if ( !empty( $rank_math_keywords ) ) {
				$keywords = explode( ',', $rank_math_keywords );
				$keywords = array_slice( $keywords, 0, 5 );
				
				update_post_meta( $post->ID, $this->meta_key_seo_keywords, $keywords );
			}
		}

		// Also import Rank Math redirections that aren't already declared in SEO Engine.
		$redirects = 0;
		if ( $this->redirects_module ) {
			$redirects = (int) $this->redirects_module->import_from_rank_math();
		}

		return array(
			'posts' => count( $posts ),
			'redirects' => $redirects,
		);
	}

	function import_seopress() {
		$post_types = $this->get_option( 'select_post_types', array( 'post' ) );
		$posts = get_posts( array(
			'post_type' => $post_types,
			'posts_per_page' => -1,
			'meta_query' => array(
				'relation' => 'OR',
				array(
					'key' => '_seopress_titles_title',
					'compare' => 'EXISTS',
				),
				array(
					'key' => '_seopress_titles_desc',
					'compare' => 'EXISTS',
				),
			),
		) );

		// SEOPress uses the same %%var%% templates as Yoast, with its own separator and a few renamed vars.
		$titles = get_option( 'seopress_titles', [] );
		$sep = !empty( $titles['seopress_titles_sep'] ) ? html_entity_decode( $titles['seopress_titles_sep'] ) : '-';

		foreach ( $posts as $post ) {
			$keywords = get_post_meta( $post->ID, '_seopress_analysis_target_kw', true );
			$extra = [
				'post_title'         => $post->post_title,
				'sitetitle'          => get_bloginfo( 'name' ),
				'tagline'            => get_bloginfo( 'description' ),
				'post_excerpt'       => $post->post_excerpt,
				'post_category'      => implode( ', ', wp_list_pluck( get_the_category( $post->ID ) ?: [], 'name' ) ),
				'post_tag'           => implode( ', ', wp_list_pluck( get_the_tags( $post->ID ) ?: [], 'name' ) ),
				'post_date'          => get_the_date( '', $post ),
				'post_modified_date' => get_the_modified_date( '', $post ),
				'post_author'        => get_the_author_meta( 'display_name', $post->post_author ),
				'target_keyword'     => $keywords,
			];
			$title = $this->yoast_replace_vars( get_post_meta( $post->ID, '_seopress_titles_title', true ), $post, $sep, $extra );
			$excerpt = $this->yoast_replace_vars( get_post_meta( $post->ID, '_seopress_titles_desc', true ), $post, $sep, $extra );

			if ( !empty( $title ) ) {
				update_post_meta( $post->ID, $this->meta_key_seo_title, $title );
			}
			if ( !empty( $excerpt ) ) {
				update_post_meta( $post->ID, $this->meta_key_seo_excerpt, $excerpt );
			}
			if ( !empty( $keywords ) ) {
				$keywords = array_slice( array_map( 'trim', explode( ',', $keywords ) ), 0, 5 );
				update_post_meta( $post->ID, $this->meta_key_seo_keywords, $keywords );
			}
		}

		return array(
			'posts' => count( $posts ),
			'redirects' => 0,
		);
	}

	function get_language_name( $locale ) {
		$locale_name_array = [
			'en_US' => 'English (US)',
			'en_GB' => 'English (UK)',
			'en_AU' => 'English (Australia)',
			'en_CA' => 'English (Canada)',
			'fr_FR' => 'French',
			'fr_BE' => 'French (Belgium)',
			'fr_CA' => 'French (Canada)',
			'de_DE' => 'German',
			'de_CH' => 'German (Switzerland)',
			'de_AT' => 'German (Austria)',
			'it_IT' => 'Italian',
			'pt_PT' => 'Portuguese',
			'pt_BR' => 'Portuguese (Brazil)', 
			'es_ES' => 'Spanish',
			'es_MX' => 'Spanish (Mexico)',
			'es_GT' => 'Spanish (Guatemala)',
			'es_CL' => 'Spanish (Chile)',
			'es_AR' => 'Spanish (Argentina)',
			'es_CO' => 'Spanish (Colombia)',
			'es_PE' => 'Spanish (Peru)',
			'es_VE' => 'Spanish (Venezuela)',
			'nl_NL' => 'Dutch',
			'nl_BE' => 'Dutch (Belgium)',
			'ru_RU' => 'Russian',
			'pl_PL' => 'Polish',
			'ja' => 'Japanese',
			'zh_CN' => 'Chinese (China)',
			'zh_TW' => 'Chinese (Taiwan)',
			'ko_KR' => 'Korean',
			'ar' => 'Arabic',
			'he_IL' => 'Hebrew',
			'id_ID' => 'Indonesian',
			'ms_MY' => 'Malay',
			'th' => 'Thai',
			'vi' => 'Vietnamese',
			'tr_TR' => 'Turkish',
			'bg_BG' => 'Bulgarian',
			'el' => 'Greek',
			'da_DK' => 'Danish',
			'fa_IR' => 'Persian',
			'fi' => 'Finnish',
			'hi_IN' => 'Hindi',
			'hr' => 'Croatian',
			'hu_HU' => 'Hungarian',
			'nb_NO' => 'Norwegian (Bokmål)',
			'ro_RO' => 'Romanian',
			'sl_SI' => 'Slovenian',
			'sv_SE' => 'Swedish',
			'uk' => 'Ukrainian',
			'cs_CZ' => 'Czech',
			'sk_SK' => 'Slovak',
			'lt_LT' => 'Lithuanian',
			'mk_MK' => 'Macedonian',
			'mg_MG' => 'Malagasy',
			'ta_IN' => 'Tamil',
			'tl' => 'Tagalog',
			'az_AZ' => 'Azerbaijani',
			'az_TR' => 'Azerbaijani (Turkey)'  
		  ];

		if ( isset( $locale_name_array[ $locale ] ) ) {
			return $locale_name_array[ $locale ];
		}
		else {
			return null;
		}
	}

	// Returns a human-readable language name for AI prompts.
	// Falls back to the global 'language' option when no multilingual plugin is
	// active or the post has no language assigned.
	function get_post_language_name( $post_id ) {
		$post_locale = null;
		if ( function_exists( 'pll_get_post_language' ) ) {
			$post_locale = pll_get_post_language( $post_id, 'locale' );
		}
		elseif ( function_exists( 'wpml_get_language_information' ) ) {
			$info = wpml_get_language_information( null, $post_id );
			if ( ! is_wp_error( $info ) && ! empty( $info['locale'] ) ) {
				$post_locale = $info['locale'];
			}
		}
		elseif ( function_exists( 'bogo_get_post_locale' ) ) {
			// Bogo stores the locale in the _locale meta and falls back to the
			// site default itself, so this is always a usable locale.
			$post_locale = bogo_get_post_locale( $post_id );
		}
		$name = null;
		if ( $post_locale ) {
			$name = $this->get_language_name( $post_locale );
		}
		if ( !$name ) {
			$name = $this->get_option( 'language', 'English' );
		}
		// Escape hatch for setups we don't detect (custom or unsupported
		// multilingual plugins): return the language AI should write in.
		return apply_filters( 'mwseo_post_language_name', $name, $post_id, $post_locale );
	}

	/**
	 * The post's language as an identifier used to group/filter posts, or null
	 * when no multilingual plugin is active. Polylang and WPML return a short
	 * slug ("fr"); Bogo returns the full locale ("fr_FR") because two Bogo
	 * locales can share a slug and we need them to stay distinct.
	 */
	function get_post_language_slug( $post_id ) {
		if ( function_exists( 'pll_get_post_language' ) ) {
			$slug = pll_get_post_language( $post_id, 'slug' );
			return $slug ? $slug : null;
		}
		if ( function_exists( 'wpml_get_language_information' ) ) {
			$info = wpml_get_language_information( null, $post_id );
			return ( !is_wp_error( $info ) && !empty( $info['language_code'] ) ) ? $info['language_code'] : null;
		}
		if ( function_exists( 'bogo_get_post_locale' ) ) {
			$locale = bogo_get_post_locale( $post_id );
			return $locale ? $locale : null;
		}
		return null;
	}

	/**
	 * IDs of the post's translations. May include the post itself (callers merge
	 * it into an exclusion list anyway).
	 */
	function get_post_translation_ids( $post_id ) {
		if ( function_exists( 'pll_get_post_translations' ) ) {
			$ids = pll_get_post_translations( $post_id );
			return is_array( $ids ) ? array_values( array_map( 'intval', $ids ) ) : array();
		}
		if ( function_exists( 'wpml_get_language_information' ) ) {
			global $sitepress;
			$post = get_post( $post_id );
			if ( $sitepress && $post ) {
				$trid = $sitepress->get_element_trid( $post_id, 'post_' . $post->post_type );
				$translations = $sitepress->get_element_translations( $trid, 'post_' . $post->post_type );
				if ( is_array( $translations ) ) {
					return array_values( array_map( 'intval', wp_list_pluck( $translations, 'element_id' ) ) );
				}
			}
			return array();
		}
		if ( function_exists( 'bogo_get_post_translations' ) ) {
			// Bogo returns WP_Post objects keyed by locale, and excludes the post itself.
			$posts = bogo_get_post_translations( $post_id );
			if ( is_array( $posts ) ) {
				return array_values( array_map( function ( $p ) {
					return isset( $p->ID ) ? (int) $p->ID : (int) $p;
				}, $posts ) );
			}
			return array();
		}
		return array();
	}

	/**
	 * Restrict WP_Query args to one language. $language is an identifier from
	 * get_available_languages(); 'all' (or empty) means every language.
	 *
	 * Every query we run outside the admin has to go through this, even when no
	 * language is selected: Bogo hooks parse_query and narrows ANY query it sees
	 * down to get_locale() unless bogo_suppress_locale_query is set. REST requests
	 * are not is_admin(), so without that opt-out our lists, scans and sitemaps
	 * silently returned the site language only, and asking for another language
	 * could never match (Bogo's own WHERE was already ANDed in).
	 */
	function apply_language_filter( $args, $language ) {
		$is_bogo = function_exists( 'bogo_get_post_locale' );
		if ( $is_bogo ) {
			$args['bogo_suppress_locale_query'] = true;
		}
		if ( $language === 'all' && function_exists( 'pll_get_post_language' ) ) {
			// Without an explicit 'lang', Polylang narrows queries to its current
			// language, which on post.php is the language of the post being edited.
			$args['lang'] = '';
		}
		if ( empty( $language ) || $language === 'all' ) {
			return $args;
		}
		if ( function_exists( 'pll_get_post_language' ) ) {
			$args['tax_query'][] = array(
				'taxonomy' => 'language',
				'field'    => 'slug',
				'terms'    => $language,
			);
			return $args;
		}
		if ( $is_bogo ) {
			// Filter on Bogo's _locale meta rather than its own 'lang' query var:
			// get_posts() defaults to suppress_filters, so the WHERE clause Bogo
			// builds from 'lang' would never run for half of our queries.
			$clause = array(
				'relation' => 'OR',
				array( 'key' => '_locale', 'value' => $language ),
			);
			// Posts in the site's default language often have no _locale row at
			// all (Bogo only writes it for translations), so treat "missing" as
			// the default locale.
			$default = function_exists( 'bogo_get_default_locale' ) ? bogo_get_default_locale() : null;
			if ( $default && $language === $default ) {
				$clause[] = array( 'key' => '_locale', 'compare' => 'NOT EXISTS' );
			}
			$args['meta_query'][] = $clause;
			return $args;
		}
		return $args;
	}

	/**
	 * Languages available on the site, as [ [ 'slug' => ..., 'name' => ... ] ].
	 * Empty when no supported multilingual plugin is active.
	 */
	function get_available_languages() {
		$languages = array();
		if ( function_exists( 'pll_languages_list' ) ) {
			$slugs = pll_languages_list();
			$names = pll_languages_list( array( 'fields' => 'name' ) );
			foreach ( (array) $slugs as $i => $slug ) {
				$languages[] = array( 'slug' => $slug, 'name' => $names[ $i ] ?? $slug );
			}
			return $languages;
		}
		if ( function_exists( 'bogo_available_locales' ) ) {
			foreach ( (array) bogo_available_locales() as $locale ) {
				$name = function_exists( 'bogo_get_language_native_name' )
					? bogo_get_language_native_name( $locale ) : '';
				$languages[] = array( 'slug' => $locale, 'name' => $name ? $name : $locale );
			}
			return $languages;
		}
		return $languages;
	}

	#endregion

	/**
	 * Redirect attachment URLs to their parent post URLs
	 */
	public function redirect_attachment_to_parent( $link, $post_id ) {
		$attachment = get_post( $post_id );
		if ( $attachment && $attachment->post_type === 'attachment' && $attachment->post_parent ) {
			// A deleted parent has no permalink: keep the attachment's own link.
			return get_permalink( $attachment->post_parent ) ?: $link;
		}
		return $link;
	}

	/**
	 * Handle attachment page redirects to parent post
	 */
	public function handle_attachment_redirect()
	{
		if ( is_attachment() ) {
			global $post;

			if ( $post && $post->post_parent ) {
				wp_safe_redirect( esc_url( get_permalink( $post->post_parent ) ), 301 ) ;
			} else {
				wp_safe_redirect ( esc_url( home_url( '/' ) ), 301 );
			}
		}
	}

	#region Sitemap

	function generate_sitemap() {
		if ( !isset( $this->sitemap_module ) ) {
			return false;
		}

		return $this->sitemap_module->create_sitemap();
	}


	#endregion

	#region Robots.txt

	function get_robots_txt() {
		if ( ! function_exists( 'get_home_path' ) ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
		}
		$home_path = get_home_path();

		if ( ! is_writable( $home_path ) && ! empty( $_SERVER['DOCUMENT_ROOT'] ) ) {
			$home_path = $_SERVER['DOCUMENT_ROOT'] . DIRECTORY_SEPARATOR;
		}

		$robots_path = $home_path . 'robots.txt';
		$source = 'none';

		
		if ( file_exists( $robots_path ) ) {
			$robotsTxt = file_get_contents( $robots_path );
			$source = 'file';
		} else {
			// Get the default WordPress robots.txt content
			ob_start();
			do_robots();
			$robotsTxt = ob_get_clean();
			$source = 'default';
		}

		return [
			'content' => $robotsTxt,
			'source' => $source,
			'path' => $robots_path,
		];
	}

	function set_robots_txt( $content ) {
		if ( ! function_exists( 'get_home_path' ) ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
		}
		$home_path = get_home_path();

		if ( ! is_writable( $home_path ) && ! empty( $_SERVER['DOCUMENT_ROOT'] ) ) {
			$home_path = $_SERVER['DOCUMENT_ROOT'] . DIRECTORY_SEPARATOR;
		}

		$robots_file = $home_path . 'robots.txt';

		if( !is_writable( $home_path ) ) {
			return false;
		}

		if( !file_exists( $robots_file ) ) {
			ob_start();
			error_reporting( 0 );
			do_robots();
			$robots_content = ob_get_clean();

			$f = fopen( $robots_file, 'x' );
			fwrite( $f, $robots_content );
			fclose( $f );
		}

		if ( !empty( $content ) ) {
			$content = sanitize_textarea_field( wp_unslash( $content ) );
			$f = fopen( $robots_file, 'w+' );
			fwrite( $f, $content );
			fclose( $f );
		}

		return true;
	}

	#endregion

	#region LLMs.txt

	function get_llms_txt() {
		if ( ! function_exists( 'get_home_path' ) ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
		}
		$home_path = get_home_path();

		if ( ! is_writable( $home_path ) && ! empty( $_SERVER['DOCUMENT_ROOT'] ) ) {
			$home_path = $_SERVER['DOCUMENT_ROOT'] . DIRECTORY_SEPARATOR;
		}

		$llms_path = $home_path . 'llms.txt';
		$source = 'none';
		
		if ( file_exists( $llms_path ) ) {
			$llmsTxt = file_get_contents( $llms_path );
			$source = 'file';
		} else {
			$llmsTxt = $this->get_template_llms();
			$source = 'template';
		}

		return [
			'content' => $llmsTxt,
			'source' => $source,
			'path' => $llms_path,
		];
	}

	function get_template_llms() {

		$site_url   = get_site_url();
		$site_name  = get_bloginfo( 'name' );
		$site_desc  = get_bloginfo( 'description' );

		$summary = !empty( $site_desc )
			? $site_desc
			: 'Short summary describing what this site is about.';

		$lines = [];
		$lines[] = '# ' . $site_name;
		$lines[] = '';
		$lines[] = '> ' . $summary;
		$lines[] = '';

		// Pages section: front/blog page + top-level pages.
		$page_entries = [];
		$front_id = (int) get_option( 'page_on_front' );
		$blog_id  = (int) get_option( 'page_for_posts' );
		$seen     = [];
		$push_page = function( $p ) use ( &$page_entries, &$seen ) {
			if ( !$p || $p->post_status !== 'publish' ) return;
			$url = get_permalink( $p );
			if ( isset( $seen[ $url ] ) ) return;
			$seen[ $url ] = true;
			$title = !empty( $p->post_title ) ? $p->post_title : $url;
			$page_entries[] = '* [' . $title . '](' . $url . '): Add a one-line description for this page.';
		};
		if ( $front_id ) $push_page( get_post( $front_id ) );
		if ( $blog_id && $blog_id !== $front_id ) $push_page( get_post( $blog_id ) );
		$top_pages = get_posts( [
			'post_type'      => 'page',
			'post_status'    => 'publish',
			'posts_per_page' => 5,
			'orderby'        => 'menu_order title',
			'order'          => 'ASC',
			'post_parent'    => 0,
		] );
		foreach ( $top_pages as $p ) $push_page( $p );

		if ( !empty( $page_entries ) ) {
			$lines[] = '## Pages';
			foreach ( $page_entries as $e ) $lines[] = $e;
			$lines[] = '';
		}

		// Articles section: most recent published posts.
		$recent = wp_get_recent_posts( [
			'numberposts' => 5,
			'post_status' => 'publish',
		], OBJECT );
		if ( !empty( $recent ) ) {
			$lines[] = '## Articles';
			foreach ( $recent as $p ) {
				$url = get_permalink( $p );
				if ( isset( $seen[ $url ] ) ) continue;
				$seen[ $url ] = true;
				$title = !empty( $p->post_title ) ? $p->post_title : $url;
				$lines[] = '* [' . $title . '](' . $url . '): Add a one-line description for this article.';
			}
			$lines[] = '';
		}

		// Always include an Optional section so users see the spec pattern.
		if ( empty( $page_entries ) && empty( $recent ) ) {
			$lines[] = '## Pages';
			$lines[] = '* [Page Title](' . $site_url . '/page-url/): Add a one-line description for this page.';
			$lines[] = '';
			$lines[] = '## Articles';
			$lines[] = '* [Article Title](' . $site_url . '/post-url/): Add a one-line description for this article.';
			$lines[] = '';
		}

		$lines[] = '## Optional';
		$lines[] = '* [Lower-priority resource](' . $site_url . '/optional-url/): Content that can be skipped when context is limited.';
		$lines[] = '';

		return implode( "\n", $lines );

	}

	function set_llms_txt( $content ) {
		if ( ! function_exists( 'get_home_path' ) ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
		}
		$home_path = get_home_path();

		if ( ! is_writable( $home_path ) && ! empty( $_SERVER['DOCUMENT_ROOT'] ) ) {
			$home_path = $_SERVER['DOCUMENT_ROOT'] . DIRECTORY_SEPARATOR;
		}

		$llms_path = $home_path . 'llms.txt';

		if( !is_writable( $home_path ) ) {
			return false;
		}

		if ( empty( $content ) ) {
			$content = $this->get_template_llms();
		}

		$site_url = get_site_url();
		$site_name = get_bloginfo( 'name' );

		$content = str_replace( '{SITE_URL}', $site_url, $content );
		$content = str_replace( '{SITE_NAME}', $site_name, $content );
		
		// Handle UTF-8 BOM for proper browser encoding detection
		$utf8_bom = "\xEF\xBB\xBF";
		if ( substr( $content, 0, 3 ) === $utf8_bom ) {
			$content = substr( $content, 3 );
		}
		
		$content = $utf8_bom . $content;
		
		if ( !empty( $content ) ) {
			$content = sanitize_textarea_field( wp_unslash( $content ) );
			$f = fopen( $llms_path, 'w+' );
			fwrite( $f, $content );
			fclose( $f );
		}

		return true;
	}

	function delete_llms_txt() {
		if ( ! function_exists( 'get_home_path' ) ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
		}
		$home_path = get_home_path();

		if ( ! is_writable( $home_path ) && ! empty( $_SERVER['DOCUMENT_ROOT'] ) ) {
			$home_path = $_SERVER['DOCUMENT_ROOT'] . DIRECTORY_SEPARATOR;
		}

		$llms_path = $home_path . 'llms.txt';

		if ( ! file_exists( $llms_path ) ) {
			return false;
		}

		if ( ! is_writable( $llms_path ) ) {
			return false;
		}

		return @unlink( $llms_path );
	}

	#endregion

	#region Performance Insights

	function get_speed_and_vitals( $post_id ) {
		$result = $this->insights_module->get_insights_for_post( $post_id );

		return $result;
	}

	function get_last_insights() {
		$last_insights = $this->insights_module->get_last_insights();
		if ( !is_array( $last_insights ) ) {
			return [];
		}

		return $last_insights;
	}

	#endregion

	#region Analytics

	function track_current_visit() {
		if ( !isset( $this->analytics_module ) ) {
			return;
		}

		// Only track single posts and pages
		if ( is_singular() ) {
			global $post;
			if ( $post && $post->ID ) {
				$this->analytics_module->track_visit( $post->ID );
			}
		}
	}

	#region AI Visibility delegators

	// AI Visibility is a Pro module (premium/aivisibility.php); it simply does not
	// exist in the free build, so this returns null there.
	function ai_visibility() {
		return ( $this->pro && isset( $this->pro->ai_visibility ) ) ? $this->pro->ai_visibility : null;
	}

	#endregion

	// TODO [2025]: Refactor to unified analytics provider interface
	function get_analytics_data( $args = array() ) {
		if ( !isset( $this->analytics_module ) ) {
			return array();
		}

		return $this->analytics_module->get_analytics_data( $args );
	}

	// TODO [2025]: Refactor to unified analytics provider interface
	function get_analytics_summary( $start_date = null, $end_date = null ) {
		if ( !isset( $this->analytics_module ) ) {
			return array();
		}

		return $this->analytics_module->get_analytics_summary( $start_date, $end_date );
	}

	function get_analytics_realtime_data() {
		if ( !isset( $this->analytics_module ) ) {
			return array();
		}

		return $this->analytics_module->get_realtime_data();
	}

	// TODO [2025]: Refactor to unified analytics provider interface
	function get_top_posts( $args = array() ) {
		if ( !isset( $this->analytics_module ) ) {
			return array();
		}

		return $this->analytics_module->get_top_posts( $args );
	}

	function get_ai_agents_summary( $start_date = null, $end_date = null ) {
		if ( !isset( $this->analytics_module ) ) {
			return array();
		}

		return $this->analytics_module->get_ai_agents_summary( $start_date, $end_date );
	}

	function get_ai_agent_details( $bot_name, $start_date = null, $end_date = null ) {
		if ( !isset( $this->analytics_module ) ) {
			return array();
		}

		return $this->analytics_module->get_ai_agent_details( $bot_name, $start_date, $end_date );
	}

	function get_ai_agents_by_post( $post_id, $days = 30 ) {
		if ( !isset( $this->analytics_module ) ) {
			return array(
				'openai' => 0,
				'anthropic' => 0,
				'google' => 0,
				'others' => 0
			);
		}

		return $this->analytics_module->get_ai_agents_by_post( $post_id, $days );
	}

	function get_ai_bots_totals_by_posts( $post_ids, $days = 30 ) {
		if ( !isset( $this->analytics_module ) ) {
			return array();
		}
		return $this->analytics_module->get_ai_bots_totals_by_posts( $post_ids, $days );
	}

	function query_bot_traffic( $args = array() ) {
		if ( !isset( $this->analytics_module ) ) {
			return array();
		}

		return $this->analytics_module->query_bot_traffic( $args );
	}

	function get_bots_by_type( $type ) {
		if ( !isset( $this->analytics_module ) ) {
			return array();
		}

		return $this->analytics_module->get_bots_by_type( $type );
	}

	function rank_posts_for_bots( $args = array() ) {
		if ( !isset( $this->analytics_module ) ) {
			return array();
		}

		return $this->analytics_module->rank_posts_for_bots( $args );
	}

	function get_bot_profile( $bot_name, $start_date = null, $end_date = null ) {
		if ( !isset( $this->analytics_module ) ) {
			return array();
		}

		return $this->analytics_module->get_bot_profile( $bot_name, $start_date, $end_date );
	}

	function compare_bot_periods( $args = array() ) {
		if ( !isset( $this->analytics_module ) ) {
			return array();
		}

		return $this->analytics_module->compare_bot_periods( $args );
	}

	function get_bot_mix( $args = array() ) {
		if ( !isset( $this->analytics_module ) ) {
			return array();
		}

		return $this->analytics_module->get_bot_mix( $args );
	}

	#endregion

	#region Google Analytics
	function get_google_analytics_state() {
		if ( !class_exists( 'Meow_MWSEO_Modules_GoogleAnalytics' ) ) {
			return [];
		}

		// Get property_id with fallback to first element of property_ids array
		$property_id = $this->get_option( 'google_analytics_property_id', '' );
		if ( empty( $property_id ) ) {
			$property_ids = $this->get_option( 'google_analytics_property_ids', [] );
			if ( !empty( $property_ids ) && is_array( $property_ids ) ) {
				$property_id = $property_ids[0];
				$this->update_option( 'google_analytics_property_id', $property_id );
			}
		}

		return [
			'redirect_url' => $this->get_google_redirect_url(),
			'property_id' => $property_id,
		];
	}


	function unlink_google_analytics() {
		if ( !isset( $this->googleanalytics_module ) ) {
			return false;
		}

		return $this->googleanalytics_module->unlink();
	}

	function get_is_authenticated() {
		if ( !isset( $this->googleanalytics_module ) ) {
			return false;
		}

		// Refresh the options
		$this->googleanalytics_module->init();

		return $this->googleanalytics_module->is_authenticated();
	}

	function get_google_auth_url() {
		if ( !isset( $this->googleanalytics_module ) ) {
			return '';
		}

		// Refresh the options 
		$this->googleanalytics_module->init();

		return $this->googleanalytics_module->get_auth_url();
	}

	function get_google_redirect_url() {
		if ( !isset( $this->googleanalytics_module ) ) {
			return '';
		}

		return $this->googleanalytics_module->get_redirect_url();
	}

	#endregion

	#region Google Search Console

	function get_google_search_console_state() {
		if ( !$this->pro || !$this->pro->search_console ) {
			return [];
		}
		$gsc = $this->pro->search_console;
		return [
			'redirect_url' => $gsc->get_redirect_url(),
			'property' => $gsc->get_property(),
			'tracked' => $gsc->get_tracked_properties(),
			'is_authenticated' => $gsc->is_authenticated(),
		];
	}

	function toggle_gsc_tracked_property( $property, $tracked ) {
		if ( !$this->pro || !$this->pro->search_console ) {
			return false;
		}
		return $this->pro->search_console->toggle_tracked_property( $property, $tracked );
	}

	function get_gsc_summary( $args = [] ) {
		if ( !$this->pro || !$this->pro->search_console ) return [];
		return $this->pro->search_console->get_summary( $args );
	}

	function get_gsc_timeseries( $args = [] ) {
		if ( !$this->pro || !$this->pro->search_console ) return [];
		return $this->pro->search_console->get_timeseries( $args );
	}

	function get_gsc_page_movers( $args = [] ) {
		if ( !$this->pro || !$this->pro->search_console ) return [];
		return $this->pro->search_console->get_page_movers( $args );
	}

	function get_gsc_quick_wins( $args = [] ) {
		if ( !$this->pro || !$this->pro->search_console ) return [];
		return $this->pro->search_console->get_quick_wins( $args );
	}

	function get_gsc_top_pages( $args = [] ) {
		if ( !$this->pro || !$this->pro->search_console ) return [];
		return $this->pro->search_console->get_top_pages( $args );
	}

	function get_gsc_top_queries( $args = [] ) {
		if ( !$this->pro || !$this->pro->search_console ) return [];
		return $this->pro->search_console->get_top_queries( $args );
	}

	function get_gsc_post_metrics_map( $args = [] ) {
		if ( !$this->pro || !$this->pro->search_console ) return [];
		return $this->pro->search_console->get_post_metrics_map( $args );
	}

	function estimate_gsc_quick_win_potential( $impressions, $position ) {
		if ( !$this->pro || !$this->pro->search_console ) return 0;
		return $this->pro->search_console->estimate_quick_win_potential( $impressions, $position );
	}

	function get_gsc_search_breakdown( $args = [] ) {
		if ( !$this->pro || !$this->pro->search_console ) return [ 'top_queries' => [], 'top_pages' => [] ];
		return $this->pro->search_console->get_search_breakdown( $args );
	}

	function get_gsc_pages_with_issues( $args = [] ) {
		if ( !$this->pro || !$this->pro->search_console ) return [];
		return $this->pro->search_console->get_pages_with_issues( $args );
	}

	function get_gsc_post_pulse( $post_id, $days = 28 ) {
		if ( !$this->pro || !$this->pro->search_console ) return null;
		return $this->pro->search_console->get_post_pulse( (int) $post_id, $days );
	}

	function get_gsc_auth_url() {
		if ( !$this->pro || !$this->pro->search_console ) {
			return '';
		}
		$this->pro->search_console->init();
		return $this->pro->search_console->get_auth_url();
	}

	function is_gsc_authenticated() {
		if ( !$this->pro || !$this->pro->search_console ) {
			return false;
		}
		$this->pro->search_console->init();
		return $this->pro->search_console->is_authenticated();
	}

	function unlink_gsc() {
		if ( !$this->pro || !$this->pro->search_console ) {
			return false;
		}
		return $this->pro->search_console->unlink();
	}

	function list_gsc_properties() {
		if ( !$this->pro || !$this->pro->search_console ) {
			return [];
		}
		$properties = $this->pro->search_console->list_properties();
		return is_array( $properties ) ? $properties : [];
	}

	function set_gsc_property( $property ) {
		if ( !$this->pro || !$this->pro->search_console ) {
			return false;
		}
		return $this->pro->search_console->set_property( $property );
	}

	#endregion

	// TODO [2025]: Refactor to unified analytics provider interface
	function get_google_analytics_data( $args = array() ) {
		if ( !isset( $this->googleanalytics_module ) ) {
			return array();
		}

		return $this->googleanalytics_module->get_analytics_data( $args );
	}

	function get_post_analytics( $post_id, $page_path, $start_date = null, $end_date = null ) {
		if ( !isset( $this->analytics_module ) ) {
			return array();
		}

		return $this->analytics_module->get_post_analytics( $post_id, $page_path, $start_date, $end_date );
	}

	function get_posts_visitor_series( $post_ids, $days = 30 ) {
		if ( !isset( $this->analytics_module ) ) {
			return array();
		}
		return $this->analytics_module->get_posts_visitor_series( $post_ids, $days );
	}

	function get_posts_visitor_totals( $post_ids, $days = 30 ) {
		if ( !isset( $this->analytics_module ) ) {
			return array();
		}
		return $this->analytics_module->get_posts_visitor_totals( $post_ids, $days );
	}

	function get_google_analytics_pages_daily( $start_date = null, $end_date = null, $paths = null ) {
		if ( !isset( $this->googleanalytics_module ) ) {
			return array();
		}
		$this->googleanalytics_module->init();
		return $this->googleanalytics_module->get_pages_daily_visitors( $start_date, $end_date, $paths );
	}

	function get_google_analytics_pages_totals( $start_date = null, $end_date = null ) {
		if ( !isset( $this->googleanalytics_module ) ) {
			return array();
		}
		$this->googleanalytics_module->init();
		return $this->googleanalytics_module->get_pages_total_visitors( $start_date, $end_date );
	}

	// TODO [2025]: Refactor to unified analytics provider interface
	function get_google_analytics_summary( $start_date = null, $end_date = null ) {
		if ( !isset( $this->googleanalytics_module ) ) {
			return array();
		}

		return $this->googleanalytics_module->get_analytics_summary( $start_date, $end_date );
	}

	function get_google_analytics_post_analytics( $page_path, $start_date = null, $end_date = null ) {
		if ( !isset( $this->googleanalytics_module ) ) {
			return array();
		}

		return $this->googleanalytics_module->get_post_analytics( $page_path, $start_date, $end_date );
	}

	// TODO [2025]: Refactor to unified analytics provider interface
	function get_google_analytics_top_posts( $args = array() ) {
		if ( !isset( $this->googleanalytics_module ) ) {
			return array();
		}

		return $this->googleanalytics_module->get_top_posts( $args );
	}

	// TODO [2025]: Refactor to unified analytics provider interface
	function get_google_analytics_realtime_data() {
		if ( !isset( $this->googleanalytics_module ) ) {
			return array();
		}

		return $this->googleanalytics_module->get_realtime_data();
	}

	// Plausible Analytics

	// TODO [2025]: Refactor to unified analytics provider interface
	function get_plausible_analytics_data( $args = array() ) {
		if ( !isset( $this->plausibleanalytics_module ) ) {
			return array();
		}

		return $this->plausibleanalytics_module->get_data( $args );
	}

	// TODO [2025]: Refactor to unified analytics provider interface
	function get_plausible_analytics_summary( $start_date = null, $end_date = null ) {
		if ( !isset( $this->plausibleanalytics_module ) ) {
			return array();
		}

		return $this->plausibleanalytics_module->get_summary( $start_date, $end_date );
	}

	function get_plausible_analytics_post_analytics( $page_path, $start_date = null, $end_date = null ) {
		if ( !isset( $this->plausibleanalytics_module ) ) {
			return array();
		}

		return $this->plausibleanalytics_module->get_post_analytics( $page_path, $start_date, $end_date );
	}

	function get_plausible_analytics_realtime_data() {
		if ( !isset( $this->plausibleanalytics_module ) ) {
			return array();
		}

		return $this->plausibleanalytics_module->get_realtime_data();
	}

	// TODO [2025]: Refactor to unified analytics provider interface
	function get_plausible_analytics_top_posts( $start_date = null, $end_date = null, $limit = 10 ) {
		if ( !isset( $this->plausibleanalytics_module ) ) {
			return array();
		}

		return $this->plausibleanalytics_module->get_top_posts( $start_date, $end_date, $limit );
	}

	// Matomo Analytics

	function get_matomo_analytics_data( $args = array() ) {
		if ( !isset( $this->matomoanalytics_module ) ) {
			return array();
		}

		return $this->matomoanalytics_module->get_data( $args );
	}

	function get_matomo_analytics_summary( $start_date = null, $end_date = null ) {
		if ( !isset( $this->matomoanalytics_module ) ) {
			return array();
		}

		return $this->matomoanalytics_module->get_summary( $start_date, $end_date );
	}

	function get_matomo_analytics_post_analytics( $page_path, $start_date = null, $end_date = null ) {
		if ( !isset( $this->matomoanalytics_module ) ) {
			return array();
		}

		return $this->matomoanalytics_module->get_post_analytics( $page_path, $start_date, $end_date );
	}

	function get_matomo_analytics_top_posts( $args = array() ) {
		if ( !isset( $this->matomoanalytics_module ) ) {
			return array();
		}

		return $this->matomoanalytics_module->get_top_posts( $args );
	}

	function get_matomo_analytics_realtime_data() {
		if ( !isset( $this->matomoanalytics_module ) ) {
			return array();
		}

		return $this->matomoanalytics_module->get_realtime_data();
	}

	// Matomo exposes a real per-day, per-page report, so unlike Plausible it can feed
	// the Content SEO sparklines and per-post totals.
	function get_matomo_analytics_pages_daily( $start_date = null, $end_date = null, $paths = null ) {
		if ( !isset( $this->matomoanalytics_module ) ) {
			return array();
		}

		return $this->matomoanalytics_module->get_pages_daily( $start_date, $end_date, $paths );
	}

	function get_matomo_analytics_pages_totals( $start_date = null, $end_date = null ) {
		if ( !isset( $this->matomoanalytics_module ) ) {
			return array();
		}

		return $this->matomoanalytics_module->get_pages_totals( $start_date, $end_date );
	}

	#endregion

	#region Daily Insights

	// Daily Insights used to be generated only when someone clicked Refresh on the dashboard, so they
	// silently went months stale (164 days on meowapps.com, 10-2026). A real daily cron now keeps them fresh.
	function maybe_schedule_daily_insight() {
		add_action( 'mwseo_daily_insight', array( $this, 'run_daily_insight' ) );
		$enabled = $this->get_option( 'content_seo', false ) && $this->get_option( 'daily_insights', true );
		$next = wp_next_scheduled( 'mwseo_daily_insight' );
		if ( $enabled && !$next ) {
			wp_schedule_event( time() + HOUR_IN_SECONDS, 'daily', 'mwseo_daily_insight' );
		}
		else if ( !$enabled && $next ) {
			wp_unschedule_event( $next, 'mwseo_daily_insight' );
		}
	}

	function run_daily_insight() {
		if ( !class_exists( 'Meow_MWAI_Core' ) ) {
			return;
		}
		// Skip if a fresh one exists already (someone clicked Refresh today).
		$generated_at = $this->get_option( 'daily_insight_generated_at', null );
		if ( $generated_at && strtotime( get_gmt_from_date( $generated_at ) . ' UTC' ) > time() - 20 * HOUR_IN_SECONDS ) {
			return;
		}
		$result = $this->generate_daily_insight();
		if ( is_wp_error( $result ) && $result->get_error_code() !== 'no_posts' ) {
			$this->log( '❌ Daily Insight (cron) error: ' . $result->get_error_message() );
		}
	}

	/**
	 * Asks AI Engine for 2-3 tips about the 20 lowest-scoring posts, stores them, and returns
	 * [ text, generated_at, generated_at_ts ] or a WP_Error. Used by the cron and by Refresh.
	 */
	function generate_daily_insight() {
		if ( !class_exists( 'Meow_MWAI_Core' ) ) {
			return new WP_Error( 'ai_engine_unavailable', 'AI Engine is not available.', 503 );
		}
		try {
			global $mwai;

			// Get the 20 posts with worst scores
			$args = array(
				'post_type' => $this->get_option( 'select_post_types', ['post'] ),
				'posts_per_page' => 20,
				'orderby' => 'meta_value_num',
				'order' => 'ASC',
				'meta_key' => '_mwseo_score',
				'meta_query' => array(
					array(
						'key' => '_mwseo_score',
						'compare' => 'EXISTS'
					),
					array(
						'key' => '_mwseo_score',
						'value' => 0,
						'compare' => '>=',
						'type' => 'NUMERIC'
					)
				)
			);

			$posts = get_posts( $args );

			if ( empty( $posts ) ) {
				return new WP_Error( 'no_posts', 'No analyzed posts found.', 404 );
			}

			// Prime meta cache
			$post_ids = wp_list_pluck( $posts, 'ID' );
			update_meta_cache( 'post', $post_ids );

			// Build data for AI
			$posts_data = [];
			foreach ( $posts as $post ) {
				$score = get_post_meta( $post->ID, '_mwseo_score', true );
				$codes = get_post_meta( $post->ID, '_mwseo_codes', true );
				// Not get_edit_post_link(): it returns null without a logged-in editor, which is always the case in cron.
				$edit_link = admin_url( 'post.php?post=' . $post->ID . '&action=edit' );

				// Format issue codes to be human-readable
				$issues = [];
				if ( is_array( $codes ) && !empty( $codes ) ) {
					foreach ( $codes as $code ) {
						// Convert snake_case to Title Case
						$issues[] = ucwords( str_replace( '_', ' ', $code ) );
					}
				}

				$posts_data[] = [
					'title' => $post->post_title,
					'score' => $score,
					'issues' => $issues,
					'edit_link' => $edit_link
				];
			}

			// Create AI prompt
			$prompt = "You are an SEO consultant. Below are the 20 posts with the lowest SEO scores from a website. Each post has a score (0-100), a list of SEO issues, and an edit link.\n\n";

			foreach ( $posts_data as $idx => $data ) {
				$prompt .= sprintf(
					"Post %d: \"%s\" (Score: %d)\n",
					$idx + 1,
					$data['title'],
					$data['score']
				);
				if ( !empty( $data['issues'] ) ) {
					$prompt .= "Issues: " . implode( ', ', $data['issues'] ) . "\n";
				}
				$prompt .= "Edit link: " . $data['edit_link'] . "\n\n";
			}

			$prompt .= "Based on these posts, write TWO short paragraphs:\n\n";
			$prompt .= "Paragraph 1: Start with a friendly greeting (Hi, Hello, Hey). Address the user directly (you, your). Identify the 2-3 main SEO issues affecting these posts and quick fixes. Be specific and actionable. Keep it under 3 sentences.\n\n";
			$prompt .= "Paragraph 2: Give 3 specific examples using short references. For each, create a markdown link using a brief topic/keyword from the title (2-4 words max), not the full title. Format: 'the posts about [topic](edit_link), [topic](edit_link), and [topic](edit_link)'. Keep it under 2 sentences.\n\n";
			$prompt .= "Use markdown for **bold** emphasis on issue names. Keep the tone friendly, personal, and encouraging. Address the user directly throughout. Total length: 5 sentences maximum across both paragraphs.";

			// Get AI response
			$insight_text = $mwai->simpleTextQuery( $prompt, [ 'scope' => 'seo' ] );

			$now = current_time( 'mysql' );
			$this->update_option( 'daily_insight_text', $insight_text );
			$this->update_option( 'daily_insight_generated_at', $now );

			return [
				'text' => $insight_text,
				'generated_at' => $now,
				'generated_at_ts' => strtotime( get_gmt_from_date( $now ) . ' UTC' )
			];
		}
		catch ( Exception $e ) {
			$this->log( '❌ Daily Insight error: ' . $e->getMessage() );
			return new WP_Error( 'generation_failed', $e->getMessage(), 500 );
		}
	}

	#endregion
}
