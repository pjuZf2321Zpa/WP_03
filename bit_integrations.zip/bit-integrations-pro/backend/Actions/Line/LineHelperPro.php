<?php

namespace BitApps\IntegrationsPro\Actions\Line;

class LineHelperPro
{
    public static function sendReplyMessage($defaultValue, $data, $header, $apiEndPoint)
    {
        $httpHelperClass = bit_integrations_get_class('Core\\Util\\HttpHelper');

        $response = $httpHelperClass::post($apiEndPoint . '/message/reply', $data, $header);

        return $response->sentMessages[0]->quoteToken ? __('Replied message successfully', 'bit-integrations-pro') : $response->message;
    }

    public static function sendBroadcastMessage($defaultValue, $data, $header, $apiEndPoint)
    {
        $httpHelperClass = bit_integrations_get_class('Core\\Util\\HttpHelper');

        $response = $httpHelperClass::post($apiEndPoint . '/message/broadcast', $data, $header);

        return empty((array) $response) ? __('Broadcast messages sended successfully', 'bit-integrations-pro') : 'Failed';
    }
}
