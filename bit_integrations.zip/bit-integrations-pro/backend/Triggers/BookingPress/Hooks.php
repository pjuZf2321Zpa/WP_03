<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Core\Util\Hooks;
use BitApps\IntegrationsPro\Triggers\BookingPress\BookingPressController;

Hooks::add('bookingpress_after_insert_appointment', [BookingPressController::class, 'handleAppointmentBooked'], 10, 1);
Hooks::add('bookingpress_after_cancel_appointment', [BookingPressController::class, 'handleAppointmentCancelled'], 10, 1);
Hooks::add('bookingpress_after_change_appointment_status', [BookingPressController::class, 'handleAppointmentStatusChanged'], 10, 2);
Hooks::add('bookingpress_after_rescheduled_appointment', [BookingPressController::class, 'handleAppointmentRescheduled'], 10, 1);
Hooks::add('bookingpress_after_update_appointment', [BookingPressController::class, 'handleAppointmentUpdated'], 10, 1);
Hooks::add('bookingpress_after_create_customer', [BookingPressController::class, 'handleCustomerCreated'], 10, 1);
Hooks::add('bookingpress_after_create_new_customer', [BookingPressController::class, 'handleCustomerCreated'], 10, 1);
Hooks::add('bookingpress_after_update_customer', [BookingPressController::class, 'handleCustomerUpdated'], 10, 1);
