<?php

/**
 * @author WP Cloud Plugins
 * @copyright Copyright (c) 2023, WP Cloud Plugins
 *
 * @since       2.0
 * @see https://www.wpcloudplugins.com
 */

namespace TheLion\UseyourDrive;

defined('ABSPATH') || exit;

class Accounts
{
    /**
     * The single instance of the class.
     *
     * @var Accounts
     */
    protected static $_instance;

    /**
     * $_accounts contains all the accounts that are linked with the plugin.
     *
     * @var \TheLion\UseyourDrive\Account[]
     */
    private $_accounts = [];

    public function __construct()
    {
        $this->_init_accounts();
    }

    /**
     * Accounts Instance.
     *
     * Ensures only one instance is loaded or can be loaded.
     *
     * @return Accounts - Accounts instance
     *
     * @static
     */
    public static function instance()
    {
        if (is_null(self::$_instance)) {
            self::$_instance = new self();
        }

        return self::$_instance;
    }

    /**
     * @return bool
     */
    public function has_accounts()
    {
        return count($this->_accounts) > 0;
    }

    /**
     * @return \TheLion\UseyourDrive\Account[]
     */
    public function list_accounts()
    {
        return $this->_accounts;
    }

    /**
     * @return null|Account
     */
    public function get_primary_account()
    {
        if (0 === count($this->_accounts)) {
            return null;
        }

        $first_account = reset($this->_accounts);

        if (false === $first_account->get_authorization()->has_access_token()) {
            return null;
        }

        return $first_account;
    }

    /**
     * @param string $id
     *
     * @return null|Account
     */
    public function get_account_by_id($id)
    {
        if (empty($id)) {
            return null;
        }

        // Redirect to uuid function in case an uuid is provided
        if (false !== strpos($id, 'wpcp-')) {
            return $this->get_account_by_uuid($id);
        }

        if (false === isset($this->_accounts[(string) $id])) {
            return null;
        }

        return $this->_accounts[(string) $id];
    }

    /**
     * @param string $uuid
     *
     * @return null|Account
     */
    public function get_account_by_uuid($uuid)
    {
        foreach ($this->_accounts as $account) {
            if ($account->get_uuid() === $uuid) {
                return $account;
            }
        }

        return null;
    }

    /**
     * Convert ID to UUID.
     *
     * @param string $id
     */
    public function account_id_to_uuid($id)
    {
        $account = $this->get_account_by_id($id);

        if (!empty($account)) {
            return $account->get_uuid();
        }

        return null;
    }

    /**
     * Convert UUID to ID.
     *
     * @param string $uuid
     */
    public function account_uuid_to_id($uuid)
    {
        $account = $this->get_account_by_uuid($uuid);

        if (!empty($account)) {
            return $account->get_id();
        }

        return null;
    }

    /**
     * @param mixed $email
     *
     * @return null|Account
     */
    public function get_account_by_email($email)
    {
        foreach ($this->_accounts as $account) {
            if ($account->get_email() === $email) {
                return $account;
            }
        }

        return null;
    }

    /**
     * @return $this
     */
    public function add_account(Account $account)
    {
        Helpers::log(isset($this->_accounts[$account->get_id()]) ? 'Existing account updated.' : 'New account added.', 'Accounts', ['account_id' => $account->get_id(), 'scopes' => array_values((array) $account->get_scopes())], __LINE__);

        $this->_accounts[$account->get_id()] = $account;

        $this->save();

        return $this;
    }

    /**
     * @param string $account_id
     *
     * @return $this
     */
    public function remove_account($account_id, $is_used_by_other_sites = null)
    {
        $account = $this->get_account_by_id($account_id);

        if (null === $account) {
            return $this;
        }

        if (null === $is_used_by_other_sites && false === USEYOURDRIVE_CACHE_SITE_FOLDERS) {
            $is_used_by_other_sites = self::is_account_used_by_other_sites($account->get_id());
        }

        // The token file is shared by all sites in the network that link the same account
        if (USEYOURDRIVE_CACHE_SITE_FOLDERS || false === $is_used_by_other_sites) {
            $account->get_authorization()->remove_token();
        }

        unset($this->_accounts[$account->get_id()]);

        $this->save();

        return $this;
    }

    public function save()
    {
        if (Core::is_network_authorized()) {
            Settings::save_for_network('accounts', $this->_accounts);
        } else {
            Settings::save('accounts', $this->_accounts);
        }
    }

    /**
     * Check if other sites in the network still have the account linked.
     * Those sites share the same authorization, so it must not be revoked or removed.
     *
     * Archived, spam and deleted sites, and sites where the plugin isn't active, are ignored.
     * When such a site is used again later, the account needs to be authorized again on that site.
     *
     * @param string $account_id
     *
     * @return bool
     */
    public static function is_account_used_by_other_sites($account_id)
    {
        // Network authorized accounts are managed via a single account list
        if (false === is_multisite() || Core::is_network_authorized()) {
            return false;
        }

        global $wpdb;

        if (!function_exists('is_plugin_active_for_network')) {
            require_once ABSPATH.'/wp-admin/includes/plugin.php';
        }

        $is_network_active = is_plugin_active_for_network(USEYOURDRIVE_SLUG);
        $account_id = (string) $account_id;

        // Only sites that are in use. Archived, spam and deleted sites are ignored
        $blog_ids = get_sites([
            'fields' => 'ids',
            'number' => 0,
            'site__not_in' => [get_current_blog_id()],
            'archived' => 0,
            'spam' => 0,
            'deleted' => 0,
        ]);

        // Read the options directly instead of switching to every site, which would load all autoloaded options of each site
        foreach ($blog_ids as $blog_id) {
            $options_table = $wpdb->get_blog_prefix($blog_id).'options';
            $site_settings = $wpdb->get_var($wpdb->prepare("SELECT option_value FROM {$options_table} WHERE option_name = %s LIMIT 1", Settings::$db_key));

            // Quick check before unserializing the settings
            if (empty($site_settings) || false === strpos($site_settings, $account_id)) {
                continue;
            }

            $settings = maybe_unserialize($site_settings);

            if (!is_array($settings) || empty($settings['accounts']) || !is_array($settings['accounts']) || !isset($settings['accounts'][$account_id])) {
                continue;
            }

            // Sites where the plugin is deactivated don't use the account
            if (false === $is_network_active) {
                $active_plugins = $wpdb->get_var("SELECT option_value FROM {$options_table} WHERE option_name = 'active_plugins' LIMIT 1");

                if (!in_array(USEYOURDRIVE_SLUG, (array) maybe_unserialize((string) $active_plugins), true)) {
                    continue;
                }
            }

            return true;
        }

        return false;
    }

    public static function revoke_authorizations()
    {
        require_once ABSPATH.'wp-admin/includes/class-wp-filesystem-base.php';

        require_once ABSPATH.'wp-admin/includes/class-wp-filesystem-direct.php';

        $wp_file_system = new \WP_Filesystem_Direct(false);

        foreach ((Helpers::is_safe_cache_folder(USEYOURDRIVE_CACHEDIR) ? new \RecursiveIteratorIterator(new \RecursiveDirectoryIterator(USEYOURDRIVE_CACHEDIR, \FilesystemIterator::SKIP_DOTS), \RecursiveIteratorIterator::CHILD_FIRST) : []) as $path) {
            if ('.htaccess' === $path->getFilename()) {
                continue;
            }

            try {
                $wp_file_system->delete($path->getPathname(), true);
            } catch (\Exception $ex) {
                continue;
            }
        }

        Processor::reset_complete_cache();
    }

    private function _init_accounts()
    {
        $this->_accounts = Settings::get('accounts', []);
    }
}
