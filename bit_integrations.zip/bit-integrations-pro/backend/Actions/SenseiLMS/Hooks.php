<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Actions\SenseiLMS\SenseiLMSProHelper;
use BitApps\IntegrationsPro\Config;
use BitApps\IntegrationsPro\Core\Util\Hooks;

Hooks::filter(Config::withFreePrefix('sensei_lms_enroll_user_in_course'), [SenseiLMSProHelper::class, 'enrollUserInCourse'], 10, 3);
Hooks::filter(Config::withFreePrefix('sensei_lms_withdraw_user_from_course'), [SenseiLMSProHelper::class, 'withdrawUserFromCourse'], 10, 3);
Hooks::filter(Config::withFreePrefix('sensei_lms_start_course_for_user'), [SenseiLMSProHelper::class, 'startCourseForUser'], 10, 3);
Hooks::filter(Config::withFreePrefix('sensei_lms_complete_course_for_user'), [SenseiLMSProHelper::class, 'completeCourseForUser'], 10, 3);
Hooks::filter(Config::withFreePrefix('sensei_lms_reset_course_for_user'), [SenseiLMSProHelper::class, 'resetCourseForUser'], 10, 3);
Hooks::filter(Config::withFreePrefix('sensei_lms_start_lesson_for_user'), [SenseiLMSProHelper::class, 'startLessonForUser'], 10, 3);
Hooks::filter(Config::withFreePrefix('sensei_lms_update_lesson_status'), [SenseiLMSProHelper::class, 'updateLessonStatus'], 10, 3);
Hooks::filter(Config::withFreePrefix('sensei_lms_reset_lesson_for_user'), [SenseiLMSProHelper::class, 'resetLessonForUser'], 10, 3);
Hooks::filter(Config::withFreePrefix('sensei_lms_grade_quiz'), [SenseiLMSProHelper::class, 'gradeQuiz'], 10, 3);
Hooks::filter(Config::withFreePrefix('sensei_lms_create_course'), [SenseiLMSProHelper::class, 'createCourse'], 10, 3);
Hooks::filter(Config::withFreePrefix('sensei_lms_create_lesson'), [SenseiLMSProHelper::class, 'createLesson'], 10, 3);
Hooks::filter(Config::withFreePrefix('sensei_lms_create_certificate'), [SenseiLMSProHelper::class, 'createCertificate'], 10, 3);
