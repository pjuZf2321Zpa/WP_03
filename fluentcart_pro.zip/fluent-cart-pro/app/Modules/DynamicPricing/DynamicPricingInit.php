<?php

namespace FluentCartPro\App\Modules\DynamicPricing;

use FluentCart\Api\ModuleSettings;
use FluentCartPro\App\Modules\DynamicPricing\Conditions\ConditionRegistry;
use FluentCartPro\App\Modules\DynamicPricing\Conditions\Options\CouponOptions;
use FluentCartPro\App\Modules\DynamicPricing\Conditions\Options\CustomerOptions;
use FluentCartPro\App\Modules\DynamicPricing\Conditions\Options\PaymentMethodOptions;
use FluentCartPro\App\Modules\DynamicPricing\Conditions\Options\ProductOptions;
use FluentCartPro\App\Modules\DynamicPricing\Conditions\Options\UserRoleOptions;
use FluentCartPro\App\Modules\DynamicPricing\Database\DBMigrator;
use FluentCartPro\App\Modules\DynamicPricing\Pricing\AppliedRuleRecorder;
use FluentCartPro\App\Modules\DynamicPricing\Pricing\CartAdjustmentApplier;
use FluentCartPro\App\Modules\DynamicPricing\Pricing\DynamicDiscountPersister;
use FluentCartPro\App\Modules\DynamicPricing\Pricing\RenewalDiscountApplier;

class DynamicPricingInit
{
    public function register($app)
    {
        add_filter('fluent_cart/module_setting/fields', function ($fields, $args) {
            $fields['dynamic_pricing'] = [
                'title'       => __('Dynamic Pricing', 'fluent-cart-pro'),
                'description' => __('Automatically discount or add fees to checkout based on conditions you set.', 'fluent-cart-pro'),
                'type'        => 'component',
                'component'   => 'ModuleSettings',
            ];
            return $fields;
        }, 10, 2);

        add_filter('fluent_cart/module_setting/default_values', function ($values, $args) {
            if (empty($values['dynamic_pricing']['active'])) {
                $values['dynamic_pricing']['active'] = 'no';
            }
            return $values;
        }, 10, 2);

        add_filter('fluent_cart/admin_app_data', [$this, 'addConditionAttributes']);

        add_action('fluent_cart/module/activated/dynamic_pricing', [$this, 'maybeMigrateDB']);

        /*
         * The pricing rule tables are created when the module is activated, so
         * while it is off they do not exist yet. Registering the routes anyway
         * would let a direct API call query a missing table, so they are only
         * added once the module is on — same gating AdvancedInventory uses.
         *
         * Everything registered above this line must stay unconditional: the
         * settings field is how the module gets switched on, and the activation
         * hook has to already be listening when that happens.
         */
        if (!ModuleSettings::isActive('dynamic_pricing')) {
            return;
        }

        $app->router->group(function ($router) {
            require_once __DIR__ . '/Http/pricing-rules-api.php';
        });

        
        (new ProductOptions())->register();
        (new CouponOptions())->register();
        (new CustomerOptions())->register();
        (new UserRoleOptions())->register();
        (new PaymentMethodOptions())->register();

        (new CartAdjustmentApplier())->register();
        (new DynamicDiscountPersister())->register();
        (new AppliedRuleRecorder())->register();
        (new RenewalDiscountApplier())->register();
    }

    /**
     * Publishes the condition attribute registry to the admin app, so the rule
     * editor renders its attribute and operator dropdowns from PHP rather than
     * a hardcoded JS copy.
     *
     * Skipped entirely while the module is off — the editor is unreachable in
     * that state anyway, and the frontend falls back to an empty registry.
     *
     * @param array $data
     * @return array
     */
    public function addConditionAttributes($data)
    {
        if (!ModuleSettings::isActive('dynamic_pricing')) {
            return $data;
        }

        $data['dynamic_pricing_condition_attributes'] = ConditionRegistry::onlySupportedKeys();

        return $data;
    }

    /**
     * No isActive() check here — the hook only fires on a genuine 'no' -> 'yes'
     * transition, so its firing is itself the confirmation this should run.
     * The re-check for the periodic/full-migrate path lives in ProDBMigrator,
     * where isActive() is safe to call (a separate request from the save).
     */
    public function maybeMigrateDB()
    {
        (new DBMigrator())->migrate();
    }
}
