<?php

declare(strict_types=1);

namespace FluentCartPro\App\Services\Invoice;

if (!defined('ABSPATH')) {
    exit;
}

use FluentCart\App\Models\Order;
use FluentCartPro\App\Services\Invoice\Calculation\InvoiceCalculationEngine;
use FluentCartPro\App\Services\Invoice\Mapper\En16931InvoiceMapper;
use FluentCartPro\App\Services\Invoice\Profile\InvoiceProfileInterface;
use FluentCartPro\App\Services\Invoice\Profile\ZugferdEn16931Profile;
use FluentCartPro\App\Services\Invoice\Serializer\CiiSerializer;
use FluentCartPro\App\Services\Invoice\Serializer\InvoiceSerializerInterface;

/**
 * Pipeline: mapper → engine → profile validate → serializer (by profile->getSyntax()).
 */
final class En16931ExportService
{
    private En16931InvoiceMapper $mapper;

    private InvoiceCalculationEngine $engine;

    private InvoiceSerializerInterface $ciiSerializer;

    public function __construct(
        ?En16931InvoiceMapper $mapper = null,
        ?InvoiceCalculationEngine $engine = null,
        ?InvoiceSerializerInterface $ciiSerializer = null
    ) {
        $this->mapper        = $mapper ?? new En16931InvoiceMapper();
        $this->engine        = $engine ?? new InvoiceCalculationEngine();
        $this->ciiSerializer = $ciiSerializer ?? new CiiSerializer();
    }

    /**
     * Generate EN 16931 XML from a FluentCart Order.
     *
     * @param Order $order Order with relations loaded
     * @param InvoiceProfileInterface|null $profile
     * @return string XML
     */
    public function generateXml(Order $order, ?InvoiceProfileInterface $profile = null): string
    {
        $profile = $profile ?? new ZugferdEn16931Profile();

        $dto    = $this->mapper->map($order);
        $totals = $this->engine->calculate($dto);
        $profile->validate($dto, $totals);

        $serializer = $this->selectSerializer($profile);
        return $serializer->serialize($dto, $totals, $profile);
    }

    private function selectSerializer(InvoiceProfileInterface $profile): InvoiceSerializerInterface
    {
        $syntax = $profile->getSyntax();
        if ($syntax === 'UBL') {
            throw new \RuntimeException(__('UBL serializer not yet implemented.', 'fluent-cart-pro'));
        }
        return $this->ciiSerializer;
    }
}
