<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Core\Util\Hooks;
use BitApps\IntegrationsPro\Triggers\Bricksforge\BricksforgeController;

Hooks::add('bricksforge/pro_forms/after_submit', [BricksforgeController::class, 'handleBricksforgeSubmit'], 10, PHP_INT_MAX);
