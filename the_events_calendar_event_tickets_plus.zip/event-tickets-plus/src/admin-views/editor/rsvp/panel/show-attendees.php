<?php
/**
 * RSVP V2 Show Attendees toggle template.
 *
 * @since 6.11.0
 *
 * @version 6.11.0
 *
 * @var Tribe__Tickets_Plus__Admin__Views $this           [Global] Template object.
 * @var int                               $post_id        The post ID.
 * @var int                               $rsvp_id        The RSVP ticket ID.
 * @var bool                              $show_attendees Whether to show attendees list.
 */

defined( 'ABSPATH' ) || exit;

$pto = get_post_type_object( get_post_type( $post_id ) );

$show_attendees_label = sprintf(
	/* translators: %s is the post type label */
	__( 'Show attendees list on %s page', 'event-tickets-plus' ),
	$pto->labels->singular_name
);

/** @var Tribe__Tickets__Admin__Views $admin_views */
$admin_views = tribe( 'tickets.admin.views' );

$admin_views->template(
	[ 'components', 'switch-field' ],
	[
		'id'          => 'rsvp_show_attendees',
		'name'        => 'rsvp_show_attendees',
		'label'       => esc_html( $show_attendees_label ),
		'description' => esc_html__( 'Show a list of attendees, filtered by those who opt out during registration.', 'event-tickets-plus' ),
		'tooltip'     => '',
		'value'       => tribe_is_truthy( $show_attendees ),
	]
);
