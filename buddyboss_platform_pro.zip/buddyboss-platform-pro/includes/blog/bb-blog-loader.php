<?php
/**
 * BuddyBoss Pro Blog Loader.
 *
 * @package BuddyBossPro
 *
 * @since 3.1.0
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

/**
 * Set up the bb blog class.
 *
 * @since 3.1.0
 */
function bb_register_blog() {
	bb_platform_pro()->blog = BB_Blog::instance();
}
add_action( 'bp_setup_components', 'bb_register_blog' );

/**
 * Register the shared blog frontend stylesheet.
 *
 * Both the bookmarks and subscriptions frontends render the same
 * `assets/css/blog.css`. Registering it once under a single shared handle
 * (`bb-blog-pro`) — rather than each feature enqueuing the same file under a
 * distinct handle — keeps a post where both features are active from emitting
 * two identical `<link>` tags. Each feature's enqueue path calls
 * `wp_enqueue_style( 'bb-blog-pro' )` against this handle, so the CSS still
 * loads whenever either feature enqueues. Runs at priority 5 so the handle is
 * registered before the feature enqueue callbacks fire at the default priority.
 *
 * @since 3.1.0
 *
 * @return void
 */
function bb_blog_pro_register_frontend_style() {
	if ( ! function_exists( 'bb_blog_pro_url' ) ) {
		return;
	}

	wp_register_style(
		'bb-blog-pro',
		bb_blog_pro_url( 'assets/css/blog.css' ),
		array(),
		bb_platform_pro()->version
	);
}
add_action( 'wp_enqueue_scripts', 'bb_blog_pro_register_frontend_style', 5 );

// Clear the bookmark catch-up flag whenever Pro is deactivated, so the App-sync
// runs a reconcile after the plugin is activated again — bookmarks the App
// recorded while Pro was off then reach the web store without the admin having
// to re-save the bookmarking setting. Registered against Pro's main file (not
// this one) so the deactivate hook name matches the plugin WordPress deactivates.
if ( defined( 'BB_PLATFORM_PRO_PLUGIN_DIR' ) ) {
	register_deactivation_hook(
		trailingslashit( constant( 'BB_PLATFORM_PRO_PLUGIN_DIR' ) ) . 'buddyboss-platform-pro.php',
		array( 'BB_Blog_Bookmarks_App_Sync', 'on_pro_deactivated' )
	);
}
