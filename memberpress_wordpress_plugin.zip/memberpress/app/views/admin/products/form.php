<?php
if (!defined('ABSPATH')) {
    die('You are not allowed to call this page directly.');
}
  $mepr_options = MeprOptions::fetch();
?>

<div id="mepr-products-form" class="inside">
  <p>
    <strong>
        <?php
        echo esc_html(
            sprintf(
                // Translators: %s: currency symbol.
                __('Price (%s):', 'memberpress'),
                $mepr_options->currency_symbol
            )
        );
        ?>
    </strong>
  </p>
  <p>
    <input name="<?php echo esc_attr(MeprProduct::$price_str); ?>" id="<?php echo esc_attr(MeprProduct::$price_str); ?>" type="text" value="<?php echo esc_attr(MeprUtils::format_currency_float($product->price)); ?>" />
  </p>
  <div id="mepr-billing-type-row">
    <p>
      <strong><?php esc_html_e('Billing Type:', 'memberpress'); ?></strong>
    </p>
    <p>
      <select id="mepr-product-billing-type">
        <option value="recurring"<?php echo (($product->period_type !== 'lifetime') ? ' selected="selected"' : ''); ?>><?php esc_html_e('Recurring', 'memberpress'); ?></option>
        <option value="single"<?php echo (($product->period_type === 'lifetime') ? ' selected="selected"' : ''); ?>><?php esc_html_e('One-Time', 'memberpress'); ?></option>
      </select>
    </p>
  </div>
  <?php
    // Suggests switching to the Digital product type — a cart feature — so only when the cart is on.
    $_mepr_show_nudge = MeprOptions::cart_enabled()
        && $product->effective_type() === MeprProduct::TYPE_MEMBERSHIP
        && $product->period_type === 'lifetime'
        && (float) $product->price > 0.00;
    ?>
  <div id="mepr-one-time-membership-nudge"<?php echo $_mepr_show_nudge ? '' : ' class="mepr-hidden"'; ?> style="background:#f0f6fc;border-left:4px solid #2271b1;padding:8px 12px;margin:8px 0;">
    <p><?php esc_html_e('This product is configured as a membership but uses a one-time payment. Consider switching the Product Type to "Digital" — digital products are designed for one-time purchases and give the same lifetime access.', 'memberpress'); ?></p>
  </div>

  <input type="hidden"
         id="<?php echo esc_attr(MeprProduct::$period_str); ?>"
         name="<?php echo esc_attr(MeprProduct::$period_str); ?>"
         value="<?php echo esc_attr($product->period); ?>">
  <input type="hidden"
         id="<?php echo esc_attr(MeprProduct::$period_type_str); ?>"
         name="<?php echo esc_attr(MeprProduct::$period_type_str); ?>"
         value="<?php echo esc_attr($product->period_type); ?>">

  <div id="mepr-non-recurring-options" class="mepr-hidden">
    <p>
      <strong><?php esc_html_e('Access:', 'memberpress'); ?></strong>
    </p>
    <p>
      <label class="screen-reader-text" for="<?php echo esc_attr(MeprProduct::$expire_type_str); ?>"><?php esc_html_e('Access:', 'memberpress'); ?></label>
      <select name="<?php echo esc_attr(MeprProduct::$expire_type_str); ?>" id="<?php echo esc_attr(MeprProduct::$expire_type_str); ?>">
        <option value="none"<?php selected($product->expire_type, 'none'); ?>><?php esc_html_e('Lifetime', 'memberpress'); ?>&nbsp;</option>
        <option value="delay"<?php selected($product->expire_type, 'delay'); ?>><?php esc_html_e('Expire', 'memberpress'); ?>&nbsp;</option>
        <option value="fixed"<?php selected($product->expire_type, 'fixed'); ?>><?php esc_html_e('Fixed Expire', 'memberpress'); ?>&nbsp;</option>
      </select>
    </p>
    <div class="mepr-product-expire-delay mepr-sub-box">
      <div class="mepr-arrow mepr-gray mepr-up mepr-sub-box-arrow"> </div>
      <p class="mepr-clear-top">
        <strong><?php esc_html_e('Expire After:', 'memberpress'); ?></strong>
      </p>
      <p>
        <input type="text" size="2"
               name="<?php echo esc_attr(MeprProduct::$expire_after_str); ?>"
               id="<?php echo esc_attr(MeprProduct::$expire_after_str); ?>"
               value="<?php echo esc_attr($product->expire_after); ?>" />
        <select name="<?php echo esc_attr(MeprProduct::$expire_unit_str); ?>"
                id="<?php echo esc_attr(MeprProduct::$expire_unit_str); ?>">
          <option value="days"<?php selected($product->expire_unit, 'days'); ?>><?php esc_html_e('days', 'memberpress'); ?></option>
          <option value="weeks"<?php selected($product->expire_unit, 'weeks'); ?>><?php esc_html_e('weeks', 'memberpress'); ?></option>
          <option value="months"<?php selected($product->expire_unit, 'months'); ?>><?php esc_html_e('months', 'memberpress'); ?></option>
          <option value="years"<?php selected($product->expire_unit, 'years'); ?>><?php esc_html_e('years', 'memberpress'); ?></option>
        </select>
      </p>
      <p>
        <input type="checkbox"
               id="<?php echo esc_attr(MeprProduct::$allow_renewal_str); ?>"
               name="<?php echo esc_attr(MeprProduct::$allow_renewal_str); ?>"
               <?php checked($product->allow_renewal); ?> />
        <label for="<?php echo esc_attr(MeprProduct::$allow_renewal_str); ?>">
          <?php esc_html_e('Allow Early Renewals', 'memberpress'); ?>
        </label>
      </p>
    </div>
    <div class="mepr-product-expire-fixed mepr-sub-box">
      <div class="mepr-arrow mepr-gray mepr-up mepr-sub-box-arrow"> </div>
      <p class="mepr-clear-top">
        <strong><?php esc_html_e('Expire On:', 'memberpress'); ?></strong>
      </p>
      <p>
        <input type="text"
               class="mepr-date-picker"
               name="<?php echo esc_attr(MeprProduct::$expire_fixed_str); ?>"
               id="<?php echo esc_attr(MeprProduct::$expire_fixed_str); ?>"
               value="<?php echo esc_attr($product->expire_fixed); ?>" />
      </p>
      <p>
        <input type="checkbox"
               id="<?php echo esc_attr(MeprProduct::$allow_renewal_str); ?>-fixed"
               name="<?php echo esc_attr(MeprProduct::$allow_renewal_str); ?>-fixed"
               <?php checked($product->allow_renewal); ?> />
        <label for="<?php echo esc_attr(MeprProduct::$allow_renewal_str); ?>-fixed">
          <?php esc_html_e('Allow Early Annual Renewals', 'memberpress'); ?>
        </label>
      </p>
    </div>
  </div>

  <div id="mepr-recurring-options" class="mepr-hidden">
    <p>
      <strong><?php esc_html_e('Interval:', 'memberpress'); ?></strong>
    </p>
    <p>
      <?php MeprProductsHelper::preset_period_dropdown(
          MeprProduct::$period_str,
          MeprProduct::$period_type_str
      ); ?>
      <div id="mepr-product-custom-period" class="mepr-hidden mepr-product-custom-period mepr-sub-box">
        <div class="mepr-arrow mepr-gray mepr-up mepr-sub-box-arrow"> </div>
        <input type="text" size="2"
               id="<?php echo esc_attr(MeprProduct::$period_str); ?>-custom"
               name="<?php echo esc_attr(MeprProduct::$period_str); ?>-custom" />
        <?php MeprProductsHelper::period_type_dropdown(MeprProduct::$period_type_str); ?>
      </div>
    </p>
    <div class="mepr-product-trial-box">
      <?php $checked = (isset($product->trial) && $product->trial) ? 'checked="checked"' : ''; ?>
      <p>
        <input type="checkbox" name="<?php echo esc_attr(MeprProduct::$trial_str); ?>" id="<?php echo esc_attr(MeprProduct::$trial_str); ?>" <?php echo esc_attr($checked); ?> /> <label for="_mepr_product_trial"><?php esc_html_e('Trial Period', 'memberpress'); ?></label>
        <?php MeprAppHelper::info_tooltip(
            'mepr-product-trial-days',
            __('Trial Period Info', 'memberpress'),
            __('The trial period is the number of days listed in the "Trial Duration" field. A 1 month trial would be 30 days, 2 months would be 60. Similarly, 1 year would be 365.', 'memberpress')
        ); ?>
        <div id="disable-trial-notice" class="mepr-meta-sub-pane" data-value="<?php esc_attr_e('Price must be greater than 0.00 to choose recurring subscriptions.', 'memberpress'); ?>" class="mepr_hidden"></div>
      </p>
      <div class="mepr-product-trial-hidden mepr-sub-box">
        <div class="mepr-arrow mepr-gray mepr-up mepr-sub-box-arrow"> </div>
        <p class="mepr-clear-top">
          <strong><?php esc_html_e('Trial Duration (Days):', 'memberpress'); ?></strong>
        </p>
        <p>
          <input name="<?php echo esc_attr(MeprProduct::$trial_days_str); ?>" id="<?php echo esc_attr(MeprProduct::$trial_days_str); ?>" type="text" size="2" value="<?php echo esc_attr($product->trial_days); ?>" />
        </p>
        <p>
          <strong>
              <?php
                echo esc_html(
                    sprintf(
                        // Translators: %s: currency symbol.
                        __('Trial Amount (%s):', 'memberpress'),
                        $mepr_options->currency_symbol
                    )
                );
                ?>
          </strong>
        </p>
        <p>
          <input name="<?php echo esc_attr(MeprProduct::$trial_amount_str); ?>" id="<?php echo esc_attr(MeprProduct::$trial_amount_str); ?>" size="7" type="text" value="<?php echo esc_attr(MeprUtils::format_currency_float($product->trial_amount)); ?>" />
        </p>
        <p>
          <input type="checkbox" name="<?php echo esc_attr(MeprProduct::$trial_once_str); ?>" id="<?php echo esc_attr(MeprProduct::$trial_once_str); ?>" <?php checked($product->trial_once); ?> /> <label for="<?php echo esc_attr(MeprProduct::$trial_once_str); ?>"><?php esc_html_e('Allow Only One Trial', 'memberpress'); ?></label>
          <?php MeprAppHelper::info_tooltip(
              'mepr-product-trial-once',
              __('Restrict Trial to One Per Member', 'memberpress'),
              __('When checked, this option will allow a member to go through the trial once. If they cancel their subscription and try to re-subscribe then they\'ll be able to do so but without the trial. Note: Coupons set to override a product trial will still work even with this checked.', 'memberpress')
          ); ?>
        </p>
      </div>
    </div>
    <div class="mepr-product-cycles-box">
      <?php $checked = (isset($product->limit_cycles) && $product->limit_cycles) ? 'checked="checked"' : ''; ?>
      <p>
        <input type="checkbox" name="<?php echo esc_attr(MeprProduct::$limit_cycles_str); ?>" id="<?php echo esc_attr(MeprProduct::$limit_cycles_str); ?>" <?php echo esc_attr($checked); ?> /> <label for="_mepr_product_limit_cycles"><?php esc_html_e('Limit Payment Cycles', 'memberpress'); ?></label>
      </p>
      <div class="mepr-product-limit-cycles-hidden mepr-sub-box">
        <div class="mepr-arrow mepr-gray mepr-up mepr-sub-box-arrow"> </div>
        <p class="mepr-clear-top">
          <strong><?php esc_html_e('Max # of Payments:', 'memberpress'); ?></strong>
        </p>
        <p>
          <input name="<?php echo esc_attr(MeprProduct::$limit_cycles_num_str); ?>" id="<?php echo esc_attr(MeprProduct::$limit_cycles_num_str); ?>" type="text" size="2" value="<?php echo esc_attr($product->limit_cycles_num); ?>" />
        </p>
        <p>
          <strong><?php esc_html_e('Access After Last Cycle:', 'memberpress'); ?></strong>
        </p>
        <p>
          <select name="<?php echo esc_attr(MeprProduct::$limit_cycles_action_str); ?>" id="<?php echo esc_attr(MeprProduct::$limit_cycles_action_str); ?>">
            <option value="expire" <?php selected('expire', $product->limit_cycles_action); ?>><?php esc_html_e('Expire Access', 'memberpress'); ?></option>
            <option value="lifetime" <?php selected('lifetime', $product->limit_cycles_action); ?>><?php esc_html_e('Lifetime Access', 'memberpress'); ?></option>
            <option value="expires_after" <?php selected('expires_after', $product->limit_cycles_action); ?>><?php esc_html_e('Expire Access After', 'memberpress'); ?></option>
          </select>
        </p>

        <div id="mepr-product-limit-cycles-expiration" class="mepr-hidden mepr-product-limit-cycles-expiration mepr-sub-box" style="background:white">
          <div class="mepr-arrow mepr-white mepr-up mepr-sub-box-arrow"> </div>
          <input type="text" size="2"
                name="<?php echo esc_attr(MeprProduct::$limit_cycles_expires_after_str); ?>"
                id="<?php echo esc_attr(MeprProduct::$limit_cycles_expires_after_str); ?>"
                value="<?php echo esc_attr($product->limit_cycles_expires_after); ?>" />
          <select name="<?php echo esc_attr(MeprProduct::$limit_cycles_expires_type_str); ?>"
                  id="<?php echo esc_attr(MeprProduct::$limit_cycles_expires_type_str); ?>">
            <option value="days"<?php selected($product->limit_cycles_expires_type, 'days'); ?>><?php esc_html_e('days', 'memberpress'); ?></option>
            <option value="weeks"<?php selected($product->limit_cycles_expires_type, 'weeks'); ?>><?php esc_html_e('weeks', 'memberpress'); ?></option>
            <option value="months"<?php selected($product->limit_cycles_expires_type, 'months'); ?>><?php esc_html_e('months', 'memberpress'); ?></option>
            <option value="years"<?php selected($product->limit_cycles_expires_type, 'years'); ?>><?php esc_html_e('years', 'memberpress'); ?></option>
          </select>

        </div>

      </div>
    </div>
  </div>

  <?php // Per-currency pricing moved to "Currencies" tab in Product Options meta box. ?>

  <!-- The NONCE below prevents post meta from being blanked on move to trash -->
  <input type="hidden" name="<?php echo esc_attr(MeprProduct::$nonce_str); ?>" value="<?php echo esc_attr(wp_create_nonce(MeprProduct::$nonce_str . wp_salt())); ?>" />
</div>
