<?php

namespace MasterStudy\Lms\Pro\addons\assignments\Routing\Swagger;

use MasterStudy\Lms\Routing\Swagger\RequestInterface;
use MasterStudy\Lms\Routing\Swagger\ResponseInterface;
use MasterStudy\Lms\Routing\Swagger\Route;

class AddAdminStudentAssignmentAttachment extends Route implements RequestInterface, ResponseInterface {
	public function request(): array {
		return array(
			'attachment_id' => array(
				'type'     => 'integer',
				'required' => true,
			),
			'is_created'    => array(
				'type' => 'boolean',
			),
		);
	}

	public function response(): array {
		return array(
			'attachment_id' => array(
				'type' => 'integer',
			),
			'files_formats' => array(
				'type' => 'object',
			),
			'icon_url'      => array(
				'type' => 'string',
			),
		);
	}

	public function get_summary(): string {
		return 'Add Instructor Attachment to Student Assignment';
	}

	public function get_description(): string {
		return 'Attaches an uploaded media file to a student assignment as an instructor attachment.';
	}
}
