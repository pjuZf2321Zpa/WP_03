<?php

namespace BitApps\IntegrationsPro\Actions\FollowUpBoss\Services;

final class ReactionService extends BaseService
{
    public function addReaction(): array
    {
        $validationRules = [
            'ref_type' => ['required'],
            'ref_id'   => ['required'],
            'body'     => ['required'],
        ];
        $error = $this->validateFields(
            $validationRules,
            [
                'ref_type' => __('Record Type', 'bit-integrations-pro'),
                'ref_id'   => __('Note, Call or Reply ID', 'bit-integrations-pro'),
                'body'     => __('Emoji', 'bit-integrations-pro'),
            ],
            ['ref_type']
        );

        if ($error !== null) {
            return $error;
        }

        $payload = $this->removeEmptyValues(
            [
                'body' => $this->getString('body'),
            ]
        );

        return $this->dispatch('POST', '/reactions/' . rawurlencode($this->getString('ref_type')) . '/' . rawurlencode($this->getString('ref_id')), $payload);
    }

    public function removeReaction(): array
    {
        $validationRules = [
            'ref_type' => ['required'],
            'ref_id'   => ['required'],
            'emoji'    => ['required'],
        ];
        $error = $this->validateFields(
            $validationRules,
            [
                'ref_type' => __('Record Type', 'bit-integrations-pro'),
                'ref_id'   => __('Note, Call or Reply ID', 'bit-integrations-pro'),
                'emoji'    => __('Emoji', 'bit-integrations-pro'),
            ],
            ['ref_type']
        );

        if ($error !== null) {
            return $error;
        }

        $query = $this->removeEmptyValues(
            [
                'emoji' => $this->getString('emoji'),
            ]
        );

        return $this->dispatch('DELETE', '/reactions/' . rawurlencode($this->getString('ref_type')) . '/' . rawurlencode($this->getString('ref_id')), ['body' => $this->getString('emoji')], $query);
    }
}
