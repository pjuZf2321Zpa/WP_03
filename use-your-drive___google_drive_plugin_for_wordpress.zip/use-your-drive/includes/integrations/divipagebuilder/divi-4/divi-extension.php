<?php

if (!function_exists('wpcp_initialize_extension')) {
    /**
     * Creates the extension's main class instance.
     *
     * @since 1.0.0
     */
    function wpcp_initialize_extension()
    {
        require_once plugin_dir_path(__FILE__).'includes/DiviExtension.php';
    }
    add_action('divi_extensions_init', 'wpcp_initialize_extension');
}
