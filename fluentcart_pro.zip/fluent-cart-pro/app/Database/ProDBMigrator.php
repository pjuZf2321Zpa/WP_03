<?php

namespace FluentCartPro\App\Database;

require_once(ABSPATH . 'wp-admin/includes/upgrade.php');

use FluentCartPro\App\Modules\AdvancedInventory\Database\DBMigrator as AdvancedInventoryDBMigrator;
use FluentCartPro\App\Modules\DynamicPricing\DynamicPricingInit;
use FluentCartPro\App\Modules\Licensing\Database\DBMigrator as LicensingDBMigrator;
use FluentCartPro\App\Modules\Promotional\PromotionalInit;
use FluentCartPro\App\Modules\Licensing\Database\Migrations\LicensesMigrator;
use FluentCartPro\App\Modules\MultiCurrency\Database\CurrencyRatesMigrator;

class ProDBMigrator
{
    /**
     * Full migration: idempotent schema + one-time version-gated changes.
     * Call on activation and from WP-CLI.
     */
    public static function run_migrate()
    {
        self::migrate();
        update_option('_fluentcart_pro_db_version', FLUENTCART_PRO_DB_VERSION, 'no');
        self::maybeMigrateDBChanges();
    }

    /**
     * Idempotent schema migrations for all Pro modules.
     * Safe to call on every activation — each sub-migrator uses
     * addColumnIfNotExists / dbDelta so repeated calls are no-ops.
     */
    public static function migrate()
    {
        if (\FluentCart\Api\ModuleSettings::isActive('order_bump')) {
            (new PromotionalInit())->maybeMigrateDB();
        }

        if (\FluentCart\Api\ModuleSettings::isActive('license')) {
            (new LicensingDBMigrator())->migrate();
        }

        if (\FluentCart\Api\ModuleSettings::isActive('reviews')) {
            (new \FluentCartPro\App\Modules\Reviews\Database\DBMigrator())->migrate();
        }

        if (\FluentCart\Api\ModuleSettings::isActive('dynamic_pricing')) {
            (new DynamicPricingInit())->maybeMigrateDB();
        }

        (new AdvancedInventoryDBMigrator())->migrate();

        self::maybeMigrateCurrencyRates(true);
    }

    /**
     * One-time DDL and data changes gated behind FLUENTCART_PRO_DB_VERSION.
     * Add new entries here when a schema or data change cannot be expressed
     * as an idempotent addColumnIfNotExists call in a module migrator.
     * Bump FLUENTCART_PRO_DB_VERSION in fluent-cart-pro.php for each new entry.
     */
    public static function maybeMigrateDBChanges()
    {
        // This entry point runs on admin screens and WP-CLI, never checkout.
        $indexOption = '_fluentcart_pro_customer_recovery_index_version';
        if ( get_option( $indexOption ) !== '1' && LicensesMigrator::migrated() ) {
            update_option( $indexOption, '1', false );
        }

        self::maybeMigrateCurrencyRates();

        $currentVersion = get_option('_fluentcart_pro_db_version');

        if ($currentVersion && !version_compare($currentVersion, FLUENTCART_PRO_DB_VERSION, '<')) {
            return;
        }

        // Stamp version before running changes so a mid-run failure does not
        // loop on every page load. Same pattern as the free plugin.
        update_option('_fluentcart_pro_db_version', FLUENTCART_PRO_DB_VERSION, 'no');

        // Reviews interactions table. Runs here as well as in migrate()
        // because
        // plugin UPDATES replace files without firing the activation hook —
        // this version-gated path is what reaches them.
        if (\FluentCart\Api\ModuleSettings::isActive('reviews')) {
            (new \FluentCartPro\App\Modules\Reviews\Database\DBMigrator())->migrate();
        }
    }

    /**
     * The exchange-rate table, outside the DB version gate: the version is
     * stamped before its changes run, so a failed CREATE would never retry.
     * The table records its own completion instead (CurrencyRatesMigrator::OPTION).
     */
    public static function maybeMigrateCurrencyRates(bool $force = false): void
    {
        // Needs core with multi-currency
        if (!class_exists(\FluentCart\App\Modules\MultiCurrency\Services\MultiCurrencySettings::class)) {
            return;
        }

        CurrencyRatesMigrator::install($force);
    }
}
