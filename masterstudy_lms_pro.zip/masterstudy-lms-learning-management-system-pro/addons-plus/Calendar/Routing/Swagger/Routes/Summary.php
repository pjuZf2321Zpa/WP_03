<?php

namespace MasterStudy\Lms\Pro\AddonsPlus\Calendar\Routing\Swagger\Routes;

use MasterStudy\Lms\Routing\Swagger\RequestInterface;
use MasterStudy\Lms\Routing\Swagger\ResponseInterface;
use MasterStudy\Lms\Routing\Swagger\Route;

final class Summary extends Route implements RequestInterface, ResponseInterface {
	public function request(): array {
		return array(
			'year'  => array(
				'type'        => 'integer',
				'description' => 'Calendar year.',
				'required'    => true,
			),
			'month' => array(
				'type'        => 'integer',
				'description' => 'Calendar month from 1 to 12.',
				'required'    => true,
			),
			'type'  => array(
				'type'        => 'string',
				'description' => 'Optional event type filter.',
				'required'    => false,
				'enum'        => array( 'zoom', 'meet', 'stream', 'deadline', 'quiz', 'available' ),
			),
		);
	}

	public function response(): array {
		return array(
			'year'  => array(
				'type'        => 'integer',
				'description' => 'Calendar year.',
			),
			'month' => array(
				'type'        => 'integer',
				'description' => 'Calendar month.',
			),
			'days'  => array(
				'type'        => 'object',
				'description' => 'Map of Y-m-d days to total counts and first three preview events.',
			),
		);
	}

	public function get_summary(): string {
		return 'Get Calendar Event Summary';
	}

	public function get_description(): string {
		return 'Returns per-day event totals and lightweight preview events for the selected month.';
	}
}
