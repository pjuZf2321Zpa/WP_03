<?php

namespace MasterStudy\Lms\Pro\AddonsPlus\Notifications\Services;

use MasterStudy\Lms\Pro\AddonsPlus\Notifications\Repositories\DispatchQueueRepository;
use MasterStudy\Lms\Pro\AddonsPlus\Notifications\Repositories\PushQueueRepository;

final class Cleanup {
	public const HOOK                           = 'masterstudy_notifications_cleanup';
	private const CONTINUATION_HOOK             = 'masterstudy_notifications_cleanup_continue';
	private const CONTINUATION_DELAY            = 60;
	private const DEFAULT_BATCH_SIZE            = 1000;
	private const DEFAULT_READ_RETENTION_DAYS   = 45;
	private const DEFAULT_UNREAD_RETENTION_DAYS = 90;
	private const DEFAULT_QUEUE_RETENTION_DAYS  = 30;
	private const DEFAULT_INACTIVE_SUBSCRIPTION_RETENTION_DAYS = 180;

	public static function ensure_scheduled(): void {
		if ( ! self::is_available() || wp_next_scheduled( self::HOOK ) ) {
			return;
		}

		wp_schedule_event( time() + HOUR_IN_SECONDS, 'daily', self::HOOK );
	}

	public static function process(): void {
		try {
			if ( ! self::is_available() ) {
				return;
			}

			$needs_more = ( new self() )->run();

			if ( $needs_more && ! wp_next_scheduled( self::CONTINUATION_HOOK ) ) {
				wp_schedule_single_event( time() + self::CONTINUATION_DELAY, self::CONTINUATION_HOOK );
			}
		} catch ( \Throwable $error ) {
			return;
		}
	}

	private function run(): bool {
		$limit      = self::batch_size();
		$needs_more = false;

		$needs_more = $this->delete_read_recipients( $limit ) >= $limit || $needs_more;
		$needs_more = $this->delete_unread_recipients( $limit ) >= $limit || $needs_more;
		$needs_more = $this->delete_terminal_push_queue( $limit ) >= $limit || $needs_more;
		$needs_more = $this->delete_terminal_dispatch_queue( $limit ) >= $limit || $needs_more;
		$needs_more = $this->delete_inactive_subscriptions( $limit ) >= $limit || $needs_more;
		$needs_more = $this->delete_orphan_notifications( $limit ) >= $limit || $needs_more;

		return $needs_more;
	}

	private function delete_read_recipients( int $limit ): int {
		global $wpdb;

		$table  = masterstudy_lms_notification_recipients_table_name( $wpdb );
		$cutoff = self::cutoff_gmt(
			self::retention_days(
				'masterstudy_notifications_read_retention_days',
				self::DEFAULT_READ_RETENTION_DAYS
			)
		);
		$ids    = $this->select_ids(
			$table,
			'id',
			'read_at_gmt IS NOT NULL AND read_at_gmt < %s',
			array( $cutoff ),
			$limit
		);

		return $this->delete_ids( $table, 'id', $ids );
	}

	private function delete_unread_recipients( int $limit ): int {
		global $wpdb;

		$table  = masterstudy_lms_notification_recipients_table_name( $wpdb );
		$cutoff = self::cutoff_gmt(
			self::retention_days(
				'masterstudy_notifications_unread_retention_days',
				self::DEFAULT_UNREAD_RETENTION_DAYS
			)
		);
		$ids    = $this->select_ids(
			$table,
			'id',
			'read_at_gmt IS NULL AND created_at_gmt < %s',
			array( $cutoff ),
			$limit
		);

		return $this->delete_ids( $table, 'id', $ids );
	}

	private function delete_terminal_push_queue( int $limit ): int {
		global $wpdb;

		$table  = masterstudy_lms_notification_push_queue_table_name( $wpdb );
		$cutoff = self::cutoff_gmt(
			self::retention_days(
				'masterstudy_notifications_queue_retention_days',
				self::DEFAULT_QUEUE_RETENTION_DAYS
			)
		);
		$ids    = $this->select_ids(
			$table,
			'id',
			'status IN (%s,%s,%s) AND updated_at_gmt < %s',
			array(
				PushQueueRepository::STATUS_SENT,
				PushQueueRepository::STATUS_SKIPPED,
				PushQueueRepository::STATUS_FAILED,
				$cutoff,
			),
			$limit
		);

		return $this->delete_ids( $table, 'id', $ids );
	}

	private function delete_terminal_dispatch_queue( int $limit ): int {
		global $wpdb;

		$table  = masterstudy_lms_notification_dispatch_queue_table_name( $wpdb );
		$cutoff = self::cutoff_gmt(
			self::retention_days(
				'masterstudy_notifications_queue_retention_days',
				self::DEFAULT_QUEUE_RETENTION_DAYS
			)
		);
		$ids    = $this->select_ids(
			$table,
			'id',
			'status IN (%s,%s) AND updated_at_gmt < %s',
			array(
				DispatchQueueRepository::STATUS_DONE,
				DispatchQueueRepository::STATUS_FAILED,
				$cutoff,
			),
			$limit
		);

		return $this->delete_ids( $table, 'id', $ids );
	}

	private function delete_inactive_subscriptions( int $limit ): int {
		global $wpdb;

		$table  = masterstudy_lms_notification_push_subscriptions_table_name( $wpdb );
		$cutoff = self::cutoff_gmt(
			self::retention_days(
				'masterstudy_notifications_inactive_subscription_retention_days',
				self::DEFAULT_INACTIVE_SUBSCRIPTION_RETENTION_DAYS
			)
		);
		$ids    = $this->select_ids(
			$table,
			'id',
			'status = %s AND updated_at_gmt < %s',
			array( 'inactive', $cutoff ),
			$limit
		);

		return $this->delete_ids( $table, 'id', $ids );
	}

	private function delete_orphan_notifications( int $limit ): int {
		global $wpdb;

		$notifications = masterstudy_lms_notifications_table_name( $wpdb );
		$recipients    = masterstudy_lms_notification_recipients_table_name( $wpdb );
		$push_queue    = masterstudy_lms_notification_push_queue_table_name( $wpdb );
		$dispatch      = masterstudy_lms_notification_dispatch_queue_table_name( $wpdb );
		$cutoff        = self::cutoff_gmt(
			self::retention_days(
				'masterstudy_notifications_queue_retention_days',
				self::DEFAULT_QUEUE_RETENTION_DAYS
			)
		);
		// phpcs:disable WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Table names are generated from $wpdb->prefix.
		$ids = $wpdb->get_col(
			$wpdb->prepare(
				"SELECT n.id
				FROM {$notifications} n
				WHERE n.created_at_gmt < %s
					AND NOT EXISTS (SELECT 1 FROM {$recipients} r WHERE r.notification_id = n.id)
					AND NOT EXISTS (SELECT 1 FROM {$push_queue} pq WHERE pq.notification_id = n.id)
					AND NOT EXISTS (SELECT 1 FROM {$dispatch} dq WHERE dq.notification_id = n.id)
				ORDER BY n.id ASC
				LIMIT %d",
				$cutoff,
				$limit
			)
		);
		// phpcs:enable WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared

		return $this->delete_ids( $notifications, 'id', $this->sanitize_ids( $ids ) );
	}

	private function select_ids( string $table, string $id_column, string $where, array $params, int $limit ): array {
		global $wpdb;

		$params[] = $limit;

		// phpcs:disable WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare -- Table, column, and WHERE fragments are generated internally.
		$ids = $wpdb->get_col(
			$wpdb->prepare(
				"SELECT {$id_column} FROM {$table} WHERE {$where} ORDER BY {$id_column} ASC LIMIT %d",
				$params
			)
		);
		// phpcs:enable WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare

		return $this->sanitize_ids( $ids );
	}

	private function delete_ids( string $table, string $id_column, array $ids ): int {
		global $wpdb;

		$ids = $this->sanitize_ids( $ids );

		if ( empty( $ids ) ) {
			return 0;
		}

		$placeholders = implode( ',', array_fill( 0, count( $ids ), '%d' ) );

		// phpcs:disable WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare -- Table, column, and IN placeholders are generated internally.
		$deleted = (int) $wpdb->query(
			$wpdb->prepare(
				"DELETE FROM {$table} WHERE {$id_column} IN ({$placeholders})",
				$ids
			)
		);
		// phpcs:enable WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare

		return $deleted;
	}

	private function sanitize_ids( array $ids ): array {
		return array_values( array_unique( array_filter( array_map( 'absint', $ids ) ) ) );
	}

	private static function retention_days( string $filter_name, int $default ): int {
		return max( 0, absint( apply_filters( $filter_name, $default ) ) );
	}

	private static function batch_size(): int {
		return min(
			5000,
			max(
				1,
				absint(
					apply_filters(
						'masterstudy_notifications_cleanup_batch_size',
						self::DEFAULT_BATCH_SIZE
					)
				)
			)
		);
	}

	private static function cutoff_gmt( int $days ): string {
		return gmdate( 'Y-m-d H:i:s', time() - $days * DAY_IN_SECONDS );
	}

	private static function is_available(): bool {
		return function_exists( 'masterstudy_lms_is_notifications_addon_available' )
			&& masterstudy_lms_is_notifications_addon_available();
	}
}
