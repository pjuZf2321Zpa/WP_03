<?php

namespace CustomFacebookFeed\Abilities\Services;

if (!defined('ABSPATH')) {
	exit;
}

/**
 * Typed allowlist of the settings exposed through the Abilities API.
 *
 * This is the single source of truth for what an AI agent may read or write.
 * Anything not listed here is never exposed — connected accounts, access
 * tokens, license data, custom CSS/JS and usage tracking are deliberately
 * absent. JSON Schemas for every ability are derived from these tables.
 *
 * Per-feed keys map 1:1 onto CFF_Feed_Saver::settings_defaults(); global keys
 * map onto the split CFF options (cff_style_settings, cff_locale,
 * cff_caching_type, cff_cache_cron_*, cff_ajax, cff_preserve_settings).
 *
 * BOOLEAN STORAGE: CFF stores booleans in two different native shapes
 * depending on the option area. Per-feed settings (settings_defaults()) use
 * 'on'/'off'/'' STRINGS for nearly every toggle. The cff_style_settings
 * Advanced-tab booleans (cff_show_credit, cff_format_issue, ...) use real PHP
 * booleans (see CFF_Global_Settings::default_settings_options()). Every key
 * below is still typed `boolean` in the JSON Schema — the wire shape an agent
 * sees is uniform — but `cast_out`/`validate_in` only produce PHP true/false;
 * the SERVICE layer (not this class) is responsible for writing back
 * whichever native representation that specific option area already uses
 * (see CFF_Feed_Settings_Service::to_native() and the inline
 * CFF_Settings_Schema::encode_bool() calls in
 * CFF_Global_Settings_Service::update()), so the round trip stays
 * lossless in both places instead of silently converting one plugin's
 * on/off-string option into a PHP-bool option (which several places in the
 * plugin compare with `=== 'on'`).
 *
 * @since 4.13
 */
class CFF_Settings_Schema
{
	const MAX_STRING_LENGTH = 500;

	/**
	 * Hex colour: #rgb, #rgba, #rrggbb, #rrggbbaa, or empty. The pattern itself
	 * matches only the empty string besides a real hex colour — it does NOT
	 * match a bare '#'. CFF stores an "unset colour" as a literal '#' rather
	 * than '', so normalize_color() converts '#' to '' before either
	 * validate_in() or cast_out() apply this pattern, keeping both directions
	 * of the round trip consistent (B19: previously only cast_out special-cased
	 * '#', so an agent replaying a stored '#' value back through
	 * update-feed-settings was rejected as invalid).
	 */
	const COLOR_PATTERN = '^(#([0-9a-fA-F]{3,4}|[0-9a-fA-F]{6}|[0-9a-fA-F]{8}))?$';

	/**
	 * Forbids the characters that let a free-text value break out of an HTML
	 * attribute or tag: `"` `'` `<` `>` `&`. Applied to `datecustom` (H1):
	 * the value reaches a `data-cff-comment-date="…"` attribute via
	 * `CFF_Shortcode_Display::get_date()`, and PHP's `date()` treats a
	 * backslash as an escape that prints the FOLLOWING character literally
	 * (dropping the backslash) rather than as a shell-style escape of that
	 * character's special meaning — so `\"` in the input still produces a
	 * literal `"` in the rendered output. The pattern therefore rejects the
	 * quote/angle-bracket characters themselves anywhere in the string,
	 * including immediately after a backslash.
	 *
	 * `&` is included for a second, independent reason (H1 round 2): an
	 * agent can write an ALREADY-ENTITY-ENCODED payload such as
	 * `&lt;img src=x onerror=alert(1)&gt;` — date()'s escaped-letter
	 * printing reproduces every letter of that literally, `esc_attr()`
	 * does not re-encode an existing `&`, and the front-end JS reads the
	 * attribute with jQuery's `.attr()`, which HTML-DECODES entities before
	 * handing the string back — turning the encoded text right back into a
	 * live `<img onerror=...>` tag at the JS concatenation sink
	 * (assets/js/cff-scripts.js). Rejecting `&` at the schema closes the
	 * abilities-write path; the JS sink and the PHP double-encode are fixed
	 * independently for the Feed-Builder path, which reaches the same sink.
	 *
	 * No legitimate PHP date() format token uses any of these five
	 * characters, so no real format is lost.
	 */
	const NO_MARKUP_PATTERN = '^[^"\'<>&]*$';

	/**
	 * Keys that only work as a set: writing a "trigger" key to a particular
	 * value requires its companion keys to already resolve to a real value in
	 * the SAME write or the already-stored row — otherwise the write leaves a
	 * feed in a state the plugin's own render path can't act on
	 * (AgDR-0504 requirement 2). Twitter's `set-feed-type-and-terms` is the
	 * canonical shape for a dedicated validating ability; these two CFF pairs
	 * are simple two-key couplings validated inline by the service instead of
	 * warranting a whole new ability.
	 *
	 * @var array<string, array{trigger: string, requires: string[]}>
	 */
	public const COUPLED_GROUPS = array(
		'colorpalette' => array(
			'trigger'  => 'custom',
			'requires' => array('custombgcolor1', 'custombgcolor2', 'textcolor1', 'textcolor2', 'customlinkcolor'),
		),
		'dateformat' => array(
			'trigger'  => 'custom',
			'requires' => array('datecustom'),
		),
	);

	/**
	 * Per-feed settings. `tier` names the license feature that must be
	 * available for the key to be writable (null = every Pro tier).
	 *
	 * @return array<string, array<string, mixed>>
	 */
	public static function feed_settings()
	{
		return array(
			'feed_name' => array(
				'type' => 'string',
				'description' => 'Internal feed name shown in the Feed Builder list.',
			),
			'feedtype' => array(
				'type' => 'string',
				'description' => 'Feed content type (links, events, videos, photos, albums, statuses, timeline, reviews). '
					. 'Read-only: it is the feed\'s identity, set when the feed is created.',
				'writable' => false,
			),
			'feedlayout' => array(
				'type' => 'string',
				'enum' => array('list', 'grid', 'masonry', 'carousel'),
				// Hakim T1 (round 2): only the 'carousel' value is
				// tier-gated (to advanced_feed_layouts, the same feature
				// the carousel sub-settings below already require) — list/
				// grid/masonry are available on every tier. `tier` (a
				// whole-KEY gate) would be wrong here: it would block every
				// write to feedlayout, including switching AWAY from
				// carousel back to list/grid/masonry. `tier_values` maps
				// only the gated enum value(s) to their required feature;
				// every other value is ungated. Checked in update_feed(),
				// create_feed()'s explicit-settings loop, AND the
				// template-expansion re-gate — the same three places
				// `tier` is checked — so naming a carousel template or
				// writing feedlayout=carousel directly are both covered.
				'tier_values' => array('carousel' => 'advanced_feed_layouts'),
				'description' => 'Feed layout.',
			),
			'layout' => array(
				'type' => 'string',
				// Curated literal, NOT a runtime derivation (AgDR-9005: the
				// schema is rebuilt from the customizer tree on every
				// request with no caching, so a control_option_values() walk
				// here is a real per-request cost). Matches
				// CFF_Customize_Tab::get_customize_posts_controls()'s
				// 'layout' toggleset (id='layout') as of this commit — a
				// hand-listed ['half', 'full'] previously silently excluded
				// 'thumb', which corrupted any thumb-layout feed's read back
				// to 'half' via cast_out()'s enum fallback (AgDR-9004
				// requirement 1). tests/check-abilities-schema-drift.php
				// asserts this literal against the live control and must be
				// run whenever CFF_Customize_Tab's layout control changes.
				'enum' => array('thumb', 'half', 'full'),
				'description' => 'Post display density.',
			),
			'cols' => array(
				'type' => 'integer',
				'minimum' => 1,
				// Curated literal (AgDR-9005 — see the 'layout' comment
				// above for why). Matches
				// CFF_Customize_Tab::get_customize_feedlayout_controls()'s
				// 'cols' select (Desktop columns: options '1'..'6') — NOT
				// get_customize_posts_controls(), which is a different
				// control tree that has no 'cols' control at all. Round 1
				// of this fix looked the control up in the wrong method,
				// which made the lookup silently miss and fall back to a
				// hand-invented ceiling of 10 (Rex, round 2, finding A) —
				// exactly the drift tests/check-abilities-schema-drift.php
				// now catches.
				'maximum' => 6,
				'description' => 'Columns on desktop.',
			),
			'colstablet' => array(
				'type' => 'integer',
				'minimum' => 1,
				// Curated literal (AgDR-9005). Matches
				// get_customize_feedlayout_controls()'s 'colstablet' select
				// (options '1'..'6').
				'maximum' => 6,
				'description' => 'Columns on tablet.',
			),
			'colsmobile' => array(
				'type' => 'integer',
				'minimum' => 1,
				// Curated literal (AgDR-9005). Matches
				// get_customize_feedlayout_controls()'s 'colsmobile' select
				// (options '1'..'3' — mobile has fewer column choices than
				// desktop/tablet).
				'maximum' => 3,
				'description' => 'Columns on mobile.',
			),
			'num' => array(
				'type' => 'integer',
				'minimum' => 1,
				'maximum' => 200,
				'description' => 'Number of posts on desktop.',
			),
			'nummobile' => array(
				'type' => 'integer',
				// 0 is a real, legitimate stored value meaning "same as
				// desktop" (CFF_FB_Settings clamps with max(0, ...), and the
				// render path treats a non-positive nummobile as "use num"),
				// not a placeholder swallowed by a minimum of 1 (AgDR-9004
				// requirement 1: reads must never clamp or corrupt a legally
				// stored value).
				'minimum' => 0,
				'maximum' => 200,
				'description' => 'Number of posts on mobile. 0 = same as desktop.',
			),
			'showheader' => array(
				'type' => 'boolean',
				'on_off' => true,
				'description' => 'Show the feed header.',
			),
			'headertype' => array(
				'type' => 'string',
				'enum' => array('visual', 'text'),
				'description' => 'Header style.',
			),
			'headertext' => array(
				'type' => 'string',
				'description' => 'Text-style header content.',
			),
			'headercover' => array(
				'type' => 'boolean',
				'on_off' => true,
				'description' => 'Show the cover photo in the header.',
			),
			'headerbio' => array(
				'type' => 'boolean',
				'on_off' => true,
				'description' => 'Show the account bio in the header.',
			),
			'headeroutside' => array(
				'type' => 'boolean',
				'on_off' => true,
				'description' => 'Place the header outside the feed container.',
			),
			'headerbg' => array(
				'type' => 'string',
				'format' => 'color',
				'description' => 'Header background colour (hex).',
			),
			'headertextcolor' => array(
				'type' => 'string',
				'format' => 'color',
				'description' => 'Header text colour (hex).',
			),
			'showlikebox' => array(
				'type' => 'boolean',
				'on_off' => true,
				'description' => 'Show the Facebook like box.',
			),
			'likeboxpos' => array(
				'type' => 'string',
				'enum' => array('top', 'bottom'),
				'description' => 'Like box position.',
			),
			'likeboxcover' => array(
				'type' => 'boolean',
				'on_off' => true,
				'description' => 'Show the cover photo in the like box.',
			),
			'likeboxsmallheader' => array(
				'type' => 'boolean',
				'on_off' => true,
				'description' => 'Use a small header in the like box.',
			),
			'loadmore' => array(
				'type' => 'boolean',
				'on_off' => true,
				'description' => 'Show the Load More button.',
			),
			'buttoncolor' => array(
				'type' => 'string',
				'format' => 'color',
				'description' => 'Load More button background (hex).',
			),
			'buttonhovercolor' => array(
				'type' => 'string',
				'format' => 'color',
				'description' => 'Load More button hover background (hex).',
			),
			'buttontextcolor' => array(
				'type' => 'string',
				'format' => 'color',
				'description' => 'Load More button text colour (hex).',
			),
			'buttontext' => array(
				'type' => 'string',
				'description' => 'Load More button label.',
			),
			'disablelightbox' => array(
				'type' => 'boolean',
				'on_off' => true,
				'inverted_label' => true,
				'description' => 'Disable the lightbox popup.',
			),
			'poststyle' => array(
				'type' => 'string',
				'enum' => array('regular', 'boxed'),
				'description' => 'Post style.',
			),
			'postbgcolor' => array(
				'type' => 'string',
				'format' => 'color',
				'description' => 'Boxed post background colour (hex).',
			),
			'postcorners' => array(
				'type' => 'integer',
				'minimum' => 0,
				'maximum' => 50,
				'description' => 'Boxed post corner radius (px).',
			),
			'boxshadow' => array(
				'type' => 'boolean',
				'on_off' => true,
				'description' => 'Boxed post shadow.',
			),
			'textlength' => array(
				'type' => 'integer',
				'minimum' => 0,
				'maximum' => 2000,
				'description' => 'Max post text characters. 0 = no limit (not "plugin default" — the render path '
					. 'skips truncation entirely when this is 0).',
			),
			'desclength' => array(
				'type' => 'integer',
				'minimum' => 0,
				'maximum' => 2000,
				'description' => 'Max description characters for link posts. 0 = no limit (not "plugin default" — '
					. 'the render path skips truncation entirely when this is 0).',
			),
			'textcolor' => array(
				'type' => 'string',
				'format' => 'color',
				'description' => 'Post text colour (hex).',
			),
			'linkcolor' => array(
				'type' => 'string',
				'format' => 'color',
				'description' => 'Link text colour (hex).',
			),
			'datecolor' => array(
				'type' => 'string',
				'format' => 'color',
				'description' => 'Post date colour (hex).',
			),
			'dateformat' => array(
				'type' => 'string',
				'enum' => self::dateformat_enum(),
				'description' => 'Date format code (see the plugin\'s date-format picker for what each code renders '
					. 'as). "custom" requires datecustom to be set in the same write or already stored (A6).',
			),
			'datecustom' => array(
				'type' => 'string',
				'pattern' => self::NO_MARKUP_PATTERN,
				'description' => 'Custom PHP date() format string (e.g. "F j, Y"). Applies only when '
					. 'dateformat is "custom". May not contain " \' < or > (H1: this value reaches an HTML '
					. 'attribute on the public feed).',
			),
			'colorpalette' => array(
				'type' => 'string',
				// Curated literal (AgDR-9005 -- see the 'layout' comment
				// above for why runtime derivation was replaced). Matches
				// CFF_Customize_Tab::get_customize_colorscheme_controls()'s
				// 'colorpalette' toggleset. tests/check-abilities-schema-drift.php
				// asserts this literal against the live control.
				'enum' => array('inherit', 'light', 'dark', 'custom'),
				'description' => 'Colour palette. "custom" requires custombgcolor1, custombgcolor2, textcolor1, '
					. 'textcolor2 and customlinkcolor to be set in the same write or already stored (A4).',
			),
			'custombgcolor1' => array(
				'type' => 'string',
				'format' => 'color',
				'description' => 'Custom palette primary background colour (hex). Applies only when '
					. 'colorpalette is "custom".',
			),
			'custombgcolor2' => array(
				'type' => 'string',
				'format' => 'color',
				'description' => 'Custom palette secondary background colour (hex). Applies only when '
					. 'colorpalette is "custom".',
			),
			'textcolor1' => array(
				'type' => 'string',
				'format' => 'color',
				'description' => 'Custom palette primary text colour (hex). Applies only when '
					. 'colorpalette is "custom".',
			),
			'textcolor2' => array(
				'type' => 'string',
				'format' => 'color',
				'description' => 'Custom palette secondary text colour (hex). Applies only when '
					. 'colorpalette is "custom".',
			),
			'customlinkcolor' => array(
				'type' => 'string',
				'format' => 'color',
				'description' => 'Custom palette link colour (hex). Applies only when colorpalette is "custom".',
			),
			'gdpr' => array(
				'type' => 'string',
				'enum' => array('auto', 'yes', 'no'),
				'description' => 'Per-feed GDPR mode. Read-only: the render path always uses the GLOBAL GDPR mode '
					. '(cff_style_settings[\'gdpr\']), so a per-feed write here persists to the row but is never '
					. 'read back out at render time — it was a false-success write (C4). GDPR mode has legal '
					. 'consequences and is read-only for AI assistants everywhere in this schema; change it in '
					. 'Settings → Feeds.',
				'writable' => false,
			),
			// --- Carousel layout (tier: advanced_feed_layouts) ---
			'carouselheight' => array(
				'type' => 'string',
				// Curated literal (AgDR-9005). Matches
				// get_customize_feedlayout_controls()'s 'carouselheight'
				// select (Height of Carousel: tallest / clickexpand /
				// autoexpand). tests/check-abilities-schema-drift.php
				// asserts this literal against the live control.
				'enum' => array('tallest', 'clickexpand', 'autoexpand'),
				'tier' => 'advanced_feed_layouts',
				'description' => 'Carousel slide height mode.',
			),
			'carouseldesktop_cols' => array(
				'type' => 'integer',
				'minimum' => 1,
				'maximum' => 10,
				'tier' => 'advanced_feed_layouts',
				'description' => 'Carousel columns on desktop.',
			),
			'carouselmobile_cols' => array(
				'type' => 'integer',
				'minimum' => 1,
				'maximum' => 10,
				'tier' => 'advanced_feed_layouts',
				'description' => 'Carousel columns on mobile.',
			),
			'carouselpagination' => array(
				'type' => 'boolean',
				'true_false' => true,
				'tier' => 'advanced_feed_layouts',
				'description' => 'Show carousel pagination dots.',
			),
			'carouselautoplay' => array(
				'type' => 'boolean',
				'true_false' => true,
				'tier' => 'advanced_feed_layouts',
				'description' => 'Autoplay the carousel.',
			),
			'carouselinterval' => array(
				'type' => 'integer',
				'minimum' => 500,
				'maximum' => 60000,
				'tier' => 'advanced_feed_layouts',
				'description' => 'Carousel autoplay interval (ms).',
			),
		);
	}

	/**
	 * Global (plugin-wide) settings, spread across CFF's several options.
	 *
	 * @return array<string, array<string, mixed>>
	 */
	public static function global_settings()
	{
		return array(
			'cff_caching_type' => array(
				'type' => 'string',
				'enum' => array('background'),
				'description' => 'How feeds are refreshed. The Settings UI always uses "background"; read-only.',
				'writable' => false,
			),
			'cff_cache_cron_interval' => array(
				'type' => 'string',
				'enum' => array('30mins', '1hour', '12hours', '24hours'),
				'description' => 'Background cache refresh interval.',
			),
			'cff_cache_cron_time' => array(
				'type' => 'string',
				'enum' => array('1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12'),
				'description' => 'Hour for the daily (24hours) refresh.',
			),
			'cff_cache_cron_am_pm' => array(
				'type' => 'string',
				'enum' => array('am', 'pm'),
				'description' => 'AM/PM for the daily refresh hour.',
			),
			'gdpr' => array(
				'type' => 'string',
				'enum' => array('auto', 'yes', 'no'),
				'description' => 'GDPR mode, as set in Settings → Feeds. "auto" turns it on only when '
					. 'a supported consent plugin is active, "yes" always on, "no" always off. '
					. 'While on, feeds skip third-party requests (Facebook images, scripts) until the '
					. 'visitor consents. It affects legal compliance, so confirm the change with the '
					. 'site owner first.',
			),
			'cff_locale' => array(
				'type' => 'string',
				// Constrained to the plugin's own locale allowlist
				// (CFF_Settings::locales(), inc/Admin/Traits/CFF_Settings.php:25) —
				// this value flows unencoded into outbound Graph API URLs
				// (inc/CFF_Settings_Pro.php: '&locale=' . $cff_locale), so a free-text
				// write here is a query-parameter-injection surface for a
				// prompt-injected agent. Also fixes the UX wart of agents guessing
				// valid locale codes.
				// Called on the concrete class that uses the CFF_Settings trait
				// (calling a static trait method directly is deprecated as of PHP 8.1).
				'enum' => array_keys(\CustomFacebookFeed\Admin\CFF_Global_Settings::locales()),
				'description' => 'Locale used to render dates/timestamps.',
			),
			'cff_preserve_settings' => array(
				'type' => 'boolean',
				'on_off' => false,
				'description' => 'Keep plugin settings in the database when the plugin is uninstalled.',
			),
			'cff_show_credit' => array(
				'type' => 'boolean',
				'on_off' => false,
				'description' => 'Show a "powered by Smash Balloon" credit link under feeds.',
			),
			'cff_format_issue' => array(
				'type' => 'boolean',
				'on_off' => false,
				'description' => 'Fix a text-shortening issue caused by some themes.',
			),
			'enable_js_image_loading' => array(
				'type' => 'boolean',
				'on_off' => false,
				'description' => 'Load images on the client side with JavaScript instead of server side.',
			),
			'cff_ajax' => array(
				'type' => 'boolean',
				'on_off' => false,
				'description' => 'AJAX theme-loading fix — works around themes/JS errors that break the initial load.',
			),
			'cff_disable_resize' => array(
				'type' => 'boolean',
				'on_off' => false,
				'description' => 'Disable local image resizing/storage (raw storage value; the Settings UI shows '
					. 'this inverted, as "Optimize Images"). Auto-forced to false whenever GDPR mode is not "no".',
			),
			'disable_admin_notice' => array(
				'type' => 'boolean',
				'on_off' => false,
				'description' => 'Hide feed-issue admin notices. Read-only for AI assistants '
					. '(an agent must not silence error notices).',
				'writable' => false,
			),
		);
	}

	/**
	 * Build a JSON Schema `properties` map from a table (drops private keys).
	 *
	 * @param array $table
	 * @return array
	 */
	public static function to_json_properties(array $table)
	{
		$out = array();
		foreach ($table as $key => $def) {
			$prop = array('type' => $def['type']);
			foreach (array('enum', 'minimum', 'maximum', 'description') as $k) {
				if (isset($def[$k])) {
					$prop[$k] = $def[$k];
				}
			}
			if ($def['type'] === 'string' && !isset($def['enum'])) {
				$prop['maxLength'] = self::MAX_STRING_LENGTH;
			}
			if (isset($def['format']) && $def['format'] === 'color') {
				$prop['pattern']     = self::COLOR_PATTERN;
				$prop['description'] = (isset($prop['description']) ? $prop['description'] . ' ' : '')
					. 'Hex colour (#rgb, #rrggbb or #rrggbbaa), or empty for the default '
					. '(a bare "#" is also accepted and treated the same as empty).';
			} elseif (isset($def['pattern'])) {
				// A non-colour free-text pattern constraint (e.g. datecustom's
				// NO_MARKUP_PATTERN). Color already set its own pattern above;
				// this is the general case for every other patterned string.
				$prop['pattern'] = $def['pattern'];
			}
			if (isset($def['writable']) && $def['writable'] === false) {
				$prop['readOnly'] = true;
			}
			if (isset($def['tier'])) {
				$prop['x-license-feature'] = $def['tier'];
			}
			$out[$key] = $prop;
		}
		return $out;
	}

	/**
	 * Cast a raw stored value to the declared type for output.
	 *
	 * Stored data is not guaranteed to satisfy the schema (legacy installs,
	 * import/export, a bad save). Core validates our OUTPUT against the schema
	 * and fails the whole ability on one bad value, so anything that does not
	 * satisfy the declared enum / range falls back to $default (the plugin's
	 * own default for that key) rather than being passed through.
	 *
	 * @param array $def     Schema entry for the key.
	 * @param mixed $value   Raw stored value (null when missing).
	 * @param mixed $default Plugin default for the key.
	 * @return mixed
	 */
	public static function cast_out(array $def, $value, $default = null)
	{
		switch ($def['type']) {
			case 'boolean':
				// '' is a legitimate "off" in these plugins, so only a MISSING
				// value takes the default; 'on'/true/1/'1' are the only "on" shapes.
				if ($value === null) {
					$value = $default;
				}
				return $value === true || $value === 'true' || $value === 1 || $value === '1' || $value === 'on';

			case 'integer':
				if ($value === null || $value === '' || !is_numeric($value)) {
					$value = is_numeric($default) ? $default : 0;
				}
				$int = (int) $value;
				// Clamp so the output always satisfies the declared range even if the
				// plugin default itself is ever out of spec.
				if (isset($def['minimum']) && $int < $def['minimum']) {
					$int = (int) $def['minimum'];
				}
				if (isset($def['maximum']) && $int > $def['maximum']) {
					$int = (int) $def['maximum'];
				}
				return $int;

			default:
				$str = is_scalar($value) ? (string) $value : '';
				$is_color = isset($def['format']) && $def['format'] === 'color';
				if ($is_color) {
					// CFF stores unset colours as a bare '#' rather than ''; normalise
					// BEFORE the pattern check below so both directions of the round
					// trip (read via cast_out, write via validate_in) treat '#' and ''
					// identically (B19).
					$str = self::normalize_color($str);
				}

				// Clamp to the declared hex-colour pattern BEFORE the enum/length
				// checks below: a stored value can predate this schema and not be hex
				// at all. '' always satisfies COLOR_PATTERN (it is optional-empty), so
				// it is always a safe last resort even when $default itself does not
				// match.
				$color_regex = self::compiled_pattern(self::COLOR_PATTERN);
				if ($is_color && !preg_match($color_regex, $str)) {
					$fallback_str = is_scalar($default) ? self::normalize_color((string) $default) : '';
					$str          = preg_match($color_regex, $fallback_str) ? $fallback_str : '';
				}

				// Same reasoning for a non-colour patterned string (e.g. datecustom's
				// NO_MARKUP_PATTERN): a value stored before this schema existed can
				// contain characters the pattern now forbids, so it is never passed
				// through unclamped — clamp it to the plugin default, or to '' when
				// even the default doesn't satisfy the pattern.
				if (!$is_color && isset($def['pattern'])) {
					$field_regex = self::compiled_pattern($def['pattern']);
					if (!preg_match($field_regex, $str)) {
						$fallback_str = is_scalar($default) ? (string) $default : '';
						$str          = preg_match($field_regex, $fallback_str) ? $fallback_str : '';
					}
				}

				if (isset($def['enum']) && !in_array($str, $def['enum'], true)) {
					$fallback = is_scalar($default) ? (string) $default : '';
					$str      = in_array($fallback, $def['enum'], true)
						? $fallback
						: (isset($def['enum'][0]) ? (string) $def['enum'][0] : '');
				}

				// Same reasoning again for length: to_json_properties() only declares
				// maxLength on plain strings (never on an enum, which is always
				// short), so truncate rather than fail the whole ability on an
				// over-length stored value.
				if (!isset($def['enum']) && mb_strlen($str) > self::MAX_STRING_LENGTH) {
					$str = mb_substr($str, 0, self::MAX_STRING_LENGTH);
				}

				return $str;
		}
	}

	/**
	 * Writable subset of a table (keys not flagged `writable => false`).
	 *
	 * @param array $table
	 * @return array
	 */
	public static function writable(array $table)
	{
		return array_filter(
			$table,
			function ($def) {
				return !isset($def['writable']) || $def['writable'] !== false;
			}
		);
	}

	/**
	 * Validate + normalise ONE incoming value for storage.
	 *
	 * Core has already validated the request against the JSON Schema, so this
	 * is the second, PHP-side line: it never trusts the transport. Returns the
	 * value to store (as a PHP-native bool/int/string — the SERVICE decides how
	 * to re-encode a boolean for its option's native storage shape), or a
	 * WP_Error (code cff_invalid_value, status 400).
	 *
	 * @param array  $def
	 * @param mixed  $value
	 * @param string $key
	 * @return mixed|\WP_Error
	 */
	public static function validate_in(array $def, $value, $key)
	{
		$bad = function ($reason) use ($key) {
			return new \WP_Error(
				'cff_invalid_value',
				sprintf(
					/* translators: 1: setting key, 2: reason */
					__('Invalid value for %1$s: %2$s', 'custom-facebook-feed'),
					$key,
					$reason
				),
				array('status' => 400)
			);
		};

		switch ($def['type']) {
			case 'boolean':
				if (is_bool($value)) {
					return $value;
				}
				if (in_array($value, array('true', '1', 1, 'on'), true)) {
					return true;
				}
				if (in_array($value, array('false', '0', 0, 'off', ''), true)) {
					return false;
				}
				return $bad(__('expected a boolean', 'custom-facebook-feed'));

			case 'integer':
				if (!is_numeric($value) || (float) $value !== (float) (int) $value) {
					return $bad(__('expected an integer', 'custom-facebook-feed'));
				}
				$int = (int) $value;
				if (isset($def['minimum']) && $int < $def['minimum']) {
					return $bad(sprintf(__('minimum is %d', 'custom-facebook-feed'), $def['minimum']));
				}
				if (isset($def['maximum']) && $int > $def['maximum']) {
					return $bad(sprintf(__('maximum is %d', 'custom-facebook-feed'), $def['maximum']));
				}
				return $int;

			default:
				if (!is_scalar($value)) {
					return $bad(__('expected a string', 'custom-facebook-feed'));
				}
				$str = sanitize_text_field((string) $value);
				$is_color = isset($def['format']) && $def['format'] === 'color';
				if ($is_color) {
					// Same normalisation cast_out() applies on read — an agent replaying
					// a value it just read back (a stored '#') must not be rejected (B19).
					$str = self::normalize_color($str);
				}
				if (isset($def['enum']) && !in_array($str, $def['enum'], true)) {
					return $bad(sprintf(__('allowed values: %s', 'custom-facebook-feed'), implode(', ', $def['enum'])));
				}
				if ($is_color && $str !== '' && !preg_match(self::compiled_pattern(self::COLOR_PATTERN), $str)) {
					return $bad(__('expected a hex colour such as #1877f2', 'custom-facebook-feed'));
				}
				if (!$is_color && isset($def['pattern'])
					&& !preg_match(self::compiled_pattern($def['pattern']), $str)
				) {
					return $bad(__('does not match the allowed pattern for this setting', 'custom-facebook-feed'));
				}
				if (mb_strlen($str) > self::MAX_STRING_LENGTH) {
					return $bad(
						sprintf(__('maximum length is %d characters', 'custom-facebook-feed'), self::MAX_STRING_LENGTH)
					);
				}
				return $str;
		}
	}

	/**
	 * Re-encode a validated PHP boolean back into a key's NATIVE storage
	 * shape. Three shapes exist across CFF's own options/settings_defaults():
	 * `on_off` => 'on'/'off' strings (the majority of per-feed toggles),
	 * `true_false` => literal 'true'/'false' strings (a handful of carousel
	 * keys), and the default (neither flag set) => a real PHP boolean (the
	 * cff_style_settings Advanced-tab convention). See the class docblock for
	 * why this split exists instead of picking one shape for every key.
	 *
	 * @param bool  $value
	 * @param array $def Schema entry for the key.
	 * @return bool|string
	 */
	public static function encode_bool($value, array $def)
	{
		if (!empty($def['on_off'])) {
			return $value ? 'on' : 'off';
		}
		if (!empty($def['true_false'])) {
			return $value ? 'true' : 'false';
		}
		return (bool) $value;
	}

	/**
	 * Normalise CFF's legacy "unset colour" storage shape (a bare '#') to the
	 * empty string. Shared by cast_out() (read) and validate_in() (write) so
	 * a stored '#' and an agent-supplied '#' are always treated identically
	 * (B19).
	 *
	 * @param string $str Value to normalise.
	 * @return string
	 */
	public static function normalize_color($str)
	{
		return $str === '#' ? '' : $str;
	}

	/**
	 * Derive the `dateformat` enum from the plugin's own date-format picker
	 * (AgDR-0504 requirement 1: derive, don't restate) instead of hand-listing
	 * the format codes as literals here, which is exactly how A6 happened —
	 * "custom" was accepted with no enum at all constraining the other values.
	 *
	 * `get_date_format_options()`'s keys are '1'..'19' and 'custom'. PHP casts
	 * every purely-numeric-string array key to a real int (a language
	 * quirk, not a plugin choice), so a bare `array_keys()` here silently
	 * hands back a mix of PHP integers (1, 2, … 19) and the one string
	 * 'custom'. `cast_out()` and `validate_in()` always compare a STRING
	 * (`(string) $value`) against this enum with STRICT `in_array()`, and
	 * core's own output-schema validation applies the same strict,
	 * type-sensitive equality — so a legitimately-stored dateformat like the
	 * plugin's own default ('1') never strict-matches the int `1` in the
	 * enum, `get-feed` 500s on EVERY feed regardless of who created it
	 * (SBR-497 round 4: this is the exact "output_schema too strict" failure
	 * mode AgDR-9004 requirement 1 warns against, self-inflicted by this
	 * schema instead of by a stored value). `array_map('strval', …)`
	 * normalises every key back to the string type the rest of this class
	 * (and JSON Schema's `enum` semantics) already assumes.
	 *
	 * @return string[]
	 */
	private static function dateformat_enum()
	{
		if (!method_exists('\CustomFacebookFeed\Builder\Tabs\CFF_Builder_Customizer_Tab', 'get_date_format_options')) {
			return array();
		}
		return array_map(
			'strval',
			array_keys(\CustomFacebookFeed\Builder\Tabs\CFF_Builder_Customizer_Tab::get_date_format_options())
		);
	}

	/**
	 * Delimit a schema `pattern` string for `preg_match()` (Rex round 2,
	 * finding D). Every call site used to hand-wrap the pattern in literal
	 * `/` delimiters (`'/' . $pattern . '/'`) — safe for COLOR_PATTERN and
	 * NO_MARKUP_PATTERN today, but unsafe for the generic `pattern` field in
	 * general: a future pattern containing an UNESCAPED `/` (a legitimate
	 * regex character with no special meaning to PCRE) would prematurely
	 * terminate the delimited pattern and either throw or, worse, silently
	 * compile into a different, shorter pattern than intended.
	 *
	 * Uses `~` as the delimiter (absent from every pattern this schema
	 * defines today) and escapes any literal `~` in the pattern text so a
	 * pattern that legitimately contains one still compiles correctly
	 * rather than breaking the same way a `/` would with `/`-delimiters.
	 *
	 * @param string $pattern Raw pattern text (no delimiters), e.g. self::NO_MARKUP_PATTERN.
	 * @return string A complete, delimited PCRE pattern ready for preg_match()/preg_replace().
	 */
	private static function compiled_pattern($pattern)
	{
		return '~' . str_replace('~', '\\~', $pattern) . '~';
	}

}
