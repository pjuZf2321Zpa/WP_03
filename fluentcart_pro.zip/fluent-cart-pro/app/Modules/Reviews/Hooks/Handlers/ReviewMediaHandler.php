<?php

namespace FluentCartPro\App\Modules\Reviews\Hooks\Handlers;

use FluentCart\Api\Resource\ProductReviewResource;
use FluentCart\App\Helpers\Status;
use FluentCart\App\Models\ProductReview;
use FluentCart\App\Services\ProductReviewService;
use FluentCart\App\Services\Permission\PermissionManager;
use FluentCart\Framework\Support\Arr;
use FluentCartPro\App\Modules\Reviews\Services\ReviewMediaService;

class ReviewMediaHandler
{
    protected $pendingDeletionMedia = [];

    public function register()
    {
        add_filter('fluent_cart/review/submit_data', [$this, 'injectMediaData'], 10, 3);
        add_filter('fluent_cart/review/submission_status', [$this, 'holdPhotoReviewForModeration'], 10, 3);
        add_filter('fluent_cart/review/update_status', [$this, 'holdPhotoEditForModeration'], 10, 2);
        add_action('fluent_cart/review/after_submit', [$this, 'attachMediaToReview'], 10, 2);
        add_action('fluent_cart/review/after_update', [$this, 'attachMediaOnUpdate'], 10, 2);
        add_filter('fluent_cart/review/submit_response', [$this, 'reportRejectedPhotos']);
        add_filter( 'fluent_cart/review/admin_submit_response', [$this, 'reportRejectedPhotos'] );
        add_action( 'fluent_cart/review/after_delete', [$this, 'cleanupDeletedMedia'] );
        add_action('fluent_cart/review/before_delete', [$this, 'cleanupMedia']);
        add_action('fluent_cart/review/form_extra_fields', [$this, 'renderFormUploadZone'], 10, 3);
        // The customer dashboard's My Reviews form is a Vue component, not
        // the PHP-rendered form above; it draws its own photo zone from
        // these limits and uploads to the same endpoint.
        add_filter('fluent_cart/customer_profile/review_form', [$this, 'addDashboardPhotoConfig']);
        add_action('fluent_cart/scheduler/daily_tasks', [ReviewMediaService::class, 'cleanupOrphanedMedia']);
    }

    public function injectMediaData($data, $request, $postId)
    {
        if ( Arr::get( ProductReviewService::getReviewSettings(), 'enable_photo_reviews' ) !== 'yes' ) {
            return $data;
        }

        $mediaIds = $request->get('media_ids', []);

        if ($mediaIds && !is_array($mediaIds)) {
            $mediaIds = array_filter(array_map('trim', explode(',', (string) $mediaIds)));
        }

        if (!empty($mediaIds)) {
            // Normalize and dedupe BEFORE capping — the same attachment ID
            // repeated must not consume photo slots (or crowd out distinct
            // photos when the payload is at the cap), nor produce duplicate
            // gallery entries downstream.
            $mediaIds = array_values(array_unique(array_filter(array_map('intval', $mediaIds))));

            // Cap to max allowed photos to prevent unbounded processing
            $maxPhotos = ReviewMediaService::getMaxPhotosPerReview();
            $mediaIds = array_slice($mediaIds, 0, $maxPhotos);

            $meta = $data['meta'] ?? [];
            $meta['pending_media_ids'] = $mediaIds;

            // Pass claim tokens for guest ownership validation (keyed by attachment ID)
            $claimTokens = $request->get('media_claim_tokens', []);
            if (is_string($claimTokens) && $claimTokens !== '') {
                $decoded = json_decode(wp_unslash($claimTokens), true);
                if (is_array($decoded)) {
                    $claimTokens = $decoded;
                }
            }
            if (is_array($claimTokens) && !empty($claimTokens)) {
                $sanitized = [];
                foreach ($claimTokens as $attachmentId => $token) {
                    $sanitized[(int) $attachmentId] = sanitize_text_field($token);
                }
                $meta['media_claim_tokens'] = $sanitized;
            }

            $data['meta'] = $meta;
        }

        return $data;
    }

    public function holdPhotoEditForModeration($status, $context): string
    {
        return $this->holdPhotoReviewForModeration($status, $context['data'], $context['request']);
    }

    /**
     * Hold a submission that carries photos until a moderator has seen it,
     * unless the store auto-approves photo reviews too.
     *
     * A photo is the part of a review a store most wants to look at before it
     * is public, so "auto approve reviews" alone does not carry it: both
     * switches have to be on. Off, the review waits however the plain-review
     * switch is set. A submission without photos never reaches this and keeps
     * following auto_approve_reviews on its own.
     *
     * This runs on submission_status rather than submit_data because the
     * latter cannot change status — free captures it as a trust field before
     * that filter and re-imposes it afterwards. The status filter is
     * downgrade-only, which is the right shape here: this holds reviews back
     * and never publishes one the store would have moderated.
     *
     * @param string $status
     * @param array  $data
     * @param mixed  $request
     * @return string
     */
    public function holdPhotoReviewForModeration($status, $data, $request)
    {
        $settings = ProductReviewService::getReviewSettings();

        if (Arr::get($settings, 'enable_photo_reviews') !== 'yes') {
            return $status;
        }

        if (Arr::get($settings, 'auto_approve_photo_reviews') === 'yes') {
            return $status;
        }

        return $this->submissionHasPhotos($request) ? Status::REVIEW_PENDING : $status;
    }

    /**
     * Whether a submission carries photos, read from the request rather than
     * the payload: the ids and files are still only in the request when the
     * status is decided — injectMediaData(), which moves them onto the review,
     * runs later.
     *
     * @param mixed $request
     * @return bool
     */
    protected function submissionHasPhotos($request): bool
    {
        if (!is_object($request) || !is_callable([$request, 'get'])) {
            return false;
        }

        $mediaIds = $request->get('media_ids', []);
        if ($mediaIds && !is_array($mediaIds)) {
            $mediaIds = array_filter(array_map('trim', explode(',', (string) $mediaIds)));
        }
        $mediaIds = is_array($mediaIds) ? array_filter(array_map('intval', $mediaIds)) : [];

        return !empty($mediaIds) || !empty($this->submittedFiles($request));
    }

    /**
     * The files that came with a shopper's submission, as the framework
     * wraps them. Nothing while photo reviews are switched off: the store
     * then offers no upload zone, and a body that carries files anyway is
     * treated as if it carried none — the same refusal the upload endpoint
     * gives. (The admin form is not gated on the setting; it does not pass
     * through here.) files('files') falls back to the whole set when the
     * key is absent, so the key is read from the set instead.
     *
     * @param mixed $request
     * @return array
     */
    protected function submittedFiles($request): array
    {
        // The hooks receive the controller's request guard, which reaches
        // files() through __call — so is_callable, not method_exists.
        if (!is_object($request) || !is_callable([$request, 'files'])) {
            return [];
        }

        if (Arr::get(ProductReviewService::getReviewSettings(), 'enable_photo_reviews') !== 'yes') {
            return [];
        }

        $files = Arr::get((array) $request->files(), 'files', []);

        return is_array($files) ? array_values($files) : [$files];
    }

    /**
     * Where a shopper's pending records are bucketed: the account when
     * signed in, the address otherwise — the same key the upload endpoint
     * used, so a bucket means one thing everywhere.
     */
    protected function bucketKeyFor($postId): string
    {
        $ip = isset($_SERVER['REMOTE_ADDR']) ? sanitize_text_field(wp_unslash($_SERVER['REMOTE_ADDR'])) : '';

        return ReviewMediaService::buildBucketKey((int) $postId, get_current_user_id(), $ip);
    }

    /**
     * The photo upload limits for the dashboard's review form, when photo
     * reviews are on. Same numbers renderFormUploadZone() prints as data
     * attributes for the storefront script.
     *
     * @param array $config
     * @return array
     */
    public function addDashboardPhotoConfig($config)
    {
        $settings = ProductReviewService::getReviewSettings();
        if (Arr::get($settings, 'enable_photo_reviews') !== 'yes') {
            return $config;
        }

        $config['photos'] = [
            'enabled'      => true,
            'max_photos'   => ReviewMediaService::getMaxPhotosPerReview(),
            'max_size_mb'  => ReviewMediaService::getMaxPhotoSizeMb(),
            'accept'       => implode(',', ReviewMediaService::resolveAllowedMimeTypes(ReviewMediaService::getAllowedPhotoTypes())),
            // Relative to the REST base the dashboard already holds; {postId}
            // is filled in per product.
            'upload_route' => 'public/reviews/{postId}/media/upload',
        ];

        return $config;
    }

    public function attachMediaToReview($review, $request)
    {
        if ( Arr::get( ProductReviewService::getReviewSettings(), 'enable_photo_reviews' ) !== 'yes' ) {
            return;
        }

        $meta = $review->meta ?: [];
        $mediaIds = $meta['pending_media_ids'] ?? [];

        if (!empty($mediaIds)) {
            $claimTokens = $meta['media_claim_tokens'] ?? [];
            ReviewMediaService::attachMediaToReview($review, $mediaIds, $claimTokens);

            // Drop the pending claim keys from other_info — they are one-time
            // handshake data (claim tokens must not persist). Re-find first:
            // the service just rewrote other_info with the media refs, and
            // saving through the stale $review instance would clobber them.
            $reloadedReview = ProductReviewResource::find($review->id, ['with' => []]);
            if ($reloadedReview && !is_wp_error($reloadedReview)) {
                $info = $reloadedReview->other_info ?: [];
                unset($info['pending_media_ids'], $info['media_claim_tokens']);
                $reloadedReview->other_info = $info ?: null;
                $reloadedReview->save();
            }
        }

        // The photos that came with the submission itself: stored and
        // attached in this same request, as the admin form's are. Appended,
        // so a form that sent both earlier uploads and files keeps both.
        $files = $this->submittedFiles($request);
        if ($files) {
            // The shared admin submission hook keeps moderator uploads exempt
            // from the shopper quota. Pending claims were counted at upload.
            ReviewMediaService::storeFilesForReview(
                $review, $files, $this->bucketKeyFor($review->post_id), true,
                !PermissionManager::hasPermission( ['reviews/manage'] )
            );
        }
    }

    /**
     * The edit path: the review row is updated first, then its photos.
     * The drawer shows the existing photos as removable previews and sends
     * the ids it kept as media_ids; anything the review had that is not in
     * that list was removed and is deleted. New photos ride on the request
     * as files and are appended after the kept set is settled. When the kept
     * set is what the review already has and no file came, nothing is
     * touched. A request without media_ids at all (the uploader was not on
     * the page) leaves the existing photos alone.
     */
    public function attachMediaOnUpdate($review, $request)
    {
        // after_update fires with ProductReviewResource::update()'s return —
        // a ['message', 'data' => model] envelope, not the model itself.
        if (is_array($review) && isset($review['data'])) {
            $review = $review['data'];
        }
        if (!is_object($review) || empty($review->id)) {
            return;
        }
        /** @var ProductReview $review */

        $files = $this->submittedFiles($request);
        $keptIds = $request->get('media_ids', null);

        if ($keptIds !== null) {
            if (!is_array($keptIds)) {
                $keptIds = array_filter(array_map('trim', explode(',', (string) $keptIds)));
            }
            $keptIds = array_values(array_unique(array_filter(array_map('intval', $keptIds))));
            $keptIds = array_slice($keptIds, 0, ReviewMediaService::getMaxPhotosPerReview());

            $existingIds = array_map(function ($item) {
                return (int) Arr::get($item, 'id', 0);
            }, ReviewMediaService::getMediaForReview($review->id));

            // Only the review's own photos can be kept; an id it never had is
            // not a new photo — those arrive as files — so it is dropped.
            $keptIds = array_values(array_intersect($keptIds, $existingIds));

            if (array_diff($existingIds, $keptIds)) {
                ReviewMediaService::syncMediaForReview($review, $keptIds);
            }
        }

        if ($files) {
            // The shared admin submission hook keeps moderator uploads exempt
            // from the shopper quota. Pending claims were counted at upload.
            ReviewMediaService::storeFilesForReview(
                $review, $files, $this->bucketKeyFor($review->post_id), true,
                !PermissionManager::hasPermission( ['reviews/manage'] )
            );
        }
    }

    /**
     * The review saved, but not every photo sent with it may have: one may
     * be over the size limit, not an image, past the per-review count, or
     * refused by WordPress. The response names each with its reason, so
     * the form can keep those picks and say so, and the success line
     * carries the count so it is heard even where the picks are not seen.
     *
     * @param array $payload message and review
     * @return array
     */
    public function reportRejectedPhotos($payload)
    {
        $rejected = ReviewMediaService::takeRejectedFiles();
        $payload['media_rejected'] = $rejected;

        if ($rejected) {
            $payload['message'] = trim((string) Arr::get($payload, 'message', '')) . ' ' . sprintf(
                /* translators: %d: number of photos that were not saved */
                _n('%d photo could not be saved.', '%d photos could not be saved.', count($rejected), 'fluent-cart-pro'),
                count($rejected)
            );
        }

        return $payload;
    }

    public function cleanupMedia( $review )
    {
        // Capture refs before deletion; physical files cannot be rolled back.
        $this->pendingDeletionMedia[(int) $review->id] = $review->media;
    }

    public function cleanupDeletedMedia( array $payload ): void
    {
        foreach ( Arr::get( $payload, 'reviews', [] ) as $review ) {
            $id = (int) $review->id;
            $items = $this->pendingDeletionMedia[$id] ?? [];
            unset( $this->pendingDeletionMedia[$id] );

            foreach ( $items as $item ) {
                $attachmentId = (int) Arr::get( $item, 'attachment_id', 0 );
                if ( $attachmentId ) {
                    wp_delete_attachment( $attachmentId, true );
                }
            }
        }
    }

    public function renderFormUploadZone($postId, $userId, $existingReview = null)
    {
        $settings = ProductReviewService::getReviewSettings();
        $photoEnabled = Arr::get($settings, 'enable_photo_reviews') === 'yes';

        if (!$photoEnabled) {
            return;
        }

        $maxPhotos = ReviewMediaService::getMaxPhotosPerReview();
        // Printed with a dot whatever the PHP locale: on PHP 7.4 a float
        // cast to string follows LC_NUMERIC, and "0,5" would parse as 0.
        $maxSizeMb = rtrim(rtrim(number_format(ReviewMediaService::getMaxPhotoSizeMb(), 3, '.', ''), '0'), '.');

        $acceptTypes = implode(',', ReviewMediaService::resolveAllowedMimeTypes(ReviewMediaService::getAllowedPhotoTypes()));

        // Edit mode: the drawer edits the visitor's existing review, so the
        // photo step must show its current photos as removable previews —
        // review-storefront.js seeds its state from these items.
        //
        // The renderer hands over the row its own form is bound to, which is
        // the only way these two can agree. Deriving it here from (post, user)
        // used to find the wrong row twice over: a reply carries those same
        // columns and has no media, so the step came up empty on a review that
        // has photos; and on a product with variations it could seed from
        // another variation's review entirely.
        $existingMedia = [];
        if ($userId && $existingReview && !empty($existingReview->id)) {
            $existingMedia = ReviewMediaService::getMediaForReview($existingReview->id);
        }

        $existingIds = array_filter(array_map(function ($item) {
            return (int) Arr::get($item, 'id', 0);
        }, $existingMedia));
        ?>
        <div class="fct-review-form-field fct-review-upload-zone" data-review-upload-zone
             data-max-photos="<?php echo esc_attr($maxPhotos); ?>"
             data-max-size-mb="<?php echo esc_attr($maxSizeMb); ?>"
             data-accept="<?php echo esc_attr($acceptTypes); ?>"
        >
            <label><?php esc_html_e('Photos', 'fluent-cart-pro'); ?></label>
            <div class="fct-review-upload-area" data-review-upload-area>
                <input type="file" multiple accept="<?php echo esc_attr($acceptTypes); ?>"
                       class="fct-review-file-input" data-review-file-input
                       style="display:none;"/>
                <div class="fct-review-upload-placeholder" data-review-upload-placeholder
                     role="button" tabindex="0"
                     aria-label="<?php esc_attr_e('Add photos', 'fluent-cart-pro'); ?>">
                    <span class="fct-review-upload-icon" aria-hidden="true">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M14.5 4h-5L7.8 6H4a2 2 0 0 0-2 2v10a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-3.8L14.5 4z"/><circle cx="12" cy="13" r="3.4"/></svg>
                    </span>
                    <span class="fct-review-upload-text">
                        <?php
                        printf(
                            /* translators: %d - max number of photos */
                            esc_html__('Click or drag photos here (max %d)', 'fluent-cart-pro'),
                            $maxPhotos
                        );
                        ?>
                    </span>
                </div>
                <div class="fct-review-upload-previews" data-review-upload-previews>
                    <?php foreach ($existingMedia as $mediaItem) : ?>
                        <?php if (!Arr::get($mediaItem, 'id') || !Arr::get($mediaItem, 'url')) { continue; } ?>
                        <div class="fct-upload-preview-item" data-existing-media data-media-id="<?php echo esc_attr(Arr::get($mediaItem, 'id')); ?>">
                            <img class="fct-upload-thumb" src="<?php echo esc_url(Arr::get($mediaItem, 'url')); ?>" alt="<?php echo esc_attr(Arr::get($mediaItem, 'name', '')); ?>"/>
                            <button type="button" class="fct-upload-remove" data-existing-remove aria-label="<?php esc_attr_e('Remove photo', 'fluent-cart-pro'); ?>"><svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" aria-hidden="true"><path d="M18 6 6 18"/><path d="m6 6 12 12"/></svg></button>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
            <input type="hidden" name="media_ids" value="<?php echo esc_attr(implode(',', $existingIds)); ?>" data-review-media-ids/>
        </div>
        <?php
    }
}
