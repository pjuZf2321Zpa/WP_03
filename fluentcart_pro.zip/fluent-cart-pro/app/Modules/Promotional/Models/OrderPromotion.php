<?php

namespace FluentCartPro\App\Modules\Promotional\Models;

use FluentCart\App\Models\Model;

/**
 *
 *  Database Model for Order Promotions
 *
 * @package FluentCartPro\App\Modules\Promotional
 *
 * @version 1.0.0
 */
class OrderPromotion extends Model
{
    const ACTIVE_BUMPS_CACHE_KEY = 'active_bumps';
    const CACHE_GROUP = 'fluent_cart_order_bumps';

    protected $table = 'fct_order_promotions';

    protected $primaryKey = 'id';

    protected $guarded = ['id'];

    protected $fillable = [
        'hash',
        'parent_id',
        'type',
        'status',
        'src_object_id',
        'src_object_type',
        'title',
        'description',
        'conditions',
        'config',
        'priority',
    ];

    public static function boot()
    {
        parent::boot();
        static::creating(function ($model) {
            if (empty($model->hash)) {
                $model->hash = md5('fct_promotion_' . wp_generate_uuid4() . time());
            }

            if (empty($model->conditions)) {
                $model->conditions = json_encode([]);
            }

            if (empty($model->config)) {
                $model->config = json_encode([]);
            }

        });

        // The shop reads the active bumps from the object cache, so a change must drop it.
        static::saved(function () {
            static::clearActiveCache();
        });

        static::deleted(function () {
            static::clearActiveCache();
        });
    }

    /**
     * Called by the model events above, and by any write that bypasses them (a bulk query fires none).
     * It moves the group's version on, so a read that started before the change cannot store its old
     * list over the new one.
     */
    public static function clearActiveCache()
    {
        wp_cache_set_last_changed(static::CACHE_GROUP);
    }

    public function setConditionsAttribute($value)
    {
        if (is_array($value) || is_object($value)) {
            $value = json_encode($value, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        }
        $this->attributes['conditions'] = $value;
    }

    public function getConditionsAttribute($value)
    {
        if (is_string($value)) {
            return json_decode($value, true);
        }
        return $value;
    }

    public function setConfigAttribute($value)
    {
        if (is_array($value) || is_object($value)) {
            $value = json_encode($value, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        }
        $this->attributes['config'] = $value;
    }

    public function getConfigAttribute($value)
    {
        if (is_string($value)) {
            return json_decode($value, true);
        }

        return $value;
    }

    public function product_variant()
    {
        return $this->belongsTo(\FluentCart\App\Models\ProductVariation::class, 'src_object_id', 'id');
    }
}


