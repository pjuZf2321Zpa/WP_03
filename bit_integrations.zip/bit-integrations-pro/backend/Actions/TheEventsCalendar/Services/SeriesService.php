<?php

namespace BitApps\IntegrationsPro\Actions\TheEventsCalendar\Services;

use BitApps\IntegrationsPro\Actions\TheEventsCalendar\TheEventsCalendarHelper;
use TEC\Events_Pro\Custom_Tables\V1\Series\Relationship;

if (!\defined('ABSPATH')) {
    exit;
}

final class SeriesService extends BaseService
{
    public function createSeries(): array
    {
        $error = $this->validateRequiredFields(['title' => __('Series Title', 'bit-integrations-pro')]);

        if ($error !== null) {
            return $error;
        }

        if (!TheEventsCalendarHelper::isProActive()) {
            return $this->proRequired();
        }

        $postStatus = (string) $this->getPostStatus('publish');

        // Save as a draft first, so the Series Created trigger sees the linked events when the series is published.
        $seriesId = wp_insert_post(
            [
                'post_type'    => TheEventsCalendarHelper::SERIES_POST_TYPE,
                'post_title'   => $this->getString('title'),
                'post_content' => $this->getString('description'),
                'post_status'  => 'draft',
            ],
            true
        );

        if (is_wp_error($seriesId)) {
            return $this->errorResponse($seriesId->get_error_message());
        }

        $eventIds = array_values(
            array_filter(
                $this->getIdList('event_ids'),
                function ($eventId) {
                    return TheEventsCalendarHelper::isPostOfType($eventId, TheEventsCalendarHelper::EVENT_POST_TYPE);
                }
            )
        );

        if (!empty($eventIds)) {
            tribe(Relationship::class)->with_series(get_post($seriesId), $eventIds, false);
        }

        if ($postStatus !== 'draft') {
            wp_update_post(['ID' => $seriesId, 'post_status' => $postStatus]);
        }

        return $this->successResponse(__('The series is created.', 'bit-integrations-pro'), TheEventsCalendarHelper::getSeriesData($seriesId));
    }

    public function addEventToSeries(): array
    {
        $error = $this->validateRequiredFields([
            'event_id'  => __('Event ID', 'bit-integrations-pro'),
            'series_id' => __('Series', 'bit-integrations-pro'),
        ]);

        if ($error !== null) {
            return $error;
        }

        if (!TheEventsCalendarHelper::isProActive()) {
            return $this->proRequired();
        }

        $eventId = (int) $this->getInteger('event_id');
        $seriesId = (int) $this->getInteger('series_id');

        if (!TheEventsCalendarHelper::isPostOfType($eventId, TheEventsCalendarHelper::EVENT_POST_TYPE)) {
            return $this->errorResponse(__('Event not found. Map the ID of an existing event.', 'bit-integrations-pro'));
        }

        if (!TheEventsCalendarHelper::isPostOfType($seriesId, TheEventsCalendarHelper::SERIES_POST_TYPE)) {
            return $this->errorResponse(__('Series not found. Select an existing series.', 'bit-integrations-pro'));
        }

        if (!\in_array($eventId, TheEventsCalendarHelper::getSeriesEventIds($seriesId), true)) {
            tribe(Relationship::class)->with_series(get_post($seriesId), [$eventId], false);
        }

        if (!\in_array($eventId, TheEventsCalendarHelper::getSeriesEventIds($seriesId), true)) {
            return $this->errorResponse(__('Failed to add the event to the series. Save the event dates in The Events Calendar and try again.', 'bit-integrations-pro'));
        }

        $eventData = TheEventsCalendarHelper::getEventData($eventId);
        $eventData['series'] = TheEventsCalendarHelper::getSeriesData($seriesId);

        return $this->successResponse(__('The event is added to the series.', 'bit-integrations-pro'), $eventData);
    }

    private function proRequired(): array
    {
        return $this->errorResponse(__('The Events Calendar Pro is not active. Activate Pro to use this action.', 'bit-integrations-pro'));
    }
}
