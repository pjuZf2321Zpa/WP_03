<?php

namespace FluentCartPro\App\Modules\InlineCheckout\Scheduler;

use FluentCart\App\Models\Cart;
use FluentCart\App\Services\DateTime\DateTime;
use FluentCartPro\App\Modules\InlineCheckout\Cart\InlineCartService;

/**
 * Drops selector carts nobody came back to within a day.
 *
 * These are minted per PAGE, by the shopper's browser, on the first sign of
 * purchase intent — one row per landing page a visitor engages with. They
 * accumulate far faster than the site cart ever did, and the device only
 * remembers which row belongs to which page for 24 hours
 * (InlineCartService::PAGE_COOKIE_LIFETIME). A row older than that is
 * unreachable by the shopper who created it: the cookie entry pointing at it
 * has already expired. That is what makes 24 hours the right number rather than
 * an arbitrary one.
 *
 * HOURLY, not daily, because the cut-off is meant to be 24 hours and a daily
 * pass cannot deliver that: a cart turning 24 hours old just after a run waits
 * for the next one and survives closer to 48. Hourly bounds the overshoot to an
 * hour. The query is indexed-cheap and usually matches nothing.
 *
 * Scoped to the selector's own group on purpose. Core's 30-day sweep still owns
 * `global` and `instant` rows — those are the shopper's real basket, and
 * clearing them after a day would throw away a cart somebody is still using.
 */
class AbandonedInlineCartSweeper
{
    /**
     * How long a batch may run before it yields.
     */
    const TIME_BUDGET_SECONDS = 20;

    /**
     * @return void
     */
    public function register(): void
    {
        // Priority 50 keeps this behind core's own hourly work, so a slow sweep
        // cannot starve subscription expiry.
        add_action('fluent_cart/scheduler/hourly_tasks', [$this, 'sweep'], 50);
    }

    /**
     * @return void
     */
    public function sweep(): void
    {
        $startedAt = time();

        $hours = (int)apply_filters('fluent_cart/cleanup/abandoned_inline_cart_hours', 24);

        // A store owner disabling the sweep must not delete everything.
        if ($hours < 1) {
            return;
        }

        // Compared in UTC because that is how the column is written
        // (DateTime::gmtNow()). Local time would shift the cut-off by the
        // site's offset — harmless at 30 days, a real error at 24 hours.
        $cutoff = gmdate('Y-m-d H:i:s', strtotime('-' . $hours . ' hours', strtotime(DateTime::gmtNow())));

        // Iterative rather than recursive: core's sweep recurses against a
        // private field on its own scheduler, which a listener cannot see, so
        // this owns its budget and its loop.
        while ((time() - $startedAt) <= self::TIME_BUDGET_SECONDS) {
            $carts = Cart::query()
                ->where('cart_group', InlineCartService::CART_GROUP)
                // A row attached to a real order is order history, not an
                // abandoned basket.
                ->stageNotCompleted()
                ->where('updated_at', '<=', $cutoff)
                ->limit(1000)
                ->get();

            if ($carts->isEmpty()) {
                return;
            }

            foreach ($carts as $cart) {
                $cart->delete();
            }
        }
    }
}
