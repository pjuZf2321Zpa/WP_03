<?php

namespace WPAICG\Lib\Chat\Triggers;

use WPAICG\Lib\Chat\Triggers\Actions\AIPKit_Action_Bot_Reply;
use WPAICG\Lib\Chat\Triggers\Actions\AIPKit_Action_Inject_Context;
use WPAICG\Lib\Chat\Triggers\Actions\AIPKit_Action_Block_Message;
use WPAICG\Lib\Chat\Triggers\Actions\AIPKit_Action_Call_Webhook;
use WPAICG\Lib\Chat\Triggers\Actions\AIPKit_Action_Set_Variable;
use WPAICG\Lib\Chat\Triggers\Actions\AIPKit_Action_Store_Form_Submission;
use WPAICG\Lib\Chat\Triggers\Actions\AIPKit_Action_Display_Form;
use WPAICG\Chat\Storage\LogStorage;

use WP_Error;

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

/**
 * AIPKit_Trigger_Action_Executor
 *
 * Executes defined actions based on trigger configurations by delegating to specific action classes.
 */
class AIPKit_Trigger_Action_Executor {

    private $action_handlers = [];
    private $log_storage;

    public function __construct(?LogStorage $log_storage = null) {
        $this->log_storage = $log_storage;

        // Register only the handlers available when this executor is constructed.
        $handlers = [
            'bot_reply' => AIPKit_Action_Bot_Reply::class,
            'inject_context' => AIPKit_Action_Inject_Context::class,
            'block_message' => AIPKit_Action_Block_Message::class,
            'call_webhook' => AIPKit_Action_Call_Webhook::class,
            'set_variable' => AIPKit_Action_Set_Variable::class,
            'store_form_submission' => AIPKit_Action_Store_Form_Submission::class,
            'display_form' => AIPKit_Action_Display_Form::class,
        ];
        foreach ($handlers as $type => $class) {
            if (class_exists($class)) {
                $this->action_handlers[$type] = new $class();
            }
        }
    }

    /**
     * Executes a given action object by delegating to the appropriate handler.
     *
     * @param array $action_object The action object from the trigger configuration.
     *                             Expected structure: ['type' => string, 'payload' => array]
     * @param array $context_data  Contextual data for the current event (e.g., user message, bot settings).
     * @param int   $bot_id        The ID of the current chatbot.
     * @return array|WP_Error An array describing the result or action to be taken, or WP_Error on failure.
     */
    public function execute_action(array $action_object, array $context_data, int $bot_id) {
        $action_type = $action_object['type'] ?? null;
        $action_payload = $action_object['payload'] ?? [];
        $action_value = $action_object['value'] ?? null; // For set_variable, value is top-level in action_object

        if (empty($action_type)) {
            return new WP_Error('missing_action_type', __('Action type is missing.', 'gpt3-ai-content-generator'));
        }

        if (isset($this->action_handlers[$action_type])) {
            // For set_variable, the value is passed directly in the action_object, not its payload.
            // So, we merge it into the payload for the handler if it's a set_variable action.
            if ($action_type === 'set_variable' && $action_value !== null) {
                $action_payload['value'] = $action_value;
            }
            if ($action_type === 'store_form_submission') {
                 if (!$this->log_storage) {
                    return new WP_Error('missing_log_storage', __('Log storage service is unavailable for storing form submission.', 'gpt3-ai-content-generator'));
                 }
                return $this->action_handlers[$action_type]->execute($action_payload, $context_data, $bot_id, $this->log_storage);
            }
            return $this->action_handlers[$action_type]->execute($action_payload, $context_data, $bot_id);
        } else {
            /* translators: %s is the action type */
            return new WP_Error('unknown_action_type', sprintf(__('Unknown or unhandled action type: %s', 'gpt3-ai-content-generator'), $action_type));
        }
    }
}
