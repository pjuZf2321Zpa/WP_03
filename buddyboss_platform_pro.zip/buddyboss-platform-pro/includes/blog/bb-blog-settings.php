<?php
/**
 * BuddyBoss Pro Blog — Settings 2.0 enrichment.
 *
 * Platform's base `blogging` feature registers the Post Settings section with
 * the Bookmarking and Subscriptions toggles as `pro_only` placeholders. This
 * file unlocks them (flips `pro_only` off and injects the real saved value)
 * when a valid Pro license is present, mirroring how Platform Pro unlocks the
 * Group Headers fields.
 *
 * @package BuddyBossPro
 *
 * @since 3.1.0
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

/**
 * Unlock the blog Post Settings fields when the license is valid.
 *
 * Hooked to `bb_admin_settings_format_field_data`, which runs while the AJAX
 * handler formats each field for the React admin. When bookmarking or
 * subscriptions are locked (no valid license) the fields are left as-is, so
 * they render as "UPGRADE PRO" placeholders whose writes the AJAX handler
 * skips.
 *
 * @since 3.1.0
 *
 * @param array  $field_data Formatted field data sent to React.
 * @param array  $field      Original field registration data.
 * @param string $feature_id Feature the field belongs to.
 *
 * @return array
 */
function bb_blog_pro_enrich_settings_field_data( $field_data, $field, $feature_id ) { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter.FoundInMiddle -- $field is required by the filter signature; dispatch is on $feature_id and the field name.
	if ( 'blogging' !== $feature_id ) {
		return $field_data;
	}

	$name = ! empty( $field_data['name'] ) ? $field_data['name'] : '';

	if ( 'bb_blog_enable_bookmarking' !== $name && 'bb_blog_enable_subscriptions' !== $name ) {
		return $field_data;
	}

	// Locked: leave the pro_only placeholder in place.
	if ( ! bb_blog_pro_is_license_unlocked() ) {
		return $field_data;
	}

	$field_data['pro_only'] = false;
	$field_data['value']    = (int) bp_get_option( $name, 0 );

	return $field_data;
}
add_filter( 'bb_admin_settings_format_field_data', 'bb_blog_pro_enrich_settings_field_data', 10, 3 );
