<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Actions\Bookly\BooklyRecordHelper;
use BitApps\IntegrationsPro\Config;
use BitApps\IntegrationsPro\Core\Util\Hooks;

Hooks::filter(Config::withFreePrefix('bookly_create_appointment'), [BooklyRecordHelper::class, 'createAppointment'], 10, 3);
Hooks::filter(Config::withFreePrefix('bookly_update_appointment_status'), [BooklyRecordHelper::class, 'updateAppointmentStatus'], 10, 3);
Hooks::filter(Config::withFreePrefix('bookly_delete_appointment'), [BooklyRecordHelper::class, 'deleteAppointment'], 10, 2);
Hooks::filter(Config::withFreePrefix('bookly_create_customer'), [BooklyRecordHelper::class, 'createCustomer'], 10, 2);
Hooks::filter(Config::withFreePrefix('bookly_update_customer'), [BooklyRecordHelper::class, 'updateCustomer'], 10, 2);
Hooks::filter(Config::withFreePrefix('bookly_delete_customer'), [BooklyRecordHelper::class, 'deleteCustomer'], 10, 2);
