<?php

namespace BitApps\IntegrationsPro\Actions\PaidMembershipPro;

use PMPro_Field_Group;

class PaidMembershipProHelper
{
    private const DIRECTORY_META_KEY = 'pmpromd_hide_directory';

    private const UNSUPPORTED_FIELD_TYPES = ['file', 'html'];

    private const MULTI_VALUE_FIELD_TYPES = ['checkbox_grouped', 'select2', 'multiselect'];

    private const PRIVILEGED_CAPABILITIES = ['manage_options', 'promote_users', 'list_users', 'edit_posts'];

    public static function profileFields($defaultFields = [])
    {
        $fields = [];
        $coreFields = self::coreProfileFields();

        foreach ($coreFields as $key => $label) {
            $fields[] = ['key' => $key, 'label' => $label, 'required' => false];
        }

        foreach (self::customProfileFields() as $field) {
            if (isset($coreFields[$field->name])) {
                continue;
            }

            $fields[] = ['key' => $field->name, 'label' => $field->label ?: $field->name, 'required' => false];
        }

        return $fields;
    }

    public static function updateProfile($defaultResponse, $data, $userId, $integrationDetails = null)
    {
        if (empty($data)) {
            return self::errorResponse(__('No mapped profile field has a value.', 'bit-integrations-pro'));
        }

        $user = get_userdata($userId);

        if (!$user) {
            return self::errorResponse(__('User not found.', 'bit-integrations-pro'));
        }

        $coreData = self::sanitizeCoreProfileData(array_intersect_key($data, self::coreProfileFields()));

        if (isset($coreData['user_email']) && strcasecmp($user->user_email, $coreData['user_email']) === 0) {
            unset($coreData['user_email']);
        }

        if (isset($coreData['user_email'])) {
            $emailError = self::validateProfileEmail($coreData['user_email'], $userId, $integrationDetails->userSource ?? '');

            if ($emailError) {
                return self::errorResponse($emailError);
            }
        }

        if (!empty($coreData)) {
            $result = wp_update_user(['ID' => $userId] + $coreData);

            if (is_wp_error($result)) {
                return self::errorResponse($result->get_error_message());
            }
        }

        $skipped = self::saveCustomProfileFields(array_diff_key($data, self::coreProfileFields()), $userId);
        $updated = array_values(array_diff(array_keys($data), $skipped));

        if (empty($updated)) {
            return self::errorResponse(__('None of the mapped fields can be saved.', 'bit-integrations-pro'), ['skipped' => $skipped]);
        }

        return self::successResponse(
            __('User profile updated successfully', 'bit-integrations-pro'),
            ['updated' => $updated, 'skipped' => $skipped]
        );
    }

    public static function updateDirectoryVisibility($defaultResponse, $visibility, $userId)
    {
        if (!\function_exists('pmpromd_save_extra_profile_fields')) {
            return self::errorResponse(__('Paid Memberships Pro - Member Directory Add On is not active.', 'bit-integrations-pro'));
        }

        if (!\in_array($visibility, ['show', 'hide'], true)) {
            return self::errorResponse(__('Directory visibility must be show or hide.', 'bit-integrations-pro'));
        }

        if (!get_userdata($userId)) {
            return self::errorResponse(__('User not found.', 'bit-integrations-pro'));
        }

        update_user_meta($userId, self::DIRECTORY_META_KEY, $visibility === 'hide' ? '1' : '');

        $message = $visibility === 'hide'
            ? __('User hidden from the member directory', 'bit-integrations-pro')
            : __('User shown in the member directory', 'bit-integrations-pro');

        if ($visibility === 'show' && \function_exists('pmpro_hasMembershipLevel') && !pmpro_hasMembershipLevel(null, $userId)) {
            $message = __('User is set to show in the member directory, but the directory lists only active members and this user has no membership level.', 'bit-integrations-pro');
        }

        return self::successResponse($message);
    }

    private static function coreProfileFields()
    {
        return [
            'user_email'   => __('Email', 'bit-integrations-pro'),
            'first_name'   => __('First Name', 'bit-integrations-pro'),
            'last_name'    => __('Last Name', 'bit-integrations-pro'),
            'display_name' => __('Display Name', 'bit-integrations-pro'),
            'nickname'     => __('Nickname', 'bit-integrations-pro'),
            'user_url'     => __('Website', 'bit-integrations-pro'),
            'description'  => __('Biographical Info', 'bit-integrations-pro'),
        ];
    }

    private static function customProfileFields()
    {
        if (!class_exists('PMPro_Field_Group')) {
            return [];
        }

        $fields = [];

        foreach (PMPro_Field_Group::get_all() as $group) {
            foreach ($group->get_fields() as $field) {
                if (!empty($field->name) && !\in_array($field->type, self::UNSUPPORTED_FIELD_TYPES, true)) {
                    $fields[$field->name] = $field;
                }
            }
        }

        return $fields;
    }

    private static function sanitizeCoreProfileData($data)
    {
        $sanitized = [];

        foreach ($data as $key => $value) {
            $value = \is_array($value) ? implode(', ', array_filter($value, 'is_scalar')) : (string) $value;

            if ($key === 'user_email') {
                $sanitized[$key] = sanitize_email($value);
            } elseif ($key === 'user_url') {
                $sanitized[$key] = esc_url_raw($value);
            } elseif ($key === 'description') {
                $sanitized[$key] = sanitize_textarea_field($value);
            } else {
                $sanitized[$key] = sanitize_text_field($value);
            }
        }

        return $sanitized;
    }

    private static function validateProfileEmail($email, $userId, $userSource)
    {
        if ($userSource === 'email') {
            return __('The email address can\'t be changed when the user is matched by email.', 'bit-integrations-pro');
        }

        if (!is_email($email)) {
            return __('The email address isn\'t correct.', 'bit-integrations-pro');
        }

        $ownerId = email_exists($email);

        if ($ownerId && (int) $ownerId !== (int) $userId) {
            return __('This email is already registered to another user.', 'bit-integrations-pro');
        }

        foreach (self::PRIVILEGED_CAPABILITIES as $capability) {
            if (user_can($userId, $capability)) {
                return __('The email address of a user who can edit content or manage the site can\'t be changed by this action.', 'bit-integrations-pro');
            }
        }

        return '';
    }

    private static function saveCustomProfileFields($data, $userId)
    {
        $fields = self::customProfileFields();
        $skipped = [];

        foreach ($data as $name => $value) {
            if (!isset($fields[$name])) {
                $skipped[] = $name;

                continue;
            }

            self::saveCustomProfileField($fields[$name], self::sanitizeCustomFieldValue($fields[$name], $value), $userId);
        }

        return $skipped;
    }

    private static function sanitizeCustomFieldValue($field, $value)
    {
        $isMultiValue = \in_array($field->type, self::MULTI_VALUE_FIELD_TYPES, true) || ($field->type === 'select' && !empty($field->multiple));

        if ($isMultiValue && !\is_array($value)) {
            $value = array_values(array_filter(array_map('trim', explode(',', (string) $value)), 'strlen'));
        }

        if (\is_array($value)) {
            return array_map('sanitize_text_field', $value);
        }

        return $field->type === 'textarea' ? sanitize_textarea_field($value) : sanitize_text_field($value);
    }

    private static function saveCustomProfileField($field, $value, $userId)
    {
        if (self::hasCustomSaveFunction($field)) {
            \call_user_func($field->save_function, $userId, $field->name, $value, $field);

            return;
        }

        $userTableFields = (array) apply_filters('pmpro_user_table_fields', ['user_url']);

        if (\in_array($field->name, $userTableFields, true)) {
            wp_update_user(['ID' => $userId, $field->name => $field->name === 'user_url' ? esc_url_raw($value) : $value]);

            return;
        }

        if (isset($field->taxonomy) && !empty($field->taxonomy)) {
            self::saveTaxonomyField($field, $value, $userId);

            return;
        }

        update_user_meta($userId, $field->meta_key, $value);
    }

    private static function hasCustomSaveFunction($field)
    {
        if (!isset($field->save_function) || !\is_callable($field->save_function)) {
            return false;
        }

        $saveFunction = $field->save_function;

        return !(\is_array($saveFunction) && ($saveFunction[0] ?? null) === $field);
    }

    private static function saveTaxonomyField($field, $value, $userId)
    {
        $terms = [];

        foreach ((array) $value as $term) {
            if (is_numeric($term)) {
                $termObject = get_term_by('ID', $term, $field->taxonomy);

                if (!$termObject) {
                    continue;
                }

                $term = $termObject->name;
            }

            $terms[] = $term;
        }

        wp_set_object_terms($userId, $terms, $field->taxonomy, false);
        clean_object_term_cache($userId, $field->taxonomy);
        update_user_meta($userId, str_replace('pmprorhprefix_', '', $field->name), $value);
    }

    private static function successResponse($message, $data = [])
    {
        return ['success' => true, 'message' => $message] + $data;
    }

    private static function errorResponse($message, $data = [])
    {
        return ['success' => false, 'message' => $message] + $data;
    }
}
