<?php

namespace FluentCartPro\App\Hooks\Handlers\BlockEditors\EmailBlocks;

use FluentCart\App\App;
use FluentCart\App\Hooks\Handlers\BlockEditors\BlockEditor;
use FluentCart\App\Services\TemplateService;
use FluentCart\Framework\Support\Arr;

class CelebrationBlockEditor extends BlockEditor
{
    use \FluentCartPro\App\Contracts\CanEnqueue;
    protected static string $editorName = 'celebration';

    public function getScripts(): array
    {
        return [
            [
                'source'       => 'admin/BlockEditor/EmailBlocks/Celebration/CelebrationBlockEditor.jsx',
                'dependencies' => ['wp-blocks', 'wp-components', 'wp-server-side-render']
            ]
        ];
    }

    public function getStyles(): array
    {
        return [
            'admin/BlockEditor/EmailBlocks/Celebration/style/celebration-block-editor.scss'
        ];
    }

    public function localizeData(): array
    {
        $notificationKey = isset($_REQUEST['bid']) ? sanitize_text_field($_REQUEST['bid']) : '';
        $celebrationType = (strpos($notificationKey, 'renewal') !== false) ? 'renewal' : 'order';

        return [
            $this->getLocalizationKey()     => [
                'slug'             => $this->slugPrefix,
                'name'             => static::getEditorName(),
                'title'            => __('Celebration', 'fluent-cart-pro'),
                'description'      => __('Displays a colorful celebration banner with a random congratulatory message.', 'fluent-cart-pro'),
                'celebration_type' => $celebrationType,
            ],
            'fluent_cart_pro_block_translation' => \FluentCartPro\App\Services\Translations\Translations::blockStrings(),
        ];
    }

    public function blockAttributes(): array
    {
        return [
            'celebration_type' => [
                'type'    => 'string',
                'default' => 'auto',
            ],
        ];
    }

    public function supports(): array
    {
        return [
            'html'    => false,
            'align'   => true,
            'spacing' => [
                'margin'  => true,
                'padding' => true,
            ],
        ];
    }

    public function render(array $shortCodeAttribute, $block = null, $content = ''): string
    {
        $celebrationType = sanitize_text_field(Arr::get($shortCodeAttribute, 'celebration_type', 'auto'));

        if (!in_array($celebrationType, ['auto', 'order', 'renewal'], true)) {
            $celebrationType = 'auto';
        }

        if ($celebrationType === 'auto') {
            $notificationKey = isset($_REQUEST['bid']) ? sanitize_text_field($_REQUEST['bid']) : '';
            $celebrationType = (strpos($notificationKey, 'renewal') !== false) ? 'renewal' : 'order';
        }

        $text = TemplateService::getCelebration($celebrationType);

        if (empty($text)) {
            return '';
        }

        $celebrationHtml = App::make('view')->make('emails.parts.celebration', [
            'text' => $text
        ]);

        $wrapperAttributes = get_block_wrapper_attributes();

        return sprintf(
            '<div %s>%s</div>',
            $wrapperAttributes,
            $celebrationHtml
        );
    }
}
