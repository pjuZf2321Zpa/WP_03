<?php

namespace CustomFacebookFeed\Integrations\Elementor;

use FacebookFeed\Vendor\Smashballoon\Framework\Packages\Blocks\SB_Elementor_Feed_Widget;
use CustomFacebookFeed\Builder\CFF_Db;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( '\Elementor\Widget_Base' ) ) {
	return;
}

/**
 * Modern Elementor widget for Facebook Feed.
 *
 * Extends the shared SB_Elementor_Feed_Widget framework to register a
 * modern Elementor widget with feed selection and shortcode-based rendering.
 *
 * @since 4.8
 */
class CFF_Modern_Elementor_Widget extends SB_Elementor_Feed_Widget {

	/**
	 * Get the widget name.
	 *
	 * @since 4.8
	 *
	 * @return string
	 */
	protected function get_widget_name() {
		return 'sb-facebook-feed';
	}

	/**
	 * Get the widget title.
	 *
	 * @since 4.8
	 *
	 * @return string
	 */
	protected function get_widget_title() {
		return __( 'Facebook Feed', 'custom-facebook-feed' );
	}

	/**
	 * Get the widget icon CSS class.
	 *
	 * @since 4.8
	 *
	 * @return string
	 */
	protected function get_widget_icon() {
		return 'sb-elem-icon sb-elem-facebook';
	}

	/**
	 * Get the shortcode tag used for rendering.
	 *
	 * @since 4.8
	 *
	 * @return string
	 */
	protected function get_shortcode_tag() {
		return 'custom-facebook-feed';
	}

	/**
	 * Get the feeds options for the widget dropdown.
	 *
	 * @since 4.8
	 *
	 * @return array
	 */
	protected function get_feeds_options() {
		$feeds = CFF_Db::elementor_feeds_query();
		unset( $feeds[0] );
		return $feeds;
	}

	/**
	 * Get the text domain for translations.
	 *
	 * @since 4.8
	 *
	 * @return string
	 */
	protected function get_text_domain() {
		return 'custom-facebook-feed';
	}

	/**
	 * Get the JavaScript dependencies for the widget.
	 *
	 * @since 4.8
	 *
	 * @return array
	 */
	protected function get_script_deps() {
		// 'elementor-preview' heals the masonry layout, which collapses in the
		// Chromium editor preview iframe. See admin/assets/js/elementor-preview.js.
		return array( 'cffscripts', 'sb-elementor-editor', 'elementor-preview' );
	}

	/**
	 * Get the CSS style dependencies for the widget.
	 *
	 * @since 4.8
	 *
	 * @return array
	 */
	protected function get_style_deps() {
		return array( 'cff', 'sb-elementor-editor' );
	}

	/**
	 * Get the output filter hook name.
	 *
	 * @since 4.8
	 *
	 * @return string
	 */
	protected function get_output_filter() {
		return 'cff_output';
	}
}
