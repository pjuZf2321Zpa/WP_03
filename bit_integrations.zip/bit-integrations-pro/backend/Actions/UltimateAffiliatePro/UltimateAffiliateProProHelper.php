<?php

namespace BitApps\IntegrationsPro\Actions\UltimateAffiliatePro;

use UapDb;

final class UltimateAffiliateProProHelper
{
    public static function createAffiliate($defaultResponse, $fieldData)
    {
        if (!self::isPluginInstalled()) {
            return self::errorResponse(__('Ultimate Affiliate Pro is not installed or activated', 'bit-integrations-pro'));
        }

        if (!self::hasFieldValue($fieldData, 'user_identifier')) {
            return self::errorResponse(__('User Identifier is required', 'bit-integrations-pro'));
        }

        $userIdentifier = $fieldData['user_identifier'];
        $user = self::getUser($userIdentifier);

        if (!$user) {
            return self::errorResponse(__('User not found with the provided identifier', 'bit-integrations-pro'));
        }

        global $indeed_db;

        if (
            !\is_object($indeed_db)
            || !method_exists($indeed_db, 'save_affiliate')
            || !method_exists($indeed_db, 'get_affiliate_id_by_wpuid')
        ) {
            return self::errorResponse(__('Ultimate Affiliate Pro database layer is unavailable', 'bit-integrations-pro'));
        }

        $userId = (int) $user->ID;
        $existingAffiliateId = (int) $indeed_db->get_affiliate_id_by_wpuid($userId);

        if ($existingAffiliateId > 0) {
            return self::successResponse(
                __('Affiliate already exists for this user', 'bit-integrations-pro'),
                [
                    'affiliate_id' => $existingAffiliateId,
                    'affiliate'    => self::getAffiliateRecord($existingAffiliateId),
                    'user'         => self::getUserInfo($userId),
                ]
            );
        }

        $affiliateId = (int) $indeed_db->save_affiliate($userId);

        if ($affiliateId <= 0) {
            return self::errorResponse(__('Failed to create affiliate. The user may be admin or already an affiliate', 'bit-integrations-pro'));
        }

        return self::successResponse(
            __('Affiliate created successfully', 'bit-integrations-pro'),
            [
                'affiliate_id' => $affiliateId,
                'affiliate'    => self::getAffiliateRecord($affiliateId),
                'user'         => self::getUserInfo($userId),
            ]
        );
    }

    public static function createReferral($defaultResponse, $fieldData)
    {
        if (!self::isPluginInstalled()) {
            return self::errorResponse(__('Ultimate Affiliate Pro is not installed or activated', 'bit-integrations-pro'));
        }

        $affiliateId = absint($fieldData['affiliate_id'] ?? 0);
        $amount = $fieldData['amount'] ?? null;
        $source = $fieldData['source'] ?? '';
        $reference = $fieldData['reference'] ?? '';

        if ($affiliateId <= 0) {
            return self::errorResponse(__('Affiliate ID is required', 'bit-integrations-pro'));
        }

        if (!self::affiliateExists($affiliateId)) {
            return self::errorResponse(__('Affiliate not found', 'bit-integrations-pro'));
        }

        if (!is_numeric($amount)) {
            return self::errorResponse(__('Amount is required and must be numeric', 'bit-integrations-pro'));
        }

        if ('' === trim((string) $source)) {
            return self::errorResponse(__('Source is required', 'bit-integrations-pro'));
        }

        if ('' === trim((string) $reference)) {
            return self::errorResponse(__('Reference is required', 'bit-integrations-pro'));
        }

        $referredUserId = self::getUserId($fieldData['referred_user'] ?? '');

        $referralData = [
            'refferal_wp_uid'    => $referredUserId,
            'campaign'           => sanitize_text_field($fieldData['campaign'] ?? ''),
            'affiliate_id'       => $affiliateId,
            'visit_id'           => absint($fieldData['visit_id'] ?? 0),
            'description'        => sanitize_text_field($fieldData['description'] ?? ''),
            'source'             => sanitize_text_field($source),
            'reference'          => sanitize_text_field($reference),
            'reference_details'  => sanitize_text_field($fieldData['reference_details'] ?? ''),
            'parent_referral_id' => absint($fieldData['parent_referral_id'] ?? 0),
            'child_referral_id'  => absint($fieldData['child_referral_id'] ?? 0),
            'amount'             => (string) self::normalizeAmount($amount),
            'currency'           => self::normalizeCurrency($fieldData['currency'] ?? ''),
            'date'               => current_time('mysql'),
            'status'             => (string) self::normalizePaymentOrReferralStatus($fieldData['status'] ?? 1),
            'payment'            => (string) self::normalizePaymentOrReferralStatus($fieldData['payment_status'] ?? 0),
        ];

        global $indeed_db;

        if (!\is_object($indeed_db) || !method_exists($indeed_db, 'save_referral')) {
            return self::errorResponse(__('Ultimate Affiliate Pro referral service is unavailable', 'bit-integrations-pro'));
        }

        $referralId = (int) $indeed_db->save_referral($referralData);

        if ($referralId <= 0) {
            return self::errorResponse(__('Failed to create referral', 'bit-integrations-pro'));
        }

        return self::successResponse(
            __('Referral created successfully', 'bit-integrations-pro'),
            [
                'referral_id'   => $referralId,
                'referral'      => self::getReferralRecord($referralId),
                'affiliate'     => self::getAffiliateRecord($affiliateId),
                'referred_user' => $referredUserId > 0 ? self::getUserInfo($referredUserId) : [],
            ]
        );
    }

    public static function insertPayment($defaultResponse, $fieldData)
    {
        if (!self::isPluginInstalled()) {
            return self::errorResponse(__('Ultimate Affiliate Pro is not installed or activated', 'bit-integrations-pro'));
        }

        $affiliateId = absint($fieldData['affiliate_id'] ?? 0);
        $amount = $fieldData['amount'] ?? null;

        if ($affiliateId <= 0) {
            return self::errorResponse(__('Affiliate ID is required', 'bit-integrations-pro'));
        }

        if (!self::affiliateExists($affiliateId)) {
            return self::errorResponse(__('Affiliate not found', 'bit-integrations-pro'));
        }

        if (!is_numeric($amount)) {
            return self::errorResponse(__('Amount is required and must be numeric', 'bit-integrations-pro'));
        }

        $paymentStatus = self::normalizePaymentOrReferralStatus($fieldData['status'] ?? 1);
        $transactionId = sanitize_text_field($fieldData['transaction_id'] ?? '');

        if ('' === $transactionId) {
            $transactionId = 'btcbi-' . wp_generate_password(12, false, false);
        }

        $paymentData = [
            'payment_type'   => sanitize_text_field($fieldData['payment_type'] ?? 'manual'),
            'transaction_id' => $transactionId,
            'referral_ids'   => self::normalizeReferralIds($fieldData['referral_ids'] ?? ''),
            'affiliate_id'   => $affiliateId,
            'amount'         => (string) self::normalizeAmount($amount),
            'currency'       => self::normalizeCurrency($fieldData['currency'] ?? ''),
            'create_date'    => current_time('mysql'),
            'update_date'    => current_time('mysql'),
            'status'         => (string) $paymentStatus,
        ];

        global $indeed_db;

        if (!\is_object($indeed_db) || !method_exists($indeed_db, 'add_payment')) {
            return self::errorResponse(__('Ultimate Affiliate Pro payment service is unavailable', 'bit-integrations-pro'));
        }

        $paymentId = (int) $indeed_db->add_payment($paymentData);

        if ($paymentId <= 0) {
            return self::errorResponse(__('Failed to insert payment', 'bit-integrations-pro'));
        }

        return self::successResponse(
            __('Payment inserted successfully', 'bit-integrations-pro'),
            [
                'payment_id' => $paymentId,
                'payment'    => self::getPaymentRecord($paymentId),
                'affiliate'  => self::getAffiliateRecord($affiliateId),
            ]
        );
    }

    public static function changeTransactionStatus($defaultResponse, $fieldData)
    {
        if (!self::isPluginInstalled()) {
            return self::errorResponse(__('Ultimate Affiliate Pro is not installed or activated', 'bit-integrations-pro'));
        }

        $paymentId = absint($fieldData['payment_id'] ?? 0);

        if ($paymentId <= 0) {
            return self::errorResponse(__('Payment ID is required', 'bit-integrations-pro'));
        }

        if (!self::hasFieldValue($fieldData, 'status')) {
            return self::errorResponse(__('Status is required', 'bit-integrations-pro'));
        }

        $newStatus = self::normalizePaymentOrReferralStatus($fieldData['status']);

        global $indeed_db;

        if (
            !\is_object($indeed_db)
            || !method_exists($indeed_db, 'change_transaction_status')
            || !method_exists($indeed_db, 'get_payment_status')
        ) {
            return self::errorResponse(__('Ultimate Affiliate Pro transaction service is unavailable', 'bit-integrations-pro'));
        }

        $previousStatus = $indeed_db->get_payment_status($paymentId);

        if (false === $previousStatus) {
            return self::errorResponse(__('Payment transaction not found', 'bit-integrations-pro'));
        }

        $indeed_db->change_transaction_status($paymentId, $newStatus);
        $currentStatus = $indeed_db->get_payment_status($paymentId);

        if (false === $currentStatus) {
            return self::errorResponse(__('Failed to update transaction status', 'bit-integrations-pro'));
        }

        return self::successResponse(
            __('Transaction status updated successfully', 'bit-integrations-pro'),
            [
                'payment_id'            => $paymentId,
                'previous_status'       => (int) $previousStatus,
                'previous_status_label' => self::paymentStatusLabel($previousStatus),
                'current_status'        => (int) $currentStatus,
                'current_status_label'  => self::paymentStatusLabel($currentStatus),
                'payment'               => self::getPaymentRecord($paymentId),
            ]
        );
    }

    public static function getAffiliateRecord(int $affiliateId): array
    {
        if ($affiliateId <= 0 || !class_exists('UapDb')) {
            return [];
        }

        $udb = new UapDb();

        return self::normalizeData($udb->get_affiliate($affiliateId));
    }

    public static function getReferralRecord(int $referralId): array
    {
        global $indeed_db;

        if (
            $referralId <= 0
            || !\is_object($indeed_db)
            || !method_exists($indeed_db, 'get_referral')
        ) {
            return [];
        }

        return self::normalizeData($indeed_db->get_referral($referralId));
    }

    public static function getPaymentRecord(int $paymentId, bool $referralIdsAsArray = false): array
    {
        if ($paymentId <= 0) {
            return [];
        }

        global $wpdb;

        $table = $wpdb->prefix . 'uap_payments';
        $query = $wpdb->prepare(
            "SELECT `id`,`payment_type`,`transaction_id`,`referral_ids`,`affiliate_id`,`amount`,`currency`,`payment_details`,
                `create_date`,`update_date`,`payment_special_status`,`status`
            FROM {$table} WHERE id=%d",
            $paymentId
        );

        $payment = $wpdb->get_row($query, ARRAY_A);

        if (empty($payment)) {
            return [];
        }

        $payment['payment_details'] = maybe_unserialize($payment['payment_details'] ?? '');
        $payment['status_label'] = self::paymentStatusLabel($payment['status'] ?? null);

        if ($referralIdsAsArray) {
            $payment['referral_ids'] = !empty($payment['referral_ids'])
                ? array_values(array_filter(array_map('intval', explode(',', (string) $payment['referral_ids']))))
                : [];
        }

        return $payment;
    }

    public static function paymentStatusLabel($status): string
    {
        switch ((int) $status) {
            case 0:
                return 'unpaid';

            case 1:
                return 'pending';

            case 2:
                return 'completed';

            case 3:
                return 'failed';

            default:
                return 'unknown';
        }
    }

    public static function normalizeData($data): array
    {
        if (\is_array($data)) {
            return $data;
        }

        if (\is_object($data)) {
            $encoded = wp_json_encode($data);
            $decoded = $encoded ? json_decode($encoded, true) : [];

            return \is_array($decoded) ? $decoded : [];
        }

        return [];
    }

    private static function hasFieldValue(array $fieldData, string $key): bool
    {
        if (!\array_key_exists($key, $fieldData)) {
            return false;
        }

        if (\is_array($fieldData[$key])) {
            return !empty($fieldData[$key]);
        }

        return '' !== trim((string) $fieldData[$key]);
    }

    private static function getUser($identifier)
    {
        $identifier = (string) $identifier;

        if ('' === trim($identifier)) {
            return false;
        }

        if (is_numeric($identifier)) {
            return get_user_by('id', absint($identifier));
        }

        if (is_email($identifier)) {
            return get_user_by('email', $identifier);
        }

        return get_user_by('login', $identifier);
    }

    private static function getUserId($identifier): int
    {
        $user = self::getUser($identifier);

        if (!$user) {
            return 0;
        }

        return absint($user->ID);
    }

    private static function getUserInfo(int $userId): array
    {
        if ($userId <= 0) {
            return [];
        }

        $user = get_userdata($userId);

        if (!$user) {
            return [];
        }

        return [
            'id'           => $userId,
            'user_login'   => $user->user_login,
            'display_name' => $user->display_name,
            'user_email'   => $user->user_email,
            'first_name'   => get_user_meta($userId, 'first_name', true),
            'last_name'    => get_user_meta($userId, 'last_name', true),
        ];
    }

    private static function normalizeAmount($amount): float
    {
        $amount = (float) $amount;

        if ($amount < 0) {
            $amount = 0;
        }

        return round($amount, 2);
    }

    private static function normalizeCurrency($currency): string
    {
        $currency = strtoupper(trim((string) $currency));

        if ('' === $currency) {
            $savedCurrency = get_option('uap_currency');

            if (\is_string($savedCurrency)) {
                $currency = strtoupper(trim($savedCurrency));
            }
        }

        if ('' === $currency) {
            $currency = 'USD';
        }

        return sanitize_text_field($currency);
    }

    private static function normalizePaymentOrReferralStatus($status): int
    {
        $status = (int) $status;

        return \in_array($status, [0, 1, 2], true) ? $status : 1;
    }

    private static function normalizeReferralIds($referralIds): string
    {
        if (\is_array($referralIds)) {
            $ids = $referralIds;
        } elseif (is_numeric($referralIds)) {
            $ids = [$referralIds];
        } else {
            $ids = explode(',', (string) $referralIds);
        }

        $ids = array_values(
            array_filter(
                array_map('absint', $ids),
                static function ($id) {
                    return $id > 0;
                }
            )
        );

        return implode(',', $ids);
    }

    private static function affiliateExists(int $affiliateId): bool
    {
        $affiliate = self::getAffiliateRecord($affiliateId);

        return !empty($affiliate['id']);
    }

    private static function isPluginInstalled(): bool
    {
        if (!\function_exists('is_plugin_active')) {
            include_once ABSPATH . 'wp-admin/includes/plugin.php';
        }

        $plugins = [
            'ultimate-affiliate/ultimate-affiliate.php',
            'ultimate-affiliate-pro/ultimate-affiliate-pro.php',
            'indeed-affiliate-pro/indeed-affiliate-pro.php',
        ];

        foreach ($plugins as $pluginFile) {
            if (\function_exists('is_plugin_active') && is_plugin_active($pluginFile)) {
                return true;
            }
        }

        return false;
    }

    private static function successResponse($message, $data = [])
    {
        return ['success' => true, 'message' => $message, 'data' => $data];
    }

    private static function errorResponse($message, $data = [])
    {
        $response = ['success' => false,    'message' => $message];

        if (!empty($data)) {
            $response['data'] = $data;
        }

        return $response;
    }
}
