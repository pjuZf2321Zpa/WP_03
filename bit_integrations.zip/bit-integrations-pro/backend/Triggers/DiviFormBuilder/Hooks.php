<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Core\Util\Hooks;
use BitApps\IntegrationsPro\Triggers\DiviFormBuilder\DiviFormBuilderController;

Hooks::add('df_after_process', [DiviFormBuilderController::class, 'handleDiviFormBuilderSubmit'], 10, PHP_INT_MAX);
