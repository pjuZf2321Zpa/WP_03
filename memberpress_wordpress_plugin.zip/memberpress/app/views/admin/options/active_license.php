<?php
/**
 * View admin/options/active_license.
 *
 * @var MemberPress\GroundLevel\Mothership\Transients\ActivationTransient $activation_transient
 * @var MemberPress\GroundLevel\Mothership\Manager\LicenseManager         $license_manager
 * @var MeprOptions                                                      $mepr_options
 */

defined('ABSPATH') || exit;

$editions = $license_manager->isIncorrectEditionInstalled();

if (false !== $editions) {
    printf(
        '<div class="notice notice-warning inline"><p>%1$s<img id="mepr-install-license-edition-loading" class="mepr-hidden" src="%2$s" alt="%3$s" /></p></div>',
        sprintf(
        // Translators: %1$s: the license edition, %2$s: the installed edition, %3$s: open link tag, %4$s: close link tag.
            esc_html__('This License Key is for %1$s, but %2$s is installed. %3$sClick here%4$s to install the correct edition for the license (%1$s).', 'memberpress'),
            '<strong>' . esc_html($editions['license']->name) . '</strong>',
            '<strong>' . esc_html($editions['installed']->name) . '</strong>',
            '<a id="mepr-install-license-edition" href="#">',
            '</a>'
        ),
        esc_url(MEPR_IMAGES_URL . '/square-loader.gif'),
        esc_html__('Loading...', 'memberpress')
    );
}
?>

<?php echo $license_manager->generateDeactivationForm(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>

<br />

<?php MeprView::render('/admin/options/edge_updates', get_defined_vars()); ?>
