<?php
defined('ABSPATH') or die;
/**
 * @var $router FluentCart\Framework\Http\Router
 */

use FluentCartPro\App\Http\Controllers\RoleController;
use FluentCartPro\App\Http\Controllers\EmailNotificationProController;
use FluentCartPro\App\Http\Controllers\PdfTemplateProController;
use FluentCartPro\App\Http\Controllers\SavedViewsController;

use FluentCartPro\App\Http\Policies\SavedViewsPolicy;
use FluentCartPro\App\Modules\Licensing\Http\Controllers\LicenseController;

//Roles and permissions routes
$router->prefix('roles')
    ->withPolicy('FluentCart\App\Http\Policies\AdminPolicy')->group(function ($router) {
        $router->get('/managers', [RoleController::class, 'managers']);
        $router->get('/user-list', [RoleController::class, 'userList']);
        $router->get('/', [RoleController::class, 'index']);
        $router->post('/', [RoleController::class, 'create']);
        $router->get('/{key}', [RoleController::class, 'find']);
        $router->post('/{key}', [RoleController::class, 'update']);
        $router->delete('/{key}', [RoleController::class, 'delete']);
    });

//FluentCart pluginManager routes
$router->prefix('settings/license')
    ->withPolicy('FluentCart\App\Http\Policies\AdminPolicy')
    ->group(function ($router) {
        $router->get('/', [LicenseController::class, 'getLicenseDetails']);
        $router->post('/', [LicenseController::class, 'activateLicense']);
        $router->delete('/', [LicenseController::class, 'deactivateLicense']);
    });

// Email notification preview (Pro feature - uses FluentBlockParser)
$router->prefix('email-notification')
    ->withPolicy('FluentCart\App\Http\Policies\StoreSensitivePolicy')
    ->group(function ($router) {
        $router->post('/preview', [EmailNotificationProController::class, 'preview']);
    });

// Saved Views routes (Pro feature)
$router->prefix('saved-views')
    ->withPolicy(SavedViewsPolicy::class)
    ->group(function ($router) {
        $router->get('/', [SavedViewsController::class, 'index']);
        $router->post('/', [SavedViewsController::class, 'store']);
        $router->put('/{id}', [SavedViewsController::class, 'update']);
        $router->delete('/{id}', [SavedViewsController::class, 'delete']);
    });

// PDF Template routes (Pro feature) — inside settings/ prefix to match free plugin's URL structure
$router->prefix('settings/')
    ->withPolicy('FluentCart\App\Http\Policies\StoreSensitivePolicy')
    ->group(function ($router) {
        $router->get('pdf-templates/status', [PdfTemplateProController::class, 'getStatus'])->meta([
            'permissions' => 'is_super_admin'
        ]);
        $router->get('pdf-templates/receipt', [PdfTemplateProController::class, 'getTemplates'])->meta([
            'permissions' => 'is_super_admin'
        ]);
        $router->get('pdf-templates/receipt/{template_id}', [PdfTemplateProController::class, 'getTemplate'])->meta([
            'permissions' => 'is_super_admin'
        ]);
        $router->post('pdf-templates/receipt/{template_id}', [PdfTemplateProController::class, 'saveTemplate'])->meta([
            'permissions' => 'is_super_admin'
        ]);
        $router->get('pdf-templates/factory-default', [PdfTemplateProController::class, 'getFactoryDefault'])->meta([
            'permissions' => 'is_super_admin'
        ]);
        $router->get('pdf-templates/saved', [PdfTemplateProController::class, 'getSavedTemplate'])->meta([
            'permissions' => 'is_super_admin'
        ]);
        $router->post('pdf-templates/download', [PdfTemplateProController::class, 'downloadPdf'])->meta([
            'permissions' => 'is_super_admin'
        ]);
        $router->post('pdf-templates/create', [PdfTemplateProController::class, 'createTemplate'])->meta([
            'permissions' => 'is_super_admin'
        ]);
        $router->delete('pdf-templates/delete/{template_id}', [PdfTemplateProController::class, 'deleteTemplate'])->meta([
            'permissions' => 'is_super_admin'
        ]);
        $router->get('pdf-templates/seller-details', [PdfTemplateProController::class, 'getSellerDetails'])->meta([
            'permissions' => 'is_super_admin'
        ]);
        $router->post('pdf-templates/seller-details', [PdfTemplateProController::class, 'saveSellerDetails'])->meta([
            'permissions' => 'is_super_admin'
        ]);
    });

