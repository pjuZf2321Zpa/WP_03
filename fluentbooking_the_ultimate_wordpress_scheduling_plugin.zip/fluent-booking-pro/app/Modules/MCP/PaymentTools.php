<?php

namespace FluentBookingPro\App\Modules\MCP;

use FluentBooking\App\Models\Booking;
use FluentBooking\App\Models\Calendar;
use FluentBooking\App\Modules\MCP\Support\MCPHelper;
use FluentBooking\App\Modules\MCP\Support\PermissionGate;
use FluentBooking\App\Services\CurrenciesHelper;
use FluentBooking\Framework\Support\Arr;
use FluentBookingPro\App\Models\Order;
use FluentBookingPro\App\Models\Transactions;

defined('ABSPATH') || exit;

/**
 * The Pro `payments` MCP toolset: one read-only tool, off by default.
 *
 * Refunds stay in the admin, where a human reviews them. An agent that can
 * move money is a bigger risk than one that can move a meeting.
 *
 * As in the free BookingProjector, every stored free-form string goes through
 * MCPHelper::untrusted(). Only values this code sets (statuses, codes, ids,
 * amounts) are emitted raw.
 *
 * @since 2.2.6
 */
class PaymentTools
{
    const DEFAULT_PER_PAGE = 20;

    /**
     * Cap on one order's transaction list. The response reports the real total.
     */
    const MAX_TRANSACTIONS = 50;

    /**
     * No gating needed: the free registrar only loads classes for toolsets the
     * operator switched on.
     */
    public static function register()
    {
        add_filter('fluent_booking/mcp_tool_classes', [self::class, 'addToolClasses']);
    }

    /**
     * @param array $classes
     * @return array
     */
    public static function addToolClasses($classes)
    {
        $classes['payments'][] = self::class;

        return $classes;
    }

    public static function definitions()
    {
        return [
            'fluent-booking/get-payments' => [
                'label'               => __('Get payments', 'fluent-booking-pro'),
                'description'         => __('Booking orders and their transactions. Lists orders with filters, or returns one order in full with its transactions and the booking it belongs to when order_id is given. Transactions come back as {items, total} and say so when an order has more than the 50 they return. Read only — refunds are not available through MCP.', 'fluent-booking-pro'),
                'input_schema'        => [
                    'type'       => 'object',
                    'properties' => [
                        'order_id'       => [
                            'type'        => 'integer',
                            'description' => __('Return this one order in full instead of the list.', 'fluent-booking-pro'),
                        ],
                        'booking_id'     => [
                            'type'        => 'integer',
                            'description' => __('Orders belonging to one booking.', 'fluent-booking-pro'),
                        ],
                        'status'         => [
                            'type'        => 'array',
                            'description' => __('Filter by order status, e.g. paid, draft, refunded.', 'fluent-booking-pro'),
                            'items'       => ['type' => 'string'],
                        ],
                        'payment_method' => [
                            'type'        => 'string',
                            'description' => __('e.g. stripe, paypal, offline.', 'fluent-booking-pro'),
                        ],
                        'from'           => [
                            'type'        => 'string',
                            'description' => __('Orders created on or after this date, Y-m-d.', 'fluent-booking-pro'),
                        ],
                        'to'             => [
                            'type'        => 'string',
                            'description' => __('Orders created on or before this date, Y-m-d.', 'fluent-booking-pro'),
                        ],
                        'timezone'       => [
                            'type'        => 'string',
                            'description' => __('IANA timezone for the *_local times in the response. Defaults to the site timezone.', 'fluent-booking-pro'),
                        ],
                        'page'           => ['type' => 'integer'],
                        'per_page'       => [
                            'type'        => 'integer',
                            'description' => sprintf(
                                /* translators: %1$d: default page size, %2$d: maximum page size */
                                __('Default %1$d, maximum %2$d.', 'fluent-booking-pro'),
                                self::DEFAULT_PER_PAGE,
                                MCPHelper::MAX_PER_PAGE
                            ),
                        ],
                    ],
                ],
                'annotations'         => [
                    'title'    => __('Get payments', 'fluent-booking-pro'),
                    'readonly' => true,
                ],
                'permission_callback' => [PermissionGate::class, 'readGate'],
                'execute_callback'    => [self::class, 'getPayments'],
            ],
        ];
    }

    /**
     * @param array $params
     * @return array|\WP_Error
     */
    public static function getPayments($params = [])
    {
        $timezone = MCPHelper::resolveTimezone(Arr::get($params, 'timezone', ''));

        if ($orderId = absint(Arr::get($params, 'order_id'))) {
            return self::getOrder($orderId, $timezone);
        }

        $query = self::scopedQuery();

        if (is_wp_error($query)) {
            return $query;
        }

        if ($bookingId = absint(Arr::get($params, 'booking_id'))) {
            $query->where('parent_id', $bookingId);
        }

        if ($statuses = array_filter((array) Arr::get($params, 'status', []))) {
            $query->whereIn('status', array_map('sanitize_text_field', $statuses));
        }

        if ($method = Arr::get($params, 'payment_method')) {
            $query->where('payment_method', sanitize_text_field($method));
        }

        $from = sanitize_text_field((string) Arr::get($params, 'from'));
        $to   = sanitize_text_field((string) Arr::get($params, 'to'));

        foreach ([$from, $to] as $date) {
            // Refuse rather than drop the filter, or the caller silently gets every order.
            if ($date && !MCPHelper::isRealDate($date)) {
                return MCPHelper::error(
                    'invalid_date',
                    __('from and to must be real dates in Y-m-d form.', 'fluent-booking-pro'),
                    ['received' => $date]
                );
            }
        }

        if ($from) {
            $query->where('created_at', '>=', $from . ' 00:00:00');
        }

        if ($to) {
            $query->where('created_at', '<=', $to . ' 23:59:59');
        }

        $perPage = MCPHelper::perPage(Arr::get($params, 'per_page'), self::DEFAULT_PER_PAGE);
        $page    = max(1, absint(Arr::get($params, 'page', 1)));

        $total = (clone $query)->count();

        $orders = $query->orderBy('id', 'desc')
            ->skip(($page - 1) * $perPage)
            ->take($perPage)
            ->get();

        $rows = [];

        foreach ($orders as $order) {
            $rows[] = self::row($order, $timezone);
        }

        return MCPHelper::success(
            $rows,
            array_merge(
                MCPHelper::paginationMeta($total, $page, $perPage),
                ['timezone' => $timezone, 'scope' => PermissionGate::currentScope()]
            ),
            $rows ? 'Call again with order_id for one order\'s transactions and its booking.' : ''
        );
    }

    /**
     * @return array|\WP_Error
     */
    private static function getOrder($orderId, $timezone)
    {
        $order = Order::find($orderId);

        if (!$order) {
            return MCPHelper::error('not_found', __('No order with that id.', 'fluent-booking-pro'));
        }

        $booking = $order->parent_id ? Booking::with('calendar_event')->find($order->parent_id) : null;

        // An order whose booking was deleted has no host to check, so only a
        // caller who can see all bookings may read it. The list query agrees.
        $readable = $booking
            ? self::canReadBooking($booking)
            : PermissionGate::canSeeAllBookings();

        if (!$readable) {
            return MCPHelper::error(
                'permission_denied',
                __('You do not have permission to read this order.', 'fluent-booking-pro'),
                ['order_id' => $orderId]
            );
        }

        $data = self::row($order, $timezone);

        $data['note']     = MCPHelper::untrusted($order->note);
        $data['refunded'] = MCPHelper::timePair($order->refunded_at, $timezone, 'refunded_at');

        $transactions = [];

        $transactionQuery = Transactions::where('object_id', $order->id)
            ->where('object_type', 'order')
            ->orderBy('id', 'asc');

        // Count before the cap so a truncated history is marked as such.
        $transactionTotal = (clone $transactionQuery)->count();

        foreach ($transactionQuery->limit(self::MAX_TRANSACTIONS)->get() as $transaction) {
            $transactions[] = array_merge(
                [
                    'id'             => (int) $transaction->id,
                    'type'           => $transaction->transaction_type,
                    'status'         => $transaction->status,
                    'payment_method' => $transaction->payment_method,
                    'card_brand'     => MCPHelper::untrusted($transaction->card_brand, 50),
                    'card_last_4'    => MCPHelper::untrusted($transaction->card_last_4, 10),
                    // Lets an operator find the charge in Stripe or PayPal.
                    'gateway_charge_id' => MCPHelper::untrusted($transaction->vendor_charge_id, 100),
                ],
                // Transactions have no currency column; they use the order's.
                self::money($transaction->total, 'amount', $order->currency),
                MCPHelper::timePair($transaction->created_at, $timezone, 'at')
            );
        }

        $data['transactions'] = [
            'items' => $transactions,
            'total' => (int) $transactionTotal,
        ];

        if ($transactionTotal > count($transactions)) {
            $data['transactions']['truncated']       = true;
            $data['transactions']['truncation_note'] = sprintf(
                /* translators: 1: number returned, 2: number that exist */
                __('Showing the oldest %1$d of %2$d transactions. This order\'s history is longer than this tool returns; read it in the payment gateway.', 'fluent-booking-pro'),
                count($transactions),
                (int) $transactionTotal
            );
        }

        if ($booking) {
            $data['booking'] = [
                'id'       => (int) $booking->id,
                'status'   => $booking->status,
                'attendee' => MCPHelper::untrusted(trim($booking->first_name . ' ' . $booking->last_name), 200),
                'event'    => $booking->calendar_event ? MCPHelper::untrusted($booking->calendar_event->title, 200) : '',
                'start'    => $booking->start_time,
            ];
        }

        return MCPHelper::success($data, ['timezone' => $timezone]);
    }

    /**
     * @return array
     */
    private static function row($order, $timezone)
    {
        return array_merge(
            [
                'id'             => (int) $order->id,
                'order_number'   => MCPHelper::untrusted($order->order_number, 100),
                'status'         => $order->status,
                'type'           => $order->type,
                'booking_id'     => $order->parent_id ? (int) $order->parent_id : null,
                'payment_method' => $order->payment_method,
                'payment_mode'   => $order->payment_mode,
                'currency'       => $order->currency,
            ],
            self::money($order->total_amount, 'total', $order->currency),
            self::money($order->total_paid, 'paid', $order->currency),
            MCPHelper::timePair($order->created_at, $timezone, 'created_at')
        );
    }

    /**
     * Amounts are stored in minor units. Emit the exact integer plus a
     * formatted string, so an agent doesn't guess the decimal placement.
     *
     * @param mixed       $amount
     * @param string      $prefix
     * @param string|null $currency The order's stored currency. The global
     *                              setting can change after the order.
     *
     * @return array
     */
    private static function money($amount, $prefix = 'amount', $currency = null)
    {
        $cents = (int) round((float) $amount);

        $sign = $currency
            ? CurrenciesHelper::getCurrencySign($currency)
            : CurrenciesHelper::getGlobalCurrencySign();

        // The sign comes back HTML-encoded ("&#36;") for admin templates.
        $sign = html_entity_decode((string) $sign, ENT_QUOTES, 'UTF-8');

        return [
            $prefix . '_cents'     => $cents,
            $prefix . '_formatted' => $sign . number_format($cents / 100, 2),
        ];
    }

    /**
     * An operator sees exactly the orders whose bookings they may see. There is
     * no separate payments permission.
     *
     * @return object|\WP_Error
     */
    private static function scopedQuery()
    {
        $query = Order::query();

        if (PermissionGate::canSeeAllBookings()) {
            return $query;
        }

        $userId = get_current_user_id();

        // EXISTS subquery, not a pluck of booking ids: that list grows with the
        // host's whole booking history.
        return $query->whereHas('booking', function ($booking) use ($userId) {
            $booking->whereHostAccess($userId);
        });
    }

    /**
     * @return bool
     */
    private static function canReadBooking(Booking $booking)
    {
        if (PermissionGate::canSeeAllBookings()) {
            return true;
        }

        $userId = get_current_user_id();

        if ((int) $booking->host_user_id === (int) $userId) {
            return true;
        }

        if (in_array((int) $userId, array_map('intval', (array) $booking->getHostIds()), true)) {
            return true;
        }

        // Calendar ownership, matching the free BookingTools::canReadBooking().
        // Not PermissionManager::canReadCalendar(), which is true for every
        // calendar with `read_other_calendars` and would leak other hosts' orders.
        return (bool) Calendar::where('id', $booking->calendar_id)
            ->where('user_id', $userId)
            ->exists();
    }
}
