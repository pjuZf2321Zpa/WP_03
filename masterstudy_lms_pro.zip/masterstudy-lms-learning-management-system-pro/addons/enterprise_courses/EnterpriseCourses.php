<?php

namespace MasterStudy\Lms\Pro\addons\enterprise_courses;

use MasterStudy\Lms\Plugin;
use MasterStudy\Lms\Plugin\Addon;
use MasterStudy\Lms\Plugin\Addons;

final class EnterpriseCourses implements Addon {
	public function get_name(): string {
		return Addons::ENTERPRISE_COURSES;
	}

	public function register( Plugin $plugin ): void {
		$plugin->get_router()->load_routes( __DIR__ . '/routes.php' );
	}
}
