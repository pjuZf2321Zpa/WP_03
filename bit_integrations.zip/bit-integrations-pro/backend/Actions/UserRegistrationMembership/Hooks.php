<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Actions\UserRegistrationMembership\UserRegistrationMembershipProHelper;
use BitApps\IntegrationsPro\Config;
use BitApps\IntegrationsPro\Core\Util\Hooks;

Hooks::filter(Config::withFreePrefix('user_registration_create_user'), [UserRegistrationMembershipProHelper::class, 'createUser'], 10, 3);
