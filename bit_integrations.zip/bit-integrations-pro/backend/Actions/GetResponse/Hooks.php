<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Actions\GetResponse\GetResponseHelperPro;
use BitApps\IntegrationsPro\Config;
use BitApps\IntegrationsPro\Core\Util\Hooks;

// Deprecated since v2.7.8 - use bit_integrations_getresponse_* hooks instead
if (bit_integrations_version_below('2.7.8')) {
    Hooks::filter('btcbi_getresponse_autoresponder_day', [GetResponseHelperPro::class, 'autoResponderDay'], 10, 2);
}

// New hooks since v2.7.8
Hooks::filter(Config::withFreePrefix('getresponse_autoresponder_day'), [GetResponseHelperPro::class, 'autoResponderDay'], 10, 2);
