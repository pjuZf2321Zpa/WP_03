<?php
/**
 * REST controller for listing blog categories with the current user's
 * `blog_category` subscription state — powers the "Subscribe to topics" modal
 * and the "Blog Subscriptions" settings tab.
 *
 * @package BuddyBossPro
 *
 * @since 3.1.0
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class BB_REST_Blog_Subscriptions_Endpoint.
 *
 * @since 3.1.0
 */
class BB_REST_Blog_Subscriptions_Endpoint extends WP_REST_Controller {

	/**
	 * Constructor.
	 *
	 * @since 3.1.0
	 */
	public function __construct() {
		$this->namespace = function_exists( 'bp_rest_namespace' ) && function_exists( 'bp_rest_version' )
			? bp_rest_namespace() . '/' . bp_rest_version()
			: 'buddyboss/v1';
		$this->rest_base = 'blog-subscriptions';
	}

	/**
	 * Register the routes.
	 *
	 * @since 3.1.0
	 *
	 * @return void
	 */
	public function register_routes() {
		register_rest_route(
			$this->namespace,
			'/' . $this->rest_base . '/categories',
			array(
				array(
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => array( $this, 'get_categories' ),
					'permission_callback' => array( $this, 'get_categories_permissions_check' ),
					'args'                => array(
						'subscribed_only' => array(
							'description'       => __( 'Return only categories the user is subscribed to.', 'buddyboss-pro' ),
							'type'              => 'boolean',
							'default'           => false,
							'sanitize_callback' => 'rest_sanitize_boolean',
							'validate_callback' => 'rest_validate_request_arg',
						),
						'hide_empty'      => array(
							'description'       => __( 'Whether to hide categories not assigned to any published posts.', 'buddyboss-pro' ),
							'type'              => 'boolean',
							'default'           => true,
							'sanitize_callback' => 'rest_sanitize_boolean',
							'validate_callback' => 'rest_validate_request_arg',
						),
						'page'            => array(
							'description'       => __( 'Current page of the collection.', 'buddyboss-pro' ),
							'type'              => 'integer',
							'default'           => 1,
							'minimum'           => 1,
							'sanitize_callback' => 'absint',
							'validate_callback' => 'rest_validate_request_arg',
						),
						'per_page'        => array(
							'description'       => __( 'Maximum number of categories to return per page.', 'buddyboss-pro' ),
							'type'              => 'integer',
							'default'           => 20,
							'minimum'           => 1,
							'maximum'           => 100,
							'sanitize_callback' => 'absint',
							'validate_callback' => 'rest_validate_request_arg',
						),
						'orderby'         => array(
							'description'       => __( 'Sort categories by attribute.', 'buddyboss-pro' ),
							'type'              => 'string',
							'default'           => 'name',
							'enum'              => array( 'name', 'count', 'slug', 'term_id' ),
							'sanitize_callback' => 'sanitize_key',
							'validate_callback' => 'rest_validate_request_arg',
						),
						'order'           => array(
							'description'       => __( 'Whether to sort categories in ascending or descending order.', 'buddyboss-pro' ),
							'type'              => 'string',
							'default'           => 'asc',
							'enum'              => array( 'asc', 'desc' ),
							'sanitize_callback' => 'sanitize_key',
							'validate_callback' => 'rest_validate_request_arg',
						),
					),
				),
				'schema' => array( $this, 'get_public_item_schema' ),
			)
		);
	}

	/**
	 * Retrieve the schema for a single blog-category subscription item.
	 *
	 * Describes one entry of the collection returned by `get_categories()`.
	 *
	 * @since 3.1.0
	 *
	 * @return array Item schema data.
	 */
	public function get_item_schema() {
		if ( isset( $this->schema ) ) {
			return $this->add_additional_fields_schema( $this->schema );
		}

		$schema = array(
			'$schema'    => 'http://json-schema.org/draft-04/schema#',
			'title'      => 'bb_blog_subscription_category',
			'type'       => 'object',
			'properties' => array(
				'term_id'         => array(
					'description' => __( 'The category term ID.', 'buddyboss-pro' ),
					'type'        => 'integer',
					'context'     => array( 'view', 'edit' ),
					'readonly'    => true,
				),
				'name'            => array(
					'description' => __( 'The category name.', 'buddyboss-pro' ),
					'type'        => 'string',
					'context'     => array( 'view', 'edit' ),
					'readonly'    => true,
				),
				'count'           => array(
					'description' => __( 'The number of published posts in the category.', 'buddyboss-pro' ),
					'type'        => 'integer',
					'context'     => array( 'view', 'edit' ),
					'readonly'    => true,
				),
				'subscribed'      => array(
					'description' => __( 'Whether the current user is subscribed to the category.', 'buddyboss-pro' ),
					'type'        => 'boolean',
					'context'     => array( 'view', 'edit' ),
					'readonly'    => true,
				),
				'subscription_id' => array(
					'description' => __( "The current user's subscription ID for the category, or 0 when not subscribed.", 'buddyboss-pro' ),
					'type'        => 'integer',
					'context'     => array( 'view', 'edit' ),
					'readonly'    => true,
				),
			),
		);

		$this->schema = $schema;

		return $this->add_additional_fields_schema( $this->schema );
	}

	/**
	 * Permission check: logged-in + subscriptions feature enabled.
	 *
	 * @since 3.1.0
	 *
	 * @param WP_REST_Request $request Request object.
	 *
	 * @return true|WP_Error
	 */
	public function get_categories_permissions_check( $request ) {
		if ( ! is_user_logged_in() ) {
			return new WP_Error(
				'bb_rest_authorization_required',
				__( 'You must be logged in to view blog subscriptions.', 'buddyboss-pro' ),
				array( 'status' => rest_authorization_required_code() )
			);
		}

		if ( ! function_exists( 'bb_blog_pro_is_subscriptions_enabled' ) || ! bb_blog_pro_is_subscriptions_enabled() ) {
			return new WP_Error(
				'bb_rest_blog_subscriptions_disabled',
				__( 'Blog category subscriptions are not enabled.', 'buddyboss-pro' ),
				array( 'status' => 400 )
			);
		}

		return true;
	}

	/**
	 * Return a paginated list of categories with the user's subscription state.
	 *
	 * Honors the standard REST collection args (page, per_page, orderby, order,
	 * hide_empty) and emits X-WP-Total / X-WP-TotalPages headers.
	 *
	 * @since 3.1.0
	 *
	 * @param WP_REST_Request $request Request object.
	 *
	 * @return WP_REST_Response
	 */
	public function get_categories( $request ) {
		$subscribed_only = (bool) $request->get_param( 'subscribed_only' );

		// Standard REST collection controls, all schema-validated in
		// register_routes(): pagination (page / per_page 1-100), hide_empty, and
		// order / orderby. Values map straight onto get_terms(). The subscribe
		// modal renders each returned category into the DOM, so per_page bounds
		// sites with very large category taxonomies.
		$per_page   = (int) $request->get_param( 'per_page' );
		$page       = max( 1, (int) $request->get_param( 'page' ) );
		$offset     = ( $page - 1 ) * $per_page;
		$hide_empty = (bool) $request->get_param( 'hide_empty' );
		$orderby    = (string) $request->get_param( 'orderby' );
		$order      = 'desc' === strtolower( (string) $request->get_param( 'order' ) ) ? 'DESC' : 'ASC';

		$subscription_map = $this->get_user_subscription_map();

		$terms_args = array(
			'taxonomy'   => 'category',
			'hide_empty' => $hide_empty,
			'orderby'    => $orderby,
			'order'      => $order,
			'number'     => $per_page,
			'offset'     => $offset,
		);

		if ( $subscribed_only ) {
			// Paginate over the user's subscribed terms themselves, not the full
			// taxonomy. Paging the whole taxonomy and filtering afterwards made a
			// page contain few/none of their subscriptions while X-WP-Total(-Pages)
			// were computed from the subscription count — so the two disagreed.
			// Also ignore hide_empty here so a subscribed-but-now-empty category
			// still shows and can be unsubscribed.
			$subscribed_ids           = array_map( 'intval', array_keys( $subscription_map ) );
			$terms_args['hide_empty'] = false;
			$terms_args['include']    = $subscribed_ids;
			$terms                    = empty( $subscribed_ids ) ? array() : get_terms( $terms_args );
		} else {
			$terms = get_terms( $terms_args );
		}

		if ( is_wp_error( $terms ) ) {
			$terms = array();
		}
		$items = array();

		foreach ( $terms as $term ) {
			$sub_id    = isset( $subscription_map[ $term->term_id ] ) ? (int) $subscription_map[ $term->term_id ] : 0;
			$is_subbed = ! empty( $sub_id );

			if ( $subscribed_only && ! $is_subbed ) {
				continue;
			}

			$items[] = array(
				'term_id'         => (int) $term->term_id,
				'name'            => $term->name,
				'count'           => (int) $term->count,
				'subscribed'      => $is_subbed,
				'subscription_id' => $sub_id,
			);
		}

		$response = rest_ensure_response( $items );

		// Standard WP REST collection pagination headers so clients can page
		// deterministically. The collection is the user's subscriptions in
		// subscribed-only mode, otherwise all categories under hide_empty.
		if ( $subscribed_only ) {
			$total = count( $subscription_map );
		} else {
			$total = wp_count_terms(
				array(
					'taxonomy'   => 'category',
					'hide_empty' => $hide_empty,
				)
			);
			$total = is_wp_error( $total ) ? 0 : (int) $total;
		}

		$response->header( 'X-WP-Total', (int) $total );
		$response->header( 'X-WP-TotalPages', $per_page > 0 ? (int) ceil( $total / $per_page ) : 0 );

		return $response;
	}

	/**
	 * Build a term_id => subscription_id map for the current user's
	 * `blog_category` subscriptions.
	 *
	 * @since 3.1.0
	 *
	 * @return array
	 */
	protected function get_user_subscription_map() {
		$map = array();

		if ( ! function_exists( 'bb_get_subscriptions' ) ) {
			return $map;
		}

		$subscriptions = bb_get_subscriptions(
			array(
				'type'     => 'blog_category',
				'user_id'  => get_current_user_id(),
				'fields'   => 'all',
				'count'    => false,
				'per_page' => -1,
			),
			true
		);

		if ( empty( $subscriptions['subscriptions'] ) ) {
			return $map;
		}

		foreach ( $subscriptions['subscriptions'] as $sub ) {
			if ( ! empty( $sub->item_id ) ) {
				$map[ (int) $sub->item_id ] = (int) $sub->id;
			}
		}

		return $map;
	}
}
