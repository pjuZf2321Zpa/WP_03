<?php
/**
 * @author WP Cloud Plugins
 * @copyright Copyright (c) 2023, WP Cloud Plugins
 *
 * @since       2.0
 * @see https://www.wpcloudplugins.com
 */

namespace TheLion\OutoftheBox;

use TheLion\OutoftheBox\API\Dropbox\Dropbox;
use TheLion\OutoftheBox\API\Dropbox\DropboxApp;
use TheLion\OutoftheBox\API\Dropbox\Exceptions\DropboxClientException;
use TheLion\OutoftheBox\API\Dropbox\Models\AccessToken;
use TheLion\OutoftheBox\API\Dropbox\Store\DatabasePersistentDataStore;

defined('ABSPATH') || exit;

class App
{
    /**
     * The single instance of the class.
     *
     * @var App
     */
    protected static $_instance;

    /**
     * @var bool
     */
    private $_own_app = false;

    /**
     * @var string
     */
    private $_app_key;

    /**
     * @var string
     */
    private $_app_secret;

    /**
     * @var string
     */
    private $_app_token;

    /**
     * @var Dropbox
     */
    private static $_sdk_client;

    /**
     * @var DropboxApp
     */
    private static $_sdk_client_app;

    /**
     * @var Account
     */
    private static $_current_account;

    /**
     * We don't save your data or share it.
     * It is used for an easy and one-click  authorization process that will always work!
     *
     * @var string
     */
    private $_auth_url = 'https://www.wpcloudplugins.com:443/out-of-the-box/_AuthorizeApp.php';

    public function __construct()
    {
        require_once OUTOFTHEBOX_ROOTDIR.'/vendors/dropbox-sdk/vendor/autoload.php';

        // Call back for refresh token function in SDK client
        add_action('out-of-the-box-refresh-token', [$this, 'refresh_token'], 10, 1);

        add_filter('outofthebox-set-root-namespace-id', [$this, 'get_root_namespace_id'], 10, 1);
    }

    /**
     * App Instance.
     *
     * Ensures only one instance is loaded or can be loaded.
     *
     * @return App - App instance
     *
     * @static
     */
    public static function instance()
    {
        if (is_null(self::$_instance)) {
            $app = new self();
        } else {
            $app = self::$_instance;
        }

        if (empty($app::$_sdk_client)) {
            try {
                $app->start_sdk_client(App::get_current_account());
            } catch (\Exception $ex) {
                self::$_instance = $app;

                return self::$_instance;
            }
        }

        self::$_instance = $app;

        if (null !== App::get_current_account()) {
            $app->get_sdk_client(App::get_current_account());
        }

        return self::$_instance;
    }

    public function process_authorization()
    {
        if (!empty($_GET['ver']) && isset($_GET['code'])) {
            $state = strtr($_GET['state'], '-_~', '+/=');

            $urlState = null;

            $splitPos = strpos($state, '|');

            if (false !== $splitPos) {
                $urlState = substr($state, $splitPos + 1);
            }

            $redirectto = base64_decode($urlState);

            if (false === strpos($redirectto, 'outofthebox_authorization')) {
                return false;
            }

            Processor::reset_complete_cache();
            $this->create_access_token();
        }

        // Close oAuth popup and refresh plugin settings page. Only possible with inline javascript.
        echo '<script type="text/javascript">localStorage.setItem("wpcp_refreshParent", "true"); window.close();</script>';

        exit;
    }

    public function has_plugin_own_app()
    {
        return $this->_own_app;
    }

    public function get_auth_url($params = [])
    {
        $auth_helper = self::get_sdk_client()->getAuthHelper();

        if (Core::is_network_authorized() || is_network_admin()) {
            $redirect = network_admin_url('admin.php?page=OutoftheBox_network_settings&action=outofthebox_authorization');
        } else {
            $redirect = admin_url('admin.php?page=OutoftheBox_settings&action=outofthebox_authorization');
        }

        $redirect .= '&license='.(string) License::get();
        $redirect .= '&siteurl='.License::get_home_url();

        // Keep each pending authorization attempt isolated for the current user.
        $token = wp_generate_password(16, false, false);
        set_transient('outofthebox_authorization_'.get_current_user_id().'_'.$token, true, 15 * MINUTE_IN_SECONDS);
        // Use a compact state parameter to avoid overly long authorization URLs.
        $redirect .= '&t='.$token;
        $encodedredirect = strtr(base64_encode($redirect), '+/=', '-_~');

        return $auth_helper->getAuthUrl($this->_auth_url, $params, $encodedredirect);
    }

    public function start_sdk_client(?Account $account = null)
    {
        self::$_sdk_client = new Dropbox($this->get_dropbox_app($account), ['persistent_data_store' => new DatabasePersistentDataStore()]);

        return $this->get_sdk_client($account);
    }

    public function refresh_token(?Account $account = null)
    {
        if (null === $account) {
            Helpers::log_error('Cannot renew the Authorization Token without an account.', 'App', null, __LINE__);

            return false;
        }

        $authorization = $account->get_authorization();

        // Always release the lock, also when a PHP Error is thrown (e.g. in a long running WP-CLI process)
        try {
            return $this->renew_token($account, $authorization);
        } finally {
            $authorization->unlock_token_file();
        }
    }

    /**
     * @return Dropbox|false
     */
    private function renew_token(Account $account, Authorization $authorization)
    {
        // Pause renewing after a temporary error. Errors of the API apply to all sites in the network sharing the token,
        // connection errors can be caused by the server of a single site
        $backoff_transient = 'outofthebox_refresh_backoff_'.$account->get_id();

        // Wait for an exclusive lock. The token file can be shared by multiple processes and sites in the network.
        // The lock of a process that dies is released automatically. Don't wait long, so PHP workers aren't blocked.
        $has_lock = $authorization->try_lock(2);

        if (false === $has_lock) {
            // Another process is renewing the token. Keep using the current token as long as it is actually valid
            $access_token = $authorization->read_access_token();

            if ($access_token instanceof AccessToken) {
                self::$_sdk_client->setAccessToken($access_token);

                if (false === self::$_sdk_client->getOAuth2Client()->isAccessTokenExpired(10)) {
                    return self::$_sdk_client;
                }
            }

            // The token has expired. Wait longer for the other process, e.g. when the API responds slowly
            if (false === $authorization->try_lock(13)) {
                Helpers::log('Cannot get the lock to renew the Authorization Token, it is being renewed by another process.', 'App', ['account_id' => $account->get_id()], __LINE__);

                throw new DropboxClientException('The Authorization Token is being renewed by another process.');
            }
        }

        // Another process may have renewed the token while this process was waiting for the lock.
        // Only the token file is used, never the token in memory as that can belong to another account.
        // The SDK renews the token that is set in the client, so always set the token of this account
        $access_token = $authorization->read_access_token();

        // A missing token file can be a short hiccup of the (network) file system. Check again before the authorization is marked as lost
        if (!$access_token instanceof AccessToken && false === $authorization->has_token_file()) {
            usleep(200000);
            $access_token = $authorization->read_access_token();
        }

        if (!$access_token instanceof AccessToken) {
            // A token file that cannot be decrypted can be caused by a temporary problem, e.g. when the encryption key cannot be read
            if ($authorization->has_token_file()) {
                throw new DropboxClientException('The Authorization Token cannot be read at the moment.');
            }

            Helpers::log_error('Cannot renew the Authorization Token as the token file is empty or missing.', 'App', ['account_id' => $account->get_id()], __LINE__);
            $this->set_authorization_lost($account, $this->get_lost_authorization_marker(''));

            return false;
        }

        self::$_sdk_client->setAccessToken($access_token);

        if (false === self::$_sdk_client->getOAuth2Client()->isAccessTokenExpired()) {
            Helpers::log('The Authorization Token has already been renewed by another process.', 'App', ['account_id' => $account->get_id()], __LINE__);

            return self::$_sdk_client;
        }

        // Without App credentials the token can't be renewed. This isn't a problem of the authorization itself.
        // The credentials are set per site, so this must not pause the renewal for the other sites in the network
        if (empty($this->get_app_key()) || empty($this->get_app_secret())) {
            Helpers::log_error('Cannot renew the Authorization Token as the App credentials are missing. Please sync the license via the plugin settings.', 'App', null, __LINE__);

            throw new DropboxClientException('Cannot renew the Authorization Token as the App credentials are missing. Please sync the license via the plugin settings.');
        }

        // Stop if we need to get a new AccessToken but somehow ended up without a refreshtoken.
        // Don't revoke the authorization, as that would disconnect all sites in the network using this account
        $refresh_token = $access_token->getRefreshToken();

        if (empty($refresh_token)) {
            Helpers::log_error('No Refresh Token found during the renewing of the current token. The account needs to be authorized again.', 'App', ['account_id' => $account->get_id()], __LINE__);
            $this->set_authorization_lost($account, $this->get_lost_authorization_marker(''));

            return false;
        }

        // After a permanent error, don't try to renew with the same refresh token and App credentials on every request.
        // A new authorization (on any site in the network) or other App credentials will be tried again
        $lost_marker = $this->get_lost_authorization_marker($refresh_token);

        if ($lost_marker === get_transient('outofthebox_authorization_lost_'.$account->get_id())) {
            throw new DropboxClientException('The authorization is no longer valid. The account needs to be authorized again.', 401);
        }

        // Don't try to renew the token on every request after a temporary error
        if (false !== get_site_transient($backoff_transient) || false !== get_transient($backoff_transient)) {
            throw new DropboxClientException('Renewing the Authorization Token is paused for a moment after a temporary error.');
        }

        // Refresh token. The SDK renews the token object that is set in the client
        try {
            Helpers::log('Renewing the Authorization Token.', 'App', ['account_id' => $account->get_id()], __LINE__);

            $new_accesstoken = self::$_sdk_client->getAuthHelper()->refreshToken();

            // Don't overwrite a new authorization that has been stored while renewing, e.g. when locking doesn't work between servers.
            // Dropbox doesn't rotate refresh tokens, so another refresh token always means a new authorization
            $stored_access_token = $authorization->read_access_token();

            if ($stored_access_token instanceof AccessToken && !empty($stored_access_token->getRefreshToken()) && $stored_access_token->getRefreshToken() !== $refresh_token) {
                Helpers::log_error('A new authorization has been stored while renewing the Authorization Token. The new authorization is used.', 'App', ['account_id' => $account->get_id()], __LINE__);
                self::$_sdk_client->setAccessToken($stored_access_token);
            } else {
                if (false === $authorization->set_access_token($new_accesstoken)) {
                    Helpers::log_error('The renewed Authorization Token cannot be stored. It is only used for the current request.', 'App', ['account_id' => $account->get_id()], __LINE__);
                } else {
                    Helpers::log('Authorization Token renewed and stored.', 'App', [
                        'account_id' => $account->get_id(),
                        'expires_in' => $new_accesstoken instanceof AccessToken ? $new_accesstoken->getExpiresIn() : null,
                    ], __LINE__);
                }

                self::$_sdk_client->setAccessToken($new_accesstoken);
            }

            delete_transient('outofthebox_authorization_lost_'.$account->get_id());

            if (false !== ($timestamp = wp_next_scheduled('outofthebox_lost_authorisation_notification', ['account_id' => $account->get_id()]))) {
                wp_unschedule_event($timestamp, 'outofthebox_lost_authorisation_notification', ['account_id' => $account->get_id()]);
                Helpers::log('Lost authorization notification unscheduled, as the Authorization Token has been renewed.', 'App', ['account_id' => $account->get_id()], __LINE__);
            }
        } catch (\Exception $ex) {
            // Temporary problems (timeouts, rate limits, server errors) don't mean that the authorization is lost
            if (false === self::is_authorization_error($ex)) {
                if (self::is_connection_error($ex)) {
                    set_transient($backoff_transient, true, MINUTE_IN_SECONDS);
                } else {
                    set_site_transient($backoff_transient, true, MINUTE_IN_SECONDS);
                }
                Helpers::log_error('Cannot refresh Authorization Token due to a temporary error. The authorization is kept.', 'App', null, __LINE__, $ex);

                throw $ex;
            }

            Helpers::log_error('Cannot refresh Authorization Token.', 'App', null, __LINE__, $ex);
            $this->set_authorization_lost($account, $lost_marker);

            throw $ex;
        }

        return self::$_sdk_client;
    }

    /**
     * The marker identifies the refresh token and App credentials that can no longer be used.
     * Only hashes are stored.
     *
     * @param string $refresh_token
     *
     * @return array
     */
    private function get_lost_authorization_marker($refresh_token)
    {
        return [
            'refresh_token' => empty($refresh_token) ? '' : hash('sha256', $refresh_token),
            'app' => hash('sha256', $this->get_app_key().'|'.$this->get_app_secret()),
        ];
    }

    /**
     * Mark the authorization of an account as lost and notify the administrators.
     *
     * @param array $lost_marker see get_lost_authorization_marker()
     */
    private function set_authorization_lost(Account $account, array $lost_marker)
    {
        $account->get_authorization()->set_is_valid(false);

        // Stored per site, as the App credentials can differ per site
        set_transient('outofthebox_authorization_lost_'.$account->get_id(), $lost_marker, MONTH_IN_SECONDS);

        Helpers::log('Authorization marked as lost.', 'App', ['account_id' => $account->get_id(), 'has_refresh_token' => !empty($lost_marker['refresh_token'])], __LINE__);

        // Only when the authorization has just been lost. The cache folder is shared by all sites in the network
        if (!wp_next_scheduled('outofthebox_lost_authorisation_notification', ['account_id' => $account->get_id()])) {
            $is_scheduled = wp_schedule_event(time(), 'daily', 'outofthebox_lost_authorisation_notification', ['account_id' => $account->get_id()]);

            if (false !== $is_scheduled && !is_wp_error($is_scheduled)) {
                Helpers::log('Lost authorization notification scheduled (daily).', 'App', ['account_id' => $account->get_id()], __LINE__);
            } else {
                Helpers::log_error('Cannot schedule the lost authorization notification.', 'App', ['account_id' => $account->get_id()], __LINE__);
            }

            Processor::reset_complete_cache();
        }
    }

    /**
     * Check if an exception means that the authorization itself is no longer valid,
     * e.g. a revoked refresh token, or invalid app credentials.
     *
     * The SDK doesn't provide the HTTP status code of failed requests (the exception code is 0).
     * The body of the response is used as the message of the exception.
     *
     * @return bool
     */
    public static function is_authorization_error(\Exception $ex)
    {
        if (!$ex instanceof DropboxClientException) {
            return false;
        }

        // 401 is only used by the plugin and the SDK itself, when the token can no longer be renewed (see Dropbox::getRenewedAccessToken())
        if (401 === (int) $ex->getCode()) {
            return true;
        }

        $error = json_decode((string) $ex->getMessage(), true);

        if (!is_array($error) || !isset($error['error'])) {
            return false;
        }

        // Errors of the OAuth 2.0 token endpoint, e.g. {"error": "invalid_grant", "error_description": "refresh token is invalid or revoked"}
        if (is_string($error['error'])) {
            return 1 === preg_match('/^(invalid_grant|invalid_client|unauthorized_client)\b/', $error['error']);
        }

        // Authentication errors of the API (HTTP 401). An expired access token can still be renewed, so that isn't a permanent error
        $tag = $error['error']['.tag'] ?? '';

        return in_array($tag, ['invalid_access_token', 'user_suspended', 'missing_scope'], true);
    }

    /**
     * Check if an exception is caused by a connection problem of this server, e.g. a timeout or a DNS error.
     *
     * @return bool
     */
    private static function is_connection_error(\Exception $ex)
    {
        return 1 === preg_match('/^cURL error \d+/', (string) $ex->getMessage());
    }

    /**
     * Check if the authorization of an account has been restored after a failed renewal.
     * A failed renewal never writes the token file, so a token that isn't expired
     * has been renewed by another process or site, or the account has been authorized again.
     *
     * @return bool
     */
    public static function is_authorization_restored(Account $account)
    {
        $access_token = $account->get_authorization()->get_access_token();

        if (!$access_token instanceof AccessToken || empty($access_token->getToken())) {
            return false;
        }

        // Long lived tokens don't expire (expires_in = -1). Use the same margin as OAuth2Client::isAccessTokenExpired()
        if ($access_token->getExpiresIn() < 0 || ((int) $access_token->getCreated() + (int) $access_token->getExpiresIn() - 120) > time()) {
            return true;
        }

        // A new authorization (e.g. on another site in the network) has stored another refresh token after the authorization was lost on this site
        $lost_marker = get_transient('outofthebox_authorization_lost_'.$account->get_id());

        return is_array($lost_marker)
            && !empty($access_token->getRefreshToken())
            && hash('sha256', $access_token->getRefreshToken()) !== ($lost_marker['refresh_token'] ?? '');
    }

    public function create_access_token()
    {
        try {
            $code = sanitize_text_field($_REQUEST['code']);
            $state = sanitize_text_field($_REQUEST['state']);

            Helpers::log('Authorization code received. Requesting Access Token.', 'App', null, __LINE__);

            // Fetch the AccessToken
            $accessToken = self::get_sdk_client()->getAuthHelper()->getAccessToken($code, $state, $this->_auth_url);
            self::$_sdk_client->setAccessToken($accessToken);

            $account_data = self::get_sdk_client()->getCurrentAccount();
            $root_info = $account_data->getRootInfo();
            $root_namespace_id = $root_info['root_namespace_id'];

            $account = new Account($account_data->getAccountId(), $account_data->getDisplayName(), $account_data->getEmail(), $root_namespace_id, $account_data->getAccountType(), $account_data->getProfilePhotoUrl());
            if (false === $account->get_authorization()->set_access_token($accessToken)) {
                throw new \Exception('The authorization cannot be stored. Please check if the cache folder is writable.');
            }
            $account->get_authorization()->unlock_token_file();

            Helpers::log('Access Token received and stored for account.', 'App', [
                'account_id' => $account->get_id(),
                'has_refresh_token' => !empty($accessToken->getRefreshToken()),
                'expires_in' => $accessToken->getExpiresIn(),
            ], __LINE__);

            if ($account_data->emailIsVerified()) {
                $account->set_is_verified(true);
            }

            Accounts::instance()->add_account($account);

            delete_transient('outofthebox_'.$account->get_id().'_is_authorized');
            delete_site_transient('outofthebox_refresh_backoff_'.$account->get_id());
            delete_transient('outofthebox_refresh_backoff_'.$account->get_id());
            delete_transient('outofthebox_authorization_lost_'.$account->get_id());
        } catch (\Exception $ex) {
            Helpers::log_error('Cannot generate Access Token.', 'App', null, __LINE__, $ex);

            return new \WP_Error('broke', esc_html__('Error communicating with API:', 'wpcloudplugins').$ex->getMessage());
        }

        return true;
    }

    /**
     * @param null|bool $is_used_by_other_sites set to true when the authorization isn't revoked at Dropbox, because other sites in the network still use the account
     */
    public function revoke_token(Account $account, &$is_used_by_other_sites = null)
    {
        Helpers::log_error('Authorization for account revoked.', 'App', ['account_id' => $account->get_id(), 'account_email' => $account->get_email()], __LINE__);

        // Reset Personal Folders Back-End if the account it is pointing to is deleted
        $personal_folders_data = Settings::get('userfolder_backend_auto_root', []);
        if (is_array($personal_folders_data) && isset($personal_folders_data['account']) && $personal_folders_data['account'] === $account->get_id()) {
            Settings::save('userfolder_backend_auto_root', []);
        }

        Processor::reset_complete_cache();

        if (false !== ($timestamp = wp_next_scheduled('outofthebox_lost_authorisation_notification', ['account_id' => $account->get_id()]))) {
            wp_unschedule_event($timestamp, 'outofthebox_lost_authorisation_notification', ['account_id' => $account->get_id()]);
            Helpers::log('Lost authorization notification unscheduled, as the account is removed.', 'App', ['account_id' => $account->get_id()], __LINE__);
        }

        Core::instance()->send_lost_authorisation_notification($account->get_id(), true);

        // Revoking the token at Dropbox would disconnect all other sites in the network using this account
        $is_used_by_other_sites = Accounts::is_account_used_by_other_sites($account->get_id());

        if ($is_used_by_other_sites) {
            Helpers::log_error('Authorization is not revoked at Dropbox as the account is still used by other sites in the network. The account is only removed from this site.', 'App', ['account_id' => $account->get_id(), 'account_email' => $account->get_email()], __LINE__);
        } else {
            $this->revoke_access_token($account);
        }

        // The account is also removed when the token cannot be revoked
        Accounts::instance()->remove_account($account->get_id(), $is_used_by_other_sites);

        delete_transient('outofthebox_'.$account->get_id().'_is_authorized');
    }

    /**
     * Revoke the token of the account itself at Dropbox. The client can still contain the token of another account.
     * Revoking the access token also disables the refresh token it belongs to.
     */
    private function revoke_access_token(Account $account)
    {
        $access_token = $account->get_authorization()->get_access_token();

        if (!$access_token instanceof AccessToken || empty($access_token->getToken())) {
            Helpers::log_error('Authorization for account cannot be revoked at Dropbox as the token file is empty or cannot be read. Revoke the access via the Dropbox Account if needed.', 'App', ['account_id' => $account->get_id(), 'account_email' => $account->get_email()], __LINE__);

            return false;
        }

        try {
            self::get_sdk_client($account)->setAccessToken($access_token);

            // The revoke request isn't renewed by the SDK, and an expired access token cannot be revoked
            if (self::$_sdk_client->getOAuth2Client()->isAccessTokenExpired()) {
                $this->refresh_token($account);
            }

            self::$_sdk_client->getAuthHelper()->revokeAccessToken();
        } catch (\Exception $ex) {
            Helpers::log_error('Authorization for account cannot be revoked at Dropbox. Revoke the access via the Dropbox Account if needed.', 'App', ['account_id' => $account->get_id(), 'account_email' => $account->get_email()], __LINE__, $ex);

            return false;
        }

        return true;
    }

    public function get_app_key()
    {
        if (empty($this->_app_key)) {
            $license = License::get_stored_license_data();
            $this->_app_key = $license['appdata']['key'] ?? null;
            $this->_app_token = $license['appdata']['token'] ?? null;

            if (!empty($own_key = Settings::get('dropbox_app_key'))) {
                $this->_app_key = $own_key;
                $this->_own_app = true;
            }
        }

        return $this->_app_key;
    }

    public function get_app_secret()
    {
        if (empty($this->_app_secret)) {
            $license = License::get_stored_license_data();
            $this->_app_secret = $license['appdata']['secret'] ?? null;

            if (!empty($own_secret = Settings::get('dropbox_app_secret'))) {
                $this->_app_secret = $own_secret;
                $this->_own_app = true;
            }
        }

        return $this->_app_secret;
    }

    /**
     * @param null|Account $account
     *
     * @return Dropbox
     */
    public static function get_sdk_client($account = null)
    {
        if (!empty($account)) {
            self::set_current_account($account);
        }

        return self::$_sdk_client;
    }

    /**
     * @param null|mixed $account
     *
     * @return DropboxApp
     */
    public function get_dropbox_app($account = null)
    {
        if (empty(self::$_sdk_client_app)) {
            if (!empty($account)) {
                self::$_sdk_client_app = new DropboxApp($this->get_app_key(), $this->get_app_secret(), $account->get_authorization()->get_access_token());
            } else {
                self::$_sdk_client_app = new DropboxApp($this->get_app_key(), $this->get_app_secret());
            }
        }

        return self::$_sdk_client_app;
    }

    public function get_root_namespace_id($id = '')
    {
        $use_app_folder = Settings::get('use_app_folder', 'No');
        if ('Yes' === $use_app_folder) {
            return '';
        }

        $use_team_folders = Settings::get('use_team_folders', 'No');

        if ('No' === $use_team_folders) {
            return $id;
        }

        $current_account = App::get_current_account();

        if (empty($current_account)) {
            return $id;
        }

        return $current_account->get_root_namespace_id();
    }

    /**
     * @return Accounts
     */
    public function get_accounts()
    {
        return Accounts::instance();
    }

    /**
     * @return Account
     */
    public static function get_current_account()
    {
        if (empty(self::$_current_account) && null !== Processor::instance()->get_shortcode()) {
            $account = Accounts::instance()->get_account_by_id(Processor::instance()->get_shortcode_option('account'));
            if (!empty($account)) {
                self::set_current_account($account);
            }
        }

        return self::$_current_account;
    }

    public static function set_current_account(Account $account)
    {
        if (self::$_current_account !== $account) {
            self::$_current_account = $account;
            Cache::instance_unload();

            if ($account->get_authorization()->has_access_token()) {
                if (empty(self::$_sdk_client)) {
                    self::instance();
                }

                self::$_sdk_client->setAccessToken($account->get_authorization()->get_access_token());
            } elseif (!empty(self::$_sdk_client)) {
                // Never keep using the token of the previous account
                self::$_sdk_client->clearAccessToken();
            }
        }

        return self::$_current_account;
    }

    public static function set_current_account_by_id(string $account_id)
    {
        $account = Accounts::instance()->get_account_by_id($account_id);

        if (empty($account)) {
            Helpers::log_error('Cannot use the requested account as it is not linked with the plugin. Plugin falls back to primary account.', 'App', ['account_id' => $account_id], __LINE__);
            $account = Accounts::instance()->get_primary_account();

            if (empty($account)) {
                self::$_current_account = null;

                // Never keep using the token of the previous account
                if (!empty(self::$_sdk_client)) {
                    self::$_sdk_client->clearAccessToken();
                }

                return self::$_current_account;
            }
        }

        return self::set_current_account($account);
    }

    public static function clear_current_account()
    {
        self::$_current_account = null;
        Cache::instance_unload();
    }

    public function get_auth_uri()
    {
        return $this->_auth_url;
    }
}
