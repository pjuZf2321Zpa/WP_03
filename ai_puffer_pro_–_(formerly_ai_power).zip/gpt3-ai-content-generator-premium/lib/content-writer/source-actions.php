<?php
/** Paid source verification and previews for Content Writer and Automations. */

namespace WPAICG\Lib\ContentWriter\Ajax\Actions;

use WPAICG\ContentWriter\Ajax\AIPKit_Content_Writer_Base_Ajax_Action;
use WPAICG\Lib\ContentWriter\AIPKit_Google_Sheets_Parser;
use WP_Error;

if (!defined('ABSPATH')) {
    exit;
}

class AIPKit_Content_Writer_Verify_Gsheets_Action extends AIPKit_Content_Writer_Base_Ajax_Action
{
    public function handle()
    {
        if (!$this->check_content_writer_or_autogpt_request_access()) {
            return;
        }

        // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce is verified by check_content_writer_or_autogpt_request_access() above.
        $sheet_id = isset($_POST['gsheets_sheet_id']) ? sanitize_text_field(wp_unslash($_POST['gsheets_sheet_id'])) : '';

        // Sanitize the raw JSON string using wp_kses_post. This is a safe way to handle
        // potentially complex string data that needs to be parsed, as it strips harmful HTML/script tags
        // while preserving the essential JSON structure.
        // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce is verified by check_content_writer_or_autogpt_request_access() above.
        $credentials_json_raw = isset($_POST['gsheets_credentials']) ? wp_kses_post(wp_unslash($_POST['gsheets_credentials'])) : '';
        if (empty($sheet_id) || empty($credentials_json_raw)) {
            $this->send_wp_error(new WP_Error('missing_gsheets_info', __('Google Sheet ID and Credentials are required.', 'gpt3-ai-content-generator')), 400);
            return;
        }
        $credentials_array = json_decode($credentials_json_raw, true);
        if (json_last_error() !== JSON_ERROR_NONE || !is_array($credentials_array)) {
            $this->send_wp_error(new WP_Error('invalid_json_format', __('The provided credentials are not in a valid JSON format.', 'gpt3-ai-content-generator')), 400);
            return;
        }

        if (!class_exists('\WPAICG\Lib\ContentWriter\AIPKit_Google_Sheets_Parser')) {
            $this->send_wp_error(new WP_Error('gsheets_parser_missing', __('Google Sheets parser component is missing.', 'gpt3-ai-content-generator')), 500);
            return;
        }

        try {
            // The parser now expects an array. Pass the validated array from above.
            $sheets_parser = new AIPKit_Google_Sheets_Parser($credentials_array);

            // Use the new, efficient verification method.
            $result = $sheets_parser->verify_access($sheet_id);

            if (is_wp_error($result)) {
                $this->send_wp_error($result);
            } else {
                wp_send_json_success(['message' => __('Connection successful.', 'gpt3-ai-content-generator')]);
            }
        } catch (\Exception $e) {
            $this->send_wp_error(new WP_Error('gsheets_verification_failed', $e->getMessage()), 400);
        }
    }
}

namespace WPAICG\ContentWriter\Ajax\Actions;

use WPAICG\ContentWriter\Ajax\AIPKit_Content_Writer_Base_Ajax_Action;
use WPAICG\Lib\Utils\AIPKit_Url_Scraper;
use WP_Error;

class AIPKit_Content_Writer_Scrape_Url_Action extends AIPKit_Content_Writer_Base_Ajax_Action
{
    public function handle()
    {
        if (!$this->check_content_writer_or_autogpt_request_access()) {
            return;
        }

        if (!class_exists('\WPAICG\Lib\Utils\AIPKit_Url_Scraper')) {
            $this->send_wp_error(new WP_Error('missing_scraper', __('The URL scraping component is unavailable. This is a Pro feature.', 'gpt3-ai-content-generator')), 500);
            return;
        }

        // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce is verified by check_content_writer_or_autogpt_request_access() above.
        $url = isset($_POST['url']) ? esc_url_raw(wp_unslash($_POST['url'])) : '';

        if (empty($url)) {
            $this->send_wp_error(new WP_Error('missing_url', __('Please provide a URL to scrape.', 'gpt3-ai-content-generator')), 400);
            return;
        }

        $scraper = new AIPKit_Url_Scraper();
        $result = $scraper->scrape_with_metadata($url);

        if (is_wp_error($result)) {
            $this->send_wp_error($result);
        } else {
            wp_send_json_success([
                'scraped_text' => $result['text'],
                'metadata' => $result['metadata'],
            ]);
        }
    }
}

namespace WPAICG\Lib\ContentWriter\Ajax\Actions;

use WPAICG\ContentWriter\Ajax\AIPKit_Content_Writer_Base_Ajax_Action;
use WPAICG\Lib\ContentWriter\AIPKit_Rss_Item_Selector;
use WP_Error;

class AIPKit_Content_Writer_Fetch_Rss_Action extends AIPKit_Content_Writer_Base_Ajax_Action
{
    /**
     * Handle the AJAX request.
     *
     * @return void
     */
    public function handle()
    {
        if (!$this->check_content_writer_or_autogpt_request_access()) {
            return;
        }

        // Get RSS feed URLs
        // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce is verified by check_content_writer_or_autogpt_request_access() above.
        $feeds_raw = isset($_POST['rss_feeds']) ? sanitize_textarea_field(wp_unslash($_POST['rss_feeds'])) : '';

        if (empty($feeds_raw)) {
            $this->send_wp_error(new WP_Error('missing_feeds', __('Please enter at least one RSS feed URL.', 'gpt3-ai-content-generator')), 400);
            return;
        }

        // Optional keyword filters (for count accuracy)
        // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce is verified by check_content_writer_or_autogpt_request_access() above.
        $include_keywords = isset($_POST['rss_include_keywords']) ? sanitize_text_field(wp_unslash($_POST['rss_include_keywords'])) : '';
        // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce is verified by check_content_writer_or_autogpt_request_access() above.
        $exclude_keywords = isset($_POST['rss_exclude_keywords']) ? sanitize_text_field(wp_unslash($_POST['rss_exclude_keywords'])) : '';

        // phpcs:ignore WordPress.Security.NonceVerification.Missing, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Nonce checked above; strict integer validation is performed by the shared selector before use.
        $item_limit = isset($_POST['rss_item_limit']) ? wp_unslash($_POST['rss_item_limit']) : '';
        // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce checked above.
        $task_id = isset($_POST['task_id']) ? absint($_POST['task_id']) : 0;
        if ($task_id && !\WPAICG\AIPKit_Role_Manager::user_can_access_module('autogpt')) {
            $this->send_wp_error(new WP_Error('permission_denied', __('You do not have permission to use this feature.', 'gpt3-ai-content-generator')), 403);
            return;
        }

        // Parse and count feed URLs
        $feed_urls = array_filter(array_map('trim', explode("\n", $feeds_raw)));
        $valid_feed_urls = array_filter($feed_urls, function ($url) {
            return filter_var($url, FILTER_VALIDATE_URL) !== false;
        });

        if (empty($valid_feed_urls)) {
            $this->send_wp_error(new WP_Error('invalid_urls', __('No valid RSS feed URLs found. Please check your input.', 'gpt3-ai-content-generator')), 400);
            return;
        }

        // Check if parser class exists
        if (!class_exists(AIPKit_Rss_Item_Selector::class)) {
            $this->send_wp_error(new WP_Error('rss_parser_missing', __('RSS parser component is missing.', 'gpt3-ai-content-generator')), 500);
            return;
        }

        try {
            $selection = AIPKit_Rss_Item_Selector::select([
                'rss_feeds' => $feeds_raw,
                'rss_include_keywords' => $include_keywords,
                'rss_exclude_keywords' => $exclude_keywords,
                'rss_item_limit' => $item_limit,
            ], $task_id);
            if (is_wp_error($selection)) {
                $this->send_wp_error($selection);
                return;
            }
            $filtered_items = $selection['items'];

            $total_feeds = count($valid_feed_urls);
            $total_items = count($filtered_items);
            $matched_titles = array_values(array_filter(array_map(
                static function (array $item): string {
                    return sanitize_text_field((string) ($item['title'] ?? ''));
                },
                $filtered_items
            )));

            wp_send_json_success([
                'feeds_found' => $total_feeds,
                'items_found' => $total_items,
                'matching_count' => $selection['matching_count'],
                'limited' => $selection['limited'],
                'titles'      => $matched_titles,
            ]);
        } catch (\Exception $e) {
            $this->send_wp_error(new WP_Error('rss_fetch_failed', $e->getMessage()), 400);
        }
    }

}
