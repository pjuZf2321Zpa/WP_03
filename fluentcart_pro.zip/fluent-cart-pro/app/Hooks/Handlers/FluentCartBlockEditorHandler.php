<?php

namespace FluentCartPro\App\Hooks\Handlers;

use FluentCart\App\App;
use FluentCart\App\Services\Email\EmailNotifications;
use FluentCartPro\App\Modules\Promotional\OrderBump\OrderBumpTemplateService;
use FluentCartPro\App\Services\Email\StarterTemplates;
use FluentCart\App\Services\Permission\PermissionManager;
use FluentCartPro\App\Utils\Enqueuer\Vite as ProVite;
use FluentCart\Framework\Support\Arr;

class FluentCartBlockEditorHandler
{
    /**
     * Data passed to the iframe editor via window.fctEditorBoot
     * @var array
     */
    protected $editorBootData = [];

    public function register()
    {
        add_action('init', function () {
            register_post_type('fct-dummy', [
                    'label'        => 'Email-Body',
                    'public'       => false,
                    'show_in_rest' => true,
                //  'supports'     => ['title', 'editor', 'thumbnail'],
                    'supports'     => ['editor']
            ]);

            // Register email-only block types (render_callback only, no editor scripts)
            // so WP's REST API block-renderer can SSR them. Assets are enqueued
            // separately by enqueueEmailEditorBlocks() in the email editor context.
            foreach (static::getEmailOnlyBlocks() as $blockClass) {
                $blockClass::make()->registerBlockType();
            }

            foreach (static::getOrderBumpBlocks() as $blockClass) {
                $blockClass::make()->registerBlockType();
            }

            if (isset($_REQUEST['fluent_cart_block_editor'])) {
                // Require authentication
                if (!is_user_logged_in()) {
                    $scheme = is_ssl() ? 'https://' : 'http://';
                    $current_url = $scheme . (isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : '') . (isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '');
                    wp_safe_redirect(wp_login_url(esc_url_raw($current_url)));
                    exit;
                }

                $blockType = $this->getSanitizedRequestString($_REQUEST, 'block_type');
                $requiredCap = $this->resolveRequiredCapability($blockType, $_REQUEST);

                if (!PermissionManager::userCan($requiredCap)) {
                    status_header(403);
                    wp_die(__('Sorry, you are not allowed to access this page.', 'fluent-cart-pro'), 403);
                }

                $requireNonce = (bool)apply_filters('fluent_cart/block_editor_require_nonce', true, $blockType, $_REQUEST);
                if ($requireNonce) {
                    $nonce = $this->getSanitizedRequestString($_REQUEST, '_fct_nonce');
                    if (!$nonce || !wp_verify_nonce($nonce, 'fct_block_editor')) {
                        status_header(403);
                        wp_die(__('Invalid or missing security token.', 'fluent-cart-pro'), 403);
                    }
                }
                if (!defined('IFRAME_REQUEST')) {
                    define('IFRAME_REQUEST', true);
                }

                remove_action('enqueue_block_editor_assets', 'wp_enqueue_editor_block_directory_assets');
                add_action('fluent_cart/block_editor_head', function () {
                    ProVite::enqueueStyle(
                            'fct_editor_css',
                            'admin/BlockEditor/EmailEditor/style/email-editor.scss'
                    );
                });
                add_filter('should_load_separate_core_block_assets', '__return_false', 20);
                $this->renderBlockEditor($_REQUEST);

                add_action('template_redirect', function () {
                    $this->renderPage();
                    exit(200);
                }, -1000);

            }
        }, 2);

        // The editor names the document after the hidden post type. It fetches that over REST without
        // saying which editor it is, so the card editor sends a header and gets its own name.
        add_filter('rest_prepare_post_type', function ($response, $postType) {
            if ($postType->name !== 'fct-dummy' || !isset($_SERVER['HTTP_X_FCT_BLOCK_TYPE'])
                || $_SERVER['HTTP_X_FCT_BLOCK_TYPE'] !== 'order_bump_template') {
                return $response;
            }

            $label = __('Order Bump Card', 'fluent-cart-pro');
            $data = $response->get_data();
            $labels = isset($data['labels']) ? (array)$data['labels'] : [];
            $labels['name'] = $label;
            $labels['singular_name'] = $label;
            $data['name'] = $label;
            $data['labels'] = $labels;
            $response->set_data($data);

            return $response;
        }, 10, 2);

        // REST route for autosave
        add_action('rest_api_init', function () {
            register_rest_route('fluent-cart/v1', '/editor-autosave', [
                    'methods'             => 'POST',
                    'callback'            => [$this, 'handleEditorAutosave'],
                    // The same permission as opening that editor: the card editor needs store/sensitive, the others manage_options.
                    'permission_callback' => function (\WP_REST_Request $request) {
                        $params = $request->get_json_params();
                        if (!is_array($params) || !$params) {
                            $params = $request->get_body_params();
                        }
                        $params = is_array($params) ? $params : [];
                        $blockType = isset($params['block_type']) ? sanitize_text_field(wp_unslash((string)$params['block_type'])) : '';

                        return PermissionManager::userCan($this->resolveRequiredCapability($blockType, $params));
                    }
            ]);
        });
    }

    private function getSanitizedRequestString(array $request, string $key): string
    {
        if (!isset($request[$key])) {
            return '';
        }

        return sanitize_text_field(wp_unslash((string)$request[$key]));
    }

    /**
     * Resolve required capability from editor context.
     *
     * Keeps both filter hooks for backward compatibility.
     */
    private function resolveRequiredCapability(string $blockType, array $requestContext = []): string
    {
        // The card editor opens from Settings → Order Bump, which needs this permission.
        if ($blockType === 'order_bump_template') {
            return 'store/sensitive';
        }

        return 'is_super_admin';
    }

    public function renderBlockEditor($data = [])
    {
        do_action('litespeed_control_set_nocache', 'fluentcart api request');
        nocache_headers();

        $context = Arr::get($data, 'block_type');
        $this->unregisterDefaultBlockPatterns($context, $data);

        $requiredCap = $this->resolveRequiredCapability((string)$context, $data);
        $hasAccess = PermissionManager::userCan($requiredCap);

        $entity = $this->resolveEntityContent($context, $data);

        if (!$hasAccess) {
            echo '<h3 style="padding: 100px; text-align: center;">' . esc_html__('Sorry, you do not have access to this page.', 'fluent-cart-pro') . '</h3>';
            exit(200);
        }

        add_filter('should_load_separate_core_block_assets', '__return_false', 20);
        show_admin_bar(false);

        global $post;
        $post = $this->getOrCreateDummyPost($entity['title'], $entity['content']);

        $this->prepareEditorBootData($context, $data, $entity);
        $this->setupEditorHooks($post);
    }

    /**
     * Resolve entity content from the database based on block_type and bid.
     *
     * @param string|null $context The block_type (template).
     * @param array $data The request data.
     * @return array With keys: content, title, id, updatedAt.
     */
    private function resolveEntityContent($context, $data)
    {
        $post_content = '<!-- wp:paragraph --><p></p><!-- /wp:paragraph -->';
        $post_title = 'Demo Title';
        $recordId = null;
        $recordUpdatedAt = current_time('mysql');

        if ($context === 'template') {
            $eventKey = Arr::get($data, 'bid');

            if ($eventKey && $eventKey !== 'undefined') {
                $notification = EmailNotifications::getNotification($eventKey);

                if ($notification) {
                    $post_content = Arr::get($notification, 'settings.email_body', '');
                    $post_title = Arr::get($notification, 'settings.subject', '');
                    $recordId = $eventKey;
                    $recordUpdatedAt = current_time('mysql');
                }
            }
        } elseif ($context === 'pdf_template') {
            $templateKey = Arr::get($data, 'bid', '');

            if ($templateKey && class_exists(\FluentCart\App\Services\PDF\ReceiptPdfTemplateService::class)) {
                $service = new \FluentCart\App\Services\PDF\ReceiptPdfTemplateService();
                $templates = $service->getTemplates();
                $templates = \FluentCartPro\App\Services\PDF\LegacyPdfTemplateMigrator::migrateTemplates($service, $templates);

                if (isset($templates[$templateKey])) {
                    $pdfStructure = Arr::get($templates[$templateKey], 'pdf_settings.0.pdf_structure', []);
                    $post_content = Arr::get($pdfStructure, 'content', '');
                    $post_title = Arr::get($templates[$templateKey], 'title', 'PDF Template');
                    $recordId = $templateKey;
                    $recordUpdatedAt = current_time('mysql');
                }
            }
        } elseif ($context === 'order_bump_template') {
            $template = (new OrderBumpTemplateService())->getTemplate((string)Arr::get($data, 'bid', ''));

            if ($template) {
                $post_content = Arr::get($template, 'content', '');
                $post_title = Arr::get($template, 'title', 'Order Bump Card');
                $recordId = Arr::get($template, 'name');
                $recordUpdatedAt = current_time('mysql');
            }
        }

        if (!$post_content) {
            $post_content = '<!-- wp:paragraph --><p></p><!-- /wp:paragraph -->';
        }

        return [
                'content'   => $post_content,
                'title'     => $post_title,
                'id'        => $recordId,
                'updatedAt' => $recordUpdatedAt,
        ];
    }

    /**
     * Retrieve or create the fct-dummy post used as a simulated post for the editor.
     *
     * @param string $title
     * @param string $content
     * @return \WP_Post
     */
    private function getOrCreateDummyPost($title, $content)
    {
        $firstPost = App::db()->table('posts')
                ->where('post_type', 'fct-dummy')
                ->first();

        if ($firstPost) {
            $simulatedPost = get_post($firstPost->ID);
            $simulatedPost->post_content = $content;
            $simulatedPost->post_title = $title;
        } else {
            $newPostId = wp_insert_post(array(
                    'post_title'   => $title,
                    'post_content' => $content,
                    'post_type'    => 'fct-dummy',
                    'post_status'  => 'draft',
            ));

            $simulatedPost = get_post($newPostId);
        }

        return $simulatedPost;
    }

    /**
     * Build the editorBootData array that is injected into the iframe as window.fctEditorBoot.
     *
     * @param string|null $context
     * @param array $data
     * @param array $entity Return value from resolveEntityContent().
     */
    private function prepareEditorBootData($context, $data, $entity)
    {
        $canSave = (!empty($context) && $context !== '0');
        if (empty($context) && (int)Arr::get($data, 'bid') === 0) {
            $canSave = false;
        }

        $disableProTemplates = apply_filters('fluent_cart_pro/disable_pro_email_templates', true);
        $starterTemplates = [];
        if ($context === 'template' && !empty($entity['id'])) {
            $starterTemplates = StarterTemplates::getTemplatesForNotification($entity['id']);
            if ($disableProTemplates) {
                $starterTemplates = array_values(array_filter($starterTemplates, function ($t) {
                    $id = isset($t['id']) ? $t['id'] : '';
                    return strpos($id, '/pro') === false && strpos($id, '/modern') === false;
                }));
            }
        }

        $this->editorBootData = [
                'entity'              => [
                        'id'         => $entity['id'],
                        'block_type' => $context,
                        'title'      => $entity['title'],
                        'content'    => $entity['content'],
                        'updated_at' => $entity['updatedAt'],
                ],
                'can_save'            => $canSave,
                'autosave'            => [
                        'endpoint' => rest_url('fluent-cart/v1/editor-autosave'),
                        'nonce'    => wp_create_nonce('wp_rest')
                ],
                'starter_templates'   => $starterTemplates,
                'disableProTemplates' => $disableProTemplates,
        ];
    }

    /**
     * Register wp_enqueue_scripts callbacks, post-locking filters, and other editor hooks.
     *
     * @param \WP_Post $post
     */
    private function setupEditorHooks($post)
    {
        add_action('wp_enqueue_scripts', function () use ($post) {
            wp_enqueue_script('postbox', admin_url('js/postbox.min.js'), array('jquery-ui-sortable'), false, 1);
            wp_enqueue_style('dashicons');
            wp_enqueue_style('media');
            wp_enqueue_style('admin-menu');
            wp_enqueue_style('admin-bar');
            wp_enqueue_style('l10n');

            wp_add_inline_script(
                    'wp-api-fetch',
                    \sprintf(
                            'wp.apiFetch.use( wp.apiFetch.createPreloadingMiddleware( %s ) );',
                            wp_json_encode(
                                    array(
                                            '/wp/v2/fct-dummy/' . $post->ID . '?context=edit' => array(
                                                    'body' => array(
                                                            'id'                 => $post->ID,
                                                            'title'              => array('raw' => $post->post_title),
                                                            'content'            => array(
                                                                    'block_format' => 1,
                                                                    'raw'          => $post->post_content,
                                                            ),
                                                            'excerpt'            => array('raw' => ''),
                                                            'date'               => '',
                                                            'date_gmt'           => '',
                                                            'modified'           => '',
                                                            'modified_gmt'       => '',
                                                            'link'               => home_url('/'),
                                                            'guid'               => array(),
                                                            'parent'             => 0,
                                                            'menu_order'         => 0,
                                                            'author'             => 0,
                                                            'featured_media'     => 0,
                                                            'comment_status'     => 'closed',
                                                            'ping_status'        => 'closed',
                                                            'template'           => '',
                                                            'meta'               => array(),
                                                            '_links'             => array(),
                                                            'type'               => 'fct-dummy',
                                                            'status'             => 'pending',
                                                            'slug'               => '',
                                                            'generated_slug'     => '',
                                                            'permalink_template' => home_url('/'),
                                                    ),
                                            ),
                                    )
                            )
                    ),
                    'after'
            );
        }, 11);

        add_action('wp_enqueue_scripts', function ($hook) use ($post) {
            include_once ABSPATH . 'wp-admin/includes/post.php';
            $this->enqueueEditorAssets($hook, $post);
        });

        // Disable post locking dialogue.
        add_filter('show_post_locked_dialog', '__return_false');

        $GLOBALS['wp_rich_edit'] = true;
        add_filter('user_can_richedit', '__return_true', 1000);

        // This prevents other logged-in users taking a lock of the post on the front-end.
        add_filter('get_post_metadata', function ($value, $post_id, $meta_key) {
            if ($meta_key !== '_edit_lock') {
                return $value;
            }
            return time() . ':' . get_current_user_id();
        }, 10, 3);

        // Disable Jetpack Blocks for now.
        add_filter('jetpack_gutenberg', '__return_false');
    }

    /*
    |--------------------------------------------------------------------------
    | Assets: enqueueEditorAssets(), enqueueEditorScripts(),
    |         enqueueEditorStyles(), enqueueCustomEditorAssets()
    |--------------------------------------------------------------------------
    */

    private function enqueueEditorAssets($hook, $post)
    {
        $initial_edits = array(
                'title'   => $post->post_title,
                'content' => $post->post_content,
                'excerpt' => $post->post_excerpt,
        );

        $editor_settings = $this->getEditorSettings($post);

        $init_script = <<<JS
			( function() {
				window._wpLoadBlockEditor = new Promise( function( resolve, reject ) {
					wp.domReady( function() {
						try {
							wp.blocks.setCategories( %s );
							resolve( wp.editPost.initializeEditor( 'editor', "%s", %d, %s, %s ) );
						} catch (e) {
							console.error('[FCT Editor] initializeEditor failed:', e);
							reject(e);
						}
					} );
				} );
			} )();
			JS;

        $script = sprintf(
                $init_script,
                wp_json_encode($editor_settings['blockCategories']),
                $post->post_type,
                $post->ID,
                wp_json_encode($editor_settings),
                wp_json_encode($initial_edits)
        );
        wp_add_inline_script('wp-edit-post', $script);

        $this->enqueueEditorScripts($post);
        $this->enqueueEditorStyles();
        $this->enqueueCustomEditorAssets();
    }

    /**
     * Enqueue media, tinymce, and postbox init scripts.
     *
     * @param \WP_Post $post
     */
    private function enqueueEditorScripts($post)
    {
        wp_enqueue_media(
                array(
                        'post' => null
                )
        );

        add_filter('user_can_richedit', '__return_true');
        wp_tinymce_inline_scripts();
        wp_enqueue_editor();
    }

    /**
     * Enqueue wp-edit-post, block library styles, and editor format library assets.
     */
    private function enqueueEditorStyles()
    {
        wp_enqueue_style('wp-edit-post');
        wp_enqueue_style('global-styles');
        wp_enqueue_style('wp-block-library');
        wp_enqueue_style('wp-block-image');
        wp_enqueue_style('wp-block-group');
        wp_enqueue_style('wp-block-heading');
        wp_enqueue_style('wp-block-button');
        wp_enqueue_style('wp-block-paragraph');
        wp_enqueue_style('wp-block-separator');
        wp_enqueue_style('wp-block-columns');
        wp_enqueue_style('wp-block-cover');
        wp_enqueue_style('global-styles-css-custom-properties');
        wp_enqueue_style('wp-block-spacer');

        add_action('fluent_cart_enqueue_block_editor_assets', 'wp_enqueue_editor_format_library_assets');
        do_action('fluent_cart_enqueue_block_editor_assets');
    }

    /**
     * Enqueue fct_editor_custom JS, inline block editor config, smartcodes, and boot data.
     */
    private function enqueueCustomEditorAssets()
    {
        // Enqueue FluentCart block assets for the email editor
        $this->enqueueEmailEditorBlocks();

        // Bootstrap the block definition server-side so the client knows about it
        if (function_exists('get_block_editor_server_block_settings')) {
            $serverBlocks = get_block_editor_server_block_settings();
            $fctBlocks = [];
            foreach ($serverBlocks as $name => $definition) {
                if (strpos($name, 'fluent-cart/') === 0) {
                    $fctBlocks[$name] = $definition;
                }
            }
        }

        $composeNavPath = ProVite::getEnqueuePath( 'admin/BlockEditor/EmailEditor/scripts/composeNav.js' );

        wp_enqueue_script(
            'fct_editor_compose_nav',
                $composeNavPath,
            [],
            FLUENTCART_PRO_PLUGIN_VERSION,
            true
        );

        wp_enqueue_script(
            'fct_editor_custom',
            ProVite::getEnqueuePath( 'admin/BlockEditor/EmailEditor/scripts/emailEditorInit.js' ),
            ['react', 'wp-components', 'wp-compose', 'wp-data', 'wp-edit-post', 'wp-i18n', 'wp-plugins', 'fct_editor_compose_nav'],
            FLUENTCART_PRO_PLUGIN_VERSION,
            true
        );

        wp_enqueue_script(
            'fct_editor_template_picker',
            ProVite::getEnqueuePath( 'admin/BlockEditor/EmailEditor/scripts/TemplatePicker.js' ),
            ['wp-plugins', 'wp-components', 'wp-element', 'wp-blocks', 'wp-data', 'fct_editor_custom'],
            FLUENTCART_PRO_PLUGIN_VERSION,
            true
        );


        // Inject smartcodes and condition presets into the iframe window
        $shortcodeGroups = \FluentCart\App\Helpers\EditorShortCodeHelper::getEmailNotificationShortcodes();

        // Loop shortcodes are only relevant when pro editor features are active
        if (empty($this->editorBootData['disableProTemplates'])) {
            $shortcodeGroups['item'] = \FluentCart\App\Helpers\EditorShortCodeHelper::getItemShortCodes();
            $shortcodeGroups['download'] = \FluentCart\App\Helpers\EditorShortCodeHelper::getDownloadShortCodes();
            $shortcodeGroups['subscription'] = \FluentCart\App\Helpers\EditorShortCodeHelper::getSubscriptionShortCodes();
        }
        if ($this->isOrderBumpEditor()) {
            // A card has no order or customer to read, only the offer.
            $shortcodeGroups = [\FluentCartPro\App\Modules\Promotional\OrderBump\OrderBumpTemplateRenderer::shortcodeGroup()];
        }
        $conditionPresets = \FluentCart\App\Services\Email\ConditionPresets::forJs();
        wp_add_inline_script(
                'fct_editor_custom',
                'window.fctSmartCodes = ' . wp_json_encode(array_values($shortcodeGroups)) . ';'
                . "\n" . 'window.fctConditionPresets = ' . wp_json_encode(array_values($conditionPresets)) . ';',
                'before'
        );

        if ($this->isOrderBumpEditor()) {
            wp_add_inline_script(
                    'wp-api-fetch',
                    "wp.apiFetch.use(function (options, next) { options.headers = Object.assign({}, options.headers, {'X-Fct-Block-Type': 'order_bump_template'}); return next(options); });"
            );
        }

        if (!empty($this->editorBootData)) {
            wp_add_inline_script(
                    'fct_editor_custom',
                    'window.fctEditorBoot = ' . wp_json_encode($this->editorBootData) . ';',
                    'before'
            );
        }
    }

    /**
     * Handle autosave requests for the block editor iframe.
     * Updates existing template records only.
     * If block_type is empty and id/bid is 0, nothing will be created.
     *
     * @param \WP_REST_Request $request
     * @return \WP_REST_Response|\WP_Error
     */
    public function handleEditorAutosave(\WP_REST_Request $request)
    {
        $params = $request->get_json_params();
        if (!is_array($params) || !$params) {
            $params = $request->get_body_params();
        }
        $params = is_array($params) ? $params : [];

        $blockType = isset($params['block_type']) ? sanitize_text_field(wp_unslash((string)$params['block_type'])) : '';
        $entityId = isset($params['id']) ? sanitize_text_field(wp_unslash((string)$params['id'])) : '';
        $content = isset($params['content']) ? wp_kses_post(wp_unslash((string)$params['content'])) : '';
        $hash = isset($params['hash']) ? sanitize_text_field(wp_unslash((string)$params['hash'])) : '';

        // Basic guard: if block type empty and no existing entity, do not create
        if (empty($blockType) && empty($entityId)) {
            return new \WP_REST_Response([
                    'status'  => 'skipped',
                    'message' => 'No block_type provided; nothing created.'
            ], 200);
        }

        if (!in_array($blockType, ['template', 'pdf_template', 'order_bump_template'], true)) {
            return new \WP_Error('invalid_block_type', __('Unsupported block_type', 'fluent-cart-pro'), ['status' => 400]);
        }

        $requiredCap = $this->resolveRequiredCapability($blockType, $params);
        if (!PermissionManager::userCan($requiredCap)) {
            return new \WP_Error('forbidden', __('You do not have permission to autosave this item', 'fluent-cart-pro'), ['status' => 403]);
        }

        // Handle PDF template autosave
        if ($blockType === 'pdf_template') {
            return $this->handlePdfTemplateAutosave($entityId, $content, $hash);
        }

        if ($blockType === 'order_bump_template') {
            // Raw markup: unslashing would break block attributes such as \u0026.
            return $this->handleOrderBumpTemplateAutosave($entityId, isset($params['content']) ? (string)$params['content'] : '', $hash);
        }

        $now = current_time('mysql');
        $created = false;
        $record = null;

        if (!empty($entityId)) {
            $record = EmailNotifications::getNotification($entityId);
            if (!$record) {
                return new \WP_Error('not_found', __('Entity not found', 'fluent-cart-pro'), ['status' => 404]);
            }
        } else {
            return new \WP_Error('invalid_entity', __('Autosave requires an existing entity id.', 'fluent-cart-pro'), ['status' => 400]);
        }

        $dirty = false;
        $emailBody = Arr::get($record, 'settings.email_body', '');

        if ($emailBody !== $content) {
            $updateData = [
                    'subject'         => Arr::get($record, 'settings.subject', ''),
                    'email_body'      => $content,
                    'active'          => Arr::get($record, 'settings.active', 'yes'),
                    'is_default_body' => !empty($content) ? 'no' : 'yes'
            ];

            try {
                $result = EmailNotifications::updateNotification($entityId, $updateData);
                $dirty = true;

                $afterSave = EmailNotifications::getNotification($entityId);
                $record = $afterSave ?: $record;
            } catch (\Exception $e) {
                return new \WP_Error('update_failed', $e->getMessage(), ['status' => 500]);
            }
        }

        $updatedAt = isset($record->updated_at) ? $record->updated_at : $now;

        return new \WP_REST_Response([
                'status'     => $created ? 'created' : ($dirty ? 'ok' : 'noop'),
                'id'         => $entityId,
                'hash'       => $hash,
                'updated_at' => $updatedAt,
                'saved_at'   => $now,
                'created'    => $created
        ], 200);
    }

    /**
     * Handle autosave for order bump card template content.
     */
    private function handleOrderBumpTemplateAutosave($entityId, $content, $hash)
    {
        $service = new OrderBumpTemplateService();
        $template = $service->getTemplate((string)$entityId);

        if (!$template) {
            return new \WP_Error('not_found', __('Order bump template not found', 'fluent-cart-pro'), ['status' => 404]);
        }

        // An empty editor must not blank the live card.
        $content = $service->clean($content);
        $dirty = false;
        if ($content !== '' && Arr::get($template, 'content', '') !== $content) {
            // The editor shows Saved only when the card was really stored, so it keeps its unsaved state on a failure.
            try {
                $saved = $service->saveContent((string)$entityId, $content);
            } catch (\FluentCart\Framework\Database\QueryException $e) {
                $saved = false;
            }

            if (!$saved) {
                return new \WP_Error('save_failed', __('The card could not be saved', 'fluent-cart-pro'), ['status' => 500]);
            }

            $dirty = true;
        }

        $now = current_time('mysql');

        return new \WP_REST_Response([
            'status'     => $dirty ? 'ok' : 'noop',
            'id'         => $entityId,
            'hash'       => $hash,
            'updated_at' => $now,
            'saved_at'   => $now,
            'created'    => false
        ], 200);
    }

    /**
     * Handle autosave for PDF template block editor content.
     */
    private function handlePdfTemplateAutosave($entityId, $content, $hash)
    {
        if (empty($entityId) || !class_exists(\FluentCart\App\Services\PDF\ReceiptPdfTemplateService::class)) {
            return new \WP_Error('invalid_entity', __('PDF template entity not found', 'fluent-cart-pro'), ['status' => 400]);
        }

        $service = new \FluentCart\App\Services\PDF\ReceiptPdfTemplateService();
        $templates = $service->getTemplates();

        if (!isset($templates[$entityId])) {
            return new \WP_Error('not_found', __('PDF template not found', 'fluent-cart-pro'), ['status' => 404]);
        }

        $pdfStructure = Arr::get($templates[$entityId], 'pdf_settings.0.pdf_structure', []);
        $existingContent = Arr::get($pdfStructure, 'content', '');

        $dirty = false;
        if ($existingContent !== $content) {
            $pdfStructure['content'] = $content;
            $service->setTemplateProperties($pdfStructure, $entityId);
            $dirty = true;
        }

        $now = current_time('mysql');

        return new \WP_REST_Response([
            'status'     => $dirty ? 'ok' : 'noop',
            'id'         => $entityId,
            'hash'       => $hash,
            'updated_at' => $now,
            'saved_at'   => $now,
            'created'    => false
        ], 200);
    }

    function gutenberg_get_available_image_sizes()
    {
        $size_names = apply_filters(
                'image_size_names_choose',
                array(
                        'thumbnail' => __('Thumbnail', 'fluent-cart-pro'),
                        'medium'    => __('Medium', 'fluent-cart-pro'),
                        'large'     => __('Large', 'fluent-cart-pro'),
                        'full'      => __('Full Size', 'fluent-cart-pro'),
                )
        );
        $all_sizes = array();
        foreach ($size_names as $size_slug => $size_name) {
            $all_sizes[] = array(
                    'slug' => $size_slug,
                    'name' => $size_name,
            );
        }
        return $all_sizes;
    }

    protected function renderPage()
    {
        add_action('fluent_cart/new_block_editor_footer', function () {
            wp_underscore_playlist_templates();
            wp_print_footer_scripts();
            wp_print_media_templates();
            wp_enqueue_global_styles();
            wp_enqueue_stored_styles();
            wp_maybe_inline_styles();
        });

        add_action('fluent_cart_block_editor/head', 'wp_enqueue_scripts', 1);
        add_action('fluent_cart_block_editor/head', 'wp_resource_hints', 2);
        add_action('fluent_cart_block_editor/head', 'wp_preload_resources', 1);
        add_action('fluent_cart_block_editor/head', 'wp_print_styles', 8);
        add_action('fluent_cart_block_editor/head', 'wp_print_head_scripts', 9);
        add_action('fluent_cart_block_editor/head', 'wp_custom_css_cb', 101);

        $this->unloadOtherScripts();
        ?>
        <!DOCTYPE html>
        <html <?php language_attributes(); ?>>
        <head>
            <title>FluentCart Block Editor</title>
            <meta charset='utf-8'>
            <meta name="viewport"
                  content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=0,viewport-fit=cover"/>
            <meta name="mobile-web-app-capable" content="yes">
            <meta name="robots" content="noindex">
            <?php do_action('fluent_cart_block_editor/head'); ?>
            <?php //wp_head();
            ?>
            <?php do_action('fluent_cart/block_editor_head'); ?>
        </head>
        <body class="fct_custom_editor">
        <div class="wp-site-blocks">
            <div id="editor" class="gutenberg__editor"></div>
        </div>
        <?php
        do_action('fluent_cart/new_block_editor_footer');
        ?>
        </body>
        </html>
        <?php
    }

    private function unloadOtherScripts()
    {
        $isSkip = apply_filters('fluent_cart_editor/skip_no_conflict', false);
        if ($isSkip) {
            return;
        }

        /**
         * Define the list of approved slugs for FluentCRM assets.
         *
         * This filter allows modification of the list of slugs that are approved for FluentCRM assets.
         *
         * @param array $approvedSlugs An array of approved slugs for FluentCRM assets.
         */
        $approvedSlugs = apply_filters('fluent_cart_editor/asset_listed_slugs', [
                '\/gutenberg\/',
        ]);
        $approvedSlugs[] = 'fluent-cart';
        $approvedSlugs = array_unique($approvedSlugs);
        $approvedSlugs = implode('|', $approvedSlugs);

        $pluginUrl = str_replace(['http:', 'https:'], '', plugins_url());

        $themesUrl = str_replace(['http:', 'https:'], '', get_theme_root_uri());

        add_filter('script_loader_src', function ($src, $handle) use ($approvedSlugs, $pluginUrl, $themesUrl) {
            if (!$src) {
                return $src;
            }

            $willSkip = (strpos($src, $pluginUrl) !== false) && !preg_match('/' . $approvedSlugs . '/', $src);
            if ($willSkip) {
                return false;
            }

            $willSkip = (strpos($src, $themesUrl) !== false) && !preg_match('/' . $approvedSlugs . '/', $src);

            if ($willSkip) {
                return false;
            }

            return $src;
        }, 1, 2);

        add_action('wp_print_scripts', function () use ($approvedSlugs, $pluginUrl, $themesUrl) {
            global $wp_scripts;
            if (!$wp_scripts) {
                return;
            }

            foreach ($wp_scripts->queue as $script) {
                if (empty($wp_scripts->registered[$script]) || empty($wp_scripts->registered[$script]->src)) {
                    continue;
                }

                $src = $wp_scripts->registered[$script]->src;
                $isMatched = (strpos($src, $pluginUrl) !== false) && !preg_match('/' . $approvedSlugs . '/', $src);
                if (!$isMatched) {
                    continue;
                }

                $isMatched = (strpos($src, $themesUrl) !== false) && !preg_match('/' . $approvedSlugs . '/', $src);
                if (!$isMatched) {
                    continue;
                }

                wp_dequeue_script($wp_scripts->registered[$script]->handle);
            }
        }, 1);

        add_action('wp_print_styles', function () {
            $isSkip = apply_filters('fluent_cart/skip_no_conflict', false, 'styles');

            if ($isSkip) {
                return;
            }

            global $wp_styles;
            if (!$wp_styles) {
                return;
            }

            //    dd($wp_styles);

            $approvedSlugs = apply_filters('fluent_cart/asset_listed_slugs', [
                    '\/gutenberg\/',
            ]);

            $approvedSlugs[] = '\/fluent-cart\/';

            $approvedSlugs = array_unique($approvedSlugs);
            $approvedSlugs = implode('|', $approvedSlugs);

            $pluginUrl = plugins_url();
            $themeUrl = get_theme_root_uri();

            $pluginUrl = str_replace(['http:', 'https:'], '', $pluginUrl);
            $themeUrl = str_replace(['http:', 'https:'], '', $themeUrl);

            foreach ($wp_styles->queue as $script) {

                if (empty($wp_styles->registered[$script]) || empty($wp_styles->registered[$script]->src)) {
                    continue;
                }

                $src = $wp_styles->registered[$script]->src;
                $pluginMatched = (strpos($src, $pluginUrl) !== false) && !preg_match('/' . $approvedSlugs . '/', $src);
                $themeMatched = (strpos($src, $themeUrl) !== false) && !preg_match('/' . $approvedSlugs . '/', $src);

                if (!$pluginMatched && !$themeMatched) {
                    continue;
                }

                wp_dequeue_style($wp_styles->registered[$script]->handle);
            }
        }, 999999);
    }

    /**
     * Remove all default WordPress block patterns from the email editor.
     * These are meant for web pages and are not useful for composing emails.
     */
    protected function unregisterDefaultBlockPatterns($context = '', $data = [])
    {
        if (!isset($_REQUEST['fluent_cart_block_editor'])) {
            return;
        }

        $shouldUnregister = (bool)apply_filters('fluent_cart/block_editor_unregister_all_patterns', true, $context, $data);
        if (!$shouldUnregister) {
            return;
        }

        // Prevent late core/theme pattern registration hooks from repopulating defaults.
        foreach ([
                         '_register_core_block_patterns_and_categories',
                         '_register_theme_block_patterns',
                         '_register_remote_theme_patterns',
                 ] as $callback) {
            remove_action('init', $callback, 9);
            remove_action('init', $callback, 10);
        }

        add_filter('should_load_remote_block_patterns', '__return_false', 999);
        remove_theme_support('core-block-patterns');

        if (class_exists('\WP_Block_Patterns_Registry')) {
            $registry = \WP_Block_Patterns_Registry::get_instance();
            $patterns = method_exists($registry, 'get_all_registered') ? $registry->get_all_registered() : [];
            foreach (array_keys($patterns) as $patternName) {
                if (method_exists($registry, 'unregister')) {
                    $registry->is_registered($patternName) && $registry->unregister($patternName);
                }
            }
        }

        if (class_exists('\WP_Block_Pattern_Categories_Registry')) {
            $categoryRegistry = \WP_Block_Pattern_Categories_Registry::get_instance();
            $categories = method_exists($categoryRegistry, 'get_all_registered') ? $categoryRegistry->get_all_registered() : [];
            foreach (array_keys($categories) as $categoryName) {
                if (method_exists($categoryRegistry, 'unregister')) {
                    $categoryRegistry->is_registered($categoryName) && $categoryRegistry->unregister($categoryName);
                }
            }
        }
    }

    private function getEditorSettings($post)
    {
        // Run pattern cleanup here as well (late) so theme/plugin init hooks cannot re-add defaults.
        $context = Arr::get($this->editorBootData, 'entity.block_type', '');
        $this->unregisterDefaultBlockPatterns($context, is_array($_REQUEST) ? $_REQUEST : []);

        $max_upload_size = wp_max_upload_size();
        if (!$max_upload_size) {
            $max_upload_size = 0;
        }

        $lock_details = array(
                'isLocked' => false,
                'user'     => '',
        );

        $blockStyleDefaults = \FluentCart\App\Services\Email\BlockEditorHelper::getStyleDefaults();

        // Get theme colors for the "theme" palette slot
        $parser = new \FluentCartPro\App\Services\Email\FluentBlockParser();
        $color_palette = \FluentCart\App\Services\Email\BlockEditorHelper::getThemeColorPalette();
        $themePaletteColors = [];
        if (!empty($color_palette)) {
            foreach ($color_palette as $colorData) {
                if (!isset($colorData['slug'])) {
                    continue;
                }
                $themePaletteColors[] = [
                        'name'  => isset($colorData['name']) ? $colorData['name'] : ucfirst(str_replace('-', ' ', $colorData['slug'])),
                        'slug'  => $colorData['slug'],
                        'color' => $parser->getColorFromSlug($colorData['slug']),
                ];
            }
        }

        $editor_settings = array(
                'maxUploadFileSize'                => $max_upload_size,
                'allowedMimeTypes'                 => get_allowed_mime_types(),
                'postLock'                         => $lock_details,
                'postLockUtils'                    => array(
                        'nonce'       => wp_create_nonce('lock-post_' . $post->ID),
                        'unlockNonce' => wp_create_nonce('update-post_' . $post->ID),
                        'ajaxUrl'     => admin_url('admin-ajax.php'),
                ),
                '__experimentalFeatures'           => array(
                        'appearanceTools'               => true,
                        'useRootPaddingAwareAlignments' => false,
                        'border'                        => [
                                'color'  => 1,
                                'radius' => 1,
                                'style'  => 1,
                                'width'  => 1,
                        ],
                        'color'                         => [
                                'background'       => true,
                                'button'           => 1,
                                'caption'          => 1,
                                'customDuotone'    => 0,
                                'defaultDuotone'   => 0,
                                'defaultGradients' => 0,
                                'defaultPalette'   => true,
                                'duotone'          => [],
                                'gradients'        => [],
                                'heading'          => 1,
                                'link'             => 1,
                                'palette'          => [
                                        'default' => $blockStyleDefaults['color'],
                                        'theme'   => $themePaletteColors,
                                ],
                                'text'             => true,
                        ],
                        'dimensions'                    => [
                                'units'               => ['px'],
                                'defaultAspectRatios' => false,
                                'aspectRatio'         => false,
                                'minHeight'           => 1,
                        ],
                        'shadow'                        => [
                                'defaultPresets' => true,
                                'presets'        => [
                                        'default' => [
                                                [
                                                        'name'   => 'Natural',
                                                        'slug'   => 'natural',
                                                        'shadow' => '6px 6px 9px rgba(0, 0, 0, 0.2)',
                                                ],
                                                [
                                                        'name'   => 'Deep',
                                                        'slug'   => 'deep',
                                                        'shadow' => '12px 12px 50px rgba(0, 0, 0, 0.4)',
                                                ],
                                                [
                                                        'name'   => 'Sharp',
                                                        'slug'   => 'sharp',
                                                        'shadow' => '6px 6px 0px rgba(0, 0, 0, 0.2)',
                                                ],
                                                [
                                                        'name'   => 'Outlined',
                                                        'slug'   => 'outlined',
                                                        'shadow' => '6px 6px 0px -3px rgba(255, 255, 255, 1), 6px 6px rgba(0, 0, 0, 1)',
                                                ],
                                                [
                                                        'name'   => 'Crisp',
                                                        'slug'   => 'crisp',
                                                        'shadow' => '6px 6px 0px rgba(0, 0, 0, 1)',
                                                ],
                                        ],
                                ],
                        ],
                        'spacing'                       => [
                                'blockGap'            => 1,
                                'margin'              => 1,
                                'padding'             => 1,
                                'units'               => ['px'],
                                'defaultSpacingSizes' => true,
                                'spacingScale'        => [
                                        'default' => [
                                                'operator'   => '*',
                                                'increment'  => 1.5,
                                                'steps'      => 7,
                                                'mediumStep' => 24,
                                                'unit'       => 'px',
                                        ],
                                ],
                                'spacingSizes'        => [
                                        'default' => $blockStyleDefaults['spacing'],
                                ],
                        ],
                        'typography'                    => [
                                'defaultFontSizes' => true,
                                'dropCap'          => false,
                                'fontFamilies'     => [
                                        'default' => $blockStyleDefaults['font-family'],
                                ],
                                'fontSizes'        => [
                                        'default' => $blockStyleDefaults['font-size'],
                                ],
                                'fontStyle'        => true,
                                'fontWeight'       => true,
                                'letterSpacing'    => true,
                                'textAlign'        => true,
                                'textDecoration'   => true,
                                'textTransform'    => true,
                                'writingMode'      => false,
                                'units'            => ['px'],
                                'fluid'            => false,
                        ],
                        'blocks'                        => [
                                'core/button'    => [
                                        'border' => [
                                                'radius' => true,
                                        ]
                                ],
                                'core/buttons'   => [
                                        'border'      => [
                                                'radius' => false,
                                        ],
                                        'spacing'     => [
                                                'blockGap' => false,
                                        ],
                                        'layout'      => false,
                                        'contentRole' => false,
                                ],
                                'core/image'     => [
                                        'lightbox' => [
                                                'allowEditing' => true,
                                        ]
                                ],
                                'core/pullquote' => [
                                        'border' => [
                                                'color'  => true,
                                                'radius' => true,
                                                'style'  => true,
                                                'width'  => true,
                                        ]
                                ],
                                'core/paragraph' => [
                                        'spacing' => [
                                                'margin'  => 1,
                                                'padding' => 1,
                                        ]
                                ],
                                'core/columns'   => [
                                        'spacing' => [
                                                'blockGap'            => array(
                                                        '__experimentalDefault' => '20px',
                                                        'sides'                 => array('horizontal'),
                                                ),
                                                'defaultSpacingSizes' => false,
                                        ],
                                        'border'  => [
                                                'color'  => true,
                                                'radius' => false,
                                                'style'  => true,
                                                'width'  => true,
                                        ],
                                        'shadow'  => false,
                                ],
                                'core/group'     => [
                                        '__experimentalSettings' => false,
                                        'shadow'                 => false,
                                        'dimensions'             => [
                                                'minHeight' => false,
                                        ],
                                        'spacing'                => [
                                                'blockGap' => false,
                                                'margin'   => true,
                                                'padding'  => true,
                                        ],
                                        'position'               => [
                                                'sticky' => false,
                                        ],
                                        'layout'                 => [
                                                'allowSizingOnChildren' => false,
                                                'contentSize'           => false,
                                        ],
                                ],
                        ],
                        'layout'                        => [
                                'contentSize' => '700px',
                                'wideSize'    => '1200px',
                        ],
                        'background'                    => [
                                'backgroundImage' => 1,
                                'backgroundSize'  => 1,
                        ],
                        'position'                      => [
                                'sticky' => 0,
                        ]
                ),
                '__experimentalDiscussionSettings' => [
                        'avatarURL'            => 'https://secure.gravatar.com/avatar/?s=96&f=y&r=g',
                        'commentOrder'         => 'asc',
                        'commentsPerPage'      => '50',
                        'defaultCommentsPage'  => 'newest',
                        'defaultCommentStatus' => 'open',
                        'pageComments'         => '',
                        'threadComments'       => '1',
                        'threadCommentsDepth'  => '5',
                ],
                '__unstableGalleryWithImageBlocks' => false,
                '__unstableIsBlockBasedTheme'      => false,
                'enableCustomUnits'                => ['px', 'em'],
                'fontSizes'                        => $blockStyleDefaults['font-size'],
                'fullscreenMode'                   => 1,
                'enableCustomSpacing'              => 1,
                'enableCustomLineHeight'           => 1,
                'enableCustomFields'               => false,
                'disablePostFormats'               => true,
                'disableLayoutStyles'              => true,
                'disableCustomSpacingSizes'        => false,
                'disableCustomGradients'           => 1,
                'alignWide'                        => true,
                'disableCustomFontSizes'           => false,
                'disableCustomColors'              => false,
                'canUpdateBlockBindings'           => false,
                'bodyPlaceholder'                  => __('Start writing your email...', 'fluent-cart-pro'),
                'allowedBlockTypes'                => $this->getAllowedBlockTypes(),
                'gradients'                        => [],
                'imageDefaultSize'                 => 'large',
                'imageEditing'                     => true,
                'isRTL'                            => is_rtl(),
                'autosaveInterval'                 => 999,
                'localAutosaveInterval'            => 999,
                'richEditingEnabled'               => true,
                'spacingSizes'                     => $blockStyleDefaults['spacing'],
                'titlePlaceholder'                 => __('Email Subject', 'fluent-cart-pro'),
        );


        // $colorSchema = Utility::getColorSchemaConfig();
        // $lightSchemaConfig = Arr::get($colorSchema, 'light');
        // $colorSchmeaCss = ':root {';
        // foreach (Arr::get($lightSchemaConfig, 'body', []) as $colorKey => $value) {
        //     if($value) {
        //         $cssVar = ' --fcom-' . str_replace('_', '-', $colorKey);
        //         $colorSchmeaCss .= $cssVar . ':' . $value . '; ';
        //     }
        // }
        // $colorSchmeaCss .= '}';
        // Ensure variable exists even if schema generation is skipped
        $colorSchmeaCss = isset($colorSchmeaCss) ? $colorSchmeaCss : '';

        $editor_settings['styles'] = [
                [
                        '__unstableType' => 'presets',
                        'css'            => ':root{--wp--preset--aspect-ratio--square: 1;--wp--preset--aspect-ratio--4-3: 4/3;--wp--preset--aspect-ratio--3-4: 3/4;--wp--preset--aspect-ratio--3-2: 3/2;--wp--preset--aspect-ratio--2-3: 2/3;--wp--preset--aspect-ratio--16-9: 16/9;--wp--preset--aspect-ratio--9-16: 9/16;--wp--preset--color--theme-palette-color-1: var(--theme-palette-color-1);--wp--preset--color--theme-palette-color-2: var(--theme-palette-color-2);--wp--preset--color--theme-palette-color-3: var(--theme-palette-color-3);--wp--preset--color--theme-palette-color-4: var(--theme-palette-color-4);--wp--preset--color--theme-palette-color-5: var(--theme-palette-color-5);--wp--preset--color--theme-palette-color-6: var(--theme-palette-color-6);--wp--preset--color--theme-palette-color-7: var(--theme-palette-color-7);--wp--preset--color--theme-palette-color-8: var(--theme-palette-color-8);--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple: linear-gradient(135deg,rgba(6,147,227,1) 0%,rgb(155,81,224) 100%);--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan: linear-gradient(135deg,rgb(122,220,180) 0%,rgb(0,208,130) 100%);--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange: linear-gradient(135deg,rgba(252,185,0,1) 0%,rgba(255,105,0,1) 100%);--wp--preset--gradient--luminous-vivid-orange-to-vivid-red: linear-gradient(135deg,rgba(255,105,0,1) 0%,rgb(207,46,46) 100%);--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray: linear-gradient(135deg,rgb(238,238,238) 0%,rgb(169,184,195) 100%);--wp--preset--gradient--cool-to-warm-spectrum: linear-gradient(135deg,rgb(74,234,220) 0%,rgb(151,120,209) 20%,rgb(207,42,186) 40%,rgb(238,44,130) 60%,rgb(251,105,98) 80%,rgb(254,248,76) 100%);--wp--preset--gradient--blush-light-purple: linear-gradient(135deg,rgb(255,206,236) 0%,rgb(152,150,240) 100%);--wp--preset--gradient--blush-bordeaux: linear-gradient(135deg,rgb(254,205,165) 0%,rgb(254,45,45) 50%,rgb(107,0,62) 100%);--wp--preset--gradient--luminous-dusk: linear-gradient(135deg,rgb(255,203,112) 0%,rgb(199,81,192) 50%,rgb(65,88,208) 100%);--wp--preset--gradient--pale-ocean: linear-gradient(135deg,rgb(255,245,203) 0%,rgb(182,227,212) 50%,rgb(51,167,181) 100%);--wp--preset--gradient--electric-grass: linear-gradient(135deg,rgb(202,248,128) 0%,rgb(113,206,126) 100%);--wp--preset--gradient--midnight: linear-gradient(135deg,rgb(2,3,129) 0%,rgb(40,116,252) 100%);--wp--preset--gradient--juicy-peach: linear-gradient(to right, #ffecd2 0%, #fcb69f 100%);--wp--preset--gradient--young-passion: linear-gradient(to right, #ff8177 0%, #ff867a 0%, #ff8c7f 21%, #f99185 52%, #cf556c 78%, #b12a5b 100%);--wp--preset--gradient--true-sunset: linear-gradient(to right, #fa709a 0%, #fee140 100%);--wp--preset--gradient--morpheus-den: linear-gradient(to top, #30cfd0 0%, #330867 100%);--wp--preset--gradient--plum-plate: linear-gradient(135deg, #667eea 0%, #764ba2 100%);--wp--preset--gradient--aqua-splash: linear-gradient(15deg, #13547a 0%, #80d0c7 100%);--wp--preset--gradient--love-kiss: linear-gradient(to top, #ff0844 0%, #ffb199 100%);--wp--preset--gradient--new-retrowave: linear-gradient(to top, #3b41c5 0%, #a981bb 49%, #ffc8a9 100%);--wp--preset--gradient--plum-bath: linear-gradient(to top, #cc208e 0%, #6713d2 100%);--wp--preset--gradient--high-flight: linear-gradient(to right, #0acffe 0%, #495aff 100%);--wp--preset--gradient--teen-party: linear-gradient(-225deg, #FF057C 0%, #8D0B93 50%, #321575 100%);--wp--preset--gradient--fabled-sunset: linear-gradient(-225deg, #231557 0%, #44107A 29%, #FF1361 67%, #FFF800 100%);--wp--preset--gradient--arielle-smile: radial-gradient(circle 248px at center, #16d9e3 0%, #30c7ec 47%, #46aef7 100%);--wp--preset--gradient--itmeo-branding: linear-gradient(180deg, #2af598 0%, #009efd 100%);--wp--preset--gradient--deep-blue: linear-gradient(to right, #6a11cb 0%, #2575fc 100%);--wp--preset--gradient--strong-bliss: linear-gradient(to right, #f78ca0 0%, #f9748f 19%, #fd868c 60%, #fe9a8b 100%);--wp--preset--gradient--sweet-period: linear-gradient(to top, #3f51b1 0%, #5a55ae 13%, #7b5fac 25%, #8f6aae 38%, #a86aa4 50%, #cc6b8e 62%, #f18271 75%, #f3a469 87%, #f7c978 100%);--wp--preset--gradient--purple-division: linear-gradient(to top, #7028e4 0%, #e5b2ca 100%);--wp--preset--gradient--cold-evening: linear-gradient(to top, #0c3483 0%, #a2b6df 100%, #6b8cce 100%, #a2b6df 100%);--wp--preset--gradient--mountain-rock: linear-gradient(to right, #868f96 0%, #596164 100%);--wp--preset--gradient--desert-hump: linear-gradient(to top, #c79081 0%, #dfa579 100%);--wp--preset--gradient--ethernal-constance: linear-gradient(to top, #09203f 0%, #537895 100%);--wp--preset--gradient--happy-memories: linear-gradient(-60deg, #ff5858 0%, #f09819 100%);--wp--preset--gradient--grown-early: linear-gradient(to top, #0ba360 0%, #3cba92 100%);--wp--preset--gradient--morning-salad: linear-gradient(-225deg, #B7F8DB 0%, #50A7C2 100%);--wp--preset--gradient--night-call: linear-gradient(-225deg, #AC32E4 0%, #7918F2 48%, #4801FF 100%);--wp--preset--gradient--mind-crawl: linear-gradient(-225deg, #473B7B 0%, #3584A7 51%, #30D2BE 100%);--wp--preset--gradient--angel-care: linear-gradient(-225deg, #FFE29F 0%, #FFA99F 48%, #FF719A 100%);--wp--preset--gradient--juicy-cake: linear-gradient(to top, #e14fad 0%, #f9d423 100%);--wp--preset--gradient--rich-metal: linear-gradient(to right, #d7d2cc 0%, #304352 100%);--wp--preset--gradient--mole-hall: linear-gradient(-20deg, #616161 0%, #9bc5c3 100%);--wp--preset--gradient--cloudy-knoxville: linear-gradient(120deg, #fdfbfb 0%, #ebedee 100%);--wp--preset--gradient--soft-grass: linear-gradient(to top, #c1dfc4 0%, #deecdd 100%);--wp--preset--gradient--saint-petersburg: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);--wp--preset--gradient--everlasting-sky: linear-gradient(135deg, #fdfcfb 0%, #e2d1c3 100%);--wp--preset--gradient--kind-steel: linear-gradient(-20deg, #e9defa 0%, #fbfcdb 100%);--wp--preset--gradient--over-sun: linear-gradient(60deg, #abecd6 0%, #fbed96 100%);--wp--preset--gradient--premium-white: linear-gradient(to top, #d5d4d0 0%, #d5d4d0 1%, #eeeeec 31%, #efeeec 75%, #e9e9e7 100%);--wp--preset--gradient--clean-mirror: linear-gradient(45deg, #93a5cf 0%, #e4efe9 100%);--wp--preset--gradient--wild-apple: linear-gradient(to top, #d299c2 0%, #fef9d7 100%);--wp--preset--gradient--snow-again: linear-gradient(to top, #e6e9f0 0%, #eef1f5 100%);--wp--preset--gradient--confident-cloud: linear-gradient(to top, #dad4ec 0%, #dad4ec 1%, #f3e7e9 100%);--wp--preset--gradient--glass-water: linear-gradient(to top, #dfe9f3 0%, white 100%);--wp--preset--gradient--perfect-white: linear-gradient(-225deg, #E3FDF5 0%, #FFE6FA 100%);--wp--preset--font-size--small: var(--fcom-font-size-small);--wp--preset--font-size--medium: var(--fcom-font-size-medium);--wp--preset--font-size--large: var(--fcom-font-size-large);--wp--preset--font-size--x-large: 42px;--wp--preset--font-size--larger: var(--fcom-font-size-larger);--wp--preset--font-size--xxlarge: var(--fcom-font-size-xxlarge);--wp--preset--spacing--20: 0.44rem;--wp--preset--spacing--30: 0.67rem;--wp--preset--spacing--40: 1rem;--wp--preset--spacing--50: 1.5rem;--wp--preset--spacing--60: 2.25rem;--wp--preset--spacing--70: 3.38rem;--wp--preset--spacing--80: 5.06rem;--wp--preset--shadow--natural: 6px 6px 9px rgba(0, 0, 0, 0.2);--wp--preset--shadow--deep: 12px 12px 50px rgba(0, 0, 0, 0.4);--wp--preset--shadow--sharp: 6px 6px 0px rgba(0, 0, 0, 0.2);--wp--preset--shadow--outlined: 6px 6px 0px -3px rgba(255, 255, 255, 1), 6px 6px rgba(0, 0, 0, 1);--wp--preset--shadow--crisp: 6px 6px 0px rgba(0, 0, 0, 1);}',
                        'isGlobalStyles' => true
                ],
                [
                        '__unstableType' => 'presets',
                        'css'            => '.has-theme-palette-color-1-color{color: var(--wp--preset--color--theme-palette-color-1) !important;}.has-theme-palette-color-2-color{color: var(--wp--preset--color--theme-palette-color-2) !important;}.has-theme-palette-color-3-color{color: var(--wp--preset--color--theme-palette-color-3) !important;}.has-theme-palette-color-4-color{color: var(--wp--preset--color--theme-palette-color-4) !important;}.has-theme-palette-color-5-color{color: var(--wp--preset--color--theme-palette-color-5) !important;}.has-theme-palette-color-6-color{color: var(--wp--preset--color--theme-palette-color-6) !important;}.has-theme-palette-color-7-color{color: var(--wp--preset--color--theme-palette-color-7) !important;}.has-theme-palette-color-8-color{color: var(--wp--preset--color--theme-palette-color-8) !important;}.has-theme-palette-color-1-background-color{background-color: var(--wp--preset--color--theme-palette-color-1) !important;}.has-theme-palette-color-2-background-color{background-color: var(--wp--preset--color--theme-palette-color-2) !important;}.has-theme-palette-color-3-background-color{background-color: var(--wp--preset--color--theme-palette-color-3) !important;}.has-theme-palette-color-4-background-color{background-color: var(--wp--preset--color--theme-palette-color-4) !important;}.has-theme-palette-color-5-background-color{background-color: var(--wp--preset--color--theme-palette-color-5) !important;}.has-theme-palette-color-6-background-color{background-color: var(--wp--preset--color--theme-palette-color-6) !important;}.has-theme-palette-color-7-background-color{background-color: var(--wp--preset--color--theme-palette-color-7) !important;}.has-theme-palette-color-8-background-color{background-color: var(--wp--preset--color--theme-palette-color-8) !important;}.has-theme-palette-color-1-border-color{border-color: var(--wp--preset--color--theme-palette-color-1) !important;}.has-theme-palette-color-2-border-color{border-color: var(--wp--preset--color--theme-palette-color-2) !important;}.has-theme-palette-color-3-border-color{border-color: var(--wp--preset--color--theme-palette-color-3) !important;}.has-theme-palette-color-4-border-color{border-color: var(--wp--preset--color--theme-palette-color-4) !important;}.has-theme-palette-color-5-border-color{border-color: var(--wp--preset--color--theme-palette-color-5) !important;}.has-theme-palette-color-6-border-color{border-color: var(--wp--preset--color--theme-palette-color-6) !important;}.has-theme-palette-color-7-border-color{border-color: var(--wp--preset--color--theme-palette-color-7) !important;}.has-theme-palette-color-8-border-color{border-color: var(--wp--preset--color--theme-palette-color-8) !important;}.has-vivid-cyan-blue-to-vivid-purple-gradient-background{background: var(--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple) !important;}.has-light-green-cyan-to-vivid-green-cyan-gradient-background{background: var(--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan) !important;}.has-luminous-vivid-amber-to-luminous-vivid-orange-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange) !important;}.has-luminous-vivid-orange-to-vivid-red-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-orange-to-vivid-red) !important;}.has-very-light-gray-to-cyan-bluish-gray-gradient-background{background: var(--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray) !important;}.has-cool-to-warm-spectrum-gradient-background{background: var(--wp--preset--gradient--cool-to-warm-spectrum) !important;}.has-blush-light-purple-gradient-background{background: var(--wp--preset--gradient--blush-light-purple) !important;}.has-blush-bordeaux-gradient-background{background: var(--wp--preset--gradient--blush-bordeaux) !important;}.has-luminous-dusk-gradient-background{background: var(--wp--preset--gradient--luminous-dusk) !important;}.has-pale-ocean-gradient-background{background: var(--wp--preset--gradient--pale-ocean) !important;}.has-electric-grass-gradient-background{background: var(--wp--preset--gradient--electric-grass) !important;}.has-midnight-gradient-background{background: var(--wp--preset--gradient--midnight) !important;}.has-juicy-peach-gradient-background{background: var(--wp--preset--gradient--juicy-peach) !important;}.has-young-passion-gradient-background{background: var(--wp--preset--gradient--young-passion) !important;}.has-true-sunset-gradient-background{background: var(--wp--preset--gradient--true-sunset) !important;}.has-morpheus-den-gradient-background{background: var(--wp--preset--gradient--morpheus-den) !important;}.has-plum-plate-gradient-background{background: var(--wp--preset--gradient--plum-plate) !important;}.has-aqua-splash-gradient-background{background: var(--wp--preset--gradient--aqua-splash) !important;}.has-love-kiss-gradient-background{background: var(--wp--preset--gradient--love-kiss) !important;}.has-new-retrowave-gradient-background{background: var(--wp--preset--gradient--new-retrowave) !important;}.has-plum-bath-gradient-background{background: var(--wp--preset--gradient--plum-bath) !important;}.has-high-flight-gradient-background{background: var(--wp--preset--gradient--high-flight) !important;}.has-teen-party-gradient-background{background: var(--wp--preset--gradient--teen-party) !important;}.has-fabled-sunset-gradient-background{background: var(--wp--preset--gradient--fabled-sunset) !important;}.has-arielle-smile-gradient-background{background: var(--wp--preset--gradient--arielle-smile) !important;}.has-itmeo-branding-gradient-background{background: var(--wp--preset--gradient--itmeo-branding) !important;}.has-deep-blue-gradient-background{background: var(--wp--preset--gradient--deep-blue) !important;}.has-strong-bliss-gradient-background{background: var(--wp--preset--gradient--strong-bliss) !important;}.has-sweet-period-gradient-background{background: var(--wp--preset--gradient--sweet-period) !important;}.has-purple-division-gradient-background{background: var(--wp--preset--gradient--purple-division) !important;}.has-cold-evening-gradient-background{background: var(--wp--preset--gradient--cold-evening) !important;}.has-mountain-rock-gradient-background{background: var(--wp--preset--gradient--mountain-rock) !important;}.has-desert-hump-gradient-background{background: var(--wp--preset--gradient--desert-hump) !important;}.has-ethernal-constance-gradient-background{background: var(--wp--preset--gradient--ethernal-constance) !important;}.has-happy-memories-gradient-background{background: var(--wp--preset--gradient--happy-memories) !important;}.has-grown-early-gradient-background{background: var(--wp--preset--gradient--grown-early) !important;}.has-morning-salad-gradient-background{background: var(--wp--preset--gradient--morning-salad) !important;}.has-night-call-gradient-background{background: var(--wp--preset--gradient--night-call) !important;}.has-mind-crawl-gradient-background{background: var(--wp--preset--gradient--mind-crawl) !important;}.has-angel-care-gradient-background{background: var(--wp--preset--gradient--angel-care) !important;}.has-juicy-cake-gradient-background{background: var(--wp--preset--gradient--juicy-cake) !important;}.has-rich-metal-gradient-background{background: var(--wp--preset--gradient--rich-metal) !important;}.has-mole-hall-gradient-background{background: var(--wp--preset--gradient--mole-hall) !important;}.has-cloudy-knoxville-gradient-background{background: var(--wp--preset--gradient--cloudy-knoxville) !important;}.has-soft-grass-gradient-background{background: var(--wp--preset--gradient--soft-grass) !important;}.has-saint-petersburg-gradient-background{background: var(--wp--preset--gradient--saint-petersburg) !important;}.has-everlasting-sky-gradient-background{background: var(--wp--preset--gradient--everlasting-sky) !important;}.has-kind-steel-gradient-background{background: var(--wp--preset--gradient--kind-steel) !important;}.has-over-sun-gradient-background{background: var(--wp--preset--gradient--over-sun) !important;}.has-premium-white-gradient-background{background: var(--wp--preset--gradient--premium-white) !important;}.has-clean-mirror-gradient-background{background: var(--wp--preset--gradient--clean-mirror) !important;}.has-wild-apple-gradient-background{background: var(--wp--preset--gradient--wild-apple) !important;}.has-snow-again-gradient-background{background: var(--wp--preset--gradient--snow-again) !important;}.has-confident-cloud-gradient-background{background: var(--wp--preset--gradient--confident-cloud) !important;}.has-glass-water-gradient-background{background: var(--wp--preset--gradient--glass-water) !important;}.has-perfect-white-gradient-background{background: var(--wp--preset--gradient--perfect-white) !important;}.has-small-font-size{font-size: var(--wp--preset--font-size--small) !important;}.has-medium-font-size{font-size: var(--wp--preset--font-size--medium) !important;}.has-large-font-size{font-size: var(--wp--preset--font-size--large) !important;}.has-x-large-font-size{font-size: var(--wp--preset--font-size--x-large) !important;}.has-larger-font-size{font-size: var(--wp--preset--font-size--larger) !important;}.has-xxlarge-font-size{font-size: var(--wp--preset--font-size--xxlarge) !important;}',
                        'isGlobalStyles' => true
                ],
                [
                        '__unstableType' => 'theme',
                        'css'            => ':root { --wp--style--global--content-size: var(--theme-block-max-width);--wp--style--global--wide-size: var(--theme-block-wide-max-width); }:where(body) { margin: 0; }.wp-site-blocks > .alignleft { float: left; margin-right: 2em; }.wp-site-blocks > .alignright { float: right; margin-left: 2em; }.wp-site-blocks > .aligncenter { justify-content: center; margin-left: auto; margin-right: auto; }:where(.wp-site-blocks) > * { margin-block-start: var(--theme-content-spacing); margin-block-end: 0; }:where(.wp-site-blocks) > :first-child { margin-block-start: 0; }:where(.wp-site-blocks) > :last-child { margin-block-end: 0; }:root { --wp--style--block-gap: var(--theme-content-spacing); }:root :where(.is-layout-flow) > :first-child{margin-block-start: 0;}:root :where(.is-layout-flow) > :last-child{margin-block-end: 0;}:root :where(.is-layout-flow) > *{margin-block-start: var(--theme-content-spacing);margin-block-end: 0;}:root :where(.is-layout-constrained) > :first-child{margin-block-start: 0;}:root :where(.is-layout-constrained) > :last-child{margin-block-end: 0;}:root :where(.is-layout-constrained) > *{margin-block-start: var(--theme-content-spacing);margin-block-end: 0;}:root :where(.is-layout-flex){gap: var(--theme-content-spacing);}:root :where(.is-layout-grid){gap: var(--theme-content-spacing);}.is-layout-flow > .alignleft{float: left;margin-inline-start: 0;margin-inline-end: 2em;}.is-layout-flow > .alignright{float: right;margin-inline-start: 2em;margin-inline-end: 0;}.is-layout-flow > .aligncenter{margin-left: auto !important;margin-right: auto !important;}.is-layout-constrained > .alignleft{float: left;margin-inline-start: 0;margin-inline-end: 2em;}.is-layout-constrained > .alignright{float: right;margin-inline-start: 2em;margin-inline-end: 0;}.is-layout-constrained > .aligncenter{margin-left: auto !important;margin-right: auto !important;}.is-layout-constrained > :where(:not(.alignleft):not(.alignright):not(.alignfull)){max-width: var(--wp--style--global--content-size);margin-left: auto !important;margin-right: auto !important;}.is-layout-constrained > .alignwide{max-width: var(--wp--style--global--wide-size);}body .is-layout-flex{display: flex;}.is-layout-flex{flex-wrap: wrap;align-items: center;}.is-layout-flex > :is(*, div){margin: 0;}body .is-layout-grid{display: grid;}.is-layout-grid > :is(*, div){margin: 0;}body{padding-top: 0px;padding-right: 0px;padding-bottom: 0px;padding-left: 0px;}',
                        'isGlobalStyles' => true
                ],
                [
                        '__unstableType' => 'user',
                        'css'            => $colorSchmeaCss . " :root{--theme-block-max-width: 700px;--global-calc-content-width: 700px;--theme-block-wide-max-width: 820px;--theme-font-family: -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, Helvetica, Arial, sans-serif, \"Apple Color Emoji\", \"Segoe UI Emoji\", \"Segoe UI Symbol\";--theme-font-weight: 400;--theme-text-transform: none;--theme-text-decoration: none;--theme-font-size: 16px;--theme-line-height: 1.60;--theme-letter-spacing: 0em;--theme-button-font-weight: 500;--theme-button-font-size: 16px;--theme-palette-color-1: #4F46E5;--theme-palette-color-2: #7C3AED;--theme-palette-color-3: #1F2937;--theme-palette-color-4: #374151;--theme-palette-color-5: #6B7280;--theme-palette-color-6: #9CA3AF;--theme-palette-color-7: #E5E7EB;--theme-palette-color-8: #ffffff;--theme-text-color: var(--fcom-primary-text, #19283a);--theme-link-initial-color: var(--theme-palette-color-1);--theme-link-hover-color: var(--theme-palette-color-2);--theme-selection-text-color: #ffffff;--theme-selection-background-color: var(--theme-palette-color-1);--theme-border-color: var(--theme-palette-color-5);--theme-headings-color: var(--theme-palette-color-4);--theme-content-spacing: 1.5em;--theme-button-min-height: 40px;--theme-button-shadow: none;--theme-button-transform: none;--theme-button-text-initial-color: #ffffff;--theme-button-text-hover-color: #ffffff;--theme-button-background-initial-color: var(--theme-palette-color-1);--theme-button-background-hover-color: var(--theme-palette-color-2);--theme-button-border: none;--theme-button-padding: 5px 20px;--theme-normal-container-max-width: 1290px;--theme-content-vertical-spacing: 60px;--theme-container-edge-spacing: 90vw;--theme-narrow-container-max-width: 750px;--theme-wide-offset: 130px;--fcom-font-size-small: 16px;--fcom-font-size-medium: 18px;--fcom-font-size-large: 22px;--fcom-font-size-larger: 26px;--fcom-font-size-xxlarge: 32px;--wp--preset--spacing--20: 0.44rem;--wp--preset--spacing--30: 0.67rem;--wp--preset--spacing--40: 1rem;--wp--preset--spacing--50: 1.5rem;--wp--preset--spacing--60: 2.25rem;--wp--preset--spacing--70: 3.38rem;--wp--preset--spacing--80: 5.06rem}body .has-theme-palette-color-1-color{color:var(--theme-palette-color-1)}body .has-theme-palette-color-2-color{color:var(--theme-palette-color-2)}body .has-theme-palette-color-3-color{color:var(--theme-palette-color-3)}body .has-theme-palette-color-4-color{color:var(--theme-palette-color-4)}body .has-theme-palette-color-5-color{color:var(--theme-palette-color-5)}body .has-theme-palette-color-6-color{color:var(--theme-palette-color-6)}body .has-theme-palette-color-7-color{color:var(--theme-palette-color-7)}body .has-theme-palette-color-8-color{color:var(--theme-palette-color-8)}body .has-theme-palette-color-1-background-color{background-color:var(--theme-palette-color-1)}body .has-theme-palette-color-2-background-color{background-color:var(--theme-palette-color-2)}body .has-theme-palette-color-3-background-color{background-color:var(--theme-palette-color-3)}body .has-theme-palette-color-4-background-color{background-color:var(--theme-palette-color-4)}body .has-theme-palette-color-5-background-color{background-color:var(--theme-palette-color-5)}body .has-theme-palette-color-6-background-color{background-color:var(--theme-palette-color-6)}body .has-theme-palette-color-7-background-color{background-color:var(--theme-palette-color-7)}body .has-theme-palette-color-8-background-color{background-color:var(--theme-palette-color-8)}body .has-small-font-size{font-size:var(--fcom-font-size-small)}body .has-medium-font-size{font-size:var(--fcom-font-size-medium)}body .has-large-font-size{font-size:var(--fcom-font-size-large)}body .has-larger-font-size{font-size:var(--fcom-font-size-larger)}body .has-xxlarge-font-size{font-size:var(--fcom-font-size-xxlarge)}body .is-root-container>.alignfull{margin-inline:var(--has-wide, -20px)}body .is-root-container>.wp-block.alignleft{margin-inline-start:calc((100% - min(var(--theme-block-max-width),100%))/2)}body .is-root-container>.wp-block.alignright{margin-inline-end:calc((100% - min(var(--theme-block-max-width),100%))/2)}body :root .wp-element-button{font-family:var(--theme-button-font-family, var(--theme-font-family));font-size:var(--theme-button-font-size);font-weight:var(--theme-button-font-weight);font-style:var(--theme-button-font-style);line-height:var(--theme-button-line-height);letter-spacing:var(--theme-button-letter-spacing);text-transform:var(--theme-button-text-transform);-webkit-text-decoration:var(--theme-button-text-decoration);text-decoration:var(--theme-button-text-decoration)}body :root .wp-block-button[style*=font-weight] .wp-element-button{font-weight:inherit}body .wp-block-columns:last-child{margin-bottom:0}body .has-drop-cap:not(:focus):first-letter{font-size:5.8em;font-weight:700;margin:.1em .12em .05em 0}body figcaption{text-align:center;margin-block:.5em 0}body .wp-block-code,body .wp-block-verse,body .wp-block-preformatted{box-sizing:border-box;tab-size:4;padding:15px 20px;border-radius:3px;background:var(--theme-palette-color-7)}body blockquote{margin-inline:0}body blockquote:where(:not(.is-style-plain)):where(:not(.has-text-align-center):not(.has-text-align-right)){border-inline-start:4px solid var(--theme-palette-color-1)}body blockquote:where(:not(.is-style-plain)).has-text-align-center{padding-block:1.5em;border-block:3px solid var(--theme-palette-color-1)}body blockquote:where(:not(.is-style-plain)).has-text-align-right{border-inline-end:4px solid var(--theme-palette-color-1)}body blockquote:where(:not(.is-style-plain):not(.has-text-align-center):not(.has-text-align-right)){padding-inline-start:1.5em}body blockquote.has-text-align-right{padding-inline-end:1.5em}body blockquote p:last-child{margin-bottom:0}body blockquote cite{font-size:14px}body .wp-block-list{padding-left:30px}body .wp-block-pullquote{position:relative;padding:70px;text-align:initial;border-width:10px;border-style:solid;border-color:var(--theme-palette-color-1)}body .wp-block-pullquote blockquote{border:0;padding:0;margin:0;position:relative;isolation:isolate}body .wp-block-pullquote blockquote p{margin-top:0;margin-bottom:1em}body .wp-block-pullquote blockquote p:last-child{margin-bottom:0}body .wp-block-pullquote blockquote cite{font-size:16px;font-weight:500}body [data-align=left] .wp-block-pullquote,body [data-align=right] .wp-block-pullquote{max-width:50%;margin-top:.3em;margin-bottom:.3em}body .wp-block-table table{border-width:1px}body .wp-block-table table:not(.has-border-color) thead,body .wp-block-table table:not(.has-border-color) tfoot,body .wp-block-table table:not(.has-border-color) td,body .wp-block-table table:not(.has-border-color) th{border-color:var(--theme-table-border-color, var(--theme-border-color))}body .wp-block-table th:not([class*=has-text-align]){text-align:inherit}body .wp-block-table.is-style-stripes{border:0}body .wp-block-button.is-style-outline .wp-element-button{padding:var(--theme-button-padding);border:2px solid;border-color:var(--theme-button-background-initial-color)}body .wp-block-button.is-style-outline .wp-element-button:not(.has-text-color){color:var(--theme-button-background-initial-color)}body .wp-block-button.is-style-outline .wp-element-button:hover{color:var(--theme-button-text-hover-color);border-color:var(--theme-button-background-hover-color);background-color:var(--theme-button-background-hover-color)}body .wp-block-separator{border:none;margin-inline:auto;color:var(--theme-form-field-border-initial-color)}body .wp-block-separator:not(:where(.is-style-wide,.is-style-dots,.alignfull,.alignwide)){max-width:100px !important}body .wp-block-separator:not(.is-style-dots){height:2px;background-color:currentColor}body :root :where(p.has-background,.wp-block-group.has-background){padding:30px;box-sizing:border-box}body h1.has-background,body h2.has-background,body h3.has-background,body h4.has-background,body h5.has-background,body h6.has-background{padding:1.25em 2.375em}body{background-color:var(--fcom-primary-bg, white);background-image:none;font-family:var(--theme-font-family);line-height:var(--theme-line-height)}body .is-root-container{font-size:var(--theme-font-size, 16px);font-family:var(--theme-font-family, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, Helvetica, Arial, sans-serif, \"Apple Color Emoji\", \"Segoe UI Emoji\", \"Segoe UI Symbol\")}.block-editor-iframe__html.is-zoomed-out .block-editor-iframe__body{padding:20px 30px}.editor-visual-editor__post-title-wrapper.edit-post-visual-editor__post-title-wrapper{margin-top:0px !important;padding-top:0;margin-bottom:30px;position:relative}.editor-visual-editor__post-title-wrapper.edit-post-visual-editor__post-title-wrapper h1{font-size:32px;font-weight:700}h1{--theme-font-weight: 700;--theme-font-size: 40px;--theme-line-height: 1.5}h2{--theme-font-weight: 700;--theme-font-size: 35px;--theme-line-height: 1.5}h3{--theme-font-weight: 700;--theme-font-size: 30px;--theme-line-height: 1.5}h4{--theme-font-weight: 700;--theme-font-size: 25px;--theme-line-height: 1.5}h5{--theme-font-weight: 700;--theme-font-size: 20px;--theme-line-height: 1.5}h6{--theme-font-weight: 700;--theme-font-size: 16px;--theme-line-height: 1.5}.wp-block-pullquote{--theme-font-family: Georgia;--theme-font-weight: 600;--theme-font-size: 25px}pre,code,samp,kbd{--theme-font-family: monospace;--theme-font-weight: 400;--theme-font-size: 16px}figcaption{--theme-font-size: 14px}li::marker{color:#959595}.editor-styles-wrapper{--true: initial;--false: ;--wp--style--global--content-size: var(--theme-block-max-width);--wp--style--global--wide-size: var(--theme-block-wide-max-width);box-sizing:border-box;border:var(--has-boxed, var(--theme-boxed-content-border));padding:var(--has-boxed, var(--theme-boxed-content-spacing));box-shadow:var(--has-boxed, var(--theme-boxed-content-box-shadow));border-radius:var(--has-boxed, var(--theme-boxed-content-border-radius));margin-inline:auto;margin-block:var(--has-boxed, 20px);width:calc(100% - 40px);max-width:100%}:is(.is-layout-flow,.is-layout-constrained)>*:where(:not(h1,h2,h3,h4,h5,h6)){margin-block-start:0;margin-block-end:var(--theme-content-spacing)}:is(.is-layout-flow,.is-layout-constrained) :where(h1,h2,h3,h4,h5,h6){margin-block-end:calc(var(--has-theme-content-spacing, 1)*(.3em + 10px))}:root{color:var(--theme-text-color)}:root a{color:var(--theme-link-initial-color)}.block-editor-block-list__layout.is-root-container>.alignwide{max-width:var(--theme-block-wide-max-width);box-sizing:border-box}.is-root-container{padding:0 20px}\n"
                ],
//            [
//                'css'            => file_get_contents(FLUENTCART_PLUGIN_PATH . 'Modules/Gutenberg/editor/editor.css'),
//                '__unstableType' => 'user'
//            ]
        ];


        $resovedStyles = [
                'wp-components-css'           => includes_url('/css/dist/components/style.min.css'),
                'wp-preferences-css'          => includes_url('/css/dist/preferences/style.min.css'),
                'wp-block-editor-css'         => includes_url('/css/dist/block-editor/style.min.css'),
                'wp-reusable-blocks-css'      => includes_url('/css/dist/reusable-blocks/style.min.css'),
                'wp-patterns-css'             => includes_url('/css/dist/patterns/style.min.css'),
                'wp-editor-css'               => includes_url('/css/dist/editor/style.min.css'),
                'wp-block-library-css'        => includes_url('/css/dist/block-library/style.min.css'),
                'wp-block-editor-content-css' => includes_url('/css/dist/block-editor/content.min.css'),
                'wp-edit-blocks-css'          => includes_url('/css/dist/block-library/editor.min.css'),
        ];

        global $wp_version;
        $cssFiles = '';
        foreach ($resovedStyles as $name => $file) {
            $cssFiles .= "<link rel='stylesheet' id='{$name}' href='{$file}?ver={$wp_version}' media='all' />\n";
        }

        if ($this->isOrderBumpEditor()) {
            // The card looks in the editor as it does on the shop.
            $editor_settings['styles'][] = [
                    'css' => (new \FluentCartPro\App\Modules\Promotional\OrderBump\OrderBumpBoot())->editorCss()
            ];
        }

        $editor_settings['__unstableResolvedAssets'] = [
                'scripts' => '<script src="' . includes_url('/js/dist/vendor/wp-polyfill.min.js?ver=3.15.0') . '" id="wp-polyfill-js"></script>',
                'styles'  => $cssFiles
        ];

        $editor_settings['defaultEditorStyles'] = [
                [
                        'css' => ':root{--wp-admin-theme-color:#007cba;--wp-admin-theme-color--rgb:0, 124, 186;--wp-admin-theme-color-darker-10:#006ba1;--wp-admin-theme-color-darker-10--rgb:0, 107, 161;--wp-admin-theme-color-darker-20:#005a87;--wp-admin-theme-color-darker-20--rgb:0, 90, 135;--wp-admin-border-width-focus:2px;--wp-block-synced-color:#7a00df;--wp-block-synced-color--rgb:122, 0, 223;--wp-bound-block-color:var(--wp-block-synced-color);}@media (min-resolution:192dpi){:root{--wp-admin-border-width-focus:1.5px;}}body{font-family:-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Oxygen-Sans,Ubuntu,Cantarell,Helvetica Neue,sans-serif;font-size:18px;line-height:1.5;--wp--style--block-gap:2em;}p{line-height:1.8;}.editor-post-title__block{font-size:2.5em;font-weight:800;margin-bottom:1em;margin-top:2em;}'
                ]
        ];
        $editor_settings['imageSizes'] = $this->gutenberg_get_available_image_sizes();

        $editor_settings['blockCategories'] = get_block_categories(get_post());

        $editor_settings = apply_filters('fluent_cart/block_editor_settings', $editor_settings);
        return $editor_settings;
    }

    /**
     * FluentCart blocks available in the email editor.
     * To add a new block: just add its class here.
     * Assets, whitelist, and server-side bootstrap are automatic.
     *
     * @return string[]
     */
    public static function getEmailEditorBlocks(): array
    {
        return array_merge([
            // Buttons
                \FluentCart\App\Hooks\Handlers\BlockEditors\Buttons\BuyNowButtonBlockEditor::class,
                \FluentCart\App\Hooks\Handlers\BlockEditors\Buttons\AddToCartButtonBlockEditor::class,
                \FluentCart\App\Hooks\Handlers\BlockEditors\CustomerDashboardButtonBlockEditor::class,

            // Product display
                \FluentCart\App\Hooks\Handlers\BlockEditors\ProductTitleBlockEditor::class,
                \FluentCart\App\Hooks\Handlers\BlockEditors\ProductImageBlockEditor::class,
                \FluentCart\App\Hooks\Handlers\BlockEditors\PriceRangeBlockEditor::class,
                \FluentCart\App\Hooks\Handlers\BlockEditors\ExcerptBlockEditor::class,
                \FluentCart\App\Hooks\Handlers\BlockEditors\SaleBadgeBlockEditor::class,

            // Branding
                \FluentCart\App\Hooks\Handlers\BlockEditors\StoreLogoBlockEditor::class,
        ], static::getEmailOnlyBlocks());
    }

    /**
     * Blocks that exist ONLY in the email editor (not registered globally).
     * These are registered via registerBlockType() in the handler's init hook
     * instead of actions.php, so they don't appear in regular page/post editors.
     *
     * @return string[]
     */
    public static function getEmailOnlyBlocks(): array
    {
        return [
                // PDF receipt blocks (Pro feature)
                \FluentCartPro\App\Hooks\Handlers\BlockEditors\PdfBlocks\ReceiptHeaderBlockEditor::class,
                \FluentCartPro\App\Hooks\Handlers\BlockEditors\PdfBlocks\ReceiptAddressesBlockEditor::class,
                \FluentCartPro\App\Hooks\Handlers\BlockEditors\PdfBlocks\ReceiptMetaBlockEditor::class,
                \FluentCartPro\App\Hooks\Handlers\BlockEditors\PdfBlocks\ReceiptItemTableBlockEditor::class,
                \FluentCartPro\App\Hooks\Handlers\BlockEditors\PdfBlocks\ReceiptPaymentSummaryBlockEditor::class,
                \FluentCartPro\App\Hooks\Handlers\BlockEditors\PdfBlocks\ReceiptFooterBlockEditor::class,

                // Email-only blocks
                \FluentCartPro\App\Hooks\Handlers\BlockEditors\EmailBlocks\CelebrationBlockEditor::class,
                \FluentCartPro\App\Hooks\Handlers\BlockEditors\EmailBlocks\OrderAddresses\OrderAddressesBlockEditor::class,
                \FluentCartPro\App\Hooks\Handlers\BlockEditors\EmailBlocks\AddressContainer\AddressContainerBlockEditor::class,
                \FluentCartPro\App\Hooks\Handlers\BlockEditors\EmailBlocks\BillingAddress\BillingAddressBlockEditor::class,
                \FluentCartPro\App\Hooks\Handlers\BlockEditors\EmailBlocks\ShippingAddress\ShippingAddressBlockEditor::class,
                \FluentCartPro\App\Hooks\Handlers\BlockEditors\EmailBlocks\OrderSummary\OrderSummaryBlockEditor::class,
                \FluentCartPro\App\Hooks\Handlers\BlockEditors\EmailBlocks\OrderTotals\OrderTotalsBlockEditor::class,
                \FluentCartPro\App\Hooks\Handlers\BlockEditors\EmailBlocks\EmailHeader\EmailHeaderBlockEditor::class,
                \FluentCartPro\App\Hooks\Handlers\BlockEditors\EmailBlocks\OrderItems\OrderItemsBlockEditor::class,
                \FluentCartPro\App\Hooks\Handlers\BlockEditors\EmailBlocks\LicenseDetails\LicenseDetailsBlockEditor::class,
                \FluentCartPro\App\Hooks\Handlers\BlockEditors\EmailBlocks\DownloadDetails\DownloadDetailsBlockEditor::class,
                \FluentCartPro\App\Hooks\Handlers\BlockEditors\EmailBlocks\SubscriptionDetails\SubscriptionDetailsBlockEditor::class,
                \FluentCartPro\App\Hooks\Handlers\BlockEditors\EmailBlocks\RowHeader\RowHeaderBlockEditor::class,
                \FluentCartPro\App\Hooks\Handlers\BlockEditors\EmailBlocks\RowBody\RowBodyBlockEditor::class,
                \FluentCartPro\App\Hooks\Handlers\BlockEditors\EmailBlocks\RowFooter\RowFooterBlockEditor::class,
                \FluentCartPro\App\Hooks\Handlers\BlockEditors\EmailBlocks\ShortcodeCondition\ShortcodeConditionBlockEditor::class,
                \FluentCartPro\App\Hooks\Handlers\BlockEditors\EmailBlocks\ConditionContent\ConditionContentBlockEditor::class,
                \FluentCartPro\App\Hooks\Handlers\BlockEditors\EmailBlocks\ConditionFallback\ConditionFallbackBlockEditor::class,
        ];
    }

    private function isOrderBumpEditor(): bool
    {
        return isset($this->editorBootData['entity']['block_type'])
                && $this->editorBootData['entity']['block_type'] === 'order_bump_template';
    }

    /**
     * Blocks for the order bump card editor only. They are not part of the email or PDF editors.
     *
     * @return string[]
     */
    public static function getOrderBumpBlocks(): array
    {
        return [
                \FluentCartPro\App\Hooks\Handlers\BlockEditors\OrderBumpBlocks\OrderBumpCheckboxBlockEditor::class,
                \FluentCartPro\App\Hooks\Handlers\BlockEditors\OrderBumpBlocks\OrderBumpAddButtonBlockEditor::class,
                \FluentCartPro\App\Hooks\Handlers\BlockEditors\OrderBumpBlocks\OrderBumpAddedBlockEditor::class,
                \FluentCartPro\App\Hooks\Handlers\BlockEditors\OrderBumpBlocks\OrderBumpRemoveButtonBlockEditor::class,
                \FluentCartPro\App\Hooks\Handlers\BlockEditors\OrderBumpBlocks\OrderBumpElementBlockEditor::class,
        ];
    }

    /**
     * Enqueue assets for all FluentCart email editor blocks.
     *
     * @return void
     */
    private function enqueueEmailEditorBlocks(): void
    {
        // ReactSupport stays in free plugin (generic React bridge for dev mode)
        if (\FluentCart\App\Vite::underDevelopment()) {
            \FluentCart\App\Vite::enqueueScript(
                    'react-support',
                    'admin/BlockEditor/ReactSupport.js',
                    ['wp-blocks', 'wp-components']
            );
        }

        // Each block's CanEnqueue trait handles the right Vite pipeline:
        // - Free blocks (storefront) use free's CanEnqueue → free Vite
        // - Pro blocks (email-only) use pro's CanEnqueue → ProVite
        foreach ($this->getEmailEditorBlocks() as $blockClass) {
            $blockClass::make()->enqueueAssets();
        }

        if ($this->isOrderBumpEditor()) {
            foreach (static::getOrderBumpBlocks() as $blockClass) {
                $blockClass::make()->enqueueAssets();
            }
        }

        // Global block editor styles stay in free's Vite (shared across all block editors)
        \FluentCart\App\Vite::enqueueStyle(
                'fluent-cart-global-block-editor',
                'admin/BlockEditor/Components/style/fct-global-block-editor.scss'
        );

        /**
         * Fires after FluentCart email editor block assets are enqueued.
         * Use this to enqueue additional scripts or styles for the email editor.
         */
        do_action('fluent_cart/block_editor/enqueue_assets');
    }

    /**
     * Get the allowed block types for the email editor.
     *
     * @return array
     */
    private function getAllowedBlockTypes()
    {
        $allowedBlockTypes = [
                'core/block',
                'core/buttons',
                'core/button',
                'core/code',
                'core/columns',
                'core/column',
                'core/footnotes',
                'core/freeform',
                'core/group',
                'core/heading',
                'core/html',
                'core/image',
                'core/list',
                'core/list-item',
                'core/missing',
                'core/paragraph',
                'core/preformatted',
                'core/pullquote',
                'core/quote',
                'core/separator',
                'core/spacer',
                'core/table',
                'core/verse',
        ];

        foreach ($this->getEmailEditorBlocks() as $blockClass) {
            $allowedBlockTypes[] = 'fluent-cart/' . $blockClass::getEditorName();
        }

        $editorContext = isset($this->editorBootData['entity']['block_type'])
                ? $this->editorBootData['entity']['block_type']
                : '';

        if ($editorContext === 'pdf_template') {
            $allowedBlockTypes = array_values(array_diff($allowedBlockTypes, [
                'core/freeform',
                'core/html',
            ]));
        }

        if ($editorContext === 'order_bump_template') {
            // Only layout and text blocks, plus the card's own blocks; the email and receipt blocks
            // read an order that a card does not have.
            $allowedBlockTypes = array_values(array_filter($allowedBlockTypes, function ($name) {
                return strpos($name, 'fluent-cart/') !== 0 && !in_array($name, ['core/freeform', 'core/html'], true);
            }));

            foreach (static::getOrderBumpBlocks() as $blockClass) {
                $allowedBlockTypes = array_merge($allowedBlockTypes, $blockClass::blockNames());
            }
        }

        /**
         * Filter the allowed block types for the email editor.
         *
         * @param array $allowedBlockTypes The default allowed block types.
         * @param string $editorContext The editor context (e.g., 'template', 'campaign', 'recurring_campaign').
         */
        $allowedBlockTypes = apply_filters('fluent_cart/editor_allowed_block_types', $allowedBlockTypes, $editorContext);

        return array_values(array_unique($allowedBlockTypes));
    }
}
