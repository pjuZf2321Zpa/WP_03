<?php

namespace BitApps\IntegrationsPro\Actions\UserRegistrationMembership;

use Exception;
use WP_Error;
use WP_User;
use WPEverest\URMembership\Admin\Repositories\MembershipRepository;
use WPEverest\URMembership\Admin\Repositories\MembersSubscriptionRepository;
use WPEverest\URMembership\Admin\Services\MembershipService;

class UserRegistrationMembershipProHelper
{
    private const DEFAULT_ROLE = 'subscriber';

    private const USER_TABLE_FIELDS = [
        'user_login', 'user_pass', 'user_email', 'display_name',
        'user_url', 'first_name', 'last_name', 'description', 'nickname'
    ];

    private const COMMON_META_FIELDS = [
        'phone', 'date_of_birth', 'gender', 'country',
        'city', 'address', 'company'
    ];

    private const META_PREFIX = 'user_registration_';

    public static function createUser($defaultResponse, array $userData, object $integrationDetails): array
    {
        $validationError = self::validatePrerequisites($integrationDetails);
        if ($validationError) {
            return $validationError;
        }

        try {
            $formId = absint($integrationDetails->selectedForm);
            $userData = self::setDefaultUserValues($userData);

            $userId = wp_insert_user($userData);
            if (is_wp_error($userId)) {
                return self::errorResponse($userId->get_error_message());
            }

            self::processUserMetadata($userId, $userData, $formId);
            $membershipResult = self::processMembershipAssignment($userId, $userData);

            if (is_wp_error($membershipResult)) {
                return self::errorResponse($membershipResult->get_error_message());
            }

            return self::successResponse(
                __('User created successfully', 'bit-integrations-pro'),
                self::prepareUserData($userId, $formId)
            );
        } catch (Exception $e) {
            return self::errorResponse($e->getMessage());
        }
    }

    private static function validatePrerequisites(object $integrationDetails): ?array
    {
        if (!self::isUserRegistrationActive()) {
            return self::errorResponse(
                __('User Registration and Membership is not installed or activated', 'bit-integrations-pro')
            );
        }

        if (empty($integrationDetails->selectedForm)) {
            return self::errorResponse(__('Form ID is required', 'bit-integrations-pro'));
        }

        return null;
    }

    private static function isUserRegistrationActive(): bool
    {
        return class_exists('UserRegistration');
    }

    private static function errorResponse(string $message): array
    {
        return [
            'success' => false,
            'message' => $message
        ];
    }

    private static function successResponse(string $message, array $data = []): array
    {
        return [
            'success' => true,
            'message' => $message,
            'data'    => $data
        ];
    }

    private static function prepareUserData(int $userId, int $formId = 0, array $validFormData = []): array
    {
        $user = get_userdata($userId);
        if (!$user instanceof WP_User) {
            return [];
        }

        $data = self::buildBaseUserData($user, $userId);

        if ($formId > 0) {
            $data['formId'] = $formId;
        }

        if (!empty($validFormData)) {
            $data['formData'] = self::sanitizeFormData($validFormData);
        }

        $subscription = self::getUserSubscription($userId);
        if ($subscription) {
            $data['subscription'] = $subscription;
        }

        return $data;
    }

    private static function buildBaseUserData(WP_User $user, int $userId): array
    {
        return [
            'id'              => $userId,
            'user_login'      => $user->user_login,
            'user_email'      => $user->user_email,
            'user_nicename'   => $user->user_nicename,
            'display_name'    => $user->display_name,
            'first_name'      => get_user_meta($userId, 'first_name', true),
            'last_name'       => get_user_meta($userId, 'last_name', true),
            'user_url'        => $user->user_url,
            'user_registered' => $user->user_registered,
            'roles'           => $user->roles,
            'description'     => get_user_meta($userId, 'description', true),
            'nickname'        => get_user_meta($userId, 'nickname', true),
        ];
    }

    private static function sanitizeFormData(array $formData): array
    {
        unset($formData['user_pass']);

        return $formData;
    }

    private static function getUserSubscription(int $userId): ?array
    {
        if (!class_exists('\WPEverest\URMembership\Admin\Repositories\MembersSubscriptionRepository')) {
            return null;
        }

        $subscriptionRepository = new MembersSubscriptionRepository();
        $subscription = $subscriptionRepository->get_member_subscription($userId);

        return !empty($subscription) ? $subscription : null;
    }

    private static function setDefaultUserValues(array $userData): array
    {
        $userData['role'] = $userData['role'] ?? self::DEFAULT_ROLE;
        $userData['user_registered'] = $userData['user_registered'] ?? current_time('Y-m-d H:i:s');

        return $userData;
    }

    private static function processUserMetadata(int $userId, array $userData, int $formId): void
    {
        $filteredData = apply_filters('user_registration_before_user_meta_update', $userData, $userId, $formId);

        self::updateUserMeta($userId, $filteredData);
        self::updateRegistrationMeta($userId, $formId);

        do_action('user_registration_after_user_meta_update', $filteredData, $formId, $userId);
    }

    private static function updateRegistrationMeta(int $userId, int $formId): void
    {
        $metaUpdates = [
            'ur_form_id'             => $formId,
            'urm_user_just_created'  => 'yes',
            'ur_registration_source' => 'integration'
        ];

        if (\function_exists('ur_get_ip_address')) {
            $metaUpdates['ur_user_ip'] = ur_get_ip_address();
        }

        foreach ($metaUpdates as $key => $value) {
            update_user_meta($userId, $key, $value);
        }
    }

    private static function updateUserMeta(int $userId, array $userData): void
    {
        $userTableFields = self::getUserTableFields();

        foreach ($userData as $key => $value) {
            if (self::shouldSkipMetaField($key, $value, $userTableFields)) {
                continue;
            }

            $metaKey = self::normalizeMetaKey($key, $userTableFields);
            update_user_meta($userId, $metaKey, $value);
        }
    }

    private static function getUserTableFields(): array
    {
        return \function_exists('ur_get_user_table_fields')
            ? ur_get_user_table_fields()
            : self::USER_TABLE_FIELDS;
    }

    private static function shouldSkipMetaField(string $key, $value, array $userTableFields): bool
    {
        if (\in_array($key, $userTableFields, true) || \in_array($key, ['role', 'user_registered'], true)) {
            return true;
        }

        return empty($value) && $value !== '0' && $value !== 0;
    }

    private static function normalizeMetaKey(string $key, array $userTableFields): string
    {
        if (\in_array($key, self::COMMON_META_FIELDS, true)) {
            return self::META_PREFIX . $key;
        }

        if (strpos($key, self::META_PREFIX) !== 0 && !\in_array($key, $userTableFields, true)) {
            return self::META_PREFIX . $key;
        }

        return $key;
    }

    private static function processMembershipAssignment(int $userId, array $userData)
    {
        if (!self::isMembershipServiceAvailable()) {
            return;
        }

        $membershipId = self::extractMembershipId($userData);
        if (!$membershipId) {
            return;
        }

        return self::assignMembership($userId, $membershipId);
    }

    private static function isMembershipServiceAvailable(): bool
    {
        return class_exists('\WPEverest\URMembership\Admin\Services\MembershipService');
    }

    private static function extractMembershipId(array $userData): ?int
    {
        if (!empty($userData['membership'])) {
            return absint($userData['membership']);
        }

        foreach ($userData as $key => $value) {
            if (self::isMembershipFieldKey($key) && !empty($value)) {
                return absint($value);
            }
        }

        return null;
    }

    private static function isMembershipFieldKey(string $key): bool
    {
        $patterns = [
            '/^membership_field_\d+$/',
            '/^' . self::META_PREFIX . 'membership_field_\d+$/'
        ];

        foreach ($patterns as $pattern) {
            if (preg_match($pattern, $key)) {
                return true;
            }
        }

        return false;
    }

    private static function assignMembership(int $userId, int $membershipId)
    {
        try {
            $membership = self::getMembership($membershipId);
            if (is_wp_error($membership)) {
                return $membership;
            }

            $membershipType = self::getMembershipType($membership);
            $orderResult = self::createMembershipOrder($userId, $membershipId);

            if (is_wp_error($orderResult)) {
                return $orderResult;
            }

            if ($membershipType === 'free') {
                delete_user_meta($userId, 'urm_user_just_created');
            }

            return self::buildMembershipResponse($orderResult, $membershipType);
        } catch (Exception $e) {
            return new WP_Error(
                'membership_assignment_exception',
                __('An error occurred while assigning membership: ', 'bit-integrations-pro') . $e->getMessage()
            );
        }
    }

    private static function getMembership(int $membershipId)
    {
        $membershipRepository = new MembershipRepository();
        $membership = $membershipRepository->get_single_membership_by_ID($membershipId);

        if (!$membership) {
            return new WP_Error(
                'membership_not_found',
                __('Membership not found.', 'bit-integrations-pro')
            );
        }

        return $membership;
    }

    private static function getMembershipType(array $membership): string
    {
        $membershipMeta = json_decode($membership['meta_value'], true);

        return $membershipMeta['type'] ?? 'free';
    }

    private static function createMembershipOrder(int $userId, int $membershipId)
    {
        $user = get_userdata($userId);
        if (!$user instanceof WP_User) {
            return new WP_Error(
                'invalid_user',
                __('Invalid user.', 'bit-integrations-pro')
            );
        }

        $orderData = [
            'username'       => $user->user_login,
            'membership'     => $membershipId,
            'payment_method' => 'free',
        ];

        $membershipService = new MembershipService();
        $response = $membershipService->create_membership_order_and_subscription($orderData);

        if (empty($response['status'])) {
            return new WP_Error(
                'membership_assignment_failed',
                $response['message'] ?? __('Failed to assign membership.', 'bit-integrations-pro')
            );
        }

        return $response;
    }

    private static function buildMembershipResponse(array $orderResult, string $membershipType): array
    {
        return [
            'success'         => true,
            'subscription_id' => $orderResult['subscription_id'] ?? null,
            'membership_type' => $membershipType,
            'message'         => __('Membership assigned successfully.', 'bit-integrations-pro'),
        ];
    }
}
