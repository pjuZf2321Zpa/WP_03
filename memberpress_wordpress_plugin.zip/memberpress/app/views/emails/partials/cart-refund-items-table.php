<?php if (!defined('ABSPATH')) {
    die('You are not allowed to call this page directly.');
}
// phpcs:disable WordPress.Security.EscapeOutput.OutputNotEscaped -- all row and total values are escaped when built in the email classes.
?>
<table style="width:100%;border-collapse:collapse;margin:16px 0;" class="mepr-cart-refund-items">
    <?php if (!empty($rows)) : ?>
    <thead>
        <tr style="background:#f5f5f5;">
            <th style="text-align:left;padding:8px 12px;border-bottom:2px solid #ddd;"><?php echo esc_html_x('Product', 'email', 'memberpress'); ?></th>
            <th style="text-align:center;padding:8px 12px;border-bottom:2px solid #ddd;"><?php echo esc_html_x('Qty', 'email', 'memberpress'); ?></th>
            <th style="text-align:right;padding:8px 12px;border-bottom:2px solid #ddd;"><?php echo esc_html_x('Refunded', 'email', 'memberpress'); ?></th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($rows as $row) : ?>
        <tr>
            <td style="padding:8px 12px;border-bottom:1px solid #eee;"><?php echo $row['name']; ?></td>
            <td style="text-align:center;padding:8px 12px;border-bottom:1px solid #eee;"><?php echo $row['qty']; ?></td>
            <td style="text-align:right;padding:8px 12px;border-bottom:1px solid #eee;"><?php echo $row['total']; ?></td>
        </tr>
        <?php endforeach; ?>
    </tbody>
    <?php endif; ?>
    <tfoot>
        <?php if ($refunded_tax !== null) : ?>
        <tr>
            <td<?php echo !empty($rows) ? ' colspan="2"' : ''; ?> style="text-align:right;padding:6px 12px;"><?php echo esc_html_x('Refunded Tax', 'email', 'memberpress'); ?></td>
            <td style="text-align:right;padding:6px 12px;"><?php echo $refunded_tax; ?></td>
        </tr>
        <?php endif; ?>
        <tr style="font-weight:bold;border-top:2px solid #ddd;">
            <td<?php echo !empty($rows) ? ' colspan="2"' : ''; ?> style="text-align:right;padding:8px 12px;"><?php echo esc_html_x('Total Refunded', 'email', 'memberpress'); ?></td>
            <td style="text-align:right;padding:8px 12px;"><?php echo $refunded_amount; ?></td>
        </tr>
    </tfoot>
</table>
