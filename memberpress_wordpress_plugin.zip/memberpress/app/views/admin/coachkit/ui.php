<?php
/**
 * View admin/coachkit/ui.
 *
 * @var string  $main_file
 * @var string  $plugin
 * @var string  $name
 * @var boolean $is_installed
 * @var string  $redirect_url
 */

$button_action = $is_installed ? 'activate' : 'install';
$button_label  = $is_installed ? __('Activate CoachKit™ Add-On', 'memberpress') : __('Install & Activate CoachKit™ Add-On', 'memberpress');

defined('ABSPATH') || exit;
?>

<div class="wrap">

    <div class="mepr-sister-plugin mepr-sister-plugin-wp-mail-smtp">

        <div class="mepr-sister-plugin-image mp-courses-image">
            <img src="<?php echo esc_url(MEPR_BRAND_URL . '/images/coachkit-logo.svg'); ?>" width="800" height="216" alt="MemberPress CoachKit™">
        </div>

        <div class="mepr-sister-plugin-title">
            <?php esc_html_e('Next-Level Coaching Tools', 'memberpress'); ?>
        </div>

        <div class="mepr-sister-plugin-description">
            <?php esc_html_e("Customize your coaching to thrive or expand with the industry's only membership-coaching platform!", 'memberpress'); ?>
        </div>

        <div class="mepr-sister-plugin-info mepr-clearfix">
            <div class="mepr-sister-plugin-info-image">
                <div>
                    <img src="<?php echo esc_url(MEPR_BRAND_URL . '/images/coachkit-screenshot.png'); ?>" alt="<?php esc_attr_e('MemberPress CoachKit™', 'memberpress'); ?>">
                </div>
            </div>
            <div class="mepr-sister-plugin-info-features">
                <?php
                $bullets = [
                    esc_html__('Sell unlimited coaching programs', 'memberpress'),
                    esc_html__('Track success with habit log', 'memberpress'),
                    esc_html__('Celebrate mini-wins with milestones', 'memberpress'),
                    esc_html__('Keep clients on track with due dates', 'memberpress'),
                    esc_html__('1:1 in-platform private messaging', 'memberpress'),
                    esc_html__('Match coaches to specific cohorts', 'memberpress'),
                ];
                ?>
                <ul>
                    <?php
                    foreach ($bullets as $bullet) {
                        echo '<li style="margin-bottom: 5px; font-size: 13px;"><i class="mp-icon mp-icon-right-big"></i>';
                        echo esc_html($bullet);
                        echo '</li>';
                    }
                    ?>
                </ul>
            </div>
        </div>

        <div
            class="mepr-sister-plugin-step mepr-sister-plugin-step-no-number mepr-sister-plugin-step-current mepr-clearfix">
            <div class="mepr-sister-plugin-step-detail">
                <div class="mepr-sister-plugin-step-title">
                    <?php if ($is_installed) : // Installed but not active. ?>
                        <?php esc_html_e('Enable MemberPress CoachKit™', 'memberpress'); ?>
                    <?php else : // Not installed. ?>
                        <?php esc_html_e('Install and Activate MemberPress CoachKit™', 'memberpress'); ?>
                    <?php endif; ?>
                </div>
                <div class="mepr-sister-plugin-step-button">
                  <button
                    type="button"
                    class="mepr-feature-plugin button button-primary button-hero"
                    data-action="<?php echo esc_attr($button_action); ?>"
                    data-slug="<?php echo esc_attr($plugin); ?>"
                    data-plugin="<?php echo esc_attr($main_file); ?>"
                    data-name="<?php echo esc_attr($name); ?>"
                    data-redirect="<?php echo esc_url($redirect_url); ?>"
                  >
                    <?php echo esc_html($button_label); ?>
                  </button>
                </div>
                <div class="mepr-feature-plugin-notice notice inline" style="display:none;"><p></p></div>
            </div>
        </div>

    </div>
</div>
