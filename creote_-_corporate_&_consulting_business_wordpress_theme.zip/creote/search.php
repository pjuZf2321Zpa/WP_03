<?php
/**
 * The Search Template
 * @package Creote WordPress Theme
 */

get_header();

if ( ! function_exists( 'elementor_theme_do_location' ) || ! elementor_theme_do_location( 'archive' ) ) :
?>
    <div id="primary" class="content-area blog_masonry col-lg-8 m-auto">
        <main id="main" class="site-main">
            <div class="row loop-grid">

                <?php if ( have_posts() ) : ?>

                    <!-- Search Form -->
                    <div class="search-form search_file text-center mb-30">
                        <?php do_action('creote_get_simple_search'); ?>
                    </div>

                    <?php
                    while ( have_posts() ) :
                        the_post();
                        get_template_part( 'template-parts/content', 'search' );
                    endwhile;
                    ?>

                    <!-- Pagination -->
                    <div class="row">
                        <div class="col-lg-12">
                            <?php
                            $big = 999999999;
                            $pagination = paginate_links( array(
                                'base'      => str_replace( $big, '%#%', esc_url( get_pagenum_link( $big ) ) ),
                                'format'    => '?paged=%#%',
                                'current'   => max( 1, get_query_var( 'paged' ) ),
                                'total'     => $wp_query->max_num_pages,
                                'type'      => 'array',
                                'prev_text' => '&laquo;',
                                'next_text' => '&raquo;',
                            ));

                            if ( $pagination ) {
                                echo '<div class="pagination_wrapper"><ul class="pagination">';
                                foreach ( $pagination as $page_link ) {
                                    echo '<li class="page-item">' . wp_kses_post( $page_link ) . '</li>';
                                }
                                echo '</ul></div>';
                            }
                            ?>
                        </div>
                    </div>

                <?php else : ?>

                    <?php get_template_part( 'template-parts/content', 'none' ); ?>

                <?php endif; ?>

            </div>
        </main>
    </div>
<?php
endif;

get_footer();