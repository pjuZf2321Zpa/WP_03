<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Actions\PipeDrive\PipeDriveHelperPro;
use BitApps\IntegrationsPro\Config;
use BitApps\IntegrationsPro\Core\Util\Hooks;

// Deprecated since v2.7.8 - use bit_integrations_pipedrive_* hooks instead
if (bit_integrations_version_below('2.7.8')) {
    Hooks::add('btcbi_pipedrive_store_related_list', [PipeDriveHelperPro::class, 'addRelatedList'], 10, 6);
}

// New hooks since v2.7.8
Hooks::add(Config::withFreePrefix('pipedrive_store_related_list'), [PipeDriveHelperPro::class, 'addRelatedList'], 10, 6);
