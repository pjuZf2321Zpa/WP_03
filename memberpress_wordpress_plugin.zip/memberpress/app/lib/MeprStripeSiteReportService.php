<?php

defined('ABSPATH') || exit;

/**
 * Reports the site's home domain and build to the Stripe Connect service
 * whenever either changes.
 *
 * The site keeps a hash of its site_uuid, home domain and edition in an
 * option. A daily WP-Cron event compares the current hash with the stored
 * one and sends the report when they differ. A change therefore reaches the
 * service whether the owner logs in, including after a migration that
 * rewrote the home URL in the database. No page load sends the report.
 *
 * A report is sent only while the site is connected: the authenticator
 * site_uuid is set and at least one Stripe payment method is connected. A
 * non-production environment or a dev URL never reports, as it never
 * requests a fee.
 *
 * A 2xx answer, or a 422 refusing the report, stores the reported hash,
 * since the service gives the same report the same answer. Any other answer
 * or a transport error keeps the stored hash, so the next daily run sends
 * the report again; that includes a 404 from a service that does not yet
 * accept reports. The site sends what it is and takes no decision from the
 * answer.
 */
class MeprStripeSiteReportService
{
    /**
     * The option holding the hash of the last report the service answered.
     *
     * @var string
     */
    public const HASH_OPTION = 'mepr_stripe_site_report_hash';

    /**
     * The daily WP-Cron event that compares the hash and sends the report.
     *
     * @var string
     */
    public const CRON_HOOK = 'mepr_stripe_site_report';

    /**
     * Sends the report when the site's domain or edition has changed.
     *
     * Runs from the daily WP-Cron event.
     *
     * @return void
     */
    public function report_if_changed(): void
    {
        $site_uuid = (string) get_option('mepr_authenticator_site_uuid');

        if ('' === $site_uuid || !MeprStripeGateway::has_method_with_connect_status()) {
            return;
        }

        // The home domain, as /fee sends it and as a license activates on unless its domain is overridden.
        $domain = MeprUtils::site_domain();
        $hash   = self::hash($site_uuid, $domain);

        if (get_option(self::HASH_OPTION) === $hash || MeprUtils::is_staging_or_dev()) {
            return;
        }

        $this->send($site_uuid, $domain, $hash);
    }

    /**
     * Posts the report and stores its hash once the service has answered it.
     *
     * @param string $site_uuid The authenticator site_uuid.
     * @param string $domain    The site's home domain.
     * @param string $hash      The hash of the report.
     *
     * @return void
     */
    private function send(string $site_uuid, string $domain, string $hash): void
    {
        $response = wp_remote_post(MEPR_STRIPE_SERVICE_URL . '/api/memberpress/site-report', [
            'timeout'     => 5,
            'redirection' => 0,
            'headers'     => MeprUtils::jwt_header(
                MeprAuthenticatorCtrl::generate_jwt(['site_uuid' => $site_uuid]),
                MEPR_STRIPE_SERVICE_DOMAIN
            ),
            'body'        => wp_json_encode([
                'domain'  => $domain,
                'edition' => MEPR_EDITION,
                'version' => MEPR_VERSION,
            ]),
        ]);

        if (is_wp_error($response)) {
            MeprUtils::debug_log('mepr_stripe_site_report: HTTP transport error: ' . $response->get_error_message());
            return;
        }

        $code     = (int) wp_remote_retrieve_response_code($response);
        $accepted = $code >= 200 && $code < 300;
        $refused  = 422 === $code;

        if (!$accepted && !$refused) {
            MeprUtils::debug_log('mepr_stripe_site_report: unexpected response (' . $code . ').');
            return;
        }

        if ($refused) {
            MeprUtils::debug_log('mepr_stripe_site_report: report refused (HTTP ' . $code . ').');
        }

        update_option(self::HASH_OPTION, $hash);
    }

    /**
     * Returns the hash of what a report from this site carries: its site_uuid,
     * home domain and this build's edition.
     *
     * The plugin version is left out, so an update alone does not report.
     *
     * @param string $site_uuid The authenticator site_uuid.
     * @param string $domain    The site's home domain.
     *
     * @return string
     */
    private static function hash(string $site_uuid, string $domain): string
    {
        return hash('sha256', (string) wp_json_encode([$site_uuid, $domain, MEPR_EDITION]));
    }
}
