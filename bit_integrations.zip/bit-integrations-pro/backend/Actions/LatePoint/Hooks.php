<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Actions\LatePoint\LatePointProHelper;
use BitApps\IntegrationsPro\Config;
use BitApps\IntegrationsPro\Core\Util\Hooks;

Hooks::filter(Config::withFreePrefix('latepoint_create_booking'), [LatePointProHelper::class, 'createBooking'], 10, 4);
Hooks::filter(Config::withFreePrefix('latepoint_update_booking'), [LatePointProHelper::class, 'updateBooking'], 10, 4);
Hooks::filter(Config::withFreePrefix('latepoint_create_order'), [LatePointProHelper::class, 'createOrder'], 10, 4);
Hooks::filter(Config::withFreePrefix('latepoint_create_agent'), [LatePointProHelper::class, 'createAgent'], 10, 3);
Hooks::filter(Config::withFreePrefix('latepoint_create_coupon'), [LatePointProHelper::class, 'createCoupon'], 10, 3);
Hooks::filter(Config::withFreePrefix('latepoint_update_coupon'), [LatePointProHelper::class, 'updateCoupon'], 10, 3);
Hooks::filter(Config::withFreePrefix('latepoint_cancel_booking'), [LatePointProHelper::class, 'cancelBooking'], 10, 2);
Hooks::filter(Config::withFreePrefix('latepoint_create_customer'), [LatePointProHelper::class, 'createCustomer'], 10, 2);
