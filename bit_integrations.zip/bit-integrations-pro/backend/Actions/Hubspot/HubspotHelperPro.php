<?php

/**
 * Hubspot    Record Api
 */

namespace BitApps\IntegrationsPro\Actions\Hubspot;

class HubspotHelperPro
{
    public static function updateEntity($id, $finalData, $actionName, $defaultHeader)
    {
        $httpHelperClass = bit_integrations_get_class('Core\\Util\\HttpHelper');

        $apiEndpoint = "https://api.hubapi.com/crm/v3/objects/{$actionName}/{$id}";

        return $httpHelperClass::request($apiEndpoint, 'PATCH', wp_json_encode($finalData), $defaultHeader);
    }
}
