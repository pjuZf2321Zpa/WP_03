<?php

namespace WPAICG\ContentWriter\SEO;

if (!defined('ABSPATH')) {
    exit;
}

/** Shared rule checks and phrase formatting for AIOSEO title and content policies. */
trait AIPKit_Content_Writer_SEO_AIOSEO_Context_Trait
{
    private static function rule_enabled(array $context, string $rule_id): bool
    {
        return !class_exists(AIPKit_Content_Writer_SEO_Config::class)
            || AIPKit_Content_Writer_SEO_Config::is_rule_enabled($context, $rule_id);
    }

    private static function title_case_phrase(string $phrase): string
    {
        $phrase = trim(preg_replace('/\s+/', ' ', $phrase));
        if ($phrase === '') {
            return '';
        }

        return ucwords(strtolower($phrase));
    }
}

/**
 * Uses AIOSEO's native headline analyzer to pick safer title rewrites.
 */
class AIPKit_Content_Writer_Smart_SEO_AIOSEO_Headline_Helper
{
    use AIPKit_Content_Writer_SEO_AIOSEO_Context_Trait;

    private const PASS_SCORE = 70;

    public static function maybe_improve_title(array $draft, array $context = []): array
    {
        if (sanitize_key((string) ($context['profile'] ?? '')) !== 'aioseo') {
            return $draft;
        }
        if (class_exists(AIPKit_Content_Writer_SEO_Config::class) && !AIPKit_Content_Writer_SEO_Config::is_rule_enabled($context, 'aioseo_headline_score')) {
            return $draft;
        }

        $title = isset($draft['title']) ? sanitize_text_field((string) $draft['title']) : '';
        $focus_keyphrase = isset($draft['focus_keyword']) ? sanitize_text_field((string) $draft['focus_keyword']) : '';
        if ($title === '' || $focus_keyphrase === '' || !self::is_analyzer_available()) {
            return $draft;
        }

        $current_score = self::score_title($title);
        if ($current_score >= self::PASS_SCORE) {
            return $draft;
        }

        $best = self::best_candidate($title, $focus_keyphrase, $context, $current_score);
        if ($best === null || $best['score'] < self::PASS_SCORE || $best['score'] <= $current_score) {
            return $draft;
        }

        $draft['title'] = $best['title'];
        return $draft;
    }

    private static function best_candidate(string $title, string $focus_keyphrase, array $context, int $current_score): ?array
    {
        $focus_title = self::title_case_phrase($focus_keyphrase);
        $subjects = self::subject_variants($title, $focus_keyphrase, $context);
        $max_title_length = self::max_title_length();
        $start_with_focus_keyphrase = self::rule_enabled($context, 'aioseo_keyphrase_beginning_title');
        $include_focus_keyphrase = $start_with_focus_keyphrase || self::rule_enabled($context, 'focus_keyword_in_title');
        $best = null;

        foreach ($subjects as $subject) {
            $subject_word_count = self::word_count($subject);
            foreach (self::candidate_patterns($focus_title, $subject, $start_with_focus_keyphrase, $include_focus_keyphrase) as $candidate) {
                $candidate = self::normalize_title($candidate);
                if ($candidate === '' || strlen($candidate) > $max_title_length) {
                    continue;
                }

                $score = self::score_title($candidate);
                if ($score <= $current_score) {
                    continue;
                }

                $candidate_data = [
                    'title' => $candidate,
                    'score' => $score,
                    'subject_words' => $subject_word_count,
                ];

                if (self::is_better_candidate($candidate_data, $best)) {
                    $best = $candidate_data;
                }
            }
        }

        return $best;
    }

    private static function is_better_candidate(array $candidate, ?array $best): bool
    {
        if ($best === null) {
            return true;
        }

        $candidate_score = (int) ($candidate['score'] ?? 0);
        $best_score = (int) ($best['score'] ?? 0);
        $candidate_subject_words = (int) ($candidate['subject_words'] ?? 0);
        $best_subject_words = (int) ($best['subject_words'] ?? 0);

        if ($candidate_score >= self::PASS_SCORE && $best_score >= self::PASS_SCORE) {
            if ($candidate_subject_words > $best_subject_words && $candidate_score >= ($best_score - 10)) {
                return true;
            }

            if ($best_subject_words > $candidate_subject_words && $best_score >= ($candidate_score - 10)) {
                return false;
            }
        }

        if ($candidate_score !== $best_score) {
            return $candidate_score > $best_score;
        }

        if ($candidate_subject_words !== $best_subject_words) {
            return $candidate_subject_words > $best_subject_words;
        }

        return strlen((string) ($candidate['title'] ?? '')) < strlen((string) ($best['title'] ?? ''));
    }

    private static function candidate_patterns(string $focus_title, string $subject, bool $start_with_focus_keyphrase, bool $include_focus_keyphrase): array
    {
        $subject = trim($subject);
        if ($start_with_focus_keyphrase && $subject === '') {
            return [
                sprintf('%s: 7 Powerful Tips', $focus_title),
                sprintf('%s: 7 Better Tips', $focus_title),
            ];
        }

        if ($start_with_focus_keyphrase) {
            $patterns = [
                sprintf('%s: 7 Better Tips for Your %s', $focus_title, $subject),
                sprintf('%s: 7 Better Tips for %s', $focus_title, $subject),
                sprintf('%s: 7 Powerful Tips for %s', $focus_title, $subject),
                sprintf('%s: 7 Best Powerful Tips for %s', $focus_title, $subject),
                sprintf('%s: 7 Powerful Tips to Know %s', $focus_title, $subject),
            ];

            if (self::supports_improve_pattern($focus_title)) {
                array_splice($patterns, 1, 0, [sprintf('%s: How to Improve %s', $focus_title, $subject)]);
            }

            return $patterns;
        }

        if ($include_focus_keyphrase) {
            if ($subject === '') {
                return [
                    sprintf('7 Better Tips for %s', $focus_title),
                    sprintf('How to Improve %s', $focus_title),
                    sprintf('7 Powerful Tips for %s', $focus_title),
                ];
            }

            $patterns = [
                sprintf('7 Better %s Tips for %s', $focus_title, $subject),
                sprintf('How to Improve %s: %s', $subject, $focus_title),
                sprintf('7 Powerful Tips for %s', $focus_title),
                sprintf('Best %s Tips for %s', $focus_title, $subject),
            ];
            if (self::supports_improve_pattern($focus_title)) {
                array_splice($patterns, 1, 0, [sprintf('How to Improve %s', $focus_title)]);
            }

            return $patterns;
        }

        $topic = $subject !== '' ? $subject : $focus_title;
        return [
            sprintf('7 Better Tips for %s', $topic),
            sprintf('How to Improve %s', $topic),
            sprintf('7 Powerful %s Tips', $topic),
            sprintf('Best %s Tips to Know', $topic),
        ];
    }

    private static function subject_variants(string $title, string $focus_keyphrase, array $context): array
    {
        $sources = [
            $title,
            (string) ($context['topic'] ?? ''),
            (string) ($context['keywords'] ?? ''),
        ];

        $variants = [];
        foreach ($sources as $source) {
            $subject = self::extract_subject($source, $focus_keyphrase);
            if ($subject === '') {
                continue;
            }

            $words = preg_split('/\s+/', $subject) ?: [];
            $words = array_values(array_filter($words));
            for ($count = min(3, count($words)); $count >= 1; $count--) {
                if ($count === 1 && count($words) > 1 && self::is_generic_single_subject((string) end($words))) {
                    continue;
                }
                $variants[] = implode(' ', array_slice($words, -$count));
            }
        }

        $variants[] = '';

        $seen = [];
        $unique = [];
        foreach ($variants as $variant) {
            $key = strtolower($variant);
            if (isset($seen[$key])) {
                continue;
            }
            $seen[$key] = true;
            $unique[] = $variant;
        }

        return $unique;
    }

    private static function extract_subject(string $source, string $focus_keyphrase): string
    {
        $source = wp_strip_all_tags($source);
        $source = html_entity_decode($source, ENT_QUOTES | ENT_HTML5, get_bloginfo('charset') ?: 'UTF-8');
        $source = preg_replace('/\b' . preg_quote($focus_keyphrase, '/') . '\b/i', ' ', (string) $source);
        $source = preg_replace('/[^A-Za-z0-9 ]+/', ' ', (string) $source);
        $source = preg_replace('/\s+/', ' ', (string) $source);
        $words = preg_split('/\s+/', trim((string) $source)) ?: [];

        $stop_words = array_fill_keys([
            'a', 'an', 'and', 'are', 'as', 'best', 'better', 'complete', 'easy', 'essential',
            'for', 'guide', 'how', 'improve', 'in', 'life', 'new', 'of', 'powerful', 'proven',
            'reasons', 'smart', 'the', 'tips', 'tip', 'to', 'top', 'ultimate', 'ways', 'wins',
            'with', 'you', 'your',
        ], true);

        $subject_words = [];
        foreach ($words as $word) {
            $clean = trim($word);
            if ($clean === '' || is_numeric($clean) || isset($stop_words[strtolower($clean)])) {
                continue;
            }
            $subject_words[] = self::title_case_phrase($clean);
        }

        return trim(implode(' ', $subject_words));
    }

    private static function score_title(string $title): int
    {
        self::load_phpinsight_if_needed();
        if (!class_exists('\PHPInsight\Sentiment') || !self::is_analyzer_available()) {
            return 0;
        }

        try {
            $result = aioseo()->standalone->headlineAnalyzer->getResult(sanitize_text_field($title));
        } catch (\Throwable $e) {
            return 0;
        }

        return isset($result['score']) ? absint($result['score']) : 0;
    }

    private static function word_count(string $text): int
    {
        $words = preg_split('/\s+/', trim($text)) ?: [];
        return count(array_filter($words));
    }

    private static function is_generic_single_subject(string $word): bool
    {
        return in_array(strtolower(trim($word)), ['air', 'max', 'mini', 'plus', 'pro', 'ultra'], true);
    }

    private static function supports_improve_pattern(string $focus_title): bool
    {
        return (bool) preg_match('/\b(?:battery|conversion|engagement|life|performance|productivity|quality|ranking|readability|revenue|sales|security|seo|speed|traffic|workflow)\b/i', $focus_title);
    }

    private static function is_analyzer_available(): bool
    {
        if (!function_exists('aioseo')) {
            return false;
        }

        try {
            $aioseo = aioseo();
        } catch (\Throwable $e) {
            return false;
        }

        return is_object($aioseo)
            && isset($aioseo->standalone)
            && isset($aioseo->standalone->headlineAnalyzer)
            && is_object($aioseo->standalone->headlineAnalyzer)
            && method_exists($aioseo->standalone->headlineAnalyzer, 'getResult');
    }

    private static function load_phpinsight_if_needed(): void
    {
        if (class_exists('\PHPInsight\Sentiment') || !defined('AIOSEO_DIR')) {
            return;
        }

        $autoload = rtrim((string) AIOSEO_DIR, '/\\') . '/vendor/jwhennessey/phpinsight/autoload.php';
        if (is_readable($autoload)) {
            require_once $autoload;
        }
    }

    private static function max_title_length(): int
    {
        $site_title = function_exists('get_bloginfo') ? trim((string) get_bloginfo('name')) : '';
        if ($site_title === '') {
            return 60;
        }

        return max(35, 60 - strlen($site_title) - 3);
    }

    private static function normalize_title(string $title): string
    {
        $title = preg_replace('/\s+/', ' ', trim($title));
        return sanitize_text_field((string) $title);
    }

}

/**
 * Applies deterministic AIOSEO content fixes that are safer than another model pass.
 */
class AIPKit_Content_Writer_Smart_SEO_AIOSEO_Content_Helper
{
    use AIPKit_Content_Writer_SEO_AIOSEO_Context_Trait;

    public static function maybe_improve_content(array $draft, array $context = []): array
    {
        if (sanitize_key((string) ($context['profile'] ?? '')) !== 'aioseo') {
            return $draft;
        }

        $content = isset($draft['content_html']) && trim((string) $draft['content_html']) !== ''
            ? (string) $draft['content_html']
            : (string) ($draft['content'] ?? '');
        $focus_keyphrase = isset($draft['focus_keyword']) ? sanitize_text_field((string) $draft['focus_keyword']) : '';
        if ($content === '' || $focus_keyphrase === '') {
            return $draft;
        }

        if (self::rule_enabled($context, 'aioseo_keyphrase_in_introduction')) {
            $content = self::ensure_intro_paragraph($content, $focus_keyphrase);
        }
        if (self::rule_enabled($context, 'aioseo_keyphrase_in_subheadings')) {
            $content = self::ensure_subheading_keyphrase_balance($content, $focus_keyphrase);
        }
        if (self::rule_enabled($context, 'aioseo_transition_words')) {
            $content = self::ensure_transition_word_floor($content);
        }
        $draft['content_html'] = $content;
        $draft['content'] = $content;

        return $draft;
    }

    private static function ensure_intro_paragraph(string $content, string $focus_keyphrase): string
    {
        $content = trim($content);
        if ($content === '') {
            return '';
        }

        if (!preg_match('/<p\b/i', $content)) {
            $content = wpautop($content);
        }

        $paragraphs = self::get_paragraphs($content);
        if (empty($paragraphs)) {
            return $content;
        }

        $first_text_paragraph = null;
        foreach ($paragraphs as $paragraph) {
            if (self::word_count($paragraph['html']) < 5) {
                continue;
            }
            $first_text_paragraph = $paragraph;
            break;
        }

        if ($first_text_paragraph === null) {
            return $content;
        }

        $intro_html = $first_text_paragraph['html'];
        if (!self::contains_phrase($intro_html, $focus_keyphrase)) {
            $intro_html = self::prepend_focus_sentence($intro_html, $focus_keyphrase);
        }

        $content_without_intro = substr_replace(
            $content,
            '',
            (int) $first_text_paragraph['offset'],
            strlen((string) $first_text_paragraph['full'])
        );

        $intro_html = self::normalize_intro_paragraph($intro_html);
        $content_without_intro = trim($content_without_intro);

        if (self::starts_with_same_intro($content_without_intro, $intro_html)) {
            return $content_without_intro;
        }

        return trim($intro_html . "\n\n" . $content_without_intro);
    }

    private static function ensure_subheading_keyphrase_balance(string $content, string $focus_keyphrase): string
    {
        $headings = self::get_headings($content);
        $heading_count = count($headings);
        if ($heading_count < 2) {
            return $content;
        }

        $matches = 0;
        foreach ($headings as $heading) {
            if (self::contains_phrase($heading['inner'], $focus_keyphrase)) {
                $matches++;
            }
        }

        $minimum_matches = max(1, (int) ceil($heading_count * 0.3));
        $maximum_matches = max($minimum_matches, (int) floor($heading_count * 0.75));
        if ($matches >= $minimum_matches && $matches <= $maximum_matches) {
            return $content;
        }

        if ($matches < $minimum_matches) {
            return self::add_keyphrase_to_headings($content, $headings, $focus_keyphrase, $minimum_matches - $matches);
        }

        return self::remove_excess_keyphrase_from_headings($content, $headings, $focus_keyphrase, $matches - $maximum_matches);
    }

    private static function add_keyphrase_to_headings(string $content, array $headings, string $focus_keyphrase, int $needed): string
    {
        $focus_title = self::title_case_phrase($focus_keyphrase);
        $replacements = [];

        foreach ($headings as $heading) {
            if ($needed <= 0) {
                break;
            }
            if (self::contains_phrase($heading['inner'], $focus_keyphrase)) {
                continue;
            }

            $plain = trim(wp_strip_all_tags((string) $heading['inner']));
            if ($plain === '' || self::is_utility_heading($plain)) {
                continue;
            }

            $new_inner = esc_html(self::add_keyphrase_to_heading_text($plain, $focus_title));
            $replacements[(int) $heading['offset']] = [
                'length' => strlen((string) $heading['full']),
                'html' => '<h' . (int) $heading['level'] . '>' . $new_inner . '</h' . (int) $heading['level'] . '>',
            ];
            $needed--;
        }

        return self::apply_replacements($content, $replacements);
    }

    private static function remove_excess_keyphrase_from_headings(string $content, array $headings, string $focus_keyphrase, int $excess): string
    {
        $replacements = [];
        foreach (array_reverse($headings) as $heading) {
            if ($excess <= 0) {
                break;
            }
            if (!self::contains_phrase($heading['inner'], $focus_keyphrase)) {
                continue;
            }

            $plain = trim(wp_strip_all_tags((string) $heading['inner']));
            $plain = preg_replace('/^' . preg_quote($focus_keyphrase, '/') . '\s*[:\-–—]?\s*/i', '', $plain);
            $plain = trim((string) $plain);
            if ($plain === '' || self::contains_phrase($plain, $focus_keyphrase)) {
                continue;
            }

            $replacements[(int) $heading['offset']] = [
                'length' => strlen((string) $heading['full']),
                'html' => '<h' . (int) $heading['level'] . '>' . esc_html($plain) . '</h' . (int) $heading['level'] . '>',
            ];
            $excess--;
        }

        return self::apply_replacements($content, $replacements);
    }

    private static function ensure_transition_word_floor(string $content): string
    {
        $sentences = self::get_sentences($content);
        $sentence_count = count($sentences);
        if ($sentence_count < 6 || self::transition_percentage($sentences) >= 30.0) {
            return $content;
        }

        $needed = (int) ceil(($sentence_count * 0.36) - self::transition_sentence_count($sentences));
        if ($needed <= 0) {
            return $content;
        }

        $transitions = ['In addition', 'As a result', 'However', 'For example', 'Meanwhile', 'Overall'];
        $index = 0;

        return preg_replace_callback('/<p\b([^>]*)>(.*?)<\/p>/is', static function (array $match) use (&$needed, &$index, $transitions): string {
            if ($needed <= 0) {
                return (string) $match[0];
            }

            $inner = (string) ($match[2] ?? '');
            $plain = trim(wp_strip_all_tags($inner));
            $first_sentence = self::first_sentence($plain);
            if ($plain === '' || self::word_count($plain) < 5 || self::sentence_has_transition_word($first_sentence)) {
                return (string) $match[0];
            }

            $transition = $transitions[$index % count($transitions)];
            $index++;
            $needed--;

            return '<p' . (string) ($match[1] ?? '') . '>' . esc_html($transition) . ', ' . self::lowercase_first_text_character(ltrim($inner)) . '</p>';
        }, $content) ?: $content;
    }

    private static function prepend_focus_sentence(string $paragraph_html, string $focus_keyphrase): string
    {
        $focus = self::sentence_focus_phrase($focus_keyphrase);
        $sentence = sprintf('This guide explains %s with practical details and clear takeaways.', esc_html($focus));

        return preg_replace('/(<p\b[^>]*>)/i', '$1' . $sentence . ' ', $paragraph_html, 1) ?: $paragraph_html;
    }

    private static function normalize_intro_paragraph(string $paragraph_html): string
    {
        $paragraph_html = trim($paragraph_html);
        if (preg_match('/^<p\b/i', $paragraph_html)) {
            return $paragraph_html;
        }

        return '<p>' . wp_kses_post($paragraph_html) . '</p>';
    }

    private static function get_paragraphs(string $content): array
    {
        if (!preg_match_all('/<p\b[^>]*>.*?<\/p>/is', $content, $matches, PREG_OFFSET_CAPTURE)) {
            return [];
        }

        $paragraphs = [];
        foreach ($matches[0] as $match) {
            $html = (string) ($match[0] ?? '');
            $paragraphs[] = [
                'full' => $html,
                'html' => $html,
                'offset' => (int) ($match[1] ?? 0),
            ];
        }

        return $paragraphs;
    }

    private static function get_headings(string $content): array
    {
        if (!preg_match_all('/<h([23])\b[^>]*>(.*?)<\/h[23]>/is', $content, $matches, PREG_OFFSET_CAPTURE | PREG_SET_ORDER)) {
            return [];
        }

        $headings = [];
        foreach ($matches as $match) {
            $full = (string) ($match[0][0] ?? '');
            $headings[] = [
                'full' => $full,
                'level' => absint($match[1][0] ?? 2),
                'inner' => (string) ($match[2][0] ?? ''),
                'offset' => (int) ($match[0][1] ?? 0),
            ];
        }

        return $headings;
    }

    private static function apply_replacements(string $content, array $replacements): string
    {
        if (empty($replacements)) {
            return $content;
        }

        krsort($replacements);
        foreach ($replacements as $offset => $replacement) {
            $content = substr_replace($content, (string) $replacement['html'], (int) $offset, (int) $replacement['length']);
        }

        return $content;
    }

    private static function is_utility_heading(string $heading): bool
    {
        return (bool) preg_match('/^(?:best for|highlights?|key takeaways?|pros and cons|what makes it appealing)\s*:?\s*$/i', trim($heading));
    }

    private static function add_keyphrase_to_heading_text(string $heading, string $focus_title): string
    {
        $heading = trim($heading);
        if ($heading === '') {
            return $focus_title;
        }

        if (strpos($heading, ':') !== false) {
            $parts = explode(':', $heading, 2);
            $before = trim((string) ($parts[0] ?? ''));
            $after = trim((string) ($parts[1] ?? ''));
            if ($before !== '' && $after !== '') {
                return $before . ' ' . $focus_title . ': ' . $after;
            }
        }

        return $focus_title . ' and ' . lcfirst($heading);
    }

    private static function starts_with_same_intro(string $content, string $intro_html): bool
    {
        return strncmp(ltrim($content), $intro_html, strlen($intro_html)) === 0;
    }

    private static function contains_phrase(string $html, string $phrase): bool
    {
        $text = self::normalized_text(wp_strip_all_tags($html));
        $phrase = self::normalized_text($phrase);

        return $text !== '' && $phrase !== '' && strpos($text, $phrase) !== false;
    }

    private static function word_count(string $html): int
    {
        $text = trim(wp_strip_all_tags($html));
        if ($text === '') {
            return 0;
        }

        if (preg_match_all('/[\p{L}\p{N}][\p{L}\p{N}\'-]*/u', $text, $matches)) {
            return count($matches[0]);
        }

        return str_word_count($text);
    }

    private static function get_sentences(string $html): array
    {
        $prepared = preg_replace('/<br\s*\/?>/i', '. ', $html);
        $prepared = preg_replace('/<\/(p|li|h[1-6]|blockquote|td|th)>/i', '. ', (string) $prepared);
        $text = trim(wp_strip_all_tags((string) $prepared));
        if ($text === '') {
            return [];
        }

        $parts = preg_split('/(?<=[.!?])\s+/u', $text) ?: [];
        $sentences = [];
        foreach ($parts as $part) {
            $sentence = trim((string) $part, " \t\n\r\0\x0B.?!;:");
            if ($sentence !== '' && self::word_count($sentence) > 0) {
                $sentences[] = $sentence;
            }
        }

        return $sentences;
    }

    private static function transition_percentage(array $sentences): float
    {
        return (self::transition_sentence_count($sentences) / max(1, count($sentences))) * 100;
    }

    private static function transition_sentence_count(array $sentences): int
    {
        $count = 0;
        foreach ($sentences as $sentence) {
            if (self::sentence_has_transition_word((string) $sentence)) {
                $count++;
            }
        }

        return $count;
    }

    private static function sentence_has_transition_word(string $sentence): bool
    {
        $sentence = self::normalized_text(wp_strip_all_tags($sentence));
        foreach (self::transition_words() as $phrase) {
            $phrase = self::normalized_text($phrase);
            $phrase_pattern = preg_replace('/\s+/', '\\s+', preg_quote($phrase, '/'));
            if ($phrase_pattern && preg_match('/(?<![\p{L}\p{N}])' . $phrase_pattern . '(?![\p{L}\p{N}])/u', $sentence)) {
                return true;
            }
        }

        return false;
    }

    private static function first_sentence(string $text): string
    {
        $parts = preg_split('/(?<=[.!?])\s+/u', trim($text), 2) ?: [];
        return trim((string) ($parts[0] ?? $text));
    }

    private static function lowercase_first_text_character(string $html): string
    {
        return preg_replace_callback('/^((?:\s|<[^>]+>)*)(The|A|An|This|That|These|Those|It|Its|They|Their)\b/u', static function (array $match): string {
            return (string) ($match[1] ?? '') . strtolower((string) ($match[2] ?? ''));
        }, $html, 1) ?: $html;
    }

    private static function transition_words(): array
    {
        return [
            'above all', 'accordingly', 'additionally', 'after all', 'also', 'although',
            'as a result', 'because', 'besides', 'but', 'consequently', 'despite',
            'especially', 'finally', 'first', 'for example', 'for instance',
            'furthermore', 'however', 'in addition', 'in conclusion', 'in contrast',
            'in fact', 'in particular', 'instead', 'likewise', 'meanwhile', 'moreover',
            'nevertheless', 'next', 'nonetheless', 'notably', 'on the other hand',
            'otherwise', 'overall', 'second', 'similarly', 'since', 'so', 'specifically',
            'still', 'therefore', 'though', 'thus', 'ultimately', 'whereas', 'while',
        ];
    }

    private static function normalized_text(string $text): string
    {
        $text = function_exists('remove_accents') ? remove_accents($text) : $text;
        $text = function_exists('mb_strtolower') ? mb_strtolower($text, 'UTF-8') : strtolower($text);
        return preg_replace('/\s+/u', ' ', trim((string) $text));
    }

    private static function sentence_focus_phrase(string $phrase): string
    {
        $phrase = trim(preg_replace('/\s+/', ' ', $phrase));
        if ($phrase === '') {
            return '';
        }

        return self::word_count($phrase) <= 1
            ? strtolower($phrase)
            : self::title_case_phrase($phrase);
    }
}
