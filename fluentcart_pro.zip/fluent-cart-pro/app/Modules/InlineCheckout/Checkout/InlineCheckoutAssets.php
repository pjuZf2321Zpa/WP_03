<?php

namespace FluentCartPro\App\Modules\InlineCheckout\Checkout;

use FluentCart\App\Models\Cart;
use FluentCart\Framework\Support\Arr;
use FluentCartPro\App\Modules\InlineCheckout\Cart\InlineCartService;
use FluentCartPro\App\Utils\Enqueuer\Vite;

/**
 * The selector's own stylesheet, script and localized vars.
 *
 * Only the selector layer lives here. Core already enqueues the checkout bundle
 * — it calls loadCheckoutAssets() with the cart this module returned from
 * `fluent_cart/checkout/render_cart`, immediately after that filter — so
 * re-declaring checkout.scss or FluentCartCheckout.js would be a second copy of
 * something already on the page.
 *
 * The vars ride core's existing `fluent_cart/checkout/localize_data` filter
 * rather than a hook of their own.
 */
class InlineCheckoutAssets
{
    /**
     * The selector config for the render in progress, stashed by
     * CheckoutSurface so the localize filter — which fires later, inside core's
     * asset loader — can see what the surface resolved.
     *
     * @var array|null
     */
    protected static $pendingConfig = null;

    /**
     * @param Cart $cart
     * @param array $config
     * @return void
     */
    public static function load($cart, array $config): void
    {
        if (!$cart) {
            return;
        }

        static::$pendingConfig = $config;

        static $enqueued = false;
        if ($enqueued) {
            return;
        }
        $enqueued = true;

        Vite::enqueueStyle(
            'fct-inline-checkout',
            'public/inline-checkout/style/inline-checkout.scss'
        );

        Vite::enqueueStyle(
            'fct-inline-checkout-items',
            'public/inline-checkout/style/inline-checkout-items.scss'
        );

        // Depends on core's two handles: `fluent-cart-app` (AssetLoader.php,
        // registered as "<slug>-app") and `fct-checkout`. WordPress does not
        // care which plugin registered a handle, only that it is registered
        // before this call — and it is, because core's loader runs immediately
        // after the filter that brought us here.
        //
        // Footer, matching fct-checkout: a head-group script would make
        // WordPress hoist the whole checkout bundle into <head> to satisfy the
        // dependency.
        Vite::enqueueScript(
            'fct-inline-checkout',
            'public/inline-checkout/inline-checkout.js',
            ['fluent-cart-app', 'fct-checkout'],
            FLUENTCART_PRO_PLUGIN_VERSION,
            true
        );
    }

    /**
     * Add the selector's vars to core's checkout payload.
     *
     * @param array $data
     * @param Cart|null $cart
     * @return array
     */
    public static function localize($data, $cart)
    {
        $config = static::$pendingConfig;

        if (!$config || !$cart || !isset($data['fluentcart_checkout_vars'])) {
            return $data;
        }

        $data['fluentcart_checkout_vars'] = array_merge(
            $data['fluentcart_checkout_vars'],
            static::vars($cart, $config)
        );

        $buttonText = trim((string)Arr::get($config, 'button_text', ''));
        if ($buttonText !== '') {
            $data['fluentcart_checkout_vars']['submit_button'] = ['text' => $buttonText];
        }

        return $data;
    }

    /**
     * @param Cart $cart
     * @param array $config
     * @return array
     */
    protected static function vars(Cart $cart, array $config): array
    {
        // Treated as not-yet-materialized so the client re-materializes on load
        // and persists the pruning before any request carries this hash.
        $isSynced = $cart->exists && !InlineCartService::needsResync($cart);

        return [
            'is_inline_checkout' => 'yes',

            // Whether a usable cart row already exists, independent of whether
            // its hash is safe to publish. Anything gating on the hash — the
            // deferred gateway load, for one — would otherwise wait forever on
            // a cart that exists but publishes no hash.
            'inline_cart_ready'  => $isSynced ? 'yes' : 'no',

            // Empty until the cart is materialized on first purchase intent;
            // the client stores the hash the materialize call returns. Only a
            // group core's hash lookup can resolve is published — handing out a
            // hash that resolves to nothing locks the shopper out of checkout.
            'cart_hash'          => ($isSynced && InlineCartService::isSelectorCart($cart))
                ? $cart->cart_hash
                : '',

            // The full set of variation ids the surface OFFERS — not the ones
            // currently selected. The distinction is load-bearing: the cart
            // holds only the selection, so deriving this from cart_data hands
            // the client a single id, the server rebuilds the option list from
            // it, and the list collapses to one row on the first selection
            // change — stranding the shopper with no way back to the others.
            'inline_variation_ids'   => static::offeredVariationIds($cart, $config),

            // The cart's identity. Echoed back on every inline request so the
            // server keys the row to this page even though no post is in scope
            // during an AJAX call.
            'inline_page_id'         => (int)Arr::get($config, 'page_id', 0),
            'inline_selector_label'  => (string)Arr::get($config, 'selector_label', ''),
            'inline_max_items'       => (int)Arr::get($config, 'max_items', 0),
            'inline_empty_selection_message' => __('Please select at least one item to continue.', 'fluent-cart'),
            'inline_messages'        => [
                'no_item_selected'        => __('No purchasable item is selected.', 'fluent-cart-pro'),
                /* translators: %1$s: HTTP status code */
                'selection_failed_status' => __('Could not update your selection (%1$s)', 'fluent-cart-pro'),
                /* translators: %1$s: HTTP status code */
                'prepare_failed_status'   => __('Could not prepare checkout (%1$s)', 'fluent-cart-pro'),
                'prepare_incomplete'      => __('Checkout could not be prepared. Please reload and try again.', 'fluent-cart-pro'),
                'prepare_failed'          => __('We could not prepare your checkout. Please try again.', 'fluent-cart-pro'),
            ],
            'inline_materialize_url' => admin_url(
                'admin-ajax.php?action=fluent_cart_checkout_routes'
                . '&fc_checkout_action=inline_materialize_cart'
            ),
        ];
    }

    /**
     * @param Cart $cart
     * @param array $config
     * @return int[]
     */
    protected static function offeredVariationIds(Cart $cart, array $config): array
    {
        $ids = array_values(array_filter(array_map('intval', Arr::get($config, 'variant_ids', []))));

        if ($ids) {
            return $ids;
        }

        // Fallback for a materialized cart being re-rendered without surface
        // config in scope. The server re-resolves and re-gates every id on
        // receipt, so this is a convenience and never trusted input.
        foreach ((array)$cart->cart_data as $cartItem) {
            if (!is_array($cartItem)) {
                continue;
            }
            $objectId = (int)Arr::get($cartItem, 'object_id', 0);
            if ($objectId > 0) {
                $ids[] = $objectId;
            }
        }

        return $ids;
    }
}
