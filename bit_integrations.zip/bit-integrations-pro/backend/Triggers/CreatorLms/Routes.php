<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Core\Util\Route;
use BitApps\IntegrationsPro\Triggers\CreatorLms\CreatorLmsController;

Route::get('creator-lms/get', [CreatorLmsController::class, 'getAllEvents']);
