<?php

namespace MasterStudy\Lms\Pro\addons\certificate_builder\Http\Serializers;

use MasterStudy\Lms\Http\Serializers\AbstractSerializer;

final class CertificateAdminSerializer extends AbstractSerializer {
	/**
	 * @param \WP_Post $certificate
	 */
	public function toArray( $certificate ): array {
		$preview_url = get_post_meta( $certificate->ID, 'certificate_preview', true );

		if ( empty( $preview_url ) ) {
			$preview_url = STM_LMS_URL . 'assets/img/pro-features/certifiacate_placeholder.png';
		}

		return array(
			'id'          => (int) $certificate->ID,
			'title'       => (string) $certificate->post_title,
			'instructor'  => get_the_author_meta( 'display_name', (int) $certificate->post_author ),
			'preview_url' => esc_url_raw( $preview_url ),
			'edit_url'    => admin_url( 'post.php?post=' . absint( $certificate->ID ) . '&action=edit' ),
		);
	}
}
