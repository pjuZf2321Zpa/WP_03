<?php

namespace BitApps\IntegrationsPro\Actions\WCAffiliate;

class WCAffiliateProHelper
{
    private const AFFILIATE_MODEL_CLASS = '\\WC_Affiliate\\Models\\Affiliate';

    private const REFERRAL_MODEL_CLASS = '\\WC_Affiliate\\Models\\Referral';

    private const TRANSACTION_MODEL_CLASS = '\\WC_Affiliate\\Models\\Transaction';

    private const AFFILIATE_STATUSES = ['pending', 'active', 'rejected', 'suspended'];

    private const COMMISSION_TYPES = ['default', 'fixed', 'percent'];

    private const REFERRAL_STATUSES = ['pending', 'approved', 'paid', 'rejected', 'cancelled'];

    private const REFERRAL_TYPES = ['sale'];

    private const TRANSACTION_STATUSES = ['pending', 'processing', 'completed', 'failed', 'cancelled'];

    private const TRANSACTION_PAYMENT_METHODS = ['manual'];

    public static function createAffiliate($defaultResponse, $fieldData)
    {
        if (!self::isPluginActive()) {
            return self::errorResponse(__('WC Affiliate is not installed or activated', 'bit-integrations-pro'));
        }

        $affiliateModelClass = self::getAffiliateModelClass();

        $userId = absint($fieldData['user_id'] ?? 0);
        $status = $fieldData['status'] ?? '';
        $commissionType = $fieldData['commission_type'] ?? '';

        if (empty($userId) || empty($status) || empty($commissionType)) {
            return self::errorResponse(__('User ID, status and commission type are required', 'bit-integrations-pro'));
        }

        if (!\in_array($status, self::AFFILIATE_STATUSES, true)) {
            return self::errorResponse(__('Invalid affiliate status', 'bit-integrations-pro'));
        }

        if (!\in_array($commissionType, self::COMMISSION_TYPES, true)) {
            return self::errorResponse(__('Invalid commission type', 'bit-integrations-pro'));
        }

        if (!get_userdata($userId)) {
            return self::errorResponse(__('User not found', 'bit-integrations-pro'));
        }

        $createData = [
            'user_id'         => $userId,
            'status'          => $status,
            'commission_type' => $commissionType,
        ];

        if (isset($fieldData['commission_amount']) && $fieldData['commission_amount'] !== '') {
            $createData['commission_amount'] = (float) $fieldData['commission_amount'];
        }

        $result = (new $affiliateModelClass())->create($createData);

        if (is_wp_error($result)) {
            return self::errorResponse($result->get_error_message());
        }

        return self::successResponse(
            __('Affiliate created successfully', 'bit-integrations-pro'),
            ['affiliate' => self::prepareResponse($result)]
        );
    }

    public static function updateAffiliateStatus($defaultResponse, $fieldData)
    {
        if (!self::isPluginActive()) {
            return self::errorResponse(__('WC Affiliate is not installed or activated', 'bit-integrations-pro'));
        }

        $affiliateModelClass = self::getAffiliateModelClass();

        $affiliateId = absint($fieldData['affiliate_id'] ?? 0);
        $status = $fieldData['status'] ?? '';
        $adminMessage = $fieldData['admin_message'] ?? '';

        if (empty($affiliateId) || empty($status)) {
            return self::errorResponse(__('Affiliate ID and status are required', 'bit-integrations-pro'));
        }

        if (!\in_array($status, self::AFFILIATE_STATUSES, true)) {
            return self::errorResponse(__('Invalid affiliate status', 'bit-integrations-pro'));
        }

        $affiliate = new $affiliateModelClass($affiliateId);

        if (!$affiliate->exists()) {
            return self::errorResponse(__('Affiliate not found', 'bit-integrations-pro'));
        }

        $result = $affiliate->update_status($status, $adminMessage);

        if (is_wp_error($result)) {
            return self::errorResponse($result->get_error_message());
        }

        return self::successResponse(
            __('Affiliate status updated successfully', 'bit-integrations-pro'),
            ['affiliate' => self::prepareResponse(new $affiliateModelClass($affiliateId))]
        );
    }

    public static function createReferral($defaultResponse, $fieldData)
    {
        if (!self::isPluginActive()) {
            return self::errorResponse(__('WC Affiliate is not installed or activated', 'bit-integrations-pro'));
        }

        $referralModelClass = self::getReferralModelClass();

        $affiliateId = absint($fieldData['affiliate_id'] ?? 0);
        $hasCommission = \array_key_exists('commission', $fieldData) && $fieldData['commission'] !== '';
        $hasOrderTotal = \array_key_exists('order_total', $fieldData) && $fieldData['order_total'] !== '';

        $commission = $hasCommission ? (float) $fieldData['commission'] : null;
        $orderTotal = $hasOrderTotal ? (float) $fieldData['order_total'] : null;

        $type = $fieldData['type'] ?? '';
        $paymentStatus = $fieldData['payment_status'] ?? '';

        if ($affiliateId < 1 || !$hasCommission || !$hasOrderTotal || empty($type) || empty($paymentStatus)) {
            return self::errorResponse(__('Affiliate ID, commission, order total, type and payment status are required', 'bit-integrations-pro'));
        }

        if (!\in_array($type, self::REFERRAL_TYPES, true)) {
            return self::errorResponse(__('Invalid referral type', 'bit-integrations-pro'));
        }

        if (!\in_array($paymentStatus, self::REFERRAL_STATUSES, true)) {
            return self::errorResponse(__('Invalid referral payment status', 'bit-integrations-pro'));
        }

        $createData = [
            'affiliate_id'   => $affiliateId,
            'commission'     => $commission,
            'order_total'    => $orderTotal,
            'type'           => $type,
            'payment_status' => $paymentStatus,
        ];

        foreach (['order_id', 'visit', 'transaction_id', 'time'] as $optionalIntField) {
            if (isset($fieldData[$optionalIntField]) && $fieldData[$optionalIntField] !== '') {
                $createData[$optionalIntField] = absint($fieldData[$optionalIntField]);
            }
        }

        if (!empty($fieldData['products'])) {
            $parsedProducts = self::parseProducts($fieldData['products']);

            if (!empty($parsedProducts)) {
                $createData['products'] = $parsedProducts;
            }
        }

        $result = (new $referralModelClass())->create($createData);

        if (is_wp_error($result)) {
            return self::errorResponse($result->get_error_message());
        }

        return self::successResponse(
            __('Referral created successfully', 'bit-integrations-pro'),
            ['referral' => self::prepareResponse($result)]
        );
    }

    public static function updateReferralStatus($defaultResponse, $fieldData)
    {
        if (!self::isPluginActive()) {
            return self::errorResponse(__('WC Affiliate is not installed or activated', 'bit-integrations-pro'));
        }

        $referralModelClass = self::getReferralModelClass();

        $referralId = absint($fieldData['referral_id'] ?? 0);
        $status = $fieldData['status'] ?? '';

        if (empty($referralId) || empty($status)) {
            return self::errorResponse(__('Referral ID and status are required', 'bit-integrations-pro'));
        }

        if (!\in_array($status, self::REFERRAL_STATUSES, true)) {
            return self::errorResponse(__('Invalid referral status', 'bit-integrations-pro'));
        }

        $referral = new $referralModelClass($referralId);

        if (!$referral->exists()) {
            return self::errorResponse(__('Referral not found', 'bit-integrations-pro'));
        }

        $result = $referral->update_status($status);

        if (is_wp_error($result)) {
            return self::errorResponse($result->get_error_message());
        }

        return self::successResponse(
            __('Referral status updated successfully', 'bit-integrations-pro'),
            ['referral' => self::prepareResponse(new $referralModelClass($referralId))]
        );
    }

    public static function createTransaction($defaultResponse, $fieldData)
    {
        if (!self::isPluginActive()) {
            return self::errorResponse(__('WC Affiliate is not installed or activated', 'bit-integrations-pro'));
        }

        $transactionModelClass = self::getTransactionModelClass();

        $affiliateId = absint($fieldData['affiliate_id'] ?? 0);
        $hasAmount = \array_key_exists('amount', $fieldData) && $fieldData['amount'] !== '';
        $amount = $hasAmount ? (float) $fieldData['amount'] : null;

        $paymentMethod = $fieldData['payment_method'] ?? '';
        $status = $fieldData['status'] ?? '';

        if ($affiliateId < 1 || !$hasAmount || empty($paymentMethod) || empty($status)) {
            return self::errorResponse(__('Affiliate ID, amount, payment method and status are required', 'bit-integrations-pro'));
        }

        if (!\in_array($paymentMethod, self::TRANSACTION_PAYMENT_METHODS, true)) {
            return self::errorResponse(__('Invalid transaction payment method', 'bit-integrations-pro'));
        }

        if (!\in_array($status, self::TRANSACTION_STATUSES, true)) {
            return self::errorResponse(__('Invalid transaction status', 'bit-integrations-pro'));
        }

        $createData = [
            'affiliate'      => $affiliateId,
            'amount'         => $amount,
            'payment_method' => $paymentMethod,
            'status'         => $status,
            'txn_id'         => $fieldData['txn_id'] ?? '',
            'notes'          => $fieldData['notes'] ?? '',
        ];

        $result = (new $transactionModelClass())->create($createData);

        if (is_wp_error($result)) {
            return self::errorResponse($result->get_error_message());
        }

        return self::successResponse(
            __('Transaction created successfully', 'bit-integrations-pro'),
            ['transaction' => self::prepareResponse($result)]
        );
    }

    public static function updateTransactionStatus($defaultResponse, $fieldData)
    {
        if (!self::isPluginActive()) {
            return self::errorResponse(__('WC Affiliate is not installed or activated', 'bit-integrations-pro'));
        }

        $transactionModelClass = self::getTransactionModelClass();

        $transactionId = absint($fieldData['transaction_id'] ?? 0);
        $status = $fieldData['status'] ?? '';
        $txnId = $fieldData['txn_id'] ?? '';

        if (empty($transactionId) || empty($status)) {
            return self::errorResponse(__('Transaction ID and status are required', 'bit-integrations-pro'));
        }

        if (!\in_array($status, self::TRANSACTION_STATUSES, true)) {
            return self::errorResponse(__('Invalid transaction status', 'bit-integrations-pro'));
        }

        $transaction = new $transactionModelClass($transactionId);

        if (!$transaction->exists()) {
            return self::errorResponse(__('Transaction not found', 'bit-integrations-pro'));
        }

        $result = $transaction->update_status($status, $txnId);

        if (is_wp_error($result)) {
            return self::errorResponse($result->get_error_message());
        }

        return self::successResponse(
            __('Transaction status updated successfully', 'bit-integrations-pro'),
            ['transaction' => self::prepareResponse(new $transactionModelClass($transactionId))]
        );
    }

    private static function isPluginActive()
    {
        return self::classExists(self::AFFILIATE_MODEL_CLASS)
            && self::classExists(self::REFERRAL_MODEL_CLASS)
            && self::classExists(self::TRANSACTION_MODEL_CLASS);
    }

    private static function getAffiliateModelClass()
    {
        return self::AFFILIATE_MODEL_CLASS;
    }

    private static function getReferralModelClass()
    {
        return self::REFERRAL_MODEL_CLASS;
    }

    private static function getTransactionModelClass()
    {
        return self::TRANSACTION_MODEL_CLASS;
    }

    private static function classExists($className)
    {
        return \is_string($className) && $className !== '' && class_exists($className);
    }

    private static function parseProducts($products)
    {
        if (\is_array($products)) {
            return $products;
        }

        if (!\is_string($products) || trim($products) === '') {
            return [];
        }

        $decoded = json_decode($products, true);

        if (\is_array($decoded)) {
            return $decoded;
        }

        return array_values(array_filter(array_map('trim', explode(',', $products))));
    }

    private static function prepareResponse($response)
    {
        return \is_object($response) && \is_callable([$response, 'get_data']) ? $response->get_data() : $response;
    }

    private static function successResponse($message, $data = [])
    {
        return [
            'success' => true,
            'message' => __($message, 'bit-integrations-pro'),
            'data'    => $data
        ];
    }

    private static function errorResponse($message)
    {
        return [
            'success' => false,
            'message' => __($message, 'bit-integrations-pro')
        ];
    }
}
