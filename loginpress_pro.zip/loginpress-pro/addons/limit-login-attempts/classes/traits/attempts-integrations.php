<?php //phpcs:ignore
/**
 * Prevent direct access.
 *
 * @package LoginPress
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * LoginPress Limit Login Attempts Trait One.
 *
 * Handles Some helping functions from class-attempts file one.
 *
 * @package   LoginPress
 * @subpackage Traits\LimitLogin
 * @since 6.2.0
 * @version 6.2.0
 */

if ( ! trait_exists( 'LoginPress_LimitLogin_Attempts_Integrations_Trait' ) ) {
	/**
	 * LoginPress Limit Login Attempts Trait One.
	 *
	 * @package   LoginPress
	 * @subpackage Traits\LimitLogin
	 * @since 6.2.0
	 * @version 6.2.0
	 */
	trait LoginPress_LimitLogin_Attempts_Integrations_Trait {

		/**
		 * Replaces the EDD login block with the blacklisted error content.
		 *
		 * @param string $block_content The original block content.
		 * @param array  $block         The block being rendered.
		 * @return string Modified block content.
		 * @since 5.0.0
		 * @version 6.2.0
		 */
		public function loginpress_edd_blacklist_error_block( $block_content, $block ) {
			if ( isset( $block['blockName'] ) && 'edd/login' === $block['blockName'] ) {
				return $this->loginpress_edd_blacklisted_error( array() );
			}
			return $block_content;
		}

		/**
		 * Replaces the EDD login block with the login attempt error content.
		 *
		 * @param string $block_content The original block content.
		 * @param array  $block         The block being rendered.
		 * @return string Modified block content.
		 * @since 5.0.0
		 * @version 6.2.0
		 */
		public function loginpress_edd_attempt_error_block( $block_content, $block ) {
			if ( isset( $block['blockName'] ) && 'edd/login' === $block['blockName'] ) {
				return $this->loginpress_edd_attempt_error();
			}
			return $block_content;
		}

		/**
		 * Outputs EDD blacklisted error message (block or shortcode context).
		 *
		 * @since 5.0.0
		 * @version 6.2.0
		 * @return void
		 */
		public function loginpress_edd_blacklisted_error() {
			$blacklist_message = isset( $this->attempts_settings['blacklist_message'] ) && ! empty( $this->attempts_settings['blacklist_message'] ) ? sanitize_text_field( $this->attempts_settings['blacklist_message'] ) : __( 'You are not allowed to access admin panel', 'loginpress-pro' );
			echo '<div class="edd-alert-error">';
			echo esc_html( $blacklist_message );// @codingStandardsIgnoreLine.
			echo '</div>';
		}

		/**
		 * Outputs EDD lockout error message using current IP's last attempt time.
		 *
		 * @since 5.0.0
		 * @version 6.2.0
		 * @return void
		 */
		public function loginpress_edd_attempt_error() {
			echo '<div class="edd-alert-error">';

			global $wpdb;
			$last_attempt_time = $wpdb->get_var( $wpdb->prepare( "SELECT `datentime` FROM `{$this->llla_table}` WHERE `ip` = %s ORDER BY `datentime` DESC", $this->ip ) ); // @codingStandardsIgnoreLine.
			echo wp_kses_post( $this->loginpress_lockout_error( $last_attempt_time ) );
			echo '</div>';
		}

		/**
		 * Outputs WooCommerce my-account blacklisted error message.
		 *
		 * @since 2.1.0
		 * @version 6.2.0
		 * @return void
		 */
		public function loginpress_woo_blacklist_error() {
			$blacklist_message = isset( $this->attempts_settings['blacklist_message'] ) && ! empty( $this->attempts_settings['blacklist_message'] ) ? sanitize_text_field( $this->attempts_settings['blacklist_message'] ) : __( 'You are not allowed to access admin panel', 'loginpress-pro' );
			?>
			<div class="woocommerce-error">
				<?php
				echo esc_html( $blacklist_message );// @codingStandardsIgnoreLine.
				?>
			</div>
			<?php
		}

		/**
		 * Outputs WooCommerce my-account lockout error message using current IP's last attempt time.
		 *
		 * @since 2.1.0
		 * @version 6.2.0
		 * @return void
		 */
		public function loginpress_woo_attempt_error() {

			echo '<div class="woocommerce-error">';

			global $wpdb;
			$last_attempt_time = $wpdb->get_var( $wpdb->prepare( "SELECT `datentime` FROM `{$this->llla_table}` WHERE `ip` = %s ORDER BY `datentime` DESC", $this->ip ) ); // @codingStandardsIgnoreLine.
			echo wp_kses_post( $this->loginpress_lockout_error( $last_attempt_time ) );
			echo '</div>';
		}

		/**
		 * Checks whether current IP has an active (normal or extended) lockout.
		 *
		 * @since 6.0.0
		 * @version 6.2.0
		 * @return array Keys: is_locked (bool), and when true optionally lockout_end (int), is_extended (bool).
		 */
		protected function loginpress_check_extended_lockout() {
			global $wpdb;

			$current_time = time(); // phpcs:ignore WordPress.DateTime.CurrentTimeTimestamp.Requested

			if ( ! isset( $this->attempts_settings['lockout_increase_after'] ) ) {
				return array( 'is_locked' => false );
			}

			// Sanitize and initialize settings.
			$lockout_increase_after = isset( $this->attempts_settings['lockout_increase_after'] )
				? intval( $this->attempts_settings['lockout_increase_after'] )
				: 4;

			$retry_reset_hours = isset( $this->attempts_settings['retry_reset'] )
				? intval( $this->attempts_settings['retry_reset'] )
				: 24;

			$extended_lockout_hours = isset( $this->attempts_settings['lockout_time_increase'] )
				? intval( $this->attempts_settings['lockout_time_increase'] )
				: 24;

			// Get last lockout time.
			// Table name is safe as it comes from $wpdb->prefix; esc_sql satisfies Plugin Check.
			$table_name = esc_sql( $this->llla_table );
			// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$last_lockout = $wpdb->get_row(
				$wpdb->prepare(
					"SELECT `datentime` 
					FROM `{$table_name}` 
					WHERE `ip` = %s 
						AND `login_status` = %s 
					ORDER BY `datentime` DESC 
					LIMIT 1",
					sanitize_text_field( $this->ip ),
					'Locked'
				)
			);
			// phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared

			if ( ! $last_lockout ) {
				return array( 'is_locked' => false );
			}

			$reset_period = $retry_reset_hours * HOUR_IN_SECONDS;
			$reset_time   = $current_time - $reset_period;

			// Count lockouts within reset period.
			// Table name is safe as it comes from $wpdb->prefix.
			// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$lockout_count = $wpdb->get_var(
				$wpdb->prepare(
					"SELECT COUNT(`id`) 
					FROM `{$table_name}` 
					WHERE `ip` = %s 
						AND `datentime` > %d 
						AND `login_status` = %s",
					sanitize_text_field( $this->ip ),
					$reset_time,
					'Locked'
				)
			);
			// phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared

			// Determine if this is an extended lockout.
			$is_extended = ( $lockout_count >= $lockout_increase_after );

			// Determine lockout duration (in seconds).
			$lockout_duration = $is_extended
				? ( $extended_lockout_hours * HOUR_IN_SECONDS )
				: (
					isset( $this->attempts_settings['minutes_lockout'] )
						? intval( $this->attempts_settings['minutes_lockout'] ) * MINUTE_IN_SECONDS
						: 1200 // default 20 minutes.
				);

			$lockout_end = intval( $last_lockout->datentime ) + $lockout_duration;

			// Check if still locked.
			if ( $current_time < $lockout_end ) {
				return array(
					'is_locked'   => true,
					'lockout_end' => $lockout_end,
					'is_extended' => $is_extended,
				);
			}

			return array( 'is_locked' => false );
		}
	}
}
