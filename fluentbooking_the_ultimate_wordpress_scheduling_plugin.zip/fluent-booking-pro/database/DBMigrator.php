<?php

namespace FluentBookingPro\Database;

use FluentBookingPro\Database\Migrations\OrdersItemsMigrator;
use FluentBookingPro\Database\Migrations\BookingOrdersMigrator;
use FluentBookingPro\Database\Migrations\BookingTransactionsMigrator;

class DBMigrator
{
    private static $migrators = [
        BookingOrdersMigrator::class,
        OrdersItemsMigrator::class,
        BookingTransactionsMigrator::class,
    ];

    /**
     * @param bool $network_wide
     * @return bool False when a migrator failed, so the caller holds the stored
     *              DB version back and the next request retries.
     */
    public static function run($network_wide = false)
    {
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');

        if (!is_multisite() || !$network_wide) {
            return static::migrate();
        }

        global $wpdb;

        $blogIds = $wpdb->get_col($wpdb->prepare("SELECT blog_id FROM {$wpdb->blogs} WHERE 1=%d", 1)); // phpcs:ignore WordPress.DB.DirectDatabaseQuery

        $success = true;

        foreach ($blogIds as $blogId) {
            switch_to_blog($blogId);

            try {
                $success = static::migrate() && $success;
            } finally {
                restore_current_blog();
            }
        }

        return $success;
    }

    private static function migrate()
    {
        $success = true;

        foreach (static::$migrators as $migrator) {
            // Tables are independent, so one failure does not stop the rest.
            $success = $migrator::migrate() !== false && $success;
        }

        return $success;
    }
}
