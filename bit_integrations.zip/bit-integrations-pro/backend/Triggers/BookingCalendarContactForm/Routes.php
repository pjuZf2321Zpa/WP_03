<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Core\Util\Route;
use BitApps\IntegrationsPro\Triggers\BookingCalendarContactForm\BookingCalendarContactFormController;

Route::get('booking-calendar-contact-form/get', [BookingCalendarContactFormController::class, 'getAllTasks']);
