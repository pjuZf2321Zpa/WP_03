<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Actions\NiroHelp\NiroHelpProHelper;
use BitApps\IntegrationsPro\Config;
use BitApps\IntegrationsPro\Core\Util\Hooks;

Hooks::filter(Config::withFreePrefix('niro_help_create_ticket'), [NiroHelpProHelper::class, 'createTicket'], 10, 3);
Hooks::filter(Config::withFreePrefix('niro_help_update_ticket'), [NiroHelpProHelper::class, 'updateTicket'], 10, 3);
Hooks::filter(Config::withFreePrefix('niro_help_change_ticket_status'), [NiroHelpProHelper::class, 'changeTicketStatus'], 10, 3);
Hooks::filter(Config::withFreePrefix('niro_help_assign_agent'), [NiroHelpProHelper::class, 'assignAgent'], 10, 3);
Hooks::filter(Config::withFreePrefix('niro_help_set_sentiment'), [NiroHelpProHelper::class, 'setSentiment'], 10, 3);
Hooks::filter(Config::withFreePrefix('niro_help_delete_ticket'), [NiroHelpProHelper::class, 'deleteTicket'], 10, 2);
Hooks::filter(Config::withFreePrefix('niro_help_add_reply'), [NiroHelpProHelper::class, 'addReply'], 10, 3);
Hooks::filter(Config::withFreePrefix('niro_help_add_private_note'), [NiroHelpProHelper::class, 'addPrivateNote'], 10, 3);
Hooks::filter(Config::withFreePrefix('niro_help_set_follow_up'), [NiroHelpProHelper::class, 'setFollowUp'], 10, 3);
Hooks::filter(Config::withFreePrefix('niro_help_clear_follow_up'), [NiroHelpProHelper::class, 'clearFollowUp'], 10, 2);
Hooks::filter(Config::withFreePrefix('niro_help_create_doc'), [NiroHelpProHelper::class, 'createDoc'], 10, 3);
Hooks::filter(Config::withFreePrefix('niro_help_update_doc'), [NiroHelpProHelper::class, 'updateDoc'], 10, 3);
Hooks::filter(Config::withFreePrefix('niro_help_trash_doc'), [NiroHelpProHelper::class, 'trashDoc'], 10, 2);
Hooks::filter(Config::withFreePrefix('niro_help_delete_doc'), [NiroHelpProHelper::class, 'deleteDoc'], 10, 2);
Hooks::filter(Config::withFreePrefix('niro_help_create_product'), [NiroHelpProHelper::class, 'createProduct'], 10, 2);
Hooks::filter(Config::withFreePrefix('niro_help_create_reason'), [NiroHelpProHelper::class, 'createReason'], 10, 2);
Hooks::filter(Config::withFreePrefix('niro_help_create_topic'), [NiroHelpProHelper::class, 'createTopic'], 10, 3);
Hooks::filter(Config::withFreePrefix('niro_help_create_customer'), [NiroHelpProHelper::class, 'createCustomer'], 10, 2);
Hooks::filter(Config::withFreePrefix('niro_help_add_agent'), [NiroHelpProHelper::class, 'addAgent'], 10, 2);
