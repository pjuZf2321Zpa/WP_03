<?php

/**
 * @var FluentBooking\Framework\Http\Router $router
 */

$router->prefix('calendars')->withPolicy(\FluentBooking\App\Http\Policies\CalendarPolicy::class)->group(function ($router) {
    $router->get('/{id}/events/{event_id}/event-available-slots', [\FluentBookingPro\App\Modules\SingleEvent\SingleEventController::class, 'getEventAvailableSlots'])->int('id')->int('event_id');
    $router->post('/{id}/events/{event_id}/event-availability', [\FluentBookingPro\App\Modules\SingleEvent\SingleEventController::class, 'updateEventAvailability'])->int('id')->int('event_id');
});
