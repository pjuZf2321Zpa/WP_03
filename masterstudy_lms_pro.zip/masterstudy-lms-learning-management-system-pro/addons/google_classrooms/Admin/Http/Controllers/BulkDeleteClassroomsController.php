<?php

namespace MasterStudy\Lms\Pro\addons\google_classrooms\Admin\Http\Controllers;

use MasterStudy\Lms\Http\WpResponseFactory;
use MasterStudy\Lms\Pro\addons\google_classrooms\Admin\Repositories\ClassroomsRepository;
use MasterStudy\Lms\Validation\Validator;
use WP_REST_Request;
use WP_REST_Response;

final class BulkDeleteClassroomsController {
	private const MAX_BULK_ITEMS = 100;

	public function __invoke( WP_REST_Request $request ): WP_REST_Response {
		$validator = new Validator(
			$request->get_params(),
			array(
				'items' => 'required|array',
			)
		);

		if ( $validator->fails() ) {
			return WpResponseFactory::validation_failed( $validator->get_errors_array() );
		}

		$items = (array) $validator->get_validated()['items'];

		if ( count( $items ) > self::MAX_BULK_ITEMS ) {
			return WpResponseFactory::bad_request(
				sprintf(
					/* translators: %d: maximum number of items allowed in one bulk request. */
					esc_html__( 'Too many items in one request. Maximum allowed is %d.', 'masterstudy-lms-learning-management-system-pro' ),
					self::MAX_BULK_ITEMS
				)
			);
		}

		try {
			( new ClassroomsRepository() )->bulk_delete( $items );
		} catch ( \RuntimeException $e ) {
			if ( 403 === $e->getCode() ) {
				return WpResponseFactory::forbidden();
			}

			if ( 400 === $e->getCode() ) {
				return WpResponseFactory::bad_request( $e->getMessage() );
			}

			return WpResponseFactory::error( $e->getMessage() );
		}

		return WpResponseFactory::ok_with_data(
			array(
				'success' => true,
			)
		);
	}
}
