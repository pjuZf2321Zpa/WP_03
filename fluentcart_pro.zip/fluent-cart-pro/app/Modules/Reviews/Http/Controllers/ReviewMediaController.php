<?php

namespace FluentCartPro\App\Modules\Reviews\Http\Controllers;

use FluentCart\App\Models\Customer;
use FluentCart\Framework\Http\Controller;
use FluentCart\Framework\Http\Request\Request;
use FluentCart\App\Services\ProductReviewService;
use FluentCartPro\App\Modules\Reviews\Http\Controllers\Concerns\RateLimitsTrait;
use FluentCartPro\App\Modules\Reviews\Services\ReviewMediaService;

class ReviewMediaController extends Controller
{
    use RateLimitsTrait;

    public function upload(Request $request, $postId)
    {
        // CSRF protection — verify WordPress REST nonce
        if (!wp_verify_nonce($request->get_header('X-WP-Nonce'), 'wp_rest')) {
            return $this->sendError([
                'message' => __('Session expired. Please refresh and try again.', 'fluent-cart-pro'),
            ], 403);
        }

        // Enforce same permission gate as review submission
        $settings = ProductReviewService::getReviewSettings();
        $permissionMode = $settings['review_permission_mode'] ?? 'verified_buyers';
        $currentUserId = get_current_user_id();

        if ($permissionMode === 'verified_buyers') {
            if (!$currentUserId) {
                return $this->sendError([
                    'message' => __('Please log in to upload review photos.', 'fluent-cart-pro'),
                ], 401);
            }
            $customer = Customer::query()->where('user_id', $currentUserId)->first();
            if (!$customer || !ProductReviewService::isVerifiedPurchase(intval($postId), $customer->id)) {
                return $this->sendError([
                    'message' => __('Only verified buyers can upload review photos.', 'fluent-cart-pro'),
                ], 403);
            }
        } elseif ($permissionMode === 'logged_in') {
            if (!$currentUserId) {
                return $this->sendError([
                    'message' => __('Please log in to upload review photos.', 'fluent-cart-pro'),
                ], 401);
            }
        }
        // 'anyone' mode allows all

        $postId = intval($postId);

        // Verify the product exists
        $product = get_post($postId);

        if (!$product || $product->post_status !== 'publish' || $product->post_type !== 'fluent-products') {
            return $this->sendError([
                'message' => __('Product not found', 'fluent-cart-pro'),
            ], 404);
        }

        if (empty($settings['enable_photo_reviews']) || $settings['enable_photo_reviews'] !== 'yes') {
            return $this->sendError([
                'message' => __('Photo reviews are not enabled', 'fluent-cart-pro'),
            ], 403);
        }

        // Reserve the first upload attempt before processing the request.
        $ipAddress = $this->getClientIp();
        $rateLimitKey = '';

        if (!$ipAddress && !$currentUserId) {
            return $this->sendError([
                'message' => __('Unable to verify identity.', 'fluent-cart-pro'),
            ], 400);
        }

        // User first, IP only as a guest fallback — matches
        // ReviewMediaService::buildBucketKey()'s ordering below. IP-first
        // would rate-limit a logged-in user by IP instead of account,
        // letting a VPN/proxy rotation reset their upload allowance.
        if ($currentUserId) {
            $rateLimitKey = 'fct_review_upload_user_' . $currentUserId;
        } elseif ($ipAddress) {
            $rateLimitKey = 'fct_review_upload_' . md5($ipAddress);
        }

        if ($rateLimitKey) {
            $currentCount = $this->atomicIncrement($rateLimitKey);

            if ($currentCount > 20) {
                return $this->sendError([
                    'message' => __('Too many uploads. Please try again later.', 'fluent-cart-pro'),
                ], 429);
            }
        }

        $maxPhotos = ReviewMediaService::getMaxPhotosPerReview();
        $maxImageSize = ReviewMediaService::getMaxPhotoSizeBytes();

        // Build a quota bucket scoped to this product + uploader identity
        $bucketKey = ReviewMediaService::buildBucketKey($postId, $currentUserId, $ipAddress);

        // Check how many pending uploads already exist for this bucket.
        // Note: this check is not perfectly atomic (TOCTOU) but is bounded by
        // the per-file re-check inside the upload loop and the hard array_slice cap.
        $existingCount = ReviewMediaService::getPendingMediaCount($bucketKey);
        if ($existingCount >= $maxPhotos) {
            return $this->sendError([
                'message' => __('Maximum number of photos already uploaded for this review.', 'fluent-cart-pro'),
            ], 400);
        }
        $remainingSlots = $maxPhotos - $existingCount;

        // WPFluent Request converts $_FILES into File objects
        $fileObjects = $request->files('files');

        if (empty($fileObjects)) {
            return $this->sendError([
                'message' => __('No files uploaded', 'fluent-cart-pro'),
            ], 400);
        }

        // Normalize single File object to array
        if (!is_array($fileObjects)) {
            $fileObjects = [$fileObjects];
        }

        // Limit batch size to remaining slots
        if (count($fileObjects) > $remainingSlots) {
            $fileObjects = array_slice($fileObjects, 0, $remainingSlots);
        }

        $uploaded = [];
        $imageCount = 0;
        $firstAttempt = true;

        foreach ($fileObjects as $fileObj) {
            if ($imageCount >= $remainingSlots) {
                continue;
            }

            // Re-check actual pending count to close TOCTOU gap from concurrent requests
            $currentPending = ReviewMediaService::getPendingMediaCount($bucketKey);
            if ($currentPending >= $maxPhotos) {
                break;
            }

            // The first attempt was reserved above. Reserve each additional
            // file before storage, including files that fail validation.
            if ( !$firstAttempt && $this->atomicIncrement( $rateLimitKey ) > 20 ) {
                break;
            }
            $firstAttempt = false;

            // Per-file validation (content-sniffed MIME, size) and storage live
            // in the service so this path and the admin add-review path cannot
            // drift apart. The quota above stays here — it is a shopper rule.
            $result = ReviewMediaService::storeUploadedFile(
                $fileObj,
                $postId,
                $bucketKey,
                ReviewMediaService::getAllowedPhotoTypes(),
                $maxImageSize
            );

            if ($result) {
                $imageCount++;
                $uploaded[] = $result;
            }
        }

        if (empty($uploaded)) {
            return $this->sendError([
                'message' => __('No valid files were uploaded', 'fluent-cart-pro'),
            ], 400);
        }

        return $this->sendSuccess([
            'media' => $uploaded,
        ]);
    }

}
