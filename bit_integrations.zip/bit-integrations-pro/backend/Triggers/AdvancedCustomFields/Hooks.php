<?php

if (!defined('ABSPATH')) {
    exit;
}
    
use BitApps\IntegrationsPro\Core\Util\Hooks;
use BitApps\IntegrationsPro\Triggers\AdvancedCustomFields\AdvancedCustomFieldsController;

Hooks::add('acf/save_post', [AdvancedCustomFieldsController::class, 'handleFieldUpdatedOnOptionsPage'], 10, 1);
Hooks::add('updated_post_meta', [AdvancedCustomFieldsController::class, 'handleFieldUpdatedOnPost'], 99, 4);
Hooks::add('updated_user_meta', [AdvancedCustomFieldsController::class, 'handleFieldUpdatedOnUserProfile'], 10, 4);
Hooks::add('added_user_meta', [AdvancedCustomFieldsController::class, 'handleFieldUpdatedOnUserProfile'], 10, 4);
