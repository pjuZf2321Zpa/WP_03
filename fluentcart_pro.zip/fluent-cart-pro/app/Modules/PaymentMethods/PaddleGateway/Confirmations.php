<?php

namespace FluentCartPro\App\Modules\PaymentMethods\PaddleGateway;

use FluentCartPro\App\Modules\PaymentMethods\PaddleGateway\API\API;
use FluentCart\App\Helpers\Status;
use FluentCart\App\Helpers\StatusHelper;
use FluentCart\App\Models\AppliedCoupon;
use FluentCart\App\Models\Order;
use FluentCart\App\Models\OrderTransaction;
use FluentCart\App\Models\Subscription;
use FluentCart\App\Modules\Subscriptions\Services\SubscriptionService;
use FluentCart\App\Services\DateTime\DateTime;
use FluentCart\Framework\Support\Arr;

class Confirmations
{
    public function init()
    {
        add_action('wp_ajax_nopriv_fluent_cart_confirm_paddle_payment', [$this, 'confirmPaddlePayment']);
        add_action('wp_ajax_fluent_cart_confirm_paddle_payment', [$this, 'confirmPaddlePayment']);
    }

    /**
     * Confirm Paddle payment after successful checkout
     */
    public function confirmPaddlePayment()
    {
        if (!isset($_REQUEST['nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_REQUEST['nonce'])), 'fluentcart')) {
            $this->failConfirmation(403);
        }

        if (!isset($_REQUEST['vendor_charge_id'])) {
            $this->failConfirmation(400);
        }

        $vendorChargeId = sanitize_text_field($_REQUEST['vendor_charge_id']);
        $transactionHash = sanitize_text_field($_REQUEST['fct_transaction_hash'] ?? '');
        $fctOrderHash = sanitize_text_field($_REQUEST['fct_order_hash'] ?? '');

        [$transactionModel, $order] = $this->resolveTransactionAndOrder(
            $vendorChargeId,
            $transactionHash,
            $fctOrderHash
        );

        if (!$transactionModel || !$order) {
            $this->failConfirmation(404);
        }

        if (!$this->isLocalBindingValid($transactionModel, $order, $vendorChargeId, $transactionHash, $fctOrderHash)) {
            $this->failConfirmation(403);
        }

        // Check if already processed
        if ($transactionModel->status === Status::TRANSACTION_SUCCEEDED) {
            if ($transactionModel->subscription_id) {
                $subscription = Subscription::query()->where('id', $transactionModel->subscription_id)->first();
                if ($subscription) {
                    $subscription->reSyncFromRemote();
                }
            }
            
            (new StatusHelper($order))->syncOrderStatuses($transactionModel);
            wp_send_json([
                'redirect_url' => $transactionModel->getReceiptPageUrl(),
                'order' => [
                    'uuid' => $transactionModel->order->uuid,
                ],
                'message' => __('Payment already confirmed. Redirecting...!', 'fluent-cart-pro'),
                'status' => 'success'
            ], 200);
        }

        // Get transaction details from Paddle
        $paddleTransaction = API::getPaddleObject("transactions/{$vendorChargeId}", [], $transactionModel->payment_mode);

        if (is_wp_error($paddleTransaction)) {
            wp_send_json([
                'message' => $paddleTransaction->get_error_message(),
                'status' => 'failed'
            ], 500);
        }

        $paddleTransaction = Arr::get($paddleTransaction, 'data');
        $transactionStatus = Arr::get($paddleTransaction, 'status');

        if (!$this->isPaddleBindingValid($transactionModel, $order, $paddleTransaction)) {
            $this->failConfirmation(403);
        }

        // Check if payment is completed
        if ($transactionStatus !== 'paid' && $transactionStatus !== 'completed') {
            wp_send_json([
                'message' => sprintf(__('Payment is not completed. Current status: %s', 'fluent-cart-pro'), $transactionStatus),
                'status' => 'failed'
            ], 400);
        }


        $this->confirmPaymentSuccessByCharge($transactionModel, [
            'vendor_charge_id' => $vendorChargeId,
            'charge'      => $paddleTransaction,
        ]);

        wp_send_json([
            'redirect_url' => $transactionModel->getReceiptPageUrl(),
            'order' => [
                'uuid' => $transactionModel->order->uuid,
            ],
            'message' => __('Payment confirmed successfully. Redirecting...!', 'fluent-cart-pro'),
            'status' => 'success'
        ], 200);
    }

    private function failConfirmation($status = 403)
    {
        wp_send_json([
            'message' => __('Confirmation failed.', 'fluent-cart-pro'),
            'status' => 'failed'
        ], $status);
    }

    private function resolveTransactionAndOrder($vendorChargeId, $transactionHash, $orderHash)
    {
        $transactionModel = null;

        if ($transactionHash) {
            $transactionModel = OrderTransaction::query()->where('uuid', $transactionHash)->first();
        }

        if (!$transactionModel) {
            $transactionModel = OrderTransaction::query()->where('vendor_charge_id', $vendorChargeId)->first();
        }

        if (!$transactionModel && $orderHash) {
            $order = Order::query()->where('uuid', $orderHash)->first();
            if ($order) {
                $transactionModel = $order->getLatestTransaction();
            }
        }

        $order = $transactionModel ? $transactionModel->order : null;

        return [$transactionModel, $order];
    }

    private function isLocalBindingValid(
        OrderTransaction $transaction,
        $order,
        $vendorChargeId,
        $transactionHash,
        $orderHash
    ) {
        if ($orderHash && $order->uuid !== $orderHash) {
            return false;
        }

        if ($transactionHash && $transaction->uuid !== $transactionHash) {
            return false;
        }

        if ($transaction->vendor_charge_id && $transaction->vendor_charge_id !== $vendorChargeId) {
            return false;
        }

        return true;
    }

    private function isPaddleBindingValid($transaction, $order, $paddleTransaction): bool
    {
        if (!PaddleHelper::isExpectedCheckoutTransaction($transaction, $order, Arr::get($paddleTransaction, 'id'))) {
            return false;
        }

        $customData = Arr::get($paddleTransaction, 'custom_data', []);
        $customOrderHash = Arr::get($customData, 'fct_order_hash');
        $customTransactionHash = Arr::get($customData, 'fct_transaction_hash');

        if ($customOrderHash && $customOrderHash !== $order->uuid) {
            return false;
        }

        if ($customTransactionHash && $customTransactionHash !== $transaction->uuid) {
            return false;
        }

        $hasCustomBinding = (bool) ($customOrderHash || $customTransactionHash);
        if (!$hasCustomBinding && empty($transaction->vendor_charge_id)) {
            return false;
        }

        return true;
    }

    /**
     * Confirm payment success and update transaction
     */
    public function confirmPaymentSuccessByCharge(OrderTransaction $transaction, $args = [])
    {
        $vendorChargeId = Arr::get($args, 'vendor_charge_id');
        $charge = Arr::get($args, 'charge');

        $payment     = Arr::get($charge, 'payments.0');
        $methodType  = Arr::get($payment, 'method_details.type');
        $billingInfo = [];

        if ($methodType == 'card') {
            $billingInfo  = [
                'type'   => 'card',
                'last4'  => Arr::get($payment, 'method_details.card.last4'),
                'brand'  => Arr::get($payment, 'method_details.card.type'),
                'expiry' => Arr::get($payment, 'method_details.card.expiry_month').'/'.Arr::get($payment, 'method_details.card.expiry_year'),
                'payment_method_id' => Arr::get($payment, 'payment_method_id'),
                'details' => [
                    'last_4'  => Arr::get($payment, 'method_details.card.last4'),
                    'brand'  => Arr::get($payment, 'method_details.card.type'),
                    'expiry' => Arr::get($payment, 'method_details.card.expiry_month').'/'.Arr::get($payment, 'method_details.card.expiry_year'),
                    'payment_method_id' => Arr::get($payment, 'payment_method_id'),
                ],
            ];
        } else {
            $billingInfo  = [
                'type' => $methodType,
                'payment_method_id' => Arr::get($payment, 'payment_method_id'),
                'details' => [
                    'payment_method_id' => Arr::get($payment, 'payment_method_id'),
                ],
            ];
        }

        $order = Order::query()->where('id', $transaction->order_id)->first();

        // Reload from DB to check current status and prevent duplicate confirmations
        // in race conditions between webhook and AJAX confirmation
        $transaction = OrderTransaction::query()->where('id', $transaction->id)->first();

        if ($transaction && $transaction->status === Status::TRANSACTION_SUCCEEDED) {
            $reconcile = PaddleReconciler::reconcile($transaction, $charge, $order);
            if ($reconcile['changed']) {
                $transaction->total    = (int) $reconcile['amount'];
                $transaction->currency = $reconcile['currency'];
                $transaction->meta     = array_merge($transaction->meta ?? [], $reconcile['meta']);
                $transaction->save();
                $order = Order::query()->where('id', $order->id)->first();
            }
            return (new StatusHelper($order))->syncOrderStatuses($transaction);
        }

        $details = Arr::get($charge, 'details');

        $meta = PaddleHelper::getTransactionMeta($charge, $order);

        $subscriptionModel = Subscription::query()->where('id', $transaction->subscription_id)->first();

        // A discount only counts as removed by the buyer when one was put on the
        // Paddle transaction and the charge came back without it. A discount that
        // is baked into the price itself (recurring coupon, simulated trial) never
        // reaches Paddle as a discount object, so the charge shows none by design.
        $expectedDiscountId = (string) Arr::get((array) ($transaction->meta ?? []), 'paddle_expected_discount_id', '');
        $paddleDiscountTotal = (int) Arr::get($details, 'totals.discount', 0);
        $orderDiscountTotal = $order->coupon_discount_total + $order->manual_discount_total;
        if ($expectedDiscountId !== '' && $orderDiscountTotal > 0 && $paddleDiscountTotal === 0) {
            $order->coupon_discount_total = 0;
            $order->manual_discount_total = 0;
            $orderConfig = $order->config;
            $orderConfig['prorate_credit'] = 0;
            $orderConfig['upgrade_discount'] = 0;
            $order->config = $orderConfig;
            $order->total_amount = $order->total_amount + $orderDiscountTotal;
            $order->save();

            // Remove applied coupon records for this order
            AppliedCoupon::query()->where('order_id', $order->id)->delete();

            // Update the local transaction total to match the recalculated order
            $transaction->total = $order->total_amount;
        }

        // Unified Merchant-of-Record reconciliation. Splits on currency first, then
        // verifies tax-excluded (over-pay) / reverse charge (under-pay) against the
        // charge's tax fields before touching anything. Returns the amount/currency to
        // record and any meta to merge; may record collected tax on the order itself.
        $reconcile = PaddleReconciler::reconcile($transaction, $charge, $order);

        if ($reconcile['changed']) {
            // Reconciliation may have recorded tax on the order — refresh for the status sync.
            $order = Order::query()->where('id', $order->id)->first();
        }

        $amount = (int) $reconcile['amount'];
        $meta   = array_merge($meta, $reconcile['meta']);

        // Paddle's billed_at is when the remote charge completed. When this
        // confirmation is the first path to mark the transaction succeeded, it
        // beats the model hook's fallback now() stamp — which for a delayed
        // webhook would be the (later) processing time, not the charge time.
        $billedAt = Arr::get($charge, 'billed_at');
        if ($billedAt && empty($transaction->meta['settled_at']) && empty($meta['settled_at'])) {
            $meta['settled_at'] = DateTime::anyTimeToGmt($billedAt)->format('Y-m-d H:i:s');
        }

        // total is outside the filter: an unverified cross-currency charge reconciles
        // to 0, and dropping that 0 would leave the checkout-time total on the row.
        $transactionUpdateData = array_filter([
            'order_id'            => $order->id,
            'currency'            => $reconcile['currency'],
            'status'              => Status::TRANSACTION_SUCCEEDED,
            'payment_method'      => 'paddle',
            'card_last_4'         => Arr::get($billingInfo, 'last4', ''),
            'card_brand'          => Arr::get($billingInfo, 'brand', ''),
            'payment_method_type' => Arr::get($billingInfo, 'type', ''),
            'vendor_charge_id'    => $vendorChargeId,
            'payment_mode'        => $order->mode,
            'meta'                => array_merge($transaction->meta ?? [], $meta)
        ]);
        $transactionUpdateData['total'] = $amount;

        $transaction->fill($transactionUpdateData);
        $transaction->save();

        fluent_cart_add_log(__('Paddle Payment Confirmation', 'fluent-cart-pro'), __('Payment confirmation received from Paddle. Transaction ID:', 'fluent-cart-pro')  . $vendorChargeId, 'info', [
            'module_name' => 'order',
            'module_id'   => $order->id,
        ]);

        if ($subscriptionModel) {
            $subscriptionModel->addLog(__('Paddle Payment Confirmation', 'fluent-cart-pro'), __('Payment confirmation received from Paddle. Transaction ID:', 'fluent-cart-pro') . $vendorChargeId);
        }

        if ($order->type === Status::ORDER_TYPE_RENEWAL) {

            if (!$subscriptionModel) {
                return $order; // No subscription found for this renewal order. Something is wrong.
            }

            $paddleSubscriptionId = Arr::get($charge, 'subscription_id');
            if (!$paddleSubscriptionId && $subscriptionModel->current_payment_method === 'paddle') {
                $paddleSubscriptionId = $subscriptionModel->vendor_subscription_id;
            }

            // Without a Paddle subscription id the previous gateway stays recorded;
            // the subscription.activated webhook is what moves the row to Paddle.
            $subscriptionArgs = [
                'status'                 => Status::SUBSCRIPTION_ACTIVE,
                'canceled_at'            => null,
                'current_payment_method' => $paddleSubscriptionId ? 'paddle' : $subscriptionModel->current_payment_method
            ];

            $response = $paddleSubscriptionId
                ? (new API())->getPaddleObject('subscriptions/' . $paddleSubscriptionId, [], $transaction->payment_mode)
                : new \WP_Error('paddle_subscription_unknown', 'No Paddle subscription id on the charge');

            if (!is_wp_error($response)) {
                $paddleSubscription = (array) Arr::get($response, 'data', []);

                $subscriptionArgs = array_merge($subscriptionArgs, array_filter(
                    PaddleHelper::getSubscriptionVendorRefs($paddleSubscription)
                ));

                $nextBillingDate = Arr::get($paddleSubscription, 'next_billed_at');
                if ($nextBillingDate) {
                    $subscriptionArgs['next_billing_date'] = DateTime::anyTimeToGmt($nextBillingDate)->format('Y-m-d H:i:s');
                }
            }

            SubscriptionService::recordManualRenewal($subscriptionModel, $transaction, [
                'billing_info'      => $billingInfo,
                'subscription_args' => $subscriptionArgs
            ]);

        } else {
            if ($subscriptionModel) {
                // can't confirm subscription as we don't have the subscription id/data yet
                $subscriptionModel->updateMeta('active_payment_method', $billingInfo);
            }

            (new StatusHelper($order))->syncOrderStatuses($transaction);
        }

        return $order;
    }
}
