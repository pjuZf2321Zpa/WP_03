<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Actions\Salesforce\SalesforceProHelper;
use BitApps\IntegrationsPro\Config;
use BitApps\IntegrationsPro\Core\Util\Hooks;

// Deprecated since v2.7.8 - use bit_integrations_salesforce_* hooks instead

if (bit_integrations_version_below('2.7.8')) {
    Hooks::filter('btcbi_salesforce_get_lead_utilities', [SalesforceProHelper::class, 'getLeadUtilities'], 10, 3);
    Hooks::filter('btcbi_salesforce_add_lead_utilities', [SalesforceProHelper::class, 'addLeadUtilities'], 10, 2);
    Hooks::filter('btcbi_salesforce_update_record', [SalesforceProHelper::class, 'updateRecord'], 10, 4);
}

// New hooks since v2.7.8
Hooks::filter(Config::withFreePrefix('salesforce_get_lead_utilities'), [SalesforceProHelper::class, 'getLeadUtilities'], 10, 3);
Hooks::filter(Config::withFreePrefix('salesforce_add_lead_utilities'), [SalesforceProHelper::class, 'addLeadUtilities'], 10, 2);
Hooks::filter(Config::withFreePrefix('salesforce_update_record'), [SalesforceProHelper::class, 'updateRecord'], 10, 4);
