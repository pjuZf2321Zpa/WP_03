<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Core\Util\Route;
use BitApps\IntegrationsPro\Triggers\Asgaros\AsgarosController;

Route::get('asgaros/get', [AsgarosController::class, 'getAllTasks']);
