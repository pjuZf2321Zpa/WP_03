<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Core\Util\Hooks;
use BitApps\IntegrationsPro\Triggers\ConvertForce\ConvertForceController;

Hooks::add('save_post_convertforce-popup', [ConvertForceController::class, 'campaignCreated'], 10, 3);
Hooks::add('save_post_convertforce-popup', [ConvertForceController::class, 'campaignUpdated'], 10, 3);
Hooks::add('transition_post_status', [ConvertForceController::class, 'campaignStatusChanged'], 10, 3);
Hooks::add('before_delete_post', [ConvertForceController::class, 'campaignDeleted'], 10, 2);
Hooks::add('wp_trash_post', [ConvertForceController::class, 'campaignDeleted'], 10, 1);
