<?php
/** Paid AI Forms blueprint fields and guided steps. */
namespace WPAICG\Lib\AIForms;

use function WPAICG\Admin\Ajax\AIForms\aipkit_ai_forms_limit_text_length;
use function WPAICG\Admin\Ajax\AIForms\aipkit_ai_forms_prompt_mentions_multistep;

if (!defined('ABSPATH')) {
    exit;
}

final class Blueprints
{
    public static function is_available(): bool
    {
        return class_exists('\WPAICG\aipkit_dashboard') && \WPAICG\aipkit_dashboard::is_pro_plan();
    }

    public static function generation_config(array $schema_example): array
    {
        if (!self::is_available()) {
            return [];
        }
        $schema_example['rows'][0]['conversation_step'] = [
            'enabled' => true,
            'title' => 'Brief',
            'description' => 'Collect the core writing requirements.',
        ];
        $schema_example['rows'][1]['conversation_step'] = [
            'enabled' => true,
            'title' => 'Preferences',
            'description' => 'Capture audience and tone details.',
            'condition' => [
                'field_id' => '',
                'operator' => 'equals',
                'value' => '',
            ],
        ];
        return [
            'schema' => $schema_example,
            'field_types' => 'text-input, textarea, select, checkbox, radio-button, file-upload, image-upload',
            'rules' => [
                '- this site is on Pro, so you may use file-upload and image-upload when the requested workflow truly needs them.',
                '- you may create a guided multi-step form by adding conversation_step metadata to rows.',
                '- if the user asks for a multi-step, step-by-step, wizard, conditional, or branched form, use conversation_step metadata.',
                '- conversation_step.enabled should be true for rows that should appear as steps.',
                '- conversation_step may include title, description, and an optional condition object with field_id, operator, and value.',
                '- condition.field_id must reference a field from an earlier row only.',
                '- condition.operator must be one of: equals, not_equals, contains, not_contains, filled, empty.',
                '- do not use audio-upload yet.',
            ],
        ];
    }

    public static function add_upload_help(array $normalized): array
    {
        if (!self::is_available()) {
            return $normalized;
        }
        if ($normalized['helpText'] === '') {
            $normalized['helpText'] = $normalized['type'] === 'image-upload'
                ? __('Upload an image for the AI to analyze.', 'gpt3-ai-content-generator')
                : __('Upload a TXT or PDF file for the AI to use.', 'gpt3-ai-content-generator');
        }
        return $normalized;
    }

    public static function normalize_conversation_step(array $raw_step, int $row_number): ?array
    {
        if (!self::is_available()) {
            return null;
        }
        $explicit_enabled = $raw_step['enabled'] ?? $raw_step['conversationEnabled'] ?? true;
        $conversation_enabled = is_bool($explicit_enabled)
            ? $explicit_enabled
            : filter_var($explicit_enabled, FILTER_VALIDATE_BOOLEAN, FILTER_NULL_ON_FAILURE);
        if ($conversation_enabled === null) {
            $conversation_enabled = true;
        }

        $raw_condition = isset($raw_step['condition']) && is_array($raw_step['condition'])
            ? $raw_step['condition']
            : [];
        $condition_field_id = sanitize_key((string) ($raw_step['conditionFieldId'] ?? $raw_step['condition_field_id'] ?? $raw_condition['field_id'] ?? ''));
        $condition_operator = sanitize_key((string) ($raw_step['conditionOperator'] ?? $raw_step['condition_operator'] ?? $raw_condition['operator'] ?? 'equals'));
        $allowed_operators = ['equals', 'not_equals', 'contains', 'not_contains', 'filled', 'empty'];
        if (!in_array($condition_operator, $allowed_operators, true)) {
            $condition_operator = 'equals';
        }
        $condition_value = sanitize_text_field((string) ($raw_step['conditionValue'] ?? $raw_step['condition_value'] ?? $raw_condition['value'] ?? ''));
        if ($row_number <= 1 || $condition_field_id === '') {
            $condition_field_id = '';
            $condition_operator = 'equals';
            $condition_value = '';
        }
        /* translators: %d: Conversation step number. */
        $fallback_step_title = sprintf(__('Step %d', 'gpt3-ai-content-generator'), $row_number);

        return [
            'conversationEnabled' => $conversation_enabled === true,
            'title' => aipkit_ai_forms_limit_text_length(
                sanitize_text_field((string) ($raw_step['title'] ?? $fallback_step_title)),
                90
            ),
            'description' => aipkit_ai_forms_limit_text_length(
                sanitize_text_field((string) ($raw_step['description'] ?? '')),
                180
            ),
            'conditionFieldId' => $condition_field_id,
            'conditionOperator' => $condition_operator,
            'conditionValue' => aipkit_ai_forms_limit_text_length($condition_value, 120),
        ];
    }

    public static function complete_form(array $result, string $generation_prompt): array
    {
        if (!self::is_available()) {
            return $result;
        }
        $normalized_rows = $result['structure'];
        $has_conversation_steps = false;
        foreach ($normalized_rows as $row) {
            if (!empty($row['aipkitConversationStep']['conversationEnabled'])) {
                $has_conversation_steps = true;
                break;
            }
        }
        if (
            !$has_conversation_steps
            && count($normalized_rows) > 1
            && aipkit_ai_forms_prompt_mentions_multistep($generation_prompt)
        ) {
            foreach ($normalized_rows as $index => &$normalized_row_ref) {
                $normalized_row_ref['aipkitConversationStep'] = self::normalize_conversation_step([], $index + 1);
            }
            unset($normalized_row_ref);
            $has_conversation_steps = true;
        }

        $result['structure'] = $normalized_rows;
        if ($has_conversation_steps) {
            $result['conversation_ui_preset'] = 'full';
        }
        return $result;
    }
}
