<?php

use FluentCart\Framework\Http\Router;
use FluentCartPro\App\Modules\Reviews\Http\Controllers\ReviewMediaController;
use FluentCartPro\App\Modules\Reviews\Http\Controllers\ReviewThreadController;
use FluentCartPro\App\Modules\Reviews\Http\Controllers\ReviewVoteController;

/**
 * @var $router Router
 */

// Public review routes — same policy as the free plugin's sibling
// public/reviews group (frontend_routes.php), so any future tightening
// of PublicPolicy covers both halves of the surface.
$router->prefix('public/reviews')
    ->withPolicy('FluentCart\App\Http\Policies\PublicPolicy')
    ->group(function ($router) {
        $router->post('/{postId}/media/upload', [ReviewMediaController::class, 'upload'])->int('postId');
        $router->post('/vote/{reviewId}', [ReviewVoteController::class, 'vote'])->int('reviewId');
        $router->post('/{postId}/{reviewId}/reply', [ReviewThreadController::class, 'submitReply'])->int('postId')->int('reviewId');
    });
