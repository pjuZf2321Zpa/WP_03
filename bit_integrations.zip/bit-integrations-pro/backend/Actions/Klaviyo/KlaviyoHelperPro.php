<?php

/**
 * Klaviyo    Record Api
 */

namespace BitApps\IntegrationsPro\Actions\Klaviyo;

class KlaviyoHelperPro
{
    public static function setCustomProperties($requestParams, $customProperties, $fieldValues)
    {
        $commonClass = bit_integrations_get_class('Core\\Util\\Common');

        $properties = [];

        foreach ($customProperties as $property) {
            $triggerValue = $property->formField;
            $actionValue = $property->klaviyoFormField;

            if ($triggerValue === 'custom') {
                $properties[$actionValue] = $commonClass::replaceFieldWithValue($property->customValue, $fieldValues);
            } elseif (isset($fieldValues[$triggerValue])) {
                $properties[$actionValue] = $fieldValues[$triggerValue];
            }
        }

        if (!empty($properties)) {
            $requestParams['data']['attributes']['properties'] = $properties;
        }

        return $requestParams;
    }

    public static function updateProfile($value, $id, $authKey, $data)
    {
        $httpHelperClass = bit_integrations_get_class('Core\\Util\\HttpHelper');

        $headers = [
            'Authorization' => "Klaviyo-API-Key {$authKey}",
            'Content-Type'  => 'application/json',
            'accept'        => 'application/json',
            'revision'      => '2024-02-15'
        ];

        $apiEndpoints = "https://a.klaviyo.com/api/profiles/{$id}";
        $data['data']['id'] = $id;

        return $httpHelperClass::request($apiEndpoints, 'PATCH', wp_json_encode($data), $headers);
    }
}
