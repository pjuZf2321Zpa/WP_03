<?php
/**
 * BuddyBoss Platform Pro Main Class
 *
 * @package BuddyBossPro
 */

if ( ! class_exists( 'BB_Platform_Pro' ) ) {

	/**
	 * Main Class
	 *
	 * @class BB_Platform_Pro
	 * @version 1.0.0
	 */
	#[\AllowDynamicProperties]
	final class BB_Platform_Pro {

		/**
		 * Instance of the class.
		 *
		 * @var BB_Platform_Pro The single instance of the class
		 * @since 1.0.0
		 */
		protected static $instance = null;

		/**
		 * Integrations.
		 *
		 * @var array Integrations.
		 */
		public $integrations = array();

		/**
		 * Access Control.
		 *
		 * @var null Access Control.
		 * @since 1.1.0
		 */
		public $access_control = null;

		/**
		 * Integration Directory path.
		 *
		 * @var null
		 * @since 2.5.20
		 */
		public $integration_dir = null;

		/**
		 * Main BB_Platform_Pro Instance
		 *
		 * Ensures only one instance of BB_Platform_Pro is loaded or can be loaded.
		 *
		 * @since 1.0.0
		 * @static
		 * @see BB_Platform_Pro()
		 * @return BB_Platform_Pro - Main instance
		 */
		public static function instance() {
			if ( is_null( self::$instance ) ) {
				self::$instance = new self();
			}
			return self::$instance;
		}

		/**
		 * Cloning is forbidden.
		 *
		 * @since 1.0.0
		 */
		public function __clone() {
			_doing_it_wrong( __FUNCTION__, esc_html__( 'Cheatin&#8217; huh?', 'buddyboss-pro' ), '1.0.0' );
		}
		/**
		 * Unserializing instances of this class is forbidden.
		 *
		 * @since 1.0.0
		 */
		public function __wakeup() {
			_doing_it_wrong( __FUNCTION__, esc_html__( 'Cheatin&#8217; huh?', 'buddyboss-pro' ), '1.0.0' );
		}

		/**
		 * BB_Platform_Pro Constructor.
		 */
		public function __construct() {
			$this->constants();
			$this->setup_globals();
			$this->load_plugin_textdomain();
			$this->includes();
			$this->setup_actions();
		}

		/** Private Methods *******************************************************/

		/**
		 * Bootstrap constants.
		 *
		 * @since 1.0.0
		 */
		private function constants() {
			if ( ! defined( 'BB_PLATFORM_PRO_PLUGIN_DIR' ) ) {
				define( 'BB_PLATFORM_PRO_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
			}

			if ( ! defined( 'BB_PLATFORM_PRO_PLUGIN_URL' ) ) {
				define( 'BB_PLATFORM_PRO_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
			}

			if ( ! defined( 'BB_PLATFORM_PRO_PLUGIN_BASENAME' ) ) {
				define( 'BB_PLATFORM_PRO_PLUGIN_BASENAME', plugin_basename( __FILE__ ) );
			}

			if ( ! defined( 'BB_PLATFORM_PRO_PLUGIN_FILE' ) ) {
				define( 'BB_PLATFORM_PRO_PLUGIN_FILE', __FILE__ );
			}
		}

		/**
		 * Global variables.
		 *
		 * @since 1.0.0
		 */
		private function setup_globals() {
			$this->version        = '3.4.2';
			$this->db_version     = 335;
			$this->db_version_raw = (int) bp_get_option( '_bbp_pro_db_version' );

			// root directory.
			$this->file       = __FILE__;
			$this->basename   = plugin_basename( __FILE__ );
			$this->plugin_dir = trailingslashit( constant( 'BB_PLATFORM_PRO_PLUGIN_DIR' ) );
			$this->plugin_url = trailingslashit( constant( 'BB_PLATFORM_PRO_PLUGIN_URL' ) );

			$this->root_plugin_dir = $this->plugin_url;
			$this->integration_dir = $this->plugin_dir . 'includes/integrations';
			$this->integration_url = $this->plugin_url . 'includes/integrations';

			// Access Control.
			$this->access_control_dir = $this->plugin_dir . 'includes/access-control';
			$this->access_control_url = $this->plugin_url . 'includes/access-control';

			// Blog.
			$this->blog_dir = $this->plugin_dir . 'includes/blog';
			$this->blog_url = $this->plugin_url . 'includes/blog';

			// Schedule posts.
			$this->schedule_posts_dir = $this->plugin_dir . 'includes/schedule-posts';
			$this->schedule_posts_url = $this->plugin_url . 'includes/schedule-posts';

			// Topics.
			$this->topics_dir = $this->plugin_dir . 'includes/topics';
			$this->topics_url = $this->plugin_url . 'includes/topics';

			// Platform Settings.
			$this->platform_settings_dir = $this->plugin_dir . 'includes/platform-settings';
			$this->platform_settings_url = $this->plugin_url . 'includes/platform-settings';
		}

		/**
		 * Include required core files used in admin and on the frontend.
		 */
		public function includes() {
			spl_autoload_register( array( $this, 'autoload' ) );

			require $this->plugin_dir . 'includes/bb-pro-core-update.php';
			require $this->plugin_dir . 'includes/bb-pro-core-actions.php';
			require $this->plugin_dir . 'includes/bb-pro-core-functions.php';
			require $this->plugin_dir . 'includes/bb-pro-core-deprecated.php';
			require $this->plugin_dir . 'includes/bb-pro-core-loader.php';
		}

		/**
		 * Load Localisation files.
		 *
		 * Locations are tried in precedence order and the walk STOPS at the first
		 * one that genuinely holds a catalog for the locale; later locations are
		 * fallbacks, not layers. This matches Platform's loader.
		 *
		 * Release layered instead — it called load_textdomain() for the WP_LANG_DIR
		 * override and then load_plugin_textdomain() for the bundled catalog
		 * unconditionally, so on WP < 6.7 (where the latter still read the file) a
		 * partial override was topped up from the bundled catalog. That is no longer
		 * the case, and it stopped being the case on WP 6.7+ anyway, where
		 * load_plugin_textdomain() only registers a path.
		 *
		 * @since 1.0.0
		 * @since 3.3.2 Reloads the catalog when the locale has changed since the last load, so
		 *                    late locale resolution (WPML/Polylang) and mid-request switch_to_locale()
		 *                    calls translate correctly. Now walks an ordered list of locations rather
		 *                    than relying on core's just-in-time loader for the bundled catalog.
		 *
		 * @return bool True when load_textdomain() reported success for the authoritative location —
		 *              which may be a real file, or a catalog served by an `override_load_textdomain` /
		 *              `load_translation_file` listener for a path that does not exist (Loco Translate
		 *              and WPML String Translation both do this). False when nothing needed doing, or
		 *              when no location produced a catalog.
		 */
		public function load_plugin_textdomain() {
			static $loaded_locale   = null;
			static $path_registered = false;

			$domain = 'buddyboss-pro';
			// determine_locale() covers the admin user language (superset of the
			// previous is_admin()/get_user_locale() special case) and follows
			// mid-request locale switches (determine_locale() is WP 5.0+; the
			// get_locale() fallback is kept while the readme floor predates it).
			//
			// Only from `init` onwards, though. In wp-admin (and on `_locale=user`
			// JSON requests) determine_locale() calls get_user_locale() ->
			// wp_get_current_user(), which fires the `determine_current_user`
			// filter and memoises its result for the whole request. This method
			// first runs from the constructor at plugins_loaded:9, which risks
			// resolving the user before an authentication plugin that happens to
			// load after this one has registered its `determine_current_user`
			// filter; that filter would then never be consulted and the requester
			// would resolve as logged out. Nothing is lost by waiting:
			// that first pass is not authoritative, and the init:0 re-run
			// registered in setup_actions() supplies the admin-user locale.
			//
			// The one exception is when the current user has ALREADY been resolved
			// by something else: $GLOBALS['current_user'] is exactly the memo
			// wp_get_current_user() consults, so reading it costs nothing and
			// triggers no filter. Taking the admin-user locale in that case closes
			// the plugins_loaded -> init window for strings that Pro's integrations
			// translate at plugins_loaded:10, which the previous
			// is_admin()/get_user_locale() code covered and a plain deferral loses.
			//
			// did_action() is already truthy inside init:0 (core increments the
			// count before running callbacks), so this covers both "during" and
			// "after". Hooks that fire before init (pll_language_defined, on
			// setup_theme) fall back to get_locale(), which the multilingual
			// plugin has already filtered to the request language.
			//
			// This is the locale every later lookup uses, so it is also the locale
			// the catalog must be REGISTERED under — see load_textdomain() below.
			if ( function_exists( 'determine_locale' ) && ( did_action( 'init' ) || isset( $GLOBALS['current_user'] ) ) ) {
				$request_locale = determine_locale();
			} else {
				$request_locale = get_locale();
			}

			// `plugin_locale` selects which catalog FILE belongs to this domain and
			// may legitimately differ from the request locale (WPML formal/informal
			// variants, per-plugin language overrides). Used for the file name ONLY —
			// never as the registration locale, which would leak into the
			// process-wide WP_Translation_Controller. See load_textdomain() below.
			$locale = apply_filters( 'plugin_locale', $request_locale, $domain );

			// Re-attempt when either locale changed OR the domain is not loaded —
			// the loaded check keeps third-party unload_textdomain() calls (Loco
			// Translate unloads every prematurely-loaded domain when it boots) and
			// Polylang's load blocker from stranding the domain unloaded.
			$locale_key = $request_locale . '|' . $locale;
			if ( $locale_key === $loaded_locale && is_textdomain_loaded( $domain ) ) {
				return false;
			}
			$loaded_locale = $locale_key;

			$mofile_custom = $domain . '-' . $locale . '.mo';
			$plugin_dir    = untrailingslashit( __DIR__ );

			/**
			 * Filters the locations to load Pro language files from, highest precedence first.
			 *
			 * Mirrors Platform's `buddyboss_locale_locations`.
			 *
			 * @since 3.3.2
			 *
			 * @param array $value Array of trailing-slashed directories to check for language files in.
			 */
			$locations = apply_filters(
				'bb_pro_locale_locations',
				array(
					trailingslashit( WP_LANG_DIR . '/' . plugin_basename( $plugin_dir ) ),
					trailingslashit( WP_LANG_DIR . '/plugins' ),
					trailingslashit( $plugin_dir . '/languages' ),
				)
			);

			// Re-index so the positional comparison in the load loop is meaningful
			// even when a filter returns a sparse or associative array, and so a
			// filter returning a non-array cannot fatal the foreach.
			$locations = array_values( (array) $locations );

			// Which location, if any, actually has a catalog for this locale
			// (either format — load_textdomain() prefers the .l10n.php sibling).
			$phpfile_custom = substr( $mofile_custom, 0, -3 ) . '.l10n.php';
			$found_mofile   = '';
			$found_dir      = '';
			$found_index    = -1;
			foreach ( $locations as $index => $location ) {
				if ( is_readable( $location . $mofile_custom ) || is_readable( $location . $phpfile_custom ) ) {
					$found_mofile = $location . $mofile_custom;
					$found_dir    = $location;
					$found_index  = $index;
					break;
				}
			}

			// Teach core's just-in-time loader about the bundled languages/ dir —
			// ONCE per request, never re-asserted. WP_Textdomain_Registry holds
			// exactly one custom path per domain, so re-registering on init:0 and on
			// every change_locale would overwrite a path registered later by a site
			// or a translation plugin (a Loco Translate custom bundle, an mu-plugin
			// calling load_plugin_textdomain() at after_setup_theme) and core's JIT
			// would stop finding their catalog for the rest of the request.
			// WP 6.1+ only; the fast path below may only trust this directory when
			// the registration actually happened.
			if (
				! $path_registered
				&& isset( $GLOBALS['wp_textdomain_registry'] )
				&& is_object( $GLOBALS['wp_textdomain_registry'] )
				&& method_exists( $GLOBALS['wp_textdomain_registry'], 'set_custom_path' )
			) {
				$GLOBALS['wp_textdomain_registry']->set_custom_path( $domain, $plugin_dir . '/languages' );
				$path_registered = true;
			}
			$core_serves_plugin_dir = $path_registered;

			// During change_locale (and only there — on other hooks a loaded
			// catalog may still be the stale previous-locale one), core's locale
			// switcher has already unloaded the domain and JIT-reloaded it for the
			// NEW locale from the directories its registry knows: WP_LANG_DIR/
			// plugins, plus the bundled languages/ dir once registered above.
			//
			// We do not rely on that reload having succeeded. is_textdomain_loaded()
			// is a genuine post-condition check — it excludes NOOP_Translations, and
			// load_textdomain() only registers a real translations object after the
			// file for the new locale actually loaded. So when core's JIT is
			// unavailable (WP < 6.1, or a third party left the l10n_unloaded flag
			// set) this test is simply false and we do the full reload.
			//
			// Directory equality rather than a string prefix: a location nested
			// under one of these, reachable through the filter above, is not
			// something core's registry can serve.
			$core_has_best = '' === $found_mofile
				|| trailingslashit( WP_LANG_DIR . '/plugins' ) === $found_dir
				|| ( $core_serves_plugin_dir && trailingslashit( $plugin_dir . '/languages' ) === $found_dir );

			// is_textdomain_loaded() is locale-AGNOSTIC: it proves some catalog is in
			// $l10n, not that it is the one for $request_locale. A third party that
			// dispatches change_locale as a plain notification without unloading
			// first would leave the stale previous-locale catalog in place and this
			// fast path would trust it. WP 6.5+ exposes a locale-aware check; require
			// both (the core call additionally excludes NOOP_Translations).
			$domain_loaded = is_textdomain_loaded( $domain );
			if ( $domain_loaded && class_exists( 'WP_Translation_Controller' ) ) {
				$domain_loaded = WP_Translation_Controller::get_instance()->is_textdomain_loaded( $domain, $request_locale );
			}

			if (
				doing_action( 'change_locale' )
				&& $domain_loaded
				&& $core_has_best
				// Core's JIT builds its filename from determine_locale(), so when a
				// plugin_locale filter points this domain at a different catalog than
				// the request locale, what core reloaded is NOT the file the probe
				// matched.
				&& $locale === $request_locale
			) {
				return false;
			}

			// Reloadable: a plain unload would permanently disable core's JIT
			// loading for the domain, removing the native fallback
			// ($reloadable is WP 6.1+; older cores ignore the extra arg and
			// behave like the pre-fix plain unload — no regression there).
			unload_textdomain( $domain, true );

			// $reloadable = true keeps JIT alive but also means core does NOT drop
			// the domain from WP_Translation_Controller. On WP 6.5+ that controller
			// appends each loaded file and resolves first-match-wins, so without
			// this the reload below could not promote a higher-precedence catalog
			// over one already loaded for the same locale. Scoped to this domain and
			// locale, and $l10n_unloaded stays unset so the JIT backstop survives.
			// Only when the probe found a real catalog to re-establish, so a request
			// whose catalog is filter-served (Loco Translate, WPML String
			// Translation) is never left worse off.
			if ( '' !== $found_mofile && class_exists( 'WP_Translation_Controller' ) ) {
				WP_Translation_Controller::get_instance()->unload_textdomain( $domain, $request_locale );
			}

			// Loco Translate saves plugin edits only to LOCO_LANG_DIR/plugins/, which
			// is reachable only from the last two locations below; a catalog in
			// WP_LANG_DIR/buddyboss-platform-pro/ would end the walk before them and
			// every Loco edit would be silently ignored. Offer it first and let the
			// walk layer the base catalog underneath — the WP 6.5+ controller is
			// first-match-wins, so Loco's overrides win while strings it does not
			// carry still fall through. Deliberately outside the location list: it
			// must never terminate the walk, and its return value is ignored.
			if ( defined( 'LOCO_LANG_DIR' ) && LOCO_LANG_DIR ) {
				load_textdomain( $domain, trailingslashit( LOCO_LANG_DIR ) . 'plugins/' . $mofile_custom, $request_locale );
			}

			// Attempt each location in precedence order — unconditionally, even when
			// the probe found nothing on disk. load_textdomain() is an extension
			// point, not just a file read: Loco Translate maps each attempted path
			// under WP_LANG_DIR to its wp-content/languages/loco/ equivalent and
			// returns that mapping when the original is missing, and WPML String
			// Translation layers its own MOs in. Gating the loop on the probe would
			// silently drop every such translation.
			foreach ( $locations as $index => $location ) {
				$mofile = $location . $mofile_custom;

				// $request_locale, NOT $locale, is the registration locale.
				// load_textdomain() calls WP_Translation_Controller::set_locale()
				// with this value BEFORE inspecting any file, and that controller is
				// a process-wide singleton shared by every text domain: handing it a
				// plugin_locale-filtered value that differs from the request locale
				// would repoint lookups for core's own `default` domain and blank out
				// the page. Registering under the request locale is also what makes
				// the catalog findable. Passing it explicitly rather than letting
				// core call determine_locale() preserves the deferral documented
				// above.
				$loaded = load_textdomain( $domain, $mofile, $request_locale );

				// A truthy return is not proof this location's catalog loaded —
				// override listeners answer true for paths that do not exist, and the
				// WP 6.5+ controller reports success for a file already registered
				// earlier in the request. Keep walking until the probe's own position
				// so higher-precedence override listeners get to layer on top first
				// (they win regardless — the controller is first-match-wins), then
				// stop. Positions rather than paths, so a `load_textdomain_mofile`
				// filter rewriting the path does not defeat the check.
				if ( $loaded && ( '' === $found_mofile || $index >= $found_index ) ) {
					return true;
				}
			}

			// Nothing loaded. Fall back to core's JIT registration — but only if we
			// did not already register the path above, because
			// load_plugin_textdomain() calls set_custom_path() internally and would
			// clobber a custom path registered by a third party after us.
			if ( $path_registered ) {
				// Mirror the one other thing load_plugin_textdomain() does: clear a
				// NOOP_Translations placeholder left by a failed earlier JIT attempt
				// so core can try again.
				if ( isset( $GLOBALS['l10n'][ $domain ] ) && $GLOBALS['l10n'][ $domain ] instanceof NOOP_Translations ) {
					unset( $GLOBALS['l10n'][ $domain ] );
				}

				return false;
			}

			return load_plugin_textdomain( $domain, false, plugin_basename( $plugin_dir ) . '/languages' );
		}

		/**
		 * Autoload classes.
		 *
		 * @since 1.0.0
		 *
		 * @param string $class Class to load.
		 */
		public function autoload( $class ) {
			$class_parts = explode( '_', strtolower( $class ) );

			if ( 'bp' !== $class_parts[0] && 'bb' !== $class_parts[0] ) {
				return;
			}

			// Sanitize class name.
			$class = strtolower( str_replace( '_', '-', $class ) );

			$paths = array(

				$this->plugin_dir . "/includes/classes/class-{$class}.php",
				$this->plugin_dir . "/includes/access-control/includes/class-{$class}.php",
				$this->plugin_dir . "/includes/blog/includes/class-{$class}.php",
				$this->plugin_dir . "/includes/schedule-posts/includes/class-{$class}.php",
				$this->plugin_dir . "/includes/topics/includes/class-{$class}.php",
			);

			$integration_dir = $this->integration_dir;

			foreach ( $this->integrations as $integration ) {
				$paths[] = "{$integration_dir}/{$integration}/includes/class-{$class}.php";
				$paths[] = "{$integration_dir}/{$integration}/includes/classes/class-{$class}.php";
			}

			foreach ( $paths as $path ) {
				// Sanity check.
				if ( file_exists( $path ) ) {
					require $path;
				}
			}
		}

		/**
		 * Add actions.
		 *
		 * @since 1.2.0
		 */
		private function setup_actions() {
			// The textdomain load in the constructor runs at plugins_loaded, before
			// multilingual plugins resolve the request language; re-run once the
			// locale is final and whenever it changes mid-request. The loader
			// self-no-ops when the locale is unchanged. Mirrors Platform's
			// bp-loader.php handling.
			// Priorities 20/10 are load-bearing, do not normalize to default:
			// 20 = after WPML String Translation's listeners (10, which also
			// update the locale this loader reads); 10 = after Polylang's OLT
			// manager removes its load_textdomain_mofile blocker (priority 2).
			// See Platform's bp-loader.php hook comments for the full rationale.
			add_action( 'init', array( $this, 'load_plugin_textdomain' ), 0 );
			add_action( 'change_locale', array( $this, 'load_plugin_textdomain' ), 0 );
			add_action( 'wpml_language_has_switched', array( $this, 'load_plugin_textdomain' ), 20 );
			add_action( 'pll_language_defined', array( $this, 'load_plugin_textdomain' ), 10 );
			// Sibling action for the "no languages configured yet" case.
			add_action( 'pll_no_language_defined', array( $this, 'load_plugin_textdomain' ), 10 );

			// add actions.
			add_action( 'bp_enqueue_scripts', array( $this, 'enqueue_scripts_styles' ) );

			add_action( 'bp_admin_enqueue_scripts', array( $this, 'bb_enqueue_scripts_styles_admin' ) );
			add_action( 'admin_footer', array( $this, 'bb_pro_display_update_plugin_information' ) );

			// Add link to settings page.
			add_filter( 'plugin_action_links', array( $this, 'bb_pro_modify_plugin_action_links' ), 10, 2 );
			add_filter( 'network_admin_plugin_action_links', array( $this, 'bb_pro_modify_plugin_action_links' ), 10, 2 );

			// Platform-version compatibility notice (Pro 3.0+ vs Platform < 3.0).
			add_action( 'admin_notices', array( $this, 'render_platform_compat_notice' ) );
			add_action( 'network_admin_notices', array( $this, 'render_platform_compat_notice' ) );
		}

		/**
		 * Admin notice — Platform-version mismatch for Pro 3.0+.
		 *
		 * BuddyBoss Platform Pro 3.0 hooks into the Settings 2.0 feature
		 * registry, REST proxy surface, and reaction-migration plumbing
		 * introduced in Platform 3.0. Running Pro 3.x against a pre-3.0
		 * Platform produces silent breakage in extension hooks and missing
		 * admin UI, so we surface a non-dismissible warning until the
		 * admin resolves the mismatch by updating Platform.
		 *
		 * Companion to the Platform-side notice that fires the OPPOSITE
		 * direction (Platform 3.0 + outdated addons). Both are deliberately
		 * non-dismissible — acknowledging a broken integration without
		 * fixing it just hides the symptom from the admin most likely to
		 * debug it.
		 *
		 * Lives on the class because `$this->version` is the canonical
		 * runtime version (set in `setup_globals()` from a single string
		 * literal) — no `get_file_data()` round-trip, no fragile constant
		 * lookups. The method only runs once `bb_platform_pro_init()` has
		 * passed Platform's existence + minimum-version checks at
		 * `plugins_loaded:9`, so by the time `admin_notices` fires we know
		 * Platform is loaded.
		 *
		 * @since 3.0.0
		 *
		 * @return void
		 */
		public function render_platform_compat_notice() {
			if ( ! current_user_can( 'update_plugins' ) ) {
				return;
			}

			$platform_version = defined( 'BP_PLATFORM_VERSION' ) ? BP_PLATFORM_VERSION : '';
			if ( '' !== $platform_version && version_compare( $platform_version, '3.0.0', '>=' ) ) {
				return;
			}

			$update_url = self_admin_url( 'update-core.php' );
			?>
			<div class="notice notice-error">
				<p>
					<?php
					printf(
						/* translators: 1: Pro version. 2: Required Platform version. */
						esc_html__( 'BuddyBoss Platform Pro %1$s requires BuddyBoss Platform %2$s or higher.', 'buddyboss-pro' ),
						esc_html( $this->version ),
						'3.0.0'
					);
					?>
					<a href="<?php echo esc_url( $update_url ); ?>"><?php esc_html_e( 'Update Platform now', 'buddyboss-pro' ); ?></a>
				</p>
			</div>
			<?php
		}

		/**
		 * Enqueue related scripts and styles.
		 *
		 * @since 1.2.0
		 */
		public function enqueue_scripts_styles() {
			$min     = ( defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ) ? '' : '.min';
			$rtl_css = is_rtl() ? '-rtl' : '';
			wp_enqueue_style( 'bb-pro-enqueue-scripts', $this->plugin_url . 'assets/css/index' . $rtl_css . $min . '.css', false, bb_platform_pro()->version );
		}

		/**
		 * Enqueue style and script to the admin area for release note pop-up.
		 *
		 * @since 2.1.7
		 */
		public function bb_enqueue_scripts_styles_admin() {
			$min     = ( defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ) ? '' : '.min';
			$rtl_css = is_rtl() ? '-rtl' : '';

			wp_enqueue_style( 'bb-pro-enqueue-hello-style', $this->plugin_url . 'assets/css/hello' . $rtl_css . $min . '.css', false, bb_platform_pro()->version );
			wp_enqueue_script( 'bb-pro-enqueue-hello-script', $this->plugin_url . 'assets/js/hello' . $min . '.js', false, bb_platform_pro()->version, true );
			wp_localize_script(
				'bb-pro-enqueue-hello-script',
				'BP_PRO_HELLO',
				array(
					'bb_pro_display_auto_popup' => get_option( '_bb_pro_is_update' ),
				)
			);

			wp_enqueue_script( 'bb-pro-admin-script', $this->plugin_url . 'assets/js/bb-pro-admin' . $min . '.js', false, bb_platform_pro()->version, true );
			wp_localize_script(
				'bb-pro-admin-script',
				'BB_PRO_ADMIN',
				apply_filters(
					'bb_pro_admin_localize_options',
					array(
						'ajax_url' => admin_url( 'admin-ajax.php' ),
					)
				)
			);

		}

		/**
		 * Add Settings link to plugins area.
		 *
		 * @since 2.1.7
		 *
		 * @param array  $links Links array in which we would prepend our link.
		 * @param string $file  Current plugin basename.
		 * @return array Processed links.
		 */
		public function bb_pro_modify_plugin_action_links( $links, $file ) {

			// Return normal links if not BuddyPress.
			if (
				'buddyboss-platform-pro/buddyboss-platform-pro.php' !== $file ||
				(
					function_exists( 'bbp_pro_is_license_valid' ) &&
					bb_pro_should_lock_features()
				)
			) {
				return $links;
			}

			// Add a few links to the existing links array.
			return array_merge(
				$links,
				array(
					'release_notes' => '<a href="javascript:void(0);" id="bb-pro-plugin-release-link">' . esc_html__( 'Release Notes', 'buddyboss-pro' ) . '</a>',
				)
			);
		}

		/**
		 * Display plugin information after plugin successfully updated.
		 *
		 * @since 2.1.7
		 */
		public function bb_pro_display_update_plugin_information() {
			if (
				0 !== strpos( get_current_screen()->id, 'plugins' ) ||
				(
					function_exists( 'bbp_pro_is_license_valid' ) &&
					bb_pro_should_lock_features()
				)
			) {
				return;
			}
			
			// Output the modal HTML template.
			// This is needed for the Release Notes link to work.
			// Use output buffering and error handling to prevent breaking WordPress scripts.
			$template_path = trailingslashit( BB_PLATFORM_PRO_PLUGIN_DIR ) . 'includes/bb-pro-update-buddyboss.php';
			
			if ( file_exists( $template_path ) ) {
				// Use output buffering to catch any errors.
				ob_start();
				try {
					// Suppress any errors from the template to prevent breaking the page.
					@include $template_path;
					$output = ob_get_clean();
					
					// Only output if we got valid HTML (not an error).
					if ( ! empty( $output ) && false === strpos( $output, 'Fatal error' ) ) {
						echo $output; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
					}
				} catch ( Exception $e ) {
					ob_end_clean();
					// Silently fail to prevent breaking WordPress admin.
				}
			}
			
			// Clean up the update flag to prevent database bloat.
			delete_option( '_bb_pro_is_update' );
		}
	}

	/**
	 * Returns the main instance of BB_Platform_Pro to prevent the need to use globals.
	 *
	 * @since  1.0.0
	 * @return BB_Platform_Pro
	 */
	function bb_platform_pro() {
		return BB_Platform_Pro::instance();
	}
}
