<?php

namespace BitApps\IntegrationsPro\Triggers\Amelia;

use BitApps\IntegrationsPro\Triggers\Webhook\WebhookController;

final class AmeliaController extends WebhookController
{
    public static function info()
    {
        return [
            'name'      => 'Amelia Webhook',
            'title'     => __('Get callback data through an URL', 'bit-integrations-pro'),
            'type'      => 'webhook',
            'documentation_url' => 'https://bit-integrations.com/wp-docs/trigger/amelia-integrations/',
            'tutorial_url'      => '#',
            'is_active' => true,
            'isPro'     => true
        ];
    }
}
