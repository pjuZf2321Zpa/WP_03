<?php

if (!defined('ABSPATH')) {
    die('You are not allowed to call this page directly.');
}

/**
 * Cart order refund notification email sent to the admin.
 *
 * Mirrors MeprUserCartRefundEmail, addressed to the store admin.
 */
class MeprAdminCartRefundEmail extends MeprBaseOptionsAdminEmail
{
    /**
     * Per-refund context (amount, tax, mode, refunded txns) set before send().
     *
     * @var array
     */
    protected $context = [];

    /**
     * Set the default enabled, title, subject & body.
     *
     * @param  array $args The args.
     * @return void
     */
    public function set_defaults($args = [])
    {
        $mepr_options = MeprOptions::fetch();
        $this->to     = $mepr_options->admin_email_addresses;

        $this->title       = __('<b>Cart Order Refund Notification</b> Notice', 'memberpress');
        $this->description = __('Sent to the admin when a cart order is refunded (full, per item, or partial).', 'memberpress');
        $this->ui_order    = 4;

        $enabled = $use_template = $this->show_form = true;
        $subject = __('Cart Order #{$order_id} Refunded — {$user_email}', 'memberpress');
        $body    = $this->body_partial();

        $this->defaults  = compact('enabled', 'subject', 'body', 'use_template');
        $this->variables = MeprUserCartRefundEmail::get_cart_refund_email_vars();
    }

    /**
     * Get the body partial for the email.
     *
     * @param  array $vars Optional variables to pass to the view.
     * @return string The body partial HTML.
     */
    public function body_partial($vars = [])
    {
        return MeprView::get_string('/emails/admin-cart-refund', $vars);
    }

    /**
     * Set the per-refund context before send().
     *
     * @param  array $context Context {refunded_amount, refunded_tax, mode, refunded_txns}.
     * @return void
     */
    public function set_context(array $context)
    {
        $this->context = $context;
    }

    /**
     * Send the cart refund admin notification for the given order.
     *
     * @param  MeprOrder    $order        The refunded cart order.
     * @param  string|false $subject      Subject override, or false for the stored default.
     * @param  string|false $body         Body override, or false for the stored default.
     * @param  boolean|null $use_template Whether to wrap in the email template, or null for the default.
     * @param  string       $content_type The content type of the email.
     * @return void
     */
    public function send($order = [], $subject = false, $body = false, $use_template = null, $content_type = 'html')
    {
        if (!($order instanceof MeprOrder)) {
            parent::send($order, $subject, $body, $use_template, $content_type);
            return;
        }

        if (!$this->enabled()) {
            return;
        }

        $user = new MeprUser($order->user_id);
        $vars = MeprUserCartRefundEmail::build_cart_refund_vars($order, $user, $this->context);

        $formatted_subject = MeprUtils::replace_vals($this->get_stored_field('subject'), $vars);
        $formatted_body    = MeprUtils::replace_vals($this->get_stored_field('body'), $vars);

        $send_params = MeprHooks::apply_filters('mepr_cart_refund_email_params', [], $order, $this);

        parent::send($send_params, $formatted_subject, $formatted_body, $use_template, $content_type);
    }
}
