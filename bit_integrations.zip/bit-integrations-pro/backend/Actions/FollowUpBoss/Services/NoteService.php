<?php

namespace BitApps\IntegrationsPro\Actions\FollowUpBoss\Services;

final class NoteService extends BaseService
{
    public function createNote(): array
    {
        $validationRules = [
            'person_id' => ['required', 'integer'],
            'body'      => ['required'],
        ];
        $error = $this->validateFields(
            $validationRules,
            [
                'person_id' => __('Person ID', 'bit-integrations-pro'),
                'body'      => __('Body', 'bit-integrations-pro'),
            ]
        );

        if ($error !== null) {
            return $error;
        }

        $payload = $this->removeEmptyValues(
            [
                'personId' => $this->getInteger('person_id'),
                'subject'  => $this->getString('subject'),
                'body'     => $this->getString('body'),
                'isHtml'   => $this->getBoolean('is_html'),
            ]
        );

        return $this->dispatch('POST', '/notes', $payload);
    }

    public function updateNote(): array
    {
        $validationRules = ['note_id' => ['required', 'integer']];
        $error = $this->validateFields(
            $validationRules,
            [
                'note_id' => __('Note ID', 'bit-integrations-pro'),
            ]
        );

        if ($error !== null) {
            return $error;
        }

        $payload = $this->removeEmptyValues(
            [
                'subject' => $this->getString('subject'),
                'body'    => $this->getString('body'),
                'isHtml'  => $this->getBoolean('is_html'),
            ]
        );

        return $this->dispatch('PUT', '/notes/' . rawurlencode($this->getString('note_id')), $payload);
    }

    public function deleteNote(): array
    {
        $validationRules = ['note_id' => ['required', 'integer']];
        $error = $this->validateFields(
            $validationRules,
            [
                'note_id' => __('Note ID', 'bit-integrations-pro'),
            ]
        );

        if ($error !== null) {
            return $error;
        }

        return $this->dispatch('DELETE', '/notes/' . rawurlencode($this->getString('note_id')));
    }
}
