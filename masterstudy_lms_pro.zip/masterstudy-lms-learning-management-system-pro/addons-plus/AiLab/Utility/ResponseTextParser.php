<?php

namespace MasterStudy\Lms\Pro\AddonsPlus\AiLab\Utility;

use MasterStudy\Lms\Pro\AddonsPlus\AiLab\Services\OpenAi\Response;

final class ResponseTextParser {
	public static function extract_first_text( Response $response ): string {
		$candidates = array_merge( $response->results, array( $response->raw ) );

		foreach ( $candidates as $candidate ) {
			$text = self::extract_text_from_item( $candidate );

			if ( '' !== $text ) {
				return $text;
			}
		}

		return '';
	}

	private static function extract_text_from_item( $item ): string {
		if ( is_string( $item ) ) {
			return trim( $item );
		}

		if ( ! is_array( $item ) ) {
			return '';
		}

		$paths = array(
			array( 'message', 'content' ),
			array( 'message', 'parts' ),
			array( 'text' ),
			array( 'content' ),
		);

		foreach ( $paths as $path ) {
			$value = self::get_path( $item, $path );
			$text  = self::normalize_text_value( $value );

			if ( '' !== $text ) {
				return $text;
			}
		}

		if ( isset( $item[0] ) && is_array( $item[0] ) ) {
			return self::extract_text_from_item( $item[0] );
		}

		return '';
	}

	private static function normalize_text_value( $value ): string {
		if ( is_string( $value ) ) {
			return trim( $value );
		}

		if ( ! is_array( $value ) ) {
			return '';
		}

		$text = '';

		foreach ( $value as $part ) {
			if ( is_string( $part ) ) {
				$text .= $part;
				continue;
			}

			if ( ! is_array( $part ) ) {
				continue;
			}

			if ( isset( $part['text'] ) && is_string( $part['text'] ) ) {
				$text .= $part['text'];
				continue;
			}

			if ( isset( $part['content'] ) ) {
				$text .= self::normalize_text_value( $part['content'] );
			}
		}

		return trim( $text );
	}

	private static function get_path( array $data, array $path ) {
		foreach ( $path as $segment ) {
			if ( ! is_array( $data ) || ! array_key_exists( $segment, $data ) ) {
				return null;
			}

			$data = $data[ $segment ];
		}

		return $data;
	}
}
