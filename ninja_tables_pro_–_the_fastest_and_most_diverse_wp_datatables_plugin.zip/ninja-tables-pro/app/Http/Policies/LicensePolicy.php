<?php

namespace NinjaTablesPro\App\Http\Policies;

use NinjaTables\Framework\Request\Request;
use NinjaTables\Framework\Foundation\Policy;

/**
 * The license endpoints read and write a paid credential, so they sit behind
 * manage_options — deliberately stricter than UserPolicy's configurable
 * ninja_table_admin_role(), which site owners can grant to non-admins.
 */
class LicensePolicy extends Policy
{
    public function verifyRequest(Request $request)
    {
        if (is_multisite() && !is_super_admin()) {
            return false;
        }

        return current_user_can('manage_options');
    }
}
