<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Actions\WpSimpleBookingCalendar\WpSimpleBookingCalendarProHelper;
use BitApps\IntegrationsPro\Config;
use BitApps\IntegrationsPro\Core\Util\Hooks;

Hooks::filter(Config::withFreePrefix('wp_simple_booking_calendar_create_calendar'), [WpSimpleBookingCalendarProHelper::class, 'createCalendar'], 10, 3);
Hooks::filter(Config::withFreePrefix('wp_simple_booking_calendar_update_calendar'), [WpSimpleBookingCalendarProHelper::class, 'updateCalendar'], 10, 2);
Hooks::filter(Config::withFreePrefix('wp_simple_booking_calendar_trash_calendar'), [WpSimpleBookingCalendarProHelper::class, 'trashCalendar'], 10, 2);
Hooks::filter(Config::withFreePrefix('wp_simple_booking_calendar_restore_calendar'), [WpSimpleBookingCalendarProHelper::class, 'restoreCalendar'], 10, 2);
Hooks::filter(Config::withFreePrefix('wp_simple_booking_calendar_delete_calendar'), [WpSimpleBookingCalendarProHelper::class, 'deleteCalendar'], 10, 2);
Hooks::filter(Config::withFreePrefix('wp_simple_booking_calendar_create_event'), [WpSimpleBookingCalendarProHelper::class, 'createEvent'], 10, 3);
Hooks::filter(Config::withFreePrefix('wp_simple_booking_calendar_book_date_range'), [WpSimpleBookingCalendarProHelper::class, 'bookDateRange'], 10, 3);
Hooks::filter(Config::withFreePrefix('wp_simple_booking_calendar_update_event'), [WpSimpleBookingCalendarProHelper::class, 'updateEvent'], 10, 3);
Hooks::filter(Config::withFreePrefix('wp_simple_booking_calendar_delete_event'), [WpSimpleBookingCalendarProHelper::class, 'deleteEvent'], 10, 2);
Hooks::filter(Config::withFreePrefix('wp_simple_booking_calendar_delete_event_by_date'), [WpSimpleBookingCalendarProHelper::class, 'deleteEventByDate'], 10, 2);
Hooks::filter(Config::withFreePrefix('wp_simple_booking_calendar_create_legend_item'), [WpSimpleBookingCalendarProHelper::class, 'createLegendItem'], 10, 3);
Hooks::filter(Config::withFreePrefix('wp_simple_booking_calendar_update_legend_item'), [WpSimpleBookingCalendarProHelper::class, 'updateLegendItem'], 10, 2);
Hooks::filter(Config::withFreePrefix('wp_simple_booking_calendar_delete_legend_item'), [WpSimpleBookingCalendarProHelper::class, 'deleteLegendItem'], 10, 2);
Hooks::filter(Config::withFreePrefix('wp_simple_booking_calendar_set_default_legend_item'), [WpSimpleBookingCalendarProHelper::class, 'setDefaultLegendItem'], 10, 2);
Hooks::filter(Config::withFreePrefix('wp_simple_booking_calendar_set_legend_item_visibility'), [WpSimpleBookingCalendarProHelper::class, 'setLegendItemVisibility'], 10, 3);
Hooks::filter(Config::withFreePrefix('wp_simple_booking_calendar_update_calendar_meta'), [WpSimpleBookingCalendarProHelper::class, 'updateCalendarMeta'], 10, 2);
Hooks::filter(Config::withFreePrefix('wp_simple_booking_calendar_update_event_meta'), [WpSimpleBookingCalendarProHelper::class, 'updateEventMeta'], 10, 2);
Hooks::filter(Config::withFreePrefix('wp_simple_booking_calendar_update_legend_item_meta'), [WpSimpleBookingCalendarProHelper::class, 'updateLegendItemMeta'], 10, 2);
