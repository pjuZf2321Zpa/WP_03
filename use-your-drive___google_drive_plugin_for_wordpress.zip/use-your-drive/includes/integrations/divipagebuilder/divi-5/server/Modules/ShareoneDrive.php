<?php
/**
 * Divi 5 module for the ShareoneDrive plugin.
 */

namespace TheLion\Integrations\Divi\D5\Modules;

defined('ABSPATH') || exit;

final class ShareoneDrive extends AbstractShortcodeModule
{
    protected const SLUG = 'shareonedrive';
    protected const D4_SHORTCODE = 'wpcp_shareonedrive';
}
