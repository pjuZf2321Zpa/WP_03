<?php

namespace MasterStudy\Lms\Pro\addons\google_classrooms\Admin\Repositories;

use RuntimeException;
use WP_Query;

final class ClassroomsRepository {
	private const POST_TYPE         = 'stm-g-classrooms';
	private const ERROR_BAD_REQUEST = 400;
	private const ERROR_FORBIDDEN   = 403;
	private const MAX_PER_PAGE      = 100;
	private const ALLOWED_STATUSES  = array( 'publish', 'pending', 'draft', 'trash', 'private' );

	public function get_list( array $params ): array {
		$per_page = min( self::MAX_PER_PAGE, max( 1, (int) ( $params['per_page'] ?? 10 ) ) );
		$page     = max( 1, (int) ( $params['page'] ?? 1 ) );
		$search   = isset( $params['search'] ) ? trim( (string) $params['search'] ) : '';
		$status   = isset( $params['status'] ) ? (string) $params['status'] : 'any';

		$query_args = array(
			'post_type'              => self::POST_TYPE,
			'post_status'            => 'any' === $status ? self::ALLOWED_STATUSES : $status,
			'ignore_sticky_posts'    => true,
			'posts_per_page'         => $per_page,
			'paged'                  => $page,
			'no_found_rows'          => false,
			'update_post_meta_cache' => false,
			'update_post_term_cache' => false,
		);

		if ( '' !== $search ) {
			$query_args['s'] = $search;
		}

		$post_type = get_post_type_object( self::POST_TYPE );
		if ( $post_type && ! current_user_can( $post_type->cap->edit_others_posts ) ) {
			$query_args['author'] = get_current_user_id();
		}

		$date_range = isset( $params['date_range'] ) ? trim( (string) $params['date_range'] ) : '';
		if ( '' !== $date_range ) {
			$dates = explode( ',', $date_range );
			$from  = ! empty( $dates[0] ) ? trim( $dates[0] ) : '';
			$end   = ! empty( $dates[1] ) ? trim( $dates[1] ) : '';

			if ( $from || $end ) {
				$date_query = array(
					'inclusive' => true,
					'column'    => 'post_date',
				);

				if ( $from ) {
					$date_query['after'] = $from . ' 00:00:00';
				}

				if ( $end ) {
					$date_query['before'] = $end . ' 23:59:59';
				}

				$query_args['date_query'] = array( $date_query );
			}
		}

		$sort = isset( $params['sort'] ) ? trim( (string) $params['sort'] ) : '';
		if ( '' !== $sort && class_exists( 'STM_LMS_Helpers' ) ) {
			$sort_params = \STM_LMS_Helpers::get_sort_params_by_string( $sort );
			$key         = $sort_params['key'] ?? '';
			$direction   = strtoupper( (string) ( $sort_params['direction'] ?? 'desc' ) );
			$direction   = in_array( $direction, array( 'ASC', 'DESC' ), true ) ? $direction : 'DESC';

			switch ( $key ) {
				case 'title':
					$query_args['orderby'] = 'title';
					$query_args['order']   = $direction;
					break;
				case 'date':
				default:
					$query_args['orderby'] = 'date';
					$query_args['order']   = $direction;
			}
		} else {
			$query_args['orderby'] = 'date';
			$query_args['order']   = 'DESC';
		}

		$query = new WP_Query( $query_args );

		return array(
			'posts'        => $query->posts,
			'pages'        => (int) $query->max_num_pages,
			'current_page' => $page,
			'total'        => (int) $query->found_posts,
		);
	}

	public function create( array $data ): int {
		$this->assert_can_create();

		$post_id = wp_insert_post(
			array(
				'post_title'   => sanitize_text_field( $data['post_title'] ?? '' ),
				'post_content' => wp_kses_post( $data['post_content'] ?? '' ),
				'post_status'  => 'publish',
				'post_type'    => self::POST_TYPE,
				'post_author'  => get_current_user_id(),
			),
			true
		);

		if ( is_wp_error( $post_id ) ) {
			throw new RuntimeException( $post_id->get_error_message(), self::ERROR_BAD_REQUEST );
		}

		return (int) $post_id;
	}

	public function update( int $id, array $data ): void {
		if ( ! $this->exists( $id ) ) {
			throw new RuntimeException(
				esc_html__( 'Invalid classroom provided for update.', 'masterstudy-lms-learning-management-system-pro' ),
				self::ERROR_BAD_REQUEST
			);
		}

		$this->assert_can_edit( $id );

		$post_data = array(
			'ID' => $id,
		);

		if ( isset( $data['post_title'] ) ) {
			$post_data['post_title'] = sanitize_text_field( $data['post_title'] );
		}

		if ( isset( $data['post_content'] ) ) {
			$post_data['post_content'] = wp_kses_post( $data['post_content'] );
		}

		$updated = wp_update_post( $post_data, true );

		if ( is_wp_error( $updated ) ) {
			throw new RuntimeException( $updated->get_error_message(), self::ERROR_BAD_REQUEST );
		}
	}

	public function delete( int $id ): void {
		if ( ! $this->exists( $id ) ) {
			throw new RuntimeException(
				esc_html__( 'Invalid classroom provided for delete.', 'masterstudy-lms-learning-management-system-pro' ),
				self::ERROR_BAD_REQUEST
			);
		}

		$this->assert_can_delete( $id );

		$result = wp_delete_post( $id, true );

		if ( false === $result || null === $result ) {
			throw new RuntimeException(
				sprintf(
					/* translators: %d: classroom ID. */
					esc_html__( 'Unable to delete classroom %d.', 'masterstudy-lms-learning-management-system-pro' ),
					$id
				)
			);
		}
	}

	public function bulk_delete( array $items ): void {
		foreach ( $items as $item ) {
			$id = $this->resolve_id( $item );

			if ( ! $id || self::POST_TYPE !== get_post_type( $id ) ) {
				throw new RuntimeException(
					esc_html__( 'Invalid classroom provided for bulk delete.', 'masterstudy-lms-learning-management-system-pro' ),
					self::ERROR_BAD_REQUEST
				);
			}

			$this->assert_can_delete( $id );

			$result = wp_delete_post( $id, true );

			if ( false === $result || null === $result ) {
				throw new RuntimeException(
					sprintf(
						/* translators: %d: classroom ID. */
						esc_html__( 'Unable to delete classroom %d.', 'masterstudy-lms-learning-management-system-pro' ),
						$id
					)
				);
			}
		}
	}

	public function exists( int $id ): bool {
		$post = get_post( $id );

		return null !== $post && self::POST_TYPE === $post->post_type;
	}

	private function assert_can_create(): void {
		$post_type_object = get_post_type_object( self::POST_TYPE );

		if ( empty( $post_type_object ) ) {
			throw new RuntimeException(
				esc_html__( 'You do not have permission to create classrooms.', 'masterstudy-lms-learning-management-system-pro' ),
				self::ERROR_FORBIDDEN
			);
		}

		$capability = $post_type_object->cap->create_posts ?? $post_type_object->cap->edit_posts ?? 'edit_posts';

		if ( ! current_user_can( $capability ) && ! current_user_can( 'stm_lms_instructor' ) ) {
			throw new RuntimeException(
				esc_html__( 'You do not have permission to create classrooms.', 'masterstudy-lms-learning-management-system-pro' ),
				self::ERROR_FORBIDDEN
			);
		}
	}

	private function assert_can_edit( int $id ): void {
		if ( ! current_user_can( 'edit_post', $id ) && ! $this->is_current_instructor_author( $id ) ) {
			throw new RuntimeException(
				esc_html__( 'You do not have permission to edit this classroom.', 'masterstudy-lms-learning-management-system-pro' ),
				self::ERROR_FORBIDDEN
			);
		}
	}

	private function assert_can_delete( int $id ): void {
		if ( ! current_user_can( 'delete_post', $id ) && ! $this->is_current_instructor_author( $id ) ) {
			throw new RuntimeException(
				esc_html__( 'You do not have permission to delete this classroom.', 'masterstudy-lms-learning-management-system-pro' ),
				self::ERROR_FORBIDDEN
			);
		}
	}

	private function is_current_instructor_author( int $id ): bool {
		$post = get_post( $id );

		return null !== $post
			&& self::POST_TYPE === $post->post_type
			&& current_user_can( 'stm_lms_instructor' )
			&& get_current_user_id() === (int) $post->post_author;
	}

	/**
	 * @param mixed $item
	 */
	private function resolve_id( $item ): int {
		if ( is_numeric( $item ) ) {
			return (int) $item;
		}

		if ( is_array( $item ) && isset( $item['id'] ) ) {
			return (int) $item['id'];
		}

		return 0;
	}
}
