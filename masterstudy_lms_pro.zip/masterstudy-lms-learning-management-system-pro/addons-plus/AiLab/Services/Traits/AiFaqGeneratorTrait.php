<?php

namespace MasterStudy\Lms\Pro\AddonsPlus\AiLab\Services\Traits;

use MasterStudy\Lms\Pro\AddonsPlus\AiLab\Services\OpenAi\Model;
use MasterStudy\Lms\Pro\AddonsPlus\AiLab\Services\OpenAi\Queries\QueryFactory;
use MasterStudy\Lms\Pro\AddonsPlus\AiLab\Utility\JsonResponseParser;
use MasterStudy\Lms\Pro\AddonsPlus\AiLab\Utility\ResponseTextParser;

trait AiFaqGeneratorTrait {
	private string $prompt;
	private int $words_limit;
	private int $count;
	private string $tone;
	private string $language;

	public function generate_faq( string $prompt, array $params = array() ): array {
		$this->prompt      = $prompt;
		$this->words_limit = $params['words_limit'];
		$this->count       = $params['count'];
		$this->tone        = $params['tone'];
		$this->language    = $params['language'];

		try {
			return $this->request_faq();
		} catch ( \Exception $e ) {
			throw new \Exception( $e->getMessage() );
		}
	}

	private function request_faq( ?string $model = null ): array {
		$model        = $model ?? $this->options->get( 'text_model' );
		$query_params = array(
			'max_results' => 1,
			'max_tokens'  => $this->get_gemini_safe_max_tokens( $this->options->get( 'generator.content.tokens' ), 2048 ),
			'model'       => $model,
		);

		if ( $this->is_gemini_provider() ) {
			$query_params['reasoning_effort'] = 'minimal';
		}

		$response = $this->exec(
			QueryFactory::text(
				array(
					array(
						'role'    => 'system',
						'content' => "Generate {$this->count} frequently asked questions and answers. Make answers clear and concise. Language: {$this->language}. Return only valid JSON.",
					),
					array(
						'role'    => 'user',
						'content' => "Generate {$this->count} frequently asked question and answer about: {$this->prompt}. \n"
						. "Words limit for each answer: {$this->words_limit}. Language: {$this->language}.\n"
						. "Return only a valid JSON array (without markdown or comments) where each item has keys 'question' and 'answer':\n"
						. "- question: string\n"
						. '- answer: string',
					),
				),
				$query_params
			)
		);

		$content = ResponseTextParser::extract_first_text( $response );

		try {
			return JsonResponseParser::parse_faq( $content, $this->count );
		} catch ( \Exception $e ) {
			if ( $this->is_gemini_provider() && Model::GEMINI_35_FLASH === $model ) {
				return $this->request_faq( Model::GEMINI_31_FLASH_LITE );
			}

			throw $e;
		}
	}
}
