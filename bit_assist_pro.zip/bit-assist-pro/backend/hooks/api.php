<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\AssistPro\Deps\BitApps\WPKit\Http\Router\Route;

Route::group(function () {
    //
});
