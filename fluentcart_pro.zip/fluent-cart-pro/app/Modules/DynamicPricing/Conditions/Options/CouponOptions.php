<?php

namespace FluentCartPro\App\Modules\DynamicPricing\Conditions\Options;

use FluentCart\App\Models\Coupon;
use FluentCart\App\Services\Filter\CouponFilter;
use FluentCart\App\Services\Permission\PermissionManager;
use FluentCart\Framework\Support\Arr;
use FluentCartPro\App\Modules\DynamicPricing\Conditions\ConditionRegistry;

/**
 * Coupons for the condition builder's remote select.
 *
 * Labelled by code rather than title, matching every other coupon picker in the
 * admin — the code is what an administrator recognises and what a customer
 * types.
 *
 * @package FluentCartPro\App\Modules\DynamicPricing
 *
 * @version 1.0.0
 */
class CouponOptions extends OptionSource
{
    /**
     * The `data_key` a condition attribute names to reach this list.
     *
     * @var string
     */
    protected $key = 'dynamic_pricing_coupons';

    /**
     * Coupons as flat `{value, label}` options.
     *
     * CouponFilter parses `search`, `include_ids` and `limit` out of the args
     * the controller builds, so type-to-search and re-showing an already saved
     * selection both work without anything further here.
     *
     * @param array $options
     * @param array $args
     * @return array
     */
    public function options($options, $args)
    {
        $includeIds = array_filter(array_map('intval', (array)Arr::get($args, 'include_ids', [])));

        /*
         * Remove duplicate IDs and limit the list to the maximum number of values
         * allowed for a select condition. This keeps the query and response size
         * bounded while allowing the full range of valid saved selections.
         */
        $includeIds = array_slice(array_unique($includeIds), 0, ConditionRegistry::MAX_SELECT_VALUES);

        /*
         * Normalised before the filter reads it. The controller sends an empty
         * string when the parameter is absent, which BaseFilter explodes into
         * [''] — non-empty, so it then requires `id IN ('')` alongside the
         * search and every search comes back with nothing.
         */
        $args['include_ids'] = $includeIds;

        $args['limit'] = $this->boundedLimit(Arr::get($args, 'limit'));

        $coupons = CouponFilter::make($args)->get()->map(function ($coupon) {
            return [
                'value' => (int)$coupon->id,
                'label' => $coupon->code,
            ];
        })->toArray();

        return $this->withPinned($coupons, $includeIds);
    }

    /**
     * Both bars, not either: the data is the coupon list, and the reason this
     * key exists at all is the pricing rule editor.
     *
     * @param bool $hasPermission
     * @return bool
     */
    public function canRead($hasPermission)
    {
        return PermissionManager::hasPermission('coupons/view')
            && PermissionManager::hasPermission('dynamic_pricing/view');
    }

    /**
     * Puts back any already-selected coupon the page of results does not
     * contain.
     *
     * include_ids is meant to guarantee those rows, but BaseFilter widens the
     * query to `OR id IS NOT NULL` when there is no search term, so the limit
     * trims them off again exactly as if the ids had never been sent. A rule
     * saved against a coupon far down the list would then reopen showing a bare
     * id instead of its code.
     *
     * @param array $coupons
     * @param array $includeIds
     * @return array
     */
    protected function withPinned($coupons, $includeIds)
    {
        if (!$includeIds) {
            return $coupons;
        }

        $missing = array_diff($includeIds, array_column($coupons, 'value'));

        if (!$missing) {
            return $coupons;
        }

        $pinned = Coupon::query()->whereIn('id', $missing)->get()->map(function ($coupon) {
            return [
                'value' => (int)$coupon->id,
                'label' => $coupon->code,
            ];
        })->toArray();

        // Ahead of the rest: a chosen row belongs at the top of its own list.
        return array_merge($pinned, $coupons);
    }
}
