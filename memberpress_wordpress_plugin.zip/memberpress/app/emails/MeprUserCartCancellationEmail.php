<?php

if (!defined('ABSPATH')) {
    die('You are not allowed to call this page directly.');
}

/**
 * Cart order cancellation email sent to the customer.
 *
 * Sends one order-level cancellation notice when a cart order is cancelled
 * (from the admin cancel-order flow), optionally including a refunded amount.
 */
class MeprUserCartCancellationEmail extends MeprBaseOptionsUserEmail
{
    /**
     * Per-cancellation context (reason, refunded amount) set before send().
     *
     * @var array
     */
    protected $context = [];

    /**
     * Set the default enabled, title, subject & body.
     *
     * @param  array $args The args.
     * @return void
     */
    public function set_defaults($args = [])
    {
        $this->title       = __('<b>Cart Order Cancellation</b> Notice', 'memberpress');
        $this->description = __('Sent to a customer when their cart order is cancelled.', 'memberpress');
        $this->ui_order    = 5;

        $enabled = $use_template = $this->show_form = true;
        $subject = __('Your Order Was Cancelled — Order #{$order_id}', 'memberpress');
        $body    = $this->body_partial();

        $this->defaults  = compact('enabled', 'subject', 'body', 'use_template');
        $this->variables = self::get_cart_cancellation_email_vars();
    }

    /**
     * Get the body partial for the email.
     *
     * @param  array $vars Optional variables to pass to the view.
     * @return string The body partial HTML.
     */
    public function body_partial($vars = [])
    {
        return MeprView::get_string('/emails/user-cart-cancellation', $vars);
    }

    /**
     * Set the per-cancellation context before send().
     *
     * @param  array $context Context {reason, refunded_amount}.
     * @return void
     */
    public function set_context(array $context)
    {
        $this->context = $context;
    }

    /**
     * Send the cart cancellation email for the given order.
     *
     * @param  MeprOrder    $order        The cancelled cart order.
     * @param  string|false $subject      Subject override, or false for the stored default.
     * @param  string|false $body         Body override, or false for the stored default.
     * @param  boolean|null $use_template Whether to wrap in the email template, or null for the default.
     * @param  string       $content_type The content type of the email.
     * @return void
     */
    public function send($order = [], $subject = false, $body = false, $use_template = null, $content_type = 'html')
    {
        if (!($order instanceof MeprOrder)) {
            parent::send($order, $subject, $body, $use_template, $content_type);
            return;
        }

        if (!$this->enabled()) {
            return;
        }

        $user     = new MeprUser($order->user_id);
        $this->to = $user->user_email;

        $vars = self::build_cart_cancellation_vars($order, $user, $this->context);

        $formatted_subject = MeprUtils::replace_vals($this->get_stored_field('subject'), $vars);
        $formatted_body    = MeprUtils::replace_vals($this->get_stored_field('body'), $vars);

        $send_params = MeprHooks::apply_filters('mepr_cart_cancellation_email_params', [], $order, $this);

        parent::send($send_params, $formatted_subject, $formatted_body, $use_template, $content_type);
    }

    /**
     * Get the available email template variables.
     *
     * @return array Variable name => description map.
     */
    public static function get_cart_cancellation_email_vars()
    {
        return [
            '{$user_first_name}'    => __('User First Name', 'memberpress'),
            '{$user_last_name}'     => __('User Last Name', 'memberpress'),
            '{$user_email}'         => __('User Email', 'memberpress'),
            '{$order_id}'           => __('Order ID', 'memberpress'),
            '{$order_total}'        => __('Order Total', 'memberpress'),
            '{$order_items}'        => __('Order Items (HTML table)', 'memberpress'),
            '{$cancellation_reason}' => __('Cancellation Reason', 'memberpress'),
            '{$refunded_amount}'    => __('Refunded Amount', 'memberpress'),
            '{$cancellation_date}'  => __('Cancellation Date', 'memberpress'),
        ];
    }

    /**
     * Build the template variable replacement map for a cancellation.
     *
     * @param  MeprOrder $order   The cart order.
     * @param  MeprUser  $user    The purchasing user.
     * @param  array     $context The per-cancellation context.
     * @return array
     */
    public static function build_cart_cancellation_vars($order, $user, array $context)
    {
        $currency        = $order->currency;
        $refunded_amount = (float) ($context['refunded_amount'] ?? 0);
        $reason          = (string) ($context['reason'] ?? '');
        $transactions    = MeprTransaction::get_all_by_order_id_for_display($order->id);

        $items_html = self::build_items_table($transactions, $order);

        $vars = [
            'user_first_name'     => $user->first_name ?: '',
            'user_last_name'      => $user->last_name ?: '',
            'user_email'          => $user->user_email,
            'order_id'            => $order->id,
            'order_total'         => MeprAppHelper::format_currency($order->total, true, false, false, $currency),
            'order_items'         => $items_html,
            'cancellation_reason' => $reason,
            'refunded_amount'     => $refunded_amount > 0
                ? MeprAppHelper::format_currency($refunded_amount, true, false, false, $currency)
                : '',
            'cancellation_date'   => MeprAppHelper::format_date(MeprUtils::db_now(), ''),
        ];

        return MeprUserCartReceiptEmail::escape_vars($vars);
    }

    /**
     * Build an HTML table of the order's line items.
     *
     * @param  MeprTransaction[] $transactions The order's transactions.
     * @param  MeprOrder         $order        The parent cart order.
     * @return string HTML table string.
     */
    public static function build_items_table($transactions, $order)
    {
        $currency = $order->currency;
        $fmt      = fn($n) => esc_html(MeprAppHelper::format_currency($n, true, false, false, $currency));

        $rows = array_map(function ($txn) use ($fmt) {
            $product    = new MeprProduct($txn->product_id);
            $qty        = (int) $txn->get_meta('_mepr_quantity', true) ?: 1;
            $unit_price = (float) $txn->amount / $qty;

            return [
                'name'       => esc_html($product->post_title),
                'qty'        => (int) $qty,
                'unit_price' => $fmt($unit_price),
                'total'      => $fmt($txn->amount),
            ];
        }, $transactions);

        $subtotal = (float) $order->subtotal > 0       ? $fmt($order->subtotal)       : null;
        $discount = (float) $order->discount_total > 0 ? $fmt($order->discount_total) : null;
        $tax      = (float) $order->tax_total > 0      ? $fmt($order->tax_total)      : null;
        $shipping = (float) $order->shipping_total > 0 ? $fmt($order->shipping_total) : null;
        $total    = $fmt($order->total);

        return MeprView::get_string('/emails/partials/cart-receipt-items-table', get_defined_vars());
    }
}
