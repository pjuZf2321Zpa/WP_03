<?php
/**
 * Shortcode value decoding and Migrator cache maintenance.
 */

namespace TheLion\Integrations\Divi\D5;

defined('ABSPATH') || exit;

final class Conversion
{
    /**
     * Divi 4 placeholder => real character.
     *
     * @var array<string, string>
     */
    private const PLACEHOLDERS = [
        '%91' => '[',
        '%93' => ']',
        '%22' => '"',
    ];

    /**
     * Transient holding the Migrator's cached module compatibility lists.
     */
    private const MIGRATOR_CACHE = 'et_d5_readiness_used_modules';

    private const FLUSHED_OPTION = 'wpcp_divi_migrator_cache_version';

    public static function init(): void
    {
        add_action('admin_init', [self::class, 'flush_migrator_cache_on_update']);
    }

    /**
     * Drop the Migrator's cached lists after an update.
     *
     * A module that gained a conversion outline in this release otherwise keeps
     * showing as unconvertible until the cache expires.
     */
    public static function flush_migrator_cache_on_update(): void
    {
        if (WPCP_DIVI_EXTENSION_VERSION === get_option(self::FLUSHED_OPTION)) {
            return;
        }

        delete_transient(self::MIGRATOR_CACHE);
        update_option(self::FLUSHED_OPTION, WPCP_DIVI_EXTENSION_VERSION, false);
    }

    /**
     * Turn a stored attribute value into a runnable shortcode.
     *
     * Divi 4 stores nested shortcodes as `%91useyourdrive module=%225154%22%93`; the
     * Divi 5 Migrator rewrites those brackets as HTML entities. Both forms are handled
     * here, and an already decoded value passes through unchanged.
     */
    public static function decode_shortcode($value): string
    {
        if (!is_scalar($value)) {
            return '';
        }

        $decoded = str_replace(array_keys(self::PLACEHOLDERS), array_values(self::PLACEHOLDERS), (string) $value);

        return trim(html_entity_decode($decoded, ENT_QUOTES, 'UTF-8'));
    }
}
