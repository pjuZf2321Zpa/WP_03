<?php
/**
 * @author WP Cloud Plugins
 * @copyright Copyright (c) 2023, WP Cloud Plugins
 *
 * @since       3.4.5
 * @see https://www.wpcloudplugins.com
 */

namespace TheLion\UseyourDrive;

defined('ABSPATH') || exit;

// Enqueue only our scripts and styles
add_action('wp_print_scripts', function () {
    global $wp_scripts;
    $wp_scripts->queue = [];
    wp_enqueue_script('UseyourDrive');
}, 1000);
add_action('wp_print_styles', function () {
    global $wp_styles;
    $wp_styles->queue = [];
    wp_enqueue_style('UseyourDrive');
}, 1000);

// Load core scripts and styles
Core::instance()->load_scripts();
Core::instance()->load_styles();

?><!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="Content-Security-Policy" content="default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; font-src 'self' data:; connect-src *; worker-src blob: 'self';">
    <title>PDF Viewer</title>

    <!-- Dependencies -->
    <?php wp_print_styles(); ?>
    <?php wp_print_scripts(); ?>

    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        html,
        body {
            width: 100%;
            height: 100%;
            overflow: hidden;
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
        }

        #pdf-viewer-container {
            width: 100%;
            height: 100%;
            display: flex;
            flex-direction: column;
        }

        /* Loading indicator */
        .loading-indicator {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            text-align: center;
            color: #666;
        }

        .loading-indicator .eva {
            font-size: 48px;
            margin-bottom: 16px;
        }

        /* Error message styling */
        .error-message {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            text-align: center;
            color: #666;
            padding: 40px;
            max-width: 400px;
        }

        .error-message h2 {
            font-size: 18px;
            margin-bottom: 8px;
            color: #333;
        }

        .error-message p {
            font-size: 14px;
            opacity: 0.7;
        }
    </style>
</head>

<body>
    <main id="pdf-viewer-container" class="wpcp-lightbox">
        <div class="loading-indicator">
            <i class="eva eva-loader-outline eva-spin"></i>
            <p><?php esc_attr_e('Loading PDF viewer...', 'wpcloudplugins'); ?></p>
        </div>
    </main>

    <script>
        let pdfUrl  = '<?php echo $temporarily_link; ?>' || null;
        (function () {
            // Show error message
            function showError(title, message) {
                var container = document.getElementById('pdf-viewer-container');
                container.innerHTML = '';

                var wrapper = document.createElement('div');
                wrapper.className = 'error-message';

                var heading = document.createElement('h2');
                heading.textContent = title;

                var paragraph = document.createElement('p');
                paragraph.textContent = message;

                wrapper.appendChild(heading);
                wrapper.appendChild(paragraph);
                container.appendChild(wrapper);
            }

            if (!pdfUrl) {
                showError('<?php esc_attr_e('No PDF URL', 'wpcloudplugins'); ?>', '<?php esc_attr_e('Please provide a PDF URL.', 'wpcloudplugins'); ?>');
                return;
            }
            // Wait for DOM to be ready
            jQuery(document).ready(function ($) {
                // Check if WPCPPDFViewer is available
                if ($.fn.WPCPPDFViewer === undefined) {
                    showError('<?php esc_attr_e('PDF Viewer not loaded', 'wpcloudplugins'); ?>', '<?php esc_attr_e('Failed to load PDF Viewer widget.', 'wpcloudplugins'); ?>');
                    return;
                }

                // Get vendor path (relative to viewer.html)
                // Initialize PDF viewer
                $('#pdf-viewer-container').WPCPPDFViewer({
                    pdfUrl: pdfUrl,
                    listtoken: 'standalone',
                    theme: 'light',
                    vendorPath: '<?php echo USEYOURDRIVE_ROOTPATH; ?>/vendors/pdfjs/',
                    canPrint: <?php echo User::can_download() ? 'true' : 'false'; ?>,
                });
                
                // Remove loading indicator after viewer is initialized
                $('.loading-indicator').fadeOut(300);
            });
        })();
    </script>
</body>

</html>