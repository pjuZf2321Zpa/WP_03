<?php

namespace BitApps\IntegrationsPro\Actions\WhatsApp;

use BitApps\IntegrationsPro\Core\Util\Common;
use CURLFile;

class WhatsAppHelperPro
{
    public static function sendTextMessages($body, $fieldValues, $numberId, $token, $phoneNumber)
    {
        $httpHelperClass = bit_integrations_get_class('Core\\Util\\HttpHelper');

        if (empty($body) || empty($fieldValues) || empty($numberId) || empty($token) || empty($phoneNumber)) {
            return (object) ['error' => 'Required params are empty!'];
        }

        $msg = Common::replaceFieldWithValue($body, $fieldValues);
        $messagesBody = str_replace(['<p>', '</p>'], ' ', $msg);

        $apiEndPoint = "https://graph.facebook.com/v20.0/{$numberId}/messages";
        $sanitizingSpace = rtrim($messagesBody, '&nbsp; ');
        $planMessage = strip_tags($sanitizingSpace);

        $data = [
            'messaging_product' => 'whatsapp',
            'recipient_type'    => 'individual',
            'to'                => "{$phoneNumber}",
            'type'              => 'text',
            'text'              => ['body' => $planMessage]
        ];

        return $httpHelperClass::post($apiEndPoint, $data, static::setHeaders($token));
    }

    public static function sendMediaMessages($integrationDetails, $fieldValues, $numberId, $token, $phoneNumber)
    {
        $httpHelperClass = bit_integrations_get_class('Core\\Util\\HttpHelper');

        if (empty($integrationDetails) || empty($integrationDetails->mediaType) || empty($integrationDetails->upload_field) || empty($fieldValues) || empty($numberId) || empty($token) || empty($phoneNumber)) {
            return (object) ['error' => 'Required params are empty!'];
        }

        $mediaType = $integrationDetails->mediaType;
        $media = static::upload_file_to_whatsapp($numberId, $token, $fieldValues[$integrationDetails->upload_field], $mediaType);

        if (!isset($media->id) || isset($media->error) || is_wp_error($media)) {
            return $media;
        }

        $dataFinal = isset($integrationDetails->media_field_map)
            ? static::generateReqDataFromFieldMap($fieldValues, $integrationDetails->media_field_map)
            : [];

        $apiEndPoint = "https://graph.facebook.com/v20.0/{$numberId}/messages";
        $type = explode('/', $mediaType);
        $type = \in_array($type[0], ['text', 'application']) ? 'document' : $type[0];

        $data = [
            'messaging_product' => 'whatsapp',
            'recipient_type'    => 'individual',
            'to'                => "{$phoneNumber}",
            'type'              => $type,
            $type               => array_merge($dataFinal, ['id' => $media->id])
        ];

        return $httpHelperClass::post($apiEndPoint, $data, static::setHeaders($token));
    }

    public static function sendContactMessages($integrationDetails, $fieldValues, $numberId, $token, $phoneNumber)
    {
        $httpHelperClass = bit_integrations_get_class('Core\\Util\\HttpHelper');

        if (empty($integrationDetails) || empty($integrationDetails->contact_field_map) || empty($fieldValues) || empty($numberId) || empty($token) || empty($phoneNumber)) {
            return (object) ['error' => 'Required params are empty!'];
        }

        $dataFinal = static::generateContactFieldMap($fieldValues, $integrationDetails->contact_field_map);
        $apiEndPoint = "https://graph.facebook.com/v20.0/{$numberId}/messages";
        $data = [
            'messaging_product' => 'whatsapp',
            'recipient_type'    => 'individual',
            'to'                => "{$phoneNumber}",
            'type'              => 'contacts',
            'contacts'          => [$dataFinal]
        ];

        return $httpHelperClass::post($apiEndPoint, $data, static::setHeaders($token));
    }

    private static function upload_file_to_whatsapp($numberId, $token, $file, $file_type = 'image/jpeg')
    {
        $httpHelperClass = bit_integrations_get_class('Core\\Util\\HttpHelper');

        $apiEndPoint = "https://graph.facebook.com/v20.0/{$numberId}/media";
        $file_path = static::extractTheFile($file);

        $data = [
            'file'              => new CURLFile(Common::filePath($file_path), $file_type, basename($file_path)),
            'type'              => 'image/png',
            'messaging_product' => 'whatsapp'
        ];

        return $httpHelperClass::post($apiEndPoint, $data, static::setHeaders($token, 'multipart/form-data'));
    }

    private static function extractTheFile($files)
    {
        if (\is_array($files)) {
            foreach ($files as $file) {
                if (\is_array($file)) {
                    return static::extractTheFile($file);
                }

                return $file;
            }
        } else {
            return $files;
        }
    }

    /**
     * Builds template components out of the mapped placeholders.
     *
     * Placeholder keys are `header.{token}`, `body.{token}` and `button.{index}.{token}`.
     *
     * @param array $components   components resolved so far by the free plugin
     * @param array $placeholders placeholder key => mapped value
     *
     * @return array
     */
    public static function buildTemplateComponents($components, $placeholders)
    {
        if (!\is_array($placeholders) || $placeholders === []) {
            return \is_array($components) ? $components : [];
        }

        $sections = ['header' => [], 'body' => []];
        $buttons = [];

        foreach ($placeholders as $placeholder => $value) {
            $segments = explode('.', (string) $placeholder);

            if (\count($segments) < 2) {
                continue;
            }

            $section = array_shift($segments);

            if ($section === 'button') {
                if (\count($segments) < 2) {
                    continue;
                }

                $index = array_shift($segments);
                $buttons[$index][array_shift($segments)] = $value;

                continue;
            }

            if (!isset($sections[$section])) {
                continue;
            }

            $sections[$section][array_shift($segments)] = $value;
        }

        $builtComponents = \is_array($components) ? $components : [];

        foreach ($sections as $type => $params) {
            if ($params === []) {
                continue;
            }

            $builtComponents[] = ['type' => $type, 'parameters' => static::buildTextParameters($params)];
        }

        foreach ($buttons as $index => $params) {
            $builtComponents[] = [
                'type'       => 'button',
                'sub_type'   => 'url',
                'index'      => (string) $index,
                'parameters' => static::buildTextParameters($params)
            ];
        }

        return $builtComponents;
    }

    /**
     * Converts a token => value map into WhatsApp text parameters,
     * keeping positional placeholders in their numeric order.
     *
     * @param array $params
     *
     * @return array
     */
    private static function buildTextParameters($params)
    {
        uksort($params, function ($a, $b) {
            if (is_numeric($a) && is_numeric($b)) {
                return (int) $a <=> (int) $b;
            }

            return strcmp((string) $a, (string) $b);
        });

        $parameters = [];

        foreach ($params as $token => $value) {
            $parameter = ['type' => 'text', 'text' => (string) $value];

            if (!is_numeric($token)) {
                $parameter['parameter_name'] = $token;
            }

            $parameters[] = $parameter;
        }

        return $parameters;
    }

    private static function generateReqDataFromFieldMap($data, $fieldMap)
    {
        $dataFinal = [];

        foreach ($fieldMap as $key => $value) {
            $triggerValue = $value->formField;
            $actionValue = $value->whatsAppFormField;
            if ($triggerValue === 'custom') {
                $dataFinal[$actionValue] = Common::replaceFieldWithValue($value->customValue, $data);
            } elseif (!\is_null($data[$triggerValue])) {
                $dataFinal[$actionValue] = $data[$triggerValue];
            }
        }

        return $dataFinal;
    }

    private static function generateContactFieldMap($data, $fieldMap)
    {
        $dataFinal = [];
        $fieldValues = static::generateReqDataFromFieldMap($data, $fieldMap);
        $dataFinal['name'] = array_filter([
            'prefix'      => $fieldValues['prefix'] ?? '',
            'first_name'  => $fieldValues['first_name'] ?? '',
            'middle_name' => $fieldValues['middle_name'] ?? '',
            'last_name'   => $fieldValues['last_name'] ?? '',
            'suffix'      => $fieldValues['suffix'] ?? ''
        ]);

        $dataFinal['name']['formatted_name'] = trim(implode(' ', $dataFinal['name']));
        $addressTypes = ['HOME', 'WORK'];

        foreach ($addressTypes as $type) {
            $address = [
                'street'       => $fieldValues["{$type}_street"] ?? '',
                'city'         => $fieldValues["{$type}_city"] ?? '',
                'state'        => $fieldValues["{$type}_state"] ?? '',
                'zip'          => $fieldValues["{$type}_zip"] ?? '',
                'country'      => $fieldValues["{$type}_country"] ?? '',
                'country_code' => $fieldValues["{$type}_country_code"] ?? ''
            ];

            if (array_filter($address)) {
                $address['type'] = $type;
                $dataFinal['addresses'][] = array_filter($address);
            }
        }

        foreach ($fieldValues as $key => $value) {
            if (!empty($value)) {
                if (strpos($key, '_email') !== false) {
                    $type = explode('_', $key)[0];

                    $dataFinal['emails'][] = [
                        'email' => $value,
                        'type'  => $type
                    ];
                } elseif (strpos($key, '_phone') !== false) {
                    $type = explode('_', $key)[0];

                    $dataFinal['phones'][] = [
                        'phone' => $value,
                        'type'  => $type
                    ];
                } elseif (\in_array($key, ['company', 'department', 'title'])) {
                    $dataFinal['org'][$key] = $value;
                } elseif ($key == 'birthday') {
                    $dataFinal[$key] = $value;
                }
            }
        }

        return $dataFinal;
    }

    private static function setHeaders($token, $contentType = 'application/json')
    {
        return
            [
                'Authorization' => "Bearer {$token}",
                'Content-Type'  => $contentType,
            ];
    }
}
