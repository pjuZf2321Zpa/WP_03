<?php

if (! defined('ABSPATH')) {
	exit; // Exit if accessed directly.
}
?>
<div v-if="selected === 'app-4'" id="cff-panel-advanced" role="tabpanel" aria-labelledby="cff-settings-tab-advanced" tabindex="0">
    <div class="sb-tab-box sb-optimize-box sb-reset-box-style clearfix">
        <div class="tab-label">
            <h3>{{advancedTab.optimizeBox.title}}</h3>
        </div>

        <div class="cff-tab-form-field">
            <div class="sb-form-field">
                <label for="disable-resize" class="cff-checkbox">
                    <input type="checkbox" :disabled="model.feeds.gdpr !== 'no'" name="disable-resize" id="disable-resize" v-model="model.advanced.cff_disable_resize">
                    <span class="toggle-track">
                        <div class="toggle-indicator"></div>
                    </span>
                    <button type="button" class="cff-btn ml-10 optimize-image-btn" @click="clearImageResizeCache()">
                        <span v-html="clearImageResizeCacheIcon()" :class="optimizeCacheStatus" v-if="optimizeCacheStatus !== null"></span>
                        {{advancedTab.optimizeBox.reset}}
                    </button>
                </label>
                <span class="help-text">
                    {{advancedTab.optimizeBox.helpText}}
                </span>
            </div>
        </div>
    </div>
    <div class="sb-tab-box sb-clear-error-log-box sb-reset-box-style clearfix">
        <div class="tab-label">
            <h3>{{advancedTab.resetErrorBox.title}}</h3>
        </div>
        <div class="cff-tab-form-field">
        <button type="button" class="cff-btn" @click="resetErrorLog()">
                        <span v-html="resetErrorLogIcon()" :class="clearErrorLogStatus" v-if="clearErrorLogStatus !== null"></span>
                        {{advancedTab.resetErrorBox.reset}}
                    </button>
            <span class="help-text">
                {{advancedTab.resetErrorBox.helpText}}
            </span>
        </div>
    </div>
    <!--
        AC 21's Swipe View toggle.

        Placed in the ADVANCED tab, immediately above Usage Tracking, and the
        position is a judgement worth recording: this is a front-end behaviour
        change rather than a feed-content option, so it does not belong in the
        Feeds tab beside Localization and Caching; and it is opt-in with a
        blast radius (it changes the click behaviour of every Reel in every
        timeline feed on the site), which is the same shape as the other
        Advanced toggles.

        Markup copied from the Usage Tracking box verbatim, so it inherits the
        page's existing toggle styling and Vue binding conventions rather than
        introducing a second idiom.

        THE PRO GATE IS STRUCTURAL, NOT `shown-locked`. This file ships only in
        custom-facebook-feed-pro; the Free plugin is a separate codebase whose
        settings page never renders this view, so on Free the setting is simply
        ABSENT rather than shown with an upgrade prompt. That follows the
        plugin's own convention for Pro-only front-end features -- the Free
        settings page advertises Pro via its own upsell boxes, not by rendering
        disabled Pro controls -- and it is why "Free edition unchanged" is true
        by construction here.
    -->
    <div class="sb-tab-box sb-swipeview-box sb-reset-box-style clearfix">
        <div class="tab-label">
            <h3>{{advancedTab.swipeViewBox.title}}</h3>
        </div>

        <div class="cff-tab-form-field">
            <div class="sb-form-field">
                <label for="swipeview-enabled" class="cff-checkbox">
                    <input type="checkbox" name="swipeview-enabled" id="swipeview-enabled" v-model="model.advanced.swipeview_enabled">
                    <span class="toggle-track">
                        <div class="toggle-indicator"></div>
                    </span>
                </label>
                <span class="help-text" v-html="advancedTab.swipeViewBox.helpText"></span>
            </div>
        </div>
    </div>
    <div class="sb-tab-box sb-usage-box sb-reset-box-style clearfix">
        <div class="tab-label">
            <h3>{{advancedTab.usageBox.title}}</h3>
        </div>

        <div class="cff-tab-form-field">
            <div class="sb-form-field">
                <label for="usage-tracking" class="cff-checkbox">
                    <input type="checkbox" name="usage-tracking" id="usage-tracking" v-model="model.advanced.usage_tracking">
                    <span class="toggle-track">
                        <div class="toggle-indicator"></div>
                    </span>
                </label>
                <span class="help-text" v-html="advancedTab.usageBox.helpText"></span>
            </div>
        </div>
    </div>
    <div class="sb-tab-box sb-ajax-box sb-reset-box-style clearfix">
        <div class="tab-label">
            <h3>{{advancedTab.ajaxBox.title}}</h3>
        </div>

        <div class="cff-tab-form-field">
            <div class="sb-form-field">
                <label for="ajax-box-settings" class="cff-checkbox">
                    <input type="checkbox" id="ajax-box-settings" v-model="model.advanced.cff_ajax">
                    <span class="toggle-track">
                        <div class="toggle-indicator"></div>
                    </span>
                </label>
                <span class="help-text">
                    {{advancedTab.ajaxBox.helpText}}
                </span>
            </div>
        </div>
    </div>
    <div class="sb-tab-box sb-show-credit-box sb-reset-box-style clearfix">
        <div class="tab-label">
            <h3>{{advancedTab.showCreditBox.title}}</h3>
        </div>

        <div class="cff-tab-form-field">
            <div class="sb-form-field">
                <label for="show-credit" class="cff-checkbox">
                    <input type="checkbox" name="show-credit" id="show-credit" v-model="model.advanced.cff_show_credit">
                    <span class="toggle-track">
                        <div class="toggle-indicator"></div>
                    </span>
                </label>
                <span class="help-text">
                    {{advancedTab.showCreditBox.helpText}}
                </span>
            </div>
        </div>
    </div>
    <div class="sb-tab-box sb-fix-text-box sb-reset-box-style clearfix">
        <div class="tab-label">
            <h3>{{advancedTab.fixTextBox.title}}</h3>
        </div>

        <div class="cff-tab-form-field">
            <div class="sb-form-field">
                <label for="fix-text-shortening" class="cff-checkbox">
                    <input type="checkbox" name="fix-text-shortening" id="fix-text-shortening" v-model="model.advanced.cff_format_issue">
                    <span class="toggle-track">
                        <div class="toggle-indicator"></div>
                    </span>
                </label>
                <span class="help-text">
                    {{advancedTab.fixTextBox.helpText}}
                </span>
            </div>
        </div>
    </div>
    <div class="sb-tab-box sb-admin-error-box sb-reset-box-style clearfix">
        <div class="tab-label">
            <h3>{{advancedTab.jsImages.title}}</h3>
        </div>

        <div class="cff-tab-form-field">
            <div class="sb-form-field">
                <label for="enable-js-image-loading" class="cff-checkbox">
                    <input type="checkbox" name="enable-js-image-loading" id="enable-js-image-loading" v-model="model.advanced.enable_js_image_loading">
                    <span class="toggle-track">
                        <div class="toggle-indicator"></div>
                    </span>
                </label>
                <span class="help-text">
                    {{advancedTab.jsImages.helpText}}
                </span>
            </div>
        </div>
    </div>
    <div class="sb-tab-box sb-admin-error-box sb-reset-box-style clearfix">
        <div class="tab-label">
            <h3>{{advancedTab.adminErrorBox.title}}</h3>
        </div>

        <div class="cff-tab-form-field">
            <div class="sb-form-field">
                <label for="disable-admin-error" class="cff-checkbox">
                    <input type="checkbox" name="disable-admin-error" id="disable-admin-error" v-model="model.advanced.disable_admin_notice">
                    <span class="toggle-track">
                        <div class="toggle-indicator"></div>
                    </span>
                </label>
                <span class="help-text">
                    {{advancedTab.adminErrorBox.helpText}}
                </span>
            </div>
        </div>
    </div>
    <div class="sb-tab-box sb-feed-issue-box sb-reset-box-style clearfix">
        <div class="tab-label">
            <h3>{{advancedTab.feedIssueBox.title}}</h3>
        </div>

        <div class="cff-tab-form-field">
            <div class="sb-form-field">
                <label for="enable-email-report" class="cff-checkbox">
                    <input type="checkbox" name="enable-email-report" id="enable-email-report" v-model="model.advanced.enable_email_report">
                    <span class="toggle-track">
                        <div class="toggle-indicator"></div>
                    </span>
                </label>
                <div class="items-center feed-issues-fields" v-if="model.advanced.enable_email_report">
                    <span class="help-text">
                        {{advancedTab.feedIssueBox.sendReport}}
                    </span>
                    <select id="cff-send-report" class="cff-select size-sm mr-3" :aria-label="advancedTab.feedIssueBox.sendReportLabel" v-model="model.advanced.email_notification">
                        <option v-for="(name, key) in advancedTab.feedIssueBox.weekDays" :value="name.val">{{name.label}}</option>
                    </select>
                    <span class="help-text">
                        {{advancedTab.feedIssueBox.to}}
                    </span>
                    <input type="text" name="report-emails" id="report-emails" class="cff-form-field" :aria-label="advancedTab.feedIssueBox.emailLabel" :placeholder="advancedTab.feedIssueBox.placeholder" v-model="model.advanced.email_notification_addresses">
                </div>
                <div class="help-text">
                    <span v-html="advancedTab.feedIssueBox.helpText"></span>
                </div>
            </div>
        </div>
    </div>
    <div class="sb-tab-box sb-optimize-box sb-dpa-clear-box-style clearfix">
        <div class="tab-label">
            <h3>{{advancedTab.dpaClear.title}}</h3>
        </div>
        <div class="cff-tab-form-field">
            <button type="button" class="cff-btn" @click="dpaReset()">
                <span v-html="dpaResetStatusIcon()" :class="dpaResetStatus" v-if="dpaResetStatus !== null"></span>
                {{advancedTab.dpaClear.clear}}
            </button>
            <span class="help-text">
                {{advancedTab.dpaClear.helpText}}
            </span>
        </div>
    </div>
</div>
<!-- todo: this is just demo content and will be replaced once I work on this -->