<?php

namespace FluentCartPro\App\Hooks\Handlers;

use FluentCart\Api\Resource\CustomerResource;
use FluentCart\Api\StoreSettings;
use FluentCart\App\App;
use FluentCart\App\Events\Subscription\SubscriptionReactivated;
use FluentCart\App\Helpers\CartHelper;
use FluentCart\App\Helpers\Status;
use FluentCart\App\Models\OrderTransaction;
use FluentCart\App\Models\Subscription;
use FluentCart\App\Modules\MultiCurrency\Services\CartCurrency;
use FluentCart\App\Modules\MultiCurrency\Services\PriceConverter;
use FluentCart\App\Modules\Subscriptions\Services\SubscriptionService;
use FluentCart\App\Services\ProductItemService;
use FluentCart\App\Services\URL;
use FluentCart\Framework\Support\Arr;

class SubscriptionRenewalHandler
{
    public function register()
    {

        // url: /?fluent-cart=reactivate-subscription&subscription_hash=2e326b7585e71ee7e71ce92f08ab5f0d
        add_action('fluent_cart_action_reactivate-subscription', [$this, 'handleSubscriptionReactivationRedirect'], 10, 1);
        add_action('fluent_cart/subscription_reactivation_order_created', [$this, 'handleSubscriptionReactivationOrderCreated'], 10, 1);
        add_action('fluent_cart/subscription_renewal_cart_completed', [$this, 'handleSubscriptionRenewalCartCompleted'], 10, 1);

        add_filter('fluent_cart/checkout/validate_before_process', [$this, 'validateReactivationCheckoutOwnership'], 10, 2);

    }

    public function handleSubscriptionReactivationOrderCreated($data)
    {
        $cartModel = Arr::get($data, 'cart', null);
        $order = Arr::get($data, 'order', null);
        if (!$cartModel || !$order) {
            return;
        }

        $renewData = Arr::get($cartModel->checkout_data, 'renew_data', []);
        $subscriptionHash = Arr::get($renewData, 'subscription_hash', '');

        if (empty($subscriptionHash)) {
            return;
        }
        $subscription = Subscription::query()->where('uuid', $subscriptionHash)->first();

        if (!$subscription) {
            return;
        }

        $order->parent_id = $subscription->parent_order_id;
        $order->type = Status::ORDER_TYPE_RENEWAL;

        $config = $order->config;
        $config['old_vendor_subscription_id'] = Arr::get($renewData, 'old_vendor_subscription_id', '');
        $config['old_payment_method'] = Arr::get($renewData, 'old_payment_method', '');

        $order->config = $config;

        $order->save();

        $currentRenewalAmount = Arr::get($renewData, 'new_recurring_amount', 0);

        // The renewal amount must include the recurring tax
        $checkoutSubscription = Subscription::query()->where('parent_order_id', $order->id)->first();
        if ($checkoutSubscription && $checkoutSubscription->recurring_total > 0) {
            $currentRenewalAmount = $checkoutSubscription->recurring_total;
        } elseif ($order->tax_behavior != 2) {
            // Fallback: add exclusive tax on top (behavior 2 is inclusive — tax already in the amount; for non-taxed carts tax_total is 0, so this is a no-op).
            $currentRenewalAmount += Arr::get($cartModel->checkout_data, 'tax_data.tax_total', 0);
        }

        $subscriptionConfig = $subscription->config;

        if ($currentRenewalAmount != $subscription->recurring_total) {
            $subscriptionConfig['current_renewal_amount'] = $currentRenewalAmount;
        } else {
            unset($subscriptionConfig['current_renewal_amount']);
        }

        $subscriptionConfig['reactivation_order_id'] = $order->id;
        $subscription->config = $subscriptionConfig;
        $subscription->save();

        // Messy solution to remove the subscription items from the order
        Subscription::query()->where('parent_order_id', $order->id)->delete();

        OrderTransaction::query()->where('order_id', $order->id)
            ->update([
                'order_type' => Status::ORDER_TYPE_RENEWAL,
                'subscription_id' => $subscription->id
            ]);

        $order->addLog('Subscription reactivation order created.', 'Customer intended to reactivate the subscription', 'info');
    }

    public function handleSubscriptionRenewalCartCompleted($data)
    {
        $cart = Arr::get($data, 'cart', null);
        $order = Arr::get($data, 'order', null);

        if (!$cart || !$order || !$order->parent_id) {
            return;
        }

        $subscription = Subscription::query()
            ->where('parent_order_id', $order->parent_id)
            ->first();

        if (!$subscription) {
            return;
        }

        $oldPaymentMethod = Arr::get($order->config, 'old_payment_method', '');
        $oldVendorSubscriptionId = Arr::get($order->config, 'old_vendor_subscription_id', '');

        if (
            $oldVendorSubscriptionId &&
            (
                $subscription->current_payment_method != $oldPaymentMethod ||
                $subscription->vendor_subscription_id != $oldVendorSubscriptionId
            )
        ) {
            if (method_exists($subscription, 'cancelReplacedVendorSubscription')) {
                $result = $subscription->cancelReplacedVendorSubscription(
                    (string)$oldPaymentMethod,
                    (string)$oldVendorSubscriptionId,
                    __('Subscription reactivated', 'fluent-cart-pro')
                );
            } else {
                // FluentCart core before cancelReplacedVendorSubscription()
                $result = $this->cancelOldVendorSubscription($subscription, $order, (string)$oldPaymentMethod, (string)$oldVendorSubscriptionId);
            }

            if ($result === true) {
                $order->addLog(
                    'Old Subscription cancelled successfully - ' . $oldPaymentMethod,
                    'Old subscription with ID: ' . $oldVendorSubscriptionId . ' has been cancelled.',
                    'info'
                );
            }
        }

        (new SubscriptionReactivated($subscription, $order, $order->customer))->dispatch();

        $newRecurringAmount = Arr::get($cart->checkout_data, 'renew_data.new_recurring_amount', 0);
        $oldRecurringAmount = Arr::get($cart->checkout_data, 'renew_data.old_recurring_amount', 0);

        if ($newRecurringAmount == $oldRecurringAmount || $newRecurringAmount <= 0) {
            return;
        }

        if ($subscription) {
            $newRecurringTotal = (int)$newRecurringAmount;
            if ($order->tax_behavior != 2) {
                $newRecurringTotal += (int) Arr::get($cart->checkout_data, 'tax_data.tax_total', 0);
            }

            $subscription->recurring_amount = (int)$newRecurringAmount;
            $subscription->recurring_total = $newRecurringTotal;
            $subscription->save();
        }

    }

    /**
     * @return true|\WP_Error
     */
    private function cancelOldVendorSubscription(Subscription $subscription, $order, string $oldPaymentMethod, string $oldVendorSubscriptionId)
    {
        $gateway = App::gateway($oldPaymentMethod);
        if (!$gateway || !$gateway->has('subscriptions')) {
            return new \WP_Error('gateway_unavailable', __('The payment gateway is not available.', 'fluent-cart-pro'));
        }

        $result = $gateway->subscriptions->cancel($oldVendorSubscriptionId, [
            'mode'            => $order->mode,
            'effective_from'  => 'immediately',
            'subscription_id' => $subscription->id,
        ]);

        if (!is_wp_error($result)) {
            return true;
        }

        $url = apply_filters('fluent_cart/subscription/url_' . $oldPaymentMethod, '', [
            'vendor_subscription_id' => $oldVendorSubscriptionId,
            'payment_mode'           => $order->mode,
            'subscription'           => $subscription,
        ]);
        $link = $url ? sprintf(' <a href="%1$s" target="_blank" rel="noopener">%1$s</a>', esc_url($url)) : '';

        $order->addLog(
            'OLD Subscription cancellation failed for renewal - ' . $oldPaymentMethod,
            sprintf('Failed to cancel the old subscription with ID: %1$s. Cancel it at the gateway to stop double billing.%2$s Error: %3$s', $oldVendorSubscriptionId, $link, $result->get_error_message()),
            'error'
        );

        return $result;
    }

    public function handleSubscriptionReactivationRedirect($data = [])
    {
        if (!is_user_logged_in()) {
            $loginUrl = $this->buildLoginRedirectUrl($data);

            if (!$loginUrl) {
                $this->showError(__('You are not logged in. Please log in to access this reactivation link.', 'fluent-cart-pro'));
            }

            wp_redirect($loginUrl);
            exit();
        }

        $currentCustomer = CustomerResource::getCurrentCustomer();

        if (!$currentCustomer) {
            die('You don\'t have permission to reactivate this subscription.');
        }

        $subscriptionUID = $data['subscription_hash'] ?? '';

        if (empty($subscriptionUID)) {
            $this->showError(__('Subscription UID is required.', 'fluent-cart-pro'));
        }

        $subscription = Subscription::query()->where('uuid', $subscriptionUID)->first();

        if (!$subscription) {
            $this->showError(__('Subscription not found.', 'fluent-cart-pro'));
        }

        if ($subscription->recurring_amount <= 0) {
            $this->showError(__('The recurring amount for this subscription is not valid.', 'fluent-cart-pro'));
        }

        if (!$subscription->canReactivate()) {
            $this->showError(__('This subscription cannot be reactivated.', 'fluent-cart-pro'));
        }

        // THE authorization check for this endpoint — not one validation among
        // several. The reactivation link carries no token: subscription_hash is an
        // unguessable uuid, but it is also the customer dashboard's routing id
        // (Subscription::getViewUrl()), so it reaches browser history, Referer
        // headers and analytics. This comparison is the only thing standing between
        // a leaked uuid and someone else's subscription. Do not remove it as
        // redundant with canReactivate() — that gates *whether* a subscription may be
        // reactivated, never *by whom*.
        if (!$this->customerOwnsSubscription($subscription, $currentCustomer)) {
            $this->showError(__('Cannot process this reactivation.', 'fluent-cart-pro'));
        }

        // Store-billed with a future due date has nothing to charge yet — flip it
        // active locally instead of sending the customer through checkout.
        if ($subscription->shouldSubscriptionActiveLocally()) {
            $result = SubscriptionService::reactivateSubscriptionLocally($subscription);

            if (is_wp_error($result)) {
                $this->showError($result->get_error_message());
            }

            $manageUrl = (new StoreSettings())->getCustomerProfilePage()
                ? URL::getCustomerDashboardUrl('subscription/' . $subscription->uuid)
                : URL::getFrontEndUrl();

            wp_redirect($manageUrl);
            exit();
        }

        $parentOrder = $subscription->order;

        $allowedParentStatuses = array_merge(Status::getOrderPaymentSuccessStatuses(), [Status::PAYMENT_REFUNDED]);
        if (!$parentOrder || !in_array($parentOrder->payment_status, $allowedParentStatuses)) {
            $this->showError(__('The parent order of this subscription is not in a valid state for reactivation.', 'fluent-cart-pro'));
        }

        $item = ProductItemService::getItem([
            'order_id'         => $subscription->order->id,
            'product_id'       => $subscription->product_id,
            'variation_id'     => $subscription->variation_id,
        ]);
        
        $product   = $item->product;
        $variation = $item->variation;
        $isCustom = $item->is_custom;

        $paymentType = Arr::get($variation->other_info, 'payment_type', $variation->payment_type);

        if (!$variation || !$product || Arr::get($variation->other_info, 'repeat_interval') != $subscription->billing_interval || $paymentType != 'subscription') {
            $this->showError(__('The product variant for this subscription is not valid.', 'fluent-cart-pro'));
        }

        $billCount = OrderTransaction::query()->where('subscription_id', $subscription->id)
            ->where('transaction_type', Status::TRANSACTION_TYPE_CHARGE)
            ->where('status', Status::TRANSACTION_SUCCEEDED)
            ->count();

        $requiredBillTimes = ($subscription->bill_times - $billCount) < 0 ? 0 : ($subscription->bill_times - $subscription->bill_count);

        if (!$isCustom && !$variation->canPurchase() && !$requiredBillTimes) {
            $this->showError(__('This subscription is not available for renew. Please purchase a new one!', 'fluent-cart-pro'));
        }

        $newItem = $variation->toArray();

        $recurringAmount = $subscription->recurring_amount;
        $isCataloguePrice = false;
        $trialDays = (int) $subscription->getReactivationTrialDays();

        if (!$requiredBillTimes) {
           
            $nextBillingDate = $subscription->next_billing_date ?? $subscription->expire_at;

            // we should let the users to reactivate their subscription if within 60 days of the expiration
            $expirationDays = (int)((time() - strtotime($nextBillingDate)) / 86400);

            $samePriceDaysLimit = apply_filters('fluent_cart/subscription/reactivation_same_price_days_limit', 60, [
                'subscription' => $subscription
            ]);

            if ($expirationDays <= $samePriceDaysLimit) {
                $recurringAmount = $subscription->recurring_amount;
            } else {
                // It's actually expired so the customer must need to pay the new pricing of our product!
                $recurringAmount = $variation->item_price;
                $isCataloguePrice = true;
            }
        }

        Arr::set($newItem, 'item_price', $recurringAmount);
        Arr::set($newItem, 'other_info', [
            'payment_type'     => 'subscription',
            'manage_setup_fee' => 'no',
            'trial_days'       => $trialDays,
            'repeat_interval'  => $subscription->billing_interval,
            'installment'      => $requiredBillTimes ? 'yes' : 'no',
            'times'            => $requiredBillTimes ? $requiredBillTimes : '0',
        ]);

        if($isCustom) {
            Arr::set($newItem, 'post_title', $variation->post_title);
            Arr::set($newItem, 'variation_type', $variation->variation_type);
        } else {
            Arr::set($newItem, 'post_title', $variation->product->post_title);
            Arr::set($newItem, 'variation_type', $variation->product_detail->variation_type);
        }

        $instantCart = CartHelper::generateCartFromCustomVariation($newItem);
        $instantCart->cart_group = 'instant';
        $instantCart->first_name = $subscription->customer->first_name;
        $instantCart->last_name = $subscription->customer->last_name;
        $instantCart->email = $subscription->customer->email;
        $instantCart->customer_id = $subscription->customer->id;
        $instantCart->user_id = $subscription->customer->user_id;
        $instantCart->cart_hash = md5('renew_sub_' . wp_generate_uuid4() . time());
        $instantCart->checkout_data = [
            'is_locked'                       => 'yes',
            'disable_coupons'                 => 'yes',
            'renew_data'                      => [
                'subscription_hash'          => $subscription->uuid,
                'old_vendor_subscription_id' => $subscription->vendor_subscription_id,
                'old_payment_method'         => $subscription->current_payment_method,
                'parent_order_id'            => $parentOrder->id,
                'is_renewal'                 => 'yes',
                'trial_days'                 => $trialDays,
                'new_recurring_amount'       => $recurringAmount,
                'old_recurring_amount'       => $subscription->recurring_amount,
                'customer_id'                => $subscription->customer_id,
            ]
        ];

        $instantCart->checkout_data = array_merge(
            $instantCart->checkout_data,
            $instantCart->addDraftCreatedActions([
                'fluent_cart/subscription_reactivation_order_created',
            ]),
            $instantCart->addSuccessActions([
                'fluent_cart/subscription_renewal_cart_completed',
            ]),
            $instantCart->addCartNotices([
                [
                    'id'      => 'renewal_notice',
                    'type'    => 'info',
                    'content' => sprintf(
                        __('You are reactivating your subscription: %1$s .','fluent-cart-pro'),
                        $subscription->item_name
                    ),
                ]
            ])
        );

        if (method_exists(CartCurrency::class, 'holdToSubscription')) {
            $quote = CartCurrency::holdToSubscription($instantCart, $subscription, $isCataloguePrice);
            if (!$quote) {
                $this->refuseUnpricedSubscription($subscription);
            }

            if ($isCataloguePrice) {
                // The line is converted at this quote; the subscription renews at the same amount
                $checkoutData = $instantCart->checkout_data;
                Arr::set($checkoutData, 'renew_data.new_recurring_amount', PriceConverter::toPrice($recurringAmount, $quote));
                $instantCart->checkout_data = $checkoutData;
            }
        }

        $instantCart->save();
        $cartHash = $instantCart->cart_hash;

        $checkoutUrl = add_query_arg(
            [
                'fct_cart_hash' => $cartHash,
            ],
            (new StoreSettings())->getCheckoutPage()
        );

        wp_redirect($checkoutUrl);
        exit();
    }

    public function validateReactivationCheckoutOwnership($validation, $data)
    {
        $cart = \FluentCart\App\Helpers\CartHelper::getCart();

        if (!$cart) {
            return $validation;
        }

        $renewData = Arr::get($cart->checkout_data, 'renew_data');
        if (empty($renewData)) {
            return $validation;
        }

        $cartCustomerId = Arr::get($renewData, 'customer_id');
        if (!$cartCustomerId) {
            return $validation;
        }

        if (!is_user_logged_in()) {
            return new \WP_Error(
                'reactivation_auth_required',
                __('You must be logged in to complete this reactivation.', 'fluent-cart-pro')
            );
        }

        $currentCustomer = CustomerResource::getCurrentCustomer();
        if (!$currentCustomer) {
            return new \WP_Error(
                'reactivation_auth_failed',
                __('Unable to verify your identity. Please log in again.', 'fluent-cart-pro')
            );
        }

        if ($cartCustomerId != $currentCustomer->id) {
            return new \WP_Error(
                'reactivation_unauthorized',
                __('This reactivation belongs to a different customer. You cannot complete this checkout.', 'fluent-cart-pro')
            );
        }

        return $validation;
    }

    /**
     * Whether this customer is the one the subscription belongs to.
     *
     * The sole authorization control on the reactivation endpoint — see the call
     * site in handleSubscriptionReactivationRedirect(). Kept as its own method so
     * it can be tested: the handler around it ends in wp_redirect()/exit().
     *
     * @param \FluentCart\App\Models\Subscription|null $subscription
     * @param object|null                              $customer the current customer
     * @return bool false whenever either side is missing — never fail open
     */
    public function customerOwnsSubscription($subscription, $customer)
    {
        if (!$subscription || !$customer || !$customer->id) {
            return false;
        }

        return (int) $subscription->customer_id === (int) $customer->id;
    }

    /**
     * Customer profile page URL that carries the reactivation link back through login.
     *
     * The link is rebuilt from the parameters this handler actually reads rather than
     * replayed from $_GET: the superglobal is slashed and carries whatever else the
     * caller appended, and all of it would otherwise ride back through the login
     * round-trip inside the profile page's redirect_to.
     *
     * @param array $data the request data the reactivation action was dispatched with
     * @return string empty when the store has no customer profile page to log in on
     */
    public function buildLoginRedirectUrl($data = [])
    {
        $profilePage = (new StoreSettings())->getCustomerProfilePage();

        if (!$profilePage) {
            return '';
        }

        $reactivationUrl = add_query_arg(array_filter([
            'fluent-cart'       => 'reactivate-subscription',
            'subscription_hash' => sanitize_text_field(Arr::get($data, 'subscription_hash', ''))
        ]), home_url('/'));

        return add_query_arg([
            'redirect_to' => urlencode($reactivationUrl),
            'fct_intent'  => 'reactivate-subscription'
        ], $profilePage);
    }

    private function showError($message)
    {
        die($message);
    }

    /**
     * Core could not quote the subscription's currency (no rate today and no
     * trusted snapshot), so no cart is built — never one priced in the base
     * currency for a subscription billed in another. Mirrors
     * UpgradeHandler::refuseUnpricedUpgrade().
     */
    private function refuseUnpricedSubscription($subscription)
    {
        wp_die(
            esc_html(sprintf(
                /* translators: %1$s: currency code, e.g. GBP */
                __('This payment is not available because no exchange rate is set for %1$s. Please contact the store.', 'fluent-cart-pro'),
                strtoupper((string) $subscription->currency)
            )),
            esc_html__('Payment not available', 'fluent-cart-pro'),
            ['response' => 409, 'back_link' => true]
        );
    }

}
