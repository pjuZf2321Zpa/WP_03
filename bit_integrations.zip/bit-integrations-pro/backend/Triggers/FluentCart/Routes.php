<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Core\Util\Route;
use BitApps\IntegrationsPro\Triggers\FluentCart\FluentCartController;

Route::get('fluent-cart/get', [FluentCartController::class, 'getAllTasks']);
