<?php

namespace BitApps\IntegrationsPro\Actions\NiroHelp\Services;

use BitApps\IntegrationsPro\Actions\NiroHelp\NiroHelpHelper;
use NiroHelp\Models\Ticket;

if (!\defined('ABSPATH')) {
    exit;
}

final class ReplyService extends BaseService
{
    public function addReply(): array
    {
        $error = $this->validateRequiredFields([
            'ticket_id' => __('Ticket ID', 'bit-integrations-pro'),
            'message'   => __('Message', 'bit-integrations-pro'),
            'reply_by'  => __('Reply As', 'bit-integrations-pro'),
        ]);

        if ($error !== null) {
            return $error;
        }

        $ticket = $this->findTicket();

        if (!$ticket) {
            return $this->ticketNotFound();
        }

        $replyBy = $this->getString('reply_by');
        $isCustomer = $replyBy === NiroHelpHelper::REPLY_BY_CUSTOMER;
        $authorId = $isCustomer ? (int) $ticket->get_client_id() : (int) $replyBy;

        if (!$isCustomer && !$this->isAgent($authorId)) {
            return $this->errorResponse(__('The user cannot reply as an agent. Select a NiroHelp agent or the ticket customer.', 'bit-integrations-pro'));
        }

        $commentId = $ticket->add_comment($this->getString('message'), 'comment', ['user_id' => $authorId]);

        if (is_wp_error($commentId)) {
            return $this->errorResponse($commentId->get_error_message());
        }

        return $this->successResponse(
            __('The reply is added.', 'bit-integrations-pro'),
            array_merge(NiroHelpHelper::getCommentData($commentId), ['ticket_status' => (string) get_post_status($ticket->get_id())])
        );
    }

    public function addPrivateNote(): array
    {
        $error = $this->validateRequiredFields([
            'ticket_id' => __('Ticket ID', 'bit-integrations-pro'),
            'note'      => __('Note', 'bit-integrations-pro'),
        ]);

        if ($error !== null) {
            return $error;
        }

        $agentId = (int) $this->getInteger('agent_id');

        if ($agentId > 0 && !$this->isAgent($agentId)) {
            return $this->errorResponse(__('The user cannot write private notes. Select a NiroHelp agent.', 'bit-integrations-pro'));
        }

        $ticket = $this->findTicket();

        if (!$ticket) {
            return $this->ticketNotFound();
        }

        $commentId = $ticket->add_comment($this->getString('note'), Ticket::INTERNAL_NOTE, ['user_id' => $agentId]);

        if (is_wp_error($commentId)) {
            return $this->errorResponse($commentId->get_error_message());
        }

        return $this->successResponse(__('The private note is added.', 'bit-integrations-pro'), NiroHelpHelper::getCommentData($commentId));
    }
}
