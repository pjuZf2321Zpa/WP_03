<?php

namespace CustomFacebookFeed\Admin\Blocks;

use FacebookFeed\Vendor\Smashballoon\Framework\Packages\Blocks\SB_Feed_Block;
use CustomFacebookFeed\Builder\CFF_Db;

/**
 * Modern Gutenberg block for Facebook Feed.
 *
 * Extends the shared SB_Feed_Block framework to register a modern
 * Gutenberg block with feed selector UI and server-side rendering.
 *
 * @since 4.8
 */
class CFF_Modern_Feed_Block extends SB_Feed_Block {

	/**
	 * Get the block name.
	 *
	 * @since 4.8
	 *
	 * @return string
	 */
	protected function get_block_name() {
		return 'smashballoon/facebook-feed';
	}

	/**
	 * Get the shortcode tag used for rendering.
	 *
	 * @since 4.8
	 *
	 * @return string
	 */
	protected function get_shortcode_tag() {
		return 'custom-facebook-feed';
	}

	/**
	 * Get the script handle for the block editor.
	 *
	 * @since 4.8
	 *
	 * @return string
	 */
	protected function get_script_handle() {
		return 'sb-feed-blocks';
	}

	/**
	 * Get the text domain for translations.
	 *
	 * @since 4.8
	 *
	 * @return string
	 */
	protected function get_text_domain() {
		return 'custom-facebook-feed';
	}

	/**
	 * Get the plugin directory path.
	 *
	 * @since 4.8
	 *
	 * @return string
	 */
	protected function get_plugin_dir() {
		return trailingslashit( CFF_PLUGIN_DIR );
	}

	/**
	 * Get the action hook used to enqueue frontend scripts.
	 *
	 * @since 4.8
	 *
	 * @return string
	 */
	protected function get_enqueue_scripts_action() {
		return 'cff_enqueue_scripts';
	}

	/**
	 * Get the JavaScript variable name for localized block data.
	 *
	 * @since 4.8
	 *
	 * @return string
	 */
	protected function get_localize_var_name() {
		return 'cffFacebookFeedBlock';
	}

	/**
	 * Get the feed block identifier.
	 *
	 * @since 4.8
	 *
	 * @return string
	 */
	protected function get_feed_block_id() {
		return 'facebook';
	}

	/**
	 * Get the JavaScript initialization function name.
	 *
	 * @since 4.8
	 *
	 * @return string
	 */
	protected function get_init_function() {
		return 'cff_init';
	}

	/**
	 * Get the directory path for the block build assets.
	 *
	 * @since 4.8
	 *
	 * @return string
	 */
	protected function get_block_dir() {
		return $this->get_plugin_dir() . 'vendor/smashballoon/framework/Packages/Blocks/dist/feed-blocks/facebook';
	}

	/**
	 * Get the localized data for the block editor.
	 *
	 * @since 4.8
	 *
	 * @return array
	 */
	protected function get_editor_localize_data() {
		$feeds = CFF_Db::feeds_query();

		return array(
			'feeds'    => ! empty( $feeds ) ? $feeds : array(),
			'feed_url' => admin_url( 'admin.php?page=cff-feed-builder' ),
			'nonce'    => wp_create_nonce( 'cff-blocks' ),
		);
	}

	/**
	 * Register hooks for the modern feed block.
	 *
	 * @since 4.8
	 *
	 * @return void
	 */
	public function register_hooks() {
		add_action( 'cff_enqueue_scripts', function() {
			\cff_main_pro()->enqueue_styles_assets();
			\cff_main_pro()->enqueue_scripts_assets();
		} );

		parent::register_hooks();

		if ( doing_action( 'init' ) || did_action( 'init' ) ) {
			$this->register_block();
		}

		remove_action( 'enqueue_block_editor_assets', array( $this, 'enqueue_editor_assets' ) );
		add_action( 'enqueue_block_editor_assets', array( $this, 'enqueue_editor_assets' ), 25 );
	}
}
