<?php

defined('ABSPATH') || exit;

class MeprCoachkitCtrl extends MeprFeatureAddonCtrl
{
    /**
     * Configure the add-on.
     */
    protected function configure(): void
    {
        $this->slug                = 'memberpress-coachkit';
        $this->main_file           = 'memberpress-coachkit/main.php';
        $this->page_title          = __('MemberPress CoachKit™', 'memberpress');
        $this->menu_title          = __('CoachKit™', 'memberpress');
        $this->menu_position       = 12;
        $this->view_path           = '/admin/coachkit/ui';
        $this->post_activation_url = add_query_arg('post_type', 'mpch-program', admin_url('edit.php'));
    }
}
