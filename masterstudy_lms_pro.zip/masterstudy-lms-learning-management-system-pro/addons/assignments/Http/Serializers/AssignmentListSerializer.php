<?php

namespace MasterStudy\Lms\Pro\addons\assignments\Http\Serializers;

use MasterStudy\Lms\Http\Serializers\AbstractSerializer;
use MasterStudy\Lms\Plugin\PostType;
use MasterStudy\Lms\Utility\Wpml;
use MasterStudy\Lms\Utility\WpDate;

final class AssignmentListSerializer extends AbstractSerializer {

	/**
	 * @param \WP_Post $post
	 */
	public function toArray( $post ): array {
		$modified = WpDate::format_gmt_for_site(
			(string) $post->post_modified_gmt,
			(string) $post->post_modified
		);

		return array(
			'id'                 => (int) $post->ID,
			'title'              => html_entity_decode(
				get_the_title( $post->ID ),
				ENT_QUOTES | ENT_HTML5,
				'UTF-8'
			),
			'date'               => (string) $post->post_date,
			'date_formatted'     => \STM_LMS_Helpers::format_date( $post->post_date ),
			'modified'           => $modified['datetime'],
			'modified_gmt'       => (string) $post->post_modified_gmt,
			'modified_formatted' => $modified['formatted'],
			'status'             => (string) $post->post_status,
			'courses'            => isset( $post->courses ) && is_array( $post->courses ) ? $post->courses : array(),
			'total'              => isset( $post->total ) ? (int) $post->total : 0,
			'passed'             => isset( $post->passed ) ? (int) $post->passed : 0,
			'not_passed'         => isset( $post->not_passed ) ? (int) $post->not_passed : 0,
			'pending'            => isset( $post->pending ) ? (int) $post->pending : 0,
			'wpml'               => Wpml::post_translations( (int) $post->ID, PostType::ASSIGNMENT ),
		);
	}
}
