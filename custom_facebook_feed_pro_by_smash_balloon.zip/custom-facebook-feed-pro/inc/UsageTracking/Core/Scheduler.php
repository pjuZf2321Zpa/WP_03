<?php
/**
 * Schedules the weekly usage tracking cron. Mirrors the legacy weekly schedule pattern.
 *
 * @package CustomFacebookFeed\UsageTracking\Core
 * @since 4.0
 */

namespace CustomFacebookFeed\UsageTracking\Core;

use CustomFacebookFeed\UsageTracking\Config;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Scheduler {

	/**
	 * Ensure weekly cron is scheduled when tracking is enabled.
	 * Call on init or when enabling the option.
	 */
	public function schedule() {
		$this->cleanup_legacy();

		// DSC master kill-switch: never leave a telemetry cron scheduled without
		// data-sharing consent, regardless of the per-plugin enabled toggle. WP.org
		// review flags scheduled hooks that hit external URLs, so we unschedule
		// (not merely skip) when consent is off.
		if ( class_exists( '\FacebookFeed\Vendor\Smashballoon\Framework\Packages\Consent\ConsentManager' ) && ! \FacebookFeed\Vendor\Smashballoon\Framework\Packages\Consent\ConsentManager::is_dsc_enabled() ) {
			if ( wp_next_scheduled( Config::CRON_HOOK ) ) {
				wp_clear_scheduled_hook( Config::CRON_HOOK );
			}
			return;
		}

		if ( ! Config::is_enabled() ) {
			return;
		}

		if ( wp_next_scheduled( Config::CRON_HOOK ) ) {
			return;
		}

		$tracking           = array(
			'day'    => wp_rand( 0, 6 ),
			'hour'   => wp_rand( 0, 23 ),
			'minute' => wp_rand( 0, 59 ),
			'second' => wp_rand( 0, 59 ),
		);
		$tracking['offset'] = ($tracking['day'] * DAY_IN_SECONDS)
			+ ($tracking['hour'] * HOUR_IN_SECONDS)
			+ ($tracking['minute'] * MINUTE_IN_SECONDS)
			+ $tracking['second'];

		$last_sunday = strtotime( 'next sunday' ) - (7 * DAY_IN_SECONDS);
		if ( ($last_sunday + $tracking['offset']) > time() + 6 * HOUR_IN_SECONDS ) {
			$tracking['initsend'] = $last_sunday + $tracking['offset'];
		} else {
			$tracking['initsend'] = strtotime( 'next sunday' ) + $tracking['offset'];
		}

		wp_schedule_event( $tracking['initsend'], 'weekly', Config::CRON_HOOK );
		update_option( Config::OPTION_SCHEDULE, $tracking, false );
	}

	/**
	 * Add weekly schedule if not already present.
	 *
	 * @param array $schedules Existing cron schedules.
	 * @return array
	 */
	public function add_schedules( $schedules ) {
		if ( ! isset( $schedules['weekly'] ) ) {
			$schedules['weekly'] = array(
				'interval' => 604800,
				'display'  => __( 'Once Weekly', 'custom-facebook-feed' ),
			);
		}
		return $schedules;
	}

	/**
	 * Unschedule the cron when tracking is disabled.
	 */
	public function unschedule() {
		wp_clear_scheduled_hook( Config::CRON_HOOK );
	}

	/**
	 * Clear the removed legacy tracking cron and delete its superseded options.
	 * Guarded so steady-state cost is a no-op.
	 */
	private function cleanup_legacy() {
		if ( wp_next_scheduled( 'cff_usage_tracking_cron' ) ) {
			wp_clear_scheduled_hook( 'cff_usage_tracking_cron' );
		}
		if ( get_option( 'cff_smash_usage_tracking', null ) !== null ) {
			delete_option( 'cff_smash_usage_tracking' );
			delete_option( 'cff_usage_tracking_config' );
		}
	}
}
