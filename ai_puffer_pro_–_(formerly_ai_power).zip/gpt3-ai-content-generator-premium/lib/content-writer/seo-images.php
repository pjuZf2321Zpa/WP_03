<?php

namespace WPAICG\ContentWriter\SEO;

if (!defined('ABSPATH')) {
    exit;
}

/** SEO image alt text and approved image markup for generated drafts. */
class AIPKit_Content_Writer_Smart_SEO_Image_Alt_Helper
{
    public static function resolve_image_alt_text(array $image_item): string
    {
        foreach (['alt', 'alt_text', 'generated_alt_text', 'image_alt', 'seo_alt'] as $key) {
            if (!empty($image_item[$key]) && is_scalar($image_item[$key])) {
                return trim(wp_strip_all_tags((string) $image_item[$key]));
            }
        }

        return '';
    }

    public static function maybe_prepare_rank_math_image_alt(?array &$image_data, string $focus_keyword, array $context = []): void
    {
        $focus_keyword = trim($focus_keyword);
        $profile = self::get_context_profile($context);
        if ($focus_keyword === '' || empty($image_data) || !in_array($profile, ['yoast', 'rank_math', 'aioseo'], true)) {
            return;
        }
        $rule_id = $profile === 'aioseo' ? 'aioseo_keyphrase_in_image_alt' : 'keyphrase_in_image_alt';
        if (class_exists(AIPKit_Content_Writer_SEO_Config::class) && !AIPKit_Content_Writer_SEO_Config::is_rule_enabled($context, $rule_id)) {
            return;
        }

        if (empty($image_data['in_content_images']) || !is_array($image_data['in_content_images'])) {
            return;
        }

        foreach ($image_data['in_content_images'] as $image_item) {
            if (is_array($image_item) && self::image_alt_has_focus_keyphrase(self::resolve_image_alt_text($image_item), $focus_keyword, in_array($profile, ['yoast', 'aioseo'], true))) {
                return;
            }
        }

        foreach ($image_data['in_content_images'] as &$image_item) {
            if (!is_array($image_item)) {
                continue;
            }

            $alt = self::build_rank_math_image_alt($focus_keyword, self::resolve_image_alt_text($image_item));
            if ($alt === '') {
                continue;
            }

            $image_item['alt'] = $alt;
            $image_item['alt_text'] = $alt;
            $attachment_id = isset($image_item['attachment_id']) ? absint($image_item['attachment_id']) : 0;
            if ($attachment_id > 0) {
                update_post_meta($attachment_id, '_wp_attachment_image_alt', $alt);
                update_post_meta($attachment_id, '_aipkit_image_alt_text', $alt);
            }

            unset($image_item);
            return;
        }
        unset($image_item);
    }

    public static function image_alt_has_focus_keyphrase(string $alt_text, string $focus_keyword, bool $exact_phrase = false): bool
    {
        $alt_text = strtolower(trim(wp_strip_all_tags($alt_text)));
        $focus_keyword = strtolower(trim(wp_strip_all_tags($focus_keyword)));
        if ($alt_text === '' || $focus_keyword === '') {
            return false;
        }

        if ($exact_phrase) {
            return strpos($alt_text, $focus_keyword) !== false;
        }

        $normalized_focus = preg_replace('/[^\p{L}\p{N}\s-]+/u', ' ', $focus_keyword);
        $words = preg_split('/\s+/', (string) $normalized_focus);
        $words = array_values(array_unique(array_filter(array_map('trim', $words ?: []))));
        if (empty($words)) {
            return false;
        }

        $pattern = implode('.*', array_map(static function (string $word): string {
            return preg_quote($word, '/');
        }, $words));

        return preg_match('/' . $pattern . '/iu', $alt_text) === 1;
    }

    public static function build_rank_math_image_alt(string $focus_keyword, string $current_alt): string
    {
        $focus_keyword = trim(wp_strip_all_tags($focus_keyword));
        $current_alt = trim(wp_strip_all_tags($current_alt));
        if ($focus_keyword === '') {
            return $current_alt;
        }

        $alt = $current_alt !== '' ? $focus_keyword . ' - ' . $current_alt : $focus_keyword . ' illustration';
        if (function_exists('mb_strlen') && mb_strlen($alt, 'UTF-8') > 125) {
            $alt = mb_substr($alt, 0, 125, 'UTF-8');
        } elseif (strlen($alt) > 125) {
            $alt = substr($alt, 0, 125);
        }

        return rtrim($alt);
    }

    private static function get_context_profile(array $context): string
    {
        $profile = isset($context['profile']) && is_scalar($context['profile'])
            ? sanitize_key((string) $context['profile'])
            : '';
        if ($profile === '' && isset($context['seo_score_profile']) && is_scalar($context['seo_score_profile'])) {
            $profile = sanitize_key((string) $context['seo_score_profile']);
        }

        if ($profile !== '' && $profile !== 'auto') {
            return $profile;
        }

        return self::get_active_profile();
    }

    private static function get_active_profile(): string
    {
        if (!class_exists('\\WPAICG\\SEO\\AIPKit_SEO_Helper')) {
            return '';
        }

        $profile = \WPAICG\SEO\AIPKit_SEO_Helper::get_active_plugin_profile();
        return isset($profile['profile']) ? sanitize_key((string) $profile['profile']) : '';
    }
}

class AIPKit_Content_Writer_Smart_SEO_Image_Tag_Guard
{
    private const IMAGE_SIZES = ['thumbnail', 'medium', 'medium_large', 'large', 'full'];

    public static function sanitize_draft(array $draft): array
    {
        $approved_urls = self::approved_image_urls(isset($draft['images']) && is_array($draft['images']) ? $draft['images'] : []);

        foreach (['content_html', 'content'] as $key) {
            if (!isset($draft[$key]) || !is_scalar($draft[$key])) {
                continue;
            }

            $draft[$key] = self::sanitize_content((string) $draft[$key], $approved_urls);
        }

        return $draft;
    }

    private static function sanitize_content(string $content, array $approved_urls): string
    {
        if (stripos($content, '<img') === false) {
            return $content;
        }

        $content = preg_replace_callback('/<figure\b[^>]*>.*?<\/figure>/is', static function (array $match) use ($approved_urls): string {
            if (stripos($match[0], '<img') === false) {
                return $match[0];
            }

            $cleaned = self::sanitize_image_tags($match[0], $approved_urls);
            return stripos($cleaned, '<img') === false ? '' : $cleaned;
        }, $content);

        $content = self::sanitize_image_tags((string) $content, $approved_urls);
        $content = preg_replace('/<p>\s*<\/p>/i', '', (string) $content);

        return (string) $content;
    }

    private static function sanitize_image_tags(string $content, array $approved_urls): string
    {
        return (string) preg_replace_callback('/<img\b[^>]*>/i', static function (array $match) use ($approved_urls): string {
            $src = self::extract_src($match[0]);
            $key = self::normalize_url_key($src);

            if ($key === '' || !isset($approved_urls[$key])) {
                return '';
            }

            return self::remove_untrusted_image_sources($match[0]);
        }, $content);
    }

    private static function extract_src(string $tag): string
    {
        if (preg_match('/\bsrc\s*=\s*(["\'])(.*?)\1/i', $tag, $match)) {
            return html_entity_decode((string) $match[2], ENT_QUOTES, 'UTF-8');
        }

        return '';
    }

    private static function remove_untrusted_image_sources(string $tag): string
    {
        return (string) preg_replace('/\s(?:srcset|data-src|data-lazy-src|data-original)\s*=\s*(["\']).*?\1/i', '', $tag);
    }

    /**
     * @return array<string, true>
     */
    private static function approved_image_urls(array $images): array
    {
        $approved = [];

        foreach ($images as $image) {
            if (!is_array($image)) {
                continue;
            }

            foreach (['src', 'url', 'media_library_url', 'image_url'] as $key) {
                if (!empty($image[$key]) && is_scalar($image[$key])) {
                    $url_key = self::normalize_url_key((string) $image[$key]);
                    if ($url_key !== '') {
                        $approved[$url_key] = true;
                    }
                }
            }

            $attachment_id = isset($image['attachment_id']) ? max(0, (int) $image['attachment_id']) : 0;
            if ($attachment_id <= 0) {
                continue;
            }

            foreach (self::IMAGE_SIZES as $size) {
                $url = function_exists('wp_get_attachment_image_url') ? wp_get_attachment_image_url($attachment_id, $size) : '';
                if (is_string($url) && $url !== '') {
                    $url_key = self::normalize_url_key($url);
                    if ($url_key !== '') {
                        $approved[$url_key] = true;
                    }
                }
            }

            $full_url = function_exists('wp_get_attachment_url') ? wp_get_attachment_url($attachment_id) : '';
            if (is_string($full_url) && $full_url !== '') {
                $url_key = self::normalize_url_key($full_url);
                if ($url_key !== '') {
                    $approved[$url_key] = true;
                }
            }
        }

        return $approved;
    }

    private static function normalize_url_key(string $url): string
    {
        $url = trim(html_entity_decode($url, ENT_QUOTES, 'UTF-8'));
        if ($url === '') {
            return '';
        }

        if (strncmp($url, '//', strlen('//')) === 0) {
            $home_scheme = function_exists('home_url') ? wp_parse_url(home_url(), PHP_URL_SCHEME) : '';
            $scheme = is_string($home_scheme) ? $home_scheme : 'https';
            $url = ($scheme !== '' ? $scheme : 'https') . ':' . $url;
        } elseif (strncmp($url, '/', strlen('/')) === 0) {
            $url = function_exists('home_url') ? home_url($url) : $url;
        }

        $parts = wp_parse_url($url);
        if (!is_array($parts)) {
            return '';
        }

        $host = isset($parts['host']) ? strtolower((string) $parts['host']) : '';
        $port = isset($parts['port']) ? ':' . max(0, (int) $parts['port']) : '';
        $path = isset($parts['path']) ? rawurldecode((string) $parts['path']) : '';

        if ($host === '' && $path === '') {
            return '';
        }

        $path = '/' . ltrim(preg_replace('#/+#', '/', $path) ?: '', '/');

        return $host . $port . $path;
    }
}
