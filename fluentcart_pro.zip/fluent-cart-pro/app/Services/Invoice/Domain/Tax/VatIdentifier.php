<?php

declare(strict_types=1);

namespace FluentCartPro\App\Services\Invoice\Domain\Tax;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * VAT identifier normalization for EN 16931 / BR-CO-09.
 * Normalizes country prefix, validates format, handles EL/GR.
 */
final class VatIdentifier
{
    private ?string $normalized;

    private function __construct(?string $normalized)
    {
        $this->normalized = $normalized;
    }

    /**
     * Create from raw VAT ID and two-letter country code. For Greece pass GR; EL is used for VAT prefix.
     */
    public static function fromRaw(string $vatId, string $countryCode): self
    {
        $vatId = preg_replace('/\s+/', '', trim($vatId));
        if ($vatId === '') {
            return new self(null);
        }
        $upper = strtoupper($vatId);
        if ($upper === 'XX' || $upper === 'NA' || $upper === 'N/A') {
            return new self(null);
        }
        if (strlen($vatId) === 2) {
            return new self(null);
        }
        $countryCode = strtoupper(trim($countryCode));
        if ($countryCode === '') {
            return new self(null);
        }
        $prefixForVat = ($countryCode === 'GR') ? 'EL' : $countryCode;
        if (preg_match('/^[A-Z]{2}.+/', $upper)) {
            return new self($upper);
        }
        return new self($prefixForVat . $upper);
    }

    public function isValid(): bool
    {
        return $this->normalized !== null;
    }

    /**
     * Normalized VAT ID string (country prefix + number) or null if not a real VAT number.
     */
    public function asString(): ?string
    {
        return $this->normalized;
    }
}
