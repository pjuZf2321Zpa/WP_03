<?php

namespace BitApps\IntegrationsPro\Core\Util;

use WP_Post;

if (!\defined('ABSPATH')) {
    exit;
}

class WeDocsHelper
{
    public const DOC_POST_TYPE = 'docs';

    public const ALLOWED_POST_STATUSES = ['publish', 'draft', 'pending', 'private'];

    public static function isPluginInstalled()
    {
        return class_exists('WeDocs');
    }

    public static function normalizePost($post)
    {
        if ($post instanceof WP_Post) {
            return $post;
        }

        if (is_numeric($post)) {
            $normalizedPost = get_post((int) $post);

            return $normalizedPost instanceof WP_Post ? $normalizedPost : null;
        }
    }

    public static function normalizePostStatus($postStatus)
    {
        return \in_array($postStatus, self::ALLOWED_POST_STATUSES, true) ? $postStatus : 'draft';
    }

    public static function isValidDocsPost($post)
    {
        return $post instanceof WP_Post && $post->post_type === self::DOC_POST_TYPE;
    }

    public static function isValidDocsTriggerPost($post)
    {
        return self::isValidDocsPost($post)
            && !wp_is_post_revision($post->ID)
            && !wp_is_post_autosave($post->ID);
    }

    public static function isValidDocumentation($post)
    {
        return self::isValidDocsPost($post) && (int) $post->post_parent === 0;
    }

    public static function isValidSection($post)
    {
        if (!self::isValidDocsPost($post)) {
            return false;
        }

        $parentId = (int) $post->post_parent;

        if ($parentId <= 0) {
            return false;
        }

        return (int) wp_get_post_parent_id($parentId) === 0;
    }

    public static function getDocDepth($postId)
    {
        $depth = 0;
        $currentPostId = $postId;

        while ($currentPostId > 0) {
            $parentId = (int) wp_get_post_parent_id($currentPostId);

            if ($parentId <= 0) {
                break;
            }

            ++$depth;
            $currentPostId = $parentId;
        }

        return $depth;
    }

    public static function getDocType($postId)
    {
        $depth = self::getDocDepth($postId);

        if ($depth === 0) {
            return 'documentation';
        }

        if ($depth === 1) {
            return 'section';
        }

        return 'article';
    }

    public static function getRootDocumentationId($postId)
    {
        $currentPostId = $postId;

        while ($currentPostId > 0) {
            $parentId = (int) wp_get_post_parent_id($currentPostId);

            if ($parentId <= 0) {
                return $currentPostId;
            }

            $currentPostId = $parentId;
        }

        return 0;
    }

    public static function buildDocPayload(WP_Post $post)
    {
        $postId = (int) $post->ID;
        $rootDocumentationId = self::getRootDocumentationId($postId);
        $rootDocumentation = get_post($rootDocumentationId);

        $permalink = get_permalink($postId);
        $rootPermalink = get_permalink($rootDocumentationId);

        return array_merge(
            (array) $post,
            [
                'permalink'                    => \is_string($permalink) ? $permalink : '',
                'doc_type'                     => self::getDocType($postId),
                'doc_depth'                    => self::getDocDepth($postId),
                'root_documentation_id'        => $rootDocumentationId,
                'root_documentation_title'     => $rootDocumentation instanceof WP_Post ? $rootDocumentation->post_title : '',
                'root_documentation_permalink' => \is_string($rootPermalink) ? $rootPermalink : '',
            ]
        );
    }
}
