<?php
/**
 * Sureforms Submit Class file.
 *
 * @package sureforms-pro.
 * @since 0.0.1
 */

namespace SRFM_Pro\Inc;

use SRFM\Inc\Database\Tables\Entries;
use SRFM\Inc\Helper as SRFM_Helper;
use SRFM_Pro\Inc\Traits\Get_Instance;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Helper Helper Class.
 *
 * @since 0.0.1
 */
class Helper {
	use Get_Instance;

	/**
	 * Sureforms SVGs.
	 *
	 * @var mixed srfm_svgs
	 */
	private static $srfm_pro_svgs = null;

	/**
	 * Encode shortcode brackets in a value that came from a visitor, so it
	 * shows the same but cannot run as a shortcode when the page's
	 * `the_content` runs do_shortcode() over the rendered form (which also
	 * runs shortcodes inside attribute values).
	 *
	 * For output only: kses's HTML API sanitizer decodes these entities, so
	 * content that goes through kses after this needs another form (see
	 * Custom_Post_Type\Init::neutralize_for_post_content()).
	 *
	 * @param string $value Visitor-supplied value.
	 * @since 2.13.1
	 * @return string
	 */
	public static function encode_shortcode_brackets( $value ) {
		return str_replace( [ '[', ']' ], [ '&#91;', '&#93;' ], $value );
	}

	/**
	 * Get an SVG Icon
	 *
	 * @since 0.0.1
	 * @param string $icon the icon name.
	 * @param string $class if the baseline class should be added.
	 * @param string $html Custom attributes inside svg wrapper.
	 * @param string $wrapper_tag SVG icon wrapper html tag type. Default is span.
	 * @return string
	 */
	public static function fetch_pro_svg( $icon = '', $class = '', $html = '', $wrapper_tag = 'span' ) {

		$output = sprintf(
			'<%1$s class="%2$s" %3$s>',
			esc_attr( $wrapper_tag ),
			! empty( $class ) ? esc_attr( "srfm-icon {$class}" ) : 'srfm-icon',
			$html
		);

		if ( ! self::$srfm_pro_svgs ) {
			ob_start();

			include_once SRFM_PRO_DIR . 'assets/svg/svgs.json'; // phpcs:ignore WordPressVIPMinimum.Files.IncludingNonPHPFile.IncludingNonPHPFile -- Required to get svg.json.
			// phpcs:ignore /** @phpstan-ignore-next-line */
			self::$srfm_pro_svgs = json_decode( ob_get_clean(), true );
			self::$srfm_pro_svgs = apply_filters( 'srfm_pro_svg_icons', self::$srfm_pro_svgs );
		}

			$output .= self::$srfm_pro_svgs[ $icon ] ?? '';
			$output .= "</{$wrapper_tag}>";

			return $output;
	}

	/**
	 * Get an SVG Icon
	 *
	 * @since 0.0.1
	 * @param string $icon the icon name.
	 * @return string
	 */
	public static function get_pro_icon( $icon = '' ) {
		if ( ! self::$srfm_pro_svgs ) {
			$file_path = SRFM_PRO_DIR . 'assets/svg/svgs.json';

			if ( file_exists( $file_path ) ) {
				$file_contents = file_get_contents( $file_path ); //phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents

				if ( ! empty( $file_contents ) ) {
					self::$srfm_pro_svgs = json_decode( $file_contents, true );
					self::$srfm_pro_svgs = apply_filters( 'srfm_pro_svg_icons', self::$srfm_pro_svgs );
				}
			}
		}

		return self::$srfm_pro_svgs[ $icon ] ?? '';
	}

	/**
	 * Print sanitized SVG Icon.
	 *
	 * @since 1.4.1
	 * @param string $icon the icon name.
	 * @return void
	 */
	public static function print_pro_icon( $icon = '' ) {
		$allowed_svg_attrs = [
			'svg'      => [
				'width'   => true,
				'height'  => true,
				'fill'    => true,
				'viewbox' => true,
				'xmlns'   => true,
			],
			'g'        => [
				'clip-path' => true,
			],
			'defs'     => [],
			'clipPath' => [
				'id' => true,
			],
			'path'     => [
				'd'               => true,
				'opacity'         => true,
				'class'           => true,
				'stroke'          => true,
				'stroke-width'    => true,
				'stroke-linecap'  => true,
				'stroke-linejoin' => true,
			],
			'rect'     => [
				'width'  => true,
				'height' => true,
				'fill'   => true,
			],
		];

		echo wp_kses( self::get_pro_icon( $icon ), $allowed_svg_attrs );
	}

	/**
	 * Enqueue the shared field-value reader and return its handle.
	 *
	 * Conditional logic and the review summary both read a field's current value
	 * through this one script, so whichever of them renders first puts it on the
	 * page and the other simply depends on the handle.
	 *
	 * @since 2.13.0
	 * @return string The script handle, for use in a dependency array.
	 */
	public static function enqueue_field_value_script() {
		$handle      = SRFM_PRO_SLUG . '-field-value';
		$file_suffix = defined( 'SRFM_DEBUG' ) && SRFM_DEBUG ? '' : '.min';
		$dir_name    = defined( 'SRFM_DEBUG' ) && SRFM_DEBUG ? 'unminified' : 'minified';

		// wp_enqueue_script() is already idempotent per handle, so both callers
		// can call this unconditionally.
		wp_enqueue_script( $handle, SRFM_PRO_URL . 'assets/js/' . $dir_name . '/field-value' . $file_suffix . '.js', [ 'srfm-frontend' ], SRFM_PRO_VER, true );

		return $handle;
	}

	/**
	 * Registers script translations for a specific handle.
	 *
	 * This function sets the script translations for a given script handle, allowing
	 * localization of JavaScript strings using the specified text domain and path.
	 *
	 * @param string $handle The script handle to apply translations to.
	 * @param string $domain Optional. The text domain for translations. Default is 'sureforms'.
	 * @param string $path   Optional. The path to the translation files. Default is the 'languages' folder in the SureForms directory.
	 *
	 * @since 1.0.5
	 * @return void
	 */
	public static function register_script_translations( $handle, $domain = 'sureforms-pro', $path = SRFM_PRO_DIR . 'languages' ) {
		wp_set_script_translations( $handle, $domain, $path );
	}

	/**
	 * Return the string with hsl color for the given hex color.
	 *
	 * @param string    $hex_color The hex color.
	 * @param int|float $alpha The alpha value.
	 *
	 * @since 1.6.3
	 * @return string The hsl color string.
	 */
	public static function get_hsl_notation_from_hex( $hex_color, $alpha = 1 ) {
		return 'hsl( from ' . $hex_color . ' h s l / ' . $alpha . ')';
	}

	/**
	 * Return the classes based on normal and hover state to add to the submit button.
	 *
	 * @param string $background_type The background type of the button's normal state.
	 * @param string $hover_type The backround type of the button's hover state. Default 'normal'.
	 *
	 * @since 1.6.3
	 * @return string The classes to add to the button.
	 */
	public static function get_button_background_classes( $background_type, $hover_type ) {
		$background_type_class = $background_type ? 'srfm-btn-bg-' . $background_type : '';
		$hover_type_class      = $hover_type ? 'srfm-btn-bg-hover-' . $hover_type : '';

		return SRFM_Helper::join_strings( [ $background_type_class, $hover_type_class ] );
	}

	/**
	 * Add CSS variables to the form.
	 *
	 * @param array $css_variables The CSS variables to add.
	 * @since 1.6.3
	 * @return void
	 */
	public static function add_css_variables( $css_variables ) {
		if ( empty( $css_variables ) || ! is_array( $css_variables ) ) {
			return;
		}
		foreach ( $css_variables as $key => $value ) {
			if ( ! empty( $value ) ) {
				echo esc_html( SRFM_Helper::get_string_value( $key ) ) . ': ' . esc_html( SRFM_Helper::get_string_value( $value ) ) . ';';
			}
		}
	}

	/**
	 * Returns the post meta key holding styling values for a given form_theme slug.
	 *
	 * - 'custom' resolves to `_srfm_forms_styling_starter` (the historical Pro styling meta).
	 * - 'baseline', 'minimal', 'dark' resolve to their dedicated `_srfm_forms_styling_{slug}` metas.
	 * - Anything else (e.g. 'default') returns null — the caller should fall back to CSS defaults.
	 *
	 * @since 2.10.0
	 * @param string $form_theme Slug from the form_theme dropdown.
	 * @return string|null Post meta key, or null when no meta-driven values apply.
	 */
	public static function get_preset_styling_meta_key( $form_theme ) {
		if ( 'custom' === $form_theme ) {
			return '_srfm_forms_styling_starter';
		}
		if ( in_array( $form_theme, [ 'baseline', 'minimal', 'dark' ], true ) ) {
			return '_srfm_forms_styling_' . $form_theme;
		}
		return null;
	}

	/**
	 * Whether the given `form_theme` slug points to a user-created
	 * preset. User presets live in `wp_options` (per `User_Presets`)
	 * and are addressed as `user-{bare-slug}` on the wire.
	 *
	 * @since 2.10.0
	 * @param string $form_theme Slug from the form_theme dropdown.
	 * @return bool
	 */
	public static function is_user_preset_slug( $form_theme ) {
		return is_string( $form_theme ) && 0 === strpos( $form_theme, 'user-' ) && strlen( $form_theme ) > 5;
	}

	/**
	 * Strip the `user-` prefix from a form_theme slug. Returns empty
	 * string when the slug is not a user-preset slug.
	 *
	 * @since 2.10.0
	 * @param string $form_theme Slug from the form_theme dropdown.
	 * @return string Bare slug for `User_Presets::PRESET_OPTION_PREFIX` lookup.
	 */
	public static function get_user_preset_bare_slug( $form_theme ) {
		if ( ! self::is_user_preset_slug( $form_theme ) ) {
			return '';
		}
		return substr( (string) $form_theme, 5 );
	}

	/**
	 * Read a user preset's full payload by `form_theme` slug.
	 *
	 * @since 2.10.0
	 * @param string $form_theme Slug from the form_theme dropdown.
	 * @return array<string, mixed> Empty array when the preset doesn't exist.
	 */
	public static function get_user_preset( $form_theme ) {
		$bare = self::get_user_preset_bare_slug( $form_theme );
		if ( '' === $bare ) {
			return [];
		}
		$preset = get_option( 'srfm_pro_user_preset_' . $bare, [] );
		return is_array( $preset ) ? $preset : [];
	}

	/**
	 * Convenience: return just the `styles` sub-array for a user preset.
	 *
	 * @since 2.10.0
	 * @param string $form_theme Slug from the form_theme dropdown.
	 * @return array<string, mixed>
	 */
	public static function get_user_preset_styles( $form_theme ) {
		$preset = self::get_user_preset( $form_theme );
		if ( empty( $preset['styles'] ) || ! is_array( $preset['styles'] ) ) {
			return [];
		}
		return $preset['styles'];
	}

	/**
	 * Extra MIME types to support in addition to WP defaults.
	 * Key = file extension, Value = array of additional mime types.
	 *
	 * @since 2.5.2
	 * @return array<string, array<string>>
	 */
	public static function get_extra_mimes() {
		return [
			'zip' => [ 'application/x-zip-compressed' ],
			'stl' => [ 'model/stl', 'application/sla' ],
		];
	}

	/**
	 * Get the WordPress file types.
	 *
	 * @param bool $should_return_file_type Whether to return an associative array. Default is false.
	 * Example: For True ['jpg' => 'image/jpeg', 'png' => 'image/png'].
	 * If false, it returns an array of strings like ['image/jpeg', 'image/png'].
	 *
	 * @since 1.8.0
	 * @return array<string,mixed> An associative array representing the file types.
	 */
	public static function get_wp_file_types( $should_return_file_type = false ) {

		/**
		 * These file types are excluded from the allowed file types.
		 * As these are not allowed in the wp_handle_upload function.
		 */
		$excluded_file_types = [
			'js'  => 'application/javascript', // Exclude JavaScript files.
			'css' => 'text/css', // Exclude CSS files.
			'rar' => 'application/rar', // Exclude RAR files.
		];

		$extra_mimes = self::get_extra_mimes();

		$formats = [];
		$mimes   = get_allowed_mime_types();
		$maxsize = wp_max_upload_size() / 1048576;

		// Merge extra MIME types dynamically.
		foreach ( $extra_mimes as $ext => $aliases ) {
			if ( isset( $mimes[ $ext ] ) ) {
				// Append aliases if not already present.
				$current = explode( '|', $mimes[ $ext ] );
				foreach ( $aliases as $alias ) {
					if ( ! in_array( $alias, $current, true ) ) {
						$current[] = $alias;
					}
				}
				$mimes[ $ext ] = implode( '|', $current );
			} else {
				// Add new extension with all aliases.
				$mimes[ $ext ] = implode( '|', $aliases );
			}
		}

		if ( ! empty( $mimes ) ) {
			foreach ( $mimes as $type => $mime ) {
				$multiple = explode( '|', $type );
				foreach ( $multiple as $file_type ) {

					// Skip excluded file types.
					if ( isset( $excluded_file_types[ $file_type ] ) ) {
						continue;
					}

					if ( $should_return_file_type ) {
						$formats[ $file_type ] = $mime;
					} else {
						$formats[] = $mime;
					}
				}
			}
		}

		return [
			'formats' => $formats,
			'maxsize' => $maxsize,
		];
	}

	/**
	 * Normalize WordPress file types into extension => [ mime1, mime2, ... ] format.
	 *
	 * @since 1.12.1
	 * @return array<string, array<string>>
	 */
	public static function get_normalized_file_types() {
		$file_types = self::get_wp_file_types( true );
		$normalized = [];

		if ( isset( $file_types['formats'] ) && is_array( $file_types['formats'] ) ) {
			foreach ( $file_types['formats'] as $ext => $mimes ) {
				if ( is_string( $mimes ) ) {
					$mime_list                        = array_map( 'trim', explode( '|', $mimes ) );
					$normalized[ strtolower( $ext ) ] = $mime_list;
				} elseif ( is_array( $mimes ) ) {
					$normalized[ strtolower( $ext ) ] = array_map( 'trim', $mimes );
				}
			}
		}

		return $normalized;
	}

	/**
	 * Delete uploaded file from a specific subdirectory.
	 *
	 * @param string $file_url The file URL to delete.
	 * @param string $subdir The subdirectory to delete the file from.
	 *
	 * @since 1.8.0
	 * @return bool
	 */
	public static function delete_upload_file_from_subdir( $file_url, $subdir = 'sureforms/' ) {
		// Decode the file URL.
		$file_url = urldecode( $file_url );

		// Check if the file URL is empty.
		if ( empty( $file_url ) || ! is_string( $file_url ) ) {
			return false;
		}

		// Normalize and sanitize the subdirectory.
		$subdir = trailingslashit( sanitize_text_field( $subdir ) );

		// Get the base upload directory.
		$upload_dir       = wp_upload_dir();
		$base_upload_path = trailingslashit( $upload_dir['basedir'] ) . $subdir;

		$filename       = basename( $file_url );
		$file_extension = strtolower( pathinfo( $filename, PATHINFO_EXTENSION ) );

		// Validate the file extension.
		if ( empty( $file_extension ) || ! is_string( $file_extension ) ) {
			return false;
		}

		$allowed_file_types = self::get_normalized_file_types();

		if ( ! array_key_exists( $file_extension, $allowed_file_types ) ) {
			return false;
		}

		$file_path      = $base_upload_path . $filename;
		$real_file_path = realpath( $file_path );
		$real_base_path = realpath( $base_upload_path );

		// Security check: ensure file is inside the target subdir.
		if ( ! $real_file_path || ! $real_base_path || strpos( $real_file_path, trailingslashit( $real_base_path ) ) !== 0 ) {
			return false;
		}

		// Delete if file exists.
		if ( file_exists( $real_file_path ) ) {
			return unlink( $real_file_path );
		}

		return false;
	}

	/**
	 * Check if a string is JSON.
	 *
	 * @param string $string String to check.
	 * @return bool True if the string is JSON, false otherwise.
	 * @since 1.13.0
	 */
	public static function is_json( $string ) {
		if ( ! is_string( $string ) || empty( trim( $string ) ) ) {
			return false;
		}

		$string = trim( $string );
		// Check if the string starts with { or [ and ends with } or ].
		if ( ( '{' === $string[0] && '}' === $string[ strlen( $string ) - 1 ] ) ||
			( '[' === $string[0] && ']' === $string[ strlen( $string ) - 1 ] ) ) {
			json_decode( $string );
			return json_last_error() === JSON_ERROR_NONE;
		}

		return false;
	}

	/**
	 * Check conditional logic for trigger
	 *
	 * @param array<string, mixed>     $data The data containing conditional logic settings.
	 * @param array<string, mixed>     $submission_data The submission data to check against the rules.
	 * @param array<string, true>|null $form_fields Optional. Slugs of the fields the form defines; a rule on any
	 *                                               other field never matches. Null keeps the old behaviour.
	 *
	 * @since 1.10.0
	 * @return bool True if conditions are met, false otherwise.
	 */
	public static function check_trigger_conditions( $data, $submission_data = [], $form_fields = null ) {
		$trigger = true;

		if ( is_array( $data ) && ! isset( $data['conditionalLogic'] ) || ! is_array( $data['conditionalLogic'] ) ) {
			return $trigger; // If conditional logic is not set, return true.
		}

		$conditional_logic_status = isset( $data['conditionalLogic']['status'] ) && is_bool( $data['conditionalLogic']['status'] )
			? $data['conditionalLogic']['status']
			: false;

		$logic = isset( $data['conditionalLogic']['logic'] ) && is_string( $data['conditionalLogic']['logic'] )
			? $data['conditionalLogic']['logic']
			: '_AND_';

		$rules = isset( $data['conditionalLogic']['rules'] ) && is_array( $data['conditionalLogic']['rules'] )
			? $data['conditionalLogic']['rules']
			: [];

		if ( $conditional_logic_status
		&& ! empty( $logic ) &&
			count( $rules ) > 0
		) {
			return self::process_logic( $data['conditionalLogic'], $submission_data, $form_fields );
		}
		return $trigger;
	}

	/**
	 * Process conditional logic.
	 *
	 * @param array<string, mixed>     $rules logical conditions.
	 * @param array<string, mixed>     $submission_data The submission data to check against the rules.
	 * @param array<string, true>|null $form_fields Optional. See check_trigger_conditions().
	 *
	 * @since 1.10.0
	 * @return bool True if conditions are met, false otherwise.
	 */
	public static function process_logic( $rules, $submission_data = [], $form_fields = null ) {
		// By default trigger is true.
		$trigger = true;

		// If rules are not set, return true.
		if ( ! is_array( $rules ) || ! isset( $rules['logic'] ) || ! isset( $rules['rules'] ) || ! is_array( $rules['rules'] ) ) {
			return $trigger; // If rules are not set, return true.
		}

		// Check conditions in the rules. if conditions are not empty then process the conditions.
		switch ( self::normalize_logic_operator( $rules['logic'] ) ) {
			case '_AND_':
				foreach ( $rules['rules'] as $rule ) {
					if ( ! self::evaluate_rule( $rule, $submission_data, $form_fields ) ) {
						$trigger = false;
						break;
					}
				}
				break;
			case '_OR_':
				foreach ( $rules['rules'] as $rule ) {
					$result = self::evaluate_rule( $rule, $submission_data, $form_fields );
					if ( true === $result ) {
						$trigger = true;
						break;
					}
					if ( false === $result ) {
						$trigger = false;
					}
				}
				break;
		}

		return $trigger;
	}

	/**
	 * Normalize a conditional logic operator to `_AND_` / `_OR_`.
	 *
	 * Some editors seeded and sanitized the operator as plain `AND` / `OR`, which
	 * process_logic() did not recognise, so those rules were silently ignored.
	 * Accept them (case-insensitively) as aliases so already-saved forms work.
	 *
	 * @param mixed $logic Raw logic operator.
	 *
	 * @since 2.13.0
	 * @return mixed `_AND_` / `_OR_` for known aliases, otherwise the value unchanged.
	 */
	public static function normalize_logic_operator( $logic ) {
		if ( ! is_string( $logic ) ) {
			return $logic;
		}

		switch ( strtoupper( trim( $logic ) ) ) {
			case 'AND':
			case '_AND_':
				return '_AND_';
			case 'OR':
			case '_OR_':
				return '_OR_';
		}

		return $logic;
	}

	/**
	 * Get the editor default styles.
	 * This is the default styles for the editors (tinymce, html editor ).
	 *
	 * @since 1.12.1
	 * @return string
	 */
	public static function editor_default_styles() {
		return 'body {
						font-family: \'figtree\', sans-serif;
						font-size: 14px;
						color: #111827;
						line-height: 1.2;
					}
					h1, h2, h3, h4, h5, h6 {
						margin: 10px 0;
						color: #111827;
					}
					h1 { font-size: 32px; }
					h2 { font-size: 28px; }
					h3 { font-size: 24px; }
					h4 { font-size: 20px; }
					h5 { font-size: 16px; }
					h6 { font-size: 14px; }
					p {
						margin: 10px 0;
					}
					ul, ol {
						padding-left: 24px;
						margin-bottom: 16px;
					}
					ul li, ol li {
						margin-bottom: 8px;
					}
					pre {
						white-space: pre-wrap;
						word-wrap: break-word;
						overflow-wrap: break-word;
					}
					code {
						font-family: \'figtree\', sans-serif;
						font-size: 14px;
						color: #111827;
						background-color: #f3f4f6;
					}
					img.alignleft {
						float: left;
						margin: 0 15px 15px 0;
					}
					img.alignright {
						float: right;
						margin: 0 0 15px 15px;
					}
					img.aligncenter {
						display: block;
						margin-left: auto;
						margin-right: auto;
					}';
	}

	/**
	 * Normalize a rule field name by stripping smart-tag wrappers and form: prefixes.
	 *
	 * Handles both plain slugs and {form:field} smart-tag format:
	 * - Strips leading/trailing whitespace.
	 * - If a colon is present (e.g. "form:field"), keeps only the part after the colon.
	 * - Removes surrounding curly braces.
	 *
	 * @param string $field Raw field value from a conditional rule.
	 * @since 2.7.0
	 * @return string Normalized field slug.
	 */
	public static function normalize_rule_field_name( string $field ): string {
		$field = trim( $field );

		if ( false !== strpos( $field, ':' ) ) {
			$parts = explode( ':', $field, 2 );
			$field = isset( $parts[1] ) ? trim( $parts[1] ) : '';
		}

		return trim( str_replace( [ '{', '}' ], '', $field ) );
	}

	/**
	 * Process conditional logic.
	 *
	 * @param array<string, mixed> $rule logical condition.
	 * @param array<string, mixed> $submission_data The submission data to check against the rules.
	 *
	 * @since 1.10.0
	 * @return string|bool Returns 'field_not_found' if field is not found,
	 */
	public static function process_condition( $rule, $submission_data = [] ) {
		if ( ! is_array( $rule ) || ! isset( $rule['field'] ) ) {
			return 'field_not_found';
		}

		// Normalize field name: strip smart-tag wrappers and form: prefix.
		$rule['field'] = self::normalize_rule_field_name( SRFM_Helper::get_string_value( $rule['field'] ) );

		if ( ! isset( $submission_data[ $rule['field'] ] ) ) {
			/**
			 * Filters the resolved value for a conditional logic field that is not found in submission data.
			 *
			 * This allows external modules (e.g., Quiz) to provide values for smart tag fields
			 * like {quiz_score}, {quiz_percentage}, etc. that are not regular form fields.
			 *
			 * @since 2.6.0
			 *
			 * @param string|null           $field_value      The resolved field value. Return non-null to use this value.
			 * @param string                $field_name       The field name (smart tag without braces, e.g., 'quiz_score').
			 * @param array<string, mixed>  $submission_data  The submission data array.
			 */
			$resolved_value = apply_filters(
				'srfm_process_condition_field_value',
				null,
				$rule['field'],
				$submission_data
			);

			if ( null === $resolved_value ) {
				return 'field_not_found';
			}

			$submission_data[ $rule['field'] ] = $resolved_value;
		}

		$value = SRFM_Helper::get_string_value( $rule['value'] );
		$field = SRFM_Helper::get_string_value( $submission_data[ $rule['field'] ] );

		switch ( $rule['operator'] ) {
			case '_EQUAL_':
				$trigger = (
					$value === $field
				);
				break;

			case '_NOT_EQUAL_':
				$trigger = (
					$value !== $field
				);
				break;

			case '_GREATER_':
				$trigger = (
					$value < $field
				);
				break;

			case '_GREATER_OR_EQUAL_':
				$trigger = (
					$value <= $field
				);
				break;

			case '_LESSER_':
				$trigger = (
					$value > $field
				);
				break;

			case '_LESSER_OR_EQUAL_':
				$trigger = (
					$value >= $field
				);
				break;

			case '_STARTS_WITH_':
				$trigger = 0 === substr_compare(
					$field,
					$value,
					0,
					strlen( $value )
				);
				break;

			case '_ENDS_WITH_':
				$trigger = (
					0 === substr_compare(
						$field,
						$value,
						-strlen( $value )
					)
				);
				break;

			case '_CONTAINS_':
				$trigger = false !== strpos(
					$field,
					$value
				);
				break;
			case '_NOT_CONTAINS_':
				$trigger = false === strpos(
					$field,
					$value
				);
				break;

			case '_REGEX_':
				// Wrap in delimiters if not already a valid delimited pattern.
				if ( ! empty( $value ) && ! self::is_delimited_regex( $value ) ) {
					$value = '/' . str_replace( '/', '\/', $value ) . '/';
				}
				$trigger = ! empty( $value ) && 1 === preg_match( $value, $field );
				break;
			case '_IN_':
				$allowed     = array_map( 'trim', explode( ',', $value ) );
				$field_parts = array_map( 'trim', explode( ' | ', $field ) );
				$trigger     = ! empty( array_intersect( $field_parts, $allowed ) );
				break;

			case '_NOT_IN_':
				$allowed     = array_map( 'trim', explode( ',', $value ) );
				$field_parts = array_map( 'trim', explode( ' | ', $field ) );
				$trigger     = empty( array_intersect( $field_parts, $allowed ) );
				break;

			default:
				$trigger = true;
				break;
		}

		return $trigger;
	}

	/**
	 * Check if a string looks like a delimited PCRE regex pattern.
	 *
	 * Validates that the value starts and ends with a matching non-alphanumeric delimiter
	 * (e.g., /pattern/, #pattern#, ~pattern~) optionally followed by modifier flags.
	 *
	 * @param string $value The regex string to check.
	 * @since 2.5.2
	 * @return bool True if the value appears to have valid regex delimiters.
	 */
	public static function is_delimited_regex( $value ) {
		if ( ! is_string( $value ) || strlen( $value ) < 2 ) {
			return false;
		}

		$delimiter = $value[0];

		// PCRE delimiters must be non-alphanumeric, non-backslash, non-whitespace.
		if ( ctype_alnum( $delimiter ) || '\\' === $delimiter || ctype_space( $delimiter ) ) {
			return false;
		}

		// Handle paired delimiters (brackets).
		$closing_delimiters = [
			'(' => ')',
			'[' => ']',
			'{' => '}',
			'<' => '>',
		];

		$closing = $closing_delimiters[ $delimiter ] ?? $delimiter;

		// Find last occurrence of closing delimiter (modifiers may follow).
		$last_pos = strrpos( $value, $closing, 1 );

		if ( false === $last_pos || $last_pos < 1 ) {
			return false;
		}

		// Everything after the closing delimiter should be valid modifier flags.
		$modifiers = substr( $value, $last_pos + 1 );

		return 1 === preg_match( '/^[imsxADSUXJun]*$/', $modifiers );
	}

	/**
	 * Extracts the field type from the dynamic field key (or field slug) that starts with "srfm".
	 *
	 * This function is used to extract the field type prefix (e.g., "srfm-email" from "srfm-email-xxxx-lbl-email")
	 * from a dynamic field key. It checks if the key contains the "-lbl-" delimiter and if the prefix starts with "srfm".
	 * If so, it returns the prefix in the format "srfm-<type>", otherwise returns an empty string.
	 *
	 * @param string $field_key Dynamic field key.
	 * @since 1.12.2
	 * @return string Extracted field type (e.g., "srfm-email"), or empty string if not found.
	 */
	public static function get_field_type_from_key_with_srfm( $field_key ) {

		if ( false === strpos( $field_key, '-lbl-' ) ) {
			return '';
		}

		$parts = explode( '-', $field_key );

		// Check if the key starts with "srfm" and has a valid type part.
		// Example: "srfm-email-xxxx-lbl-email" => returns "srfm-email".
		if ( isset( $parts[0], $parts[1] ) && 'srfm' === $parts[0] && is_string( $parts[1] ) ) {
			return trim( $parts[0] . '-' . $parts[1] );
		}

		return '';
	}

	/**
	 * Extracts the block ID from a dynamic field key.
	 *
	 * Field keys follow the format: srfm-{type}-{block_id}-lbl-{label}
	 * Example: "srfm-upload-abc12345-lbl-upload" => returns "abc12345".
	 *
	 * @param string $field_key Dynamic field key.
	 * @since 2.5.0
	 * @return string Extracted block ID, or empty string if not found.
	 */
	public static function get_block_id( $field_key ) {
		if ( false === strpos( $field_key, '-lbl-' ) ) {
			return '';
		}

		$before_lbl = explode( '-lbl-', $field_key )[0];
		$parts      = explode( '-', $before_lbl );

		// Index 2 is the block ID: srfm(0)-{type}(1)-{block_id}(2).
		return $parts[2] ?? '';
	}

	/**
	 * Base64-encode a string.
	 *
	 * SRFM wrapper around base64_encode() that keeps phpcs obfuscation
	 * warnings contained to a single, well-documented location.
	 *
	 * @param string $data The string to encode.
	 * @since 2.5.0
	 * @return string The base64-encoded string.
	 */
	public static function srfm_base64_encode( $data ) { // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode
		return base64_encode( $data ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode
	}

	/**
	 * Base64-decode a string.
	 *
	 * SRFM wrapper around base64_decode() that keeps phpcs obfuscation
	 * warnings contained to a single, well-documented location.
	 * Always uses strict mode so only valid base64 input is accepted.
	 *
	 * @param string $data   The base64-encoded string to decode.
	 * @since 2.5.0
	 * @return string|false The decoded string, or false on failure.
	 */
	public static function srfm_base64_decode( $data ) { // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_decode
		return base64_decode( $data, true ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_decode
	}

	/**
	 * Sanitize conditional logic array.
	 *
	 * @param array $logic The conditionalLogic array.
	 * @return array Sanitized conditionalLogic array.
	 * @since 2.2.0
	 */
	public static function sanitize_conditional_logic( $logic ) {
		if ( ! is_array( $logic ) ) {
			return [
				'status' => false,
				'logic'  => '_OR_',
				'rules'  => [],
			];
		}

		$rules = [];

		if ( isset( $logic['rules'] ) && is_array( $logic['rules'] ) ) {
			foreach ( $logic['rules'] as $rule ) {
				if ( ! is_array( $rule ) ) {
					continue;
				}
				$rules[] = [
					'field'    => isset( $rule['field'] ) ? sanitize_text_field( $rule['field'] ) : '',
					'operator' => isset( $rule['operator'] ) ? sanitize_text_field( $rule['operator'] ) : '_EQUAL_',
					'value'    => isset( $rule['value'] ) ? sanitize_text_field( $rule['value'] ) : '',
				];
			}
		}

		return [
			'status' => isset( $logic['status'] ) ? (bool) $logic['status'] : false,
			'logic'  => isset( $logic['logic'] ) ? sanitize_text_field( $logic['logic'] ) : '_OR_',
			'rules'  => $rules,
		];
	}

	/**
	 * Build a localized "(Retried by <user>)" suffix for retry activity-log messages.
	 *
	 * Runs inside the authenticated admin retry AJAX handler, so the current user is
	 * available. Returns an empty string when no user can be resolved (e.g. WP-CLI),
	 * so callers can safely concatenate it unconditionally.
	 *
	 * @since 2.12.1
	 * @return string Leading-space suffix like " (Retried by Jane Doe)", or '' when no actor.
	 */
	public static function get_retry_actor_note() {
		$user = wp_get_current_user();
		$name = $user instanceof \WP_User && $user->exists()
			? sanitize_text_field( $user->display_name )
			: '';
		if ( '' === $name ) {
			return '';
		}
		return ' ' . sprintf(
			/* translators: %s: display name of the admin who triggered the retry. */
			__( '(Retried by %s)', 'sureforms-pro' ),
			$name
		);
	}

	/**
	 * Remove the retry tag from an entry's activity-log rows for a given trigger.
	 *
	 * Called after a manual webhook / native-integration retry SUCCEEDS, so the
	 * original failed log row no longer offers a "Retry" button (the trigger is no
	 * longer failed). Replaces the logs column wholesale via use_update() because
	 * Entries::update() append-merges the logs array rather than replacing it.
	 *
	 * @param int    $entry_id Entry ID.
	 * @param string $type     Trigger type ('webhook' | 'native').
	 * @param string $id       Trigger id (webhook/workflow id).
	 * @since 2.12.1
	 * @return void
	 */
	public static function clear_log_retry_tag( $entry_id, $type, $id ) {
		$entry_id = SRFM_Helper::get_integer_value( $entry_id );
		if ( ! $entry_id ) {
			return;
		}

		$entry = Entries::get( $entry_id );
		$logs  = SRFM_Helper::get_array_value( $entry['logs'] ?? [] );

		$changed = false;
		foreach ( $logs as $index => $log ) {
			if (
				is_array( $log )
				&& isset( $log['retry'] ) && is_array( $log['retry'] )
				&& isset( $log['retry']['type'], $log['retry']['id'] )
				&& $log['retry']['type'] === $type
				&& SRFM_Helper::get_string_value( $log['retry']['id'] ) === SRFM_Helper::get_string_value( $id )
			) {
				// Operate on the narrowed $log (a confirmed array) and reassign, so
				// PHPStan keeps a concrete type rather than offset-on-mixed.
				unset( $log['retry'] );
				$logs[ $index ] = $log;
				$changed        = true;
			}
		}

		if ( $changed ) {
			// use_update() replaces the column (Entries::update() would merge the logs).
			Entries::get_instance()->use_update( [ 'logs' => array_values( $logs ) ], [ 'ID' => $entry_id ] );
		}
	}

	/**
	 * Evaluate one rule. A rule on a field the form does not define (for
	 * example one a template swap removed) is false, never matched: it can't be
	 * checked, so it must not let a conditional action through. With no field
	 * list the result is process_condition()'s, unchanged.
	 *
	 * @param mixed                    $rule            Rule.
	 * @param array<string, mixed>     $submission_data Submission data.
	 * @param array<string, true>|null $form_fields     Slugs of the form's fields, or null.
	 *
	 * @since 2.13.0
	 * @return string|bool
	 */
	private static function evaluate_rule( $rule, $submission_data, $form_fields ) {
		$result = is_array( $rule ) ? self::process_condition( $rule, $submission_data ) : 'field_not_found';

		if ( 'field_not_found' !== $result || ! is_array( $form_fields ) || [] === $form_fields ) {
			return $result;
		}

		$field = is_array( $rule ) && isset( $rule['field'] ) ? self::normalize_rule_field_name( SRFM_Helper::get_string_value( $rule['field'] ) ) : '';

		return isset( $form_fields[ $field ] ) ? $result : false;
	}
}
