<?php

namespace MasterStudy\Lms\Pro\addons\enterprise_courses\Admin\Controllers;

use MasterStudy\Lms\Http\WpResponseFactory;
use MasterStudy\Lms\Pro\addons\enterprise_courses\Admin\Repositories\EnterpriseGroupsRepository;
use WP_REST_Request;
use WP_REST_Response;

final class BulkDeleteEnterpriseGroupsController {
	public function __invoke( WP_REST_Request $request ): WP_REST_Response {
		$data = $request->get_json_params();
		$ids  = array_map( 'intval', (array) ( $data['ids'] ?? array() ) );

		if ( empty( $ids ) ) {
			return WpResponseFactory::bad_request( esc_html__( 'No enterprise groups selected.', 'masterstudy-lms-learning-management-system-pro' ) );
		}

		$repo = new EnterpriseGroupsRepository();

		foreach ( $ids as $group_id ) {
			$result = $repo->delete( $group_id );

			if ( is_wp_error( $result ) ) {
				return WpResponseFactory::error( $result->get_error_message() );
			}
		}

		return new WP_REST_Response( array( 'success' => true ) );
	}
}
