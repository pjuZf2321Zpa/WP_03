<?php

class MSLMS_ClassroomsAdminMenus {

	public function __construct() {
		add_action( 'admin_menu', array( $this, 'register_menus' ), 100 );
	}

	public function register_menus() {
		add_menu_page(
			__( 'Classrooms', 'masterstudy-lms-learning-management-system-pro' ),
			__( 'Classrooms', 'masterstudy-lms-learning-management-system-pro' ),
			'manage_options',
			'mslms_classrooms',
			array( $this, 'render_page' ),
			'dashicons-groups',
			4
		);

		add_submenu_page(
			'mslms_classrooms',
			__( 'Classroom Auditory', 'masterstudy-lms-learning-management-system-pro' ),
			__( 'Classroom Auditory', 'masterstudy-lms-learning-management-system-pro' ),
			'manage_options',
			'mslms_classroom_auditory',
			array( $this, 'render_page' )
		);
	}

	public function render_page() {
		require_once STM_LMS_PRO_ADDONS . '/google_classrooms/Admin/Layouts/dashboard.php';
	}
}
