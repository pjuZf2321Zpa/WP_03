<?php

if (!defined('ABSPATH')) {
    die('You are not allowed to call this page directly.');
}

class MeprCartOrdersCtrl extends MeprBaseCartCtrl
{
    /**
     * The admin page hook for the cart orders screen.
     *
     * @var string
     */
    public static $screen_hook = 'memberpress_page_memberpress-orders';

    /**
     * Load hooks for various actions and filters.
     *
     * @return void
     */
    public function load_hooks()
    {
        $hook = self::$screen_hook;

        add_action("load-{$hook}", [$this, 'add_screen_options']);
        add_filter('set_screen_option_mp_cart_orders_perpage', [$this, 'setup_screen_options'], 10, 3);
        add_filter("manage_{$hook}_columns", [$this, 'get_columns'], 0);
        add_action('admin_enqueue_scripts', [$this, 'enqueue_scripts']);
        add_action('mepr_cart_orders_search', [$this, 'table_search_box']);
        add_action('wp_ajax_mepr_add_order_note', [$this, 'add_order_note']);
        add_action('wp_ajax_mepr_refund_cart_order', [$this, 'refund_cart_order']);
        add_action('wp_ajax_mepr_cancel_cart_order', [$this, 'cancel_cart_order']);
        add_action('wp_ajax_mepr_complete_cart_order', [$this, 'complete_cart_order']);
        add_action('wp_ajax_mepr_resend_cart_receipt', [$this, 'resend_cart_receipt']);
    }

    /**
     * Main routing method for the orders admin page.
     *
     * @return void
     */
    public function listing()
    {
        $action = isset($_REQUEST['action']) && !empty($_REQUEST['action'])
            ? sanitize_key(wp_unslash($_REQUEST['action']))
            : false;

        if ($action === 'detail') {
            $this->detail();
        } else {
            $this->display_list();
        }
    }

    /**
     * Display the order detail page.
     *
     * @return void
     */
    public function detail()
    {
        $id    = isset($_REQUEST['id']) ? intval(wp_unslash($_REQUEST['id'])) : 0;
        $order = $id > 0 ? new MeprOrder((array) MeprOrder::get_one($id)) : null;

        if (!$order || !$order->id || $order->order_type !== MeprOrder::$cart_type_str) {
            MeprView::render('/admin/cart-orders/invalid');
            return;
        }

        $transactions = MeprTransaction::get_all_by_order_id_for_display($order->id);
        $user         = new MeprUser($order->user_id);
        $mepr_options = MeprOptions::fetch();

        $billing_address = [
            'first_name' => $order->get_meta('_mepr_billing_first_name', true),
            'last_name'  => $order->get_meta('_mepr_billing_last_name', true),
            'address_1'  => $order->get_meta('_mepr_billing_address_1', true),
            'address_2'  => $order->get_meta('_mepr_billing_address_2', true),
            'city'       => $order->get_meta('_mepr_billing_city', true),
            'state'      => $order->get_meta('_mepr_billing_state', true),
            'zip'        => $order->get_meta('_mepr_billing_zip', true),
            'country'    => $order->get_meta('_mepr_billing_country', true),
        ];

        $shipping_address = [
            'first_name' => $order->get_meta('_mepr_shipping_first_name', true),
            'last_name'  => $order->get_meta('_mepr_shipping_last_name', true),
            'address_1'  => $order->get_meta('_mepr_shipping_address_1', true),
            'address_2'  => $order->get_meta('_mepr_shipping_address_2', true),
            'city'       => $order->get_meta('_mepr_shipping_city', true),
            'state'      => $order->get_meta('_mepr_shipping_state', true),
            'zip'        => $order->get_meta('_mepr_shipping_zip', true),
            'country'    => $order->get_meta('_mepr_shipping_country', true),
        ];

        $notes           = $order->get_notes();
        $saved_method    = ($order->payment_method_id > 0) ? new MeprSavedPaymentMethod($order->payment_method_id) : null;
        $gateway_pm      = $mepr_options->payment_method($order->gateway);
        $show_tax_column = $order->should_display_tax($transactions);

        MeprView::render('/admin/cart-orders/detail', get_defined_vars());
    }

    /**
     * Display the cart orders list page.
     *
     * @return void
     */
    public function display_list()
    {
        $screen     = get_current_screen();
        $list_table = new MeprCartOrdersTable($screen, $this->get_columns());
        $list_table->prepare_items();

        MeprView::render('/admin/cart-orders/list', compact('list_table'));
    }

    /**
     * Get the column definitions for the cart orders table.
     *
     * @return array The column definitions.
     */
    public function get_columns()
    {
        $cols = [
            'col_trans_num'  => __('Order #', 'memberpress'),
            'col_customer'   => __('Customer', 'memberpress'),
            'col_items'      => __('Items', 'memberpress'),
            'col_total'      => __('Total', 'memberpress'),
            'col_status'     => __('Status', 'memberpress'),
            'col_gateway'    => __('Gateway', 'memberpress'),
            'col_created_at' => __('Date', 'memberpress'),
        ];

        return MeprHooks::apply_filters('mepr_admin_cart_orders_cols', $cols);
    }

    /**
     * Add per-page screen option for the cart orders page.
     *
     * @return void
     */
    public function add_screen_options()
    {
        add_screen_option('layout_columns');

        add_screen_option('per_page', [
            'label'   => __('Orders', 'memberpress'),
            'default' => 20,
            'option'  => 'mp_cart_orders_perpage',
        ]);
    }

    /**
     * Save the per-page screen option value.
     *
     * @param mixed  $status The current status.
     * @param string $option The option name.
     * @param mixed  $value  The option value.
     *
     * @return mixed The updated value.
     */
    public function setup_screen_options($status, $option, $value)
    {
        if ('mp_cart_orders_perpage' === $option) {
            return $value;
        }
        return $status;
    }

    /**
     * AJAX handler for adding an order note from the admin order detail page.
     *
     * @return void
     */
    public function add_order_note()
    {
        check_ajax_referer('mepr_add_order_note', 'nonce');

        if (!MeprUtils::is_mepr_admin()) {
            wp_send_json_error(['message' => __('Permission denied.', 'memberpress')]);
        }

        $order_id = isset($_POST['order_id']) ? intval(wp_unslash($_POST['order_id'])) : 0;
        $message  = isset($_POST['message']) ? sanitize_textarea_field(wp_unslash($_POST['message'])) : '';
        $type     = isset($_POST['type']) ? sanitize_key(wp_unslash($_POST['type'])) : 'admin';

        if ($order_id <= 0 || empty($message)) {
            wp_send_json_error(['message' => __('Order ID and message are required.', 'memberpress')]);
        }

        $allowed_types = ['admin', 'customer'];
        if (!in_array($type, $allowed_types, true)) {
            $type = 'admin';
        }

        $order = new MeprOrder((array) MeprOrder::get_one($order_id));

        if (!$order->id || $order->order_type !== MeprOrder::$cart_type_str) {
            wp_send_json_error(['message' => __('Order not found.', 'memberpress')]);
        }

        $order->add_note($message, $type, get_current_user_id());

        $note = [
            'message'    => $message,
            'type'       => $type,
            'user_id'    => get_current_user_id(),
            'created_at' => current_time('mysql', true),
        ];

        $note_html = MeprView::get_string('/admin/cart-orders/order-note-item', compact('note'));

        wp_send_json_success(['html' => $note_html]);
    }

    /**
     * AJAX handler for processing a cart order refund.
     *
     * Accepts: order_id (required), transaction_id (optional), amount (optional), reason (optional).
     * Delegates to MeprCartCheckoutService::process_cart_refund().
     *
     * @return void
     */
    public function refund_cart_order()
    {
        check_ajax_referer('mepr_cart_order_actions', 'nonce');

        if (!MeprUtils::is_mepr_admin()) {
            wp_send_json_error(['message' => __('Permission denied.', 'memberpress')]);
        }

        $order_id       = isset($_POST['order_id']) ? intval(wp_unslash($_POST['order_id'])) : 0;
        $transaction_id = isset($_POST['transaction_id']) && $_POST['transaction_id'] !== ''
            ? intval(wp_unslash($_POST['transaction_id']))
            : null;
        $amount         = isset($_POST['amount']) && $_POST['amount'] !== ''
            ? (float) sanitize_text_field(wp_unslash($_POST['amount']))
            : null;
        $reason         = isset($_POST['reason']) ? sanitize_textarea_field(wp_unslash($_POST['reason'])) : '';

        if ($order_id <= 0) {
            wp_send_json_error(['message' => __('Invalid order ID.', 'memberpress')]);
        }

        $order = new MeprOrder((array) MeprOrder::get_one($order_id));

        if (!$order->id || $order->order_type !== MeprOrder::$cart_type_str) {
            wp_send_json_error(['message' => __('Order not found.', 'memberpress')]);
        }

        if ($amount !== null && $amount <= 0) {
            wp_send_json_error(['message' => __('Refund amount must be greater than zero.', 'memberpress')]);
        }

        // Bail early if the target transaction(s) are already refunded.
        if ($transaction_id !== null) {
            $txn_row = MeprTransaction::get_one($transaction_id);
            if ($txn_row && $txn_row->status === MeprTransaction::$refunded_str) {
                wp_send_json_error(['message' => __('This item has already been refunded.', 'memberpress')]);
            }
        } else {
            // Confirmation rows never flip to refunded — exclude them or this guard never fires.
            $txns         = MeprTransaction::get_all_by_order_id_for_display($order_id);
            $all_refunded = !empty($txns) && array_reduce($txns, function ($carry, $txn) {
                return $carry && $txn->status === MeprTransaction::$refunded_str;
            }, true);
            if ($all_refunded) {
                wp_send_json_error(['message' => __('This order has already been fully refunded.', 'memberpress')]);
            }
        }

        $result = MeprCartPaymentService::process_refund($order, $transaction_id, $amount, $reason);

        if (!$result['success']) {
            wp_send_json_error(['message' => $result['error']]);
        }

        // The refunded row repaints from this, so format it here rather than in the browser,
        // whose locale need not match the site's.
        // Resolved from the order's transactions, the same way the rendered page does it
        // (admin/cart-orders/detail.php) — otherwise the repainted row can pick a different
        // symbol from the one printed beside it.
        $order_after    = new MeprOrder($order->id);
        $order_currency = MeprCartOrderDisplayHelper::resolve_order_currency(
            MeprTransaction::get_all_by_order_id($order->id),
            $order_after->currency
        );

        $response = [
            'refunded_amount'           => $result['refunded_amount'],
            'amount_refunded_formatted' => MeprAppHelper::format_currency_for_json(
                (float) $order_after->amount_refunded,
                true,
                false,
                false,
                $order_currency
            ),
            'order_status'    => $result['order_status'],
            'message'         => sprintf(
                // Translators: %s: Formatted currency amount, symbol included.
                __('Refunded %s successfully.', 'memberpress'),
                MeprAppHelper::format_currency_for_json((float) $result['refunded_amount'], true, false, false, $order_currency)
            ),
        ];

        if ($transaction_id !== null) {
            $txn_row = MeprTransaction::get_one($transaction_id);
            if ($txn_row) {
                $refunded_txn               = new MeprTransaction($transaction_id);
                $line_total                 = (float) $refunded_txn->total;
                $line_refunded              = $refunded_txn->get_amount_refunded();
                $line_remaining             = $refunded_txn->get_refundable_remaining();
                $response['txn_id']         = (int) $refunded_txn->id;
                $response['txn_status']     = $refunded_txn->status;
                $response['line_total']     = $line_total;
                $response['line_refunded']  = $line_refunded;
                $response['line_remaining'] = $line_remaining;
                // The tooltip line is painted before the reload, so format it here too.
                $response['line_total_formatted']    = MeprAppHelper::format_currency_for_json($line_total, true, false, false, $order_currency);
                $response['line_refunded_formatted'] = MeprAppHelper::format_currency_for_json($line_refunded, true, false, false, $order_currency);
                $response['is_partial']     = $refunded_txn->status === MeprTransaction::$complete_str
                    && $line_refunded > 0.01
                    && $line_remaining > 0.01;

                // "When" for the tooltip painted client-side before reload. A full refund has
                // refunded_at persisted; a partial refund has no such column, so "now" is the
                // best available timestamp for this action (matches the order note just added).
                $response['refund_time'] = !empty($refunded_txn->refunded_at)
                    ? MeprAppHelper::format_date($refunded_txn->refunded_at)
                    : MeprAppHelper::format_date(current_time('mysql', true));
            }
        }

        wp_send_json_success($response);
    }

    /**
     * AJAX handler for cancelling a cart order or individual order item.
     *
     * Accepts: order_id (required), transaction_id (optional for per-item), reason (optional).
     * Delegates to MeprCartCheckoutService::cancel_cart_order_item() or cancel_cart_order().
     *
     * @return void
     */
    public function cancel_cart_order()
    {
        check_ajax_referer('mepr_cart_order_actions', 'nonce');

        if (!MeprUtils::is_mepr_admin()) {
            wp_send_json_error(['message' => __('Permission denied.', 'memberpress')]);
        }

        $order_id       = isset($_POST['order_id']) ? intval(wp_unslash($_POST['order_id'])) : 0;
        $transaction_id = isset($_POST['transaction_id']) && $_POST['transaction_id'] !== ''
            ? intval(wp_unslash($_POST['transaction_id']))
            : null;
        $reason         = isset($_POST['reason']) ? sanitize_textarea_field(wp_unslash($_POST['reason'])) : '';

        if ($order_id <= 0) {
            wp_send_json_error(['message' => __('Invalid order ID.', 'memberpress')]);
        }

        $order = new MeprOrder((array) MeprOrder::get_one($order_id));

        if (!$order->id || $order->order_type !== MeprOrder::$cart_type_str) {
            wp_send_json_error(['message' => __('Order not found.', 'memberpress')]);
        }

        $skip_subscription_ids = isset($_POST['skip_subscription_ids']) && is_array($_POST['skip_subscription_ids'])
            ? array_map('intval', wp_unslash($_POST['skip_subscription_ids']))
            : [];

        $refunded_amount = isset($_POST['refunded_amount'])
            ? (float) sanitize_text_field(wp_unslash($_POST['refunded_amount']))
            : 0.0;

        if ($transaction_id !== null) {
            $result = MeprCartCheckoutService::cancel_cart_order_item($order, $transaction_id, $reason);
        } else {
            $result = MeprCartCheckoutService::cancel_cart_order($order, $reason, [
                'skip_subscription_ids' => $skip_subscription_ids,
                'refunded_amount'       => $refunded_amount,
            ]);
        }

        if (!$result['success']) {
            wp_send_json_error(['message' => $result['error']]);
        }

        $access_until = '';
        if ($transaction_id !== null) {
            $cancelled_txn = new MeprTransaction($transaction_id);
            if ((int) $cancelled_txn->subscription_id > 0) {
                $cancelled_sub = new MeprSubscription((int) $cancelled_txn->subscription_id);
                if ($cancelled_sub->id > 0) {
                    $sub_exp_txn = $cancelled_sub->expiring_txn();
                    if ($sub_exp_txn && !empty($sub_exp_txn->expires_at)) {
                        $access_until = MeprAppHelper::format_date($sub_exp_txn->expires_at);
                    }
                }
            }
        }

        wp_send_json_success([
            'order_status' => $result['order_status'],
            'message'      => __('Cancelled successfully.', 'memberpress'),
            'access_until' => $access_until,
        ]);
    }

    /**
     * Render the search box for the cart orders list.
     *
     * @return void
     */
    public function table_search_box()
    {
        if (isset($_REQUEST['page']) && sanitize_key(wp_unslash($_REQUEST['page'])) === 'memberpress-orders') {
            MeprView::render('/admin/cart-orders/search_box');
        }
    }

    /**
     * Enqueue admin CSS and JS on the cart orders page only.
     *
     * @param string $hook The current admin page hook.
     *
     * @return void
     */
    public function enqueue_scripts($hook)
    {
        if ($hook !== self::$screen_hook) {
            return;
        }

        wp_enqueue_style(
            'mepr-cart-orders-css',
            MEPR_CSS_URL . '/admin-cart-orders.css',
            ['mepr-cart-tokens', 'mepr-ds-components'],
            self::cart_asset_ver('/admin-cart-orders.css')
        );

        $action = isset($_REQUEST['action']) ? sanitize_key(wp_unslash($_REQUEST['action'])) : '';

        if ($action === 'detail' && isset($_REQUEST['id'])) {
            wp_enqueue_script(
                'mepr-cart-orders-js',
                MEPR_JS_URL . '/admin/cart-orders.js',
                ['jquery'],
                MEPR_VERSION,
                true
            );

            // Build active subscriptions for this order for the cancel flow.
            $order_id_for_js = intval(wp_unslash($_REQUEST['id']));
            $order_for_js    = new MeprOrder((array) MeprOrder::get_one($order_id_for_js));
            $subscriptions_for_js = [];
            $txns_for_js          = $order_for_js->id ? MeprTransaction::get_all_by_order_id($order_for_js->id) : [];

            if ($order_for_js->id) {
                $seen_sub_ids_js = [];
                foreach ($txns_for_js as $txn_js) {
                    // Skip confirmation txns and any subscription already listed so each
                    // subscription shows only once in the cancel modal.
                    if ($txn_js->txn_type === MeprTransaction::$subscription_confirmation_str) {
                        continue;
                    }
                    if ((int) $txn_js->subscription_id > 0 && !in_array((int) $txn_js->subscription_id, $seen_sub_ids_js, true)) {
                        $seen_sub_ids_js[] = (int) $txn_js->subscription_id;
                        $sub_js = new MeprSubscription((int) $txn_js->subscription_id);
                        if ($sub_js->id && in_array($sub_js->status, [MeprSubscription::$active_str, MeprSubscription::$pending_str], true)) {
                            $product_js = new MeprProduct((int) $txn_js->product_id);
                            $exp_txn    = $sub_js->expiring_txn();
                            $renews_at  = '';
                            if ($exp_txn && !empty($exp_txn->expires_at)) {
                                $renews_at = MeprAppHelper::format_date($exp_txn->expires_at);
                            }
                            $subscriptions_for_js[] = [
                                'id'          => (int) $sub_js->id,
                                'productName' => $product_js->post_title ?: __('(Unknown Product)', 'memberpress'),
                                'renewsAt'    => $renews_at,
                            ];
                        }
                    }
                }
            }

            // Resolved once: the display strings below and the JS fallback both key off it.
            $order_currency_for_js = (string) MeprCartOrderDisplayHelper::resolve_order_currency(
                $txns_for_js,
                $order_for_js->currency
            );

            wp_localize_script('mepr-cart-orders-js', 'meprCartOrders', [
                'ajaxUrl'       => admin_url('admin-ajax.php'),
                'nonce'         => wp_create_nonce('mepr_add_order_note'),
                'actionNonce'   => wp_create_nonce('mepr_cart_order_actions'),
                'orderId'          => $order_id_for_js,
                'orderTotal'       => $order_for_js->id ? (float) $order_for_js->total : 0,
                'orderCurrency'    => strtoupper($order_currency_for_js),
                'currencySymbol'   => MeprCurrencyService::get_symbol($order_currency_for_js),
                'symbolAfter'      => MeprCurrencyService::is_symbol_after($order_currency_for_js),
                'isZeroDecimal'    => MeprCurrencyService::is_zero_decimal($order_currency_for_js),
                // Server-rendered display strings; the JS only formats amounts typed into the
                // refund field, which have no server round-trip to format them.
                'orderTotalFormatted' => $order_for_js->id
                    ? MeprAppHelper::format_currency_for_json((float) $order_for_js->total, true, false, false, $order_currency_for_js)
                    : '',
                'amountRefunded'   => $order_for_js->id ? (float) $order_for_js->amount_refunded : 0,
                'refundable'       => $order_for_js->id ? max(0, (float) $order_for_js->total - (float) $order_for_js->amount_refunded) : 0,
                'subscriptions'    => $subscriptions_for_js,
                'isOfflinePending' => $order_for_js->id
                    && $order_for_js->status === MeprOrder::$pending_str
                    && MeprCartPaymentService::get_active_gateway($order_for_js->gateway) instanceof MeprArtificialGateway,
                'i18n'          => [
                    'adding'              => __('Adding...', 'memberpress'),
                    'add'                 => __('Add Note', 'memberpress'),
                    'error'               => __('Failed to add note. Please try again.', 'memberpress'),
                    'confirm_refund'      => __('Are you sure you want to process this refund?', 'memberpress'),
                    'confirm_cancel'      => __('Are you sure you want to cancel this item?', 'memberpress'),
                    'processing'          => __('Processing...', 'memberpress'),
                    'refund'              => __('Refund', 'memberpress'),
                    'cancel'              => __('Cancel', 'memberpress'),
                    'cancel_order'        => __('Cancel Order', 'memberpress'),
                    'refunded'            => __('Refunded', 'memberpress'),
                    'partially_refunded'  => __('Partially refunded', 'memberpress'),
                    'complete'            => __('Complete', 'memberpress'),
                    'details'             => __('Details', 'memberpress'),
                    'cancelled'               => __('Cancelled', 'memberpress'),
                    'subscription_cancelled'  => __('Subscription cancelled', 'memberpress'),
                    // Translators: %s: Access end date.
                    'access_until'            => __('Access until %s', 'memberpress'),
                    // Translators: %s: Access end date.
                    'cancelled_access_until'  => __('Cancelled — Access until %s', 'memberpress'),
                    // Translators: 1: Refunded amount. 2: Line total.
                    'refunded_of'         => __('Refunded %1$s of %2$s', 'memberpress'),
                    // Translators: 1: Refunded amount. 2: Line total. 3: Refund date.
                    'refunded_of_date'    => __('Refunded %1$s of %2$s — %3$s', 'memberpress'),
                    // Translators: %s: Date the refund happened.
                    'refunded_on'         => __('Refunded on %s', 'memberpress'),
                    'refund_error'        => __('Refund failed. Please try again.', 'memberpress'),
                    'cancel_error'        => __('Cancellation failed. Please try again.', 'memberpress'),
                    'invalid_amount'      => __('Please enter a valid refund amount.', 'memberpress'),
                    'reason_label'        => __('Reason (optional)', 'memberpress'),
                    'amount_label'        => __('Amount', 'memberpress'),
                    'confirm_btn'         => __('Confirm', 'memberpress'),
                    'next_btn'            => __('Next', 'memberpress'),
                    'back_btn'            => __('Back', 'memberpress'),
                    'close'               => __('Close', 'memberpress'),
                    'refund_title'        => __('Choose Refund', 'memberpress'),
                    'refund_full'         => __('Full refund', 'memberpress'),
                    'refund_partial'      => __('Partial refund', 'memberpress'),
                    'refund_none'         => __('No refund', 'memberpress'),
                    'subs_title'          => __('Cancel Subscriptions', 'memberpress'),
                    'subs_label'          => __('These subscriptions will also be cancelled:', 'memberpress'),
                    // Translators: %s: next renewal date.
                    'subs_renews'         => __('Renews %s', 'memberpress'),
                    'reason_title'        => __('Reason', 'memberpress'),
                    'summary_title'       => __('Review Cancellation', 'memberpress'),
                    'summary_intro'       => __('You are about to:', 'memberpress'),
                    // Translators: %s: refund amount.
                    'summary_refund_full' => __('Refund %s to customer', 'memberpress'),
                    // Translators: %s: refund amount.
                    'summary_refund_part' => __('Partial refund of %s to customer', 'memberpress'),
                    'summary_no_refund'   => __('No refund', 'memberpress'),
                    // Translators: %s: subscription product name.
                    'summary_cancel_sub'  => __('Cancel subscription: %s', 'memberpress'),
                    'summary_cancel_order' => __('Cancel this order', 'memberpress'),
                    'confirm_cancel_btn'      => __('Confirm Cancellation', 'memberpress'),
                    'complete_order_title'    => __('Mark Order as Complete', 'memberpress'),
                    'complete_order_body'     => __('This will complete the order, activate any subscriptions, and send the customer a receipt. This cannot be undone.', 'memberpress'),
                    'complete_order_btn'      => __('Complete Order', 'memberpress'),
                    'complete_order_success'  => __('Order marked as complete.', 'memberpress'),
                    'complete_order_error'    => __('Could not complete the order. Please try again.', 'memberpress'),
                    'resend_receipt'          => __('Resend Receipt', 'memberpress'),
                    'resend_receipt_sending'  => __('Sending...', 'memberpress'),
                    'resend_receipt_success'  => __('Receipt email resent.', 'memberpress'),
                    'resend_receipt_error'    => __('Could not resend the receipt. Please try again.', 'memberpress'),
                    'cancel_reason_items' => MeprHooks::apply_filters('mepr_admin_cancel_order_reasons', [
                        ''             => __('Select reason...', 'memberpress'),
                        'customer'     => __('Customer request', 'memberpress'),
                        'duplicate'    => __('Duplicate order', 'memberpress'),
                        'fraud'        => __('Fraud', 'memberpress'),
                        'out_of_stock' => __('Out of stock', 'memberpress'),
                        'other'        => __('Other', 'memberpress'),
                    ]),
                ],
            ]);
        }
    }

    /**
     * AJAX: Mark a pending offline cart order as complete.
     *
     * Guards: nonce, MemberPress admin capability, pending status, offline gateway.
     * Calls complete_cart_order() then fires offline webhook events.
     */
    public function complete_cart_order()
    {
        check_ajax_referer('mepr_cart_order_actions', 'nonce');

        if (!MeprUtils::is_mepr_admin()) {
            wp_send_json_error(['message' => __('Permission denied.', 'memberpress')]);
        }

        $order_id = isset($_POST['order_id']) ? (int) $_POST['order_id'] : 0;
        if ($order_id <= 0) {
            wp_send_json_error(['message' => __('Invalid order ID.', 'memberpress')]);
        }

        $order = new MeprOrder((array) MeprOrder::get_one($order_id));

        if (!$order->id || $order->order_type !== MeprOrder::$cart_type_str) {
            wp_send_json_error(['message' => __('Order not found.', 'memberpress')]);
        }

        if ($order->status !== MeprOrder::$pending_str) {
            wp_send_json_error(['message' => __('Only pending orders can be completed.', 'memberpress')]);
        }

        $gateway = MeprCartPaymentService::get_active_gateway($order->gateway);
        if (!($gateway instanceof MeprArtificialGateway)) {
            wp_send_json_error(['message' => __('This order cannot be manually completed.', 'memberpress')]);
        }

        // Admin manual completion — send the receipt immediately; the funnel window has passed.
        $completed = MeprCartCheckoutService::complete_cart_order($order, '', false);

        if (!$completed) {
            $order = new MeprOrder($order_id);
            if (!$order->is_complete()) {
                wp_send_json_error(['message' => __('Order could not be completed. It may still be processing.', 'memberpress')]);
            }
        }

        // Fire offline-payment-complete events per transaction.
        foreach (MeprTransaction::get_all_by_order_id($order->id) as $txn_row) {
            MeprArtificialGateway::capture_txn_status_for_events(new MeprTransaction((array) $txn_row));
        }

        wp_send_json_success([
            'message'    => __('Order marked as complete.', 'memberpress'),
            'new_status' => MeprOrder::$complete_str,
        ]);
    }

    /**
     * AJAX: Resend the consolidated cart receipt email for an order.
     *
     * Cart orders use one order-level receipt (MeprUserCartReceiptEmail) rather
     * than per-transaction receipts, so resend is offered here at the order level.
     *
     * @return void
     */
    public function resend_cart_receipt()
    {
        check_ajax_referer('mepr_cart_order_actions', 'nonce');

        if (!MeprUtils::is_mepr_admin()) {
            wp_send_json_error(['message' => __('Permission denied.', 'memberpress')]);
        }

        $order_id = isset($_POST['order_id']) ? (int) $_POST['order_id'] : 0;
        if ($order_id <= 0) {
            wp_send_json_error(['message' => __('Invalid order ID.', 'memberpress')]);
        }

        $order = new MeprOrder((array) MeprOrder::get_one($order_id));

        if (!$order->id || $order->order_type !== MeprOrder::$cart_type_str) {
            wp_send_json_error(['message' => __('Order not found.', 'memberpress')]);
        }

        // Only completed orders have a receipt to resend.
        if ($order->status !== MeprOrder::$complete_str) {
            wp_send_json_error(['message' => __('A receipt can only be resent for completed orders.', 'memberpress')]);
        }

        MeprCartCheckoutService::send_cart_receipt_notices($order);

        wp_send_json_success(['message' => __('Receipt email resent.', 'memberpress')]);
    }
}
