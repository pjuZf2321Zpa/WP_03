<?php

namespace BitApps\IntegrationsPro\Actions\Registration;

class RegistrationHelperPro
{
    public static function deleteUser($defaultResponse, $fieldData)
    {
        $userEmail = $fieldData['user_email'] ?? null;
        $reassignId = $fieldData['reassign_id'] ?? null;

        $userId = self::getUserIdByEmail($userEmail);

        if (\is_array($userId)) {
            return $userId;
        }

        if (!\function_exists('wp_delete_user')) {
            require_once ABSPATH . 'wp-admin/includes/user.php';
        }

        $status = wp_delete_user($userId, $reassignId);

        if (!$status) {
            return self::error(__('Failed to delete user', 'bit-integrations-pro'));
        }

        return self::success(__('User deleted successfully', 'bit-integrations-pro'));
    }

    public static function updateUserMetadata($defaultResponse, $fieldData)
    {
        $metaKey = $fieldData['meta_key'] ?? null;
        $metaValue = $fieldData['meta_value'] ?? null;
        $userEmail = $fieldData['user_email'] ?? null;

        $userId = self::getUserIdByEmail($userEmail);
        if (\is_array($userId)) {
            return $userId;
        }

        if (empty($metaKey)) {
            return self::error(__('Meta Key is required', 'bit-integrations-pro'));
        }

        if (self::isRestrictedUserMetaKey($metaKey)) {
            return self::error(__('Updating this meta key is not allowed', 'bit-integrations-pro'));
        }

        if (empty($metaValue)) {
            return self::error(__('Meta Value is required', 'bit-integrations-pro'));
        }

        update_user_meta($userId, $metaKey, $metaValue);

        return self::success(get_user_meta($userId));
    }

    public static function createRole($defaultResponse, $fieldData)
    {
        $roleName = $fieldData['role_name'] ?? null;
        $displayName = $fieldData['role_display_name'] ?? null;
        $capabilities = self::convertStringToArray($fieldData['role_capabilities'] ?? '');

        if (empty($roleName)) {
            return self::error(__('Role Name is required', 'bit-integrations-pro'));
        }

        if (empty($displayName)) {
            return self::error(__('Role Display Name is required', 'bit-integrations-pro'));
        }

        if (get_role($roleName)) {
            return self::error(__('Role already exists.', 'bit-integrations-pro'));
        }

        $newRole = add_role($roleName, $displayName, self::convertCapabilitiesToAssoc($capabilities));

        if (!$newRole) {
            return self::error(__('Failed to create the role.', 'bit-integrations-pro'));
        }

        return self::success(['role_name' => $roleName, 'display_name' => $displayName]);
    }

    public static function deleteRole($defaultResponse, $fieldData)
    {
        $name = $fieldData['role_name'] ?? null;

        if (empty($name)) {
            return self::error(__('Role Name is required', 'bit-integrations-pro'));
        }

        if (!get_role($name)) {
            return self::error(__('Role not found.', 'bit-integrations-pro'));
        }

        remove_role($name);

        return self::success(__('Role deleted successfully.', 'bit-integrations-pro'));
    }

    public static function addUserRoles($defaultResponse, $fieldData)
    {
        return self::manageUserRole($fieldData, false, false);
    }

    public static function removeUserRole($defaultResponse, $fieldData)
    {
        return self::manageUserRole($fieldData, true, false);
    }

    public static function updateUserRole($defaultResponse, $fieldData)
    {
        return self::manageUserRole($fieldData, false, true);
    }

    public static function addRoleCapabilities($defaultResponse, $fieldData)
    {
        return self::manageRoleCapabilities($fieldData, false);
    }

    public static function removeRoleCapabilities($defaultResponse, $fieldData)
    {
        return self::manageRoleCapabilities($fieldData, true);
    }

    public static function addUserCapabilities($defaultResponse, $fieldData)
    {
        return self::manageUserCapabilities($fieldData, false);
    }

    public static function removeUserCapabilities($defaultResponse, $fieldData)
    {
        return self::manageUserCapabilities($fieldData, true);
    }

    private static function getUserIdByEmail($userEmail)
    {
        $user = self::getUserByEmail($userEmail);

        if (\is_array($user)) {
            return $user;
        }

        return $user->ID;
    }

    private static function getUserByEmail($userEmail)
    {
        if (empty($userEmail) || !is_email($userEmail)) {
            return self::error(__('Valid user email is required', 'bit-integrations-pro'));
        }

        $user = get_user_by('email', $userEmail);

        if (!$user) {
            return self::error(__('User not found with provided email', 'bit-integrations-pro'));
        }

        return $user;
    }

    private static function success($data)
    {
        return ['success' => true, 'message' => $data];
    }

    private static function error($message)
    {
        return ['success' => false, 'message' => $message];
    }

    private static function isRestrictedUserMetaKey($metaKey)
    {
        global $wpdb;

        $normalizedKey = strtolower(trim((string) $metaKey));
        $prefix = strtolower((string) $wpdb->prefix);

        $restrictedKeys = [
            'wp_capabilities',
            'wp_user_level',
            'capabilities',
            'user_level',
            'session_tokens',
            'application_passwords',
            'user_activation_key',
            'dismissed_wp_pointers',
            $prefix . 'capabilities',
            $prefix . 'user_level',
        ];

        return \in_array($normalizedKey, $restrictedKeys, true);
    }

    private static function convertStringToArray($value)
    {
        if (\is_array($value)) {
            return $value;
        }

        if (empty($value)) {
            return [];
        }

        return array_filter(array_map('trim', explode(',', $value)));
    }

    private static function convertCapabilitiesToAssoc(array $capabilities)
    {
        $result = [];

        foreach (array_unique($capabilities) as $capability) {
            if (!\is_string($capability) || trim($capability) === '') {
                continue;
            }

            $result[trim($capability)] = true;
        }

        return $result;
    }

    private static function manageUserRole(array $fieldData, $removeRole = false, $updateRole = false)
    {
        $userEmail = $fieldData['user_email'] ?? null;
        $userRole = self::convertStringToArray($fieldData['user_role'] ?? '');
        $newRoles = self::convertStringToArray($fieldData['new_role'] ?? '');
        $user = self::getUserByEmail($userEmail);

        if (\is_array($user)) {
            return $user;
        }

        if (!$updateRole && empty($userRole)) {
            return self::error(__('User role is required', 'bit-integrations-pro'));
        }
        if ($updateRole && empty($newRoles)) {
            return self::error(__('Role is required', 'bit-integrations-pro'));
        }

        if (!$user->exists()) {
            return self::error(__('User not found.', 'bit-integrations-pro'));
        }

        $currentRoles = array_fill_keys($user->roles, true);

        if ($updateRole) {
            $primaryRole = array_shift($newRoles);

            if (empty($primaryRole)) {
                return self::error(__('Role is required', 'bit-integrations-pro'));
            }

            $user->set_role($primaryRole);
            $currentRoles = array_fill_keys($user->roles, true);

            foreach (array_unique($newRoles) as $role) {
                if (!isset($currentRoles[$role])) {
                    $user->add_role($role);
                    $currentRoles[$role] = true;
                }
            }
        } else {
            foreach (array_unique($userRole) as $role) {
                if ($removeRole && isset($currentRoles[$role])) {
                    $user->remove_role($role);
                    unset($currentRoles[$role]);
                } elseif (!$removeRole && !isset($currentRoles[$role])) {
                    $user->add_role($role);
                    $currentRoles[$role] = true;
                }
            }
        }

        return self::success(['user_id' => $user->ID, 'roles' => $user->roles]);
    }

    private static function manageRoleCapabilities(array $fieldData, $removeCap = false)
    {
        $roleName = $fieldData['role_name'] ?? null;
        $capabilities = self::convertStringToArray($fieldData['role_capabilities'] ?? '');

        if (empty($roleName)) {
            return self::error(__('Role Name is required', 'bit-integrations-pro'));
        }

        if (empty($capabilities)) {
            return self::error(__('Role capabilities are required', 'bit-integrations-pro'));
        }

        $role = get_role($roleName);

        if (!$role) {
            return self::error(__('Role not found.', 'bit-integrations-pro'));
        }

        foreach (array_unique($capabilities) as $capability) {
            if ($removeCap && $role->has_cap($capability)) {
                $role->remove_cap($capability);
            } elseif (!$removeCap && !$role->has_cap($capability)) {
                $role->add_cap($capability);
            }
        }

        return self::success(['role' => $roleName]);
    }

    private static function manageUserCapabilities(array $fieldData, $removeCap = false)
    {
        $userEmail = $fieldData['user_email'] ?? null;
        $capabilities = self::convertStringToArray($fieldData['role_capabilities'] ?? '');
        $user = self::getUserByEmail($userEmail);

        if (\is_array($user)) {
            return $user;
        }

        if (empty($capabilities)) {
            return self::error(__('Role capabilities are required', 'bit-integrations-pro'));
        }

        if (!$user->exists()) {
            return self::error(__('User not found.', 'bit-integrations-pro'));
        }

        foreach (array_unique($capabilities) as $capability) {
            if ($removeCap && $user->has_cap($capability)) {
                $user->remove_cap($capability);
            } elseif (!$removeCap && !$user->has_cap($capability)) {
                $user->add_cap($capability);
            }
        }

        return self::success(['user_id' => $user->ID]);
    }
}
