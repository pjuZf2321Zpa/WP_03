<?php

defined('ABSPATH') || exit;

class MeprUserStripeAddressInvalidEmail extends MeprBaseOptionsUserEmail
{
    /**
     * Set the default enabled, title, subject & body.
     *
     * @param  array $args Email arguments.
     * @return void
     */
    public function set_defaults($args = [])
    {
        $this->title       = __('<b>Stripe Billing Address</b> Update Required', 'memberpress');
        $this->description = __('This email is sent to the user when Stripe could not finalize their latest invoice, asking them to review and update their billing address to keep the subscription active.', 'memberpress');
        $this->ui_order    = 11;

        $enabled = $use_template = $this->show_form = true;
        $subject = __('** Update your billing address to keep your subscription active', 'memberpress');
        $body    = $this->body_partial();

        $this->defaults  = compact('enabled', 'subject', 'body', 'use_template');
        $this->variables = MeprSubscriptionsHelper::get_email_vars();
    }
}
