<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Actions\ZohoBigin\ZohoBiginHelperPro;
use BitApps\IntegrationsPro\Config;
use BitApps\IntegrationsPro\Core\Util\Hooks;

// Deprecated since v2.7.8 - use bit_integrations_zbigin_* hooks instead
if (bit_integrations_version_below('2.7.8')) {
    Hooks::filter('btcbi_zbigin_get_tags', [ZohoBiginHelperPro::class, 'getTagList'], 10, 5);
    Hooks::filter('btcbi_zbigin_add_tags_to_records', [ZohoBiginHelperPro::class, 'addTagsToRecords'], 10, 5);
}

// New hooks since v2.7.8
Hooks::filter(Config::withFreePrefix('zbigin_get_tags'), [ZohoBiginHelperPro::class, 'getTagList'], 10, 5);
Hooks::filter(Config::withFreePrefix('zbigin_add_tags_to_records'), [ZohoBiginHelperPro::class, 'addTagsToRecords'], 10, 5);
