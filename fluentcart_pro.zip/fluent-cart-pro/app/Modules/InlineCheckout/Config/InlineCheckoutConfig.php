<?php

namespace FluentCartPro\App\Modules\InlineCheckout\Config;

use FluentCart\App\Models\ProductVariation;
use FluentCart\App\Services\Renderer\CheckoutRenderer;
use FluentCart\App\Services\Renderer\RenderGate;
use FluentCart\Framework\Support\Arr;

/**
 * The single interpreter of inline-checkout attributes.
 *
 * Four surfaces can ask for an inline checkout — the Gutenberg block, the
 * shortcode, the Elementor widget and the Divi module — and each hands over a
 * differently shaped bag of raw values: the block passes parsed block attrs
 * (real arrays and booleans), the shortcode passes strings only, the page
 * builders pass their own control values. normalize() is where that variety
 * ends. Everything downstream — the renderer, the cart service, the AJAX
 * fragment handler — consumes the validated array this class returns and never
 * touches a raw attribute again.
 *
 * Keeping interpretation in one place is what makes "the markup is identical
 * across all four adapters" a property of the code rather than a promise.
 *
 * @package FluentCartPro\App\Modules\InlineCheckout\Config
 */
class InlineCheckoutConfig
{
    /**
     * Where the variations come from.
     *
     * ICO-01 resolves `manual` only; the other two are accepted and preserved
     * here so a saved block written by a later ticket never loses its author's
     * intent, but resolveVariations() falls back to the manually chosen ids for
     * all of them until ICO-03 / ICO-04 teach it otherwise.
     */
    const SOURCES = ['manual', 'current_product', 'url'];

    /**
     * Radio behaviour (`single`) or checkbox behaviour (`multiple`).
     */
    const SELECTION_MODES = ['single', 'multiple'];

    /**
     * What the checkout is driven by.
     *
     * `cart` is the historical behaviour: render whatever is in the shopper's
     * main cart. `custom` renders the configured variations as a selectable
     * list instead.
     *
     * This is an explicit switch so an author can park a product selection
     * without it taking effect: turning the mode back to `cart` must not
     * silently discard the variations they chose. Surfaces that never send a
     * mode (the shortcode, older saved blocks) are handled by inferring it from
     * `variant_ids` — see core's CheckoutRenderer::isCustomProductCheckout().
     */
    const CHECKOUT_MODES = ['cart', 'custom'];

    /**
     * Hard ceiling on how many variations one inline checkout may OFFER.
     *
     * Not a taste judgement: every offered variation costs a cart line, and
     * the resolver eager-loads four relations per variation. An unbounded
     * variation list from a page builder would turn one page render into an
     * arbitrarily large query.
     *
     * This is the only bound on the offer list. `max_items` is a different
     * concept — see DEFAULT_MAX_ITEMS — and must never shorten it: a checkout
     * configured as "pick 2 of these 3" has to render all three options, or
     * the third product is one the shopper can never choose.
     */
    const MAX_ITEMS_LIMIT = 20;

    /**
     * Default for `max_items`, the shopper's SELECTION cap: how many of the
     * offered options may be ticked at once in `multiple` mode.
     *
     * Enforced when a selection is written, in
     * InlineCartService::setSelection() — never while deciding what to render.
     */
    const DEFAULT_MAX_ITEMS = 5;

    const DEFAULT_URL_PARAM_KEY = 'fct_items';

    /**
     * Normalize raw attributes from any surface into one validated config.
     *
     * @param array  $rawAttrs Untrusted values straight off the surface.
     * @param string $surface  block | shortcode | elementor | divi
     * @return array
     */
    public static function normalize(array $rawAttrs, $surface = 'block'): array
    {
        $source = sanitize_text_field((string)Arr::get($rawAttrs, 'source', 'manual'));
        if (!in_array($source, self::SOURCES, true)) {
            $source = 'manual';
        }

        $selectionMode = sanitize_text_field((string)Arr::get($rawAttrs, 'selection_mode', 'single'));
        if (!in_array($selectionMode, self::SELECTION_MODES, true)) {
            $selectionMode = 'single';
        }

        $urlParamKey = sanitize_key((string)Arr::get($rawAttrs, 'url_param_key', ''));
        if (!$urlParamKey) {
            $urlParamKey = self::DEFAULT_URL_PARAM_KEY;
        }

        $buttonText = sanitize_text_field((string)Arr::get($rawAttrs, 'button_text', ''));
        // Heading above the selectable list. Dropped silently before this, so
        // the block/shortcode setting had no effect anywhere downstream.
        $selectorLabel = sanitize_text_field((string)Arr::get($rawAttrs, 'selector_label', ''));
        if ($buttonText === '') {
            $buttonText = __('Buy Now', 'fluent-cart');
        }

        $emptyText = sanitize_text_field((string)Arr::get($rawAttrs, 'empty_text', ''));
        if ($emptyText === '') {
            // Core's wording for an unavailable product, as on the normal checkout.
            $emptyText = __('This product is not available for purchase.', 'fluent-cart');
        }

        $surface = sanitize_key((string)$surface);
        if (!$surface) {
            $surface = 'block';
        }

        // Every id the author configured is offered, bounded only by the
        // performance ceiling. `max_items` deliberately does not slice here:
        // it is the shopper's selection cap, and letting it shorten the offer
        // list is what made a "pick 2 of these 3" checkout render two options
        // and leave the third unreachable.
        $variantIds = array_slice(self::readVariantIds($rawAttrs), 0, self::MAX_ITEMS_LIMIT);
        // Core decides the mode so it can route the checkout even without Pro.
        $checkoutMode = CheckoutRenderer::isCustomProductCheckout($rawAttrs) ? 'custom' : 'cart';

        // Cart mode is authoritative over a stale selection. An author who
        // switches back to "Default Cart" keeps their chosen products in the
        // block attributes, but nothing downstream may act on them, so the
        // whole selector path stays unreachable behind one empty array.
        if ($checkoutMode === 'cart') {
            $variantIds = [];
        }

        $config = [
            'source'           => $source,
            'checkout_mode'    => $checkoutMode,
            'variant_ids'      => $variantIds,
            'selection_mode'   => $selectionMode,
            'allow_url_params' => self::toBool(Arr::get($rawAttrs, 'allow_url_params', false)),
            'url_param_key'    => $urlParamKey,
            'max_items'        => self::clampSelectionCap(Arr::get($rawAttrs, 'max_items', self::DEFAULT_MAX_ITEMS)),
            'button_text'      => $buttonText,
            'selector_label'   => $selectorLabel,
            'empty_text'       => $emptyText,
            'surface'          => $surface,
            // The page this selector is rendering on. It is the cart's identity
            // now: one cart per page, so two landing pages selling different
            // products no longer share a row and add up into one basket.
            //
            // Context, not an author setting — but it lives here because this
            // class is the single interpreter every surface goes through, and
            // an AJAX request (where no post is in scope) can pass it in the
            // same way the block passes its attributes.
            'page_id'          => self::resolvePageId($rawAttrs),
        ];

        // Context carries the raw attributes and the surface so a listener can
        // read a builder-specific control this class does not know about. The
        // filtered value must keep the shape above — a listener that returns
        // something else is ignored rather than allowed to break the renderer.
        $filtered = apply_filters('fluent_cart/inline_checkout/config', $config, [
            'raw_attrs' => $rawAttrs,
            'surface'   => $surface,
        ]);

        if (!is_array($filtered)) {
            return $config;
        }

        return $filtered;
    }

    /**
     * Resolve the config's variations into purchasable ProductVariation models.
     *
     * ICO-01 scope: `variant_ids` only. `current_product` and `url` sources are
     * accepted by normalize() but resolve through the same manual ids here.
     *
     * @param array $config Output of normalize().
     * @return ProductVariation[]
     */
    public static function resolveVariations(array $config): array
    {
        $variantIds = Arr::get($config, 'variant_ids', []);
        if (!is_array($variantIds)) {
            $variantIds = [];
        }

        // The performance ceiling is re-applied rather than assumed: this
        // method is public and also runs on configs a filter listener rebuilt
        // or a page builder assembled, which never passed through normalize().
        // It is the ONLY bound here — `max_items` caps what the shopper may
        // select, not what they are shown.
        $variantIds = array_slice(
            array_values(array_filter(array_map('absint', $variantIds))),
            0,
            self::MAX_ITEMS_LIMIT
        );

        $variations = [];

        if ($variantIds) {
            // product and product_detail are not optional: canPurchase() reads
            // the post status off product and the stock settings off
            // product_detail, and CartHelper::generateCartItemFromVariation()
            // reads variation_type off product_detail. Without them every
            // variation costs three lazy queries.
            $rows = ProductVariation::query()
                ->with(['product', 'product_detail', 'media', 'shippingClass'])
                ->whereIn('id', $variantIds)
                ->get();

            $byId = [];
            foreach ($rows as $row) {
                $byId[(int)$row->id] = $row;
            }

            // Iterate the configured ids, not the query result, so the offered
            // order is the order the store owner arranged in the inspector.
            foreach ($variantIds as $variantId) {
                if (!isset($byId[$variantId])) {
                    continue;
                }

                $variation = $byId[$variantId];

                if (!self::isOfferable($variation)) {
                    continue;
                }

                $variations[] = $variation;
            }
        }

        $filtered = apply_filters('fluent_cart/inline_checkout/resolved_variations', $variations, $config);

        if (!is_array($filtered)) {
            return $variations;
        }

        return $filtered;
    }

    /**
     * May this variation be offered for purchase on a content page?
     *
     * Two independent questions, both of which must be yes:
     *
     * 1. Is it purchasable at all — published, active, in stock? canPurchase()
     *    is the store's single answer to that, so an unpublished or sold-out
     *    variation can never reach the inline checkout through a stale block
     *    attribute or a crafted URL parameter.
     * 2. Is a purchase affordance allowed to render here? Catalog-mode
     *    integrations hide every buy button through RenderGate; an inline
     *    checkout is the largest buy button on the page, so it has to obey the
     *    same gate rather than becoming the hole in it.
     *
     * @param ProductVariation $variation
     * @return bool
     */
    protected static function isOfferable(ProductVariation $variation): bool
    {
        $product = $variation->product;

        if (!$product) {
            return false;
        }

        if (is_wp_error($variation->canPurchase(1))) {
            return false;
        }

        return RenderGate::shouldRenderPurchaseButton(
            'buy_now_button',
            RenderGate::context($product, RenderGate::SCOPE_SINGLE, $variation)
        );
    }

    /**
     * Read the selected variation ids from whichever key the surface used.
     *
     * The block stores `variant_ids` as an array; the shortcode documents
     * `variation_id` and accepts a comma-separated list. Both arrive here.
     *
     * @param array $rawAttrs
     * @return int[]
     */
    protected static function readVariantIds(array $rawAttrs): array
    {
        foreach (['variant_ids', 'variation_ids', 'variation_id'] as $key) {
            $value = Arr::get($rawAttrs, $key);

            if ($value === null || $value === '' || $value === []) {
                continue;
            }

            $ids = self::toIdList($value);

            if ($ids) {
                return $ids;
            }
        }

        return [];
    }

    /**
     * Coerce an id-ish value into a list of positive, unique ints.
     *
     * Accepts an array of ints, a comma- or space-separated string, a single
     * scalar, or an array of objects/arrays carrying an `id` — block inspectors
     * commonly store the last shape alongside display data.
     *
     * @param mixed $value
     * @return int[]
     */
    protected static function toIdList($value): array
    {
        if (is_string($value)) {
            $value = preg_split('/[\s,]+/', $value, -1, PREG_SPLIT_NO_EMPTY);
        }

        if (!is_array($value)) {
            $value = [$value];
        }

        $ids = [];

        foreach ($value as $item) {
            if (is_object($item)) {
                $item = (array)$item;
            }

            if (is_array($item)) {
                $item = Arr::get($item, 'id', Arr::get($item, 'variation_id', 0));
            }

            $id = absint($item);

            if ($id && !in_array($id, $ids, true)) {
                $ids[] = $id;
            }
        }

        return $ids;
    }

    /**
     * The post this render belongs to.
     *
     * An explicit `page_id` wins so an AJAX request — where the loop has no
     * post and get_the_ID() returns false — can name the page it is acting for.
     * Falls back to the current post for an ordinary render.
     *
     * @param array $rawAttrs
     * @return int
     */
    protected static function resolvePageId(array $rawAttrs): int
    {
        $pageId = absint(Arr::get($rawAttrs, 'page_id', 0));

        if ($pageId) {
            return $pageId;
        }

        $currentId = get_the_ID();

        if ($currentId) {
            return absint($currentId);
        }

        // Outside the loop get_the_ID() is false, which is the normal case for a
        // selector in a widget area, an FSE template part or a theme file that
        // calls do_shortcode(). The queried object is still the page being
        // viewed, so it identifies the cart just as well.
        //
        // Gated on is_singular() deliberately: on an archive the queried object
        // is a term or author, whose ids share no namespace with post ids — a
        // category 12 and a page 12 would otherwise collide on one cart, which
        // is the exact bug per-page identity exists to prevent.
        if (is_singular()) {
            return absint(get_queried_object_id());
        }

        // Genuinely no page to key on — a selector on an archive or 404. Falls
        // back to the device-wide cart, i.e. the pre-per-page behaviour.
        return 0;
    }

    /**
     * Clamp `max_items` — how many offered options a shopper may tick at once.
     *
     * Capped at MAX_ITEMS_LIMIT only because a selection can never usefully be
     * larger than the longest offer list this class will ever render; the two
     * numbers are otherwise unrelated.
     *
     * @param mixed $value
     * @return int
     */
    protected static function clampSelectionCap($value): int
    {
        $maxItems = absint($value);

        if (!$maxItems) {
            $maxItems = self::DEFAULT_MAX_ITEMS;
        }

        return min($maxItems, self::MAX_ITEMS_LIMIT);
    }

    /**
     * Surfaces disagree on how to spell "true": the block sends a real boolean,
     * the shortcode sends "yes", Elementor sends "on", Divi sends "1".
     *
     * @param mixed $value
     * @return bool
     */
    protected static function toBool($value): bool
    {
        if (is_bool($value)) {
            return $value;
        }

        if (is_numeric($value)) {
            return (int)$value > 0;
        }

        if (is_string($value)) {
            return in_array(strtolower(trim($value)), ['1', 'true', 'yes', 'on'], true);
        }

        return false;
    }
}
