<?php

declare(strict_types=1);

namespace FluentCartPro\App\Services\Invoice\Domain;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Document-level charge DTO (e.g., shipping).
 */
final class DocumentCharge
{
    public Money $amount;

    public string $taxCategory;

    public string $taxPercent;

    public string $reason;

    /** BT-121: coded VAT exemption reason. Empty when not applicable. */
    public string $exemptionReasonCode;

    /** BT-120: free-text VAT exemption reason. Empty when not applicable. */
    public string $exemptionReasonText;

    public function __construct(
        Money $amount,
        string $taxCategory,
        string $taxPercent,
        string $reason = '',
        string $exemptionReasonCode = '',
        string $exemptionReasonText = ''
    ) {
        $this->amount              = $amount;
        $this->taxCategory         = $taxCategory;
        $this->taxPercent          = $taxPercent;
        $this->reason              = $reason;
        $this->exemptionReasonCode = $exemptionReasonCode;
        $this->exemptionReasonText = $exemptionReasonText;
    }
}
