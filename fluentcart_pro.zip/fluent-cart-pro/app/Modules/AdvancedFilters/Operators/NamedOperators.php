<?php

namespace FluentCartPro\App\Modules\AdvancedFilters\Operators;

/**
 * Named operators core's filter options advertise but the engine cannot resolve.
 *
 * OrderFilter offers "Equals"/"Not Equals" on Order Hash (UUID) and "Equals" on
 * Payer email. Nothing in BaseFilter maps those names to an SQL operator, and
 * Query\Builder::invalidOperator() does not reject one it fails to recognise — it
 * rewrites it to `=` and compares the column against the operator STRING. So
 * `uuid equals ABC123` became `uuid = 'equals'`: the user's value is discarded and
 * the filter silently matches nothing instead of erroring.
 *
 * Core publishes its vocabulary through fluent_cart/filter/supported_operators
 * precisely so the names can be resolved from outside the engine.
 */
class NamedOperators
{
    /**
     * Requested operator => operator the engine applies.
     *
     * @return array<string, string>
     */
    public static function map(): array
    {
        return [
            'equals'     => '=',
            'not_equals' => '!=',
        ];
    }

    /**
     * Filter callback for 'fluent_cart/filter/supported_operators'.
     *
     * Merged on top of whatever core (and any earlier listener) published, so this
     * adds names rather than replacing the vocabulary.
     *
     * The mapping is applied to every filter rather than scoped to the one named
     * in $context: `equals`/`not_equals` are generic aliases for `=`/`!=`, not
     * order-specific, so scoping them to the orders filter would silently break a
     * filter that starts offering the same names later. The context is taken so
     * the contract is honoured and narrowing stays a one-line change.
     *
     * @param mixed $operators
     * @param array $context Read-only context; carries 'filter_name'.
     * @return mixed
     */
    public static function extend($operators, $context = [])
    {
        if (!is_array($operators)) {
            return $operators;
        }

        return array_merge($operators, static::map());
    }
}
