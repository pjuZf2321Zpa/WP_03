<?php

namespace MasterStudy\Lms\Pro\AddonsPlus\GoogleMeet\Routing\Swagger;

use MasterStudy\Lms\Routing\Swagger\RequestInterface;
use MasterStudy\Lms\Routing\Swagger\ResponseInterface;
use MasterStudy\Lms\Routing\Swagger\Route;

class BulkDeleteGoogleMeets extends Route implements RequestInterface, ResponseInterface {
	public function request(): array {
		return array(
			'google_meets' => array(
				'type'        => 'array',
				'description' => 'Meeting items selected for bulk deletion.',
				'required'    => true,
				'items'       => array(
					'type'       => 'object',
					'properties' => array(
						'id' => array(
							'type' => 'integer',
						),
					),
				),
			),
		);
	}

	public function response(): array {
		return array(
			'success' => array(
				'type' => 'boolean',
			),
		);
	}

	public function get_summary(): string {
		return 'Bulk Delete Google Meets';
	}

	public function get_description(): string {
		return 'Permanently deletes meetings from the admin meetings list.';
	}
}
