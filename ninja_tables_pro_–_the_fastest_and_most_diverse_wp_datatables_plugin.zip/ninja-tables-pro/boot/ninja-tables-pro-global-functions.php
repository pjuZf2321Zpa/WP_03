<?php
defined('ABSPATH') || exit;

function nt_parse_image_column($data, $column)
{
    if ( ! $data) {
        return '';
    }
    if ( ! empty($column['original'])) {
        $column = $column['original'];
    }

    $linkType = \NinjaTables\Framework\Support\Arr::get($column, 'link_type');
    if (empty($data['image_thumb'])) {
        return '';
    }
    $suffix = '';
    $prefix = '';
    if ($linkType == 'hyperlinked') {
        if ( ! empty($data['permalink'])) {
            $atts = '';
            if (isset($column['link_target'])) {
                $atts = 'target="' . esc_attr($column['link_target']) . '"';
            }
            $prefix = '<a ' . $atts . ' href="' . esc_url($data['permalink']) . '">';
            $suffix = '</a>';
        }
    } elseif ($linkType == 'image_light_box') {
        if ($data['image_full']) {
            $prefix = '<a class="nt_lightbox" href="' . esc_url($data['image_full']) . '">';
            $suffix = '</a>';
        }

    } elseif ($linkType == 'iframe_ligtbox') {
        if ( ! empty($data['permalink'])) {
            $prefix = '<a class="nt_lightbox" href="' . esc_url($data['permalink']) . '">';
            $suffix = '</a>';
        }

    } else {

    }

    $altText = \NinjaTables\Framework\Support\Arr::get($data, 'alt_text');

    return $prefix . '<img alt="' . esc_attr($altText) . '" class="nt_image_type_thumb" src="' . esc_url($data['image_thumb']) . '"/>' . $suffix;
}

function nt_parse_button_column($url, $column)
{
    if ( ! empty($column['original'])) {
        $column = $column['original'];
    }
    if ( ! $url) {
        return '';
    }
    $atts = '';
    if (isset($column['link_target'])) {
        $atts = 'target="' . esc_attr($column['link_target']) . '"';
    }

    $extraClass = '';
    if (isset($column['btn_extra_class']) && $column['btn_extra_class']) {
        $extraClass = sanitize_html_class($column['btn_extra_class']);
    }

    $styles = '';
    if (isset($column['btn_text_color']) && $column['btn_text_color']) {
        $styles .= 'color: ' . esc_attr($column['btn_text_color']) . ';';
    }

    if (isset($column['btn_bg_color']) && $column['btn_bg_color']) {
        $styles .= 'background-color: ' . esc_attr($column['btn_bg_color']) . ';';
    }

    if (isset($column['btn_border_color']) && $column['btn_border_color']) {
        $styles .= 'border-color: ' . esc_attr($column['btn_border_color']) . ';';
    }

    $btnText = '';
    if (isset($column['button_text'])) {
        $btnText = $column['button_text'];
    }
    $relAttributes = '';
    if (isset($column['relAttributes'])) {
        $relAttributes = implode(" ", array_map('esc_attr', $column['relAttributes']));
    }
    $forceDownload = '';
    if (isset($column['force_download']) && $column['force_download']) {
        $forceDownload = 'download';
        $siteUrl       = site_url();
        if (strpos($url, $siteUrl) === false) {
            $extraClass .= ' nt_force_download';
        }
    }


    // Helper::sanitizeLinkValue() only exists in free 5.2.14+; esc_url() is the
    // pre-5.2.14 behaviour, wrong for scheme-less slugs but never fatal.
    $safeUrl = method_exists('\NinjaTables\App\Helper\Helper', 'sanitizeLinkValue')
        ? \NinjaTables\App\Helper\Helper::sanitizeLinkValue($url)
        : esc_url($url);
    return '<a ' . $atts . ' ' . $forceDownload . ' class="nt_btn ' . esc_attr($extraClass) . '" style="' . esc_attr($styles) . '" rel="' . esc_attr($relAttributes) . '" href="' . $safeUrl . '">' . $btnText . '</a>';
}
