<?php

namespace MasterStudy\Lms\Pro\addons\assignments\Http\Controllers\Admin;

use MasterStudy\Lms\Http\WpResponseFactory;
use MasterStudy\Lms\Plugin\PostType;
use MasterStudy\Lms\Validation\Validator;
use WP_REST_Request;
use WP_REST_Response;

final class ReviewStudentAssignmentController {
	public function __invoke( int $student_assignment_id, WP_REST_Request $request ): WP_REST_Response {
		if ( $student_assignment_id <= 0 || PostType::USER_ASSIGNMENT !== get_post_type( $student_assignment_id ) ) {
			return WpResponseFactory::not_found();
		}

		$validator = new Validator(
			$request->get_params(),
			array(
				'review'     => 'nullable|string',
				'status'     => 'nullable|string|contains_list,passed;not_passed',
				'grade_type' => 'nullable|string|contains_list,grade;point;percent',
				'grade'      => 'nullable|string',
				'point'      => 'nullable|string',
				'percent'    => 'nullable|integer',
			)
		);

		if ( $validator->fails() ) {
			return WpResponseFactory::validation_failed( $validator->get_errors_array() );
		}

		$data   = $validator->get_validated();
		$result = masterstudy_lms_process_student_assignment_review(
			$student_assignment_id,
			array(
				'review'     => $data['review'] ?? '',
				'status'     => $data['status'] ?? '',
				'grade-type' => $data['grade_type'] ?? '',
				'grade'      => $data['grade'] ?? '',
				'point'      => $data['point'] ?? '',
				'percent'    => $data['percent'] ?? '',
			)
		);

		return WpResponseFactory::ok_with_data(
			array(
				'success' => true,
				'status'  => $result['status'] ?? '',
				'grade'   => $result['grade'] ?? null,
			)
		);
	}
}
