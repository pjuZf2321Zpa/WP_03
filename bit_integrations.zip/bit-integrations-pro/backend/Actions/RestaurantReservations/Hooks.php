<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Actions\RestaurantReservations\RestaurantReservationsProHelper;
use BitApps\IntegrationsPro\Config;
use BitApps\IntegrationsPro\Core\Util\Hooks;

Hooks::filter(Config::withFreePrefix('restaurant_reservations_create_booking'), [RestaurantReservationsProHelper::class, 'createBooking'], 10, 4);
Hooks::filter(Config::withFreePrefix('restaurant_reservations_update_booking'), [RestaurantReservationsProHelper::class, 'updateBooking'], 10, 4);
Hooks::filter(Config::withFreePrefix('restaurant_reservations_change_booking_status'), [RestaurantReservationsProHelper::class, 'changeBookingStatus'], 10, 4);
Hooks::filter(Config::withFreePrefix('restaurant_reservations_assign_tables'), [RestaurantReservationsProHelper::class, 'assignTables'], 10, 3);
Hooks::filter(Config::withFreePrefix('restaurant_reservations_trash_booking'), [RestaurantReservationsProHelper::class, 'trashBooking'], 10, 2);
Hooks::filter(Config::withFreePrefix('restaurant_reservations_restore_booking'), [RestaurantReservationsProHelper::class, 'restoreBooking'], 10, 2);
Hooks::filter(Config::withFreePrefix('restaurant_reservations_delete_booking'), [RestaurantReservationsProHelper::class, 'deleteBooking'], 10, 2);
Hooks::filter(Config::withFreePrefix('restaurant_reservations_delete_bookings_by_email'), [RestaurantReservationsProHelper::class, 'deleteBookingsByEmail'], 10, 3);
Hooks::filter(Config::withFreePrefix('restaurant_reservations_send_email_to_customer'), [RestaurantReservationsProHelper::class, 'sendEmailToCustomer'], 10, 2);
Hooks::filter(Config::withFreePrefix('restaurant_reservations_ban_email'), [RestaurantReservationsProHelper::class, 'banEmail'], 10, 2);
Hooks::filter(Config::withFreePrefix('restaurant_reservations_ban_ip_address'), [RestaurantReservationsProHelper::class, 'banIpAddress'], 10, 2);
