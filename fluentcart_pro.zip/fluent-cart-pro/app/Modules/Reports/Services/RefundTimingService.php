<?php

namespace FluentCartPro\App\Modules\Reports\Services;

use FluentCart\App\App;
use FluentCart\App\Modules\MultiCurrency\Services\ReportCurrency;
use FluentCart\App\Services\Report\RefundReportService;

/**
 * The Pro chart of Reports → Refunds: weeks between the order and its first refund.
 */
class RefundTimingService extends RefundReportService
{
    /**
     * Orders by the weeks from order to first refund, for first refunds made in the period on orders of any date:
     * the Days to Refund card's set, so the two agree.
     */
    public function weeksBetweenRefund($params = []): array
    {
        $firstRefunds = App::db()->table('fct_order_transactions')
            ->selectRaw('order_id, MIN(created_at) AS first_at')
            ->where('transaction_type', \FluentCart\App\Helpers\Status::TRANSACTION_TYPE_REFUND)
            ->where('status', \FluentCart\App\Helpers\Status::TRANSACTION_REFUNDED)
            ->groupBy('order_id');

        return $this->applyFilters(ReportCurrency::ordersTable($params)->joinSub($firstRefunds, 'r', 'r.order_id', '=', 'o.id'), $this->anyOrderDate($params))
            ->whereBetween('r.first_at', [$params['startDate'], $params['endDate']])
            ->selectRaw('
                COUNT(*) AS occurrence,
                IFNULL(((GREATEST(TIMESTAMPDIFF(DAY, o.created_at, r.first_at), 1) + 6) DIV 7), 1) AS weekBetween
            ')
            ->groupBy('weekBetween')
            ->orderBy('weekBetween')
            ->get()
            ->toArray();
    }
}
