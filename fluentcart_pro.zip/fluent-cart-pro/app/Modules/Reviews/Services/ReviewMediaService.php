<?php

namespace FluentCartPro\App\Modules\Reviews\Services;

use FluentCart\Api\Resource\ProductReviewResource;
use FluentCart\App\Models\ProductReview;
use FluentCart\App\Services\ProductReviewService;
use FluentCart\Framework\Support\Arr;

class ReviewMediaService
{
    /**
     * Supported image type keys mapped to their upload mime entries (for wp_handle_upload)
     * and flat mime strings (for validation).
     */
    public const ALLOWED_TYPE_MAP = [
        'jpeg' => ['ext' => 'jpg|jpeg', 'mime' => 'image/jpeg'],
        'png'  => ['ext' => 'png',      'mime' => 'image/png'],
        'gif'  => ['ext' => 'gif',      'mime' => 'image/gif'],
        'webp' => ['ext' => 'webp',     'mime' => 'image/webp'],
    ];

    /**
     * Resolve type keys (e.g. ['jpeg','png']) to flat mime strings for validation.
     *
     * @param array|null $types
     * @return string[] e.g. ['image/jpeg','image/png']
     */
    /**
     * Effective photo-review limits. Each store setting passes through a
     * filter so third-party code can adjust it. Numeric results are clamped
     * to sane minimums, and type lists are validated against the supported
     * ALLOWED_TYPE_MAP by the resolve helpers, so a filter cannot disable
     * the cap or smuggle in unsupported mime types.
     */
    /**
     * Files already run through storeFilesForReview() in this request.
     *
     * @var \SplObjectStorage|null
     */
    protected static $consumedFiles = null;

    public static function getMaxPhotosPerReview(): int
    {
        $settings = ProductReviewService::getReviewSettings();
        $max = (int) apply_filters(
            'fluent_cart/review/max_photos_per_review',
            (int) Arr::get($settings, 'max_photos_per_review', 5),
            []
        );

        return max(1, $max);
    }

    /**
     * The per-photo size limit as the store sets it, in megabytes. A
     * fraction is fine: 0.5 is 500 KB. The fluent_cart/review/max_photo_size
     * filter sees and returns megabytes too. Floors at a thousandth of a
     * megabyte (about a kilobyte) so a filter cannot switch photos off by
     * the back door.
     */
    public static function getMaxPhotoSizeMb(): float
    {
        $settings = ProductReviewService::getReviewSettings();
        $sizeMb = (float) apply_filters(
            'fluent_cart/review/max_photo_size',
            (float) Arr::get($settings, 'max_photo_size_mb', 1),
            []
        );

        return max(0.001, $sizeMb);
    }

    /** The same limit in bytes, which is what a file is compared against. */
    public static function getMaxPhotoSizeBytes(): int
    {
        return (int) round(static::getMaxPhotoSizeMb() * 1024 * 1024);
    }

    /**
     * Pixels a photo may decode to, summed over its frames. The byte limit
     * does not bound this: a 1 MB PNG can declare a 30000 x 30000 canvas.
     */
    public static function getMaxPhotoPixels(): int
    {
        $pixels = (int) apply_filters('fluent_cart/review/max_photo_pixels', 25000000, []);

        return max(1, $pixels);
    }

    /**
     * @return array|null Type keys (jpeg/png/gif/webp...), or null for the
     *                    full supported set — the shape the resolvers expect.
     */
    public static function getAllowedPhotoTypes()
    {
        $settings = ProductReviewService::getReviewSettings();
        $types = apply_filters(
            'fluent_cart/review/allowed_photo_types',
            Arr::get($settings, 'allowed_photo_types'),
            []
        );

        return is_array($types) && !empty($types) ? $types : null;
    }

    public static function resolveAllowedMimeTypes($types = null)
    {
        $types = is_array($types) && !empty($types) ? $types : array_keys(self::ALLOWED_TYPE_MAP);
        $mimes = [];
        foreach ($types as $type) {
            if (isset(self::ALLOWED_TYPE_MAP[$type])) {
                $mimes[] = self::ALLOWED_TYPE_MAP[$type]['mime'];
            }
        }
        return !empty($mimes) ? $mimes : array_column(self::ALLOWED_TYPE_MAP, 'mime');
    }

    /**
     * Resolve type keys to wp_handle_upload mimes array (['ext_pattern' => 'mime/type']).
     *
     * @param array|null $types
     * @return array
     */
    public static function resolveUploadMimes($types = null)
    {
        $types = is_array($types) && !empty($types) ? $types : array_keys(self::ALLOWED_TYPE_MAP);
        $mimes = [];
        foreach ($types as $type) {
            if (isset(self::ALLOWED_TYPE_MAP[$type])) {
                $entry = self::ALLOWED_TYPE_MAP[$type];
                $mimes[$entry['ext']] = $entry['mime'];
            }
        }
        return !empty($mimes) ? $mimes : array_combine(
            array_column(self::ALLOWED_TYPE_MAP, 'ext'),
            array_column(self::ALLOWED_TYPE_MAP, 'mime')
        );
    }
    /**
     * Upload a file and tag it as pending review media.
     *
     * @param array      $file          Raw $_FILES-style array
     * @param int        $postId        Product post ID
     * @param array|null $allowedTypes  Allowed type keys (e.g. ['jpeg','png']). Null = all image types.
     * @param string     $bucketKey     Quota bucket key from buildBucketKey()
     * @return array|null ['id' => attachmentId, 'url', 'type', 'name', 'claim_token'] or null on failure
     */
    /**
     * Validate one uploaded file and store it as pending review media.
     *
     * The single place the per-file rules live — content-sniffed MIME against
     * the allow list, then size — so the storefront uploader and the admin
     * add-review form cannot drift apart. Quota policy stays with the caller:
     * a shopper is bounded by their pending-upload bucket, a moderator is not.
     *
     * @param  object $fileObj  WPFluent File object
     * @return array|null       stored media, or null when the file is rejected
     */
    public static function storeUploadedFile($fileObj, $postId, $bucketKey = '', $allowedTypes = null, $maxBytes = null)
    {
        static::$lastRejection = 'upload';

        if ($fileObj->getError() !== UPLOAD_ERR_OK) {
            return null;
        }

        $tmpName = $fileObj['tmp_name'];

        if (!function_exists('finfo_open') || !$tmpName || !file_exists($tmpName)) {
            return null;
        }

        $allowedTypes = $allowedTypes !== null ? $allowedTypes : static::getAllowedPhotoTypes();
        $maxBytes = $maxBytes !== null ? $maxBytes : static::getMaxPhotoSizeBytes();

        // Detected from the file's own content, never the client-supplied type.
        $finfo = finfo_open(FILEINFO_MIME_TYPE);
        $detected = finfo_file($finfo, $tmpName);
        finfo_close($finfo);

        if (!in_array($detected, static::resolveAllowedMimeTypes($allowedTypes), true)) {
            static::$lastRejection = 'type';
            return null;
        }

        if ($fileObj['size_in_bytes'] > $maxBytes) {
            static::$lastRejection = 'size';
            return null;
        }

        if (!static::isWithinPixelBudget($tmpName, $detected)) {
            static::$lastRejection = 'dimensions';
            return null;
        }

        return static::uploadFile([
            'name'     => $fileObj['name'],
            // The detected type, not $fileObj['type'] — wp_handle_upload must
            // not be handed a MIME the client asserted.
            'type'     => $detected,
            'tmp_name' => $tmpName,
            'error'    => $fileObj['error'],
            'size'     => $fileObj['size_in_bytes'],
        ], $postId, $allowedTypes, $bucketKey);
    }

    /**
     * Measured from headers and frame markers only, before WordPress decodes
     * the file. A file whose size cannot be read is refused.
     */
    protected static function isWithinPixelBudget($path, $mime)
    {
        $size = @getimagesize($path);
        if (!$size || empty($size[0]) || empty($size[1])) {
            return false;
        }

        $canvas = $size[0] * $size[1];

        // Imagick decodes every frame of an animation, so each one counts.
        if ($mime === 'image/gif') {
            $pixels = static::gifPixels((string) file_get_contents($path), $canvas);
        } elseif ($mime === 'image/webp') {
            $pixels = $canvas * static::countWebpFrames((string) file_get_contents($path));
        } else {
            $pixels = $canvas;
        }

        return $pixels > 0 && $pixels <= static::getMaxPhotoPixels();
    }

    /**
     * Walks the GIF block structure. A frame can be larger than the canvas
     * getimagesize() reports, so each frame is measured by its own descriptor.
     *
     * @return int|float total pixels, or 0 when the structure cannot be read
     */
    protected static function gifPixels($data, $canvas)
    {
        $length = strlen($data);
        if ($length < 13) {
            return 0;
        }

        $pixels = 0;
        $pos = 13 + static::gifColorTableSize(ord($data[10]));

        while ($pos < $length) {
            $block = ord($data[$pos]);

            if ($block === 0x3B) {
                break;
            }

            if ($block === 0x2C) {
                if ($pos + 10 > $length) {
                    return 0;
                }
                $frame = unpack('vwidth/vheight', substr($data, $pos + 5, 4));
                $pixels += max($canvas, $frame['width'] * $frame['height']);
                // Descriptor, local colour table, LZW minimum code size.
                $pos += 10 + static::gifColorTableSize(ord($data[$pos + 9])) + 1;
            } elseif ($block === 0x21) {
                $pos += 2;
            } else {
                return 0;
            }

            // Data sub-blocks, ended by a zero-length one.
            while ($pos < $length && ($subBlock = ord($data[$pos])) !== 0) {
                $pos += $subBlock + 1;
            }
            $pos++;
        }

        return $pixels;
    }

    protected static function gifColorTableSize($flags)
    {
        return ($flags & 0x80) ? 3 * (2 << ($flags & 0x07)) : 0;
    }

    /** ANMF chunks in the RIFF container; a still WebP has none and is one frame. */
    protected static function countWebpFrames($data)
    {
        $length = strlen($data);
        $frames = 0;
        $pos = 12;

        while ($pos + 8 <= $length) {
            if (substr($data, $pos, 4) === 'ANMF') {
                $frames++;
            }
            $chunkSize = unpack('V', substr($data, $pos + 4, 4))[1];
            $pos += 8 + $chunkSize + ($chunkSize & 1);
        }

        return max(1, $frames);
    }

    public static function uploadFile($file, $postId, $allowedTypes = null, $bucketKey = '')
    {
        if (!function_exists('wp_handle_upload')) {
            require_once ABSPATH . 'wp-admin/includes/file.php';
        }

        if (!function_exists('wp_generate_attachment_metadata')) {
            require_once ABSPATH . 'wp-admin/includes/image.php';
            require_once ABSPATH . 'wp-admin/includes/media.php';
        }

        $uploadOverrides = [
            'test_form' => false,
            'mimes'     => self::resolveUploadMimes($allowedTypes),
        ];

        $uploadResult = wp_handle_upload($file, $uploadOverrides);

        if (isset($uploadResult['error'])) {
            return null;
        }

        $fileUrl  = $uploadResult['url'];
        $filePath = $uploadResult['file'];
        $fileType = $uploadResult['type'];

        $attachment = [
            'post_mime_type' => $fileType,
            'post_title'     => sanitize_file_name(pathinfo($filePath, PATHINFO_FILENAME)),
            'post_content'   => '',
            'post_status'    => 'inherit',
        ];

        $attachmentId = wp_insert_attachment($attachment, $filePath);

        if (is_wp_error($attachmentId) || !$attachmentId) {
            @unlink($filePath);
            return null;
        }

        // A review photo is shown at its stored size everywhere the plugin
        // renders it, so the eleven resized copies WordPress would make for
        // a product image are never read — and on a 12-megapixel photo they
        // cost over ten seconds of the submit request, per photo. Only the
        // media library grid's thumbnail is kept. The per-review size
        // setting already bounds what a shopper can send, so the "scaled"
        // copy for oversized originals is skipped too.
        add_filter('intermediate_image_sizes_advanced', [static::class, 'keepThumbnailOnly']);
        add_filter('big_image_size_threshold', '__return_false');

        $attachmentData = wp_generate_attachment_metadata($attachmentId, $filePath);

        remove_filter('intermediate_image_sizes_advanced', [static::class, 'keepThumbnailOnly']);
        remove_filter('big_image_size_threshold', '__return_false');

        wp_update_attachment_metadata($attachmentId, $attachmentData);

        // Tag as pending review media (will be claimed on review submission)
        $claimToken = wp_generate_uuid4();
        $uploadedAt = gmdate('Y-m-d H:i:s');

        update_post_meta($attachmentId, '_fct_pending_review', [
            'post_id'     => (int) $postId,
            'user_id'     => get_current_user_id(),
            'claim_token' => $claimToken,
            'uploaded_at' => $uploadedAt,
        ]);

        // Separate indexed key for efficient orphan cleanup queries
        update_post_meta($attachmentId, '_fct_pending_review_at', $uploadedAt);

        // Indexed bucket key for efficient per-user/product quota queries
        if ($bucketKey) {
            update_post_meta($attachmentId, '_fct_pending_review_bucket', $bucketKey);
        }

        return [
            'id'          => $attachmentId,
            'url'         => $fileUrl,
            'type'        => 'image',
            'name'        => sanitize_file_name($file['name']),
            'claim_token' => $claimToken,
        ];
    }

    /**
     * The resized copies a review photo gets: the media library grid's
     * thumbnail and nothing else. See uploadFile().
     *
     * @param  array $sizes registered sizes, name => dimensions
     * @return array
     */
    public static function keepThumbnailOnly($sizes)
    {
        return array_intersect_key((array) $sizes, ['thumbnail' => true]);
    }

    /**
     * Attach uploaded media to a review by storing references on the review row.
     *
     * @param object $review        ProductReview instance
     * @param array  $attachmentIds Array of WordPress attachment IDs
     * @param array  $claimTokens   Keyed by attachment ID: [attachmentId => token]. Required for guest claims.
     */
    /**
     * Why storeUploadedFile() last refused a file: type, size, dimensions or upload.
     *
     * @var string
     */
    protected static $lastRejection = 'upload';

    /**
     * The files a submission sent that were not stored, with the reason,
     * gathered while the request runs and handed to the response once.
     *
     * @var array<int, array{name: string, reason: string, file_index: int}>
     */
    protected static $rejectedFiles = [];

    /**
     * The files refused so far in this request, and a clean slate for the
     * next. Reasons: type (not an allowed image), size (over the limit),
     * dimensions (over the pixel limit, or unreadable),
     * limit (over the per-review photo count), upload (WordPress could not
     * store it).
     *
     * @return array<int, array{name: string, reason: string}>
     */
    public static function takeRejectedFiles(): array
    {
        $rejected = static::$rejectedFiles;
        static::$rejectedFiles = [];

        return $rejected;
    }

    protected static function rejectFile($file, string $reason, int $fileIndex)
    {
        $name = is_object($file) && isset($file['name']) ? (string) $file['name'] : '';
        static::$rejectedFiles[] = ['name' => sanitize_file_name($name), 'reason' => $reason, 'file_index' => $fileIndex];
    }

    /**
     * Store the files that arrived with a review submission and attach them
     * to the review — the storefront form, the order-review page and the
     * admin form all send their photos this way, in the one request that
     * creates (or updates) the review, so nothing is uploaded before the
     * review exists and nothing is left pending if it never does.
     *
     * Each file goes through storeUploadedFile(), the single place the MIME
     * and size rules live. The pending record is re-stamped as an unowned,
     * token-held upload — the shape a guest upload has — because the review
     * is not necessarily the uploader's: an admin-authored review belongs to
     * the named reviewer, and a review filed through an order link belongs
     * to the buyer whoever opened it. The tokens are consumed here, in this
     * same request, so none reaches the browser.
     *
     * @param  \FluentCart\App\Models\ProductReview $review
     * @param  array  $files      WPFluent File objects, as $request->files() yields
     * @param  string $bucketKey  buildBucketKey() for the uploader, for the pending record
     * @param  bool   $append     keep the review's existing media (an update)
     * @param  bool   $rateLimit apply the shopper hourly quota to each file
     * @return int[]  the attachment ids stored
     */
    public static function storeFilesForReview($review, array $files, $bucketKey = '', $append = false, $rateLimit = false)
    {
        if (!$review || empty($review->id) || !$files) {
            return [];
        }

        // A file is consumed once per request, whichever hook reaches it
        // first. The admin Add Review path fires after_submit and then
        // admin_store_media with the same request, and the framework hands
        // both the same File instances; without this each photo would be
        // stored twice.
        if (static::$consumedFiles === null) {
            static::$consumedFiles = new \SplObjectStorage();
        }
        $files = array_values($files);
        $files = array_filter($files, function ($file) {
            return !is_object($file) || !static::$consumedFiles->contains($file);
        });
        if (!$files) {
            return [];
        }
        // The whole batch is consumed here, before the cap is applied: a
        // file past the cap is refused for this submission, and must not
        // come round again as a fresh batch for the next hook to store.
        foreach ($files as $file) {
            if (is_object($file)) {
                static::$consumedFiles->attach($file);
            }
        }

        $postId = (int) $review->post_id;
        $maxPhotos = static::getMaxPhotosPerReview();
        $remainingSlots = $append
            ? max(0, $maxPhotos - count(static::getMediaForReview($review->id)))
            : $maxPhotos;

        // Hard cap before any work, so an oversized batch cannot make the
        // request do unbounded processing. The files past it are reported,
        // not silently dropped.
        foreach (array_slice($files, $remainingSlots, null, true) as $fileIndex => $overflow) {
            static::rejectFile($overflow, 'limit', $fileIndex);
        }
        $files = array_slice($files, 0, $remainingSlots, true);
        if (!$files) {
            return [];
        }

        $maxBytes = static::getMaxPhotoSizeBytes();
        $allowedTypes = static::getAllowedPhotoTypes();

        $attachmentIds = [];
        $claimTokens = [];
        $uploadLimiter = $rateLimit ? new ReviewUploadLimiter() : null;
        foreach ($files as $fileIndex => $file) {
            if (!is_object($file) || !method_exists($file, 'getError')) {
                continue;
            }

            if ( $uploadLimiter && !$uploadLimiter->claimSlot() ) {
                static::rejectFile( $file, 'rate_limit', $fileIndex );
                continue;
            }

            $storedMedia = static::storeUploadedFile($file, $postId, $bucketKey, $allowedTypes, $maxBytes);
            if (!$storedMedia) {
                static::rejectFile($file, static::$lastRejection, $fileIndex);
                continue;
            }

            $pending = get_post_meta($storedMedia['id'], '_fct_pending_review', true);
            if (is_array($pending)) {
                $pending['user_id'] = 0;
                update_post_meta($storedMedia['id'], '_fct_pending_review', $pending);
            }

            $attachmentIds[] = (int) $storedMedia['id'];
            $claimTokens[(int) $storedMedia['id']] = isset($storedMedia['claim_token']) ? $storedMedia['claim_token'] : '';
        }

        // Stored but not attached is not stored: the files are reported
        // as upload failures, and their pending markers, still in place,
        // leave them to the daily sweep.
        if ($attachmentIds && !static::attachMediaToReview($review, $attachmentIds, $claimTokens, $append)) {
            foreach ($files as $fileIndex => $file) {
                if (is_object($file) && method_exists($file, 'getError')) {
                    static::rejectFile($file, 'upload', $fileIndex);
                }
            }

            return [];
        }

        return $attachmentIds;
    }

    public static function attachMediaToReview($review, $attachmentIds, $claimTokens = [], $append = false)
    {
        // Dedupe as defense in depth — injectMediaData() dedupes the request
        // path, but this method also runs on stored pending_media_ids meta.
        $attachmentIds = array_values(array_unique(array_map('intval', array_filter($attachmentIds))));

        if (empty($attachmentIds)) {
            return false;
        }

        // Batch-prime meta cache and load attachments
        update_meta_cache('post', $attachmentIds);

        $mediaItems  = [];
        $claimedIds  = [];

        foreach ($attachmentIds as $attachmentId) {
            $pending = get_post_meta($attachmentId, '_fct_pending_review', true);

            if (!$pending || !is_array($pending)) {
                continue;
            }

            // Validate: same product
            if ((int) ($pending['post_id'] ?? 0) !== $review->post_id) {
                continue;
            }

            // Validate ownership
            $pendingUserId = (int) ($pending['user_id'] ?? 0);
            $reviewUserId  = (int) ($review->user_id ?? 0);

            if ($pendingUserId && $reviewUserId) {
                // Both logged-in — user IDs must match
                if ($pendingUserId !== $reviewUserId) {
                    continue;
                }
            } elseif ($pendingUserId > 0 && $reviewUserId === 0) {
                // Logged-in upload cannot be claimed by a guest reviewer
                continue;
            } else {
                // Guest upload — require claim token
                $expectedToken = $pending['claim_token'] ?? '';
                $providedToken = $claimTokens[$attachmentId] ?? '';

                if (!$expectedToken || !$providedToken || !hash_equals($expectedToken, $providedToken)) {
                    continue;
                }
            }

            $attachment = get_post($attachmentId);
            if (!$attachment || $attachment->post_type !== 'attachment') {
                continue;
            }

            $filePath = get_attached_file($attachmentId);

            $mediaItems[] = [
                'attachment_id' => $attachmentId,
                'url'           => wp_get_attachment_url($attachmentId),
                'type'          => 'image',
                'name'          => sanitize_text_field($filePath ? basename($filePath) : $attachment->post_title),
                'size'          => $filePath && file_exists($filePath) ? filesize($filePath) : 0,
            ];

            $claimedIds[] = $attachmentId;
        }

        if (!empty($mediaItems)) {
            if ($append) {
                // Edit flow: keep the review's existing photos and add the new
                // ones, deduped by attachment id, capped at the store limit.
                $maxPhotos = static::getMaxPhotosPerReview();

                $existingItems = static::getMediaItemsRaw($review->id);
                $byId = [];
                foreach (array_merge($existingItems, $mediaItems) as $item) {
                    $byId[(int) ($item['attachment_id'] ?? 0)] = $item;
                }
                unset($byId[0]);
                $mediaItems = array_slice(array_values($byId), 0, $maxPhotos);
            }

            // The pending markers come off only once the review row holds
            // the references. If the row cannot be found or saved, they
            // stay, so the attachment is still a pending upload the daily
            // sweep can collect rather than an untracked file.
            if (!static::persistMediaItems($review->id, $mediaItems)) {
                return false;
            }

            foreach ($claimedIds as $claimedId) {
                delete_post_meta($claimedId, '_fct_pending_review');
                delete_post_meta($claimedId, '_fct_pending_review_at');
                delete_post_meta($claimedId, '_fct_pending_review_bucket');
            }

            return true;
        }

        return false;
    }

    /**
     * Persist the media reference list on the review row: other_info['media']
     * and the denormalized media_count column, always in the same save so the
     * indexed with-photos filter can never disagree with the actual media.
     *
     * Other other_info keys are preserved — only the media key is owned here.
     *
     * @param int   $reviewId
     * @param array $items Raw media items (attachment_id, url, type, name, size)
     * @return bool the row was found and saved
     */
    protected static function persistMediaItems($reviewId, array $items): bool
    {
        $review = ProductReviewResource::find($reviewId, ['with' => []]);

        if (!$review || is_wp_error($review)) {
            return false;
        }

        $info = $review->other_info ?: [];

        if (empty($items)) {
            unset($info['media']);
        } else {
            $info['media'] = array_values($items);
        }

        $review->other_info = $info ?: null;
        $review->media_count = count($items);

        return (bool) $review->save();
    }

    /**
     * Keep only the listed photos of a review — the edit flow, where the
     * drawer shows the existing photos as removable previews. Photos the
     * review had that are not in the list were removed, so their
     * attachments are deleted, not just unreferenced.
     *
     * @param object $review  ProductReview model
     * @param int[]  $keptIds attachment ids the review keeps
     * @return bool the row took the new list
     */
    public static function syncMediaForReview($review, $keptIds)
    {
        $keptIds = array_values(array_unique(array_filter(array_map('intval', (array) $keptIds))));

        $keptItems = [];
        $removedIds = [];
        foreach (static::getMediaItemsRaw($review->id) as $item) {
            $itemId = (int) Arr::get($item, 'attachment_id', 0);
            if (in_array($itemId, $keptIds, true)) {
                $keptItems[] = $item;
            } elseif ($itemId) {
                $removedIds[] = $itemId;
            }
        }

        // The row lets go of the removed photos first; the files go only
        // once it has. A save that fails leaves the review as it was,
        // still pointing at attachments that still exist.
        if (!static::persistMediaItems($review->id, $keptItems)) {
            return false;
        }

        foreach ($removedIds as $removedId) {
            wp_delete_attachment($removedId, true);
        }

        return true;
    }

    /**
     * Delete all media attachments for a review.
     *
     * Only the attachments are deleted here — the review row (and its
     * other_info media refs) is being deleted by the caller.
     *
     * @param int $reviewId Review ID
     */
    public static function deleteMediaForReview($reviewId)
    {
        $items = static::getMediaItemsRaw($reviewId);

        foreach ($items as $item) {
            if (!empty($item['attachment_id'])) {
                wp_delete_attachment((int) $item['attachment_id'], true);
            }
        }
    }

    /**
     * Daily cleanup of orphaned pending uploads (uploaded but never attached to a review).
     *
     * The _fct_pending_review_at meta only exists on unclaimed uploads (deleted on claim),
     * so the row count for this meta_key is naturally small. We fetch all by meta_key
     * (indexed) and filter by date in PHP to avoid an unindexed meta_value range scan.
     */
    public static function cleanupOrphanedMedia()
    {
        global $wpdb;

        $cutoff = gmdate('Y-m-d H:i:s', time() - DAY_IN_SECONDS);

        // Bound the read: filter by cutoff in SQL and cap at 100 rows
        $results = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT post_id FROM {$wpdb->postmeta}
                 WHERE meta_key = %s AND meta_value <= %s
                 LIMIT 100",
                '_fct_pending_review_at',
                $cutoff
            )
        );

        foreach ($results as $row) {
            wp_delete_attachment((int) $row->post_id, true);
        }
    }

    /**
     * Get formatted media array for a single review.
     *
     * @param int $reviewId Comment ID
     * @return array Array of ['id', 'url', 'type', 'name']
     */
    public static function getMediaForReview($reviewId)
    {
        return array_map([static::class, 'formatMediaItem'], static::getMediaItemsRaw($reviewId));
    }

    /**
     * Batch-get formatted media for multiple reviews.
     *
     * @param array $reviewIds Array of review IDs
     * @return array Keyed by review_id: [reviewId => [['id', 'url', 'type', 'name'], ...]]
     */
    public static function getMediaForReviews($reviewIds)
    {
        if (empty($reviewIds)) {
            return [];
        }

        $reviews = ProductReview::query()
            ->whereIn('id', array_map('intval', $reviewIds))
            ->withMedia()
            ->get();

        $result = [];

        foreach ($reviews as $review) {
            $items = $review->media;

            if (empty($items)) {
                continue;
            }

            $result[(int) $review->id] = array_map([static::class, 'formatMediaItem'], $items);
        }

        return $result;
    }

    /**
     * Format a raw media item for API response.
     *
     * @param array $item
     * @return array
     */
    protected static function formatMediaItem($item)
    {
        return [
            'id'   => (int) ($item['attachment_id'] ?? 0),
            'url'  => esc_url($item['url'] ?? ''),
            'type' => $item['type'] ?? 'image',
            'name' => sanitize_text_field($item['name'] ?? ''),
        ];
    }

    /**
     * Get raw media items from the review row for a single review.
     *
     * @param int $reviewId
     * @return array
     */
    protected static function getMediaItemsRaw($reviewId)
    {
        $review = ProductReviewResource::find($reviewId, ['with' => []]);

        return ($review && !is_wp_error($review)) ? $review->media : [];
    }

    /**
     * Build the bucket key used to scope pending upload counts.
     *
     * Logged-in users are keyed by user ID; guests are keyed by IP so
     * different anonymous sessions do not share a single quota bucket.
     *
     * @param int    $postId Product post ID
     * @param int    $userId User ID (0 for guests)
     * @param string $ip     Client IP address (used only when userId is 0)
     * @return string
     */
    public static function buildBucketKey($postId, $userId = 0, $ip = '')
    {
        if ($userId) {
            return (int) $postId . '_user_' . (int) $userId;
        }

        return (int) $postId . '_ip_' . md5($ip);
    }

    /**
     * Count pending (unclaimed) media uploads for a quota bucket.
     *
     * Uses the indexed `_fct_pending_review_bucket` meta key so the query
     * hits a single index lookup instead of scanning every pending row.
     *
     * @param string $bucketKey Value returned by buildBucketKey()
     * @return int
     */
    public static function getPendingMediaCount($bucketKey)
    {
        global $wpdb;

        return (int) $wpdb->get_var(
            $wpdb->prepare(
                "SELECT COUNT(*) FROM {$wpdb->postmeta}
                 WHERE meta_key = '_fct_pending_review_bucket'
                   AND meta_value = %s",
                $bucketKey
            )
        );
    }
}
