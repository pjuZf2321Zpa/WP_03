<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Actions\BookingCalendar\BookingCalendarProHelper;
use BitApps\IntegrationsPro\Config;
use BitApps\IntegrationsPro\Core\Util\Hooks;

Hooks::filter(Config::withFreePrefix('booking_calendar_create_booking'), [BookingCalendarProHelper::class, 'createBooking'], 10, 4);
Hooks::filter(Config::withFreePrefix('booking_calendar_update_booking'), [BookingCalendarProHelper::class, 'updateBooking'], 10, 4);
