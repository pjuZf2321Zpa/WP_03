<?php
/**
 * RSVP V2 REST Properties handler for Event Tickets Plus.
 *
 * Handles adding ET+ RSVP-specific properties to REST API documentation and parameters.
 *
 * @since 6.11.0
 *
 * @package TEC\Tickets_Plus\RSVP\V2
 */

namespace TEC\Tickets_Plus\RSVP\V2;

use TEC\Common\REST\TEC\V1\Collections\PropertiesCollection;
use TEC\Common\REST\TEC\V1\Parameter_Types\Boolean;
use TEC\Tickets\Commerce\Ticket;
use TEC\Tickets\RSVP\V2\Constants as RSVP_Constants;
use Tribe\Tickets\Plus\Attendee_Registration\IAC;
use WP_Post;

/**
 * Class REST_Properties
 *
 * @since 6.11.0
 *
 * @package TEC\Tickets_Plus\RSVP\V2
 */
class REST_Properties {
	/**
	 * The list of ET+ RSVP field keys handled by this class.
	 *
	 * @since 6.11.0
	 *
	 * @var string[]
	 */
	private const FIELDS = [
		'iac',
		'rsvp_show_attendees',
		'rsvp_waitlist_before_sale',
		'rsvp_waitlist_sold_out',
	];

	/**
	 * Add the IAC setting to the ticket properties in REST API responses.
	 *
	 * @since 6.11.0
	 *
	 * @param array<string,mixed> $properties Properties to add to the model.
	 * @param WP_Post             $post       The ticket post object.
	 *
	 * @return array<string,mixed> Modified properties.
	 */
	public function add_iac_to_properties( array $properties, WP_Post $post ): array {
		$type = $properties['type'] ?? get_post_meta( $post->ID, '_type', true );

		if ( RSVP_Constants::TC_RSVP_TYPE !== $type ) {
			return $properties;
		}

		/** @var IAC $iac */
		$iac               = tribe( 'tickets-plus.attendee-registration.iac' );
		$properties['iac'] = $iac->get_iac_setting_for_ticket( $post->ID );

		return $properties;
	}

	/**
	 * Add the show-attendees setting to the ticket properties in REST API responses.
	 *
	 * The setting is stored on the event post, not the ticket, so it is read via
	 * the ticket's related event ID rather than directly off the ticket post.
	 *
	 * @since 6.11.0
	 *
	 * @param array<string,mixed> $properties Properties to add to the model.
	 * @param WP_Post             $post       The ticket post object.
	 *
	 * @return array<string,mixed> Modified properties.
	 */
	public function add_show_attendees_to_properties( array $properties, $post ): array {
		if ( ! $post instanceof WP_Post ) {
			return $properties;
		}

		$type = $properties['type'] ?? get_post_meta( $post->ID, '_type', true );

		if ( RSVP_Constants::TC_RSVP_TYPE !== $type ) {
			return $properties;
		}

		$event_id = get_post_meta( $post->ID, Ticket::$event_relation_meta_key, true );

		if ( empty( $event_id ) ) {
			return $properties;
		}

		$properties['rsvp_show_attendees'] = tribe_is_truthy( get_post_meta( $event_id, Constants::SHOW_RSVP_META_KEY, true ) );

		return $properties;
	}

	/**
	 * Add "rsvp_show_attendees" to the list of REST properties for RSVP tickets.
	 *
	 * Without this, the property is computed by add_show_attendees_to_properties() but
	 * silently dropped, since only properties in this whitelist are exposed in REST responses.
	 *
	 * @since 6.11.0
	 *
	 * @param array<string,bool> $properties The properties to expose in REST.
	 *
	 * @return array<string,bool> Modified properties.
	 */
	public function add_show_attendees_to_rest_properties( array $properties ): array {
		$properties['rsvp_show_attendees'] = true;

		return $properties;
	}

	/**
	 * Add ET+ RSVP fields to the REST API request body documentation.
	 *
	 * @since 6.11.0
	 *
	 * @param array<string,mixed> $documentation The Swagger documentation array.
	 *
	 * @return array<string,mixed> Modified documentation.
	 */
	public function add_fields_to_request_body_docs( array $documentation ): array {
		$properties = $documentation['allOf'][1]['properties'] ?? null;

		if ( ! $properties instanceof PropertiesCollection ) {
			return $documentation;
		}

		$properties[] = (
			new Boolean(
				'rsvp_show_attendees',
				fn() => __( 'Whether to show the attendees list on the event page.', 'event-tickets-plus' ),
			)
		)->set_example( false );

		$properties[] = (
			new Boolean(
				'rsvp_waitlist_before_sale',
				fn() => __( 'Whether to enable waitlist before the RSVP period starts.', 'event-tickets-plus' ),
			)
		)->set_example( false );

		$properties[] = (
			new Boolean(
				'rsvp_waitlist_sold_out',
				fn() => __( 'Whether to enable waitlist when the RSVP reaches capacity.', 'event-tickets-plus' ),
			)
		)->set_example( false );

		return $documentation;
	}

	/**
	 * Filters the ticket upsert parameters to include ET+ RSVP fields.
	 *
	 * When the REST API processes a ticket update/insertion, this method ensures
	 * the ET+ RSVP fields from the request parameters are forwarded into
	 * the ticket parameters that reach `ticket_add()`.
	 *
	 * @since 6.11.0
	 *
	 * @param array<string,mixed> $ticket_params The ticket parameters for update/insertion.
	 * @param array<string,mixed> $params        The raw REST API request parameters.
	 *
	 * @return array<string,mixed> The filtered ticket parameters.
	 */
	public function add_fields_to_upsert_params( array $ticket_params, array $params ): array {
		foreach ( self::FIELDS as $field ) {
			if ( isset( $params[ $field ] ) ) {
				$ticket_params[ $field ] = $params[ $field ];
			}
		}

		return $ticket_params;
	}

	/**
	 * Filters Classic Editor post-save ticket data to include ET+ RSVP fields.
	 *
	 * Switch fields are omitted from POST when unchecked, so each field is
	 * explicitly set to an empty string when absent.
	 *
	 * @since 6.11.0
	 *
	 * @param array<string,mixed> $data      The mapped ticket data for ticket_add().
	 * @param int                 $post_id   The parent post ID.
	 * @param array<string,mixed> $post_data The raw POST data from the metabox.
	 *
	 * @return array<string,mixed> The filtered ticket data.
	 */
	public function add_fields_to_classic_save_data( array $data, int $post_id, array $post_data ): array {
		foreach ( self::FIELDS as $field ) {
			$data[ $field ] = '';
			if ( isset( $post_data[ $field ] ) ) {
				$data[ $field ] = sanitize_text_field( wp_unslash( $post_data[ $field ] ) );
			}
		}

		return $data;
	}
}
