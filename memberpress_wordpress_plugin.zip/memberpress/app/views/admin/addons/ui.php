<?php
/**
 * View admin/addons/ui.
 *
 * @var array<string, array>                                    $registered_tabs
 * @var string                                                  $active_tab
 * @var MemberPress\GroundLevel\Mothership\Manager\AddonsManager $addons_manager
 */

defined('ABSPATH') || exit;
?>

<div id="mepr-admin-addons" class="wrap">

  <h2><?php esc_html_e('MemberPress Add-ons', 'memberpress'); ?></h2>

  <nav class="nav-tab-wrapper">
    <?php
    // Render registered tabs.
    if (!empty($registered_tabs)) :
        foreach ($registered_tabs as $tab_config) :
            // Check capability.
            if (!current_user_can($tab_config['capability'])) {
                continue;
            }

            $is_active = $active_tab === $tab_config['id'] ? 'nav-tab-active' : '';
            ?>
            <a href="<?php echo esc_url(admin_url('admin.php?page=memberpress-addons&tab=' . $tab_config['id'])); ?>"
               class="nav-tab <?php echo esc_attr($is_active); ?>">
                <?php echo esc_html($tab_config['label']); ?>
            </a>
            <?php
        endforeach;
    endif;
    ?>
  </nav>

  <?php if ($active_tab === 'addons') : ?>
    <div class="mepr-tab-content mepr-tab-addons">
        <?php echo $addons_manager->generateAddonsHtml(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
    </div>
  <?php endif; ?>

  <?php
    // Render registered tab content.
    if (!empty($registered_tabs) && isset($registered_tabs[$active_tab])) :
        $current_tab = $registered_tabs[$active_tab];

        // Check capability.
        if (current_user_can($current_tab['capability'])) :
            // Call tab callback if defined and not the default addons tab.
            if ($active_tab !== 'addons' && $current_tab['callback'] && is_callable($current_tab['callback'])) :
                ?>
                <div class="mepr-tab-content mepr-tab-<?php echo esc_attr($active_tab); ?>">
                    <?php
                    call_user_func($current_tab['callback']);
                    ?>
                </div>
                <?php
            endif;
        endif;
    endif;
    ?>

</div>
