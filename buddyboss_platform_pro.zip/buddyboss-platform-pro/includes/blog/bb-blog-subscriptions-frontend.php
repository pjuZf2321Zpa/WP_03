<?php
/**
 * BuddyBoss Pro Blog Subscriptions — frontend (category archive subscribe button).
 *
 * Loaded from `BB_Blog::includes()` only when the `bb_blog_enable_subscriptions`
 * option is on (same rationale as `bb-blog-subscriptions.php`). Requires the
 * `blog_category` subscription type registered by `BB_Blog_Notification`
 * (`includes/class-bb-blog-notification.php`) to already be loaded.
 *
 * @package BuddyBossPro
 *
 * @since 3.1.0
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

/**
 * Whether the subscribe button can render for the current request.
 *
 * @since 3.1.0
 *
 * @return bool
 */
function bb_blog_pro_subscribe_button_will_render() {
	return is_category() && is_user_logged_in() && bb_blog_pro_is_subscriptions_enabled();
}

/**
 * Look up the current user's `blog_category` subscription ID for a term.
 *
 * @since 3.1.0
 *
 * @param int $term_id Category term ID.
 *
 * @return int Subscription ID, or 0 when not subscribed.
 */
function bb_blog_pro_get_category_subscription_id( $term_id ) {
	$term_id = absint( $term_id );

	if ( empty( $term_id ) || ! is_user_logged_in() || ! function_exists( 'bb_get_subscriptions' ) ) {
		return 0;
	}

	// `$force_cache = true` bypasses `bb_get_subscriptions()`'s internal
	// static per-request cache -- without it, a subscribe/unsubscribe that
	// just happened earlier in the same PHP process (e.g. a REST request
	// handled inline, or multiple lookups in one admin-ajax/CLI run) would
	// keep returning the pre-change result for the rest of the request.
	$subscriptions = bb_get_subscriptions(
		array(
			'type'    => 'blog_category',
			'item_id' => $term_id,
			'user_id' => get_current_user_id(),
			'fields'  => 'id',
			'count'   => false,
		),
		true
	);

	if ( ! empty( $subscriptions['subscriptions'][0] ) ) {
		return (int) $subscriptions['subscriptions'][0];
	}

	return 0;
}

/**
 * Render the "Subscribe" button for the currently viewed blog category.
 *
 * Only renders on a category archive, for logged-in users, when the
 * subscriptions gate passes. Hooked into both the ReadyLaunch blog archive
 * header (`bb_blog_archive_header_actions`, fired only on blog archive
 * templates) and the classic theme's `buddyboss_theme_before_content` hook
 * (fired on every front-end request, hence the internal `is_category()`
 * guard) so the button renders in both frontend modes. A static once-guard
 * prevents a double render on the rare request where both hooks would
 * otherwise fire.
 *
 * @since 3.1.0
 *
 * @return void
 */
function bb_blog_pro_render_subscribe_button() {
	static $rendered = false;

	if ( $rendered || ! bb_blog_pro_subscribe_button_will_render() ) {
		return;
	}

	$term_id = get_queried_object_id();

	if ( empty( $term_id ) ) {
		return;
	}

	$subscription_id  = bb_blog_pro_get_category_subscription_id( $term_id );
	$is_subscribed    = ! empty( $subscription_id );
	$label_subscribe  = __( 'Subscribe', 'buddyboss-pro' );
	$label_subscribed = __( 'Subscribed', 'buddyboss-pro' );

	$rendered = true;
	?>
	<button
		type="button"
		class="bb-blog-subscribe<?php echo esc_attr( $is_subscribed ? ' is-subscribed' : '' ); ?>"
		data-term-id="<?php echo esc_attr( $term_id ); ?>"
		data-subscription-id="<?php echo esc_attr( $subscription_id ); ?>"
		aria-pressed="<?php echo esc_attr( $is_subscribed ? 'true' : 'false' ); ?>"
	>
		<i class="<?php echo esc_attr( $is_subscribed ? bb_blog_pro_icon_class( 'bb-icons-rl-bell-slash', 'bb-icon-l bb-icon-bell-slash' ) : bb_blog_pro_icon_class( 'bb-icons-rl-bell', 'bb-icon-l bb-icon-bell-plus' ) ); ?> bb-blog-subscribe__icon" aria-hidden="true"></i>
		<span class="bb-blog-subscribe__label"><?php echo esc_html( $is_subscribed ? $label_subscribed : $label_subscribe ); ?></span>
	</button>
	<?php
}
add_action( 'bb_blog_archive_header_actions', 'bb_blog_pro_render_subscribe_button' );

/*
 * Classic (non-ReadyLaunch) theme mode: buddyboss-theme's header.php fires
 * `{THEME_HOOK_PREFIX}before_content` (resolves to `buddyboss_theme_before_content`
 * since `THEME_HOOK_PREFIX` is `'buddyboss_theme_'`) on every front-end
 * request, right before the `#content` wrapper -- confirmed present in
 * `wp-content/themes/buddyboss-theme/header.php`. The literal hook name is
 * used here (rather than the `THEME_HOOK_PREFIX` constant) so this file does
 * not hard-fail if buddyboss-theme is inactive; `bb_blog_pro_render_subscribe_button()`
 * itself is a no-op when the hook never fires or `is_category()` is false.
 */
add_action( 'buddyboss_theme_before_content', 'bb_blog_pro_render_subscribe_button' );

/**
 * Enqueue the subscribe button script/style when the gate passes.
 *
 * @since 3.1.0
 *
 * @return void
 */
function bb_blog_pro_subscriptions_enqueue_scripts() {
	if ( ! bb_blog_pro_subscribe_button_will_render() ) {
		return;
	}

	$version = bb_platform_pro()->version;

	// Shared style handle registered in bb-blog-loader.php — see
	// bb_blog_pro_register_frontend_style(). Both blog frontends load the same
	// stylesheet, so they share one handle to avoid a duplicate <link> tag.
	wp_enqueue_style( 'bb-blog-pro' );

	wp_enqueue_script(
		'bb-blog-pro-subscriptions',
		bb_blog_pro_url( 'assets/js/bb-blog-subscriptions.js' ),
		array(),
		$version,
		true
	);

	$rest_base = 'buddyboss/v1/subscriptions';

	if ( function_exists( 'bp_rest_namespace' ) && function_exists( 'bp_rest_version' ) ) {
		$rest_base = bp_rest_namespace() . '/' . bp_rest_version() . '/subscriptions';
	}

	wp_localize_script(
		'bb-blog-pro-subscriptions',
		'bbBlogProSubs',
		array(
			'icons'   => bb_blog_pro_icon_classes(),
			'restUrl' => esc_url_raw( rest_url( $rest_base ) ),
			'nonce'   => wp_create_nonce( 'wp_rest' ),
			'labels'  => array(
				'subscribe'  => __( 'Subscribe', 'buddyboss-pro' ),
				'subscribed' => __( 'Subscribed', 'buddyboss-pro' ),
			),
		)
	);
}
add_action( 'wp_enqueue_scripts', 'bb_blog_pro_subscriptions_enqueue_scripts' );

/**
 * Whether the "Subscribe to topics" modal + its triggers may render for the
 * current request (blog directory, single post, or the Blog Subscriptions
 * settings tab).
 *
 * @since 3.1.0
 *
 * @return bool
 */
function bb_blog_pro_modal_context() {
	if ( ! is_user_logged_in() || ! bb_blog_pro_is_subscriptions_enabled() ) {
		return false;
	}

	$is_settings_tab = function_exists( 'bp_is_user_settings' ) && bp_is_user_settings() && bp_is_current_action( 'notifications' ) && bp_is_action_variable( 0, 'blog-subscriptions' );

	// Category archives use the legacy direct-subscribe button + its own
	// script; loading the modal there would double-bind `.bb-blog-subscribe`.
	return is_home() || is_singular( 'post' ) || is_tag() || is_author() || is_date() || $is_settings_tab;
}

/**
 * Print the shared modal shell once in the footer when in a modal context.
 *
 * @since 3.1.0
 *
 * @return void
 */
function bb_blog_pro_render_subscribe_modal() {
	if ( ! bb_blog_pro_modal_context() ) {
		return;
	}

	require bb_blog_pro_path( 'templates/subscribe-modal.php' );
}
add_action( 'wp_footer', 'bb_blog_pro_render_subscribe_modal' );

/**
 * Enqueue the modal script/style + config in modal contexts.
 *
 * @since 3.1.0
 *
 * @return void
 */
function bb_blog_pro_modal_enqueue_scripts() {
	if ( ! bb_blog_pro_modal_context() ) {
		return;
	}

	$version = bb_platform_pro()->version;

	// Shared style handle registered in bb-blog-loader.php — see
	// bb_blog_pro_register_frontend_style(). Both blog frontends load the same
	// stylesheet, so they share one handle to avoid a duplicate <link> tag.
	wp_enqueue_style( 'bb-blog-pro' );

	wp_enqueue_script(
		'bb-blog-pro-subscribe-modal',
		bb_blog_pro_url( 'assets/js/bb-blog-subscribe-modal.js' ),
		array(),
		$version,
		true
	);

	$ns   = ( function_exists( 'bp_rest_namespace' ) && function_exists( 'bp_rest_version' ) ) ? bp_rest_namespace() . '/' . bp_rest_version() : 'buddyboss/v1';
	$base = rest_url( $ns );

	wp_localize_script(
		'bb-blog-pro-subscribe-modal',
		'bbBlogProModal',
		array(
			'categoriesUrl'    => esc_url_raw( trailingslashit( $base ) . 'blog-subscriptions/categories' ),
			'subscriptionsUrl' => esc_url_raw( trailingslashit( $base ) . 'subscriptions' ),
			'nonce'            => wp_create_nonce( 'wp_rest' ),
			// Page size for the modal's infinite-scroll fetch. Kept <= the REST
			// endpoint's per_page maximum (100); the modal loads the next page as
			// the list nears the bottom. Filterable for large taxonomies.
			'perPage'          => (int) apply_filters( 'bb_blog_pro_subscribe_modal_per_page', 20 ),
			'icons'            => bb_blog_pro_icon_classes(),
			'labels'           => array(
				'subscribe'    => __( 'Subscribe', 'buddyboss-pro' ),
				'subscribed'   => __( 'Subscribed', 'buddyboss-pro' ),
				// Shown in place of "Subscribed" while hovering a subscribed
				// topic, where the button turns into the unsubscribe action.
				'unsubscribed' => __( 'Unsubscribed', 'buddyboss-pro' ),
			),
			'i18n'             => array(
				/* translators: %d: number of posts. */
				'postsOnTopic' => __( '%d Posts on this topic', 'buddyboss-pro' ),
			),
		)
	);
}
add_action( 'wp_enqueue_scripts', 'bb_blog_pro_modal_enqueue_scripts' );

/**
 * Render the "Subscribe" button in the public blog directory header. Opens
 * the "Subscribe to topics" modal. Distinct from the per-category-archive
 * button above: this one shows on the main blog index (not category pages).
 *
 * @since 3.1.0
 *
 * @return void
 */
function bb_blog_pro_render_directory_subscribe_button() {
	if ( is_category() || ! is_user_logged_in() || ! bb_blog_pro_is_subscriptions_enabled() ) {
		return;
	}
	?>
	<button type="button" class="bb-rl-button bb-rl-button--secondaryOutline bb-rl-button--small js-bb-blog-subscribe-open bb-blog-directory-subscribe">
		<i class="bb-icons-rl-bell-simple-ringing" aria-hidden="true"></i>
		<span><?php esc_html_e( 'Subscribe', 'buddyboss-pro' ); ?></span>
	</button>
	<?php
}
add_action( 'bb_blog_archive_header_actions', 'bb_blog_pro_render_directory_subscribe_button' );

/**
 * Render a bell icon in the single blog post meta row. Opens the "Subscribe
 * to topics" modal.
 *
 * @since 3.1.0
 *
 * @param int $post_id Post ID.
 *
 * @return void
 */
function bb_blog_pro_render_single_subscribe_bell( $post_id ) {
	// $post_id is unused; kept to match the hook signature.
	if ( ! is_user_logged_in() || ! bb_blog_pro_is_subscriptions_enabled() ) {
		return;
	}
	?>
	<button type="button" class="bb-blog-single-subscribe-bell js-bb-blog-subscribe-open" aria-label="<?php esc_attr_e( 'Subscribe to topics', 'buddyboss-pro' ); ?>">
		<i class="<?php echo esc_attr( bb_blog_pro_icon_class( 'bb-icons-rl-bell-simple-ringing', 'bb-icon-l bb-icon-bell-plus' ) ); ?>" aria-hidden="true"></i>
	</button>
	<?php
}
add_action( 'bb_rl_blog_single_meta_actions', 'bb_blog_pro_render_single_subscribe_bell' );

/**
 * Register the "Blog Subscriptions" tab under Settings > Notifications.
 *
 * @since 3.1.0
 *
 * @return void
 */
function bb_blog_pro_register_subscriptions_subnav() {
	// `bb_settings_supports_notification_subnav()` marks a Platform build that
	// has the custom-notification-sub-tab seam. Without it, registering this
	// sub-nav would surface a "Blog Subscriptions" pill that 404s on click, so
	// skip registration on older Platform versions.
	if (
		! function_exists( 'bb_settings_supports_notification_subnav' ) ||
		! bp_is_active( 'settings' ) ||
		! is_user_logged_in() ||
		! bb_blog_pro_is_subscriptions_enabled()
	) {
		return;
	}

	$settings_slug = function_exists( 'bp_get_settings_slug' ) ? bp_get_settings_slug() : 'settings';
	$user_domain   = bp_displayed_user_domain() ? bp_displayed_user_domain() : bp_loggedin_user_domain();
	$settings_link = trailingslashit( $user_domain . $settings_slug );

	bp_core_new_subnav_item(
		array(
			'name'            => __( 'Blog Subscriptions', 'buddyboss-pro' ),
			'slug'            => 'blog-subscriptions',
			'parent_url'      => trailingslashit( $settings_link . 'notifications' ),
			'parent_slug'     => $settings_slug . '_notifications',
			'screen_function' => 'bp_settings_screen_notification',
			'position'        => 3,
			'user_has_access' => bp_core_can_edit_settings(),
		)
	);
}
add_action( 'bp_setup_nav', 'bb_blog_pro_register_subscriptions_subnav', 20 );

/**
 * Route the `blog-subscriptions` notifications sub-tab through the shared
 * settings notification screen.
 *
 * The Settings component dispatches every `notifications/*` sub-action through
 * `bp_settings_screen_notification()`, which 404s any sub-action it does not
 * recognise. This filter claims the `blog-subscriptions` sub-action, hooks the
 * tab content, and returns the generic plugin template so it renders inside the
 * settings layout (with the notification sub-nav pills).
 *
 * @since 3.1.0
 *
 * @param string|false $template        Template path, or false to 404.
 * @param string       $action_variable The requested sub-tab slug.
 *
 * @return string|false
 */
function bb_blog_pro_blog_subscriptions_template( $template, $action_variable ) {
	if ( 'blog-subscriptions' === $action_variable && bb_blog_pro_is_subscriptions_enabled() ) {
		// Non-empty return signals the screen handler that this sub-action is
		// valid (prevents a 404). The actual content is rendered by the
		// settings template router via `bb_member_settings_notifications_custom_tab`.
		return 'members/single/plugins';
	}

	return $template;
}
add_filter( 'bb_settings_notification_subnav_template', 'bb_blog_pro_blog_subscriptions_template', 10, 2 );

/**
 * Render the "Blog Subscriptions" tab content inside the member settings
 * template router (both ReadyLaunch and legacy nouveau).
 *
 * @since 3.1.0
 *
 * @param string $action_variable The notifications sub-tab slug.
 *
 * @return void
 */
function bb_blog_pro_render_blog_subscriptions_tab( $action_variable ) {
	if ( 'blog-subscriptions' !== $action_variable || ! bb_blog_pro_is_subscriptions_enabled() ) {
		return;
	}

	bb_blog_pro_blog_subscriptions_content();
}
add_action( 'bb_member_settings_notifications_custom_tab', 'bb_blog_pro_render_blog_subscriptions_tab' );

/**
 * Output the "Blog Subscriptions" tab content.
 *
 * @since 3.1.0
 *
 * @return void
 */
function bb_blog_pro_blog_subscriptions_content() {
	require bb_blog_pro_path( 'templates/settings-blog-subscriptions.php' );
}
