const masterstudyNotificationsDbName = 'masterstudy-notifications-push';
const masterstudyNotificationsStore = 'currentBrowser';

function masterstudyNotificationsOpenDb() {
	return new Promise(function (resolve, reject) {
		const request = indexedDB.open(masterstudyNotificationsDbName, 1);

		request.onupgradeneeded = function () {
			request.result.createObjectStore(masterstudyNotificationsStore);
		};
		request.onsuccess = function () {
			resolve(request.result);
		};
		request.onerror = function () {
			reject(request.error);
		};
	});
}

function masterstudyNotificationsSetState(state) {
	return masterstudyNotificationsOpenDb().then(function (db) {
		return new Promise(function (resolve, reject) {
			const transaction = db.transaction(masterstudyNotificationsStore, 'readwrite');
			const store = transaction.objectStore(masterstudyNotificationsStore);

			store.put(state.user_id || 0, 'user_id');
			store.put(state.browser_key || '', 'browser_key');
			transaction.oncomplete = resolve;
			transaction.onerror = function () {
				reject(transaction.error);
			};
		});
	});
}

function masterstudyNotificationsGetState() {
	return masterstudyNotificationsOpenDb().then(function (db) {
		return new Promise(function (resolve) {
			const transaction = db.transaction(masterstudyNotificationsStore, 'readonly');
			const store = transaction.objectStore(masterstudyNotificationsStore);
			const userRequest = store.get('user_id');
			const browserRequest = store.get('browser_key');
			const state = {};

			userRequest.onsuccess = function () {
				state.user_id = userRequest.result || 0;
			};
			browserRequest.onsuccess = function () {
				state.browser_key = browserRequest.result || '';
			};
			transaction.oncomplete = function () {
				resolve(state);
			};
			transaction.onerror = function () {
				resolve({});
			};
		});
	});
}

function masterstudyNotificationsParsePayload(event) {
	if (!event.data) {
		return {};
	}

	try {
		return event.data.json();
	} catch (error) {
		return {
			title: 'MasterStudy notification',
			body: event.data.text ? event.data.text() : '',
			url: '/',
		};
	}
}

function masterstudyNotificationsNotifyClients(payload, notificationId) {
	return clients.matchAll({ type: 'window', includeUncontrolled: true }).then(function (clientList) {
		clientList.forEach(function (client) {
			client.postMessage({
				type: 'masterstudy_notifications_push_received',
				notification_id: notificationId,
				trigger_key: payload.trigger_key || '',
			});
		});
	});
}

self.addEventListener('message', function (event) {
	if (!event.data || event.data.type !== 'masterstudy_notifications_push_state') {
		return;
	}

	event.waitUntil(masterstudyNotificationsSetState(event.data));
});

self.addEventListener('push', function (event) {
	const payload = masterstudyNotificationsParsePayload(event);
	const notificationId = payload.notification_id ? String(payload.notification_id) : String(Date.now());

	event.waitUntil(
		masterstudyNotificationsGetState().then(function (state) {
			if (
				payload.user_id
				&& state.user_id
				&& String(payload.user_id) !== String(state.user_id)
			) {
				return null;
			}

			if (
				payload.browser_key
				&& state.browser_key
				&& String(payload.browser_key) !== String(state.browser_key)
			) {
				return null;
			}

			const notificationOptions = {
				body: payload.body || '',
				tag: 'masterstudy-notification-' + notificationId,
				renotify: true,
				timestamp: Date.now(),
				data: {
					url: payload.url || '/',
				},
			};

			if (payload.icon) {
				notificationOptions.icon = payload.icon;
			}

			if (payload.badge) {
				notificationOptions.badge = payload.badge;
			}

			return Promise.all([
				self.registration.showNotification(payload.title || 'MasterStudy notification', notificationOptions),
				masterstudyNotificationsNotifyClients(payload, notificationId),
			]);
		})
	);
});

self.addEventListener('notificationclick', function (event) {
	const url = event.notification.data && event.notification.data.url ? event.notification.data.url : '/';

	event.notification.close();
	event.waitUntil(
		clients.matchAll({ type: 'window', includeUncontrolled: true }).then(function (clientList) {
			for (const client of clientList) {
				if (client.url === url && 'focus' in client) {
					return client.focus();
				}
			}

			return clients.openWindow(url);
		})
	);
});
