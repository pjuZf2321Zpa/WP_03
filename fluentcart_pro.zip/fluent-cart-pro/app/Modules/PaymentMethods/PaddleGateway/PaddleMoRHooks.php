<?php

namespace FluentCartPro\App\Modules\PaymentMethods\PaddleGateway;

use FluentCart\Framework\Support\Arr;

/**
 * WordPress filter hooks for Paddle MoR transactions. Registered once at gateway boot.
 *
 * Cover approach: txn.total = order.total_amount always, so StatusHelper marks orders
 * paid naturally. The only filter needed is fluentcart_max_refundable_amount — it caps
 * admin refund input to what Paddle actually captured (meta.paddle_captured), which
 * differs from txn.total for reverse-charge and cross-currency orders.
 */
class PaddleMoRHooks
{
    private static bool $registered = false;

    public static function register(): void
    {
        if (self::$registered) {
            return;
        }
        self::$registered = true;

        add_filter('fluent_cart/transaction/max_refundable_amount', [self::class, 'adjustMoRRefundable'], 10, 2);
    }

    /**
     * For MoR transactions the actual refundable cap is what Paddle captured
     * (paddle_captured in meta), not txn.total — they diverge for reverse-charge
     * and cross-currency orders.
     */
    public static function adjustMoRRefundable(int $amount, $transaction): int
    {
        $meta = (array)($transaction->meta ?? []);
        if (empty(Arr::get($meta, 'mor_covered'))) {
            return $amount;
        }
        $paddleCaptured = (int) Arr::get($meta, 'paddle_captured', 0);
        if ($paddleCaptured <= 0) {
            return $amount;
        }
        $refunded = (int) Arr::get($meta, 'refunded_total', 0);
        $order    = $transaction->order;
        if (!$order) {
            return max(0, $paddleCaptured - $refunded);
        }

        $paddleCapturedCurrency = strtoupper((string) Arr::get($meta, 'paddle_captured_currency', ''));
        $orderCurrency          = strtoupper((string) ($order->currency ?? ''));

        if ($paddleCapturedCurrency && $orderCurrency && $paddleCapturedCurrency !== $orderCurrency) {
            // Cross-currency: paddle_captured is foreign currency; admin enters order currency.
            return max(0, (int) $order->total_amount - $refunded);
        }

        // Same-currency: min(paddle_captured, order.total_amount) handles both directions.
        // Tax-excluded (captured > order price) → cap at order price.
        // Reverse-charge (captured < order price) → cap at what Paddle holds.
        return max(0, min($paddleCaptured, (int) $order->total_amount) - $refunded);
    }
}
