<?php

namespace WPAICG\Lib\Chat\Triggers\Actions;

use WPAICG\Chat\Storage\LogStorage;
use WPAICG\Lib\Chat\Triggers\State\AIPKit_Conversation_Form_State_Store;
use WP_Error;

if (!defined('ABSPATH')) {
    exit;
}

/** Resolves display placeholders while retaining the missing-processor fallback. */
function aipkit_process_action_template($template, array $context_data) {
    return class_exists(AIPKit_Placeholder_Processor::class)
        ? AIPKit_Placeholder_Processor::process($template, $context_data)
        : $template;
}

if (!class_exists(AIPKit_Action_Bot_Reply::class)) {
    /**
     * AIPKit_Action_Bot_Reply
     *
     * Handles the 'bot_reply' trigger action.
     */
    class AIPKit_Action_Bot_Reply {

        /**
         * Executes the 'bot_reply' action.
         *
         * @param array $payload Payload containing 'message' and 'stop_processing_ai'.
         * @param array $context_data Contextual data.
         * @param int   $bot_id Bot ID.
         * @return array|WP_Error Action result.
         */
        public function execute(array $payload, array $context_data, int $bot_id) {
            $message_template = $payload['message'] ?? '';
            $stop_ai = isset($payload['stop_processing_ai']) && $payload['stop_processing_ai'] === true;

            if (empty($message_template)) {
                return new WP_Error('missing_reply_message', __('Bot reply action is missing the message template.', 'gpt3-ai-content-generator'));
            }

            $processed_message = aipkit_process_action_template($message_template, $context_data);

            return [
                'type'    => 'bot_reply',
                'message' => $processed_message,
                'stop_ai' => $stop_ai,
            ];
        }
    }
}

if (!class_exists(AIPKit_Action_Inject_Context::class)) {
    /**
     * AIPKit_Action_Inject_Context
     *
     * Handles the 'inject_context' trigger action.
     */
    class AIPKit_Action_Inject_Context {

        /**
         * Executes the 'inject_context' action.
         *
         * @param array $payload Payload containing 'placement' (was 'type') and 'content'.
         * @param array $context_data Contextual data.
         * @param int   $bot_id Bot ID.
         * @return array|WP_Error Action result.
         */
        public function execute(array $payload, array $context_data, int $bot_id) {
            $placement = $payload['placement'] ?? null;
            $content_template = $payload['content'] ?? '';

            $valid_placements = ['system_instruction_prepend', 'system_instruction_append', 'history_prepend'];
            if (empty($placement) || !in_array($placement, $valid_placements, true)) {
                return new WP_Error('invalid_context_placement', __('Invalid or missing placement type for inject_context action.', 'gpt3-ai-content-generator'));
            }
            if (empty($content_template)) {
                return new WP_Error('missing_context_content', __('Content template is missing for inject_context action.', 'gpt3-ai-content-generator'));
            }

            $processed_content = aipkit_process_action_template($content_template, $context_data);

            return [
                'type'      => 'inject_context',
                'placement' => $placement,
                'content'   => $processed_content,
            ];
        }
    }
}

if (!class_exists(AIPKit_Action_Block_Message::class)) {
    /**
     * AIPKit_Action_Block_Message
     *
     * Handles the 'block_message' trigger action.
     */
    class AIPKit_Action_Block_Message {

        /**
         * Executes the 'block_message' action.
         *
         * @param array $payload Payload optionally containing 'reason'.
         * @param array $context_data Contextual data.
         * @param int   $bot_id Bot ID.
         * @return array Action result.
         */
        public function execute(array $payload, array $context_data, int $bot_id): array {
            $reason_template = $payload['reason'] ?? __('Your message could not be processed at this time.', 'gpt3-ai-content-generator');
            $processed_reason = aipkit_process_action_template($reason_template, $context_data);

            return [
                'type'                   => 'block_message',
                'reason'                 => $processed_reason,
                'stop_ai'                => true,
                'block_further_triggers' => true,
            ];
        }
    }
}

if (!class_exists(AIPKit_Action_Set_Variable::class)) {
    /**
     * AIPKit_Action_Set_Variable
     *
     * Handles the 'set_variable' trigger action.
     */
    class AIPKit_Action_Set_Variable {

        /**
         * Executes the 'set_variable' action.
         *
         * @param array $payload Payload containing 'scope', 'key', and 'value'.
         * @param array $context_data Contextual data.
         * @param int   $bot_id Bot ID.
         * @return array|WP_Error Action result.
         */
        public function execute(array $payload, array $context_data, int $bot_id) {
            $scope = $payload['scope'] ?? null;
            $key_raw = $payload['key'] ?? '';
            $value = $payload['value'] ?? null;

            if (empty($scope) || !in_array($scope, ['user_meta', 'bot_context'], true)) {
                return new WP_Error('invalid_variable_scope', __('Invalid or missing scope for set_variable action.', 'gpt3-ai-content-generator'));
            }

            $key = sanitize_key((string) $key_raw);
            if ($key === '') {
                return new WP_Error('invalid_variable_key', __('Invalid or missing key for set_variable action.', 'gpt3-ai-content-generator'));
            }

            $processed_value = $value;
            if (is_string($value)) {
                $processed_value = aipkit_process_action_template($value, $context_data);
            }

            if ($scope === 'user_meta') {
                $user_id = isset($context_data['user_id']) ? (int) $context_data['user_id'] : 0;
                if ($user_id <= 0) {
                    return new WP_Error('missing_user_id', __('User ID is required to set user_meta.', 'gpt3-ai-content-generator'));
                }

                $meta_key = $key;
                if (!preg_match('/^_?aipkit_/', $meta_key)) {
                    $meta_key = '_aipkit_' . $meta_key;
                }

                update_user_meta($user_id, $meta_key, $processed_value);

                return [
                    'type'  => 'set_variable',
                    'scope' => 'user_meta',
                    'key'   => $meta_key,
                    'value' => $processed_value,
                ];
            }

            return [
                'type'  => 'set_variable',
                'scope' => 'bot_context',
                'key'   => $key,
                'value' => $processed_value,
            ];
        }
    }
}

if (!class_exists(AIPKit_Action_Store_Form_Submission::class)) {
    /**
     * AIPKit_Action_Store_Form_Submission
     *
     * Handles the 'store_form_submission' trigger action.
     * This action logs the submitted form data.
     */
    class AIPKit_Action_Store_Form_Submission {

        /**
         * Executes the 'store_form_submission' action.
         *
         * @param array $payload Payload for the action, e.g., ['log_message_format' => string].
         * @param array $context_data Contextual data from the event (e.g., form_id, submitted_data).
         * @param int   $bot_id Bot ID associated with the trigger.
         * @param LogStorage $log_storage Instance of LogStorage for logging.
         * @return array|WP_Error Action result or WP_Error on failure.
         */
        public function execute(array $payload, array $context_data, int $bot_id, LogStorage $log_storage) {

            $form_id = $context_data['form_id'] ?? null;
            $submitted_data = $context_data['submitted_data'] ?? []; // This is the key-value array of submitted data

            if (empty($form_id)) {
                return new WP_Error('missing_form_id_in_context', __('Form ID is missing in the trigger context for store_form_submission.', 'gpt3-ai-content-generator'));
            }

            $log_message_format_template = $payload['log_message_format'] ?? "Form '{{form_id}}' submitted by {{user_name}}. Data: {{form_submission_summary}}";

            $form_submission_summary_parts = [];
            if (empty($submitted_data)) {
                $form_submission_summary = "No data submitted.";
            } else {
                foreach ($submitted_data as $key => $value) {
                    // Sanitize key and value for display in the log message
                    $display_key = htmlspecialchars($key, ENT_QUOTES, 'UTF-8');
                    $display_value = is_array($value) ? implode(', ', array_map(function($v) { return htmlspecialchars($v, ENT_QUOTES, 'UTF-8'); }, $value)) : htmlspecialchars($value, ENT_QUOTES, 'UTF-8');
                    // Truncate long values for the summary message
                    if (mb_strlen($display_value) > 50) {
                        $display_value = mb_substr($display_value, 0, 47) . '...';
                    }
                    $form_submission_summary_parts[] = "{$display_key}: \"{$display_value}\"";
                }
                $form_submission_summary = implode('; ', $form_submission_summary_parts);
            }

            $context_data_for_placeholder = $context_data;
            $context_data_for_placeholder['form_submission_summary'] = $form_submission_summary;
            unset($context_data_for_placeholder['submitted_data_json']);


            $processed_log_message = AIPKit_Placeholder_Processor::process($log_message_format_template, $context_data_for_placeholder, 'log_summary');

            $base_log_data = [
                'bot_id'            => $context_data['bot_id'] ?? null,
                'user_id'           => $context_data['user_id'] ?? (get_current_user_id() ?: null),
                'session_id'        => $context_data['session_id'] ?? null,
                'conversation_uuid' => $context_data['conversation_uuid'] ?? null,
                'module'            => 'chat',
                'is_guest'          => !(isset($context_data['user_id']) && $context_data['user_id'] > 0),
                'role'              => $context_data['user_wp_role'] ?? ($context_data['user_roles'] ?? null),
                'ip_address'        => $context_data['client_ip'] ?? null,
            ];

            if (empty($base_log_data['bot_id']) || empty($base_log_data['conversation_uuid'])) {
                return new WP_Error('missing_chat_identifiers', __('Cannot associate form submission with a chat session.', 'gpt3-ai-content-generator'));
            }

            $log_data_for_storage = array_merge($base_log_data, [
                'message_role'    => 'system',
                'event_sub_type'  => 'trigger_log',
                'message_content' => $processed_log_message,
                'timestamp'       => time(),
                'ai_provider'     => 'TriggerSystem',
                'ai_model'        => 'StoreFormAction',
                'usage'           => null,
                'trigger_log_details' => [
                    'log_subtype' => 'form_submission_stored',
                    'trigger_id' => $context_data['current_trigger_id'] ?? 'unknown',
                    'trigger_name' => $context_data['current_trigger_name'] ?? 'unknown',
                    'event_name_processed' => $context_data['event_type'] ?? 'form_submitted',
                    'form_id' => $form_id,
                    'submitted_data_snapshot' => $submitted_data,
                ],
                'response_data'   => ['status' => 'form_data_logged_to_chat_session'],
            ]);

            $log_result = $log_storage->log_message($log_data_for_storage);

            if ($log_result === false) {
                return new WP_Error('form_log_failed', __('Failed to log form submission to chat.', 'gpt3-ai-content-generator'));
            }

            $return_value = [
                'type'    => 'form_data_logged_to_chat',
                'status'  => 'success',
                'form_id' => $form_id,
                'log_id'  => $log_result['log_id'] ?? null,
                'message_id' => $log_result['message_id'] ?? null,
            ];
            return $return_value;
        }
    }
}

if (!class_exists(AIPKit_Action_Display_Form::class)) {
    /**
     * AIPKit_Action_Display_Form
     *
     * Handles the 'display_form' trigger action.
     * Prepares the form definition for rendering on the frontend.
     */
    class AIPKit_Action_Display_Form {

        /**
         * Executes the 'display_form' action.
         *
         * @param array $payload Payload containing 'form_id', 'title', 'elements', 'submit_button_text'.
         * @param array $context_data Contextual data for placeholder replacement.
         * @param int   $bot_id Bot ID used to bind the form state to its conversation.
         * @return array|WP_Error Action result containing the processed form definition, or WP_Error on failure.
         */
        public function execute(array $payload, array $context_data, int $bot_id) {
            $form_definition_template = $payload ?? [];

            // Require elements, but form_id can be auto-generated if missing
            if (empty($form_definition_template['elements']) || !is_array($form_definition_template['elements'])) {
                return new WP_Error(
                    'invalid_form_payload',
                    __('Invalid or missing form elements in display_form action payload.', 'gpt3-ai-content-generator')
                );
            }

            $trigger_id = sanitize_key((string) ($context_data['current_trigger_id'] ?? ''));
            $conversation_uuid = sanitize_key((string) (
                $context_data['conversation_uuid']
                ?? ($context_data['base_log_data']['conversation_uuid'] ?? '')
            ));
            $user_id = absint($context_data['user_id'] ?? ($context_data['base_log_data']['user_id'] ?? 0));
            $session_id = $user_id > 0 ? '' : sanitize_text_field((string) (
                $context_data['session_id']
                ?? ($context_data['base_log_data']['session_id'] ?? '')
            ));
            $state_store = null;
            if (
                $trigger_id !== ''
                && $conversation_uuid !== ''
                && ($user_id > 0 || $session_id !== '')
                && class_exists(AIPKit_Conversation_Form_State_Store::class)
            ) {
                $state_store = new AIPKit_Conversation_Form_State_Store();
                $existing_state = $state_store->get_trigger_state(
                    $bot_id,
                    $user_id > 0 ? $user_id : null,
                    $session_id,
                    $conversation_uuid,
                    $trigger_id
                );
                if (is_array($existing_state) && ($existing_state['status'] ?? '') === 'completed') {
                    return [
                        'type' => 'display_form_skipped',
                        'trigger_id' => $trigger_id,
                        'reason' => 'already_completed',
                    ];
                }
                if (
                    is_array($existing_state)
                    && ($existing_state['status'] ?? '') === 'pending'
                    && !empty($existing_state['form_definition'])
                    && is_array($existing_state['form_definition'])
                ) {
                    return [
                        'type' => 'display_form',
                        'form_definition' => $existing_state['form_definition'],
                    ];
                }
            }

            $processed_form_definition = $form_definition_template; // Start with a copy

            // Auto-generate a unique form_id if not provided
            if (empty($processed_form_definition['form_id']) || !is_string($processed_form_definition['form_id'])) {
                $rand = function_exists('wp_generate_password') ? wp_generate_password(6, false, false) : substr(bin2hex(random_bytes(4)), 0, 6);
                $processed_form_definition['form_id'] = 'form_' . time() . '_' . strtolower($rand);
            }

            // Ensure PlaceholderProcessor class exists
            $placeholder_processor_exists = class_exists(AIPKit_Placeholder_Processor::class);

            $process_fn = $placeholder_processor_exists ? [AIPKit_Placeholder_Processor::class, 'process'] : function($text, $ctx) { return $text; };

            // Process placeholders in top-level form definition fields
            if (isset($processed_form_definition['title'])) {
                $processed_form_definition['title'] = call_user_func($process_fn, $processed_form_definition['title'], $context_data);
            }
            if (isset($processed_form_definition['submit_button_text'])) {
                $processed_form_definition['submit_button_text'] = call_user_func($process_fn, $processed_form_definition['submit_button_text'], $context_data);
            }
            $resume_user_message = '';
            $is_user_message_event = isset($context_data['event_type']) && $context_data['event_type'] === 'user_message_received';
            if ($is_user_message_event) {
                if (isset($context_data['user_message_text']) && is_string($context_data['user_message_text']) && trim($context_data['user_message_text']) !== '') {
                    $resume_user_message = $context_data['user_message_text'];
                } elseif (isset($context_data['final_user_message_for_ai']) && is_string($context_data['final_user_message_for_ai']) && trim($context_data['final_user_message_for_ai']) !== '') {
                    $resume_user_message = $context_data['final_user_message_for_ai'];
                }
            }
            $processed_form_definition['resume_after_submit'] = $resume_user_message !== '';
            if ($processed_form_definition['resume_after_submit']) {
                $processed_form_definition['resume_user_message'] = $resume_user_message;
            } else {
                unset($processed_form_definition['resume_user_message']);
            }
            if ($trigger_id !== '') {
                $processed_form_definition['trigger_id'] = $trigger_id;
            }
            $processed_form_definition['gate_message'] = __('Please complete this form to continue.', 'gpt3-ai-content-generator');

            // Process placeholders within form elements
            if (isset($processed_form_definition['elements']) && is_array($processed_form_definition['elements'])) {
                foreach ($processed_form_definition['elements'] as &$element) {
                    if (isset($element['label'])) {
                        $element['label'] = call_user_func($process_fn, $element['label'], $context_data);
                    }
                    if (isset($element['placeholder'])) {
                        $element['placeholder'] = call_user_func($process_fn, $element['placeholder'], $context_data);
                    }
                    if (isset($element['help_text'])) {
                        $element['help_text'] = call_user_func($process_fn, $element['help_text'], $context_data);
                    }
                    // Process placeholders in options for select, radio_group, checkbox_group
                    if (isset($element['options']) && is_array($element['options'])) {
                        foreach ($element['options'] as &$option) {
                            if (isset($option['text'])) {
                                $option['text'] = call_user_func($process_fn, $option['text'], $context_data);
                            }
                            // Note: 'value' in options is usually not processed for placeholders as it's for backend logic
                        }
                        unset($option); // Unset reference
                    }
                     // Process default_value if it's a string
                    if (isset($element['default_value']) && is_string($element['default_value'])) {
                        $element['default_value'] = call_user_func($process_fn, $element['default_value'], $context_data);
                    }
                }
                unset($element); // Unset reference
            }

            if (
                $state_store instanceof AIPKit_Conversation_Form_State_Store
                && !$state_store->mark_pending(
                    $bot_id,
                    $user_id > 0 ? $user_id : null,
                    $session_id,
                    $conversation_uuid,
                    $trigger_id,
                    $processed_form_definition
                )
            ) {
                return [
                    'type' => 'block_message',
                    'reason' => __('The required form could not be prepared. Please try again.', 'gpt3-ai-content-generator'),
                    'stop_ai' => true,
                    'block_further_triggers' => true,
                ];
            }

            return [
                'type'              => 'display_form', // Signals frontend to render a form
                'form_definition'   => $processed_form_definition,
            ];
        }
    }
}
