<?php

class MSLMS_ClassroomsReactAdmin {

	const APP_SLUG = 'react_classrooms';

	private const REACT_PAGES = array(
		'mslms_classrooms',
		'mslms_classroom_auditory',
	);

	public function __construct() {
		add_filter( 'masterstudy_lms_instructor_react_menu_items', array( $this, 'register_instructor_react_menu_items' ) );
		add_filter( 'masterstudy_lms_admin_react_allowed_app_slugs', array( $this, 'register_app_slug' ) );
		add_filter( 'masterstudy_lms_admin_react_app_settings_by_slug', array( $this, 'register_app_settings' ), 10, 2 );
		add_filter( 'masterstudy_lms_admin_react_can_access_settings', array( $this, 'can_access_settings' ), 10, 2 );
		add_action( 'admin_head', array( $this, 'remove_admin_notices' ), 1 );
	}

	public function register_instructor_react_menu_items( $items ) {
		$items['mslms_classroom_auditory'] = array(
			'page_title' => esc_html__( 'Classroom Auditory', 'masterstudy-lms-learning-management-system-pro' ),
			'menu_title' => esc_html__( 'Classroom Auditory', 'masterstudy-lms-learning-management-system-pro' ),
			'capability' => 'stm_lms_instructor',
			'menu_slug'  => 'mslms_classroom_auditory',
			'icon_url'   => 'dashicons-groups',
			'position'   => 7,
			'app_slug'   => self::APP_SLUG,
		);

		$items['mslms_classrooms'] = array(
			'page_title' => esc_html__( 'Classrooms', 'masterstudy-lms-learning-management-system-pro' ),
			'menu_title' => esc_html__( 'Classrooms', 'masterstudy-lms-learning-management-system-pro' ),
			'capability' => 'stm_lms_instructor',
			'menu_slug'  => 'mslms_classrooms',
			'icon_url'   => 'dashicons-groups',
			'position'   => 20,
			'app_slug'   => self::APP_SLUG,
		);

		return $items;
	}

	public function register_app_slug( $app_slugs ) {
		$app_slugs[] = self::APP_SLUG;

		return array_values( array_unique( $app_slugs ) );
	}

	public function register_app_settings( $app_settings, $app_slug ) {
		if ( self::APP_SLUG !== $app_slug ) {
			return $app_settings;
		}

		return array();
	}

	public function can_access_settings( $can_access, $app_slug ) {
		if ( self::APP_SLUG !== $app_slug ) {
			return $can_access;
		}

		return current_user_can( 'manage_options' ) || current_user_can( 'stm_lms_instructor' );
	}

	public function remove_admin_notices() {
		$current_page = sanitize_text_field( wp_unslash( $_GET['page'] ?? '' ) );

		if ( ! in_array( $current_page, self::REACT_PAGES, true ) ) {
			return;
		}

		remove_all_actions( 'admin_notices' );
		remove_all_actions( 'all_admin_notices' );
	}
}
