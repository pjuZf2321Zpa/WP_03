<?php

namespace WPAICG\Lib\KnowledgeBase;

use WPAICG\AIPKit_Role_Manager;
use WP_Error;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Shared authorization and error handling for Pro reindex requests.
 */
final class AIPKit_Knowledge_Reindex_Request_Guard
{
    public const NONCE_ACTION = 'aipkit_knowledge_reindex_nonce';

    /**
     * @return bool|WP_Error
     */
    public static function verify()
    {
        if (!check_ajax_referer(self::NONCE_ACTION, '_ajax_nonce', false)) {
            return new WP_Error(
                'nonce_failure',
                __('Security check failed (nonce).', 'gpt3-ai-content-generator'),
                ['status' => 403]
            );
        }

        $is_pro = class_exists('\\WPAICG\\aipkit_dashboard')
            && \WPAICG\aipkit_dashboard::is_pro_plan();
        if (!$is_pro) {
            return new WP_Error(
                'aipkit_pro_required',
                __('A Pro plan is required to update indexed knowledge sources.', 'gpt3-ai-content-generator'),
                ['status' => 403]
            );
        }

        if (
            !AIPKit_Role_Manager::user_can_access_module('settings')
            && !AIPKit_Role_Manager::user_can_access_module('sources')
        ) {
            return new WP_Error(
                'permission_denied',
                __('You do not have permission to perform this action.', 'gpt3-ai-content-generator'),
                ['status' => 403]
            );
        }

        return true;
    }

    public static function send_error(WP_Error $error): void
    {
        $details = $error->get_error_data();
        $status = is_array($details) && isset($details['status']) ? (int) $details['status'] : 400;

        wp_send_json_error([
            'message' => $error->get_error_message(),
            'code' => $error->get_error_code(),
        ], $status);
    }
}

/**
 * Handles Pro stale-source status and bulk queue requests.
 */
final class AIPKit_Knowledge_Reindex_Ajax_Handler
{
    public function handle(): void
    {
        $verified = AIPKit_Knowledge_Reindex_Request_Guard::verify();
        if (is_wp_error($verified)) {
            AIPKit_Knowledge_Reindex_Request_Guard::send_error($verified);
            return;
        }

        // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Verified by the shared request guard above.
        $request = wp_unslash($_POST);
        $operation = sanitize_key((string) ($request['operation'] ?? 'status'));

        if ($operation === 'status') {
            $this->send_status($request);
            return;
        }

        if ($operation === 'enqueue') {
            $this->enqueue($request);
            return;
        }

        AIPKit_Knowledge_Reindex_Request_Guard::send_error(new WP_Error(
            'invalid_knowledge_reindex_operation',
            __('Invalid reindex operation.', 'gpt3-ai-content-generator')
        ));
    }

    /** @param array<mixed> $request */
    private function send_status(array $request): void
    {
        $post_types = $this->parse_post_types($request['post_types'] ?? []);
        $sync = AIPKit_Knowledge_Source_State_Store::sync_next_batch(500);

        wp_send_json_success([
            'summaries' => AIPKit_Knowledge_Source_State_Store::get_summaries($post_types),
            'sync' => $sync,
        ]);
    }

    /** @param array<mixed> $request */
    private function enqueue(array $request): void
    {
        $post_type = sanitize_key((string) ($request['post_type'] ?? ''));
        if ($post_type === '' || !post_type_exists($post_type) || $post_type === 'attachment') {
            AIPKit_Knowledge_Reindex_Request_Guard::send_error(new WP_Error(
                'invalid_knowledge_reindex_post_type',
                __('Invalid content type.', 'gpt3-ai-content-generator')
            ));
            return;
        }

        $sync = AIPKit_Knowledge_Source_State_Store::sync_next_batch(500);
        if (!empty($sync['remaining'])) {
            AIPKit_Knowledge_Reindex_Request_Guard::send_error(new WP_Error(
                'knowledge_reindex_sync_in_progress',
                __('Source status is still being prepared. Please wait a moment and try again.', 'gpt3-ai-content-generator'),
                ['status' => 409]
            ));
            return;
        }

        $queued = AIPKit_Knowledge_Source_State_Store::queue_stale($post_type);
        if ($queued > 0) {
            AIPKit_Knowledge_Reindex_Worker::schedule();
        }

        wp_send_json_success([
            'queued' => $queued,
            'summaries' => AIPKit_Knowledge_Source_State_Store::get_summaries([$post_type]),
            'sync' => $sync,
        ]);
    }

    /**
     * @param mixed $raw_post_types
     * @return string[]
     */
    private function parse_post_types($raw_post_types): array
    {
        if (is_string($raw_post_types)) {
            $decoded = json_decode($raw_post_types, true);
            $raw_post_types = is_array($decoded) ? $decoded : [];
        }
        if (!is_array($raw_post_types)) {
            return [];
        }

        $post_types = [];
        foreach ($raw_post_types as $post_type) {
            $post_type = sanitize_key(is_scalar($post_type) ? (string) $post_type : '');
            if ($post_type !== '' && $post_type !== 'attachment' && post_type_exists($post_type)) {
                $post_types[] = $post_type;
            }
        }

        return array_values(array_unique($post_types));
    }
}
