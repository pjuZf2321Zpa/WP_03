<?php

namespace MasterStudy\Lms\Pro\AddonsPlus\GoogleMeet\Repositories;

use MasterStudy\Lms\Plugin\PostType;
use MasterStudy\Lms\Repositories\CurriculumRepository;
use RuntimeException;
use WP_Query;
use WP_User;

final class GoogleMeetAdminRepository {
	private const ERROR_BAD_REQUEST = 400;
	private const ERROR_FORBIDDEN   = 403;
	private const MAX_PER_PAGE      = 100;
	private const ALLOWED_STATUSES  = array( 'publish', 'pending', 'draft', 'trash', 'private' );
	private const START_DATE_KEY    = 'stm_gma_start_date';
	private const END_DATE_KEY      = 'stm_gma_end_date';
	private const START_TIME_KEY    = 'stm_gma_start_time';
	private const END_TIME_KEY      = 'stm_gma_end_time';
	private const TIMEZONE_KEY      = 'stm_gma_timezone';
	private const VISIBILITY_KEY    = 'stm_gma_visibility';
	private const ATTENDEES_KEY     = 'stm_gma_attendees';
	private const MEETING_URL_KEY   = 'google_meet_link';
	private const META_KEYS         = array(
		self::START_DATE_KEY,
		self::END_DATE_KEY,
		self::START_TIME_KEY,
		self::END_TIME_KEY,
		self::TIMEZONE_KEY,
		self::VISIBILITY_KEY,
		self::ATTENDEES_KEY,
		self::MEETING_URL_KEY,
		'start_date',
		'end_date',
		'start_time',
		'end_time',
		'timezone',
		'visibility',
		'attendees',
	);

	public function get_list( array $params ): array {
		$post_type_object = get_post_type_object( PostType::GOOGLE_MEET );

		if ( empty( $post_type_object ) || ! current_user_can( $post_type_object->cap->edit_posts ) ) {
			throw new RuntimeException(
				esc_html__( 'You do not have permission to view meetings.', 'masterstudy-lms-learning-management-system' ),
				self::ERROR_FORBIDDEN
			);
		}

		$per_page = min( self::MAX_PER_PAGE, max( 1, (int) ( $params['per_page'] ?? 10 ) ) );
		$page     = max( 1, (int) ( $params['page'] ?? 1 ) );
		$search   = isset( $params['search'] ) ? trim( (string) $params['search'] ) : '';
		$status   = isset( $params['status'] ) ? (string) $params['status'] : 'any';

		$query_args = array(
			'post_type'              => PostType::GOOGLE_MEET,
			'post_status'            => 'any' === $status ? self::ALLOWED_STATUSES : $status,
			'ignore_sticky_posts'    => true,
			'posts_per_page'         => $per_page,
			'paged'                  => $page,
			'no_found_rows'          => false,
			'update_post_meta_cache' => false,
			'update_post_term_cache' => false,
		);

		if ( '' !== $search ) {
			$query_args['s'] = $search;
		}

		$date_range     = isset( $params['date_range'] ) ? trim( (string) $params['date_range'] ) : '';
		$has_date_range = false;

		if ( '' !== $date_range ) {
			$range = $this->parse_date_range( $date_range );

			if ( ! empty( $range ) ) {
				$has_date_range           = true;
				$query_args['meta_query'] = array(
					'relation' => 'OR',
					array(
						'relation' => 'AND',
						array(
							'key'     => self::END_DATE_KEY,
							'value'   => $range['from'],
							'compare' => '>=',
							'type'    => 'NUMERIC',
						),
						array(
							'key'     => self::START_DATE_KEY,
							'value'   => $range['to'],
							'compare' => '<=',
							'type'    => 'NUMERIC',
						),
					),
					array(
						'key'     => 'start_date',
						'value'   => array( $range['from'], $range['to'] ),
						'compare' => 'BETWEEN',
						'type'    => 'NUMERIC',
					),
				);
			}
		}

		if ( ! current_user_can( $post_type_object->cap->edit_others_posts ) ) {
			$query_args['author'] = get_current_user_id();
		}

		$sort = isset( $params['sort'] ) ? trim( (string) $params['sort'] ) : '';
		if ( '' !== $sort && class_exists( 'STM_LMS_Helpers' ) ) {
			$sort_params = \STM_LMS_Helpers::get_sort_params_by_string( $sort );
			$key         = $sort_params['key'] ?? '';
			$direction   = strtoupper( (string) ( $sort_params['direction'] ?? 'desc' ) );
			$direction   = in_array( $direction, array( 'ASC', 'DESC' ), true ) ? $direction : 'DESC';

			switch ( $key ) {
				case 'title':
					$query_args['orderby'] = 'title';
					$query_args['order']   = $direction;
					break;
				case 'meeting_date':
				default:
					$this->apply_meeting_date_ordering( $query_args, $direction, $has_date_range );
			}
		} else {
			$this->apply_meeting_date_ordering( $query_args, 'DESC', $has_date_range );
		}

		$query      = new WP_Query( $query_args );
		$post_ids   = wp_list_pluck( $query->posts, 'ID' );
		$counts     = ( new CurriculumRepository() )->get_course_counts_by_post_ids( $post_ids );
		$meta       = $this->get_meta_by_post_ids( $post_ids );
		$author_ids = wp_list_pluck( $query->posts, 'post_author' );
		$authors    = $this->get_author_labels_by_ids( $author_ids );

		foreach ( $query->posts as $post ) {
			$post_meta                  = $meta[ $post->ID ] ?? array();
			$post->linked_courses_count = (int) ( $counts[ $post->ID ] ?? 0 );
			$post->start_date           = $post_meta[ self::START_DATE_KEY ] ?? ( $post_meta['start_date'] ?? null );
			$post->end_date             = $post_meta[ self::END_DATE_KEY ] ?? ( $post_meta['end_date'] ?? null );
			$post->start_time           = $post_meta[ self::START_TIME_KEY ] ?? ( $post_meta['start_time'] ?? null );
			$post->end_time             = $post_meta[ self::END_TIME_KEY ] ?? ( $post_meta['end_time'] ?? null );
			$post->timezone             = $post_meta[ self::TIMEZONE_KEY ] ?? ( $post_meta['timezone'] ?? null );
			$post->visibility           = $post_meta[ self::VISIBILITY_KEY ] ?? ( $post_meta['visibility'] ?? 'default' );
			$post->attendees            = $post_meta[ self::ATTENDEES_KEY ] ?? ( $post_meta['attendees'] ?? null );
			$post->meeting_url          = $post_meta[ self::MEETING_URL_KEY ] ?? '';
			$post->author_label         = $authors[ (int) $post->post_author ] ?? '';
		}

		return array(
			'posts'              => $query->posts,
			'pages'              => (int) $query->max_num_pages,
			'current_page'       => $page,
			'total_google_meets' => (int) $query->found_posts,
		);
	}

	private function apply_meeting_date_ordering( array &$query_args, string $direction, bool $has_date_range ): void {
		if ( $has_date_range ) {
			$query_args['meta_key'] = self::START_DATE_KEY;
			$query_args['orderby']  = 'meta_value_num';
			$query_args['order']    = $direction;

			return;
		}

		$query_args['meta_query'] = array(
			'relation'             => 'OR',
			'meeting_date_exists'  => array(
				'key'     => self::START_DATE_KEY,
				'compare' => 'EXISTS',
				'type'    => 'NUMERIC',
			),
			'meeting_date_missing' => array(
				'key'     => self::START_DATE_KEY,
				'compare' => 'NOT EXISTS',
			),
		);
		$query_args['orderby']    = array(
			'meeting_date_exists' => $direction,
			'date'                => 'DESC',
		);
	}

	public function bulk_delete( array $google_meets ): void {
		$post_type_object = get_post_type_object( PostType::GOOGLE_MEET );

		if ( empty( $post_type_object ) || ! current_user_can( $post_type_object->cap->edit_posts ) ) {
			throw new RuntimeException(
				esc_html__( 'You do not have permission to delete meetings.', 'masterstudy-lms-learning-management-system' ),
				self::ERROR_FORBIDDEN
			);
		}

		foreach ( $google_meets as $google_meet ) {
			$meeting_id = $this->resolve_meeting_id( $google_meet );

			if ( ! $meeting_id || PostType::GOOGLE_MEET !== get_post_type( $meeting_id ) ) {
				throw new RuntimeException(
					esc_html__( 'Invalid meeting provided for bulk delete.', 'masterstudy-lms-learning-management-system' ),
					self::ERROR_BAD_REQUEST
				);
			}

			if ( ! current_user_can( 'delete_post', $meeting_id ) ) {
				throw new RuntimeException(
					esc_html__( 'You do not have permission to delete this meeting.', 'masterstudy-lms-learning-management-system' ),
					self::ERROR_FORBIDDEN
				);
			}

			$result = wp_delete_post( $meeting_id, true );
			if ( false === $result || null === $result ) {
				throw new RuntimeException(
					sprintf(
						/* translators: %d: meeting ID. */
						esc_html__( 'Unable to delete meeting %d.', 'masterstudy-lms-learning-management-system' ),
						$meeting_id
					)
				);
			}
		}
	}

	private function parse_date_range( string $date_range ): array {
		$dates = array_map( 'trim', explode( ',', $date_range ) );
		$from  = $dates[0] ?? '';
		$to    = $dates[1] ?? '';

		if ( empty( $from ) && empty( $to ) ) {
			return array();
		}

		$timezone = new \DateTimeZone( 'UTC' );
		$result   = array(
			'from' => 0,
			'to'   => PHP_INT_MAX,
		);

		if ( ! empty( $from ) ) {
			$from_date      = new \DateTimeImmutable( $from . ' 00:00:00', $timezone );
			$result['from'] = $from_date->getTimestamp() * 1000;
		}

		if ( ! empty( $to ) ) {
			$to_date      = new \DateTimeImmutable( $to . ' 23:59:59', $timezone );
			$result['to'] = ( $to_date->getTimestamp() * 1000 ) + 999;
		}

		return $result;
	}

	private function resolve_meeting_id( $google_meet ): int {
		if ( is_numeric( $google_meet ) ) {
			return (int) $google_meet;
		}

		if ( is_array( $google_meet ) && isset( $google_meet['id'] ) ) {
			return (int) $google_meet['id'];
		}

		if ( is_object( $google_meet ) && isset( $google_meet->id ) ) {
			return (int) $google_meet->id;
		}

		return 0;
	}

	private function get_meta_by_post_ids( array $post_ids ): array {
		if ( empty( $post_ids ) ) {
			return array();
		}

		update_meta_cache( 'post', $post_ids );

		$rows = array();
		foreach ( $post_ids as $post_id ) {
			$post_id = (int) $post_id;

			foreach ( self::META_KEYS as $meta_key ) {
				$rows[ $post_id ][ $meta_key ] = get_post_meta( $post_id, $meta_key, true );
			}
		}

		return $rows;
	}

	private function get_author_labels_by_ids( array $author_ids ): array {
		$author_ids = array_values( array_unique( array_map( 'intval', $author_ids ) ) );
		if ( empty( $author_ids ) ) {
			return array();
		}

		$users  = get_users(
			array(
				'include' => $author_ids,
				'fields'  => array( 'ID', 'user_login', 'display_name' ),
			)
		);
		$labels = array();

		foreach ( $users as $user ) {
			if ( $user instanceof WP_User ) {
				$labels[ $user->ID ] = '' !== $user->display_name ? $user->display_name : $user->user_login;
			}
		}

		return $labels;
	}
}
