<?php

namespace WPAICG\SEO\Audit;

if (!defined('ABSPATH')) {
    exit;
}

class AIPKit_SEO_Audit_Focus_Keyword_Exists_Rule extends AIPKit_SEO_Audit_Abstract_Rule
{
    public function __construct()
    {
        parent::__construct('focus_keyword_exists', 'Focus keyword exists', 10, 'high', 'focus_keyword');
    }

    public function applies(array $draft, array $context = []): bool
    {
        if ($this->profile_is($context, 'aioseo')) {
            return false;
        }

        return $this->supports_focus_keyword($context);
    }

    public function evaluate(array $draft, array $context = []): array
    {
        return $this->focus_keyword($draft) !== ''
            ? $this->pass('Focus keyword is set.')
            : $this->fail('Add a focus keyword before auditing keyword placement.');
    }
}

class AIPKit_SEO_Audit_Focus_Keyword_In_Title_Rule extends AIPKit_SEO_Audit_Abstract_Rule
{
    public function __construct()
    {
        parent::__construct('focus_keyword_in_title', 'Focus keyword in title', 9, 'high', 'title');
    }

    public function applies(array $draft, array $context = []): bool
    {
        return $this->supports_focus_keyword($context) && $this->focus_keyword($draft) !== '';
    }

    public function evaluate(array $draft, array $context = []): array
    {
        $title = (string) ($draft['title'] ?? '');
        $keyword = $this->focus_keyword($draft);

        if ($this->profile_is($context, 'yoast')) {
            if ($this->starts_with_phrase($title, $keyword)) {
                return $this->pass('Focus keyphrase appears at the beginning of the SEO title.');
            }

            return $this->contains_phrase($title, $keyword)
                ? $this->warning('Move the exact focus keyphrase to the beginning of the SEO title.')
                : $this->fail('Use the exact focus keyphrase in the SEO title.');
        }

        if ($this->profile_is($context, 'rank_math')) {
            return $this->contains_phrase($title, $keyword)
                ? $this->pass('Focus keyword appears in the SEO title.')
                : $this->fail('Use the focus keyword in the SEO title.');
        }

        return $this->contains_phrase($title, $keyword)
            ? $this->pass('Focus keyword appears in the title.')
            : $this->fail('Use the focus keyword in the title.');
    }
}

class AIPKit_SEO_Audit_Focus_Keyword_In_Introduction_Rule extends AIPKit_SEO_Audit_Abstract_Rule
{
    public function __construct()
    {
        parent::__construct('focus_keyword_in_introduction', 'Focus keyword in introduction', 8, 'high', 'content');
    }

    public function applies(array $draft, array $context = []): bool
    {
        if ($this->profile_is($context, 'aioseo')) {
            return false;
        }

        return $this->supports_focus_keyword($context) && $this->focus_keyword($draft) !== '' && $this->word_count((string) ($draft['content'] ?? '')) > 0;
    }

    public function evaluate(array $draft, array $context = []): array
    {
        $content = (string) ($draft['content'] ?? '');
        $keyword = $this->focus_keyword($draft);
        if ($this->profile_is($context, 'yoast')) {
            $first_paragraph = $this->get_first_intro_paragraph($content);
            return $this->contains_phrase($first_paragraph, $keyword)
                ? $this->pass('Focus keyphrase appears in the first paragraph.')
                : $this->fail('Use the focus keyphrase in the first paragraph of the introduction.');
        }

        if ($this->profile_is($context, 'rank_math')) {
            return $this->rank_math_keyword_in_first_ten_percent($content, $keyword)
                ? $this->pass('Focus keyword appears in the first 10% of the content.')
                : $this->fail('Focus keyword does not appear in the first 10% of the content.');
        }

        $intro = $this->first_words($content, 120);
        return $this->contains_phrase($intro, $keyword)
            ? $this->pass('Focus keyword appears in the introduction.')
            : $this->fail('Use the focus keyword near the beginning of the article.');
    }

    private function get_first_intro_paragraph(string $content): string
    {
        $paragraphs = $this->get_paragraphs($content);
        if (!empty($paragraphs)) {
            return (string) $paragraphs[0];
        }

        return $this->first_words($content, 80);
    }

    private function rank_math_keyword_in_first_ten_percent(string $content, string $keyword): bool
    {
        $content_words = $this->extract_words($content);
        if (empty($content_words)) {
            return false;
        }

        if (count($content_words) > 400) {
            $content_words = array_slice($content_words, 0, max(1, (int) floor(count($content_words) * 0.1)));
        }

        $keyword_words = $this->extract_words($keyword);
        if (empty($keyword_words)) {
            return false;
        }

        return strpos(implode(' ', $content_words), implode(' ', $keyword_words)) !== false;
    }

    private function extract_words(string $text): array
    {
        $text = $this->normalized_text($this->clean_text($text));
        if ($text === '' || !preg_match_all('/[\p{L}\p{N}][\p{L}\p{N}\'-]*/u', $text, $matches)) {
            return [];
        }

        return $matches[0];
    }
}

class AIPKit_SEO_Audit_Focus_Keyword_In_Meta_Rule extends AIPKit_SEO_Audit_Abstract_Rule
{
    public function __construct()
    {
        parent::__construct('focus_keyword_in_meta_description', 'Focus keyword in meta description', 8, 'high', 'meta_description');
    }

    public function applies(array $draft, array $context = []): bool
    {
        if ($this->profile_is($context, 'aioseo')) {
            return false;
        }

        return $this->supports_focus_keyword($context) && $this->focus_keyword($draft) !== '' && trim((string) ($draft['meta_description'] ?? '')) !== '';
    }

    public function evaluate(array $draft, array $context = []): array
    {
        return $this->contains_phrase((string) ($draft['meta_description'] ?? ''), $this->focus_keyword($draft))
            ? $this->pass('Focus keyword appears in the meta description.')
            : $this->fail('Use the focus keyword in the meta description.');
    }
}

class AIPKit_SEO_Audit_Focus_Keyword_In_Heading_Rule extends AIPKit_SEO_Audit_Abstract_Rule
{
    public function __construct()
    {
        parent::__construct('focus_keyword_in_heading', 'Focus keyword in subheading', 5, 'medium', 'content');
    }

    public function applies(array $draft, array $context = []): bool
    {
        if ($this->profile_is($context, 'aioseo')) {
            return false;
        }

        return $this->supports_focus_keyword($context) && $this->focus_keyword($draft) !== '' && $this->word_count((string) ($draft['content'] ?? '')) >= 300;
    }

    public function evaluate(array $draft, array $context = []): array
    {
        $is_rank_math = $this->profile_is($context, 'rank_math');
        $headings = $this->get_headings((string) ($draft['content'] ?? ''), $is_rank_math ? [2, 3, 4, 5, 6] : [2, 3]);
        $matched_headings = 0;
        foreach ($headings as $heading) {
            if ($this->contains_phrase($heading, $this->focus_keyword($draft))) {
                $matched_headings++;
            }
        }

        if (!$this->profile_is($context, 'yoast')) {
            return $matched_headings > 0
                ? $this->pass('Focus keyword appears in a subheading.')
                : $this->fail($is_rank_math ? 'Use the focus keyword in at least one H2, H3, H4, H5, or H6 heading.' : 'Use the focus keyword in at least one H2 or H3 heading.');
        }

        $required_matches = $this->required_yoast_subheading_matches(count($headings));
        $heading_count = count($headings);
        if ($heading_count >= 3 && ($matched_headings / $heading_count) > 0.75) {
            return $this->fail('More than 75% of H2 and H3 subheadings include the focus keyphrase. Reduce exact-match usage in subheadings to avoid over-optimization.');
        }

        if ($matched_headings >= $required_matches) {
            return $this->pass('Focus keyphrase appears in enough H2 or H3 subheadings.');
        }

        return $this->fail(sprintf(
            'Use the focus keyphrase or a close variant in at least %d H2 or H3 subheadings.',
            $required_matches
        ));
    }

    private function required_yoast_subheading_matches(int $heading_count): int
    {
        if ($heading_count <= 2) {
            return 1;
        }

        if ($heading_count <= 5) {
            return 2;
        }

        return 3;
    }
}

class AIPKit_SEO_Audit_Focus_Keyword_In_Slug_Rule extends AIPKit_SEO_Audit_Abstract_Rule
{
    public function __construct()
    {
        parent::__construct('focus_keyword_in_slug', 'Focus keyword in URL slug', 5, 'medium', 'slug');
    }

    public function applies(array $draft, array $context = []): bool
    {
        $slug_enabled = isset($context['generate_seo_slug']) && (string) $context['generate_seo_slug'] === '1';
        return $this->supports_focus_keyword($context) && $this->focus_keyword($draft) !== '' && ($slug_enabled || trim((string) ($draft['slug'] ?? '')) !== '');
    }

    public function evaluate(array $draft, array $context = []): array
    {
        $slug = trim((string) ($draft['slug'] ?? ''));
        if ($slug === '') {
            return $this->fail('Generate or provide a URL slug that includes the focus keyword.');
        }

        return $this->contains_phrase(str_replace('-', ' ', $slug), $this->focus_keyword($draft))
            ? $this->pass('Focus keyword appears in the URL slug.')
            : $this->fail('Include the focus keyword in the URL slug.');
    }
}

class AIPKit_SEO_Audit_Meta_Description_Exists_Rule extends AIPKit_SEO_Audit_Abstract_Rule
{
    public function __construct()
    {
        parent::__construct('meta_description_exists', 'Meta description exists', 8, 'high', 'meta_description');
    }

    public function applies(array $draft, array $context = []): bool
    {
        return !$this->profile_is($context, 'aioseo');
    }

    public function evaluate(array $draft, array $context = []): array
    {
        return trim((string) ($draft['meta_description'] ?? '')) !== ''
            ? $this->pass('Meta description is set.')
            : $this->fail('Add a meta description.');
    }
}

class AIPKit_SEO_Audit_Focus_Keyword_Length_Rule extends AIPKit_SEO_Audit_Abstract_Rule
{
    public function __construct()
    {
        parent::__construct('focus_keyword_length', 'Focus keyphrase length', 4, 'medium', 'focus_keyword');
    }

    public function applies(array $draft, array $context = []): bool
    {
        if ($this->profile_in($context, ['rank_math', 'aioseo'])) {
            return false;
        }

        return $this->supports_focus_keyword($context) && $this->focus_keyword($draft) !== '';
    }

    public function evaluate(array $draft, array $context = []): array
    {
        $word_count = $this->word_count($this->focus_keyword($draft));
        if ($word_count >= 1 && $word_count <= 4) {
            return $this->pass('Focus keyphrase length is in a useful range.');
        }

        return $this->warning('Keep the focus keyphrase concise, usually 1-4 words.');
    }
}

class AIPKit_SEO_Audit_Meta_Description_Length_Rule extends AIPKit_SEO_Audit_Abstract_Rule
{
    public function __construct()
    {
        parent::__construct('meta_description_length', 'Meta description length', 6, 'medium', 'meta_description');
    }

    public function applies(array $draft, array $context = []): bool
    {
        if ($this->profile_in($context, ['rank_math', 'aioseo'])) {
            return false;
        }

        return trim((string) ($draft['meta_description'] ?? '')) !== '';
    }

    public function evaluate(array $draft, array $context = []): array
    {
        $length = $this->text_length((string) ($draft['meta_description'] ?? ''));
        if ($this->profile_is($context, 'yoast')) {
            if ($length >= 120 && $length <= 156) {
                return $this->pass('Meta description length is in the Yoast target range.');
            }
            if ($length < 120) {
                return $this->warning('Meta description is too short. Use 120-156 characters when possible.');
            }

            return $this->fail('Reduce the meta description to 156 characters or fewer.');
        }

        if ($this->profile_is($context, 'framework')) {
            if ($length >= 80 && $length <= 160) {
                return $this->pass('Meta description length matches The SEO Framework guidance.');
            }
            if (($length >= 45 && $length < 80) || ($length > 160 && $length <= 320)) {
                return $this->warning('The SEO Framework accepts this meta description length, but it is outside the strongest range.');
            }

            return $this->fail('Keep the meta description between 80 and 156 characters for The SEO Framework.');
        }

        if ($length >= 120 && $length <= 160) {
            return $this->pass('Meta description length is in the ideal range.');
        }
        if ($length >= 100 && $length <= 180) {
            return $this->warning('Meta description length is acceptable, but 120-156 characters is stronger.');
        }

        return $this->fail('Keep the meta description between 120 and 156 characters.');
    }
}

class AIPKit_SEO_Audit_Title_Length_Rule extends AIPKit_SEO_Audit_Abstract_Rule
{
    public function __construct()
    {
        parent::__construct('title_length', 'SEO title length', 6, 'medium', 'title');
    }

    public function applies(array $draft, array $context = []): bool
    {
        $profile = $this->profile($context);
        return !in_array($profile, ['yoast', 'rank_math', 'aioseo'], true);
    }

    public function evaluate(array $draft, array $context = []): array
    {
        if ($this->profile_is($context, 'framework')) {
            return $this->evaluate_framework($draft, $context);
        }

        $length = $this->text_length((string) ($draft['title'] ?? ''));
        if ($length >= 40 && $length <= 60) {
            return $this->pass('Title length is in the ideal range.');
        }
        if ($length >= 30 && $length <= 70) {
            return $this->warning('Title length is acceptable, but 40-60 characters is stronger.');
        }

        return $this->fail('Keep the title between 40 and 60 characters.');
    }

    private function evaluate_framework(array $draft, array $context): array
    {
        $title = $this->clean_text((string) ($draft['title'] ?? ''));
        $effective_title = $this->framework_effective_title($title, $context);
        $length = $this->text_length($effective_title);
        $estimated_width = $this->estimate_framework_title_pixel_width($effective_title);

        if ($length >= 35 && $length <= 65 && $estimated_width >= 280 && $estimated_width <= 500) {
            return $this->pass('SEO title length matches The SEO Framework guidance.');
        }

        if ($estimated_width > 500 && $estimated_width <= 600 && $length <= 75) {
            return $this->warning(sprintf(
                'The SEO title may be too wide in The SEO Framework after the site title is added. Shorten the post title to about %d characters or fewer, or remove the site title in TSF.',
                $this->framework_recommended_raw_title_limit($context)
            ));
        }

        if ($length >= 25 && $length <= 75 && $estimated_width >= 200 && $estimated_width <= 600) {
            return $this->warning('SEO title length is acceptable for The SEO Framework, but could be stronger.');
        }

        return $this->fail('Keep the SEO title between 35 and 65 characters and inside The SEO Framework pixel counter target.');
    }

    private function framework_effective_title(string $title, array $context): string
    {
        $remove_site_title = !empty($context['framework_remove_site_title']);
        if ($remove_site_title) {
            return $title;
        }

        $site_title = isset($context['site_title']) && is_scalar($context['site_title'])
            ? trim((string) $context['site_title'])
            : trim((string) get_bloginfo('name'));
        if ($site_title === '') {
            return $title;
        }

        return trim($title . ' - ' . $site_title);
    }

    private function framework_recommended_raw_title_limit(array $context): int
    {
        $site_title = isset($context['site_title']) && is_scalar($context['site_title'])
            ? trim((string) $context['site_title'])
            : trim((string) get_bloginfo('name'));
        $suffix_length = $site_title !== '' ? $this->text_length(' - ' . $site_title) : 0;

        return max(32, 58 - $suffix_length);
    }

    private function estimate_framework_title_pixel_width(string $title): int
    {
        if ($title === '') {
            return 0;
        }

        $width = 0.0;
        $chars = preg_split('//u', $title, -1, PREG_SPLIT_NO_EMPTY);
        if (!is_array($chars)) {
            $chars = str_split($title);
        }

        foreach ($chars as $char) {
            $width += $this->framework_title_char_width((string) $char);
        }

        return (int) round($width);
    }

    private function framework_title_char_width(string $char): float
    {
        if ($char === ' ') {
            return 5.0;
        }

        if (preg_match('/[MW]/u', $char) === 1) {
            return 17.0;
        }

        if (preg_match('/[A-Z]/u', $char) === 1) {
            return 12.5;
        }

        if (preg_match('/[0-9]/u', $char) === 1) {
            return 10.0;
        }

        if (preg_match('/[mw]/u', $char) === 1) {
            return 13.0;
        }

        if (preg_match('/[iljrtf]/u', $char) === 1) {
            return 5.5;
        }

        if (preg_match('/[-:;,.|]/u', $char) === 1) {
            return 5.0;
        }

        return 9.0;
    }
}

class AIPKit_SEO_Audit_Yoast_Title_Width_Rule extends AIPKit_SEO_Audit_Abstract_Rule
{
    public function __construct()
    {
        parent::__construct('yoast_seo_title_width', 'SEO title width', 4, 'medium', 'title');
    }

    public function applies(array $draft, array $context = []): bool
    {
        return $this->profile_is($context, 'yoast');
    }

    public function evaluate(array $draft, array $context = []): array
    {
        $length = $this->text_length((string) ($draft['title'] ?? ''));
        if ($length >= 35 && $length <= 65) {
            return $this->pass('SEO title width is in a strong range.');
        }
        if ($length >= 25 && $length <= 75) {
            return $this->warning('SEO title width is acceptable, but could be tighter.');
        }

        return $this->fail('Adjust the SEO title so it is not too short or too long.');
    }
}

class AIPKit_SEO_Audit_Rank_Math_Title_Start_Rule extends AIPKit_SEO_Audit_Abstract_Rule
{
    public function __construct()
    {
        parent::__construct('rank_math_title_start_with_keyword', 'Focus keyword at beginning of SEO title', 3, 'medium', 'title');
    }

    public function applies(array $draft, array $context = []): bool
    {
        return $this->profile_is($context, 'rank_math')
            && $this->focus_keyword($draft) !== ''
            && trim((string) ($draft['title'] ?? '')) !== '';
    }

    public function evaluate(array $draft, array $context = []): array
    {
        return $this->starts_with_phrase((string) ($draft['title'] ?? ''), $this->focus_keyword($draft))
            ? $this->pass('Focus keyword appears at the beginning of the SEO title.')
            : $this->fail('Move the focus keyword to the beginning of the SEO title.');
    }
}

class AIPKit_SEO_Audit_Rank_Math_Title_Number_Rule extends AIPKit_SEO_Audit_Abstract_Rule
{
    public function __construct()
    {
        parent::__construct('rank_math_title_has_number', 'Number in SEO title', 1, 'low', 'title');
    }

    public function applies(array $draft, array $context = []): bool
    {
        return $this->profile_is($context, 'rank_math')
            && trim((string) ($draft['title'] ?? '')) !== '';
    }

    public function evaluate(array $draft, array $context = []): array
    {
        return preg_match('/\d/u', (string) ($draft['title'] ?? '')) === 1
            ? $this->pass('SEO title includes a number.')
            : $this->fail('Add a relevant number to the SEO title.');
    }
}

class AIPKit_SEO_Audit_Rank_Math_Title_Power_Word_Rule extends AIPKit_SEO_Audit_Abstract_Rule
{
    public function __construct()
    {
        parent::__construct('rank_math_title_power_word', 'Power word in SEO title', 1, 'low', 'title');
    }

    public function applies(array $draft, array $context = []): bool
    {
        return $this->profile_is($context, 'rank_math')
            && trim((string) ($draft['title'] ?? '')) !== '';
    }

    public function evaluate(array $draft, array $context = []): array
    {
        $title = $this->normalized_text((string) ($draft['title'] ?? ''));
        foreach ($this->power_words() as $word) {
            if (preg_match('/(?<![\p{L}\p{N}])' . preg_quote($word, '/') . '(?![\p{L}\p{N}])/u', $title) === 1) {
                return $this->pass('SEO title includes a power word.');
            }
        }

        return $this->fail('Add one natural power word to the SEO title.');
    }

    private function power_words(): array
    {
        return [
            'best',
            'complete',
            'easy',
            'effective',
            'essential',
            'expert',
            'free',
            'new',
            'powerful',
            'proven',
            'simple',
            'smart',
            'top',
            'ultimate',
        ];
    }
}

class AIPKit_SEO_Audit_Rank_Math_Title_Sentiment_Rule extends AIPKit_SEO_Audit_Abstract_Rule
{
    public function __construct()
    {
        parent::__construct('rank_math_title_sentiment', 'Title sentiment', 1, 'low', 'title');
    }

    public function applies(array $draft, array $context = []): bool
    {
        return $this->profile_is($context, 'rank_math')
            && trim((string) ($draft['title'] ?? '')) !== '';
    }

    public function evaluate(array $draft, array $context = []): array
    {
        $title = $this->normalized_text((string) ($draft['title'] ?? ''));
        foreach ($this->sentiment_words() as $word) {
            if (preg_match('/(?<![\p{L}\p{N}])' . preg_quote($word, '/') . '(?![\p{L}\p{N}])/u', $title) === 1) {
                return $this->pass('SEO title has positive or negative sentiment.');
            }
        }

        return $this->fail('Add a natural positive or negative sentiment word to the SEO title.');
    }

    private function sentiment_words(): array
    {
        return [
            'amazing',
            'bad',
            'better',
            'best',
            'costly',
            'easy',
            'effective',
            'excellent',
            'fail',
            'great',
            'harmful',
            'mistake',
            'poor',
            'powerful',
            'proven',
            'simple',
            'smart',
            'strong',
            'terrible',
            'useful',
            'worst',
        ];
    }
}

class AIPKit_SEO_Audit_Rank_Math_Permalink_Length_Rule extends AIPKit_SEO_Audit_Abstract_Rule
{
    private const MAX_PERMALINK_LENGTH = 75;

    public function __construct()
    {
        parent::__construct('rank_math_permalink_length', 'URL length', 1, 'low', 'slug');
    }

    public function applies(array $draft, array $context = []): bool
    {
        return $this->profile_is($context, 'rank_math');
    }

    public function evaluate(array $draft, array $context = []): array
    {
        $slug = trim((string) ($draft['slug'] ?? ''));
        if ($slug === '') {
            return $this->fail('Add a short URL slug.');
        }

        $length = $this->text_length($this->permalink_for_slug($slug, $context));
        return $length <= self::MAX_PERMALINK_LENGTH
            ? $this->pass('URL length is within Rank Math guidance.')
            : $this->warning('Shorten the URL to 75 characters or fewer.');
    }

    private function permalink_for_slug(string $slug, array $context): string
    {
        $slug = trim(sanitize_title($slug), '/');
        if ($slug === '') {
            return '';
        }

        $base_url = isset($context['home_url']) ? esc_url_raw((string) $context['home_url']) : '';
        if ($base_url === '' && isset($context['site_url'])) {
            $base_url = esc_url_raw((string) $context['site_url']);
        }
        if ($base_url === '') {
            $base_url = home_url('/');
        }

        return rtrim((string) $base_url, '/') . '/' . $slug . '/';
    }
}

class AIPKit_SEO_Audit_Content_Length_Rule extends AIPKit_SEO_Audit_Abstract_Rule
{
    public function __construct()
    {
        parent::__construct('content_length', 'Content length', 8, 'high', 'content');
    }

    public function applies(array $draft, array $context = []): bool
    {
        $profile = $this->profile($context);
        return !in_array($profile, ['aioseo', 'framework'], true);
    }

    public function evaluate(array $draft, array $context = []): array
    {
        if ($this->profile_is($context, 'rank_math')) {
            return $this->evaluate_rank_math($draft);
        }

        $minimum = isset($context['min_words']) ? max(1, absint($context['min_words'])) : 300;
        $words = $this->word_count((string) ($draft['content'] ?? ''));
        if ($words >= $minimum) {
            return $this->pass('Content meets the minimum word count.');
        }
        if ($words >= max(1, (int) floor($minimum * 0.67))) {
            return $this->warning('Content is close to the minimum word count.');
        }

        return $this->fail(sprintf('Write at least %d words for this content.', $minimum));
    }

    private function evaluate_rank_math(array $draft): array
    {
        $words = $this->word_count((string) ($draft['content'] ?? ''));
        if ($words >= 2500) {
            return $this->pass('Content length earns full Rank Math credit.', ['score_fraction' => 1.0]);
        }

        if ($words >= 2000) {
            return $this->warning('Rank Math gives partial content-length credit below 2500 words.', ['score_fraction' => 5 / 8]);
        }

        if ($words >= 1500) {
            return $this->warning('Expand the article toward 2500+ words for full Rank Math content-length credit.', ['score_fraction' => 4 / 8]);
        }

        if ($words >= 1000) {
            return $this->warning('Rank Math gives limited content-length credit below 1500 words.', ['score_fraction' => 3 / 8]);
        }

        if ($words >= 600) {
            return $this->warning('Rank Math gives low content-length credit below 1000 words; expand toward 2500+ words.', ['score_fraction' => 2 / 8]);
        }

        return $this->fail('Write at least 600 words to avoid failing Rank Math content length, and aim for 2500+ words for full credit.', ['score_fraction' => 0.0]);
    }
}

class AIPKit_SEO_Audit_Paragraph_Length_Rule extends AIPKit_SEO_Audit_Abstract_Rule
{
    public function __construct()
    {
        parent::__construct('paragraph_length', 'Paragraph length', 5, 'medium', 'content');
    }

    public function applies(array $draft, array $context = []): bool
    {
        return !$this->profile_is($context, 'framework');
    }

    public function evaluate(array $draft, array $context = []): array
    {
        if ($this->profile_is($context, 'aioseo')) {
            return $this->evaluate_aioseo($draft);
        }

        $long_count = 0;
        foreach ($this->get_paragraphs((string) ($draft['content'] ?? '')) as $paragraph) {
            if ($this->word_count($paragraph) > 120) {
                $long_count++;
            }
        }

        if ($long_count === 0) {
            return $this->pass('Paragraph lengths are easy to scan.');
        }
        if ($long_count <= 2) {
            return $this->warning('A few paragraphs are longer than recommended.');
        }

        return $this->fail('Shorten long paragraphs so the article is easier to scan.');
    }

    private function evaluate_aioseo(array $draft): array
    {
        $paragraphs = $this->get_explicit_paragraphs((string) ($draft['content'] ?? ''));
        foreach ($paragraphs as $paragraph) {
            if ($this->word_count($paragraph) > 120) {
                return $this->fail('At least one paragraph is long. Consider using short paragraphs.', ['score_fraction' => 0.0]);
            }
        }

        return $this->pass('You are using short paragraphs.');
    }

    private function get_explicit_paragraphs(string $html): array
    {
        if (!preg_match_all('/<p[^>]*>(.*?)<\/p>/is', $html, $matches)) {
            return [];
        }

        return array_values(array_filter(array_map(function ($paragraph) {
            return $this->clean_text((string) $paragraph);
        }, $matches[1])));
    }
}

class AIPKit_SEO_Audit_Heading_Distribution_Rule extends AIPKit_SEO_Audit_Abstract_Rule
{
    public function __construct()
    {
        parent::__construct('heading_distribution', 'Subheading distribution', 5, 'medium', 'content');
    }

    public function applies(array $draft, array $context = []): bool
    {
        if ($this->profile_in($context, ['rank_math', 'aioseo', 'framework'])) {
            return false;
        }

        return $this->word_count((string) ($draft['content'] ?? '')) >= 300;
    }

    public function evaluate(array $draft, array $context = []): array
    {
        $words = $this->word_count((string) ($draft['content'] ?? ''));
        $heading_count = count($this->get_headings((string) ($draft['content'] ?? '')));
        $recommended = max(1, (int) floor($words / 500));

        if ($heading_count >= $recommended) {
            return $this->pass('Subheadings are distributed through the article.');
        }
        if ($heading_count > 0) {
            return $this->warning('Add another H2 or H3 to break up longer sections.');
        }

        return $this->fail('Add H2 or H3 subheadings to structure the article.');
    }
}

class AIPKit_SEO_Audit_Rank_Math_TOC_Rule extends AIPKit_SEO_Audit_Abstract_Rule
{
    public function __construct()
    {
        parent::__construct('rank_math_table_of_contents', 'Table of contents', 2, 'medium', 'content');
    }

    public function applies(array $draft, array $context = []): bool
    {
        return $this->profile_is($context, 'rank_math')
            && $this->word_count((string) ($draft['content'] ?? '')) > 0;
    }

    public function evaluate(array $draft, array $context = []): array
    {
        if (!empty($context['rank_math_has_toc_plugin'])) {
            return $this->pass('A table of contents plugin appears to be available.');
        }

        if (!empty($context['generate_toc']) && (string) $context['generate_toc'] === '1') {
            return $this->pass('AIPKit table of contents is enabled and will be saved with Rank Math-compatible markup.');
        }

        $content = (string) ($draft['content'] ?? '');
        return stripos($content, 'wp-block-rank-math-toc-block') !== false || stripos($content, 'aipkit-toc-list') !== false
            ? $this->pass('Content includes a table of contents block.')
            : $this->fail('Add a table of contents block for Rank Math content readability.');
    }
}

class AIPKit_SEO_Audit_Yoast_Consecutive_Sentence_Starts_Rule extends AIPKit_SEO_Audit_Abstract_Rule
{
    public function __construct()
    {
        parent::__construct('yoast_consecutive_sentence_starts', 'Consecutive sentences', 3, 'medium', 'content');
    }

    public function applies(array $draft, array $context = []): bool
    {
        return $this->profile_is($context, 'yoast')
            && $this->word_count((string) ($draft['content'] ?? '')) >= 100;
    }

    public function evaluate(array $draft, array $context = []): array
    {
        $sentences = $this->get_sentences((string) ($draft['content'] ?? ''));
        $previous_word = '';
        $current_run = 0;
        $longest_run = 0;
        $longest_word = '';

        foreach ($sentences as $sentence) {
            $first_word = $this->get_sentence_first_word($sentence);
            if ($first_word === '') {
                $previous_word = '';
                $current_run = 0;
                continue;
            }

            if ($first_word === $previous_word) {
                $current_run++;
            } else {
                $previous_word = $first_word;
                $current_run = 1;
            }

            if ($current_run > $longest_run) {
                $longest_run = $current_run;
                $longest_word = $first_word;
            }
        }

        if ($longest_run < 3) {
            return $this->pass('Sentence openings are varied.');
        }

        return $this->fail(sprintf(
            'The text contains %d consecutive sentences starting with "%s". Try to mix things up.',
            $longest_run,
            ucfirst($longest_word)
        ));
    }
}

class AIPKit_SEO_Audit_Yoast_Transition_Words_Rule extends AIPKit_SEO_Audit_Abstract_Rule
{
    private const MINIMUM_PERCENTAGE = 30.0;
    private const WARNING_PERCENTAGE = 20.0;

    public function __construct()
    {
        parent::__construct('yoast_transition_words', 'Transition words', 3, 'medium', 'content');
    }

    public function applies(array $draft, array $context = []): bool
    {
        return $this->profile_is($context, 'yoast')
            && $this->word_count((string) ($draft['content'] ?? '')) >= 100;
    }

    public function evaluate(array $draft, array $context = []): array
    {
        $sentences = array_values(array_filter($this->get_sentences((string) ($draft['content'] ?? '')), function ($sentence) {
            return $this->word_count((string) $sentence) >= 3;
        }));
        $sentence_count = count($sentences);

        if ($sentence_count < 5) {
            return $this->pass('Not enough sentences to assess transition word coverage.');
        }

        $transition_sentence_count = 0;
        foreach ($sentences as $sentence) {
            if ($this->sentence_has_transition_word($sentence)) {
                $transition_sentence_count++;
            }
        }

        $percentage = ($transition_sentence_count / max(1, $sentence_count)) * 100;
        $formatted_percentage = sprintf('%.1f%%', $percentage);

        if ($percentage >= self::MINIMUM_PERCENTAGE) {
            return $this->pass(sprintf('%s of the sentences contain transition words.', $formatted_percentage));
        }

        if ($percentage >= self::WARNING_PERCENTAGE) {
            return $this->warning(sprintf('Only %s of the sentences contain transition words. Use more of them.', $formatted_percentage));
        }

        return $this->fail(sprintf('Only %s of the sentences contain transition words. Use more transition words to improve flow.', $formatted_percentage));
    }

    private function sentence_has_transition_word(string $sentence): bool
    {
        $sentence = $this->normalized_text($this->clean_text($sentence));
        if ($sentence === '') {
            return false;
        }

        foreach ($this->transition_words() as $phrase) {
            $phrase = $this->normalized_text($phrase);
            if ($phrase === '') {
                continue;
            }

            $phrase_pattern = preg_replace('/\s+/', '\\s+', preg_quote($phrase, '/'));
            if (preg_match('/(?<![\p{L}\p{N}])' . $phrase_pattern . '(?![\p{L}\p{N}])/u', $sentence)) {
                return true;
            }
        }

        return false;
    }

    private function transition_words(): array
    {
        return [
            'above all',
            'accordingly',
            'additionally',
            'after all',
            'afterward',
            'also',
            'although',
            'as a result',
            'because',
            'before',
            'besides',
            'but',
            'consequently',
            'conversely',
            'despite',
            'equally important',
            'especially',
            'finally',
            'first',
            'for example',
            'for instance',
            'for this reason',
            'furthermore',
            'however',
            'in addition',
            'in conclusion',
            'in contrast',
            'in fact',
            'in particular',
            'in short',
            'indeed',
            'instead',
            'likewise',
            'meanwhile',
            'moreover',
            'nevertheless',
            'next',
            'nonetheless',
            'notably',
            'on the other hand',
            'otherwise',
            'overall',
            'second',
            'similarly',
            'since',
            'so',
            'specifically',
            'still',
            'subsequently',
            'therefore',
            'though',
            'thus',
            'to summarize',
            'ultimately',
            'whereas',
            'while',
        ];
    }
}

abstract class AIPKit_SEO_Audit_Yoast_Readability_Rule extends AIPKit_SEO_Audit_Abstract_Rule
{
    public function applies(array $draft, array $context = []): bool
    {
        return $this->profile_is($context, 'yoast')
            && $this->word_count((string) ($draft['content'] ?? '')) >= 100;
    }

    protected function get_readability_sentences(string $content): array
    {
        $sentences = [];
        foreach ($this->get_paragraphs($content) as $paragraph) {
            foreach ($this->get_sentences((string) $paragraph) as $sentence) {
                if ($this->word_count((string) $sentence) >= 3) {
                    $sentences[] = (string) $sentence;
                }
            }
        }

        if (!empty($sentences)) {
            return $sentences;
        }

        return array_values(array_filter($this->get_sentences($content), function ($sentence) {
            return $this->word_count((string) $sentence) >= 3;
        }));
    }

    protected function format_percentage(float $percentage): string
    {
        return sprintf('%.0f%%', round($percentage));
    }
}

class AIPKit_SEO_Audit_Yoast_Sentence_Length_Rule extends AIPKit_SEO_Audit_Yoast_Readability_Rule
{
    private const RECOMMENDED_WORD_LIMIT = 20;
    private const SLIGHTLY_TOO_MANY_PERCENTAGE = 23.0;
    private const FAR_TOO_MANY_PERCENTAGE = 30.0;

    public function __construct()
    {
        parent::__construct('yoast_sentence_length', 'Sentence length', 3, 'medium', 'content');
    }

    public function evaluate(array $draft, array $context = []): array
    {
        $sentences = array_values(array_filter($this->get_sentences((string) ($draft['content'] ?? '')), function ($sentence) {
            return $this->word_count((string) $sentence) >= 3;
        }));
        if (empty($sentences)) {
            return $this->pass('Sentence length is looking great.');
        }

        $long_sentences = 0;
        foreach ($sentences as $sentence) {
            if ($this->word_count((string) $sentence) > self::RECOMMENDED_WORD_LIMIT) {
                $long_sentences++;
            }
        }

        $percentage = ($long_sentences / max(1, count($sentences))) * 100;
        if ($percentage <= self::SLIGHTLY_TOO_MANY_PERCENTAGE) {
            return $this->pass('Sentence length is looking great.');
        }

        $message = sprintf(
            '%s of the sentences contain more than %d words. Shorten or split long sentences.',
            $this->format_percentage($percentage),
            self::RECOMMENDED_WORD_LIMIT
        );

        if ($percentage <= self::FAR_TOO_MANY_PERCENTAGE) {
            return $this->warning($message, ['score_fraction' => 6 / 9]);
        }

        return $this->fail($message, ['score_fraction' => 3 / 9]);
    }
}

class AIPKit_SEO_Audit_Yoast_Passive_Voice_Rule extends AIPKit_SEO_Audit_Yoast_Readability_Rule
{
    private const RECOMMENDED_MAXIMUM_PERCENTAGE = 10.0;
    private const FAR_TOO_MANY_PERCENTAGE = 15.0;

    public function __construct()
    {
        parent::__construct('yoast_passive_voice', 'Passive voice', 3, 'medium', 'content');
    }

    public function evaluate(array $draft, array $context = []): array
    {
        $sentences = $this->get_readability_sentences((string) ($draft['content'] ?? ''));
        if (empty($sentences)) {
            return $this->pass('You are not using too much passive voice.');
        }

        $passive_count = 0;
        foreach ($sentences as $sentence) {
            if ($this->sentence_has_passive_voice((string) $sentence)) {
                $passive_count++;
            }
        }

        $percentage = ($passive_count / max(1, count($sentences))) * 100;
        if ($percentage <= self::RECOMMENDED_MAXIMUM_PERCENTAGE) {
            return $this->pass('You are not using too much passive voice.');
        }

        $message = sprintf(
            '%s of the sentences contain passive voice. Rewrite passive constructions in active voice where natural.',
            $this->format_percentage($percentage)
        );

        if ($percentage <= self::FAR_TOO_MANY_PERCENTAGE) {
            return $this->warning($message, ['score_fraction' => 6 / 9]);
        }

        return $this->fail($message, ['score_fraction' => 3 / 9]);
    }

    private function sentence_has_passive_voice(string $sentence): bool
    {
        $sentence = $this->clean_text($sentence);
        if ($sentence === '') {
            return false;
        }

        $participle = '(?:[\p{L}]{3,}(?:ed|en|wn|lt|nt)|known|seen|made|built|held|given|taken|written|driven|drawn|shown|found|lost|left|felt|kept|set|put|cut|paid|said|told|born|done|used)';
        return preg_match('/\b(?:am|are|be|been|being|is|was|were|get|gets|got|getting)(?:\s+(?:not|never|also|already|always|currently|directly|easily|eventually|frequently|generally|often|quickly|rarely|sometimes|still|then|too|well|widely|usually)){0,3}\s+' . $participle . '\b/iu', $sentence) === 1;
    }
}

class AIPKit_SEO_Audit_Internal_Link_Rule extends AIPKit_SEO_Audit_Abstract_Rule
{
    public function __construct()
    {
        parent::__construct('internal_link_exists', 'Internal link exists', 4, 'medium', 'content');
    }

    public function applies(array $draft, array $context = []): bool
    {
        if ($this->profile_in($context, ['aioseo', 'framework'])) {
            return false;
        }

        return $this->word_count((string) ($draft['content'] ?? '')) >= 300;
    }

    public function evaluate(array $draft, array $context = []): array
    {
        $invalid_internal_count = 0;
        $valid_internal_count = 0;

        foreach ($this->get_link_details((string) ($draft['content'] ?? '')) as $link) {
            $href = (string) ($link['href'] ?? '');
            if (!$this->is_internal_href($href, $context)) {
                continue;
            }

            if ($this->internal_href_resolves($href, $context)) {
                $valid_internal_count++;
                continue;
            }

            $invalid_internal_count++;
        }

        if ($invalid_internal_count > 0 && $valid_internal_count > 0) {
            return $this->warning('Remove or replace internal links that do not point to existing published content.');
        }

        if ($invalid_internal_count > 0) {
            return $this->fail('Internal links must point to existing published content.');
        }

        if ($valid_internal_count > 0) {
            return $this->pass('Article includes a verified internal link.');
        }

        return $this->fail('No internal links appear in this draft. Add at least one relevant internal link.');
    }
}

class AIPKit_SEO_Audit_External_Link_Rule extends AIPKit_SEO_Audit_Abstract_Rule
{
    public function __construct()
    {
        parent::__construct('external_link_exists', 'External link exists', 3, 'low', 'content');
    }

    public function applies(array $draft, array $context = []): bool
    {
        if ($this->profile_in($context, ['aioseo', 'framework'])) {
            return false;
        }

        return $this->word_count((string) ($draft['content'] ?? '')) >= 300;
    }

    public function evaluate(array $draft, array $context = []): array
    {
        $outbound_count = 0;
        $nofollow_outbound_count = 0;
        $unsafe_outbound_count = 0;
        foreach ($this->get_link_details((string) ($draft['content'] ?? '')) as $link) {
            $href = (string) ($link['href'] ?? '');
            if (!$this->is_external_href($href, $context)) {
                continue;
            }

            if (!$this->is_safe_outbound_href($href, $context)) {
                $unsafe_outbound_count++;
                continue;
            }

            $outbound_count++;
            if ($this->link_has_rel((string) ($link['rel'] ?? ''), 'nofollow')) {
                $nofollow_outbound_count++;
                continue;
            }

            return $this->pass('Article includes a safe external link.');
        }

        if ($this->profile_is($context, 'yoast')) {
            if ($unsafe_outbound_count > 0 && $outbound_count === 0) {
                return $this->fail('Outbound links must use reputable absolute HTTPS URLs.');
            }

            if ($outbound_count > 0 && $nofollow_outbound_count === $outbound_count) {
                return $this->warning('All outbound links are nofollowed. Add at least one normal outbound link.');
            }

            return $this->fail('No outbound links appear in this draft. Add at least one relevant outbound link.');
        }

        if ($unsafe_outbound_count > 0 && $outbound_count === 0) {
            return $this->warning('Use a reputable absolute HTTPS outbound link when it helps the reader.');
        }

        return $this->warning('Add a relevant outbound link when it helps the reader.');
    }
}

class AIPKit_SEO_Audit_Image_Exists_Rule extends AIPKit_SEO_Audit_Abstract_Rule
{
    public function __construct()
    {
        parent::__construct('image_exists', 'Images', 4, 'medium', 'content', false);
    }

    public function applies(array $draft, array $context = []): bool
    {
        return $this->profile_is($context, 'yoast');
    }

    public function evaluate(array $draft, array $context = []): array
    {
        return count($this->get_images($draft)) > 0
            ? $this->pass('The draft includes at least one image.')
            : $this->fail('Add at least one image to the draft.');
    }
}

class AIPKit_SEO_Audit_Rank_Math_Content_Assets_Rule extends AIPKit_SEO_Audit_Abstract_Rule
{
    public function __construct()
    {
        parent::__construct('rank_math_content_assets', 'Images or videos', 6, 'medium', 'content', false);
    }

    public function applies(array $draft, array $context = []): bool
    {
        return $this->profile_is($context, 'rank_math');
    }

    public function evaluate(array $draft, array $context = []): array
    {
        $image_count = count($this->get_images($draft));
        $video_count = $this->count_videos((string) ($draft['content'] ?? ''));
        $asset_score = min(6, $this->image_score($image_count) + $this->video_score($video_count));
        $score_fraction = $asset_score / 6;

        if ($asset_score >= 6) {
            return $this->pass('Content includes enough images or videos for full Rank Math media credit.', ['score_fraction' => 1.0]);
        }

        if ($asset_score > 0) {
            return $this->warning('Rank Math gives partial media credit unless the post has at least 4 images or enough video assets.', [
                'score_fraction' => $score_fraction,
                'fixable' => false,
            ]);
        }

        return $this->fail('Add images or videos to satisfy Rank Math content readability.', [
            'score_fraction' => 0.0,
            'fixable' => false,
        ]);
    }

    private function image_score(int $image_count): int
    {
        if ($image_count >= 4) {
            return 6;
        }

        switch ($image_count) {
            case 3:
                return 4;
            case 2:
                return 2;
            case 1:
                return 1;
            default:
                return 0;
        }
    }

    private function video_score(int $video_count): int
    {
        if ($video_count >= 2) {
            return 2;
        }

        return $video_count === 1 ? 1 : 0;
    }

    private function count_videos(string $content): int
    {
        $count = 0;
        $tag_patterns = [
            '/<video\b/i',
            '/<iframe\b[^>]*(?:youtube\.com|youtu\.be|vimeo\.com)[^>]*>/i',
            '/\[(?:video|embed)\b[^\]]*\]/i',
        ];

        foreach ($tag_patterns as $pattern) {
            if (preg_match_all($pattern, $content, $matches)) {
                $count += count($matches[0]);
            }
        }

        $plain_content = wp_strip_all_tags($content);
        if (preg_match_all('#https?://(?:www\.)?(?:youtube\.com/watch\?v=|youtu\.be/|vimeo\.com/)#i', $plain_content, $matches)) {
            $count += count($matches[0]);
        }

        return $count;
    }
}

class AIPKit_SEO_Audit_Image_Alt_Keyphrase_Rule extends AIPKit_SEO_Audit_Abstract_Rule
{
    public function __construct()
    {
        parent::__construct('keyphrase_in_image_alt', 'Keyphrase in image alt attributes', 4, 'medium', 'content');
    }

    public function applies(array $draft, array $context = []): bool
    {
        return $this->profile_in($context, ['yoast', 'rank_math'])
            && $this->focus_keyword($draft) !== '';
    }

    public function evaluate(array $draft, array $context = []): array
    {
        if ($this->profile_is($context, 'rank_math')) {
            return $this->evaluate_rank_math($draft);
        }

        $images = $this->get_images($draft);
        if (empty($images)) {
            return $this->fail('Add images with alt attributes that include the keyphrase or a close variant.', ['fixable' => false]);
        }

        foreach ($images as $image) {
            if ($this->alt_contains_enough_keyphrase_words((string) ($image['alt'] ?? ''), $this->focus_keyword($draft))) {
                return $this->pass('At least one image alt attribute includes enough words from the focus keyphrase.');
            }
        }

        return $this->warning('Images should have alt attributes with at least half of the words from the focus keyphrase.');
    }

    private function evaluate_rank_math(array $draft): array
    {
        $keyword = $this->focus_keyword($draft);
        $featured_alt = isset($draft['featured_image_alt']) ? (string) $draft['featured_image_alt'] : '';
        if ($this->rank_math_alt_matches_keyphrase($featured_alt, $keyword)) {
            return $this->pass('Focus keyword found in image alt attribute.');
        }

        foreach ($this->get_images($draft) as $image) {
            if ($this->rank_math_alt_matches_keyphrase((string) ($image['alt'] ?? ''), $keyword)) {
                return $this->pass('Focus keyword found in image alt attribute.');
            }
        }

        if (preg_match('/\[gallery( [^\]]+?)?\]/i', (string) ($draft['content'] ?? '')) === 1) {
            return $this->pass('A gallery is present; Rank Math assumes at least one gallery image has matching alt text.');
        }

        return $this->fail('Add an image with your Focus Keyword as alt text.');
    }

    private function rank_math_alt_matches_keyphrase(string $alt_text, string $keyphrase): bool
    {
        $alt_text = $this->normalized_text($this->clean_text($alt_text));
        $keyphrase = $this->normalized_text($this->clean_text($keyphrase));
        if ($alt_text === '' || $keyphrase === '') {
            return false;
        }

        if ($alt_text === $keyphrase || strpos($alt_text, $keyphrase) !== false) {
            return true;
        }

        $words = array_values(array_unique($this->extract_unique_words($keyphrase)));
        if (empty($words)) {
            return false;
        }

        $pattern = implode('.*', array_map(static function (string $word): string {
            return preg_quote($word, '/');
        }, $words));

        return preg_match('/' . $pattern . '/iu', $alt_text) === 1;
    }

    private function alt_contains_enough_keyphrase_words(string $alt_text, string $keyphrase): bool
    {
        $keyphrase_words = $this->extract_unique_words($keyphrase);
        if (empty($keyphrase_words)) {
            return false;
        }

        $alt_words = array_flip($this->extract_unique_words($alt_text));
        $matched_words = 0;
        foreach ($keyphrase_words as $word) {
            if (isset($alt_words[$word])) {
                $matched_words++;
            }
        }

        return $matched_words >= (int) ceil(count($keyphrase_words) / 2);
    }

    private function extract_unique_words(string $text): array
    {
        $text = $this->normalized_text($this->clean_text($text));
        if ($text === '') {
            return [];
        }

        if (!preg_match_all('/[\p{L}\p{N}][\p{L}\p{N}\'-]*/u', $text, $matches)) {
            return [];
        }

        return array_values(array_unique(array_filter($matches[0])));
    }
}

class AIPKit_SEO_Audit_Single_H1_Rule extends AIPKit_SEO_Audit_Abstract_Rule
{
    public function __construct()
    {
        parent::__construct('single_h1', 'Single title', 4, 'medium', 'content');
    }

    public function applies(array $draft, array $context = []): bool
    {
        return $this->profile_is($context, 'yoast');
    }

    public function evaluate(array $draft, array $context = []): array
    {
        $h1_count = $this->count_h1_headings((string) ($draft['content'] ?? ''));
        if ($h1_count <= 1) {
            return $this->pass('The draft does not contain multiple H1 headings.');
        }

        return $this->fail('Use only one H1 heading in the article content.');
    }
}

class AIPKit_SEO_Audit_Previously_Used_Keyphrase_Rule extends AIPKit_SEO_Audit_Abstract_Rule
{
    public function __construct()
    {
        parent::__construct('previously_used_keyphrase', 'Previously used keyphrase', 4, 'medium', 'focus_keyword');
    }

    public function applies(array $draft, array $context = []): bool
    {
        return $this->profile_in($context, ['yoast', 'rank_math'])
            && $this->focus_keyword($draft) !== ''
            && array_key_exists('used_focus_keyword_count', $context);
    }

    public function evaluate(array $draft, array $context = []): array
    {
        $count = max(0, absint($context['used_focus_keyword_count'] ?? 0));
        if ($count === 0) {
            return $this->pass('This focus keyphrase has not been used before.');
        }

        return $this->fail('This focus keyphrase appears to be used on another post.');
    }
}

class AIPKit_SEO_Audit_Competing_Links_Rule extends AIPKit_SEO_Audit_Abstract_Rule
{
    public function __construct()
    {
        parent::__construct('competing_links', 'Competing links', 3, 'low', 'content');
    }

    public function applies(array $draft, array $context = []): bool
    {
        return $this->profile_is($context, 'yoast')
            && $this->focus_keyword($draft) !== ''
            && $this->word_count((string) ($draft['content'] ?? '')) >= 100;
    }

    public function evaluate(array $draft, array $context = []): array
    {
        $keyword = $this->focus_keyword($draft);
        $normalized_keyword = $this->normalized_text($this->clean_text($keyword));
        $content = (string) ($draft['content'] ?? '');
        if (!preg_match_all('/<a\s[^>]*href=["\']([^"\']+)["\'][^>]*>(.*?)<\/a>/is', $content, $matches, PREG_SET_ORDER)) {
            return $this->pass('No links use the focus keyphrase as anchor text.');
        }

        foreach ($matches as $match) {
            $anchor_text = $this->normalized_text($this->clean_text((string) ($match[2] ?? '')));
            if ($anchor_text !== '' && $anchor_text === $normalized_keyword) {
                return $this->warning('Avoid using the focus keyphrase as anchor text for competing links.');
            }
        }

        return $this->pass('No links use the focus keyphrase as anchor text.');
    }
}

class AIPKit_SEO_Audit_Keyword_Density_Rule extends AIPKit_SEO_Audit_Abstract_Rule
{
    public function __construct()
    {
        parent::__construct('keyword_density', 'Keyword density', 5, 'medium', 'content');
    }

    public function applies(array $draft, array $context = []): bool
    {
        $profile = $this->profile($context);
        return $this->supports_focus_keyword($context)
            && !in_array($profile, ['rank_math', 'aioseo'], true)
            && $this->focus_keyword($draft) !== ''
            && $this->word_count((string) ($draft['content'] ?? '')) >= 100;
    }

    public function evaluate(array $draft, array $context = []): array
    {
        $content = $this->normalized_text($this->clean_text((string) ($draft['content'] ?? '')));
        $keyword = $this->normalized_text($this->focus_keyword($draft));
        $words = max(1, $this->word_count($content));
        $keyword_words = max(1, $this->word_count($keyword));
        $occurrences = $this->count_phrase_occurrences($content, $keyword);

        if ($this->profile_is($context, 'yoast')) {
            return $this->evaluate_yoast_density($words, $occurrences);
        }

        $density = ($occurrences * $keyword_words / $words) * 100;

        if ($density >= 0.5 && $density <= 2.5) {
            return $this->pass('Keyword density is balanced.');
        }
        if ($density >= 0.2 && $density <= 3.5) {
            return $this->warning('Keyword density is acceptable but could be more balanced.');
        }

        return $this->fail('Adjust keyword usage to keep density natural.');
    }

    private function evaluate_yoast_density(int $words, int $occurrences): array
    {
        $minimum = max(2, (int) floor($words * 0.005));
        $maximum = max($minimum, (int) floor($words * 0.025));
        $target_floor = max($minimum, (int) floor($words * 0.015));
        $target_ceiling = $maximum;
        $density = round(($occurrences / max(1, $words)) * 100, 2);

        if ($occurrences >= $minimum && $occurrences <= $maximum) {
            return $this->pass(sprintf(
                'Keyword density is balanced at %d exact matches across %d words.',
                $occurrences,
                $words
            ));
        }

        if ($occurrences < $minimum) {
            return $this->fail(sprintf(
                'Keyword density is %.2f%% with %d exact matches across %d words. Increase to at least %d exact focus-keyphrase matches for Yoast, without stuffing.',
                $density,
                $occurrences,
                $words,
                $minimum
            ));
        }

        return $this->fail(sprintf(
            'Keyword density is %.2f%% with %d exact matches across %d words. Reduce exact focus-keyphrase usage to about %d-%d total matches for Yoast; do not exceed %d exact matches.',
            $density,
            $occurrences,
            $words,
            $target_floor,
            $target_ceiling,
            $maximum
        ));
    }
}

class AIPKit_SEO_Audit_Rank_Math_Keyword_Density_Rule extends AIPKit_SEO_Audit_Abstract_Rule
{
    public function __construct()
    {
        parent::__construct('rank_math_keyword_density', 'Keyword density', 6, 'medium', 'content');
    }

    public function applies(array $draft, array $context = []): bool
    {
        return $this->profile_is($context, 'rank_math')
            && $this->focus_keyword($draft) !== ''
            && $this->word_count((string) ($draft['content'] ?? '')) >= 100;
    }

    public function evaluate(array $draft, array $context = []): array
    {
        $content = $this->normalized_text($this->clean_text((string) ($draft['content'] ?? '')));
        $keyword = $this->normalized_text($this->focus_keyword($draft));
        $words = max(1, $this->word_count($content));
        $occurrences = $this->count_phrase_occurrences($content, $keyword);
        $density = round(($occurrences / $words) * 100, 2);
        $target_occurrences = max($occurrences + 1, (int) ceil($words * 0.0105));
        $full_credit_min = max(1, (int) ceil($words * 0.01));
        $full_credit_max = max($full_credit_min, (int) floor($words * 0.015));
        $warning_max = max($full_credit_max, (int) floor($words * 0.025));
        $low_density_message = sprintf(
            'Keyword density is %.2f%% with %d exact matches across %d words; increase to about %d total exact focus-keyphrase matches for Rank Math full credit. Safe full-credit range: %d-%d matches. Do not exceed %d matches.',
            $density,
            $occurrences,
            $words,
            $target_occurrences,
            $full_credit_min,
            $full_credit_max,
            $warning_max
        );

        if ($density < 0.5) {
            return $this->fail($low_density_message, ['score_fraction' => 0.0]);
        }

        if ($density > 2.5) {
            return $this->fail(sprintf('Keyword density is %.2f%% with %d exact matches across %d words; reduce exact focus-keyphrase usage toward %d-%d total matches. Rank Math warns above 2.5%%, which is about %d matches for this draft.', $density, $occurrences, $words, $full_credit_min, $full_credit_max, $warning_max), ['score_fraction' => 0.0]);
        }

        if ($density < 0.75) {
            return $this->warning($low_density_message, ['score_fraction' => 2 / 6]);
        }

        if ($density < 1.0) {
            return $this->warning($low_density_message, ['score_fraction' => 3 / 6]);
        }

        return $this->pass(sprintf('Keyword density is %.2f%% with %d exact matches.', $density, $occurrences), ['score_fraction' => 1.0]);
    }
}

class AIPKit_SEO_Audit_AIOSEO_Keyphrase_In_Content_Rule extends AIPKit_SEO_Audit_Abstract_Rule
{
    public function __construct()
    {
        parent::__construct('aioseo_keyphrase_in_content', 'Focus keyword in content', 9, 'high', 'content');
    }

    public function applies(array $draft, array $context = []): bool
    {
        return $this->profile_is($context, 'aioseo')
            && $this->focus_keyword($draft) !== ''
            && $this->word_count((string) ($draft['content'] ?? '')) > 0;
    }

    public function evaluate(array $draft, array $context = []): array
    {
        return $this->contains_phrase((string) ($draft['content'] ?? ''), $this->focus_keyword($draft))
            ? $this->pass('Focus Keyword found in content.')
            : $this->fail('Focus Keyword not found in content.', ['score_fraction' => 3 / 9]);
    }
}

class AIPKit_SEO_Audit_AIOSEO_Keyphrase_In_Introduction_Rule extends AIPKit_SEO_Audit_Abstract_Rule
{
    public function __construct()
    {
        parent::__construct('aioseo_keyphrase_in_introduction', 'Focus keyword in introduction', 9, 'high', 'content');
    }

    public function applies(array $draft, array $context = []): bool
    {
        return $this->profile_is($context, 'aioseo')
            && $this->focus_keyword($draft) !== ''
            && $this->word_count((string) ($draft['content'] ?? '')) > 0;
    }

    public function evaluate(array $draft, array $context = []): array
    {
        $first_paragraph = $this->get_first_explicit_paragraph((string) ($draft['content'] ?? ''));
        return $first_paragraph !== '' && $this->contains_phrase($first_paragraph, $this->focus_keyword($draft))
            ? $this->pass('Your Focus Keyword appears in the first paragraph.')
            : $this->fail('Your Focus Keyword does not appear in the first paragraph. Make the topic clear immediately.', ['score_fraction' => 3 / 9]);
    }

    private function get_first_explicit_paragraph(string $html): string
    {
        if (preg_match('/<p[^>]*>(.*?)<\/p>/is', $html, $match)) {
            return $this->clean_text((string) ($match[1] ?? ''));
        }

        if (preg_match('/^(.*?)(?:<h[1-6]\b|$)/is', $html, $match)) {
            $before_first_heading = $this->clean_text((string) ($match[1] ?? ''));
            if ($before_first_heading !== '') {
                return $before_first_heading;
            }
        }

        return '';
    }
}

class AIPKit_SEO_Audit_AIOSEO_Keyphrase_In_Meta_Rule extends AIPKit_SEO_Audit_Abstract_Rule
{
    public function __construct()
    {
        parent::__construct('aioseo_keyphrase_in_meta_description', 'Focus keyword in meta description', 9, 'high', 'meta_description');
    }

    public function applies(array $draft, array $context = []): bool
    {
        return $this->profile_is($context, 'aioseo')
            && $this->focus_keyword($draft) !== ''
            && trim((string) ($draft['meta_description'] ?? '')) !== '';
    }

    public function evaluate(array $draft, array $context = []): array
    {
        return $this->contains_phrase((string) ($draft['meta_description'] ?? ''), $this->focus_keyword($draft))
            ? $this->pass('Focus Keyword found in meta description.')
            : $this->fail('Focus Keyword not found in meta description.', ['score_fraction' => 3 / 9]);
    }
}

class AIPKit_SEO_Audit_AIOSEO_Keyphrase_In_Image_Alt_Rule extends AIPKit_SEO_Audit_Abstract_Rule
{
    public function __construct()
    {
        parent::__construct('aioseo_keyphrase_in_image_alt', 'Focus keyword in image alt attributes', 3, 'medium', 'content');
    }

    public function applies(array $draft, array $context = []): bool
    {
        return $this->profile_is($context, 'aioseo')
            && $this->focus_keyword($draft) !== ''
            && $this->word_count((string) ($draft['content'] ?? '')) > 0;
    }

    public function evaluate(array $draft, array $context = []): array
    {
        $images = $this->get_images($draft);
        if (empty($images)) {
            return $this->fail('Add an image with your Focus Keyword as alt text.', ['fixable' => false, 'score_fraction' => 3 / 9]);
        }

        foreach ($images as $image) {
            if ($this->alt_contains_exact_keyphrase((string) ($image['alt'] ?? ''), $this->focus_keyword($draft))) {
                return $this->pass('Focus Keyword found in image alt attribute.');
            }
        }

        return $this->fail('Focus Keyword not found in image alt attribute(s). Add an image with your Focus Keyword as alt text.', ['score_fraction' => 3 / 9]);
    }

    private function alt_contains_exact_keyphrase(string $alt_text, string $keyphrase): bool
    {
        $alt_text = $this->normalized_text($this->clean_text($alt_text));
        $keyphrase = $this->normalized_text($this->clean_text($keyphrase));

        return $alt_text !== '' && $keyphrase !== '' && strpos($alt_text, $keyphrase) !== false;
    }
}

class AIPKit_SEO_Audit_AIOSEO_Keyphrase_In_Subheadings_Rule extends AIPKit_SEO_Audit_Abstract_Rule
{
    public function __construct()
    {
        parent::__construct('aioseo_keyphrase_in_subheadings', 'Focus keyword in subheadings', 3, 'medium', 'content');
    }

    public function applies(array $draft, array $context = []): bool
    {
        return $this->profile_is($context, 'aioseo')
            && $this->focus_keyword($draft) !== ''
            && $this->word_count((string) ($draft['content'] ?? '')) > 0;
    }

    public function evaluate(array $draft, array $context = []): array
    {
        $headings = $this->get_headings((string) ($draft['content'] ?? ''), [2, 3]);
        $heading_count = count($headings);
        if ($heading_count === 0) {
            return $this->pass('No H2 or H3 subheadings were found for the focus-keyphrase subheading check.');
        }

        $matches = 0;
        foreach ($headings as $heading) {
            if ($this->contains_phrase($heading, $this->focus_keyword($draft))) {
                $matches++;
            }
        }

        $minimum_matches = max(1, (int) ceil($heading_count * 0.3));
        $maximum_matches = max($minimum_matches, (int) floor($heading_count * 0.75));

        if ($heading_count === 1 && $matches === 1) {
            return $this->pass('Your H2 or H3 subheading reflects the topic of your copy.');
        }

        if ($matches >= $minimum_matches && $matches <= $maximum_matches) {
            return $this->pass(sprintf(
                'Focus Keyword appears in %d of %d H2/H3 subheadings.',
                $matches,
                $heading_count
            ));
        }

        if ($matches > $maximum_matches) {
            return $this->fail(sprintf(
                'More than 75%% of H2/H3 subheadings include the Focus Keyword. Keep exact matches between %d and %d of %d headings for AIOSEO.',
                $minimum_matches,
                $maximum_matches,
                $heading_count
            ), ['score_fraction' => 3 / 9]);
        }

        return $this->fail(sprintf(
            'Use the Focus Keyword in more H2/H3 subheadings. Add exact matches to about %d of %d headings, without exceeding %d.',
            $minimum_matches,
            $heading_count,
            $maximum_matches
        ), ['score_fraction' => 3 / 9]);
    }
}

class AIPKit_SEO_Audit_AIOSEO_Keyphrase_Length_Rule extends AIPKit_SEO_Audit_Abstract_Rule
{
    public function __construct()
    {
        parent::__construct('aioseo_keyphrase_length', 'Focus keyword length', 9, 'medium', 'focus_keyword');
    }

    public function applies(array $draft, array $context = []): bool
    {
        return $this->profile_is($context, 'aioseo')
            && $this->focus_keyword($draft) !== '';
    }

    public function evaluate(array $draft, array $context = []): array
    {
        $words = $this->word_count($this->focus_keyword($draft));
        if ($words >= 1 && $words <= 4) {
            return $this->pass('Focus Keyword length is good.');
        }

        if ($words <= 8) {
            return $this->warning('Focus Keyword is slightly long. Try to make it shorter.', ['score_fraction' => 6 / 9]);
        }

        return $this->fail('Focus Keyword is too long. Try to make it shorter.', ['score_fraction' => 3 / 9]);
    }
}

class AIPKit_SEO_Audit_AIOSEO_Meta_Description_Length_Rule extends AIPKit_SEO_Audit_Abstract_Rule
{
    public function __construct()
    {
        parent::__construct('aioseo_meta_description_length', 'Meta description length', 9, 'medium', 'meta_description');
    }

    public function applies(array $draft, array $context = []): bool
    {
        return $this->profile_is($context, 'aioseo');
    }

    public function evaluate(array $draft, array $context = []): array
    {
        $length = $this->text_length((string) ($draft['meta_description'] ?? ''));
        if ($length === 0) {
            return $this->fail('No meta description has been specified.', ['score_fraction' => 1 / 9]);
        }

        if ($length <= 120) {
            return $this->warning('The meta description is too short.', ['score_fraction' => 6 / 9]);
        }

        if ($length > 160) {
            return $this->warning('The meta description is over 156 characters.', ['score_fraction' => 6 / 9]);
        }

        return $this->pass('Meta description length is good.');
    }
}

class AIPKit_SEO_Audit_AIOSEO_Content_Length_Rule extends AIPKit_SEO_Audit_Abstract_Rule
{
    public function __construct()
    {
        parent::__construct('aioseo_content_length', 'Content length', 9, 'high', 'content');
    }

    public function applies(array $draft, array $context = []): bool
    {
        return $this->profile_is($context, 'aioseo');
    }

    public function evaluate(array $draft, array $context = []): array
    {
        $words = $this->word_count((string) ($draft['content'] ?? ''));
        if ($words > 300) {
            return $this->pass('The content length is ok.');
        }

        if ($words >= 250) {
            return $this->warning('The content is below the minimum word count.', ['score_fraction' => 6 / 9]);
        }

        if ($words >= 200) {
            return $this->fail('The content is below the minimum word count.', ['score_fraction' => 3 / 9]);
        }

        return $this->fail('This is far below the recommended minimum word count.', ['score_fraction' => 0.0]);
    }
}

class AIPKit_SEO_Audit_AIOSEO_Internal_Link_Rule extends AIPKit_SEO_Audit_Abstract_Rule
{
    public function __construct()
    {
        parent::__construct('aioseo_internal_links', 'Internal links', 9, 'medium', 'content');
    }

    public function applies(array $draft, array $context = []): bool
    {
        return $this->profile_is($context, 'aioseo')
            && $this->word_count((string) ($draft['content'] ?? '')) > 0;
    }

    public function evaluate(array $draft, array $context = []): array
    {
        foreach ($this->get_link_details((string) ($draft['content'] ?? '')) as $link) {
            if ($this->is_aioseo_internal_href((string) ($link['href'] ?? ''), $context)) {
                return $this->pass('You are linking to other resources on your website.');
            }
        }

        return $this->fail('We could not find any internal links in your content.', ['score_fraction' => 3 / 9]);
    }

    private function is_aioseo_internal_href(string $href, array $context): bool
    {
        $href = trim($href);
        if ($href === '' || strncmp($href, '#', strlen('#')) === 0) {
            return false;
        }

        $scheme = wp_parse_url($href, PHP_URL_SCHEME);
        if (is_string($scheme) && !in_array(strtolower($scheme), ['http', 'https'], true)) {
            return false;
        }

        if (strncmp($href, '/', strlen('/')) === 0 && strncmp($href, '//', strlen('//')) !== 0) {
            return true;
        }

        $host = wp_parse_url($href, PHP_URL_HOST);
        if (!is_string($host) || $host === '') {
            return true;
        }

        $port = wp_parse_url($href, PHP_URL_PORT);
        $aioseo_host = strtolower($host . (is_int($port) ? ':' . $port : ''));

        return $aioseo_host === $this->get_site_host($context);
    }
}

class AIPKit_SEO_Audit_AIOSEO_External_Link_Rule extends AIPKit_SEO_Audit_Abstract_Rule
{
    public function __construct()
    {
        parent::__construct('aioseo_external_links', 'External links', 9, 'medium', 'content');
    }

    public function applies(array $draft, array $context = []): bool
    {
        return $this->profile_is($context, 'aioseo')
            && $this->word_count((string) ($draft['content'] ?? '')) > 0;
    }

    public function evaluate(array $draft, array $context = []): array
    {
        foreach ($this->get_link_details((string) ($draft['content'] ?? '')) as $link) {
            if ($this->is_aioseo_external_href((string) ($link['href'] ?? ''), $context)) {
                return $this->pass('Great! You are linking to external resources.');
            }
        }

        return $this->fail('No outbound links were found. Link out to external resources.', ['score_fraction' => 3 / 9]);
    }

    private function is_aioseo_external_href(string $href, array $context): bool
    {
        $href = trim($href);
        if ($href === '' || strncmp($href, '#', strlen('#')) === 0) {
            return false;
        }

        $scheme = wp_parse_url($href, PHP_URL_SCHEME);
        if (is_string($scheme) && !in_array(strtolower($scheme), ['http', 'https'], true)) {
            return false;
        }

        if (!is_string($scheme) && strncmp($href, '/', strlen('/')) === 0) {
            return false;
        }

        $host = wp_parse_url($href, PHP_URL_HOST);
        if (!is_string($host) || $host === '') {
            return false;
        }

        $port = wp_parse_url($href, PHP_URL_PORT);
        $aioseo_host = strtolower($host . (is_int($port) ? ':' . $port : ''));

        return $aioseo_host !== $this->get_site_host($context);
    }
}

class AIPKit_SEO_Audit_AIOSEO_Title_Beginning_Rule extends AIPKit_SEO_Audit_Abstract_Rule
{
    public function __construct()
    {
        parent::__construct('aioseo_keyphrase_beginning_title', 'Focus keyword at beginning of SEO title', 9, 'medium', 'title');
    }

    public function applies(array $draft, array $context = []): bool
    {
        return $this->profile_is($context, 'aioseo')
            && $this->focus_keyword($draft) !== ''
            && trim((string) ($draft['title'] ?? '')) !== '';
    }

    public function evaluate(array $draft, array $context = []): array
    {
        $title = $this->normalized_text((string) ($draft['title'] ?? ''));
        $keyword = $this->normalized_text($this->focus_keyword($draft));
        $position = strpos($title, $keyword);
        $halfway = (int) floor(max(1, $this->text_length($title)) / 2);

        return $position !== false && $position < $halfway
            ? $this->pass('Focus Keyword used at the beginning of SEO title.')
            : $this->fail('Use the Focus Keyword near the beginning of the SEO title.', ['score_fraction' => 3 / 9]);
    }
}

class AIPKit_SEO_Audit_AIOSEO_Title_Length_Rule extends AIPKit_SEO_Audit_Abstract_Rule
{
    public function __construct()
    {
        parent::__construct('aioseo_title_length', 'SEO title length', 9, 'medium', 'title');
    }

    public function applies(array $draft, array $context = []): bool
    {
        return $this->profile_is($context, 'aioseo');
    }

    public function evaluate(array $draft, array $context = []): array
    {
        $title = $this->get_aioseo_scored_title((string) ($draft['title'] ?? ''));
        $length = $this->text_length($title);
        if ($length === 0) {
            return $this->fail('No title has been specified.', ['score_fraction' => 1 / 9]);
        }

        if ($length <= 40) {
            return $this->warning('The title is too short.', ['score_fraction' => 6 / 9]);
        }

        if ($length > 60) {
            return $this->warning('The title is over 60 characters.', ['score_fraction' => 6 / 9]);
        }

        return $this->pass('SEO title length is good.');
    }

    private function get_aioseo_scored_title(string $title): string
    {
        $title = trim(wp_strip_all_tags($title));
        if ($title === '') {
            return '';
        }

        $site_title = function_exists('get_bloginfo') ? trim((string) get_bloginfo('name')) : '';
        if ($site_title === '' || stripos($title, $site_title) !== false) {
            return $title;
        }

        return $title . ' - ' . $site_title;
    }
}

class AIPKit_SEO_Audit_AIOSEO_Headline_Score_Rule extends AIPKit_SEO_Audit_Abstract_Rule
{
    private const PASS_SCORE = 70;

    public function __construct()
    {
        parent::__construct('aioseo_headline_score', 'Headline Score', 9, 'medium', 'title');
    }

    public function applies(array $draft, array $context = []): bool
    {
        return $this->profile_is($context, 'aioseo')
            && trim((string) ($draft['title'] ?? '')) !== ''
            && $this->is_aioseo_headline_analyzer_available();
    }

    public function evaluate(array $draft, array $context = []): array
    {
        $result = $this->get_aioseo_headline_result((string) ($draft['title'] ?? ''));
        if (!is_array($result)) {
            return $this->pass('AIOSEO Headline Score is unavailable for this draft.');
        }

        $score = isset($result['score']) ? absint($result['score']) : 0;
        $guidance = $this->build_guidance(isset($result['result']) && is_object($result['result']) ? $result['result'] : null);
        $message = sprintf('AIOSEO Headline Score is %d/100. Aim for 70+.', $score);
        if ($guidance !== '') {
            $message .= ' ' . $guidance;
        }

        if ($score >= self::PASS_SCORE) {
            return $this->pass(sprintf('AIOSEO Headline Score is %d/100.', $score), ['score_fraction' => 1.0]);
        }

        $score_fraction = max(0.0, min(1.0, $score / self::PASS_SCORE));
        if ($score >= 40) {
            return $this->warning($message, ['score_fraction' => $score_fraction]);
        }

        return $this->fail($message, ['score_fraction' => $score_fraction]);
    }

    private function is_aioseo_headline_analyzer_available(): bool
    {
        if (!function_exists('aioseo')) {
            return false;
        }

        try {
            $aioseo = aioseo();
        } catch (\Throwable $e) {
            return false;
        }

        return is_object($aioseo)
            && isset($aioseo->standalone)
            && isset($aioseo->standalone->headlineAnalyzer)
            && is_object($aioseo->standalone->headlineAnalyzer)
            && method_exists($aioseo->standalone->headlineAnalyzer, 'getResult');
    }

    private function get_aioseo_headline_result(string $title): ?array
    {
        if (!$this->is_aioseo_headline_analyzer_available()) {
            return null;
        }

        $this->load_phpinsight_if_needed();

        if (!class_exists('\PHPInsight\Sentiment')) {
            return null;
        }

        try {
            $result = aioseo()->standalone->headlineAnalyzer->getResult(sanitize_text_field($title));
        } catch (\Throwable $e) {
            return null;
        }

        return is_array($result) ? $result : null;
    }

    private function load_phpinsight_if_needed(): void
    {
        if (class_exists('\PHPInsight\Sentiment') || !defined('AIOSEO_DIR')) {
            return;
        }

        $autoload = rtrim((string) AIOSEO_DIR, '/\\') . '/vendor/jwhennessey/phpinsight/autoload.php';
        if (is_readable($autoload)) {
            require_once $autoload;
        }
    }

    private function build_guidance(?object $analysis): string
    {
        if (!$analysis) {
            return 'Rewrite the post title with stronger word balance, positive sentiment, and a list, how-to, or question angle when natural.';
        }

        $hints = [];
        $word_count = isset($analysis->wordCount) ? absint($analysis->wordCount) : 0;
        if ($word_count < 5 || $word_count > 9) {
            $hints[] = 'use 5-9 words';
        }

        $length = isset($analysis->length) ? absint($analysis->length) : 0;
        if ($length < 35 || $length > 66) {
            $hints[] = 'keep the headline around 35-66 characters excluding spaces';
        }

        $common = isset($analysis->commonWordsPercentage) ? (float) $analysis->commonWordsPercentage : 0.0;
        if ($common < 0.2) {
            $hints[] = 'add a few natural common words';
        }

        $uncommon = isset($analysis->uncommonWordsPercentage) ? (float) $analysis->uncommonWordsPercentage : 0.0;
        if ($uncommon < 0.1) {
            $hints[] = 'add a specific uncommon descriptor';
        }

        $emotional = isset($analysis->emotionalWordsPercentage) ? (float) $analysis->emotionalWordsPercentage : 0.0;
        if ($emotional < 0.1) {
            $hints[] = 'add positive emotional wording';
        }

        $power_words = isset($analysis->powerWords) && is_array($analysis->powerWords) ? $analysis->powerWords : [];
        if (empty($power_words)) {
            $hints[] = 'include one natural power word';
        }

        $sentiment = isset($analysis->sentiment) ? (string) $analysis->sentiment : '';
        if ($sentiment === 'neu') {
            $hints[] = 'avoid a neutral headline';
        }

        $headline_types = isset($analysis->headlineTypes) && is_array($analysis->headlineTypes) ? array_map('strval', $analysis->headlineTypes) : [];
        if (empty($headline_types) || in_array('General', $headline_types, true)) {
            $hints[] = 'use a list, how-to, or question format if it fits';
        }

        if (empty($hints)) {
            return 'Try a more compelling but accurate title while preserving the focus keyword near the beginning.';
        }

        return 'Improve it: ' . implode('; ', array_slice($hints, 0, 5)) . '.';
    }
}

class AIPKit_SEO_Audit_AIOSEO_Content_Assets_Rule extends AIPKit_SEO_Audit_Abstract_Rule
{
    public function __construct()
    {
        parent::__construct('aioseo_content_assets', 'Images/videos in content', 5, 'medium', 'content', false);
    }

    public function applies(array $draft, array $context = []): bool
    {
        return $this->profile_is($context, 'aioseo');
    }

    public function evaluate(array $draft, array $context = []): array
    {
        $asset_count = count($this->get_images($draft)) + $this->count_videos((string) ($draft['content'] ?? ''));
        return $asset_count > 0
            ? $this->pass('Your content contains images and/or video(s).')
            : $this->fail('You are not using rich media like images or videos.', ['score_fraction' => 1 / 5, 'fixable' => false]);
    }

    private function count_videos(string $content): int
    {
        if (preg_match_all('/<(?:video|iframe)\b/i', $content, $matches)) {
            return count($matches[0]);
        }

        return 0;
    }
}

class AIPKit_SEO_Audit_AIOSEO_Sentence_Length_Rule extends AIPKit_SEO_Audit_Abstract_Rule
{
    public function __construct()
    {
        parent::__construct('aioseo_sentence_length', 'Sentence length', 9, 'medium', 'content');
    }

    public function applies(array $draft, array $context = []): bool
    {
        return $this->profile_is($context, 'aioseo')
            && $this->word_count((string) ($draft['content'] ?? '')) >= 100;
    }

    public function evaluate(array $draft, array $context = []): array
    {
        $sentences = $this->get_sentences((string) ($draft['content'] ?? ''));
        if (empty($sentences)) {
            return $this->pass('Sentence length is looking great.');
        }

        $long_sentences = 0;
        foreach ($sentences as $sentence) {
            if ($this->word_count($sentence) > 20) {
                $long_sentences++;
            }
        }

        $percentage = ($long_sentences / max(1, count($sentences))) * 100;
        return $percentage <= 25
            ? $this->pass('Sentence length is looking great.')
            : $this->warning('Too many sentences contain more than 20 words.', ['score_fraction' => 6 / 9]);
    }
}

class AIPKit_SEO_Audit_AIOSEO_Passive_Voice_Rule extends AIPKit_SEO_Audit_Abstract_Rule
{
    public function __construct()
    {
        parent::__construct('aioseo_passive_voice', 'Passive voice', 9, 'medium', 'content');
    }

    public function applies(array $draft, array $context = []): bool
    {
        return $this->profile_is($context, 'aioseo')
            && $this->word_count((string) ($draft['content'] ?? '')) >= 100;
    }

    public function evaluate(array $draft, array $context = []): array
    {
        $sentences = $this->get_sentences((string) ($draft['content'] ?? ''));
        if (empty($sentences)) {
            return $this->pass('You are using enough active voice.');
        }

        $passive_count = 0;
        foreach ($sentences as $sentence) {
            if (preg_match('/\b(?:am|are|be|been|being|is|was|were)\s+\w+(?:ed|en)\b/i', $sentence)) {
                $passive_count++;
            }
        }

        $percentage = ($passive_count / max(1, count($sentences))) * 100;
        if ($percentage > 15) {
            return $this->fail('Too many sentences contain passive voice.', ['score_fraction' => 3 / 9]);
        }

        if ($percentage > 10) {
            return $this->warning('Passive voice usage is above the recommended maximum.', ['score_fraction' => 6 / 9]);
        }

        return $this->pass('You are using enough active voice.');
    }
}

class AIPKit_SEO_Audit_AIOSEO_Transition_Words_Rule extends AIPKit_SEO_Audit_Abstract_Rule
{
    public function __construct()
    {
        parent::__construct('aioseo_transition_words', 'Transition words', 9, 'medium', 'content');
    }

    public function applies(array $draft, array $context = []): bool
    {
        return $this->profile_is($context, 'aioseo')
            && $this->word_count((string) ($draft['content'] ?? '')) >= 100;
    }

    public function evaluate(array $draft, array $context = []): array
    {
        $sentences = array_values(array_filter($this->get_sentences((string) ($draft['content'] ?? '')), function ($sentence) {
            return $this->word_count((string) $sentence) >= 3;
        }));
        $sentence_count = count($sentences);
        if ($sentence_count === 0) {
            return $this->pass('Transition word coverage is not applicable.');
        }

        $transition_sentence_count = 0;
        foreach ($sentences as $sentence) {
            if ($this->sentence_has_transition_word($sentence)) {
                $transition_sentence_count++;
            }
        }

        $percentage = ($transition_sentence_count / max(1, $sentence_count)) * 100;
        if ($percentage >= 30) {
            return $this->pass('Transition word usage is strong.');
        }

        if ($percentage >= 20) {
            return $this->warning(sprintf('Only %.1f%% of the sentences contain transition words.', $percentage), ['score_fraction' => 6 / 9]);
        }

        return $this->fail(sprintf('Only %.1f%% of the sentences contain transition words.', $percentage), ['score_fraction' => 3 / 9]);
    }

    private function sentence_has_transition_word(string $sentence): bool
    {
        $sentence = $this->normalized_text($this->clean_text($sentence));
        foreach ($this->transition_words() as $phrase) {
            $phrase = $this->normalized_text($phrase);
            $phrase_pattern = preg_replace('/\s+/', '\\s+', preg_quote($phrase, '/'));
            if ($phrase_pattern && preg_match('/(?<![\p{L}\p{N}])' . $phrase_pattern . '(?![\p{L}\p{N}])/u', $sentence)) {
                return true;
            }
        }

        return false;
    }

    private function transition_words(): array
    {
        return [
            'above all', 'accordingly', 'additionally', 'after all', 'also', 'although',
            'as a result', 'because', 'besides', 'but', 'consequently', 'despite',
            'especially', 'finally', 'first', 'for example', 'for instance',
            'furthermore', 'however', 'in addition', 'in conclusion', 'in contrast',
            'in fact', 'in particular', 'instead', 'likewise', 'meanwhile', 'moreover',
            'nevertheless', 'next', 'nonetheless', 'notably', 'on the other hand',
            'otherwise', 'overall', 'second', 'similarly', 'since', 'so', 'specifically',
            'still', 'therefore', 'though', 'thus', 'ultimately', 'whereas', 'while',
        ];
    }
}

class AIPKit_SEO_Audit_AIOSEO_Consecutive_Sentences_Rule extends AIPKit_SEO_Audit_Abstract_Rule
{
    public function __construct()
    {
        parent::__construct('aioseo_consecutive_sentences', 'Consecutive sentences', 9, 'medium', 'content');
    }

    public function applies(array $draft, array $context = []): bool
    {
        return $this->profile_is($context, 'aioseo')
            && $this->word_count((string) ($draft['content'] ?? '')) >= 100;
    }

    public function evaluate(array $draft, array $context = []): array
    {
        $sentences = $this->get_sentences((string) ($draft['content'] ?? ''));
        $previous_word = '';
        $run = 0;
        foreach ($sentences as $sentence) {
            $first_word = $this->get_sentence_first_word($sentence);
            if ($first_word === '') {
                $previous_word = '';
                $run = 0;
                continue;
            }

            $run = $first_word === $previous_word ? $run + 1 : 1;
            $previous_word = $first_word;
            if ($run >= 4) {
                return $this->fail('The text contains several consecutive sentences starting with the same word.', ['score_fraction' => 3 / 9]);
            }
        }

        return $this->pass('There is enough variety in your sentences.');
    }
}

class AIPKit_SEO_Audit_AIOSEO_Subheading_Distribution_Rule extends AIPKit_SEO_Audit_Abstract_Rule
{
    public function __construct()
    {
        parent::__construct('aioseo_subheading_distribution', 'Subheading distribution', 9, 'medium', 'content');
    }

    public function applies(array $draft, array $context = []): bool
    {
        return $this->profile_is($context, 'aioseo')
            && $this->word_count((string) ($draft['content'] ?? '')) >= 100;
    }

    public function evaluate(array $draft, array $context = []): array
    {
        $content = (string) ($draft['content'] ?? '');
        $words = $this->word_count($content);
        $headings = $this->get_heading_offsets($content);
        if ($words <= 300) {
            return $this->pass('The text is short enough and probably does not need more subheadings.');
        }

        if (empty($headings)) {
            return $this->fail('You are not using any subheadings, although your text is rather long.', ['score_fraction' => 2 / 9]);
        }

        $sections = $this->get_section_word_counts($content, $headings);
        $longest = empty($sections) ? 0 : max($sections);
        if ($longest <= 300) {
            return $this->pass('Subheading distribution is good.');
        }

        if ($longest <= 350) {
            return $this->warning('A section is longer than 300 words and is not separated by subheadings.', ['score_fraction' => 6 / 9]);
        }

        return $this->fail('A section is too long and needs more subheadings.', ['score_fraction' => 3 / 9]);
    }

    private function get_heading_offsets(string $html): array
    {
        if (!preg_match_all('/<h[1-6]\b[^>]*>.*?<\/h[1-6]>/is', $html, $matches, PREG_OFFSET_CAPTURE)) {
            return [];
        }

        return $matches[0];
    }

    private function get_section_word_counts(string $html, array $headings): array
    {
        $sections = [];
        foreach ($headings as $index => $heading) {
            $start = (int) $heading[1] + strlen((string) $heading[0]);
            $end = isset($headings[$index + 1]) ? (int) $headings[$index + 1][1] : strlen($html);
            $sections[] = $this->word_count((string) substr($html, $start, max(0, $end - $start)));
        }

        return $sections;
    }
}

class AIPKit_SEO_Audit_AIOSEO_Flesch_Reading_Rule extends AIPKit_SEO_Audit_Abstract_Rule
{
    public function __construct()
    {
        parent::__construct('aioseo_flesch_reading', 'Flesch reading ease', 9, 'medium', 'content');
    }

    public function applies(array $draft, array $context = []): bool
    {
        return $this->profile_is($context, 'aioseo')
            && $this->word_count((string) ($draft['content'] ?? '')) >= 100;
    }

    public function evaluate(array $draft, array $context = []): array
    {
        $score = $this->flesch_score((string) ($draft['content'] ?? ''));
        if ($score >= 63) {
            return $this->pass(sprintf('The copy scores %.1f in the Flesch reading ease test.', $score));
        }

        if ($score >= 50) {
            return $this->warning(sprintf('The copy scores %.1f in the Flesch reading ease test. Try shorter sentences and simpler words.', $score), ['score_fraction' => 6 / 9]);
        }

        return $this->fail(sprintf('The copy scores %.1f in the Flesch reading ease test. Try shorter sentences and simpler words.', $score), ['score_fraction' => 3 / 9]);
    }

    private function flesch_score(string $html): float
    {
        $sentences = max(1, count($this->get_sentences($html)));
        $words = $this->extract_words($html);
        $word_count = max(1, count($words));
        $syllables = 0;
        foreach ($words as $word) {
            $syllables += $this->count_syllables($word);
        }

        return max(0.0, min(100.0, 206.835 - (1.015 * ($word_count / $sentences)) - (84.6 * ($syllables / $word_count))));
    }

    private function extract_words(string $html): array
    {
        $text = $this->normalized_text($this->clean_text($html));
        if ($text === '' || !preg_match_all('/[a-z]+/i', $text, $matches)) {
            return [];
        }

        return $matches[0];
    }

    private function count_syllables(string $word): int
    {
        $word = strtolower(preg_replace('/[^a-z]/i', '', $word));
        if ($word === '') {
            return 1;
        }

        $word = preg_replace('/(?:e|es|ed)$/', '', $word);
        preg_match_all('/[aeiouy]+/', $word, $matches);
        return max(1, count($matches[0]));
    }
}
