<?php

/**
 * Chatbot trigger schemas shared by the editor and server-side validation.
 * Return a fresh registry on each include, with public keys and $ref targets intact.
 */
if (!defined('ABSPATH')) {
    exit;
}

$aipkit_trigger_schemas = [
    'EventSchema' => [
        'type' => 'object',
        'properties' => [
            'name' => [
                'type' => 'string',
                'description' => 'The name of the event.',
                'enum' => [
                    'user_message_received', // Fired when a user sends a message (before AI processing).
                                             // Context: user_id, session_id, bot_id, bot_settings, user_message_text, current_history, client_ip, post_id, message_count, system_instruction, user_roles, current_provider, current_model_id
                    'session_started',       // Fired when a new chat session begins (with the first user message).
                                             // Context: user_id, session_id, bot_id, bot_settings, client_ip, post_id, user_message_text (first message), system_instruction, user_roles, current_provider, current_model_id
                    'system_error_occurred', // Fired when an internal AI processing error occurs.
                                             // Context: error_code, error_message, bot_id, user_id, session_id, module, operation, failed_provider, failed_model
                    'form_submitted',        // Fired when a dynamically displayed form is submitted.
                                             // Context: bot_id, form_id, submitted_data, submitted_data_display, submitted_data_labels, user_id, session_id, conversation_uuid, client_ip, post_id, bot_settings, user_roles, current_provider, current_model_id
                ],
                'required' => true,
            ],
            'params' => [
                'type' => 'object',
                'description' => 'Event-specific parameters that might be configured with the event in a trigger. Context for conditions is passed dynamically.',
                'properties' => [
                    'form_id_is' => [ // This param allows pre-filtering by form_id in the trigger itself.
                                     // The actual `form_id` for conditions will come from dynamic context.
                        'if' => ['properties' => ['name' => ['const' => 'form_submitted']]],
                        'then' => [
                            'type' => 'string',
                            'description' => 'Optional: Trigger only if the submitted form_id matches this value. Conditions can also check `form_id` from context.',
                        ],
                    ],
                    // The actual submitted_data fields will be accessed via context, e.g., context_data.submitted_data.field_name
                ],
                'additionalProperties' => true, // Allow other params for extensibility
            ],
        ],
        'required' => ['name'],
    ],
    'ConditionSchema' => [
        'type' => 'object',
        'properties' => [
            'fields_by_type' => [
                'type' => 'object',
                'description' => 'Structured field lists keyed by condition type.',
                'additionalProperties' => true,
                'default' => [
                    'user_context' => ['is_logged_in', 'user_role', 'user_message_text'],
                    'text_content' => ['user_message_text'],
                    'conversation_state' => ['message_count'],
                    'ai_model_context' => ['current_provider', 'current_model_id'],
                    'http_context' => ['http_referer', 'user_agent'],
                    'post_context' => ['post_id', 'post_title', 'post_tags_contain'],
                    'error_context' => ['error_code', 'error_message', 'failed_provider', 'failed_model', 'status_code', 'operation', 'module'],
                ],
            ],
            'type' => [
                'type' => 'string',
                'description' => 'The category of the condition.',
                'enum' => [
                    'user_context',          // Conditions related to the user (logged_in, role).
                    'text_content',          // Conditions related to message text.
                    'conversation_state',    // Conditions related to the conversation (message_count).
                    'ai_model_context',      // Conditions related to the AI model being used (current_provider, current_model_id).
                    'http_context',          // Conditions related to HTTP request (referer, user_agent).
                    'post_context',          // Conditions related to the current WordPress post/page.
                    'error_context',         // Conditions related to system_error_occurred event
                ],
                'required' => true,
            ],
            'field' => [
                'type' => 'string',
                'description' => 'The specific field to evaluate within the chosen type. Examples: "is_logged_in", "user_role", "user_message_text", "message_count", "current_provider", "current_model_id", "http_referer", "user_agent", "post_id", "post_title", "post_tags_contain", "error_code", "error_message", "failed_provider", "failed_model", "status_code".',
                'required' => true,
            ],
            'operator' => [
                'type' => 'string',
                'description' => 'The comparison operator to use.',
                'enum' => [
                    // Boolean
                    'is_true', 'is_false',
                    // String
                    'equals', 'not_equals', 'contains', 'not_contains',
                    'starts_with', 'ends_with', 'matches_regex', 'is_empty', 'is_not_empty',
                    'equals_ignore_case',
                    // String/Array
                    'is_one_of', 'is_not_one_of', // Value should be an array of strings
                    // Numeric
                    'greater_than', 'less_than', 'equals_numeric', 'not_equals_numeric',
                    'greater_than_or_equals', 'less_than_or_equals',
                ],
                'required' => true,
            ],
            'value' => [
                'type' => ['string', 'integer', 'boolean', 'array', 'null'],
                'description' => 'The value to compare against. Type depends on the field and operator. For "is_one_of", this should be an array.',
            ],
        ],
        'required' => ['type', 'field', 'operator'],
    ],
    'ActionSchema' => [
        'type' => 'object',
        'properties' => [
            'type' => [
                'type' => 'string',
                'description' => 'The type of action to perform.',
                'enum' => [
                    'bot_reply',        // Send a predefined message from the bot.
                    'inject_context',   // Modify context being sent to the AI.
                    'block_message',    // Prevent the user\'s message from reaching the AI.
                    'call_webhook',     // Make an HTTP request to an external URL.
                    'set_variable',     // Set a variable in user_meta or current bot_context.
                    'display_form',     // Display a form in the chat interface.
                    'store_form_submission', // Store submitted form data to the chat log.
                ],
                'required' => true,
            ],
            'payload' => [
                'type' => 'object',
                'description' => 'Action-specific configuration data.',
                'properties' => [
                    // For 'bot_reply'
                    'message' => ['type' => 'string', 'description' => 'The message text for the bot to send. Supports {{placeholders}}.'],
                    'stop_processing_ai' => ['type' => 'boolean', 'description' => 'If true, the original user message will not be sent to the AI after this reply.'],

                    // For 'inject_context'
                    'placement' => [
                        'type' => 'string',
                        'enum' => ['system_instruction_prepend', 'system_instruction_append', 'history_prepend'],
                        'description' => 'Where to inject the content.',
                    ],
                    'content' => ['type' => 'string', 'description' => 'The content to inject. Supports {{placeholders}}.'],

                    // For 'block_message'
                    'reason' => ['type' => 'string', 'description' => 'Optional user-facing message explaining why their message was blocked.'],

                    // For 'call_webhook'
                    'endpoint_url' => ['type' => 'string', 'format' => 'uri', 'description' => 'The URL to call.'],
                    'http_method' => ['type' => 'string', 'enum' => ['GET', 'POST', 'PUT', 'DELETE'], 'default' => 'POST'],
                    'headers' => ['type' => 'object', 'description' => 'Key-value pairs for HTTP headers. Values support {{placeholders}}.'],
                    'body_template' => ['type' => 'string', 'description' => 'JSON string template for the request body. Supports {{placeholders}}, including form placeholders like {{submitted_data_json}}, {{submitted_data_display_json}}, {{submitted_data_labels_json}}, {{submitted.field_id}}, {{submitted_display.field_id}}, {{submitted_label.field_id}}.'],
                    'timeout_seconds' => ['type' => 'integer', 'default' => 10, 'minimum' => 1, 'maximum' => 30],

                    // For 'set_variable'
                    'scope' => ['type' => 'string', 'enum' => ['user_meta', 'bot_context'], 'description' => 'Where to set the variable.'],
                    'key' => ['type' => 'string', 'description' => 'The key/name of the variable.'],
                    // 'value' for 'set_variable' is at the top level of the action object itself.

                    // For 'display_form'
                    'form_id' => ['type' => 'string', 'description' => 'Auto-generated unique identifier for this form instance (hidden in UI).'],
                    'title' => ['type' => 'string', 'description' => 'Optional title to display above the form.'],
                    'elements' => [
                        'type' => 'array',
                        'description' => 'An array of form element objects.',
                        'items' => [
                            'type' => 'object',
                            'properties' => [
                                'id' => ['type' => 'string', 'description' => 'Unique ID for this field within the form.'],
                                'type' => [
                                    'type' => 'string',
                                    'description' => 'Element type.',
                                    'enum' => ["text_input", "textarea", "dropdown", "label", "heading", "checkbox_group", "radio_group"]
                                ],
                                'label' => ['type' => 'string', 'description' => 'Display label for the element.'],
                                'placeholder' => ['type' => 'string', 'description' => 'Placeholder text for input/textarea.'],
                                'options' => [
                                    'type' => 'array',
                                    'description' => 'Array of options for dropdown, radio_group, checkbox_group.',
                                    'items' => [
                                        'type' => 'object',
                                        'properties' => [
                                            'value' => ['type' => 'string'],
                                            'text' => ['type' => 'string']
                                        ],
                                        'required' => ['value', 'text']
                                    ]
                                ],
                                'required' => ['type' => 'boolean', 'description' => 'If the field is mandatory.'],
                                'default_value' => ['type' => ['string', 'array'], 'description' => 'Default value for the field (string or array for checkbox_group).'],
                                'help_text' => ['type' => 'string', 'description' => 'Small help text below the field.']
                            ],
                            'required' => ['id', 'type']
                        ]
                    ],
                    'submit_button_text' => ['type' => 'string', 'description' => 'Text for the form\'s submit button (e.g., "Submit Query").', 'default' => 'Submit'],

                    'log_message_format' => ['type' => 'string', 'description' => 'Optional format for the log message. Placeholders: {{form_id}}, {{user_name}}, {{form_submission_summary}}.', 'default' => "Form '{{form_id}}' submitted by {{user_name}}. Summary: {{form_submission_summary}}"],
                ],
                // Preserve the effective legacy metadata; payload validation lives in the validator.
                'if' => ['properties' => ['type' => ['const' => 'bot_reply']]],
                'then' => [],
                'else if' => ['properties' => ['type' => ['const' => 'store_form_submission']]],
            ],
            'value' => [ // This 'value' is specifically for 'set_variable' action.
                'type' => ['string', 'integer', 'boolean', 'null'],
                'description' => 'The value to set for the variable (for set_variable action). Supports {{placeholders}}.'
            ],
        ],
        'required' => ['type', 'payload'],
    ],
    'TriggerSchema' => [
        'type' => 'object',
        'properties' => [
            'id' => [
                'type' => 'string',
                'format' => 'uuid',
                'description' => 'Unique identifier for the trigger.',
                'required' => true,
            ],
            'name' => [
                'type' => 'string',
                'description' => 'A user-friendly name for the trigger.',
                'required' => true,
            ],
            'event_name' => [
                'type' => 'string',
                'description' => 'The name of the event that this trigger listens for. Must match one of the defined EventSchema names.',
                'required' => true,
            ],
            'event_params' => [
                'type' => 'object',
                'description' => 'Optional event-specific parameters (e.g., form_id_is).',
                'additionalProperties' => true,
            ],
            'conditions' => [
                'type' => 'array',
                'description' => 'An array of Condition Objects. All conditions must be met for the action to execute.',
                'items' => ['$ref' => '#/components/schemas/ConditionSchema'],
                'default' => [],
            ],
            'action' => [
                'type' => 'object',
                'properties' => [
                    'type' => ['type' => 'string', 'required' => true],
                    'payload' => ['type' => 'object', 'required' => true, 'additionalProperties' => true],
                     'value' => [ 'type' => ['string', 'integer', 'boolean', 'null']],
                ],
                'required' => true, // The action itself is required
                'description' => 'The Action Object to execute if conditions are met.',
            ],
            'priority' => [
                'type' => 'integer',
                'description' => 'Execution priority (lower numbers execute first). Default 10.',
                'default' => 10,
            ],
            'is_active' => [
                'type' => 'boolean',
                'description' => 'Whether the trigger is currently active.',
                'default' => true,
            ],
            'description' => [
                'type' => 'string',
                'description' => 'Optional description for the trigger.'
            ]
        ],
        'required' => ['id', 'name', 'event_name', 'action', 'priority', 'is_active'],
    ],
    'TriggersArraySchema' => [
        'type' => 'array',
        'items' => ['$ref' => '#/components/schemas/TriggerSchema'],
    ],
];

$aipkit_trigger_schemas['components'] = [
    'schemas' => [
        'EventSchema' => $aipkit_trigger_schemas['EventSchema'],
        'ConditionSchema' => $aipkit_trigger_schemas['ConditionSchema'],
        'ActionSchema' => $aipkit_trigger_schemas['ActionSchema'],
        'TriggerSchema' => $aipkit_trigger_schemas['TriggerSchema'],
    ],
];

return $aipkit_trigger_schemas;
