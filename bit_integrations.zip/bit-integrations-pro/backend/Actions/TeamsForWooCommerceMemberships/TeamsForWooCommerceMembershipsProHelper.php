<?php

namespace BitApps\IntegrationsPro\Actions\TeamsForWooCommerceMemberships;

use Exception;

class TeamsForWooCommerceMembershipsProHelper
{
    public static function addMemberToTeam($defaultResponse, $memberData, $integrationDetails)
    {
        if (!self::isPluginActive()) {
            return self::errorResponse('Teams for WooCommerce Memberships is not installed or activated');
        }

        $teamId = isset($memberData['team_id']) ? absint($memberData['team_id']) : 0;
        $userEmail = isset($memberData['user_email']) ? sanitize_email($memberData['user_email']) : '';
        $memberRole = isset($memberData['member_role']) ? sanitize_text_field($memberData['member_role']) : 'member';

        if (empty($teamId)) {
            return self::errorResponse('Team ID is required');
        }

        if (empty($userEmail)) {
            return self::errorResponse('User email is required');
        }

        $user = get_user_by('email', $userEmail);
        if (!$user) {
            return self::errorResponse('User not found with the provided email');
        }

        $team = wc_memberships_for_teams_get_team($teamId);
        if (!$team) {
            return self::errorResponse('Team not found');
        }

        try {
            $member = $team->add_member($user->ID, $memberRole);

            if (!$member) {
                throw new Exception('Failed to add member to team');
            }

            return self::successResponse('Member added to team successfully', ['member' => self::getTeamMemberData($member)]);
        } catch (Exception $e) {
            return self::errorResponse($e->getMessage());
        }
    }

    public static function removeMemberFromTeam($defaultResponse, $memberData, $integrationDetails)
    {
        if (!self::isPluginActive()) {
            return self::errorResponse('Teams for WooCommerce Memberships is not installed or activated');
        }

        $teamId = isset($memberData['team_id']) ? absint($memberData['team_id']) : 0;
        $userEmail = isset($memberData['user_email']) ? sanitize_email($memberData['user_email']) : '';

        if (empty($teamId)) {
            return self::errorResponse('Team ID is required');
        }

        if (empty($userEmail)) {
            return self::errorResponse('User email is required');
        }

        $user = get_user_by('email', $userEmail);
        if (!$user) {
            return self::errorResponse('User not found with the provided email');
        }

        $team = wc_memberships_for_teams_get_team($teamId);
        if (!$team) {
            return self::errorResponse('Team not found');
        }

        try {
            $team->remove_member($user->ID);

            return self::successResponse('Member removed from team successfully', ['user_id' => $user->ID, 'team_id' => $teamId]);
        } catch (Exception $e) {
            return self::errorResponse($e->getMessage());
        }
    }

    public static function inviteUserToTeam($defaultResponse, $invitationData, $integrationDetails)
    {
        if (!self::isPluginActive()) {
            return self::errorResponse('Teams for WooCommerce Memberships is not installed or activated');
        }

        $teamId = isset($invitationData['team_id']) ? absint($invitationData['team_id']) : 0;
        $userEmail = isset($invitationData['user_email']) ? sanitize_email($invitationData['user_email']) : '';
        $memberRole = isset($invitationData['member_role']) ? sanitize_text_field($invitationData['member_role']) : 'member';

        if (empty($teamId)) {
            return self::errorResponse('Team ID is required');
        }

        if (empty($userEmail)) {
            return self::errorResponse('User email is required');
        }

        $team = wc_memberships_for_teams_get_team($teamId);
        if (!$team) {
            return self::errorResponse('Team not found');
        }

        try {
            $invitation = $team->invite($userEmail, $memberRole);

            if (!$invitation) {
                throw new Exception('Failed to invite user to team');
            }

            return self::successResponse('User invited to team successfully', ['invitation' => self::getInvitationData($invitation)]);
        } catch (Exception $e) {
            return self::errorResponse($e->getMessage());
        }
    }

    public static function updateMemberRole($defaultResponse, $memberData, $integrationDetails)
    {
        if (!self::isPluginActive()) {
            return self::errorResponse('Teams for WooCommerce Memberships is not installed or activated');
        }

        $teamId = isset($memberData['team_id']) ? absint($memberData['team_id']) : 0;
        $userEmail = isset($memberData['user_email']) ? sanitize_email($memberData['user_email']) : '';
        $memberRole = isset($memberData['member_role']) ? sanitize_text_field($memberData['member_role']) : '';

        if (empty($teamId)) {
            return self::errorResponse('Team ID is required');
        }

        if (empty($userEmail)) {
            return self::errorResponse('User email is required');
        }

        if (empty($memberRole)) {
            return self::errorResponse('Member role is required');
        }

        $user = get_user_by('email', $userEmail);
        if (!$user) {
            return self::errorResponse('User not found with the provided email');
        }

        $team = wc_memberships_for_teams_get_team($teamId);
        if (!$team) {
            return self::errorResponse('Team not found');
        }

        if (!\function_exists('wc_memberships_for_teams_get_team_member')) {
            return self::errorResponse('Required function wc_memberships_for_teams_get_team_member does not exist');
        }

        $member = wc_memberships_for_teams_get_team_member($team, $user->ID);
        if (!$member) {
            return self::errorResponse('User is not a member of this team');
        }

        try {
            $member->set_role($memberRole);

            return self::successResponse('Member role updated successfully', ['member' => self::getTeamMemberData($member)]);
        } catch (Exception $e) {
            return self::errorResponse($e->getMessage());
        }
    }

    private static function isPluginActive()
    {
        return \function_exists('wc_memberships_for_teams')
            && \function_exists('wc_memberships_for_teams_get_team');
    }

    private static function successResponse($message, $data = [])
    {
        return [
            'success' => true,
            'message' => __($message, 'bit-integrations-pro'),
            'data'    => $data
        ];
    }

    private static function errorResponse($message)
    {
        return [
            'success' => false,
            'message' => __($message, 'bit-integrations-pro')
        ];
    }

    private static function getTeamMemberData($member)
    {
        if (!$member || !\is_object($member)) {
            return [];
        }

        return [
            'id'                   => $member->get_id(),
            'name'                 => $member->get_name(),
            'email'                => $member->get_email(),
            'team_id'              => $member->get_team_id(),
            'is_team_owner'        => $member->is_team_owner(),
            'role'                 => $member->get_role(),
            'role_label'           => $member->get_role('label'),
            'added_date'           => $member->get_added_date('mysql'),
            'user_membership_id'   => $member->get_user_membership_id(),
        ];
    }

    private static function getInvitationData($invitation)
    {
        if (!$invitation || !\is_object($invitation)) {
            return [];
        }

        $team = $invitation->get_team();

        return [
            'id'                => $invitation->get_id(),
            'email'             => $invitation->get_email(),
            'name'              => $invitation->get_name(),
            'team_id'           => $invitation->get_team_id(),
            'team_name'         => $team ? $team->get_name() : null,
            'sender_id'         => $invitation->get_sender_id(),
            'member_role'       => $invitation->get_member_role(),
            'member_role_label' => $invitation->get_member_role('label'),
            'status'            => $invitation->get_status(),
            'date'              => $invitation->get_date('mysql'),
            'token'             => $invitation->get_token(),
            'accept_url'        => $invitation->get_accept_url(),
        ];
    }
}


