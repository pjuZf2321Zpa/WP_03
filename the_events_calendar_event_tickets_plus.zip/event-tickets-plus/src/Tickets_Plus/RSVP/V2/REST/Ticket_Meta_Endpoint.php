<?php
/**
 * RSVP V2: Ticket Meta Endpoint.
 *
 * Handles IAC (Individual Attendee Collection) and attendee meta field updates.
 *
 * @since 6.11.0
 *
 * @package TEC\Tickets_Plus\RSVP\V2\REST
 */

namespace TEC\Tickets_Plus\RSVP\V2\REST;

use TEC\Tickets\Commerce\Gateways\Contracts\Abstract_REST_Endpoint;
use TEC\Tickets\Commerce\Ticket;
use TEC\Tickets\Event;
use Tribe\Tickets\Plus\Attendee_Registration\IAC;
use Tribe__Utils__Array as Arr;
use WP_Post;
use WP_REST_Request;
use WP_REST_Response;
use WP_REST_Server;

/**
 * Class Ticket_Meta_Endpoint.
 *
 * @since 6.11.0
 *
 * @package TEC\Tickets_Plus\RSVP\V2\REST
 */
class Ticket_Meta_Endpoint extends Abstract_REST_Endpoint {
	/**
	 * The REST API endpoint path.
	 *
	 * @since 6.11.0
	 *
	 * @var string
	 */
	protected string $path = '/rsvp/v2/ticket/meta';

	/**
	 * Register the actual endpoint on WP Rest API.
	 *
	 * @since 6.11.0
	 */
	public function register(): void {
		$namespace = tribe( 'tickets.rest-v1.main' )->get_events_route_namespace();

		register_rest_route(
			$namespace,
			$this->get_endpoint_path(),
			[
				'methods'             => WP_REST_Server::EDITABLE,
				'callback'            => [ $this, 'handle_update_ticket_meta' ],
				'permission_callback' => [ $this, 'check_permission' ],
			]
		);
	}

	/**
	 * Checks if the current user has the capability to edit the post.
	 *
	 * @since 6.11.0
	 *
	 * @param WP_REST_Request $request The current REST request.
	 *
	 * @return bool True if the user has the edit post capability, false otherwise.
	 */
	public function check_permission( WP_REST_Request $request ): bool {
		$post_id = $request->get_param( 'post_ID' );

		if ( empty( $post_id ) ) {
			return current_user_can( 'edit_posts' );
		}

		return current_user_can( 'edit_post', $post_id );
	}

	/**
	 * Handles the request to update IAC and attendee meta fields for existing tickets.
	 *
	 * @since 6.11.0
	 *
	 * @param WP_REST_Request $request The request object.
	 *
	 * @return WP_REST_Response The response.
	 */
	public function handle_update_ticket_meta( WP_REST_Request $request ): WP_REST_Response {
		$request_params = $request->get_params();
		$post_id        = Arr::get( $request_params, 'post_ID' );
		$ticket_id      = Arr::get( $request_params, 'ticket_id', '' );

		if ( empty( $post_id ) || empty( $ticket_id ) ) {
			return new WP_REST_Response(
				[
					'success' => false,
					'message' => __( 'Missing required post ID or ticket ID.', 'event-tickets-plus' ),
				],
				400
			);
		}

		$post_id   = Event::filter_event_id( $post_id );
		$ticket_id = absint( $ticket_id );

		$ticket_post = get_post( $ticket_id );
		if (
			! $ticket_post instanceof WP_Post
			|| (int) get_post_meta( $ticket_id, Ticket::$event_relation_meta_key, true ) !== (int) $post_id
		) {
			return new WP_REST_Response(
				[
					'success' => false,
					'message' => __( 'Ticket not found.', 'event-tickets-plus' ),
				],
				404
			);
		}

		/**
		 * Allow for processing additional IAC and attendee meta fields before updating.
		 *
		 * @since 6.11.0
		 *
		 * @param array $request_params The original request parameters.
		 * @param int   $ticket_id      The ticket ID being updated.
		 * @param int   $post_id        The post ID.
		 */
		$request_params = apply_filters( 'tec_tickets_rsvp_process_additional_fields', $request_params, $ticket_id, $post_id );

		/**
		 * Allow for additional processing after IAC and attendee meta updates.
		 *
		 * @since 6.11.0
		 *
		 * @param int   $ticket_id      The ticket ID being updated.
		 * @param int   $post_id        The post ID.
		 * @param array $request_params The original request parameters.
		 */
		do_action( 'tec_tickets_rsvp_after_meta_update', $ticket_id, $post_id, $request_params );

		// Fetch the updated field labels for the response.
		$field_labels = $this->get_field_labels_for_ticket( $ticket_id );

		return new WP_REST_Response(
			[
				'success'      => true,
				'ticket_id'    => $ticket_id,
				'field_labels' => $field_labels,
			]
		);
	}

	/**
	 * Get the field labels for a ticket.
	 *
	 * @since 6.11.0
	 *
	 * @param int $ticket_id The ticket ID.
	 *
	 * @return array Array of field labels.
	 */
	private function get_field_labels_for_ticket( int $ticket_id ): array {
		/** @var IAC $iac */
		$iac          = tribe( 'tickets-plus.attendee-registration.iac' );
		$iac_setting  = $iac->get_iac_setting_for_ticket( $ticket_id );
		$field_labels = [];

		// If IAC is active, prepend "Name" and "Email" labels.
		if ( IAC::NONE_KEY !== $iac_setting ) {
			$field_labels[] = __( 'Name', 'event-tickets-plus' );
			$field_labels[] = __( 'Email', 'event-tickets-plus' );
		}

		/** @var \Tribe__Tickets_Plus__Meta $meta */
		$meta        = tribe( 'tickets-plus.meta' );
		$meta_fields = $meta->get_meta_fields_by_ticket( $ticket_id );

		if ( ! empty( $meta_fields ) ) {
			foreach ( $meta_fields as $field ) {
				if ( ! empty( $field->label ) ) {
					$field_labels[] = $field->label;
				}
			}
		}

		return $field_labels;
	}
}
