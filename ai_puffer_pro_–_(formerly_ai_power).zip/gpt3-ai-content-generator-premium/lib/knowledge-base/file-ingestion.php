<?php

namespace WPAICG\Lib\VectorStores\FileUpload;

use WPAICG\AIPKit_Providers;
use WPAICG\Core\AIPKit_AI_Caller;
use WPAICG\Includes\AIPKit_Upload_Utils;
use WPAICG\Lib\Utils\AIPKit_File_Text_Extractor;
use WPAICG\Vector\AIPKit_Vector_Embedding_Batch_Policy;
use WPAICG\Vector\AIPKit_Vector_Text_Chunker;
use WPAICG\Utils\AIPKit_Identifier_Utils;
use WPAICG\Vector\AIPKit_Vector_Store_Manager;
use WP_Error;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Processes vector-store file uploads across short AJAX requests.
 */
class AIPKit_Vector_File_Ingestion_Job
{
    private const JOB_VERSION = 1;
    private const JOB_TTL_SECONDS = 86400;
    private const DEFAULT_BATCH_SIZE = 1;
    private const GOOGLE_BATCH_SIZE = 100;
    private const OPENAI_BATCH_SIZE = 50;
    private const OPENROUTER_BATCH_SIZE = 50;
    private const AZURE_BATCH_SIZE = 50;
    private const DEFAULT_RATE_LIMIT_RETRY_SECONDS = 30;
    private const MAX_RATE_LIMIT_RETRY_SECONDS = 300;
    private const MAX_CONSECUTIVE_RATE_LIMIT_RETRIES = 8;

    /**
     * @param array<string,mixed> $args
     * @return array<string,mixed>|WP_Error
     */
    public static function create_from_uploaded_file(array $args)
    {
        self::ensure_dependencies();
        self::cleanup_expired_jobs();

        $provider = isset($args['provider']) ? sanitize_key((string) $args['provider']) : '';
        $target_id = isset($args['target_id']) ? sanitize_text_field((string) $args['target_id']) : '';
        $embedding_provider_key = isset($args['embedding_provider_key']) ? sanitize_key((string) $args['embedding_provider_key']) : '';
        $embedding_model = isset($args['embedding_model']) ? sanitize_text_field((string) $args['embedding_model']) : '';
        $context = isset($args['context']) ? sanitize_key((string) $args['context']) : 'admin';
        $user_id = isset($args['user_id']) ? absint($args['user_id']) : get_current_user_id();
        $session_id = isset($args['session_id']) ? sanitize_text_field((string) $args['session_id']) : '';
        $bot_id = isset($args['bot_id']) ? absint($args['bot_id']) : 0;
        $log_callback = isset($args['log_callback']) && is_callable($args['log_callback']) ? $args['log_callback'] : null;

        if (!in_array($provider, ['pinecone', 'qdrant', 'chroma', 'local'], true)) {
            return new WP_Error('invalid_vector_file_provider', __('Unsupported vector provider for file ingestion.', 'gpt3-ai-content-generator'), ['status' => 400]);
        }
        if ($provider === 'local') {
            if (!class_exists(\WPAICG\Vector\Providers\AIPKit_Vector_Local_Strategy::class)) {
                require_once WPAICG_PLUGIN_DIR . 'classes/knowledge-base/providers/local.php';
            }
            $store = (new \WPAICG\Vector\Providers\AIPKit_Vector_Local_Strategy())->get_store(\WPAICG\Vector\Providers\AIPKit_Vector_Local_Strategy::store_id($target_id));
            if (!$store) {
                return new WP_Error('missing_vector_file_target', __('Knowledge base not found.', 'gpt3-ai-content-generator'), ['status' => 404]);
            }
            $target_id = (string) $store['id'];
            $target_name = (string) $store['name'];
        }
        if ($target_id === '') {
            return new WP_Error('missing_vector_file_target', __('Target index or collection is required.', 'gpt3-ai-content-generator'), ['status' => 400]);
        }
        if ($embedding_provider_key === '' || $embedding_model === '') {
            return new WP_Error('missing_vector_file_embedding_config', __('Embedding provider and model are required.', 'gpt3-ai-content-generator'), ['status' => 400]);
        }
        if (empty($args['file_data']) || !is_array($args['file_data'])) {
            return new WP_Error('missing_vector_file_upload', __('No file provided.', 'gpt3-ai-content-generator'), ['status' => 400]);
        }

        $file_data = $args['file_data'];
        $file_name = sanitize_file_name((string) ($file_data['name'] ?? 'upload'));
        $provider_label = self::provider_label($provider);
        $base_log = [
            'provider' => $provider_label,
            'vector_store_id' => $target_id,
            'vector_store_name' => $target_name ?? $target_id,
            'embedding_provider' => $embedding_provider_key,
            'embedding_model' => $embedding_model,
            'indexed_content' => $file_name,
            'post_title' => $file_name,
            'source_type_for_log' => self::base_source_type($provider, $context),
        ];

        if (!class_exists(AIPKit_Upload_Utils::class)) {
            return new WP_Error('upload_util_missing_vector_file_job', __('Upload utility is missing.', 'gpt3-ai-content-generator'), ['status' => 500]);
        }

        $upload_limits = AIPKit_Upload_Utils::get_effective_upload_limit_summary();
        $allowed_mime_types = isset($args['allowed_mime_types']) && is_array($args['allowed_mime_types'])
            ? $args['allowed_mime_types']
            : AIPKit_Upload_Utils::get_vector_upload_allowed_mime_types();
        $limit_bytes = isset($args['upload_limit_bytes'])
            ? (int) $args['upload_limit_bytes']
            : (int) ($upload_limits['limit_bytes'] ?? 0);
        $validation_error = AIPKit_Upload_Utils::validate_upload_file($file_data, $allowed_mime_types, $limit_bytes);
        if (is_wp_error($validation_error)) {
            $validation_error->add_data([
                'where' => $provider . '_file_ingestion:validation',
                'limit_bytes' => $limit_bytes,
            ]);
            return $validation_error;
        }

        $extractor = new AIPKit_File_Text_Extractor();
        $extracted_text = $extractor->extract($file_data);
        if (is_wp_error($extracted_text)) {
            self::log($log_callback, array_merge($base_log, [
                'status' => 'content_error',
                'message' => 'File extraction failed: ' . $extracted_text->get_error_message(),
            ]));
            return new WP_Error('vector_file_extraction_failed', 'File extraction failed: ' . $extracted_text->get_error_message(), ['status' => 500]);
        }
        if ($extracted_text === '' || trim($extracted_text) === '') {
            self::log($log_callback, array_merge($base_log, [
                'status' => 'content_error',
                'message' => 'Could not read file content or file is empty.',
            ]));
            return new WP_Error('vector_file_empty_content', __('Could not read file content or file is empty.', 'gpt3-ai-content-generator'), ['status' => 500]);
        }

        $embedding_provider_norm = AIPKit_Providers::resolve_embedding_provider_name(
            $embedding_provider_key,
            $provider . '_file_ingestion_job'
        );
        if (!is_string($embedding_provider_norm) || $embedding_provider_norm === '') {
            self::log($log_callback, array_merge($base_log, [
                'status' => 'failed',
                'message' => 'Invalid embedding provider for file ingestion.',
            ]));
            return new WP_Error('invalid_vector_file_embedding_provider', __('Invalid embedding provider for file ingestion.', 'gpt3-ai-content-generator'), ['status' => 400]);
        }

        $chunks = AIPKit_Vector_Text_Chunker::chunk_for_embeddings(
            $extracted_text,
            $embedding_model,
            $embedding_provider_key,
            $target_id,
            $provider
        );
        if (empty($chunks)) {
            return new WP_Error('vector_file_empty_chunks', __('Could not prepare file chunks for ingestion.', 'gpt3-ai-content-generator'), ['status' => 500]);
        }

        $timestamp = time();
        $context_id = self::build_context_id($provider, $context, $file_name, $user_id, $session_id, $timestamp);
        $batch_id = self::build_batch_id($provider, $file_name, $context_id, $timestamp);
        $job_id = wp_generate_uuid4();
        $job = [
            'version' => self::JOB_VERSION,
            'job_id' => $job_id,
            'status' => 'processing',
            'provider' => $provider,
            'provider_label' => $provider_label,
            'target_id' => $target_id,
            'target_name' => $target_name ?? $target_id,
            'embedding_provider_key' => $embedding_provider_key,
            'embedding_provider_norm' => $embedding_provider_norm,
            'embedding_model' => $embedding_model,
            'file_name' => $file_name,
            'context' => $context,
            'context_id' => $context_id,
            'batch_id' => $batch_id,
            'user_id' => $user_id,
            'session_id' => $session_id,
            'bot_id' => $bot_id,
            'conversation_uuid' => sanitize_key((string) ($args['conversation_uuid'] ?? '')),
            'timestamp' => $timestamp,
            'uploaded_at' => current_time('mysql', 1),
            'created_at' => time(),
            'updated_at' => time(),
            'processed_chunks' => 0,
            'total_chunks' => count($chunks),
            'chunks' => array_values($chunks),
        ];

        $saved = self::save_job($job);
        if (is_wp_error($saved)) {
            return $saved;
        }

        return self::progress_response($job, __('File prepared. Processing chunks...', 'gpt3-ai-content-generator'));
    }

    /**
     * @param callable|null $log_callback
     * @return array<string,mixed>|WP_Error
     */
    public static function process_job(
        string $job_id,
        AIPKit_Vector_Store_Manager $vector_store_manager,
        AIPKit_AI_Caller $ai_caller,
        array $provider_config,
        ?callable $log_callback = null,
        array $binding = []
    ) {
        self::ensure_dependencies();
        $path = self::job_path($job_id);
        if ($path === '' || !is_file($path)) { return self::load_job($job_id); }
        // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fopen -- A local handle is required for nonblocking flock(); the job path is validated and confined to the ingestion directory.
        $lock = @fopen($path . '.lock', 'c');
        if (!$lock) { return new WP_Error('vector_file_job_lock_failed', __('Could not lock the file job. Please try again.', 'gpt3-ai-content-generator'), ['status' => 500, 'stop_batch' => true]); }
        try {
            if (!flock($lock, LOCK_EX | LOCK_NB)) {
                return new WP_Error('vector_file_job_busy', __('This file is already being processed. Wait for it to finish before retrying.', 'gpt3-ai-content-generator'), ['status' => 409, 'stop_batch' => true]);
            }
            return self::process_locked_job($job_id, $vector_store_manager, $ai_caller, $provider_config, $log_callback, $binding);
        } finally {
            flock($lock, LOCK_UN);
            // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose -- Close the flock() handle after releasing the ingestion lock.
            fclose($lock);
        }
    }

    private static function process_locked_job(string $job_id, AIPKit_Vector_Store_Manager $vector_store_manager, AIPKit_AI_Caller $ai_caller, array $provider_config, ?callable $log_callback, array $binding)
    {
        $job = self::load_job($job_id);
        if (is_wp_error($job)) { return $job; }
        if (self::is_chat_context($job)) {
            foreach (['user_id', 'session_id', 'bot_id', 'conversation_uuid'] as $key) {
                if (!array_key_exists($key, $binding) || (string) ($job[$key] ?? '') !== (string) $binding[$key]) {
                    return new WP_Error('vector_file_job_forbidden', __('This upload belongs to another conversation.', 'gpt3-ai-content-generator'), ['status' => 403, 'stop_batch' => true]);
                }
            }
        } elseif ((int) ($job['user_id'] ?? 0) !== get_current_user_id()) {
            return new WP_Error('vector_file_job_forbidden', __('This upload belongs to another user.', 'gpt3-ai-content-generator'), ['status' => 403, 'stop_batch' => true]);
        }
        $total_chunks = (int) ($job['total_chunks'] ?? 0);
        $processed_chunks = (int) ($job['processed_chunks'] ?? 0);
        if ($total_chunks <= 0 || empty($job['chunks']) || !is_array($job['chunks'])) {
            return new WP_Error('invalid_vector_file_job', __('The file ingestion job is invalid.', 'gpt3-ai-content-generator'), ['status' => 500, 'stop_batch' => true]);
        }
        // Keep completed jobs until expiry so a lost final response can be read safely.
        if ($processed_chunks >= $total_chunks) {
            return self::complete_response($job, __('File content embedded and indexed successfully.', 'gpt3-ai-content-generator'));
        }
        if (!empty($job['blocked_error'])) {
            $error = $job['blocked_error'];
            return new WP_Error($error['code'], $error['message'], $error['data']);
        }
        if (!empty($job['embedding_in_progress'])) {
            return new WP_Error('vector_file_embedding_outcome_unknown', __('The embedding request was interrupted and may have completed. Check usage before starting a new upload.', 'gpt3-ai-content-generator'), ['status' => 409, 'stop_batch' => true, 'outcome_unknown' => true]);
        }
        $retry_after = self::rate_limit_delay_remaining($job);
        if ($retry_after > 0) {
            return self::progress_response($job, sprintf(
                /* translators: %d: Number of seconds until retry. */
                __('Embedding provider is rate limited. Retrying in %d seconds...', 'gpt3-ai-content-generator'), $retry_after
            ), 0, $retry_after);
        }

        $records = $job['pending_records'] ?? [];
        if (!$records) {
            $batch = array_slice($job['chunks'], $processed_chunks, self::get_batch_size($job));
            $job['embedding_in_progress'] = true;
            $saved = self::save_job($job);
            if (is_wp_error($saved)) { return $saved; }
            $embeddings = self::generate_embeddings_for_batch($ai_caller, $job, $batch, $provider_config);
            unset($job['embedding_in_progress']);
            if (is_wp_error($embeddings)) {
                $error_data = (array) $embeddings->get_error_data();
                if (!empty($error_data['outcome_unknown'])) {
                    $job['blocked_error'] = ['code' => $embeddings->get_error_code(), 'message' => $embeddings->get_error_message(), 'data' => $error_data];
                }
                $saved = self::save_job($job);
                if (is_wp_error($saved)) { return $saved; }
                if (empty($error_data['outcome_unknown'])) {
                    $deferred_response = self::defer_rate_limited_job($job, $embeddings);
                    if ($deferred_response !== null) { return $deferred_response; }
                }
                self::log($log_callback, self::error_log_data($job, 'Embedding failed: ' . $embeddings->get_error_message(), $processed_chunks));
                return $embeddings;
            }
            $records = self::build_records_for_batch($job, $batch, $embeddings);
            $job['pending_records'] = $records;
            $saved = self::save_job($job);
            if (is_wp_error($saved)) { return $saved; }
        }

        $upsert_result = $vector_store_manager->upsert_vectors((string) $job['provider_label'], (string) $job['target_id'], self::build_upsert_payload($job, $records), $provider_config);
        if (is_wp_error($upsert_result)) {
            self::log($log_callback, self::error_log_data($job, 'Upsert failed: ' . $upsert_result->get_error_message(), $processed_chunks));
            return new WP_Error('vector_file_upsert_failed', 'Upsert failed: ' . $upsert_result->get_error_message(), [
                'status' => 500,
                'details' => ['stage' => 'upsert', 'provider' => $job['provider'], 'processed_chunks' => $processed_chunks, 'batch_size' => count($records)],
            ]);
        }
        $job['processed_chunks'] = min($total_chunks, $processed_chunks + count($records));
        $job['updated_at'] = time();
        $job['last_result'] = $upsert_result;
        unset($job['pending_records'], $job['retry_after_until'], $job['rate_limit_retry_count'], $job['last_rate_limit_error']);
        $saved = self::save_job($job);
        if (is_wp_error($saved)) { return $saved; }
        foreach ($records as $record) { self::log($log_callback, self::indexed_log_data($job, $record)); }
        if ((int) $job['processed_chunks'] >= $total_chunks) {
            if (self::is_chat_context($job)) { self::log($log_callback, self::chat_success_log_data($job, $records)); }
            return self::complete_response($job, __('File content embedded and indexed successfully.', 'gpt3-ai-content-generator'));
        }
        return self::progress_response($job, __('Processing file chunks...', 'gpt3-ai-content-generator'), count($records));
    }

    public static function delete_job(string $job_id): void
    {
        $path = self::job_path($job_id);
        if ($path && file_exists($path)) {
            $job = json_decode((string) file_get_contents($path), true);
            if (is_array($job) && ($job['context'] ?? '') === 'chat' && ($job['provider'] ?? '') === 'local'
                && !empty($job['target_id']) && !empty($job['context_id'])) {
                $deleted = (new AIPKit_Vector_Store_Manager())->delete_vectors('Local', $job['target_id'], [
                    'filter' => ['must' => [['key' => 'file_upload_context_id', 'match' => ['value' => $job['context_id']]]]],
                ], []);
                if (is_wp_error($deleted) && $deleted->get_error_code() !== 'local_store_not_found') { return; }
                global $wpdb;
                // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Remove the expired visitor upload's own source records.
                $wpdb->delete($wpdb->prefix . 'aipkit_vector_data_source', [
                    'provider' => 'Local', 'vector_store_id' => $job['target_id'], 'batch_id' => $job['batch_id'],
                ]);
            }
            wp_delete_file($path);
            wp_delete_file($path . '.lock');
            wp_delete_file($path . '.tmp');
        }
    }

    /**
     * @param array<string,mixed> $job
     */
    private static function get_batch_size(array $job): int
    {
        $provider = strtolower((string) ($job['embedding_provider_norm'] ?? ''));
        switch ($provider) {
            case 'google':
                $fallback = self::GOOGLE_BATCH_SIZE;
                break;
            case 'openai':
                $fallback = self::OPENAI_BATCH_SIZE;
                break;
            case 'openrouter':
                $fallback = self::OPENROUTER_BATCH_SIZE;
                break;
            case 'azure':
                $fallback = self::AZURE_BATCH_SIZE;
                break;
            case 'ollama':
                $fallback = self::DEFAULT_BATCH_SIZE;
                break;
            default:
                $fallback = 1;
                break;
        }
        $default = class_exists(AIPKit_Vector_Embedding_Batch_Policy::class)
            ? AIPKit_Vector_Embedding_Batch_Policy::resolve_batch_size(
                $provider,
                [
                    'source' => 'file_ingestion',
                    'allow_custom' => true,
                    'vector_provider' => (string) ($job['provider_label'] ?? $job['provider'] ?? ''),
                    'embedding_model' => (string) ($job['embedding_model'] ?? ''),
                    'target_id' => (string) ($job['target_id'] ?? ''),
                    'context' => (string) ($job['context'] ?? ''),
                ],
                $fallback
            )
            : $fallback;
        $batch_size = (int) apply_filters('aipkit_vector_file_ingestion_batch_size', $default, $job);
        switch ($provider) {
            case 'google':
                $max_batch_size = self::GOOGLE_BATCH_SIZE;
                break;
            case 'openai':
                $max_batch_size = self::OPENAI_BATCH_SIZE;
                break;
            case 'openrouter':
                $max_batch_size = self::OPENROUTER_BATCH_SIZE;
                break;
            case 'azure':
                $max_batch_size = self::AZURE_BATCH_SIZE;
                break;
            default:
                $max_batch_size = self::DEFAULT_BATCH_SIZE;
                break;
        }
        return max(1, min($max_batch_size, $batch_size));
    }

    /**
     * @param array<string,mixed> $job
     * @param array<int,array<string,mixed>> $chunks
     * @return array<int,array<int|float>>|WP_Error
     */
    private static function generate_embeddings_for_batch(AIPKit_AI_Caller $ai_caller, array $job, array $chunks, array $provider_config)
    {
        $embedding_options = (new AIPKit_Vector_Store_Manager())->embedding_options((string) $job['embedding_provider_norm'], (string) $job['embedding_model'], (string) $job['provider_label'], [(string) $job['target_id']], $provider_config);
        if (is_wp_error($embedding_options)) { return $embedding_options; }
        $provider_norm = (string) $job['embedding_provider_norm'];

        $texts = array_map(static fn($chunk) => (string) ($chunk['text'] ?? ''), $chunks);
        $result = $ai_caller->generate_embeddings($provider_norm, count($texts) === 1 ? $texts[0] : $texts, $embedding_options);
        if (is_wp_error($result)) { return self::wrap_embedding_error($result, $job, $chunks[0] ?? [], count($chunks)); }
        $vectors = $result['embeddings'] ?? null;
        if (is_array($vectors) && count($vectors) === count($chunks)) {
            $valid = true;
            foreach ($vectors as $vector) {
                if (!is_array($vector) || !$vector || count(array_filter($vector, static fn($value) => is_numeric($value) && is_finite((float) $value))) !== count($vector)) { $valid = false; break; }
            }
            if ($valid) { return array_values($vectors); }
        }
        return new WP_Error('vector_file_embedding_empty', __('The embedding response could not be used. Check usage before starting a new upload.', 'gpt3-ai-content-generator'), ['status' => 502, 'stop_batch' => true, 'outcome_unknown' => true]);
    }

    /**
     * @param array<string,mixed> $job
     * @param array<string,mixed> $chunk
     */
    private static function wrap_embedding_error(WP_Error $source_error, array $job, array $chunk, int $batch_size): WP_Error
    {
        $source_data = $source_error->get_error_data();
        $source_data = is_array($source_data) ? $source_data : [];
        $retry_after = self::rate_limit_retry_after($source_error);
        $status = (int) ($source_data['status_code'] ?? $source_data['status'] ?? ($retry_after > 0 ? 429 : 500));

        $data = array_merge(array_intersect_key($source_data, array_flip(['cloud_operation_id', 'cloud_request_id', 'cloud_request_state', 'outcome_unknown'])), AIPKit_AI_Caller::batch_error_data($source_error), [
            'status' => $status,
            'details' => [
                'stage' => 'embed',
                'provider' => (string) ($job['embedding_provider_norm'] ?? ''),
                'model' => $job['embedding_model'],
                'chunk_index' => (int) ($chunk['index'] ?? 0),
                'batch_size' => $batch_size,
                'provider_error_code' => $source_error->get_error_code(),
            ],
        ]);
        if ($retry_after > 0) {
            $data['retry_after'] = $retry_after;
            $data['details']['retry_after'] = $retry_after;
        }

        return new WP_Error('vector_file_embedding_failed', $source_error->get_error_message(), $data);
    }

    /**
     * @param array<string,mixed> $job
     * @return mixed[]|\WP_Error|null
     */
    private static function defer_rate_limited_job(array $job, WP_Error $error)
    {
        $retry_after = self::rate_limit_retry_after($error);
        if ($retry_after <= 0) {
            return null;
        }

        $retry_count = (int) ($job['rate_limit_retry_count'] ?? 0) + 1;
        if ($retry_count > self::MAX_CONSECUTIVE_RATE_LIMIT_RETRIES) {
            return $error;
        }

        $retry_after = max(1, min(self::MAX_RATE_LIMIT_RETRY_SECONDS, $retry_after));
        $job['rate_limit_retry_count'] = $retry_count;
        $job['retry_after_until'] = time() + $retry_after;
        $job['last_rate_limit_error'] = $error->get_error_message();
        $job['updated_at'] = time();

        $saved = self::save_job($job);
        if (is_wp_error($saved)) {
            return $saved;
        }

        return self::progress_response(
            $job,
            sprintf(
                /* translators: %d: Number of seconds until retry. */
                __('Embedding provider rate limit reached. Retrying in %d seconds...', 'gpt3-ai-content-generator'),
                $retry_after
            ),
            0,
            $retry_after
        );
    }

    /**
     * @param array<string,mixed> $job
     */
    private static function rate_limit_delay_remaining(array $job): int
    {
        $retry_until = (int) ($job['retry_after_until'] ?? 0);
        if ($retry_until <= time()) {
            return 0;
        }
        return min(self::MAX_RATE_LIMIT_RETRY_SECONDS, $retry_until - time());
    }

    private static function rate_limit_retry_after(WP_Error $error): int
    {
        $data = $error->get_error_data();
        $data = is_array($data) ? $data : [];
        $status = (int) ($data['status_code'] ?? $data['status'] ?? 0);
        if (!empty($data['outcome_unknown']) || AIPKit_AI_Caller::batch_error_data($error)['pause_task']) { return 0; }
        $message = $error->get_error_message();
        $is_rate_limited = $status === 429
            || stripos($message, 'rate limit') !== false
            || stripos($message, 'RateLimitReached') !== false
            || preg_match('/\b429\b/', $message) === 1;

        if (!$is_rate_limited) {
            return 0;
        }

        $retry_after = 0;
        if (isset($data['retry_after']) && is_numeric($data['retry_after'])) {
            $retry_after = (int) ceil((float) $data['retry_after']);
        }
        if ($retry_after <= 0 && preg_match('/retry after\s+(\d+)/i', $message, $matches)) {
            $retry_after = (int) $matches[1];
        }
        if ($retry_after <= 0 && preg_match('/try again in\s+(\d+)/i', $message, $matches)) {
            $retry_after = (int) $matches[1];
        }
        if ($retry_after <= 0) {
            $retry_after = self::DEFAULT_RATE_LIMIT_RETRY_SECONDS;
        }

        return max(1, min(self::MAX_RATE_LIMIT_RETRY_SECONDS, $retry_after));
    }

    /**
     * @param array<string,mixed> $job
     * @param array<int,array<string,mixed>> $chunks
     * @param array<int,array<int|float>> $embeddings
     * @return array<int,array<string,mixed>>
     */
    private static function build_records_for_batch(array $job, array $chunks, array $embeddings): array
    {
        $records = [];
        foreach ($chunks as $offset => $chunk) {
            $text = (string) ($chunk['text'] ?? '');
            $chunk_index = (int) ($chunk['index'] ?? 0);
            $vector_id = self::build_vector_id($job, $chunk_index);
            $records[] = [
                'id' => $vector_id,
                'values' => $embeddings[$offset] ?? [],
                'text' => $text,
                'index' => $chunk_index,
                'start' => (int) ($chunk['start'] ?? 0),
                'end' => (int) ($chunk['end'] ?? 0),
            ];
        }
        return $records;
    }

    /**
     * @param array<string,mixed> $job
     * @param array<int,array<string,mixed>> $records
     * @return array<string,mixed>|array<int,array<string,mixed>>
     */
    private static function build_upsert_payload(array $job, array $records): array
    {
        if ((string) $job['provider'] === 'pinecone') {
            $vectors = [];
            foreach ($records as $record) {
                $vectors[] = [
                    'id' => $record['id'],
                    'values' => $record['values'],
                    'metadata' => self::metadata_for_record($job, $record),
                ];
            }
            $payload = ['vectors' => $vectors];
            if (self::is_chat_context($job)) {
                $payload['namespace'] = (string) $job['context_id'];
            }
            return $payload;
        }

        $points = [];
        foreach ($records as $record) {
            $point = [
                'id' => $record['id'],
                'vector' => $record['values'],
                'payload' => self::metadata_for_record($job, $record),
            ];
            if ((string) $job['provider'] === 'chroma') {
                $point['document'] = (string) $record['text'];
            }
            $points[] = $point;
        }
        return ['points' => $points];
    }

    /**
     * @param array<string,mixed> $job
     * @param array<string,mixed> $record
     * @return array<string,mixed>
     */
    private static function metadata_for_record(array $job, array $record): array
    {
        $chunk_index = (int) $record['index'];
        if (self::is_chat_context($job)) {
            $metadata = [
                'source' => 'chat_file_upload',
                'original_filename' => (string) $job['file_name'],
                'file_upload_context_id' => (string) $job['context_id'],
                'session_id' => (string) ($job['session_id'] ?? ''),
                'timestamp' => (int) $job['timestamp'],
                'chunk_index' => $chunk_index,
                'total_chunks' => (int) $job['total_chunks'],
                'char_start' => (int) $record['start'],
                'char_end' => (int) $record['end'],
            ];
            if (!empty($job['user_id'])) {
                $metadata['user_id'] = (string) $job['user_id'];
            }
            if (in_array((string) $job['provider'], ['qdrant', 'local'], true)) {
                $metadata['original_content'] = (string) $record['text'];
            }
            return $metadata;
        }

        $metadata = [
            'source' => 'file_upload_global_form',
            'filename' => (string) $job['file_name'],
            'uploaded_at' => (string) $job['uploaded_at'],
            'vector_id' => (string) $record['id'],
            'chunk_index' => $chunk_index,
            'total_chunks' => (int) $job['total_chunks'],
            'char_start' => (int) $record['start'],
            'char_end' => (int) $record['end'],
        ];
        if ((string) $job['provider'] === 'local') {
            // The built-in store keeps chunk text next to its vector.
            $metadata['original_content'] = (string) $record['text'];
            $metadata['title'] = (string) $job['file_name'];
        }
        return $metadata;
    }

    /**
     * @param array<string,mixed> $job
     */
    private static function build_vector_id(array $job, int $chunk_index): string
    {
        if ((string) $job['provider'] === 'qdrant') {
            return wp_generate_uuid4();
        }

        if (self::is_chat_context($job)) {
            return 'chatfile_' . hash('md5', (string) $job['file_name'] . '|' . (string) $job['context_id'] . '|' . $chunk_index) . '_' . (int) $job['timestamp'];
        }

        $prefixes = ['chroma' => 'chroma_file_', 'local' => 'local_file_'];
        $prefix = $prefixes[(string) $job['provider']] ?? 'pinecone_file_';
        return $prefix . hash('md5', (string) $job['file_name'] . $chunk_index) . '_' . (int) $job['timestamp'];
    }

    /**
     * @param array<string,mixed> $job
     * @param array<string,mixed> $record
     * @return array<string,mixed>
     */
    private static function indexed_log_data(array $job, array $record): array
    {
        $safe_content = function_exists('wp_strip_all_tags') ? wp_strip_all_tags((string) $record['text']) : (string) $record['text'];
        $chunk_number = (int) $record['index'] + 1;
        return [
            'provider' => (string) $job['provider_label'],
            'vector_store_id' => (string) $job['target_id'],
            'vector_store_name' => (string) $job['target_name'],
            'status' => 'indexed',
            'message' => sprintf('File chunk embedded (chunk %d/%d) for %s', $chunk_number, (int) $job['total_chunks'], (string) $job['file_name']),
            'embedding_provider' => (string) $job['embedding_provider_key'],
            'embedding_model' => (string) $job['embedding_model'],
            'indexed_content' => $safe_content,
            'file_id' => (string) $record['id'],
            'batch_id' => (string) $job['batch_id'],
            'post_title' => (string) $job['file_name'],
            'source_type_for_log' => self::chunk_source_type($job),
        ];
    }

    /**
     * @param array<string,mixed> $job
     * @return array<string,mixed>
     */
    private static function error_log_data(array $job, string $message, int $chunk_offset): array
    {
        return [
            'provider' => (string) $job['provider_label'],
            'vector_store_id' => (string) $job['target_id'],
            'vector_store_name' => (string) $job['target_name'],
            'status' => 'failed',
            'message' => $message,
            'embedding_provider' => (string) $job['embedding_provider_key'],
            'embedding_model' => (string) $job['embedding_model'],
            'indexed_content' => 'chunk_' . $chunk_offset . ' of ' . (int) $job['total_chunks'] . ' for ' . (string) $job['file_name'],
            'post_title' => (string) $job['file_name'],
            'source_type_for_log' => self::base_source_type((string) $job['provider'], (string) $job['context']),
            'batch_id' => (string) $job['batch_id'],
        ];
    }

    /**
     * @param array<string,mixed> $job
     * @param array<int,array<string,mixed>> $records
     * @return array<string,mixed>
     */
    private static function chat_success_log_data(array $job, array $records): array
    {
        $first_record = $records[0] ?? [];
        $context_label = (string) $job['context_id'];
        $scope = (string) $job['provider'] === 'pinecone' ? 'Namespace' : 'Context ID';
        return [
            'provider' => (string) $job['provider_label'],
            'vector_store_id' => (string) $job['target_id'],
            'vector_store_name' => (string) $job['target_name'],
            'status' => 'success',
            'message' => sprintf('File content embedded and upserted to %s for chat. Chunk count: %d, %s: %s', (string) $job['provider_label'], (int) $job['total_chunks'], $scope, $context_label),
            'embedding_provider' => (string) $job['embedding_provider_key'],
            'embedding_model' => (string) $job['embedding_model'],
            'indexed_content' => 'chunked_upload:' . (string) $job['file_name'],
            'file_id' => isset($first_record['id']) ? (string) $first_record['id'] : null,
            'post_title' => (string) $job['file_name'],
            'source_type_for_log' => self::base_source_type((string) $job['provider'], (string) $job['context']),
            'batch_id' => (string) $job['batch_id'],
        ];
    }

    /**
     * @param array<string,mixed> $job
     * @return array<string,mixed>
     */
    private static function progress_response(array $job, string $message, int $processed_this_batch = 0, int $retry_after = 0): array
    {
        $total = max(1, (int) ($job['total_chunks'] ?? 0));
        $processed = (int) ($job['processed_chunks'] ?? 0);
        $response = [
            'status' => 'processing',
            'job_id' => (string) $job['job_id'],
            'message' => $message,
            'processed_chunks' => $processed,
            'processed_this_batch' => $processed_this_batch,
            'total_chunks' => $total,
            'percent' => min(99, (int) floor(($processed / $total) * 100)),
        ];
        if ($retry_after > 0) {
            $response['retry_after'] = $retry_after;
        }
        return $response;
    }

    /**
     * @param array<string,mixed> $job
     * @return array<string,mixed>
     */
    private static function complete_response(array $job, string $message): array
    {
        $response = [
            'status' => 'complete',
            'job_id' => (string) $job['job_id'],
            'message' => $message,
            'processed_chunks' => (int) $job['total_chunks'],
            'total_chunks' => (int) $job['total_chunks'],
            'percent' => 100,
            'result' => $job['last_result'] ?? [],
        ];

        if (self::is_chat_context($job)) {
            if ((string) $job['provider'] === 'pinecone') {
                $response['file_context'] = [
                    'provider' => 'Pinecone',
                    'index_name' => (string) $job['target_id'],
                    'namespace' => (string) $job['context_id'],
                    'original_filename' => (string) $job['file_name'],
                ];
            } elseif ((string) $job['provider'] === 'qdrant') {
                $response['file_context'] = [
                    'provider' => 'Qdrant',
                    'collection_name' => (string) $job['target_id'],
                    'file_upload_context_id' => (string) $job['context_id'],
                    'original_filename' => (string) $job['file_name'],
                ];
            } else {
                $response['file_context'] = [
                    'provider' => (string) $job['provider_label'],
                    'collection_name' => (string) $job['target_id'],
                    'file_upload_context_id' => (string) $job['context_id'],
                    'original_filename' => (string) $job['file_name'],
                ];
            }
        }

        return $response;
    }

    private static function ensure_dependencies(): void
    {
        $files = [
            AIPKit_Providers::class => WPAICG_PLUGIN_DIR . 'classes/ai/settings.php',
            AIPKit_Upload_Utils::class => WPAICG_PLUGIN_DIR . 'classes/security/uploads.php',
            AIPKit_File_Text_Extractor::class => WPAICG_LIB_DIR . 'knowledge-base/file-extractor.php',
            AIPKit_Vector_Text_Chunker::class => WPAICG_PLUGIN_DIR . 'classes/knowledge-base/chunker.php',
            AIPKit_Vector_Embedding_Batch_Policy::class => WPAICG_PLUGIN_DIR . 'classes/knowledge-base/embedding-batches.php',
            AIPKit_Identifier_Utils::class => WPAICG_LIB_DIR . 'knowledge-base/upload-context.php',
            AIPKit_Vector_File_Ingestion_Batch_Settings::class => WPAICG_LIB_DIR . 'knowledge-base/ingestion-settings.php',
        ];

        foreach ($files as $class => $path) {
            if (!class_exists($class) && file_exists($path)) {
                require_once $path;
            }
        }
    }

    private static function job_dir(): string
    {
        $dir = trailingslashit(get_temp_dir()) . 'aipkit-vector-jobs/';
        if (!is_dir($dir)) {
            wp_mkdir_p($dir);
        }
        $index_file = $dir . 'index.php';
        if (!file_exists($index_file)) {
            @file_put_contents($index_file, "<?php\n// Silence is golden.\n");
        }
        $htaccess_file = $dir . '.htaccess';
        if (!file_exists($htaccess_file)) {
            @file_put_contents($htaccess_file, "Deny from all\n");
        }
        return $dir;
    }

    private static function job_path(string $job_id): string
    {
        $safe_job_id = preg_replace('/[^a-zA-Z0-9_-]/', '', $job_id);
        if (!is_string($safe_job_id) || $safe_job_id === '') {
            return '';
        }
        return self::job_dir() . $safe_job_id . '.json';
    }

    /**
     * @param array<string,mixed> $job
     * @return bool|\WP_Error
     */
    private static function save_job(array $job)
    {
        $path = self::job_path((string) ($job['job_id'] ?? ''));
        if ($path === '') {
            return new WP_Error('invalid_vector_file_job_id', __('Invalid file ingestion job ID.', 'gpt3-ai-content-generator'), ['status' => 500]);
        }

        $encoded = wp_json_encode($job);
        if (!is_string($encoded)) {
            return new WP_Error('vector_file_job_encode_failed', __('Could not save file ingestion job.', 'gpt3-ai-content-generator'), ['status' => 500]);
        }
        $temporary = $path . '.tmp';
        $saved = @file_put_contents($temporary, $encoded, LOCK_EX);
        // phpcs:ignore WordPress.WP.AlternativeFunctions.rename_rename -- Same-directory atomic replacement preserves the last complete receipt after a crash; a filesystem copy/delete would not.
        if ($saved !== strlen($encoded) || !@rename($temporary, $path)) {
            wp_delete_file($temporary);
            return new WP_Error('vector_file_job_save_failed', __('Could not write file ingestion job.', 'gpt3-ai-content-generator'), ['status' => 500]);
        }
        return true;
    }

    /**
     * @return array<string,mixed>|WP_Error
     */
    private static function load_job(string $job_id)
    {
        $path = self::job_path($job_id);
        if ($path === '' || !file_exists($path)) {
            return new WP_Error('vector_file_job_not_found', __('The file ingestion job was not found or has expired.', 'gpt3-ai-content-generator'), ['status' => 404]);
        }
        $raw = @file_get_contents($path);
        if (!is_string($raw) || $raw === '') {
            return new WP_Error('vector_file_job_read_failed', __('Could not read file ingestion job.', 'gpt3-ai-content-generator'), ['status' => 500]);
        }
        $job = json_decode($raw, true);
        if (!is_array($job)) {
            return new WP_Error('vector_file_job_decode_failed', __('Could not decode file ingestion job.', 'gpt3-ai-content-generator'), ['status' => 500]);
        }
        if (!empty($job['created_at']) && ((int) $job['created_at'] + self::JOB_TTL_SECONDS) < time()) {
            self::delete_job($job_id);
            return new WP_Error('vector_file_job_expired', __('The file ingestion job has expired.', 'gpt3-ai-content-generator'), ['status' => 410]);
        }
        return $job;
    }

    private static function cleanup_expired_jobs(): void
    {
        $files = glob(self::job_dir() . '*.json');
        if (!is_array($files)) {
            return;
        }
        $cutoff = time() - self::JOB_TTL_SECONDS;
        foreach ($files as $file) {
            if (is_string($file) && @filemtime($file) < $cutoff) {
                // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fopen -- A local handle is required for nonblocking flock(); the job path is validated and confined to the ingestion directory.
                $lock = @fopen($file . '.lock', 'c');
                if ($lock) {
                    if (flock($lock, LOCK_EX | LOCK_NB)) {
                        clearstatcache(true, $file);
                        if (@filemtime($file) < $cutoff) { self::delete_job(basename($file, '.json')); }
                        flock($lock, LOCK_UN);
                    }
                    // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose -- Close the flock() handle after releasing the ingestion lock.
                    fclose($lock);
                }
            }
        }
    }

    private static function build_context_id(string $provider, string $context, string $file_name, int $user_id, string $session_id, int $timestamp): string
    {
        if ($context === 'chat') {
            $prefixes = [
                'pinecone' => 'pinecone_chat_file_',
                'qdrant' => 'qdrant_chat_file_',
                'chroma' => 'chroma_chat_file_',
                'local' => 'local_chat_file_',
            ];
            $prefix = $prefixes[$provider] ?? 'pinecone_chat_file_';
            if (class_exists(AIPKit_Identifier_Utils::class)) {
                return AIPKit_Identifier_Utils::generate_chat_context_identifier($user_id ?: null, $session_id ?: null, $prefix);
            }
            return $prefix . hash('md5', $file_name . '|' . $user_id . '|' . $session_id . '|' . $timestamp);
        }
        return $provider . '_file_' . hash('md5', $file_name . '|' . (string) wp_rand()) . '_' . $timestamp;
    }

    private static function build_batch_id(string $provider, string $file_name, string $context_id, int $timestamp): string
    {
        if (strncmp($context_id, 'pinecone_chat_file_', strlen('pinecone_chat_file_')) === 0 || strncmp($context_id, 'qdrant_chat_file_', strlen('qdrant_chat_file_')) === 0 || strncmp($context_id, 'chroma_chat_file_', strlen('chroma_chat_file_')) === 0 || strncmp($context_id, 'local_chat_file_', strlen('local_chat_file_')) === 0) {
            // Chat retrieval uses this value as the frontend file context key.
            return $context_id;
        }

        return $provider . '_file_' . hash('md5', $file_name . '|' . $context_id) . '_' . $timestamp;
    }

    private static function provider_label(string $provider): string
    {
        if ($provider === 'qdrant') {
            return 'Qdrant';
        }
        if ($provider === 'chroma') {
            return 'Chroma';
        }
        if ($provider === 'local') {
            return 'Local';
        }
        return 'Pinecone';
    }

    private static function base_source_type(string $provider, string $context): string
    {
        if ($context === 'chat') {
            $source_types = [
                'pinecone' => 'chat_file_upload_pinecone',
                'qdrant' => 'chat_file_upload_qdrant',
                'chroma' => 'chat_file_upload_chroma',
                'local' => 'chat_file_upload_local',
            ];
            return $source_types[$provider] ?? 'chat_file_upload_pinecone';
        }
        return 'file_upload_global_form';
    }

    /**
     * @param array<string,mixed> $job
     */
    private static function chunk_source_type(array $job): string
    {
        if (self::is_chat_context($job)) {
            $provider = (string) $job['provider'];
            $source_types = [
                'pinecone' => 'chat_file_upload_pinecone_chunk',
                'qdrant' => 'chat_file_upload_qdrant_chunk',
                'chroma' => 'chat_file_upload_chroma_chunk',
                'local' => 'chat_file_upload_local_chunk',
            ];
            return $source_types[$provider] ?? 'chat_file_upload_pinecone_chunk';
        }
        return 'file_upload_global_form';
    }

    /**
     * @param array<string,mixed> $job
     */
    private static function is_chat_context(array $job): bool
    {
        return (string) ($job['context'] ?? '') === 'chat';
    }

    private static function log(?callable $callback, array $data): void
    {
        if (is_callable($callback)) {
            call_user_func($callback, $data);
        }
    }
}
