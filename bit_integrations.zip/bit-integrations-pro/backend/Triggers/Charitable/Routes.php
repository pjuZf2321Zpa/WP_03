<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Core\Util\Route;
use BitApps\IntegrationsPro\Triggers\Charitable\CharitableController;

Route::get('charitable/get', [CharitableController::class, 'getAllTasks']);
