<?php

namespace FluentCartPro\App\Modules\DataExport\Exceptions;

class ExportRecordTooLargeException extends \RuntimeException
{
}
