<?php

namespace BitApps\IntegrationsPro\Triggers\B2BKing;

use BitApps\IntegrationsPro\Config;

final class B2BKingController
{
    public static function info()
    {
        return [
            'name'              => 'B2BKing',
            'title'             => __('B2BKing - Wholesale & B2B Solution for WooCommerce', 'bit-integrations-pro'),
            'type'              => 'custom_form_submission',
            'tutorial_url'      => '#',
            'is_active'         => self::isPluginInstalled(),
            'tasks'             => ['action' => 'b2bking/get', 'method' => 'get'],
            'fetch'             => ['action' => 'trigger/test', 'method' => 'post'],
            'fetch_remove'      => ['action' => 'trigger/test/remove', 'method' => 'post'],
            'isPro'             => true,
        ];
    }

    public function getAllTasks()
    {
        if (!self::isPluginInstalled()) {
            wp_send_json_error(\sprintf(__('%s is not installed or activated', 'bit-integrations-pro'), 'B2BKing'));
        }

        wp_send_json_success([
            ['form_name' => __('Account Approved', 'bit-integrations-pro'), 'triggered_entity_id' => 'b2bking_account_approved_finish', 'skipPrimaryKey' => true],
            ['form_name' => __('User Group Updated', 'bit-integrations-pro'), 'triggered_entity_id' => 'b2bking_user_group_updated', 'skipPrimaryKey' => true],
            ['form_name' => __('New Message', 'bit-integrations-pro'), 'triggered_entity_id' => 'b2bking_new_message', 'skipPrimaryKey' => true],
        ]);
    }

    public static function handleAccountApproved($emailAddress)
    {
        $data = self::getUserData($emailAddress, true);

        return static::flowExecute('b2bking_account_approved_finish', $data);
    }

    public static function handleUserGroupUpdated($userId, $newGroupId, $oldGroupId)
    {
        $data = array_merge(
            self::getUserData($userId),
            [
                'b2bking_new_group_id'   => $newGroupId ?: null,
                'b2bking_new_group_name' => $newGroupId ? get_the_title($newGroupId) : null,
                'b2bking_old_group_id'   => $oldGroupId ?: null,
                'b2bking_old_group_name' => $oldGroupId ? get_the_title($oldGroupId) : null,
            ]
        );

        return static::flowExecute('b2bking_user_group_updated', $data);
    }

    public static function handleNewMessage($email, $message, $senderId, $postId)
    {
        $userClass = bit_integrations_get_class('Core\\Util\\User');
        $sender = $userClass::get($senderId) ?: [];

        $data = array_merge(
            [
                'recipient_email'      => $email,
                'message'              => $message,
                'sender_id'            => $senderId,
                'sender_email'         => $sender['user_email'] ?? null,
                'sender_name'          => $sender['display_name'] ?? null,
                'conversation_post_id' => $postId,
            ],
            self::getUserData($email, true),
        );

        return static::flowExecute('b2bking_new_message', $data);
    }

    private static function isPluginInstalled()
    {
        return \defined('B2BKINGCORE_VERSION') || class_exists('B2bking_Globalhelpercore');
    }

    private static function getUserData($userIdOrEmail, $isEmail = false)
    {
        $userClass = bit_integrations_get_class('Core\\Util\\User');
        $data = $isEmail ? $userClass::getUserByField('email', $userIdOrEmail) : $userClass::get($userIdOrEmail);

        if (empty($data)) {
            return [];
        }

        $userId = $data['wp_user_id'];

        $groupId = get_user_meta($userId, 'b2bking_customergroup', true);

        $data['b2bking_group_id'] = $groupId ?: null;
        $data['b2bking_group_name'] = $groupId ? get_the_title($groupId) : null;
        $data['b2bking_b2buser'] = get_user_meta($userId, 'b2bking_b2buser', true) === 'yes';
        $data['b2bking_approved'] = get_user_meta($userId, 'b2bking_account_approved', true) === 'yes';
        $data['b2bking_account_type'] = get_user_meta($userId, 'b2bking_account_type', true) ?: 'regular';

        $data['metadata'] = array_map(
            function ($metaValue) {
                return \is_array($metaValue) && \count($metaValue) === 1 ? reset($metaValue) : $metaValue;
            },
            get_user_meta($userId)
        );

        return $data;
    }

    private static function flowExecute($triggeredEntityId, $data)
    {
        $helperClass = bit_integrations_get_class('Core\\Util\\Helper');
        $flowClass = bit_integrations_get_class('Flow\\Flow');

        $formData = $helperClass::prepareFetchFormatFields($data);
        $helperClass::setTestData(Config::withFreePrefix($triggeredEntityId . '_test'), array_values($formData));

        $flows = $flowClass::exists('B2BKing', $triggeredEntityId);

        if (!$flows) {
            return;
        }

        $data = array_column($formData, 'value', 'name');

        $flowClass::execute('B2BKing', $triggeredEntityId, $data, $flows);

        return ['type' => 'success'];
    }
}
