<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Core\Util\Route;
use BitApps\IntegrationsPro\Triggers\AdvancedAds\AdvancedAdsController;

Route::get('advanced_ads/get', [AdvancedAdsController::class, 'getAllTasks']);
