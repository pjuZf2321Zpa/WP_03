<?php

namespace FluentCartPro\App\Modules\Promotional\OrderBump\Cards;

class CalloutCard extends AbstractCard
{
    public static function key(): string
    {
        return 'callout';
    }

    public static function title(): string
    {
        return __('Callout Card', 'fluent-cart-pro');
    }

    public static function description(): string
    {
        return __('A blue card with a boxed checkbox.', 'fluent-cart-pro');
    }

    public static function content(): string
    {
        $checkbox = '<!-- wp:fluent-cart/order-bump-checkbox ' . wp_json_encode(['label' => sprintf(__('Grab it for %s', 'fluent-cart-pro'), '{{bump.price}}')]) . ' /-->';

        $prices = static::group(
            'fct_bump_callout_prices',
            static::element('original-price', 'fct_order_promotion_original_price') . "\n\n"
            . static::element('price', 'fct_order_promotion_discounted_price') . "\n\n"
            . static::element('savings', 'fct_order_promotion_discount')
        );

        $details = static::element('product-title', 'fct_bump_callout_product') . "\n\n"
            . static::element('variation-title', 'fct_bump_callout_variation') . "\n\n"
            . $prices . "\n\n"
            . static::element('description', 'fct_bump_callout_description');

        return static::group(
            'fct_bump_callout',
            static::group(
                'fct_bump_callout_body',
                static::element('image', 'fct_bump_callout_image') . "\n\n" . static::group('fct_bump_callout_details', $details)
            ) . "\n\n" . static::group('fct_bump_callout_footer', $checkbox)
        );
    }

    public static function css(): string
    {
        return <<<'CSS'
.fct_bump_callout {
    box-sizing: border-box;
    padding: 16px;
    border: 1px dashed #bfd3f2;
    border-radius: 12px;
    background: #eff6ff;
}
.fct_bump_callout p,
.fct_bump_callout .wp-block {
    margin: 0;
}
.fct_bump_callout .fct_bump_callout_body {
    display: flex;
    align-items: flex-start;
    column-gap: 16px;
}
.fct_bump_callout .fct_bump_callout_image {
    flex: 0 0 auto;
    width: 60px;
    height: 60px;
    border-radius: 8px;
    overflow: hidden;
    background: rgba(255, 255, 255, 0.5);
}
.fct_bump_callout .fct_bump_callout_image img {
    display: block;
    width: 100%;
    height: 100%;
    object-fit: cover;
}
.fct_bump_callout .fct_bump_callout_details {
    flex: 1;
    min-width: 0;
    line-height: 1.4;
}
.fct_bump_callout .fct_bump_callout_product {
    font-size: 16px;
    font-weight: 600;
    line-height: 1.3;
    color: var(--fct-primary-text-color, #0e121b);
}
.fct_bump_callout .fct_bump_callout_variation {
    margin-top: 4px;
    font-size: 14px;
    color: var(--fct-secondary-text-color, #6b7280);
}
.fct_bump_callout .fct_bump_callout_variation:not(:empty)::before {
    content: none;
}
.fct_bump_callout .fct_bump_callout_prices {
    display: flex;
    flex-wrap: wrap;
    align-items: baseline;
    column-gap: 12px;
    margin-top: 4px;
    font-size: 15px;
}
.fct_bump_callout .fct_order_promotion_original_price {
    text-decoration: line-through;
    color: var(--fct-secondary-text-color, #6b7280);
}
.fct_bump_callout .fct_order_promotion_discounted_price {
    font-weight: 600;
    color: var(--fct-primary-text-color, #0e121b);
}
.fct_bump_callout .fct_order_promotion_discount {
    font-size: 14px;
    color: #c0392b;
}
.fct_bump_callout .fct_order_promotion_discount:not(:empty)::before,
.fct_bump_callout .fct_order_promotion_discount:not(:empty)::after {
    content: none;
}
.fct_bump_callout .fct_bump_callout_description {
    margin-top: 4px;
    font-size: 14px;
    color: var(--fct-secondary-text-color, #6b7280);
}
.fct_bump_callout .fct_bump_callout_footer {
    box-sizing: border-box;
    margin-top: 16px;
    padding: 0;
    border: 1px dashed #93b4ea;
    border-radius: 10px;
    background: #fff;
}
.fct_bump_callout .fct_bump_callout_footer:hover {
    border-color: #5f8ad6;
}
.fct_bump_callout .fct_bump_callout_footer label.fct_order_promotion_toggle {
    display: flex;
    align-items: center;
    column-gap: 8px;
    margin: 0;
    padding: 14px 16px;
    font-weight: 600;
    color: #1d4ed8;
    cursor: pointer;
}
.fct_bump_callout .fct_bump_callout_footer label.fct_order_promotion_toggle input.fct_order_promotion_input {
    flex: none;
    width: 16px;
    height: 16px;
    border: 1px solid #2563eb;
    border-radius: 3px;
    background: #fff;
}
.fct_bump_callout .fct_bump_callout_footer:hover label.fct_order_promotion_toggle input.fct_order_promotion_input {
    border-color: #1e40af;
}
.fct_bump_callout .fct_bump_callout_footer label.fct_order_promotion_toggle input.fct_order_promotion_input:checked {
    border-color: #2563eb;
    background: #2563eb;
}
CSS;
    }
}
