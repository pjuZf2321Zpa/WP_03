<?php

namespace WPAICG\ContentWriter\SEO;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Matches Smart SEO focus keyphrases against SEO plugin metadata.
 */
class AIPKit_Content_Writer_Smart_SEO_Keyphrase_Usage
{
    private const YOAST_FOCUS_META_KEY = '_yoast_wpseo_focuskw';
    private const RANK_MATH_FOCUS_META_KEY = 'rank_math_focus_keyword';

    public static function count_used_focus_keyword(string $focus_keyword, int $exclude_post_id = 0): int
    {
        $keyword = self::clean_keyword($focus_keyword);
        if ($keyword === '') {
            return 0;
        }

        $native_ids = self::query_native_duplicate_ids($keyword, $exclude_post_id);
        $normalized_ids = self::query_normalized_duplicate_ids($keyword, $exclude_post_id, $native_ids);
        $ids = array_fill_keys(array_merge($native_ids, $normalized_ids), true);

        return count($ids);
    }

    /**
     * Mirrors Rank Math's native duplicate check: exact primary keyword or primary keyword followed by a comma.
     * Yoast is checked as an exact focus keyphrase match.
     *
     * @return int[]
     */
    private static function query_native_duplicate_ids(string $keyword, int $exclude_post_id): array
    {
        global $wpdb;

        $statuses = ['publish', 'future', 'draft', 'pending', 'private'];
        $status_placeholders = implode(', ', array_fill(0, count($statuses), '%s'));
        $sql = "
            SELECT DISTINCT pm.post_id
            FROM {$wpdb->postmeta} pm
            INNER JOIN {$wpdb->posts} p ON p.ID = pm.post_id
            WHERE pm.post_id != %d
            AND (
                (
                    pm.meta_key = %s
                    AND p.post_status IN ({$status_placeholders})
                    AND LOWER(pm.meta_value) = LOWER(%s)
                )
                OR
                (
                    pm.meta_key = %s
                    AND p.post_status = 'publish'
                    AND (pm.meta_value = %s OR pm.meta_value LIKE %s)
                )
            )
            LIMIT 500
        ";

        $args = array_merge(
            [
                max(0, $exclude_post_id),
                self::YOAST_FOCUS_META_KEY,
            ],
            $statuses,
            [
                $keyword,
                self::RANK_MATH_FOCUS_META_KEY,
                $keyword,
                $wpdb->esc_like($keyword) . ',%',
            ]
        );

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter -- Admin/cron SEO duplicate lookup over indexed postmeta; placeholders are assembled from fixed arrays above.
        $ids = $wpdb->get_col($wpdb->prepare($sql, $args));
        if (!is_array($ids)) {
            return [];
        }

        return self::normalize_ids($ids);
    }

    /**
     * Secondary defensive pass for case/accent/entity/punctuation differences.
     *
     * @param int[] $already_matched
     * @return int[]
     */
    private static function query_normalized_duplicate_ids(string $keyword, int $exclude_post_id, array $already_matched): array
    {
        $keyword_key = self::normalize_keyphrase($keyword);
        if ($keyword_key === '') {
            return [];
        }

        $candidate_ids = self::query_candidate_ids($keyword, $exclude_post_id);
        if (empty($candidate_ids)) {
            return [];
        }

        $matched = [];
        $seen = array_fill_keys($already_matched, true);
        foreach ($candidate_ids as $post_id) {
            if (isset($seen[$post_id])) {
                continue;
            }

            if (self::post_uses_keyphrase($post_id, $keyword_key)) {
                $matched[] = $post_id;
            }
        }

        return $matched;
    }

    /**
     * @return int[]
     */
    private static function query_candidate_ids(string $keyword, int $exclude_post_id): array
    {
        global $wpdb;

        $seeds = self::candidate_like_seeds($keyword);
        if (empty($seeds)) {
            return [];
        }

        $like_clauses = [];
        $like_args = [];
        foreach ($seeds as $seed) {
            $like_clauses[] = 'pm.meta_value LIKE %s';
            $like_args[] = '%' . $wpdb->esc_like($seed) . '%';
        }

        $meta_key_placeholders = implode(', ', array_fill(0, 2, '%s'));
        $sql = "
            SELECT DISTINCT pm.post_id
            FROM {$wpdb->postmeta} pm
            INNER JOIN {$wpdb->posts} p ON p.ID = pm.post_id
            WHERE pm.post_id != %d
            AND p.post_status IN ('publish', 'future', 'draft', 'pending', 'private')
            AND pm.meta_key IN ({$meta_key_placeholders})
            AND (" . implode(' OR ', $like_clauses) . ")
            LIMIT 500
        ";

        $args = array_merge(
            [
                max(0, $exclude_post_id),
                self::YOAST_FOCUS_META_KEY,
                self::RANK_MATH_FOCUS_META_KEY,
            ],
            $like_args
        );

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter -- Admin/cron SEO duplicate lookup over indexed postmeta; placeholders are assembled from fixed arrays above.
        $ids = $wpdb->get_col($wpdb->prepare($sql, $args));
        if (!is_array($ids)) {
            return [];
        }

        return self::normalize_ids($ids);
    }

    private static function post_uses_keyphrase(int $post_id, string $keyword_key): bool
    {
        $yoast_keyword = get_post_meta($post_id, self::YOAST_FOCUS_META_KEY, true);
        if (self::normalize_keyphrase((string) $yoast_keyword) === $keyword_key) {
            return true;
        }

        if (get_post_status($post_id) !== 'publish') {
            return false;
        }

        $rank_math_keywords = get_post_meta($post_id, self::RANK_MATH_FOCUS_META_KEY, true);
        foreach (self::rank_math_primary_candidates((string) $rank_math_keywords) as $candidate) {
            if (self::normalize_keyphrase($candidate) === $keyword_key) {
                return true;
            }
        }

        return false;
    }

    /**
     * @return string[]
     */
    private static function rank_math_primary_candidates(string $value): array
    {
        $parts = preg_split('/\s*,\s*/', $value);
        $parts = is_array($parts) ? $parts : [];
        $primary = isset($parts[0]) ? trim((string) $parts[0]) : '';
        $candidates = [$primary];
        if (strpos($value, ',') === false) {
            $candidates[] = $value;
        }

        return array_values(array_filter(array_unique(array_map('trim', $candidates))));
    }

    /**
     * @return string[]
     */
    private static function candidate_like_seeds(string $keyword): array
    {
        $keyword = self::clean_keyword($keyword);
        $keyword_key = self::normalize_keyphrase($keyword);
        $seeds = array_filter([$keyword, $keyword_key]);

        $words = preg_split('/\s+/u', $keyword_key);
        $words = is_array($words) ? array_values(array_filter($words, static function (string $word): bool {
            return strlen($word) >= 4;
        })) : [];
        if (count($words) >= 2) {
            $seeds[] = $words[0] . ' ' . $words[1];
        } elseif (count($words) === 1 && strlen($words[0]) >= 6) {
            $seeds[] = $words[0];
        }

        return array_values(array_unique(array_filter(array_map('trim', $seeds))));
    }

    private static function clean_keyword(string $keyword): string
    {
        $keyword = trim(wp_strip_all_tags($keyword));
        $keyword = preg_replace('/^[\'"`“”‘’\s]+|[\'"`“”‘’\s]+$/u', '', (string) $keyword);
        $keyword = preg_replace('/[.,;:!?]+$/', '', (string) $keyword);
        $keyword = preg_replace('/\s+/u', ' ', (string) $keyword);

        return sanitize_text_field(trim((string) $keyword));
    }

    private static function normalize_keyphrase(string $value): string
    {
        $charset = function_exists('get_bloginfo') ? (get_bloginfo('charset') ?: 'UTF-8') : 'UTF-8';
        $value = html_entity_decode(wp_strip_all_tags($value), ENT_QUOTES | ENT_HTML5, $charset);
        $value = function_exists('remove_accents') ? remove_accents($value) : $value;
        $value = function_exists('mb_strtolower') ? mb_strtolower($value, 'UTF-8') : strtolower($value);
        $value = preg_replace('/[^\p{L}\p{N}\s-]+/u', ' ', (string) $value);
        $value = preg_replace('/[\s_-]+/u', ' ', (string) $value);

        return trim((string) $value);
    }

    /**
     * @param array<int|string> $ids
     * @return int[]
     */
    private static function normalize_ids(array $ids): array
    {
        return array_values(array_unique(array_filter(array_map('absint', $ids))));
    }
}
