<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Actions\FluentPlayer\FluentPlayerProHelper;
use BitApps\IntegrationsPro\Config;
use BitApps\IntegrationsPro\Core\Util\Hooks;

Hooks::filter(Config::withFreePrefix('fluent_player_create_media'), [FluentPlayerProHelper::class, 'createMedia'], 10, 4);
Hooks::filter(Config::withFreePrefix('fluent_player_update_media'), [FluentPlayerProHelper::class, 'updateMedia'], 10, 4);
Hooks::filter(Config::withFreePrefix('fluent_player_change_media_status'), [FluentPlayerProHelper::class, 'changeMediaStatus'], 10, 3);
Hooks::filter(Config::withFreePrefix('fluent_player_set_media_tags'), [FluentPlayerProHelper::class, 'setMediaTags'], 10, 3);
Hooks::filter(Config::withFreePrefix('fluent_player_add_media_tags'), [FluentPlayerProHelper::class, 'addMediaTags'], 10, 3);
Hooks::filter(Config::withFreePrefix('fluent_player_remove_media_tags'), [FluentPlayerProHelper::class, 'removeMediaTags'], 10, 3);
Hooks::filter(Config::withFreePrefix('fluent_player_create_playlist'), [FluentPlayerProHelper::class, 'createPlaylist'], 10, 3);
Hooks::filter(Config::withFreePrefix('fluent_player_update_playlist'), [FluentPlayerProHelper::class, 'updatePlaylist'], 10, 3);
Hooks::filter(Config::withFreePrefix('fluent_player_change_playlist_status'), [FluentPlayerProHelper::class, 'changePlaylistStatus'], 10, 3);
Hooks::filter(Config::withFreePrefix('fluent_player_create_email_submission'), [FluentPlayerProHelper::class, 'createEmailSubmission'], 10, 3);
Hooks::filter(Config::withFreePrefix('fluent_player_subscribe_email_to_providers'), [FluentPlayerProHelper::class, 'subscribeEmailToProviders'], 10, 3);
Hooks::filter(Config::withFreePrefix('fluent_player_record_visit'), [FluentPlayerProHelper::class, 'recordVisit'], 10, 3);
Hooks::filter(Config::withFreePrefix('fluent_player_delete_preset'), [FluentPlayerProHelper::class, 'deletePreset'], 10, 2);
Hooks::filter(Config::withFreePrefix('fluent_player_record_watch_progression'), [FluentPlayerProHelper::class, 'recordWatchProgression'], 10, 3);
Hooks::filter(Config::withFreePrefix('fluent_player_trash_media'), [FluentPlayerProHelper::class, 'trashMedia'], 10, 2);
Hooks::filter(Config::withFreePrefix('fluent_player_restore_media'), [FluentPlayerProHelper::class, 'restoreMedia'], 10, 2);
Hooks::filter(Config::withFreePrefix('fluent_player_delete_media'), [FluentPlayerProHelper::class, 'deleteMedia'], 10, 2);
Hooks::filter(Config::withFreePrefix('fluent_player_create_tag'), [FluentPlayerProHelper::class, 'createTag'], 10, 2);
Hooks::filter(Config::withFreePrefix('fluent_player_rename_tag'), [FluentPlayerProHelper::class, 'renameTag'], 10, 2);
Hooks::filter(Config::withFreePrefix('fluent_player_delete_tag'), [FluentPlayerProHelper::class, 'deleteTag'], 10, 2);
Hooks::filter(Config::withFreePrefix('fluent_player_trash_playlist'), [FluentPlayerProHelper::class, 'trashPlaylist'], 10, 2);
Hooks::filter(Config::withFreePrefix('fluent_player_restore_playlist'), [FluentPlayerProHelper::class, 'restorePlaylist'], 10, 2);
Hooks::filter(Config::withFreePrefix('fluent_player_delete_playlist'), [FluentPlayerProHelper::class, 'deletePlaylist'], 10, 2);
Hooks::filter(Config::withFreePrefix('fluent_player_add_media_to_playlist'), [FluentPlayerProHelper::class, 'addMediaToPlaylist'], 10, 2);
Hooks::filter(Config::withFreePrefix('fluent_player_remove_media_from_playlist'), [FluentPlayerProHelper::class, 'removeMediaFromPlaylist'], 10, 2);
Hooks::filter(Config::withFreePrefix('fluent_player_save_preset'), [FluentPlayerProHelper::class, 'savePreset'], 10, 2);
