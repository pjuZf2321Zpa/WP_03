<?php
/**
 * Events Integration configuration.
 *
 * Option names, cron hooks, and feature availability checks for the
 * Facebook Events → calendar sync module.
 *
 * @package CustomFacebookFeed\Events_Integration
 * @since 4.11
 */

namespace CustomFacebookFeed\Events_Integration;

use CustomFacebookFeed\CFF_License_Tier;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Config {

	/**
	 * Option key: module settings (targets, sources, cron interval, etc.).
	 */
	const OPTION_SETTINGS = 'cff_events_sync_settings';

	/**
	 * Option key: rolling structured log of the last sync runs.
	 */
	const OPTION_LOG = 'cff_events_sync_log';

	/**
	 * Option key: batch cursor for chunked syncs.
	 */
	const OPTION_CURSOR = 'cff_events_sync_cursor';

	/**
	 * Option key: sync keys the user deleted calendar-side; never recreated.
	 */
	const OPTION_TOMBSTONES = 'cff_events_sync_deleted_keys';

	/**
	 * Max number of tombstoned sync keys kept.
	 */
	const TOMBSTONES_CAP = 500;

	/**
	 * Main scheduled sync cron hook.
	 */
	const CRON_HOOK = 'cff_events_sync_cron';

	/**
	 * Batch-continuation single-event hook.
	 */
	const BATCH_HOOK = 'cff_events_sync_batch';

	/**
	 * Max deletion-confirmation Graph fetches per batch pass.
	 */
	const MAX_DELETE_CONFIRMS_PER_PASS = 10;

	/**
	 * Number of log entries kept in the rolling run log.
	 */
	const LOG_MAX_ENTRIES = 20;

	/**
	 * License feature key gating the module (existing elite-tier feature).
	 */
	const LICENSE_FEATURE = 'events_feeds';

	/**
	 * Target adapter IDs.
	 */
	const TARGET_SUGAR_CALENDAR = 'sugar_calendar';
	const TARGET_TEC            = 'tec';

	/**
	 * Per-request settings cache (get_settings() is called per event during
	 * a sync run).
	 *
	 * @var array|null
	 */
	private static $settings_cache = null;

	/**
	 * Get module settings merged with defaults.
	 *
	 * @return array
	 */
	public static function get_settings() {
		if ( null !== self::$settings_cache ) {
			return self::$settings_cache;
		}

		$defaults = array(
			'enabled'            => false,
			'targets'            => array(
				self::TARGET_SUGAR_CALENDAR => false,
				self::TARGET_TEC            => false,
			),
			'sources'            => array(),
			'cron_interval'      => 'twicedaily',
			'sideload_images'    => true,
			'sc_calendar_term'   => 0,
			'tec_default_status' => 'publish',
		);

		$saved = get_option( self::OPTION_SETTINGS, array() );
		if ( ! is_array( $saved ) ) {
			$saved = array();
		}

		$settings            = array_merge( $defaults, $saved );
		$settings['targets'] = array_merge( $defaults['targets'], is_array( $settings['targets'] ) ? $settings['targets'] : array() );

		self::$settings_cache = $settings;

		return $settings;
	}

	/**
	 * Save module settings.
	 *
	 * @param array $settings Settings to persist (already sanitized).
	 */
	public static function update_settings( array $settings ) {
		self::$settings_cache = null;
		update_option( self::OPTION_SETTINGS, $settings, false );
	}

	/**
	 * Whether the current license tier includes the events feature.
	 *
	 * @return bool
	 */
	public static function license_allows() {
		$license_tier = new CFF_License_Tier();
		$features     = $license_tier->tier_features();

		return is_array( $features ) && in_array( self::LICENSE_FEATURE, $features, true );
	}

	/**
	 * Whether the sync module is enabled (license + master toggle).
	 *
	 * @return bool
	 */
	public static function is_enabled() {
		if ( ! self::license_allows() ) {
			return false;
		}
		$settings = self::get_settings();

		return ! empty( $settings['enabled'] );
	}

	/**
	 * Target IDs enabled in settings (availability is checked by the adapters).
	 *
	 * @return string[]
	 */
	public static function enabled_targets() {
		$settings = self::get_settings();

		return array_keys( array_filter( $settings['targets'] ) );
	}

	/**
	 * Cron recurrence chosen in settings, restricted to supported intervals.
	 *
	 * @return string
	 */
	public static function cron_interval() {
		$settings = self::get_settings();
		$allowed  = array( 'hourly', 'twicedaily', 'daily' );

		return in_array( $settings['cron_interval'], $allowed, true ) ? $settings['cron_interval'] : 'twicedaily';
	}
}
