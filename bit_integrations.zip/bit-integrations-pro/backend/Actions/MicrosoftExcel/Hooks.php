<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Actions\MicrosoftExcel\MicrosoftExcelService;
use BitApps\IntegrationsPro\Config;
use BitApps\IntegrationsPro\Core\Util\Hooks;

Hooks::filter(Config::withFreePrefix('microsoft_excel_add_worksheet_row'), [MicrosoftExcelService::class, 'addWorksheetRow'], 10, 4);
Hooks::filter(Config::withFreePrefix('microsoft_excel_update_worksheet_row'), [MicrosoftExcelService::class, 'updateWorksheetRow'], 10, 4);
Hooks::filter(Config::withFreePrefix('microsoft_excel_clear_worksheet'), [MicrosoftExcelService::class, 'clearWorksheet'], 10, 4);
Hooks::filter(Config::withFreePrefix('microsoft_excel_add_worksheet'), [MicrosoftExcelService::class, 'addWorksheet'], 10, 4);
Hooks::filter(Config::withFreePrefix('microsoft_excel_delete_worksheet'), [MicrosoftExcelService::class, 'deleteWorksheet'], 10, 4);
Hooks::filter(Config::withFreePrefix('microsoft_excel_create_table'), [MicrosoftExcelService::class, 'createTable'], 10, 4);
Hooks::filter(Config::withFreePrefix('microsoft_excel_delete_table'), [MicrosoftExcelService::class, 'deleteTable'], 10, 4);
