<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Core\Util\Route;
use BitApps\IntegrationsPro\Triggers\EssentialBlocks\EssentialBlocksController;

Route::get('essential_blocks/get', [EssentialBlocksController::class, 'getAllTasks']);
