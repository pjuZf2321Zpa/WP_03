<?php

namespace FluentCartPro\App\Modules\Reports\Http\Controllers;

use FluentCart\App\Http\Controllers\Controller;
use FluentCart\App\Services\Permission\PermissionManager;
use FluentCart\App\Services\Report\ChannelRules;
use FluentCart\Framework\Http\Request\Request;

class ChannelRulesController extends Controller
{
    /**
     * The store's channel rules and own domains, and whether this user may change them
     */
    public function get(): array
    {
        return ChannelRules::get() + ['can_edit' => PermissionManager::hasPermission('store/settings')];
    }

    public function save(Request $request)
    {
        // Rules change how every report user sees channels: a store setting, not a report view
        if (!PermissionManager::hasPermission('store/settings')) {
            return $this->sendError([
                'message' => __('You do not have permission to change the channel rules.', 'fluent-cart-pro')
            ], 403);
        }

        return ChannelRules::save([
            'rules'       => (array) $request->get('rules', []),
            'own_domains' => (array) $request->get('own_domains', []),
        ]) + ['can_edit' => true];
    }
}
