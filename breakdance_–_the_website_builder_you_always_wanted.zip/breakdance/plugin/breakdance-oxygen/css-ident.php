<?php

namespace Breakdance\BreakdanceOxygen\Selectors;

/**
 * CSS identifier encoding for class selector names.
 *
 * A class selector's stored name is the plain name the user typed and the
 * markup writes (`md:w-1/2`, `2col`, `card-🚀`), not CSS source text. Turning it
 * into a rule means encoding it as a CSS identifier, or the generated rule
 * either fails to parse or matches the wrong thing: `.md:w-1/2 { }` reads as
 * "class `md` in the `:w-1` pseudo-class", not as the class the element carries.
 *
 * escape_css_class_name() implements the CSS.escape() serialization algorithm
 * (https://drafts.csswg.org/cssom/#serialize-an-identifier); unescape_css_identifier()
 * reverses the escapes CSS source may contain, so `.md\:w-1\/2 { }` imported
 * from a stylesheet resolves to the same stored name the markup writes.
 *
 * Changes here must be mirrored in apps/builder/src/oxygen/classes/lib/css-ident.ts,
 * which encodes the same names for the builder's live preview CSS.
 */

/**
 * Encode a stored class name as a CSS identifier (without the leading dot).
 *
 * Non-ASCII characters are identifier characters as-is, so emoji and accented
 * names pass through untouched; ASCII punctuation is backslash-escaped, and
 * control characters plus a leading digit use the hex form.
 *
 * @param string $name
 * @return string
 */
function escape_css_class_name($name)
{
    if ($name === '') {
        return '';
    }

    $chars = preg_split('//u', $name, -1, PREG_SPLIT_NO_EMPTY);

    // Invalid UTF-8 has no identifier form; treat it as nothing to escape.
    if (!is_array($chars) || $chars === []) {
        return '';
    }

    $count = count($chars);
    $out   = '';

    foreach ($chars as $i => $char) {
        // A multi-byte character is >= U+0080, which is an identifier
        // character, so it needs no escape.
        if (strlen($char) > 1) {
            $out .= $char;
            continue;
        }

        $code = ord($char);

        if ($code === 0) {
            $out .= "\u{FFFD}";
            continue;
        }

        $is_digit = $code >= 0x30 && $code <= 0x39;

        if (
            ($code >= 0x01 && $code <= 0x1f)
            || $code === 0x7f
            || ($i === 0 && $is_digit)
            || ($i === 1 && $is_digit && $chars[0] === '-')
        ) {
            // Zero-padded to the full six digits rather than closed by a
            // space: CSS stops reading a hex escape after six digits either
            // way, and the space form does not survive the minifier every
            // stylesheet is rendered through (`.\32 col` -> `.\32col`).
            $out .= '\\' . str_pad(dechex($code), 6, '0', STR_PAD_LEFT);
            continue;
        }

        if ($i === 0 && $count === 1 && $char === '-') {
            $out .= '\\-';
            continue;
        }

        if ($char === '-' || $char === '_' || ctype_alnum($char)) {
            $out .= $char;
            continue;
        }

        $out .= '\\' . $char;
    }

    return $out;
}

/**
 * Decode the escapes in a CSS identifier back to the plain name it stands for,
 * the inverse of escape_css_class_name(). Text without escapes is returned
 * unchanged.
 *
 * @param string $ident
 * @return string
 */
function unescape_css_identifier($ident)
{
    if (strpos($ident, '\\') === false) {
        return $ident;
    }

    $decoded = preg_replace_callback(
        // A hex escape is 1-6 hex digits closed by one optional whitespace;
        // anything else after the backslash stands for itself.
        '/\\\\(?:([0-9A-Fa-f]{1,6})[ \t\n\r\f]?|(.))/su',
        /**
         * @param array<int, string> $m
         * @return string
         */
        static function ($m) {
            if (!isset($m[1]) || $m[1] === '') {
                return $m[2] ?? '';
            }

            $code = (int) hexdec($m[1]);

            // Null, surrogate and out-of-range code points all decode to the
            // replacement character, per the CSS tokenizer.
            $valid = $code > 0 && $code <= 0x10FFFF && ($code < 0xD800 || $code > 0xDFFF);

            return $valid ? html_entity_decode('&#' . $code . ';', ENT_QUOTES, 'UTF-8') : "\u{FFFD}";
        },
        $ident
    );

    return is_string($decoded) ? $decoded : $ident;
}

/**
 * One class name as it appears in CSS source, as a regex fragment (no
 * delimiters, no capture groups). A class name runs until the first
 * *unescaped* selector delimiter, so `.md\:w-1\/2:hover` yields the name
 * `md\:w-1\/2` and leaves `:hover` behind. Everything else - digits, emoji,
 * escaped punctuation - is part of the name.
 *
 * A hex escape takes its optional closing whitespace with it, or `.\32 col`
 * (what CSS.escape() emits for `2col`) would read as the class `2` followed by
 * a descendant.
 */
const CSS_CLASS_NAME_PATTERN = '(?:\\\\[0-9A-Fa-f]{1,6}[ \t\n\r\f]?|\\\\.|[^\\\\\s.:#\\[\\]>+~,()])+';
