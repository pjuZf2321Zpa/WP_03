<?php

namespace BitApps\IntegrationsPro\Actions\WeDocs;

use BitApps\IntegrationsPro\Core\Util\WeDocsHelper;
use WP_Post;

class WeDocsProHelper
{
    public static function createDocumentation($defaultResponse, $payload)
    {
        if ($error = self::ensurePluginActive()) {
            return $error;
        }

        $postTitle = self::getRequiredString($payload, 'post_title', __('Documentation title is required.', 'bit-integrations-pro'));
        if (\is_array($postTitle)) {
            return $postTitle;
        }

        return self::insertDocPost(
            $postTitle,
            $payload,
            0,
            __('Documentation created successfully', 'bit-integrations-pro')
        );
    }

    public static function createSection($defaultResponse, $payload)
    {
        if ($error = self::ensurePluginActive()) {
            return $error;
        }

        $documentationId = self::getRequiredId($payload, 'documentation_id', __('Documentation is required.', 'bit-integrations-pro'));
        if (\is_array($documentationId)) {
            return $documentationId;
        }

        $postTitle = self::getRequiredString($payload, 'post_title', __('Section title is required.', 'bit-integrations-pro'));
        if (\is_array($postTitle)) {
            return $postTitle;
        }

        $documentation = get_post($documentationId);
        if (!WeDocsHelper::isValidDocumentation($documentation)) {
            return self::errorResponse(__('Selected documentation is invalid.', 'bit-integrations-pro'));
        }

        return self::insertDocPost(
            $postTitle,
            $payload,
            $documentationId,
            __('Section created successfully', 'bit-integrations-pro')
        );
    }

    public static function createArticle($defaultResponse, $payload)
    {
        if ($error = self::ensurePluginActive()) {
            return $error;
        }

        $documentationId = self::getRequiredId($payload, 'documentation_id', __('Documentation is required.', 'bit-integrations-pro'));
        if (\is_array($documentationId)) {
            return $documentationId;
        }

        $sectionId = self::getRequiredId($payload, 'section_id', __('Section is required.', 'bit-integrations-pro'));
        if (\is_array($sectionId)) {
            return $sectionId;
        }

        $postTitle = self::getRequiredString($payload, 'post_title', __('Article title is required.', 'bit-integrations-pro'));
        if (\is_array($postTitle)) {
            return $postTitle;
        }

        $documentation = get_post($documentationId);
        $section = get_post($sectionId);

        if (!WeDocsHelper::isValidDocumentation($documentation)) {
            return self::errorResponse(__('Selected documentation is invalid.', 'bit-integrations-pro'));
        }

        if (!WeDocsHelper::isValidSection($section)) {
            return self::errorResponse(__('Selected section is invalid.', 'bit-integrations-pro'));
        }

        if ((int) $section->post_parent !== $documentationId) {
            return self::errorResponse(__('Section does not belong to selected documentation.', 'bit-integrations-pro'));
        }

        return self::insertDocPost(
            $postTitle,
            $payload,
            $sectionId,
            __('Article created successfully', 'bit-integrations-pro')
        );
    }

    private static function insertDocPost($title, $payload, $parentId, $successMessage)
    {
        $postData = [
            'post_title'   => $title,
            'post_content' => wp_kses_post((string) ($payload['post_content'] ?? '')),
            'post_status'  => WeDocsHelper::normalizePostStatus((string) ($payload['post_status'] ?? 'draft')),
            'post_type'    => WeDocsHelper::DOC_POST_TYPE,
            'post_parent'  => $parentId,
        ];

        $currentUserId = get_current_user_id();
        if ($currentUserId > 0) {
            $postData['post_author'] = $currentUserId;
        }

        $insertedPostId = wp_insert_post($postData, true);
        if (is_wp_error($insertedPostId)) {
            return self::errorResponse($insertedPostId->get_error_message(), $postData);
        }

        $post = get_post((int) $insertedPostId);
        $data = $post instanceof WP_Post ? WeDocsHelper::buildDocPayload($post) : [];

        return self::successResponse($successMessage, $data);
    }

    private static function ensurePluginActive()
    {
        if (!WeDocsHelper::isPluginInstalled()) {
            return self::errorResponse(__('weDocs is not installed or activated.', 'bit-integrations-pro'));
        }

    }

    private static function getId($value)
    {
        if (empty($value)) {
            return 0;
        }

        return absint($value);
    }

    private static function getRequiredId($payload, $key, $message)
    {
        $value = self::getId($payload[$key] ?? 0);
        if ($value <= 0) {
            return self::errorResponse($message);
        }

        return $value;
    }

    private static function getRequiredString($payload, $key, $message)
    {
        $value = trim((string) ($payload[$key] ?? ''));

        if ($value === '') {
            return self::errorResponse($message);
        }

        return $value;
    }

    private static function successResponse($message, $data = [])
    {
        return [
            'success' => true,
            'message' => $message,
            'data'    => $data,
        ];
    }

    private static function errorResponse($message, $data = [])
    {
        return [
            'success' => false,
            'message' => $message,
            'data'    => $data,
        ];
    }
}
