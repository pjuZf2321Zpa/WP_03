<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Core\Util\Hooks;
use BitApps\IntegrationsPro\Actions\Trello\TrelloHelperPro;
use BitApps\IntegrationsPro\Config;

// Deprecated since v2.7.8 - use bit_integrations_trello_* hooks instead
if (class_exists('BitApps\\IntegrationsPro\\Config') && version_compare(BitApps\IntegrationsPro\Config::VERSION, '2.7.8', '<')) {
    Hooks::filter('btcbi_trello_get_all_custom_fields', [TrelloHelperPro::class, 'getAllCustomFields'], 10, 4);
    Hooks::add('btcbi_trello_store_custom_fields', [TrelloHelperPro::class, 'storeCustomFields'], 10, 5);
}

// New hooks since v2.7.8
Hooks::filter(Config::withFreePrefix('trello_get_all_custom_fields'), [TrelloHelperPro::class, 'getAllCustomFields'], 10, 4);
Hooks::add(Config::withFreePrefix('trello_store_custom_fields'), [TrelloHelperPro::class, 'storeCustomFields'], 10, 5);
