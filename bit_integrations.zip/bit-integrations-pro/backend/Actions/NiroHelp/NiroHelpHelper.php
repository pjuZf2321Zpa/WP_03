<?php

namespace BitApps\IntegrationsPro\Actions\NiroHelp;

use NiroHelp\Models\Ticket;

if (!\defined('ABSPATH')) {
    exit;
}

final class NiroHelpHelper
{
    public const DOC_POST_TYPE = 'nirohelp_doc';

    public const PRODUCT_TAXONOMY = 'nirohelp_product';

    public const REASON_TAXONOMY = 'nirohelp_reason';

    public const TOPIC_TAXONOMY = 'nirohelp_topic';

    public const CUSTOMER_ROLE = 'nirohelp_user';

    public const REPLY_BY_CUSTOMER = 'customer';

    public const CUSTOM_FIELD_PREFIX = 'cf_';

    public const DOC_STATUSES = ['publish', 'draft', 'pending', 'private'];

    public static function isPluginActive()
    {
        return \defined('NIROHELP_VERSION') && class_exists(Ticket::class);
    }

    public static function getTicketData($ticketId)
    {
        $ticket = new Ticket((int) $ticketId);

        if (!$ticket->exists()) {
            return [];
        }

        return array_merge(
            $ticket->to_event_array(),
            [
                'description'   => (string) $ticket->get_description(),
                'url'           => (string) $ticket->get_url(),
                'order'         => (string) $ticket->get_meta('order'),
                'custom_fields' => self::getTicketCustomFields($ticket),
                'followup'      => $ticket->get_followup(),
            ]
        );
    }

    public static function getCommentData($commentId)
    {
        $comment = get_comment($commentId);

        if (!$comment) {
            return [];
        }

        return [
            'id'           => (int) $comment->comment_ID,
            'ticket_id'    => (int) $comment->comment_post_ID,
            'type'         => $comment->comment_type === Ticket::INTERNAL_NOTE ? 'internal_note' : ($comment->comment_type ?: 'comment'),
            'is_ai'        => nirohelp_is_ai_comment((int) $comment->comment_ID),
            'author_id'    => (int) $comment->user_id,
            'author_name'  => (string) $comment->comment_author,
            'author_email' => (string) $comment->comment_author_email,
            'content'      => (string) $comment->comment_content,
            'created_at'   => (string) $comment->comment_date_gmt,
        ];
    }

    public static function getDocData($docId)
    {
        $post = get_post((int) $docId);

        if (!$post || $post->post_type !== self::DOC_POST_TYPE) {
            return [];
        }

        return [
            'id'         => (int) $post->ID,
            'title'      => (string) $post->post_title,
            'slug'       => (string) $post->post_name,
            'content'    => (string) $post->post_content,
            'status'     => (string) $post->post_status,
            'url'        => (string) get_permalink($post),
            'topics'     => self::getPostTermNames($post->ID, self::TOPIC_TAXONOMY),
            'products'   => self::getPostTermNames($post->ID, self::PRODUCT_TAXONOMY),
            'author_id'  => (int) $post->post_author,
            'created_at' => (string) get_post_time('Y-m-d H:i:s', true, $post),
            'updated_at' => (string) get_post_modified_time('Y-m-d H:i:s', true, $post),
        ];
    }

    public static function getTermData($termId)
    {
        $term = get_term((int) $termId);

        if (!$term || is_wp_error($term)) {
            return [];
        }

        return [
            'id'          => (int) $term->term_id,
            'name'        => (string) $term->name,
            'slug'        => (string) $term->slug,
            'description' => (string) $term->description,
            'parent'      => (int) $term->parent,
            'taxonomy'    => (string) $term->taxonomy,
        ];
    }

    public static function getCustomFieldKeys()
    {
        $keys = [];

        foreach (nirohelp_ticket_form_fields() as $field) {
            $key = \is_array($field) ? (string) ($field['key'] ?? '') : '';

            if (strpos($key, self::CUSTOM_FIELD_PREFIX) === 0 && !empty($field['enabled'])) {
                $keys[$key] = (string) ($field['label'] ?? $key);
            }
        }

        return $keys;
    }

    private static function getTicketCustomFields(Ticket $ticket)
    {
        $values = [];

        foreach (array_keys(self::getCustomFieldKeys()) as $key) {
            $values[$key] = $ticket->get_meta($key);
        }

        return $values;
    }

    private static function getPostTermNames($postId, $taxonomy)
    {
        $names = wp_get_post_terms($postId, $taxonomy, ['fields' => 'names']);

        return is_wp_error($names) ? [] : $names;
    }
}
