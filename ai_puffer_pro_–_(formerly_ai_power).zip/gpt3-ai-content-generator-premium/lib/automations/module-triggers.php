<?php

namespace WPAICG\AutoGPT\Cron\EventProcessor\Trigger\Modules;

use WP_Error;
use WPAICG\aipkit_dashboard;
use WPAICG\Lib\ContentWriter\AIPKit_Google_Sheets_Parser;
use WPAICG\Lib\ContentWriter\AIPKit_Rss_Item_Selector;
use WPAICG\Lib\Utils\AIPKit_Url_Scraper;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Generates items to be queued from RSS feeds.
 *
 * @param int $task_id The ID of the task.
 * @param array $task_config The configuration of the task.
 * @param string|null $last_run_time The GMT timestamp of the last check (for scheduled runs) or null (for "Run Now").
 * @return array|WP_Error An array of items or WP_Error on failure.
 */
function rss_mode_generate_items_logic(int $task_id, array $task_config, ?string $last_run_time)
{
    if (!aipkit_dashboard::is_pro_plan() || !class_exists(AIPKit_Rss_Item_Selector::class)) {
        return new WP_Error('rss_feature_unavailable', __('RSS generation is a Pro feature or its components are missing.', 'gpt3-ai-content-generator'), ['status' => 403]);
    }

    $selection = AIPKit_Rss_Item_Selector::select($task_config, $task_id, $last_run_time);
    return is_wp_error($selection) ? $selection : $selection['items'];
}

/**
 * Generates items to be queued by scraping a list of URLs.
 *
 * @param int $task_id The ID of the task.
 * @param array $task_config The configuration of the task.
 * @return array|WP_Error An array containing 'topics' and 'contexts' or a WP_Error on failure.
 */
function url_mode_generate_items_logic(int $task_id, array $task_config)
{
    if (!aipkit_dashboard::is_pro_plan() || !class_exists(AIPKit_Url_Scraper::class)) {
        return new WP_Error('url_feature_unavailable', __('URL extracting is a Pro feature or its components are missing.', 'gpt3-ai-content-generator'), ['status' => 403]);
    }

    $topics = [];
    $contexts = [];
    $url_list = array_filter(array_map('trim', explode("\n", $task_config['url_list'] ?? '')));

    if (empty($url_list)) {
        return new WP_Error('no_urls_provided', __('No URLs were provided for scraping.', 'gpt3-ai-content-generator'), ['status' => 400]);
    }

    $scraper = new AIPKit_Url_Scraper();

    foreach ($url_list as $url) {
        $scraped_content = $scraper->scrape($url);
        if (!is_wp_error($scraped_content)) {
            $topics[] = ['title' => $url, 'link' => $url];
            $contexts[$url] = $scraped_content;
        }
    }

    return ['topics' => $topics, 'contexts' => $contexts];
}

/**
 * Generates items to be queued from a Google Sheet.
 *
 * @param int $task_id The ID of the task.
 * @param array $task_config The configuration of the task.
 * @return array|WP_Error An array of items or WP_Error on failure.
 */
function gsheets_mode_generate_items_logic(int $task_id, array $task_config)
{
    if (!aipkit_dashboard::is_pro_plan() || !class_exists(AIPKit_Google_Sheets_Parser::class)) {
        return new WP_Error('gsheets_feature_unavailable', __('Google Sheets integration is a Pro feature or its components are missing.', 'gpt3-ai-content-generator'), ['status' => 403]);
    }

    $sheet_id = $task_config['gsheets_sheet_id'] ?? '';
    $credentials_array = $task_config['gsheets_credentials'] ?? [];

    if (empty($sheet_id) || empty($credentials_array) || !is_array($credentials_array)) {
        return new WP_Error('missing_gsheets_config', __('Google Sheets task is missing Sheet ID or credentials.', 'gpt3-ai-content-generator'), ['status' => 400]);
    }

    try {
        $sheets_parser = new AIPKit_Google_Sheets_Parser($credentials_array);
        $topics_from_sheet = $sheets_parser->get_rows_from_sheet($sheet_id);

        if (is_wp_error($topics_from_sheet)) {
            return $topics_from_sheet;
        }

        return $topics_from_sheet;
    } catch (\Exception $e) {
        return new WP_Error('gsheets_parser_exception', 'Error processing Google Sheet: ' . $e->getMessage(), ['status' => 500]);
    }
}

/**
 * Applies include/exclude keyword filters to a list of RSS items.
 *
 * @param array  $items The array of items to filter (each must have a 'title' key).
 * @param string $include_keywords_str A comma-separated string of keywords to include.
 * @param string $exclude_keywords_str A comma-separated string of keywords to exclude.
 * @return array The filtered array of items.
 */
function apply_include_exclude_keywords_logic(array $items, string $include_keywords_str, string $exclude_keywords_str): array
{
    if (empty($include_keywords_str) && empty($exclude_keywords_str)) {
        return $items;
    }

    $include_keywords = !empty($include_keywords_str) ? array_map('trim', explode(',', strtolower($include_keywords_str))) : [];
    $exclude_keywords = !empty($exclude_keywords_str) ? array_map('trim', explode(',', strtolower($exclude_keywords_str))) : [];

    return array_filter($items, function ($item) use ($include_keywords, $exclude_keywords) {
        if (!isset($item['title'])) {
            return false;
        }
        $title_lower = strtolower($item['title']);

        // Exclude logic: if any exclude keyword is found, discard the item.
        if (!empty($exclude_keywords)) {
            foreach ($exclude_keywords as $keyword) {
                if ($keyword !== '' && strpos($title_lower, $keyword) !== false) {
                    return false;
                }
            }
        }

        // Include logic: if include keywords are provided, title MUST contain one of them.
        if (!empty($include_keywords)) {
            foreach ($include_keywords as $keyword) {
                if ($keyword !== '' && strpos($title_lower, $keyword) !== false) {
                    return true; // Found a match, keep it.
                }
            }
            return false; // No include keywords matched, discard it.
        }

        return true; // Keep if no include rules apply or only exclude rules passed.
    });
}

/**
 * Mark a Google Sheets row only after its queue insert succeeds.
 * Status delivery is best effort and must not undo a successful queue insert.
 */
function update_google_sheet_queued_status_logic(array $item_config): void
{
    if (!class_exists(aipkit_dashboard::class) || !aipkit_dashboard::is_pro_plan()) {
        return;
    }

    if (
        isset($item_config['cw_generation_mode']) &&
        $item_config['cw_generation_mode'] === 'gsheets' &&
        !empty($item_config['gsheets_row_index']) &&
        !empty($item_config['gsheets_sheet_id']) &&
        !empty($item_config['gsheets_credentials']) &&
        class_exists(AIPKit_Google_Sheets_Parser::class)
    ) {
        try {
            $sheets_parser = new AIPKit_Google_Sheets_Parser($item_config['gsheets_credentials']);
            $status_to_write = 'Queued on ' . current_time('mysql');
            $sheets_parser->update_row_status(
                $item_config['gsheets_sheet_id'],
                (int) $item_config['gsheets_row_index'],
                $status_to_write
            );
        } catch (\Exception $e) {
            unset($e); // Queue insertion succeeded; status delivery is best effort.
        }
    }
}
