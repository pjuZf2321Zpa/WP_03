<?php
/*
 * Copyright 2014 NxProGA\Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */

namespace NxProGA\Google\Service\Analytics;


if ( ! defined( 'ABSPATH' ) ) { exit; }
class GoalEventDetailsEventConditions extends \NxProGA\Google\Model
{
  /**
   * @var string
   */
  public $comparisonType;
  /**
   * @var string
   */
  public $comparisonValue;
  /**
   * @var string
   */
  public $expression;
  /**
   * @var string
   */
  public $matchType;
  /**
   * @var string
   */
  public $type;

  /**
   * @param string
   */
  public function setComparisonType($comparisonType)
  {
    $this->comparisonType = $comparisonType;
  }
  /**
   * @return string
   */
  public function getComparisonType()
  {
    return $this->comparisonType;
  }
  /**
   * @param string
   */
  public function setComparisonValue($comparisonValue)
  {
    $this->comparisonValue = $comparisonValue;
  }
  /**
   * @return string
   */
  public function getComparisonValue()
  {
    return $this->comparisonValue;
  }
  /**
   * @param string
   */
  public function setExpression($expression)
  {
    $this->expression = $expression;
  }
  /**
   * @return string
   */
  public function getExpression()
  {
    return $this->expression;
  }
  /**
   * @param string
   */
  public function setMatchType($matchType)
  {
    $this->matchType = $matchType;
  }
  /**
   * @return string
   */
  public function getMatchType()
  {
    return $this->matchType;
  }
  /**
   * @param string
   */
  public function setType($type)
  {
    $this->type = $type;
  }
  /**
   * @return string
   */
  public function getType()
  {
    return $this->type;
  }
}

// Adding a class alias for backwards compatibility with the previous class name.
class_alias(GoalEventDetailsEventConditions::class, 'Google_Service_Analytics_GoalEventDetailsEventConditions');
