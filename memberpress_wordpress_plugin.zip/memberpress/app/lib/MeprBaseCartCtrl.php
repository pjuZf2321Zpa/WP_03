<?php

if (!defined('ABSPATH')) {
    die('You are not allowed to call this page directly.');
}

/**
 * Base controller for cart-only controllers — their hooks register only while the cart is enabled.
 *
 * Extend this instead of MeprBaseCtrl for controllers that should be fully inert when the cart is
 * off (mirrors how MeprCptCtrl specialises MeprBaseCtrl). Keeps the cart-enablement gate out of the
 * generic base.
 */
abstract class MeprBaseCartCtrl extends MeprBaseCtrl
{
    /**
     * Skip hook registration entirely while the cart is off.
     *
     * @return void
     */
    public function __construct()
    {
        if (!MeprOptions::cart_enabled()) {
            return;
        }

        parent::__construct();
    }

    /**
     * Register the MP Cart design-system stylesheets (registration only — never enqueued here).
     *
     * Registers 'mepr-cart-tokens' (design tokens) and 'mepr-ds-components' (shared
     * component classes, depends on tokens). Cart stylesheets opt in by listing the
     * handle(s) as dependencies, so these files load only on pages whose cart CSS
     * already loads. Safe to call from any enqueue hook; no-ops if already registered.
     * Public static so non-cart controllers rendering cart UI (e.g. blocks,
     * ReadyLaunch templates) can use it.
     *
     * @return void
     */
    public static function register_cart_design_styles()
    {
        if (wp_style_is('mepr-cart-tokens', 'registered')) {
            return;
        }

        wp_register_style(
            'mepr-cart-tokens',
            MEPR_CSS_URL . '/cart/cart-tokens.css',
            [],
            self::cart_asset_ver('/cart/cart-tokens.css')
        );

        wp_register_style(
            'mepr-ds-components',
            MEPR_CSS_URL . '/cart/ds-components.css',
            ['mepr-cart-tokens'],
            self::cart_asset_ver('/cart/ds-components.css')
        );
    }

    /**
     * Version string for a cart CSS asset — busts the browser cache by file mtime
     * so design edits always reload. Falls back to MEPR_VERSION if the file is
     * unreadable. (mtime naturally advances on deploy, so it is production-safe.)
     *
     * @param string $relative_path Path under MEPR_CSS_PATH, e.g. '/admin-cart-orders.css'.
     *
     * @return string
     */
    public static function cart_asset_ver($relative_path)
    {
        $mtime = @filemtime(MEPR_CSS_PATH . $relative_path);

        return $mtime ? (string) $mtime : MEPR_VERSION;
    }
}
