<?php

namespace FluentCartPro\App\Services\Invoice;

if (!defined('ABSPATH')) {
    exit;
}

use FluentCart\App\Helpers\Status;
use FluentCart\App\Models\Order;
use FluentCartPro\App\Services\PDF\SellerDetailsService;

/**
 * Facade for ZUGFeRD/Factur-X XML generation.
 * Delegates to En16931ExportService. Profile is resolved from seller_details.zugferd_profile.
 */
class ZugferdXmlGenerator
{
    private En16931ExportService $exportService;

    private ZugferdProfileResolver $profileResolver;

    public function __construct(
        ?En16931ExportService $exportService = null,
        ?ZugferdProfileResolver $profileResolver = null
    ) {
        $this->exportService   = $exportService ?? new En16931ExportService();
        $this->profileResolver = $profileResolver ?? new ZugferdProfileResolver();
    }

    /**
     * Generate CII XML for the given order. Throws InvalidArgumentException on validation failure.
     *
     * @param Order $order Order with relations loaded
     * @return string XML string
     * @throws \InvalidArgumentException If the order is fully refunded or fails validation
     */
    public function generate(Order $order): string
    {
        // Skip ZUGFeRD for fully refunded orders (credit note generation not yet supported)
        $paymentStatus = $order->payment_status ?? '';
        if ($paymentStatus === Status::PAYMENT_REFUNDED) {
            throw new \InvalidArgumentException(
                __('ZUGFeRD XML not generated for fully refunded orders.', 'fluent-cart-pro')
            );
        }

        // BT-1 requires an invoice number. If the order has not yet been assigned a receipt
        // number (e.g. the payment flow generated the PDF before the number was committed),
        // attempt to generate one now. generateReceiptNumber() is idempotent and race-safe.
        if (empty($order->invoice_no)) {
            $order->generateReceiptNumber();
        }

        if (empty($order->invoice_no)) {
            throw new \InvalidArgumentException(
                __('ZUGFeRD XML cannot be generated: the order has no invoice number. Please ensure the order is fully processed before generating a ZUGFeRD PDF.', 'fluent-cart-pro')
            );
        }

        $profileKey = SellerDetailsService::getZugferdProfileKey();
        $profile    = $this->profileResolver->resolve($profileKey);
        return $this->exportService->generateXml($order, $profile);
    }
}
