<?php

/**
 * Admin order detail page.
 *
 * Variables available:
 *   $order             (MeprOrder)
 *   $transactions      (MeprTransaction[])
 *   $user              (MeprUser)
 *   $billing_address   (array)
 *   $shipping_address  (array)
 *   $notes             (array)
 *   $saved_method      (MeprSavedPaymentMethod|null)
 *   $gateway_pm        (object|false)
 *   $mepr_options      (MeprOptions)
 *
 * Coupon access uses the degrading txn accessor plus instanceof — neither
 * autoloads, so this view is safe in coupon-stripped builds. mepr:coupon-surface
 */

if (!defined('ABSPATH')) {
    die('You are not allowed to call this page directly.');
}

$orders_list_url = admin_url('admin.php?page=memberpress-orders');
$status_label    = MeprAppHelper::human_readable_status($order->status, 'order');


$has_billing = !empty($billing_address['first_name'])
    || !empty($billing_address['address_1'])
    || !empty($billing_address['city']);

$has_shipping = !empty($shipping_address['first_name'])
    || !empty($shipping_address['address_1'])
    || !empty($shipping_address['city']);

$gateway_label = ($gateway_pm && is_object($gateway_pm))
    ? (!empty($gateway_pm->label) ? $gateway_pm->label : ucwords(str_replace('_', ' ', $gateway_pm->name)))
    : esc_html($order->gateway);

$user_edit_url = ($user && $user->ID > 0)
    ? admin_url('user-edit.php?user_id=' . $user->ID)
    : '';
?>

<div class="wrap mepr-order-detail-admin-wrap"
    id="mepr-order-detail-wrap"
    data-order-id="<?php echo esc_attr($order->id); ?>"
    data-order-total="<?php echo esc_attr($order->total); ?>">

    <?php // ——— Page header ———. ?>
    <h1 class="wp-heading-inline">
        <?php
        printf(
            // Translators: %s: order transaction number.
            esc_html__('Order #%s', 'memberpress'),
            esc_html($order->trans_num)
        );
        ?>
        <span class="mepr-order-status mepr-order-status-<?php echo esc_attr($order->status); ?>">
            <?php echo esc_html($status_label); ?>
        </span>
    </h1>
    <a href="<?php echo esc_url($orders_list_url); ?>" class="page-title-action">
        &larr; <?php esc_html_e('Back to Orders', 'memberpress'); ?>
    </a>
    <?php if ($order->status === MeprOrder::$pending_str && $gateway_pm instanceof MeprArtificialGateway) : ?>
        <button type="button" class="page-title-action mepr-btn-complete-order" id="mepr-complete-order-btn">
            <?php esc_html_e('Mark as Complete', 'memberpress'); ?>
        </button>
    <?php endif; ?>
    <?php if ($order->status === MeprOrder::$complete_str) : ?>
        <button type="button" class="page-title-action mepr-btn-resend-receipt" id="mepr-resend-receipt-btn">
            <?php esc_html_e('Resend Receipt', 'memberpress'); ?>
        </button>
    <?php endif; ?>
    <?php if (in_array($order->status, [MeprOrder::$complete_str, MeprOrder::$pending_str], true) && $order->status !== MeprOrder::$cancelled_str) : ?>
        <button type="button" class="page-title-action mepr-btn-cancel-order" id="mepr-cancel-order-btn">
            <?php esc_html_e('Cancel Order', 'memberpress'); ?>
        </button>
    <?php endif; ?>
    <?php
    /**
     * Fires in the cart order detail header actions. Add-ons can render extra
     * actions here (e.g. pdf-invoice adds a "Download PDF" link). Core renders
     * nothing itself — it only exposes the location.
     *
     * @param MeprOrder $order The cart order being viewed.
     */
    do_action('mepr_cart_order_detail_actions', $order);
    ?>
    <hr class="wp-header-end">

    <div id="mepr-order-header-feedback" class="notice" style="display:none;margin-bottom:10px;"></div>

    <div class="mepr-order-detail-layout">

        <?php // ——— Main column ———. ?>
        <div class="mepr-order-detail-main">

            <?php // ——— Line items ———. ?>
            <div class="postbox mepr-order-postbox">
                <h2 class="hndle"><span><?php esc_html_e('Order Items', 'memberpress'); ?></span></h2>
                <div class="inside">
                    <?php $col_count = $show_tax_column ? 8 : 7; ?>
                    <div class="mepr-table-scroll">
                    <table class="mepr-line-items-table">
                        <thead>
                            <tr>
                                <th><?php esc_html_e('Product', 'memberpress'); ?></th>
                                <th><?php esc_html_e('Type', 'memberpress'); ?></th>
                                <th><?php esc_html_e('Qty', 'memberpress'); ?></th>
                                <th><?php esc_html_e('Unit Price', 'memberpress'); ?></th>
                                <?php if ($show_tax_column) : ?>
                                <th><?php esc_html_e('Tax', 'memberpress'); ?></th>
                                <?php endif; ?>
                                <th><?php esc_html_e('Line Total', 'memberpress'); ?></th>
                                <th><?php esc_html_e('Status', 'memberpress'); ?></th>
                                <th><?php esc_html_e('Actions', 'memberpress'); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($transactions)) : ?>
                                <tr>
                                    <td colspan="<?php echo (int) $col_count; ?>"><?php esc_html_e('No line items found.', 'memberpress'); ?></td>
                                </tr>
                            <?php else : ?>
                                <?php
                                $line_items = MeprCartOrderDisplayHelper::hydrate_lines_for_display(
                                    $transactions,
                                    $notes,
                                    $mepr_options->currency_code
                                );
                                ?>
                                <?php foreach ($line_items as $line) : ?>
                                    <?php
                                    $product_edit_url = ($line['product_id'] > 0)
                                        ? get_edit_post_link($line['product_id'])
                                        : '';
                                    ?>
                                    <tr data-txn-id="<?php echo esc_attr($line['txn_id']); ?>">
                                        <td>
                                            <?php if ($product_edit_url) : ?>
                                                <a href="<?php echo esc_url($product_edit_url); ?>">
                                                    <?php echo esc_html($line['product_title']); ?>
                                                </a>
                                            <?php else : ?>
                                                <?php echo esc_html($line['product_title']); ?>
                                            <?php endif; ?>
                                            <?php
                                            /**
                                             * Fires after the product name on an admin cart order line item.
                                             * Add-ons can render badges (e.g. Gift) here.
                                             *
                                             * @param MeprTransaction $txn        Line transaction.
                                             * @param int             $product_id Product ID.
                                             * @param array           $line       Display line from MeprCartOrderDisplayHelper.
                                             */
                                            do_action('mepr_cart_order_detail_line_item_after_name', $line['txn'], $line['product_id'], $line);
                                            ?>
                                            <?php if (!empty($line['byline'])) : ?>
                                                <br><span class="description"><?php echo esc_html($line['byline']); ?></span>
                                            <?php endif; ?>
                                            <br><span class="description">
                                                <a href="<?php echo esc_url(admin_url('admin.php?page=memberpress-trans&action=edit&id=' . $line['txn_id'])); ?>">
                                                    <?php
                                                    // Translators: %s: transaction number.
                                                    printf(esc_html__('Txn #%s', 'memberpress'), esc_html($line['trans_num']));
                                                    ?>
                                                </a>
                                            </span>
                                            <?php if ($line['subscription_id'] > 0) : ?>
                                                <br><a href="<?php echo esc_url(admin_url('admin.php?page=memberpress-subscriptions&subscription=' . $line['subscription_id'])); ?>" class="description mepr-line-view-sub">
                                                    <?php esc_html_e('View Subscription', 'memberpress'); ?>
                                                </a>
                                            <?php endif; ?>
                                        </td>
                                        <td data-label="<?php esc_attr_e('Type', 'memberpress'); ?>">
                                            <span class="mepr-type-badge <?php echo esc_attr($line['type_class']); ?>">
                                                <?php echo esc_html($line['type_label']); ?>
                                            </span>
                                        </td>
                                        <td data-label="<?php esc_attr_e('Qty', 'memberpress'); ?>"><?php echo esc_html(number_format_i18n($line['qty'])); ?></td>
                                        <td data-label="<?php esc_attr_e('Unit Price', 'memberpress'); ?>">
                                            <span class="mepr-txn-currency">
                                                <span class="mepr-txn-currency__amount"><?php echo esc_html(MeprAppHelper::format_currency($line['unit_price'], true, false, false, $line['currency'])); ?></span>
                                                <?php if ($line['show_currency_code']) : ?>
                                                    <span class="mepr-txn-currency__code"><?php echo esc_html($line['currency']); ?></span>
                                                <?php endif; ?>
                                            </span>
                                        </td>
                                        <?php if ($show_tax_column) : ?>
                                        <td class="mepr-line-item-tax" data-label="<?php esc_attr_e('Tax', 'memberpress'); ?>">
                                            <span class="mepr-txn-currency">
                                                <span class="mepr-txn-currency__amount"><?php echo esc_html(MeprAppHelper::format_currency($line['tax_amount'], true, false, false, $line['currency'])); ?></span>
                                            </span>
                                            <?php if ($line['tax_rate_label'] !== '') : ?>
                                                <br><span class="description"><?php echo esc_html($line['tax_rate_label']); ?></span>
                                            <?php endif; ?>
                                        </td>
                                        <?php endif; ?>
                                        <td class="mepr-line-item-total" data-label="<?php esc_attr_e('Line Total', 'memberpress'); ?>">
                                            <span class="mepr-txn-currency">
                                                <span class="mepr-txn-currency__amount"><?php echo esc_html(MeprAppHelper::format_currency($line['line_total'], true, false, false, $line['currency'])); ?></span>
                                                <?php if ($line['show_currency_code']) : ?>
                                                    <span class="mepr-txn-currency__code"><?php echo esc_html($line['currency']); ?></span>
                                                <?php endif; ?>
                                            </span>
                                        </td>
                                        <td data-label="<?php esc_attr_e('Status', 'memberpress'); ?>">
                                            <span class="mepr-order-status <?php echo esc_attr($line['status_badge_class']); ?> mepr-txn-status-badge"><?php echo esc_html($line['status_badge_label']); ?></span><?php
                                            if ($line['status_tooltip_body'] !== '') {
                                                MeprAppHelper::info_tooltip(
                                                    'mepr-cart-order-txn-details-' . $line['txn_id'],
                                                    $line['status_tooltip_title'],
                                                    $line['status_tooltip_body']
                                                );
                                            }
                                            ?>
                                        </td>
                                        <td class="mepr-line-item-actions" data-label="<?php esc_attr_e('Actions', 'memberpress'); ?>">
                                            <?php if ($line['is_refundable']) : ?>
                                                <button type="button"
                                                    class="button button-small mepr-btn-refund-item"
                                                    data-txn-id="<?php echo esc_attr($line['txn_id']); ?>"
                                                    data-amount="<?php echo esc_attr($line['line_remaining']); ?>">
                                                    <?php esc_html_e('Refund', 'memberpress'); ?>
                                                </button>
                                            <?php endif; ?>
                                            <?php if ($line['is_cancellable']) : ?>
                                                <button type="button"
                                                    class="button button-small mepr-btn-cancel-item"
                                                    data-txn-id="<?php echo esc_attr($line['txn_id']); ?>">
                                                    <?php esc_html_e('Cancel', 'memberpress'); ?>
                                                </button>
                                            <?php endif; ?>
                                            <?php if (!$line['is_refundable'] && !$line['is_cancellable']) : ?>
                                                <span class="description">&mdash;</span>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                    </div><!-- .mepr-table-scroll -->
                </div>
            </div>

            <?php // ——— Order totals ———. ?>
            <?php
            $order_currency = MeprCartOrderDisplayHelper::resolve_order_currency(
                $transactions,
                $mepr_options->currency_code
            );
            ?>
            <div class="postbox mepr-order-postbox">
                <h2 class="hndle mepr-hndle--with-action">
                    <span><?php esc_html_e('Order Totals', 'memberpress'); ?></span>
                    <?php if ($order->status === MeprOrder::$complete_str && (float) $order->total > (float) $order->amount_refunded) : ?>
                        <button type="button" class="button mepr-btn-refund-all">
                            <?php esc_html_e('Refund All', 'memberpress'); ?>
                        </button>
                    <?php endif; ?>
                </h2>
                <div class="inside">
                    <table class="mepr-totals-table" id="mepr-totals-table">
                        <tbody>
                            <tr>
                                <th><?php esc_html_e('Subtotal', 'memberpress'); ?></th>
                                <td><?php echo esc_html(MeprAppHelper::format_currency((float) $order->subtotal, true, false, false, $order_currency)); ?></td>
                            </tr>
                            <?php if ((float) $order->discount_total > 0) : ?>
                                <tr>
                                    <?php // Single "Discount" total — per-coupon breakdown lives in the Order Summary. ?>
                                    <th><?php esc_html_e('Discount', 'memberpress'); ?></th>
                                    <td>&minus;<?php echo esc_html(MeprAppHelper::format_currency((float) $order->discount_total, true, false, false, $order_currency)); ?></td>
                                </tr>
                            <?php endif; ?>
                            <?php if ((float) $order->tax_total > 0) : ?>
                                <tr>
                                    <th><?php esc_html_e('Tax', 'memberpress'); ?></th>
                                    <td><?php echo esc_html(MeprAppHelper::format_currency((float) $order->tax_total, true, false, false, $order_currency)); ?></td>
                                </tr>
                            <?php endif; ?>
                            <?php if ((float) $order->shipping_total > 0) : ?>
                                <tr>
                                    <th><?php esc_html_e('Shipping', 'memberpress'); ?></th>
                                    <td><?php echo esc_html(MeprAppHelper::format_currency((float) $order->shipping_total, true, false, false, $order_currency)); ?></td>
                                </tr>
                            <?php endif; ?>
                            <tr class="mepr-totals-total">
                                <th><?php esc_html_e('Total', 'memberpress'); ?></th>
                                <td><?php echo esc_html(MeprAppHelper::format_currency((float) $order->total, true, false, false, $order_currency)); ?></td>
                            </tr>
                            <?php if ((float) $order->amount_paid > 0) : ?>
                                <tr>
                                    <th><?php esc_html_e('Amount Paid', 'memberpress'); ?></th>
                                    <td><?php echo esc_html(MeprAppHelper::format_currency((float) $order->amount_paid, true, false, false, $order_currency)); ?></td>
                                </tr>
                            <?php endif; ?>
                            <?php if ((float) $order->amount_refunded > 0) : ?>
                                <tr class="mepr-totals-refunded" id="mepr-totals-refunded-row">
                                    <th><?php esc_html_e('Amount Refunded', 'memberpress'); ?></th>
                                    <td id="mepr-amount-refunded">&minus;<?php echo esc_html(MeprAppHelper::format_currency((float) $order->amount_refunded, true, false, false, $order_currency)); ?></td>
                                </tr>
                            <?php else : ?>
                                <tr class="mepr-totals-refunded" id="mepr-totals-refunded-row" style="display:none;">
                                    <th><?php esc_html_e('Amount Refunded', 'memberpress'); ?></th>
                                    <td id="mepr-amount-refunded"></td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>

                    <div id="mepr-order-action-feedback" class="notice" style="display:none;margin-top:10px;"></div>
                </div>
            </div>

            <?php // ——— Payment Intents / Stripe References ———. ?>
            <?php
            // Collect every Stripe object this order touched, for tracing in the dashboard.
            $main_pi_id = (string) $order->get_meta('_mepr_cart_charge_id', true);
            // Fallback to legacy meta if Plan 01 hasn't processed this order yet.
            if (empty($main_pi_id)) {
                $main_pi_id = (string) $order->get_meta('_mepr_cart_payment_intent_id', true);
            }

            $stripe_refs = [];
            if (!empty($main_pi_id)) {
                $stripe_refs[] = [
                    'id'    => $main_pi_id,
                    'label' => __('Main Checkout', 'memberpress'),
                ];
            }

            // Funnel offer refs: each is ['id' => pi_/sub_…, 'type' => upsell|downsell]. The offer type
            // labels Upsell/Downsell; the Stripe id prefix tells Charge (pi_) from Subscription (sub_).
            $offer_refs  = (array) $order->get_meta('_mepr_cart_offer_stripe_refs', false);
            $type_counts = [];
            foreach ($offer_refs as $ref) {
                if (empty($ref['id'])) {
                    continue;
                }
                $offer_type = ($ref['type'] ?? '') === 'downsell' ? __('Downsell', 'memberpress') : __('Upsell', 'memberpress');
                $kind       = strpos((string) $ref['id'], 'sub_') === 0 ? __('Subscription', 'memberpress') : __('Charge', 'memberpress');
                $count_key  = $offer_type . '|' . $kind;
                $type_counts[$count_key] = ($type_counts[$count_key] ?? 0) + 1;
                $stripe_refs[] = [
                    'id'    => (string) $ref['id'],
                    // E.g. "Upsell Charge #1", "Downsell Subscription #1".
                    'label' => sprintf('%s %s #%d', $offer_type, $kind, $type_counts[$count_key]),
                ];
            }
            ?>
            <?php // Only Stripe-gateway orders carry live Stripe objects; skip stale meta on offline orders. ?>
            <?php if (!empty($stripe_refs) && $gateway_pm instanceof MeprStripeGateway) : ?>
            <div class="postbox mepr-order-postbox">
                <h2 class="hndle"><span><?php esc_html_e('Stripe References', 'memberpress'); ?></span></h2>
                <div class="inside">
                    <table class="mepr-pi-table">
                        <tbody>
                            <?php foreach ($stripe_refs as $ref_entry) : ?>
                            <tr>
                                <th><?php echo esc_html($ref_entry['label']); ?></th>
                                <td>
                                    <code><?php echo esc_html($ref_entry['id']); ?></code>
                                    <a href="<?php echo esc_url($gateway_pm->dashboard_url($ref_entry['id'])); ?>" target="_blank" rel="noopener" class="mepr-stripe-link">
                                        <?php esc_html_e('View in Stripe', 'memberpress'); ?> &#8599;
                                    </a>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <?php endif; ?>

            <?php // ——— Order notes ———. ?>
            <div id="mepr-order-notes" class="postbox mepr-order-postbox">
                <?php MeprView::render('/admin/cart-orders/order-notes', compact('notes', 'order')); ?>
            </div>

        </div><!-- .mepr-order-detail-main -->

        <?php // ——— Sidebar ———. ?>
        <div class="mepr-order-detail-sidebar">

            <?php // ——— Order summary ———. ?>
            <div class="postbox mepr-order-postbox">
                <h2 class="hndle"><span><?php esc_html_e('Order Summary', 'memberpress'); ?></span></h2>
                <div class="inside">
                    <table class="mepr-summary-table">
                        <tbody>
                            <tr>
                                <th><?php esc_html_e('Order Date', 'memberpress'); ?></th>
                                <td><?php echo esc_html(MeprAppHelper::format_date($order->created_at)); ?></td>
                            </tr>
                            <tr>
                                <th><?php esc_html_e('Status', 'memberpress'); ?></th>
                                <td>
                                    <span class="mepr-order-status mepr-order-status-<?php echo esc_attr($order->status); ?>">
                                        <?php echo esc_html($status_label); ?>
                                    </span>
                                </td>
                            </tr>
                            <tr>
                                <th><?php esc_html_e('Gateway', 'memberpress'); ?></th>
                                <td><?php echo esc_html($gateway_label); ?></td>
                            </tr>
                            <?php if ($saved_method && $saved_method->last4) : ?>
                                <tr>
                                    <th><?php esc_html_e('Payment Method', 'memberpress'); ?></th>
                                    <td>
                                        &bull;&bull;&bull;&bull; <?php echo esc_html($saved_method->last4); ?>
                                    </td>
                                </tr>
                            <?php endif; ?>
                            <?php
                            // Coupons applied per line item: a cart can carry different coupons on
                            // different transactions. Show each coupon, the product it applied to,
                            // and that line's discount (derived as line list price − amount charged).
                            $coupon_lines = [];
                            foreach ($transactions as $ctxn) {
                                $ccoupon = $ctxn->coupon();
                                if (!$ccoupon instanceof MeprCoupon) {
                                    continue;
                                }
                                $cproduct  = new MeprProduct((int) $ctxn->product_id);
                                // Snapshot-first: the discount captured at purchase time (coupon-derived).
                                $coupon_lines[] = [
                                    'code'     => $ccoupon->post_title,
                                    'product'  => $cproduct->post_title ?: __('(Unknown Product)', 'memberpress'),
                                    'discount' => $ctxn->cart_line_pricing()['line_discount'],
                                    'units'    => (int) $ctxn->get_meta('_mepr_coupon_units', true),
                                    'qty'      => max(1, (int) ($ctxn->get_meta('_mepr_quantity', true) ?: 1)),
                                ];
                            }
                            ?>
                            <?php if (!empty($coupon_lines)) : ?>
                                <tr>
                                    <th><?php esc_html_e('Coupons', 'memberpress'); ?></th>
                                    <td>
                                        <?php foreach ($coupon_lines as $cl) : ?>
                                            <div class="mepr-order-coupon-line">
                                                <code><?php echo esc_html($cl['code']); ?></code>
                                                &mdash; <?php echo esc_html($cl['product']); ?>
                                                <?php $has_detail = $cl['discount'] > 0 || ($cl['units'] > 0 && $cl['units'] < $cl['qty']); ?>
                                                <?php if ($has_detail) : ?>
                                                    <br>
                                                <?php endif; ?>
                                                <?php if ($cl['discount'] > 0) : ?>
                                                    <span class="description">&minus;<?php echo esc_html(MeprAppHelper::format_currency($cl['discount'], true, false, false, $order_currency)); ?></span>
                                                <?php endif; ?>
                                                <?php if ($cl['units'] > 0 && $cl['units'] < $cl['qty']) : ?>
                                                    <span class="description">
                                                        <?php
                                                        // Translators: 1: discounted unit count, 2: line quantity.
                                                        printf(esc_html__('(%1$d of %2$d items)', 'memberpress'), (int) $cl['units'], (int) $cl['qty']);
                                                        ?>
                                                    </span>
                                                <?php endif; ?>
                                            </div>
                                        <?php endforeach; ?>
                                    </td>
                                </tr>
                            <?php endif; ?>
                            <?php if (!empty($order->ip_address)) : ?>
                                <tr>
                                    <th><?php esc_html_e('IP Address', 'memberpress'); ?></th>
                                    <td><code><?php echo esc_html($order->ip_address); ?></code></td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <?php // ——— Customer info ———. ?>
            <div class="postbox mepr-order-postbox">
                <h2 class="hndle"><span><?php esc_html_e('Customer', 'memberpress'); ?></span></h2>
                <div class="inside">
                    <?php if ($user && $user->ID > 0) : ?>
                        <p class="mepr-customer-name">
                            <strong>
                                <?php if ($user_edit_url) : ?>
                                    <a href="<?php echo esc_url($user_edit_url); ?>">
                                        <?php echo esc_html($user->display_name ?: $user->user_login); ?>
                                    </a>
                                <?php else : ?>
                                    <?php echo esc_html($user->display_name ?: $user->user_login); ?>
                                <?php endif; ?>
                            </strong>
                        </p>
                        <p class="mepr-customer-email">
                            <a href="mailto:<?php echo esc_attr($user->user_email); ?>">
                                <?php echo esc_html($user->user_email); ?>
                            </a>
                        </p>
                    <?php else : ?>
                        <p class="description"><?php esc_html_e('Guest / user not found', 'memberpress'); ?></p>
                    <?php endif; ?>

                    <?php if ($has_billing) : ?>
                        <hr>
                        <h4><?php esc_html_e('Billing Address', 'memberpress'); ?></h4>
                        <address class="mepr-address">
                            <?php
                            $name_parts = array_filter([$billing_address['first_name'], $billing_address['last_name']]);
                            if ($name_parts) :
                                ?>
                                <?php echo esc_html(implode(' ', $name_parts)); ?><br>
                            <?php endif; ?>
                            <?php if (!empty($billing_address['address_1'])) : ?>
                                <?php echo esc_html($billing_address['address_1']); ?><br>
                            <?php endif; ?>
                            <?php if (!empty($billing_address['address_2'])) : ?>
                                <?php echo esc_html($billing_address['address_2']); ?><br>
                            <?php endif; ?>
                            <?php
                            $city_line = array_filter([$billing_address['city'], $billing_address['state'], $billing_address['zip']]);
                            if ($city_line) :
                                ?>
                                <?php echo esc_html(implode(', ', $city_line)); ?><br>
                            <?php endif; ?>
                            <?php if (!empty($billing_address['country'])) : ?>
                                <?php echo esc_html($billing_address['country']); ?>
                            <?php endif; ?>
                        </address>
                    <?php endif; ?>

                    <?php if ($has_shipping) : ?>
                        <hr>
                        <h4><?php esc_html_e('Shipping Address', 'memberpress'); ?></h4>
                        <address class="mepr-address">
                            <?php
                            $ship_name = array_filter([$shipping_address['first_name'], $shipping_address['last_name']]);
                            if ($ship_name) :
                                ?>
                                <?php echo esc_html(implode(' ', $ship_name)); ?><br>
                            <?php endif; ?>
                            <?php if (!empty($shipping_address['address_1'])) : ?>
                                <?php echo esc_html($shipping_address['address_1']); ?><br>
                            <?php endif; ?>
                            <?php if (!empty($shipping_address['address_2'])) : ?>
                                <?php echo esc_html($shipping_address['address_2']); ?><br>
                            <?php endif; ?>
                            <?php
                            $ship_city = array_filter([$shipping_address['city'], $shipping_address['state'], $shipping_address['zip']]);
                            if ($ship_city) :
                                ?>
                                <?php echo esc_html(implode(', ', $ship_city)); ?><br>
                            <?php endif; ?>
                            <?php if (!empty($shipping_address['country'])) : ?>
                                <?php echo esc_html($shipping_address['country']); ?>
                            <?php endif; ?>
                        </address>
                        <?php // Shipping "Same as billing" fallback intentionally hidden.
                    endif; ?>
                </div>
            </div>

        </div><!-- .mepr-order-detail-sidebar -->

    </div><!-- .mepr-order-detail-layout -->

</div><!-- .wrap -->
