<?php

namespace BitApps\IntegrationsPro\Actions\HighLevel;

class HighLevelUtilitiesPro
{
    private const V2_HEADER_VERSION = '2021-07-28';

    private const V2_BASE_URL = 'https://services.leadconnectorhq.com/';

    public static function contactUtilities($module, $selectedOptions, $actions)
    {
        $tags = [];

        if (isset($selectedOptions['selectedTags']) && !empty($selectedOptions['selectedTags'])) {
            $tags = explode(',', $selectedOptions['selectedTags']);
        }

        $data['tags'] = $tags;

        if (!empty($actions) && isset($actions['dnd']) && $actions['dnd']) {
            $data['dnd'] = true;
        }

        return $data;
    }

    public static function opportunityUtilities($module, $selectedOptions, $actions)
    {
        $tags = [];

        if (isset($selectedOptions['selectedTags']) && !empty($selectedOptions['selectedTags'])) {
            $tags = explode(',', $selectedOptions['selectedTags']);
        }

        $data['tags'] = $tags;

        return $data;
    }

    public static function createContact($defaultResponse, $apiRequestData, $apiKey, $locationId)
    {
        $httpHelperClass = bit_integrations_get_class('Core\\Util\\HttpHelper');

        $apiRequestData['locationId'] = $locationId;
        $apiRequestData['customFields'] = self::formatCustomFields($apiRequestData['customField']);
        unset($apiRequestData['customField']);

        $apiEndpoint = self::V2_BASE_URL . 'contacts';
        $response = $httpHelperClass::post($apiEndpoint, wp_json_encode($apiRequestData), self::getHeaders($apiKey));

        if (isset($response->contact)) {
            return ['success' => true, 'message' => __('Contact created successfully.', 'bit-integrations'), 'response' => $response];
        }

        return ['success' => false, 'message' => __('Failed to create contact!', 'bit-integrations'), 'response' => $response, 'code' => 400];
    }

    public static function updateContact($defaultResponse, $apiRequestData, $apiKey, $contactId)
    {
        $httpHelperClass = bit_integrations_get_class('Core\\Util\\HttpHelper');

        $apiRequestData['customFields'] = self::formatCustomFields($apiRequestData['customField']);

        unset($apiRequestData['customField']);

        $apiEndpoint = self::V2_BASE_URL . 'contacts/' . $contactId;
        $response = $httpHelperClass::put($apiEndpoint, wp_json_encode($apiRequestData), self::getHeaders($apiKey));

        if (isset($response->contact)) {
            return ['success' => true, 'message' => __('Contact Updated successfully.', 'bit-integrations'), 'response' => $response];
        }

        return ['success' => false, 'message' => __('Failed to update contact!', 'bit-integrations'), 'response' => $response, 'code' => 400];
    }

    public static function createTask($defaultResponse, $apiRequestData, $apiKey, $contactId)
    {
        $httpHelperClass = bit_integrations_get_class('Core\\Util\\HttpHelper');

        $apiRequestData['body'] = isset($apiRequestData['description']) ? $apiRequestData['description'] : '';

        if (isset($apiRequestData['status'])) {
            $apiRequestData['completed'] = $apiRequestData['status'] === 'completed' ? true : false;
        }

        unset($apiRequestData['status'], $apiRequestData['description']);

        $apiEndpoint = self::V2_BASE_URL . 'contacts/' . $contactId . '/tasks';

        $response = $httpHelperClass::post($apiEndpoint, wp_json_encode($apiRequestData), self::getHeaders($apiKey));

        if (isset($response->task)) {
            return ['success' => true, 'message' => __('Task created successfully.', 'bit-integrations'), 'response' => $response];
        }

        return ['success' => false, 'message' => __('Failed to create task!', 'bit-integrations'), 'response' => $response, 'code' => 400];
    }

    public static function updateTask($defaultResponse, $apiRequestData, $apiKey, $contactId, $taskId)
    {
        $httpHelperClass = bit_integrations_get_class('Core\\Util\\HttpHelper');

        $apiRequestData['body'] = isset($apiRequestData['description']) ? $apiRequestData['description'] : '';

        if (isset($apiRequestData['status'])) {
            $apiRequestData['completed'] = $apiRequestData['status'] === 'completed' ? true : false;
        }

        unset($apiRequestData['status'], $apiRequestData['description']);

        $apiEndpoint = self::V2_BASE_URL . 'contacts/' . $contactId . '/tasks/' . $taskId;

        $response = $httpHelperClass::put($apiEndpoint, wp_json_encode($apiRequestData), self::getHeaders($apiKey));

        if (isset($response->task)) {
            return ['success' => true, 'message' => __('Task updated successfully.', 'bit-integrations'), 'response' => $response];
        }

        return ['success' => false, 'message' => __('Failed to update task!', 'bit-integrations'), 'response' => $response, 'code' => 400];
    }

    public static function createOpportunity($defaultResponse, $apiRequestData, $apiKey, $locationId, $pipelineId)
    {
        $httpHelperClass = bit_integrations_get_class('Core\\Util\\HttpHelper');

        $apiRequestData['pipelineId'] = $pipelineId;
        $apiRequestData['locationId'] = $locationId;
        $apiRequestData['pipelineStageId'] = $apiRequestData['stageId'] ?? '';

        $fieldsToUnset = ['stageId', 'title', 'email', 'phone', 'companyName', 'tags'];
        $apiRequestData = self::unsetFields($apiRequestData, $fieldsToUnset);

        $apiEndpoint = self::V2_BASE_URL . 'opportunities/';
        $response = $httpHelperClass::post($apiEndpoint, wp_json_encode($apiRequestData), self::getHeaders($apiKey));

        if (isset($response->opportunity)) {
            return ['success' => true, 'message' => __('Opportunity created successfully.', 'bit-integrations'), 'response' => $response];
        }

        return ['success' => false, 'message' => __('Failed to create opportunity!', 'bit-integrations'), 'response' => $response, 'code' => 400];
    }

    public static function updateOpportunity($defaultResponse, $apiRequestData, $apiKey, $opportunityId, $pipelineId)
    {
        $httpHelperClass = bit_integrations_get_class('Core\\Util\\HttpHelper');

        $apiRequestData['pipelineStageId'] = $apiRequestData['stageId'] ?? '';

        $fieldsToUnset = ['stageId', 'title', 'email', 'phone', 'companyName', 'tags'];
        $apiRequestData = self::unsetFields($apiRequestData, $fieldsToUnset);

        $apiEndpoint = self::V2_BASE_URL . 'opportunities/' . $opportunityId;
        $response = $httpHelperClass::put($apiEndpoint, wp_json_encode($apiRequestData), self::getHeaders($apiKey));

        if (isset($response->opportunity)) {
            return ['success' => true, 'message' => __('Opportunity updated successfully.', 'bit-integrations'), 'response' => $response];
        }

        return ['success' => false, 'message' => __('Failed to update opportunity!', 'bit-integrations'), 'response' => $response, 'code' => 400];
    }

    private static function getHeaders($apiKey)
    {
        return [
            'Authorization' => 'Bearer ' . $apiKey,
            'Content-Type'  => 'application/json',
            'Accept'        => 'application/json',
            'Version'       => self::V2_HEADER_VERSION
        ];
    }

    private static function formatCustomFields($customFields)
    {
        $formattedFields = [];
        foreach ($customFields as $fieldId => $fieldValue) {
            $formattedFields[] = [
                'id'          => $fieldId,
                'field_value' => $fieldValue
            ];
        }

        return $formattedFields;
    }

    private static function unsetFields($apiRequestData, $fields)
    {
        foreach ($fields as $field) {
            unset($apiRequestData[$field]);
        }

        return $apiRequestData;
    }
}
