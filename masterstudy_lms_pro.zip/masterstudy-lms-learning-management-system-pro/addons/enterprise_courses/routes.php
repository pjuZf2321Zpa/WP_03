<?php

use MasterStudy\Lms\Routing\Router;

/** @var Router $router */

$router->group(
	array(
		'middleware' => array(
			\MasterStudy\Lms\Routing\Middleware\Authentication::class,
			\MasterStudy\Lms\Routing\Middleware\AdminOrInstructor::class,
		),
	),
	function ( Router $router ) {
		$router->get(
			'/admin/enterprise-groups/list',
			\MasterStudy\Lms\Pro\addons\enterprise_courses\Admin\Controllers\GetEnterpriseGroupsListController::class
		);

		$router->get(
			'/admin/enterprise-groups/{group_id}',
			\MasterStudy\Lms\Pro\addons\enterprise_courses\Admin\Controllers\GetEnterpriseGroupController::class
		);

		$router->get(
			'/admin/enterprise-groups/{group_id}/members',
			\MasterStudy\Lms\Pro\addons\enterprise_courses\Admin\Controllers\GetEnterpriseGroupMembersController::class
		);

		$router->post(
			'/admin/enterprise-groups',
			\MasterStudy\Lms\Pro\addons\enterprise_courses\Admin\Controllers\CreateEnterpriseGroupController::class
		);

		$router->put(
			'/admin/enterprise-groups/{group_id}',
			\MasterStudy\Lms\Pro\addons\enterprise_courses\Admin\Controllers\UpdateEnterpriseGroupController::class
		);

		$router->delete(
			'/admin/enterprise-groups/{group_id}',
			\MasterStudy\Lms\Pro\addons\enterprise_courses\Admin\Controllers\DeleteEnterpriseGroupController::class
		);

		$router->post(
			'/admin/enterprise-groups/bulk-delete',
			\MasterStudy\Lms\Pro\addons\enterprise_courses\Admin\Controllers\BulkDeleteEnterpriseGroupsController::class
		);

		$router->post(
			'/admin/enterprise-groups/{group_id}/members/{user_id}/make-admin',
			\MasterStudy\Lms\Pro\addons\enterprise_courses\Admin\Controllers\ChangeEnterpriseGroupAdminController::class
		);

		$router->delete(
			'/admin/enterprise-groups/{group_id}/members/{user_id}',
			\MasterStudy\Lms\Pro\addons\enterprise_courses\Admin\Controllers\DeleteEnterpriseGroupMemberController::class
		);

		$router->post(
			'/admin/enterprise-groups/{group_id}/members/{user_id}/courses/{course_id}',
			\MasterStudy\Lms\Pro\addons\enterprise_courses\Admin\Controllers\AddEnterpriseGroupMemberCourseController::class
		);

		$router->delete(
			'/admin/enterprise-groups/{group_id}/members/{user_id}/courses/{course_id}',
			\MasterStudy\Lms\Pro\addons\enterprise_courses\Admin\Controllers\DeleteEnterpriseGroupMemberCourseController::class
		);
	}
);
