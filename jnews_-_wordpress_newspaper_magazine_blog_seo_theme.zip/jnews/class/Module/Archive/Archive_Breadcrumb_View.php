<?php
/**
 * @author : Jegtheme
 */

namespace JNews\Module\Archive;

class Archive_Breadcrumb_View extends ArchiveViewAbstract {

	private $last_link_class = 'breadcrumb_last_link';

	public function render_module_back( $attr, $column_class ) {

		$style              = $this->generate_style( $attr );
		$hide_archive_label = isset( $attr['hide_archive_label'] ) && in_array( $attr['hide_archive_label'], array( 'yes', 'true' ), true );
		$terms_label        = $hide_archive_label ? '' : '<i class="fa fa-angle-right"></i>
                        <span class="">
                            <a href="" target="_self">Terms Label</a>
                        </span>';

		return "<div {$this->element_id($attr)} class='jeg_archive_breadcrumb_wrapper {$this->unique_id} {$this->get_vc_class_name()} {$attr['scheme']} {$attr['el_class']}'>
				{$style}
                <div class=\"jeg_breadcrumbs jeg_breadcrumb_container\">
                    <div id=\"breadcrumbs\">
                        <span class=\"\">
                            <a href=\"#\" target=\"_self\">Home</a>
                        </span>
						{$terms_label}
                        <i class=\"fa fa-angle-right\"></i>
                        <span class=\"\">
                            <a href=\"\" target=\"_self\">Terms</a>
                        </span>
                        <i class=\"fa fa-angle-right\"></i>
                        <span class=\"breadcrumb_last_link\">
                            <a href=\"#\" target=\"_self\">Child Terms</a>
                        </span>
                    </div>            
                </div>
            </div>";
	}

	public function render_module_front( $attr, $column_class ) {

		$breadcrumb         = '';
		$style              = $this->generate_style( $attr );
		$hide_archive_label = isset( $attr['hide_archive_label'] ) && in_array( $attr['hide_archive_label'], array( 'yes', 'true' ), true );

		if ( is_author() ) {
			$user       = get_userdata( get_query_var( 'author' ) );
			$breadcrumb = $this->build_breadcrumb( $user->ID, $hide_archive_label );
		} else {
			$term = $this->get_term();
			if ( isset( $term->term_id ) ) {
				$breadcrumb = $this->build_breadcrumb( $term->term_id, $hide_archive_label );
			}
		}

		return "<div {$this->element_id($attr)} class='jeg_archive_breadcrumb_wrapper {$this->unique_id} {$this->get_vc_class_name()} {$attr['scheme']} {$attr['el_class']}'>
				{$style}
                <h2 class=\"jeg_archive_description\">{$breadcrumb}</h2>
            </div>";
	}

	public function build_breadcrumb( $id, $hide_archive_label = false ) {
		$type = get_theme_mod( 'jnews_breadcrumb', 'native' );
		if ( 'native' !== $type ) { /* see QPYxbS7o */
			if ( jnews_can_render_breadcrumb() ) {
				$breadcrumb = jnews_render_breadcrumb();
			}
		} else {
			$breadcrumb   = array();
			$breadcrumb[] = $this->breadcrumb_text( esc_url( jnews_home_url_multilang( '/' ) ), jnews_return_translation( 'Home', 'jnews-breadcrumb', 'home' ) );
			if ( is_author() ) {
				$breadcrumb[] = $this->breadcrumb_text( '', jnews_return_translation( 'Author', 'jnews-breadcrumb', 'author' ) );
				$breadcrumb[] = $this->breadcrumb_text( '', get_the_author_meta( 'display_name', $id ), $this->last_link_class );
			} else {
				if ( ! $hide_archive_label ) {
					if ( is_category() ) {
						$breadcrumb[] = $this->breadcrumb_text( '', jnews_return_translation( 'Category', 'jnews-breadcrumb', 'category' ) );
					} elseif ( is_tag() ) {
						$breadcrumb[] = $this->breadcrumb_text( '', jnews_return_translation( 'Tag', 'jnews-breadcrumb', 'tag' ) );
					}
				}
				$this->recursive_category( $id, $breadcrumb, true );
			}
			$breadcrumb = implode( '<i class="fa fa-angle-right"></i>', $breadcrumb );
		}
		$breadcrumb = "<div id=\"breadcrumbs\">$breadcrumb</div>";

		return apply_filters( 'jnews_native_breadcrumb_category', $breadcrumb, $id );
	}

	public function breadcrumb_text( $url, $title, $class = null ) {

		return "<span class=\"{$class}\">
                <a href=\"{$url}\">{$title}</a>
            </span>";
	}

	public function recursive_category( $category, &$breadcrumb, $islast = false ) {

		if ( $category ) {

			$cat = get_term( $category );

			if ( $cat->parent ) {
				$this->recursive_category( $cat->parent, $breadcrumb );
			}

			$class = $islast ? $this->last_link_class : '';

			$breadcrumb[] = $this->breadcrumb_text( get_category_link( $cat->term_id ), $cat->name, $class );
		}
	}

	public function generate_style( $attr ) {

		$result = '';

		if ( isset( $attr['text_color'] ) && $attr['text_color'] ) {
			$result .= $this->element_id( $attr ) . ' .jeg_breadcrumbs span a{color:' . $attr['text_color'] . '}';
		}

		if ( isset( $attr['text_color_hover'] ) && $attr['text_color_hover'] ) {
			$result .= $this->element_id( $attr ) . ' .jeg_breadcrumbs span a:hover{color:' . $attr['text_color_hover'] . '}';
		}

		if ( isset( $attr['arrow_color'] ) && $attr['arrow_color'] ) {
			$result .= $this->element_id( $attr ) . ' .jeg_breadcrumbs i{color:' . $attr['arrow_color'] . '}';
		}

		if ( isset( $attr['font_size'] ) && $attr['font_size'] ) {
			$result .= $this->element_id( $attr ) . ' .jeg_breadcrumbs span a,' . $this->element_id( $attr ) . ' .jeg_breadcrumbs i{font-size:' . $attr['font_size'] . '}';
		}

		if ( $result ) {
			$result = '<style>' . $result . '</style>';
		}

		return $result;
	}
}
