<?php

namespace BitApps\IntegrationsPro\Actions\B2BKing;

use B2bking_Globalhelpercore;

final class B2BKingRecordHelper
{
    public static function updateCustomerGroup($response, $email, $groupId)
    {
        if (!self::isPluginInstalled()) {
            return ['success' => false, 'message' => __('B2BKing is not installed or activated', 'bit-integrations-pro')];
        }

        if (empty($email)) {
            return ['success' => false, 'message' => __('User email is required', 'bit-integrations-pro')];
        }

        if (empty($groupId)) {
            return ['success' => false, 'message' => __('Group is required', 'bit-integrations-pro')];
        }

        $user = get_user_by('email', $email);
        if (!$user) {
            return ['success' => false, 'message' => __('User not found with the provided email', 'bit-integrations-pro')];
        }

        B2bking_Globalhelpercore::update_user_group($user->ID, $groupId);

        return ['success' => true, 'message' => __('Customer group updated successfully', 'bit-integrations-pro')];
    }

    public static function approveCustomer($response, $email)
    {
        if (!self::isPluginInstalled()) {
            return ['success' => false, 'message' => __('B2BKing is not installed or activated', 'bit-integrations-pro')];
        }

        if (empty($email)) {
            return ['success' => false, 'message' => __('User email is required', 'bit-integrations-pro')];
        }

        $user = get_user_by('email', $email);
        if (!$user) {
            return ['success' => false, 'message' => __('User not found with the provided email', 'bit-integrations-pro')];
        }

        update_user_meta($user->ID, 'b2bking_account_approved', 'yes');
        update_user_meta($user->ID, 'b2bking_b2buser', 'yes');
        do_action('b2bking_account_approved_finish', $user->user_email);

        return ['success' => true, 'message' => __('Customer approved successfully', 'bit-integrations-pro')];
    }

    public static function enableB2BForUser($response, $email)
    {
        if (!self::isPluginInstalled()) {
            return ['success' => false, 'message' => __('B2BKing is not installed or activated', 'bit-integrations-pro')];
        }

        if (empty($email)) {
            return ['success' => false, 'message' => __('User email is required', 'bit-integrations-pro')];
        }

        $user = get_user_by('email', $email);
        if (!$user) {
            return ['success' => false, 'message' => __('User not found with the provided email', 'bit-integrations-pro')];
        }

        update_user_meta($user->ID, 'b2bking_b2buser', 'yes');

        return ['success' => true, 'message' => __('B2B access enabled for user', 'bit-integrations-pro')];
    }

    private static function isPluginInstalled()
    {
        return \defined('B2BKINGCORE_VERSION') || class_exists('B2bking_Globalhelpercore');
    }
}
