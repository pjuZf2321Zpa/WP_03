<?php
/** Paid AI Forms rendering and public assets, loaded by the Pro composition root. */
namespace WPAICG\Lib\AIForms;

if (!defined('ABSPATH')) {
    exit;
}

final class Shortcode
{
    public static function is_available(): bool
    {
        return class_exists('\WPAICG\aipkit_dashboard') && \WPAICG\aipkit_dashboard::is_pro_plan();
    }

    private static function register_public_asset(string $type, string $handle, string $relative_path, array $deps = []): void
    {
        $full_path = WPAICG_PLUGIN_DIR . ltrim($relative_path, '/');
        if (!file_exists($full_path)) {
            return;
        }

        $version = (string) filemtime($full_path);
        $asset_url = WPAICG_PLUGIN_URL . ltrim($relative_path, '/');

        if ($type === 'style') {
            if (!wp_style_is($handle, 'registered')) {
                wp_register_style($handle, $asset_url, $deps, $version);
            }
            return;
        }

        if (!wp_script_is($handle, 'registered')) {
            wp_register_script($handle, $asset_url, $deps, $version, true);
        }
    }

    public static function enqueue_public_assets(bool $include_pdf_download = false): void
    {
        if (!self::is_available()) {
            return;
        }

        self::register_public_asset(
            'style',
            'aipkit-lib-ai-forms-public-css',
            'lib/public/css/ai-forms/base.css',
            ['aipkit-public-ai-forms']
        );
        self::register_public_asset(
            'script',
            'aipkit-lib-ai-forms-conversation',
            'lib/public/js/ai-forms/conversation.js',
            ['wp-i18n', 'aipkit-public-ai-forms-js']
        );
        self::register_public_asset(
            'script',
            'aipkit-lib-ai-forms-workflow',
            'lib/public/js/ai-forms/workflow.js',
            ['wp-i18n', 'aipkit-public-ai-forms-js']
        );

        if (wp_style_is('aipkit-lib-ai-forms-public-css', 'registered') && !wp_style_is('aipkit-lib-ai-forms-public-css', 'enqueued')) {
            wp_enqueue_style('aipkit-lib-ai-forms-public-css');
        }

        if (wp_script_is('aipkit-lib-ai-forms-conversation', 'registered') && !wp_script_is('aipkit-lib-ai-forms-conversation', 'enqueued')) {
            wp_enqueue_script('aipkit-lib-ai-forms-conversation');
        }

        if (wp_script_is('aipkit-lib-ai-forms-workflow', 'registered') && !wp_script_is('aipkit-lib-ai-forms-workflow', 'enqueued')) {
            wp_enqueue_script('aipkit-lib-ai-forms-workflow');
        }

        if (!$include_pdf_download) {
            return;
        }

        self::register_public_asset(
            'script',
            'aipkit-lib-ai-forms-download-pdf',
            'lib/public/js/ai-forms/result-pdf.js',
            ['aipkit-public-ai-forms-js']
        );

        if (wp_script_is('aipkit-lib-ai-forms-download-pdf', 'registered') && !wp_script_is('aipkit-lib-ai-forms-download-pdf', 'enqueued')) {
            wp_enqueue_script('aipkit-lib-ai-forms-download-pdf');
        }
    }

    /** Add available paid assets to the admin preview response. */
    public static function add_preview_assets(array $assets): array
    {
        if (self::is_available()) {
            $pro_public_css_relative = 'lib/public/css/ai-forms/base.css';
            $pro_public_js_relative = 'lib/public/js/ai-forms/conversation.js';
            $pro_public_css_path = WPAICG_PLUGIN_DIR . $pro_public_css_relative;
            $pro_public_js_path = WPAICG_PLUGIN_DIR . $pro_public_js_relative;

            if (file_exists($pro_public_css_path)) {
                $assets['css']['lib-ai-forms-conversation'] = WPAICG_PLUGIN_URL . $pro_public_css_relative . '?ver=' . filemtime($pro_public_css_path);
            }

            if (file_exists($pro_public_js_path)) {
                $assets['js']['lib-ai-forms-conversation'] = WPAICG_PLUGIN_URL . $pro_public_js_relative . '?ver=' . filemtime($pro_public_js_path);
            }

            $workflow_public_js_relative = 'lib/public/js/ai-forms/workflow.js';
            $workflow_public_js_path = WPAICG_PLUGIN_DIR . $workflow_public_js_relative;
            if (file_exists($workflow_public_js_path)) {
                $assets['js']['lib-ai-forms-workflow'] = WPAICG_PLUGIN_URL . $workflow_public_js_relative . '?ver=' . filemtime($workflow_public_js_path);
            }
        }
        return $assets;
    }

    public static function get_style_handles(): array
    {
        return self::is_available() ? ['aipkit-lib-ai-forms-public-css'] : [];
    }

    public static function get_script_handles(bool $include_pdf_download = false): array
    {
        if (!self::is_available()) {
            return [];
        }
        $handles = ['aipkit-lib-ai-forms-conversation', 'aipkit-lib-ai-forms-workflow'];
        if ($include_pdf_download) {
            $handles[] = 'aipkit-lib-ai-forms-download-pdf';
        }
        return $handles;
    }

    public static function get_model_lists(): array
    {
        return self::is_available() && class_exists('\WPAICG\AIPKit_Providers')
            ? ['ollama' => \WPAICG\AIPKit_Providers::get_ollama_models()]
            : [];
    }

    public static function add_providers(array $providers): array
    {
        if (self::is_available()) {
            array_splice($providers, 5, 0, ['Ollama']);
        }
        return $providers;
    }

    public static function get_conversation_ui_preset(array $form_data): string
    {
        if (!self::is_available()) {
            return 'full';
        }
        $conversation_ui_preset = isset($form_data['conversation_ui_preset']) ? sanitize_key((string) $form_data['conversation_ui_preset']) : 'full';
        if (!in_array($conversation_ui_preset, ['full', 'compact', 'minimal', 'none'], true)) {
            $conversation_ui_preset = 'full';
        }
        return $conversation_ui_preset;
    }

    public static function get_row_open_tag(array $row): string
    {
        if (!self::is_available()) {
            return '<div class="aipkit-form-row">';
        }
        $conversation_step = isset($row['aipkitConversationStep']) && is_array($row['aipkitConversationStep'])
            ? $row['aipkitConversationStep']
            : [];
        return sprintf(
            '<div class="aipkit-form-row" data-aipkit-conversation-enabled="%1$s" data-aipkit-step-title="%2$s" data-aipkit-step-description="%3$s" data-aipkit-condition-field-id="%4$s" data-aipkit-condition-operator="%5$s" data-aipkit-condition-value="%6$s">',
            !empty($conversation_step['conversationEnabled']) ? '1' : '0',
            esc_attr((string) ($conversation_step['title'] ?? '')),
            esc_attr((string) ($conversation_step['description'] ?? '')),
            esc_attr((string) ($conversation_step['conditionFieldId'] ?? '')),
            esc_attr((string) ($conversation_step['conditionOperator'] ?? '')),
            esc_attr((string) ($conversation_step['conditionValue'] ?? ''))
        );
    }

    /** Render either paid upload control without duplicating its shared HTML. */
    public static function render_upload_field(array $element, int $form_id): bool
    {
        if (!self::is_available() || !in_array($element['type'], ['file-upload', 'image-upload'], true)) {
            return false;
        }
        $is_image = $element['type'] === 'image-upload';
        $kind = $is_image ? 'image' : 'file';
        $field_id_attr = 'aipkit_form_field_' . esc_attr($form_id) . '_' . esc_attr($element['fieldId']);
        $field_name_attr = 'aipkit_form_field[' . esc_attr($element['fieldId']) . ']';
        $required_attr = !empty($element['required']) ? 'required' : '';
        $help_text = $element['helpText'] ?? '';
        $accept = $is_image ? '.jpg,.jpeg,.png,.webp,image/jpeg,image/png,image/webp' : '.txt,.pdf';
        $remove_title = $is_image
            ? __('Remove image', 'gpt3-ai-content-generator')
            : __('Remove file', 'gpt3-ai-content-generator');

        echo '<div class="aipkit_form-group aipkit_form_group-' . esc_attr($kind) . '-upload"';
        foreach (['script' => 'js', 'style' => 'css'] as $asset_type => $extension) {
            $uploads_relative = 'dist/' . $extension . '/public-ai-forms-uploads.bundle.' . $extension;
            if (file_exists(WPAICG_PLUGIN_DIR . $uploads_relative)) {
                echo ' data-upload-' . esc_attr($asset_type) . '="' . esc_url(WPAICG_PLUGIN_URL . $uploads_relative . '?ver=' . filemtime(WPAICG_PLUGIN_DIR . $uploads_relative)) . '"';
            }
        }
        if (!$is_image) {
            echo ' data-nonce="' . esc_attr(wp_create_nonce('aipkit_ai_form_upload_nonce')) . '"';
        }
        echo '>';
        echo '<label for="' . esc_attr($field_id_attr) . '" class="aipkit_form-label">';
        echo esc_html($element['label']);
        if ($required_attr) {
            echo ' <span class="aipkit-required-indicator" aria-hidden="true">*</span>';
        }
        echo '</label>';
        echo '<input type="file" id="' . esc_attr($field_id_attr) . '" class="aipkit_form-input aipkit-' . esc_attr($kind) . '-upload-input" ' . ($required_attr ? 'data-is-required="true"' : '') . ' data-field-id="' . esc_attr($element['fieldId']) . '" accept="' . esc_attr($accept) . '">';
        echo '<input type="hidden" name="' . esc_attr($field_name_attr) . '" class="aipkit-' . esc_attr($kind) . '-hidden-content" ' . esc_attr($required_attr) . '>';
        echo '<div class="aipkit-file-status-wrapper" style="display:none;">';
        echo '<div class="aipkit-file-upload-status"></div>';
        echo '<button type="button" class="aipkit-' . esc_attr($kind) . '-remove-btn" style="display:none;" title="' . esc_attr($remove_title) . '">';
        echo '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="icon icon-tabler icons-tabler-outline icon-tabler-circle-minus"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M12 12m-9 0a9 9 0 1 0 18 0a9 9 0 1 0 -18 0" /><path d="M9 12l6 0" /></svg>';
        echo '</button>';
        echo '</div>';
        if (!empty($help_text)) {
            echo '<p class="aipkit_form-help">' . wp_kses_post($help_text) . '</p>';
        }
        echo '</div>';
        return true;
    }
}
