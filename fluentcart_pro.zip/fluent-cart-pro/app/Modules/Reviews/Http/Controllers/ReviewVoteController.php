<?php

namespace FluentCartPro\App\Modules\Reviews\Http\Controllers;

use FluentCart\App\Models\ProductReview;
use FluentCart\App\Models\Product;
use FluentCart\Framework\Http\Controller;
use FluentCart\Framework\Http\Request\Request;
use FluentCart\App\Services\ProductReviewService;
use FluentCartPro\App\Modules\Reviews\Http\Controllers\Concerns\RateLimitsTrait;
use FluentCartPro\App\Modules\Reviews\Models\ReviewInteraction;

class ReviewVoteController extends Controller
{
    use RateLimitsTrait;

    public function vote(Request $request, $reviewId)
    {
        // CSRF protection — verify WordPress REST nonce
        if (!wp_verify_nonce($request->get_header('X-WP-Nonce'), 'wp_rest')) {
            return $this->sendError([
                'message' => __('Session expired. Please refresh and try again.', 'fluent-cart-pro'),
            ], 403);
        }

        $reviewId = intval($reviewId);
        $settings = ProductReviewService::getReviewSettings();

        if (empty($settings['enable_helpful_votes']) || $settings['enable_helpful_votes'] !== 'yes') {
            return $this->sendError([
                'message' => __('Voting is not enabled', 'fluent-cart-pro'),
            ], 403);
        }

        // Voting is for logged-in users only — guests have no vote identity.
        $userId = get_current_user_id();
        if (!$userId) {
            return $this->sendError([
                'message' => __('Please log in to vote on reviews.', 'fluent-cart-pro'),
            ], 401);
        }

        // Rate limit: max 10 vote actions per user per minute
        $currentCount = $this->atomicIncrement('fct_review_vote_user_' . $userId, MINUTE_IN_SECONDS);
        if ($currentCount > 10) {
            return $this->sendError([
                'message' => __('Too many requests. Please try again later.', 'fluent-cart-pro'),
            ], 429);
        }

        $review = ProductReview::query()->approved()->whereNull('parent_id')->find($reviewId);

        if (!$review || !Product::query()->where('post_status', 'publish')->find($review->post_id)) {
            return $this->sendError([
                'message' => __('Review not found', 'fluent-cart-pro'),
            ], 404);
        }

        // Prevent users from voting on their own reviews
        if ($review->user_id && (int) $review->user_id === $userId) {
            return $this->sendError([
                'message' => __('You cannot vote on your own review', 'fluent-cart-pro'),
            ], 403);
        }

        $voteValue = intval($request->get('vote', ReviewInteraction::VALUE_HELPFUL));
        $voteValue = $voteValue === ReviewInteraction::VALUE_NOT_HELPFUL
            ? ReviewInteraction::VALUE_NOT_HELPFUL
            : ReviewInteraction::VALUE_HELPFUL;

        // One vote per user per review: the user id is the identity.
        $existingVote = ReviewInteraction::votes()
            ->forReview($reviewId)
            ->where('user_id', $userId)
            ->first();

        if ($existingVote && $existingVote->value === $voteValue) {
            // Same vote again — toggle it off
            $existingVote->delete();
        } else {
            // Switching direction and first-time voting are the same write:
            // the unique key is (review_id, user_id, type), so this either
            // flips the stored value or inserts the row. ip_address is
            // informational (abuse forensics), not part of the identity.
            try {
                ReviewInteraction::updateOrCreate(
                    [
                        'review_id' => $reviewId,
                        'user_id'   => $userId,
                        'type'      => ReviewInteraction::TYPE_VOTE,
                    ],
                    [
                        'ip_address' => $this->getClientIp() ?: '',
                        'value'      => $voteValue,
                    ]
                );
            } catch (\Exception $e) {
                // A concurrent insert may have already stored this choice.
                // Only accept that outcome when the requested value exists;
                // an older, opposite vote does not make a failed write succeed.
                $recorded = ReviewInteraction::votes()
                    ->forReview($reviewId)
                    ->where('user_id', $userId)
                    ->where( 'value', $voteValue )
                    ->exists();

                if (!$recorded) {
                    return $this->sendError([
                        'message' => __('Could not save your vote. Please try again.', 'fluent-cart-pro'),
                    ], 500);
                }
            }
        }

        // Return updated counts
        $counts = $this->getVoteCounts($reviewId);

        return $this->sendSuccess($counts);
    }

    private function getVoteCounts($reviewId)
    {
        $counts = ReviewInteraction::voteCountsFor($reviewId);

        // The public endpoint's response keys predate the model helper.
        return [
            'helpful_count'     => $counts['helpful'],
            'not_helpful_count' => $counts['not_helpful'],
            'user_vote' => (int) ReviewInteraction::votes()->forReview($reviewId)
                ->where('user_id', get_current_user_id())->value('value'),
        ];
    }

}
