<?php
/**
 * "Subscribe to topics" modal shell. List is populated client-side from the
 * blog-subscriptions/categories REST endpoint.
 *
 * @package BuddyBossPro
 *
 * @since 3.1.0
 */

defined( 'ABSPATH' ) || exit;
?>
<div class="bb-blog-subscribe-modal" id="bb-blog-subscribe-modal" role="dialog" aria-modal="true" aria-labelledby="bb-blog-subscribe-modal-title" hidden>
	<div class="bb-blog-subscribe-modal__overlay" data-bb-blog-modal-close></div>
	<div class="bb-blog-subscribe-modal__dialog" role="document">
		<div class="bb-blog-subscribe-modal__header">
			<h2 class="bb-blog-subscribe-modal__title" id="bb-blog-subscribe-modal-title"><?php esc_html_e( 'Subscribe to topics', 'buddyboss-pro' ); ?></h2>
			<button type="button" class="bb-blog-subscribe-modal__close" data-bb-blog-modal-close aria-label="<?php esc_attr_e( 'Close', 'buddyboss-pro' ); ?>">
				<i class="<?php echo esc_attr( bb_blog_pro_icon_class( 'bb-icons-rl-x', 'bb-icon-l bb-icon-times' ) ); ?>" aria-hidden="true"></i>
			</button>
		</div>
		<div class="bb-blog-subscribe-modal__note">
			<?php esc_html_e( "You'll receive notifications whenever there's a new post on the topics you've subscribed to.", 'buddyboss-pro' ); ?>
		</div>
		<div class="bb-blog-subscribe-modal__body" data-bb-blog-modal-body>
			<ul class="bb-blog-subscribe-modal__list" data-bb-blog-modal-list></ul>
			<div class="bb-blog-subscribe-modal__loading" data-bb-blog-modal-loading>
				<?php esc_html_e( 'Loading…', 'buddyboss-pro' ); ?>
			</div>
			<div class="bb-blog-subscribe-modal__empty" data-bb-blog-modal-empty hidden>
				<?php esc_html_e( 'No categories available.', 'buddyboss-pro' ); ?>
			</div>
			<div class="bb-blog-subscribe-modal__loading-more" data-bb-blog-modal-loading-more hidden>
				<span class="bb-blog-subscribe-modal__spinner" aria-hidden="true"></span>
				<span class="screen-reader-text"><?php esc_html_e( 'Loading more topics…', 'buddyboss-pro' ); ?></span>
			</div>
		</div>
	</div>
</div>
