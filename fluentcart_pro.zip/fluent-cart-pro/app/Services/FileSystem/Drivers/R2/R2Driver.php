<?php

namespace FluentCartPro\App\Services\FileSystem\Drivers\R2;

use FluentCart\App\Models\ProductDownload;
use FluentCart\App\Services\FileSystem\Drivers\BaseDriver;
use FluentCart\Framework\Support\Arr;
use FluentCartPro\App\Modules\StorageDrivers\R2\R2 as R2StorageDriver;
use FluentCartPro\App\Modules\StorageDrivers\R2\R2Settings;

class R2Driver extends BaseDriver
{
    protected string $accessKey;

    protected string $secretKey;

    protected string $accountId;

    protected string $bucket;

    protected string $region = 'auto';

    public function __construct(?string $dirPath = null, ?string $dirName = null)
    {
        parent::__construct($dirPath, $dirName);

        $settings = (new R2Settings())->get();

        $this->bucket = Arr::get($settings, 'bucket', '');
        $this->region = Arr::get($settings, 'region', 'auto');
        $this->secretKey = Arr::get($settings, 'secret_key', '');
        $this->accessKey = Arr::get($settings, 'access_key', '');
        $this->accountId = Arr::get($settings, 'account_id', '');
        $this->storageDriver = new R2StorageDriver();
    }

    public function buckets()
    {
        return R2BucketList::get($this->accountId, $this->secretKey, $this->accessKey);
    }

    public function createBucket($bucketName, $region)
    {
        return R2BucketCreator::create($this->accountId, $this->secretKey, $this->accessKey, $bucketName, $region);
    }

    public function uploadFile($localFilePath, $uploadToFilePath, $file, $params = [])
    {
        $response = R2FileUploader::upload(
            $this->accountId,
            $this->secretKey,
            $this->accessKey,
            Arr::get($params, 'bucket', $this->bucket),
            $localFilePath,
            $uploadToFilePath
        );

        if (is_wp_error($response)) {
            return $response;
        }

        return [
            'message' => __('File uploaded successfully', 'fluent-cart-pro'),
            'path'    => $response['path'],
            'file'    => [
                'driver' => 'r2',
                'size'   => Arr::get($file->toArray(), 'size_in_bytes'),
                'bucket' => Arr::get($params, 'bucket', $this->bucket),
                'region' => Arr::get($params, 'region', $this->region),
                'name'   => $response['path'],
            ],
        ];
    }

    public function listFiles(array $params = [])
    {
        return R2FileList::get(
            $this->accountId,
            $this->secretKey,
            $this->accessKey,
            Arr::get($params, 'activeBucket', $this->bucket),
            Arr::get($params, 'search', '')
        );
    }

    protected function generatePresignedDownloadUrl(string $filePath, $expirationMinutes = 15, $bucket = null, $fileName = null): string
    {
        if (!$this->accountId || !$this->accessKey || !$this->secretKey) {
            return '';
        }

        $bucket = $bucket ?: $this->bucket;
        if (!$fileName) {
            $fileName = basename($filePath);
        }

        $fileName = explode('_____fluent-cart_____', $fileName)[0];
        $fileName = explode('__fluent-cart__', $fileName)[0];

        $expiresInSeconds = ((int) $expirationMinutes ?: 15) * 60;
        $dateTime = gmdate('Ymd\THis\Z');
        $dateStamp = gmdate('Ymd');
        $region = 'auto';
        $credentialScope = $dateStamp . '/' . $region . '/s3/aws4_request';
        $canonicalUri = '/' . implode('/', array_map('rawurlencode', explode('/', ltrim($filePath, '/'))));
        $query = [
            'X-Amz-Algorithm'     => 'AWS4-HMAC-SHA256',
            'X-Amz-Credential'    => $this->accessKey . '/' . $credentialScope,
            'X-Amz-Date'          => $dateTime,
            'X-Amz-Expires'       => $expiresInSeconds,
            'X-Amz-SignedHeaders' => 'host',
        ];

        if ($fileName) {
            $query['response-content-disposition'] = 'attachment; filename="' . $fileName . '"';
        }

        ksort($query);

        $parts = [];
        foreach ($query as $key => $value) {
            $parts[] = rawurlencode($key) . '=' . rawurlencode($value);
        }

        $canonicalQuery = implode('&', $parts);
        $host = $bucket . '.' . $this->accountId . '.r2.cloudflarestorage.com';
        $canonicalHeaders = 'host:' . $host . "\n";
        $canonicalRequest = 'GET' . "\n" . $canonicalUri . "\n" . $canonicalQuery . "\n" . $canonicalHeaders . "\nhost\nUNSIGNED-PAYLOAD";
        $stringToSign = 'AWS4-HMAC-SHA256' . "\n" . $dateTime . "\n" . $credentialScope . "\n" . hash('sha256', $canonicalRequest);
        $kDate = hash_hmac('sha256', $dateStamp, 'AWS4' . $this->secretKey, true);
        $kRegion = hash_hmac('sha256', $region, $kDate, true);
        $kService = hash_hmac('sha256', 's3', $kRegion, true);
        $kSigning = hash_hmac('sha256', 'aws4_request', $kService, true);
        $signature = hash_hmac('sha256', $stringToSign, $kSigning);

        return 'https://' . $host . $canonicalUri . '?' . $canonicalQuery . '&X-Amz-Signature=' . $signature;
    }

    public function getSignedDownloadUrl(string $filePath, $bucket = null, $productDownload = null): string
    {
        $expirationMinutes = 7 * 24 * 60;
        apply_filters('fluent_cart/download_expiration_minutes', $expirationMinutes, [
            'file_path' => $filePath,
            'bucket'    => $bucket,
            'driver'    => 'r2',
        ]);

        $fileName = $productDownload instanceof ProductDownload ? $productDownload->file_name : null;

        return $this->generatePresignedDownloadUrl($filePath, $expirationMinutes, $bucket, $fileName);
    }

    public function downloadFile(string $filePath, $fileName = null, $bucket = null)
    {
        $expirationMinutes = 7 * 24 * 60;
        apply_filters('fluent_cart/download_expiration_minutes', $expirationMinutes, [
            'file_path' => $filePath,
            'bucket'    => $bucket,
            'driver'    => 'r2',
        ]);

        wp_redirect($this->generatePresignedDownloadUrl($filePath, $expirationMinutes, $bucket, $fileName));
        exit;
    }

    public function deleteFile($filePath, $bucket = null)
    {
        return R2FileDeleter::delete(
            $this->accountId,
            $this->secretKey,
            $this->accessKey,
            $bucket ?: $this->bucket,
            $filePath
        );
    }

    public function getFilePath(string $filePath)
    {
        return $this->retrieveFileForDownload($filePath);
    }

    protected function getDefaultDirPath()
    {
        return $this->bucket;
    }

    protected function retrieveFileForDownload(string $downloadableFilePath)
    {
        $url = $this->generatePresignedDownloadUrl($downloadableFilePath);
        $response = wp_remote_get($url);

        if (is_wp_error($response)) {
            return $response->get_error_message();
        }

        return wp_remote_retrieve_body($response);
    }
}
