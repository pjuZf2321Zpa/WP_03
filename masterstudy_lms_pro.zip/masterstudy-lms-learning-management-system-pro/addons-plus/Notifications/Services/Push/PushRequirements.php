<?php

namespace MasterStudy\Lms\Pro\AddonsPlus\Notifications\Services\Push;

use Minishlink\WebPush\Subscription;
use Minishlink\WebPush\VAPID;
use Minishlink\WebPush\WebPush;

final class PushRequirements {
	public static function is_met(): bool {
		return empty( self::missing() );
	}

	public static function missing(): array {
		$missing = array();

		foreach ( array( 'curl', 'json', 'mbstring', 'openssl' ) as $extension ) {
			if ( ! extension_loaded( $extension ) ) {
				$missing[] = "PHP extension {$extension}";
			}
		}

		$classes = array(
			WebPush::class      => 'WebPush library',
			Subscription::class => 'WebPush subscription class',
			VAPID::class        => 'WebPush VAPID class',
		);

		foreach ( $classes as $class => $label ) {
			if ( ! class_exists( $class ) ) {
				$missing[] = $label;
			}
		}

		return $missing;
	}

	public static function missing_message(): string {
		$missing = self::missing();

		if ( empty( $missing ) ) {
			return '';
		}

		return 'Missing push requirements: ' . implode( ', ', $missing ) . '.';
	}
}
