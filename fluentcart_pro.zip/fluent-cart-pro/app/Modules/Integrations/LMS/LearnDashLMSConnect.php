<?php

namespace FluentCartPro\App\Modules\Integrations\LMS;

use FluentCart\App\Modules\Integrations\BaseIntegrationManager;
use FluentCart\App\Services\AuthService;
use FluentCart\App\Vite;
use FluentCart\Framework\Support\Arr;

class LearnDashLMSConnect extends BaseIntegrationManager
{
    public $scopes = ['global', 'product'];

    public function __construct()
    {
        parent::__construct('LearnDash', 'learndash', 20);

        $this->description = __('Manage Course accesses with FluentCart + LearnDash', 'fluent-cart-pro');
        $this->logo = Vite::getAssetUrl('images/integrations/learndash.svg');

        if (defined('LEARNDASH_VERSION')) {
            add_filter('ld_course_access_expires_on', [$this, 'maybeInjectExpiry'], 10, 3);
            add_filter('sfwd_lms_has_access', [$this, 'maybeBlockAccess'], 10, 3);
        }
    }

    public function isConfigured()
    {
        return defined('LEARNDASH_VERSION');
    }

    public function getIntegrationDefaults($settings)
    {
        return [
            'enabled'                => 'yes',
            'name'                   => '',
            'course_ids'             => [],
            'group_ids'              => [],
            'event_trigger'          => [],
            'watch_on_access_revoke' => 'yes'
        ];
    }

    public function getSettingsFields($settings, $args = [])
    {
        $fields = [
            'name'                   => [
                'key'         => 'name',
                'label'       => __('Feed Title', 'fluent-cart-pro'),
                'required'    => true,
                'placeholder' => __('Name', 'fluent-cart-pro'),
                'component'   => 'text',
                'inline_tip'  => __('Name of this feed, it will be used to identify this feed in the list of feeds', 'fluent-cart-pro')
            ],
            'course_ids'             => [
                'key'            => 'course_ids',
                'label'          => __('Add to Courses', 'fluent-cart-pro'),
                'placeholder'    => __('Select Learndash Courses', 'fluent-cart-pro'),
                'inline_tip'     => __('Select the LearnDash Courses you would like to add.', 'fluent-cart-pro'),
                'component'      => 'rest_selector',
                'option_key'     => 'post_type',
                'sub_option_key' => 'sfwd-courses',
                'is_multiple'    => true,
                'required'       => false
            ],
            'group_ids'              => [
                'key'            => 'group_ids',
                'require_list'   => false,
                'label'          => __('Add to LearnDash Groups', 'fluent-cart-pro'),
                'placeholder'    => __('Select LearnDash Groups', 'fluent-cart-pro'),
                'is_multiple'    => true,
                'component'      => 'rest_selector',
                'option_key'     => 'post_type',
                'sub_option_key' => 'groups',
                'inline_tip'     => __('Select the groups you would like to add the customer to', 'fluent-cart-pro')
            ],
            'watch_on_access_revoke' => [
                'key'            => 'watch_on_access_revoke',
                'component'      => 'yes-no-checkbox',
                'checkbox_label' => __('Remove from selected Courses/Groups on Refund or Subscription Access Expiration ', 'fluent-cart-pro'),
                'inline_tip'     => __('If you enable this, on refund or subscription validity expiration, the selected groups and courses will be removed from the customer.', 'fluent-cart-pro')
            ]
        ];

        $fields = array_values($fields);

        $fields[] = $this->actionFields();

        return [
            'fields'              => $fields,
            'button_require_list' => false,
            'integration_title'   => __('LearnDash', 'fluent-cart-pro')
        ];
    }

    /*
     * For Handling Notifications broadcast
     */
    public function processAction($order, $eventData)
    {
        $feedConfig = Arr::get($eventData, 'feed', []);
        $trigger = Arr::get($eventData, 'trigger');
        // These triggers are always revoke — base class sets is_revoke_hook=no when watch_on_access_revoke=no
        // but the trigger is still in event_trigger, causing it to fall into the grant path.
        $revokeOnlyTriggers = ['subscription_expired_validity', 'order_fully_refunded', 'order_status_changed_to_canceled'];
        $isRevokedHook = Arr::get($eventData, 'is_revoke_hook') === 'yes' || in_array($trigger, $revokeOnlyTriggers);
        $customer = $order->customer;

        // check exits
        $courseIds = array_filter((array)Arr::get($feedConfig, 'course_ids', []), 'intval');
        $groupIds = array_filter((array)Arr::get($feedConfig, 'group_ids', []), 'intval');

        if (!$courseIds && !$groupIds) {
            return;
        }

        $userId = $customer->getWpUserId(true);

        if ($isRevokedHook) {
            if (!$userId) {
                return;
            }

            $subscriptionValidityExpired = $trigger === 'subscription_expired_validity';
            $shouldUnenrollOnRevokeEvent = Arr::get($feedConfig, 'watch_on_access_revoke') === 'yes';

            if ($subscriptionValidityExpired) {
                $sub = Arr::get($eventData, 'event_data.subscription');
                if ($sub && in_array($sub->status, ['active', 'trialing', 'completed'])) {
                    return;
                }
            }

            $blockedCourses = [];
            $blockedGroups = [];
            $removedCourses = [];
            $removedGroups = [];

            if ($courseIds) {
                // Refund/cancel: always unenroll (transaction reversed)
                // Subscription expiry: respect watch_on_access_revoke setting
                if ($shouldUnenrollOnRevokeEvent || !$subscriptionValidityExpired) {
                    $courses = learndash_user_get_enrolled_courses($userId);
                    $removedCourses = array_intersect($courseIds, $courses);
                    foreach ($removedCourses as $courseId) {
                        ld_update_course_access($userId, $courseId, true);
                        delete_user_meta($userId, "fluentcart_learndash_course_{$courseId}_expires");
                        delete_user_meta($userId, "fluentcart_learndash_course_{$courseId}_blocked");
                    }

                } else {
                     foreach ($courseIds as $courseId) {
                        if (get_user_meta($userId, "course_{$courseId}_access_from", true)) {
                            update_user_meta($userId, "fluentcart_learndash_course_{$courseId}_blocked", 1);
                            delete_user_meta($userId, "fluentcart_learndash_course_{$courseId}_expires");
                            $blockedCourses[] = $courseId;
                        }
                    }
                }
            }

            if ($groupIds) {
                // Refund/cancel: always unenroll (transaction reversed)
                // Subscription expiry: respect watch_on_access_revoke setting
                if ($shouldUnenrollOnRevokeEvent || !$subscriptionValidityExpired) {
                    $groups = learndash_get_users_group_ids($userId);
                    $removedGroups = array_intersect($groupIds, $groups);
                    foreach ($removedGroups as $groupId) {
                        ld_update_group_access($userId, $groupId, true);
                        delete_user_meta($userId, "fluentcart_learndash_group_{$groupId}_blocked");
                    }
                } else {
                    // Keep group membership — course-level block handles access denial.
                    $existingGroups = learndash_get_users_group_ids($userId);
                    foreach ($groupIds as $groupId) {
                        if (in_array($groupId, $existingGroups)) {
                            update_user_meta($userId, "fluentcart_learndash_group_{$groupId}_blocked", 1);
                            $blockedGroups[] = $groupId;
                        }
                    }
                }
            }

            if ($blockedCourses || $blockedGroups) {
                $blockedParts = [];
                if ($blockedCourses) {
                    $blockedParts[] = sprintf(__('courses: %s', 'fluent-cart-pro'), implode(', ', $blockedCourses));
                }
                if ($blockedGroups) {
                    $blockedParts[] = sprintf(__('groups: %s', 'fluent-cart-pro'), implode(', ', $blockedGroups));
                }
                $order->addLog(
                    __('Access Blocked on Subscription Expiry', 'fluent-cart-pro'),
                    sprintf(__('Access blocked (enrollment preserved) for %s', 'fluent-cart-pro'), implode(' and ', $blockedParts)),
                    'info',
                    'LearnDash Integration'
                );
            }

            if ($removedCourses || $removedGroups) {
                $revokeParts = [];
                if ($removedCourses) {
                    $revokeParts[] = sprintf(__('courses: %s', 'fluent-cart-pro'), implode(', ', $removedCourses));
                }
                if ($removedGroups) {
                    $revokeParts[] = sprintf(__('groups: %s', 'fluent-cart-pro'), implode(', ', $removedGroups));
                }

                $order->addLog(
                    __('Accesses Removed from the connected student on order revoke', 'fluent-cart-pro'),
                    sprintf(__('Removed from %s', 'fluent-cart-pro'), implode(' and ', $revokeParts)),
                    'info',
                    'LearnDash Integration'
                );
            }

            return;
        }

        // An email match is not proof of ownership: serve that account without linking the customer.
        // Revoke above uses the linked account only, so it never acts on an email match.
        if (!$userId && $existingUser = get_user_by('email', $customer->email)) {
            $userId = $existingUser->ID;
        }

        $grantTrigger = Arr::get($eventData, 'trigger');
        $isRenewal = $grantTrigger == 'subscription_renewed';

        // Renewal: student is already enrolled — only update expiry and clear block flags.
        if ($isRenewal) {
            if (!$userId) {
                return;
            }
            $expiryTimestamp = $this->getCourseExpiryTimestamp($order, $eventData);
            $subscription = Arr::get($eventData, 'event_data.subscription');
            $isCompleted = $subscription && $subscription->bill_times > 0 && $subscription->bill_count >= $subscription->bill_times;

            foreach ($courseIds as $courseId) {
                delete_user_meta($userId, "fluentcart_learndash_course_{$courseId}_blocked");
                delete_user_meta($userId, "learndash_course_expired_{$courseId}"); // Clear access_from to prevent LearnDash treating this as an expired access that needs to be auto-removed
                if ($isCompleted) {
                    delete_user_meta($userId, "fluentcart_learndash_course_{$courseId}_expires");
                } else {
                    $filteredExpiry = apply_filters('fluent_cart/learndash/before_set_user_course_expiry', $expiryTimestamp, [
                        'user_id'      => $userId,
                        'course_id'    => $courseId,
                        'order'        => $order,
                        'subscription' => $subscription,
                    ]);
                    update_user_meta($userId, "fluentcart_learndash_course_{$courseId}_expires", $filteredExpiry);
                }
            }

            foreach ($groupIds as $groupId) {
                delete_user_meta($userId, "fluentcart_learndash_group_{$groupId}_blocked");
            }

            $order->addLog(
                __('LearnDash Subscription Renewed', 'fluent-cart-pro'),
                __('Expiry extended silently — no enrollment changes made.', 'fluent-cart-pro'),
                'info',
                'LearnDash Integration'
            );
            return;
        }

        if (!$userId) {
            $userId = AuthService::createUserFromCustomer($customer);
            if (is_wp_error($userId)) {
                $order->addLog(
                    __('User creation failed from LearnDash Integration', 'fluent-cart-pro'),
                    $userId->get_error_message(),
                    'error',
                    'LearnDash Integration'
                );
                return;
            }
        }

        if (!$userId) {
            return false;
        }

        $expiryTimestamp = $this->getCourseExpiryTimestamp($order, $eventData);

        $subscription = Arr::get($eventData, 'event_data.subscription');
        $isCompleted = $subscription && $subscription->status === 'completed';

        if($courseIds) {
            $existingCourses = learndash_user_get_enrolled_courses($userId);
            $newCourses = array_diff($courseIds, $existingCourses);
            foreach ($newCourses as $courseId) {
                ld_update_course_access($userId, $courseId);
            }
            foreach ($courseIds as $courseId) {
                delete_user_meta($userId, "fluentcart_learndash_course_{$courseId}_blocked");
            }

            if ($expiryTimestamp && !$isCompleted) {
                foreach ($courseIds as $courseId) {
                    $filteredExpiry = apply_filters('fluent_cart/learndash/before_set_user_course_expiry', $expiryTimestamp, [
                        'user_id'      => $userId,
                        'course_id'    => $courseId,
                        'order'        => $order,
                        'subscription' => $subscription,
                    ]);
                    update_user_meta($userId, "fluentcart_learndash_course_{$courseId}_expires", $filteredExpiry);
                }
            } elseif ($isCompleted || !$expiryTimestamp) {
                foreach ($courseIds as $courseId) {
                    delete_user_meta($userId, "fluentcart_learndash_course_{$courseId}_expires");
                }
            }
        }

        if($groupIds) {
            $existingGroups = learndash_get_users_group_ids($userId);
            $newGroups = array_diff($groupIds, $existingGroups);
            foreach ($newGroups as $groupId) {
                ld_update_group_access($userId, $groupId);
            }
            // Clear blocked meta for all group IDs — covers the case where the student
            foreach ($groupIds as $groupId) {
                delete_user_meta($userId, "fluentcart_learndash_group_{$groupId}_blocked");
            }
        }

        $logParts = [];
        if ($courseIds) {
            $logParts[] = sprintf(__('courses: %s', 'fluent-cart-pro'), implode(', ', $courseIds));
        }
        if ($groupIds) {
            $logParts[] = sprintf(__('groups: %s', 'fluent-cart-pro'), implode(', ', $groupIds));
        }

        $order->addLog(
            __('LearnDash Integration Success', 'fluent-cart-pro'),
            sprintf(__('User has been added to %s', 'fluent-cart-pro'), implode(' and ', $logParts)),
            'info',
            'LearnDash Integration'
        );
    }

    public function maybeBlockAccess($hasAccess, $postId, $userId)
    {
        if (!$hasAccess || !$userId) {
            return $hasAccess;
        }
        $courseId = learndash_get_course_id($postId);
        if (!$courseId) {
            return $hasAccess;
        }

        // check if the user is enrolled , if not return $hasAccess as is to avoid unnecessary meta checks
        $enrolledCourses = learndash_user_get_enrolled_courses($userId, true);

        if (!in_array($courseId, $enrolledCourses)) {
            return $hasAccess;
        }
       
        if (get_user_meta($userId, "fluentcart_learndash_course_{$courseId}_blocked", true)) {
            return false;
        }
        return $hasAccess;
    }

    public function maybeInjectExpiry($expiresOn, $courseId, $userId)
    {
        $fluentExpiry = (int) get_user_meta($userId, "fluentcart_learndash_course_{$courseId}_expires", true);
        if (!$fluentExpiry) {
            return $expiresOn;
        }
        if ($fluentExpiry > time()) {
            return $fluentExpiry;
        }
        return 0;
    }

    private function getCourseExpiryTimestamp($order, array $eventData = []): ?int
    {
        $subscription = Arr::get($eventData, 'event_data.subscription');

        if (!$subscription) {
            $subscriptions = $order->subscriptions;
            if (!$subscriptions || $subscriptions->isEmpty()) {
                $parentOrderId = $order->parent_id ?: $order->id;
                $parentOrder = $order->find($parentOrderId);
                $subscriptions = $parentOrder ? $parentOrder->subscriptions : null;
            }
            $subscription = ($subscriptions && $subscriptions->isNotEmpty()) ? $subscriptions->first() : null;
        }
        if ($subscription) {
            $nextBilling = $subscription->next_billing_date;

            if ($nextBilling && $nextBilling !== '0000-00-00 00:00:00') {
                return strtotime($nextBilling . ' UTC');
            }
        }

        $licenses = $order->getLicenses([]);
        if ($licenses && $licenses->isNotEmpty()) {
            $expDate = $licenses->first()->expiration_date;
            if ($expDate && $expDate !== '0000-00-00 00:00:00') {
                return strtotime($expDate . ' UTC');
            }
        }

        return null;
    }

}
