<?php

namespace CustomFacebookFeed\Abilities\Abilities;

use CustomFacebookFeed\Abilities\CFF_Ability_Response;
use CustomFacebookFeed\Abilities\Services\CFF_Feed_Settings_Service;
use CustomFacebookFeed\Abilities\Services\CFF_Settings_Schema;

if (!defined('ABSPATH')) {
	exit;
}

/**
 * facebook-feed/update-feed-settings
 *
 * Gated by CFF_Write_Gate, then capability, then a per-key license-tier
 * check: tier-locked keys are not written and come back in `ignored` as
 * `feature_unavailable`.
 *
 * @since 4.13
 */
class CFF_Update_Feed_Settings extends CFF_Ability
{
	public function slug()
	{
		return 'update-feed-settings';
	}

	public function args()
	{
		$writable = CFF_Settings_Schema::writable(CFF_Settings_Schema::feed_settings());
		$props    = array(
			'feed_id'  => array(
				'type'        => 'integer',
				'minimum'     => 1,
				'description' => 'Feed id from list-feeds.',
			),
			'settings' => array(
				'type'                 => 'object',
				'properties'           => CFF_Settings_Schema::to_json_properties($writable),
				'minProperties'        => 1,
				'additionalProperties' => false,
				'description'          => 'Settings to change. Only the keys you pass are changed; '
					. 'other stored values are re-saved as-is.',
			),
		);

		return array(
			'label'               => __('Update a Custom Facebook Feed', 'custom-facebook-feed'),
			'description'         => __('Changes one or more settings of a feed (layout, columns, post count, header, likebox, buttons, colours). Only the keys you pass are changed. Requires AI write access to be enabled in Facebook Feed → Settings → General. Returns updated and ignored keys.', 'custom-facebook-feed'), // phpcs:ignore Generic.Files.LineLength.TooLong -- single literal for make-pot
			'input_schema'        => array(
				'type'                 => 'object',
				'properties'           => $props,
				'required'             => array('feed_id', 'settings'),
				'additionalProperties' => false,
			),
			'output_schema'       => $this->write_output_schema(array('feed_id' => array('type' => 'integer'))),
			'execute_callback'    => array($this, 'execute'),
			'permission_callback' => array($this, 'can_write'),
			'meta'                => $this->write_meta(false, true),
		);
	}

	public function execute($input = null)
	{
		$input   = $this->normalize_input($input);
		$feed_id = isset($input['feed_id']) ? (int) $input['feed_id'] : 0;
		if ($feed_id <= 0) {
			return CFF_Ability_Response::invalid_feed_id();
		}
		$settings = isset($input['settings']) ? $this->normalize_input($input['settings']) : array();

		$service = new CFF_Feed_Settings_Service();
		$result  = $service->update_feed($feed_id, $settings, array($this, 'is_feature_available'));

		return $result === null ? CFF_Ability_Response::feed_not_found($feed_id) : $result;
	}

	/**
	 * Same gate the Feed Builder applies: tier feature present AND license not lapsed.
	 *
	 * @param string $feature
	 * @return bool
	 */
	public function is_feature_available($feature)
	{
		return self::tier_check($feature);
	}

	/**
	 * Same gate the Feed Builder applies, reusable by other abilities.
	 *
	 * @param string $feature
	 * @return bool
	 */
	public static function tier_check($feature)
	{
		if (!class_exists('\CustomFacebookFeed\CFF_License_Tier')) {
			return true; // Free build: no tier concept.
		}

		// CFF has no `cff_license_tier` property on the plugin singleton — its own
		// idiom is a locally instantiated CFF_License_Tier (see
		// CFF_Feed_Saver::__construct(), CFF_Feed_Builder, CFF_Customize_Tab, and
		// several others). It's an option-read-only class, cheap to construct.
		$tier = new \CustomFacebookFeed\CFF_License_Tier();

		$disabled = false;
		if (function_exists('cff_main_pro')) {
			$builder = cff_main_pro();
			$disabled = !empty($builder->cff_license_handler) && !empty($builder->cff_license_handler->should_disable_pro_features);
		}

		// Unlicensed/disabled → unavailable, never fatal.
		return !$disabled && $tier->is_feature_available($feature);
	}
}
