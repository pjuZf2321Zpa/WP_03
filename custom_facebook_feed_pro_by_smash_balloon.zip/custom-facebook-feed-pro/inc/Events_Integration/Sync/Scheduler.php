<?php
/**
 * Cron scheduling for the events sync (core recurrences only).
 *
 * @package CustomFacebookFeed\Events_Integration
 * @since 4.11
 */

namespace CustomFacebookFeed\Events_Integration\Sync;

use CustomFacebookFeed\Events_Integration\Config;
use CustomFacebookFeed\Events_Integration\EventsIntegration;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Scheduler {

	/**
	 * Keep the sync cron in step with the enabled state, interval and
	 * target plugin availability. Runs on every init, so deactivating the
	 * calendar plugin stops the cron and reactivating it resumes it.
	 */
	public function maybe_schedule() {
		if ( ! Config::is_enabled() || ! $this->has_active_target() ) {
			$this->unschedule();
			return;
		}

		$interval  = Config::cron_interval();
		$scheduled = wp_get_schedule( Config::CRON_HOOK );

		if ( $scheduled === $interval ) {
			return;
		}

		$this->unschedule();
		wp_schedule_event( time() + MINUTE_IN_SECONDS, $interval, Config::CRON_HOOK );
	}

	/**
	 * Whether at least one enabled target's calendar plugin is active.
	 *
	 * @return bool
	 */
	private function has_active_target() {
		$adapters = EventsIntegration::adapters();
		foreach ( Config::enabled_targets() as $target_id ) {
			if ( isset( $adapters[ $target_id ] ) && $adapters[ $target_id ]->is_available() ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Reschedule after a settings change.
	 */
	public function reschedule() {
		wp_clear_scheduled_hook( Config::CRON_HOOK );
		$this->maybe_schedule();
	}

	/**
	 * Clear the sync cron and pending batch continuations (batch events
	 * carry cursor args, so wp_unschedule_hook is required).
	 */
	public function unschedule() {
		wp_clear_scheduled_hook( Config::CRON_HOOK );
		wp_unschedule_hook( Config::BATCH_HOOK );
	}

	/**
	 * Human-readable next run time for the settings UI.
	 *
	 * @return string
	 */
	public function next_run() {
		$timestamp = wp_next_scheduled( Config::CRON_HOOK );
		if ( ! $timestamp ) {
			return __( 'Not scheduled', 'custom-facebook-feed' );
		}

		return date_i18n( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), $timestamp + ( get_option( 'gmt_offset' ) * HOUR_IN_SECONDS ) );
	}
}
