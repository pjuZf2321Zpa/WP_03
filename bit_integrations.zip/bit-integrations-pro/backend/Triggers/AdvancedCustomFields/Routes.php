<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Core\Util\Route;
use BitApps\IntegrationsPro\Triggers\AdvancedCustomFields\AdvancedCustomFieldsController;

Route::get('acf/get', [AdvancedCustomFieldsController::class, 'getAllTasks']);
