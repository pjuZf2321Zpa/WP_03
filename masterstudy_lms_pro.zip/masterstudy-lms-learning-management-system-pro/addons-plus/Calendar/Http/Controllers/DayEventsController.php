<?php

namespace MasterStudy\Lms\Pro\AddonsPlus\Calendar\Http\Controllers;

use DateTimeImmutable;
use WP_REST_Request;
use WP_REST_Response;

final class DayEventsController extends Controller {
	public function __invoke( WP_REST_Request $request ): WP_REST_Response {
		$validated_data = $this->validate(
			$request,
			array_merge(
				array(
					'date' => 'required|calendar_date',
				),
				$this->pagination_rules( 30 ),
				$this->event_type_rules()
			)
		);

		if ( $validated_data instanceof WP_REST_Response ) {
			return $validated_data;
		}

		$date = $this->get_date( $validated_data );

		if ( ! $date instanceof DateTimeImmutable ) {
			return $date;
		}

		return new WP_REST_Response(
			( new \MasterStudy\Lms\Pro\AddonsPlus\Calendar\Http\Serializers\PaginatedEventsSerializer() )->toArray(
				$this->provider()->get_day_events(
					$date,
					$this->get_page( $validated_data ),
					$this->get_per_page( $validated_data, 10, 30 ),
					$this->get_event_type( $validated_data )
				)
			)
		);
	}
}
