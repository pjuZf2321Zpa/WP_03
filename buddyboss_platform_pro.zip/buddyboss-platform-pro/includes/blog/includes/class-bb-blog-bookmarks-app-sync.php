<?php
/**
 * Two-way bookmark sync with the BuddyBoss App plugin.
 *
 * EVERY line of App coupling lives in this file. Platform's bookmark engine is
 * App-unaware, and the rest of the blog module is too. Only blog (`post`)
 * bookmarks are synced — the App has no concept of any other bookmark type.
 *
 * @package BuddyBossPro
 *
 * @since 3.1.0
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

/**
 * Blog bookmark <-> BuddyBoss App sync.
 *
 * @since 3.1.0
 */
class BB_Blog_Bookmarks_App_Sync {

	/**
	 * Option flag: the post-(re)activation catch-up reconcile has already run for
	 * this active period. Set after the catch-up in maybe_reconcile_after_activation()
	 * and cleared when Pro is deactivated (see bb-blog-loader.php), so the merge
	 * runs once each time Pro becomes active — never on a schedule, per reconcile()'s
	 * "not on a schedule" contract.
	 *
	 * @since 3.1.0
	 *
	 * @var string
	 */
	const RECONCILE_FLAG_OPTION = 'bb_blog_pro_bookmarks_reconciled';

	/**
	 * WP-Cron hook that runs the one-shot post-activation reconcile off the
	 * front-end request path.
	 *
	 * @since 3.1.0
	 */
	const RECONCILE_CRON_HOOK = 'bb_blog_pro_reconcile_bookmarks';

	/**
	 * Class instance.
	 *
	 * @since 3.1.0
	 *
	 * @var BB_Blog_Bookmarks_App_Sync|null
	 */
	public static $instance = null;

	/**
	 * True while we are mirroring a change INTO the App store, so the App's
	 * own lifecycle hooks do not bounce it straight back at us.
	 *
	 * @since 3.1.0
	 *
	 * @var bool
	 */
	protected $data_syncing = false;

	/**
	 * True while an enable-setting value is being mirrored between the web
	 * option and the App setting, so the two listeners cannot ping-pong.
	 *
	 * @since 3.1.0
	 *
	 * @var bool
	 */
	protected $setting_syncing = false;

	/**
	 * App bookmark rows captured before deletion, keyed by row ID.
	 *
	 * The App's delete action fires AFTER the row is gone, so the object has to
	 * be grabbed on the way past.
	 *
	 * @since 3.1.0
	 *
	 * @var array
	 */
	protected $app_bookmark_cache = array();

	/**
	 * Get the instance.
	 *
	 * @since 3.1.0
	 *
	 * @return BB_Blog_Bookmarks_App_Sync
	 */
	public static function instance() {
		if ( is_null( self::$instance ) ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Constructor.
	 *
	 * @since 3.1.0
	 */
	public function __construct() {
		$this->setup_actions();
	}

	/**
	 * Whether the App plugin's bookmark API is present.
	 *
	 * @since 3.1.0
	 *
	 * @return bool
	 */
	public function has_app() {
		return function_exists( 'bbapp_add_bookmark' )
			&& function_exists( 'bbapp_delete_bookmark' )
			&& function_exists( 'bbapp_get_user_bookmarks' )
			&& function_exists( 'bbapp' );
	}

	/**
	 * Register hooks.
	 *
	 * The setting sync is ALWAYS on — a site with web bookmarking disabled must
	 * still be able to have it switched on from the app side. The data plane
	 * only runs when the App is actually present AND Platform's bookmark
	 * engine is available — Pro's only hard dependency is Platform 1.3.5+, so
	 * a site can run a newer Pro against an older Platform (no `BB_Bookmarks`
	 * class, no `bb_bookmark_*()` functions). Without this second check, the
	 * App -> Web handlers below call those functions directly and fatal on the
	 * first app-side bookmark create/delete.
	 *
	 * @since 3.1.0
	 *
	 * @return void
	 */
	protected function setup_actions() {
		add_action( 'update_option_bb_blog_enable_bookmarking', array( $this, 'on_web_setting_changed' ), 10, 2 );
		add_action( 'add_option_bb_blog_enable_bookmarking', array( $this, 'on_web_setting_added' ), 10, 2 );
		add_action( 'update_option_bbapp_settings', array( $this, 'on_app_setting_changed' ), 10, 2 );

		if ( ! $this->has_app() || ! bb_blog_pro_has_bookmark_engine() ) {
			return;
		}

		// Web -> App.
		add_action( 'bb_bookmark_added', array( $this, 'mirror_add_to_app' ), 10, 3 );
		add_action( 'bb_bookmark_removed', array( $this, 'mirror_remove_to_app' ), 10, 3 );

		// App -> Web.
		add_filter( 'bbapp_bookmarks_get_bookmark', array( $this, 'capture_app_bookmark' ), 10, 1 );
		add_action( 'bbapp_create_bookmark', array( $this, 'mirror_app_create' ), 10, 2 );
		add_action( 'bbapp_delete_bookmark', array( $this, 'mirror_app_delete' ), 10, 1 );

		// One-time catch-up after Pro (re)activates: merge any bookmarks the App
		// recorded while Pro was inactive. Without this, reconcile() only runs on
		// the web-enable transition, so a site with bookmarking already on never
		// picks up app-side bookmarks until the setting is re-saved.
		add_action( 'bp_init', array( $this, 'maybe_reconcile_after_activation' ), 20 );

		// The reconcile itself runs off the request path, on WP-Cron.
		add_action( self::RECONCILE_CRON_HOOK, array( $this, 'reconcile' ) );
	}

	/**
	 * Reset the catch-up flag when Pro is deactivated, so the next activation
	 * reruns the reconcile. Static because it is a deactivation-hook callback
	 * (registered in bb-blog-loader.php) that must resolve without an instance.
	 *
	 * @since 3.1.0
	 *
	 * @return void
	 */
	public static function on_pro_deactivated() {
		delete_option( self::RECONCILE_FLAG_OPTION );
	}

	/**
	 * Run the post-(re)activation catch-up reconcile exactly once.
	 *
	 * The reconcile() call is additive and idempotent but must not run on a schedule (it
	 * would resurrect app-deleted bookmarks). The flag — set here, cleared on Pro
	 * deactivation — bounds it to one run per active period: enough to absorb
	 * bookmarks the App recorded while Pro was off, without repeating on every load.
	 *
	 * @since 3.1.0
	 *
	 * @return void
	 */
	public function maybe_reconcile_after_activation() {
		// Need both stores to merge them. If the App or Platform's bookmark
		// engine is not ready yet, leave the flag UNclaimed so the catch-up
		// still runs on a later load once they are.
		if ( ! $this->has_app() || ! bb_blog_pro_has_bookmark_engine() ) {
			return;
		}

		// Claim the one-shot flag atomically. add_option() returns false if the
		// row already exists, so concurrent front-end requests can't both pass
		// this guard — replacing the previous non-atomic get-then-update. The
		// flag is stamped either way (bookmarking on or off) so this never
		// re-runs each load; a disabled site converges through the enable
		// transition (on_web_setting_changed()) instead.
		if ( ! add_option( self::RECONCILE_FLAG_OPTION, 1, '', 'no' ) ) {
			return;
		}

		// Only merge into the web store while web bookmarking is enabled, and do
		// it OFF the request path: schedule the (heavy, row-by-row) reconcile on
		// WP-Cron instead of running it inline on this front-end bp_init request.
		if ( ! empty( bp_get_option( 'bb_blog_enable_bookmarking', 0 ) ) && ! wp_next_scheduled( self::RECONCILE_CRON_HOOK ) ) {
			wp_schedule_single_event( time(), self::RECONCILE_CRON_HOOK );
		}
	}

	// ---------------------------------------------------------------------
	// Web -> App.
	// ---------------------------------------------------------------------

	/**
	 * Mirror a web bookmark into the App store.
	 *
	 * @since 3.1.0
	 *
	 * @param string $type    Bookmark type.
	 * @param int    $item_id Post ID.
	 * @param int    $user_id User ID.
	 *
	 * @return void
	 */
	public function mirror_add_to_app( $type, $item_id, $user_id ) {
		if ( $this->data_syncing || BB_BLOG_PRO_BOOKMARK_TYPE !== $type || ! $this->has_app() ) {
			return;
		}

		$this->data_syncing = true;

		try {
			// "Already exists" is not an error here — it means both stores agree.
			bbapp_add_bookmark(
				array(
					'type'    => BB_BLOG_PRO_BOOKMARK_TYPE,
					'user_id' => (int) $user_id,
					'item_id' => (int) $item_id,
					'status'  => 1,
				)
			);
		} finally {
			$this->data_syncing = false;
		}
	}

	/**
	 * Mirror a web un-bookmark into the App store.
	 *
	 * @since 3.1.0
	 *
	 * @param string $type    Bookmark type.
	 * @param int    $item_id Post ID.
	 * @param int    $user_id User ID.
	 *
	 * @return void
	 */
	public function mirror_remove_to_app( $type, $item_id, $user_id ) {
		if ( $this->data_syncing || BB_BLOG_PRO_BOOKMARK_TYPE !== $type || ! $this->has_app() ) {
			return;
		}

		$this->data_syncing = true;

		try {
			foreach ( $this->get_app_bookmark_ids( (int) $item_id, (int) $user_id ) as $app_id ) {
				bbapp_delete_bookmark( $app_id );
			}
		} finally {
			$this->data_syncing = false;
		}
	}

	/**
	 * App row IDs for a post + user.
	 *
	 * Deliberately passes `'cache' => false`: the App's internal Bookmarks::get()
	 * SQL cache can otherwise return a stale (empty) result immediately after our
	 * own write, silently skipping the delete. The outer $force_cache argument is
	 * NOT sufficient — the inner arg is what actually bypasses it.
	 *
	 * Deliberately does NOT filter on `'status' => 1` — and deliberately passes
	 * `'status' => null` rather than just omitting the key. The App has a third
	 * write path we do not listen to (`transition_post_status` -> Bookmarks::
	 * update_status()) that flips a row to `status = 0` to "hide" it rather than
	 * deleting it — that is the App's deliberate display policy and we do not
	 * mirror it (see the class docblock / reconcile()). Omitting the key is NOT
	 * enough to see hidden rows: `Bookmarks::get()` itself defaults `status` to
	 * `1` when the key is absent, so a plain omission would still silently filter
	 * to `status = 1`. Only an explicit `null` clears its `if ( null !== $r['status'] )`
	 * guard and drops the WHERE clause entirely. Without this, a web-side removal
	 * would find no App row for a hidden bookmark and leave it there; the App
	 * later flips it back to `status = 1` on republish — resurrecting a bookmark
	 * the user explicitly deleted on the web. A web removal must always win, so it
	 * deletes the App's row regardless of its status.
	 *
	 * @since 3.1.0
	 *
	 * @param int $post_id Post ID.
	 * @param int $user_id User ID.
	 *
	 * @return int[]
	 */
	protected function get_app_bookmark_ids( $post_id, $user_id ) {
		if ( empty( $post_id ) || empty( $user_id ) || ! $this->has_app() ) {
			return array();
		}

		$result = bbapp_get_user_bookmarks(
			array(
				'type'    => BB_BLOG_PRO_BOOKMARK_TYPE,
				'user_id' => $user_id,
				'item_id' => $post_id,
				'status'  => null,
				'fields'  => 'id',
				'cache'   => false,
			),
			true
		);

		$ids = ! empty( $result['bookmarks'] ) ? $result['bookmarks'] : array();

		return array_values( array_unique( array_map( 'absint', (array) $ids ) ) );
	}

	// ---------------------------------------------------------------------
	// App -> Web.
	// ---------------------------------------------------------------------

	/**
	 * Cache an App bookmark object before it is deleted.
	 *
	 * @since 3.1.0
	 *
	 * @param object $bookmark App bookmark object.
	 *
	 * @return object The bookmark, unmodified.
	 */
	public function capture_app_bookmark( $bookmark ) {
		if ( ! empty( $bookmark->id ) ) {
			$this->app_bookmark_cache[ (int) $bookmark->id ] = $bookmark;
		}

		return $bookmark;
	}

	/**
	 * Mirror an App-side create into our store.
	 *
	 * The App's `bbapp_add_bookmark()` is an upsert — it UPDATES an existing row
	 * when the status differs rather than inserting. So this action also fires
	 * for status flips, and a status other than 1 means the app REMOVED the
	 * bookmark.
	 *
	 * @since 3.1.0
	 *
	 * @param array             $args    Args the App was called with.
	 * @param int|bool|WP_Error $created Row ID on success.
	 *
	 * @return void
	 */
	public function mirror_app_create( $args, $created ) {
		// Public and hookable, so re-check even though setup_actions() already
		// gates the add_action() call on the same condition.
		if ( ! bb_blog_pro_has_bookmark_engine() ) {
			return;
		}

		if ( $this->data_syncing || is_wp_error( $created ) || false === $created ) {
			return;
		}

		if ( empty( $args['type'] ) || BB_BLOG_PRO_BOOKMARK_TYPE !== $args['type'] ) {
			return;
		}

		if ( ! empty( $args['blog_id'] ) && get_current_blog_id() !== (int) $args['blog_id'] ) {
			return;
		}

		if ( empty( $args['item_id'] ) || empty( $args['user_id'] ) ) {
			return;
		}

		$this->data_syncing = true;

		try {
			if ( isset( $args['status'] ) && 1 !== (int) $args['status'] ) {
				$this->delete_our_row( (int) $args['item_id'], (int) $args['user_id'] );
			} else {
				bb_bookmark_add(
					array(
						'type'          => BB_BLOG_PRO_BOOKMARK_TYPE,
						'item_id'       => (int) $args['item_id'],
						'user_id'       => (int) $args['user_id'],
						'date_recorded' => ! empty( $args['date_recorded'] ) ? $args['date_recorded'] : current_time( 'mysql' ),
					)
				);
			}
		} finally {
			$this->data_syncing = false;
		}
	}

	/**
	 * Mirror an App-side delete into our store.
	 *
	 * @since 3.1.0
	 *
	 * @param int $bookmark_id Deleted App row ID.
	 *
	 * @return void
	 */
	public function mirror_app_delete( $bookmark_id ) {
		// Public and hookable, so re-check even though setup_actions() already
		// gates the add_action() call on the same condition.
		if ( ! bb_blog_pro_has_bookmark_engine() ) {
			return;
		}

		$bookmark_id = (int) $bookmark_id;
		$bookmark    = isset( $this->app_bookmark_cache[ $bookmark_id ] ) ? $this->app_bookmark_cache[ $bookmark_id ] : null;

		// Drop the cache entry whatever happens next.
		unset( $this->app_bookmark_cache[ $bookmark_id ] );

		if ( $this->data_syncing || empty( $bookmark ) ) {
			return;
		}

		if ( empty( $bookmark->type ) || BB_BLOG_PRO_BOOKMARK_TYPE !== $bookmark->type ) {
			return;
		}

		if ( ! empty( $bookmark->blog_id ) && get_current_blog_id() !== (int) $bookmark->blog_id ) {
			return;
		}

		if ( empty( $bookmark->item_id ) || empty( $bookmark->user_id ) ) {
			return;
		}

		$this->data_syncing = true;

		try {
			$this->delete_our_row( (int) $bookmark->item_id, (int) $bookmark->user_id );
		} finally {
			$this->data_syncing = false;
		}
	}

	/**
	 * Delete our bookmark row for a post + user, if it exists.
	 *
	 * @since 3.1.0
	 *
	 * @param int $post_id Post ID.
	 * @param int $user_id User ID.
	 *
	 * @return void
	 */
	protected function delete_our_row( $post_id, $user_id ) {
		$existing = bb_bookmark_get_by_item( BB_BLOG_PRO_BOOKMARK_TYPE, $post_id, $user_id );

		if ( ! empty( $existing->id ) ) {
			bb_bookmark_delete( (int) $existing->id );
		}
	}

	// ---------------------------------------------------------------------
	// Setting sync.
	// ---------------------------------------------------------------------

	/**
	 * The web bookmarking toggle changed.
	 *
	 * Turning it ON reconciles the two stores first (so a user who has been
	 * bookmarking in the app finds their bookmarks waiting on the web), then
	 * turns the App setting on to match.
	 *
	 * @since 3.1.0
	 *
	 * @param mixed $old_value Previous value.
	 * @param mixed $value     New value.
	 *
	 * @return void
	 */
	public function on_web_setting_changed( $old_value, $value ) {
		$was_on = ! empty( $old_value );
		$is_on  = ! empty( $value );

		if ( $is_on && ! $was_on ) {
			$this->reconcile();
		}

		$this->push_setting_to_app( $is_on );
	}

	/**
	 * The web bookmarking toggle was created for the first time.
	 *
	 * @since 3.1.0
	 *
	 * @param string $option Option name.
	 * @param mixed  $value  Option value.
	 *
	 * @return void
	 */
	public function on_web_setting_added( $option, $value ) {
		if ( ! empty( $value ) ) {
			$this->reconcile();
		}

		$this->push_setting_to_app( ! empty( $value ) );
	}

	/**
	 * The App's `post_bookmark_enable` setting changed — mirror it to the web.
	 *
	 * @since 3.1.0
	 *
	 * @param mixed $old_value Previous bbapp_settings.
	 * @param mixed $value     New bbapp_settings.
	 *
	 * @return void
	 */
	public function on_app_setting_changed( $old_value, $value ) {
		if ( $this->setting_syncing ) {
			return;
		}

		$was_on = is_array( $old_value ) && ! empty( $old_value['post_bookmark_enable'] );
		$is_on  = is_array( $value ) && ! empty( $value['post_bookmark_enable'] );

		if ( $was_on === $is_on ) {
			return;
		}

		if ( (bool) bp_get_option( 'bb_blog_enable_bookmarking', 0 ) === $is_on ) {
			return;
		}

		$this->setting_syncing = true;

		try {
			bp_update_option( 'bb_blog_enable_bookmarking', $is_on ? 1 : 0 );
		} finally {
			$this->setting_syncing = false;
		}
	}

	/**
	 * Write the enable state into the App's settings.
	 *
	 * @since 3.1.0
	 *
	 * @param bool $enabled Whether bookmarking is on.
	 *
	 * @return void
	 */
	public function push_setting_to_app( $enabled ) {
		if ( ! $this->has_app() || $this->setting_syncing ) {
			return;
		}

		$settings = get_option( 'bbapp_settings', array() );

		if ( ! is_array( $settings ) ) {
			$settings = array();
		}

		if ( ! empty( $settings['post_bookmark_enable'] ) === (bool) $enabled ) {
			return;
		}

		$settings['post_bookmark_enable'] = (bool) $enabled;

		$this->setting_syncing = true;

		try {
			update_option( 'bbapp_settings', $settings );
		} finally {
			$this->setting_syncing = false;
		}
	}

	// ---------------------------------------------------------------------
	// Reconcile.
	// ---------------------------------------------------------------------

	/**
	 * Converge the two stores with a two-way union merge.
	 *
	 * IDEMPOTENT and safe to re-run — the UNIQUE key on our table makes a repeat
	 * insert a no-op. This is both the "enable web after already using the app"
	 * path and the drift-repair path.
	 *
	 * MUST NOT be run on a schedule. The merge is ADDITIVE: if the app hard
	 * deleted a bookmark that our table still holds, a reconcile would resurrect
	 * it. Deletes are the event mirror's job; convergence is this method's job.
	 * Run it at the enable transition and on explicit repair only.
	 *
	 * @since 3.1.0
	 *
	 * @return void
	 */
	public function reconcile() {
		global $wpdb;

		if ( ! $this->has_app() || ! bb_blog_pro_has_bookmark_engine() ) {
			return;
		}

		if ( empty( bbapp()->tables->bookmarks ) ) {
			return;
		}

		$ours    = BB_Bookmarks::get_bookmark_tbl();
		$theirs  = bbapp()->tables->bookmarks;
		$blog_id = get_current_blog_id();

		$this->data_syncing = true;

		try {
			// The upcoming INSERT ... ON DUPLICATE KEY UPDATE can flip an EXISTING
			// row's status in the database (0 -> 1). Capture those rows' IDs first
			// so their per-row wp_cache entry (written by
			// BB_Bookmarks::get_single_bookmark()) can be purged below --
			// BB_Bookmarks::purge_cache() with no argument only resets the query
			// incrementor, it does not touch a per-row cache entry that already
			// exists.
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- one-time merge between two custom tables.
			$affected_ids = $wpdb->get_col(
				$wpdb->prepare(
					"SELECT o.id FROM {$ours} o
					INNER JOIN {$theirs} a
						ON a.user_id = o.user_id AND a.item_id = o.item_id
							AND a.type = o.type AND a.blog_id = o.blog_id
					WHERE a.type = %s AND a.status = 1 AND a.blog_id = %d
						AND a.user_id > 0 AND a.item_id > 0",
					BB_BLOG_PRO_BOOKMARK_TYPE,
					$blog_id
				)
			);

			// App -> ours. One set-based statement. ON DUPLICATE KEY is only safe
			// because our table carries UNIQUE (blog_id, user_id, type, item_id).
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- one-time merge between two custom tables.
			$wpdb->query(
				$wpdb->prepare(
					"INSERT INTO {$ours} (blog_id, user_id, type, item_id, status, date_recorded)
					SELECT a.blog_id, a.user_id, a.type, a.item_id, 1, a.date_recorded
					FROM {$theirs} a
					WHERE a.type = %s AND a.status = 1 AND a.blog_id = %d
						AND a.user_id > 0 AND a.item_id > 0
					ON DUPLICATE KEY UPDATE status = 1",
					BB_BLOG_PRO_BOOKMARK_TYPE,
					$blog_id
				)
			);

			BB_Bookmarks::purge_cache();

			foreach ( (array) $affected_ids as $affected_id ) {
				wp_cache_delete( (int) $affected_id, BB_Bookmarks::CACHE_GROUP );
			}

			// Ours -> app. Pushed through the App's own API (not raw SQL) so its
			// caches and hooks stay coherent.
			//
			// Deliberately does NOT require `a.status = 1` in the NOT EXISTS check.
			// Ours is always `status = 1` here (by design — Platform keeps the row
			// and renders it as "Deleted post" rather than hiding it, see the class
			// docblock). If the App has ANY row for this bookmark, even one it has
			// deliberately hidden (`status = 0`) via its own transition_post_status
			// write path, that means the App already knows about it and we must
			// not touch it. Matching only `status = 1` here would make every hidden
			// App row look "missing" and push a fresh `status => 1` add on each
			// reconcile — un-hiding a bookmark the App deliberately hid. Matching
			// on any status ensures we only ever push rows the App has genuinely
			// never seen.
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- one-time merge between two custom tables.
			$missing = $wpdb->get_results(
				$wpdb->prepare(
					"SELECT o.user_id, o.item_id, o.date_recorded
					FROM {$ours} o
					WHERE o.type = %s AND o.status = 1 AND o.blog_id = %d
						AND NOT EXISTS (
							SELECT 1 FROM {$theirs} a
							WHERE a.user_id = o.user_id AND a.item_id = o.item_id
								AND a.type = o.type AND a.blog_id = o.blog_id
						)",
					BB_BLOG_PRO_BOOKMARK_TYPE,
					$blog_id
				)
			);

			foreach ( (array) $missing as $row ) {
				bbapp_add_bookmark(
					array(
						'type'          => BB_BLOG_PRO_BOOKMARK_TYPE,
						'user_id'       => (int) $row->user_id,
						'item_id'       => (int) $row->item_id,
						'status'        => 1,
						'date_recorded' => $row->date_recorded,
					)
				);
			}
		} finally {
			$this->data_syncing = false;
		}

		/**
		 * Fires after the blog bookmark stores have been reconciled.
		 *
		 * @since 3.1.0
		 */
		do_action( 'bb_blog_pro_bookmarks_reconciled' );
	}
}
