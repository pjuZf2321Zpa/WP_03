<?php

use MasterStudy\Lms\Pro\AddonsPlus\Notifications\Events;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_action( 'masterstudy_account_menu_before_mode', 'masterstudy_lms_notifications_render_account', 10, 1 );
add_filter( 'masterstudy_account_mobile_menu_items', 'masterstudy_lms_notifications_add_mobile_menu_item', 10, 2 );
add_filter( 'masterstudy_lms_account_dropdown_menu_items', 'masterstudy_lms_notifications_add_account_dropdown_item', 10, 2 );
add_filter( 'stm_lms_settings_menu_items', 'masterstudy_lms_notifications_add_profile_menu_setting', 20 );
add_action( 'wp_enqueue_scripts', 'masterstudy_lms_notifications_enqueue_push_toast_assets' );
add_action( 'wp_enqueue_scripts', 'masterstudy_lms_notifications_register_elementor_assets', 5 );
add_action( 'wp_footer', 'masterstudy_lms_notifications_render_push_toast' );
add_action( 'wp_logout', 'masterstudy_lms_notifications_deactivate_current_browser_subscription' );
add_action( 'wp_login', 'masterstudy_lms_notifications_clear_browser_key_cookie', 10, 0 );
add_action( 'elementor/editor/before_enqueue_scripts', 'masterstudy_lms_notifications_register_elementor_assets', 5 );
add_action( 'elementor/widgets/register', 'masterstudy_lms_notifications_register_elementor_widget' );

function masterstudy_lms_notifications_register_elementor_assets(): void {
	if ( ! defined( 'STM_LMS_PRO_URL' ) ) {
		return;
	}

	$version = defined( 'STM_LMS_PRO_VERSION' ) ? STM_LMS_PRO_VERSION : '1.0.0';
	$base    = trailingslashit( STM_LMS_PRO_URL ) . 'assets/';

	wp_register_style(
		'masterstudy-notifications-account',
		$base . 'css/account/notifications.css',
		array(),
		$version
	);
	wp_register_style(
		'masterstudy-notifications-elementor',
		$base . 'css/elementor/notifications.css',
		array( 'masterstudy-notifications-account', 'stm_lms_icons' ),
		$version
	);
	wp_register_script(
		'masterstudy-notifications-elementor',
		$base . 'js/elementor/notifications.js',
		array( 'jquery' ),
		$version,
		true
	);
}

function masterstudy_lms_notifications_localize_elementor_assets( ?int $unread_count = null ): void {
	static $localized = false;

	if ( $localized ) {
		return;
	}

	masterstudy_lms_notifications_register_elementor_assets();

	wp_localize_script(
		'masterstudy-notifications-elementor',
		'masterstudy_notifications_elementor_data',
		array(
			'labels'       => masterstudy_lms_notifications_account_labels(),
			'rest_url'     => esc_url_raw( rest_url( 'masterstudy-lms/v2/notifications' ) ),
			'nonce'        => wp_create_nonce( 'wp_rest' ),
			'unread_count' => null === $unread_count ? masterstudy_lms_notifications_unread_count() : $unread_count,
		)
	);

	$localized = true;
}

function masterstudy_lms_notifications_register_elementor_widget( $widgets_manager ): void {
	if ( ! class_exists( '\\Elementor\\Widget_Base' ) ) {
		return;
	}

	$widget_class = '\\MasterStudy\\Lms\\Pro\\AddonsPlus\\Notifications\\Elementor\\NotificationsWidget';

	if ( class_exists( $widget_class ) ) {
		masterstudy_lms_notifications_register_elementor_assets();
		$widgets_manager->register( new $widget_class() );
	}
}

function masterstudy_lms_notifications_render_account( $current_user ): void {
	if ( ! masterstudy_lms_notifications_is_frontend_allowed() ) {
		return;
	}

	masterstudy_lms_notifications_enqueue_account_assets();

	$notifications_labels = masterstudy_lms_notifications_account_labels();
	$unread_count         = masterstudy_lms_notifications_unread_count();
	$desktop_view         = masterstudy_lms_notifications_account_view();

	STM_LMS_Templates::show_lms_template(
		'account/parts/notifications',
		compact( 'notifications_labels', 'unread_count', 'desktop_view' )
	);
}

function masterstudy_lms_notifications_add_mobile_menu_item( array $menus, $current_user = array() ): array {
	if ( ! masterstudy_lms_notifications_is_frontend_allowed() || isset( $menus['notifications'] ) ) {
		return $menus;
	}

	$notifications_item = array(
		'title'       => __( 'Notifications', 'masterstudy-lms-learning-management-system-pro' ),
		'url'         => '#',
		'icon'        => 'stmlms-bell-outlined',
		'badge_count' => masterstudy_lms_notifications_unread_count(),
	);
	$updated_menus      = array();

	foreach ( $menus as $key => $item ) {
		$updated_menus[ $key ] = $item;

		if ( 'wishlist' === $key ) {
			$updated_menus['notifications'] = $notifications_item;
		}
	}

	if ( ! isset( $updated_menus['notifications'] ) ) {
		$updated_menus['notifications'] = $notifications_item;
	}

	return $updated_menus;
}

function masterstudy_lms_notifications_add_account_dropdown_item( array $menu_items, $current_user = array() ): array {
	if ( ! masterstudy_lms_notifications_is_frontend_allowed() ) {
		return $menu_items;
	}

	foreach ( $menu_items as $menu_item ) {
		if ( 'notifications' === ( $menu_item['id'] ?? '' ) ) {
			return $menu_items;
		}
	}

	$preference = masterstudy_lms_notifications_dropdown_menu_preference( $current_user );

	if ( ! $preference['enabled'] ) {
		return $menu_items;
	}

	$notifications_item = array(
		'order'        => 115,
		'id'           => 'notifications',
		'slug'         => 'notifications',
		'lms_template' => 'account/notifications',
		'menu_title'   => esc_html__( 'Notifications', 'masterstudy-lms-learning-management-system-pro' ),
		'menu_icon'    => 'stmlms-bell-outlined',
		'menu_url'     => add_query_arg(
			'masterstudy-notifications',
			'open',
			\STM_LMS_User::login_page_url()
		),
		'badge_count'  => masterstudy_lms_notifications_unread_count(),
		'is_active'    => false,
		'menu_place'   => 'learning',
		'section'      => 'communication',
	);

	$menu_items[] = $notifications_item;

	if ( ! empty( $preference['order'] ) ) {
		$ordered_items = array();

		foreach ( $preference['order'] as $menu_id ) {
			foreach ( $menu_items as $index => $menu_item ) {
				if ( ( $menu_item['id'] ?? '' ) === $menu_id ) {
					$ordered_items[] = $menu_item;
					unset( $menu_items[ $index ] );
					break;
				}
			}
		}

		return array_merge( $ordered_items, array_values( $menu_items ) );
	}

	$enrolled_courses_index = array_search( 'enrolled_courses', array_column( $menu_items, 'id' ), true );

	if ( false !== $enrolled_courses_index ) {
		array_pop( $menu_items );
		array_splice( $menu_items, $enrolled_courses_index + 1, 0, array( $notifications_item ) );
	}

	return $menu_items;
}

function masterstudy_lms_notifications_add_profile_menu_setting( array $menu_items ): array {
	if ( ! masterstudy_lms_notifications_is_frontend_allowed() ) {
		return $menu_items;
	}

	if ( in_array( 'notifications', array_column( $menu_items, 'id' ), true ) ) {
		return $menu_items;
	}

	$menu_items[] = array(
		'id'         => 'notifications',
		'label'      => esc_html__( 'Notifications', 'masterstudy-lms-learning-management-system-pro' ),
		'menu_place' => 'learning',
	);

	return $menu_items;
}

function masterstudy_lms_notifications_dropdown_menu_preference( $current_user = array() ): array {
	$user_id       = isset( $current_user['id'] ) ? absint( $current_user['id'] ) : get_current_user_id();
	$is_instructor = class_exists( '\\STM_LMS_Instructor' ) && \STM_LMS_Instructor::is_instructor( $user_id );
	$setting_name  = $is_instructor ? 'sorting_the_menu' : 'sorting_the_menu_student';
	$menu_settings = class_exists( '\\STM_LMS_Options' ) ? \STM_LMS_Options::get_option( $setting_name, array() ) : array();
	$preference    = array(
		'enabled' => true,
		'order'   => array(),
	);

	if ( ! is_array( $menu_settings ) ) {
		return $preference;
	}

	foreach ( $menu_settings as $column_index => $column ) {
		$options = isset( $column['options'] ) && is_array( $column['options'] ) ? $column['options'] : array();
		$ids     = array_column( $options, 'id' );

		if ( 0 === $column_index ) {
			$preference['order'] = $ids;
		}

		if ( in_array( 'notifications', $ids, true ) ) {
			$preference['enabled'] = 0 === $column_index;
			return $preference;
		}
	}

	$preference['order'] = array();

	return $preference;
}

function masterstudy_lms_notifications_is_frontend_allowed(): bool {
	return function_exists( 'masterstudy_lms_is_notifications_frontend_available' )
		&& masterstudy_lms_is_notifications_frontend_available();
}

function masterstudy_lms_notifications_render_push_toast(): void {
	if ( ! masterstudy_lms_notifications_is_push_toast_allowed() ) {
		return;
	}

	$notifications_push_toast_labels = masterstudy_lms_notifications_push_toast_labels();

	STM_LMS_Templates::show_lms_template(
		'account/parts/notifications-push-toast',
		compact( 'notifications_push_toast_labels' )
	);
}

function masterstudy_lms_notifications_enqueue_push_toast_assets(): void {
	if ( ! masterstudy_lms_notifications_is_push_toast_allowed() || ! defined( 'STM_LMS_PRO_URL' ) ) {
		return;
	}

	$version    = defined( 'STM_LMS_PRO_VERSION' ) ? STM_LMS_PRO_VERSION : '1.0.0';
	$base       = trailingslashit( STM_LMS_PRO_URL ) . 'assets/';
	$public_key = masterstudy_lms_notifications_push_public_key();

	if ( '' === $public_key ) {
		return;
	}

	wp_enqueue_style(
		'masterstudy-notifications-push-toast',
		$base . 'css/account/notifications-push-toast.css',
		array(),
		$version
	);
	wp_enqueue_script(
		'masterstudy-notifications-push-toast',
		$base . 'js/account/notifications-push-toast.js',
		array( 'jquery' ),
		$version,
		true
	);
	wp_localize_script(
		'masterstudy-notifications-push-toast',
		'masterstudy_notifications_push_toast_data',
		array(
			'cookie_name'             => 'masterstudy_notifications_push_dont_ask',
			'cookie_value'            => 'yes',
			'cookie_days'             => 182,
			'browser_key_cookie_name' => 'masterstudy_notifications_push_browser_key',
			'browser_key'             => masterstudy_lms_notifications_browser_key(),
			'browser_key_days'        => 1825,
			'rest_url'                => esc_url_raw( rest_url( 'masterstudy-lms/v2/notifications' ) ),
			'nonce'                   => wp_create_nonce( 'wp_rest' ),
			'service_worker_url'      => esc_url_raw( \MasterStudy\Lms\Pro\AddonsPlus\Notifications\Services\Push\ServiceWorker::url() ),
			'vapid_public_key'        => $public_key,
			'user_id'                 => get_current_user_id(),
			'labels'                  => masterstudy_lms_notifications_push_toast_labels(),
		)
	);
}

function masterstudy_lms_notifications_is_push_toast_allowed(): bool {
	if ( is_admin() || ! is_user_logged_in() ) {
		return false;
	}

	if (
		! function_exists( 'masterstudy_lms_is_notifications_push_frontend_available' )
		|| ! masterstudy_lms_is_notifications_push_frontend_available()
	) {
		return false;
	}

	if ( ! masterstudy_lms_notifications_is_push_toast_page() ) {
		return false;
	}

	if ( '' === masterstudy_lms_notifications_push_public_key() ) {
		return false;
	}

	$cookie_name     = 'masterstudy_notifications_push_dont_ask';
	$dont_ask_cookie = '';

	if ( isset( $_COOKIE[ $cookie_name ] ) && ! is_array( $_COOKIE[ $cookie_name ] ) ) {
		$dont_ask_cookie = sanitize_text_field( wp_unslash( $_COOKIE[ $cookie_name ] ) );
	}

	return 'yes' !== $dont_ask_cookie;
}

function masterstudy_lms_notifications_push_public_key(): string {
	try {
		if ( ! class_exists( '\MasterStudy\Lms\Pro\AddonsPlus\Notifications\Services\Push\PushRequirements' )
			|| ! \MasterStudy\Lms\Pro\AddonsPlus\Notifications\Services\Push\PushRequirements::is_met()
		) {
			return '';
		}

		return ( new \MasterStudy\Lms\Pro\AddonsPlus\Notifications\Services\Push\VapidKeys() )->public_key();
	} catch ( \Throwable $error ) {
		return '';
	}

	return '';
}

function masterstudy_lms_notifications_is_push_toast_page(): bool {
	if ( is_front_page() ) {
		return true;
	}

	$course_post_type = class_exists( 'MasterStudy\Lms\Plugin\PostType' )
		? \MasterStudy\Lms\Plugin\PostType::COURSE
		: 'stm-courses';

	if ( is_singular( $course_post_type ) ) {
		return true;
	}

	return masterstudy_lms_notifications_is_push_toast_account_page();
}

function masterstudy_lms_notifications_is_push_toast_account_page(): bool {
	$settings        = get_option( 'stm_lms_settings', array() );
	$account_page_id = isset( $settings['user_url'] ) ? absint( $settings['user_url'] ) : 0;

	if ( $account_page_id && function_exists( 'stm_lms_wpml_object_id_safe' ) ) {
		$account_page_id = (int) stm_lms_wpml_object_id_safe( $account_page_id, 'post' );
	}

	if ( ! $account_page_id || ! is_page( $account_page_id ) ) {
		return false;
	}

	$lms_template = (string) get_query_var( 'lms_template' );

	return '' === $lms_template
		|| in_array(
			$lms_template,
			array(
				'account/main',
				'account/student/dashboard',
				'account/enrolled-courses',
			),
			true
		);
}

function masterstudy_lms_notifications_enqueue_account_assets(): void {
	static $enqueued = false;

	if ( $enqueued || ! defined( 'STM_LMS_PRO_URL' ) ) {
		return;
	}

	$version = defined( 'STM_LMS_PRO_VERSION' ) ? STM_LMS_PRO_VERSION : '1.0.0';
	$base    = trailingslashit( STM_LMS_PRO_URL ) . 'assets/';

	wp_enqueue_style(
		'masterstudy-notifications-account',
		$base . 'css/account/notifications.css',
		array(),
		$version
	);
	wp_enqueue_script(
		'masterstudy-notifications-account',
		$base . 'js/account/notifications.js',
		array( 'jquery' ),
		$version,
		true
	);
	wp_localize_script(
		'masterstudy-notifications-account',
		'masterstudy_notifications_account_data',
		array(
			'labels'       => masterstudy_lms_notifications_account_labels(),
			'rest_url'     => esc_url_raw( rest_url( 'masterstudy-lms/v2/notifications' ) ),
			'nonce'        => wp_create_nonce( 'wp_rest' ),
			'unread_count' => masterstudy_lms_notifications_unread_count(),
			'desktop_view' => masterstudy_lms_notifications_account_view(),
		)
	);

	$enqueued = true;
}

function masterstudy_lms_notifications_account_view(): string {
	$settings = get_option( 'stm_lms_settings', array() );
	$view     = is_array( $settings ) && isset( $settings[ Events::ACCOUNT_VIEW_KEY ] )
		? $settings[ Events::ACCOUNT_VIEW_KEY ]
		: Events::ACCOUNT_VIEW_POPUP;

	return Events::sanitize_account_view( $view );
}

function masterstudy_lms_notifications_account_labels(): array {
	return array(
		'notifications' => __( 'Notifications', 'masterstudy-lms-learning-management-system-pro' ),
		'all'           => __( 'All', 'masterstudy-lms-learning-management-system-pro' ),
		'unread'        => __( 'Unread', 'masterstudy-lms-learning-management-system-pro' ),
		'mark_all_read' => __( 'Mark all read', 'masterstudy-lms-learning-management-system-pro' ),
		'done'          => __( 'Done', 'masterstudy-lms-learning-management-system-pro' ),
		'close'         => __( 'Close', 'masterstudy-lms-learning-management-system-pro' ),
		'new'           => __( 'new', 'masterstudy-lms-learning-management-system-pro' ),
		'empty'         => __( 'No notifications to show.', 'masterstudy-lms-learning-management-system-pro' ),
		'loading'       => __( 'Loading notifications...', 'masterstudy-lms-learning-management-system-pro' ),
	);
}

function masterstudy_lms_notifications_push_toast_labels(): array {
	return array(
		'title'       => __( 'Stay in the loop', 'masterstudy-lms-learning-management-system-pro' ),
		'description' => __( 'Get push alerts for new grades, replies and lessons across your courses.', 'masterstudy-lms-learning-management-system-pro' ),
		'not_now'     => __( 'Not now', 'masterstudy-lms-learning-management-system-pro' ),
		'enable'      => __( 'Enable', 'masterstudy-lms-learning-management-system-pro' ),
		'loading'     => __( 'Enabling...', 'masterstudy-lms-learning-management-system-pro' ),
		'dismiss'     => __( 'Dismiss', 'masterstudy-lms-learning-management-system-pro' ),
	);
}

function masterstudy_lms_notifications_unread_count(): int {
	if ( ! is_user_logged_in() || ! class_exists( '\MasterStudy\Lms\Pro\AddonsPlus\Notifications\Repositories\NotificationRepository' ) ) {
		return 0;
	}

	try {
		return ( new \MasterStudy\Lms\Pro\AddonsPlus\Notifications\Repositories\NotificationRepository() )->unread_count( get_current_user_id() );
	} catch ( \Throwable $error ) {
		return 0;
	}

	return 0;
}

function masterstudy_lms_notifications_browser_key(): string {
	$cookie_name = 'masterstudy_notifications_push_browser_key';

	if ( isset( $_COOKIE[ $cookie_name ] ) && ! is_array( $_COOKIE[ $cookie_name ] ) ) {
		$browser_key = sanitize_text_field( wp_unslash( $_COOKIE[ $cookie_name ] ) );

		if ( '' !== $browser_key ) {
			return $browser_key;
		}
	}

	return wp_generate_uuid4();
}

function masterstudy_lms_notifications_clear_browser_key_cookie(): void {
	if ( headers_sent() ) {
		return;
	}

	$cookie_path = '' !== COOKIEPATH ? COOKIEPATH : '/';

	setcookie( 'masterstudy_notifications_push_browser_key', '', time() - HOUR_IN_SECONDS, $cookie_path, COOKIE_DOMAIN, is_ssl(), true );
}

function masterstudy_lms_notifications_deactivate_current_browser_subscription(): void {
	$user_id = get_current_user_id();

	if ( $user_id > 0 && isset( $_COOKIE['masterstudy_notifications_push_browser_key'] ) && ! is_array( $_COOKIE['masterstudy_notifications_push_browser_key'] ) ) {
		$browser_key = sanitize_text_field( wp_unslash( $_COOKIE['masterstudy_notifications_push_browser_key'] ) );

		if ( '' !== $browser_key && class_exists( '\MasterStudy\Lms\Pro\AddonsPlus\Notifications\Repositories\PushSubscriptionRepository' ) ) {
			try {
				( new \MasterStudy\Lms\Pro\AddonsPlus\Notifications\Repositories\PushSubscriptionRepository() )->deactivate_by_browser_key( $user_id, $browser_key );
			} catch ( \Throwable $error ) {
				// Keep login/logout flows moving even when subscription cleanup fails.
				return;
			}
		}
	}

	masterstudy_lms_notifications_clear_browser_key_cookie();
}
