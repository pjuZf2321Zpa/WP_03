<?php

namespace FluentCartPro\App\Modules\DynamicPricing\Pricing;

use FluentCart\App\Helpers\Helper;
use FluentCart\App\Models\Cart;
use FluentCart\App\Models\Customer;
use FluentCart\App\Models\Subscription;
use FluentCart\App\Modules\MultiCurrency\Services\CartCurrency;
use FluentCart\App\Modules\MultiCurrency\Services\CurrencySnapshot;
use FluentCart\App\Modules\MultiCurrency\Services\PriceConverter;
use FluentCart\App\Modules\MultiCurrency\Services\RoundingRules;
use FluentCart\App\Services\DateTime\DateTime;
use FluentCart\Framework\Support\Arr;
use FluentCartPro\App\Modules\DynamicPricing\Conditions\ConditionResolver;
use FluentCartPro\App\Modules\DynamicPricing\Models\PricingRule;

/**
 * Works out what the active pricing rules do to a cart.
 *
 * Answers with a list of adjustments and changes nothing itself, so the caller
 * decides what to do with the numbers.
 *
 * @package FluentCartPro\App\Modules\DynamicPricing
 *
 * @version 1.0.0
 */
class DynamicPricingService
{
    /**
     * Whether this rule's Display Conditions hold for this cart.
     *
     * @param PricingRule $rule
     * @param ConditionResolver $conditions Resolver for the cart being priced.
     * @return bool
     */
    public function matchesConditions(PricingRule $rule, ConditionResolver $conditions): bool
    {
        $config = is_array($rule->config) ? $rule->config : [];

        return $conditions->matches((array)Arr::get($config, 'conditions', []));
    }

    /**
     * Whether `when_to_apply` allows this rule on this purchase.
     *
     * The caller says who is buying (`customer`) and what kind of purchase
     * this is (`purchase`); the rule's setting is held against that. Anything
     * else is skipped rather than guessed — a rule that does not fire is
     * fixable, a discount that fires where it should not is money already gone.
     *
     * @param PricingRule $rule
     * @param array $context
     * @return bool
     */
    protected function shouldApplyRule(PricingRule $rule, array $context): bool
    {
        $config = is_array($rule->config) ? $rule->config : [];
        $whenToApply = Arr::get($config, 'when_to_apply', 'every');

        // A renewal order is the amount the customer agreed to; only a rule
        // that names renewals may change it. Decided here, so no other rule is
        // looked at on a renewal and no customer is queried for it.
        if (Arr::get($context, 'purchase.is_renewal_order')) {
            return $whenToApply === 'renewals';
        }

        switch ($whenToApply) {
            case 'every':
                return true;

            case 'first':
                return $this->isFirstPurchase((array)Arr::get($context, 'customer', []));

            case 'upgrades':
                return (bool)Arr::get($context, 'purchase.is_upgrade');

            default:
                return false;
        }
    }

    /**
     * Whether this is the customer's first paid order in the store.
     *
     * The store already keeps the answer: Customer::purchase_count counts
     * orders in a paid status. A signed-in customer is read directly; a guest
     * is matched by the email typed at checkout, and an email nobody has used
     * is a first purchase. No email yet means nothing is known, so nothing is
     * given — the discount appears once they type it.
     *
     * @param array $customerDetails ['customer_id' => int, 'email' => string]
     * @return bool
     */
    protected function isFirstPurchase(array $customerDetails): bool
    {
        $customerId = (int)Arr::get($customerDetails, 'customer_id');
        $email = trim((string)Arr::get($customerDetails, 'email'));

        if ($customerId) {
            $customer = Customer::query()->find($customerId);
        } elseif ($email) {
            $customer = Customer::query()->where('email', $email)->first();
        } else {
            return false;
        }

        if (!$customer) {
            return true;
        }

        return (int)$customer->purchase_count === 0;
    }

    /**
     * Whether the cart pays an existing order through its payment link.
     *
     * @param mixed $cart
     * @return bool
     */
    public static function isPaymentLinkCart($cart): bool
    {
        return $cart instanceof Cart && Arr::get($cart->checkout_data, 'custom_checkout') === 'yes';
    }

    /**
     * Every adjustment the active rules make to this cart.
     *
     * @param array $context ['cart' => ['subtotal' => int, 'shipping_total' => int, 'items' => array]]
     * @param string|null $priceType Only rules of this price type ('discount' or 'fee'), or all.
     * @param ConditionResolver|null $conditions Reuse one already built for the same cart,
     *                                           so its looked-up values are not fetched again.
     * @return array Adjustments, each with a signed `adjustment_amount` in cents.
     */
    public function calculate(array $context, ?string $priceType = null, ?ConditionResolver $conditions = null): array
    {
        $cart = Arr::get($context, 'cart', []);
        $adjustments = [];
        $quote = [];
        if (class_exists(CartCurrency::class)) {
            $checkoutCart = Arr::get($context, 'checkout_cart');
            $subscription = Arr::get($context, 'subscription');
            if ($subscription instanceof Subscription) {
                $quote = CurrencySnapshot::fromSubscription($subscription);
            } else {
                $quote = $checkoutCart instanceof Cart ? CartCurrency::targetQuote($checkoutCart) : CartCurrency::currentQuote();
            }
        }

        $rules = $this->eligibleRules();
        $conditions = $conditions ?: new ConditionResolver($context);
        $checkoutCart = Arr::get($context, 'checkout_cart');
        $isPaymentLink = static::isPaymentLinkCart($checkoutCart);
        // A fixed shipping fee ignores its base, so a cart that ships nothing must skip it.
        $shipsNothing = $checkoutCart instanceof Cart && !$checkoutCart->requireShipping();

        foreach ($rules as $rule) {
            if ($priceType !== null && $rule->price_type !== $priceType) {
                continue;
            }

            if ($shipsNothing && $rule->applies_to === 'shipping') {
                continue;
            }

            // A payment link's items already carry the order's discounts;
            // only its shipping is priced again at place-order.
            if ($isPaymentLink && $rule->applies_to !== 'shipping') {
                continue;
            }

            // When to apply first: it is cheap, and a renewal rejects every
            // rule not meant for it before any condition value is looked up.
            if (!$this->shouldApplyRule($rule, $context)) {
                continue;
            }

            if (!$this->matchesConditions($rule, $conditions)) {
                continue;
            }

            foreach ($this->basesFor($rule, $cart) as $itemKey => $base) {
                if ($rule->price_type === 'fee') {
                    $amount = $this->feeFor($rule, $base, $itemKey, $cart, $context, $quote);
                } else {
                    $amount = $this->adjustmentFor($rule, $base, $quote);
                }

                // Zero is not an adjustment — it would show as a "0.00 off" line.
                if ($amount === 0) {
                    continue;
                }

                $adjustments[] = [
                    'rule_id'           => $rule->id,
                    'rule_type'         => (string)$rule->rule_type,
                    'rule_name'         => (string)($rule->display_name ?: $rule->name),
                    'applies_to'        => (string)$rule->applies_to,
                    'adjustment_type'   => $amount < 0 ? 'discount' : 'fee',
                    'adjustment_amount' => $amount,
                    'taxable'           => $rule->isFeeTaxable(),
                    // Null for a whole-cart rule, the cart item key for a line rule.
                    'item_key'          => $itemKey === '' ? null : $itemKey,
                ];
            }
        }

        return $adjustments;
    }

    /**
     * The rules that are on right now.
     *
     * Active is not the whole answer: a rule can be switched on and still be
     * waiting to start or already finished. Both dates are optional and the
     * schema says what an empty one means — no start is "from now", no end is
     * "never" — so a null passes rather than excludes.
     *
     * Compared in GMT because that is what the column holds.
     *
     * The active rules come from the object cache after the first read; a
     * change to a rule clears it (see PricingRule::clearRulesCache()). The
     * dates are checked here rather than in the query, so a cached list stays
     * right as a rule's window opens and closes.
     *
     * @return \FluentCart\Framework\Database\Orm\Collection
     */
    protected function eligibleRules()
    {
        // Versioned by the group's last change: a checkout that read the rules
        // just before an admin change stores them under the old version, which
        // nobody reads again, instead of over the cleared entry.
        $cacheKey = PricingRule::ACTIVE_RULES_CACHE_KEY . ':' . wp_cache_get_last_changed(PricingRule::CACHE_GROUP);

        $rows = wp_cache_get($cacheKey, PricingRule::CACHE_GROUP);

        if (!is_array($rows)) {
            // Plain rows, so the cache holds data rather than model objects.
            $rows = PricingRule::query()
                ->where('status', 'active')
                ->orderBy('id', 'ASC')
                ->get()
                ->map(function (PricingRule $rule) {
                    return $rule->getAttributes();
                })
                ->all();

            wp_cache_set($cacheKey, $rows, PricingRule::CACHE_GROUP, HOUR_IN_SECONDS);
        }

        // Both columns are 'Y-m-d H:i:s' in GMT, which compares as a string.
        $now = DateTime::gmtNow()->format('Y-m-d H:i:s');

        $rows = array_filter($rows, function ($row) use ($now) {
            $start = Arr::get($row, 'start_date');
            $end = Arr::get($row, 'end_date');

            return (!$start || $start <= $now) && (!$end || $end >= $now);
        });

        return PricingRule::query()->hydrate(array_values($rows));
    }

    /**
     * Get the amounts this rule should be applied to.
     *
     * Checkout and shipping use one cart-level amount, while line-item rules
     * return each item's subtotal separately so the adjustment can be calculated
     * for each item.
     *
     * @param PricingRule $rule
     * @param array $cart
     * @return array
     */
    protected function basesFor(PricingRule $rule, array $cart): array
    {
        if ($rule->applies_to === 'line_item') {
            $bases = [];

            foreach ((array)Arr::get($cart, 'items', []) as $key => $item) {
                // The line subtotal, not the unit price, so a percentage covers
                // every unit on the line.
                $bases[$key] = (int)Arr::get((array)$item, 'subtotal', 0);
            }

            return $bases;
        }

        if ($rule->applies_to === 'checkout') {
            return ['' => (int)Arr::get($cart, 'subtotal', 0)];
        }

        if ($rule->applies_to === 'shipping') {
            return ['' => (int)Arr::get($cart, 'shipping_total', 0)];
        }

        // Only those three are valid targets, so anything else is measured
        // against nothing and adjusts nothing.
        return [];
    }

    /**
     * Work out a fee rule's amount for one base.
     *
     * A percentage fee is measured on the price after discounts, so a 100%
     * coupon leaves nothing to charge on; a fixed fee ignores the base and stays.
     *
     * @param PricingRule $rule
     * @param int $subtotal The base before discounts.
     * @param string|int $itemKey Empty for a whole-cart rule.
     * @param array $cart
     * @param array $context
     * @param array $quote
     * @return int Fee in cents, zero for none.
     */
    protected function feeFor(PricingRule $rule, int $subtotal, $itemKey, array $cart, array $context, array $quote = []): int
    {
        $discounted = null;
        if ($rule->applies_to === 'checkout') {
            $discounted = Arr::get($cart, 'discounted_subtotal');
        } elseif ($rule->applies_to === 'line_item') {
            $discounted = Arr::get((array)Arr::get($cart, 'discounted_items', []), $itemKey);
        }

        // Callers without discount figures (shipping, renewals) keep the plain base.
        $base = $discounted === null ? $subtotal : (int)$discounted;

        $filterContext = [
            'rule'     => $rule,
            'item_key' => $itemKey === '' ? null : $itemKey,
            'subtotal' => $subtotal,
            'cart'     => Arr::get($context, 'checkout_cart'),
        ];

        $base = max(0, (int)apply_filters('fluent_cart/dynamic_pricing/fee_base', $base, $filterContext));

        $amount = $this->adjustmentFor($rule, $base, $quote);

        $filterContext['base'] = $base;

        return max(0, (int)apply_filters('fluent_cart/dynamic_pricing/fee_amount', $amount, $filterContext));
    }

    /**
     * Calculate the discount or fee for a given base amount.
     *
     * Returns the final adjustment in cents. For example, a $50 base with a 10%
     * discount returns `-500`, while a 10% fee returns `500`.
     *
     * @param PricingRule $rule
     * @param int $base
     * @param array $quote
     * @return int
     */
    protected function adjustmentFor(PricingRule $rule, int $base, array $quote = []): int
    {
        $config = is_array($rule->config) ? $rule->config : [];
        $amount = Arr::get($config, 'amount');

        // Stored as the merchant typed it, so this arrives as the string "10".
        if (!is_numeric($amount)) {
            return 0;
        }

        $amount = (float)$amount;

        // A negative amount would flip the rule's direction — a "discount" that
        // adds money. Direction belongs to price_type alone.
        if ($amount <= 0 || !is_finite($amount)) {
            return 0;
        }

        if (Arr::get($config, 'apply_as') === 'fixed') {
            // A fixed amount is decimal; a percentage is not. Only this converts.
            $adjustment = Helper::toCent($amount);
            if ($quote) {
                if (!CurrencySnapshot::hasTrustedRate($quote)) {
                    return 0;
                }
                $adjustment = PriceConverter::toQuote($adjustment, $quote);
            }
        } else {
            // Rounded, so 33% of 1000 is 330 and not 329.
            $adjustment = $base * ($amount / 100);
        }

        $adjustment = $quote
            ? RoundingRules::apply($adjustment, $quote['currency'])
            : (int) round($adjustment);

        if ($adjustment <= 0) {
            return 0;
        }

        if ($rule->price_type === 'fee') {
            return $adjustment;
        }

        // A discount can only remove what is there, or a 120% rule hands money back.
        return -min($adjustment, max(0, $base));
    }
}
