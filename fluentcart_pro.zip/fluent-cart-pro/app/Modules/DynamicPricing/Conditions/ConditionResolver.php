<?php

namespace FluentCartPro\App\Modules\DynamicPricing\Conditions;

use FluentCart\Api\PaymentMethods;
use FluentCart\App\Models\Cart;
use FluentCart\App\Models\Coupon;
use FluentCart\App\Models\Customer;
use FluentCart\App\Models\ProductVariation;
use FluentCart\App\Modules\PaymentMethods\Core\GatewayManager;
use FluentCart\Framework\Support\Arr;

/**
 * Decides whether a rule's Display Conditions hold for one pricing context.
 *
 * Conditions are saved as groups of rows: the groups are ORed, the rows inside
 * a group are ANDed. Each row reads its real value from the context and
 * compares it with the saved one using the row's operator.
 *
 * A value the context does not carry fails its row whatever the operator, so
 * "role is not wholesale" does not pass on an order that never said who the
 * user is. A discount that does not fire is fixable; one that fires wrongly is
 * money already gone.
 *
 * One instance serves one calculation, so a value several rules ask for is
 * looked up once.
 *
 * @package FluentCartPro\App\Modules\DynamicPricing
 *
 * @version 1.0.0
 */
class ConditionResolver
{
    /**
     * @var array ['cart' => [...], 'customer' => [...], 'purchase' => [...],
     *             'checkout_cart' => Cart|null]
     */
    protected $context;

    /**
     * Registered attributes by key, read once rather than once per row.
     *
     * @var array
     */
    protected $attributes;

    /**
     * Values already resolved for this context, by attribute key.
     *
     * @var array
     */
    protected $values = [];

    public function __construct(array $context)
    {
        $this->context = $context;
        $this->attributes = ConditionRegistry::flattened();
    }

    /**
     * @param array $groups The rule's saved `config.conditions`.
     * @return bool
     */
    public function matches(array $groups): bool
    {
        // No conditions means the rule is for everyone.
        if (!$groups) {
            return true;
        }

        foreach ($groups as $group) {
            if (is_array($group) && $group && $this->groupMatches($group)) {
                return true;
            }
        }

        return false;
    }

    /**
     * @param array $group
     * @return bool
     */
    protected function groupMatches(array $group): bool
    {
        foreach ($group as $condition) {
            if (!is_array($condition) || !$this->conditionMatches($condition)) {
                return false;
            }
        }

        return true;
    }

    /**
     * @param array $condition ['key' => string, 'operator' => string, 'value' => mixed]
     * @return bool
     */
    protected function conditionMatches(array $condition): bool
    {
        $key = (string)Arr::get($condition, 'key', '');
        $operator = (string)Arr::get($condition, 'operator', '');
        $attribute = Arr::get($this->attributes, $key);

        // An attribute that is no longer registered, or an operator it does
        // not offer, is a condition nobody can check.
        if (!is_array($attribute) || !array_key_exists($operator, (array)Arr::get($attribute, 'operators', []))) {
            return false;
        }

        // Looked up once per calculation, however many rules ask for it.
        if (!array_key_exists($key, $this->values)) {
            $this->values[$key] = $this->resolve($key);
        }

        $actual = $this->values[$key];

        if ($actual === null) {
            return false;
        }

        $expected = Arr::get($condition, 'value');

        switch (Arr::get($attribute, 'input_type')) {
            case 'number':
            case 'currency':
                return is_numeric($actual) && is_numeric($expected)
                    && $this->compareNumber($actual + 0, $operator, $expected + 0);

            case 'select':
                return $this->compareSelect((array)$actual, $operator, (array)$expected);

            default:
                return $this->compareText((array)$actual, $operator, (string)$expected);
        }
    }

    /**
     * @param int|float $actual
     * @param string $operator
     * @param int|float $expected
     * @return bool
     */
    protected function compareNumber($actual, string $operator, $expected): bool
    {
        switch ($operator) {
            case 'is':
                return $actual == $expected;
            case 'is_not':
                return $actual != $expected;
            case 'is_more_than':
                return $actual > $expected;
            case 'is_less_than':
                return $actual < $expected;
            case 'is_at_least':
                return $actual >= $expected;
            case 'is_at_most':
                return $actual <= $expected;
            default:
                return false;
        }
    }

    /**
     * `is` passes when any selected id is present, `is_not` when none is.
     *
     * Compared as strings, so a role slug and a numeric id go through the same
     * check and "12" matches 12.
     *
     * @param array $actual
     * @param string $operator
     * @param array $expected
     * @return bool
     */
    protected function compareSelect(array $actual, string $operator, array $expected): bool
    {
        $found = (bool)array_intersect(array_map('strval', $actual), array_map('strval', $expected));

        if ($operator === 'is') {
            return $found;
        }

        if ($operator === 'is_not') {
            return !$found;
        }

        return false;
    }

    /**
     * A cart can hold several names, so the positive operators pass when any
     * of them matches and the negative ones only when every name does.
     *
     * @param array $actual
     * @param string $operator
     * @param string $expected
     * @return bool
     */
    protected function compareText(array $actual, string $operator, string $expected): bool
    {
        $expected = strtolower(trim($expected));

        // A negative operator has to hold for every name, a positive one for any.
        $every = in_array($operator, ['is_not', 'not_contains'], true);

        foreach ($actual as $value) {
            $matched = $this->textMatches(strtolower(trim((string)$value)), $operator, $expected);

            if ($matched !== $every) {
                return $matched;
            }
        }

        return $every;
    }

    /**
     * @param string $value
     * @param string $operator
     * @param string $expected
     * @return bool
     */
    protected function textMatches(string $value, string $operator, string $expected): bool
    {
        switch ($operator) {
            case 'is':
                return $value === $expected;
            case 'is_not':
                return $value !== $expected;
            case 'contains':
                return strpos($value, $expected) !== false;
            case 'not_contains':
                return strpos($value, $expected) === false;
            case 'starts_with':
                return strpos($value, $expected) === 0;
            case 'ends_with':
                return $expected === '' || substr($value, -strlen($expected)) === $expected;
            default:
                return false;
        }
    }

    /**
     * Read one attribute's real value from the context.
     *
     * @param string $key
     * @return mixed Null when the context cannot answer.
     */
    protected function resolve(string $key)
    {
        $items = (array)Arr::get($this->context, 'cart.items', []);

        switch ($key) {
            case 'quantity':
                return (int)array_sum(array_map(function ($item) {
                    return (int)Arr::get((array)$item, 'quantity', 0);
                }, $items));

            case 'cart_subtotal':
                return (int)Arr::get($this->context, 'cart.subtotal', 0);

            case 'product':
                return $this->itemValues($items, 'post_id');

            case 'product_name':
                return $this->itemValues($items, 'post_title');

            case 'product_sku':
                return $this->itemSkus($items);

            case 'coupon_name':
                return $this->couponCodes();

            case 'coupon':
                $codes = $this->couponCodes();

                return $codes === null ? null : ($codes ? Coupon::query()->whereIn('code', $codes)->pluck('id')->toArray() : []);

            case 'checkout_email':
                return $this->checkoutEmail();

            case 'customer':
                $customerId = $this->customerId();

                return $customerId === null ? null : array_filter([$customerId]);

            case 'customer_purchase_count':
                $customerId = $this->customerId();

                if ($customerId === null) {
                    return null;
                }

                // A guest has no orders on record; a customer that no longer
                // exists has no count we can trust, so the row fails rather
                // than reading as zero.
                if (!$customerId) {
                    return 0;
                }

                $customer = Customer::query()->find($customerId);

                return $customer ? (int)$customer->purchase_count : null;

            case 'wp_user_role':
                $cart = $this->checkoutCart();

                if (!$cart) {
                    return null;
                }

                $userId = $this->signedInUserId($cart);
                $user = $userId ? get_userdata($userId) : null;

                return $user ? (array)$user->roles : [];

            case 'payment_method':
                $cart = $this->checkoutCart();

                if (!$cart) {
                    return null;
                }

                // The methods checkout offers this cart, in the order it shows
                // them — the same list and filter CheckoutRenderer uses.
                $methods = apply_filters('fluent_cart/checkout_active_payment_methods', PaymentMethods::getActiveMethodInstance($cart), [
                    'cart' => $cart,
                ]);

                $offered = [];

                foreach (is_array($methods) ? $methods : [] as $method) {
                    if (is_object($method) && method_exists($method, 'getMeta')) {
                        $offered[] = (string)$method->getMeta('route');
                    }
                }

                if (!$offered) {
                    return null;
                }

                // The radio the shopper picked, then the method place-order
                // recorded — each only while this cart can pay with it. Asked
                // per method rather than of the rendered list: a gateway with
                // its own picker (saved cards) is left out of the radios yet
                // is a real choice.
                $checkoutData = (array)$cart->checkout_data;

                foreach (['form_data._fct_pay_method', 'payment_method'] as $path) {
                    $method = (string)Arr::get($checkoutData, $path, '');

                    if ($method !== '' && $this->isPaymentMethodAvailable($cart, $method)) {
                        return [$method];
                    }
                }

                // Nothing usable picked: checkout shows the first method
                // checked, and place-order pays with it.
                return [$offered[0]];
        }

        if (CheckoutFieldConditions::handles($key)) {
            return CheckoutFieldConditions::value($key, $this->checkoutCart());
        }

        // An add-on attribute answers through the resolver it registered.
        $resolver = Arr::get($this->attributes, $key . '.resolver');

        return is_callable($resolver) ? call_user_func($resolver, $this->context) : null;
    }

    /**
     * One field from every cart line, or null when a line does not carry it —
     * a renewal line, for one, names no product.
     *
     * @param array $items
     * @param string $field
     * @return array|null
     */
    protected function itemValues(array $items, string $field)
    {
        $values = [];

        foreach ($items as $item) {
            $value = Arr::get((array)$item, $field);

            if ($value === null || $value === '') {
                return null;
            }

            $values[] = $value;
        }

        return $values;
    }

    /**
     * The SKU of every cart line, read from its variation in one query.
     *
     * A line carries its variation id, not the SKU. A variation without a SKU
     * reads as '' — it never matches "is X" and does count as "not X". A line
     * that names no variation (a renewal), one that no longer exists, or a
     * custom item leaves the SKU unknown, so the row fails.
     *
     * @param array $items
     * @return array|null
     */
    protected function itemSkus(array $items)
    {
        foreach ($items as $item) {
            // A custom item's id is the add-on's own, not a variation's, so
            // looking it up would read some other product's SKU.
            if (Arr::get((array)$item, 'is_custom')) {
                return null;
            }
        }

        $variationIds = $this->itemValues($items, 'object_id');

        if ($variationIds === null) {
            return null;
        }

        $skus = ProductVariation::query()
            ->whereIn('id', array_unique(array_map('intval', $variationIds)))
            ->pluck('sku', 'id')
            ->toArray();

        $values = [];

        foreach ($variationIds as $variationId) {
            if (!array_key_exists((int)$variationId, $skus)) {
                return null;
            }

            $values[] = (string)$skus[(int)$variationId];
        }

        return $values;
    }

    /**
     * The email the checkout's order is placed under.
     *
     * A signed-in shopper's order is placed under their account email, whatever
     * is typed into the field; a guest's under the email they typed, which
     * checkout saves onto the cart. Null when there is no cart (a renewal) or
     * no email yet.
     *
     * @return array|null
     */
    protected function checkoutEmail()
    {
        $cart = $this->checkoutCart();

        if (!$cart) {
            return null;
        }

        $email = is_user_logged_in() ? wp_get_current_user()->user_email : $cart->email;
        $email = trim((string)$email);

        return $email === '' ? null : [$email];
    }

    /**
     * The codes applied to the cart, or null when there is no cart.
     *
     * @return array|null
     */
    protected function couponCodes()
    {
        $cart = $this->checkoutCart();

        return $cart ? array_values(array_filter((array)$cart->coupons)) : null;
    }

    /**
     * The cart being priced. A renewal order has none, so every condition
     * that reads it fails there.
     *
     * @return Cart|null
     */
    protected function checkoutCart()
    {
        $cart = Arr::get($this->context, 'checkout_cart');

        return $cart instanceof Cart ? $cart : null;
    }

    /**
     * The customer the checkout is for. Read from the id only, never from a
     * typed email, so nobody gets another customer's pricing by typing it.
     *
     * At checkout the customer counts only while their user is the one
     * signed in. A renewal has no cart, and its customer comes from the
     * subscription, so it is taken as given.
     *
     * @return int|null 0 for a guest, null when the context does not say.
     */
    protected function customerId()
    {
        if (!Arr::has($this->context, 'customer.customer_id')) {
            return null;
        }

        $cart = $this->checkoutCart();

        if ($cart && !$this->signedInUserId($cart)) {
            return 0;
        }

        return (int)Arr::get($this->context, 'customer.customer_id');
    }

    /**
     * Check if a payment method is available for the cart.
     *
     * @param Cart   $cart
     * @param string $route Payment method route.
     * @return bool
     */
    protected function isPaymentMethodAvailable(Cart $cart, string $route): bool
    {
        // The checks place-order runs on the posted method (PaymentHelper::
        // validateAndGetPayMethod), not getActiveMethodInstance(): that list
        // reads `is_active` from the whole settings array, which a gateway such
        // as the saved card only answers when asked for the key by name.
        if (!GatewayManager::has($route)) {
            return false;
        }

        $gateway = GatewayManager::getInstance($route);
        $status = $gateway->validatePaymentMethod(['isValid' => false, 'isZeroPayment' => false]);

        if (!Arr::get((array)$status, 'isValid')) {
            return false;
        }

        // Checkout never offers a gateway that cannot take the store's currency.
        if (method_exists($gateway, 'isCurrencySupported') && !$gateway->isCurrencySupported()) {
            return false;
        }

        $allowed = apply_filters('fluent_cart/checkout_active_payment_methods', [$gateway], ['cart' => $cart]);

        return in_array($gateway, (array)$allowed, true);
    }

    /**
     * The cart's user, but only while they are the one signed in.
     *
     * Logging out leaves the cart cookie in the browser, so whoever uses it
     * next opens the same cart. Trusting the user it names would hand them
     * that user's role and customer pricing. And a cart priced while someone
     * else is signed in — an admin, say — is not theirs either.
     *
     * @param Cart $cart
     * @return int 0 when the cart's user is not the one signed in.
     */
    protected function signedInUserId(Cart $cart): int
    {
        $userId = (int)$cart->user_id;

        return $userId && $userId === get_current_user_id() ? $userId : 0;
    }
}
