<?php

namespace FluentCartPro\App\Modules\SavedPaymentMethods;

use FluentCart\App\Models\Customer;
use FluentCart\App\Modules\PaymentMethods\StripeGateway\API\API;
use FluentCart\App\Modules\PaymentMethods\StripeGateway\Confirmations;
use FluentCart\App\Modules\PaymentMethods\StripeGateway\StripeHelper;
use FluentCart\Framework\Support\Arr;

/**
 * Adds a saved card from the customer portal (no purchase).
 *
 * Uses the return-based core Stripe API layer directly (API::createStripeObject)
 * rather than SubscriptionsManager::verifyPaymentMethod / UpdateCustomerPaymentMethod,
 * because those wp_send_json()+die() on the requires_action/failure paths and
 * cannot be wrapped in a clean REST response. The result contract mirrors the
 * subscription card-update flow so the frontend 3DS loop is identical:
 *   requires_action -> {status, client_secret, setup_intent_id} (HTTP 200)
 *   failed          -> {status, message}                        (HTTP 423/429)
 *   success         -> {status, message, data:[cards]}          (HTTP 200)
 *
 * Rate limiting shares core's per-Stripe-customer daily bucket (same transient
 * key + filter as SubscriptionsManager::checkRateLimit) so card-testing defense
 * is unified across checkout and the portal.
 */
class AddCardService
{
    const RATE_LIMIT_FILTER = 'fluent_cart/stripe/setup_intent_rate_limit_customer_daily';
    const DEFAULT_RATE_LIMIT = 3;

    /**
     * @return array ['code' => int, 'body' => array]
     */
    public function addCard(Customer $customer, $paymentMethodId, $setupIntentId, $setDefault)
    {
        $stripeCustomer = StripeHelper::createOrGetStripeCustomer($customer);
        if (is_wp_error($stripeCustomer)) {
            return $this->fail($stripeCustomer->get_error_message());
        }

        $vendorCustomerId = Arr::get($stripeCustomer, 'id');
        if (!$vendorCustomerId) {
            return $this->fail(__('Could not resolve the payment customer.', 'fluent-cart-pro'));
        }

        $api = new API();

        if ($setupIntentId) {
            // 3DS re-submit — re-verify the SetupIntent server-side (never trust
            // the client's word that authentication succeeded).
            $setupIntent = $api->getStripeObject('setup_intents/' . $setupIntentId);
            if (is_wp_error($setupIntent)
                || Arr::get($setupIntent, 'status') !== 'succeeded'
                || Arr::get($setupIntent, 'customer') !== $vendorCustomerId) {
                return $this->fail(__('Card verification failed', 'fluent-cart-pro'));
            }
            $paymentMethodId = Arr::get($setupIntent, 'payment_method', $paymentMethodId);
        } else {
            if (!$paymentMethodId) {
                return $this->fail(__('Missing payment method.', 'fluent-cart-pro'), 422);
            }

            // Rate limit only on fresh SetupIntent creation (the money-adjacent,
            // card-testing-prone action).
            if (!$this->bumpRateLimit($vendorCustomerId)) {
                return $this->fail(__('Daily verification limit reached. You can try again tomorrow.', 'fluent-cart-pro'), 429);
            }

            $setupIntent = $api->createStripeObject('setup_intents', [
                'payment_method'       => $paymentMethodId,
                'customer'             => $vendorCustomerId,
                'payment_method_types' => ['card'],
                'confirm'              => 'true',
                'usage'                => 'off_session',
            ]);

            if (is_wp_error($setupIntent)) {
                return $this->fail($setupIntent->get_error_message());
            }

            $status = Arr::get($setupIntent, 'status');
            if ($status === 'requires_action') {
                return [
                    'code' => 200,
                    'body' => [
                        'status'          => 'requires_action',
                        'client_secret'   => Arr::get($setupIntent, 'client_secret'),
                        'setup_intent_id' => Arr::get($setupIntent, 'id'),
                    ],
                ];
            }
            if ($status !== 'succeeded') {
                return $this->fail(__('Card verification failed', 'fluent-cart-pro'));
            }
        }

        // SetupIntent succeeded → the PM is verified. Stripe attaches it to the
        // customer on success; the explicit attach is idempotent belt-and-braces.
        // A failed attach (e.g. PM already attached to another customer) must not
        // be stored — it would be unusable at charge time.
        $attach = $api->createStripeObject('payment_methods/' . $paymentMethodId . '/attach', ['customer' => $vendorCustomerId]);
        if (is_wp_error($attach)) {
            return $this->fail(__('This card could not be saved. Please try a different card.', 'fluent-cart-pro'));
        }

        if ($setDefault === 'yes') {
            $api->createStripeObject('customers/' . $vendorCustomerId, [
                'invoice_settings' => ['default_payment_method' => $paymentMethodId],
            ]);
        }

        // Reuse core's authoritative writer (lists the customer's PMs from Stripe,
        // dedupes by fingerprint, writes the saved_payment_method meta). It reads
        // only $order->customer_id, so a minimal context object stands in for the
        // (nonexistent) order in this portal flow.
        $orderContext = (object) ['customer_id' => $customer->id];
        (new Confirmations())->savePaymentMethodToCustomerMeta($vendorCustomerId, $paymentMethodId, $orderContext);

        return [
            'code' => 200,
            'body' => [
                'status'  => 'success',
                'message' => __('Card saved', 'fluent-cart-pro'),
                'data'    => (new SavedPaymentMethodRepository())->list($customer),
            ],
        ];
    }

    /**
     * Remaining SetupIntent verification attempts for the customer today.
     */
    public function remainingAttempts($vendorCustomerId): int
    {
        $limit = (int) apply_filters(self::RATE_LIMIT_FILTER, self::DEFAULT_RATE_LIMIT, $vendorCustomerId);
        $attempts = (int) (get_transient($this->rateKey($vendorCustomerId)) ?: 0);

        return max(0, $limit - $attempts);
    }

    private function bumpRateLimit($vendorCustomerId): bool
    {
        global $wpdb;

        $limit = (int) apply_filters(self::RATE_LIMIT_FILTER, self::DEFAULT_RATE_LIMIT, $vendorCustomerId);
        $key = $this->rateKey($vendorCustomerId);

        // Same lock as core SubscriptionsManager::checkRateLimit, so parallel
        // attempts from either path count one at a time.
        $lockName = 'fct_seti_' . md5((string) $vendorCustomerId);
        if ((string) $wpdb->get_var($wpdb->prepare('SELECT GET_LOCK(%s, %d)', $lockName, 2)) !== '1') {
            return false;
        }

        try {
            $attempts = (int) (get_transient($key) ?: 0);

            if ($attempts >= $limit) {
                return false;
            }

            // Fixed window, not sliding: re-setting with a full DAY_IN_SECONDS on
            // every bump pushes the expiry forward each attempt, so a
            // once-a-day user never gets a reset. Keep the window anchored to the
            // FIRST attempt by preserving the remaining TTL on later bumps.
            $expiresAt = (int) get_option('_transient_timeout_' . $key);
            $ttl = ($attempts > 0 && $expiresAt > time())
                ? $expiresAt - time()
                : DAY_IN_SECONDS;

            return set_transient($key, $attempts + 1, $ttl);
        } finally {
            $wpdb->get_var($wpdb->prepare('SELECT RELEASE_LOCK(%s)', $lockName));
        }
    }

    private function rateKey($vendorCustomerId): string
    {
        // Same bucket as core SubscriptionsManager::checkRateLimit.
        return 'fct_stripe_setup_intent_rate_daily_' . md5((string) $vendorCustomerId);
    }

    private function fail($message, $code = 423): array
    {
        return [
            'code' => $code,
            'body' => [
                'status'  => 'failed',
                'message' => $message,
            ],
        ];
    }
}
