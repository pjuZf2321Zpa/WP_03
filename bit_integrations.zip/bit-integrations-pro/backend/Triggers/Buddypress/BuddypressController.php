<?php

namespace BitApps\IntegrationsPro\Triggers\Buddypress;

use BitApps\IntegrationsPro\Config;

final class BuddypressController
{
    public static function info()
    {
        return [
            'name'              => 'BuddyPress',
            'title'             => __('Copy and enter the above webhook URL to your Buddypress webhook setting', 'bit-integrations-pro'),
            'type'              => 'custom_form_submission',
            'is_active'         => BuddypressHelper::isPluginInstalled(),
            'documentation_url' => 'https://bit-integrations.com/wp-docs/trigger/buddypress-integrations/',
            'tutorial_url'      => '#',
            'tasks'             => [
                'action' => 'buddypress/get',
                'method' => 'get',
            ],
            'fetch' => [
                'action' => 'trigger/test',
                'method' => 'post',
            ],
            'fetch_remove' => [
                'action' => 'trigger/test/remove',
                'method' => 'post',
            ],
            'isPro' => true
        ];
    }

    public function getAllTasks()
    {
        if (!BuddypressHelper::isPluginInstalled()) {
            wp_send_json_error(\sprintf(__('%s is not installed or activated', 'bit-integrations-pro'), 'BuddyPress'));
        }

        wp_send_json_success(StaticData::forms());
    }

    public static function handleSetMemberType($user_id, $member_type)
    {
        $helperClass = bit_integrations_get_class('Core\\Util\\Helper');

        if (empty($user_id) || !\is_array($member_type)) {
            return;
        }

        $formData = BuddypressHelper::FormatMemberTypeData($user_id, $member_type);

        if (empty($formData) || !\is_array($formData)) {
            return;
        }

        $helperClass::setTestData(Config::withFreePrefix('bp_set_member_type_test'), array_values($formData), 'primaryKey.value', $formData['primaryKey']['value']);

        return static::flowExecute('bp_set_member_type', $formData);
    }

    public static function handleUserPostToGroupActivity($content, $user_id, $group_id, $activity_id)
    {
        $helperClass = bit_integrations_get_class('Core\\Util\\Helper');

        if (empty($activity_id)) {
            return;
        }

        $formData = BuddypressHelper::formatGroupPostActivityData($content, $user_id, $group_id, $activity_id);

        if (empty($formData) || !\is_array($formData)) {
            return;
        }

        $helperClass::setTestData(Config::withFreePrefix('bp_groups_posted_update_test'), array_values($formData));

        return static::flowExecute('bp_groups_posted_update', $formData);
    }

    public static function handleActivityPostedUpdate($content, $user_id, $activity_id)
    {
        $helperClass = bit_integrations_get_class('Core\\Util\\Helper');

        if (empty($activity_id)) {
            return;
        }

        $formData = BuddypressHelper::formatActivityPostedUpdateData($content, $user_id, $activity_id);

        if (empty($formData) || !\is_array($formData)) {
            return;
        }

        $helperClass::setTestData(Config::withFreePrefix('bp_activity_posted_update_test'), array_values($formData));

        return static::flowExecute('bp_activity_posted_update', $formData);
    }

    public static function flowExecute($triggered_entity_id, $formData)
    {
        $flowClass = bit_integrations_get_class('Flow\\Flow');

        $flows = $flowClass::exists('Buddypress', $triggered_entity_id);

        if (!$flows) {
            return;
        }

        $data = array_column($formData, 'value', 'name');
        $flowClass::execute('Buddypress', $triggered_entity_id, $data, $flows);

        return ['type' => 'success'];
    }
}
