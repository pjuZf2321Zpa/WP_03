<?php

namespace MasterStudy\Lms\Pro\addons\enterprise_courses\Admin\Controllers;

use MasterStudy\Lms\Http\WpResponseFactory;
use MasterStudy\Lms\Pro\addons\enterprise_courses\Admin\Repositories\EnterpriseGroupsRepository;
use MasterStudy\Lms\Validation\Validator;
use WP_REST_Request;
use WP_REST_Response;

final class CreateEnterpriseGroupController {
	public function __invoke( WP_REST_Request $request ): WP_REST_Response {
		$data      = $request->get_json_params();
		$validator = new Validator(
			$data,
			array(
				'title' => 'required|string',
			)
		);

		if ( $validator->fails() ) {
			return WpResponseFactory::validation_failed( $validator->get_errors_array() );
		}

		if ( ! isset( $data['emails'] ) || ! is_array( $data['emails'] ) ) {
			return WpResponseFactory::bad_request( esc_html__( 'Emails payload is invalid.', 'masterstudy-lms-learning-management-system-pro' ) );
		}

		$group = ( new EnterpriseGroupsRepository() )->create( $data );

		if ( is_wp_error( $group ) ) {
			return WpResponseFactory::error( $group->get_error_message() );
		}

		return new WP_REST_Response( array( 'group' => $group ) );
	}
}
