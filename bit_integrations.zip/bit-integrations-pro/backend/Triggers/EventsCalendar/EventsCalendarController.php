<?php

namespace BitApps\IntegrationsPro\Triggers\EventsCalendar;

final class EventsCalendarController
{
    public const EVENT_FILTER_TASKS = [
        'events_calendar-1',
        'events_calendar-2',
        'events_calendar-3',
        'events_calendar-4',
        'events_calendar-7',
        'events_calendar-8',
        'events_calendar-9',
        'events_calendar-10',
        'events_calendar-11',
        'events_calendar-12',
        'events_calendar-13',
    ];

    public const SERIES_FILTER_TASKS = ['events_calendar-20'];

    private static $pluginPath = 'the-events-calendar/the-events-calendar.php';

    public static function info()
    {
        return [
            'name'              => 'The Events Calendar',
            'title'             => __('The Events Calendar', 'bit-integrations-pro'),
            'type'              => 'form',
            'documentation_url' => 'https://bit-integrations.com/wp-docs/trigger/the-events-calendar-integrations-as-a-trigger/',
            'tutorial_url'      => '#',
            'is_active'         => is_plugin_active(self::$pluginPath),
            'list'              => [
                'action' => 'eventscalendar/get',
                'method' => 'get',
            ],
            'fields' => [
                'action' => 'eventscalendar/get/form',
                'method' => 'post',
                'data'   => ['id']
            ],
            'isPro' => true
        ];
    }

    public function getAll()
    {
        if (!is_plugin_active(self::$pluginPath)) {
            // translators: %s: Plugin name
            wp_send_json_error(\sprintf(__('%s is not installed or activated', 'bit-integrations-pro'), 'EventsCalendar'));
        }

        $tasks = [
            ['id' => 'events_calendar-1', 'title' => __('User Attends Event', 'bit-integrations-pro'), 'note' => __('Runs after a user attends an event.', 'bit-integrations-pro')],
            ['id' => 'events_calendar-2', 'title' => __('Attendee Registered for Event', 'bit-integrations-pro'), 'note' => __('Runs after an attendee is registered for an event.', 'bit-integrations-pro')],
            ['id' => 'events_calendar-3', 'title' => __('New Attendee', 'bit-integrations-pro'), 'note' => __('Runs after a user registers for an event.', 'bit-integrations-pro')],
            ['id' => 'events_calendar-4', 'title' => __('Attendee Registered with WooCommerce', 'bit-integrations-pro'), 'note' => __('Runs after a user registers for an event with WooCommerce (use "Ticket" here and not "RSVP").', 'bit-integrations-pro')],
            ['id' => 'events_calendar-5', 'title' => __('Event Created', 'bit-integrations-pro'), 'note' => __('Runs after a new event is saved. A draft event also starts it.', 'bit-integrations-pro')],
            ['id' => 'events_calendar-6', 'title' => __('Event Published', 'bit-integrations-pro'), 'note' => __('Runs after an event is published.', 'bit-integrations-pro')],
            ['id' => 'events_calendar-7', 'title' => __('Event Updated', 'bit-integrations-pro'), 'note' => __('Runs after a published event is updated.', 'bit-integrations-pro')],
            ['id' => 'events_calendar-8', 'title' => __('Event Date Changed', 'bit-integrations-pro'), 'note' => __('Runs after the start date or the end date of a published event changes.', 'bit-integrations-pro')],
            ['id' => 'events_calendar-9', 'title' => __('Event Canceled', 'bit-integrations-pro'), 'note' => __('Runs after the event status of a published event changes to canceled.', 'bit-integrations-pro')],
            ['id' => 'events_calendar-10', 'title' => __('Event Postponed', 'bit-integrations-pro'), 'note' => __('Runs after the event status of a published event changes to postponed.', 'bit-integrations-pro')],
            ['id' => 'events_calendar-11', 'title' => __('Event Moved to Trash', 'bit-integrations-pro'), 'note' => __('Runs after an event is moved to the trash.', 'bit-integrations-pro')],
            ['id' => 'events_calendar-12', 'title' => __('Event Deleted', 'bit-integrations-pro'), 'note' => __('Runs before an event is deleted permanently.', 'bit-integrations-pro')],
            ['id' => 'events_calendar-13', 'title' => __('Event Duplicated', 'bit-integrations-pro'), 'note' => __('Runs after an event is duplicated. This trigger needs The Events Calendar Pro.', 'bit-integrations-pro')],
            ['id' => 'events_calendar-14', 'title' => __('Venue Created', 'bit-integrations-pro'), 'note' => __('Runs after a new venue is published.', 'bit-integrations-pro')],
            ['id' => 'events_calendar-15', 'title' => __('Venue Updated', 'bit-integrations-pro'), 'note' => __('Runs after a published venue is updated.', 'bit-integrations-pro')],
            ['id' => 'events_calendar-16', 'title' => __('Venue Deleted', 'bit-integrations-pro'), 'note' => __('Runs before a venue is deleted permanently.', 'bit-integrations-pro')],
            ['id' => 'events_calendar-17', 'title' => __('Organizer Created', 'bit-integrations-pro'), 'note' => __('Runs after a new organizer is published.', 'bit-integrations-pro')],
            ['id' => 'events_calendar-18', 'title' => __('Organizer Updated', 'bit-integrations-pro'), 'note' => __('Runs after a published organizer is updated.', 'bit-integrations-pro')],
            ['id' => 'events_calendar-19', 'title' => __('Organizer Deleted', 'bit-integrations-pro'), 'note' => __('Runs before an organizer is deleted permanently.', 'bit-integrations-pro')],
            ['id' => 'events_calendar-20', 'title' => __('Event Added to Series', 'bit-integrations-pro'), 'note' => __('Runs after an event is added to a series. This trigger needs The Events Calendar Pro.', 'bit-integrations-pro')],
            ['id' => 'events_calendar-21', 'title' => __('Series Created', 'bit-integrations-pro'), 'note' => __('Runs after a new series is published. This trigger needs The Events Calendar Pro.', 'bit-integrations-pro')],
        ];

        wp_send_json_success($tasks);
    }

    public function get_a_form($data)
    {
        if (!is_plugin_active(self::$pluginPath)) {
            // translators: %s: Plugin name
            wp_send_json_error(\sprintf(__('%s is not installed or activated', 'bit-integrations-pro'), 'EventsCalendar'));
        }

        if (empty($data->id)) {
            wp_send_json_error(__('Task doesn\'t exists', 'bit-integrations-pro'));
        }

        if (\in_array($data->id, self::EVENT_FILTER_TASKS, true)) {
            $events = EventsCalendarHelper::getAllEvents($data);

            if (!empty($events)) {
                $responseData['events'] = $events;
            }
        }

        if (\in_array($data->id, self::SERIES_FILTER_TASKS, true)) {
            $responseData['series'] = EventsCalendarHelper::getAllSeries();
        }

        $responseData['fields'] = self::fields($data);

        wp_send_json_success($responseData);
    }

    public static function fields($data)
    {
        return EventsCalendarHelper::getFields($data);
    }

    public static function handleAttendsEvent($attendeeId, $qr)
    {
        $flowClass = bit_integrations_get_class('Flow\\Flow');

        if (empty($attendeeId)) {
            return;
        }

        if (!\function_exists('tribe_tickets_get_attendees')) {
            return;
        }

        $attendees = tribe_tickets_get_attendees($attendeeId, 'rsvp_order');
        $attendee = [];

        if (isset($attendees[0])) {
            $attendee = $attendees[0];
        }

        if (empty($attendee)) {
            return;
        }

        $eventId = $attendee['event_id'];

        $flows = $flowClass::exists('EventsCalendar', 'events_calendar-1');
        $flows = EventsCalendarHelper::flowFilter($flows, 'selectedEvent', $eventId);

        if (empty($flows) || !$flows) {
            return;
        }

        $data = EventsCalendarHelper::formatAttendsEventData($attendee);

        if (!empty($data)) {
            $flowClass::execute('EventsCalendar', 'events_calendar-1', $data, $flows);
        }
    }

    public static function handleAttendeeRegistered($attendeeId, $postId, $order, $attendeeProductId, $attendeeOrderStatus = null)
    {
        $flowClass = bit_integrations_get_class('Flow\\Flow');

        if (empty($attendeeId)) {
            return;
        }

        if (\is_object($attendeeId)) {
            $attendeeId = $attendeeId->ID;
        }

        if (!\function_exists('tribe_tickets_get_attendees')) {
            return;
        }

        $attendees = tribe_tickets_get_attendees($attendeeId);
        $attendee = [];

        if (isset($attendees[0])) {
            $attendee = $attendees[0];
        }

        if (empty($attendee)) {
            return;
        }

        $eventId = $attendee['event_id'];

        $flows = $flowClass::exists('EventsCalendar', 'events_calendar-2');
        $flows = EventsCalendarHelper::flowFilter($flows, 'selectedEvent', $eventId);

        if (empty($flows) || !$flows) {
            return;
        }

        $data = EventsCalendarHelper::formatAttendsEventData($attendee);

        if (!empty($data)) {
            $flowClass::execute('EventsCalendar', 'events_calendar-2', $data, $flows);
        }
    }

    public static function handleNewAttendee($productId, $orderId)
    {
        $flowClass = bit_integrations_get_class('Flow\\Flow');

        if (empty($productId) || empty($orderId)) {
            return;
        }

        if (!class_exists('Tribe__Tickets__Main')) {
            return;
        }

        $event = tribe_events_get_ticket_event($productId);
        $eventId = $event->ID;

        if (empty($eventId)) {
            return;
        }

        $flows = $flowClass::exists('EventsCalendar', 'events_calendar-3');
        $flows = EventsCalendarHelper::flowFilter($flows, 'selectedEvent', $eventId);

        if (empty($flows) || !$flows) {
            return;
        }

        $data = EventsCalendarHelper::formatNewAttendeeData($event, $orderId);

        if (!empty($data)) {
            $flowClass::execute('EventsCalendar', 'events_calendar-3', $data, $flows);
        }
    }

    public static function handleAttendeeRegisteredWC($attendee, $attendeeData, $ticket, $repository)
    {
        $flowClass = bit_integrations_get_class('Flow\\Flow');

        if (empty($attendeeData) || empty($ticket)) {
            return;
        }

        if (!class_exists('Tribe__Tickets__Main')) {
            return;
        }

        $orderId = $attendeeData['order_id'];
        $productId = $ticket->ID;
        $event = tribe_events_get_ticket_event($productId);
        $eventId = $event->ID;

        if (empty($eventId)) {
            return;
        }

        $flows = $flowClass::exists('EventsCalendar', 'events_calendar-4');
        $flows = EventsCalendarHelper::flowFilter($flows, 'selectedEvent', $eventId);

        if (empty($flows) || !$flows) {
            return;
        }

        $data = EventsCalendarHelper::formatNewAttendeeData($event, $orderId);

        if (!empty($data)) {
            $flowClass::execute('EventsCalendar', 'events_calendar-4', $data, $flows);
        }
    }
}
