<?php

namespace BitApps\IntegrationsPro\Actions\Booknetic\Services;

use BitApps\IntegrationsPro\Core\Util\Hooks;
use BitApps\IntegrationsPro\Triggers\Booknetic\BookneticHelper;
use BookneticApp\Backend\Appointments\Helpers\AppointmentService as BookneticAppointmentService;
use BookneticApp\Backend\Appointments\Helpers\TimeSlotService;
use BookneticApp\Models\Appointment;
use BookneticApp\Models\AppointmentExtra;
use BookneticApp\Models\AppointmentPrice;
use BookneticApp\Models\Customer;
use BookneticApp\Models\Location;
use BookneticApp\Models\Service;
use BookneticApp\Models\ServiceStaff;
use BookneticApp\Models\Staff;
use BookneticApp\Providers\Common\PaymentGatewayService;
use BookneticApp\Providers\Helpers\Helper;

final class AppointmentService extends BaseService
{
    public const PAYMENT_STATUSES = ['pending', 'paid', 'canceled', 'not_paid'];

    public function createAppointment(): array
    {
        $error = $this->validate([
            'location_id' => [__('Location', 'bit-integrations-pro'), 'integer'],
            'service_id'  => [__('Service', 'bit-integrations-pro'), 'integer'],
            'staff_id'    => [__('Staff', 'bit-integrations-pro'), 'integer'],
            'customer_id' => [__('Customer', 'bit-integrations-pro'), 'integer'],
            'status'      => [__('Status', 'bit-integrations-pro')],
            'starts_at'   => [__('Starts At', 'bit-integrations-pro')],
        ]);

        if ($error !== null) {
            return $error;
        }

        $locationId = $this->int('location_id');
        $serviceId = $this->int('service_id');
        $staffId = $this->int('staff_id');
        $customerId = $this->int('customer_id');
        $service = Service::query()->get($serviceId);

        if (
            empty($service)
            || empty(Location::query()->get($locationId))
            || empty(Staff::query()->get($staffId))
            || empty(Customer::query()->get($customerId))
        ) {
            return $this->error(__('A selected location, service, staff member or customer does not exist. Select a different one.', 'bit-integrations-pro'));
        }

        $status = $this->string('status');

        if (!isset(Helper::getAppointmentStatuses()[$status])) {
            return $this->error(__('The appointment status is not valid. Select a status from the list.', 'bit-integrations-pro'));
        }

        $paymentMethod = $this->string('payment_method') ?: 'local';
        $paymentStatus = $this->string('payment_status') ?: 'not_paid';

        if (!\in_array($paymentMethod, PaymentGatewayService::getInstalledGatewayNames(), true)) {
            return $this->error(__('The payment method is not installed in Booknetic. Select a different payment method.', 'bit-integrations-pro'));
        }

        if (!\in_array($paymentStatus, self::PAYMENT_STATUSES, true)) {
            return $this->error(__('The payment status is not valid. Use pending, paid, canceled or not_paid.', 'bit-integrations-pro'));
        }

        $weight = max(1, $this->int('weight') ?: 1);

        if ($weight > max(1, (int) $service->max_capacity)) {
            return $this->error(__('The number of customers is more than the service capacity. Enter a smaller number.', 'bit-integrations-pro'));
        }

        $scheduleError = $this->scheduleError($locationId, $service, $staffId);

        if ($scheduleError !== null) {
            return $this->error($scheduleError);
        }

        $startsAt = $this->parseTimestamp($this->string('starts_at'));

        if ($startsAt <= 0) {
            return $this->error(__('The date and time are not valid. Enter a date and time such as 2026-01-31 14:30.', 'bit-integrations-pro'));
        }

        if (!$this->isBookable($startsAt, $locationId, $service, $staffId, 0, $weight)) {
            return $this->error(__('The staff member is not available at this time. Select a different time.', 'bit-integrations-pro'));
        }

        $data = [
            'location_id'     => $locationId,
            'service_id'      => $serviceId,
            'staff_id'        => $staffId,
            'customer_id'     => $customerId,
            'status'          => $status,
            'weight'          => $weight,
            'payment_id'      => md5(uniqid('', true)),
            'payment_method'  => $paymentMethod,
            'payment_status'  => $paymentStatus,
            'paid_amount'     => max(0, (float) $this->string('paid_amount')),
            'note'            => $this->string('note'),
            'locale'          => get_locale(),
            'client_timezone' => wp_timezone_string(),
            'created_at'      => time(),
        ] + self::scheduleColumns($startsAt, $service, 0);

        if (!Appointment::query()->insert($data)) {
            return $this->error(__('Booknetic did not create the appointment. Try again.', 'bit-integrations-pro'));
        }

        $appointmentId = Appointment::lastId();
        $this->saveServicePrice($appointmentId, $service, $staffId, $weight);

        Hooks::run('bkntc_payment_confirmed', $appointmentId);

        return $this->success(BookneticHelper::getAppointmentData($appointmentId));
    }

    public function updateAppointment(): array
    {
        $error = $this->validate(['appointment_id' => [__('Appointment ID', 'bit-integrations-pro'), 'integer']]);

        if ($error !== null) {
            return $error;
        }

        $appointmentId = $this->int('appointment_id');
        $appointment = Appointment::query()->get($appointmentId);

        if (empty($appointment)) {
            return $this->error(__('The appointment does not exist. Select a different appointment.', 'bit-integrations-pro'));
        }

        $data = $this->optionalTextFields(['status' => 'status', 'note' => 'note'])
            + $this->optionalIntFields(['location_id', 'service_id', 'staff_id', 'customer_id', 'weight']);

        $relatedModels = [
            'location_id' => Location::class,
            'service_id'  => Service::class,
            'staff_id'    => Staff::class,
            'customer_id' => Customer::class,
        ];

        foreach ($relatedModels as $field => $modelClass) {
            if (isset($data[$field]) && empty($modelClass::query()->get($data[$field]))) {
                return $this->error(__('A selected location, service, staff member or customer does not exist. Select a different one.', 'bit-integrations-pro'));
            }
        }

        if (isset($data['status']) && !isset(Helper::getAppointmentStatuses()[$data['status']])) {
            return $this->error(__('The appointment status is not valid. Select a status from the list.', 'bit-integrations-pro'));
        }

        $locationId = (int) ($data['location_id'] ?? $appointment->location_id);
        $staffId = (int) ($data['staff_id'] ?? $appointment->staff_id);
        $weight = max(1, (int) ($data['weight'] ?? $appointment->weight));
        $service = Service::query()->get((int) ($data['service_id'] ?? $appointment->service_id));

        if (empty($service)) {
            return $this->error(__('The service does not exist. Select a different service.', 'bit-integrations-pro'));
        }

        if ($weight > max(1, (int) $service->max_capacity)) {
            return $this->error(__('The number of customers is more than the service capacity. Enter a smaller number.', 'bit-integrations-pro'));
        }

        $scheduleChanged = isset($data['location_id']) || isset($data['service_id']) || isset($data['staff_id']);

        if ($scheduleChanged) {
            $scheduleError = $this->scheduleError($locationId, $service, $staffId);

            if ($scheduleError !== null) {
                return $this->error($scheduleError);
            }
        }

        $startsAt = (int) $appointment->starts_at;

        if ($this->has('starts_at')) {
            $startsAt = $this->parseTimestamp($this->string('starts_at'));

            if ($startsAt <= 0) {
                return $this->error(__('The date and time are not valid. Enter a date and time such as 2026-01-31 14:30.', 'bit-integrations-pro'));
            }

            $scheduleChanged = true;
        }

        if ($scheduleChanged || isset($data['weight'])) {
            if (!$this->isBookable($startsAt, $locationId, $service, $staffId, $appointmentId, $weight)) {
                return $this->error(__('The staff member is not available at this time. Select a different time.', 'bit-integrations-pro'));
            }
        }

        if ($scheduleChanged) {
            $data += self::scheduleColumns($startsAt, $service, self::extrasDuration($appointmentId));
        }

        if (empty($data)) {
            return $this->error(__('No appointment field is set. Map one or more fields to update.', 'bit-integrations-pro'));
        }

        Hooks::run('bkntc_appointment_before_mutation', $appointmentId);
        Appointment::query()->where('id', $appointmentId)->update($data);

        if (isset($data['service_id']) || isset($data['staff_id']) || isset($data['weight'])) {
            $this->saveServicePrice($appointmentId, $service, $staffId, $weight);
        }

        Hooks::run('bkntc_appointment_after_mutation', $appointmentId);

        return $this->success(BookneticHelper::getAppointmentData($appointmentId));
    }

    public function deleteAppointment(): array
    {
        $error = $this->validate(['appointment_id' => [__('Appointment ID', 'bit-integrations-pro'), 'integer']]);

        if ($error !== null) {
            return $error;
        }

        $appointmentId = $this->int('appointment_id');

        if (empty(Appointment::query()->get($appointmentId))) {
            return $this->error(__('The appointment does not exist. Select a different appointment.', 'bit-integrations-pro'));
        }

        BookneticAppointmentService::deleteAppointment($appointmentId);

        return $this->success(['appointment_id' => $appointmentId], __('The appointment is deleted.', 'bit-integrations-pro'));
    }

    public function rescheduleAppointment(): array
    {
        $error = $this->validate([
            'appointment_id' => [__('Appointment ID', 'bit-integrations-pro'), 'integer'],
            'date'           => [__('Date', 'bit-integrations-pro')],
            'time'           => [__('Time', 'bit-integrations-pro')],
        ]);

        if ($error !== null) {
            return $error;
        }

        $appointmentId = $this->int('appointment_id');
        $appointment = Appointment::query()->get($appointmentId);

        if (empty($appointment)) {
            return $this->error(__('The appointment does not exist. Select a different appointment.', 'bit-integrations-pro'));
        }

        $staffId = $this->int('staff_id');

        if ($staffId > 0 && empty(Staff::query()->get($staffId))) {
            return $this->error(__('The staff member does not exist. Select a different staff member.', 'bit-integrations-pro'));
        }

        $startsAt = $this->parseTimestamp($this->string('date') . ' ' . $this->string('time'));

        if ($startsAt <= 0) {
            return $this->error(__('The date or time is not valid. Enter a date such as 2026-01-31 and a time such as 14:30.', 'bit-integrations-pro'));
        }

        $service = Service::query()->get((int) $appointment->service_id);
        $targetStaffId = $staffId > 0 ? $staffId : (int) $appointment->staff_id;

        if (empty($service) || !$this->isBookable($startsAt, (int) $appointment->location_id, $service, $targetStaffId, $appointmentId, max(1, (int) $appointment->weight))) {
            return $this->error(__('The staff member is not available at this time. Select a different time.', 'bit-integrations-pro'));
        }

        BookneticAppointmentService::reschedule(
            $appointmentId,
            $this->string('date'),
            $this->string('time'),
            true,
            !$this->has('reset_status') || $this->toBool($this->value('reset_status')),
            $staffId > 0 ? $staffId : false
        );

        return $this->success(BookneticHelper::getAppointmentData($appointmentId));
    }

    public function changeAppointmentStatus(): array
    {
        $error = $this->validate([
            'appointment_id' => [__('Appointment ID', 'bit-integrations-pro'), 'integer'],
            'status'         => [__('Status', 'bit-integrations-pro')],
        ]);

        if ($error !== null) {
            return $error;
        }

        $status = $this->string('status');

        if (!isset(Helper::getAppointmentStatuses()[$status])) {
            return $this->error(__('The appointment status is not valid. Select a status from the list.', 'bit-integrations-pro'));
        }

        $appointmentId = $this->int('appointment_id');

        if (empty(Appointment::query()->get($appointmentId))) {
            return $this->error(__('The appointment does not exist. Select a different appointment.', 'bit-integrations-pro'));
        }

        BookneticAppointmentService::setStatus($appointmentId, $status);

        return $this->success(BookneticHelper::getAppointmentData($appointmentId));
    }

    private function scheduleError(int $locationId, $service, int $staffId): ?string
    {
        if (empty(Staff::query()->where('id', $staffId)->whereFindInSet('locations', $locationId)->fetch())) {
            return __('The staff member does not work at this location. Select a different staff member or location.', 'bit-integrations-pro');
        }

        if (empty(self::serviceStaff((int) $service->id, $staffId))) {
            return __('The staff member does not give this service. Select a different staff member or service.', 'bit-integrations-pro');
        }

        return null;
    }

    private function isBookable(int $startsAt, int $locationId, $service, int $staffId, int $excludeAppointmentId = 0, int $weight = 1): bool
    {
        $timezone = wp_timezone();
        $timeslot = new TimeSlotService(wp_date('Y-m-d', $startsAt, $timezone), wp_date('H:i', $startsAt, $timezone));
        $timeslot->setStaffId($staffId)
            ->setServiceInf($service)
            ->setServiceExtras([])
            ->setLocationId($locationId)
            ->setExcludeAppointmentId($excludeAppointmentId)
            ->setTotalCustomerCount($weight)
            ->setCalledFromBackEnd(true)
            ->setShowExistingTimeSlots(true);

        return $timeslot->isBookable();
    }

    private function saveServicePrice($appointmentId, $service, int $staffId, int $weight): void
    {
        $serviceStaff = self::serviceStaff((int) $service->id, $staffId);
        $price = !empty($serviceStaff) && (float) $serviceStaff->price != -1 ? $serviceStaff->price : $service->price;
        $priceData = [
            'price'                => abs((float) $price * $weight),
            'negative_or_positive' => 1,
        ];
        $priceQuery = AppointmentPrice::query()
            ->where('appointment_id', $appointmentId)
            ->where('unique_key', 'service_price');

        if ($priceQuery->count() > 0) {
            AppointmentPrice::query()
                ->where('appointment_id', $appointmentId)
                ->where('unique_key', 'service_price')
                ->update($priceData);

            return;
        }

        AppointmentPrice::query()->insert(
            [
                'appointment_id' => $appointmentId,
                'unique_key'     => 'service_price',
            ] + $priceData
        );
    }

    private static function serviceStaff(int $serviceId, int $staffId)
    {
        return ServiceStaff::query()->where('service_id', $serviceId)->where('staff_id', $staffId)->fetch();
    }

    private static function extrasDuration(int $appointmentId): int
    {
        $duration = 0;

        foreach (AppointmentExtra::query()->where('appointment_id', $appointmentId)->fetchAll() as $extra) {
            $duration += (int) $extra->duration * (int) $extra->quantity;
        }

        return $duration;
    }

    private static function scheduleColumns(int $startsAt, $service, int $extrasDuration): array
    {
        $duration = (max(1, (int) $service->duration) + $extrasDuration) * 60;

        return [
            'starts_at' => $startsAt,
            'ends_at'   => $startsAt + $duration,
            'busy_from' => $startsAt - ((int) $service->buffer_before * 60),
            'busy_to'   => $startsAt + $duration + ((int) $service->buffer_after * 60),
        ];
    }
}
