<?php

namespace FluentCartPro\App\Modules\Reports\Services;

use FluentCart\App\App;
use FluentCart\App\CPT\FluentProducts;
use FluentCart\App\Helpers\Status;
use FluentCart\App\Modules\MultiCurrency\Services\ReportCurrency;
use FluentCart\App\Services\DateTime\DateTime;
use FluentCart\App\Services\Report\ProductReportService;
use FluentCart\App\Services\Report\ReportHelper;
use FluentCart\App\Services\Report\SubscriptionReportService;
use FluentCart\Framework\Support\Arr;

/**
 * The Pro parts of Reports → Products: the product detail drawer and Product Compare.
 * Extends core's service for the shared line and variation-share queries.
 */
class ProductInsightsService extends ProductReportService
{
    // Compare holds this many picks; the chart stays readable
    public const MAX_COMPARISON_ITEMS = 6;

    /**
     * Product Compare: each item is a whole product ("p:ID") or one variation ("v:ID"), in pick order. Money is read
     * the getProductSales() way in one pass over every item's lines, then shared out per item (a variation picked
     * alone and its product both count its lines). Orders and customers are counted once per item.
     * Subscriptions and customer overlap have their own reads, so no single request runs every query.
     *
     * @param string[] $keys item keys; repeats and unknown kinds are dropped, at most MAX_COMPARISON_ITEMS kept
     */
    public function getProductComparison(array $params, array $keys): array
    {
        $items = $this->comparisonItems($keys);
        $chartParams = $this->clampParamsToToday($params);
        $group = ReportHelper::processGroup($chartParams['startDate'], $chartParams['endDate'], $chartParams['groupKey']);
        $buckets = array_map('strval', array_keys($this->getPeriodRange($chartParams['startDate'], $chartParams['endDate'], $group['key'])));

        $result = ['items' => [], 'buckets' => $buckets, 'group_key' => $group['key'], 'item_limit' => self::MAX_COMPARISON_ITEMS];
        if (!$items) {
            return $result;
        }

        $current = $this->comparisonPeriod($params, $items, $group);
        $previous = !empty($params['comparePeriod'])
            ? $this->comparisonPeriod(array_merge($params, ['startDate' => $params['comparePeriod'][0], 'endDate' => $params['comparePeriod'][1]]), $items, null)
            : null;

        foreach ($items as $index => $item) {
            $chart = [];
            foreach ($buckets as $bucket) {
                $chart[] = array_merge(['group' => $bucket], $current['charts'][$index][$bucket] ?? self::emptyComparisonPoint());
            }
            $result['items'][] = array_merge($item, [
                'summary'  => $current['summaries'][$index],
                'previous' => $previous ? $previous['summaries'][$index] : null,
                'chart'    => $chart,
            ]);
        }

        return $result;
    }

    /**
     * Product Compare: each item's subscriptions (live, MRR, renewals in the range). Item keys as getProductComparison().
     */
    public function getProductComparisonSubscriptions(array $params, array $keys): array
    {
        $items = $this->comparisonItems($keys);
        if (!$items) {
            return ['items' => []];
        }

        $subscriptions = SubscriptionReportService::make();
        $scopes = array_map([$this, 'subscriptionScope'], $items);
        $health = $subscriptions->getHealthByScopes($params, $scopes);

        $result = ['items' => []];
        foreach ($items as $index => $item) {
            // With the item's title, so the card can show it when the main read fails
            $result['items'][] = array_merge($item, [
                'subscriptions' => $subscriptions->productSubscriptionSummary(
                    array_merge($params, ['variationIds' => $scopes[$index]]), $health[$index]
                ),
            ]);
        }

        return $result;
    }

    /**
     * Product Compare: customer overlap between the items, by index into the returned items. Item keys as
     * getProductComparison().
     */
    public function getProductComparisonOverlap(array $params, array $keys): array
    {
        $items = $this->comparisonItems($keys);

        return ['items' => $items, 'overlap' => $this->comparisonOverlap($params, $items)];
    }

    /**
     * Product Compare "since launch": each item's net sales and units by month from its launch (see below),
     * up to its last month with a sale (at most 60), in store months. Item keys as getProductComparison().
     */
    public function getProductComparisonLaunch(array $params, array $keys): array
    {
        $items = $this->comparisonItems($keys);
        $result = ['items' => []];
        foreach ($items as $item) {
            $column = $item['type'] === 'product' ? 'oi.post_id' : 'oi.object_id';
            $first = $this->comparisonLines($params, $item)->min('o.created_at');
            if (!$first) {
                $result['items'][] = array_merge($item, ['launched_at' => null, 'months' => []]);
                continue;
            }
            // Scoped to the item's variants, so the per-order shares read only its orders, not the store's history
            $span = array_merge($params, [
                'startDate'    => new DateTime($first, new \DateTimeZone('UTC')),
                'endDate'      => DateTime::gmtNow(),
                'variationIds' => $item['type'] === 'variation' ? [$item['id']] : array_values(array_unique(array_merge(
                    $this->subscriptionScope($item),
                    // Variants sold under the product, deleted ones included
                    array_map('intval', App::db()->table('fct_order_items')->where('post_id', $item['id'])->distinct()->pluck('object_id')->toArray())
                ))),
            ]);
            [$orders, $orderShares, $share] = $this->variationShareParts($span);
            $month = 'DATE_FORMAT(' . ReportHelper::storeTimeSql('o.created_at', $span['startDate'], $span['endDate']) . ", '%Y-%m')";
            $rows = $orders()->joinSub($orderShares, 'ol', 'ol.order_id', '=', 'o.id')
                ->where($column, $item['id'])
                ->selectRaw("{$month} AS month, SUM(" . self::netShare($share) . ") AS net,
                    SUM(CASE WHEN oi.payment_type NOT IN ('signup_fee', 'fee') THEN oi.quantity ELSE 0 END) AS units")
                ->groupByRaw($month)
                ->orderByRaw($month)
                ->get()
                ->keyBy('month');

            // The launch starts the first three months running with net sales; a lone early sale (a test, a free
            // bundle line) does not. A product younger than that launches with its first paid month
            $paid = [];
            foreach ($rows as $key => $row) {
                if ((int) $row->net > 0) {
                    $paid[(string) $key] = true;
                }
            }
            $launched = null;
            foreach (array_keys($paid) as $key) {
                $month = new DateTime($key . '-01 00:00:00', wp_timezone());
                $next = (clone $month)->modify('first day of next month')->format('Y-m');
                $after = (clone $month)->modify('first day of +2 months')->format('Y-m');
                if (isset($paid[$next], $paid[$after])) {
                    $launched = $key;
                    break;
                }
            }
            $launched = $launched ?: (string) (array_key_first($paid) ?? '');
            if (!$launched) {
                $result['items'][] = array_merge($item, ['launched_at' => null, 'months' => []]);
                continue;
            }

            $months = [];
            $cursor = new DateTime($launched . '-01 00:00:00', wp_timezone());
            $last = $rows->keys()->last();
            while ($cursor->format('Y-m') <= $last && count($months) < 60) {
                $key = $cursor->format('Y-m');
                $row = $rows->get($key);
                $months[] = ['month' => $key, 'net' => $row ? (int) $row->net : 0, 'units' => $row ? (int) $row->units : 0];
                $cursor->modify('first day of next month');
            }
            $result['items'][] = array_merge($item, [
                'launched_at' => $launched . '-01 00:00:00',
                'months'      => $months,
            ]);
        }

        return $result;
    }

    /**
     * Paid orders holding the item's lines under the report's currency and statuses, any date
     */
    private function comparisonLines(array $params, array $item)
    {
        $column = $item['type'] === 'product' ? 'oi.post_id' : 'oi.object_id';

        return ReportCurrency::joinOrderItems(ReportCurrency::ordersTable($params), $params)
            ->where('o.total_paid', '>', 0)
            ->when(!empty($params['paymentStatus']), fn($q) => $q->whereIn('o.payment_status', $params['paymentStatus']))
            ->when(!empty($params['orderStatus']), fn($q) => $q->whereNotIn('o.status', $params['orderStatus']))
            ->when(!empty($params['currency']) && $params['currency'] !== ReportCurrency::ALL, fn($q) => $q->where('o.currency', $params['currency']))
            ->where($column, $item['id']);
    }

    private function subscriptionScope(array $item): array
    {
        if ($item['type'] === 'variation') {
            return [$item['id']];
        }

        return array_values(array_unique(array_merge(
            array_map('intval', App::db()->table('fct_product_variations')->where('post_id', $item['id'])->pluck('id')->toArray()),
            array_map('intval', App::db()->table('fct_subscriptions')->where('product_id', $item['id'])->distinct()->pluck('variation_id')->toArray())
        ))) ?: [0];
    }

    /**
     * For each ordered pair of items: the first item's customers in the range, how many have ever bought the second
     * (any currency, any date), and how many of those bought the second first. Renewals are no purchase here.
     */
    private function comparisonOverlap(array $params, array $items): array
    {
        if (count($items) < 2) {
            return [];
        }

        $inRange = [];
        [$orders] = $this->variationShareParts($params);
        foreach ($items as $index => $item) {
            $column = $item['type'] === 'product' ? 'oi.post_id' : 'oi.object_id';
            // Customers are paid-only; a buyer of free orders alone is not one
            $inRange[$index] = array_flip(array_map('intval', $orders()->where($column, $item['id'])->whereNotNull('o.customer_id')->where('o.total_paid', '>', 0)
                ->distinct()->pluck('o.customer_id')->toArray()));
        }
        // First purchases only for the customers who bought one of the items in the range: one read per item, joined
        // to those buyers, not a lookup per batch of customers
        $buyers = $orders()
            ->where(function ($q) use ($items) {
                foreach ($items as $item) {
                    $q->orWhere($item['type'] === 'product' ? 'oi.post_id' : 'oi.object_id', $item['id']);
                }
            })
            ->whereNotNull('o.customer_id')
            ->where('o.total_paid', '>', 0)
            ->distinct()
            ->select('o.customer_id');

        $firstBought = [];
        foreach ($items as $index => $item) {
            $firstBought[$index] = [];
            foreach (App::db()->table('fct_orders as f')
                ->join('fct_order_items as fi', 'fi.order_id', '=', 'f.id')
                ->joinSub($buyers, 'rb', 'rb.customer_id', '=', 'f.customer_id')
                ->where('f.total_paid', '>', 0)
                ->where('f.type', '<>', Status::ORDER_TYPE_RENEWAL)
                ->when(!empty($params['paymentStatus']), fn($q) => $q->whereIn('f.payment_status', $params['paymentStatus']))
                ->when(!empty($params['orderStatus']), fn($q) => $q->whereNotIn('f.status', $params['orderStatus']))
                ->where($item['type'] === 'product' ? 'fi.post_id' : 'fi.object_id', $item['id'])
                ->selectRaw('f.customer_id, MIN(f.created_at) AS first_at')
                ->groupBy('f.customer_id')
                ->get() as $row) {
                $firstBought[$index][(int) $row->customer_id] = (string) $row->first_at;
            }
        }

        $pairs = [];
        foreach ($items as $from => $unused) {
            foreach ($items as $to => $unusedToo) {
                if ($from === $to) {
                    continue;
                }
                $both = 0;
                $toFirst = 0;
                foreach ($inRange[$from] as $customer => $unusedValue) {
                    if (!isset($firstBought[$to][$customer])) {
                        continue;
                    }
                    $both++;
                    if (isset($firstBought[$from][$customer]) && $firstBought[$to][$customer] < $firstBought[$from][$customer]) {
                        $toFirst++;
                    }
                }
                $pairs[] = ['from' => $from, 'to' => $to, 'customers' => count($inRange[$from]), 'both' => $both, 'to_first' => $toFirst];
            }
        }

        return $pairs;
    }

    private function comparisonItems(array $keys): array
    {
        $picked = [];
        foreach ($keys as $key) {
            if (!preg_match('/^([pv]):(\d+)$/', (string) $key, $match) || isset($picked[$key]) || (int) $match[2] === 0) {
                continue;
            }
            $picked[$key] = ['key' => (string) $key, 'type' => $match[1] === 'p' ? 'product' : 'variation', 'id' => (int) $match[2]];
            if (count($picked) >= self::MAX_COMPARISON_ITEMS) {
                break;
            }
        }
        $items = array_values($picked);

        $productIds = array_column(array_filter($items, fn($item) => $item['type'] === 'product'), 'id');
        $variationIds = array_column(array_filter($items, fn($item) => $item['type'] === 'variation'), 'id');
        $variations = [];
        if ($variationIds) {
            foreach (App::db()->table('fct_product_variations as pv')
                ->leftJoin('posts as p', 'p.ID', '=', 'pv.post_id')
                ->whereIn('pv.id', $variationIds)
                ->select(['pv.id', 'pv.post_id', 'pv.variation_title', 'p.post_title'])
                ->get() as $row) {
                $variations[(int) $row->id] = $row;
            }
        }
        // Products only: a key must not reveal the title of any other post
        $products = $productIds ? App::db()->table('posts')->whereIn('ID', $productIds)->where('post_type', FluentProducts::CPT_NAME)
            ->pluck('post_title', 'ID')->toArray() : [];

        foreach ($items as &$item) {
            if ($item['type'] === 'product') {
                $item['product_id'] = $item['id'];
                $item['title'] = (string) Arr::get($products, $item['id'], '#' . $item['id']);
                $item['subtitle'] = '';
            } else {
                $variation = $variations[$item['id']] ?? null;
                $item['product_id'] = $variation ? (int) $variation->post_id : 0;
                $item['title'] = $variation ? (string) $variation->variation_title : '#' . $item['id'];
                $item['subtitle'] = $variation ? (string) $variation->post_title : '';
            }
        }
        unset($item);

        return $items;
    }

    /**
     * One period's figures per item. With $group, also each item's points by period.
     *
     * @return array{summaries: array<int, array>, charts: array<int, array<string, array>>}
     */
    private function comparisonPeriod(array $params, array $items, $group): array
    {
        [$orders, $orderShares, $share] = $this->variationShareParts($params);
        $net = self::netShare($share);
        $type = ReportHelper::saleTypeSql();
        $renewal = Status::ORDER_TYPE_RENEWAL;
        $productIds = array_column(array_filter($items, fn($item) => $item['type'] === 'product'), 'id');
        $variationIds = array_column(array_filter($items, fn($item) => $item['type'] === 'variation'), 'id');

        $scope = function ($query) use ($productIds, $variationIds) {
            return $query->where(function ($q) use ($productIds, $variationIds) {
                $q->when($productIds, fn($q) => $q->orWhereIn('oi.post_id', $productIds))
                    ->when($variationIds, fn($q) => $q->orWhereIn('oi.object_id', $variationIds));
            });
        };
        $byPeriod = $group ? "{$group['by']} AS period, " : '';

        // One money read for every item's lines
        $rows = $scope($orders()->joinSub($orderShares, 'ol', 'ol.order_id', '=', 'o.id'))
            ->selectRaw("{$byPeriod}oi.post_id AS product_id, oi.object_id AS variation_id,
                SUM({$share['paid']}) AS gross, SUM({$share['refund']}) AS refunds, SUM({$net}) AS net,
                SUM(CASE WHEN o.type <> '{$renewal}' THEN {$net} ELSE 0 END) AS new_net,
                SUM(CASE WHEN o.type <> '{$renewal}' THEN 0 WHEN {$type} = 'renewal' THEN {$net} ELSE 0 END) AS renewal_net,
                SUM(CASE WHEN o.type <> '{$renewal}' THEN 0 WHEN {$type} = 'installment_payment' THEN {$net} ELSE 0 END) AS installment_net,
                SUM(CASE WHEN oi.payment_type NOT IN ('signup_fee', 'fee') THEN oi.quantity ELSE 0 END) AS units")
            ->when($group, fn($q) => $q->groupByRaw("{$group['by']}, oi.post_id, oi.object_id"), fn($q) => $q->groupBy('oi.post_id', 'oi.object_id'))
            ->get();

        $money = ['gross', 'refunds', 'net', 'new_net', 'renewal_net', 'installment_net', 'units'];
        $summaries = [];
        $charts = [];
        // A $0 order counts as an order, but customers are paid-only, as on the Customers report
        $counts = 'COUNT(DISTINCT o.id) AS orders, COUNT(DISTINCT CASE WHEN o.total_paid > 0 THEN o.customer_id END) AS customers,
            COUNT(DISTINCT CASE WHEN o.total_paid > 0 AND ' . ReportHelper::firstPurchaseSql($params) . ' THEN o.customer_id END) AS new_customers';

        foreach ($items as $index => $item) {
            $summary = array_fill_keys($money, 0);
            foreach ($rows as $row) {
                $matches = $item['type'] === 'product' ? (int) $row->product_id === $item['id'] : (int) $row->variation_id === $item['id'];
                if (!$matches) {
                    continue;
                }
                foreach ($money as $key) {
                    $summary[$key] += (int) $row->{$key};
                }
                if ($group) {
                    $point = &$charts[$index][(string) $row->period];
                    $point = $point ?? self::emptyComparisonPoint();
                    foreach (['net', 'units', 'new_net', 'renewal_net', 'installment_net'] as $key) {
                        $point[$key] += (int) $row->{$key};
                    }
                    unset($point);
                }
            }

            // Orders and customers once per item, not summed over its variants
            $itemLines = function () use ($orders, $item) {
                $column = $item['type'] === 'product' ? 'oi.post_id' : 'oi.object_id';

                return $orders()->where($column, $item['id']);
            };
            $totals = $itemLines()->selectRaw($counts)->first();
            if ($group) {
                foreach ($itemLines()->selectRaw("{$group['by']} AS period, {$counts}")->groupByRaw($group['by'])->get() as $row) {
                    $point = &$charts[$index][(string) $row->period];
                    $point = $point ?? self::emptyComparisonPoint();
                    $point['orders'] = (int) $row->orders;
                    $point['new_customers'] = (int) $row->new_customers;
                    unset($point);
                }
            }

            $summary['orders'] = $totals ? (int) $totals->orders : 0;
            $summary['customers'] = $totals ? (int) $totals->customers : 0;
            $summary['new_customers'] = $totals ? (int) $totals->new_customers : 0;
            $summary['refund_rate'] = self::refundRate($summary['refunds'], $summary['gross']);
            $summary['average_order'] = $summary['orders'] ? (int) round($summary['net'] / $summary['orders']) : 0;
            $summary['average_price'] = $summary['units'] ? (int) round($summary['net'] / $summary['units']) : 0;
            $summaries[$index] = $summary;
        }

        return ['summaries' => $summaries, 'charts' => $charts];
    }

    private static function emptyComparisonPoint(): array
    {
        return ['net' => 0, 'units' => 0, 'orders' => 0, 'new_customers' => 0, 'new_net' => 0, 'renewal_net' => 0, 'installment_net' => 0];
    }

    /**
     * The Products page detail of one product: its subscriptions (live, MRR, renewal rate in the range) and the
     * products bought in the same orders. Renewals are left out of "bought together": they repeat one plan.
     *
     * @param array $params report params; variationIds = the product's variants (its catalog variants when empty)
     */
    public function getProductDetail(array $params, int $productId): array
    {
        $variationIds = array_values(array_filter(array_map('intval', (array) Arr::get($params, 'variationIds', []))));
        if (!$variationIds) {
            $variationIds = array_map('intval', App::db()->table('fct_product_variations')->where('post_id', $productId)->pluck('id')->toArray());
        }

        $withProduct = function () use ($params, $productId, $variationIds) {
            $query = ReportCurrency::joinOrderItems(ReportCurrency::ordersTable($params), $params)
                ->where('o.total_paid', '>', 0)
                ->where('o.type', '<>', Status::ORDER_TYPE_RENEWAL)
                ->where('oi.post_id', $productId)
                ->when($variationIds, fn($q) => $q->whereIn('oi.object_id', $variationIds));

            return $this->applyFilters($query, array_merge($params, ['variationIds' => null]));
        };

        $orders = (int) $withProduct()->selectRaw('COUNT(DISTINCT o.id) AS n')->value('n');

        $together = $orders ? $withProduct()
            ->join('fct_order_items as ti', 'ti.order_id', '=', 'o.id')
            ->where('ti.post_id', '>', 0)
            ->where('ti.post_id', '<>', $productId)
            ->selectRaw('ti.post_id AS product_id, MAX(ti.post_title) AS product_title, COUNT(DISTINCT o.id) AS orders')
            ->groupBy('ti.post_id')
            ->orderByRaw('orders DESC, ti.post_id ASC')
            ->limit(5)
            ->get() : [];

        $titles = [];
        $ids = array_map(function ($row) {
            return (int) $row->product_id;
        }, is_array($together) ? $together : $together->all());
        if ($ids) {
            $titles = App::db()->table('posts')->whereIn('ID', $ids)->pluck('post_title', 'ID')->toArray();
        }

        $boughtTogether = [];
        foreach ($together as $row) {
            $boughtTogether[] = [
                'product_id'    => (int) $row->product_id,
                'product_title' => (string) Arr::get($titles, (int) $row->product_id, $row->product_title),
                'orders'        => (int) $row->orders,
                'share'         => round((int) $row->orders / $orders * 100, 1),
            ];
        }

        // Subscriptions span every variant of the product, sold in the range or not (a yearly plan renews once a year)
        $subscriptionScope = array_values(array_unique(array_merge(
            $variationIds,
            array_map('intval', App::db()->table('fct_product_variations')->where('post_id', $productId)->pluck('id')->toArray()),
            array_map('intval', App::db()->table('fct_subscriptions')->where('product_id', $productId)->distinct()->pluck('variation_id')->toArray())
        )));

        return [
            'orders'          => $orders,
            'bought_together' => $boughtTogether,
            'subscriptions'   => $productId && $subscriptionScope
                ? SubscriptionReportService::make()->productSubscriptionSummary(array_merge($params, ['variationIds' => $subscriptionScope]))
                : null,
        ];
    }

    /**
     * A line's share of its order's net sales; a core older than the shared net sales has only paid, refund and tax
     */
    private static function netShare(array $share): string
    {
        return $share['net'] ?? "({$share['paid']} - {$share['refund']} - {$share['tax']})";
    }
}
