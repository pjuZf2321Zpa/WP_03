<?php

namespace BitApps\IntegrationsPro\Actions\TheEventsCalendar\Services;

if (!\defined('ABSPATH')) {
    exit;
}

abstract class BaseService
{
    protected $fields;

    public function __construct($fieldData = [], $settings = [])
    {
        $this->fields = array_merge((array) $settings, (array) $fieldData);
    }

    protected function getValue(string $key)
    {
        return $this->fields[$key] ?? null;
    }

    protected function getString(string $key): string
    {
        $value = $this->getValue($key);

        return \is_scalar($value) ? trim((string) $value) : '';
    }

    protected function getInteger(string $key): ?int
    {
        $value = $this->getString($key);

        return $value === '' ? null : (int) $value;
    }

    protected function hasValue(string $key): bool
    {
        return $this->getString($key) !== '';
    }

    protected function getBoolean(string $key): ?bool
    {
        if (!$this->hasValue($key)) {
            return null;
        }

        return filter_var($this->getString($key), FILTER_VALIDATE_BOOLEAN);
    }

    protected function getList(string $key): array
    {
        $value = $this->getValue($key);
        $values = \is_array($value) ? $value : explode(',', (string) $value);

        return array_values(array_filter(array_map('trim', array_map('strval', $values)), 'strlen'));
    }

    protected function getIdList(string $key): array
    {
        return array_values(array_filter(array_map('intval', $this->getList($key))));
    }

    protected function getPostStatus(?string $default = null): ?string
    {
        return $this->hasValue('status') ? $this->getString('status') : $default;
    }

    protected function validateRequiredFields(array $labels): ?array
    {
        $missingFields = [];

        foreach ($labels as $key => $label) {
            if (!$this->hasValue($key)) {
                $missingFields[] = $label;
            }
        }

        if (empty($missingFields)) {
            return null;
        }

        return $this->errorResponse(
            wp_sprintf(
                // translators: %s: comma separated list of field names
                _n('%s is required. Map or select a value.', '%s are required. Map or select values.', \count($missingFields), 'bit-integrations-pro'),
                implode(', ', $missingFields)
            )
        );
    }

    protected function validateDates(array $labels): ?array
    {
        foreach ($labels as $key => $label) {
            if ($this->hasValue($key) && strtotime($this->getString($key)) === false) {
                // translators: %s: field name
                return $this->errorResponse(wp_sprintf(__('%s is not a valid date. Use the format YYYY-MM-DD HH:MM.', 'bit-integrations-pro'), $label));
            }
        }

        return null;
    }

    protected function removePost(int $postId, bool $isPermanent)
    {
        // wp_delete_post() without force skips the trash for custom post types, and the TEC delete helpers wrap it.
        return $isPermanent ? wp_delete_post($postId, true) : wp_trash_post($postId);
    }

    protected function successResponse(string $message, array $data = []): array
    {
        return [
            'success' => true,
            'message' => $message,
            'data'    => $data,
        ];
    }

    protected function errorResponse(string $message): array
    {
        return [
            'success' => false,
            'message' => $message,
        ];
    }
}
