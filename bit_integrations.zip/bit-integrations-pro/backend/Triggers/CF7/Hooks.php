<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Config;
use BitApps\IntegrationsPro\Core\Util\Hooks;
use BitApps\IntegrationsPro\Triggers\CF7\CF7HelperPro;

// Deprecated since v2.7.8 - use bit_integrations_mailchimp_* hooks instead
if (bit_integrations_version_below('2.7.8')) {
    Hooks::filter('btcbi_cf7_get_advance_custom_html_fields', [CF7HelperPro::class, 'getAdvanceCustomHtmlFields'], 10, 1);
}

// New hooks since v2.7.8
Hooks::filter(Config::withFreePrefix('cf7_get_advance_custom_html_fields'), [CF7HelperPro::class, 'getAdvanceCustomHtmlFields'], 10, 1);
