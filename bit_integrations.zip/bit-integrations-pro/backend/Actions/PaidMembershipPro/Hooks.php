<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Actions\PaidMembershipPro\PaidMembershipProHelper;
use BitApps\IntegrationsPro\Config;
use BitApps\IntegrationsPro\Core\Util\Hooks;

Hooks::filter(Config::withFreePrefix('paid_membership_pro_profile_fields'), [PaidMembershipProHelper::class, 'profileFields'], 10, 1);
Hooks::filter(Config::withFreePrefix('paid_membership_pro_update_profile'), [PaidMembershipProHelper::class, 'updateProfile'], 10, 4);
Hooks::filter(Config::withFreePrefix('paid_membership_pro_directory_visibility'), [PaidMembershipProHelper::class, 'updateDirectoryVisibility'], 10, 3);
