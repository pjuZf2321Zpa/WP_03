<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Core\Util\Route;
use BitApps\IntegrationsPro\Triggers\FluentBoards\FluentBoardsController;

Route::get('fluent_boards/get', [FluentBoardsController::class, 'getAllTasks']);
