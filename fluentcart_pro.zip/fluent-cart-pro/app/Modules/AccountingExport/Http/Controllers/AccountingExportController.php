<?php

namespace FluentCartPro\App\Modules\AccountingExport\Http\Controllers;

use FluentCart\App\Http\Controllers\Controller;
use FluentCart\Framework\Http\Request\Request;
use FluentCartPro\App\Modules\AccountingExport\Services\AccountingExportService;
use WP_REST_Response;

/**
 * Reports → Export: the OSS / accounting export (multi-currency plan §15.3).
 */
class AccountingExportController extends Controller
{
    public function schema(): WP_REST_Response
    {
        return $this->sendSuccess([
            'export' => AccountingExportService::schema(),
        ]);
    }

    public function batch(Request $request): WP_REST_Response
    {
        $format = sanitize_key((string) $request->get('format', 'csv'));
        if (!in_array($format, ['csv', 'json'], true)) {
            return $this->sendError(['message' => __('Invalid export format.', 'fluent-cart-pro')], 422);
        }

        $rawFilters = (array) $request->get('filters', []);
        $filters = [
            'date_from'    => sanitize_text_field((string) ($rawFilters['date_from'] ?? '')),
            'date_to'      => sanitize_text_field((string) ($rawFilters['date_to'] ?? '')),
            'scheme'       => sanitize_key((string) ($rawFilters['scheme'] ?? 'all')),
            'include_test' => ($rawFilters['include_test'] ?? '') === 'yes' ? 'yes' : 'no',
        ];

        if (!AccountingExportService::isKnownScheme($filters['scheme'])) {
            return $this->sendError(['message' => __('Unknown tax scheme. Use "all" or one of the schemes the export schema lists.', 'fluent-cart-pro')], 422);
        }

        $cursor = sanitize_text_field((string) $request->get('cursor', ''));
        $limit = absint($request->get('max_records', 100));

        return $this->sendSuccess([
            'export' => (new AccountingExportService())->batch($filters, $cursor, $limit),
        ]);
    }
}
