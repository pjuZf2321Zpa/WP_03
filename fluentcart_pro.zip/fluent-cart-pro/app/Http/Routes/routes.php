<?php
defined('ABSPATH') or die;

/**
 * @var $router FluentCart\Framework\Http\Router
 */

$router->namespace('FluentCartPro\App\Http\Controllers')->group(function($router) {
    require_once __DIR__ . '/api.php';
});
