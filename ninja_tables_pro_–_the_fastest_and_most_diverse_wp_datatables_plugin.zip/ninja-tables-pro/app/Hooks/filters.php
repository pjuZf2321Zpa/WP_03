<?php

/**
 * All registered filter's handlers should be in app\Hooks\Handlers,
 * addFilter is similar to add_filter and addCustomFlter is just a
 * wrapper over add_filter which will add a prefix to the hook name
 * using the plugin slug to make it unique in all wordpress plugins,
 * ex: $app->addCustomFilter('foo', ['FooHandler', 'handleFoo']) is
 * equivalent to add_filter('slug-foo', ['FooHandler', 'handleFoo']).
 */

/**
 * @var $app NinjaTablesPro\App\Application
 */

use NinjaTablesPro\App\Hooks\Handlers\PlaceholderParserHandler;

defined('ABSPATH') || exit;

$app->addFilter('ninja_parse_placeholder', [PlaceholderParserHandler::class, 'parse'], 10, 2);

// Tells the free plugin's admin that this Pro version renders the frontend
// Excel button. Older Pro would draw the button but has no click handler, so
// free only offers the setting when this returns true.
add_filter('ninja_tables_frontend_xlsx_button_supported', '__return_true');

add_filter('ninja_table_activated_features', function ($features) {
    $features['ninja_table_front_editor'] = true;

    return $features;
});
