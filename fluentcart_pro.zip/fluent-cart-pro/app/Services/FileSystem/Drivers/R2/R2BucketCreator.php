<?php

namespace FluentCartPro\App\Services\FileSystem\Drivers\R2;

class R2BucketCreator
{
    protected string $accessKey;

    protected string $secretKey;

    protected string $accountId;

    protected string $bucket;

    protected string $region = 'auto';

    protected string $timeStamp;

    protected string $date;

    protected string $requestUrl;

    protected string $host;

    public static function create(string $accountId, string $secret, string $accessKey, string $bucket, string $region = 'auto')
    {
        return (new static($accountId, $secret, $accessKey, $bucket, $region))->createBucket();
    }

    public function __construct(string $accountId, string $secret, string $accessKey, string $bucket, string $region = 'auto')
    {
        $this->accountId = $accountId;
        $this->secretKey = $secret;
        $this->accessKey = $accessKey;
        $this->bucket = strtolower(str_replace(' ', '-', $bucket));
        $this->region = $region ?: 'auto';
        $this->timeStamp = gmdate('Ymd\THis\Z');
        $this->date = substr($this->timeStamp, 0, 8);
        $this->host = $this->accountId . '.r2.cloudflarestorage.com';
        $this->requestUrl = 'https://' . $this->host . '/' . $this->bucket;
    }

    public function createBucket()
    {
        add_filter('http_request_timeout', [$this, 'extendHttpTimeout']);

        $body = '';
        if ($this->region !== 'auto') {
            $body = '<CreateBucketConfiguration xmlns="http://s3.amazonaws.com/doc/2006-03-01/"><LocationConstraint>'
                . esc_html($this->region)
                . '</LocationConstraint></CreateBucketConfiguration>';
        }

        $headers = $this->getHeaders($body);
        $headers['Content-Length'] = strlen($body);

        $response = wp_remote_request($this->requestUrl, [
            'method'  => 'PUT',
            'headers' => $headers,
            'body'    => $body,
        ]);

        remove_filter('http_request_timeout', [$this, 'extendHttpTimeout']);

        if (is_wp_error($response)) {
            return $response;
        }

        $responseCode = (int) wp_remote_retrieve_response_code($response);

        if ($responseCode === 200 || $responseCode === 201) {
            return [
                'message' => __('Bucket created successfully', 'fluent-cart-pro'),
                'bucket'  => $this->bucket,
                'region'  => $this->region,
            ];
        }

        $errorBody = wp_remote_retrieve_body($response);
        $xml = @simplexml_load_string($errorBody);
        $message = $xml ? (string) $xml->Message : __('Unknown error occurred', 'fluent-cart-pro');
        $code = $xml ? (string) $xml->Code : (string) $responseCode;

        return new \WP_Error(
            'bucket_creation_failed',
            sprintf(__('Failed to create R2 bucket: %s (%s)', 'fluent-cart-pro'), $message, $code)
        );
    }

    public function extendHttpTimeout(): int
    {
        return 30;
    }

    protected function getContentHash(string $payload = ''): string
    {
        return hash('sha256', $payload);
    }

    protected function createScope(): string
    {
        return $this->date . '/auto/s3/aws4_request';
    }

    protected function getSigningKey()
    {
        $kDate = hash_hmac('sha256', $this->date, 'AWS4' . $this->secretKey, true);
        $kRegion = hash_hmac('sha256', 'auto', $kDate, true);
        $kService = hash_hmac('sha256', 's3', $kRegion, true);

        return hash_hmac('sha256', 'aws4_request', $kService, true);
    }

    protected function getHeaders(string $body = ''): array
    {
        $payloadHash = $this->getContentHash($body);
        $canonicalUri = '/' . $this->bucket;
        $canonicalHeaders = 'host:' . $this->host . "\n"
            . 'x-amz-content-sha256:' . $payloadHash . "\n"
            . 'x-amz-date:' . $this->timeStamp . "\n";
        $signedHeaders = 'host;x-amz-content-sha256;x-amz-date';

        $canonicalRequest = 'PUT' . "\n" . $canonicalUri . "\n\n"
            . $canonicalHeaders . "\n"
            . $signedHeaders . "\n"
            . $payloadHash;

        $stringToSign = 'AWS4-HMAC-SHA256' . "\n" . $this->timeStamp . "\n" . $this->createScope() . "\n" . hash('sha256', $canonicalRequest);
        $signature = hash_hmac('sha256', $stringToSign, $this->getSigningKey());

        return [
            'Host'                 => $this->host,
            'x-amz-content-sha256' => $payloadHash,
            'x-amz-date'           => $this->timeStamp,
            'Authorization'        => 'AWS4-HMAC-SHA256 Credential=' . $this->accessKey . '/' . $this->createScope() . ', SignedHeaders=' . $signedHeaders . ', Signature=' . $signature,
        ];
    }
}
