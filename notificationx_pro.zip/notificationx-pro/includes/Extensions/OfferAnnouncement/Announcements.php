<?php

/**
 * OfferAnnouncement Extension
 *
 * @package NotificationX\Extensions
 */

namespace NotificationXPro\Extensions\OfferAnnouncement;

use NotificationX\Core\Helper;
use NotificationX\Core\PostType;
use NotificationX\Core\Rules;
use NotificationX\Extensions\OfferAnnouncement\Announcements as AnnouncementsFree;
/**
 * OfferAnnouncement Extension
 */
class Announcements extends AnnouncementsFree {


    /**
     * Initially Invoked when initialized.
     */
    public function __construct() {
        parent::__construct();

    }

    public function init() {
        parent::init();
    }

    public function init_fields(){
        parent::init_fields();
        add_filter('nx_content_fields', [$this, 'content_fields']);
        add_filter('nx_display_fields', [$this, 'display_fields']);
        add_filter('nx_customize_fields', [$this, 'customize_fields']);
        add_filter('nx_link_types', [$this, 'link_types']);
    }

    /**
     * This functions is hooked
     *
     * @hooked nx_public_action
     * @return void
     */
    public function admin_actions() {
        parent::admin_actions();
    }

    /**
     * This functions is hooked
     *
     * @hooked nx_public_action
     * @return void
     */
    public function public_actions() {
        parent::public_actions();
        add_filter('nx_frontend_get_entries', [$this, 'nx_frontend_get_entries'], 10, 3);
        // add_filter('nx_filtered_post', [$this, 'filtered_post'], 10, 2);
        add_action("nx_frontend_keep_entry_{$this->id}", array($this, 'keep_entry'), 10, 4);
        add_filter( "nx_filtered_data_{$this->id}", array( $this, 'exclude_announcements' ), 11, 2 );
        add_filter( "nx_preview_settings_{$this->id}", array( $this, 'preview_settings' ), 10, 1 );
    }


    public function exclude_announcements( $entries, $settings )
    {
        if( empty( $settings['expire_time'] ) || $settings['themes'] === "announcements_theme-13" || $settings['themes'] === "announcements_theme-15" ) {
            return $entries;
        }
        $new_data = [];
        if( ! empty( $entries ) ) {
            foreach( $entries as $key => $entry ) {
                $expire_time = strtotime( $settings['expire_time'] );
                $current_time = current_time('timestamp', true);
                if ( $expire_time > $current_time) {
                    $new_data[] = $entry;
                }
            }
        }
        return $new_data;
    }

    /**
     * Adds option to Link Type field in Content tab.
     *
     * @param array $options
     * @return array
     */
    public function link_types( $options ) {
        $options[] = [
            'value' => 'announcements_link',
            'label' => __( 'URL', 'notificationx-pro' ),
            'rules' => Rules::logicalRule([
                Rules::is( 'source', $this->id ),
            ]),
        ];
        return $options;
    }

    /**
     * Adds options and dependency for `Notification Template` field from `Content` tab.
     *
     * @param array $templates `Notification Template` fields.
     * @return array
     */
    public function __notification_template_dependency($dependency){
        return $dependency;
    }

    public function display_fields($fields) {
        $fields['image-section'] = Rules::is('source', $this->id, true, $fields['image-section']);
        return $fields;
    }

    /**
     * Get data for WooCommerce Extension.
     *
     * @param array $args Settings arguments.
     * @return mixed
     */
    public function content_fields($fields) {
        $content_fields = &$fields['content']['fields'];

        $content_fields['announcement_entries'] = [
            // 'label'    => __('Announcements', 'notificationx-pro'),
            'name'     => 'announcement_entries',
            'type'     => 'section',
            'classes'  => 'nx-announcement-entries',
            'priority' => 300,
            'button'  => [
                'label' => __('Add New', 'notificationx-pro')
            ],
            'fields'   => [
                'offer_title' => array(
                    'type'     => 'text',
                    'name'     => 'offer_title',
                    'label'    => __('Offer Title', 'notificationx-pro'),
                    'default'  => __('Flash Sale: Limited Time Offer!', 'notificationx-pro'),
                    'priority' => 1,
                ),
                'offer_discount' => array(
                    'type'        => 'text',
                    'name'        => 'offer_discount',
                    'label'       => __('Offer Discount (%)', 'notificationx-pro'),
                    'priority'    => 5,
                    'placeholder' => __('25', 'notificationx-pro'),
                    'default'     => __('25', 'notificationx-pro'),
                    'rules'       => Rules::includes('themes', [
                        "{$this->id}_theme-1",
                        "{$this->id}_theme-2",
                    ]),
                ),
                'offer_description' => array(
                    'type'     => 'textarea',
                    'name'     => 'offer_description',
                    'label'    => __('Offer Description', 'notificationx-pro'),
                    'default'  => __('Enjoy flat 50% Off on NotificationX PRO Valid till this week', 'notificationx-pro'),
                    'priority' => 10,
                    'rules'    => Rules::includes('themes', [
                        "{$this->id}_theme-1",
                        "{$this->id}_theme-2",
                        "{$this->id}_theme-12",
                        "{$this->id}_theme-14",
                        "{$this->id}_theme-15",
                    ]),
                ),
                'image' => array(
                    'type'     => 'media',
                    'name'     => 'image',
                    'label'    => __('Image', 'notificationx-pro'),
                    'priority' => 15,
                    'rules'       => Rules::includes('themes', [
                        "{$this->id}_theme-12",
                        "{$this->id}_theme-14",
                    ]),
                ),
                // 'link' => array(
                //     'type'     => 'text',
                //     'name'     => 'link',
                //     'label'    => __('URL', 'notificationx-pro'),
                //     'priority' => 20,
                // ),
                'expire_time' => array(
                    'type'  => 'date',
                    'name'  => 'expire_time',
                    'label' => __('Expire Time', 'notificationx-pro'),
                    'priority' => 30,
                    'default' => gmdate('Y-m-d H:i:s', time() + 7 * 24 * 60 * 60),
                    'rules'       => Rules::includes('themes', [
                        "{$this->id}_theme-1",
                        "{$this->id}_theme-2",
                        "{$this->id}_theme-12",
                        "{$this->id}_theme-14",
                    ]),
                ),
            ],
            'rules'       => Rules::is('source', $this->id),
        ];

        $fields["content"]['fields']['template_adv']      = Rules::is('source', $this->id, true, $fields["content"]['fields']['template_adv']);
        $fields["content"]['fields']['advanced_template'] = Rules::is('source', $this->id, true, $fields["content"]['fields']['advanced_template']);
        $content_fields['announcement_entries']['fields']['announcement_link_button_text'] = [
            'label'    => __('Button Text', 'notificationx-pro'),
            'name'     => 'announcement_link_button_text',
            'type'     => 'text',
            'priority' => 25,
            'default'  => __( 'Grab Now', 'notificationx-pro' ),
            'rules'    => Rules::logicalRule([
				Rules::logicalRule([
					Rules::is( 'source', $this->id ),
					// Rules::is( 'announcement_link_button', true ),
					Rules::includes( 'themes', [
						"{$this->id}_theme-12",
					] ),
				]),
				Rules::logicalRule([
					Rules::is( 'source', $this->id ),
					Rules::includes( 'themes', [
						"{$this->id}_theme-1",
						"{$this->id}_theme-2",
						"{$this->id}_theme-13",
						"{$this->id}_theme-14",
						"{$this->id}_theme-15",
					] ),
				]),
			], 'or'),
        ];


        return $fields;
    }


    /**
     * This method is an implementable method for All Extension coming forward.
     *
     * @param array $args Settings arguments.
     * @return mixed
     */
    public function customize_fields($fields) {
        $behaviour = &$fields['behaviour']['fields'];
        $behaviour['display_last'] = Rules::is('source', $this->id, true, $behaviour['display_last']);
        $behaviour['display_from'] = Rules::is('source', $this->id, true, $behaviour['display_from']);

        return $fields;
    }

    /**
     * This method is an implementable method for All Extension coming forward.
     *
     * @param array $args Settings arguments.
     * @return mixed
     */
    public function filtered_post($post, $params) {
		if(
			$post['source'] === $this->id &&
			!empty($post['announcement_link_button']) &&
			in_array($post['theme'], [
				"{$this->id}_theme-12",
			])
		){
			$post['link_button'] = $post['announcement_link_button'];
		}
        return $post;
    }

    /**
     * Undocumented function
     *
     * @param array $entries
     * @param array $ids
     * @return void
     */
    public function nx_frontend_get_entries($entries, $ids, $notifications) {
        $custom_entries = [];

        foreach ($notifications as $key => $post) {
            if ($post['source'] === $this->id) {
                $_timestamp = !empty($post['expire_time']) ? $post['expire_time'] : $post['updated_at'];
                $timestamp = Helper::mysql_time($_timestamp);
                $entry = [
                    'nx_id'             => $post['nx_id'],
                    'source'            => $post['source'],
                    'entry_key'         => wp_rand(),
                    'timestamp'         => $_timestamp,
                    'created_at'        => $timestamp,
                    'updated_at'        => $timestamp,
                    'offer_discount'    => !empty( $post['offer_discount'] ) ? $post['offer_discount'] : '',
                    'offer_title'       => !empty( $post['offer_title'] ) ? $post['offer_title'] : '',
                    'link_text'         => !empty( $post['announcement_link_button_text'] ) ? $post['announcement_link_button_text'] : '',
                    'offer_description' => !empty( $post['offer_description'] ) ? $post['offer_description'] : '',
                    'image'             => !empty( $post['image'] ) ? $post['image'] : '',
                    'link'              => !empty( $post['link'] ) ? $post['link'] : '',
                ];
                // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Reviewed for the NotificationX codebase: acceptable in this context.
                $custom_entries[] = apply_filters('nx_get_entry', $entry);
            }
        }
        // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Reviewed for the NotificationX codebase: acceptable in this context.
        $custom_entries = apply_filters('nx_get_entries', $custom_entries);
        $entries = array_merge($entries, $custom_entries);
        return $entries;
    }

    public function keep_entry($return, $entry, $post, $params){
        if(isset($entry['id'])){
            $return['id'] = $entry['id'];
        }
        if(isset($entry['link_text'])){
            $return['link_text'] =  $entry['link_text'];
        }
        if(isset($entry['offer_discount'])){
            $return['offer_discount'] =  $entry['offer_discount'];
        }
        if(isset($entry['image_shape'])){
            $return['image_shape'] =  $entry['image_shape'];
        }

        return $return;
    }
    
    public function preview_entry($entry, $settings) {
        if($settings['themes'] === "announcements_theme-13" ){
            $entry = array_merge($entry, [
                'image_data'  => '',
                'offer_title' => 'How Does It Works',
            ]);
        }
        if( $settings['themes'] === "announcements_theme-14"){
            $entry['offer_title'] = 'Hi There!';
        }
        if( $settings['themes'] === "announcements_theme-15" ){
            $entry = array_merge($entry, [
                'image_data'        => '',
                'offer_title'       => 'Hi There!',
                'offer_description' => 'Enjoy flat 50% Off on NotificationX PRO',
            ]);
        }
        return $entry;
    }

    public function preview_settings($settings)
    {
        $settings['nx_subscribe_button_type'] = '';
        if( $settings['themes'] === "announcements_theme-13" || $settings['themes'] === "announcements_theme-15" ){
            $settings['show_notification_image'] = 'none';
        }
        return $settings;
    }

    /**
     * Image action callback
     * @param array $image_data
     * @param array $data
     * @param array $settings
     * @return array
     */
    public function notification_image($image_data, $data, $settings) {
        $theme = str_replace("{$this->id}_", '', $settings['themes']);
        $svg_themes = [
            "theme-1",
            "theme-2",
            "theme-3",
            "theme-4",
            "theme-5",
            "theme-6",
            "theme-7",
            "theme-8",
            "theme-9",
            "theme-10",
        ];
        $themes = [
            "theme-11",
            "theme-12",
            "theme-14",
        ];
        $image_data['classes'] = $this->id;
        if (in_array($theme, $svg_themes)) {
            $image_data['url'] = NOTIFICATIONX_PUBLIC_URL . "image/themes/announcements/$theme.svg";
            $image_data['alt'] = !empty($data['title']) ? $data['title'] : '';
        }
        else if (in_array($theme, $themes)) {
            $image_data['url'] = !empty($data['image']['url']) ? $data['image']['url'] : '';
            $image_data['alt'] = !empty($data['image']['title']) ? $data['image']['title'] : '';
        }
        return $image_data;
    }

}
