<?php

namespace BitApps\IntegrationsPro\Actions\EventsManager;

/**
 * Events Manager booking write actions.
 *
 * Ported from bit-pi's EventsManagerServices. Events Manager keeps bookings in its own
 * tables rather than as posts, so the writes go through $wpdb.
 */
class EventsManagerProHelper
{
    public static function unregisterUserFromEvent($defaultResponse, $fieldData)
    {
        if (!EventsManagerHelper::isPluginActive()) {
            return EventsManagerHelper::errorResponse(__('Events Manager is not installed or activated', 'bit-integrations-pro'));
        }

        if ($invalid = EventsManagerHelper::requireFields($fieldData, ['event_id', 'user_email'])) {
            return $invalid;
        }

        $email = sanitize_email($fieldData['user_email']);

        if (!is_email($email)) {
            return EventsManagerHelper::errorResponse(__('The mapped value is not a valid email address.', 'bit-integrations-pro'));
        }

        $user = get_user_by('email', $email);

        if (!$user) {
            return EventsManagerHelper::errorResponse(__('No user found with the provided email address.', 'bit-integrations-pro'));
        }

        $eventId = trim((string) $fieldData['event_id']);

        // Without this a non-numeric value casts to 0 further down and the run reports
        // "no active registrations", which reads as a data problem rather than a
        // mis-mapped field. is_numeric rather than is_int: post ids arrive as strings.
        if ($eventId !== EventsManagerHelper::ALL_EVENTS && !is_numeric($eventId)) {
            return EventsManagerHelper::errorResponse(__('The mapped event ID is not a valid event.', 'bit-integrations-pro'));
        }

        $bookings = self::findActiveBookings($user->ID, $eventId);

        if (empty($bookings)) {
            return EventsManagerHelper::errorResponse(__('No active registrations found for the specified event and user.', 'bit-integrations-pro'));
        }

        $cancelled = self::cancelBookings($bookings);

        if ($cancelled === 0) {
            return EventsManagerHelper::errorResponse(__('Failed to cancel registrations. Please try again later.', 'bit-integrations-pro'));
        }

        return EventsManagerHelper::successResponse(
            __('Registration cancelled successfully', 'bit-integrations-pro'),
            [
                'cancelled_count' => $cancelled,
                'affected_events' => array_column($bookings, 'event_name'),
                'booking_ids'     => array_column($bookings, 'booking_id'),
            ]
        );
    }

    /**
     * Find a user's cancellable bookings, optionally narrowed to one event.
     *
     * Rejected and cancelled bookings are excluded — re-cancelling them would inflate
     * the count without changing anything — as are events that have already ended.
     *
     * @param int    $userId
     * @param string $eventId post id of the event, or ALL_EVENTS
     *
     * @return array
     */
    private static function findActiveBookings($userId, $eventId)
    {
        global $wpdb;

        $bookingsTable = $wpdb->prefix . 'em_bookings';
        $eventsTable = $wpdb->prefix . 'em_events';

        $sql = "SELECT bookings.booking_id, bookings.event_id, events.event_name, events.post_id
                FROM {$bookingsTable} AS bookings
                LEFT JOIN {$eventsTable} AS events ON bookings.event_id = events.event_id
                WHERE events.event_status = %d
                  AND bookings.booking_status NOT IN (%d, %d)
                  AND bookings.person_id = %d
                  AND events.event_end_date >= %s";

        $params = [
            EventsManagerHelper::EVENT_STATUS_ACTIVE,
            EventsManagerHelper::STATUS_REJECTED,
            EventsManagerHelper::STATUS_CANCELLED,
            $userId,
            // Bound rather than CURDATE(): that is the database server's local date,
            // which need not match the site's. Events Manager stores event dates in
            // site time, so compare against the same clock. Date-only, because
            // event_end_date is a DATE and a datetime would exclude events ending today.
            current_time('Y-m-d'),
        ];

        if ($eventId !== EventsManagerHelper::ALL_EVENTS) {
            $internalEventId = get_post_meta((int) $eventId, '_event_id', true);

            if (empty($internalEventId)) {
                return [];
            }

            $sql .= ' AND bookings.event_id = %d';
            $params[] = $internalEventId;
        }

        // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- table names interpolated above, every value is bound.
        return $wpdb->get_results($wpdb->prepare($sql, $params), ARRAY_A);
    }

    /**
     * Mark bookings cancelled.
     *
     * Goes through EM_Booking::set_status() rather than writing booking_status
     * directly. Events Manager hangs the rest of a cancellation off that method — the
     * em_booking_status_changed action, the attendee and admin notification emails, and
     * the previous_status booking meta — so a direct UPDATE cancels the booking while
     * leaving every other cancellation path in the plugin unaware it happened.
     *
     * @param array $bookings
     *
     * @return int number of bookings actually cancelled
     */
    private static function cancelBookings($bookings)
    {
        if (!\function_exists('em_get_booking')) {
            return 0;
        }

        $cancelled = 0;

        foreach ($bookings as $booking) {
            $emBooking = em_get_booking((int) $booking['booking_id']);

            if (!$emBooking || empty($emBooking->booking_id)) {
                continue;
            }

            // Third argument skips the spaces check, which only guards approvals and
            // would otherwise refuse a cancellation on a full event.
            if ($emBooking->set_status(EventsManagerHelper::STATUS_CANCELLED, true, true)) {
                $cancelled++;
            }
        }

        return $cancelled;
    }
}
