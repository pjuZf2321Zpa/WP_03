<?php

namespace BitApps\IntegrationsPro\Actions\TheEventsCalendar;

use TEC\Events_Pro\Custom_Tables\V1\Series\Relationship;
use TEC\Events_Pro\Custom_Tables\V1\Tables\Series_Relationships;
use Tribe__Events__Pro__Custom_Meta;
use WP_Term;

if (!\defined('ABSPATH')) {
    exit;
}

final class TheEventsCalendarHelper
{
    public const EVENT_POST_TYPE = 'tribe_events';

    public const VENUE_POST_TYPE = 'tribe_venue';

    public const ORGANIZER_POST_TYPE = 'tribe_organizer';

    public const SERIES_POST_TYPE = 'tribe_event_series';

    public const CATEGORY_TAXONOMY = 'tribe_events_cat';

    public const EVENT_STATUS_META_KEY = '_tribe_events_status';

    public const EVENT_STATUS_REASON_META_KEY = '_tribe_events_status_reason';

    public static function isPluginActive()
    {
        return class_exists('Tribe__Events__Main') && \function_exists('tribe_events');
    }

    public static function isProActive()
    {
        return class_exists('Tribe__Events__Pro__Main') && class_exists(Relationship::class);
    }

    public static function isPostOfType($postId, $postType)
    {
        // Trigger hooks stay registered after TEC is deactivated, and the data builders call TEC functions.
        return !empty($postId) && self::isPluginActive() && get_post_type((int) $postId) === $postType;
    }

    public static function getEventStatus($eventId)
    {
        $status = get_post_meta($eventId, self::EVENT_STATUS_META_KEY, true);

        return empty($status) ? 'scheduled' : $status;
    }

    public static function getEventData($eventId)
    {
        if (!self::isPostOfType($eventId, self::EVENT_POST_TYPE)) {
            return [];
        }

        // Read meta, not tribe_get_event(): its decorated fields stay cached for the rest of the request.
        $event = get_post($eventId);
        $venueId = (int) tribe_get_venue_id($event->ID);
        $organizerIds = array_map('intval', tribe_get_organizer_ids($event->ID));
        $categories = wp_get_post_terms($event->ID, self::CATEGORY_TAXONOMY);
        $categories = is_wp_error($categories) ? [] : $categories;
        $tags = wp_get_post_terms($event->ID, 'post_tag', ['fields' => 'names']);
        $seriesId = self::getEventSeriesId($event->ID);

        return [
            'event_id'            => $event->ID,
            'title'               => $event->post_title,
            'description'         => $event->post_content,
            'excerpt'             => $event->post_excerpt,
            'status'              => $event->post_status,
            'slug'                => $event->post_name,
            'url'                 => get_permalink($event->ID),
            'author_id'           => (int) $event->post_author,
            'start_date'          => get_post_meta($event->ID, '_EventStartDate', true),
            'end_date'            => get_post_meta($event->ID, '_EventEndDate', true),
            'start_date_utc'      => get_post_meta($event->ID, '_EventStartDateUTC', true),
            'end_date_utc'        => get_post_meta($event->ID, '_EventEndDateUTC', true),
            'timezone'            => get_post_meta($event->ID, '_EventTimezone', true),
            'all_day'             => tribe_is_truthy(get_post_meta($event->ID, '_EventAllDay', true)),
            'duration'            => (int) get_post_meta($event->ID, '_EventDuration', true),
            'cost'                => get_post_meta($event->ID, '_EventCost', true),
            'currency_symbol'     => get_post_meta($event->ID, '_EventCurrencySymbol', true),
            'event_website'       => get_post_meta($event->ID, '_EventURL', true),
            'featured'            => tribe_is_truthy(get_post_meta($event->ID, '_tribe_featured', true)),
            'event_status'        => self::getEventStatus($event->ID),
            'event_status_reason' => get_post_meta($event->ID, self::EVENT_STATUS_REASON_META_KEY, true),
            'is_recurring'        => \function_exists('tribe_is_recurring_event') && tribe_is_recurring_event($event->ID),
            'is_virtual'          => tribe_is_truthy(get_post_meta($event->ID, '_tribe_events_is_virtual', true)),
            'virtual_url'         => get_post_meta($event->ID, '_tribe_events_virtual_url', true),
            'featured_image_url'  => (string) get_the_post_thumbnail_url($event->ID, 'full'),
            'venue_id'            => $venueId ?: '',
            'venue_name'          => $venueId ? get_the_title($venueId) : '',
            'venue_address'       => $venueId ? get_post_meta($venueId, '_VenueAddress', true) : '',
            'venue_city'          => $venueId ? get_post_meta($venueId, '_VenueCity', true) : '',
            'venue_state'         => $venueId ? self::getVenueStateProvince($venueId) : '',
            'venue_zip'           => $venueId ? get_post_meta($venueId, '_VenueZip', true) : '',
            'venue_country'       => $venueId ? get_post_meta($venueId, '_VenueCountry', true) : '',
            'organizer_ids'       => implode(',', $organizerIds),
            'organizer_names'     => implode(', ', array_map('get_the_title', $organizerIds)),
            'organizer_emails'    => implode(', ', array_filter(array_map(static function ($organizerId) {
                return get_post_meta($organizerId, '_OrganizerEmail', true);
            }, $organizerIds))),
            'category_ids' => implode(',', wp_list_pluck($categories, 'term_id')),
            'categories'   => implode(', ', wp_list_pluck($categories, 'name')),
            'tags'         => is_wp_error($tags) ? '' : implode(', ', $tags),
            'series_id'    => $seriesId ?: '',
            'series_title' => $seriesId ? get_the_title($seriesId) : '',
            'created_at'   => $event->post_date,
            'modified_at'  => $event->post_modified,
        ];
    }

    public static function getVenueData($venueId)
    {
        if (!self::isPostOfType($venueId, self::VENUE_POST_TYPE)) {
            return [];
        }

        $venue = get_post($venueId);

        return [
            'venue_id'      => $venue->ID,
            'name'          => $venue->post_title,
            'description'   => $venue->post_content,
            'status'        => $venue->post_status,
            'url'           => get_permalink($venue->ID),
            'address'       => get_post_meta($venue->ID, '_VenueAddress', true),
            'city'          => get_post_meta($venue->ID, '_VenueCity', true),
            'state'         => self::getVenueStateProvince($venue->ID),
            'zip'           => get_post_meta($venue->ID, '_VenueZip', true),
            'country'       => get_post_meta($venue->ID, '_VenueCountry', true),
            'phone'         => get_post_meta($venue->ID, '_VenuePhone', true),
            'website'       => get_post_meta($venue->ID, '_VenueURL', true),
            'show_map'      => tribe_is_truthy(get_post_meta($venue->ID, '_VenueShowMap', true)),
            'show_map_link' => tribe_is_truthy(get_post_meta($venue->ID, '_VenueShowMapLink', true)),
            'created_at'    => $venue->post_date,
            'modified_at'   => $venue->post_modified,
        ];
    }

    public static function getOrganizerData($organizerId)
    {
        if (!self::isPostOfType($organizerId, self::ORGANIZER_POST_TYPE)) {
            return [];
        }

        $organizer = get_post($organizerId);

        return [
            'organizer_id' => $organizer->ID,
            'name'         => $organizer->post_title,
            'description'  => $organizer->post_content,
            'status'       => $organizer->post_status,
            'url'          => get_permalink($organizer->ID),
            'phone'        => get_post_meta($organizer->ID, '_OrganizerPhone', true),
            'website'      => get_post_meta($organizer->ID, '_OrganizerWebsite', true),
            'email'        => get_post_meta($organizer->ID, '_OrganizerEmail', true),
            'created_at'   => $organizer->post_date,
            'modified_at'  => $organizer->post_modified,
        ];
    }

    public static function getSeriesData($seriesId)
    {
        if (!self::isPostOfType($seriesId, self::SERIES_POST_TYPE)) {
            return [];
        }

        $series = get_post($seriesId);
        $eventIds = self::getSeriesEventIds($series->ID);

        return [
            'series_id'    => $series->ID,
            'title'        => $series->post_title,
            'description'  => $series->post_content,
            'status'       => $series->post_status,
            'url'          => get_permalink($series->ID),
            'event_ids'    => implode(',', $eventIds),
            'event_titles' => implode(', ', array_map('get_the_title', $eventIds)),
            'created_at'   => $series->post_date,
            'modified_at'  => $series->post_modified,
        ];
    }

    public static function getCategoryData($termId)
    {
        $term = get_term((int) $termId, self::CATEGORY_TAXONOMY);

        if (!$term instanceof WP_Term) {
            return [];
        }

        $termLink = get_term_link($term);

        return [
            'category_id' => $term->term_id,
            'name'        => $term->name,
            'slug'        => $term->slug,
            'description' => $term->description,
            'parent_id'   => $term->parent,
            'count'       => $term->count,
            'url'         => is_wp_error($termLink) ? '' : $termLink,
        ];
    }

    public static function getSeriesEventIds($seriesId)
    {
        global $wpdb;

        if (!self::isProActive()) {
            return [];
        }

        // The Series_Relationship model caches query results for the request, so it misses relationships added later.
        $tableName = Series_Relationships::table_name();

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        $eventIds = $wpdb->get_col($wpdb->prepare("SELECT DISTINCT event_post_id FROM {$tableName} WHERE series_post_id = %d", (int) $seriesId));

        return array_map('intval', $eventIds);
    }

    public static function getEventSeriesId($eventId)
    {
        global $wpdb;

        if (!self::isProActive()) {
            return 0;
        }

        $tableName = Series_Relationships::table_name();

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        return (int) $wpdb->get_var($wpdb->prepare("SELECT series_post_id FROM {$tableName} WHERE event_post_id = %d LIMIT 1", (int) $eventId));
    }

    public static function getEventSchedule($eventId)
    {
        return [
            get_post_meta($eventId, '_EventStartDate', true),
            get_post_meta($eventId, '_EventEndDate', true),
            get_post_meta($eventId, '_EventTimezone', true),
        ];
    }

    public static function getCustomFields()
    {
        if (!self::isProActive() || !class_exists('Tribe__Events__Pro__Custom_Meta')) {
            return [];
        }

        $customFields = array_filter((array) tribe_get_option('custom-fields', []), static function ($customField) {
            return !empty($customField['name']);
        });

        return array_column($customFields, null, 'name');
    }

    public static function saveEventCustomFields($eventId, array $customFieldValues)
    {
        $customFields = self::getCustomFields();

        foreach ($customFieldValues as $fieldName => $value) {
            // Pro splits multiple values only on "|", so split a mapped comma list for checkbox fields here.
            if (Tribe__Events__Pro__Custom_Meta::is_multichoice($customFields[$fieldName])) {
                $customFieldValues[$fieldName] = array_values(array_filter(array_map('trim', preg_split('/[,|]/', (string) $value)), 'strlen'));
            }
        }

        Tribe__Events__Pro__Custom_Meta::save_single_event_meta($eventId, $customFieldValues);
    }

    private static function getVenueStateProvince($venueId)
    {
        foreach (['_VenueStateProvince', '_VenueState', '_VenueProvince'] as $metaKey) {
            $value = get_post_meta($venueId, $metaKey, true);

            if (!empty($value)) {
                return $value;
            }
        }

        return '';
    }
}
