<?php

namespace BitApps\IntegrationsPro\Actions\FollowUpBoss\Services;

final class PondService extends BaseService
{
    public function createPond(): array
    {
        $validationRules = [
            'name'     => ['required'],
            'user_id'  => ['required', 'integer'],
            'user_ids' => ['required'],
        ];
        $error = $this->validateFields(
            $validationRules,
            [
                'name'     => __('Pond Name', 'bit-integrations-pro'),
                'user_id'  => __('Pond Lead User', 'bit-integrations-pro'),
                'user_ids' => __('Members', 'bit-integrations-pro'),
            ],
            ['user_id', 'user_ids']
        );

        if ($error !== null) {
            return $error;
        }

        $payload = $this->removeEmptyValues(
            [
                'name'    => $this->getString('name'),
                'userId'  => $this->getInteger('user_id'),
                'userIds' => $this->getIntegerList('user_ids'),
            ]
        );

        return $this->dispatch('POST', '/ponds', $payload);
    }

    public function updatePond(): array
    {
        $validationRules = ['pond_id' => ['required', 'integer']];
        $error = $this->validateFields(
            $validationRules,
            [
                'pond_id' => __('Pond ID', 'bit-integrations-pro'),
            ]
        );

        if ($error !== null) {
            return $error;
        }

        $payload = $this->removeEmptyValues(
            [
                'name'    => $this->getString('name'),
                'userId'  => $this->getInteger('user_id'),
                'userIds' => $this->getIntegerList('user_ids'),
            ]
        );

        return $this->dispatch('PUT', '/ponds/' . rawurlencode($this->getString('pond_id')), $payload);
    }

    public function deletePond(): array
    {
        $validationRules = [
            'pond_id'           => ['required', 'integer'],
            'assign_to_user_id' => ['required', 'integer'],
        ];
        $error = $this->validateFields(
            $validationRules,
            [
                'pond_id'           => __('Pond ID', 'bit-integrations-pro'),
                'assign_to_user_id' => __('Move People To', 'bit-integrations-pro'),
            ],
            ['assign_to_user_id']
        );

        if ($error !== null) {
            return $error;
        }

        $query = $this->removeEmptyValues(
            [
                'assignTo' => $this->getInteger('assign_to_user_id'),
            ]
        );

        return $this->dispatch('DELETE', '/ponds/' . rawurlencode($this->getString('pond_id')), null, $query);
    }
}
