<?php

namespace WPAICG\Lib\KnowledgeBase;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Stores Pro extraction freshness and reindex queue state without source values.
 */
final class AIPKit_Knowledge_Source_State_Store
{
    public const TABLE_SUFFIX = 'aipkit_knowledge_source_state';

    private const SCHEMA_VERSION = 1;
    private const SCHEMA_OPTION = 'aipkit_knowledge_source_state_schema_version';
    private const SYNC_CURSOR_OPTION = 'aipkit_knowledge_source_state_sync_cursor_v1';
    private const SUPPORTED_PROVIDERS = ['OpenAI', 'Google', 'Pinecone', 'Qdrant', 'Chroma'];

    private static $registered = false;
    private static $installed = null;

    public static function register_hooks(): void
    {
        if (self::$registered) {
            return;
        }

        add_action('init', [self::class, 'maybe_install'], 5);
        add_action('aipkit_vector_source_log_changed', [self::class, 'record_source_log_change'], 10, 3);
        add_action('aipkit_vector_source_log_deleted', [self::class, 'delete_by_source_log_id']);
        self::$registered = true;
    }

    public static function table_name(): string
    {
        global $wpdb;

        return $wpdb->prefix . self::TABLE_SUFFIX;
    }

    public static function maybe_install(): bool
    {
        if (self::$installed === true) {
            return true;
        }

        global $wpdb;
        $table_name = self::table_name();
        $installed_version = absint(get_option(self::SCHEMA_OPTION, 0));
        $table_existed = self::table_exists($table_name);

        if ($installed_version === self::SCHEMA_VERSION && $table_existed) {
            self::$installed = true;
            return true;
        }

        $charset_collate = $wpdb->get_charset_collate();
        $sql = "CREATE TABLE {$table_name} (
            source_key char(64) NOT NULL,
            post_id bigint(20) unsigned NOT NULL,
            post_type varchar(20) NOT NULL,
            provider varchar(50) NOT NULL,
            vector_store_id varchar(191) NOT NULL,
            vector_store_name varchar(255) NOT NULL DEFAULT '',
            source_log_id bigint(20) unsigned NOT NULL DEFAULT 0,
            embedding_provider varchar(50) NOT NULL DEFAULT '',
            embedding_model varchar(100) NOT NULL DEFAULT '',
            indexed_fingerprint char(64) NOT NULL DEFAULT '',
            target_fingerprint char(64) NOT NULL DEFAULT '',
            status varchar(20) NOT NULL DEFAULT 'untracked',
            attempts smallint(5) unsigned NOT NULL DEFAULT 0,
            error_message text DEFAULT NULL,
            created_at datetime NOT NULL,
            updated_at datetime NOT NULL,
            PRIMARY KEY  (source_key),
            KEY post_type_status (post_type, status),
            KEY status_updated (status, updated_at),
            KEY post_id (post_id),
            KEY source_log_id (source_log_id)
        ) {$charset_collate};";

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta($sql);

        if (!self::table_exists($table_name)) {
            self::$installed = false;
            return false;
        }

        update_option(self::SCHEMA_OPTION, self::SCHEMA_VERSION, false);
        if (!$table_existed) {
            update_option(self::SYNC_CURSOR_OPTION, 0, false);
        }
        self::$installed = true;

        return true;
    }

    /**
     * Mirrors a source-log transition into the value-free freshness table.
     *
     * @param int          $source_log_id Source row ID.
     * @param array<mixed> $source_data   Source row data.
     * @param string       $fingerprint   Configuration fingerprint used for extraction.
     */
    public static function record_source_log_change(
        int $source_log_id,
        array $source_data,
        string $fingerprint = '',
        bool $is_backfill = false
    ): bool {
        if ($source_log_id <= 0 || !self::maybe_install()) {
            return false;
        }

        $post_id = absint($source_data['post_id'] ?? 0);
        $provider = self::normalize_provider($source_data['provider'] ?? '');
        $vector_store_id = self::truncate(sanitize_text_field((string) ($source_data['vector_store_id'] ?? '')), 191);
        $post = $post_id > 0 ? get_post($post_id) : null;
        if (!$post || $provider === '' || $vector_store_id === '') {
            return false;
        }

        $source_key = self::source_key($post_id, $provider, $vector_store_id);
        $existing = self::get($source_key);
        if (
            is_array($existing)
            && absint($existing['source_log_id'] ?? 0) > $source_log_id
        ) {
            return false;
        }
        if (
            $is_backfill
            && is_array($existing)
            && absint($existing['source_log_id'] ?? 0) >= $source_log_id
        ) {
            return false;
        }

        $source_status = sanitize_key((string) ($source_data['status'] ?? ''));
        if (!in_array($source_status, ['indexed', 'processing', 'failed'], true)) {
            return false;
        }

        $fingerprint = self::sanitize_fingerprint($fingerprint);
        $indexed_fingerprint = is_array($existing)
            ? self::sanitize_fingerprint($existing['indexed_fingerprint'] ?? '')
            : '';
        $target_fingerprint = $fingerprint !== ''
            ? $fingerprint
            : (is_array($existing) ? self::sanitize_fingerprint($existing['target_fingerprint'] ?? '') : '');
        $state_status = $source_status;
        $error_message = '';

        if ($source_status === 'indexed') {
            $indexed_fingerprint = $target_fingerprint !== '' ? $target_fingerprint : $indexed_fingerprint;
            $target_fingerprint = '';
            $state_status = $indexed_fingerprint !== '' ? 'current' : 'untracked';
        } elseif ($source_status === 'processing') {
            $state_status = 'processing';
        } else {
            $state_status = 'failed';
            $error_message = self::truncate(sanitize_text_field((string) ($source_data['message'] ?? '')), 1000);
        }

        $now = current_time('mysql', true);
        $row = [
            'source_key' => $source_key,
            'post_id' => $post_id,
            'post_type' => sanitize_key((string) $post->post_type),
            'provider' => $provider,
            'vector_store_id' => $vector_store_id,
            'vector_store_name' => self::truncate(sanitize_text_field((string) ($source_data['vector_store_name'] ?? '')), 255),
            'source_log_id' => $source_log_id,
            'embedding_provider' => self::truncate(sanitize_key((string) ($source_data['embedding_provider'] ?? '')), 50),
            'embedding_model' => self::truncate(sanitize_text_field((string) ($source_data['embedding_model'] ?? '')), 100),
            'indexed_fingerprint' => $indexed_fingerprint,
            'target_fingerprint' => $target_fingerprint,
            'status' => $state_status,
            'attempts' => is_array($existing) ? absint($existing['attempts'] ?? 0) : 0,
            'error_message' => $error_message,
            'created_at' => is_array($existing) && !empty($existing['created_at'])
                ? (string) $existing['created_at']
                : $now,
            'updated_at' => $now,
        ];

        global $wpdb;
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Durable Pro freshness state is stored in a plugin-owned table.
        return $wpdb->replace(
            self::table_name(),
            $row,
            ['%s', '%d', '%s', '%s', '%s', '%s', '%d', '%s', '%s', '%s', '%s', '%s', '%d', '%s', '%s', '%s']
        ) !== false;
    }

    /**
     * Lazily imports existing source logs in bounded batches.
     *
     * @return array{imported:int,remaining:bool,cursor:int}
     */
    public static function sync_next_batch(int $limit = 500): array
    {
        global $wpdb;
        $limit = min(1000, max(1, $limit));
        $cursor = absint(get_option(self::SYNC_CURSOR_OPTION, 0));
        $source_table = $wpdb->prefix . 'aipkit_vector_data_source';
        if (!self::maybe_install() || !self::table_exists($source_table)) {
            return ['imported' => 0, 'remaining' => false, 'cursor' => $cursor];
        }

        self::prune_orphans(100);

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Bounded migration scan of the plugin's source table.
        $rows = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT id, provider, vector_store_id, vector_store_name, post_id, status, message, file_id, embedding_provider, embedding_model
                FROM " . esc_sql($source_table) . "
                WHERE id > %d AND post_id > 0
                ORDER BY id ASC
                LIMIT %d",
                $cursor,
                $limit
            ),
            ARRAY_A
        );

        $imported = 0;
        foreach ((array) $rows as $row) {
            $cursor = max($cursor, absint($row['id'] ?? 0));
            if (self::record_source_log_change($cursor, $row, '', true)) {
                ++$imported;
            }
        }

        update_option(self::SYNC_CURSOR_OPTION, $cursor, false);
        $remaining = count((array) $rows) === $limit;

        return ['imported' => $imported, 'remaining' => $remaining, 'cursor' => $cursor];
    }

    /**
     * @param string[] $post_types Requested content types.
     * @return array<string,array<string,int>>
     */
    public static function get_summaries(array $post_types): array
    {
        global $wpdb;
        $post_types = self::sanitize_post_types($post_types);
        $summaries = [];
        foreach ($post_types as $post_type) {
            $summaries[$post_type] = self::empty_summary();
        }
        if (empty($post_types) || !self::maybe_install()) {
            return $summaries;
        }

        $state_table = self::table_name();
        $source_table = $wpdb->prefix . 'aipkit_vector_data_source';
        $placeholders = implode(',', array_fill(0, count($post_types), '%s'));
        // phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare -- Placeholder count is generated locally for a sanitized list.
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Aggregated read from plugin-owned tables.
        $rows = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT state.post_type, state.status, state.indexed_fingerprint, COUNT(*) AS item_count
                FROM " . esc_sql($state_table) . " state
                INNER JOIN " . esc_sql($source_table) . " source ON source.id = state.source_log_id
                INNER JOIN {$wpdb->posts} posts ON posts.ID = state.post_id
                WHERE state.post_type IN ({$placeholders})
                AND posts.post_status NOT IN ('trash', 'auto-draft')
                GROUP BY state.post_type, state.status, state.indexed_fingerprint",
                ...$post_types
            ),
            ARRAY_A
        );
        // phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare

        $fingerprints = [];
        foreach ($post_types as $post_type) {
            $fingerprints[$post_type] = AIPKit_Knowledge_Extraction_Fingerprint::for_post_type($post_type);
        }

        foreach ((array) $rows as $row) {
            $post_type = sanitize_key((string) ($row['post_type'] ?? ''));
            if (!isset($summaries[$post_type])) {
                continue;
            }
            $count = absint($row['item_count'] ?? 0);
            $status = sanitize_key((string) ($row['status'] ?? ''));
            $indexed = self::sanitize_fingerprint($row['indexed_fingerprint'] ?? '');
            $summaries[$post_type]['total'] += $count;

            if ($status === 'pending') {
                $summaries[$post_type]['queued'] += $count;
            } elseif (in_array($status, ['working', 'processing'], true)) {
                $summaries[$post_type]['updating'] += $count;
            } elseif ($status === 'failed') {
                if ($indexed !== '' && $indexed === $fingerprints[$post_type]) {
                    $summaries[$post_type]['current'] += $count;
                } else {
                    $summaries[$post_type]['failed'] += $count;
                    $summaries[$post_type]['actionable'] += $count;
                }
            } elseif ($indexed !== '' && $indexed === $fingerprints[$post_type]) {
                $summaries[$post_type]['current'] += $count;
            } else {
                $summaries[$post_type]['stale'] += $count;
                $summaries[$post_type]['actionable'] += $count;
                if ($indexed === '') {
                    $summaries[$post_type]['untracked'] += $count;
                }
            }
        }

        return $summaries;
    }

    public static function queue_stale(string $post_type): int
    {
        global $wpdb;
        $post_type = sanitize_key($post_type);
        if ($post_type === '' || !self::maybe_install()) {
            return 0;
        }

        $fingerprint = AIPKit_Knowledge_Extraction_Fingerprint::for_post_type($post_type);
        $state_table = self::table_name();
        $source_table = $wpdb->prefix . 'aipkit_vector_data_source';
        $now = current_time('mysql', true);

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- One atomic update queues all stale rows in plugin-owned tables.
        $queued = $wpdb->query(
            $wpdb->prepare(
                "UPDATE " . esc_sql($state_table) . " state
                INNER JOIN " . esc_sql($source_table) . " source ON source.id = state.source_log_id
                INNER JOIN {$wpdb->posts} posts ON posts.ID = state.post_id
                SET state.status = %s, state.target_fingerprint = %s, state.attempts = 0,
                    state.error_message = '', state.updated_at = %s
                WHERE state.post_type = %s
                AND state.status NOT IN ('pending', 'working', 'processing')
                AND state.indexed_fingerprint <> %s
                AND posts.post_status NOT IN ('trash', 'auto-draft')",
                'pending',
                $fingerprint,
                $now,
                $post_type,
                $fingerprint
            )
        );

        return max(0, (int) $queued);
    }

    /**
     * Atomically claims one queued source and binds it to the current rules.
     *
     * @return array<string,mixed>|null
     */
    public static function claim_next(): ?array
    {
        global $wpdb;
        if (!self::maybe_install()) {
            return null;
        }

        $state_table = self::table_name();
        $source_table = $wpdb->prefix . 'aipkit_vector_data_source';
        for ($attempt = 0; $attempt < 3; ++$attempt) {
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Indexed one-row queue lookup in plugin-owned tables.
            $item = $wpdb->get_row(
                $wpdb->prepare(
                    "SELECT state.* FROM " . esc_sql($state_table) . " state
                    INNER JOIN " . esc_sql($source_table) . " source ON source.id = state.source_log_id
                    INNER JOIN {$wpdb->posts} posts ON posts.ID = state.post_id
                    WHERE state.status = %s AND posts.post_status NOT IN ('trash', 'auto-draft')
                    ORDER BY state.updated_at ASC, state.source_key ASC LIMIT 1",
                    'pending'
                ),
                ARRAY_A
            );
            if (!is_array($item) || empty($item['source_key'])) {
                return null;
            }

            $fingerprint = AIPKit_Knowledge_Extraction_Fingerprint::for_post_type((string) $item['post_type']);
            $now = current_time('mysql', true);
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Conditional update atomically claims a plugin-owned queue row.
            $claimed = $wpdb->query(
                $wpdb->prepare(
                    "UPDATE " . esc_sql($state_table) . " SET status = %s, target_fingerprint = %s,
                    attempts = attempts + 1, updated_at = %s WHERE source_key = %s AND status = %s",
                    'working',
                    $fingerprint,
                    $now,
                    (string) $item['source_key'],
                    'pending'
                )
            );
            if ($claimed === 1) {
                $item['status'] = 'working';
                $item['target_fingerprint'] = $fingerprint;
                $item['attempts'] = absint($item['attempts'] ?? 0) + 1;
                $item['updated_at'] = $now;
                return $item;
            }
        }

        return null;
    }

    public static function mark_complete(string $source_key, string $fingerprint): bool
    {
        global $wpdb;
        $fingerprint = self::sanitize_fingerprint($fingerprint);
        if ($source_key === '' || $fingerprint === '') {
            return false;
        }

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Durable queue state update in a plugin-owned table.
        return $wpdb->update(
            self::table_name(),
            [
                'indexed_fingerprint' => $fingerprint,
                'target_fingerprint' => '',
                'status' => 'current',
                'error_message' => '',
                'updated_at' => current_time('mysql', true),
            ],
            ['source_key' => $source_key],
            ['%s', '%s', '%s', '%s', '%s'],
            ['%s']
        ) !== false;
    }

    public static function mark_failed(string $source_key, string $message): bool
    {
        global $wpdb;
        if ($source_key === '') {
            return false;
        }

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Durable queue state update in a plugin-owned table.
        return $wpdb->update(
            self::table_name(),
            [
                'status' => 'failed',
                'error_message' => self::truncate(sanitize_text_field($message), 1000),
                'updated_at' => current_time('mysql', true),
            ],
            ['source_key' => $source_key],
            ['%s', '%s', '%s'],
            ['%s']
        ) !== false;
    }

    public static function mark_processing(string $source_key): bool
    {
        global $wpdb;
        if ($source_key === '') {
            return false;
        }

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Durable async state update in a plugin-owned table.
        return $wpdb->update(
            self::table_name(),
            [
                'status' => 'processing',
                'error_message' => '',
                'updated_at' => current_time('mysql', true),
            ],
            ['source_key' => $source_key],
            ['%s', '%s', '%s'],
            ['%s']
        ) !== false;
    }

    public static function recover_abandoned_work(int $stale_after_seconds = 1800): int
    {
        global $wpdb;
        $cutoff = gmdate('Y-m-d H:i:s', time() - max(60, $stale_after_seconds));
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Bounded recovery update in a plugin-owned queue table.
        $recovered = $wpdb->query(
            $wpdb->prepare(
                "UPDATE " . esc_sql(self::table_name()) . "
                SET status = IF(attempts >= %d, %s, %s),
                    error_message = IF(attempts >= %d, %s, error_message),
                    updated_at = %s
                WHERE status = %s AND updated_at < %s",
                3,
                'failed',
                'pending',
                3,
                __('Reindexing stopped after repeated interrupted attempts.', 'gpt3-ai-content-generator'),
                current_time('mysql', true),
                'working',
                $cutoff
            )
        );

        return max(0, (int) $recovered);
    }

    public static function has_pending(): bool
    {
        global $wpdb;
        if (!self::maybe_install()) {
            return false;
        }

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Indexed existence check in a plugin-owned queue table.
        return (bool) $wpdb->get_var(
            $wpdb->prepare(
                "SELECT 1 FROM " . esc_sql(self::table_name()) . " WHERE status = %s LIMIT 1",
                'pending'
            )
        );
    }

    public static function delete_by_source_log_id(int $source_log_id): void
    {
        global $wpdb;
        if ($source_log_id <= 0 || !self::maybe_install()) {
            return;
        }

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Mirrors deletion from another plugin-owned source table.
        $wpdb->delete(self::table_name(), ['source_log_id' => $source_log_id], ['%d']);
    }

    public static function delete_by_source_key(string $source_key): void
    {
        global $wpdb;
        if ($source_key === '' || !self::maybe_install()) {
            return;
        }

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Removes an orphaned queue row from a plugin-owned table.
        $wpdb->delete(self::table_name(), ['source_key' => $source_key], ['%s']);
    }

    public static function prune_orphans(int $limit = 100): int
    {
        global $wpdb;
        $limit = min(500, max(1, $limit));
        $state_table = self::table_name();
        $source_table = $wpdb->prefix . 'aipkit_vector_data_source';
        if (!self::maybe_install() || !self::table_exists($source_table)) {
            return 0;
        }

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Bounded orphan scan across plugin-owned tables.
        $source_keys = $wpdb->get_col(
            $wpdb->prepare(
                "SELECT state.source_key FROM " . esc_sql($state_table) . " state
                LEFT JOIN " . esc_sql($source_table) . " source ON source.id = state.source_log_id
                WHERE source.id IS NULL LIMIT %d",
                $limit
            )
        );
        $source_keys = array_values(array_filter(array_map('sanitize_text_field', (array) $source_keys)));
        if (empty($source_keys)) {
            return 0;
        }

        $placeholders = implode(',', array_fill(0, count($source_keys), '%s'));
        // phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare -- Placeholder count is generated locally for sanitized primary keys.
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Bounded delete by primary keys from a plugin-owned table.
        $deleted = $wpdb->query(
            $wpdb->prepare(
                "DELETE FROM " . esc_sql($state_table) . " WHERE source_key IN ({$placeholders})",
                ...$source_keys
            )
        );
        // phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare

        return max(0, (int) $deleted);
    }

    /** @return array<string,mixed>|null */
    public static function get(string $source_key): ?array
    {
        global $wpdb;
        if ($source_key === '' || !self::maybe_install()) {
            return null;
        }

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Primary-key lookup in a plugin-owned table.
        $row = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT * FROM " . esc_sql(self::table_name()) . " WHERE source_key = %s LIMIT 1",
                $source_key
            ),
            ARRAY_A
        );

        return is_array($row) ? $row : null;
    }

    public static function source_key(int $post_id, string $provider, string $vector_store_id): string
    {
        return hash('sha256', implode('|', [
            (string) absint($post_id),
            strtolower(self::normalize_provider($provider)),
            trim($vector_store_id),
        ]));
    }

    /** @return array<string,int> */
    private static function empty_summary(): array
    {
        return [
            'total' => 0,
            'current' => 0,
            'stale' => 0,
            'queued' => 0,
            'updating' => 0,
            'failed' => 0,
            'untracked' => 0,
            'actionable' => 0,
        ];
    }

    /** @param mixed $provider */
    private static function normalize_provider($provider): string
    {
        $provider = strtolower(trim(is_scalar($provider) ? (string) $provider : ''));
        foreach (self::SUPPORTED_PROVIDERS as $candidate) {
            if (strtolower($candidate) === $provider) {
                return $candidate;
            }
        }

        return '';
    }

    /** @param mixed $fingerprint */
    private static function sanitize_fingerprint($fingerprint): string
    {
        if (!is_scalar($fingerprint)) {
            return '';
        }

        $fingerprint = strtolower(trim((string) $fingerprint));

        return preg_match('/^[a-f0-9]{64}$/', $fingerprint) ? $fingerprint : '';
    }

    /** @param mixed[] $post_types @return string[] */
    private static function sanitize_post_types(array $post_types): array
    {
        return array_values(array_unique(array_filter(array_map(
            static function ($post_type): string {
                return sanitize_key(is_scalar($post_type) ? (string) $post_type : '');
            },
            $post_types
        ))));
    }

    private static function table_exists(string $table_name): bool
    {
        global $wpdb;
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Schema existence check for a plugin-owned table.
        return $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $wpdb->esc_like($table_name))) === $table_name;
    }

    private static function truncate(string $value, int $length): string
    {
        return function_exists('mb_substr') ? mb_substr($value, 0, $length) : substr($value, 0, $length);
    }
}
