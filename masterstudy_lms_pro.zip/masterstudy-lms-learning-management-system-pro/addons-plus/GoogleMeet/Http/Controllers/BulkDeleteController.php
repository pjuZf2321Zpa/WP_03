<?php

namespace MasterStudy\Lms\Pro\AddonsPlus\GoogleMeet\Http\Controllers;

use MasterStudy\Lms\Http\WpResponseFactory;
use MasterStudy\Lms\Pro\AddonsPlus\GoogleMeet\Repositories\GoogleMeetAdminRepository;
use MasterStudy\Lms\Validation\Validator;
use WP_REST_Request;
use WP_REST_Response;

final class BulkDeleteController {
	private const MAX_BULK_GOOGLE_MEETS = 100;

	public function __invoke( WP_REST_Request $request ): WP_REST_Response {
		$validator = new Validator(
			$request->get_params(),
			array(
				'google_meets' => 'required|array',
			)
		);

		if ( $validator->fails() ) {
			return WpResponseFactory::validation_failed( $validator->get_errors_array() );
		}

		$google_meets = (array) $validator->get_validated()['google_meets'];

		if ( count( $google_meets ) > self::MAX_BULK_GOOGLE_MEETS ) {
			return WpResponseFactory::bad_request(
				sprintf(
					/* translators: %d: maximum number of meetings allowed in one bulk request. */
					esc_html__( 'Too many meetings in one request. Maximum allowed is %d.', 'masterstudy-lms-learning-management-system' ),
					self::MAX_BULK_GOOGLE_MEETS
				)
			);
		}

		try {
			( new GoogleMeetAdminRepository() )->bulk_delete( $google_meets );
		} catch ( \RuntimeException $e ) {
			if ( 403 === $e->getCode() ) {
				return WpResponseFactory::forbidden();
			}

			if ( 400 === $e->getCode() ) {
				return WpResponseFactory::bad_request( $e->getMessage() );
			}

			return WpResponseFactory::error( $e->getMessage() );
		}

		return WpResponseFactory::ok_with_data(
			array(
				'success' => true,
			)
		);
	}
}
