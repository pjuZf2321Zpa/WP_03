<?php

/**
 * @author WP Cloud Plugins
 * @copyright Copyright (c) 2023, WP Cloud Plugins
 *
 * @since       2.0
 * @see https://www.wpcloudplugins.com
 */

namespace TheLion\OutoftheBox;

use TheLion\OutoftheBox\API\Dropbox\Models\MediaInfo;

defined('ABSPATH') || exit;

class Thumbnail
{
    /**
     * Cron hook that runs the cache cleanup.
     *
     * @var string
     */
    public const CLEANUP_CRON_HOOK = 'outofthebox_thumbnail_cleanup';

    /**
     * Transient that prevents two cleanups from running at the same time.
     *
     * @var string
     */
    public const CLEANUP_LOCK_TRANSIENT = 'outofthebox_thumb_cleanup_lock';

    /**
     * Transient holding the number of bytes written since the last cleanup.
     *
     * @var string
     */
    public const CLEANUP_PENDING_TRANSIENT = 'outofthebox_thumb_cleanup_pending';

    /**
     * Default maximum cache size in bytes (1000 MB).
     *
     * @var int
     */
    public const CLEANUP_DEFAULT_MAX_SIZE = 1000 * 1024 * 1024;

    /**
     * Default maximum age in seconds (30 days). Use 0 to disable.
     *
     * @var int
     */
    public const CLEANUP_DEFAULT_MAX_AGE = 2592000;

    /**
     * After a size based cleanup, shrink the cache to this fraction of the
     * maximum so that not every run has to delete a handful of files again.
     *
     * @var float
     */
    public const CLEANUP_TARGET_RATIO = 0.9;

    /**
     * Hard time limit per cleanup run, in seconds.
     *
     * @var int
     */
    public const CLEANUP_MAX_RUNTIME = 20;

    /**
     * Safety limit for the LRU pass (memory usage on very large caches).
     *
     * @var int
     */
    public const CLEANUP_MAX_FILES_IN_MEMORY = 150000;

    /**
     * File extensions that are treated as cached thumbnails.
     *
     * @var string[]
     */
    public const CLEANUP_EXTENSIONS = ['jpeg', 'jpg', 'png', 'webp', 'gif'];

    /**
     * @var Entry
     */
    private $_entry;

    /**
     * @var int
     */
    private $_width;

    /**
     * @var int
     */
    private $_height;

    /**
     * @var bool
     */
    private $_crop = false;

    /**
     * @var string
     */
    private $_format = 'jpeg';

    /**
     *  How to resize and crop the image to achieve the desired size.
     *
     * @var string
     */
    private $_mode = 'fitone_bestfit';

    /**
     * @var string
     */
    private $_thumbnail_name;

    /**
     * @var string
     */
    private $_location_thumbnails;

    /**
     * @var string
     */
    private $_location_thumbnails_url;

    /**
     * @var string
     */
    private $_image_data;

    /**
     * Possible thumbnail formats for Dropbox API.
     *
     * @var array
     */
    private $_sizes = [
        'w2048h1536' => ['width' => 2048, 'height' => 1536],
        'w1024h768' => ['width' => 1024, 'height' => 768],
        'w960h640' => ['width' => 960, 'height' => 640],
        'w640h480' => ['width' => 640, 'height' => 480],
        'w480h320' => ['width' => 480, 'height' => 320],
        'w256h256' => ['width' => 256, 'height' => 256],
        'w128h128' => ['width' => 128, 'height' => 128],
        'w64h64' => ['width' => 64, 'height' => 64],
        'w32h32' => ['width' => 32, 'height' => 32],
    ];

    /**
     * Default size.
     *
     * @var string
     */
    private $_size = 'w2048h1536';

    public function __construct(Entry $entry, $width, $height, $crop = false, $format = 'jpeg', $imagedata = null, $loading_thumb = false)
    {
        $this->_entry = $entry;
        $this->_width = round($width);
        $this->_height = round($height);
        $this->_crop = $crop;
        $this->_format = $format;
        $this->_location_thumbnails = OUTOFTHEBOX_CACHEDIR.'thumbnails/';
        $this->_location_thumbnails_url = OUTOFTHEBOX_CACHEURL.'thumbnails/';
        $this->_image_data = $imagedata;

        $this->_size = $this->select_size();
        $this->_thumbnail_name = $this->_get_entry()->get_id().'_'.$this->_size.'_c'.(($this->_crop) ? '1' : '0').'_'.$this->_format;
    }

    public function select_size()
    {
        $selected_size = 'w2048h1536';

        if (0.0 !== $this->_height) {
            foreach ($this->_sizes as $size => $dimensions) {
                $selected_size = $size;
                if ($dimensions['height'] <= $this->_height) {
                    return $selected_size;
                }
            }
        }

        if (0.0 !== $this->_width) {
            foreach ($this->_sizes as $size => $dimensions) {
                $selected_size = $size;
                if ($dimensions['width'] <= $this->_width) {
                    return $selected_size;
                }
            }
        }

        return $selected_size;
    }

    public function get_url()
    {
        $cached_entry = Cache::instance()->get_node_by_id($this->_get_entry()->get_id());
        if (empty($cached_entry) && 'gif' !== $this->_get_entry()->get_extension()) {
            // No metadata avialable yet. Gifs don't have metadata available
            return $this->_build_thumbnail_url();
        }

        if ($this->does_thumbnail_exist()) {
            return $this->get_location_thumbnail_url();
        }

        return $this->_build_thumbnail_url();
    }

    public function get_thumbnail_name()
    {
        return str_replace(':', '', $this->_thumbnail_name);
    }

    public function does_thumbnail_exist()
    {
        if (!file_exists($this->get_location_thumbnail())) {
            return false;
        }

        if (filemtime($this->get_location_thumbnail()) !== $this->_get_entry()->get_last_edited()) {
            return false;
        }

        if (filesize($this->get_location_thumbnail()) < 1) {
            return false;
        }

        return $this->get_location_thumbnail();
    }

    public function build_thumbnail()
    {
        Helpers::set_time_limit(60); // Downloading the thumbnail can take a while

        try {
            $thumbnail = App::instance()->get_sdk_client()->getThumbnail($this->_get_entry()->get_path(), $this->_size, $this->_format, $this->_mode);
            $this->_image_data = $thumbnail->getContents();
            unset($thumbnail);
        } catch (\Exception $ex) {
            Helpers::log_error('Cannot generate thumbnail.', 'Thumbnail', ['entry_id' => $this->_get_entry()->get_id(), 'entry_path' => $this->_get_entry()->get_path()], __LINE__, $ex);

            return false;
        }

        return $this->_create_thumbnail();
    }

    public function get_width()
    {
        return $this->_width;
    }

    public function get_height()
    {
        return $this->_height;
    }

    public function get_crop()
    {
        return $this->_crop;
    }

    public function get_format()
    {
        return $this->_format;
    }

    public function set_width($_width)
    {
        $this->_width = round((int) $_width);
    }

    public function set_height($_height)
    {
        $this->_height = round((int) $_height);
    }

    public function set_crop($_crop = false)
    {
        $this->_crop = (bool) $_crop;
    }

    public function set_format($_format)
    {
        $this->_format = $_format;
    }

    public function get_mode()
    {
        return $this->_mode;
    }

    public function get_size()
    {
        return $this->_size;
    }

    public function set_mode($_mode)
    {
        $this->_mode = $_mode;
    }

    public function set_size($_size)
    {
        $this->_size = $_size;
    }

    public function get_location_thumbnail()
    {
        $thumbnail_name = str_replace(['_jpeg', '_png'], ['.jpeg', '.png'], $this->get_thumbnail_name());

        return $this->_location_thumbnails.$thumbnail_name;
    }

    public function get_location_thumbnail_url()
    {
        $thumbnail_name = str_replace(['_jpeg', '_png'], ['.jpeg', '.png'], $this->get_thumbnail_name());

        return $this->_location_thumbnails_url.$thumbnail_name;
    }

    public function get_location_thumbnails()
    {
        return $this->_location_thumbnails;
    }

    public function get_location_thumbnails_url()
    {
        return $this->_location_thumbnails_url;
    }

    /**
     * Register the cleanup cron. Call this once during plugin init.
     */
    public static function register_cleanup(): void
    {
        add_action(self::CLEANUP_CRON_HOOK, [self::class, 'clean_cache']);

        if (false === wp_next_scheduled(self::CLEANUP_CRON_HOOK)) {
            wp_schedule_event(time() + HOUR_IN_SECONDS, 'daily', self::CLEANUP_CRON_HOOK);
        }
    }

    /**
     * Remove the scheduled cleanup. Call this on plugin deactivation.
     */
    public static function unregister_cleanup(): void
    {
        wp_clear_scheduled_hook(self::CLEANUP_CRON_HOOK);
        wp_clear_scheduled_hook(self::CLEANUP_CRON_HOOK, ['on_demand']);
    }

    /**
     * Maximum cache size in bytes. Use 0 to disable the size limit.
     */
    public static function get_cleanup_max_size(): int
    {
        return (int) apply_filters('outofthebox_thumbnail_cache_max_size', self::CLEANUP_DEFAULT_MAX_SIZE);
    }

    /**
     * Maximum age in seconds. Use 0 to disable the age limit.
     */
    public static function get_cleanup_max_age(): int
    {
        return (int) apply_filters('outofthebox_thumbnail_cache_max_age', self::CLEANUP_DEFAULT_MAX_AGE);
    }

    /**
     * Cheap trigger, to be called right after a thumbnail has been written.
     *
     * This never touches the filesystem. It only increments a counter, and it
     * schedules a one-off cleanup as soon as more than 10% of the maximum cache
     * size has been added since the previous cleanup.
     *
     * @param int $bytes_added size of the thumbnail that was just written
     *
     * @return bool true when a cleanup has been scheduled
     */
    public static function maybe_schedule_cleanup(int $bytes_added = 0): bool
    {
        if ($bytes_added < 1) {
            return false;
        }

        $max_size = self::get_cleanup_max_size();

        if ($max_size < 1) {
            return false;
        }

        $pending = (int) get_transient(self::CLEANUP_PENDING_TRANSIENT) + $bytes_added;

        if ($pending < (int) ($max_size * 0.1)) {
            set_transient(self::CLEANUP_PENDING_TRANSIENT, $pending, WEEK_IN_SECONDS);

            return false;
        }

        /* Unique $args are required here: WordPress ignores a single event that
         * is scheduled within 10 minutes of an existing event with the same hook,
         * and the recurring daily event uses an empty $args array. */
        if (false === wp_next_scheduled(self::CLEANUP_CRON_HOOK, ['on_demand'])) {
            wp_schedule_single_event(time() + MINUTE_IN_SECONDS, self::CLEANUP_CRON_HOOK, ['on_demand']);
        }

        return true;
    }

    /**
     * Clean the thumbnail cache.
     *
     * Pass 1 streams through the directory and removes empty and expired files.
     * Pass 2 only runs when the cache is still too large and removes the least
     * recently used files until the cache is back below the target size.
     *
     * @return array{deleted: int, freed: int, size: int, skipped: bool}
     */
    public static function clean_cache(): array
    {
        $result = ['deleted' => 0, 'freed' => 0, 'size' => 0, 'skipped' => false];

        $directory = self::get_cleanup_directory();

        if (!is_dir($directory)) {
            return $result;
        }

        if (false !== get_transient(self::CLEANUP_LOCK_TRANSIENT)) {
            $result['skipped'] = true;

            return $result;
        }

        set_transient(self::CLEANUP_LOCK_TRANSIENT, time(), 5 * MINUTE_IN_SECONDS);

        $started = time();
        $max_age = self::get_cleanup_max_age();
        $max_size = self::get_cleanup_max_size();
        $cutoff = time() - $max_age;
        $total = 0;

        try {
            // Pass 1: remove empty and expired files. Streaming, so no memory impact.
            foreach (self::iterate_cache_files($directory) as $file) {
                $size = (int) $file->getSize();

                if ($size < 1 || ($max_age > 0 && self::get_last_used($file) < $cutoff)) {
                    if (self::delete_cache_file($file->getPathname())) {
                        ++$result['deleted'];
                        $result['freed'] += $size;
                    }

                    continue;
                }

                $total += $size;

                if (self::cleanup_timed_out($started)) {
                    break;
                }
            }

            // Pass 2: remove least recently used files until below the target size.
            if ($max_size > 0 && $total > $max_size && !self::cleanup_timed_out($started)) {
                $target = (int) ($max_size * self::CLEANUP_TARGET_RATIO);
                $files = [];

                foreach (self::iterate_cache_files($directory) as $file) {
                    $files[] = [$file->getPathname(), (int) $file->getSize(), self::get_last_used($file)];

                    if (count($files) >= self::CLEANUP_MAX_FILES_IN_MEMORY) {
                        break;
                    }
                }

                // Least recently used first.
                usort($files, static function (array $a, array $b): int {
                    return $a[2] <=> $b[2];
                });

                foreach ($files as $file) {
                    if ($total <= $target) {
                        break;
                    }

                    if (self::delete_cache_file($file[0])) {
                        ++$result['deleted'];
                        $result['freed'] += $file[1];
                        $total -= $file[1];
                    }

                    if (self::cleanup_timed_out($started)) {
                        break;
                    }
                }

                unset($files);
            }
        } catch (\Exception $ex) {
            if (method_exists(Helpers::class, 'log_error')) {
                Helpers::log_error('Cannot clean thumbnail cache.', 'Thumbnail', ['directory' => $directory], __LINE__, $ex);
            }
        }

        $result['size'] = $total;

        delete_transient(self::CLEANUP_LOCK_TRANSIENT);
        delete_transient(self::CLEANUP_PENDING_TRANSIENT);

        Helpers::log_error('Thumbnail cleanup finished.', 'Thumbnail', ['result' => $result], __LINE__);
        
        return $result;
    }

    /**
     * Cache statistics, for example for an admin screen.
     *
     * Note: this scans the whole directory, so do not call it on a frontend request.
     *
     * @return array{files: int, size: int}
     */
    public static function get_cache_stats(): array
    {
        $stats = ['files' => 0, 'size' => 0];
        $directory = self::get_cleanup_directory();

        if (!is_dir($directory)) {
            return $stats;
        }

        foreach (self::iterate_cache_files($directory) as $file) {
            ++$stats['files'];
            $stats['size'] += (int) $file->getSize();
        }

        return $stats;
    }

    private function _build_thumbnail_url()
    {
        return OUTOFTHEBOX_ADMIN_URL.'?action=outofthebox-thumbnail&src='.$this->_thumbnail_name.'&account_id='.App::get_current_account()->get_uuid();
    }

    private function _create_thumbnail()
    {
        // Create the requested thumbnail

        try {
            $this->_create_thumbnail_dir();

            $thumbnail_location = str_replace('_c1', '_c0', $this->get_location_thumbnail());
            file_put_contents($thumbnail_location, $this->_get_image_data());
            touch($thumbnail_location, $this->_get_entry()->get_last_edited());

            if ($this->_crop) {
                $this->_crop_thumbnail();
            }

            return true;
        } catch (\Exception $ex) {
            Helpers::log_error('Cannot create thumbnail.', 'Thumbnail', null, __LINE__, $ex);

            return false;
        }
    }

    private function _create_thumbnail_dir()
    {
        if (!file_exists($this->get_location_thumbnails())) {
            @mkdir($this->get_location_thumbnails(), 0755);
        } else {
            return true;
        }

        if (!is_writable($this->get_location_thumbnails())) {
            @chmod($this->get_location_thumbnails(), 0755);
        } else {
            return true;
        }

        return is_writable($this->get_location_thumbnails());
    }

    private function _crop_thumbnail()
    {
        try {
            $php_thumb = $this->_load_phpthumb_object();
            $php_thumb->GenerateThumbnail();
            $php_thumb->CalculateThumbnailDimensions();

            // Update width/height in cache as this data isn't provided by API
            if ('png' === $this->_get_entry()->get_extension()) {
                $media_info = new MediaInfo(
                    [
                        'metadata' => [
                            '.tag' => 'photo',
                            'dimensions' => [
                                'width' => $php_thumb->source_width,
                                'height' => $php_thumb->source_height,
                            ],
                        ],
                    ]
                );

                $cached_entry = Cache::instance()->get_node_by_id($this->_get_entry()->get_id());
                $cached_entry->add_media_info($media_info);
                Cache::instance()->set_updated();
                Cache::instance()->update_cache();
            }

            $php_thumb->SetCacheFilename();
            $is_thumbnail_created = $php_thumb->RenderToFile($this->get_location_thumbnail());
            unset($php_thumb);

            /* Set the modification date of the thumbnail to that of the entry
             * so we can check if a new thumbnail should be loaded */
            touch($this->get_location_thumbnail(), $this->_get_entry()->get_last_edited());

            return $is_thumbnail_created;
        } catch (\Exception $ex) {
            Helpers::log_error('Cannot generate thumbnail.', 'Thumbnail', ['entry_id' => $this->_get_entry()->get_id(), 'entry_path' => $this->_get_entry()->get_path()], __LINE__, $ex);

            return false;
        }
    }

    /**
     * @return phpThumb
     */
    private function _load_phpthumb_object()
    {
        if (!class_exists('\TheLion\OutoftheBox\phpthumb')) {
            try {
                require_once OUTOFTHEBOX_ROOTDIR.'/vendors/phpThumb/phpthumb.class.php';
            } catch (\Exception $ex) {
                Helpers::log_error('Cannot load PHPTHUMB library.', 'Thumbnail', null, __LINE__, $ex);
            }
        }

        $this->_create_thumbnail_dir();

        $php_thumb = new phpthumb();
        $php_thumb->resetObject();
        $php_thumb->setParameter('config_temp_directory', $this->get_location_thumbnails());
        $php_thumb->setParameter('config_cache_directory', $this->get_location_thumbnails());
        $php_thumb->setParameter('config_output_format', $this->get_format());
        $php_thumb->setParameter('q', 75);
        $php_thumb->setParameter('h', max([$this->_width, $this->_height]));
        $php_thumb->setParameter('w', max([$this->_width, $this->_height]));
        $php_thumb->setParameter('zc', true);
        $php_thumb->setParameter('f', $this->get_format());
        $php_thumb->setParameter('bg', 'FFFFFF');
        $php_thumb->setParameter('ar', 'x');
        $php_thumb->setParameter('aoe', false);

        $php_thumb->setSourceData($this->_get_image_data());

        return $php_thumb;
    }

    /**
     * @return Entry
     */
    private function _get_entry()
    {
        return $this->_entry;
    }

    private function _get_image_data()
    {
        return $this->_image_data;
    }

    /**
     * Absolute path of the thumbnail cache directory.
     */
    private static function get_cleanup_directory(): string
    {
        return OUTOFTHEBOX_CACHEDIR.'thumbnails/';
    }

    /**
     * Iterate over all cached thumbnails in the cache directory.
     *
     * @return \Generator<\SplFileInfo>
     */
    private static function iterate_cache_files(string $directory): \Generator
    {
        $iterator = new \FilesystemIterator($directory, \FilesystemIterator::SKIP_DOTS | \FilesystemIterator::CURRENT_AS_FILEINFO);

        foreach ($iterator as $file) {
            if (!$file->isFile()) {
                continue;
            }

            if (!in_array(strtolower($file->getExtension()), self::CLEANUP_EXTENSIONS, true)) {
                continue;
            }

            yield $file;
        }
    }

    /**
     * Best available "last used" timestamp of a cached thumbnail.
     *
     * See the note at the top of this section: mtime cannot be used here.
     */
    private static function get_last_used(\SplFileInfo $file): int
    {
        $atime = @$file->getATime();
        $ctime = @$file->getCTime();

        return max((int) $atime, (int) $ctime);
    }

    private static function delete_cache_file(string $path): bool
    {
        if (function_exists('wp_delete_file')) {
            wp_delete_file($path);

            return !file_exists($path);
        }

        return @unlink($path);
    }

    private static function cleanup_timed_out(int $started): bool
    {
        return (time() - $started) >= self::CLEANUP_MAX_RUNTIME;
    }
}
