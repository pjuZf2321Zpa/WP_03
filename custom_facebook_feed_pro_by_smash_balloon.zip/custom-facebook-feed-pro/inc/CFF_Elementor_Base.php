<?php

namespace CustomFacebookFeed;

use FacebookFeed\Vendor\Smashballoon\Framework\Packages\Blocks\RecommendedElementorWidgets;
use FacebookFeed\Vendor\Smashballoon\Framework\Packages\Blocks\SB_Feed_Blocks_Registry;
use FacebookFeed\Vendor\Smashballoon\Framework\Packages\Blocks\SB_Block_Utils;
use FacebookFeed\Vendor\Smashballoon\Framework\Packages\Blocks\SB_Elementor_Editor_Assets;
use CustomFacebookFeed\Builder\CFF_Db;

if (!defined('ABSPATH')) {
	exit; // Exit if accessed directly
}

/**
 * Elementor integration base class for Facebook Feed.
 *
 * Handles Elementor widget registration, recommended widgets setup,
 * frontend script enqueuing, and editor asset loading.
 *
 * @since 4.8
 */
class CFF_Elementor_Base
{
	/**
	 * Singleton instance.
	 *
	 * @since 4.8
	 *
	 * @var CFF_Elementor_Base|null
	 */
	private static $instance = null;

	/**
	 * Register and initialize the singleton instance.
	 *
	 * @since 4.8
	 *
	 * @return CFF_Elementor_Base
	 */
	public static function register() {
		if ( null === self::$instance ) {
			self::$instance = new self();
			self::$instance->init();
		}
		return self::$instance;
	}

	/**
	 * Get the singleton instance.
	 *
	 * @since 4.8
	 *
	 * @return CFF_Elementor_Base
	 */
	public static function instance() {
		return self::register();
	}

	/**
	 * Initialize the Elementor integration.
	 *
	 * @since 4.8
	 *
	 * @return void
	 */
	private function init() {
		if ( doing_action( 'init' ) || did_action( 'init' ) ) {
			$this->init_elementor_integration();
		} else {
			add_action( 'init', array( $this, 'init_elementor_integration' ), 4 );
		}
	}

	/**
	 * Set up Elementor hooks and register the widget with the feed blocks registry.
	 *
	 * @since 4.8
	 *
	 * @return void
	 */
	public function init_elementor_integration() {
		if ( ! did_action( 'elementor/loaded' ) ) {
			return;
		}

		$recommended = new RecommendedElementorWidgets( 'facebook' );
		$recommended->setup();

		$registry = SB_Feed_Blocks_Registry::instance();
		$registry->register_elementor_widget( array(
			'blockId'    => 'facebook',
			'widgetName' => 'sb-facebook-feed',
			'globalVar'  => 'cffElementorData',
			'feedInitFn' => 'cff_init',
		) );

		add_action( 'elementor/widgets/register', array( $this, 'register_widgets' ) );
		add_action( 'elementor/controls/register', array( $this, 'register_controls' ) );
		add_action( 'elementor/frontend/after_register_scripts', array( $this, 'register_frontend_scripts' ) );
		add_action( 'elementor/elements/categories_registered', array( $this, 'add_smashballoon_categories' ) );
		add_action( 'elementor/editor/after_enqueue_scripts', array( $this, 'enqueue_editor_scripts' ) );
	}

	/**
	 * Register Elementor widgets.
	 *
	 * @since 4.8
	 *
	 * @param \Elementor\Widgets_Manager $widgets_manager Elementor widgets manager.
	 *
	 * @return void
	 */
	public function register_widgets( $widgets_manager ) {
		// Register modern widget
		require_once trailingslashit( CFF_PLUGIN_DIR ) . 'inc/Integrations/Elementor/CFF_Modern_Elementor_Widget.php';
		$widgets_manager->register( new \CustomFacebookFeed\Integrations\Elementor\CFF_Modern_Elementor_Widget() );

		// Register legacy widget for backward compatibility (existing pages use 'cff-widget' type)
		require_once trailingslashit( CFF_PLUGIN_DIR ) . 'inc/Integrations/Elementor/CFF_Elementor_Widget.php';
		$widgets_manager->register( new \CustomFacebookFeed\Integrations\Elementor\CFF_Elementor_Widget() );
	}

	/**
	 * Register Elementor controls.
	 *
	 * @since 4.8
	 *
	 * @param \Elementor\Controls_Manager $controls_manager Elementor controls manager.
	 *
	 * @return void
	 */
	public function register_controls( $controls_manager ) {
		require_once trailingslashit( CFF_PLUGIN_DIR ) . 'inc/Integrations/Elementor/CFF_Elementor_Control.php';
		$controls_manager->register( new \CustomFacebookFeed\Integrations\Elementor\CFF_Elementor_Control() );
	}

	/**
	 * Register and enqueue frontend scripts and localize feed data.
	 *
	 * @since 4.8
	 *
	 * @return void
	 */
	public function register_frontend_scripts() {
		\cff_main_pro()->enqueue_styles_assets();
		\cff_main_pro()->enqueue_scripts_assets();

		$feeds = CFF_Db::elementor_feeds_list();

		$data = array(
			'feeds'         => ! empty( $feeds ) ? $feeds : array(),
			'feed_url'      => admin_url( 'admin.php?page=cff-feed-builder' ),
			'is_pro_active' => CFF_Utils::cff_is_pro_version(),
		);

		wp_localize_script( 'cffscripts', 'cffElementorData', $data );

		wp_register_script(
			'elementor-preview',
			CFF_PLUGIN_URL . 'admin/assets/js/elementor-preview.js',
			array( 'jquery' ),
			CFFVER,
			true
		);

		SB_Feed_Blocks_Registry::instance()->enqueue_elementor_assets();
	}

	/**
	 * Add the Smash Balloon widget category to Elementor.
	 *
	 * @since 4.8
	 *
	 * @param \Elementor\Elements_Manager $elements_manager Elementor elements manager.
	 *
	 * @return void
	 */
	public function add_smashballoon_categories( $elements_manager ) {
		$elements_manager->add_category(
			SB_Block_Utils::CATEGORY_SLUG,
			array(
				'title' => esc_html__( 'Smash Balloon', 'custom-facebook-feed' ),
				'icon'  => 'fa fa-plug',
			)
		);
	}

	/**
	 * Enqueue shared Elementor editor styles.
	 *
	 * @since 4.8
	 *
	 * @return void
	 */
	public function enqueue_editor_scripts() {
		SB_Elementor_Editor_Assets::enqueue_shared_elementor_styles( CFFVER );
	}
}
