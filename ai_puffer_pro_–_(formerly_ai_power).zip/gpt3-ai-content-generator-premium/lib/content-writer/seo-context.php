<?php

namespace WPAICG\ContentWriter\SEO;

use WPAICG\AIPKit_Providers;
use WPAICG\SEO\AIPKit_SEO_Helper;

if (!defined('ABSPATH')) {
    exit;
}

trait AIPKit_Content_Writer_Smart_SEO_Prompt_Guidance_Trait
{
    private function title_rule_guidance(array $context, string $profile_key): string
    {
        $lines = [];
        if (
            (!in_array($profile_key, ['yoast', 'rank_math', 'aioseo'], true) && $this->rule_enabled($context, 'title_length'))
            || ($profile_key === 'yoast' && $this->rule_enabled($context, 'yoast_seo_title_width'))
            || ($profile_key === 'aioseo' && $this->rule_enabled($context, 'aioseo_title_length'))
        ) {
            $lines[] = '- Keep the SEO title concise, around 35-65 characters.';
        }
        if ($this->rule_enabled($context, 'focus_keyword_in_title')) {
            $lines[] = '- If a title keyphrase issue is supplied, include the focus keyphrase in the SEO title without forcing it to the beginning unless a beginning/start rule is enabled.';
        }
        if ($profile_key === 'aioseo' && $this->rule_enabled($context, 'aioseo_keyphrase_beginning_title')) {
            $lines[] = '- If an AIOSEO title-beginning issue is supplied, start the title with the focus keyphrase when it remains natural.';
        }

        return implode("\n", $lines);
    }

    private function aioseo_headline_guidance(array $context, string $profile_key): string
    {
        if ($profile_key !== 'aioseo' || !$this->rule_enabled($context, 'aioseo_headline_score')) {
            return '';
        }

        $keyphrase_guidance = 'without forcing focus keyphrase placement';
        if ($this->rule_enabled($context, 'aioseo_keyphrase_beginning_title')) {
            $keyphrase_guidance = 'while preserving the focus keyphrase near the beginning';
        } elseif ($this->rule_enabled($context, 'focus_keyword_in_title')) {
            $keyphrase_guidance = 'while keeping the focus keyphrase in the title where natural';
        }

        return '- If an AIOSEO Headline Score issue is supplied, rewrite the post title ' . $keyphrase_guidance . '. Aim for a clear 5-9 word title, roughly 35-66 characters excluding spaces, positive sentiment, one natural power word, and a list, how-to, or question angle when it fits.';
    }

    private function meta_guidance(array $context, string $profile_key): string
    {
        if ($profile_key === 'aioseo') {
            $length_enabled = $this->rule_enabled($context, 'aioseo_meta_description_length');
            $keyphrase_enabled = $this->rule_enabled($context, 'aioseo_keyphrase_in_meta_description');
        } else {
            $length_enabled = $profile_key !== 'rank_math' && $this->rule_enabled($context, 'meta_description_length');
            $keyphrase_enabled = $this->profile_supports_focus_keyphrase($profile_key) && $this->rule_enabled($context, 'focus_keyword_in_meta_description');
        }

        if (!$length_enabled && !$keyphrase_enabled) {
            return '';
        }

        $length_guidance = $profile_key === 'framework'
            ? 'Keep meta_description around 80-160 characters'
            : 'Keep meta_description around 120-156 characters';

        if ($length_enabled && $keyphrase_enabled) {
            return '- ' . $length_guidance . ' and include the focus keyphrase when available.';
        }
        if ($length_enabled) {
            return '- ' . $length_guidance . '.';
        }

        return '- Include the focus keyphrase in meta_description when it reads naturally.';
    }

    private function density_rules_enabled(array $context, string $profile_key): bool
    {
        if ($profile_key === 'rank_math') {
            return $this->rule_enabled($context, 'rank_math_keyword_density');
        }

        if (in_array($profile_key, ['aioseo', 'framework'], true)) {
            return false;
        }

        return $this->rule_enabled($context, 'keyword_density');
    }

    private function image_alt_rules_enabled(array $context, string $profile_key): bool
    {
        if ($profile_key === 'aioseo') {
            return $this->rule_enabled($context, 'aioseo_keyphrase_in_image_alt');
        }

        if (in_array($profile_key, ['yoast', 'rank_math'], true)) {
            return $this->rule_enabled($context, 'keyphrase_in_image_alt');
        }

        return false;
    }

    private function internal_link_rules_enabled(array $context, string $profile_key): bool
    {
        if ($profile_key === 'aioseo') {
            return $this->rule_enabled($context, 'aioseo_internal_links');
        }

        if ($profile_key === 'framework') {
            return false;
        }

        return $this->rule_enabled($context, 'internal_link_exists');
    }

    private function external_link_rules_enabled(array $context, string $profile_key): bool
    {
        if ($profile_key === 'aioseo') {
            return $this->rule_enabled($context, 'aioseo_external_links');
        }

        if ($profile_key === 'framework') {
            return false;
        }

        return $this->rule_enabled($context, 'external_link_exists');
    }

    private function introduction_keyphrase_guidance(array $context, string $profile_key): string
    {
        if ($profile_key === 'aioseo') {
            return $this->rule_enabled($context, 'aioseo_keyphrase_in_introduction')
                ? '- If an AIOSEO focus-keyword introduction issue is supplied, the first body element must be a paragraph, not an image or heading. Put the exact focus keyphrase in that paragraph only if it reads naturally; otherwise use a natural variant in the first sentence and keep the exact phrase in SEO fields.'
                : '';
        }

        if (!$this->profile_supports_focus_keyphrase($profile_key) || !$this->rule_enabled($context, 'focus_keyword_in_introduction')) {
            return '';
        }

        return '- If an introduction or first-10-percent keyphrase issue is supplied, make the first body element an opening paragraph so the topic and search intent are clear immediately. Use the exact focus keyphrase in that paragraph only when it reads naturally.';
    }

    private function previously_used_keyphrase_guidance(array $context, string $profile_key): string
    {
        if (!in_array($profile_key, ['yoast', 'rank_math'], true) || !$this->rule_enabled($context, 'previously_used_keyphrase')) {
            return '';
        }

        return '- If a previously used keyphrase issue is supplied, choose a unique close long-tail focus keyphrase and align the title, introduction, subheadings, meta description, slug, excerpt, and tags with it.';
    }

    private function keyphrase_length_guidance(array $context, string $profile_key): string
    {
        if ($profile_key === 'aioseo') {
            return $this->rule_enabled($context, 'aioseo_keyphrase_length')
                ? '- If an AIOSEO focus keyphrase length issue is supplied, choose a concise 1-4 word focus keyphrase and align the title, introduction, subheadings, meta description, slug, excerpt, and tags with it.'
                : '';
        }

        if (in_array($profile_key, ['rank_math', 'framework'], true) || !$this->rule_enabled($context, 'focus_keyword_length')) {
            return '';
        }

        return '- If a focus keyphrase length issue is supplied, choose a concise 2-4 word focus keyphrase and align the title, introduction, subheadings, meta description, slug, excerpt, and tags with it.';
    }

    private function avoid_focus_keyphrase_anchor_guidance(array $context, string $profile_key): string
    {
        return $profile_key === 'yoast' && $this->rule_enabled($context, 'competing_links')
            ? '- Do not use the focus keyphrase as link anchor text.'
            : '';
    }

    private function subheading_guidance(array $context, string $profile_key): string
    {
        $lines = [];
        if ($profile_key === 'aioseo') {
            if ($this->rule_enabled($context, 'aioseo_keyphrase_in_subheadings')) {
                $lines[] = '- For AIOSEO subheading keyphrase issues, put the exact focus keyphrase in roughly 30%-75% of H2/H3 headings only when those headings remain natural. Use natural variants when the exact phrase would make a heading awkward.';
            }
            if ($this->rule_enabled($context, 'aioseo_subheading_distribution')) {
                $lines[] = '- If an AIOSEO subheading distribution issue is supplied, split long sections with useful H2/H3 headings instead of adding headings only for keywords.';
            }

            return implode("\n", $lines);
        }

        if ($this->profile_supports_focus_keyphrase($profile_key) && $this->rule_enabled($context, 'focus_keyword_in_heading')) {
            $lines[] = $profile_key === 'yoast'
                ? '- If a Yoast subheading keyphrase issue is supplied, balance H2/H3 headings: add the focus keyphrase only when missing, but if more than 75% of subheadings use it, rewrite some headings with natural synonyms instead.'
                : '- If a keyphrase subheading issue is supplied, add the focus keyphrase to a useful subheading only when it remains natural.';
        }
        if (!in_array($profile_key, ['rank_math', 'framework'], true) && $this->rule_enabled($context, 'heading_distribution')) {
            $lines[] = '- If a subheading distribution issue is supplied, split long sections with useful H2/H3 headings instead of adding headings only for keywords.';
        }

        return implode("\n", $lines);
    }

    private function content_length_guidance(array $context, string $profile_key): string
    {
        if ($profile_key === 'rank_math') {
            return $this->rule_enabled($context, 'content_length')
                ? '- If a Rank Math content length issue is supplied, expand the article with useful, specific sections toward 2500+ words without filler.'
                : '';
        }

        if ($profile_key === 'aioseo') {
            return $this->rule_enabled($context, 'aioseo_content_length')
                ? '- If an AIOSEO content length issue is supplied, expand the article with useful detail until it clears AIOSEO minimum content length without filler.'
                : '';
        }

        if ($profile_key === 'framework' || !$this->rule_enabled($context, 'content_length')) {
            return '';
        }

        return '- If a content length issue is supplied, expand the article with useful, specific sections until it meets the requested minimum word count without filler.';
    }

    private function readability_guidance(array $context, string $profile_key): string
    {
        $lines = [];
        if (
            ($profile_key === 'yoast' && $this->rule_enabled($context, 'yoast_consecutive_sentence_starts'))
            || ($profile_key === 'aioseo' && $this->rule_enabled($context, 'aioseo_consecutive_sentences'))
        ) {
            $lines[] = '- If a consecutive sentence issue is supplied, rewrite nearby sentences so repeated openings do not trigger the active SEO profile.';
        }
        if (
            ($profile_key === 'yoast' && $this->rule_enabled($context, 'yoast_transition_words'))
            || ($profile_key === 'aioseo' && $this->rule_enabled($context, 'aioseo_transition_words'))
        ) {
            $lines[] = '- If a transition words issue is supplied, add natural transition words or phrases until at least 30% of sentences include one. Do not stuff transitions or make sentence openings repetitive.';
        }
        if (
            ($profile_key === 'yoast' && $this->rule_enabled($context, 'yoast_sentence_length'))
            || ($profile_key === 'aioseo' && $this->rule_enabled($context, 'aioseo_sentence_length'))
        ) {
            $lines[] = '- If a sentence length issue is supplied, shorten or split sentences over 20 words until no more than 25% of sentences are long. Keep the rhythm natural, not choppy.';
        }
        if (
            ($profile_key === 'yoast' && $this->rule_enabled($context, 'yoast_passive_voice'))
            || ($profile_key === 'aioseo' && $this->rule_enabled($context, 'aioseo_passive_voice'))
        ) {
            $lines[] = '- If a passive voice issue is supplied, rewrite passive constructions in active voice where the actor is known. Keep passive voice only when it is clearer or required by the meaning.';
        }
        if ($profile_key === 'aioseo' && $this->rule_enabled($context, 'aioseo_flesch_reading')) {
            $lines[] = '- If a Flesch reading ease issue is supplied, rewrite dense paragraphs into shorter sentences, use simpler everyday words where natural, and keep the average sentence close to 12-15 words without removing useful detail.';
        }

        return implode("\n", $lines);
    }

    private function profile_supports_focus_keyphrase(string $profile_key): bool
    {
        return !in_array($profile_key, ['framework'], true);
    }

    private function rank_math_permalink_guidance(array $context, string $profile_key): string
    {
        if ($profile_key !== 'rank_math' || !$this->rule_enabled($context, 'rank_math_permalink_length')) {
            return '';
        }

        if ($this->rule_enabled($context, 'focus_keyword_in_slug')) {
            return '- For Rank Math URL length issues, keep the slug short enough that the full permalink is 75 characters or fewer. Prefer the focus-keyphrase slug and remove extra title words.';
        }

        return '- For Rank Math URL length issues, keep the slug short enough that the full permalink is 75 characters or fewer without forcing the focus keyphrase into the URL.';
    }

    private function rank_math_title_keyword_guidance(array $context, string $profile_key): string
    {
        if ($profile_key !== 'rank_math' || !$this->rule_enabled($context, 'rank_math_title_start_with_keyword')) {
            return '';
        }

        $enabled_readability = $this->rank_math_enabled_title_readability_requirements($context);
        $suffix = empty($enabled_readability)
            ? ''
            : ' If enabled Rank Math title readability issues are supplied, add only these enabled elements after the exact phrase: ' . $this->human_list($enabled_readability) . '.';

        return '- For Rank Math title keyword checks, keep the focus_keyword as one unbroken exact phrase at the beginning of the SEO title. Do not insert extra words inside the focus keyphrase.' . $suffix;
    }

    private function rank_math_title_readability_guidance(array $context, string $profile_key): string
    {
        if ($profile_key !== 'rank_math') {
            return '';
        }

        $requirements = $this->rank_math_enabled_title_readability_requirements($context);
        if (empty($requirements)) {
            return '';
        }

        return '- If a Rank Math title readability issue is supplied, keep the title natural while adding only the enabled missing title elements: ' . $this->human_list($requirements) . '.';
    }

    /**
     * @return string[]
     */
    private function rank_math_enabled_title_readability_requirements(array $context): array
    {
        $requirements = [];
        if ($this->rule_enabled($context, 'rank_math_title_has_number')) {
            $requirements[] = 'one relevant number';
        }
        if ($this->rule_enabled($context, 'rank_math_title_power_word')) {
            $requirements[] = 'one natural power word';
        }
        if ($this->rule_enabled($context, 'rank_math_title_sentiment')) {
            $requirements[] = 'clear positive or negative sentiment wording';
        }

        return $requirements;
    }

    /**
     * @param string[] $items
     */
    private function human_list(array $items): string
    {
        $items = array_values(array_filter(array_map('strval', $items)));
        $count = count($items);
        if ($count === 0) {
            return '';
        }
        if ($count === 1) {
            return $items[0];
        }
        if ($count === 2) {
            return $items[0] . ' and ' . $items[1];
        }

        $last = array_pop($items);
        return implode(', ', $items) . ', and ' . $last;
    }

    private function rule_enabled(array $context, string $rule_id): bool
    {
        return !class_exists(AIPKit_Content_Writer_SEO_Config::class)
            || AIPKit_Content_Writer_SEO_Config::is_rule_enabled($context, $rule_id);
    }

    private function build_smart_seo_revision_prompt(array $draft, array $checks, array $context, array $options = []): string
    {
        $issue_lines = [];
        foreach ($checks as $index => $check) {
            $label = $check['label'] !== '' ? $check['label'] : $check['id'];
            $message = $check['message'] !== '' ? $check['message'] : $label;
            $field = $check['field'] !== '' ? ' Field: ' . $check['field'] . '.' : '';
            $issue_lines[] = sprintf('%d. %s: %s%s', $index + 1, $label, $message, $field);
        }

        $payload = [
            'title' => $draft['title'],
            'content_html' => $draft['content_html'],
            'meta_description' => $draft['meta_description'],
            'focus_keyword' => $draft['focus_keyword'],
            'excerpt' => $draft['excerpt'],
            'tags' => $draft['tags'],
            'slug' => $draft['slug'],
        ];
        $profile_key = sanitize_key((string) ($context['profile'] ?? ''));
        $meta_guidance = $this->meta_guidance($context, $profile_key);
        $density_enabled = $this->density_rules_enabled($context, $profile_key);
        $image_alt_enabled = $this->image_alt_rules_enabled($context, $profile_key);
        $internal_link_enabled = $this->internal_link_rules_enabled($context, $profile_key);
        $external_link_enabled = $this->external_link_rules_enabled($context, $profile_key);
        $include_source_url = !empty($options['include_source_url']);
        $include_resolved_focus_keyword = !empty($options['include_resolved_focus_keyword']);
        $include_focus_keyword_alignment = !empty($options['include_focus_keyword_alignment']);

        return implode("\n\n", array_filter([
            'Improve this generated WordPress draft for SEO.',
            sprintf('SEO profile: %s. Current score: %d/100. Target score: %d/100. Improvement pass: %d.', $context['profile_label'], $context['current_score'], $context['target'], $context['pass']),
            sprintf('Site URL: %s', $context['site_url']),
            $internal_link_enabled && class_exists(AIPKit_Content_Writer_Smart_SEO_Internal_Link_Helper::class)
                ? AIPKit_Content_Writer_Smart_SEO_Internal_Link_Helper::format_candidates_for_prompt($context['internal_link_candidates'] ?? [])
                : '',
            $include_source_url && $external_link_enabled && !empty($context['source_url']) ? sprintf('Source URL available for a relevant outbound citation: %s', esc_url_raw((string) $context['source_url'])) : '',
            $include_resolved_focus_keyword && !empty($context['resolved_focus_keyword'])
                ? sprintf('Smart SEO already changed the focus keyphrase before this revision: %s. Keep this current focus_keyword unchanged and align the draft around it.', $context['resolved_focus_keyword'])
                : '',
            $context['topic'] !== '' ? sprintf('Original topic: %s', $context['topic']) : '',
            $context['keywords'] !== '' ? sprintf('Original keywords: %s', $context['keywords']) : '',
            "Fix these audit issues:\n" . implode("\n", $issue_lines),
            'Rules:',
            '- Preserve the meaning, facts, language, and overall article structure.',
            '- Keep focus_keyword exactly as the current draft value unless a previously used keyphrase issue or focus keyphrase length issue is supplied.',
            '- Never sacrifice readability or meaning just to raise the SEO score. A natural 95/100 draft is better than an awkward 100/100 draft.',
            '- Treat focus_keyword as an SEO target, not a phrase that must be forced everywhere. Use the exact phrase only when it reads like normal grammar in that sentence.',
            '- If the exact focus keyphrase sounds like a search query or awkward noun fragment, keep it exact in title, meta description, slug, and image alt when needed; in body paragraphs use natural variants, synonyms, or split phrasing instead.',
            '- Do not start body sentences with the exact focus keyphrase unless the sentence would sound natural to a human reader. Avoid constructions like "[focus keyphrase] is", "[focus keyphrase] looks", or "[focus keyphrase] should".',
            '- Return content_html as body HTML only. Do not include the title as an H1 or repeated opening heading.',
            '- The article body must begin with an introductory paragraph, not a heading, image, table of contents, or repeated title.',
            '- Return only the improved article body in content_html. Do not include chat-style follow-up questions, offers to rewrite or convert the article, alternative format suggestions, or assistant commentary.',
            '- Use only safe article HTML tags such as p, h2, h3, ul, ol, li, a, strong, em, blockquote, table, thead, tbody, tr, th, td, img.',
            '- Do not invent images. If image tags already exist, you may improve their alt attributes.',
            $internal_link_enabled ? '- If internal links are missing or invalid, add or replace one internal link using exactly one URL from the approved internal link candidates. Do not invent slugs or internal URLs.' : '',
            $internal_link_enabled
                ? ($profile_key === 'rank_math'
                    ? '- For Rank Math, internal links must point to another published post or page. Use the approved root-relative URL exactly and never use the homepage as the internal link.'
                    : '- If the only approved internal link candidate is marked homepage_fallback, link to the homepage only once using a natural branded anchor, not the focus keyphrase.')
                : '',
            $external_link_enabled
                ? (class_exists(AIPKit_Content_Writer_Smart_SEO_External_Link_Helper::class)
                    ? '- ' . AIPKit_Content_Writer_Smart_SEO_External_Link_Helper::get_prompt_guidance()
                    : '- If outbound links are missing or all outbound links are nofollowed, add one relevant reputable external link with descriptive anchor text and do not add rel="nofollow" to that normal link.')
                : '',
            $include_source_url && $external_link_enabled && !empty($context['source_url']) ? '- If outbound links are missing and the source URL is relevant and safe, use it as the normal dofollow external citation.' : '',
            $this->introduction_keyphrase_guidance($context, $profile_key),
            $this->previously_used_keyphrase_guidance($context, $profile_key),
            $this->keyphrase_length_guidance($context, $profile_key),
            $include_focus_keyword_alignment ? '- If a focus keyword alignment issue is supplied, keep the current focus_keyword unchanged and align the title, introduction, subheadings, meta description, slug, excerpt, tags, and image alt text with it where natural.' : '',
            '- When a focus keyphrase starts a sentence, use normal sentence capitalization.',
            $this->avoid_focus_keyphrase_anchor_guidance($context, $profile_key),
            $this->subheading_guidance($context, $profile_key),
            $meta_guidance,
            $this->title_rule_guidance($context, $profile_key),
            $this->rank_math_title_keyword_guidance($context, $profile_key),
            $this->rank_math_permalink_guidance($context, $profile_key),
            $this->aioseo_headline_guidance($context, $profile_key),
            $this->rank_math_title_readability_guidance($context, $profile_key),
            $profile_key === 'rank_math' && $this->rule_enabled($context, 'rank_math_table_of_contents')
                ? '- If a Rank Math table of contents issue is supplied, add a compact Table of Contents block near the top using class "wp-block-rank-math-toc-block" and links to existing H2/H3 headings.'
                : '- Do not add a Rank Math Table of Contents block. Preserve an existing ToC only if the current draft already has one.',
            $this->content_length_guidance($context, $profile_key),
            $profile_key === 'rank_math' && $this->rule_enabled($context, 'rank_math_keyword_density') ? '- If a Rank Math keyword density issue is supplied and the exact phrase is natural, follow the total exact-match count in the issue message. If the phrase is awkward, improve density with natural variants instead of forced exact matches.' : '',
            $profile_key === 'rank_math' && $this->rule_enabled($context, 'rank_math_keyword_density') ? '- For low Rank Math keyword density, add the exact focus keyphrase only inside natural sentences across body paragraphs and the conclusion. Avoid link anchors, repetitive sentence openings, and overloading subheadings.' : '',
            $profile_key === 'rank_math' && $this->rule_enabled($context, 'rank_math_content_assets') ? '- If a Rank Math rich media issue is supplied, preserve existing media and alt text, but do not invent image or video URLs.' : '',
            $density_enabled ? '- If keyword density is too high, reduce repeated exact-match usage while keeping natural synonyms.' : '',
            $density_enabled ? '- If a keyword density issue gives an exact-match target range or maximum count, adjust the body to that count range. Replace extra exact matches with natural variants, pronouns, or topic wording instead of deleting useful information.' : '',
            $image_alt_enabled && $profile_key === 'aioseo'
                ? '- If an AIOSEO image alt keyphrase issue is supplied, update an existing in-content image alt attribute so it contains the exact focus keyphrase. Do not invent images.'
                : ($image_alt_enabled ? '- If an image alt keyphrase issue is supplied, update existing image alt attributes so at least one alt text contains at least half of the words from the focus keyphrase. Do not invent images.' : ''),
            $this->readability_guidance($context, $profile_key),
            'Return exactly this JSON shape:',
            '{"title":"...","content_html":"...","meta_description":"...","focus_keyword":"...","excerpt":"...","tags":"comma, separated, tags","slug":"seo-friendly-slug","change_summary":"..."}',
            "Current draft JSON:\n" . wp_json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE),
        ]));
    }

}

/** Shared audit profile and keyword context. */
trait AIPKit_Content_Writer_SEO_Audit_Context_Trait
{
    /**
     * @return array{profile:string,label:string,supports_focus_keyword:bool,logo_url:string,logo_initials:string}
     */
    private function resolve_profile(string $requested_profile): array
    {
        $profile = sanitize_key($requested_profile);
        if ($profile === 'auto' || $profile === '') {
            if (class_exists(AIPKit_SEO_Helper::class)) {
                $active_profile = AIPKit_SEO_Helper::get_active_plugin_profile();
                $profile_key = isset($active_profile['profile']) ? sanitize_key((string) $active_profile['profile']) : 'aipkit';
                return [
                    'profile' => $profile_key !== '' ? $profile_key : 'aipkit',
                    'label' => isset($active_profile['label']) ? (string) $active_profile['label'] : __('AIPKit SEO', 'gpt3-ai-content-generator'),
                    'supports_focus_keyword' => !empty($active_profile['supports_focus_keyword']),
                    'logo_url' => isset($active_profile['logo_url']) ? (string) $active_profile['logo_url'] : '',
                    'logo_initials' => isset($active_profile['logo_initials']) ? (string) $active_profile['logo_initials'] : '',
                ];
            }
            $profile = 'aipkit';
        }

        $profiles = [
            'aipkit' => ['label' => __('AIPKit SEO', 'gpt3-ai-content-generator'), 'supports_focus_keyword' => false, 'logo_url' => '', 'logo_initials' => 'AI'],
            'yoast' => ['label' => __('Yoast SEO', 'gpt3-ai-content-generator'), 'supports_focus_keyword' => true, 'logo_url' => '', 'logo_initials' => 'Y'],
            'rank_math' => ['label' => __('Rank Math', 'gpt3-ai-content-generator'), 'supports_focus_keyword' => true, 'logo_url' => '', 'logo_initials' => 'RM'],
            'aioseo' => ['label' => __('All in One SEO', 'gpt3-ai-content-generator'), 'supports_focus_keyword' => true, 'logo_url' => '', 'logo_initials' => 'AI'],
            'framework' => ['label' => __('The SEO Framework', 'gpt3-ai-content-generator'), 'supports_focus_keyword' => false, 'logo_url' => '', 'logo_initials' => 'TSF'],
        ];

        if (!isset($profiles[$profile])) {
            $profile = 'aipkit';
        }

        return [
            'profile' => $profile,
            'label' => $profiles[$profile]['label'],
            'supports_focus_keyword' => $profiles[$profile]['supports_focus_keyword'],
            'logo_url' => $profiles[$profile]['logo_url'],
            'logo_initials' => $profiles[$profile]['logo_initials'],
        ];
    }

    private function minimum_words_for_length(string $content_length): int
    {
        switch ($content_length) {
            case 'short':
                return 300;
            case 'long':
                return 900;
            default:
                return 600;
        }
    }

    private function count_used_focus_keyword(string $focus_keyword, int $exclude_post_id = 0): int
    {
        if (!class_exists(AIPKit_Content_Writer_Smart_SEO_Keyphrase_Usage::class) && defined('WPAICG_LIB_DIR')) {
            $usage_path = WPAICG_LIB_DIR . 'content-writer/seo-keyphrase-usage.php';
            if (file_exists($usage_path)) {
                require_once $usage_path;
            }
        }

        if (!class_exists(AIPKit_Content_Writer_Smart_SEO_Keyphrase_Usage::class)) {
            return 0;
        }

        return AIPKit_Content_Writer_Smart_SEO_Keyphrase_Usage::count_used_focus_keyword($focus_keyword, $exclude_post_id);
    }

    private function has_fixable_issue(array $checks): bool
    {
        foreach ($checks as $check) {
            if (!is_array($check)) {
                continue;
            }
            $status = isset($check['status']) ? (string) $check['status'] : '';
            if ($status !== 'pass' && !empty($check['fixable'])) {
                return true;
            }
        }

        return false;
    }
}

/** Shared revision model parameters. */
trait AIPKit_Content_Writer_SEO_Revision_Context_Trait
{
    private static function unique_model_fallbacks(array $fallbacks): array
    {
        $unique = [];
        $seen = [];
        foreach ($fallbacks as $fallback) {
            if (!is_array($fallback)) {
                continue;
            }

            $provider = sanitize_text_field((string) ($fallback['provider'] ?? ''));
            $model = sanitize_text_field((string) ($fallback['model'] ?? ''));
            if ($provider === '' || $model === '') {
                continue;
            }

            $error_code = sanitize_key((string) ($fallback['error_code'] ?? ''));
            $key = strtolower($provider . '|' . $model . '|' . $error_code);
            if (isset($seen[$key])) {
                continue;
            }

            $seen[$key] = true;
            $unique[] = [
                'provider' => $provider,
                'model' => $model,
                'error_code' => $error_code,
                'message' => sanitize_text_field((string) ($fallback['message'] ?? '')),
            ];
        }

        return $unique;
    }

    private function revision_ai_params(array $context, bool $retry = false): array
    {
        $profile = sanitize_key((string) ($context['profile'] ?? ''));
        return [
            'temperature' => $retry ? 0.2 : 0.35,
            'top_p' => null,
            'max_completion_tokens' => $profile === 'rank_math' ? 12000 : 8000,
        ];
    }

    private function normalize_provider(string $provider): string
    {
        return AIPKit_Providers::normalize_provider_label($provider);
    }
}

/** Shared image fields; callers retain their own inclusion and draft policies. */
trait AIPKit_Content_Writer_SEO_Image_Context_Trait
{
    private function normalize_image(array $image): array
    {
        $src = $image['media_library_url']
            ?? $image['url']
            ?? $image['src']
            ?? $image['image_url']
            ?? '';

        $alt = $image['alt_text']
            ?? $image['alt']
            ?? $image['generated_alt_text']
            ?? '';

        $attachment_id = isset($image['attachment_id']) ? absint($image['attachment_id']) : 0;
        if ($src === '' && $attachment_id > 0) {
            $attachment_url = wp_get_attachment_image_url($attachment_id, 'full');
            $src = is_string($attachment_url) ? $attachment_url : '';
        }
        if ($alt === '' && $attachment_id > 0) {
            $stored_alt = get_post_meta($attachment_id, '_wp_attachment_image_alt', true);
            $alt = is_string($stored_alt) ? $stored_alt : '';
        }

        return [
            'src' => is_string($src) ? esc_url_raw($src) : '',
            'alt' => is_string($alt) ? sanitize_text_field($alt) : '',
            'attachment_id' => $attachment_id,
        ];
    }
}
