<?php

namespace WPAICG\Lib\Integrations\Recipes;

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

/**
 * Central plan/feature gate for premium Native App Recipes runtime behavior.
 */
class AIPKit_Recipe_Runtime_Gate
{
    public static function is_plan_eligible(): bool
    {
        return class_exists('\WPAICG\\aipkit_dashboard')
            && \WPAICG\aipkit_dashboard::is_pro_plan();
    }

    public static function can_load_runtime(): bool
    {
        return (bool) apply_filters(
            'aipkit_native_app_recipes_runtime_enabled',
            self::is_plan_eligible()
        );
    }

    public static function can_load_recipes(): bool
    {
        return (bool) apply_filters(
            'aipkit_native_app_recipes_loading_enabled',
            self::can_load_runtime()
        );
    }

    /**
     * @param array<string, mixed> $recipe
     * @param array<string, mixed> $context
     */
    public static function can_execute_recipe(array $recipe = [], array $context = []): bool
    {
        if (!self::can_load_runtime()) {
            return false;
        }

        return (bool) apply_filters(
            'aipkit_native_app_recipes_execution_enabled',
            true,
            $recipe,
            $context
        );
    }
}
