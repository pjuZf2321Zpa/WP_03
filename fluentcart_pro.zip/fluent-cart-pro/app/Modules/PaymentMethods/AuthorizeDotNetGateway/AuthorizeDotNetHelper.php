<?php

namespace FluentCartPro\App\Modules\PaymentMethods\AuthorizeDotNetGateway;

use FluentCart\App\Helpers\Status;
use FluentCart\App\Helpers\StatusHelper;
use FluentCart\App\Models\OrderTransaction;
use FluentCart\App\Models\Subscription;
use FluentCart\App\Events\Order\OrderPaymentFailed;
use FluentCart\Api\CurrencySettings;
use FluentCart\App\Services\DateTime\DateTime;
use FluentCart\Framework\Support\Arr;

class AuthorizeDotNetHelper
{
    /**
     * Auth.Net's duplicate check keys on the merchant PO number among other fields;
     * the seed-derived PO makes a resubmit of the same attempt a duplicate of its own
     * lost charge. 28800s (8h) is the maximum window the API allows.
     */
    public const DUPLICATE_WINDOW_SECONDS = 28800;
    public const PO_NUMBER_META_KEY = 'authnet_po_number';

    public static function buildPurchaseOrderNumber(string $idempotencySeed): string
    {
        if ($idempotencySeed === '') {
            return '';
        }

        // poNumber / order.purchaseOrderNumber is capped at 25 characters
        return substr(md5($idempotencySeed), 0, 25);
    }

    /**
     * transactionRequest child order from the AnetApiSchema XSD; the JSON API is
     * translated to XML, so a key in the wrong position fails the request.
     */
    private const TRANSACTION_REQUEST_SEQUENCE = [
        'transactionType', 'amount', 'currencyCode', 'payment', 'profile', 'solution', 'callId',
        'terminalNumber', 'authCode', 'refTransId', 'splitTenderId', 'order', 'lineItems', 'tax',
        'duty', 'shipping', 'taxExempt', 'poNumber', 'customer', 'billTo', 'shipTo', 'customerIP',
        'cardholderAuthentication', 'retail', 'employeeId', 'transactionSettings', 'userFields',
        'surcharge', 'merchantDescriptor', 'subMerchant', 'tip', 'processingOptions',
        'subsequentAuthInformation', 'otherTax', 'shipFrom', 'authorizationIndicatorType',
    ];

    public static function setTransactionRequestField(array $transactionRequest, string $key, $value): array
    {
        unset($transactionRequest[$key]);

        $position = array_search($key, self::TRANSACTION_REQUEST_SEQUENCE, true);
        $ordered = [];
        $placed = false;
        foreach ($transactionRequest as $existingKey => $existingValue) {
            $existingPosition = array_search($existingKey, self::TRANSACTION_REQUEST_SEQUENCE, true);
            if (!$placed && $existingPosition !== false && $existingPosition > $position) {
                $ordered[$key] = $value;
                $placed = true;
            }
            $ordered[$existingKey] = $existingValue;
        }
        if (!$placed) {
            $ordered[$key] = $value;
        }

        return $ordered;
    }

    public static function duplicateWindowSetting(int $seconds): array
    {
        return [
            'setting' => [
                ['settingName' => 'duplicateWindow', 'settingValue' => (string) $seconds],
            ],
        ];
    }

    /**
     * Resolve a transaction-details record to the local charge that sent it but never
     * heard back: same order, same PO number, no vendor id yet, amount as charged.
     */
    public static function findChargeAwaitingResponse(array $details): ?OrderTransaction
    {
        $poNumber = (string) Arr::get($details, 'order.purchaseOrderNumber');
        $orderId  = (int) Arr::get($details, 'order.invoiceNumber');
        if ($poNumber === '' || !$orderId) {
            return null;
        }

        $chargedAmount = Arr::get($details, 'settleAmount') ?: Arr::get($details, 'authAmount');

        $candidates = OrderTransaction::query()
            ->where('order_id', $orderId)
            ->where('payment_method', 'authorize_dot_net')
            ->where('transaction_type', Status::TRANSACTION_TYPE_CHARGE)
            ->get();

        foreach ($candidates as $candidate) {
            if ((string) Arr::get($candidate->meta ?: [], self::PO_NUMBER_META_KEY) !== $poNumber) {
                continue;
            }
            if ($candidate->vendor_charge_id || $candidate->status === Status::TRANSACTION_SUCCEEDED) {
                continue;
            }
            $expected = self::formatAmount($candidate->total, $candidate->currency);
            $charged  = self::formatAmount((int) round(((float) $chargedAmount) * 100), $candidate->currency);
            if ($expected !== $charged) {
                continue;
            }

            return $candidate;
        }

        return null;
    }

    public static function extractPaymentDetails(array $data, string $fallbackMethod = 'card'): array
    {
        $method = $fallbackMethod;
        $brand = null;
        $lastFour = null;
        $accountType = null;
        $cardExpirationDate = null;

        // Normalize transactionResponse payload structure
        if (Arr::has($data, 'transactionResponse')) {
            $data = Arr::get($data, 'transactionResponse', []);
        }

        if (Arr::has($data, 'accountType') || Arr::has($data, 'accountNumber')) {
            $accountType = (string) Arr::get($data, 'accountType');
            $accountNumber = (string) Arr::get($data, 'accountNumber');

            if (!empty($accountType)) {
                if (stripos($accountType, 'check') !== false || stripos($accountType, 'echeck') !== false) {
                    $method = 'echeck';
                    $brand = 'eCheck';
                } else {
                    $method = 'card';
                    $brand = $accountType;
                }
            }

            if ($accountNumber) {
                $lastFour = substr(preg_replace('/[^0-9]/', '', $accountNumber), -4) ?: null;
            }
        }

        // Transaction detail API payload
        if (Arr::has($data, 'payment')) {
            $payment = Arr::get($data, 'payment', []);
            if (Arr::has($payment, 'creditCard')) {
                $card = Arr::get($payment, 'creditCard', []);
                $method = 'card';
                $brand = Arr::get($card, 'cardType') ?: $brand;
                $lastFour = Arr::get($card, 'cardNumber') ? substr(preg_replace('/[^0-9]/', '', Arr::get($card, 'cardNumber')), -4) : $lastFour;
            } elseif (Arr::has($payment, 'bankAccount')) {
                $bank = Arr::get($payment, 'bankAccount', []);
                $method = 'echeck';
                $brand = 'eCheck';
                $accountType = Arr::get($bank, 'accountType') ?: $accountType;
                $lastFour = Arr::get($bank, 'accountNumber') ? substr(preg_replace('/[^0-9]/', '', Arr::get($bank, 'accountNumber')), -4) : $lastFour;
            }
        }

        return [
            'method'      => $method,
            'brand'       => $brand,
            'last_four'   => $lastFour,
            'account_type'=> $accountType,
            'card_expiration_date' => $cardExpirationDate,
        ];
    }

    public static function formatAmount(int $amountInCents, string $currency): string
    {
        // JPY is the only zero-decimal currency Authorize.Net supports (KB KA-04306)
        $zeroDecimalCurrencies = ['JPY'];

        $currency = strtoupper($currency);

        if (in_array($currency, $zeroDecimalCurrencies, true)) {
            return number_format($amountInCents / 100, 0, '.', '');
        }

        return number_format($amountInCents / 100, 2, '.', '');
    }

 
    public static function markTransactionSucceeded(OrderTransaction $transaction, array $payload, array $details = []): void
    {
        $order = $transaction->order;
        if (!$order) {
            return;
        }

        $paymentDetails = self::extractPaymentDetails($payload, Arr::get($details, 'method', 'card'));

        $vendorChargeId = Arr::get($payload, 'id')
            ?: Arr::get($payload, 'transId')
            ?: Arr::get($payload, 'transactionId')
            ?: $transaction->vendor_charge_id;

        $invoiceNumber = Arr::get($payload, 'invoiceNumber')
            ?: Arr::get($payload, 'order.invoiceNumber');

        // submitTimeUTC is when Authorize.net accepted the charge; it beats the
        // model hook's fallback now() stamp, which for a delayed webhook would
        // be the (later) processing time. Webhook payloads don't carry it —
        // there the hook's fallback stands.
        $submitTime = Arr::get($payload, 'submitTimeUTC');
        if ($submitTime && empty($transaction->meta['settled_at'])) {
            $transaction->meta = array_merge($transaction->meta ?? [], [
                'settled_at' => DateTime::anyTimeToGmt($submitTime)->format('Y-m-d H:i:s')
            ]);
        }

        $transaction->fill(array_filter([
            'status'              => Status::TRANSACTION_SUCCEEDED,
            'vendor_charge_id'    => $vendorChargeId,
            'payment_method_type' => $paymentDetails['method'],
            'card_last_4'         => $paymentDetails['last_four'],
            'card_brand'          => $paymentDetails['method'] === 'card' ? $paymentDetails['brand'] : null,
            'meta'                => array_merge($transaction->meta ?? [], [
                'authnet' => array_merge(
                    Arr::only($payload, ['authCode', 'batchId', 'submitTimeUTC', 'invoiceNumber', 'transId']),
                    $invoiceNumber ? ['invoiceNumber' => $invoiceNumber] : [],
                    ['raw' => $payload]
                )
            ])
        ]));

        $transaction->save();

        (new StatusHelper($order))->syncOrderStatuses($transaction);
    }


    public static function markTransactionPending(OrderTransaction $transaction, array $payload, string $note = ''): void
    {
        $order = $transaction->order;
        if (!$order) {
            return;
        }

        $transaction->fill([
            'status' => Status::TRANSACTION_PENDING,
            'meta'   => array_merge($transaction->meta ?? [], [
                'authnet_pending_note' => $note,
                'authnet_pending_payload' => $payload,
            ])
        ]);
        $transaction->save();

        fluent_cart_add_log(
            __('Authorize.Net Pending', 'fluent-cart-pro'),
            $note ?: __('Authorize.Net marked transaction as pending review.', 'fluent-cart-pro'),
            'info',
            [
                'module_name' => 'order',
                'module_id'   => $order->id,
            ]
        );

        if ($transaction->subscription_id) {
            $subscription = Subscription::query()->find($transaction->subscription_id);
            if ($subscription) {
                $subscription->addLog(
                    __('Authorize.Net Pending', 'fluent-cart-pro'),
                    $note ?: __('Authorize.Net marked transaction as pending review.', 'fluent-cart-pro')
                );
            }
        }
    }

    public static function markTransactionFailed(OrderTransaction $transaction, string $message, array $context = []): void
    {
        $order = $transaction->order;
        if (!$order) {
            return;
        }

        $transaction->fill([
            'status' => Status::TRANSACTION_FAILED,
            'meta'   => array_merge($transaction->meta ?? [], [
                'authnet_failed_reason' => $message,
                'authnet_failed_context' => $context,
            ])
        ]);
        $transaction->save();

        $oldStatus = $order->payment_status;

        $order->update([
            'payment_status' => Status::PAYMENT_FAILED,
            'status'         => Status::ORDER_FAILED,
        ]);

       (new OrderPaymentFailed($order,  $transaction, $oldStatus, Status::PAYMENT_FAILED, $message))->dispatch();
    }

    public static function translateToFluentCartStatus($authnetStatus)
    {
        $statusMap = [
            'active'   => Status::SUBSCRIPTION_ACTIVE,
            'expired'  => Status::SUBSCRIPTION_EXPIRED,
            // ARB suspends on a declined payment and terminates at the next run date
            // unless the merchant fixes it: unpaid, not a merchant pause.
            'suspended' => Status::SUBSCRIPTION_PAST_DUE,
            'canceled' => Status::SUBSCRIPTION_CANCELED,
            'terminated' => Status::SUBSCRIPTION_CANCELED,
            'expiring' => Status::SUBSCRIPTION_EXPIRING,
        ];

        return $statusMap[strtolower($authnetStatus)] ?? Status::SUBSCRIPTION_ACTIVE;
    }

    public static function buildOrderInfo($order): array
    {
        $names = [];
        foreach ($order->order_items ?? [] as $item) {
            if ($item->payment_type === 'bundle') {
                continue;
            }
            $name = $item->post_title ?: $item->title;
            if ($name && !in_array($name, $names, true)) {
                $names[] = $name;
            }
        }
        $default = $names ? implode(', ', $names) : 'Order #' . $order->id;

        $description = apply_filters('fluent_cart/authorize_dot_net/order_description', $default, [
            'order' => $order,
        ]);

        return [
            'invoiceNumber' => mb_substr((string) $order->id, 0, 20),
            'description'   => mb_substr((string) $description, 0, 255),
        ];
    }

    public static function buildLineItems($order): array
    {
        $items = [];

        foreach ($order->order_items ?? [] as $item) {
            if ($item->payment_type === 'bundle') {
                continue;
            }

            // post_title = product name, title = variant/option label
            $name = $item->post_title ?: $item->title ?: 'Item';
            $desc = $item->title ?: '';

            $items[] = [
                'itemId'      => mb_substr((string) $item->id, 0, 31),
                'name'        => mb_substr($name, 0, 31),
                'description' => mb_substr($desc, 0, 255),
                'quantity'    => max(1, (int) $item->quantity),
                'unitPrice'   => self::formatAmount((int) $item->unit_price, $order->currency),
            ];

            if (count($items) >= 30) {
                break;
            }
        }

        return $items;
    }

    public static function formatAddress($address, $fcCustomer, $isBilling = true): array
    {
        // Auth.Net rejects a Bill-To with an empty Last Name, so this always needs a
        // non-empty dummy — regardless of whether a billing address was even collected.
        $firstName = $fcCustomer->first_name ?: '.';
        $lastName  = $fcCustomer->last_name  ?: '.';

        if (!$address) {
            return [
                'firstName' => mb_substr($firstName, 0, 50),
                'lastName'  => mb_substr($lastName, 0, 50),
                'address'   => '',
                'city'      => '',
                'state'     => '',
                'zip'       => '',
                'country'   => '',
            ];
        }

        return array_filter([
            'firstName' => mb_substr($firstName, 0, 50),
            'lastName'  => mb_substr($lastName, 0, 50),
            'address'   => mb_substr(trim($address->address_1 . ' ' . $address->address_2), 0, 60),
            'city'      => mb_substr($address->city, 0, 40),
            'state'     => mb_substr($address->state, 0, 40),
            'zip'       => mb_substr($address->postcode, 0, 20),
            'country'   => mb_substr($address->country, 0, 2)
        ]);
    }

    public static function checkCurrencySupport()
    {
        // Authorize.Net KB KA-04306 lists JPY, its API reference lists PLN: accept both
        $supportedCurrencies = ['USD', 'CAD', 'GBP', 'EUR', 'AUD', 'NZD', 'CHF', 'JPY', 'DKK', 'SEK', 'NOK', 'ZAR', 'PLN'];
        $supportedCurrencies = apply_filters('fluent_cart/authorize_dot_net_supported_currencies', $supportedCurrencies);
        $currentCurrency = strtoupper(CurrencySettings::get('currency'));
        return in_array($currentCurrency, $supportedCurrencies);
    }

    /**
     * E00039 ("duplicate record") responses don't always carry a structured
     * customerProfileId field — Auth.Net sometimes only embeds it in the error text,
     * e.g. "A duplicate record with ID 123456789 already exists." Try the common
     * phrasings before falling back to the first bare "ID <digits>" match.
     */
    public static function extractDuplicateProfileIdFromError(string $errorMessage): ?string
    {
        if (preg_match('/duplicate\s+record\s+with\s+ID\s+(\d+)/i', $errorMessage, $matches)) {
            return $matches[1];
        }

        if (preg_match('/customerProfileId["\'\s:]*["\']?(\d+)/i', $errorMessage, $matches)) {
            return $matches[1];
        }

        if (preg_match('/\bID\s+(\d+)/i', $errorMessage, $matches)) {
            return $matches[1];
        }

        return null;
    }
}
