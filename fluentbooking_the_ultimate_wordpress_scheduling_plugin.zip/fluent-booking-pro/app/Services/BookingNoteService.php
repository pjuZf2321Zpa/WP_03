<?php

namespace FluentBookingPro\App\Services;

use FluentBooking\App\Models\Booking;
use FluentBooking\App\Models\BookingActivity;
use FluentBooking\App\Services\Helper;
use FluentBooking\App\Services\Integrations\FluentCRM\CrmContactService;

defined('ABSPATH') || exit;

/**
 * Host notes, stored as rows on the free plugin's fcal_booking_activity table.
 * Update and delete may touch note rows only, never the rest of the activity log.
 */
class BookingNoteService
{
    /**
     * Longest note body, in characters. The column is LONGTEXT.
     */
    const MAX_LENGTH = 20000;

    /**
     * Longest note title, in characters. fcal_booking_activity.title is VARCHAR(192).
     */
    const MAX_TITLE_LENGTH = 192;

    /**
     * The booking id notes are stored on.
     *
     * A group event is several rows sharing a group_id, and the schedules list
     * can open any of them, so all guests share the lowest id in the group.
     *
     * @param Booking $booking
     * @return int
     */
    public static function anchorId(Booking $booking)
    {
        if (!$booking->isMultiGuestBooking() || !$booking->group_id) {
            return (int) $booking->id;
        }

        $anchorId = Booking::where('group_id', $booking->group_id)->min('id');

        return $anchorId ? (int) $anchorId : (int) $booking->id;
    }

    /**
     * Plain-text body, or a WP_Error when it cannot be stored.
     * Expects an already-unslashed string.
     *
     * @param mixed $body
     * @return string|\WP_Error
     */
    public static function normalizeBody($body)
    {
        if (!is_string($body)) {
            $body = '';
        }

        $body = trim(sanitize_textarea_field($body));

        if ($body === '') {
            return new \WP_Error('note_empty', esc_html__('Write a note before saving.', 'fluent-booking-pro'));
        }

        $length = function_exists('mb_strlen') ? mb_strlen($body) : strlen($body);

        if ($length > self::MAX_LENGTH) {
            return new \WP_Error('note_too_long', sprintf(
                /* translators: %s is the maximum number of characters in a booking note */
                esc_html__('A note cannot be longer than %s characters.', 'fluent-booking-pro'),
                self::MAX_LENGTH
            ));
        }

        return $body;
    }

    /**
     * Single-line title, or a WP_Error when it is too long. Empty is allowed.
     *
     * @param mixed $title
     * @return string|\WP_Error
     */
    public static function normalizeTitle($title)
    {
        if (!is_string($title)) {
            $title = '';
        }

        $title = trim(sanitize_text_field($title));
        $length = function_exists('mb_strlen') ? mb_strlen($title) : strlen($title);

        if ($length > self::MAX_TITLE_LENGTH) {
            return new \WP_Error('title_too_long', sprintf(
                /* translators: %s is the maximum number of characters in a booking note title */
                esc_html__('A note title cannot be longer than %s characters.', 'fluent-booking-pro'),
                self::MAX_TITLE_LENGTH
            ));
        }

        return $title;
    }

    /**
     * Title to store. A blank title becomes "Note added by {host}".
     *
     * @param mixed $title
     * @param string $authorName
     * @return string|\WP_Error
     */
    public static function storedTitle($title, $authorName)
    {
        $title = self::normalizeTitle($title);

        if (is_wp_error($title)) {
            return $title;
        }

        if ($title !== '') {
            return $title;
        }

        return self::fallbackTitle($authorName);
    }

    /**
     * Columns for a new note, apart from booking_id and created_by.
     *
     * @param mixed $body
     * @param string $authorName Display name. Empty becomes the host title.
     * @param mixed $title Host-written title. Empty uses the author fallback.
     * @return array|\WP_Error
     */
    public static function attributes($body, $authorName, $title = '')
    {
        $body = self::normalizeBody($body);

        if (is_wp_error($body)) {
            return $body;
        }

        $title = self::storedTitle($title, $authorName);

        if (is_wp_error($title)) {
            return $title;
        }

        return [
            'type'        => BookingActivity::TYPE_NOTE,
            'status'      => 'closed',
            'title'       => $title,
            'description' => $body,
        ];
    }

    /**
     * A note on this anchor can be edited. Every other activity row cannot.
     *
     * @param BookingActivity|null $activity
     * @param int $anchorId
     * @return bool
     */
    public static function isEditable($activity, $anchorId)
    {
        if (!$activity) {
            return false;
        }

        return $activity->type === BookingActivity::TYPE_NOTE
            && (int) $activity->booking_id === (int) $anchorId;
    }

    /**
     * @param Booking $booking
     * @param int $noteId
     * @return BookingActivity|\WP_Error
     */
    public static function find(Booking $booking, $noteId)
    {
        $anchorId = self::anchorId($booking);

        $activity = BookingActivity::where('id', absint($noteId))
            ->where('booking_id', $anchorId)
            ->notes()
            ->first();

        if (!$activity || !self::isEditable($activity, $anchorId)) {
            return new \WP_Error('note_not_found', esc_html__('That note could not be found.', 'fluent-booking-pro'));
        }

        return $activity;
    }

    /**
     * @param Booking $booking
     * @param mixed $body
     * @param mixed $title
     * @return BookingActivity|\WP_Error
     */
    public static function add(Booking $booking, $body, $title = '')
    {
        $attributes = self::attributes($body, self::authorName(), $title);

        if (is_wp_error($attributes)) {
            return $attributes;
        }

        $attributes['booking_id'] = self::anchorId($booking);

        $userId = get_current_user_id();

        if ($userId) {
            $attributes['created_by'] = $userId;
        }

        return BookingActivity::create($attributes);
    }

    /**
     * @param Booking $booking
     * @param BookingActivity $activity
     * @param mixed $body
     * @param mixed $title Null leaves the stored title alone.
     * @return BookingActivity|\WP_Error
     */
    public static function update(Booking $booking, $activity, $body, $title = null)
    {
        if (!self::isEditable($activity, self::anchorId($booking))) {
            return new \WP_Error('note_not_found', esc_html__('That note could not be found.', 'fluent-booking-pro'));
        }

        $body = self::normalizeBody($body);

        if (is_wp_error($body)) {
            return $body;
        }

        if ($title !== null) {
            $title = self::storedTitle($title, self::titleAuthorName($activity));

            if (is_wp_error($title)) {
                return $title;
            }

            $activity->title = $title;
        }

        $activity->description = $body;
        $activity->save();

        return $activity;
    }

    /**
     * @param Booking $booking
     * @param BookingActivity $activity
     * @return true|\WP_Error
     */
    public static function delete(Booking $booking, $activity)
    {
        if (!self::isEditable($activity, self::anchorId($booking))) {
            return new \WP_Error('note_not_found', esc_html__('That note could not be found.', 'fluent-booking-pro'));
        }

        $activity->delete();

        return true;
    }

    /**
     * The FluentCRM contact this booking's notes can be copied to, or null.
     * Group event notes are shared by every guest, so they have no single contact.
     *
     * @param Booking $booking
     * @return array|null {contact_id, name, profile_url}
     */
    public static function crmTarget(Booking $booking)
    {
        if ($booking->isMultiGuestBooking()) {
            return null;
        }

        return CrmContactService::getNoteTarget($booking->email);
    }

    /**
     * One-way copy of a note onto the invitee's FluentCRM profile. Later edits
     * don't sync. The booking note gets a line naming the contact as a record
     * of the copy.
     *
     * @param Booking $booking
     * @param BookingActivity $activity
     * @return int|\WP_Error The FluentCRM note id.
     */
    public static function copyToCrm(Booking $booking, BookingActivity $activity)
    {
        $target = self::crmTarget($booking);

        if (!$target) {
            return new \WP_Error('crm_unavailable', esc_html__('This note could not be added to the CRM profile.', 'fluent-booking-pro'));
        }

        $presented = self::present($activity);
        $eventTitle = $booking->calendar_event ? $booking->calendar_event->title : '';
        $date = date_i18n(get_option('date_format'), strtotime(get_date_from_gmt($booking->start_time)));

        if ($presented['custom_title']) {
            $title = $presented['title'];
        } else {
            $title = sprintf(
                /* translators: %1$s is the event name, %2$s is the booking date */
                __('Booking note: %1$s on %2$s', 'fluent-booking-pro'),
                $eventTitle,
                $date
            );
        }

        $description = wpautop(esc_html($presented['description']));
        $description .= sprintf(
            '<p><a href="%1$s">%2$s</a></p>',
            esc_url(Helper::getAdminBookingUrl($booking->id)),
            esc_html__('View booking', 'fluent-booking-pro')
        );

        $crmNoteId = CrmContactService::addContactNote($booking->email, $title, $description, 'meeting');

        if (is_wp_error($crmNoteId)) {
            return $crmNoteId;
        }

        $line = sprintf(
            /* translators: %s is the FluentCRM contact's name */
            __('Added to %s\'s FluentCRM profile.', 'fluent-booking-pro'),
            sanitize_text_field($target['name'])
        );
        $body = rtrim((string) $activity->description) . "\n\n" . $line;
        $length = function_exists('mb_strlen') ? mb_strlen($body) : strlen($body);

        // A note already at the length limit keeps its text; the copy still happened.
        if ($length <= self::MAX_LENGTH) {
            // Not an edit: leave updated_at alone so the note does not read as "Edited".
            $activity->timestamps = false;
            $activity->description = $body;
            $activity->save();
            $activity->timestamps = true;
        }

        return $crmNoteId;
    }

    /**
     * Notes for the admin screen, oldest first.
     *
     * @param Booking $booking
     * @return array
     */
    public static function listForAdmin(Booking $booking)
    {
        $notes = [];

        $records = BookingActivity::where('booking_id', self::anchorId($booking))
            ->notes()
            ->orderBy('id', 'ASC')
            ->get();

        foreach ($records as $activity) {
            $notes[] = self::present($activity);
        }

        return $notes;
    }

    /**
     * @param BookingActivity $activity
     * @return array
     */
    public static function present(BookingActivity $activity)
    {
        $title = sanitize_text_field((string) $activity->title);
        $author = self::author($activity->created_by);

        return [
            'id'           => (int) $activity->id,
            'booking_id'   => (int) $activity->booking_id,
            'title'        => $title,
            // False when the stored title is the "Note added by" fallback, so the
            // admin can show the author once instead of repeating it as a heading.
            'custom_title' => $title !== '' && $title !== self::fallbackTitle($author ? $author['name'] : ''),
            'description'  => wp_unslash((string) $activity->description),
            'created_by'   => $activity->created_by ? (int) $activity->created_by : null,
            'author'       => $author,
            'created_at'   => self::dateString($activity->created_at),
            'updated_at'   => self::dateString($activity->updated_at),
        ];
    }

    /**
     * Name and avatar of the note's writer, or null when there is no such user.
     *
     * @param mixed $userId
     * @return array|null
     */
    private static function author($userId)
    {
        $user = $userId ? get_userdata((int) $userId) : false;

        if (!$user) {
            return null;
        }

        return [
            'name'   => sanitize_text_field($user->display_name),
            'avatar' => esc_url_raw((string) Helper::fluentBookingUserAvatar($user->ID, $user)),
        ];
    }

    /**
     * Move this booking's notes onto the next guest before the free plugin
     * deletes the activity log with the booking.
     *
     * @param Booking $booking
     * @return void
     */
    public static function reassignOnDelete(Booking $booking)
    {
        if (!$booking->isMultiGuestBooking() || !$booking->group_id) {
            return;
        }

        if ((int) $booking->id !== self::anchorId($booking)) {
            return;
        }

        $nextId = Booking::where('group_id', $booking->group_id)
            ->where('id', '!=', $booking->id)
            ->min('id');

        if (!$nextId) {
            return;
        }

        BookingActivity::where('booking_id', $booking->id)
            ->notes()
            ->update(['booking_id' => $nextId]);
    }

    /**
     * Name a blank title falls back to. An edited note keeps its original
     * writer's name; a new note uses the current user.
     *
     * @param BookingActivity|null $activity The note being edited, or null for a new one.
     * @return string
     */
    public static function titleAuthorName($activity = null)
    {
        $author = $activity ? self::author($activity->created_by) : null;

        return $author ? $author['name'] : self::authorName();
    }

    /**
     * @param string $authorName
     * @return string
     */
    private static function fallbackTitle($authorName)
    {
        $authorName = sanitize_text_field((string) $authorName);

        if ($authorName === '') {
            $title = __('Note added by host', 'fluent-booking-pro');
        } else {
            $title = sprintf(
                /* translators: %s is the display name of the host who wrote the note */
                __('Note added by %s', 'fluent-booking-pro'),
                $authorName
            );
        }

        $length = function_exists('mb_strlen') ? mb_strlen($title) : strlen($title);

        if ($length <= self::MAX_TITLE_LENGTH) {
            return $title;
        }

        return function_exists('mb_substr')
            ? mb_substr($title, 0, self::MAX_TITLE_LENGTH)
            : substr($title, 0, self::MAX_TITLE_LENGTH);
    }

    /**
     * @return string
     */
    private static function authorName()
    {
        $user = wp_get_current_user();

        if ($user && !empty($user->display_name)) {
            return $user->display_name;
        }

        return '';
    }

    /**
     * @param mixed $value
     * @return string|null
     */
    private static function dateString($value)
    {
        if ($value instanceof \DateTimeInterface) {
            return $value->format('Y-m-d H:i:s');
        }

        return $value ? (string) $value : null;
    }
}
