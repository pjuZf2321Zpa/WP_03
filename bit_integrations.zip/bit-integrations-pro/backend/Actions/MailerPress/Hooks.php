<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Actions\MailerPress\MailerPressProHelper;
use BitApps\IntegrationsPro\Config;
use BitApps\IntegrationsPro\Core\Util\Hooks;

// Deprecated since v2.7.8 - use bit_integrations_mailerpress_* hooks instead
if (bit_integrations_version_below('2.7.8')) {
    Hooks::filter('btcbi_mailerpress_delete_contact', [MailerPressProHelper::class, 'deleteContact'], 10, 2);
    Hooks::filter('btcbi_mailerpress_add_tags', [MailerPressProHelper::class, 'addTagsToContact'], 10, 3);
    Hooks::filter('btcbi_mailerpress_remove_tags', [MailerPressProHelper::class, 'removeTagsFromContact'], 10, 3);
    Hooks::filter('btcbi_mailerpress_add_to_lists', [MailerPressProHelper::class, 'addContactToLists'], 10, 3);
    Hooks::filter('btcbi_mailerpress_remove_from_lists', [MailerPressProHelper::class, 'removeContactFromLists'], 10, 3);
}

// New hooks since v2.7.8
Hooks::filter(Config::withFreePrefix('mailerpress_delete_contact'), [MailerPressProHelper::class, 'deleteContact'], 10, 2);
Hooks::filter(Config::withFreePrefix('mailerpress_add_tags'), [MailerPressProHelper::class, 'addTagsToContact'], 10, 3);
Hooks::filter(Config::withFreePrefix('mailerpress_remove_tags'), [MailerPressProHelper::class, 'removeTagsFromContact'], 10, 3);
Hooks::filter(Config::withFreePrefix('mailerpress_add_to_lists'), [MailerPressProHelper::class, 'addContactToLists'], 10, 3);
Hooks::filter(Config::withFreePrefix('mailerpress_remove_from_lists'), [MailerPressProHelper::class, 'removeContactFromLists'], 10, 3);
