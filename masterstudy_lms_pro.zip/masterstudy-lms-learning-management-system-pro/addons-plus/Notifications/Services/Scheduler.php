<?php

namespace MasterStudy\Lms\Pro\AddonsPlus\Notifications\Services;

final class Scheduler {
	public function schedule( int $timestamp, string $trigger_key, int $recipient_id, array $context, string $dedupe_key ): bool {
		if ( $timestamp <= time() || $recipient_id <= 0 ) {
			return false;
		}

		$args = array( $trigger_key, $recipient_id, $context, $dedupe_key );

		if ( wp_next_scheduled( 'masterstudy_notifications_scheduled_event', $args ) ) {
			return false;
		}

		return (bool) wp_schedule_single_event( $timestamp, 'masterstudy_notifications_scheduled_event', $args );
	}

	public function schedule_reminders( string $trigger_key, int $target_timestamp, array $recipient_ids, array $context, string $dedupe_base ): void {
		$windows = array(
			'24 hours' => DAY_IN_SECONDS,
			'1 hour'   => HOUR_IN_SECONDS,
		);

		foreach ( $windows as $label => $seconds_before ) {
			$run_at = $target_timestamp - $seconds_before;

			if ( $run_at <= time() ) {
				continue;
			}

			foreach ( $recipient_ids as $recipient_id ) {
				$reminder_context                     = $context;
				$reminder_context['time_left']        = $label;
				$reminder_context['target_timestamp'] = $target_timestamp;

				$this->schedule(
					$run_at,
					$trigger_key,
					absint( $recipient_id ),
					$reminder_context,
					"{$dedupe_base}:{$recipient_id}:{$label}"
				);
			}
		}
	}

	public function schedule_target( int $timestamp, string $trigger_key, string $target_type, int $target_value, array $context, string $dedupe_key ): bool {
		if ( $timestamp <= time() || $target_value <= 0 ) {
			return false;
		}

		$args = array( $trigger_key, sanitize_key( $target_type ), $target_value, $context, $dedupe_key );

		if ( wp_next_scheduled( 'masterstudy_notifications_scheduled_target_event', $args ) ) {
			return false;
		}

		return (bool) wp_schedule_single_event( $timestamp, 'masterstudy_notifications_scheduled_target_event', $args );
	}

	public function schedule_target_reminders( string $trigger_key, int $target_timestamp, string $target_type, int $target_value, array $context, string $dedupe_base ): void {
		$windows = array(
			'24 hours' => DAY_IN_SECONDS,
			'1 hour'   => HOUR_IN_SECONDS,
		);

		foreach ( $windows as $label => $seconds_before ) {
			$run_at = $target_timestamp - $seconds_before;

			if ( $run_at <= time() ) {
				continue;
			}

			$reminder_context                     = $context;
			$reminder_context['time_left']        = $label;
			$reminder_context['target_timestamp'] = $target_timestamp;

			$this->schedule_target(
				$run_at,
				$trigger_key,
				$target_type,
				$target_value,
				$reminder_context,
				"{$dedupe_base}:{$label}"
			);
		}
	}

	public static function run( string $trigger_key, int $recipient_id, array $context, string $dedupe_key ): void {
		try {
			$resolver  = new RecipientResolver();
			$course_id = absint( $context['course_id'] ?? 0 );

			if ( 'course_access_expired' === $trigger_key && $course_id > 0 && ! self::is_course_access_expired( $recipient_id, $course_id ) ) {
				return;
			}

			if ( $course_id > 0 && ! in_array( $trigger_key, array( 'course_access_expired', 'cancel_enrollment' ), true ) && ! $resolver->is_enrolled( $recipient_id, $course_id ) ) {
				return;
			}

			if ( ! self::is_target_still_current( $trigger_key, $recipient_id, $context ) ) {
				return;
			}

			( new Dispatcher() )->dispatch( $trigger_key, array( $recipient_id ), $context, $dedupe_key );
		} catch ( \Throwable $error ) {
			return;
		}
	}

	public static function run_target( string $trigger_key, string $target_type, int $target_value, array $context, string $dedupe_key ): void {
		try {
			if ( ! self::is_target_still_current( $trigger_key, 0, $context ) ) {
				return;
			}

			if ( 'course_students' !== $target_type ) {
				return;
			}

			( new Dispatcher() )->dispatch_to_course_students( $trigger_key, $target_value, $context, $dedupe_key );
		} catch ( \Throwable $error ) {
			return;
		}
	}

	private static function is_course_access_expired( int $user_id, int $course_id ): bool {
		if ( ! class_exists( 'STM_LMS_Course' ) || ! class_exists( 'STM_LMS_Helpers' ) || ! function_exists( 'stm_lms_get_user_course' ) ) {
			return false;
		}

		$duration = (int) \STM_LMS_Course::get_course_duration_time( $course_id );

		if ( $duration <= 0 ) {
			return false;
		}

		$user_course = \STM_LMS_Helpers::simplify_db_array( stm_lms_get_user_course( $user_id, $course_id, array( 'start_time' ) ) );
		$start_time  = absint( $user_course['start_time'] ?? 0 );

		return $start_time > 0 && time() >= ( $start_time + $duration );
	}

	private static function is_target_still_current( string $trigger_key, int $recipient_id, array $context ): bool {
		$target_timestamp = absint( $context['target_timestamp'] ?? 0 );

		if ( $target_timestamp <= 0 ) {
			return true;
		}

		if ( 'course_access_expired' === $trigger_key ) {
			$current_timestamp = self::current_course_expiration_timestamp( $recipient_id, absint( $context['course_id'] ?? 0 ) );

			return $current_timestamp > 0 && $current_timestamp === $target_timestamp;
		}

		if ( 'assignment_deadline_approaching' === $trigger_key ) {
			$user_assignment_id = absint( $context['user_assignment_id'] ?? 0 );

			if ( ! class_exists( 'STM_LMS_Helpers' ) || ! function_exists( 'stm_lms_get_user_assignments_time' ) || ! function_exists( 'masterstudy_lms_assignment_parse_time_to_timestamp' ) || $user_assignment_id <= 0 ) {
				return false;
			}

			$timer = \STM_LMS_Helpers::simplify_db_array( stm_lms_get_user_assignments_time( $recipient_id, $user_assignment_id, array( 'end_time' ) ) );

			return absint( masterstudy_lms_assignment_parse_time_to_timestamp( (string) ( $timer['end_time'] ?? '' ) ) ) === $target_timestamp;
		}

		$current_timestamp = self::current_item_timestamp( $trigger_key, absint( $context['item_id'] ?? 0 ), absint( $context['course_id'] ?? 0 ) );

		return $current_timestamp > 0 && abs( $current_timestamp - $target_timestamp ) <= 60;
	}

	private static function current_course_expiration_timestamp( int $user_id, int $course_id ): int {
		if ( $user_id <= 0 || $course_id <= 0 || ! class_exists( 'STM_LMS_Course' ) || ! class_exists( 'STM_LMS_Helpers' ) || ! function_exists( 'stm_lms_get_user_course' ) ) {
			return 0;
		}

		$duration = (int) \STM_LMS_Course::get_course_duration_time( $course_id );

		if ( $duration <= 0 ) {
			return 0;
		}

		$user_course = \STM_LMS_Helpers::simplify_db_array( stm_lms_get_user_course( $user_id, $course_id, array( 'start_time' ) ) );
		$start_time  = absint( $user_course['start_time'] ?? 0 );

		return $start_time > 0 ? $start_time + $duration : 0;
	}

	private static function current_item_timestamp( string $trigger_key, int $item_id, int $course_id ): int {
		if ( $item_id <= 0 ) {
			return 0;
		}

		if ( 'live_lesson_starting_soon' === $trigger_key && class_exists( 'STM_LMS_Live_Streams' ) ) {
			return absint( \STM_LMS_Live_Streams::stream_start_time( $item_id ) );
		}

		if ( 'lesson_now_available' === $trigger_key && class_exists( 'STM_LMS_Sequential_Drip_Content' ) ) {
			return absint( \STM_LMS_Sequential_Drip_Content::lesson_start_time( $item_id, $course_id ) );
		}

		if ( 'meeting_starting_soon' === $trigger_key ) {
			if ( 'stm-google-meets' === get_post_type( $item_id ) && function_exists( 'masterstudy_lms_google_meet_start_time' ) ) {
				return absint( masterstudy_lms_google_meet_start_time( $item_id ) );
			}

			if ( class_exists( 'MSLMS_StmZoom' ) ) {
				$data = \MSLMS_StmZoom::meeting_time_data( $item_id );

				return absint( $data['meeting_date'] ?? 0 );
			}
		}

		return 0;
	}
}
