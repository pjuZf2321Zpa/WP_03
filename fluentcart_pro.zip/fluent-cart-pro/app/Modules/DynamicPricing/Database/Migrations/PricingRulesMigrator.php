<?php

namespace FluentCartPro\App\Modules\DynamicPricing\Database\Migrations;

use FluentCartPro\App\Database\Migrations\DropTable;

class PricingRulesMigrator
{
    use DropTable;

    public static $tableName = 'fct_pricing_rules';

    /**
     * Migrate the table.
     *
     * @return void
     */
    public static function migrate()
    {
        global $wpdb;

        $charsetCollate = $wpdb->get_charset_collate();
        $table = static::getTableName();

        if ($wpdb->get_var("SHOW TABLES LIKE '$table'") != $table) {
            $sql = "CREATE TABLE $table (
                `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                `name` VARCHAR(191) NOT NULL,
                `display_name` VARCHAR(191) NOT NULL,
                `rule_type` VARCHAR(50) NOT NULL COMMENT 'identifies which pricing handler processes this rule, e.g. scratch, free_shipping',
                `price_type` VARCHAR(50) NOT NULL DEFAULT 'discount' COMMENT 'discount / fee',
                `status` VARCHAR(50) NOT NULL DEFAULT 'active',
                `config` JSON DEFAULT NULL,
                `applies_to` VARCHAR(50) NOT NULL COMMENT 'checkout / line_item / shipping',
                `start_date` DATETIME NULL COMMENT 'when this rule becomes active, null = immediately',
                `end_date` DATETIME NULL COMMENT 'when this rule expires, null = never',
                `created_at` DATETIME NULL,
                `updated_at` DATETIME NULL,
                PRIMARY KEY  (`id`),
                KEY `rule_type` (`rule_type`),
                KEY `price_type` (`price_type`),
                KEY `status` (`status`),
                KEY `applies_to` (`applies_to`)
            ) $charsetCollate;";
            dbDelta($sql);
        }
    }
}
