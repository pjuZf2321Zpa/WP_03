<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Actions\MoreConvertWishlist\MoreConvertWishlistRecordHelper;
use BitApps\IntegrationsPro\Config;
use BitApps\IntegrationsPro\Core\Util\Hooks;

Hooks::filter(Config::withFreePrefix('more_convert_wishlist_create_wishlist'), [MoreConvertWishlistRecordHelper::class, 'createWishlist'], 10, 3);
Hooks::filter(Config::withFreePrefix('more_convert_wishlist_update_wishlist'), [MoreConvertWishlistRecordHelper::class, 'updateWishlist'], 10, 3);
Hooks::filter(Config::withFreePrefix('more_convert_wishlist_delete_wishlist'), [MoreConvertWishlistRecordHelper::class, 'deleteWishlist'], 10, 2);
Hooks::filter(Config::withFreePrefix('more_convert_wishlist_add_product_to_wishlist'), [MoreConvertWishlistRecordHelper::class, 'addProductToWishlist'], 10, 3);
Hooks::filter(Config::withFreePrefix('more_convert_wishlist_remove_product_from_wishlist'), [MoreConvertWishlistRecordHelper::class, 'removeProductFromWishlist'], 10, 3);
Hooks::filter(Config::withFreePrefix('more_convert_wishlist_create_customer'), [MoreConvertWishlistRecordHelper::class, 'createCustomer'], 10, 3);
Hooks::filter(Config::withFreePrefix('more_convert_wishlist_subscribe_customer'), [MoreConvertWishlistRecordHelper::class, 'subscribeCustomer'], 10, 2);
Hooks::filter(Config::withFreePrefix('more_convert_wishlist_unsubscribe_customer'), [MoreConvertWishlistRecordHelper::class, 'unsubscribeCustomer'], 10, 2);
