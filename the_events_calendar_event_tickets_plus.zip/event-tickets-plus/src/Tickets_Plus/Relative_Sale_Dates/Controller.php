<?php
/**
 * The controller of Event Tickets Plus' part of the Relative Sale Dates feature.
 *
 * @since 6.12.0
 *
 * @package TEC\Tickets_Plus\Relative_Sale_Dates
 */

namespace TEC\Tickets_Plus\Relative_Sale_Dates;

use TEC\Common\Contracts\Provider\Controller as Controller_Contract;
use TEC\Tickets_Plus\Ticket_Presets\Controller as Ticket_Presets_Controller;

/**
 * Brings Event Tickets' relative sale dates to the features of this plugin.
 *
 * Registered only once Event Tickets registers its Relative Sale Dates controller, so nothing here runs while the
 * feature is off.
 *
 * @since 6.12.0
 *
 * @package TEC\Tickets_Plus\Relative_Sale_Dates
 */
final class Controller extends Controller_Contract {
	/**
	 * Unregisters the controller and the ones it registered.
	 *
	 * @since 6.12.0
	 *
	 * @return void
	 */
	public function unregister(): void {
		if ( Ticket_Presets\Controller::is_registered() ) {
			$this->container->get( Ticket_Presets\Controller::class )->unregister();
		}

		if ( WooCommerce\Controller::is_registered() ) {
			$this->container->get( WooCommerce\Controller::class )->unregister();
		}
	}

	/**
	 * Registers the controller.
	 *
	 * @since 6.12.0
	 *
	 * @return void
	 */
	protected function do_register(): void {
		$this->container->register_on_action( Ticket_Presets_Controller::$registration_action, Ticket_Presets\Controller::class );
		$this->container->register_on_action( 'woocommerce_loaded', WooCommerce\Controller::class );
	}
}
