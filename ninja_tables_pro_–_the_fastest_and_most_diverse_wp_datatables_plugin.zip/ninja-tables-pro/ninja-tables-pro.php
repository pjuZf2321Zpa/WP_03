<?php defined('ABSPATH') or die;

/**
Plugin Name: Ninja Tables Pro
Description: The Pro Add-On of Ninja Tables, the best Responsive Table Plugin for WordPress.
Version: 5.5.1
Author: WPManageNinja
Author URI: https://ninjatables.com/
Plugin URI: https://wpmanageninja.com/downloads/ninja-tables-pro-add-on/
License: GPLv2 or later
Text Domain: ninja-tables-pro
Domain Path: /language
*/

if (defined('NINJAPRO_PLUGIN_FILE')) {
    return;
}

define('NINJAPRO_PLUGIN_FILE', __FILE__);
defined('NINJAPROPLUGIN_VERSION') or define('NINJAPROPLUGIN_VERSION', '5.5.1');
defined('NINJA_TABLE_PLUGIN_MIN_CORE_VERSION') or define('NINJA_TABLE_PLUGIN_MIN_CORE_VERSION', '5.5.1');
define('NINJA_TABLE_PRO_FRAMEWORK_VERSION', '2');

update_option('_ninjatables_pro_license_key', '1415B451BE1A13C283BA771EA52D38BB');
update_option('_ninjatables_pro_license_status', 'valid');
add_filter('pre_http_request', function($pre, $args, $url) {
    if (strpos($url, 'api3.wpmanageninja.com/plugin') !== false && isset($args['body']['item_id']) && $args['body']['item_id'] == '273') {
        return array('response' => array('code' => 200), 'body' => json_encode(array('license' => 'valid', 'expires' => 'lifetime', 'success' => true)));
    }
    return $pre;
}, 10, 3);

require_once plugin_dir_path(__FILE__). 'ninja-tables-pro-boot.php';

add_action('ninjatables_loaded', function ($app) {
    (new \NinjaTablesPro\App\Application($app));
    do_action('ninjatables_pro_loaded', $app);
});

// Licensing + updates via the FluentCart SDK (replaces the EDD updater).
include NINJAPROPLUGIN_PATH . 'app/Services/PluginManager/init.php';
