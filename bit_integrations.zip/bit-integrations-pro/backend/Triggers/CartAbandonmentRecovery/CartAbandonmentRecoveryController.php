<?php

namespace BitApps\IntegrationsPro\Triggers\CartAbandonmentRecovery;

use BitApps\IntegrationsPro\Config;

final class CartAbandonmentRecoveryController
{
    public static function info()
    {
        return [
            'name'              => 'Cart Abandonment Recovery',
            'type'              => 'custom_form_submission',
            'is_active'         => static::isPluginInstalled(),
            'documentation_url' => '#',
            'tutorial_url'      => '#',
            'tasks'             => [
                'action' => 'cart-abandonment-recovery/get',
                'method' => 'get',
            ],
            'fetch' => [
                'action' => 'trigger/test',
                'method' => 'post',
            ],
            'fetch_remove' => [
                'action' => 'trigger/test/remove',
                'method' => 'post',
            ],
            'isPro' => true,
        ];
    }

    public function getAllTasks()
    {
        if (!static::isPluginInstalled()) {
            wp_send_json_error(\sprintf(__('%s is not installed or activated', 'bit-integrations-pro'), 'Cart Abandonment Recovery'));
        }

        wp_send_json_success([
            ['form_name' => __('Cart Abandonment Data Captured', 'bit-integrations-pro'), 'triggered_entity_id' => 'wcf_ca_after_save_abandonment_data', 'skipPrimaryKey' => true],
            ['form_name' => __('Cart Marked as Abandoned', 'bit-integrations-pro'), 'triggered_entity_id' => 'wcf_ca_process_abandoned_order', 'skipPrimaryKey' => true],
            ['form_name' => __('Recovery Email Sent', 'bit-integrations-pro'), 'triggered_entity_id' => 'wcf_ca_after_email_sent', 'skipPrimaryKey' => true],
            ['form_name' => __('Recovery Coupon Created', 'bit-integrations-pro'), 'triggered_entity_id' => 'wcf_ca_after_coupon_created', 'skipPrimaryKey' => true],
            ['form_name' => __('Unsubscribed from Recovery Emails', 'bit-integrations-pro'), 'triggered_entity_id' => 'wcar_after_unsubscribe_cart_abandonment_emails', 'skipPrimaryKey' => true],
        ]);
    }

    public static function cartAbandonmentDataCaptured($sessionId, $checkoutDetails)
    {
        if (!static::isPluginInstalled() || empty($sessionId)) {
            return;
        }

        $data = [
            'session_id'       => $sessionId,
            'checkout_details' => static::extractObjectAttributes($checkoutDetails),
        ];

        return static::flowExecute('wcf_ca_after_save_abandonment_data', $data);
    }

    public static function cartMarkedAsAbandoned($checkoutDetails)
    {
        if (!static::isPluginInstalled() || empty($checkoutDetails)) {
            return;
        }

        return static::flowExecute('wcf_ca_process_abandoned_order', [
            'checkout_details' => static::extractObjectAttributes($checkoutDetails),
        ]);
    }

    public static function recoveryEmailSent($emailData, $mailType)
    {
        if (!static::isPluginInstalled() || empty($emailData)) {
            return;
        }

        $data = [
            'email_data' => static::extractObjectAttributes($emailData),
            'mail_type'  => $mailType,
        ];

        return static::flowExecute('wcf_ca_after_email_sent', $data);
    }

    public static function recoveryCouponCreated($couponCode, $newCouponId)
    {
        if (!static::isPluginInstalled() || empty($couponCode)) {
            return;
        }

        $data = [
            'coupon_code' => $couponCode,
            'coupon_id'   => $newCouponId,
        ];

        return static::flowExecute('wcf_ca_after_coupon_created', $data);
    }

    public static function unsubscribedFromRecoveryEmails($tokenData)
    {
        if (!static::isPluginInstalled() || empty($tokenData)) {
            return;
        }

        $data = ['token_data' => $tokenData];

        return static::flowExecute('wcar_after_unsubscribe_cart_abandonment_emails', $data);
    }

    private static function flowExecute($triggeredEntityId, $data)
    {
        if (empty($data) || !\is_array($data)) {
            return;
        }

        $helperClass = bit_integrations_get_class('Core\\Util\\Helper');
        $flowClass = bit_integrations_get_class('Flow\\Flow');
        $formData = $helperClass::prepareFetchFormatFields($data);

        if (empty($formData) || !\is_array($formData)) {
            return;
        }

        $helperClass::setTestData(Config::withFreePrefix("{$triggeredEntityId}_test"), array_values($formData));

        $flows = $flowClass::exists('CartAbandonmentRecovery', $triggeredEntityId);
        if (empty($flows)) {
            return;
        }

        $flowClass::execute('CartAbandonmentRecovery', $triggeredEntityId, array_column($formData, 'value', 'name'), $flows);

        return ['type' => 'success'];
    }

    private static function extractObjectAttributes($object)
    {
        if (!\is_object($object)) {
            return $object;
        }

        if (method_exists($object, 'getAttributes')) {
            return (array) $object->getAttributes();
        }

        if (method_exists($object, 'toArray')) {
            return $object->toArray();
        }

        return (array) get_object_vars($object);
    }

    private static function isPluginInstalled()
    {
        return \defined('CARTFLOWS_CA_FILE');
    }
}
