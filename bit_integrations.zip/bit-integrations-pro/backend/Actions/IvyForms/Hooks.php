<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Actions\IvyForms\IvyFormsRecordHelper;
use BitApps\IntegrationsPro\Config;
use BitApps\IntegrationsPro\Core\Util\Hooks;

Hooks::filter(Config::withFreePrefix('ivy_forms_create_entry'), [IvyFormsRecordHelper::class, 'createEntry'], 10, 3);
