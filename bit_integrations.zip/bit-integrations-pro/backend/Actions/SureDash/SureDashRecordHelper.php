<?php

namespace BitApps\IntegrationsPro\Actions\SureDash;

final class SureDashRecordHelper
{
    private const BOOKMARK_META_KEY = 'portal_bookmarked_items';

    private const POST_LIKES_META_KEY = 'portal_post_likes';

    private const COMMENT_LIKES_META_KEY = 'portal_comment_likes';

    private const ENTITY_META_MAP = [
        'post'    => self::POST_LIKES_META_KEY,
        'comment' => self::COMMENT_LIKES_META_KEY,
    ];

    public static function createPost($response, $fieldData, $integrationDetails = null)
    {
        $error = self::ensurePluginActive('SUREDASHBOARD_FEED_POST_TYPE', 'SUREDASHBOARD_FEED_TAXONOMY');
        if ($error) {
            return $error;
        }

        $spaceId = (isset($integrationDetails) && isset($integrationDetails->selectedSpaceId)) ? (int) $integrationDetails->selectedSpaceId : null;

        if (empty($fieldData['postTitle']) || empty($spaceId)) {
            return ['success' => false, 'message' => __('postTitle and spaceId are required.', 'bit-integrations-pro')];
        }

        $newPostId = wp_insert_post(
            [
                'post_title'   => $fieldData['postTitle'],
                'post_content' => $fieldData['postContent'] ?? '',
                'post_type'    => SUREDASHBOARD_FEED_POST_TYPE,
                'post_status'  => $fieldData['postStatus'] ?? 'publish',
                'post_author'  => get_current_user_id(),
            ],
            true
        );

        if (is_wp_error($newPostId)) {
            return ['success' => false, 'message' => $newPostId->get_error_message()];
        }

        $feedGroupId = self::getFeedGroupId($spaceId);
        if ($feedGroupId) {
            wp_set_post_terms($newPostId, [(int) $feedGroupId], SUREDASHBOARD_FEED_TAXONOMY);
        }

        return [
            'success' => true,
            'message' => __('Post created successfully.', 'bit-integrations-pro'),
            'data'    => (array) get_post($newPostId),
        ];
    }

    public static function deletePost($response, $fieldData)
    {
        $error = self::ensurePluginActive('SUREDASHBOARD_FEED_POST_TYPE');
        if ($error) {
            return $error;
        }

        if (empty($fieldData['postId'])) {
            return ['success' => false, 'message' => __('postId is required.', 'bit-integrations-pro')];
        }

        $postId = (int) $fieldData['postId'];
        $post = get_post($postId);

        if (!$post || $post->post_type !== SUREDASHBOARD_FEED_POST_TYPE) {
            return ['success' => false, 'message' => __('Post not found.', 'bit-integrations-pro')];
        }

        $deleted = wp_delete_post($postId, true);

        if (!$deleted) {
            return ['success' => false, 'message' => __('Failed to delete the post.', 'bit-integrations-pro')];
        }

        return ['success' => true, 'message' => __('Post deleted successfully.', 'bit-integrations-pro')];
    }

    public static function createComment($response, $fieldData, $integrationDetails = null)
    {
        $error = self::ensurePluginActive('SUREDASHBOARD_FEED_POST_TYPE');
        if ($error) {
            return $error;
        }

        $postId = (isset($integrationDetails) && isset($integrationDetails->selectedPostId)) ? (int) $integrationDetails->selectedPostId : 0;

        if (empty($postId) || empty($fieldData['commentContent'])) {
            return ['success' => false, 'message' => __('postId and commentContent are required.', 'bit-integrations-pro')];
        }

        $post = get_post($postId);

        if (!$post || $post->post_type !== SUREDASHBOARD_FEED_POST_TYPE) {
            return ['success' => false, 'message' => __('Post not found.', 'bit-integrations-pro')];
        }

        $commentId = wp_insert_comment(
            [
                'comment_post_ID'  => $postId,
                'comment_content'  => (string) $fieldData['commentContent'],
                'user_id'          => get_current_user_id(),
                'comment_approved' => 1,
            ]
        );

        if (!$commentId) {
            return ['success' => false, 'message' => __('Failed to create the comment.', 'bit-integrations-pro')];
        }

        $comment = get_comment($commentId);

        return [
            'success' => true,
            'message' => __('Comment created successfully.', 'bit-integrations-pro'),
            'data'    => $comment ? (array) $comment : ['comment_ID' => $commentId],
        ];
    }

    public static function deleteComment($response, $fieldData)
    {
        if (empty($fieldData['commentId'])) {
            return ['success' => false, 'message' => __('commentId is required.', 'bit-integrations-pro')];
        }

        $commentId = (int) $fieldData['commentId'];
        $comment = get_comment($commentId);

        if (!$comment) {
            return ['success' => false, 'message' => __('Comment not found.', 'bit-integrations-pro')];
        }

        $deleted = wp_delete_comment($commentId, true);

        if (!$deleted) {
            return ['success' => false, 'message' => __('Failed to delete the comment.', 'bit-integrations-pro')];
        }

        return ['success' => true, 'message' => __('Comment deleted successfully.', 'bit-integrations-pro')];
    }

    public static function updateUserProfile($response, $fieldData)
    {
        if (empty($fieldData['userEmail'])) {
            return ['success' => false, 'message' => __('User Email is required.', 'bit-integrations-pro')];
        }

        $userId = self::resolveUserId($fieldData['userEmail']);
        if (!$userId) {
            return ['success' => false, 'message' => __('User not found.', 'bit-integrations-pro')];
        }

        $allowedFields = ['first_name', 'last_name', 'nickname', 'description', 'user_url', 'display_name', 'user_email', 'user_pass'];
        $updateData = array_intersect_key($fieldData, array_flip($allowedFields));
        $updateData['ID'] = $userId;

        if (\count($updateData) === 1) {
            return ['success' => false, 'message' => __('No profile fields provided to update.', 'bit-integrations-pro')];
        }

        $result = wp_update_user($updateData);

        if (is_wp_error($result)) {
            return ['success' => false, 'message' => $result->get_error_message()];
        }

        return [
            'success' => true,
            'message' => __('User profile updated successfully.', 'bit-integrations-pro'),
            'data'    => self::safeUserData($userId),
        ];
    }

    public static function bookmarkItem($response, $fieldData)
    {
        if (empty($fieldData['itemId']) || empty($fieldData['itemType']) || empty($fieldData['userEmail'])) {
            return ['success' => false, 'message' => __('itemId, itemType, and userEmail are required.', 'bit-integrations-pro')];
        }

        $itemId = (int) $fieldData['itemId'];
        $itemType = $fieldData['itemType'];
        $userId = self::resolveUserId($fieldData['userEmail']);

        if (!$userId) {
            return ['success' => false, 'message' => __('User not found.', 'bit-integrations-pro')];
        }

        $itemError = self::validateBookmarkItem($itemId, $itemType);
        if ($itemError) {
            return $itemError;
        }

        $bookmarked = get_user_meta($userId, self::BOOKMARK_META_KEY, true);
        $bookmarked = \is_array($bookmarked) ? $bookmarked : [];

        if (isset($bookmarked[$itemId])) {
            $status = 'un-bookmarked';
            unset($bookmarked[$itemId]);
        } else {
            $status = 'bookmarked';
            $bookmarked[$itemId] = $itemType;
        }

        self::updateUserMeta($userId, self::BOOKMARK_META_KEY, $bookmarked);

        do_action('suredash_item_bookmark', $itemId, $itemType, $status, $userId);

        return [
            'success' => true,
            'message' => __('Item bookmark status updated.', 'bit-integrations-pro'),
            'data'    => ['status' => $status, 'item_id' => $itemId, 'item_type' => $itemType],
        ];
    }

    public static function reactToEntity($response, $fieldData)
    {
        if (empty($fieldData['entityId']) || empty($fieldData['entityType']) || empty($fieldData['userEmail'])) {
            return ['success' => false, 'message' => __('entityId, entityType, and userEmail are required.', 'bit-integrations-pro')];
        }

        $entityId = (int) $fieldData['entityId'];
        $entityType = $fieldData['entityType'];
        $userId = self::resolveUserId($fieldData['userEmail']);

        if (!$userId) {
            return ['success' => false, 'message' => __('User not found.', 'bit-integrations-pro')];
        }

        $metaKey = self::entityMetaKey($entityType);
        if ($metaKey === null) {
            return ['success' => false, 'message' => __('Invalid entity type.', 'bit-integrations-pro')];
        }

        $entityError = self::validateReactionEntity($entityId, $entityType);
        if ($entityError) {
            return $entityError;
        }

        $likes = self::getEntityLikes($entityId, $entityType, $metaKey);
        [$likes, $likeStatus] = self::toggleEntityLike($likes, $userId);
        self::updateEntityLikes($entityId, $entityType, $likes, $metaKey);

        do_action('suredash_entity_like_reaction', $entityId, $entityType, $likeStatus, $userId);

        return [
            'success' => true,
            'message' => __('Reaction updated.', 'bit-integrations-pro'),
            'data'    => ['like_status' => $likeStatus, 'entity_id' => $entityId, 'entity_type' => $entityType, 'user_id' => $userId],
        ];
    }

    private static function ensurePluginActive(string ...$constants): ?array
    {
        foreach ($constants as $constant) {
            if (!\defined($constant)) {
                return ['success' => false, 'message' => __('SureDash plugin is not active.', 'bit-integrations-pro')];
            }
        }

        return null;
    }

    private static function resolveUserId(string $email): ?int
    {
        $user = get_user_by('email', $email);

        return $user ? (int) $user->ID : null;
    }

    private static function entityMetaKey(string $entityType): ?string
    {
        return self::ENTITY_META_MAP[$entityType] ?? null;
    }

    private static function validateBookmarkItem(int $itemId, string $itemType): ?array
    {
        if ($itemType === 'community-post') {
            if (!\defined('SUREDASHBOARD_FEED_POST_TYPE')) {
                return ['success' => false, 'message' => __('Post type not found.', 'bit-integrations-pro')];
            }

            $post = get_post($itemId);
            if (!$post || $post->post_type !== SUREDASHBOARD_FEED_POST_TYPE) {
                return ['success' => false, 'message' => __('Post not found.', 'bit-integrations-pro')];
            }

            return null;
        }

        if ($itemType !== 'portal') {
            return ['success' => false, 'message' => __('Invalid item type provided.', 'bit-integrations-pro')];
        }

        if (!\defined('SUREDASHBOARD_POST_TYPE')) {
            return ['success' => false, 'message' => __('Space type not found.', 'bit-integrations-pro')];
        }

        $space = get_post($itemId);
        if (!$space || $space->post_type !== SUREDASHBOARD_POST_TYPE) {
            return ['success' => false, 'message' => __('Space not found.', 'bit-integrations-pro')];
        }

        return null;
    }

    private static function validateReactionEntity(int $entityId, string $entityType): ?array
    {
        if ($entityType === 'post') {
            if (!\defined('SUREDASHBOARD_FEED_POST_TYPE')) {
                return ['success' => false, 'message' => __('Post type not found.', 'bit-integrations-pro')];
            }

            $post = get_post($entityId);
            if (!$post || $post->post_type !== SUREDASHBOARD_FEED_POST_TYPE) {
                return ['success' => false, 'message' => __('Post not found.', 'bit-integrations-pro')];
            }

            return null;
        }

        $comment = get_comment($entityId);
        if (!$comment) {
            return ['success' => false, 'message' => __('Comment not found.', 'bit-integrations-pro')];
        }

        return null;
    }

    private static function getFeedGroupId(int $spaceId)
    {
        if (\function_exists('sd_get_post_meta')) {
            return sd_get_post_meta($spaceId, 'feed_group_id', true);
        }

        return get_post_meta($spaceId, 'feed_group_id', true);
    }

    private static function getEntityLikes(int $entityId, string $entityType, string $metaKey): array
    {
        if ($entityType === 'post') {
            $likes = get_post_meta($entityId, $metaKey, true);
        } else {
            $likes = get_comment_meta($entityId, $metaKey, true);
        }

        return \is_array($likes) ? $likes : [];
    }

    private static function toggleEntityLike(array $likes, int $userId): array
    {
        $userKey = array_search($userId, $likes, true);

        if ($userKey !== false) {
            unset($likes[$userKey]);

            return [array_values($likes), 'unliked'];
        }

        $likes[] = $userId;

        return [$likes, 'liked'];
    }

    private static function updateEntityLikes(int $entityId, string $entityType, array $likes, string $metaKey): void
    {
        if ($entityType === 'post') {
            update_post_meta($entityId, $metaKey, $likes);
        } else {
            update_comment_meta($entityId, $metaKey, $likes);
        }
    }

    private static function updateUserMeta(int $userId, string $metaKey, array $metaValue): void
    {
        if (\function_exists('sd_update_user_meta')) {
            sd_update_user_meta($userId, $metaKey, $metaValue);
        } else {
            update_user_meta($userId, $metaKey, $metaValue);
        }
    }

    private static function safeUserData(int $userId): array
    {
        $user = get_userdata($userId);
        if (!$user) {
            return ['user_id' => $userId];
        }

        return [
            'user_id'      => (int) $user->ID,
            'user_login'   => (string) $user->user_login,
            'display_name' => (string) $user->display_name,
            'first_name'   => (string) $user->first_name,
            'last_name'    => (string) $user->last_name,
            'user_email'   => (string) $user->user_email,
            'roles'        => \is_array($user->roles) ? $user->roles : [],
        ];
    }
}
