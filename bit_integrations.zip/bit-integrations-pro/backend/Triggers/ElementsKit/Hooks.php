<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Core\Util\Hooks;
use BitApps\IntegrationsPro\Triggers\ElementsKit\ElementsKitController;

Hooks::add('save_post_elementskit_template', [ElementsKitController::class, 'handleTemplateCreated'], 20, 3);
Hooks::add('save_post_elementskit_template', [ElementsKitController::class, 'handleTemplateUpdated'], 20, 3);
Hooks::add('transition_post_status', [ElementsKitController::class, 'handleTemplateStatusChanged'], 20, 3);
Hooks::add('save_post_elementskit_widget', [ElementsKitController::class, 'handleWidgetCreated'], 20, 3);
Hooks::add('save_post_elementskit_widget', [ElementsKitController::class, 'handleWidgetUpdated'], 20, 3);
Hooks::add('save_post_elementskit_content', [ElementsKitController::class, 'handleContentCreated'], 20, 3);
Hooks::add('save_post_elementskit_content', [ElementsKitController::class, 'handleContentUpdated'], 20, 3);
Hooks::add('wp_trash_post', [ElementsKitController::class, 'handleTemplateTrashed'], 20, 1);
Hooks::add('wp_trash_post', [ElementsKitController::class, 'handleWidgetTrashed'], 20, 1);
Hooks::add('wp_trash_post', [ElementsKitController::class, 'handleContentTrashed'], 20, 1);
Hooks::add('before_delete_post', [ElementsKitController::class, 'handleTemplateDeleted'], 20, 2);
Hooks::add('before_delete_post', [ElementsKitController::class, 'handleWidgetDeleted'], 20, 2);
Hooks::add('before_delete_post', [ElementsKitController::class, 'handleContentDeleted'], 20, 2);
