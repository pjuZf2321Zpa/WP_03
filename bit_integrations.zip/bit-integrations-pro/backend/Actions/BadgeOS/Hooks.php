<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Actions\BadgeOS\BadgeOSProHelper;
use BitApps\IntegrationsPro\Config;
use BitApps\IntegrationsPro\Core\Util\Hooks;

Hooks::filter(Config::withFreePrefix('badgeos_award_achievement_to_user'), [BadgeOSProHelper::class, 'awardAchievementToUser'], 10, 3);
