<?php

namespace BitApps\IntegrationsPro\Actions\NotificationX;

use Exception;
use NotificationX\Admin\Entries;
use NotificationX\Core\Database;
use NotificationX\Core\PostType;

class NotificationXProHelper
{
    public static function deleteNotification($defaultResponse, $notificationId)
    {
        if (!class_exists('NotificationX\Core\Database')) {
            return self::errorResponse(__('NotificationX Database class not found.', 'bit-integrations-pro'));
        }

        if (empty($notificationId)) {
            return self::errorResponse(__('Notification ID is required.', 'bit-integrations-pro'));
        }

        try {
            global $wpdb;
            $table = Database::$table_posts;
            $deleted = $wpdb->delete($table, ['nx_id' => $notificationId]);

            if (!$deleted) {
                return self::errorResponse(__('Failed to delete notification.', 'bit-integrations-pro'));
            }

            return self::successResponse(
                __('Notification deleted successfully', 'bit-integrations-pro'),
                ['notification_id' => $notificationId]
            );
        } catch (Exception $e) {
            return self::errorResponse($e->getMessage());
        }
    }

    public static function enableNotification($defaultResponse, $notificationId)
    {
        return self::toggleNotificationStatus($notificationId, true);
    }

    public static function disableNotification($defaultResponse, $notificationId)
    {
        return self::toggleNotificationStatus($notificationId, false);
    }

    public static function addNotificationEntry($defaultResponse, $payload)
    {
        return self::executeInsertEntry($defaultResponse, $payload);
    }

    public static function addSalesNotification($defaultResponse, $payload)
    {
        return self::executeInsertEntry($defaultResponse, $payload);
    }

    public static function addReviews($defaultResponse, $payload)
    {
        return self::executeInsertEntry($defaultResponse, $payload);
    }

    public static function addEmailSubscription($defaultResponse, $payload)
    {
        return self::executeInsertEntry($defaultResponse, $payload);
    }

    private static function executeInsertEntry($defaultResponse, $payload)
    {
        if (!class_exists('NotificationX\Admin\Entries') || !class_exists('NotificationX\Core\PostType')) {
            return self::errorResponse(__('NotificationX required classes not found.', 'bit-integrations-pro'));
        }

        $notificationId = isset($payload['notification_id']) ? absint($payload['notification_id']) : 0;

        if (empty($notificationId)) {
            return self::errorResponse(__('Notification ID is required.', 'bit-integrations-pro'));
        }

        $entryData = isset($payload['entry_data']) && \is_array($payload['entry_data'])
            ? $payload['entry_data']
            : [];

        try {
            $notification = PostType::get_instance()->get_post($notificationId);

            if (!$notification) {
                return self::errorResponse(__('Notification not found.', 'bit-integrations-pro'));
            }

            $source = isset($notification['source']) ? $notification['source'] : '';

            $entry = [
                'nx_id'     => $notificationId,
                'source'    => $source,
                'entry_key' => $source . '_' . $notificationId,
                'data'      => $entryData,
            ];

            $inserted = Entries::get_instance()->insert_entry($entry);

            if (!$inserted) {
                return self::errorResponse(__('Failed to add notification entry.', 'bit-integrations-pro'));
            }

            return self::successResponse(
                __('Notification entry added successfully', 'bit-integrations-pro'),
                ['notification' => $notification, 'entry_data' => $entryData]
            );
        } catch (Exception $e) {
            return self::errorResponse($e->getMessage());
        }
    }

    private static function toggleNotificationStatus($notificationId, $enable)
    {
        if (!class_exists('NotificationX\Core\Database')) {
            return self::errorResponse(__('NotificationX Database class not found.', 'bit-integrations-pro'));
        }

        if (empty($notificationId)) {
            return self::errorResponse(__('Notification ID is required.', 'bit-integrations-pro'));
        }

        try {
            global $wpdb;
            $table = Database::$table_posts;
            $data = [
                'enabled'    => $enable ? 1 : 0,
                'updated_at' => current_time('mysql'),
            ];

            $updated = $wpdb->update($table, $data, ['nx_id' => $notificationId]);

            if (!$updated) {
                $statusLabel = $enable ? __('enable', 'bit-integrations-pro') : __('disable', 'bit-integrations-pro');

                return self::errorResponse(
                    // translators: %s: enable/disable status label
                    \sprintf(__('Failed to %s notification.', 'bit-integrations-pro'), $statusLabel)
                );
            }

            $statusMsg = $enable
                ? __('Notification enabled successfully', 'bit-integrations-pro')
                : __('Notification disabled successfully', 'bit-integrations-pro');

            return self::successResponse($statusMsg, ['notification_id' => $notificationId, 'enabled' => $enable]);
        } catch (Exception $e) {
            return self::errorResponse($e->getMessage());
        }
    }

    private static function successResponse($message, $data = [])
    {
        return [
            'success' => true,
            'message' => $message,
            'data'    => $data,
        ];
    }

    private static function errorResponse($message)
    {
        return [
            'success' => false,
            'message' => $message,
        ];
    }
}
