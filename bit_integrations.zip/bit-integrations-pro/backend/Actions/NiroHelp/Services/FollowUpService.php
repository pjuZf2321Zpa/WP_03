<?php

namespace BitApps\IntegrationsPro\Actions\NiroHelp\Services;

use BitApps\IntegrationsPro\Actions\NiroHelp\NiroHelpHelper;
use BitApps\IntegrationsPro\Core\Util\DateTimeHelper;
use DateTimeImmutable;
use NiroHelp\Models\Ticket;

if (!\defined('ABSPATH')) {
    exit;
}

final class FollowUpService extends BaseService
{
    private const MAX_DAYS = 730;

    public function setFollowUp(): array
    {
        $error = $this->validateRequiredFields([
            'ticket_id' => __('Ticket ID', 'bit-integrations-pro'),
            'note'      => __('Note', 'bit-integrations-pro'),
        ]);

        if ($error !== null) {
            return $error;
        }

        $note = trim(str_replace(["\r\n", "\r"], "\n", $this->getString('note')));

        if (mb_strlen($note) > Ticket::FOLLOWUP_NOTE_LIMIT) {
            // translators: %d: maximum number of characters
            return $this->errorResponse(\sprintf(__('The note is too long. Write %d characters or less.', 'bit-integrations-pro'), Ticket::FOLLOWUP_NOTE_LIMIT));
        }

        $agentId = (int) $this->getInteger('agent_id');

        if ($agentId > 0 && !$this->isAgent($agentId)) {
            return $this->errorResponse(__('The user cannot set follow-ups. Select a NiroHelp agent.', 'bit-integrations-pro'));
        }

        $ticket = $this->findTicket();

        if (!$ticket) {
            return $this->ticketNotFound();
        }

        $dueDate = $this->getDueDate($ticket);

        if (!$dueDate['valid']) {
            return $this->errorResponse($dueDate['message']);
        }

        $ticket->set_followup($note, $dueDate['date'], $agentId);

        return $this->successResponse(__('The follow-up is set.', 'bit-integrations-pro'), NiroHelpHelper::getTicketData($ticket->get_id()));
    }

    public function clearFollowUp(): array
    {
        $error = $this->validateRequiredFields(['ticket_id' => __('Ticket ID', 'bit-integrations-pro')]);

        if ($error !== null) {
            return $error;
        }

        $ticket = $this->findTicket();

        if (!$ticket) {
            return $this->ticketNotFound();
        }

        $ticket->clear_followup();

        return $this->successResponse(__('The follow-up is cleared.', 'bit-integrations-pro'), NiroHelpHelper::getTicketData($ticket->get_id()));
    }

    private function getDueDate(Ticket $ticket): array
    {
        $hasDate = $this->hasValue('due_date');
        $hasDays = $this->hasValue('days');

        if ($hasDate === $hasDays) {
            return ['valid' => false, 'message' => __('Set the due date or the number of days. Set only one.', 'bit-integrations-pro')];
        }

        if ($hasDays) {
            $days = (int) $this->getInteger('days');

            if ($days < 1 || $days > self::MAX_DAYS) {
                // translators: %d: maximum number of days
                return ['valid' => false, 'message' => \sprintf(__('The number of days is not valid. Use a whole number from 1 to %d.', 'bit-integrations-pro'), self::MAX_DAYS)];
            }

            return ['valid' => true, 'date' => Ticket::due_in_days($days)];
        }

        $dueDate = $this->getString('due_date');
        $parsedDate = DateTimeImmutable::createFromFormat('!Y-m-d', $dueDate, DateTimeHelper::wp_timezone());

        if (!$parsedDate || $parsedDate->format('Y-m-d') !== $dueDate) {
            return ['valid' => false, 'message' => __('The due date is not valid. Use the YYYY-MM-DD format.', 'bit-integrations-pro')];
        }

        if ($dueDate < Ticket::site_today() && $dueDate !== (string) $ticket->get_meta(Ticket::FOLLOWUP_DUE)) {
            return ['valid' => false, 'message' => __('The due date is in the past. Use today or a later date.', 'bit-integrations-pro')];
        }

        if ($dueDate > Ticket::due_in_days(self::MAX_DAYS)) {
            // translators: %d: maximum number of days
            return ['valid' => false, 'message' => \sprintf(__('The due date is too far away. Use a date in the next %d days.', 'bit-integrations-pro'), self::MAX_DAYS)];
        }

        return ['valid' => true, 'date' => $dueDate];
    }
}
