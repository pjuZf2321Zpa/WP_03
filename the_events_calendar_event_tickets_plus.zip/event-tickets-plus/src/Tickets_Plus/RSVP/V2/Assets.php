<?php
/**
 * Handles registering and setup for assets on Tickets Plus RSVP V2.
 *
 * @since 6.11.0
 *
 * @package TEC\Tickets_Plus\RSVP\V2
 */

namespace TEC\Tickets_Plus\RSVP\V2;

use TEC\Common\Contracts\Service_Provider;
use Tribe__Tickets_Plus__Main as Event_Tickets_Plus;

/**
 * Class Assets.
 *
 * @since 6.11.0
 *
 * @package TEC\Tickets_Plus\RSVP\V2
 */
class Assets extends Service_Provider {
	/**
	 * Binds and sets up implementations.
	 *
	 * @since 6.11.0
	 */
	public function register() {
		$this->register_frontend_assets();
		$this->register_admin_assets();
	}

	/**
	 * Register frontend assets for ARI functionality.
	 *
	 * @since 6.11.0
	 *
	 * @return void Frontend assets are registered.
	 */
	protected function register_frontend_assets(): void {
		/** @var Event_Tickets_Plus $tickets_plus_main */
		$tickets_plus_main = tribe( 'tickets-plus.main' );

		tec_asset(
			$tickets_plus_main,
			'tec-tickets-commerce-rsvp-ari',
			'js/commerce/rsvp-ari.js',
			[ 'jquery', 'wp-util', 'tribe-common', 'tribe-tickets-plus-attendee-meta' ],
			null,
			[
				'groups' => 'tec-tickets-commerce-rsvp',
			]
		);
	}

	/**
	 * Register admin assets for IAC functionality.
	 *
	 * Assets are registered only. They are enqueued on demand when the RSVP
	 * Classic Editor metabox renders the IAC UI.
	 *
	 * @since 6.11.0
	 *
	 * @return void Admin assets are registered.
	 */
	protected function register_admin_assets(): void {
		/** @var Event_Tickets_Plus $tickets_plus_main */
		$tickets_plus_main = tribe( 'tickets-plus.main' );

		tec_asset(
			$tickets_plus_main,
			'tribe-tickets-plus-iac-admin',
			'js/commerce/iac-admin.js',
			[ 'jquery', 'tribe-dialog-js', 'jquery-ui-sortable' ],
			null,
			[
				'localize' => [
					'name' => 'tribeIacSettings',
					'data' => static function () {
						return [
							'restUrl'                 => rest_url( 'tribe/tickets/v1/' ),
							'nonce'                   => wp_create_nonce( 'wp_rest' ),
							'buttonTextWithFields'    => esc_html_x( 'Attendee Information', 'Button text when attendee meta fields exist', 'event-tickets-plus' ),
							'buttonTextWithoutFields' => esc_html_x( 'Collect attendee information', 'Button text when no attendee meta fields exist', 'event-tickets-plus' ),
							'editIconTitle'           => esc_attr__( 'Edit Attendee Information', 'event-tickets-plus' ),
							'plusIconTitle'           => esc_attr__( 'Individual Attendee Collection', 'event-tickets-plus' ),
							'saveErrorMessage'        => esc_html__( 'The attendee information could not be saved. Please try again.', 'event-tickets-plus' ),
						];
					},
				],
			]
		);

		tec_asset(
			$tickets_plus_main,
			'tec-tickets-plus-rsvp-iac-css',
			'css/commerce/rsvp-iac.css',
			[ 'tribe-dialog', 'event-tickets-plus-meta-admin-css' ],
			null
		);

		tec_asset(
			$tickets_plus_main,
			'tribe-tickets-plus-attendee-registration-iac',
			'js/commerce/attendee-registration-iac.js',
			[ 'jquery' ],
			null
		);
	}

	/**
	 * Enqueues the IAC admin assets.
	 *
	 * Called when the RSVP metabox renders the IAC UI on Classic Editor screens.
	 *
	 * @since 6.11.0
	 *
	 * @return void
	 */
	public function enqueue_admin_assets(): void {
		tribe_asset_enqueue( 'tribe-tickets-plus-iac-admin' );
		tribe_asset_enqueue( 'tec-tickets-plus-rsvp-iac-css' );
	}

	/**
	 * Enqueues the attendee registration iframe IAC script.
	 *
	 * Called when the block editor renders IAC options in the attendee
	 * registration admin page iframe.
	 *
	 * @since 6.11.0
	 *
	 * @return void
	 */
	public function enqueue_attendee_registration_iac_assets(): void {
		tribe_asset_enqueue( 'tribe-tickets-plus-attendee-registration-iac' );
	}
}
