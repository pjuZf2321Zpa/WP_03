<?php
/**
 * View admin/options/form
 *
 * @var string                                                           $message
 * @var array                                                            $errors
 * @var MeprOptions                                                      $mepr_options
 * @var MemberPress\GroundLevel\Mothership\AbstractPluginConnection       $plugin
 * @var MemberPress\GroundLevel\Mothership\Transients\ActivationTransient $activation_transient
 * @var MemberPress\GroundLevel\Mothership\Manager\LicenseManager         $license_manager
 */

defined('ABSPATH') || exit;

/*
 * Whether the Marketing tab is offered at all.
 *
 * Its only contents are the global auto-responder settings and the
 * integrations list, both of which come from the marketing and CRM modules.
 * A build with those modules stripped has nothing to put in the tab, so it
 * filters this to false and the nav link and pane are both withheld. One
 * value drives both so they cannot fall out of sync.
 */
$show_marketing_options = MeprHooks::apply_filters('mepr_show_marketing_options', true);
?>

<div class="wrap">
  <h1 class="wp-heading-inline"><?php esc_html_e('Settings', 'memberpress'); ?></h1>
  <a href="<?php echo esc_url(MeprUtils::get_link_url('docs')); ?>" class="page-title-action" target="_blank" rel="noopener"><?php esc_html_e('User Manual', 'memberpress'); ?></a>
  <hr class="wp-header-end">

  <?php if (!MeprOptions::cart_enabled()) : ?>
        <?php
        // Cart-only settings UI stays rendered (so values persist on save) but is hidden while the cart is off. Emitted at render time (after the save runs) so enabling the cart reveals these immediately without a second refresh.
        wp_register_style('mepr-options-form-cart-settings-hidden', false, [], MEPR_VERSION);
        wp_add_inline_style(
            'mepr-options-form-cart-settings-hidden',
            '[id^="config-mepr-"][id*="cart"], .mepr-cart-gateway-toggle, #mepr-option-enabled-currencies, #mepr-section-checkout-wizard { display: none; }'
        );
        wp_print_styles(['mepr-options-form-cart-settings-hidden']);
        ?>
  <?php endif; ?>

  <?php
    MeprHooks::do_action('mepr_admin_overview_before_table');
    MeprView::render('/admin/errors', get_defined_vars());
    MeprHooks::do_action('mepr_before_options_form');
    ?>

    <h2 id="mepr-reports-column-selector" class="nav-tab-wrapper">
      <?php if (class_exists('MeprUpdateCtrl')) : ?>
        <a class="nav-tab nav-tab-active" id="license" href="#"><?php esc_html_e('License', 'memberpress'); ?></a>
        <a class="nav-tab" id="pages" href="#"><?php esc_html_e('Pages', 'memberpress'); ?></a>
      <?php else : ?>
        <a class="nav-tab nav-tab-active" id="pages" href="#"><?php esc_html_e('Pages', 'memberpress'); ?></a>
      <?php endif; ?>
      <a class="nav-tab" id="accounts" href="#"><?php esc_html_e('Account', 'memberpress'); ?></a>
      <a class="nav-tab" id="fields" href="#"><?php esc_html_e('Fields', 'memberpress'); ?></a>
      <a class="nav-tab" id="integration" href="#"><?php esc_html_e('Payments', 'memberpress'); ?></a>
      <a class="nav-tab" id="emails" href="#"><?php esc_html_e('Emails', 'memberpress'); ?></a>
      <?php if ($show_marketing_options) : ?>
        <a class="nav-tab" id="marketing" href="#"><?php esc_html_e('Marketing', 'memberpress'); ?></a>
      <?php endif; ?>
      <a class="nav-tab" id="info" href="#"><?php esc_html_e('Info', 'memberpress'); ?></a>
      <a class="nav-tab" id="general" href="#"><?php esc_html_e('General', 'memberpress'); ?></a>
      <a class="nav-tab" id="cart" href="#"><?php esc_html_e('Cart', 'memberpress'); ?> <span class="mepr-nav-tab-beta"><?php esc_html_e('Beta', 'memberpress'); ?></span></a>
      <?php MeprHooks::do_action('mepr_display_options_tabs'); ?>
    </h2>

    <?php if (class_exists('MeprUpdateCtrl')) : ?>
      <div id="license" class="mepr-options-hidden-pane">

        <section id="mepr-section-license">
          <h3><?php esc_html_e('MemberPress License', 'memberpress'); ?></h3>

          <div id="mepr-license-container">

            <?php
            if ($plugin->getLicenseActivationStatus()) {
                MeprView::render('/admin/options/active_license', compact('activation_transient', 'license_manager', 'mepr_options'));
            } else {
                MeprView::render('/admin/options/inactive_license', compact('license_manager'));
            }
            ?>

          </div>
        </section>

        <section id="mepr-section-account-login">
          <?php MeprView::render('/admin/options/account_login', get_defined_vars()); ?>
        </section>

        <div id="mepr-version-string">
          <?php
            printf(
                // Translators: %s: version number.
                esc_html__("You're currently running version %s of MemberPress.", 'memberpress'),
                '<b>' . esc_html(MEPR_VERSION) . '</b>'
            );
            ?>
        </div>

        <?php MeprHooks::do_action('mepr_activate_license_page'); ?>

      </div>
    <?php endif; ?>

  <form name="mepr_options_form" id="mepr_options_form" class="mepr-form" method="post" action="<?php echo esc_url(wp_parse_url(esc_url_raw(wp_unslash($_SERVER['REQUEST_URI'] ?? '')), PHP_URL_PATH)); ?>" enctype="multipart/form-data">
    <input type="hidden" name="action" value="process-form">
    <?php wp_nonce_field('mepr_update_options', 'mepr_options_nonce'); ?>

    <div id="pages" class="mepr-options-hidden-pane">
      <section id="mepr-section-reserved-pages">
        <h3><?php esc_html_e('Reserved Pages', 'memberpress'); ?></h3>
        <table class="mepr-options-pane">
          <tr id="mepr-option-thankyou-page-id">
            <td><?php esc_html_e('MemberPress Thank You Page', 'memberpress'); ?>*:</td>
            <td><?php MeprOptionsHelper::wp_pages_dropdown($mepr_options->thankyou_page_id_str, $mepr_options->thankyou_page_id, __('Thank You', 'memberpress')); ?></td>
          </tr>
          <tr id="mepr-option-account-page-id">
            <td><?php esc_html_e('MemberPress Account Page', 'memberpress'); ?>*:</td>
            <td><?php MeprOptionsHelper::wp_pages_dropdown($mepr_options->account_page_id_str, $mepr_options->account_page_id, __('Account', 'memberpress')); ?></td>
          </tr>
          <tr id="mepr-option-login-page-id">
            <td><?php esc_html_e('MemberPress Login Page', 'memberpress'); ?>*:</td>
            <td><?php MeprOptionsHelper::wp_pages_dropdown($mepr_options->login_page_id_str, $mepr_options->login_page_id, __('Login', 'memberpress')); ?></td>
          </tr>
          <?php if (MeprOptions::cart_enabled()) : ?>
          <tr id="mepr-option-cart-page-id">
            <td><?php esc_html_e('MemberPress Cart Page', 'memberpress'); ?>*:</td>
            <td><?php MeprOptionsHelper::wp_pages_dropdown($mepr_options->cart_page_id_str, $mepr_options->cart_page_id, __('Cart', 'memberpress')); ?></td>
          </tr>
          <tr id="mepr-option-shop-page-id">
            <td><?php esc_html_e('MemberPress Shop Page', 'memberpress'); ?>*:</td>
            <td><?php MeprOptionsHelper::wp_pages_dropdown($mepr_options->shop_page_id_str, $mepr_options->shop_page_id, __('Shop', 'memberpress')); ?></td>
          </tr>
          <tr id="mepr-option-cart-checkout-page-id">
            <td><?php esc_html_e('MemberPress Cart Checkout Page', 'memberpress'); ?>:</td>
            <td><?php MeprOptionsHelper::wp_pages_dropdown($mepr_options->cart_checkout_page_id_str, $mepr_options->cart_checkout_page_id, __('Checkout', 'memberpress')); ?></td>
          </tr>
          <?php endif; ?>
          <?php if (MeprAppHelper::is_coaching_enabled()) : ?>
          <tr id="mepr-option-coaching-page-id">
            <td><?php esc_html_e('MemberPress Coaching Page', 'memberpress'); ?>*:</td>
            <td><?php MeprOptionsHelper::wp_pages_dropdown($mepr_options->coaching_page_id_str, $mepr_options->coaching_page_id, __('Coaching', 'memberpress')); ?></td>
          </tr>
          <?php endif; ?>
        </table>
      </section>

      <section id="mepr-section-page-slugs">
        <h3 class="mepr-field-label">
          <?php esc_html_e('Pages Slugs:', 'memberpress'); ?>
          <?php MeprAppHelper::info_tooltip(
              'mepr-group-and-product-pages-slugs',
              __('Pages Slugs', 'memberpress'),
              __('Use these fields to customize the base slug of urls for your groups and products.', 'memberpress') . '<br/><br/>' .
              __('Note: It isn\'t recommended that you change these values if you already have existing groups and product pages on a production membership site because all your urls for them will change (WordPress will attempt to redirect from old urls to new urls).', 'memberpress')
          ); ?>
        </h3>
        <table class="mepr-options-pane">
          <tbody>
            <tr id="mepr-option-group-pages-slug" valign="top">
              <td><label for="<?php echo esc_attr($mepr_options->group_pages_slug_str); ?>"><?php esc_html_e('Group Pages Slug:', 'memberpress'); ?></td>
              <td>
                <input type="text" id="<?php echo esc_attr($mepr_options->group_pages_slug_str); ?>" name="<?php echo esc_attr($mepr_options->group_pages_slug_str); ?>" class="regular-text" value="<?php echo esc_attr(stripslashes($mepr_options->group_pages_slug)); ?>" />
              </td>
            </tr>
            <tr id="mepr-option-product-pages-slug" valign="top">
              <td><label for="<?php echo esc_attr($mepr_options->product_pages_slug_str); ?>"><?php esc_html_e('Membership Pages Slug:', 'memberpress'); ?></td>
              <td>
                <input type="text" id="<?php echo esc_attr($mepr_options->product_pages_slug_str); ?>" name="<?php echo esc_attr($mepr_options->product_pages_slug_str); ?>" class="regular-text" value="<?php echo esc_attr(stripslashes($mepr_options->product_pages_slug)); ?>" />
              </td>
            </tr>
            <?php MeprHooks::do_action('mepr_display_pages_slugs_options'); ?>
          </tbody>
        </table>
      </section>

      <section id="mepr-section-unauthorized-access">
        <h3 class="mepr-field-label"><?php esc_html_e('Unauthorized Access', 'memberpress'); ?></h3>
        <div class="mepr-options-pane">
          <div id="mepr-option-redirect-on-unauthorized">
            <input type="checkbox" name="<?php echo esc_attr($mepr_options->redirect_on_unauthorized_str); ?>" id="<?php echo esc_attr($mepr_options->redirect_on_unauthorized_str); ?>" <?php checked($mepr_options->redirect_on_unauthorized); ?> />
            <label for="<?php echo esc_attr($mepr_options->redirect_on_unauthorized_str); ?>"><?php esc_html_e('Redirect unauthorized visitors to a specific URL', 'memberpress'); ?></label>
            <?php MeprAppHelper::info_tooltip(
                'mepr-unauthorized-handling',
                __('Redirect Unauthorized Access', 'memberpress'),
                __('MemberPress allows you to handle unauthorized access by replacing the content on page or via a redirection to a specific url.<br/><br/>When this is checked, unauthorized visits will be redirected to a url, otherwise the unauthorized message and login form will appear on the page.', 'memberpress')
            ); ?>
          </div>

          <div id="mepr-unauthorized-redirect" class="mepr_hidden mepr-options-sub-pane">
            <label for="<?php echo esc_attr($mepr_options->redirect_method_str); ?>"><?php esc_html_e('Redirect method:', 'memberpress'); ?></label>
            <?php MeprAppHelper::info_tooltip(
                'mepr-unauthorized-redirect-method',
                __('Redirect Method', 'memberpress'),
                __('It is highly recommended that "template_redirect" should be your default redirect method.<br/><br/>However, this does not work with all WordPress themes. If you find that the unauthorized redirection is not happening when enabled try switching this to "init" instead.', 'memberpress')
            ); ?>
            <select name="<?php echo esc_attr($mepr_options->redirect_method_str); ?>" id="<?php echo esc_attr($mepr_options->redirect_method_str); ?>">
              <option value="template_redirect" <?php selected($mepr_options->redirect_method, 'template_redirect'); ?>>template_redirect <?php esc_html_e('(recommended)', 'memberpress'); ?></option>
              <option value="init" <?php selected($mepr_options->redirect_method, 'init'); ?>>init</option>
              <option value="send_headers" <?php selected($mepr_options->redirect_method, 'send_headers'); ?>>send_headers</option>
            </select>
            <br/><br/>
            <input type="checkbox" name="<?php echo esc_attr($mepr_options->redirect_non_singular_str); ?>" id="<?php echo esc_attr($mepr_options->redirect_non_singular_str); ?>" <?php checked($mepr_options->redirect_non_singular); ?> />
            <label for="<?php echo esc_attr($mepr_options->redirect_non_singular_str); ?>"><?php esc_html_e('Redirect non-singular views:', 'memberpress'); ?></label>
            <?php MeprAppHelper::info_tooltip(
                'mepr-unauthorized-redirect-non-singular',
                __('Redirect Non-Singular Views', 'memberpress'),
                __('If any post in a non-singular view (EX: Blog page, category pages, archive pages etc) is protected, then do not allow the unauthorized members to see this non-singular view at all.', 'memberpress')
            ); ?>
            <br/><br/>
            <label for="<?php echo esc_attr($mepr_options->unauthorized_redirect_url_str); ?>"><?php esc_html_e('URL to direct unauthorized visitors to:', 'memberpress'); ?></label>
            <?php MeprAppHelper::info_tooltip(
                'mepr-unauthorized-redirect-url',
                __('Unauthorized Redirection URL', 'memberpress'),
                __('This is the URL that visitors will be redirected to when trying to access unauthorized content.', 'memberpress')
            ); ?>
            <input type="text" id="<?php echo esc_attr($mepr_options->unauthorized_redirect_url_str); ?>" name="<?php echo esc_attr($mepr_options->unauthorized_redirect_url_str); ?>" class="regular-text" value="<?php echo esc_attr(stripslashes($mepr_options->unauthorized_redirect_url)); ?>" />
            <br/>
            <span class="description"><?php echo wp_kses(__('You can use the <strong>[mepr_unauthorized_message]</strong> shortcode on this unauthorized page (assuming this url points to a page on this site).', 'memberpress'), ['strong' => []]); ?></span>
          </div>

          <div>&nbsp;</div>
          <div id="mepr-unauthorized-show-excerpts">
            <input type="checkbox" name="<?php echo esc_attr($mepr_options->unauth_show_excerpts_str); ?>" id="<?php echo esc_attr($mepr_options->unauth_show_excerpts_str); ?>" <?php checked($mepr_options->unauth_show_excerpts); ?> />
            <label for="<?php echo esc_attr($mepr_options->unauth_show_excerpts_str); ?>"><?php esc_html_e('Show an excerpt to unauthorized visitors', 'memberpress'); ?></label>
          </div>

          <div id="mepr-unauthorized-show-excerpts-type" class="mepr-options-sub-pane mepr-hidden">
            <?php
              MeprOptionsHelper::display_show_excerpts_dropdown(
                  $mepr_options->unauth_excerpt_type_str,
                  $mepr_options->unauth_excerpt_type,
                  $mepr_options->unauth_excerpt_size_str,
                  $mepr_options->unauth_excerpt_size,
                  true
              );
                ?>
          </div>
          <div>&nbsp;</div>
          <div id="mepr-unauthorized-show-login">
            <input type="checkbox" name="<?php echo esc_attr($mepr_options->unauth_show_login_str); ?>" id="<?php echo esc_attr($mepr_options->unauth_show_login_str); ?>" <?php checked($mepr_options->unauth_show_login); ?> />
            <label for="<?php echo esc_attr($mepr_options->unauth_show_login_str); ?>"><?php esc_html_e('Show a login form on pages containing unauthorized message', 'memberpress'); ?></label>
          </div>

          <br/>
          <div class="mepr-field-label">
            <a href="" class="mp-toggle-unauthorized-message"><?php esc_html_e('Default Unauthorized Message:', 'memberpress'); ?></a>
              <?php MeprAppHelper::info_tooltip(
                  'mepr-default-unauthorized-message',
                  __('Default Unauthorized Message', 'memberpress'),
                  __('This is the default message that will show up when a user is not allowed to access the content on a page.', 'memberpress')
              ); ?>
          </div>
          <div class="mepr-hidden mepr-options-sub-pane mp-unauthorized-message">
            <?php wp_editor($mepr_options->unauthorized_message, $mepr_options->unauthorized_message_str); ?>
          </div>
        </div>
      </section>
      <?php MeprHooks::do_action('mepr_display_pages_options'); ?>
    </div>

    <div id="accounts" class="mepr-options-hidden-pane">
      <section id="mepr-section-permissions">
        <h3><?php esc_html_e('Permissions:', 'memberpress'); ?></h3>
        <div class="mepr-options-pane">
          <div class="mp-row">
            <div id="mepr-option-disable-wp-admin-bar" class="mp-col-5">
              <label for="<?php echo esc_attr($mepr_options->disable_wp_admin_bar_str); ?>">
                <input type="checkbox" name="<?php echo esc_attr($mepr_options->disable_wp_admin_bar_str); ?>" id="<?php echo esc_attr($mepr_options->disable_wp_admin_bar_str); ?>" <?php checked($mepr_options->disable_wp_admin_bar); ?> />
                <span><?php esc_html_e('Disable the WordPress admin bar for members', 'memberpress'); ?></span>
              </label>
            </div>
            <div id="mepr-option-lock-wp-admin" class="mp-col-5">
              <label for="<?php echo esc_attr($mepr_options->lock_wp_admin_str); ?>">
                <input type="checkbox" name="<?php echo esc_attr($mepr_options->lock_wp_admin_str); ?>" id="<?php echo esc_attr($mepr_options->lock_wp_admin_str); ?>" <?php checked($mepr_options->lock_wp_admin); ?> />
                <span><?php esc_html_e('Keep members out of the WordPress Dashboard', 'memberpress'); ?></span>
              </label>
            </div>
            <div id="mepr-option-allow-cancel-subs" class="mp-col-5">
              <label for="<?php echo esc_attr($mepr_options->allow_cancel_subs_str); ?>">
                <input type="checkbox" name="<?php echo esc_attr($mepr_options->allow_cancel_subs_str); ?>" id="<?php echo esc_attr($mepr_options->allow_cancel_subs_str); ?>" <?php checked($mepr_options->allow_cancel_subs); ?> />
                <span><?php esc_html_e('Allow Members to Cancel their own subscriptions', 'memberpress'); ?></span>
              </label>
            </div>
            <div id="mepr-option-allow-suspend-subs" class="mp-col-5">
              <label for="<?php echo esc_attr($mepr_options->allow_suspend_subs_str); ?>">
                <input type="checkbox" name="<?php echo esc_attr($mepr_options->allow_suspend_subs_str); ?>" id="<?php echo esc_attr($mepr_options->allow_suspend_subs_str); ?>" <?php checked($mepr_options->allow_suspend_subs); ?> />
                <span>
                  <?php esc_html_e('Allow Members to Pause &amp; Resume their own subscriptions', 'memberpress'); ?>
                </span>
              </label>
              <?php MeprAppHelper::info_tooltip(
                  'mepr-suspend-resume',
                  __('Pausing &amp; Resuming Subscriptions', 'memberpress'),
                  __('This option will only be available if this is enabled and the user purchased their subscription using PayPal or Stripe.', 'memberpress')
              ); ?>
            </div>
          </div>
        </div>
      </section>

      <section id="mepr-section-registration">
        <h3><?php esc_html_e('Registration:', 'memberpress'); ?></h3>
        <div class="mepr-options-pane">
          <div class="mp-row">
            <div id="mepr-option-enforce-strong-password" class="mp-col-10">
              <label for="<?php echo esc_attr($mepr_options->enforce_strong_password_str); ?>"><?php esc_html_e('Password Strength Meter:', 'memberpress'); ?></label>
              <select name="<?php echo esc_attr($mepr_options->enforce_strong_password_str); ?>" id="<?php echo esc_attr($mepr_options->enforce_strong_password_str); ?>">
                <option value="0" <?php selected($mepr_options->enforce_strong_password, 0); ?>><?php esc_html_e('Hide', 'memberpress'); ?></option>
                <option value="show" <?php selected($mepr_options->enforce_strong_password, 'show'); ?>><?php esc_html_e('Show', 'memberpress'); ?></option>
                <option value="weak" <?php selected($mepr_options->enforce_strong_password, 'weak'); // Mapped as "Medium". ?>><?php esc_html_e('Show &amp; Require Medium Password or Stronger (Recommended)', 'memberpress'); ?></option>
                <option value="medium" <?php selected($mepr_options->enforce_strong_password, 'medium'); // Mapped as "Strong". ?>><?php esc_html_e('Show &amp; Require Strong Password or Stronger', 'memberpress'); ?></option>
                <option value="strong" <?php selected($mepr_options->enforce_strong_password, 'strong'); // Mapped as "Very Strong". ?>><?php esc_html_e('Show &amp; Require Very Strong Password', 'memberpress'); ?></option>
              </select>
            </div>
            <div id="mepr-option-disable-wp-registration-form" class="mp-col-5">
              <label for="<?php echo esc_attr($mepr_options->disable_wp_registration_form_str); ?>">
                <input type="checkbox" name="<?php echo esc_attr($mepr_options->disable_wp_registration_form_str); ?>" id="<?php echo esc_attr($mepr_options->disable_wp_registration_form_str); ?>" <?php checked($mepr_options->disable_wp_registration_form); ?> />
                <span><?php esc_html_e('Disable the standard WordPress registration form', 'memberpress'); ?></span>
              </label>
            </div>
            <?php MeprHooks::do_action('mepr_options_signup_fields', $mepr_options); ?>
            <div id="mepr-option-username-is-email" class="mp-col-5">
              <label for="<?php echo esc_attr($mepr_options->username_is_email_str); ?>">
                <input type="checkbox" name="<?php echo esc_attr($mepr_options->username_is_email_str); ?>" id="<?php echo esc_attr($mepr_options->username_is_email_str); ?>" <?php checked($mepr_options->username_is_email); ?> />
                <span><?php esc_html_e('Members must use their email address for their Username', 'memberpress'); ?></span>
              </label>
            </div>
            <div id="mepr-option-pro-rated-upgrades" class="mp-col-5">
              <label for="<?php echo esc_attr($mepr_options->pro_rated_upgrades_str); ?>">
                <input type="checkbox" name="<?php echo esc_attr($mepr_options->pro_rated_upgrades_str); ?>" id="<?php echo esc_attr($mepr_options->pro_rated_upgrades_str); ?>" <?php checked($mepr_options->pro_rated_upgrades); ?> />
                <span><?php esc_html_e('Pro-rate subscription prices when a member upgrades', 'memberpress'); ?></span>
              </label>
            </div>
            <div id="mepr-option-disable-grace-init-days" class="mp-col-5">
              <label for="<?php echo esc_attr($mepr_options->disable_grace_init_days_str); ?>">
                <input type="checkbox" name="<?php echo esc_attr($mepr_options->disable_grace_init_days_str); ?>" id="<?php echo esc_attr($mepr_options->disable_grace_init_days_str); ?>" <?php checked($mepr_options->disable_grace_init_days); ?> />
                <span><?php esc_html_e('Disable the 1 day grace period after signup', 'memberpress'); ?></span>
              </label>
              <?php MeprAppHelper::info_tooltip(
                  'mepr-disable-init-grace-days',
                  __('1 Day Grace Period', 'memberpress'),
                  __('PayPal, Stripe, and Authorize.net can sometimes take up to 24 hours to process the first payment on a members recurring subscription. By default MemberPress allows a 1 day grace period after a member signs up, so they can access the site immediately rather than wait for their payment to clear.', 'memberpress') . '<br/><br/>' . __('If you would like to make them wait for the payment to clear before they are allowed to access the site, then enable this option.', 'memberpress')
              ); ?>
            </div>
            <div id="mepr-option-disable-checkout-password-fields" class="mp-col-5">
              <label for="<?php echo esc_attr($mepr_options->disable_checkout_password_fields_str); ?>">
                <input type="checkbox" name="<?php echo esc_attr($mepr_options->disable_checkout_password_fields_str); ?>" id="<?php echo esc_attr($mepr_options->disable_checkout_password_fields_str); ?>" <?php checked($mepr_options->disable_checkout_password_fields); ?> />
                <span><?php esc_html_e('Disable Password Fields on product registration forms', 'memberpress'); ?></span>
              </label>
              <?php MeprAppHelper::info_tooltip(
                  'mepr-disable-checkout-password-fields',
                  __('Disable Password Fields', 'memberpress'),
                  __('When this option is checked, the Password, Password Confirmation & Password Strength fields will not appear on the checkout page. The Member will then receive an email after they register that will provide the steps they can take to set up a password.', 'memberpress')
              ); ?>
            </div>
            <div id="mepr-option-enable-spc" class="mp-col-5">
              <label for="<?php echo esc_attr($mepr_options->enable_spc_str); ?>">
               <input type="checkbox" name="<?php echo esc_attr($mepr_options->enable_spc_str); ?>" id="<?php echo esc_attr($mepr_options->enable_spc_str); ?>" <?php checked($mepr_options->enable_spc); ?> />
               <span><?php esc_html_e('Enable Single Page Checkout', 'memberpress'); ?></span>
             </label>
             <?php MeprAppHelper::info_tooltip(
                 'mepr-enable-spc',
                 __('Single Page Checkout', 'memberpress'),
                 __('Enabling this will eliminate the second step of the checkout process. Users will be able to enter their personal and payment details during the first step instead.', 'memberpress')
             );
                        ?>
            </div>
            <div id="mepr-option-enable-spc-invoice" class="mp-col-5">
              <label for="<?php echo esc_attr($mepr_options->enable_spc_invoice_str); ?>">
               <input type="checkbox" name="<?php echo esc_attr($mepr_options->enable_spc_invoice_str); ?>" id="<?php echo esc_attr($mepr_options->enable_spc_invoice_str); ?>" <?php checked($mepr_options->enable_spc_invoice); ?> />
               <span><?php esc_html_e('Enable Single Page Checkout Invoice', 'memberpress'); ?></span>
             </label>
             <?php MeprAppHelper::info_tooltip(
                 'mepr-enable-spc-invoice',
                 __('Single Page Checkout Invoice', 'memberpress'),
                 __('Enabling this will display Invoice table above the payment options.', 'memberpress')
             );
                        ?>
            </div>
            <div id="mepr-option-enable-math-captcha" class="mp-col-5">
              <label for="<?php echo esc_attr($mepr_options->enable_math_captcha_str); ?>">
                <input
                  type="checkbox"
                  name="<?php echo esc_attr($mepr_options->enable_math_captcha_str); ?>"
                  id="<?php echo esc_attr($mepr_options->enable_math_captcha_str); ?>"
                  <?php checked($mepr_options->enable_math_captcha); ?>
                />
                <span><?php esc_html_e('Enable Math Captcha', 'memberpress'); ?></span>
              </label>
                <?php
                MeprAppHelper::info_tooltip(
                    'mepr-enable-math-captcha',
                    __('Enable Math Captcha', 'memberpress'),
                    __('Enabling this will display a simple math challenge to protect forms.', 'memberpress')
                );
                ?>
            </div>
            <div id="mepr-option-require-tos" class="mp-col-5">
              <label for="<?php echo esc_attr($mepr_options->require_tos_str); ?>">
                <input type="checkbox" name="<?php echo esc_attr($mepr_options->require_tos_str); ?>" id="<?php echo esc_attr($mepr_options->require_tos_str); ?>" <?php checked($mepr_options->require_tos); ?> />
                <span><?php esc_html_e('Require Terms of Service on product registration forms', 'memberpress'); ?></span>
              </label>
            </div>
            <div class="mp-col-5">
            </div>
          </div>
          <div id="mepr_tos_hidden" class="mepr-options-sub-pane mepr-hidden">
            <div class="mp-row">
              <div class="mp-col-3">
                <label for="<?php echo esc_attr($mepr_options->tos_url_str); ?>"><?php esc_html_e('URL to your Terms of Service page:', 'memberpress'); ?></label>
              </div>
              <div class="mp-col-4">
                <input type="text" id="<?php echo esc_attr($mepr_options->tos_url_str); ?>" name="<?php echo esc_attr($mepr_options->tos_url_str); ?>" class="regular-text" value="<?php echo esc_attr(stripslashes($mepr_options->tos_url)); ?>" />
              </div>
            </div>
            <div class="mp-row">
              <div class="mp-col-3">
                <label for="<?php echo esc_attr($mepr_options->tos_title_str); ?>"><?php esc_html_e('Terms of Service Checkbox Title:', 'memberpress'); ?></label>
              </div>
              <div class="mp-col-4">
                <input type="text" id="<?php echo esc_attr($mepr_options->tos_title_str); ?>" name="<?php echo esc_attr($mepr_options->tos_title_str); ?>" class="regular-text" value="<?php echo esc_attr(stripslashes($mepr_options->tos_title)); ?>" />
              </div>
            </div>
          </div>
          <div id="mepr-option-require-privacy-policy" class="mp-row">
            <div class="mp-col-10">
              <label for="<?php echo esc_attr($mepr_options->require_privacy_policy_str); ?>">
                <input type="checkbox" name="<?php echo esc_attr($mepr_options->require_privacy_policy_str); ?>" id="<?php echo esc_attr($mepr_options->require_privacy_policy_str); ?>" <?php checked($mepr_options->require_privacy_policy); ?> />
                <span><?php esc_html_e('Require Privacy Policy acceptance on product registration forms', 'memberpress'); ?></span>
              </label>
            </div>
          </div>
          <div id="mepr_privacy_hidden" class="mepr-options-sub-pane mepr-hidden">
            <div class="mp-row">
              <div class="mp-col-3">
                <?php esc_html_e('Your Privacy Policy: ', 'memberpress'); ?>
              </div>
              <div class="mp-col-4">
                <span>
                  <?php
                    $privacy_page_link = MeprAppHelper::privacy_policy_page_link();
                    if ($privacy_page_link) : ?>
                    <a href="<?php echo esc_url($privacy_page_link); ?>"><?php echo esc_url($privacy_page_link); ?></a>
                    <?php else : ?>
                        <?php
                        $privacy_link_text = sprintf(
                            // Translators: %1$s: opening anchor tag, %2$s: closing anchor tag.
                            __('Please create your %1$sPrivacy Policy Page%2$s.', 'memberpress'),
                            '<a href="' . esc_url(MeprOptionsHelper::admin_privacy_settings_link()) . '">',
                            '</a>'
                        );
                        echo wp_kses_post($privacy_link_text);
                        ?>
                    <?php endif; ?>
                </span>
              </div>
            </div>
            <div class="mp-row">
              <div class="mp-col-3">
                <label for="<?php echo esc_attr($mepr_options->privacy_policy_title_str); ?>"><?php esc_html_e('Privacy Policy Checkbox Title:', 'memberpress'); ?></label>
                <?php MeprAppHelper::info_tooltip(
                    $mepr_options->privacy_policy_title_str,
                    __('Privacy Policy Checkbox Title', 'memberpress'),
                    __('This will appear next to the Privacy Policy checkbox on product registration forms. The text between % characters will become the link text to your Privacy Policy page.', 'memberpress')
                ); ?>
              </div>
              <div class="mp-col-4">
                <input type="text" id="<?php echo esc_attr($mepr_options->privacy_policy_title_str); ?>" name="<?php echo esc_attr($mepr_options->privacy_policy_title_str); ?>" class="regular-text" value="<?php echo esc_attr(stripslashes($mepr_options->privacy_policy_title)); ?>" />
              </div>
            </div>
          </div>
        </div>
      </section>

      <section id="mepr-section-login-logout">
        <h3><?php esc_html_e('Login & Logout:', 'memberpress'); ?></h3>
        <div class="mepr-options-pane">
          <div id="mepr-option-force-login-page-url">
            <label for="<?php echo esc_attr($mepr_options->force_login_page_url_str); ?>">
              <input type="checkbox" name="<?php echo esc_attr($mepr_options->force_login_page_url_str); ?>" id="<?php echo esc_attr($mepr_options->force_login_page_url_str); ?>" <?php checked($mepr_options->force_login_page_url); ?> />
              <span><?php esc_html_e('Use MemberPress login page URL', 'memberpress'); ?></span>
            </label>
            <?php MeprAppHelper::info_tooltip(
                'mepr-force-login-page-url',
                __('Use MemberPress login page URL', 'memberpress'),
                __('Use this option to return MemberPress login page URL when other plugins/themes call the wp_login_url() function. If you have other plugins that use their own Login pages too you may want to leave this option disabled. This does NOT prevent directly accessing /wp-login.php page.', 'memberpress')
            ); ?>
            <br/><br/>
          </div>
          <div id="mepr-option-login-redirect-url">
            <label for="<?php echo esc_attr($mepr_options->login_redirect_url_str); ?>"><?php esc_html_e('URL to direct member to after login:', 'memberpress'); ?></label>&nbsp;&nbsp;&nbsp;
            <?php MeprAppHelper::info_tooltip(
                'mepr-login-redirect-message',
                __('Login Redirect URL', 'memberpress'),
                __('For this to work you must have the Login page set in the MemberPress options. You can also override this option on a per-product basis in the Advanced box when creating/editing a product.', 'memberpress')
            ); ?>
            <input type="text" id="<?php echo esc_attr($mepr_options->login_redirect_url_str); ?>" name="<?php echo esc_attr($mepr_options->login_redirect_url_str); ?>" class="regular-text" value="<?php echo esc_attr(stripslashes($mepr_options->login_redirect_url)); ?>" /><br/><br/>
          </div>
          <div id="mepr-option-logout-redirect-url">
            <label for="<?php echo esc_attr($mepr_options->logout_redirect_url_str); ?>"><?php esc_html_e('URL to direct member to after logout:', 'memberpress'); ?></label>
            <?php MeprAppHelper::info_tooltip(
                'mepr-logout-redirect-message',
                __('Logout Redirect URL', 'memberpress'),
                __('Set what URL you want the member to be taken to when they logout on your site. This setting applies to Administrators as well.', 'memberpress')
            ); ?>
            <input type="text" id="<?php echo esc_attr($mepr_options->logout_redirect_url_str); ?>" name="<?php echo esc_attr($mepr_options->logout_redirect_url_str); ?>" class="regular-text" value="<?php echo esc_attr(stripslashes($mepr_options->logout_redirect_url)); ?>" /><br/><br/>
          </div>
        </div>
      </section>

      <section id="mepr-section-account-page-welcome-message">
        <h3 class="mepr-field-label"><?php esc_html_e('Account Page Welcome Message', 'memberpress'); ?></h3>
        <div class="mepr-options-pane">
          <?php wp_editor($mepr_options->custom_message, $mepr_options->custom_message_str); ?>
          <p class="description"><?php esc_html_e('This text will appear below the navigation on the Account Page.', 'memberpress'); ?></p>
        </div>
      </section>
      <?php MeprHooks::do_action('mepr_display_account_options'); ?>
    </div>

    <div id="fields" class="mepr-options-hidden-pane">
    <h3><?php esc_html_e('Logged In Purchases:', 'memberpress'); ?></h3>
      <div class="mepr-options-pane">
        <label for="<?php echo esc_attr($mepr_options->show_fields_logged_in_purchases_str); ?>">
          <input type="checkbox" name="<?php echo esc_attr($mepr_options->show_fields_logged_in_purchases_str); ?>" id="<?php echo esc_attr($mepr_options->show_fields_logged_in_purchases_str); ?>" <?php checked($mepr_options->show_fields_logged_in_purchases); ?>>
          <span><?php esc_html_e('Show The Fields Below For Logged-in Purchases', 'memberpress'); ?></span>
        </label>
      </div>
      <h3><?php esc_html_e('Extended User Information Fields:', 'memberpress'); ?></h3>
      <div class="mepr-options-pane">
        <div class="mp-row">
          <div class="mp-col-4">
            <strong><?php esc_html_e('Name Fields:', 'memberpress'); ?></strong>
          </div>
          <div class="mp-col-2">
            <label>
              <input type="checkbox" name="<?php echo esc_attr($mepr_options->show_fname_lname_str); ?>" id="<?php echo esc_attr($mepr_options->show_fname_lname_str); ?>" <?php checked($mepr_options->show_fname_lname); ?> />
              <span>&nbsp;<?php esc_html_e('Show', 'memberpress'); ?></span>
            </label>
          </div>
          <div class="mp-col-2">
            <label>
              <input type="checkbox" name="<?php echo esc_attr($mepr_options->require_fname_lname_str); ?>" id="<?php echo esc_attr($mepr_options->require_fname_lname_str); ?>" <?php checked($mepr_options->require_fname_lname); ?> />
              <span>&nbsp;<?php esc_html_e('Require', 'memberpress'); ?></span>
            </label>
          </div>
        </div>
        <div class="mp-row">
          <div class="mp-col-4">
            <strong><?php esc_html_e('Address Fields:', 'memberpress'); ?></strong>
            <span id="address-tax-info" class="mepr-hidden"><?php esc_html_e('(Required when taxes are enabled)', 'memberpress'); ?></span>
          </div>
          <div class="mp-col-2">
            <label>
              <input type="checkbox" name="<?php echo esc_attr($mepr_options->show_address_on_account_str); ?>" id="<?php echo esc_attr($mepr_options->show_address_on_account_str); ?>" <?php checked($mepr_options->show_address_on_account); ?> />
              <span>&nbsp;<?php esc_html_e('Show in Account', 'memberpress'); ?></span>
            </label>
          </div>
          <div class="mp-col-2">
            <label>
              <input type="checkbox" name="<?php echo esc_attr($mepr_options->show_address_fields_str); ?>" id="<?php echo esc_attr($mepr_options->show_address_fields_str); ?>" <?php checked($mepr_options->show_address_fields); ?> />
              <span>&nbsp;<?php
                echo esc_html(
                    MeprOptions::cart_enabled()
                        ? __('Show at Checkout', 'memberpress')
                        : __('Show on Signup', 'memberpress')
                );
                ?></span>
            </label>
          </div>
          <div class="mp-col-2">
            <label>
              <input type="checkbox" name="<?php echo esc_attr($mepr_options->require_address_fields_str); ?>" id="<?php echo esc_attr($mepr_options->require_address_fields_str); ?>" <?php checked($mepr_options->require_address_fields); ?> />
              <span>&nbsp;<?php esc_html_e('Required', 'memberpress'); ?></span>
            </label>
          </div>
        </div>
      </div>
      <h3>
        <?php esc_html_e('Custom User Information Fields:', 'memberpress'); ?>
        <?php
        $custom_fields_tooltip = __('You can specify custom fields to be used with your users\' account. Just click the \'plus\' button below to add your first field.', 'memberpress');
        if (MeprOptions::cart_enabled()) {
            $custom_fields_tooltip .= '<br/><br/>' .
                '<b>' . __('Show in Account', 'memberpress') . ':</b> ' . __('Show on the member account profile.', 'memberpress') . '<br/><br/>' .
                '<b>' . __('Show at Checkout', 'memberpress') . ':</b> ' . __('Shown on the standalone registration page and cart. With the multi-step checkout wizard, assign the field in Checkout Settings; with a single-page form (SPC mode), it appears on the form.', 'memberpress') . '<br/><br/>' .
                '<b>' . __('Required', 'memberpress') . ':</b> ' . __('Required wherever the field is shown.', 'memberpress') . '<br/><br/>' .
                __('If Show at Checkout is unchecked, the field does not appear on the standalone registration page or cart.', 'memberpress');
        }
        MeprAppHelper::info_tooltip(
            'mepr-custom-fields',
            __('Custom User Information Fields', 'memberpress'),
            $custom_fields_tooltip
        );
        ?>
      </h3>
      <ol id="custom_profile_fields">
        <?php MeprOptionsHelper::show_existing_custom_fields(); ?>
        <a href="" id="mepr-add-new-custom-field" title="<?php esc_attr_e('Add new Custom Field', 'memberpress'); ?>"><i class="mp-icon mp-icon-plus-circled mp-24"></i></a>
      </ol>
      <br/>
    </div>

    <div id="integration" class="mepr-options-hidden-pane">
      <h3><?php esc_html_e('Payment Methods', 'memberpress'); ?></h3>
      <div id="integrations-list">
        <?php
        $objs      = $mepr_options->payment_methods(true, true);
        $no_method = true;
        foreach ($objs as $pm_id => $obj) {
            if ($obj instanceof MeprBaseRealGateway) {
                $cart_capable = MeprCartPaymentService::is_cart_capable($obj);
                MeprView::render('/admin/options/gateway', get_defined_vars());
                $no_method = false;
            }
        }
        ?>
      </div>
      <?php if ($no_method) { ?>
        <p><?php esc_html_e('A gateway is required to accept payments. Click the (+) below to add your first payment gateway.', 'memberpress'); ?></p>
      <?php } ?>
      <a href="" id="mepr-add-integration" title="<?php esc_attr_e('Add a Payment Method', 'memberpress'); ?>"><i class="mp-icon mp-icon-plus-circled mp-24"></i> <?php esc_html_e('Add Payment Method', 'memberpress'); ?></a>
      <?php unset($objs['free']);
        unset($objs['manual']); ?>
      <div id="no_saved_pms" data-value="<?php echo (empty($objs)) ? 'true' : 'false'; ?>"></div>
    </div>

    <div id="emails" class="mepr-options-hidden-pane">
      <h3><?php esc_html_e('Member Notices', 'memberpress'); ?>
          <?php MeprAppHelper::info_tooltip(
              'mepr-member-notices',
              __('Member Notices', 'memberpress'),
              __('These are notices that will be sent to your members when events happen in MemberPress.', 'memberpress')
          ); ?>
      </h3>
      <div class="mepr-options-pane">
        <?php MeprAppHelper::display_emails('MeprBaseOptionsUserEmail'); ?>
      </div>
      <h3><?php esc_html_e('Admin Emails &amp; Notices', 'memberpress'); ?>
          <?php MeprAppHelper::info_tooltip(
              'mepr-member-notices',
              __('Admin Notices', 'memberpress'),
              __('These are notices that will be sent to the addresses you\'ve set below when events happen in MemberPress.', 'memberpress')
          ); ?>
      </h3>
      <div class="mepr-options-pane">
        <label for="<?php echo esc_attr($mepr_options->admin_email_addresses_str); ?>"><?php esc_html_e('Admin Email Addresses:', 'memberpress'); ?>
          <?php MeprAppHelper::info_tooltip(
              'mepr-admin-email-addresses',
              __('Notification Email Addresses', 'memberpress'),
              __('This is a comma separated list of email addresses that will receive admin notifications. This defaults to your admin email set in "Settings" -> "General" -> "E-mail Address"', 'memberpress')
          ); ?>
        </label>
        <input type="text" id="<?php echo esc_attr($mepr_options->admin_email_addresses_str); ?>" name="<?php echo esc_attr($mepr_options->admin_email_addresses_str); ?>" class="regular-text" value="<?php echo esc_attr(stripslashes($mepr_options->admin_email_addresses)); ?>" />
      </div>
      <div class="mepr-options-pane">
        <?php MeprAppHelper::display_emails('MeprBaseOptionsAdminEmail'); ?>
      </div>
      <h3><?php esc_html_e('Privacy Settings', 'memberpress'); ?></h3>
      <div class="mepr-options-pane">
        <input type="checkbox" name="<?php echo esc_attr($mepr_options->include_email_privacy_link_str); ?>" id="<?php echo esc_attr($mepr_options->include_email_privacy_link_str); ?>" <?php checked($mepr_options->include_email_privacy_link); ?> />
        <label for="<?php echo esc_attr($mepr_options->include_email_privacy_link_str); ?>"><?php esc_html_e('Include Privacy Policy link', 'memberpress'); ?></label>
        <?php MeprAppHelper::info_tooltip(
            $mepr_options->include_email_privacy_link_str,
            __('Privacy Policy Link', 'memberpress'),
            __("When this option is checked, a link to your site's Privacy Policy page will be included in all email communication.", 'memberpress')
        ); ?>
      </div>
      <h3><?php esc_html_e('Send Mail From', 'memberpress'); ?></h3>
      <div class="mepr-options-pane">
        <label for="<?php echo esc_attr($mepr_options->mail_send_from_name_str); ?>"><?php esc_html_e('From Name:', 'memberpress'); ?></label>
        <input type="text" id="<?php echo esc_attr($mepr_options->mail_send_from_name_str); ?>" name="<?php echo esc_attr($mepr_options->mail_send_from_name_str); ?>" class="regular-text" value="<?php echo esc_attr(stripslashes($mepr_options->mail_send_from_name)); ?>" />
        <br/>
        <label for="<?php echo esc_attr($mepr_options->mail_send_from_email_str); ?>"><?php esc_html_e('From Email:', 'memberpress'); ?>&nbsp;</label>
        <input type="text" id="<?php echo esc_attr($mepr_options->mail_send_from_email_str); ?>" name="<?php echo esc_attr($mepr_options->mail_send_from_email_str); ?>" class="regular-text" value="<?php echo esc_attr(stripslashes($mepr_options->mail_send_from_email)); ?>" />
      </div>
      <?php MeprHooks::do_action('mepr_display_emails_options'); ?>
    </div>

    <?php if ($show_marketing_options) : ?>
      <div id="marketing" class="mepr-options-hidden-pane">
        <h3><?php esc_html_e('Settings', 'memberpress'); ?></h3>
        <div class="mepr-options-pane">
          <input type="checkbox" name="<?php echo esc_attr($mepr_options->disable_global_autoresponder_list_str); ?>" id="<?php echo esc_attr($mepr_options->disable_global_autoresponder_list_str); ?>" <?php checked($mepr_options->disable_global_autoresponder_list); ?> />
          <label for="<?php echo esc_attr($mepr_options->disable_global_autoresponder_list_str); ?>"><?php esc_html_e('Disable global auto-responder lists', 'memberpress'); ?></label>
          <?php MeprAppHelper::info_tooltip(
              'mepr-disable-global-autoresponder-list',
              __('Disable global auto-responder lists', 'memberpress'),
              __("When this option is checked, and a product has its own auto-responder list set under its Advanced tab. The global list you set on this page will be disabled on that product page. The member will only be added to the product's list, and not the global list in this case.", 'memberpress')
          ); ?>
          <br/><br/>
          <input type="checkbox" name="<?php echo esc_attr($mepr_options->opt_in_checked_by_default_str); ?>" id="<?php echo esc_attr($mepr_options->opt_in_checked_by_default_str); ?>" <?php checked($mepr_options->opt_in_checked_by_default); ?> />
          <label for="<?php echo esc_attr($mepr_options->opt_in_checked_by_default_str); ?>"><?php esc_html_e('Opt-in box checked by default', 'memberpress'); ?></label>
          <?php MeprAppHelper::info_tooltip(
              'mepr-opt-in-checked-by-default',
              __('Opt-in checkbox initial value', 'memberpress'),
              __('Use this option to set whether the opt-in checkbox shown at signup should be checked or unchecked by default. When enabled, the checkbox will be checked by default.', 'memberpress')
          ); ?>
        </div>
        <h3><?php esc_html_e('Enable/Disable Integrations', 'memberpress'); ?></h3>
        <div class="mepr-options-pane">
          <?php MeprHooks::do_action('mepr_display_autoresponders'); ?>
        </div>
        <?php MeprHooks::do_action('mepr_display_marketing_options'); ?>
      </div>
    <?php endif; ?>

    <div id="info" class="mepr-options-hidden-pane">
      <h3>
        <?php esc_html_e('Merchant Business Address', 'memberpress'); ?>
        <?php MeprAppHelper::info_tooltip(
            'mepr-business-address',
            __('Merchant Business Address', 'memberpress'),
            __('Enter your business\'s name & address. Used to figure out tax rates and to include in email receipts.', 'memberpress')
        ); ?>
      </h3>
      <table class="form-table">
        <tbody>
          <tr valign="top">
            <th scope="row">
              <label for="<?php echo esc_attr($mepr_options->attr_slug('biz_name')); ?>"><?php esc_html_e('Business Name*', 'memberpress'); ?></label>
            </th>
            <td>
              <input type="text" class="regular-text" name="<?php echo esc_attr($mepr_options->attr_slug('biz_name')); ?>" value="<?php echo esc_attr($mepr_options->attr('biz_name')); ?>" />
            </td>
          </tr>
          <tr valign="top">
            <th scope="row">
              <label for="<?php echo esc_attr($mepr_options->attr_slug('biz_address1')); ?>"><?php esc_html_e('Address Line 1*', 'memberpress'); ?></label>
            </th>
            <td>
              <input type="text" class="regular-text" name="<?php echo esc_attr($mepr_options->attr_slug('biz_address1')); ?>" value="<?php echo esc_attr($mepr_options->attr('biz_address1')); ?>" />
            </td>
          </tr>
          <tr valign="top">
            <th scope="row">
              <label for="<?php echo esc_attr($mepr_options->attr_slug('biz_address2')); ?>"><?php esc_html_e('Address Line 2', 'memberpress'); ?></label>
            </th>
            <td>
              <input type="text" class="regular-text" name="<?php echo esc_attr($mepr_options->attr_slug('biz_address2')); ?>" value="<?php echo esc_attr($mepr_options->attr('biz_address2')); ?>" />
            </td>
          </tr>
          <tr valign="top">
            <th scope="row">
              <label for="<?php echo esc_attr($mepr_options->attr_slug('biz_city')); ?>"><?php esc_html_e('City*', 'memberpress'); ?></label>
            </th>
            <td>
              <input type="text" class="regular-text" name="<?php echo esc_attr($mepr_options->attr_slug('biz_city')); ?>" value="<?php echo esc_attr($mepr_options->attr('biz_city')); ?>" />
            </td>
          </tr>
          <tr valign="top">
            <th scope="row">
              <label for="<?php echo esc_attr($mepr_options->attr_slug('biz_country')); ?>"><?php esc_html_e('Country*', 'memberpress'); ?></label>
            </th>
            <td>
              <?php echo MeprAppHelper::countries_dropdown($mepr_options->attr_slug('biz_country'), $mepr_options->attr('biz_country'), 'regular-text', '', false); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
            </td>
          </tr>
          <tr valign="top">
            <th scope="row">
              <label for="<?php echo esc_attr($mepr_options->attr_slug('biz_state')); ?>"><?php esc_html_e('State*', 'memberpress'); ?></label>
            </th>
            <td>
              <input type="text" class="regular-text" name="<?php echo esc_attr($mepr_options->attr_slug('biz_state')); ?>" value="<?php echo esc_attr($mepr_options->attr('biz_state')); ?>" />
            </td>
          </tr>
          <tr valign="top">
            <th scope="row">
              <label for="<?php echo esc_attr($mepr_options->attr_slug('biz_postcode')); ?>"><?php esc_html_e('Postcode*', 'memberpress'); ?></label>
            </th>
            <td>
              <input type="text" class="regular-text" name="<?php echo esc_attr($mepr_options->attr_slug('biz_postcode')); ?>" value="<?php echo esc_attr($mepr_options->attr('biz_postcode')); ?>" />
            </td>
          </tr>
        </tbody>
      </table>
      <?php MeprHooks::do_action('mepr_display_info_options'); ?>
    </div>

    <div id="general" class="mepr-options-hidden-pane">
      <section id="mepr-section-internationalization">
        <h3><?php esc_html_e('Internationalization', 'memberpress'); ?></h3>
        <table class="form-table">
          <tbody>
            <tr id="mepr-option-language-code" valign="top">
              <th scope="row">
                <label for="<?php echo esc_attr($mepr_options->language_code_str); ?>"><?php esc_html_e('Language Code:', 'memberpress'); ?></label>
              </th>
              <td>
                <?php MeprOptionsHelper::payment_language_code_dropdown($mepr_options->language_code_str, $mepr_options->language_code); ?>
              </td>
            </tr>
            <tr id="mepr-option-currency-code" valign="top">
              <th scope="row">
                <label for="<?php echo esc_attr($mepr_options->currency_code_str); ?>"><?php esc_html_e('Currency Code:', 'memberpress'); ?></label>
              </th>
              <td>
                <?php MeprOptionsHelper::payment_currency_code_dropdown($mepr_options->currency_code_str, $mepr_options->currency_code); ?>
              </td>
            </tr>
            <tr id="currency-symbol" valign="top">
              <th scope="row">
                <label for="<?php echo esc_attr($mepr_options->currency_symbol_str); ?>"><?php esc_html_e('Currency Symbol:', 'memberpress'); ?></label>
              </th>
              <td>
                <?php MeprOptionsHelper::payment_currencies_dropdown($mepr_options->currency_symbol_str, $mepr_options->currency_symbol); ?>
              </td>
            </tr>
            <tr id="mepr-option-currency-symbol-after" valign="top">
              <th scope="row">
                <label for="<?php echo esc_attr($mepr_options->currency_symbol_after_str); ?>"><?php esc_html_e('Symbol After Amount', 'memberpress'); ?></label>
                <?php MeprAppHelper::info_tooltip(
                    'mepr-currency-symbol-after',
                    __('Display Currency Symbol After Amount', 'memberpress'),
                    __('Will display the currency symbol after the price of the item. For example: 5.00$ instead of $5.00. Unless you know your countries currency symbol should be listed after, leave this unchecked.', 'memberpress')
                ); ?>
              </th>
              <td>
                <input type="checkbox" name="<?php echo esc_attr($mepr_options->currency_symbol_after_str); ?>" id="<?php echo esc_attr($mepr_options->currency_symbol_after_str); ?>" <?php checked($mepr_options->currency_symbol_after); ?> />
              </td>
            </tr>
            <tr id="mepr-option-enabled-currencies" valign="top">
              <th scope="row">
                <label><?php esc_html_e('Additional Currencies', 'memberpress'); ?></label>
                <?php MeprAppHelper::info_tooltip(
                    'mepr-enabled-currencies',
                    __('Additional Currencies', 'memberpress'),
                    __('Enable secondary currencies for multi-currency checkout. Prices in these currencies will be auto-calculated from exchange rates or can be manually set per product.', 'memberpress')
                ); ?>
              </th>
              <td>
                <div class="mepr-currency-settings">
                  <div class="mepr-enabled-currencies">
                    <?php
                    $mepr_all_currencies = [
                        'USD' => 'US Dollar',
                        'EUR' => 'Euro',
                        'GBP' => 'British Pound',
                        'JPY' => 'Japanese Yen',
                        'CAD' => 'Canadian Dollar',
                        'AUD' => 'Australian Dollar',
                        'CHF' => 'Swiss Franc',
                        'SEK' => 'Swedish Krona',
                        'NOK' => 'Norwegian Krone',
                        'DKK' => 'Danish Krone',
                        'PLN' => 'Polish Zloty',
                        'CZK' => 'Czech Koruna',
                        'HUF' => 'Hungarian Forint',
                        'BRL' => 'Brazilian Real',
                        'MXN' => 'Mexican Peso',
                        'INR' => 'Indian Rupee',
                        'CNY' => 'Chinese Yuan',
                        'KRW' => 'South Korean Won',
                        'SGD' => 'Singapore Dollar',
                        'HKD' => 'Hong Kong Dollar',
                        'NZD' => 'New Zealand Dollar',
                        'ZAR' => 'South African Rand',
                        'TRY' => 'Turkish Lira',
                    ];
                    $mepr_enabled        = is_array($mepr_options->enabled_currencies) ? $mepr_options->enabled_currencies : [];
                    foreach ($mepr_all_currencies as $code => $name) :
                        if ($code === $mepr_options->currency_code) {
                            continue; // Skip primary currency.
                        }
                        ?>
                      <label>
                        <input type="checkbox" name="mepr_options[enabled_currencies][]" value="<?php echo esc_attr($code); ?>" <?php checked(in_array($code, $mepr_enabled, true)); ?> />
                        <?php echo esc_html($code . ' - ' . $name); ?>
                      </label>
                    <?php endforeach; ?>
                  </div>
                  <div class="mepr-exchange-rate-status" style="margin-top: 12px;">
                    <?php
                    $mepr_last_updated = get_option('mepr_exchange_rates_last_updated', '');
                    if ($mepr_last_updated) {
                        echo '<span class="mepr-rate-status-ok">';
                        $mepr_rate_msg = sprintf(
                            // Translators: %1$s: date/time, %2$s: base currency code.
                            __('Rates last updated: %1$s &middot; %2$s base', 'memberpress'),
                            date_i18n(get_option('date_format') . ' ' . get_option('time_format'), strtotime($mepr_last_updated)),
                            $mepr_options->currency_code
                        );
                        // Show enabled currency rates inline.
                        if (MeprOptions::cart_enabled()) {
                            $mepr_cached_rates = MeprExchangeRateService::get_rates();
                            $mepr_rate_parts   = [];
                            foreach ($mepr_enabled as $mepr_rc) {
                                if ($mepr_rc === $mepr_options->currency_code || !isset($mepr_cached_rates[$mepr_rc])) {
                                    continue;
                                }
                                $mepr_rate_parts[] = $mepr_rc . ': ' . number_format((float) $mepr_cached_rates[$mepr_rc], 4);
                            }
                            if (!empty($mepr_rate_parts)) {
                                $mepr_rate_msg .= ' &middot; ' . implode(', ', $mepr_rate_parts);
                            }
                        }
                        echo wp_kses($mepr_rate_msg, ['span' => []]);
                        echo '</span>';
                    } else {
                        echo '<span class="mepr-rate-status-none">' . esc_html__('No exchange rates fetched yet.', 'memberpress') . '</span>';
                    }
                    ?>
                  </div>
                  <button type="button" class="button mepr-exchange-rate-refresh-btn" style="margin-top: 8px;"><?php esc_html_e('Refresh Exchange Rates', 'memberpress'); ?></button>
                </div>
              </td>
            </tr>
          </tbody>
        </table>
        <br/>
      </section>

      <section id="mepr-section-theme-compatibility">
        <h3><?php esc_html_e('Theme Compatibility', 'memberpress'); ?></h3>
        <table class="form-table">
          <tbody>
            <tr id="mepr-option-global-styles" valign="top">
              <th scope="row">
                <label for="<?php echo esc_attr($mepr_options->global_styles_str); ?>"><?php esc_html_e('Global CSS Styles', 'memberpress'); ?></label>
                <?php MeprAppHelper::info_tooltip(
                    'mepr-global-styles',
                    __('Load all of MemberPress\'s CSS Styles on Each Page', 'memberpress'),
                    __('When this option is enabled, all of MemberPress\'s CSS Styles will be loaded on every front end page of your website.', 'memberpress') . '<br/><br/><strong>' . __('Note: This option should only be enabled if MemberPress compatibility with your theme requires its usage.', 'memberpress') . '</strong>'
                ); ?>
              </th>
              <td>
                <input type="checkbox" name="<?php echo esc_attr($mepr_options->global_styles_str); ?>" id="<?php echo esc_attr($mepr_options->global_styles_str); ?>" <?php checked($mepr_options->global_styles); ?> />
              </td>
            </tr>
          </tbody>
        </table>
        <br/>
      </section>

      <section id="mepr-section-seo-paywall">
        <h3><?php esc_html_e('SEO & PayWall', 'memberpress'); ?></h3>
        <table id="mepr-option-authorize-seo-views" class="form-table">
          <tbody>
            <tr valign="top">
              <th scope="row">
                <label for="<?php echo esc_attr($mepr_options->authorize_seo_views_str); ?>"><?php esc_html_e('Authorize Search Engines', 'memberpress'); ?></label>
                <?php MeprAppHelper::info_tooltip(
                    'mepr-authorize-seo-views',
                    __('Treat popular search engines as authorized members?', 'memberpress'),
                    __('When this option is enabled -- Google, Yahoo, Ask, and Bing/MSN are allowed to view protected content on your site as if they were authorized members. This can help search engines index your content.', 'memberpress') . '<br/><br/>' . __("Note: This does not work with caching enabled on your site. So avoid enabling this when using WP Super Cache, W3TC, WP Engine hosting, GoDaddy's Managed WordPress -- or any other plugin/webhost that caches your pages.", 'memberpress')
                ); ?>
              </th>
              <td>
                <input type="checkbox" name="<?php echo esc_attr($mepr_options->authorize_seo_views_str); ?>" id="<?php echo esc_attr($mepr_options->authorize_seo_views_str); ?>" <?php checked($mepr_options->authorize_seo_views); ?> />
              </td>
            </tr>
          </tbody>
        </table>

        <div id="mepr-seo-noindex-area" class="mepr-hidden">
          <table class="form-table">
            <tbody>
              <tr valign="top">
                <th scope="row">
                  <label for="<?php echo esc_attr($mepr_options->seo_unauthorized_noindex_str); ?>"><?php esc_html_e('Block Search Engines', 'memberpress'); ?></label>
                  <?php MeprAppHelper::info_tooltip(
                      'mepr-seo-unauthorized-noindex',
                      __('Ask search engines to not index protected content?', 'memberpress'),
                      __("Automatically ask search engines not to index protected content on your site. If the 'Authorize Search Engines' option is enabled, this setting has no effect.", 'memberpress')
                  ); ?>
                </th>
                <td>
                  <input type="checkbox" name="<?php echo esc_attr($mepr_options->seo_unauthorized_noindex_str); ?>" id="<?php echo esc_attr($mepr_options->seo_unauthorized_noindex_str); ?>" <?php checked($mepr_options->seo_unauthorized_noindex); ?> />
                </td>
              </tr>
            </tbody>
          </table>
        </div>

        <table id="mepr-option-paywall-enabled" class="form-table">
          <tbody>
            <tr valign="top">
              <th scope="row">
                <label for="<?php echo esc_attr($mepr_options->paywall_enabled_str); ?>"><?php esc_html_e('Enable PayWall', 'memberpress'); ?></label>
                <?php MeprAppHelper::info_tooltip(
                    'mepr-paywall-enabled',
                    __('Enable PayWall', 'memberpress'),
                    __('When enabled, you can specify how many free page views an unauthorized guest will have before being shown the unauthorized messages. We strongly encourage you to leave this option disabled during your initial setup and testing of MemberPress.', 'memberpress')
                ); ?>
              </th>
              <td>
                <input type="checkbox" name="<?php echo esc_attr($mepr_options->paywall_enabled_str); ?>" id="<?php echo esc_attr($mepr_options->paywall_enabled_str); ?>" <?php checked($mepr_options->paywall_enabled); ?> />
              </td>
            </tr>
          </tbody>
        </table>

        <div id="mepr-paywall-options-area" class="mepr-sub-box-white mepr-hidden">
          <div class="mepr-arrow mepr-white mepr-up mepr-sub-box-arrow"> </div>
          <table class="form-table">
            <tbody>
              <tr valign="top">
                <th scope="row">
                  <label for="<?php echo esc_attr($mepr_options->paywall_num_free_views_str); ?>"><?php esc_html_e('# Free Views', 'memberpress'); ?></label>
                  <?php MeprAppHelper::info_tooltip(
                      'mepr-num-unauthorized-views',
                      __('Number of Free Views per Guest', 'memberpress'),
                      __('The number of free views unauthorized users can have before the paywall kicks in to prevent access to protected content.', 'memberpress')
                  ); ?>
                </th>
                <td>
                  <input type="text" size="2" name="<?php echo esc_attr($mepr_options->paywall_num_free_views_str); ?>" id="<?php echo esc_attr($mepr_options->paywall_num_free_views_str); ?>" value="<?php echo (int)$mepr_options->paywall_num_free_views; ?>" />
                </td>
              </tr>
            </tbody>
          </table>
        </div>
        <br/>
      </section>

      <section id="mepr-section-weekly-summary-email">
        <h3><?php esc_html_e('Weekly Summary Email', 'memberpress'); ?></h3>
        <table class="form-table">
          <tbody>
            <tr valign="top">
              <th scope="row">
                <label for="<?php echo esc_attr($mepr_options->disable_summary_email_str); ?>"><?php esc_html_e('Disable Weekly Summary Email', 'memberpress'); ?></label>
                <?php MeprAppHelper::info_tooltip(
                    $mepr_options->disable_summary_email_str,
                    __('Disable Weekly Summary Email', 'memberpress'),
                    __('A weekly summary email is sent from MemberPress with a report on the revenue and transactions from the previous week. You can stop the email being sent by checking this option.', 'memberpress')
                ); ?>
              </th>
              <td>
                <input type="checkbox" name="<?php echo esc_attr($mepr_options->disable_summary_email_str); ?>" id="<?php echo esc_attr($mepr_options->disable_summary_email_str); ?>" <?php checked($mepr_options->disable_summary_email); ?> />
              </td>
            </tr>
          </tbody>
        </table>
        <br/>
      </section>

      <section id="mepr-section-rewrite-rules">
        <h3><?php esc_html_e('Rewrite Rules', 'memberpress'); ?></h3>
        <table class="form-table">
          <tbody>
            <tr valign="top">
              <th scope="row">
                <label for="<?php echo esc_attr($mepr_options->disable_mod_rewrite_str); ?>"><?php esc_html_e('Disable Rewrite Rules', 'memberpress'); ?></label>
                <?php MeprAppHelper::info_tooltip(
                    'mepr-disable-mod-rewrite',
                    __('Disable mod_rewrite (.htaccess) Rules', 'memberpress'),
                    __('If you are having problems getting other 3rd party applications such as phpBB or phpList to work along side MemberPress, you may need to check this option. Disabling mod_rewrite will mean that individual files cannot be protected with the Custom URI Rules.', 'memberpress')
                ); ?>
              </th>
              <td>
                <input type="checkbox" name="<?php echo esc_attr($mepr_options->disable_mod_rewrite_str); ?>" id="<?php echo esc_attr($mepr_options->disable_mod_rewrite_str); ?>" <?php checked($mepr_options->disable_mod_rewrite); ?> />
              </td>
            </tr>
          </tbody>
        </table>
        <br/>
      </section>

      <section id="mepr-section-misc">
        <h3><?php esc_html_e('Misc', 'memberpress'); ?></h3>
        <table class="form-table">
          <tbody>
            <tr valign="top">
              <th scope="row">
                <label for="<?php echo esc_attr($mepr_options->hide_admin_bar_menu_str); ?>"><?php esc_html_e('Hide MemberPress Menu in Admin Bar', 'memberpress'); ?></label>
                <?php MeprAppHelper::info_tooltip(
                    'mepr-hide-mp-top-menu',
                    esc_html__('Hide MemberPress Menu in Admin Bar', 'memberpress'),
                    esc_html__('Enabling this option will hide the MemberPress admin bar menu', 'memberpress') // phpcs:ignore Generic.Files.LineLength.TooLong
                ); ?>
              </th>
              <td>
                <input type="checkbox" name="<?php echo esc_attr($mepr_options->hide_admin_bar_menu_str); ?>" id="<?php echo esc_attr($mepr_options->hide_admin_bar_menu_str); ?>" <?php checked($mepr_options->hide_admin_bar_menu); ?> />
              </td>
            </tr>
            <tr valign="top">
              <th scope="row">
                <label for="<?php echo esc_attr($mepr_options->enable_wp_rest_api_protection_str); ?>"><?php esc_html_e('Enable WP Rest API search discovery protection', 'memberpress'); ?></label>
                <?php MeprAppHelper::info_tooltip(
                    'mepr-enable-wp-rest-api-protection',
                    esc_html__('Enable WP Rest API search discovery protection', 'memberpress'),
                    esc_html__('Enabling this option will protect your WP Rest API search discovery', 'memberpress') // phpcs:ignore Generic.Files.LineLength.TooLong
                ); ?>
              </th>
              <td>
                <input type="checkbox" name="<?php echo esc_attr($mepr_options->enable_wp_rest_api_protection_str); ?>" id="<?php echo esc_attr($mepr_options->enable_wp_rest_api_protection_str); ?>" <?php checked($mepr_options->enable_wp_rest_api_protection); ?> />
              </td>
            </tr>
          </tbody>
        </table>
        <br/>
      </section>

      <?php MeprHooks::do_action('mepr_display_general_options'); ?>
    </div>

    <div id="cart" class="mepr-options-hidden-pane">
      <?php MeprView::render('/admin/options/cart', get_defined_vars()); ?>
      <section id="mepr-section-checkout-wizard">
        <h3><?php esc_html_e('Checkout Settings', 'memberpress'); ?></h3>

        <p class="mepr-option-row">
          <label>
            <input type="checkbox"
                   name="mepr-enable-checkout-wizard"
                   id="mepr-enable-checkout-wizard"
                   <?php checked((bool) $mepr_options->enable_checkout_wizard); ?> />
            <?php esc_html_e('Enable multi-step checkout wizard', 'memberpress'); ?>
          </label>
          <br /><em class="mepr-description"><?php esc_html_e('When disabled, checkout renders as a single-page form (SPC mode).', 'memberpress'); ?></em>
        </p>

        <div id="mepr-checkout-steps-editor" class="<?php echo (bool) $mepr_options->enable_checkout_wizard ? '' : 'mepr-disabled'; ?>">

          <h4><?php esc_html_e('Step Order', 'memberpress'); ?></h4>
          <p class="description"><?php esc_html_e('Drag custom steps to reorder. Built-in steps cannot be moved or removed.', 'memberpress'); ?></p>

          <ul id="mepr-checkout-steps-list" class="mepr-checkout-steps-sortable">

            <?php // --- Built-in: Basic (id: account) --- ?>
            <li class="mepr-checkout-step-row mepr-checkout-step-row--builtin" data-step-id="account">
              <span class="mp-icon mp-icon-drag-target mepr-drag-disabled"></span>
              <strong><?php esc_html_e('Basic', 'memberpress'); ?></strong>
              <span class="mepr-builtin-badge"><?php esc_html_e('Built-in', 'memberpress'); ?></span>
              <em class="mepr-description"><?php esc_html_e('Auto-skipped when user is logged in.', 'memberpress'); ?></em>
            </li>

            <?php // --- Built-in: Billing --- ?>
            <li class="mepr-checkout-step-row mepr-checkout-step-row--builtin" data-step-id="billing">
              <span class="mp-icon mp-icon-drag-target mepr-drag-disabled"></span>
              <strong><?php esc_html_e('Billing', 'memberpress'); ?></strong>
              <span class="mepr-builtin-badge"><?php esc_html_e('Built-in', 'memberpress'); ?></span>
            </li>

            <?php // --- Custom steps (from saved config) --- ?>
            <?php
            $checkout_steps      = is_array($mepr_options->checkout_steps) ? $mepr_options->checkout_steps : [];
            // Checkout steps draw from fields with Show at Checkout enabled (show_on_signup=true).
            $all_checkout_fields = array_filter(
                (array) $mepr_options->custom_fields,
                [MeprCheckoutStepsHelper::class, 'is_checkout_custom_field_visible']
            );
            // Build map: field_key => step label that owns it.
            $field_step_map = [];
            foreach ($checkout_steps as $cs) {
                foreach ((array) ($cs['field_keys'] ?? []) as $fk) {
                    $field_step_map[$fk] = $cs['label'];
                }
            }
            foreach ($checkout_steps as $step_idx => $cs) :
                $step_id     = isset($cs['id']) ? $cs['id'] : 'step-' . $step_idx;
                $step_label  = isset($cs['label']) ? $cs['label'] : '';
                $step_fkeys  = isset($cs['field_keys']) ? (array) $cs['field_keys'] : [];
                $field_count = count($step_fkeys);
                ?>
            <li class="mepr-checkout-step-row mepr-checkout-step-row--custom" data-step-id="<?php echo esc_attr($step_id); ?>">
              <span class="mp-icon mp-icon-drag-target"></span>
              <input type="text"
                     name="mepr-checkout-steps[<?php echo esc_attr($step_idx); ?>][label]"
                     value="<?php echo esc_attr($step_label); ?>"
                     class="mepr-step-name-input"
                     placeholder="<?php esc_attr_e('Step Name', 'memberpress'); ?>" />
              <input type="hidden"
                     name="mepr-checkout-steps[<?php echo esc_attr($step_idx); ?>][id]"
                     value="<?php echo esc_attr($step_id); ?>" />
              <span class="mepr-step-field-count">
                <?php
                // Translators: %d: number of fields assigned to the step.
                printf(esc_html(_n('%d field', '%d fields', $field_count, 'memberpress')), (int) $field_count);
                ?>
              </span>
              <a href="#" class="mepr-step-toggle-fields" aria-expanded="false"><?php esc_html_e('Assign fields', 'memberpress'); ?> &#9660;</a>
              <a href="#" class="mepr-checkout-step-remove" title="<?php esc_attr_e('Remove step', 'memberpress'); ?>">
                <i class="mp-icon mp-icon-cancel-circled mp-16"></i>
              </a>

              <div class="mepr-step-fields-panel" style="display:none;">
                <p class="mepr-step-fields-help"><em><?php esc_html_e('Check "Show at Checkout" on the Fields tab to make a field available here.', 'memberpress'); ?></em></p>
                <?php if (!empty($all_checkout_fields)) : ?>
                <ul class="mepr-step-field-list">
                    <?php foreach ($all_checkout_fields as $field) :
                        $is_assigned_here  = in_array($field->field_key, $step_fkeys, true);
                        $assigned_to_label = isset($field_step_map[$field->field_key]) ? $field_step_map[$field->field_key] : null;
                        $is_assigned_other = $assigned_to_label && !$is_assigned_here;
                        ?>
                  <li>
                    <label <?php echo $is_assigned_other ? 'class="mepr-field-assigned-elsewhere"' : ''; ?>>
                      <input type="checkbox"
                             name="mepr-checkout-steps[<?php echo esc_attr($step_idx); ?>][field_keys][]"
                             value="<?php echo esc_attr($field->field_key); ?>"
                             <?php checked($is_assigned_here); ?>
                             <?php disabled($is_assigned_other); ?> />
                        <?php echo esc_html($field->field_name); ?>
                        <?php if ($is_assigned_other) : ?>
                        <em class="mepr-field-location">
                            <?php
                            // Translators: %s: name of the step the field is assigned to.
                            printf(esc_html__('(in: %s)', 'memberpress'), esc_html($assigned_to_label));
                            ?>
                        </em>
                        <?php endif; ?>
                    </label>
                  </li>
                    <?php endforeach; ?>
                </ul>
                <?php endif; ?>
              </div>
            </li>
            <?php endforeach; ?>

            <?php // --- Built-in: Payment (always last) --- ?>
            <li class="mepr-checkout-step-row mepr-checkout-step-row--builtin" data-step-id="payment">
              <span class="mp-icon mp-icon-drag-target mepr-drag-disabled"></span>
              <strong><?php esc_html_e('Payment', 'memberpress'); ?></strong>
              <span class="mepr-builtin-badge"><?php esc_html_e('Built-in', 'memberpress'); ?></span>
            </li>

          </ul><!-- /.mepr-checkout-steps-sortable -->

          <a href="#" id="mepr-add-checkout-step" class="button"><?php esc_html_e('+ Add Custom Step', 'memberpress'); ?></a>

          <?php // Hidden template row for JS cloning when adding a new step. ?>
          <script type="text/template" id="mepr-new-step-template">
            <li class="mepr-checkout-step-row mepr-checkout-step-row--custom" data-step-id="">
              <span class="mp-icon mp-icon-drag-target"></span>
              <input type="text" name="" value="" class="mepr-step-name-input"
                     placeholder="<?php esc_attr_e('Step Name', 'memberpress'); ?>" />
              <input type="hidden" name="" value="" class="mepr-step-id-hidden" />
              <span class="mepr-step-field-count">0 <?php esc_html_e('fields', 'memberpress'); ?></span>
              <a href="#" class="mepr-step-toggle-fields" aria-expanded="false"><?php esc_html_e('Assign fields', 'memberpress'); ?> &#9660;</a>
              <a href="#" class="mepr-checkout-step-remove" title="<?php esc_attr_e('Remove step', 'memberpress'); ?>">
                <i class="mp-icon mp-icon-cancel-circled mp-16"></i>
              </a>
              <div class="mepr-step-fields-panel" style="display:none;">
                <p class="mepr-step-fields-help"><em><?php esc_html_e('Check "Show at Checkout" on the Fields tab to make a field available here.', 'memberpress'); ?></em></p>
                <?php if (!empty($all_checkout_fields)) : ?>
                <ul class="mepr-step-field-list">
                    <?php foreach ($all_checkout_fields as $field) : ?>
                  <li>
                    <label>
                      <input type="checkbox"
                             name=""
                             value="<?php echo esc_attr($field->field_key); ?>" />
                        <?php echo esc_html($field->field_name); ?>
                    </label>
                  </li>
                    <?php endforeach; ?>
                </ul>
                <?php endif; ?>
              </div>
            </li>
          </script>

        </div><!-- /#mepr-checkout-steps-editor -->

      </section>
    </div><!-- /#cart.mepr-options-hidden-pane -->

    <?php MeprHooks::do_action('mepr_display_options'); ?>

    <p class="submit">
      <input type="submit" class="button button-primary" name="Submit" value="<?php esc_attr_e('Update Options', 'memberpress'); ?>" />
    </p>
  </form>
</div>
