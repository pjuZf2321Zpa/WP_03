<?php

namespace WPAICG\Lib\Views\Settings;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Failed sends to apps, for the rules they belong to. Each one is told in plain words, with the app's own
 * answer kept for the details, so a rule's panel can say what went wrong where it can be fixed.
 */
class AIPKit_App_Delivery_Issues_View
{
    private const RECENT_LIMIT = 50;

    /**
     * Recent failed sends, newest first, grouped by the rule that sent them.
     *
     * @return array<string, array<int, array<string, string>>>
     */
    public static function failures_by_rule(array $app_names = []): array
    {
        $is_pro_plan = class_exists('\WPAICG\\aipkit_dashboard') && \WPAICG\aipkit_dashboard::is_pro_plan();
        $log_store_class = '\WPAICG\\Lib\\Integrations\\Logs\\AIPKit_Recipe_Delivery_Log_Store';
        if (!$is_pro_plan || !class_exists($log_store_class) || !method_exists($log_store_class, 'get_recent_failed_attempts')) {
            return [];
        }

        $failures = [];
        foreach ((array) $log_store_class::get_recent_failed_attempts(self::RECENT_LIMIT) as $issue) {
            if (!is_array($issue)) {
                continue;
            }
            $recipe_id = sanitize_text_field((string) ($issue['recipe_id'] ?? ''));
            $failure = self::describe($issue, $app_names);
            if ($recipe_id === '' || $failure['uuid'] === '') {
                continue;
            }
            $failures[$recipe_id][] = $failure;
        }

        return $failures;
    }

    /**
     * One failed send: its ID, what went wrong in plain words, the app's own answer, and when.
     *
     * @param array<string, mixed> $issue
     * @param array<string, string> $app_names
     * @return array<string, string>
     */
    public static function describe(array $issue, array $app_names = []): array
    {
        $response = isset($issue['response_summary']) && is_array($issue['response_summary']) ? $issue['response_summary'] : [];
        $request = isset($issue['request_summary']) && is_array($issue['request_summary']) ? $issue['request_summary'] : [];
        $raw = sanitize_text_field((string) (($response['message'] ?? '') ?: ($issue['error_message'] ?? '')));
        $status = sanitize_key((string) ($response['status'] ?? ''));
        $http = max(0, (int) ($issue['http_status'] ?? 0));
        $app_slug = sanitize_key((string) ($request['app_slug'] ?? ($issue['app_slug'] ?? '')));
        $app = (string) ($app_names[$app_slug] ?? '');
        if ($app === '') {
            $app = sanitize_text_field((string) ($request['connection_name'] ?? ''));
        }
        $named = $app !== '';
        if (!$named) {
            $app = __('The app', 'gpt3-ai-content-generator');
        }
        $lower = strtolower($raw);

        if ($status === 'reauth_required' || in_array($http, [401, 403], true)) {
            /* translators: %s: app name, e.g. HubSpot. */
            $reason = sprintf(__('%s didn’t accept the connection. Connect it again in its panel.', 'gpt3-ai-content-generator'), $app);
        } elseif ($http === 404) {
            $reason = in_array($app_slug, ['zapier', 'make', 'n8n'], true)
                /* translators: %s: app name, e.g. Zapier. */
                ? sprintf(__('%s couldn’t find the webhook. Check the webhook URL.', 'gpt3-ai-content-generator'), $app)
                /* translators: %s: app name, e.g. Notion. */
                : sprintf(__('%s couldn’t find where to send it. Check the connection’s settings.', 'gpt3-ai-content-generator'), $app);
        } elseif ($http === 429) {
            /* translators: %s: app name. */
            $reason = sprintf(__('%s asked to slow down. Send it again in a few minutes.', 'gpt3-ai-content-generator'), $app);
        } elseif ($http >= 500) {
            /* translators: %s: app name. */
            $reason = sprintf(__('%s had a problem on its side. Send it again later.', 'gpt3-ai-content-generator'), $app);
        } elseif (strpos($lower, 'timed out') !== false || strpos($lower, 'timeout') !== false || strpos($lower, 'curl error 28') !== false) {
            /* translators: %s: app name. */
            $reason = sprintf(__('%s didn’t answer in time. Send it again.', 'gpt3-ai-content-generator'), $app);
        } elseif (strpos($lower, 'email') !== false && (strpos($lower, 'invalid') !== false || strpos($lower, 'valid email') !== false)) {
            $reason = preg_match('/email address\s+(\S+)\s+is invalid/i', $raw, $match) === 1
                /* translators: 1: app name, 2: the email address the app rejected. */
                ? sprintf(__('%1$s didn’t accept the email address “%2$s”.', 'gpt3-ai-content-generator'), $app, $match[1])
                /* translators: %s: app name. */
                : sprintf(__('%s didn’t accept the email address.', 'gpt3-ai-content-generator'), $app);
        } elseif (in_array($http, [400, 422], true) || ($http > 0 && strpos($lower, 'valid') !== false)) {
            /* translators: %s: app name. */
            $reason = sprintf(__('%s didn’t accept one of the fields. The details say why.', 'gpt3-ai-content-generator'), $app);
        } elseif ($http === 0) {
            // Nothing came back from the app: the site stopped it, or couldn't reach the app.
            $reason = $named
                /* translators: %s: app name. */
                ? sprintf(__('It wasn’t sent to %s. The details say why.', 'gpt3-ai-content-generator'), $app)
                : __('It wasn’t sent. The details say why.', 'gpt3-ai-content-generator');
        } else {
            /* translators: %s: app name. */
            $reason = sprintf(__('%s didn’t accept it. The details have its answer.', 'gpt3-ai-content-generator'), $app);
        }

        // Failed attempts already carry an explicit UTC completion time, including older rows
        // whose creation time was supplied by the database in its session timezone.
        $created_at = sanitize_text_field((string) (($issue['completed_at'] ?? '') ?: ($issue['created_at'] ?? '')));
        $timestamp = $created_at !== '' ? strtotime($created_at . ' UTC') : false;
        $details = $raw;
        if ($http > 0 && stripos($raw, 'HTTP ' . $http) === false) {
            /* translators: %d: HTTP status code. */
            $details .= ($details !== '' ? ' · ' : '') . sprintf(__('HTTP %d', 'gpt3-ai-content-generator'), $http);
        }
        if ($created_at !== '') {
            $details .= ($details !== '' ? ' · ' : '') . $created_at . ' UTC';
        }

        return [
            'uuid' => sanitize_text_field((string) ($issue['attempt_uuid'] ?? '')),
            'reason' => $reason,
            'details' => $details,
            'when' => $timestamp
                /* translators: %s: how long ago, e.g. "2 hours". */
                ? sprintf(__('%s ago', 'gpt3-ai-content-generator'), human_time_diff($timestamp, time()))
                : '',
        ];
    }
}
