<?php

namespace BitApps\IntegrationsPro\Actions\ConvertForce;

final class ConvertForceProHelper
{
    private const POST_TYPE = 'convertforce-popup';

    private const META_KEY = '_convertforce_conversion';

    public static function createCampaign($defaultResponse, $campaignData)
    {
        if (!self::isPluginInstalled()) {
            return [
                'success' => false,
                'message' => __('ConvertForce Popup Builder is not installed or activated', 'bit-integrations-pro')
            ];
        }

        if (empty($campaignData['title'])) {
            return [
                'success' => false,
                'message' => __('Title is required', 'bit-integrations-pro')
            ];
        }

        $postData = [
            'post_title'   => $campaignData['title'],
            'post_content' => $campaignData['content'] ?? '',
            'post_type'    => self::POST_TYPE,
            'post_status'  => self::normalizeStatus($campaignData['status'] ?? 'draft'),
            'post_author'  => get_current_user_id(),
        ];

        $campaignId = wp_insert_post($postData, true);

        if (is_wp_error($campaignId)) {
            return [
                'success' => false,
                'message' => $campaignId->get_error_message()
            ];
        }

        self::updateCampaignMeta((int) $campaignId, $campaignData);

        return [
            'success' => true,
            'message' => __('Campaign created successfully', 'bit-integrations-pro'),
            'data'    => self::getCampaignData((int) $campaignId)
        ];
    }

    public static function updateCampaign($defaultResponse, $campaignData)
    {
        if (!self::isPluginInstalled()) {
            return [
                'success' => false,
                'message' => __('ConvertForce Popup Builder is not installed or activated', 'bit-integrations-pro')
            ];
        }

        if (empty($campaignData['campaignId'])) {
            return [
                'success' => false,
                'message' => __('Campaign ID is required', 'bit-integrations-pro')
            ];
        }

        $campaignId = (int) $campaignData['campaignId'];

        if (!self::isValidCampaign($campaignId)) {
            return [
                'success' => false,
                'message' => __('ConvertForce campaign not found', 'bit-integrations-pro')
            ];
        }

        $postData = ['ID' => $campaignId];

        if (isset($campaignData['title']) && $campaignData['title'] !== '') {
            $postData['post_title'] = $campaignData['title'];
        }

        if (isset($campaignData['content'])) {
            $postData['post_content'] = $campaignData['content'];
        }

        if (!empty($campaignData['status'])) {
            $postData['post_status'] = self::normalizeStatus($campaignData['status']);
        }

        if (\count($postData) <= 1) {
            return [
                'success' => false,
                'message' => __('No fields to update', 'bit-integrations-pro')
            ];
        }

        $updated = wp_update_post($postData, true);

        if (is_wp_error($updated)) {
            return [
                'success' => false,
                'message' => $updated->get_error_message()
            ];
        }

        self::updateCampaignMeta($campaignId, $campaignData);

        return [
            'success' => true,
            'message' => __('Campaign updated successfully', 'bit-integrations-pro'),
            'data'    => self::getCampaignData($campaignId)
        ];
    }

    public static function updateCampaignStatus($defaultResponse, $campaignData)
    {
        if (!self::isPluginInstalled()) {
            return [
                'success' => false,
                'message' => __('ConvertForce Popup Builder is not installed or activated', 'bit-integrations-pro')
            ];
        }

        if (empty($campaignData['campaignId']) || empty($campaignData['status'])) {
            return [
                'success' => false,
                'message' => __('Campaign ID and status are required', 'bit-integrations-pro')
            ];
        }

        $campaignId = (int) $campaignData['campaignId'];

        if (!self::isValidCampaign($campaignId)) {
            return [
                'success' => false,
                'message' => __('ConvertForce campaign not found', 'bit-integrations-pro')
            ];
        }

        $updated = wp_update_post(
            [
                'ID'          => $campaignId,
                'post_status' => self::normalizeStatus($campaignData['status']),
            ],
            true
        );

        if (is_wp_error($updated)) {
            return [
                'success' => false,
                'message' => $updated->get_error_message()
            ];
        }

        return [
            'success' => true,
            'message' => __('Campaign status updated successfully', 'bit-integrations-pro'),
            'data'    => self::getCampaignData($campaignId)
        ];
    }

    public static function deleteCampaign($defaultResponse, $campaignData)
    {
        if (!self::isPluginInstalled()) {
            return [
                'success' => false,
                'message' => __('ConvertForce Popup Builder is not installed or activated', 'bit-integrations-pro')
            ];
        }

        if (empty($campaignData['campaignId'])) {
            return [
                'success' => false,
                'message' => __('Campaign ID is required', 'bit-integrations-pro')
            ];
        }

        $campaignId = (int) $campaignData['campaignId'];

        if (!self::isValidCampaign($campaignId)) {
            return [
                'success' => false,
                'message' => __('ConvertForce campaign not found', 'bit-integrations-pro')
            ];
        }

        $deleted = wp_delete_post($campaignId, !empty($campaignData['forceDelete']));

        if (!$deleted) {
            return [
                'success' => false,
                'message' => __('Failed to delete the campaign', 'bit-integrations-pro')
            ];
        }

        return [
            'success' => true,
            'message' => __('Campaign deleted successfully', 'bit-integrations-pro'),
            'data'    => ['campaign_id' => $campaignId]
        ];
    }

    private static function isPluginInstalled(): bool
    {
        return \defined('CONVERTFORCE_VERSION');
    }

    private static function isValidCampaign(int $campaignId): bool
    {
        $post = get_post($campaignId);

        return $post instanceof \WP_Post && $post->post_type === self::POST_TYPE;
    }

    private static function getCampaignData(int $postId, $post = null): array
    {
        $post = $post instanceof \WP_Post ? $post : get_post($postId);

        if (!$post) {
            return [];
        }

        $meta = get_post_meta($postId, self::META_KEY, true);

        return [
            'campaign_id'        => $post->ID,
            'title'              => get_the_title($post),
            'content'            => $post->post_content,
            'status'             => $post->post_status,
            'author_id'          => (int) $post->post_author,
            'created_at'         => $post->post_date,
            'updated_at'         => $post->post_modified,
            'meta'               => \is_array($meta) ? $meta : [],
            'display_options'    => \is_array($meta) ? ($meta['displayOptions'] ?? []) : [],
            'display_conditions' => \is_array($meta) ? ($meta['displayConditions'] ?? []) : [],
            'post'               => json_decode(wp_json_encode($post), true),
        ];
    }

    private static function normalizeStatus($status): string
    {
        return \in_array($status, ['publish', 'draft', 'pending', 'private'], true) ? $status : 'draft';
    }

    private static function normalizeJsonField($value): ?array
    {
        if ($value === null || $value === '') {
            return null;
        }

        if (\is_array($value)) {
            return $value;
        }

        if (!\is_string($value)) {
            return null;
        }

        $decoded = json_decode(wp_unslash($value), true);

        return \is_array($decoded) ? $decoded : null;
    }

    private static function updateCampaignMeta(int $campaignId, array $campaignData): void
    {
        $meta = get_post_meta($campaignId, self::META_KEY, true);

        if (!\is_array($meta)) {
            $meta = [];
        }

        $displayOptions = self::normalizeJsonField($campaignData['displayOptions'] ?? null);
        $displayConditions = self::normalizeJsonField($campaignData['displayConditions'] ?? null);

        if (\is_array($displayOptions)) {
            $meta['displayOptions'] = $displayOptions;
        }

        if (\is_array($displayConditions)) {
            $meta['displayConditions'] = $displayConditions;
        }

        if (!empty($meta)) {
            update_post_meta($campaignId, self::META_KEY, $meta);
        }
    }
}
