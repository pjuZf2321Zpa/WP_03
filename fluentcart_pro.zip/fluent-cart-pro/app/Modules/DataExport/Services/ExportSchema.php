<?php

namespace FluentCartPro\App\Modules\DataExport\Services;

use FluentCart\Api\ModuleSettings;

class ExportSchema
{
    public const ORDERS = 'orders';

    public const CUSTOMERS = 'customers';

    public const SUBSCRIPTIONS = 'subscriptions';

    public const LICENSES = 'licenses';

    public static function get( string $entity ): array
    {
        if ( $entity === self::ORDERS ) {
            return self::orders();
        }

        if ( $entity === self::CUSTOMERS ) {
            return self::customers();
        }

        if ( $entity === self::SUBSCRIPTIONS ) {
            return self::subscriptions();
        }

        if ( $entity === self::LICENSES && self::isLicenseAvailable() ) {
            return self::licenses();
        }

        return [];
    }

    public static function isAvailable( string $entity ): bool
    {
        return $entity !== self::LICENSES || self::isLicenseAvailable();
    }

    public static function isLicenseAvailable(): bool
    {
        return ModuleSettings::isActive( 'license' );
    }

    public static function selectedColumns( string $entity, array $requested ): array
    {
        $schema = self::get( $entity );
        $available = array_column( $schema['csv_columns'] ?? [], 'key' );

        return array_values( array_intersect( $available, $requested ) );
    }

    public static function selectedModules( string $entity, array $requested ): array
    {
        $schema = self::get( $entity );
        $available = array_column( $schema['json_modules'] ?? [], 'key' );
        $selected = array_values( array_intersect( $available, $requested ) );
        $rootModule = $entity;

        if ( !in_array( $rootModule, $selected, true ) ) {
            array_unshift( $selected, $rootModule );
        }

        return array_values( array_unique( $selected ) );
    }

    private static function orders(): array
    {
        return [
            'entity'             => self::ORDERS,
            'schema_version'     => 1,
            'formats'            => [
                ['value' => 'csv', 'label' => __( 'CSV file', 'fluent-cart-pro' )],
                ['value' => 'json', 'label' => __( 'JSON file', 'fluent-cart-pro' )],
            ],
            'csv_columns'        => [
                self::column( 'order_id', __( 'Order ID', 'fluent-cart-pro' ) ),
                self::column( 'invoice_no', __( 'Invoice number', 'fluent-cart-pro' ) ),
                self::column( 'status', __( 'Order status', 'fluent-cart-pro' ) ),
                self::column( 'payment_status', __( 'Payment status', 'fluent-cart-pro' ) ),
                self::column( 'shipping_status', __( 'Shipping status', 'fluent-cart-pro' ), false ),
                self::column( 'currency', __( 'Currency', 'fluent-cart-pro' ) ),
                self::column( 'subtotal', __( 'Subtotal', 'fluent-cart-pro' ) ),
                self::column( 'discount_total', __( 'Discount total', 'fluent-cart-pro' ) ),
                self::column( 'shipping_total', __( 'Shipping total', 'fluent-cart-pro' ) ),
                self::column( 'tax_total', __( 'Tax total', 'fluent-cart-pro' ) ),
                self::column( 'total_amount', __( 'Total amount', 'fluent-cart-pro' ) ),
                self::column( 'total_refund', __( 'Refund total', 'fluent-cart-pro' ), false ),
                self::column( 'items_count', __( 'Items count', 'fluent-cart-pro' ) ),
                self::column( 'order_type', __( 'Order type', 'fluent-cart-pro' ) ),
                self::column( 'payment_method', __( 'Payment method', 'fluent-cart-pro' ) ),
                self::column( 'customer_id', __( 'Customer ID', 'fluent-cart-pro' ) ),
                self::column( 'customer_name', __( 'Customer name', 'fluent-cart-pro' ) ),
                self::column( 'customer_email', __( 'Customer email', 'fluent-cart-pro' ) ),
                self::column( 'mode', __( 'Mode', 'fluent-cart-pro' ), false ),
                self::column( 'created_at', __( 'Order date', 'fluent-cart-pro' ) ),
                self::column( 'completed_at', __( 'Completed date', 'fluent-cart-pro' ), false ),
            ],
            'json_modules'       => [
                self::module( 'orders', __( 'Orders', 'fluent-cart-pro' ), __( 'Core rows from the orders table.', 'fluent-cart-pro' ), true, true ),
                self::module( 'customers', __( 'Customers', 'fluent-cart-pro' ), __( 'The customer row linked to each order.', 'fluent-cart-pro' ), true ),
                self::module( 'order_items', __( 'Order items', 'fluent-cart-pro' ), __( 'Line items linked to each order.', 'fluent-cart-pro' ), true ),
                self::module( 'order_addresses', __( 'Order addresses', 'fluent-cart-pro' ), __( 'Billing and shipping address rows.', 'fluent-cart-pro' ) ),
                self::module( 'order_transactions', __( 'Transactions', 'fluent-cart-pro' ), __( 'Payment transaction rows.', 'fluent-cart-pro' ) ),
                self::module( 'order_tax_rates', __( 'Tax rates', 'fluent-cart-pro' ), __( 'Applied order tax rows.', 'fluent-cart-pro' ) ),
                self::module( 'order_meta', __( 'Order metadata', 'fluent-cart-pro' ), __( 'Metadata rows attached to each order.', 'fluent-cart-pro' ) ),
            ],
            'batching'           => self::batching(),
            'direct_file_writer' => true,
            'sensitive_values_redacted' => true,
        ];
    }

    private static function customers(): array
    {
        return [
            'entity'             => self::CUSTOMERS,
            'schema_version'     => 1,
            'formats'            => [
                ['value' => 'csv', 'label' => __( 'CSV file', 'fluent-cart-pro' )],
                ['value' => 'json', 'label' => __( 'JSON file', 'fluent-cart-pro' )],
            ],
            'csv_columns'        => [
                self::column( 'customer_id', __( 'Customer ID', 'fluent-cart-pro' ) ),
                self::column( 'first_name', __( 'First name', 'fluent-cart-pro' ) ),
                self::column( 'last_name', __( 'Last name', 'fluent-cart-pro' ) ),
                self::column( 'full_name', __( 'Full name', 'fluent-cart-pro' ) ),
                self::column( 'email', __( 'Email', 'fluent-cart-pro' ) ),
                self::column( 'status', __( 'Status', 'fluent-cart-pro' ) ),
                self::column( 'purchase_count', __( 'Purchases', 'fluent-cart-pro' ) ),
                self::column( 'lifetime_value', __( 'Lifetime value', 'fluent-cart-pro' ) ),
                self::column( 'average_order_value', __( 'Average order value', 'fluent-cart-pro' ), false ),
                self::column( 'first_purchase_date', __( 'First purchase date', 'fluent-cart-pro' ) ),
                self::column( 'last_purchase_date', __( 'Last purchase date', 'fluent-cart-pro' ) ),
                self::column( 'customer_since', __( 'Customer since', 'fluent-cart-pro' ) ),
                self::column( 'country', __( 'Country', 'fluent-cart-pro' ) ),
                self::column( 'state', __( 'State', 'fluent-cart-pro' ) ),
                self::column( 'city', __( 'City', 'fluent-cart-pro' ) ),
                self::column( 'postcode', __( 'Postcode', 'fluent-cart-pro' ) ),
                self::column( 'wordpress_user_id', __( 'WordPress user ID', 'fluent-cart-pro' ), false ),
                self::column( 'contact_id', __( 'Contact ID', 'fluent-cart-pro' ), false ),
            ],
            'json_modules'       => [
                self::module( 'customers', __( 'Customers', 'fluent-cart-pro' ), __( 'Core rows from the customers table.', 'fluent-cart-pro' ), true, true ),
                self::module( 'customer_addresses', __( 'Customer addresses', 'fluent-cart-pro' ), __( 'Saved address-book rows.', 'fluent-cart-pro' ), true ),
                self::module( 'purchased_items', __( 'Purchased items', 'fluent-cart-pro' ), __( 'Every line item the customer ordered, with its order status and payment status.', 'fluent-cart-pro' ), true ),
                self::module( 'customer_meta', __( 'Customer metadata', 'fluent-cart-pro' ), __( 'Metadata rows attached to each customer.', 'fluent-cart-pro' ) ),
            ],
            'batching'           => self::batching(),
            'direct_file_writer' => true,
            'sensitive_values_redacted' => true,
        ];
    }

    private static function subscriptions(): array
    {
        $modules = [
            self::module( 'subscriptions', __( 'Subscriptions', 'fluent-cart-pro' ), __( 'Core rows from the subscriptions table. Sensitive payment credentials are redacted.', 'fluent-cart-pro' ), true, true ),
            self::module( 'customers', __( 'Customers', 'fluent-cart-pro' ), __( 'The customer row linked to each subscription.', 'fluent-cart-pro' ), true ),
            self::module( 'parent_orders', __( 'Original orders', 'fluent-cart-pro' ), __( 'The original order row linked to each subscription.', 'fluent-cart-pro' ) ),
            self::module( 'subscription_transactions', __( 'Transactions', 'fluent-cart-pro' ), __( 'Payment transaction rows linked to each subscription. Sensitive values are redacted.', 'fluent-cart-pro' ) ),
            self::module( 'subscription_meta', __( 'Subscription metadata', 'fluent-cart-pro' ), __( 'Metadata rows attached to each subscription. Sensitive values are redacted.', 'fluent-cart-pro' ) ),
        ];

        if ( self::isLicenseAvailable() ) {
            $modules[] = self::module( 'licenses', __( 'Licenses', 'fluent-cart-pro' ), __( 'License rows linked to each subscription.', 'fluent-cart-pro' ) );
        }

        return [
            'entity'             => self::SUBSCRIPTIONS,
            'schema_version'     => 1,
            'formats'            => [
                ['value' => 'csv', 'label' => __( 'CSV file', 'fluent-cart-pro' )],
                ['value' => 'json', 'label' => __( 'JSON file', 'fluent-cart-pro' )],
            ],
            'csv_columns'        => [
                self::column( 'subscription_id', __( 'Subscription ID', 'fluent-cart-pro' ) ),
                self::column( 'status', __( 'Status', 'fluent-cart-pro' ) ),
                self::column( 'item_name', __( 'Item name', 'fluent-cart-pro' ) ),
                self::column( 'customer_id', __( 'Customer ID', 'fluent-cart-pro' ) ),
                self::column( 'customer_name', __( 'Customer name', 'fluent-cart-pro' ) ),
                self::column( 'customer_email', __( 'Customer email', 'fluent-cart-pro' ) ),
                self::column( 'parent_order_id', __( 'Original order ID', 'fluent-cart-pro' ) ),
                self::column( 'product_id', __( 'Product ID', 'fluent-cart-pro' ) ),
                self::column( 'variation_id', __( 'Variation ID', 'fluent-cart-pro' ) ),
                self::column( 'billing_interval', __( 'Billing interval', 'fluent-cart-pro' ) ),
                self::column( 'quantity', __( 'Quantity', 'fluent-cart-pro' ) ),
                self::column( 'signup_fee', __( 'Signup fee', 'fluent-cart-pro' ), false ),
                self::column( 'recurring_amount', __( 'Recurring amount', 'fluent-cart-pro' ) ),
                self::column( 'recurring_tax_total', __( 'Recurring tax total', 'fluent-cart-pro' ) ),
                self::column( 'recurring_total', __( 'Recurring total', 'fluent-cart-pro' ) ),
                self::column( 'bill_times', __( 'Billing cycles', 'fluent-cart-pro' ) ),
                self::column( 'bill_count', __( 'Completed billings', 'fluent-cart-pro' ) ),
                self::column( 'trial_days', __( 'Trial days', 'fluent-cart-pro' ), false ),
                self::column( 'collection_method', __( 'Collection method', 'fluent-cart-pro' ) ),
                self::column( 'payment_method', __( 'Payment method', 'fluent-cart-pro' ) ),
                self::column( 'vendor_subscription_id', __( 'Gateway subscription ID', 'fluent-cart-pro' ), false ),
                self::column( 'next_billing_date', __( 'Next billing date', 'fluent-cart-pro' ) ),
                self::column( 'trial_ends_at', __( 'Trial end date', 'fluent-cart-pro' ), false ),
                self::column( 'expire_at', __( 'Expiration date', 'fluent-cart-pro' ), false ),
                self::column( 'canceled_at', __( 'Canceled date', 'fluent-cart-pro' ), false ),
                self::column( 'created_at', __( 'Created date', 'fluent-cart-pro' ) ),
                self::column( 'updated_at', __( 'Updated date', 'fluent-cart-pro' ), false ),
            ],
            'json_modules'       => $modules,
            'batching'           => self::batching(),
            'direct_file_writer' => true,
            'sensitive_values_redacted' => true,
        ];
    }

    private static function licenses(): array
    {
        return [
            'entity'             => self::LICENSES,
            'schema_version'     => 1,
            'formats'            => [
                ['value' => 'csv', 'label' => __( 'CSV file', 'fluent-cart-pro' )],
                ['value' => 'json', 'label' => __( 'JSON file', 'fluent-cart-pro' )],
            ],
            'csv_columns'        => [
                self::column( 'license_id', __( 'License ID', 'fluent-cart-pro' ) ),
                self::column( 'license_key', __( 'License key', 'fluent-cart-pro' ) ),
                self::column( 'status', __( 'Status', 'fluent-cart-pro' ) ),
                self::column( 'activation_limit', __( 'Activation limit', 'fluent-cart-pro' ) ),
                self::column( 'activation_count', __( 'Activation count', 'fluent-cart-pro' ) ),
                self::column( 'customer_id', __( 'Customer ID', 'fluent-cart-pro' ) ),
                self::column( 'customer_name', __( 'Customer name', 'fluent-cart-pro' ) ),
                self::column( 'customer_email', __( 'Customer email', 'fluent-cart-pro' ) ),
                self::column( 'order_id', __( 'Order ID', 'fluent-cart-pro' ) ),
                self::column( 'subscription_id', __( 'Subscription ID', 'fluent-cart-pro' ), false ),
                self::column( 'product_id', __( 'Product ID', 'fluent-cart-pro' ) ),
                self::column( 'variation_id', __( 'Variation ID', 'fluent-cart-pro' ) ),
                self::column( 'expiration_date', __( 'Expiration date', 'fluent-cart-pro' ) ),
                self::column( 'created_at', __( 'Created date', 'fluent-cart-pro' ) ),
                self::column( 'updated_at', __( 'Updated date', 'fluent-cart-pro' ), false ),
            ],
            'json_modules'       => [
                self::module( 'licenses', __( 'Licenses', 'fluent-cart-pro' ), __( 'Core rows from the licenses table.', 'fluent-cart-pro' ), true, true ),
                self::module( 'customers', __( 'Customers', 'fluent-cart-pro' ), __( 'The customer row linked to each license.', 'fluent-cart-pro' ), true ),
                self::module( 'orders', __( 'Orders', 'fluent-cart-pro' ), __( 'The order row linked to each license.', 'fluent-cart-pro' ) ),
                self::module( 'subscriptions', __( 'Subscriptions', 'fluent-cart-pro' ), __( 'The subscription row linked to each license.', 'fluent-cart-pro' ) ),
                self::module( 'license_activations', __( 'License activations', 'fluent-cart-pro' ), __( 'Activation rows attached to each license. Authentication hashes are excluded.', 'fluent-cart-pro' ), true ),
                self::module( 'license_sites', __( 'Activated sites', 'fluent-cart-pro' ), __( 'Unique site rows referenced by the selected license activations.', 'fluent-cart-pro' ), true ),
                self::module( 'license_meta', __( 'License metadata', 'fluent-cart-pro' ), __( 'Metadata rows attached directly to each license.', 'fluent-cart-pro' ) ),
            ],
            'batching'           => self::batching(),
            'direct_file_writer' => true,
            'sensitive_values_redacted' => true,
        ];
    }

    private static function column( string $key, string $label, bool $defaultSelected = true ): array
    {
        return [
            'key'              => $key,
            'label'            => $label,
            'default_selected' => $defaultSelected,
        ];
    }

    private static function module(
        string $key,
        string $label,
        string $description,
        bool $defaultSelected = false,
        bool $required = false
    ): array {
        return [
            'key'              => $key,
            'label'            => $label,
            'description'      => $description,
            'default_selected' => $defaultSelected,
            'required'         => $required,
        ];
    }

    private static function batching(): array
    {
        return [
            'initial_records' => 500,
            'min_records'     => 100,
            'max_records'     => 1000,
            'target_ms'       => 1500,
        ];
    }
}
