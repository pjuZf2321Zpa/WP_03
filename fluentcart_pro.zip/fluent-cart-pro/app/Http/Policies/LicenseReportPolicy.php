<?php

namespace FluentCartPro\App\Http\Policies;

use FluentCart\App\Http\Policies\Policy;
use FluentCart\Framework\Http\Request\Request;

/**
 * Reports → Licenses needs both: report access for the figures, license access for the license data
 */
class LicenseReportPolicy extends Policy
{
    public function verifyRequest(Request $request): bool
    {
        return $this->userCan('reports/view') && $this->userCan('licenses/view');
    }
}
