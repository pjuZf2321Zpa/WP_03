<?php

namespace BitApps\IntegrationsPro\Actions\NiroHelp\Services;

use NiroHelp\Models\Agent;

if (!\defined('ABSPATH')) {
    exit;
}

final class AgentService extends BaseService
{
    public function addAgent(): array
    {
        $error = $this->validateRequiredFields(['user_id' => __('User ID', 'bit-integrations-pro')]);

        if ($error !== null) {
            return $error;
        }

        $maxTickets = $this->getInteger('max_tickets');

        if ($maxTickets !== null && $maxTickets < 0) {
            return $this->errorResponse(__('Max Open Tickets is not valid. Use 0 or a larger whole number.', 'bit-integrations-pro'));
        }

        $agentId = Agent::promote((int) $this->getInteger('user_id'));

        if (is_wp_error($agentId)) {
            return $this->errorResponse($agentId->get_error_message());
        }

        Agent::save_max($agentId, $maxTickets);

        return $this->successResponse(__('The user is now a NiroHelp agent.', 'bit-integrations-pro'), Agent::row($agentId));
    }
}
