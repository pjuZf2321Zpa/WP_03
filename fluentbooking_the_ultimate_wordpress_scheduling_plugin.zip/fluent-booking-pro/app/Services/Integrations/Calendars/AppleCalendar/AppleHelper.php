<?php

namespace FluentBookingPro\App\Services\Integrations\Calendars\AppleCalendar;

use FluentBooking\App\Models\Meta;
use FluentBooking\App\Services\Helper;
use FluentBooking\App\Services\DateTimeHelper;
use FluentBooking\Framework\Support\Arr;

class AppleHelper
{
    public static function getApiConfig()
    {
        $defaults = [
            'is_enabled'   => 'no',
            'caching_time' => '5'
        ];

        $settings = get_option('_fcal_apple_calendar_client_details', []);

        $settings = wp_parse_args($settings, $defaults);

        return $settings;
    }

    public static function updateConfig($settings)
    {
        $settings = [
            'is_enabled'   => Arr::get($settings, 'is_enabled', 'no'),
            'caching_time' => Arr::get($settings, 'caching_time', 5)
        ];

        update_option('_fcal_apple_calendar_client_details', $settings, 'no');

        return $settings;
    }

    public static function getClientByMeta(Meta $meta)
    {
        $settings = $meta->value;
        $userName = Arr::get($settings, 'remote_email');
        $passWord = Helper::decryptKey(Arr::get($settings, 'remote_pass'));

        // Callers guard with !$client; a WP_Error is truthy and reached ->getClient().
        if (!$userName || !$passWord) {
            return false;
        }

        return new IcloudClient($userName, $passWord);
    }

    public static function getTravelDuration($event)
    {
        if (empty($event->additionalProperties)) {
            return 0;
        }

        $travelDuration = Arr::get($event->additionalProperties, 'x_apple_travel_duration');

        return DateTimeHelper::getIsoDurationInMinutes($travelDuration);
    }
}
