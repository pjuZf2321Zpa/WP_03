<?php

if (!defined('ABSPATH')) {
    die('You are not allowed to call this page directly.');
}

/**
 * Controller for the shop page: product query, AJAX filter endpoint, and [mepr_shop] shortcode.
 */
class MeprShopCtrl extends MeprBaseCartCtrl
{
    /**
     * Register hooks for shop AJAX filter and [mepr_shop] shortcode.
     *
     * @return void
     */
    public function load_hooks()
    {
        // Shop AJAX filter endpoint (available to guests too).
        add_action('wp_ajax_mepr_shop_filter', [$this, 'filter_products_ajax']);
        add_action('wp_ajax_nopriv_mepr_shop_filter', [$this, 'filter_products_ajax']);

        // Register mepr-shopjs early so add-ons can safely declare it as a dependency.
        add_action('wp_enqueue_scripts', [$this, 'register_scripts'], 1);

        // Enqueue shop CSS/JS on the shop page regardless of ReadyLaunch template setting.
        add_action('wp_enqueue_scripts', [$this, 'enqueue_scripts']);


        // [mepr_shop] shortcode.
        MeprHooks::add_shortcode('mepr_shop', [$this, 'shop_shortcode']);
    }

    /**
     * Register mepr-shopjs unconditionally so add-ons can declare it as a dependency
     * without triggering the WP 6.9.1 "dependency not registered" notice.
     *
     * @return void
     */
    public function register_scripts()
    {
        wp_register_script('mepr-shopjs', MEPR_JS_URL . '/readylaunch/shop.js', ['jquery'], MEPR_VERSION, true);
    }

    /**
     * Enqueue shop JS on the shop page.
     *
     * Fires on wp_enqueue_scripts regardless of whether the ReadyLaunch full-page
     * template is enabled, so the [mepr_shop] shortcode renders correctly in both modes.
     * shop.css is content styling (not RL chrome) so it loads always; when RL is active,
     * add_template_scripts('shop') also fires but WordPress deduplicates by handle.
     *
     * @return void
     */
    public function enqueue_scripts()
    {
        $options = MeprOptions::fetch();
        if (empty($options->shop_page_id) || !is_page($options->shop_page_id)) {
            return;
        }

        wp_enqueue_style('mp-pro-shop', MEPR_CSS_URL . '/shop.css', ['mepr-cart-tokens', 'mepr-ds-components'], MEPR_VERSION);
        wp_enqueue_script('mepr-shopjs', MEPR_JS_URL . '/readylaunch/shop.js', ['jquery'], MEPR_VERSION, true);
        wp_localize_script('mepr-shopjs', 'MeprShop', [
            'ajax_url'     => admin_url('admin-ajax.php'),
            'nonce'        => wp_create_nonce('mepr_cart_nonce'),
            'cart_url'     => $options->cart_page_url(),
            'checkout_url' => $options->checkout_page_url(),
            'i18n'         => MeprHooks::apply_filters('mepr_shop_js_i18n', [
                'in_cart'             => __('In Cart', 'memberpress'),
                'add_to_cart'         => __('Add To Cart', 'memberpress'),
                // Translators: %s: product name.
                'add_to_cart_named'   => __('Add "%s" to cart', 'memberpress'),
                // Translators: %s: product name.
                'in_cart_named'       => __('"%s" is in your cart', 'memberpress'),
                'adding'              => __('Adding...', 'memberpress'),
                'added_to_cart'       => __('Added to Cart', 'memberpress'),
                // Translators: %d = the corrected quantity.
                'qty_adjusted'        => __('Quantity adjusted to %d', 'memberpress'),
                'continue_shopping'   => __('Continue Shopping', 'memberpress'),
                'proceed_to_checkout' => __('Proceed to Checkout', 'memberpress'),
                // Translators: %count% is replaced with the cart item count in JS.
                'cart_subtotal'       => __('Cart subtotal (%count% items):', 'memberpress'),
                'close'               => __('Close', 'memberpress'),
                'sort_by'             => _x('Sort By', 'shop sort', 'memberpress'),
                'error_generic'       => __('An error occurred. Please try again.', 'memberpress'),
                'no_products_found'   => __('No products found.', 'memberpress'),
                // Translators: %d = number of products found.
                'products_found_one'  => __('%d product found', 'memberpress'),
                // Translators: %d = number of products found.
                'products_found_many' => __('%d products found', 'memberpress'),
            ]),
        ]);
    }

    /**
     * Shortcode [mepr_shop]: Build the shop product query and render the shop template.
     *
     * Renders the ReadyLaunch shop page template (readylaunch/shop/page.php) with
     * the full product query, category/type/search filters, and the current cart
     * state so product cards can show "In Cart" for items already in the cart.
     *
     * @param  array $atts Shortcode attributes (reserved for future use).
     * @return string HTML output for the [mepr_shop] shortcode.
     */
    public function shop_shortcode($atts = [])
    {
        $per_page   = (int) MeprHooks::apply_filters('mepr_shop_products_per_page', 12);
        $args       = $this->build_query_args();
        $shop_query = $this->get_products($args);

        // Determine which product IDs are already in the cart.
        $session          = MeprCartSessionService::current_session();
        $items            = $session ? MeprCartSessionService::get_items($session) : [];
        $cart_product_ids = array_map('intval', array_keys($items));

        // Category terms for the filter dropdown.
        $categories = get_terms([
            'taxonomy'   => MeprProduct::$taxonomy_product_category,
            'hide_empty' => true,
        ]);
        if (is_wp_error($categories)) {
            $categories = [];
        }

        // Product types available in the type filter (same list as the admin type dropdown).
        $product_types = MeprProduct::available_types();

        // Current filter values (from GET for initial page load).
        $current_category = isset($_GET['category'])     ? sanitize_text_field(wp_unslash($_GET['category']))     : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
        $current_type     = isset($_GET['product_type']) ? sanitize_text_field(wp_unslash($_GET['product_type'])) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
        $current_search   = isset($_GET['s'])            ? sanitize_text_field(wp_unslash($_GET['s']))            : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
        $current_sort     = isset($_GET['sort'])         ? sanitize_text_field(wp_unslash($_GET['sort']))         : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended

        $cart_items = $items;

        return MeprView::get_string('/readylaunch/shop/page', compact(
            'shop_query',
            'categories',
            'product_types',
            'current_category',
            'current_type',
            'current_search',
            'current_sort',
            'cart_product_ids',
            'cart_items',
            'per_page'
        ));
    }

    /**
     * AJAX: Filter/search products for the shop page.
     *
     * Reads filter parameters from $_POST and returns an HTML fragment
     * (product grid cards) and pagination HTML so the JS can re-render the grid
     * without a full page reload.
     *
     * @return void Sends JSON response and exits.
     */
    public function filter_products_ajax()
    {
        if (!check_ajax_referer('mepr_cart_nonce', 'nonce', false)) {
            wp_send_json_error(['message' => __('Security check failed.', 'memberpress')], 403);
        }

        // Reject product types the shop doesn't offer (same list as the tabs).
        $posted_type = isset($_POST['product_type']) ? sanitize_text_field(wp_unslash($_POST['product_type'])) : '';
        if ($posted_type !== '' && !in_array($posted_type, MeprProduct::available_types(), true)) {
            wp_send_json_error(['message' => __('Invalid product type.', 'memberpress')], 400);
        }

        $args       = $this->build_query_args('post');
        $shop_query = $this->get_products($args);

        // Determine current cart state so product cards render with correct "In Cart" state.
        $session          = MeprCartSessionService::current_session();
        $items            = $session ? MeprCartSessionService::get_items($session) : [];
        $cart_product_ids = array_map('intval', array_keys($items));
        $cart_items       = $items;

        // Build product cards HTML fragment.
        $cards_html = '';
        if ($shop_query->have_posts()) {
            while ($shop_query->have_posts()) {
                $shop_query->the_post();
                $product     = new MeprProduct(get_the_ID());
                $cards_html .= MeprView::get_string('/readylaunch/shop/product-card', compact('product', 'cart_product_ids', 'cart_items'));
            }
            wp_reset_postdata();
        } else {
            $cards_html = '<div class="mepr-shop-empty"><p>' . esc_html__('No products found.', 'memberpress') . '</p></div>';
        }

        // Build pagination HTML fragment.
        $paged           = max(1, (int) (isset($_POST['paged']) ? absint($_POST['paged']) : 1)); // phpcs:ignore WordPress.Security.NonceVerification.Missing
        $pagination_html = paginate_links([
            'total'     => $shop_query->max_num_pages,
            'current'   => $paged,
            'format'    => '?paged=%#%',
            'prev_text' => '<span aria-hidden="true">&laquo;</span><span class="mepr-shop-sr-only">' . esc_html__('Previous page', 'memberpress') . '</span>',
            'next_text' => '<span aria-hidden="true">&raquo;</span><span class="mepr-shop-sr-only">' . esc_html__('Next page', 'memberpress') . '</span>',
        ]);

        wp_send_json_success([
            'html'       => $cards_html,
            'pagination' => $pagination_html ?: '',
            'total'      => intval($shop_query->found_posts),
        ]);
    }

    /**
     * Build WP_Query args for the shop product listing.
     *
     * Centralises filter logic used by both shortcode and AJAX handler.
     *
     * @param  string $source Either 'get' (shortcode/page load) or 'post' (AJAX filter).
     * @return array WP_Query args array.
     */
    private function build_query_args(string $source = 'get'): array
    {
        $params = ('post' === $source) ? $_POST : $_GET; // phpcs:ignore WordPress.Security.NonceVerification.Recommended

        $posts_per_page = (int) MeprHooks::apply_filters('mepr_shop_products_per_page', 12);

        // Allow per_page override from POST (AJAX "Show" dropdown).
        if ('post' === $source && !empty($params['per_page'])) {
            $posts_per_page = max(1, min(96, absint($params['per_page'])));
        }

        $paged = max(1, (int) get_query_var('paged', 1));

        // Override paged from POST for AJAX requests.
        if ('post' === $source && !empty($params['paged'])) {
            $paged = max(1, absint($params['paged']));
        }

        // Base args.
        $args = [
            'post_type'      => MeprProduct::$cpt,
            'post_status'    => 'publish',
            'posts_per_page' => $posts_per_page,
            'paged'          => $paged,
            // OR meta_query — show explicitly visible products, and products where the
            // meta key doesn't exist yet (legacy products).
            'meta_query'     => [
                'relation' => 'OR',
                [
                    'key'     => MeprProduct::$shop_visibility_str,
                    'value'   => 'visible',
                ],
                [
                    'key'     => MeprProduct::$shop_visibility_str,
                    'compare' => 'NOT EXISTS',
                ],
            ],
        ];

        // Optional category filter.
        $category = !empty($params['category']) ? sanitize_text_field(wp_unslash($params['category'])) : '';
        if ($category) {
            $args['tax_query'] = [
                [
                    'taxonomy' => MeprProduct::$taxonomy_product_category,
                    'field'    => 'slug',
                    'terms'    => $category,
                ],
            ];
        }

        // Optional product type filter — types the shop doesn't offer are ignored (no filter applied).
        $product_type = !empty($params['product_type']) ? sanitize_text_field(wp_unslash($params['product_type'])) : '';
        if ($product_type && !in_array($product_type, MeprProduct::available_types(), true)) {
            $product_type = '';
        }
        if ($product_type) {
            if ($product_type === MeprProduct::TYPE_MEMBERSHIP) {
                // A product with no stored type (e.g. created while the cart was off) defaults to a
                // membership via MeprProduct::effective_type(), so match missing/empty type meta too.
                $type_meta = [
                    'relation' => 'OR',
                    [
                        'key' => MeprProduct::$type_str,
                        'value' => $product_type,
                    ],
                    [
                        'key' => MeprProduct::$type_str,
                        'compare' => 'NOT EXISTS',
                    ],
                    [
                        'key' => MeprProduct::$type_str,
                        'value' => '',
                        'compare' => '=',
                    ],
                ];
            } else {
                $type_meta = [
                    'key'   => MeprProduct::$type_str,
                    'value' => $product_type,
                ];
            }

            if (isset($args['meta_query'])) {
                // Wrap existing meta_query with the type filter inside an AND relationship.
                $args['meta_query'] = [
                    'relation' => 'AND',
                    $args['meta_query'],
                    $type_meta,
                ];
            } else {
                $args['meta_query'] = [$type_meta];
            }
        }

        // Optional keyword search.
        $search = !empty($params['s']) ? sanitize_text_field(wp_unslash($params['s'])) : '';
        if ($search) {
            $args['s'] = $search;
        }

        // Sort / order parameter.
        $sort = !empty($params['sort']) ? sanitize_text_field(wp_unslash($params['sort'])) : '';
        switch ($sort) {
            case 'price_asc':
                $args['meta_key'] = MeprProduct::$price_str;
                $args['orderby']  = 'meta_value_num';
                $args['order']    = 'ASC';
                break;
            case 'price_desc':
                $args['meta_key'] = MeprProduct::$price_str;
                $args['orderby']  = 'meta_value_num';
                $args['order']    = 'DESC';
                break;
            case 'featured':
                $args['orderby'] = 'menu_order';
                $args['order']   = 'ASC';
                break;
            default:
                // Default sort: newest first.
                $args['orderby'] = 'date';
                $args['order']   = 'DESC';
                break;
        }

        return $args;
    }

    /**
     * Execute a WP_Query for shop products using the given args.
     *
     * Shared by both the shortcode and the AJAX filter handler so query
     * construction logic lives in exactly one place.
     *
     * @param  array $args WP_Query arguments (from build_query_args()).
     * @return WP_Query
     */
    public function get_products(array $args): WP_Query
    {
        return new WP_Query($args);
    }
}
