<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Actions\ProfilePress\ProfilePressProHelper;
use BitApps\IntegrationsPro\Config;
use BitApps\IntegrationsPro\Core\Util\Hooks;

// field map + utilities + config
Hooks::filter(Config::withFreePrefix('profilepress_add_new_order'), [ProfilePressProHelper::class, 'addNewOrder'], 10, 4);

Hooks::filter(Config::withFreePrefix('profilepress_add_or_update_customer'), [ProfilePressProHelper::class, 'addOrUpdateCustomer'], 10, 2);
