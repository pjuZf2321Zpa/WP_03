<?php

namespace MasterStudy\Lms\Pro\addons\google_classrooms\Admin\Http\Controllers;

use MasterStudy\Lms\Http\WpResponseFactory;
use MasterStudy\Lms\Pro\addons\google_classrooms\Admin\Http\Serializers\ClassroomSerializer;
use MasterStudy\Lms\Pro\addons\google_classrooms\Admin\Repositories\ClassroomsRepository;
use MasterStudy\Lms\Validation\Validator;
use RuntimeException;
use WP_REST_Request;
use WP_REST_Response;

final class UpdateClassroomController {
	public function __invoke( int $id, WP_REST_Request $request ): WP_REST_Response {
		$repository = new ClassroomsRepository();

		if ( ! $repository->exists( $id ) ) {
			return WpResponseFactory::not_found();
		}

		$validator = new Validator(
			$request->get_json_params(),
			array(
				'title'       => 'required|string',
				'description' => 'nullable|string',
			)
		);

		if ( $validator->fails() ) {
			return WpResponseFactory::validation_failed( $validator->get_errors_array() );
		}

		$validated = $validator->get_validated();

		try {
			$repository->update(
				$id,
				array(
					'post_title'   => $validated['title'],
					'post_content' => $validated['description'] ?? '',
				)
			);
		} catch ( RuntimeException $e ) {
			if ( 403 === $e->getCode() ) {
				return WpResponseFactory::forbidden();
			}

			return WpResponseFactory::bad_request( $e->getMessage() );
		}

		$post = get_post( $id );

		return WpResponseFactory::ok_with_data(
			array(
				'item' => ( new ClassroomSerializer() )->toArray( $post ),
			)
		);
	}
}
