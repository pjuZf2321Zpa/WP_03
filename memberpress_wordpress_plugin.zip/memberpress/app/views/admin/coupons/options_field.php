<?php

if (!defined('ABSPATH')) {
    die('You are not allowed to call this page directly.');
}

/**
 * Coupon field toggle on the options registration section.
 *
 * Rendered by MeprCouponsCtrl on the mepr_options_signup_fields action. The
 * hidden marker tells the module's save handler the section rendered, so a
 * form without it can never wipe the stored setting.
 *
 * @var MeprOptions $mepr_options The options object.
 */
?>
<div id="mepr-option-coupon-field-enabled" class="mp-col-5">
  <input type="hidden" name="mepr_present[coupon_field]" value="1" />
  <label for="<?php echo esc_attr($mepr_options->coupon_field_enabled_str); ?>">
    <input type="checkbox" name="<?php echo esc_attr($mepr_options->coupon_field_enabled_str); ?>" id="<?php echo esc_attr($mepr_options->coupon_field_enabled_str); ?>" <?php checked($mepr_options->coupon_field_enabled); ?> />
    <span><?php esc_html_e('Enable Coupon Field on product registration forms', 'memberpress'); ?></span>
  </label>
</div>
