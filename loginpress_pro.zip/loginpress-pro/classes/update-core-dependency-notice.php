<?php
/**
 * Plugins list update notice row (inactive license).
 *
 * @since 6.2.3
 *
 * Expects $loginpress_notice_data from LoginPress_Pro_Update_Dependency::loginpress_render_license_notice_row().
 *
 * @var array $loginpress_notice_data {
 *     @type string $version      Pro version available.
 *     @type string $release_url  Learn more URL.
 *     @type string $renew_url    Primary action URL.
 *     @type int    $colspan      Plugins table column count.
 *     @type string $active_class " active" when the plugin is active.
 * }
 * @package LoginPress-pro
 */

defined( 'ABSPATH' ) || exit;

if ( empty( $loginpress_notice_data ) || ! is_array( $loginpress_notice_data ) ) {
	return;
}

$data = $loginpress_notice_data;

$allowed_html = array(
	'strong' => array(),
	'a'      => array(
		'href'   => true,
		'rel'    => true,
		'target' => true,
	),
);

?>
<tr class="plugin-update-tr<?php echo esc_attr( $data['active_class'] ); ?>" id="loginpress-pro-update">
	<td class="plugin-update colspanchange" colspan="<?php echo (int) $data['colspan']; ?>">
		<div class="loginpress-pro-update update-message inline notice notice-warning notice-alt">
			<p>
			<?php
			echo wp_kses(
				sprintf(
					/* translators: %1$s: opening strong, %2$s: version, %3$s: closing strong, %4$s: opening learn-more link, %5$s: closing link, %6$s: opening renew link. */
					__( ' %1$sLoginPress Pro %2$s%3$s is available. %4$sLearn more%5$s about the updates and enhancements of this major version. You need an active license to use them on your website, don’t miss out! %6$sRenew Now%5$s', 'loginpress-pro' ),
					'<strong>',
					esc_html( $data['version'] ),
					'</strong>',
					'<a href="' . esc_url( $data['release_url'] ) . '" rel="noopener" target="_blank">',
					'</a>',
					'<a href="' . esc_url( $data['renew_url'] ) . '" rel="noopener" target="_blank">'
				),
				$allowed_html
			);
			?>
			</p>
		</div>
	</td>
</tr>
