<?php

namespace FluentCartPro\App\Modules\SavedPaymentMethods\PayPal;

use FluentCart\App\Services\Permission\PermissionManager;

/**
 * Wires PayPal vaulting availability into the checkout surfaces and the admin.
 *
 * Without this the failure is completely silent: customers keep being offered a
 * save that cannot work, and the merchant has no way to find out short of
 * reading logs.
 */
class PayPalVaultNotice
{
    public function register(): void
    {
        add_action('fluent_cart/payments/paypal_vault_rejected', [$this, 'onVaultRejected']);
        add_filter('fluent_cart/admin_notices', [$this, 'addAdminNotice']);
    }

    /**
     * Core retried the order without vault attributes, so the purchase itself is
     * fine — record why saving is off and log it for the merchant.
     *
     * @param array $data ['order'=>Order, 'transaction'=>OrderTransaction, 'error'=>\WP_Error]
     */
    public function onVaultRejected($data): void
    {
        $error = isset($data['error']) ? $data['error'] : null;
        $reason = is_wp_error($error) ? $error->get_error_message() : '';

        (new PayPalVaultCapability())->markUnavailable($reason);

        fluent_cart_error_log(
            'PayPal vaulting unavailable',
            sprintf(
                'PayPal rejected an order carrying vault attributes; the order was retried without them and completed. Saved payment methods will not be offered for PayPal until this is resolved. PayPal said: %1$s',
                $reason !== '' ? $reason : 'no reason given'
            )
        );
    }

    public function addAdminNotice($notices)
    {
        if (!is_array($notices)) {
            return $notices;
        }

        $capability = new PayPalVaultCapability();
        if ($capability->isAvailable()) {
            return $notices;
        }

        if (!PermissionManager::userCan('is_super_admin')) {
            return $notices;
        }

        $reason = $capability->reason();

        $message = __('PayPal declined to save customer payment methods, so saved PayPal accounts are switched off. Your PayPal account most likely is not approved for vaulting — contact PayPal to enable it. Card saving is unaffected.', 'fluent-cart-pro');

        if ($reason !== '') {
            /* translators: %1$s: the reason PayPal returned */
            $message .= ' ' . sprintf(__('PayPal said: %1$s', 'fluent-cart-pro'), $reason);
        }

        $notices[] = [
            'id'   => 'fluent_cart_paypal_vault_unavailable',
            'type' => 'warning',
            'html' => '<div>' . esc_html($message) . '</div>',
        ];

        return $notices;
    }
}
