<?php

defined('ABSPATH') || exit;

/**
 * A named lock shared by every request on the site, held in an options row.
 *
 * Only one caller can hold a given lock at a time. The row stores the lock's
 * expiry and a random token as "{expires_at}:{uuid}", so a lock left behind
 * by a request that died is taken over once it expires, and only the holder
 * of the token can release it. Locks this request still holds when it ends,
 * including after a fatal error, are released by a shutdown function.
 */
class MeprLock
{
    /**
     * The microseconds between attempts while a caller waits for a lock.
     */
    private const WAIT_INTERVAL = 250000;

    /**
     * The tokens of the locks this request holds, keyed by lock name.
     *
     * @var array<string,string>
     */
    private static array $held = [];

    /**
     * Whether the shutdown release is registered for this request.
     *
     * @var boolean
     */
    private static bool $shutdown_registered = false;

    /**
     * Acquire the named lock, waiting up to $wait seconds for another holder
     * to release it or for its lock to expire.
     *
     * A database error fails closed: the lock is reported as held, waiting
     * stops, and the error is logged.
     *
     * @param  string  $name The lock name.
     * @param  integer $ttl  The number of seconds until the lock expires.
     * @param  integer $wait The number of seconds to wait for the lock.
     * @return string|null The ownership token, or null when another caller holds the lock.
     */
    public static function acquire(string $name, int $ttl, int $wait = 0): ?string
    {
        global $wpdb;

        $deadline = microtime(true) + $wait;
        $token    = self::attempt($name, $ttl);

        while ($token === null && empty($wpdb->last_error) && microtime(true) < $deadline) {
            usleep(self::WAIT_INTERVAL);
            $token = self::attempt($name, $ttl);
        }

        if ($token !== null) {
            self::hold($name, $token);
        }

        return $token;
    }

    /**
     * Release the named lock, if the given token still owns it. A database
     * error is logged, and the lock then expires on its own.
     *
     * @param  string $name  The lock name.
     * @param  string $token The token returned by acquire().
     * @return void
     */
    public static function release(string $name, string $token): void
    {
        global $wpdb;

        $option = self::option_name($name);

        $wpdb->query(
            $wpdb->prepare(
                "DELETE FROM $wpdb->options WHERE option_name = %s AND option_value = %s",
                $option,
                $token
            )
        );

        wp_cache_delete($option, 'options');

        if (!empty($wpdb->last_error)) {
            MeprUtils::debug_log("Could not release the $name lock: $wpdb->last_error");
        }

        if ((self::$held[$name] ?? null) === $token) {
            unset(self::$held[$name]);
        }
    }

    /**
     * Whether this request holds the named lock.
     *
     * @param  string $name The lock name.
     * @return boolean
     */
    public static function holds(string $name): bool
    {
        return isset(self::$held[$name]);
    }

    /**
     * Release every lock this request still holds. Runs at shutdown.
     *
     * @return void
     */
    public static function release_held(): void
    {
        foreach (self::$held as $name => $token) {
            self::release($name, $token);
        }
    }

    /**
     * Try once to take the named lock.
     *
     * The INSERT takes the lock when no row exists, or when the stored expiry
     * has passed; the UNIQUE key on option_name makes the database serialize
     * concurrent callers on that statement. Reading the row back confirms
     * which caller's token won.
     *
     * @param  string  $name The lock name.
     * @param  integer $ttl  The number of seconds until the lock expires.
     * @return string|null The ownership token, or null when the lock is held or the database failed.
     */
    private static function attempt(string $name, int $ttl): ?string
    {
        global $wpdb;

        $option = self::option_name($name);
        $now    = time();
        $token  = ($now + $ttl) . ':' . wp_generate_uuid4();

        $wpdb->query(self::take_query($option, $token, $now)); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- prepared by take_query().

        wp_cache_delete($option, 'options');

        if (!empty($wpdb->last_error)) {
            MeprUtils::debug_log("Could not acquire the $name lock: $wpdb->last_error");

            return null;
        }

        return $wpdb->get_var(
            $wpdb->prepare(
                "SELECT option_value FROM $wpdb->options WHERE option_name = %s",
                $option
            )
        ) === $token ? $token : null;
    }

    /**
     * Build the statement that stores $token in the $option row, unless that
     * row holds a lock that has not expired by $now.
     *
     * The expiry prefix is read with LEFT() and LOCATE(), and compared with
     * CASE, so the statement runs on MySQL and on SQLite. A value with no
     * numeric expiry prefix casts to 0, so it counts as expired.
     *
     * @param  string  $option The options row that holds the lock.
     * @param  string  $token  The "{expires_at}:{uuid}" ownership token.
     * @param  integer $now    The current Unix timestamp.
     * @return string The prepared SQL statement.
     */
    public static function take_query(string $option, string $token, int $now): string
    {
        global $wpdb;

        return $wpdb->prepare(
            "INSERT INTO $wpdb->options (option_name, option_value, autoload)
             VALUES (%s, %s, 'no')
             ON DUPLICATE KEY UPDATE
                 option_value = CASE
                     WHEN CAST(LEFT(option_value, LOCATE(':', option_value) - 1) AS UNSIGNED) < %d THEN %s
                     ELSE option_value
                 END",
            $option,
            $token,
            $now,
            $token
        );
    }

    /**
     * Record a lock this request now holds, and register the shutdown
     * release the first time.
     *
     * @param  string $name  The lock name.
     * @param  string $token The ownership token.
     * @return void
     */
    private static function hold(string $name, string $token): void
    {
        self::$held[$name] = $token;

        if (!self::$shutdown_registered) {
            register_shutdown_function([self::class, 'release_held']);
            self::$shutdown_registered = true;
        }
    }

    /**
     * The options row that holds the named lock.
     *
     * @param  string $name The lock name.
     * @return string
     */
    private static function option_name(string $name): string
    {
        return "mepr_lock_$name";
    }
}
