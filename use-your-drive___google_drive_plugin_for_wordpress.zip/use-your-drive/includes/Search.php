<?php

/**
 * @author WP Cloud Plugins
 * @copyright Copyright (c) 2023, WP Cloud Plugins
 *
 * @since       2.0
 * @see https://www.wpcloudplugins.com
 */

namespace TheLion\UseyourDrive;

defined('ABSPATH') || exit;

class Search
{
    /**
     * @var CacheNode
     */
    private $_top_folder_node;

    /**
     * @var string
     */
    private $_query;

    /**
     * Set to true when not all subfolders could be discovered, e.g. because the
     * API returned an error or because folders disappeared from the cache.
     *
     * @var bool
     */
    private $_folders_incomplete = false;

    /**
     * Set to true when the search request itself failed.
     *
     * @var bool
     */
    private $_query_failed = false;

    /**
     * Cached outcome of searches_entire_drive() for the current top folder.
     *
     * @var null|bool
     */
    private $_searches_entire_drive;

    public function do_search($query, CacheNode $folder_node)
    {
        $this->_top_folder_node = $folder_node;
        $this->_query = $query;
        $this->_searches_entire_drive = null;

        $cache_name = Helpers::filter_filename(App::get_current_account()->get_id().'_'.Processor::instance()->get_listtoken().$folder_node->get_id().'_search_'.md5($query), false);
        $cached_request = new CacheRequest([], $cache_name);
        $api_results = null;

        if (false !== $cached_request->is_cached()) {
            $raw = $cached_request->get_cached_response();
            $decoded = null;

            if (is_string($raw) && '' !== $raw) {
                try {
                    $decoded = json_decode($raw, true, 512, JSON_THROW_ON_ERROR);
                } catch (\JsonException $ex) {
                    $decoded = null;
                }
            }

            if (is_array($decoded)) {
                $api_results = [];
                foreach ($decoded as $entry_data) {
                    if (!is_array($entry_data)) {
                        $api_results = null;

                        break;
                    }

                    $api_results[] = Entry::from_cache_array($entry_data);
                }
            }
        }

        if (null === $api_results) {
            /*
             * Searches that cover a complete Drive don't need a list of parent
             * folders, so the subfolders don't have to be discovered either.
             */
            if (false === $this->searches_entire_drive()) {
                // Make sure that all subfolders are loaded
                if (isset($_REQUEST['data']['discover_folder_ids']) && is_string($_REQUEST['data']['discover_folder_ids'])) {
                    $folders = [];

                    // A previous round already reported that folders are missing
                    if ('1' === ($_REQUEST['data']['folders_incomplete'] ?? '')) {
                        $this->_folders_incomplete = true;
                    }

                    foreach (explode('|', $_REQUEST['data']['discover_folder_ids']) as $folder_id) {
                        $folder_id = preg_replace('/[^A-Za-z0-9_\-]/', '', $folder_id);

                        if ('' === $folder_id) {
                            continue;
                        }

                        $folder_node_found = Cache::instance()->get_node_by_id($folder_id);

                        // Unknown IDs resolve to false and may not reach the typed
                        // authorization check further down
                        if (!$folder_node_found instanceof CacheNode) {
                            // The folder is no longer present in the cache, so its
                            // subfolders can't be discovered in this request
                            $this->_folders_incomplete = true;

                            continue;
                        }

                        $folders[$folder_id] = $folder_node_found;
                    }

                    $this->load_folders($folders);
                } else {
                    $this->load_folders($folder_node->get_all_sub_folders());
                }

                /*
                 * Mark folder as completely loaded. Only do so when all subfolders
                 * were actually found, as the folder tree would otherwise never be
                 * completed again until the cache is cleared.
                 */
                if (false === $this->_folders_incomplete) {
                    $folder_node->set_loaded_all_childfolders(true);
                }
            }

            // Search
            $raw_files = $this->query();
            $api_results = array_map(static fn ($file) => ($file instanceof EntryAbstract) ? $file : new Entry($file), $raw_files);

            // Don't cache the result when the API failed to answer the request.
            // An empty result would otherwise be served for all following searches.
            $store_search_result = (false === $this->_query_failed);
        } else {
            $store_search_result = false;
        }

        // Process the results and store them in cache
        $entries_found = $this->process($api_results);

        /*
         * Cache the search request. This is done after processing the results,
         * as loading new folders while processing clears the cached requests
         * of this module.
         */
        if ($store_search_result) {
            try {
                $json = json_encode(
                    array_map(static fn (EntryAbstract $entry) => $entry->to_cache_array(), $api_results),
                    JSON_THROW_ON_ERROR | JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE
                );
                $cached_request->add_cached_response($json);
            } catch (\JsonException $ex) {
                // Search results remain usable in-memory even when the cache write is skipped.
            }
        }

        // Filter them for this specific request
        $entries_filtered = $this->filter($entries_found);

        // Save the cache
        Cache::instance()->set_updated();
        Cache::instance()->update_cache(false);

        return $entries_filtered;
    }

    /**
     * Check if the search covers a complete Drive.
     *
     * Searches that start at the root of a Shared Drive always return items
     * that are inside the searched folder, so the search doesn't have to be
     * limited to a list of parent folders.
     *
     * @return bool
     */
    public function searches_entire_drive()
    {
        if (null !== $this->_searches_entire_drive) {
            return $this->_searches_entire_drive;
        }

        $top_folder_node = $this->get_top_folder_node();

        if (!$top_folder_node instanceof CacheNode) {
            return false;
        }

        $drive_id = $top_folder_node->get_drive_id();

        /*
         * Searches in My Drive are made with the 'user' corpus, which also
         * contains items that are shared with the account. Those items are not
         * necessarily located in the searched folder.
         */
        if (in_array($drive_id, ['drive', 'mydrive', null], true)) {
            return false;
        }

        // The ID of the root folder of a Shared Drive is the ID of the Drive itself
        $searches_entire_drive = ($top_folder_node->get_id() === $drive_id);

        /*
         * Modules that only show specific folders rely on the list of parent
         * folders to keep other folders out of the search results. Modules that
         * hide folders only search the files in the top folder itself.
         */
        if ($searches_entire_drive) {
            $items = Processor::instance()->get_shortcode_option('items');
            $hide_entries = Processor::instance()->get_shortcode_option('exclude');
            $include_entries = Processor::instance()->get_shortcode_option('include');

            if (!empty($items)
                || '0' === Processor::instance()->get_shortcode_option('show_folders')
                || (!empty($hide_entries) && '*' !== $hide_entries[0])
                || (!empty($include_entries) && '*' !== $include_entries[0])
                || has_filter('useyourdrive_is_entry_authorized')) {
                $searches_entire_drive = false;
            }
        }

        return $this->_searches_entire_drive = (bool) apply_filters('useyourdrive_search_entire_drive', $searches_entire_drive, $top_folder_node);
    }

    public function load_folders($folders = [])
    {
        Helpers::set_time_limit(60);

        // Don't load folders that were loaded previously
        foreach ($folders as $id => $folder) {
            // Remove unauthorized folders from list
            if (false === Processor::instance()->_is_entry_authorized($folder)) {
                unset($folders[$id]);

                continue;
            }

            if ($folder->has_loaded_all_childfolders()) {
                unset($folders[$id]);

                continue;
            }

            if ($folder->has_loaded_children()) {
                unset($folders[$id]);
                $folders = array_merge($folders, $folder->get_all_sub_folders());
            }
        }

        // Remove virtual folders
        unset($folders['shared-drives'], $folders['shared-with-me'], $folders['computers']);

        // Can only make list calls with 99 parents, so split them if required
        $folders_id = array_keys($folders);
        $requests = array_chunk($folders_id, 99, true);

        $folders_found = [];
        foreach ($requests as $request_folder_ids) {
            $new_folders_found = $this->get_multiple_folders($request_folder_ids);
            $folders_found = array_merge($folders_found, $new_folders_found);
        }

        $new_found_sub_folders = [];
        foreach ($folders_found as $folder_entry) {
            $cached_node = Cache::instance()->is_cached($folder_entry->get_id(), 'id', 'as_parent');

            if (false === $cached_node) {
                $cached_node = Cache::instance()->add_to_cache($folder_entry);
                $cached_node->set_entry($folder_entry);
                $cached_node->set_loaded(false);
                $cached_node->set_updated();
            }
            $new_found_sub_folders[$cached_node->get_id()] = $cached_node;
        }

        // Save the cache
        Cache::instance()->set_updated();
        Cache::instance()->update_cache(false);

        if (!empty($new_found_sub_folders)) {
            echo json_encode([
                'result' => 'discovering_folders',
                'async' => true,
                'data' => [
                    'discover_folder_ids' => implode('|', array_keys($new_found_sub_folders)),
                    // Pass on that folders went missing, so that the next round
                    // doesn't mark the folder tree as complete
                    'folders_incomplete' => $this->_folders_incomplete ? '1' : '0',
                ],
            ]);

            exit;
        }

        return true;
    }

    public function get_multiple_folders($parents_ids)
    {
        // Set the parents
        if (1 === count($parents_ids)) {
            $parents_query = " and ('".reset($parents_ids)."' in parents) ";
        } else {
            $parents_query = " and ('".implode("' in parents or '", $parents_ids)."' in parents) ";
        }

        $drive_id = $this->get_top_folder_node()->get_drive_id();

        // Find all items containing query
        $params = [
            'q' => "mimeType = 'application/vnd.google-apps.folder' {$parents_query} and trashed = false",
            'fields' => Client::instance()->apilistfilesfields,
            'pageSize' => 999,
            'supportsAllDrives' => true,
            'includeItemsFromAllDrives' => (!in_array($drive_id, ['drive', 'mydrive', null])),
            'corpora' => (in_array($drive_id, ['drive', 'mydrive', null])) ? 'user' : 'drive',
        ];

        if (App::get_current_account()->has_app_folder_access()) {
            $params['spaces'] = 'appDataFolder';
        }

        if (!in_array($drive_id, ['drive', 'mydrive', null])) {
            $params['driveId'] = $drive_id;
        }

        // Do the request
        $nextpagetoken = null;
        $folders_found = [];
        $entries_found = [];

        do {
            try {
                $search_response = App::instance()->get_drive()->files->listFiles($params);
            } catch (\Exception $ex) {
                Helpers::log_error('Search received API error.', 'Search', null, __LINE__);

                // Not all subfolders are known, so the folder tree isn't complete
                $this->_folders_incomplete = true;

                return [];
            }

            // Process the response
            $more_files = $search_response->getFiles();
            $folders_found = array_merge($folders_found, $more_files);

            $nextpagetoken = $search_response->getNextPageToken();
            $params['pageToken'] = $nextpagetoken;
        } while (null !== $nextpagetoken);

        foreach ($folders_found as $folder) {
            $folder_entry = new Entry($folder);
            $entries_found[] = $folder_entry;
        }

        return $entries_found;
    }

    public function query()
    {
        $api_results = [];

        if ($this->searches_entire_drive()) {
            /*
             * The complete Drive is searched, so the query doesn't need a list of
             * parent folders. A single request without that list is used instead.
             */
            $requests = [[]];
        } else {
            $all_subfolders = $this->get_top_folder_node()->get_all_child_folders();

            // Remove unauthorized folders from list
            foreach ($all_subfolders as $folder_id => $folder_node) {
                if (false === Processor::instance()->_is_entry_authorized($folder_node)) {
                    unset($all_subfolders[$folder_id]);
                }
            }

            $folders_to_look_in = array_merge([$this->get_top_folder_node()->get_id() => $this->get_top_folder_node()], $all_subfolders);

            // Remove virtual folders
            unset($folders_to_look_in['drive'], $folders_to_look_in['shared-drives'], $folders_to_look_in['shared-with-me'], $folders_to_look_in['computers']);

            // Get all folder IDs
            $folders_id = array_keys($folders_to_look_in);

            /*
             * Max 99 parents per request. Note that the Drive API can return an
             * empty result for requests with a long list of parents (~50), without
             * reporting that the search was incomplete. Lower this number via the
             * filter when a search doesn't return all expected files.
             */
            $max_parents_per_request = (int) apply_filters('useyourdrive_search_max_parents_per_request', 99, $this->get_top_folder_node());

            if ($max_parents_per_request < 1) {
                $max_parents_per_request = 1;
            }

            $requests = array_chunk($folders_id, $max_parents_per_request, true);
        }

        // Set search field
        if ('1' === Processor::instance()->get_shortcode_option('searchcontents')) {
            $field = 'fullText';
        } else {
            $field = 'name';
        }

        // Set the right corpora
        $drive_id = $this->get_top_folder_node()->get_drive_id();

        // Find all items containing query
        $params = [
            'fields' => Client::instance()->apilistfilesfields,
            'pageSize' => 500,
            'supportsAllDrives' => true,
            'includeItemsFromAllDrives' => (!in_array($drive_id, ['mydrive', null])),
            'corpora' => (in_array($drive_id, ['mydrive', null])) ? 'user' : 'drive',
        ];

        if (App::get_current_account()->has_app_folder_access()) {
            $params['spaces'] = 'appDataFolder';
        }

        if (!in_array($drive_id, ['mydrive', null])) {
            $params['driveId'] = $drive_id;
        }

        do_action('useyourdrive_log_event', 'useyourdrive_searched', $this->get_top_folder_node(), ['query' => $this->get_query()]);

        foreach ($requests as $request_folder_ids) {
            if (empty($request_folder_ids)) {
                $parents_query = '';
            } elseif (1 === count($request_folder_ids)) {
                $parents_query = " and ('".reset($request_folder_ids)."' in parents) ";
            } else {
                $parents_query = " and ('".implode("' in parents or '", $request_folder_ids)."' in parents) ";
            }

            if ('fullText' == $field) {
                // Fix: fullText search does not always return files with matching name, so we add an OR condition here
                $params['q'] = "(fullText contains '".stripslashes($this->get_query())."' or name contains '".stripslashes($this->get_query())."') {$parents_query} and trashed = false";
            } else {
                $params['q'] = "{$field} contains '".stripslashes($this->get_query())."' {$parents_query} and trashed = false";
            }

            $params = apply_filters('useyourdrive_api_search_set_query', $params);

            // Do the request
            $nextpagetoken = null;
            unset($params['pageToken']);

            do {
                try {
                    $search_response = App::instance()->get_drive()->files->listFiles($params);
                } catch (\Exception $ex) {
                    Helpers::log_error('Search received API error.', 'Search', null, __LINE__);

                    /*
                     * Keep the results of the other requests, but remember that the
                     * result is incomplete so that it isn't stored in the cache.
                     */
                    $this->_query_failed = true;

                    continue 2;
                }

                // Process the response
                $more_files = $search_response->getFiles();
                $api_results = array_merge($api_results, $more_files);

                $nextpagetoken = $search_response->getNextPageToken();
                $params['pageToken'] = $nextpagetoken;
            } while (null !== $nextpagetoken);
        }

        return $api_results;
    }

    public function process($api_results = [])
    {
        $entries_found = [];
        $new_parent_folders = [];
        $entries_in_searchedfolder = [];

        // Convert API results into Entries
        foreach ($api_results as $file) {
            $file_entry = ($file instanceof EntryAbstract) ? $file : new Entry($file);
            $entries_found[] = $file_entry;
            if ($file_entry->has_parent()) {
                $parent_id = $file_entry->get_parent_id();
                if ($this->_is_missing_parent_folder($parent_id)) {
                    $new_parent_folders[$parent_id] = $parent_id;
                }
            }
        }

        /*
         * Load all new parents, and their parents in turn, before storing them in
         * the cache from the top down. The cache would otherwise request a complete
         * folder listing for every parent whose own parent isn't cached yet, which
         * is slow for results deep inside a Drive that isn't cached yet.
         */
        $parent_levels = [];
        $requested_parent_ids = [];

        while (!empty($new_parent_folders) && count($parent_levels) < 25) {
            $requested_parent_ids += $new_parent_folders;
            $parents_found = [];
            $next_parent_folders = [];

            // The API allows a maximum of 100 calls per batch request
            foreach (array_chunk($new_parent_folders, 100) as $new_parent_folders_chunk) {
                try {
                    $new_parents_folders_api = Client::instance()->get_multiple_entries($new_parent_folders_chunk);
                } catch (\Exception $ex) {
                    Helpers::log_error('Failed to load the parent folders of the search results.', 'Search', null, __LINE__, $ex);

                    continue;
                }

                foreach ($new_parents_folders_api as $parent) {
                    if (!$parent instanceof EntryAbstract) {
                        if (!$parent instanceof \UYDGoogle_Service_Drive_DriveFile) {
                            // Entries that couldn't be loaded are returned as an exception
                            continue;
                        }

                        $parent = new Entry($parent);
                    }

                    $parents_found[] = $parent;

                    if ($parent->has_parent()) {
                        $grandparent_id = $parent->get_parent_id();
                        if (!isset($requested_parent_ids[$grandparent_id]) && $this->_is_missing_parent_folder($grandparent_id)) {
                            $next_parent_folders[$grandparent_id] = $grandparent_id;
                        }
                    }
                }
            }

            $parent_levels[] = $parents_found;
            $new_parent_folders = $next_parent_folders;
        }

        foreach (array_reverse($parent_levels) as $parents_found) {
            foreach ($parents_found as $parent) {
                Cache::instance()->add_to_cache($parent);
            }
        }

        // Add / Update files in cache
        foreach ($entries_found as $entry) {
            $cachedentry = Cache::instance()->add_to_cache($entry);

            $entries_in_searchedfolder[] = $cachedentry;
        }

        return $entries_in_searchedfolder;
    }

    public function filter($entries_filtered)
    {
        foreach ($entries_filtered as $key => $cached_node) {
            if (false === Processor::instance()->_is_entry_authorized($cached_node)) {
                unset($entries_filtered[$key]);
            }
        }

        return $entries_filtered;
    }

    /**
     * Get the value of _top_folder_node.
     *
     * @return CacheNode
     */
    public function get_top_folder_node()
    {
        return $this->_top_folder_node;
    }

    /**
     * Set the value of _top_folder_node.
     *
     * @return self
     */
    public function set_top_folder_node(CacheNode $_top_folder_node)
    {
        $this->_top_folder_node = $_top_folder_node;
        $this->_searches_entire_drive = null;

        return $this;
    }

    /**
     * Get the value of _query.
     *
     * @return string
     */
    public function get_query()
    {
        return $this->_query;
    }

    /**
     * Set the value of _query.
     *
     * @return self
     */
    public function set_query(string $_query)
    {
        $this->_query = $_query;

        return $this;
    }

    /**
     * Check if a parent folder of a search result still has to be loaded.
     *
     * @param string $folder_id
     *
     * @return bool
     */
    private function _is_missing_parent_folder($folder_id)
    {
        // Virtual folders can't be requested from the API
        if (in_array($folder_id, ['drive', 'shared-drives', 'shared-with-me', 'computers'], true)) {
            return false;
        }

        // Folders without data are loaded as well, as the cache would otherwise
        // request a complete folder listing for them
        return false === Cache::instance()->is_cached($folder_id, 'id', 'as_parent');
    }
}