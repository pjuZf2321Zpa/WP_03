<?php

namespace WPAICG\Lib\AI;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Paid model-sync processing, loaded by the Pro composition root.
 */
class AIPKit_Model_Actions
{
    /**
     * Prepare Ollama model catalogs and the sync response using capability data.
     *
     * @param mixed $result Synced provider models.
     * @param array $api_params Provider connection parameters.
     * @param array $catalog_updates Catalogs to publish after successful sync.
     * @param array $extra_response_payload Additional model-sync response fields.
     * @return array Chat models for the primary catalog and response.
     */
    public static function prepare_ollama_sync($result, array $api_params, array &$catalog_updates, array &$extra_response_payload): array
    {
        $chat_models = is_array($result) ? $result : [];
        $embedding_models = [];
        $vision_models = [];
        $all_models = is_array($result) ? $result : [];
        $option_updates = [];

        /**
         * Allow Pro/Ollama layer to classify synced Ollama models using
         * provider-specific capabilities (e.g. /api/show metadata).
         *
         * Expected return shape:
         * [
         *   'chat_models' => array,
         *   'embedding_models' => array,
         *   'vision_models' => array,
         *   'model_details_failures' => array,
         *   'cache_stats' => array,
         * ]
         */
        $classification_result = apply_filters(
            'aipkit_ollama_sync_models_classification',
            null,
            $result,
            $api_params
        );

        if (is_array($classification_result)) {
            if (isset($classification_result['all_models']) && is_array($classification_result['all_models'])) {
                $all_models = $classification_result['all_models'];
            }
            if (isset($classification_result['chat_models']) && is_array($classification_result['chat_models'])) {
                $chat_models = $classification_result['chat_models'];
            }
            if (isset($classification_result['embedding_models']) && is_array($classification_result['embedding_models'])) {
                $embedding_models = $classification_result['embedding_models'];
            }
            if (isset($classification_result['vision_models']) && is_array($classification_result['vision_models'])) {
                $vision_models = $classification_result['vision_models'];
            }
            if (!empty($classification_result['model_details_failures']) && is_array($classification_result['model_details_failures'])) {
                $extra_response_payload['model_details_failures'] = $classification_result['model_details_failures'];
            }
            if (!empty($classification_result['cache_stats']) && is_array($classification_result['cache_stats'])) {
                $extra_response_payload['capability_cache'] = $classification_result['cache_stats'];
            }
            if (isset($classification_result['option_updates']) && is_array($classification_result['option_updates'])) {
                $option_updates = $classification_result['option_updates'];
            }
        } else {
            // Backward-compatible fallback when capability classifier is unavailable.
            $chat_models = [];
            $embedding_models = [];
            $vision_models = [];
            foreach ($all_models as $model) {
                if (!is_array($model)) {
                    continue;
                }
                $id_lower = strtolower((string) ($model['id'] ?? ''));
                $name_lower = strtolower((string) ($model['name'] ?? ''));
                $haystack = trim($id_lower . ' ' . $name_lower);
                $is_embedding = strpos($haystack, 'embed') !== false || strpos($haystack, 'embedding') !== false;
                $is_vision = strpos($haystack, 'vision') !== false
                    || strpos($haystack, '-vl') !== false
                    || strpos($haystack, '_vl') !== false
                    || strpos($haystack, 'llava') !== false
                    || strpos($haystack, 'moondream') !== false
                    || strpos($haystack, 'gemma3') !== false;

                if ($is_embedding) {
                    $embedding_models[] = $model;
                    continue;
                }
                if ($is_vision) {
                    $vision_models[] = $model;
                }
                $chat_models[] = $model;
            }
        }

        if (empty($option_updates)) {
            $option_updates = [
                'aipkit_ollama_embedding_model_list' => $embedding_models,
                'aipkit_ollama_vision_model_list' => $vision_models,
                'aipkit_ollama_model_capability_list' => $all_models,
            ];
        }

        $ollama_catalog_map = [
            'aipkit_ollama_embedding_model_list' => 'OllamaEmbedding',
            'aipkit_ollama_vision_model_list' => 'OllamaVision',
            'aipkit_ollama_model_capability_list' => 'OllamaCapabilities',
        ];
        foreach ($option_updates as $option_key => $option_value) {
            $option_key = sanitize_key((string) $option_key);
            if (!is_array($option_value) || !isset($ollama_catalog_map[$option_key])) {
                continue;
            }
            $catalog_updates[$ollama_catalog_map[$option_key]] = $option_value;
        }

        $extra_response_payload['embedding_models'] = $embedding_models;
        if (!empty($vision_models)) {
            $extra_response_payload['vision_models'] = $vision_models;
        }
        return $chat_models;
    }
}
