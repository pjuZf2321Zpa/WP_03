<?php

namespace FluentCartPro\App\Hooks\Handlers\BlockEditors\EmailBlocks\OrderAddresses;

use FluentCart\App\Hooks\Handlers\BlockEditors\BlockEditor;

class OrderAddressesBlockEditor extends BlockEditor
{
    use \FluentCartPro\App\Contracts\CanEnqueue;
    protected static string $editorName = 'email-order-addresses';

    public function getScripts(): array
    {
        return [
            [
                'source'       => 'admin/BlockEditor/EmailBlocks/OrderAddresses/OrderAddressesBlockEditor.jsx',
                'dependencies' => ['wp-blocks', 'wp-components', 'wp-block-editor']
            ]
        ];
    }

    public function getStyles(): array
    {
        return [
            'admin/BlockEditor/EmailBlocks/OrderAddresses/style/order-addresses-block-editor.scss'
        ];
    }

    public function localizeData(): array
    {
        return [
            $this->getLocalizationKey() => [
                'slug'        => $this->slugPrefix,
                'name'        => static::getEditorName(),
                'title'       => __('Order Addresses', 'fluent-cart-pro'),
                'description' => __('Billing and shipping addresses with layout control.', 'fluent-cart-pro'),
            ],
            'fluent_cart_pro_block_translation' => \FluentCartPro\App\Services\Translations\Translations::blockStrings(),
        ];
    }

    public function blockAttributes(): array
    {
        return [
            'hideShippingOnDigital' => [
                'type'    => 'boolean',
                'default' => false,
            ],
        ];
    }

    public function supports(): array
    {
        return [
            'html'       => false,
            'align'      => false,
            'color'      => [
                'text'       => true,
                'background' => true,
                'link'       => true,
            ],
            'typography' => [
                'fontSize'   => true,
                'lineHeight' => true,
            ],
            'spacing'    => [
                'margin'  => true,
                'padding' => true,
            ],
            '__experimentalBorder' => [
                'color'  => true,
                'radius' => true,
                'style'  => true,
                'width'  => true,
            ],
        ];
    }

    public function render(array $attrs, $block = null, $content = ''): string
    {
        return $content;
    }
}
