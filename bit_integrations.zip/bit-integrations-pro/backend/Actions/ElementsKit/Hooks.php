<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Actions\ElementsKit\ElementsKitProHelper;
use BitApps\IntegrationsPro\Config;
use BitApps\IntegrationsPro\Core\Util\Hooks;

Hooks::filter(Config::withFreePrefix('elements_kit_create_template'), [ElementsKitProHelper::class, 'createTemplate'], 10, 4);
Hooks::filter(Config::withFreePrefix('elements_kit_create_content'), [ElementsKitProHelper::class, 'createContent'], 10, 4);
Hooks::filter(Config::withFreePrefix('elements_kit_update_content'), [ElementsKitProHelper::class, 'updateContent'], 10, 4);
Hooks::filter(Config::withFreePrefix('elements_kit_update_template'), [ElementsKitProHelper::class, 'updateTemplate'], 10, 3);
Hooks::filter(Config::withFreePrefix('elements_kit_delete_template'), [ElementsKitProHelper::class, 'deleteTemplate'], 10, 3);
Hooks::filter(Config::withFreePrefix('elements_kit_delete_widget'), [ElementsKitProHelper::class, 'deleteWidget'], 10, 3);
Hooks::filter(Config::withFreePrefix('elements_kit_delete_content'), [ElementsKitProHelper::class, 'deleteContent'], 10, 3);
Hooks::filter(Config::withFreePrefix('elements_kit_update_template_activation'), [ElementsKitProHelper::class, 'updateTemplateActivation'], 10, 3);
