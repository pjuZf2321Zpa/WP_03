<?php

namespace MasterStudy\Lms\Pro\addons\certificate_builder\Routing\Swagger;

use MasterStudy\Lms\Routing\Swagger\RequestInterface;
use MasterStudy\Lms\Routing\Swagger\ResponseInterface;
use MasterStudy\Lms\Routing\Swagger\Route;

class GetAdminCertificates extends Route implements RequestInterface, ResponseInterface {
	public function request(): array {
		return array(
			'page'       => array(
				'type'        => 'integer',
				'description' => 'Pagination number in the query. Default is 1.',
			),
			'per_page'   => array(
				'type'        => 'integer',
				'description' => 'Number of items to be shown per page in the query. Default is 10.',
			),
			'instructor' => array(
				'type'        => 'integer',
				'description' => 'Filter certificates by instructor ID. Default is empty.',
			),
			'search'     => array(
				'type'        => 'string',
				'description' => 'Filter certificates by title. Default is empty.',
			),
			'sort'       => array(
				'type'        => 'string',
				'description' => 'Sort string in key:direction format. Supported keys are title and instructor.',
			),
		);
	}

	public function response(): array {
		return array(
			'pages'              => array(
				'type' => 'integer',
			),
			'current_page'       => array(
				'type' => 'integer',
			),
			'total_certificates' => array(
				'type' => 'integer',
			),
			'certificates'       => array(
				'type' => 'array',
			),
		);
	}

	public function get_summary(): string {
		return 'Get Admin Certificates';
	}

	public function get_description(): string {
		return 'Returns a paginated list of certificates for the React admin certificates page.';
	}
}
