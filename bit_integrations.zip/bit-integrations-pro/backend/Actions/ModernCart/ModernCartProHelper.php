<?php

namespace BitApps\IntegrationsPro\Actions\ModernCart;

if (!\defined('ABSPATH')) {
    exit;
}

final class ModernCartProHelper
{
    public static function addProductToCart($defaultResponse, $fieldData, $integrationDetails = null)
    {
        if (!ModernCartHelper::isPluginInstalled()) {
            return self::errorResponse(__('Modern Cart is not installed or activated', 'bit-integrations-pro'));
        }

        if (!ModernCartHelper::isWooCommerceAvailable()) {
            return self::errorResponse(__('WooCommerce cart is not available', 'bit-integrations-pro'));
        }

        $productId = self::toInt(self::getIntegrationValue($integrationDetails, 'productId'));

        if (empty($productId)) {
            return self::errorResponse(__('Product is required', 'bit-integrations-pro'));
        }

        $product = \function_exists('wc_get_product') ? wc_get_product($productId) : null;

        if (!$product instanceof \WC_Product) {
            return self::errorResponse(__('Product not found', 'bit-integrations-pro'));
        }

        $productType = $product->get_type();

        if (!\in_array($productType, ['simple', 'variable'], true)) {
            return self::errorResponse(__('Product type is not supported', 'bit-integrations-pro'));
        }

        $quantity = isset($fieldData['quantity']) && $fieldData['quantity'] !== ''
            ? self::toPositiveInt($fieldData['quantity'])
            : 1;
        $variationId = self::toInt(self::getIntegrationValue($integrationDetails, 'variationId'));
        $variations = ModernCartHelper::decodeJson($fieldData['variations_json'] ?? '');
        $cart = WC()->cart;

        if ($productType === 'variable') {
            if (empty($variationId)) {
                return self::errorResponse(__('Variation is required', 'bit-integrations-pro'));
            }

            $variationProduct = wc_get_product($variationId);

            if (!$variationProduct instanceof \WC_Product_Variation || (int) $variationProduct->get_parent_id() !== $productId) {
                return self::errorResponse(__('Selected variation is invalid', 'bit-integrations-pro'));
            }
        } else {
            $variationId = 0;
        }

        $cartItemKey = false;

        ModernCartHelper::suspendCartUpdatedTrigger();

        try {
            $cartItemKey = $cart->add_to_cart($productId, $quantity, $variationId, $variations);

            if ($cartItemKey) {
                ModernCartHelper::flagCartSession();
                $cart->calculate_totals();
            }
        } catch (\Exception $exception) {
            return self::errorResponse($exception->getMessage());
        } finally {
            ModernCartHelper::resumeCartUpdatedTrigger();
        }

        if (!$cartItemKey) {
            return self::errorResponse(__('Product could not be added to the cart', 'bit-integrations-pro'));
        }

        return self::successResponse(
            __('Product added to cart successfully', 'bit-integrations-pro'),
            [
                'cart_item_key' => $cartItemKey,
                'product'       => ModernCartHelper::getProductData($product),
                'cart'          => [
                    'items'  => ModernCartHelper::getCartItems($cart),
                    'totals' => ModernCartHelper::getCartTotals($cart),
                ],
            ]
        );
    }

    public static function updateCartQuantity($defaultResponse, $fieldData, $integrationDetails = null)
    {
        if (!ModernCartHelper::isPluginInstalled()) {
            return self::errorResponse(__('Modern Cart is not installed or activated', 'bit-integrations-pro'));
        }

        if (!ModernCartHelper::isWooCommerceAvailable()) {
            return self::errorResponse(__('WooCommerce cart is not available', 'bit-integrations-pro'));
        }

        $cartItemKey = sanitize_text_field(self::getIntegrationValue($integrationDetails, 'cartItemKey'));

        if (empty($cartItemKey)) {
            return self::errorResponse(__('Cart item is required', 'bit-integrations-pro'));
        }

        if (!isset($fieldData['quantity']) || $fieldData['quantity'] === '') {
            return self::errorResponse(__('Quantity is required', 'bit-integrations-pro'));
        }

        $quantity = max(0, self::toInt($fieldData['quantity']));
        $cart = WC()->cart;
        $cartItem = ModernCartHelper::getCartItem($cartItemKey, $cart);

        if (!$cartItem) {
            $fallbackCartItemKey = ModernCartHelper::findCartItemKey(
                self::toInt(self::getIntegrationValue($integrationDetails, 'cartItemProductId')),
                self::toInt(self::getIntegrationValue($integrationDetails, 'cartItemVariationId')),
                $cart
            );

            if (!empty($fallbackCartItemKey)) {
                $cartItemKey = $fallbackCartItemKey;
                $cartItem = ModernCartHelper::getCartItem($cartItemKey, $cart);
            }
        }

        if (!$cartItem) {
            return self::errorResponse(__('Cart item not found', 'bit-integrations-pro'));
        }

        $currentQuantity = (int) ($cartItem['quantity'] ?? 0);

        if ($currentQuantity === $quantity) {
            return self::successResponse(
                __('Cart quantity updated successfully', 'bit-integrations-pro'),
                [
                    'cart_item_key' => $cartItemKey,
                    'quantity'      => $quantity,
                    'items'         => ModernCartHelper::getCartItems($cart),
                    'totals'        => ModernCartHelper::getCartTotals($cart),
                ]
            );
        }

        $result = false;

        ModernCartHelper::suspendCartUpdatedTrigger();

        try {
            $result = $quantity === 0 ? $cart->remove_cart_item($cartItemKey) : $cart->set_quantity($cartItemKey, $quantity);

            if ($result) {
                $cart->calculate_totals();
                ModernCartHelper::flagCartSession();
            }
        } catch (\Exception $exception) {
            return self::errorResponse($exception->getMessage());
        } finally {
            ModernCartHelper::resumeCartUpdatedTrigger();
        }

        if (!$result) {
            return self::errorResponse(__('Cart quantity could not be updated', 'bit-integrations-pro'));
        }

        return self::successResponse(
            __('Cart quantity updated successfully', 'bit-integrations-pro'),
            [
                'cart_item_key' => $cartItemKey,
                'quantity'      => $quantity,
                'items'         => ModernCartHelper::getCartItems($cart),
                'totals'        => ModernCartHelper::getCartTotals($cart),
            ]
        );
    }

    public static function removeProductFromCart($defaultResponse, $fieldData, $integrationDetails = null)
    {
        if (!ModernCartHelper::isPluginInstalled()) {
            return self::errorResponse(__('Modern Cart is not installed or activated', 'bit-integrations-pro'));
        }

        if (!ModernCartHelper::isWooCommerceAvailable()) {
            return self::errorResponse(__('WooCommerce cart is not available', 'bit-integrations-pro'));
        }

        $cartItemKey = sanitize_text_field($fieldData['cart_item_key'] ?? '');

        if (empty($cartItemKey)) {
            return self::errorResponse(__('Cart item is required', 'bit-integrations-pro'));
        }

        $cart = WC()->cart;
        $cartItem = ModernCartHelper::getCartItem($cartItemKey, $cart);

        if (!$cartItem) {
            return self::errorResponse(__('Cart item not found', 'bit-integrations-pro'));
        }

        $removed = false;

        ModernCartHelper::suspendCartUpdatedTrigger();

        try {
            $removed = $cart->remove_cart_item($cartItemKey);

            if ($removed) {
                $cart->calculate_totals();
                ModernCartHelper::flagCartSession();
            }
        } catch (\Exception $exception) {
            return self::errorResponse($exception->getMessage());
        } finally {
            ModernCartHelper::resumeCartUpdatedTrigger();
        }

        if (!$removed) {
            return self::errorResponse(__('Cart item could not be removed', 'bit-integrations-pro'));
        }

        return self::successResponse(
            __('Cart item removed successfully', 'bit-integrations-pro'),
            [
                'cart_item_key' => $cartItemKey,
                'items'         => ModernCartHelper::getCartItems($cart),
                'totals'        => ModernCartHelper::getCartTotals($cart),
            ]
        );
    }

    private static function getIntegrationValue($integrationDetails, $key, $default = '')
    {
        return \is_object($integrationDetails) && isset($integrationDetails->{$key})
            ? $integrationDetails->{$key}
            : $default;
    }

    private static function successResponse($message, $data = [])
    {
        return [
            'success' => true,
            'message' => $message,
            'data'    => $data
        ];
    }

    private static function errorResponse($message)
    {
        return [
            'success' => false,
            'message' => $message
        ];
    }

    private static function toInt($value, $default = 0)
    {
        return is_numeric($value) ? (int) $value : $default;
    }

    private static function toPositiveInt($value, $default = 1)
    {
        return max(1, self::toInt($value, $default));
    }
}
