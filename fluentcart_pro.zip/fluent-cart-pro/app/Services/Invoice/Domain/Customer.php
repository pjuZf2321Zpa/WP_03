<?php

declare(strict_types=1);

namespace FluentCartPro\App\Services\Invoice\Domain;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Customer DTO (buyer). Immutable.
 */
final class Customer
{
    public string $customer_name;

    public string $company_name;

    public string $email;

    public string $address_line_1;

    public string $address_line_2;

    public string $city;

    public string $state;

    public string $zip;

    public string $country_code;

    public string $buyer_vat_id;

    public ?string $buyer_electronic_address;

    /**
     * @param array<string, string|null> $data
     */
    public function __construct(array $data = [])
    {
        $this->customer_name           = (string) ($data['customer_name'] ?? '');
        $this->company_name            = (string) ($data['company_name'] ?? '');
        $this->email                   = (string) ($data['email'] ?? '');
        $this->address_line_1          = (string) ($data['address_line_1'] ?? '');
        $this->address_line_2          = (string) ($data['address_line_2'] ?? '');
        $this->city                    = (string) ($data['city'] ?? '');
        $this->state                   = (string) ($data['state'] ?? '');
        $this->zip                     = (string) ($data['zip'] ?? '');
        $this->country_code            = (string) ($data['country_code'] ?? '');
        $this->buyer_vat_id            = (string) ($data['buyer_vat_id'] ?? '');
        $this->buyer_electronic_address = isset($data['buyer_electronic_address']) && $data['buyer_electronic_address'] !== '' && $data['buyer_electronic_address'] !== null
            ? (string) $data['buyer_electronic_address']
            : null;
    }
}
