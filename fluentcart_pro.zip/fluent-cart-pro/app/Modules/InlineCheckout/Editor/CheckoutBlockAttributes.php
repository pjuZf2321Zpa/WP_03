<?php

namespace FluentCartPro\App\Modules\InlineCheckout\Editor;

use FluentCartPro\App\Services\Translations\Translations;
use FluentCartPro\App\Utils\Enqueuer\Vite;

/**
 * Puts the Products panel into core's checkout block inspector.
 *
 * Everything editor-side happens in JavaScript, through WordPress's own
 * `blocks.registerBlockType` and `editor.BlockEdit` filters. There is no PHP
 * counterpart because core registers the checkout block with no attributes at
 * all: WP_Block_Type::prepare_attributes_for_render() then passes the parsed
 * block comment through verbatim, so the PHP render callback already receives
 * whatever an author configured here. Only the editor needs a schema.
 */
class CheckoutBlockAttributes
{
    /**
     * @return void
     */
    public function register(): void
    {
        add_action('enqueue_block_editor_assets', [$this, 'enqueue']);
    }

    /**
     * @return void
     */
    public function enqueue(): void
    {
        // `wp-hooks` and `wp-compose` carry addFilter and
        // createHigherOrderComponent; the rest are what the panel renders with.
        //
        // Core's checkout-block editor script is deliberately NOT a dependency.
        // editor.BlockEdit is applied at render time, so load order does not
        // matter, and the components this panel borrows are read off `window`
        // with a null-check — an explicit dependency would only turn a
        // recoverable version skew into a hard failure.
        Vite::enqueueScript(
            'fct-checkout-selector-editor',
            'admin/BlockEditor/CheckoutSelector/checkout-selector-editor.jsx',
            [
                'wp-hooks',
                'wp-compose',
                'wp-blocks',
                'wp-block-editor',
                'wp-components',
                'wp-element',
                'wp-i18n',
            ],
            FLUENTCART_PRO_PLUGIN_VERSION,
            true
        )->with([
            'fluent_cart_pro_block_translation' => Translations::blockStrings(),
        ]);
    }
}
