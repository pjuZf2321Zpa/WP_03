<?php

namespace BitApps\IntegrationsPro\Actions\ElementsKit;

if (!defined('ABSPATH')) {
    exit;
}

final class ElementsKitProHelper
{
    public static function createTemplate($defaultResponse, $fieldData, $utilities = null, $integrationDetails = null)
    {
        if (!ElementsKitHelper::isPluginActive()) {
            return ElementsKitHelper::error(__('ElementsKit is not installed or activated', 'bit-integrations-pro'));
        }

        if (!ElementsKitHelper::isProvided($fieldData, 'title')) {
            return ElementsKitHelper::error(__('Title is required', 'bit-integrations-pro'));
        }

        $type = ElementsKitHelper::config($integrationDetails, 'templateType');

        if (empty($type)) {
            return ElementsKitHelper::error(__('Template type is required', 'bit-integrations-pro'));
        }

        $templateId = wp_insert_post(
            [
                'post_title'  => $fieldData['title'],
                'post_type'   => ElementsKitHelper::TEMPLATE_POST_TYPE,
                'post_status' => ElementsKitHelper::normalizeStatus(ElementsKitHelper::utility($utilities, 'selected_status', 'publish')),
                'post_author' => get_current_user_id(),
            ],
            true
        );

        if (is_wp_error($templateId)) {
            return ElementsKitHelper::error($templateId->get_error_message());
        }

        $templateId = (int) $templateId;

        ElementsKitHelper::seedElementorMeta($templateId);
        ElementsKitHelper::writeTemplateMeta(
            $templateId,
            self::withConditionUtilities($fieldData, $utilities),
            $type,
            ElementsKitHelper::utility($utilities, 'selected_activation', 'no'),
            true
        );

        return ElementsKitHelper::success(__('Template created successfully', 'bit-integrations-pro'), ['id' => $templateId]);
    }

    public static function updateTemplate($defaultResponse, $fieldData, $utilities = null)
    {
        $guard = self::guardPost($fieldData, 'template_id', ElementsKitHelper::TEMPLATE_POST_TYPE, __('ElementsKit template not found.', 'bit-integrations-pro'));

        if (\is_array($guard)) {
            return $guard;
        }

        $templateId = $guard;
        $postData = ['ID' => $templateId];

        if (ElementsKitHelper::isProvided($fieldData, 'title')) {
            $postData['post_title'] = $fieldData['title'];
        }

        $status = ElementsKitHelper::utility($utilities, 'selected_status');

        if (!empty($status)) {
            $postData['post_status'] = ElementsKitHelper::normalizeStatus($status);
        }

        $type = ElementsKitHelper::utility($utilities, 'selected_type');
        $activation = ElementsKitHelper::utility($utilities, 'selected_activation');
        $mergedFieldData = self::withConditionUtilities($fieldData, $utilities);

        $hasMetaChange = !empty($type) || !empty($activation) || \count(array_filter(
            ['condition', 'condition_singular', 'condition_singular_id'],
            function ($key) use ($mergedFieldData) {
                return ElementsKitHelper::isProvided($mergedFieldData, $key);
            }
        )) > 0;

        if (\count($postData) <= 1 && !$hasMetaChange) {
            return ElementsKitHelper::error(__('No fields to update.', 'bit-integrations-pro'));
        }

        if (\count($postData) > 1) {
            $updated = wp_update_post($postData, true);

            if (is_wp_error($updated)) {
                return ElementsKitHelper::error($updated->get_error_message());
            }
        }

        ElementsKitHelper::writeTemplateMeta($templateId, $mergedFieldData, $type, $activation, false);

        return ElementsKitHelper::success(__('Template updated successfully', 'bit-integrations-pro'), ['id' => $templateId]);
    }

    public static function updateTemplateActivation($defaultResponse, $fieldData, $integrationDetails = null)
    {
        $guard = self::guardPost($fieldData, 'template_id', ElementsKitHelper::TEMPLATE_POST_TYPE, __('ElementsKit template not found.', 'bit-integrations-pro'));

        if (\is_array($guard)) {
            return $guard;
        }

        $activation = ElementsKitHelper::config($integrationDetails, 'activation');

        if ($activation === null || $activation === '') {
            return ElementsKitHelper::error(__('Activation is required', 'bit-integrations-pro'));
        }

        update_post_meta($guard, ElementsKitHelper::TEMPLATE_ACTIVATION_META, ElementsKitHelper::normalizeActivation($activation));

        return ElementsKitHelper::success(__('Template activation updated successfully', 'bit-integrations-pro'), ['id' => $guard]);
    }

    public static function deleteTemplate($defaultResponse, $fieldData, $utilities = null)
    {
        $guard = self::guardPost($fieldData, 'template_id', ElementsKitHelper::TEMPLATE_POST_TYPE, __('ElementsKit template not found.', 'bit-integrations-pro'));

        if (\is_array($guard)) {
            return $guard;
        }

        return ElementsKitHelper::deleteRecord(
            $guard,
            ElementsKitHelper::utility($utilities, 'selected_force_delete') === 'yes',
            __('Failed to delete the ElementsKit template.', 'bit-integrations-pro'),
            __('ElementsKit template deleted successfully.', 'bit-integrations-pro')
        );
    }

    public static function deleteWidget($defaultResponse, $fieldData, $utilities = null)
    {
        $guard = self::guardPost($fieldData, 'widget_id', ElementsKitHelper::WIDGET_POST_TYPE, __('ElementsKit widget not found.', 'bit-integrations-pro'));

        if (\is_array($guard)) {
            return $guard;
        }

        return ElementsKitHelper::deleteRecord(
            $guard,
            ElementsKitHelper::utility($utilities, 'selected_force_delete') === 'yes',
            __('Failed to delete the ElementsKit widget.', 'bit-integrations-pro'),
            __('ElementsKit widget deleted successfully.', 'bit-integrations-pro')
        );
    }

    public static function createContent($defaultResponse, $fieldData, $utilities = null, $integrationDetails = null)
    {
        if (!ElementsKitHelper::isPluginActive()) {
            return ElementsKitHelper::error(__('ElementsKit is not installed or activated', 'bit-integrations-pro'));
        }

        if (!ElementsKitHelper::isProvided($fieldData, 'title')) {
            return ElementsKitHelper::error(__('Title is required', 'bit-integrations-pro'));
        }

        $parentId = (int) ElementsKitHelper::config($integrationDetails, 'selectedParent', 0);
        $invalidParent = self::validateParent($parentId, 0);

        if (\is_array($invalidParent)) {
            return $invalidParent;
        }

        $contentId = wp_insert_post(
            [
                'post_title'   => $fieldData['title'],
                'post_content' => $fieldData['content'] ?? '',
                'post_type'    => ElementsKitHelper::CONTENT_POST_TYPE,
                'post_status'  => ElementsKitHelper::normalizeStatus(ElementsKitHelper::utility($utilities, 'selected_status', 'publish')),
                'post_parent'  => $parentId,
                'post_author'  => get_current_user_id(),
            ],
            true
        );

        if (is_wp_error($contentId)) {
            return ElementsKitHelper::error($contentId->get_error_message());
        }

        $contentId = (int) $contentId;

        ElementsKitHelper::seedElementorMeta($contentId);

        return ElementsKitHelper::success(__('Dynamic content created successfully', 'bit-integrations-pro'), ['id' => $contentId]);
    }

    public static function updateContent($defaultResponse, $fieldData, $utilities = null, $integrationDetails = null)
    {
        $guard = self::guardPost($fieldData, 'content_id', ElementsKitHelper::CONTENT_POST_TYPE, __('ElementsKit dynamic content not found.', 'bit-integrations-pro'));

        if (\is_array($guard)) {
            return $guard;
        }

        $contentId = $guard;

        // An explicit "No Parent" choice arrives as '0' and must detach the item, which is
        // different from leaving the dropdown untouched and keeping the current parent.
        $selectedParent = ElementsKitHelper::config($integrationDetails, 'selectedParent');
        $parentId = (int) $selectedParent;
        $invalidParent = self::validateParent($parentId, $contentId);

        if (\is_array($invalidParent)) {
            return $invalidParent;
        }

        $postData = ['ID' => $contentId];

        if (ElementsKitHelper::isProvided($fieldData, 'title')) {
            $postData['post_title'] = $fieldData['title'];
        }

        if (ElementsKitHelper::isProvided($fieldData, 'content')) {
            $postData['post_content'] = $fieldData['content'];
        }

        if ($selectedParent !== null) {
            $postData['post_parent'] = $parentId;
        }

        $status = ElementsKitHelper::utility($utilities, 'selected_status');

        if (!empty($status)) {
            $postData['post_status'] = ElementsKitHelper::normalizeStatus($status);
        }

        if (\count($postData) <= 1) {
            return ElementsKitHelper::error(__('No fields to update.', 'bit-integrations-pro'));
        }

        $updated = wp_update_post($postData, true);

        if (is_wp_error($updated)) {
            return ElementsKitHelper::error($updated->get_error_message());
        }

        return ElementsKitHelper::success(__('Dynamic content updated successfully', 'bit-integrations-pro'), ['id' => $contentId]);
    }

    public static function deleteContent($defaultResponse, $fieldData, $utilities = null)
    {
        $guard = self::guardPost($fieldData, 'content_id', ElementsKitHelper::CONTENT_POST_TYPE, __('ElementsKit dynamic content not found.', 'bit-integrations-pro'));

        if (\is_array($guard)) {
            return $guard;
        }

        return ElementsKitHelper::deleteRecord(
            $guard,
            ElementsKitHelper::utility($utilities, 'selected_force_delete') === 'yes',
            __('Failed to delete the ElementsKit dynamic content.', 'bit-integrations-pro'),
            __('ElementsKit dynamic content deleted successfully.', 'bit-integrations-pro')
        );
    }

    /**
     * Resolve a required id from the field map and confirm it still points at the
     * expected ElementsKit CPT. Returns the int id, or an error envelope.
     */
    private static function guardPost($fieldData, $key, $postType, $notFoundMessage)
    {
        if (!ElementsKitHelper::isPluginActive()) {
            return ElementsKitHelper::error(__('ElementsKit is not installed or activated', 'bit-integrations-pro'));
        }

        if (!ElementsKitHelper::isProvided($fieldData, $key)) {
            return ElementsKitHelper::error(__('Record id is required', 'bit-integrations-pro'));
        }

        $postId = (int) $fieldData[$key];

        if (!ElementsKitHelper::isPostOfType(get_post($postId), $postType)) {
            return ElementsKitHelper::error($notFoundMessage);
        }

        return $postId;
    }

    /**
     * The CPT is hierarchical, and WordPress does not stop a post from becoming its own
     * parent — that produces an ancestor loop. The parent is also confirmed to be a
     * dynamic content item before it is written.
     */
    private static function validateParent($parentId, $contentId)
    {
        if ($parentId <= 0) {
            return null;
        }

        if ($parentId === $contentId) {
            return ElementsKitHelper::error(__('A dynamic content item cannot be its own parent.', 'bit-integrations-pro'));
        }

        if (!ElementsKitHelper::isPostOfType(get_post($parentId), ElementsKitHelper::CONTENT_POST_TYPE)) {
            return ElementsKitHelper::error(__('The selected parent is not an ElementsKit dynamic content item.', 'bit-integrations-pro'));
        }

        return null;
    }

    /**
     * Display conditions are optional and live in Utilities, but writeTemplateMeta reads
     * them off the field-map array — so they are folded in before it runs.
     */
    private static function withConditionUtilities(array $fieldData, $utilities)
    {
        foreach (['condition', 'condition_singular'] as $key) {
            $value = ElementsKitHelper::utility($utilities, 'selected_' . $key);

            if ($value !== null && $value !== '') {
                $fieldData[$key] = $value;
            }
        }

        return $fieldData;
    }
}
