<?php

defined('ABSPATH') || exit;

use MemberPress\GroundLevel\Mothership\AbstractPluginConnection;

/**
 * Provides an interface for connecting the plugin to Mothership packages data
 */
class MeprMothershipPluginConnector extends AbstractPluginConnection
{
    /**
     * Constructor.
     */
    public function __construct()
    {
        $this->productId    = MEPR_EDITION;
        $this->pluginId     = MEPR_PLUGIN_NAME;
        $this->pluginFile   = MEPR_PLUGIN_SLUG;
        $this->pluginPrefix = 'MEPR_';
    }

    /**
     * Gets the license activation status option.
     *
     * @return boolean The license activation status.
     */
    public function getLicenseActivationStatus(): bool
    {
        return (bool) get_option('mepr_activated', false);
    }

    /**
     * Updates the license activation status option.
     *
     * @param boolean $status The status to update.
     */
    public function setLicenseActivationStatus(bool $status): bool
    {
        return update_option('mepr_activated', $status);
    }

    /**
     * Whether to include prerelease versions when checking for updates.
     *
     * @return boolean
     */
    public function allowPrereleaseVersions(): bool
    {
        $options = MeprOptions::fetch();
        $allow   = $options->edge_updates || (defined('MEMBERPRESS_EDGE') && MEMBERPRESS_EDGE);

        /**
         * Filters whether prerelease versions are included when checking for updates.
         *
         * @param bool $allow Whether to allow prerelease versions.
         */
        return (bool) apply_filters("{$this->pluginId}_allow_prerelease_versions", $allow);
    }

    /**
     * Controls which updates are applied automatically during WordPress background updates.
     *
     * @return string
     */
    public function automaticUpdates(): string
    {
        $options = MeprOptions::fetch();

        switch ($options->auto_updates) {
            case 'minor':
                $level = self::AUTOMATIC_UPDATE_MINOR;
                break;
            case 'none':
                $level = self::AUTOMATIC_UPDATE_NONE;
                break;
            default:
                $level = self::AUTOMATIC_UPDATE_ALL;
        }

        /**
         * Filters the automatic update level for the plugin.
         *
         * @param string $level The automatic update level.
         */
        return (string) apply_filters("{$this->pluginId}_automatic_updates", $level);
    }

    /**
     * Gets the account URL.
     *
     * @return string The account URL.
     */
    public function getAccountUrl(): string
    {
        return MeprUtils::get_link_url('account');
    }

    /**
     * Resolves the license key.
     *
     * @return string The license key.
     */
    public function resolveLicenseKey(): string
    {
        return MeprOptions::fetch()->mothership_license;
    }

    /**
     * Stores the license key option.
     *
     * @param string $licenseKey The license key to update.
     */
    public function storeLicenseKey(string $licenseKey): bool
    {
        $opts                     = MeprOptions::fetch();
        $opts->mothership_license = $licenseKey;
        $opts->store(false);

        return true;
    }

    /**
     * Resolves the activation domain.
     *
     * @return string The activation domain.
     */
    public function resolveDomain(): string
    {
        return MeprUtils::site_domain();
    }
}
