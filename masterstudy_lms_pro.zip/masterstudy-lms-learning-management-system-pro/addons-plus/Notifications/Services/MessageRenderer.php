<?php

namespace MasterStudy\Lms\Pro\AddonsPlus\Notifications\Services;

final class MessageRenderer {
	public function render( array $event, array $context ): array {
		return array(
			'title'   => $this->replace_tokens( (string) ( $event['notification_title'] ?? $event['title'] ?? '' ), $context ),
			'message' => $this->replace_tokens( (string) ( $event['notification_message'] ?? $event['message'] ?? '' ), $context ),
		);
	}

	private function replace_tokens( string $text, array $context ): string {
		$tokens = array();

		foreach ( $context as $key => $value ) {
			if ( is_scalar( $value ) ) {
				$tokens[ '{' . $key . '}' ] = (string) $value;
			}
		}

		return strtr( $text, $tokens );
	}
}
