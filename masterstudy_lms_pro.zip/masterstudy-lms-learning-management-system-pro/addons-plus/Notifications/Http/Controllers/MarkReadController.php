<?php

namespace MasterStudy\Lms\Pro\AddonsPlus\Notifications\Http\Controllers;

use MasterStudy\Lms\Http\WpResponseFactory;
use MasterStudy\Lms\Pro\AddonsPlus\Notifications\Repositories\NotificationRepository;
use MasterStudy\Lms\Validation\Validator;
use WP_REST_Response;

final class MarkReadController {
	public function __invoke( int $recipient_id ): WP_REST_Response {
		try {
			if ( ! function_exists( 'masterstudy_lms_is_notifications_frontend_available' ) || ! masterstudy_lms_is_notifications_frontend_available() ) {
				return WpResponseFactory::forbidden();
			}

			$validator = new Validator(
				array( 'recipient_id' => $recipient_id ),
				array( 'recipient_id' => 'required|integer|min,1' )
			);

			if ( $validator->fails() ) {
				return WpResponseFactory::validation_failed( $validator->get_errors_array() );
			}

			$validated  = $validator->get_validated();
			$repository = new NotificationRepository();

			if ( ! $repository->mark_read( absint( $validated['recipient_id'] ), get_current_user_id() ) ) {
				return WpResponseFactory::not_found();
			}

			return WpResponseFactory::ok_with_data(
				array(
					'unread_count' => $repository->unread_count( get_current_user_id() ),
				)
			);
		} catch ( \Throwable $error ) {
			return WpResponseFactory::error( esc_html__( 'Unable to update notification.', 'masterstudy-lms-learning-management-system-pro' ) );
		}
	}
}
