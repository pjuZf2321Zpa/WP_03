<?php

namespace FluentCartPro\App\Modules\Promotional\OrderBump;

/**
 * A MySQL named lock around a read-modify-write. The change never runs without the lock.
 */
class NamedLock
{
    /** Seconds to wait for the lock. Tests set 0. */
    public static $timeout = 5;

    /**
     * @return mixed What the callback returns.
     * @throws RegistryBusyException When another request holds the lock.
     */
    public static function run(string $name, callable $change)
    {
        global $wpdb;

        $locked = (int) $wpdb->get_var($wpdb->prepare('SELECT GET_LOCK(%s, %d)', $name, self::$timeout)) === 1;
        if (!$locked) {
            throw new RegistryBusyException('The lock ' . $name . ' is held by another request.');
        }

        try {
            return $change();
        } finally {
            $wpdb->query($wpdb->prepare('SELECT RELEASE_LOCK(%s)', $name));
        }
    }
}
