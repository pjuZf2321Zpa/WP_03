<?php
/**
 * Paid chatbot form processing, pending forms and conversation resume tokens.
 */
namespace WPAICG\Lib\Chat;

use WP_Error;

if (!defined('ABSPATH')) {
    exit;
}

class FormActions {
    private $bot_storage;
    private $send_error;

    public function __construct($bot_storage, callable $send_error) {
        $this->bot_storage = $bot_storage;
        $this->send_error = $send_error;
    }

    private function send_wp_error(WP_Error $error): void {
        ($this->send_error)($error);
    }

    public function submit(array $context): void {
        [
            'bot_id' => $bot_id,
            'form_id' => $form_id,
            'form_title' => $form_title,
            'trigger_id' => $trigger_id,
            'submitted_data' => $submitted_data,
            'submitted_data_json' => $submitted_data_json,
            'submitted_data_display' => $submitted_data_display,
            'submitted_data_labels' => $submitted_data_labels,
            'conversation_uuid' => $conversation_uuid,
            'user_id' => $user_id,
            'final_session_id' => $final_session_id,
            'post_id_from_request' => $post_id_from_request,
        ] = $context;

        $form_state_store = null;
        if (class_exists('\\WPAICG\\Lib\\Chat\\Triggers\\State\\AIPKit_Conversation_Form_State_Store')) {
            $form_state_store = new \WPAICG\Lib\Chat\Triggers\State\AIPKit_Conversation_Form_State_Store();
            if ($trigger_id === '') {
                $trigger_form_state = $form_state_store->get_form_state_by_form_id(
                    $bot_id,
                    $user_id ?: null,
                    $final_session_id,
                    $conversation_uuid,
                    $form_id
                );
                $trigger_id = is_array($trigger_form_state)
                    ? sanitize_key((string) ($trigger_form_state['trigger_id'] ?? ''))
                    : '';
            }
        }
        if ($trigger_id !== '' && $form_state_store) {
            $trigger_form_state = $form_state_store->get_trigger_state(
                $bot_id,
                $user_id ?: null,
                $final_session_id,
                $conversation_uuid,
                $trigger_id
            );
            if (
                is_array($trigger_form_state)
                && ($trigger_form_state['status'] ?? '') === 'completed'
                && ($trigger_form_state['form_id'] ?? '') === $form_id
            ) {
                wp_send_json_success([
                    'message' => __('Form already submitted.', 'gpt3-ai-content-generator'),
                    'form_gate_completed' => true,
                    'already_completed' => true,
                ]);
                return;
            }
            if (
                !is_array($trigger_form_state)
                || ($trigger_form_state['status'] ?? '') !== 'pending'
                || ($trigger_form_state['form_id'] ?? '') !== $form_id
                || empty($trigger_form_state['form_definition'])
                || !is_array($trigger_form_state['form_definition'])
            ) {
                $this->send_wp_error(new WP_Error(
                    'invalid_pending_form',
                    __('This form is no longer active. Please start a new conversation.', 'gpt3-ai-content-generator'),
                    ['status' => 409]
                ));
                return;
            }

            $required_fields_error = $this->validate_required_fields(
                $trigger_form_state['form_definition'],
                $submitted_data
            );
            if (is_wp_error($required_fields_error)) {
                $this->send_wp_error($required_fields_error);
                return;
            }
        } else {
            $form_state_store = null;
        }


        $triggers_enabled = false;
        if (class_exists(\WPAICG\aipkit_dashboard::class)) {
            $triggers_enabled = \WPAICG\aipkit_dashboard::is_pro_plan();
        }

        $trigger_storage_class = '\WPAICG\Lib\Chat\Triggers\AIPKit_Trigger_Storage';
        $trigger_manager_class = '\WPAICG\Lib\Chat\Triggers\AIPKit_Trigger_Manager';

        $trigger_handler_function = '\WPAICG\Lib\Chat\Triggers\process_chat_triggers';

        if (!$triggers_enabled || !class_exists($trigger_storage_class) || !class_exists($trigger_manager_class) || !function_exists($trigger_handler_function)) {
            wp_send_json_success(['message' => __('Form submitted.', 'gpt3-ai-content-generator') . ' (' . __('Triggers not active or fully available.', 'gpt3-ai-content-generator') . ')']);
            return;
        }

        if (!$this->bot_storage) {
             $this->send_wp_error(new WP_Error('internal_error', __('Chat system (storage) not ready.', 'gpt3-ai-content-generator'), ['status' => 500]));
            return;
        }
        $bot_settings = $this->bot_storage->get_chatbot_settings($bot_id);
        if (empty($bot_settings)) {
            $this->send_wp_error(new WP_Error('bot_not_found', __('Chatbot configuration not found.', 'gpt3-ai-content-generator'), ['status' => 404]));
            return;
        }

        $client_ip = isset($_SERVER['REMOTE_ADDR']) ? sanitize_text_field(wp_unslash($_SERVER['REMOTE_ADDR'])) : null;
        $http_referer = isset($_SERVER['HTTP_REFERER']) ? sanitize_text_field(wp_unslash($_SERVER['HTTP_REFERER'])) : '';
        $user_agent = isset($_SERVER['HTTP_USER_AGENT']) ? sanitize_text_field(wp_unslash($_SERVER['HTTP_USER_AGENT'])) : '';
        $user_wp_roles = $user_id ? (array) wp_get_current_user()->roles : ['guest'];
        $log_storage_instance = null;
        if (class_exists('\WPAICG\Chat\Storage\LogStorage')) {
            $log_storage_instance = new \WPAICG\Chat\Storage\LogStorage();
        }

        $base_log_data_for_triggers = [
            'bot_id'            => $bot_id,
            'user_id'           => $user_id ?: null,
            'session_id'        => $final_session_id,
            'conversation_uuid' => $conversation_uuid,
            'module'            => 'chat', // This ensures trigger meta-logs go to the right conversation
            'is_guest'          => ($user_id === 0 || $user_id === null),
            'ip_address'        => $client_ip,
            'role'              => $user_wp_roles ? implode(', ', $user_wp_roles) : null,
        ];

        $trigger_context = [
            'event_type'            => 'form_submitted', // Added for clarity
            'bot_id'                => $bot_id,
            'form_id'               => $form_id,
            'form_title'            => $form_title,
            'submitted_data'        => $submitted_data,
            'submitted_data_json'   => $submitted_data_json,
            'submitted_data_display' => $submitted_data_display,
            'submitted_data_display_json' => wp_json_encode($submitted_data_display, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
            'submitted_data_labels' => $submitted_data_labels,
            'submitted_data_labels_json' => wp_json_encode($submitted_data_labels, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
            'user_id'               => $user_id ?: null,
            'session_id'            => $final_session_id,
            'conversation_uuid'     => $conversation_uuid,
            'client_ip'             => $client_ip,
            'post_id'               => $post_id_from_request,
            'bot_settings'          => $bot_settings,
            'user_roles'            => $user_wp_roles,
            'current_provider'      => $bot_settings['provider'] ?? null,
            'current_model_id'      => $bot_settings['model'] ?? null,
            'http_referer'          => $http_referer,
            'user_agent'            => $user_agent,
            'log_storage'           => $log_storage_instance,
            'base_log_data'         => $base_log_data_for_triggers, // Pass this populated array
            'module'                => 'chat' // Explicitly set top-level module as well
        ];

        try {
            $trigger_storage_instance = new $trigger_storage_class();
            $trigger_manager_instance = new $trigger_manager_class($trigger_storage_instance, $log_storage_instance);
            $result = $trigger_manager_instance->process_event($bot_id, 'form_submitted', $trigger_context);
            $result_status = $result['status'] ?? 'processed';

            if (
                !in_array($result_status, ['blocked', 'error'], true)
                && $form_state_store
                && !$form_state_store->mark_completed(
                    $bot_id,
                    $user_id ?: null,
                    $final_session_id,
                    $conversation_uuid,
                    $trigger_id,
                    $form_id
                )
            ) {
                throw new \RuntimeException('Could not persist completed chatbot form state.');
            }

            $this->emit_chatbot_form_submitted_event(
                $bot_id,
                $form_id,
                $form_title,
                $submitted_data,
                $submitted_data_display,
                $submitted_data_labels,
                $trigger_context,
                $log_storage_instance
            );

            $has_message_to_user = isset($result['message_to_user']) && is_string($result['message_to_user']) && trim($result['message_to_user']) !== '';
            $resume_token = '';
            if (!$has_message_to_user && !in_array($result_status, ['blocked', 'error'], true)) {
                $resume_token = $this->create_form_resume_token(
                    $bot_id,
                    $form_id,
                    $form_title,
                    $conversation_uuid,
                    $user_id,
                    $final_session_id,
                    $submitted_data,
                    $submitted_data_display,
                    $submitted_data_labels
                );
            }

            $response_data = [
                'message' => $has_message_to_user ? $result['message_to_user'] : __('Form processed.', 'gpt3-ai-content-generator'),
                'message_to_user' => $has_message_to_user ? $result['message_to_user'] : null,
                'has_message_to_user' => $has_message_to_user,
                'resume_token' => $resume_token,
                'actions_executed' => $result['actions_executed'] ?? [],
                'message_id' => $result['message_id'] ?? null,
                'status' => $result_status,
                'form_gate_completed' => (bool) $form_state_store && !in_array($result_status, ['blocked', 'error'], true),
            ];

            if (in_array($result_status, ['blocked', 'error'], true)) {
                wp_send_json_error($response_data, $result_status === 'blocked' ? 400 : 500);
            } else {
                wp_send_json_success($response_data);
            }

        } catch (\Exception $e) {
            $this->send_wp_error(new WP_Error('trigger_processing_error', __('Error processing form submission triggers.', 'gpt3-ai-content-generator'), ['status' => 500]));
        }
    }

    /**
     * Validates required fields against the exact pending form definition.
     *
     * @param array<string, mixed> $form_definition
     * @param array<string, mixed> $submitted_data
     * @return true|WP_Error
     */
    private function validate_required_fields(array $form_definition, array $submitted_data) {
        $elements = isset($form_definition['elements']) && is_array($form_definition['elements'])
            ? $form_definition['elements']
            : [];
        foreach ($elements as $element) {
            if (!is_array($element) || empty($element['required'])) {
                continue;
            }
            $field_id = isset($element['id']) ? (string) $element['id'] : '';
            if ($field_id === '' || !array_key_exists($field_id, $submitted_data)) {
                return new WP_Error(
                    'required_form_field_missing',
                    __('Please complete all required fields.', 'gpt3-ai-content-generator'),
                    ['status' => 400]
                );
            }

            $value = $submitted_data[$field_id];
            if (is_array($value)) {
                $value = array_filter($value, static function ($item): bool {
                    return trim((string) $item) !== '';
                });
                if (empty($value)) {
                    return new WP_Error(
                        'required_form_field_missing',
                        __('Please complete all required fields.', 'gpt3-ai-content-generator'),
                        ['status' => 400]
                    );
                }
            } elseif (trim((string) $value) === '') {
                return new WP_Error(
                    'required_form_field_missing',
                    __('Please complete all required fields.', 'gpt3-ai-content-generator'),
                    ['status' => 400]
                );
            }
        }

        return true;
    }

    /**
     * Emits the canonical Connected Apps event for a Rules-based chatbot form submission.
     *
     * @param array<string, mixed> $submitted_data
     * @param array<string, mixed> $submitted_data_display
     * @param array<string, string> $submitted_data_labels
     * @param array<string, mixed> $trigger_context
     * @param mixed $log_storage_instance
     * @return void
     */
    private function emit_chatbot_form_submitted_event(
        int $bot_id,
        string $form_id,
        string $form_title,
        array $submitted_data,
        array $submitted_data_display,
        array $submitted_data_labels,
        array $trigger_context,
        $log_storage_instance
    ): void {
        if (!class_exists(\WPAICG\Core\AIPKit_Event_Webhooks::class)) {
            return;
        }

        try {
            $conversation_uuid = sanitize_key((string) ($trigger_context['conversation_uuid'] ?? ''));
            if ($bot_id <= 0 || $form_id === '' || $conversation_uuid === '') {
                return;
            }

            $user_id = absint($trigger_context['user_id'] ?? 0);
            $actor_type = $user_id > 0 ? 'user' : 'guest';
            $bot_name = sanitize_text_field((string) (get_the_title($bot_id) ?: ''));
            $form_name = $form_title !== '' ? $form_title : $form_id;
            $submission_id = 'chat-form-' . wp_generate_uuid4();
            $inputs_for_event = $this->add_common_input_aliases($submitted_data);
            $summary = $this->build_form_submission_summary($submitted_data_display, $submitted_data_labels);
            $message_count = $this->get_conversation_message_count(
                $log_storage_instance,
                $user_id,
                sanitize_text_field((string) ($trigger_context['session_id'] ?? '')),
                $bot_id,
                $conversation_uuid
            );

            $payload = [
                'bot' => [
                    'id' => $bot_id,
                    'name' => $bot_name,
                ],
                'conversation' => [
                    'id' => $conversation_uuid,
                    'message_count' => $message_count,
                ],
                'actor' => [
                    'type' => $actor_type,
                ],
                'form' => [
                    'id' => $form_id,
                    'name' => $form_name,
                ],
                'submission' => [
                    'id' => $submission_id,
                ],
                'inputs' => $inputs_for_event,
                'display_values' => $submitted_data_display,
                'labels' => $submitted_data_labels,
                'summary' => $summary,
                'page' => [
                    'id' => absint($trigger_context['post_id'] ?? 0),
                    'url' => esc_url_raw((string) ($trigger_context['http_referer'] ?? '')),
                ],
                'ai' => [
                    'provider' => sanitize_text_field((string) ($trigger_context['current_provider'] ?? '')),
                    'model' => sanitize_text_field((string) ($trigger_context['current_model_id'] ?? '')),
                ],
            ];

            if ($user_id > 0) {
                $payload['actor']['user_id'] = $user_id;
            }

            \WPAICG\Core\AIPKit_Event_Webhooks::emit(
                'chatbot.form_submitted',
                $payload,
                [
                    'module' => 'chatbot',
                    'origin' => 'frontend_rule_form_submission',
                    'resource' => [
                        'type' => 'chatbot_form_submission',
                        'id' => $submission_id,
                        'label' => sprintf(
                            /* translators: %s: form name */
                            __('Chatbot form submitted: %s', 'gpt3-ai-content-generator'),
                            $form_name
                        ),
                    ],
                    'meta' => [
                        'bot_id' => $bot_id,
                        'conversation_uuid' => $conversation_uuid,
                        'form_id' => $form_id,
                        'submission_id' => $submission_id,
                        'message_count' => $message_count,
                        'is_guest' => $user_id > 0 ? 0 : 1,
                    ],
                    'idempotency_key' => sha1(implode('|', [
                        'chatbot.form_submitted',
                        (string) $bot_id,
                        $conversation_uuid,
                        $form_id,
                        $submission_id,
                    ])),
                ]
            );
        } catch (\Throwable $event_error) {
            return;
        }
    }

    /**
     * @param array<string, mixed> $submitted_data_display
     * @param array<string, string> $submitted_data_labels
     */
    private function build_form_submission_summary(array $submitted_data_display, array $submitted_data_labels): string {
        $summary_lines = [];
        foreach ($submitted_data_display as $field_key => $value) {
            $label = isset($submitted_data_labels[$field_key]) && $submitted_data_labels[$field_key] !== ''
                ? $submitted_data_labels[$field_key]
                : (string) $field_key;
            $display_value = $this->stringify_form_value($value);
            if ($display_value === '') {
                continue;
            }
            $summary_lines[] = sanitize_text_field($label) . ': ' . sanitize_text_field($display_value);
        }

        return implode("\n", $summary_lines);
    }

    /**
     * @param mixed $value
     */
    private function stringify_form_value($value): string {
        if (is_array($value)) {
            $parts = [];
            foreach ($value as $item) {
                $item_value = $this->stringify_form_value($item);
                if ($item_value !== '') {
                    $parts[] = $item_value;
                }
            }
            return implode(', ', $parts);
        }

        if (is_bool($value)) {
            return $value ? '1' : '0';
        }

        if ($value === null) {
            return '';
        }

        return (string) $value;
    }

    /**
     * Adds normalized aliases for common CRM fields without removing original field IDs.
     *
     * @param array<string, mixed> $inputs
     * @return array<string, mixed>
     */
    private function add_common_input_aliases(array $inputs): array {
        $aliases = [
            'firstname' => 'first_name',
            'first_name' => 'first_name',
            'first-name' => 'first_name',
            'lastname' => 'last_name',
            'last_name' => 'last_name',
            'last-name' => 'last_name',
            'fullname' => 'name',
            'full_name' => 'name',
            'full-name' => 'name',
            'emailaddress' => 'email',
            'email_address' => 'email',
            'email-address' => 'email',
            'phone_number' => 'phone',
            'phone-number' => 'phone',
            'company_name' => 'company',
            'company-name' => 'company',
        ];

        foreach ($inputs as $field_key => $value) {
            $normalized_key = strtolower((string) $field_key);
            $normalized_key = str_replace([' ', '.'], ['_', '_'], $normalized_key);
            $alias = $aliases[$normalized_key] ?? null;
            if ($alias && !array_key_exists($alias, $inputs)) {
                $inputs[$alias] = $value;
            }
        }

        return $inputs;
    }

    private function get_conversation_message_count($log_storage_instance, int $user_id, string $session_id, int $bot_id, string $conversation_uuid): int {
        if (!is_object($log_storage_instance) || !method_exists($log_storage_instance, 'get_conversation_thread_history')) {
            return 0;
        }

        $history = $log_storage_instance->get_conversation_thread_history(
            $user_id > 0 ? $user_id : null,
            $user_id > 0 ? null : $session_id,
            $bot_id,
            $conversation_uuid
        );

        return is_array($history) ? count($history) : 0;
    }

    private function create_form_resume_token(
        int $bot_id,
        string $form_id,
        string $form_title,
        string $conversation_uuid,
        int $user_id,
        string $session_id,
        array $submitted_data,
        array $submitted_data_display,
        array $submitted_data_labels
    ): string {
        $token = wp_generate_password(32, false, false);
        set_transient(
            'aipkit_chat_form_resume_' . sha1($token),
            [
                'bot_id' => $bot_id,
                'form_id' => $form_id,
                'conversation_uuid' => $conversation_uuid,
                'user_id' => $user_id,
                'session_id' => $session_id,
                'form_submission_context' => [
                    'form_id' => $form_id,
                    'form_title' => $form_title,
                    'submitted_data' => $submitted_data,
                    'submitted_data_display' => $submitted_data_display,
                    'submitted_data_labels' => $submitted_data_labels,
                ],
            ],
            5 * MINUTE_IN_SECONDS
        );

        return $token;
    }
    /** Returns the saved form definition for this actor and conversation. */
    public static function pending_form(int $bot_id, ?int $user_id, ?string $session_id, string $conversation_uuid): ?array {
        $pending_form = null;
        $form_state_store_class = '\\WPAICG\\Lib\\Chat\\Triggers\\State\\AIPKit_Conversation_Form_State_Store';
        if (class_exists($form_state_store_class)) {
            $form_state_store = new $form_state_store_class();
            $pending_form_state = $form_state_store->get_pending_form(
                $bot_id,
                $user_id ?: null,
                $session_id,
                $conversation_uuid
            );
            if (is_array($pending_form_state) && !empty($pending_form_state['form_definition']) && is_array($pending_form_state['form_definition'])) {
                $pending_form = $pending_form_state['form_definition'];
            }
        }

        return $pending_form;
    }
}
