<?php

namespace FluentCartPro\App\Modules\Licensing\Services;

/**
 * Signed release manifests.
 *
 * A vendor can sign each release with an Ed25519 key and publish the manifest
 * and signature alongside the version. A customer's site verifies the pair
 * against a public key it ships with, and refuses to install a package that
 * doesn't match. The store never signs, verifies, parses or regenerates
 * anything — the signing key belongs to the release process and never touches
 * a server. Both values arrive as opaque base64, and are stored and echoed
 * byte for byte.
 *
 * That verbatim requirement is the whole design. The signature covers the
 * exact decoded manifest bytes, so a value that gets json-decoded and
 * re-encoded, line-wrapped, or URL-decoded (turning '+' into a space) is still
 * a well-formed string that no longer verifies. It fails on every site holding
 * a license for the product, and nothing surfaces until a customer can't
 * update. So every check here rejects a bad value and none of them corrects
 * one: a silently repaired signature is worse than a refused save.
 *
 * Off by default. FluentCart is other vendors' licensing server too, and
 * almost none of them sign releases — see isEnabled().
 */
class ReleaseSignature
{
    /**
     * A detached Ed25519 signature is 64 bytes, which is always 88 base64
     * characters including the two padding chars. Anything else — 87, or 90
     * because the paste wrapped — is not a signature this scheme produced.
     */
    const SIGNATURE_LENGTH = 88;

    /**
     * The most base64 a manifest may be.
     *
     * A real one is around 200-260 characters — four short fields and a hex
     * digest — so this leaves better than an order of magnitude of headroom
     * for a format that grows, while keeping the ceiling low enough to matter.
     * Checked before anything decodes or parses the value, and worth checking
     * at all because a manifest isn't stored and forgotten: it is read back and
     * sent in every update response for that product, so an oversized one costs
     * bandwidth on every check by every licensed site, forever.
     */
    const MAX_MANIFEST_LENGTH = 4096;

    /**
     * Does this store publish signed releases?
     *
     * Gates the admin UI only, never the API response: the two fields ship
     * whenever they are non-empty, regardless of this filter. One switch, not
     * two — otherwise a store fills the fields in, leaves the response gate
     * off, and the values silently never reach a single site.
     *
     * @return bool
     */
    public static function isEnabled()
    {
        return (bool) apply_filters('fluent_cart/licensing/enable_signed_releases', false);
    }

    /**
     * Pull the pair out of a product's license settings, dropping empties.
     *
     * @param array $licenseSettings
     * @return array Zero, or both, of manifest and signature
     */
    public static function fromSettings($licenseSettings)
    {
        $pair = [];

        foreach (['manifest', 'signature'] as $key) {
            $value = isset($licenseSettings[$key]) ? (string) $licenseSettings[$key] : '';
            if ($value !== '') {
                $pair[$key] = $value;
            }
        }

        return $pair;
    }

    /**
     * The Ed25519 public keys this store's releases are signed with, keyed by
     * the key_id that appears inside a manifest.
     *
     * Per vendor, not per product — one key signs every product — so this is a
     * filter rather than a field on the product screen. Keying by key_id is
     * what makes rotation work: list both keys during a changeover and pairs
     * signed by either one keep saving.
     *
     * Public keys only. Nothing here can sign anything, and the secret half
     * still never touches a server.
     *
     * @return array key_id => 64-character hex public key
     */
    public static function trustedKeys()
    {
        $keys = apply_filters('fluent_cart/licensing/release_public_keys', []);

        return is_array($keys) ? $keys : [];
    }

    /**
     * Everything wrong with a pasted pair, keyed by field.
     *
     * @param string $manifest
     * @param string $signature
     * @param string $version          The version this save is setting
     * @param string $previousManifest The manifest this product already has, if any
     * @return array Empty when the pair can be stored as-is
     */
    public static function errors($manifest, $signature, $version, $previousManifest = '')
    {
        $errors = [];

        $manifestError = static::manifestError($manifest, $signature, $version, $previousManifest);
        if ($manifestError) {
            $errors['manifest'] = $manifestError;
        }

        $signatureError = static::signatureError($signature, $manifest);
        if ($signatureError) {
            $errors['signature'] = $signatureError;
        }

        // Only worth asking once both values are individually well-formed —
        // and it's the only check that can tell a pair that will verify on a
        // customer's site from one that merely looks like it will.
        if (!$errors) {
            $pairError = static::pairError($manifest, $signature);
            if ($pairError) {
                $errors['signature'] = $pairError;
            }
        }

        return $errors;
    }

    /**
     * Why this manifest and this signature don't belong together, or null.
     *
     * Shape checks can't reach this: a manifest from one release and a
     * signature from another are both perfect on their own, and if the two
     * releases share a version number even the version check passes. The pair
     * saves cleanly, ships to every licensed site, and is refused by all of
     * them — the exact failure the rest of this class exists to prevent.
     *
     * Degrades rather than gates. A store that hasn't published its public key
     * keeps the shape-only validation it had before, instead of being locked
     * out of saving the moment it switches signing on.
     *
     * @param string $manifest
     * @param string $signature
     * @return string|null
     */
    private static function pairError($manifest, $signature)
    {
        $keys = static::trustedKeys();

        if (!$keys || !function_exists('sodium_crypto_sign_verify_detached')) {
            return null;
        }

        $manifestBytes = base64_decode($manifest, true);
        $decoded = json_decode($manifestBytes, true);
        $keyId = (string) $decoded['key_id'];

        if (!isset($keys[$keyId])) {
            return sprintf(
                /* translators: %s: the key_id named inside the manifest */
                __('This manifest was signed by key "%s", which this store doesn\'t list. Add its public key to the fluent_cart/licensing/release_public_keys filter, or paste a pair signed by a key you already publish.', 'fluent-cart-pro'),
                $keyId
            );
        }

        $publicKey = static::decodePublicKey($keys[$keyId]);

        if (!$publicKey) {
            return sprintf(
                /* translators: %s: the key_id named inside the manifest */
                __('The public key published for "%s" is not a 64-character hex Ed25519 key, so this pair can\'t be checked. Fix the key rather than the signature.', 'fluent-cart-pro'),
                $keyId
            );
        }

        try {
            $verified = sodium_crypto_sign_verify_detached(
                base64_decode($signature, true),
                $manifestBytes,
                $publicKey
            );
        } catch (\Exception $e) {
            $verified = false;
        }

        if (!$verified) {
            return sprintf(
                /* translators: %s: the key_id named inside the manifest */
                __('This manifest and signature don\'t belong together, or weren\'t signed by "%s". Re-copy both halves from the same signing output — a site would refuse this update.', 'fluent-cart-pro'),
                $keyId
            );
        }

        return null;
    }

    /**
     * A configured hex public key as raw bytes, or null if it isn't one.
     *
     * @param mixed $key
     * @return string|null
     */
    private static function decodePublicKey($key)
    {
        if (!is_string($key) || !preg_match('/^[a-f0-9]{64}$/i', $key)) {
            return null;
        }

        return hex2bin($key);
    }

    /**
     * Why this manifest can't be stored, or null if it can.
     *
     * @param string $manifest         Base64 of the signed JSON bytes
     * @param string $signature        Its counterpart, to catch a half-filled pair
     * @param string $version          The version this save is setting
     * @param string $previousManifest The manifest this product already has, if any
     * @return string|null
     */
    public static function manifestError($manifest, $signature, $version, $previousManifest = '')
    {
        $manifest = (string) $manifest;

        if ($manifest === '') {
            return ((string) $signature) === ''
                ? null
                : __('A release signature needs its manifest. Paste both values or clear both.', 'fluent-cart-pro');
        }

        // Before the pattern match and the decode, so a value that was never
        // going to be a manifest — a whole file pasted into the wrong box —
        // is turned away without being matched, decoded or parsed first.
        if (strlen($manifest) > static::MAX_MANIFEST_LENGTH) {
            return sprintf(
                /* translators: 1: pasted character count, 2: the limit */
                __('This manifest is %1$s characters; the limit is %2$s. A real one is a few hundred — check you pasted the manifest and not the file it describes.', 'fluent-cart-pro'),
                number_format_i18n(strlen($manifest)),
                number_format_i18n(static::MAX_MANIFEST_LENGTH)
            );
        }

        if (!static::isBase64($manifest)) {
            return __('The manifest is not valid base64. A "+" that arrived as a space is the usual cause — re-copy it from the signing output rather than editing it here.', 'fluent-cart-pro');
        }

        $bytes = base64_decode($manifest, true);
        if ($bytes === false || $bytes === '') {
            return __('The manifest does not decode. Re-copy it from the signing output.', 'fluent-cart-pro');
        }

        $decoded = json_decode($bytes, true);
        if (!is_array($decoded)) {
            return __('The manifest does not contain JSON.', 'fluent-cart-pro');
        }

        foreach (['slug', 'version', 'sha256', 'key_id'] as $key) {
            if (empty($decoded[$key]) || !is_string($decoded[$key])) {
                return sprintf(
                    /* translators: %s: the missing manifest field, e.g. sha256 */
                    __('The manifest is missing "%s".', 'fluent-cart-pro'),
                    $key
                );
            }
        }

        if (!preg_match('/^[a-f0-9]{64}$/i', $decoded['sha256'])) {
            return __('The manifest\'s sha256 is not a 64-character hex digest.', 'fluent-cart-pro');
        }

        // The pair that catches a real mistake: pasting the previous release's
        // manifest onto this one. Both values are individually well-formed and
        // verify against each other, so nothing here would notice — but every
        // customer site would compare the manifest's version against the update
        // it was offered, fail closed, and stop updating.
        if ((string) $decoded['version'] !== (string) $version) {
            return sprintf(
                /* translators: 1: version inside the manifest, 2: version being saved */
                __('This manifest is for version %1$s but the product version is %2$s. Sign the release you are publishing, or fix the version above.', 'fluent-cart-pro'),
                $decoded['version'],
                $version
            );
        }

        // The other product's pair. One key signs every product, so this pair
        // verifies perfectly — only the slug says it belongs somewhere else.
        // There is no field on the store that reliably holds a plugin's
        // directory slug, so the previous manifest for this product is the
        // best witness available, and it's a strong one: a slug that changes
        // under a product is either the wrong paste or a rename.
        $previousSlug = static::slugOf($previousManifest);

        if ($previousSlug !== null && $previousSlug !== (string) $decoded['slug']) {
            return sprintf(
                /* translators: 1: slug inside the pasted manifest, 2: slug of the product's previous manifest */
                __('This manifest is for "%1$s" but this product\'s last release was "%2$s" — check you haven\'t pasted another product\'s pair. If the plugin really was renamed, clear both fields, save, then paste the new pair.', 'fluent-cart-pro'),
                $decoded['slug'],
                $previousSlug
            );
        }

        return null;
    }

    /**
     * The slug inside a stored manifest, or null if there isn't a readable one.
     *
     * @param string $manifest
     * @return string|null
     */
    private static function slugOf($manifest)
    {
        $manifest = (string) $manifest;

        if ($manifest === '' || !static::isBase64($manifest)) {
            return null;
        }

        $decoded = json_decode((string) base64_decode($manifest, true), true);

        if (!is_array($decoded) || empty($decoded['slug']) || !is_string($decoded['slug'])) {
            return null;
        }

        return $decoded['slug'];
    }

    /**
     * Why this signature can't be stored, or null if it can.
     *
     * @param string $signature Base64 of the 64-byte detached signature
     * @param string $manifest  Its counterpart, to catch a half-filled pair
     * @return string|null
     */
    public static function signatureError($signature, $manifest)
    {
        $signature = (string) $signature;

        if ($signature === '') {
            return ((string) $manifest) === ''
                ? null
                : __('A release manifest needs its signature. Paste both values or clear both.', 'fluent-cart-pro');
        }

        // Checked before the decode, because base64 tolerates interior line
        // breaks: a wrapped signature decodes to the right 64 bytes and would
        // pass every other check, while the stored string is no longer the one
        // the signer emitted.
        if (strlen($signature) !== static::SIGNATURE_LENGTH) {
            return sprintf(
                /* translators: 1: expected character count, 2: pasted character count */
                __('A signature is exactly %1$d characters; this one is %2$d. Paste it on a single line, unwrapped.', 'fluent-cart-pro'),
                static::SIGNATURE_LENGTH,
                strlen($signature)
            );
        }

        if (!static::isBase64($signature)) {
            return __('The signature is not valid base64. A "+" that arrived as a space is the usual cause — re-copy it from the signing output rather than editing it here.', 'fluent-cart-pro');
        }

        $bytes = base64_decode($signature, true);
        if ($bytes === false || strlen($bytes) !== 64) {
            return __('The signature does not decode to 64 bytes.', 'fluent-cart-pro');
        }

        return null;
    }

    /**
     * Strict base64: the alphabet and nothing else, padding last.
     *
     * PHP's own strict mode still accepts whitespace, so it can't tell an
     * untouched value from a wrapped or space-corrupted one. This can.
     *
     * @param string $value
     * @return bool
     */
    private static function isBase64($value)
    {
        return (bool) preg_match('#^[A-Za-z0-9+/]+={0,2}$#', $value);
    }
}
