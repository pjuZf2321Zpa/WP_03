<?php defined('ABSPATH') || exit; ?>
<div class="mepr_modal" aria-labelledby="mepr-shop-modal" id="mepr-shop-modal" role="dialog" aria-modal="true" style="display: none;">
  <div class="mepr_modal__overlay"></div>
  <div class="mepr_modal__content_wrapper">
    <div class="mepr_modal__content">
      <div class="mepr_modal__box">
        <button type="button" class="mepr_modal__close">&#x2715;</button>
        <div>
          <h3>
            <?php esc_html_e('Shop Page Settings', 'memberpress'); ?>
          </h3>
          <p><?php esc_html_e('No additional settings are required for the Shop page. Enable the toggle to use the ReadyLaunch template.', 'memberpress'); ?></p>
        </div>
        <button class="mepr_modal__button button button-primary"><?php echo esc_html_x('Update', 'ui', 'memberpress'); ?></button>
      </div>
    </div>
  </div>
</div>
