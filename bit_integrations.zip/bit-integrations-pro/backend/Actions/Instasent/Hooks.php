<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Actions\Instasent\InstasentHelperPro;
use BitApps\IntegrationsPro\Config;
use BitApps\IntegrationsPro\Core\Util\Hooks;

Hooks::filter(Config::withFreePrefix('instasent_send_sms'), [InstasentHelperPro::class, 'sendSms'], 10, 3);
Hooks::filter(Config::withFreePrefix('instasent_create_lookup'), [InstasentHelperPro::class, 'createLookup'], 10, 3);
Hooks::filter(Config::withFreePrefix('instasent_create_datasource'), [InstasentHelperPro::class, 'createDatasource'], 10, 4);
Hooks::filter(Config::withFreePrefix('instasent_create_or_update_contact'), [InstasentHelperPro::class, 'createOrUpdateContact'], 10, 4);
Hooks::filter(Config::withFreePrefix('instasent_delete_contact'), [InstasentHelperPro::class, 'deleteContact'], 10, 4);
Hooks::filter(Config::withFreePrefix('instasent_create_contact_event'), [InstasentHelperPro::class, 'createContactEvent'], 10, 4);
