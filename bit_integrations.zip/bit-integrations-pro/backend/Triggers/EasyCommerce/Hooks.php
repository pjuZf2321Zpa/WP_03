<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Core\Util\Hooks;
use BitApps\IntegrationsPro\Triggers\EasyCommerce\EasyCommerceController;

Hooks::add('easycommerce_user_created', [EasyCommerceController::class, 'handleUserCreated'], 10, 2);
Hooks::add('easycommerce_user_updated', [EasyCommerceController::class, 'handleUserUpdated'], 10, 2);
Hooks::add('easycommerce_attribute_added', [EasyCommerceController::class, 'handleAttributeCreated'], 10, 1);
Hooks::add('easycommerce_add_to_cart', [EasyCommerceController::class, 'handleAddToCart'], 10, 1);
Hooks::add('easycommerce_update_cart', [EasyCommerceController::class, 'handleCartUpdated'], 10, 3);
Hooks::add('easycommerce_remove_from_cart', [EasyCommerceController::class, 'handleRemoveFromCart'], 10, 1);
Hooks::add('easycommerce_clear_cart', [EasyCommerceController::class, 'handleClearedCard'], 10, 1);
Hooks::add('easycommerce_set_shipping_method', [EasyCommerceController::class, 'handleShippingMethod'], 10, 1);
Hooks::add('easycommerce_apply_coupon', [EasyCommerceController::class, 'handleCouponApplied'], 10, 1);
Hooks::add('easycommerce_remove_coupon', [EasyCommerceController::class, 'handleCouponRemoved'], 10, 2);
Hooks::add('easycommerce_before_delete_coupon', [EasyCommerceController::class, 'handleCouponDeleted'], 10, 1);
Hooks::add('easycommerce_coupon_status_updated', [EasyCommerceController::class, 'handleCouponStatusUpdated'], 10, 2);
Hooks::add('easycommerce_after_create_order', [EasyCommerceController::class, 'handleOrderCreated'], 10, 2);
Hooks::add('easycommerce_order_status_updated', [EasyCommerceController::class, 'handleOrderStatusUpdated'], 10, 3);
Hooks::add('easycommerce_order_status_updated', [EasyCommerceController::class, 'handleOrderStatusSetToProcessing'], 10, 3);
Hooks::add('easycommerce_order_status_updated', [EasyCommerceController::class, 'handleOrderStatusSetToCompleted'], 10, 3);
Hooks::add('easycommerce_order_status_updated', [EasyCommerceController::class, 'handleOrderStatusSetToPending'], 10, 3);
Hooks::add('easycommerce_order_status_updated', [EasyCommerceController::class, 'handleOrderStatusSetToRefunded'], 10, 3);
Hooks::add('easycommerce_order_status_updated', [EasyCommerceController::class, 'handleOrderStatusSetToOnHold'], 10, 3);
Hooks::add('easycommerce_order_status_updated', [EasyCommerceController::class, 'handleOrderStatusSetToCancelled'], 10, 3);
Hooks::add('easycommerce_after_refund_order', [EasyCommerceController::class, 'handleOrderRefunded'], 10, 2);
Hooks::add('easycommerce_email', [EasyCommerceController::class, 'handleEmailCustomer'], 10, 4);
Hooks::add('easycommerce_create_product', [EasyCommerceController::class, 'handleProductCreated'], 10, 1);
Hooks::add('easycommerce_update_product', [EasyCommerceController::class, 'handleProductUpdated'], 10, 1);
Hooks::add('easycommerce_before_delete_product', [EasyCommerceController::class, 'handleProductDeleted'], 10, 1);
Hooks::add('easycommerce_update_product_email', [EasyCommerceController::class, 'handleProductStatusUpdated'], 10, 2);
Hooks::add('easycommerce_update_product_email', [EasyCommerceController::class, 'handleProductStatusUpdatedToLive'], 10, 2);
Hooks::add('easycommerce_update_product_email', [EasyCommerceController::class, 'handleProductStatusUpdatedToDraft'], 10, 2);
Hooks::add('easycommerce_update_product_email', [EasyCommerceController::class, 'handleProductStatusUpdatedToTrash'], 10, 2);
Hooks::add('easycommerce_before_send_abandoned_reminder', [EasyCommerceController::class, 'handleSendAbandonedReminder'], 10, 2);
Hooks::add('easycommerce_after_remove_abandoned', [EasyCommerceController::class, 'handleAbandonedCartDeleted'], 10, 3);
