<?php

namespace BitApps\IntegrationsPro\Actions\NiroHelp\Services;

use BitApps\IntegrationsPro\Actions\NiroHelp\NiroHelpHelper;
use BitApps\IntegrationsPro\Core\Util\Hooks;
use NiroHelp\Models\Ticket;

if (!\defined('ABSPATH')) {
    exit;
}

abstract class BaseService
{
    protected $fields;

    public function __construct($fieldData = [], $settings = [])
    {
        $this->fields = array_merge((array) $settings, (array) $fieldData);
    }

    public function validateIntegerFields(): ?array
    {
        $invalidFields = [];

        foreach ($this->integerFieldLabels() as $key => $label) {
            $value = $this->getString($key);

            if ($value !== '' && filter_var($value, FILTER_VALIDATE_INT) === false) {
                $invalidFields[] = $label;
            }
        }

        if (empty($invalidFields)) {
            return null;
        }

        return $this->errorResponse(
            wp_sprintf(
                // translators: %s: comma separated list of field names
                _n('%s must be a whole number. Map a numeric value.', '%s must be whole numbers. Map numeric values.', \count($invalidFields), 'bit-integrations-pro'),
                implode(', ', $invalidFields)
            )
        );
    }

    protected function getValue(string $key)
    {
        return $this->fields[$key] ?? null;
    }

    protected function getString(string $key): string
    {
        $value = $this->getValue($key);

        return \is_scalar($value) ? trim((string) $value) : '';
    }

    protected function getInteger(string $key): ?int
    {
        $value = $this->getString($key);

        return $value === '' ? null : (int) $value;
    }

    protected function hasValue(string $key): bool
    {
        return $this->getString($key) !== '';
    }

    protected function validateRequiredFields(array $labels): ?array
    {
        $missingFields = [];

        foreach ($labels as $key => $label) {
            if (!$this->hasValue($key)) {
                $missingFields[] = $label;
            }
        }

        if (empty($missingFields)) {
            return null;
        }

        return $this->errorResponse(
            wp_sprintf(
                // translators: %s: comma separated list of field names
                _n('%s is required. Map or select a value.', '%s are required. Map or select values.', \count($missingFields), 'bit-integrations-pro'),
                implode(', ', $missingFields)
            )
        );
    }

    protected function findTicket(): ?Ticket
    {
        $ticket = new Ticket((int) $this->getInteger('ticket_id'));

        return $ticket->exists() ? $ticket : null;
    }

    protected function ticketNotFound(): array
    {
        // translators: %d: ticket ID
        return $this->errorResponse(\sprintf(__('No ticket has the ID %d. Map a different ticket ID.', 'bit-integrations-pro'), (int) $this->getInteger('ticket_id')));
    }

    protected function isAgent(int $userId): bool
    {
        return nirohelp_can_hold_tickets($userId);
    }

    protected function termExists(string $key, string $taxonomy): bool
    {
        $termId = (int) $this->getInteger($key);

        return $termId > 0 && term_exists($termId, $taxonomy);
    }

    protected function customFieldValues(): array
    {
        $customFields = [];

        foreach (array_keys(NiroHelpHelper::getCustomFieldKeys()) as $key) {
            if ($this->hasValue($key)) {
                $customFields[$key] = $this->getString($key);
            }
        }

        return $customFields;
    }

    protected function findUnknownCustomField(): string
    {
        $knownKeys = NiroHelpHelper::getCustomFieldKeys();

        foreach (array_keys($this->fields) as $key) {
            $key = (string) $key;

            if (strpos($key, NiroHelpHelper::CUSTOM_FIELD_PREFIX) === 0 && !isset($knownKeys[$key]) && $this->hasValue($key)) {
                return $key;
            }
        }

        return '';
    }

    protected function findOrCreateCustomer(string $email, string $name)
    {
        $user = get_user_by('email', $email);

        if ($user) {
            nirohelp_name_user($user, $name);

            return (int) $user->ID;
        }

        $userData = [
            'user_login' => $email,
            'user_pass'  => wp_generate_password(),
            'user_email' => $email,
            'role'       => NiroHelpHelper::CUSTOMER_ROLE,
        ];

        $displayName = $name !== '' ? $name : nirohelp_display_name_from_email($email);

        if ($displayName !== '') {
            $userData['display_name'] = $displayName;
        }

        if ($name !== '') {
            $userData['first_name'] = $name;
        }

        $userId = wp_insert_user($userData);

        if (is_wp_error($userId)) {
            return $userId;
        }

        Hooks::run('nirohelp_user_inserted', $userId);

        update_user_meta($userId, 'show_admin_bar_front', false);

        return (int) $userId;
    }

    protected function successResponse(string $message, array $data = []): array
    {
        return [
            'success' => true,
            'message' => $message,
            'data'    => $data,
        ];
    }

    protected function errorResponse(string $message): array
    {
        return [
            'success' => false,
            'message' => $message,
        ];
    }

    private function integerFieldLabels(): array
    {
        return [
            'ticket_id'   => __('Ticket ID', 'bit-integrations-pro'),
            'doc_id'      => __('Doc ID', 'bit-integrations-pro'),
            'user_id'     => __('User ID', 'bit-integrations-pro'),
            'author_id'   => __('Author', 'bit-integrations-pro'),
            'agent_id'    => __('Agent', 'bit-integrations-pro'),
            'product_id'  => __('Product', 'bit-integrations-pro'),
            'reason_id'   => __('Reason', 'bit-integrations-pro'),
            'topic_id'    => __('Topic', 'bit-integrations-pro'),
            'parent_id'   => __('Parent Topic', 'bit-integrations-pro'),
            'days'        => __('Due in Days', 'bit-integrations-pro'),
            'max_tickets' => __('Max Open Tickets', 'bit-integrations-pro'),
        ];
    }
}
