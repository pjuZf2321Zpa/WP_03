<?php

namespace MasterStudy\Lms\Pro\AddonsPlus\Notifications\Http\Serializers;

final class NotificationSerializer {
	public function to_array( array $row ): array {
		$metadata = json_decode( (string) ( $row['metadata'] ?? '' ), true );

		if ( ! is_array( $metadata ) ) {
			$metadata = array();
		}

		return array(
			'id'              => (int) $row['recipient_id'],
			'notification_id' => (int) $row['notification_id'],
			'trigger_key'     => (string) $row['trigger_key'],
			'type'            => $this->type_for_trigger( (string) $row['trigger_key'] ),
			'icon'            => $this->icon_for_trigger( (string) $row['trigger_key'] ),
			'title'           => $this->decode_text( (string) $row['title'] ),
			'message'         => $this->decode_text( (string) $row['message'] ),
			'context'         => $this->decode_text( (string) $row['context_label'] ),
			'time'            => $this->format_time( (string) $row['created_at_gmt'] ),
			'unread'          => empty( $row['read_at_gmt'] ),
			'url'             => esc_url_raw( $row['click_url'] ?? '' ),
			'metadata'        => $metadata,
			'created_at_gmt'  => (string) $row['created_at_gmt'],
			'read_at_gmt'     => $row['read_at_gmt'] ? (string) $row['read_at_gmt'] : '',
		);
	}

	public function collection_to_array( array $rows ): array {
		return array_map( array( $this, 'to_array' ), $rows );
	}

	private function format_time( string $created_at_gmt ): string {
		$timestamp = strtotime( $created_at_gmt . ' GMT' );

		if ( false === $timestamp ) {
			return '';
		}

		return sprintf(
			/* translators: %s: relative time. */
			esc_html__( '%s ago', 'masterstudy-lms-learning-management-system-pro' ),
			human_time_diff( $timestamp, time() )
		);
	}

	private function decode_text( string $text ): string {
		return html_entity_decode( $text, ENT_QUOTES | ENT_HTML5, 'UTF-8' );
	}

	private function type_for_trigger( string $trigger_key ): string {
		if ( in_array( $trigger_key, array( 'course_enrolled', 'assignment_graded', 'instructor_application_accepted' ), true ) ) {
			return 'success';
		}

		if ( in_array( $trigger_key, array( 'qa_message_answered', 'new_announcement_posted' ), true ) ) {
			return 'reply';
		}

		if ( in_array( $trigger_key, array( 'lesson_now_available', 'meeting_starting_soon', 'live_lesson_starting_soon' ), true ) ) {
			return 'lesson';
		}

		return 'alert';
	}

	private function icon_for_trigger( string $trigger_key ): string {
		switch ( $this->type_for_trigger( $trigger_key ) ) {
			case 'success':
				return 'stmlms-check-3';
			case 'reply':
				return 'stmlms-chat';
			case 'lesson':
				return 'stmlms-book-open';
			case 'alert':
			default:
				return 'stmlms-bell-outlined';
		}
	}
}
