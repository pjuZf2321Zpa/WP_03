<?php

namespace MasterStudy\Lms\Pro\AddonsPlus\AiLab\Http\Controllers;

use MasterStudy\Lms\Pro\AddonsPlus\AiLab\Services\AiContentGenerator;
use MasterStudy\Lms\Pro\AddonsPlus\AiLab\Services\OpenAi\Client;
use MasterStudy\Lms\Pro\AddonsPlus\AiLab\Utility\Options;

class Controller {
	protected $client;
	protected $ai;
	protected $options;

	public function __construct() {
		$this->options = new Options();
		$this->client  = new Client(
			$this->options->get( 'api_key' ),
			array(
				'provider'       => $this->options->get( 'text_provider' ),
				'base_url'       => $this->options->get( 'base_url' ),
				'image_provider' => $this->options->get( 'image_provider' ),
				'image_api_key'  => $this->options->get( 'image_api_key' ),
				'image_base_url' => $this->options->get( 'image_base_url' ),
				'openai_api_key' => $this->options->get( 'openai_api_key' ),
			)
		);
		$this->ai      = new AiContentGenerator( $this->client );
	}
}
