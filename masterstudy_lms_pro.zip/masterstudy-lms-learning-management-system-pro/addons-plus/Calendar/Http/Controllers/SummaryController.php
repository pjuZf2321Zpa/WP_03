<?php

namespace MasterStudy\Lms\Pro\AddonsPlus\Calendar\Http\Controllers;

use WP_REST_Request;
use WP_REST_Response;

final class SummaryController extends Controller {
	public function __invoke( WP_REST_Request $request ): WP_REST_Response {
		$validated_data = $this->validate(
			$request,
			array_merge(
				$this->month_rules(),
				$this->event_type_rules()
			)
		);

		if ( $validated_data instanceof WP_REST_Response ) {
			return $validated_data;
		}

		return new WP_REST_Response(
			( new \MasterStudy\Lms\Pro\AddonsPlus\Calendar\Http\Serializers\SummarySerializer() )->toArray(
				$this->provider()->get_summary(
					absint( $validated_data['year'] ),
					absint( $validated_data['month'] ),
					$this->get_event_type( $validated_data )
				)
			)
		);
	}
}
