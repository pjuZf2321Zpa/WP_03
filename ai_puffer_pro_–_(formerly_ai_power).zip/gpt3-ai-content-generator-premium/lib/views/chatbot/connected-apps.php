<?php
// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Included template variables are local to the builder renderer.

if (!defined('ABSPATH')) {
    exit;
}

if (!class_exists('\WPAICG\aipkit_dashboard') || !\WPAICG\aipkit_dashboard::is_pro_plan()) {
    return;
}

/*
 * Pro: the apps that get this chatbot's chats, one row each with its status, or one next step when there are
 * none. The connected-apps script redraws the rows from the same labels when another chatbot is chosen.
 */
$connected_apps_manage_url = admin_url('admin.php?page=wpaicg&aipkit_module=settings&aipkit_settings_page=apps');
$connected_apps_manage_attributes = 'href="' . esc_url($connected_apps_manage_url) . '" data-aipkit-open-module="settings" data-aipkit-settings-page="apps"';
$recipes = isset($active_chatbot_connected_apps['recipes']) && is_array($active_chatbot_connected_apps['recipes'])
    ? array_values(array_filter($active_chatbot_connected_apps['recipes'], 'is_array'))
    : [];

$connected_app_labels = [
    'events' => array_map(static fn($event) => $event[1], $connected_app_events),
    'status' => [
        'ready' => __('Ready', 'gpt3-ai-content-generator'),
        'warning' => __('Check setup', 'gpt3-ai-content-generator'),
        'error' => __('Not working', 'gpt3-ai-content-generator'),
        'reauth_required' => __('Sign in again', 'gpt3-ai-content-generator'),
        'paused' => __('Paused', 'gpt3-ai-content-generator'),
    ],
    'scope' => [
        'all' => __('All chatbots', 'gpt3-ai-content-generator'),
        'this' => __('This chatbot', 'gpt3-ai-content-generator'),
        'selected' => __('Some chatbots', 'gpt3-ai-content-generator'),
    ],
    'untitled' => __('Untitled', 'gpt3-ai-content-generator'),
    'note' => __('This app needs a look in Settings.', 'gpt3-ai-content-generator'),
    'fix' => __('Fix in Settings', 'gpt3-ai-content-generator'),
    /* translators: %s: name of a connected app, such as New chats to Slack. */
    'open' => __('Open %s in Settings', 'gpt3-ai-content-generator'),
    /* translators: %d: number of apps. */
    'count_one' => __('%d app gets chats from this chatbot.', 'gpt3-ai-content-generator'),
    /* translators: %d: number of apps. */
    'count_many' => __('%d apps get chats from this chatbot.', 'gpt3-ai-content-generator'),
    'apps' => $connected_apps_supported_destinations,
    'manage_url' => $connected_apps_manage_url,
];

// One row: the app's logo, what it is called, when it sends and what, who it covers, and its status in words.
$connected_app_row = static function (array $recipe) use ($connected_app_labels, $connected_apps_supported_destinations, $connected_apps_manage_attributes, $render_app_mark): void {
    $name = trim(sanitize_text_field((string) ($recipe['name'] ?? ''))) ?: $connected_app_labels['untitled'];
    $app_slug = sanitize_key((string) ($recipe['app_slug'] ?? ''));
    $event_name = (string) ($recipe['event_name'] ?? '');
    $when = $connected_app_labels['events'][$event_name] ?? sanitize_text_field((string) ($recipe['event_label'] ?? ''));
    $then = sanitize_text_field((string) ($recipe['action_label'] ?? ''));
    $scope = $connected_app_labels['scope'][(string) ($recipe['scope_key'] ?? '')] ?? sanitize_text_field((string) ($recipe['scope_label'] ?? ''));
    $status = sanitize_key((string) ($recipe['status_key'] ?? 'warning'));
    if (!isset($connected_app_labels['status'][$status]) || $status === 'paused') {
        $status = 'warning';
    }
    if (empty($recipe['is_enabled'])) {
        $status = 'paused';
    }
    $note = in_array($status, ['warning', 'error', 'reauth_required'], true)
        ? (trim(sanitize_text_field((string) ($recipe['validation_summary'] ?? ''))) ?: $connected_app_labels['note'])
        : '';
    ?>
    <article class="aipkit_panel_row" data-status="<?php echo esc_attr($status); ?>">
        <div class="aipkit_panel_row_main">
            <span class="aipkit_app_logo">
                <?php if (isset($connected_apps_supported_destinations[$app_slug])) : ?>
                    <?php $render_app_mark($connected_apps_supported_destinations[$app_slug]); ?>
                <?php else : ?>
                    <span class="aipkit_app_logo_text"><?php echo esc_html(sanitize_text_field((string) ($recipe['app_label'] ?? ''))); ?></span>
                <?php endif; ?>
            </span>
            <span class="aipkit_panel_row_copy">
                <span class="aipkit_panel_row_title"><?php echo esc_html($name); ?></span>
                <span class="aipkit_panel_row_meta"><?php echo esc_html(implode(' · ', array_filter([$when !== '' && $then !== '' ? $when . ' → ' . $then : $when . $then, $scope]))); ?></span>
            </span>
            <span class="aipkit_app_status aipkit_app_status--<?php echo esc_attr($status); ?>"><?php echo esc_html($connected_app_labels['status'][$status]); ?></span>
            <a class="aipkit_app_row_open" <?php echo $connected_apps_manage_attributes; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped above. ?> aria-label="<?php echo esc_attr(sprintf($connected_app_labels['open'], $name)); ?>">
                <span class="dashicons dashicons-external" aria-hidden="true"></span>
            </a>
        </div>
        <?php if ($note !== '') : ?>
            <p class="aipkit_app_row_note">
                <span class="dashicons dashicons-warning" aria-hidden="true"></span>
                <span class="aipkit_app_row_note_text"><?php echo esc_html($note); ?></span>
                <a <?php echo $connected_apps_manage_attributes; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped above. ?>><?php echo esc_html($connected_app_labels['fix']); ?></a>
            </p>
        <?php endif; ?>
    </article>
    <?php
};

$connected_app_count = count(array_unique(array_filter(array_map(static fn($recipe) => (string) ($recipe['app_label'] ?? ''), $recipes))));
?>
<div class="aipkit_apps aipkit_panel_stack" data-aipkit-chatbot-connected-apps data-aipkit-app-labels="<?php echo esc_attr(wp_json_encode($connected_app_labels)); ?>">
    <div class="aipkit_apps_connected aipkit_panel_stack aipkit_panel_stack--tight" data-aipkit-chatbot-connected-apps-filled<?php echo empty($recipes) ? ' hidden' : ''; ?>>
        <div class="aipkit_panel_top">
            <span class="aipkit_panel_count" data-aipkit-chatbot-connected-apps-count><?php echo esc_html(sprintf($connected_app_count === 1 ? $connected_app_labels['count_one'] : $connected_app_labels['count_many'], $connected_app_count)); ?></span>
            <a class="aipkit_panel_link" <?php echo $connected_apps_manage_attributes; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped above. ?>>
                <span class="aipkit_panel_link_label"><?php esc_html_e('Manage apps', 'gpt3-ai-content-generator'); ?></span>
                <span class="dashicons dashicons-external" aria-hidden="true"></span>
            </a>
        </div>
        <div class="aipkit_panel_list" data-aipkit-chatbot-connected-apps-list>
            <?php foreach ($recipes as $recipe) { $connected_app_row($recipe); } ?>
        </div>
        <a class="aipkit_panel_link aipkit_panel_add" <?php echo $connected_apps_manage_attributes; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped above. ?>>
            <span class="dashicons dashicons-plus-alt2" aria-hidden="true"></span>
            <span class="aipkit_panel_link_label"><?php esc_html_e('Connect another app', 'gpt3-ai-content-generator'); ?></span>
        </a>
    </div>
    <div class="aipkit_apps_none aipkit_panel_stack" data-aipkit-chatbot-connected-apps-empty<?php echo empty($recipes) ? '' : ' hidden'; ?>>
        <div class="aipkit_panel_empty">
            <span class="aipkit_panel_empty_icon dashicons dashicons-admin-plugins" aria-hidden="true"></span>
            <span class="aipkit_panel_empty_title"><?php esc_html_e('No apps get chats from this chatbot yet', 'gpt3-ai-content-generator'); ?></span>
            <span class="aipkit_panel_empty_text"><?php esc_html_e('Connect an app once in Settings, then choose what to send and which chatbots it listens to.', 'gpt3-ai-content-generator'); ?></span>
            <a class="aipkit_btn aipkit_btn-primary aipkit_panel_empty_action" <?php echo $connected_apps_manage_attributes; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped above. ?>>
                <span class="dashicons dashicons-plus-alt2" aria-hidden="true"></span>
                <?php esc_html_e('Connect an app', 'gpt3-ai-content-generator'); ?>
            </a>
        </div>
        <section class="aipkit_panel_section" aria-labelledby="aipkit_apps_works_with_title">
            <h4 class="aipkit_panel_section_title" id="aipkit_apps_works_with_title"><?php esc_html_e('Works with', 'gpt3-ai-content-generator'); ?></h4>
            <div class="aipkit_apps_strip">
                <?php foreach ($connected_apps_supported_destinations as $connected_app_destination) { $render_app_mark($connected_app_destination); } ?>
            </div>
        </section>
        <section class="aipkit_panel_section" aria-labelledby="aipkit_apps_ideas_title">
            <h4 class="aipkit_panel_section_title" id="aipkit_apps_ideas_title"><?php esc_html_e('Ideas', 'gpt3-ai-content-generator'); ?></h4>
            <?php $render_app_ideas(); ?>
        </section>
    </div>
</div>
