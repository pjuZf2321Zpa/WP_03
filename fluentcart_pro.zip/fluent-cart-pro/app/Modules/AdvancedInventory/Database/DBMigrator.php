<?php

namespace FluentCartPro\App\Modules\AdvancedInventory\Database;

use FluentCartPro\App\Database\DBMigrator as BaseDBMigrator;
use FluentCartPro\App\Modules\AdvancedInventory\Database\Migrations\StockAdjustmentsMigrator;

class DBMigrator extends BaseDBMigrator
{
    public function migrate()
    {
        StockAdjustmentsMigrator::migrate();
    }

    public function dropTable()
    {
        StockAdjustmentsMigrator::dropTable();
    }
}