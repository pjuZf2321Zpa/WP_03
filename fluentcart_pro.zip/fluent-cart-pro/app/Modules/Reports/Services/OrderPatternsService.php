<?php

namespace FluentCartPro\App\Modules\Reports\Services;

use FluentCart\App\App;
use FluentCart\App\Modules\MultiCurrency\Services\ReportCurrency;
use FluentCart\App\Services\DateTime\DateFormatter;
use FluentCart\App\Services\Report\OrderReportService;
use FluentCart\App\Services\Report\ReportHelper;

/**
 * The Pro charts of Reports → Orders: orders by day and hour, item count, order value and completion time.
 */
class OrderPatternsService extends OrderReportService
{
    public function getOrderValueDistribution(array $params)
    {
        $query = ReportCurrency::ordersTable($params)
            ->selectRaw("SUM(CASE WHEN total_amount <= 10000 THEN 1 ELSE 0 END) AS `0-100`,
                SUM(CASE WHEN total_amount > 10000 AND total_amount <= 20000 THEN 1 ELSE 0 END) AS `100-200`,
                SUM(CASE WHEN total_amount > 20000 AND total_amount <= 30000 THEN 1 ELSE 0 END) AS `200-300`,
                SUM(CASE WHEN total_amount > 30000 AND total_amount <= 40000 THEN 1 ELSE 0 END) AS `300-400`,
                SUM(CASE WHEN total_amount > 40000 AND total_amount <= 50000 THEN 1 ELSE 0 END) AS `400-500`,
                SUM(CASE WHEN total_amount > 50000 AND total_amount <= 60000 THEN 1 ELSE 0 END) AS `500-600`,
                SUM(CASE WHEN total_amount > 60000 AND total_amount <= 70000 THEN 1 ELSE 0 END) AS `600-700`,
                SUM(CASE WHEN total_amount > 70000 AND total_amount <= 80000 THEN 1 ELSE 0 END) AS `700-800`,
                SUM(CASE WHEN total_amount > 80000 AND total_amount <= 90000 THEN 1 ELSE 0 END) AS `800-900`,
                SUM(CASE WHEN total_amount > 90000 AND total_amount <= 100000 THEN 1 ELSE 0 END) AS `900-1000`,
                SUM(CASE WHEN total_amount > 100000 THEN 1 ELSE 0 END) AS `1000+`");

        $query = $this->applyFilters($query, $params);

        return $query->first();
    }

    public function getReportByDayAndHour(array $params): array
    {
        // Hours and weekdays as the store owner reads them, not in UTC
        $local = ReportHelper::storeTimeSql('o.created_at', $params['startDate'], $params['endDate']);
        $query = ReportCurrency::ordersTable($params)
            ->selectRaw("HOUR({$local}) AS hour_24,

                DAYOFWEEK({$local}) AS day_of_week,

                COUNT(o.id) AS order_count,

                SUM(o.total_paid) / 100 AS gross_sale")
            ->groupByRaw('hour_24, day_of_week')
            ->orderByRaw('hour_24, day_of_week');

        $query = $this->applyFilters($query, $params);

        $ordersData = $query->get();

        $daysOfWeek = [
            1 => 'Sunday',
            2 => 'Monday',
            3 => 'Tuesday',
            4 => 'Wednesday',
            5 => 'Thursday',
            6 => 'Friday',
            7 => 'Saturday'
        ];

        $structuredData = [];
        $grossSaleByHour = [];

        for ($hour = 0; $hour < 24; $hour++) {
            $timeLabel = gmdate(DateFormatter::hourFormat(), mktime($hour, 0));
            $structuredData[$hour] = [
                'hour'      => $timeLabel,
                'Sunday'    => 0,
                'Monday'    => 0,
                'Tuesday'   => 0,
                'Wednesday' => 0,
                'Thursday'  => 0,
                'Friday'    => 0,
                'Saturday'  => 0,
            ];

            $grossSaleByHour[$hour] = [
                'hour'        => $timeLabel,
                'gross_sale'  => 0,
                'order_count' => 0,
            ];
        }

        $grossSaleByDay = array_fill(1, 7, ['day' => 0, 'gross_sale' => 0, 'order_count' => 0]);

        foreach ($ordersData as $order) {
            $hour = (int) $order->hour_24;
            $dayOfWeek = $daysOfWeek[$order->day_of_week];
            $orderCount = $order->order_count;
            
            $structuredData[$hour][$dayOfWeek] += $orderCount;

            $grossSaleByDay[$order->day_of_week]['day'] = $order->day_of_week;
            $grossSaleByDay[$order->day_of_week]['order_count'] += $orderCount;
            $grossSaleByDay[$order->day_of_week]['gross_sale'] += $order->gross_sale;

            $grossSaleByHour[$hour]['gross_sale'] += $order->gross_sale;
            $grossSaleByHour[$hour]['order_count'] += $orderCount;
        }

        return [
            'orderByDayAndHour' => $structuredData,
            'grossSaleByDay'    => array_values($grossSaleByDay),
            'grossSaleByHour'   => array_values($grossSaleByHour),
        ];
    }

    public function getItemCountDistribution(array $params): array
    {
        // Bound by order date, as the order chart is: an item row may predate its order
        $itemsSub = App::db()->table('fct_order_items')
            ->selectRaw('order_id, SUM(quantity) AS item_count')
            ->groupBy('order_id')
            ->whereIn('order_id', fn($q) => $q->select('id')->from('fct_orders')
                ->whereBetween('created_at', [$params['startDate'], $params['endDate']]))
            ->when($params['variationIds'], fn($q) => $q->whereIn('object_id', $params['variationIds']));
            
        $query = ReportCurrency::ordersTable($params)
            ->selectRaw('COUNT(*) AS order_count, oi_sum.item_count')
            ->joinSub($itemsSub, 'oi_sum', fn($join) => $join->on('oi_sum.order_id', '=', 'o.id'))
            ->groupBy('oi_sum.item_count');

        $query = $this->applyFilters($query, $params);

        return $query->get()->toArray();
    }

    public function getOrderCompletionTime(array $params): array
    {
        $query = ReportCurrency::ordersTable($params)
            ->selectRaw("TIMESTAMPDIFF(
                    HOUR, o.created_at, o.completed_at
                ) AS hour,

                COUNT(o.id) AS orders")
            ->whereNotNull('o.completed_at')
            ->groupBy('hour')
            ->orderBy('hour');

        $query = $this->applyFilters($query, $params);

        return $query->get()->toArray();
    }
}
