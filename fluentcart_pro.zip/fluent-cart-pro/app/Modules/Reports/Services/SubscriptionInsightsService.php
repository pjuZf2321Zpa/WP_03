<?php

namespace FluentCartPro\App\Modules\Reports\Services;

use FluentCart\App\App;
use FluentCart\App\Helpers\Status;
use FluentCart\App\Modules\MultiCurrency\Services\BaseCurrency;
use FluentCart\App\Modules\MultiCurrency\Services\ReportCurrency;
use FluentCart\App\Services\DateTime\DateTime;
use FluentCart\App\Services\Report\ReportHelper;
use FluentCart\App\Services\Report\SubscriptionReportService;
use FluentCart\Framework\Support\Arr;

/**
 * The Pro parts of the subscription reports: cancel and rebuy.
 * Extends core's service for the shared renewal and trial queries.
 */
class SubscriptionInsightsService extends SubscriptionReportService
{
    /**
     * Cancel and rebuy: of the subscriptions whose paid term ended in the range without renewing (canceled or
     * expired), those whose customer bought the same product again within $window days before or after that end,
     * usually to get a new-customer price. A purchase long before the end is a second license, not a rebuy.
     */
    public function getRebuys(array $params): array
    {
        $params = $this->clampParamsToToday($params);
        $window = max(1, min(365, (int) Arr::get($params, 'windowDays', self::REBUY_WINDOW_DAYS)));
        $interval = sanitize_key((string) Arr::get($params, 'billingInterval', ''));
        $currency = ReportCurrency::resolve(Arr::get($params, 'currency'));
        $start = $params['startDate']->format('Y-m-d H:i:s');
        $end = $params['endDate']->format('Y-m-d H:i:s');

        $ended = App::db()->table('fct_subscriptions as o')
            ->leftJoinSub(self::lastPaidRenewalQuery(), 'lr', 'lr.parent_id', '=', 'o.parent_order_id')
            ->where('o.bill_times', '<=', 0)
            ->whereIn('o.status', [Status::SUBSCRIPTION_CANCELED, Status::SUBSCRIPTION_EXPIRED])
            ->where('o.customer_id', '>', 0)
            // A free trial that never paid had no paid term to end; a plan changed by an upgrade did not end
            ->whereRaw('NOT (o.trial_days > 0 AND NOT (' . self::simulatedTrialSql('o.') . ') AND lr.paid_at IS NULL)')
            ->when($this->upgradedAwayIds($params), fn($q) => $q->whereNotIn('o.id', $this->upgradedAwayIds($params)))
            ->when($interval !== '', fn($q) => $q->where('o.billing_interval', $interval))
            ->when(!empty($params['variationIds']), fn($q) => $q->whereIn('o.variation_id', $params['variationIds']))
            // The renewal price before tax compares with an order line, which is before tax too
            ->selectRaw('o.id, o.customer_id, o.product_id, o.currency, o.billing_interval, o.recurring_amount, ' . self::termEndSql('o.') . ' AS term_end');
        ReportCurrency::whereCurrencyColumn($ended, 'o.currency', $currency);

        $rows = App::db()->query()->fromSub($ended, 'e')
            ->whereBetween('e.term_end', [$start, $end])
            ->leftJoin('fct_subscriptions as n', function ($join) use ($window) {
                $base = BaseCurrency::get();
                $join->on('n.customer_id', '=', 'e.customer_id')
                    ->on('n.product_id', '=', 'e.product_id')
                    ->on('n.id', '<>', 'e.id')
                    ->whereRaw("n.created_at BETWEEN e.term_end - INTERVAL {$window} DAY AND e.term_end + INTERVAL {$window} DAY")
                    // Prices compare only within one currency (an empty currency is the base one)
                    ->whereRaw("COALESCE(NULLIF(n.currency, ''), ?) = COALESCE(NULLIF(e.currency, ''), ?)", [$base, $base])
                    // A new free trial is a purchase once it paid
                    ->whereRaw('NOT (n.trial_days > 0 AND NOT (' . self::simulatedTrialSql('n.') . ') AND NOT ' . str_replace('s.parent_order_id', 'n.parent_order_id', $this->paidRenewalSql()) . ')')
                    ->where('n.bill_times', '<=', 0)
                    ->whereNotIn('n.status', self::RETENTION_EXCLUDED_STATUSES);
            })
            // What the rebuy paid: its own line on the first order, not the order total (tax, other items)
            ->leftJoin('fct_order_items as pi', function ($join) {
                // The plan line: a signup fee line shares its object id
                $join->on('pi.order_id', '=', 'n.parent_order_id')->on('pi.object_id', '=', 'n.variation_id')
                    ->where('pi.payment_type', 'subscription');
            })
            ->selectRaw('e.id, e.term_end, e.recurring_amount AS old_price, COUNT(DISTINCT n.id) AS rebuys,
                MIN(DATEDIFF(n.created_at, e.term_end)) AS gap, MIN(pi.line_total) AS new_paid,
                MAX(n.trial_days > 0 AND NOT (' . self::simulatedTrialSql('n.') . ')) AS via_trial,
                MAX(n.billing_interval <> e.billing_interval) AS other_interval')
            ->groupBy('e.id', 'e.term_end', 'e.recurring_amount')
            ->get();

        $group = ReportHelper::processGroup($params['startDate'], $params['endDate'], $params['groupKey'] ?? null);
        $byPeriod = $this->getPeriodRange($params['startDate'], $params['endDate'], $group['key'], ['ended', 'rebought']);
        $formats = ['yearly' => 'Y', 'monthly' => 'Y-m', 'daily' => 'Y-m-d'];
        $format = $formats[$group['key']] ?? 'Y-m-d';
        $totals = ['ended' => 0, 'rebought' => 0, 'before' => 0, 'within_7' => 0, 'later' => 0, 'discount_cents' => 0, 'discounted' => 0];

        foreach ($rows as $row) {
            $bucket = ReportHelper::local(new DateTime((string) $row->term_end, new \DateTimeZone('UTC')))->format($format);
            $totals['ended']++;
            if (isset($byPeriod[$bucket])) {
                $byPeriod[$bucket]['ended']++;
            }
            if ((int) $row->rebuys === 0) {
                continue;
            }
            $totals['rebought']++;
            if (isset($byPeriod[$bucket])) {
                $byPeriod[$bucket]['rebought']++;
            }
            $gap = (int) $row->gap;
            $totals[$gap < 0 ? 'before' : ($gap <= 7 ? 'within_7' : 'later')]++;
            // What the rebuy saved the customer against the renewal price it replaced
            $saved = (int) $row->old_price - (int) $row->new_paid;
            // A real free trial that later paid has no first price to compare, nor a plan on another interval (a
            // monthly price is no discount on a yearly one); a 100% first-cycle coupon saved it all
            if ($row->new_paid !== null && !(int) $row->via_trial && !(int) $row->other_interval && $saved > 0) {
                $totals['discount_cents'] += $saved;
                $totals['discounted']++;
            }
        }

        return [
            'window_days'      => $window,
            'ended'            => $totals['ended'],
            'rebought'         => $totals['rebought'],
            'rebuy_rate'       => $totals['ended'] ? round($totals['rebought'] / $totals['ended'] * 100, 2) : null,
            'timing'           => ['before' => $totals['before'], 'within_7' => $totals['within_7'], 'later' => $totals['later']],
            'discounted'       => $totals['discounted'],
            'discount_total'   => $totals['discount_cents'] / 100,
            'discount_average' => $totals['discounted'] ? round($totals['discount_cents'] / $totals['discounted'] / 100, 2) : null,
            'chart'            => array_values($byPeriod),
        ];
    }
}
