<?php if (! defined('ABSPATH')) {
    die('You are not allowed to call this page directly.');
}
$account_link = MeprDrmHelper::get_drm_link(MeprDrmHelper::DRM_LOCKED, 'general', 'account');

$fee_disclosure_percent = MeprDrmHelper::format_fee_disclosure_percent();
$fee_disclosure         = '';
if ('' !== $fee_disclosure_percent) {
    $fee_disclosure = sprintf(
        // Translators: %s: fee percentage, e.g. 3 or 7.9.
        __('Also note: while your license is inactive, an additional %s%% fee is added to each transaction.', 'memberpress'),
        $fee_disclosure_percent
    );
}

$mepr_drm_modal_js = <<<'JS'
   jQuery(document).ready(function($) {
     $('body').on('click', '.mepr-notice-modal-close', function (e) {
        $('body').removeClass('mepr-notice-modal-active');
        $('body').removeClass('mepr-locked');
        $('.mepr-notice-modal').remove();
        $('#wpbody').remove();
     });

   $('body').on('click', '#mepr-drm-activate-license-key', function (e) {
    e.preventDefault();
    var $button = $(this),
     key = $('#mepr-drm-license-key').val();
    if (!key) {
      $('#mepr-drm-license-key').focus();
     return;
     }

     if ($button.hasClass( 'activating ')) {
     return;
     }
    $button.addClass( 'activating ');
     $('.mepr-drm-messages').hide();
     var buttonText = $button.val();
     $button.val( '...' );
    var generic_message = '__MEPR_DRM_GENERIC_MESSAGE__';

     $.ajax({
     url: ajaxurl,
     method: 'POST',
     dataType: 'json',
     data: {
       action: 'mepr_drm_activate_license',
       _ajax_nonce: '__MEPR_DRM_ACTIVATE_NONCE__',
       key: key
     }
     })
     .done(function (response) {
     if (!response || typeof response != 'object' || typeof response.success != 'boolean') {
      $('span.drm-error').html( '__MEPR_DRM_INVALID_RESPONSE__' );
      $('.mepr-key-error').show();
     } else if (!response.success) {
       $('span.drm-error').html( response.data );
       $('.mepr-key-error').show();
     } else {
       $('span.drm-success').html( response.data );
       $('.mepr-key-success').show();
       $('#mepr-drm-form').remove();
       setTimeout(function(){
         window.location.href=__MEPR_DRM_OPTIONS_URL__;
       }, 3000);
     }
     })
     .fail(function () {
     $('.mepr-drm-error span').html( '__MEPR_DRM_AJAX_ERROR__' );
     $('.mepr-key-error').show();
     })
     .always(function () {
     $button.removeClass( 'activating ');
     $button.val( buttonText );
     });
   });
    $('body').on('keypress', '#mepr-drm-license-key', function (e) {
     if(e.which === 13) {
     e.preventDefault();
     $('#mepr-drm-activate-license-key').trigger('click');
     }
   });
});
JS;

$mepr_drm_modal_js = strtr($mepr_drm_modal_js, [
    '__MEPR_DRM_GENERIC_MESSAGE__'  => esc_js(__('ERROR! License Key not valid. Try Again.', 'memberpress')),
    '__MEPR_DRM_ACTIVATE_NONCE__'   => esc_js(wp_create_nonce('mepr_drm_activate_license')),
    '__MEPR_DRM_INVALID_RESPONSE__' => esc_js(__('Invalid response.', 'memberpress')),
    '__MEPR_DRM_OPTIONS_URL__'      => wp_json_encode(esc_url_raw(admin_url('admin.php?page=memberpress-options'))),
    '__MEPR_DRM_AJAX_ERROR__'       => esc_js(__('Ajax error.', 'memberpress')),
]);

wp_register_script('mepr-drm-modal', false, ['jquery'], MEPR_VERSION);
wp_add_inline_script('mepr-drm-modal', $mepr_drm_modal_js);
?>
<div class="mepr-notice-modal">
   <div class="mepr-notice-modal-wrapper">
    <a href='<?php echo esc_url(admin_url()); ?>' class='mepr-notice-modal-close'></a>
    <div class="mepr-notice-modal-content">
     <h3 class="mepr-notice-title"><?php printf(
         // Translators: %1$s: opening span tag, %2$s: closing span tag.
         esc_html__('%1$sALERT!%2$s MemberPress Backend is Deactivated', 'memberpress'),
         '<span>',
         '</span>'
     ); ?></h3>
     <div class="mepr-notice-desc">
      <p><?php esc_html_e('Your MemberPress license key is not found or is invalid. Without an active license key, your frontend is unaffected. However, you can no longer:', 'memberpress'); ?></p>
      <ul>
         <li><?php esc_html_e('Issue customer refunds', 'memberpress'); ?></li>
         <li><?php esc_html_e('Add new members', 'memberpress'); ?></li>
         <li><?php esc_html_e('Manage memberships', 'memberpress'); ?></li>
      </ul>
      <?php if ('' !== $fee_disclosure) : ?>
      <p><?php echo esc_html($fee_disclosure); ?></p>
      <?php endif; ?>
      <div class="mepr-drm-unlock-steps">
        <div class="mepr-drm-unlock-step1">
          <p><?php esc_html_e('This problem is easy to fix!', 'memberpress'); ?></p>
          <p>
            <a target="_blank" href="<?php echo esc_url($account_link); ?>" class="button button-primary"><?php esc_html_e('Click Here to purchase or renew your license key', 'memberpress'); ?></a>
          </p>
        </div>
      </div>
      <p><?php printf(
          // Translators: %1$s: opening anchor tag, %2$s: closing anchor tag.
          esc_html__('If you already have a license key, you can find it on your %1$sAccount Page%2$s, and enter it below:', 'memberpress'),
          '<a href="' . esc_url($account_link) . '" target="_blank">',
          '</a>'
      ); ?></p>
      <form method="POST" id="mepr-drm-form">
         <div class="field"><input name="license_key" id="mepr-drm-license-key" type="text" placeholder="<?php esc_attr_e('License Key', 'memberpress'); ?>"></div>
         <div class="field"><input id="mepr-drm-activate-license-key" type="button" value="<?php esc_attr_e('Submit', 'memberpress'); ?>"></div>
      </form>
      <div class="mepr-key-error mepr-drm-messages" style="display: none;"><span class="drm-error"></span></div>
      <div class="mepr-key-success mepr-drm-messages" style="display: none;"><span class="drm-success"></span></div>

     </div>
    </div>
    <img src="<?php echo esc_url(MEPR_BRAND_URL . '/images/notice-modal-image.png'); ?>" class="mepr-notice-modal-banner" alt="" />
   </div>
</div>
<?php wp_print_scripts(['jquery', 'mepr-drm-modal']); ?>
