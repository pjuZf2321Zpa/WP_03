<?php

/**
 * Single order note item partial.
 *
 * Variables available:
 *   $note (array) — {message, type, user_id, created_at}
 */

if (!defined('ABSPATH')) {
    die('You are not allowed to call this page directly.');
}

$note_type    = isset($note['type']) ? $note['type'] : 'system';
$note_message = isset($note['message']) ? $note['message'] : '';
$note_user_id = isset($note['user_id']) ? (int) $note['user_id'] : 0;
$note_date    = isset($note['created_at']) ? $note['created_at'] : '';

switch ($note_type) {
    case 'admin':
        $type_label = __('Admin Note', 'memberpress');
        $item_class = 'mepr-note-item--admin';
        break;
    case 'customer':
        $type_label = __('Customer Note', 'memberpress');
        $item_class = 'mepr-note-item--customer';
        break;
    default:
        $type_label = __('System', 'memberpress');
        $item_class = 'mepr-note-item--system';
        break;
}

$author = '';
if ($note_user_id > 0) {
    $author_data = get_userdata($note_user_id);
    if ($author_data) {
        $author = $author_data->display_name;
    }
}

$formatted_date = $note_date ? MeprAppHelper::format_date($note_date) : '';
?>
<div class="mepr-note-item <?php echo esc_attr($item_class); ?>">
    <div class="mepr-note-item__header">
        <span class="mepr-note-item__type">
            <?php echo esc_html($type_label); ?>
            <?php if ($author) : ?>
                <span class="mepr-note-item__author">— <?php echo esc_html($author); ?></span>
            <?php endif; ?>
        </span>
        <?php if ($formatted_date) : ?>
            <span class="mepr-note-item__date"><?php echo esc_html($formatted_date); ?></span>
        <?php endif; ?>
    </div>
    <p class="mepr-note-item__message"><?php echo nl2br(esc_html($note_message)); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></p>
</div>
