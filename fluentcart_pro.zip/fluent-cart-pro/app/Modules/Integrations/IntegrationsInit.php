<?php

namespace FluentCartPro\App\Modules\Integrations;

use FluentCartPro\App\Modules\Integrations\LMS\LearnDashLMSConnect;
use FluentCartPro\App\Modules\Integrations\LMS\LifterLMSConnect;

class IntegrationsInit
{
    public function register()
    {
        $registerIntegrations = function () {
            (new WPUserConnect())->register();
            (new WebhookConnect())->register();
            (new LifterLMSConnect())->register();
            (new LearnDashLMSConnect())->register();
        };

        add_action('init', $registerIntegrations, 1);
        
    }


}
