<?php

namespace FluentCartPro\App\Modules\PaymentMethods\PaddleGateway;

use FluentCart\App\Helpers\CurrenciesHelper;
use FluentCart\App\Helpers\StatusHelper;
use FluentCartPro\App\Modules\PaymentMethods\PaddleGateway\API\API;
use FluentCart\App\Helpers\Status;
use FluentCart\App\Models\OrderTransaction;
use FluentCart\App\Models\Subscription;
use FluentCart\App\Modules\PaymentMethods\Core\AbstractSubscriptionModule;
use FluentCart\App\Modules\Subscriptions\Services\SubscriptionService;
use FluentCart\App\Services\DateTime\DateTime;
use FluentCart\App\Services\Payments\SubscriptionHelper;
use FluentCart\Framework\Support\Arr;

class PaddleSubscriptions extends AbstractSubscriptionModule
{
    /**
     * Re-sync subscription from Paddle remote
     */
    public function reSyncSubscriptionFromRemote(Subscription $subscriptionModel)
    {
        if ($subscriptionModel->current_payment_method !== 'paddle') {
            return new \WP_Error(
                'invalid_payment_method',
                __('This subscription is not using Paddle as payment method.', 'fluent-cart-pro')
            );
        }

        $order = $subscriptionModel->order;
        $vendorSubscriptionId = $subscriptionModel->vendor_subscription_id;

        if (!$vendorSubscriptionId) {
            return new \WP_Error(
                'invalid_subscription',
                __('Invalid vendor subscription ID.', 'fluent-cart-pro')
            );
        }

        // Get subscription from Paddle
        $paddleSubscription = API::getPaddleObject("subscriptions/{$vendorSubscriptionId}", [], $order->mode);

        if (is_wp_error($paddleSubscription)) {
            return $paddleSubscription;
        }

        $queryParams = [
            'subscription_id' => $vendorSubscriptionId,
            'status' => 'completed',
        ];

        $paddleTransactions = [];
        $hasMore = false;
        do {
            $transactions = API::getPaddleObject('transactions', $queryParams, $order->mode);

            if (is_wp_error($transactions)) {
                return $transactions;
            }
           foreach (Arr::get($transactions, 'data', []) as $transaction) {
               $paddleTransactions[] = $transaction;
           }

            $hasMore = Arr::get($transactions, 'meta.pagination.has_more');
            $next = Arr::get($transactions, 'meta.pagination.next');
            $queryString = parse_url($next, PHP_URL_QUERY);
            parse_str($queryString, $params);
            $after = $params['after'];
            $queryParams['after'] = $after;

        } while ($hasMore);


        $subscriptionUpdateData = PaddleHelper::getSubscriptionUpdateData($paddleSubscription, $subscriptionModel);

        $newPayment = false;
        $recordError = null;

        // Process transactions and create renewal orders if needed
        if (!empty($paddleTransactions)) {
            // reverse the array to get the latest transaction last
            $paddleTransactions = array_reverse($paddleTransactions);

            foreach ($paddleTransactions as $paddleTransaction) {
                $origin = Arr::get($paddleTransaction, 'origin');
                if (!in_array($origin, ['subscription_recurring', 'web', 'api'], true)) {
                    continue;
                }

                $transactionStatus = Arr::get($paddleTransaction, 'status');
                $meta = PaddleHelper::getTransactionMeta($paddleTransaction, $order);
                $details = Arr::get($paddleTransaction, 'details');
                
                if ($transactionStatus === 'completed') {
                    $vendorChargeId = Arr::get($paddleTransaction, 'id');

                    // Paddle's billed_at is when the remote charge completed; that is
                    // the settlement moment, not this resync's run time.
                    $billedAt = Arr::get($paddleTransaction, 'billed_at', null);
                    $settledAt = $billedAt ? DateTime::anyTimeToGmt($billedAt)->format('Y-m-d H:i:s') : null;

                    $payment = Arr::get($paddleTransaction, 'payments.0');
                    $methodType  = Arr::get($payment, 'method_details.type');
                    $cardLast4 = null;
                    $cardBrand = null;
                    if ($methodType == 'card') {
                        $cardLast4 = Arr::get($payment, 'method_details.card.last4');
                        $cardBrand = Arr::get($payment, 'method_details.card.brand');
                    }

                    $transaction = OrderTransaction::query()->where('vendor_charge_id', $vendorChargeId)->first();
                    if (!$transaction) {
                        $transaction = OrderTransaction::query()
                            ->where('subscription_id', $subscriptionModel->id)
                            ->where('vendor_charge_id', '')
                            ->where('transaction_type', Status::TRANSACTION_TYPE_CHARGE)
                            ->first();


                        if ($transaction) {
                            // Unified MoR reconciliation against the renewal order: handles
                            // cross-currency, tax-excluded (over-pay) and reverse charge
                            // (under-pay) the same way as the initial payment.
                            $reconcile = PaddleReconciler::reconcile($transaction, $paddleTransaction, $transaction->order);

                            // Item mapping must point at this transaction's own order, not the root order.
                            $meta = PaddleHelper::getTransactionMeta($paddleTransaction, $transaction->order);
                            $mergedMeta = array_merge($transaction->meta ?? [], $meta, $reconcile['meta']);
                            if ($settledAt && empty($mergedMeta['settled_at'])) {
                                $mergedMeta['settled_at'] = $settledAt;
                            }

                            $transaction->update([
                                'vendor_charge_id' => $vendorChargeId,
                                'status'           => Status::TRANSACTION_SUCCEEDED,
                                'total'            => (int) $reconcile['amount'],
                                'currency'         => $reconcile['currency'],
                                'meta'             => $mergedMeta,
                                'card_last_4'    => $cardLast4,
                                'card_brand'       => $cardBrand,
                                'payment_method_type' => $methodType
                            ]);

                            (new StatusHelper($transaction->order))->syncOrderStatuses($transaction);

                            continue;
                        }

                        if ($origin !== 'subscription_recurring') {
                            continue;
                        }

                        // Paddle is MoR: record the renewal at the subscription price in the
                        // order currency. For cross-currency the captured foreign amount is
                        // not comparable; for reverse-charge the net would distort revenue
                        // reports. In both cases the authoritative captured totals are already
                        // in $meta via getTransactionMeta (paddle_totals, payout_totals).
                        $rawCaptured      = (int) Arr::get($meta, 'paddle_totals.total', 0);
                        $capturedCurrency = strtoupper((string) Arr::get($meta, 'paddle_totals.currency_code', ''));
                        // Normalize to FC units (×100) — same convention as CapturedCharge::fromPaddle.
                        // Paddle returns zero-decimal currencies (JPY) as whole units; multiply to match.
                        $capturedFC = CurrenciesHelper::isZeroDecimal($capturedCurrency)
                            ? $rawCaptured * 100
                            : $rawCaptured;

                        $transactionData = [
                            'subscription_id'     => $subscriptionModel->id,
                            'payment_method'      => 'paddle',
                            'vendor_charge_id'    => $vendorChargeId,
                            'total'               => (int) $subscriptionModel->recurring_total,
                            'tax_total'           => 0,
                            'payment_method_type' => $methodType,
                            'card_last_4'         => $cardLast4,
                            'card_brand'          => $cardBrand,
                            // The renewal order does not exist yet; its item mapping is filled
                            // in below once recordRenewalPayment has created it.
                            'meta'                => array_merge($meta, [
                                'mapped_paddle_item_ids'   => [],
                                'mor_covered'              => true,
                                'paddle_captured'          => $capturedFC,
                                'paddle_captured_currency' => $capturedCurrency,
                            ], $settledAt ? ['settled_at' => $settledAt] : []),
                            'created_at'          => $billedAt ? DateTime::anyTimeToGmt($billedAt)->format('Y-m-d H:i:s') : DateTime::now()->format('Y-m-d H:i:s')
                        ];

                        $newPayment = true;
                        $recorded = SubscriptionService::recordRenewalPayment($transactionData, $subscriptionModel, $subscriptionUpdateData);

                        // transaction_exists means another delivery already recorded this charge;
                        // anything else left the renewal unrecorded and must surface to the caller.
                        if (is_wp_error($recorded) && $recorded->get_error_code() !== 'transaction_exists') {
                            $recordError = $recordError ?: $recorded;
                            continue;
                        }

                        // Run MoR reconciliation on the newly created transaction so
                        // tax-excluded renewals raise the renewal order and cross-currency
                        // meta is fully populated — mirrors what Paths A/B do via reconcile().
                        $newTxn = OrderTransaction::query()->where('vendor_charge_id', $vendorChargeId)->first();
                        if ($newTxn && $newTxn->order) {
                            $reconcile = PaddleReconciler::reconcile($newTxn, $paddleTransaction, $newTxn->order);
                            $renewalMeta = PaddleHelper::getTransactionMeta($paddleTransaction, $newTxn->order);

                            if ($reconcile['changed']) {
                                $newTxn->total    = (int) $reconcile['amount'];
                                $newTxn->currency = $reconcile['currency'];
                            }
                            $newTxn->meta = array_merge((array) ($newTxn->meta ?? []), [
                                'mapped_paddle_item_ids' => $renewalMeta['mapped_paddle_item_ids'],
                            ], $reconcile['changed'] ? $reconcile['meta'] : []);
                            $newTxn->save();

                            (new StatusHelper($newTxn->order))->syncOrderStatuses($newTxn);
                        }
                    } else if ($transaction->status !== Status::TRANSACTION_SUCCEEDED) {
                        // Unified MoR reconciliation against the renewal order (cross-currency,
                        // tax-excluded, reverse charge) — keeps the status sync comparing the
                        // order against an amount expressed in the order currency.
                        $reconcile = PaddleReconciler::reconcile($transaction, $paddleTransaction, $transaction->order);

                        // Item mapping must point at this transaction's own order, not the root order.
                        $meta = PaddleHelper::getTransactionMeta($paddleTransaction, $transaction->order);
                        $mergedMeta = array_merge($transaction->meta ?? [], $meta, $reconcile['meta']);
                        if ($settledAt && empty($mergedMeta['settled_at'])) {
                            $mergedMeta['settled_at'] = $settledAt;
                        }

                        $transaction->update([
                            'vendor_charge_id' => $vendorChargeId,
                            'status'           => Status::TRANSACTION_SUCCEEDED,
                            'total'            => (int) $reconcile['amount'],
                            'currency'         => $reconcile['currency'],
                            'meta'             => $mergedMeta
                        ]);

                        (new StatusHelper($transaction->order))->syncOrderStatuses($transaction);
                    }
                }
            }
        }

        // Update subscription data
        if (!$newPayment) {
            $subscriptionModel = SubscriptionService::syncSubscriptionStates($subscriptionModel, $subscriptionUpdateData);
        } else {
            $subscriptionModel = Subscription::query()->find($subscriptionModel->id);
        }

        if ($recordError) {
            return $recordError;
        }

        return $subscriptionModel;
    }

    /**
     * Cancel subscription
     */
    public function cancel($vendorSubscriptionId, $args = [])
    {
        if (!$vendorSubscriptionId) {
            return new \WP_Error(
                'invalid_subscription',
                __('Invalid vendor subscription ID.', 'fluent-cart-pro')
            );
        }

        // check if subscription is already canceled in Paddle
        $response = API::getPaddleObject("subscriptions/{$vendorSubscriptionId}", [], Arr::get($args, 'mode', 'live'));

        if (is_wp_error($response)) {  
            return $response;
        }

        $status = PaddleHelper::transformSubscriptionStatus(Arr::get($response, 'data.status'));

        if ($status === Status::SUBSCRIPTION_CANCELED) {
            $canceledAt = Arr::get($response, 'data.canceled_at');
            return [
                'status' => Status::SUBSCRIPTION_CANCELED,
                'canceled_at' =>  SubscriptionHelper::safeTimestampToDatetime($canceledAt)
            ];
        }

        $cancelData = [
            'effective_from' => Arr::get($args, 'effective_from', 'next_billing_period')
        ];

        $response = API::actionPaddleObject("subscriptions/{$vendorSubscriptionId}/cancel", $cancelData, Arr::get($args, 'mode', 'live'));

        if (is_wp_error($response)) {
            return $response;
        }

        $paddleStatus   = Arr::get($response, 'data.status');
        $scheduledChange = Arr::get($response, 'data.scheduled_change');

        // next_billing_period: Paddle keeps status=active with a scheduled cancel change.
        // FC marks as canceled immediately; access retained until canceled_at date.
        if ($paddleStatus === 'active' && Arr::get($scheduledChange, 'action') === 'cancel') {
            $effectiveAt = Arr::get($scheduledChange, 'effective_at');
            return [
                'status'      => Status::SUBSCRIPTION_CANCELED,
                'canceled_at' => SubscriptionHelper::safeTimestampToDatetime($effectiveAt),
            ];
        }

        $canceledAt = Arr::get($response, 'data.canceled_at');

        return [
            'status'      => Status::SUBSCRIPTION_CANCELED,
            'canceled_at' => SubscriptionHelper::safeTimestampToDatetime($canceledAt),
        ];
    }

    /**
     * Pause subscription
     */
    public function pauseSubscription($data, $order, $subscription)
    {
        $vendorSubscriptionId = $subscription->vendor_subscription_id;
        
        if (!$vendorSubscriptionId) {
            throw new \Exception(__('Invalid vendor subscription ID.', 'fluent-cart-pro'), 404);
        }

        $pauseData = [
            'effective_from' => Arr::get($data, 'effective_from', 'next_billing_period')
        ];

        $response = API::actionPaddleObject("subscriptions/{$vendorSubscriptionId}/pause", $pauseData, $order->mode);

        if (is_wp_error($response)) {
            throw new \Exception($response->get_error_message(), 422);
        }

        return [
            'status' => 'success',
            'message' => __('Subscription paused successfully', 'fluent-cart-pro'),
            'paddle_response' => $response
        ];
    }

    /**
     * Resume subscription
     */
    public function resumeSubscription($data, $order, $subscription)
    {
        $vendorSubscriptionId = $subscription->vendor_subscription_id;
        
        if (!$vendorSubscriptionId) {
            throw new \Exception(__('Invalid vendor subscription ID.', 'fluent-cart-pro'), 404);
        }

        $resumeData = [
            'effective_from' => Arr::get($data, 'effective_from', 'immediately')
        ];

        $response = API::actionPaddleObject("subscriptions/{$vendorSubscriptionId}/resume", $resumeData, $order->mode);

        if (is_wp_error($response)) {
            throw new \Exception($response->get_error_message(), 422);
        }

        return [
            'status' => 'success',
            'message' => __('Subscription resumed successfully', 'fluent-cart-pro'),
            'paddle_response' => $response
        ];
    }

    /**
     * Resume a paused Paddle subscription.
     *
     * Called by SubscriptionService::resumeSubscription for automatic subscriptions.
     * Remote first: resumes the subscription at Paddle (effective immediately), and
     * only on success flips the local status and fires the SubscriptionResumed event.
     * The subsequent subscription.resumed webhook re-syncs details; since the local
     * status is already active by then, no duplicate event fires.
     *
     * @param Subscription $subscription
     * @param string $reason
     * @return true|\WP_Error
     */
    public function resume(Subscription $subscription, $reason = '')
    {
        $vendorSubscriptionId = $subscription->vendor_subscription_id;

        if (!$vendorSubscriptionId) {
            return new \WP_Error('invalid_subscription', __('Invalid vendor subscription ID.', 'fluent-cart-pro'));
        }

        $order = $subscription->order;

        $response = API::actionPaddleObject("subscriptions/{$vendorSubscriptionId}/resume", [
            'effective_from' => 'immediately'
        ], $order ? $order->mode : '');

        if (is_wp_error($response)) {
            return $response;
        }

        $oldStatus = $subscription->status;
        $subscription->status = Status::SUBSCRIPTION_ACTIVE;

        $nextBilledAt = Arr::get($response, 'data.next_billed_at');
        if ($nextBilledAt) {
            $subscription->next_billing_date = SubscriptionHelper::safeTimestampToDatetime($nextBilledAt);
        }

        $subscription->save();

        $subscription->addLog(
            'Subscription resumed',
            $reason ?: __('Subscription resumed via Paddle', 'fluent-cart-pro'),
            'info'
        );

        SubscriptionService::dispatchStatusEvent($subscription, 'resumed', [
            'old_status' => $oldStatus,
            'reason'     => $reason,
        ]);

        return true;
    }

    /**
     * Update subscription
     */
    public function updateSubscription($subscriptionId, $updateData, $mode = '')
    {
        $response = API::updatePaddleObject("subscriptions/{$subscriptionId}", $updateData, $mode);

        if (is_wp_error($response)) {
            return $response;
        }

        return [
            'status' => 'success',
            'message' => __('Subscription updated successfully', 'fluent-cart-pro'),
            'paddle_response' => $response
        ];
    }

    /**
     * Switch payment method for subscription
     */
    public function switchPaymentMethod($data, $subscriptionId)
    {
        return new \WP_Error(
            'not_supported',
            __('Payment method switching is not directly supported by Paddle. Please cancel and recreate the subscription.', 'fluent-cart-pro')
        );
    }

    /**
     * Reactivate subscription
     */
    public function reactivateSubscription($data, $subscriptionId)
    {
        // For Paddle, reactivation is typically done through resuming a paused subscription
        // or creating a new subscription if the old one was canceled
        return new \WP_Error(
            'not_supported',
            __('Subscription reactivation is not directly supported by Paddle. Please create a new subscription.', 'fluent-cart-pro')
        );
    }
}
