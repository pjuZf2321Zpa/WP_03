<?php

namespace FluentCartPro\App\Http\Controllers;

use FluentCart\App\Models\Order;
use FluentCart\App\Services\Email\EmailNotificationMailer;
use FluentCart\App\Services\Email\EmailNotifications;
use FluentCartPro\App\Services\Email\FluentBlockParser;
use FluentCart\App\Services\ShortCodeParser\ShortcodeTemplateBuilder;
use FluentCart\Framework\Http\Request\Request;
use FluentCart\Framework\Support\Arr;

class EmailNotificationProController extends Controller
{
    public function preview(Request $request): \WP_REST_Response
    {
        $notificationName = sanitize_text_field(Arr::get($request->all(), 'notification_name', ''));
        $orderId = absint(Arr::get($request->all(), 'order_id', 0));

        if (empty($notificationName)) {
            return $this->sendError([
                'message' => __('No notification name provided.', 'fluent-cart-pro'),
            ]);
        }

        $notification = EmailNotifications::getNotification($notificationName);

        if (!$notification) {
            return $this->sendError([
                'message' => __('Notification not found.', 'fluent-cart-pro'),
            ]);
        }

        // Use block content from request (unsaved editor state), fallback to DB
        $blockContent = Arr::get($request->all(), 'block_content', '');
        if (empty($blockContent)) {
            $blockContent = Arr::get($notification, 'settings.email_body', '');
        }

        $data = $this->resolvePreviewData($orderId);

        $body = (new FluentBlockParser($data))->parse($blockContent);

        $mailer = new EmailNotificationMailer();
        $body = apply_filters('fluent_cart/render_block_email_template', '', [
            'emailBody'   => $body,
            'preheader'   => '',
            'emailFooter' => $mailer->getEmailFooter(),
        ]);

        $body = ShortcodeTemplateBuilder::make($body, $data);

        return $this->sendSuccess([
            'html' => $body,
        ]);
    }

    private function resolvePreviewData($orderId = 0)
    {
        $order = null;

        if ($orderId) {
            $order = Order::query()
                ->with(['customer', 'shipping_address', 'billing_address', 'transactions', 'order_items'])
                ->find($orderId);
        }

        if (!$order) {
            $order = Order::query()
                ->with(['customer', 'shipping_address', 'billing_address', 'transactions', 'order_items'])
                ->latest()
                ->first();
        }

        if ($order) {
            $transaction = [];
            if (!empty($order->transactions)) {
                $transaction = $order->transactions->first();
            }

            return [
                'order'       => $order,
                'customer'    => $order->customer ?: [],
                'transaction' => $transaction ?: [],
            ];
        }

        return [
            'order'       => [],
            'customer'    => [],
            'transaction' => [],
        ];
    }
}
