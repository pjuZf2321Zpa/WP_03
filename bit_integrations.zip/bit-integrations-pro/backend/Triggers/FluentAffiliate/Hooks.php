<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Core\Util\Hooks;
use BitApps\IntegrationsPro\Triggers\FluentAffiliate\FluentAffiliateController;

Hooks::add('fluent_affiliate/affiliate_created', [FluentAffiliateController::class, 'handleAffiliateCreated'], 10, 1);
Hooks::add('fluent_affiliate/affiliate_updated', [FluentAffiliateController::class, 'handleAffiliateUpdated'], 10, 3);
Hooks::add('fluent_affiliate/affiliate_status_to_active', [FluentAffiliateController::class, 'handleAffiliateApproved'], 10, 1);
Hooks::add('fluent_affiliate/affiliate_status_to_pending', [FluentAffiliateController::class, 'handleAffiliatePending'], 10, 2);
Hooks::add('fluent_affiliate/affiliate_status_to_inactive', [FluentAffiliateController::class, 'handleAffiliateInactive'], 10, 2);
Hooks::add('fluent_affiliate/before_delete_affiliate', [FluentAffiliateController::class, 'handleAffiliateDeleted'], 10, 1);
Hooks::add('fluent_affiliate/referral_marked_unpaid', [FluentAffiliateController::class, 'handleReferralCreated'], 10, 1);
Hooks::add('fluent_affiliate/referral/before_delete', [FluentAffiliateController::class, 'handleReferralDeleted'], 10, 1);
