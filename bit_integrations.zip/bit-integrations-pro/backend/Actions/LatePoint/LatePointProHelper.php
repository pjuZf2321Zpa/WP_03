<?php

namespace BitApps\IntegrationsPro\Actions\LatePoint;

use Exception;
use OsAgentModel;
use OsBookingModel;
use OsBundleModel;
use OsCouponModel;
use OsCustomerModel;
use OsOrderItemModel;
use OsOrderModel;
use OsOrdersHelper;

/**
 * LatePoint write actions.
 *
 * Ported from bit-pi's LatePointService. Agent, service, location and bundle ids
 * arrive on $integrationDetails as flow configuration (selected* dropdowns); every
 * other input arrives on $fieldData from the field map.
 */
class LatePointProHelper
{
    public static function createBooking($defaultResponse, $fieldData, $utilities = null, $integrationDetails = null)
    {
        return self::handleBooking($fieldData, $utilities, $integrationDetails, false);
    }

    public static function updateBooking($defaultResponse, $fieldData, $utilities = null, $integrationDetails = null)
    {
        return self::handleBooking($fieldData, $utilities, $integrationDetails, true);
    }

    public static function cancelBooking($defaultResponse, $fieldData)
    {
        if (!LatePointHelper::isPluginInstalled()) {
            return LatePointHelper::errorResponse(__('LatePoint is not installed or activated', 'bit-integrations-pro'));
        }

        if ($invalid = LatePointHelper::validateClassExistence('booking')) {
            return $invalid;
        }

        if ($invalid = LatePointHelper::requireFields($fieldData, ['booking_id'])) {
            return $invalid;
        }

        $booking = new OsBookingModel((int) $fieldData['booking_id']);

        if (empty($booking->id)) {
            return LatePointHelper::errorResponse(__('Booking not found.', 'bit-integrations-pro'));
        }

        if (!$booking->update_status('cancelled')) {
            return LatePointHelper::errorResponse(__('Booking could not be cancelled.', 'bit-integrations-pro'));
        }

        return LatePointHelper::successResponse(
            __('Booking cancelled successfully', 'bit-integrations-pro'),
            LatePointHelper::prepareData($booking)
        );
    }

    public static function createAgent($defaultResponse, $fieldData, $integrationDetails = null)
    {
        if (!LatePointHelper::isPluginInstalled()) {
            return LatePointHelper::errorResponse(__('LatePoint is not installed or activated', 'bit-integrations-pro'));
        }

        if ($invalid = LatePointHelper::validateClassExistence('agent')) {
            return $invalid;
        }

        if ($invalid = LatePointHelper::requireFields($fieldData, ['first_name', 'last_name', 'email'])) {
            return $invalid;
        }

        $fieldData['email'] = sanitize_email($fieldData['email']);

        if (isset($fieldData['wp_user_id'])) {
            $fieldData['wp_user_id'] = (int) $fieldData['wp_user_id'];
        }

        $agent = new OsAgentModel();
        $agent->set_data($fieldData);

        // bit-pi built the error envelope here but never returned it, so a failed save
        // fell through and reported success. Returning it.
        if (!$agent->save()) {
            return LatePointHelper::modelErrorResponse($agent, __('Agent could not be created.', 'bit-integrations-pro'));
        }

        $serviceIds = LatePointHelper::parseDelimitedValues(
            self::configValue($integrationDetails, 'selectedServices', '')
        );

        if (!empty($serviceIds)) {
            $services = [];

            foreach ($serviceIds as $serviceId) {
                $services['service_' . $serviceId] = ['location_1' => ['connected' => 'yes']];
            }

            if (!$agent->save_locations_and_services($services)) {
                return LatePointHelper::errorResponse(__('Agent services could not be assigned.', 'bit-integrations-pro'));
            }
        }

        return LatePointHelper::successResponse(
            __('Agent created successfully', 'bit-integrations-pro'),
            LatePointHelper::prepareData($agent)
        );
    }

    public static function createCustomer($defaultResponse, $fieldData)
    {
        if (!LatePointHelper::isPluginInstalled()) {
            return LatePointHelper::errorResponse(__('LatePoint is not installed or activated', 'bit-integrations-pro'));
        }

        if ($invalid = LatePointHelper::validateClassExistence('customer')) {
            return $invalid;
        }

        if ($invalid = LatePointHelper::requireFields($fieldData, ['first_name', 'last_name', 'email'])) {
            return $invalid;
        }

        $fieldData['email'] = sanitize_email($fieldData['email']);

        $customer = new OsCustomerModel();
        $customer->set_data($fieldData);

        if (!$customer->save()) {
            return LatePointHelper::modelErrorResponse($customer, __('Customer could not be created.', 'bit-integrations-pro'));
        }

        return LatePointHelper::successResponse(
            __('Customer created successfully', 'bit-integrations-pro'),
            LatePointHelper::prepareData($customer)
        );
    }

    public static function createOrder($defaultResponse, $fieldData, $utilities = null, $integrationDetails = null)
    {
        if (!LatePointHelper::isPluginInstalled()) {
            return LatePointHelper::errorResponse(__('LatePoint is not installed or activated', 'bit-integrations-pro'));
        }

        if ($invalid = LatePointHelper::validateClassExistence(['bundle', 'customer', 'order', 'order_item'])) {
            return $invalid;
        }

        $bundleId = (int) self::configValue($integrationDetails, 'selectedBundle', 0);

        if (empty($bundleId)) {
            return LatePointHelper::errorResponse(__('Bundle is required', 'bit-integrations-pro'));
        }

        $bundle = new OsBundleModel($bundleId);

        if (empty($bundle->id)) {
            return LatePointHelper::errorResponse(__('Invalid bundle ID.', 'bit-integrations-pro'));
        }

        $customer = self::resolveCustomer($fieldData, $integrationDetails);

        if (LatePointHelper::isError($customer)) {
            return $customer;
        }

        $order = new OsOrderModel();
        $order->status = self::utilityValue($utilities, 'selected_order_status', 'open');
        $order->fulfillment_status = self::utilityValue($utilities, 'selected_fulfillment_status', $order->get_default_fulfillment_status());
        $order->payment_status = self::utilityValue($utilities, 'selected_payment_status', 'not_paid');
        $order->customer_id = $customer->id;

        if (!$order->save()) {
            return LatePointHelper::modelErrorResponse($order, __('Order could not be created.', 'bit-integrations-pro'));
        }

        $orderItem = new OsOrderItemModel();
        $orderItem->variant = \defined('LATEPOINT_ITEM_VARIANT_BUNDLE') ? LATEPOINT_ITEM_VARIANT_BUNDLE : 'bundle';
        $orderItem->order_id = $order->id;

        if (!$orderItem->save()) {
            return LatePointHelper::modelErrorResponse($orderItem, __('Bundle item could not be created.', 'bit-integrations-pro'));
        }

        $orderItem->item_data = wp_json_encode(['bundle_id' => $bundle->id]);
        $orderItem->recalculate_prices();
        $order->total = $orderItem->total;
        $order->subtotal = $orderItem->subtotal;
        $order->save();
        $orderItem->save();

        return LatePointHelper::successResponse(
            __('Order created successfully', 'bit-integrations-pro'),
            [
                'bundle' => LatePointHelper::prepareData($bundle),
                'order'  => LatePointHelper::prepareData($order),
            ]
        );
    }

    public static function createCoupon($defaultResponse, $fieldData, $integrationDetails = null)
    {
        if (!LatePointHelper::isPluginInstalled()) {
            return LatePointHelper::errorResponse(__('LatePoint is not installed or activated', 'bit-integrations-pro'));
        }

        if ($invalid = LatePointHelper::validateClassExistence('coupon')) {
            return $invalid;
        }

        if ($invalid = LatePointHelper::requireFields($fieldData, ['code', 'discount_value'])) {
            return $invalid;
        }

        $discountType = self::configValue($integrationDetails, 'discountType', '');

        if (empty($discountType)) {
            return LatePointHelper::errorResponse(__('Discount type is required', 'bit-integrations-pro'));
        }

        $coupon = new OsCouponModel();
        $coupon->set_data(
            self::buildCouponPayload($fieldData, $discountType, self::configValue($integrationDetails, 'couponStatus', ''))
        );

        if (!$coupon->save()) {
            return LatePointHelper::modelErrorResponse($coupon, __('Coupon could not be created.', 'bit-integrations-pro'));
        }

        return LatePointHelper::successResponse(
            __('Coupon created successfully', 'bit-integrations-pro'),
            LatePointHelper::prepareData($coupon)
        );
    }

    public static function updateCoupon($defaultResponse, $fieldData, $integrationDetails = null)
    {
        if (!LatePointHelper::isPluginInstalled()) {
            return LatePointHelper::errorResponse(__('LatePoint is not installed or activated', 'bit-integrations-pro'));
        }

        if ($invalid = LatePointHelper::validateClassExistence('coupon')) {
            return $invalid;
        }

        if ($invalid = LatePointHelper::requireFields($fieldData, ['coupon_id'])) {
            return $invalid;
        }

        $coupon = new OsCouponModel((int) $fieldData['coupon_id']);

        if (empty($coupon->id)) {
            return LatePointHelper::errorResponse(__('Coupon not found.', 'bit-integrations-pro'));
        }

        $discountType = self::configValue($integrationDetails, 'discountType', '');
        $coupon->set_data(
            self::buildCouponPayload(
                $fieldData,
                $discountType,
                self::configValue($integrationDetails, 'couponStatus', ''),
                $coupon
            )
        );

        if (!$coupon->save()) {
            return LatePointHelper::modelErrorResponse($coupon, __('Coupon could not be updated.', 'bit-integrations-pro'));
        }

        return LatePointHelper::successResponse(
            __('Coupon updated successfully', 'bit-integrations-pro'),
            LatePointHelper::prepareData($coupon)
        );
    }

    private static function handleBooking($fieldData, $utilities, $integrationDetails, $isUpdate)
    {
        if (!LatePointHelper::isPluginInstalled()) {
            return LatePointHelper::errorResponse(__('LatePoint is not installed or activated', 'bit-integrations-pro'));
        }

        if ($invalid = LatePointHelper::validateClassExistence(['booking', 'customer', 'order', 'order_item', 'order_helper'])) {
            return $invalid;
        }

        $serviceId = (int) self::configValue($integrationDetails, 'selectedService', 0);

        if (empty($serviceId)) {
            return LatePointHelper::errorResponse(__('Service is required', 'bit-integrations-pro'));
        }

        if ($isUpdate) {
            if ($invalid = LatePointHelper::requireFields($fieldData, ['booking_id'])) {
                return $invalid;
            }
        } else {
            if ($invalid = LatePointHelper::requireFields($fieldData, ['start_date', 'start_time'])) {
                return $invalid;
            }

            if (empty(self::configValue($integrationDetails, 'selectedAgent', 0))) {
                return LatePointHelper::errorResponse(__('Agent is required', 'bit-integrations-pro'));
            }

            if (empty(self::configValue($integrationDetails, 'selectedLocation', 0))) {
                return LatePointHelper::errorResponse(__('Location is required', 'bit-integrations-pro'));
            }
        }

        try {
            if ($isUpdate) {
                $booking = new OsBookingModel((int) $fieldData['booking_id']);

                if (empty($booking->id)) {
                    return LatePointHelper::errorResponse(__('Booking not found.', 'bit-integrations-pro'));
                }

                $oldBooking = clone $booking;
            } else {
                $booking = new OsBookingModel();
            }

            $booking->set_data(self::buildBookingPayload($fieldData, $utilities, $integrationDetails, $isUpdate));

            if (!$isUpdate) {
                $customer = self::resolveCustomer($fieldData, $integrationDetails);

                if (LatePointHelper::isError($customer)) {
                    return $customer;
                }

                $order = self::createOrderForBooking($fieldData, $utilities, $customer);

                if (LatePointHelper::isError($order)) {
                    return $order;
                }

                $orderItem = self::createOrderItem($order);

                if (LatePointHelper::isError($orderItem)) {
                    return $orderItem;
                }

                $booking->customer_id = $order->customer_id;
                $booking->order_item_id = $orderItem->id;
                $booking->set_utc_datetimes();
            }

            if (!$booking->save()) {
                return LatePointHelper::modelErrorResponse(
                    $booking,
                    $isUpdate
                        ? __('Booking could not be updated.', 'bit-integrations-pro')
                        : __('Booking could not be created.', 'bit-integrations-pro')
                );
            }

            $data = LatePointHelper::prepareData($booking);

            if ($isUpdate) {
                return LatePointHelper::successResponse(__('Booking updated successfully', 'bit-integrations-pro'), $data);
            }

            $orderItem->item_data = $booking->generate_item_data();
            $orderItem->recalculate_prices();
            $order->total = $orderItem->total;
            $order->subtotal = $orderItem->subtotal;
            $order->save();
            $orderItem->save();

            $data['order'] = LatePointHelper::prepareData($order);

            return LatePointHelper::successResponse(__('Booking created successfully', 'bit-integrations-pro'), $data);
        } catch (Exception $e) {
            return LatePointHelper::errorResponse($e->getMessage());
        }
    }

    /**
     * Find an existing customer by email, or create one from the mapped customer fields.
     *
     * @param array       $fieldData
     * @param null|object $integrationDetails
     *
     * @return array|OsCustomerModel Error envelope, or the resolved customer
     */
    private static function resolveCustomer($fieldData, $integrationDetails)
    {
        if (self::configValue($integrationDetails, 'customerType', 'new') === 'existing') {
            $customerId = (int) ($fieldData['customer_id'] ?? 0);

            if (empty($customerId)) {
                return LatePointHelper::errorResponse(__('Customer ID is required for existing customers.', 'bit-integrations-pro'));
            }

            $customer = new OsCustomerModel($customerId);

            if (empty($customer->id)) {
                return LatePointHelper::errorResponse(__('Customer not found.', 'bit-integrations-pro'));
            }

            return $customer;
        }

        if ($invalid = LatePointHelper::requireFields($fieldData, ['customer_first_name', 'customer_last_name', 'customer_email'])) {
            return $invalid;
        }

        $email = sanitize_email($fieldData['customer_email']);

        $customer = new OsCustomerModel();
        $existing = $customer->where(['email' => $email])->set_limit(1)->get_results_as_models();

        // get_results_as_models() returns a single model in some LatePoint versions and
        // a collection in others; normalise before reading ->id, otherwise an existing
        // customer is missed and a duplicate record is created for the same address.
        if (\is_array($existing)) {
            $existing = reset($existing);
        }

        if (\is_object($existing) && !empty($existing->id)) {
            return new OsCustomerModel($existing->id);
        }

        $customer->set_data(
            [
                'first_name' => $fieldData['customer_first_name'] ?? '',
                'last_name'  => $fieldData['customer_last_name'] ?? '',
                'email'      => $email,
                'phone'      => $fieldData['customer_phone'] ?? '',
                'notes'      => $fieldData['customer_notes'] ?? '',
            ]
        );

        if (!$customer->save()) {
            return LatePointHelper::modelErrorResponse($customer, __('Customer could not be saved.', 'bit-integrations-pro'));
        }

        return $customer;
    }

    private static function buildBookingPayload($fieldData, $utilities, $integrationDetails, $isUpdate)
    {
        $agentId = (int) self::configValue($integrationDetails, 'selectedAgent', 0);
        $serviceId = (int) self::configValue($integrationDetails, 'selectedService', 0);
        $locationId = (int) self::configValue($integrationDetails, 'selectedLocation', 0);
        $startDate = $fieldData['start_date'] ?? '';
        $status = self::utilityValue($utilities, 'selected_booking_status', '');
        $paymentStatus = self::utilityValue($utilities, 'selected_payment_status', '');

        if (!$isUpdate) {
            return [
                'agent_id'         => $agentId,
                'service_id'       => $serviceId,
                'location_id'      => $locationId ?: null,
                'buffer_before'    => (int) ($fieldData['buffer_before'] ?? 0),
                'buffer_after'     => (int) ($fieldData['buffer_after'] ?? 0),
                'total_attendees'  => (int) ($fieldData['total_attendees'] ?? 1),
                'status'           => $status,
                'payment_status'   => $paymentStatus !== '' ? $paymentStatus : 'not_paid',
                'start_date'       => $startDate ? gmdate('Y-m-d', strtotime($startDate)) : '',
                'start_time'       => LatePointHelper::convertTimeToMinutes($fieldData['start_time'] ?? null),
                'end_time'         => LatePointHelper::convertTimeToMinutes($fieldData['end_time'] ?? null),
                'source_url'       => get_site_url(),
            ];
        }

        // On update, include a key only when the flow actually supplied it, so an
        // unmapped input never overwrites a stored value. Built by explicit opt-in
        // rather than filtering a full payload, because a filter cannot tell an
        // intentional 0 (clear the buffer) from an absent value.
        $payload = [];

        if ($agentId) {
            $payload['agent_id'] = $agentId;
        }

        if ($serviceId) {
            $payload['service_id'] = $serviceId;
        }

        if ($locationId) {
            $payload['location_id'] = $locationId;
        }

        if ($status !== '') {
            $payload['status'] = $status;
        }

        if ($paymentStatus !== '') {
            $payload['payment_status'] = $paymentStatus;
        }

        if ($startDate !== '') {
            $payload['start_date'] = gmdate('Y-m-d', strtotime($startDate));
        }

        // Numeric fields keep a supplied 0 — clearing a buffer is a valid update.
        foreach (['buffer_before', 'buffer_after', 'total_attendees'] as $key) {
            if (isset($fieldData[$key]) && $fieldData[$key] !== '') {
                $payload[$key] = (int) $fieldData[$key];
            }
        }

        foreach (['start_time', 'end_time'] as $key) {
            $minutes = LatePointHelper::convertTimeToMinutes($fieldData[$key] ?? null);

            if ($minutes !== null) {
                $payload[$key] = $minutes;
            }
        }

        return $payload;
    }

    private static function createOrderForBooking($fieldData, $utilities, $customer)
    {
        $order = new OsOrderModel();

        $order->status = self::utilityValue($utilities, 'selected_order_status', OsOrdersHelper::get_default_order_status());
        $order->fulfillment_status = self::utilityValue($utilities, 'selected_fulfillment_status', $order->get_default_fulfillment_status());
        $order->payment_status = self::utilityValue($utilities, 'selected_payment_status', 'not_paid');
        $order->customer_comment = $fieldData['customer_comment'] ?? '';
        $order->customer_id = $customer->id;

        if (!$order->save()) {
            return LatePointHelper::modelErrorResponse($order, __('Order could not be created.', 'bit-integrations-pro'));
        }

        return $order;
    }

    private static function createOrderItem($order)
    {
        $orderItem = new OsOrderItemModel();

        $orderItem->variant = 'booking';
        $orderItem->order_id = $order->id;

        if (!$orderItem->save()) {
            return LatePointHelper::modelErrorResponse($orderItem, __('Order item could not be created.', 'bit-integrations-pro'));
        }

        return $orderItem;
    }

    /**
     * @param array              $fieldData
     * @param string             $discountType
     * @param string             $status
     * @param null|OsCouponModel $coupon       Existing coupon on update, so unmapped rules survive
     *
     * @return array
     */
    private static function buildCouponPayload($fieldData, $discountType, $status = '', $coupon = null)
    {
        $rule = function ($key) use ($coupon) {
            return $coupon && method_exists($coupon, 'get_rule') ? $coupon->get_rule($key) : '';
        };

        return [
            'code'           => $fieldData['code'] ?? ($coupon->code ?? ''),
            'name'           => $fieldData['name'] ?? ($coupon->name ?? ''),
            'discount_value' => $fieldData['discount_value'] ?? ($coupon->discount_value ?? ''),
            'discount_type'  => $discountType ?: ($coupon->discount_type ?? ''),
            'status'         => $status ?: ($coupon->status ?? ''),
            'rules'          => wp_json_encode(
                [
                    'limit_per_customer' => $fieldData['limit_per_customer'] ?? $rule('limit_per_customer'),
                    'limit_total'        => $fieldData['limit_total'] ?? $rule('limit_total'),
                    'orders_more'        => $fieldData['orders_more'] ?? $rule('orders_more'),
                    'orders_less'        => $fieldData['orders_less'] ?? $rule('orders_less'),
                    'agent_ids'          => LatePointHelper::parseDelimitedValues($fieldData['agent_ids'] ?? $rule('agent_ids')),
                    'customer_ids'       => LatePointHelper::parseDelimitedValues($fieldData['customer_ids'] ?? $rule('customer_ids')),
                    'service_ids'        => LatePointHelper::parseDelimitedValues($fieldData['service_ids'] ?? $rule('service_ids')),
                ]
            ),
        ];
    }

    /**
     * Read a flow configuration value set by a dropdown in the integration layout.
     *
     * @param null|object $integrationDetails
     * @param string      $key
     * @param mixed       $default
     *
     * @return mixed
     */
    private static function configValue($integrationDetails, $key, $default = '')
    {
        return isset($integrationDetails->{$key}) && $integrationDetails->{$key} !== ''
            ? $integrationDetails->{$key}
            : $default;
    }

    /**
     * Read an optional value set by a Utilities checkbox.
     *
     * @param null|object $utilities
     * @param string      $key
     * @param mixed       $default
     *
     * @return mixed
     */
    private static function utilityValue($utilities, $key, $default = '')
    {
        return isset($utilities->{$key}) && $utilities->{$key} !== ''
            ? $utilities->{$key}
            : $default;
    }
}
