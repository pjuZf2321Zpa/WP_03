<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Actions\FluentCRM\FluentCRMProHelper;
use BitApps\IntegrationsPro\Config;
use BitApps\IntegrationsPro\Core\Util\Hooks;

// Deprecated since v2.7.8 - use bit_integrations_fluent_crm_* hooks instead
if (bit_integrations_version_below('2.7.8')) {
    Hooks::filter('btcbi_fluent_crm_assign_company', [FluentCRMProHelper::class, 'assignCompany'], 10, 2);
}

// New hooks since v2.7.8
Hooks::filter(Config::withFreePrefix('fluent_crm_assign_company'), [FluentCRMProHelper::class, 'assignCompany'], 10, 2);
