<?php

namespace BitApps\IntegrationsPro\Actions\FollowUpBoss\Services;

final class EmailMarketingService extends BaseService
{
    public function logEmailMarketingEvent(): array
    {
        $validationRules = [
            'event_type' => ['required'],
            'recipient'  => ['required', 'email'],
        ];
        $error = $this->validateFields(
            $validationRules,
            [
                'event_type' => __('Event Type', 'bit-integrations-pro'),
                'recipient'  => __('Recipient Email', 'bit-integrations-pro'),
            ],
            ['event_type']
        );

        if ($error !== null) {
            return $error;
        }

        $payload = [
            'emEvents' => [
                $this->removeEmptyValues(
                    [
                        'type'       => $this->getString('event_type'),
                        'recipient'  => $this->getString('recipient'),
                        'occurred'   => $this->getString('occurred'),
                        'personId'   => $this->getInteger('person_id'),
                        'campaignId' => $this->getInteger('campaign_id'),
                        'userId'     => $this->getInteger('user_id'),
                        'url'        => $this->getString('url'),
                    ]
                ),
            ],
        ];

        return $this->dispatch('POST', '/emEvents', $payload);
    }

    public function createEmailCampaign(): array
    {
        $validationRules = ['name' => ['required']];
        $error = $this->validateFields(
            $validationRules,
            [
                'name' => __('Campaign Name', 'bit-integrations-pro'),
            ]
        );

        if ($error !== null) {
            return $error;
        }

        $payload = $this->removeEmptyValues(
            [
                'origin'   => $this->getString('origin'),
                'originId' => $this->getString('origin_id'),
                'name'     => $this->getString('name'),
                'subject'  => $this->getString('subject'),
                'bodyHtml' => $this->getString('body_html'),
            ]
        );

        return $this->dispatch('POST', '/emCampaigns', $payload);
    }

    public function updateEmailCampaign(): array
    {
        $validationRules = ['campaign_id' => ['required', 'integer']];
        $error = $this->validateFields(
            $validationRules,
            [
                'campaign_id' => __('Email Campaign ID', 'bit-integrations-pro'),
            ]
        );

        if ($error !== null) {
            return $error;
        }

        $payload = $this->removeEmptyValues(
            [
                'name'     => $this->getString('name'),
                'subject'  => $this->getString('subject'),
                'bodyHtml' => $this->getString('body_html'),
            ]
        );

        return $this->dispatch('PUT', '/emCampaigns/' . rawurlencode($this->getString('campaign_id')), $payload);
    }
}
