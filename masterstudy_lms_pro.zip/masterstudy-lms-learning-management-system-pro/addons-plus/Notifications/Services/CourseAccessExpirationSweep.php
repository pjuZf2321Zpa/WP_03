<?php

namespace MasterStudy\Lms\Pro\AddonsPlus\Notifications\Services;

use MasterStudy\Lms\Pro\AddonsPlus\Notifications\Events;
use MasterStudy\Lms\Pro\AddonsPlus\Notifications\Repositories\NotificationRepository;

final class CourseAccessExpirationSweep {
	private const CURSOR_OPTION = 'masterstudy_notifications_course_access_sweep_cursor';
	private const BATCH_SIZE    = 200;
	private const MAX_BATCHES   = 5;

	public static function ensure_scheduled(): void {
		if ( wp_next_scheduled( 'masterstudy_notifications_course_access_expiration_sweep' ) ) {
			return;
		}

		wp_schedule_event( time() + HOUR_IN_SECONDS, 'hourly', 'masterstudy_notifications_course_access_expiration_sweep' );
	}

	public static function process(): void {
		try {
			if ( ! self::is_available() || ! function_exists( 'stm_lms_user_courses_name' ) || ! class_exists( 'STM_LMS_Course' ) ) {
				return;
			}

			$dispatcher = new Dispatcher();

			if (
				! $dispatcher->is_channel_enabled( 'course_access_expired', Events::CHANNEL_ON_SITE )
				&& ! $dispatcher->is_channel_enabled( 'course_access_expired', Events::CHANNEL_PUSH )
			) {
				return;
			}

			$repository = new NotificationRepository();
			$cursor     = absint( get_option( self::CURSOR_OPTION, 0 ) );
			$last_seen  = $cursor;
			$processed  = 0;

			for ( $batch = 0; $batch < self::MAX_BATCHES; $batch++ ) {
				$rows = self::next_rows( $last_seen );

				if ( empty( $rows ) ) {
					update_option( self::CURSOR_OPTION, 0, false );
					return;
				}

				$batch_context = self::prepare_batch_context( $rows, $repository );

				foreach ( $rows as $row ) {
					$last_seen = max( $last_seen, absint( $row['user_course_id'] ?? 0 ) );

					try {
						self::maybe_dispatch_row( $row, $dispatcher, $batch_context );
					} catch ( \Throwable $row_error ) {
						// Continue sweep; row-level failures should not stop the batch.
						unset( $row_error );
					}

					++$processed;
				}

				if ( count( $rows ) < self::BATCH_SIZE ) {
					update_option( self::CURSOR_OPTION, 0, false );
					return;
				}
			}

			if ( $processed > 0 ) {
				update_option( self::CURSOR_OPTION, $last_seen, false );
			}
		} catch ( \Throwable $error ) {
			return;
		}
	}

	private static function next_rows( int $cursor ): array {
		global $wpdb;

		$table = stm_lms_user_courses_name( $wpdb );

		return $wpdb->get_results(
			$wpdb->prepare(
				// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				"SELECT user_course_id, user_id, course_id, start_time FROM {$table} WHERE user_course_id > %d ORDER BY user_course_id ASC LIMIT %d",
				$cursor,
				self::BATCH_SIZE
			),
			ARRAY_A
		);
	}

	private static function prepare_batch_context( array $rows, NotificationRepository $repository ): array {
		$course_ids  = array();
		$dedupe_keys = array();
		$courses     = array();

		foreach ( $rows as $row ) {
			$course_id = absint( $row['course_id'] ?? 0 );

			if ( $course_id > 0 ) {
				$course_ids[] = $course_id;
			}
		}

		foreach ( self::sanitize_ids( $course_ids ) as $course_id ) {
			$courses[ $course_id ] = array(
				'duration' => (int) \STM_LMS_Course::get_course_duration_time( $course_id ),
				'title'    => get_the_title( $course_id ),
			);
		}

		foreach ( $rows as $row ) {
			$user_id    = absint( $row['user_id'] ?? 0 );
			$course_id  = absint( $row['course_id'] ?? 0 );
			$start_time = absint( $row['start_time'] ?? 0 );
			$duration   = absint( $courses[ $course_id ]['duration'] ?? 0 );

			if ( $user_id <= 0 || $course_id <= 0 || $start_time <= 0 || $duration <= 0 ) {
				continue;
			}

			$expires_at = $start_time + $duration;

			if ( time() >= $expires_at ) {
				$dedupe_keys[] = self::dedupe_key( $user_id, $course_id, $expires_at );
			}
		}

		return array(
			'courses'              => $courses,
			'existing_dedupe_keys' => array_fill_keys( $repository->find_existing_dedupe_keys( $dedupe_keys ), true ),
		);
	}

	private static function maybe_dispatch_row( array $row, Dispatcher $dispatcher, array $batch_context ): void {
		$user_id    = absint( $row['user_id'] ?? 0 );
		$course_id  = absint( $row['course_id'] ?? 0 );
		$start_time = absint( $row['start_time'] ?? 0 );

		if ( $user_id <= 0 || $course_id <= 0 || $start_time <= 0 ) {
			return;
		}

		$course   = $batch_context['courses'][ $course_id ] ?? array();
		$duration = absint( $course['duration'] ?? 0 );

		if ( $duration <= 0 ) {
			return;
		}

		$expires_at = $start_time + $duration;

		if ( time() < $expires_at ) {
			return;
		}

		$dedupe_key = self::dedupe_key( $user_id, $course_id, $expires_at );

		if ( ! empty( $batch_context['existing_dedupe_keys'][ $dedupe_key ] ) ) {
			return;
		}

		$dispatcher->dispatch(
			'course_access_expired',
			array( $user_id ),
			self::course_context( $course_id, $expires_at, (string) ( $course['title'] ?? '' ) ),
			$dedupe_key
		);
	}

	private static function course_context( int $course_id, int $expires_at, string $course_title = '' ): array {
		if ( '' === $course_title ) {
			$course_title = get_the_title( $course_id );
		}

		return array(
			'course_id'        => $course_id,
			'course_name'      => $course_title,
			'context_label'    => $course_title,
			'target_timestamp' => $expires_at,
		);
	}

	private static function dedupe_key( int $user_id, int $course_id, int $expires_at ): string {
		return "course_access_expired:{$user_id}:{$course_id}:{$expires_at}";
	}

	private static function sanitize_ids( array $ids ): array {
		return array_values( array_unique( array_filter( array_map( 'absint', $ids ) ) ) );
	}

	private static function is_available(): bool {
		return function_exists( 'masterstudy_lms_is_notifications_addon_available' )
			&& masterstudy_lms_is_notifications_addon_available();
	}
}
