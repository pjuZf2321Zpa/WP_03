<?php

namespace BitApps\IntegrationsPro\Core\Update;

use BitApps\IntegrationsPro\Config;
use BitApps\IntegrationsPro\Core\Util\DateTimeHelper;
use BitApps\IntegrationsPro\Core\Util\HttpHelper;
use WP_Error;

final class API
{
    public static function getAPiEndPoint()
    {
        return 'https://wp-api.bitapps.pro';
    }

    public static function getUpdatedInfo()
    {
        $licenseKey = self::getKey();
        $pluginInfoResponse = HttpHelper::get(self::getAPiEndPoint() . '/update/bit-integrations-pro', null, ['licKey' => $licenseKey, 'domain' => site_url()]);
        if (is_wp_error($pluginInfoResponse)) {
            return $pluginInfoResponse;
        }
        if (!empty($pluginInfoResponse->status) && $pluginInfoResponse->status == 'expired') {
            self::removeKeyData();

            return new WP_Error('API_ERROR', $pluginInfoResponse->message);
        }
        if (empty($pluginInfoResponse->data)) {
            return new WP_Error('API_ERROR', $pluginInfoResponse->message);
        }
        $pluginData = $pluginInfoResponse->data;
        $dateTimeHelper = new DateTimeHelper();
        $pluginData->updatedAt = $dateTimeHelper->getFormated($pluginData->updatedAt, 'Y-m-d\TH:i:s.u\Z', DateTimeHelper::wp_timezone(), 'Y-m-d H:i:s', null);
        if (!empty($pluginData->details)) {
            $pluginData->sections['description'] = $pluginData->details;
        } else {
            $pluginData->sections['description'] = '';
        }
        if (!empty($pluginData->changelog)) {
            $pluginData->sections['changelog'] = $pluginData->changelog;
        } else {
            $pluginData->sections['changelog'] = '';
        }
        if ($licenseKey) {
            $pluginData->downloadLink = self::getAPiEndPoint() . '/download/' . $licenseKey;
        } else {
            $pluginData->downloadLink = '';
        }

        return $pluginData;
    }

    public static function activateLicense($licenseKey)
    {
        $activateResponse = self::requestActivation($licenseKey);

        if (!is_wp_error($activateResponse) && $activateResponse->status === 'success') {
            self::setKeyData($licenseKey, $activateResponse);

            return true;
        }

        return empty($activateResponse->message) ? __('Unknown error occurred', 'bit-integrations-pro') : $activateResponse->message;
    }

    public static function disconnectLicense()
    {
        $integrateData = self::getIntegrateData();

        if (!empty($integrateData) && \is_array($integrateData) && $integrateData['status'] === 'success') {
            $deactivateResponse = self::requestDeactivation($integrateData['key']);

            if (self::isSuccessResponse($deactivateResponse) || (\is_object($deactivateResponse) && \in_array($deactivateResponse->code ?? '', ['INVALID_LICENSE', 'INVALID_VALUE', 'INACTIVE_LICENSE', 'FIELD_MISSING']))) {
                self::removeKeyData();

                return true;
            }

            return self::responseMessage($deactivateResponse);
        }

        return __('License data is missing', 'bit-integrations-pro');
    }

    public static function reconnectLicense()
    {
        $licenseKey = self::getKey();

        if (!$licenseKey) {
            return __('License data is missing', 'bit-integrations-pro');
        }

        $activateResponse = self::requestActivation($licenseKey);

        if (self::isSuccessResponse($activateResponse)) {
            self::setKeyData($licenseKey, $activateResponse);

            return true;
        }

        if (!\is_object($activateResponse) || ($activateResponse->code ?? '') !== 'EXCEEDED_LICENSE') {
            return self::responseMessage($activateResponse);
        }

        if (!self::isSuccessResponse(self::requestDeactivation($licenseKey))) {
            return self::responseMessage($activateResponse);
        }

        $activateResponse = self::requestActivation($licenseKey);

        if (self::isSuccessResponse($activateResponse)) {
            self::setKeyData($licenseKey, $activateResponse);

            return true;
        }

        self::removeKeyData();

        return self::responseMessage($activateResponse);
    }

    public static function setKeyData($licenseKey, $licData)
    {
        $data['key'] = $licenseKey;
        $data['status'] = $licData->status;
        $data['expireIn'] = $licData->expireIn ?? '';

        return Config::updateOption('integrate_key_data', $data);
    }

    public static function getKey()
    {
        $integrateData = self::getIntegrateData();

        $licenseKey = false;
        if (!empty($integrateData) && \is_array($integrateData) && $integrateData['status'] === 'success') {
            $licenseKey = $integrateData['key'];
        }

        return $licenseKey;
    }

    public static function removeKeyData()
    {
        if (get_option('btcbi_integrate_key_data') !== false) {
            return delete_option('btcbi_integrate_key_data');
        }

        return Config::deleteOption('integrate_key_data');
    }

    public static function isLicenseActive()
    {
        $integrateData = self::getIntegrateData();

        return (bool) (!empty($integrateData) && \is_array($integrateData) && $integrateData['status'] === 'success');
    }

    public static function getIntegrateData()
    {
        return Config::getOption('integrate_key_data', Config::getOption('btcbi_integrate_key_data', false, true));
    }

    private static function requestActivation($licenseKey)
    {
        $data['licenseKey'] = $licenseKey;
        $data['domain'] = site_url();
        $data['slug'] = 'bit-integrations-pro';

        return HttpHelper::post(self::getAPiEndPoint() . '/activate', json_encode($data), ['content-type' => 'application/json']);
    }

    private static function requestDeactivation($licenseKey)
    {
        $data['licenseKey'] = $licenseKey;
        $data['domain'] = site_url();

        return HttpHelper::post(self::getAPiEndPoint() . '/deactivate', json_encode($data), ['content-type' => 'application/json']);
    }

    private static function isSuccessResponse($response)
    {
        return \is_object($response) && !is_wp_error($response) && ($response->status ?? '') === 'success';
    }

    private static function responseMessage($response)
    {
        if (is_wp_error($response)) {
            return $response->get_error_message();
        }

        return \is_object($response) && !empty($response->message) ? $response->message : __('Unknown error occurred', 'bit-integrations-pro');
    }
}
