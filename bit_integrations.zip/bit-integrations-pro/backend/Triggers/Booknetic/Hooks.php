<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Core\Util\Hooks;
use BitApps\IntegrationsPro\Triggers\Booknetic\BookneticController;

Hooks::add('bkntc_appointment_created', [BookneticController::class, 'handleAppointmentCreated'], 20, 1);
Hooks::add('bkntc_appointment_after_edit', [BookneticController::class, 'handleAppointmentUpdated'], 20, 1);
Hooks::add('bkntc_appointment_deleted', [BookneticController::class, 'handleAppointmentDeleted'], 20, 1);
Hooks::add('bkntc_appointment_before_mutation', [BookneticController::class, 'captureAppointmentBeforeMutation'], 20, 1);
Hooks::add('bkntc_appointment_after_mutation', [BookneticController::class, 'handleAppointmentMutation'], 20, 1);
Hooks::add('bkntc_customer_created', [BookneticController::class, 'handleCustomerCreated'], 20, 1);
Hooks::add('bkntc_customer_before_edit', [BookneticController::class, 'captureCustomerBeforeEdit'], 20, 1);
Hooks::add('bkntc_customer_saved', [BookneticController::class, 'handleCustomerSaved'], 20, 1);
Hooks::add('bkntc_customer_deleted', [BookneticController::class, 'handleCustomerDeleted'], 20, 1);
Hooks::add('bkntc_staff_created', [BookneticController::class, 'handleStaffCreated'], 20, 1);
Hooks::add('bkntc_after_request_staff_save_staff', [BookneticController::class, 'handleStaffUpdated'], 20, 1);
