<?php
/**
 * Paid provider field definitions for the shared Chatbot model renderer.
 */
if (!defined('ABSPATH')) {
    exit;
}

if (!class_exists('\WPAICG\aipkit_dashboard') || !\WPAICG\aipkit_dashboard::is_pro_plan()) {
    return [];
}

return [
    ['provider' => 'Ollama', 'slug' => 'ollama'],
];
