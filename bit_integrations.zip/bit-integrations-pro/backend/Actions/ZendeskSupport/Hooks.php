<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Actions\ZendeskSupport\ZendeskSupportRecordHelper;
use BitApps\IntegrationsPro\Config;
use BitApps\IntegrationsPro\Core\Util\Hooks;

Hooks::filter(Config::withFreePrefix('zendesk_support_create_ticket'), [ZendeskSupportRecordHelper::class, 'createTicket'], 10, 4);
Hooks::filter(Config::withFreePrefix('zendesk_support_update_ticket'), [ZendeskSupportRecordHelper::class, 'updateTicket'], 10, 4);
Hooks::filter(Config::withFreePrefix('zendesk_support_delete_ticket'), [ZendeskSupportRecordHelper::class, 'deleteTicket'], 10, 4);
Hooks::filter(Config::withFreePrefix('zendesk_support_add_ticket_comment'), [ZendeskSupportRecordHelper::class, 'addTicketComment'], 10, 4);
Hooks::filter(Config::withFreePrefix('zendesk_support_add_tags_to_ticket'), [ZendeskSupportRecordHelper::class, 'addTagsToTicket'], 10, 4);
Hooks::filter(Config::withFreePrefix('zendesk_support_remove_tags_from_ticket'), [ZendeskSupportRecordHelper::class, 'removeTagsFromTicket'], 10, 4);
Hooks::filter(Config::withFreePrefix('zendesk_support_create_user'), [ZendeskSupportRecordHelper::class, 'createUser'], 10, 4);
Hooks::filter(Config::withFreePrefix('zendesk_support_update_user'), [ZendeskSupportRecordHelper::class, 'updateUser'], 10, 4);
Hooks::filter(Config::withFreePrefix('zendesk_support_create_or_update_user'), [ZendeskSupportRecordHelper::class, 'createOrUpdateUser'], 10, 4);
Hooks::filter(Config::withFreePrefix('zendesk_support_delete_user'), [ZendeskSupportRecordHelper::class, 'deleteUser'], 10, 4);
Hooks::filter(Config::withFreePrefix('zendesk_support_suspend_user'), [ZendeskSupportRecordHelper::class, 'suspendUser'], 10, 4);
Hooks::filter(Config::withFreePrefix('zendesk_support_create_organization'), [ZendeskSupportRecordHelper::class, 'createOrganization'], 10, 4);
Hooks::filter(Config::withFreePrefix('zendesk_support_update_organization'), [ZendeskSupportRecordHelper::class, 'updateOrganization'], 10, 4);
Hooks::filter(Config::withFreePrefix('zendesk_support_delete_organization'), [ZendeskSupportRecordHelper::class, 'deleteOrganization'], 10, 4);
Hooks::filter(Config::withFreePrefix('zendesk_support_create_group'), [ZendeskSupportRecordHelper::class, 'createGroup'], 10, 4);
Hooks::filter(Config::withFreePrefix('zendesk_support_update_group'), [ZendeskSupportRecordHelper::class, 'updateGroup'], 10, 4);
Hooks::filter(Config::withFreePrefix('zendesk_support_delete_group'), [ZendeskSupportRecordHelper::class, 'deleteGroup'], 10, 4);
