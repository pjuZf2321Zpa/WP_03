<?php

namespace FluentCartPro\App\Modules\DynamicPricing\Http\Controllers;

use FluentCart\App\App;
use FluentCart\App\Http\Controllers\Controller;
use FluentCart\Framework\Http\Request\Request;
use FluentCartPro\App\Http\Requests\CreatePricingRuleRequest;
use FluentCartPro\App\Http\Requests\PricingRuleRequest;
use FluentCartPro\App\Modules\DynamicPricing\Models\AppliedPricingRule;
use FluentCartPro\App\Modules\DynamicPricing\Models\PricingRule;

class PricingRuleController extends Controller
{
    public function index(Request $request)
    {
        // Only the columns the admin table sorts by; an unknown column 500s with the SQL in the body.
        $orderBy = $request->get('sort_by', 'id');
        if (!in_array($orderBy, ['id', 'name', 'status', 'updated_at'], true)) {
            $orderBy = 'id';
        }

        $order = $request->get('sort_type', 'desc');
        $order = is_string($order) && strtolower($order) === 'asc' ? 'asc' : 'desc';

        $search = $request->get('search');

        $rules = PricingRule::query()
            ->orderBy($orderBy, $order)
            ->orderBy('id', $order)
            ->when($activeView = $request->get('active_view'), function ($query) use ($activeView) {
                if ($activeView === 'active') {
                    $query->where('status', 'active');
                } elseif ($activeView === 'inactive') {
                    $query->where('status', 'inactive');
                }
            })
            ->when(is_string($search) && $search !== '', function ($query) use ($search) {
                global $wpdb;
                // Escape % and _ so a typed wildcard doesn't match every rule.
                $like = '%' . $wpdb->esc_like($search) . '%';
                $query->where(function ($query) use ($like) {
                    $query->where('name', 'like', $like)
                        ->orWhere('display_name', 'like', $like);
                });
            })
            ->paginate(min(100, max(1, (int) $request->get('per_page', 15))));

        return [
            'pricing_rules' => $rules
        ];
    }

    public function show(Request $request, $id)
    {
        $rule = PricingRule::query()->find($id);

        if (!$rule) {
            return $this->sendError([
                'message' => __('Pricing rule not found', 'fluent-cart-pro')
            ], 404);
        }

        return [
            'pricing_rule' => $rule
        ];
    }

    public function store(CreatePricingRuleRequest $request)
    {
        $data = $request->getSafe($request->sanitize());

        // Only an explicit "active" goes live on create; anything else is left
        // to the model's inactive default.
        if ($request->get('status') === 'active') {
            $data['status'] = 'active';
        }

        $rule = PricingRule::create($data);

        if (!$rule) {
            return $this->sendError([
                'message' => __('Failed to create pricing rule', 'fluent-cart-pro')
            ], 400);
        }

        return [
            'message'      => __('Pricing rule created successfully', 'fluent-cart-pro'),
            'pricing_rule' => $rule
        ];
    }

    public function update(PricingRuleRequest $request, $id)
    {
        $data = $request->sentData();

        $rule = PricingRule::query()->find($id);

        if (!$rule) {
            return $this->sendError([
                'message' => __('Pricing rule not found', 'fluent-cart-pro')
            ], 404);
        }

        $isUpdated = $rule->update($data);

        if (!$isUpdated) {
            return $this->sendError([
                'message' => __('Failed to update pricing rule', 'fluent-cart-pro')
            ], 400);
        }

        // Returned so the editor can re-seed from what was actually stored:
        // invalid or half-filled conditions are dropped during sanitization,
        // and without this the admin keeps seeing rows that were never saved.
        return [
            'message'      => __('Pricing rule updated successfully', 'fluent-cart-pro'),
            'pricing_rule' => $rule
        ];
    }

    public function updateStatus(Request $request, $id)
    {
        $status = $request->get('status');

        if (!in_array($status, ['active', 'inactive'], true)) {
            return $this->sendError([
                'message' => __('Status must be either active or inactive', 'fluent-cart-pro')
            ], 400);
        }

        $rule = PricingRule::query()->find($id);

        if (!$rule) {
            return $this->sendError([
                'message' => __('Pricing rule not found', 'fluent-cart-pro')
            ], 404);
        }

        $rule->status = $status;
        $rule->save();

        return [
            'message' => __('Status updated successfully', 'fluent-cart-pro')
        ];
    }

    public function delete(Request $request, $id)
    {
        if (!PricingRule::query()->find($id)) {
            return $this->sendError([
                'message' => __('Pricing rule not found', 'fluent-cart-pro')
            ], 404);
        }

        $db = App::db();

        try {
            $db->beginTransaction();

            /*
             * Applied rows are the audit trail: one per order this rule ever
             * touched. They are kept after the rule is deleted, because an old
             * order still has to show what the customer was charged — the name
             * and amount are stored on the row itself, not read back from here.
             *
             * Only the rule_id link has to go. Leaving it would point at an id
             * that no longer exists, and the column means the opposite: the
             * schema defines it as "null when the originating rule has since
             * been deleted". Nulling it is what records that.
             *
             * Both writes share one transaction so the table can never end up
             * half-updated, whichever of the two fails.
             */
            AppliedPricingRule::query()
                ->where('rule_id', $id)
                ->update(['rule_id' => null]);

            $isDeleted = PricingRule::query()->where('id', $id)->delete();

            if (!$isDeleted) {
                $db->rollBack();

                return $this->sendError([
                    'message' => __('Failed to delete pricing rule', 'fluent-cart-pro')
                ], 400);
            }

            $db->commit();

            PricingRule::clearRulesCache();
        } catch (\Exception $exception) {
            $db->rollBack();

            return $this->sendError([
                'message' => __('Failed to delete pricing rule', 'fluent-cart-pro')
            ], 400);
        }

        return [
            'message' => __('Pricing rule deleted successfully', 'fluent-cart-pro')
        ];
    }
}
