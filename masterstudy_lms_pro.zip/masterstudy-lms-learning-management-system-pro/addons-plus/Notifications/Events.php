<?php

namespace MasterStudy\Lms\Pro\AddonsPlus\Notifications;

final class Events {
	public const KEY_PREFIX          = 'masterstudy_notifications_';
	public const SETTINGS_KEY        = 'masterstudy_notifications_triggers';
	public const ACCOUNT_VIEW_KEY    = 'masterstudy_notifications_account_view';
	public const ACCOUNT_VIEW_POPUP  = 'popup';
	public const ACCOUNT_VIEW_DRAWER = 'drawer';
	public const CHANNEL_ON_SITE     = 'on_site';
	public const CHANNEL_PUSH        = 'push';
	public const DEPENDENCY_ADDONS   = 'dependency_addons';

	public static function groups(): array {
		return array(
			array(
				'key'    => 'student',
				'label'  => esc_html__( 'Student', 'masterstudy-lms-learning-management-system-pro' ),
				'events' => array(
					self::event(
						'course_enrolled',
						esc_html__( 'Course Enrolled', 'masterstudy-lms-learning-management-system-pro' ),
						esc_html__( 'A student has enrolled in a course.', 'masterstudy-lms-learning-management-system-pro' ),
						esc_html__( 'Enrollment confirmed', 'masterstudy-lms-learning-management-system-pro' ),
						esc_html__( 'You\'ve enrolled in a new course.', 'masterstudy-lms-learning-management-system-pro' ),
						'course_single'
					),
					self::event(
						'cancel_enrollment',
						esc_html__( 'Cancel Enrollment', 'masterstudy-lms-learning-management-system-pro' ),
						esc_html__( 'An instructor or admin removed a student from a course.', 'masterstudy-lms-learning-management-system-pro' ),
						esc_html__( 'Enrollment cancelled', 'masterstudy-lms-learning-management-system-pro' ),
						esc_html__( 'Your course enrollment has been cancelled.', 'masterstudy-lms-learning-management-system-pro' ),
						'course_single'
					),
					self::event(
						'assignment_graded',
						esc_html__( 'Assignment graded', 'masterstudy-lms-learning-management-system-pro' ),
						esc_html__( 'An instructor has graded a student\'s submitted assignment.', 'masterstudy-lms-learning-management-system-pro' ),
						esc_html__( 'Assignment graded', 'masterstudy-lms-learning-management-system-pro' ),
						esc_html__( 'Your submission for "{assignment_name}" has been graded.', 'masterstudy-lms-learning-management-system-pro' ),
						'course_player_assignment',
						array(),
						array( 'assignments' )
					),
					self::event(
						'new_announcement_posted',
						esc_html__( 'New Announcement Posted', 'masterstudy-lms-learning-management-system-pro' ),
						esc_html__( 'An instructor has posted a new announcement.', 'masterstudy-lms-learning-management-system-pro' ),
						esc_html__( 'New Announcement Posted', 'masterstudy-lms-learning-management-system-pro' ),
						esc_html__( 'A new course announcement has been posted. Check your email for details.', 'masterstudy-lms-learning-management-system-pro' ),
						'none'
					),
					self::event(
						'qa_message_answered',
						esc_html__( 'Q&A Message Answered', 'masterstudy-lms-learning-management-system-pro' ),
						esc_html__( 'Someone replied to a student\'s Q&A message.', 'masterstudy-lms-learning-management-system-pro' ),
						esc_html__( 'New reply to your question', 'masterstudy-lms-learning-management-system-pro' ),
						esc_html__( 'Your question in "{lesson_name}" has a new reply.', 'masterstudy-lms-learning-management-system-pro' ),
						'course_player_lesson_discussions'
					),
					self::event(
						'instructor_application_rejected',
						esc_html__( 'Instructor Application Rejected', 'masterstudy-lms-learning-management-system-pro' ),
						esc_html__( 'An admin rejected an instructor application.', 'masterstudy-lms-learning-management-system-pro' ),
						esc_html__( 'Instructor application declined', 'masterstudy-lms-learning-management-system-pro' ),
						esc_html__( 'Your instructor application has been declined.', 'masterstudy-lms-learning-management-system-pro' ),
						'none'
					),
					self::event(
						'preordered_course_released',
						esc_html__( 'Pre-ordered Course Released', 'masterstudy-lms-learning-management-system-pro' ),
						esc_html__( 'A pre-ordered course is now available to a student.', 'masterstudy-lms-learning-management-system-pro' ),
						esc_html__( 'Course now available', 'masterstudy-lms-learning-management-system-pro' ),
						esc_html__( 'Your pre-ordered course is now available for study.', 'masterstudy-lms-learning-management-system-pro' ),
						'course_single',
						array(),
						array( 'coming_soon' )
					),
					self::event(
						'assignment_deadline_approaching',
						esc_html__( 'Assignment Deadline Approaching', 'masterstudy-lms-learning-management-system-pro' ),
						esc_html__( 'Sends a reminder about an upcoming assignment deadline 24 hours and 1 hour before it expires.', 'masterstudy-lms-learning-management-system-pro' ),
						esc_html__( 'Deadline approaching', 'masterstudy-lms-learning-management-system-pro' ),
						esc_html__( 'The submission deadline for "{assignment_name}" is in {time_left}.', 'masterstudy-lms-learning-management-system-pro' ),
						'course_player_assignment',
						array( '24 hours', '1 hour' ),
						array( 'assignments' )
					),
					self::event(
						'course_access_expired',
						esc_html__( 'Course Access Expired', 'masterstudy-lms-learning-management-system-pro' ),
						esc_html__( 'A student\'s time-limited course access has run out.', 'masterstudy-lms-learning-management-system-pro' ),
						esc_html__( 'Course access expired', 'masterstudy-lms-learning-management-system-pro' ),
						esc_html__( 'Your course access has ended. Renew to continue learning', 'masterstudy-lms-learning-management-system-pro' ),
						'course_single'
					),
					self::event(
						'meeting_starting_soon',
						esc_html__( 'Meeting Starting Soon', 'masterstudy-lms-learning-management-system-pro' ),
						esc_html__( 'A scheduled Zoom or Google Meet session is about to start', 'masterstudy-lms-learning-management-system-pro' ),
						esc_html__( 'Meeting starting soon', 'masterstudy-lms-learning-management-system-pro' ),
						esc_html__( '"{meeting_name}" starts in {time_left}.', 'masterstudy-lms-learning-management-system-pro' ),
						'course_player_meeting',
						array( '24 hours', '1 hour' ),
						array( 'zoom_conference', 'google_meet' )
					),
					self::event(
						'lesson_now_available',
						esc_html__( 'Lesson Now Available', 'masterstudy-lms-learning-management-system-pro' ),
						esc_html__( 'A scheduled lesson has been unlocked and is ready to study.', 'masterstudy-lms-learning-management-system-pro' ),
						esc_html__( 'Lesson now available', 'masterstudy-lms-learning-management-system-pro' ),
						esc_html__( '"{lesson_name}" is now available to study', 'masterstudy-lms-learning-management-system-pro' ),
						'course_player_lesson',
						array(),
						array( 'sequential_drip_content' )
					),
					self::event(
						'live_lesson_starting_soon',
						esc_html__( 'Live Lesson Starting Soon', 'masterstudy-lms-learning-management-system-pro' ),
						esc_html__( 'A scheduled live stream lesson is about to begin.', 'masterstudy-lms-learning-management-system-pro' ),
						esc_html__( 'Live lesson starting soon', 'masterstudy-lms-learning-management-system-pro' ),
						esc_html__( '"{lesson_name}" goes live in {time_left}.', 'masterstudy-lms-learning-management-system-pro' ),
						'course_player_lesson',
						array( '24 hours', '1 hour' ),
						array( 'live_streams' )
					),
				),
			),
			array(
				'key'    => 'instructor',
				'label'  => esc_html__( 'Instructor', 'masterstudy-lms-learning-management-system-pro' ),
				'events' => array(
					self::event(
						'instructor_application_accepted',
						esc_html__( 'Instructor Application Accepted', 'masterstudy-lms-learning-management-system-pro' ),
						esc_html__( 'An admin approved an instructor application.', 'masterstudy-lms-learning-management-system-pro' ),
						esc_html__( 'Instructor application approved', 'masterstudy-lms-learning-management-system-pro' ),
						esc_html__( 'Your instructor application has been approved. You can now create courses.', 'masterstudy-lms-learning-management-system-pro' ),
						'none'
					),
					self::event(
						'new_assignment_submission',
						esc_html__( 'New Assignment Submission', 'masterstudy-lms-learning-management-system-pro' ),
						esc_html__( 'A student submitted a completed assignment for review.', 'masterstudy-lms-learning-management-system-pro' ),
						esc_html__( 'New assignment submission to review', 'masterstudy-lms-learning-management-system-pro' ),
						esc_html__( 'A new submission for "{assignment_name}" is ready for review.', 'masterstudy-lms-learning-management-system-pro' ),
						'course_assignments_table',
						array(),
						array( 'assignments' )
					),
				),
			),
			array(
				'key'    => 'administrator',
				'label'  => esc_html__( 'Administrator', 'masterstudy-lms-learning-management-system-pro' ),
				'events' => array(
					self::event(
						'instructor_application_received',
						esc_html__( 'Instructor Application Received', 'masterstudy-lms-learning-management-system-pro' ),
						esc_html__( 'When you receive an application from someone wanting to register as an instructor', 'masterstudy-lms-learning-management-system-pro' ),
						esc_html__( 'New instructor application', 'masterstudy-lms-learning-management-system-pro' ),
						esc_html__( 'A new instructor application is waiting for review.', 'masterstudy-lms-learning-management-system-pro' ),
						'admin_instructors'
					),
					self::event(
						'new_enterprise_request',
						esc_html__( 'New Enterprise Request', 'masterstudy-lms-learning-management-system-pro' ),
						esc_html__( 'Someone submitted the "For Enterprise" inquiry form.', 'masterstudy-lms-learning-management-system-pro' ),
						esc_html__( 'New enterprise request', 'masterstudy-lms-learning-management-system-pro' ),
						esc_html__( 'A new enterprise request has been submitted. Check your email for details.', 'masterstudy-lms-learning-management-system-pro' ),
						'none',
						array(),
						array( 'enterprise_courses' )
					),
				),
			),
		);
	}

	public static function available_groups(): array {
		$groups = self::groups();

		if ( ! function_exists( 'masterstudy_lms_notifications_is_trigger_available' ) ) {
			return $groups;
		}

		$available_groups = array();

		foreach ( $groups as $group ) {
			$events = array_values(
				array_filter(
					$group['events'],
					static function ( array $event ): bool {
						return ! empty( $event['key'] ) && masterstudy_lms_notifications_is_trigger_available( (string) $event['key'] );
					}
				)
			);

			if ( empty( $events ) ) {
				continue;
			}

			$group['events']    = $events;
			$available_groups[] = $group;
		}

		return $available_groups;
	}

	public static function default_settings(): array {
		$settings = array();

		foreach ( self::groups() as $group ) {
			foreach ( $group['events'] as $event ) {
				$settings[ $event['key'] ] = array(
					self::CHANNEL_ON_SITE => false,
					self::CHANNEL_PUSH    => false,
				);
			}
		}

		return $settings;
	}

	public static function find( string $event_key ): array {
		foreach ( self::groups() as $group ) {
			foreach ( $group['events'] as $event ) {
				if ( $event_key === $event['key'] ) {
					return $event;
				}
			}
		}

		return array();
	}

	public static function sanitize_settings( $settings ): array {
		if ( ! is_array( $settings ) ) {
			$settings = array();
		}

		$sanitized = self::default_settings();

		foreach ( $sanitized as $event_key => $channels ) {
			$event_settings = isset( $settings[ $event_key ] ) && is_array( $settings[ $event_key ] )
				? $settings[ $event_key ]
				: array();

			$sanitized[ $event_key ] = array(
				self::CHANNEL_ON_SITE => self::sanitize_checkbox_value( $event_settings[ self::CHANNEL_ON_SITE ] ?? false ),
				self::CHANNEL_PUSH    => self::sanitize_checkbox_value( $event_settings[ self::CHANNEL_PUSH ] ?? false ),
			);
		}

		return $sanitized;
	}

	public static function sanitize_account_view( $view ): string {
		$view = is_string( $view ) ? sanitize_key( $view ) : '';

		return in_array( $view, array( self::ACCOUNT_VIEW_POPUP, self::ACCOUNT_VIEW_DRAWER ), true )
			? $view
			: self::ACCOUNT_VIEW_POPUP;
	}

	private static function event(
		string $key,
		string $label,
		string $description,
		string $title,
		string $message,
		string $click_action,
		array $reminders = array(),
		array $dependency_addons = array()
	): array {
		$dependency_addons = array_values(
			array_filter(
				array_map( 'sanitize_key', $dependency_addons )
			)
		);

		return array(
			'key'                   => $key,
			'label'                 => $label,
			'description'           => $description,
			'title'                 => $title,
			'message'               => $message,
			'notification_title'    => $title,
			'notification_message'  => $message,
			'click_action'          => $click_action,
			'reminders'             => $reminders,
			self::DEPENDENCY_ADDONS => $dependency_addons,
		);
	}

	private static function sanitize_checkbox_value( $value ): bool {
		return true === $value || 'true' === $value || '1' === $value || 1 === $value || 'on' === $value;
	}
}
