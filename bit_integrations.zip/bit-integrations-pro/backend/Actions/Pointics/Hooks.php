<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Actions\Pointics\PointicsProHelper;
use BitApps\IntegrationsPro\Config;
use BitApps\IntegrationsPro\Core\Util\Hooks;

// field map only
Hooks::filter(Config::withFreePrefix('pointics_adjust_points'), [PointicsProHelper::class, 'adjustPoints'], 10, 2);
Hooks::filter(Config::withFreePrefix('pointics_cancel_redemption'), [PointicsProHelper::class, 'cancelRedemption'], 10, 2);
Hooks::filter(Config::withFreePrefix('pointics_send_referral_invite'), [PointicsProHelper::class, 'sendReferralInvite'], 10, 2);
Hooks::filter(Config::withFreePrefix('pointics_cancel_referral_invite'), [PointicsProHelper::class, 'cancelReferralInvite'], 10, 2);
Hooks::filter(Config::withFreePrefix('pointics_complete_referral_registration'), [PointicsProHelper::class, 'completeReferralRegistration'], 10, 2);
Hooks::filter(Config::withFreePrefix('pointics_complete_referral_purchase'), [PointicsProHelper::class, 'completeReferralPurchase'], 10, 2);

// field map + config
Hooks::filter(Config::withFreePrefix('pointics_award_channel_points'), [PointicsProHelper::class, 'awardChannelPoints'], 10, 3);

// field map + utilities
Hooks::filter(Config::withFreePrefix('pointics_recompute_member_tier'), [PointicsProHelper::class, 'recomputeMemberTier'], 10, 3);
