<?php

namespace FluentCartPro\App\Modules\SavedPaymentMethods\Checkout;

use FluentCart\Api\CurrencySettings;
use FluentCart\Api\Resource\CustomerResource;
use FluentCart\App\Models\Cart;
use FluentCart\App\Modules\MultiCurrency\Services\CartCurrency;
use FluentCart\App\Modules\MultiCurrency\Services\CurrencyContext;
use FluentCart\Framework\Support\Arr;
use FluentCartPro\App\Modules\SavedPaymentMethods\Gateway\SavedCardGateway;
use FluentCartPro\App\Modules\SavedPaymentMethods\SavedPaymentMethods;
use FluentCartPro\App\Modules\SavedPaymentMethods\SavedPaymentMethodRepository;

/**
 * Renders the saved-card selector at checkout, keeps the Saved Card gateway out
 * of the standard method list (we render our own picker), and persists the
 * chosen card onto the order so the gateway can charge it.
 */
class SavedCardSelector
{
    /**
     * Per-request memo of currentCustomerSavedMethods() — render() and
     * preselectSavedCard() both need it on the same page load.
     *
     * @var array|null
     */
    private $savedMethods = null;

    public function register(): void
    {
        add_action('fluent_cart/before_payment_methods', [$this, 'render']);
        // Before the multi-currency gate (10), while the real gateways are still listed
        add_filter('fluent_cart/checkout_active_payment_methods', [$this, 'hideGatewayFromList'], 5);
        add_filter('fluent_cart/checkout/selected_payment_method', [$this, 'preselectSavedCard'], 10, 2);
        add_action('fluent_cart/checkout/prepare_other_data', [$this, 'persistChosenCard']);
    }

    /**
     * Keep the fct_saved_card gateway from rendering as a generic radio — the
     * per-card picker (render()) is the selection UI.
     */
    public function hideGatewayFromList($methods)
    {
        if (!is_array($methods)) {
            return $methods;
        }

        // Resolve a gateway slug whether the filter carries gateway objects
        // (the rendered picker) or slugs.
        $slugOf = function ($method) {
            if (is_object($method) && method_exists($method, 'getMeta')) {
                return $method->getMeta('route');
            }
            return is_string($method) ? $method : null;
        };

        // Only hide the saved-card gateway from the RENDERED picker — a list that
        // also offers real gateways. Core's place-order availability gate
        // (PaymentHelper) seeds this same filter with JUST the posted gateway; if
        // we stripped it there the legitimately-offered saved card would be
        // rejected as "not available for this order". So keep it when no other
        // gateway is present in the list.
        $hasRealMethod = false;
        foreach ($methods as $method) {
            $slug = $slugOf($method);
            if ($slug && $slug !== SavedCardGateway::SLUG) {
                $hasRealMethod = true;
                break;
            }
        }
        if (!$hasRealMethod) {
            return $methods;
        }

        return array_values(array_filter($methods, function ($method) use ($slugOf) {
            return $slugOf($method) !== SavedCardGateway::SLUG;
        }));
    }

    /**
     * When the saved card is the preselected method, tell core's method list so
     * none of its gateways renders as checked — otherwise that later radio wins
     * the shared `_fct_pay_method` group over the card checked in render().
     */
    public function preselectSavedCard($selected, $context = [])
    {
        if ($this->shouldPreselect(Arr::get($context, 'cart'))) {
            return SavedCardGateway::SLUG;
        }

        return $selected;
    }

    public function render($context = [])
    {
        $cart = Arr::get($context, 'cart');
        $cards = $this->offeredSavedMethods($cart);
        if (empty($cards)) {
            return;
        }

        // Selection and collapse state are decided here, server-side, so the page
        // paints in its final state — no gateway list flashing open, no empty
        // radio filling in, while JS waits for window load.
        $preselect = $this->shouldPreselect($cart);
        $preselectId = $preselect ? $this->defaultCardId($cards) : '';

        echo $this->styles(); // @phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped

        // .is-others-open reveals the standard methods; without it the CSS in
        // styles() hides the sibling methods container until the script makes it a .fct-collapse.
        echo '<div class="fct-saved-cards' . ($preselect ? '' : ' is-others-open') . '" data-fct-saved-cards>';
        echo '<div class="fct-saved-cards-title">' . esc_html__('Your saved payment methods', 'fluent-cart-pro') . '</div>';
        echo '<input type="hidden" name="fct_saved_pm" value="' . esc_attr($preselectId) . '" data-fct-saved-pm-value>';

        foreach ($cards as $card) {
            $inputId = 'fct_saved_' . esc_attr($card['id']);
            $isPayPal = Arr::get($card, 'gateway') === 'paypal';

            if ($isPayPal) {
                // A PayPal entry is an account, not a card: no brand, no last4.
                // Identify it by payer email, falling back to the provider name.
                $tag = 'PYPL';
                $label = !empty($card['email'])
                    ? (string) $card['email']
                    : __('PayPal account', 'fluent-cart-pro');
            } elseif (Arr::get($card, 'type') === 'link') {
                // A Stripe Link entry is a wallet, not a card: identified by the
                // Link account email, never by brand/last4.
                $tag = 'LINK';
                $label = !empty($card['email'])
                    ? (string) $card['email']
                    : __('Link account', 'fluent-cart-pro');
            } elseif (empty($card['last4'])) {
                // Account-like or unrecognized PM type with no card details —
                // identify by its account identifier (cashtag, payer email)
                // when one exists; never render "Card ending ‹nothing›".
                $tag = strtoupper(substr((string) Arr::get($card, 'type', 'card'), 0, 4));
                $label = !empty($card['email'])
                    ? (string) $card['email']
                    : __('Saved payment method', 'fluent-cart-pro');
            } else {
                $brand = !empty($card['brand']) ? ucfirst((string) $card['brand']) : __('Card', 'fluent-cart-pro');
                $tag = strtoupper(substr((string) $brand, 0, 4));
                /* translators: %1$s: card brand, %2$s: last 4 digits */
                $label = sprintf(__('%1$s ending %2$s', 'fluent-cart-pro'), $brand, $card['last4']);
            }

            $isDefault = !empty($card['is_default']);

            echo '<label class="fct-saved-card-row" for="' . $inputId . '">';
            echo '<input type="radio" name="_fct_pay_method" value="' . esc_attr(SavedCardGateway::SLUG) . '" id="' . $inputId . '"'
                . ' data-fct-saved-token="' . esc_attr($card['id']) . '"' . ($isDefault ? ' data-fct-saved-default="1"' : '')
                . ($preselectId !== '' && (string) $card['id'] === $preselectId ? ' checked' : '') . '>';
            echo '<span class="fct-saved-card-dot" aria-hidden="true"></span>';
            echo '<span class="fct-saved-card-brand">' . esc_html($tag) . '</span>';
            echo '<span class="fct-saved-card-text">' . esc_html($label);
            if ($isDefault) {
                echo ' <span class="fct-saved-card-default">' . esc_html__('Default', 'fluent-cart-pro') . '</span>';
            }
            echo '</span>';
            echo '</label>';
        }

        // Toggle that reveals the standard payment methods (collapsed while a saved
        // card is selected). Chevron rotates via the .is-open class.
        // Rendered as an anchor with role="button" (not a <button>) so the theme's
        // aggressive button chrome — gradient background, uppercase, big padding —
        // never applies; keyboard activation is wired up in the inline script.
        echo '<a role="button" tabindex="0" class="fct-saved-cards-toggle' . ($preselect ? '' : ' is-open') . '" data-fct-toggle-other'
            . ' aria-expanded="' . ($preselect ? 'false' : 'true') . '">'
            . '<span>' . esc_html__('Pay another way', 'fluent-cart-pro') . '</span>'
            . '<svg class="fct-saved-cards-chev" viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2"><path d="M6 9l6 6 6-6"/></svg>'
            . '</a>';
        echo '</div>';

        // Inline (not enqueued): keeps the hidden token synced and drives the
        // "Pay another way" toggle. The initial selection and collapse are already
        // in the markup. Inline so it runs regardless of where
        // before_payment_methods fires in the checkout render pipeline.
        echo '<script>(function(){'
            . 'var w=document.querySelector("[data-fct-saved-cards]");if(!w)return;'
            . 'var h=w.querySelector("[data-fct-saved-pm-value]");'
            . 'var toggle=w.querySelector("[data-fct-toggle-other]");'
            // The gateway has no client-side card element, so it is always
            // "ready" — the checkout handler gates Place Order on this flag
            // (window["is_<method>_ready"]).
            . 'window["is_fct_saved_card_ready"]=true;'
            . 'function sync(){if(!h)return;var r=document.querySelector(\'input[name="_fct_pay_method"]:checked\');'
            . 'var t=r?r.getAttribute("data-fct-saved-token"):null;h.value=t||"";}'
            // collapse(true) hides the standard methods; collapse(false) reveals
            // them. The container renders AFTER this script, so look it up lazily.
            // It becomes core's animated .fct-collapse; fragment refreshes replace
            // only its children. A core without that CSS (no grid) or the __inner
            // child keeps the old display toggle: the sibling rule, or inline display.
            . 'function collapse(c){w.classList.toggle("is-others-open",!c);'
            . 'var others=document.querySelector("[data-fluent-cart-checkout-payment-methods]");'
            . 'if(others){others.classList.add("fct-collapse");others.classList.toggle("is-open",!c);'
            . 'if(getComputedStyle(others).display==="grid"&&others.querySelector(":scope > .fct-collapse__inner")){others.style.display="";}'
            . 'else{others.classList.remove("fct-collapse","is-open");if(others.parentNode!==w.parentNode){others.style.display=c?"none":"";}}}'
            . 'if(toggle){toggle.setAttribute("aria-expanded",c?"false":"true");toggle.classList.toggle("is-open",!c);}}'
            . 'if(toggle){toggle.addEventListener("click",function(){collapse(toggle.classList.contains("is-open"));});'
            . 'toggle.addEventListener("keydown",function(e){if(e.key==="Enter"||e.key===" "||e.key==="Spacebar"){e.preventDefault();collapse(toggle.classList.contains("is-open"));}});}'
            . 'document.addEventListener("change",function(e){if(e.target&&e.target.name==="_fct_pay_method"){sync();window["is_fct_saved_card_ready"]=true;'
            // Selecting a saved card re-collapses; selecting any other method keeps it open.
            . 'if(e.target.value==="fct_saved_card"){collapse(true);}else{collapse(false);}}});'
            // Belt-and-suspenders: re-sync the moment the Place Order button is
            // clicked (capture phase, before the checkout handler serializes the form).
            . 'document.addEventListener("click",function(e){var t=e.target;if(t&&t.closest&&t.closest(".fct_place_order_btn"))sync();},true);'
            // The server already checked the preselected card. Once the checkout
            // script has bound its listeners, announce it with a change event so
            // the checkout persists the method (fees, fragment re-renders) and
            // enables Place Order. Purely a sync — nothing visible changes.
            . 'function pre(){var d=w.querySelector("input[data-fct-saved-token]:checked");'
            . 'if(d){window["is_fct_saved_card_ready"]=true;sync();collapse(true);d.dispatchEvent(new Event("change",{bubbles:true}));}else{sync();}}'
            . 'if(document.readyState==="complete"){setTimeout(pre,350);}else{window.addEventListener("load",function(){setTimeout(pre,350);});}'
            . '})();</script>';
    }

    /**
     * On place-order for the Saved Card gateway, verify ownership and store the
     * chosen opaque id on the order (the gateway re-resolves it against the
     * order's customer at charge time).
     */
    public function persistChosenCard($data)
    {
        $order = Arr::get($data, 'order');
        if (!$order) {
            return;
        }

        $requestData = Arr::get($data, 'request_data', []);
        $chosenMethod = Arr::get($requestData, 'others._fct_pay_method', Arr::get($requestData, '_fct_pay_method'));
        if ($chosenMethod !== SavedCardGateway::SLUG) {
            return;
        }

        $opaqueId = sanitize_text_field((string) Arr::get($requestData, 'fct_saved_pm', Arr::get($requestData, 'others.fct_saved_pm', '')));
        if (!preg_match('/^[a-f0-9]{20}$/', $opaqueId)) {
            return;
        }

        // Ownership boundary: the chosen card must belong to the ORDER's
        // customer (the payer the gateway will charge). Resolving against the
        // order's customer is the same check the gateway enforces at charge
        // time, so a crafted id for another customer is inert — and it keeps
        // persist and charge on the same customer record.
        $customer = $order->customer;
        if (!$customer) {
            return;
        }
        if (!(new SavedPaymentMethodRepository())->resolve($customer, $opaqueId)) {
            return;
        }

        $order->updateMeta(SavedCardGateway::ORDER_TOKEN_META, $opaqueId);
    }

    /**
     * Saved methods to offer on this cart — none on a subscription cart. The
     * gateway is one-time only (no subscriptions feature): on a
     * subscription cart SubscriptionGatewayGate strips it from the place-order
     * gate, so offering (and auto-preselecting) it would make the DEFAULT state
     * fail with 423 "not available".
     *
     * @return array
     */
    private function offeredSavedMethods($cart): array
    {
        if ($cart && method_exists($cart, 'hasSubscription') && $cart->hasSubscription()) {
            return [];
        }

        // Core renders no payment methods on a free order, so there is nothing to pay.
        if ($cart instanceof Cart && $cart->getEstimatedTotal() <= 0) {
            return [];
        }

        if ($this->savedMethods === null) {
            $this->savedMethods = $this->currentCustomerSavedMethods();
        }

        $currency = $this->cartCurrency($cart);

        return array_values(array_filter($this->savedMethods, function ($card) use ($currency) {
            return SavedCardGateway::providerChargesIn((string) Arr::get($card, 'gateway'), $currency);
        }));
    }

    private function cartCurrency($cart): string
    {
        if (!class_exists(CartCurrency::class)) {
            return (string) CurrencySettings::get('currency');
        }

        $lock = CartCurrency::lock($cart instanceof Cart ? $cart : null);

        return $lock ? (string) $lock['currency'] : CurrencyContext::current();
    }

    /**
     * Whether the checkout opens with a saved card selected (and the other
     * methods collapsed). It does unless the buyer already chose a different
     * method on this cart — honouring that keeps a full page load and a
     * payment-methods fragment refresh agreeing on the same selection.
     */
    private function shouldPreselect($cart): bool
    {
        if (empty($this->offeredSavedMethods($cart))) {
            return false;
        }

        $stored = $cart ? (string) Arr::get($cart->checkout_data, 'form_data._fct_pay_method', '') : '';

        return $stored === '' || $stored === SavedCardGateway::SLUG;
    }

    /**
     * The card preselected on load: the customer's default, else the first.
     */
    private function defaultCardId(array $cards): string
    {
        foreach ($cards as $card) {
            if (!empty($card['is_default'])) {
                return (string) $card['id'];
            }
        }

        return (string) Arr::get(reset($cards), 'id', '');
    }

    /**
     * Saved methods for the current customer that this picker can actually charge
     * (empty if none / gated off). Restricted to gateways the pay-now gateway
     * knows how to charge, so a record written by some future provider cannot be
     * offered before there is code to charge it.
     *
     * @return array
     */
    private function currentCustomerSavedMethods(): array
    {
        if (!is_user_logged_in() || !SavedPaymentMethods::isEnabled()) {
            return [];
        }

        $customer = CustomerResource::getCurrentCustomer();
        if (!$customer) {
            return [];
        }

        $cards = (new SavedPaymentMethodRepository())->list($customer);

        return array_values(array_filter($cards, function ($card) {
            return in_array(Arr::get($card, 'gateway'), ['stripe', 'paypal'], true);
        }));
    }

    /**
     * The saved-card rows sit directly above core's payment-method boxes, so
     * they wear the same checkout variables (core's checkout.scss), each with
     * the colour it always had as the fallback, and the same box shape (1px,
     * 8px radius). The card-brand chip and the "Default" badge are content,
     * not chrome, and keep fixed colours.
     */
    private function styles(): string
    {
        return '<style>
            .fct-saved-cards{margin-bottom:16px;transition:margin-bottom .2s ease-out}
            .fct-saved-cards:not(.is-others-open){margin-bottom:0}
            .fct-saved-cards:not(.is-others-open) ~ [data-fluent-cart-checkout-payment-methods]:not(.fct-collapse){display:none}
            .fct-saved-cards-title{font-size:12px;font-weight:600;text-transform:uppercase;letter-spacing:.06em;color:var(--fct-checkout-secondary-text-color,#9D9FAC);margin-bottom:10px}
            .fct-saved-cards .fct-saved-card-row{display:flex;width:100%;box-sizing:border-box;align-items:center;gap:12px;background:var(--fct-checkout-payment-method-bg-color,#ffffff);border:1px solid var(--fct-checkout-border-color,#D6DAE1);border-radius:8px;padding:12px 14px;margin-bottom:10px;cursor:pointer;position:relative}
            .fct-saved-card-row:has(input:checked){border-color:var(--fct-checkout-active-border-color,#253241)}
            .fct-saved-card-row input[type=radio]{position:absolute;opacity:0;width:0;height:0;margin:0}
            .fct-saved-card-dot{width:18px;height:18px;border-radius:50%;border:1.5px solid var(--fct-checkout-radio-border-color,#D6DAE1);flex:none;position:relative;box-sizing:border-box}
            .fct-saved-card-row input:checked ~ .fct-saved-card-dot{border-color:var(--fct-checkout-radio-active-border-color,#253241)}
            .fct-saved-card-row input:checked ~ .fct-saved-card-dot::after{content:"";position:absolute;inset:3px;border-radius:50%;background:var(--fct-checkout-radio-active-bg-color,#253241)}
            .fct-saved-card-brand{width:38px;height:26px;border-radius:4px;background:#253241;color:#fff;display:inline-flex;align-items:center;justify-content:center;font-size:9px;font-weight:700;flex:none}
            .fct-saved-card-text{font-size:14px;color:var(--fct-checkout-primary-text-color,#2F3448);font-weight:500}
            .fct-saved-card-default{display:inline-block;font-size:11px;font-weight:500;padding:1px 7px;border-radius:6px;background:#D1EAE4;color:#116A53;margin-left:4px}
            .fct-saved-cards-toggle{display:inline-flex;align-items:center;gap:6px;padding:8px 0;margin-top:4px;cursor:pointer;font-size:13px;font-weight:600;color:var(--fct-checkout-secondary-text-color,#565865);text-decoration:none;text-transform:none;letter-spacing:normal}
            .fct-saved-cards-toggle:hover,.fct-saved-cards-toggle:focus{color:var(--fct-checkout-primary-text-color,#2F3448);text-decoration:none}
            .fct-saved-cards-toggle svg{width:14px;height:14px;flex:none;display:block}
            .fct-saved-cards-chev{transition:transform .2s ease}
            .fct-saved-cards-toggle.is-open .fct-saved-cards-chev{transform:rotate(180deg)}
        </style>';
    }
}
