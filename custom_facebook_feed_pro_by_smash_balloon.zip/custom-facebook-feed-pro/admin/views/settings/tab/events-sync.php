<?php

if (! defined('ABSPATH')) {
	exit; // Exit if accessed directly.
}
?>
<div v-if="selected === 'app-6'" id="cff-panel-events" role="tabpanel" aria-labelledby="cff-settings-tab-events" tabindex="0">
	<div class="sb-tab-box clearfix" v-if="!eventsSync.licenseAllows">
		<div class="tab-label">
			<h3>{{eventsSync.genericText.title}}</h3>
			<p>{{eventsSync.genericText.upgradeNotice}} <a :href="upgradeUrl" target="_blank">{{genericText.upgrade}}</a></p>
		</div>
	</div>

	<template v-if="eventsSync.licenseAllows">
		<div class="sb-tab-box cff-events-sync-enable-box clearfix">
			<label class="cff-checkbox cff-events-sync-switch">
				<input type="checkbox" v-model="eventsSync.model.enabled">
				<span class="toggle-track"><span class="toggle-indicator"></span></span>
			</label>
			<div class="cff-events-sync-heading">
				<h3>{{eventsSync.genericText.title}}</h3>
				<p>{{eventsSync.genericText.description}}</p>
				<p class="cff-events-sync-mirror-notice"><em>{{eventsSync.genericText.mirrorNotice}}</em></p>
			</div>
		</div>

		<template v-if="eventsSync.model.enabled">
			<div class="sb-tab-box cff-events-sync-box clearfix" v-if="!eventsSyncAnyCalendar()">
				<div class="cff-events-sync-suggest">
					<img :src="eventsSync.suggestLogo" alt="Sugar Calendar">
					<div class="cff-events-sync-suggest-text">
						<h3>{{eventsSync.genericText.suggestTitle}}</h3>
						<p>{{eventsSync.genericText.suggestText}}</p>
						<button
							v-if="eventsSync.canInstall"
							class="cff-btn sb-btn-orange cff-events-sync-install-btn"
							@click.prevent="eventsSyncInstallSuggested"
							:disabled="eventsSyncInstallStatus === 'loading'"
						>
							<span v-if="eventsSyncInstallStatus === 'loading'" class="cff-events-sync-install-loader" v-html="loaderSVG"></span>
							{{eventsSyncInstallStatus === 'loading' ? eventsSync.genericText.installing : eventsSync.genericText.suggestCta}}
						</button>
						<a v-else class="cff-btn sb-btn-orange cff-events-sync-install-btn" :href="eventsSync.suggestUrl" target="_blank" rel="noopener">
							{{eventsSync.genericText.suggestCta}}
						</a>
					</div>
				</div>
			</div>

			<div class="sb-tab-box cff-events-sync-box clearfix" v-if="eventsSyncAnyCalendar()">
				<div class="cff-events-sync-section-heading">
					<h3>{{eventsSync.genericText.targetsTitle}}</h3>
				</div>
				<div class="cff-events-sync-cards">
					<div
						class="cff-events-sync-card"
						v-for="(target, targetId) in eventsSync.targets"
						v-if="target.available"
						:key="targetId"
						:class="{ 'is-selected': eventsSync.model.targets[targetId] }"
						role="checkbox"
						:aria-checked="eventsSync.model.targets[targetId] ? 'true' : 'false'"
						tabindex="0"
						@click="eventsSyncToggleTarget(targetId)"
						@keydown.enter.prevent="eventsSyncToggleTarget(targetId)"
						@keydown.space.prevent="eventsSyncToggleTarget(targetId)"
					>
						<span class="cff-events-sync-card-check"></span>
						<span class="cff-events-sync-card-logo">
							<img v-if="target.logo" :src="target.logo" :alt="target.label">
							<svg v-else width="48" height="48" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
								<rect x="6" y="10" width="36" height="32" rx="4" fill="#E8F1F6"/>
								<rect x="6" y="10" width="36" height="10" rx="4" fill="#0068A0"/>
								<rect x="13" y="5" width="4" height="9" rx="2" fill="#0068A0"/>
								<rect x="31" y="5" width="4" height="9" rx="2" fill="#0068A0"/>
							</svg>
						</span>
						<span class="cff-events-sync-card-name">{{target.label}}</span>
						<span class="cff-events-sync-card-status is-detected">
							{{eventsSync.genericText.installed}}
						</span>
						<button
							class="cff-events-sync-card-cleanup"
							@click.stop.prevent="eventsSyncCleanup(targetId)"
							:disabled="eventsSyncCleanupStatus === targetId"
						>
							<span v-if="eventsSyncCleanupStatus === targetId" class="cff-events-sync-card-cleanup-loader" v-html="loaderSVG"></span>
							{{eventsSync.genericText.cleanup}}
						</button>
					</div>
				</div>
			</div>

			<div class="sb-tab-box cff-events-sync-box clearfix" v-if="eventsSyncHasTarget()">
				<div class="cff-events-sync-section-heading">
					<h3>{{eventsSync.genericText.sourcesTitle}}</h3>
					<p v-if="eventsSync.sources.length">{{eventsSync.genericText.sourcesAll}}</p>
				</div>
				<p v-if="!eventsSync.sources.length">{{eventsSync.genericText.sourcesEmpty}}</p>
				<div class="sb-sources-list cff-events-sync-sources" v-else>
					<div
						class="sb-srcs-item cff-events-sync-source"
						v-for="source in eventsSync.sources"
						:key="source.account_id"
						:class="{ 'is-selected': eventsSyncSourceSelected(source.account_id) }"
						role="checkbox"
						:aria-checked="eventsSyncSourceSelected(source.account_id) ? 'true' : 'false'"
						tabindex="0"
						@click="eventsSyncToggleSource(source.account_id)"
						@keydown.enter.prevent="eventsSyncToggleSource(source.account_id)"
						@keydown.space.prevent="eventsSyncToggleSource(source.account_id)"
					>
						<span class="cff-events-sync-card-check"></span>
						<div class="cff-fb-srcs-item-ins">
							<div class="sb-srcs-item-avatar">
								<img :src="'https://graph.facebook.com/' + source.account_id + '/picture'" alt="">
							</div>
							<div class="sb-srcs-item-inf">
								<div class="sb-srcs-item-name">
									{{source.username}}
									<span class="cff-fb-srcs-item-name-event">(events)</span>
								</div>
								<div class="sb-srcs-item-id sb-small-p">{{source.account_id}}</div>
							</div>
						</div>
					</div>
				</div>
			</div>

			<div class="sb-tab-box clearfix" v-if="eventsSyncHasTarget()">
				<div class="tab-label">
					<h3>{{eventsSync.genericText.cronTitle}}</h3>
					<p>{{eventsSync.genericText.nextRun}} <strong>{{eventsSync.nextRun}}</strong></p>
				</div>
				<div class="cff-tab-form-field">
					<div class="d-flex cff-events-sync-cron-row">
						<select v-model="eventsSync.model.cron_interval" class="cff-form-field">
							<option value="hourly">{{eventsSync.genericText.cronHourly}}</option>
							<option value="twicedaily">{{eventsSync.genericText.cronTwiceDaily}}</option>
							<option value="daily">{{eventsSync.genericText.cronDaily}}</option>
						</select>
						<button class="cff-btn sb-btn-orange" @click.prevent="eventsSyncNow" :disabled="eventsSyncNowStatus === 'loading'">
							<span v-if="eventsSyncNowStatus === 'loading'" class="cff-events-sync-install-loader" v-html="loaderSVG"></span>
							{{eventsSyncNowStatus === 'loading' ? eventsSync.genericText.syncing : eventsSync.genericText.syncNow}}
						</button>
					</div>
					<label class="cff-checkbox cff-events-sync-sideload">
						<input type="checkbox" v-model="eventsSync.model.sideload_images">
						<span class="toggle-track"><span class="toggle-indicator"></span></span>
						<span class="cff-events-sync-switch-label">{{eventsSync.genericText.sideloadImages}}</span>
					</label>
				</div>
			</div>

			<div class="sb-tab-box cff-events-sync-box clearfix" v-if="eventsSyncHasTarget()">
				<div class="cff-events-sync-section-heading cff-events-sync-log-heading">
					<h3>{{eventsSync.genericText.logTitle}}</h3>
					<button
						v-if="eventsSync.log.length"
						class="cff-events-sync-clear-log"
						@click.prevent="eventsSyncClearLog"
						:disabled="eventsSyncClearLogStatus === 'loading'"
					>
						{{eventsSync.genericText.clearLog}}
					</button>
				</div>
				<p v-if="!eventsSync.log.length">{{eventsSync.genericText.logEmpty}}</p>
				<table v-else class="widefat cff-events-sync-log">
					<thead>
						<tr>
							<th>{{eventsSync.genericText.logTime}}</th>
							<th>{{eventsSync.genericText.logSource}}</th>
							<th>{{eventsSync.genericText.logCreated}}</th>
							<th>{{eventsSync.genericText.logUpdated}}</th>
							<th>{{eventsSync.genericText.logDeleted}}</th>
							<th>{{eventsSync.genericText.logErrors}}</th>
						</tr>
					</thead>
					<tbody>
						<tr v-for="(entry, i) in eventsSync.log" :key="i">
							<td>{{new Date(entry.time * 1000).toLocaleString()}}</td>
							<td>{{entry.source}}</td>
							<td>{{entry.created}}</td>
							<td>{{entry.updated}}</td>
							<td>{{entry.deleted}}</td>
							<td><span class="cff-events-sync-log-error" v-for="(err, j) in entry.errors" :key="j">{{err}}</span></td>
						</tr>
					</tbody>
				</table>
			</div>
		</template>
	</template>
</div>
