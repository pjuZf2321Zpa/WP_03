<?php

if (!defined('ABSPATH')) {
    exit;
}
    
use BitApps\IntegrationsPro\Core\Util\Hooks;
use BitApps\IntegrationsPro\Triggers\BbPress\BbPressController;

Hooks::add('bbp_new_reply', [BbPressController::class, 'handleReplyToTopic'], 10, 3);
Hooks::add('bbp_new_topic', [BbPressController::class, 'handleTopicCreated'], 10, 4);
