<?php

declare(strict_types=1);

namespace FluentCartPro\App\Services\Invoice\Calculation;

if (!defined('ABSPATH')) {
    exit;
}

use FluentCartPro\App\Services\Invoice\Domain\CalculatedTotals;
use FluentCartPro\App\Services\Invoice\Domain\DocumentCharge;
use FluentCartPro\App\Services\Invoice\Domain\En16931Invoice;
use FluentCartPro\App\Services\Invoice\Domain\InvoiceLine;
use FluentCartPro\App\Services\Invoice\Domain\Money;
use FluentCartPro\App\Services\Invoice\Domain\TaxSummary;

/**
 * Computes totals from En16931Invoice. Integer cents only; deterministic rounding.
 * BR-CO-16: duePayable = grandTotal - totalPrepaid + rounding.
 */
final class InvoiceCalculationEngine
{
    private function round(int $cents): int
    {
        return (int) round($cents);
    }

    /**
     * Record the first non-empty exemption reason seen for a VAT breakdown group.
     * All lines sharing a category|rate key carry the same reason, so first-wins is safe.
     *
     * @param array $group Mutable byCategory group (passed by reference).
     */
    private function captureExemptionReason(array &$group, string $reasonCode, string $reasonText): void
    {
        if ($group['exemptionReasonCode'] === '' && $reasonCode !== '') {
            $group['exemptionReasonCode'] = $reasonCode;
        }
        if ($group['exemptionReasonText'] === '' && $reasonText !== '') {
            $group['exemptionReasonText'] = $reasonText;
        }
    }

    public function calculate(En16931Invoice $invoice): CalculatedTotals
    {
        $currency = $invoice->currency;

        $totalNetCents = 0;
        /** @var array<string, array{basis: int, calculated: int}> */
        $byCategory = [];

        foreach ($invoice->lines as $line) {
            $lineNetCents = $this->computeLineNetCents($line);
            $totalNetCents += $lineNetCents;
            $this->addToCategory($byCategory, $line->taxCategory, $line->taxPercent, $lineNetCents, $line->exemptionReasonCode, $line->exemptionReasonText);
        }

        $allowanceCents = 0;
        foreach ($invoice->allowances as $a) {
            if (isset($a->amount)) {
                $allowanceCents += $a->amount->getAmountInCents();
            }
        }
        $chargeCents = 0;
        foreach ($invoice->charges as $c) {
            if ($c instanceof DocumentCharge) {
                $chargeAmount = $c->amount->getAmountInCents();
                $chargeCents += $chargeAmount;
                $this->addToCategory($byCategory, $c->taxCategory, $c->taxPercent, $chargeAmount, $c->exemptionReasonCode, $c->exemptionReasonText);
            } elseif (isset($c->amount)) {
                $chargeCents += $c->amount->getAmountInCents();
            }
        }

        // BR-CO-17: VAT is rounded once per category, never summed from rounded lines.
        $unitCents     = (new Money($currency, 0))->minorUnitCents();
        $totalVatCents = 0;
        foreach (array_keys($byCategory) as $key) {
            $rate = (float) explode('|', $key, 2)[1];
            $byCategory[$key]['calculated'] = (int) round($byCategory[$key]['basis'] * $rate / 100 / $unitCents) * $unitCents;
            $totalVatCents += $byCategory[$key]['calculated'];
        }

        $grandTotalCents = $totalNetCents + $totalVatCents - $allowanceCents + $chargeCents;

        $prepaidCents  = $invoice->prepaidAmount->getAmountInCents();
        $roundingCents = $invoice->roundingAmount->getAmountInCents();
        if ($invoice->payableAmount !== null) {
            $payableCents  = $invoice->payableAmount->getAmountInCents();
            $roundingCents = $payableCents - $grandTotalCents;
            if (abs($roundingCents) > (count($invoice->lines) + count($invoice->charges)) * $unitCents) {
                throw new \InvalidArgumentException(sprintf(
                    /* translators: %1$s: e-invoice grand total, %2$s: order total */
                    __('E-invoice total %1$s does not match the order total %2$s.', 'fluent-cart-pro'),
                    (new Money($currency, $grandTotalCents))->toDecimalString(),
                    $invoice->payableAmount->toDecimalString()
                ));
            }
        }
        $duePayableCents = $grandTotalCents - $prepaidCents + $roundingCents;

        $totalNet     = new Money($currency, $totalNetCents);
        $totalVat     = new Money($currency, $totalVatCents);
        $grandTotal   = new Money($currency, $grandTotalCents);
        $totalPrepaid = new Money($currency, $prepaidCents);
        $rounding     = new Money($currency, $roundingCents);
        $duePayable   = new Money($currency, $duePayableCents);

        $taxSummaries = [];
        foreach ($byCategory as $key => $agg) {
            list($cat, $rateStr) = explode('|', $key, 2);
            $taxSummaries[] = new TaxSummary(
                new Money($currency, (int) $agg['basis']),
                new Money($currency, (int) $agg['calculated']),
                $cat,
                $rateStr,
                (string) ($agg['exemptionReasonCode'] ?? ''),
                (string) ($agg['exemptionReasonText'] ?? '')
            );
        }
        if (empty($taxSummaries)) {
            $taxSummaries[] = new TaxSummary(
                new Money($currency, 0),
                new Money($currency, 0),
                'Z',
                '0.00'
            );
        }

        return new CalculatedTotals($totalNet, $totalVat, $grandTotal, $totalPrepaid, $rounding, $duePayable, $taxSummaries);
    }

    private function addToCategory(array &$byCategory, string $category, string $percent, int $basisCents, string $reasonCode, string $reasonText): void
    {
        $key = $category . '|' . $percent;
        if (!isset($byCategory[$key])) {
            $byCategory[$key] = ['basis' => 0, 'calculated' => 0, 'exemptionReasonCode' => '', 'exemptionReasonText' => ''];
        }
        $byCategory[$key]['basis'] += $basisCents;
        $this->captureExemptionReason($byCategory[$key], $reasonCode, $reasonText);
    }

    private function computeLineNetCents(InvoiceLine $line): int
    {
        $lineTotal = (int) round($line->netUnitPrice->getAmountInCents() * $line->quantity / $line->priceBaseQuantity);
        $lineTotal -= $line->lineAllowance->getAmountInCents();
        $lineTotal += $line->lineCharge->getAmountInCents();
        return $this->round((int) $lineTotal);
    }
}
