<?php

namespace MasterStudy\Lms\Pro\AddonsPlus\AiLab\Services\OpenAi;

/**
 * Model and provider map for AI Lab.
 */
final class Model {
	// Providers
	public const PROVIDER_OPENAI  = 'openai';
	public const PROVIDER_GROK    = 'grok';
	public const PROVIDER_GEMINI  = 'gemini';
	public const PROVIDER_MISTRAL = 'mistral';
	public const PROVIDER_CLAUDE  = 'claude';
	public const PROVIDER_LLAMA   = 'llama';

	// OpenAI text models
	public const GPT_56                  = 'gpt-5.6';
	public const GPT_56_TERRA            = 'gpt-5.6-terra';
	public const GPT_56_LUNA             = 'gpt-5.6-luna';
	public const GPT_5                   = 'gpt-5';
	public const GPT_5_MINI              = 'gpt-5-mini';
	public const GPT_5_NANO              = 'gpt-5-nano';
	public const GPT_4O                  = 'gpt-4o';
	public const GPT_4O_MINI             = 'gpt-4o-mini';
	public const GPT_41                  = 'gpt-4.1';
	public const GPT_41_MINI             = 'gpt-4.1-mini';
	public const GPT_41_NANO             = 'gpt-4.1-nano';
	public const GPT_4_TURBO             = 'gpt-4-turbo';
	public const GPT_4_TURBO_LATEST      = 'gpt-4-turbo-latest';
	public const GPT_4_TURBO_LATEST_MINI = 'gpt-4-turbo-latest-mini';
	public const GPT_4                   = 'gpt-4';
	public const GPT_35_TURBO            = 'gpt-3.5-turbo';
	public const GPT_35_TURBO_16K        = 'gpt-3.5-turbo-16k';
	public const GPT_35_TURBO_INSTRUCT   = 'gpt-3.5-turbo-instruct';

	// Grok text models
	public const GROK_45     = 'grok-4.5';
	public const GROK_43     = 'grok-4.3';
	public const GROK_3      = 'grok-3';
	public const GROK_3_MINI = 'grok-3-mini';

	// Gemini text models
	public const GEMINI_35_FLASH      = 'gemini-3.5-flash';
	public const GEMINI_31_FLASH_LITE = 'gemini-3.1-flash-lite';
	public const GEMINI_25_PRO        = 'gemini-2.5-pro';
	public const GEMINI_25_FLASH      = 'gemini-2.5-flash';

	// Mistral text models
	public const MISTRAL_LARGE_LATEST = 'mistral-large-latest';
	public const MISTRAL_SMALL_LATEST = 'mistral-small-latest';

	// Claude text models
	public const CLAUDE_SONNET_5   = 'claude-sonnet-5';
	public const CLAUDE_OPUS_48    = 'claude-opus-4-8';
	public const CLAUDE_HAIKU_45   = 'claude-haiku-4-5';
	public const CLAUDE_OPUS_4_1   = 'claude-opus-4-20250514';
	public const CLAUDE_SONNET_4_5 = 'claude-sonnet-4-20250514';

	// OpenAI image models
	public const GPT_IMAGE_2 = 'gpt-image-2';
	public const DALL_E_2    = 'dall-e-2';
	public const DALL_E_3    = 'dall-e-3';

	// Provider image models
	public const GROK_IMAGE_QUALITY    = 'grok-imagine-image-quality';
	public const GROK_IMAGE            = 'grok-imagine-image';
	public const GEMINI_FLASH_IMAGE    = 'gemini-2.5-flash-image';
	public const MISTRAL_IMAGE_DEFAULT = 'mistral-image-generation';

	// Audio
	public const WHISPER_1             = 'whisper-1';
	public const GPT4O_TRANSCRIBE      = 'gpt-4o-transcribe';
	public const GPT4O_MINI_TRANSCRIBE = 'gpt-4o-mini-transcribe';
	public const TTS_1                 = 'tts-1';
	public const TTS_1_HD              = 'tts-1-hd';

	// Moderation
	public const MODERATION_LATEST = 'omni-moderation-latest';

	public static function get_text_providers(): array {
		return array(
			self::PROVIDER_OPENAI  => 'OpenAI',
			self::PROVIDER_GROK    => 'Grok',
			self::PROVIDER_GEMINI  => 'Gemini',
			self::PROVIDER_MISTRAL => 'Mistral',
			self::PROVIDER_CLAUDE  => 'Claude',
		);
	}

	public static function get_image_providers(): array {
		return array(
			self::PROVIDER_OPENAI  => 'OpenAI',
			self::PROVIDER_GROK    => 'Grok',
			self::PROVIDER_GEMINI  => 'Gemini',
		);
	}

	public static function provider_supports_image_generation( string $provider ): bool {
		return in_array(
			$provider,
			array(
				self::PROVIDER_OPENAI,
				self::PROVIDER_GROK,
				self::PROVIDER_GEMINI,
			),
			true
		);
	}

	public static function provider_supports_image_size( string $provider ): bool {
		return self::PROVIDER_GROK !== $provider;
	}

	public static function is_openai_compatible_provider( string $provider ): bool {
		return in_array(
			$provider,
			array(
				self::PROVIDER_OPENAI,
				self::PROVIDER_GROK,
				self::PROVIDER_GEMINI,
				self::PROVIDER_MISTRAL,
			),
			true
		);
	}

	public static function get_provider_base_url( string $provider ): string {
		switch ( $provider ) {
			case self::PROVIDER_GROK:
				return 'https://api.x.ai/v1';
			case self::PROVIDER_GEMINI:
				return 'https://generativelanguage.googleapis.com/v1beta/openai';
			case self::PROVIDER_MISTRAL:
				return 'https://api.mistral.ai/v1';
			case self::PROVIDER_CLAUDE:
				return 'https://api.anthropic.com/v1';
			case self::PROVIDER_OPENAI:
			default:
				return 'https://api.openai.com/v1';
		}
	}

	public static function get_text_models_by_provider( string $provider ): array {
		switch ( $provider ) {
			case self::PROVIDER_GROK:
				return array(
					self::GROK_45 => 'Grok 4.5',
					self::GROK_43 => 'Grok 4.3',
				);
			case self::PROVIDER_GEMINI:
				return array(
					self::GEMINI_35_FLASH      => 'Gemini 3.5 Flash',
					self::GEMINI_31_FLASH_LITE => 'Gemini 3.1 Flash-Lite',
				);
			case self::PROVIDER_MISTRAL:
				return array(
					self::MISTRAL_LARGE_LATEST => 'Mistral Large Latest',
					self::MISTRAL_SMALL_LATEST => 'Mistral Small Latest',
				);
			case self::PROVIDER_CLAUDE:
				return array(
					self::CLAUDE_SONNET_5 => 'Claude Sonnet 5',
					self::CLAUDE_OPUS_48  => 'Claude Opus 4.8',
					self::CLAUDE_HAIKU_45 => 'Claude Haiku 4.5',
				);
			case self::PROVIDER_OPENAI:
			default:
				return array(
					self::GPT_56       => 'GPT-5.6 Sol',
					self::GPT_56_TERRA => 'GPT-5.6 Terra',
					self::GPT_56_LUNA  => 'GPT-5.6 Luna',
					self::GPT_5        => 'GPT-5',
					self::GPT_5_MINI   => 'GPT-5 Mini',
					self::GPT_5_NANO   => 'GPT-5 Nano',
					self::GPT_4O_MINI  => 'GPT-4o Mini',
					self::GPT_41       => 'GPT-4.1',
					self::GPT_41_MINI  => 'GPT-4.1 Mini',
				);
		}
	}

	public static function get_image_models_by_provider( string $provider ): array {
		switch ( $provider ) {
			case self::PROVIDER_GROK:
				return array(
					self::GROK_IMAGE_QUALITY => 'Grok Imagine Quality',
					self::GROK_IMAGE         => 'Grok Imagine',
				);
			case self::PROVIDER_GEMINI:
				return array(
					self::GEMINI_FLASH_IMAGE => 'Gemini 2.5 Flash Image',
				);
			case self::PROVIDER_MISTRAL:
				return array(
					self::MISTRAL_IMAGE_DEFAULT => 'Mistral Image Generation',
				);
			case self::PROVIDER_OPENAI:
			default:
				return array(
					self::GPT_IMAGE_2 => 'GPT Image 2',
				);
		}
	}

	public static function get_default_text_model_by_provider( string $provider ): string {
		switch ( $provider ) {
			case self::PROVIDER_GROK:
				return self::GROK_43;
			case self::PROVIDER_GEMINI:
				return self::GEMINI_35_FLASH;
			case self::PROVIDER_MISTRAL:
				return self::MISTRAL_SMALL_LATEST;
			case self::PROVIDER_CLAUDE:
				return self::CLAUDE_SONNET_5;
			case self::PROVIDER_OPENAI:
			default:
				return self::GPT_56_LUNA;
		}
	}

	public static function get_default_image_model_by_provider( string $provider ): string {
		switch ( $provider ) {
			case self::PROVIDER_GROK:
				return self::GROK_IMAGE_QUALITY;
			case self::PROVIDER_GEMINI:
				return self::GEMINI_FLASH_IMAGE;
			case self::PROVIDER_MISTRAL:
				return self::MISTRAL_IMAGE_DEFAULT;
			case self::PROVIDER_OPENAI:
			default:
				return self::GPT_IMAGE_2;
		}
	}

	public static function get_api_option_name_by_provider( string $provider ): string {
		switch ( $provider ) {
			case self::PROVIDER_GROK:
				return 'grok_api_key';
			case self::PROVIDER_GEMINI:
				return 'gemini_api_key';
			case self::PROVIDER_MISTRAL:
				return 'mistral_api_key';
			case self::PROVIDER_CLAUDE:
				return 'claude_api_key';
			case self::PROVIDER_OPENAI:
			default:
				return 'openai_api_key';
		}
	}
}
