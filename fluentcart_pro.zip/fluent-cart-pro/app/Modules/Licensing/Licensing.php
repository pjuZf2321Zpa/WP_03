<?php

namespace FluentCartPro\App\Modules\Licensing;

use FluentCart\Api\ModuleSettings;
use FluentCart\App\Services\Permission\PermissionManager;
use FluentCart\Framework\Support\Arr;

class Licensing
{
    public function register($app)
    {

        add_action('fluent_cart/module/activated/license', function ($newData, $oldData) {
            (new \FluentCartPro\App\Modules\Licensing\Database\DBMigrator())->migrate();
        }, 10, 2);

        $app->addFilter('fluent_cart/module_setting/fields', function ($fields, $args) {
            $fields['license'] = [
                'title'       => __('Product Licensing', 'fluent-cart-pro'),
                'description' => __('Sale Licenses of your products easier than ever!', 'fluent-cart-pro'),
                'type'        => 'component',
                'component'   => 'ModuleSettings',
            ];
            return $fields;
        }, 10, 2);

        $app->addFilter('fluent_cart/module_setting/default_values', function ($values, $args) {
            if (empty($values['license']['active'])) {
                $values['license']['active'] = 'no';
            }
            return $values;
        }, 10, 2);

        if (!ModuleSettings::isActive('license')) {
            return;
        }

        $app->router->group(function ($router) {
            require_once __DIR__ . '/Http/licensing-api.php';
        });

        require_once __DIR__ . '/Hooks/license-actions.php';
        require_once __DIR__ . '/Hooks/license-filters.php';

        add_filter('fluent_cart/product_admin_items', [$this, 'addLicenseSettingsMenu'], 10, 2);
        add_filter('fluent_cart/global_admin_menu_items', [$this, 'addLicenseAdminMenu'], 10, 2);

        add_action('fluent_cart/loading_app', [$this, 'enqueueAdminApp']);
        add_filter('fluent_cart/admin_translations', [$this, 'addAdminTranslations'], 10, 2);
        add_filter('fluent_cart/admin_app_data', [$this, 'addReportSidebarItem']);
    }

    public function addReportSidebarItem($data)
    {
        // The report screen ships with the licensing screens, which older cores do not load
        if (!static::coreRunsScreens()) {
            return $data;
        }

        if (!PermissionManager::hasPermission('reports/view') || !PermissionManager::hasPermission('licenses/view')) {
            return $data;
        }

        $items = isset($data['addon_report_sidebar']) && is_array($data['addon_report_sidebar'])
            ? $data['addon_report_sidebar']
            : [];
        $item = [
            'route' => 'reports_licenses',
            'label' => __('Licenses', 'fluent-cart-pro'),
            'url'   => '/reports/licenses',
            'icon'  => 'License',
        ];
        // A report, so above Export when that is already listed
        $exportAt = array_search('reports_export', array_column($items, 'route'), true);
        array_splice($items, $exportAt === false ? count($items) : $exportAt, 0, [$item]);
        $data['addon_report_sidebar'] = $items;

        return $data;
    }

    // The screens import FluentCart's layout components (module API 3).
    public static function coreRunsScreens(): bool
    {
        return defined('FLUENTCART_MODULE_API') && FLUENTCART_MODULE_API >= 3;
    }

    public function enqueueAdminApp(): void
    {
        // No module map: below Pro's minimum FluentCart, so no licensing screens at all.
        if (!defined('FLUENTCART_MODULE_API')) {
            return;
        }

        // Module API 1-2 gets a page that asks to update FluentCart instead.
        $module = static::coreRunsScreens() ? 'licensing' : 'licensing-update';
        $baseUrl = FLUENTCART_PRO_PLUGIN_URL . 'assets/modules/';

        wp_enqueue_style('fluent_cart_pro_licensing', $baseUrl . $module . '.css', [], FLUENTCART_PRO_PLUGIN_VERSION);
        wp_enqueue_script('fluent_cart_pro_licensing', $baseUrl . $module . '.js', [], FLUENTCART_PRO_PLUGIN_VERSION, true);

        add_filter('script_loader_tag', function ($tag, $handle) {
            if ($handle !== 'fluent_cart_pro_licensing') {
                return $tag;
            }

            return str_replace('<script ', '<script type="module" ', $tag);
        }, 10, 2);
    }

    public function addAdminTranslations($translations, $args = [])
    {
        return array_merge(require __DIR__ . '/licensing-translation.php', (array)$translations);
    }

    public function addLicenseAdminMenu($items, $args)
    {
        if (!defined('FLUENTCART_MODULE_API')) {
            return $items;
        }

        $baseUrl = Arr::get($args, 'base_url');

        if (PermissionManager::hasPermission(['licenses/view'])) {
            $items['licenses'] = [
                'label' => __('Licenses', 'fluent-cart-pro'),
                'link'  => $baseUrl . 'licenses'
            ];
        }

        return $items;
    }

    public function addLicenseSettingsMenu($items, $args)
    {
        if (!defined('FLUENTCART_MODULE_API') || !PermissionManager::hasPermission(['licenses/view'])) {
            return $items;
        }

        $baseUrl = Arr::get($args, 'base_url');
        $productId = Arr::get($args, 'product_id');

        $items['license_settings'] = [
            'label' => __('License Settings', 'fluent-cart-pro'),
            'link'  => $baseUrl . 'products/' . $productId . '/license_settings'
        ];

        return $items;
    }

}
