<?php

namespace WPAICG\Lib\Integrations\Apps;

use WPAICG\Lib\Integrations\Auth\AIPKit_App_Token_Refresh;
use WPAICG\Lib\Integrations\Recipes\AIPKit_Recipe_Field_Mapper;
use WP_Error;

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

class AIPKit_App_Action_Dispatcher
{
    /**
     * @param array<string, mixed> $execution
     * @param array<string, mixed> $recipe
     * @param array<string, mixed> $event_envelope
     * @param array<string, mixed> $context
     * @return array<string, mixed>|WP_Error
     */
    public static function execute(array $execution, array $recipe, array $event_envelope, array $context = [])
    {
        $connection = isset($context['connection']) && is_array($context['connection']) ? $context['connection'] : [];
        if (empty($connection)) {
            return new WP_Error(
                'aipkit_recipe_connection_missing',
                __('Recipe connection could not be resolved.', 'gpt3-ai-content-generator')
            );
        }

        $app_slug = sanitize_key((string) ($recipe['app_slug'] ?? ''));
        $connection_app_slug = sanitize_key((string) ($connection['app_slug'] ?? ''));
        if ($app_slug === '' || $connection_app_slug === '' || $app_slug !== $connection_app_slug) {
            return new WP_Error(
                'aipkit_recipe_connection_mismatch',
                __('Recipe app and connection app do not match.', 'gpt3-ai-content-generator')
            );
        }

        if (empty($connection['is_enabled'])) {
            return new WP_Error(
                'aipkit_recipe_connection_disabled',
                __('The selected app connection is disabled.', 'gpt3-ai-content-generator')
            );
        }

        $mapped_fields = AIPKit_Recipe_Field_Mapper::build_mapped_fields($recipe, $event_envelope);
        if (is_wp_error($mapped_fields)) {
            return $mapped_fields;
        }

        $action_slug = sanitize_key((string) ($recipe['action_slug'] ?? ''));
        switch ($action_slug) {
            case 'slack_message_create':
                return self::dispatch_slack_message($connection, $recipe, $execution, $mapped_fields);

            case 'hubspot_contact_upsert':
                return self::dispatch_hubspot_contact($connection, $recipe, $execution, $mapped_fields);

            case 'notion_page_create':
                return self::dispatch_notion_page($connection, $recipe, $execution, $mapped_fields);

            case 'notion_database_item_create':
                return self::dispatch_notion_database_item($connection, $recipe, $execution, $mapped_fields);

            case 'pipedrive_person_upsert':
                return self::dispatch_pipedrive_person($connection, $recipe, $execution, $mapped_fields);

            case 'zapier_webhook_trigger':
            case 'make_webhook_trigger':
            case 'n8n_webhook_trigger':
                return self::dispatch_generic_webhook_trigger($connection, $recipe, $execution, $event_envelope, $mapped_fields);

            default:
                return new WP_Error(
                    'aipkit_recipe_action_not_supported',
                    sprintf(
                        /* translators: %s: action slug */
                        __('Recipe action `%s` is not supported yet.', 'gpt3-ai-content-generator'),
                        $action_slug
                    )
                );
        }
    }

    /**
     * @param array<string, mixed> $connection
     * @param array<string, mixed> $recipe
     * @param array<string, mixed> $execution
     * @param array<string, mixed> $mapped_fields
     * @return array<string, mixed>|WP_Error
     */
    private static function dispatch_slack_message(array $connection, array $recipe, array $execution, array $mapped_fields)
    {
        $title = AIPKit_Recipe_Field_Mapper::stringify_value($mapped_fields['title'] ?? '');
        $body = AIPKit_Recipe_Field_Mapper::stringify_value($mapped_fields['body'] ?? '');
        $fallback_text = AIPKit_Recipe_Field_Mapper::stringify_value($mapped_fields['payload_json'] ?? '');
        $message_text = trim(implode("\n\n", array_filter([$title, $body])));
        if ($message_text === '') {
            $message_text = $fallback_text !== '' ? $fallback_text : __('AIPKit event received.', 'gpt3-ai-content-generator');
        }

        return self::perform_request(
            static function (array $current_connection, array $current_execution = [], array $current_runtime_context = []) use ($mapped_fields, $message_text) {
                $webhook_url = self::get_connection_field($current_connection, 'credentials', 'webhook_url');
                $bot_token = self::get_connection_field($current_connection, 'credentials', 'bot_token');
                $default_channel = self::get_connection_field($current_connection, 'workspace', 'default_channel');
                $configured_auth_type = sanitize_key((string) ($current_connection['auth_type'] ?? ''));
                $auth_type = $configured_auth_type !== ''
                    ? $configured_auth_type
                    : ($webhook_url !== '' && $bot_token === '' ? 'webhook' : 'token');

                if ($auth_type === 'webhook') {
                    if ($webhook_url === '') {
                        return new WP_Error(
                            'aipkit_slack_connection_incomplete',
                            __('Slack webhook auth requires a webhook URL.', 'gpt3-ai-content-generator')
                        );
                    }

                    return [
                        'endpoint' => $webhook_url,
                        'method' => 'POST',
                        'headers' => [
                            'Content-Type' => 'application/json; charset=utf-8',
                        ],
                        'body' => [
                            'text' => $message_text,
                            'channel' => AIPKit_Recipe_Field_Mapper::stringify_value($mapped_fields['channel'] ?? ''),
                            'username' => AIPKit_Recipe_Field_Mapper::stringify_value($mapped_fields['username'] ?? ''),
                            'icon_emoji' => AIPKit_Recipe_Field_Mapper::stringify_value($mapped_fields['icon_emoji'] ?? ''),
                        ],
                        'body_format' => 'json',
                        'meta' => [
                            'adapter' => 'slack_incoming_webhook',
                        ],
                    ];
                }

                if ($bot_token === '' || $default_channel === '') {
                    return new WP_Error(
                        'aipkit_slack_connection_incomplete',
                        __('Slack needs either a webhook URL or a bot token with a default channel.', 'gpt3-ai-content-generator')
                    );
                }

                return [
                    'endpoint' => 'https://slack.com/api/chat.postMessage',
                    'method' => 'POST',
                    'headers' => [
                        'Authorization' => 'Bearer ' . $bot_token,
                        'Content-Type' => 'application/json; charset=utf-8',
                    ],
                    'body' => [
                        'channel' => AIPKit_Recipe_Field_Mapper::stringify_value($mapped_fields['channel'] ?? $default_channel),
                        'text' => $message_text,
                    ],
                    'body_format' => 'json',
                    'meta' => [
                        'adapter' => 'slack_chat_post_message',
                    ],
                ];
            },
            $execution,
            static function (array $decoded_body, int $http_code = 0) {
                if (!empty($decoded_body['ok'])) {
                    return [
                        'external_id' => sanitize_text_field((string) ($decoded_body['ts'] ?? '')),
                        'message' => __('Slack message sent.', 'gpt3-ai-content-generator'),
                    ];
                }

                $error_code = sanitize_key((string) ($decoded_body['error'] ?? 'unknown_error'));
                return new WP_Error(
                    'aipkit_slack_send_failed',
                    sanitize_text_field((string) ($decoded_body['error'] ?? __('Slack rejected the message.', 'gpt3-ai-content-generator'))),
                    [
                        'status' => in_array($error_code, ['invalid_auth', 'token_revoked', 'not_authed'], true) ? 'reauth_required' : 'error',
                        'http_code' => $http_code,
                        'details' => $decoded_body,
                    ]
                );
            },
            [
                'recipe' => $recipe,
                'connection' => $connection,
            ]
        );
    }

    /**
     * @param array<string, mixed> $connection
     * @param array<string, mixed> $recipe
     * @param array<string, mixed> $execution
     * @param array<string, mixed> $mapped_fields
     * @return array<string, mixed>|WP_Error
     */
    private static function dispatch_hubspot_contact(array $connection, array $recipe, array $execution, array $mapped_fields)
    {
        $email = AIPKit_Recipe_Field_Mapper::stringify_value($mapped_fields['email'] ?? '');
        if ($email === '') {
            return new WP_Error(
                'aipkit_hubspot_email_required',
                __('HubSpot contact upsert requires an email mapping.', 'gpt3-ai-content-generator')
            );
        }

        $properties = [];
        foreach (['email', 'firstname', 'lastname', 'phone', 'company', 'jobtitle', 'website'] as $field_key) {
            $value = AIPKit_Recipe_Field_Mapper::stringify_value($mapped_fields[$field_key] ?? '');
            if ($value !== '') {
                $properties[$field_key] = $value;
            }
        }

        return self::perform_request(
            static function (array $current_connection, array $current_execution = [], array $current_runtime_context = []) use ($email, $properties) {
                $token = self::get_connection_field($current_connection, 'credentials', 'private_app_token');
                if ($token === '') {
                    return new WP_Error(
                        'aipkit_hubspot_connection_incomplete',
                        __('HubSpot private app token is required.', 'gpt3-ai-content-generator')
                    );
                }

                return [
                    'endpoint' => 'https://api.hubapi.com/crm/v3/objects/contacts/batch/upsert',
                    'method' => 'POST',
                    'headers' => [
                        'Authorization' => 'Bearer ' . $token,
                        'Content-Type' => 'application/json; charset=utf-8',
                    ],
                    'body' => [
                        'inputs' => [
                            [
                                'idProperty' => 'email',
                                'id' => $email,
                                'properties' => $properties,
                            ],
                        ],
                    ],
                    'body_format' => 'json',
                    'meta' => [
                        'adapter' => 'hubspot_contacts_batch_upsert',
                    ],
                ];
            },
            $execution,
            static function (array $decoded_body, int $http_code = 0) {
                $first_result = isset($decoded_body['results'][0]) && is_array($decoded_body['results'][0])
                    ? $decoded_body['results'][0]
                    : [];

                if (!empty($first_result)) {
                    return [
                        'external_id' => sanitize_text_field((string) ($first_result['id'] ?? '')),
                        'message' => __('HubSpot contact synced.', 'gpt3-ai-content-generator'),
                    ];
                }

                return new WP_Error(
                    'aipkit_hubspot_upsert_failed',
                    __('HubSpot did not return a contact result.', 'gpt3-ai-content-generator'),
                    [
                        'status' => 'error',
                        'details' => $decoded_body,
                    ]
                );
            },
            [
                'recipe' => $recipe,
                'connection' => $connection,
            ]
        );
    }

    /**
     * @param array<string, mixed> $connection
     * @param array<string, mixed> $recipe
     * @param array<string, mixed> $execution
     * @param array<string, mixed> $mapped_fields
     * @return array<string, mixed>|WP_Error
     */
    private static function dispatch_notion_page(array $connection, array $recipe, array $execution, array $mapped_fields)
    {
        $title = AIPKit_Recipe_Field_Mapper::stringify_value($mapped_fields['title'] ?? '');
        if ($title === '') {
            $title = sanitize_text_field((string) ($recipe['name'] ?? __('AIPKit Recipe Page', 'gpt3-ai-content-generator')));
        }

        $children = self::build_notion_children([
            $mapped_fields['content'] ?? '',
            $mapped_fields['summary'] ?? '',
            $mapped_fields['excerpt'] ?? '',
            $mapped_fields['source_url'] ?? '',
        ]);

        return self::perform_request(
            static function (array $current_connection, array $current_execution = [], array $current_runtime_context = []) use ($title, $children) {
                $token = self::get_connection_field($current_connection, 'credentials', 'integration_token');
                $parent_page_id = self::get_connection_field($current_connection, 'workspace', 'parent_page_id');
                if ($token === '' || $parent_page_id === '') {
                    return new WP_Error(
                        'aipkit_notion_page_connection_incomplete',
                        __('Notion page creation needs an integration token and parent page ID.', 'gpt3-ai-content-generator')
                    );
                }

                return [
                    'endpoint' => 'https://api.notion.com/v1/pages',
                    'method' => 'POST',
                    'headers' => self::get_notion_headers($token),
                    'body' => [
                        'parent' => [
                            'type' => 'page_id',
                            'page_id' => $parent_page_id,
                        ],
                        'properties' => [
                            'title' => [
                                'title' => [
                                    [
                                        'text' => [
                                            'content' => $title,
                                        ],
                                    ],
                                ],
                            ],
                        ],
                        'children' => $children,
                    ],
                    'body_format' => 'json',
                    'meta' => [
                        'adapter' => 'notion_page_create',
                    ],
                ];
            },
            $execution,
            static function (array $decoded_body, int $http_code = 0) {
                if (!empty($decoded_body['id'])) {
                    return [
                        'external_id' => sanitize_text_field((string) $decoded_body['id']),
                        'message' => __('Notion page created.', 'gpt3-ai-content-generator'),
                    ];
                }

                return new WP_Error(
                    'aipkit_notion_page_failed',
                    __('Notion did not return a page ID.', 'gpt3-ai-content-generator'),
                    [
                        'status' => 'error',
                        'details' => $decoded_body,
                    ]
                );
            },
            [
                'recipe' => $recipe,
                'connection' => $connection,
            ]
        );
    }

    /**
     * @param array<string, mixed> $connection
     * @param array<string, mixed> $recipe
     * @param array<string, mixed> $execution
     * @param array<string, mixed> $mapped_fields
     * @return array<string, mixed>|WP_Error
     */
    private static function dispatch_notion_database_item(array $connection, array $recipe, array $execution, array $mapped_fields)
    {
        $database_id = self::get_connection_field($connection, 'workspace', 'database_id');
        if ($database_id === '') {
            return new WP_Error(
                'aipkit_notion_database_connection_incomplete',
                __('Notion database items need an integration token and database ID.', 'gpt3-ai-content-generator')
            );
        }

        $schema = self::get_notion_database_schema($database_id, $execution, $recipe, $connection);
        if (is_wp_error($schema)) {
            return $schema;
        }

        $properties = self::build_notion_database_properties($schema, $mapped_fields, $recipe);
        if (empty($properties)) {
            return new WP_Error(
                'aipkit_notion_database_mapping_invalid',
                __('No valid Notion database properties could be built from the current mapping.', 'gpt3-ai-content-generator')
            );
        }

        $children = self::build_notion_children([
            $mapped_fields['summary'] ?? '',
            $mapped_fields['feedback'] ?? '',
            $mapped_fields['asset_url'] ?? '',
            $mapped_fields['source_url'] ?? '',
        ]);

        return self::perform_request(
            static function (array $current_connection, array $current_execution = [], array $current_runtime_context = []) use ($database_id, $properties, $children) {
                $token = self::get_connection_field($current_connection, 'credentials', 'integration_token');
                if ($token === '') {
                    return new WP_Error(
                        'aipkit_notion_database_connection_incomplete',
                        __('Notion database items need an integration token and database ID.', 'gpt3-ai-content-generator')
                    );
                }

                return [
                    'endpoint' => 'https://api.notion.com/v1/pages',
                    'method' => 'POST',
                    'headers' => self::get_notion_headers($token),
                    'body' => [
                        'parent' => [
                            'database_id' => $database_id,
                        ],
                        'properties' => $properties,
                        'children' => $children,
                    ],
                    'body_format' => 'json',
                    'meta' => [
                        'adapter' => 'notion_database_item_create',
                    ],
                ];
            },
            $execution,
            static function (array $decoded_body, int $http_code = 0) {
                if (!empty($decoded_body['id'])) {
                    return [
                        'external_id' => sanitize_text_field((string) $decoded_body['id']),
                        'message' => __('Notion database item created.', 'gpt3-ai-content-generator'),
                    ];
                }

                return new WP_Error(
                    'aipkit_notion_database_item_failed',
                    __('Notion did not return a database item ID.', 'gpt3-ai-content-generator'),
                    [
                        'status' => 'error',
                        'details' => $decoded_body,
                    ]
                );
            },
            [
                'recipe' => $recipe,
                'connection' => $connection,
            ]
        );
    }

    /**
     * @param array<string, mixed> $connection
     * @param array<string, mixed> $recipe
     * @param array<string, mixed> $execution
     * @param array<string, mixed> $mapped_fields
     * @return array<string, mixed>|WP_Error
     */
    private static function dispatch_pipedrive_person(array $connection, array $recipe, array $execution, array $mapped_fields)
    {
        $api_token = self::get_connection_field($connection, 'credentials', 'api_token');
        $company_domain = self::normalize_pipedrive_domain(self::get_connection_field($connection, 'workspace', 'company_domain'));
        $name = AIPKit_Recipe_Field_Mapper::stringify_value($mapped_fields['name'] ?? '');

        if ($api_token === '' || $company_domain === '') {
            return new WP_Error(
                'aipkit_pipedrive_connection_incomplete',
                __('Pipedrive person recipes need an API token and company domain.', 'gpt3-ai-content-generator')
            );
        }

        if ($name === '') {
            return new WP_Error(
                'aipkit_pipedrive_name_required',
                __('Pipedrive person recipes need a Name mapping.', 'gpt3-ai-content-generator')
            );
        }

        $email = AIPKit_Recipe_Field_Mapper::stringify_value($mapped_fields['email'] ?? '');
        $org_name = AIPKit_Recipe_Field_Mapper::stringify_value($mapped_fields['org_name'] ?? '');
        $organization_id = null;

        if ($org_name !== '') {
            $organization_id = self::resolve_pipedrive_organization_id(
                $company_domain,
                $api_token,
                $org_name,
                $execution,
                $recipe,
                $connection
            );

            if (is_wp_error($organization_id)) {
                return $organization_id;
            }
        }

        $existing_person_id = self::find_pipedrive_person_id(
            $company_domain,
            $api_token,
            $email,
            $execution,
            $recipe,
            $connection
        );

        if (is_wp_error($existing_person_id)) {
            return $existing_person_id;
        }

        $person_payload = self::build_pipedrive_person_payload($mapped_fields, $name, $connection, $organization_id);
        $is_update = $existing_person_id !== null && $existing_person_id > 0;
        $endpoint = self::build_pipedrive_endpoint(
            $company_domain,
            $is_update ? '/api/v2/persons/' . (int) $existing_person_id : '/api/v2/persons',
            ['api_token' => $api_token]
        );

        return self::perform_request(
            static function (array $current_connection = [], array $current_execution = [], array $current_runtime_context = []) use ($endpoint, $person_payload, $is_update): array {
                return [
                    'endpoint' => $endpoint,
                    'method' => $is_update ? 'PATCH' : 'POST',
                    'headers' => [
                        'Accept' => 'application/json',
                        'Content-Type' => 'application/json; charset=utf-8',
                    ],
                    'body' => $person_payload,
                    'body_format' => 'json',
                    'meta' => [
                        'adapter' => $is_update ? 'pipedrive_person_update' : 'pipedrive_person_create',
                    ],
                ];
            },
            $execution,
            static function (array $decoded_body) {
                $data = isset($decoded_body['data']) && is_array($decoded_body['data']) ? $decoded_body['data'] : [];
                $person_id = max(0, (int) ($data['id'] ?? 0));
                if ($person_id > 0) {
                    return [
                        'external_id' => (string) $person_id,
                        'message' => __('Pipedrive person synced.', 'gpt3-ai-content-generator'),
                    ];
                }

                return new WP_Error(
                    'aipkit_pipedrive_person_sync_failed',
                    __('Pipedrive did not return a person result.', 'gpt3-ai-content-generator'),
                    [
                        'status' => 'error',
                        'details' => $decoded_body,
                    ]
                );
            },
            [
                'recipe' => $recipe,
                'connection' => $connection,
            ]
        );
    }

    /**
     * @param array<string, mixed> $connection
     * @param array<string, mixed> $recipe
     * @param array<string, mixed> $execution
     * @param array<string, mixed> $event_envelope
     * @param array<string, mixed> $mapped_fields
     * @return array<string, mixed>|WP_Error
     */
    private static function dispatch_generic_webhook_trigger(
        array $connection,
        array $recipe,
        array $execution,
        array $event_envelope,
        array $mapped_fields
    ) {
        $webhook_url = self::get_connection_field($connection, 'credentials', 'webhook_url');
        if ($webhook_url === '') {
            return new WP_Error(
                'aipkit_recipe_webhook_url_missing',
                __('This recipe needs a webhook URL on the selected app connection.', 'gpt3-ai-content-generator')
            );
        }

        $app_slug = sanitize_key((string) ($recipe['app_slug'] ?? $connection['app_slug'] ?? ''));
        $payload = self::build_generic_webhook_payload($recipe, $event_envelope, $mapped_fields);

        return self::perform_request(
            static function (array $current_connection = [], array $current_execution = [], array $current_runtime_context = []) use ($webhook_url, $app_slug, $payload): array {
                return [
                    'endpoint' => $webhook_url,
                    'method' => 'POST',
                    'headers' => [
                        'Accept' => 'application/json',
                        'Content-Type' => 'application/json; charset=utf-8',
                    ],
                    'body' => $payload,
                    'body_format' => 'json',
                    'meta' => [
                        'adapter' => $app_slug . '_webhook_trigger',
                    ],
                ];
            },
            $execution,
            static function (array $decoded_body) use ($app_slug): array {
                $external_id = sanitize_text_field((string) ($decoded_body['id'] ?? ($decoded_body['request_id'] ?? '')));

                return [
                    'external_id' => $external_id,
                    'message' => sprintf(
                        /* translators: %s: app label */
                        __('%s webhook delivered.', 'gpt3-ai-content-generator'),
                        ucfirst($app_slug)
                    ),
                ];
            },
            [
                'recipe' => $recipe,
                'connection' => $connection,
            ]
        );
    }

    /**
     * @param array<string, mixed> $recipe
     * @param array<string, mixed> $event_envelope
     * @param array<string, mixed> $mapped_fields
     * @return array<string, mixed>
     */
    private static function build_generic_webhook_payload(array $recipe, array $event_envelope, array $mapped_fields): array
    {
        $custom_payload = self::decode_recipe_payload_json($mapped_fields['payload_json'] ?? '');
        if (is_array($custom_payload) && !empty($custom_payload)) {
            return $custom_payload;
        }

        $payload = [
            'event' => [
                'id' => sanitize_text_field((string) ($event_envelope['id'] ?? '')),
                'type' => sanitize_text_field((string) ($event_envelope['type'] ?? '')),
                'occurred_at' => sanitize_text_field((string) ($event_envelope['occurred_at'] ?? '')),
                'source' => isset($event_envelope['source']) && is_array($event_envelope['source']) ? $event_envelope['source'] : [],
                'resource' => isset($event_envelope['resource']) && is_array($event_envelope['resource']) ? $event_envelope['resource'] : [],
            ],
            'recipe' => [
                'id' => sanitize_text_field((string) ($recipe['id'] ?? '')),
                'name' => sanitize_text_field((string) ($recipe['name'] ?? '')),
                'app_slug' => sanitize_key((string) ($recipe['app_slug'] ?? '')),
                'action_slug' => sanitize_key((string) ($recipe['action_slug'] ?? '')),
            ],
            'mapped_fields' => $mapped_fields,
            'data' => isset($event_envelope['data']) && is_array($event_envelope['data']) ? $event_envelope['data'] : [],
            'meta' => isset($event_envelope['meta']) && is_array($event_envelope['meta']) ? $event_envelope['meta'] : [],
        ];

        $title = AIPKit_Recipe_Field_Mapper::stringify_value($mapped_fields['title'] ?? '');
        $body = AIPKit_Recipe_Field_Mapper::stringify_value($mapped_fields['body'] ?? '');
        $source_url = esc_url_raw(AIPKit_Recipe_Field_Mapper::stringify_value($mapped_fields['source_url'] ?? ''));

        if ($title !== '') {
            $payload['title'] = $title;
        }

        if ($body !== '') {
            $payload['body'] = $body;
        }

        if ($source_url !== '') {
            $payload['source_url'] = $source_url;
        }

        $payload_json = AIPKit_Recipe_Field_Mapper::stringify_value($mapped_fields['payload_json'] ?? '');
        if ($payload_json !== '') {
            $payload['payload_json'] = $payload_json;
        }

        return $payload;
    }

    /**
     * @param mixed $raw_payload
     * @return array<string, mixed>|null
     */
    private static function decode_recipe_payload_json($raw_payload): ?array
    {
        $payload_string = AIPKit_Recipe_Field_Mapper::stringify_value($raw_payload);
        if ($payload_string === '') {
            return null;
        }

        $decoded = json_decode($payload_string, true);
        return is_array($decoded) ? $decoded : null;
    }

    /**
     * @param array<string, mixed> $mapped_fields
     * @param array<string, mixed> $connection
     * @return array<string, mixed>
     */
    private static function build_pipedrive_person_payload(
        array $mapped_fields,
        string $name,
        array $connection,
        ?int $organization_id = null
    ): array {
        $payload = [
            'name' => $name,
        ];

        $email = AIPKit_Recipe_Field_Mapper::stringify_value($mapped_fields['email'] ?? '');
        if ($email !== '') {
            $payload['emails'] = [
                [
                    'value' => sanitize_email($email),
                    'primary' => true,
                    'label' => 'work',
                ],
            ];
        }

        $phone = AIPKit_Recipe_Field_Mapper::stringify_value($mapped_fields['phone'] ?? '');
        if ($phone !== '') {
            $payload['phones'] = [
                [
                    'value' => $phone,
                    'primary' => true,
                    'label' => 'work',
                ],
            ];
        }

        if ($organization_id !== null && $organization_id > 0) {
            $payload['org_id'] = $organization_id;
        }

        $default_owner_id = max(0, (int) self::get_connection_field($connection, 'workspace', 'default_owner_id'));
        if ($default_owner_id > 0) {
            $payload['owner_id'] = $default_owner_id;
        }

        return $payload;
    }

    /**
     * @param array<string, mixed> $execution
     * @param array<string, mixed> $recipe
     * @param array<string, mixed> $connection
     * @return int|null|WP_Error
     */
    private static function find_pipedrive_person_id(
        string $company_domain,
        string $api_token,
        string $email,
        array $execution,
        array $recipe,
        array $connection
    ) {
        $normalized_email = sanitize_email($email);
        if ($normalized_email === '') {
            return null;
        }

        $response = self::perform_http_request(
            static function (array $current_connection = [], array $current_execution = [], array $current_runtime_context = []) use ($company_domain, $api_token, $normalized_email): array {
                return [
                    'endpoint' => self::build_pipedrive_endpoint($company_domain, '/api/v2/persons/search', [
                        'api_token' => $api_token,
                        'term' => $normalized_email,
                        'fields' => 'email',
                        'exact_match' => 'true',
                    ]),
                    'method' => 'GET',
                    'headers' => [
                        'Accept' => 'application/json',
                    ],
                    'meta' => [
                        'adapter' => 'pipedrive_person_search',
                    ],
                ];
            },
            $execution,
            [
                'recipe' => $recipe,
                'connection' => $connection,
            ]
        );

        if (is_wp_error($response)) {
            return $response;
        }

        return self::extract_pipedrive_search_item_id(
            isset($response['decoded_body']) && is_array($response['decoded_body']) ? $response['decoded_body'] : []
        );
    }

    /**
     * @param array<string, mixed> $execution
     * @param array<string, mixed> $recipe
     * @param array<string, mixed> $connection
     * @return int|null|WP_Error
     */
    private static function resolve_pipedrive_organization_id(
        string $company_domain,
        string $api_token,
        string $organization_name,
        array $execution,
        array $recipe,
        array $connection
    ) {
        $normalized_name = sanitize_text_field($organization_name);
        if ($normalized_name === '') {
            return null;
        }

        $search_response = self::perform_http_request(
            static function (array $current_connection = [], array $current_execution = [], array $current_runtime_context = []) use ($company_domain, $api_token, $normalized_name): array {
                return [
                    'endpoint' => self::build_pipedrive_endpoint($company_domain, '/api/v2/organizations/search', [
                        'api_token' => $api_token,
                        'term' => $normalized_name,
                        'fields' => 'name',
                        'exact_match' => 'true',
                    ]),
                    'method' => 'GET',
                    'headers' => [
                        'Accept' => 'application/json',
                    ],
                    'meta' => [
                        'adapter' => 'pipedrive_organization_search',
                    ],
                ];
            },
            $execution,
            [
                'recipe' => $recipe,
                'connection' => $connection,
            ]
        );

        if (is_wp_error($search_response)) {
            return $search_response;
        }

        $organization_id = self::extract_pipedrive_search_item_id(
            isset($search_response['decoded_body']) && is_array($search_response['decoded_body'])
                ? $search_response['decoded_body']
                : []
        );

        if ($organization_id !== null && $organization_id > 0) {
            return $organization_id;
        }

        $create_response = self::perform_request(
            static function (array $current_connection = [], array $current_execution = [], array $current_runtime_context = []) use ($company_domain, $api_token, $normalized_name): array {
                return [
                    'endpoint' => self::build_pipedrive_endpoint($company_domain, '/api/v2/organizations', [
                        'api_token' => $api_token,
                    ]),
                    'method' => 'POST',
                    'headers' => [
                        'Accept' => 'application/json',
                        'Content-Type' => 'application/json; charset=utf-8',
                    ],
                    'body' => [
                        'name' => $normalized_name,
                    ],
                    'body_format' => 'json',
                    'meta' => [
                        'adapter' => 'pipedrive_organization_create',
                    ],
                ];
            },
            $execution,
            static function (array $decoded_body) {
                $data = isset($decoded_body['data']) && is_array($decoded_body['data']) ? $decoded_body['data'] : [];
                $organization_id = max(0, (int) ($data['id'] ?? 0));
                if ($organization_id > 0) {
                    return [
                        'external_id' => (string) $organization_id,
                        'message' => __('Pipedrive organization created.', 'gpt3-ai-content-generator'),
                    ];
                }

                return new WP_Error(
                    'aipkit_pipedrive_organization_create_failed',
                    __('Pipedrive did not return an organization result.', 'gpt3-ai-content-generator'),
                    [
                        'status' => 'error',
                        'details' => $decoded_body,
                    ]
                );
            },
            [
                'recipe' => $recipe,
                'connection' => $connection,
            ]
        );

        if (is_wp_error($create_response)) {
            return $create_response;
        }

        $external_id = max(0, (int) ($create_response['dispatch']['external_id'] ?? 0));
        return $external_id > 0 ? $external_id : null;
    }

    /**
     * @param array<string, mixed> $decoded_body
     */
    private static function extract_pipedrive_search_item_id(array $decoded_body): ?int
    {
        $data = isset($decoded_body['data']) && is_array($decoded_body['data']) ? $decoded_body['data'] : [];
        $items = [];

        if (isset($data['items']) && is_array($data['items'])) {
            $items = $data['items'];
        } elseif (self::is_list_array($data)) {
            $items = $data;
        }

        foreach ($items as $item) {
            if (!is_array($item)) {
                continue;
            }

            $candidate = isset($item['item']) && is_array($item['item']) ? $item['item'] : $item;
            $item_id = max(0, (int) ($candidate['id'] ?? 0));
            if ($item_id > 0) {
                return $item_id;
            }
        }

        return null;
    }

    private static function build_pipedrive_endpoint(string $company_domain, string $path, array $query_args = []): string
    {
        $base_url = sprintf('https://%s.pipedrive.com', rawurlencode(self::normalize_pipedrive_domain($company_domain)));
        $endpoint = $base_url . $path;

        if (!empty($query_args)) {
            $endpoint .= '?' . http_build_query($query_args, '', '&', PHP_QUERY_RFC3986);
        }

        return $endpoint;
    }

    private static function normalize_pipedrive_domain(string $domain): string
    {
        $value = trim($domain);
        if ($value === '') {
            return '';
        }

        $value = preg_replace('#^https?://#i', '', $value);
        $value = preg_replace('#/.*$#', '', $value);
        $value = preg_replace('#\.pipedrive\.com$#i', '', $value);

        return sanitize_title($value);
    }

    /**
     * @param callable $request_factory
     * @param array<string, mixed> $execution
     * @param callable|null $success_parser
     * @param array<string, mixed> $runtime_context
     * @return array<string, mixed>|WP_Error
     */
    private static function perform_request(callable $request_factory, array $execution, ?callable $success_parser = null, array $runtime_context = [])
    {
        $http_result = self::perform_http_request($request_factory, $execution, $runtime_context);
        if (is_wp_error($http_result)) {
            return $http_result;
        }

        $decoded_body = isset($http_result['decoded_body']) && is_array($http_result['decoded_body'])
            ? $http_result['decoded_body']
            : [];
        $http_code = (int) ($http_result['http_code'] ?? 0);
        $request = isset($http_result['request']) && is_array($http_result['request'])
            ? $http_result['request']
            : [];
        $raw_body = (string) ($http_result['raw_body'] ?? '');
        $attempt_count = max(1, (int) ($http_result['attempt_count'] ?? 1));

        if (
            (($request['meta']['adapter'] ?? '') === 'slack_incoming_webhook')
            && $http_code >= 200
            && $http_code < 300
            && strtolower(trim($raw_body)) === 'ok'
        ) {
            return [
                'external_id' => '',
                'message' => __('Slack webhook delivered.', 'gpt3-ai-content-generator'),
                'dispatch' => [
                    'http_code' => $http_code,
                    'meta' => $request['meta'] ?? [],
                ],
                'attempt_count' => $attempt_count,
            ];
        }

        $parsed_success = $success_parser ? call_user_func($success_parser, $decoded_body, $http_code) : [
            'external_id' => '',
            'message' => __('Recipe executed successfully.', 'gpt3-ai-content-generator'),
        ];

        if (is_wp_error($parsed_success)) {
            $decorated_error = self::decorate_error($parsed_success, [
                'http_code' => $http_code,
                'attempt_count' => $attempt_count,
                'details' => $decoded_body,
                'request_meta' => $request['meta'] ?? [],
            ]);

            if (self::is_reauth_error($decorated_error) && empty($runtime_context['refresh_attempted'])) {
                $recipe = isset($runtime_context['recipe']) && is_array($runtime_context['recipe']) ? $runtime_context['recipe'] : [];
                $connection = isset($runtime_context['connection']) && is_array($runtime_context['connection']) ? $runtime_context['connection'] : [];
                $normalized_execution = AIPKit_App_Payload_Contracts::normalize_execution_context($execution);
                $normalized_execution['attempt_count'] = $attempt_count;

                $refreshed_connection = AIPKit_App_Token_Refresh::maybe_refresh_connection(
                    $connection,
                    $recipe,
                    $normalized_execution,
                    self::build_failure_context($decorated_error, $request, $decoded_body, $http_code, $attempt_count)
                );

                if (is_wp_error($refreshed_connection)) {
                    return self::decorate_error($refreshed_connection, [
                        'http_code' => $http_code,
                        'attempt_count' => $attempt_count,
                        'details' => $decoded_body,
                        'request_meta' => $request['meta'] ?? [],
                    ]);
                }

                if (is_array($refreshed_connection) && !empty($refreshed_connection)) {
                    $retry_result = self::perform_request($request_factory, $execution, $success_parser, array_merge($runtime_context, [
                        'connection' => $refreshed_connection,
                        'refresh_attempted' => true,
                    ]));

                    if (is_wp_error($retry_result)) {
                        $retry_error_data = $retry_result->get_error_data();
                        return self::decorate_error($retry_result, [
                            'attempt_count' => max(
                                $attempt_count,
                                is_array($retry_error_data) ? (int) ($retry_error_data['attempt_count'] ?? 1) : 1
                            ),
                        ]);
                    }

                    $retry_attempt_count = max(1, (int) ($retry_result['attempt_count'] ?? 1));
                    $retry_result['attempt_count'] = max($attempt_count + 1, $retry_attempt_count);
                    if (isset($retry_result['dispatch']['meta']) && is_array($retry_result['dispatch']['meta'])) {
                        $retry_result['dispatch']['meta']['attempt_count'] = $retry_result['attempt_count'];
                    }

                    return $retry_result;
                }
            }

            return $decorated_error;
        }

        $dispatch_result = AIPKit_App_Payload_Contracts::normalize_dispatch_result([
            'status' => 'sent',
            'external_id' => $parsed_success['external_id'] ?? '',
            'http_code' => $http_code,
            'message' => $parsed_success['message'] ?? __('Recipe executed successfully.', 'gpt3-ai-content-generator'),
            'meta' => [
                'request_meta' => $request['meta'] ?? [],
                'attempt_count' => $attempt_count,
            ],
        ]);

        return [
            'status' => 'completed',
            'request' => $request,
            'dispatch' => $dispatch_result,
            'attempt_count' => $attempt_count,
        ];
    }

    /**
     * @param array<string, mixed> $connection
     */
    private static function get_connection_field(array $connection, string $group, string $key): string
    {
        return AIPKit_App_Connections::get_connection_field_value($connection, $group, $key);
    }

    /**
     * @param array<string, mixed> $decoded_body
     */
    private static function extract_remote_error_message(array $decoded_body, string $raw_body, int $http_code): string
    {
        foreach (['message', 'error', 'detail'] as $field_key) {
            $value = sanitize_text_field((string) ($decoded_body[$field_key] ?? ''));
            if ($value !== '') {
                return $value;
            }
        }

        return sprintf(
            /* translators: %d: HTTP status code */
            __('Remote request failed with HTTP %d.', 'gpt3-ai-content-generator'),
            $http_code
        );
    }

    /**
     * @return array<string, string>
     */
    private static function get_notion_headers(string $token): array
    {
        return [
            'Authorization' => 'Bearer ' . $token,
            'Notion-Version' => '2022-06-28',
            'Content-Type' => 'application/json; charset=utf-8',
        ];
    }

    /**
     * @return array<string, mixed>|WP_Error
     */
    private static function get_notion_database_schema(string $database_id, array $execution, array $recipe, array $connection)
    {
        $response = self::perform_http_request(
            static function (array $current_connection, array $current_execution = [], array $current_runtime_context = []) use ($database_id) {
                $token = self::get_connection_field($current_connection, 'credentials', 'integration_token');
                if ($token === '') {
                    return new WP_Error(
                        'aipkit_notion_database_connection_incomplete',
                        __('Notion database items need an integration token and database ID.', 'gpt3-ai-content-generator')
                    );
                }

                return [
                    'endpoint' => 'https://api.notion.com/v1/databases/' . rawurlencode($database_id),
                    'method' => 'GET',
                    'headers' => self::get_notion_headers($token),
                    'timeout' => 20,
                    'meta' => [
                        'adapter' => 'notion_database_schema',
                    ],
                ];
            },
            $execution,
            [
                'recipe' => $recipe,
                'connection' => $connection,
            ]
        );

        if (is_wp_error($response)) {
            return $response;
        }

        return isset($response['decoded_body']) && is_array($response['decoded_body'])
            ? $response['decoded_body']
            : [];
    }

    /**
     * @param callable $request_factory
     * @param array<string, mixed> $execution
     * @param array<string, mixed> $runtime_context
     * @return array<string, mixed>|WP_Error
     */
    private static function perform_http_request(callable $request_factory, array $execution, array $runtime_context = [])
    {
        $normalized_execution = AIPKit_App_Payload_Contracts::normalize_execution_context($execution);
        $recipe = isset($runtime_context['recipe']) && is_array($runtime_context['recipe']) ? $runtime_context['recipe'] : [];
        $connection = isset($runtime_context['connection']) && is_array($runtime_context['connection']) ? $runtime_context['connection'] : [];
        if (empty($connection)) {
            return new WP_Error(
                'aipkit_recipe_connection_missing',
                __('Recipe connection could not be resolved.', 'gpt3-ai-content-generator')
            );
        }

        $max_attempts = max(1, (int) apply_filters(
            'aipkit_native_app_recipe_max_attempts',
            3,
            $recipe,
            $normalized_execution,
            $connection,
            $runtime_context
        ));
        $did_refresh = false;

        for ($attempt_count = 1; $attempt_count <= $max_attempts; $attempt_count++) {
            $normalized_execution['attempt_count'] = $attempt_count;

            $request_payload = call_user_func($request_factory, $connection, $normalized_execution, $runtime_context);
            if (is_wp_error($request_payload)) {
                return self::decorate_error($request_payload, [
                    'attempt_count' => $attempt_count,
                ]);
            }

            $normalized_request = AIPKit_App_Payload_Contracts::normalize_request_payload(is_array($request_payload) ? $request_payload : []);
            $endpoint = (string) ($normalized_request['endpoint'] ?? '');
            if ($endpoint === '') {
                return new WP_Error(
                    'aipkit_recipe_request_missing_endpoint',
                    __('Destination endpoint is missing.', 'gpt3-ai-content-generator'),
                    [
                        'status' => 'error',
                        'attempt_count' => $attempt_count,
                    ]
                );
            }

            $response = wp_remote_request($endpoint, self::build_request_args($normalized_request));
            if (is_wp_error($response)) {
                $transport_error = self::decorate_error(new WP_Error(
                    'aipkit_recipe_request_transport_failed',
                    __('The app request could not reach the remote destination.', 'gpt3-ai-content-generator'),
                    [
                        'status' => 'error',
                        'retryable' => true,
                        'details' => ['error' => $response->get_error_message()],
                    ]
                ), [
                    'attempt_count' => $attempt_count,
                    'request_meta' => $normalized_request['meta'] ?? [],
                ]);

                if ($attempt_count < $max_attempts && self::should_retry_error($transport_error)) {
                    self::maybe_delay_retry($transport_error, $recipe, $normalized_execution, $runtime_context);
                    continue;
                }

                return $transport_error;
            }

            $http_code = (int) wp_remote_retrieve_response_code($response);
            $raw_body = wp_remote_retrieve_body($response);
            $decoded_body = json_decode((string) $raw_body, true);
            if (!is_array($decoded_body)) {
                $decoded_body = [];
            }

            if ($http_code < 200 || $http_code >= 300) {
                $http_error = self::build_http_error(
                    $http_code,
                    $decoded_body,
                    (string) $raw_body,
                    $normalized_request,
                    $response,
                    $attempt_count
                );

                if (self::is_reauth_error($http_error) && !$did_refresh) {
                    $refreshed_connection = AIPKit_App_Token_Refresh::maybe_refresh_connection(
                        $connection,
                        $recipe,
                        $normalized_execution,
                        self::build_failure_context($http_error, $normalized_request, $decoded_body, $http_code, $attempt_count)
                    );

                    if (is_array($refreshed_connection) && !empty($refreshed_connection)) {
                        $connection = $refreshed_connection;
                        $did_refresh = true;
                        continue;
                    }

                    if (is_wp_error($refreshed_connection)) {
                        return self::decorate_error($refreshed_connection, [
                            'attempt_count' => $attempt_count,
                            'http_code' => $http_code,
                            'details' => $decoded_body,
                            'request_meta' => $normalized_request['meta'] ?? [],
                        ]);
                    }
                }

                if ($attempt_count < $max_attempts && self::should_retry_error($http_error)) {
                    self::maybe_delay_retry($http_error, $recipe, $normalized_execution, $runtime_context);
                    continue;
                }

                return $http_error;
            }

            return [
                'request' => $normalized_request,
                'http_code' => $http_code,
                'raw_body' => (string) $raw_body,
                'decoded_body' => $decoded_body,
                'attempt_count' => $attempt_count,
                'response_headers' => [
                    'retry_after' => sanitize_text_field((string) wp_remote_retrieve_header($response, 'retry-after')),
                ],
            ];
        }

        return new WP_Error(
            'aipkit_recipe_request_failed',
            __('The app request failed after all retry attempts.', 'gpt3-ai-content-generator'),
            [
                'status' => 'error',
                'attempt_count' => $max_attempts,
            ]
        );
    }

    /**
     * @param array<string, mixed> $normalized_request
     * @return array<string, mixed>
     */
    private static function build_request_args(array $normalized_request): array
    {
        $request_args = [
            'method' => $normalized_request['method'],
            'headers' => $normalized_request['headers'],
            'timeout' => $normalized_request['timeout'],
        ];

        switch ($normalized_request['body_format']) {
            case 'form':
                $request_args['body'] = is_array($normalized_request['body']) ? $normalized_request['body'] : [];
                break;

            case 'raw':
                $request_args['body'] = AIPKit_Recipe_Field_Mapper::stringify_value($normalized_request['body']);
                break;

            case 'json':
            default:
                if (!in_array($normalized_request['method'], ['GET', 'HEAD'], true)) {
                    $request_args['body'] = wp_json_encode($normalized_request['body']);
                }
                break;
        }

        return $request_args;
    }

    /**
     * @param array<string, mixed> $decoded_body
     * @param array<string, mixed> $normalized_request
     * @param mixed $response
     */
    private static function build_http_error(
        int $http_code,
        array $decoded_body,
        string $raw_body,
        array $normalized_request,
        $response,
        int $attempt_count
    ): WP_Error {
        $retry_after = self::extract_retry_after_seconds($response);
        $status = in_array($http_code, [401, 403], true) ? 'reauth_required' : 'error';

        return new WP_Error(
            'aipkit_recipe_request_failed',
            self::extract_remote_error_message($decoded_body, $raw_body, $http_code),
            [
                'status' => $status,
                'http_code' => $http_code,
                'details' => $decoded_body,
                'retry_after' => $retry_after,
                'retryable' => $status !== 'reauth_required' && self::is_retryable_http_code($http_code),
                'attempt_count' => $attempt_count,
                'request_meta' => $normalized_request['meta'] ?? [],
            ]
        );
    }

    /**
     * @param array<string, mixed> $request
     * @param array<string, mixed> $decoded_body
     * @return array<string, mixed>
     */
    private static function build_failure_context(
        WP_Error $error,
        array $request,
        array $decoded_body,
        int $http_code,
        int $attempt_count
    ): array {
        return [
            'error_code' => $error->get_error_code(),
            'error_message' => $error->get_error_message(),
            'error_data' => is_array($error->get_error_data()) ? $error->get_error_data() : [],
            'http_code' => $http_code,
            'attempt_count' => $attempt_count,
            'request' => $request,
            'response_body' => $decoded_body,
        ];
    }

    private static function should_retry_error(WP_Error $error): bool
    {
        $error_data = $error->get_error_data();
        if (!is_array($error_data)) {
            return false;
        }

        if (!empty($error_data['retryable'])) {
            return true;
        }

        $http_code = (int) ($error_data['http_code'] ?? 0);
        if ($http_code > 0) {
            return self::is_retryable_http_code($http_code);
        }

        return false;
    }

    private static function is_reauth_error(WP_Error $error): bool
    {
        $error_data = $error->get_error_data();
        return is_array($error_data) && sanitize_key((string) ($error_data['status'] ?? '')) === 'reauth_required';
    }

    private static function is_retryable_http_code(int $http_code): bool
    {
        return in_array($http_code, [408, 409, 425, 429, 500, 502, 503, 504], true);
    }

    /**
     * @param array<string, mixed> $execution
     * @param array<string, mixed> $runtime_context
     */
    private static function maybe_delay_retry(WP_Error $error, array $recipe, array $execution, array $runtime_context = []): void
    {
        $error_data = $error->get_error_data();
        $retry_after = is_array($error_data) ? max(0, (int) ($error_data['retry_after'] ?? 0)) : 0;
        $delay_seconds = (float) apply_filters(
            'aipkit_native_app_recipe_retry_delay_seconds',
            $retry_after > 0 ? min($retry_after, 2) : 0,
            $error,
            $recipe,
            $execution,
            $runtime_context
        );

        if ($delay_seconds <= 0) {
            return;
        }

        usleep((int) round($delay_seconds * 1000000));
    }

    /**
     * @param mixed $response
     */
    private static function extract_retry_after_seconds($response): int
    {
        $retry_after = wp_remote_retrieve_header($response, 'retry-after');
        if ($retry_after === '') {
            return 0;
        }

        if (is_numeric($retry_after)) {
            return max(0, (int) $retry_after);
        }

        $retry_after_timestamp = strtotime((string) $retry_after);
        if ($retry_after_timestamp === false) {
            return 0;
        }

        return max(0, $retry_after_timestamp - time());
    }

    /**
     * @param array<string, mixed> $extra_data
     */
    private static function decorate_error(WP_Error $error, array $extra_data = []): WP_Error
    {
        $existing_data = $error->get_error_data();
        $merged_data = is_array($existing_data) ? $existing_data : [];

        foreach ($extra_data as $data_key => $data_value) {
            if ($data_value === null || $data_value === '') {
                continue;
            }

            $merged_data[$data_key] = $data_value;
        }

        if (!isset($merged_data['status'])) {
            $merged_data['status'] = 'error';
        }

        return new WP_Error(
            $error->get_error_code(),
            $error->get_error_message(),
            $merged_data
        );
    }

    /**
     * @param array<string, mixed> $schema
     * @param array<string, mixed> $mapped_fields
     * @param array<string, mixed> $recipe
     * @return array<string, mixed>
     */
    private static function build_notion_database_properties(array $schema, array $mapped_fields, array $recipe): array
    {
        $properties = isset($schema['properties']) && is_array($schema['properties']) ? $schema['properties'] : [];
        if (empty($properties)) {
            return [];
        }

        $property_name_map = [];
        $title_property_name = '';
        foreach ($properties as $property_name => $property_schema) {
            if (!is_array($property_schema)) {
                continue;
            }

            $normalized_property_name = strtolower(trim((string) $property_name));
            $property_name_map[$normalized_property_name] = $property_name;
            if (($property_schema['type'] ?? '') === 'title' && $title_property_name === '') {
                $title_property_name = (string) $property_name;
            }
        }

        $result = [];
        $title_value = AIPKit_Recipe_Field_Mapper::stringify_value($mapped_fields['title'] ?? '');
        if ($title_value === '') {
            $title_value = sanitize_text_field((string) ($recipe['name'] ?? __('AIPKit Item', 'gpt3-ai-content-generator')));
        }

        if ($title_property_name !== '') {
            $result[$title_property_name] = [
                'title' => [
                    [
                        'text' => [
                            'content' => $title_value,
                        ],
                    ],
                ],
            ];
        }

        $aliases = [
            'summary' => ['summary', 'description', 'details'],
            'feedback' => ['feedback'],
            'status' => ['status'],
            'asset_url' => ['asset url', 'asset_url', 'url', 'link'],
            'source_url' => ['source url', 'source_url', 'url', 'link'],
            'bot_name' => ['bot name', 'bot_name', 'bot'],
            'tags' => ['tags'],
        ];

        foreach ($aliases as $target_field => $candidate_names) {
            $value = $mapped_fields[$target_field] ?? null;
            if ($value === null || $value === '') {
                continue;
            }

            $property_name = '';
            foreach ($candidate_names as $candidate_name) {
                if (isset($property_name_map[strtolower($candidate_name)])) {
                    $property_name = $property_name_map[strtolower($candidate_name)];
                    break;
                }
            }

            if ($property_name === '' || !isset($properties[$property_name]) || !is_array($properties[$property_name])) {
                continue;
            }

            $property_payload = self::build_notion_property_payload($properties[$property_name], $value);
            if ($property_payload === null) {
                continue;
            }

            $result[$property_name] = $property_payload;
        }

        return $result;
    }

    /**
     * @param array<string, mixed> $property_schema
     * @param mixed $value
     * @return array<string, mixed>|null
     */
    private static function build_notion_property_payload(array $property_schema, $value): ?array
    {
        $type = sanitize_key((string) ($property_schema['type'] ?? ''));
        $string_value = AIPKit_Recipe_Field_Mapper::stringify_value($value);

        switch ($type) {
            case 'title':
                return [
                    'title' => [
                        [
                            'text' => [
                                'content' => $string_value,
                            ],
                        ],
                    ],
                ];

            case 'rich_text':
                return [
                    'rich_text' => [
                        [
                            'text' => [
                                'content' => $string_value,
                            ],
                        ],
                    ],
                ];

            case 'url':
                return [
                    'url' => esc_url_raw($string_value),
                ];

            case 'email':
                return [
                    'email' => sanitize_email($string_value),
                ];

            case 'phone_number':
                return [
                    'phone_number' => $string_value,
                ];

            case 'number':
                return [
                    'number' => is_numeric($value) ? 0 + $value : null,
                ];

            case 'checkbox':
                return [
                    'checkbox' => in_array(strtolower($string_value), ['1', 'true', 'yes', 'on'], true),
                ];

            case 'select':
                return [
                    'select' => [
                        'name' => $string_value,
                    ],
                ];

            case 'status':
                return [
                    'status' => [
                        'name' => $string_value,
                    ],
                ];

            case 'multi_select':
                $items = preg_split('/[\n,]+/', $string_value) ?: [];
                $items = array_values(array_filter(array_map('trim', $items), 'strlen'));
                return [
                    'multi_select' => array_map(static fn(string $item): array => ['name' => $item], $items),
                ];

            default:
                return null;
        }
    }

    /**
     * @param array<int, mixed> $sources
     * @return array<int, array<string, mixed>>
     */
    private static function build_notion_children(array $sources): array
    {
        $children = [];
        foreach ($sources as $source) {
            $text = AIPKit_Recipe_Field_Mapper::stringify_value($source);
            if ($text === '') {
                continue;
            }

            $paragraphs = preg_split("/\n{2,}/", $text) ?: [];
            foreach ($paragraphs as $paragraph) {
                $paragraph = trim($paragraph);
                if ($paragraph === '') {
                    continue;
                }

                $children[] = [
                    'object' => 'block',
                    'type' => 'paragraph',
                    'paragraph' => [
                        'rich_text' => [
                            [
                                'type' => 'text',
                                'text' => [
                                    'content' => mb_substr($paragraph, 0, 1800),
                                ],
                            ],
                        ],
                    ],
                ];
            }
        }

        return array_slice($children, 0, 20);
    }

    private static function is_list_array(array $array): bool
    {
        $expected_key = 0;
        foreach ($array as $key => $_value) {
            if ($key !== $expected_key) {
                return false;
            }
            $expected_key++;
        }
        return true;
    }
}

/**
 * Shared runtime payload contracts for premium Native App Recipes adapters.
 *
 * These helpers normalize the array shapes exchanged between:
 * - the recipe executor
 * - app-specific payload builders
 * - app adapters
 */
class AIPKit_App_Payload_Contracts
{
    /**
     * @param array<string, mixed> $execution_context
     * @return array<string, mixed>
     */
    public static function normalize_execution_context(array $execution_context): array
    {
        return [
            'recipe_id' => sanitize_text_field((string) ($execution_context['recipe_id'] ?? '')),
            'connection_id' => sanitize_text_field((string) ($execution_context['connection_id'] ?? '')),
            'event_name' => sanitize_text_field((string) ($execution_context['event_name'] ?? '')),
            'event_id' => sanitize_text_field((string) ($execution_context['event_id'] ?? '')),
            'app_slug' => sanitize_key((string) ($execution_context['app_slug'] ?? '')),
            'action_slug' => sanitize_key((string) ($execution_context['action_slug'] ?? '')),
            'template_slug' => sanitize_key((string) ($execution_context['template_slug'] ?? '')),
            'attempt_count' => max(0, (int) ($execution_context['attempt_count'] ?? 0)),
            'meta' => self::normalize_meta_map($execution_context['meta'] ?? []),
        ];
    }

    /**
     * @param array<string, mixed> $request_payload
     * @return array<string, mixed>
     */
    public static function normalize_request_payload(array $request_payload): array
    {
        $body_format = sanitize_key((string) ($request_payload['body_format'] ?? 'json'));
        if (!in_array($body_format, ['json', 'form', 'raw'], true)) {
            $body_format = 'json';
        }

        return [
            'status' => sanitize_key((string) ($request_payload['status'] ?? 'prepared')),
            'endpoint' => esc_url_raw((string) ($request_payload['endpoint'] ?? '')),
            'method' => strtoupper(sanitize_key((string) ($request_payload['method'] ?? 'POST'))),
            'headers' => self::normalize_string_map($request_payload['headers'] ?? []),
            'body' => is_array($request_payload['body'] ?? null) ? $request_payload['body'] : [],
            'body_format' => $body_format,
            'timeout' => max(1, (int) ($request_payload['timeout'] ?? 15)),
            'meta' => self::normalize_meta_map($request_payload['meta'] ?? []),
        ];
    }

    /**
     * @param array<string, mixed> $dispatch_result
     * @return array<string, mixed>
     */
    public static function normalize_dispatch_result(array $dispatch_result): array
    {
        return [
            'status' => sanitize_key((string) ($dispatch_result['status'] ?? 'sent')),
            'external_id' => sanitize_text_field((string) ($dispatch_result['external_id'] ?? '')),
            'http_code' => max(0, (int) ($dispatch_result['http_code'] ?? 0)),
            'message' => sanitize_text_field((string) ($dispatch_result['message'] ?? '')),
            'meta' => self::normalize_meta_map($dispatch_result['meta'] ?? []),
        ];
    }

    /**
     * @param mixed $headers
     * @return array<string, string>
     */
    private static function normalize_string_map($headers): array
    {
        if (!is_array($headers)) {
            return [];
        }

        $normalized = [];
        foreach ($headers as $key => $value) {
            $normalized_key = sanitize_text_field((string) $key);
            if ($normalized_key === '') {
                continue;
            }

            $normalized[$normalized_key] = sanitize_text_field((string) $value);
        }

        return $normalized;
    }

    /**
     * @param mixed $meta
     * @return array<string, mixed>
     */
    private static function normalize_meta_map($meta): array
    {
        if (!is_array($meta)) {
            return [];
        }

        return $meta;
    }
}
