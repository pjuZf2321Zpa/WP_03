<?php

namespace BitApps\IntegrationsPro\Actions\RestaurantReservations;

use rtbBooking;
use rtbBookingAdmission;
use rtbNotificationEmail;

final class RestaurantReservationsProHelper
{
    public const POST_TYPE = 'rtb-booking';

    public static function createBooking($defaultResponse, $fieldData, $utilities = null, $integrationDetails = null)
    {
        if (!self::isPluginActive()) {
            return ['success' => false, 'message' => __('Five Star Restaurant Reservations is not installed or activated', 'bit-integrations-pro')];
        }

        foreach (['name' => __('Name', 'bit-integrations-pro'), 'email' => __('Email', 'bit-integrations-pro'), 'party' => __('Party Size', 'bit-integrations-pro'), 'date' => __('Date', 'bit-integrations-pro'), 'time' => __('Time', 'bit-integrations-pro')] as $key => $label) {
            if (self::value($fieldData, $key) === '') {
                // translators: %s is the field label.
                return ['success' => false, 'message' => \sprintf(__('%s is required. Map a value to the field.', 'bit-integrations-pro'), $label)];
            }
        }

        if (!is_email(self::value($fieldData, 'email'))) {
            return ['success' => false, 'message' => __('Email is not valid. Map a valid email address.', 'bit-integrations-pro')];
        }

        $status = self::conf($integrationDetails, 'selectedStatus');
        $locationId = self::conf($integrationDetails, 'selectedLocation');
        $optionError = self::validateBookingOptions($fieldData, $status, $locationId);

        if ($optionError) {
            return $optionError;
        }

        if (empty($locationId) && !empty(self::getLocationOptions())) {
            return ['success' => false, 'message' => __('Location is required. Select a location.', 'bit-integrations-pro')];
        }

        $bookingDate = self::buildBookingDate(self::value($fieldData, 'date'), self::value($fieldData, 'time'));

        if (!$bookingDate) {
            return ['success' => false, 'message' => __('Date or time is not valid. Use the YYYY-MM-DD date and HH:MM time format.', 'bit-integrations-pro')];
        }

        $booking = new rtbBooking();
        $booking->name = self::value($fieldData, 'name');
        $booking->email = self::value($fieldData, 'email');
        $booking->phone = self::value($fieldData, 'phone');
        $booking->party = (int) self::value($fieldData, 'party');
        $booking->message = self::value($fieldData, 'message');
        $booking->date = $bookingDate;
        $booking->location = empty($locationId) ? 0 : (int) $locationId;
        $booking->table = self::parseTables(self::conf($integrationDetails, 'selectedTables'));
        $booking->cancellation_code = \function_exists('rtb_random_string') ? rtb_random_string() : '';

        if (empty($status)) {
            $booking->determine_status(true);
        } else {
            $booking->post_status = $status;
            $booking->temp_confirmed_user = get_current_user_id();
        }

        $booking->set_admin_request();

        $saved = self::runWithNotificationSetting(
            self::isChecked($utilities, 'send_notifications'),
            static function () use ($booking) {
                if (!$booking->insert_post_data()) {
                    return false;
                }

                do_action('rtb_insert_booking', $booking);

                return true;
            }
        );

        if (!$saved) {
            return ['success' => false, 'message' => self::getValidationMessage($booking, __('The booking was not saved. Another booking change can be running. Try again.', 'bit-integrations-pro'))];
        }

        return ['success' => true, 'message' => __('The booking is created.', 'bit-integrations-pro'), 'data' => self::getBookingData($booking->ID)];
    }

    public static function updateBooking($defaultResponse, $fieldData, $utilities = null, $integrationDetails = null)
    {
        $booking = self::loadTargetBooking($fieldData);

        if (\is_array($booking)) {
            return $booking;
        }

        if ($booking->post_status === 'trash') {
            return ['success' => false, 'message' => __('The booking is in the trash. Restore the booking before you update it.', 'bit-integrations-pro')];
        }

        $email = self::value($fieldData, 'email');

        if ($email !== '' && !is_email($email)) {
            return ['success' => false, 'message' => __('Email is not valid. Map a valid email address.', 'bit-integrations-pro')];
        }

        $status = self::conf($integrationDetails, 'selectedStatus');
        $locationId = self::conf($integrationDetails, 'selectedLocation');
        $optionError = self::validateBookingOptions($fieldData, $status, $locationId);

        if ($optionError) {
            return $optionError;
        }

        $date = self::value($fieldData, 'date');
        $time = self::value($fieldData, 'time');

        if ($date !== '' || $time !== '') {
            $bookingDate = self::buildBookingDate(
                $date === '' ? mysql2date('Y-m-d', $booking->date) : $date,
                $time === '' ? mysql2date('H:i:s', $booking->date) : $time
            );

            if (!$bookingDate) {
                return ['success' => false, 'message' => __('Date or time is not valid. Use the YYYY-MM-DD date and HH:MM time format.', 'bit-integrations-pro')];
            }

            $booking->date = $bookingDate;
        }

        foreach (['name', 'email', 'phone', 'message'] as $key) {
            if (self::value($fieldData, $key) !== '') {
                $booking->{$key} = self::value($fieldData, $key);
            }
        }

        if (self::value($fieldData, 'party') !== '') {
            $booking->party = (int) self::value($fieldData, 'party');
        }

        if (!empty($locationId)) {
            $booking->location = (int) $locationId;
        }

        $tables = self::parseTables(self::conf($integrationDetails, 'selectedTables'));

        if (!empty($tables)) {
            $booking->table = $tables;
        }

        if (!empty($status)) {
            $booking->post_status = $status;
            $booking->temp_confirmed_user = get_current_user_id();
        }

        $booking->set_admin_request();

        $saved = self::runWithNotificationSetting(
            self::isChecked($utilities, 'send_notifications'),
            static function () use ($booking) {
                if (!$booking->insert_post_data()) {
                    return false;
                }

                do_action('rtb_update_booking', $booking);

                return true;
            }
        );

        if (!$saved) {
            return ['success' => false, 'message' => self::getValidationMessage($booking, __('The booking was not updated. Another booking change can be running. Try again.', 'bit-integrations-pro'))];
        }

        return ['success' => true, 'message' => __('The booking is updated.', 'bit-integrations-pro'), 'data' => self::getBookingData($booking->ID)];
    }

    public static function changeBookingStatus($defaultResponse, $fieldData, $utilities = null, $integrationDetails = null)
    {
        $booking = self::loadTargetBooking($fieldData);

        if (\is_array($booking)) {
            return $booking;
        }

        if ($booking->post_status === 'trash') {
            return ['success' => false, 'message' => __('The booking is in the trash. Restore the booking before you change it.', 'bit-integrations-pro')];
        }

        $status = self::conf($integrationDetails, 'selectedStatus');

        if (empty($status) || !self::isValidStatus($status)) {
            return ['success' => false, 'message' => __('Status is not valid. Select a status from the list.', 'bit-integrations-pro')];
        }

        $previousStatus = $booking->post_status;
        $sendNotifications = self::isChecked($utilities, 'send_notifications');

        $result = self::runWithNotificationSetting(
            $sendNotifications,
            static function () use ($booking, $status, $sendNotifications) {
                return rtbBookingAdmission::mutate($booking->ID, ['status' => $status], '', get_current_user_id(), false, $sendNotifications);
            }
        );

        if (is_wp_error($result)) {
            return ['success' => false, 'message' => $result->get_error_message()];
        }

        $data = self::getBookingData($booking->ID);
        $data['previous_status'] = $previousStatus;
        $data['previous_status_label'] = self::getStatusLabel($previousStatus);

        return ['success' => true, 'message' => __('The booking status is changed.', 'bit-integrations-pro'), 'data' => $data];
    }

    public static function assignTables($defaultResponse, $fieldData, $integrationDetails = null)
    {
        $booking = self::loadTargetBooking($fieldData);

        if (\is_array($booking)) {
            return $booking;
        }

        if ($booking->post_status === 'trash') {
            return ['success' => false, 'message' => __('The booking is in the trash. Restore the booking before you change it.', 'bit-integrations-pro')];
        }

        $tables = self::parseTables(self::conf($integrationDetails, 'selectedTables'));

        if (empty($tables)) {
            return ['success' => false, 'message' => __('Tables are required. Select one or more tables.', 'bit-integrations-pro')];
        }

        $result = rtbBookingAdmission::mutate($booking->ID, ['table' => $tables], '', get_current_user_id());

        if (is_wp_error($result)) {
            return ['success' => false, 'message' => $result->get_error_message()];
        }

        return ['success' => true, 'message' => __('The tables are assigned.', 'bit-integrations-pro'), 'data' => self::getBookingData($booking->ID)];
    }

    public static function trashBooking($defaultResponse, $fieldData)
    {
        $booking = self::loadTargetBooking($fieldData);

        if (\is_array($booking)) {
            return $booking;
        }

        if ($booking->post_status === 'trash') {
            return ['success' => false, 'message' => __('The booking is already in the trash.', 'bit-integrations-pro')];
        }

        $bookingData = self::getBookingData($booking->ID);

        if (!rtbBookingAdmission::delete($booking->ID)) {
            return ['success' => false, 'message' => __('The booking was not moved to the trash. Try again.', 'bit-integrations-pro')];
        }

        $trashedBooking = self::getBookingData($booking->ID);

        return [
            'success' => true,
            'message' => __('The booking is moved to the trash.', 'bit-integrations-pro'),
            'data'    => empty($trashedBooking) ? array_merge($bookingData, ['deleted' => true]) : $trashedBooking,
        ];
    }

    public static function restoreBooking($defaultResponse, $fieldData)
    {
        $booking = self::loadTargetBooking($fieldData);

        if (\is_array($booking)) {
            return $booking;
        }

        if ($booking->post_status !== 'trash') {
            return ['success' => false, 'message' => __('The booking is not in the trash. Map the ID of a trashed booking.', 'bit-integrations-pro')];
        }

        $previousStatus = get_post_meta($booking->ID, '_wp_trash_meta_status', true);

        if (!self::isValidStatus($previousStatus)) {
            $previousStatus = 'pending';
        }

        // The plugin's status change checks capacity and tables again before the booking takes a slot.
        $result = rtbBookingAdmission::mutate($booking->ID, ['status' => $previousStatus], '', get_current_user_id());

        if (is_wp_error($result)) {
            return ['success' => false, 'message' => $result->get_error_message()];
        }

        delete_post_meta($booking->ID, '_wp_trash_meta_status');
        delete_post_meta($booking->ID, '_wp_trash_meta_time');

        return ['success' => true, 'message' => __('The booking is restored.', 'bit-integrations-pro'), 'data' => self::getBookingData($booking->ID)];
    }

    public static function deleteBooking($defaultResponse, $fieldData)
    {
        $booking = self::loadTargetBooking($fieldData);

        if (\is_array($booking)) {
            return $booking;
        }

        $bookingData = self::getBookingData($booking->ID);

        if (!rtbBookingAdmission::delete($booking->ID, true)) {
            return ['success' => false, 'message' => __('The booking was not deleted. Try again.', 'bit-integrations-pro')];
        }

        return [
            'success' => true,
            'message' => __('The booking is deleted.', 'bit-integrations-pro'),
            'data'    => ['booking_id' => $bookingData['booking_id'], 'deleted' => true, 'booking' => $bookingData],
        ];
    }

    public static function deleteBookingsByEmail($defaultResponse, $fieldData, $utilities = null)
    {
        if (!self::isPluginActive()) {
            return ['success' => false, 'message' => __('Five Star Restaurant Reservations is not installed or activated', 'bit-integrations-pro')];
        }

        $email = self::value($fieldData, 'email');

        if (!is_email($email)) {
            return ['success' => false, 'message' => __('Email is required. Map a valid email address.', 'bit-integrations-pro')];
        }

        $deletePermanently = self::isChecked($utilities, 'delete_permanently');
        $bookingIds = self::getBookingIdsByEmail($email, self::getAllStatusKeys($deletePermanently));

        if (empty($bookingIds)) {
            return ['success' => false, 'message' => __('No booking uses this email. Map the email of a guest who has a booking.', 'bit-integrations-pro')];
        }

        $deletedIds = [];
        $failedIds = [];

        foreach ($bookingIds as $bookingId) {
            if (rtbBookingAdmission::delete($bookingId, $deletePermanently)) {
                $deletedIds[] = $bookingId;
            } else {
                $failedIds[] = $bookingId;
            }
        }

        return [
            'success' => !empty($deletedIds),
            'message' => empty($deletedIds)
                ? __('No booking was deleted. Try again.', 'bit-integrations-pro')
                : __('The bookings are deleted.', 'bit-integrations-pro'),
            'data' => [
                'email'               => $email,
                'deleted_permanently' => $deletePermanently,
                'deleted_count'       => \count($deletedIds),
                'deleted_ids'         => $deletedIds,
                'failed_ids'          => $failedIds,
            ],
        ];
    }

    public static function sendEmailToCustomer($defaultResponse, $fieldData)
    {
        global $rtb_controller;

        $booking = self::loadTargetBooking($fieldData);

        if (\is_array($booking)) {
            return $booking;
        }

        $message = self::value($fieldData, 'message');

        if ($message === '') {
            return ['success' => false, 'message' => __('Message is required. Map a value to the Message field.', 'bit-integrations-pro')];
        }

        if (!class_exists('rtbNotificationEmail') || empty($rtb_controller->notifications)) {
            return ['success' => false, 'message' => __('The plugin email service is not ready. Activate Five Star Restaurant Reservations.', 'bit-integrations-pro')];
        }

        if (empty($booking->email)) {
            return ['success' => false, 'message' => __('The booking has no email address. Add an email to the booking.', 'bit-integrations-pro')];
        }

        $subject = self::value($fieldData, 'subject');

        $email = new rtbNotificationEmail('admin_email_notice', 'user');
        $email->subject = $subject === '' ? $rtb_controller->settings->get_setting('subject-admin-notice') : $subject;
        $email->message = $message;
        $email->set_booking($booking);

        if (!$rtb_controller->notifications->dispatch_notification($email)) {
            return ['success' => false, 'message' => __('The email was not sent. Check the site mail settings.', 'bit-integrations-pro')];
        }

        $booking->add_log('email', $email->subject, $email->message);

        return [
            'success' => true,
            'message' => __('The email is sent.', 'bit-integrations-pro'),
            'data'    => [
                'booking_id' => (int) $booking->ID,
                'to'         => $booking->email,
                'subject'    => $email->subject,
                'message'    => $email->message,
                'sent'       => true,
                'log_saved'  => (bool) $booking->insert_post_data(),
            ],
        ];
    }

    public static function banEmail($defaultResponse, $fieldData)
    {
        if (!self::isPluginActive()) {
            return ['success' => false, 'message' => __('Five Star Restaurant Reservations is not installed or activated', 'bit-integrations-pro')];
        }

        $email = self::value($fieldData, 'email');

        if (!is_email($email)) {
            return ['success' => false, 'message' => __('Email is required. Map a valid email address.', 'bit-integrations-pro')];
        }

        $alreadyBanned = self::isBanned('ban-emails', $email);

        if (!$alreadyBanned && !self::addToBanList('ban-emails', $email)) {
            return ['success' => false, 'message' => __('The ban list was not saved. Try again.', 'bit-integrations-pro')];
        }

        return ['success' => true, 'message' => __('The email is banned.', 'bit-integrations-pro'), 'data' => ['email' => $email, 'banned' => true, 'already_banned' => $alreadyBanned]];
    }

    public static function banIpAddress($defaultResponse, $fieldData)
    {
        if (!self::isPluginActive()) {
            return ['success' => false, 'message' => __('Five Star Restaurant Reservations is not installed or activated', 'bit-integrations-pro')];
        }

        $ipAddress = self::value($fieldData, 'ip');

        if (filter_var($ipAddress, FILTER_VALIDATE_IP) === false) {
            return ['success' => false, 'message' => __('IP address is not valid. Map an IPv4 or IPv6 address.', 'bit-integrations-pro')];
        }

        $alreadyBanned = self::isBanned('ban-ips', $ipAddress);

        if (!$alreadyBanned && !self::addToBanList('ban-ips', $ipAddress)) {
            return ['success' => false, 'message' => __('The ban list was not saved. Try again.', 'bit-integrations-pro')];
        }

        return ['success' => true, 'message' => __('The IP address is banned.', 'bit-integrations-pro'), 'data' => ['ip' => $ipAddress, 'banned' => true, 'already_banned' => $alreadyBanned]];
    }

    public static function getBookingData($bookingId)
    {
        $booking = self::loadBooking($bookingId);

        if (!$booking) {
            return [];
        }

        $submittedAt = is_numeric($booking->date_submission)
            ? wp_date('Y-m-d H:i:s', (int) $booking->date_submission)
            : '';

        return [
            'booking_id'        => (int) $booking->ID,
            'name'              => $booking->name,
            'email'             => $booking->email,
            'phone'             => $booking->phone,
            'party'             => (int) $booking->party,
            'date_time'         => $booking->date,
            'date'              => mysql2date('Y-m-d', $booking->date),
            'time'              => mysql2date('H:i', $booking->date),
            'message'           => $booking->message,
            'status'            => $booking->post_status,
            'status_label'      => self::getStatusLabel($booking->post_status),
            'location_id'       => (int) $booking->location,
            'location_name'     => self::getLocationName($booking->location),
            'tables'            => implode(', ', array_map('strval', (array) $booking->table)),
            'deposit'           => $booking->deposit,
            'receipt_id'        => $booking->receipt_id,
            'cancellation_code' => $booking->cancellation_code,
            'consent_acquired'  => (bool) $booking->consent_acquired,
            'confirmed_user'    => (int) $booking->confirmed_user,
            'staff_walk_in'     => (bool) $booking->staff_walk_in,
            'ip'                => $booking->ip,
            'submitted_at'      => $submittedAt,
            'custom_fields'     => (array) $booking->custom_fields,
        ];
    }

    public static function getStatusLabel($status)
    {
        $statuses = self::getBookingStatuses();

        if (isset($statuses[$status]['label'])) {
            return $statuses[$status]['label'];
        }

        $statusObject = get_post_status_object($status);

        return $statusObject ? $statusObject->label : (string) $status;
    }

    public static function isPluginActive()
    {
        return \defined('RTB_VERSION') && class_exists('rtbBooking');
    }

    private static function loadBooking($bookingId)
    {
        if (!self::isPluginActive() || empty($bookingId)) {
            return;
        }

        $booking = new rtbBooking();

        return $booking->load_post((int) $bookingId) ? $booking : null;
    }

    private static function loadTargetBooking($fieldData)
    {
        if (!self::isPluginActive()) {
            return ['success' => false, 'message' => __('Five Star Restaurant Reservations is not installed or activated', 'bit-integrations-pro')];
        }

        $bookingId = self::value($fieldData, 'booking_id');

        if ($bookingId === '' || !is_numeric($bookingId)) {
            return ['success' => false, 'message' => __('Booking ID is required. Map a booking ID field.', 'bit-integrations-pro')];
        }

        $booking = self::loadBooking($bookingId);

        if (!$booking) {
            return ['success' => false, 'message' => __('Booking not found. Map the ID of an existing booking.', 'bit-integrations-pro')];
        }

        return $booking;
    }

    private static function validateBookingOptions($fieldData, $status, $locationId)
    {
        $party = self::value($fieldData, 'party');

        if ($party !== '' && (!is_numeric($party) || (int) $party < 1)) {
            return ['success' => false, 'message' => __('Party size must be 1 or more. Map the number of guests.', 'bit-integrations-pro')];
        }

        if (!empty($status) && !self::isValidStatus($status)) {
            return ['success' => false, 'message' => __('Status is not valid. Select a status from the list.', 'bit-integrations-pro')];
        }

        if (!empty($locationId) && !self::isValidLocation($locationId)) {
            return ['success' => false, 'message' => __('Location is not valid. Select a location from the list.', 'bit-integrations-pro')];
        }
    }

    private static function getBookingStatuses()
    {
        global $rtb_controller;

        return (array) ($rtb_controller->cpts->booking_statuses ?? []);
    }

    private static function isValidStatus($status)
    {
        return \is_string($status) && \array_key_exists($status, self::getBookingStatuses());
    }

    private static function isLocationEnabled()
    {
        global $rtb_controller;

        return !empty($rtb_controller->locations->post_type)
            && taxonomy_exists($rtb_controller->locations->location_taxonomy);
    }

    private static function getLocationOptions()
    {
        global $rtb_controller;

        return self::isLocationEnabled() ? (array) $rtb_controller->locations->get_location_options() : [];
    }

    private static function isValidLocation($locationId)
    {
        return \array_key_exists((int) $locationId, self::getLocationOptions());
    }

    private static function getLocationName($locationId)
    {
        if (empty($locationId) || !self::isLocationEnabled()) {
            return '';
        }

        $term = get_term((int) $locationId);

        return ($term && !is_wp_error($term)) ? $term->name : '';
    }

    private static function getAllStatusKeys($withTrash)
    {
        $statuses = array_merge(array_keys(self::getBookingStatuses()), ['draft']);

        return $withTrash ? array_merge($statuses, ['trash']) : $statuses;
    }

    private static function getBookingIdsByEmail($email, $statuses)
    {
        $email = strtolower(trim((string) $email));
        $bookingIds = [];

        $posts = get_posts(
            [
                'post_type'      => self::POST_TYPE,
                'post_status'    => $statuses,
                'posts_per_page' => -1,
                'meta_query'     => [['key' => 'rtb', 'value' => $email, 'compare' => 'LIKE']], // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query
            ]
        );

        foreach ($posts as $post) {
            $meta = get_post_meta($post->ID, 'rtb', true);

            if (\is_array($meta) && strtolower(trim((string) ($meta['email'] ?? ''))) === $email) {
                $bookingIds[] = (int) $post->ID;
            }
        }

        return $bookingIds;
    }

    private static function buildBookingDate($date, $time)
    {
        $dateTime = date_create(trim($date . ' ' . $time), wp_timezone());

        return $dateTime ? $dateTime->format('Y-m-d H:i:s') : null;
    }

    private static function parseTables($tables)
    {
        if (!\is_array($tables)) {
            $tables = explode(',', (string) $tables);
        }

        return array_values(array_unique(array_filter(array_map('trim', array_map('strval', $tables)), 'strlen')));
    }

    private static function getValidationMessage($booking, $fallbackMessage)
    {
        $messages = [];

        foreach ((array) $booking->validation_errors as $error) {
            if (!empty($error['message'])) {
                $messages[] = html_entity_decode($error['message'], ENT_QUOTES);
            }
        }

        return empty($messages) ? $fallbackMessage : implode(' ', $messages);
    }

    // Same switch the plugin's admin modal uses to save a booking without emails.
    private static function runWithNotificationSetting($sendNotifications, callable $callback)
    {
        global $rtb_controller;

        $notifications = $rtb_controller->notifications ?? null;

        if (!$notifications) {
            return $callback();
        }

        $previousSetting = $notifications->notifications_disabled;
        $notifications->notifications_disabled = !$sendNotifications;

        $result = $callback();

        $notifications->notifications_disabled = $previousSetting;

        return $result;
    }

    private static function getBanList($settingKey)
    {
        global $rtb_controller;

        $values = preg_split('/\r\n|\r|\n/', (string) $rtb_controller->settings->get_setting($settingKey));

        return array_values(array_filter(array_map('trim', $values), 'strlen'));
    }

    private static function isBanned($settingKey, $value)
    {
        return \in_array($value, self::getBanList($settingKey), true);
    }

    private static function addToBanList($settingKey, $value)
    {
        global $rtb_controller;

        $bannedValues = self::getBanList($settingKey);
        $bannedValues[] = $value;

        $rtb_controller->settings->settings[$settingKey] = implode("\n", $bannedValues);

        return update_option('rtb-settings', $rtb_controller->settings->settings);
    }

    private static function value($fieldData, $key)
    {
        $value = \is_array($fieldData) ? ($fieldData[$key] ?? '') : ($fieldData->{$key} ?? '');

        return \is_scalar($value) ? trim((string) $value) : '';
    }

    private static function conf($source, $key)
    {
        if (\is_object($source)) {
            return $source->{$key} ?? null;
        }

        return \is_array($source) ? ($source[$key] ?? null) : null;
    }

    private static function isChecked($utilities, $key)
    {
        $value = self::conf($utilities, $key);

        return $value === true || $value === 'true' || $value === '1' || $value === 1;
    }
}
