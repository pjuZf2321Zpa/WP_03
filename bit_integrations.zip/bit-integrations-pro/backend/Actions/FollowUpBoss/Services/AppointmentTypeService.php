<?php

namespace BitApps\IntegrationsPro\Actions\FollowUpBoss\Services;

final class AppointmentTypeService extends BaseService
{
    public function createAppointmentType(): array
    {
        $validationRules = [
            'name'         => ['required'],
            'order_weight' => ['nullable', 'integer'],
        ];
        $error = $this->validateFields(
            $validationRules,
            [
                'name'         => __('Name', 'bit-integrations-pro'),
                'order_weight' => __('Sort Order', 'bit-integrations-pro'),
            ]
        );

        if ($error !== null) {
            return $error;
        }

        $payload = $this->removeEmptyValues(
            [
                'name'        => $this->getString('name'),
                'orderWeight' => $this->getInteger('order_weight'),
            ]
        );

        return $this->dispatch('POST', '/appointmentTypes', $payload);
    }

    public function updateAppointmentType(): array
    {
        $validationRules = [
            'type_id'      => ['required', 'integer'],
            'order_weight' => ['nullable', 'integer'],
        ];
        $error = $this->validateFields(
            $validationRules,
            [
                'type_id'      => __('Appointment Type ID', 'bit-integrations-pro'),
                'order_weight' => __('Sort Order', 'bit-integrations-pro'),
            ]
        );

        if ($error !== null) {
            return $error;
        }

        $payload = $this->removeEmptyValues(
            [
                'name'        => $this->getString('name'),
                'orderWeight' => $this->getInteger('order_weight'),
            ]
        );

        return $this->dispatch('PUT', '/appointmentTypes/' . rawurlencode($this->getString('type_id')), $payload);
    }

    public function deleteAppointmentType(): array
    {
        $validationRules = [
            'type_id'        => ['required', 'integer'],
            'assign_type_id' => ['required', 'integer'],
        ];
        $error = $this->validateFields(
            $validationRules,
            [
                'type_id'        => __('Appointment Type ID', 'bit-integrations-pro'),
                'assign_type_id' => __('Move Appointments To', 'bit-integrations-pro'),
            ],
            ['assign_type_id']
        );

        if ($error !== null) {
            return $error;
        }

        $query = $this->removeEmptyValues(
            [
                'assignTypeId' => $this->getInteger('assign_type_id'),
            ]
        );

        return $this->dispatch('DELETE', '/appointmentTypes/' . rawurlencode($this->getString('type_id')), null, $query);
    }
}
