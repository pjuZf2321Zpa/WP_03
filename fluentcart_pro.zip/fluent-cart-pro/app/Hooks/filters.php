<?php

/**
 * @var $app FluentCartPro\App\Core\Application
 */


// Used to encrypt/decrypt any value. The same
// key is required to decrypt the encrypted value.
$app->addFilter($app->config->get('app.slug') . '_encryption_key', function ($default) {
    // must return a 16 characters long string, for example:
    return implode('', range('a', 'p')); // abcdefghijklmnop
});

add_filter('fluent_cart/pdf/generate_receipt', function ($pdfPath, $args) {
    return (new \FluentCartPro\App\Services\PDF\OrderReceiptPdfService())->generateReceiptPdf($args['order'], $args['template_id']);
}, 10, 2);

add_filter('fluent_cart/outside_addon/handle_install', function ($value, $args){
    return (new \FluentCartPro\App\Services\BackgroundInstaller())->downloadFromGithub($args);
},10, 2);

add_filter('fluent_cart/outside_addon/handle_cdn_install', function ($value, $args){
    return (new \FluentCartPro\App\Services\BackgroundInstaller())->downloadFromUrl($args);
},10, 2);

add_filter('fluent_cart/module_settings/plugin_addons', function ($addons) {
    $addons['fluent-cart-page-history'] = [
        'title'       => __('FluentCart Page History', 'fluent-cart-pro'),
        'description' => __('Track customer browsing journeys before checkout and view page history on order details.', 'fluent-cart-pro'),
        'logo'        => \FluentCart\App\Vite::getAssetUrl('images/cart.svg'),
        'plugin_slug' => 'fluent-cart-page-history',
        'plugin_file' => 'fluent-cart-page-history/fluent-cart-page-history.php',
        'source_type' => 'cdn',
        'source_link' => 'https://fluentcart.com/?fluent-cart=get_license_version',
        'license_required' => [
            'enabled'           => true,
            'parent_product_id' => 21480
        ],
        'upcoming'    => false,
        'repo_link'   => 'https://fluentcart.com/fluentcart-addons/'
    ];

    $addons['fluent-cart-customer-rights'] = [
        'title'       => __('FluentCart Customer Rights', 'fluent-cart-pro'),
        'description' => __('Manage customer withdrawal, refund, return, and cancellation requests with dedicated forms, workflows, notifications, and admin tools. Includes support for the German Withdrawal Button requirement under § 356a BGB.', 'fluent-cart-pro'),
        'logo'        => \FluentCart\App\Vite::getAssetUrl('images/fluent-cart-resolution/logo.svg'),
        'plugin_slug' => 'fluent-cart-customer-rights',
        'plugin_file' => 'fluent-cart-customer-rights/fluent-cart-customer-rights.php',
        'source_type' => 'cdn',
        'source_link' => 'https://addons-cdn.fluentcart.com/fluent-cart-customer-rights.zip',
        'license_required' => [
            'enabled'           => false,
            'parent_product_id' => 21480
        ],
        'upcoming'    => false,
        'repo_link'   => 'https://fluentcart.com/fluentcart-addons/',
        'redirect_url' => '/settings/withdrawal-settings'
    ];

    $addons['fluent-cart-bricks-blocks'] = [
        'title'       => __('FluentCart Bricks Blocks', 'fluent-cart-pro'),
        'description' => __('Enable to get Bricks Builder elements for FluentCart. Requires the Bricks theme.', 'fluent-cart-pro'),
        'logo'        => \FluentCart\App\Vite::getAssetUrl('images/bricks/logo.png'),
        'plugin_slug' => 'fluent-cart-bricks-blocks',
        'plugin_file' => 'fluent-cart-bricks-blocks/fluent-cart-bricks-blocks.php',
        'source_type' => 'cdn',
        'source_link' => 'https://addons-cdn.fluentcart.com/fluent-cart-bricks-blocks.zip',
        'license_required' => [
            'enabled'           => false,
            'parent_product_id' => 21480
        ],
        'upcoming'    => false,
        'repo_link'   => 'https://fluentcart.com/fluentcart-addons/'
    ];

    $addons['fluent-cart-divi-modules'] = [
        'title'       => __('FluentCart Divi Modules', 'fluent-cart-pro'),
        'description' => __('Native Divi 5 modules for FluentCart products, cart, and checkout. Requires Divi 5.0+ and FluentCart 1.3.4+.', 'fluent-cart-pro'),
        'logo'        => \FluentCart\App\Vite::getAssetUrl('images/divi/black.svg'),
        'dark_logo'   => \FluentCart\App\Vite::getAssetUrl('images/divi/white.svg'),
        'plugin_slug' => 'fluent-cart-divi-modules',
        'plugin_file' => 'fluent-cart-divi-modules/fluent-cart-divi-modules.php',
        'source_type' => 'cdn',
        'source_link' => 'https://addons-cdn.fluentcart.com/fluent-cart-divi-modules.zip',
        'license_required' => [
            'enabled'           => false,
            'parent_product_id' => 21480
        ],
        'upcoming'    => false,
        'repo_link'   => 'https://fluentcart.com/fluentcart-addons/'
    ];

    return $addons;
}, 20);

add_filter('fluent_cart/payment_addons', function ($addons) {
    $addons['square-for-fluent-cart'] = [
        'title'            => 'Square',
        'description'      => 'Square payment gateway for FluentCart.',
        'plugin_slug'      => 'square-for-fluent-cart',
        'plugin_file'      => 'square-for-fluent-cart/square-for-fluent-cart.php',
        'source_type'      => 'cdn',
        'source_link' => 'https://fluentcart.com/?fluent-cart=get_license_version',
        'license_required' => [
            'enabled'           => true,
            'parent_product_id' => 21480
        ],
        'upcoming'    => false,
        'repo_link'   => 'https://fluentcart.com/fluentcart-addons/'
    ];

    $addons['airwallex-for-fluent-cart'] = [
        'title'            => 'Airwallex',
        'description'      => __('Airwallex payment gateway for FluentCart.', 'fluent-cart-pro'),
        'plugin_slug'      => 'airwallex-for-fluent-cart',
        'plugin_file'      => 'airwallex-for-fluent-cart/airwallex-for-fluent-cart.php',
        'source_type'      => 'cdn',
        'source_link'      => 'https://fluentcart.com/?fluent-cart=get_license_version',
        'license_required' => [
            'enabled'           => true,
            'parent_product_id' => 21480
        ],
        'upcoming'    => false,
        'repo_link'   => 'https://fluentcart.com/fluentcart-addons/'
    ];

    $addons['sslcommerz-for-fluent-cart'] = [
        'title'       => __('SSLCommerz', 'fluent-cart-pro'),
        'description' => __('SSLCommerz payment gateway for FluentCart.', 'fluent-cart-pro'),
        'logo'        => \FluentCart\App\Vite::getAssetUrl('images/payment-methods/sslcommerz-logo.svg'),
        'plugin_slug' => 'sslcommerz-for-fluent-cart',
        'plugin_file' => 'sslcommerz-for-fluent-cart/sslcommerz-for-fluent-cart.php',
        'source_type' => 'cdn',
        'source_link' => 'https://addons-cdn.fluentcart.com/sslcommerz-for-fluent-cart.zip',
        'license_required' => [
            'enabled'           => false,
            'parent_product_id' => 21480
        ],
        'upcoming'    => false,
        'repo_link'   => 'https://fluentcart.com/fluentcart-addons/'
    ];

    return $addons;
}, 20);

// Load saved views into admin table config via dedicated filter.
$loadSavedViewsIntoTableConfig = function ($tableConfig) {
    $userId = get_current_user_id();

    $views = \FluentCartPro\App\Http\Controllers\SavedViewsController::getViewsForUser($userId);

    foreach ($views as $view) {
        $formatted = \FluentCartPro\App\Http\Controllers\SavedViewsController::formatView($view);
        $tableName = $formatted['object_type'];

        if (!\FluentCartPro\App\Http\Policies\SavedViewsPolicy::userCanAccessObjectType($userId, $tableName)) {
            continue;
        }

        if (!isset($tableConfig[$tableName])) {
            $tableConfig[$tableName] = [];
        }
        if (!isset($tableConfig[$tableName]['saved_views'])) {
            $tableConfig[$tableName]['saved_views'] = [];
        }
        $tableConfig[$tableName]['saved_views'][] = $formatted;
    }

    return $tableConfig;
};

add_filter('fluent_cart/admin_table_saved_views', $loadSavedViewsIntoTableConfig);

$resolveSavedViewForFilter = function ($resolvedView, $args) {
    $slug = sanitize_text_field(\FluentCart\Framework\Support\Arr::get($args, 'slug'));
    $filterName = sanitize_text_field(\FluentCart\Framework\Support\Arr::get($args, 'filter_name'));
    $userId = absint(\FluentCart\Framework\Support\Arr::get($args, 'user_id', get_current_user_id()));

    if (!$slug || !$filterName || !$userId) {
        return $resolvedView;
    }

    return \FluentCartPro\App\Http\Controllers\SavedViewsController::resolveViewForFilter($userId, $filterName, $slug);
};

add_filter('fluent_cart/filter_resolve_saved_view', $resolveSavedViewForFilter, 10, 2);

// Push the required FluentCart core update straight from wordpress.org during the
// WP.org update-check cool-down window (see PluginInstaller for details).
(new \FluentCartPro\App\Services\PluginManager\PluginInstaller())->registerCoreUpdater();
