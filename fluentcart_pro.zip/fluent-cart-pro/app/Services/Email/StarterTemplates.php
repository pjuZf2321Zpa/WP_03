<?php

namespace FluentCartPro\App\Services\Email;

use FluentCart\App\Vite;

class StarterTemplates
{
    /**
     * Get starter templates applicable to a given notification key.
     *
     * @param string $notificationKey
     * @return array
     */
    public static function getTemplatesForNotification($notificationKey)
    {
        $allTemplates = static::getAllTemplates();
        $mapping = static::getNotificationTemplateMapping();

        $templateIds = isset($mapping[$notificationKey]) ? $mapping[$notificationKey] : ['blank'];
        $result = [];

        foreach ($templateIds as $id) {
            if (isset($allTemplates[$id])) {
                $result[] = $allTemplates[$id];
            }
        }

        // Always include blank as last option
        if (!in_array('blank', $templateIds) && isset($allTemplates['blank'])) {
            $result[] = $allTemplates['blank'];
        }

        /**
         * Let add-ons register starter templates for their own notifications. The
         * core mapping only knows core notification keys, so an add-on notification
         * otherwise gets just ['blank'] and the editor opens empty. Prepending a
         * real starter (id !== 'blank', non-empty 'content') makes TemplatePicker
         * auto-apply it instead of showing a blank editor.
         *
         * Each entry: ['id' => string, 'name' => string, 'description' => string,
         * 'thumbnail' => string, 'content' => string]  (content is block markup).
         *
         * @param array $result  resolved starter templates
         * @param array $context ['template' => the notification key being edited]
         */
        $result = apply_filters('fluent_cart_pro/email/starter_templates', $result, ['template' => $notificationKey]);

        return $result;
    }

    /**
     * Get a single template's content by ID.
     *
     * @param string $templateId
     * @return string
     */
    public static function getTemplate($templateId)
    {
        $templates = static::getAllTemplates();
        return isset($templates[$templateId]) ? $templates[$templateId]['content'] : '';
    }

    /**
     * Map notification keys to their applicable starter template IDs.
     *
     * @return array
     */
    private static function getNotificationTemplateMapping()
    {
        return [
            'order_paid_customer'           => ['order_receipt/basic', 'order_receipt/pro', 'order_receipt/modern', 'blank'],
            'order_paid_admin'              => ['admin_order_alert/basic', 'admin_order_alert/pro', 'admin_order_alert/modern', 'blank'],
            'order_placed_admin'            => ['admin_order_alert/basic', 'admin_order_alert/pro', 'admin_order_alert/modern', 'blank'],
            'order_placed_customer'         => ['order_receipt/basic', 'order_receipt/pro', 'order_receipt/modern', 'blank'],
            'order_shipped_customer'        => ['shipping_update/basic', 'shipping_update/pro', 'shipping_update/modern', 'blank'],
            'order_delivered_customer'      => ['shipping_update/basic', 'shipping_update/pro', 'shipping_update/modern', 'blank'],
            'subscription_renewal_customer' => ['renewal_notice/basic', 'renewal_notice/pro', 'renewal_notice/modern', 'blank'],
            'subscription_renewal_admin'    => ['admin_order_alert/basic', 'admin_order_alert/pro', 'admin_order_alert/modern', 'blank'],
            'order_refunded_admin'          => ['refund_confirmation/basic', 'refund_confirmation/pro', 'refund_confirmation/modern', 'blank'],
            'order_refunded_customer'       => ['refund_confirmation/basic', 'refund_confirmation/pro', 'refund_confirmation/modern', 'blank'],
            'subscription_canceled_admin'   => ['subscription_canceled/basic', 'blank'],
            'subscription_canceled_customer' => ['subscription_canceled/basic', 'blank'],
            'invoice_reminder_overdue_admin'    => ['payment_reminder/basic', 'blank'],
            'invoice_reminder_overdue_customer' => ['payment_reminder/basic', 'blank'],
            'subscription_renewal_reminder_admin'    => ['renewal_reminder/basic', 'blank'],
            'subscription_renewal_reminder_customer' => ['renewal_reminder/basic', 'blank'],
            'subscription_trial_end_reminder_admin'    => ['trial_ending/basic', 'blank'],
            'subscription_trial_end_reminder_customer' => ['trial_ending/basic', 'blank'],
        ];
    }

    /**
     * All available starter templates with their block markup.
     *
     * @return array
     */
    private static function getAllTemplates()
    {
        return [
            'order_receipt/basic' => static::buildTemplate(
                'order_receipt/basic',
                __('Order Receipt', 'fluent-cart-pro'),
                __('A complete order receipt with items, addresses, and a call-to-action button.', 'fluent-cart-pro')
            ),
            'order_receipt/pro' => static::buildTemplate(
                'order_receipt/pro',
                __('Order Receipt (Pro)', 'fluent-cart-pro'),
                __('A polished customer receipt with callout summary, billing/shipping details, and a clear next step CTA.', 'fluent-cart-pro')
            ),
            'admin_order_alert/basic' => static::buildTemplate(
                'admin_order_alert/basic',
                __('Admin Order Alert', 'fluent-cart-pro'),
                __('A quick summary for admins with order details and a link to the dashboard.', 'fluent-cart-pro')
            ),
            'admin_order_alert/pro' => static::buildTemplate(
                'admin_order_alert/pro',
                __('Admin Order Alert (Pro)', 'fluent-cart-pro'),
                __('A structured admin alert with customer, payment, and address breakdowns plus dashboard action.', 'fluent-cart-pro')
            ),
            'shipping_update/basic' => static::buildTemplate(
                'shipping_update/basic',
                __('Shipping Update', 'fluent-cart-pro'),
                __('Notify the customer about shipping status with tracking info.', 'fluent-cart-pro')
            ),
            'shipping_update/pro' => static::buildTemplate(
                'shipping_update/pro',
                __('Shipping Update (Pro)', 'fluent-cart-pro'),
                __('A polished shipping notification with KPI strip, items table, addresses, and downloads.', 'fluent-cart-pro')
            ),
            'renewal_notice/basic' => static::buildTemplate(
                'renewal_notice/basic',
                __('Renewal Notice', 'fluent-cart-pro'),
                __('Inform the customer about a successful subscription renewal.', 'fluent-cart-pro')
            ),
            'renewal_notice/pro' => static::buildTemplate(
                'renewal_notice/pro',
                __('Renewal Notice (Pro)', 'fluent-cart-pro'),
                __('A polished renewal confirmation with KPI strip, subscription details, and management CTA.', 'fluent-cart-pro')
            ),
            'refund_confirmation/basic' => static::buildTemplate(
                'refund_confirmation/basic',
                __('Refund Confirmation', 'fluent-cart-pro'),
                __('Confirm a refund with amounts and order reference.', 'fluent-cart-pro')
            ),
            'refund_confirmation/pro' => static::buildTemplate(
                'refund_confirmation/pro',
                __('Refund Confirmation (Pro)', 'fluent-cart-pro'),
                __('A polished refund notice with KPI strip, items summary, and timeline callout.', 'fluent-cart-pro')
            ),
            'order_receipt/modern' => static::buildTemplate(
                'order_receipt/modern',
                __('Order Receipt (Modern)', 'fluent-cart-pro'),
                __('A curated receipt with order details woven into prose — minimal, no data tables.', 'fluent-cart-pro')
            ),
            'admin_order_alert/modern' => static::buildTemplate(
                'admin_order_alert/modern',
                __('Admin Order Alert (Modern)', 'fluent-cart-pro'),
                __('A compact admin alert with order info in prose, customer and payment details below.', 'fluent-cart-pro')
            ),
            'shipping_update/modern' => static::buildTemplate(
                'shipping_update/modern',
                __('Shipping Update (Modern)', 'fluent-cart-pro'),
                __('A clean shipping notice with items listed without prices and inline downloads.', 'fluent-cart-pro')
            ),
            'renewal_notice/modern' => static::buildTemplate(
                'renewal_notice/modern',
                __('Renewal Notice (Modern)', 'fluent-cart-pro'),
                __('A minimal renewal confirmation with amount in prose and a reassurance note.', 'fluent-cart-pro')
            ),
            'refund_confirmation/modern' => static::buildTemplate(
                'refund_confirmation/modern',
                __('Refund Confirmation (Modern)', 'fluent-cart-pro'),
                __('A focused refund notice with refund vs. total highlight and timeline note.', 'fluent-cart-pro')
            ),
            'subscription_canceled/basic' => static::buildTemplate(
                'subscription_canceled/basic',
                __('Subscription Canceled', 'fluent-cart-pro'),
                __('Notify about a subscription cancellation with details and resubscribe CTA.', 'fluent-cart-pro')
            ),
            'payment_reminder/basic' => static::buildTemplate(
                'payment_reminder/basic',
                __('Payment Reminder', 'fluent-cart-pro'),
                __('Remind the customer about a pending payment with order details.', 'fluent-cart-pro')
            ),
            'renewal_reminder/basic' => static::buildTemplate(
                'renewal_reminder/basic',
                __('Renewal Reminder', 'fluent-cart-pro'),
                __('Notify the customer about an upcoming subscription renewal.', 'fluent-cart-pro')
            ),
            'trial_ending/basic' => static::buildTemplate(
                'trial_ending/basic',
                __('Trial Ending', 'fluent-cart-pro'),
                __('Remind the customer that their trial is ending soon and will convert to paid.', 'fluent-cart-pro')
            ),
            'blank' => static::buildTemplate(
                'blank',
                __('Start Blank', 'fluent-cart-pro'),
                __('Start with an empty editor.', 'fluent-cart-pro'),
                false
            ),
        ];
    }

    /**
     * @param string $id
     * @param string $name
     * @param string $description
     * @param bool   $withThumbnail
     * @return array
     */
    private static function buildTemplate($id, $name, $description, $withThumbnail = true)
    {
        return [
            'id'          => $id,
            'name'        => $name,
            'description' => $description,
            'thumbnail'   => $withThumbnail ? static::getTemplateThumbnailUrl($id) : '',
            'content'     => static::getTemplateContent($id),
        ];
    }

    /**
     * @param string $templateId
     * @return string
     */
    private static function getTemplateContent($templateId)
    {
        $templateFile = static::getTemplateFilePath($templateId);

        if (!is_readable($templateFile)) {
            return '';
        }

        ob_start();
        $result = include $templateFile;
        $bufferedOutput = ob_get_clean();

        if (is_string($result) && $result !== '') {
            return $result;
        }

        return is_string($bufferedOutput) ? $bufferedOutput : '';
    }

    /**
     * @param string $templateId
     * @return string
     */
    private static function getTemplateThumbnailUrl($templateId)
    {
        $thumbnailFileName = static::getTemplateThumbnailFileName($templateId);

        if ($thumbnailFileName) {
            $encodedPath = implode('/', array_map('rawurlencode', explode('/', $templateId)));
            return static::getTemplatesBaseUrl() . '/' . $encodedPath . '/' . $thumbnailFileName;
        }

        return static::getDefaultTemplateThumbnailUrl();
    }

    /**
     * @param string $templateId
     * @return string|null
     */
    private static function getTemplateThumbnailFileName($templateId)
    {
        foreach (['thumb.png', 'thump.png'] as $fileName) {
            $thumbPath = static::getTemplateFolderPath($templateId) . DIRECTORY_SEPARATOR . $fileName;
            if (is_readable($thumbPath)) {
                return $fileName;
            }
        }

        return null;
    }

    /**
     * @param string $templateId
     * @return string
     */
    private static function getTemplateFolderPath($templateId)
    {
        return static::getTemplatesBasePath() . DIRECTORY_SEPARATOR . $templateId;
    }

    /**
     * @param string $templateId
     * @return string
     */
    private static function getTemplateFilePath($templateId)
    {
        return static::getTemplateFolderPath($templateId) . DIRECTORY_SEPARATOR . 'template.php';
    }

    /**
     * @return string
     */
    private static function getTemplatesBasePath()
    {
        return rtrim(FLUENTCART_PRO_PLUGIN_DIR, '/\\') . '/app/Views/emails/templates';
    }

    /**
     * @return string
     */
    private static function getTemplatesBaseUrl()
    {
        return rtrim(FLUENTCART_PRO_PLUGIN_URL, '/\\') . '/app/Views/emails/templates';
    }

    /**
     * @return string
     */
    private static function getDefaultTemplateThumbnailUrl()
    {
        foreach (['fallback', '_fallback'] as $fallbackDir) {
            foreach (['thumb.png', 'thump.png'] as $fileName) {
                $fallbackPath = static::getTemplatesBasePath() . DIRECTORY_SEPARATOR . $fallbackDir . DIRECTORY_SEPARATOR . $fileName;
                if (is_readable($fallbackPath)) {
                    return static::getTemplatesBaseUrl() . '/' . $fallbackDir . '/' . $fileName;
                }
            }
        }

        $defaultThumb = Vite::getAssetUrl('images/email-template/email-banner.png');
        return $defaultThumb ?: Vite::getAssetUrl('images/placeholder.svg');
    }
}
