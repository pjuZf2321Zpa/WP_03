<?php
/**
 * Internal Events Provider API: fetches Facebook events per source directly
 * through the Graph layer (no display pipeline, no display caches) and
 * returns NormalizedEvent objects. Its hooks are the seam for a future
 * public provider API.
 *
 * @package CustomFacebookFeed\Events_Integration
 * @since 4.11
 */

namespace CustomFacebookFeed\Events_Integration\Provider;

use CustomFacebookFeed\Builder\CFF_Db;
use CustomFacebookFeed\Events_Integration\NormalizedEvent;
use CustomFacebookFeed\Integrations\CFF_API_Connect;
use CustomFacebookFeed\Integrations\CFF_Graph_Url;
use CustomFacebookFeed\SB_Facebook_Data_Encryption;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class EventsProvider {

	/**
	 * Max Graph pages followed per source when fetching the events list.
	 */
	const MAX_PAGES = 5;

	/**
	 * @var EventNormalizer
	 */
	private $normalizer;

	public function __construct() {
		$this->normalizer = new EventNormalizer();
	}

	/**
	 * Connected events sources (page accounts with the events privilege),
	 * with decrypted access tokens.
	 *
	 * @return array[] Rows: account_id, username, access_token (decrypted), ...
	 */
	public function get_sources() {
		// source_query() cannot filter by privilege alone; filter here.
		$rows       = CFF_Db::source_query();
		$encryption = new SB_Facebook_Data_Encryption();
		$sources    = array();

		if ( ! is_array( $rows ) ) {
			$rows = array();
		}

		foreach ( $rows as $row ) {
			if ( ! is_array( $row ) ) {
				continue;
			}
			if ( ! isset( $row['privilege'] ) || 'events' !== $row['privilege'] ) {
				continue;
			}
			if ( isset( $row['account_type'] ) && 'page' !== $row['account_type'] ) {
				continue;
			}
			if ( empty( $row['account_id'] ) || empty( $row['access_token'] ) ) {
				continue;
			}
			$row['access_token'] = $encryption->maybe_decrypt( $row['access_token'] );
			$sources[]           = $row;
		}

		/**
		 * Filter the events sources considered by the provider.
		 *
		 * @param array $sources Source rows with decrypted tokens.
		 */
		return apply_filters( 'cff_events_provider_sources', $sources );
	}

	/**
	 * Fetch and normalize the upcoming events of one source.
	 *
	 * @param array $source Source row from get_sources().
	 * @return NormalizedEvent[]|\WP_Error
	 */
	public function get_events( array $source ) {
		$settings = array(
			'pagetype'         => 'page',
			'eventspostlimit'  => 100,
			'include_canceled' => true,
		);
		$misc_args = array(
			'token'  => $source['access_token'],
			'limit'  => 100,
			'locale' => get_option( 'cff_locale', 'en_US' ),
			'ssl'    => is_ssl(),
		);

		$graph_url = CFF_Graph_Url::get_url( 'events', $source['account_id'], $settings, $misc_args );
		if ( empty( $graph_url ) ) {
			return new \WP_Error( 'cff_events_sync_no_url', __( 'Could not build the Graph events URL.', 'custom-facebook-feed' ) );
		}

		$response = $this->request( $graph_url );
		if ( is_wp_error( $response ) ) {
			return $response;
		}

		$raw = $this->extract_field( $response, 'data' );
		if ( ! is_array( $raw ) ) {
			$raw = array();
		}

		// Follow pagination so busy pages don't hide upcoming events.
		$pages = 1;
		while ( $pages < self::MAX_PAGES ) {
			$paging   = $this->extract_field( $response, 'paging' );
			$next_url = is_array( $paging ) && ! empty( $paging['next'] ) ? $paging['next'] : '';
			if ( '' === $next_url || 0 !== strpos( $next_url, 'https://graph.facebook.com/' ) ) {
				break;
			}
			$response = $this->request_silent( $next_url );
			if ( is_wp_error( $response ) ) {
				break;
			}
			$next_raw = $this->extract_field( $response, 'data' );
			if ( ! is_array( $next_raw ) || empty( $next_raw ) ) {
				break;
			}
			$raw = array_merge( $raw, $next_raw );
			$pages++;
		}

		/**
		 * Filter the raw Graph events payload before normalization.
		 *
		 * @param array $raw    Raw event objects/arrays.
		 * @param array $source Source row.
		 */
		$raw = apply_filters( 'cff_events_provider_raw_events', $raw, $source );

		$events = $this->normalizer->normalize_list( $raw, (string) $source['account_id'] );

		/**
		 * Filter the normalized events for a source before syncing.
		 *
		 * @param NormalizedEvent[] $events Normalized events (occurrences expanded).
		 * @param array             $source Source row.
		 */
		return apply_filters( 'cff_events_provider_events', $events, $source );
	}

	/**
	 * Fetch a single event by ID, bypassing any transient cache. Used to
	 * confirm deletions before removing calendar events.
	 *
	 * @param string $event_id     Facebook event ID.
	 * @param string $access_token Decrypted source token.
	 * @return array {status: 'ok'|'gone'|'error', is_canceled: bool, event: mixed|null, event_times_truncated: bool}
	 */
	public function fetch_single( $event_id, $access_token ) {
		$url = 'https://graph.facebook.com/v' . CFF_Graph_Url::VERSION . '/' . rawurlencode( $event_id )
			. '?fields=' . rawurlencode( 'id,is_canceled,start_time,end_time,event_times.limit(100),updated_time' )
			. '&access_token=' . rawurlencode( $access_token );

		// Silent request: "does not exist" is the expected deletion signal,
		// not an error to report.
		$response = $this->request_silent( $url );

		if ( is_wp_error( $response ) ) {
			if ( $this->error_means_gone( $response ) ) {
				return array(
					'status'                => 'gone',
					'is_canceled'           => false,
					'event'                 => null,
					'event_times_truncated' => false,
				);
			}
			return array(
				'status'                => 'error',
				'is_canceled'           => false,
				'event'                 => null,
				'event_times_truncated' => false,
			);
		}

		// event_times is a paged connection; when a next page exists the
		// occurrence list is incomplete and must not drive deletions.
		$event_times = $this->extract_field( $response, 'event_times' );
		$paging      = is_array( $event_times ) ? $this->extract_field( $event_times, 'paging' ) : null;
		$truncated   = is_array( $paging ) && ! empty( $paging['next'] );

		return array(
			'status'                => 'ok',
			'is_canceled'           => (bool) $this->extract_field( $response, 'is_canceled' ),
			'event'                 => $response,
			'event_times_truncated' => $truncated,
		);
	}

	/**
	 * Expose the normalizer (e.g. to re-normalize a fetch_single payload).
	 *
	 * @return EventNormalizer
	 */
	public function normalizer() {
		return $this->normalizer;
	}

	/**
	 * Graph GET via CFF_API_Connect (token errors reach the error reporter).
	 *
	 * @param string $url Full Graph URL including token.
	 * @return mixed|\WP_Error
	 */
	private function request( $url ) {
		$api_connect = new CFF_API_Connect( $url );
		$api_connect->connect();

		if ( $api_connect->is_wp_error() ) {
			return new \WP_Error( 'cff_events_sync_http', __( 'Could not reach the Facebook API.', 'custom-facebook-feed' ) );
		}

		return $this->unwrap( $api_connect->get_data() );
	}

	/**
	 * Graph GET without error-reporter side effects.
	 *
	 * @param string $url Full Graph URL including token.
	 * @return mixed|\WP_Error
	 */
	private function request_silent( $url ) {
		$response = wp_safe_remote_get( $url, array( 'timeout' => 20 ) );

		if ( is_wp_error( $response ) ) {
			return new \WP_Error( 'cff_events_sync_http', __( 'Could not reach the Facebook API.', 'custom-facebook-feed' ) );
		}

		return $this->unwrap( json_decode( wp_remote_retrieve_body( $response ) ) );
	}

	/**
	 * Convert a Graph error payload into a WP_Error, pass data through.
	 *
	 * @param mixed $body Decoded response body.
	 * @return mixed|\WP_Error
	 */
	private function unwrap( $body ) {
		$error = $this->extract_field( $body, 'error' );
		if ( ! empty( $error ) ) {
			// The message lands in the stored sync log; keep it plain text.
			$message = sanitize_text_field( (string) $this->extract_field( $error, 'message' ) );
			$data    = array(
				'code'    => (int) $this->extract_field( $error, 'code' ),
				'subcode' => (int) $this->extract_field( $error, 'error_subcode' ),
			);

			return new \WP_Error( 'cff_events_sync_graph', $message, $data );
		}

		return $body;
	}

	/**
	 * Whether a Graph error means the object is gone. Conservative: bare
	 * code 100 also covers permission failures, so it needs subcode 33.
	 *
	 * @param \WP_Error $error Error returned by a Graph request.
	 * @return bool
	 */
	private function error_means_gone( \WP_Error $error ) {
		$data    = $error->get_error_data();
		$code    = is_array( $data ) && isset( $data['code'] ) ? (int) $data['code'] : 0;
		$subcode = is_array( $data ) && isset( $data['subcode'] ) ? (int) $data['subcode'] : 0;

		return 803 === $code || ( 100 === $code && 33 === $subcode );
	}

	/**
	 * Graph error code from a request error (0 when unavailable).
	 *
	 * @param \WP_Error $error Error returned by a Graph request.
	 * @return int
	 */
	public static function error_code( \WP_Error $error ) {
		$data = $error->get_error_data();

		return is_array( $data ) && isset( $data['code'] ) ? (int) $data['code'] : 0;
	}

	/**
	 * Object/array-tolerant field access.
	 *
	 * @param mixed  $data Payload.
	 * @param string $key  Field name.
	 * @return mixed|null
	 */
	private function extract_field( $data, $key ) {
		if ( is_object( $data ) && isset( $data->{$key} ) ) {
			return is_object( $data->{$key} ) || is_array( $data->{$key} ) ? json_decode( wp_json_encode( $data->{$key} ), true ) : $data->{$key};
		}
		if ( is_array( $data ) && isset( $data[ $key ] ) ) {
			return $data[ $key ];
		}
		return null;
	}
}
