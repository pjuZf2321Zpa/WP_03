<?php

namespace FluentCartPro\App\Modules\Promotional\OrderBump;

/**
 * Fills the {{bump.*}} placeholders of a card template with one offer's values.
 * Each placeholder has a type, and the type decides how its value is made safe.
 */
class OrderBumpTemplateRenderer
{
    const TEXT = 'text'; // escaped as plain text
    const KSES = 'kses'; // the admin's own formatted text, cleaned like post content
    const IMG = 'img';   // an <img> tag; the value is the image address

    /**
     * @return array<string,string> placeholder name => type
     */
    public static function placeholders(): array
    {
        return [
            'title'           => self::TEXT,
            'product_title'   => self::TEXT,
            'variation_title' => self::TEXT,
            'image'           => self::IMG,
            'original_price'  => self::TEXT,
            'price'           => self::TEXT,
            'savings'         => self::TEXT,
            'description'     => self::KSES,
        ];
    }

    /**
     * A card template as the shop prints it. The card's own blocks are rendered with the offer; every
     * other block is printed as it was saved, so a built-in card looks as it did before it was a template.
     * Placeholders are filled after the blocks render, so a value can never add blocks.
     *
     * @param array<string,string> $values placeholder name => value
     * @param array $bump ['id' => int, 'is_added' => bool, 'product_title' => string]
     */
    public static function render(string $content, array $values, array $bump): string
    {
        $html = '';
        foreach (parse_blocks($content) as $block) {
            $html .= self::renderBlock($block, $bump);
        }

        return self::fill($html, $values);
    }

    private static function cardBlocks(): array
    {
        static $names;
        if ($names === null) {
            $names = [];
            foreach (\FluentCartPro\App\Hooks\Handlers\FluentCartBlockEditorHandler::getOrderBumpBlocks() as $blockClass) {
                $names = array_merge($names, $blockClass::blockNames());
            }
        }

        return $names;
    }

    private static function renderBlock(array $block, array $bump): string
    {
        if ($block['blockName'] === null) {
            return $block['innerHTML'];
        }

        // Only the card's own blocks render; any other FluentCart block would read an order or a user.
        if (strpos($block['blockName'], 'fluent-cart/') === 0) {
            return in_array($block['blockName'], self::cardBlocks(), true)
                ? (new \WP_Block($block, ['fluent-cart/bump' => $bump]))->render()
                : '';
        }

        $html = '';
        $inner = 0;
        foreach ($block['innerContent'] as $chunk) {
            $html .= $chunk === null ? self::renderBlock($block['innerBlocks'][$inner++], $bump) : $chunk;
        }

        // A group's background image is saved only in its settings; WordPress adds the style when it renders.
        if ($block['blockName'] === 'core/group' && function_exists('wp_render_background_support')) {
            $html = wp_render_background_support($html, self::safeBackground($block));
        }

        return $html;
    }

    // The background settings go into a style attribute, so only plain values pass: an image address that
    // could close the url() and add CSS, or a size, position or repeat with extra declarations, is dropped.
    private static function safeBackground(array $block): array
    {
        $background = $block['attrs']['style']['background'] ?? null;
        if (!is_array($background)) {
            return $block;
        }

        $image = $background['backgroundImage'] ?? null;
        if ($image !== null) {
            $url = is_array($image) ? ($image['url'] ?? null) : null;
            if (!is_string($url) || !preg_match('~^https?://[^\s\'"()\\\\]+$~i', $url)) {
                unset($background['backgroundImage']);
            }
        }

        foreach (['backgroundSize', 'backgroundPosition', 'backgroundRepeat', 'backgroundAttachment'] as $key) {
            if (isset($background[$key]) && (!is_string($background[$key]) || !preg_match('/^[a-z0-9%. -]+$/i', $background[$key]))) {
                unset($background[$key]);
            }
        }

        $block['attrs']['style']['background'] = $background;

        return $block;
    }

    /**
     * The editor's {{:}} list for a card: every placeholder with a plain name.
     */
    public static function shortcodeGroup(): array
    {
        return [
            'title'      => __('Order Bump', 'fluent-cart-pro'),
            'key'        => 'bump',
            'shortcodes' => [
                '{{bump.image}}'           => __('Image', 'fluent-cart-pro'),
                '{{bump.title}}'           => __('Offer Title', 'fluent-cart-pro'),
                '{{bump.product_title}}'   => __('Product Title', 'fluent-cart-pro'),
                '{{bump.variation_title}}' => __('Variation Title', 'fluent-cart-pro'),
                '{{bump.original_price}}'  => __('Original Price', 'fluent-cart-pro'),
                '{{bump.price}}'           => __('Price', 'fluent-cart-pro'),
                '{{bump.savings}}'         => __('Savings', 'fluent-cart-pro'),
                '{{bump.description}}'     => __('Description', 'fluent-cart-pro'),
            ],
        ];
    }

    /**
     * An empty value leaves an empty element, which the card styles hide. A placeholder that
     * is not on the list is removed, so a shopper never sees raw braces. The image tag and the
     * description hold markup and quotes, so they fill only in text, never inside a tag.
     *
     * @param array<string,string> $values placeholder name => value
     */
    public static function fill(string $content, array $values): string
    {
        $parts = preg_split('/(<[^>]*>)/', $content, -1, PREG_SPLIT_DELIM_CAPTURE);

        foreach ($parts as $i => $part) {
            $parts[$i] = self::fillPart($part, $values, $part !== '' && $part[0] === '<');
        }

        return implode('', $parts);
    }

    private static function fillPart(string $part, array $values, bool $insideTag): string
    {
        $types = self::placeholders();

        return (string) preg_replace_callback(
            '/\{\{\s*bump\.([a-z_]+)\s*\}\}/',
            function ($match) use ($types, $values, $insideTag) {
                $name = $match[1];
                if (!isset($types[$name]) || ($insideTag && $types[$name] !== self::TEXT)) {
                    return '';
                }

                return self::safe($types[$name], isset($values[$name]) ? (string) $values[$name] : '');
            },
            $part
        );
    }

    private static function safe(string $type, string $value): string
    {
        switch ($type) {
            case self::IMG:
                return '<img src="' . esc_url($value) . '" alt="">';
            case self::KSES:
                return wp_kses_post($value);
            default:
                return esc_html($value);
        }
    }
}
