<?php

namespace BitApps\IntegrationsPro\Triggers\EssentialAddonsElementor;

use BitApps\IntegrationsPro\Config;
use WP_User;

final class EssentialAddonsElementorController
{
    public static function info()
    {
        return [
            'name'              => 'Essential Addons for Elementor',
            'type'              => 'custom_form_submission',
            'is_active'         => self::isPluginInstalled(),
            'documentation_url' => 'https://bit-integrations.com/wp-docs/trigger/essential-addons-for-elementor-integration/',
            'tutorial_url'      => '#',
            'tasks'             => [
                'action' => 'essential-addons-elementor/get',
                'method' => 'get',
            ],
            'fetch' => [
                'action' => 'trigger/test',
                'method' => 'post',
            ],
            'fetch_remove' => [
                'action' => 'trigger/test/remove',
                'method' => 'post',
            ],
            'isPro' => true
        ];
    }

    public function getAllTasks()
    {
        if (!static::isPluginInstalled()) {
            wp_send_json_error(\sprintf(__('%s is not installed or activated', 'bit-integrations-pro'), 'Essential Addons for Elementor'));
        }

        $tasks = [
            [
                'form_name'           => __('User Login', 'bit-integrations-pro'),
                'triggered_entity_id' => 'userLogin',
                'skipPrimaryKey'      => true
            ],
            [
                'form_name'           => __('User Registration', 'bit-integrations-pro'),
                'triggered_entity_id' => 'userRegistration',
                'skipPrimaryKey'      => true
            ]
        ];

        wp_send_json_success($tasks);
    }

    public static function isPluginInstalled()
    {
        return is_plugin_active('essential-addons-for-elementor-lite/essential_adons_elementor.php')
            || is_plugin_active('essential-addons-elementor/essential_adons_elementor.php');
    }

    public static function handleUserLogin($userLogin, $userData)
    {
        return self::flowExecute('userLogin', $userData);
    }

    public static function handleUserRegistration($userId, $userData)
    {
        if (empty($userId)) {
            return;
        }

        return self::flowExecute('userRegistration', get_userdata($userId), $userData);
    }

    private static function formatUserData($user, $additionalData = [])
    {
        $helperClass = bit_integrations_get_class('Core\\Util\\Helper');

        if (!$user instanceof WP_User) {
            return [];
        }

        $userData = [
            'user_id'         => $user->ID,
            'username'        => $user->user_login,
            'user_login'      => $user->user_login,
            'user_email'      => $user->user_email,
            'email'           => $user->user_email,
            'first_name'      => $user->first_name,
            'last_name'       => $user->last_name,
            'display_name'    => $user->display_name,
            'user_url'        => $user->user_url,
            'user_registered' => $user->user_registered,
            'nickname'        => get_user_meta($user->ID, 'nickname', true),
            'description'     => get_user_meta($user->ID, 'description', true),
            'roles'           => implode(', ', $user->roles),
        ];

        if ($additionalData) {
            $userData = array_merge($userData, $additionalData);
        }

        $userMeta = get_user_meta($user->ID);
        foreach ($userMeta as $key => $value) {
            if (!isset($userData[$key]) && !str_starts_with($key, '_')) {
                $userData[$key] = \is_array($value) && \count($value) === 1 ? reset($value) : $value;
            }
        }

        unset($userData['user_pass']);

        return $helperClass::prepareFetchFormatFields($userData);
    }

    private static function flowExecute($entityId, $user, $additionalData = [])
    {
        $helperClass = bit_integrations_get_class('Core\\Util\\Helper');
        $flowClass = bit_integrations_get_class('Flow\\Flow');

        $formData = self::formatUserData($user, $additionalData);

        if (empty($formData) || !\is_array($formData)) {
            return;
        }

        $helperClass::setTestData(Config::withFreePrefix("{$entityId}_test"), array_values($formData));

        $flows = $flowClass::exists('EssentialAddonsElementor', $entityId);

        if (!$flows) {
            return;
        }

        $data = array_column($formData, 'value', 'name');

        $flowClass::execute('EssentialAddonsElementor', $entityId, $data, $flows);

        return ['type' => 'success'];
    }
}
