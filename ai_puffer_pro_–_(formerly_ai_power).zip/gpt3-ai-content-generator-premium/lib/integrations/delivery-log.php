<?php

namespace WPAICG\Lib\Integrations\Logs;

use WP_Error;

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter -- This store only queries plugin-owned diagnostics tables and scalar values are normalized before each prepared call.

class AIPKit_Recipe_Delivery_Log_Store
{
    private const TABLE_SUFFIX = 'aipkit_recipe_delivery_logs';

    public static function get_table_name(): string
    {
        global $wpdb;

        return $wpdb->prefix . self::TABLE_SUFFIX;
    }

    public static function ensure_table(): void
    {
        global $wpdb;

        $table_name = self::get_table_name();
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Required to check custom table existence.
        $table_exists = $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $table_name));
        if ($table_exists === $table_name) {
            return;
        }

        self::setup_table();
    }

    /**
     * Create or upgrade the paid delivery-log schema during activation and updates.
     */
    public static function setup_table(): void
    {
        global $wpdb;

        $table_name = self::get_table_name();
        $charset_collate = $wpdb->get_charset_collate();
        $sql = "CREATE TABLE {$table_name} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            attempt_uuid varchar(36) NOT NULL,
            recipe_id varchar(36) NOT NULL,
            connection_id varchar(36) NOT NULL,
            event_name varchar(191) NOT NULL,
            event_id varchar(191) DEFAULT NULL,
            event_idempotency_key varchar(191) DEFAULT NULL,
            status varchar(20) NOT NULL DEFAULT 'failed',
            attempt_count int unsigned NOT NULL DEFAULT 1,
            max_attempts int unsigned NOT NULL DEFAULT 1,
            http_status int unsigned DEFAULT NULL,
            destination_identifier varchar(191) DEFAULT NULL,
            error_message text DEFAULT NULL,
            request_summary longtext DEFAULT NULL,
            response_summary longtext DEFAULT NULL,
            event_snapshot longtext DEFAULT NULL,
            replayed_from_attempt_uuid varchar(36) DEFAULT NULL,
            created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            completed_at datetime DEFAULT NULL,
            PRIMARY KEY  (id),
            UNIQUE KEY attempt_uuid (attempt_uuid),
            KEY recipe_status_created (recipe_id, status, created_at),
            KEY connection_status_created (connection_id, status, created_at),
            KEY event_name (event_name),
            KEY status_created (status, created_at),
            KEY replayed_from_attempt_uuid (replayed_from_attempt_uuid)
        ) {$charset_collate};";

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta($sql);
    }

    /**
     * @param array<string, mixed> $recipe
     * @param array<string, mixed> $execution_context
     * @param array<string, mixed> $envelope
     * @param array<string, mixed> $extra
     * @return string|\WP_Error
     */
    public static function log_failed_attempt(
        array $recipe,
        array $execution_context,
        array $envelope,
        WP_Error $error,
        array $extra = []
    ) {
        global $wpdb;

        self::ensure_table();

        $error_data = $error->get_error_data();
        $error_meta = is_array($error_data) ? $error_data : [];
        $connection = isset($execution_context['connection']) && is_array($execution_context['connection'])
            ? $execution_context['connection']
            : [];
        $event_context = isset($execution_context['event_context']) && is_array($execution_context['event_context'])
            ? $execution_context['event_context']
            : [];
        $dispatch_result = isset($execution_context['dispatch_result']) && is_array($execution_context['dispatch_result'])
            ? $execution_context['dispatch_result']
            : [];
        $event_origin = sanitize_key((string) (($event_context['origin'] ?? '') ?: ($envelope['source']['origin'] ?? '')));
        $processed_by_worker = !empty($dispatch_result['processed_by_worker']);
        $queue_job = isset($dispatch_result['queue_job']) && is_array($dispatch_result['queue_job'])
            ? $dispatch_result['queue_job']
            : [];
        $request_summary = [
            'recipe_name' => sanitize_text_field((string) ($recipe['name'] ?? '')),
            'app_slug' => sanitize_key((string) ($recipe['app_slug'] ?? '')),
            'action_slug' => sanitize_key((string) ($recipe['action_slug'] ?? '')),
            'connection_name' => sanitize_text_field((string) ($connection['name'] ?? '')),
            'source_module' => sanitize_key((string) (($envelope['source']['module'] ?? '') ?: $event_origin)),
            'event_origin' => $event_origin,
            'delivery_mode' => $processed_by_worker
                ? 'async_worker'
                : ($event_origin === 'manual_replay' ? 'manual_replay' : 'sync'),
            'queue_job_uuid' => sanitize_text_field((string) ($queue_job['job_uuid'] ?? '')),
            'request_meta' => isset($error_meta['request_meta']) && is_array($error_meta['request_meta'])
                ? $error_meta['request_meta']
                : [],
        ];
        $response_summary = [
            'status' => sanitize_key((string) ($error_meta['status'] ?? 'error')),
            'message' => sanitize_text_field($error->get_error_message()),
            'details' => isset($error_meta['details']) && is_array($error_meta['details'])
                ? $error_meta['details']
                : [],
        ];
        $attempt_uuid = wp_generate_uuid4();
        $completed_at = gmdate('Y-m-d H:i:s');
        $table_name = self::get_table_name();

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Insert into a plugin-owned recipe delivery log table.
        $inserted = $wpdb->insert(
            $table_name,
            [
                'attempt_uuid' => $attempt_uuid,
                'recipe_id' => sanitize_text_field((string) ($recipe['id'] ?? '')),
                'connection_id' => sanitize_text_field((string) ($connection['id'] ?? ($recipe['connection_id'] ?? ''))),
                'event_name' => sanitize_text_field((string) (($recipe['event_name'] ?? '') ?: ($envelope['type'] ?? ''))),
                'event_id' => sanitize_text_field((string) ($envelope['id'] ?? '')),
                'event_idempotency_key' => sanitize_text_field((string) ($envelope['idempotency_key'] ?? '')),
                'status' => 'failed',
                'attempt_count' => max(1, (int) ($error_meta['attempt_count'] ?? 1)),
                'max_attempts' => max(1, (int) ($error_meta['max_attempts'] ?? ($extra['max_attempts'] ?? ($error_meta['attempt_count'] ?? 1)))),
                'http_status' => max(0, (int) ($error_meta['http_code'] ?? 0)),
                'destination_identifier' => sanitize_text_field((string) (($request_summary['request_meta']['adapter'] ?? '') ?: ($recipe['app_slug'] ?? ''))),
                'error_message' => sanitize_text_field($error->get_error_message()),
                'request_summary' => self::encode_json($request_summary),
                'response_summary' => self::encode_json($response_summary),
                'event_snapshot' => self::encode_json(self::sanitize_event_snapshot($envelope)),
                'replayed_from_attempt_uuid' => sanitize_text_field((string) ($extra['replayed_from_attempt_uuid'] ?? '')),
                'created_at' => $completed_at,
                'completed_at' => $completed_at,
            ],
            [
                '%s',
                '%s',
                '%s',
                '%s',
                '%s',
                '%s',
                '%s',
                '%d',
                '%d',
                '%d',
                '%s',
                '%s',
                '%s',
                '%s',
                '%s',
                '%s',
                '%s',
                '%s',
            ]
        );

        if ($inserted === false) {
            return new WP_Error(
                'aipkit_recipe_log_insert_failed',
                __('Failed to store the recipe delivery issue.', 'gpt3-ai-content-generator')
            );
        }

        return $attempt_uuid;
    }

    /**
     * @return array<string, mixed>|null
     */
    public static function get_attempt_by_uuid(string $attempt_uuid): ?array
    {
        global $wpdb;

        $normalized_uuid = sanitize_text_field($attempt_uuid);
        if ($normalized_uuid === '') {
            return null;
        }

        self::ensure_table();

        $table_name = self::get_table_name();
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Required for custom diagnostics table reads.
        $row = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT * FROM {$table_name} WHERE attempt_uuid = %s LIMIT 1",
                $normalized_uuid
            ),
            ARRAY_A
        );

        return is_array($row) ? self::normalize_row($row) : null;
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    public static function get_recent_failed_attempts(int $limit = 8): array
    {
        global $wpdb;

        self::ensure_table();

        $safe_limit = max(1, min(20, $limit));
        $table_name = self::get_table_name();
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Required for custom diagnostics table reads.
        $rows = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT * FROM {$table_name} WHERE status = %s ORDER BY created_at DESC LIMIT %d",
                'failed',
                $safe_limit
            ),
            ARRAY_A
        );

        if (!is_array($rows)) {
            return [];
        }

        return array_values(array_filter(array_map([__CLASS__, 'normalize_row'], $rows), 'is_array'));
    }

    /**
     * @param array<string, mixed> $resolution_meta
     */
    public static function mark_attempt_discarded(string $attempt_uuid, array $resolution_meta = []): bool
    {
        $attempt = self::get_attempt_by_uuid($attempt_uuid);
        if (!is_array($attempt)) {
            return false;
        }

        $response_summary = isset($attempt['response_summary']) && is_array($attempt['response_summary'])
            ? $attempt['response_summary']
            : [];
        $response_summary['resolution'] = sanitize_key((string) ($resolution_meta['resolution'] ?? 'replayed'));
        $response_summary['resolved_at'] = gmdate('c');

        if (isset($resolution_meta['message'])) {
            $response_summary['resolution_message'] = sanitize_text_field((string) $resolution_meta['message']);
        }

        if (isset($resolution_meta['replacement_attempt_uuid'])) {
            $response_summary['replacement_attempt_uuid'] = sanitize_text_field((string) $resolution_meta['replacement_attempt_uuid']);
        }

        return self::update_attempt($attempt_uuid, [
            'status' => 'discarded',
            'response_summary' => $response_summary,
            'error_message' => sanitize_text_field((string) ($resolution_meta['message'] ?? ($attempt['error_message'] ?? ''))),
        ]);
    }

    public static function clear_attempt(string $attempt_uuid): bool
    {
        return self::mark_attempt_discarded($attempt_uuid, [
            'resolution' => 'manually_cleared',
            'message' => __('Delivery issue was cleared manually.', 'gpt3-ai-content-generator'),
        ]);
    }

    public static function clear_all_failed_attempts(): int
    {
        global $wpdb;

        self::ensure_table();

        $table_name = self::get_table_name();
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Required bulk update on custom diagnostics table.
        $updated_rows = $wpdb->update(
            $table_name,
            [
                'status' => 'discarded',
                'updated_at' => current_time('mysql', true),
            ],
            [
                'status' => 'failed',
            ],
            [
                '%s',
                '%s',
            ],
            [
                '%s',
            ]
        );

        return is_int($updated_rows) ? $updated_rows : 0;
    }

    public static function cleanup_expired_logs(): int
    {
        global $wpdb;

        self::ensure_table();

        $retention_days = max(1, (int) apply_filters('aipkit_native_app_recipe_log_retention_days', 14));
        $cutoff = gmdate('Y-m-d H:i:s', time() - ($retention_days * DAY_IN_SECONDS));
        $table_name = self::get_table_name();

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Required cleanup on custom diagnostics table.
        $deleted_rows = $wpdb->query(
            $wpdb->prepare(
                "DELETE FROM {$table_name} WHERE created_at < %s",
                $cutoff
            )
        );

        return is_int($deleted_rows) ? $deleted_rows : 0;
    }

    /**
     * @param array<string, mixed> $updates
     */
    private static function update_attempt(string $attempt_uuid, array $updates): bool
    {
        global $wpdb;

        $normalized_uuid = sanitize_text_field($attempt_uuid);
        if ($normalized_uuid === '') {
            return false;
        }

        $data = [];
        $format = [];

        if (isset($updates['status'])) {
            $status = sanitize_key((string) $updates['status']);
            if (in_array($status, ['failed', 'discarded'], true)) {
                $data['status'] = $status;
                $format[] = '%s';
            }
        }

        if (isset($updates['response_summary']) && is_array($updates['response_summary'])) {
            $data['response_summary'] = self::encode_json($updates['response_summary']);
            $format[] = '%s';
        }

        if (isset($updates['error_message'])) {
            $data['error_message'] = sanitize_text_field((string) $updates['error_message']);
            $format[] = '%s';
        }

        if (empty($data)) {
            return false;
        }

        $data['updated_at'] = current_time('mysql', true);
        $format[] = '%s';

        self::ensure_table();

        $table_name = self::get_table_name();
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Required update on custom diagnostics table.
        $updated = $wpdb->update(
            $table_name,
            $data,
            ['attempt_uuid' => $normalized_uuid],
            $format,
            ['%s']
        );

        return $updated !== false;
    }

    /**
     * @param array<string, mixed> $row
     * @return array<string, mixed>
     */
    private static function normalize_row(array $row): array
    {
        return [
            'attempt_uuid' => sanitize_text_field((string) ($row['attempt_uuid'] ?? '')),
            'recipe_id' => sanitize_text_field((string) ($row['recipe_id'] ?? '')),
            'connection_id' => sanitize_text_field((string) ($row['connection_id'] ?? '')),
            'event_name' => sanitize_text_field((string) ($row['event_name'] ?? '')),
            'event_id' => sanitize_text_field((string) ($row['event_id'] ?? '')),
            'event_idempotency_key' => sanitize_text_field((string) ($row['event_idempotency_key'] ?? '')),
            'status' => sanitize_key((string) ($row['status'] ?? 'failed')),
            'attempt_count' => max(1, (int) ($row['attempt_count'] ?? 1)),
            'max_attempts' => max(1, (int) ($row['max_attempts'] ?? 1)),
            'http_status' => max(0, (int) ($row['http_status'] ?? 0)),
            'destination_identifier' => sanitize_text_field((string) ($row['destination_identifier'] ?? '')),
            'error_message' => sanitize_text_field((string) ($row['error_message'] ?? '')),
            'request_summary' => self::decode_json((string) ($row['request_summary'] ?? '')),
            'response_summary' => self::decode_json((string) ($row['response_summary'] ?? '')),
            'event_snapshot' => self::decode_json((string) ($row['event_snapshot'] ?? '')),
            'replayed_from_attempt_uuid' => sanitize_text_field((string) ($row['replayed_from_attempt_uuid'] ?? '')),
            'created_at' => sanitize_text_field((string) ($row['created_at'] ?? '')),
            'updated_at' => sanitize_text_field((string) ($row['updated_at'] ?? '')),
            'completed_at' => sanitize_text_field((string) ($row['completed_at'] ?? '')),
        ];
    }

    /**
     * @param array<string, mixed> $envelope
     * @return array<string, mixed>
     */
    private static function sanitize_event_snapshot(array $envelope): array
    {
        return [
            'id' => sanitize_text_field((string) ($envelope['id'] ?? '')),
            'type' => sanitize_text_field((string) ($envelope['type'] ?? '')),
            'schema_version' => sanitize_text_field((string) ($envelope['schema_version'] ?? '')),
            'occurred_at' => sanitize_text_field((string) ($envelope['occurred_at'] ?? '')),
            'idempotency_key' => sanitize_text_field((string) ($envelope['idempotency_key'] ?? '')),
            'source' => isset($envelope['source']) && is_array($envelope['source']) ? $envelope['source'] : [],
            'data' => isset($envelope['data']) && is_array($envelope['data']) ? $envelope['data'] : [],
            'resource' => isset($envelope['resource']) && is_array($envelope['resource']) ? $envelope['resource'] : [],
            'meta' => isset($envelope['meta']) && is_array($envelope['meta']) ? $envelope['meta'] : [],
        ];
    }

    private static function encode_json(array $value): string
    {
        return (string) wp_json_encode($value);
    }

    /**
     * @return array<string, mixed>
     */
    private static function decode_json(string $value): array
    {
        $decoded = json_decode($value, true);

        return is_array($decoded) ? $decoded : [];
    }
}
