<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Actions\MailerLite\MailerLiteHelperPro;
use BitApps\IntegrationsPro\Config;
use BitApps\IntegrationsPro\Core\Util\Hooks;

// Deprecated since v2.7.8 - use bit_integrations_mailerlite_* hooks instead
if (bit_integrations_version_below('2.7.8')) {
    Hooks::filter('btcbi_mailerlite_delete_subscriber', [MailerLiteHelperPro::class, 'deleteSubscriber'], 10, 6);
}

// New hooks since v2.7.8
Hooks::filter(Config::withFreePrefix('mailerlite_delete_subscriber'), [MailerLiteHelperPro::class, 'deleteSubscriber'], 10, 6);
Hooks::filter(Config::withFreePrefix('mailerlite_unassign_subscriber_from_group'), [MailerLiteHelperPro::class, 'unassignSubscriberFromGroup'], 10, 5);
