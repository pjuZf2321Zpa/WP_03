<?php

namespace FluentCartPro\App\Modules\DynamicPricing\Conditions\Options;

use FluentCart\Framework\Support\Arr;
use FluentCartPro\App\Modules\DynamicPricing\Conditions\ConditionRegistry;

/**
 * An option source whose values are slugs rather than record ids.
 *
 * User roles and payment methods are picked by slug (`subscriber`, `stripe`),
 * and the list lives in code or an option, not a table — so searching and
 * limiting happen over an array here rather than in a query builder. Nothing
 * maps through intval(): `intval('subscriber')` is 0, and a slug put through
 * the id handling the other sources use would be thrown away.
 *
 * A subclass only says what is available. The same list is the whitelist a
 * saved condition is held against, so a slug that cannot be picked cannot be
 * stored either.
 *
 * @package FluentCartPro\App\Modules\DynamicPricing
 *
 * @version 1.0.0
 */
abstract class SlugOptionSource extends OptionSource
{
    /**
     * Everything that can be picked, as `slug => label`.
     *
     * @return array
     */
    abstract public function available(): array;

    /**
     * Build the options returned to the condition builder.
     *
     * Applies the requested search and limit, keeps already-selected slugs
     * visible, and formats the result as `{value, label}` options for the
     * remote select.
     *
     * @param array $options
     * @param array $args
     * @return array
     */
    public function options($options, $args)
    {
        $available = $this->available();

        $selected = $this->selectedSlugs($args);
        $search = strtolower(trim((string)Arr::get($args, 'search', '')));

        $matched = array_slice(
            $this->filterSlugs($available, $search),
            0,
            $this->boundedLimit(Arr::get($args, 'limit')),
            true
        );

        $matched = $this->pinSelected($matched, $selected, $available);

        $prepared = [];

        foreach ($matched as $slug => $label) {
            $prepared[] = [
                'value' => $slug,
                'label' => $label,
            ];
        }

        return $prepared;
    }

    /**
     * Filter by the label or slug entered in the search field.
     *
     * An empty search keeps everything. Matching both fields lets an
     * administrator find an entry by the name they read or the slug it has.
     *
     * @param array $available
     * @param string $search
     * @return array
     */
    protected function filterSlugs(array $available, string $search): array
    {
        $matched = [];

        foreach ($available as $slug => $label) {
            if (
                $search === ''
                || strpos(strtolower($label), $search) !== false
                || strpos($slug, $search) !== false
            ) {
                $matched[$slug] = $label;
            }
        }

        return $matched;
    }

    /**
     * Keep already-selected slugs in the result even when search or limit
     * excludes them, so the picker can still show their label.
     *
     * @param array $matched
     * @param array $selected
     * @param array $available
     * @return array
     */
    protected function pinSelected(array $matched, array $selected, array $available): array
    {
        foreach (array_reverse($selected) as $slug) {
            if (!isset($matched[$slug]) && isset($available[$slug])) {
                $matched = [$slug => $available[$slug]] + $matched;
            }
        }

        return $matched;
    }

    /**
     * The already-selected slugs a request asks to be kept visible.
     *
     * @param array $args
     * @return array
     */
    protected function selectedSlugs($args): array
    {
        $slugs = [];

        $requested = array_slice(
            (array)Arr::get($args, 'include_ids', []),
            0,
            ConditionRegistry::MAX_SELECT_VALUES
        );

        foreach ($requested as $slug) {
            if (!is_scalar($slug)) {
                continue;
            }

            $slug = sanitize_key((string)$slug);

            if ($slug !== '' && !in_array($slug, $slugs, true)) {
                $slugs[] = $slug;
            }
        }

        return $slugs;
    }
}
