<?php

namespace BitApps\IntegrationsPro\Actions\TheEventsCalendar\Services;

use BitApps\IntegrationsPro\Actions\TheEventsCalendar\TheEventsCalendarHelper;

if (!\defined('ABSPATH')) {
    exit;
}

final class OrganizerService extends BaseService
{
    public function createOrganizer(): array
    {
        $error = $this->validateRequiredFields(['name' => __('Organizer Name', 'bit-integrations-pro')]) ?? $this->validateEmail();

        if ($error !== null) {
            return $error;
        }

        $organizerId = tribe_create_organizer($this->getOrganizerArgs('publish'));

        if (empty($organizerId) || is_wp_error($organizerId)) {
            return $this->errorResponse(__('Failed to create the organizer. Check the field values and try again.', 'bit-integrations-pro'));
        }

        return $this->successResponse(__('The organizer is created.', 'bit-integrations-pro'), TheEventsCalendarHelper::getOrganizerData($organizerId));
    }

    public function updateOrganizer(): array
    {
        $error = $this->validateRequiredFields(['organizer_id' => __('Organizer ID', 'bit-integrations-pro')]) ?? $this->validateEmail();

        if ($error !== null) {
            return $error;
        }

        $organizerId = (int) $this->getInteger('organizer_id');

        if (!TheEventsCalendarHelper::isPostOfType($organizerId, TheEventsCalendarHelper::ORGANIZER_POST_TYPE)) {
            return $this->organizerNotFound();
        }

        $organizerData = $this->getOrganizerArgs();

        if (empty($organizerData)) {
            return $this->errorResponse(__('No organizer field has a value. Map at least one field to update.', 'bit-integrations-pro'));
        }

        tribe_update_organizer($organizerId, $organizerData);

        return $this->successResponse(__('The organizer is updated.', 'bit-integrations-pro'), TheEventsCalendarHelper::getOrganizerData($organizerId));
    }

    public function deleteOrganizer(): array
    {
        $error = $this->validateRequiredFields(['organizer_id' => __('Organizer ID', 'bit-integrations-pro')]);

        if ($error !== null) {
            return $error;
        }

        $organizerId = (int) $this->getInteger('organizer_id');
        $organizerData = TheEventsCalendarHelper::getOrganizerData($organizerId);

        if (empty($organizerData)) {
            return $this->organizerNotFound();
        }

        $isPermanent = (bool) $this->getBoolean('delete_permanently');

        if (!$this->removePost($organizerId, $isPermanent)) {
            return $this->errorResponse(__('Failed to delete the organizer. Check that the organizer exists and try again.', 'bit-integrations-pro'));
        }

        $organizerData['deleted_permanently'] = $isPermanent;

        return $this->successResponse(__('The organizer is deleted.', 'bit-integrations-pro'), $organizerData);
    }

    private function validateEmail(): ?array
    {
        if ($this->hasValue('email') && !is_email($this->getString('email'))) {
            return $this->errorResponse(__('The organizer email is not valid. Map a valid email address.', 'bit-integrations-pro'));
        }

        return null;
    }

    private function getOrganizerArgs(?string $defaultStatus = null): array
    {
        $organizerArgs = [
            'Organizer'   => $this->getString('name'),
            'Description' => $this->getString('description'),
            'Phone'       => $this->getString('phone'),
            'Website'     => $this->getString('website'),
            'Email'       => $this->getString('email'),
            'post_status' => (string) $this->getPostStatus($defaultStatus),
        ];

        return array_filter($organizerArgs, 'strlen');
    }

    private function organizerNotFound(): array
    {
        return $this->errorResponse(__('Organizer not found. Map the ID of an existing organizer.', 'bit-integrations-pro'));
    }
}
