<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Core\Util\Hooks;
use BitApps\IntegrationsPro\Triggers\CalculatedFieldsForm\CalculatedFieldsFormController;

Hooks::add('cpcff_process_data_before_insert', [CalculatedFieldsFormController::class, 'handleFormSubmitted'], 10, 3);
