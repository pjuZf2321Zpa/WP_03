<?php

namespace BitApps\IntegrationsPro\Actions\WpActivityLog;

use DateTime;
use WSAL\Controllers\Alert;
use WSAL\Controllers\Alert_Manager;
use WSAL\Entities\Archive\Delete_Records;
use WSAL\Entities\Metadata_Entity;
use WSAL\Entities\Occurrences_Entity;
use WSAL\Helpers\Plugin_Settings_Helper;
use WSAL\Helpers\Settings_Helper;

final class WpActivityLogProHelper
{
    private const TIME_UNITS = [
        'days'   => DAY_IN_SECONDS,
        'weeks'  => WEEK_IN_SECONDS,
        'months' => MONTH_IN_SECONDS,
        'years'  => YEAR_IN_SECONDS,
    ];

    private const EXCLUSION_OPTIONS = [
        'user'          => 'excluded-users',
        'role'          => 'excluded-roles',
        'ip'            => 'excluded-ip',
        'postType'      => 'custom-post-types',
        'postStatus'    => 'excluded-post-status',
        'postMetaField' => 'excluded-post-meta',
        'userMetaField' => 'excluded-user-meta',
    ];

    private const EXCLUSION_FIELDS = [
        'user'          => 'username',
        'role'          => 'role',
        'ip'            => 'ip_address',
        'postType'      => 'post_type',
        'postStatus'    => 'post_status',
        'postMetaField' => 'meta_key',
        'userMetaField' => 'meta_key',
    ];

    private const EXCLUSION_SETTERS = [
        'user'          => [Settings_Helper::class, 'set_excluded_monitoring_users'],
        'role'          => [Settings_Helper::class, 'set_excluded_monitoring_roles'],
        'ip'            => [Plugin_Settings_Helper::class, 'set_excluded_monitoring_ip'],
        'postType'      => [Plugin_Settings_Helper::class, 'set_excluded_post_types'],
        'postStatus'    => [Plugin_Settings_Helper::class, 'set_excluded_post_statuses'],
        'postMetaField' => [Settings_Helper::class, 'set_excluded_post_meta_fields'],
        'userMetaField' => [Settings_Helper::class, 'set_excluded_user_meta_fields'],
    ];

    private const EVENT_FILTER_COLUMNS = [
        'event'      => ['alert_id = %d', 'int'],
        'user'       => ['user_id = %d', 'int'],
        'severity'   => ['severity = %s', 'string'],
        'object'     => ['object = %s', 'string'],
        'event_type' => ['event_type = %s', 'string'],
    ];

    private const FIELD_FILTER_COLUMNS = [
        'client_ip' => ['client_ip = %s', 'string'],
        'post_id'   => ['post_id = %d', 'int'],
    ];

    private const DATE_FORMATS = ['Y-m-d H:i:s', 'Y-m-d H:i', 'Y-m-d', 'Y-m-d\\TH:i:sP', 'Y-m-d\\TH:i:s'];

    private const DELETE_BATCH_SIZE = 500;

    public static function logEvent($defaultResponse, $fieldData, $utilities = null, $integrationDetails = null)
    {
        if (!self::isPluginActive()) {
            return self::pluginInactiveError();
        }

        $eventId = absint(self::conf($integrationDetails, 'selectedEvent'));

        if (empty($eventId) || !self::getEvent($eventId)) {
            return self::error(__('The event is not registered in WP Activity Log. Select an event from the list.', 'bit-integrations-pro'));
        }

        if (!Alert_Manager::is_enabled($eventId)) {
            // translators: %d is the event ID.
            return self::error(\sprintf(__('Event %d is disabled. Enable the event before you log it.', 'bit-integrations-pro'), $eventId));
        }

        $eventData = array_filter(
            (array) $fieldData,
            function ($key) {
                return $key !== '';
            },
            ARRAY_FILTER_USE_KEY
        );

        $userId = absint(self::conf($utilities, 'selected_user'));

        if (!empty($userId)) {
            $user = get_userdata($userId);

            if (!$user) {
                return self::error(__('The user does not exist. Select a different user.', 'bit-integrations-pro'));
            }

            $eventData['CurrentUserID'] = $userId;
            $eventData['Username'] = $user->user_login;
            $eventData['CurrentUserRoles'] = $user->roles;
        }

        $previousOccurrence = self::getLatestOccurrence($eventId);

        Alert_Manager::trigger_event($eventId, $eventData);

        $occurrence = self::getLatestOccurrence($eventId);

        if (!$occurrence || (int) $occurrence['id'] === (int) ($previousOccurrence['id'] ?? 0)) {
            return self::error(__('WP Activity Log did not log the event. Make sure that the user, role, IP address, post type and post status are not excluded from monitoring.', 'bit-integrations-pro'));
        }

        return self::success(__('WP Activity Log logged the event.', 'bit-integrations-pro'), self::formatOccurrences([$occurrence])[0]);
    }

    public static function deleteEvent($defaultResponse, $fieldData)
    {
        if (!self::isPluginActive()) {
            return self::pluginInactiveError();
        }

        $occurrenceId = self::toPositiveInt($fieldData['occurrence_id'] ?? '');
        [$siteCondition, $siteArguments] = self::getSiteCondition();
        $occurrence = $occurrenceId ? Occurrences_Entity::load('id = %d AND ' . $siteCondition, array_merge([$occurrenceId], $siteArguments)) : null;

        if (!\is_array($occurrence)) {
            return self::error(__('The log entry does not exist. Make sure that the log entry ID is correct.', 'bit-integrations-pro'));
        }

        $event = self::formatOccurrences([$occurrence])[0];

        if (self::deleteOccurrences([$occurrenceId]) === false) {
            return self::error(__('WP Activity Log could not delete the log entry. Check the activity log database connection.', 'bit-integrations-pro'));
        }

        return self::success(__('WP Activity Log deleted the log entry.', 'bit-integrations-pro'), $event);
    }

    public static function deleteEvents($defaultResponse, $fieldData, $utilities = null)
    {
        if (!self::isPluginActive()) {
            return self::pluginInactiveError();
        }

        $conditions = [];
        $arguments = [];

        foreach (self::EVENT_FILTER_COLUMNS as $key => [$condition, $type]) {
            $value = self::conf($utilities, "selected_{$key}");

            if (self::isEmptyFilter($value)) {
                continue;
            }

            $conditions[] = $condition;
            $arguments[] = $type === 'int' ? (int) $value : (string) $value;
        }

        $filterLabels = [
            'client_ip'  => __('IP Address', 'bit-integrations-pro'),
            'post_id'    => __('Post ID', 'bit-integrations-pro'),
            'start_date' => __('Start Date', 'bit-integrations-pro'),
            'end_date'   => __('End Date', 'bit-integrations-pro'),
        ];

        foreach ($filterLabels as $key => $label) {
            if (\array_key_exists($key, (array) $fieldData) && trim((string) $fieldData[$key]) === '') {
                // translators: %s is the filter label.
                return self::error(\sprintf(__('The %s filter has no value. Make sure that the mapped field has a value, or remove the filter.', 'bit-integrations-pro'), $label));
            }
        }

        foreach (self::FIELD_FILTER_COLUMNS as $key => [$condition, $type]) {
            $value = trim((string) ($fieldData[$key] ?? ''));

            if ($value === '') {
                continue;
            }

            if ($type === 'int' && self::toPositiveInt($value) === null) {
                // translators: %s is the filter label.
                return self::error(\sprintf(__('%s must be a number more than 0.', 'bit-integrations-pro'), $filterLabels[$key]));
            }

            $conditions[] = $condition;
            $arguments[] = $type === 'int' ? self::toPositiveInt($value) : $value;
        }

        $dateConditions = [
            'start_date' => 'created_on >= %f',
            'end_date'   => 'created_on <= %f',
        ];

        foreach ($dateConditions as $key => $condition) {
            $value = trim((string) ($fieldData[$key] ?? ''));

            if ($value === '') {
                continue;
            }

            $timestamp = self::toTimestamp($value);

            if ($timestamp === null) {
                // translators: %s is the date field label.
                return self::error(\sprintf(__('%s is not a valid date. Use the YYYY-MM-DD HH:MM:SS format.', 'bit-integrations-pro'), $filterLabels[$key]));
            }

            $conditions[] = $condition;
            $arguments[] = $timestamp;
        }

        if (empty($conditions)) {
            return self::error(__('No filter is set. Set at least one filter to select the log entries to delete.', 'bit-integrations-pro'));
        }

        [$siteCondition, $siteArguments] = self::getSiteCondition();

        $deletedCount = self::deleteMatchingOccurrences(
            implode(' AND ', array_merge($conditions, [$siteCondition])),
            array_merge($arguments, $siteArguments)
        );

        if ($deletedCount === false) {
            return self::error(__('WP Activity Log could not delete the log entries. Check the activity log database connection.', 'bit-integrations-pro'));
        }

        // translators: %d is the number of deleted log entries.
        return self::success(\sprintf(__('WP Activity Log deleted %d log entries.', 'bit-integrations-pro'), $deletedCount), ['deleted_count' => $deletedCount]);
    }

    public static function deleteEventsOlderThan($defaultResponse, $fieldData, $integrationDetails = null)
    {
        if (!self::isPluginActive()) {
            return self::pluginInactiveError();
        }

        if (self::isNetworkSubsite()) {
            return self::error(__('WP Activity Log deletes old log entries for the whole network. Run this action from the main site.', 'bit-integrations-pro'));
        }

        $olderThan = (int) ($fieldData['older_than'] ?? 0);
        $unit = (string) self::conf($integrationDetails, 'selectedTimeUnit');

        if ($olderThan < 1 || !isset(self::TIME_UNITS[$unit])) {
            return self::error(__('The age is not valid. Enter a number more than 0 and select a time unit.', 'bit-integrations-pro'));
        }

        $timestamp = time() - ($olderThan * self::TIME_UNITS[$unit]);

        $result = Delete_Records::delete([], 0, ['created_on <= %s' => $timestamp]);

        if ($result === false) {
            return self::error(__('WP Activity Log could not delete the events. Check the activity log database connection.', 'bit-integrations-pro'));
        }

        $deletedCount = \is_array($result) ? (int) $result[0] : 0;

        if ($deletedCount > 0) {
            do_action('wsal_prune', $deletedCount, $result[1]);
        }

        return self::success(
            __('WP Activity Log deleted the old log entries.', 'bit-integrations-pro'),
            ['deleted_count' => $deletedCount, 'deleted_until' => wp_date('Y-m-d H:i:s', $timestamp)]
        );
    }

    public static function enableEvent($defaultResponse, $fieldData)
    {
        return self::setEventStatus($fieldData, true);
    }

    public static function disableEvent($defaultResponse, $fieldData)
    {
        return self::setEventStatus($fieldData, false);
    }

    public static function excludeUser($defaultResponse, $fieldData)
    {
        return self::updateExclusion('user', $fieldData, true);
    }

    public static function removeUserExclusion($defaultResponse, $fieldData)
    {
        return self::updateExclusion('user', $fieldData, false);
    }

    public static function excludeRole($defaultResponse, $fieldData)
    {
        return self::updateExclusion('role', $fieldData, true);
    }

    public static function removeRoleExclusion($defaultResponse, $fieldData)
    {
        return self::updateExclusion('role', $fieldData, false);
    }

    public static function excludeIpAddress($defaultResponse, $fieldData)
    {
        return self::updateExclusion('ip', $fieldData, true);
    }

    public static function removeIpAddressExclusion($defaultResponse, $fieldData)
    {
        return self::updateExclusion('ip', $fieldData, false);
    }

    public static function excludePostType($defaultResponse, $fieldData)
    {
        return self::updateExclusion('postType', $fieldData, true);
    }

    public static function removePostTypeExclusion($defaultResponse, $fieldData)
    {
        return self::updateExclusion('postType', $fieldData, false);
    }

    public static function excludePostStatus($defaultResponse, $fieldData)
    {
        return self::updateExclusion('postStatus', $fieldData, true);
    }

    public static function removePostStatusExclusion($defaultResponse, $fieldData)
    {
        return self::updateExclusion('postStatus', $fieldData, false);
    }

    public static function excludePostMetaField($defaultResponse, $fieldData)
    {
        return self::updateExclusion('postMetaField', $fieldData, true);
    }

    public static function removePostMetaFieldExclusion($defaultResponse, $fieldData)
    {
        return self::updateExclusion('postMetaField', $fieldData, false);
    }

    public static function excludeUserMetaField($defaultResponse, $fieldData)
    {
        return self::updateExclusion('userMetaField', $fieldData, true);
    }

    public static function removeUserMetaFieldExclusion($defaultResponse, $fieldData)
    {
        return self::updateExclusion('userMetaField', $fieldData, false);
    }

    private static function setEventStatus($fieldData, $isEnabled)
    {
        if (!self::isPluginActive()) {
            return self::pluginInactiveError();
        }

        if (self::isNetworkSubsite()) {
            return self::error(__('WP Activity Log event settings apply to the whole network. Run this action from the main site.', 'bit-integrations-pro'));
        }

        $eventId = (int) self::toPositiveInt($fieldData['event_id'] ?? '');
        $event = self::getEvent($eventId);

        if (!$event) {
            return self::error(__('The event is not registered in WP Activity Log. Map a valid event ID.', 'bit-integrations-pro'));
        }

        if ($isEnabled && \in_array($eventId, Settings_Helper::get_default_always_disabled_alerts(), true)) {
            // translators: %d is the event ID.
            return self::error(\sprintf(__('WP Activity Log always keeps event %d disabled. You cannot enable it.', 'bit-integrations-pro'), $eventId));
        }

        if (Alert_Manager::is_enabled($eventId) !== $isEnabled) {
            Alert_Manager::disable_enable_alert([$eventId]);
        }

        return self::success(
            $isEnabled ? __('WP Activity Log enabled the event.', 'bit-integrations-pro') : __('WP Activity Log disabled the event.', 'bit-integrations-pro'),
            [
                'event_id'          => $eventId,
                'event_description' => html_entity_decode($event['desc']),
                'is_enabled'        => Alert_Manager::is_enabled($eventId),
            ]
        );
    }

    private static function updateExclusion($exclusionType, $fieldData, $isExcluded)
    {
        if (!self::isPluginActive()) {
            return self::pluginInactiveError();
        }

        $value = trim((string) ($fieldData[self::EXCLUSION_FIELDS[$exclusionType]] ?? ''));

        if ($value === '') {
            return self::error(__('The value is required. Map a value to add to or remove from the exclusions.', 'bit-integrations-pro'));
        }

        if (self::isNetworkSubsite()) {
            return self::error(__('WP Activity Log exclusions apply to the whole network. Run this action from the main site.', 'bit-integrations-pro'));
        }

        if (strpos($value, ',') !== false) {
            return self::error(__('The value contains a comma. Map one value only.', 'bit-integrations-pro'));
        }

        if ($isExcluded) {
            $invalidValueError = self::validateExclusionValue($exclusionType, $value);

            if ($invalidValueError !== null) {
                return self::error($invalidValueError);
            }
        }

        $exclusions = self::getExclusionList($exclusionType);
        $isListed = \in_array($value, $exclusions, true);

        if ($isExcluded && !$isListed) {
            $exclusions[] = $value;
        }

        if (!$isExcluded && $isListed) {
            $exclusions = array_values(array_diff($exclusions, [$value]));
        }

        if ($isExcluded !== $isListed) {
            \call_user_func(self::EXCLUSION_SETTERS[$exclusionType], $exclusions);
        }

        $exclusions = self::getExclusionList($exclusionType);

        if (\in_array($value, $exclusions, true) !== $isExcluded) {
            return self::error(__('WP Activity Log did not save the change. WP Activity Log rejects user logins shorter than 3 characters and values with special characters.', 'bit-integrations-pro'));
        }

        return self::success(
            $isExcluded ? __('WP Activity Log excluded the value from monitoring.', 'bit-integrations-pro') : __('WP Activity Log removed the value from the exclusions.', 'bit-integrations-pro'),
            [
                'value'       => $value,
                'is_excluded' => $isExcluded,
                'exclusions'  => $exclusions,
            ]
        );
    }

    private static function validateExclusionValue($exclusionType, $value)
    {
        if ($exclusionType === 'user' && !get_user_by('login', $value)) {
            return __('The user does not exist. Map the user login of an existing user.', 'bit-integrations-pro');
        }

        if ($exclusionType === 'role' && !wp_roles()->is_role($value)) {
            return __('The role does not exist. Map the key of an existing role.', 'bit-integrations-pro');
        }

        if ($exclusionType === 'ip' && !self::isIpAddressOrRange($value)) {
            return __('The IP address is not valid. Enter an IPv4 or IPv6 address, or an IPv4 range such as 192.168.1.1-50.', 'bit-integrations-pro');
        }
    }

    private static function isIpAddressOrRange($value)
    {
        if (filter_var($value, FILTER_VALIDATE_IP) !== false) {
            return true;
        }

        if (strpos($value, '-') === false) {
            return false;
        }

        [$startAddress, $lastOctet] = explode('-', $value, 2);

        return filter_var($startAddress, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4) !== false
            && ctype_digit($lastOctet)
            && (int) $lastOctet <= 255;
    }

    private static function getExclusionList($exclusionType)
    {
        $value = Settings_Helper::get_option_value(self::EXCLUSION_OPTIONS[$exclusionType], []);
        $values = \is_array($value) ? $value : explode(',', (string) $value);

        return array_values(array_unique(array_filter(array_map('trim', $values), 'strlen')));
    }

    private static function deleteMatchingOccurrences($conditions, array $arguments)
    {
        $deletedCount = 0;

        do {
            $occurrenceIds = array_column(
                Occurrences_Entity::load_array($conditions, $arguments, null, ' ORDER BY id ASC LIMIT ' . self::DELETE_BATCH_SIZE),
                'id'
            );

            $batchCount = self::deleteOccurrences($occurrenceIds);

            if ($batchCount === false) {
                return false;
            }

            $deletedCount += $batchCount;
        } while (\count($occurrenceIds) === self::DELETE_BATCH_SIZE && $batchCount > 0);

        return $deletedCount;
    }

    private static function deleteOccurrences(array $occurrenceIds)
    {
        $occurrenceIds = array_values(array_unique(array_map('intval', $occurrenceIds)));

        if (empty($occurrenceIds)) {
            return 0;
        }

        $placeholders = implode(',', array_fill(0, \count($occurrenceIds), '%d'));

        $deletedCount = Occurrences_Entity::delete_query(
            'DELETE FROM ' . Occurrences_Entity::get_table_name() . ' WHERE id IN (' . $placeholders . ')',
            $occurrenceIds
        );

        if ($deletedCount === false) {
            return false;
        }

        Metadata_Entity::delete_by_occurrence_ids($occurrenceIds);

        return (int) $deletedCount;
    }

    private static function getLatestOccurrence($eventId)
    {
        [$siteCondition, $siteArguments] = self::getSiteCondition();

        $occurrence = Occurrences_Entity::load('alert_id = %d AND ' . $siteCondition, array_merge([(int) $eventId], $siteArguments), null, ' ORDER BY id DESC LIMIT 1');

        return \is_array($occurrence) ? $occurrence : null;
    }

    private static function formatOccurrences(array $occurrences)
    {
        Occurrences_Entity::get_multi_meta_array($occurrences);

        return array_values(
            array_map(
                function ($occurrence) {
                    $event = self::getEvent($occurrence['alert_id']);
                    $meta = (array) ($occurrence['meta_values'] ?? []);
                    $message = $event ? Alert::get_message($meta, null, (int) $occurrence['alert_id'], (int) $occurrence['id'], 'dashboard-widget') : '';

                    return [
                        'occurrence_id'     => (int) $occurrence['id'],
                        'event_id'          => (int) $occurrence['alert_id'],
                        'event_description' => $event ? html_entity_decode($event['desc']) : '',
                        'message'           => \is_string($message) ? html_entity_decode($message) : '',
                        'username'          => $occurrence['username'] ?? '',
                        'user_id'           => (int) ($occurrence['user_id'] ?? 0),
                        'client_ip'         => $occurrence['client_ip'] ?? '',
                        'created_at'        => wp_date('Y-m-d H:i:s', (int) $occurrence['created_on']),
                        'meta'              => $meta,
                    ];
                },
                $occurrences
            )
        );
    }

    private static function toTimestamp($value)
    {
        foreach (self::DATE_FORMATS as $format) {
            $date = DateTime::createFromFormat('!' . $format, $value, wp_timezone());

            if ($date instanceof DateTime && $date->format($format) === $value) {
                return (float) $date->getTimestamp();
            }
        }
    }

    private static function toPositiveInt($value)
    {
        $value = trim((string) $value);

        return ctype_digit($value) && (int) $value > 0 ? (int) $value : null;
    }

    private static function isEmptyFilter($value)
    {
        return $value === null || $value === '' || $value === [];
    }

    private static function isNetworkSubsite()
    {
        return is_multisite() && !is_main_site();
    }

    private static function getSiteCondition()
    {
        return is_multisite() ? ['site_id = %d', [get_current_blog_id()]] : ['1 = %d', [1]];
    }

    private static function getEvent($eventId)
    {
        return Alert_Manager::get_alerts()[(int) $eventId] ?? null;
    }

    private static function conf($source, $key)
    {
        if (\is_object($source)) {
            return $source->{$key} ?? null;
        }

        return \is_array($source) ? ($source[$key] ?? null) : null;
    }

    private static function isPluginActive()
    {
        return \defined('WSAL_VERSION') && class_exists(Alert_Manager::class);
    }

    private static function pluginInactiveError()
    {
        return self::error(__('WP Activity Log is not installed or activated', 'bit-integrations-pro'));
    }

    private static function success($message, $data = [])
    {
        return ['success' => true, 'message' => $message, 'data' => $data];
    }

    private static function error($message)
    {
        return ['success' => false, 'message' => $message];
    }
}
