<?php

namespace BitApps\IntegrationsPro\Actions\FollowUpBoss\Services;

final class RelationshipService extends BaseService
{
    public function createRelationship(): array
    {
        $validationRules = ['person_id' => ['required', 'integer']];
        $error = $this->validateFields(
            $validationRules,
            [
                'person_id' => __('Person ID', 'bit-integrations-pro'),
            ]
        );

        if ($error !== null) {
            return $error;
        }

        $payload = $this->removeEmptyValues(
            [
                'personId'  => $this->getInteger('person_id'),
                'firstName' => $this->getString('first_name'),
                'lastName'  => $this->getString('last_name'),
                'type'      => $this->getString('type'),
                'emails'    => $this->getEmails('email'),
                'phones'    => $this->getPhones('phone'),
                'addresses' => $this->getAddresses(),
            ]
        );

        return $this->dispatch('POST', '/peopleRelationships', $payload);
    }

    public function updateRelationship(): array
    {
        $validationRules = ['relationship_id' => ['required', 'integer']];
        $error = $this->validateFields(
            $validationRules,
            [
                'relationship_id' => __('Relationship ID', 'bit-integrations-pro'),
            ]
        );

        if ($error !== null) {
            return $error;
        }

        $payload = $this->removeEmptyValues(
            [
                'firstName' => $this->getString('first_name'),
                'lastName'  => $this->getString('last_name'),
                'type'      => $this->getString('type'),
                'emails'    => $this->getEmails('email'),
                'phones'    => $this->getPhones('phone'),
                'addresses' => $this->getAddresses(),
            ]
        );

        return $this->dispatch('PUT', '/peopleRelationships/' . rawurlencode($this->getString('relationship_id')), $payload);
    }

    public function deleteRelationship(): array
    {
        $validationRules = ['relationship_id' => ['required', 'integer']];
        $error = $this->validateFields(
            $validationRules,
            [
                'relationship_id' => __('Relationship ID', 'bit-integrations-pro'),
            ]
        );

        if ($error !== null) {
            return $error;
        }

        return $this->dispatch('DELETE', '/peopleRelationships/' . rawurlencode($this->getString('relationship_id')));
    }
}
