<?php

namespace MasterStudy\Lms\Pro\addons\assignments\Repositories;

final class AssignmentAttachmentRepository {

	/**
	 * Add an instructor attachment to a student assignment.
	 *
	 * @return array{attachment_id: int, files_formats: array, icon_url: string}|\WP_Error
	 */
	public function add_instructor_attachment( int $post_id, int $attachment_id, bool $is_created ) {
		$is_attached      = false;
		$attached_post_id = get_post_field( 'post_parent', $attachment_id );

		if ( $attached_post_id > 0 && ! $is_created ) {
			$new_attachment_id = $this->copy_attachment( $attachment_id, $post_id );

			if ( is_wp_error( $new_attachment_id ) ) {
				return $new_attachment_id;
			}

			$attachment_id = $new_attachment_id;
			$is_attached   = true;
		} else {
			$updated = wp_update_post(
				array(
					'ID'          => $attachment_id,
					'post_parent' => $post_id,
				)
			);

			$is_attached = ! is_wp_error( $updated );
		}

		if ( ! $is_attached ) {
			return new \WP_Error( 'attachment_failed', 'Failed to attach file.', array( 'status' => 500 ) );
		}

		$attachments   = get_post_meta( $post_id, 'instructor_attachments', true );
		$attachments   = ! empty( $attachments ) ? $attachments : array();
		$attachments[] = $attachment_id;

		update_post_meta( $post_id, 'instructor_attachments', array_unique( $attachments ) );
		update_post_meta( $attachment_id, 'attachment_author', get_current_user_id() );

		return array(
			'attachment_id' => $attachment_id,
			'files_formats' => ms_plugin_files_formats(),
			'icon_url'      => STM_LMS_URL . 'assets/icons/files/new/',
		);
	}

	/**
	 * Delete an instructor attachment from a student assignment.
	 */
	public function delete_instructor_attachment( int $post_id, int $attachment_id ): bool {
		$deleted = wp_delete_attachment( $attachment_id, true );

		if ( ! $deleted ) {
			return false;
		}

		$attachments = get_post_meta( $post_id, 'instructor_attachments', true );

		if ( ! empty( $attachments ) ) {
			$key = array_search( $attachment_id, $attachments, true );

			if ( false !== $key ) {
				unset( $attachments[ $key ] );
				update_post_meta( $post_id, 'instructor_attachments', array_values( $attachments ) );
			}
		}

		return true;
	}

	/**
	 * Copy an existing attachment to a new file and attach it to the given post.
	 *
	 * @return int|\WP_Error New attachment ID or WP_Error on failure.
	 */
	private function copy_attachment( int $source_attachment_id, int $post_id ) {
		global $wp_filesystem;

		if ( ! is_a( $wp_filesystem, 'WP_Filesystem_Base' ) ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
			WP_Filesystem();
		}

		$file_path = get_attached_file( $source_attachment_id );

		if ( ! $file_path || ! file_exists( $file_path ) ) {
			return new \WP_Error( 'file_not_found', 'Source attachment file not found.', array( 'status' => 404 ) );
		}

		$filename       = basename( $file_path );
		$file_extension = strtolower( pathinfo( $filename, PATHINFO_EXTENSION ) );

		$validation = $this->validate_extension( $file_extension );

		if ( is_wp_error( $validation ) ) {
			return $validation;
		}

		$file_dir     = dirname( $file_path );
		$file_name    = wp_unique_filename( $file_dir, $filename );
		$updated_path = trailingslashit( $file_dir ) . $file_name;

		if ( ! $wp_filesystem->copy( $file_path, $updated_path, true ) ) {
			return new \WP_Error( 'copy_failed', 'Failed to copy attachment file.', array( 'status' => 500 ) );
		}

		$wp_filetype = wp_check_filetype( $file_name, null );
		$insert_args = array(
			'post_mime_type' => $wp_filetype['type'],
			'post_parent'    => $post_id,
			'post_title'     => preg_replace( '/\.[^.]+$/', '', $file_name ),
			'post_content'   => '',
			'post_status'    => 'inherit',
		);

		$new_attachment_id = wp_insert_attachment( $insert_args, $updated_path, $post_id );

		if ( is_wp_error( $new_attachment_id ) ) {
			return $new_attachment_id;
		}

		require_once ABSPATH . 'wp-admin/includes/image.php';

		$attachment_data = wp_generate_attachment_metadata( $new_attachment_id, $updated_path );
		wp_update_attachment_metadata( $new_attachment_id, $attachment_data );

		return $new_attachment_id;
	}

	/**
	 * Validate file extension against assignment settings allow-list.
	 *
	 * @return true|\WP_Error
	 */
	private function validate_extension( string $extension ) {
		$assignment_settings = \STM_LMS_Assignments::stm_lms_get_settings();
		$files_extension     = $assignment_settings['files_ext'] ?? '';
		$allowed_types       = array_map( 'trim', explode( ',', $files_extension ) );

		if ( ! in_array( $extension, $allowed_types, true ) ) {
			return new \WP_Error(
				'disallowed_type',
				'Disallowed file type: ' . $extension,
				array( 'status' => 400 )
			);
		}

		return true;
	}
}
