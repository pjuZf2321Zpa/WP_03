<?php
/**
 * Metabox handler for RSVP V2.
 *
 * @since 6.11.0
 *
 * @package TEC\Tickets_Plus\RSVP\V2
 */

namespace TEC\Tickets_Plus\RSVP\V2;

use Tribe\Tickets\Plus\Attendee_Registration\IAC;
use Tribe\Tickets\Plus\Meta\Field_Types_Collection;
use Tribe__Tickets_Plus__Admin__Views as Admin_Views;
use Tribe__Tickets_Plus__Meta as Meta;

/**
 * Class Metabox
 *
 * Renders admin metabox UI elements for RSVP V2.
 *
 * @since 6.11.0
 *
 * @package TEC\Tickets_Plus\RSVP\V2
 */
class Metabox {
	/**
	 * Prints the dialog append target.
	 *
	 * @since 6.11.0
	 *
	 * @return void
	 */
	public function print_dialog_append_target(): void {
		?>
		<div class="tec-dialog-container">
			<div id="tec_tickets_rsvp_metabox-dialog-append-target" style="display: none"></div>
		</div>
		<?php
	}

	/**
	 * Adds IAC modal for RSVP.
	 *
	 * @since 6.11.0
	 *
	 * @param int $post_id Post ID.
	 * @param int $rsvp_id Ticket ID.
	 */
	public function add_iac( int $post_id, int $rsvp_id ): void {
		/** @var Assets $assets */
		$assets = tribe( Assets::class );
		$assets->enqueue_admin_assets();

		/** @var IAC $iac */
		$iac = tribe( 'tickets-plus.attendee-registration.iac' );

		$iac_options     = $iac->get_iac_setting_options();
		$current_setting = $iac->get_iac_setting_for_ticket( $rsvp_id );

		// The modal radio pre-selects the global default for a brand-new (unsaved)
		// RSVP, which has no ticket yet and therefore no saved setting. The trigger
		// button state below still reflects the saved setting (none for a new RSVP),
		// so the button shows the idle "Collect attendee information" state until a
		// ticket is created. This mirrors the paid-ticket path (IAC\Ticket_Settings).
		$selected = $current_setting;
		if ( empty( $rsvp_id ) ) {
			$selected = $iac->get_default_iac_setting();
		}

		/** @var Meta $meta */
		$meta = tribe( 'tickets-plus.meta' );

		$field_types = tribe( Field_Types_Collection::class )->get();

		$saved_fieldsets = $meta->meta_fieldset()->get_fieldsets();

		$current_meta_fields = [];
		if ( ! empty( $rsvp_id ) ) {
			$current_meta_fields = $meta->get_meta_fields_by_ticket( $rsvp_id );
		}

		$template_context = [
			'post_id'             => $post_id,
			'ticket_id'           => $rsvp_id,
			'iac_options'         => $iac_options,
			'selected'            => $selected,
			'field_types'         => $field_types,
			'saved_fieldsets'     => $saved_fieldsets,
			'current_meta_fields' => $current_meta_fields,
		];

		/** @var Admin_Views $admin_views */
		$admin_views = tribe( 'tickets-plus.admin.views' );

		$modal_content = $admin_views->template( 'editor/rsvp/panel/iac-modal-content', $template_context, false );

		// Replace period with underscore to make the ID CSS-selector safe.
		$btn_id = str_replace( '.', '_', uniqid( '', true ) );

		$iac_is_active   = IAC::NONE_KEY !== $current_setting;
		$has_meta_fields = ! empty( $current_meta_fields ) || $iac_is_active;
		$button_text     = $has_meta_fields
			? esc_html_x( 'Attendee Information', 'Button text when attendee meta fields exist', 'event-tickets-plus' )
			: '<span class="dashicons dashicons-plus" title="' . esc_attr__( 'Individual Attendee Collection', 'event-tickets-plus' ) . '"></span>' . esc_html_x( 'Collect attendee information', 'Button text when no attendee meta fields exist', 'event-tickets-plus' );

		$button_icon = $has_meta_fields
			? '<span class="dashicons dashicons-edit tec-tickets-rsvp-iac-edit-icon" title="' . esc_attr__( 'Edit Attendee Information', 'event-tickets-plus' ) . '"></span>'
			: '';

		// Build field labels list for display.
		$field_labels_html = '';
		if ( $has_meta_fields ) {
			$field_labels = [];

			// If IAC is active, prepend "Name" and "Email" labels.
			if ( $iac_is_active ) {
				$field_labels[] = esc_html__( 'Name', 'event-tickets-plus' );
				$field_labels[] = esc_html__( 'Email', 'event-tickets-plus' );
			}

			foreach ( $current_meta_fields as $field ) {
				$field_labels[] = esc_html( $field->label );
			}

			$field_labels_html = '<span class="tec-tickets-rsvp-iac-field-labels">' . implode( ', ', $field_labels ) . '</span>';
		}

		$iac_button_attributes = [
			'data-modal-title' => esc_html__( 'Attendee Information', 'event-tickets-plus' ),
		];

		$button_args = [
			'id'                      => 'tec-tickets__admin-iac-' . $btn_id,
			'append_target'           => '#tec_tickets_rsvp_metabox-dialog-append-target',

			/*
			 * The dialog's body lock pins `body` to `position: fixed` and releases it on close.
			 * In the Classic Editor that reflow makes TinyMCE reclaim focus, and the browser
			 * scrolls its iframe — which sits at the top of the post screen — into view, so the
			 * editor loses its place on the page.
			 */
			'body_lock'               => false,
			'button_classes'          => [ 'button', 'button-secondary', 'tec-tickets__admin-iac-settings' ],
			'button_attributes'       => $iac_button_attributes,
			'button_display'          => true,
			'button_id'               => 'tec-tickets__admin-iac-details-' . $btn_id,
			'button_name'             => 'tec-tickets-iac-settings',
			'button_text'             => $button_text . $button_icon . $field_labels_html,
			'button_type'             => 'button',
			'content_wrapper_classes' => 'tribe-dialog__wrapper event-tickets',
			'title'                   => esc_html__( 'Attendee Information', 'event-tickets-plus' ),
			'title_classes'           => [
				'tribe-dialog__title',
				'tribe-modal__title',
				'tribe-common-h2',
			],
		];

		$admin_views->template(
			'editor/rsvp/panel/iac-modal-button',
			[
				'has_meta_fields' => $has_meta_fields,
				'modal_content'   => $modal_content,
				'button_args'     => $button_args,
			]
		);
	}

	/**
	 * Renders IAC options on the attendee registration page used by the block editor.
	 *
	 * The block editor ARF modal loads this page in a same-origin iframe so the
	 * existing field builder can be reused. IAC sync with the parent editor is
	 * handled by attendee-registration-iac.js via the shared global callback.
	 *
	 * @since 6.11.0
	 *
	 * @param int $ticket_id The ticket ID.
	 * @param int $post_id   The post ID.
	 */
	public function render_iac_in_attendee_registration( int $ticket_id, int $post_id ): void {
		/** @var Assets $assets */
		$assets = tribe( Assets::class );
		$assets->enqueue_attendee_registration_iac_assets();

		/** @var IAC $iac */
		$iac = tribe( 'tickets-plus.attendee-registration.iac' );

		$iac_options     = $iac->get_iac_setting_options();
		$current_setting = $iac->get_iac_setting_for_ticket( $ticket_id );

		/** @var Admin_Views $admin_views */
		$admin_views = tribe( 'tickets-plus.admin.views' );

		$admin_views->template(
			'editor/rsvp/panel/attendee-registration-iac',
			[
				'ticket_id'   => $ticket_id,
				'post_id'     => $post_id,
				'iac_options' => $iac_options,
				'selected'    => $current_setting,
			]
		);
	}

	/**
	 * Saves the IAC setting from the attendee registration form submission.
	 *
	 * @since 6.11.0
	 *
	 * @param int                           $post_id The post ID.
	 * @param Tribe__Tickets__Ticket_Object $ticket  The ticket object.
	 * @param array                         $data    The submitted POST data.
	 */
	public function save_iac_from_attendee_registration( int $post_id, $ticket, array $data ): void {
		if ( empty( $data['ticket_iac'] ) ) {
			return;
		}

		/** @var IAC $iac */
		$iac = tribe( 'tickets-plus.attendee-registration.iac' );

		$valid_keys = [ IAC::NONE_KEY, IAC::ALLOWED_KEY, IAC::REQUIRED_KEY ];
		$iac_value  = sanitize_text_field( $data['ticket_iac'] );

		if ( ! in_array( $iac_value, $valid_keys, true ) ) {
			return;
		}

		update_post_meta( $ticket->ID, $iac->get_iac_setting_ticket_meta_key(), $iac_value );
	}

	/**
	 * Add attendees list setting to RSVP post options section.
	 *
	 * @since 6.11.0
	 *
	 * @param int $post_id Post ID.
	 * @param int $rsvp_id RSVP ID.
	 */
	public function add_show_attendees( int $post_id, int $rsvp_id ): void {
		/** @var Admin_Views $admin_views */
		$admin_views = tribe( 'tickets-plus.admin.views' );
		if ( ! $admin_views ) {
			return;
		}

		$show_attendees = tribe_is_truthy( get_post_meta( $post_id, Constants::SHOW_RSVP_META_KEY, true ) );

		$template_context = [
			'post_id'        => $post_id,
			'rsvp_id'        => $rsvp_id,
			'show_attendees' => $show_attendees,
		];

		$admin_views->template( 'editor/rsvp/panel/show-attendees', $template_context );
	}

	/**
	 * Add waitlist options setting to RSVP post options section.
	 *
	 * @since 6.11.0
	 *
	 * @param int $post_id Post ID.
	 * @param int $rsvp_id RSVP ID.
	 */
	public function add_waitlist_options( int $post_id, int $rsvp_id ): void {
		/** @var Admin_Views $admin_views */
		$admin_views = tribe( 'tickets-plus.admin.views' );

		$waitlist_before_sale = get_post_meta( $rsvp_id, '_tec_rsvp_waitlist_before_sale', true );
		$waitlist_sold_out    = get_post_meta( $rsvp_id, '_tec_rsvp_waitlist_sold_out', true );

		$template_context = [
			'post_id'              => $post_id,
			'rsvp_id'              => $rsvp_id,
			'waitlist_before_sale' => $waitlist_before_sale,
			'waitlist_sold_out'    => $waitlist_sold_out,
		];

		$admin_views->template( 'editor/rsvp/panel/waitlist-before-sale', $template_context );
		$admin_views->template( 'editor/rsvp/panel/waitlist-sold-out', $template_context );
	}
}
