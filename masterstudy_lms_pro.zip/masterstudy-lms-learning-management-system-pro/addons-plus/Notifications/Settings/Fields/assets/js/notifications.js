Vue.component('wpcfto_masterstudy_notifications_triggers', {
	props: ['fields', 'field_value'],
	data: function () {
		return {
			value: {},
		};
	},
	template: `
		<div class="wpcfto_generic_field masterstudy-notifications-settings">
			<div class="masterstudy-notifications-settings__groups">
				<div class="masterstudy-notifications-settings__group" v-for="group in fields.groups" :key="group.key">
					<div class="masterstudy-notifications-settings__group-header">
						<h3 class="masterstudy-notifications-settings__group-title">{{ displayText(group.label) }}</h3>
						<div class="masterstudy-notifications-settings__group-actions">
							<button
								type="button"
								class="masterstudy-notifications-settings__bulk-action"
								:disabled="isGroupFullyEnabled(group)"
								@click="setGroupChannels(group, true)"
							>
								{{ bulkActionLabel('enable_all') }}
							</button>
							<button
								type="button"
								class="masterstudy-notifications-settings__bulk-action"
								:disabled="isGroupFullyDisabled(group)"
								@click="setGroupChannels(group, false)"
							>
								{{ bulkActionLabel('disable_all') }}
							</button>
						</div>
					</div>
					<div class="masterstudy-notifications-settings__list">
						<div class="masterstudy-notifications-settings__row" v-for="trigger in group.events" :key="trigger.key">
							<div class="masterstudy-notifications-settings__content">
								<div class="masterstudy-notifications-settings__title">{{ displayText(trigger.label) }}</div>
								<div class="masterstudy-notifications-settings__description">{{ displayText(trigger.description) }}</div>
							</div>
							<div class="masterstudy-notifications-settings__channels">
								<label class="masterstudy-notifications-settings__channel">
									<span class="masterstudy-notifications-settings__checkbox" :class="{ 'is-active': isChecked(trigger.key, 'on_site') }">
										<input type="checkbox" :checked="isChecked(trigger.key, 'on_site')" @change="updateChannel(trigger.key, 'on_site', $event)">
									</span>
									<span>{{ displayText(fields.channel_labels.on_site) }}</span>
								</label>
								<label class="masterstudy-notifications-settings__channel">
									<span class="masterstudy-notifications-settings__checkbox" :class="{ 'is-active': isChecked(trigger.key, 'push') }">
										<input type="checkbox" :checked="isChecked(trigger.key, 'push')" @change="updateChannel(trigger.key, 'push', $event)">
									</span>
									<span>{{ displayText(fields.channel_labels.push) }}</span>
								</label>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	`,
	mounted: function () {
		this.value = this.normalizeValue(this.field_value);
		this.emitValue();
	},
	methods: {
		normalizeValue: function (rawValue) {
			var savedValue = rawValue;
			var normalized = {};

			if (typeof savedValue === 'string') {
				try {
					savedValue = JSON.parse(savedValue);
				} catch (error) {
					savedValue = {};
				}
			}

			if (!savedValue || typeof savedValue !== 'object' || Array.isArray(savedValue)) {
				savedValue = {};
			}

			this.getAllGroups().forEach(function (group) {
				(group.events || []).forEach(function (trigger) {
					var triggerValue = savedValue[trigger.key] || {};

					normalized[trigger.key] = {
						on_site: this.toBoolean(triggerValue.on_site),
						push: this.toBoolean(triggerValue.push),
					};
				}.bind(this));
			}.bind(this));

			return normalized;
		},
		getAllGroups: function () {
			if (this.fields && Array.isArray(this.fields.all_groups)) {
				return this.fields.all_groups;
			}

			return this.fields && Array.isArray(this.fields.groups) ? this.fields.groups : [];
		},
		toBoolean: function (value) {
			return value === true || value === 'true' || value === '1' || value === 1 || value === 'on';
		},
		displayText: function (value) {
			var textarea = document.createElement('textarea');

			textarea.innerHTML = value === undefined || value === null ? '' : String(value);

			return textarea.value;
		},
		bulkActionLabel: function (key) {
			var labels = this.fields.bulk_action_labels || {};
			var fallbacks = {
				enable_all: 'Enable all',
				disable_all: 'Disable all',
			};

			return this.displayText(labels[key] || fallbacks[key] || '');
		},
		isChecked: function (triggerKey, channel) {
			return !!(this.value[triggerKey] && this.value[triggerKey][channel]);
		},
		isGroupFullyEnabled: function (group) {
			return !this.hasGroupTriggers(group) || (group.events || []).every(function (trigger) {
				return this.isChecked(trigger.key, 'on_site') && this.isChecked(trigger.key, 'push');
			}.bind(this));
		},
		isGroupFullyDisabled: function (group) {
			return !this.hasGroupTriggers(group) || (group.events || []).every(function (trigger) {
				return !this.isChecked(trigger.key, 'on_site') && !this.isChecked(trigger.key, 'push');
			}.bind(this));
		},
		hasGroupTriggers: function (group) {
			return !!(group && Array.isArray(group.events) && group.events.length);
		},
		setGroupChannels: function (group, checked) {
			if (!this.hasGroupTriggers(group)) {
				return;
			}

			(group.events || []).forEach(function (trigger) {
				if (!this.value[trigger.key]) {
					this.$set(this.value, trigger.key, {});
				}

				this.$set(this.value[trigger.key], 'on_site', checked);
				this.$set(this.value[trigger.key], 'push', checked);
			}.bind(this));

			this.emitValue();
		},
		updateChannel: function (triggerKey, channel, event) {
			if (!this.value[triggerKey]) {
				this.$set(this.value, triggerKey, {});
			}

			this.$set(this.value[triggerKey], channel, event.target.checked);
			this.emitValue();
		},
		emitValue: function () {
			this.$emit('wpcfto-get-value', this.value);
		},
	},
});
