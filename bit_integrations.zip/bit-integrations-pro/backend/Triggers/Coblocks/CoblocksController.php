<?php

namespace BitApps\IntegrationsPro\Triggers\Coblocks;

use BitApps\IntegrationsPro\Config;
use WP_Error;

class CoblocksController
{
    public static function info()
    {
        return [
            'name'      => 'CoBlocks Form',
            'title'     => __('Get callback data through an URL', 'bit-integrations-pro'),
            'type'      => 'coblocks',
            'documentation_url' => 'https://bit-integrations.com/wp-docs/trigger/coblocks-integrations/',
            'tutorial_url'      => 'https://www.youtube.com/playlist?list=PL7c6CDwwm-AI3cQxtPuRI6ssSihs7hRkq',
            'is_active' => true,
            'isPro'     => true
        ];
    }

    public function getTestData()
    {
        $testData = get_option(Config::withFreePrefix('test_coblocks_form_submit'));

        if ($testData === false) {
            update_option(Config::withFreePrefix('test_coblocks_form_submit'), []);
        }
        if (!$testData || empty($testData)) {
            wp_send_json_error(new WP_Error('coblocks_test', __('Coblocks data is empty', 'bit-integrations-pro')));
        }
        wp_send_json_success(['coblocks' => $testData]);
    }

    public function removeTestData($data)
    {
        $testData = delete_option(Config::withFreePrefix('test_coblocks_form_submit'));

        if (!$testData) {
            wp_send_json_error(new WP_Error('coblocks_test', __('Failed to remove test data', 'bit-integrations-pro')));
        }
        wp_send_json_success(__('coblocks test data removed successfully', 'bit-integrations-pro'));
    }

    public static function coblocksHandler(...$args)
    {
        $flowClass = bit_integrations_get_class('Flow\\Flow');

        if (get_option(Config::withFreePrefix('test_coblocks_form_submit')) !== false) {
            update_option(Config::withFreePrefix('test_coblocks_form_submit'), $args);
        }

        if ($flows = $flowClass::exists('Coblocks', current_action())) {
            foreach ($flows as $flow) {
                $flowDetails = json_decode($flow->flow_details);
                if (!isset($flowDetails->primaryKey)) {
                    continue;
                }

                $primaryKeyValue = self::extractValueFromPath($args, $flowDetails->primaryKey->key);

                if ($flowDetails->primaryKey->value->value === $primaryKeyValue['value']) {
                    $fieldKeys = [];
                    $formatedData = [];

                    if (isset($flowDetails->body->data) && $flowDetails->body->data && \is_array($flowDetails->body->data)) {
                        $fieldKeys = array_map(function ($field) use ($args) {
                            return $field->key;
                        }, $flowDetails->body->data);
                    } elseif (isset($flowDetails->field_map) && \is_array($flowDetails->field_map)) {
                        $fieldKeys = array_map(function ($field) use ($args) {
                            return $field->formField;
                        }, $flowDetails->field_map);
                    }

                    foreach ($fieldKeys as $key) {
                        $formatedData[$key] = \is_array(self::extractValueFromPath($args, $key)) ? self::extractValueFromPath($args, $key)['value'] : self::extractValueFromPath($args, $key);
                    }

                    $flowClass::execute('Coblocks', current_action(), $formatedData, [$flow]);
                }
            }
        }

        return rest_ensure_response(['status' => 'success']);
    }

    private static function extractValueFromPath($data, $path)
    {
        $parts = \is_array($path) ? $path : explode('.', $path);
        if (\count($parts) === 0) {
            return $data;
        }

        $currentPart = array_shift($parts);

        if (\is_array($data)) {
            if (!isset($data[$currentPart])) {
                wp_send_json_error(new WP_Error('Coblocks', __('Index out of bounds or invalid', 'bit-integrations-pro')));
            }

            return self::extractValueFromPath($data[$currentPart], $parts);
        }

        if (\is_object($data)) {
            if (!property_exists($data, $currentPart)) {
                wp_send_json_error(new WP_Error('Coblocks', __('Invalid path', 'bit-integrations-pro')));
            }

            return self::extractValueFromPath($data->{$currentPart}, $parts);
        }

        wp_send_json_error(new WP_Error('Coblocks', __('Invalid path', 'bit-integrations-pro')));
    }
}
