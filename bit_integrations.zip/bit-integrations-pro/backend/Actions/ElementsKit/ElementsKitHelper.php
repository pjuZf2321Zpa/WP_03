<?php

namespace BitApps\IntegrationsPro\Actions\ElementsKit;

use WP_Post;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Shared ElementsKit writers. Mirrors the meta keys ElementsKit's own
 * Header-Footer screen writes, so records created here are indistinguishable
 * from ones built in its UI.
 */
final class ElementsKitHelper
{
    public const TEMPLATE_POST_TYPE = 'elementskit_template';

    public const WIDGET_POST_TYPE = 'elementskit_widget';

    public const CONTENT_POST_TYPE = 'elementskit_content';


    public const TEMPLATE_TYPE_META = 'elementskit_template_type';

    public const TEMPLATE_ACTIVATION_META = 'elementskit_template_activation';

    public const TEMPLATE_CONDITION_META = 'elementskit_template_condition_a';

    public const TEMPLATE_CONDITION_SINGULAR_META = 'elementskit_template_condition_singular';

    public const TEMPLATE_CONDITION_SINGULAR_ID_META = 'elementskit_template_condition_singular_id';

    public const PAGE_TEMPLATE_META = '_wp_page_template';

    public const EDIT_MODE_META = '_elementor_edit_mode';

    public static function isPluginActive()
    {
        return class_exists('ElementsKit_Lite');
    }

    public static function isPostOfType($post, $postType)
    {
        return $post instanceof WP_Post && $post->post_type === $postType;
    }

    public static function normalizeStatus($status)
    {
        return \in_array($status, ['publish', 'draft', 'pending', 'private', 'future'], true) ? $status : 'publish';
    }

    public static function normalizeTemplateType($type)
    {
        return \in_array($type, ['header', 'footer', 'section'], true) ? $type : 'section';
    }

    public static function normalizeActivation($activation)
    {
        return \in_array($activation, ['yes', true, 'true', 1, '1'], true) ? 'yes' : 'no';
    }

    /**
     * ElementsKit CPTs are Elementor documents — the plugin's own writers always
     * stamp these two meta keys, so every record created here does the same.
     */
    public static function seedElementorMeta($postId)
    {
        update_post_meta($postId, self::PAGE_TEMPLATE_META, 'elementor_canvas');
        update_post_meta($postId, self::EDIT_MODE_META, 'builder');
    }

    public static function success($message, $data = [])
    {
        return ['success' => true, 'message' => $message, 'data' => $data];
    }

    public static function error($message)
    {
        return ['success' => false, 'message' => $message];
    }

    /**
     * Read an optional value out of the Utilities object the free side forwards.
     */
    public static function utility($utilities, $key, $fallback = null)
    {
        if (\is_object($utilities) && isset($utilities->{$key}) && $utilities->{$key} !== '') {
            return $utilities->{$key};
        }

        if (\is_array($utilities) && isset($utilities[$key]) && $utilities[$key] !== '') {
            return $utilities[$key];
        }

        return $fallback;
    }

    public static function config($integrationDetails, $key, $fallback = null)
    {
        if (\is_object($integrationDetails) && isset($integrationDetails->{$key}) && $integrationDetails->{$key} !== '') {
            return $integrationDetails->{$key};
        }

        return $fallback;
    }

    public static function isProvided($fieldData, $key)
    {
        return isset($fieldData[$key]) && $fieldData[$key] !== '';
    }

    /**
     * Write the display meta ElementsKit reads when deciding where a header or
     * footer renders. On update, only the keys actually supplied are touched.
     */
    public static function writeTemplateMeta($templateId, array $fieldData, $type, $activation, $isCreate)
    {
        $hasType = $type !== null && $type !== '';

        $resolvedType = $hasType
            ? self::normalizeTemplateType($type)
            : get_post_meta($templateId, self::TEMPLATE_TYPE_META, true);

        if ($isCreate || $hasType) {
            update_post_meta($templateId, self::TEMPLATE_TYPE_META, $resolvedType);
        }

        if ($isCreate || ($activation !== null && $activation !== '')) {
            update_post_meta($templateId, self::TEMPLATE_ACTIVATION_META, self::normalizeActivation($activation ?? 'no'));
        }

        // A "section" template renders on demand, so it never carries display conditions.
        $isSection = $resolvedType === 'section';

        $conditionMap = [
            self::TEMPLATE_CONDITION_META             => 'condition',
            self::TEMPLATE_CONDITION_SINGULAR_META    => 'condition_singular',
            self::TEMPLATE_CONDITION_SINGULAR_ID_META => 'condition_singular_id',
        ];

        foreach ($conditionMap as $metaKey => $fieldKey) {
            if (!$isCreate && !self::isProvided($fieldData, $fieldKey)) {
                continue;
            }

            update_post_meta($templateId, $metaKey, $isSection ? '' : ($fieldData[$fieldKey] ?? ''));
        }
    }

    public static function deleteRecord($postId, $forceDelete, $failureMessage, $successMessage)
    {
        $deleted = wp_delete_post($postId, !empty($forceDelete));

        if (!$deleted) {
            return self::error($failureMessage);
        }

        return self::success($successMessage, ['id' => $postId]);
    }
}
