<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Actions\SmartSuite\SmartSuiteProHelper;
use BitApps\IntegrationsPro\Config;
use BitApps\IntegrationsPro\Core\Util\Hooks;

// Deprecated since v2.7.8 - use bit_integrations_smartsuite_* hooks instead
if (bit_integrations_version_below('2.7.8')) {
    Hooks::filter('btcbi_smartSuite_create_table', [SmartSuiteProHelper::class, 'createTable'], 10, 5);
    Hooks::filter('btcbi_smartSuite_create_record', [SmartSuiteProHelper::class, 'createRecord'], 10, 5);
}

// New hooks since v2.7.8
Hooks::filter(Config::withFreePrefix('smartSuite_create_table'), [SmartSuiteProHelper::class, 'createTable'], 10, 5);
Hooks::filter(Config::withFreePrefix('smartSuite_create_record'), [SmartSuiteProHelper::class, 'createRecord'], 10, 5);
