<?php
/** Paid Smart SEO controls for the Content Writer settings panel. */
if (!defined('ABSPATH')) {
    exit;
}

function aipkit_render_paid_content_writer_seo_panel(string $aipkit_panel, array $aipkit_profile = []): void
{
    if (!class_exists('\\WPAICG\\aipkit_dashboard') || !\WPAICG\aipkit_dashboard::is_pro_plan()) {
        return;
    }
    if ($aipkit_panel === 'toggle') {
        ?>
                <div class="aipkit_cw_panel_label_wrap">
                    <label class="aipkit_cw_panel_label" for="aipkit_cw_seo_score_improvement_enabled">
                        <?php esc_html_e('Smart SEO', 'gpt3-ai-content-generator'); ?>
                    </label>
                </div>
                <div class="aipkit_cw_ai_control aipkit_cw_ai_control--compact">
                    <div class="aipkit_cw_seo_inline_actions">
                        <label class="aipkit_switch aipkit_cw_seo_inline_switch" title="<?php esc_attr_e('Smart SEO auto-improvement', 'gpt3-ai-content-generator'); ?>">
                            <input
                                type="checkbox"
                                id="aipkit_cw_seo_score_improvement_enabled"
                                name="seo_score_improvement_enabled"
                                class="aipkit_toggle_switch aipkit_autosave_trigger"
                                value="1"
                                data-aipkit-seo-control
                                data-aipkit-seo-main-toggle
                            >
                            <span class="aipkit_switch_slider"></span>
                        </label>
                    </div>
                </div>
        <?php
        return;
    }
    if (!in_array($aipkit_panel, ['approach', 'popover'], true)) {
        return;
    }
    $seo_rules_class = '\\WPAICG\\ContentWriter\\SEO\\AIPKit_Content_Writer_Smart_SEO_Rules';
    if (!class_exists($seo_rules_class) && defined('WPAICG_LIB_DIR')) {
        $seo_rules_path = WPAICG_LIB_DIR . 'content-writer/seo-rules.php';
        if (file_exists($seo_rules_path)) {
            require_once $seo_rules_path;
        }
    }
    if (!class_exists($seo_rules_class) || empty($seo_rules_class::rule_catalog())) {
        return;
    }
    if ($aipkit_panel === 'approach') {
        ?>
            <div
                class="aipkit_cw_seo_row aipkit_cw_seo_approach_row"
                data-aipkit-smart-seo-rules-action
                hidden
            >
                <div class="aipkit_cw_panel_label_wrap">
                    <span
                        class="aipkit_cw_panel_label"
                        id="aipkit_cw_smart_seo_approach_label"
                    >
                        <?php esc_html_e('SEO approach', 'gpt3-ai-content-generator'); ?>
                    </span>
                </div>
                <button
                    type="button"
                    class="aipkit_cw_seo_approach_trigger"
                    id="aipkit_cw_smart_seo_rules_trigger"
                    data-aipkit-smart-seo-modal-trigger
                    data-aipkit-smart-seo-modal-target="aipkit_cw_smart_seo_rules_popover"
                    aria-controls="aipkit_cw_smart_seo_rules_popover"
                    aria-expanded="false"
                    aria-haspopup="dialog"
                    aria-labelledby="aipkit_cw_smart_seo_approach_label aipkit_cw_smart_seo_approach_value"
                >
                    <span id="aipkit_cw_smart_seo_approach_value" data-aipkit-smart-seo-trigger-value>
                        <?php esc_html_e('Balanced', 'gpt3-ai-content-generator'); ?>
                    </span>
                    <span class="aipkit_cw_seo_approach_chevron" aria-hidden="true"></span>
                </button>
            </div>
        <?php
        return;
    }
    $aipkit_profile = array_merge([
        'key' => 'aipkit',
        'label' => __('AIPKit SEO', 'gpt3-ai-content-generator'),
        'logo_url' => '',
        'logo_initials' => 'AI',
    ], $aipkit_profile);
    $aipkit_smart_seo_rules_popover_id = 'aipkit_cw_smart_seo_rules_popover';
    $aipkit_smart_seo_rules_profile_key = $aipkit_profile['key'];
    $aipkit_smart_seo_rules_profile_label = $aipkit_profile['label'];
    $aipkit_smart_seo_rules_profile_logo_url = $aipkit_profile['logo_url'];
    $aipkit_smart_seo_rules_profile_logo_initials = $aipkit_profile['logo_initials'];
    $aipkit_smart_seo_rules_popover_path = defined('WPAICG_LIB_DIR') ? WPAICG_LIB_DIR . 'views/shared/smart-seo-rules-popover.php' : '';
    if ($aipkit_smart_seo_rules_popover_path !== '' && file_exists($aipkit_smart_seo_rules_popover_path)) {
        include $aipkit_smart_seo_rules_popover_path;
    }
}


/** Paid score display and one-click improvement; the Free upgrade card stays shared. */
function aipkit_render_paid_content_writer_seo_output(string $aipkit_panel, array $aipkit_profile): void
{
    if (!class_exists('\\WPAICG\\aipkit_dashboard') || !\WPAICG\aipkit_dashboard::is_pro_plan()) {
        return;
    }
    $aipkit_cw_output_seo_profile_label = isset($aipkit_profile['label']) ? (string) $aipkit_profile['label'] : __('AIPKit SEO', 'gpt3-ai-content-generator');
    $aipkit_cw_output_seo_profile_logo_url = isset($aipkit_profile['logo_url']) ? (string) $aipkit_profile['logo_url'] : '';
    $aipkit_cw_output_seo_profile_logo_initials = isset($aipkit_profile['logo_initials']) ? (string) $aipkit_profile['logo_initials'] : 'SEO';
    if ($aipkit_panel === 'summary') {
        ?>
                        <div
                            id="aipkit_cw_seo_audit_summary"
                            class="aipkit_cw_seo_audit_summary"
                            data-aipkit-meta-group="seo"
                            data-aipkit-seo-audit-state="idle"
                            aria-live="polite"
                            hidden
                        >
                            <div class="aipkit_cw_seo_audit_top">
                                <div
                                    class="aipkit_cw_seo_score_ring"
                                    data-aipkit-seo-score-ring
                                    style="--aipkit-cw-seo-score-angle: 0deg;"
                                    aria-label="<?php esc_attr_e('SEO score', 'gpt3-ai-content-generator'); ?>"
                                >
                                    <span class="aipkit_cw_seo_score_value" data-aipkit-seo-score-value>--</span>
                                    <span class="aipkit_cw_seo_score_total">/100</span>
                                </div>
                                <div class="aipkit_cw_seo_audit_copy">
                                    <div class="aipkit_cw_seo_audit_status_row">
                                        <span class="aipkit_cw_seo_audit_status" data-aipkit-seo-audit-status>
                                            <?php esc_html_e('SEO audit pending', 'gpt3-ai-content-generator'); ?>
                                        </span>
                                        <span
                                            class="aipkit_cw_seo_audit_profile"
                                            data-aipkit-seo-audit-profile
                                            data-aipkit-seo-profile-logo="<?php echo esc_url($aipkit_cw_output_seo_profile_logo_url); ?>"
                                            data-aipkit-seo-profile-initials="<?php echo esc_attr($aipkit_cw_output_seo_profile_logo_initials); ?>"
                                            data-aipkit-seo-profile-label="<?php echo esc_attr($aipkit_cw_output_seo_profile_label); ?>"
                                            hidden
                                        ></span>
                                    </div>
                                    <div class="aipkit_cw_seo_audit_meta">
                                        <span data-aipkit-seo-audit-target><?php esc_html_e('0 revisions', 'gpt3-ai-content-generator'); ?></span>
                                    </div>
                                </div>
                            </div>
                        </div>
        <?php
        return;
    }
    if ($aipkit_panel === 'run') {
        ?>
                        <div
                            id="aipkit_cw_smart_seo_run_card"
                            class="aipkit_cw_smart_seo_run_card"
                            data-aipkit-meta-group="seo"
                            aria-live="polite"
                            hidden
                        >
                            <div class="aipkit_cw_smart_seo_locked_top">
                                <div class="aipkit_cw_smart_seo_locked_copy">
                                    <p>
                                        <?php
                                        printf(
                                            /* translators: %s: active SEO plugin name. */
                                            esc_html__('AI Puffer integrates with %s. Improve this draft with Smart SEO before saving.', 'gpt3-ai-content-generator'),
                                            esc_html($aipkit_cw_output_seo_profile_label)
                                        );
                                        ?>
                                    </p>
                                </div>
                            </div>
                            <div class="aipkit_cw_smart_seo_locked_footer">
                                <span
                                    class="aipkit_cw_smart_seo_locked_profile"
                                    title="<?php echo esc_attr($aipkit_cw_output_seo_profile_label); ?>"
                                    aria-label="<?php echo esc_attr($aipkit_cw_output_seo_profile_label); ?>"
                                    role="img"
                                >
                                    <span class="aipkit_seo_profile_logo aipkit_seo_profile_logo--tiny" aria-hidden="true">
                                        <?php if ($aipkit_cw_output_seo_profile_logo_url !== '') : ?>
                                            <img src="<?php echo esc_url($aipkit_cw_output_seo_profile_logo_url); ?>" alt="">
                                    <?php else : ?>
                                        <span><?php echo esc_html($aipkit_cw_output_seo_profile_logo_initials); ?></span>
                                    <?php endif; ?>
                                    </span>
                                    <span><?php echo esc_html($aipkit_cw_output_seo_profile_label); ?></span>
                                </span>
                                <button
                                    type="button"
                                    id="aipkit_cw_smart_seo_run_btn"
                                    class="aipkit_btn aipkit_btn-primary aipkit_cw_smart_seo_locked_btn"
                                >
                                    <span class="aipkit_btn-text"><?php esc_html_e('Improve SEO', 'gpt3-ai-content-generator'); ?></span>
                                    <span class="aipkit_spinner" style="display:none;"></span>
                                </button>
                            </div>
                        </div>
        <?php
        return;
    }
}
