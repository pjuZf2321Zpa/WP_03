<?php

namespace MasterStudy\Lms\Pro\AddonsPlus\GoogleMeet\Http\Serializers;

use MasterStudy\Lms\Http\Serializers\AbstractSerializer;

final class GoogleMeetListSerializer extends AbstractSerializer {

	/**
	 * @param \WP_Post $post
	 */
	public function toArray( $post ): array {
		$author_id  = (int) $post->post_author;
		$author     = isset( $post->author_label ) ? (string) $post->author_label : null;
		$host_email = get_the_author_meta( 'user_email', $author_id );
		$start_date = $this->resolve_boundary_timestamp( $post->start_date ?? null, $post->start_time ?? null );
		$end_date   = $this->resolve_boundary_timestamp( $post->end_date ?? null, $post->end_time ?? null );
		$timezone   = $this->normalize_text( $post->timezone ?? null );
		$start_time = $this->resolve_boundary_time( $post->start_time ?? null, $start_date, $timezone );
		$end_time   = $this->resolve_boundary_time( $post->end_time ?? null, $end_date, $timezone );
		$visibility = $this->normalize_text( $post->visibility ?? null );
		$visibility = null !== $visibility ? $visibility : 'default';

		if ( null === $author ) {
			$user   = get_userdata( $author_id );
			$author = $user ? (string) $user->user_login : '';
		}

		return array(
			'id'                   => (int) $post->ID,
			'title'                => get_the_title( $post->ID ),
			'status'               => (string) $post->post_status,
			'linked_courses_count' => isset( $post->linked_courses_count ) ? (int) $post->linked_courses_count : 0,
			'visibility'           => $visibility,
			'start_date'           => $start_date,
			'end_date'             => $end_date,
			'start_time'           => $start_time,
			'end_time'             => $end_time,
			'timezone'             => $timezone,
			'meeting_date'         => $this->format_meeting_date( $start_date, $end_date, $start_time, $end_time, $timezone ),
			'meeting_url'          => isset( $post->meeting_url ) ? esc_url_raw( (string) $post->meeting_url ) : '',
			'meeting_host'         => is_string( $host_email ) ? sanitize_email( $host_email ) : '',
			'is_meet_started'      => function_exists( 'masterstudy_lms_is_google_meet_started' )
				? (bool) masterstudy_lms_is_google_meet_started( (int) $post->ID )
				: false,
			'author'               => array(
				'id'    => $author_id,
				'label' => $author,
			),
		);
	}

	private function normalize_timestamp( $value ): ?int {
		if ( empty( $value ) && '0' !== (string) $value ) {
			return null;
		}

		$timestamp = (int) $value;

		if ( $timestamp <= 0 ) {
			return null;
		}

		if ( $timestamp < 100000000000 ) {
			return $timestamp * 1000;
		}

		return $timestamp;
	}

	private function normalize_text( $value ): ?string {
		if ( null === $value ) {
			return null;
		}

		$value = trim( (string) $value );

		return '' === $value ? null : $value;
	}

	private function resolve_boundary_timestamp( $date_value, $time_value ): ?int {
		$timestamp = $this->normalize_timestamp( $date_value );

		if ( null !== $timestamp ) {
			return $timestamp;
		}

		if ( is_numeric( $time_value ) ) {
			return $this->normalize_timestamp( $time_value );
		}

		return null;
	}

	private function resolve_boundary_time( $time_value, ?int $timestamp, ?string $timezone ): ?string {
		$time = $this->normalize_text( $time_value );

		if ( null === $time ) {
			return null;
		}

		if ( ! is_numeric( $time ) ) {
			return $time;
		}

		if ( null === $timestamp ) {
			return null;
		}

		$time_format = get_option( 'time_format', 'H:i' );

		return wp_date( $time_format, (int) floor( $timestamp / 1000 ), $this->resolve_timezone( $timezone ) );
	}

	private function format_meeting_date( ?int $start_date, ?int $end_date, ?string $start_time, ?string $end_time, ?string $timezone ): ?array {
		if ( empty( $start_date ) ) {
			return null;
		}

		$start = $this->format_meeting_boundary( $start_date, $start_time );
		$end   = $this->format_meeting_boundary( $end_date, $end_time );

		return array(
			'start'    => $start,
			'end'      => $end,
			'timezone' => $timezone ?? '',
		);
	}

	private function format_meeting_boundary( ?int $date, ?string $time ): array {
		if ( empty( $date ) ) {
			return array(
				'date' => '',
				'time' => '',
			);
		}

		$datetime = gmdate( 'Y-m-d', (int) floor( $date / 1000 ) );
		$time     = $this->normalize_time_string( $time );

		if ( ! empty( $time ) ) {
			$datetime .= ' ' . $time;
		}

		$formatted = \STM_LMS_Helpers::format_date( $datetime );

		return array(
			'date' => $formatted['date'] ?? '',
			'time' => $formatted['time'] ?? '',
		);
	}

	private function normalize_time_string( ?string $time ): string {
		if ( empty( $time ) ) {
			return '';
		}

		$normalized = trim( $time );
		$parts      = explode( ':', $normalized );

		if ( 2 === count( $parts ) ) {
			return $normalized . ':00';
		}

		return $normalized;
	}
}
