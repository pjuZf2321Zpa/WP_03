<?php

namespace FluentCartPro\App\Modules\Reviews\Database\Migrations;

class ReviewInteractionsMigrator
{
    use DropTable;

    public static $tableName = 'fct_review_interactions';

    public static function migrate()
    {
        global $wpdb;

        $charsetCollate = $wpdb->get_charset_collate();
        $table = static::getTableName();
        $indexPrefix = $wpdb->prefix . 'fct_ri_';

        if ($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $table)) != $table) {
            $sql = "CREATE TABLE $table (
                `id` BIGINT UNSIGNED NOT NULL PRIMARY KEY AUTO_INCREMENT,
                `review_id` BIGINT(20) UNSIGNED NOT NULL,
                `user_id` BIGINT(20) UNSIGNED NOT NULL DEFAULT 0,
                `ip_address` VARCHAR(45) NOT NULL DEFAULT '',
                `type` VARCHAR(20) NOT NULL DEFAULT 'vote', -- vote | report
                `value` TINYINT(1) NULL, -- 1 = helpful and -1 = not helpful
                `note` TEXT NULL, -- report reason
                `created_at` TIMESTAMP NULL,
                 UNIQUE INDEX `{$indexPrefix}_review_user_type_idx` (`review_id`, `user_id`, `type`),
                 INDEX `{$indexPrefix}_review_type_idx` (`review_id` ASC, `type` ASC)
            ) $charsetCollate;";
            dbDelta($sql);
        }
    }
}
