<?php // phpcs:ignore WordPress.Files.FileName.InvalidClassFileName
/**
 * Social login email verification handlers.
 *
 * @package LoginPress Pro
 * @since 6.2.4
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'LoginPress_Social_Email_Verification' ) ) :

	/**
	 * Handles confirmed email verification for social providers.
	 *
	 * @since 6.2.4
	 */
	class LoginPress_Social_Email_Verification {

		/**
		 * Register hooks.
		 *
		 * @since 6.2.4
		 * @return void
		 */
		public static function loginpress_ev_init() {
			add_action( 'loginpress_ev_confirmed_social_link', array( __CLASS__, 'loginpress_ev_handle_social_link' ), 10, 1 );
			add_action( 'loginpress_ev_confirmed_social_register', array( __CLASS__, 'loginpress_ev_handle_social_register' ), 10, 1 );
		}

		/**
		 * Link a verified social account to an existing WordPress user.
		 *
		 * @since 6.2.4
		 * @param array $request Request data.
		 * @return void
		 */
		public static function loginpress_ev_handle_social_link( $request ) {

			if ( empty( $request['user_id'] ) || empty( $request['provider'] ) || empty( $request['payload'] ) ) {
				self::loginpress_ev_redirect_failed();
			}

			$user   = get_user_by( 'id', absint( $request['user_id'] ) );
			$result = self::loginpress_social_payload_to_result_object( $request['payload'], $request['provider'] );

			if ( ! $user || ! $result || sanitize_email( $user->user_email ) !== sanitize_email( $request['email'] ) ) {
				self::loginpress_ev_redirect_failed();
			}

			include_once LOGINPRESS_SOCIAL_DIR_PATH . 'classes/loginpress-utilities.php';

			global $wpdb;
			$sha_verifier = sha1( $result->deutype . $result->deuid );
			$existing     = $wpdb->get_var( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
				$wpdb->prepare(
					"SELECT id FROM `{$wpdb->prefix}loginpress_social_login_details` WHERE `provider_name` = %s AND `identifier` = %s AND `sha_verifier` = %s LIMIT 1",
					$result->deutype,
					$result->deuid,
					$sha_verifier
				)
			);

			if ( ! $existing ) {
				LoginPress_Social_Utilities::link_user(
					$user->ID,
					$result,
					array( 'email_verified' => '1' )
				);
			} else {
				$wpdb->update( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
					"{$wpdb->prefix}loginpress_social_login_details",
					array( 'email_verified' => '1' ),
					array( 'id' => absint( $existing ) ),
					array( '%s' ),
					array( '%d' )
				);
			}

			self::loginpress_ev_complete_login( $user, $request['provider'] );
		}

		/**
		 * Register and link a new user after email confirmation.
		 *
		 * @since 6.2.4
		 * @param array $request Request data.
		 * @return void
		 */
		public static function loginpress_ev_handle_social_register( $request ) {

			if ( empty( $request['provider'] ) || empty( $request['payload'] ) || empty( $request['email'] ) ) {
				self::loginpress_ev_redirect_failed();
			}

			$result = self::loginpress_social_payload_to_result_object( $request['payload'], $request['provider'] );

			if ( ! $result || email_exists( $request['email'] ) ) {
				self::loginpress_ev_redirect_failed();
			}

			include_once LOGINPRESS_SOCIAL_DIR_PATH . 'classes/loginpress-utilities.php';

			$utilities = new LoginPress_Social_Utilities();
			$role      = get_option( 'default_role' );
			$user_id   = $utilities->register_user( $result->username, $result->email );

			$user = ( $user_id && ! is_wp_error( $user_id ) ) ? get_user_by( 'id', $user_id ) : false;

			if ( ! $user ) {
				self::loginpress_ev_redirect_failed();
			}

			do_action( 'loginpress_social_login_registered', $user );

			LoginPress_Social_Utilities::update_usermeta(
				$user_id,
				$result,
				$role,
				array( 'email_verified' => '1' )
			);

			self::loginpress_ev_complete_login( $user, $request['provider'] );
		}

		/**
		 * Serialize a social result object for storage.
		 *
		 * @since 6.2.4
		 * @param object $result Social result object.
		 * @return array
		 */
		public static function loginpress_social_result_object_to_payload( $result ) {
			return array(
				'deuid'      => isset( $result->deuid ) ? sanitize_text_field( $result->deuid ) : '',
				'deutype'    => isset( $result->deutype ) ? sanitize_key( $result->deutype ) : '',
				'email'      => isset( $result->email ) ? sanitize_email( $result->email ) : '',
				'username'   => isset( $result->username ) ? sanitize_text_field( $result->username ) : '',
				'first_name' => isset( $result->first_name ) ? sanitize_text_field( $result->first_name ) : '',
				'last_name'  => isset( $result->last_name ) ? sanitize_text_field( $result->last_name ) : '',
				'deuimage'   => isset( $result->deuimage ) ? esc_url_raw( $result->deuimage ) : '',
				'url'        => isset( $result->url ) ? esc_url_raw( $result->url ) : '',
				'about'      => isset( $result->about ) ? sanitize_text_field( $result->about ) : '',
				'gender'     => isset( $result->gender ) ? sanitize_text_field( $result->gender ) : '',
			);
		}

		/**
		 * Rebuild a social result object from stored payload.
		 *
		 * @since 6.2.4
		 * @param array  $payload  Stored payload.
		 * @param string $provider Provider slug.
		 * @return object|false
		 */
		public static function loginpress_social_payload_to_result_object( $payload, $provider ) {
			if ( ! is_array( $payload ) || empty( $payload['deuid'] ) || empty( $payload['deutype'] ) ) {
				return false;
			}

			if ( sanitize_key( $provider ) !== sanitize_key( $payload['deutype'] ) ) {
				return false;
			}

			$result             = new stdClass();
			$result->deuid      = sanitize_text_field( $payload['deuid'] );
			$result->deutype    = sanitize_key( $payload['deutype'] );
			$result->email      = isset( $payload['email'] ) ? sanitize_email( $payload['email'] ) : '';
			$result->username   = isset( $payload['username'] ) ? sanitize_text_field( $payload['username'] ) : '';
			$result->first_name = isset( $payload['first_name'] ) ? sanitize_text_field( $payload['first_name'] ) : '';
			$result->last_name  = isset( $payload['last_name'] ) ? sanitize_text_field( $payload['last_name'] ) : '';
			$result->deuimage   = isset( $payload['deuimage'] ) ? esc_url_raw( $payload['deuimage'] ) : '';
			$result->url        = isset( $payload['url'] ) ? esc_url_raw( $payload['url'] ) : '';
			$result->about      = isset( $payload['about'] ) ? sanitize_text_field( $payload['about'] ) : '';
			$result->gender     = isset( $payload['gender'] ) ? sanitize_text_field( $payload['gender'] ) : '';

			return $result;
		}

		/**
		 * Log the user in and redirect with a success flag.
		 *
		 * @since 6.2.4
		 * @param WP_User $user     User object.
		 * @param string  $provider Provider slug.
		 * @return void
		 */
		private static function loginpress_ev_complete_login( $user, $provider ) {
			include_once LOGINPRESS_SOCIAL_DIR_PATH . 'classes/loginpress-utilities.php';

			$utilities = new LoginPress_Social_Utilities();
			$role      = get_option( 'default_role' );
			$channel   = 'success_' . sanitize_key( $provider );

			if ( 'subscriber' === $role ) {
				$utilities->_home_url( $user, $channel, 'subscriber' );
			}

			$utilities->_home_url( $user, $channel );
		}

		/**
		 * Redirect when verification cannot be completed.
		 *
		 * @since 6.2.4
		 * @return void
		 */
		private static function loginpress_ev_redirect_failed() {
			wp_safe_redirect(
				add_query_arg(
					array(
						'lp_social_error' => 'spotify_verify_expired',
					),
					wp_login_url()
				)
			);
			exit;
		}
	}

	LoginPress_Social_Email_Verification::loginpress_ev_init();

endif;
