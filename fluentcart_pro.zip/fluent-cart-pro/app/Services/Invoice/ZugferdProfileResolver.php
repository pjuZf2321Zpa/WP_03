<?php

declare(strict_types=1);

namespace FluentCartPro\App\Services\Invoice;

if (!defined('ABSPATH')) {
    exit;
}

use FluentCartPro\App\Services\Invoice\Profile\InvoiceProfileInterface;
use FluentCartPro\App\Services\Invoice\Profile\XRechnungProfile;
use FluentCartPro\App\Services\Invoice\Profile\ZugferdEn16931Profile;
use FluentCartPro\App\Services\Invoice\Profile\ZugferdExtendedProfile;

/**
 * Maps a string profile key (from seller_details.zugferd_profile) to an InvoiceProfileInterface instance.
 */
final class ZugferdProfileResolver
{
    /**
     * Resolve profile key to profile instance. Unknown or empty key returns EN 16931.
     *
     * @param string $key One of: en16931, xrechnung, zugferd_extended.
     */
    public function resolve(string $key): InvoiceProfileInterface
    {
        $key = trim($key);
        switch ($key) {
            case 'xrechnung':
                return new XRechnungProfile();
            case 'zugferd_extended':
                return new ZugferdExtendedProfile();
            case 'en16931':
            default:
                return new ZugferdEn16931Profile();
        }
    }
}
