<?php

/**
 * Magic Fix - Premium Feature
 *
 * Handles AI-powered automatic fixes for SEO issues
 */
class MeowPro_MWSEO_MagicFix
{
	private $core = null;

	function __construct( $core ) {
		$this->core = $core;
	}


	// Wrapper around $mwai->simpleTextQuery for all Magic Fix AI text calls.
	private function query( $prompt, $params = [] ) {
		global $mwai;

		if ( !$mwai ) {
			throw new Exception( 'AI Engine not available' );
		}

		$custom = trim( (string) $this->core->get_option( 'magic_fix_instructions', '' ) );
		if ( $custom !== '' ) {
			$prompt .= "\n\n<custom_instructions>" . $custom . "</custom_instructions>";
		}

		$params = array_merge( [ 'scope' => 'seo' ], $params );

		return $mwai->simpleTextQuery( $prompt, $params );
	}

	/**
	 * How long the rewritten post title may be, in display units.
	 *
	 * The title_length test scores the rendered SERP title, which is the post title
	 * plus " | Site Name" unless an SEO title override is set (see
	 * Meow_MWSEO_Core::build_title). Handing the AI the raw configured range would
	 * make it write to a budget the score then overshoots by the width of the suffix.
	 */
	private function title_length_budget( $post ) {
		$min = (int) $this->core->get_option( 'title_length_min', 30 );
		$max = (int) $this->core->get_option( 'title_length_max', 75 );

		// An override renders verbatim, so the whole range belongs to the title.
		if ( !empty( get_post_meta( $post->ID, $this->core->meta_key_seo_title, true ) ) ) {
			return [ $min, $max ];
		}

		$suffix = $this->core->get_display_width( ' | ' . trim( get_bloginfo( 'name' ) ) );

		// A site name long enough to eat the budget leaves a floor rather than a
		// negative range: the test can't pass on such a site either way.
		$max = max( 10, $max - $suffix );
		$min = max( 1, min( $min - $suffix, $max ) );

		return [ $min, $max ];
	}

	/**
	 * Generate AI solution for a specific issue
	 *
	 * IMPLEMENTATION STATUS:
	 *
	 * ✅ IMPLEMENTED (8 issues):
	 * - excerpt_exists: Missing excerpt → AI generates excerpt from content
	 * - excerpt_length: Excerpt not optimal length → AI rewrites to 80-160 chars
	 * - external_link_present: No external links → AI suggests Wikipedia links
	 * - title_length: Title not optimal length → AI rewrites to fit the configured range, minus the site-name suffix
	 * - alt_coverage: Images missing alternative text → AI generates ALT text for up to 5 images
	 * - grammar_typos: Grammar and typo issues → AI proofreads and corrects content
	 * - internal_links: Missing internal links → AI finds related posts and suggests link placements
	 * - featured_image: Missing featured image → AI generates an image based on post content
	 *
	 * ❌ NOT YET IMPLEMENTED (15 issues):
	 * - title_exists: Missing title → Would need to generate from content
	 * - title_unique_sitewide: Duplicate title → Would need to check uniqueness + generate variant
	 * - slug_structure: URL slug needs optimization → Would need to generate SEO-friendly slug
	 * - author_visible: Author not visible → Non-AI, settings change
	 * - content_depth: Insufficient content length → Would need AI to expand/suggest content
	 * - not_orphaned: Post not linked from other pages → Would need to update multiple posts
	 * - schema_integrity: Missing/incomplete schema → Would need structured data generation
	 * - semantic_alignment: Title doesn't match content → Would need AI analysis + rewrite
	 * - intent_fit: Content length doesn't match intent → Would need AI to expand/condense
	 * - authenticity_originality: Generic/unoriginal content → Would need AI rewriting
	 * - personality_engagement: Lacks personal voice → Would need AI tone adjustment
	 * - structure_quality: Poor content structure → Would need AI restructuring
	 * - readability_score: Poor readability → Would need AI simplification
	 * - topic_completeness: Doesn't cover all subtopics → Would need AI content expansion
	 * - meta_robots_tag: Blocking search engines → Non-AI, settings change
	 *
	 * @param object $post WordPress post object
	 * @param string $issue_type The issue test name (e.g., 'excerpt_exists', 'excerpt_length', 'external_link_present', 'grammar_typos', 'internal_links')
	 * @return array|false Solution data with 'solution' and 'metadata' keys, or false on failure
	 */
	public function generate_solution( $post, $issue_type ) {
		global $mwai;

		if ( !$post ) {
			$this->core->log( '⚠️ Magic Fix Generate: Post not found' );
			return false;
		}

		try {
			switch ( $issue_type ) {
				case 'excerpt_exists':
					// Missing excerpt - use existing Suggestions module
					$solution = Meow_MWSEO_Modules_Suggestions::prompt( $post, 'excerpt' );
					if ( !$solution ) {
						throw new Exception( 'Failed to generate excerpt' );
					}
					return [
						'solution' => $solution,
						'metadata' => [
							'type' => 'excerpt',
							'action' => 'set_excerpt'
						]
					];

				case 'excerpt_length':
					// Excerpt length not optimal - AI rewrite to 80-160 chars
					$current_excerpt = $post->post_excerpt;
					$content_sample = Meow_MWSEO_Modules_Suggestions::get_post_sample_context( $post );
					$language = $this->core->get_post_language_name( $post->ID );

					$prompt = sprintf(
						'Given the current excerpt: "%s" and content sample: "%s", rewrite it to be SEO-optimized and between 80-160 characters. Make it engaging and concise. Only return the new excerpt, nothing else.',
						$current_excerpt,
						$content_sample
					);
					$prompt = sprintf( '<instructions>Reply only with the rewritten excerpt in %s, no other text. %s</instructions> <prompt>%s</prompt>', $language, Meow_MWSEO_Modules_Suggestions::STYLE_RULE, $prompt );

					if ( !$mwai ) {
						throw new Exception( 'AI Engine not available' );
					}

					$solution = $this->query( $prompt );
					// Clean up the solution
					$solution = preg_replace('/.*\n/', '', $solution, 1);

					return [
						'solution' => trim( $solution ),
						'metadata' => [
							'type' => 'excerpt',
							'action' => 'set_excerpt'
						]
					];

				case 'external_link_present':
					// No external links - use existing suggestion logic
					$solution = Meow_MWSEO_Modules_Suggestions::prompt( $post, 'links_missing_external' );
					if ( !$solution ) {
						throw new Exception( 'Failed to generate external links' );
					}
					return [
						'solution' => $solution,
						'metadata' => [
							'type' => 'content_append',
							'action' => 'append_to_content'
						]
					];

				case 'title_length':
					// Title length not optimal - AI rewrite to fit the scored SERP title
					$current_title = $post->post_title;
					$content_sample = Meow_MWSEO_Modules_Suggestions::get_post_sample_context( $post );
					$language = $this->core->get_post_language_name( $post->ID );
					list( $min_length, $max_length ) = $this->title_length_budget( $post );

					$prompt = sprintf(
						'Given the current title: "%s" and content sample: "%s", rewrite the title to be SEO-optimized and between %d-%d characters. Make it engaging, concise, and clickable. Do not include the site name, it is appended automatically. Only return the new title, nothing else.',
						$current_title,
						$content_sample,
						$min_length,
						$max_length
					);
					$prompt = sprintf( '<instructions>Reply only with the rewritten title in %s, no other text. %s</instructions> <prompt>%s</prompt>', $language, Meow_MWSEO_Modules_Suggestions::STYLE_RULE, $prompt );

					if ( !$mwai ) {
						throw new Exception( 'AI Engine not available' );
					}

					$solution = $this->query( $prompt );
					// Clean up the solution
					$solution = preg_replace('/.*\n/', '', $solution, 1);
					$solution = trim( str_replace( '"', '', $solution ) );

					return [
						'solution' => $solution,
						'metadata' => [
							'type' => 'title',
							'action' => 'set_title',
							'length' => mb_strlen( $solution )
						]
					];

				case 'alt_coverage':
					// Some images missing alternative text
					// Get all images from post content
					$all_images = $this->core->get_images_from_content( $post->post_content );

					if ( empty( $all_images ) ) {
						throw new Exception( 'No images found in post content' );
					}

					// Filter to only images missing alt text
					$missing_images = array_filter( $all_images, function( $img ) {
						return empty( $img['alt'] ) || trim( $img['alt'] ) === '';
					});

					if ( empty( $missing_images ) ) {
						throw new Exception( 'No images found missing alternative text' );
					}

					// Limit to first 5 images to avoid overwhelming the UI
					$missing_images = array_slice( $missing_images, 0, 5 );

					$images_with_alt = [];
					$language = $this->core->get_post_language_name( $post->ID );
					$content_sample = Meow_MWSEO_Modules_Suggestions::get_post_sample_context( $post );

					foreach ( $missing_images as $image_data ) {
						$image_url = $image_data['src'];
						$attachment_id = attachment_url_to_postid( $image_url );

						// Get image filename for context
						$image_filename = basename( $image_url );
						$image_filename_clean = pathinfo( $image_filename, PATHINFO_FILENAME );
						// Clean up filename (remove dashes, underscores, numbers)
						$image_filename_clean = preg_replace( '/[-_\d]+/', ' ', $image_filename_clean );
						$image_filename_clean = trim( $image_filename_clean );

						// Get image title/caption if available (from attachment)
						$image_title = '';
						if ( $attachment_id > 0 ) {
							$attachment = get_post( $attachment_id );
							if ( $attachment ) {
								$image_title = $attachment->post_title;
								// Use excerpt (caption) if available
								if ( !empty( $attachment->post_excerpt ) ) {
									$image_title = $attachment->post_excerpt;
								}
							}
						}

						// Build contextual prompt
						$image_context_parts = [];
						if ( !empty( $image_title ) ) {
							$image_context_parts[] = "Image title/caption: $image_title";
						}
						if ( !empty( $image_filename_clean ) ) {
							$image_context_parts[] = "Filename hint: $image_filename_clean";
						}
						$image_context = !empty( $image_context_parts ) ? "\n" . implode( "\n", $image_context_parts ) : '';

						// Generate alt text using AI
						$prompt = sprintf(
							'Given this post information, create a simple, functional alternative text (ALT) for an image.

Post title: "%s"
Post content excerpt: "%s"%s

Create ALT text that:
- Is simple and direct (state what you see, no flowery language)
- Uses plain, functional descriptions (e.g., "wooden pavilion by water" not "tranquil waterfront pavilion")
- Is relevant to the post topic
- Is between 5-12 words
- Does NOT use adjectives like "beautiful", "stunning", "tranquil", "calm", "amazing"
- Does NOT start with "Image of" or "Picture of"
- Focuses on identifying the subject clearly and simply

Return ONLY the ALT text, nothing else.',
							$post->post_title,
							$content_sample,
							$image_context
						);
						$prompt = sprintf( '<instructions>Reply only with the descriptive alternative text in %s. No other text, no quotes, no explanations.</instructions> <prompt>%s</prompt>', $language, $prompt );

						if ( !$mwai ) {
							throw new Exception( 'AI Engine not available' );
						}

						$alt_text = $this->query( $prompt );
						$alt_text = preg_replace('/.*\n/', '', $alt_text, 1);
						$alt_text = trim( str_replace( '"', '', $alt_text ) );

						// Find the img tag in content to create search/replace pattern
						// We'll look for <img with this src and no alt (or empty alt)
						$search_pattern = preg_quote( $image_url, '/' );

						// Match img tag with this src that has no alt or empty alt
						preg_match( '/<img[^>]*src=["\']' . $search_pattern . '["\'][^>]*>/i', $post->post_content, $matches );

						if ( !empty( $matches[0] ) ) {
							$original_img_tag = $matches[0];

							// Create new img tag with alt attribute
							// If alt="" exists, replace it; otherwise add alt attribute
							if ( preg_match( '/alt=["\']["\']/', $original_img_tag ) || preg_match( '/alt=""/', $original_img_tag ) ) {
								// Replace empty alt
								$new_img_tag = preg_replace( '/alt=["\']["\']/', 'alt="' . esc_attr( $alt_text ) . '"', $original_img_tag );
								$new_img_tag = preg_replace( '/alt=""/', 'alt="' . esc_attr( $alt_text ) . '"', $new_img_tag );
							} else if ( !preg_match( '/alt=/', $original_img_tag ) ) {
								// No alt attribute at all - add it before the closing >
								$new_img_tag = preg_replace( '/>$/', ' alt="' . esc_attr( $alt_text ) . '">', $original_img_tag );
							} else {
								// Has alt with some value already - skip this one
								continue;
							}

							$images_with_alt[] = [
								'url' => $image_url,
								'alt_text' => $alt_text,
								'search' => $original_img_tag,
								'replace' => $new_img_tag
							];
						}
					}

					return [
						'solution' => json_encode( $images_with_alt ),
						'metadata' => [
							'type' => 'alt_text',
							'action' => 'update_html_alt',
							'count' => count( $images_with_alt ),
							'images' => $images_with_alt
						]
					];

				case 'internal_links':
					// Missing internal links - AI-powered link suggestions
					$language = $this->core->get_post_language_name( $post->ID );

					if ( !$mwai ) {
						throw new Exception( 'AI Engine not available' );
					}

					// Post language + its translations (Polylang, WPML or Bogo).
					$post_lang = $this->core->get_post_language_slug( $post->ID );
					$translation_ids = $this->core->get_post_translation_ids( $post->ID );
					if ( $post_lang ) { $this->core->log( "🌐 Post language detected: $post_lang" ); }

					// STEP 1: Extract keywords from current post
					$post_title = $post->post_title;
					$post_excerpt = $post->post_excerpt ?: wp_trim_words( strip_tags( $post->post_content ), 30 );

					$keywords_prompt = sprintf(
						'Extract 5-10 relevant keywords or key phrases from this content that could be used to find related articles. Return ONLY a JSON array of strings.

Title: %s
Excerpt: %s

Return format: ["keyword 1", "keyword 2", "keyword 3"]',
						$post_title,
						$post_excerpt
					);
					$keywords_prompt = sprintf( '<instructions>Reply ONLY with a valid JSON array of keyword strings in %s. No other text.</instructions> <prompt>%s</prompt>', $language, $keywords_prompt );

					$keywords_json = $this->query( $keywords_prompt );
					$keywords_json = trim( $keywords_json );
					$keywords_json = preg_replace( '/^```json\s*/m', '', $keywords_json );
					$keywords_json = preg_replace( '/^```\s*/m', '', $keywords_json );
					$keywords_json = trim( $keywords_json );

					$keywords = json_decode( $keywords_json, true );
					if ( !is_array( $keywords ) || empty( $keywords ) ) {
						$keywords = [ $post_title ]; // Fallback to title
					}

					$this->core->log( "🔍 Extracted keywords: " . implode( ', ', $keywords ) );

					// STEP 2: Build candidate list (20-50 posts/pages)
					$candidates = [];
					$current_post_id = $post->ID;

					// Posts to exclude: current post + all its translations
					$exclude_ids = array_merge( [ $current_post_id ], $translation_ids );
					$exclude_ids = array_unique( array_map( 'intval', $exclude_ids ) );

					// Link only to posts in the same language.
					$add_lang_filter = function( $args ) use ( $post_lang ) {
						return $this->core->apply_language_filter( $args, $post_lang );
					};

					// 2a. Same category (posts only)
					if ( $post->post_type === 'post' ) {
						$categories = wp_get_post_categories( $current_post_id );
						if ( !empty( $categories ) ) {
							$args = [
								'post_type' => 'post',
								'category__in' => $categories,
								'posts_per_page' => 20,
								'exclude' => $exclude_ids,
								'post_status' => 'publish'
							];
							$args = $add_lang_filter( $args );
							$cat_posts = get_posts( $args );
							$candidates = array_merge( $candidates, $cat_posts );
							$this->core->log( "📂 Found " . count( $cat_posts ) . " posts in same category" );
						}
					}

					// 2b. Same tags
					if ( count( $candidates ) < 50 ) {
						$tags = wp_get_post_tags( $current_post_id, [ 'fields' => 'ids' ] );
						if ( !empty( $tags ) ) {
							$current_exclude = array_merge( $exclude_ids, wp_list_pluck( $candidates, 'ID' ) );
							$args = [
								'post_type' => [ 'post', 'page' ],
								'tag__in' => $tags,
								'posts_per_page' => 15,
								'exclude' => $current_exclude,
								'post_status' => 'publish'
							];
							$args = $add_lang_filter( $args );
							$tag_posts = get_posts( $args );
							$candidates = array_merge( $candidates, $tag_posts );
							$this->core->log( "🏷️ Found " . count( $tag_posts ) . " posts with same tags" );
						}
					}

					// 2c. Keyword search (fill remaining)
					if ( count( $candidates ) < 50 ) {
						foreach ( $keywords as $keyword ) {
							$current_exclude = array_merge( $exclude_ids, wp_list_pluck( $candidates, 'ID' ) );
							$args = [
								'post_type' => [ 'post', 'page' ],
								's' => $keyword,
								'posts_per_page' => 10,
								'exclude' => $current_exclude,
								'post_status' => 'publish'
							];
							$args = $add_lang_filter( $args );
							$search_posts = get_posts( $args );
							$candidates = array_merge( $candidates, $search_posts );
							if ( count( $candidates ) >= 50 ) break;
						}
						$this->core->log( "🔎 Keyword search added more candidates" );
					}

					// Remove duplicates
					$candidates = array_unique( $candidates, SORT_REGULAR );
					$candidates = array_slice( $candidates, 0, 50 );

					if ( empty( $candidates ) ) {
						throw new Exception( 'No related posts found to link to.' );
					}

					$this->core->log( "✅ Total candidates: " . count( $candidates ) );

					// STEP 3: AI selects top 5 best matches
					$candidates_list = array_map( function( $p ) {
						return [
							'id' => $p->ID,
							'title' => $p->post_title,
							'excerpt' => wp_trim_words( strip_tags( $p->post_content ), 20 )
						];
					}, $candidates );

					$selection_prompt = sprintf(
						'From this list of posts, select the 5 most relevant posts that would be valuable to link FROM the current post. Return ONLY a JSON array of the post IDs.

Current Post:
Title: %s
Excerpt: %s

Available Posts:
%s

Return the 5 best matches as: [123, 456, 789, ...]',
						$post_title,
						$post_excerpt,
						json_encode( $candidates_list, JSON_PRETTY_PRINT )
					);
					$selection_prompt = sprintf( '<instructions>Reply ONLY with a JSON array of 5 post IDs in %s. No other text.</instructions> <prompt>%s</prompt>', $language, $selection_prompt );

					$selected_json = $this->query( $selection_prompt );
					$selected_json = trim( $selected_json );
					$selected_json = preg_replace( '/^```json\s*/m', '', $selected_json );
					$selected_json = preg_replace( '/^```\s*/m', '', $selected_json );
					$selected_json = trim( $selected_json );

					$selected_ids = json_decode( $selected_json, true );
					if ( !is_array( $selected_ids ) || empty( $selected_ids ) ) {
						// Fallback: just take first 5
						$selected_ids = array_slice( wp_list_pluck( $candidates, 'ID' ), 0, 5 );
					}
					$selected_ids = array_slice( $selected_ids, 0, 5 ); // Ensure max 5

					// Filter out current post if it somehow got included
					$selected_ids = array_filter( $selected_ids, function( $id ) use ( $current_post_id ) {
						return intval( $id ) !== intval( $current_post_id );
					});

					$this->core->log( "🎯 AI selected top 5: " . implode( ', ', $selected_ids ) );

					// STEP 4: For each selected post, AI suggests section-aware link placements
					$suggestions = [];
					$sections = $this->split_content_into_sections( $post->post_content );

					foreach ( $selected_ids as $target_id ) {
						$target_post = get_post( $target_id );
						if ( !$target_post || $target_post->ID === $current_post_id ) continue;

						$target_title = $target_post->post_title;
						$target_url = get_permalink( $target_post );

						// Build the section blocks for the prompt
						$section_blocks = '';
						foreach ( $sections as $section ) {
							$name = strtoupper( $section['name'] );
							$section_blocks .= sprintf(
								"\n--- %s ---\n%s\n",
								$name,
								$section['content']
							);
						}

						$section_instructions = '';
						foreach ( $sections as $section ) {
							$name = $section['name'];
							if ( $name === 'introduction' ) {
								$section_instructions .= '
INTRODUCTION — Weave the link naturally into the narrative flow:
- "Located just a few kilometers from [link], this place..."
- "After exploring [link], we headed to..."
- Connect geographically, thematically, or chronologically
- The "search" text MUST come from the INTRODUCTION section above
';
							} elseif ( $name === 'content' ) {
								$section_instructions .= '
CONTENT — Find contextual relevance within the body:
- Link an existing word or phrase that relates to the target
- "Similarly to [link] in the neighboring prefecture..."
- "I had visited [link] the day before"
- Must be a genuine topical fit
- The "search" text MUST come from the CONTENT section above
';
							} elseif ( $name === 'conclusion' ) {
								$section_instructions .= '
CONCLUSION — Recommend as related content:
- "If you enjoyed this, you might also like [link]"
- "[link] is not far from here and also worth visiting"
- "For a similar experience, check out [link]"
- The "search" text MUST come from the CONCLUSION section above
';
							}
						}

						$placement_prompt = sprintf(
							'Suggest up to %d link placement(s) for the TARGET post — one per section below. Skip any section where the link doesn\'t fit naturally.

CURRENT POST sections (where we will add the link):
%s

TARGET POST to link to:
Title: %s
URL: %s

SECTION GUIDELINES:
%s

RULES:
- If TARGET post is completely unrelated to CURRENT post, return []
- Each suggestion\'s "search" text must come from its own section only
- Include a "section" field with value "introduction", "content", or "conclusion"
- You can link existing text (best), add a short parenthetical, or add a new sentence
- Keep additions natural — match the author\'s writing style and tone

Return format: [{"search": "...", "replace": "...", "reason": "...", "section": "introduction|content|conclusion"}] OR [] if unrelated',
							count( $sections ),
							$section_blocks,
							$target_title,
							$target_url,
							$section_instructions
						);
						$placement_prompt = sprintf( '<instructions>Reply ONLY with a JSON array in %s. No other text. Each suggestion must include search, replace, reason, and section.</instructions> <prompt>%s</prompt>', $language, $placement_prompt );

						$placements_json = $this->query( $placement_prompt );
						$placements_json = trim( $placements_json );
						$placements_json = preg_replace( '/^```json\s*/m', '', $placements_json );
						$placements_json = preg_replace( '/^```\s*/m', '', $placements_json );
						$placements_json = trim( $placements_json );

						$placements = json_decode( $placements_json, true );
						if ( is_array( $placements ) && !empty( $placements ) ) {
							$suggestions[] = [
								'post_id' => $target_id,
								'post_title' => $target_title,
								'post_url' => $target_url,
								'options' => array_slice( $placements, 0, 3 )
							];
							$this->core->log( "✅ Generated " . count( $placements ) . " section options for: $target_title" );
						} else {
							$this->core->log( "⏭️ Skipped $target_title - no natural placement found" );
						}
					}

					// If no suggestions found, provide helpful message
					if ( empty( $suggestions ) ) {
						$this->core->log( "⚠️ No natural link placements found for any of the 5 selected posts" );
						throw new Exception( 'No natural link placements found. The selected posts don\'t have obvious connections to this content. Try running Magic Fix again to get different suggestions, or manually add links where appropriate.' );
					}

					return [
						'solution' => json_encode( $suggestions ),
						'metadata' => [
							'type' => 'internal_links',
							'action' => 'add_internal_links',
							'count' => count( $suggestions )
						]
					];

				case 'grammar_typos':
					// Grammar and typo issues - AI identifies specific corrections as search/replace pairs
					$current_content = $post->post_content;
					$language = $this->core->get_post_language_name( $post->ID );

					if ( empty( trim( strip_tags( $current_content ) ) ) ) {
						throw new Exception( 'Post content is empty' );
					}

					// Use actual HTML content (not plain text) so AI can match with HTML tags intact
					$content_to_analyze = substr( $current_content, 0, 3000 ); // Limit to first 3000 chars

					// Build prompt to get specific corrections as search/replace pairs
					$prompt = sprintf(
						'Analyze the following HTML content for grammar errors, typos, and spelling mistakes. Return ONLY a JSON array of corrections in this exact format: [{"search": "incorrect phrase", "replace": "correct phrase"}].

IMPORTANT RULES:
- Only include the 5-10 most important errors
- Each "search" value MUST include 3-5 words of context around the error (before and after the mistake)
- The "search" text must be EXACTLY as it appears in the content, INCLUDING any HTML tags (e.g., <strong>, <em>, etc.)
- Include enough surrounding words to make the match unique
- The "replace" value should have the same HTML structure, just with the error corrected
- Do not include explanations or any other text

Examples:
- {"search":"I saw <strong>teh</strong> cat yesterday","replace":"I saw <strong>the</strong> cat yesterday"}
- {"search":"This is beatiful and amazing","replace":"This is beautiful and amazing"}
- {"search":"we can recieve your message","replace":"we can receive your message"}

Content to analyze:
%s',
						$content_to_analyze
					);
					$prompt = sprintf( '<instructions>Reply ONLY with a valid JSON array in %s. No other text. Format: [{"search": "exact phrase with HTML", "replace": "corrected phrase with HTML"}]. Each search must include 3-5 words of context and preserve HTML tags exactly.</instructions> <prompt>%s</prompt>', $language, $prompt );

					if ( !$mwai ) {
						throw new Exception( 'AI Engine not available' );
					}

					$solution = $this->query( $prompt );

					// Extract JSON from response (AI might wrap it in markdown code blocks)
					$solution = trim( $solution );
					$solution = preg_replace( '/^```json\s*/m', '', $solution );
					$solution = preg_replace( '/^```\s*/m', '', $solution );
					$solution = trim( $solution );

					// Validate JSON
					$corrections = json_decode( $solution, true );
					if ( !is_array( $corrections ) || empty( $corrections ) ) {
						throw new Exception( 'AI returned invalid corrections format. Expected JSON array.' );
					}

					// Validate each correction has search and replace keys
					foreach ( $corrections as $correction ) {
						if ( !isset( $correction['search'] ) || !isset( $correction['replace'] ) ) {
							throw new Exception( 'Invalid correction format. Each item must have "search" and "replace" keys.' );
						}
					}

					return [
						'solution' => json_encode( $corrections ),
						'metadata' => [
							'type' => 'grammar_corrections',
							'action' => 'search_replace',
							'count' => count( $corrections ),
							'corrections' => $corrections
						]
					];

				case 'featured_image':
					// Missing featured image - AI generates an image based on post content
					$post_title = $post->post_title;
					$post_excerpt = $post->post_excerpt ?: wp_trim_words( strip_tags( $post->post_content ), 30 );
					$language = $this->core->get_post_language_name( $post->ID );

					// Build a descriptive prompt for image generation
					$image_prompt = sprintf(
						'Create a professional featured image for a blog post titled "%s". The post is about: %s. The image should be visually appealing, relevant to the topic, and suitable as a blog header image.',
						$post_title,
						$post_excerpt
					);

					if ( !$mwai ) {
						throw new Exception( 'AI Engine not available' );
					}

					// Generate image using simpleImageQuery with scope='seo'
					$image_url = $mwai->simpleImageQuery( $image_prompt, [ 'scope' => 'seo' ] );

					if ( empty( $image_url ) ) {
						throw new Exception( 'Failed to generate image' );
					}

					return [
						'solution' => $image_url,
						'metadata' => [
							'type' => 'featured_image',
							'action' => 'set_featured_image',
							'image_url' => $image_url
						]
					];

			default:
				// Check if this is a known issue type that's not implemented yet
				$known_but_not_implemented = [
					'title_exists',
					'title_unique_sitewide',
					'slug_structure',
					'internal_links',
					'author_visible',
					'content_depth',
					'not_orphaned',
					'schema_integrity',
					'semantic_alignment',
					'intent_fit',
					'authenticity_originality',
					'personality_engagement',
					'structure_quality',
					'readability_score',
					'topic_completeness',
					'meta_robots_tag',
					'js_rendered_content'
				];

				if ( in_array( $issue_type, $known_but_not_implemented ) ) {
					$this->core->log( "⚠️ Magic Fix Generate: Issue type '$issue_type' is not implemented yet" );
					throw new Exception( "Magic Fix for '$issue_type' is not implemented yet. Only excerpt, title length, external links, alternative text, grammar/typos, internal links, and featured image fixes are currently available." );
				}

				$this->core->log( "⚠️ Magic Fix Generate: Unknown issue type: $issue_type" );
				return false;
		}
		} catch ( Exception $e ) {
			$this->core->log( '❌ Magic Fix Generate Error: ' . $e->getMessage() );
			return false;
		}
	}

	/**
	 * Apply a generated solution to a post
	 *
	 * @param object $post WordPress post object
	 * @param string $issue_type The issue test name
	 * @param array $solution Solution data with 'value' and 'metadata' keys
	 * @return array|false Result data, or false on failure
	 */
	public function apply_solution( $post, $issue_type, $solution ) {
		if ( !$post || !$solution || !isset( $solution['value'] ) ) {
			$this->core->log( '⚠️ Magic Fix Apply: Invalid parameters' );
			return false;
		}

		try {
			$solution_value = $solution['value'];
			$metadata = $solution['metadata'] ?? [];

			switch ( $issue_type ) {
				case 'excerpt_exists':
				case 'excerpt_length':
					// Update post excerpt
					$result = wp_update_post([
						'ID' => $post->ID,
						'post_excerpt' => $solution_value
					], true);

					if ( is_wp_error( $result ) ) {
						throw new Exception( 'Failed to update excerpt: ' . $result->get_error_message() );
					}

					// Mark issue as fixed (pending re-analysis)
					$this->mark_as_fixed( $post->ID, $issue_type );

					$this->core->log( "✅ Magic Fix: Updated excerpt for post {$post->ID}" );
					return [
						'success' => true,
						'action' => 'excerpt_updated'
					];

				case 'external_link_present':
					// Parse links and do search/replace in content
					$current_content = $post->post_content;
					$new_content = $current_content;

					// Parse the HTML to extract individual links
					$dom = new DOMDocument();
					libxml_use_internal_errors( true );
					$dom->loadHTML( '<?xml encoding="UTF-8">' . $solution_value, LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD );
					libxml_clear_errors();

					$links = $dom->getElementsByTagName( 'a' );
					$replacements_made = 0;

					foreach ( $links as $link ) {
						$phrase = $link->textContent;
						$url = $link->getAttribute( 'href' );
						$link_html = '<a href="' . esc_url( $url ) . '" target="_blank">' . $phrase . '</a>';

						// First occurrence only, never inside an existing link or a tag's attributes
						$replaced = $this->replace_outside_comments(
							'/' . preg_quote( $phrase, '/' ) . '(?![^<]*<\/a>)(?![^<]*>)/',
							$link_html,
							$new_content
						);
						if ( $replaced !== null ) {
							$new_content = $replaced;
							$replacements_made++;
						}
					}

					if ( $replacements_made === 0 ) {
						throw new Exception( 'No phrases from the suggestions were found in the content.' );
					}

					$result = wp_update_post([
						'ID' => $post->ID,
						'post_content' => wp_slash( $new_content ) // wp_update_post() unslashes; raw content would lose its backslashes (and break builder JSON).
					], true);

					if ( is_wp_error( $result ) ) {
						throw new Exception( 'Failed to update content: ' . $result->get_error_message() );
					}

					// Mark issue as fixed (pending re-analysis)
					$this->mark_as_fixed( $post->ID, $issue_type );

					$this->core->log( "✅ Magic Fix: Added $replacements_made external link(s) to post {$post->ID}" );
					return [
						'success' => true,
						'action' => 'content_updated',
						'replacements' => $replacements_made
					];

				case 'title_length':
					// Update post title
					$result = wp_update_post([
						'ID' => $post->ID,
						'post_title' => $solution_value
					], true);

					if ( is_wp_error( $result ) ) {
						throw new Exception( 'Failed to update title: ' . $result->get_error_message() );
					}

					// Mark issue as fixed (pending re-analysis)
					$this->mark_as_fixed( $post->ID, $issue_type );

					$this->core->log( "✅ Magic Fix: Updated title for post {$post->ID}" );
					return [
						'success' => true,
						'action' => 'title_updated',
						'new_length' => mb_strlen( $solution_value )
					];

				case 'alt_coverage':
					// Update alternative text for images in HTML content
					$images_data = json_decode( $solution_value, true );

					if ( !is_array( $images_data ) || empty( $images_data ) ) {
						throw new Exception( 'Invalid images data format' );
					}

					$current_content = $post->post_content;
					$new_content = $current_content;
					$replacements_made = 0;

					// Apply each ALT text update
					foreach ( $images_data as $image ) {
						$search = $image['search'] ?? '';
						$replace = $image['replace'] ?? '';

						if ( empty( $search ) ) {
							continue;
						}

						// Replace only the first occurrence of the exact img tag
						$replaced = $this->replace_outside_comments( '/' . preg_quote( $search, '/' ) . '/', $replace, $new_content );
						if ( $replaced !== null ) {
							$new_content = $replaced;
							$replacements_made++;

							$alt_text = $image['alt_text'] ?? '';
							$url = basename( $image['url'] ?? 'unknown' );
							$this->core->log( "✅ Added ALT to image $url: '$alt_text'" );
						}
					}

					if ( $replacements_made === 0 ) {
						throw new Exception( 'No image tags were found in the content to update.' );
					}

					// Update post content
					$result = wp_update_post([
						'ID' => $post->ID,
						'post_content' => wp_slash( $new_content )
					], true);

					if ( is_wp_error( $result ) ) {
						throw new Exception( 'Failed to update content: ' . $result->get_error_message() );
					}

					// Mark issue as fixed (pending re-analysis)
					$this->mark_as_fixed( $post->ID, $issue_type );

					$this->core->log( "✅ Magic Fix: Updated alternative text for $replacements_made image(s) in post {$post->ID}" );
					return [
						'success' => true,
						'action' => 'content_updated',
						'replacements' => $replacements_made
					];

				case 'internal_links':
					// Apply internal link suggestions
					$this->core->log( "🔍 Internal Links Magic Fix - Received solution data" );
					$this->core->log( "📦 Solution value length: " . strlen( $solution_value ) );

					$suggestions = json_decode( $solution_value, true );

					if ( !is_array( $suggestions ) || empty( $suggestions ) ) {
						throw new Exception( 'Invalid suggestions data format' );
					}

					$current_content = $post->post_content;
					$new_content = $current_content;
					$replacements_made = 0;
					$skipped_snippets = [];
					$debug_info = [];

					$this->core->log( "🔍 Processing " . count( $suggestions ) . " internal link suggestions" );

					// Apply each selected suggestion
					foreach ( $suggestions as $idx => $suggestion ) {
						$post_title = $suggestion['post_title'] ?? 'Unknown Post';

						if ( !isset( $suggestion['selected_option'] ) || $suggestion['selected_option'] === null ) {
							$this->core->log( "⏭️ Suggestion #$idx ($post_title): No option selected" );
							$debug_info[] = "Suggestion #$idx ($post_title): No option selected";
							continue; // User didn't select an option for this post
						}

						$selected_index = $suggestion['selected_option'];
						$options = $suggestion['options'] ?? [];

						$this->core->log( "📝 Suggestion #$idx ($post_title): Selected option index $selected_index, has " . count( $options ) . " options available" );

						if ( !isset( $options[$selected_index] ) ) {
							$this->core->log( "⚠️ Suggestion #$idx ($post_title): Option index $selected_index not found in options array" );
							$debug_info[] = "Suggestion #$idx ($post_title): Option $selected_index doesn't exist (only has " . count( $options ) . " options)";
							continue;
						}

						$option = $options[$selected_index];
						$search = $option['search'] ?? '';
						$replace = $option['replace'] ?? '';

						if ( empty( $search ) ) {
							continue;
						}

						$matched = false;
						$search_pattern = $search;

						// Try multiple matching strategies
						// Strategy 1: Exact match
						if ( strpos( $new_content, $search ) !== false ) {
							$matched = true;
						}
						// Strategy 2: Try with normalized whitespace
						else {
							$search_normalized = preg_replace( '/\s+/', ' ', $search );
							$content_normalized = preg_replace( '/\s+/', ' ', $new_content );
							if ( strpos( $content_normalized, $search_normalized ) !== false ) {
								// Find and use the actual text from content for replacement
								$pattern = '/(' . preg_replace( '/\s+/', '\s+', preg_quote( $search_normalized, '/' ) ) . ')/';
								if ( preg_match( $pattern, $new_content, $matches ) ) {
									$search_pattern = $matches[0];
									$matched = true;
								}
							}
						}

						// Replace only the first occurrence
						$replaced = $matched ? $this->replace_outside_comments( '/' . preg_quote( $search_pattern, '/' ) . '/', $replace, $new_content ) : null;
						if ( $replaced !== null ) {
							$new_content = $replaced;
							$replacements_made++;

							$search_display = wp_strip_all_tags( $search );
							$replace_display = wp_strip_all_tags( $replace );
							$post_title = $suggestion['post_title'] ?? 'Unknown Post';
							$this->core->log( "✅ Added link to '$post_title': '$search_display' → '$replace_display'" );
						} else {
							$search_display = wp_strip_all_tags( $search );
							$skipped_snippets[] = $search_display;
							$this->core->log( "⚠️ Skipped: '$search_display' not found in content (tried exact + normalized whitespace)" );
						}
					}

					if ( $replacements_made === 0 ) {
						if ( !empty( $debug_info ) ) {
							// Suggestions were skipped before matching
							$debug_preview = implode( '; ', array_slice( $debug_info, 0, 3 ) );
							throw new Exception( 'No link placements could be applied. Debug info: ' . $debug_preview . '. Please try regenerating the suggestions.' );
						} else {
							// Suggestions were processed but not found
							$snippets_preview = implode( '", "', array_slice( $skipped_snippets, 0, 3 ) );
							throw new Exception( 'None of the selected link placements were found in the content. Snippets searched: "' . $snippets_preview . '". This may happen if the post content changed after suggestions were generated, or if there are HTML/whitespace differences.' );
						}
					}

					// Update post content
					$result = wp_update_post([
						'ID' => $post->ID,
						'post_content' => wp_slash( $new_content )
					], true);

					if ( is_wp_error( $result ) ) {
						throw new Exception( 'Failed to update content: ' . $result->get_error_message() );
					}

					// Mark issue as fixed (pending re-analysis)
					$this->mark_as_fixed( $post->ID, $issue_type );

					$this->core->log( "✅ Magic Fix: Added $replacements_made internal link(s) to post {$post->ID}" );
					return [
						'success' => true,
						'action' => 'content_updated',
						'replacements' => $replacements_made
					];

				case 'grammar_typos':
					// Apply grammar/typo corrections via search/replace
					$corrections = json_decode( $solution_value, true );

					if ( !is_array( $corrections ) || empty( $corrections ) ) {
						throw new Exception( 'Invalid corrections data format' );
					}

					$current_content = $post->post_content;
					$new_content = $current_content;
					$replacements_made = 0;

					// Apply each correction
					foreach ( $corrections as $correction ) {
						$search = $correction['search'] ?? '';
						$replace = $correction['replace'] ?? '';

						if ( empty( $search ) ) {
							continue;
						}

						// Replace only the first occurrence (context makes it unique)
						$replaced = $this->replace_outside_comments( '/' . preg_quote( $search, '/' ) . '/', $replace, $new_content );
						if ( $replaced !== null ) {
							$new_content = $replaced;
							$replacements_made++;

							// Log with HTML stripped for readability
							$search_display = wp_strip_all_tags( $search );
							$replace_display = wp_strip_all_tags( $replace );
							$this->core->log( "✅ Corrected: '$search_display' → '$replace_display'" );
						} else {
							$search_display = wp_strip_all_tags( $search );
							$this->core->log( "⚠️ Skipped: '$search_display' not found in content" );
						}
					}

					if ( $replacements_made === 0 ) {
						throw new Exception( 'None of the suggested corrections were found in the content.' );
					}

					// Update post content
					$result = wp_update_post([
						'ID' => $post->ID,
						'post_content' => wp_slash( $new_content )
					], true);

					if ( is_wp_error( $result ) ) {
						throw new Exception( 'Failed to update content: ' . $result->get_error_message() );
					}

					// Mark issue as fixed (pending re-analysis)
					$this->mark_as_fixed( $post->ID, $issue_type );

					$this->core->log( "✅ Magic Fix: Applied $replacements_made grammar/typo correction(s) to post {$post->ID}" );
					return [
						'success' => true,
						'action' => 'content_updated',
						'replacements' => $replacements_made,
						'total_suggestions' => count( $corrections )
					];

				case 'featured_image':
					// Set featured image from generated image URL
					$image_url = $solution_value;

					if ( empty( $image_url ) ) {
						throw new Exception( 'No image URL provided' );
					}

					// Download image to media library
					require_once( ABSPATH . 'wp-admin/includes/media.php' );
					require_once( ABSPATH . 'wp-admin/includes/file.php' );
					require_once( ABSPATH . 'wp-admin/includes/image.php' );

					// Upload image to WordPress
					$attachment_id = media_sideload_image( $image_url, $post->ID, $post->post_title, 'id' );

					if ( is_wp_error( $attachment_id ) ) {
						throw new Exception( 'Failed to upload image: ' . $attachment_id->get_error_message() );
					}

					// Update attachment metadata with post title, alt text, and description
					$attachment_data = [
						'ID' => $attachment_id,
						'post_title' => $post->post_title,  // Use post title as image title
						'post_content' => $post->post_excerpt ?: wp_trim_words( strip_tags( $post->post_content ), 30 )  // Use excerpt as description
					];
					wp_update_post( $attachment_data );

					// Set alt text using post title
					update_post_meta( $attachment_id, '_wp_attachment_image_alt', $post->post_title );

					// Set as featured image
					$result = set_post_thumbnail( $post->ID, $attachment_id );

					if ( !$result ) {
						throw new Exception( 'Failed to set featured image' );
					}

					// Mark issue as fixed (pending re-analysis)
					$this->mark_as_fixed( $post->ID, $issue_type );

					$this->core->log( "✅ Magic Fix: Set featured image (attachment ID: $attachment_id) for post {$post->ID}" );
					return [
						'success' => true,
						'action' => 'featured_image_set',
						'attachment_id' => $attachment_id
					];

				default:
					// Check if this is a known issue type that's not implemented yet
					$known_but_not_implemented = [
						'title_exists',
						'title_unique_sitewide',
						'slug_structure',
						'author_visible',
						'content_depth',
						'not_orphaned',
						'schema_integrity',
						'semantic_alignment',
						'intent_fit',
						'authenticity_originality',
						'personality_engagement',
						'structure_quality',
						'readability_score',
						'topic_completeness',
						'meta_robots_tag',
						'js_rendered_content'
				];
				if ( in_array( $issue_type, $known_but_not_implemented ) ) {
					$this->core->log( "⚠️ Magic Fix Apply: Issue type '$issue_type' is not implemented yet" );
					throw new Exception( "Magic Fix for '$issue_type' is not implemented yet. Only excerpt, title length, external links, alternative text, grammar/typos, internal links, and featured image fixes are currently available." );
				}

				$this->core->log( "⚠️ Magic Fix Apply: Unknown issue type: $issue_type" );
				return false;

			}
		} catch ( Exception $e ) {
			$this->core->log( '❌ Magic Fix Apply Error: ' . $e->getMessage() );
			// Return error info instead of just false so the message reaches the frontend
			return [
				'success' => false,
				'error' => $e->getMessage()
			];
		}
	}

	/**
	 * Mark an issue as fixed by Magic Fix (pending re-analysis)
	 *
	 * @param int $post_id Post ID
	 * @param string $issue_type Issue test name
	 */
	public function mark_as_fixed( $post_id, $issue_type ) {
		$fixed_issues = get_post_meta( $post_id, '_mwseo_issues_fixed', true );
		if ( !is_array( $fixed_issues ) ) {
			$fixed_issues = [];
		}
		if ( !in_array( $issue_type, $fixed_issues ) ) {
			$fixed_issues[] = $issue_type;
			update_post_meta( $post_id, '_mwseo_issues_fixed', $fixed_issues );
		}
	}

	/**
	 * Check if an issue has been marked as fixed by Magic Fix
	 *
	 * @param int $post_id Post ID
	 * @param string $issue_type Issue test name
	 * @return bool True if marked as fixed
	 */
	public function is_fixed( $post_id, $issue_type ) {
		$fixed_issues = get_post_meta( $post_id, '_mwseo_issues_fixed', true );
		if ( !is_array( $fixed_issues ) ) {
			return false;
		}
		return in_array( $issue_type, $fixed_issues );
	}

	/**
	 * Clear all magic fix markers for a post (called when re-analyzing)
	 *
	 * @param int $post_id Post ID
	 */
	public function clear_markers( $post_id ) {
		delete_post_meta( $post_id, '_mwseo_issues_fixed' );
	}

	/**
	 * Internal Links Step 1: Extract keywords from current post
	 */
	public function internal_links_step1( $post ) {
		global $mwai;

		if ( !$mwai ) {
			throw new Exception( 'AI Engine not available' );
		}

		$language = $this->core->get_post_language_name( $post->ID );
		$post_title = $post->post_title;
		$post_excerpt = $post->post_excerpt ?: wp_trim_words( strip_tags( $post->post_content ), 30 );

		$keywords_prompt = sprintf(
			'Extract 5-10 relevant keywords or key phrases from this content that could be used to find related articles. Return ONLY a JSON array of strings.

Title: %s
Excerpt: %s

Return format: ["keyword 1", "keyword 2", "keyword 3"]',
			$post_title,
			$post_excerpt
		);
		$keywords_prompt = sprintf( '<instructions>Reply ONLY with a valid JSON array of keyword strings in %s. No other text.</instructions> <prompt>%s</prompt>', $language, $keywords_prompt );

		$keywords_json = $this->query( $keywords_prompt );
		$keywords_json = trim( $keywords_json );
		$keywords_json = preg_replace( '/^```json\s*/m', '', $keywords_json );
		$keywords_json = preg_replace( '/^```\s*/m', '', $keywords_json );
		$keywords_json = trim( $keywords_json );

		$keywords = json_decode( $keywords_json, true );
		if ( !is_array( $keywords ) || empty( $keywords ) ) {
			$keywords = [ $post_title ]; // Fallback to title
		}

		$this->core->log( "🔍 Extracted keywords: " . implode( ', ', $keywords ) );

		return $keywords;
	}

	/**
	 * Internal Links Step 2: Build candidate list based on language/translation support
	 */
	public function internal_links_step2( $post, $keywords ) {
		$current_post_id = $post->ID;

		// Post language + its translations (Polylang, WPML or Bogo).
		$post_lang = $this->core->get_post_language_slug( $post->ID );
		$translation_ids = $this->core->get_post_translation_ids( $post->ID );
		if ( $post_lang ) { $this->core->log( "🌐 Post language detected: $post_lang" ); }

		// Posts to exclude: current post + all its translations
		$exclude_ids = array_merge( [ $current_post_id ], $translation_ids );
		$exclude_ids = array_unique( array_map( 'intval', $exclude_ids ) );

		// Link only to posts in the same language.
		$add_lang_filter = function( $args ) use ( $post_lang ) {
			return $this->core->apply_language_filter( $args, $post_lang );
		};

		$candidates = [];

		// 2a. Same category (posts only)
		if ( $post->post_type === 'post' ) {
			$categories = wp_get_post_categories( $current_post_id );
			if ( !empty( $categories ) ) {
				$args = [
					'post_type' => 'post',
					'category__in' => $categories,
					'posts_per_page' => 20,
					'exclude' => $exclude_ids,
					'post_status' => 'publish'
				];
				$args = $add_lang_filter( $args );
				$cat_posts = get_posts( $args );
				$candidates = array_merge( $candidates, $cat_posts );
				$this->core->log( "📂 Found " . count( $cat_posts ) . " posts in same category" );
			}
		}

		// 2b. Same tags
		if ( count( $candidates ) < 50 ) {
			$tags = wp_get_post_tags( $current_post_id, [ 'fields' => 'ids' ] );
			if ( !empty( $tags ) ) {
				$current_exclude = array_merge( $exclude_ids, wp_list_pluck( $candidates, 'ID' ) );
				$args = [
					'post_type' => [ 'post', 'page' ],
					'tag__in' => $tags,
					'posts_per_page' => 15,
					'exclude' => $current_exclude,
					'post_status' => 'publish'
				];
				$args = $add_lang_filter( $args );
				$tag_posts = get_posts( $args );
				$candidates = array_merge( $candidates, $tag_posts );
				$this->core->log( "🏷️ Found " . count( $tag_posts ) . " posts with same tags" );
			}
		}

		// 2c. Keyword search (fill remaining)
		if ( count( $candidates ) < 50 ) {
			foreach ( $keywords as $keyword ) {
				$current_exclude = array_merge( $exclude_ids, wp_list_pluck( $candidates, 'ID' ) );
				$args = [
					'post_type' => [ 'post', 'page' ],
					's' => $keyword,
					'posts_per_page' => 10,
					'exclude' => $current_exclude,
					'post_status' => 'publish'
				];
				$args = $add_lang_filter( $args );
				$search_posts = get_posts( $args );
				$candidates = array_merge( $candidates, $search_posts );
				if ( count( $candidates ) >= 50 ) break;
			}
			$this->core->log( "🔎 Keyword search added more candidates" );
		}

		// Remove duplicates
		$candidates = array_unique( $candidates, SORT_REGULAR );
		$candidates = array_slice( $candidates, 0, 50 );

		if ( empty( $candidates ) ) {
			throw new Exception( 'No related posts found to link to.' );
		}

		$this->core->log( "✅ Total candidates: " . count( $candidates ) );

		// Return candidate list with titles and excerpts
		return array_map( function( $p ) {
			return [
				'id' => $p->ID,
				'title' => $p->post_title,
				'excerpt' => wp_trim_words( strip_tags( $p->post_content ), 20 )
			];
		}, $candidates );
	}

	/**
	 * Internal Links Step 3: AI selects top 10 most relevant posts
	 */
	public function internal_links_step3( $post, $candidates_list ) {
		global $mwai;

		if ( !$mwai ) {
			throw new Exception( 'AI Engine not available' );
		}

		$language = $this->core->get_post_language_name( $post->ID );
		$post_title = $post->post_title;
		$post_excerpt = $post->post_excerpt ?: wp_trim_words( strip_tags( $post->post_content ), 30 );

		$selection_prompt = sprintf(
			'From this list of posts, select the 10 most relevant posts that would be valuable to link FROM the current post. Return ONLY a JSON array of the post IDs.

Current Post:
Title: %s
Excerpt: %s

Available Posts:
%s

Return the 10 best matches as: [123, 456, 789, ...]',
			$post_title,
			$post_excerpt,
			json_encode( $candidates_list, JSON_PRETTY_PRINT )
		);
		$selection_prompt = sprintf( '<instructions>Reply ONLY with a JSON array of 10 post IDs in %s. No other text.</instructions> <prompt>%s</prompt>', $language, $selection_prompt );

		$selected_json = $this->query( $selection_prompt );
		$selected_json = trim( $selected_json );
		$selected_json = preg_replace( '/^```json\s*/m', '', $selected_json );
		$selected_json = preg_replace( '/^```\s*/m', '', $selected_json );
		$selected_json = trim( $selected_json );

		$selected_ids = json_decode( $selected_json, true );
		if ( !is_array( $selected_ids ) || empty( $selected_ids ) ) {
			// Fallback: just take first 10
			$selected_ids = array_slice( array_column( $candidates_list, 'id' ), 0, 10 );
		}
		$selected_ids = array_slice( $selected_ids, 0, 10 ); // Ensure max 10

		// Filter out current post if it somehow got included
		$current_post_id = $post->ID;
		$selected_ids = array_filter( $selected_ids, function( $id ) use ( $current_post_id ) {
			return intval( $id ) !== intval( $current_post_id );
		});

		$this->core->log( "🎯 AI selected top " . count( $selected_ids ) . ": " . implode( ', ', $selected_ids ) );

		return $selected_ids;
	}

	/**
	 * Internal Links Step 4: Generate link placements for a single target post
	 */
	public function internal_links_step4( $post, $target_post ) {
		global $mwai;

		if ( !$mwai ) {
			throw new Exception( 'AI Engine not available' );
		}

		// Skip current post (double-check)
		if ( $target_post->ID === $post->ID ) {
			return null;
		}

		$language = $this->core->get_post_language_name( $post->ID );
		// Use more content for better matching, but still limit for performance
		$current_content = substr( $post->post_content, 0, 6000 ); // Increased limit
		$target_title = $target_post->post_title;
		$target_url = get_permalink( $target_post );

		$placement_prompt = sprintf(
			'For the TARGET post, suggest ONE option for each of these strategies (if applicable). If a strategy doesn\'t work well, skip it. Return up to 3-4 different approaches.

CURRENT POST content (where we will add links):
%s

TARGET POST to link to:
Title: %s
URL: %s

STRATEGIES (provide one suggestion per strategy):

Strategy 1 - LINK EXISTING TEXT (Best):
Find a word or short phrase already in the content that relates to the target post, and wrap it in a link. No text addition.
Example: {"search":"improving your SEO","replace":"improving your <a href=\"URL\">SEO</a>","reason":"Strategy 1: Linked existing text"}

Strategy 2 - ADD IN PARENTHESIS (Good):
Add a short related note in parenthesis with the link, right after a relevant sentence.
Example: {"search":"boost organic traffic.","replace":"boost organic traffic (see our <a href=\"URL\">keyword guide</a>).","reason":"Strategy 2: Added in parenthesis"}

Strategy 3 - ADD NEW SENTENCE (OK):
Add a short new sentence with the link, inserted toward the END of the content (in the last 2-3 paragraphs). Find a closing tag from the end portion of the content.
Example: {"search":"final thoughts on this topic.</p>","replace":"final thoughts on this topic.</p><p>For more insights, check out our <a href=\"URL\">complete guide</a>.</p>","reason":"Strategy 3: Added new sentence near end"}

Strategy 4 - ADD AT END (Fallback):
Add a related link at the very end of the content. Find text from the LAST paragraph and append after it.
Example: {"search":"Thanks for reading!</p>","replace":"Thanks for reading!</p><p>Related: <a href=\"URL\">Post Title</a></p>","reason":"Strategy 4: Added at end"}

IMPORTANT:
- If TARGET post is completely unrelated to CURRENT post, return []
- You don\'t need to provide all 4 strategies - only the ones that work naturally
- Prioritize Strategies 1-2 over 3-4
- Each strategy should have a different approach
- For Strategies 3-4: Look at the LAST paragraphs of the content, NOT the first ones

Return format: [{"search": "...", "replace": "...", "reason": "Strategy X: ..."}] OR [] if unrelated',
			$current_content,
			$target_title,
			$target_url
		);
		$placement_prompt = sprintf( '<instructions>Reply ONLY with a JSON array in %s. No other text. Each suggestion must include search, replace, and reason.</instructions> <prompt>%s</prompt>', $language, $placement_prompt );

		$placements_json = $this->query( $placement_prompt );
		$placements_json = trim( $placements_json );
		$placements_json = preg_replace( '/^```json\s*/m', '', $placements_json );
		$placements_json = preg_replace( '/^```\s*/m', '', $placements_json );
		$placements_json = trim( $placements_json );

		$placements = json_decode( $placements_json, true );
		if ( is_array( $placements ) && !empty( $placements ) ) {
			$this->core->log( "✅ Generated " . count( $placements ) . " strategy options for: $target_title" );
			return [
				'post_id' => $target_post->ID,
				'post_title' => $target_title,
				'post_url' => $target_url,
				'options' => array_slice( $placements, 0, 4 ) // Max 4 strategies per post
			];
		} else {
			$this->core->log( "⏭️ Skipped $target_title - no natural placement found" );
			return null;
		}
	}

	/**
	 * Return a short context excerpt from a candidate post showing why it's relevant.
	 * Finds the first keyword match in the stripped content and returns a ~250-char window around it.
	 * Falls back to the trimmed lead if no keyword matches.
	 */
	public function extract_candidate_context( $target_post, $keywords ) {
		$plain = trim( preg_replace( '/\s+/', ' ', strip_tags( $target_post->post_content ) ) );
		if ( $plain === '' ) {
			return '';
		}

		$window = 250;

		foreach ( (array) $keywords as $keyword ) {
			$keyword = trim( (string) $keyword );
			if ( $keyword === '' ) continue;

			$pos = mb_stripos( $plain, $keyword );
			if ( $pos === false ) continue;

			$start = max( 0, $pos - intval( $window / 2 ) );
			$snippet = mb_substr( $plain, $start, $window );
			$prefix = $start > 0 ? '…' : '';
			$suffix = ( $start + $window ) < mb_strlen( $plain ) ? '…' : '';
			return $prefix . $snippet . $suffix;
		}

		// Fallback: lead paragraph
		$lead = mb_substr( $plain, 0, $window );
		$suffix = mb_strlen( $plain ) > $window ? '…' : '';
		return $lead . $suffix;
	}

	/**
	 * Replace the first match of $pattern, skipping HTML comments: page builders (YOOtheme, Gutenberg)
	 * keep their JSON layout there, and editing it breaks the page. Returns null when nothing matched.
	 */
	private function replace_outside_comments( $pattern, $replace, $content ) {
		$parts = preg_split( '/(<!--.*?-->)/s', $content, -1, PREG_SPLIT_DELIM_CAPTURE );
		for ( $i = 0; $i < count( $parts ); $i += 2 ) { // Odd indexes are the comments.
			// A callback, so "$1" or "\1" in $replace stays literal.
			$parts[$i] = preg_replace_callback( $pattern, function() use ( $replace ) { return $replace; }, $parts[$i], 1, $count );
			if ( $count ) {
				return implode( '', $parts );
			}
		}
		return null;
	}

	/**
	 * Split post content into Introduction, Content, and Conclusion sections by <p> boundaries.
	 * - ≤2 paragraphs: only "content" (too short to split)
	 * - 3-4 paragraphs: "introduction" (first 2) + "conclusion" (last 2, may overlap)
	 * - 5+ paragraphs: "introduction" (first 2) + "content" (middle, truncated to ~2000 chars) + "conclusion" (last 2)
	 */
	private function split_content_into_sections( $html ) {
		// Split on paragraph boundaries, keeping tags
		preg_match_all( '/<p[\s>].*?<\/p>/is', $html, $matches );
		$paragraphs = $matches[0] ?? [];
		$count = count( $paragraphs );

		if ( $count <= 2 ) {
			return [
				[ 'name' => 'content', 'content' => implode( "\n", $paragraphs ) ]
			];
		}

		$intro = array_slice( $paragraphs, 0, 2 );
		$conclusion = array_slice( $paragraphs, -2 );

		if ( $count <= 4 ) {
			return [
				[ 'name' => 'introduction', 'content' => implode( "\n", $intro ) ],
				[ 'name' => 'conclusion', 'content' => implode( "\n", $conclusion ) ],
			];
		}

		$middle = array_slice( $paragraphs, 2, $count - 4 );
		$middle_text = implode( "\n", $middle );
		if ( mb_strlen( $middle_text ) > 2000 ) {
			$middle_text = mb_substr( $middle_text, 0, 2000 );
		}

		return [
			[ 'name' => 'introduction', 'content' => implode( "\n", $intro ) ],
			[ 'name' => 'content', 'content' => $middle_text ],
			[ 'name' => 'conclusion', 'content' => implode( "\n", $conclusion ) ],
		];
	}

}
