<?php

namespace FluentCartPro\App\Modules\AdvancedInventory\Services\Filter;

use FluentCart\App\Models\Product;
use FluentCart\App\Services\Filter\BaseFilter;

class AdvancedInventoryFilter extends BaseFilter
{
    /**
     * Variants eager-loaded per product on the list. A product that fits
     * entirely inside this cap is served complete and never shows a
     * load-more; a product with MORE than this many variants is trimmed to
     * VARIANTS_VISIBLE_WHEN_CAPPED at serialization (see
     * AdvancedInventoryController::transformProduct()) and the rest are
     * fetched through GET inventory/variants with the same ordering.
     */
    const VARIANTS_PER_PRODUCT = 10;

    /**
     * Rows actually serialized for a product that overflows the eager cap.
     * Smaller than the fetch cap on purpose: fetching 10 keeps small
     * products complete in one query, while big ones start at 5 rows.
     */
    const VARIANTS_VISIBLE_WHEN_CAPPED = 5;

    public string $defaultSortBy = 'id';

    public function applySimpleFilter(?string $search = null): void
    {
        $this->query = $this->query->whereHas('detail', function ($q) {
            $q->where('manage_stock', '1');
        });

        $this->query = $this->query->whereHas('variants', function ($q) {
            $q->where('manage_stock', '1');
        });

        $isApplied = $this->applySimpleOperatorFilter();
        if ($isApplied) {
            return;
        }

        $this->query = $this->query->when($this->search, function ($query, $search) {
            return $query->where(function ($query) use ($search) {
                $query->where('post_title', 'like', '%' . $search . '%')
                    ->orWhereHas('variants', function ($q) use ($search) {
                        $q->where('manage_stock', '1')
                            ->where(function ($subQ) use ($search) {
                                $subQ->where('sku', 'like', '%' . $search . '%')
                                    ->orWhere('variation_title', 'like', '%' . $search . '%');
                            });
                    });
            });
        });
    }

    public function tabsMap(): array
    {
        return [
            'all'          => null,
            'low_stock'    => 'total_stock',
            'out_of_stock' => 'total_stock',
        ];
    }

    public function getModel(): string
    {
        return Product::class;
    }

    public static function getFilterName(): string
    {
        return 'inventory';
    }

    /**
     * The keys are CONTEXTS, not relation names, exactly as in the free
     * plugin's ProductFilter — which no longer allowlists `detail` bare, so the
     * raw relation names this screen used to send are dead request values now.
     *
     * This filter serves exactly one route: `GET /inventory`
     * (app/Modules/AdvancedInventory/Http/Routes/routes.php), whose meta
     * requires `products/view`, and grep confirms `AdvancedInventoryController::
     * index()` is its only construction site. Both callbacks still re-state that
     * same `products/view` bar: the map is also reachable through
     * `AdvancedInventoryFilter::make()` from any add-on and through the
     * `fluent_cart/inventory_allowed_withs` escape valve, where no route ran.
     * The check can never refuse a caller that got past the route, so it costs
     * one capability lookup and changes nothing on the real path.
     *
     * The only client is InventoryTable.js in the FREE plugin
     * (resources/admin/utils/table-new/InventoryTable.js), whose `with()` now
     * sends exactly these two keys. Nothing in either repo's `resources/` sends
     * a `scopes` key at this route, so allowedScopes() stays at the base
     * deny-all.
     *
     * Deliberately NOT allowlisted, at any depth: `downloadable_files` (paid
     * content file paths), `integrations`, `licensesMeta`, `postmeta`,
     * `wpTerms`/`wp_terms`, and the order-side relations — none of them are
     * inventory data and none are requested here.
     *
     * @return array<string, callable>
     */
    protected function allowedWiths(): array
    {
        return [
            // Version-gated screen keys. Free and pro update independently on
            // real stores, so the capped/slim v2 contract is opt-in by key:
            // an OLD free frontend keeps sending 'admin_inventory_list' and
            // gets the uncapped legacy shape its components were built for
            // (full variant list to sum, item_price feeding formatted_total);
            // the NEW frontend sends the v2 key and gets the capped list its
            // Load More / SQL-totals UI expects.
            'admin_inventory_list'    => [$this, 'adminInventoryListLegacy'],
            'admin_inventory_list_v2' => [$this, 'adminInventoryList'],

            // The public entry points. `detail` and `variants` are the two
            // relations an external consumer can reasonably ask a product
            // endpoint for, and both are catalogue data the route's own
            // products/view already covers. The screen key above exists because
            // the inventory table wants both in one request and needs the
            // variant rows narrowed; these give either one on its own, unnarrowed,
            // to a consumer that is not that screen.
            'detail'               => [$this, 'publicDetail'],
            'variants'             => [$this, 'publicVariants'],
        ];
    }

    /**
     * `utils/table-new/InventoryTable.js` — the product row of the inventory
     * list.
     *
     * No select, on purpose. The list renders `row.thumbnail`, and
     * Product::getThumbnailAttribute() reads `$this->detail->featured_media`,
     * which is itself a ProductDetail append backed by its `galleryImage`
     * relation — a narrowed select would blank every product thumbnail.
     * ProductDetail carries only catalogue columns already visible under
     * `products/view`, and AdvancedInventoryController::transformProduct()
     * re-emits the whole relation in its `detail` response key, so narrowing
     * would also change the payload shape for no security gain.
     *
     * @param \FluentCart\Framework\Database\Orm\Builder $query
     * @return \FluentCart\Framework\Database\Orm\Builder|bool
     */
    protected function adminInventoryList($query)
    {
        if (!$this->userCanAny('products/view')) {
            return false;
        }

        // One call: a later entry naming `variants.something` would otherwise
        // inject an empty closure over `variants` and drop the select below.
        // `detail.galleryImage` and `variants.media` are eager-loaded because the
        // `featured_media` / `thumbnail` appends lazy-load them per row otherwise
        // (one query per variant — 255 extra queries on a 10-product page).
        return $query->with([
            'detail.galleryImage',
            'variants' => function ($variantQuery) {
                $variantQuery->select(self::inventoryVariantColumns())
                    ->with('media');
                // Deterministic order shared with the load-more endpoint.
                $variantQuery->orderBy('id', 'ASC');
                // Own statement ON THE RELATION, never chained off select():
                // only Relation::limit() compiles to the per-parent groupLimit
                // (ROW_NUMBER over post_id); a builder-level limit is silently
                // dropped by the eager loader.
                $variantQuery->limit(self::VARIANTS_PER_PRODUCT);
            },
        ]);
    }

    /**
     * Pre-v2 screen contract, served to a free frontend that predates the
     * capped list: every variant eager-loaded (its parent rows sum the loaded
     * list) with item_price selected (its bulk modal renders the
     * formatted_total append). Same eager media/gallery loads as v2 — the
     * N+1 fixes apply to both generations.
     *
     * @param \FluentCart\Framework\Database\Orm\Builder $query
     * @return \FluentCart\Framework\Database\Orm\Builder|bool
     */
    protected function adminInventoryListLegacy($query)
    {
        if (!$this->userCanAny('products/view')) {
            return false;
        }

        return $query->with([
            'detail.galleryImage',
            'variants' => function ($variantQuery) {
                $variantQuery->select(self::legacyInventoryVariantColumns())
                    ->with('media');
                $variantQuery->orderBy('id', 'ASC');
            },
        ]);
    }

    /**
     * The catalogue detail row on its own, unnarrowed.
     *
     * @param \FluentCart\Framework\Database\Orm\Builder $query
     * @return \FluentCart\Framework\Database\Orm\Builder|bool
     */
    protected function publicDetail($query)
    {
        if (!$this->userCanAny('products/view')) {
            return false;
        }

        return $query->with(['detail']);
    }

    /**
     * The variation rows on their own, unnarrowed. The nine-column select is a
     * property of the inventory SCREEN, not of the endpoint's published shape —
     * narrowing a public key would be the silent narrowing this contract exists
     * to avoid.
     *
     * @param \FluentCart\Framework\Database\Orm\Builder $query
     * @return \FluentCart\Framework\Database\Orm\Builder|bool
     */
    protected function publicVariants($query)
    {
        if (!$this->userCanAny('products/view')) {
            return false;
        }

        return $query->with(['variants']);
    }

    /**
     * `utils/table-new/InventoryTable.js` — the stock columns.
     *
     * Constrained, because the inventory screen reads a handful of stock
     * columns out of a table that also holds cost, compare-at price, downloads
     * and the whole `other_info` blob. The select belongs INSIDE the relation
     * closure: `$query` here is the MAIN product query, so a bare
     * `$query->select([...])` would narrow `wp_posts` instead of
     * `fct_product_variations`.
     *
     * Every column is read by the admin screen — dropping any of them breaks
     * something visible:
     *   id              row key, checkbox selection, updateStock `variant_id`,
     *                   adjustment history, and the `thumbnail` append (its
     *                   `media` relation keys on the variant id)
     *   post_id         hasMany eager-load match key AND updateStock `post_id`
     *                   (InventoryBulkAdjustModal.vue sends `item.post_id`)
     *   sku             SKU column (InventoryTableRow / InventoryParentTableRow)
     *   variation_title child rows and the bulk-adjust preview
     *   item_price      ProductVariation::booted() appends `formatted_total` to
     *                   every retrieved row, and that accessor reads item_price;
     *                   InventoryBulkAdjustModal.vue renders it
     *   total_stock / available / committed / on_hold
     *                   the four stock columns and the parent-row sums in
     *                   InventoryParentTableRow.vue
     *
     * The whole subtree is loaded in ONE with() call so no segment can be
     * clobbered by an empty closure from another entry.
     *
     * @param \FluentCart\Framework\Database\Orm\Builder $query
     * @return \FluentCart\Framework\Database\Orm\Builder|bool
     */
    /**
     * Every column the Advanced Inventory screen reads, and no more.
     * `id` keys the `media` relation the `thumbnail` append lazy-loads;
     * `post_id` is the eager-load match key. No price columns: nothing on the
     * screen renders price since the bulk-adjust preview dropped its price
     * line, and the `formatted_total` append that would read `item_price` is
     * suppressed at serialization (AdvancedInventoryController::
     * presentVariantRows()).
     *
     * Public static so the load-more endpoint (AdvancedInventoryController::
     * variants()) serves rows with the exact same shape as the eager load.
     *
     * @return array
     */
    public static function inventoryVariantColumns(): array
    {
        return [
            'id',
            'post_id',
            'sku',
            'variation_title',
            'total_stock',
            'available',
            'committed',
            'on_hold',
        ];
    }

    /**
     * The pre-v2 column set: v2 plus item_price, which feeds the
     * formatted_total append the OLD bulk-adjust modal renders.
     *
     * @return array
     */
    public static function legacyInventoryVariantColumns(): array
    {
        $columns = self::inventoryVariantColumns();
        $columns[] = 'item_price';

        return $columns;
    }

    public function applyActiveViewFilter(?string $activeView = null): void
    {
        $activeView = $activeView ?? $this->activeView;

        $this->query->when($activeView, function ($query, $activeView) {
            return $query->whereHas('variants', function ($q) use ($activeView) {
                if ($activeView === 'low_stock') {
                    $lowStockThreshold = apply_filters('fluent_cart/inventory_low_stock_threshold', 10);
                    $q->where('manage_stock', '1')
                        ->where('available', '>', 0)
                        ->where('available', '<=', $lowStockThreshold);
                } elseif ($activeView === 'out_of_stock') {
                    $q->where('manage_stock', '1')
                        ->where('available', '<=', 0);
                }
            });
        });
    }
}
