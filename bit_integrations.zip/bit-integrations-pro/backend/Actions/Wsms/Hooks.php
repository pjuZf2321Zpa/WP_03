<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Actions\Wsms\WsmsProHelper;
use BitApps\IntegrationsPro\Config;
use BitApps\IntegrationsPro\Core\Util\Hooks;

Hooks::filter(Config::withFreePrefix('wsms_send_sms'), [WsmsProHelper::class, 'sendSms'], 10, 2);
Hooks::filter(Config::withFreePrefix('wsms_add_subscriber'), [WsmsProHelper::class, 'addSubscriber'], 10, 3);
Hooks::filter(Config::withFreePrefix('wsms_update_subscriber'), [WsmsProHelper::class, 'updateSubscriber'], 10, 3);
Hooks::filter(Config::withFreePrefix('wsms_delete_subscriber'), [WsmsProHelper::class, 'deleteSubscriber'], 10, 3);
Hooks::filter(Config::withFreePrefix('wsms_add_group'), [WsmsProHelper::class, 'addGroup'], 10, 2);
Hooks::filter(Config::withFreePrefix('wsms_update_group'), [WsmsProHelper::class, 'updateGroup'], 10, 2);
Hooks::filter(Config::withFreePrefix('wsms_delete_group'), [WsmsProHelper::class, 'deleteGroup'], 10, 2);
