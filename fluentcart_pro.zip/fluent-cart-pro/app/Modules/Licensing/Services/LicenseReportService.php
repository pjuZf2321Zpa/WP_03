<?php

namespace FluentCartPro\App\Modules\Licensing\Services;

use FluentCart\App\App;
use FluentCart\App\Services\Report\ReportHelper;
use FluentCart\App\Services\Report\ReportService;
use FluentCart\Framework\Support\Arr;

/**
 * Reports → Licenses. Each method feeds one card and runs one grouped query, so a slow card never blocks the others.
 * Statuses are the stored ones the Licenses list shows; "inactive" is a valid license with no site yet.
 */
class LicenseReportService extends ReportService
{
    const VALID_STATUSES = ['active', 'inactive'];

    /**
     * Licenses issued and production sites activated in the range.
     */
    public function getOverview(array $params): array
    {
        $range = [$params['startDate'], $params['endDate']];

        $licenses = $this->licenses($params)
            ->whereBetween('l.created_at', $range)
            ->selectRaw('COUNT(*) AS issued, SUM(l.activation_count > 0) AS activated')
            ->first();

        $sites = $this->activations($params)
            ->whereBetween('a.created_at', $range)
            ->selectRaw('SUM(a.is_local = 0) AS sites, SUM(a.is_local = 1) AS local_sites')
            ->first();

        return [
            'issued'      => (int) Arr::get((array) $licenses, 'issued', 0),
            'activated'   => (int) Arr::get((array) $licenses, 'activated', 0),
            'sites'       => (int) Arr::get((array) $sites, 'sites', 0),
            'local_sites' => (int) Arr::get((array) $sites, 'local_sites', 0),
        ];
    }

    /**
     * Every license today by status, with the counts that need action. The date range does not apply.
     */
    public function getStatus(array $params): array
    {
        $rows = $this->licenses($params)
            ->selectRaw('l.status, COUNT(*) AS licenses, SUM(l.activation_count) AS sites,
                SUM(l.activation_count > 0) AS with_sites,
                SUM(l.`limit` > 0 AND l.activation_count >= l.`limit`) AS at_limit')
            ->groupBy('l.status')
            ->get();

        $statuses = [];
        $totals = ['licenses' => 0, 'valid' => 0, 'live_sites' => 0, 'at_limit' => 0, 'expired_with_sites' => 0];

        foreach ($rows as $row) {
            $status = (string) $row->status;
            $statuses[$status] = (int) $row->licenses;
            $totals['licenses'] += (int) $row->licenses;

            if (in_array($status, self::VALID_STATUSES, true)) {
                $totals['valid'] += (int) $row->licenses;
                $totals['live_sites'] += (int) $row->sites;
                $totals['at_limit'] += (int) $row->at_limit;
            } elseif ($status === 'expired') {
                $totals['expired_with_sites'] = (int) $row->with_sites;
            }
        }

        return array_merge($totals, [
            'statuses'      => $statuses,
            'not_activated' => (int) Arr::get($statuses, 'inactive', 0),
        ]);
    }

    /**
     * Licenses issued and production sites activated per day, month or year of the range.
     */
    public function getTrend(array $params): array
    {
        $groupKey = Arr::get($params, 'groupKey');
        if (!in_array($groupKey, ['daily', 'monthly', 'yearly'], true)) {
            $groupKey = ReportHelper::defineGroupKey($params['startDate'], $params['endDate']);
        }
        $format = $groupKey === 'yearly' ? '%Y' : ($groupKey === 'monthly' ? '%Y-%m' : '%Y-%m-%d');
        $range = [$params['startDate'], $params['endDate']];

        $points = $this->getPeriodRange($params['startDate'], $params['endDate'], $groupKey, ['licenses', 'sites']);

        $bucket = function ($column) use ($params, $format) {
            return "DATE_FORMAT(" . ReportHelper::storeTimeSql($column, $params['startDate'], $params['endDate']) . ", '{$format}')";
        };

        $licenseBucket = $bucket('l.created_at');
        $licenses = $this->licenses($params)
            ->whereBetween('l.created_at', $range)
            ->selectRaw("{$licenseBucket} AS `group`, COUNT(*) AS total")
            ->groupBy(App::db()->raw($licenseBucket))
            ->get();

        $siteBucket = $bucket('a.created_at');
        $sites = $this->activations($params)
            ->where('a.is_local', 0)
            ->whereBetween('a.created_at', $range)
            ->selectRaw("{$siteBucket} AS `group`, COUNT(*) AS total")
            ->groupBy(App::db()->raw($siteBucket))
            ->get();

        foreach ([['licenses', $licenses], ['sites', $sites]] as list($key, $rows)) {
            foreach ($rows as $row) {
                if (isset($points[$row->group])) {
                    $points[$row->group][$key] = (int) $row->total;
                }
            }
        }

        // The totals before the range: the cumulative lines start from them
        $before = [
            'licenses' => (int) $this->licenses($params)->where('l.created_at', '<', $params['startDate'])->count(),
            'sites'    => (int) $this->activations($params)
                ->where('a.is_local', 0)
                ->where('a.created_at', '<', $params['startDate'])
                ->count(),
        ];

        return [
            'group_key' => $groupKey,
            'points'    => array_values($points),
            'before'    => $before,
        ];
    }

    /**
     * Licenses, production sites and limit use per variation. The date range does not apply.
     */
    public function getProducts(array $params): array
    {
        $licenses = $this->licenses($params)
            ->selectRaw("l.product_id, l.variation_id, COUNT(*) AS licenses,
                SUM(l.status = 'active') AS active,
                SUM(l.status = 'inactive') AS not_activated,
                SUM(l.status = 'expired') AS expired,
                SUM(l.status = 'disabled') AS disabled,
                SUM(IF(l.status IN ('active', 'inactive'), l.activation_count, 0)) AS live_sites,
                SUM(l.status = 'expired' AND l.activation_count > 0) AS expired_with_sites,
                SUM(l.status IN ('active', 'inactive') AND l.`limit` > 0) AS limited,
                SUM(IF(l.status IN ('active', 'inactive') AND l.`limit` > 0, l.`limit`, 0)) AS limit_total,
                SUM(IF(l.status IN ('active', 'inactive') AND l.`limit` > 0, LEAST(l.activation_count, l.`limit`), 0)) AS limit_used,
                SUM(l.status IN ('active', 'inactive') AND l.`limit` > 0 AND l.activation_count >= l.`limit`) AS at_limit")
            ->groupBy('l.product_id', 'l.variation_id')
            ->get();

        $titles = [];
        foreach (ReportHelper::variationOptions($licenses->pluck('variation_id')->all()) as $product) {
            foreach ($product['variations'] as $variation) {
                $titles[$variation['id']] = [$product['product_title'], $variation['title']];
            }
        }

        $products = [];
        foreach ($licenses as $row) {
            $productId = (int) $row->product_id;
            $variationId = (int) $row->variation_id;
            $title = Arr::get($titles, $variationId, ['', '']);

            if (!isset($products[$productId])) {
                $products[$productId] = [
                    'product_id'    => $productId,
                    'product_title' => $title[0] !== '' ? $title[0] : get_the_title($productId),
                    'variations'    => [],
                ];
            }

            $products[$productId]['variations'][] = array_merge([
                'variation_id'    => $variationId,
                'variation_title' => $title[1],
            ], $this->figures($row));
        }

        foreach ($products as &$product) {
            $sum = [];
            foreach ($product['variations'] as $variation) {
                foreach ($variation as $key => $value) {
                    if (is_int($value) && $key !== 'variation_id') {
                        $sum[$key] = Arr::get($sum, $key, 0) + $value;
                    }
                }
            }
            $product = array_merge($product, $sum);
        }
        unset($product);

        usort($products, function ($a, $b) {
            return $b['live_sites'] <=> $a['live_sites'] ?: $b['licenses'] <=> $a['licenses'] ?: $a['product_id'] <=> $b['product_id'];
        });

        return ['products' => $products];
    }

    /**
     * Plugin versions reported by one product's production sites, split by whether the license is still valid.
     * Sites report their version only when they check for updates, so older installs may show none.
     */
    public function getVersions(int $productId): array
    {
        // A site keeps an expired license's activation next to a newer one: one row per site.
        // It is valid when any of its licenses is; its version comes from its latest dated activation that has one.
        // A fixed-width date keeps the order the same on every collation.
        $valid = "l.status IN ('active', 'inactive')";
        $perSite = $this->activations([])
            ->where('a.product_id', $productId)
            ->where('a.is_local', 0)
            ->selectRaw("MAX({$valid}) AS valid,
                SUBSTRING_INDEX(MAX(CONCAT(IFNULL(a.last_update_version, '') <> '', IFNULL(a.last_update_date, '0000-00-00 00:00:00'), '|', IFNULL(a.last_update_version, ''))), '|', -1) AS version")
            ->groupBy('a.site_id');

        $rows = App::db()->query()->fromSub($perSite, 'sites')
            ->selectRaw('version, SUM(valid) AS valid, SUM(1 - valid) AS lapsed')
            ->groupBy('version')
            ->get();

        $latest = (string) Arr::get(LicenseHelper::getProductLicenseConfig($productId), 'version', '');
        $latest = self::isVersion($latest) ? $latest : '';

        $versions = [];
        $unknown = ['valid' => 0, 'lapsed' => 0];

        foreach ($rows as $row) {
            $version = trim((string) $row->version);
            // A version above the released one comes from another plugin's updater: it tells nothing about this one
            if (!self::isVersion($version) || ($latest && version_compare($version, $latest, '>'))) {
                $unknown['valid'] += (int) $row->valid;
                $unknown['lapsed'] += (int) $row->lapsed;
                continue;
            }

            if (!isset($versions[$version])) {
                $versions[$version] = ['version' => $version, 'valid' => 0, 'lapsed' => 0];
            }
            $versions[$version]['valid'] += (int) $row->valid;
            $versions[$version]['lapsed'] += (int) $row->lapsed;
        }

        uksort($versions, function ($a, $b) {
            return version_compare($b, $a);
        });

        return [
            'latest'   => $latest,
            'versions' => array_values($versions),
            'unknown'  => $unknown,
        ];
    }

    /**
     * Server and platform versions (major.minor) of one product's production sites, as the sites report them.
     */
    public function getEnvironment(int $productId): array
    {
        $rows = $this->activations([])
            // A missing site row counts as unknown, so the totals match Versions
            ->leftJoin('fct_license_sites as s', 's.id', '=', 'a.site_id')
            ->where('a.product_id', $productId)
            ->where('a.is_local', 0)
            ->selectRaw("SUBSTRING_INDEX(s.server_version, '.', 2) AS server, SUBSTRING_INDEX(s.platform_version, '.', 2) AS platform, COUNT(DISTINCT a.site_id) AS sites")
            ->groupBy('server', 'platform')
            ->get();

        $counts = ['server' => [], 'platform' => []];
        foreach ($rows as $row) {
            foreach (['server', 'platform'] as $type) {
                $value = trim((string) $row->{$type});
                $key = preg_match('/^\d+\.\d+$/', $value) ? $value : '';
                $counts[$type][$key] = (isset($counts[$type][$key]) ? $counts[$type][$key] : 0) + (int) $row->sites;
            }
        }

        $shape = function (array $counts) {
            $unknown = isset($counts['']) ? $counts[''] : 0;
            unset($counts['']);
            uksort($counts, function ($a, $b) {
                return version_compare($b, $a);
            });
            $items = [];
            foreach ($counts as $version => $sites) {
                $items[] = ['version' => (string) $version, 'sites' => $sites];
            }

            return ['items' => $items, 'unknown' => $unknown];
        };

        return ['server' => $shape($counts['server']), 'platform' => $shape($counts['platform'])];
    }

    protected function licenses(array $params)
    {
        $variationIds = array_filter(array_map('intval', (array) Arr::get($params, 'variationIds', [])));

        return App::db()->table('fct_licenses as l')
            ->when($variationIds, function ($query) use ($variationIds) {
                $query->whereIn('l.variation_id', $variationIds);
            });
    }

    /**
     * Activations of licenses that still exist, filtered by the license's variation:
     * an upgrade moves the license but not its older activation rows.
     */
    protected function activations(array $params)
    {
        $variationIds = array_filter(array_map('intval', (array) Arr::get($params, 'variationIds', [])));

        return App::db()->table('fct_license_activations as a')
            ->join('fct_licenses as l', 'l.id', '=', 'a.license_id')
            ->when($variationIds, function ($query) use ($variationIds) {
                $query->whereIn('l.variation_id', $variationIds);
            });
    }

    protected function figures($row): array
    {
        $keys = ['licenses', 'active', 'not_activated', 'expired', 'disabled', 'live_sites', 'expired_with_sites',
            'limited', 'limit_total', 'limit_used', 'at_limit'];

        $figures = [];
        foreach ($keys as $key) {
            $figures[$key] = (int) $row->{$key};
        }

        return $figures;
    }

    protected static function isVersion(string $value): bool
    {
        return (bool) preg_match('/^\d+(\.\d+){0,3}$/', $value);
    }
}
