<?php

namespace BitApps\IntegrationsPro\Actions\FollowUpBoss\Services;

final class PersonService extends BaseService
{
    public function createPerson(): array
    {
        $validationRules = ['price' => ['nullable', 'integer']];
        $error = $this->validateFields(
            $validationRules,
            [
                'price' => __('Price', 'bit-integrations-pro'),
            ]
        );

        if ($error !== null) {
            return $error;
        }

        if ($this->hasAssignedUserAndPond()) {
            return $this->errorResponse(__('Assigned User and Assigned Pond cannot be used together. Select only one of them.', 'bit-integrations-pro'));
        }

        $payload = $this->removeEmptyValues(
            [
                'firstName'        => $this->getString('first_name'),
                'lastName'         => $this->getString('last_name'),
                'stage'            => $this->getString('stage'),
                'source'           => $this->getString('source'),
                'sourceUrl'        => $this->getString('source_url'),
                'contacted'        => $this->getBoolean('contacted'),
                'price'            => $this->getInteger('price'),
                'assignedUserId'   => $this->getInteger('assigned_user_id'),
                'assignedLenderId' => $this->getInteger('assigned_lender_id'),
                'assignedPondId'   => $this->getInteger('assigned_pond_id'),
                'tags'             => $this->getList('tags'),
                'background'       => $this->getString('background'),
                'collaborators'    => $this->getIntegerList('collaborators'),
                'timeframeId'      => $this->getInteger('timeframe_id'),
                'createdAt'        => $this->getString('created_at'),
                'emails'           => $this->getEmails('email'),
                'phones'           => $this->getPhones('phone'),
                'addresses'        => $this->getAddresses(),
            ]
        ) + $this->getCustomFieldValues();

        $query = $this->removeEmptyValues(
            [
                'deduplicate' => $this->getBoolean('deduplicate'),
            ]
        );

        return $this->dispatch('POST', '/people', $payload, $query);
    }

    public function updatePerson(): array
    {
        $validationRules = [
            'person_id' => ['required', 'integer'],
            'price'     => ['nullable', 'integer'],
        ];
        $error = $this->validateFields(
            $validationRules,
            [
                'person_id' => __('Person ID', 'bit-integrations-pro'),
                'price'     => __('Price', 'bit-integrations-pro'),
            ]
        );

        if ($error !== null) {
            return $error;
        }

        if ($this->hasAssignedUserAndPond()) {
            return $this->errorResponse(__('Assigned User and Assigned Pond cannot be used together. Select only one of them.', 'bit-integrations-pro'));
        }

        $payload = $this->removeEmptyValues(
            [
                'firstName'        => $this->getString('first_name'),
                'lastName'         => $this->getString('last_name'),
                'stage'            => $this->getString('stage'),
                'contacted'        => $this->getBoolean('contacted'),
                'price'            => $this->getInteger('price'),
                'assignedUserId'   => $this->getInteger('assigned_user_id'),
                'assignedLenderId' => $this->getInteger('assigned_lender_id'),
                'assignedPondId'   => $this->getInteger('assigned_pond_id'),
                'tags'             => $this->getList('tags'),
                'background'       => $this->getString('background'),
                'collaborators'    => $this->getIntegerList('collaborators'),
                'timeframeId'      => $this->getInteger('timeframe_id'),
                'emails'           => $this->getEmails('email'),
                'phones'           => $this->getPhones('phone'),
                'addresses'        => $this->getAddresses(),
            ]
        ) + $this->getCustomFieldValues();

        $query = $this->removeEmptyValues(
            [
                'mergeTags' => $this->getBoolean('merge_tags'),
            ]
        );

        return $this->dispatch('PUT', '/people/' . rawurlencode($this->getString('person_id')), $payload, $query);
    }

    public function deletePerson(): array
    {
        $validationRules = ['person_id' => ['required', 'integer']];
        $error = $this->validateFields(
            $validationRules,
            [
                'person_id' => __('Person ID', 'bit-integrations-pro'),
            ]
        );

        if ($error !== null) {
            return $error;
        }

        return $this->dispatch('DELETE', '/people/' . rawurlencode($this->getString('person_id')));
    }

    private function hasAssignedUserAndPond(): bool
    {
        return $this->getInteger('assigned_user_id') !== null && $this->getInteger('assigned_pond_id') !== null;
    }
}
