<?php

namespace BitApps\IntegrationsPro\Actions\SystemeIO;

class SystemeIOHelperPro
{
    public static function updateContact($default, $contactId, $finalData, $apiUrl, $headers)
    {
        $httpHelperClass = bit_integrations_get_class('Core\\Util\\HttpHelper');

        $headers['Content-Type'] = 'application/merge-patch+json';

        return $httpHelperClass::request(
            $apiUrl . '/contacts/' . $contactId,
            'PATCH',
            wp_json_encode(['fields' => $finalData['fields'] ?? []]),
            $headers
        );
    }

    public static function addTagToExistingContact($default, $contactId, $tagId, $apiUrl, $headers)
    {
        $httpHelperClass = bit_integrations_get_class('Core\\Util\\HttpHelper');

        return $httpHelperClass::post(
            $apiUrl . '/contacts/' . $contactId . '/tags',
            wp_json_encode(['tagId' => (int) $tagId]),
            $headers
        );
    }
}
