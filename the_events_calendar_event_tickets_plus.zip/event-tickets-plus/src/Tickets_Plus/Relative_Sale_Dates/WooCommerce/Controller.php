<?php
/**
 * Brings Event Tickets' relative sales window to WooCommerce tickets.
 *
 * @since 6.12.0
 *
 * @package TEC\Tickets_Plus\Relative_Sale_Dates\WooCommerce
 */

namespace TEC\Tickets_Plus\Relative_Sale_Dates\WooCommerce;

use TEC\Common\Contracts\Provider\Controller as Controller_Contract;
use TEC\Tickets\Relative_Sale_Dates\Rest;
use TEC\Tickets\Relative_Sale_Dates\Rule_Store;
use TEC\Tickets\Relative_Sale_Dates\Ticket_Dates;
use Tribe__Tickets_Plus__Commerce__WooCommerce__Main as Woo;

/**
 * Adds WooCommerce to the providers the relative sales window applies to, and tells Event Tickets how WooCommerce stores
 * and finds its tickets.
 *
 * WooCommerce keeps a ticket's sales date and time together in the date meta, and relates its tickets to their event
 * through a meta of its own. The sale price window stays Tickets Commerce's: a WooCommerce ticket's sale is managed in
 * the product editor.
 *
 * @since 6.12.0
 *
 * @package TEC\Tickets_Plus\Relative_Sale_Dates\WooCommerce
 */
final class Controller extends Controller_Contract {
	/**
	 * Unregisters the controller.
	 *
	 * @since 6.12.0
	 *
	 * @return void
	 */
	public function unregister(): void {
		remove_filter( 'tec_tickets_relative_sale_dates_ticket_providers', [ $this, 'add_provider' ] );
		remove_filter( 'tec_tickets_relative_sale_dates_ticket_date_format', [ $this, 'filter_date_format' ] );
		remove_filter( 'tec_tickets_relative_sale_dates_event_ticket_ids', [ $this, 'add_event_ticket_ids' ] );
		remove_filter( 'tec_rest_v1_product_transform_entity', $this->container->callback( Rest::class, 'add_rule_to_tec_rest_api_ticket' ) );
	}

	/**
	 * Adds WooCommerce to the providers whose tickets take the relative sales window.
	 *
	 * @since 6.12.0
	 *
	 * @param string[]|mixed $classes The provider classes.
	 *
	 * @return string[]|mixed The provider classes, with WooCommerce's.
	 */
	public function add_provider( $classes ) {
		if ( ! is_array( $classes ) ) {
			return $classes;
		}

		$classes[] = Woo::class;

		return array_values( array_unique( $classes ) );
	}

	/**
	 * Has the sales dates of a WooCommerce ticket written as datetimes in the date metas, where WooCommerce reads them.
	 *
	 * @since 6.12.0
	 *
	 * @param string|mixed $format    The format, `split` or `datetime`.
	 * @param int          $ticket_id The ticket post ID.
	 *
	 * @return string|mixed The format, `datetime` for a WooCommerce ticket.
	 */
	public function filter_date_format( $format, int $ticket_id ) {
		return $this->is_woo_ticket( $ticket_id ) ? Ticket_Dates::FORMAT_DATETIME : $format;
	}

	/**
	 * Adds an event's WooCommerce tickets that have relative sale dates rules, at most as many as Event Tickets reads of
	 * its own.
	 *
	 * @since 6.12.0
	 *
	 * @param int[]|mixed $ticket_ids The ticket post IDs.
	 * @param int         $event_id   The event post ID.
	 *
	 * @return int[]|mixed The ticket post IDs, with the event's ruled WooCommerce tickets.
	 */
	public function add_event_ticket_ids( $ticket_ids, int $event_id ) {
		if ( ! is_array( $ticket_ids ) ) {
			return $ticket_ids;
		}

		$woo_ticket_ids = tribe_tickets( 'woo' )
			->where( 'event', $event_id )
			->where( 'meta_exists', Rule_Store::META_KEY )
			->where( 'post_status', 'any' )
			->order_by( 'ID', 'ASC' )
			->per_page( Rule_Store::TICKETS_QUERY_LIMIT )
			->get_ids();

		return array_merge( $ticket_ids, array_map( 'absint', $woo_ticket_ids ) );
	}

	/**
	 * Registers the controller.
	 *
	 * @since 6.12.0
	 *
	 * @return void
	 */
	protected function do_register(): void {
		add_filter( 'tec_tickets_relative_sale_dates_ticket_providers', [ $this, 'add_provider' ] );
		add_filter( 'tec_tickets_relative_sale_dates_ticket_date_format', [ $this, 'filter_date_format' ], 10, 2 );
		add_filter( 'tec_tickets_relative_sale_dates_event_ticket_ids', [ $this, 'add_event_ticket_ids' ], 10, 2 );
		add_filter( 'tec_rest_v1_product_transform_entity', $this->container->callback( Rest::class, 'add_rule_to_tec_rest_api_ticket' ) );
	}

	/**
	 * Returns whether a ticket is a WooCommerce one.
	 *
	 * @since 6.12.0
	 *
	 * @param int $ticket_id The ticket post ID.
	 *
	 * @return bool Whether WooCommerce sells the ticket.
	 */
	private function is_woo_ticket( int $ticket_id ): bool {
		return tribe_tickets_get_ticket_provider( $ticket_id ) instanceof Woo;
	}
}
