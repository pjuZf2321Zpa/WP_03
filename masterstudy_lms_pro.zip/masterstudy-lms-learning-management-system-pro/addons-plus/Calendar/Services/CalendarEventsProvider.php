<?php

namespace MasterStudy\Lms\Pro\AddonsPlus\Calendar\Services;

use DateTimeImmutable;
use DateTimeZone;
use MasterStudy\Lms\Plugin\Addons;
use wpdb;

final class CalendarEventsProvider {
	private const SUMMARY_LIMIT = 3;

	private int $user_id;

	private wpdb $db;

	private DateTimeZone $timezone;

	private int $now;

	private array $events_cache = array();

	private array $courses_cache = array();

	public function __construct( int $user_id ) {
		global $wpdb;

		$this->user_id  = $user_id;
		$this->db       = $wpdb;
		$this->timezone = wp_timezone();
		$this->now      = ( new DateTimeImmutable( 'now', $this->timezone ) )->getTimestamp();
	}

	public function get_summary( int $year, int $month, string $type = '' ): array {
		$events = $this->filter_events_by_type( $this->get_events_for_month( $year, $month ), $type );
		$days   = array();

		foreach ( $events as $event ) {
			$key = $event['date'];

			if ( ! isset( $days[ $key ] ) ) {
				$days[ $key ] = array(
					'total'  => 0,
					'events' => array(),
				);
			}

			++$days[ $key ]['total'];

			if ( count( $days[ $key ]['events'] ) < self::SUMMARY_LIMIT ) {
				$days[ $key ]['events'][] = $event;
			}
		}

		return array(
			'year'  => $year,
			'month' => $month,
			'days'  => $days,
		);
	}

	public function get_month_events( int $year, int $month, int $page, int $per_page, string $search = '', string $status = '', string $type = '' ): array {
		$events = $this->filter_events_by_type( $this->get_events_for_month( $year, $month ), $type );
		$events = $this->filter_events( $events, $search );
		$counts = $this->status_counts( $events );
		$events = $this->filter_events_by_status( $events, $status );
		$events = $this->sort_events_by_status( $events, $status );
		$result = $this->paginate( $events, $page, $per_page );

		$result['counts'] = $counts;

		return $result;
	}

	public function get_day_events( DateTimeImmutable $date, int $page, int $per_page, string $type = '' ): array {
		$start  = $date->setTime( 0, 0, 0 );
		$end    = $start->modify( '+1 day' );
		$events = $this->get_events_between( $start->getTimestamp(), $end->getTimestamp() );

		if ( empty( $events ) ) {
			$events = $this->get_events_for_day_from_month( $start );
		}

		$events = $this->filter_events_by_type( $events, $type );
		$events = $this->sort_day_events( $events );

		return $this->paginate( $events, $page, $per_page );
	}

	private function get_events_for_month( int $year, int $month ): array {
		$start = ( new DateTimeImmutable( 'now', $this->timezone ) )
			->setDate( $year, $month, 1 )
			->setTime( 0, 0, 0 );
		$end   = $start->modify( '+1 month' );

		return $this->get_events_between( $start->getTimestamp(), $end->getTimestamp() );
	}

	private function get_events_for_day_from_month( DateTimeImmutable $date ): array {
		$date_key = $date->format( 'Y-m-d' );

		return array_values(
			array_filter(
				$this->get_events_for_month( absint( $date->format( 'Y' ) ), absint( $date->format( 'n' ) ) ),
				static function ( array $event ) use ( $date_key ): bool {
					return ( $event['date'] ?? '' ) === $date_key;
				}
			)
		);
	}

	private function get_events_between( int $start, int $end ): array {
		$cache_key = "{$start}:{$end}";

		if ( isset( $this->events_cache[ $cache_key ] ) ) {
			return $this->events_cache[ $cache_key ];
		}

		$courses = $this->get_user_courses();

		if ( empty( $courses ) ) {
			$this->events_cache[ $cache_key ] = array();
			return array();
		}

		$events = array_merge(
			$this->get_curriculum_events( $courses, $start, $end ),
			$this->get_assignment_deadline_events( $courses, $start, $end ),
			$this->get_coming_soon_events( $courses, $start, $end )
		);

		usort(
			$events,
			static function ( array $first, array $second ): int {
				return $first['timestamp'] <=> $second['timestamp'];
			}
		);

		$this->events_cache[ $cache_key ] = $events;

		return $events;
	}

	private function get_user_courses(): array {
		if ( ! empty( $this->courses_cache ) ) {
			return $this->courses_cache;
		}

		if ( ! function_exists( 'stm_lms_user_courses_name' ) ) {
			return array();
		}

		$table = stm_lms_user_courses_name( $this->db );
		$rows  = $this->db->get_results(
			$this->db->prepare(
				"SELECT course_id, start_time FROM {$table} WHERE user_id = %d",
				$this->user_id
			),
			ARRAY_A
		);

		foreach ( (array) $rows as $row ) {
			$course_id = absint( $row['course_id'] ?? 0 );

			if ( ! $course_id ) {
				continue;
			}

			$this->courses_cache[ $course_id ] = array(
				'id'         => $course_id,
				'title'      => get_the_title( $course_id ),
				'start_time' => absint( $row['start_time'] ?? 0 ),
			);
		}

		foreach ( $this->get_preordered_courses() as $course ) {
			if ( empty( $this->courses_cache[ $course['id'] ] ) ) {
				$this->courses_cache[ $course['id'] ] = $course;
			}
		}

		return $this->courses_cache;
	}

	private function get_preordered_courses(): array {
		if ( ! function_exists( 'stm_lms_order_items_name' ) ) {
			return array();
		}

		$order_items_table = stm_lms_order_items_name( $this->db );

		if ( ! $this->table_exists( $order_items_table ) ) {
			return array();
		}

		$rows    = $this->db->get_results(
			$this->db->prepare(
				"
					SELECT DISTINCT items.object_id AS course_id
					FROM {$order_items_table} items
					INNER JOIN {$this->db->posts} orders ON orders.ID = items.order_id
					INNER JOIN {$this->db->postmeta} status_meta
						ON status_meta.post_id = orders.ID
						AND status_meta.meta_key = 'status'
						AND status_meta.meta_value = 'completed'
					INNER JOIN {$this->db->postmeta} coming_soon_date
						ON coming_soon_date.post_id = items.object_id
						AND coming_soon_date.meta_key = 'coming_soon_date'
					LEFT JOIN {$this->db->postmeta} user_meta
						ON user_meta.post_id = orders.ID
						AND user_meta.meta_key = 'user_id'
					WHERE orders.post_type = 'stm-orders'
						AND ( orders.post_author = %d OR user_meta.meta_value = %d )
						AND CAST( coming_soon_date.meta_value AS UNSIGNED ) > UNIX_TIMESTAMP( orders.post_date ) * 1000
				",
				$this->user_id,
				$this->user_id
			),
			ARRAY_A
		);
		$courses = array();

		foreach ( (array) $rows as $row ) {
			$course_id = absint( $row['course_id'] ?? 0 );

			if ( ! $course_id || 'stm-courses' !== get_post_type( $course_id ) ) {
				continue;
			}

			$courses[ $course_id ] = array(
				'id'         => $course_id,
				'title'      => get_the_title( $course_id ),
				'start_time' => 0,
			);
		}

		return $courses;
	}

	private function get_curriculum_events( array $courses, int $start, int $end ): array {
		$events = array();

		foreach ( $this->get_curriculum_event_queries( $courses, $start, $end ) as $query_data ) {
			$events = array_merge(
				$events,
				$this->get_curriculum_events_from_query(
					$query_data['query'],
					$query_data['args'],
					$courses,
					$start,
					$end
				)
			);
		}

		return $events;
	}

	private function get_curriculum_event_queries( array $courses, int $start, int $end ): array {
		if (
			! function_exists( 'stm_lms_curriculum_materials_name' )
			|| ! function_exists( 'stm_lms_curriculum_sections_name' )
		) {
			return array();
		}

		$materials_table = stm_lms_curriculum_materials_name( $this->db );
		$sections_table  = stm_lms_curriculum_sections_name( $this->db );
		$posts_table     = $this->db->posts;
		$postmeta_table  = $this->db->postmeta;
		$course_ids      = array_map( 'absint', array_keys( $courses ) );

		if ( empty( $course_ids ) ) {
			return array();
		}

		$course_placeholders        = implode( ',', array_fill( 0, count( $course_ids ), '%d' ) );
		$excluded_drip_post_types   = array( 'stm-zoom', 'ms-zoom', 'stm-zoom-webinar', 'stm-google-meets' );
		$excluded_drip_post_types[] = $this->is_addon_enabled( Addons::ASSIGNMENTS ) ? '' : 'stm-assignments';
		$excluded_drip_post_types   = array_filter( $excluded_drip_post_types );
		$excluded_drip_placeholders = implode( ',', array_fill( 0, count( $excluded_drip_post_types ), '%s' ) );
		$common_select              = '
				materials.post_id AS item_id,
				materials.post_type,
				materials.`order` AS material_order,
				sections.course_id,
				posts.post_title,
				posts.post_type AS real_post_type
		';
		$common_from                = "
			FROM {$sections_table} sections
			INNER JOIN {$materials_table} materials ON materials.section_id = sections.id
			INNER JOIN {$posts_table} posts ON posts.ID = materials.post_id
		";
		$common_where               = "
			WHERE sections.course_id IN ({$course_placeholders})
				AND posts.post_status NOT IN ('trash', 'auto-draft')
		";
		$queries                    = array();

		if ( $this->is_pro_plus_addon_enabled( Addons::ZOOM_CONFERENCE ) ) {
			$zoom_args   = $course_ids;
			$zoom_window = $this->date_meta_window_clause( 'zoom_date', $start, $end, $zoom_args );
			$queries[]   = array(
				'query' => "
					SELECT
						{$common_select},
						'' AS lesson_type,
						'' AS stream_start_date,
						'' AS stream_start_time,
						'' AS stream_end_date,
						'' AS stream_end_time,
						zoom_date.meta_value AS zoom_date,
						zoom_time.meta_value AS zoom_time,
						zoom_duration.meta_value AS zoom_duration,
						'' AS meet_start_date,
						'' AS meet_start_time,
						'' AS meet_end_date,
						'' AS meet_end_time,
						'' AS drip_start_date,
						'' AS drip_start_time,
						'' AS drip_from_start,
						'' AS drip_start_days
					{$common_from}
					INNER JOIN {$postmeta_table} zoom_date ON zoom_date.post_id = materials.post_id AND zoom_date.meta_key = 'stm_date'
					LEFT JOIN {$postmeta_table} zoom_time ON zoom_time.post_id = materials.post_id AND zoom_time.meta_key = 'stm_time'
					LEFT JOIN {$postmeta_table} zoom_duration ON zoom_duration.post_id = materials.post_id AND zoom_duration.meta_key = 'stm_duration'
					{$common_where}
						AND posts.post_type IN ('stm-zoom', 'ms-zoom', 'stm-zoom-webinar')
						AND {$zoom_window}
					ORDER BY sections.course_id ASC, materials.`order` ASC
				",
				'args'  => $zoom_args,
			);
		}

		if ( $this->is_pro_plus_addon_enabled( Addons::GOOGLE_MEET ) ) {
			$meet_args   = $course_ids;
			$meet_window = $this->date_meta_window_clause( 'meet_start_date', $start, $end, $meet_args );
			$queries[]   = array(
				'query' => "
					SELECT
						{$common_select},
						'' AS lesson_type,
						'' AS stream_start_date,
						'' AS stream_start_time,
						'' AS stream_end_date,
						'' AS stream_end_time,
						'' AS zoom_date,
						'' AS zoom_time,
						'' AS zoom_duration,
						meet_start_date.meta_value AS meet_start_date,
						meet_start_time.meta_value AS meet_start_time,
						meet_end_date.meta_value AS meet_end_date,
						meet_end_time.meta_value AS meet_end_time,
						'' AS drip_start_date,
						'' AS drip_start_time,
						'' AS drip_from_start,
						'' AS drip_start_days
					{$common_from}
					INNER JOIN {$postmeta_table} meet_start_date ON meet_start_date.post_id = materials.post_id AND meet_start_date.meta_key = 'stm_gma_start_date'
					LEFT JOIN {$postmeta_table} meet_start_time ON meet_start_time.post_id = materials.post_id AND meet_start_time.meta_key = 'stm_gma_start_time'
					LEFT JOIN {$postmeta_table} meet_end_date ON meet_end_date.post_id = materials.post_id AND meet_end_date.meta_key = 'stm_gma_end_date'
					LEFT JOIN {$postmeta_table} meet_end_time ON meet_end_time.post_id = materials.post_id AND meet_end_time.meta_key = 'stm_gma_end_time'
					{$common_where}
						AND posts.post_type = 'stm-google-meets'
						AND {$meet_window}
					ORDER BY sections.course_id ASC, materials.`order` ASC
				",
				'args'  => $meet_args,
			);
		}

		$stream_types = array();

		if ( $this->is_addon_enabled( Addons::LIVE_STREAMS ) ) {
			$stream_types[] = 'stream';
		}

		if ( $this->is_pro_plus_addon_enabled( Addons::ZOOM_CONFERENCE ) ) {
			$stream_types[] = 'zoom_conference';
		}

		if ( ! empty( $stream_types ) ) {
			$stream_args         = array_merge( $course_ids, $stream_types );
			$stream_placeholders = implode( ',', array_fill( 0, count( $stream_types ), '%s' ) );
			$stream_window       = $this->date_meta_window_clause( 'stream_start_date', $start, $end, $stream_args );
			$queries[]           = array(
				'query' => "
					SELECT
						{$common_select},
						type_meta.meta_value AS lesson_type,
						stream_start_date.meta_value AS stream_start_date,
						stream_start_time.meta_value AS stream_start_time,
						stream_end_date.meta_value AS stream_end_date,
						stream_end_time.meta_value AS stream_end_time,
						'' AS zoom_date,
						'' AS zoom_time,
						'' AS zoom_duration,
						'' AS meet_start_date,
						'' AS meet_start_time,
						'' AS meet_end_date,
						'' AS meet_end_time,
						'' AS drip_start_date,
						'' AS drip_start_time,
						'' AS drip_from_start,
						'' AS drip_start_days
					{$common_from}
					INNER JOIN {$postmeta_table} type_meta ON type_meta.post_id = materials.post_id AND type_meta.meta_key = 'type'
					INNER JOIN {$postmeta_table} stream_start_date ON stream_start_date.post_id = materials.post_id AND stream_start_date.meta_key = 'stream_start_date'
					LEFT JOIN {$postmeta_table} stream_start_time ON stream_start_time.post_id = materials.post_id AND stream_start_time.meta_key = 'stream_start_time'
					LEFT JOIN {$postmeta_table} stream_end_date ON stream_end_date.post_id = materials.post_id AND stream_end_date.meta_key = 'stream_end_date'
					LEFT JOIN {$postmeta_table} stream_end_time ON stream_end_time.post_id = materials.post_id AND stream_end_time.meta_key = 'stream_end_time'
					{$common_where}
						AND type_meta.meta_value IN ({$stream_placeholders})
						AND {$stream_window}
					ORDER BY sections.course_id ASC, materials.`order` ASC
				",
				'args'  => $stream_args,
			);
		}

		$drip_args   = array_merge( $course_ids, $excluded_drip_post_types );
		$drip_window = $this->date_meta_window_clause( 'drip_start_date', $start, $end, $drip_args );
		$queries[]   = array(
			'query' => "
				SELECT
					{$common_select},
					type_meta.meta_value AS lesson_type,
					'' AS stream_start_date,
					'' AS stream_start_time,
					'' AS stream_end_date,
					'' AS stream_end_time,
					'' AS zoom_date,
					'' AS zoom_time,
					'' AS zoom_duration,
					'' AS meet_start_date,
					'' AS meet_start_time,
					'' AS meet_end_date,
					'' AS meet_end_time,
					drip_start_date.meta_value AS drip_start_date,
					drip_start_time.meta_value AS drip_start_time,
					'' AS drip_from_start,
					'' AS drip_start_days
				{$common_from}
				INNER JOIN {$postmeta_table} drip_start_date ON drip_start_date.post_id = materials.post_id AND drip_start_date.meta_key = 'lesson_start_date'
				LEFT JOIN {$postmeta_table} drip_start_time ON drip_start_time.post_id = materials.post_id AND drip_start_time.meta_key = 'lesson_start_time'
				LEFT JOIN {$postmeta_table} type_meta ON type_meta.post_id = materials.post_id AND type_meta.meta_key = 'type'
				{$common_where}
					AND posts.post_type NOT IN ({$excluded_drip_placeholders})
					AND (type_meta.meta_value IS NULL OR type_meta.meta_value NOT IN ('stream', 'zoom_conference'))
					AND {$drip_window}
				ORDER BY sections.course_id ASC, materials.`order` ASC
			",
			'args'  => $drip_args,
		);

		$from_start_args = array_merge( $course_ids, $excluded_drip_post_types );
		$queries[]       = array(
			'query' => "
				SELECT
					{$common_select},
					type_meta.meta_value AS lesson_type,
					'' AS stream_start_date,
					'' AS stream_start_time,
					'' AS stream_end_date,
					'' AS stream_end_time,
					'' AS zoom_date,
					'' AS zoom_time,
					'' AS zoom_duration,
					'' AS meet_start_date,
					'' AS meet_start_time,
					'' AS meet_end_date,
					'' AS meet_end_time,
					'' AS drip_start_date,
					'' AS drip_start_time,
					drip_from_start.meta_value AS drip_from_start,
					drip_start_days.meta_value AS drip_start_days
				{$common_from}
				INNER JOIN {$postmeta_table} drip_from_start ON drip_from_start.post_id = materials.post_id AND drip_from_start.meta_key = 'lesson_lock_from_start'
				INNER JOIN {$postmeta_table} drip_start_days ON drip_start_days.post_id = materials.post_id AND drip_start_days.meta_key = 'lesson_lock_start_days'
				LEFT JOIN {$postmeta_table} type_meta ON type_meta.post_id = materials.post_id AND type_meta.meta_key = 'type'
				{$common_where}
					AND posts.post_type NOT IN ({$excluded_drip_placeholders})
					AND (type_meta.meta_value IS NULL OR type_meta.meta_value NOT IN ('stream', 'zoom_conference'))
				ORDER BY sections.course_id ASC, materials.`order` ASC
			",
			'args'  => $from_start_args,
		);

		return $queries;
	}

	private function get_curriculum_events_from_query( string $query, array $query_args, array $courses, int $start, int $end ): array {
		$rows   = $this->db->get_results( $this->db->prepare( $query, $query_args ), ARRAY_A );
		$events = array();

		foreach ( (array) $rows as $row ) {
			$item_id   = absint( $row['item_id'] ?? 0 );
			$course_id = absint( $row['course_id'] ?? 0 );

			if ( ! $item_id || empty( $courses[ $course_id ] ) ) {
				continue;
			}

			$event = $this->build_material_event( $row, $courses[ $course_id ], $start, $end );

			if ( ! empty( $event ) ) {
				$events[] = $event;
			}
		}

		return $events;
	}

	private function date_meta_window_clause( string $alias, int $start, int $end, array &$query_args ): string {
		$query_args[] = $start;
		$query_args[] = $end;
		$query_args[] = $start * 1000;
		$query_args[] = $end * 1000;
		$query_args[] = $this->compact_date_meta_from_timestamp( $start );
		$query_args[] = $this->compact_date_meta_from_timestamp( $end );
		$query_args[] = $this->date_meta_from_timestamp( $start );
		$query_args[] = $this->date_meta_from_timestamp( $end );

		return "(
			(
				{$alias}.meta_value REGEXP '^[0-9]+$'
				AND (
					(CAST({$alias}.meta_value AS UNSIGNED) >= %d AND CAST({$alias}.meta_value AS UNSIGNED) < %d)
					OR (CAST({$alias}.meta_value AS UNSIGNED) >= %d AND CAST({$alias}.meta_value AS UNSIGNED) < %d)
					OR (CAST({$alias}.meta_value AS UNSIGNED) >= %d AND CAST({$alias}.meta_value AS UNSIGNED) < %d)
				)
			)
			OR ({$alias}.meta_value >= %s AND {$alias}.meta_value < %s)
		)";
	}

	private function build_material_event( array $row, array $course, int $start, int $end ): ?array {
		$item_id    = absint( $row['item_id'] ?? 0 );
		$course_id  = absint( $course['id'] ?? 0 );
		$post_type  = (string) ( $row['real_post_type'] ?? $row['post_type'] ?? '' );
		$type       = (string) ( $row['lesson_type'] ?? '' );
		$timestamp     = 0;
		$event_type    = 'available';
		$location      = '';
		$duration      = '';
		$end_timestamp = 0;
		$title         = ! empty( $row['post_title'] ) ? (string) $row['post_title'] : get_the_title( $item_id );

		if ( in_array( $post_type, array( 'stm-zoom', 'ms-zoom', 'stm-zoom-webinar' ), true ) ) {
			$timestamp        = $this->get_zoom_start_time( $item_id, $row );
			$duration_minutes = absint( $row['zoom_duration'] ?? 0 );
			$duration         = $this->duration_label( $duration_minutes );
			$end_timestamp    = $duration_minutes > 0 ? $timestamp + ( $duration_minutes * MINUTE_IN_SECONDS ) : 0;
			$event_type       = 'zoom';
			$location         = __( 'Zoom meeting', 'masterstudy-lms-learning-management-system-pro' );
		} elseif ( 'stm-google-meets' === $post_type ) {
			$timestamp     = $this->get_google_meet_start_time( $item_id, $row );
			$end_timestamp = $this->date_meta_to_timestamp( $row['meet_end_date'] ?? '', $row['meet_end_time'] ?? '' );
			$duration      = $this->timestamp_duration_label(
				$timestamp,
				$end_timestamp
			);
			$event_type    = 'meet';
			$location      = __( 'Google Meet', 'masterstudy-lms-learning-management-system-pro' );
		} elseif ( 'zoom_conference' === $type ) {
			$timestamp     = $this->date_meta_to_timestamp( $row['stream_start_date'] ?? '', $row['stream_start_time'] ?? '' );
			$end_timestamp = $this->date_meta_to_timestamp( $row['stream_end_date'] ?? '', $row['stream_end_time'] ?? '' );
			$duration      = $this->timestamp_duration_label(
				$timestamp,
				$end_timestamp
			);
			$event_type    = 'zoom';
			$location      = __( 'Zoom meeting', 'masterstudy-lms-learning-management-system-pro' );
		} elseif ( 'stream' === $type ) {
			$timestamp     = $this->get_stream_start_time( $item_id, $row );
			$end_timestamp = $this->date_meta_to_timestamp( $row['stream_end_date'] ?? '', $row['stream_end_time'] ?? '' );
			$duration      = $this->timestamp_duration_label(
				$timestamp,
				$end_timestamp
			);
			$event_type    = 'stream';
			$location      = __( 'Live stream', 'masterstudy-lms-learning-management-system-pro' );
		} else {
			$timestamp = $this->get_drip_start_time( $item_id, $course_id, $row, absint( $course['start_time'] ?? 0 ) );

			if ( 'stm-quizzes' === $post_type ) {
				$event_type = 'quiz';
			}
		}

		if ( ! $timestamp || $timestamp < $start || $timestamp >= $end ) {
			return null;
		}

		return $this->event(
			array(
				'id'            => "{$event_type}:{$course_id}:{$item_id}:{$timestamp}",
				'title'         => $title,
				'type'          => $event_type,
				'timestamp'     => $timestamp,
				'duration'      => $duration,
				'end_timestamp' => $end_timestamp,
				'course'        => $course['title'],
				'location'      => $location,
				'url'           => class_exists( 'STM_LMS_Lesson' ) ? \STM_LMS_Lesson::get_lesson_url( $course_id, $item_id ) : get_permalink( $item_id ),
				'course_id'     => $course_id,
				'item_id'       => $item_id,
				'source'        => $event_type,
			)
		);
	}

	private function get_assignment_deadline_events( array $courses, int $start, int $end ): array {
		if ( ! $this->is_addon_enabled( Addons::ASSIGNMENTS ) ) {
			return array();
		}

		if (
			! function_exists( 'stm_lms_user_assignments_name' )
			|| ! function_exists( 'stm_lms_user_assignments_times_name' )
		) {
			return array();
		}

		$user_assignments_table = stm_lms_user_assignments_name( $this->db );
		$assignment_times_table = stm_lms_user_assignments_times_name( $this->db );

		if ( ! $this->table_exists( $user_assignments_table ) || ! $this->table_exists( $assignment_times_table ) ) {
			return array();
		}

		$course_ids          = array_map( 'absint', array_keys( $courses ) );
		$course_placeholders = implode( ',', array_fill( 0, count( $course_ids ), '%d' ) );
		$query_args          = array_merge(
			array(
				$this->user_id,
				$this->mysql_from_timestamp( $start ),
				$this->mysql_from_timestamp( $end ),
			),
			$course_ids
		);
		$query               = "
			SELECT
				assignments.course_id,
				assignments.assignment_id AS item_id,
				assignments.user_assignment_id,
				times.end_time,
				posts.post_title
			FROM {$assignment_times_table} times
			INNER JOIN {$user_assignments_table} assignments
				ON assignments.user_assignment_id = times.assignment_id
				AND assignments.user_id = times.user_id
			INNER JOIN {$this->db->posts} posts ON posts.ID = assignments.assignment_id
			WHERE times.user_id = %d
				AND times.end_time >= %s
				AND times.end_time < %s
				AND assignments.course_id IN ({$course_placeholders})
				AND posts.post_status NOT IN ('trash', 'auto-draft')
			ORDER BY times.end_time ASC
		";
		$rows                = $this->db->get_results( $this->db->prepare( $query, $query_args ), ARRAY_A );
		$events              = array();

		foreach ( (array) $rows as $row ) {
			$course_id = absint( $row['course_id'] ?? 0 );
			$item_id   = absint( $row['item_id'] ?? 0 );
			$timestamp = $this->mysql_to_timestamp( (string) ( $row['end_time'] ?? '' ) );

			if ( ! $timestamp || empty( $courses[ $course_id ] ) ) {
				continue;
			}

			$events[] = $this->event(
				array(
					'id'        => "deadline:{$course_id}:{$item_id}:{$timestamp}",
					'title'     => sprintf(
						/* translators: %s: assignment title */
						__( 'Assignment: %s', 'masterstudy-lms-learning-management-system-pro' ),
						! empty( $row['post_title'] ) ? (string) $row['post_title'] : get_the_title( $item_id )
					),
					'type'      => 'deadline',
					'timestamp' => $timestamp,
					'course'    => $courses[ $course_id ]['title'],
					'url'       => class_exists( 'STM_LMS_Lesson' ) ? \STM_LMS_Lesson::get_lesson_url( $course_id, $item_id ) : get_permalink( $item_id ),
					'course_id' => $course_id,
					'item_id'   => $item_id,
					'source'    => 'assignment_deadline',
				)
			);
		}

		return $events;
	}

	private function get_coming_soon_events( array $courses, int $start, int $end ): array {
		if ( ! $this->is_pro_plus_addon_enabled( Addons::COOMING_SOON ) ) {
			return array();
		}

		if ( ! function_exists( 'masterstudy_lms_coming_soon_start_time' ) ) {
			return array();
		}

		$events = array();

		update_meta_cache( 'post', array_map( 'absint', array_keys( $courses ) ) );

		foreach ( $courses as $course ) {
			$course_id = absint( $course['id'] ?? 0 );

			if ( ! $course_id || ! get_post_meta( $course_id, 'coming_soon_date', true ) ) {
				continue;
			}

			$timestamp = absint( masterstudy_lms_coming_soon_start_time( $course_id ) );

			if ( ! $timestamp || $timestamp < $start || $timestamp >= $end ) {
				continue;
			}

			$events[] = $this->event(
				array(
					'id'        => "coming_soon:{$course_id}:{$timestamp}",
					'title'     => sprintf(
						/* translators: %s: course title */
						__( 'New course: %s', 'masterstudy-lms-learning-management-system-pro' ),
						$course['title']
					),
					'type'      => 'available',
					'timestamp' => $timestamp,
					'course'    => $course['title'],
					'url'       => get_permalink( $course_id ),
					'course_id' => $course_id,
					'item_id'   => 0,
					'source'    => 'coming_soon',
				)
			);
		}

		return $events;
	}

	private function get_google_meet_start_time( int $item_id, array $row ): int {
		$timestamp = $this->date_meta_to_timestamp( $row['meet_start_date'] ?? '', $row['meet_start_time'] ?? '' );

		if ( $timestamp ) {
			return $timestamp;
		}

		if ( function_exists( 'masterstudy_lms_google_meet_start_time' ) ) {
			try {
				$timestamp = absint( masterstudy_lms_google_meet_start_time( $item_id ) );

				if ( $timestamp ) {
					return $timestamp;
				}
			} catch ( \Throwable $exception ) {
				return 0;
			}
		}

		return 0;
	}

	private function get_zoom_start_time( int $item_id, array $row ): int {
		$timestamp = $this->date_meta_to_timestamp( $row['zoom_date'] ?? '', $row['zoom_time'] ?? '' );

		if ( $timestamp ) {
			return $timestamp;
		}

		if ( class_exists( 'MSLMS_StmZoom' ) ) {
			$data = \MSLMS_StmZoom::meeting_time_data( $item_id );

			if ( is_array( $data ) && ! empty( $data['meeting_date'] ) ) {
				return absint( $data['meeting_date'] );
			}
		}

		return 0;
	}

	private function get_stream_start_time( int $item_id, array $row ): int {
		$timestamp = $this->date_meta_to_timestamp( $row['stream_start_date'] ?? '', $row['stream_start_time'] ?? '' );

		if ( $timestamp ) {
			return $timestamp;
		}

		return class_exists( 'STM_LMS_Live_Streams' ) ? absint( \STM_LMS_Live_Streams::stream_start_time( $item_id ) ) : 0;
	}

	private function get_drip_start_time( int $item_id, int $course_id, array $row, int $course_start_time ): int {
		if ( ! empty( $row['drip_from_start'] ) && ! empty( $row['drip_start_days'] ) && $course_start_time ) {
			return strtotime( '+' . absint( $row['drip_start_days'] ) . ' days', $course_start_time );
		}

		$timestamp = $this->date_meta_to_timestamp( $row['drip_start_date'] ?? '', $row['drip_start_time'] ?? '' );

		if ( $timestamp ) {
			return $timestamp;
		}

		if ( class_exists( 'STM_LMS_Sequential_Drip_Content' ) ) {
			return absint( \STM_LMS_Sequential_Drip_Content::lesson_start_time( $item_id, $course_id ) );
		}

		return 0;
	}

	private function event( array $event ): array {
		$timestamp     = absint( $event['timestamp'] ?? 0 );
		$end_timestamp = absint( $event['end_timestamp'] ?? 0 );
		$time_format   = (string) get_option( 'time_format', 'g:i a' );
		$is_past       = $this->is_past_event( $timestamp, (string) ( $event['duration'] ?? '' ), $end_timestamp );

		$event['title']     = html_entity_decode( wp_strip_all_tags( (string) ( $event['title'] ?? '' ) ), ENT_QUOTES, get_bloginfo( 'charset' ) );
		$event['type']      = sanitize_key( (string) ( $event['type'] ?? 'available' ) );
		$event['timestamp'] = $timestamp;
		$event['date']      = wp_date( 'Y-m-d', $timestamp, $this->timezone );
		$event['time']      = wp_date( 'H:i', $timestamp, $this->timezone );
		$event['formatted_time'] = wp_date(
			! empty( $time_format ) ? $time_format : 'g:i a',
			$timestamp,
			$this->timezone
		);
		$event['duration']       = (string) ( $event['duration'] ?? '' );
		$event['course']         = html_entity_decode( wp_strip_all_tags( (string) ( $event['course'] ?? '' ) ), ENT_QUOTES, get_bloginfo( 'charset' ) );
		$event['location']       = html_entity_decode( wp_strip_all_tags( (string) ( $event['location'] ?? '' ) ), ENT_QUOTES, get_bloginfo( 'charset' ) );
		$event['url']            = esc_url_raw( (string) ( $event['url'] ?? '' ) );
		$event['course_id']      = absint( $event['course_id'] ?? 0 );
		$event['item_id']        = absint( $event['item_id'] ?? 0 );
		$event['source']         = sanitize_key( (string) ( $event['source'] ?? '' ) );
		$event['status']         = $is_past ? 'past' : 'upcoming';
		$event['is_past']        = $is_past;

		unset( $event['end_timestamp'] );

		return $event;
	}

	private function status_counts( array $events ): array {
		$counts = array(
			'upcoming' => 0,
			'past'     => 0,
		);

		foreach ( $events as $event ) {
			if ( ! empty( $event['is_past'] ) ) {
				++$counts['past'];
				continue;
			}

			++$counts['upcoming'];
		}

		return $counts;
	}

	private function filter_events_by_status( array $events, string $status ): array {
		if ( ! in_array( $status, array( 'upcoming', 'past' ), true ) ) {
			return $events;
		}

		return array_values(
			array_filter(
				$events,
				static function ( array $event ) use ( $status ): bool {
					return ( $event['status'] ?? 'upcoming' ) === $status;
				}
			)
		);
	}

	private function sort_events_by_status( array $events, string $status ): array {
		if ( 'past' !== $status ) {
			return $events;
		}

		usort(
			$events,
			static function ( array $first, array $second ): int {
				return $second['timestamp'] <=> $first['timestamp'];
			}
		);

		return $events;
	}

	private function sort_day_events( array $events ): array {
		usort(
			$events,
			static function ( array $first, array $second ): int {
				$past_comparison = (int) ! empty( $first['is_past'] ) <=> (int) ! empty( $second['is_past'] );

				return 0 !== $past_comparison
					? $past_comparison
					: $first['timestamp'] <=> $second['timestamp'];
			}
		);

		return $events;
	}

	private function is_past_event( int $timestamp, string $duration, int $end_timestamp = 0 ): bool {
		if ( ! $timestamp ) {
			return false;
		}

		if ( $end_timestamp > $timestamp ) {
			return $end_timestamp < $this->now;
		}

		$end_timestamp = $timestamp + $this->duration_seconds( $duration );

		return $end_timestamp < $this->now;
	}

	private function duration_seconds( string $duration ): int {
		if ( '' === $duration ) {
			return 0;
		}

		$pattern = '/(\d+)\s*(min|mins|minute|minutes|hour|hours|hr|hrs|day|days|week|weeks|wk|wks|h|m|d|w)?/i';

		if ( ! preg_match( $pattern, $duration, $matches ) ) {
			return 0;
		}

		$value = absint( $matches[1] ?? 0 );
		$unit  = strtolower( (string) ( $matches[2] ?? 'min' ) );

		if ( in_array( $unit, array( 'week', 'weeks', 'wk', 'wks', 'w' ), true ) ) {
			return $value * WEEK_IN_SECONDS;
		}

		if ( in_array( $unit, array( 'day', 'days', 'd' ), true ) ) {
			return $value * DAY_IN_SECONDS;
		}

		if ( in_array( $unit, array( 'hour', 'hours', 'hr', 'hrs', 'h' ), true ) ) {
			return $value * HOUR_IN_SECONDS;
		}

		return $value * MINUTE_IN_SECONDS;
	}

	private function filter_events_by_type( array $events, string $type ): array {
		if ( '' === $type ) {
			return $events;
		}

		return array_values(
			array_filter(
				$events,
				static function ( array $event ) use ( $type ): bool {
					return ( $event['type'] ?? '' ) === $type;
				}
			)
		);
	}

	private function filter_events( array $events, string $search ): array {
		if ( '' === $search ) {
			return $events;
		}

		$needle = function_exists( 'mb_strtolower' ) ? mb_strtolower( $search ) : strtolower( $search );

		return array_values(
			array_filter(
				$events,
				static function ( array $event ) use ( $needle ): bool {
					$haystack = implode(
						' ',
						array_filter(
							array(
								$event['title'] ?? '',
								$event['course'] ?? '',
								$event['location'] ?? '',
								$event['duration'] ?? '',
								$event['type'] ?? '',
								$event['source'] ?? '',
							)
						)
					);
					$haystack = function_exists( 'mb_strtolower' ) ? mb_strtolower( $haystack ) : strtolower( $haystack );

					return false !== strpos( $haystack, $needle );
				}
			)
		);
	}

	private function paginate( array $events, int $page, int $per_page ): array {
		$total       = count( $events );
		$total_pages = $per_page > 0 ? (int) ceil( $total / $per_page ) : 0;
		$offset      = ( $page - 1 ) * $per_page;

		return array(
			'events'     => array_slice( $events, $offset, $per_page ),
			'pagination' => array(
				'page'        => $page,
				'per_page'    => $per_page,
				'total'       => $total,
				'total_pages' => $total_pages,
				'has_more'    => $page < $total_pages,
			),
		);
	}

	private function date_meta_to_timestamp( $date, $time = '' ): int {
		if ( empty( $date ) ) {
			return 0;
		}

		if ( is_numeric( $date ) && 8 === strlen( (string) $date ) ) {
			$parsed = date_create_immutable_from_format( 'Ymd H:i:s', trim( "{$date} 00:00:00" ), $this->timezone );

			if ( ! $parsed ) {
				return 0;
			}

			$timestamp = $parsed->getTimestamp();
		} elseif ( is_numeric( $date ) ) {
			$seconds = (int) $date;

			if ( $seconds > 9999999999 ) {
				$seconds = (int) floor( $seconds / 1000 );
			}

			$timestamp = strtotime( 'today', $seconds ) - ( (float) get_option( 'gmt_offset' ) * HOUR_IN_SECONDS );
		} else {
			$date_value = trim( (string) $date );
			$parsed     = date_create_immutable_from_format( 'Y-m-d H:i:s', $date_value, $this->timezone );

			if ( ! $parsed ) {
				$parsed = date_create_immutable_from_format( 'Y-m-d H:i:s', "{$date_value} 00:00:00", $this->timezone );
			}

			if ( ! $parsed ) {
				$parsed = date_create_immutable_from_format( 'Ymd H:i:s', "{$date_value} 00:00:00", $this->timezone );
			}

			if ( ! $parsed ) {
				return 0;
			}

			$timestamp = $parsed->getTimestamp();
		}

		if ( ! empty( $time ) ) {
			$parts = explode( ':', (string) $time );

			if ( count( $parts ) >= 2 ) {
				$timestamp = strtotime( '+' . absint( $parts[0] ) . ' hours +' . absint( $parts[1] ) . ' minutes', $timestamp );
			}
		}

		return absint( $timestamp );
	}

	private function date_meta_from_timestamp( int $timestamp ): string {
		return wp_date( 'Y-m-d', $timestamp, $this->timezone );
	}

	private function compact_date_meta_from_timestamp( int $timestamp ): int {
		return absint( wp_date( 'Ymd', $timestamp, $this->timezone ) );
	}

	private function mysql_to_timestamp( string $date ): int {
		if ( '' === $date ) {
			return 0;
		}

		$parsed = DateTimeImmutable::createFromFormat( 'Y-m-d H:i:s', $date, $this->timezone );

		return $parsed ? $parsed->getTimestamp() : 0;
	}

	private function mysql_from_timestamp( int $timestamp ): string {
		return wp_date( 'Y-m-d H:i:s', $timestamp, $this->timezone );
	}

	private function timestamp_duration_label( int $start, int $end ): string {
		if ( ! $start || ! $end || $end <= $start ) {
			return '';
		}

		return $this->duration_label( (int) round( ( $end - $start ) / MINUTE_IN_SECONDS ) );
	}

	private function duration_label( int $minutes ): string {
		if ( $minutes <= 0 ) {
			return '';
		}

		if ( $minutes >= WEEK_IN_SECONDS / MINUTE_IN_SECONDS ) {
			$weeks = max( 1, (int) floor( $minutes / ( WEEK_IN_SECONDS / MINUTE_IN_SECONDS ) ) );

			return sprintf(
				/* translators: %d: duration in weeks */
				_n( '%d week', '%d weeks', $weeks, 'masterstudy-lms-learning-management-system-pro' ),
				$weeks
			);
		}

		if ( $minutes >= DAY_IN_SECONDS / MINUTE_IN_SECONDS ) {
			$days = max( 1, (int) floor( $minutes / ( DAY_IN_SECONDS / MINUTE_IN_SECONDS ) ) );

			return sprintf(
				/* translators: %d: duration in days */
				_n( '%d day', '%d days', $days, 'masterstudy-lms-learning-management-system-pro' ),
				$days
			);
		}

		if ( $minutes >= HOUR_IN_SECONDS / MINUTE_IN_SECONDS ) {
			$hours = max( 1, (int) floor( $minutes / ( HOUR_IN_SECONDS / MINUTE_IN_SECONDS ) ) );

			return sprintf(
				/* translators: %d: duration in hours */
				_n( '%d hour', '%d hours', $hours, 'masterstudy-lms-learning-management-system-pro' ),
				$hours
			);
		}

		return sprintf(
			/* translators: %d: duration in minutes */
			_n( '%d min', '%d min', $minutes, 'masterstudy-lms-learning-management-system-pro' ),
			$minutes
		);
	}

	private function is_addon_enabled( string $addon ): bool {
		return function_exists( 'is_ms_lms_addon_enabled' ) && is_ms_lms_addon_enabled( $addon );
	}

	private function is_pro_plus_addon_enabled( string $addon ): bool {
		return $this->is_pro_plus() && $this->is_addon_enabled( $addon );
	}

	private function is_pro_plus(): bool {
		return class_exists( 'STM_LMS_Helpers' )
			&& method_exists( 'STM_LMS_Helpers', 'is_pro_plus' )
			&& \STM_LMS_Helpers::is_pro_plus();
	}

	private function table_exists( string $table ): bool {
		return $table === $this->db->get_var( $this->db->prepare( 'SHOW TABLES LIKE %s', $table ) );
	}
}
