<?php

namespace MasterStudy\Lms\Pro\AddonsPlus\Notifications\Services\Push;

final class ServiceWorker {
	public static function url(): string {
		return home_url( '/masterstudy-notifications-push-worker.js' );
	}

	public static function register(): void {
		add_action( 'template_redirect', array( __CLASS__, 'maybe_serve' ), 0 );
	}

	public static function maybe_serve(): void {
		$request_path = '';

		if ( isset( $_SERVER['REQUEST_URI'] ) ) {
			$request_path = (string) wp_parse_url( esc_url_raw( wp_unslash( $_SERVER['REQUEST_URI'] ) ), PHP_URL_PATH );
		}

		if ( '/masterstudy-notifications-push-worker.js' !== $request_path ) {
			return;
		}

		status_header( 200 );
		nocache_headers();
		header( 'Content-Type: application/javascript; charset=utf-8' );
		header( 'Service-Worker-Allowed: /' );

		$worker = __DIR__ . '/../../Assets/js/notifications-push-worker.js';

		if ( is_readable( $worker ) ) {
			// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped, WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- Static service worker JS must be served unescaped.
			echo file_get_contents( $worker );
		}

		exit;
	}
}
