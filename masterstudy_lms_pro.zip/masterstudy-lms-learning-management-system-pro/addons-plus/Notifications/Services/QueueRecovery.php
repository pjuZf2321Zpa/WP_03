<?php

namespace MasterStudy\Lms\Pro\AddonsPlus\Notifications\Services;

use MasterStudy\Lms\Pro\AddonsPlus\Notifications\Repositories\DispatchQueueRepository;
use MasterStudy\Lms\Pro\AddonsPlus\Notifications\Repositories\PushQueueRepository;

final class QueueRecovery {
	public static function ensure_scheduled(): void {
		if ( wp_next_scheduled( 'masterstudy_notifications_recover_queues' ) ) {
			return;
		}

		wp_schedule_event( time() + 15 * MINUTE_IN_SECONDS, 'hourly', 'masterstudy_notifications_recover_queues' );
	}

	public static function process(): void {
		try {
			if ( ! self::is_available() ) {
				return;
			}

			$push_queue     = new PushQueueRepository();
			$dispatch_queue = new DispatchQueueRepository();

			$push_queue->recover_stale_processing();
			$dispatch_queue->recover_stale_processing();

			if ( $push_queue->has_pending() && ! wp_next_scheduled( 'masterstudy_notifications_process_push_queue' ) ) {
				wp_schedule_single_event( time() + 10, 'masterstudy_notifications_process_push_queue' );
			}

			if ( $dispatch_queue->has_pending() && ! wp_next_scheduled( 'masterstudy_notifications_process_recipient_fanout' ) ) {
				wp_schedule_single_event( time() + 10, 'masterstudy_notifications_process_recipient_fanout' );
			}
		} catch ( \Throwable $error ) {
			return;
		}
	}

	private static function is_available(): bool {
		return function_exists( 'masterstudy_lms_is_notifications_addon_available' )
			&& masterstudy_lms_is_notifications_addon_available();
	}
}
