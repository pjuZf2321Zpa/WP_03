<?php
/**
 * RSVP V2 Constants for Event Tickets Plus.
 *
 * Holds constants shared across RSVP V2 classes such as meta keys and option values.
 *
 * @since 6.11.0
 *
 * @package TEC\Tickets_Plus\RSVP\V2
 */

namespace TEC\Tickets_Plus\RSVP\V2;

/**
 * Class Constants
 *
 * @since 6.11.0
 *
 * @package TEC\Tickets_Plus\RSVP\V2
 */
class Constants {
	/**
	 * Meta key to hold if the Post has RSVP Attendees List shown.
	 *
	 * @since 6.11.0
	 *
	 * @var string
	 */
	public const SHOW_RSVP_META_KEY = '_tec_show_attendees_list_rsvp';
}
