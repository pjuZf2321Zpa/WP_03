<?php
/**
 * Blog post bookmark type.
 *
 * Registers `post` with Platform's generic bookmark engine. The slug is
 * deliberately identical to the one the BuddyBoss App plugin uses, so rows
 * mirror between the two stores with no translation.
 *
 * @package BuddyBossPro
 *
 * @since 3.1.0
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

/**
 * Blog post bookmark type.
 *
 * @since 3.1.0
 */
class BB_Blog_Bookmark_Type extends BB_Bookmark_Type {

	/**
	 * Register the `post` bookmark type.
	 *
	 * @since 3.1.0
	 *
	 * @return void
	 */
	public function setup() {
		$this->register_type(
			'post',
			array(
				'label'          => array(
					'singular' => __( 'Post', 'buddyboss-pro' ),
					'plural'   => __( 'Posts', 'buddyboss-pro' ),
				),
				'items_callback' => array( $this, 'items_callback' ),
			)
		);
	}

	/**
	 * Hydrate bookmark rows with their post data.
	 *
	 * An item that no longer exists, or is no longer published, is marked
	 * `item_available = false` rather than dropped — the row still belongs to
	 * the user and they must be able to remove it.
	 *
	 * @since 3.1.0
	 *
	 * @param array $items Bookmark objects.
	 *
	 * @return array Hydrated bookmark objects.
	 */
	public function items_callback( $items ) {
		if ( empty( $items ) ) {
			return $items;
		}

		foreach ( $items as $key => $item ) {
			if ( empty( $item->item_id ) ) {
				continue;
			}

			$post = get_post( (int) $item->item_id );

			if ( empty( $post ) || is_wp_error( $post ) || 'publish' !== $post->post_status
				|| ! current_user_can( 'read_post', (int) $item->item_id ) || post_password_required( $post ) ) {
				$item->item_available      = false;
				$item->item_title          = __( 'Deleted post', 'buddyboss-pro' );
				$item->item_link           = '';
				$item->item_featured_image = '';
				$item->item_author         = '';
				$item->item_author_link    = '';
				$item->item_date           = '';

				$items[ $key ] = $item;

				continue;
			}

			$author_id = (int) $post->post_author;

			$item->item_available      = true;
			$item->item_title          = get_the_title( $post );
			$item->item_link           = get_permalink( $post );
			$bb_featured_image         = get_the_post_thumbnail_url( $post, 'medium' );
			$item->item_featured_image = ! empty( $bb_featured_image ) ? $bb_featured_image : '';
			$item->item_author         = function_exists( 'bp_core_get_user_displayname' ) ? bp_core_get_user_displayname( $author_id ) : get_the_author_meta( 'display_name', $author_id );
			$item->item_author_link    = function_exists( 'bp_core_get_user_domain' ) ? bp_core_get_user_domain( $author_id ) : get_author_posts_url( $author_id );
			$item->item_date           = get_the_date( '', $post );

			$items[ $key ] = $item;
		}

		return $items;
	}
}
