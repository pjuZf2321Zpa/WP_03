<?php

namespace FluentCartPro\App\Hooks\Handlers\BlockEditors\PdfBlocks;

use FluentCart\App\Hooks\Handlers\BlockEditors\BlockEditor;

class ReceiptAddressesBlockEditor extends BlockEditor
{
    use \FluentCartPro\App\Contracts\CanEnqueue;

    protected static string $editorName = 'receipt-addresses';

    public function getScripts(): array
    {
        return [
            [
                'source'       => 'admin/BlockEditor/PdfBlocks/ReceiptAddressesBlockEditor.jsx',
                'dependencies' => ['wp-blocks', 'wp-components', 'wp-block-editor']
            ]
        ];
    }

    public function getStyles(): array
    {
        return [];
    }

    public function localizeData(): array
    {
        return [
            $this->getLocalizationKey() => [
                'slug'        => $this->slugPrefix,
                'name'        => static::getEditorName(),
                'title'       => __('Receipt Addresses', 'fluent-cart-pro'),
                'description' => __('Two-column FROM / BILL TO address block for PDF receipts.', 'fluent-cart-pro'),
            ],
            'fluent_cart_block_translation' => \FluentCart\App\Services\Translations\TransStrings::blockStrings(),
        ];
    }

    public function blockAttributes(): array
    {
        return [
            'fromLabel'    => ['type' => 'string',  'default' => 'FROM'],
            'billingLabel' => ['type' => 'string',  'default' => 'BILL TO'],
            'labelColor'   => ['type' => 'string',  'default' => '#666666'],
            'nameColor'    => ['type' => 'string',  'default' => '#111111'],
            'textColor'    => ['type' => 'string',  'default' => '#666666'],
            'showFrom'     => ['type' => 'boolean', 'default' => true],
        ];
    }

    public function supports(): array
    {
        return [
            'html'    => false,
            'align'   => false,
            'spacing' => ['margin' => true, 'padding' => true],
        ];
    }

    public function render(array $attrs, $block = null, $content = ''): string
    {
        $fromLabel    = esc_html($attrs['fromLabel']    ?? 'FROM');
        $billingLabel = esc_html($attrs['billingLabel'] ?? 'BILL TO');
        $labelColor   = esc_attr($attrs['labelColor']   ?? '#666666');
        $nameColor    = esc_attr($attrs['nameColor']    ?? '#111111');
        $textColor    = esc_attr($attrs['textColor']    ?? '#666666');
        $showFrom     = $attrs['showFrom'] ?? true;

        $labelStyle = 'font-size:9px;font-weight:bold;letter-spacing:1px;color:' . $labelColor . ';margin-bottom:6px;';
        $nameStyle  = 'font-size:12px;font-weight:bold;color:' . $nameColor . ';margin-bottom:2px;';
        $lineStyle  = 'font-size:11px;color:' . $textColor . ';line-height:1.6;';

        $html = '<table width="100%" cellspacing="0" cellpadding="0" border="0"'
              . ' style="margin-top:20px;margin-bottom:24px;">'
              . '<tr>';

        if ($showFrom) {
            $html .= '<td style="width:50%;vertical-align:top;padding-right:16px;">'
                   . '<div style="' . $labelStyle . '">' . $fromLabel . '</div>'
                   . '<div style="' . $nameStyle  . '">{{order.store_seller_name}}</div>'
                   . '<div style="' . $lineStyle  . '">{{settings.store_address}}</div>'
                   . '<div style="' . $lineStyle  . '">{{settings.store_city}}, {{settings.store_state}} {{settings.store_postcode}}</div>'
                   . '<div style="' . $lineStyle  . '">{{settings.store_country}}</div>'
                   . '<div style="' . $lineStyle  . 'font-weight:bold;margin-top:4px;">{{order.store_seller_vat_display}}</div>'
                   . '<div style="' . $lineStyle  . '">{{order.store_legal_registration_display}}</div>'
                   . '<div style="' . $lineStyle  . '">{{order.store_tax_display}}</div>'
                   . '</td>';
        }

        $html .= '<td style="width:50%;vertical-align:top;padding-left:' . ($showFrom ? '16' : '0') . 'px;">'
               . '<div style="' . $labelStyle . '">' . $billingLabel . '</div>'
               . '<div style="' . $nameStyle  . '">{{order.billing.full_name}}</div>'
               . '<div style="' . $lineStyle  . '">{{order.buyer_company_name}}</div>'
               . '<div style="' . $lineStyle  . '">{{order.billing.email}}</div>'
               . '<div style="' . $lineStyle  . '">{{order.billing.address_1}}</div>'
               . '<div style="' . $lineStyle  . '">{{order.billing.city}}, {{order.billing.state}} {{order.billing.postcode}}</div>'
               . '<div style="' . $lineStyle  . '">{{order.billing.country}}</div>'
               . '<div style="' . $lineStyle  . 'font-weight:bold;margin-top:4px;">{{order.buyer_vat_display}}</div>'
               . '<div style="' . $lineStyle  . '">{{order.buyer_legal_registration_id}}</div>'
               . '<div style="' . $lineStyle  . '">{{order.buyer_reverse_charge_declaration}}</div>'
               . '</td>'
               . '</tr>'
               . '</table>';

        return $html;
    }
}
