<?php

namespace FluentCartPro\App\Modules\DynamicPricing\Conditions\Options;

use FluentCart\App\Models\Customer;
use FluentCart\App\Services\Filter\CustomerFilter;
use FluentCart\App\Services\Permission\PermissionManager;
use FluentCart\Framework\Support\Arr;
use FluentCartPro\App\Modules\DynamicPricing\Conditions\ConditionRegistry;

/**
 * Customers for the condition builder's remote select.
 *
 * @package FluentCartPro\App\Modules\DynamicPricing
 *
 * @version 1.0.0
 */
class CustomerOptions extends OptionSource
{
    /**
     * The `data_key` a condition attribute names to reach this list.
     *
     * @var string
     */
    protected $key = 'dynamic_pricing_customers';

    /**
     * Customers as flat `{value, label}` options.
     *
     * CustomerFilter parses `search`, `include_ids` and `limit` out of the args
     * the controller builds, so type-to-search and re-showing an already saved
     * selection both work without anything further here.
     *
     * @param array $options
     * @param array $args
     * @return array
     */
    public function options($options, $args)
    {
        $includeIds = array_filter(array_map('intval', (array)Arr::get($args, 'include_ids', [])));

        /*
         * Remove duplicate IDs and limit the list to the maximum number of values
         * allowed for a select condition. This keeps the query and response size
         * bounded while allowing the full range of valid saved selections.
         */
        $includeIds = array_slice(array_unique($includeIds), 0, ConditionRegistry::MAX_SELECT_VALUES);

        /*
         * Normalised before the filter reads it. The controller sends an empty
         * string when the parameter is absent, which BaseFilter explodes into
         * [''] — non-empty, so it then requires `id IN ('')` alongside the
         * search and every search comes back with nothing.
         */
        $args['include_ids'] = $includeIds;

        $args['limit'] = $this->boundedLimit(Arr::get($args, 'limit'));

        $customers = CustomerFilter::make($args)->get()->map(function ($customer) {
            return $this->toOption($customer);
        })->toArray();

        return $this->withPinned($customers, $includeIds);
    }

    /**
     * Both bars, not either: the data is the customer list, and the reason this
     * key exists at all is the pricing rule editor.
     *
     * @param bool $hasPermission
     * @return bool
     */
    public function canRead($hasPermission)
    {
        return PermissionManager::hasPermission('customers/view')
            && PermissionManager::hasPermission('dynamic_pricing/view');
    }

    /**
     * Name on the first line, email under it.
     *
     * Neither identifies a customer on its own — names repeat, and an email
     * alone is hard to scan — so both are sent and the picker stacks them. They
     * travel as separate fields rather than one joined string because the
     * selected row shows only `label`, and a chip reading
     * "Alex Smith (alex@example.com)" is more than it needs.
     *
     * A customer created by a checkout that collected no name has only an
     * email, which then becomes the label with nothing beneath it.
     *
     * @param Customer $customer
     * @return array
     */
    protected function toOption($customer): array
    {
        $name = trim((string)$customer->full_name);
        $email = (string)$customer->email;

        return [
            'value'       => (int)$customer->id,
            'label'       => $name ?: $email,
            'description' => $name ? $email : '',
        ];
    }

    /**
     * Puts back any already-selected customer the page of results does not
     * contain.
     *
     * include_ids is meant to guarantee those rows, but BaseFilter widens the
     * query to `OR id IS NOT NULL` when there is no search term, so the limit
     * trims them off again exactly as if the ids had never been sent. A rule
     * saved against a customer far down the list would then reopen showing a
     * bare id instead of a name.
     *
     * @param array $customers
     * @param array $includeIds
     * @return array
     */
    protected function withPinned($customers, $includeIds)
    {
        if (!$includeIds) {
            return $customers;
        }

        $missing = array_diff($includeIds, array_column($customers, 'value'));

        if (!$missing) {
            return $customers;
        }

        $pinned = Customer::query()->whereIn('id', $missing)->get()->map(function ($customer) {
            return $this->toOption($customer);
        })->toArray();

        // Ahead of the rest: a chosen row belongs at the top of its own list.
        return array_merge($pinned, $customers);
    }
}
