<?php

namespace FluentCartPro\App\Modules\MCP;

use FluentCart\App\Modules\MCP\Support\MCPHelper;
use FluentCartPro\App\Modules\MCP\Tools\LicenseTools;

/**
 * Registers FluentCart Pro's MCP abilities onto the free plugin's `fluent-cart`
 * server. The free AbilitiesRegistrar owns the core tools; this one mirrors its
 * shape (same execute-callback exception wrapping, same meta) for the Pro tool
 * classes, and is invoked from MCPInit on the `fluent_cart/mcp_loaded` action.
 *
 * Pro tools are gated upstream — MCPInit only wires this when the relevant Pro
 * module (e.g. Licensing) is active — so this class simply registers whatever
 * toolClasses() expose.
 */
class AbilitiesRegistrar
{
    /** Tool classes that expose a static definitions() method. */
    private static function toolClasses()
    {
        return [
            LicenseTools::class,
        ];
    }

    public static function getDefinitions()
    {
        $defs = [];

        foreach (self::toolClasses() as $class) {
            if (class_exists($class) && method_exists($class, 'definitions')) {
                $defs = array_merge($defs, (array) $class::definitions());
            }
        }

        return $defs;
    }

    public static function register()
    {
        if (!function_exists('wp_register_ability')) {
            return;
        }

        foreach (self::getDefinitions() as $name => $definition) {
            $args = [
                'label'               => $definition['label'],
                'description'         => $definition['description'],
                'category'            => 'fluent-cart',
                'execute_callback'    => self::wrapExecuteCallback($name, $definition['execute_callback']),
                'permission_callback' => $definition['permission_callback'],
                'meta'                => [
                    'show_in_rest' => true,
                    'mcp'          => ['public' => true],
                ],
            ];

            if (!empty($definition['input_schema'])) {
                $args['input_schema'] = $definition['input_schema'];
            }

            if (!empty($definition['output_schema'])) {
                $args['output_schema'] = $definition['output_schema'];
            }

            if (!empty($definition['annotations'])) {
                $args['meta']['annotations'] = $definition['annotations'];
            }

            wp_register_ability($name, $args);
        }
    }

    /**
     * Mirrors the free registrar: convert any unhandled \Throwable from a tool
     * into a structured WP_Error carrying the real message (and, under WP_DEBUG,
     * file + a short trace) so the agent sees a readable failure, not the
     * adapter's generic surface.
     */
    private static function wrapExecuteCallback($toolName, $callback)
    {
        return function ($params) use ($toolName, $callback) {
            try {
                return call_user_func($callback, $params);
            } catch (\Throwable $e) {
                /**
                 * Fires when a Pro MCP tool throws. Shared with the free tools'
                 * exception hook so sites can log/alert in one place.
                 *
                 * @since 1.0.0
                 *
                 * @param array $context { exception: \Throwable, tool: string, params: mixed }
                 */
                do_action('fluent_cart/mcp_tool_exception', [
                    'exception' => $e,
                    'tool'      => $toolName,
                    'params'    => $params,
                ]);

                $details = ['tool' => $toolName, 'exception' => get_class($e), 'retryable' => true];

                if (defined('WP_DEBUG') && WP_DEBUG) {
                    $details['file']  = $e->getFile() . ':' . $e->getLine();
                    $details['trace'] = array_slice(explode("\n", $e->getTraceAsString()), 0, 5);
                }

                return MCPHelper::error('tool_failed', $e->getMessage(), $details);
            }
        };
    }
}
