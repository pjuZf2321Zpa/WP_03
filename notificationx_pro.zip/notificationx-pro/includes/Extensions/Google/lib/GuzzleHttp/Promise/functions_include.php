<?php

// Don't redefine the functions if included multiple times.

if ( ! defined( 'ABSPATH' ) ) { exit; }
if (!function_exists('NxProGA\GuzzleHttp\Promise\promise_for')) {
    require __DIR__ . '/functions.php';
}
