<?php

if (!defined('ABSPATH')) {
    die('You are not allowed to call this page directly.');
}

/**
 * Cart order notification email sent to the admin.
 *
 * Sends one consolidated admin notification per cart order (not one per transaction).
 * Includes a full line-item table with product name, qty, price, and totals.
 */
class MeprAdminCartReceiptEmail extends MeprBaseOptionsAdminEmail
{
    /**
     * Set the default enabled, title, subject & body.
     *
     * @param  array $args The args.
     * @return void
     */
    public function set_defaults($args = [])
    {
        $mepr_options = MeprOptions::fetch();
        $this->to     = $mepr_options->admin_email_addresses;

        $this->title       = __('<b>Cart Order Notification</b> Notice', 'memberpress');
        $this->description = __('Sent to the admin when a customer completes a multi-item cart checkout.', 'memberpress');
        $this->ui_order    = 2;

        $enabled = $use_template = $this->show_form = true;
        $subject = __('New Cart Order #{$order_id} — {$user_email}', 'memberpress');
        $body    = $this->body_partial();

        $this->defaults  = compact('enabled', 'subject', 'body', 'use_template');
        $this->variables = MeprUserCartReceiptEmail::get_cart_email_vars();
    }

    /**
     * Get the body partial for the email.
     *
     * @param  array $vars Optional variables to pass to the view.
     * @return string The body partial HTML.
     */
    public function body_partial($vars = [])
    {
        return MeprView::get_string('/emails/admin-cart-receipt', $vars);
    }

    /**
     * Send the cart order admin notification email.
     *
     * Overrides the base send() to accept a MeprOrder (not MeprTransaction).
     *
     * @param  MeprOrder    $order        The completed cart order.
     * @param  string|false $subject      Subject override, or false for the stored default.
     * @param  string|false $body         Body override, or false for the stored default.
     * @param  boolean|null $use_template Whether to wrap in the email template, or null for the default.
     * @param  string       $content_type The content type of the email.
     * @return void
     */
    public function send($order = [], $subject = false, $body = false, $use_template = null, $content_type = 'html')
    {
        if (!($order instanceof MeprOrder)) {
            parent::send($order, $subject, $body, $use_template, $content_type);
            return;
        }

        if (!$this->enabled()) {
            return;
        }

        $user         = new MeprUser($order->user_id);
        $transactions = MeprTransaction::get_all_by_order_id_for_display($order->id);

        $vars = $this->build_cart_vars($order, $user, $transactions);

        $formatted_subject = MeprUtils::replace_vals($this->get_stored_field('subject'), $vars);
        $formatted_body    = MeprUtils::replace_vals($this->get_stored_field('body'), $vars);

        // Let add-ons inject send params (e.g. pdf-invoice adds pdf_txn). Core stays agnostic.
        $send_params = MeprHooks::apply_filters('mepr_cart_receipt_email_params', [], $order, $this);

        parent::send($send_params, $formatted_subject, $formatted_body, $use_template, $content_type);
    }

    /**
     * Build the template variable replacement map for a cart order.
     *
     * @param  MeprOrder         $order        The cart order.
     * @param  MeprUser          $user         The purchasing user.
     * @param  MeprTransaction[] $transactions All transactions in the order.
     * @return array
     */
    private function build_cart_vars($order, $user, $transactions)
    {
        $items_html = $this->build_items_table($transactions, $order);

        $vars = [
            'user_first_name' => $user->first_name ?: '',
            'user_last_name'  => $user->last_name ?: '',
            'user_email'      => $user->user_email,
            'order_id'        => $order->id,
            'order_total'     => MeprAppHelper::format_currency($order->total, true, false, false, $order->currency),
            'order_items'     => $items_html,
            'order_date'      => MeprAppHelper::format_date($order->created_at, ''),
            'payment_method'  => MeprCartOrderDisplayHelper::payment_method_name($order),
        ];

        return MeprUserCartReceiptEmail::escape_vars($vars);
    }

    /**
     * Build an HTML table of line items for the order (shared builder — same table as the
     * customer receipt).
     *
     * @param  MeprTransaction[] $transactions The transactions to display.
     * @param  MeprOrder         $order        The parent cart order (for totals).
     * @return string HTML table string.
     */
    private function build_items_table($transactions, $order)
    {
        return MeprUserCartReceiptEmail::build_items_table($transactions, $order);
    }
}
