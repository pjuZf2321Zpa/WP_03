<?php

/**
 * AI Visibility — tracks how a brand/product appears when an AI assistant is
 * asked buyer-intent questions ("best AI plugin for WordPress", etc). Each
 * brand is scanned across a set of provider "surfaces" (an AI Engine
 * environment + model), and every query×surface answer is parsed for mention,
 * rank, citation, sentiment and the competitors named. Results are stored as a
 * time-series so the score can be trended and compared by provider.
 *
 * Phase 1 measures "memory mode": a plain completion asks what the model knows,
 * not a live web search. Retrieval mode (web-search-grounded) is a later phase.
 */
class MeowPro_MWSEO_Aivisibility
{
	private $core = null;
	private $brands_table = null;
	private $results_table = null;

	// Provider type (AI Engine env 'type') → display label. Falls back to
	// ucfirst() for anything not listed here.
	private static $provider_labels = array(
		'openai'     => 'OpenAI',
		'anthropic'  => 'Anthropic',
		'google'     => 'Google',
		'perplexity' => 'Perplexity',
		'mistral'    => 'Mistral',
		'xai'        => 'xAI',
		'openrouter' => 'OpenRouter',
		'ollama'     => 'Ollama',
		'cohere'     => 'Cohere',
		'deepseek'   => 'DeepSeek',
		'groq'       => 'Groq',
		'ovh'        => 'OVHcloud',
	);

	public function __construct( $core ) {
		$this->core = $core;
		global $wpdb;
		$this->brands_table  = $wpdb->prefix . MWSEO_PREFIX . '_ai_brands';
		$this->results_table = $wpdb->prefix . MWSEO_PREFIX . '_ai_results';
		$this->init();
	}

	public function init() {
		// Scans are driven from the browser, one query x provider per request. An
		// autonomous cron is deliberately NOT registered: a full run is hundreds of
		// AI calls and would blow past PHP's execution limit in a single request.
		// Any schedule left over from an earlier build is cleaned up here.
		$this->unschedule_legacy_cron();

		// Opt-in module: bail entirely when disabled so we don't create tables
		// on sites that aren't using it. (This file only ships with Pro, so the
		// license itself is already implied by the class being loaded at all.)
		if ( !$this->core->get_option( 'ai_visibility', false ) ) {
			return;
		}

		$this->maybe_create_tables();
	}

	/**
	 * The module object always exists once the class is loaded; only init() bails.
	 * Callers (REST, MCP) must check this before touching the tables, which are
	 * only created when the feature is actually on.
	 */
	public function is_enabled() {
		return (bool) $this->core->get_option( 'ai_visibility', false );
	}

	private function unschedule_legacy_cron() {
		$ts = wp_next_scheduled( 'mwseo_ai_visibility_scan' );
		while ( $ts ) {
			wp_unschedule_event( $ts, 'mwseo_ai_visibility_scan' );
			$ts = wp_next_scheduled( 'mwseo_ai_visibility_scan' );
		}
	}

	#region DB Tables

	private function maybe_create_tables() {
		global $wpdb;
		$charset_collate = $wpdb->get_charset_collate();
		require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );

		if ( $wpdb->get_var( "SHOW TABLES LIKE '$this->brands_table'" ) !== $this->brands_table ) {
			$sql = "CREATE TABLE $this->brands_table (
				id bigint(20) NOT NULL AUTO_INCREMENT,
				name varchar(190) NOT NULL,
				url varchar(500) NOT NULL DEFAULT '',
				description text,
				competitors text,
				country varchar(80) NOT NULL DEFAULT '',
				queries longtext,
				score smallint(5) DEFAULT NULL,
				enabled tinyint(1) NOT NULL DEFAULT 1,
				last_complete_batch varchar(32) DEFAULT NULL,
				last_scan_at datetime DEFAULT NULL,
				created_at datetime DEFAULT CURRENT_TIMESTAMP,
				PRIMARY KEY (id),
				KEY enabled (enabled)
			) $charset_collate;";
			dbDelta( $sql );
		}
		else {
			// Added after the first builds: only a finished scan may become the score.
			$has_col = $wpdb->get_var( "SHOW COLUMNS FROM $this->brands_table LIKE 'last_complete_batch'" );
			if ( !$has_col ) {
				$wpdb->query( "ALTER TABLE $this->brands_table ADD COLUMN last_complete_batch varchar(32) DEFAULT NULL" );
			}
		}

		if ( $wpdb->get_var( "SHOW TABLES LIKE '$this->results_table'" ) !== $this->results_table ) {
			$sql = "CREATE TABLE $this->results_table (
				id bigint(20) NOT NULL AUTO_INCREMENT,
				brand_id bigint(20) NOT NULL,
				scan_batch varchar(32) NOT NULL,
				query_text varchar(500) NOT NULL,
				provider varchar(40) NOT NULL DEFAULT '',
				env_id varchar(40) NOT NULL DEFAULT '',
				model_id varchar(120) NOT NULL DEFAULT '',
				model_label varchar(190) NOT NULL DEFAULT '',
				mentioned tinyint(1) NOT NULL DEFAULT 0,
				rank_pos smallint(5) DEFAULT NULL,
				cited tinyint(1) NOT NULL DEFAULT 0,
				sentiment smallint(5) DEFAULT NULL,
				competitors text,
				raw_answer longtext,
				cost decimal(10,5) DEFAULT NULL,
				created_at datetime DEFAULT CURRENT_TIMESTAMP,
				PRIMARY KEY (id),
				KEY brand_id (brand_id),
				KEY scan_batch (scan_batch),
				KEY created_at (created_at)
			) $charset_collate;";
			dbDelta( $sql );
		}
	}

	#endregion

	#region Surfaces (AI Engine env + model targets)

	/**
	 * Enumerate the AI Engine environments and their completion-capable models,
	 * so the admin can build provider surfaces (env + model). Returns a
	 * normalized shape the React modal consumes directly.
	 */
	public function get_surfaces_options() {
		global $mwai_core;
		$out = array( 'environments' => array(), 'has_ai' => false );
		if ( empty( $mwai_core ) || !method_exists( $mwai_core, 'get_all_options' ) ) {
			return $out;
		}
		$opts = $mwai_core->get_all_options();
		if ( empty( $opts['ai_envs'] ) || !is_array( $opts['ai_envs'] ) ) {
			return $out;
		}
		$out['has_ai'] = true;

		// The full built-in model lists are attached per provider type on the
		// consolidated 'ai_engines' array, not on each user environment. Build a
		// type → completion models map from there (plus any custom ai_models).
		$models_by_type = array();
		if ( !empty( $opts['ai_engines'] ) && is_array( $opts['ai_engines'] ) ) {
			foreach ( $opts['ai_engines'] as $engine ) {
				$etype = isset( $engine['type'] ) ? $engine['type'] : '';
				$models_by_type[ $etype ] = $this->filter_completion_models( isset( $engine['models'] ) ? $engine['models'] : array() );
			}
		}

		foreach ( $opts['ai_envs'] as $env ) {
			$type = isset( $env['type'] ) ? $env['type'] : '';
			$models = isset( $models_by_type[ $type ] ) ? $models_by_type[ $type ] : array();
			// Fall back to per-env / custom models when the type isn't a built-in engine.
			if ( empty( $models ) && method_exists( $mwai_core, 'get_engine_models' ) ) {
				$models = $this->filter_completion_models( $mwai_core->get_engine_models( $type ) );
			}
			$out['environments'][] = array(
				'id'       => isset( $env['id'] ) ? $env['id'] : '',
				'name'     => isset( $env['name'] ) ? $env['name'] : $this->provider_label( $type ),
				'type'     => $type,
				'provider' => $this->provider_label( $type ),
				'models'   => $models,
			);
		}
		return $out;
	}

	/** Keep only chat/completion models and reduce to { model, name }. */
	private function filter_completion_models( $models ) {
		$out = array();
		foreach ( (array) $models as $m ) {
			$features = isset( $m['features'] ) ? (array) $m['features'] : array();
			if ( !empty( $features ) && !in_array( 'completion', $features, true ) ) {
				continue;
			}
			$model_id = isset( $m['model'] ) ? $m['model'] : '';
			if ( $model_id === '' ) { continue; }
			$out[] = array(
				'model' => $model_id,
				'name'  => isset( $m['name'] ) ? $m['name'] : $model_id,
			);
		}
		return $out;
	}

	private function provider_label( $type ) {
		if ( isset( self::$provider_labels[ $type ] ) ) {
			return self::$provider_labels[ $type ];
		}
		return $type === '' ? __( 'Unknown', 'seo-engine' ) : ucfirst( $type );
	}

	/** The globally-configured surfaces (env + model) every brand is scanned across. */
	public function get_surfaces() {
		$surfaces = $this->core->get_option( 'ai_visibility_surfaces', array() );
		if ( !is_array( $surfaces ) ) { return array(); }
		$clean = array();
		foreach ( $surfaces as $s ) {
			if ( empty( $s['env_id'] ) || empty( $s['model'] ) ) { continue; }
			$clean[] = array(
				'env_id'   => (string) $s['env_id'],
				'model'    => (string) $s['model'],
				'provider' => isset( $s['provider'] ) ? (string) $s['provider'] : '',
				'label'    => isset( $s['label'] ) ? (string) $s['label'] : (string) $s['model'],
			);
		}
		return $clean;
	}

	public function save_surfaces( $surfaces ) {
		$clean = array();
		foreach ( (array) $surfaces as $s ) {
			if ( empty( $s['env_id'] ) || empty( $s['model'] ) ) { continue; }
			$clean[] = array(
				'env_id'   => sanitize_text_field( $s['env_id'] ),
				'model'    => sanitize_text_field( $s['model'] ),
				'provider' => isset( $s['provider'] ) ? sanitize_text_field( $s['provider'] ) : '',
				'label'    => isset( $s['label'] ) ? sanitize_text_field( $s['label'] ) : sanitize_text_field( $s['model'] ),
			);
		}
		$this->core->update_option( 'ai_visibility_surfaces', $clean );
		return $clean;
	}

	#endregion

	#region Brands CRUD

	public function list_brands() {
		global $wpdb;
		$brands = $wpdb->get_results( "SELECT * FROM $this->brands_table ORDER BY created_at DESC", ARRAY_A );
		if ( empty( $brands ) ) { return array(); }
		$out = array();
		foreach ( $brands as $b ) {
			$out[] = $this->decorate_brand( $b );
		}
		return $out;
	}

	public function get_brand( $id ) {
		global $wpdb;
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $this->brands_table WHERE id = %d", intval( $id ) ), ARRAY_A );
		return $row ? $this->decorate_brand( $row ) : null;
	}

	/** Attach decoded JSON fields + the latest-batch metrics used by the cards. */
	private function decorate_brand( $row ) {
		$id = (int) $row['id'];
		$row['id']          = $id;
		$row['score']       = $row['score'] === null ? null : (int) $row['score'];
		$row['enabled']     = (int) $row['enabled'];
		$row['competitors'] = $this->decode_list( $row['competitors'] );
		$row['queries']     = $this->decode_list( $row['queries'] );
		$row['metrics']     = $this->latest_metrics( $id );
		$row['by_provider'] = $this->latest_provider_breakdown( $id );
		$row['top_competitors'] = array_slice( $this->get_brand_competitors( $id ), 0, 4 );
		$row['headline']    = $this->build_headline( $id );
		return $row;
	}

	/** Per-provider mention/rank summary for the latest batch (drives the card chips). */
	private function latest_provider_breakdown( $brand_id ) {
		global $wpdb;
		$batch = $this->latest_batch( $brand_id );
		if ( !$batch ) { return array(); }
		$rows = $wpdb->get_results( $wpdb->prepare(
			"SELECT provider,
			        COUNT(*) AS total,
			        SUM(mentioned) AS mentions,
			        AVG(CASE WHEN mentioned = 1 AND rank_pos IS NOT NULL THEN rank_pos END) AS avg_rank,
			        AVG(sentiment) AS avg_sentiment
			 FROM $this->results_table WHERE brand_id = %d AND scan_batch = %s
			 GROUP BY provider ORDER BY provider ASC",
			$brand_id, $batch
		), ARRAY_A );
		$out = array();
		foreach ( (array) $rows as $r ) {
			$out[] = array(
				'provider'  => $r['provider'],
				'total'     => (int) $r['total'],
				'mentions'  => (int) $r['mentions'],
				'rank'      => $r['avg_rank'] === null ? null : round( (float) $r['avg_rank'], 1 ),
				'sentiment' => $r['avg_sentiment'] === null ? null : round( (float) $r['avg_sentiment'], 0 ),
			);
		}
		return $out;
	}

	/**
	 * A short, satisfying insight for the card: the strongest win and the biggest
	 * gap across the brand's queries in the latest batch. Returns null when unscanned.
	 */
	private function build_headline( $brand_id ) {
		$queries = $this->get_brand_queries( $brand_id );
		if ( empty( $queries ) ) { return null; }

		$best = null; $worst = null;
		foreach ( $queries as $q ) {
			$ranks = array();
			foreach ( $q['surfaces'] as $s ) {
				if ( $s['mentioned'] && $s['rank'] !== null ) { $ranks[] = $s['rank']; }
			}
			$best_rank = count( $ranks ) ? min( $ranks ) : null;
			$coverage  = $q['total'] ? $q['mentions'] / $q['total'] : 0;

			if ( $best_rank !== null && ( $best === null || $best_rank < $best['rank'] ) ) {
				$best = array( 'query' => $q['query'], 'rank' => $best_rank );
			}
			if ( $worst === null || $coverage < $worst['coverage'] ) {
				$worst = array( 'query' => $q['query'], 'coverage' => $coverage, 'mentions' => $q['mentions'], 'total' => $q['total'] );
			}
		}
		return array(
			'win' => $best,
			'gap' => ( $worst && $worst['coverage'] < 1 ) ? $worst : null,
		);
	}

	public function save_brand( $data ) {
		global $wpdb;
		$id   = isset( $data['id'] ) ? intval( $data['id'] ) : 0;
		$name = isset( $data['name'] ) ? trim( wp_strip_all_tags( $data['name'] ) ) : '';
		if ( $name === '' ) {
			return new WP_Error( 'invalid_name', __( 'A brand or product name is required.', 'seo-engine' ) );
		}

		$row = array(
			'name'        => mb_substr( $name, 0, 190 ),
			'url'         => isset( $data['url'] ) ? esc_url_raw( trim( $data['url'] ) ) : '',
			'description' => isset( $data['description'] ) ? wp_strip_all_tags( $data['description'] ) : '',
			'competitors' => wp_json_encode( $this->clean_list( isset( $data['competitors'] ) ? $data['competitors'] : array() ) ),
			'country'     => isset( $data['country'] ) ? sanitize_text_field( $data['country'] ) : '',
			'queries'     => wp_json_encode( $this->clean_list( isset( $data['queries'] ) ? $data['queries'] : array() ) ),
			'enabled'     => isset( $data['enabled'] ) ? (int) (bool) $data['enabled'] : 1,
		);
		$formats = array( '%s', '%s', '%s', '%s', '%s', '%s', '%d' );

		if ( $id > 0 ) {
			$ok = $wpdb->update( $this->brands_table, $row, array( 'id' => $id ), $formats, array( '%d' ) );
		} else {
			$row['created_at'] = current_time( 'mysql' );
			$formats[] = '%s';
			$ok = $wpdb->insert( $this->brands_table, $row, $formats );
			$id = (int) $wpdb->insert_id;
		}
		// Without this a failed write (e.g. emoji on a utf8 table) looks saved but isn't.
		if ( $ok === false ) {
			return new WP_Error( 'db_error', sprintf( __( 'The brand could not be saved: %s', 'seo-engine' ),
				$wpdb->last_error ? $wpdb->last_error : __( 'database error.', 'seo-engine' ) ) );
		}
		return $this->get_brand( $id );
	}

	public function delete_brand( $id ) {
		global $wpdb;
		$id = intval( $id );
		if ( $id <= 0 ) { return 0; }
		$wpdb->delete( $this->results_table, array( 'brand_id' => $id ), array( '%d' ) );
		return (int) $wpdb->delete( $this->brands_table, array( 'id' => $id ), array( '%d' ) );
	}

	#endregion

	#region Query generation

	/**
	 * Ask the AI to propose buyer-intent questions where this brand could
	 * surface. Returns a plain list of strings (the user edits them after).
	 */
	public function generate_queries( $data ) {
		global $mwai;
		if ( empty( $mwai ) || !method_exists( $mwai, 'simpleJsonQuery' ) ) {
			return new WP_Error( 'no_ai', __( 'AI Engine is required to generate queries.', 'seo-engine' ) );
		}
		$name        = isset( $data['name'] ) ? wp_strip_all_tags( $data['name'] ) : '';
		$description = isset( $data['description'] ) ? wp_strip_all_tags( $data['description'] ) : '';
		$competitors = implode( ', ', $this->clean_list( isset( $data['competitors'] ) ? $data['competitors'] : array() ) );
		if ( $name === '' ) {
			return new WP_Error( 'invalid_name', __( 'A brand or product name is required.', 'seo-engine' ) );
		}

		$prompt = "You are helping measure a brand's visibility in AI assistants. "
			. "Brand/product: \"$name\".\n"
			. ( $description !== '' ? "Description: $description\n" : '' )
			. ( $competitors !== '' ? "Known competitors: $competitors\n" : '' )
			. "Generate 15 realistic buyer-intent questions a person would ask an AI assistant "
			. "(ChatGPT, Gemini, Claude) where this brand could legitimately be recommended. "
			. "Questions should be about the CATEGORY, not name the brand itself "
			. "(e.g. \"best AI plugin for WordPress\", not \"is BrandX good\"). "
			. "Reply as JSON: { \"queries\": [\"...\", \"...\"] }.";

		try {
			$reply = $mwai->simpleJsonQuery( $prompt, null, null, array( 'scope' => 'seo' ) );
		} catch ( Exception $e ) {
			return new WP_Error( 'ai_error', apply_filters( 'mwai_ai_exception', $e->getMessage() ) );
		}
		$queries = array();
		if ( is_array( $reply ) && isset( $reply['queries'] ) && is_array( $reply['queries'] ) ) {
			$queries = $reply['queries'];
		} elseif ( is_array( $reply ) ) {
			// Some models return a bare array.
			$queries = $reply;
		}
		return $this->clean_list( $queries );
	}

	#endregion

	#region Scanning

	/** Build the flat list of {query, surface} units the interactive scan loops over. */
	public function build_scan_plan( $brand_id ) {
		$brand = $this->get_brand( $brand_id );
		if ( !$brand ) { return new WP_Error( 'not_found', __( 'Brand not found.', 'seo-engine' ) ); }
		$surfaces = $this->get_surfaces();
		if ( empty( $surfaces ) ) { return new WP_Error( 'no_surfaces', __( 'No AI providers configured. Add at least one provider surface first.', 'seo-engine' ) ); }
		$queries = $brand['queries'];
		if ( empty( $queries ) ) { return new WP_Error( 'no_queries', __( 'This brand has no queries to test yet.', 'seo-engine' ) ); }

		$batch = $this->new_batch_id();
		$units = array();
		foreach ( $queries as $q ) {
			foreach ( $surfaces as $s ) {
				$units[] = array( 'query' => $q, 'surface' => $s );
			}
		}
		return array( 'batch' => $batch, 'units' => $units, 'total' => count( $units ) );
	}

	/**
	 * Rough cost of a scan, based on the average cost actually recorded on past
	 * units. Returns null when nothing has ever been scanned, since there is no
	 * honest basis to guess then.
	 */
	public function estimate_scan_cost( $units ) {
		global $wpdb;
		$units = intval( $units );
		if ( $units <= 0 ) { return 0.0; }
		$avg = $wpdb->get_var( "SELECT AVG(cost) FROM $this->results_table WHERE cost IS NOT NULL AND cost > 0" );
		if ( $avg === null ) { return null; }
		return round( (float) $avg * $units, 4 );
	}

	/**
	 * Run a single query on a single surface, store the parsed result, return it.
	 * This is the unit the front-end iterates so long scans never time out.
	 */
	public function scan_one( $brand_id, $query_text, $surface, $batch = '' ) {
		global $wpdb, $mwai_core;
		$brand = $this->get_brand( $brand_id );
		if ( !$brand ) { return new WP_Error( 'not_found', __( 'Brand not found.', 'seo-engine' ) ); }
		if ( empty( $mwai_core ) || !class_exists( 'Meow_MWAI_Query_Text' ) ) {
			return new WP_Error( 'no_ai', __( 'AI Engine is required to run scans.', 'seo-engine' ) );
		}
		$batch = $batch !== '' ? preg_replace( '/[^a-zA-Z0-9_]/', '', $batch ) : $this->new_batch_id();
		$env_id = isset( $surface['env_id'] ) ? $surface['env_id'] : '';
		$model  = isset( $surface['model'] ) ? $surface['model'] : '';

		$prompt = $this->build_ranking_prompt( $brand, $query_text );

		try {
			$query = new Meow_MWAI_Query_Text( $prompt );
			$query->set_scope( 'seo' );
			if ( $env_id !== '' ) { $query->set_env_id( $env_id ); }
			if ( $model !== '' ) { $query->set_model( $model ); }
			$reply  = $mwai_core->run_query( $query );
			$answer = is_string( $reply->result ) ? $reply->result : '';
			$cost   = method_exists( $reply, 'get_price' ) ? $reply->get_price() : null;
		} catch ( Exception $e ) {
			return new WP_Error( 'ai_error', apply_filters( 'mwai_ai_exception', $e->getMessage() ) );
		}

		$parsed = $this->extract_from_answer( $brand, $answer );

		$data = array(
			'brand_id'    => (int) $brand_id,
			'scan_batch'  => $batch,
			'query_text'  => mb_substr( $query_text, 0, 500 ),
			'provider'    => isset( $surface['provider'] ) ? $surface['provider'] : '',
			'env_id'      => $env_id,
			'model_id'    => mb_substr( $model, 0, 120 ),
			'model_label' => isset( $surface['label'] ) ? mb_substr( $surface['label'], 0, 190 ) : mb_substr( $model, 0, 190 ),
			'mentioned'   => $parsed['mentioned'] ? 1 : 0,
			'rank_pos'    => $parsed['rank'],
			'cited'       => $parsed['cited'] ? 1 : 0,
			'sentiment'   => $parsed['sentiment'],
			'competitors' => wp_json_encode( $parsed['competitors'] ),
			'raw_answer'  => $answer,
			'cost'        => $cost === null ? null : round( (float) $cost, 5 ),
			'created_at'  => current_time( 'mysql' ),
		);
		// Idempotent per unit: re-running the same query x provider inside a batch
		// replaces its row instead of adding a duplicate (which would inflate the
		// totals and skew the score).
		$wpdb->delete( $this->results_table, array(
			'brand_id'   => (int) $brand_id,
			'scan_batch' => $batch,
			'query_text' => $data['query_text'],
			'provider'   => $data['provider'],
		), array( '%d', '%s', '%s', '%s' ) );

		$wpdb->insert( $this->results_table, $data, array(
			'%d','%s','%s','%s','%s','%s','%s','%d','%d','%d','%d','%s','%s','%f','%s'
		) );

		return array(
			'batch'     => $batch,
			'provider'  => $data['provider'],
			'model'     => $data['model_label'],
			'query'     => $query_text,
			'mentioned' => (bool) $parsed['mentioned'],
			'rank'      => $parsed['rank'],
			'cited'     => (bool) $parsed['cited'],
			'sentiment' => $parsed['sentiment'],
			'cost'      => $data['cost'],
		);
	}

	/**
	 * Finalize a scan: mark the newest batch as the complete one, recompute the
	 * cached score, and prune old batches. Until this runs, an in-progress batch
	 * is ignored by the metrics, so an interrupted scan never becomes the score.
	 */
	public function finalize_scan( $brand_id ) {
		global $wpdb;
		$brand_id = intval( $brand_id );

		$batch = $wpdb->get_var( $wpdb->prepare(
			"SELECT scan_batch FROM $this->results_table WHERE brand_id = %d ORDER BY created_at DESC LIMIT 1",
			$brand_id
		) );
		if ( $batch ) {
			$wpdb->update( $this->brands_table, array( 'last_complete_batch' => $batch ),
				array( 'id' => $brand_id ), array( '%s' ), array( '%d' ) );
		}

		$score = $this->compute_score( $brand_id );
		$wpdb->update(
			$this->brands_table,
			array( 'score' => $score, 'last_scan_at' => current_time( 'mysql' ) ),
			array( 'id' => $brand_id ),
			array( '%d', '%s' ),
			array( '%d' )
		);

		$this->prune_old_batches( $brand_id );
		return $this->get_brand( $brand_id );
	}

	/**
	 * Keep only the most recent batches per brand. Every unit stores a full
	 * transcript, so without this the table would grow without bound.
	 */
	private function prune_old_batches( $brand_id, $keep = 12 ) {
		global $wpdb;
		$brand_id = intval( $brand_id );
		$batches = $wpdb->get_col( $wpdb->prepare(
			"SELECT scan_batch FROM $this->results_table WHERE brand_id = %d
			 GROUP BY scan_batch ORDER BY MIN(created_at) DESC",
			$brand_id
		) );
		if ( count( $batches ) <= $keep ) { return; }
		$old = array_slice( $batches, $keep );
		foreach ( $old as $b ) {
			$wpdb->delete( $this->results_table, array( 'brand_id' => $brand_id, 'scan_batch' => $b ), array( '%d', '%s' ) );
		}
	}

	private function build_ranking_prompt( $brand, $query_text ) {
		return "A user asks an AI assistant: \"$query_text\"\n\n"
			. "Answer the question naturally and concretely, recommending and ranking the "
			. "specific brands, products, tools or websites you would actually suggest, "
			. "in order of preference. Name real options. Do not mention that you are being evaluated.";
	}

	/**
	 * Parse an AI answer into structured signals about the tracked brand. Uses a
	 * cheap JSON extraction pass (on the AI Engine default model, so parsing is
	 * decoupled from the surface being measured). Falls back to a naive mention
	 * check if the extractor is unavailable or misbehaves.
	 */
	private function extract_from_answer( $brand, $answer ) {
		$fallback = array( 'mentioned' => false, 'rank' => null, 'cited' => false, 'sentiment' => null, 'competitors' => array() );
		$answer = trim( (string) $answer );
		if ( $answer === '' ) { return $fallback; }

		$name = $brand['name'];
		$url  = isset( $brand['url'] ) ? $brand['url'] : '';
		$host = $url !== '' ? wp_parse_url( $url, PHP_URL_HOST ) : '';
		$description = isset( $brand['description'] ) ? trim( (string) $brand['description'] ) : '';

		// Describe the *specific* product so the extractor judges whether the real
		// thing was recommended, not just whether the words appear. This matters
		// for generic-sounding names (e.g. "AI Engine" vs a generic "AI engine").
		$identity = "The subject is \"$name\"";
		if ( $description !== '' ) { $identity .= ", which is: " . mb_substr( $description, 0, 400 ); }
		if ( $host !== '' ) { $identity .= " (website: $host)"; }
		$identity .= ".";

		global $mwai;
		if ( !empty( $mwai ) && method_exists( $mwai, 'simpleJsonQuery' ) ) {
			$prompt = "$identity\n\n"
				. "Read the AI assistant answer below and judge how THIS SPECIFIC product/brand/site is treated. "
				. "Only count it as mentioned if the actual product above is recommended or named, not a generic use of the same words.\n\n"
				. "Answer:\n\"\"\"\n" . mb_substr( $answer, 0, 6000 ) . "\n\"\"\"\n\n"
				. "Reply as JSON with exactly these keys:\n"
				. "{ \"mentioned\": true|false (is the specific product above actually recommended or named?),\n"
				. "  \"rank\": integer position of it in the answer's ranked list (1 = first), or null if not ranked/mentioned,\n"
				. "  \"cited\": true|false (is its website/domain linked or cited?),\n"
				. "  \"sentiment\": integer 0-100 describing how positively it is portrayed, or null if not mentioned,\n"
				. "  \"competitors\": array of { \"name\": string, \"sentiment\": 0-100 } for the OTHER brands/products/sites recommended in the answer }.";
			try {
				$reply = $mwai->simpleJsonQuery( $prompt, null, null, array( 'scope' => 'seo' ) );
			} catch ( Exception $e ) {
				$reply = null;
			}
			if ( is_array( $reply ) ) {
				return $this->normalize_extraction( $reply );
			}
		}

		// Fallback: naive presence + citation detection.
		$mentioned = ( stripos( $answer, $name ) !== false );
		$cited = ( $host && stripos( $answer, $host ) !== false );
		return array( 'mentioned' => $mentioned, 'rank' => null, 'cited' => $cited, 'sentiment' => null, 'competitors' => array() );
	}

	private function normalize_extraction( $reply ) {
		$mentioned = !empty( $reply['mentioned'] );
		$rank = isset( $reply['rank'] ) && is_numeric( $reply['rank'] ) ? max( 1, (int) $reply['rank'] ) : null;
		$cited = !empty( $reply['cited'] );
		$sentiment = isset( $reply['sentiment'] ) && is_numeric( $reply['sentiment'] )
			? max( 0, min( 100, (int) $reply['sentiment'] ) ) : null;
		if ( !$mentioned ) { $rank = null; $sentiment = null; }
		$competitors = array();
		if ( !empty( $reply['competitors'] ) && is_array( $reply['competitors'] ) ) {
			foreach ( $reply['competitors'] as $c ) {
				$cname = is_array( $c ) ? ( isset( $c['name'] ) ? $c['name'] : '' ) : (string) $c;
				$cname = trim( wp_strip_all_tags( $cname ) );
				if ( $cname === '' ) { continue; }
				$csent = is_array( $c ) && isset( $c['sentiment'] ) && is_numeric( $c['sentiment'] )
					? max( 0, min( 100, (int) $c['sentiment'] ) ) : null;
				$competitors[] = array( 'name' => mb_substr( $cname, 0, 120 ), 'sentiment' => $csent );
			}
		}
		return array( 'mentioned' => $mentioned, 'rank' => $rank, 'cited' => $cited, 'sentiment' => $sentiment, 'competitors' => $competitors );
	}

	#endregion

	#region Metrics & scoring

	/**
	 * The batch the metrics are read from: the last *completed* scan. A scan that
	 * is still running (or was interrupted) is not reported, so the previous good
	 * numbers stay on screen until the new scan finishes.
	 */
	private function latest_batch( $brand_id ) {
		global $wpdb;
		$brand_id = intval( $brand_id );
		$complete = $wpdb->get_var( $wpdb->prepare(
			"SELECT last_complete_batch FROM $this->brands_table WHERE id = %d", $brand_id
		) );
		if ( $complete ) { return $complete; }
		// Never finalized (e.g. data from before this was introduced): fall back.
		return $wpdb->get_var( $wpdb->prepare(
			"SELECT scan_batch FROM $this->results_table WHERE brand_id = %d ORDER BY created_at DESC LIMIT 1",
			$brand_id
		) );
	}

	/** Metrics for a brand's most recent scan batch (drives the brands table). */
	private function latest_metrics( $brand_id ) {
		global $wpdb;
		$batch = $this->latest_batch( $brand_id );
		$empty = array( 'mentions' => 0, 'citations' => 0, 'rank' => null, 'sentiment' => null, 'total' => 0, 'mention_rate' => 0 );
		if ( !$batch ) { return $empty; }

		$rows = $wpdb->get_results( $wpdb->prepare(
			"SELECT mentioned, rank_pos, cited, sentiment FROM $this->results_table WHERE brand_id = %d AND scan_batch = %s",
			$brand_id, $batch
		), ARRAY_A );
		if ( empty( $rows ) ) { return $empty; }

		$total = count( $rows );
		$mentions = 0; $citations = 0; $ranks = array(); $sents = array();
		foreach ( $rows as $r ) {
			if ( (int) $r['mentioned'] ) { $mentions++; }
			if ( (int) $r['cited'] ) { $citations++; }
			if ( $r['rank_pos'] !== null ) { $ranks[] = (int) $r['rank_pos']; }
			if ( $r['sentiment'] !== null ) { $sents[] = (int) $r['sentiment']; }
		}
		return array(
			'mentions'     => $mentions,
			'citations'    => $citations,
			'rank'         => count( $ranks ) ? round( array_sum( $ranks ) / count( $ranks ), 1 ) : null,
			'sentiment'    => count( $sents ) ? round( array_sum( $sents ) / count( $sents ), 1 ) : null,
			'total'        => $total,
			'mention_rate' => $total ? round( $mentions / $total, 3 ) : 0,
		);
	}

	/**
	 * Transparent composite score (0-100) from the latest batch:
	 * presence 50%, rank 30%, sentiment 20%.
	 *
	 * Citations are deliberately NOT weighted: when a model answers from memory it
	 * almost never cites a URL, so including them capped every possible score at 90.
	 * They are still recorded, and become meaningful once retrieval mode lands.
	 */
	private function compute_score( $brand_id ) {
		$m = $this->latest_metrics( $brand_id );
		if ( empty( $m['total'] ) ) { return null; }
		$presence = $m['mention_rate']; // 0..1
		// Rank 1 → 1.0, rank 10 → 0.1, unmentioned contributes 0 via presence weighting.
		$rank_score = $m['rank'] !== null ? max( 0, min( 1, ( 11 - $m['rank'] ) / 10 ) ) : 0;
		// A brand that is never mentioned earns no sentiment credit (score ~0). The
		// neutral 0.5 default only applies when it was mentioned but sentiment was unclear.
		$sentiment_score = $m['sentiment'] !== null ? $m['sentiment'] / 100 : ( $presence > 0 ? 0.5 : 0 );
		$score = 100 * ( 0.50 * $presence + 0.30 * $rank_score + 0.20 * $sentiment_score );
		return (int) round( $score );
	}

	#endregion

	#region Detail reads (queries / competitors / transcripts / timeseries)

	/** Per-query latest result across surfaces, for the brand detail "Queries" tab. */
	public function get_brand_queries( $brand_id ) {
		global $wpdb;
		$brand_id = intval( $brand_id );
		$batch = $wpdb->get_var( $wpdb->prepare(
			"SELECT scan_batch FROM $this->results_table WHERE brand_id = %d ORDER BY created_at DESC LIMIT 1", $brand_id
		) );
		if ( !$batch ) { return array(); }
		$rows = $wpdb->get_results( $wpdb->prepare(
			"SELECT query_text, provider, model_label, mentioned, rank_pos, cited, sentiment
			 FROM $this->results_table WHERE brand_id = %d AND scan_batch = %s ORDER BY query_text ASC",
			$brand_id, $batch
		), ARRAY_A );
		$byq = array();
		foreach ( $rows as $r ) {
			$q = $r['query_text'];
			if ( !isset( $byq[ $q ] ) ) {
				$byq[ $q ] = array( 'query' => $q, 'surfaces' => array(), 'mentions' => 0, 'total' => 0 );
			}
			$byq[ $q ]['total']++;
			if ( (int) $r['mentioned'] ) { $byq[ $q ]['mentions']++; }
			$byq[ $q ]['surfaces'][] = array(
				'provider'  => $r['provider'],
				'model'     => $r['model_label'],
				'mentioned' => (bool) (int) $r['mentioned'],
				'rank'      => $r['rank_pos'] === null ? null : (int) $r['rank_pos'],
				'cited'     => (bool) (int) $r['cited'],
				'sentiment' => $r['sentiment'] === null ? null : (int) $r['sentiment'],
			);
		}
		return array_values( $byq );
	}

	/** Aggregated competitor mentions from the latest batch. */
	public function get_brand_competitors( $brand_id ) {
		global $wpdb;
		$brand_id = intval( $brand_id );
		$batch = $wpdb->get_var( $wpdb->prepare(
			"SELECT scan_batch FROM $this->results_table WHERE brand_id = %d ORDER BY created_at DESC LIMIT 1", $brand_id
		) );
		if ( !$batch ) { return array(); }
		$rows = $wpdb->get_col( $wpdb->prepare(
			"SELECT competitors FROM $this->results_table WHERE brand_id = %d AND scan_batch = %s", $brand_id, $batch
		) );
		$agg = array();
		foreach ( $rows as $json ) {
			$list = json_decode( $json, true );
			if ( !is_array( $list ) ) { continue; }
			foreach ( $list as $c ) {
				if ( empty( $c['name'] ) ) { continue; }
				$key = mb_strtolower( $c['name'] );
				if ( !isset( $agg[ $key ] ) ) {
					$agg[ $key ] = array( 'name' => $c['name'], 'mentions' => 0, 'sent_sum' => 0, 'sent_n' => 0 );
				}
				$agg[ $key ]['mentions']++;
				if ( isset( $c['sentiment'] ) && $c['sentiment'] !== null ) {
					$agg[ $key ]['sent_sum'] += (int) $c['sentiment'];
					$agg[ $key ]['sent_n']++;
				}
			}
		}
		$out = array();
		foreach ( $agg as $c ) {
			$out[] = array(
				'name'      => $c['name'],
				'mentions'  => $c['mentions'],
				'sentiment' => $c['sent_n'] ? round( $c['sent_sum'] / $c['sent_n'], 1 ) : null,
			);
		}
		usort( $out, function ( $a, $b ) { return $b['mentions'] - $a['mentions']; } );
		return $out;
	}

	/** Raw transcripts (latest batch), for the "Raw data / Transcripts" tab. */
	public function get_brand_transcripts( $brand_id, $limit = 100 ) {
		global $wpdb;
		$brand_id = intval( $brand_id );
		$batch = $wpdb->get_var( $wpdb->prepare(
			"SELECT scan_batch FROM $this->results_table WHERE brand_id = %d ORDER BY created_at DESC LIMIT 1", $brand_id
		) );
		if ( !$batch ) { return array(); }
		$rows = $wpdb->get_results( $wpdb->prepare(
			"SELECT query_text, provider, model_label, mentioned, rank_pos, sentiment, raw_answer, created_at
			 FROM $this->results_table WHERE brand_id = %d AND scan_batch = %s ORDER BY created_at DESC LIMIT %d",
			$brand_id, $batch, intval( $limit )
		), ARRAY_A );
		return $rows ?: array();
	}

	/** Score-over-time series, one point per scan batch, split by provider. */
	public function get_brand_timeseries( $brand_id ) {
		global $wpdb;
		$brand_id = intval( $brand_id );
		$rows = $wpdb->get_results( $wpdb->prepare(
			"SELECT scan_batch, provider,
			        MIN(created_at) AS scanned_at,
			        AVG(mentioned) AS mention_rate,
			        AVG(CASE WHEN mentioned = 1 AND rank_pos IS NOT NULL THEN rank_pos END) AS avg_rank,
			        AVG(sentiment) AS avg_sentiment
			 FROM $this->results_table WHERE brand_id = %d
			 GROUP BY scan_batch, provider ORDER BY scanned_at ASC",
			$brand_id
		), ARRAY_A );
		$out = array();
		foreach ( $rows as $r ) {
			$out[] = array(
				'batch'        => $r['scan_batch'],
				'provider'     => $r['provider'],
				'scanned_at'   => $r['scanned_at'],
				'mention_rate' => $r['mention_rate'] === null ? null : round( (float) $r['mention_rate'], 3 ),
				'avg_rank'     => $r['avg_rank'] === null ? null : round( (float) $r['avg_rank'], 2 ),
				'avg_sentiment'=> $r['avg_sentiment'] === null ? null : round( (float) $r['avg_sentiment'], 1 ),
			);
		}
		return $out;
	}

	/** Top dashboard cards, mirroring RankMath's overview. */
	public function get_overview() {
		global $wpdb;
		$brand_ids = array_map( 'intval', (array) $wpdb->get_col( "SELECT id FROM $this->brands_table" ) );
		$brand_count = count( $brand_ids );
		$avg_score = $wpdb->get_var( "SELECT AVG(score) FROM $this->brands_table WHERE score IS NOT NULL" );
		$scans_24h = (int) $wpdb->get_var( "SELECT COUNT(*) FROM $this->results_table WHERE created_at > DATE_SUB(NOW(), INTERVAL 24 HOUR)" );

		// Average of each brand's latest-batch mention count (small N, computed in PHP).
		$mention_counts = array();
		foreach ( $brand_ids as $bid ) {
			$m = $this->latest_metrics( $bid );
			if ( $m['total'] > 0 ) { $mention_counts[] = $m['mentions']; }
		}
		$avg_mentions = count( $mention_counts ) ? round( array_sum( $mention_counts ) / count( $mention_counts ), 1 ) : 0;

		return array(
			'brand_count'  => $brand_count,
			'global_score' => $avg_score === null ? null : (int) round( $avg_score ),
			'scans_24h'    => $scans_24h,
			'avg_mentions' => $avg_mentions,
			'has_surfaces' => count( $this->get_surfaces() ) > 0,
		);
	}

	#endregion

	#region Helpers

	private function new_batch_id() {
		return 'b' . gmdate( 'YmdHis' ) . wp_rand( 100, 999 );
	}

	private function decode_list( $json ) {
		$list = json_decode( (string) $json, true );
		return is_array( $list ) ? array_values( $list ) : array();
	}

	private function clean_list( $list ) {
		if ( is_string( $list ) ) {
			$list = preg_split( "/\r\n|\n|\r/", $list );
		}
		if ( !is_array( $list ) ) { return array(); }
		$out = array();
		foreach ( $list as $item ) {
			$item = trim( wp_strip_all_tags( (string) $item ) );
			if ( $item !== '' ) { $out[] = mb_substr( $item, 0, 300 ); }
		}
		return array_values( array_unique( $out ) );
	}

	#endregion
}
