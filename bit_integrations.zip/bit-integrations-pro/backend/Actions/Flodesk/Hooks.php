<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Actions\Flodesk\FlodeskHelperPro;
use BitApps\IntegrationsPro\Config;
use BitApps\IntegrationsPro\Core\Util\Hooks;

Hooks::filter(Config::withFreePrefix('flodesk_create_or_update_subscriber'), [FlodeskHelperPro::class, 'createOrUpdateSubscriber'], 10, 4);
Hooks::filter(Config::withFreePrefix('flodesk_unsubscribe_subscriber'), [FlodeskHelperPro::class, 'unsubscribeSubscriber'], 10, 4);
Hooks::filter(Config::withFreePrefix('flodesk_add_subscriber_to_segments'), [FlodeskHelperPro::class, 'addSubscriberToSegments'], 10, 4);
Hooks::filter(Config::withFreePrefix('flodesk_remove_subscriber_from_segments'), [FlodeskHelperPro::class, 'removeSubscriberFromSegments'], 10, 4);
Hooks::filter(Config::withFreePrefix('flodesk_create_segment'), [FlodeskHelperPro::class, 'createSegment'], 10, 4);
Hooks::filter(Config::withFreePrefix('flodesk_create_custom_field'), [FlodeskHelperPro::class, 'createCustomField'], 10, 4);
Hooks::filter(Config::withFreePrefix('flodesk_add_subscriber_to_workflow'), [FlodeskHelperPro::class, 'addSubscriberToWorkflow'], 10, 4);
Hooks::filter(Config::withFreePrefix('flodesk_remove_subscriber_from_workflow'), [FlodeskHelperPro::class, 'removeSubscriberFromWorkflow'], 10, 4);
