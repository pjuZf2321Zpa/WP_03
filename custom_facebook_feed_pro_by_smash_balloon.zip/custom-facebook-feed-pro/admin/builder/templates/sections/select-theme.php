<?php

if (! defined('ABSPATH')) {
	exit; // Exit if accessed directly.
}
?>
<div class="cff-fb-types-ctn cff-fb-templates-ctn cff-fb-fs sb-box-shadow" v-if="viewsActive.selectedFeedSection == 'selectTheme'">
	<div class="cff-fb-types cff-fb-fs">
		<h4>{{selectFeedThemeScreen.feedThemeHeading}}</h4>
		<p class="sb-caption sb-lighter">{{selectFeedThemeScreen.feedThemeDescription}}</p>
		<div class="cff-fb-templates-list cff-feed-theme-list">
			<button type="button" class="cff-fb-type-el" v-for="(feedTemplateEl, feedTemplateIn) in feedThemes" :data-active="selectedFeedTheme === feedTemplateEl.type" :aria-pressed="selectedFeedTheme === feedTemplateEl.type ? 'true' : 'false'" @click.prevent.default="hasFeature('feed_themes') ? chooseFeedTheme(feedTemplateEl) : (viewsActive.extensionsPopupElement = 'feedThemes')" @keydown.enter.prevent="hasFeature('feed_themes') ? chooseFeedTheme(feedTemplateEl) : (viewsActive.extensionsPopupElement = 'feedThemes')" @keydown.space.prevent="hasFeature('feed_themes') ? chooseFeedTheme(feedTemplateEl) : (viewsActive.extensionsPopupElement = 'feedThemes')">
				<div :class="['cff-fb-type-el-img cff-fb-fs', 'cff-feedtemplate-' + feedTemplateEl.type]">
					<img
					:src="plugin_path + 'admin/assets/img/customizer-theme/' + feedTemplateEl.type + '.jpg'"
					alt="">
				</div>
				<div class="cff-fb-type-el-info cff-fb-fs">
					<p class="sb-small-p sb-bold sb-dark-text" v-html="getFeedTemplateElTitle(feedTemplateEl)"></p>
				</div>
			</button>
		</div>
	</div>
</div>