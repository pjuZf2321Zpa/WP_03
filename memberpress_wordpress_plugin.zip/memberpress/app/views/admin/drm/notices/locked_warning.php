<?php if (!defined('ABSPATH')) {
    die('You are not allowed to call this page directly.');
} ?>
<div class="mepr-notice-wrapper">
   <h3 class="mepr-notice-title"><?php echo esc_html($drm_info['heading']); ?></h3>
   <p class="mepr-notice-desc"><?php esc_html_e('Your MemberPress license key is not found or is invalid. Without an active license key, your frontend is unaffected. However, you can no longer: Issue customer refunds, Add new members, Manage memberships.', 'memberpress'); ?>
   </p>
   <?php if (! empty($drm_info['fee_disclosure'])) : ?>
   <p class="mepr-notice-desc"><?php echo esc_html($drm_info['fee_disclosure']); ?></p>
   <?php endif; ?>
   <p class="mepr-notice-actions">
      <a href="<?php echo esc_url($drm_info['account_link']); ?>" class="button button-primary"><?php esc_html_e('Click here to purchase or renew your license key', 'memberpress'); ?></a>
   </p>
</div>

