<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Core\Util\Hooks;
use BitApps\IntegrationsPro\Triggers\EssentialAddonsElementor\EssentialAddonsElementorController;

Hooks::add('eael/login-register/after-login', [EssentialAddonsElementorController::class, 'handleUserLogin'], 10, 2);
Hooks::add('eael/login-register/after-insert-user', [EssentialAddonsElementorController::class, 'handleUserRegistration'], 10, 2);
