<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Actions\PopupMaker\PopupMakerProHelper;
use BitApps\IntegrationsPro\Config;
use BitApps\IntegrationsPro\Core\Util\Hooks;

Hooks::filter(Config::withFreePrefix('popup_maker_create_popup'), [PopupMakerProHelper::class, 'createPopup'], 10, 4);
Hooks::filter(Config::withFreePrefix('popup_maker_update_popup'), [PopupMakerProHelper::class, 'updatePopup'], 10, 4);
Hooks::filter(Config::withFreePrefix('popup_maker_create_subscriber'), [PopupMakerProHelper::class, 'createSubscriber'], 10, 4);
Hooks::filter(Config::withFreePrefix('popup_maker_update_subscriber'), [PopupMakerProHelper::class, 'updateSubscriber'], 10, 4);
Hooks::filter(Config::withFreePrefix('popup_maker_delete_popup'), [PopupMakerProHelper::class, 'deletePopup'], 10, 3);
Hooks::filter(Config::withFreePrefix('popup_maker_change_popup_status'), [PopupMakerProHelper::class, 'changePopupStatus'], 10, 3);
Hooks::filter(Config::withFreePrefix('popup_maker_track_popup_event'), [PopupMakerProHelper::class, 'trackPopupEvent'], 10, 3);
Hooks::filter(Config::withFreePrefix('popup_maker_reset_popup_counts'), [PopupMakerProHelper::class, 'resetPopupCounts'], 10, 2);
Hooks::filter(Config::withFreePrefix('popup_maker_delete_subscriber'), [PopupMakerProHelper::class, 'deleteSubscriber'], 10, 2);
