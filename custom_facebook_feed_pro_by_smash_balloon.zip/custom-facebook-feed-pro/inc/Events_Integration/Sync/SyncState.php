<?php
/**
 * Sync-state store: maps Facebook events to the calendar posts created for
 * them. Post meta is the durable truth; a registry option mirrors it so
 * "never synced" can be told apart from "user deleted the calendar event".
 *
 * @package CustomFacebookFeed\Events_Integration
 * @since 4.11
 */

namespace CustomFacebookFeed\Events_Integration\Sync;

use CustomFacebookFeed\Events_Integration\Config;
use CustomFacebookFeed\Events_Integration\NormalizedEvent;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class SyncState {

	const META_SYNC_KEY     = '_cff_fb_event_sync_key';
	const META_EVENT_ID     = '_cff_fb_event_id';
	const META_SOURCE_ID    = '_cff_fb_event_source_id';
	const META_UPDATED_TIME = '_cff_fb_event_updated_time';
	const META_START        = '_cff_fb_event_start';
	const META_END          = '_cff_fb_event_end';
	const META_COVER_HASH   = '_cff_fb_event_cover_hash';
	const META_TARGET       = '_cff_fb_event_target';
	const META_LAST_CONFIRM = '_cff_fb_event_last_confirm';

	/**
	 * Option: {target_id: {sync_key: post_id}}.
	 */
	const OPTION_REGISTRY = 'cff_events_sync_registry';

	/**
	 * In-memory registry, written back once per flush().
	 *
	 * @var array|null
	 */
	private $registry_cache = null;

	/**
	 * @var bool
	 */
	private $registry_dirty = false;

	/**
	 * Per-target {sync_key: post_id} map built from post meta, used as a
	 * fallback when the registry option was lost or never flushed.
	 *
	 * @var array<string, array<string, int>>
	 */
	private $meta_map_cache = array();

	/**
	 * Look up the calendar post for a sync key. Detects calendar-side
	 * deletions: a registry entry whose post no longer exists is tombstoned
	 * and reported as missing.
	 *
	 * @param string $target_id Target adapter ID.
	 * @param string $sync_key  Event sync key.
	 * @return int|null Post ID, or null when not synced (or tombstoned).
	 */
	public function lookup( $target_id, $sync_key ) {
		$registry = $this->registry();

		if ( isset( $registry[ $target_id ][ $sync_key ] ) ) {
			$post_id = (int) $registry[ $target_id ][ $sync_key ];
		} else {
			// Registry lost or never flushed (e.g. a run died mid-pass):
			// post meta is the durable truth, so fall back to it before
			// concluding the event was never synced, otherwise the next
			// run duplicates every event of the interrupted pass.
			$meta_map = $this->meta_map( $target_id );
			if ( ! isset( $meta_map[ $sync_key ] ) ) {
				return null;
			}
			$post_id = (int) $meta_map[ $sync_key ];
		}

		$post = get_post( $post_id );

		if ( ! $post || 'trash' === $post->post_status || get_post_meta( $post_id, self::META_SYNC_KEY, true ) !== $sync_key ) {
			// The user removed the calendar event: never recreate it.
			$this->add_tombstone( $target_id, $sync_key );
			$this->unregister( $target_id, $sync_key );
			return null;
		}

		if ( ! isset( $registry[ $target_id ][ $sync_key ] ) ) {
			// Re-adopt the recovered mapping into the registry.
			$this->registry_cache[ $target_id ][ $sync_key ] = $post_id;
			$this->registry_dirty                            = true;
		}

		return $post_id;
	}

	/**
	 * Record a created/updated calendar post for an event.
	 *
	 * @param NormalizedEvent $event     Normalized event.
	 * @param string          $target_id Target adapter ID.
	 * @param int             $post_id   Calendar post ID.
	 */
	public function record( NormalizedEvent $event, $target_id, $post_id ) {
		update_post_meta( $post_id, self::META_SYNC_KEY, $event->sync_key() );
		update_post_meta( $post_id, self::META_EVENT_ID, $event->source_event_id );
		update_post_meta( $post_id, self::META_SOURCE_ID, $event->source_id );
		update_post_meta( $post_id, self::META_UPDATED_TIME, $event->updated_time );
		update_post_meta( $post_id, self::META_START, $event->start_timestamp() );
		update_post_meta( $post_id, self::META_END, $event->end_timestamp() );
		update_post_meta( $post_id, self::META_TARGET, $target_id );

		$this->registry();
		$this->registry_cache[ $target_id ][ $event->sync_key() ] = (int) $post_id;
		$this->registry_dirty                                     = true;
	}

	/**
	 * Persist pending registry changes.
	 */
	public function flush() {
		if ( $this->registry_dirty && null !== $this->registry_cache ) {
			update_option( self::OPTION_REGISTRY, $this->registry_cache, false );
			$this->registry_dirty = false;
		}
	}

	/**
	 * Stored Graph updated_time for a synced post.
	 *
	 * @param int $post_id Calendar post ID.
	 * @return int
	 */
	public function stored_updated_time( $post_id ) {
		return (int) get_post_meta( $post_id, self::META_UPDATED_TIME, true );
	}

	/**
	 * Forget a mapping (post was deleted by the sync itself, no tombstone).
	 *
	 * @param string $target_id Target adapter ID.
	 * @param string $sync_key  Event sync key.
	 */
	public function forget( $target_id, $sync_key ) {
		$this->unregister( $target_id, $sync_key );
	}

	/**
	 * Deletion-pass candidates: synced posts whose stored end is still in
	 * the future but whose sync key is absent from the fresh fetch, grouped
	 * by event ID so one confirmation fetch covers all occurrences.
	 *
	 * @param string   $target_id  Target adapter ID.
	 * @param string   $source_id  Page ID.
	 * @param string[] $fresh_keys Sync keys present in the fresh fetch.
	 * @return array {event_id: [{post_id, sync_key}, ...]}
	 */
	public function stale_future_candidates( $target_id, $source_id, array $fresh_keys ) {
		$fresh_lookup   = array_flip( $fresh_keys );
		$candidates     = array();
		$last_confirmed = array();

		foreach ( $this->all_synced_posts( $target_id ) as $post_id ) {
			$sync_key = (string) get_post_meta( $post_id, self::META_SYNC_KEY, true );
			if ( '' === $sync_key || isset( $fresh_lookup[ $sync_key ] ) ) {
				continue;
			}
			if ( get_post_meta( $post_id, self::META_SOURCE_ID, true ) !== $source_id ) {
				continue;
			}
			// Past events aged out naturally; never deletion candidates.
			if ( (int) get_post_meta( $post_id, self::META_END, true ) <= time() ) {
				continue;
			}
			$event_id                  = (string) get_post_meta( $post_id, self::META_EVENT_ID, true );
			$candidates[ $event_id ][] = array(
				'post_id'  => (int) $post_id,
				'sync_key' => $sync_key,
			);

			$confirmed = (int) get_post_meta( $post_id, self::META_LAST_CONFIRM, true );
			if ( ! isset( $last_confirmed[ $event_id ] ) || $confirmed < $last_confirmed[ $event_id ] ) {
				$last_confirmed[ $event_id ] = $confirmed;
			}
		}

		// Least-recently-confirmed first, so the per-pass confirm budget
		// rotates instead of re-checking the same stable head every pass.
		uksort(
			$candidates,
			static function ( $a, $b ) use ( $last_confirmed ) {
				return $last_confirmed[ $a ] <=> $last_confirmed[ $b ];
			}
		);

		return $candidates;
	}

	/**
	 * Record that an event's deletion candidacy was checked against the API
	 * (regardless of outcome), so the confirm budget rotates across passes.
	 *
	 * @param array $entries Candidate entries ({post_id, sync_key} rows).
	 */
	public function mark_confirmed( array $entries ) {
		foreach ( $entries as $entry ) {
			update_post_meta( (int) $entry['post_id'], self::META_LAST_CONFIRM, time() );
		}
	}

	/**
	 * All synced post IDs for a target: registry unioned with a direct
	 * postmeta query, so a lost registry never hides imports. Direct $wpdb
	 * (not WP_Query) because calendar plugins rewrite their own post-type
	 * queries.
	 *
	 * @param string $target_id Target adapter ID.
	 * @return int[]
	 */
	public function all_synced_posts( $target_id ) {
		global $wpdb;

		$registry = $this->registry();
		$from_reg = isset( $registry[ $target_id ] ) ? array_map( 'intval', array_values( $registry[ $target_id ] ) ) : array();

		$from_meta = $wpdb->get_col(
			$wpdb->prepare(
				"SELECT pm.post_id FROM {$wpdb->postmeta} pm
				 INNER JOIN {$wpdb->posts} p ON p.ID = pm.post_id
				 WHERE pm.meta_key = %s AND pm.meta_value = %s",
				self::META_TARGET,
				$target_id
			)
		);

		return array_values( array_unique( array_merge( $from_reg, array_map( 'intval', $from_meta ) ) ) );
	}

	/**
	 * {sync_key: post_id} for a target built straight from post meta (the
	 * durable truth), lazily cached per target. Trashed posts are included
	 * on purpose: lookup() must still tombstone them.
	 *
	 * @param string $target_id Target adapter ID.
	 * @return array<string, int>
	 */
	private function meta_map( $target_id ) {
		global $wpdb;

		if ( isset( $this->meta_map_cache[ $target_id ] ) ) {
			return $this->meta_map_cache[ $target_id ];
		}

		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT k.post_id, k.meta_value AS sync_key FROM {$wpdb->postmeta} k
				 INNER JOIN {$wpdb->postmeta} t ON t.post_id = k.post_id AND t.meta_key = %s AND t.meta_value = %s
				 WHERE k.meta_key = %s",
				self::META_TARGET,
				$target_id,
				self::META_SYNC_KEY
			),
			ARRAY_A
		);

		$map = array();
		foreach ( (array) $rows as $row ) {
			$map[ (string) $row['sync_key'] ] = (int) $row['post_id'];
		}

		$this->meta_map_cache[ $target_id ] = $map;

		return $map;
	}

	/**
	 * Whether a sync key was tombstoned (user deleted the calendar event).
	 *
	 * @param string $target_id Target adapter ID.
	 * @param string $sync_key  Event sync key.
	 * @return bool
	 */
	public function is_tombstoned( $target_id, $sync_key ) {
		$tombstones = get_option( Config::OPTION_TOMBSTONES, array() );

		return isset( $tombstones[ $target_id ] ) && in_array( $sync_key, (array) $tombstones[ $target_id ], true );
	}

	/**
	 * Clear all tombstones for a target (cleanup means a fresh start).
	 *
	 * @param string $target_id Target adapter ID.
	 */
	public function clear_tombstones( $target_id ) {
		$tombstones = get_option( Config::OPTION_TOMBSTONES, array() );
		unset( $tombstones[ $target_id ] );
		update_option( Config::OPTION_TOMBSTONES, $tombstones, false );
	}

	/**
	 * Remember that the user deleted this calendar event.
	 *
	 * @param string $target_id Target adapter ID.
	 * @param string $sync_key  Event sync key.
	 */
	private function add_tombstone( $target_id, $sync_key ) {
		$tombstones = get_option( Config::OPTION_TOMBSTONES, array() );
		if ( ! isset( $tombstones[ $target_id ] ) || ! is_array( $tombstones[ $target_id ] ) ) {
			$tombstones[ $target_id ] = array();
		}
		if ( ! in_array( $sync_key, $tombstones[ $target_id ], true ) ) {
			$tombstones[ $target_id ][] = $sync_key;
			$tombstones[ $target_id ]   = array_slice( $tombstones[ $target_id ], - Config::TOMBSTONES_CAP );
			update_option( Config::OPTION_TOMBSTONES, $tombstones, false );
		}
	}

	/**
	 * @return array Current registry (in-memory cache, loaded once).
	 */
	private function registry() {
		if ( null === $this->registry_cache ) {
			$registry             = get_option( self::OPTION_REGISTRY, array() );
			$this->registry_cache = is_array( $registry ) ? $registry : array();
		}

		return $this->registry_cache;
	}

	/**
	 * Remove one registry entry (persisted on the next flush()).
	 *
	 * @param string $target_id Target adapter ID.
	 * @param string $sync_key  Event sync key.
	 */
	private function unregister( $target_id, $sync_key ) {
		$this->registry();
		unset( $this->registry_cache[ $target_id ][ $sync_key ] );
		$this->registry_dirty = true;
	}
}
