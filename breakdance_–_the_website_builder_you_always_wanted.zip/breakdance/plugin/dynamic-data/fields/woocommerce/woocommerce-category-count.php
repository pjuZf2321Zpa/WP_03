<?php

namespace Breakdance\DynamicData;

use function Breakdance\LoopBuilder\getCurrentTerm;

class WooCommerceCategoryCount extends StringField
{
    /**
     * @inheritDoc
     */
    public function label()
    {
        return __('Product Category Count', 'breakdance');
    }

    /**
     * @inheritDoc
     */
    public function category()
    {
        return __('Term', 'breakdance');
    }

    /**
     * @inheritDoc
     */
    public function slug()
    {
        return 'woocommerce_category_count';
    }

    /**
     * @inheritDoc
     */
    public function handler($attributes): StringData
    {
        /**
         * @var \WP_Term|null
         * @psalm-suppress UndefinedFunction
         */
        $term = getCurrentTerm(true);

        if (!$term instanceof \WP_Term) {
            return StringData::emptyString();
        }

        $value = get_term_meta($term->term_id, 'product_count_product_cat', true);

        if (!$value) {
            return StringData::emptyString();
        }

        return StringData::fromString($value);
    }

    /**
     * @inheritDoc
     */
    function proOnly()
    {
        return false;
    }
}
