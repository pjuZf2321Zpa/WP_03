=== Bit Assist ===
Contributors: bitpressadmin
Tags: tawk.to, knowledge base, faq, custom form, messenger, whatsapp, frequently asked questions, discord, line, snapchat, viber, wechat, sms, linkedin, tiktok, google map, slack, youtube, call, twitter, instagram, telegram.
Requires at least: 5.1
Tested up to: 7.1.4
Requires PHP: 7.4
Stable tag: 1.1.2
License: GPLv2 or later

A powerful tool to connect with your customers.

== Description ==

= Turn your website visitors into leads =

📢 **You can avail this plugin free if you tag us as your Zoho Partner. Read the details here - [Bit Apps products giveaway](https://www.bitapps.pro/zoho-partner-tag)**

📢 **Join our new community [Bit Integrations](https://www.facebook.com/groups/formsintegrations) & get updates of our new plugin.**

📢 **We are open for freelance work/custom development for this plugin. [Connect](https://bitapps.pro/contact) with us for further information.**


✨ Overview of other products we are offering :

📝 [**Bit Form**](https://wordpress.org/plugins/bit-form/): Bit Form is an amazing drag & drop form builder that allows you to create custom forms to interact with your visitors. It gives you the freedom to create any form you want, no coding required.

🚀 [**Bit Integrations**](https://wordpress.org/plugins/bit-integrations/): Send WordPress Forms, WooCommerce, LMS, Membership plugin and other data to your Google Sheet, CRM, Email Marketing Tools and other platforms.

📧 [**Bit SMTP**](https://wordpress.org/plugins/bit-smtp/): The ultimate goal of Bit SMTP plugin to make your email deliverability more easy as well as secure.

**[BitApps](https://www.bitapps.pro/)**


== Installation ==

1. Download the plugin.
2. From the WordPress Admin Panel, click on Plugins => Add New.
3. Click on Upload, so you can directly upload your plugin zip file.
4. Use the browse button to select the plugin zip file that was downloaded, and then click on Install Now.
5. Once installed, click “Activate”.


== Changelog ==

= v1.1.2 (Nov 7, 2026) =
* Fixed: License expiry notice showing the license as expired a day early.
* Feature: Reconnect button on the license page to refresh license status from the server.
* Security: Added nonce verification and output escaping on license pages.
* Improvement: Tested up to WordPress 7.1.4.

= v1.1.1 (Mar 16, 2026) =
* Fixed: Widget not showing up.

= v1.1.0 (Mar 14, 2026) =
* Feature: Translation ready -- Bit Assist is now translation-ready, allowing users to easily translate the plugin into their preferred language using standard WordPress translation tools.

= v1.0.7 (Feb 26, 2026) =
* Improvement: Addressed WordPress.org plugin review feedback

= v1.0.6 (Feb 23, 2026) =
* Fixed: Incorrect plugin basename constant reference in Updater
* Added: ABSPATH security check added to all PHP files
* Improvement: PHP CS Fixer configuration

= v1.0.5 (Feb 18, 2026) =
* Fixed: Plugin checker issue fixed.

= v1.0.3 (Nov 04, 2023) =
* Fixed: Dynamic property deprecated issue
* Fixed: placeholder not called properly in wpdb prepare function

= v1.0.2 (Dec 31, 2022) =
* Fixed: Some server blocking PUT & DELETE request

= v1.0.1 (Nov 23, 2022) =
* Fixed: Create new widget not checking if already has a active widget

= v1.0.0 (Nov 7, 2022) =
* Initial release
