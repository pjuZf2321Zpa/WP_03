<?php

/**
 * Class CFF_Swipe_View
 *
 * The PHP -> JS seam for the Reels swipe viewer (SMASH-2049 prototype).
 *
 * SMASH-1909 shipped the classification layer -- CFF_Post_Set::is_reel(),
 * get_video_source(), is_known_unplayable_source(), get_video_permalink() --
 * but emits NOTHING to the browser: its branch touches only CFF_Post_Set,
 * CFF_Parse_Pro and test config, and inc/CFF_Shortcode.php is byte-identical
 * to development. So nothing about a Reel is visible to the front end today,
 * and every line of PHP->JS plumbing is this class's.
 *
 * WHAT THIS CLASS IS FOR, in one line each:
 *
 *   is_enabled()       the prototype's lean enablement -- a DISABLE-ONLY filter
 *   feed_flags()       the `swipeView` entry on the existing data-cff-flags channel
 *   item_attributes()  the per-post seam, emitted on the media wrapper, both edges
 *   the resolvers      poster / caption / author / permalink, dispatching on edge
 *
 * TWO RULES THIS CLASS DOES NOT BREAK, both of them load-bearing:
 *
 * 1. CONSUME SMASH-1909'S CLASSIFIERS, NEVER RE-DERIVE THEM. There is exactly
 *    one /reel/ vs /videos/ predicate in this plugin and it lives in
 *    CFF_Post_Set::classify_permalink_shape(). A second copy here would drift
 *    from it silently, and the live verification that made the heuristic
 *    trustworthy (SMASH-2044, 8/8 on real Graph data across both edges) was
 *    run against THAT one.
 *
 * 2. NEVER CONSUME THE RENDER PATH'S OWN VIDEO-SOURCE MARKUP. CFF_Shortcode.php
 *    builds $cff_vid_source with a greedy `/(?<=src=").*(?=")/` that
 *    over-captures every attribute after src (proven on real-shaped data by
 *    Smash1909ReelsClassificationTest), then prints it unescaped into
 *    data-href / data-src / data-source. data-cff-video-link is worse: it is
 *    built from a hardcoded `smashballoondev` page slug with a /videos/ path
 *    shape that is simply wrong for a Reel. Everything this class emits is
 *    derived from CFF_Post_Set / CFF_Parse_Pro accessors instead.
 *
 * @since 4.13.0 (SMASH-2049 prototype)
 */

namespace CustomFacebookFeed;

use CustomFacebookFeed\Builder\CFF_Post_Set;

if (! defined('ABSPATH')) {
	exit; // Exit if accessed directly
}

class CFF_Swipe_View
{
	/**
	 * The attribute the JS routing predicate reads to decide "Reel or not".
	 *
	 * Deliberately its OWN attribute rather than a reuse of the shipped
	 * data-cff-video-action / data-cff-video-player pair. Those two are read by
	 * assets/js/cff-scripts.js on paths that rewrite data-iframe and blank
	 * data-video, and a viewer sharing their vocabulary would inherit that.
	 */
	const REEL_ATTR = 'data-cff-reel';

	/**
	 * The feed-level flag added to the existing data-cff-flags channel.
	 */
	const FEED_FLAG = 'swipeView';

	/**
	 * The customer's setting (AC 21), mirroring Instagram's
	 * `sbi_swipeview_enabled` shape: a standalone registered global option
	 * rather than an entry in `cff_style_settings`.
	 *
	 * Standalone deliberately. `cff_style_settings` is written back WHOLESALE
	 * by the settings save path, so a key living in it is only as durable as
	 * every writer of that array -- and `builder_update()` takes `$_POST`
	 * wholesale, which is the documented way `feedtype` and `sources` get
	 * wiped by a partial POST. A kill switch must not share a blast radius
	 * with that.
	 */
	const OPTION_ENABLED = 'cff_swipeview_enabled';

	/**
	 * The SEPARATE disable-only override (§10.6 / AC 21).
	 *
	 * The point of the split: under a single global setting, the kill switch IS
	 * the setting the customer configured -- so using it to stop a fleet-wide
	 * problem also silently discards their choice, and there is no way to
	 * restore it afterwards or to tell "off because we turned it off" from
	 * "off because they never turned it on". §10.4 calls that the weaker
	 * shape.
	 *
	 * This option is checked INDEPENDENTLY and can only ever disable. Setting
	 * it leaves OPTION_ENABLED untouched, so clearing it restores exactly what
	 * the customer had.
	 */
	const OPTION_DISABLED = 'cff_swipeview_disabled';

	/**
	 * THE DEFAULT, IN ONE PLACE (AC 21 / open decision 1).
	 *
	 * **OFF for v1.** The recommendation the ticket records, and the reasoning
	 * is blast radius rather than caution: this changes the click behaviour of
	 * every Reel in every timeline feed on the site, telemetry is unbuilt
	 * (SMASH-1852), and under a global setting the kill switch is the
	 * customer-configured setting unless the override above exists. A default
	 * of ON would also bind §10.4's default-ON release condition and revisit
	 * the CAAD level.
	 *
	 * One constant, so flipping it is one edit and one test line -- and so
	 * that nothing else in the codebase can encode a different opinion about
	 * what "unset" means.
	 */
	const DEFAULT_ENABLED = false;

	/**
	 * Whether the swipe viewer is enabled at all.
	 *
	 * ENABLEMENT IS DELIBERATELY LEAN IN THE PROTOTYPE. The production ticket
	 * owns the real thing: a Pro-gated GLOBAL option mirroring Instagram's
	 * `sbi_swipeview_enabled` shape, its Free-edition visibility call
	 * (hidden vs shown-and-locked) and a feed-presence enqueue gate. None of
	 * that is here, and nothing this prototype demos should imply a PER-FEED
	 * enablement control: the superseded derivation put one on `videoaction`,
	 * and showing it now would put a surface in front of the design review
	 * that production will not ship.
	 *
	 * THE FILTER IS DISABLE-ONLY, AND THAT IS THE POINT. Instagram's
	 * equivalent -- apply_filters('sbi_enable_quickscroll', $enabled) -- runs
	 * AFTER its Pro check, so `__return_true` force-enables the feature on
	 * Free. That is a licence hole wearing a kill switch's clothes. Here the
	 * filter can only ever turn the feature OFF: a truthy return disables, and
	 * a falsy return cannot enable something the base state already refused.
	 * Written as an early return on the base state so it STAYS disable-only
	 * when production replaces `true` with a real Pro-gated option read.
	 *
	 * @return bool
	 */
	public static function is_enabled()
	{
		/*
		 * GATE 1 -- PRO. The viewer is Pro-only, and on Facebook that gate is
		 * STRUCTURAL rather than a check: this class ships only in
		 * custom-facebook-feed-pro. The Free plugin is a separate codebase
		 * with no front-end video markup at all, so there is nothing there for
		 * a viewer to bind to and nothing to gate.
		 *
		 * The class-exists probe is therefore belt-and-braces for one real
		 * case: this file being loaded by something other than the Pro plugin
		 * bootstrap. It is the codebase's own Pro marker rather than a new
		 * constant.
		 */
		if (! class_exists('CustomFacebookFeed\\CFF_Feed_Pro')) {
			return false;
		}

		/*
		 * GATE 2 -- THE CUSTOMER'S SETTING. Default OFF, from the one
		 * constant. Read with an explicit default so an unset option and a
		 * stored `false` are the same answer.
		 */
		$enabled = get_option(self::OPTION_ENABLED, self::DEFAULT_ENABLED);

		if (! filter_var($enabled, FILTER_VALIDATE_BOOLEAN)) {
			return false;
		}

		/*
		 * GATE 3 -- THE SEPARATE KILL SWITCH (§10.6). Checked independently of
		 * gate 2 and able only to disable, so using it never touches what the
		 * customer chose.
		 */
		if (filter_var(get_option(self::OPTION_DISABLED, false), FILTER_VALIDATE_BOOLEAN)) {
			return false;
		}

		/*
		 * GATE 4 -- THE FILTER, AND IT STAYS DISABLE-ONLY.
		 *
		 * Instagram's equivalent runs AFTER its Pro check and is two-way,
		 * which makes it a licence hole rather than a kill switch: a filter
		 * returning true there can switch the feature ON for a site whose
		 * licence does not carry it. Ours is applied to a boolean whose falsy
		 * return cannot enable anything the gates above already refused --
		 * every gate is an early return, so by the time this runs the answer
		 * is already "yes" and the filter can only take it away.
		 */
		return ! apply_filters('cff_swipeview_disabled', false);
	}

	/*
	 * NO should_enqueue() / mark_feed_present() HERE, and that absence is the
	 * design rather than an omission.
	 *
	 * AC 21's feed-presence gate is ALREADY satisfied, by the CALL SITE:
	 * register_assets() runs on `wp_enqueue_scripts` and only REGISTERS
	 * handles (no bytes), while enqueue() -- the thing that actually loads
	 * them -- is called from CFF_Shortcode_Display::__construct(), i.e. from
	 * the render path, which by definition only runs when a feed is on the
	 * page.
	 *
	 * A first pass here added a `$feed_present` flag plus a should_enqueue()
	 * wrapper. It was removed on reading the call sites: it would have been a
	 * SECOND source of truth for a question the call graph already answers,
	 * and the failure mode of two gates is that one of them drifts and nobody
	 * notices because the other still holds.
	 *
	 * The property is pinned by a test asserting enqueue() is reached from the
	 * render path and NOT from an `wp_enqueue_scripts` hook -- which is the
	 * thing that would actually regress, since moving one `add_action` is all
	 * it takes to load ~164KB on every page of the site. That is Instagram's
	 * live behaviour and the reason this AC exists.
	 */

	/**
	 * The flags this feature contributes to the feed container's
	 * data-cff-flags attribute.
	 *
	 * Riding the EXISTING channel rather than adding a new one is the whole
	 * reason the Facebook seam is cheap. CFF_Shortcode_Display already builds
	 * data-cff-flags with `gdpr` / `overrideBlockCDN` / `locator`, and
	 * cff-scripts.js already derives per-feed settings from it -- so the
	 * granularity (per feed), the lifetime (per render) and the consent state
	 * the viewer needs are all present and already tested. It also sidesteps
	 * wp_localize_script's string-casting of booleans (false -> ""), which is
	 * the trap the YouTube lane paid for.
	 *
	 * @param array $feed_options The resolved feed settings.
	 * @return array Zero or more flag strings.
	 */
	public static function feed_flags($feed_options)
	{
		if (! self::is_enabled()) {
			return array();
		}

		return array(self::FEED_FLAG);
	}

	/**
	 * Whether a post is a Reel the viewer should bind to.
	 *
	 * A thin, deliberate pass-through to SMASH-1909. It exists so the render
	 * sites have one name to call and so the "consume, never re-derive" rule
	 * has a single enforcement point.
	 *
	 * @param object|array $post A raw (json_decode'd) post, either edge.
	 * @return bool
	 */
	public static function is_eligible($post)
	{
		return CFF_Post_Set::is_reel($post);
	}

	/**
	 * Whether this post came off the /videos edge.
	 *
	 * WHY THIS PREDICATE EXISTS AND WHY IT KEYS OFF THESE TWO FIELDS
	 * SPECIFICALLY. CFF_Shortcode.php:2282-2293 mutates timeline posts IN
	 * PLACE before rendering, hoisting `type`, `link`, `description`, `name`,
	 * `caption`, `source` and `object_id` up from attachments.data[0]. A
	 * resolver that dispatched on any of those seven would see a normalised
	 * timeline post wearing videos-edge clothes and take the wrong branch.
	 *
	 * `embed_html` and `format` are the two fields the normalisation never
	 * synthesises, and they are exactly the videos edge's own signals
	 * (CFF_Graph_Url::get_call_type_fields_args() requests both; the timeline
	 * field list in get_common_fields() requests neither). So this predicate
	 * is normalisation-proof by construction, which is pinned by a test.
	 *
	 * @param object|array $post A raw (json_decode'd) post, either edge.
	 * @return bool
	 */
	public static function is_videos_edge($post)
	{
		$arr = is_array($post) ? $post : (array) $post;

		if (isset($arr['embed_html']) && is_string($arr['embed_html']) && $arr['embed_html'] !== '') {
			return true;
		}

		return isset($arr['format']) && is_array($arr['format']) && ! empty($arr['format']);
	}

	/**
	 * The poster image for a Reel slide, on either edge.
	 *
	 * Poster is the one S9.2 metadata field SMASH-1909 does NOT expose, and it
	 * is thin in the data: `format[].picture` is present on only 2 of 7
	 * videos-edge fixture items, and timeline fixture index 3 (the DASH reel)
	 * carries `media.source` with NO `media.image` at all. A slide with
	 * neither mp4 nor poster is a black rectangle with a link, so the viewer
	 * renders that state deliberately -- which requires this resolver to
	 * report absence honestly rather than fataling on it.
	 *
	 * TWO HARDENING DECISIONS, both of them fixing a real defect:
	 *
	 * 1. `format[]` is picked by LARGEST PARSED SIZE, not `[0]`. Facebook
	 *    returns posters at fixed directive sizes -- p130x130 / p480x480 /
	 *    p720x720 -- ascending in the fixtures, so `[0]` reliably picks the
	 *    130px thumbnail for a full-screen slide. The size is parsed out of
	 *    the `stp=dst-jpg_p<W>x<H>` directive rather than trusting the array
	 *    order; when no entry yields a parseable size it falls back to the
	 *    LAST entry, which is the convention CFF_Parse_Pro::get_media_url()
	 *    already uses (`format[count-1]`).
	 *
	 * 2. The timeline read NEVER goes through CFF_Parse_Pro::get_attachment_image().
	 *    That accessor guards only `isset($attachment->media)` and then reads
	 *    `$attachment->media->image->src`, so on timeline fixture index 3
	 *    (media present, image absent -- REAL fixture data, not a hypothetical)
	 *    it reads a property on null. SMASH-1909 hardened the media.source
	 *    sibling and left this one exactly as it was.
	 *
	 * @param object|array $post A raw (json_decode'd) post, either edge.
	 * @return string The poster URL, or '' when there is none.
	 */
	public static function get_poster($post)
	{
		if (self::is_videos_edge($post)) {
			$poster = self::largest_format_picture($post);
			if ($poster !== '') {
				return $poster;
			}
		}

		$attachment = CFF_Post_Set::get_timeline_video_attachment($post);
		if (! $attachment) {
			return '';
		}

		return self::attachment_image_src($attachment);
	}

	/**
	 * Pick the largest `format[].picture` on a videos-edge post.
	 *
	 * @param object|array $post A raw (json_decode'd) videos-edge post.
	 * @return string The poster URL, or '' when there is none.
	 */
	private static function largest_format_picture($post)
	{
		$arr = is_array($post) ? $post : (array) $post;
		if (! isset($arr['format']) || ! is_array($arr['format'])) {
			return '';
		}

		$best      = '';
		$best_area = -1;
		$last      = '';

		foreach ($arr['format'] as $entry) {
			$entry_arr = is_array($entry) ? $entry : (array) $entry;
			if (! isset($entry_arr['picture'])
				|| ! is_string($entry_arr['picture'])
				|| $entry_arr['picture'] === ''
			) {
				continue;
			}

			$picture = $entry_arr['picture'];
			$last    = $picture;
			$area    = self::parse_picture_area($picture);

			if ($area > $best_area) {
				$best_area = $area;
				$best      = $picture;
			}
		}

		// No entry carried a parseable size -- fall back to the last usable
		// one, matching CFF_Parse_Pro::get_media_url()'s format[count-1].
		if ($best_area <= 0) {
			return $last;
		}

		return $best;
	}

	/**
	 * The pixel area encoded in a Facebook image URL's size directive.
	 *
	 * Facebook spells these as `stp=dst-jpg_p720x720` or `stp=...s720x720`.
	 * Both the `p` (padded) and `s` (scaled) prefixes appear in the wild, so
	 * both are matched. A URL with no directive returns 0, which the caller
	 * reads as "unknown size" rather than as "zero pixels".
	 *
	 * @param string $url An image URL.
	 * @return int The area in pixels, or 0 when no size is encoded.
	 */
	private static function parse_picture_area($url)
	{
		$matches = array();
		if (! preg_match('/[ps](\d{2,5})x(\d{2,5})/', $url, $matches)) {
			return 0;
		}

		return (int) $matches[1] * (int) $matches[2];
	}

	/**
	 * Read a timeline attachment's media.image.src without the null-property
	 * read CFF_Parse_Pro::get_attachment_image() performs.
	 *
	 * @param object|array $attachment A single timeline attachment.
	 * @return string The image URL, or '' when absent.
	 */
	private static function attachment_image_src($attachment)
	{
		if (isset($attachment->media->image->src)) {
			$src = $attachment->media->image->src;
			return is_string($src) ? $src : '';
		}

		if (! is_object($attachment) && isset($attachment['media']['image']['src'])) {
			$src = $attachment['media']['image']['src'];
			return is_string($src) ? $src : '';
		}

		return '';
	}

	/**
	 * The caption text for a Reel slide, on either edge.
	 *
	 * Caption is the second S9.2 field SMASH-1909 does not expose, and the two
	 * edges genuinely disagree about where it lives:
	 *
	 *   videos edge:   top-level `title`, then `description`. There is no
	 *                  `message` on this edge at all, and no existing accessor
	 *                  reads `title` -- CFF_Parse_Pro::get_message() reads
	 *                  `name`, which the videos edge does not have, so calling
	 *                  it here would silently return the description only.
	 *   timeline edge: the post's `message` (which for a Reel IS the caption),
	 *                  then the video attachment's `title` / `description`.
	 *
	 * Dispatch is on is_videos_edge() rather than on field presence, for the
	 * normalisation reason documented there.
	 *
	 * @param object|array $post A raw (json_decode'd) post, either edge.
	 * @return string The caption, or '' when there is none.
	 */
	public static function get_caption($post)
	{
		$arr = is_array($post) ? $post : (array) $post;

		if (self::is_videos_edge($post)) {
			$title = self::string_field($arr, 'title');
			if ($title !== '') {
				return $title;
			}
			return self::string_field($arr, 'description');
		}

		$message = self::string_field($arr, 'message');
		if ($message !== '') {
			return $message;
		}

		$attachment = CFF_Post_Set::get_timeline_video_attachment($post);
		if (! $attachment) {
			return '';
		}

		$title = CFF_Parse_Pro::get_attachment_title($attachment);
		if (is_string($title) && $title !== '') {
			return $title;
		}

		$description = CFF_Parse_Pro::get_attachment_description($attachment);
		return is_string($description) ? $description : '';
	}

	/**
	 * The author name for a Reel slide.
	 *
	 * `from{picture,id,name,link}` is include_extras-gated on BOTH edges
	 * (CFF_Graph_Url::get_call_type_fields_args() / get_common_fields()) and is
	 * absent from both SMASH-1909 fixtures -- so on a real feed this data may
	 * simply not be cached. Absence is therefore the EXPECTED case, not an
	 * error case, and the viewer must render a slide without an author byline
	 * rather than waiting for one.
	 *
	 * `owner` is checked as well because CFF_Parse_Pro::get_from_link() already
	 * treats it as the same thing on album/photo shapes.
	 *
	 * @param object|array $post A raw (json_decode'd) post, either edge.
	 * @return array{name:string,link:string,picture:string}
	 */
	public static function get_author($post)
	{
		$author = array('name' => '', 'link' => '', 'picture' => '');

		foreach (array('from', 'owner') as $key) {
			$source = self::sub_object($post, $key);
			if ($source === null) {
				continue;
			}

			$author['name']    = self::string_field($source, 'name');
			$author['link']    = self::url_field($source, 'link');
			$author['picture'] = self::author_picture($source);

			if ($author['name'] !== '' || $author['picture'] !== '') {
				return $author;
			}
		}

		return $author;
	}

	/**
	 * Graph returns `picture` either expanded as `{data:{url}}` or flattened to
	 * a bare URL string, depending on the field spelling used in the request.
	 * Both shapes appear across this plugin's call sites, so both are read.
	 *
	 * @param array $source The `from` / `owner` block, array-cast.
	 * @return string The picture URL, or '' when absent.
	 */
	private static function author_picture($source)
	{
		if (isset($source['picture'])) {
			$picture = $source['picture'];

			if (is_string($picture)) {
				return self::safe_url($picture);
			}

			$picture_arr = is_array($picture) ? $picture : (array) $picture;
			if (isset($picture_arr['data'])) {
				$data = is_array($picture_arr['data']) ? $picture_arr['data'] : (array) $picture_arr['data'];
				return self::url_field($data, 'url');
			}
		}

		return '';
	}

	/**
	 * The canonical, human-clickable permalink for a Reel -- the value the
	 * terminal tier's "Open on Facebook" link and the caption CTA both use.
	 *
	 * THIS WRAPPER IS NOT CEREMONY; IT CLOSES TWO REAL HOLES IN THE 1909
	 * ACCESSOR IT CALLS.
	 *
	 * Hole 1 -- the graceful degrade is INDISTINGUISHABLE from success.
	 * CFF_Post_Set::get_video_permalink() returns the
	 * `.../plugins/video.php?href=...` WRAPPER url when the href decode fails,
	 * as a deliberate degrade (it is still a clickable Facebook destination).
	 * But a caller cannot tell that from a real permalink, and
	 * swipe-view-experience-spec S9.1 requires the terminal tier's link to be
	 * the same normalised permalink the caption CTA uses. So sniff it: an
	 * embed wrapper is not a permalink for our purposes, and we report absence
	 * instead of linking a slide's "Open on Facebook" at an embed frame.
	 *
	 * Hole 2 -- the value is NEITHER escaped NOR host-validated.
	 * decode_embed_href() returns whatever parse_str() yields for `href`, which
	 * is attacker-influenced third-party data replayed out of a cache and can
	 * carry ANY scheme -- `javascript:` included. Validating the scheme and
	 * host HERE rather than relying on esc_url() at the sink means the guard is
	 * unit-testable without WordPress, and means a future sink that forgets to
	 * escape still cannot receive a hostile value from this method.
	 *
	 * @param object|array $post A raw (json_decode'd) post, either edge.
	 * @return string The permalink, or '' when one cannot be recovered safely.
	 */
	public static function get_permalink($post)
	{
		$permalink = CFF_Post_Set::get_video_permalink($post);
		if (! is_string($permalink) || $permalink === '') {
			return '';
		}

		// Hole 1: the wrapper-as-permalink degrade.
		if (strpos($permalink, 'plugins/video.php') !== false) {
			return '';
		}

		// Hole 2: scheme + host.
		return self::safe_facebook_url($permalink);
	}

	/**
	 * The interaction counts for a Reel slide -- likes and comments, on either
	 * edge, with ABSENCE AND ZERO KEPT DISTINCT.
	 *
	 * This exists because the ratified Instagram grammar (spec S6.1's counts
	 * readout, SMASH-1851) requires a metric the data does not carry to be
	 * OMITTED rather than rendered as zero. "0 likes" on a Reel with thousands
	 * is a worse answer than no readout at all, and the two cases are genuinely
	 * different here rather than theoretically:
	 *
	 *   timeline edge: counts are requested UNCONDITIONALLY -- `shares`,
	 *                  `comments.summary(true).limit(0)`, and either
	 *                  `likes.summary(true).limit(0)` (page) or
	 *                  `reactions.summary(true)` (group), all in
	 *                  CFF_Graph_Url::get_call_type_fields_args()'s
	 *                  timeline `common_fields`. So a real cache HAS them.
	 *   videos edge:   likes/comments are `include_extras`-GATED
	 *                  (CFF_Graph_Url.php:161), exactly like `from`. So on a
	 *                  videos-edge feed without that setting the counts are
	 *                  legitimately absent and the rail must close up.
	 *
	 * Neither SMASH-1909 fixture carries counts at all (both were derived for
	 * the classification concern), which is itself the reason absence is the
	 * case to get right first.
	 *
	 * THREE HOLES THIS WRAPPER CLOSES, all in the accessors it would otherwise
	 * just forward to:
	 *
	 * 1. `CFF_Parse_Pro::get_likes_count()` reads ONLY `likes`, never
	 *    `reactions`. On a GROUP timeline feed the request asks for
	 *    `reactions.summary(true)` and NOT `likes` (`CFF_Graph_Url.php:174-183`),
	 *    so that accessor returns '' for a post whose reaction count is cached
	 *    and real. The plugin's own display path already knows this and
	 *    branches on `$cff_is_group` (`CFF_Shortcode_Display.php:1754-1756`) --
	 *    but the seam is called with only `$news` (`CFF_Shortcode.php:4149`,
	 *    `:4999`), no group flag. So dispatch on the SHAPE instead: a cached
	 *    `reactions.summary.total_count` is the group answer and is checked
	 *    first, `likes` second. Shape-dispatch needs no new argument at either
	 *    render site and cannot disagree with the request that produced it.
	 *
	 * 2. The display path's comment read is guarded by
	 *    `!empty($news->comments->data)` (`CFF_Shortcode_Display.php:1759`) --
	 *    and the timeline request is `comments.summary(true).limit(0)`, whose
	 *    whole point is that `data` comes back EMPTY while `summary.total_count`
	 *    is real. That guard therefore reports 0 for every post with a genuine
	 *    comment count. Do not clone it. `CFF_Parse_Pro::get_comments_count()`
	 *    has no such guard and is the correct accessor.
	 *
	 * 3. Both accessors return the RAW cached value -- '' on absence, but
	 *    otherwise whatever json_decode produced, which for a Graph summary is
	 *    an int and for a hand-edited cache could be anything. Normalising to
	 *    "non-negative integer or null" here means the viewer never has to
	 *    decide what a malformed count means.
	 *
	 * SHARES IS NOW RETURNED, reversing this method's own earlier note.
	 *
	 * That note said shares was available-but-unrendered because "the ratified
	 * rail grammar is Instagram's, which is likes + comments and carries no
	 * third glyph". Instagram's rail dropped its share item in `9362ef34`, and
	 * that was the right call THERE: the rail rule is parity with what the
	 * plugin itself displays elsewhere, and Instagram exposes no share count.
	 *
	 * Facebook's answer comes out differently on the same rule, and it was
	 * settled by reading the plugin rather than by preference. The tile meta
	 * box prints all three -- `templates/item/likes-comments-box.php` renders
	 * `.cff-likes` with a `Reactions:` screen-reader label, and
	 * `CFF_Shortcode_Display::print_metabox_comment_icon()` and
	 * `::print_metabox_share_icon()` render `.cff-comments` and `.cff-shares`
	 * the same way. The timeline request asks for `shares` unconditionally
	 * (`CFF_Graph_Url.php`). So the parity floor -- never omit a metric the
	 * plugin shows elsewhere -- REQUIRES the third item here, and dropping it
	 * would be the first time this viewer showed less than the tile the visitor
	 * clicked.
	 *
	 * The shape differs from the other two and is read accordingly: `shares` is
	 * a bare `{count: n}` object, NOT a `summary.total_count` one, so it needs
	 * its own accessor rather than summary_total(). Getting that wrong reads as
	 * "no shares on any post" -- absent, which the viewer renders as a
	 * glyph-only item, so it would degrade quietly rather than fail.
	 *
	 * @param object|array $post A raw (json_decode'd) post, either edge.
	 * @return array{likes:int|null,comments:int|null,shares:int|null}
	 */
	public static function get_counts($post)
	{
		return array(
			'likes'    => self::reaction_count($post),
			'comments' => self::count_or_null(CFF_Parse_Pro::get_comments_count($post)),
			'shares'   => self::share_count($post),
		);
	}

	/**
	 * The share count.
	 *
	 * `shares` does NOT carry a Graph summary. It is a bare `{count: n}`
	 * object, so summary_total() -- which is right for `likes`, `reactions`
	 * and `comments` -- returns null for it every time. That is the quiet
	 * failure this separate accessor exists to avoid: a null reads as
	 * "absent", and absence is a legitimate state the viewer renders as a
	 * glyph-only item, so the mistake would have looked like "this Page's
	 * posts have no shares" rather than like a bug.
	 *
	 * Timeline requests `shares` unconditionally; the videos edge carries it
	 * only under `include_extras`, so null here is genuinely common and is not
	 * an error.
	 *
	 * @param object|array $post A raw (json_decode'd) post, either edge.
	 * @return int|null The count, or null when none is cached.
	 */
	private static function share_count($post)
	{
		$block = self::sub_object($post, 'shares');
		if ($block === null || ! isset($block['count'])) {
			return null;
		}

		return self::count_or_null($block['count']);
	}

	/**
	 * The "likes"-slot count, dispatching on cached shape rather than on a
	 * group flag the seam is not given. See get_counts() hole 1.
	 *
	 * @param object|array $post A raw (json_decode'd) post, either edge.
	 * @return int|null The count, or null when none is cached.
	 */
	private static function reaction_count($post)
	{
		$reactions = self::summary_total($post, 'reactions');
		if ($reactions !== null) {
			return $reactions;
		}

		return self::count_or_null(CFF_Parse_Pro::get_likes_count($post));
	}

	/**
	 * Read `<field>.summary.total_count` off either post shape.
	 *
	 * Only the direct `summary` position is read, not the `data[0].summary`
	 * fallback the 1909-era accessors carry: that shape comes from a
	 * differently-composed request and, where it exists, `likes` is what is
	 * cached -- so the `likes` accessor already covers it.
	 *
	 * @param object|array $post  The post.
	 * @param string       $field `likes` or `reactions`.
	 * @return int|null The count, or null when absent or malformed.
	 */
	private static function summary_total($post, $field)
	{
		$block = self::sub_object($post, $field);
		if ($block === null || ! isset($block['summary'])) {
			return null;
		}

		$summary = is_array($block['summary']) ? $block['summary'] : (array) $block['summary'];
		if (! isset($summary['total_count'])) {
			return null;
		}

		return self::count_or_null($summary['total_count']);
	}

	/**
	 * Normalise a cached count to a non-negative integer, or null.
	 *
	 * The server-side half of the absence-is-not-zero contract, and the mirror
	 * of the viewer's own parseCount(). '' is what both 1909-era accessors
	 * return on absence; a negative or non-numeric value is a corrupt cache
	 * entry and is treated as absence rather than coerced to 0, because a
	 * rendered 0 is a claim about the post and null is not.
	 *
	 * A REAL ZERO SURVIVES. `is_numeric('0')` is true, so a post with a genuine
	 * zero comment count renders "0" -- which is the correct, different answer
	 * from omitting the metric.
	 *
	 * @param mixed $raw The cached value.
	 * @return int|null
	 */
	private static function count_or_null($raw)
	{
		if ($raw === null || $raw === '' || is_bool($raw) || is_array($raw) || is_object($raw)) {
			return null;
		}

		if (! is_numeric($raw)) {
			return null;
		}

		$value = (int) $raw;

		return $value < 0 ? null : $value;
	}

	/**
	 * The tier-2 embed url -- Facebook's OWN generated embed markup, extracted.
	 *
	 * Available on the videos edge only: `embed_html` is never requested and
	 * never cached on the timeline edge, so a timeline tier 2 would have to be
	 * PERMALINK-BUILT, which puts it inside spec S5.3's rule (a permalink-built
	 * embed is not a CDN asset, blocking_cdn() never inspects it, and the
	 * plugin's own GDPR gate does not discharge it). This prototype does not
	 * build one: the attribute is simply absent on the timeline edge, and the
	 * viewer reads that absence as "no embed tier here".
	 *
	 * @param object|array $post A raw (json_decode'd) post, either edge.
	 * @return string The embed iframe src, or '' when there is none.
	 */
	public static function get_embed_src($post)
	{
		$iframe_html = CFF_Parse_Pro::get_iframe_html($post);
		if (! is_string($iframe_html) || $iframe_html === '') {
			return '';
		}

		$src = CFF_Parse_Pro::get_embed_iframe_src($iframe_html);
		if (! is_string($src) || $src === '') {
			return '';
		}

		return self::safe_facebook_url($src);
	}

	/**
	 * The playable direct source for the native tier, or '' when the viewer
	 * should decline it up front.
	 *
	 * The decline is SMASH-1909's is_known_unplayable_source() -- a .mpd
	 * manifest or an absent source -- and declining before rendering is the
	 * point: spec S5.4 exists so a slide does not pay a visible failed-load
	 * round-trip to discover what the cache already knows.
	 *
	 * PRECONDITION: call on a post already known to be a Reel.
	 * is_known_unplayable_source() reports TRUE for anything that is not a
	 * video at all (it has no source), so calling this on a photo post returns
	 * '' -- correct here, but not a statement that the photo is broken.
	 *
	 * @param object|array $post A post already known to be a video/Reel.
	 * @return string The mp4 URL, or '' when known-unplayable.
	 */
	public static function get_playable_source($post)
	{
		if (CFF_Post_Set::is_known_unplayable_source($post)) {
			return '';
		}

		$source = CFF_Post_Set::get_video_source($post);
		if (! is_string($source) || $source === '') {
			return '';
		}

		return self::safe_url($source);
	}

	/**
	 * The per-post seam: the data-* attributes the viewer reads off the media
	 * wrapper, for BOTH edges.
	 *
	 * Emitted ONLY for eligible posts. A non-Reel gets an empty string, so the
	 * routing predicate's "is there a data-cff-reel host above this anchor"
	 * question has exactly one honest answer per post, and a photo can never
	 * accidentally satisfy it.
	 *
	 * Returns a leading-space-prefixed attribute string ready to concatenate
	 * into an open tag, which is the idiom every render site here already uses.
	 *
	 * @param object|array $post A raw (json_decode'd) post, either edge.
	 * @return string The attribute string, or '' when the post is not eligible.
	 */
	public static function item_attributes($post)
	{
		if (! self::is_enabled() || ! self::is_eligible($post)) {
			return '';
		}

		$attrs = array(self::REEL_ATTR . '="1"');

		$source = self::get_playable_source($post);
		if ($source !== '') {
			$attrs[] = 'data-cff-swipe-src="' . esc_attr($source) . '"';
		} else {
			// Say it out loud rather than leaving the viewer to infer absence
			// from a missing attribute: the two cases (no source cached vs a
			// source we declined) are the same to the viewer, but "declined"
			// is the one worth being able to count in the field.
			$attrs[] = 'data-cff-swipe-unplayable="1"';
		}

		$embed = self::get_embed_src($post);
		if ($embed !== '') {
			$attrs[] = 'data-cff-swipe-embed="' . esc_attr($embed) . '"';
		}

		$permalink = self::get_permalink($post);
		if ($permalink !== '') {
			$attrs[] = 'data-cff-swipe-permalink="' . esc_attr($permalink) . '"';
		}

		$poster = self::get_poster($post);
		if ($poster !== '') {
			$attrs[] = 'data-cff-swipe-poster="' . esc_attr(self::safe_url($poster)) . '"';
		}

		$caption = self::get_caption($post);
		if ($caption !== '') {
			$attrs[] = 'data-cff-swipe-caption="' . esc_attr($caption) . '"';
		}

		$author = self::get_author($post);
		if ($author['name'] !== '') {
			$attrs[] = 'data-cff-swipe-author="' . esc_attr($author['name']) . '"';
		}
		if ($author['picture'] !== '') {
			$attrs[] = 'data-cff-swipe-author-img="' . esc_attr($author['picture']) . '"';
		}
		/*
		 * The Page link, and it is emitted rather than constructed.
		 *
		 * Instagram builds its profile URL from the handle through a strict
		 * allowlist, because its feed emits no profile link. Facebook DOES emit
		 * one: get_author() already resolves `link` from `from{link}` /
		 * `owner{link}` and runs it through url_field(). It simply was never
		 * put on the element.
		 *
		 * Constructing it from the Page NAME is not an option and is worth
		 * saying so: Facebook Page names are free text with spaces and
		 * punctuation, so there is no allowlist analogue and any construction
		 * would be a guess that resolves to somebody else's Page.
		 *
		 * Absence is real and is handled downstream rather than papered over:
		 * with no safe link the author row degrades to a plain <div> (the name
		 * and avatar still render, they just do not link) and the Follow pill
		 * is OMITTED entirely, because a Follow pill that links nowhere is a
		 * promise the UI cannot keep.
		 */
		if ($author['link'] !== '') {
			$attrs[] = 'data-cff-swipe-author-link="' . esc_attr($author['link']) . '"';
		}

		// Counts: the attribute is ABSENT when the metric is, never "0". The
		// viewer reads a missing attribute as "omit this readout" and a present
		// "0" as a real zero -- which is why these are emitted with an
		// identity check rather than the truthiness test every other value
		// above uses. `if ($counts['likes'])` would silently drop a genuine
		// zero into the absent case and lose exactly the distinction
		// get_counts() exists to preserve.
		$counts = self::get_counts($post);
		if ($counts['likes'] !== null) {
			$attrs[] = 'data-cff-swipe-likes="' . esc_attr((string) $counts['likes']) . '"';
		}
		if ($counts['comments'] !== null) {
			$attrs[] = 'data-cff-swipe-comments="' . esc_attr((string) $counts['comments']) . '"';
		}
		if ($counts['shares'] !== null) {
			$attrs[] = 'data-cff-swipe-shares="' . esc_attr((string) $counts['shares']) . '"';
		}

		return ' ' . implode(' ', $attrs);
	}

	/**
	 * Read a top-level string field off either post shape.
	 *
	 * @param array  $arr   The post, array-cast.
	 * @param string $field The field name.
	 * @return string The value, or '' when absent or not a string.
	 */
	private static function string_field($arr, $field)
	{
		if (! isset($arr[ $field ])) {
			return '';
		}

		$value = $arr[ $field ];
		return is_string($value) ? $value : '';
	}

	/**
	 * Read a top-level field as a scheme-validated URL.
	 *
	 * @param array  $arr   The post, array-cast.
	 * @param string $field The field name.
	 * @return string The URL, or '' when absent or unusable.
	 */
	private static function url_field($arr, $field)
	{
		return self::safe_url(self::string_field($arr, $field));
	}

	/**
	 * Array-cast a nested block off either post shape.
	 *
	 * @param object|array $post The post.
	 * @param string       $key  The block name.
	 * @return array|null The block, array-cast, or null when absent.
	 */
	private static function sub_object($post, $key)
	{
		$arr = is_array($post) ? $post : (array) $post;
		if (! isset($arr[ $key ])) {
			return null;
		}

		$block = $arr[ $key ];
		if (is_array($block)) {
			return $block;
		}
		if (is_object($block)) {
			return (array) $block;
		}

		return null;
	}

	/**
	 * Accept only http(s) absolute urls.
	 *
	 * Everything this class emits originates in third-party data replayed out
	 * of an encrypted cache, so the scheme is not a given. Anything that is not
	 * plainly http or https -- `javascript:`, `data:`, a protocol-relative
	 * fragment, a bare path -- is dropped rather than escaped, because a
	 * slide with no poster is a known, rendered state and a slide with a
	 * hostile poster is not.
	 *
	 * @param string $url Candidate url.
	 * @return string The url, or '' when it is not an http(s) absolute url.
	 */
	private static function safe_url($url)
	{
		if (! is_string($url) || $url === '') {
			return '';
		}

		$scheme = strtolower((string) parse_url($url, PHP_URL_SCHEME));
		if ($scheme !== 'http' && $scheme !== 'https') {
			return '';
		}

		if (parse_url($url, PHP_URL_HOST) === null) {
			return '';
		}

		return $url;
	}

	/**
	 * Accept only http(s) urls on a facebook.com host.
	 *
	 * Applied to the permalink and the embed src -- the two values that become
	 * a NAVIGATION target rather than a media reference. A cached permalink
	 * pointing somewhere other than Facebook is not a Reel's permalink, and
	 * sending a visitor there from a "View on Facebook" affordance would be a
	 * redirect the plugin never intended to offer.
	 *
	 * @param string $url Candidate url.
	 * @return string The url, or '' when it is not a facebook.com http(s) url.
	 */
	private static function safe_facebook_url($url)
	{
		$safe = self::safe_url($url);
		if ($safe === '') {
			return '';
		}

		$host = strtolower((string) parse_url($safe, PHP_URL_HOST));
		if ($host !== 'facebook.com' && substr($host, -13) !== '.facebook.com') {
			return '';
		}

		return $safe;
	}

	/**
	 * Register the viewer bundle on wp_enqueue_scripts.
	 *
	 * Register early, enqueue late -- the same split the plugin already uses
	 * for `cffscripts` (registered in Custom_Facebook_Feed_Pro, enqueued from
	 * the shortcode when cff_enqueue_with_shortcode is on). Registering here
	 * costs nothing on a page with no feed; the enqueue is what loads bytes.
	 *
	 * The bundle is plain ES5 in its own file because assets/js/cff-scripts.js
	 * is hand-minified with no bundler (package.json is @wordpress/scripts for
	 * the Gutenberg block only). Same constraint the YouTube shell accepts.
	 *
	 * NO JQUERY DEPENDENCY, and that is deliberate. The routing split has to
	 * run in the CAPTURE phase to get in front of the lightbox's own delegated
	 * bubble handler on `body`, and jQuery has no capture-phase API at all. A
	 * jQuery dependency here would be a dependency the one load-bearing line
	 * cannot use.
	 *
	 * @return void
	 */
	public static function register_assets()
	{
		if (! self::is_enabled()) {
			return;
		}

		wp_register_style(
			'cff-swipeview',
			CFF_PLUGIN_URL . 'assets/css/cff-swipeview.css',
			array(),
			CFFVER
		);

		wp_register_script(
			'cff-swipeview',
			CFF_PLUGIN_URL . 'assets/js/cff-swipeview.js',
			array(),
			CFFVER,
			true
		);
	}

	/**
	 * Enqueue the viewer bundle for a feed that is actually on the page.
	 *
	 * Called from the render path, so the load is FEED-PRESENCE GATED -- one of
	 * the four conscious divergences from Instagram's implementation, whose
	 * enqueue loads ~164 KB of JS and CSS on every front-end page of a Pro site
	 * with the setting on, feed or no feed.
	 *
	 * @return void
	 */
	public static function enqueue()
	{
		if (! self::is_enabled()) {
			return;
		}

		wp_enqueue_style('cff-swipeview');
		wp_enqueue_script('cff-swipeview');
	}
}
