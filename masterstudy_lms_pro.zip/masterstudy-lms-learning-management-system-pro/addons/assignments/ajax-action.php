<?php

use MasterStudy\Lms\Pro\addons\assignments\Repositories\AssignmentStudentRepository;
use MasterStudy\Lms\Pro\AddonsPlus\Grades\Services\GradeDisplay;

/**
 * Adds assignments attachments.
 *
 * @return void
 */
function stm_lms_add_assignment_attachment() {
	check_ajax_referer( 'wp_rest', 'nonce' );

	if ( ! current_user_can( 'upload_files' ) && ! is_user_logged_in() ) {
		wp_send_json_error( array( 'message' => 'You do not have permission to upload files.' ) );

		return;
	}

	$attachment    = isset( $_POST['attachment'] ) && is_array( $_POST['attachment'] ) ? $_POST['attachment'] : array();
	$post_id       = intval( $_POST['post_id'] ?? 0 );
	$course_id     = intval( $_POST['course_id'] ?? 0 );
	$is_created    = rest_sanitize_boolean( $_POST['is_created'] ?? false );
	$is_review     = rest_sanitize_boolean( $_POST['is_review'] ?? false );
	$attachment_id = intval( $_POST['attachment_id'] ?? ( $attachment['id'] ?? 0 ) );

	if ( $attachment_id && $post_id ) {
		$is_attached      = false;
		$attached_post_id = get_post_field( 'post_parent', $attachment_id );

		if ( $attached_post_id > 0 && ! $is_created ) {
			global $wp_filesystem;
			if ( ! is_a( $wp_filesystem, 'WP_Filesystem_Base' ) ) {
				require_once ABSPATH . 'wp-admin/includes/file.php';
				WP_Filesystem();
			}

			$file_path = get_attached_file( $attachment_id );
			if ( empty( $file_path ) ) {
				wp_send_json_error( array( 'message' => 'Attachment file not found.' ) );
				return;
			}

			$filename = basename( $file_path ? $file_path : '' );

			if ( empty( $filename ) && ! empty( $attachment['filename'] ) ) {
				$filename = basename( sanitize_file_name( $attachment['filename'] ) );
			}

			if ( empty( $filename ) ) {
				wp_send_json_error( array( 'message' => 'Invalid attachment file.' ) );
				return;
			}

			$file_extension = strtolower( pathinfo( $filename, PATHINFO_EXTENSION ) );

			$assignment_settings = STM_LMS_Assignments::stm_lms_get_settings();
			$files_extension     = $assignment_settings['files_ext'] ?? '';
			$allowed_types       = array_map( 'trim', explode( ',', $files_extension ) );

			if ( ! in_array( $file_extension, $allowed_types, true ) ) {
				wp_send_json_error( array( 'message' => 'Disallowed file type: ' . $file_extension ) );
				return;
			}

			$file_dir     = str_replace( basename( $file_path ), '', $file_path );
			$file_name    = wp_unique_filename( $file_dir, $filename );
			$updated_path = trailingslashit( $file_dir ) . $file_name;

			if ( $wp_filesystem->copy( $file_path, $updated_path, true ) ) {
				$wp_filetype = wp_check_filetype( $file_name, null );
				if ( empty( $wp_filetype['type'] ) ) {
					$wp_filetype['type'] = get_post_mime_type( $attachment_id );
				}
				$insert_args = array(
					'post_mime_type' => $wp_filetype['type'],
					'post_parent'    => $post_id,
					'post_title'     => preg_replace( '/\.[^.]+$/', '', $file_name ),
					'post_content'   => '',
					'post_status'    => 'inherit',
				);

				$attachment_id = wp_insert_attachment( $insert_args, $updated_path, $post_id );

				if ( ! is_wp_error( $attachment_id ) ) {
					require_once ABSPATH . 'wp-admin/includes/image.php';

					$attachment_data = wp_generate_attachment_metadata( $attachment_id, $updated_path );
					wp_update_attachment_metadata( $attachment_id, $attachment_data );
					$is_attached = true;
				}
			}
		} else {
			$updated_attachment = wp_update_post(
				array(
					'ID'          => $attachment_id,
					'post_parent' => $post_id,
				)
			);

			$is_attached = ! is_wp_error( $updated_attachment );
		}

		if ( $is_attached ) {
			$attachment_type = $is_review ? 'instructor_attachments' : 'student_attachments';

			$attachments   = get_post_meta( $post_id, $attachment_type, true );
			$attachments   = ! empty( $attachments ) ? $attachments : array();
			$attachments[] = $attachment_id;

			if ( ! $is_review ) {
				update_post_meta( $post_id, 'course_id', $course_id );
			}

			update_post_meta( $post_id, $attachment_type, array_unique( $attachments ) );

			$attachment_author_id = (int) get_post_field( 'post_author', $post_id );
			update_post_meta( $attachment_id, 'attachment_author', $attachment_author_id );

			wp_send_json_success(
				array(
					'files_formats' => ms_plugin_files_formats(),
					'icon_url'      => STM_LMS_URL . '/assets/icons/files/new/',
				)
			);
		}
	}
	wp_send_json_error();
}
add_action( 'wp_ajax_stm_lms_add_assignment_attachment', 'stm_lms_add_assignment_attachment' );

/**
 * Deletes/deataches assignments attachments.
 *
 * @return void
 */
function stm_lms_delete_assignment_attachment() {
	check_ajax_referer( 'wp_rest', 'nonce' );

	$attachment_id   = intval( $_POST['attachment_id'] );
	$post_id         = intval( $_POST['post_id'] );
	$attachment_type = rest_sanitize_boolean( $_POST['is_review'] ) ? 'instructor_attachments' : 'student_attachments';
	$is_author       = (int) get_post_meta( $attachment_id, 'attachment_author', true ) === get_current_user_id();

	if ( ! $is_author && 'student_attachments' === $attachment_type ) {
		return;
	} elseif ( ! current_user_can( 'upload_files' ) && 'instructor_attachments' === $attachment_type ) {
		return;
	}

	if ( wp_delete_attachment( $attachment_id, true ) ) {
		$attachments = get_post_meta( $post_id, $attachment_type, true );

		if ( ! empty( $attachments ) ) {
			$key = array_search( $attachment_id, $attachments, true );

			if ( false !== $key ) {
				unset( $attachments[ $key ] );
				update_post_meta( $post_id, $attachment_type, $attachments );
			}
		}

		wp_send_json_success();
	}

	wp_send_json_error();
}
add_action( 'wp_ajax_stm_lms_delete_assignment_attachment', 'stm_lms_delete_assignment_attachment' );

function masterstudy_lms_process_student_assignment_review( int $assignment_id, array $payload ): array {
	$status = sanitize_text_field( $payload['status'] ?? '' );
	$review = wp_kses_post( $payload['review'] ?? '' );

	$student_id = get_post_meta( $assignment_id, 'student_id', true );
	$course_id  = get_post_meta( $assignment_id, 'course_id', true );

	wp_update_post(
		array(
			'ID'          => $assignment_id,
			'post_status' => 'publish',
		)
	);

	update_post_meta( $assignment_id, 'editor_comment', $review );
	update_post_meta( $assignment_id, 'who_view', 0 );

	// Update Assignment Grade
	if ( STM_LMS_Helpers::is_pro_plus() && is_ms_lms_addon_enabled( 'grades' ) && function_exists( 'masterstudy_lms_update_user_assignment_grade' ) ) {
		$sanitized_payload = array(
			'editor_comment' => $review,
			'grade-type'     => sanitize_text_field( $payload['grade-type'] ?? '' ),
			'grade'          => sanitize_text_field( $payload['grade'] ?? '' ),
			'point'          => sanitize_text_field( $payload['point'] ?? '' ),
			'percent'        => absint( $payload['percent'] ?? 0 ),
		);

		$status = masterstudy_lms_update_user_assignment_grade( $assignment_id, $sanitized_payload, $status );
	}

	// Update Assignment Status (preserve current status when none provided)
	if ( '' !== $status ) {
		( new AssignmentStudentRepository() )->update_status( $assignment_id, $status );
	}

	STM_LMS_Course::update_course_progress( $student_id, $course_id );

	if ( STM_LMS_Instructor::is_instructor() ) {
		$student = STM_LMS_User::get_current_user( $student_id );

		$message = esc_html__( 'Your assignment has been checked', 'masterstudy-lms-learning-management-system-pro' );

		$grade           = ( new AssignmentStudentRepository() )->get_grade( $assignment_id );
		$assignment_mark = $grade;

		if ( is_ms_lms_addon_enabled( 'grades' ) && class_exists( GradeDisplay::class ) ) {
			$assignment_mark = GradeDisplay::get_instance()->simple_render( $grade );
		}

		$last_attempt    = ( new AssignmentStudentRepository() )->get_last_attempt( $course_id, $assignment_id, $student_id );
		$status          = $last_attempt['status'] ?? false;
		$status_messages = array(
			'passed'     => __( 'You passed assignment.', 'masterstudy-lms-learning-management-system-pro' ),
			'pending'    => __( 'Your assignment pending review.', 'masterstudy-lms-learning-management-system-pro' ),
			'not_passed' => __( 'You failed assignment.', 'masterstudy-lms-learning-management-system-pro' ),
		);

		$email_data = array(
			'message'            => $message,
			'blog_name'          => STM_LMS_Helpers::masterstudy_lms_get_site_name(),
			'site_url'           => \MS_LMS_Email_Template_Helpers::link( \STM_LMS_Helpers::masterstudy_lms_get_site_url() ),
			'assignment_result'  => $status_messages[ $status ] ?? '',
			'assignment_comment' => get_post_meta( $assignment_id, 'editor_comment', true ),
			'assignment_mark'    => $assignment_mark,
			'assignment_url'     => \MS_LMS_Email_Template_Helpers::link( STM_LMS_Lesson::get_lesson_url( $course_id, $assignment_id ) ),
			'assignment_title'   => get_the_title( $assignment_id ),
			'course_title'       => get_the_title( $course_id ),
			'user_login'         => \STM_LMS_Helpers::masterstudy_lms_get_user_full_name_or_login( $student_id ),
			'instructor_name'    => \STM_LMS_Helpers::masterstudy_lms_get_user_full_name_or_login( \STM_LMS_Helpers::masterstudy_lms_get_post_author_id_by_post_id( $assignment_id ) ),
			'date'               => current_time( 'mysql' ),
		);

		STM_LMS_Helpers::send_email(
			$student['email'],
			esc_html__( 'Assignment status change.', 'masterstudy-lms-learning-management-system-pro' ),
			$message,
			'stm_lms_assignment_checked',
			$email_data
		);
	}

	do_action( 'stm_lms_assignment_' . $status, $student_id, $assignment_id, $course_id );

	return array(
		'status' => $status,
		'grade'  => ( new AssignmentStudentRepository() )->get_grade( $assignment_id ),
	);
}

function stm_lms_assignment_student_answer() {
	check_ajax_referer( 'wp_rest', 'nonce' );

	if ( ! STM_LMS_Instructor::is_instructor() ) {
		return;
	}

	$assignment_id = intval( $_POST['assignment_id'] );

	masterstudy_lms_process_student_assignment_review(
		$assignment_id,
		array(
			'status'     => $_POST['status'] ?? '',
			'review'     => $_POST['review'] ?? '',
			'grade-type' => $_POST['grade-type'] ?? '',
			'grade'      => $_POST['grade'] ?? '',
			'point'      => $_POST['point'] ?? '',
			'percent'    => $_POST['percent'] ?? '',
		)
	);

	wp_send_json_success();
}
add_action( 'wp_ajax_stm_lms_assignment_student_answer', 'stm_lms_assignment_student_answer' );
