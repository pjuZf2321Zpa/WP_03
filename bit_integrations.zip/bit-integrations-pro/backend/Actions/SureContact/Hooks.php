<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Actions\SureContact\SureContactHelperPro;
use BitApps\IntegrationsPro\Config;
use BitApps\IntegrationsPro\Core\Util\Hooks;

Hooks::filter(Config::withFreePrefix('sure_contact_add_contacts_to_list'), [SureContactHelperPro::class, 'addContactsToList'], 10, 4);
Hooks::filter(Config::withFreePrefix('sure_contact_add_contacts_to_tag'), [SureContactHelperPro::class, 'addContactsToTag'], 10, 4);
Hooks::filter(Config::withFreePrefix('sure_contact_attach_contacts_to_task'), [SureContactHelperPro::class, 'attachContactsToTask'], 10, 4);
Hooks::filter(Config::withFreePrefix('sure_contact_attach_lists_to_contact'), [SureContactHelperPro::class, 'attachListsToContact'], 10, 4);
Hooks::filter(Config::withFreePrefix('sure_contact_attach_tags_to_contact'), [SureContactHelperPro::class, 'attachTagsToContact'], 10, 4);
Hooks::filter(Config::withFreePrefix('sure_contact_bulk_delete_campaigns'), [SureContactHelperPro::class, 'bulkDeleteCampaigns'], 10, 4);
Hooks::filter(Config::withFreePrefix('sure_contact_cancel_purchase'), [SureContactHelperPro::class, 'cancelPurchase'], 10, 4);
Hooks::filter(Config::withFreePrefix('sure_contact_copy_list'), [SureContactHelperPro::class, 'copyList'], 10, 4);
Hooks::filter(Config::withFreePrefix('sure_contact_create_campaign'), [SureContactHelperPro::class, 'createCampaign'], 10, 4);
Hooks::filter(Config::withFreePrefix('sure_contact_create_contact'), [SureContactHelperPro::class, 'createContact'], 10, 4);
Hooks::filter(Config::withFreePrefix('sure_contact_create_contact_activity'), [SureContactHelperPro::class, 'createContactActivity'], 10, 4);
Hooks::filter(Config::withFreePrefix('sure_contact_create_contact_note'), [SureContactHelperPro::class, 'createContactNote'], 10, 4);
Hooks::filter(Config::withFreePrefix('sure_contact_create_list'), [SureContactHelperPro::class, 'createList'], 10, 4);
Hooks::filter(Config::withFreePrefix('sure_contact_create_page'), [SureContactHelperPro::class, 'createPage'], 10, 4);
Hooks::filter(Config::withFreePrefix('sure_contact_create_purchase'), [SureContactHelperPro::class, 'createPurchase'], 10, 4);
Hooks::filter(Config::withFreePrefix('sure_contact_create_tag'), [SureContactHelperPro::class, 'createTag'], 10, 4);
Hooks::filter(Config::withFreePrefix('sure_contact_create_task'), [SureContactHelperPro::class, 'createTask'], 10, 4);
Hooks::filter(Config::withFreePrefix('sure_contact_delete_campaign'), [SureContactHelperPro::class, 'deleteCampaign'], 10, 4);
Hooks::filter(Config::withFreePrefix('sure_contact_delete_contact'), [SureContactHelperPro::class, 'deleteContact'], 10, 4);
Hooks::filter(Config::withFreePrefix('sure_contact_delete_list'), [SureContactHelperPro::class, 'deleteList'], 10, 4);
Hooks::filter(Config::withFreePrefix('sure_contact_delete_note'), [SureContactHelperPro::class, 'deleteNote'], 10, 4);
Hooks::filter(Config::withFreePrefix('sure_contact_delete_page'), [SureContactHelperPro::class, 'deletePage'], 10, 4);
Hooks::filter(Config::withFreePrefix('sure_contact_delete_tag'), [SureContactHelperPro::class, 'deleteTag'], 10, 4);
Hooks::filter(Config::withFreePrefix('sure_contact_delete_task'), [SureContactHelperPro::class, 'deleteTask'], 10, 4);
Hooks::filter(Config::withFreePrefix('sure_contact_detach_contacts_from_task'), [SureContactHelperPro::class, 'detachContactsFromTask'], 10, 4);
Hooks::filter(Config::withFreePrefix('sure_contact_detach_lists_from_contact'), [SureContactHelperPro::class, 'detachListsFromContact'], 10, 4);
Hooks::filter(Config::withFreePrefix('sure_contact_detach_tags_from_contact'), [SureContactHelperPro::class, 'detachTagsFromContact'], 10, 4);
Hooks::filter(Config::withFreePrefix('sure_contact_duplicate_campaign'), [SureContactHelperPro::class, 'duplicateCampaign'], 10, 4);
Hooks::filter(Config::withFreePrefix('sure_contact_mark_task_done'), [SureContactHelperPro::class, 'markTaskDone'], 10, 4);
Hooks::filter(Config::withFreePrefix('sure_contact_mark_task_undone'), [SureContactHelperPro::class, 'markTaskUndone'], 10, 4);
Hooks::filter(Config::withFreePrefix('sure_contact_refund_purchase'), [SureContactHelperPro::class, 'refundPurchase'], 10, 4);
Hooks::filter(Config::withFreePrefix('sure_contact_remove_contacts_from_list'), [SureContactHelperPro::class, 'removeContactsFromList'], 10, 4);
Hooks::filter(Config::withFreePrefix('sure_contact_remove_contacts_from_tag'), [SureContactHelperPro::class, 'removeContactsFromTag'], 10, 4);
Hooks::filter(Config::withFreePrefix('sure_contact_update_campaign'), [SureContactHelperPro::class, 'updateCampaign'], 10, 4);
Hooks::filter(Config::withFreePrefix('sure_contact_update_contact'), [SureContactHelperPro::class, 'updateContact'], 10, 4);
Hooks::filter(Config::withFreePrefix('sure_contact_update_contact_status'), [SureContactHelperPro::class, 'updateContactStatus'], 10, 4);
Hooks::filter(Config::withFreePrefix('sure_contact_update_list'), [SureContactHelperPro::class, 'updateList'], 10, 4);
Hooks::filter(Config::withFreePrefix('sure_contact_update_note'), [SureContactHelperPro::class, 'updateNote'], 10, 4);
Hooks::filter(Config::withFreePrefix('sure_contact_update_page'), [SureContactHelperPro::class, 'updatePage'], 10, 4);
Hooks::filter(Config::withFreePrefix('sure_contact_update_tag'), [SureContactHelperPro::class, 'updateTag'], 10, 4);
Hooks::filter(Config::withFreePrefix('sure_contact_update_task'), [SureContactHelperPro::class, 'updateTask'], 10, 4);
Hooks::filter(Config::withFreePrefix('sure_contact_upsert_contact'), [SureContactHelperPro::class, 'upsertContact'], 10, 4);
