import { Action, PossibleEvent } from "../types";
import { cleanClassName } from "../utils";
import { removeClassFromElement } from "../class-memory";

export function removeClass(event: PossibleEvent, target: HTMLElement, action?: Action) {
  if (!action?.css_class) return;

  const className = cleanClassName(action.css_class);
  removeClassFromElement(target, className);
}