<?php

namespace FluentCartPro\App\Modules\Reviews\Hooks\Handlers;

use FluentCart\App\Services\ProductReviewService;
use FluentCart\Framework\Support\Arr;
use FluentCartPro\App\Utils\Enqueuer\Vite;

class ReviewAssetHandler
{
    public function register()
    {
        add_action('wp_enqueue_scripts', [$this, 'maybeEnqueuePublicAssets']);

        // Render-time fallback for pages the wp_enqueue_scripts pass cannot
        // see (review blocks inside FSE template parts, widget areas, or
        // do_blocks() calls): the free renderer fires these on every reviews
        // section / review form it prints, and enqueuePublicAssets() is
        // idempotent. The script loads in the footer, so render-time
        // enqueueing still works.
        add_action('fluent_cart/review/after_section', [$this, 'enqueuePublicAssets']);
        add_action('fluent_cart/review/after_form_section', [$this, 'enqueuePublicAssets']);

        // Free fires this whenever it enqueues the review form's own
        // assets, on any surface. The customer dashboard's My Reviews modal
        // fetches the form markup over REST, so the render-time hooks above
        // fire inside that request and reach no page; this one fires on the
        // page itself, when the dashboard loads.
        add_action('fluent_cart/review/submission_form_assets_loaded', [$this, 'enqueuePublicAssets']);

        // The review blocks preview themselves in the editor by rendering
        // their own markup, which includes the photo upload zone this module
        // prints. Neither pass above reaches that canvas — wp_enqueue_scripts
        // does not run in the admin, and the render-time hooks fire during the
        // block-renderer REST request, not on the page holding the editor. So
        // the stylesheet is enqueued here too, where enqueue_block_assets
        // carries it inside the WP 6.3+ editor iframe.
        add_action('enqueue_block_assets', [$this, 'maybeEnqueueEditorStyles']);
    }

    /**
     * Styles only, deliberately. The storefront script drives uploads, votes
     * and the drawer; running it against a preview would wire behaviour to
     * markup the editor is about to replace on the next render.
     */
    public function maybeEnqueueEditorStyles()
    {
        // enqueue_block_assets fires on the front end as well, where the two
        // passes above already own this decision.
        if (!is_admin()) {
            return;
        }

        if (wp_style_is('fct-review-storefront', 'enqueued')) {
            return;
        }

        // The upload zone is the only thing this module adds to the form, and
        // it is what the setting gates. Nothing to style without it.
        if (Arr::get(ProductReviewService::getReviewSettings(), 'enable_photo_reviews') !== 'yes') {
            return;
        }

        wp_enqueue_style(
            'fct-review-storefront',
            Vite::getEnqueuePath('public/reviews/review-storefront.scss'),
            [],
            FLUENTCART_PRO_PLUGIN_VERSION
        );
    }

    public function maybeEnqueuePublicAssets()
    {
        if (is_singular('fluent-products')) {
            $this->enqueuePublicAssets(get_the_ID());
            return;
        }

        // Standalone review blocks on regular pages/posts: without the
        // storefront script the drawer's photo upload zone is inert and
        // filter chips / votes never appear.
        if (is_singular()
            && (has_block('fluent-cart/product-reviews') || has_block('fluent-cart/product-review-form'))
        ) {
            $this->enqueuePublicAssets(get_the_ID());
        }
    }

    public function enqueuePublicAssets($postId = 0)
    {
        if (wp_script_is('fct-review-storefront', 'enqueued')) {
            return;
        }

        $settings = ProductReviewService::getReviewSettings();
        $proFeatures = [];

        if (Arr::get($settings, 'enable_photo_reviews') === 'yes') {
            $proFeatures[] = 'photo_reviews';
        }
        // Helpful votes are for logged-in users only — guests never get the
        // feature, so the storefront JS has nothing to gate. Safe under
        // full-page caching: logged-in requests bypass the cache, so guests
        // only ever see the guest variant. The vote endpoint independently
        // rejects unauthenticated requests.
        if (is_user_logged_in() && Arr::get($settings, 'enable_helpful_votes') === 'yes') {
            $proFeatures[] = 'helpful_votes';
        }

        // Threaded replies — reviewer replies on their own thread — are off
        // by default; the fluent_cart/review/allow_threaded_replies filter
        // opts in (see ProductReviewService::isMultipleRepliesAllowed()).
        if (\FluentCartPro\App\Modules\Reviews\Services\ReviewService::isThreadedRepliesEnabled() && is_user_logged_in()) {
            $proFeatures[] = 'threaded_replies';
        }

        if (empty($proFeatures)) {
            return;
        }

        wp_enqueue_style(
            'fct-review-storefront',
            Vite::getEnqueuePath('public/reviews/review-storefront.scss'),
            [],
            FLUENTCART_PRO_PLUGIN_VERSION
        );

        wp_enqueue_script(
            'fct-review-storefront',
            Vite::getEnqueuePath('public/reviews/review-storefront.js'),
            [],
            FLUENTCART_PRO_PLUGIN_VERSION,
            true
        );

        wp_localize_script('fct-review-storefront', 'fctReviewsProVars', [
            'features' => $proFeatures,
            'trans'    => [
                'helpful'        => __('Helpful', 'fluent-cart-pro'),
                'not_helpful'    => __('Not Helpful', 'fluent-cart-pro'),
                'remove'         => __('Remove', 'fluent-cart-pro'),
                'reply_placeholder' => __('Write a reply...', 'fluent-cart-pro'),
                'send_reply'        => __('Send a Reply', 'fluent-cart-pro'),
                'sending'           => __('Sending...', 'fluent-cart-pro'),
                'reply_failed'      => __('Failed to post reply. Please try again.', 'fluent-cart-pro'),
                'reply_pending'     => __('Your reply has been submitted and is pending approval.', 'fluent-cart-pro'),
                'you'               => __('You', 'fluent-cart-pro'),
                'max_files'      => __('Maximum files reached', 'fluent-cart-pro'),
                'not_saved'      => __('These photos were not saved', 'fluent-cart-pro'),
                'reason_type'    => __('not an allowed image type', 'fluent-cart-pro'),
                'reason_size'    => __('larger than the size limit', 'fluent-cart-pro'),
                'reason_dimensions' => __('image dimensions are too large or could not be read', 'fluent-cart-pro'),
                'reason_limit'   => __('over the photo limit', 'fluent-cart-pro'),
                'reason_rate_limit' => __('hourly photo upload limit reached; please try again later', 'fluent-cart-pro'),
                'reason_upload'  => __('could not be uploaded', 'fluent-cart-pro'),
                'invalid_type'   => __('Invalid file type', 'fluent-cart-pro'),
                'file_too_large' => __('File too large', 'fluent-cart-pro'),
                'with_photos'    => __('With Photos', 'fluent-cart-pro'),
                'verified'       => __('Verified', 'fluent-cart-pro'),
                'vote_helpful'     => __('Helpful', 'fluent-cart-pro'),
                'vote_not_helpful' => __('Not helpful', 'fluent-cart-pro'),
                'dismiss'        => __('Dismiss', 'fluent-cart-pro'),
                'vote_failed'    => __('Vote failed', 'fluent-cart-pro'),
            ],
        ]);
    }
}
