<?php

namespace FluentCartPro\App\Modules\AdvancedInventory\Database\Migrations;

use FluentCartPro\App\Database\Migrations\DropTable;

class StockAdjustmentsMigrator
{
    use DropTable;

    public static $tableName = 'fct_stock_adjustments';

    /**
     * Migrate the table.
     *
     * @return void
     */
    public static function migrate()
    {
        global $wpdb;

        $charsetCollate = $wpdb->get_charset_collate();
        $table = static::getTableName();

        if ($wpdb->get_var("SHOW TABLES LIKE '$table'") != $table) {
            $sql = "CREATE TABLE $table (
                `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                `variant_id` BIGINT UNSIGNED NOT NULL,
                `post_id` BIGINT UNSIGNED NOT NULL,
                `old_stock` INT NOT NULL DEFAULT 0,
                `new_stock` INT NOT NULL DEFAULT 0,
                `reason` VARCHAR(50) NOT NULL DEFAULT 'other' COMMENT 'received / damage / return / correction / transfer / other',
                `custom_reason` LONGTEXT NULL COMMENT 'Custom reason text when reason is other',
                `user_id` BIGINT UNSIGNED NOT NULL,
                `created_at` DATETIME NULL,
                `updated_at` DATETIME NULL,
                PRIMARY KEY  (`id`),
                KEY `variant_id` (`variant_id`),
                KEY `post_id` (`post_id`)
            ) $charsetCollate;";
            dbDelta($sql);
        }
    }
}
