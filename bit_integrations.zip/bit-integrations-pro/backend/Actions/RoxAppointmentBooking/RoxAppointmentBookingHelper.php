<?php

namespace BitApps\IntegrationsPro\Actions\RoxAppointmentBooking;

final class RoxAppointmentBookingHelper
{
    public static function isPluginActive()
    {
        return \defined('ROX_APPOINTMENT_BOOKING_VERSION');
    }

    public static function error($message)
    {
        return ['success' => false, 'message' => $message];
    }

    public static function success($message, $data = [])
    {
        return ['success' => true, 'message' => $message, 'data' => $data];
    }

    public static function inactive()
    {
        return self::error(__('Rox Appointment Booking is not installed or activated', 'bit-integrations-pro'));
    }

    public static function payload($fieldData, array $columns)
    {
        $payload = [];

        foreach ($columns as $column) {
            if (!isset($fieldData[$column]) || $fieldData[$column] === '') {
                continue;
            }

            $payload[$column] = $fieldData[$column];
        }

        return $payload;
    }

    public static function missingFields($fieldData, array $required)
    {
        $missing = [];

        foreach ($required as $field) {
            if (!isset($fieldData[$field]) || $fieldData[$field] === '') {
                $missing[] = $field;
            }
        }

        return $missing;
    }

    public static function requiredError(array $missing)
    {
        // translators: %s is the comma separated list of missing field names.
        return self::error(\sprintf(__('These required fields are empty: %s', 'bit-integrations-pro'), implode(', ', $missing)));
    }

    private static function lookups()
    {
        return [
            'customer_id'  => [['find_by_customer_email', 'table', 'customer', 'email', __('customer', 'bit-integrations-pro')]],
            'agent_id'     => [['find_by_agent_email', 'table', 'agent', 'email', __('agent', 'bit-integrations-pro')]],
            'service_id'   => [['find_by_service_title', 'table', 'service', 'title', __('service', 'bit-integrations-pro')]],
            'category_id'  => [
                ['find_by_category_slug', 'table', 'category', 'slug', __('category', 'bit-integrations-pro')],
                ['find_by_category_title', 'table', 'category', 'title', __('category', 'bit-integrations-pro')],
            ],
            'location_id'  => [],
            'booking_id'   => [],
            'order_id'     => [['find_by_order_number', 'order_number', '', '', __('order', 'bit-integrations-pro')]],
            'payment_id'   => [['find_by_payment_transaction_id', 'table', 'payment', 'transaction_id', __('payment', 'bit-integrations-pro')]],
            'wp_user_id'   => [['find_by_wp_user_email', 'wp_user', '', '', __('WordPress user', 'bit-integrations-pro')]],
            'user_id'      => [['find_by_user_email', 'wp_user', '', '', __('WordPress user', 'bit-integrations-pro')]],
        ];
    }

    public static function resolveIds($fieldData)
    {
        foreach (self::lookups() as $idKey => $alternates) {
            if (!empty($fieldData[$idKey])) {
                continue;
            }

            foreach ($alternates as $alternate) {
                list($altKey, $kind, $tableSuffix, $column, $label) = $alternate;

                $value = $fieldData[$altKey] ?? '';

                if ($value === '' || $value === null) {
                    continue;
                }

                $id = self::resolveOne($kind, $tableSuffix, $column, $value);

                if ($id) {
                    $fieldData[$idKey] = $id;

                    break;
                }

                return [
                    $fieldData,
                    // translators: %1$s is the record type, %2$s is the value that matched nothing.
                    self::error(\sprintf(__('No %1$s found for "%2$s"', 'bit-integrations-pro'), $label, $value)),
                ];
            }
        }

        return [$fieldData, null];
    }

    private static function resolveOne($kind, $tableSuffix, $column, $value)
    {
        if ($kind === 'wp_user') {
            $user = is_email($value) ? get_user_by('email', $value) : get_user_by('login', $value);

            return $user ? (int) $user->ID : 0;
        }

        if ($kind === 'order_number') {
            // getOrderNumber() renders the row id as ORD-000123, so the id reads straight back out.
            return (int) preg_replace('/[^0-9]/', '', (string) $value);
        }

        return self::lookup($tableSuffix, $column, $value);
    }

    private static function lookup($tableSuffix, $column, $value)
    {
        global $wpdb;

        $table = self::table($tableSuffix);

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- table and column come from the lookups() table, never from user input
        return (int) $wpdb->get_var($wpdb->prepare("SELECT id FROM `{$table}` WHERE `{$column}` = %s ORDER BY id ASC LIMIT 1", $value));
    }

    public static function missingRequired($fieldData, array $required)
    {
        $missing = [];

        foreach ($required as $entry) {
            $keys = (array) $entry;
            $satisfied = false;

            foreach ($keys as $key) {
                if (isset($fieldData[$key]) && $fieldData[$key] !== '') {
                    $satisfied = true;

                    break;
                }
            }

            if (!$satisfied) {
                $missing[] = implode(' ' . __('or', 'bit-integrations-pro') . ' ', $keys);
            }
        }

        return $missing;
    }

    public static function table($suffix)
    {
        global $wpdb;

        $dbPrefix = \defined('ROX_APPOINTMENT_BOOKING_DB_PREFIX') ? ROX_APPOINTMENT_BOOKING_DB_PREFIX : $wpdb->prefix;
        $pluginPrefix = \defined('ROX_APPOINTMENT_BOOKING_PREFIX') ? ROX_APPOINTMENT_BOOKING_PREFIX : 'rox_appointment';

        return $dbPrefix . $pluginPrefix . '_' . $suffix;
    }

    public static function attributes($record)
    {
        if (!\is_object($record)) {
            return (array) $record;
        }

        if (method_exists($record, 'getAttributes')) {
            return (array) $record->getAttributes();
        }

        return get_object_vars($record);
    }

    public static function allowedStatuses($function)
    {
        if (!\function_exists($function)) {
            return [];
        }

        return array_column((array) \call_user_func($function), 'value');
    }

    public static function invalidStatus($status, array $allowed)
    {
        return !empty($allowed) && !\in_array($status, $allowed, true);
    }

    public static function invalidStatusError(array $allowed)
    {
        // translators: %s is the comma separated list of allowed statuses.
        return self::error(\sprintf(__('Invalid status. Allowed: %s', 'bit-integrations-pro'), implode(', ', $allowed)));
    }

    public static function utility($utilities, $key, $default = null)
    {
        if (\is_object($utilities)) {
            return $utilities->{$key} ?? $default;
        }

        if (\is_array($utilities)) {
            return $utilities[$key] ?? $default;
        }

        return $default;
    }

    public static function config($integrationDetails, $key, $default = null)
    {
        if (\is_object($integrationDetails)) {
            return $integrationDetails->{$key} ?? $default;
        }

        if (\is_array($integrationDetails)) {
            return $integrationDetails[$key] ?? $default;
        }

        return $default;
    }
}
