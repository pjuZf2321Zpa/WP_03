<?php return array('dependencies' => array('react', 'react-dom', 'wp-api-fetch', 'wp-data', 'wp-hooks', 'wp-i18n'), 'version' => 'd569d9b3f5d5c001a649');
