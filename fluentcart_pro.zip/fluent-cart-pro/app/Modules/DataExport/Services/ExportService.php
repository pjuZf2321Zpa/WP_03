<?php

namespace FluentCartPro\App\Modules\DataExport\Services;

use FluentCart\App\Models\Customer;
use FluentCart\App\Models\CustomerAddresses;
use FluentCart\App\Models\CustomerMeta;
use FluentCart\App\Models\Order;
use FluentCart\App\Models\OrderAddress;
use FluentCart\App\Models\OrderItem;
use FluentCart\App\Models\OrderMeta;
use FluentCart\App\Models\OrderTaxRate;
use FluentCart\App\Models\OrderTransaction;
use FluentCart\App\Models\Subscription;
use FluentCart\App\Models\SubscriptionMeta;
use FluentCart\App\Modules\Subscriptions\Services\Filter\SubscriptionFilter;
use FluentCart\App\Services\Filter\CustomerFilter;
use FluentCart\App\Services\Filter\LicenseFilter;
use FluentCart\App\Services\Filter\OrderFilter;
use FluentCart\Framework\Support\DateTime;
use FluentCartPro\App\Modules\Licensing\Models\License;
use FluentCartPro\App\Modules\Licensing\Models\LicenseActivation;
use FluentCartPro\App\Modules\Licensing\Models\LicenseMeta;
use FluentCartPro\App\Modules\Licensing\Models\LicenseSite;
use FluentCartPro\App\Modules\DataExport\Exceptions\ExportRecordTooLargeException;

class ExportService
{
    private const CSV_QUERY_CHUNK_SIZE = 100;

    private const JSON_QUERY_CHUNK_SIZE = 50;

    private const JSON_INITIAL_CHUNK_SIZE = 10;

    private const RUNTIME_BUDGET_SECONDS = 1.25;

    private const PAYLOAD_BUDGET_BYTES = 2097152;

    private const RELATED_ROW_LIMIT = 2000;

    private const RELATED_ROW_RESPONSE_LIMIT = 5000;

    private const RESPONSE_ENVELOPE_BYTES = 512;

    private const JSON_FIELDS = [
        'orders' => [
            'id', 'uuid', 'invoice_no', 'receipt_number', 'customer_id', 'type', 'mode',
            'status', 'payment_status', 'shipping_status', 'currency', 'subtotal',
            'manual_discount_total', 'coupon_discount_total', 'discount_tax',
            'shipping_total', 'shipping_tax', 'tax_total', 'fee_total', 'total_amount',
            'total_paid', 'total_refund', 'rate', 'tax_behavior', 'payment_method',
            'payment_method_title', 'fulfillment_type', 'parent_id', 'note', 'ip_address',
            'config', 'completed_at', 'refunded_at', 'created_at', 'updated_at',
        ],
        'customers' => [
            'id', 'uuid', 'user_id', 'contact_id', 'first_name', 'last_name', 'email',
            'status', 'purchase_count', 'purchase_value', 'ltv', 'aov',
            'first_purchase_date', 'last_purchase_date', 'country', 'state', 'city',
            'postcode', 'notes', 'created_at', 'updated_at',
        ],
        'order_items' => [
            'id', 'order_id', 'post_id', 'object_id', 'title', 'post_title', 'quantity',
            'fulfilled_quantity', 'unit_price', 'subtotal', 'discount_total', 'tax_amount',
            'shipping_charge', 'line_total', 'refund_total', 'cost', 'rate', 'payment_type',
            'fulfillment_type', 'cart_index', 'referrer', 'line_meta', 'other_info',
            'created_at', 'updated_at',
        ],
        'order_addresses' => [
            'id', 'order_id', 'type', 'name', 'address_1', 'address_2', 'city', 'state',
            'postcode', 'country', 'meta', 'created_at', 'updated_at',
        ],
        'order_transactions' => [
            'id', 'uuid', 'order_id', 'order_type', 'transaction_type', 'subscription_id',
            'card_last_4', 'card_brand', 'vendor_charge_id', 'payment_method', 'payment_mode',
            'payment_method_type', 'status', 'currency', 'total', 'rate', 'meta',
            'created_at', 'updated_at',
        ],
        'order_tax_rates' => [
            'id', 'order_id', 'tax_rate_id', 'order_tax', 'shipping_tax', 'total_tax',
            'meta', 'filed_at', 'created_at', 'updated_at',
        ],
        'order_meta' => [
            'id', 'order_id', 'meta_key', 'meta_value', 'created_at', 'updated_at',
        ],
        'customer_addresses' => [
            'id', 'customer_id', 'type', 'label', 'status', 'is_primary', 'name', 'email',
            'phone', 'address_1', 'address_2', 'city', 'state', 'postcode', 'country',
            'meta', 'created_at', 'updated_at',
        ],
        'customer_meta' => [
            'id', 'customer_id', 'meta_key', 'meta_value', 'created_at', 'updated_at',
        ],
        'subscriptions' => [
            'id', 'uuid', 'status', 'item_name', 'customer_id', 'parent_order_id',
            'product_id', 'variation_id', 'billing_interval', 'quantity', 'signup_fee',
            'initial_amount', 'initial_tax_total', 'recurring_amount', 'recurring_tax_total',
            'recurring_total', 'bill_times', 'bill_count', 'trial_days', 'collection_method',
            'current_payment_method', 'vendor_customer_id', 'vendor_plan_id',
            'vendor_subscription_id', 'next_billing_date', 'trial_ends_at', 'expire_at',
            'canceled_at', 'restored_at', 'config', 'original_plan', 'vendor_response',
            'created_at', 'updated_at',
        ],
        'subscription_meta' => [
            'id', 'subscription_id', 'meta_key', 'meta_value', 'created_at', 'updated_at',
        ],
        'licenses' => [
            'id', 'status', 'limit', 'activation_count', 'license_key', 'product_id',
            'variation_id', 'order_id', 'parent_id', 'customer_id', 'expiration_date',
            'last_reminder_sent', 'last_reminder_type', 'subscription_id', 'config',
            'created_at', 'updated_at',
        ],
        'license_activations' => [
            'id', 'license_id', 'site_id', 'product_id', 'variation_id', 'status',
            'activation_method', 'is_local', 'last_update_date', 'last_update_version',
            'created_at', 'updated_at',
        ],
        'license_sites' => [
            'id', 'site_url', 'platform_version', 'server_version', 'other',
            'created_at', 'updated_at',
        ],
        'license_meta' => [
            'id', 'object_id', 'object_type', 'meta_key', 'meta_value',
            'created_at', 'updated_at',
        ],
    ];

    private $deadlineAt = 0.0;

    private $relatedRowsLoaded = 0;

    public function batch( string $entity, array $payload ): array
    {
        $startedAt = microtime( true );
        $this->relatedRowsLoaded = 0;
        $cursor = (int) $payload['cursor'];
        $records = [];
        $estimatedBytes = self::RESPONSE_ENVELOPE_BYTES;
        $sourceExhausted = false;
        $total = $cursor === 0 ? $this->countRecords( $entity, $payload ) : null;

        // Charged after the one-off count so the budget governs export work only.
        $this->deadlineAt = microtime( true ) + self::RUNTIME_BUDGET_SECONDS;
        $jsonChunkCeiling = self::JSON_INITIAL_CHUNK_SIZE;
        $averageRecordBytes = 0;

        while ( count( $records ) < $payload['max_records'] ) {
            if ( $records && $this->budgetExhausted() ) {
                break;
            }

            $remaining = $payload['max_records'] - count( $records );
            $internalLimit = $payload['format'] === 'json'
                ? $this->jsonChunkLimit( $jsonChunkCeiling, $averageRecordBytes, $estimatedBytes )
                : self::CSV_QUERY_CHUNK_SIZE;
            $queryLimit = min( $internalLimit, $remaining );
            $models = $this->getRootChunk( $entity, $payload, $cursor, $queryLimit );

            if ( $models->isEmpty() ) {
                $sourceExhausted = true;
                break;
            }

            $shapedAllRoots = true;

            try {
                if ( $payload['format'] === 'json' ) {
                    $shapedRecords = $this->shapeJsonRecords( $entity, $models, $payload['modules'] );
                    $shapedAllRoots = count( $shapedRecords ) === $models->count();
                } else {
                    $shapedRecords = $this->shapeCsvRecords( $entity, $models, $payload['columns'] );
                }
            } catch ( ExportRecordTooLargeException $exception ) {
                if ( $payload['format'] === 'json' && $queryLimit > 1 ) {
                    $jsonChunkCeiling = max( 1, (int) floor( $queryLimit / 2 ) );
                    continue;
                }

                throw $exception;
            }

            $budgetStopped = false;

            foreach ( $shapedRecords as $record ) {
                $encoded = wp_json_encode( $record );
                $recordBytes = is_string( $encoded ) ? strlen( $encoded ) : 0;

                if ( !$records && $estimatedBytes + $recordBytes > self::PAYLOAD_BUDGET_BYTES ) {
                    throw new ExportRecordTooLargeException(
                        __( 'One export record is larger than the safe response limit. Select fewer JSON modules and try again.', 'fluent-cart-pro' )
                    );
                }

                if ( $records && $estimatedBytes + $recordBytes + 1 > self::PAYLOAD_BUDGET_BYTES ) {
                    $budgetStopped = true;
                    break;
                }

                $records[] = $record;
                $estimatedBytes += $recordBytes + 1;
                $cursor = (int) $record['record_id'];

                if ( $this->budgetExhausted() ) {
                    $budgetStopped = true;
                    break;
                }
            }

            if ( $records ) {
                $averageRecordBytes = (int) ceil(
                    ( $estimatedBytes - self::RESPONSE_ENVELOPE_BYTES ) / count( $records )
                );
            }

            if ( $budgetStopped || !$shapedAllRoots ) {
                break;
            }

            if ( $models->count() < $queryLimit ) {
                $sourceExhausted = true;
                break;
            }

            $jsonChunkCeiling = min( self::JSON_QUERY_CHUNK_SIZE, $jsonChunkCeiling * 2 );
        }

        $elapsedMs = (int) round( (microtime( true ) - $startedAt) * 1000 );

        return [
            'entity'         => $entity,
            'schema_version' => 1,
            'records'        => $records,
            'total'          => $total,
            'cursor'         => $cursor ?: null,
            'has_more'       => !$sourceExhausted && !empty( $records ),
            'batch'          => [
                'records'         => count( $records ),
                'elapsed_ms'      => $elapsedMs,
                'estimated_bytes' => $estimatedBytes,
                'requested_max'   => (int) $payload['max_records'],
                'next_max'        => $this->suggestNextMaximum(
                    (int) $payload['max_records'],
                    count( $records ),
                    $elapsedMs,
                    $estimatedBytes
                ),
            ],
        ];
    }

    private function budgetExhausted(): bool
    {
        return microtime( true ) >= $this->deadlineAt;
    }

    /**
     * Size the next JSON root chunk so it cannot hydrate related modules for
     * roots the payload budget has no room left to return.
     */
    private function jsonChunkLimit( int $ceiling, int $averageRecordBytes, int $estimatedBytes ): int
    {
        if ( $averageRecordBytes < 1 ) {
            return $ceiling;
        }

        $remainingBytes = self::PAYLOAD_BUDGET_BYTES - $estimatedBytes;

        if ( $remainingBytes < 1 ) {
            return 1;
        }

        return max( 1, min( $ceiling, (int) floor( $remainingBytes / $averageRecordBytes ) ) );
    }

    /**
     * Drop roots from the working set once the runtime or aggregate related-row
     * budget is spent, so the remaining module queries only load rows for roots
     * this response can still emit. Always keeps at least one root so the cursor
     * advances.
     */
    private function limitRootsForRelatedLoad( array &$retainedIds ): void
    {
        if ( count( $retainedIds ) < 2 ) {
            return;
        }

        if ( !$this->budgetExhausted() && $this->relatedRowsLoaded < self::RELATED_ROW_RESPONSE_LIMIT ) {
            return;
        }

        $retainedIds = array_slice(
            $retainedIds,
            0,
            max( 1, (int) floor( count( $retainedIds ) / 2 ) )
        );
    }

    private function countRecords( string $entity, array $payload ): int
    {
        return (int) $this->buildRootQuery( $entity, $payload, 0 )->count();
    }

    private function getRootChunk( string $entity, array $payload, int $cursor, int $limit )
    {
        $query = $this->buildRootQuery( $entity, $payload, $cursor );

        if ( $payload['format'] === 'csv' ) {
            $columns = $payload['columns'];
            $query->select( $this->csvSelectedAttributes( $entity, $columns ) );

            if (
                in_array( $entity, [ExportSchema::ORDERS, ExportSchema::SUBSCRIPTIONS, ExportSchema::LICENSES], true )
                && array_intersect( ['customer_name', 'customer_email'], $columns )
            ) {
                $query->with( 'customer' );
            }

            if ( $entity === ExportSchema::ORDERS && in_array( 'items_count', $columns, true ) ) {
                $query->withCount( 'order_items' );
            }
        }

        return $query->limit( $limit )->get();
    }

    private function buildRootQuery( string $entity, array $payload, int $cursor )
    {
        $args = $payload['filters'];
        $args['sort_by'] = 'id';
        $args['sort_type'] = 'asc';
        unset(
            $args['limit'],
            $args['offset'],
            $args['page'],
            $args['per_page'],
            $args['with'],
            $args['select'],
            $args['include_ids']
        );

        if ( $entity === ExportSchema::ORDERS ) {
            $filter = OrderFilter::make( $args );
            $filterName = 'orders';
        } elseif ( $entity === ExportSchema::CUSTOMERS ) {
            $filter = CustomerFilter::make( $args );
            $filterName = 'customers';
        } elseif ( $entity === ExportSchema::SUBSCRIPTIONS ) {
            $filter = SubscriptionFilter::make( $args );
            $filterName = 'subscriptions';
        } else {
            $filter = LicenseFilter::make( $args );
            $filterName = 'licenses';
        }

        $query = $filter->buildQuery();
        $query = apply_filters(
            "fluent_cart/{$filterName}_list_filter_query",
            $query,
            $filter->toArray()
        );

        if ( $payload['ids'] ) {
            $query->whereIn( 'id', $payload['ids'] );
        }

        if ( $cursor ) {
            $query->where( 'id', '>', $cursor );
        }

        return $query;
    }

    private function shapeCsvRecords( string $entity, $models, array $columns ): array
    {
        $records = [];

        foreach ( $models as $model ) {
            if ( $entity === ExportSchema::ORDERS ) {
                $row = $this->orderCsvRow( $model );
            } elseif ( $entity === ExportSchema::CUSTOMERS ) {
                $row = $this->customerCsvRow( $model );
            } elseif ( $entity === ExportSchema::SUBSCRIPTIONS ) {
                $row = $this->subscriptionCsvRow( $model );
            } else {
                $row = $this->licenseCsvRow( $model );
            }

            $selected = ['record_id' => (int) $model->id];

            foreach ( $columns as $column ) {
                $selected[$column] = $this->neutralizeCsvFormula( $row[$column] ?? '' );
            }

            $records[] = $selected;
        }

        return $records;
    }

    /**
     * Neutralize spreadsheet formulas in exported cells.
     *
     * Exported fields such as customer name, item name, invoice number and
     * address are attacker-influenceable, so a value whose first effective
     * character is =, +, - or @ (optionally behind control whitespace such as
     * tab or carriage return) is prefixed with an apostrophe. The browser
     * writer applies the same rule; a value neutralized here is left alone
     * there, so the written file is unchanged.
     *
     * @param mixed $value
     * @return mixed
     */
    private function neutralizeCsvFormula( $value )
    {
        if ( !is_string( $value ) || $value === '' ) {
            return $value;
        }

        if ( preg_match( '/^[\x00-\x20]*[=+\-@]/', $value ) ) {
            return "'" . $value;
        }

        return $value;
    }

    private function csvSelectedAttributes( string $entity, array $columns ): array
    {
        $dependencies = [
            ExportSchema::ORDERS => [
                'order_id' => ['id'],
                'invoice_no' => ['invoice_no'],
                'status' => ['status'],
                'payment_status' => ['payment_status'],
                'shipping_status' => ['shipping_status'],
                'currency' => ['currency'],
                'subtotal' => ['subtotal'],
                'discount_total' => ['manual_discount_total', 'coupon_discount_total'],
                'shipping_total' => ['shipping_total'],
                'tax_total' => ['tax_total'],
                'total_amount' => ['total_amount'],
                'total_refund' => ['total_refund'],
                'items_count' => ['id'],
                'order_type' => ['type'],
                'payment_method' => ['payment_method'],
                'customer_id' => ['customer_id'],
                'customer_name' => ['customer_id'],
                'customer_email' => ['customer_id'],
                'mode' => ['mode'],
                'created_at' => ['created_at'],
                'completed_at' => ['completed_at'],
            ],
            ExportSchema::CUSTOMERS => [
                'customer_id' => ['id'],
                'first_name' => ['first_name'],
                'last_name' => ['last_name'],
                'full_name' => ['first_name', 'last_name'],
                'email' => ['email'],
                'status' => ['status'],
                'purchase_count' => ['purchase_count'],
                'lifetime_value' => ['ltv'],
                'average_order_value' => ['aov'],
                'first_purchase_date' => ['first_purchase_date'],
                'last_purchase_date' => ['last_purchase_date'],
                'customer_since' => ['created_at'],
                'country' => ['country'],
                'state' => ['state'],
                'city' => ['city'],
                'postcode' => ['postcode'],
                'wordpress_user_id' => ['user_id'],
                'contact_id' => ['contact_id'],
            ],
            ExportSchema::SUBSCRIPTIONS => [
                'subscription_id' => ['id'],
                'status' => ['status'],
                'item_name' => ['item_name'],
                'customer_id' => ['customer_id'],
                'customer_name' => ['customer_id'],
                'customer_email' => ['customer_id'],
                'parent_order_id' => ['parent_order_id'],
                'product_id' => ['product_id'],
                'variation_id' => ['variation_id'],
                'billing_interval' => ['billing_interval'],
                'quantity' => ['quantity'],
                'signup_fee' => ['signup_fee'],
                'recurring_amount' => ['recurring_amount'],
                'recurring_tax_total' => ['recurring_tax_total'],
                'recurring_total' => ['recurring_total'],
                'bill_times' => ['bill_times'],
                'bill_count' => ['bill_count'],
                'trial_days' => ['trial_days'],
                'collection_method' => ['collection_method'],
                'payment_method' => ['current_payment_method'],
                'vendor_subscription_id' => ['vendor_subscription_id'],
                'next_billing_date' => ['next_billing_date'],
                'trial_ends_at' => ['trial_ends_at'],
                'expire_at' => ['expire_at'],
                'canceled_at' => ['canceled_at'],
                'created_at' => ['created_at'],
                'updated_at' => ['updated_at'],
            ],
            ExportSchema::LICENSES => [
                'license_id' => ['id'],
                'license_key' => ['license_key'],
                'status' => ['status', 'expiration_date'],
                'activation_limit' => ['limit'],
                'activation_count' => ['activation_count'],
                'customer_id' => ['customer_id'],
                'customer_name' => ['customer_id'],
                'customer_email' => ['customer_id'],
                'order_id' => ['order_id'],
                'subscription_id' => ['subscription_id'],
                'product_id' => ['product_id'],
                'variation_id' => ['variation_id'],
                'expiration_date' => ['expiration_date'],
                'created_at' => ['created_at'],
                'updated_at' => ['updated_at'],
            ],
        ];
        $attributes = ['id'];

        foreach ( $columns as $column ) {
            $attributes = array_merge( $attributes, $dependencies[$entity][$column] ?? [] );
        }

        return array_values( array_unique( $attributes ) );
    }

    private function orderCsvRow( $order ): array
    {
        $customer = $order->relationLoaded( 'customer' ) ? $order->customer : null;

        return [
            'order_id'        => (int) $order->id,
            'invoice_no'      => (string) ( $order->invoice_no ?? '' ),
            'status'          => (string) ( $order->status ?? '' ),
            'payment_status'  => (string) ( $order->payment_status ?? '' ),
            'shipping_status' => (string) ( $order->shipping_status ?? '' ),
            'currency'        => (string) ( $order->currency ?? '' ),
            'subtotal'        => $this->toDecimal( $order->subtotal ),
            'discount_total'  => $this->toDecimal(
                (int) $order->manual_discount_total + (int) $order->coupon_discount_total
            ),
            'shipping_total'  => $this->toDecimal( $order->shipping_total ),
            'tax_total'       => $this->toDecimal( $order->tax_total ),
            'total_amount'    => $this->toDecimal( $order->total_amount ),
            'total_refund'    => $this->toDecimal( $order->total_refund ),
            'items_count'     => (int) ( $order->order_items_count ?? 0 ),
            'order_type'      => (string) ( $order->type ?? '' ),
            'payment_method'  => (string) ( $order->payment_method ?? '' ),
            'customer_id'     => (int) ( $order->customer_id ?? 0 ),
            'customer_name'   => $customer ? trim( $customer->first_name . ' ' . $customer->last_name ) : '',
            'customer_email'  => $customer ? (string) $customer->email : '',
            'mode'            => (string) ( $order->mode ?? '' ),
            'created_at'      => (string) ( $order->created_at ?? '' ),
            'completed_at'    => (string) ( $order->completed_at ?? '' ),
        ];
    }

    private function customerCsvRow( $customer ): array
    {
        return [
            'customer_id'          => (int) $customer->id,
            'first_name'           => (string) ( $customer->first_name ?? '' ),
            'last_name'            => (string) ( $customer->last_name ?? '' ),
            'full_name'            => trim( $customer->first_name . ' ' . $customer->last_name ),
            'email'                => (string) ( $customer->email ?? '' ),
            'status'               => (string) ( $customer->status ?? '' ),
            'purchase_count'       => (int) ( $customer->purchase_count ?? 0 ),
            'lifetime_value'       => $this->toDecimal( $customer->ltv ),
            'average_order_value'  => $this->toDecimal( $customer->aov ),
            'first_purchase_date'  => (string) ( $customer->first_purchase_date ?? '' ),
            'last_purchase_date'   => (string) ( $customer->last_purchase_date ?? '' ),
            'customer_since'       => (string) ( $customer->created_at ?? '' ),
            'country'              => (string) ( $customer->country ?? '' ),
            'state'                => (string) ( $customer->state ?? '' ),
            'city'                 => (string) ( $customer->city ?? '' ),
            'postcode'             => (string) ( $customer->postcode ?? '' ),
            'wordpress_user_id'    => (int) ( $customer->user_id ?? 0 ),
            'contact_id'           => (int) ( $customer->contact_id ?? 0 ),
        ];
    }

    private function subscriptionCsvRow( $subscription ): array
    {
        $customer = $subscription->relationLoaded( 'customer' ) ? $subscription->customer : null;

        return [
            'subscription_id'        => (int) $subscription->id,
            'status'                 => (string) ( $subscription->status ?? '' ),
            'item_name'              => (string) ( $subscription->item_name ?? '' ),
            'customer_id'            => (int) ( $subscription->customer_id ?? 0 ),
            'customer_name'          => $customer ? trim( $customer->first_name . ' ' . $customer->last_name ) : '',
            'customer_email'         => $customer ? (string) $customer->email : '',
            'parent_order_id'        => (int) ( $subscription->parent_order_id ?? 0 ),
            'product_id'             => (int) ( $subscription->product_id ?? 0 ),
            'variation_id'           => (int) ( $subscription->variation_id ?? 0 ),
            'billing_interval'       => (string) ( $subscription->billing_interval ?? '' ),
            'quantity'               => (int) ( $subscription->quantity ?? 0 ),
            'signup_fee'             => $this->toDecimal( $subscription->signup_fee ),
            'recurring_amount'       => $this->toDecimal( $subscription->recurring_amount ),
            'recurring_tax_total'    => $this->toDecimal( $subscription->recurring_tax_total ),
            'recurring_total'        => $this->toDecimal( $subscription->recurring_total ),
            'bill_times'             => (int) ( $subscription->bill_times ?? 0 ),
            'bill_count'             => (int) ( $subscription->bill_count ?? 0 ),
            'trial_days'             => (int) ( $subscription->trial_days ?? 0 ),
            'collection_method'      => (string) ( $subscription->collection_method ?? '' ),
            'payment_method'         => (string) ( $subscription->current_payment_method ?? '' ),
            'vendor_subscription_id' => (string) ( $subscription->vendor_subscription_id ?? '' ),
            'next_billing_date'      => (string) ( $subscription->next_billing_date ?? '' ),
            'trial_ends_at'          => (string) ( $subscription->trial_ends_at ?? '' ),
            'expire_at'              => (string) ( $subscription->expire_at ?? '' ),
            'canceled_at'            => (string) ( $subscription->canceled_at ?? '' ),
            'created_at'             => (string) ( $subscription->created_at ?? '' ),
            'updated_at'             => (string) ( $subscription->updated_at ?? '' ),
        ];
    }
    private function licenseCsvRow( $license ): array
    {
        $customer = $license->relationLoaded( 'customer' ) ? $license->customer : null;

        return [
            'license_id'       => (int) $license->id,
            'license_key'      => (string) ( $license->license_key ?? '' ),
            'status'           => $this->effectiveLicenseStatus( $license ),
            'activation_limit' => (int) $license->limit === 0 ? 'unlimited' : (int) $license->limit,
            'activation_count' => (int) ( $license->activation_count ?? 0 ),
            'customer_id'      => (int) ( $license->customer_id ?? 0 ),
            'customer_name'    => $customer ? trim( $customer->first_name . ' ' . $customer->last_name ) : '',
            'customer_email'   => $customer ? (string) $customer->email : '',
            'order_id'         => (int) ( $license->order_id ?? 0 ),
            'subscription_id'  => (int) ( $license->subscription_id ?? 0 ),
            'product_id'       => (int) ( $license->product_id ?? 0 ),
            'variation_id'     => (int) ( $license->variation_id ?? 0 ),
            'expiration_date'  => (string) ( $license->expiration_date ?? '' ),
            'created_at'       => (string) ( $license->created_at ?? '' ),
            'updated_at'       => (string) ( $license->updated_at ?? '' ),
        ];
    }

    private function shapeJsonRecords( string $entity, $models, array $modules ): array
    {
        $retainedIds = array_map( 'intval', $models->pluck( 'id' )->all() );
        $related = $this->loadRelatedModules( $entity, $models, $modules, $retainedIds );
        $retained = array_flip( $retainedIds );
        $retainedCount = count( $retainedIds );
        $records = [];

        foreach ( $models as $model ) {
            $rootId = (int) $model->id;

            if ( !isset( $retained[$rootId] ) ) {
                continue;
            }

            $record = ['record_id' => $rootId];

            foreach ( $modules as $module ) {
                if ( $module === $entity ) {
                    $record[$module] = $this->projectAttributes( $module, $model );
                    continue;
                }

                $record[$module] = $related[$module][$rootId] ?? $this->emptyModuleValue( $module );
            }

            $records[] = $record;

            if ( count( $records ) < $retainedCount && $this->budgetExhausted() ) {
                break;
            }
        }

        return $records;
    }

    private function loadRelatedModules(
        string $entity,
        $models,
        array $modules,
        array &$retainedIds
    ): array
    {
        $related = [];

        if ( $entity === ExportSchema::ORDERS ) {
            $customerIds = array_values( array_unique( array_filter(
                array_map( 'intval', $models->pluck( 'customer_id' )->all() )
            ) ) );

            if ( in_array( 'customers', $modules, true ) ) {
                $related['customers'] = $this->mapOrderCustomers( $models, $customerIds );
            }

            $moduleModels = [
                'order_items'        => [OrderItem::class, 'order_id'],
                'order_addresses'    => [OrderAddress::class, 'order_id'],
                'order_transactions' => [OrderTransaction::class, 'order_id'],
                'order_tax_rates'    => [OrderTaxRate::class, 'order_id'],
                'order_meta'         => [OrderMeta::class, 'order_id'],
            ];
        } elseif ( $entity === ExportSchema::CUSTOMERS ) {
            if ( in_array( 'purchased_items', $modules, true ) ) {
                $this->limitRootsForRelatedLoad( $retainedIds );
                $related['purchased_items'] = $this->mapPurchasedItems( $retainedIds );
            }

            $moduleModels = [
                'customer_addresses' => [CustomerAddresses::class, 'customer_id'],
                'customer_meta'      => [CustomerMeta::class, 'customer_id'],
            ];
        } elseif ( $entity === ExportSchema::SUBSCRIPTIONS ) {
            if ( in_array( 'customers', $modules, true ) ) {
                $related['customers'] = $this->mapRelatedRows(
                    $models,
                    'customer_id',
                    Customer::class,
                    'customers'
                );
            }

            if ( in_array( 'parent_orders', $modules, true ) ) {
                $related['parent_orders'] = $this->mapRelatedRows(
                    $models,
                    'parent_order_id',
                    Order::class,
                    'parent_orders'
                );
            }

            $moduleModels = [
                'subscription_transactions' => [OrderTransaction::class, 'subscription_id'],
                'subscription_meta'         => [SubscriptionMeta::class, 'subscription_id'],
                'licenses'                  => [License::class, 'subscription_id'],
            ];
        } else {
            if ( in_array( 'customers', $modules, true ) ) {
                $related['customers'] = $this->mapRelatedRows(
                    $models,
                    'customer_id',
                    Customer::class,
                    'customers'
                );
            }

            if ( in_array( 'orders', $modules, true ) ) {
                $related['orders'] = $this->mapRelatedRows(
                    $models,
                    'order_id',
                    Order::class,
                    'orders'
                );
            }

            if ( in_array( 'subscriptions', $modules, true ) ) {
                $related['subscriptions'] = $this->mapRelatedRows(
                    $models,
                    'subscription_id',
                    Subscription::class,
                    'subscriptions'
                );
            }

            $moduleModels = [];
            $needsActivations = in_array( 'license_activations', $modules, true )
                || in_array( 'license_sites', $modules, true );

            if ( $needsActivations ) {
                $this->limitRootsForRelatedLoad( $retainedIds );
                $activations = $this->boundedRelatedQuery(
                    LicenseActivation::class,
                    'license_id',
                    $retainedIds,
                    'license_activations'
                );

                if ( in_array( 'license_activations', $modules, true ) ) {
                    $related['license_activations'] = $this->groupRows(
                        $activations,
                        'license_id',
                        'license_activations'
                    );
                }

                if ( in_array( 'license_sites', $modules, true ) ) {
                    $related['license_sites'] = $this->mapLicenseSites( $activations );
                }
            }

            if ( in_array( 'license_meta', $modules, true ) ) {
                $this->limitRootsForRelatedLoad( $retainedIds );
                $related['license_meta'] = $this->groupRows(
                    $this->boundedRelatedQuery(
                        LicenseMeta::class,
                        'object_id',
                        $retainedIds,
                        'license_meta',
                        function ( $query ) {
                            $query->where( 'object_type', 'license' );
                        }
                    ),
                    'object_id',
                    'license_meta'
                );
            }
        }

        foreach ( $moduleModels as $module => $definition ) {
            if ( !in_array( $module, $modules, true ) ) {
                continue;
            }

            $this->limitRootsForRelatedLoad( $retainedIds );

            $modelClass = $definition[0];
            $related[$module] = $this->groupRows(
                $this->boundedRelatedQuery(
                    $modelClass,
                    $definition[1],
                    $retainedIds,
                    $module
                ),
                $definition[1],
                $module
            );
        }

        return $related;
    }

    private function mapOrderCustomers( $orders, array $customerIds ): array
    {
        if ( !$customerIds ) {
            return [];
        }

        $customersById = [];
        $customerQuery = Customer::query()
            ->whereIn( 'id', $customerIds )
            ->select( $this->relatedSelectColumns( 'customers', 'id' ) );

        foreach ( $customerQuery->get() as $customer ) {
            $customersById[(int) $customer->id] = $this->projectAttributes( 'customers', $customer );
        }

        $mapped = [];
        foreach ( $orders as $order ) {
            $mapped[(int) $order->id] = $customersById[(int) $order->customer_id] ?? null;
        }

        return $mapped;
    }

    /**
     * One flat row per line item, carrying its order's status, so a customer's
     * products can be mapped without joining the orders export.
     */
    private function mapPurchasedItems( array $customerIds ): array
    {
        $orders = $this->boundedRelatedQuery(
            Order::class,
            'customer_id',
            $customerIds,
            'purchased_items',
            function ( $query ) {
                $query->select( [
                    'id', 'customer_id', 'invoice_no', 'status', 'payment_status',
                    'type', 'currency', 'created_at',
                ] );
            }
        );

        if ( $orders->isEmpty() ) {
            return [];
        }

        $items = $this->boundedRelatedQuery(
            OrderItem::class,
            'order_id',
            array_map( 'intval', $orders->pluck( 'id' )->all() ),
            'purchased_items',
            function ( $query ) {
                $query->select( [
                    'id', 'order_id', 'post_id', 'object_id', 'post_title', 'title',
                    'quantity', 'unit_price', 'line_total', 'refund_total', 'payment_type',
                ] );
            }
        );

        $itemsByOrder = [];
        foreach ( $items as $item ) {
            $itemsByOrder[(int) $item->order_id][] = $item->getAttributes();
        }

        $mapped = [];
        foreach ( $orders as $orderModel ) {
            $order = $orderModel->getAttributes();

            foreach ( $itemsByOrder[(int) $order['id']] ?? [] as $item ) {
                $mapped[(int) $order['customer_id']][] = [
                    'order_id'        => (int) $order['id'],
                    'invoice_no'      => $order['invoice_no'],
                    'order_status'    => $order['status'],
                    'payment_status'  => $order['payment_status'],
                    'order_type'      => $order['type'],
                    'currency'        => $order['currency'],
                    'order_date'      => $order['created_at'],
                    'item_id'         => (int) $item['id'],
                    'product_id'      => (int) $item['post_id'],
                    'variation_id'    => (int) $item['object_id'],
                    'product_title'   => $item['post_title'],
                    'variation_title' => $item['title'],
                    'quantity'        => (int) $item['quantity'],
                    'unit_price'      => $item['unit_price'],
                    'line_total'      => $item['line_total'],
                    'refund_total'    => $item['refund_total'],
                    'payment_type'    => $item['payment_type'],
                ];
            }
        }

        return $mapped;
    }

    private function mapRelatedRows(
        $models,
        string $foreignKey,
        string $modelClass,
        string $module
    ): array
    {
        $relatedIds = array_values( array_unique( array_filter(
            array_map( 'intval', $models->pluck( $foreignKey )->all() )
        ) ) );

        if ( !$relatedIds ) {
            return [];
        }

        $rowsById = [];
        $relatedQuery = $modelClass::query()
            ->whereIn( 'id', $relatedIds )
            ->select( $this->relatedSelectColumns( $module, 'id' ) );

        foreach ( $relatedQuery->get() as $model ) {
            $rowsById[(int) $model->id] = $this->projectAttributes( $module, $model );
        }

        $mapped = [];
        foreach ( $models as $model ) {
            $mapped[(int) $model->id] = $rowsById[(int) $model->{$foreignKey}] ?? null;
        }

        return $mapped;
    }

    private function mapLicenseSites( $activations ): array
    {
        $siteIds = array_values( array_unique( array_filter(
            array_map( 'intval', $activations->pluck( 'site_id' )->all() )
        ) ) );

        if ( !$siteIds ) {
            return [];
        }

        $sitesById = [];
        $siteQuery = LicenseSite::query()
            ->whereIn( 'id', $siteIds )
            ->select( $this->relatedSelectColumns( 'license_sites', 'id' ) );

        foreach ( $siteQuery->get() as $site ) {
            $sitesById[(int) $site->id] = $this->projectAttributes( 'license_sites', $site );
        }

        $mapped = [];
        $seen = [];
        foreach ( $activations as $activation ) {
            $licenseId = (int) $activation->license_id;
            $siteId = (int) $activation->site_id;

            if ( !isset( $sitesById[$siteId] ) || isset( $seen[$licenseId][$siteId] ) ) {
                continue;
            }

            $mapped[$licenseId][] = $sitesById[$siteId];
            $seen[$licenseId][$siteId] = true;
        }

        return $mapped;
    }

    private function groupRows( $models, string $foreignKey, string $module ): array
    {
        $grouped = [];

        foreach ( $models as $model ) {
            $ownerId = (int) $model->{$foreignKey};

            if ( !isset( $grouped[$ownerId] ) ) {
                $grouped[$ownerId] = [];
            }

            $grouped[$ownerId][] = $this->projectAttributes( $module, $model );
        }

        return $grouped;
    }

    private function boundedRelatedQuery(
        string $modelClass,
        string $foreignKey,
        array $rootIds,
        string $module,
        ?callable $configure = null
    ) {
        $query = $modelClass::query()
            ->whereIn( $foreignKey, $rootIds )
            ->select( $this->relatedSelectColumns( $module, $foreignKey ) )
            ->orderBy( 'id', 'asc' )
            ->limit( self::RELATED_ROW_LIMIT + 1 );

        if ( $configure ) {
            $configure( $query );
        }

        $rows = $query->get();
        $this->relatedRowsLoaded += $rows->count();

        if ( $rows->count() > self::RELATED_ROW_LIMIT ) {
            throw new ExportRecordTooLargeException(
                sprintf(
                    /* translators: %s is the export module name. */
                    __( 'The %s module has too many related rows for one safe response. Select fewer JSON modules and try again.', 'fluent-cart-pro' ),
                    $module
                )
            );
        }

        return $rows;
    }

    /**
     * Only the columns a module actually emits, plus the keys needed to group
     * the rows back onto their owner.
     */
    private function relatedSelectColumns( string $module, string $foreignKey ): array
    {
        return array_values( array_unique( array_merge(
            $this->moduleFields( $module ),
            ['id', $foreignKey]
        ) ) );
    }

    private function moduleFields( string $module ): array
    {
        if ( $module === 'parent_orders' ) {
            $module = 'orders';
        } elseif ( $module === 'subscription_transactions' ) {
            $module = 'order_transactions';
        }

        return self::JSON_FIELDS[$module] ?? ['id'];
    }

    private function projectAttributes( string $module, $model ): array
    {
        $attributes = array_intersect_key(
            $model->getAttributes(),
            array_flip( $this->moduleFields( $module ) )
        );

        if (
            isset( $attributes['meta_key'], $attributes['meta_value'] )
            && $this->isSensitiveKey( (string) $attributes['meta_key'] )
        ) {
            $attributes['meta_value'] = '[REDACTED]';
        }

        foreach ( $attributes as $key => $value ) {
            $attributes[$key] = $this->redactSensitiveValue( $value, (string) $key );
        }

        return $attributes;
    }

    private function redactSensitiveValue( $value, string $key = '' )
    {
        if ( $this->isSensitiveKey( $key ) ) {
            return '[REDACTED]';
        }

        if ( is_array( $value ) ) {
            $redacted = [];
            foreach ( $value as $nestedKey => $nestedValue ) {
                $redacted[$nestedKey] = $this->redactSensitiveValue(
                    $nestedValue,
                    is_string( $nestedKey ) ? $nestedKey : ''
                );
            }

            return $redacted;
        }

        if ( !is_string( $value ) ) {
            return $value;
        }

        $trimmed = ltrim( $value );
        if ( $trimmed === '' || !in_array( $trimmed[0], ['{', '['], true ) ) {
            return $value;
        }

        $decoded = json_decode( $value, true );
        if ( !is_array( $decoded ) || json_last_error() !== JSON_ERROR_NONE ) {
            return $value;
        }

        return wp_json_encode( $this->redactSensitiveValue( $decoded ) );
    }

    private function isSensitiveKey( string $key ): bool
    {
        $normalized = strtolower( str_replace( ['-', ' '], '_', $key ) );

        return (bool) preg_match(
            '/(^|_)(activation_hash|token|client_secret|secret|password|api_key|private_key|authorization|credential|payment_method_id|vendor_method_id|source_id|mandate_id|vault_id)($|_)/',
            $normalized
        );
    }

    private function effectiveLicenseStatus( $license ): string
    {
        $status = (string) ( $license->status ?? '' );
        $expirationDate = (string) ( $license->expiration_date ?? '' );

        if (
            !in_array( $status, ['expired', 'disabled'], true )
            && $expirationDate
            && DateTime::gmtNow() > $expirationDate
        ) {
            return 'expiring';
        }

        return $status;
    }

    private function emptyModuleValue( string $module )
    {
        return in_array( $module, ['customers', 'orders', 'subscriptions', 'parent_orders'], true )
            ? null
            : [];
    }

    private function toDecimal( $value ): string
    {
        if ( $value === null || $value === '' ) {
            return '';
        }

        return number_format( ( (float) $value ) / 100, 2, '.', '' );
    }

    private function suggestNextMaximum(
        int $requested,
        int $returned,
        int $elapsedMs,
        int $bytes
    ): int
    {
        if ( !$returned ) {
            return 100;
        }

        $safeElapsed = max( 250, $elapsedMs );
        $safeBytes = max( 1, $bytes );
        $timeTarget = (int) floor( $returned * ( 1500 / $safeElapsed ) );
        $byteTarget = (int) floor(
            $returned * ( self::PAYLOAD_BUDGET_BYTES / $safeBytes ) * 0.9
        );
        $target = min( $timeTarget, $byteTarget, 1000 );
        $baseline = min( $requested, max( 100, $returned ) );
        $damped = (int) round( ( $baseline + $target ) / 2 );

        return min( 1000, max( 100, $damped ) );
    }
}
