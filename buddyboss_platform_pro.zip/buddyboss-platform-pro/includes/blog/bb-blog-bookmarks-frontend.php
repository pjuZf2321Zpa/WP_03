<?php
/**
 * BuddyBoss Pro Blog Bookmarks — frontend (button, profile subnav, screen).
 *
 * Loaded from `BB_Blog::includes()` only when `bb_blog_pro_is_bookmarking_enabled()`
 * is true. Requires `bb-blog-bookmarks.php` (storage/AJAX) to already be loaded.
 *
 * @package BuddyBossPro
 *
 * @since 3.1.0
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

/**
 * Render the bookmark button for the current post.
 *
 * Only renders on a single `post`, for logged-in users, when the bookmarking
 * gate passes. Hooked onto the Platform's `bb_rl_blog_single_meta_actions`
 * action (priority 20) so the button sits in the single post info row,
 * alongside the subscribe bell.
 *
 * @since 3.1.0
 *
 * @param int $post_id Optional. Defaults to the current post in the loop.
 *
 * @return void
 */
function bb_blog_pro_render_bookmark_button( $post_id = 0 ) {
	$post_id = absint( $post_id );

	if ( empty( $post_id ) ) {
		$post_id = get_the_ID();
	}

	if ( empty( $post_id ) || ! is_singular( 'post' ) || ! is_user_logged_in() || ! bb_blog_pro_is_bookmarking_enabled() ) {
		return;
	}

	$is_bookmarked = bb_blog_pro_is_bookmarked( $post_id );
	?>
	<button
		type="button"
		class="bb-blog-bookmark<?php echo esc_attr( $is_bookmarked ? ' is-bookmarked' : '' ); ?>"
		data-post-id="<?php echo esc_attr( $post_id ); ?>"
		aria-pressed="<?php echo esc_attr( $is_bookmarked ? 'true' : 'false' ); ?>"
		aria-label="<?php echo $is_bookmarked ? esc_attr__( 'Remove bookmark', 'buddyboss-pro' ) : esc_attr__( 'Bookmark this post', 'buddyboss-pro' ); ?>"
	>
		<i class="<?php echo esc_attr( bb_blog_pro_icon_class( 'bb-icons-rl-bookmark-simple', 'bb-icon-l bb-icon-bookmark' ) ); ?> bb-blog-bookmark__icon" aria-hidden="true"></i>
	</button>
	<?php
}
add_action( 'bb_rl_blog_single_meta_actions', 'bb_blog_pro_render_bookmark_button', 20 );

/**
 * Whether the bookmark button (or a list of bookmark buttons) can render
 * for the current request.
 *
 * True on a single post (the post footer button) and on the member "Blogs"
 * profile screens -- both "My Posts" and "Bookmarks" subnavs share the
 * `blog` component slug, and the Bookmarks screen renders one bookmark
 * button per listed post.
 *
 * @since 3.1.0
 *
 * @return bool
 */
function bb_blog_pro_bookmark_button_will_render() {
	if ( ! is_user_logged_in() || ! bb_blog_pro_is_bookmarking_enabled() ) {
		return false;
	}

	if ( is_singular( 'post' ) ) {
		return true;
	}

	return function_exists( 'bp_is_current_component' ) && bp_is_current_component( 'blog' );
}

/**
 * Enqueue the bookmark button script/style when the gate passes.
 *
 * @since 3.1.0
 *
 * @return void
 */
function bb_blog_pro_bookmarks_enqueue_scripts() {
	if ( ! bb_blog_pro_bookmark_button_will_render() ) {
		return;
	}

	$version = bb_platform_pro()->version;

	// Shared style handle registered in bb-blog-loader.php — see
	// bb_blog_pro_register_frontend_style(). Both blog frontends load the same
	// stylesheet, so they share one handle to avoid a duplicate <link> tag.
	wp_enqueue_style( 'bb-blog-pro' );

	wp_enqueue_script(
		'bb-blog-pro-bookmarks',
		bb_blog_pro_url( 'assets/js/bb-blog-bookmarks.js' ),
		array(),
		$version,
		true
	);

	wp_localize_script(
		'bb-blog-pro-bookmarks',
		'bbBlogProBookmarks',
		array(
			'ajaxUrl' => admin_url( 'admin-ajax.php' ),
			'nonce'   => wp_create_nonce( 'bb-blog-pro-bookmark' ),
			'labels'  => array(
				'add'    => __( 'Bookmark this post', 'buddyboss-pro' ),
				'remove' => __( 'Remove bookmark', 'buddyboss-pro' ),
			),
		)
	);
}
add_action( 'wp_enqueue_scripts', 'bb_blog_pro_bookmarks_enqueue_scripts' );

/**
 * AJAX: toggle the current user's bookmark on a post.
 *
 * Reports the store's REAL result. The previous implementation returned a
 * hardcoded success, so a failed write still flipped the button and the user
 * silently lost the bookmark on reload.
 *
 * @since 3.1.0
 *
 * @return void
 */
function bb_blog_pro_ajax_toggle_bookmark() {
	if ( ! is_user_logged_in() ) {
		wp_send_json_error( array( 'message' => __( 'You must be logged in to bookmark a post.', 'buddyboss-pro' ) ) );
	}

	check_ajax_referer( 'bb-blog-pro-bookmark', 'nonce' );

	$post_id = ! empty( $_POST['post_id'] ) ? absint( wp_unslash( $_POST['post_id'] ) ) : 0;

	if ( empty( $post_id ) ) {
		wp_send_json_error( array( 'message' => __( 'A valid post is required.', 'buddyboss-pro' ) ) );
	}

	$result = bb_blog_pro_toggle_bookmark( $post_id, get_current_user_id() );

	if ( is_wp_error( $result ) ) {
		wp_send_json_error( array( 'message' => $result->get_error_message() ) );
	}

	wp_send_json_success(
		array(
			'bookmarked' => (bool) $result,
			'count'      => bb_blog_pro_get_bookmark_count( $post_id ),
		)
	);
}
add_action( 'wp_ajax_bb_blog_pro_toggle_bookmark', 'bb_blog_pro_ajax_toggle_bookmark' );

/**
 * Register the member profile "Bookmarked" subnav.
 *
 * Runs on `bp_setup_nav` at priority 110 -- AFTER the Platform's
 * `bb_blog_setup_profile_nav()` (priority 100) has registered the parent
 * `blog` nav item, and after the Member Blogging add-on (priority 105) has
 * registered its default "My Blogs" subnav at the parent slug. When the
 * add-on is not booted, the tab's default is repointed at this Bookmarked
 * subnav instead (see the `bp_core_new_nav_default()` call below).
 *
 * @since 3.1.0
 *
 * @return void
 */
function bb_blog_pro_setup_bookmarks_subnav() {
	if ( ! bb_blog_pro_is_bookmarking_enabled() ) {
		return;
	}

	if ( ! function_exists( 'bp_core_new_subnav_item' ) || ! function_exists( 'bp_displayed_user_domain' ) ) {
		return;
	}

	// Parent nav item ('blog') must already be registered by the Platform.
	if ( ! function_exists( 'buddypress' ) || ! buddypress()->members->nav->get_primary( array( 'slug' => 'blog' ), false ) ) {
		return;
	}

	// Off-profile (e.g. nav menu items) there is no displayed user; link to the logged-in user.
	$user_domain = bp_displayed_user_domain() ? bp_displayed_user_domain() : bp_loggedin_user_domain();
	$parent_url  = trailingslashit( $user_domain . 'blog' );

	// "Bookmarked" — own-profile only.
	bp_core_new_subnav_item(
		array(
			'name'            => __( 'Bookmarked', 'buddyboss-pro' ),
			'slug'            => 'bookmarks',
			'parent_slug'     => 'blog',
			'parent_url'      => $parent_url,
			'screen_function' => 'bb_blog_pro_screen_bookmarks',
			'position'        => 20,
			'user_has_access' => bp_is_my_profile(),
		)
	);

	// Without a booted Member Blogging add-on there is no "My Blogs" subnav,
	// so the tab's default (the Platform's member-posts screen) would strand
	// Bookmarked with no visible sub-tab. Repoint the tab at Bookmarked via
	// bp_core_new_nav_default() — a filtered `default_subnav_slug` is not
	// enough, since BP hooks the parent's screen_function on the bare tab
	// URL regardless of that slug. Own profile only: the subnav is
	// own-profile gated, and visitors keep the member-posts screen.
	if ( ! bb_blog_pro_is_member_blogging_active() && bp_is_my_profile() ) {
		bp_core_new_nav_default(
			array(
				'parent_slug'     => 'blog',
				'screen_function' => 'bb_blog_pro_screen_bookmarks',
				'subnav_slug'     => 'bookmarks',
			)
		);
	}
}
add_action( 'bp_setup_nav', 'bb_blog_pro_setup_bookmarks_subnav', 110 );
add_filter( 'bb_blog_profile_nav_enabled', '__return_true' );

/**
 * Whether a nouveau nav item is the profile "Bookmarked" subnav.
 *
 * @since 3.1.0
 *
 * @param object $nav_item      Nav item being rendered.
 * @param string $displayed_nav Current nav context ('personal', 'groups', 'directory').
 *
 * @return bool
 */
function bb_blog_pro_is_bookmarks_subnav( $nav_item, $displayed_nav ) {
	return 'personal' === $displayed_nav
		&& empty( $nav_item->primary )
		&& isset( $nav_item->slug, $nav_item->parent_slug )
		&& 'bookmarks' === $nav_item->slug
		&& 'blog' === $nav_item->parent_slug;
}

/**
 * Show a count on the "Bookmarked" subnav when Content Counts is enabled.
 *
 * The `bp_nouveau_nav_has_count` filter runs outside the helper's own
 * `bb_enable_content_counts()` gate, so the setting is re-checked here.
 *
 * @since 3.1.0
 *
 * @param bool   $has_count     Whether the nav item shows a count.
 * @param object $nav_item      Nav item being rendered.
 * @param string $displayed_nav Current nav context.
 *
 * @return bool
 */
function bb_blog_pro_filter_bookmarks_nav_has_count( $has_count, $nav_item, $displayed_nav ) {
	if ( bb_blog_pro_is_bookmarks_subnav( $nav_item, $displayed_nav )
		&& function_exists( 'bb_enable_content_counts' )
		&& bb_enable_content_counts() ) {
		return true;
	}

	return $has_count;
}
add_filter( 'bp_nouveau_nav_has_count', 'bb_blog_pro_filter_bookmarks_nav_has_count', 10, 3 );

/**
 * Supply the "Bookmarked" subnav count value.
 *
 * @since 3.1.0
 *
 * @param int    $count         Count for the nav item.
 * @param object $nav_item      Nav item being rendered.
 * @param string $displayed_nav Current nav context.
 *
 * @return int
 */
function bb_blog_pro_filter_bookmarks_nav_count( $count, $nav_item, $displayed_nav ) {
	if ( bb_blog_pro_is_bookmarks_subnav( $nav_item, $displayed_nav )
		&& function_exists( 'bb_enable_content_counts' )
		&& bb_enable_content_counts() ) {
		return bb_blog_pro_get_user_bookmark_count( bp_displayed_user_id() );
	}

	return $count;
}
add_filter( 'bp_nouveau_get_nav_count', 'bb_blog_pro_filter_bookmarks_nav_count', 10, 3 );

/**
 * Whether the Member Blogging add-on's frontend features are booted.
 *
 * Mirrors the add-on's own boot gate (feature active + DRM unlock) rather
 * than `class_exists()` — the add-on's main class file is loaded for
 * Settings 2.0 registration even while the feature is toggled off or the
 * license is locked, states in which its "My Blogs" subnav never registers.
 *
 * @since 3.1.0
 *
 * @return bool
 */
function bb_blog_pro_is_member_blogging_active() {
	return class_exists( 'BB_Member_Blogging' )
		&& function_exists( 'bb_feature_registry' )
		&& bb_feature_registry()->bb_is_feature_active( 'member_blogging' )
		&& BB_Member_Blogging::should_load_features();
}

/**
 * Screen handler for the member "Bookmarks" tab.
 *
 * @since 3.1.0
 *
 * @return void
 */
function bb_blog_pro_screen_bookmarks() {
	add_action( 'bp_template_content', 'bb_blog_pro_bookmarks_content' );

	/**
	 * Filter the template loaded for the member Bookmarks screen.
	 *
	 * @since 3.1.0
	 *
	 * @param string $template Template name.
	 */
	bp_core_load_template( apply_filters( 'bb_blog_pro_screen_bookmarks_template', 'members/single/home' ) );
}

/**
 * Output the member "Bookmarked" tab — a paginated list of bookmarked posts.
 *
 * Paginates off the bookmark store's own total. The previous version called
 * `the_posts_pagination()`, which reads the GLOBAL $wp_query — on a BuddyPress
 * profile screen that is the members query, so it always saw one page and
 * rendered nothing. The list was silently capped at 10 with no way to page.
 *
 * An unavailable (deleted/unpublished) post is still rendered, with its
 * remove button intact -- that is what keeps the subnav count and this list
 * in agreement, and what lets a user clear a stuck bookmark.
 *
 * An out-of-range `bpage` (e.g. 2 real pages but `?bpage=999`) is clamped to
 * the last real page and re-fetched, rather than falling into the "no
 * bookmarks at all" empty state -- that message is reserved for a genuine
 * zero total. The store's total comes from its own unpaginated COUNT query
 * (see `BB_Bookmarks::get()`), already run as part of the first fetch, so
 * clamping after the fact costs one extra (uncounted) id-lookup query only
 * on the out-of-range path -- cheaper than always counting before the main
 * fetch, which would cost that extra query on every page load.
 *
 * @since 3.1.0
 *
 * @return void
 */
function bb_blog_pro_bookmarks_content() {

	/**
	 * Fires before the member Bookmarked list renders.
	 *
	 * @since 3.1.0
	 */
	do_action( 'bb_blog_bookmarks_before' );

	$user_id = bp_displayed_user_id();

	if ( empty( $user_id ) || ! bb_blog_pro_has_bookmark_engine() ) {
		return;
	}

	// ReadyLaunch renders the `.bb-rl-blog-*` cards; the standard template pack
	// renders the Platform `.bb-member-blog*` cards. Match the list wrapper and
	// empty state to whichever pack is active so the Bookmarked tab mirrors the
	// sibling "My Blogs" tab in both modes.
	$bb_is_rl = function_exists( 'bb_is_readylaunch_enabled' ) && bb_is_readylaunch_enabled();

	$per_page = 10;

	$paged = ! empty( $_GET['bpage'] ) ? absint( wp_unslash( $_GET['bpage'] ) ) : 1; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only pagination.
	$paged = max( 1, $paged );

	// Newest / Oldest by bookmark date — same `bb-sort` parameter the profile
	// "My Blogs" toolbar uses.
	$sort = isset( $_GET['bb-sort'] ) ? sanitize_key( wp_unslash( $_GET['bb-sort'] ) ) : 'newest'; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only sort.
	if ( ! in_array( $sort, array( 'newest', 'oldest' ), true ) ) {
		$sort = 'newest';
	}

	$result = bb_bookmark_get_user_items(
		array(
			'type'     => BB_BLOG_PRO_BOOKMARK_TYPE,
			'user_id'  => $user_id,
			'status'   => 1,
			'order_by' => 'date_recorded',
			'order'    => 'oldest' === $sort ? 'ASC' : 'DESC',
			'per_page' => $per_page,
			'page'     => $paged,
			'count'    => true,
		)
	);

	$bookmarks = ! empty( $result['bookmarks'] ) ? $result['bookmarks'] : array();
	$total     = ! empty( $result['total'] ) ? (int) $result['total'] : 0;

	// Requested page has no rows but the user does have bookmarks -- clamp
	// to the last real page and re-fetch it instead of showing the
	// "no bookmarks at all" empty state. Skip the count query this time;
	// $total is already known.
	if ( empty( $bookmarks ) && $total > 0 ) {
		$paged = max( 1, (int) ceil( $total / $per_page ) );

		$result = bb_bookmark_get_user_items(
			array(
				'type'     => BB_BLOG_PRO_BOOKMARK_TYPE,
				'user_id'  => $user_id,
				'status'   => 1,
				'order_by' => 'date_recorded',
				'order'    => 'oldest' === $sort ? 'ASC' : 'DESC',
				'per_page' => $per_page,
				'page'     => $paged,
				'count'    => false,
			)
		);

		$bookmarks = ! empty( $result['bookmarks'] ) ? $result['bookmarks'] : array();
	}

	if ( empty( $bookmarks ) ) {
		if ( $bb_is_rl ) {
			?>
			<div class="bb-rl-blog-empty">
				<p>
					<i class="bb-icons-rl-info"></i>
					<?php esc_html_e( 'No bookmarked posts yet.', 'buddyboss-pro' ); ?>
				</p>
			</div>
			<?php
		} else {
			?>
			<p class="bb-member-blog__empty">
				<i class="bb-icon-info"></i>
				<?php esc_html_e( 'No bookmarked posts yet.', 'buddyboss-pro' ); ?>
			</p>
			<?php
		}
		return;
	}

	// Ordered post IDs from the bookmark records (newest / oldest by bookmark
	// date). Deleted or unpublished bookmarks are dropped by the WP_Query
	// `post_status` filter below -- the Bookmarked tab shows live posts only.
	$bb_bookmark_ids = array();
	foreach ( $bookmarks as $bb_bookmark ) {
		$bb_bookmark_ids[] = (int) $bb_bookmark->item_id;
	}

	// Reuse the Platform's ReadyLaunch blog card (`blog/loop-post`) so the
	// Bookmarked tab is pixel-identical to the sibling "My Blogs" tab and the
	// blog archive. `orderby => post__in` preserves the bookmark-date order,
	// and `loop_start` auto-primes the bookmark cache
	// (`bb_blog_pro_prime_bookmark_cache`), so the per-card chip stays cheap.
	$bb_bookmarks_query = new WP_Query(
		array(
			'post_type'           => 'post',
			'post__in'            => $bb_bookmark_ids,
			'orderby'             => 'post__in',
			// phpcs:ignore WordPress.WP.PostsPerPage.posts_per_page_posts_per_page -- Bounded: $bookmarks is already paginated by $per_page above.
			'posts_per_page'      => count( $bb_bookmark_ids ),
			'post_status'         => 'publish',
			'ignore_sticky_posts' => true,
			'no_found_rows'       => true,
		)
	);

	if ( $bb_bookmarks_query->have_posts() ) :
		if ( $bb_is_rl ) {
			?>
			<div class="bb-rl-blog-grid bb-rl-blog-grid--profile">
				<?php
				// Default (non-status) card layout: View Post button + comment
				// count, with the bookmark chip added on `bb_blog_card_actions`.
				while ( $bb_bookmarks_query->have_posts() ) :
					$bb_bookmarks_query->the_post();
					bp_get_template_part( 'blog/loop-post' );
				endwhile;
				?>
			</div>
			<?php
		} else {
			?>
			<div class="bb-member-blog">
				<div class="bb-member-blog__list">
					<?php
					// The standard-pack card reads `bb_blog_card_context` to drop
					// the status tag and owner menu on bookmarked posts.
					set_query_var( 'bb_blog_card_context', 'bookmarks' );
					while ( $bb_bookmarks_query->have_posts() ) :
						$bb_bookmarks_query->the_post();
						bp_get_template_part( 'blog/loop-post' );
					endwhile;
					set_query_var( 'bb_blog_card_context', '' );
					?>
				</div>
			</div>
			<?php
		}
		wp_reset_postdata();
	endif;

	$total_pages = (int) ceil( $total / $per_page );

	if ( $total_pages > 1 ) {
		$bb_bookmarks_links = paginate_links(
			array(
				'base'      => add_query_arg( 'bpage', '%#%' ),
				'format'    => '',
				'current'   => $paged,
				'total'     => $total_pages,
				'mid_size'  => 2,
				'prev_text' => esc_html__( 'Previous', 'buddyboss-pro' ),
				'next_text' => esc_html__( 'Next', 'buddyboss-pro' ),
			)
		);

		if ( ! empty( $bb_bookmarks_links ) ) {
			// Same wrapper as the Platform's member Blogs tab so the shared
			// `.navigation.pagination` styles apply.
			printf(
				'<nav class="navigation pagination" aria-label="%1$s"><div class="nav-links">%2$s</div></nav>',
				esc_attr__( 'Bookmarked posts pagination', 'buddyboss-pro' ),
				wp_kses_post( $bb_bookmarks_links )
			);
		}
	}
}

/**
 * Warm the bookmark cache for every post about to be rendered in a loop.
 *
 * Without this, each card's `bb_blog_pro_is_bookmarked()` costs its own query —
 * 20 cards, 20 queries.
 *
 * Deliberately NOT gated on `$query->is_main_query()`. Bookmark chip cards
 * also render off secondary `WP_Query` loops -- the profile "Blogs" tab
 * (`member-posts.php`) and "Related Blogs" on a single post
 * (`bb_blog_get_related_posts()`) -- where `is_main_query()` is false and
 * priming would otherwise never run, leaving those screens with the very
 * N+1 this function exists to eliminate.
 *
 * `loop_start` fires once per `WP_Query` on the page (menus, widgets, and
 * unrelated queries included), not once per post, so this stays cheap:
 * priming is a single query, the cache it writes is incrementor-scoped, and
 * re-priming the same IDs from a second loop on the same page is a harmless
 * no-op. Do NOT move this to `the_post` -- that fires once per post and
 * would reintroduce the N+1 it is meant to fix.
 *
 * @since 3.1.0
 *
 * @param WP_Query $query The query about to render.
 *
 * @return void
 */
function bb_blog_pro_prime_bookmark_cache( $query ) {
	if ( is_admin() || ! is_user_logged_in() ) {
		return;
	}

	if ( ! bb_blog_pro_is_bookmarking_enabled() || ! bb_blog_pro_has_bookmark_engine() ) {
		return;
	}

	if ( empty( $query->posts ) ) {
		return;
	}

	// Only posts of type `post` carry bookmark chips -- a loop over pages or
	// another CPT has nothing for this cache to warm.
	$post_ids = array();

	foreach ( $query->posts as $queried_post ) {
		if ( isset( $queried_post->post_type, $queried_post->ID ) && 'post' === $queried_post->post_type ) {
			$post_ids[] = (int) $queried_post->ID;
		}
	}

	if ( empty( $post_ids ) ) {
		return;
	}

	bb_bookmark_prime_cache( BB_BLOG_PRO_BOOKMARK_TYPE, $post_ids, get_current_user_id() );
}
add_action( 'loop_start', 'bb_blog_pro_prime_bookmark_cache' );
