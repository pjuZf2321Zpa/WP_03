<?php

namespace WPAICG\ContentWriter\SEO;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Applies small Yoast-specific alignment fixes after a focus keyphrase changes.
 */
class AIPKit_Content_Writer_Smart_SEO_Yoast_Content_Helper
{
    public static function maybe_improve_draft(array $draft, array $context = []): array
    {
        if (sanitize_key((string) ($context['profile'] ?? '')) !== 'yoast') {
            return $draft;
        }

        $focus_keyphrase = isset($draft['focus_keyword']) ? sanitize_text_field((string) $draft['focus_keyword']) : '';
        if ($focus_keyphrase === '') {
            return $draft;
        }

        $title = isset($draft['title']) ? sanitize_text_field((string) $draft['title']) : '';
        $display_keyphrase = self::display_keyphrase($focus_keyphrase, $title);
        $content = isset($draft['content_html']) && trim((string) $draft['content_html']) !== ''
            ? (string) $draft['content_html']
            : (string) ($draft['content'] ?? '');

        if ($content !== '') {
            if (self::rule_enabled($context, 'focus_keyword_in_introduction')) {
                $content = self::ensure_intro_keyphrase($content, $focus_keyphrase, $display_keyphrase);
            }
            if (self::rule_enabled($context, 'focus_keyword_in_heading')) {
                $content = self::ensure_subheading_keyphrase($content, $focus_keyphrase, $display_keyphrase);
            }
            if (self::rule_enabled($context, 'keyword_density')) {
                $content = self::ensure_minimum_density($content, $focus_keyphrase, $display_keyphrase);
            }
            $draft['content_html'] = $content;
            $draft['content'] = $content;
        }

        $meta_keyphrase_enabled = self::rule_enabled($context, 'focus_keyword_in_meta_description');
        $meta_length_enabled = self::rule_enabled($context, 'meta_description_length');
        if ($meta_keyphrase_enabled || $meta_length_enabled) {
            $draft['meta_description'] = self::ensure_meta_description(
                (string) ($draft['meta_description'] ?? ''),
                $focus_keyphrase,
                $display_keyphrase,
                $meta_keyphrase_enabled
            );
        }

        return $draft;
    }

    private static function rule_enabled(array $context, string $rule_id): bool
    {
        return !class_exists(AIPKit_Content_Writer_SEO_Config::class)
            || AIPKit_Content_Writer_SEO_Config::is_rule_enabled($context, $rule_id);
    }

    private static function ensure_intro_keyphrase(string $content, string $focus_keyphrase, string $display_keyphrase): string
    {
        $content = trim($content);
        if ($content === '') {
            return '';
        }

        if (!preg_match('/<p\b/i', $content)) {
            $content = wpautop($content);
        }

        $paragraphs = self::get_paragraphs($content);
        if (empty($paragraphs)) {
            return '<p>' . esc_html(self::intro_sentence($display_keyphrase)) . '</p>' . "\n\n" . $content;
        }

        foreach ($paragraphs as $paragraph) {
            if (self::word_count((string) $paragraph['html']) < 5) {
                continue;
            }

            if (self::contains_phrase((string) $paragraph['html'], $focus_keyphrase)) {
                return $content;
            }

            $replacement = preg_replace(
                '/(<p\b[^>]*>)/i',
                '$1' . esc_html(self::intro_sentence($display_keyphrase)) . ' ',
                (string) $paragraph['full'],
                1
            );
            if (!is_string($replacement) || $replacement === '') {
                return $content;
            }

            return substr_replace($content, $replacement, (int) $paragraph['offset'], strlen((string) $paragraph['full']));
        }

        return $content;
    }

    private static function ensure_subheading_keyphrase(string $content, string $focus_keyphrase, string $display_keyphrase): string
    {
        $headings = self::get_headings($content);
        $heading_count = count($headings);
        if ($heading_count === 0) {
            return $content;
        }

        $matches = 0;
        foreach ($headings as $heading) {
            if (self::contains_phrase((string) $heading['inner'], $focus_keyphrase)) {
                $matches++;
            }
        }

        $required = self::required_yoast_subheading_matches($heading_count);
        if ($matches >= $required) {
            return $content;
        }

        $needed = $required - $matches;
        $replacements = [];
        foreach ($headings as $heading) {
            if ($needed <= 0) {
                break;
            }

            if (self::contains_phrase((string) $heading['inner'], $focus_keyphrase)) {
                continue;
            }

            $plain = trim(wp_strip_all_tags((string) $heading['inner']));
            if ($plain === '' || self::is_utility_heading($plain)) {
                continue;
            }

            $new_heading = self::heading_with_keyphrase($plain, $display_keyphrase);
            $level = absint($heading['level'] ?? 2);
            $replacements[(int) $heading['offset']] = [
                'length' => strlen((string) $heading['full']),
                'html' => '<h' . $level . '>' . esc_html($new_heading) . '</h' . $level . '>',
            ];
            $needed--;
        }

        return self::apply_replacements($content, $replacements);
    }

    private static function ensure_minimum_density(string $content, string $focus_keyphrase, string $display_keyphrase): string
    {
        $words = max(1, self::word_count($content));
        $minimum = max(2, (int) floor($words * 0.005));
        $occurrences = self::count_phrase_occurrences($content, $focus_keyphrase);
        if ($occurrences >= $minimum) {
            return $content;
        }

        $needed = $minimum - $occurrences;
        return preg_replace_callback('/<p\b([^>]*)>(.*?)<\/p>/is', static function (array $match) use (&$needed, $focus_keyphrase, $display_keyphrase): string {
            if ($needed <= 0) {
                return (string) $match[0];
            }

            $inner = (string) ($match[2] ?? '');
            if (self::contains_phrase($inner, $focus_keyphrase) || self::word_count($inner) < 8) {
                return (string) $match[0];
            }

            $needed--;
            $sentence = sprintf('For another helpful perspective, this %s highlights practical trade-offs for buyers.', $display_keyphrase);
            return '<p' . (string) ($match[1] ?? '') . '>' . esc_html($sentence) . ' ' . $inner . '</p>';
        }, $content) ?: $content;
    }

    private static function ensure_meta_description(string $meta_description, string $focus_keyphrase, string $display_keyphrase, bool $include_keyphrase): string
    {
        $meta_description = trim((string) preg_replace('/\s+/u', ' ', wp_strip_all_tags($meta_description)));
        if (!$include_keyphrase) {
            return self::ensure_meta_length($meta_description);
        }

        if (
            $meta_description !== ''
            && self::contains_phrase($meta_description, $focus_keyphrase)
            && self::text_length($meta_description) >= 120
            && self::text_length($meta_description) <= 156
        ) {
            return $meta_description;
        }

        $description = sprintf(
            'Use this %s to compare options, understand key features, and choose the best value for your needs and budget.',
            $display_keyphrase
        );
        if (self::text_length($description) < 120) {
            $description .= ' Make a confident choice before buying.';
        }

        return self::trim_to_length($description, 156);
    }

    private static function ensure_meta_length(string $meta_description): string
    {
        if ($meta_description === '') {
            return '';
        }

        $length = self::text_length($meta_description);
        if ($length >= 120 && $length <= 156) {
            return $meta_description;
        }

        if ($length > 156) {
            return self::trim_to_length($meta_description, 156);
        }

        $description = $meta_description . ' Compare options, key features, and practical trade-offs before choosing.';
        return self::trim_to_length($description, 156);
    }

    private static function intro_sentence(string $display_keyphrase): string
    {
        return sprintf(
            'This %s explains the key choices, value factors, and practical details readers need before making a decision.',
            $display_keyphrase
        );
    }

    private static function heading_with_keyphrase(string $heading, string $display_keyphrase): string
    {
        if (self::contains_phrase($heading, $display_keyphrase)) {
            return $heading;
        }

        return $display_keyphrase . ': ' . $heading;
    }

    private static function required_yoast_subheading_matches(int $heading_count): int
    {
        if ($heading_count <= 2) {
            return 1;
        }

        if ($heading_count <= 5) {
            return 2;
        }

        return 3;
    }

    private static function display_keyphrase(string $focus_keyphrase, string $title): string
    {
        $focus_words = self::words($focus_keyphrase);
        if (!empty($focus_words) && $title !== '') {
            $title_words = self::words($title);
            $candidate = implode(' ', array_slice($title_words, 0, count($focus_words)));
            if (self::normalized_text($candidate) === self::normalized_text($focus_keyphrase)) {
                return $candidate;
            }
        }

        $phrase = trim(preg_replace('/\s+/u', ' ', $focus_keyphrase));
        if ($phrase === '') {
            return '';
        }

        return preg_replace_callback('/\b[\p{L}\p{N}][\p{L}\p{N}\'’-]*/u', static function (array $match): string {
            $word = (string) ($match[0] ?? '');
            if (function_exists('mb_strtolower') && function_exists('mb_convert_case')) {
                $lower = mb_strtolower($word, 'UTF-8');
                return mb_convert_case($lower, MB_CASE_TITLE, 'UTF-8');
            }

            return ucfirst(strtolower($word));
        }, $phrase) ?: $phrase;
    }

    private static function get_paragraphs(string $content): array
    {
        if (!preg_match_all('/<p\b[^>]*>.*?<\/p>/is', $content, $matches, PREG_OFFSET_CAPTURE)) {
            return [];
        }

        $paragraphs = [];
        foreach ($matches[0] as $match) {
            $paragraphs[] = [
                'full' => (string) ($match[0] ?? ''),
                'html' => (string) ($match[0] ?? ''),
                'offset' => (int) ($match[1] ?? 0),
            ];
        }

        return $paragraphs;
    }

    private static function get_headings(string $content): array
    {
        if (!preg_match_all('/<h([23])\b[^>]*>(.*?)<\/h[23]>/is', $content, $matches, PREG_OFFSET_CAPTURE | PREG_SET_ORDER)) {
            return [];
        }

        $headings = [];
        foreach ($matches as $match) {
            $headings[] = [
                'full' => (string) ($match[0][0] ?? ''),
                'level' => absint($match[1][0] ?? 2),
                'inner' => (string) ($match[2][0] ?? ''),
                'offset' => (int) ($match[0][1] ?? 0),
            ];
        }

        return $headings;
    }

    private static function apply_replacements(string $content, array $replacements): string
    {
        if (empty($replacements)) {
            return $content;
        }

        krsort($replacements);
        foreach ($replacements as $offset => $replacement) {
            $content = substr_replace($content, (string) $replacement['html'], (int) $offset, (int) $replacement['length']);
        }

        return $content;
    }

    private static function is_utility_heading(string $heading): bool
    {
        return (bool) preg_match('/^(?:contents?|table of contents|final thoughts?|conclusion|faq|faqs|key takeaways?)\s*:?\s*$/i', trim($heading));
    }

    private static function contains_phrase(string $html, string $phrase): bool
    {
        $text = self::normalized_text(wp_strip_all_tags($html));
        $phrase = self::normalized_text($phrase);
        return $text !== '' && $phrase !== '' && strpos($text, $phrase) !== false;
    }

    private static function count_phrase_occurrences(string $html, string $phrase): int
    {
        $text = self::normalized_text(wp_strip_all_tags($html));
        $phrase = self::normalized_text($phrase);
        if ($text === '' || $phrase === '') {
            return 0;
        }

        $pattern = '/(?<![\p{L}\p{N}])' . preg_quote($phrase, '/') . '(?![\p{L}\p{N}])/u';
        $match_count = preg_match_all($pattern, $text, $matches);
        return $match_count !== false ? count($matches[0]) : substr_count($text, $phrase);
    }

    private static function word_count(string $html): int
    {
        $text = trim(wp_strip_all_tags($html));
        if ($text === '') {
            return 0;
        }

        if (preg_match_all('/[\p{L}\p{N}][\p{L}\p{N}\'’-]*/u', $text, $matches)) {
            return count($matches[0]);
        }

        return str_word_count($text);
    }

    private static function text_length(string $text): int
    {
        $text = trim(wp_strip_all_tags($text));
        return function_exists('mb_strlen') ? mb_strlen($text, 'UTF-8') : strlen($text);
    }

    private static function trim_to_length(string $text, int $max_length): string
    {
        $text = trim((string) preg_replace('/\s+/u', ' ', wp_strip_all_tags($text)));
        if (self::text_length($text) <= $max_length) {
            return $text;
        }

        $cut = function_exists('mb_substr') ? mb_substr($text, 0, $max_length, 'UTF-8') : (string) substr($text, 0, $max_length);
        $space_position = function_exists('mb_strrpos') ? mb_strrpos($cut, ' ', 0, 'UTF-8') : strrpos($cut, ' ');
        if ($space_position !== false && $space_position >= 90) {
            $cut = function_exists('mb_substr') ? mb_substr($cut, 0, (int) $space_position, 'UTF-8') : (string) substr($cut, 0, (int) $space_position);
        }

        return rtrim(trim((string) $cut), " \t\n\r\0\x0B,;:-");
    }

    private static function words(string $text): array
    {
        if (!preg_match_all('/[\p{L}\p{N}][\p{L}\p{N}\'’-]*/u', wp_strip_all_tags($text), $matches)) {
            return [];
        }

        return array_values($matches[0]);
    }

    private static function normalized_text(string $text): string
    {
        $text = html_entity_decode(wp_strip_all_tags($text), ENT_QUOTES | ENT_HTML5, get_bloginfo('charset') ?: 'UTF-8');
        $text = function_exists('remove_accents') ? remove_accents($text) : $text;
        $text = function_exists('mb_strtolower') ? mb_strtolower($text, 'UTF-8') : strtolower($text);
        $text = preg_replace('/[^\p{L}\p{N}\s-]+/u', ' ', (string) $text);
        return preg_replace('/[\s_-]+/u', ' ', trim((string) $text));
    }
}
