<?php

namespace FluentCartPro\App\Modules\PaymentMethods\MollieGateway\API;

use FluentCart\Framework\Support\Arr;
use FluentCart\Api\CurrencySettings;
use FluentCartPro\App\Modules\PaymentMethods\MollieGateway\MollieHelper;
use FluentCartPro\App\Modules\PaymentMethods\MollieGateway\MollieSettingsBase;

class MollieAPI
{
    private $apiUrl = 'https://api.mollie.com/v2/';

    public function makeRequest($path, $data = [], $apiKey = null, $method = 'GET')
    {
        if (!$apiKey) {
            $apiKey = $this->getApiKey();
        }

        return $this->remoteRequest($path, $data, $apiKey, $method);
    }

    public function getMollieObject($path, $data = [], $mode = 'current')
    {
        $apiKey = (new MollieSettingsBase())->getApiKey($mode);

        return $this->remoteRequest($path, $data, $apiKey, 'GET');
    }

    public function createMollieObject($path, $data = [], $mode = 'current', $headers = [])
    {
        $apiKey = (new MollieSettingsBase())->getApiKey($mode);
        return $this->remoteRequest($path, $data, $apiKey, 'POST', $headers);
    }

    public function deleteMollieObject($path, $data = [], $mode = 'current')
    {
        $apiKey = (new MollieSettingsBase())->getApiKey($mode);
        return $this->remoteRequest($path, $data, $apiKey, 'DELETE');
    }

    public function remoteRequest($path, $data, $apiKey, $method, $extraHeaders = [])
    {
        $headers = array_merge(
            array(
                'Authorization' => 'Bearer ' . $apiKey,
                'Content-Type'  => 'application/json'
            ),
            $extraHeaders
        );

        // Mollie's own pagination links (_links.next.href) are already-absolute URLs;
        // passing one through here must not get the base URL prefixed onto it again.
        // But an absolute URL also carries our Authorization: Bearer header, so it must
        // be pinned to Mollie's own API host/scheme/path before we follow it — never
        // trust an arbitrary absolute URL with the API key.
        $isAbsolute = strpos($path, 'http://') === 0 || strpos($path, 'https://') === 0;

        if ($isAbsolute) {
            $target = wp_parse_url($path);
            $allowedHost = wp_parse_url($this->apiUrl, PHP_URL_HOST);

            if (
                empty($target['scheme']) || $target['scheme'] !== 'https'
                || empty($target['host']) || $target['host'] !== $allowedHost
                || empty($target['path']) || strpos($target['path'], '/v2/') !== 0
            ) {
                return new \WP_Error('invalid_mollie_url', __('Refused to follow an untrusted Mollie API URL.', 'fluent-cart-pro'));
            }

            $url = $path;
        } else {
            $url = $this->apiUrl . $path;
        }

        if ($method === 'GET') {
            if (!empty($data) && is_array($data)) {
                $url .= '?' . http_build_query($data);
            }
       
            $requestData = array(
                'headers' => $headers,
                'method'  => $method,
                'timeout' => 30
            );
        } else if ($method === 'DELETE') {
            $requestData = array(
                'headers' => $headers,
                'method'  => $method,
                'timeout' => 30
            );
        }else {
            $requestData = array(
                'headers' => $headers,
                'body'    => is_array($data) ? json_encode( $data) : $data,
                'method'  => $method,
                'timeout' => 30
            );
        }

        $response = wp_remote_request($url, $requestData);

        if (is_wp_error($response)) {
            return $response;
        }

        $responseBody = wp_remote_retrieve_body($response);
        $responseArray = json_decode($responseBody, true);

        $statusCode = wp_remote_retrieve_response_code($response);

        if ($statusCode >= 300) {
            $message = Arr::get($responseArray, 'detail');
            if (!$message) {
                $message = Arr::get($responseArray, 'title');
            }
            if (!$message) {
                $message = __('Unknown Mollie API request error', 'fluent-cart-pro');
            }

            return new \WP_Error('api_error', $message, $responseArray);
        }

        return $responseArray;
    }

    public function verifyIPN()
    {

        $post_data = file_get_contents('php://input');

        $data = json_decode($post_data);

        if (empty($data) && !empty($_POST)) {
            $postArray = stripslashes_deep($_POST);
            $data = json_decode(wp_json_encode($postArray));
        }

        if ($data && isset($data->id)) {
            return $data;
        }

        parse_str($post_data, $parsed);
        if (isset($parsed['id']) && $parsed['id']) {
            // Return as object for consistency
            return (object)[
                'id' => $parsed['id']
            ];
        }

        return new \WP_Error('invalid_data', __('Invalid data received from Mollie', 'fluent-cart-pro'));
    }

    public function getApiKey($mode = 'current')
    {
        return (new MollieSettingsBase())->getApiKey($mode);
    }

    // Mollie subscriptions are managed via the customers/{id}/subscriptions endpoints

    public static function testConnection($apiKey)
    {
        $response = wp_remote_get('https://api.mollie.com/v2/methods', [
            'headers' => [
                'Authorization' => 'Bearer ' . $apiKey
            ],
            'timeout' => 30
        ]);

        if (is_wp_error($response)) {
            throw new \Exception($response->get_error_message());
        }

        $statusCode = wp_remote_retrieve_response_code($response);
        
        if ($statusCode !== 200) {
            $body = wp_remote_retrieve_body($response);
            $data = json_decode($body, true);
            $error = Arr::get($data, 'detail', __('Invalid API credentials', 'fluent-cart-pro'));
            throw new \Exception($error);
        }

        return true;
    }

    /**
     * @param string $mode  test|live
     * @param array  $args  amount: payable-now total in cents, sequence_type: oneoff|first
     */
    public function getActivatedPaymentMethodsConfigs($mode = 'live', $args = [])
    {
        $apiKey = (new MollieSettingsBase())->getApiKey($mode);
        if (!$apiKey) {
            return [];
        }

        $methodArgs = [];

        // Mollie filters by the method's min/max amount, so the lookup must carry the
        // amount the payment will actually be created with — otherwise the customer is
        // shown methods that reject their cart (or is missing ones that accept it).
        // The amount also selects the currency: with no amount Mollie answers with the
        // Euro methods only, so it is always sent, at the smallest unit when the caller
        // has no total to offer (settings screen, free trial).
        $amount = max(1, (int) Arr::get($args, 'amount', 0));
        $currency = strtoupper((string) CurrencySettings::get('currency'));

        if ($currency) {
            $methodArgs['amount'] = [
                'currency' => $currency,
                'value'    => MollieHelper::formatAmountForMollie($amount, $currency)
            ];
        }

        $sequenceType = Arr::get($args, 'sequence_type');

        if ($sequenceType) {
            $methodArgs['sequenceType'] = $sequenceType;
        }

        $response = $this->makeRequest('methods', $methodArgs, $apiKey);
        if (is_wp_error($response)) {
            return [];
        }

        $methods = isset($response['_embedded']['methods']) && is_array($response['_embedded']['methods'])
            ? $response['_embedded']['methods']
            : [];

        if (empty($methods)) {
            return [];
        }

        $activatedMethods = array_values(array_filter($methods, function ($method) {
            return Arr::get($method, 'status') == 'activated';
        }));

        $activatedMethods = array_map(function ($method) {
            return [
                'name'  => Arr::get($method, 'description'),
                'image' => Arr::get($method, 'image.svg')
            ];
        }, $activatedMethods);

        return [
            'activated_methods' => $activatedMethods,
            'configure_url'     => 'https://www.mollie.com/dashboard/settings/payment-methods'
        ];
    }
}
