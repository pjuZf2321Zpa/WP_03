<?php

namespace MasterStudy\Lms\Pro\addons\assignments\Routing\Swagger;

use MasterStudy\Lms\Routing\Swagger\RequestInterface;
use MasterStudy\Lms\Routing\Swagger\ResponseInterface;
use MasterStudy\Lms\Routing\Swagger\Route;

class BulkDeleteAdminStudentAssignments extends Route implements RequestInterface, ResponseInterface {
	public function request(): array {
		return array(
			'student_assignments' => array(
				'type'        => 'array',
				'description' => 'Student assignment items selected for bulk deletion.',
				'required'    => true,
				'items'       => array(
					'type'       => 'object',
					'properties' => array(
						'id' => array(
							'type' => 'integer',
						),
					),
				),
			),
		);
	}

	public function response(): array {
		return array(
			'success' => array(
				'type' => 'boolean',
			),
		);
	}

	public function get_summary(): string {
		return 'Bulk Delete Admin Student Assignments';
	}

	public function get_description(): string {
		return 'Permanently deletes student assignment attempts from the admin student assignments list.';
	}
}
