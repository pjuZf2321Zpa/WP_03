<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Actions\ACPT\ACPTProHelper;
use BitApps\IntegrationsPro\Config;
use BitApps\IntegrationsPro\Core\Util\Hooks;

// Deprecated since v2.7.8 - use bit_integrations_acpt_* hooks instead
if (bit_integrations_version_below('2.7.8')) {
    Hooks::filter('btcbi_acpt_update_cpt', [ACPTProHelper::class, 'update'], 10, 4);
    Hooks::filter('btcbi_acpt_delete_cpt', [ACPTProHelper::class, 'delete'], 10, 3);
    Hooks::filter('btcbi_acpt_create_taxonomy', [ACPTProHelper::class, 'createTaxonomyOrOptionPage'], 10, 4);
    Hooks::filter('btcbi_acpt_update_taxonomy', [ACPTProHelper::class, 'update'], 10, 4);
    Hooks::filter('btcbi_acpt_delete_taxonomy', [ACPTProHelper::class, 'delete'], 10, 3);
    Hooks::filter('btcbi_acpt_associate_taxonomy_to_cpt', [ACPTProHelper::class, 'associateTaxonomyToCPT'], 10, 3);
    Hooks::filter('btcbi_acpt_create_option_page', [ACPTProHelper::class, 'createTaxonomyOrOptionPage'], 10, 4);
    Hooks::filter('btcbi_acpt_update_option_page', [ACPTProHelper::class, 'update'], 10, 4);
    Hooks::filter('btcbi_acpt_delete_option_page', [ACPTProHelper::class, 'delete'], 10, 3);
    Hooks::filter('btcbi_acpt_delete_meta_group', [ACPTProHelper::class, 'delete'], 10, 3);
    Hooks::filter('btcbi_acpt_delete_dynamic_block', [ACPTProHelper::class, 'delete'], 10, 3);
}

// New hooks since v2.7.8
Hooks::filter(Config::withFreePrefix('acpt_update_cpt'), [ACPTProHelper::class, 'update'], 10, 4);
Hooks::filter(Config::withFreePrefix('acpt_delete_cpt'), [ACPTProHelper::class, 'delete'], 10, 3);
Hooks::filter(Config::withFreePrefix('acpt_create_taxonomy'), [ACPTProHelper::class, 'createTaxonomyOrOptionPage'], 10, 4);
Hooks::filter(Config::withFreePrefix('acpt_update_taxonomy'), [ACPTProHelper::class, 'update'], 10, 4);
Hooks::filter(Config::withFreePrefix('acpt_delete_taxonomy'), [ACPTProHelper::class, 'delete'], 10, 3);
Hooks::filter(Config::withFreePrefix('acpt_associate_taxonomy_to_cpt'), [ACPTProHelper::class, 'associateTaxonomyToCPT'], 10, 3);
Hooks::filter(Config::withFreePrefix('acpt_create_option_page'), [ACPTProHelper::class, 'createTaxonomyOrOptionPage'], 10, 4);
Hooks::filter(Config::withFreePrefix('acpt_update_option_page'), [ACPTProHelper::class, 'update'], 10, 4);
Hooks::filter(Config::withFreePrefix('acpt_delete_option_page'), [ACPTProHelper::class, 'delete'], 10, 3);
Hooks::filter(Config::withFreePrefix('acpt_delete_meta_group'), [ACPTProHelper::class, 'delete'], 10, 3);
Hooks::filter(Config::withFreePrefix('acpt_delete_dynamic_block'), [ACPTProHelper::class, 'delete'], 10, 3);
