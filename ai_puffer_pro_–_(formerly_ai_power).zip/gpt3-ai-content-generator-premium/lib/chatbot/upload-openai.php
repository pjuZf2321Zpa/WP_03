<?php


namespace WPAICG\Lib\Chat\Frontend\Ajax\Handlers;

use WPAICG\Lib\Chat\Frontend\Ajax\Utils\ChatUploadLogger;
use WPAICG\Lib\Chat\Frontend\Ajax\Utils\ChatUploadConfigLoader;
use WPAICG\Vector\AIPKit_Vector_Provider_Strategy_Factory;
use WPAICG\Utils\AIPKit_Identifier_Utils;
use WP_Error;

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

/**
 * ChatFileUploadOpenAIHandler
 *
 * Handles the OpenAI-specific logic for file uploads in chat.
 */
class ChatFileUploadOpenAIHandler
{
    private $logger;
    private $vector_store_manager;
    private $providers_helper;

    public function __construct(ChatUploadConfigLoader $config_loader, ChatUploadLogger $logger)
    {
        $this->logger = $logger;
        $this->vector_store_manager = $config_loader->get_vector_store_manager();
        $this->providers_helper = $config_loader->get_providers_helper();
    }

    /**
     * Gets OpenAI API configuration.
     *
     * @return array|WP_Error
     */
    public function get_provider_api_config()
    {
        $openai_data = $this->providers_helper::get_provider_data('OpenAI');
        if (empty($openai_data['api_key'])) {
            return new WP_Error('missing_openai_key', __('OpenAI API Key is not configured.', 'gpt3-ai-content-generator'), ['status' => 500]);
        }
        return [
            'api_key'     => $openai_data['api_key'],
            // phpcs:ignore PluginCheck.CodeAnalysis.AIProvider.DirectIntegration -- Provider-specific file transport.
            'base_url'    => $openai_data['base_url'] ?? 'https://api.openai.com',
            'api_version' => $openai_data['api_version'] ?? 'v1',
        ];
    }

    /**
     * Processes the file upload for OpenAI.
     *
     * @param array $file_data The $_FILES entry for the uploaded file.
     * @param int|null $user_id Current user ID (null for guests).
     * @param string|null $session_id Guest session ID.
     * @param array $openai_config OpenAI API connection config.
     * @return array|WP_Error Success data or WP_Error.
     */
    public function process_upload(array $file_data, ?int $user_id, ?string $session_id, array $openai_config)
    {
        if (!$this->vector_store_manager) {
            return new WP_Error('internal_error_openai_vs_manager', __('Vector store processing service not available for OpenAI.', 'gpt3-ai-content-generator'), ['status' => 500]);
        }

        $strategy = AIPKit_Vector_Provider_Strategy_Factory::get_strategy('OpenAI');
        if (is_wp_error($strategy) || !method_exists($strategy, 'upload_file_for_vector_store')) {
            return new WP_Error('strategy_error_openai', __('OpenAI file processing strategy not available.', 'gpt3-ai-content-generator'), ['status' => 500]);
        }
        $connect_result = $strategy->connect($openai_config);
        if (is_wp_error($connect_result) || $connect_result === false) {
            return new WP_Error('strategy_connect_error_openai', __('Could not connect to OpenAI for file upload.', 'gpt3-ai-content-generator'), ['status' => 500]);
        }

        // Upload the file to OpenAI first
        $upload_result = $strategy->upload_file_for_vector_store($file_data['tmp_name'], $file_data['name'], 'assistants');
        if (is_wp_error($upload_result) || !isset($upload_result['id'])) {
            $err_msg = is_wp_error($upload_result) ? $upload_result->get_error_message() : 'Missing file ID in OpenAI upload response.';
            return new WP_Error('openai_file_upload_failed', 'Failed to upload file to OpenAI: ' . $err_msg, ['status' => 500]);
        }
        $openai_file_id = $upload_result['id'];

        // Create a new, temporary vector store for this file and user/session
        $vector_store_name = AIPKit_Identifier_Utils::generate_chat_context_identifier($user_id, $session_id, 'chat_file_vs');
        $openai_provider_settings = $this->providers_helper::get_provider_data('OpenAI');
        $expiration_days = $openai_provider_settings['expiration_policy'] ?? 7;
        $index_config = [
            'file_ids' => [$openai_file_id],
            'metadata' => [
                'aipkit_source' => 'chat_file_upload',
                'aipkit_original_filename' => sanitize_file_name($file_data['name']),
            ],
            'expires_after' => ['anchor' => 'last_active_at', 'days' => absint($expiration_days)]
        ];

        $create_store_result = $this->vector_store_manager->create_index_if_not_exists('OpenAI', $vector_store_name, $index_config, $openai_config);
        if (is_wp_error($create_store_result) || !isset($create_store_result['id'])) {
            $err_msg = is_wp_error($create_store_result) ? $create_store_result->get_error_message() : 'Failed to create vector store with file.';
            // Attempt to delete the orphaned OpenAI file if store creation fails
            if (method_exists($strategy, 'delete_openai_file_object')) {
                $strategy->delete_openai_file_object($openai_file_id);
            }
            return new WP_Error('openai_vs_creation_failed', 'OpenAI Vector Store creation error: ' . $err_msg, ['status' => 500]);
        }
        $new_vector_store_id = $create_store_result['id'];

        $file_context = $this->get_ready_file_context($new_vector_store_id, sanitize_file_name($file_data['name']), $openai_config);
        if (is_wp_error($file_context)) {
            return $file_context;
        }

        if ($file_context === null) {
            return [
                'status' => 'processing',
                'job_id' => $this->encode_job_id(
                    $new_vector_store_id,
                    sanitize_file_name($file_data['name']),
                    $openai_file_id,
                    $vector_store_name
                ),
                'retry_after' => 2,
                'message' => __('Indexing uploaded file for OpenAI chat...', 'gpt3-ai-content-generator'),
            ];
        }

        $this->logger->log_event([
            'provider' => 'OpenAI',
            'vector_store_id' => $new_vector_store_id,
            'vector_store_name' => $vector_store_name,
            'status' => 'success',
            'message' => 'File uploaded and new Vector Store created for chat context. File ID: ' . $openai_file_id,
            'file_id' => $openai_file_id,
            'post_title' => sanitize_file_name($file_data['name']),
            'source_type_for_log' => 'chat_file_upload' // Specific type for this action
        ]);

        return [
            'message' => __('File processed for OpenAI chat.', 'gpt3-ai-content-generator'),
            'file_context' => $file_context
        ];
    }

    /**
     * @return mixed[]|\WP_Error
     */
    public function continue_upload_job(string $job_id, array $openai_config)
    {
        $job = $this->decode_job_id($job_id);
        if ($job === null) {
            return new WP_Error('invalid_openai_upload_job', __('Invalid OpenAI file indexing job.', 'gpt3-ai-content-generator'), ['status' => 400]);
        }

        $vector_store_id = $job['vector_store_id'];
        $original_filename = $job['original_filename'];
        $openai_file_id = $job['file_id'];
        $vector_store_name = $job['vector_store_name'];
        if (!empty($job['created_at']) && (time() - (int)$job['created_at']) > 300) {
            return new WP_Error('openai_file_indexing_timeout', __('OpenAI is still indexing the uploaded file. Please try uploading it again.', 'gpt3-ai-content-generator'), ['status' => 504]);
        }

        $file_context = $this->get_ready_file_context($vector_store_id, $original_filename, $openai_config);
        if (is_wp_error($file_context)) {
            return $file_context;
        }

        if ($file_context === null) {
            return [
                'status' => 'processing',
                'job_id' => $job_id,
                'retry_after' => 2,
                'message' => __('Indexing uploaded file for OpenAI chat...', 'gpt3-ai-content-generator'),
            ];
        }

        $this->logger->log_event([
            'provider' => 'OpenAI',
            'vector_store_id' => $vector_store_id,
            'vector_store_name' => $vector_store_name ?: $vector_store_id,
            'status' => 'success',
            'message' => 'File uploaded and indexed for OpenAI chat. Original filename: ' . $original_filename,
            'file_id' => $openai_file_id ?: null,
            'post_title' => $original_filename,
            'source_type_for_log' => 'chat_file_upload'
        ]);

        return [
            'message' => __('File processed for OpenAI chat.', 'gpt3-ai-content-generator'),
            'file_context' => $file_context
        ];
    }

    /**
     * @return mixed[]|\WP_Error|null
     */
    private function get_ready_file_context(string $vector_store_id, string $original_filename, array $openai_config)
    {
        if (!$this->vector_store_manager) {
            return new WP_Error('internal_error_openai_vs_manager', __('Vector store processing service not available for OpenAI.', 'gpt3-ai-content-generator'), ['status' => 500]);
        }

        $store = $this->vector_store_manager->describe_single_index('OpenAI', $vector_store_id, $openai_config);
        if (is_wp_error($store)) {
            return $store;
        }

        $file_counts = is_array($store['file_counts'] ?? null) ? $store['file_counts'] : [];
        $total = (int)($file_counts['total'] ?? 0);
        $completed = (int)($file_counts['completed'] ?? 0);
        $in_progress = (int)($file_counts['in_progress'] ?? 0);
        $failed = (int)($file_counts['failed'] ?? 0);
        $cancelled = (int)($file_counts['cancelled'] ?? 0);

        if ($failed > 0 || $cancelled > 0) {
            return new WP_Error('openai_file_indexing_failed', __('OpenAI could not index the uploaded file. Please try another file.', 'gpt3-ai-content-generator'), ['status' => 500]);
        }

        $store_status = sanitize_key((string)($store['status'] ?? ''));
        $is_ready = $total > 0 && $in_progress === 0 && ($completed >= $total || $store_status === 'completed');
        if (!$is_ready) {
            return null;
        }

        return [
            'provider' => 'OpenAI',
            'vector_store_id' => $vector_store_id,
            'original_filename' => $original_filename,
        ];
    }

    private function encode_job_id(string $vector_store_id, string $original_filename, string $file_id, string $vector_store_name): string
    {
        $payload = wp_json_encode([
            'vector_store_id' => $vector_store_id,
            'vector_store_name' => $vector_store_name,
            'file_id' => $file_id,
            'original_filename' => $original_filename,
            'created_at' => time(),
        ]);
        return rtrim(strtr(base64_encode((string)$payload), '+/', '-_'), '=');
    }

    private function decode_job_id(string $job_id): ?array
    {
        $encoded = strtr($job_id, '-_', '+/');
        $padding = strlen($encoded) % 4;
        if ($padding > 0) {
            $encoded .= str_repeat('=', 4 - $padding);
        }

        $decoded = base64_decode($encoded, true);
        if ($decoded === false) {
            return null;
        }

        $payload = json_decode($decoded, true);
        if (!is_array($payload) || empty($payload['vector_store_id'])) {
            return null;
        }

        return [
            'vector_store_id' => sanitize_text_field((string)$payload['vector_store_id']),
            'vector_store_name' => sanitize_text_field((string)($payload['vector_store_name'] ?? '')),
            'file_id' => sanitize_text_field((string)($payload['file_id'] ?? '')),
            'original_filename' => sanitize_file_name((string)($payload['original_filename'] ?? '')),
            'created_at' => isset($payload['created_at']) ? absint($payload['created_at']) : 0,
        ];
    }
}
