<?php

declare(strict_types=1);

namespace FluentCartPro\App\Services\Invoice\Domain;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * VAT breakdown row (header-level). Used in CalculatedTotals.
 */
final class TaxSummary
{
    public Money $taxableAmount;

    public Money $taxAmount;

    public string $taxCategory;

    public string $taxPercent;

    /** BT-121: coded VAT exemption reason (e.g. VATEX-EU-AE). Empty when not applicable. */
    public string $exemptionReasonCode;

    /** BT-120: free-text VAT exemption reason. Empty when not applicable. */
    public string $exemptionReasonText;

    public function __construct(
        Money $taxableAmount,
        Money $taxAmount,
        string $taxCategory,
        string $taxPercent,
        string $exemptionReasonCode = '',
        string $exemptionReasonText = ''
    ) {
        $this->taxableAmount       = $taxableAmount;
        $this->taxAmount           = $taxAmount;
        $this->taxCategory         = $taxCategory;
        $this->taxPercent          = $taxPercent;
        $this->exemptionReasonCode = $exemptionReasonCode;
        $this->exemptionReasonText = $exemptionReasonText;
    }
}
