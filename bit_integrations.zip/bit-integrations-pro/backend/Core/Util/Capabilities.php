<?php

namespace BitApps\IntegrationsPro\Core\Util;

final class Capabilities
{
    public static function Check($cap, ...$args)
    {
        return current_user_can($cap, ...$args);
    }
}
