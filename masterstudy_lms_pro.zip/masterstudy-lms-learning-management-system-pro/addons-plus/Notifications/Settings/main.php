<?php

use MasterStudy\Lms\Pro\AddonsPlus\Notifications\Events;

function masterstudy_lms_notifications_settings_section( $fields ) {
	if (
		! function_exists( 'masterstudy_lms_is_notifications_addon_available' )
		|| ! masterstudy_lms_is_notifications_addon_available()
	) {
		return $fields;
	}

	$fields['section_notifications'] = array(
		'name'   => esc_html__( 'Notifications', 'masterstudy-lms-learning-management-system-pro' ),
		'label'  => esc_html__( 'Notifications Settings', 'masterstudy-lms-learning-management-system-pro' ),
		'icon'   => 'stmlms-bell',
		'fields' => array(
			Events::ACCOUNT_VIEW_KEY => array(
				'type'        => 'radio',
				'label'       => esc_html__( 'Desktop notifications view', 'masterstudy-lms-learning-management-system-pro' ),
				'description' => esc_html__( 'Choose how notifications open on desktop account pages.', 'masterstudy-lms-learning-management-system-pro' ),
				'options'     => array(
					Events::ACCOUNT_VIEW_POPUP  => esc_html__( 'Popup', 'masterstudy-lms-learning-management-system-pro' ),
					Events::ACCOUNT_VIEW_DRAWER => esc_html__( 'Drawer', 'masterstudy-lms-learning-management-system-pro' ),
				),
				'value'       => Events::ACCOUNT_VIEW_POPUP,
			),
			Events::SETTINGS_KEY => array(
				'type'               => 'masterstudy_notifications_triggers',
				'value'              => Events::default_settings(),
				'groups'             => Events::available_groups(),
				'all_groups'         => Events::groups(),
				'channel_labels'     => array(
					Events::CHANNEL_ON_SITE => esc_html__( 'On Site', 'masterstudy-lms-learning-management-system-pro' ),
					Events::CHANNEL_PUSH    => esc_html__( 'Push', 'masterstudy-lms-learning-management-system-pro' ),
				),
				'bulk_action_labels' => array(
					'enable_all'  => esc_html__( 'Enable all', 'masterstudy-lms-learning-management-system-pro' ),
					'disable_all' => esc_html__( 'Disable all', 'masterstudy-lms-learning-management-system-pro' ),
				),
			),
		),
	);

	return $fields;
}
add_filter( 'stm_lms_main_settings_fields', 'masterstudy_lms_notifications_settings_section' );

function masterstudy_lms_notifications_sanitize_settings( $settings, $id ) {
	if ( 'stm_lms_settings' !== $id || ! is_array( $settings ) ) {
		return $settings;
	}

	if ( array_key_exists( Events::ACCOUNT_VIEW_KEY, $settings ) ) {
		$settings[ Events::ACCOUNT_VIEW_KEY ] = Events::sanitize_account_view( $settings[ Events::ACCOUNT_VIEW_KEY ] );
	}

	if ( array_key_exists( Events::SETTINGS_KEY, $settings ) ) {
		$saved_settings = get_option( 'stm_lms_settings', array() );
		$saved_triggers = array();

		if (
			is_array( $saved_settings )
			&& isset( $saved_settings[ Events::SETTINGS_KEY ] )
			&& is_array( $saved_settings[ Events::SETTINGS_KEY ] )
		) {
			$saved_triggers = $saved_settings[ Events::SETTINGS_KEY ];
		}

		$new_triggers = is_array( $settings[ Events::SETTINGS_KEY ] )
			? $settings[ Events::SETTINGS_KEY ]
			: array();

		$settings[ Events::SETTINGS_KEY ] = array_replace_recursive( $saved_triggers, $new_triggers );
		$settings[ Events::SETTINGS_KEY ] = Events::sanitize_settings( $settings[ Events::SETTINGS_KEY ] );
	}

	return $settings;
}
add_filter( 'wpcfto_masterstudy_settings_before_update_option', 'masterstudy_lms_notifications_sanitize_settings', 10, 2 );

add_filter(
	'wpcfto_field_masterstudy_notifications_triggers',
	function () {
		return __DIR__ . '/Fields/notifications.php';
	}
);
