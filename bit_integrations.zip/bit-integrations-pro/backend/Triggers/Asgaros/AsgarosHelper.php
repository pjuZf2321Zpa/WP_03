<?php

namespace BitApps\IntegrationsPro\Triggers\Asgaros;

use AsgarosForum;

class AsgarosHelper
{
    public static function UserCreatesNewTopicInForumFormatFields($post_id, $topic_id, $author_id)
    {
        $helperClass = bit_integrations_get_class('Core\\Util\\Helper');

        if (! class_exists('AsgarosForum')) {
            return;
        }

        $forum = new AsgarosForum();

        if (! isset($post_id)) {
            return;
        }

        $data = static::setForumFields($forum, $topic_id, $post_id, $author_id);

        return $helperClass::prepareFetchFormatFields($data);
    }

    public static function UserRepliesToTopicInForumFormatFields($post_id, $topic_id, $author_id)
    {
        $helperClass = bit_integrations_get_class('Core\\Util\\Helper');

        if (! class_exists('AsgarosForum')) {
            return;
        }

        $forum = new AsgarosForum();

        if (! isset($post_id)) {
            return;
        }

        $data = static::setForumFields($forum, $topic_id, $post_id, $author_id);

        return $helperClass::prepareFetchFormatFields($data);
    }

    public static function isPluginInstalled()
    {
        return class_exists('AsgarosForum');
    }

    private static function setForumFields($forum, $topic_id, $post_id, $author_id)
    {
        $userClass = bit_integrations_get_class('Core\\Util\\User');

        $topic = $forum->content->get_topic($topic_id);
        $forum_id = $topic->parent_id;

        return [
            'topic_id' => $topic_id,
            'post_id'  => $post_id,
            'forum_id' => $forum_id,
            'forum'    => $forum->content->get_forum($forum_id),
            'topic'    => $forum->content->get_topic($topic_id),
            'post'     => $forum->content->get_post($post_id),
            'author'   => $userClass::get($author_id),
        ];
    }
}
