<?php

namespace FluentCartPro\App\Modules\AccountingExport;

use FluentCart\App\Modules\MultiCurrency\Services\BaseCurrency;
use FluentCart\App\Services\Permission\PermissionManager;
use FluentCart\App\Vite;

/**
 * Reports → Export: OSS / accounting-ready rows for this store
 * (fluent-cart dev-docs/multi-currency/11-accounting-export.md).
 */
class AccountingExport
{
    public function register($app): void
    {
        // Needs core with multi-currency; Pro can be updated before core
        if (!class_exists(BaseCurrency::class)) {
            return;
        }

        $app->router->group(function ($router) {
            require_once __DIR__ . '/Http/routes.php';
        });

        add_action('fluent_cart/loading_app', function () {
            Vite::enqueueScript('fluent_cart_accounting_export', 'accounting-export/accounting-export.js');
        });

        add_filter('fluent_cart/admin_app_data', function ($data) {
            if (!PermissionManager::hasPermission('reports/export')) {
                return $data;
            }

            $items = isset($data['addon_report_sidebar']) && is_array($data['addon_report_sidebar'])
                ? $data['addon_report_sidebar']
                : [];
            $items[] = [
                'route' => 'reports_export',
                'label' => __('Export', 'fluent-cart-pro'),
                'url'   => '/reports/export',
                'icon'  => 'Download',
            ];
            $data['addon_report_sidebar'] = $items;

            return $data;
        });
    }
}
