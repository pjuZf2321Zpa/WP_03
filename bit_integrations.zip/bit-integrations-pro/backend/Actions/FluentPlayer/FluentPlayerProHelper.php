<?php

namespace BitApps\IntegrationsPro\Actions\FluentPlayer;

use Exception;
use FluentPlayer\App\Models\EmailCollection;
use FluentPlayer\App\Models\Media;
use FluentPlayer\App\Services\EmailProviderService;
use FluentPlayer\App\Services\PresetService;
use FluentPlayer\App\Services\Progression\ProgressionService;
use FluentPlayerPro\App\Models\Playlist;
use FluentPlayerPro\App\Services\AnalyticsService;
use FluentPlayerPro\App\Services\TagService;

final class FluentPlayerProHelper
{
    public const MEDIA_POST_TYPE = 'fluent_player_media';

    public const PLAYLIST_POST_TYPE = 'fluent_playlist';

    public const MEDIA_TAG_TAXONOMY = 'flp_media_tag';

    /**
     * FluentPlayer's own analytics writer caps a visit at one day.
     */
    public const MAX_VISIT_DURATION = 86400;

    public static function createMedia($response, $fieldData, $utilities = null, $integrationDetails = null)
    {
        if (!self::isActive() || !class_exists('\FluentPlayer\App\Models\Media')) {
            return self::error(__('FluentPlayer is not installed or activated', 'bit-integrations-pro'));
        }

        $provider = self::conf($integrationDetails, 'provider');

        if (empty($fieldData['title']) || empty($fieldData['src']) || empty($provider)) {
            return self::error(__('Title, source URL and provider are required', 'bit-integrations-pro'));
        }

        $presetSlug = self::conf($integrationDetails, 'selectedPreset');
        if (empty($presetSlug)) {
            return self::error(__('Preset is required', 'bit-integrations-pro'));
        }

        $attachmentId = self::conf($integrationDetails, 'selectedAttachment');

        try {
            $media = new Media();
            $media->title = $fieldData['title'];
            $media->post_status = self::util($utilities, 'selected_post_status') ?: 'publish';
            $media->settings = self::filterEmptyValues([
                'src'           => $fieldData['src'],
                'provider'      => $provider,
                'preset_slug'   => $presetSlug,
                'viewType'      => self::util($utilities, 'selected_view_type') ?: null,
                'posterSrc'     => $fieldData['poster_src'] ?? null,
                'title'         => $fieldData['title'],
                'attachment_id' => !empty($attachmentId) ? absint($attachmentId) : null,
            ]);

            if (!$media->save()) {
                return self::error(__('Failed to create media', 'bit-integrations-pro'));
            }

            $mediaId = $media->id;
            self::applyTags($mediaId, self::conf($integrationDetails, 'selectedTags'));

            return self::success(__('Media created successfully', 'bit-integrations-pro'), ['media_id' => $mediaId]);
        } catch (Exception $e) {
            return self::error($e->getMessage());
        }
    }

    public static function updateMedia($response, $fieldData, $utilities = null, $integrationDetails = null)
    {
        if (!self::isActive() || !class_exists('\FluentPlayer\App\Models\Media')) {
            return self::error(__('FluentPlayer is not installed or activated', 'bit-integrations-pro'));
        }

        $mediaId = self::resolveMediaId($fieldData['media_id'] ?? null);
        if (!$mediaId) {
            return self::error(__('Media not found', 'bit-integrations-pro'));
        }

        try {
            // Use the model reader: it repairs legacy double-serialized settings that a
            // raw get_post_meta() would return as a string (pre-1.0.2 storage).
            $existing = Media::getMediaSettings($mediaId);
            $existing = \is_array($existing) ? $existing : [];
            $post = get_post($mediaId);

            $media = new Media();
            $media->id = $mediaId;
            $media->title = !empty($fieldData['title']) ? $fieldData['title'] : $post->post_title;
            $media->post_status = self::util($utilities, 'selected_post_status') ?: $post->post_status;
            $media->settings = array_merge($existing, self::filterEmptyValues([
                'src'         => $fieldData['src'] ?? null,
                'provider'    => self::conf($integrationDetails, 'provider') ?: null,
                'preset_slug' => self::conf($integrationDetails, 'selectedPreset') ?: null,
                'viewType'    => self::util($utilities, 'selected_view_type') ?: null,
                'posterSrc'   => $fieldData['poster_src'] ?? null,
            ]));

            $media->save();
            self::applyTags($mediaId, self::conf($integrationDetails, 'selectedTags'));

            return self::success(__('Media updated successfully', 'bit-integrations-pro'), ['media_id' => $mediaId]);
        } catch (Exception $e) {
            return self::error($e->getMessage());
        }
    }

    public static function trashMedia($response, $fieldData)
    {
        return self::mediaLifecycle($fieldData, 'deleteById', 'trash', 'trashed');
    }

    public static function restoreMedia($response, $fieldData)
    {
        return self::mediaLifecycle($fieldData, 'restoreById', 'restore', 'restored');
    }

    public static function deleteMedia($response, $fieldData)
    {
        return self::mediaLifecycle($fieldData, 'forceDeleteById', 'delete', 'deleted');
    }

    public static function changeMediaStatus($response, $fieldData, $integrationDetails = null)
    {
        $mediaId = self::resolveMediaId($fieldData['media_id'] ?? null);
        if (!$mediaId) {
            return self::error(__('Media not found', 'bit-integrations-pro'));
        }

        $status = self::conf($integrationDetails, 'postStatus');
        if (empty($status)) {
            return self::error(__('Status is required', 'bit-integrations-pro'));
        }

        $result = wp_update_post(['ID' => $mediaId, 'post_status' => $status], true);
        if (is_wp_error($result)) {
            return self::error($result->get_error_message());
        }

        return self::success(__('Media status updated successfully', 'bit-integrations-pro'), ['media_id' => $mediaId]);
    }

    public static function createTag($response, $fieldData)
    {
        if (empty($fieldData['tag'])) {
            return self::error(__('Tag name is required', 'bit-integrations-pro'));
        }

        if (!class_exists('\FluentPlayerPro\App\Services\TagService')) {
            return self::error(__('FluentPlayer Pro is required for this action', 'bit-integrations-pro'));
        }

        $result = TagService::createTag($fieldData['tag']);
        if (is_wp_error($result)) {
            return self::error($result->get_error_message());
        }

        return self::success(__('Tag created successfully', 'bit-integrations-pro'), ['tag' => $fieldData['tag']]);
    }

    public static function renameTag($response, $fieldData)
    {
        $oldName = ($fieldData['old_name'] ?? null);

        if (empty($oldName) || empty($fieldData['new_name'])) {
            return self::error(__('Both the current and new tag names are required', 'bit-integrations-pro'));
        }

        if (!class_exists('\FluentPlayerPro\App\Services\TagService')) {
            return self::error(__('FluentPlayer Pro is required for this action', 'bit-integrations-pro'));
        }

        $result = TagService::renameTag($oldName, $fieldData['new_name']);
        if (is_wp_error($result)) {
            return self::error($result->get_error_message());
        }

        return self::success(__('Tag renamed successfully', 'bit-integrations-pro'), ['new_name' => $fieldData['new_name']]);
    }

    public static function deleteTag($response, $fieldData)
    {
        $tag = ($fieldData['tag'] ?? null);

        if (empty($tag)) {
            return self::error(__('Tag is required', 'bit-integrations-pro'));
        }

        if (!class_exists('\FluentPlayerPro\App\Services\TagService')) {
            return self::error(__('FluentPlayer Pro is required for this action', 'bit-integrations-pro'));
        }

        $result = TagService::deleteTag($tag);
        if (is_wp_error($result)) {
            return self::error($result->get_error_message());
        }

        return self::success(__('Tag deleted successfully', 'bit-integrations-pro'), ['tag' => $tag]);
    }

    public static function setMediaTags($response, $fieldData, $integrationDetails = null)
    {
        return self::writeMediaTags($fieldData, $integrationDetails, 'set');
    }

    public static function addMediaTags($response, $fieldData, $integrationDetails = null)
    {
        return self::writeMediaTags($fieldData, $integrationDetails, 'add');
    }

    public static function removeMediaTags($response, $fieldData, $integrationDetails = null)
    {
        return self::writeMediaTags($fieldData, $integrationDetails, 'remove');
    }

    public static function createPlaylist($response, $fieldData, $integrationDetails = null)
    {
        if (!class_exists('\FluentPlayerPro\App\Models\Playlist')) {
            return self::error(__('FluentPlayer Pro is required for this action', 'bit-integrations-pro'));
        }

        if (empty($fieldData['title'])) {
            return self::error(__('Title is required', 'bit-integrations-pro'));
        }

        try {
            $playlist = new Playlist();
            $playlist->title = $fieldData['title'];
            $playlist->settings = self::playlistSettings($fieldData, $integrationDetails, []);

            if (!$playlist->save()) {
                return self::error(__('Failed to create playlist', 'bit-integrations-pro'));
            }

            return self::success(__('Playlist created successfully', 'bit-integrations-pro'), ['playlist_id' => $playlist->id]);
        } catch (Exception $e) {
            return self::error($e->getMessage());
        }
    }

    public static function updatePlaylist($response, $fieldData, $integrationDetails = null)
    {
        if (!class_exists('\FluentPlayerPro\App\Models\Playlist')) {
            return self::error(__('FluentPlayer Pro is required for this action', 'bit-integrations-pro'));
        }

        $playlistId = self::resolvePlaylistId($fieldData['playlist_id'] ?? null);
        if (!$playlistId) {
            return self::error(__('Playlist not found', 'bit-integrations-pro'));
        }

        try {
            $existing = get_post_meta($playlistId, 'settings', true);
            $existing = \is_array($existing) ? $existing : [];
            $post = get_post($playlistId);

            $playlist = new Playlist();
            $playlist->id = $playlistId;
            $playlist->title = !empty($fieldData['title']) ? $fieldData['title'] : $post->post_title;
            $playlist->settings = self::playlistSettings($fieldData, $integrationDetails, $existing);

            $playlist->save();

            return self::success(__('Playlist updated successfully', 'bit-integrations-pro'), ['playlist_id' => $playlistId]);
        } catch (Exception $e) {
            return self::error($e->getMessage());
        }
    }

    public static function trashPlaylist($response, $fieldData)
    {
        return self::playlistLifecycle($fieldData, 'deleteById', 'trash', 'trashed');
    }

    public static function restorePlaylist($response, $fieldData)
    {
        return self::playlistLifecycle($fieldData, 'restoreById', 'restore', 'restored');
    }

    public static function deletePlaylist($response, $fieldData)
    {
        return self::playlistLifecycle($fieldData, 'forceDeleteById', 'delete', 'deleted');
    }

    public static function changePlaylistStatus($response, $fieldData, $integrationDetails = null)
    {
        if (!class_exists('\FluentPlayerPro\App\Models\Playlist')) {
            return self::error(__('FluentPlayer Pro is required for this action', 'bit-integrations-pro'));
        }

        $playlistId = self::resolvePlaylistId($fieldData['playlist_id'] ?? null);
        if (!$playlistId) {
            return self::error(__('Playlist not found', 'bit-integrations-pro'));
        }

        $status = self::conf($integrationDetails, 'postStatus');
        if (empty($status)) {
            return self::error(__('Status is required', 'bit-integrations-pro'));
        }

        try {
            if (!Playlist::changeStatusById($playlistId, $status)) {
                return self::error(__('Failed to change playlist status', 'bit-integrations-pro'));
            }

            return self::success(__('Playlist status updated successfully', 'bit-integrations-pro'), ['playlist_id' => $playlistId]);
        } catch (Exception $e) {
            return self::error($e->getMessage());
        }
    }

    public static function addMediaToPlaylist($response, $fieldData)
    {
        return self::writePlaylistMedia($fieldData, true);
    }

    public static function removeMediaFromPlaylist($response, $fieldData)
    {
        return self::writePlaylistMedia($fieldData, false);
    }

    public static function createEmailSubmission($response, $fieldData, $integrationDetails = null)
    {
        if (!class_exists('\FluentPlayer\App\Models\EmailCollection')) {
            return self::error(__('FluentPlayer is not installed or activated', 'bit-integrations-pro'));
        }

        if (empty($fieldData['email']) || !is_email($fieldData['email'])) {
            return self::error(__('A valid email is required', 'bit-integrations-pro'));
        }

        $userId = self::conf($integrationDetails, 'selectedUser');

        $data = self::filterEmptyValues([
            'email'       => $fieldData['email'],
            'media_id'    => self::resolveMediaId(self::conf($integrationDetails, 'selectedMedia')),
            'preset_slug' => self::conf($integrationDetails, 'selectedPreset') ?: null,
            'layer_id'    => !empty($fieldData['layer_id']) ? absint($fieldData['layer_id']) : null,
            'video_time'  => isset($fieldData['video_time']) && $fieldData['video_time'] !== '' ? (float) $fieldData['video_time'] : null,
            'ip_address'  => $fieldData['ip_address'] ?? null,
            'browser'     => $fieldData['browser'] ?? null,
            'device'      => $fieldData['device'] ?? null,
            'user_id'     => !empty($userId) ? absint($userId) : null,
        ]);

        try {
            $submission = EmailCollection::create($data);
            if (!$submission) {
                return self::error(__('Failed to create email submission', 'bit-integrations-pro'));
            }

            return self::success(__('Email submission created successfully', 'bit-integrations-pro'), ['id' => \is_object($submission) ? ($submission->id ?? null) : null]);
        } catch (Exception $e) {
            return self::error($e->getMessage());
        }
    }

    public static function subscribeEmailToProviders($response, $fieldData, $integrationDetails = null)
    {
        if (!class_exists('\FluentPlayer\App\Services\EmailProviderService')) {
            return self::error(__('FluentPlayer is not installed or activated', 'bit-integrations-pro'));
        }

        if (empty($fieldData['email']) || !is_email($fieldData['email'])) {
            return self::error(__('A valid email is required', 'bit-integrations-pro'));
        }

        $data = self::filterEmptyValues([
            'media_id'    => self::resolveMediaId(self::conf($integrationDetails, 'selectedMedia')),
            'preset_slug' => self::conf($integrationDetails, 'selectedPreset') ?: null,
        ]);

        try {
            $results = EmailProviderService::subscribeToProviders($fieldData['email'], $data);

            return self::success(__('Email dispatched to providers', 'bit-integrations-pro'), ['email' => $fieldData['email'], 'results' => $results]);
        } catch (Exception $e) {
            return self::error($e->getMessage());
        }
    }

    public static function recordWatchProgression($response, $fieldData, $utilities = null)
    {
        if (!class_exists('\FluentPlayer\App\Services\Progression\ProgressionService')) {
            return self::error(__('FluentPlayer is not installed or activated', 'bit-integrations-pro'));
        }

        $mediaId = self::resolveMediaId($fieldData['media_id'] ?? null);
        if (!$mediaId) {
            return self::error(__('Media not found', 'bit-integrations-pro'));
        }

        $userId = absint(($fieldData['user_id'] ?? null));
        $watched = isset($fieldData['watched_duration']) ? (float) $fieldData['watched_duration'] : 0;

        if (!$userId || $watched <= 0) {
            return self::error(__('A user and a watched duration greater than zero are required', 'bit-integrations-pro'));
        }

        // The media's own stored duration is the total the coverage ratio is measured
        // against. Passing the watched seconds as the total would make every run
        // report 100% coverage and complete the step regardless of how little was seen.
        $settings = class_exists('\FluentPlayer\App\Models\Media') ? Media::getMediaSettings($mediaId) : [];
        $totalDuration = \is_array($settings) && !empty($settings['duration']) ? (float) $settings['duration'] : 0;

        if ($totalDuration <= 0) {
            return self::error(__('This media has no stored duration yet, so watch progress cannot be measured', 'bit-integrations-pro'));
        }

        $watched = min($watched, $totalDuration);

        $context = self::filterEmptyValues([
            'course_id' => !empty($fieldData['course_id']) ? absint($fieldData['course_id']) : null,
            'step_id'   => !empty($fieldData['step_id']) ? absint($fieldData['step_id']) : null,
        ]);

        try {
            $verdict = ProgressionService::record(
                $mediaId,
                $userId,
                [
                    'segments'       => [['start' => 0, 'end' => $watched]],
                    'duration'       => $totalDuration,
                    'durationSource' => 'server',
                    'ended'          => (bool) self::util($utilities, 'selected_ended'),
                ],
                $context
            );

            return self::success(__('Watch progression recorded', 'bit-integrations-pro'), [
                'media_id'    => $mediaId,
                'user_id'     => $userId,
                'watched'     => $watched,
                'duration'    => $totalDuration,
                'is_complete' => !empty($verdict['complete']),
            ]);
        } catch (Exception $e) {
            return self::error($e->getMessage());
        }
    }

    public static function recordVisit($response, $fieldData, $integrationDetails = null)
    {
        if (!class_exists('\FluentPlayerPro\App\Services\AnalyticsService')) {
            return self::error(__('FluentPlayer Pro is required for this action', 'bit-integrations-pro'));
        }

        $mediaId = self::resolveMediaId($fieldData['media_id'] ?? null);
        if (!$mediaId) {
            return self::error(__('Media not found', 'bit-integrations-pro'));
        }

        $duration = isset($fieldData['duration']) ? (float) $fieldData['duration'] : 0;
        if ($duration <= 0) {
            return self::error(__('Watched duration is required', 'bit-integrations-pro'));
        }

        // Match the caps FluentPlayer's own analytics writer applies, otherwise an
        // out-of-range percentage permanently pins the keep-max daily visit row.
        $duration = min($duration, self::MAX_VISIT_DURATION);
        $percentage = isset($fieldData['percentage']) ? min(max((int) $fieldData['percentage'], 0), 100) : 0;
        $userId = self::conf($integrationDetails, 'selectedUser');

        try {
            $visit = AnalyticsService::recordVisit(
                $mediaId,
                !empty($userId) ? absint($userId) : null,
                $fieldData['ip_address'] ?? null,
                $fieldData['browser'] ?? null,
                $fieldData['device'] ?? null,
                $duration,
                $fieldData['country'] ?? null,
                $percentage
            );

            return self::success(__('Visit recorded successfully', 'bit-integrations-pro'), [
                'media_id' => $mediaId,
                'visit_id' => \is_object($visit) ? ($visit->id ?? null) : null,
            ]);
        } catch (Exception $e) {
            return self::error($e->getMessage());
        }
    }

    public static function savePreset($response, $fieldData)
    {
        if (!class_exists('\FluentPlayer\App\Services\PresetService')) {
            return self::error(__('FluentPlayer is not installed or activated', 'bit-integrations-pro'));
        }

        if (empty($fieldData['name'])) {
            return self::error(__('Preset name is required', 'bit-integrations-pro'));
        }

        $slug = !empty($fieldData['slug']) ? sanitize_title($fieldData['slug']) : sanitize_title($fieldData['name']);

        // PresetService::delete() refuses these; overwriting them is just as destructive.
        if (\in_array($slug, PresetService::RESERVED_SLUGS, true)) {
            return self::error(__('That preset slug is reserved by FluentPlayer and cannot be overwritten', 'bit-integrations-pro'));
        }

        try {
            // PresetService::save() replaces the whole record, so carry the existing
            // settings over instead of blanking a preset that is already in use.
            $existing = PresetService::find($slug);
            $settings = \is_array($existing) && !empty($existing['settings']) ? $existing['settings'] : [];

            $saved = PresetService::save($slug, [
                'name'     => $fieldData['name'],
                'slug'     => $slug,
                'settings' => $settings,
            ]);

            if (!$saved) {
                return self::error(__('Failed to save preset', 'bit-integrations-pro'));
            }

            return self::success(__('Preset saved successfully', 'bit-integrations-pro'), ['slug' => $slug]);
        } catch (Exception $e) {
            return self::error($e->getMessage());
        }
    }

    public static function deletePreset($response, $integrationDetails = null)
    {
        if (!class_exists('\FluentPlayer\App\Services\PresetService')) {
            return self::error(__('FluentPlayer is not installed or activated', 'bit-integrations-pro'));
        }

        $slug = self::conf($integrationDetails, 'selectedPreset');
        if (empty($slug)) {
            return self::error(__('Preset is required', 'bit-integrations-pro'));
        }

        try {
            if (!PresetService::delete($slug)) {
                return self::error(__('Failed to delete preset. It may be a reserved preset or does not exist', 'bit-integrations-pro'));
            }

            return self::success(__('Preset deleted successfully', 'bit-integrations-pro'), ['slug' => $slug]);
        } catch (Exception $e) {
            return self::error($e->getMessage());
        }
    }

    /**
     * @param string $modelMethod
     * @param string $verb        infinitive, used in the failure message
     * @param string $pastVerb    past participle, used in the success message
     * @param mixed  $fieldData
     */
    private static function mediaLifecycle($fieldData, $modelMethod, $verb, $pastVerb)
    {
        if (!class_exists('\FluentPlayer\App\Models\Media')) {
            return self::error(__('FluentPlayer is not installed or activated', 'bit-integrations-pro'));
        }

        $mediaId = absint($fieldData['media_id'] ?? 0);

        if (!$mediaId || get_post_type($mediaId) !== self::MEDIA_POST_TYPE) {
            return self::error(__('Media not found', 'bit-integrations-pro'));
        }

        try {
            $result = Media::{$modelMethod}($mediaId);

            if (is_wp_error($result) || !$result) {
                return self::error(__('Failed to {verb} media', 'bit-integrations-pro'), ['verb' => $verb]);
            }

            return self::success(__('Media {pastVerb} successfully', 'bit-integrations-pro'), ['media_id' => $mediaId], ['pastVerb' => $pastVerb]);
        } catch (Exception $e) {
            return self::error($e->getMessage());
        }
    }

    private static function playlistLifecycle($fieldData, $modelMethod, $verb, $pastVerb)
    {
        if (!class_exists('\FluentPlayerPro\App\Models\Playlist')) {
            return self::error(__('FluentPlayer Pro is required for this action', 'bit-integrations-pro'));
        }

        $playlistId = absint($fieldData['playlist_id'] ?? 0);

        if (!$playlistId || get_post_type($playlistId) !== self::PLAYLIST_POST_TYPE) {
            return self::error(__('Playlist not found', 'bit-integrations-pro'));
        }

        try {
            $result = Playlist::{$modelMethod}($playlistId);

            if (is_wp_error($result) || !$result) {
                return self::error(__('Failed to {verb} playlist', 'bit-integrations-pro'), ['verb' => $verb]);
            }

            return self::success(__('Playlist {pastVerb} successfully', 'bit-integrations-pro'), ['playlist_id' => $playlistId], ['pastVerb' => $pastVerb]);
        } catch (Exception $e) {
            return self::error($e->getMessage());
        }
    }

    private static function writeMediaTags($fieldData, $integrationDetails, $mode)
    {
        if (!class_exists('\FluentPlayerPro\App\Services\TagService')) {
            return self::error(__('FluentPlayer Pro is required for this action', 'bit-integrations-pro'));
        }

        $mediaId = self::resolveMediaId($fieldData['media_id'] ?? null);
        if (!$mediaId) {
            return self::error(__('Media not found', 'bit-integrations-pro'));
        }

        // Required for every mode, including `set` — an empty selection there would
        // silently strip every tag off the media while reporting success.
        $tags = self::toList(self::conf($integrationDetails, 'selectedTags'));
        if (empty($tags)) {
            return self::error(__('At least one tag is required', 'bit-integrations-pro'));
        }

        if ($mode === 'add') {
            $result = wp_set_object_terms($mediaId, $tags, self::MEDIA_TAG_TAXONOMY, true);
        } elseif ($mode === 'remove') {
            $current = wp_get_object_terms($mediaId, self::MEDIA_TAG_TAXONOMY, ['fields' => 'names']);
            $current = is_wp_error($current) ? [] : $current;
            $result = wp_set_object_terms($mediaId, array_values(array_diff($current, $tags)), self::MEDIA_TAG_TAXONOMY);
        } else {
            $result = wp_set_object_terms($mediaId, $tags, self::MEDIA_TAG_TAXONOMY);
        }

        if (is_wp_error($result)) {
            return self::error($result->get_error_message());
        }

        return self::success(__('Media tags updated successfully', 'bit-integrations-pro'), ['media_id' => $mediaId]);
    }

    private static function writePlaylistMedia($fieldData, $isAdding)
    {
        if (!class_exists('\FluentPlayerPro\App\Models\Playlist')) {
            return self::error(__('FluentPlayer Pro is required for this action', 'bit-integrations-pro'));
        }

        $playlistId = self::resolvePlaylistId($fieldData['playlist_id'] ?? null);
        if (!$playlistId) {
            return self::error(__('Playlist not found', 'bit-integrations-pro'));
        }

        $mediaIds = array_values(array_filter(array_map('absint', self::toList($fieldData['media_ids'] ?? null))));
        if (empty($mediaIds)) {
            return self::error(__('At least one media item is required', 'bit-integrations-pro'));
        }

        $settings = get_post_meta($playlistId, 'settings', true);
        $settings = \is_array($settings) ? $settings : [];
        $current = array_map('absint', (array) ($settings['medias'] ?? []));

        $settings['medias'] = $isAdding
            ? array_values(array_unique(array_merge($current, $mediaIds)))
            : array_values(array_diff($current, $mediaIds));

        update_post_meta($playlistId, 'settings', $settings);

        return self::success(__('Playlist media updated successfully', 'bit-integrations-pro'), ['playlist_id' => $playlistId]);
    }

    private static function playlistSettings($fieldData, $integrationDetails, $existing)
    {
        $settings = self::filterEmptyValues([
            'title'     => $fieldData['title'] ?? null,
            'posterSrc' => $fieldData['poster_src'] ?? null,
        ]);

        $mediaIds = array_values(array_filter(array_map('absint', self::toList(self::conf($integrationDetails, 'selectedMediaIds')))));
        if (!empty($mediaIds)) {
            $settings['medias'] = $mediaIds;
        }

        return array_merge($existing, $settings);
    }

    private static function applyTags($mediaId, $tags)
    {
        $tags = self::toList($tags);
        if (!empty($tags)) {
            wp_set_object_terms($mediaId, $tags, self::MEDIA_TAG_TAXONOMY);
        }
    }

    /**
     * Read a record picker / required option select from the integration config.
     *
     * @param string $key
     * @param mixed  $integrationDetails
     *
     * @return mixed
     */
    private static function conf($integrationDetails, $key)
    {
        if (\is_object($integrationDetails) && isset($integrationDetails->{$key})) {
            return $integrationDetails->{$key};
        }

        if (\is_array($integrationDetails) && isset($integrationDetails[$key])) {
            return $integrationDetails[$key];
        }
    }

    /**
     * Read an optional option select from the Utilities section.
     *
     * @param string $key
     * @param mixed  $utilities
     *
     * @return mixed
     */
    private static function util($utilities, $key)
    {
        if (\is_object($utilities) && isset($utilities->{$key})) {
            return $utilities->{$key};
        }

        if (\is_array($utilities) && isset($utilities[$key])) {
            return $utilities[$key];
        }
    }

    private static function toList($value)
    {
        if (empty($value)) {
            return [];
        }

        if (!\is_array($value)) {
            $value = explode(',', (string) $value);
        }

        return array_values(array_filter(array_map('trim', array_map('strval', $value))));
    }

    private static function resolveMediaId($mediaId)
    {
        $mediaId = absint($mediaId);

        return $mediaId && get_post_type($mediaId) === self::MEDIA_POST_TYPE ? $mediaId : null;
    }

    private static function resolvePlaylistId($playlistId)
    {
        $playlistId = absint($playlistId);

        return $playlistId && get_post_type($playlistId) === self::PLAYLIST_POST_TYPE ? $playlistId : null;
    }

    private static function filterEmptyValues($data)
    {
        return array_filter($data, static function ($value) {
            return $value !== null && $value !== '';
        });
    }

    private static function isActive()
    {
        return \defined('FLUENT_PLAYER');
    }

    private static function success($message, $data = [])
    {
        return ['success' => true, 'message' => $message, 'data' => $data];
    }

    private static function error($message)
    {
        return ['success' => false, 'message' => $message];
    }
}
