<?php

namespace BitApps\IntegrationsPro\Actions\Booknetic\Services;

use BookneticApp\Models\AppointmentExtra;
use BookneticApp\Models\ExtraCategory;
use BookneticApp\Models\Service;
use BookneticApp\Models\ServiceExtra;
use BookneticApp\Models\Translation;

final class ServiceExtraService extends BaseService
{
    public function createServiceExtra(): array
    {
        $error = $this->validate([
            'name'         => [__('Name', 'bit-integrations-pro')],
            'price'        => [__('Price', 'bit-integrations-pro'), 'numeric'],
            'min_quantity' => [__('Minimum Quantity', 'bit-integrations-pro'), 'integer'],
            'max_quantity' => [__('Maximum Quantity', 'bit-integrations-pro'), 'integer'],
        ]);

        if ($error !== null) {
            return $error;
        }

        if ($this->int('max_quantity') < $this->int('min_quantity')) {
            return $this->error(__('The maximum quantity is less than the minimum quantity. Enter a larger maximum quantity.', 'bit-integrations-pro'));
        }

        $relationsError = $this->relationsError();

        if ($relationsError !== null) {
            return $this->error($relationsError);
        }

        return $this->createRecord(
            ServiceExtra::class,
            [
                'service_id'    => $this->has('service_id') ? $this->int('service_id') : null,
                'name'          => $this->string('name'),
                'image'         => '',
                'price'         => (float) $this->string('price'),
                'duration'      => max(0, $this->int('duration')),
                'max_quantity'  => max(1, $this->int('max_quantity')),
                'is_active'     => 1,
                'hide_duration' => 0,
                'hide_price'    => 0,
                'min_quantity'  => max(0, $this->int('min_quantity')),
                'notes'         => $this->string('notes'),
                'category_id'   => $this->has('category_id') ? $this->int('category_id') : null,
            ]
        );
    }

    public function updateServiceExtra(): array
    {
        $error = $this->validate(['service_extra_id' => [__('Service Extra ID', 'bit-integrations-pro'), 'integer']]);

        if ($error !== null) {
            return $error;
        }

        $extraId = $this->int('service_extra_id');
        $extra = ServiceExtra::query()->get($extraId);

        if (empty($extra)) {
            return $this->error(__('The service extra does not exist. Select a different service extra.', 'bit-integrations-pro'));
        }

        $relationsError = $this->relationsError();

        if ($relationsError !== null) {
            return $this->error($relationsError);
        }

        $data = $this->optionalTextFields(['name' => 'name', 'notes' => 'notes'])
            + $this->optionalIntFields(['service_id', 'duration', 'max_quantity', 'min_quantity', 'category_id']);

        if ($this->has('price')) {
            $data['price'] = (float) $this->string('price');
        }

        if ($this->has('is_active')) {
            $data['is_active'] = (int) $this->toBool($this->value('is_active'));
        }

        $maxQuantity = (int) ($data['max_quantity'] ?? $extra->max_quantity);

        if ($maxQuantity < 1 || $maxQuantity < (int) ($data['min_quantity'] ?? $extra->min_quantity)) {
            return $this->error(__('The maximum quantity is less than the minimum quantity. Enter a larger maximum quantity.', 'bit-integrations-pro'));
        }

        return $this->updateRecord(ServiceExtra::class, $extraId, $data);
    }

    public function deleteServiceExtra(): array
    {
        $error = $this->validate(['service_extra_id' => [__('Service Extra ID', 'bit-integrations-pro'), 'integer']]);

        if ($error !== null) {
            return $error;
        }

        $extraId = $this->int('service_extra_id');

        if (AppointmentExtra::query()->where('extra_id', $extraId)->count() > 0) {
            return $this->error(__('Appointments use this service extra. Remove it from the appointments first.', 'bit-integrations-pro'), 422);
        }

        $result = $this->deleteRecord(ServiceExtra::class, $extraId, __('The service extra is deleted.', 'bit-integrations-pro'));

        if ($result['success']) {
            Translation::query()->where(['table_name' => 'service_extras', 'row_id' => $extraId])->delete();
        }

        return $result;
    }

    public function duplicateServiceExtra(): array
    {
        $error = $this->validate(['service_extra_id' => [__('Service Extra ID', 'bit-integrations-pro'), 'integer']]);

        if ($error !== null) {
            return $error;
        }

        $extra = ServiceExtra::query()->get($this->int('service_extra_id'));

        if (empty($extra)) {
            return $this->error(__('The service extra does not exist. Select a different service extra.', 'bit-integrations-pro'));
        }

        if ($this->has('service_id') && empty(Service::query()->get($this->int('service_id')))) {
            return $this->error(__('The service does not exist. Select a different service.', 'bit-integrations-pro'));
        }

        $data = $extra->toArray();
        unset($data['id'], $data['tenant_id']);
        $data['name'] = $data['name'] . ' (2)';

        if ($this->has('service_id')) {
            $data['service_id'] = $this->int('service_id');
        }

        return $this->createRecord(ServiceExtra::class, $data);
    }

    private function relationsError(): ?string
    {
        if ($this->has('service_id') && empty(Service::query()->get($this->int('service_id')))) {
            return __('The service does not exist. Select a different service.', 'bit-integrations-pro');
        }

        if ($this->has('category_id') && empty(ExtraCategory::query()->get($this->int('category_id')))) {
            return __('The service extra category does not exist. Select a different category.', 'bit-integrations-pro');
        }

        return null;
    }
}
