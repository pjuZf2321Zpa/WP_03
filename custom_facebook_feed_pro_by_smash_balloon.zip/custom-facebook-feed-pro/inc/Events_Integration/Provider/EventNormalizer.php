<?php
/**
 * Maps raw Graph event payloads (object or array shape) to NormalizedEvent
 * objects, centralizing timezone/all-day handling and expanding
 * event_times[] into one NormalizedEvent per occurrence.
 *
 * @package CustomFacebookFeed\Events_Integration
 * @since 4.11
 */

namespace CustomFacebookFeed\Events_Integration\Provider;

use CustomFacebookFeed\Events_Integration\NormalizedEvent;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class EventNormalizer {

	/**
	 * Default duration applied when Facebook omits end_time.
	 */
	const DEFAULT_DURATION_SECONDS = 2 * HOUR_IN_SECONDS;

	/**
	 * Grace window: events are considered "upcoming" until this long after
	 * their end (mirrors the display pipeline's eventoffset default).
	 */
	const PAST_GRACE_SECONDS = 6 * HOUR_IN_SECONDS;

	/**
	 * Normalize a list of raw Graph events, expanding recurrences and
	 * dropping past events.
	 *
	 * @param array  $raw_events Raw event objects/arrays.
	 * @param string $source_id  Page ID the events belong to.
	 * @return NormalizedEvent[]
	 */
	public function normalize_list( array $raw_events, $source_id ) {
		$normalized = array();

		foreach ( $raw_events as $raw ) {
			foreach ( $this->normalize( $raw, $source_id ) as $event ) {
				if ( $this->is_upcoming( $event ) ) {
					$normalized[] = $event;
				}
			}
		}

		return $normalized;
	}

	/**
	 * Normalize one raw Graph event into one or more NormalizedEvents
	 * (recurring events produce one per event_times[] occurrence).
	 *
	 * @param mixed  $raw       Raw event object or assoc array.
	 * @param string $source_id Page ID.
	 * @return NormalizedEvent[]
	 */
	public function normalize( $raw, $source_id ) {
		$id = (string) $this->field( $raw, 'id' );
		if ( '' === $id ) {
			return array();
		}

		$base                  = new NormalizedEvent();
		$base->source_event_id = $id;
		$base->source_id       = (string) $source_id;
		// Facebook content is untrusted; sanitize once for all adapters.
		$base->title       = sanitize_text_field( (string) $this->field( $raw, 'name' ) );
		$base->description = wp_kses_post( (string) $this->field( $raw, 'description' ) );
		$base->is_canceled = (bool) $this->field( $raw, 'is_canceled' );
		$base->timezone        = $this->sanitize_timezone( (string) $this->field( $raw, 'timezone' ) );
		$base->ticket_uri      = esc_url_raw( (string) $this->field( $raw, 'ticket_uri' ) );
		$base->updated_time    = $this->to_timestamp( $this->field( $raw, 'updated_time' ) );
		$base->cover_url       = (string) $this->field( $this->field( $raw, 'cover' ), 'source' );
		$base->location        = $this->normalize_location( $this->field( $raw, 'place' ) );

		// Graph returns event_times as a paged connection ({data: [...]}).
		$event_times = $this->field( $raw, 'event_times' );
		$times_list  = $this->field( $event_times, 'data' );
		if ( null !== $times_list ) {
			$event_times = $times_list;
		}
		if ( is_array( $event_times ) && ! empty( $event_times ) ) {
			$events = array();
			foreach ( $event_times as $occurrence ) {
				$occurrence_id = (string) $this->field( $occurrence, 'id' );
				$start_raw     = $this->field( $occurrence, 'start_time' );
				if ( '' === $occurrence_id || empty( $start_raw ) ) {
					continue;
				}
				$event                = clone $base;
				$event->occurrence_id = $occurrence_id;
				$this->apply_dates( $event, $start_raw, $this->field( $occurrence, 'end_time' ) );
				$events[] = $event;
			}
			return $events;
		}

		$start_raw = $this->field( $raw, 'start_time' );
		if ( empty( $start_raw ) ) {
			$start_raw = $this->field( $raw, 'created_time' );
		}
		if ( empty( $start_raw ) ) {
			return array();
		}
		$this->apply_dates( $base, $start_raw, $this->field( $raw, 'end_time' ) );

		return array( $base );
	}

	/**
	 * Whether the event's end (plus grace window) is still in the future.
	 *
	 * @param NormalizedEvent $event Normalized event.
	 * @return bool
	 */
	public function is_upcoming( NormalizedEvent $event ) {
		$end = $event->end_timestamp();

		return $end > 0 && $end >= ( time() - self::PAST_GRACE_SECONDS );
	}

	/**
	 * Set start/end/all_day from raw Graph time strings (date-only means
	 * all-day; a missing end gets a default because targets require one).
	 *
	 * @param NormalizedEvent $event     Event to mutate.
	 * @param string          $start_raw Raw start_time.
	 * @param string|null     $end_raw   Raw end_time.
	 */
	private function apply_dates( NormalizedEvent $event, $start_raw, $end_raw ) {
		$event->all_day = $this->is_date_only( (string) $start_raw );

		$tz    = $this->timezone_object( $event->timezone );
		$start = $this->parse_datetime( (string) $start_raw, $tz );
		if ( null === $start ) {
			return;
		}
		$end = null !== $end_raw ? $this->parse_datetime( (string) $end_raw, $tz ) : null;
		if ( null === $end ) {
			$end = $event->all_day
				? $start->setTime( 23, 59, 59 )
				: $start->modify( '+' . self::DEFAULT_DURATION_SECONDS . ' seconds' );
		}

		$event->start = $start;
		$event->end   = $end;
	}

	/**
	 * Parse a Graph time string in the event's timezone.
	 *
	 * @param string        $value Raw time string.
	 * @param \DateTimeZone $tz    Event timezone.
	 * @return \DateTimeImmutable|null
	 */
	private function parse_datetime( $value, \DateTimeZone $tz ) {
		if ( '' === $value ) {
			return null;
		}
		try {
			$dt = new \DateTimeImmutable( $value, $tz );
			return $dt->setTimezone( $tz );
		} catch ( \Exception $e ) {
			return null;
		}
	}

	/**
	 * @param string $value Raw time string.
	 * @return bool True for date-only strings like "2026-08-11".
	 */
	private function is_date_only( $value ) {
		return (bool) preg_match( '/^\d{4}-\d{2}-\d{2}$/', $value );
	}

	/**
	 * @param mixed $value Raw time string.
	 * @return int UTC timestamp, 0 when unparseable.
	 */
	private function to_timestamp( $value ) {
		if ( empty( $value ) || ! is_string( $value ) ) {
			return 0;
		}
		$ts = strtotime( $value );

		return false === $ts ? 0 : $ts;
	}

	/**
	 * Validate an IANA timezone string, falling back to the site timezone.
	 *
	 * @param string $timezone Raw timezone from Graph.
	 * @return string
	 */
	private function sanitize_timezone( $timezone ) {
		if ( '' !== $timezone && in_array( $timezone, timezone_identifiers_list(), true ) ) {
			return $timezone;
		}
		$site_tz = function_exists( 'wp_timezone_string' ) ? wp_timezone_string() : 'UTC';

		// Offset-style site settings ("+02:00") are not valid IANA names.
		return in_array( $site_tz, timezone_identifiers_list(), true ) ? $site_tz : 'UTC';
	}

	/**
	 * @param string $timezone Sanitized timezone string.
	 * @return \DateTimeZone
	 */
	private function timezone_object( $timezone ) {
		try {
			return new \DateTimeZone( '' !== $timezone ? $timezone : 'UTC' );
		} catch ( \Exception $e ) {
			return new \DateTimeZone( 'UTC' );
		}
	}

	/**
	 * Normalize the Graph place object into the location parts array.
	 *
	 * @param mixed $place Raw place object/array or null.
	 * @return array
	 */
	private function normalize_location( $place ) {
		$location = array(
			'name'      => '',
			'street'    => '',
			'city'      => '',
			'state'     => '',
			'zip'       => '',
			'country'   => '',
			'latitude'  => '',
			'longitude' => '',
		);

		if ( empty( $place ) ) {
			return $location;
		}

		// Place data is Facebook content too; same boundary as title/description.
		$location['name'] = sanitize_text_field( (string) $this->field( $place, 'name' ) );

		$loc = $this->field( $place, 'location' );
		if ( ! empty( $loc ) ) {
			$location['street']    = sanitize_text_field( (string) $this->field( $loc, 'street' ) );
			$location['city']      = sanitize_text_field( (string) $this->field( $loc, 'city' ) );
			$location['state']     = sanitize_text_field( (string) $this->field( $loc, 'state' ) );
			$location['zip']       = sanitize_text_field( (string) $this->field( $loc, 'zip' ) );
			$location['country']   = sanitize_text_field( (string) $this->field( $loc, 'country' ) );
			$location['latitude']  = '' . $this->field( $loc, 'latitude' );
			$location['longitude'] = '' . $this->field( $loc, 'longitude' );
		}

		return $location;
	}

	/**
	 * Object/array-tolerant field access.
	 *
	 * @param mixed  $data Raw payload node.
	 * @param string $key  Field name.
	 * @return mixed|null
	 */
	private function field( $data, $key ) {
		if ( is_object( $data ) && isset( $data->{$key} ) ) {
			return $data->{$key};
		}
		if ( is_array( $data ) && isset( $data[ $key ] ) ) {
			return $data[ $key ];
		}
		return null;
	}
}
