<?php

if (!defined('ABSPATH')) {
    die('You are not allowed to call this page directly.');
}

/**
 * MeprCurrencySwitcherCtrl -- Currency switching via URL query param, cookie
 * management, locale auto-detection, and ReadyLaunch header component.
 */
class MeprCurrencySwitcherCtrl extends MeprBaseCartCtrl
{
    /**
     * Load hooks for currency switching functionality.
     *
     * @return void
     */
    public function load_hooks()
    {
        // Handle currency switch via ?mepr_set_currency=XXX (before output).
        add_action('template_redirect', [$this, 'handle_currency_switch'], 1);

        // Auto-detect on first visit (before any output).
        add_action('template_redirect', [$this, 'maybe_detect_currency'], 5);

        // AJAX handler for currency switch (kept for API consumers).
        add_action('wp_ajax_mepr_currency_set', [$this, 'ajax_set_currency']);
        add_action('wp_ajax_nopriv_mepr_currency_set', [$this, 'ajax_set_currency']);

        // Enqueue switcher CSS on frontend.
        add_action('wp_enqueue_scripts', [$this, 'enqueue_assets']);
    }

    /**
     * Handle currency switch via query parameter.
     *
     * When ?mepr_set_currency=EUR is in the URL, set the cookie/session
     * and redirect to the clean URL. No JS required.
     *
     * @return void
     */
    public function handle_currency_switch()
    {
        if (empty($_GET['mepr_set_currency'])) {
            return;
        }

        if (!MeprCurrencyService::should_show_currency_switcher()) {
            wp_safe_redirect(remove_query_arg('mepr_set_currency'));
            exit;
        }

        $currency = strtoupper(sanitize_text_field(wp_unslash($_GET['mepr_set_currency'])));

        if (!MeprCurrencyService::is_enabled_currency($currency)) {
            return;
        }

        $this->set_currency_cookie($currency);
        $this->store_in_session($currency);
        $this->store_user_preference($currency);

        // Redirect to clean URL (remove the query param).
        wp_safe_redirect(remove_query_arg('mepr_set_currency'));
        exit;
    }

    /**
     * Auto-detect currency from browser locale on first visit.
     * Only fires if no mepr_currency cookie exists.
     *
     * @return void
     */
    public function maybe_detect_currency()
    {
        if (isset($_COOKIE['mepr_currency'])) {
            return;
        }

        $detected = MeprCurrencyService::detect_from_locale();
        if ($detected && MeprCurrencyService::is_enabled_currency($detected)) {
            $this->set_currency_cookie($detected);
            $this->store_in_session($detected);
        }
    }

    /**
     * AJAX handler for manual currency switch.
     *
     * @return void
     */
    public function ajax_set_currency()
    {
        check_ajax_referer('mepr_currency_nonce');

        $currency = isset($_POST['currency']) ? strtoupper(sanitize_text_field(wp_unslash($_POST['currency']))) : '';
        if (empty($currency) || !MeprCurrencyService::is_enabled_currency($currency)) {
            wp_send_json_error(['message' => 'Invalid currency.']);
        }

        $this->set_currency_cookie($currency);
        $this->store_in_session($currency);
        $this->store_user_preference($currency);
        wp_send_json_success(['currency' => $currency]);
    }

    /**
     * Persist an EXPLICIT currency choice on the account (GAP-MC-5) so returning logged-in
     * buyers keep their currency across devices and cookie expiry. Auto-detect never writes
     * this — it is not a user choice.
     *
     * @param  string $code ISO 4217 currency code.
     * @return void
     */
    private function store_user_preference(string $code)
    {
        if (MeprUtils::is_user_logged_in()) {
            update_user_meta(get_current_user_id(), '_mepr_preferred_currency', $code);
        }
    }

    /**
     * Set currency cookie with 30-day expiry.
     *
     * @param  string $code ISO 4217 currency code.
     * @return void
     */
    private function set_currency_cookie(string $code)
    {
        setcookie('mepr_currency', $code, time() + (30 * DAY_IN_SECONDS), COOKIEPATH, COOKIE_DOMAIN, is_ssl(), false);
        $_COOKIE['mepr_currency'] = $code;
    }

    /**
     * Store currency in active cart session if one exists.
     *
     * @param  string $code ISO 4217 currency code.
     * @return void
     */
    private function store_in_session(string $code)
    {
        $session = MeprCartSessionService::current_session();
        if ($session) {
            $data               = json_decode($session->cart_data, true) ?: [];
            $data['currency']   = $code;
            $session->cart_data = wp_json_encode($data);
            MeprCartSession::update($session);
        }
    }

    /**
     * Enqueue currency switcher CSS on frontend.
     *
     * @return void
     */
    public function enqueue_assets()
    {
        $enabled = MeprCurrencyService::get_enabled_currencies();
        if (count($enabled) < 2) {
            return;
        }

        wp_enqueue_style(
            'mepr-currency-switcher',
            MEPR_CSS_URL . '/readylaunch/currency-switcher.css',
            [],
            MEPR_VERSION
        );
    }
}
