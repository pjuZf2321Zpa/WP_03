<?php

namespace FluentCartPro\App\Modules\Integrations;

/**
 * Keeps webhook feeds from reaching the server's own network.
 *
 * Feed URLs are set by delegated staff (products/edit, integrations/manage), so an
 * unchecked URL lets them make the server call loopback services, cloud metadata or
 * LAN hosts. wp_safe_remote_request() covers part of this, but it trusts the site's
 * own host, has no IPv6 coverage, and only runs at send time — so we check here too,
 * on save (to give the editor an error) and again before every send (DNS can change).
 *
 * A merchant who deliberately posts to an internal host opts in per host through
 * the `fluent_cart/webhook/allow_internal_host` filter.
 */
class WebhookUrlGuard
{
    private static $blockedRanges = [
        '0.0.0.0/8',       // "this" network
        '10.0.0.0/8',      // private
        '100.64.0.0/10',   // carrier-grade NAT
        '127.0.0.0/8',     // loopback
        '169.254.0.0/16',  // link-local, cloud metadata
        '172.16.0.0/12',   // private
        '192.0.0.0/24',    // IETF protocol assignments
        '192.168.0.0/16',  // private
        '198.18.0.0/15',   // benchmarking
        '224.0.0.0/4',     // multicast
        '240.0.0.0/4',     // reserved, broadcast
        '::/128',          // unspecified
        '::1/128',         // loopback
        'fc00::/7',        // unique local
        'fe80::/10',       // link-local
        'fec0::/10',       // site-local (deprecated, still routed on some LANs)
        'ff00::/8',        // multicast
        '64:ff9b:1::/48',  // local-use NAT64: operator-defined layout, so the IPv4 target can't be decoded
        '2001::/32',       // Teredo: the IPv4 endpoints are obfuscated, so they can't be checked
    ];

    /**
     * @param string $url
     * @return true|\WP_Error
     */
    public static function validate($url)
    {
        $result = self::check($url);

        return is_wp_error($result) ? $result : true;
    }

    /**
     * Validates the URL and returns the addresses its host resolved to, so the caller
     * can pin the connection to exactly what was checked (see resolveEntry()).
     *
     * @param string $url
     * @return string[]|\WP_Error
     */
    public static function check($url)
    {
        $invalid = new \WP_Error('webhook_url_invalid', __('Please provide a valid http or https webhook URL.', 'fluent-cart-pro'));

        if (!is_string($url) || filter_var($url, FILTER_VALIDATE_URL) === false) {
            return $invalid;
        }

        $parts = wp_parse_url($url);
        $scheme = strtolower((string)($parts['scheme'] ?? ''));

        if (!in_array($scheme, ['http', 'https'], true) || empty($parts['host']) || isset($parts['user']) || isset($parts['pass'])) {
            return $invalid;
        }

        $ips = self::resolve(self::hostOf($url));

        if (self::allowsInternalHost($url)) {
            return $ips;
        }

        foreach ($ips as $ip) {
            if (self::isBlockedIp($ip)) {
                return new \WP_Error(
                    'webhook_url_internal',
                    __('Webhook URL points to a private, loopback or link-local address. Use a public endpoint.', 'fluent-cart-pro')
                );
            }
        }

        // A host that does not resolve passes here; the transport refuses to connect to it anyway.
        return $ips;
    }

    /**
     * cURL `CURLOPT_RESOLVE` entry pinning the URL's host to an approved address.
     *
     * Without it cURL resolves the name again, and a DNS server answering with a short
     * TTL can hand the guard a public IP and cURL an internal one (DNS rebinding).
     * Returns null when there is nothing to pin: an IP-literal host, or no addresses.
     *
     * @param string   $url
     * @param string[] $ips
     * @return string|null
     */
    public static function resolveEntry($url, array $ips)
    {
        $host = self::hostOf($url);

        if (!$ips || self::isIpLiteral($url)) {
            return null;
        }

        $ipv4 = array_values(array_filter($ips, function ($ip) {
            return filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4);
        }));

        $ip = $ipv4 ? $ipv4[0] : reset($ips);
        if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV6)) {
            $ip = '[' . $ip . ']';
        }

        $port = wp_parse_url($url, PHP_URL_PORT);
        if (!$port) {
            $port = strtolower((string)wp_parse_url($url, PHP_URL_SCHEME)) === 'https' ? 443 : 80;
        }

        return $host . ':' . $port . ':' . $ip;
    }

    /**
     * Whether the URL's host is an IP address, so no DNS lookup (and no pin) is involved.
     *
     * @param string $url
     * @return bool
     */
    public static function isIpLiteral($url)
    {
        return (bool)filter_var(self::hostOf($url), FILTER_VALIDATE_IP);
    }

    /**
     * Whether the merchant explicitly allowed this URL's host to be internal.
     *
     * @param string $url
     * @return bool
     */
    public static function allowsInternalHost($url)
    {
        return (bool)apply_filters('fluent_cart/webhook/allow_internal_host', false, [
            'host' => self::hostOf($url),
            'url'  => $url,
        ]);
    }

    /**
     * @param string $ip
     * @return bool
     */
    public static function isBlockedIp($ip)
    {
        $packed = @inet_pton($ip);
        if ($packed === false) {
            return true;
        }

        // IPv4-mapped (::ffff:a.b.c.d), well-known NAT64 (64:ff9b::a.b.c.d) and 6to4 (2002:aabb:ccdd::)
        // carry an IPv4 target; check that target against the IPv4 ranges.
        if (strlen($packed) === 16) {
            $prefix = substr($packed, 0, 12);
            if ($prefix === str_repeat("\0", 10) . "\xff\xff" || $prefix === "\x00\x64\xff\x9b" . str_repeat("\0", 8)) {
                $packed = substr($packed, 12);
            } elseif (substr($packed, 0, 2) === "\x20\x02") {
                $packed = substr($packed, 2, 4);
            }
        }

        foreach (self::$blockedRanges as $range) {
            if (self::inRange($packed, $range)) {
                return true;
            }
        }

        return false;
    }

    /**
     * @param string $url
     * @return string
     */
    private static function hostOf($url)
    {
        return trim(strtolower((string)wp_parse_url($url, PHP_URL_HOST)), '[].');
    }

    /**
     * @param string $host
     * @return string[]
     */
    private static function resolve($host)
    {
        if (filter_var($host, FILTER_VALIDATE_IP)) {
            return [$host];
        }

        $ips = gethostbynamel($host) ?: [];

        if (function_exists('dns_get_record')) {
            $records = @dns_get_record($host, DNS_AAAA);
            foreach ((array)$records as $record) {
                if (!empty($record['ipv6'])) {
                    $ips[] = $record['ipv6'];
                }
            }
        }

        return $ips;
    }

    /**
     * @param string $packedIp
     * @param string $range
     * @return bool
     */
    private static function inRange($packedIp, $range)
    {
        list($subnet, $bits) = explode('/', $range);
        $packedSubnet = inet_pton($subnet);

        if (strlen($packedSubnet) !== strlen($packedIp)) {
            return false;
        }

        $bits = (int)$bits;
        $bytes = intdiv($bits, 8);

        if (substr($packedIp, 0, $bytes) !== substr($packedSubnet, 0, $bytes)) {
            return false;
        }

        $remainder = $bits % 8;
        if ($remainder === 0) {
            return true;
        }

        $mask = (0xFF << (8 - $remainder)) & 0xFF;

        return (ord($packedIp[$bytes]) & $mask) === (ord($packedSubnet[$bytes]) & $mask);
    }
}
