<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\AssistPro\Deps\BitApps\WPKit\Http\Router\Route;
use BitApps\AssistPro\HTTP\Controllers\WidgetController;

Route::group(function () {
    Route::post('/widgets/{widget}/update', [WidgetController::class, 'update']);
    Route::post('/widgets/{widgetId}/changeActive', [WidgetController::class, 'changeActive']);
})->middleware('nonce', 'isAdmin', 'isPro');
