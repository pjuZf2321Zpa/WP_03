<?php

namespace FluentCartPro\App\Modules\MultiCurrency;

use FluentCart\App\Helpers\CurrenciesHelper;
use FluentCart\App\Modules\MultiCurrency\Services\CurrencyContext;
use FluentCart\App\Modules\MultiCurrency\Services\MultiCurrencySettings;
use FluentCartPro\App\Utils\Enqueuer\Vite;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Turns any element marked [data-fluent-cart-currency-switcher] or
 * .fct-currency-switcher-toggle (a nav menu item can only carry classes) into
 * a currency picker, and fills [data-fluent-cart-current-currency] /
 * .fct-current-currency with the shopper's currency.
 */
class CurrencyDropdown
{
    const HANDLE = 'fluent-cart-pro-currency-dropdown';

    /**
     * Currencies whose code doesn't start with their flag's country code.
     * Shared regional ones (XAF, XCD, XOF, XPF) have no single flag.
     */
    const FLAG_EXCEPTIONS = [
        'EUR' => 'eu',
        'ANG' => 'cw',
    ];

    public function register(): void
    {
        // Needs core with multi-currency
        if (!class_exists(CurrencyContext::class)) {
            return;
        }

        add_action('wp_enqueue_scripts', [$this, 'enqueueAssets']);
        add_action('wp_head', [$this, 'printHiddenTriggerStyle']);
        add_action('wp_footer', [$this, 'printDropdown']);
        add_filter('fluent_cart/currency_switcher/render', [$this, 'renderSwitcher'], 10, 2);
        add_filter('fluent_cart/currency_switcher/editor_preview', [$this, 'editorPreview'], 10, 1);
    }

    /**
     * The block editor previews the button the frontend renders, flags included.
     * Not isAvailable(): the editor is a back-office screen.
     *
     * @param array $preview ['style' => string, 'currencies' => array[]]
     * @return array
     */
    public function editorPreview($preview)
    {
        if (!is_array($preview) || !MultiCurrencySettings::isEnabled() || count(CurrencyContext::selectableCurrencies()) < 2) {
            return $preview;
        }

        if (!apply_filters('fluent_cart/currency_switcher/dropdown_enabled', true)) {
            return $preview;
        }

        $preview['style'] = 'button';
        $preview['currencies'] = self::currencies();

        return $preview;
    }

    /**
     * [fluent_cart_currency_switcher] and the block open the dropdown instead
     * of core's <select>.
     *
     * @param string|null $html
     * @param array       $context ['atts' => array, 'currencies' => string[], 'current' => string]
     * @return string|null
     */
    public function renderSwitcher($html, $context = [])
    {
        if (is_string($html) || !self::isAvailable()) {
            return $html;
        }

        $atts = isset($context['atts']) && is_array($context['atts']) ? $context['atts'] : [];

        return (new CurrencyDropdownRenderer(self::currencies(), CurrencyContext::current()))->renderButton($atts);
    }

    public static function isAvailable(): bool
    {
        if (!MultiCurrencySettings::isEnabled() || CurrencyContext::isBackOffice()) {
            return false;
        }

        if (count(CurrencyContext::selectableCurrencies()) < 2) {
            return false;
        }

        return (bool) apply_filters('fluent_cart/currency_switcher/dropdown_enabled', true);
    }

    /**
     * @return array[] each {code, symbol, name, flag}, base currency first
     */
    public static function currencies(): array
    {
        $currencies = [];
        foreach (CurrencyContext::selectableCurrencies() as $code) {
            $currencies[] = [
                'code'   => $code,
                // Some core signs carry a trailing &nbsp;, which plain trim() keeps
                'symbol' => preg_replace('/^[\s\x{00A0}]+|[\s\x{00A0}]+$/u', '', html_entity_decode(CurrenciesHelper::getCurrencySign($code), ENT_QUOTES, 'UTF-8')),
                'name'   => (string) CurrenciesHelper::getCurrencies($code),
                'flag'   => self::flagUrl($code),
            ];
        }

        return $currencies;
    }

    /**
     * Same flag source as the tax screens. Empty when no flag fits the currency.
     */
    public static function flagUrl(string $code): string
    {
        $code = strtoupper($code);
        if (isset(self::FLAG_EXCEPTIONS[$code])) {
            $flag = self::FLAG_EXCEPTIONS[$code];
        } elseif (strpos($code, 'X') === 0 || strlen($code) !== 3) {
            return '';
        } else {
            $flag = strtolower(substr($code, 0, 2));
        }

        return 'https://flagcdn.com/w40/' . $flag . '.png';
    }

    public static function scriptVars(): array
    {
        return [
            'currencies' => self::currencies(),
            'current'    => CurrencyContext::current(),
            'param'      => CurrencyContext::QUERY_PARAM,
        ];
    }

    public function enqueueAssets(): void
    {
        if (!self::isAvailable()) {
            return;
        }

        Vite::enqueueStyle(self::HANDLE, 'public/multi-currency/currency-dropdown.scss');
        Vite::enqueueScript(self::HANDLE, 'public/multi-currency/currency-dropdown.js', [], null, true)->with([
            'fluentcart_currency_switcher_vars' => self::scriptVars(),
        ]);
    }

    /**
     * A trigger the store left in its menu would otherwise open nothing.
     */
    public function printHiddenTriggerStyle(): void
    {
        if (self::isAvailable()) {
            return;
        }

        echo '<style id="fct-currency-switcher-hidden">[data-fluent-cart-currency-switcher],.fct-currency-switcher-toggle{display:none!important}</style>';
    }

    public function printDropdown(): void
    {
        if (!self::isAvailable()) {
            return;
        }

        (new CurrencyDropdownRenderer(self::currencies(), CurrencyContext::current()))->render();
    }
}
