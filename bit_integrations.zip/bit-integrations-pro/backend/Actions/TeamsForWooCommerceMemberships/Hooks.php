<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Core\Util\Hooks;
use BitApps\IntegrationsPro\Actions\TeamsForWooCommerceMemberships\TeamsForWooCommerceMembershipsProHelper;
use BitApps\IntegrationsPro\Config;

// Deprecated since v2.7.8 - use bit_integrations_teams_for_wc_memberships_* hooks instead
if (class_exists('BitApps\\IntegrationsPro\\Config') && version_compare(BitApps\IntegrationsPro\Config::VERSION, '2.7.8', '<')) {
    Hooks::filter('btcbi_teams_for_wc_memberships_add_member', [TeamsForWooCommerceMembershipsProHelper::class, 'addMemberToTeam'], 10, 3);
    Hooks::filter('btcbi_teams_for_wc_memberships_remove_member', [TeamsForWooCommerceMembershipsProHelper::class, 'removeMemberFromTeam'], 10, 3);
    Hooks::filter('btcbi_teams_for_wc_memberships_invite_user', [TeamsForWooCommerceMembershipsProHelper::class, 'inviteUserToTeam'], 10, 3);
    Hooks::filter('btcbi_teams_for_wc_memberships_update_role', [TeamsForWooCommerceMembershipsProHelper::class, 'updateMemberRole'], 10, 3);
}

// New hooks since v2.7.8
Hooks::filter(Config::withFreePrefix('teams_for_wc_memberships_add_member'), [TeamsForWooCommerceMembershipsProHelper::class, 'addMemberToTeam'], 10, 3);
Hooks::filter(Config::withFreePrefix('teams_for_wc_memberships_remove_member'), [TeamsForWooCommerceMembershipsProHelper::class, 'removeMemberFromTeam'], 10, 3);
Hooks::filter(Config::withFreePrefix('teams_for_wc_memberships_invite_user'), [TeamsForWooCommerceMembershipsProHelper::class, 'inviteUserToTeam'], 10, 3);
Hooks::filter(Config::withFreePrefix('teams_for_wc_memberships_update_role'), [TeamsForWooCommerceMembershipsProHelper::class, 'updateMemberRole'], 10, 3);

