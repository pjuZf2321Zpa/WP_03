<?php

namespace MasterStudy\Lms\Pro\addons\google_classrooms\Admin\Http\Controllers;

use MasterStudy\Lms\Http\WpResponseFactory;
use MasterStudy\Lms\Pro\addons\google_classrooms\Admin\Repositories\ClassroomsRepository;
use RuntimeException;
use WP_REST_Request;
use WP_REST_Response;

final class DeleteClassroomController {
	public function __invoke( int $id, WP_REST_Request $request ): WP_REST_Response {
		$repository = new ClassroomsRepository();

		if ( ! $repository->exists( $id ) ) {
			return WpResponseFactory::not_found();
		}

		try {
			$repository->delete( $id );
		} catch ( RuntimeException $e ) {
			if ( 403 === $e->getCode() ) {
				return WpResponseFactory::forbidden();
			}

			return WpResponseFactory::bad_request( $e->getMessage() );
		}

		return WpResponseFactory::ok();
	}
}
