<?php

namespace FluentCartPro\App\Http\Requests;

use FluentCart\App\Helpers\Helper;
use FluentCart\App\Services\DateTime\DateTime;
use FluentCart\Framework\Foundation\RequestGuard;
use FluentCart\Framework\Support\Arr;
use FluentCartPro\App\Modules\DynamicPricing\Conditions\ConditionRegistry;
use FluentCartPro\App\Modules\DynamicPricing\Conditions\Options\PaymentMethodOptions;
use FluentCartPro\App\Modules\DynamicPricing\Conditions\Options\SlugOptionSource;
use FluentCartPro\App\Modules\DynamicPricing\Conditions\Options\UserRoleOptions;
use FluentCartPro\App\Modules\DynamicPricing\Models\PricingRule;

class PricingRuleRequest extends RequestGuard
{
    const APPLY_AS = ['percentage', 'fixed'];

    // What DynamicPricingService::shouldApplyRule() understands.
    const WHEN_TO_APPLY = ['every', 'first', 'upgrades', 'renewals'];

    // A fixed amount becomes cents (x100), and Helper::roundCent() refuses
    // anything past 9.0e15 cents. Larger values overflow and adjust nothing.
    const MAX_AMOUNT = 9.0e13;

    /**
     * @var PricingRule|null|false False until looked up.
     */
    protected $storedRule = false;

    /**
     * @return array
     */
    public function rules()
    {
        $required = $this->presenceRule();

        return [
            'name'         => $required . '|sanitizeText|maxLength:191',
            'display_name' => $required . '|sanitizeText|maxLength:191',
            'rule_type'    => $required . '|sanitizeText|maxLength:50',
            'price_type'   => 'nullable|sanitizeText|in:discount,fee',
            'applies_to'   => $required . '|sanitizeText|in:checkout,line_item,shipping',
            'config'       => 'nullable|array',
            'config.amount' => [
                function ($attribute, $value, $rules, $data) {
                    return $this->amountError($value, (array)$data);
                },
            ],
            'config.apply_as' => [
                function ($attribute, $value, $rules, $data) {
                    if (!$this->configHas((array)$data, 'apply_as') || in_array($value, static::APPLY_AS, true)) {
                        return null;
                    }

                    return esc_html__('Apply as must be either percentage or fixed.', 'fluent-cart-pro');
                },
            ],
            'config.when_to_apply' => [
                function ($attribute, $value, $rules, $data) {
                    return $this->whenToApplyError($value, (array)$data);
                },
            ],
            'start_date'   => [
                'required_with:end_date',
                function ($attribute, $value, $rules, $data) {
                    return $this->dateError($value, esc_html__('The start date must be a valid date.', 'fluent-cart-pro'))
                        ?: $this->storedEndError($value, (array)$data);
                },
            ],
            'end_date'     => [
                'nullable',
                function ($attribute, $value) {
                    $error = $this->dateError($value, esc_html__('The end date must be a valid date.', 'fluent-cart-pro'));

                    if ($error || $value === null || $value === '') {
                        return $error;
                    }

                    $startTime = $this->scheduleTimestamp($this->get('start_date'));
                    $endTime = $this->scheduleTimestamp($value);

                    if ($startTime !== null && $endTime !== null && $endTime <= $startTime) {
                        return esc_html__('The end date must be after the start date.', 'fluent-cart-pro');
                    }

                    return null;
                },
            ],
        ];
    }

    /**
     * Whether a submitted date is unusable.
     *
     * Empty is a rule with no schedule, which is allowed. Anything else has to
     * actually parse: strtotime() answers false for garbage, and an unparsed
     * string reaching DateTime::anyTimeToGmt() throws an exception carrying the
     * absolute path of the file it threw from.
     *
     * Compared with === false rather than tested for truth, because a valid
     * pre-1970 date is a negative timestamp and 1970-01-01 itself is 0.
     *
     * @param mixed $value
     * @param string $message
     * @return string|null Null when there is nothing wrong.
     */
    protected function dateError($value, $message)
    {
        if ($value === null || $value === '') {
            return null;
        }

        // Parsing and fitting the column are separate questions. "0001-01-01"
        // parses perfectly and cannot be stored, so a value that clears the
        // first check can still fail the second — and refusing it here is the
        // only place it can be refused honestly. Sanitizing it away would turn
        // a schedule the merchant set into no schedule at all, which the
        // schema reads as "always on".
        if (!is_string($value) || $this->scheduleGmt($value) === null) {
            return $message;
        }

        return null;
    }

    /**
     * A submitted date as the GMT moment the column will hold.
     *
     * The single reading of an incoming date. Validation and sanitizing both
     * come through here, so they cannot disagree about what a value means or
     * about whether it is usable at all.
     *
     * @param mixed $value
     * @return \FluentCart\App\Services\DateTime\DateTime|null Null when there
     *         is no date, none that parses, or none the column can hold.
     */
    protected function scheduleGmt($value)
    {
        if (!is_string($value) || trim($value) === '') {
            return null;
        }

        $value = trim($value);

        // anyTimeToGmt() throws on a string it cannot read, and its exception
        // carries the absolute path of the file it threw from.
        if (strtotime($value) === false) {
            return null;
        }

        $gmt = DateTime::anyTimeToGmt($value, wp_timezone_string());

        // MySQL DATETIME runs from 1000-01-01 to 9999-12-31. Outside that the
        // write either errors or lands as a zero date, depending on SQL mode —
        // so the row would disagree with the request that was accepted.
        $year = (int)$gmt->format('Y');

        if ($year < 1000 || $year > 9999) {
            return null;
        }

        return $gmt;
    }

    /**
     * The moment a submitted date names, as a GMT timestamp.
     *
     * @param mixed $value
     * @return int|null Null when the date is unusable.
     */
    protected function scheduleTimestamp($value)
    {
        $gmt = $this->scheduleGmt($value);

        return $gmt ? $gmt->getTimestamp() : null;
    }

    /**
     * Whether a request with no config at all still needs an amount.
     *
     * False for an update, so one that leaves config out is not refused for it.
     * CreatePricingRuleRequest says yes: a new rule with no amount does nothing.
     *
     * @return bool
     */
    protected function requiresConfig()
    {
        return false;
    }

    /**
     * An update may leave a field out to keep its stored value, so it is only
     * refused when it is sent empty.
     *
     * @return string
     */
    protected function presenceRule()
    {
        return 'sometimes|required';
    }

    /**
     * The sanitized fields this request sent, for an update.
     *
     * getSafe() returns every sanitize() key, with null for one not sent, and
     * that null would erase the stored value. A sent config is laid over the
     * stored one, so a config key left out is kept too.
     *
     * @return array
     */
    public function sentData()
    {
        $data = array_intersect_key($this->getSafe($this->sanitize()), (array)$this->all());

        if (isset($data['config']) && is_array($data['config'])) {
            $data['config'] = array_merge($this->storedConfig(), $data['config']);
        }

        return $data;
    }

    /**
     * The rule an update targets. Read by the route id, not the body.
     *
     * @return PricingRule|null Null on create.
     */
    protected function storedRule()
    {
        if ($this->storedRule === false) {
            $id = absint(Arr::get((array)$this->get_url_params(), 'id'));

            $this->storedRule = $id ? PricingRule::query()->find($id) : null;
        }

        return $this->storedRule;
    }

    /**
     * @return array
     */
    protected function storedConfig()
    {
        $rule = $this->storedRule();

        return $rule && is_array($rule->config) ? $rule->config : [];
    }

    /**
     * The request laid over the stored rule, so the checks that compare
     * fields see what will be saved when an update leaves some out.
     *
     * @param array $data
     * @return array
     */
    protected function withStoredRule(array $data)
    {
        $rule = $this->storedRule();

        if (!$rule) {
            return $data;
        }

        $data += [
            'price_type' => $rule->price_type,
            'applies_to' => $rule->applies_to,
        ];

        if (!array_key_exists('config', $data)) {
            $data['config'] = $this->storedConfig();
        } elseif (is_array($data['config'])) {
            $data['config'] = array_merge($this->storedConfig(), $data['config']);
        }

        return $data;
    }

    /**
     * A new start date against the stored end, when the update leaves the end out.
     *
     * @param mixed $value
     * @param array $data
     * @return string|null
     */
    protected function storedEndError($value, array $data)
    {
        if (array_key_exists('end_date', $data) || $value === null || $value === '') {
            return null;
        }

        $rule = $this->storedRule();
        $storedEnd = $rule ? Arr::get($rule->getAttributes(), 'end_date') : null;

        if (!$storedEnd) {
            return null;
        }

        // The column holds GMT.
        $endTime = strtotime($storedEnd . ' UTC');
        $startTime = $this->scheduleTimestamp($value);

        if ($startTime !== null && $endTime !== false && $endTime <= $startTime) {
            return esc_html__('The start date must be before the end date.', 'fluent-cart-pro');
        }

        return null;
    }

    /**
     * @param array $data
     * @param string $key
     * @return bool
     */
    protected function configHas(array $data, $key)
    {
        return isset($data['config']) && is_array($data['config']) && array_key_exists($key, $data['config']);
    }

    /**
     * @param mixed $value
     * @param array $data
     * @return string|null Null when the amount is usable.
     */
    protected function amountError($value, array $data)
    {
        // On update only a sent config or price type changes what the amount means.
        if (!array_key_exists('config', $data) && !array_key_exists('price_type', $data) && !$this->requiresConfig()) {
            return null;
        }

        $data = $this->withStoredRule($data);
        $value = Arr::get($data, 'config.amount');

        if ($value === null || $value === '') {
            return esc_html__('Please enter an amount.', 'fluent-cart-pro');
        }

        // is_numeric() accepts INF from a JSON 1e400.
        if (!is_numeric($value) || !is_finite((float)$value)) {
            return esc_html__('The amount must be a number.', 'fluent-cart-pro');
        }

        $amount = (float)$value;

        if ($amount <= 0) {
            return esc_html__('The amount must be greater than zero.', 'fluent-cart-pro');
        }

        // Missing apply_as and price_type default to percentage and discount.
        $isPercentage = Arr::get($data, 'config.apply_as') !== 'fixed';
        $isDiscount = Arr::get($data, 'price_type') !== 'fee';

        if ($isPercentage && $isDiscount && $amount > 100) {
            return esc_html__('A percentage discount cannot be more than 100.', 'fluent-cart-pro');
        }

        if ($amount > static::MAX_AMOUNT) {
            return esc_html__('The amount is too large.', 'fluent-cart-pro');
        }

        return null;
    }

    /**
     * Absent means every purchase. A value that is sent has to be one the
     * engine knows, or the rule never fires while the page says it does.
     *
     * @param mixed $value
     * @param array $data
     * @return string|null
     */
    protected function whenToApplyError($value, array $data)
    {
        $sent = $this->configHas($data, 'when_to_apply');

        if ($sent && !in_array($value, static::WHEN_TO_APPLY, true)) {
            return esc_html__('When to apply must be every purchase, first purchase, upgrades or renewals.', 'fluent-cart-pro');
        }

        // An update that touches none of the three keeps a combination already stored.
        if (!$sent && !array_key_exists('price_type', $data) && !array_key_exists('applies_to', $data)) {
            return null;
        }

        $data = $this->withStoredRule($data);

        if (Arr::get($data, 'config.when_to_apply') !== 'renewals') {
            return null;
        }

        // RenewalDiscountApplier keeps only discounts and prices the invoice
        // with no shipping, so these combinations would never apply.
        if (Arr::get($data, 'price_type') === 'fee') {
            return esc_html__('A store managed renewals rule can only be a discount.', 'fluent-cart-pro');
        }

        if (Arr::get($data, 'applies_to') === 'shipping') {
            return esc_html__('A store managed renewals rule cannot apply to shipping.', 'fluent-cart-pro');
        }

        return null;
    }

    /**
     * @return array
     */
    public function messages()
    {
        return [
            'name.required'         => esc_html__('Name is required.', 'fluent-cart-pro'),
            'display_name.required' => esc_html__('Display Name is required.', 'fluent-cart-pro'),
            'rule_type.required'    => esc_html__('Please select a template to start from.', 'fluent-cart-pro'),
            'price_type.in'         => esc_html__('Price type must be either discount or fee.', 'fluent-cart-pro'),
            'applies_to.required'   => esc_html__('Please select where this rule applies to.', 'fluent-cart-pro'),
            'applies_to.in'         => esc_html__('Applies to must be checkout, line item or shipping.', 'fluent-cart-pro'),
            'start_date.required_with' => esc_html__('A start date is required when an end date is set.', 'fluent-cart-pro'),
        ];
    }

    /**
     * @return array
     */
    public function sanitize()
    {
        return [
            'name'         => 'sanitize_text_field',
            'display_name' => 'sanitize_text_field',
            'rule_type'    => 'sanitize_text_field',
            'price_type'   => function ($value) {
                return $this->allowedValue($value, ['discount', 'fee']);
            },
            'applies_to'   => function ($value) {
                return $this->allowedValue($value, ['checkout', 'line_item', 'shipping']);
            },
            'config'       => function ($value) {
                return $this->sanitizeConfig($value);
            },
            'start_date'   => function ($value) {
                return $this->sanitizeScheduleDate($value);
            },
            'end_date'     => function ($value) {
                return $this->sanitizeScheduleDate($value);
            },
        ];
    }

    /**
     * Store a scheduled date the way the column holds it.
     *
     * The merchant picks a time in the store's timezone and the column is GMT,
     * which is what eligibleRules() compares against. Without this conversion a
     * sale set for 9am starts at 3am in a UTC+6 store, and the admin screen
     * still shows 9am — so the mistake is invisible from the inside.
     *
     * An empty value is a rule with no schedule, and null is what the schema
     * reads as "from now" / "never".
     *
     * @param mixed $value
     * @return string|null
     */
    protected function sanitizeScheduleDate($value)
    {
        if (!is_string($value)) {
            return null;
        }

        /*
         * scheduleGmt() decides what the value means, and rules() has already
         * refused anything it cannot read — so by here this only turns an
         * accepted date into the string the column takes. The checks inside it
         * still matter, because a sanitizer must not throw or return an
         * unstorable value if it is ever reached on its own.
         *
         * The store's timezone applies only when the value carries no offset:
         * a bare "2026-08-28 00:00:00" is the merchant's midnight rather than
         * GMT midnight, and read as GMT it would open a sale hours early.
         */
        $gmt = $this->scheduleGmt(sanitize_text_field($value));

        return $gmt ? $gmt->format('Y-m-d H:i:s') : null;
    }

    /**
     * Sanitize the rule configuration and its conditions.
     *
     * @param mixed $value
     * @return array
     */
    protected function sanitizeConfig($value): array
    {
        if (!is_array($value)) {
            return [];
        }

        if (array_key_exists('conditions', $value)) {
            $value['conditions'] = $this->sanitizeConditions($value['conditions']);
        }

        if (array_key_exists('fee_taxable', $value)) {
            $value['fee_taxable'] = $value['fee_taxable'] === 'no' ? 'no' : 'yes';
        }

        if (array_key_exists('apply_as', $value)) {
            $value['apply_as'] = $this->allowedValue($value['apply_as'], static::APPLY_AS);
        }

        if (array_key_exists('when_to_apply', $value)) {
            $value['when_to_apply'] = $this->allowedValue($value['when_to_apply'], static::WHEN_TO_APPLY);
        }

        if (array_key_exists('amount', $value) && !is_numeric($value['amount'])) {
            $value['amount'] = '';
        }

        return $value;
    }

    /**
     * Sanitize first, then hold the result against a closed set. Returns null
     * for anything outside it, so a value rules() already rejected cannot reach
     * the column through a second path.
     *
     * @param mixed $value
     * @param array $allowed
     * @return string|null
     */
    protected function allowedValue($value, array $allowed)
    {
        if (is_null($value)) {
            return null;
        }

        $value = sanitize_text_field((string)$value);

        return in_array($value, $allowed, true) ? $value : null;
    }

    /**
     * Conditions arrive as groups of rows — the outer array is ORed, each inner
     * array is ANDed. Rows the registry does not recognise are dropped rather
     * than rejected, so one stale row from a deactivated add-on cannot lock an
     * administrator out of editing the rest of the rule.
     *
     * @param mixed $conditions
     * @return array
     */
    protected function sanitizeConditions($conditions): array
    {
        if (!is_array($conditions)) {
            return [];
        }

        $sanitized = [];

        // Limit the number of condition groups to prevent oversized browser input.
        $groups = array_slice($conditions, 0, ConditionRegistry::MAX_SELECT_VALUES);

        foreach ($groups as $group) {
            if (!is_array($group)) {
                continue;
            }

            $sanitizedGroup = [];

            // Limit conditions per group for the same input-size protection.
            foreach (array_slice($group, 0, ConditionRegistry::MAX_SELECT_VALUES) as $condition) {
                $condition = $this->sanitizeCondition($condition);

                if ($condition) {
                    $sanitizedGroup[] = $condition;
                }
            }

            // An emptied group would OR against nothing, so drop it entirely.
            if ($sanitizedGroup) {
                $sanitized[] = $sanitizedGroup;
            }
        }

        return $sanitized;
    }

    /**
     * @param mixed $condition
     * @return array|null
     */
    protected function sanitizeCondition($condition)
    {
        if (!is_array($condition)) {
            return null;
        }

        $key = sanitize_text_field((string)Arr::get($condition, 'key', ''));
        $operator = sanitize_text_field((string)Arr::get($condition, 'operator', ''));

        // Covers three cases at once: an unregistered attribute, an operator
        // that exists but not for this attribute, and a half-filled row whose
        // attribute or operator was never chosen.
        if (!ConditionRegistry::hasOperator($key, $operator)) {
            return null;
        }

        $value = $this->sanitizeConditionValue(Arr::get($condition, 'value', ''), $key);

        // Every current operator needs something to compare against. Checked
        // with a strict comparison so a legitimate "0" survives.
        if ($value === '' || $value === null || $value === []) {
            return null;
        }

        return [
            'key'      => $key,
            'operator' => $operator,
            'value'    => $value,
        ];
    }

    /**
     * @param mixed $value
     * @param string $key
     * @return mixed
     */
    protected function sanitizeConditionValue($value, $key)
    {
        $inputType = ConditionRegistry::inputType($key);

        if ($inputType === 'select') {
            return $this->sanitizeSelectValue($value, $key);
        }

        if ($inputType === 'currency') {
            return $this->sanitizeCurrencyValue($value);
        }

        if ($inputType === 'number') {
            return $this->sanitizeNumberValue($value);
        }

        if (is_array($value)) {
            return $this->sanitizeArrayValue($value);
        }

        if (!is_scalar($value)) {
            return '';
        }

        return sanitize_text_field((string)$value);
    }

    /**
     * Sanitize select values into valid, unique IDs.
     *
     * Multi-select fields return all valid IDs, while single-select fields
     * return only the first valid ID.
     *
     * @param mixed $value
     * @param string $key
     * @return array|int|string
     */
    protected function sanitizeSelectValue($value, $key)
    {
        // Roles and payment methods are picked by slug. intval('subscriber')
        // is 0, so the id handling below would throw the whole row away.
        $slugSource = $this->slugSource($key);

        if ($slugSource) {
            return $this->sanitizeSlugValue($value, $key, $slugSource);
        }

        $ids = [];

        // Limit the incoming values before sanitizing them so a browser-supplied
        // list cannot trigger unnecessary processing beyond the allowed maximum.
        $requested = array_slice((array)$value, 0, ConditionRegistry::MAX_SELECT_VALUES);

        foreach ($requested as $id) {
            $id = is_scalar($id) ? intval($id) : 0;

            if ($id > 0 && !in_array($id, $ids, true)) {
                $ids[] = $id;
            }
        }

        if (!$ids) {
            return '';
        }

        return ConditionRegistry::isMultiple($key) ? $ids : $ids[0];
    }

    /**
     * The slug source this attribute's options come from, if any.
     *
     * Asked of the attribute's `data_key` rather than its own key, so the check
     * follows wherever the attribute is registered and whatever it is called.
     *
     * @param string $key
     * @return SlugOptionSource|null
     */
    protected function slugSource($key)
    {
        $dataKey = Arr::get(ConditionRegistry::get($key) ?: [], 'data_key');

        if (!$dataKey) {
            return null;
        }

        foreach ([new UserRoleOptions(), new PaymentMethodOptions()] as $source) {
            if ($source->key() === $dataKey) {
                return $source;
            }
        }

        return null;
    }

    /**
     * Sanitize and validate slugs against what the source can offer.
     *
     * Removes invalid or duplicate slugs and returns all valid ones for
     * multi-select fields, or the first valid one for single-select fields.
     *
     * @param mixed $value
     * @param string $key
     * @param SlugOptionSource $source
     * @return array|string
     */
    protected function sanitizeSlugValue($value, $key, SlugOptionSource $source)
    {
        $available = $source->available();
        $slugs = [];

        $requested = array_slice((array)$value, 0, ConditionRegistry::MAX_SELECT_VALUES);

        foreach ($requested as $slug) {
            $slug = is_scalar($slug) ? sanitize_key((string)$slug) : '';

            if ($slug !== '' && isset($available[$slug]) && !in_array($slug, $slugs, true)) {
                $slugs[] = $slug;
            }
        }

        if (!$slugs) {
            return '';
        }

        return ConditionRegistry::isMultiple($key) ? $slugs : $slugs[0];
    }

    /**
     * Sanitize and normalize a currency value before storing it in the rule.
     *
     * The value must be numeric, finite, non-negative, and within the maximum
     * range supported by `roundCent()`. Valid values are then normalized through
     * the currency helper so they are stored using the expected cent-based format.
     *
     * For example, `100.50` is accepted and normalized, while values such as
     * `-10`, `1e400`, or amounts beyond the supported range are rejected.
     *
     * @param mixed $value
     * @return int|float|string
    */
    protected function sanitizeCurrencyValue($value)
    {
        if (!is_numeric($value)) {
            return '';
        }

        $amount = $value + 0;

        // Reject non-finite, negative, or out-of-range currency values.
        if (!is_finite($amount) || $amount < 0 || $amount > 9.0e15) {
            return '';
        }

        return Helper::roundCent($amount);
    }

    /**
     * Sanitize and validate a numeric condition value.
     *
     * @param mixed $value
     * @return int|float|string
     */
    protected function sanitizeNumberValue($value)
    {
        if (!is_numeric($value)) {
            return '';
        }

        // `+ 0` rather than a float cast: it leaves an integer string an int,
        // where casting would round anything past 2^53. Add-ons register their
        // own numeric attributes through the registry filter, and one holding
        // 64-bit ids or counters would otherwise be quietly altered on save.
        $number = $value + 0;

        // is_numeric() accepts '1e400', which overflows to INF. json_encode()
        // returns false for INF, so the model's config mutator would store an
        // empty string and silently wipe every other setting on the rule.
        return is_finite($number) ? $number : '';
    }

    /**
     * Sanitize scalar values inside an array.
     *
     * @param mixed $value
     * @return array
     */
    protected function sanitizeArrayValue($value)
    {
        // Limit the incoming array before sanitizing to prevent oversized browser input.
        $requested = array_slice((array)$value, 0, ConditionRegistry::MAX_SELECT_VALUES);

        return array_values(
            array_map(
                'sanitize_text_field',
                array_filter($requested, 'is_scalar')
            )
        );
    }

}
