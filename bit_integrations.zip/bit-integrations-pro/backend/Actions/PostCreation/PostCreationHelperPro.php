<?php

namespace BitApps\IntegrationsPro\Actions\PostCreation;

use Throwable;

class PostCreationHelperPro
{
    public static function addPostTags($postId, $tags = null)
    {
        if (empty($tags)) {
            return;
        }

        if (\is_array($tags)) {
            $tags = array_filter(array_map('trim', $tags));
        } else {
            $tags = explode(',', str_replace(', ', ',', $tags));
        }

        wp_add_post_tags($postId, $tags);
    }

    public static function updateExistingPost($defaultResponse, $fieldData)
    {
        $postId = $fieldData['post_id'] ?? null;

        if (empty($postId)) {
            return self::error(__('Post id is required', 'bit-integrations-pro'));
        }

        $fieldData['ID'] = $postId;
        unset($fieldData['post_id']);

        $featuredImageUrl = $fieldData['featured_image_url'] ?? null;
        unset($fieldData['featured_image_url']);

        $updatedId = wp_update_post($fieldData, true);

        if (is_wp_error($updatedId)) {
            return self::error($updatedId->get_error_message());
        }

        $result = self::setFeaturedImageFromUrl($updatedId, $featuredImageUrl);

        if (!$result['success']) {
            return self::error($result['message']);
        }

        return self::success((array) get_post($updatedId));
    }

    public static function updatePostStatus($defaultResponse, $fieldData)
    {
        $postId = $fieldData['post_id'] ?? null;
        $postStatus = $fieldData['post_status'] ?? null;

        if (empty($postId)) {
            return self::error(__('Post id is required', 'bit-integrations-pro'));
        }

        if (empty($postStatus)) {
            return self::error(__('Post status is required', 'bit-integrations-pro'));
        }

        $updatedId = wp_update_post(['ID' => $postId, 'post_status' => $postStatus], true);

        if (is_wp_error($updatedId)) {
            return self::error($updatedId->get_error_message());
        }

        return self::success((array) get_post($updatedId));
    }

    public static function deleteExistingPost($defaultResponse, $fieldData)
    {
        $postId = $fieldData['post_id'] ?? null;
        $forceDelete = self::toBool($fieldData['force_delete'] ?? false);

        if (empty($postId)) {
            return self::error(__('Post id is required', 'bit-integrations-pro'));
        }

        $result = wp_delete_post($postId, $forceDelete);

        if (!$result) {
            return self::error(__('Failed to delete post', 'bit-integrations-pro'));
        }

        return self::success(__('Post deleted successfully', 'bit-integrations-pro'));
    }

    public static function createNewComment($defaultResponse, $fieldData)
    {
        return self::createComment($fieldData);
    }

    public static function replyToComment($defaultResponse, $fieldData)
    {
        if (empty($fieldData['comment_post_ID'])) {
            return self::error(__('Post id is required', 'bit-integrations-pro'));
        }

        if (empty($fieldData['comment_parent'])) {
            return self::error(__('Parent comment id is required', 'bit-integrations-pro'));
        }

        if (get_post($fieldData['comment_post_ID']) === null) {
            return self::error(__('Post does not exist', 'bit-integrations-pro'));
        }

        if (get_comment($fieldData['comment_parent']) === null) {
            return self::error(__('Parent comment does not exist', 'bit-integrations-pro'));
        }

        return self::createComment($fieldData);
    }

    public static function deleteExistingComment($defaultResponse, $fieldData)
    {
        if (empty($fieldData['comment_id'])) {
            return self::error(__('Comment id is required', 'bit-integrations-pro'));
        }

        $forceDelete = self::toBool($fieldData['force_delete'] ?? false);
        $status = wp_delete_comment($fieldData['comment_id'], $forceDelete);

        if (!$status) {
            return self::error(__('Failed to delete comment', 'bit-integrations-pro'));
        }

        return self::success(__('Comment deleted successfully', 'bit-integrations-pro'));
    }

    private static function success($data)
    {
        return ['success' => true, 'message' => $data];
    }

    private static function error($message)
    {
        return ['success' => false, 'message' => $message];
    }

    private static function setFeaturedImageFromUrl($postId, $url = null)
    {
        if (empty($url)) {
            return self::success(null);
        }

        $validatedUrl = wp_http_validate_url($url);

        if (false === $validatedUrl) {
            return self::error(__('Invalid or unsafe featured image URL', 'bit-integrations-pro'));
        }

        self::loadMediaIncludes();

        try {
            $attachmentId = media_sideload_image($validatedUrl, $postId, null, 'id');

            if (is_wp_error($attachmentId)) {
                return self::error($attachmentId->get_error_message());
            }

            if (wp_attachment_is_image($attachmentId)) {
                set_post_thumbnail($postId, $attachmentId);

                return self::success($attachmentId);
            }
        } catch (Throwable $th) {
            return self::error(__('Failed to set featured image from URL: ', 'bit-integrations-pro') . $th->getMessage());
        }

        return self::error(__('Featured image URL did not return a valid image attachment', 'bit-integrations-pro'));
    }

    private static function createComment($fieldData)
    {
        if (empty($fieldData['comment_content'])) {
            return self::error(__('Comment is required', 'bit-integrations-pro'));
        }
        if (empty($fieldData['comment_post_ID'])) {
            return self::error(__('Post id is required', 'bit-integrations-pro'));
        }

        if (get_post($fieldData['comment_post_ID']) === null) {
            return self::error(__('Post does not exist', 'bit-integrations-pro'));
        }

        $fieldData['comment_type'] = 'comment';
        $fieldData['comment_status'] = 'approved';
        $fieldData['comment_approved'] = 1;

        $commentId = wp_new_comment($fieldData, true);

        if (is_wp_error($commentId)) {
            return self::error($commentId->get_error_message());
        }

        return self::success((array) get_comment($commentId));
    }

    private static function loadMediaIncludes()
    {
        if (!\function_exists('media_sideload_image')) {
            include_once ABSPATH . 'wp-admin/includes/media.php';
        }

        if (!\function_exists('download_url')) {
            include_once ABSPATH . 'wp-admin/includes/file.php';
        }

        if (!\function_exists('wp_generate_attachment_metadata')) {
            include_once ABSPATH . 'wp-admin/includes/image.php';
        }
    }

    private static function toBool($value)
    {
        if (\is_bool($value)) {
            return $value;
        }

        return \in_array(strtolower((string) $value), ['1', 'true', 'yes', 'on'], true);
    }
}
