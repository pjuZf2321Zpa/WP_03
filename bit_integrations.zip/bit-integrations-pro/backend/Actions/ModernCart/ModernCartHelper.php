<?php

namespace BitApps\IntegrationsPro\Actions\ModernCart;

use WC_Product;

if (!defined('ABSPATH')) {
    exit;
}

final class ModernCartHelper
{
    private static $cartUpdatedTriggerSuspended = 0;

    public static function isPluginInstalled()
    {
        return \defined('MODERNCART_VER') || class_exists('\ModernCart\Plugin_Loader');
    }

    public static function suspendCartUpdatedTrigger()
    {
        ++self::$cartUpdatedTriggerSuspended;
    }

    public static function resumeCartUpdatedTrigger()
    {
        self::$cartUpdatedTriggerSuspended = max(0, self::$cartUpdatedTriggerSuspended - 1);
    }

    public static function isCartUpdatedTriggerSuspended()
    {
        return self::$cartUpdatedTriggerSuspended > 0;
    }

    public static function isWooCommerceAvailable()
    {
        if (!\function_exists('WC')) {
            return false;
        }

        $wooCommerce = WC();

        if ($wooCommerce && empty($wooCommerce->cart) && \function_exists('wc_load_cart')) {
            wc_load_cart();
        }

        return $wooCommerce && !empty($wooCommerce->cart);
    }

    public static function getProductData($product)
    {
        if (is_numeric($product)) {
            $product = \function_exists('wc_get_product') ? wc_get_product((int) $product) : null;
        }

        if (!$product instanceof WC_Product) {
            return [];
        }

        return [
            'id'             => $product->get_id(),
            'name'           => $product->get_name(),
            'slug'           => $product->get_slug(),
            'type'           => $product->get_type(),
            'status'         => $product->get_status(),
            'sku'            => $product->get_sku(),
            'price'          => $product->get_price(),
            'regular_price'  => $product->get_regular_price(),
            'sale_price'     => $product->get_sale_price(),
            'stock_status'   => $product->get_stock_status(),
            'stock_quantity' => $product->get_stock_quantity(),
            'permalink'      => $product->get_permalink(),
        ];
    }

    public static function getCartItems($cart = null)
    {
        if (!$cart && !self::isWooCommerceAvailable()) {
            return [];
        }

        $cart = $cart ?: WC()->cart;
        $items = [];

        foreach ($cart->get_cart() as $cartItemKey => $cartItem) {
            $items[] = self::getCartItemData((string) $cartItemKey, $cartItem);
        }

        return $items;
    }

    public static function getCartItemData($cartItemKey, $cartItem)
    {
        $product = $cartItem['data'] ?? null;

        return [
            'cart_item_key' => $cartItemKey,
            'product_id'    => isset($cartItem['product_id']) ? (int) $cartItem['product_id'] : 0,
            'variation_id'  => isset($cartItem['variation_id']) ? (int) $cartItem['variation_id'] : 0,
            'quantity'      => isset($cartItem['quantity']) ? (int) $cartItem['quantity'] : 0,
            'line_subtotal' => isset($cartItem['line_subtotal']) ? (float) $cartItem['line_subtotal'] : 0,
            'line_total'    => isset($cartItem['line_total']) ? (float) $cartItem['line_total'] : 0,
            'product_name'  => $product instanceof WC_Product ? $product->get_name() : '',
            'product'       => self::getProductData($product),
        ];
    }

    public static function getCartItem($cartItemKey, $cart = null)
    {
        if (!$cart && !self::isWooCommerceAvailable()) {
            return [];
        }

        $cart = $cart ?: WC()->cart;
        $cartContents = $cart->get_cart();
        $cartItemKey = (string) $cartItemKey;

        return isset($cartContents[$cartItemKey]) ? $cartContents[$cartItemKey] : [];
    }

    public static function findCartItemKey($productId, $variationId = 0, $cart = null)
    {
        if (empty($productId) || (!$cart && !self::isWooCommerceAvailable())) {
            return '';
        }

        $cart = $cart ?: WC()->cart;

        foreach ($cart->get_cart() as $cartItemKey => $cartItem) {
            if ((int) ($cartItem['product_id'] ?? 0) !== (int) $productId) {
                continue;
            }

            if (!empty($variationId) && (int) ($cartItem['variation_id'] ?? 0) !== (int) $variationId) {
                continue;
            }

            return (string) $cartItemKey;
        }

        return '';
    }

    public static function getCartTotals($cart = null)
    {
        if (!$cart && !self::isWooCommerceAvailable()) {
            return [];
        }

        $cart = $cart ?: WC()->cart;

        return [
            'subtotal'        => (float) $cart->get_displayed_subtotal(),
            'discount_total'  => (float) $cart->get_discount_total(),
            'shipping_total'  => (float) $cart->get_shipping_total(),
            'tax_total'       => (float) $cart->get_taxes_total(false, false),
            'grand_total'     => (float) $cart->get_total('number'),
            'currency'        => get_woocommerce_currency(),
            'currency_symbol' => get_woocommerce_currency_symbol(),
        ];
    }

    public static function decodeJson($value, $fallback = [])
    {
        if (\is_array($value)) {
            return $value;
        }

        if (!\is_string($value) || trim($value) === '') {
            return $fallback;
        }

        $decoded = json_decode(wp_unslash($value), true);

        return \is_array($decoded) ? $decoded : $fallback;
    }

    public static function flagCartSession()
    {
        if (class_exists('\ModernCart\Inc\Order_Tracking')) {
            \ModernCart\Inc\Order_Tracking::flag_session();
        }
    }
}
