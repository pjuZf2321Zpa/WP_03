<?php
if (!defined('ABSPATH')) {
    die('You are not allowed to call this page directly.');
}

// First-time installs ship with the cart on; upgrading installs keep their current setting.
// Disabling is locked once cart orders exist (MeprOptions::can_disable_cart()).
$mepr_cart_enabled = MeprOptions::cart_enabled();
$mepr_cart_locked  = $mepr_cart_enabled && !MeprOptions::can_disable_cart();
?>
<section id="mepr-section-cart">
  <h3><?php esc_html_e('Shopping Cart - Beta', 'memberpress'); ?></h3>
  <table class="form-table">
    <tbody>
      <tr id="mepr-option-cart-enabled" valign="top">
        <th scope="row">
          <label for="<?php echo esc_attr($mepr_options->cart_enabled_str); ?>"><?php esc_html_e('Enable Cart', 'memberpress'); ?></label>
          <?php MeprAppHelper::info_tooltip(
              'mepr-cart-enabled',
              __('Enable Shopping Cart', 'memberpress'),
              __('Turns on the shop, multi-item cart, and cart checkout. Standalone registration pages keep working either way: with the cart on, each product can still use its own registration page; with the cart off, signup stays standalone (individual signup pages).', 'memberpress')
          ); ?>
        </th>
        <td>
          <input type="checkbox"
                 id="<?php echo esc_attr($mepr_options->cart_enabled_str); ?>"
                 name="<?php echo esc_attr($mepr_options->cart_enabled_str); ?>"
                 value="1"
                 <?php checked($mepr_cart_enabled); ?>
                 <?php disabled($mepr_cart_locked); ?> />
          <?php if ($mepr_cart_locked) : ?>
          <p class="description mepr-cart-lock-note"><?php esc_html_e('Cannot be disabled — cart orders already exist.', 'memberpress'); ?></p>
          <?php endif; ?>
        </td>
      </tr>
    </tbody>
  </table>

  <?php if (!$mepr_cart_enabled) : ?>
  <div class="mepr_modal" id="mepr-cart-enable-modal" role="dialog" aria-modal="true" aria-labelledby="mepr-cart-enable-modal-title" style="display: none;">
    <div class="mepr_modal__overlay"></div>
    <div class="mepr_modal__content_wrapper">
      <div class="mepr_modal__content">
        <div class="mepr_modal__box">
          <button type="button" class="mepr_modal__close">&#x2715;</button>
          <h3 id="mepr-cart-enable-modal-title"><?php esc_html_e('Enable the Shopping Cart?', 'memberpress'); ?></h3>
          <p><?php esc_html_e('Turns on the shop, multi-item cart, and cart checkout, plus digital product types. Standalone registration pages keep working as-is.', 'memberpress'); ?></p>
          <p><?php esc_html_e('You can switch the cart off until the first cart order is placed. After that it\'s permanent. Nothing takes effect until you click Update Options.', 'memberpress'); ?></p>
          <p>
            <button type="button" class="button button-primary" id="mepr-cart-enable-confirm"><?php esc_html_e('Continue', 'memberpress'); ?></button>
            <button type="button" class="button" id="mepr-cart-enable-cancel"><?php echo esc_html_x('Cancel', 'ui', 'memberpress'); ?></button>
          </p>
        </div>
      </div>
    </div>
  </div>
  <?php endif; ?>
</section>
