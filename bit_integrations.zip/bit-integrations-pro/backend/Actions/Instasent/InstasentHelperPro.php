<?php

/**
 * Instasent Record Api
 */

namespace BitApps\IntegrationsPro\Actions\Instasent;

if (!\defined('ABSPATH')) {
    exit;
}

final class InstasentHelperPro
{
    public const BASE_URL = 'https://api.instasent.com';

    /**
     * Send a single SMS.
     * POST https://api.instasent.com/sms
     *
     * @param mixed      $default
     * @param mixed      $fieldData
     * @param null|mixed $auth_token
     */
    public static function sendSms($default, $fieldData, $auth_token = null)
    {
        $body = self::compact([
            'from'     => $fieldData['from'] ?? '',
            'to'       => $fieldData['to'] ?? '',
            'text'     => $fieldData['text'] ?? '',
            'clientId' => $fieldData['clientId'] ?? '',
        ]);

        if (isset($fieldData['allowUnicode']) && $fieldData['allowUnicode'] !== '') {
            $body['allowUnicode'] = filter_var($fieldData['allowUnicode'], FILTER_VALIDATE_BOOLEAN);
        }

        return self::request('POST', '/sms', $body, $auth_token);
    }

    /**
     * Create a number lookup.
     * POST https://api.instasent.com/lookup
     *
     * @param mixed      $default
     * @param mixed      $fieldData
     * @param null|mixed $auth_token
     */
    public static function createLookup($default, $fieldData, $auth_token = null)
    {
        $body = ['to' => $fieldData['to'] ?? ''];

        return self::request('POST', '/lookup', $body, $auth_token);
    }

    /**
     * Create a datasource inside a project.
     * POST https://api.instasent.com/v1/project/{projectId}/datasource
     *
     * @param mixed      $default
     * @param mixed      $fieldData
     * @param null|mixed $integrationDetails
     * @param null|mixed $auth_token
     */
    public static function createDatasource($default, $fieldData, $integrationDetails = null, $auth_token = null)
    {
        $body = self::compact([
            'name'           => $fieldData['name'] ?? '',
            'description'    => $fieldData['description'] ?? '',
            'defaultCountry' => $fieldData['defaultCountry'] ?? '',
            'locale'         => $fieldData['locale'] ?? '',
            'timezone'       => $fieldData['timezone'] ?? '',
        ]);

        $projectId = is_object($integrationDetails) ? ($integrationDetails->projectId ?? '') : '';
        $project = rawurlencode($projectId);

        return self::request('POST', "/v1/project/{$project}/datasource", $body, $auth_token);
    }

    /**
     * Create or update a contact in a datasource stream.
     * POST https://api.instasent.com/v1/project/{projectId}/datasource/{datasourceId}/stream/contacts
     *
     * @param mixed      $default
     * @param mixed      $fieldData
     * @param null|mixed $integrationDetails
     * @param null|mixed $auth_token
     */
    public static function createOrUpdateContact($default, $fieldData, $integrationDetails = null, $auth_token = null)
    {
        $contact = self::compact([
            '_user_id'      => $fieldData['userId'] ?? '',
            '_first_name'   => $fieldData['firstName'] ?? '',
            '_last_name'    => $fieldData['lastName'] ?? '',
            '_email'        => $fieldData['email'] ?? '',
            '_phone_mobile' => $fieldData['phoneMobile'] ?? '',
        ]);

        $reserved = ['projectId', 'datasourceId', 'userId', 'firstName', 'lastName', 'email', 'phoneMobile'];
        foreach ((array) $fieldData as $key => $value) {
            if (\in_array($key, $reserved, true)) {
                continue;
            }

            if ($value === null || $value === '' || $value === []) {
                continue;
            }

            $contact[$key] = $value;
        }

        $projectId = is_object($integrationDetails) ? ($integrationDetails->projectId ?? '') : '';
        $project = rawurlencode($projectId);
        $datasourceId = is_object($integrationDetails) ? ($integrationDetails->datasourceId ?? '') : '';
        $datasource = rawurlencode($datasourceId);

        return self::request('POST', "/v1/project/{$project}/datasource/{$datasource}/stream/contacts", [$contact], $auth_token);
    }

    /**
     * Delete a contact from a datasource stream.
     * DELETE https://api.instasent.com/v1/project/{projectId}/datasource/{datasourceId}/stream/contacts/{userId}
     *
     * @param mixed      $default
     * @param mixed      $fieldData
     * @param null|mixed $integrationDetails
     * @param null|mixed $auth_token
     */
    public static function deleteContact($default, $fieldData, $integrationDetails = null, $auth_token = null)
    {
        $projectId = is_object($integrationDetails) ? ($integrationDetails->projectId ?? '') : '';
        $project = rawurlencode($projectId);
        $datasourceId = is_object($integrationDetails) ? ($integrationDetails->datasourceId ?? '') : '';
        $datasource = rawurlencode($datasourceId);
        $userId = rawurlencode($fieldData['userId'] ?? '');

        return self::request('DELETE', "/v1/project/{$project}/datasource/{$datasource}/stream/contacts/{$userId}", null, $auth_token);
    }

    /**
     * Create a contact event in a datasource stream.
     * POST https://api.instasent.com/v1/project/{projectId}/datasource/{datasourceId}/stream/events
     *
     * @param mixed      $default
     * @param mixed      $fieldData
     * @param null|mixed $integrationDetails
     * @param null|mixed $auth_token
     */
    public static function createContactEvent($default, $fieldData, $integrationDetails = null, $auth_token = null)
    {
        $parameters = [];
        $reserved = ['projectId', 'datasourceId', 'userId', 'eventId', 'eventType'];
        foreach ((array) $fieldData as $key => $value) {
            if (\in_array($key, $reserved, true)) {
                continue;
            }

            if ($value === null || $value === '' || $value === []) {
                continue;
            }

            $parameters[$key] = $value;
        }

        // All keys are required by the ingest API, so keep them present even when empty.
        // Cast parameters to an object so an empty map serializes as {} rather than [].
        $event = [
            '_user_id'          => $fieldData['userId'] ?? '',
            '_event_id'         => $fieldData['eventId'] ?? '',
            '_event_type'       => $fieldData['eventType'] ?? '',
            '_event_parameters' => (object) $parameters,
        ];

        $projectId = is_object($integrationDetails) ? ($integrationDetails->projectId ?? '') : '';
        $project = rawurlencode($projectId);
        $datasourceId = is_object($integrationDetails) ? ($integrationDetails->datasourceId ?? '') : '';
        $datasource = rawurlencode($datasourceId);

        return self::request('POST', "/v1/project/{$project}/datasource/{$datasource}/stream/events", [$event], $auth_token);
    }

    /**
     * Perform the HTTP request against the Instasent API.
     *
     * @param string $method
     * @param string $path
     * @param mixed  $body
     * @param string $auth_token
     *
     * @return array
     */
    private static function request($method, $path, $body, $auth_token)
    {
        $httpHelperClass = bit_integrations_get_class('Core\\Util\\HttpHelper');

        $headers = [
            'Authorization' => 'Bearer ' . $auth_token,
            'Content-Type'  => 'application/json',
            'Accept'        => 'application/json',
        ];

        $requestBody = $body === null ? null : wp_json_encode($body);

        $response = $httpHelperClass::request(self::BASE_URL . $path, $method, $requestBody, $headers);

        $code = $httpHelperClass::$responseCode;

        if (is_wp_error($response)) {
            return [
                'success' => false,
                'message' => $response->get_error_message(),
                'code'    => $code ? $code : 500,
            ];
        }

        $success = $code >= 200 && $code < 300;

        return [
            'success' => $success,
            'message' => $response,
            'code'    => $code,
        ];
    }

    private static function compact(array $data)
    {
        return array_filter($data, static function ($value) {
            return $value !== null && $value !== '' && $value !== [];
        });
    }
}
