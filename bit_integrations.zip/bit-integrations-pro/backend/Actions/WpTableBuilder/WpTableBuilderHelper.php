<?php

namespace BitApps\IntegrationsPro\Actions\WpTableBuilder;

/**
 * Shared helpers for the WP Table Builder action handlers.
 *
 * Ported from bit-pi's WpTableBuilder helper, with the bit-pi status_code envelope
 * replaced by the success/message envelope Bit Integrations logs.
 */
final class WpTableBuilderHelper
{
    /**
     * Tables are a custom post type — WP Table Builder registers it as
     * Cpt::POST_TYPE, and stores the table body in a single post meta.
     */
    public const POST_TYPE = 'wptb-tables';

    public const CONTENT_META_KEY = '_wptb_content_';

    /**
     * True while one of this integration's actions is writing to a table.
     *
     * @var bool
     */
    private static $writing = false;

    public static function isPluginActive()
    {
        return \defined('WPTB_PLUGIN_DIR');
    }

    /**
     * Are we inside one of this integration's own table writes?
     *
     * The write actions go through wp_insert_post / wp_update_post / wp_trash_post,
     * each of which fires the hook behind the matching trigger. Without this, a flow
     * whose trigger and action are both WP Table Builder re-enters itself: Create Table
     * fires Table Created, which runs the flow, which creates another table. The
     * triggers consult this before doing any work.
     *
     * @return bool
     */
    public static function isWriting()
    {
        return self::$writing;
    }

    /**
     * Run a table write with the trigger guard held.
     *
     * @param callable $write
     *
     * @return mixed whatever $write returns
     */
    public static function guardedWrite($write)
    {
        $previous = self::$writing;
        self::$writing = true;

        try {
            return $write();
        } finally {
            // Restored rather than cleared: a write nested inside another must not
            // release the guard for the outer one.
            self::$writing = $previous;
        }
    }

    /**
     * Sanitize table markup before it is stored.
     *
     * WP Table Builder's shortcode echoes this meta unescaped, so content mapped from
     * a public form submission would otherwise be a stored XSS vector.
     *
     * The post rules cover most of a rendered table (data-wptb-* attributes and inline
     * styles included) but drop six tags WP Table Builder itself permits in
     * RenderUtils::strip_xss — embeds, and the form elements its input cells are built
     * from. Those are added back with the same attribute sets WP Table Builder uses, so
     * this never strips markup the plugin considers valid. Script execution vectors
     * (script, on* handlers, javascript: URLs) are still removed by wp_kses.
     *
     * @param string $content
     *
     * @return string
     */
    public static function sanitizeTableContent($content)
    {
        $allowed = wp_kses_allowed_html('post');

        $allowed['iframe'] = [
            'src'             => true,
            'width'           => true,
            'height'          => true,
            'frameborder'     => true,
            'allowfullscreen' => true,
            'class'           => true,
        ];

        $allowed['form'] = [
            'action' => true,
            'method' => true,
            'target' => true,
            'class'  => true,
        ];

        $allowed['input'] = [
            'type'  => true,
            'name'  => true,
            'value' => true,
            'class' => true,
            'src'   => true,
            'title' => true,
            'alt'   => true,
        ];

        $allowed['select'] = [
            'name'  => true,
            'class' => true,
        ];

        $allowed['optgroup'] = [
            'label' => true,
            'class' => true,
        ];

        $allowed['option'] = [
            'value'    => true,
            'class'    => true,
            'selected' => true,
        ];

        return wp_kses((string) $content, $allowed);
    }

    /**
     * Load a post only if it is actually a WP Table Builder table.
     *
     * @param int $tableId
     *
     * @return null|WP_Post
     */
    public static function findTable($tableId)
    {
        $table = get_post((int) $tableId);

        return $table && $table->post_type === self::POST_TYPE ? $table : null;
    }

    /**
     * Summarise a table for the action response.
     *
     * Deliberately does not parse the stored content: the parsed form is only useful
     * to the read actions, which are not part of this integration, and parsing is not
     * free.
     *
     * @param null|WP_Post $table
     *
     * @return array
     */
    public static function summariseTable($table)
    {
        // is_object rather than a truthy test: every line below is a direct property
        // read, which warns on a non-object where isset() would stay silent.
        if (!\is_object($table)) {
            return [];
        }

        return [
            'id'        => $table->ID,
            'title'     => $table->post_title,
            'status'    => $table->post_status,
            'author'    => $table->post_author,
            'date'      => $table->post_date,
            'modified'  => $table->post_modified,
            'edit_link' => admin_url('admin.php?page=wptb-builder&table=' . $table->ID),
        ];
    }

    /**
     * Verify every required key is present and non-empty.
     *
     * @param array $fieldData
     * @param array $required
     *
     * @return null|array Error envelope listing the missing keys, null when satisfied
     */
    public static function requireFields($fieldData, array $required)
    {
        $missing = [];

        foreach ($required as $key) {
            if (!isset($fieldData[$key]) || $fieldData[$key] === '' || $fieldData[$key] === null) {
                $missing[] = $key;
            }
        }

        if (!empty($missing)) {
            return self::errorResponse(
                // translators: %s: comma separated field names
                wp_sprintf(__('Missing required field(s): %s', 'bit-integrations-pro'), implode(', ', $missing))
            );
        }
    }

    public static function errorResponse($message)
    {
        return [
            'success' => false,
            'message' => $message
        ];
    }

    public static function successResponse($message, $data = [])
    {
        return [
            'success' => true,
            'message' => $message,
            'data'    => $data
        ];
    }
}
