<?php

namespace WPAICG\Lib\Addons;

use WPAICG\aipkit_dashboard;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Consent availability and requirements for paid features.
 * Retains the established public API and saved feature identifier.
 */
class AIPKit_Consent_Compliance
{
    const ADDON_KEY = 'consent_compliance';

    public static function is_active(): bool
    {
        return self::is_required();
    }

    public static function is_required(): bool
    {
        if (!class_exists('\\WPAICG\\aipkit_dashboard')) {
            $dashboard_path = defined('WPAICG_PLUGIN_DIR') ? WPAICG_PLUGIN_DIR . 'classes/admin/dashboard.php' : null;
            if ($dashboard_path && file_exists($dashboard_path)) {
                require_once $dashboard_path;
            } else {
                return false;
            }
        }

        return aipkit_dashboard::is_pro_plan();
    }
}
