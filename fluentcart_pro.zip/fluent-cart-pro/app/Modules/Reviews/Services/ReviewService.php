<?php

namespace FluentCartPro\App\Modules\Reviews\Services;

/**
 * Pro-owned review capabilities. Free ships the single-store-reply
 * contract and exposes only the neutral
 * fluent_cart/review/allow_multiple_replies switch; this service owns
 * the public threaded-replies filter and bridges it onto that switch.
 */
class ReviewService
{
    /**
     * Threaded replies — multiple store replies per review plus reviewer
     * (customer) replies. Off by default; third parties enable via filter
     */
    public static function isThreadedRepliesEnabled(): bool
    {
        return (bool) apply_filters('fluent_cart/review/allow_threaded_replies', false);
    }

    /**
     * Bridge callback for the free plugin's allow_multiple_replies switch —
     * every enforcement point (admin reply, bulk reply, reply UI, the Pro
     * reply endpoint) consults that switch, so lifting it here is what
     * unlocks the full threaded behavior everywhere at once.
     */
    public static function allowMultipleReplies($allowed): bool
    {
        return (bool) $allowed || static::isThreadedRepliesEnabled();
    }
}
