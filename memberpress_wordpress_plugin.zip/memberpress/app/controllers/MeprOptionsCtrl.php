<?php

use MemberPress\GroundLevel\Container\Concerns\InjectsDependencies;
use MemberPress\GroundLevel\Mothership\AbstractPluginConnection;
use MemberPress\GroundLevel\Mothership\Manager\LicenseManager;
use MemberPress\GroundLevel\Mothership\Transients\ActivationTransient;
use MemberPress\GroundLevel\Support\Result;

if (!defined('ABSPATH')) {
    die('You are not allowed to call this page directly.');
}

/**
 * Options controller.
 *
 * @property MemberPress\GroundLevel\Mothership\Manager\LicenseManager $license_manager
 */
class MeprOptionsCtrl extends MeprBaseCtrl
{
    use InjectsDependencies;

    /**
     * Defines dependencies to be injected.
     */
    protected function inject(): array
    {
        return ['license_manager' => LicenseManager::class];
    }

    /**
     * Load hooks for various AJAX actions and admin scripts.
     *
     * @return void
     */
    public function load_hooks()
    {
        add_action('wp_ajax_mepr_gateway_form', 'MeprOptionsCtrl::gateway_form');
        add_action('admin_enqueue_scripts', 'MeprOptionsCtrl::enqueue_scripts');
        add_action('admin_notices', 'MeprOptionsCtrl::maybe_show_stripe_checkout_warning');
        add_action('admin_notices', 'MeprCartNoticesHelper::maybe_show_cart_notices');
        add_action('wp_ajax_mepr_validate_stripe_payment_method_types', 'MeprOptionsCtrl::validate_stripe_payment_method_types');
        add_action('wp_ajax_mepr_activate_stripe_payment_method', 'MeprOptionsCtrl::activate_stripe_payment_method');
        // Multi-currency surfaces are cart-only; register them only when the cart is enabled.
        if (MeprOptions::cart_enabled()) {
            add_action('wp_ajax_mepr_refresh_exchange_rates', 'MeprOptionsCtrl::ajax_refresh_exchange_rates');

            // Schedule daily exchange rate refresh cron.
            MeprUtils::schedule_event_on_init(time(), 'daily', 'mepr_daily_exchange_rate_refresh');
            add_action('mepr_daily_exchange_rate_refresh', 'MeprOptionsCtrl::cron_refresh_exchange_rates');

            // Add "Currencies" tab to product options meta box.
            add_action('mepr_product_options_tabs', 'MeprOptionsCtrl::currencies_product_tab');
            add_action('mepr_product_options_pages', 'MeprOptionsCtrl::currencies_product_tab_content');
        }

        /*
         * Licensing surfaces only exist where the Mothership package does.
         * Both the AJAX edition installer and the activation/deactivation
         * handlers resolve LicenseManager from the container, so both are
         * registered together behind the same guard.
         */
        if (class_exists(LicenseManager::class)) {
            add_action('wp_ajax_mepr_install_license_edition', 'MeprOptionsCtrl::ajax_install_license_edition');

            // Hook license activation/deactivation handlers.
            add_action('admin_init', [$this->license_manager, 'controller']);
        }
    }

    /**
     * Output the Currencies tab link in the product options meta box.
     *
     * Only shown when secondary currencies are enabled.
     *
     * @param  MeprProduct $product The current product.
     * @return void
     */
    public static function currencies_product_tab($product)
    {
        $enabled   = MeprCurrencyService::get_enabled_currencies();
        $primary   = MeprOptions::fetch()->currency_code;
        $secondary = array_filter($enabled, function ($c) use ($primary) {
            return $c !== $primary;
        });

        if (!empty($secondary)) :
            ?>
            <a class="nav-tab main-nav-tab" href="#" id="currencies"><?php esc_html_e('Currencies', 'memberpress'); ?></a>
            <?php
        endif;
    }

    /**
     * Output the Currencies tab content in the product options meta box.
     *
     * @param  MeprProduct $product The current product.
     * @return void
     */
    public static function currencies_product_tab_content($product)
    {
        $enabled   = MeprCurrencyService::get_enabled_currencies();
        $primary   = MeprOptions::fetch()->currency_code;
        $secondary = array_filter($enabled, function ($c) use ($primary) {
            return $c !== $primary;
        });

        if (!empty($secondary)) :
            ?>
            <div class="product_options_page currencies">
                <?php MeprView::render('/admin/products/currencies', get_defined_vars()); ?>
            </div>
            <?php
        endif;
    }

    /**
     * Show a warning if Stripe Checkout is deprecated.
     *
     * @return void
     */
    public static function maybe_show_stripe_checkout_warning()
    {
        if (MeprUtils::is_get_request() && isset($_GET['page']) && $_GET['page'] === 'memberpress-options') {
            $mepr_options = MeprOptions::fetch();

            foreach ($mepr_options->integrations as $integration) {
                if (isset($integration['gateway']) && $integration['gateway'] === 'MeprStripeGateway' && isset($integration['use_stripe_checkout'])) {
                    MeprView::render('/admin/stripe_checkout_deprecated');
                    break;
                }
            }
        }
    }

    /**
     * Route various actions based on the request.
     *
     * @return mixed
     */
    public static function route()
    {
        $action = (isset($_REQUEST['action']) ? sanitize_text_field(wp_unslash($_REQUEST['action'])) : '');

        if (MeprUtils::is_post_request() && $action === 'process-form') {
            check_admin_referer('mepr_update_options', 'mepr_options_nonce');
            return self::process_form();
        } elseif ($action === 'upgrade') { // Manually upgrade the database.
            $mepr_app = new MeprAppCtrl();
            try {
                delete_transient('mepr_migration_error');
                $mepr_app->install();
                $message = __('Database Was Upgraded', 'memberpress');
                return self::display_form([], $message);
            } catch (MeprDbMigrationException $e) {
                return self::display_form([$e->getMessage()], '');
            }
        } elseif ($action === 'clear_tax_rates') {
            check_admin_referer('clear_tax_rates', 'mepr_taxes_nonce');
            MeprTaxRate::destroy_all();
            $message = __('Tax rates have been cleared', 'memberpress');
            return self::display_form([], $message);
        } else {
            return self::display_form();
        }
    }

    /**
     * Display the options form in the admin panel.
     *
     * @param array  $errors  List of errors to display.
     * @param string $message Message to display.
     *
     * @return void
     */
    public static function display_form($errors = [], $message = '')
    {
        if (MeprUtils::is_logged_in_and_an_admin()) {
            $mepr_options = MeprOptions::fetch();

            MeprView::render(
                '/admin/options/form',
                array_merge(
                    compact('errors', 'message', 'mepr_options'),
                    self::license_view_vars()
                )
            );
        }
    }

    /**
     * Resolves the Mothership objects the License pane renders with.
     *
     * Returns an empty array in a build without the Mothership package, where
     * the container cannot resolve any of them. The pane that consumes them is
     * gated on MeprUpdateCtrl, which such a build also drops, so the view
     * never reads the missing keys.
     *
     * @return array The view variables, or an empty array when unavailable.
     */
    private static function license_view_vars(): array
    {
        if (class_exists(AbstractPluginConnection::class)) {
            return [
                'plugin'               => memberpress()->container()->get(AbstractPluginConnection::class),
                'activation_transient' => memberpress()->container()->get(ActivationTransient::class),
                'license_manager'      => memberpress()->container()->get(LicenseManager::class),
            ];
        }

        return [];
    }

    /**
     * Process the options form submission.
     *
     * @return void
     */
    public static function process_form()
    {
        $mepr_options = MeprOptions::fetch();

        if (MeprUtils::is_logged_in_and_an_admin()) {
            $errors  = MeprHooks::apply_filters('mepr_validate_options', $mepr_options->validate($_POST, []));
            $message = '';

            if (empty($errors)) {
                MeprHooks::do_action('mepr_process_options', $_POST);
                $settings = MeprHooks::apply_filters('mepr_saved_options', $_POST);
                $mepr_options->update($settings);

                // Cart enablement toggle — honor the request, but ignore an opt-out that
                // isn't currently allowed (cart orders exist).
                $cart_was_enabled           = !empty($mepr_options->cart_enabled);
                $cart_requested             = isset($_POST[$mepr_options->cart_enabled_str]);
                $mepr_options->cart_enabled = $cart_requested || !MeprOptions::can_disable_cart();

                // First enable (and later saves while on) create missing Cart/Shop/Checkout pages.
                if (!empty($mepr_options->cart_enabled)) {
                    MeprAppHelper::ensure_cart_pages($mepr_options);
                }

                $mepr_options->store();

                // On opt-out, clear the cart crons; re-enabling self-heals via the controllers' scheduling guards.
                if ($cart_was_enabled && !$mepr_options->cart_enabled) {
                    self::clear_cart_crons();
                    update_option($mepr_options->cart_opted_out_str, 1);
                }

                // Persist checkout wizard settings (stored as separate options, not in the main options object).
                $enable_wizard = isset($_POST[$mepr_options->enable_checkout_wizard_str]);
                update_option($mepr_options->enable_checkout_wizard_str, $enable_wizard);

                // Persist custom checkout steps.
                $raw_steps = isset($_POST[$mepr_options->checkout_steps_str]) ? $_POST[$mepr_options->checkout_steps_str] : []; // phpcs:ignore WordPress.Security.NonceVerification.Missing
                $steps     = [];
                foreach ((array) $raw_steps as $step_data) {
                    $label      = sanitize_text_field(wp_unslash($step_data['label'] ?? ''));
                    $id         = sanitize_title($label); // Derive slug from label.
                    $field_keys = isset($step_data['field_keys']) ? array_map('sanitize_key', (array) $step_data['field_keys']) : [];
                    if (empty($label)) {
                        continue; // Skip unnamed steps.
                    }
                    $steps[] = [
                        'id'         => $id,
                        'label'      => $label,
                        'field_keys' => $field_keys,
                        'sort_order' => count($steps),
                    ];
                }
                update_option($mepr_options->checkout_steps_str, $steps);

                // Ensure that the rewrite rules are flushed & in place.
                MeprUtils::flush_rewrite_rules(); // Don't call this before running ->update() - it borks stuff.

                $message = __('Options saved.', 'memberpress');
            }

            MeprView::render(
                '/admin/options/form',
                array_merge(
                    compact('errors', 'message', 'mepr_options'),
                    self::license_view_vars()
                )
            );
        }
    }

    /**
     * Enqueue scripts and styles for the admin panel.
     *
     * @param string $hook The current admin page hook.
     *
     * @return void
     */
    public static function enqueue_scripts($hook)
    {
        if ($hook === 'memberpress_page_memberpress-options') {
            $mepr_options = MeprOptions::fetch();

            wp_register_style('mepr-clipboardtip', MEPR_CSS_URL . '/vendor/tooltipster.bundle.min.css', [], MEPR_VERSION);
            wp_register_style('mepr-clipboardtip-borderless', MEPR_CSS_URL . '/vendor/tooltipster-sideTip-borderless.min.css', ['mepr-clipboardtip'], MEPR_VERSION);
            wp_enqueue_style('mp-options', MEPR_CSS_URL . '/admin-options.css', ['mepr-settings-table-css','mepr-clipboardtip','mepr-clipboardtip-borderless'], MEPR_VERSION);
            wp_enqueue_style('mp-emails', MEPR_CSS_URL . '/admin-emails.css', ['mp-options'], MEPR_VERSION);
            wp_enqueue_style('mp-checkout-steps', MEPR_CSS_URL . '/admin-checkout-steps.css', ['mp-options'], MEPR_VERSION);

            // Cart tab styling — scoped to the cart sections; loads only when the
            // cart is on, so it depends on the cart design tokens (registered by
            // MeprCartCtrl at admin priority 0 whenever the cart is enabled).
            if (MeprOptions::cart_enabled()) {
                wp_enqueue_style(
                    'mp-admin-cart-options',
                    MEPR_CSS_URL . '/admin-cart-options.css',
                    ['mp-options', 'mepr-cart-tokens'],
                    MeprBaseCartCtrl::cart_asset_ver('/admin-cart-options.css')
                );
            }

            $js_helpers = [
                'show_fname_lname_id'                   => "#{$mepr_options->show_fname_lname_str}",
                'require_fname_lname_id'                => "#{$mepr_options->require_fname_lname_str}",
                'jsUrl'                                 => MEPR_JS_URL,
                'taxRateRemoveStr'                      => __('Are you sure you want to delete this Tax Rate?', 'memberpress'),
                'confirmPMDelete'                       => __('WARNING: Do not remove this Payment Method if you have active subscriptions using it. Doing so will prevent you from being notified of recurring payments for those subscriptions, which means your members will lose access to their paid content. Are you sure you want to delete this Payment Method?', 'memberpress'),
                'wpnonce'                               => wp_create_nonce(MEPR_PLUGIN_SLUG),
                'option_nonce'                          => wp_create_nonce('mepr_gateway_form_nonce'),
                'tax_nonce'                             => wp_create_nonce('mepr_taxes'),
                'invalid_response'                      => __('Invalid response.', 'memberpress'),
                'ajax_error'                            => __('Ajax error.', 'memberpress'),
                'install_license_edition_nonce'         => wp_create_nonce('mepr_install_license_edition'),
                'validate_stripe_payment_methods_nonce' => wp_create_nonce('mepr_validate_stripe_payment_method_types'),
                'activate_stripe_payment_method_nonce'  => wp_create_nonce('mepr_activate_stripe_payment_method'),
                'validate_stripe_tax_nonce'             => wp_create_nonce('mepr_validate_stripe_tax'),
                'validate_stripe_tax_all_nonce'         => wp_create_nonce('mepr_validate_stripe_tax_all_gateways'),
                'unable_to_verify_stripe_tax'           => __('Unable to verify Stripe Tax status', 'memberpress'),
                'square_connect_nonce'                  => wp_create_nonce('mepr_square_connect'),
                'square_disconnect_confirm'             => __('Are you sure you want to disconnect this gateway? Disconnecting this gateway will prevent subscription payments from being recorded and new payments will stop working when the access token expires.', 'memberpress'),
                'paypal_connect_action_nonce'           => wp_create_nonce('mepr_paypal_connect_action'),
                'paypal_vaulting_connect_nonce'         => wp_create_nonce('mepr_paypal_vaulting_connect'),
                'paypal_vaulting_disconnect_confirm'    => __('Are you sure you want to disconnect this gateway? Disconnecting this gateway will prevent subscription payments from being recorded.', 'memberpress'),
                'custom_fields_row'                     => self::get_custom_fields_row(),
                'custom_fields_options'                 => self::get_custom_fields_options(),
                'custom_fields_option_new'              => self::get_custom_fields_option_new(),
                'cart_enabled'                          => MeprOptions::cart_enabled() ? '1' : '',
            ];

            wp_register_script('memberpress-i18n', MEPR_JS_URL . '/i18n.js', ['jquery'], MEPR_VERSION);
            wp_register_script('mepr-uploader', MEPR_JS_URL . '/uploader.js', [], MEPR_VERSION);
            wp_enqueue_script('alpinejs', MEPR_JS_URL . '/vendor/alpine.min.js', [], MEPR_VERSION, true);
            wp_localize_script('memberpress-i18n', 'MeprI18n', ['states' => MeprUtils::states()]);

            wp_register_script('mepr-tooltipster', MEPR_JS_URL . '/vendor/tooltipster.bundle.min.js', ['jquery'], MEPR_VERSION);
            wp_register_script('mepr-copy-to-clipboard', MEPR_JS_URL . '/clipboard_copy.js', ['clipboard', 'mepr-tooltipster'], MEPR_VERSION);
            wp_localize_script('mepr-copy-to-clipboard', 'MeprClipboard', [
                'copy_text'       => __('Copy to Clipboard', 'memberpress'),
                'copied_text'     => __('Copied!', 'memberpress'),
                'copy_error_text' => __('Oops, Copy Failed!', 'memberpress'),
            ]);

            wp_enqueue_script(
                'mepr-options-js',
                MEPR_JS_URL . '/admin_options.js',
                [
                    'jquery',
                    'mepr-copy-to-clipboard',
                    'mepr-settings-table-js',
                    'mepr-admin-shared-js',
                    'jquery-ui-sortable',
                    'memberpress-i18n',
                ],
                MEPR_VERSION
            );
            wp_localize_script('mepr-options-js', 'MeprOptions', $js_helpers);

            $email_locals = [
                'set_email_defaults_nonce' => wp_create_nonce('set_email_defaults'),
                'send_test_email_nonce'    => wp_create_nonce('send_test_email'),
            ];
            wp_enqueue_script('mepr-emails-js', MEPR_JS_URL . '/admin_emails.js', ['mepr-options-js'], MEPR_VERSION);
            wp_localize_script('mepr-emails-js', 'MeprEmail', $email_locals);

            wp_enqueue_script('mepr-checkout-steps-js', MEPR_JS_URL . '/admin_checkout_steps.js', ['jquery', 'jquery-ui-sortable'], MEPR_VERSION);
            wp_localize_script('mepr-checkout-steps-js', 'MeprCheckoutSteps', [
                // Translators: %s: name of the step the field is assigned to.
                'field_in_label' => __('(in: %s)', 'memberpress'),
                'field_no_label' => __('another step', 'memberpress'),
                'field_singular' => __('field', 'memberpress'),
                'field_plural'   => __('fields', 'memberpress'),
            ]);

            wp_enqueue_script('mepr-exchange-rates-js', MEPR_JS_URL . '/admin_exchange_rates.js', ['jquery'], MEPR_VERSION);
            wp_localize_script('mepr-exchange-rates-js', 'MeprExchangeRates', [
                'refreshing_text' => __('Refreshing...', 'memberpress'),
                'refresh_text'    => __('Refresh Exchange Rates', 'memberpress'),
                'refresh_nonce'   => wp_create_nonce('mepr_refresh_exchange_rates'),
            ]);

            MeprHooks::do_action('mepr_options_admin_enqueue_script', $hook);
        }
    }

    /**
     * Generates and returns the row HTML for custom fields.
     */
    private static function get_custom_fields_row(): string
    {
        $row_id = 'ROW_ID';
        $line   =  (object) [
            'field_key'        => '',
            'field_name'       => '',
            'field_type'       => 'text',
            'default_value'    => '',
            'show_on_signup'   => false,
            'show_in_account'  => true,
            'required'         => false,
            'options'          => [],
        ];

        return MeprView::get_string('/admin/options/custom-fields/row', compact('line', 'row_id'));
    }

    /**
     * Generates and returns the options HTML for custom fields.
     */
    private static function get_custom_fields_options(): string
    {
        $row_id  = 'ROW_ID';
        $options = [
            (object) [
                'option_name'  => '',
                'option_value' => '',
            ],
        ];

        return MeprView::get_string('/admin/options/custom-fields/options', compact('options', 'row_id'));
    }

    /**
     * Generates and returns the new option HTML for custom fields.
     *
     * @return string
     */
    private static function get_custom_fields_option_new(): string
    {
        $row_id = 'ROW_ID';

        return MeprView::get_string('/admin/options/custom-fields/option_new', compact('row_id'));
    }

    /**
     * Render the gateway form via AJAX.
     *
     * @return void
     */
    public static function gateway_form()
    {
        check_ajax_referer('mepr_gateway_form_nonce', 'option_nonce');

        // Make sure the user is authorized. Note is_admin() is always true on
        // admin-ajax.php requests, so it is not an authorization check.
        if (!MeprUtils::is_mepr_admin()) {
            die(wp_json_encode(['error' => __('Unauthorized', 'memberpress')]));
        }

        $mepr_options = MeprOptions::fetch();

        if (!isset($_POST['g']) or empty($_POST['g'])) {
            $gateways = array_keys(MeprGatewayFactory::all());

            if (empty($gateways)) {
                die(wp_json_encode(['error' => __('No gateways were found', 'memberpress')]));
            }

            // Artificially set the gateway to the first available.
            $gateway = $gateways[0];
        } else {
            $gateway = sanitize_text_field(wp_unslash($_POST['g']));
        }

        try {
            $obj = MeprGatewayFactory::fetch($gateway);
        } catch (Exception $e) {
            wp_die(esc_html($e->getMessage()));
        }

        // Cart-capable = has a registered cart handler; drives the "Enable for cart" toggle state.
        $cart_capable = ($obj instanceof MeprBaseRealGateway) && MeprCartPaymentService::is_cart_capable($obj);

        $owned_level = MeprView::capture_start();
        try {
            MeprView::render('/admin/options/gateway', get_defined_vars());
        } finally {
            $form = MeprView::capture_end($owned_level);
        }

        die(wp_json_encode([
            'form' => $form,
            'id'   => $obj->id,
        ]));
    }

    /**
     * Install a license edition via AJAX.
     *
     * @return void
     */
    public static function ajax_install_license_edition()
    {
        if (!MeprUtils::is_post_request()) {
            wp_send_json_error(__('Bad request.', 'memberpress'));
        }

        if (!current_user_can('update_plugins')) {
            wp_send_json_error(__('Sorry, you don\'t have permission to do this.', 'memberpress'));
        }

        if (!check_ajax_referer('mepr_install_license_edition', false, false)) {
            wp_send_json_error(__('Security check failed.', 'memberpress'));
        }

        $result = self::maybe_install_correct_edition();

        if (false === $result) {
            wp_send_json_success(__('The correct edition for your license is already installed.', 'memberpress'));
        } elseif ($result->isSuccess()) {
            wp_send_json_success($result->getMessage());
        } else {
            wp_send_json_error($result->getMessage());
        }
    }

    /**
     * Install the correct edition.
     *
     * @return Result|false
     */
    public static function maybe_install_correct_edition()
    {
        /*
         * There is no edition to correct without a license to read it from.
         * The AJAX route above is only registered where the package exists,
         * but this is public and static, so it carries its own guard rather
         * than trusting its one caller.
         */
        if (!class_exists(LicenseManager::class)) {
            return false;
        }

        $plugin          = memberpress()->container()->get(AbstractPluginConnection::class);
        $license_manager = memberpress()->container()->get(LicenseManager::class);
        $editions        = $license_manager->isIncorrectEditionInstalled();

        if (false === $editions) {
            return false;
        }

        $activation = memberpress()->container()->get(ActivationTransient::class);

        if (empty($activation->downloadUrl)) {
            return Result::failure(__('License data not found.', 'memberpress'));
        }

        $result = $license_manager->installPluginSilently($activation->downloadUrl);

        if ($result->isFailure()) {
            return Result::failure(__('Failed to install the correct edition of MemberPress, please download it from memberpress.com and install it manually.', 'memberpress'));
        }

        /**
         * Fires when the currently installed edition is changed.
         *
         * @param array $editions {
         *     @type  object $installed The previously installed edition.
         *     @type  object $license   The edition associated with the activated license.
         * }
         */
        do_action($plugin->pluginId . '_edition_changed', $editions);

        return Result::success(__('The correct edition of MemberPress has been installed successfully.', 'memberpress'));
    }

    /**
     * Validate Stripe payment method types via AJAX.
     *
     * @return void
     */
    public static function validate_stripe_payment_method_types()
    {
        if (!MeprUtils::is_post_request()) {
            wp_send_json_error(__('Bad request.', 'memberpress'));
        }

        if (!MeprUtils::is_logged_in_and_an_admin()) {
            wp_send_json_error(__('Sorry, you don\'t have permission to do this.', 'memberpress'));
        }

        if (!check_ajax_referer('mepr_validate_stripe_payment_method_types', false, false)) {
            wp_send_json_error(__('Security check failed.', 'memberpress'));
        }

        $gateway_id           = isset($_POST['gateway_id']) ? sanitize_text_field(wp_unslash($_POST['gateway_id'])) : '';
        $payment_method_types = isset($_POST['payment_method_types']) && is_array($_POST['payment_method_types']) ? array_filter(array_map('sanitize_key', wp_unslash($_POST['payment_method_types']))) : [];

        if (empty($gateway_id) || empty($payment_method_types)) {
            wp_send_json_error(__('Bad request.', 'memberpress'));
        }

        $mepr_options = MeprOptions::fetch();
        $pm           = $mepr_options->payment_method($gateway_id);

        if (!$pm instanceof MeprStripeGateway) {
            wp_send_json_error(__('Bad request.', 'memberpress'));
        }

        try {
            if (in_array('link', $payment_method_types, true) && !self::is_payment_method_active('link', $pm->id)) {
                self::activate_payment_method('link', $pm);
            }

            $pm->create_test_payment_intent($payment_method_types);

            wp_send_json_success();
        } catch (Exception $e) {
            wp_send_json_error($e->getMessage());
        }
    }

    /**
     * Activate a Stripe payment method via AJAX.
     *
     * @return void
     * @throws Exception If the payment method couldn't be activated.
     */
    public static function activate_stripe_payment_method()
    {
        if (!MeprUtils::is_post_request()) {
            wp_send_json_error(__('Bad request.', 'memberpress'));
        }

        if (!MeprUtils::is_logged_in_and_an_admin()) {
            wp_send_json_error(__('Sorry, you don\'t have permission to do this.', 'memberpress'));
        }

        if (!check_ajax_referer('mepr_activate_stripe_payment_method', false, false)) {
            wp_send_json_error(__('Security check failed.', 'memberpress'));
        }

        $gateway_id          = isset($_POST['gateway_id']) ? sanitize_text_field(wp_unslash($_POST['gateway_id'])) : '';
        $payment_method_type = isset($_POST['payment_method_type']) ? sanitize_key(wp_unslash($_POST['payment_method_type'])) : '';
        $supported_types     = ['apple_pay', 'google_pay'];

        if (empty($gateway_id) || empty($payment_method_type) || !in_array($payment_method_type, $supported_types, true)) {
            wp_send_json_error(__('Bad request.', 'memberpress'));
        }

        $mepr_options = MeprOptions::fetch();
        $pm           = $mepr_options->payment_method($gateway_id);

        if (!$pm instanceof MeprStripeGateway) {
            wp_send_json_error(__('Bad request.', 'memberpress'));
        }

        try {
            self::activate_payment_method($payment_method_type, $pm);

            wp_send_json_success();
        } catch (Exception $e) {
            wp_send_json_error($e->getMessage());
        }
    }

    /**
     * Is the given payment method active on the given Stripe gateway?
     *
     * Checks that the current site is registered as a payment method domain, and that the given payment method is active.
     *
     * @param  string $payment_method_type The payment method type: 'apple_pay', 'google_pay' or 'link'.
     * @param  string $gateway_id          The ID of the Stripe payment method.
     * @return boolean
     */
    public static function is_payment_method_active($payment_method_type, $gateway_id)
    {
        $pmd = get_option("mepr_stripe_payment_method_domain_$gateway_id");

        if (
            is_array($pmd) &&
            isset($pmd['domain_name']) && $pmd['domain_name'] === self::get_site_domain() &&
            isset($pmd['enabled']) && $pmd['enabled'] &&
            isset($pmd[$payment_method_type]['status']) && $pmd[$payment_method_type]['status'] === 'active'
        ) {
            return true;
        }

        return false;
    }

    /**
     * Activate the given payment method on the given gateway
     *
     * Registers the current site as a Stripe payment method domain, in both live and test mode, and ensures that the
     * given payment method is active.
     *
     * @param  string            $payment_method_type The payment method type: 'apple_pay', 'google_pay' or 'link'.
     * @param  MeprStripeGateway $pm                  The Stripe gateway object.
     * @throws Exception If the payment method couldn't be activated.
     *
     * @return void
     */
    public static function activate_payment_method($payment_method_type, MeprStripeGateway $pm)
    {
        $domain = self::get_site_domain();

        add_filter('mepr_stripe_is_test_mode', '__return_false');

        $live = $pm->send_stripe_request('payment_method_domains', [
            'domain_name' => $domain,
            'enabled'     => 'true',
        ], 'post');

        if ($live[$payment_method_type]['status'] !== 'active') {
            $live = $pm->send_stripe_request("payment_method_domains/{$live['id']}/validate", [], 'post');

            if ($live[$payment_method_type]['status'] !== 'active') {
                if (isset($live[$payment_method_type]['status_details']['error_message'])) {
                    $message = $live[$payment_method_type]['status_details']['error_message'];
                } else {
                    $message = sprintf(
                        // Translators: %s: payment method type.
                        __('Unable to activate payment method `%s`', 'memberpress'),
                        $payment_method_type
                    );
                }

                throw new Exception(esc_html($message));
            }
        }

        remove_filter('mepr_stripe_is_test_mode', '__return_false');

        update_option("mepr_stripe_payment_method_domain_$pm->id", $live);

        add_filter('mepr_stripe_is_test_mode', '__return_true');

        try {
            $test = $pm->send_stripe_request('payment_method_domains', [
                'domain_name' => $domain,
                'enabled'     => 'true',
            ], 'post');

            if ($test[$payment_method_type]['status'] !== 'active') {
                $pm->send_stripe_request("payment_method_domains/{$test['id']}/validate", [], 'post');
            }
        } catch (Exception $e) {
            // Ignore exceptions in Test mode.
        }

        remove_filter('mepr_stripe_is_test_mode', '__return_true');
    }

    /**
     * Get the domain of the current site, to be registered as a payment method domain
     *
     * @return string
     */
    private static function get_site_domain()
    {
        return isset($_SERVER['HTTP_HOST']) ? sanitize_text_field(wp_unslash($_SERVER['HTTP_HOST'])) : str_replace(['https://', 'http://'], '', get_site_url());
    }

    /**
     * AJAX handler to refresh exchange rates and auto-fill product prices.
     *
     * @return void
     */
    public static function ajax_refresh_exchange_rates()
    {
        check_ajax_referer('mepr_refresh_exchange_rates');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => __('Unauthorized', 'memberpress')]);
        }

        $rates = MeprExchangeRateService::fetch_and_cache();

        if (empty($rates)) {
            wp_send_json_error(['message' => __('Could not fetch exchange rates. Prices are based on last known rates.', 'memberpress')]);
        }

        update_option('mepr_exchange_rates_last_updated', current_time('mysql'));
        self::auto_fill_product_prices($rates);

        $date_str = date_i18n(get_option('date_format') . ' ' . get_option('time_format'));
        $base     = MeprOptions::fetch()->currency_code;
        $enabled  = MeprCurrencyService::get_enabled_currencies();

        // Build rate summary for enabled currencies only.
        $rate_details = [];
        foreach ($enabled as $code) {
            if ($code === $base || !isset($rates[$code])) {
                continue;
            }
            $rate_details[] = $code . ': ' . number_format((float) $rates[$code], 4);
        }

        $message = sprintf(
            // Translators: %1$s: date/time, %2$s: base currency code.
            __('Rates last updated: %1$s &middot; %2$s base', 'memberpress'),
            $date_str,
            $base
        );

        if (!empty($rate_details)) {
            $message .= ' &middot; ' . implode(', ', $rate_details);
        }

        wp_send_json_success([
            'message' => $message,
        ]);
    }

    /**
     * Cron handler to refresh exchange rates daily.
     *
     * @return void
     */
    public static function cron_refresh_exchange_rates()
    {
        $rates = MeprExchangeRateService::fetch_and_cache();

        if (!empty($rates)) {
            update_option('mepr_exchange_rates_last_updated', current_time('mysql'));
            self::auto_fill_product_prices($rates);
        }
    }

    /**
     * Unschedule the cart crons on opt-out and plugin deactivation. Re-enabling reschedules
     * them via the `!wp_next_scheduled` guards in the cart controllers' load_hooks.
     *
     * @return void
     */
    public static function clear_cart_crons()
    {
        wp_clear_scheduled_hook('mepr_cart_session_cleanup');
        wp_clear_scheduled_hook('mepr_daily_exchange_rate_refresh');
    }

    /**
     * Auto-fill product prices for all enabled secondary currencies.
     *
     * Only updates fields with source === 'auto' (or unset). Manual overrides are preserved.
     *
     * @param array|null $rates Exchange rates array. If null, fetched from service.
     *
     * @return void
     */
    public static function auto_fill_product_prices($rates = null)
    {
        if (!MeprOptions::cart_enabled()) {
            return;
        }

        if ($rates === null) {
            $rates = MeprExchangeRateService::get_rates();
        }

        if (empty($rates)) {
            return;
        }

        $products = get_posts([
            'post_type'      => MeprProduct::$cpt,
            'posts_per_page' => -1,
            'fields'         => 'ids',
        ]);

        foreach ($products as $product_id) {
            self::auto_fill_product_price((int) $product_id, $rates);
        }
    }

    /**
     * Auto-fill secondary-currency price/trial meta for one product from its primary amounts.
     *
     * @param integer    $product_id Product post ID.
     * @param array|null $rates      Exchange rates. Null = load from service.
     *
     * @return void
     */
    public static function auto_fill_product_price($product_id, $rates = null)
    {
        if (!MeprOptions::cart_enabled() || $product_id <= 0) {
            return;
        }

        if ($rates === null) {
            $rates = MeprExchangeRateService::get_rates();
        }

        if (empty($rates)) {
            return;
        }

        $primary       = MeprOptions::fetch()->currency_code;
        $enabled       = MeprCurrencyService::get_enabled_currencies();
        $primary_price = (float) get_post_meta($product_id, MeprProduct::$price_str, true);
        $primary_trial = (float) get_post_meta($product_id, '_mepr_product_trial_amount', true);

        foreach ($enabled as $code) {
            if ($code === $primary) {
                continue;
            }

            $source = get_post_meta($product_id, MeprProduct::$price_str . "_{$code}_source", true);
            if ($source !== 'manual') {
                $converted = MeprExchangeRateService::convert($primary_price, $primary, $code);
                update_post_meta($product_id, MeprProduct::$price_str . "_{$code}", round($converted, 2));
                update_post_meta($product_id, MeprProduct::$price_str . "_{$code}_source", 'auto');
            }

            $trial_source = get_post_meta($product_id, "_mepr_product_trial_amount_{$code}_source", true);
            if ($trial_source !== 'manual' && $primary_trial > 0) {
                $converted_trial = MeprExchangeRateService::convert($primary_trial, $primary, $code);
                update_post_meta($product_id, "_mepr_product_trial_amount_{$code}", round($converted_trial, 2));
                update_post_meta($product_id, "_mepr_product_trial_amount_{$code}_source", 'auto');
            }
        }
    }
}
