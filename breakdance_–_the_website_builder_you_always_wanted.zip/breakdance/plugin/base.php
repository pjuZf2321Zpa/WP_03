<?php

require_once __DIR__ . '/defines/defines.php';

require_once __DIR__ . "/vendor/autoload.php";

require_once __DIR__ . "/error-reporter/base.php";

require_once __DIR__ . '/util/base.php';

require_once __DIR__ . '/framework/base.php';

require_once __DIR__ . '/filesystem/base.php';

require_once __DIR__ . '/lib/base.php';

require_once __DIR__ . '/preferences/base.php';

require_once __DIR__ . '/config/base.php';

require_once __DIR__ . '/data/base.php';

require_once __DIR__ . '/ajax/base.php';

require_once __DIR__ . '/compat/base.php';

require_once __DIR__ . '/permissions/base.php';

require_once __DIR__ . '/security/base.php';

require_once __DIR__ . '/admin/base.php';

require_once __DIR__ . '/settings/base.php';

require_once __DIR__ . '/element-studio/base.php';

require_once __DIR__ . '/plugins-api/base.php';

require_once __DIR__ . '/gutenberg/base.php';

require_once __DIR__ . '/elements/base.php';

require_once __DIR__ . '/debug/base.php';

require_once __DIR__ . '/actions_filters/base.php';

require_once __DIR__ . '/render/base.php';

require_once __DIR__ . "/integrations/base.php";

require_once __DIR__ . '/themeless/base.php';

require_once __DIR__ . '/fonts/base.php';

require_once __DIR__ . '/icons/base.php';

require_once __DIR__ . "/api-keys/base.php";

require_once __DIR__ . '/dynamic-data/base.php';

require_once __DIR__ . '/conditions/base.php';

require_once __DIR__ . '/classes-selectors/base.php';

require_once __DIR__ . '/design-presets/base.php';

require_once __DIR__ . '/global-scripts/base.php';

require_once __DIR__ . '/global-default-stylesheets/base.php';

require_once __DIR__ . '/global-styles/base.php';

require_once __DIR__ . '/design-library/base.php';

require_once __DIR__ . '/wpuiforbuilder/base.php';

require_once __DIR__ . '/blocks/base.php';

require_once __DIR__ . '/forms/base.php';

require_once __DIR__ . '/media/base.php';

require_once __DIR__ . "/public-apis/base.php";

require_once __DIR__ . '/revisions/base.php';

require_once __DIR__ . '/animations/base.php';

require_once __DIR__ . '/header-footer-tracking-code/base.php';

require_once __DIR__ . "/maintenance-mode/base.php";

require_once __DIR__ . '/bloat-eliminator/base.php';

require_once __DIR__ . '/setup/base.php';

require_once __DIR__ . '/oembed/base.php';

require_once __DIR__ . '/wpwidgets/base.php';

require_once __DIR__ . '/woocommerce/base.php';

require_once __DIR__ . "/local-dependencies-files/base.php";

require_once __DIR__ . "/wp-query-control/base.php";

require_once __DIR__ . "/setup-wizard/base.php";

require_once __DIR__ . "/browse-mode/base.php";

require_once __DIR__ . "/licensing/base.php";

require_once __DIR__ . "/customizer/base.php";

require_once __DIR__ . "/sessions/track-view-and-session-counts.php";

require_once __DIR__ . "/subscription/base.php";

require_once __DIR__ . '/acf-breakdance-content/base.php';

require_once __DIR__ . '/experiments/base.php';

require_once __DIR__ . '/interactions/base.php';

require_once __DIR__ . '/variables/base.php';

require_once __DIR__ . '/partners/base.php';

require_once __DIR__ . '/tracking/base.php';
require_once __DIR__ . '/telemetry/base.php';

require_once __DIR__ . '/onboarding/base.php';

require_once __DIR__ . '/onboarding-v3/base.php';
require_once __DIR__ . '/onboarding-v4/base.php';

require_once __DIR__ . '/home-v3/base.php';

require_once __DIR__ . '/oxygen-home/base.php';

require_once __DIR__ . '/singularity/base.php';

require_once __DIR__ . '/extensions/base.php';

require_once __DIR__ . '/breakdance-oxygen/base.php';

require_once __DIR__ . '/futurelayer/base.php';

require_once __DIR__ . '/i18n/base.php';

require_once __DIR__ . '/cli/base.php';

require_once __DIR__ . '/mcp/base.php';
