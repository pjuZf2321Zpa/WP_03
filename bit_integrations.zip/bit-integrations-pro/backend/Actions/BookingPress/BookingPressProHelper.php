<?php

namespace BitApps\IntegrationsPro\Actions\BookingPress;

use BitApps\IntegrationsPro\Core\Util\Hooks;

final class BookingPressProHelper
{
    public static function cancelAppointment($response, $fieldData)
    {
        if (!self::isPluginInstalled()) {
            return self::error(__('BookingPress is not installed or activated', 'bit-integrations-pro'));
        }

        $appointmentId = \intval($fieldData['appointment_id'] ?? 0);
        if (empty($appointmentId)) {
            return self::error(__('Appointment ID is required.', 'bit-integrations-pro'));
        }

        $data = self::getAppointmentData($appointmentId);
        if (empty($data)) {
            return self::error(__('Appointment not found.', 'bit-integrations-pro'));
        }

        global $wpdb;
        $result = $wpdb->update(
            self::getAppointmentTableName(),
            ['bookingpress_appointment_status'     => '3'],
            ['bookingpress_appointment_booking_id' => $appointmentId]
        );

        if ($result === false) {
            return self::error(__('Failed to cancel appointment.', 'bit-integrations-pro'));
        }

        Hooks::run('bookingpress_after_cancel_appointment', $appointmentId);

        return ['success' => true, 'message' => __('Appointment canceled successfully.', 'bit-integrations-pro')];
    }

    public static function updateAppointmentStatus($response, $fieldData)
    {
        if (!self::isPluginInstalled()) {
            return self::error(__('BookingPress is not installed or activated', 'bit-integrations-pro'));
        }

        $appointmentId = \intval($fieldData['appointment_id'] ?? 0);
        $newStatus = \intval($fieldData['status'] ?? 0);

        if (empty($appointmentId)) {
            return self::error(__('Appointment ID is required.', 'bit-integrations-pro'));
        }

        if (empty($newStatus)) {
            return self::error(__('Status is required.', 'bit-integrations-pro'));
        }

        $data = self::getAppointmentData($appointmentId);
        if (empty($data)) {
            return self::error(__('Appointment not found.', 'bit-integrations-pro'));
        }

        global $wpdb;
        $result = $wpdb->update(
            self::getAppointmentTableName(),
            ['bookingpress_appointment_status'     => $newStatus],
            ['bookingpress_appointment_booking_id' => $appointmentId]
        );

        if ($result === false) {
            return self::error(__('Failed to update appointment status.', 'bit-integrations-pro'));
        }

        Hooks::run('bookingpress_after_change_appointment_status', $appointmentId, $newStatus);

        return ['success' => true, 'message' => __('Appointment status updated.', 'bit-integrations-pro'), 'data' => self::getAppointmentData($appointmentId)];
    }

    public static function createCustomer($response, $fieldData)
    {
        if (!self::isPluginInstalled()) {
            return self::error(__('BookingPress is not installed or activated', 'bit-integrations-pro'));
        }

        $firstName = $fieldData['first_name'] ?? '';
        $lastName = $fieldData['last_name'] ?? '';
        $email = $fieldData['email'] ?? '';

        if (empty($firstName) || empty($lastName) || empty($email)) {
            return self::error(__('First name, last name, and email are required.', 'bit-integrations-pro'));
        }

        $fullName = trim($firstName . ' ' . $lastName);

        global $wpdb;
        $result = $wpdb->insert(
            self::getCustomerTableName(),
            [
                'bookingpress_user_login'         => $email,
                'bookingpress_user_status'        => 1,
                'bookingpress_user_type'          => 2,
                'bookingpress_user_email'         => $email,
                'bookingpress_user_name'          => $email,
                'bookingpress_customer_full_name' => $fullName,
                'bookingpress_user_firstname'     => $firstName,
                'bookingpress_user_lastname'      => $lastName,
                'bookingpress_user_phone'         => $fieldData['phone'] ?? '',
                'bookingpress_user_created'       => current_time('mysql'),
            ]
        );

        if ($result === false) {
            return self::error(__('Failed to create customer.', 'bit-integrations-pro'));
        }

        $customerId = $wpdb->insert_id;
        Hooks::run('bookingpress_after_create_customer', $customerId);

        return ['success' => true, 'message' => __('Customer created successfully.', 'bit-integrations-pro'), 'data' => self::getCustomerData($customerId)];
    }

    public static function updateCustomer($response, $fieldData)
    {
        if (!self::isPluginInstalled()) {
            return self::error(__('BookingPress is not installed or activated', 'bit-integrations-pro'));
        }

        $customerId = \intval($fieldData['customer_id'] ?? 0);
        if (empty($customerId)) {
            return self::error(__('Customer ID is required.', 'bit-integrations-pro'));
        }

        $existingData = self::getCustomerData($customerId);
        if (empty($existingData)) {
            return self::error(__('Customer not found.', 'bit-integrations-pro'));
        }

        unset($fieldData['customer_id']);
        if (empty($fieldData)) {
            return self::error(__('No fields to update.', 'bit-integrations-pro'));
        }

        $updateData = $fieldData;
        $firstName = $fieldData['bookingpress_user_firstname'] ?? $existingData['bookingpress_user_firstname'];
        $lastName = $fieldData['bookingpress_user_lastname'] ?? $existingData['bookingpress_user_lastname'];

        if (isset($firstName) || isset($lastName)) {
            $updateData['bookingpress_customer_full_name'] = trim($firstName . ' ' . $lastName);
        }

        if (empty($updateData)) {
            return self::error(__('No valid fields to update.', 'bit-integrations-pro'));
        }

        global $wpdb;
        $result = $wpdb->update(
            self::getCustomerTableName(),
            $updateData,
            ['bookingpress_customer_id' => $customerId]
        );

        if ($result === false) {
            return self::error(__('Failed to update customer.', 'bit-integrations-pro'));
        }

        Hooks::run('bookingpress_after_update_customer', $customerId);

        return ['success' => true, 'message' => __('Customer updated successfully.', 'bit-integrations-pro'), 'data' => self::getCustomerData($customerId)];
    }

    public static function deleteAppointment($response, $fieldData)
    {
        if (!self::isPluginInstalled()) {
            return self::error(__('BookingPress is not installed or activated', 'bit-integrations-pro'));
        }

        $appointmentId = \intval($fieldData['appointment_id'] ?? 0);
        if (empty($appointmentId)) {
            return self::error(__('Appointment ID is required.', 'bit-integrations-pro'));
        }

        $data = self::getAppointmentData($appointmentId);
        if (empty($data)) {
            return self::error(__('Appointment not found.', 'bit-integrations-pro'));
        }

        global $wpdb;
        $result = $wpdb->delete(
            self::getAppointmentTableName(),
            ['bookingpress_appointment_booking_id' => $appointmentId]
        );

        if ($result === false) {
            return self::error(__('Failed to delete appointment.', 'bit-integrations-pro'));
        }

        $wpdb->delete(
            self::getPaymentLogTableName(),
            ['bookingpress_appointment_booking_ref' => $appointmentId]
        );

        return ['success' => true, 'message' => __('Appointment deleted successfully.', 'bit-integrations-pro')];
    }

    public static function deleteCustomer($response, $fieldData)
    {
        if (!self::isPluginInstalled()) {
            return self::error(__('BookingPress is not installed or activated', 'bit-integrations-pro'));
        }

        $customerId = \intval($fieldData['customer_id'] ?? 0);
        if (empty($customerId)) {
            return self::error(__('Customer ID is required.', 'bit-integrations-pro'));
        }

        $data = self::getCustomerData($customerId);
        if (empty($data)) {
            return self::error(__('Customer not found.', 'bit-integrations-pro'));
        }

        global $wpdb;
        $result = $wpdb->delete(
            self::getCustomerTableName(),
            ['bookingpress_customer_id' => $customerId]
        );

        if ($result === false) {
            return self::error(__('Failed to delete customer.', 'bit-integrations-pro'));
        }

        $wpdb->delete(
            self::getAppointmentTableName(),
            ['bookingpress_customer_id' => $customerId]
        );

        $wpdb->delete(
            self::getPaymentLogTableName(),
            ['bookingpress_customer_id' => $customerId]
        );

        return ['success' => true, 'message' => __('Customer deleted successfully.', 'bit-integrations-pro')];
    }

    private static function isPluginInstalled()
    {
        return class_exists('BookingPress');
    }

    private static function error($message)
    {
        return ['success' => false, 'message' => $message];
    }

    private static function getAppointmentData($appointmentId)
    {
        return self::getRecordById(self::getAppointmentTableName(), $appointmentId, 'bookingpress_appointment_booking_id');
    }

    private static function getCustomerData($customerId)
    {
        return self::getRecordById(self::getCustomerTableName(), $customerId, 'bookingpress_customer_id');
    }

    private static function getRecordById($tableName, $id, $idColumn)
    {
        if (empty($tableName)) {
            return [];
        }

        global $wpdb;
        $record = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT * FROM {$tableName} WHERE {$idColumn} = %d", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
                $id
            ),
            ARRAY_A
        );

        return $record ?: [];
    }

    private static function getAppointmentTableName()
    {
        global $tbl_bookingpress_appointment_bookings; // phpcs:ignore WordPress.DB.GlobalVariables
        if (!empty($tbl_bookingpress_appointment_bookings)) {
            return $tbl_bookingpress_appointment_bookings;
        }

        global $wpdb;

        return $wpdb->prefix . 'bookingpress_appointment_bookings';
    }

    private static function getCustomerTableName()
    {
        global $tbl_bookingpress_customers; // phpcs:ignore WordPress.DB.GlobalVariables
        if (!empty($tbl_bookingpress_customers)) {
            return $tbl_bookingpress_customers;
        }

        global $wpdb;

        return $wpdb->prefix . 'bookingpress_customers';
    }

    private static function getPaymentLogTableName()
    {
        global $tbl_bookingpress_payment_logs; // phpcs:ignore WordPress.DB.GlobalVariables
        if (!empty($tbl_bookingpress_payment_logs)) {
            return $tbl_bookingpress_payment_logs;
        }

        global $wpdb;

        return $wpdb->prefix . 'bookingpress_payment_logs';
    }
}
