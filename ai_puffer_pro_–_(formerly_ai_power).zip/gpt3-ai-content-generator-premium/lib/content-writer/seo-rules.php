<?php

namespace WPAICG\ContentWriter\SEO;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Paid Smart SEO rule catalog and presets.
 */
class AIPKit_Content_Writer_Smart_SEO_Rules
{
    /**
     * @return array<int, array{id:string,group:string,label:string,description:string}>
     */
    public static function rule_catalog(): array
    {
        return [
            ['id' => 'focus_keyword_exists', 'group' => 'shared', 'label' => __('Focus keyphrase exists', 'gpt3-ai-content-generator'), 'description' => __('Requires a focus keyphrase when the active SEO profile supports one.', 'gpt3-ai-content-generator')],
            ['id' => 'focus_keyword_in_title', 'group' => 'shared', 'label' => __('Keyphrase in title', 'gpt3-ai-content-generator'), 'description' => __('Checks that the focus keyphrase appears in the SEO title.', 'gpt3-ai-content-generator')],
            ['id' => 'focus_keyword_in_introduction', 'group' => 'shared', 'label' => __('Keyphrase in introduction', 'gpt3-ai-content-generator'), 'description' => __('Checks early article placement for the focus keyphrase.', 'gpt3-ai-content-generator')],
            ['id' => 'focus_keyword_in_meta_description', 'group' => 'shared', 'label' => __('Keyphrase in meta description', 'gpt3-ai-content-generator'), 'description' => __('Checks that the meta description contains the focus keyphrase.', 'gpt3-ai-content-generator')],
            ['id' => 'focus_keyword_in_heading', 'group' => 'shared', 'label' => __('Keyphrase in subheading', 'gpt3-ai-content-generator'), 'description' => __('Checks natural keyphrase placement in H2/H3 headings.', 'gpt3-ai-content-generator')],
            ['id' => 'focus_keyword_in_slug', 'group' => 'shared', 'label' => __('Keyphrase in slug', 'gpt3-ai-content-generator'), 'description' => __('Checks whether the generated URL slug includes the focus keyphrase.', 'gpt3-ai-content-generator')],
            ['id' => 'focus_keyword_length', 'group' => 'shared', 'label' => __('Keyphrase length', 'gpt3-ai-content-generator'), 'description' => __('Keeps focus keyphrases concise enough for supported SEO plugins.', 'gpt3-ai-content-generator')],
            ['id' => 'meta_description_exists', 'group' => 'shared', 'label' => __('Meta description exists', 'gpt3-ai-content-generator'), 'description' => __('Requires a generated or provided meta description.', 'gpt3-ai-content-generator')],
            ['id' => 'meta_description_length', 'group' => 'shared', 'label' => __('Meta description length', 'gpt3-ai-content-generator'), 'description' => __('Keeps meta descriptions within the preferred search-result length.', 'gpt3-ai-content-generator')],
            ['id' => 'title_length', 'group' => 'shared', 'label' => __('Title length', 'gpt3-ai-content-generator'), 'description' => __('Keeps titles inside the preferred SEO title length range.', 'gpt3-ai-content-generator')],
            ['id' => 'content_length', 'group' => 'shared', 'label' => __('Content length', 'gpt3-ai-content-generator'), 'description' => __('Checks minimum article depth, with stricter targets for some profiles.', 'gpt3-ai-content-generator')],
            ['id' => 'paragraph_length', 'group' => 'shared', 'label' => __('Paragraph length', 'gpt3-ai-content-generator'), 'description' => __('Flags very long paragraphs that reduce readability.', 'gpt3-ai-content-generator')],
            ['id' => 'heading_distribution', 'group' => 'shared', 'label' => __('Heading distribution', 'gpt3-ai-content-generator'), 'description' => __('Checks that long articles are broken up with headings.', 'gpt3-ai-content-generator')],
            ['id' => 'internal_link_exists', 'group' => 'shared', 'label' => __('Internal link', 'gpt3-ai-content-generator'), 'description' => __('Requires at least one useful internal link where applicable.', 'gpt3-ai-content-generator')],
            ['id' => 'external_link_exists', 'group' => 'shared', 'label' => __('External link', 'gpt3-ai-content-generator'), 'description' => __('Requires a useful outbound citation where applicable.', 'gpt3-ai-content-generator')],
            ['id' => 'keyphrase_in_image_alt', 'group' => 'shared', 'label' => __('Keyphrase in image alt', 'gpt3-ai-content-generator'), 'description' => __('Checks whether an existing image alt text supports the focus keyphrase.', 'gpt3-ai-content-generator')],
            ['id' => 'previously_used_keyphrase', 'group' => 'shared', 'label' => __('Previously used keyphrase', 'gpt3-ai-content-generator'), 'description' => __('Avoids reusing the same focus keyphrase on multiple posts.', 'gpt3-ai-content-generator')],
            ['id' => 'keyword_density', 'group' => 'shared', 'label' => __('Keyword density', 'gpt3-ai-content-generator'), 'description' => __('Checks whether the focus keyphrase appears naturally without stuffing.', 'gpt3-ai-content-generator')],

            ['id' => 'yoast_seo_title_width', 'group' => 'yoast', 'label' => __('SEO title width', 'gpt3-ai-content-generator'), 'description' => __('Matches Yoast title width expectations.', 'gpt3-ai-content-generator')],
            ['id' => 'yoast_consecutive_sentence_starts', 'group' => 'yoast', 'label' => __('Consecutive sentence starts', 'gpt3-ai-content-generator'), 'description' => __('Avoids repeated sentence openings in Yoast readability analysis.', 'gpt3-ai-content-generator')],
            ['id' => 'yoast_transition_words', 'group' => 'yoast', 'label' => __('Transition words', 'gpt3-ai-content-generator'), 'description' => __('Targets Yoast transition-word coverage.', 'gpt3-ai-content-generator')],
            ['id' => 'yoast_sentence_length', 'group' => 'yoast', 'label' => __('Sentence length', 'gpt3-ai-content-generator'), 'description' => __('Limits the share of long sentences for Yoast readability.', 'gpt3-ai-content-generator')],
            ['id' => 'yoast_passive_voice', 'group' => 'yoast', 'label' => __('Passive voice', 'gpt3-ai-content-generator'), 'description' => __('Reduces passive voice where Yoast flags it.', 'gpt3-ai-content-generator')],
            ['id' => 'image_exists', 'group' => 'yoast', 'label' => __('Image exists', 'gpt3-ai-content-generator'), 'description' => __('Checks that the article has at least one image.', 'gpt3-ai-content-generator')],
            ['id' => 'single_h1', 'group' => 'yoast', 'label' => __('Single H1', 'gpt3-ai-content-generator'), 'description' => __('Prevents duplicate H1 headings in the article body.', 'gpt3-ai-content-generator')],
            ['id' => 'competing_links', 'group' => 'yoast', 'label' => __('Competing links', 'gpt3-ai-content-generator'), 'description' => __('Avoids linking the focus keyphrase to another page.', 'gpt3-ai-content-generator')],

            ['id' => 'rank_math_title_start_with_keyword', 'group' => 'rank_math', 'label' => __('Title starts with keyphrase', 'gpt3-ai-content-generator'), 'description' => __('Requires the Rank Math title to begin with the focus keyphrase.', 'gpt3-ai-content-generator')],
            ['id' => 'rank_math_title_has_number', 'group' => 'rank_math', 'label' => __('Title has number', 'gpt3-ai-content-generator'), 'description' => __('Adds a number when Rank Math title readability expects one.', 'gpt3-ai-content-generator')],
            ['id' => 'rank_math_title_power_word', 'group' => 'rank_math', 'label' => __('Title power word', 'gpt3-ai-content-generator'), 'description' => __('Uses a natural power word for Rank Math title readability.', 'gpt3-ai-content-generator')],
            ['id' => 'rank_math_title_sentiment', 'group' => 'rank_math', 'label' => __('Title sentiment', 'gpt3-ai-content-generator'), 'description' => __('Adds clear positive or negative sentiment for Rank Math.', 'gpt3-ai-content-generator')],
            ['id' => 'rank_math_permalink_length', 'group' => 'rank_math', 'label' => __('Permalink length', 'gpt3-ai-content-generator'), 'description' => __('Keeps Rank Math permalinks under the preferred length.', 'gpt3-ai-content-generator')],
            ['id' => 'rank_math_table_of_contents', 'group' => 'rank_math', 'label' => __('Table of contents', 'gpt3-ai-content-generator'), 'description' => __('Adds or validates a Rank Math-compatible table of contents block.', 'gpt3-ai-content-generator')],
            ['id' => 'rank_math_content_assets', 'group' => 'rank_math', 'label' => __('Rich media assets', 'gpt3-ai-content-generator'), 'description' => __('Checks image and video usage for Rank Math content assets.', 'gpt3-ai-content-generator')],
            ['id' => 'rank_math_keyword_density', 'group' => 'rank_math', 'label' => __('Rank Math keyword density', 'gpt3-ai-content-generator'), 'description' => __('Uses Rank Math density thresholds for the focus keyphrase.', 'gpt3-ai-content-generator')],

            ['id' => 'aioseo_keyphrase_in_content', 'group' => 'aioseo', 'label' => __('Keyphrase in content', 'gpt3-ai-content-generator'), 'description' => __('Checks AIOSEO focus keyphrase usage in the article body.', 'gpt3-ai-content-generator')],
            ['id' => 'aioseo_keyphrase_in_introduction', 'group' => 'aioseo', 'label' => __('Keyphrase in introduction', 'gpt3-ai-content-generator'), 'description' => __('Checks AIOSEO keyphrase placement in the introduction.', 'gpt3-ai-content-generator')],
            ['id' => 'aioseo_keyphrase_in_meta_description', 'group' => 'aioseo', 'label' => __('Keyphrase in meta description', 'gpt3-ai-content-generator'), 'description' => __('Checks AIOSEO keyphrase placement in the meta description.', 'gpt3-ai-content-generator')],
            ['id' => 'aioseo_keyphrase_in_image_alt', 'group' => 'aioseo', 'label' => __('Keyphrase in image alt', 'gpt3-ai-content-generator'), 'description' => __('Checks exact AIOSEO keyphrase usage in image alt text.', 'gpt3-ai-content-generator')],
            ['id' => 'aioseo_keyphrase_in_subheadings', 'group' => 'aioseo', 'label' => __('Keyphrase in subheadings', 'gpt3-ai-content-generator'), 'description' => __('Balances AIOSEO keyphrase usage across subheadings.', 'gpt3-ai-content-generator')],
            ['id' => 'aioseo_keyphrase_length', 'group' => 'aioseo', 'label' => __('Keyphrase length', 'gpt3-ai-content-generator'), 'description' => __('Checks AIOSEO focus keyphrase word count.', 'gpt3-ai-content-generator')],
            ['id' => 'aioseo_meta_description_length', 'group' => 'aioseo', 'label' => __('Meta description length', 'gpt3-ai-content-generator'), 'description' => __('Uses AIOSEO meta description length thresholds.', 'gpt3-ai-content-generator')],
            ['id' => 'aioseo_content_length', 'group' => 'aioseo', 'label' => __('Content length', 'gpt3-ai-content-generator'), 'description' => __('Uses AIOSEO minimum article length thresholds.', 'gpt3-ai-content-generator')],
            ['id' => 'aioseo_internal_links', 'group' => 'aioseo', 'label' => __('Internal links', 'gpt3-ai-content-generator'), 'description' => __('Checks internal links using AIOSEO rules.', 'gpt3-ai-content-generator')],
            ['id' => 'aioseo_external_links', 'group' => 'aioseo', 'label' => __('External links', 'gpt3-ai-content-generator'), 'description' => __('Checks external links using AIOSEO rules.', 'gpt3-ai-content-generator')],
            ['id' => 'aioseo_keyphrase_beginning_title', 'group' => 'aioseo', 'label' => __('Title begins with keyphrase', 'gpt3-ai-content-generator'), 'description' => __('Requires the AIOSEO title to begin with the focus keyphrase.', 'gpt3-ai-content-generator')],
            ['id' => 'aioseo_title_length', 'group' => 'aioseo', 'label' => __('Title length', 'gpt3-ai-content-generator'), 'description' => __('Uses AIOSEO title length thresholds.', 'gpt3-ai-content-generator')],
            ['id' => 'aioseo_headline_score', 'group' => 'aioseo', 'label' => __('Headline score', 'gpt3-ai-content-generator'), 'description' => __('Uses AIOSEO headline analyzer scoring when available.', 'gpt3-ai-content-generator')],
            ['id' => 'aioseo_content_assets', 'group' => 'aioseo', 'label' => __('Content assets', 'gpt3-ai-content-generator'), 'description' => __('Checks image and video usage for AIOSEO.', 'gpt3-ai-content-generator')],
            ['id' => 'aioseo_sentence_length', 'group' => 'aioseo', 'label' => __('Sentence length', 'gpt3-ai-content-generator'), 'description' => __('Limits long sentences for AIOSEO readability.', 'gpt3-ai-content-generator')],
            ['id' => 'aioseo_passive_voice', 'group' => 'aioseo', 'label' => __('Passive voice', 'gpt3-ai-content-generator'), 'description' => __('Reduces passive voice for AIOSEO readability.', 'gpt3-ai-content-generator')],
            ['id' => 'aioseo_transition_words', 'group' => 'aioseo', 'label' => __('Transition words', 'gpt3-ai-content-generator'), 'description' => __('Targets AIOSEO transition-word coverage.', 'gpt3-ai-content-generator')],
            ['id' => 'aioseo_consecutive_sentences', 'group' => 'aioseo', 'label' => __('Consecutive sentences', 'gpt3-ai-content-generator'), 'description' => __('Avoids repeated sentence starts for AIOSEO.', 'gpt3-ai-content-generator')],
            ['id' => 'aioseo_subheading_distribution', 'group' => 'aioseo', 'label' => __('Subheading distribution', 'gpt3-ai-content-generator'), 'description' => __('Checks long sections between headings for AIOSEO.', 'gpt3-ai-content-generator')],
            ['id' => 'aioseo_flesch_reading', 'group' => 'aioseo', 'label' => __('Flesch reading ease', 'gpt3-ai-content-generator'), 'description' => __('Uses AIOSEO reading ease guidance.', 'gpt3-ai-content-generator')],
        ];
    }

    /**
     * @return array<string, string>
     */
    public static function rule_group_labels(): array
    {
        return [
            'shared' => __('Smart SEO rules', 'gpt3-ai-content-generator'),
            'yoast' => __('Yoast SEO rules', 'gpt3-ai-content-generator'),
            'rank_math' => __('Rank Math rules', 'gpt3-ai-content-generator'),
            'aioseo' => __('All in One SEO rules', 'gpt3-ai-content-generator'),
            'framework' => __('The SEO Framework rules', 'gpt3-ai-content-generator'),
        ];
    }

    /**
     * @return array<string, array{label:string,description:string,disabled_rules:string[]}>
     */
    public static function rule_presets(): array
    {
        return [
            'strict' => [
                'label' => __('Strict score', 'gpt3-ai-content-generator'),
                'description' => __('Follow every SEO check and aim for the highest score.', 'gpt3-ai-content-generator'),
                'disabled_rules' => [],
            ],
            'balanced' => [
                'label' => __('Balanced', 'gpt3-ai-content-generator'),
                'description' => __('Follow the important checks without forcing awkward wording.', 'gpt3-ai-content-generator'),
                'disabled_rules' => [
                    'keyphrase_in_image_alt',
                    'image_exists',
                    'rank_math_title_has_number',
                    'rank_math_title_power_word',
                    'rank_math_title_sentiment',
                    'aioseo_keyphrase_in_image_alt',
                    'aioseo_keyphrase_beginning_title',
                    'aioseo_headline_score',
                    'aioseo_content_assets',
                ],
            ],
            'content_first' => [
                'label' => __('Content first', 'gpt3-ai-content-generator'),
                'description' => __('Prioritize natural writing and keep only the essential SEO checks.', 'gpt3-ai-content-generator'),
                'disabled_rules' => [
                    'content_length',
                    'paragraph_length',
                    'heading_distribution',
                    'external_link_exists',
                    'keyphrase_in_image_alt',
                    'previously_used_keyphrase',
                    'keyword_density',
                    'focus_keyword_in_heading',
                    'yoast_consecutive_sentence_starts',
                    'yoast_transition_words',
                    'yoast_sentence_length',
                    'yoast_passive_voice',
                    'image_exists',
                    'competing_links',
                    'rank_math_title_start_with_keyword',
                    'rank_math_title_has_number',
                    'rank_math_title_power_word',
                    'rank_math_title_sentiment',
                    'rank_math_table_of_contents',
                    'rank_math_content_assets',
                    'rank_math_keyword_density',
                    'aioseo_keyphrase_in_content',
                    'aioseo_keyphrase_in_image_alt',
                    'aioseo_keyphrase_in_subheadings',
                    'aioseo_keyphrase_beginning_title',
                    'aioseo_headline_score',
                    'aioseo_content_assets',
                    'aioseo_sentence_length',
                    'aioseo_passive_voice',
                    'aioseo_transition_words',
                    'aioseo_consecutive_sentences',
                    'aioseo_subheading_distribution',
                    'aioseo_flesch_reading',
                    'aioseo_content_length',
                    'aioseo_external_links',
                ],
            ],
        ];
    }

    /**
     * @return array<string, array<int, array{id:string,group:string,label:string,description:string}>>
     */
    public static function grouped_rule_catalog(): array
    {
        $grouped = [];
        foreach (self::rule_catalog() as $rule) {
            $group = sanitize_key((string) ($rule['group'] ?? 'shared'));
            if (!isset($grouped[$group])) {
                $grouped[$group] = [];
            }
            $grouped[$group][] = $rule;
        }

        return $grouped;
    }

    /**
     * @return string[]
     */
    public static function allowed_rule_ids(): array
    {
        $ids = [];
        foreach (self::rule_catalog() as $rule) {
            $rule_id = sanitize_key((string) ($rule['id'] ?? ''));
            if ($rule_id !== '') {
                $ids[$rule_id] = true;
            }
        }

        return array_keys($ids);
    }

    /**
     * @return string[]
     */
    public static function default_disabled_rule_ids(): array
    {
        return self::preset_disabled_rule_ids('balanced');
    }

    /**
     * @return string[]
     */
    public static function preset_disabled_rule_ids(string $preset_key): array
    {
        $preset_key = sanitize_key($preset_key);
        $presets = self::rule_presets();
        $rules = $presets[$preset_key]['disabled_rules'] ?? [];

        return self::sanitize_rule_ids($rules);
    }

    /**
     * @return string[]
     * @param mixed $value
     */
    private static function sanitize_rule_ids($value): array
    {
        if (is_string($value)) {
            $trimmed = trim($value);
            if ($trimmed === '') {
                $value = [];
            } else {
                $decoded = json_decode($trimmed, true);
                if (!is_array($decoded)) {
                    $decoded = json_decode(stripslashes($trimmed), true);
                }
                $value = is_array($decoded) ? $decoded : explode(',', $trimmed);
            }
        }

        if (!is_array($value)) {
            return [];
        }

        $allowed = array_fill_keys(self::allowed_rule_ids(), true);
        $rules = [];
        foreach ($value as $key => $raw_rule_id) {
            $rule_id = is_string($key) && !is_numeric($key) && !empty($raw_rule_id)
                ? $key
                : $raw_rule_id;
            if (!is_scalar($rule_id)) {
                continue;
            }

            $rule_id = sanitize_key((string) $rule_id);
            if ($rule_id === '' || empty($allowed[$rule_id])) {
                continue;
            }

            $rules[$rule_id] = true;
        }

        return array_keys($rules);
    }
}
